"""PlanetaryPy unified CLI.

Usage:
    plp fetch mro.ctx.edr P02_001916_2221_XI_42N027W
    plp hifetch PSP_003092_0985 --browse
    plp ctxqv J05_046771_1950
    plp catalog build
"""

import click
import typer

app = typer.Typer(
    name="plp",
    help="PlanetaryPy — Python tools for planetary science data access.",
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)


# ── fetch ────────────────────────────────────────────────────────────


def _complete_product_id(ctx: click.Context, args: list[str], incomplete: str) -> list[str]:
    """Context-aware tab completion for product IDs based on the key argument.

    Routes the dotted ``key`` argument to :func:`planetarypy.pds.complete_pid`,
    which handles every registered PDS index uniformly (per-index column
    selection, prefix stripping, and bare-PID normalization come from
    :class:`planetarypy.catalog._index_resolver.IndexConfig`). Both forms are
    accepted: a direct index key (``cassini.iss.index``, used by ``plp meta``)
    or a catalog product key (``cassini.iss.edr_sat``, used by ``plp fetch``).
    """
    key = ctx.params.get("key", "")
    if not key:
        return []
    try:
        from planetarypy.pds import complete_pid
        from planetarypy.pds.utils import _all_dotted_index_keys

        if key in _all_dotted_index_keys():
            return complete_pid(incomplete, key)

        from planetarypy.catalog._index_resolver import INDEX_REGISTRY
        parts = tuple(key.split("."))
        if len(parts) == 3 and parts in INDEX_REGISTRY:
            return complete_pid(incomplete, INDEX_REGISTRY[parts].index_key)
    except Exception:
        pass
    return []


@app.command()
def fetch(
    key: str = typer.Argument(help="Dotted product key, e.g. mro.ctx.edr"),
    product_id: str = typer.Argument(help="Product identifier",
                                     autocompletion=_complete_product_id),
    force: bool = typer.Option(False, "--force", "-f", help="Re-download even if cached"),
    label_only: bool = typer.Option(False, "--label-only", "-l", help="Download only the label file"),
    here: bool = typer.Option(False, "--here", "-H", help="Download into current directory instead of planetarypy storage"),
    folder: bool = typer.Option(False, "--folder", "-d", help="Print the local folder instead of file paths (composes with `cd`)"),
):
    """Download a PDS product by ID.

    Examples:
        plp fetch mro.ctx.edr P02_001916_2221_XI_42N027W
        plp fetch --here mro.ctx.edr P02_001916_2221_XI_42N027W
        cd (plp fetch --folder mro.ctx.edr P02_001916_2221_XI_42N027W)
    """
    from pathlib import Path

    from planetarypy.catalog import fetch_product, get_product_urls

    typer.echo(f"Resolving {key} / {product_id}...", err=True)
    try:
        for url in get_product_urls(key, product_id).values():
            typer.echo(f"URL: {url}", err=True)

        downloaded = fetch_product(
            key, product_id,
            local_dir=Path.cwd() if here else None,
            label_only=label_only, force=force,
        )
        # Stdout-only payload so shell command substitution composes:
        #   --folder         -> single line, the folder        (cd (plp fetch --folder …))
        #   default          -> one line per file, full paths  (qgis (plp fetch …))
        if folder:
            typer.echo(downloaded.local_dir)
        else:
            for f in downloaded.files:
                typer.echo(f)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)


# ── HiRISE commands ─────────────────────────────────────────────────


def _complete_hirise_obsid_rdr(incomplete: str) -> list[str]:
    """Tab-completion for HiRISE obsids with RDR products (browse, RDR fetch)."""
    from planetarypy.pds import complete_pid
    return complete_pid(incomplete, "mro.hirise.rdr")


def _complete_hirise_obsid_edr(incomplete: str) -> list[str]:
    """Tab-completion for HiRISE obsids from EDR index (all observations)."""
    from planetarypy.pds import complete_pid
    return complete_pid(incomplete, "mro.hirise.edr")


@app.command()
def hibrowse(
    product_id: str = typer.Argument(
        help="HiRISE product ID, e.g. PSP_003092_0985_RED or PSP_004238_1135_RED1_1",
        autocompletion=_complete_hirise_obsid_rdr,
    ),
    annotated: bool = typer.Option(True, "--annotated/--clean", "-a/-c", help="Annotated (default) or clean browse"),
    here: bool = typer.Option(False, "--here", "-H", help="Download into current directory"),
    force: bool = typer.Option(False, "--force", "-f", help="Re-download even if cached"),
):
    """Download a HiRISE browse JPEG from EXTRAS.

    Bare observation IDs default to RDR RED browse.

    Examples:
        plp hibrowse PSP_003092_0985_RED          (annotated browse)
        plp hibrowse --clean PSP_003092_0985_RED   (clean browse)
        plp hibrowse ESP_075422_2040_COLOR
        plp hibrowse PSP_004238_1135_RED1_1       (EDR CCD)
        plp hibrowse PSP_003092_0985              (defaults to RDR RED)
    """
    from pathlib import Path
    from planetarypy.instruments.mro.hirise import browse_url, get_browse

    # Show URL immediately so user knows we're waiting on the server
    typer.echo(f"Fetching {browse_url(product_id, annotated=annotated)}", err=True)

    try:
        dest = Path.cwd() if here else None
        outpath = get_browse(product_id, annotated=annotated, dest=dest, force=force)
        # Raw path on stdout so `qgis (plp hibrowse …)` and similar
        # shell substitutions capture just the path.
        typer.echo(outpath)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

    import platform
    if platform.system() == "Darwin":
        import subprocess
        subprocess.Popen(["open", str(outpath)])


@app.command()
def hiedr(
    obsid: str = typer.Argument(help="HiRISE observation ID, e.g. PSP_003092_0985",
                                autocompletion=_complete_hirise_obsid_edr),
    red: bool = typer.Option(False, "--red", help="Download RED CCDs (RED0–RED9, 20 files)"),
    ir: bool = typer.Option(False, "--ir", help="Download IR CCDs (IR10–IR11, 4 files)"),
    bg: bool = typer.Option(False, "--bg", help="Download BG CCDs (BG12–BG13, 4 files)"),
    ccds: str = typer.Option(None, "--ccds", help="Specific CCD numbers, e.g. '4,5' for RED4+RED5 only"),
    here: bool = typer.Option(False, "--here", "-H", help="Download into current directory"),
    force: bool = typer.Option(False, "--force", "-f", help="Re-download even if cached"),
):
    """Download HiRISE EDR channel files by observation ID.

    Downloads both channels (0 and 1) for each CCD in the selected color.
    If no color flag is given, defaults to --red.

    Examples:
        plp hiedr PSP_003092_0985 --red           (all 20 RED files)
        plp hiedr PSP_003092_0985 --red --ccds 4,5 (RED4+RED5 only, 4 files)
        plp hiedr PSP_003092_0985 --ir             (IR10+IR11, 4 files)
        plp hiedr PSP_003092_0985 --bg             (BG12+BG13, 4 files)
        plp hiedr PSP_003092_0985 --here --ccds 4,5 (download to current dir)
    """
    from pathlib import Path
    from planetarypy.instruments.mro.hirise import download_edr, edr_products

    # Default to RED if nothing specified
    if not red and not ir and not bg:
        red = True

    colors = []
    if red:
        colors.append("red")
    if ir:
        colors.append("ir")
    if bg:
        colors.append("bg")

    ccd_nums = [int(n) for n in ccds.split(",")] if ccds else None
    saveroot = Path.cwd() if here else None

    products = edr_products(obsid, colors=colors, ccds=ccd_nums, saveroot=saveroot)
    typer.echo(f"{obsid}: {len(products)} EDR files from {products[0].url.parent}")

    try:
        download_edr(obsid, colors=colors, ccds=ccd_nums, saveroot=saveroot, overwrite=force)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

    typer.echo(f"Stored in: {products[0].local_path.parent}")


@app.command()
def himos(
    obsid: str = typer.Argument(
        help="HiRISE observation ID, e.g. PSP_003092_0985",
        autocompletion=_complete_hirise_obsid_edr,
    ),
    red: bool = typer.Option(False, "--red", help="Process RED CCDs"),
    ir: bool = typer.Option(False, "--ir", help="Process IR CCDs"),
    bg: bool = typer.Option(False, "--bg", help="Process BG CCDs"),
    ccds: str = typer.Option(None, "--ccds", help="Specific CCD numbers, e.g. '4,5'"),
    mapfile: str = typer.Option(None, "--map", "-m", help="ISIS map projection file (.map)"),
    overwrite: bool = typer.Option(False, "--force", "-f", help="Reprocess even if mosaic exists"),
):
    """Create a HiRISE CCD mosaic from EDR data via ISIS.

    Full pipeline: download → hi2isis → spiceinit → hical → histitch →
    cubenorm → cam2map → equalizer → automos.

    If no color flag is given, defaults to --red.

    Examples:
        plp himos PSP_003092_0985                    (all 10 RED CCDs)
        plp himos PSP_003092_0985 --ccds 4,5         (RED4+RED5 central pair)
        plp himos PSP_003092_0985 --ir               (IR mosaic)
        plp himos PSP_003092_0985 --red --ir --bg    (all three colors)
        plp himos PSP_003092_0985 --map mymap.map    (custom projection)
    """
    from planetarypy.instruments.mro.hirise import create_mosaics

    if not red and not ir and not bg:
        red = True

    colors = []
    if red:
        colors.append("red")
    if ir:
        colors.append("ir")
    if bg:
        colors.append("bg")

    ccd_nums = [int(n) for n in ccds.split(",")] if ccds else None

    try:
        results = create_mosaics(
            obsid, colors=colors, ccds=ccd_nums,
            mapfile=mapfile, overwrite=overwrite,
        )
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

    for color, path in results.items():
        typer.echo(f"{color.upper()} mosaic: {path}")


# ── CTX commands ────────────────────────────────────────────────────


def _complete_ctx_pid(incomplete: str) -> list[str]:
    """Tab-completion callback for CTX product IDs."""
    from planetarypy.pds import complete_pid
    return complete_pid(incomplete, "mro.ctx.edr")


@app.command()
def ctxqv(
    imgid: str = typer.Argument(
        help="CTX product ID (short or full), e.g. J05_046771_1950",
        autocompletion=_complete_ctx_pid,
    ),
    stride: int = typer.Option(10, "--stride", "-s", help="Downsample factor"),
    save: str = typer.Option(None, "--save", "-o", help="Save to PNG instead of displaying"),
    stretch: str = typer.Option("1,99", "--stretch", "-p", help="Percentile stretch as 'low,high'. Use 'none' to disable."),
    edr: bool = typer.Option(False, "--edr", help="Force raw EDR, skip calibrated files"),
    center_box: int = typer.Option(None, "--center-box", "-c", help="Show full-res center crop of N pixels (default 500 if flag used)"),
):
    """Show a downsampled quickview of a CTX image.

    Automatically uses the best available level:
    map-projected > calibrated > cube > raw EDR.

    Use --center-box to also show a full-resolution crop from the image center.
    """
    import matplotlib.pyplot as plt
    import numpy as np

    arr = None
    full_arr = None
    level = None
    pid = imgid

    need_center = center_box is not None
    source_path = None

    if not edr:
        try:
            from planetarypy.instruments.mro.ctx.ctx_calib import Calib

            typer.echo(f"Checking for calibrated products for {imgid}...")
            calib = Calib(imgid)
            pid = calib.edr.pid
            arr, path, level = calib.quickview(stride=stride)
            if arr is not None:
                typer.echo(f"Using {level} product: {path.name}")
                source_path = path
        except Exception:
            pass

    if arr is None:
        from planetarypy.instruments.mro.ctx.ctx_edr import EDR

        typer.echo(f"Using raw EDR for {imgid} (stride={stride})...")
        edr_obj = EDR(imgid)
        pid = edr_obj.pid
        arr = edr_obj.quickview(stride=stride)
        level = "edr"
        source_path = edr_obj.path

    typer.echo(f"Image: {arr.shape[1]}x{arr.shape[0]} px [{level}]")

    from planetarypy.plotting import imshow_gray

    if need_center and source_path is not None:
        box = center_box
        # Read only the center crop at full resolution using rioxarray windowed read
        import rioxarray as rxr
        da = rxr.open_rasterio(source_path, chunks=True).isel(band=0, drop=True)
        h, w = da.shape
        cy, cx = h // 2, w // 2
        half = box // 2
        y0 = max(0, cy - half)
        y1 = min(h, cy + half)
        x0 = max(0, cx - half)
        x1 = min(w, cx + half)
        crop = da.values[y0:y1, x0:x1]

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 7),
                                        gridspec_kw={"width_ratios": [1, 1]})
        imshow_gray(arr, stretch=stretch, title=f"{pid} [{level}]", ax=ax1)

        # Draw center box indicator on the overview
        oy0, ox0 = y0 // stride, x0 // stride
        oy1, ox1 = y1 // stride, x1 // stride
        from matplotlib.patches import Rectangle
        rect = Rectangle((ox0, oy0), ox1 - ox0, oy1 - oy0,
                          linewidth=1.5, edgecolor="red", facecolor="none")
        ax1.add_patch(rect)

        imshow_gray(crop, stretch=stretch, title=f"center {box}px full-res", ax=ax2)
        fig.tight_layout()
        typer.echo(f"Center crop: {crop.shape[1]}x{crop.shape[0]} px at ({cx},{cy})")
    else:
        ax = imshow_gray(arr, stretch=stretch, title=f"{pid} [{level}]")
        fig = ax.get_figure()
        fig.tight_layout()

    if save:
        fig.savefig(save, dpi=150, bbox_inches="tight")
        typer.echo(f"Saved to {save}")
    else:
        plt.show()


# ── catalog ──────────────────────────────────────────────────────────

catalog_app = typer.Typer(help="PDS catalog management.", no_args_is_help=True)
app.add_typer(catalog_app, name="catalog")


@catalog_app.command("build")
def catalog_build(
    force: bool = typer.Option(False, "--force", help="Force rebuild from scratch"),
    validate_urls: bool = typer.Option(False, "--validate-urls", help="Run URL validation after build"),
):
    """Build the PDS catalog database from pdr-tests definitions."""
    from planetarypy.catalog import build_catalog

    typer.echo("Building PDS catalog...")
    stats = build_catalog(force=force)
    typer.echo(
        f"Done: {stats.get('instruments', '?')} instruments, "
        f"{stats.get('product_types', '?')} product types, "
        f"{stats.get('products', '?')} products"
    )
    if stats.get("ambiguous"):
        typer.echo(f"\nAmbiguous mappings ({len(stats['ambiguous'])}): {', '.join(stats['ambiguous'])}")

    if validate_urls:
        from planetarypy.catalog._validation import validate_urls as do_validate
        from planetarypy.config import config

        typer.echo("\nValidating URLs...")
        counts = do_validate(config.storage_root)
        typer.echo(f"URL validation: {counts}")


# ── catalog: browsing helpers + cross-reference to INDEX_REGISTRY ───


def _complete_index_key(incomplete: str) -> list[str]:
    """Tab completion: registered dotted index keys."""
    try:
        from planetarypy.pds.utils import _all_dotted_index_keys
        return [k for k in _all_dotted_index_keys() if k.startswith(incomplete)]
    except Exception:
        return []


def _fetchable_sets():
    """Return three sets covering which catalog entries are fetchable.

    A catalog (mission, instrument, product_key) triple is "fetchable"
    when ``INDEX_REGISTRY`` has an entry for it — meaning ``plp fetch``
    can resolve a product through the registered cumulative index.
    """
    from planetarypy.catalog._index_resolver import INDEX_REGISTRY
    triples = set(INDEX_REGISTRY.keys())
    return {
        "products": triples,
        "instruments": {(m, i) for (m, i, _) in triples},
        "missions": {m for (m, _, _) in triples},
    }


def _catalog_show_mission(mission: str, fetchable):
    from rich.console import Console
    from rich.table import Table

    from planetarypy.catalog import list_instruments
    from planetarypy.catalog._index_resolver import INDEX_REGISTRY
    from planetarypy.pds.utils import _all_dotted_index_keys

    instruments = list_instruments(mission)
    if not instruments:
        typer.echo(f"Unknown mission: {mission!r}", err=True)
        raise typer.Exit(1)

    # Pre-compute the registered indexes per instrument (from the static
    # index URL config), so we can distinguish three states for each
    # instrument: no index at all / indexed-but-no-fetch-resolver / fetchable.
    indexes_by_inst: dict[str, list[str]] = {}
    for k in _all_dotted_index_keys():
        m, i, idx = k.split(".", 2)
        if m == mission:
            indexes_by_inst.setdefault(i, []).append(idx)

    table = Table(
        title=f"{mission} instruments",
        title_style="bold",
        header_style="bold magenta",
        pad_edge=False,
    )
    table.add_column("instrument", style="cyan", no_wrap=True)
    table.add_column("registered indexes", overflow="fold")
    table.add_column("fetchable product types", overflow="fold")

    for inst in instruments:
        idx_names = sorted(indexes_by_inst.get(inst, []))
        fetch_keys = sorted(
            f"{p} → {cfg.index_key}"
            for (m, i, p), cfg in INDEX_REGISTRY.items()
            if (m, i) == (mission, inst)
        )
        if fetch_keys:
            fetch_cell = "\n".join(fetch_keys)
        elif idx_names:
            fetch_cell = "(no fetch resolver)"
        else:
            fetch_cell = ""
        table.add_row(inst, ", ".join(idx_names), fetch_cell)
    Console().print(table)


def _catalog_show_instrument(mission: str, instrument: str, fetchable):
    from rich.console import Console
    from rich.table import Table

    from planetarypy.catalog import list_products
    from planetarypy.catalog._index_resolver import INDEX_REGISTRY

    products = list_products(f"{mission}.{instrument}")
    if not products:
        typer.echo(f"Unknown mission.instrument: {mission!r}.{instrument!r}", err=True)
        raise typer.Exit(1)

    # `list_products` returns normalized_type names; the registry is keyed by
    # raw product_key. Show both perspectives.
    table = Table(
        title=f"{mission}.{instrument} product types",
        title_style="bold",
        header_style="bold magenta",
        pad_edge=False,
    )
    table.add_column("normalized type", style="cyan")
    table.add_column("registered fetchable variants", overflow="fold")

    by_type: dict[str, list[str]] = {}
    for (m, i, p), cfg in INDEX_REGISTRY.items():
        if (m, i) != (mission, instrument):
            continue
        # Best-effort: use the first prefix segment of product_key as the type.
        norm = p.split("_", 1)[0].lower()
        by_type.setdefault(norm, []).append(f"{p} → {cfg.index_key}")

    for ptype in products:
        variants = by_type.get(ptype, [])
        table.add_row(ptype, "\n".join(variants))
    # Surface any registry entries whose product_key didn't map to a normalized type.
    for ptype, variants in by_type.items():
        if ptype not in products:
            table.add_row(ptype + " (extra)", "\n".join(variants))
    Console().print(table)


@catalog_app.command("list")
def catalog_list(
    key: str = typer.Argument(
        None,
        help="Optional dotted key: 'mission' or 'mission.instrument'. "
             "Omit to list missions.",
    ),
):
    """Browse the pdr-tests catalog inventory.

    Examples:
        plp catalog list                       # all missions
        plp catalog list cassini               # cassini instruments
        plp catalog list cassini.iss           # cassini.iss product types
    """
    from rich.console import Console
    from rich.table import Table

    fetchable = _fetchable_sets()

    if key is None:
        from planetarypy.catalog import list_missions, summary

        summary_df = summary().set_index("mission")
        missions = list_missions()
        table = Table(
            title=f"PDS catalog — {len(missions)} missions",
            title_style="bold",
            header_style="bold magenta",
            pad_edge=False,
        )
        table.add_column("mission", style="cyan", no_wrap=True)
        table.add_column("instruments", justify="right")
        table.add_column("product types", justify="right")
        table.add_column("products", justify="right")
        table.add_column("fetchable", justify="center")
        for m in missions:
            row = summary_df.loc[m] if m in summary_df.index else None
            instr_n = int(row["instruments"]) if row is not None else 0
            ptype_n = int(row["product_types"]) if row is not None else 0
            prod_n = int(row["products"]) if row is not None else 0
            mark = "✓" if m in fetchable["missions"] else ""
            table.add_row(m, str(instr_n), str(ptype_n), str(prod_n), mark)
        Console().print(table)
        return

    parts = key.split(".")
    if len(parts) == 1:
        _catalog_show_mission(parts[0], fetchable)
    elif len(parts) == 2:
        _catalog_show_instrument(parts[0], parts[1], fetchable)
    else:
        typer.echo(
            f"Too many dotted parts in {key!r}. Use 'plp catalog show <key>' "
            "for product-type detail.",
            err=True,
        )
        raise typer.Exit(1)


@catalog_app.command("show")
def catalog_show(
    key: str = typer.Argument(
        ...,
        help="Dotted key 'mission.instrument.product_key' for full detail.",
    ),
):
    """Show full catalog + INDEX_REGISTRY info for a single product type."""
    from rich.console import Console
    from rich.table import Table

    from planetarypy.catalog._index_resolver import INDEX_REGISTRY

    parts = key.split(".")
    if len(parts) != 3:
        typer.echo(
            f"Expected 'mission.instrument.product_key', got {key!r}.",
            err=True,
        )
        raise typer.Exit(1)
    mission, instrument, product_key = parts

    cfg = INDEX_REGISTRY.get((mission, instrument, product_key))

    table = Table(
        title=f"{key}",
        title_style="bold",
        header_style="bold magenta",
        show_header=False,
        pad_edge=False,
    )
    table.add_column("field", style="cyan", no_wrap=True)
    table.add_column("value", overflow="fold")
    table.add_row("mission", mission)
    table.add_row("instrument", instrument)
    table.add_row("product_key", product_key)

    if cfg is None:
        table.add_row("fetchable", "no — no INDEX_REGISTRY entry")
    else:
        table.add_row("fetchable", "yes")
        table.add_row("  index_key", cfg.index_key)
        if cfg.archive_url:
            table.add_row("  archive_url", cfg.archive_url)
        if cfg.seti_volume_group:
            table.add_row("  seti_volume_group", cfg.seti_volume_group)
        if cfg.extra_index_keys:
            table.add_row("  extra_index_keys", ", ".join(cfg.extra_index_keys))
        table.add_row("  product_id_col", cfg.product_id_col)
        if cfg.completion_id_col:
            table.add_row("  completion_id_col", cfg.completion_id_col)
        if cfg.pid_strip_prefix_re:
            table.add_row("  pid_strip_prefix_re", cfg.pid_strip_prefix_re)

    # Sample-products count from catalog DB (best-effort; may not be built yet)
    try:
        from planetarypy.catalog import example_products
        df = example_products(mission, instrument, product_key)
        table.add_row("catalog sample products", str(len(df)))
    except Exception:
        pass

    Console().print(table)


@catalog_app.command("search")
def catalog_search(
    query: str = typer.Argument(..., help="Substring to search across catalog fields."),
):
    """Search the catalog (mission/instrument/product_key/product_id)."""
    from rich.console import Console
    from rich.table import Table

    from planetarypy.catalog import search

    df = search(query)
    if df.empty:
        typer.echo(f"No catalog entries match {query!r}.")
        return

    table = Table(
        title=f"Catalog search: {query!r}  ({len(df)} hits)",
        title_style="bold",
        header_style="bold magenta",
        pad_edge=False,
    )
    for col in df.columns:
        table.add_column(str(col), overflow="fold")
    for _, row in df.iterrows():
        table.add_row(*[str(v) if v is not None else "" for v in row])
    Console().print(table)


@catalog_app.command("summary")
def catalog_summary():
    """Per-mission counts of instruments, product types, and products."""
    from rich.console import Console
    from rich.table import Table

    from planetarypy.catalog import summary

    df = summary()
    table = Table(title="Catalog summary", title_style="bold",
                  header_style="bold magenta", pad_edge=False)
    for col in df.columns:
        table.add_column(str(col),
                         justify="right" if col != "mission" else "left",
                         style="cyan" if col == "mission" else None,
                         no_wrap=(col == "mission"))
    for _, row in df.iterrows():
        table.add_row(*[str(v) for v in row])
    Console().print(table)


@catalog_app.command("ambiguous")
def catalog_ambiguous():
    """List instruments whose mission/instrument mapping is ambiguous."""
    from rich.console import Console
    from rich.table import Table

    from planetarypy.catalog import ambiguous_mappings

    df = ambiguous_mappings()
    if df.empty:
        typer.echo("No ambiguous mappings.")
        return
    table = Table(title=f"Ambiguous mappings ({len(df)})",
                  title_style="bold", header_style="bold magenta", pad_edge=False)
    for col in df.columns:
        table.add_column(str(col), overflow="fold")
    for _, row in df.iterrows():
        table.add_row(*[str(v) for v in row])
    Console().print(table)


# ── indexes: registered PDS index browse ─────────────────────────────

indexes_app = typer.Typer(
    help="Browse and manage registered PDS indexes.", no_args_is_help=True,
)
app.add_typer(indexes_app, name="indexes")


@indexes_app.command("list")
def indexes_list(
    key: str = typer.Argument(
        None,
        help="Optional dotted key: 'mission' or 'mission.instrument'. "
             "Omit to list missions.",
    ),
    tree: bool = typer.Option(
        False, "--tree",
        help="Render as a tree (mirrors planetarypy.pds.print_available_indexes).",
    ),
):
    """Browse the registered PDS indexes (the operational fetch surface).

    Examples:
        plp indexes list                     # all missions, summary table
        plp indexes list cassini             # cassini instruments
        plp indexes list cassini.iss         # cassini.iss indexes (with cache status)
        plp indexes list --tree              # full tree (legacy print_available_indexes)
    """
    from rich.console import Console
    from rich.table import Table

    from planetarypy.pds import print_available_indexes
    from planetarypy.pds.utils import _all_dotted_index_keys

    parts = key.split(".") if key else []
    if len(parts) > 2:
        typer.echo(
            f"Too many dotted parts in {key!r}. Use 'plp indexes info <key>' "
            "for single-index detail.",
            err=True,
        )
        raise typer.Exit(1)

    if tree:
        print_available_indexes(
            filter_mission=parts[0] if parts else None,
            filter_instrument=parts[1] if len(parts) == 2 else None,
        )
        return

    all_keys = _all_dotted_index_keys()

    if not parts:
        # Mission summary
        from collections import defaultdict
        by_mission: dict[str, dict[str, list[str]]] = defaultdict(
            lambda: defaultdict(list)
        )
        for k in all_keys:
            m, i, idx = k.split(".", 2)
            by_mission[m][i].append(idx)

        table = Table(
            title=f"Registered PDS indexes — {len(by_mission)} missions, "
                  f"{len(all_keys)} indexes",
            title_style="bold",
            header_style="bold magenta",
            pad_edge=False,
        )
        table.add_column("mission", style="cyan", no_wrap=True)
        table.add_column("instruments", justify="right")
        table.add_column("indexes", justify="right")
        table.add_column("breakdown", overflow="fold")
        for m in sorted(by_mission):
            instruments = by_mission[m]
            breakdown = ", ".join(
                f"{i} ({len(instruments[i])})" for i in sorted(instruments)
            )
            n_indexes = sum(len(v) for v in instruments.values())
            table.add_row(m, str(len(instruments)), str(n_indexes), breakdown)
        Console().print(table)
        return

    if len(parts) == 1:
        mission = parts[0]
        from collections import defaultdict
        by_instrument: dict[str, list[str]] = defaultdict(list)
        for k in all_keys:
            m, i, idx = k.split(".", 2)
            if m == mission:
                by_instrument[i].append(idx)
        if not by_instrument:
            typer.echo(f"No registered indexes for mission {mission!r}.", err=True)
            raise typer.Exit(1)

        table = Table(
            title=f"{mission} — registered indexes",
            title_style="bold",
            header_style="bold magenta",
            pad_edge=False,
        )
        table.add_column("instrument", style="cyan", no_wrap=True)
        table.add_column("indexes", justify="right")
        table.add_column("names", overflow="fold")
        for i in sorted(by_instrument):
            names = sorted(by_instrument[i])
            table.add_row(i, str(len(names)), ", ".join(names))
        Console().print(table)
        return

    # mission.instrument: per-index table with cache + catalog x-ref
    from planetarypy.catalog._index_resolver import INDEX_REGISTRY
    from planetarypy.pds import Index

    mission, instrument = parts
    matching = sorted(
        k for k in all_keys
        if k.startswith(f"{mission}.{instrument}.")
    )
    if not matching:
        typer.echo(
            f"No registered indexes for {mission!r}.{instrument!r}.", err=True
        )
        raise typer.Exit(1)

    catalog_xref: dict[str, list[str]] = {}
    for (m, i, p), cfg in INDEX_REGISTRY.items():
        catalog_xref.setdefault(cfg.index_key, []).append(f"{m}.{i}.{p}")

    table = Table(
        title=f"{mission}.{instrument} — registered indexes",
        title_style="bold",
        header_style="bold magenta",
        pad_edge=False,
    )
    table.add_column("index_key", style="cyan", no_wrap=True)
    table.add_column("cached", justify="center")
    table.add_column("size", justify="right")
    table.add_column("catalog entry", overflow="fold")
    for k in matching:
        try:
            idx = Index(k)
            parq = idx.local_parq_path
            if parq.is_file():
                cached = "✓"
                size = f"{parq.stat().st_size / 1e6:.1f} MB"
            else:
                cached = ""
                size = ""
        except Exception:
            cached = "?"
            size = ""
        xref = ", ".join(catalog_xref.get(k, []))
        table.add_row(k, cached, size, xref)
    Console().print(table)


@indexes_app.command("info")
def indexes_info(
    key: str = typer.Argument(..., help="Dotted index key, e.g. cassini.iss.index",
                              autocompletion=_complete_index_key),
):
    """Show config + cache status for a registered PDS index."""
    from rich.console import Console
    from rich.table import Table

    from planetarypy.pds import Index
    from planetarypy.pds.utils import (
        _all_dotted_index_keys,
        _completion_id_col_for,
        _index_config_for,
    )

    if key not in _all_dotted_index_keys():
        typer.echo(f"Unknown index key: {key!r}.", err=True)
        raise typer.Exit(1)

    idx = Index(key)
    cfg = _index_config_for(key)

    table = Table(title=key, title_style="bold", show_header=False, pad_edge=False)
    table.add_column("field", style="cyan", no_wrap=True)
    table.add_column("value", overflow="fold")

    table.add_row("index_key", key)
    try:
        table.add_row("remote URL", str(idx.url) if idx.url else "(unresolved)")
    except Exception as e:
        table.add_row("remote URL", f"(error: {e})")
    table.add_row("remote type", idx.remote_type)

    parq = idx.local_parq_path
    if parq.is_file():
        size_mb = parq.stat().st_size / 1e6
        table.add_row("local cached", f"yes — {parq}  ({size_mb:.1f} MB)")
    else:
        table.add_row("local cached", "no")

    table.add_row(
        "completion column", _completion_id_col_for(key)
    )
    if cfg is not None:
        table.add_row("PID column", cfg.product_id_col)
        if cfg.pid_strip_prefix_re:
            table.add_row("pid_strip_prefix_re", cfg.pid_strip_prefix_re)
        if cfg.archive_url:
            table.add_row("archive_url", cfg.archive_url)
        if cfg.seti_volume_group:
            table.add_row("seti_volume_group", cfg.seti_volume_group)

    # Catalog cross-reference
    catalog_keys = []
    from planetarypy.catalog._index_resolver import INDEX_REGISTRY
    for (m, i, p), c in INDEX_REGISTRY.items():
        if c.index_key == key or key in c.extra_index_keys:
            catalog_keys.append(f"{m}.{i}.{p}")
    if catalog_keys:
        table.add_row("catalog entries", "\n".join(sorted(catalog_keys)))

    Console().print(table)


@indexes_app.command("refresh")
def indexes_refresh(
    config: bool = typer.Option(
        False, "--config",
        help="Force-refresh upstream URL config (planetarypy_index_urls.toml).",
    ),
    cache: str = typer.Option(None, "--cache",
                              help="Re-download a specific index's cumulative parquet.",
                              autocompletion=_complete_index_key),
):
    """Refresh upstream index config or re-download a single index."""
    if not config and not cache:
        typer.echo("Pass --config to refresh the upstream URL TOML, "
                   "or --cache <KEY> to re-download a single index.", err=True)
        raise typer.Exit(1)

    if config:
        from planetarypy.pds.static_index import ConfigHandler
        h = ConfigHandler(force_update=True)
        typer.echo(f"Refreshed upstream config → {h.path}")

    if cache:
        from planetarypy.pds import Index
        idx = Index(cache, force_config_update=False)
        typer.echo(f"Re-downloading {cache} ...", err=True)
        idx.download(force=True)
        typer.echo(f"Cached at: {idx.local_parq_path}")


# ── CTX housekeeping ────────────────────────────────────────────────


@app.command("ctx-migrate")
def ctx_migrate(
    dry_run: bool = typer.Option(
        False, "--dry-run", "-n",
        help="Show what would be moved without touching anything",
    ),
):
    """Move existing CTX files on disk to match current [edr.local] layout.

    Scans each ``mrox_*`` volume folder under the configured EDR local
    root and relocates any file named ``<pid>.<ext>`` (26-char CTX
    product_id) to the location that the active config dictates.
    Idempotent: a second run does nothing.

    Typical use: after switching ``[edr.local].with_pid`` between
    ``false`` and ``true``, run this once to bring existing downloads
    (and any co-located derived files) into the new layout.
    """
    from planetarypy.instruments.mro.ctx.ctx_edr import _edr_local_folder

    root = _edr_local_folder()
    if not root.is_dir():
        typer.echo(f"No CTX storage at {root}", err=True)
        raise typer.Exit(1)

    moved = 0
    skipped = 0
    conflicts = 0
    for vol_dir in sorted(root.glob("mrox_*")):
        if not vol_dir.is_dir():
            continue
        # Walk recursively so files already nested in <pid>/ subfolders
        # get tallied as "already in place", not silently skipped.
        for f in vol_dir.rglob("*"):
            if not f.is_file():
                continue
            head, sep, _ = f.name.partition(".")
            if not sep or len(head) != 26:
                continue
            pid = head
            target = _edr_local_folder(volume=vol_dir.name, pid=pid) / f.name
            if f.resolve() == target.resolve():
                skipped += 1
                continue
            if target.exists():
                typer.echo(
                    f"[conflict] {f} → {target} (target already exists, skipping)",
                    err=True,
                )
                conflicts += 1
                continue
            if dry_run:
                typer.echo(f"[dry-run] {f} → {target}")
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                f.rename(target)
                typer.echo(f"{f} → {target}")
            moved += 1
    verb = "would move" if dry_run else "moved"
    typer.echo(
        f"{verb}: {moved}; already in place: {skipped}; conflicts: {conflicts}",
        err=True,
    )


# ── spicer ───────────────────────────────────────────────────────────


@app.command()
def spicer(
    body: str = typer.Argument(help="NAIF body name, e.g. Mars, Moon, Enceladus"),
    time: str = typer.Option(None, "--time", "-t", help="UTC time (default: now)"),
    lon: float = typer.Option(None, "--lon", help="Longitude [deg] for surface illumination"),
    lat: float = typer.Option(None, "--lat", help="Latitude [deg] for surface illumination"),
):
    """Show current SPICE data for a solar system body.

    Without --lon/--lat, shows global properties (L_s, subsolar point,
    solar constant). With coordinates, adds surface illumination.

    Examples:
        plp spicer Mars
        plp spicer Moon --time 2024-06-15T12:00:00
        plp spicer Mars --lon 137.4 --lat -4.6
    """
    from planetarypy.spice.spicer import Spicer

    try:
        s = Spicer(body)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

    typer.echo(f"\n  {s.body}")
    typer.echo(f"  {'=' * len(s.body)}")
    typer.echo(f"  Radii:          {s.radii.a:.1f} x {s.radii.b:.1f} x {s.radii.c:.1f} km")
    typer.echo(f"  Reference frame: {s.ref_frame}")

    try:
        ls = s.solar_longitude(time)
        typer.echo(f"\n  Solar longitude (L_s): {ls:.1f}")
    except Exception:
        typer.echo("\n  Solar longitude:       (needs ephemeris kernels)")

    try:
        ss_lon, ss_lat = s.subsolar_point(time)
        typer.echo(f"  Sub-solar point:       lon={ss_lon:.2f}, lat={ss_lat:.2f}")
    except Exception:
        typer.echo("  Sub-solar point:       (needs ephemeris kernels)")

    try:
        sc = s.solar_constant(time)
        typer.echo(f"  Solar constant:        {sc:.0f} W/m²")
    except Exception:
        typer.echo("  Solar constant:        (needs ephemeris kernels)")

    if lon is not None and lat is not None:
        try:
            illum = s.illumination(lon=lon, lat=lat, time=time)
            typer.echo(f"\n  Surface at ({lon}, {lat}):")
            typer.echo(f"    Solar incidence:   {illum.solar_incidence:.1f}")
            typer.echo(f"    Solar flux:        {illum.solar_flux:.0f} W/m²")
            typer.echo(f"    Local solar time:  {illum.local_solar_time}")

            az = s.solar_azimuth_at(lon, lat, time)
            typer.echo(f"    Solar azimuth:     {az:.1f} (CW from N)")
        except Exception as e:
            typer.echo("\n  Surface illumination: (needs ephemeris kernels)")
            typer.echo(f"    {e}")

    typer.echo()


# ── example_pid ──────────────────────────────────────────────────────


@app.command("example_pid")
def example_pid(
    key: str = typer.Argument(
        help="Dotted index key, e.g. mro.ctx.edr",
        autocompletion=_complete_index_key,
    ),
):
    """Print an example product ID from a registered PDS index.

    Useful as a seed for `plp fetch`, demo notebooks, and smoke tests.

    Examples:
        plp example_pid mro.ctx.edr
        plp example_pid cassini.iss.index
    """
    from planetarypy.pds import get_example_pid

    try:
        pid = get_example_pid(key)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

    typer.echo(pid)


# ── meta ─────────────────────────────────────────────────────────────


@app.command("meta")
def meta(
    key: str = typer.Argument(
        help="Dotted index key, e.g. mro.ctx.edr",
        autocompletion=_complete_index_key,
    ),
    product_id: str = typer.Argument(
        help="Product identifier",
        autocompletion=_complete_product_id,
    ),
    long: bool = typer.Option(
        False, "--long", "-l",
        help="Request the long form when the index has a custom display "
             "(no effect on indexes that always return the full row).",
    ),
):
    """Print the metadata row for a product from its PDS cumulative index.

    Thin wrapper around ``planetarypy.pds.get_meta(key, product_id, long=...)``.
    Matches the product ID against the configured (or conventional) PID
    column, tolerant of case and PDS path/extension/version-suffix
    decoration. Indexes may register custom display logic (short summaries,
    multi-row aggregation, …) which the ``--long`` flag toggles into the
    full-row form.

    Examples:
        plp meta mro.ctx.edr P02_001916_2221_XI_42N027W
        plp meta cassini.iss.index 1_N1454725799
    """
    from rich.console import Console
    from rich.table import Table

    from planetarypy.pds import get_meta

    try:
        row = get_meta(key, product_id, long=long)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1)

    title_pid = (
        row.get("PRODUCT_ID")
        or row.get("OBSERVATION_ID")
        or row.get("FILE_NAME")
        or product_id
    )
    table = Table(
        title=f"{key} — {str(title_pid).strip()}",
        title_style="bold",
        header_style="bold magenta",
        show_lines=False,
        pad_edge=False,
    )
    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Value", overflow="fold")
    for col, val in row.items():
        table.add_row(str(col), "" if val is None else str(val))

    Console().print(table)


def main():
    app()
