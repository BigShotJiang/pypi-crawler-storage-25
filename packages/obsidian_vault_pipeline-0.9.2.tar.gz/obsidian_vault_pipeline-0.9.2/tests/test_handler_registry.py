from __future__ import annotations

import inspect

from ovp_pipeline.handler_registry import resolve_focused_action_handler, resolve_stage_handler


def test_compatibility_pack_falls_back_to_base_stage_handler():
    spec = resolve_stage_handler(
        pack_name="default-knowledge",
        stage="articles",
        runtime_adapter="pipeline_step",
    )

    assert spec.pack == "research-tech"
    assert spec.stage == "articles"
    assert spec.runtime_adapter == "pipeline_step"


def test_compatibility_pack_falls_back_to_base_focused_action_handler():
    spec = resolve_focused_action_handler(
        pack_name="default-knowledge",
        action_kind="deep_dive_workflow",
    )

    assert spec.pack == "research-tech"
    assert spec.action_kind == "deep_dive_workflow"
    assert spec.safe_to_run is True
    assert spec.entrypoint == (
        "ovp_pipeline.packs.research_tech.focused_actions:run_deep_dive_workflow_action"
    )


def test_focused_action_handlers_accept_positional_vault_and_action():
    from ovp_pipeline.focused_actions import (
        run_deep_dive_workflow_action,
        run_object_extraction_workflow_action,
    )

    inspect.signature(run_deep_dive_workflow_action).bind("vault", {})
    inspect.signature(run_object_extraction_workflow_action).bind("vault", {})


def test_execute_profile_stage_handler_preserves_caller_owned_empty_results(monkeypatch):
    import ovp_pipeline.handler_registry as registry_source
    from ovp_pipeline.packs.base import StageHandlerSpec

    captured: dict[str, object] = {}

    monkeypatch.setattr(
        registry_source,
        "resolve_stage_handler",
        lambda **kwargs: StageHandlerSpec(
            name="articles",
            pack="research-tech",
            handler_kind="profile_stage",
            runtime_adapter="pipeline_step",
            entrypoint="tests.fake:handler",
            stage="articles",
        ),
    )
    monkeypatch.setattr(
        registry_source,
        "load_entrypoint",
        lambda entrypoint: (
            lambda **kwargs: captured.setdefault("results", kwargs["results"]) or {"success": True}
        ),
    )

    owned_results: dict[str, object] = {}
    registry_source.execute_profile_stage_handler(object(), "articles", results=owned_results)

    assert captured["results"] is owned_results


def test_execute_autopilot_stage_handler_preserves_caller_owned_empty_result(monkeypatch):
    import ovp_pipeline.handler_registry as registry_source
    from ovp_pipeline.packs.base import StageHandlerSpec

    captured: dict[str, object] = {}

    monkeypatch.setattr(
        registry_source,
        "resolve_stage_handler",
        lambda **kwargs: StageHandlerSpec(
            name="quality",
            pack="research-tech",
            handler_kind="profile_stage",
            runtime_adapter="autopilot_stage",
            entrypoint="tests.fake:handler",
            stage="quality",
        ),
    )
    monkeypatch.setattr(
        registry_source,
        "load_entrypoint",
        lambda entrypoint: (
            lambda **kwargs: captured.setdefault("result", kwargs["result"]) or {"quality": 4.0}
        ),
    )

    owned_result: dict[str, object] = {}
    registry_source.execute_autopilot_stage_handler(object(), "quality", result=owned_result)

    assert captured["result"] is owned_result


def test_execute_profile_stage_handler_uses_execution_contract_resolution(monkeypatch):
    import ovp_pipeline.handler_registry as registry_source
    from ovp_pipeline.execution_contract_registry import ExecutionContractSpec
    from ovp_pipeline.packs.base import ProcessorContractSpec, StageHandlerSpec

    monkeypatch.setattr(
        registry_source,
        "resolve_stage_handler",
        lambda **kwargs: (_ for _ in ()).throw(AssertionError("legacy stage resolver should not run")),
    )
    monkeypatch.setattr(
        registry_source,
        "resolve_stage_execution_contract",
        lambda **kwargs: ExecutionContractSpec(
            handler_spec=StageHandlerSpec(
                name="articles",
                pack="research-tech",
                handler_kind="profile_stage",
                runtime_adapter="pipeline_step",
                entrypoint="tests.fake:handler",
                stage="articles",
            ),
            processor_contract=ProcessorContractSpec(
                name="articles",
                pack="research-tech",
                stage="articles",
                mode="llm_structured",
                inputs=("source_note",),
                outputs=("deep_dive",),
                entrypoint="tests.fake:processor",
            ),
        ),
    )

    captured: dict[str, object] = {}
    monkeypatch.setattr(
        registry_source,
        "load_entrypoint",
        lambda entrypoint: lambda **kwargs: (
            captured.setdefault("spec", kwargs["spec"]),
            {"ok": True},
        )[1],
    )

    result = registry_source.execute_profile_stage_handler(object(), "articles")

    assert result == {"ok": True}
    assert captured["spec"].stage == "articles"


def test_execute_focused_action_handler_uses_execution_contract_resolution(monkeypatch):
    import ovp_pipeline.handler_registry as registry_source
    from ovp_pipeline.execution_contract_registry import ExecutionContractSpec
    from ovp_pipeline.packs.base import ProcessorContractSpec, StageHandlerSpec

    monkeypatch.setattr(
        registry_source,
        "resolve_focused_action_handler",
        lambda **kwargs: (
            (_ for _ in ()).throw(AssertionError("legacy focused resolver should not run"))
        ),
    )
    monkeypatch.setattr(
        registry_source,
        "resolve_focused_action_execution_contract",
        lambda **kwargs: ExecutionContractSpec(
            handler_spec=StageHandlerSpec(
                name="deep-dive",
                pack="research-tech",
                handler_kind="focused_action",
                runtime_adapter="focused_action",
                entrypoint="tests.fake:handler",
                action_kind="deep_dive_workflow",
            ),
            processor_contract=ProcessorContractSpec(
                name="deep-dive",
                pack="research-tech",
                action_kind="deep_dive_workflow",
                mode="llm_structured",
                inputs=("source_note",),
                outputs=("deep_dive",),
                entrypoint="tests.fake:processor",
            ),
        ),
    )

    monkeypatch.setattr(
        registry_source,
        "load_entrypoint",
        lambda entrypoint: lambda vault_dir, action: {"output_path": "demo.md"},
    )

    spec, result = registry_source.execute_focused_action_handler("/tmp/vault", {"action_kind": "deep_dive_workflow"})

    assert spec.action_kind == "deep_dive_workflow"
    assert result == {"output_path": "demo.md"}
