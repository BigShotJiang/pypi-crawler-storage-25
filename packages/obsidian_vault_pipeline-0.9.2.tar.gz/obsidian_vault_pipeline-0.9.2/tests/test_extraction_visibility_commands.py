from __future__ import annotations

import json
from pathlib import Path


def _write_run(layout, *, source_name: str, profile_name: str, values: dict[str, object]) -> Path:
    from ovp_pipeline.derived.paths import extraction_run_path
    from ovp_pipeline.extraction.results import ExtractionRecord, ExtractionRunResult, ExtractionSpan

    source_path = Path(f"50-Inbox/01-Raw/{source_name}")
    artifact_path = extraction_run_path(
        layout,
        pack_name="default-knowledge",
        profile_name=profile_name,
        source_path=source_path,
    )
    artifact_path.parent.mkdir(parents=True, exist_ok=True)
    artifact_path.write_text(
        json.dumps(
            ExtractionRunResult(
                pack_name="default-knowledge",
                profile_name=profile_name,
                source_path=str(source_path),
                records=[
                    ExtractionRecord(
                        values=values,
                        spans=[
                            ExtractionSpan(
                                source_path=str(source_path),
                                section_title=str(values.get("section_title") or values.get("subject") or ""),
                                char_start=0,
                                char_end=20,
                                quote="example quote",
                            )
                        ],
                    )
                ],
            ).to_dict(),
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    return artifact_path


def test_extract_preview_command_returns_latest_artifact(temp_vault, capsys):
    from ovp_pipeline.commands import extract_preview
    from ovp_pipeline.runtime import VaultLayout

    layout = VaultLayout.from_vault(temp_vault)
    _write_run(
        layout,
        source_name="doc-one.md",
        profile_name="tech/doc_structure",
        values={"section_title": "Architecture", "summary": "Overview"},
    )

    exit_code = extract_preview.main(
        [
            "--vault-dir",
            str(temp_vault),
            "--pack",
            "default-knowledge",
            "--profile",
            "tech/doc_structure",
        ]
    )

    payload = json.loads(capsys.readouterr().out)
    assert exit_code == 0
    assert payload["profile_name"] == "tech/doc_structure"
    assert payload["record_count"] == 1
    assert payload["records"][0]["values"]["section_title"] == "Architecture"


def test_extract_preview_help_mentions_primary_pack(capsys):
    from ovp_pipeline.commands import extract_preview

    try:
        extract_preview.main(["--help"])
    except SystemExit as exc:
        assert exc.code == 0

    output = " ".join(capsys.readouterr().out.split())
    assert "compatibility pack" in output
    assert "research-tech" in output


def test_extract_preview_command_normalizes_source_filter(temp_vault, capsys):
    from ovp_pipeline.commands import extract_preview
    from ovp_pipeline.runtime import VaultLayout

    layout = VaultLayout.from_vault(temp_vault)
    _write_run(
        layout,
        source_name="doc-one.md",
        profile_name="tech/doc_structure",
        values={"section_title": "Architecture", "summary": "Overview"},
    )

    exit_code = extract_preview.main(
        [
            "--vault-dir",
            str(temp_vault),
            "--pack",
            "default-knowledge",
            "--profile",
            "tech/doc_structure",
            "--source",
            str(temp_vault / "50-Inbox" / "01-Raw" / "doc-one.md"),
        ]
    )

    payload = json.loads(capsys.readouterr().out)
    assert exit_code == 0
    assert payload["run_count"] == 1


def test_extract_preview_command_rejects_negative_limit(temp_vault):
    from ovp_pipeline.commands import extract_preview

    try:
        extract_preview.main(
            [
                "--vault-dir",
                str(temp_vault),
                "--pack",
                "default-knowledge",
                "--profile",
                "tech/doc_structure",
                "--limit",
                "-1",
            ]
        )
    except SystemExit as exc:
        assert exc.code == 2
    else:
        raise AssertionError("expected argparse failure for negative limit")


def test_extraction_dashboard_command_summarizes_profiles(temp_vault, capsys):
    from ovp_pipeline.commands import extraction_dashboard
    from ovp_pipeline.runtime import VaultLayout

    layout = VaultLayout.from_vault(temp_vault)
    _write_run(
        layout,
        source_name="doc-one.md",
        profile_name="tech/doc_structure",
        values={"section_title": "Architecture", "summary": "Overview"},
    )
    _write_run(
        layout,
        source_name="doc-two.md",
        profile_name="media/commentary_sentiment",
        values={"subject": "OVP", "stance": "positive"},
    )

    exit_code = extraction_dashboard.main(
        [
            "--vault-dir",
            str(temp_vault),
            "--pack",
            "default-knowledge",
        ]
    )

    payload = json.loads(capsys.readouterr().out)
    assert exit_code == 0
    assert payload["pack"] == "default-knowledge"
    assert payload["total_runs"] == 2
    assert payload["profiles"]["tech/doc_structure"]["run_count"] == 1
    assert payload["profiles"]["media/commentary_sentiment"]["run_count"] == 1


def test_extraction_dashboard_help_mentions_primary_pack(capsys):
    from ovp_pipeline.commands import extraction_dashboard

    try:
        extraction_dashboard.main(["--help"])
    except SystemExit as exc:
        assert exc.code == 0

    output = " ".join(capsys.readouterr().out.split())
    assert "compatibility pack" in output
    assert "research-tech" in output


def test_extract_preview_command_supports_research_tech_pack(temp_vault, capsys):
    from ovp_pipeline.commands import extract_preview
    from ovp_pipeline.runtime import VaultLayout

    layout = VaultLayout.from_vault(temp_vault)
    artifact_path = _write_run(
        layout,
        source_name="research-doc.md",
        profile_name="tech/doc_structure",
        values={"section_title": "Runtime", "summary": "Overview"},
    )
    payload = json.loads(artifact_path.read_text(encoding="utf-8"))
    payload["pack_name"] = "research-tech"
    artifact_path.unlink()
    research_artifact = layout.extraction_runs_dir / "research-tech" / "tech__doc_structure" / artifact_path.name
    research_artifact.parent.mkdir(parents=True, exist_ok=True)
    research_artifact.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")

    exit_code = extract_preview.main(
        [
            "--vault-dir",
            str(temp_vault),
            "--pack",
            "research-tech",
            "--profile",
            "tech/doc_structure",
        ]
    )

    preview = json.loads(capsys.readouterr().out)
    assert exit_code == 0
    assert preview["pack"] == "research-tech"
    assert preview["record_count"] == 1


def test_extraction_dashboard_command_supports_research_tech_pack(temp_vault, capsys):
    from ovp_pipeline.commands import extraction_dashboard
    from ovp_pipeline.runtime import VaultLayout

    layout = VaultLayout.from_vault(temp_vault)
    artifact_path = _write_run(
        layout,
        source_name="research-doc.md",
        profile_name="tech/doc_structure",
        values={"section_title": "Runtime", "summary": "Overview"},
    )
    payload = json.loads(artifact_path.read_text(encoding="utf-8"))
    payload["pack_name"] = "research-tech"
    artifact_path.unlink()
    research_artifact = layout.extraction_runs_dir / "research-tech" / "tech__doc_structure" / artifact_path.name
    research_artifact.parent.mkdir(parents=True, exist_ok=True)
    research_artifact.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")

    exit_code = extraction_dashboard.main(
        [
            "--vault-dir",
            str(temp_vault),
            "--pack",
            "research-tech",
        ]
    )

    dashboard = json.loads(capsys.readouterr().out)
    assert exit_code == 0
    assert dashboard["pack"] == "research-tech"
    assert dashboard["total_runs"] == 1
    assert dashboard["profiles"]["tech/doc_structure"]["run_count"] == 1
