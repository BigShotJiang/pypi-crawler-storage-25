from __future__ import annotations

import argparse
import json

from ..packs.loader import list_builtin_packs
from ..plugins import discover_entrypoint_packs, discover_plugin_manifests, manifest_paths_from_env


def _serialize_pack(pack: object, *, source: str) -> dict[str, object]:
    profile_names = [profile.name for profile in pack.workflow_profiles()]
    return {
        "name": pack.name,
        "role": getattr(pack, "role", "domain"),
        "compatibility_base": getattr(pack, "compatibility_base", None),
        "version": pack.version,
        "api_version": pack.api_version,
        "profiles": profile_names,
        "source": source,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="List built-in and externally discoverable domain packs."
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit structured JSON instead of a human-readable list",
    )
    args = parser.parse_args(argv)

    builtin = [_serialize_pack(pack, source="builtin") for pack in list_builtin_packs()]
    builtin_names = {item["name"] for item in builtin}

    entrypoint = [
        _serialize_pack(pack, source="entrypoint")
        for pack in discover_entrypoint_packs().values()
        if pack.name not in builtin_names
    ]
    entrypoint_names = {item["name"] for item in entrypoint}

    manifest_paths = manifest_paths_from_env()
    manifests = []
    if manifest_paths:
        for manifest in discover_plugin_manifests(manifest_paths).values():
            if manifest.name in builtin_names or manifest.name in entrypoint_names:
                continue
            manifests.append(
                {
                    "name": manifest.name,
                    "role": "external",
                    "compatibility_base": None,
                    "version": manifest.version,
                    "api_version": manifest.api_version,
                    "profiles": [],
                    "source": "manifest",
                    "manifest_path": str(manifest.manifest_path),
                }
            )

    payload = {"builtin": builtin, "external": entrypoint + manifests}
    if args.json:
        print(json.dumps(payload, ensure_ascii=False))
        return 0

    for item in builtin:
        line = f"{item['name']} [{item['role']}]"
        if item["compatibility_base"]:
            line += f" -> {item['compatibility_base']}"
        line += f" profiles={','.join(item['profiles'])}"
        print(line)
    for item in entrypoint:
        line = f"{item['name']} [{item['role']}]"
        if item["compatibility_base"]:
            line += f" -> {item['compatibility_base']}"
        line += f" profiles={','.join(item['profiles'])} source=entrypoint"
        print(line)
    for item in manifests:
        print(f"{item['name']} [external] manifest={item['manifest_path']}")
    return 0
