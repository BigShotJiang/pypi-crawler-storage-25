from __future__ import annotations

import argparse
import json
from pathlib import Path

from ..packs.loader import DEFAULT_PACK_NAME, PRIMARY_PACK_NAME, load_pack
from ..runtime import resolve_vault_dir
from ..wiki_views.runtime import build_view


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build a compiled wiki view from a pack-defined view spec.")
    parser.add_argument("--vault-dir", type=Path, default=None, help="Vault directory")
    parser.add_argument(
        "--pack",
        default=DEFAULT_PACK_NAME,
        help=f"Pack name (default compatibility pack: {DEFAULT_PACK_NAME}; primary pack: {PRIMARY_PACK_NAME})",
    )
    parser.add_argument("--view", required=True, help="Wiki view name")
    parser.add_argument("--object-id", help="Object ID for object-specific materializers")
    parser.add_argument("--cluster-id", help="Cluster ID for cluster-specific materializers")
    args = parser.parse_args(argv)

    vault_dir = resolve_vault_dir(args.vault_dir)
    pack = load_pack(args.pack)
    view = pack.wiki_view(args.view)
    if view.builder == "object_page" and not args.object_id:
        parser.error("the --object-id argument is required for object/page views")
    if view.builder == "cluster_crystal" and not args.cluster_id:
        parser.error("the --cluster-id argument is required for cluster/crystal views")
    output_path = build_view(vault_dir, view, object_id=args.object_id, cluster_id=args.cluster_id)
    print(json.dumps({"output_path": str(output_path)}, ensure_ascii=False))
    return 0
