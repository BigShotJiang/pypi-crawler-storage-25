from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from ..knowledge_index import contradiction_object_ids, rebuild_compiled_summaries, resolve_contradictions
from ..runtime import VaultLayout, resolve_vault_dir
from ..truth_api import record_review_action


def _load_contradiction_ids_from_queue(layout: VaultLayout, queue_name: str) -> tuple[list[str], dict[str, list[Path]]]:
    queue_dir = layout.review_queue_dir / queue_name
    if not queue_dir.exists():
        return [], {}

    contradiction_ids: list[str] = []
    queue_files_by_id: dict[str, list[Path]] = {}
    for artifact in sorted(queue_dir.rglob("*.json")):
        try:
            payload = json.loads(artifact.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError, ValueError) as exc:
            print(f"Skipping malformed queue artifact {artifact}: {exc}", file=sys.stderr)
            continue
        contradiction_id = payload.get("contradiction_id")
        if contradiction_id:
            resolved_id = str(contradiction_id)
            contradiction_ids.append(resolved_id)
            queue_files_by_id.setdefault(resolved_id, []).append(artifact)
    return list(dict.fromkeys(contradiction_ids)), queue_files_by_id


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Resolve contradiction records in the truth store.")
    parser.add_argument("--vault-dir", type=Path, default=None, help="Vault directory")
    parser.add_argument("--contradiction-id", action="append", help="Specific contradiction ID to resolve")
    parser.add_argument("--from-queue", help="Load contradiction IDs from a review queue directory")
    parser.add_argument(
        "--status",
        required=True,
        choices=["resolved_keep_positive", "resolved_keep_negative", "dismissed", "needs_human"],
        help="Resolution status to apply",
    )
    parser.add_argument("--note", default="", help="Optional resolution note")
    parser.add_argument("--rebuild-summaries", action="store_true", help="Rebuild compiled summaries for affected objects")
    parser.add_argument("--json", action="store_true", help="Emit JSON output")
    args = parser.parse_args(argv)

    vault_dir = resolve_vault_dir(args.vault_dir)
    layout = VaultLayout.from_vault(vault_dir)

    contradiction_ids = list(args.contradiction_id or [])
    queue_files_by_id: dict[str, list[Path]] = {}
    if args.from_queue:
        queue_ids, queue_files_by_id = _load_contradiction_ids_from_queue(layout, args.from_queue)
        contradiction_ids.extend(queue_ids)
    contradiction_ids = list(dict.fromkeys(contradiction_ids))

    payload = resolve_contradictions(vault_dir, contradiction_ids, status=args.status, note=args.note)
    affected_object_ids = contradiction_object_ids(vault_dir, payload["contradiction_ids"])
    if payload["resolved_count"] and args.rebuild_summaries:
        rebuild_payload = rebuild_compiled_summaries(vault_dir, object_ids=affected_object_ids)
        payload["rebuilt_summary_count"] = rebuild_payload["objects_rebuilt"]
        payload["rebuilt_object_ids"] = rebuild_payload["object_ids"]
    else:
        payload["rebuilt_summary_count"] = 0
        payload["rebuilt_object_ids"] = []
    if payload["resolved_count"]:
        payload["object_ids"] = affected_object_ids
        record_review_action(
            vault_dir,
            event_type="ui_contradictions_resolved",
            slug=affected_object_ids[0] if affected_object_ids else "",
            payload={
                "object_ids": affected_object_ids,
                "contradiction_ids": payload["contradiction_ids"],
                "status": args.status,
                "note": args.note,
                "rebuilt_object_ids": payload["rebuilt_object_ids"],
            },
            session_id="resolve-contradictions-cli",
        )
    else:
        payload["object_ids"] = []

    cleared_queue_files: list[str] = []
    if payload["resolved_count"] and queue_files_by_id:
        for contradiction_id in payload["contradiction_ids"]:
            for queue_file in queue_files_by_id.get(contradiction_id, []):
                if queue_file.exists():
                    queue_file.unlink()
                    cleared_queue_files.append(str(queue_file))

    payload["cleared_queue_files"] = cleared_queue_files
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(f"resolved contradictions: {payload['resolved_count']}")
        for contradiction_id in payload["contradiction_ids"]:
            print(f"- {contradiction_id}")
    return 0
