from __future__ import annotations

from .base import BaseDomainPack, WorkflowProfile


DEFAULT_PACK_NAME = "default-knowledge"
PRIMARY_PACK_NAME = "research-tech"
DEFAULT_WORKFLOW_PACK_NAME = PRIMARY_PACK_NAME
BUILTIN_PACK_LOADERS = {
    "default-knowledge": ("ovp_pipeline.packs.default_knowledge", "get_pack"),
    "research-tech": ("ovp_pipeline.packs.research_tech", "get_pack"),
}


def load_default_pack() -> BaseDomainPack:
    return load_builtin_pack(DEFAULT_PACK_NAME)


def load_primary_pack() -> BaseDomainPack:
    return load_builtin_pack(PRIMARY_PACK_NAME)


def list_builtin_packs() -> list[BaseDomainPack]:
    return [load_builtin_pack(name) for name in BUILTIN_PACK_LOADERS]


def load_builtin_pack(name: str) -> BaseDomainPack:
    if name not in BUILTIN_PACK_LOADERS:
        available = ", ".join(sorted(BUILTIN_PACK_LOADERS))
        raise ValueError(f"Unknown builtin pack '{name}'. Available builtin packs: {available}")
    module_name, factory_name = BUILTIN_PACK_LOADERS[name]
    module = __import__(module_name, fromlist=[factory_name])
    pack = getattr(module, factory_name)()
    if not isinstance(pack, BaseDomainPack):
        raise TypeError(f"builtin pack '{name}' did not return a BaseDomainPack")
    return pack


def load_pack(name: str) -> BaseDomainPack:
    if name in BUILTIN_PACK_LOADERS:
        return load_builtin_pack(name)
    from ..plugins import (
        discover_entrypoint_packs,
        discover_plugin_manifests,
        load_manifest_pack,
        manifest_paths_from_env,
    )

    entrypoint_packs = discover_entrypoint_packs()
    if name in entrypoint_packs:
        return entrypoint_packs[name]

    manifest_paths = manifest_paths_from_env()
    if manifest_paths:
        manifests = discover_plugin_manifests(manifest_paths)
        if name in manifests:
            return load_manifest_pack(manifests[name])
    raise ValueError(f"Unknown pack: {name}")


def resolve_workflow_profile(
    *,
    pack_name: str | None = None,
    profile_name: str | None = None,
    default_profile: str,
    require_autopilot: bool = False,
    runtime_adapter: str = "pipeline_step",
) -> tuple[BaseDomainPack, WorkflowProfile]:
    """Resolve a pack/profile pair with stable defaults."""

    resolved_pack_name = pack_name or DEFAULT_WORKFLOW_PACK_NAME
    resolved_profile_name = profile_name or default_profile

    pack = load_pack(resolved_pack_name)
    profile = pack.profile(resolved_profile_name)

    if require_autopilot and not profile.supports_autopilot:
        raise ValueError(
            f"Workflow profile '{resolved_profile_name}' for pack '{resolved_pack_name}' "
            "does not support autopilot"
        )

    from ..execution_contract_registry import resolve_stage_execution_contract

    for stage in profile.stages:
        try:
            resolve_stage_execution_contract(
                pack_name=pack,
                stage=stage,
                runtime_adapter=runtime_adapter,
            )
        except ValueError as exc:
            raise ValueError(
                f"Workflow profile '{profile.name}' for pack '{pack.name}' is missing "
                f"execution contract for stage '{stage}' "
                f"(runtime_adapter={runtime_adapter})"
            ) from exc

    return pack, profile
