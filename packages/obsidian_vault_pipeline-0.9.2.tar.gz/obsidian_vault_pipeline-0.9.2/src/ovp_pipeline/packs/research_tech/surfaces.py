from __future__ import annotations

import sqlite3
from collections import Counter
from pathlib import Path
from typing import Any
from urllib.parse import quote

from ... import truth_api as core
from ...runtime import resolve_vault_dir


def _scoped_path(path: str, *, pack_name: str | None = None) -> str:
    normalized_pack = str(pack_name or "").strip()
    if not normalized_pack:
        return path
    separator = "&" if "?" in path else "?"
    return f"{path}{separator}pack={quote(normalized_pack, safe='')}"


def _traceability_object_ids(traceability: dict[str, Any]) -> list[str]:
    object_ids = [
        str(entry.get("object_id") or "")
        for entry in traceability.get("objects", [])
        if str(entry.get("object_id") or "").strip()
    ]
    if object_ids:
        return list(dict.fromkeys(object_ids))
    brain_lookup = traceability.get("brain_first_lookup") or {}
    return list(
        dict.fromkeys(
            str(entry.get("object_id") or "")
            for entry in brain_lookup.get("existing_objects", [])
            if str(entry.get("object_id") or "").strip()
        )
    )


def _traceability_contract_payload(traceability: dict[str, Any]) -> dict[str, Any]:
    return {
        "brain_first_lookup": traceability.get("brain_first_lookup") or {},
        "backlink_expectation": traceability.get("backlink_expectation") or {},
    }


def _briefing_evidence_count(item: dict[str, Any]) -> int:
    evidence: set[str] = set()
    for key in ("source_paths", "note_paths", "object_ids"):
        value = item.get(key)
        if isinstance(value, list):
            evidence.update(str(entry) for entry in value if str(entry or "").strip())
    for key in ("signal_id", "path"):
        value = str(item.get(key) or "").strip()
        if value:
            evidence.add(value)
    return len(evidence)


def _briefing_actionability(item: dict[str, Any]) -> str:
    recommended_action = item.get("recommended_action")
    if not isinstance(recommended_action, dict):
        return "review"
    queue_status = str(recommended_action.get("queue_status") or "").strip().lower()
    if queue_status in {"queued", "running", "pending", "scheduled", "in_progress"}:
        return "queued"
    if bool(recommended_action.get("executable")):
        return "executable"
    return "review"


def _annotate_briefing_value(
    item: dict[str, Any],
    *,
    value_kind: str,
    value_reason: str,
) -> dict[str, Any]:
    item["value_kind"] = value_kind
    item["value_reason"] = value_reason
    item["evidence_count"] = _briefing_evidence_count(item)
    item["actionability"] = _briefing_actionability(item)
    return item


def _first_useful_sign_check(first_useful_sign: dict[str, Any] | None) -> dict[str, Any]:
    if not first_useful_sign:
        return {
            "status": "empty",
            "kind": "",
            "reason": "No background insight or priority item has enough current evidence to surface.",
            "evidence_count": 0,
            "actionability": "review",
        }
    raw_evidence = first_useful_sign.get("evidence_count")
    try:
        evidence_count = int(raw_evidence)
    except (TypeError, ValueError):
        evidence_count = _briefing_evidence_count(first_useful_sign)
    raw_actionability = first_useful_sign.get("actionability")
    actionability = (
        str(raw_actionability).strip()
        if str(raw_actionability or "").strip()
        else _briefing_actionability(first_useful_sign)
    )
    kind = str(first_useful_sign.get("kind") or "")
    title = str(first_useful_sign.get("title") or "")
    return {
        "status": "useful",
        "kind": kind,
        "reason": (
            f"{title or kind} surfaced with {evidence_count} evidence reference(s) "
            f"and {actionability} follow-up."
        ),
        "evidence_count": evidence_count,
        "actionability": actionability,
    }


def _background_policy_summary(
    *,
    pack_name: str,
    recent_signals: list[dict[str, Any]],
    action_by_signal_id: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    governed: dict[str, dict[str, Any]] = {}
    for governance_spec in core.list_effective_governance_specs(pack_name=pack_name):
        for rule in governance_spec.signal_rules:
            signal_type = str(rule.signal_type or "").strip()
            if not signal_type:
                continue
            governed[signal_type] = {
                "signal_type": signal_type,
                "resolver_rule": str(rule.resolver_rule or ""),
                "auto_queue": bool(rule.auto_queue),
                "provider_pack": str(governance_spec.pack or ""),
                "provider_name": str(governance_spec.name or ""),
            }

    signal_counts = Counter(str(item.get("signal_type") or "") for item in recent_signals)
    signals_by_type: dict[str, list[dict[str, Any]]] = {}
    for item in recent_signals:
        signals_by_type.setdefault(str(item.get("signal_type") or ""), []).append(item)
    signal_type_decisions: dict[str, dict[str, Any]] = {}
    skipped_reasons: Counter[str] = Counter()
    for signal_type, rule in sorted(governed.items()):
        matching = signals_by_type.get(signal_type, [])
        queued_count = sum(
            1
            for item in matching
            if str(item.get("signal_id") or "") in action_by_signal_id
        )
        skipped_count = 0
        type_reasons: Counter[str] = Counter()
        if rule["auto_queue"]:
            for item in matching:
                recommended_action = item.get("recommended_action")
                if not isinstance(recommended_action, dict) or not recommended_action.get("kind"):
                    skipped_count += 1
                    type_reasons["missing_recommended_action"] += 1
                elif str(item.get("signal_id") or "") not in action_by_signal_id:
                    skipped_count += 1
                    type_reasons["not_queued"] += 1
        else:
            skipped_count = 0

        if rule["auto_queue"]:
            skipped_reasons.update(type_reasons)
        signal_type_decisions[signal_type] = {
            **rule,
            "decision": "auto_queue_enabled" if rule["auto_queue"] else "review_only",
            "active_signal_count": int(signal_counts.get(signal_type, 0)),
            "queued_action_count": queued_count,
            "skipped_count": skipped_count,
            "skipped_reasons": dict(type_reasons),
        }

    auto_queue_types = sorted(
        signal_type for signal_type, rule in governed.items() if rule["auto_queue"]
    )
    review_only_types = sorted(
        signal_type for signal_type, rule in governed.items() if not rule["auto_queue"]
    )
    return {
        "governed_signal_types": sorted(governed),
        "auto_queue_enabled_signal_types": auto_queue_types,
        "review_only_signal_types": review_only_types,
        "active_auto_queue_signal_count": sum(
            int(signal_counts.get(signal_type, 0)) for signal_type in auto_queue_types
        ),
        "active_review_only_signal_count": sum(
            int(signal_counts.get(signal_type, 0)) for signal_type in review_only_types
        ),
        "skipped_signal_count": sum(skipped_reasons.values()),
        "skipped_reasons": dict(skipped_reasons),
        "signal_type_decisions": signal_type_decisions,
    }


def _merge_briefing_action_metadata(
    item: dict[str, Any],
    action: dict[str, Any],
) -> None:
    recommended_action = item.get("recommended_action")
    if isinstance(recommended_action, dict):
        if action:
            recommended_action["queue_status"] = str(action.get("status") or "")
            recommended_action["action_id"] = str(action.get("action_id") or "")
            recommended_action["precondition_status"] = str(
                action.get("precondition_status") or ""
            )
            recommended_action["blocked_reason"] = str(action.get("blocked_reason") or "")
            recommended_action["obsolete_reason"] = str(action.get("obsolete_reason") or "")
        recommended_action.setdefault("queue_status", "")
        recommended_action.setdefault("action_id", "")
        recommended_action.setdefault("precondition_status", "")
        recommended_action.setdefault("blocked_reason", "")
        recommended_action.setdefault("obsolete_reason", "")
    if action:
        item["action_lifecycle"] = {
            **(item.get("action_lifecycle") if isinstance(item.get("action_lifecycle"), dict) else {}),
            "queue_status": str(action.get("status") or ""),
            "action_id": str(action.get("action_id") or ""),
            "precondition_status": str(action.get("precondition_status") or ""),
            "blocked_reason": str(action.get("blocked_reason") or ""),
            "obsolete_reason": str(action.get("obsolete_reason") or ""),
        }
    else:
        item.setdefault("action_lifecycle", {})
    item["evidence_count"] = _briefing_evidence_count(item)
    item["actionability"] = _briefing_actionability(item)


def list_production_chains(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    query: str | None = None,
    limit: int = 100,
) -> list[dict[str, Any]]:
    limit, _ = core._validate_page_args(limit=limit, offset=0)
    db_path = core._db_path(vault_dir)
    resolved_vault = resolve_vault_dir(vault_dir)
    normalized_query = (query or "").strip().lower()
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute(
            """
            SELECT slug, title, note_type, path
            FROM pages_index
            WHERE note_type = 'deep_dive'
            ORDER BY note_type, slug
            """
        ).fetchall()

    candidates: list[dict[str, str]] = []
    seen_paths: set[str] = set()
    for slug, title, note_type, path in rows:
        relative_path = core._vault_relative_path(resolved_vault, path)
        seen_paths.add(relative_path)
        candidates.append(
            {
                "slug": str(slug),
                "title": str(title),
                "note_type": str(note_type),
                "path": relative_path,
                "stage_label": "deep_dive",
            }
        )

    processed_root = resolved_vault / "50-Inbox" / "03-Processed"
    if processed_root.exists():
        for candidate in sorted(processed_root.rglob("*.md")):
            relative_path = str(candidate.resolve().relative_to(resolved_vault.resolve()))
            if relative_path in seen_paths:
                continue
            frontmatter = core._parse_frontmatter(candidate.read_text(encoding="utf-8"))
            candidates.append(
                {
                    "slug": candidate.stem,
                    "title": str(frontmatter.get("title") or candidate.stem).strip(),
                    "note_type": "note",
                    "path": relative_path,
                    "stage_label": "source_note",
                }
            )

    items: list[dict[str, Any]] = []
    for candidate in candidates:
        relative_path = candidate["path"]
        chain = core.get_note_traceability(vault_dir, note_path=relative_path, pack_name=pack_name)
        if normalized_query:
            haystacks = [
                str(candidate["title"]).lower(),
                str(candidate["slug"]).lower(),
                relative_path.lower(),
                *(item["title"].lower() for item in chain["deep_dives"]),
                *(item["title"].lower() for item in chain["objects"]),
                *(item["title"].lower() for item in chain["atlas_pages"]),
                *(item["title"].lower() for item in chain["source_notes"]),
            ]
            if not any(normalized_query in haystack for haystack in haystacks):
                continue
        items.append(
            {
                "slug": candidate["slug"],
                "title": candidate["title"],
                "note_type": candidate["note_type"],
                "path": relative_path,
                "stage_label": candidate["stage_label"],
                "traceability": chain,
            }
        )
        if len(items) >= limit:
            break
    return items


def build_signal_entries(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
) -> list[dict[str, Any]]:
    resolved_vault = resolve_vault_dir(vault_dir)
    normalized_pack = str(pack_name or core.DEFAULT_WORKFLOW_PACK_NAME)
    timestamp = core._utc_now_text()
    signals: list[dict[str, Any]] = []

    for item in core.list_contradictions(
        resolved_vault,
        pack_name=normalized_pack,
        status="open",
        limit=core.MAX_PAGE_SIZE,
    ):
        object_ids = list(
            dict.fromkeys(
                claim_id.split("::", 1)[0]
                for claim_id in (item["positive_claim_ids"] + item["negative_claim_ids"])
            )
        )
        signals.append(
            {
                "signal_id": core._signal_id("contradiction_open", item["contradiction_id"]),
                "signal_type": "contradiction_open",
                "detected_at": timestamp,
                "status": "active",
                "title": item["subject_key"],
                "detail": (
                    f"{item['scope_summary']['object_count']} objects, "
                    f"{len(item['ranked_evidence'])} ranked evidence rows"
                ),
                "explanation": core.SIGNAL_TYPE_EXPLANATIONS["contradiction_open"],
                "source_path": _scoped_path("/contradictions", pack_name=normalized_pack),
                "source_label": "Contradictions",
                "object_ids": object_ids,
                "note_paths": [],
                "downstream_effects": [
                    {
                        "label": "Review contradiction",
                        "path": _scoped_path(
                            f"/contradictions?q={quote(item['subject_key'], safe='')}",
                            pack_name=normalized_pack,
                        ),
                    },
                    *[
                        {
                            "label": f"Object: {claim['object_title']}",
                            "path": _scoped_path(
                                f"/object?id={claim['object_id']}",
                                pack_name=normalized_pack,
                            ),
                        }
                        for claim in item["positive_claims"][:1] + item["negative_claims"][:1]
                    ],
                ],
                "recommended_action": core._recommended_action(
                    kind="review_contradiction",
                    label="Review contradiction",
                    path=_scoped_path(
                        f"/contradictions?q={quote(item['subject_key'], safe='')}",
                        pack_name=normalized_pack,
                    ),
                    executable=True,
                ),
                "payload": {
                    "contradiction_id": item["contradiction_id"],
                    "scope_summary": item["scope_summary"],
                    "status_bucket": item["status_bucket"],
                },
            }
        )

    for item in core.list_stale_summaries(
        resolved_vault,
        pack_name=normalized_pack,
        limit=core.MAX_PAGE_SIZE,
    ):
        signals.append(
            {
                "signal_id": core._signal_id("stale_summary", item["object_id"]),
                "signal_type": "stale_summary",
                "detected_at": timestamp,
                "status": "active",
                "title": item["title"],
                "detail": ", ".join(item["reason_texts"]),
                "explanation": core.SIGNAL_TYPE_EXPLANATIONS["stale_summary"],
                "source_path": _scoped_path(
                    f"/summaries?q={quote(item['object_id'], safe='')}",
                    pack_name=normalized_pack,
                ),
                "source_label": "Stale Summaries",
                "object_ids": [item["object_id"]],
                "note_paths": [],
                "downstream_effects": [
                    {"label": "Open object", "path": item["object_path"]},
                    {
                        "label": "Review stale summary",
                        "path": _scoped_path(
                            f"/summaries?q={quote(item['object_id'], safe='')}",
                            pack_name=normalized_pack,
                        ),
                    },
                ],
                "recommended_action": core._recommended_action(
                    kind="rebuild_summary",
                    label="Rebuild summary",
                    path=_scoped_path(
                        f"/summaries?q={quote(item['object_id'], safe='')}",
                        pack_name=normalized_pack,
                    ),
                    executable=True,
                ),
                "payload": {
                    "reason_codes": item["reason_codes"],
                    "latest_event_date": item["latest_event_date"],
                },
            }
        )

    production_chains = core.list_production_chains(
        resolved_vault,
        pack_name=normalized_pack,
        limit=core.MAX_PAGE_SIZE,
    )
    for item in core._production_gap_items_from_chains(production_chains, limit=core.MAX_PAGE_SIZE):
        object_ids = _traceability_object_ids(item["traceability"])
        signals.append(
            {
                "signal_id": item["signal_id"],
                "signal_type": "production_gap",
                "detected_at": timestamp,
                "status": "active",
                "title": item["title"],
                "detail": item["detail"],
                "explanation": core.SIGNAL_TYPE_EXPLANATIONS["production_gap"],
                "source_path": f"/note?path={quote(item['note_path'], safe='')}",
                "source_label": "Production",
                "object_ids": object_ids,
                "note_paths": [item["note_path"]],
                "downstream_effects": [
                    {
                        "label": "Open note",
                        "path": f"/note?path={quote(item['note_path'], safe='')}",
                    },
                    {
                        "label": "Inspect production chain",
                        "path": _scoped_path(
                            f"/production?q={quote(item['title'], safe='')}",
                            pack_name=normalized_pack,
                        ),
                    },
                ],
                "recommended_action": core._recommended_action(
                    kind="inspect_production_gap",
                    label="Inspect production gap",
                    path=_scoped_path(
                        f"/production?q={quote(item['title'], safe='')}",
                        pack_name=normalized_pack,
                    ),
                    executable=False,
                ),
                "payload": {
                    "stage_label": item["stage_label"],
                    "missing": item["missing"],
                    "traceability_counts": item["traceability"]["counts"],
                    **_traceability_contract_payload(item["traceability"]),
                },
            }
        )

    for item in production_chains:
        traceability = item["traceability"]
        if item["stage_label"] == "source_note" and not traceability["deep_dives"]:
            signals.append(
                {
                    "signal_id": core._signal_id("source_needs_deep_dive", item["path"]),
                    "signal_type": "source_needs_deep_dive",
                    "detected_at": timestamp,
                    "status": "active",
                    "title": item["title"],
                    "detail": "Processed source note has no derived deep dive yet.",
                    "explanation": core.SIGNAL_TYPE_EXPLANATIONS["source_needs_deep_dive"],
                    "source_path": f"/note?path={quote(item['path'], safe='')}",
                    "source_label": "Production",
                    "object_ids": [],
                    "note_paths": [item["path"]],
                    "downstream_effects": [
                        {
                            "label": "Open source note",
                            "path": f"/note?path={quote(item['path'], safe='')}",
                        },
                        {
                            "label": "Inspect production chain",
                            "path": _scoped_path(
                                f"/production?q={quote(item['title'], safe='')}",
                                pack_name=normalized_pack,
                            ),
                        },
                    ],
                    "recommended_action": core._recommended_action(
                        kind="deep_dive_workflow",
                        label="Create deep dive",
                        path=f"/note?path={quote(item['path'], safe='')}",
                        executable=False,
                    ),
                    "payload": {
                        "stage_label": item["stage_label"],
                        "traceability_counts": traceability["counts"],
                        **_traceability_contract_payload(traceability),
                    },
                }
            )
        if item["stage_label"] == "deep_dive" and not traceability["objects"]:
            object_ids = _traceability_object_ids(traceability)
            object_effects = [
                {
                    "label": f"Existing object: {entry['title']}",
                    "path": _scoped_path(
                        f"/object?id={quote(str(entry['object_id']), safe='')}",
                        pack_name=normalized_pack,
                    ),
                }
                for entry in (traceability.get("brain_first_lookup") or {}).get(
                    "existing_objects", []
                )[:2]
                if entry.get("object_id")
            ]
            signals.append(
                {
                    "signal_id": core._signal_id("deep_dive_needs_objects", item["path"]),
                    "signal_type": "deep_dive_needs_objects",
                    "detected_at": timestamp,
                    "status": "active",
                    "title": item["title"],
                    "detail": "Deep dive has not produced any evergreen objects yet.",
                    "explanation": core.SIGNAL_TYPE_EXPLANATIONS["deep_dive_needs_objects"],
                    "source_path": f"/note?path={quote(item['path'], safe='')}",
                    "source_label": "Production",
                    "object_ids": object_ids,
                    "note_paths": [item["path"]],
                    "downstream_effects": [
                        {
                            "label": "Open deep dive",
                            "path": f"/note?path={quote(item['path'], safe='')}",
                        },
                        *object_effects,
                        {
                            "label": "Inspect production chain",
                            "path": _scoped_path(
                                f"/production?q={quote(item['title'], safe='')}",
                                pack_name=normalized_pack,
                            ),
                        },
                    ],
                    "recommended_action": core._recommended_action(
                        kind="object_extraction_workflow",
                        label="Extract evergreen objects",
                        path=f"/note?path={quote(item['path'], safe='')}",
                        executable=False,
                    ),
                    "payload": {
                        "stage_label": item["stage_label"],
                        "traceability_counts": traceability["counts"],
                        **_traceability_contract_payload(traceability),
                    },
                }
            )

    for item in core.list_review_actions(resolved_vault, limit=core.MAX_PAGE_SIZE):
        if item["event_type"] == "ui_contradictions_resolved":
            status = item["status"] or "reviewed"
            signals.append(
                {
                    "signal_id": core._signal_id(
                        "contradiction_reviewed",
                        f"{item['timestamp']}::{','.join(item['contradiction_ids'])}",
                    ),
                    "signal_type": "contradiction_reviewed",
                    "detected_at": item["timestamp"],
                    "status": "active",
                    "title": "Contradiction reviewed",
                    "detail": f"{len(item['contradiction_ids'])} contradictions moved to {status}.",
                    "explanation": core.SIGNAL_TYPE_EXPLANATIONS["contradiction_reviewed"],
                    "source_path": "/contradictions?status=resolved",
                    "source_label": "Review Actions",
                    "object_ids": item["object_ids"],
                    "note_paths": [],
                    "downstream_effects": [
                        {
                            "label": "Open resolved contradictions",
                            "path": "/contradictions?status=resolved",
                        },
                        *[
                            {"label": f"Object: {object_id}", "path": f"/object?id={object_id}"}
                            for object_id in item["object_ids"][:2]
                        ],
                    ],
                    "recommended_action": core._recommended_action(
                        kind="review_resolution",
                        label="Inspect resolved contradictions",
                        path="/contradictions?status=resolved",
                        executable=False,
                    ),
                    "payload": {
                        "event_type": item["event_type"],
                        "contradiction_ids": item["contradiction_ids"],
                        "status": status,
                        "rebuilt_object_ids": item["rebuilt_object_ids"],
                    },
                }
            )
        elif item["event_type"] == "ui_summaries_rebuilt":
            rebuilt_count = item["objects_rebuilt"] or len(item["rebuilt_object_ids"])
            signals.append(
                {
                    "signal_id": core._signal_id(
                        "summary_rebuilt",
                        f"{item['timestamp']}::{','.join(item['rebuilt_object_ids'])}",
                    ),
                    "signal_type": "summary_rebuilt",
                    "detected_at": item["timestamp"],
                    "status": "active",
                    "title": "Summary rebuilt",
                    "detail": f"{rebuilt_count} summaries rebuilt.",
                    "explanation": core.SIGNAL_TYPE_EXPLANATIONS["summary_rebuilt"],
                    "source_path": "/summaries",
                    "source_label": "Review Actions",
                    "object_ids": item["object_ids"],
                    "note_paths": [],
                    "downstream_effects": [
                        {"label": "Open stale summaries", "path": "/summaries"},
                        *[
                            {"label": f"Object: {object_id}", "path": f"/object?id={object_id}"}
                            for object_id in item["rebuilt_object_ids"][:2]
                        ],
                    ],
                    "recommended_action": core._recommended_action(
                        kind="review_rebuilt_summary",
                        label="Inspect rebuilt summaries",
                        path="/summaries",
                        executable=False,
                    ),
                    "payload": {
                        "event_type": item["event_type"],
                        "objects_rebuilt": rebuilt_count,
                        "rebuilt_object_ids": item["rebuilt_object_ids"],
                    },
                }
            )

    signals.sort(key=lambda item: (item["signal_type"], item["title"].lower(), item["signal_id"]))
    return signals


def build_briefing_snapshot(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    limit: int = 8,
) -> dict[str, Any]:
    limit, _ = core._validate_page_args(limit=limit, offset=0)
    resolved_vault = resolve_vault_dir(vault_dir)
    normalized_pack = str(pack_name or core.DEFAULT_WORKFLOW_PACK_NAME)
    recent_signals = core._list_signals_from_ledger(
        resolved_vault,
        ledger_path=core._signal_ledger_path(
            resolved_vault,
            pack_name=normalized_pack,
        ),
        limit=limit,
    )
    unresolved_signal_types = {
        "contradiction_open",
        "stale_summary",
        "production_gap",
        "source_needs_deep_dive",
        "deep_dive_needs_objects",
    }
    unresolved_issues = [
        item for item in recent_signals if item["signal_type"] in unresolved_signal_types
    ]
    unresolved_issues.sort(
        key=lambda item: (
            core._briefing_priority_score(item),
            str(item.get("title") or "").lower(),
            str(item.get("signal_id") or ""),
        ),
        reverse=True,
    )
    unresolved_issues = unresolved_issues[:limit]
    changed_signals = [
        item
        for item in recent_signals
        if item["signal_type"] in {"contradiction_reviewed", "summary_rebuilt"}
    ]
    changed_object_ids = list(
        dict.fromkeys(
            object_id
            for item in changed_signals
            for object_id in item.get("object_ids", [])
            if object_id
        )
    )
    topic_counts: Counter[str] = Counter()
    for item in recent_signals:
        for object_id in item.get("object_ids", []):
            topic_counts[object_id] += 1
    active_topic_ids = [object_id for object_id, _ in topic_counts.most_common(limit)]

    object_rows = core._batch_object_rows(
        resolved_vault,
        [*changed_object_ids, *active_topic_ids],
        pack_name=normalized_pack,
    )
    changed_objects = [
        {
            "object_id": object_id,
            "title": object_rows.get(object_id, {}).get("title") or object_id,
            "path": _scoped_path(f"/object?id={object_id}", pack_name=normalized_pack),
        }
        for object_id in changed_object_ids[:limit]
    ]
    active_topics = [
        {
            "object_id": object_id,
            "title": object_rows.get(object_id, {}).get("title") or object_id,
            "signal_count": count,
            "path": _scoped_path(f"/topic?id={object_id}", pack_name=normalized_pack),
        }
        for object_id, count in topic_counts.most_common(limit)
    ]
    evolution_candidates = core.list_evolution_candidates(
        vault_dir,
        pack_name=normalized_pack,
        limit=min(core.MAX_PAGE_SIZE, limit * 3),
    )
    evolution_object_ids = list(
        dict.fromkeys(
            object_id
            for item in evolution_candidates
            for object_id in item.get("object_ids", [])
            if object_id
        )
    )
    evolution_rows = core._batch_object_rows(
        vault_dir, evolution_object_ids, pack_name=normalized_pack
    )
    merged_insights: dict[tuple[str, str, str], dict[str, Any]] = {}
    for item in evolution_candidates:
        primary_object_id = next(
            (object_id for object_id in item.get("object_ids", []) if object_id), ""
        )
        primary_title = (
            evolution_rows.get(primary_object_id, {}).get("title")
            or object_rows.get(primary_object_id, {}).get("title")
            or str(item.get("subject_id") or primary_object_id)
        )
        path = _scoped_path(
            "/evolution?link_type="
            + quote(str(item["link_type"]), safe="")
            + "&q="
            + quote(str(primary_title), safe=""),
            pack_name=normalized_pack,
        )
        insight = {
            "kind": f"evolution_{item['link_type']}",
            "link_type": item["link_type"],
            "title": str(primary_title),
            "detail": core.EVOLUTION_LINK_EXPLANATIONS.get(
                item["link_type"], "Knowledge evolution was detected."
            ),
            "path": path,
            "source_paths": [path for path in item.get("source_paths", []) if path][:3],
            "object_ids": list(item.get("object_ids", [])),
            "recommended_action": core._recommended_action(
                kind="review_evolution",
                label="Review evolution",
                path=path,
                executable=True,
            ),
        }
        _annotate_briefing_value(
            insight,
            value_kind="synthesis",
            value_reason="Evolution candidates connect current objects to source-backed change signals.",
        )
        key = (str(insight["kind"]), str(insight["title"]), str(insight["path"]))
        existing = merged_insights.get(key)
        if existing is None:
            merged_insights[key] = insight
        else:
            existing["source_paths"] = list(
                dict.fromkeys([*existing.get("source_paths", []), *insight.get("source_paths", [])])
            )[:3]
            existing["object_ids"] = list(
                dict.fromkeys([*existing.get("object_ids", []), *insight.get("object_ids", [])])
            )
            existing["evidence_count"] = _briefing_evidence_count(existing)
            existing["actionability"] = _briefing_actionability(existing)
    insights = list(merged_insights.values())
    insights.sort(
        key=lambda item: (
            core._briefing_evolution_score(item),
            str(item.get("title") or "").lower(),
            str(item.get("path") or ""),
        ),
        reverse=True,
    )
    insights = insights[:limit]

    action_items = core.list_action_queue(
        vault_dir, pack_name=normalized_pack, limit=core.MAX_PAGE_SIZE
    )
    action_by_signal_id = {
        str(action.get("source_signal_id") or ""): action
        for action in action_items
        if str(action.get("source_signal_id") or "")
    }

    priority_items: list[dict[str, Any]] = []
    for item in unresolved_issues:
        signal_id = str(item["signal_id"])
        action = action_by_signal_id.get(signal_id, {})
        recommended_action = item.get("recommended_action")
        if isinstance(recommended_action, dict) and action:
            recommended_action = {
                **recommended_action,
                "queue_status": str(action.get("status") or ""),
                "action_id": str(action.get("action_id") or ""),
                "precondition_status": str(action.get("precondition_status") or ""),
                "blocked_reason": str(action.get("blocked_reason") or ""),
                "obsolete_reason": str(action.get("obsolete_reason") or ""),
            }
        priority_item = {
            "signal_id": signal_id,
            "kind": item["signal_type"],
            "title": item["title"],
            "detail": item["detail"],
            "path": item["source_path"],
            "source_paths": list(item.get("note_paths", [])),
            "object_ids": list(item.get("object_ids", [])),
            "recommended_action": recommended_action,
            "action_lifecycle": item.get("action_lifecycle") or {},
        }
        _annotate_briefing_value(
            priority_item,
            value_kind="actionable_priority",
            value_reason=(
                "Active signals with resolver metadata indicate maintenance work the operator "
                "does not need to rediscover manually."
            ),
        )
        priority_items.append(priority_item)
        if len(priority_items) >= limit:
            break
    seen_priority_keys = {(item["kind"], item["title"], item["path"]) for item in priority_items}
    for item in insights:
        key = (item["kind"], item["title"], item["path"])
        if key in seen_priority_keys:
            continue
        priority_items.append(item)
        seen_priority_keys.add(key)
        if len(priority_items) >= limit:
            break
    for item in priority_items:
        signal_id = str(item.get("signal_id") or "")
        action = action_by_signal_id.get(signal_id, {})
        _merge_briefing_action_metadata(item, action)
    for item in insights:
        _merge_briefing_action_metadata(item, {})
    first_useful_sign = insights[0] if insights else (priority_items[0] if priority_items else None)
    first_useful_sign_check = _first_useful_sign_check(first_useful_sign)
    background_policy = _background_policy_summary(
        pack_name=normalized_pack,
        recent_signals=recent_signals,
        action_by_signal_id=action_by_signal_id,
    )
    queue_summary = {
        "queued_count": sum(1 for item in action_items if item.get("status") == "queued"),
        "safe_queued_count": sum(
            1
            for item in action_items
            if item.get("status") == "queued" and bool(item.get("safe_to_run"))
        ),
        "running_count": sum(1 for item in action_items if item.get("status") == "running"),
        "failed_count": sum(1 for item in action_items if item.get("status") == "failed"),
        "failure_buckets": dict(
            Counter(
                str(item.get("failure_bucket") or "")
                for item in action_items
                if item.get("status") == "failed" and str(item.get("failure_bucket") or "")
            )
        ),
    }

    return {
        "generated_at": core._utc_now_text(),
        "recent_signal_count": len(recent_signals),
        "unresolved_issue_count": len(unresolved_issues),
        "changed_object_count": len(changed_objects),
        "active_topic_count": len(active_topics),
        "recent_signals": recent_signals,
        "unresolved_issues": unresolved_issues,
        "changed_objects": changed_objects,
        "active_topics": active_topics,
        "insight_count": len(insights),
        "priority_item_count": len(priority_items),
        "insights": insights,
        "priority_items": priority_items,
        "first_useful_sign": first_useful_sign,
        "first_useful_sign_check": first_useful_sign_check,
        "background_policy": background_policy,
        "queue_summary": queue_summary,
    }
