from __future__ import annotations

import json
import sqlite3
from collections import Counter
from pathlib import Path
from typing import Any
from urllib.parse import quote

from ..assembly_recipe_registry import describe_assembly_recipe_contract
from ..governance_registry import describe_governance_contract
from ..observation_surface_registry import describe_observation_surface_contract
from ..pack_resolution import iter_compatible_packs
from ..packs.loader import PRIMARY_PACK_NAME
from ..reuse_emitter import collect_object_ids, emit_reuse_events_for_object_ids
from ..runtime import VaultLayout, resolve_vault_dir
from ..truth_store import CONTRADICTION_HEURISTIC_NOTE
from ..truth_api import (
    CONTRADICTION_STATUS_EXPLANATIONS,
    MAX_PAGE_SIZE,
    SIGNAL_TYPE_EXPLANATIONS,
    _batch_object_rows,
    count_objects,
    get_briefing_snapshot,
    get_graph_cluster_detail,
    get_object_detail,
    get_object_traceability,
    get_note_inbound_capture_summary,
    get_note_provenance,
    get_note_traceability,
    get_object_provenance_map,
    get_review_context,
    get_runtime_status,
    get_topic_neighborhood,
    list_candidate_concepts,
    list_evolution_candidates,
    list_evolution_links,
    list_review_actions,
    list_atlas_memberships,
    list_action_queue,
    list_contradictions,
    list_deep_dive_derivations,
    list_graph_clusters,
    list_objects,
    list_production_gaps,
    list_production_chains,
    list_signals,
    list_stale_summaries,
    list_timeline_events,
    search_vault_surface,
)

DEFAULT_EVENT_DOSSIER_LIMIT = 50
DEFAULT_TRACEABILITY_BROWSER_LIMIT = 50


def _scoped_path(path: str, *, pack_name: str | None = None) -> str:
    if not pack_name:
        return path
    separator = "&" if "?" in path else "?"
    return f"{path}{separator}pack={quote(pack_name, safe='')}"


def _emit_briefing_reuse(
    vault_dir: Path | str,
    payload: dict[str, Any],
    *,
    pack: str,
    consumer_ref: str,
) -> None:
    """Emit one ``briefing``-surface reuse event per canonical object in payload.

    Reuse-event emission is best-effort instrumentation — a JSONL append
    failure must never block the view-builder from returning a payload.
    """
    if not pack:
        return
    try:
        object_ids = collect_object_ids(payload)
        if not object_ids:
            return
        emit_reuse_events_for_object_ids(
            vault_dir,
            pack=pack,
            object_ids=object_ids,
            surface="briefing",
            consumer_ref=consumer_ref,
        )
    except Exception:  # noqa: BLE001 — best-effort instrumentation
        return


def _supports_research_shell(pack_name: str | None = None) -> bool:
    try:
        return any(pack.name == PRIMARY_PACK_NAME for pack in iter_compatible_packs(pack_name))
    except ValueError:
        return False


def _assembly_contract(recipe_name: str, *, pack_name: str | None = None) -> dict[str, str]:
    return describe_assembly_recipe_contract(pack_name=pack_name, recipe_name=recipe_name)


def _compiled_section(
    section_id: str,
    label: str,
    *,
    summary: str,
    items: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    normalized_items = list(items or [])
    return {
        "id": section_id,
        "label": label,
        "anchor": section_id.replace("_", "-"),
        "summary": summary,
        "item_count": len(normalized_items),
        "items": normalized_items,
    }


def _workflow_group(
    group_id: str,
    title: str,
    summary: str,
    items: list[dict[str, str]],
) -> dict[str, Any]:
    return {
        "id": group_id,
        "title": title,
        "summary": summary,
        "items": items,
    }


def _briefing_value_evidence_count(item: dict[str, Any]) -> int:
    evidence: set[str] = set()
    for key in ("source_paths", "note_paths", "object_ids"):
        value = item.get(key)
        if isinstance(value, list):
            evidence.update(str(entry) for entry in value if str(entry or "").strip())
    for key in ("signal_id", "path"):
        value = str(item.get(key) or "").strip()
        if value:
            evidence.add(value)
    return len(evidence)


def _briefing_value_actionability(item: dict[str, Any]) -> str:
    recommended_action = item.get("recommended_action")
    if not isinstance(recommended_action, dict):
        return "review"
    queue_status = str(recommended_action.get("queue_status") or "").strip().lower()
    if queue_status in {"queued", "running", "pending", "scheduled", "in_progress"}:
        return "queued"
    if bool(recommended_action.get("executable")):
        return "executable"
    return "review"


def _briefing_value_check(first_useful_sign: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(first_useful_sign, dict):
        return {
            "status": "empty",
            "kind": "",
            "reason": "No background insight or priority item has enough current evidence to surface.",
            "evidence_count": 0,
            "actionability": "review",
        }
    raw_evidence = first_useful_sign.get("evidence_count")
    try:
        evidence_count = int(raw_evidence)
    except (TypeError, ValueError):
        evidence_count = _briefing_value_evidence_count(first_useful_sign)
    raw_actionability = first_useful_sign.get("actionability")
    actionability = (
        str(raw_actionability).strip()
        if str(raw_actionability or "").strip()
        else _briefing_value_actionability(first_useful_sign)
    )
    kind = str(first_useful_sign.get("kind") or "")
    title = str(first_useful_sign.get("title") or "")
    return {
        "status": "useful",
        "kind": kind,
        "reason": (
            f"{title or kind} surfaced with {evidence_count} evidence reference(s) "
            f"and {actionability} follow-up."
        ),
        "evidence_count": evidence_count,
        "actionability": actionability,
    }


def _build_dashboard_workflow_groups(
    *,
    requested_pack: str,
    research_overview_supported: bool,
) -> list[dict[str, Any]]:
    return [
        _workflow_group(
            "orient",
            "Orient",
            "Start with the compiled entry products before diving into individual queues.",
            [
                {
                    "label": "Orientation Brief",
                    "path": _scoped_path("/briefing", pack_name=requested_pack),
                    "detail": "Read the current entry product.",
                },
                {
                    "label": "Workbench Home",
                    "path": _scoped_path("/", pack_name=requested_pack),
                    "detail": "Return to the current shell overview.",
                },
            ],
        ),
        _workflow_group(
            "inspect",
            "Inspect",
            "Read the current knowledge state directly from compiled browsing surfaces.",
            [
                {
                    "label": "Objects",
                    "path": _scoped_path("/objects", pack_name=requested_pack),
                    "detail": "Browse indexed evergreen objects.",
                },
                {
                    "label": "Search",
                    "path": _scoped_path("/search", pack_name=requested_pack),
                    "detail": "Search notes and objects across the shell.",
                },
            ],
        ),
        _workflow_group(
            "review",
            "Review",
            "Open the highest-signal maintenance surfaces for contradictions, summaries, and signals.",
            [
                {
                    "label": "Signals",
                    "path": _scoped_path("/signals", pack_name=requested_pack),
                    "detail": "Review current active signals.",
                },
                {
                    "label": "Contradictions" if research_overview_supported else "Actions",
                    "path": _scoped_path(
                        "/contradictions" if research_overview_supported else "/actions",
                        pack_name=requested_pack,
                    ),
                    "detail": (
                        "Inspect open semantic tensions."
                        if research_overview_supported
                        else "Review queued execution actions."
                    ),
                },
            ],
        ),
        _workflow_group(
            "trace",
            "Trace",
            "Follow provenance and downstream production chains before editing or reviewing.",
            [
                {
                    "label": "Production",
                    "path": _scoped_path("/production", pack_name=requested_pack),
                    "detail": "Inspect production weak points and chain state.",
                },
                {
                    "label": "Deep Dives" if research_overview_supported else "Notes",
                    "path": _scoped_path(
                        "/deep-dives" if research_overview_supported else "/objects",
                        pack_name=requested_pack,
                    ),
                    "detail": (
                        "Follow note -> deep dive -> object derivation."
                        if research_overview_supported
                        else "Use object pages as the primary trace surface."
                    ),
                },
            ],
        ),
        _workflow_group(
            "explore",
            "Explore",
            "Move through topic, graph, and timeline surfaces once the shell has oriented you.",
            [
                {
                    "label": "Events" if research_overview_supported else "Objects",
                    "path": _scoped_path(
                        "/events" if research_overview_supported else "/objects",
                        pack_name=requested_pack,
                    ),
                    "detail": (
                        "Explore timeline and dossier surfaces."
                        if research_overview_supported
                        else "Explore the shared-shell object browser."
                    ),
                },
                {
                    "label": "Clusters" if research_overview_supported else "Search",
                    "path": _scoped_path(
                        "/clusters" if research_overview_supported else "/search",
                        pack_name=requested_pack,
                    ),
                    "detail": (
                        "Explore graph clusters and higher-order structure."
                        if research_overview_supported
                        else "Use search to move laterally through the vault."
                    ),
                },
            ],
        ),
    ]


def _operator_action(label: str, path: str, detail: str) -> dict[str, str]:
    return {
        "label": label,
        "path": path,
        "detail": detail,
    }


def _impact_counts(items: list[dict[str, Any]]) -> dict[str, int]:
    return dict(
        Counter(
            str((item.get("impact_summary") or {}).get("impact_status") or "unknown")
            for item in items
        )
    )


def _capture_status_counts(items: list[dict[str, Any]]) -> dict[str, int]:
    return dict(
        Counter(
            str((item.get("capture_summary") or {}).get("status") or "missing")
            for item in items
        )
    )


def _section_nav_from_compiled_sections(sections: list[dict[str, Any]]) -> list[dict[str, str]]:
    return [
        {
            "href": f"#{str(section.get('anchor') or str(section.get('id') or '').replace('_', '-'))}",
            "label": str(section.get("label") or section.get("id") or ""),
        }
        for section in sections
    ]


def _db_path(vault_dir: Path | str) -> Path:
    resolved = resolve_vault_dir(vault_dir)
    return VaultLayout.from_vault(resolved).knowledge_db


def _existing_object_rows(
    vault_dir: Path | str,
    object_ids: list[str],
    *,
    pack_name: str | None = None,
) -> dict[str, str]:
    normalized_object_ids = list(dict.fromkeys(object_id for object_id in object_ids if object_id))
    if not normalized_object_ids:
        return {}
    db_path = _db_path(vault_dir)
    placeholders = ",".join("?" for _ in normalized_object_ids)
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute(
            f"""
            SELECT object_id, title
            FROM objects
            WHERE object_id IN ({placeholders})
            """,
            tuple(normalized_object_ids),
        ).fetchall()
    return {str(object_id): str(title) for object_id, title in rows}


def _object_scope_paths(
    vault_dir: Path | str,
    object_ids: list[str],
    *,
    pack_name: str | None = None,
) -> dict[str, str]:
    normalized_object_ids = list(dict.fromkeys(object_id for object_id in object_ids if object_id))
    if not normalized_object_ids:
        return {}
    rows = _batch_object_rows(vault_dir, normalized_object_ids, pack_name=pack_name)
    return {
        str(object_id): str(rows.get(object_id, {}).get("canonical_path") or "")
        for object_id in normalized_object_ids
    }


def _object_ids_from_claim_ids(*claim_id_lists: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for claim_ids in claim_id_lists:
        for claim_id in claim_ids:
            object_id = claim_id.split("::", 1)[0]
            if object_id and object_id not in seen:
                seen.add(object_id)
                ordered.append(object_id)
    return ordered


def _edge_kind_parts(edge_kind: str) -> tuple[str, str]:
    family, sep, subtype = str(edge_kind).partition(":")
    if not sep:
        return (family, "")
    return (family, subtype)


def _derive_cluster_structural_label(
    *,
    center_title: str,
    edge_summary_items: list[dict[str, Any]],
) -> dict[str, str]:
    contradiction_item = next((item for item in edge_summary_items if item["edge_family"] == "contradiction"), None)
    if contradiction_item is not None:
        return {
            "kind": "contradiction_cluster",
            "title": f"Contradiction cluster around {center_title}",
            "reason": f"{contradiction_item['count']} contradiction edges are present in the local graph.",
        }
    dominant = edge_summary_items[0] if edge_summary_items else None
    if dominant is None:
        return {
            "kind": "reference_cluster",
            "title": f"Reference cluster around {center_title}",
            "reason": "No internal edge structure has been materialized yet.",
        }
    if dominant["edge_family"] == "relation":
        return {
            "kind": "relation_cluster",
            "title": f"Relation cluster around {center_title}",
            "reason": f"{dominant['count']} {dominant['display_name']} dominate the local graph.",
        }
    return {
        "kind": "mixed_cluster",
        "title": f"Mixed graph cluster around {center_title}",
        "reason": f"Dominant edge family is {dominant['edge_family']}.",
    }


def _build_relation_pattern_items(edge_summary_items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "edge_kind": item["edge_kind"],
            "subtype": item["edge_subtype"],
            "display_name": item["display_name"],
            "count": item["count"],
        }
        for item in edge_summary_items
        if item["edge_family"] == "relation"
    ]


def _relation_pattern_preview(relation_pattern_items: list[dict[str, Any]]) -> str:
    if not relation_pattern_items:
        return ""
    preview_items = relation_pattern_items[:2]
    preview = ", ".join(f"{item['display_name']} ({item['count']})" for item in preview_items)
    if len(relation_pattern_items) > 2:
        return f"{preview}, +{len(relation_pattern_items) - 2} more"
    return preview


def _top_counter_items(
    counts: Counter[str],
    item_map: dict[str, dict[str, Any]],
    *,
    limit: int = 5,
) -> list[dict[str, Any]]:
    return [
        {**item_map[key], "object_count": count}
        for key, count in sorted(counts.items(), key=lambda item: (-item[1], item[0]))
        if key in item_map
    ][:limit]


def _collect_cluster_provenance(
    vault_dir: Path | str,
    member_object_ids: list[str],
) -> dict[str, Any]:
    provenance_map = get_object_provenance_map(vault_dir, member_object_ids)
    source_note_counts: Counter[str] = Counter()
    source_note_items: dict[str, dict[str, Any]] = {}
    moc_counts: Counter[str] = Counter()
    moc_items: dict[str, dict[str, Any]] = {}
    for provenance in provenance_map.values():
        for note in provenance["source_notes"]:
            slug = str(note["slug"])
            source_note_items.setdefault(slug, note)
            source_note_counts[slug] += 1
        for moc in provenance["mocs"]:
            slug = str(moc["slug"])
            moc_items.setdefault(slug, moc)
            moc_counts[slug] += 1
    return {
        "source_note_counts": source_note_counts,
        "source_note_items": source_note_items,
        "moc_counts": moc_counts,
        "moc_items": moc_items,
    }


def _build_cluster_provenance_index(
    vault_dir: Path | str,
    cluster_rows: list[dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    return {
        str(row["cluster_id"]): _collect_cluster_provenance(
            vault_dir,
            [str(member["object_id"]) for member in row["members"]],
        )
        for row in cluster_rows
    }


def _build_related_cluster_items(
    vault_dir: Path | str,
    *,
    cluster_id: str,
    requested_pack: str,
    current_source_note_items: dict[str, dict[str, Any]],
    current_moc_items: dict[str, dict[str, Any]],
    cluster_rows: list[dict[str, Any]] | None = None,
    cluster_provenance_index: dict[str, dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    current_source_slugs = set(current_source_note_items)
    current_moc_slugs = set(current_moc_items)
    if not current_source_slugs and not current_moc_slugs:
        return []
    related_items: list[dict[str, Any]] = []
    rows = cluster_rows if cluster_rows is not None else list_graph_clusters(vault_dir, pack_name=requested_pack, limit=200)
    for row in rows:
        if str(row["cluster_id"]) == cluster_id:
            continue
        provenance = None
        if cluster_provenance_index is not None:
            provenance = cluster_provenance_index.get(str(row["cluster_id"]))
        if provenance is None:
            member_object_ids = [str(member["object_id"]) for member in row["members"]]
            provenance = _collect_cluster_provenance(vault_dir, member_object_ids)
        shared_source_slugs = sorted(current_source_slugs & set(provenance["source_note_items"]))
        shared_moc_slugs = sorted(current_moc_slugs & set(provenance["moc_items"]))
        if not shared_source_slugs and not shared_moc_slugs:
            continue
        reason_parts: list[str] = []
        if shared_source_slugs:
            reason_parts.append(f"{len(shared_source_slugs)} shared source notes")
        if shared_moc_slugs:
            reason_parts.append(f"{len(shared_moc_slugs)} shared atlas pages")
        score = len(shared_source_slugs) * 10 + len(shared_moc_slugs) * 5 + int(row["member_count"])
        if shared_source_slugs and shared_moc_slugs:
            bridge_kind = "source_and_atlas_overlap"
        elif shared_source_slugs:
            bridge_kind = "source_overlap"
        else:
            bridge_kind = "atlas_overlap"
        if len(shared_source_slugs) >= 1 and len(shared_moc_slugs) >= 1:
            bridge_band = "strong"
        elif len(shared_source_slugs) >= 1 or len(shared_moc_slugs) >= 2:
            bridge_band = "medium"
        else:
            bridge_band = "light"
        related_items.append(
            {
                "cluster_id": str(row["cluster_id"]),
                "pack": requested_pack,
                "label": str(row["label"]),
                "display_title": f"Cluster around {row['center_title']}",
                "detail_path": (
                    f"/cluster?id={quote(str(row['cluster_id']), safe='')}"
                    f"&pack={quote(requested_pack, safe='')}"
                ),
                "member_count": int(row["member_count"]),
                "shared_source_count": len(shared_source_slugs),
                "shared_moc_count": len(shared_moc_slugs),
                "shared_source_titles": [
                    str(current_source_note_items.get(slug, provenance["source_note_items"].get(slug, {})).get("title", slug))
                    for slug in shared_source_slugs
                ][:3],
                "shared_moc_titles": [
                    str(current_moc_items.get(slug, provenance["moc_items"].get(slug, {})).get("title", slug))
                    for slug in shared_moc_slugs
                ][:3],
                "bridge_kind": bridge_kind,
                "bridge_band": bridge_band,
                "reason": ", ".join(reason_parts),
                "score": score,
            }
        )
    related_items.sort(key=lambda item: (-item["score"], item["label"].lower(), item["cluster_id"]))
    return related_items[:5]


def _bridge_kind_display_name(bridge_kind: str) -> str:
    if bridge_kind == "source_and_atlas_overlap":
        return "Source + Atlas Overlap"
    if bridge_kind == "source_overlap":
        return "Source Overlap"
    if bridge_kind == "atlas_overlap":
        return "Atlas Overlap"
    return bridge_kind.replace("_", " ").title()


def _build_related_cluster_groups(related_clusters: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, Any]] = {}
    for item in related_clusters:
        group = grouped.setdefault(
            str(item["bridge_kind"]),
            {
                "bridge_kind": str(item["bridge_kind"]),
                "display_name": _bridge_kind_display_name(str(item["bridge_kind"])),
                "count": 0,
                "cluster_titles": [],
            },
        )
        group["count"] += 1
        if item["display_title"] not in group["cluster_titles"]:
            group["cluster_titles"].append(item["display_title"])
    return sorted(
        grouped.values(),
        key=lambda item: (-int(item["count"]), str(item["bridge_kind"])),
    )


def _build_reading_routes(related_clusters: list[dict[str, Any]]) -> list[dict[str, Any]]:
    route_specs = [
        (
            "full_context_route",
            "Full Context Route",
            {"source_and_atlas_overlap"},
        ),
        (
            "source_continuity_route",
            "Source Continuity Route",
            {"source_and_atlas_overlap", "source_overlap"},
        ),
        (
            "atlas_continuity_route",
            "Atlas Continuity Route",
            {"source_and_atlas_overlap", "atlas_overlap"},
        ),
    ]
    routes: list[dict[str, Any]] = []
    for index, (route_kind, display_name, allowed_bridge_kinds) in enumerate(route_specs, start=1):
        candidate = next(
            (item for item in related_clusters if str(item["bridge_kind"]) in allowed_bridge_kinds),
            None,
        )
        if candidate is None:
            continue
        if route_kind == "full_context_route":
            route_reason = (
                "Best first if you want both evidence continuity and atlas continuity across clusters."
            )
            route_score = int(candidate["score"]) + 30
        elif route_kind == "source_continuity_route":
            route_reason = "Best if you want to keep reading along shared source-note coverage."
            route_score = int(candidate["score"]) + 20
        else:
            route_reason = "Best if you want to keep reading along shared atlas-page coverage."
            route_score = int(candidate["score"]) + 10
        routes.append(
            {
                "route_kind": route_kind,
                "route_rank": index,
                "route_score": route_score,
                "display_name": display_name,
                "cluster_id": candidate["cluster_id"],
                "display_title": candidate["display_title"],
                "detail_path": candidate["detail_path"],
                "bridge_kind": candidate["bridge_kind"],
                "bridge_band": candidate["bridge_band"],
                "reason": candidate["reason"],
                "route_reason": route_reason,
            }
        )
    return routes


def _build_cluster_surface_sections(
    vault_dir: Path | str,
    *,
    cluster: dict[str, Any],
    edges: list[dict[str, Any]],
    requested_pack: str,
    cluster_rows: list[dict[str, Any]] | None = None,
    cluster_provenance_index: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    member_object_ids = [str(member["object_id"]) for member in cluster["members"]]
    edge_kind_counts = Counter(edge["edge_kind"] for edge in edges)
    edge_summary_items = [
        {
            "edge_kind": edge_kind,
            "edge_family": _edge_kind_parts(edge_kind)[0],
            "edge_subtype": _edge_kind_parts(edge_kind)[1],
            "display_name": (
                "contradiction links"
                if _edge_kind_parts(edge_kind)[0] == "contradiction"
                else (
                    f"{_edge_kind_parts(edge_kind)[1].replace('_', ' ')} links"
                    if _edge_kind_parts(edge_kind)[0] == "relation" and _edge_kind_parts(edge_kind)[1]
                    else edge_kind.replace(":", " ")
                )
            ),
            "count": count,
        }
        for edge_kind, count in sorted(edge_kind_counts.items(), key=lambda item: (-item[1], item[0]))
    ]
    object_kind_counts = Counter(
        str(member["object_kind"])
        for member in cluster["members"]
        if member.get("object_kind")
    )
    review_context = get_review_context(vault_dir, member_object_ids, pack_name=requested_pack)
    open_contradictions = [
        {
            "contradiction_id": item["contradiction_id"],
            "subject_key": item["subject_key"],
            "object_ids": _object_ids_from_claim_ids(item["positive_claim_ids"], item["negative_claim_ids"]),
            "path": f"/contradictions?q={quote(str(item['subject_key']), safe='')}",
        }
        for item in list_contradictions(
            vault_dir,
            pack_name=requested_pack,
            status="open",
            limit=MAX_PAGE_SIZE,
        )
        if set(_object_ids_from_claim_ids(item["positive_claim_ids"], item["negative_claim_ids"])) & set(member_object_ids)
    ][:5]
    stale_summaries = list_stale_summaries(
        vault_dir,
        pack_name=requested_pack,
        object_ids=member_object_ids,
        limit=5,
    )
    provenance = (
        cluster_provenance_index.get(str(cluster["cluster_id"]))
        if cluster_provenance_index is not None and str(cluster["cluster_id"]) in cluster_provenance_index
        else _collect_cluster_provenance(vault_dir, member_object_ids)
    )
    source_note_counts = provenance["source_note_counts"]
    source_note_items = provenance["source_note_items"]
    moc_counts = provenance["moc_counts"]
    moc_items = provenance["moc_items"]

    top_edge_kind = next(iter(sorted(edge_kind_counts.items(), key=lambda item: (-item[1], item[0]))), None)
    kind_summary = ", ".join(
        f"{kind} {count}"
        for kind, count in sorted(object_kind_counts.items(), key=lambda item: (-item[1], item[0]))
    )
    summary_bullets = [
        f"{cluster['member_count']} objects in a {cluster['cluster_kind']} cluster centered on {cluster['center_title']}.",
    ]
    if top_edge_kind:
        summary_bullets.append(
            f"{len(edges)} internal edges across {len(edge_kind_counts)} edge kinds; dominant edge kind is {top_edge_kind[0]} ({top_edge_kind[1]})."
        )
    if kind_summary:
        summary_bullets.append(f"Object kinds in scope: {kind_summary}.")
    if review_context["source_note_count"] or review_context["moc_count"]:
        summary_bullets.append(
            f"Coverage currently includes {review_context['source_note_count']} source/deep-dive notes and {review_context['moc_count']} atlas pages."
        )
    if review_context["open_contradiction_count"] or review_context["stale_summary_count"]:
        summary_bullets.append(
            f"Review pressure: {review_context['open_contradiction_count']} open contradictions and {review_context['stale_summary_count']} stale summaries in this cluster scope."
        )
    structural_label = _derive_cluster_structural_label(
        center_title=str(cluster["center_title"]),
        edge_summary_items=edge_summary_items,
    )
    relation_pattern_items = _build_relation_pattern_items(edge_summary_items)
    relation_pattern_preview = _relation_pattern_preview(relation_pattern_items)
    related_clusters = _build_related_cluster_items(
        vault_dir,
        cluster_id=str(cluster["cluster_id"]),
        requested_pack=requested_pack,
        current_source_note_items=source_note_items,
        current_moc_items=moc_items,
        cluster_rows=cluster_rows,
        cluster_provenance_index=cluster_provenance_index,
    )
    related_cluster_groups = _build_related_cluster_groups(related_clusters)
    reading_routes = _build_reading_routes(related_clusters)
    next_read_cluster = related_clusters[0] if related_clusters else None

    return {
        "display_title": structural_label["title"],
        "edge_count": len(edges),
        "edge_kind_counts": dict(edge_kind_counts),
        "edge_summary_items": edge_summary_items,
        "relation_pattern_items": relation_pattern_items,
        "relation_pattern_preview": relation_pattern_preview,
        "object_kind_counts": dict(object_kind_counts),
        "structural_label": structural_label,
        "review_context": review_context,
        "open_contradictions": open_contradictions,
        "stale_summaries": stale_summaries,
        "related_clusters": related_clusters,
        "related_cluster_groups": related_cluster_groups,
        "reading_routes": reading_routes,
        "next_read_cluster": next_read_cluster,
        "top_source_notes": _top_counter_items(source_note_counts, source_note_items),
        "top_mocs": _top_counter_items(moc_counts, moc_items),
        "summary_bullets": summary_bullets,
    }


def build_cluster_summary_payload(
    vault_dir: Path | str,
    *,
    cluster_id: str,
    pack_name: str | None = None,
    cluster_rows: list[dict[str, Any]] | None = None,
    cluster_provenance_index: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    detail = get_graph_cluster_detail(vault_dir, cluster_id, pack_name=pack_name)
    cluster = detail["cluster"]
    requested_pack = pack_name or str(cluster["pack"])
    member_index = {str(member["object_id"]): member for member in cluster["members"]}
    detail_path = (
        f"/cluster?id={quote(str(cluster['cluster_id']), safe='')}"
        f"&pack={quote(requested_pack, safe='')}"
    )
    enriched_cluster = {
        **cluster,
        "detail_path": detail_path,
        "center_object_path": _scoped_path(
            f"/object?id={quote(str(cluster['center_object_id']), safe='')}",
            pack_name=requested_pack,
        ),
        "member_links": [
            {
                **member,
                "path": _scoped_path(
                    f"/object?id={quote(str(member['object_id']), safe='')}",
                    pack_name=requested_pack,
                ),
            }
            for member in cluster["members"]
        ],
    }
    enriched_edges = [
        {
            **edge,
            "source_title": member_index.get(str(edge["source_object_id"]), {}).get(
                "title",
                str(edge["source_object_id"]),
            ),
            "target_title": member_index.get(str(edge["target_object_id"]), {}).get(
                "title",
                str(edge["target_object_id"]),
            ),
            "source_path": _scoped_path(
                f"/object?id={quote(str(edge['source_object_id']), safe='')}",
                pack_name=requested_pack,
            ),
            "target_path": _scoped_path(
                f"/object?id={quote(str(edge['target_object_id']), safe='')}",
                pack_name=requested_pack,
            ),
        }
        for edge in detail["edges"]
    ]
    sections = _build_cluster_surface_sections(
        vault_dir,
        cluster=enriched_cluster,
        edges=enriched_edges,
        requested_pack=requested_pack,
        cluster_rows=cluster_rows,
        cluster_provenance_index=cluster_provenance_index,
    )
    return {
        "requested_pack": requested_pack,
        "cluster": enriched_cluster,
        "edges": enriched_edges,
        **sections,
    }


def _build_production_summary(
    vault_dir: Path | str,
    object_ids: list[str],
    *,
    pack_name: str | None = None,
) -> dict[str, Any]:
    normalized_object_ids = list(dict.fromkeys(object_id for object_id in object_ids if object_id))
    object_traceability = [
        get_object_traceability(vault_dir, object_id, pack_name=pack_name)
        for object_id in normalized_object_ids
    ]
    source_note_counts: Counter[str] = Counter()
    deep_dive_counts: Counter[str] = Counter()
    atlas_page_counts: Counter[str] = Counter()
    source_note_items: dict[str, dict[str, str]] = {}
    deep_dive_items: dict[str, dict[str, str]] = {}
    atlas_page_items: dict[str, dict[str, str]] = {}
    missing_source_object_ids: list[str] = []
    missing_deep_dive_object_ids: list[str] = []
    missing_atlas_object_ids: list[str] = []

    for traceability in object_traceability:
        object_id = traceability["object"]["object_id"]
        if not traceability["source_notes"]:
            missing_source_object_ids.append(object_id)
        if not traceability["deep_dives"]:
            missing_deep_dive_object_ids.append(object_id)
        if not traceability["atlas_pages"]:
            missing_atlas_object_ids.append(object_id)
        for item in traceability["source_notes"]:
            source_note_items.setdefault(item["path"], item)
            source_note_counts[item["path"]] += 1
        for item in traceability["deep_dives"]:
            deep_dive_items.setdefault(item["slug"], item)
            deep_dive_counts[item["slug"]] += 1
        for item in traceability["atlas_pages"]:
            atlas_page_items.setdefault(item["slug"], item)
            atlas_page_counts[item["slug"]] += 1

    def _top_items(
        counts: Counter[str],
        item_map: dict[str, dict[str, str]],
    ) -> list[dict[str, Any]]:
        ordered = sorted(
            counts.items(),
            key=lambda item: (-item[1], item[0]),
        )
        return [
            {
                **item_map[key],
                "object_count": count,
            }
            for key, count in ordered
            if key in item_map
        ][:5]

    signals: list[dict[str, Any]] = []
    if missing_source_object_ids:
        signals.append(
            {
                "code": "missing_source_notes",
                "count": len(missing_source_object_ids),
                "label": "Missing source notes",
                "object_ids": missing_source_object_ids,
            }
        )
    if missing_deep_dive_object_ids:
        signals.append(
            {
                "code": "missing_deep_dives",
                "count": len(missing_deep_dive_object_ids),
                "label": "Missing deep dives",
                "object_ids": missing_deep_dive_object_ids,
            }
        )
    if missing_atlas_object_ids:
        signals.append(
            {
                "code": "missing_atlas_reach",
                "count": len(missing_atlas_object_ids),
                "label": "Missing Atlas / MOC reach",
                "object_ids": missing_atlas_object_ids,
            }
        )

    return {
        "object_count": len(normalized_object_ids),
        "counts": {
            "source_notes": len(source_note_items),
            "deep_dives": len(deep_dive_items),
            "atlas_pages": len(atlas_page_items),
        },
        "top_source_notes": _top_items(source_note_counts, source_note_items),
        "top_deep_dives": _top_items(deep_dive_counts, deep_dive_items),
        "top_atlas_pages": _top_items(atlas_page_counts, atlas_page_items),
        "signals": signals,
    }


def _build_production_weak_points(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    query: str | None = None,
    limit: int = 12,
) -> list[dict[str, Any]]:
    return list_production_gaps(vault_dir, pack_name=pack_name, query=query, limit=limit)


def _build_evolution_section(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    query: str | None = None,
    link_type: str | None = None,
    status: str = "candidate",
    scoped_object_ids: list[str] | None = None,
) -> dict[str, Any]:
    normalized_object_ids = list(dict.fromkeys(object_id for object_id in (scoped_object_ids or []) if object_id))
    canonical_paths = {
        path
        for path in _object_scope_paths(
            vault_dir,
            normalized_object_ids,
            pack_name=pack_name,
        ).values()
        if path
    }
    reviewed_links = list_evolution_links(
        vault_dir,
        object_ids=normalized_object_ids or None,
        pack_name=pack_name,
        query=query,
        link_type=link_type,
    )
    reviewed_evolution_ids = {str(item["evolution_id"]) for item in reviewed_links}
    accepted_links = [item for item in reviewed_links if item["status"] == "accepted"]
    rejected_links = [item for item in reviewed_links if item["status"] == "rejected"]
    candidate_items = [
        item
        for item in list_evolution_candidates(
            vault_dir,
            object_ids=normalized_object_ids or None,
            pack_name=pack_name,
            query=query,
            link_type=link_type,
            status="candidate",
        )
        if item["evolution_id"] not in reviewed_evolution_ids
    ]
    if normalized_object_ids:
        filtered_items: list[dict[str, Any]] = []
        for item in candidate_items:
            refs = (str(item["earlier_ref"]), str(item["later_ref"]))
            if item["subject_kind"] == "object" and item["subject_id"] in normalized_object_ids:
                filtered_items.append(item)
                continue
            if any(
                ref.startswith(f"claim://{object_id}::") or ref == f"object://{object_id}"
                for object_id in normalized_object_ids
                for ref in refs
            ):
                filtered_items.append(item)
                continue
            if any(path in canonical_paths for path in item["source_paths"]):
                filtered_items.append(item)
        candidate_items = filtered_items
        accepted_links = [
            item for item in accepted_links
            if set(item.get("object_ids", [])).intersection(normalized_object_ids)
        ]
        rejected_links = [
            item for item in rejected_links
            if set(item.get("object_ids", [])).intersection(normalized_object_ids)
        ]
    if status == "accepted":
        candidate_items = []
    elif status == "rejected":
        candidate_items = []
        accepted_links = []
    elif status == "candidate":
        pass
    else:
        # keep all sections visible on the default "all" view
        status = "all"
    return {
        "accepted_links": accepted_links,
        "rejected_links": rejected_links,
        "candidate_items": candidate_items,
        "candidate_count": len(candidate_items),
        "accepted_count": len(accepted_links),
        "rejected_count": len(rejected_links),
        "link_types": sorted(
            {
                *(item["link_type"] for item in candidate_items),
                *(str(item.get("link_type") or "") for item in accepted_links),
                *(str(item.get("link_type") or "") for item in rejected_links),
            }
        ),
        "status": status,
    }


def build_signal_browser_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    signal_type: str | None = None,
    query: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    governance_contract = describe_governance_contract(pack_name=pack_name)
    surface_contract = describe_observation_surface_contract(
        pack_name=pack_name,
        surface_kind="signals",
    )
    if surface_contract["status"] == "missing":
        return {
            "screen": "signals/browser",
            "requested_pack": requested_pack,
            "surface_contract": surface_contract,
            "governance_contract": governance_contract,
            "operator_rail": [],
            "surface_error": (
                f"Pack '{surface_contract['requested_pack']}' does not expose a shared shell "
                f"'signals' surface."
            ),
            "items": [],
            "count": 0,
            "query": query or "",
            "signal_type": signal_type or "",
            "type_counts": {},
            "impact_counts": {},
            "signal_type_explanations": SIGNAL_TYPE_EXPLANATIONS,
        }
    items = list_signals(vault_dir, pack_name=pack_name, signal_type=signal_type, query=query)
    return {
        "screen": "signals/browser",
        "requested_pack": requested_pack,
        "surface_contract": surface_contract,
        "governance_contract": governance_contract,
        "operator_rail": [
            _operator_action(
                "Action Queue",
                _scoped_path("/actions", pack_name=requested_pack),
                "Run or inspect queued actions.",
            ),
            _operator_action(
                "Production Browser",
                _scoped_path("/production", pack_name=requested_pack),
                "Trace current production weak points.",
            ),
            _operator_action(
                "Contradictions",
                _scoped_path(
                    "/contradictions" if _supports_research_shell(pack_name) else "/search",
                    pack_name=requested_pack,
                ),
                (
                    "Review semantic tensions."
                    if _supports_research_shell(pack_name)
                    else "Shared-shell search fallback."
                ),
            ),
            _operator_action(
                "Orientation Brief",
                _scoped_path("/briefing", pack_name=requested_pack),
                "Return to the current entry product.",
            ),
        ],
        "items": items,
        "count": len(items),
        "query": query or "",
        "signal_type": signal_type or "",
        "type_counts": dict(Counter(item["signal_type"] for item in items)),
        "impact_counts": _impact_counts(items),
        "capture_status_counts": _capture_status_counts(items),
        "signal_type_explanations": SIGNAL_TYPE_EXPLANATIONS,
    }


def build_action_queue_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    status: str | None = None,
    query: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    items = list_action_queue(vault_dir, pack_name=pack_name, status=status, query=query)
    return {
        "screen": "actions/browser",
        "requested_pack": requested_pack,
        "governance_contract": describe_governance_contract(pack_name=pack_name),
        "items": items,
        "count": len(items),
        "query": query or "",
        "status": status or "",
        "status_counts": dict(Counter(str(item["status"]) for item in items)),
        "impact_counts": _impact_counts(items),
        "queued_safe_count": sum(1 for item in items if item.get("status") == "queued" and item.get("safe_to_run")),
        "failed_count": sum(1 for item in items if item.get("status") == "failed"),
        "failure_buckets": dict(
            Counter(
                str(item.get("failure_bucket") or "")
                for item in items
                if item.get("status") == "failed" and str(item.get("failure_bucket") or "")
            )
        ),
    }


def build_candidate_browser_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    query: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    payload = list_candidate_concepts(vault_dir, query=query, limit=limit, offset=offset)
    payload["requested_pack"] = requested_pack
    payload["operator_rail"] = [
        _operator_action(
            "Orientation Brief",
            _scoped_path("/briefing", pack_name=requested_pack),
            "Read the compiled context before changing canonical concepts.",
        ),
        _operator_action(
            "Signals",
            _scoped_path("/signals", pack_name=requested_pack),
            "Check whether this candidate is attached to active production signals.",
        ),
        _operator_action(
            "Actions",
            _scoped_path("/actions", pack_name=requested_pack),
            "Inspect queued work that may depend on candidate canonicalization.",
        ),
        _operator_action(
            "Objects",
            _scoped_path("/objects", pack_name=requested_pack),
            "Compare candidates against active Evergreen objects.",
        ),
    ]
    payload["query"] = query or ""
    return payload


def build_briefing_payload(vault_dir: Path | str, *, pack_name: str | None = None) -> dict[str, Any]:
    requested_pack = pack_name or ""
    surface_contract = describe_observation_surface_contract(
        pack_name=pack_name,
        surface_kind="briefing",
    )
    assembly_contract = _assembly_contract("orientation_brief", pack_name=pack_name)
    governance_contract = describe_governance_contract(pack_name=pack_name)
    if surface_contract["status"] == "missing":
        return {
            "screen": "briefing/intelligence",
            "requested_pack": requested_pack,
            "surface_contract": surface_contract,
            "assembly_contract": assembly_contract,
            "governance_contract": governance_contract,
            "surface_error": (
                f"Pack '{surface_contract['requested_pack']}' does not expose a shared shell "
                f"'briefing' surface."
            ),
            "generated_at": "",
            "recent_signal_count": 0,
            "unresolved_issue_count": 0,
            "changed_object_count": 0,
            "active_topic_count": 0,
            "recent_signals": [],
            "unresolved_issues": [],
            "changed_objects": [],
            "active_topics": [],
            "insight_count": 0,
            "priority_item_count": 0,
            "insights": [],
            "priority_items": [],
            "compiled_sections": [],
            "section_nav": [],
            "first_useful_sign": None,
            "first_useful_sign_check": {
                "status": "empty",
                "kind": "",
                "reason": "No briefing surface is available for this pack.",
                "evidence_count": 0,
                "actionability": "review",
            },
            "background_policy": {
                "governed_signal_types": [],
                "auto_queue_enabled_signal_types": [],
                "review_only_signal_types": [],
                "active_auto_queue_signal_count": 0,
                "active_review_only_signal_count": 0,
                "skipped_signal_count": 0,
                "skipped_reasons": {},
                "signal_type_decisions": {},
            },
            "loop_summary": {
                "productive_count": 0,
                "waiting_count": 0,
                "running_count": 0,
                "ready_count": 0,
                "completed_count": 0,
                "failed_count": 0,
                "stalled_count": 0,
                "review_only_count": 0,
            },
            "queue_summary": {
                "queued_count": 0,
                "safe_queued_count": 0,
                "running_count": 0,
                "failed_count": 0,
                "failure_buckets": {},
            },
        }
    snapshot = get_briefing_snapshot(vault_dir, pack_name=pack_name)
    changed_items = [
        {
            "kind": "changed_object",
            "label": str(item["title"]),
            "path": str(item["path"]),
            "detail": f"Changed object · {item['object_id']}",
        }
        for item in snapshot.get("changed_objects", [])[:5]
    ]
    what_matters_items = [
        {
            "kind": "active_topic",
            "label": str(item["title"]),
            "path": str(item["path"]),
            "detail": f"{int(item['signal_count'])} signals in scope",
        }
        for item in snapshot.get("active_topics", [])[:5]
    ]
    needs_review_items = [
        {
            "kind": str(item["signal_type"]),
            "label": str(item["title"]),
            "path": str(item["source_path"]),
            "detail": str(item["detail"]),
        }
        for item in snapshot.get("unresolved_issues", [])[:5]
    ]
    next_read_items = [
        {
            "kind": str(item["kind"]),
            "label": str(item["title"]),
            "path": str(item["path"]),
            "detail": str(item["detail"]),
        }
        for item in snapshot.get("insights", [])[:5]
    ]
    next_action_items = [
        {
            "kind": str(item["kind"]),
            "label": str(item["title"]),
            "path": str(((item.get("recommended_action") or {}).get("path")) or item.get("path") or ""),
            "detail": str(((item.get("recommended_action") or {}).get("label")) or item.get("detail") or ""),
        }
        for item in snapshot.get("priority_items", [])[:5]
    ]
    impact_counts = _impact_counts(snapshot.get("recent_signals", []))
    loop_summary = {
        "productive_count": impact_counts.get("productive", 0),
        "waiting_count": impact_counts.get("waiting", 0),
        "running_count": impact_counts.get("running", 0),
        "ready_count": impact_counts.get("ready", 0),
        "completed_count": impact_counts.get("completed", 0),
        "failed_count": impact_counts.get("failed", 0),
        "stalled_count": impact_counts.get("stalled", 0),
        "review_only_count": impact_counts.get("review_only", 0),
    }
    signal_loop_items = [
        {
            "kind": "productive",
            "label": "Productive",
            "path": _scoped_path("/signals", pack_name=requested_pack),
            "detail": f"{loop_summary['productive_count']} signals produced visible downstream change.",
        },
        {
            "kind": "waiting",
            "label": "Waiting",
            "path": _scoped_path("/actions", pack_name=requested_pack),
            "detail": f"{loop_summary['waiting_count']} signals currently have queued execution waiting.",
        },
        {
            "kind": "running",
            "label": "Running",
            "path": _scoped_path("/actions", pack_name=requested_pack),
            "detail": f"{loop_summary['running_count']} signals are currently executing.",
        },
        {
            "kind": "blocked",
            "label": "Blocked",
            "path": _scoped_path("/actions", pack_name=requested_pack),
            "detail": (
                f"{loop_summary['failed_count'] + loop_summary['stalled_count']} signals are failed or stalled."
            ),
        },
        {
            "kind": "review_only",
            "label": "Review Only",
            "path": _scoped_path("/signals", pack_name=requested_pack),
            "detail": f"{loop_summary['review_only_count']} signals currently route to review rather than queued execution.",
        },
    ]
    productive_signal = next(
        (
            item
            for item in snapshot.get("recent_signals", [])
            if str((item.get("impact_summary") or {}).get("impact_status") or "") == "productive"
        ),
        None,
    )
    first_useful_sign = (
        {
            "signal_id": str(productive_signal.get("signal_id") or ""),
            "kind": str(productive_signal.get("signal_type") or ""),
            "title": str(productive_signal.get("title") or ""),
            "detail": str((productive_signal.get("impact_summary") or {}).get("impact_detail") or ""),
            "path": str(
                ((productive_signal.get("recommended_action") or {}).get("queue_path"))
                or ((productive_signal.get("recommended_action") or {}).get("path"))
                or productive_signal.get("source_path")
                or ""
            ),
            "source_paths": list(productive_signal.get("note_paths", [])),
            "object_ids": list(productive_signal.get("object_ids", [])),
            "recommended_action": productive_signal.get("recommended_action"),
        }
        if productive_signal is not None
        else snapshot.get("first_useful_sign")
    )
    first_useful_sign_check = _briefing_value_check(first_useful_sign)
    inbound_capture_items = [
        {
            "kind": "capture_signal",
            "label": str(item.get("title") or ""),
            "path": str(item.get("source_path") or ""),
            "detail": str((item.get("capture_summary") or {}).get("summary") or ""),
        }
        for item in snapshot.get("recent_signals", [])
        if str((item.get("capture_summary") or {}).get("status") or "") != "missing"
    ]
    compiled_sections = [
        _compiled_section(
            "signal_loop",
            "Signal Loop",
            summary=(
                f"{loop_summary['productive_count']} productive, "
                f"{loop_summary['waiting_count']} waiting, "
                f"{loop_summary['failed_count'] + loop_summary['stalled_count']} blocked/stalled."
            ),
            items=signal_loop_items,
        ),
        _compiled_section(
            "inbound_capture",
            "Inbound Capture",
            summary=(
                f"{len(inbound_capture_items)} recent signals currently expose deterministic inbound capture audit."
                if inbound_capture_items
                else "No recent signals currently carry inbound capture audit."
            ),
            items=inbound_capture_items,
        ),
        _compiled_section(
            "what_changed",
            "What Changed",
            summary=f"{len(changed_items)} changed objects surfaced recently.",
            items=changed_items,
        ),
        _compiled_section(
            "what_matters",
            "What Matters",
            summary=f"{len(what_matters_items)} active topics currently dominate the signal surface.",
            items=what_matters_items,
        ),
        _compiled_section(
            "needs_review",
            "Needs Review",
            summary=f"{len(needs_review_items)} unresolved issues currently deserve attention.",
            items=needs_review_items,
        ),
        _compiled_section(
            "next_reads",
            "Next Reads",
            summary=f"{len(next_read_items)} compiled next-read routes were surfaced from current evidence.",
            items=next_read_items,
        ),
        _compiled_section(
            "next_actions",
            "Next Actions",
            summary=f"{len(next_action_items)} next actions are currently available from the queue and briefing logic.",
            items=next_action_items,
        ),
    ]
    operator_rail = [
        _operator_action(
            "Signals",
            _scoped_path("/signals", pack_name=requested_pack),
            "Open active signal review from the current shell.",
        ),
        _operator_action(
            "Action Queue",
            _scoped_path("/actions", pack_name=requested_pack),
            "Run or inspect queued actions.",
        ),
        _operator_action(
            "Production Browser",
            _scoped_path("/production", pack_name=requested_pack),
            "Inspect production-chain weak points and reach.",
        ),
        _operator_action(
            "Search",
            _scoped_path("/search", pack_name=requested_pack),
            "Jump into freeform search from the current orientation pass.",
        ),
    ]
    payload: dict[str, Any] = {
        "screen": "briefing/intelligence",
        "requested_pack": requested_pack,
        "surface_contract": surface_contract,
        "assembly_contract": assembly_contract,
        "governance_contract": governance_contract,
        **snapshot,
        "first_useful_sign": first_useful_sign,
        "first_useful_sign_check": first_useful_sign_check,
        "loop_summary": loop_summary,
        "operator_rail": operator_rail,
        "compiled_sections": compiled_sections,
        "section_nav": _section_nav_from_compiled_sections(compiled_sections),
    }
    _emit_briefing_reuse(
        vault_dir,
        payload,
        pack=requested_pack or PRIMARY_PACK_NAME,
        consumer_ref="view:briefing",
    )
    return payload


def build_object_page_payload(
    vault_dir: Path | str,
    object_id: str,
    *,
    pack_name: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    research_shell_enabled = _supports_research_shell(pack_name)
    detail = get_object_detail(vault_dir, object_id, pack_name=pack_name)
    neighborhood = get_topic_neighborhood(vault_dir, object_id, pack_name=pack_name)
    review_context = get_review_context(vault_dir, [object_id], pack_name=pack_name) if research_shell_enabled else {}
    neighbor_titles = {item["object_id"]: item["title"] for item in neighborhood["neighbors"]}
    relations = [
        {
            **item,
            "target_title": neighbor_titles.get(item["target_object_id"], item["target_object_id"]),
            "target_path": _scoped_path(
                f"/object?id={quote(str(item['target_object_id']), safe='')}",
                pack_name=requested_pack,
            ),
        }
        for item in detail["relations"]
    ]
    research_links = {
        "events_path": _scoped_path(f"/events?q={quote(object_id, safe='')}", pack_name=requested_pack),
        "contradictions_path": _scoped_path(
            f"/contradictions?q={quote(object_id, safe='')}",
            pack_name=requested_pack,
        ),
        "summaries_path": _scoped_path(
            f"/summaries?q={quote(object_id, safe='')}",
            pack_name=requested_pack,
        ),
        "deep_dives_path": _scoped_path(
            f"/deep-dives?q={quote(object_id, safe='')}",
            pack_name=requested_pack,
        ),
        "atlas_path": _scoped_path(f"/atlas?q={quote(object_id, safe='')}", pack_name=requested_pack),
    } if research_shell_enabled else {
        "events_path": "",
        "contradictions_path": "",
        "summaries_path": "",
        "deep_dives_path": "",
        "atlas_path": "",
    }
    evolution_section = (
        _build_evolution_section(
            vault_dir,
            pack_name=pack_name,
            status="all",
            scoped_object_ids=[object_id],
        )
        if research_shell_enabled
        else {
            "accepted_links": [],
            "rejected_links": [],
            "candidate_items": [],
            "candidate_count": 0,
            "accepted_count": 0,
            "rejected_count": 0,
            "link_types": [],
            "status": "all",
        }
    )
    summary_text = detail["summary"]["summary_text"] if detail["summary"] else ""
    stale_summary_details = (
        list_stale_summaries(
            vault_dir,
            pack_name=pack_name,
            object_ids=[object_id],
            limit=10,
        )
        if research_shell_enabled
        else []
    )
    production_chain = get_object_traceability(vault_dir, object_id, pack_name=pack_name)
    compiled_sections = [
        _compiled_section(
            "current_state",
            "Current State",
            summary=summary_text or "No compiled summary yet.",
            items=[
                {
                    "kind": "summary",
                    "label": detail["object"]["title"],
                    "path": "",
                    "detail": summary_text or "No compiled summary yet.",
                },
                {"kind": "claims", "label": "Claims", "path": "", "detail": f"{len(detail['claims'])} claims"},
                {"kind": "relations", "label": "Relations", "path": "", "detail": f"{len(relations)} relations"},
            ],
        ),
        _compiled_section(
            "why_it_matters",
            "Why It Matters",
            summary=f"{len(detail['contradictions']) if research_shell_enabled else 0} contradictions and {review_context.get('stale_summary_count', 0)} stale summaries shape current maintenance urgency.",
            items=[
                {
                    "kind": "topic",
                    "label": "Explore topic",
                    "path": _scoped_path(f"/topic?id={quote(object_id, safe='')}", pack_name=requested_pack),
                    "detail": "Open the surrounding topic neighborhood.",
                },
                *(
                    [
                        {
                            "kind": "events",
                            "label": "Related events",
                            "path": research_links["events_path"],
                            "detail": "See timeline context for this object.",
                        }
                    ]
                    if research_shell_enabled
                    else []
                ),
            ],
        ),
        _compiled_section(
            "evidence_traceability",
            "Evidence Traceability",
            summary=f"{len(detail['evidence'])} evidence rows, {len(detail['provenance']['source_notes'])} source notes, {len(detail['provenance']['mocs'])} atlas pages.",
            items=[
                {
                    "kind": "evergreen",
                    "label": "Evergreen note",
                    "path": _scoped_path(
                        f"/note?path={quote(detail['provenance']['evergreen_path'], safe='')}",
                        pack_name=requested_pack,
                    )
                    if detail["provenance"]["evergreen_path"]
                    else "",
                    "detail": detail["provenance"]["evergreen_path"] or "No evergreen markdown path",
                },
                *[
                    {
                        "kind": "source_note",
                        "label": item["title"],
                        "path": _scoped_path(f"/note?path={quote(item['path'], safe='')}", pack_name=requested_pack),
                        "detail": item["note_type"],
                    }
                    for item in detail["provenance"]["source_notes"][:3]
                ],
            ],
        ),
        _compiled_section(
            "production_chain",
            "Production Chain",
            summary=str(production_chain.get("chain_summary") or ""),
            items=[
                {
                    "kind": "chain_status",
                    "label": "Chain status",
                    "path": "",
                    "detail": str(production_chain.get("chain_status") or ""),
                },
                {
                    "kind": "missing_stages",
                    "label": "Missing stages",
                    "path": "",
                    "detail": ", ".join(
                        str(item).replace("_", " ")
                        for item in production_chain.get("missing_stages", [])
                    )
                    or "None",
                },
                *[
                    {
                        "kind": "deep_dive",
                        "label": item["title"],
                        "path": _scoped_path(
                            f"/note?path={quote(item['path'], safe='')}",
                            pack_name=requested_pack,
                        ),
                        "detail": "Downstream deep dive",
                    }
                    for item in production_chain["deep_dives"][:2]
                ],
                *[
                    {
                        "kind": "atlas_page",
                        "label": item["title"],
                        "path": _scoped_path(
                            f"/note?path={quote(item['path'], safe='')}",
                            pack_name=requested_pack,
                        ),
                        "detail": "Atlas / MOC reach",
                    }
                    for item in production_chain["atlas_pages"][:2]
                ],
            ],
        ),
        _compiled_section(
            "open_tensions",
            "Open Tensions",
            summary=f"{len(detail['contradictions']) if research_shell_enabled else 0} contradictions and {len(stale_summary_details) if research_shell_enabled else 0} stale-summary signals remain.",
            items=[
                *[
                    {
                        "kind": "contradiction",
                        "label": item["subject_key"],
                        "path": research_links["contradictions_path"],
                        "detail": item["status"],
                    }
                    for item in detail["contradictions"][:3]
                ],
                *[
                    {
                        "kind": "stale_summary",
                        "label": item["title"],
                        "path": research_links["summaries_path"],
                        "detail": ", ".join(item["reason_texts"]),
                    }
                    for item in stale_summary_details[:2]
                ],
            ],
        ),
        _compiled_section(
            "where_to_go_next",
            "Where To Go Next",
            summary="Use the surrounding compiled products to continue reading or review.",
            items=[
                {
                    "kind": "topic",
                    "label": "Topic overview",
                    "path": _scoped_path(f"/topic?id={quote(object_id, safe='')}", pack_name=requested_pack),
                    "detail": "Open the surrounding topic page.",
                },
                *(
                    [
                        {
                            "kind": "events",
                            "label": "Event dossier",
                            "path": research_links["events_path"],
                            "detail": "See event and time context.",
                        },
                        {
                            "kind": "contradictions",
                            "label": "Contradiction review",
                            "path": research_links["contradictions_path"],
                            "detail": "Inspect open conflicts.",
                        },
                    ]
                    if research_shell_enabled
                    else []
                ),
            ],
        ),
    ]
    operator_rail = [
        _operator_action(
            "Topic overview",
            _scoped_path(f"/topic?id={quote(object_id, safe='')}", pack_name=requested_pack),
            "Open the surrounding topic page.",
        ),
        _operator_action(
            "Event dossier" if research_shell_enabled else "Signals",
            research_links["events_path"] if research_shell_enabled else _scoped_path("/signals", pack_name=requested_pack),
            (
                "See timeline context for this object."
                if research_shell_enabled
                else "Open active signal review."
            ),
        ),
        _operator_action(
            "Contradiction review" if research_shell_enabled else "Search",
            research_links["contradictions_path"] if research_shell_enabled else _scoped_path("/search", pack_name=requested_pack),
            (
                "Inspect open contradictions for this object."
                if research_shell_enabled
                else "Search laterally from this object."
            ),
        ),
        _operator_action(
            "Production Browser",
            _scoped_path("/production", pack_name=requested_pack),
            "Inspect downstream production chain state.",
        ),
    ]
    payload: dict[str, Any] = {
        "screen": "object/page",
        "requested_pack": requested_pack,
        "assembly_contract": _assembly_contract("object_brief", pack_name=pack_name),
        "research_shell_enabled": research_shell_enabled,
        **detail,
        "production_chain": production_chain,
        "relations": relations,
        "claim_count": len(detail["claims"]),
        "relation_count": len(relations),
        "contradiction_count": len(detail["contradictions"]) if research_shell_enabled else 0,
        "evidence_count": len(detail["evidence"]),
        "context": {
            "object_kind": detail["object"]["object_kind"],
            "source_slug": detail["object"]["source_slug"],
            "canonical_path": detail["object"]["canonical_path"],
        },
        "provenance": detail["provenance"],
        "review_context": review_context,
        "review_history": list_review_actions(vault_dir, object_ids=[object_id], limit=8) if research_shell_enabled else [],
        "evolution": evolution_section,
        "stale_summary_details": stale_summary_details,
        "open_contradiction_ids": (
            [item["contradiction_id"] for item in detail["contradictions"] if item["status"] == "open"]
            if research_shell_enabled
            else []
        ),
        "links": {
            "topic_path": _scoped_path(f"/topic?id={quote(object_id, safe='')}", pack_name=requested_pack),
            **research_links,
        },
        "operator_rail": operator_rail,
        "compiled_sections": compiled_sections,
        "section_nav": [
            {"href": "#summary", "label": "Summary"},
            *_section_nav_from_compiled_sections(compiled_sections),
            {"href": "#claims", "label": "Claims"},
            {"href": "#relations", "label": "Relations"},
            *(
                [{"href": "#contradictions", "label": "Contradictions"}]
                if research_shell_enabled
                else []
            ),
        ],
    }
    _emit_briefing_reuse(
        vault_dir,
        payload,
        pack=str((detail.get("object") or {}).get("pack") or requested_pack),
        consumer_ref=f"view:object_page:{object_id}",
    )
    return payload


def build_topic_overview_payload(
    vault_dir: Path | str,
    object_id: str,
    *,
    pack_name: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    research_shell_enabled = _supports_research_shell(pack_name)
    neighborhood = get_topic_neighborhood(vault_dir, object_id, pack_name=pack_name)
    detail = get_object_detail(vault_dir, object_id, pack_name=pack_name)
    scoped_object_ids = [object_id, *[item["object_id"] for item in neighborhood["neighbors"]]]
    review_context = (
        get_review_context(
            vault_dir,
            scoped_object_ids,
            pack_name=pack_name,
        )
        if research_shell_enabled
        else {}
    )
    scoped_stale_summaries = (
        list_stale_summaries(
            vault_dir,
            pack_name=pack_name,
            object_ids=scoped_object_ids,
            limit=50,
        )
        if research_shell_enabled
        else []
    )
    scoped_contradictions = (
        [
            item
            for item in list_contradictions(vault_dir, pack_name=pack_name, limit=100)
            if set(item["positive_claim_ids"] + item["negative_claim_ids"])
            and any(claim_id.split("::", 1)[0] in set(scoped_object_ids) for claim_id in item["positive_claim_ids"] + item["negative_claim_ids"])
            and item["status"] == "open"
        ]
        if research_shell_enabled
        else []
    )
    neighbors = [
        {
            **item,
            "object_path": _scoped_path(
                f"/object?id={quote(str(item['object_id']), safe='')}",
                pack_name=requested_pack,
            ),
        }
        for item in neighborhood["neighbors"]
    ]
    production_summary = _build_production_summary(
        vault_dir,
        scoped_object_ids,
        pack_name=pack_name,
    )
    research_links = {
        "events_path": _scoped_path(f"/events?q={quote(object_id, safe='')}", pack_name=requested_pack),
        "contradictions_path": _scoped_path(
            f"/contradictions?q={quote(object_id, safe='')}",
            pack_name=requested_pack,
        ),
        "summaries_path": _scoped_path(
            f"/summaries?q={quote(object_id, safe='')}",
            pack_name=requested_pack,
        ),
        "deep_dives_path": _scoped_path(
            f"/deep-dives?q={quote(object_id, safe='')}",
            pack_name=requested_pack,
        ),
        "atlas_path": _scoped_path(f"/atlas?q={quote(object_id, safe='')}", pack_name=requested_pack),
    } if research_shell_enabled else {
        "events_path": "",
        "contradictions_path": "",
        "summaries_path": "",
        "deep_dives_path": "",
        "atlas_path": "",
    }
    compiled_sections = [
        _compiled_section(
            "current_state",
            "Current State",
            summary=f"{len(neighbors)} neighbors and {len(neighborhood['edges'])} edges define this topic view.",
            items=[
                {
                    "kind": "center_object",
                    "label": detail["object"]["title"],
                    "path": _scoped_path(f"/object?id={quote(object_id, safe='')}", pack_name=requested_pack),
                    "detail": detail["summary"]["summary_text"] if detail["summary"] else "No compiled summary yet.",
                },
                *[
                    {
                        "kind": "neighbor",
                        "label": item["title"],
                        "path": item["object_path"],
                        "detail": "Neighbor in current topic scope",
                    }
                    for item in neighbors[:3]
                ],
            ],
        ),
        _compiled_section(
            "why_it_matters",
            "Why It Matters",
            summary=f"{review_context.get('open_contradiction_count', 0)} contradictions and {review_context.get('stale_summary_count', 0)} stale summaries currently shape this topic.",
            items=[
                *(
                    [
                        {
                            "kind": "events",
                            "label": "Event dossier",
                            "path": research_links["events_path"],
                            "detail": "See time-bounded activity around this topic.",
                        },
                        {
                            "kind": "deep_dives",
                            "label": "Source deep dives",
                            "path": research_links["deep_dives_path"],
                            "detail": "Inspect supporting analysis.",
                        },
                    ]
                    if research_shell_enabled
                    else []
                ),
            ],
        ),
        _compiled_section(
            "evidence_traceability",
            "Evidence Traceability",
            summary=f"{len(detail['provenance']['source_notes'])} source notes and {len(detail['provenance']['mocs'])} atlas pages anchor this topic.",
            items=[
                *[
                    {
                        "kind": "source_note",
                        "label": item["title"],
                        "path": _scoped_path(f"/note?path={quote(item['path'], safe='')}", pack_name=requested_pack),
                        "detail": item["note_type"],
                    }
                    for item in detail["provenance"]["source_notes"][:3]
                ],
                *[
                    {
                        "kind": "atlas_page",
                        "label": item["title"],
                        "path": _scoped_path(f"/note?path={quote(item['path'], safe='')}", pack_name=requested_pack),
                        "detail": "Atlas / MOC",
                    }
                    for item in detail["provenance"]["mocs"][:3]
                ],
            ],
        ),
        _compiled_section(
            "production_chain",
            "Production Chain",
            summary=(
                f"{production_summary['object_count']} objects in scope currently resolve to "
                f"{production_summary['counts']['source_notes']} source notes, "
                f"{production_summary['counts']['deep_dives']} deep dives, and "
                f"{production_summary['counts']['atlas_pages']} atlas pages."
            ),
            items=[
                *[
                    {
                        "kind": "top_deep_dive",
                        "label": item["title"],
                        "path": _scoped_path(
                            f"/note?path={quote(item['path'], safe='')}",
                            pack_name=requested_pack,
                        ),
                        "detail": f"Supports {item['object_count']} objects in this topic scope.",
                    }
                    for item in production_summary["top_deep_dives"][:2]
                ],
                *[
                    {
                        "kind": "top_atlas_page",
                        "label": item["title"],
                        "path": _scoped_path(
                            f"/note?path={quote(item['path'], safe='')}",
                            pack_name=requested_pack,
                        ),
                        "detail": f"Reaches {item['object_count']} objects in this topic scope.",
                    }
                    for item in production_summary["top_atlas_pages"][:2]
                ],
                *[
                    {
                        "kind": "gap_signal",
                        "label": item["label"],
                        "path": _scoped_path(
                            f"/production?q={quote(object_id, safe='')}",
                            pack_name=requested_pack,
                        ),
                        "detail": f"{item['count']} objects in this topic scope.",
                    }
                    for item in production_summary["signals"][:3]
                ],
            ],
        ),
        _compiled_section(
            "open_tensions",
            "Open Tensions",
            summary=f"{len(scoped_contradictions)} open contradictions and {len(scoped_stale_summaries)} stale summaries remain in this topic scope.",
            items=[
                *[
                    {
                        "kind": "contradiction",
                        "label": item["subject_key"],
                        "path": research_links["contradictions_path"],
                        "detail": item["status"],
                    }
                    for item in scoped_contradictions[:3]
                ],
                *[
                    {
                        "kind": "stale_summary",
                        "label": item["title"],
                        "path": research_links["summaries_path"],
                        "detail": ", ".join(item["reason_texts"]),
                    }
                    for item in scoped_stale_summaries[:2]
                ],
            ],
        ),
        _compiled_section(
            "where_to_go_next",
            "Where To Go Next",
            summary="Jump from the topic hub into the most useful next compiled products.",
            items=[
                {
                    "kind": "center_object",
                    "label": "Center object",
                    "path": _scoped_path(f"/object?id={quote(object_id, safe='')}", pack_name=requested_pack),
                    "detail": "Open the canonical object page.",
                },
                *(
                    [
                        {
                            "kind": "contradictions",
                            "label": "Contradictions",
                            "path": research_links["contradictions_path"],
                            "detail": "Review open tensions.",
                        },
                        {
                            "kind": "atlas",
                            "label": "Atlas / MOC",
                            "path": research_links["atlas_path"],
                            "detail": "Open atlas reach.",
                        },
                    ]
                    if research_shell_enabled
                    else []
                ),
            ],
        ),
    ]
    operator_rail = [
        _operator_action(
            "Center object",
            _scoped_path(f"/object?id={quote(object_id, safe='')}", pack_name=requested_pack),
            "Open the canonical object page.",
        ),
        _operator_action(
            "Event dossier" if research_shell_enabled else "Signals",
            research_links["events_path"] if research_shell_enabled else _scoped_path("/signals", pack_name=requested_pack),
            (
                "See time-bounded activity around this topic."
                if research_shell_enabled
                else "Review active shell signals."
            ),
        ),
        _operator_action(
            "Contradictions" if research_shell_enabled else "Search",
            research_links["contradictions_path"] if research_shell_enabled else _scoped_path("/search", pack_name=requested_pack),
            (
                "Review open tensions in topic scope."
                if research_shell_enabled
                else "Search laterally from this topic."
            ),
        ),
        _operator_action(
            "Production Browser",
            _scoped_path("/production", pack_name=requested_pack),
            "Inspect production-chain weak points in the current shell.",
        ),
    ]
    payload: dict[str, Any] = {
        "screen": "overview/topic",
        "requested_pack": requested_pack,
        "assembly_contract": _assembly_contract("topic_overview", pack_name=pack_name),
        "research_shell_enabled": research_shell_enabled,
        **neighborhood,
        "neighbors": neighbors,
        "edge_count": len(neighborhood["edges"]),
        "neighbor_count": len(neighbors),
        "center_summary": detail["summary"]["summary_text"] if detail["summary"] else "",
        "provenance": detail["provenance"],
        "production_summary": production_summary,
        "review_context": review_context,
        "review_history": (
            list_review_actions(
                vault_dir,
                object_ids=scoped_object_ids,
                limit=8,
            )
            if research_shell_enabled
            else []
        ),
        "evolution": (
            _build_evolution_section(
                vault_dir,
                pack_name=pack_name,
                status="all",
                scoped_object_ids=scoped_object_ids,
            )
            if research_shell_enabled
            else {
                "accepted_links": [],
                "rejected_links": [],
                "candidate_items": [],
                "candidate_count": 0,
                "accepted_count": 0,
                "rejected_count": 0,
                "link_types": [],
                "status": "all",
            }
        ),
        "scoped_object_ids": scoped_object_ids,
        "scoped_stale_summary_ids": [item["object_id"] for item in scoped_stale_summaries],
        "scoped_open_contradiction_ids": [item["contradiction_id"] for item in scoped_contradictions],
        "links": {
            "center_object_path": _scoped_path(
                f"/object?id={quote(object_id, safe='')}",
                pack_name=requested_pack,
            ),
            **research_links,
        },
        "operator_rail": operator_rail,
        "compiled_sections": compiled_sections,
        "section_nav": _section_nav_from_compiled_sections(compiled_sections),
    }
    _emit_briefing_reuse(
        vault_dir,
        payload,
        pack=str((neighborhood.get("center") or {}).get("row_pack") or requested_pack),
        consumer_ref=f"view:topic_overview:{object_id}",
    )
    return payload


def _escape_like(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def build_event_dossier_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    query: str | None = None,
    limit: int | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    research_shell_enabled = _supports_research_shell(pack_name)
    effective_limit = DEFAULT_EVENT_DOSSIER_LIMIT if limit is None else limit
    events = [
        _build_timeline_event_item(row)
        for row in list_timeline_events(
            vault_dir,
            pack_name=pack_name,
            query=query,
            limit=effective_limit or DEFAULT_EVENT_DOSSIER_LIMIT,
        )
    ]
    provenance_map = get_object_provenance_map(
        vault_dir,
        [event["object_id"] for event in events],
        pack_name=pack_name,
    )
    scoped_object_ids = [event["object_id"] for event in events]
    review_context = get_review_context(vault_dir, scoped_object_ids, pack_name=pack_name)
    scoped_stale_summaries = list_stale_summaries(
        vault_dir,
        pack_name=pack_name,
        object_ids=scoped_object_ids,
        limit=100,
    )
    scoped_contradictions = [
        item
        for item in list_contradictions(vault_dir, pack_name=pack_name, limit=200)
        if any(claim_id.split("::", 1)[0] in set(scoped_object_ids) for claim_id in item["positive_claim_ids"] + item["negative_claim_ids"])
        and item["status"] == "open"
    ]
    for event in events:
        event["object_path"] = _scoped_path(
            f"/object?id={quote(str(event['object_id']), safe='')}",
            pack_name=requested_pack,
        )
        event["review_links"] = {
            "object_path": event["object_path"],
            "topic_path": _scoped_path(
                f"/topic?id={quote(str(event['object_id']), safe='')}",
                pack_name=requested_pack,
            ),
            "contradictions_path": _scoped_path(
                f"/contradictions?q={quote(str(event['object_id']), safe='')}",
                pack_name=requested_pack,
            ),
            "summaries_path": _scoped_path(
                f"/summaries?q={quote(str(event['object_id']), safe='')}",
                pack_name=requested_pack,
            ),
        }
        event["provenance"] = provenance_map.get(
            event["object_id"],
            {"evergreen_path": "", "source_notes": [], "mocs": []},
        )
    dates = sorted({event["event_date"] for event in events}, reverse=True)
    grouped: dict[str, list[dict[str, Any]]] = {}
    for event in events:
        grouped.setdefault(event["event_date"], []).append(event)
    cluster_sections = [
        {
            "date": date,
            "clusters": _cluster_timeline_events(grouped[date]),
        }
        for date in dates
    ]
    event_type_counts = Counter(event["event_kind"] for event in events)
    row_type_counts = Counter(event["row_type"] for event in events)
    anchor_kind_counts = Counter(event["timeline_anchor_kind"] for event in events)
    semantic_roles = Counter(event["semantic_role"] for event in events)
    compiled_sections = [
        _compiled_section(
            "current_state",
            "Current State",
            summary=f"{len(events)} timeline rows grouped into {sum(len(section['clusters']) for section in cluster_sections)} visible event clusters.",
            items=[
                *[
                    {
                        "kind": "event_cluster",
                        "label": item["title"],
                        "path": item["review_links"]["topic_path"],
                        "detail": f"{item['row_count']} timeline rows",
                    }
                    for section in cluster_sections[:2]
                    for item in section["clusters"][:2]
                ]
            ],
        ),
        _compiled_section(
            "why_it_matters",
            "Why It Matters",
            summary=f"{review_context.get('open_contradiction_count', 0)} contradictions and {review_context.get('stale_summary_count', 0)} stale summaries appear in the visible event scope.",
            items=[
                {"kind": "query", "label": query or "All events", "path": "", "detail": "Current dossier filter scope."},
                {
                    "kind": "contradictions",
                    "label": "Contradiction review",
                    "path": _scoped_path(f"/contradictions?q={quote(query or '', safe='')}", pack_name=requested_pack) if query else _scoped_path("/contradictions", pack_name=requested_pack),
                    "detail": "Inspect tensions in the visible event scope.",
                },
            ],
        ),
        _compiled_section(
            "evidence_traceability",
            "Evidence Traceability",
            summary=f"{len({note['slug'] for event in events for note in event['provenance']['source_notes']})} source notes and {len({moc['slug'] for event in events for moc in event['provenance']['mocs']})} atlas pages anchor the visible event scope.",
            items=[
                *[
                    {
                        "kind": "source_note",
                        "label": note["title"],
                        "path": _scoped_path(f"/note?path={quote(note['path'], safe='')}", pack_name=requested_pack),
                        "detail": note["note_type"],
                    }
                    for event in events[:3]
                    for note in event["provenance"]["source_notes"][:1]
                ]
            ],
        ),
        _compiled_section(
            "open_tensions",
            "Open Tensions",
            summary=f"{len(scoped_contradictions)} contradictions and {len(scoped_stale_summaries)} stale summaries remain visible in this dossier.",
            items=[
                *[
                    {
                        "kind": "contradiction",
                        "label": item["subject_key"],
                        "path": _scoped_path(f"/contradictions?q={quote(item['subject_key'], safe='')}", pack_name=requested_pack),
                        "detail": item["status"],
                    }
                    for item in scoped_contradictions[:3]
                ],
                *[
                    {
                        "kind": "stale_summary",
                        "label": item["title"],
                        "path": item["object_path"],
                        "detail": ", ".join(item["reason_texts"]),
                    }
                    for item in scoped_stale_summaries[:2]
                ],
            ],
        ),
        _compiled_section(
            "where_to_go_next",
            "Where To Go Next",
            summary="Continue from the timeline into object, contradiction, and summary review surfaces.",
            items=[
                *[
                    {
                        "kind": "topic",
                        "label": item["title"],
                        "path": item["review_links"]["topic_path"],
                        "detail": "Open topic context for this event cluster.",
                    }
                    for item in events[:3]
                ]
            ],
        ),
    ]
    operator_rail = [
        _operator_action(
            "Production Browser",
            _scoped_path("/production", pack_name=requested_pack),
            "Inspect production chains behind the visible timeline scope.",
        ),
        _operator_action(
            "Contradictions",
            _scoped_path(
                f"/contradictions?q={quote(query or '', safe='')}",
                pack_name=requested_pack,
            )
            if query
            else _scoped_path("/contradictions", pack_name=requested_pack),
            "Review contradiction rows for the current dossier scope.",
        ),
        _operator_action(
            "Signals",
            _scoped_path("/signals", pack_name=requested_pack),
            "Open the active signal queue.",
        ),
        _operator_action(
            "Clusters" if research_shell_enabled else "Search",
            _scoped_path("/clusters" if research_shell_enabled else "/search", pack_name=requested_pack),
            (
                "Explore graph clusters connected to current work."
                if research_shell_enabled
                else "Search laterally from the current shell."
            ),
        ),
    ]
    return {
        "screen": "event/dossier",
        "requested_pack": requested_pack,
        "assembly_contract": _assembly_contract("event_dossier", pack_name=pack_name),
        "events": events,
        "event_count": len(events),
        "cluster_count": sum(len(section["clusters"]) for section in cluster_sections),
        "dates": dates,
        "cluster_sections": cluster_sections,
        "event_type_counts": dict(event_type_counts),
        "limit": effective_limit,
        "is_limited": effective_limit is not None,
        "timeline_contract": {
            "timeline_kind": "dated_note_projection",
            "grouping_kind": "object_date_rollup",
            "row_type_counts": dict(row_type_counts),
            "anchor_kind_counts": dict(anchor_kind_counts),
            "semantic_roles": dict(semantic_roles),
            "event_vs_note_explanation": (
                "Event Dossier groups dated note and heading projections by object and date; "
                "it is not a canonical event entity store."
            ),
        },
        "production_summary": _build_production_summary(
            vault_dir,
            scoped_object_ids,
            pack_name=pack_name,
        ),
        "review_context": review_context,
        "review_history": list_review_actions(vault_dir, object_ids=scoped_object_ids, limit=8),
        "scoped_object_ids": list(dict.fromkeys(scoped_object_ids)),
        "scoped_stale_summary_ids": [item["object_id"] for item in scoped_stale_summaries],
        "scoped_open_contradiction_ids": [item["contradiction_id"] for item in scoped_contradictions],
        "model_notes": [
            "Event Dossier is a timeline over dated notes projected from indexed pages, not a separate event entity system.",
            "page_date rows come from note-level dates; heading_date rows come from dated section headings.",
        ],
        "operator_rail": operator_rail,
        "query": query or "",
        "compiled_sections": compiled_sections,
        "section_nav": _section_nav_from_compiled_sections(compiled_sections),
    }


def build_evolution_browser_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    query: str | None = None,
    status: str = "all",
    link_type: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    evolution = _build_evolution_section(
        vault_dir,
        pack_name=pack_name,
        query=query,
        link_type=link_type,
        status=status,
    )
    type_counts = Counter(
        item["link_type"]
        for item in [
            *evolution["candidate_items"],
            *evolution["accepted_links"],
            *evolution["rejected_links"],
        ]
    )
    return {
        "screen": "evolution/browser",
        "requested_pack": requested_pack,
        "query": query or "",
        "status": status,
        "link_type": link_type or "",
        "items": evolution["candidate_items"],
        "candidate_items": evolution["candidate_items"],
        "accepted_links": evolution["accepted_links"],
        "rejected_links": evolution["rejected_links"],
        "candidate_count": evolution["candidate_count"],
        "accepted_count": evolution["accepted_count"],
        "rejected_count": evolution["rejected_count"],
        "count": evolution["candidate_count"] + evolution["accepted_count"] + evolution["rejected_count"],
        "type_counts": dict(type_counts),
        "link_types": evolution["link_types"],
    }


def build_cluster_browser_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    query: str | None = None,
    limit: int = DEFAULT_TRACEABILITY_BROWSER_LIMIT,
) -> dict[str, Any]:
    items = list_graph_clusters(vault_dir, pack_name=pack_name, query=query, limit=limit)
    cluster_provenance_index = _build_cluster_provenance_index(vault_dir, items)
    cluster_kind_counts = Counter(item["cluster_kind"] for item in items)
    largest_cluster_size = max((int(item["member_count"]) for item in items), default=0)
    enriched_items = []
    for item in items:
        requested_pack = pack_name or str(item["pack"])
        summary = build_cluster_summary_payload(
            vault_dir,
            cluster_id=str(item["cluster_id"]),
            pack_name=requested_pack,
            cluster_rows=items,
            cluster_provenance_index=cluster_provenance_index,
        )
        review_context = summary["review_context"]
        dominant_edge_kind = next(
            iter(
                sorted(
                    summary["edge_kind_counts"].items(),
                    key=lambda pair: (-pair[1], pair[0]),
                )
            ),
            None,
        )
        priority_score = (
            review_context["open_contradiction_count"] * 100
            + review_context["stale_summary_count"] * 40
            + int(item["member_count"]) * 10
            + int(summary["edge_count"]) * 3
            + review_context["source_note_count"]
            + review_context["moc_count"]
        )
        if summary["reading_routes"]:
            priority_score += 15
        if review_context["open_contradiction_count"] > 0 or review_context["stale_summary_count"] > 0:
            priority_band = "attention"
            priority_reason = (
                f"{review_context['open_contradiction_count']} open contradictions, "
                f"{review_context['stale_summary_count']} stale summaries"
            )
        elif dominant_edge_kind is not None:
            priority_band = "active"
            priority_reason = f"dominant edge kind {dominant_edge_kind[0]} ({dominant_edge_kind[1]})"
        else:
            priority_band = "reference"
            priority_reason = f"{review_context['source_note_count']} source notes in scope"
        strongest_related = summary["related_clusters"][0] if summary["related_clusters"] else None
        top_reading_route = summary["reading_routes"][0] if summary["reading_routes"] else None
        enriched_items.append(
            {
                **item,
                "row_pack": str(item.get("row_pack") or item["pack"]),
                "pack": requested_pack,
                "detail_path": summary["cluster"]["detail_path"],
                "center_object_path": summary["cluster"]["center_object_path"],
                "member_links": summary["cluster"]["member_links"],
                "display_title": summary["display_title"],
                "relation_pattern_preview": summary["relation_pattern_preview"],
                "related_cluster_count": len(summary["related_clusters"]),
                "related_cluster_preview": ", ".join(
                    related["display_title"] for related in summary["related_clusters"][:2]
                ),
                "neighborhood_score": strongest_related["score"] if strongest_related else 0,
                "neighborhood_reason": strongest_related["reason"] if strongest_related else "",
                "neighborhood_band": strongest_related["bridge_band"] if strongest_related else "",
                "neighborhood_bridge_kind": strongest_related["bridge_kind"] if strongest_related else "",
                "next_read_title": strongest_related["display_title"] if strongest_related else "",
                "next_read_path": strongest_related["detail_path"] if strongest_related else "",
                "next_read_reason": strongest_related["reason"] if strongest_related else "",
                "top_reading_route_kind": top_reading_route["route_kind"] if top_reading_route else "",
                "top_reading_route_title": top_reading_route["display_title"] if top_reading_route else "",
                "top_reading_route_reason": top_reading_route["route_reason"] if top_reading_route else "",
                "has_reading_route": bool(top_reading_route),
                "reading_intent_count": len(summary["reading_routes"]),
                "reading_intent_preview": ", ".join(
                    route["display_name"] for route in summary["reading_routes"]
                ),
                "summary_bullets": summary["summary_bullets"],
                "structural_label": summary["structural_label"],
                "edge_kind_counts": summary["edge_kind_counts"],
                "edge_summary_items": summary["edge_summary_items"],
                "edge_count": summary["edge_count"],
                "relation_pattern_items": summary["relation_pattern_items"],
                "review_context": summary["review_context"],
                "open_contradictions": summary["open_contradictions"],
                "stale_summaries": summary["stale_summaries"],
                "related_clusters": summary["related_clusters"],
                "related_cluster_groups": summary["related_cluster_groups"],
                "reading_routes": summary["reading_routes"],
                "next_read_cluster": summary["next_read_cluster"],
                "top_source_notes": summary["top_source_notes"],
                "top_mocs": summary["top_mocs"],
                "object_kind_counts": summary["object_kind_counts"],
                "priority_score": priority_score,
                "priority_band": priority_band,
                "priority_reason": priority_reason,
                "top_summary_bullet": summary["summary_bullets"][0] if summary["summary_bullets"] else "",
                "dominant_edge_kind": dominant_edge_kind[0] if dominant_edge_kind is not None else "",
            }
        )
    enriched_items.sort(
        key=lambda item: (
            -int(item["priority_score"]),
            str(item["label"]).lower(),
            str(item["cluster_id"]),
        )
    )
    return {
        "screen": "graph/clusters",
        "requested_pack": pack_name or "",
        "query": query or "",
        "limit": limit,
        "is_limited": True,
        "items": enriched_items,
        "count": len(enriched_items),
        "cluster_kind_counts": dict(cluster_kind_counts),
        "largest_cluster_size": largest_cluster_size,
        "model_notes": [
            "Graph clusters currently come from pack-owned graph seed projections, not from a final semantic clustering model.",
            "Current research-tech clusters are relation/contradiction connected components over pack-scoped truth rows.",
        ],
    }


def build_cluster_detail_payload(
    vault_dir: Path | str,
    *,
    cluster_id: str,
    pack_name: str | None = None,
    cluster_rows: list[dict[str, Any]] | None = None,
    cluster_provenance_index: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    detail = get_graph_cluster_detail(vault_dir, cluster_id, pack_name=pack_name)
    cluster = detail["cluster"]
    requested_pack = pack_name or str(cluster["pack"])
    member_index = {str(member["object_id"]): member for member in cluster["members"]}
    detail_path = (
        f"/cluster?id={quote(str(cluster['cluster_id']), safe='')}"
        f"&pack={quote(requested_pack, safe='')}"
    )
    enriched_cluster = {
        **cluster,
        "detail_path": detail_path,
        "center_object_path": _scoped_path(
            f"/object?id={quote(str(cluster['center_object_id']), safe='')}",
            pack_name=requested_pack,
        ),
        "member_links": [
            {
                **member,
                "path": _scoped_path(
                    f"/object?id={quote(str(member['object_id']), safe='')}",
                    pack_name=requested_pack,
                ),
            }
            for member in cluster["members"]
        ],
    }
    enriched_edges = [
        {
            **edge,
            "source_title": member_index.get(str(edge["source_object_id"]), {}).get(
                "title",
                str(edge["source_object_id"]),
            ),
            "target_title": member_index.get(str(edge["target_object_id"]), {}).get(
                "title",
                str(edge["target_object_id"]),
            ),
            "source_path": _scoped_path(
                f"/object?id={quote(str(edge['source_object_id']), safe='')}",
                pack_name=requested_pack,
            ),
            "target_path": _scoped_path(
                f"/object?id={quote(str(edge['target_object_id']), safe='')}",
                pack_name=requested_pack,
            ),
        }
        for edge in detail["edges"]
    ]
    sections = _build_cluster_surface_sections(
        vault_dir,
        cluster=enriched_cluster,
        edges=enriched_edges,
        requested_pack=requested_pack,
        cluster_rows=cluster_rows,
        cluster_provenance_index=cluster_provenance_index,
    )

    return {
        "screen": "graph/cluster-detail",
        "requested_pack": requested_pack,
        "cluster": enriched_cluster,
        "browser_path": f"/clusters?pack={quote(requested_pack, safe='')}",
        "edges": enriched_edges,
        **sections,
        "model_notes": [
            "Cluster detail currently reflects pack-owned graph seed structure, not a final semantic subgraph model.",
            "Edges are filtered to the cluster's own member set inside the requested pack projection.",
        ],
    }


def build_contradiction_browser_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    status: str | None = None,
    query: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    raw_items = list_contradictions(vault_dir, pack_name=pack_name, status=status, query=query)
    provenance_map = get_object_provenance_map(
        vault_dir,
        _object_ids_from_claim_ids(
            *(
                item["positive_claim_ids"] + item["negative_claim_ids"]
                for item in raw_items
            )
        ),
        pack_name=pack_name,
    )
    items = []
    for item in raw_items:
        object_ids = _object_ids_from_claim_ids(item["positive_claim_ids"], item["negative_claim_ids"])
        source_notes: dict[str, dict[str, Any]] = {}
        mocs: dict[str, dict[str, Any]] = {}
        object_titles: dict[str, str] = {}
        for object_id in object_ids:
            provenance = provenance_map.get(
                object_id,
                {"title": object_id, "evergreen_path": "", "source_notes": [], "mocs": []},
            )
            object_titles[object_id] = provenance["title"]
            for note in provenance["source_notes"]:
                source_notes.setdefault(note["slug"], note)
            for moc in provenance["mocs"]:
                mocs.setdefault(moc["slug"], moc)
        items.append(
            {
                **item,
                "object_ids": object_ids,
                "object_titles": object_titles,
                "object_links": [
                    {
                        "object_id": object_id,
                        "path": _scoped_path(
                            f"/object?id={quote(object_id, safe='')}",
                            pack_name=requested_pack,
                        ),
                    }
                    for object_id in object_ids
                ],
                "provenance": {
                    "source_notes": list(source_notes.values()),
                    "mocs": list(mocs.values()),
                },
            }
    )
    status_counts = Counter(item["status"] for item in items)
    compiled_sections = [
        _compiled_section(
            "current_state",
            "Current State",
            summary=f"{len(items)} contradiction rows are currently visible, with {status_counts.get('open', 0)} still open.",
            items=[
                *[
                    {
                        "kind": "contradiction",
                        "label": item["subject_key"],
                        "path": _scoped_path(f"/contradictions?q={quote(item['subject_key'], safe='')}", pack_name=requested_pack),
                        "detail": item["status"],
                    }
                    for item in items[:4]
                ]
            ],
        ),
        _compiled_section(
            "why_it_matters",
            "Why It Matters",
            summary=f"{len({object_id for item in items for object_id in item['object_ids']})} objects and {len({note['slug'] for item in items for note in item['provenance']['source_notes']})} source notes are affected by the visible contradiction scope.",
            items=[
                {"kind": "filter", "label": status or "all", "path": "", "detail": "Current contradiction filter."},
                {"kind": "query", "label": query or "all", "path": "", "detail": "Current query scope."},
            ],
        ),
        _compiled_section(
            "evidence_traceability",
            "Evidence Traceability",
            summary="Contradictions are anchored by ranked evidence and provenance across source notes and atlas pages.",
            items=[
                *[
                    {
                        "kind": "source_note",
                        "label": note["title"],
                        "path": _scoped_path(f"/note?path={quote(note['path'], safe='')}", pack_name=requested_pack),
                        "detail": note["note_type"],
                    }
                    for item in items[:3]
                    for note in item["provenance"]["source_notes"][:1]
                ]
            ],
        ),
        _compiled_section(
            "open_tensions",
            "Open Tensions",
            summary=f"{status_counts.get('open', 0)} open rows still require review or dismissal.",
            items=[
                *[
                    {
                        "kind": "open_contradiction",
                        "label": item["subject_key"],
                        "path": _scoped_path(f"/contradictions?q={quote(item['subject_key'], safe='')}", pack_name=requested_pack),
                        "detail": item["status_explanation"],
                    }
                    for item in items[:4]
                    if item["status"] == "open"
                ]
            ],
        ),
        _compiled_section(
            "where_to_go_next",
            "Where To Go Next",
            summary="Route from contradiction review into object pages and downstream maintenance.",
            items=[
                *[
                    {
                        "kind": "object",
                        "label": item["object_titles"].get(link["object_id"], link["object_id"]),
                        "path": link["path"],
                        "detail": "Open affected object page.",
                    }
                    for item in items[:2]
                    for link in item["object_links"][:2]
                ]
            ],
        ),
    ]
    operator_rail = [
        _operator_action(
            "Signals",
            _scoped_path("/signals", pack_name=requested_pack),
            "Open active signals for related maintenance entry points.",
        ),
        _operator_action(
            "Action Queue",
            _scoped_path("/actions", pack_name=requested_pack),
            "Inspect queued or failed execution work.",
        ),
        _operator_action(
            "Production Browser",
            _scoped_path("/production", pack_name=requested_pack),
            "Trace production gaps behind the visible contradictions.",
        ),
        _operator_action(
            "Events",
            _scoped_path("/events", pack_name=requested_pack),
            "Compare contradiction scope against the timeline surface.",
        ),
    ]
    return {
        "screen": "truth/contradictions",
        "requested_pack": requested_pack,
        "assembly_contract": _assembly_contract("contradiction_view", pack_name=pack_name),
        "items": items,
        "count": len(items),
        "open_count": status_counts.get("open", 0),
        "resolved_count": sum(count for status, count in status_counts.items() if status != "open"),
        "scope_summary": {
            "item_count": len(items),
            "object_count": len({object_id for item in items for object_id in item["object_ids"]}),
            "source_note_count": len(
                {
                    note["slug"]
                    for item in items
                    for note in item["provenance"]["source_notes"]
                }
            ),
        },
        "detection_contract": {
            "model": "page_summary_polarity",
            "confidence": "heuristic",
            "polarity_semantics": "Positive and negative claim sets are compared within the same contradiction subject scope.",
            "evidence_semantics": "Ranked evidence is assembled from claim_evidence rows attached to both polarity sides.",
            "status_buckets": {
                "open": status_counts.get("open", 0),
                "reviewed": sum(count for row_status, count in status_counts.items() if row_status != "open"),
            },
            "status_explanations": CONTRADICTION_STATUS_EXPLANATIONS,
        },
        "detection_notes": [
            "Contradictions are currently detected from page_summary claim polarity, not from full semantic contradiction analysis.",
            "Zero results do not prove consistency; they usually mean the current heuristic did not detect a conflict.",
            CONTRADICTION_HEURISTIC_NOTE,
        ],
        "empty_state": "Zero results usually means the current heuristic did not detect a conflict, not that the vault is globally contradiction-free.",
        "operator_rail": operator_rail,
        "status": status or "",
        "query": query or "",
        "compiled_sections": compiled_sections,
        "section_nav": _section_nav_from_compiled_sections(compiled_sections),
    }


def _build_timeline_event_item(row: tuple[Any, ...] | dict[str, Any]) -> dict[str, Any]:
    if isinstance(row, dict):
        payload = json.loads(str(row.get("payload_json") or "{}"))
        event_date = str(row.get("event_date") or "")
        event_type = str(row.get("event_type") or "")
        heading = str(row.get("heading") or "").strip()
        object_id = str(row.get("object_id") or "")
        title = str(row.get("title") or object_id)
        summary_text = str(row.get("summary_text") or "")
        row_pack = str(row.get("row_pack") or "")
    else:
        payload = json.loads(row[3] or "{}")
        event_date = str(row[0] or "")
        event_type = str(row[1])
        heading = str(row[2] or "").strip()
        object_id = str(row[4])
        title = str(row[5])
        summary_text = str(row[6] or "")
        row_pack = ""
    if event_type == "page_date":
        timeline_anchor_kind = "note"
        timeline_anchor_label = str(payload.get("title") or title)
        semantic_role = "note_date_projection"
        event_kind = "dated_note"
        event_label = "Dated Note"
    else:
        timeline_anchor_kind = "heading"
        timeline_anchor_label = heading or str(payload.get("title") or title)
        semantic_role = "heading_date_projection"
        event_kind = "dated_heading"
        event_label = "Dated Heading"
    return {
        "event_date": event_date,
        "event_type": event_type,
        "row_type": event_type,
        "event_kind": event_kind,
        "event_label": event_label,
        "semantic_role": semantic_role,
        "timeline_anchor_kind": timeline_anchor_kind,
        "timeline_anchor_label": timeline_anchor_label,
        "object_id": object_id,
        "title": title,
        "summary_text": summary_text,
        "row_pack": row_pack,
    }


def _cluster_timeline_events(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    clusters: dict[tuple[str, str], dict[str, Any]] = {}
    for event in events:
        key = (str(event["event_date"]), str(event["object_id"]))
        cluster = clusters.setdefault(
            key,
            {
                "event_date": event["event_date"],
                "object_id": event["object_id"],
                "title": event["title"],
                "object_path": event["object_path"],
                "summary_text": event["summary_text"],
                "review_links": event["review_links"],
                "provenance": event["provenance"],
                "row_count": 0,
                "row_types": [],
                "event_labels": [],
                "semantic_roles": [],
                "timeline_anchor_labels": [],
                "grouping_kind": "object_date_rollup",
                "event_vs_note_explanation": (
                    "This cluster groups timeline rows for the same object and date; "
                    "it is a dossier rollup, not a canonical event entity."
                ),
            },
        )
        cluster["row_count"] += 1
        for field, value in (
            ("row_types", event["row_type"]),
            ("event_labels", event["event_label"]),
            ("semantic_roles", event["semantic_role"]),
            ("timeline_anchor_labels", event["timeline_anchor_label"]),
        ):
            if value not in cluster[field]:
                cluster[field].append(value)
    for cluster in clusters.values():
        cluster["row_types"] = sorted(cluster["row_types"])
        cluster["semantic_roles"] = sorted(cluster["semantic_roles"])
    return sorted(clusters.values(), key=lambda item: (str(item["event_date"]), str(item["object_id"])))


def build_truth_dashboard_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    runtime = get_runtime_status(vault_dir)
    objects = build_objects_index_payload(vault_dir, limit=12, offset=0, pack_name=pack_name)
    signals = build_signal_browser_payload(vault_dir, pack_name=pack_name)
    production = build_production_browser_payload(vault_dir, pack_name=pack_name)
    production_weak_points = production["weak_points"]
    research_overview_supported = _supports_research_shell(pack_name)
    if research_overview_supported:
        contradictions = build_contradiction_browser_payload(vault_dir, pack_name=pack_name)
        events = build_event_dossier_payload(vault_dir, pack_name=pack_name, limit=8)
        stale_summaries = build_stale_summary_browser_payload(vault_dir, pack_name=pack_name)
        evolution = build_evolution_browser_payload(vault_dir, pack_name=pack_name, status="all")
    else:
        contradictions = {
            "count": 0,
            "open_count": 0,
            "items": [],
            "browser_path": _scoped_path("/contradictions", pack_name=requested_pack),
        }
        events = {
            "count": 0,
            "items": [],
            "dates": [],
            "browser_path": _scoped_path("/events", pack_name=requested_pack),
        }
        stale_summaries = {
            "count": 0,
            "items": [],
            "browser_path": _scoped_path("/summaries", pack_name=requested_pack),
        }
        evolution = {
            "candidate_count": 0,
            "accepted_count": 0,
            "items": [],
        }
    priorities: list[dict[str, Any]] = []
    if research_overview_supported:
        for item in contradictions["items"][:4]:
            priorities.append(
                {
                    "kind": "contradiction",
                    "label": item["subject_key"],
                    "path": _scoped_path(
                        f"/contradictions?q={quote(str(item['subject_key']), safe='')}",
                        pack_name=requested_pack,
                    ),
                    "detail": f"{len(item['object_ids'])} objects in scope",
                }
            )
        for item in stale_summaries["items"][:4]:
            priorities.append(
                {
                    "kind": "stale_summary",
                    "label": item["title"],
                    "path": item["object_path"],
                    "detail": ", ".join(item["reason_codes"]),
                }
            )
    else:
        for item in signals["items"][:4]:
            priorities.append(
                {
                    "kind": item["signal_type"],
                    "label": item["title"],
                    "path": item["source_path"],
                    "detail": item["detail"],
                }
            )
    for item in production_weak_points[:4]:
        priorities.append(
            {
                "kind": "production_gap",
                "label": item["title"],
                "path": _scoped_path(
                    f"/note?path={quote(item['note_path'], safe='')}",
                    pack_name=requested_pack,
                ),
                "detail": item["detail"],
            }
        )
    orientation = build_briefing_payload(vault_dir, pack_name=pack_name)
    entry_sections = [
        _compiled_section(
            "what_changed_recently",
            "What Changed Recently",
            summary=f"{orientation.get('changed_object_count', 0)} changed objects and {orientation.get('recent_signal_count', 0)} recent signals surfaced.",
            items=[
                *[
                    {
                        "kind": "changed_object",
                        "label": item["title"],
                        "path": item["path"],
                        "detail": f"Changed object · {item['object_id']}",
                    }
                    for item in orientation.get("changed_objects", [])[:4]
                ]
            ],
        ),
        _compiled_section(
            "important_right_now",
            "Important Right Now",
            summary=f"{len(orientation.get('priority_items', []))} priority items are currently surfaced.",
            items=[
                *[
                    {
                        "kind": str(item["kind"]),
                        "label": str(item["title"]),
                        "path": str(item["path"]),
                        "detail": str(item["detail"]),
                    }
                    for item in orientation.get("priority_items", [])[:4]
                ]
            ],
        ),
        _compiled_section(
            "deserves_review",
            "Deserves Review",
            summary=f"{contradictions['open_count'] if research_overview_supported else signals['count']} review-oriented items are currently in scope.",
            items=(
                [
                    {
                        "kind": "contradiction",
                        "label": item["subject_key"],
                        "path": _scoped_path(
                            f"/contradictions?q={quote(str(item['subject_key']), safe='')}",
                            pack_name=requested_pack,
                        ),
                        "detail": f"{len(item['object_ids'])} objects in scope",
                    }
                    for item in contradictions["items"][:4]
                ]
                if research_overview_supported
                else [
                    {
                        "kind": str(item["signal_type"]),
                        "label": str(item["title"]),
                        "path": str(item["source_path"]),
                        "detail": str(item["detail"]),
                    }
                    for item in signals["items"][:4]
                ]
            ),
        ),
        _compiled_section(
            "recommended_next_steps",
            "Recommended Next Steps",
            summary="Start with the orientation brief, then move into the highest-signal compiled surfaces.",
            items=[
                {
                    "kind": "orientation",
                    "label": "Orientation Brief",
                    "path": _scoped_path("/briefing", pack_name=requested_pack),
                    "detail": "Open the current knowledge entry product.",
                },
                {
                    "kind": "signals",
                    "label": "Signals",
                    "path": _scoped_path("/signals", pack_name=requested_pack),
                    "detail": "Review current active signals.",
                },
                {
                    "kind": "production",
                    "label": "Production",
                    "path": _scoped_path("/production", pack_name=requested_pack),
                    "detail": "Inspect production weak points.",
                },
                *(
                    [
                        {
                            "kind": "graph",
                            "label": "Clusters",
                            "path": _scoped_path("/clusters", pack_name=requested_pack),
                            "detail": "Explore graph clusters.",
                        }
                    ]
                    if research_overview_supported
                    else []
                ),
            ],
        ),
    ]
    workflow_groups = _build_dashboard_workflow_groups(
        requested_pack=requested_pack,
        research_overview_supported=research_overview_supported,
    )
    return {
        "screen": "truth/dashboard",
        "requested_pack": requested_pack,
        "research_overview": {
            "status": "supported" if research_overview_supported else "shared_shell_only",
            "reason": (
                "Research-specific overview surfaces are available because this pack resolves through research-tech."
                if research_overview_supported
                else "This pack currently gets the shared home shell only; research-specific overview panels stay hidden until the pack defines its own equivalents."
            ),
        },
        "objects": {
            "count": objects["total_count"],
            "items": objects["items"],
        },
        "contradictions": {
            "count": contradictions["count"],
            "open_count": contradictions["open_count"],
            "items": contradictions["items"][:8],
            "browser_path": _scoped_path("/contradictions", pack_name=requested_pack),
        },
        "events": {
            "count": events["event_count"],
            "items": events["events"][:8],
            "dates": events["dates"],
            "browser_path": _scoped_path("/events", pack_name=requested_pack),
        },
        "stale_summaries": {
            "count": stale_summaries["count"],
            "items": stale_summaries["items"][:8],
            "browser_path": _scoped_path("/summaries", pack_name=requested_pack),
        },
        "evolution": {
            "candidate_count": evolution["candidate_count"],
            "accepted_count": evolution["accepted_count"],
            "items": evolution["candidate_items"][:6],
        },
        "production": {
            **production,
            "browser_path": _scoped_path("/production", pack_name=requested_pack),
            "weak_point_count": len(production_weak_points),
        },
        "signals": {
            **signals,
            "items": signals["items"][:8],
            "browser_path": _scoped_path("/signals", pack_name=requested_pack),
        },
        "runtime": runtime,
        "orientation": orientation,
        "workflow_groups": workflow_groups,
        "entry_sections": entry_sections,
        "recent_review_actions": list_review_actions(vault_dir, limit=8),
        "priorities": priorities[:8],
    }


def build_runtime_home_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    runtime = get_runtime_status(vault_dir)
    research_overview_supported = _supports_research_shell(pack_name)
    try:
        objects = build_objects_index_payload(vault_dir, limit=8, offset=0, pack_name=pack_name)
    except (OSError, sqlite3.Error):
        objects = {
            "total_count": 0,
            "items": [],
            "error": "object_index_unavailable",
        }
    entry_sections: list[dict[str, Any]] = []
    return {
        "screen": "truth/runtime-home",
        "requested_pack": requested_pack,
        "runtime": runtime,
        "research_overview": {
            "status": "supported" if research_overview_supported else "shared_shell_only",
            "reason": (
                "Research-specific overview surfaces are available because this pack resolves through research-tech."
                if research_overview_supported
                else "This pack currently gets the shared home shell only; research-specific overview panels stay hidden until the pack defines its own equivalents."
            ),
        },
        "workflow_groups": _build_dashboard_workflow_groups(
            requested_pack=requested_pack,
            research_overview_supported=research_overview_supported,
        ),
        "entry_sections": entry_sections,
        "objects": {
            "count": objects["total_count"],
            "total_count": objects["total_count"],
            "items": objects["items"],
            **({"error": objects["error"]} if objects.get("error") else {}),
        },
        "orientation": {
            "assembly_contract": _assembly_contract("orientation_brief", pack_name=pack_name),
            "governance_contract": describe_governance_contract(pack_name=pack_name),
        },
        "signals": {
            "count": 0,
            "items": [],
            "browser_path": _scoped_path("/signals", pack_name=requested_pack),
            "surface_contract": describe_observation_surface_contract(pack_name=pack_name, surface_kind="signals"),
        },
        "production": {
            "weak_points": [],
            "weak_point_count": 0,
            "browser_path": _scoped_path("/production", pack_name=requested_pack),
            "surface_contract": describe_observation_surface_contract(
                pack_name=pack_name,
                surface_kind="production_chains",
            ),
        },
        "contradictions": {
            "count": 0,
            "open_count": 0,
            "items": [],
            "browser_path": _scoped_path("/contradictions", pack_name=requested_pack),
        },
        "events": {
            "count": 0,
            "items": [],
            "dates": [],
            "browser_path": _scoped_path("/events", pack_name=requested_pack),
        },
        "stale_summaries": {
            "count": 0,
            "items": [],
            "browser_path": _scoped_path("/summaries", pack_name=requested_pack),
        },
        "evolution": {
            "candidate_count": 0,
            "accepted_count": 0,
            "items": [],
        },
        "recent_review_actions": [],
        "priorities": [],
        "mode": "runtime_first",
    }


def build_objects_index_payload(
    vault_dir: Path | str,
    *,
    limit: int = 100,
    offset: int = 0,
    query: str | None = None,
    pack_name: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    items = [
        {
            **item,
            "object_path": _scoped_path(
                f"/object?id={quote(str(item['object_id']), safe='')}",
                pack_name=requested_pack,
            ),
        }
        for item in list_objects(vault_dir, limit=limit, offset=offset, query=query, pack_name=pack_name)
    ]
    total_count = count_objects(vault_dir, query=query, pack_name=pack_name)
    return {
        "screen": "objects/index",
        "requested_pack": requested_pack,
        "items": items,
        "count": len(items),
        "total_count": total_count,
        "limit": limit,
        "offset": offset,
        "query": query or "",
    }


def build_atlas_browser_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    query: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    items = list_atlas_memberships(
        vault_dir,
        pack_name=pack_name,
        query=query,
        limit=DEFAULT_TRACEABILITY_BROWSER_LIMIT,
    )
    derivations = list_deep_dive_derivations(
        vault_dir,
        pack_name=pack_name,
        limit=DEFAULT_TRACEABILITY_BROWSER_LIMIT,
    )
    object_to_deep_dives: dict[str, dict[str, dict[str, str]]] = {}
    object_to_source_notes: dict[str, dict[str, dict[str, str]]] = {}
    for item in derivations:
        source_notes = get_note_traceability(vault_dir, note_path=item["path"], pack_name=pack_name)["source_notes"]
        for derived in item["derived_objects"]:
            object_to_deep_dives.setdefault(derived["object_id"], {})[item["slug"]] = {
                "slug": item["slug"],
                "title": item["title"],
                "note_type": "deep_dive",
                "path": item["path"],
            }
            object_to_source_notes.setdefault(derived["object_id"], {})
            for source in source_notes:
                object_to_source_notes[derived["object_id"]][source["path"]] = source
    enriched_items = []
    for item in items:
        enriched_members = [
            {
                **member,
                "object_path": _scoped_path(
                    f"/object?id={quote(str(member['object_id']), safe='')}",
                    pack_name=requested_pack,
                ),
            }
            for member in item["members"]
        ]
        preview_titles = [member["title"] for member in enriched_members[:5]]
        member_object_ids = [member["object_id"] for member in enriched_members]
        source_note_map: dict[str, dict[str, str]] = {}
        deep_dive_map: dict[str, dict[str, str]] = {}
        for member_object_id in member_object_ids:
            for source in object_to_source_notes.get(member_object_id, {}).values():
                source_note_map.setdefault(source["path"], source)
            for deep_dive in object_to_deep_dives.get(member_object_id, {}).values():
                deep_dive_map.setdefault(deep_dive["slug"], deep_dive)
        enriched_items.append(
            {
                **item,
                "members": enriched_members,
                "member_count": len(enriched_members),
                "preview_titles": preview_titles,
                "source_notes": list(source_note_map.values()),
                "deep_dives": list(deep_dive_map.values()),
            }
        )
    return {
        "screen": "atlas/browser",
        "requested_pack": requested_pack,
        "items": enriched_items,
        "count": len(enriched_items),
        "query": query or "",
        "limit": DEFAULT_TRACEABILITY_BROWSER_LIMIT,
        "is_limited": True,
    }


def build_derivation_browser_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    query: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    items = list_deep_dive_derivations(
        vault_dir,
        pack_name=pack_name,
        query=query,
        limit=DEFAULT_TRACEABILITY_BROWSER_LIMIT,
    )
    enriched_items = []
    for item in items:
        derived_objects = [
            {
                "object_id": member["object_id"],
                "title": member["title"],
                "object_path": _scoped_path(
                    f"/object?id={quote(str(member['object_id']), safe='')}",
                    pack_name=requested_pack,
                ),
            }
            for member in item["derived_objects"]
        ]
        preview_titles = [member["title"] for member in derived_objects[:5]]
        provenance_map = get_object_provenance_map(
            vault_dir,
            [member["object_id"] for member in derived_objects],
            pack_name=pack_name,
        )
        atlas_page_map: dict[str, dict[str, str]] = {}
        for provenance in provenance_map.values():
            for atlas_page in provenance["mocs"]:
                atlas_page_map.setdefault(atlas_page["slug"], atlas_page)
        source_notes = get_note_traceability(vault_dir, note_path=item["path"], pack_name=pack_name)["source_notes"]
        enriched_items.append(
            {
                **item,
                "derived_objects": derived_objects,
                "derived_object_count": len(derived_objects),
                "preview_titles": preview_titles,
                "atlas_pages": list(atlas_page_map.values()),
                "source_notes": source_notes,
            }
        )
    return {
        "screen": "derivations/browser",
        "requested_pack": requested_pack,
        "items": enriched_items,
        "count": len(enriched_items),
        "query": query or "",
        "limit": DEFAULT_TRACEABILITY_BROWSER_LIMIT,
        "is_limited": True,
    }


def build_production_browser_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    query: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    surface_contract = describe_observation_surface_contract(
        pack_name=pack_name,
        surface_kind="production_chains",
    )
    if surface_contract["status"] == "missing":
        return {
            "screen": "production/browser",
            "requested_pack": requested_pack,
            "surface_contract": surface_contract,
            "surface_error": (
                f"Pack '{surface_contract['requested_pack']}' does not expose a shared shell "
                f"'production_chains' surface."
            ),
            "items": [],
            "source_items": [],
            "deep_dive_items": [],
            "weak_points": [],
            "count": 0,
            "query": query or "",
            "limit": DEFAULT_TRACEABILITY_BROWSER_LIMIT,
            "is_limited": True,
            "counts": {
                "source_notes": 0,
                "deep_dives": 0,
            },
            "operator_rail": [],
            "compiled_sections": [],
            "section_nav": [],
        }
    items = list_production_chains(
        vault_dir,
        pack_name=pack_name,
        query=query,
        limit=DEFAULT_TRACEABILITY_BROWSER_LIMIT,
    )
    source_items = [item for item in items if item["stage_label"] == "source_note"]
    deep_dive_items = [item for item in items if item["stage_label"] == "deep_dive"]
    weak_points = _build_production_weak_points(vault_dir, pack_name=pack_name, query=query)
    compiled_sections = [
        _compiled_section(
            "current_state",
            "Current State",
            summary=(
                f"{len(items)} production-chain entries are currently visible, spanning "
                f"{len(source_items)} source notes and {len(deep_dive_items)} deep dives."
            ),
            items=[
                {
                    "kind": "source_notes",
                    "label": "Source notes",
                    "path": "",
                    "detail": f"{len(source_items)} source-note chain entries in scope.",
                },
                {
                    "kind": "deep_dives",
                    "label": "Deep dives",
                    "path": "",
                    "detail": f"{len(deep_dive_items)} deep-dive chain entries in scope.",
                },
            ],
        ),
        _compiled_section(
            "why_it_matters",
            "Why It Matters",
            summary=(
                f"{len(weak_points)} chain weak points currently block full source-to-object-to-atlas legibility."
            ),
            items=[
                *[
                    {
                        "kind": "weak_point",
                        "label": item["title"],
                        "path": _scoped_path(
                            f"/note?path={quote(str(item['note_path']), safe='')}",
                            pack_name=requested_pack,
                        ),
                        "detail": f"Missing {', '.join(item['missing'])}",
                    }
                    for item in weak_points[:3]
                ]
            ],
        ),
        _compiled_section(
            "chain_gaps",
            "Chain Gaps",
            summary="Weak points highlight where the current production chain stops short of a complete downstream path.",
            items=[
                *[
                    {
                        "kind": item["stage_label"],
                        "label": item["title"],
                        "path": _scoped_path(
                            f"/note?path={quote(str(item['note_path']), safe='')}",
                            pack_name=requested_pack,
                        ),
                        "detail": ", ".join(item["missing"]),
                    }
                    for item in weak_points[:5]
                ]
            ],
        ),
        _compiled_section(
            "where_to_go_next",
            "Where To Go Next",
            summary="Use the visible source and deep-dive entries to continue into note, object, and atlas-level traceability.",
            items=[
                *[
                    {
                        "kind": item["stage_label"],
                        "label": item["title"],
                        "path": _scoped_path(
                            f"/note?path={quote(str(item['path']), safe='')}",
                            pack_name=requested_pack,
                        ),
                        "detail": str(item["traceability"].get("chain_summary") or ""),
                    }
                    for item in items[:4]
                ]
            ],
        ),
    ]
    operator_rail = [
        _operator_action(
            "Orientation Brief",
            _scoped_path("/briefing", pack_name=requested_pack),
            "Return to the current entry product.",
        ),
        _operator_action(
            "Signals",
            _scoped_path("/signals", pack_name=requested_pack),
            "Review active signals related to chain maintenance.",
        ),
        _operator_action(
            "Action Queue",
            _scoped_path("/actions", pack_name=requested_pack),
            "Run or inspect queued execution work.",
        ),
        _operator_action(
            "Search",
            _scoped_path("/search", pack_name=requested_pack),
            "Search laterally from the current production scope.",
        ),
    ]
    return {
        "screen": "production/browser",
        "requested_pack": requested_pack,
        "surface_contract": surface_contract,
        "items": items,
        "source_items": source_items,
        "deep_dive_items": deep_dive_items,
        "weak_points": weak_points,
        "count": len(items),
        "query": query or "",
        "limit": DEFAULT_TRACEABILITY_BROWSER_LIMIT,
        "is_limited": True,
        "counts": {
            "source_notes": len(source_items),
            "deep_dives": len(deep_dive_items),
        },
        "operator_rail": operator_rail,
        "compiled_sections": compiled_sections,
        "section_nav": _section_nav_from_compiled_sections(compiled_sections),
    }


def build_stale_summary_browser_payload(
    vault_dir: Path | str,
    *,
    pack_name: str | None = None,
    query: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    items = [
        {
            **item,
            "object_path": _scoped_path(
                f"/object?id={quote(str(item['object_id']), safe='')}",
                pack_name=requested_pack,
            ),
        }
        for item in list_stale_summaries(vault_dir, pack_name=pack_name, query=query)
    ]
    review_context = get_review_context(vault_dir, [item["object_id"] for item in items], pack_name=pack_name)
    return {
        "screen": "truth/stale-summaries",
        "requested_pack": requested_pack,
        "items": items,
        "count": len(items),
        "query": query or "",
        "review_context": review_context,
        "review_history": list_review_actions(vault_dir, object_ids=[item["object_id"] for item in items], limit=8),
        "detection_notes": [
            "Stale summary review flags compiled summaries that are weak and have no outgoing supporting relations.",
            "This queue is deterministic and favors false negatives over false positives.",
        ],
    }


def build_search_payload(
    vault_dir: Path | str,
    *,
    query: str,
    pack_name: str | None = None,
    page: int = 1,
    page_size: int = 50,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    page = max(1, int(page))
    page_size = max(1, min(int(page_size), 200))
    offset = (page - 1) * page_size
    results = search_vault_surface(
        vault_dir,
        query=query,
        pack_name=pack_name,
        object_limit=page_size,
        note_limit=page_size,
        object_offset=offset,
        note_offset=offset,
    )
    return {
        "screen": "search/results",
        "requested_pack": requested_pack,
        **results,
        "objects": [
            {
                **item,
                "object_path": _scoped_path(
                    f"/object?id={quote(str(item['object_id']), safe='')}",
                    pack_name=requested_pack,
                ),
            }
            for item in results["objects"]
        ],
        "notes": [
            {
                **item,
                "note_path": _scoped_path(
                    f"/note?path={quote(str(item['path']), safe='')}",
                    pack_name=requested_pack,
                ),
            }
            for item in results["notes"]
        ],
        "object_count": len(results["objects"]),
        "note_count": len(results["notes"]),
        "page": page,
        "page_size": page_size,
    }


def build_note_page_payload(
    vault_dir: Path | str,
    *,
    note_path: str,
    pack_name: str | None = None,
) -> dict[str, Any]:
    requested_pack = pack_name or ""
    provenance = get_note_provenance(vault_dir, note_path=note_path)
    production_chain = get_note_traceability(vault_dir, note_path=note_path, pack_name=pack_name)
    inbound_capture = get_note_inbound_capture_summary(vault_dir, note_path=note_path)
    production_chain["source_notes"] = [
        {
            **item,
            "note_path": _scoped_path(
                f"/note?path={quote(str(item['path']), safe='')}",
                pack_name=requested_pack,
            ),
        }
        for item in production_chain["source_notes"]
    ]
    production_chain["deep_dives"] = [
        {
            **item,
            "note_path": _scoped_path(
                f"/note?path={quote(str(item['path']), safe='')}",
                pack_name=requested_pack,
            ),
        }
        for item in production_chain["deep_dives"]
    ]
    production_chain["objects"] = [
        {
            **item,
            "object_path": _scoped_path(
                f"/object?id={quote(str(item['object_id']), safe='')}",
                pack_name=requested_pack,
            ),
        }
        for item in production_chain["objects"]
    ]
    production_chain["atlas_pages"] = [
        {
            **item,
            "note_path": _scoped_path(
                f"/note?path={quote(str(item['path']), safe='')}",
                pack_name=requested_pack,
            ),
        }
        for item in production_chain["atlas_pages"]
    ]
    compiled_sections = [
        _compiled_section(
            "current_state",
            "Current State",
            summary=(
                f"{production_chain['note']['title']} currently resolves as a "
                f"{production_chain.get('stage_label', '').replace('_', ' ')} with "
                f"{production_chain['counts']['deep_dives']} deep dives, "
                f"{production_chain['counts']['objects']} objects, and "
                f"{production_chain['counts']['atlas_pages']} atlas pages downstream."
            ),
            items=[
                {
                    "kind": "stage",
                    "label": str(production_chain.get("stage_label") or "").replace("_", " "),
                    "path": "",
                    "detail": str(production_chain.get("chain_status") or ""),
                }
            ],
        ),
        _compiled_section(
            "inbound_capture",
            "Inbound Capture",
            summary=str(inbound_capture.get("summary") or ""),
            items=[
                {
                    "kind": str(item.get("kind") or ""),
                    "label": str(item.get("label") or ""),
                    "path": (
                        _scoped_path(f"/note?path={quote(str(item['path']), safe='')}", pack_name=requested_pack)
                        if item.get("path")
                        else ""
                    ),
                    "detail": str(item.get("detail") or ""),
                }
                for item in inbound_capture.get("items", [])
            ],
        ),
        _compiled_section(
            "evidence_traceability",
            "Evidence Traceability",
            summary="The note traceability chain shows which deep dives, objects, and atlas pages this note currently anchors.",
            items=[
                *[
                    {
                        "kind": "deep_dive",
                        "label": item["title"],
                        "path": item["note_path"],
                        "detail": "Downstream deep dive",
                    }
                    for item in production_chain["deep_dives"][:3]
                ],
                *[
                    {
                        "kind": "object",
                        "label": item["title"],
                        "path": item["object_path"],
                        "detail": "Derived evergreen object",
                    }
                    for item in production_chain["objects"][:3]
                ],
            ],
        ),
        _compiled_section(
            "production_chain",
            "Production Chain",
            summary=str(production_chain.get("chain_summary") or ""),
            items=[
                {
                    "kind": "chain_status",
                    "label": "Chain status",
                    "path": "",
                    "detail": str(production_chain.get("chain_status") or ""),
                },
                {
                    "kind": "missing_stages",
                    "label": "Missing stages",
                    "path": "",
                    "detail": ", ".join(str(item).replace("_", " ") for item in production_chain.get("missing_stages", [])) or "None",
                },
            ],
        ),
        _compiled_section(
            "where_to_go_next",
            "Where To Go Next",
            summary="Continue into downstream deep dives, derived objects, or atlas reach from this note.",
            items=[
                *[
                    {
                        "kind": "deep_dive",
                        "label": item["title"],
                        "path": item["note_path"],
                        "detail": "Open downstream deep dive.",
                    }
                    for item in production_chain["deep_dives"][:2]
                ],
                *[
                    {
                        "kind": "object",
                        "label": item["title"],
                        "path": item["object_path"],
                        "detail": "Open derived object page.",
                    }
                    for item in production_chain["objects"][:2]
                ],
            ],
        ),
    ]
    fallback_object_path = (
        production_chain["objects"][0]["object_path"]
        if production_chain["objects"]
        else _scoped_path("/objects", pack_name=requested_pack)
    )
    fallback_object_label = "Open derived object" if production_chain["objects"] else "Objects"
    return {
        "screen": "note/page",
        "requested_pack": requested_pack,
        "note_path": note_path,
        "provenance": provenance,
        "inbound_capture": inbound_capture,
        "production_chain": production_chain,
        "operator_rail": [
            _operator_action(
                "Production Browser",
                _scoped_path("/production", pack_name=requested_pack),
                "Inspect broader production-chain weak points.",
            ),
            _operator_action(
                "Signals",
                _scoped_path("/signals", pack_name=requested_pack),
                "Open active signals for this shell scope.",
            ),
            _operator_action(
                fallback_object_label,
                fallback_object_path,
                "Jump into the most relevant derived object surface.",
            ),
        ],
        "compiled_sections": compiled_sections,
        "section_nav": _section_nav_from_compiled_sections(compiled_sections),
    }
