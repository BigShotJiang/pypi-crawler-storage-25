'use strict';

/**
 * SSE Keepalive — heartbeat for streaming connections.
 *
 * Prevents proxies and load balancers from killing idle SSE connections
 * by sending periodic comment events (`: keepalive`).
 *
 * Also supports client-side reconnection with event ID tracking.
 *
 * Inspired by LibreChat's SSE reconnection + Redis event sequencing.
 *
 * @module sseKeepalive
 */

// ── Constants ──────────────────────────────────────────────────────

const DEFAULT_INTERVAL_MS = 15000;  // 15s — typical proxy timeout is 60s
const COMMENT_EVENT = ': keepalive\n\n';

// ── Keepalive Class ────────────────────────────────────────────────

class SSEKeepalive {
  /**
   * @param {object} res - HTTP response (writable stream)
   * @param {object} [options]
   * @param {number} [options.intervalMs]
   * @param {Function} [options.onError]
   */
  constructor(res, options = {}) {
    this._res = res;
    this._intervalMs = options.intervalMs || DEFAULT_INTERVAL_MS;
    this._onError = options.onError || null;
    this._timer = null;
    this._eventSeq = 0;
    this._active = true;
  }

  /**
   * Start the keepalive timer.
   * @returns {this}
   */
  start() {
    if (this._timer) return this;
    this._timer = setInterval(() => {
      if (!this._active) return;
      try {
        if (!this._res.writableEnded && !this._res.destroyed) {
          this._res.write(COMMENT_EVENT);
        } else {
          this.stop();
        }
      } catch (err) {
        if (this._onError) try { this._onError(err); } catch { /* ignore */ }
        this.stop();
      }
    }, this._intervalMs);
    if (this._timer.unref) this._timer.unref();
    return this;
  }

  /**
   * Send a named SSE event with auto-incrementing ID.
   * @param {string} event - Event name
   * @param {string|object} data - Event data
   * @returns {number} Event sequence number
   */
  send(event, data) {
    if (!this._active || this._res.writableEnded) return -1;
    this._eventSeq++;
    const payload = typeof data === 'string' ? data : JSON.stringify(data);
    try {
      this._res.write(`id: ${this._eventSeq}\nevent: ${event}\ndata: ${payload}\n\n`);
    } catch { /* connection closed */ }
    return this._eventSeq;
  }

  /**
   * Send a data-only SSE event (default event type).
   * @param {string|object} data
   * @returns {number}
   */
  sendData(data) {
    if (!this._active || this._res.writableEnded) return -1;
    this._eventSeq++;
    const payload = typeof data === 'string' ? data : JSON.stringify(data);
    try {
      this._res.write(`id: ${this._eventSeq}\ndata: ${payload}\n\n`);
    } catch { /* connection closed */ }
    return this._eventSeq;
  }

  /**
   * Send a terminal "done" event (with optional abort flag).
   * @param {boolean} [aborted=false]
   */
  done(aborted = false) {
    if (!this._active) return;
    this.send('done', { aborted, seq: this._eventSeq });
    this.stop();
  }

  /**
   * Get the current event sequence number.
   * Used for client-side reconnection (Last-Event-ID).
   * @returns {number}
   */
  getSeq() {
    return this._eventSeq;
  }

  /**
   * Stop the keepalive timer.
   */
  stop() {
    this._active = false;
    if (this._timer) {
      clearInterval(this._timer);
      this._timer = null;
    }
  }
}

// ── Factory ────────────────────────────────────────────────────────

/**
 * Attach SSE keepalive to an HTTP response.
 * Sets appropriate headers and starts the timer.
 *
 * @param {object} res - Express/Node HTTP response
 * @param {object} [options]
 * @param {number} [options.intervalMs]
 * @param {Function} [options.onError]
 * @returns {SSEKeepalive}
 */
function attach(res, options = {}) {
  // Set SSE headers
  if (!res.headersSent) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no', // nginx buffering bypass
    });
  }

  const keepalive = new SSEKeepalive(res, options);
  keepalive.start();

  // Auto-stop on close
  res.on('close', () => keepalive.stop());

  return keepalive;
}

module.exports = {
  SSEKeepalive,
  attach,
  DEFAULT_INTERVAL_MS,
};
