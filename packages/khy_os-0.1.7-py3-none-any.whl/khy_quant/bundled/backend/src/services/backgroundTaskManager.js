'use strict';

/**
 * Background Task Manager — pause, resume, cancel, and lifecycle management.
 *
 * Extends the basic task store with:
 *   - Pause / resume / cancel state transitions
 *   - AbortController-based cancellation
 *   - TTL cleanup for terminal tasks
 *   - Event callbacks for state changes
 *
 * Inspired by Qwen Code's BackgroundTaskRegistry (3 types: agents, shells, monitors)
 * and Claude Code's paused-resumable agents.
 *
 * @module backgroundTaskManager
 */

// ── Constants ──────────────────────────────────────────────────────

const TERMINAL_TASK_TTL_MS = 5 * 60 * 1000; // 5 min
const MAX_TASKS = 100;
const CLEANUP_INTERVAL_MS = 60 * 1000;

const VALID_STATES = new Set([
  'pending', 'running', 'paused', 'completed', 'failed', 'cancelled',
]);

const TERMINAL_STATES = new Set(['completed', 'failed', 'cancelled']);

// ── State ──────────────────────────────────────────────────────────

/** @type {Map<string, BackgroundTask>} */
const _tasks = new Map();

/** @type {Map<string, AbortController>} */
const _abortControllers = new Map();

/** @type {Function[]} */
const _listeners = [];

let _cleanupTimer = null;
let _nextId = 1;

// ── Task class ─────────────────────────────────────────────────────

/**
 * @typedef {object} BackgroundTask
 * @property {string} id
 * @property {string} type - 'agent' | 'shell' | 'monitor' | 'generic'
 * @property {string} state
 * @property {string} label
 * @property {number} createdAt
 * @property {number} updatedAt
 * @property {number|null} completedAt
 * @property {*} result
 * @property {string|null} error
 * @property {object} meta
 */

// ── Core API ───────────────────────────────────────────────────────

/**
 * Register a new background task.
 *
 * @param {object} params
 * @param {string} [params.type='generic']
 * @param {string} params.label
 * @param {object} [params.meta]
 * @returns {{ task: BackgroundTask, signal: AbortSignal, release: () => void }}
 */
function register(params) {
  _ensureCleanup();
  _evictIfNeeded();

  const id = `bg_${_nextId++}`;
  const now = Date.now();

  const task = {
    id,
    type: params.type || 'generic',
    state: 'running',
    label: params.label || id,
    createdAt: now,
    updatedAt: now,
    completedAt: null,
    result: null,
    error: null,
    meta: params.meta || {},
  };

  const controller = new AbortController();
  _tasks.set(id, task);
  _abortControllers.set(id, controller);
  _emit('created', task);

  return {
    task,
    signal: controller.signal,
    release: () => complete(id),
  };
}

/**
 * Pause a running task.
 * @param {string} id
 * @returns {{ success: boolean, error?: string }}
 */
function pause(id) {
  const task = _tasks.get(id);
  if (!task) return { success: false, error: 'Task not found' };
  if (task.state !== 'running') return { success: false, error: `Cannot pause task in state: ${task.state}` };

  task.state = 'paused';
  task.updatedAt = Date.now();
  _emit('paused', task);
  return { success: true };
}

/**
 * Resume a paused task.
 * @param {string} id
 * @returns {{ success: boolean, signal?: AbortSignal, error?: string }}
 */
function resume(id) {
  const task = _tasks.get(id);
  if (!task) return { success: false, error: 'Task not found' };
  if (task.state !== 'paused') return { success: false, error: `Cannot resume task in state: ${task.state}` };

  task.state = 'running';
  task.updatedAt = Date.now();

  // Ensure abort controller exists
  if (!_abortControllers.has(id)) {
    _abortControllers.set(id, new AbortController());
  }

  _emit('resumed', task);
  return { success: true, signal: _abortControllers.get(id)?.signal };
}

/**
 * Cancel a running or paused task.
 * @param {string} id
 * @param {string} [reason]
 * @returns {{ success: boolean, error?: string }}
 */
function cancel(id, reason) {
  const task = _tasks.get(id);
  if (!task) return { success: false, error: 'Task not found' };
  if (TERMINAL_STATES.has(task.state)) return { success: false, error: `Task already in terminal state: ${task.state}` };

  // Signal abort
  const controller = _abortControllers.get(id);
  if (controller && !controller.signal.aborted) {
    controller.abort(new Error(reason || 'Task cancelled'));
  }

  task.state = 'cancelled';
  task.updatedAt = Date.now();
  task.completedAt = Date.now();
  task.error = reason || 'Cancelled by user';
  _emit('cancelled', task);
  return { success: true };
}

/**
 * Mark a task as completed with a result.
 * @param {string} id
 * @param {*} [result]
 * @returns {{ success: boolean }}
 */
function complete(id, result) {
  const task = _tasks.get(id);
  if (!task || TERMINAL_STATES.has(task.state)) return { success: false };

  task.state = 'completed';
  task.updatedAt = Date.now();
  task.completedAt = Date.now();
  task.result = result ?? null;
  _abortControllers.delete(id);
  _emit('completed', task);
  return { success: true };
}

/**
 * Mark a task as failed.
 * @param {string} id
 * @param {string} error
 * @returns {{ success: boolean }}
 */
function fail(id, error) {
  const task = _tasks.get(id);
  if (!task || TERMINAL_STATES.has(task.state)) return { success: false };

  task.state = 'failed';
  task.updatedAt = Date.now();
  task.completedAt = Date.now();
  task.error = error;
  _abortControllers.delete(id);
  _emit('failed', task);
  return { success: true };
}

/**
 * Get a task by ID.
 * @param {string} id
 * @returns {BackgroundTask|undefined}
 */
function get(id) {
  return _tasks.get(id);
}

/**
 * List all tasks, optionally filtered.
 * @param {object} [filter]
 * @param {string} [filter.state]
 * @param {string} [filter.type]
 * @returns {BackgroundTask[]}
 */
function listAll(filter = {}) {
  let tasks = [..._tasks.values()];
  if (filter.state) tasks = tasks.filter(t => t.state === filter.state);
  if (filter.type) tasks = tasks.filter(t => t.type === filter.type);
  return tasks;
}

/**
 * Get count by state.
 * @returns {{ running: number, paused: number, completed: number, failed: number, cancelled: number }}
 */
function getCounts() {
  const counts = { running: 0, paused: 0, completed: 0, failed: 0, cancelled: 0, pending: 0 };
  for (const task of _tasks.values()) {
    counts[task.state] = (counts[task.state] || 0) + 1;
  }
  return counts;
}

// ── Events ─────────────────────────────────────────────────────────

/**
 * Subscribe to task events.
 * @param {Function} listener - (event: string, task: BackgroundTask) => void
 * @returns {Function} Unsubscribe function
 */
function onEvent(listener) {
  _listeners.push(listener);
  return () => {
    const idx = _listeners.indexOf(listener);
    if (idx >= 0) _listeners.splice(idx, 1);
  };
}

function _emit(event, task) {
  for (const l of _listeners) {
    try { l(event, task); } catch { /* ignore */ }
  }
}

// ── Cleanup ────────────────────────────────────────────────────────

function _evictIfNeeded() {
  if (_tasks.size < MAX_TASKS) return;

  // Remove oldest terminal tasks
  const terminals = [..._tasks.entries()]
    .filter(([, t]) => TERMINAL_STATES.has(t.state))
    .sort((a, b) => a[1].completedAt - b[1].completedAt);

  for (const [id] of terminals) {
    _tasks.delete(id);
    _abortControllers.delete(id);
    if (_tasks.size < MAX_TASKS) break;
  }
}

function _runCleanup() {
  const now = Date.now();
  for (const [id, task] of _tasks) {
    if (TERMINAL_STATES.has(task.state) && task.completedAt && (now - task.completedAt) > TERMINAL_TASK_TTL_MS) {
      _tasks.delete(id);
      _abortControllers.delete(id);
    }
  }
}

function _ensureCleanup() {
  if (_cleanupTimer) return;
  _cleanupTimer = setInterval(_runCleanup, CLEANUP_INTERVAL_MS);
  if (_cleanupTimer.unref) _cleanupTimer.unref();
}

/**
 * Reset all state (for testing / new session).
 */
function reset() {
  // Cancel all running tasks
  for (const [id, controller] of _abortControllers) {
    if (!controller.signal.aborted) controller.abort();
  }
  _tasks.clear();
  _abortControllers.clear();
  _listeners.length = 0;
  if (_cleanupTimer) { clearInterval(_cleanupTimer); _cleanupTimer = null; }
  _nextId = 1;
}

module.exports = {
  register,
  pause,
  resume,
  cancel,
  complete,
  fail,
  get,
  listAll,
  getCounts,
  onEvent,
  reset,
  TERMINAL_TASK_TTL_MS,
  MAX_TASKS,
};
