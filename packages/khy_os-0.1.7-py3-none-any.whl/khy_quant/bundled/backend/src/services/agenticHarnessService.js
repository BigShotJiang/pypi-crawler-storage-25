'use strict';

/**
 * agenticHarnessService.js
 *
 * Five-pillar runtime composition for:
 *   1) Context engineering
 *   2) Agent loop resiliency
 *   3) Skills activation
 *   4) Memory engineering
 *   5) Harness-level observability
 *
 * This module does not replace existing services. It assembles them into one
 * reusable entrypoint so CLI/REPL/sub-agents can share the same workflow.
 */

const crypto = require('crypto');
const path = require('path');
const { AgentContext } = require('./agentContext');
const { routeContextStrategy, truncateToolResults } = require('./contextRouter');
const { compress } = require('./contextCompressor');
const { estimateTokens } = require('./contextWasm');
const { runToolUseLoop } = require('./toolUseLoop');
const { retryWithBackoff, isRetryableError } = require('./retryWithBackoff');
const backgroundTaskManager = require('./backgroundTaskManager');
const projectMemoryService = require('./projectMemoryService');
const memdir = require('../memdir');
const skills = require('../skills');

const DEFAULTS = Object.freeze({
  contextBudget: 128000,
  retryAttempts: 2,
  retryMinDelayMs: 700,
  retryMaxDelayMs: 5000,
  memoryHintLimit: 4,
  skillHintLimit: 6,
  cacheTtlMs: 120000,
  maxCacheEntries: 256,
});

function createAgenticHarness(options = {}) {
  const cfg = {
    ...DEFAULTS,
    ...(options || {}),
  };

  const hintCache = _createTtlCache(cfg.cacheTtlMs, cfg.maxCacheEntries);
  const vectorRetriever = typeof cfg.vectorRetriever === 'function' ? cfg.vectorRetriever : null;

  async function buildContextPacket(input = {}) {
    const userMessage = String(input.userMessage || '').trim();
    const systemPrompt = String(input.systemPrompt || '');
    const contextBudget = Math.max(2048, Number(input.contextBudget || cfg.contextBudget) || cfg.contextBudget);
    const messages = _cloneMessages(input.messages);
    const recentFiles = _safeArray(input.recentFiles);
    const cwd = input.cwd || process.cwd();

    const contextRoute = routeContextStrategy(messages, systemPrompt, userMessage, contextBudget);
    let workingMessages = _cloneMessages(messages);

    if (contextRoute.route === 'truncate_tool_results_only' || contextRoute.route === 'compact_then_truncate') {
      truncateToolResults(workingMessages, Math.max(0, contextRoute.overflow));
    }

    if ((contextRoute.route === 'compact_only' || contextRoute.route === 'compact_then_truncate')
      && typeof input.callModelForCompression === 'function'
      && workingMessages.length > 0) {
      try {
        const compactResult = await compress(workingMessages, {
          estimateTokensFn: estimateTokens,
          callModelFn: input.callModelForCompression,
          contextWindowTokens: contextBudget,
        });
        if (Array.isArray(compactResult.compressed)) {
          workingMessages = compactResult.compressed;
        }
      } catch {
        // Compression is best-effort. The route info still indicates pressure.
      }
    }

    const cacheKey = _hashInput(JSON.stringify({
      userMessage,
      cwd,
      recentFiles,
      memoryHintLimit: input.memoryHintLimit || cfg.memoryHintLimit,
      skillHintLimit: input.skillHintLimit || cfg.skillHintLimit,
    }));

    let hints = hintCache.get(cacheKey);
    if (!hints) {
      const memoryHints = await _collectMemoryHints({
        userMessage,
        maxItems: Math.max(1, Number(input.memoryHintLimit || cfg.memoryHintLimit) || cfg.memoryHintLimit),
        vectorRetriever,
      });
      const skillHints = _collectSkillHints({
        userMessage,
        cwd,
        recentFiles,
        maxItems: Math.max(1, Number(input.skillHintLimit || cfg.skillHintLimit) || cfg.skillHintLimit),
      });
      hints = { memoryHints, skillHints };
      hintCache.set(cacheKey, hints);
    }

    const tokenEstimate = workingMessages.reduce((sum, msg) => sum + estimateTokens(msg.content || ''), 0)
      + estimateTokens(systemPrompt)
      + estimateTokens(userMessage);

    return {
      userMessage,
      cwd,
      messages: workingMessages,
      recentFiles,
      contextBudget,
      tokenEstimate,
      contextRoute,
      memoryHints: hints.memoryHints,
      skillHints: hints.skillHints,
    };
  }

  async function run(request = {}) {
    const userMessage = String(request.userMessage || '').trim();
    const chat = request.chat;
    if (!userMessage) throw new Error('agenticHarnessService: userMessage is required');
    if (typeof chat !== 'function') throw new Error('agenticHarnessService: chat function is required');

    const cwd = request.cwd || process.cwd();
    const chatOpts = request.chatOpts || {};
    const onEvent = typeof request.onEvent === 'function' ? request.onEvent : null;
    const startedAt = Date.now();
    const defaultLabel = `agentic:${path.basename(cwd)}`;
    const taskHandle = backgroundTaskManager.register({
      type: 'agent',
      label: request.taskLabel || defaultLabel,
      meta: {
        phase: 'prepare',
        cwd,
      },
    });

    const runtimeCtx = request.agentContext instanceof AgentContext
      ? request.agentContext
      : new AgentContext({
          role: request.role || 'general',
          toolFilter: request.toolFilter || null,
          config: request.agentConfig || {},
        });

    try {
      const contextPacket = await buildContextPacket({
        userMessage,
        messages: request.messages,
        systemPrompt: request.systemPrompt,
        contextBudget: request.contextBudget,
        cwd,
        recentFiles: request.recentFiles,
        memoryHintLimit: request.memoryHintLimit,
        skillHintLimit: request.skillHintLimit,
        callModelForCompression: async (text, opts) => chat(text, {
          ...chatOpts,
          ...opts,
          _isFollowUp: true,
        }),
      });

      taskHandle.task.meta.phase = 'loop';
      taskHandle.task.updatedAt = Date.now();

      const loopInput = _buildLoopInput(contextPacket);
      const loopOptions = request.loopOptions || {};

      const runLoopOnce = async () => {
        const result = await runToolUseLoop(loopInput, {
          ...loopOptions,
          chat,
          chatOpts: {
            ...chatOpts,
            _agentContext: runtimeCtx,
          },
        });
        if (_isRetryableLoopOutcome(result)) {
          const err = new Error(`Transient tool loop error: ${result.errorType}`);
          err.code = `tool-loop-${result.errorType}`;
          err.loopResult = result;
          throw err;
        }
        return result;
      };

      let loopResult;
      try {
        loopResult = await retryWithBackoff(runLoopOnce, {
          attempts: Math.max(1, Number(request.retryAttempts || cfg.retryAttempts) || cfg.retryAttempts),
          minDelayMs: Math.max(100, Number(request.retryMinDelayMs || cfg.retryMinDelayMs) || cfg.retryMinDelayMs),
          maxDelayMs: Math.max(500, Number(request.retryMaxDelayMs || cfg.retryMaxDelayMs) || cfg.retryMaxDelayMs),
          shouldRetry: (err) => {
            if (err && err.loopResult) return true;
            return isRetryableError(err);
          },
          onRetry: (retryInfo) => {
            if (!onEvent) return;
            onEvent({
              type: 'retry',
              attempt: retryInfo.attempt,
              maxAttempts: retryInfo.maxAttempts,
              delayMs: retryInfo.delayMs,
              error: retryInfo.err?.message || 'retry',
            });
          },
        });
      } catch (err) {
        if (err && err.loopResult) {
          loopResult = err.loopResult;
        } else {
          throw err;
        }
      }

      const finishedAt = Date.now();
      const harnessReport = {
        durationMs: finishedAt - startedAt,
        contextRoute: contextPacket.contextRoute.route,
        tokenEstimate: contextPacket.tokenEstimate,
        memoryHints: contextPacket.memoryHints,
        skillHints: contextPacket.skillHints,
        iterations: Number(loopResult?.iterations || 0),
        toolCalls: Array.isArray(loopResult?.toolCallLog) ? loopResult.toolCallLog.length : 0,
        taskId: taskHandle.task.id,
      };

      try {
        projectMemoryService.saveSessionTrace(cwd, {
          type: 'agentic_harness_run',
          promptPreview: userMessage.slice(0, 500),
          contextRoute: harnessReport.contextRoute,
          iterations: harnessReport.iterations,
          toolCalls: harnessReport.toolCalls,
          memoryHints: harnessReport.memoryHints.map(item => item.filename),
          skillHints: harnessReport.skillHints.map(item => item.trigger || item.name),
          durationMs: harnessReport.durationMs,
          success: !loopResult?.errorType,
        });
      } catch {
        // Session trace persistence is best-effort.
      }

      backgroundTaskManager.complete(taskHandle.task.id, harnessReport);
      if (onEvent) onEvent({ type: 'completed', report: harnessReport });

      return {
        ...loopResult,
        harness: harnessReport,
      };
    } catch (err) {
      backgroundTaskManager.fail(taskHandle.task.id, err?.message || 'agentic harness failed');
      if (onEvent) onEvent({ type: 'failed', error: err?.message || 'agentic harness failed' });
      throw err;
    }
  }

  return {
    run,
    buildContextPacket,
    config: { ...cfg },
    clearCache: () => hintCache.clear(),
  };
}

function _buildLoopInput(packet) {
  const sections = [packet.userMessage];

  if (packet.memoryHints.length > 0) {
    sections.push([
      '[System Memory Hints]',
      ...packet.memoryHints.map((item, idx) => `${idx + 1}. ${item.title} (${item.filename}) - ${item.snippet}`),
    ].join('\n'));
  }

  if (packet.skillHints.length > 0) {
    sections.push([
      '[System Skill Hints]',
      ...packet.skillHints.map((item, idx) => `${idx + 1}. ${item.trigger || item.name}: ${item.description}`),
    ].join('\n'));
  }

  if (packet.contextRoute.route !== 'fits') {
    sections.push(
      `[System Context Route] route=${packet.contextRoute.route}; overflow=${packet.contextRoute.overflow}; `
      + `toolResultTokens=${packet.contextRoute.toolResultTokens}.`,
    );
  }

  return sections.join('\n\n');
}

function _isRetryableLoopOutcome(loopResult) {
  const retryable = new Set(['timeout', 'network', 'process', 'unknown', 'cancelled']);
  const errorType = String(loopResult?.errorType || '').trim().toLowerCase();
  if (!errorType || !retryable.has(errorType)) return false;
  const calls = Array.isArray(loopResult?.toolCallLog) ? loopResult.toolCallLog.length : 0;
  return calls === 0;
}

async function _collectMemoryHints({ userMessage, maxItems, vectorRetriever }) {
  if (!userMessage) return [];
  const queryTokens = _tokenize(userMessage);
  if (queryTokens.size === 0) return [];

  const candidates = [];
  const seen = new Set();

  const pushHit = (hit, source) => {
    const filename = String(hit?.filename || '').trim();
    if (!filename || seen.has(filename)) return;
    seen.add(filename);
    const frontmatter = hit.frontmatter || {};
    const joined = [frontmatter.name, frontmatter.description, ...(hit.matches || [])].filter(Boolean).join(' ');
    const textTokens = _tokenize(joined);
    const score = _overlapScore(queryTokens, textTokens);
    candidates.push({
      filename,
      title: String(frontmatter.name || filename),
      snippet: _safeSnippet((hit.matches || []).join(' | ') || frontmatter.description || ''),
      score,
      source,
    });
  };

  try {
    const direct = memdir.searchMemories(userMessage);
    for (const hit of direct) pushHit(hit, 'text');
  } catch {
    // ignore
  }

  if (candidates.length < maxItems) {
    const tokenQueries = [...queryTokens].filter(t => t.length >= 2).slice(0, 4);
    for (const token of tokenQueries) {
      try {
        const tokenHits = memdir.searchMemories(token);
        for (const hit of tokenHits) pushHit(hit, 'token');
      } catch {
        // ignore
      }
      if (candidates.length >= maxItems * 3) break;
    }
  }

  if (vectorRetriever) {
    try {
      const vectorHits = await vectorRetriever({
        query: userMessage,
        maxItems: maxItems * 2,
      });
      if (Array.isArray(vectorHits)) {
        for (const hit of vectorHits) {
          pushHit({
            filename: hit.filename || hit.id || `vector-${candidates.length + 1}`,
            frontmatter: {
              name: hit.title || hit.name || hit.filename || 'vector-memory',
              description: hit.description || '',
            },
            matches: [hit.snippet || hit.content || ''],
          }, 'vector');
        }
      }
    } catch {
      // Vector retrieval is optional.
    }
  }

  return candidates
    .sort((a, b) => b.score - a.score || a.filename.localeCompare(b.filename))
    .slice(0, maxItems)
    .map(({ filename, title, snippet, source }) => ({ filename, title, snippet, source }));
}

function _collectSkillHints({ userMessage, cwd, recentFiles, maxItems }) {
  try {
    skills.discoverAllSkills(cwd);
    const activeSkills = skills.getActiveSkills({ cwd, recentFiles });
    if (!Array.isArray(activeSkills) || activeSkills.length === 0) return [];

    const queryTokens = _tokenize(userMessage);
    const scored = activeSkills.map((skill) => {
      const baseText = [
        skill.name,
        skill.description,
        skill.trigger,
        ...(skill.tags || []),
      ].filter(Boolean).join(' ');
      const skillTokens = _tokenize(baseText);
      return {
        name: skill.name,
        trigger: skill.trigger,
        description: _safeSnippet(skill.description || '', 140),
        score: _overlapScore(queryTokens, skillTokens),
      };
    });

    const hasSignal = scored.some(item => item.score > 0);
    const picked = (hasSignal
      ? scored.filter(item => item.score > 0)
      : scored
    )
      .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
      .slice(0, maxItems)
      .map(({ name, trigger, description }) => ({ name, trigger, description }));

    return picked;
  } catch {
    return [];
  }
}

function _tokenize(text) {
  const raw = String(text || '').toLowerCase();
  const out = new Set();
  const words = raw.match(/[a-z0-9_./-]+/g) || [];
  for (const word of words) {
    const normalized = word.trim();
    if (normalized.length >= 2) out.add(normalized);
  }

  // Keep CJK bigrams to support Chinese query matching.
  const cjk = (raw.match(/[\u4e00-\u9fff]+/g) || []).join('');
  for (let i = 0; i < cjk.length - 1; i++) {
    out.add(cjk.slice(i, i + 2));
  }
  return out;
}

function _overlapScore(left, right) {
  if (!(left instanceof Set) || !(right instanceof Set) || left.size === 0 || right.size === 0) {
    return 0;
  }
  let hit = 0;
  for (const token of left) {
    if (right.has(token)) hit++;
  }
  return hit / left.size;
}

function _safeSnippet(text, maxLen = 180) {
  const oneLine = String(text || '').replace(/\s+/g, ' ').trim();
  if (oneLine.length <= maxLen) return oneLine;
  return `${oneLine.slice(0, maxLen - 1)}…`;
}

function _cloneMessages(messages) {
  if (!Array.isArray(messages)) return [];
  return messages.map((msg) => ({
    role: String(msg?.role || 'assistant'),
    content: String(msg?.content || ''),
  }));
}

function _safeArray(value) {
  return Array.isArray(value) ? value.filter(Boolean) : [];
}

function _hashInput(input) {
  return crypto.createHash('sha1').update(String(input || '')).digest('hex');
}

function _createTtlCache(ttlMs, maxEntries) {
  const ttl = Math.max(1000, Number(ttlMs) || DEFAULTS.cacheTtlMs);
  const cap = Math.max(16, Number(maxEntries) || DEFAULTS.maxCacheEntries);
  const map = new Map();

  function get(key) {
    const entry = map.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
      map.delete(key);
      return null;
    }
    return entry.value;
  }

  function set(key, value) {
    if (map.size >= cap) {
      const firstKey = map.keys().next().value;
      if (firstKey !== undefined) map.delete(firstKey);
    }
    map.set(key, {
      value,
      expiresAt: Date.now() + ttl,
    });
  }

  function clear() {
    map.clear();
  }

  return { get, set, clear };
}

module.exports = {
  createAgenticHarness,
  DEFAULTS,
};
