/**
 * Tool Calling System — enable AI models to invoke tools with user confirmation.
 *
 * Architecture:
 * 1. Tools are registered (built-in + MCP servers + user plugins)
 * 2. AI generates tool_use requests during conversation
 * 3. System prompts user for confirmation (unless dangerous mode)
 * 4. Tool executes and result feeds back to AI
 *
 * Security:
 * - All tool calls require explicit user approval by default
 * - "Dangerous mode" (--dangerous / KHYQUANT_DANGEROUS=true) skips confirmation
 * - Dangerous mode requires explicit user acknowledgment on first enable
 * - Tool permissions can be pre-approved per tool or per category
 *
 * Inspired by: Claude Code permission model, Claw tool calling, MCP protocol
 */
const readline = require('readline');
const path = require('path');
const fs = require('fs');
const os = require('os');
const {
  normalizeToolName,
  normalizeToolParams,
  getClaudeCompatToolDefinitions,
  getClaudeCompatToolList,
} = require('./claudeCompat');
const { rewriteWindowsDesktopPath } = require('../utils/pathCompat');

let _chalk;
const chalk = () => (_chalk ??= (require('chalk').default || require('chalk')));

// Expand ~ and ~user in file paths to absolute paths
function expandPath(p) {
  if (!p || typeof p !== 'string') return p;
  if (p.startsWith('~/') || p === '~') {
    return path.join(os.homedir(), p.slice(1));
  }
  return p;
}

function _trimWrappingQuotes(value) {
  return String(value || '').trim().replace(/^['"`]+|['"`]+$/g, '').trim();
}

function _looksLikeFilesystemTarget(raw = '') {
  const text = String(raw || '').trim();
  if (!text) return false;
  return text.startsWith('~/')
    || text.startsWith('./')
    || text.startsWith('../')
    || text.startsWith('.\\')
    || text.startsWith('..\\')
    || text.startsWith('/')
    || text.startsWith('\\')
    || /^[A-Za-z]:[\\/]/.test(text)
    || /\.[A-Za-z0-9]{1,10}$/.test(text);
}

function _resolveExistingFilesystemTarget(input = '') {
  const normalizedInput = rewriteWindowsDesktopPath(_trimWrappingQuotes(input));
  if (!normalizedInput || !_looksLikeFilesystemTarget(normalizedInput)) return '';

  const cwd = process.env.KHYQUANT_CWD || process.cwd();
  const candidates = [];
  const pushCandidate = (value) => {
    const candidate = String(value || '').trim();
    if (!candidate) return;
    if (!candidates.includes(candidate)) candidates.push(candidate);
  };

  const expandedRaw = expandPath(normalizedInput);
  pushCandidate(expandedRaw);

  const absoluteLike = path.isAbsolute(expandedRaw)
    || /^[A-Za-z]:[\\/]/.test(expandedRaw)
    || /^\\\\/.test(expandedRaw);
  if (!absoluteLike) {
    pushCandidate(path.resolve(cwd, expandedRaw));
  }

  for (const candidate of candidates) {
    try {
      if (fs.existsSync(candidate)) return candidate;
    } catch { /* ignore invalid filesystem candidates */ }
  }
  return '';
}

async function _openFilesystemTarget(targetPath = '') {
  const absPath = String(targetPath || '').trim();
  if (!absPath) return { success: false, error: 'Target path is required' };

  const launchers = [];
  if (process.platform === 'win32') {
    launchers.push({
      command: 'explorer.exe',
      args: [absPath],
      hint: `explorer.exe ${absPath}`,
    });
  } else if (process.platform === 'darwin') {
    launchers.push({
      command: 'open',
      args: [absPath],
      hint: `open ${absPath}`,
    });
  } else {
    if (_commandExists('xdg-open')) {
      launchers.push({
        command: 'xdg-open',
        args: [absPath],
        hint: `xdg-open ${absPath}`,
      });
    }
    if (_commandExists('gio')) {
      launchers.push({
        command: 'gio',
        args: ['open', absPath],
        hint: `gio open ${absPath}`,
      });
    }
  }

  if (launchers.length === 0) {
    return {
      success: false,
      error: `No launcher is available to open path: ${absPath}`,
      hint: 'Install xdg-open/gio (Linux) or use a desktop session that supports opening files.',
    };
  }

  let lastError = null;
  for (const launcher of launchers) {
    try {
      await _spawnDetached(launcher.command, launcher.args, {
        env: { ...process.env },
      });
      return {
        success: true,
        launcher: launcher.hint,
        output: `已打开目标: ${absPath}`,
      };
    } catch (err) {
      lastError = err;
    }
  }

  return {
    success: false,
    error: `Failed to open path ${absPath}: ${lastError?.message || 'launcher failed'}`,
  };
}

function _normalizePathLikeParams(params = {}) {
  if (!params || typeof params !== 'object') return params;
  const out = { ...params };
  const pathLikeKeys = [
    'path',
    'file_path',
    'filePath',
    'inputPath',
    'outputPath',
    'directory',
    'dir',
  ];
  for (const key of pathLikeKeys) {
    if (typeof out[key] === 'string' && out[key].trim()) {
      out[key] = rewriteWindowsDesktopPath(out[key]);
    }
  }
  return out;
}

// ── Interactive Application Detection ──────────────────────────────
// Detects whether a command is an interactive/GUI application that should
// be spawned detached (not blocking execSync). Works cross-platform.

// Cache: populated lazily on first call. Maps binary name → true/false.
let _guiAppCache = null;

// CLI tools that should NEVER be spawned detached (they expect piped I/O)
const _cliTools = new Set([
  'ls', 'cat', 'head', 'tail', 'grep', 'rg', 'find', 'wc', 'file', 'stat',
  'pwd', 'which', 'echo', 'tree', 'du', 'df', 'date', 'whoami', 'hostname',
  'uname', 'env', 'printenv', 'sort', 'uniq', 'sed', 'awk', 'cut', 'tr',
  'tee', 'xargs', 'curl', 'wget', 'ssh', 'scp', 'rsync', 'tar', 'gzip',
  'zip', 'unzip', 'cp', 'mv', 'rm', 'mkdir', 'rmdir', 'chmod', 'chown',
  'ln', 'touch', 'diff', 'patch', 'git', 'npm', 'node', 'python', 'python3',
  'pip', 'pip3', 'docker', 'systemctl', 'journalctl', 'ps', 'top', 'htop',
  'kill', 'pkill', 'pgrep', 'mount', 'umount', 'fdisk', 'lsblk', 'ip',
  'ifconfig', 'ping', 'traceroute', 'nslookup', 'dig', 'netstat', 'ss',
  'apt', 'apt-get', 'yum', 'dnf', 'pacman', 'brew', 'snap', 'flatpak',
  'dpkg', 'rpm', 'make', 'cmake', 'gcc', 'g++', 'cargo', 'go', 'javac',
  'java', 'mvn', 'gradle', 'bash', 'sh', 'zsh', 'fish', 'crontab', 'at',
  'systemctl', 'service', 'sudo', 'su', 'man', 'info', 'help',
]);

/**
 * Build the GUI app cache by scanning .desktop files (Linux) or known paths.
 * Returns a Set of binary names that are GUI/interactive applications.
 */
function _buildGuiAppCache() {
  const cache = new Set();

  if (process.platform === 'linux') {
    // Scan .desktop files — every GUI app on Linux registers one
    const desktopDirs = [
      '/usr/share/applications',
      '/usr/local/share/applications',
      path.join(os.homedir(), '.local/share/applications'),
      '/var/lib/flatpak/exports/share/applications',
      '/var/lib/snapd/desktop/applications',
    ];
    for (const dir of desktopDirs) {
      try {
        if (!fs.existsSync(dir)) continue;
        const files = fs.readdirSync(dir).filter(f => f.endsWith('.desktop'));
        for (const file of files) {
          try {
            const content = fs.readFileSync(path.join(dir, file), 'utf-8');
            // Extract Exec= line and get the binary name
            const execMatch = content.match(/^Exec\s*=\s*(.+)$/m);
            if (!execMatch) continue;
            // Exec line may have %f %u etc. args, env prefixes, or full paths
            let execCmd = execMatch[1].trim()
              .replace(/^env\s+\S+=\S+\s+/, '')  // strip env VAR=val prefix
              .replace(/%[fFuUdDnNickvm]/g, '')   // strip desktop entry codes
              .trim();
            const bin = path.basename(execCmd.split(/\s+/)[0]);
            if (bin) cache.add(bin);
          } catch { /* skip unreadable files */ }
        }
      } catch { /* skip inaccessible dirs */ }
    }
  } else if (process.platform === 'win32') {
    // On Windows, scan common app directories and Start Menu shortcuts
    const progDirs = [
      process.env.ProgramFiles,
      process.env['ProgramFiles(x86)'],
      path.join(os.homedir(), 'AppData', 'Local', 'Programs'),
    ].filter(Boolean);
    for (const dir of progDirs) {
      try {
        if (!fs.existsSync(dir)) continue;
        // Only scan top-level subdirectories (app names)
        const entries = fs.readdirSync(dir);
        for (const entry of entries) {
          // Use the directory/exe name as a potential app name
          cache.add(entry.toLowerCase().replace(/\.exe$/i, ''));
        }
      } catch { /* skip */ }
    }
    // Also scan Start Menu for .lnk files (covers most installed apps)
    const startMenuDirs = [
      path.join(os.homedir(), 'AppData', 'Roaming', 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
      path.join(process.env.ProgramData || 'C:\\ProgramData', 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
    ];
    for (const dir of startMenuDirs) {
      try {
        if (!fs.existsSync(dir)) continue;
        const walk = (d) => {
          for (const entry of fs.readdirSync(d, { withFileTypes: true })) {
            if (entry.isDirectory()) { try { walk(path.join(d, entry.name)); } catch {} }
            else if (entry.name.endsWith('.lnk')) {
              cache.add(entry.name.replace(/\.lnk$/i, '').toLowerCase());
            }
          }
        };
        walk(dir);
      } catch { /* skip */ }
    }
  } else if (process.platform === 'darwin') {
    // macOS: scan /Applications
    try {
      const apps = fs.readdirSync('/Applications')
        .filter(f => f.endsWith('.app'))
        .map(f => f.replace(/\.app$/, '').toLowerCase());
      apps.forEach(a => cache.add(a));
    } catch { /* skip */ }
  }

  return cache;
}

/**
 * Determine if a command binary is an interactive/GUI application.
 * Uses multiple heuristics:
 *   1. Known CLI tool → false (never detach)
 *   2. In .desktop file cache → true
 *   3. Has a .desktop file by name → true
 *   4. `which` resolves it and it's not in system bin → likely app
 */
function _isGuiApplication(cmdBin) {
  if (!cmdBin) return false;
  const bin = path.basename(cmdBin).toLowerCase();

  // Definitely a CLI tool
  if (_cliTools.has(bin)) return false;

  // Platform-specific GUI launchers
  if (bin === 'xdg-open') return true;
  if (bin === 'open' && process.platform === 'darwin') return true;
  if (bin === 'start' && process.platform === 'win32') return true;

  // Build cache once
  if (!_guiAppCache) {
    _guiAppCache = _buildGuiAppCache();
  }

  // Direct match in desktop file cache
  if (_guiAppCache.has(bin)) return true;

  // Check if a .desktop file exists for this binary name
  if (process.platform === 'linux') {
    const desktopDirs = [
      '/usr/share/applications',
      '/usr/local/share/applications',
      path.join(os.homedir(), '.local/share/applications'),
    ];
    for (const dir of desktopDirs) {
      try {
        if (fs.existsSync(path.join(dir, `${bin}.desktop`))) return true;
      } catch {}
    }
  }

  // Check if the binary is in an app-like path (not /usr/bin CLI tools)
  if (process.platform === 'win32') return false; // .lnk scanning handles Windows apps
  try {
    const { execFileSync } = require('child_process');
    const resolved = execFileSync('which', [bin], { encoding: 'utf-8', timeout: 2000 }).trim();
    if (resolved) {
      // Binaries in /opt, /snap, ~/local/bin, AppImage paths are usually GUI apps
      if (/\/(opt|snap|flatpak|AppImage|\.local\/bin)\//.test(resolved)) return true;
      // Symlinks to /opt or snap are also GUI apps
      try {
        const real = fs.realpathSync(resolved);
        if (/\/(opt|snap|flatpak)\//.test(real)) return true;
      } catch {}
    }
  } catch { /* binary not found */ }

  return false;
}

// ── Installed App Index ────────────────────────────────────────────
// Scans .desktop files to build a searchable list of all installed GUI apps.
// Cached after first call; refresh by setting _installedAppsCache = null.
let _installedAppsCache = null;
let _installedAppsCacheTime = 0;
const APP_CACHE_TTL = 60000; // refresh every 60s

const APP_ALIAS_MAP = Object.freeze({
  // Browsers
  '火狐': 'firefox',
  '火狐浏览器': 'firefox',
  'firefox': 'firefox',
  'ff': 'firefox',
  '夸克': 'quark',
  '夸克浏览器': 'quark',
  'quark': 'quark',
  '谷歌浏览器': 'google-chrome',
  '谷歌': 'google-chrome',
  'chrome': 'google-chrome',
  'chromium': 'chromium',
  'edge': 'microsoft-edge',
  '微软浏览器': 'microsoft-edge',
  '浏览器': 'firefox',

  // IM / Collaboration
  '飞书': 'bytedance-feishu',
  'lark': 'bytedance-feishu',
  'feishu': 'bytedance-feishu',
  '微信': 'wechat',
  '企业微信': 'wxwork',
  'qq': 'qq',
  '钉钉': 'dingtalk',

  // System utilities
  '终端': 'gnome-terminal',
  '控制台': 'gnome-terminal',
  '文件管理器': 'nautilus',
  '文件': 'nautilus',

  // Category intents
  '图片编辑器': 'gimp',
  '图像编辑器': 'gimp',
  '照片编辑器': 'gimp',
  'image editor': 'gimp',
  'photo editor': 'gimp',
  'pdf编辑器': 'libreoffice',
  'pdf editor': 'libreoffice',
});

function _normalizeAppQuery(input) {
  return String(input || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, '')
    .replace(/[，。、“”‘’"'`~!@#$%^&*()_+=|\\[\]{};:<>/?-]/g, '');
}

function _buildAppCandidates(input) {
  const raw = String(input || '').trim();
  if (!raw) return [];

  const normalized = _normalizeAppQuery(raw);
  const candidates = new Set();

  candidates.add(raw.toLowerCase());
  candidates.add(normalized);

  const directAlias = APP_ALIAS_MAP[raw] || APP_ALIAS_MAP[normalized];
  if (directAlias) candidates.add(String(directAlias).toLowerCase());

  for (const [k, v] of Object.entries(APP_ALIAS_MAP)) {
    const keyNorm = _normalizeAppQuery(k);
    if (normalized && (normalized === keyNorm || normalized.includes(keyNorm) || keyNorm.includes(normalized))) {
      candidates.add(String(v).toLowerCase());
    }
  }

  return Array.from(candidates).filter(Boolean);
}

function _commandExists(bin) {
  if (!bin) return false;
  const { searchExecutable } = require('../tools/platformUtils');
  return !!searchExecutable(bin);
}

function _splitExecLine(line) {
  const raw = String(line || '').trim();
  if (!raw) return [];
  const out = [];
  const re = /"([^"]*)"|'([^']*)'|([^\s]+)/g;
  let m;
  while ((m = re.exec(raw)) !== null) {
    out.push(m[1] || m[2] || m[3] || '');
  }
  return out.filter(Boolean);
}

async function _launchLinuxDesktopEntry(app = {}) {
  if (process.platform !== 'linux') {
    return { launched: false, reason: 'unsupported-platform' };
  }
  const desktopId = String(app.desktopId || '').trim();
  const desktopPath = String(app.desktopPath || '').trim();

  const launchers = [];
  if (desktopId && _commandExists('gtk-launch')) {
    launchers.push({ command: 'gtk-launch', args: [desktopId], hint: `gtk-launch ${desktopId}` });
  }
  if (desktopPath && _commandExists('gio')) {
    launchers.push({ command: 'gio', args: ['launch', desktopPath], hint: `gio launch ${desktopPath}` });
  }
  if (desktopPath && _commandExists('xdg-open')) {
    launchers.push({ command: 'xdg-open', args: [desktopPath], hint: `xdg-open ${desktopPath}` });
  }

  if (launchers.length === 0) {
    return { launched: false, reason: 'launcher-not-found' };
  }

  let lastError = null;
  for (const item of launchers) {
    try {
      await _spawnDetached(item.command, item.args, {
        env: { ...process.env },
      });
      return {
        launched: true,
        mode: 'desktop-entry',
        command: item.command,
        args: item.args,
        hint: item.hint,
      };
    } catch (err) {
      lastError = err;
    }
  }
  return {
    launched: false,
    reason: 'all-launchers-failed',
    error: lastError,
  };
}

function _resolveWindowsShortcutTarget(linkPath) {
  if (process.platform !== 'win32') return '';
  const raw = String(linkPath || '').trim().replace(/^"+|"+$/g, '');
  if (!raw || !/\.lnk$/i.test(raw)) return '';

  const { execFileSync } = require('child_process');
  const psBin = _commandExists('pwsh') ? 'pwsh' : (_commandExists('powershell') ? 'powershell' : '');
  if (!psBin) return '';

  const escaped = raw.replace(/'/g, "''");
  const script = [
    '$ErrorActionPreference = "Stop"',
    '$w = New-Object -ComObject WScript.Shell',
    `$s = $w.CreateShortcut('${escaped}')`,
    'if ($null -ne $s -and $s.TargetPath) { [Console]::Out.Write($s.TargetPath) }',
  ].join('; ');

  try {
    const stdout = execFileSync(psBin, [
      '-NoProfile',
      '-NonInteractive',
      '-Command',
      script,
    ], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 4000,
    });
    return String(stdout || '').trim().replace(/^"+|"+$/g, '');
  } catch {
    return '';
  }
}

function _looksLikePowerShellCommand(command) {
  const trimmed = String(command || '').trim();
  if (!trimmed) return false;
  if (/^(?:powershell|pwsh)(?:\.exe)?\b/i.test(trimmed)) return false;
  if (/^(?:cmd|cmd\.exe)\b/i.test(trimmed)) return false;
  if (/^[A-Za-z]:\\/.test(trimmed) || /^\\\\/.test(trimmed)) return false;
  if (/^\.\.?[\\/]/.test(trimmed)) return false;
  if (/^[A-Za-z0-9_.-]+(?:\.exe|\.cmd|\.bat)?\b/.test(trimmed) && !/-[A-Za-z]/.test(trimmed)) return false;
  return /^(?:New|Get|Set|Remove|Copy|Move|Rename|Test|Resolve|Clear|Start|Stop|Restart|Enable|Disable|Add)-[A-Za-z]+/i
    .test(trimmed);
}

async function _spawnDetached(command, args = [], options = {}) {
  const { spawn } = require('child_process');
  const { buildGuiEnv } = require('../tools/platformUtils');
  // Ensure GUI env (DISPLAY etc.) is set for graphical applications
  const env = options.env ? buildGuiEnv(options.env) : buildGuiEnv();
  const isWin = process.platform === 'win32';
  return new Promise((resolve, reject) => {
    let settled = false;
    let child;
    try {
      if (isWin) {
        const target = String(command || '').trim().replace(/^"+|"+$/g, '');
        const targetBase = path.basename(target).toLowerCase();
        const normalizedArgs = Array.isArray(args) ? args.map(a => String(a)) : [];
        const spawnOptions = {
          detached: true,
          stdio: 'ignore',
          windowsHide: true,
          ...options,
          env,
        };

        if (targetBase === 'explorer' || targetBase === 'explorer.exe') {
          child = spawn('explorer.exe', normalizedArgs, spawnOptions);
        } else if (/\.(lnk|url)$/i.test(target)) {
          child = spawn('explorer.exe', [target, ...normalizedArgs], spawnOptions);
        } else if (/\.msi$/i.test(target)) {
          child = spawn('cmd.exe', ['/c', 'start', '', target, ...normalizedArgs], spawnOptions);
        } else {
          child = spawn(target, normalizedArgs, spawnOptions);
        }
      } else {
        child = spawn(command, args, {
          detached: true,
          stdio: 'ignore',
          ...options,
          env,
        });
      }
    } catch (err) {
      reject(err);
      return;
    }
    child.once('error', (err) => {
      if (settled) return;
      settled = true;
      reject(err);
    });
    child.once('spawn', () => {
      if (settled) return;
      settled = true;
      try { child.unref(); } catch { /* noop */ }
      resolve(child);
    });
  });
}

function _inferWindowsImageName(command) {
  let raw = String(command || '').trim().replace(/^"+|"+$/g, '');
  if (!raw) return '';
  if (/\.lnk$/i.test(raw)) {
    const target = _resolveWindowsShortcutTarget(raw);
    if (target) raw = target;
  }
  const base = path.basename(raw).toLowerCase();
  if (!base || base === 'explorer' || base === 'explorer.exe') return '';
  if (/\.(lnk|url|msi|cmd|bat|ps1|vbs|js)$/i.test(base)) return '';
  if (base.endsWith('.exe')) return base;
  if (/^[a-z0-9_.-]+$/i.test(base)) return `${base}.exe`;
  return '';
}

function _formatLaunchOutput(displayName, execHint, verification) {
  if (verification && verification.verified) {
    return `已启动并验证: ${displayName} (${execHint})`;
  }
  if (!verification) {
    return `已发送启动请求: ${displayName} (${execHint})（未验证）`;
  }
  if (verification.mode === 'unverifiable') {
    return `已发送启动请求: ${displayName} (${execHint})（未验证：无法识别目标进程）`;
  }
  if (verification.reason === 'no-new-process-detected' && verification.imageName) {
    return `已发送启动请求: ${displayName} (${execHint})（未验证：未检测到新进程 ${verification.imageName}）`;
  }
  return `已发送启动请求: ${displayName} (${execHint})（未验证）`;
}

function _getWindowsProcessPids(imageName) {
  const { execFileSync } = require('child_process');
  const out = new Set();
  if (!imageName) return out;
  try {
    const stdout = execFileSync('tasklist', [
      '/FI',
      `IMAGENAME eq ${imageName}`,
      '/FO',
      'CSV',
      '/NH',
    ], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 2000,
    });
    const lines = String(stdout || '').split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    for (const line of lines) {
      if (!line.startsWith('"')) continue;
      const m = line.match(/^"[^"]*","([^"]+)",/);
      if (!m) continue;
      const pid = Number(m[1].replace(/,/g, ''));
      if (Number.isFinite(pid) && pid > 0) out.add(pid);
    }
  } catch {
    return out;
  }
  return out;
}

async function _verifyWindowsLaunch(command, beforePids = new Set(), timeoutMs = 2000, opts = {}) {
  const imageName = String(opts.imageName || '').trim() || _inferWindowsImageName(command);
  if (!imageName) {
    return {
      verified: false,
      mode: 'unverifiable',
      reason: 'process-name-unknown',
    };
  }

  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    await new Promise(resolve => setTimeout(resolve, 250));
    const afterPids = _getWindowsProcessPids(imageName);
    for (const pid of afterPids) {
      if (!beforePids.has(pid)) {
        return {
          verified: true,
          mode: 'process-diff',
          imageName,
          pid,
        };
      }
    }
  }

  return {
    verified: false,
    mode: 'process-diff',
    imageName,
    reason: 'no-new-process-detected',
  };
}

/**
 * Detect shell commands that are probing for an app rather than doing real work.
 * Examples: `which feishu`, `command -v lark`, `nohup feishu &`, `pgrep -i feishu`
 */
function _looksLikeShellAppProbe(command) {
  const cmd = String(command || '').trim().toLowerCase();
  if (!cmd) return false;
  return /\b(which|whereis|command\s+-v|type\s+-p|nohup|xdg-open|gtk-launch|gio\s+launch)\b/.test(cmd)
    || /\b(pgrep|pidof)\b/.test(cmd)
    || /\bps\s+aux\b.*\bgrep\b/.test(cmd);
}

/**
 * Extract the likely app target from a shell probe command.
 * "which feishu" → "feishu", "nohup lark &" → "lark", "xdg-open https://..." → null
 */
function _extractAppTargetFromCommand(command) {
  const cmd = String(command || '').trim();
  // "which X" / "whereis X" / "command -v X" / "type -p X"
  let m = cmd.match(/\b(?:which|whereis|command\s+-v|type\s+-p)\s+(\S+)/i);
  if (m) return m[1];
  // "nohup X ..." / "nohup X &"
  m = cmd.match(/\bnohup\s+(\S+)/i);
  if (m) return m[1];
  // "gtk-launch X" / "gio launch X"
  m = cmd.match(/\b(?:gtk-launch|gio\s+launch)\s+(\S+)/i);
  if (m) return m[1].replace(/\.desktop$/, '');
  // Direct binary invocation (single word or word + args)
  const parts = cmd.split(/\s+/);
  if (parts.length <= 3 && !/[|><;&$`]/.test(cmd)) {
    return parts[0];
  }
  return null;
}

function _hasGraphicalSession() {
  if (process.platform !== 'linux') return true;
  const { getDisplay } = require('../tools/platformUtils');
  const display = getDisplay();
  const wayland = String(process.env.WAYLAND_DISPLAY || '').trim();
  return !!(display || wayland);
}

function _getInstalledApps() {
  const now = Date.now();
  if (_installedAppsCache && (now - _installedAppsCacheTime) < APP_CACHE_TTL) {
    return _installedAppsCache;
  }

  const apps = [];

  if (process.platform === 'linux') {
    const desktopDirs = [
      '/usr/share/applications',
      '/usr/local/share/applications',
      path.join(os.homedir(), '.local/share/applications'),
      '/var/lib/flatpak/exports/share/applications',
      '/var/lib/snapd/desktop/applications',
    ];

    for (const dir of desktopDirs) {
      try {
        if (!fs.existsSync(dir)) continue;
        const files = fs.readdirSync(dir).filter(f => f.endsWith('.desktop'));
        for (const file of files) {
          try {
            const content = fs.readFileSync(path.join(dir, file), 'utf-8');
            // Skip entries that are truly hidden services (Type=Service, OnlyShowIn=...)
            if (/^Type\s*=\s*Service/mi.test(content)) continue;

            const nameMatch = content.match(/^Name\s*=\s*(.+)$/m);
            const nameCnMatch = content.match(/^Name\[zh_CN\]\s*=\s*(.+)$/m);
            const execMatch = content.match(/^Exec\s*=\s*(.+)$/m);
            const keywordsMatch = content.match(/^Keywords\s*=\s*(.+)$/m);
            const commentMatch = content.match(/^Comment\s*=\s*(.+)$/m);
            const commentCnMatch = content.match(/^Comment\[zh_CN\]\s*=\s*(.+)$/m);

            if (!execMatch) continue;

            let execCmd = execMatch[1].trim()
              .replace(/%[fFuUdDnNickvm]/g, '')  // strip desktop entry field codes
              .replace(/^env\s+\S+=\S+\s+/g, '') // strip env prefixes
              .trim();
            const bin = path.basename(execCmd.split(/\s+/)[0]);
            const name = (nameMatch ? nameMatch[1].trim() : bin);
            const nameCn = nameCnMatch ? nameCnMatch[1].trim() : '';
            const keywords = keywordsMatch
              ? keywordsMatch[1].split(';').map(k => k.trim().toLowerCase()).filter(Boolean)
              : [];
            const comment = commentMatch ? commentMatch[1].trim() : '';
            const commentCn = commentCnMatch ? commentCnMatch[1].trim() : '';

            // Build combined search text for fuzzy matching
            const searchText = [name, nameCn, bin, comment, commentCn, ...keywords, file.replace('.desktop', '')]
              .join(' ').toLowerCase();

            apps.push({
              name,
              nameCn,
              bin,
              exec: execCmd,
              keywords,
              searchText,
              file,
              desktopId: file.replace(/\.desktop$/i, ''),
              desktopPath: path.join(dir, file),
            });
          } catch { /* skip unreadable */ }
        }
      } catch { /* skip inaccessible dir */ }
    }
  } else if (process.platform === 'win32') {
    // Windows: scan Start Menu shortcuts
    const startMenuDirs = [
      path.join(process.env.APPDATA || '', 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
      path.join(process.env.ProgramData || 'C:\\ProgramData', 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
    ];
    for (const dir of startMenuDirs) {
      try {
        if (!fs.existsSync(dir)) continue;
        const walk = (d) => {
          for (const entry of fs.readdirSync(d, { withFileTypes: true })) {
            if (entry.isDirectory()) { try { walk(path.join(d, entry.name)); } catch {} }
            else if (entry.name.endsWith('.lnk') || entry.name.endsWith('.url')) {
              const name = entry.name.replace(/\.(lnk|url)$/i, '');
              apps.push({ name, nameCn: '', bin: name.toLowerCase(), exec: path.join(d, entry.name), keywords: [], searchText: name.toLowerCase(), file: entry.name });
            }
          }
        };
        walk(dir);
      } catch { /* skip */ }
    }
  } else if (process.platform === 'darwin') {
    try {
      const macApps = fs.readdirSync('/Applications').filter(f => f.endsWith('.app'));
      for (const app of macApps) {
        const name = app.replace('.app', '');
        apps.push({ name, nameCn: '', bin: name.toLowerCase(), exec: `open -a "${name}"`, keywords: [], searchText: name.toLowerCase(), file: app });
      }
    } catch { /* skip */ }
  }

  _installedAppsCache = apps;
  _installedAppsCacheTime = now;
  return apps;
}

const PERMISSIONS_FILE = path.join(os.homedir(), '.khyquant', 'tool_permissions.json');

// Tool categories and risk levels
const RISK_LEVELS = {
  safe: { label: '安全', color: 'green', autoApprove: true },
  low: { label: '低风险', color: 'cyan', autoApprove: false },
  medium: { label: '中风险', color: 'yellow', autoApprove: false },
  high: { label: '高风险', color: 'red', autoApprove: false },
  critical: { label: '危险', color: 'redBright', autoApprove: false },
};

// Built-in tools available for AI to call
const BUILTIN_TOOLS = [
  {
    name: 'quote',
    description: 'Get real-time stock/futures quote',
    category: 'data',
    risk: 'safe',
    parameters: {
      symbol: { type: 'string', required: true, description: 'Stock/futures symbol code' },
    },
    handler: async (params) => {
      const { handleQuote } = require('../cli/handlers/data');
      await handleQuote(params.symbol);
      return { success: true };
    },
  },
  {
    name: 'backtest',
    description: 'Run strategy backtest',
    category: 'analysis',
    risk: 'safe',
    parameters: {
      symbol: { type: 'string', required: true },
      strategy: { type: 'string', required: false },
      start: { type: 'string', required: false },
      end: { type: 'string', required: false },
      capital: { type: 'number', required: false },
    },
    handler: async (params) => {
      const { handleBacktestRun } = require('../cli/handlers/backtest');
      await handleBacktestRun(params.symbol, params);
      return { success: true };
    },
  },
  {
    name: 'data_fetch',
    description: 'Download K-line data for a symbol',
    category: 'data',
    risk: 'safe',
    parameters: {
      symbol: { type: 'string', required: true },
    },
    handler: async (params) => {
      const { handleDataFetch } = require('../cli/handlers/data');
      await handleDataFetch(params.symbol);
      return { success: true };
    },
  },
  {
    name: 'search',
    description: 'Search for instruments by name/code',
    category: 'data',
    risk: 'safe',
    parameters: {
      keyword: { type: 'string', required: true },
    },
    handler: async (params) => {
      const { resolveSymbol } = require('../cli/symbolResolver');
      const result = await resolveSymbol(params.keyword);
      return { success: true, result };
    },
  },
  {
    name: 'execute_code',
    description: 'Execute JavaScript code in sandbox',
    category: 'execution',
    risk: 'high',
    parameters: {
      code: { type: 'string', required: true, description: 'JavaScript code to execute' },
    },
    handler: async (params) => {
      // Sandboxed execution via VM with timeout guard
      const vm = require('vm');
      const { withTimeout } = require('../services/resourceGuard');
      const sandbox = { result: null, console: { log: (...args) => { sandbox._output = (sandbox._output || '') + args.join(' ') + '\n'; } } };
      const context = vm.createContext(sandbox);
      await withTimeout(
        Promise.resolve(vm.runInContext(params.code, context, { timeout: 5000 })),
        10000,
        'execute_code'
      );
      return { success: true, output: sandbox._output || '', result: sandbox.result };
    },
  },
  {
    name: 'open_app',
    description: 'Open an application installed on this computer. Accepts app name in any language (e.g. "docker", "apifox", "火狐", "文件管理器"). Automatically finds and launches the correct binary.',
    category: 'system',
    risk: 'medium',
    parameters: {
      name: { type: 'string', required: true, description: 'Application name (fuzzy match supported)' },
    },
    handler: async (params) => {
      const rawName = String(params.name || '').trim();
      const appName = rawName.toLowerCase();
      if (!appName) return { success: false, error: 'Application name is required' };
      if (process.platform === 'linux' && !_hasGraphicalSession()) {
        return {
          success: false,
          error: 'No graphical session detected (DISPLAY/WAYLAND_DISPLAY is not set). Unable to open GUI applications from this terminal session.',
        };
      }
      const candidates = _buildAppCandidates(rawName);

      // Build index of installed apps from .desktop files
      const apps = _getInstalledApps();

      // Fuzzy match with priority: exact bin/name > bin starts with > name includes > keyword/searchText
      let match = null;
      for (const candidate of candidates.length > 0 ? candidates : [appName]) {
        match = apps.find(a => a.bin === candidate || a.name.toLowerCase() === candidate);
        if (!match) match = apps.find(a => a.bin.startsWith(candidate) || a.name.toLowerCase().startsWith(candidate));
        if (!match) match = apps.find(a => a.bin.includes(candidate) || a.name.toLowerCase().includes(candidate));
        if (!match && rawName) match = apps.find(a => a.nameCn && a.nameCn.includes(rawName));
        if (!match) {
          match = apps.find(a =>
            a.keywords.some(k => k.includes(candidate))
            || candidate.split(/\s+/).every(w => a.searchText.includes(w))
          );
        }
        if (match) break;
      }

      if (!match) {
        // Fallback: if binary exists in PATH, launch directly.
        const runnable = (candidates.length > 0 ? candidates : [appName]).find(c => _commandExists(c));
        if (runnable) {
          try {
            const imageName = _inferWindowsImageName(runnable);
            const beforePids = process.platform === 'win32'
              ? _getWindowsProcessPids(imageName)
              : new Set();
            await _spawnDetached(runnable, [], {
              env: { ...process.env },
            });
            const verification = process.platform === 'win32'
              ? await _verifyWindowsLaunch(runnable, beforePids, 2000, { imageName })
              : { verified: true, mode: 'spawn' };
            const output = _formatLaunchOutput(rawName, runnable, verification);
            return {
              success: true,
              verified: !!verification.verified,
              verification,
              output,
            };
          } catch (err) {
            return { success: false, error: `Failed to launch ${rawName}: ${err.message}` };
          }
        }

        // List similar apps as suggestions
        const suggestions = apps
          .filter(a => a.searchText.includes(appName.charAt(0)))
          .slice(0, 5)
          .map(a => a.name);
        return {
          success: false,
          error: `Application "${params.name}" not found on this system.`,
          hint: suggestions.length > 0
            ? `Similar apps: ${suggestions.join(', ')}`
            : 'No similar apps found. The user may need to install it first.',
        };
      }

      // Launch the app detached
      try {
        const execLine = String(match.exec || '').trim();
        if (!execLine) {
          return { success: false, error: `Failed to launch ${match.name}: empty launch command` };
        }

        const normalizedExec = execLine.replace(/^"+|"+$/g, '');
        if (process.platform !== 'win32' && /^[A-Za-z]:\\/.test(normalizedExec)) {
          return { success: false, error: `Failed to launch ${match.name}: Windows path detected on non-Windows runtime` };
        }

        let launchCommand = normalizedExec;
        let launchArgs = [];
        if (process.platform === 'win32') {
          const isPathLike = /^(?:[A-Za-z]:\\|\\\\|\.{1,2}[\\/])/.test(normalizedExec);
          const isDirectFile = /\.(lnk|url|exe|msi|cmd|bat)$/i.test(normalizedExec);
          if (!(isPathLike && isDirectFile)) {
            const execParts = _splitExecLine(normalizedExec);
            if (execParts.length === 0) {
              return { success: false, error: `Failed to launch ${match.name}: invalid launch command` };
            }
            launchCommand = execParts[0];
            launchArgs = execParts.slice(1);
          }
        } else {
          const execParts = _splitExecLine(normalizedExec);
          if (execParts.length === 0) {
            return { success: false, error: `Failed to launch ${match.name}: invalid launch command` };
          }
          launchCommand = execParts[0];
          launchArgs = execParts.slice(1);
        }

        const imageName = _inferWindowsImageName(launchCommand);
        const beforePids = process.platform === 'win32'
          ? _getWindowsProcessPids(imageName)
          : new Set();
        await _spawnDetached(launchCommand, launchArgs, {
          env: { ...process.env },
        });
        const verification = process.platform === 'win32'
          ? await _verifyWindowsLaunch(launchCommand, beforePids, 2000, { imageName })
          : { verified: true, mode: 'spawn' };
        const output = _formatLaunchOutput(match.name, match.bin, verification);
        return {
          success: true,
          verified: !!verification.verified,
          verification,
          output,
        };
      } catch (err) {
        if (process.platform === 'linux') {
          const fallback = await _launchLinuxDesktopEntry(match);
          if (fallback.launched) {
            const verification = { verified: true, mode: fallback.mode, launcher: fallback.hint };
            return {
              success: true,
              verified: true,
              verification,
              output: `已通过桌面入口启动: ${match.name} (${fallback.hint})`,
            };
          }
          const reason = fallback.error?.message || fallback.reason || 'desktop-entry-launch-failed';
          return { success: false, error: `Failed to launch ${match.name}: ${err.message}; fallback failed: ${reason}` };
        }
        return { success: false, error: `Failed to launch ${match.name}: ${err.message}` };
      }
    },
  },
  {
    name: 'import_model',
    description: 'Import a local model file/directory or download from URL. Supports: .gguf, .safetensors, .zip archives, model directories. Auto-detects format, extracts archives, patches for llama.cpp compatibility, validates, and registers with Ollama.',
    category: 'ai',
    risk: 'medium',
    parameters: {
      source: { type: 'string', required: true, description: 'Local file/directory path or download URL' },
      name: { type: 'string', required: false, description: 'Target model name (auto-derived if omitted)' },
      base: { type: 'string', required: false, description: 'Base model for adapter imports' },
    },
    handler: async (params) => {
      const modelImport = require('./modelImportService');
      const source = String(params.source || '').trim();
      if (!source) return { success: false, error: 'No source path or URL provided' };
      const result = await modelImport.importModel(source, {
        name: params.name,
        base: params.base,
      });
      if (result.success) {
        return {
          success: true,
          output: `Model imported: ${result.model} (${result.sourceKind})\nSteps: ${(result.steps || []).join(' → ')}`,
          model: result.model,
        };
      }
      return { success: false, error: result.error, steps: result.steps };
    },
  },
  {
    name: 'download_model',
    description: 'Download a model from a URL (HuggingFace, ModelScope, GitHub, direct links). Auto-detects format and imports after download.',
    category: 'ai',
    risk: 'medium',
    parameters: {
      url: { type: 'string', required: true, description: 'Model download URL' },
      name: { type: 'string', required: false, description: 'Target model name (auto-derived if omitted)' },
    },
    handler: async (params) => {
      const modelImport = require('./modelImportService');
      const url = String(params.url || '').trim();
      if (!url) return { success: false, error: 'No URL provided' };
      const result = await modelImport.importFromUrl(url, { name: params.name });
      if (result.success) {
        return {
          success: true,
          output: `Model downloaded and imported: ${result.model} (${result.sourceKind})\nSteps: ${(result.steps || []).join(' → ')}`,
          model: result.model,
        };
      }
      return { success: false, error: result.error, steps: result.steps };
    },
  },
  {
    name: 'list_models',
    description: 'List all models on this computer: imported KHY/Ollama models and local model files found on disk. Shows model name, size, format, location, and import status.',
    category: 'ai',
    risk: 'low',
    parameters: {},
    handler: async () => {
      const modelImport = require('./modelImportService');
      const all = await modelImport.listAllModels();

      const lines = [];
      if (all.khyModels.length) {
        lines.push('=== KHY/Ollama 已导入模型 ===');
        for (const m of all.khyModels) {
          lines.push(`  ✓ ${m.name}  ${m.size}  ${m.family}  ${m.quantization || ''}`);
        }
      } else {
        lines.push('=== KHY/Ollama 已导入模型 === (无)');
      }

      lines.push('');
      if (all.localModels.length) {
        lines.push('=== 本地模型文件 ===');
        for (const m of all.localModels) {
          const tag = m.imported ? '[已导入]' : '[未导入]';
          lines.push(`  ${tag} ${m.name}  ${m.sizeStr}  ${m.format}  📂 ${m.path}`);
        }
      } else {
        lines.push('=== 本地模型文件 === (未发现)');
      }

      if (all.ideModels && all.ideModels.length) {
        lines.push('');
        lines.push('=== IDE 可用模型 ===');
        for (const m of all.ideModels) {
          lines.push(`  ${m.source}/${m.name}  (路由: ${m.route})`);
        }
        lines.push(`提示: 通过 gateway proxy (localhost:${process.env.PROXY_PORT || '9100'}/v1) 可作为 OpenAI API 使用`);
      }

      return {
        success: true,
        output: lines.join('\n'),
        khyCount: all.khyModels.length,
        localCount: all.localModels.length,
        ideCount: (all.ideModels || []).length,
      };
    },
  },
  {
    name: 'export_ollama_model',
    description: 'Export a model from Ollama to a local GGUF file for KHY use. Creates a symlink or copy in the KHY models directory.',
    category: 'ai',
    risk: 'medium',
    parameters: {
      model: { type: 'string', required: true, description: 'Ollama model name (e.g. qwen3.5:4b)' },
      dest: { type: 'string', required: false, description: 'Destination directory (default: KHY models/)' },
    },
    handler: async (params) => {
      const modelImport = require('./modelImportService');
      const model = String(params.model || '').trim();
      if (!model) return { success: false, error: 'No model name provided' };
      const result = await modelImport.exportFromOllama(model, params.dest);
      if (result.success) {
        return { success: true, output: `Exported: ${result.model} → ${result.path} (${result.sizeMB} MB)` };
      }
      return { success: false, error: result.error };
    },
  },
  {
    name: 'shell_command',
    description: 'Execute a shell command',
    category: 'system',
    risk: 'critical',
    parameters: {
      command: { type: 'string', required: true, description: 'Shell command to run' },
    },
    handler: async (params) => {
      // Block shell commands that could read khy OS protected source
      const cmd = params.command;
      let commandToRun = cmd;
      try {
        const { isProtectedPath } = require('./selfOptimizer');
        const khyRoot = path.resolve(__dirname, '../..');
        // Block: cat/less/head/tail/grep/find on KHY source dirs
        const readPatterns = /\b(cat|less|head|tail|more|strings|xxd|hexdump)\s/;
        if (readPatterns.test(cmd)) {
          const pathMatch = cmd.match(/\s(\/\S+|\.\.\/\S+|\.\S+)/);
          if (pathMatch) {
            const target = path.resolve(process.env.KHYQUANT_CWD || process.cwd(), pathMatch[1]);
            if (isProtectedPath(target)) {
              return { success: false, error: 'Access denied: Cannot read khy OS core source files via shell' };
            }
          }
        }
        // Block any command referencing KHY backend/src or frontend/src directly
        if (cmd.includes(path.join(khyRoot, 'backend', 'src')) || cmd.includes(path.join(khyRoot, 'frontend', 'src'))) {
          return { success: false, error: 'Access denied: khy OS source directories are protected' };
        }
      } catch {}
      // GUI / background commands: detect if the command is a GUI app and
      // spawn it detached so it doesn't block and timeout.
      // Instead of a hardcoded list, we detect GUI apps dynamically:
      //   1. Check if the binary has a .desktop file (standard Linux GUI registration)
      //   2. Check if it's a known GUI launcher command
      //   3. Fall back to checking if the binary links against display libraries
      if (process.platform !== 'win32') {
        const cmdBin = cmd.trim().split(/\s+/)[0];
        const isGuiApp = _isGuiApplication(cmdBin);
        if (isGuiApp) {
          if (process.platform === 'linux' && !_hasGraphicalSession()) {
            return {
              success: false,
              error: 'No graphical session detected (DISPLAY/WAYLAND_DISPLAY is not set). Unable to open GUI applications from this terminal session.',
            };
          }
          try {
            const { spawn } = require('child_process');
            const parts = cmd.trim().split(/\s+/);
            const child = spawn(parts[0], parts.slice(1), {
              detached: true,
              stdio: 'ignore',
              env: { ...process.env },
            });
            child.unref();
            return { success: true, output: `已在后台启动: ${cmd}` };
          } catch (spawnErr) {
            return { success: false, error: spawnErr.message };
          }
        }
      }

      if (process.platform === 'win32' && _looksLikePowerShellCommand(cmd)) {
        const psBin = _commandExists('pwsh') ? 'pwsh' : 'powershell';
        const escaped = String(cmd || '').replace(/'/g, "''");
        commandToRun = `${psBin} -NoProfile -ExecutionPolicy Bypass -Command '${escaped}'`;
      }

      // Route through sandbox classification — block/warn on dangerous/critical commands
      let _sandboxRoute = null;
      try {
        const { routeCommand } = require('../services/toolSandbox');
        // When dangerousMode is active (bridge/direct mode, or user-enabled),
        // auto-approve dangerous commands to prevent false-positive blocks.
        _sandboxRoute = routeCommand(commandToRun, { autoApprove: _dangerousMode });
        if (_sandboxRoute.executor === 'blocked') {
          return {
            success: false,
            error: _sandboxRoute.approvalPrompt || `Blocked: command classified as ${_sandboxRoute.tier}`,
            hint: `Use the approval system to unlock: tier=${_sandboxRoute.tier}, rule=${_sandboxRoute.matchedRule}`,
            _permissionTier: { tier: _sandboxRoute.tier, matchedRule: _sandboxRoute.matchedRule, approved: false },
          };
        }
        if (_sandboxRoute.executor === 'pending' && _sandboxRoute.needsApproval) {
          return {
            success: false,
            error: _sandboxRoute.approvalPrompt || `This command requires user approval (tier: ${_sandboxRoute.tier})`,
            hint: 'Ask the user for confirmation before executing dangerous commands.',
            needsApproval: true,
            tier: _sandboxRoute.tier,
            _permissionTier: { tier: _sandboxRoute.tier, matchedRule: _sandboxRoute.matchedRule, approved: false },
          };
        }
      } catch { /* toolSandbox not available, continue without routing */ }

      const { safeExec } = require('../services/resourceGuard');
      const result = safeExec(commandToRun);
      if (result.exitCode !== 0) {
        const stderr = result.stderr || '';
        if (/fork:\s*retry:\s*Resource temporarily unavailable/i.test(stderr)) {
          // Auto-fallback: if the command looks like an app-launch probe or
          // a direct app invocation, try open_app before returning the error.
          const cmdBin = cmd.trim().split(/\s+/)[0];
          if (_looksLikeShellAppProbe(cmd) || _isGuiApplication(cmdBin)) {
            const appTarget = _extractAppTargetFromCommand(cmd);
            if (appTarget) {
              try {
                const openAppTool = BUILTIN_TOOLS.find(t => t.name === 'open_app')
                  || (module.exports.BUILTIN_TOOLS || []).find(t => t.name === 'open_app');
                if (openAppTool) {
                  const fallbackResult = await openAppTool.handler({ name: appTarget });
                  if (fallbackResult && fallbackResult.success) {
                    return {
                      ...fallbackResult,
                      hint: `Shell fork limited; auto-fallback to open_app("${appTarget}") succeeded.`,
                    };
                  }
                }
              } catch { /* fallback failed, return original error */ }
            }
          }
          return {
            success: false,
            output: result.stdout,
            exitCode: result.exitCode,
            error: {
              code: 'executor_unavailable',
              message: 'Shell executor cannot fork subprocesses right now.',
              hint: 'This often indicates adapter/sandbox executor constraints, not confirmed host resource exhaustion. Prefer intent-native tools such as open_app, or retry/switch adapter.',
              retryable: true,
            },
            hint: 'Do not conclude host resource exhaustion from this signal alone.',
          };
        }
        const cmdBin = cmd.trim().split(/\s+/)[0];
        // Detect "command not found" and provide helpful install hints
        if (/command not found|No such file|not recognized/.test(stderr)) {
          const installHint = process.platform === 'win32'
            ? `Search/install with: winget search ${cmdBin}, choco search ${cmdBin}, npm install -g ${cmdBin}, pip install ${cmdBin}.`
            : `Search/install with: apt search ${cmdBin}, snap find ${cmdBin}, flatpak search ${cmdBin}, pip install ${cmdBin}, npm install -g ${cmdBin}.`;
          return {
            success: false,
            output: result.stdout,
            error: stderr,
            exitCode: result.exitCode,
            hint: `"${cmdBin}" is not installed. You can help the user install it. `
              + `${installHint} `
              + `Or search online: https://github.com/search?q=${encodeURIComponent(cmdBin)} , `
              + `https://www.google.com/search?q=${encodeURIComponent(cmdBin + ' install')} . `
              + `ASK the user before installing anything.`,
          };
        }
        return { success: false, output: result.stdout, error: stderr, exitCode: result.exitCode };
      }
      return {
        success: true,
        output: result.stdout,
        ...(_sandboxRoute ? { _permissionTier: { tier: _sandboxRoute.tier, matchedRule: _sandboxRoute.matchedRule, approved: true } } : {}),
      };
    },
  },
  {
    name: 'read_file',
    description: 'Read contents of a file',
    category: 'filesystem',
    risk: 'low',
    parameters: {
      path: { type: 'string', required: true },
    },
    handler: async (params) => {
      // Block access to khy OS protected source files
      const filePath = expandPath(params.path);
      try {
        const { isProtectedPath } = require('./selfOptimizer');
        if (isProtectedPath(filePath)) {
          return { success: false, error: 'Access denied: khy OS core source files are protected' };
        }
      } catch {}
      const content = fs.readFileSync(filePath, 'utf-8');
      return { success: true, content: content.slice(0, 10000), path: filePath };
    },
  },
  {
    name: 'write_file',
    description: 'Write content to a file',
    category: 'filesystem',
    risk: 'high',
    parameters: {
      path: { type: 'string', required: true },
      content: { type: 'string', required: true },
    },
    handler: async (params) => {
      // Block writes to khy OS protected source files
      const filePath = expandPath(params.path);
      try {
        const { isProtectedPath } = require('./selfOptimizer');
        if (isProtectedPath(filePath)) {
          return { success: false, error: 'Access denied: Cannot modify khy OS core source files' };
        }
      } catch {}
      // Auto-create parent directories
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(filePath, params.content, 'utf-8');
      return { success: true, path: filePath };
    },
  },
  {
    name: 'strategy_list',
    description: 'List available trading strategies',
    category: 'data',
    risk: 'safe',
    parameters: {},
    handler: async () => {
      try {
        const { Strategy } = require('../models');
        const strategies = await Strategy.findAll({ raw: true });
        return { success: true, strategies };
      } catch {
        return { success: false, error: 'Database not available' };
      }
    },
  },
  {
    name: 'web_search',
    description: 'Search the web for current information (news, docs, prices, tech specs, etc.)',
    category: 'data',
    risk: 'safe',
    parameters: {
      query: { type: 'string', required: true, description: 'Search query (max 200 characters)' },
    },
    handler: async (params) => {
      const webSearch = require('./webSearchService');
      return webSearch.search(params.query);
    },
  },
  // ── Git tools ──
  {
    name: 'git_status',
    description: 'Show git repository status (staged, modified, untracked files)',
    category: 'git',
    risk: 'safe',
    parameters: {},
    handler: async () => {
      const { execSync } = require('child_process');
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      const output = execSync('git status', { cwd, timeout: 5000, encoding: 'utf-8' });
      return { success: true, output };
    },
  },
  {
    name: 'git_diff',
    description: 'Show staged and unstaged changes',
    category: 'git',
    risk: 'safe',
    parameters: {
      staged: { type: 'boolean', required: false, description: 'Show only staged changes' },
    },
    handler: async (params) => {
      const { execSync } = require('child_process');
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      const cmd = params.staged ? 'git diff --cached' : 'git diff';
      const output = execSync(cmd, { cwd, timeout: 10000, encoding: 'utf-8' });
      return { success: true, output: output.slice(0, 10000) };
    },
  },
  {
    name: 'git_log',
    description: 'Show recent commit history',
    category: 'git',
    risk: 'safe',
    parameters: {
      count: { type: 'number', required: false, description: 'Number of commits (default 10)' },
    },
    handler: async (params) => {
      const { execSync } = require('child_process');
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      const n = Math.min(params.count || 10, 50);
      const output = execSync(`git log --oneline -${n}`, { cwd, timeout: 5000, encoding: 'utf-8' });
      return { success: true, output };
    },
  },
  {
    name: 'git_add',
    description: 'Stage files for commit',
    category: 'git',
    risk: 'low',
    parameters: {
      files: { type: 'string', required: true, description: 'File paths to stage (space-separated, or "." for all)' },
    },
    handler: async (params) => {
      const { execSync } = require('child_process');
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      execSync(`git add ${params.files}`, { cwd, timeout: 5000, encoding: 'utf-8' });
      return { success: true, output: `Staged: ${params.files}` };
    },
  },
  {
    name: 'git_commit',
    description: 'Create a git commit with a message',
    category: 'git',
    risk: 'medium',
    parameters: {
      message: { type: 'string', required: true, description: 'Commit message' },
    },
    handler: async (params) => {
      const { execSync } = require('child_process');
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      // Escape double quotes in message
      const msg = params.message.replace(/"/g, '\\"');
      const output = execSync(`git commit -m "${msg}"`, { cwd, timeout: 10000, encoding: 'utf-8' });
      return { success: true, output };
    },
  },
  {
    name: 'git_push',
    description: 'Push commits to remote repository',
    category: 'git',
    risk: 'high',
    parameters: {
      remote: { type: 'string', required: false, description: 'Remote name (default: origin)' },
      branch: { type: 'string', required: false, description: 'Branch name' },
    },
    handler: async (params) => {
      const { execSync } = require('child_process');
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      const remote = params.remote || 'origin';
      const branch = params.branch || '';
      const output = execSync(`git push ${remote} ${branch}`.trim(), { cwd, timeout: 30000, encoding: 'utf-8' });
      return { success: true, output };
    },
  },
  {
    name: 'git_branch',
    description: 'List or create branches',
    category: 'git',
    risk: 'low',
    parameters: {
      name: { type: 'string', required: false, description: 'New branch name (omit to list)' },
    },
    handler: async (params) => {
      const { execSync } = require('child_process');
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      const cmd = params.name ? `git branch ${params.name}` : 'git branch -a';
      const output = execSync(cmd, { cwd, timeout: 5000, encoding: 'utf-8' });
      return { success: true, output };
    },
  },
  {
    name: 'git_checkout',
    description: 'Switch to a branch or restore files',
    category: 'git',
    risk: 'medium',
    parameters: {
      target: { type: 'string', required: true, description: 'Branch name or file path' },
    },
    handler: async (params) => {
      const { execSync } = require('child_process');
      const cwd = process.env.KHYQUANT_CWD || process.cwd();
      const output = execSync(`git checkout ${params.target}`, { cwd, timeout: 5000, encoding: 'utf-8' });
      return { success: true, output };
    },
  },
  // ── Self-optimization tools ──
  {
    name: 'optimize_config',
    description: 'Safely update AI configuration (system prompt, agent roles, prompt library). Hot-update, no restart needed.',
    category: 'optimization',
    risk: 'medium',
    parameters: {
      target: { type: 'string', required: true, description: 'Config target: system_prompt | agent_roles | prompt_library' },
      content: { type: 'string', required: true, description: 'New content for the config' },
      reason: { type: 'string', required: true, description: 'Why this optimization' },
    },
    handler: async (params) => {
      const optimizer = require('./selfOptimizer');
      return optimizer.applyOptimization(params.target, params.content, params.reason);
    },
  },
  {
    name: 'propose_code_change',
    description: 'Propose a source code change via git branch (requires user review, does not affect running code)',
    category: 'optimization',
    risk: 'high',
    parameters: {
      file_path: { type: 'string', required: true, description: 'Absolute path to the source file' },
      content: { type: 'string', required: true, description: 'Proposed new file content' },
      description: { type: 'string', required: true, description: 'What was changed and why' },
    },
    handler: async (params) => {
      const optimizer = require('./selfOptimizer');
      return optimizer.proposeCodeChange(params.file_path, params.content, params.description);
    },
  },
];

// State
let _dangerousMode = false;
let _permissions = null;
let _mcpServers = [];
let _allTools = [...BUILTIN_TOOLS];

// Register chain_run tool (LangChain-compatible chain execution)
try {
  const chainWasm = require('./chainWasm');
  _allTools.push({
    name: 'chain_run',
    description: 'Execute a LangChain-compatible chain by name. Available chains: echo, template, react-parse.',
    category: 'ai',
    risk: 'low',
    parameters: {
      chain: { type: 'string', description: 'Chain name (echo, template, react-parse)', required: true },
      input: { type: 'string', description: 'Input text for the chain', required: true },
      template: { type: 'string', description: 'Prompt template with {key} placeholders (for template chain)' },
      keys: { type: 'array', description: 'Placeholder key names (for template chain)' },
      values: { type: 'array', description: 'Placeholder values (for template chain)' },
    },
    handler: async (params) => {
      const { chain, input, template, keys, values } = params || {};
      if (!chain) return { error: 'Missing chain name' };
      if (!input) return { error: 'Missing input' };
      if (chain === 'echo') {
        const tmpl = template || 'echo: {input}';
        return { output: chainWasm.renderTemplate(tmpl, ['input'], [input]) };
      }
      if (chain === 'react-parse') {
        return { output: chainWasm.parseReactResponse(input) };
      }
      if (chain === 'template') {
        const tmpl = template || '{input}';
        const k = keys || ['input'];
        const v = values || [input];
        return { output: chainWasm.renderTemplate(tmpl, k, v) };
      }
      return { error: `Unknown chain: ${chain}` };
    },
  });
} catch { /* chainWasm not available */ }

const _claudeCompatTools = getClaudeCompatToolList();

function _toolKey(name) {
  return String(name || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
}

function _toolNameVariants(name) {
  const raw = String(name || '').trim();
  if (!raw) return [];
  const variants = new Set([raw]);
  const snake = raw
    .replace(/([a-z])([A-Z])/g, '$1_$2')
    .replace(/[\s-]+/g, '_')
    .toLowerCase();
  const camel = snake.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
  variants.add(snake);
  variants.add(camel);
  variants.add(raw.toLowerCase());
  return [...variants].filter(Boolean);
}

function _getToolRegistry() {
  try {
    return require('../tools');
  } catch {
    return null;
  }
}

function _findBuiltinTool(name) {
  const variants = _toolNameVariants(name);
  for (const variant of variants) {
    const direct = _allTools.find(t => t.name === variant);
    if (direct) return direct;
  }
  const keys = new Set(variants.map(_toolKey));
  return _allTools.find(t => keys.has(_toolKey(t.name))) || null;
}

function _findRegistryTool(name) {
  const registry = _getToolRegistry();
  if (!registry) return null;

  const variants = _toolNameVariants(name);
  for (const variant of variants) {
    const direct = registry.get(variant);
    if (direct) return direct;
  }

  let allTools;
  try {
    allTools = registry.getAll();
  } catch {
    allTools = null;
  }
  if (!allTools || typeof allTools.values !== 'function') return null;

  const keys = new Set(variants.map(_toolKey));
  for (const tool of allTools.values()) {
    if (!tool) continue;
    if (keys.has(_toolKey(tool.name))) return tool;
    if (Array.isArray(tool.aliases) && tool.aliases.some((alias) => keys.has(_toolKey(alias)))) {
      return tool;
    }
  }
  return null;
}

function _findCompatTool(name) {
  const key = _toolKey(name);
  if (!key) return null;
  return _claudeCompatTools.find((tool) => (
    _toolKey(tool.name) === key || _toolKey(tool.canonical) === key
  )) || null;
}

function _resolveToolDescriptor(requestedName) {
  const normalizedName = normalizeToolName(requestedName) || requestedName;

  // Priority 1: Registry tools with alwaysLoad (newer, feature-rich implementations
  // like FileReadTool that support offset/limit, replacing legacy builtins)
  const registryTool = _findRegistryTool(normalizedName) || _findRegistryTool(requestedName);
  if (registryTool && registryTool.alwaysLoad) {
    return {
      source: 'registry',
      tool: registryTool,
      resolvedName: registryTool.name,
      requestedName,
      normalizedName,
    };
  }

  // Priority 2: Builtin tools (legacy, simple implementations)
  const builtinTool = _findBuiltinTool(normalizedName) || _findBuiltinTool(requestedName);
  if (builtinTool) {
    return {
      source: 'builtin',
      tool: builtinTool,
      resolvedName: builtinTool.name,
      requestedName,
      normalizedName,
    };
  }

  // Priority 3: Registry tools without alwaysLoad
  if (registryTool) {
    return {
      source: 'registry',
      tool: registryTool,
      resolvedName: registryTool.name,
      requestedName,
      normalizedName,
    };
  }

  // Priority 4: Claude compat tools (name mapping layer)
  const compatTool = _findCompatTool(normalizedName) || _findCompatTool(requestedName);
  if (compatTool) {
    return {
      source: 'compat',
      tool: compatTool,
      resolvedName: compatTool.canonical,
      requestedName,
      normalizedName,
    };
  }

  return null;
}

function _buildDirectoryListing(baseDir, relPath = '.', recursive = false, maxEntries = 200) {
  const out = [];
  const queue = [{ abs: baseDir, rel: relPath, depth: 0 }];

  while (queue.length > 0 && out.length < maxEntries) {
    const current = queue.shift();
    let entries;
    try {
      entries = fs.readdirSync(current.abs, { withFileTypes: true });
    } catch {
      continue;
    }

    entries.sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
      if (out.length >= maxEntries) break;
      const rel = path.join(current.rel, entry.name);
      const abs = path.join(current.abs, entry.name);
      out.push({
        name: entry.name,
        path: rel === '.' ? entry.name : rel,
        type: entry.isDirectory() ? 'directory' : 'file',
      });
      if (recursive && entry.isDirectory() && current.depth < 8 && !entry.name.startsWith('.')) {
        queue.push({ abs, rel: rel === '.' ? entry.name : rel, depth: current.depth + 1 });
      }
    }
  }
  return out;
}

async function _executeCompatTool(compatCanonicalName, params = {}, traceContext = {}) {
  const normalizedParams = normalizeToolParams(compatCanonicalName, params);
  const cwd = process.env.KHYQUANT_CWD || process.cwd();

  if (compatCanonicalName === 'ls') {
    const target = normalizedParams.path || '.';
    const abs = path.resolve(cwd, target);
    if (!fs.existsSync(abs)) {
      return { success: false, error: `Path not found: ${target}` };
    }
    const recursive = Boolean(normalizedParams.recursive);
    const maxEntries = Math.max(1, Math.min(Number(normalizedParams.max_entries) || 200, 2000));
    const entries = _buildDirectoryListing(abs, '.', recursive, maxEntries);
    return {
      success: true,
      path: abs,
      recursive,
      count: entries.length,
      entries,
      truncated: entries.length >= maxEntries,
    };
  }

  if (compatCanonicalName === 'multiEdit') {
    const filePath = normalizedParams.file_path || normalizedParams.path;
    const edits = Array.isArray(normalizedParams.edits) ? normalizedParams.edits : [];
    if (!filePath || edits.length === 0) {
      return { success: false, error: 'multiEdit requires file_path and non-empty edits[]' };
    }
    const editTool = _findRegistryTool('editFile') || _findBuiltinTool('editFile');
    if (!editTool) {
      return { success: false, error: 'editFile tool is unavailable' };
    }

    const applied = [];
    for (let i = 0; i < edits.length; i++) {
      const edit = edits[i];
      const editParams = {
        file_path: filePath,
        old_string: edit.old_string,
        new_string: edit.new_string,
        replace_all: Boolean(edit.replace_all),
      };
      const result = await editTool.execute(editParams, {});
      if (!result || !result.success) {
        return {
          success: false,
          error: result?.error || `multiEdit failed at edit index ${i}`,
          appliedCount: applied.length,
          failedIndex: i,
        };
      }
      applied.push({ index: i, replacements: result.replacements || 1 });
    }
    return {
      success: true,
      file: filePath,
      editsApplied: applied.length,
      details: applied,
    };
  }

  if (compatCanonicalName === 'todoWrite') {
    const items = Array.isArray(normalizedParams.todos) ? normalizedParams.todos : [];
    const normalized = items.map((item, index) => {
      if (typeof item === 'string') {
        return { id: `todo-${index + 1}`, content: item, status: 'pending' };
      }
      return {
        id: item.id || `todo-${index + 1}`,
        content: item.content || item.text || '',
        status: item.status || (item.done ? 'completed' : 'pending'),
        priority: item.priority || 'normal',
      };
    }).filter(t => t.content);

    let todoPath = '';
    const payload = JSON.stringify({
      updatedAt: new Date().toISOString(),
      todos: normalized,
    }, null, 2);
    const candidateDirs = [
      path.join(os.homedir(), '.khyquant'),
      path.join(cwd, '.khyquant'),
      path.join('/tmp', 'khyquant'),
    ];

    let lastWriteErr = null;
    for (const dir of candidateDirs) {
      try {
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        const candidate = path.join(dir, 'todo_state.json');
        fs.writeFileSync(candidate, payload, 'utf-8');
        todoPath = candidate;
        lastWriteErr = null;
        break;
      } catch (err) {
        lastWriteErr = err;
      }
    }
    if (!todoPath) {
      return { success: false, error: lastWriteErr?.message || 'Unable to persist todo state' };
    }

    try {
      const hud = require('../cli/hudRenderer');
      hud.updateTodos(normalized.map(t => ({ text: t.content, done: t.status === 'completed' })));
    } catch { /* best effort */ }

    return {
      success: true,
      path: todoPath,
      count: normalized.length,
      output: `Wrote ${normalized.length} todo item(s).`,
      todos: normalized,
    };
  }

  if (compatCanonicalName === 'webFetch') {
    const url = String(normalizedParams.url || '').trim();
    if (!/^https?:\/\//i.test(url)) {
      return { success: false, error: 'webFetch requires an http/https URL' };
    }
    const timeoutMs = Math.min(Math.max(Number(normalizedParams.timeout) || 15000, 1000), 60000);
    const maxChars = Math.min(Math.max(Number(normalizedParams.max_chars) || 20000, 1000), 200000);
    const { fetchWithSsrfGuard } = require('./fetchTimeout');
    let fetchFn = typeof fetch === 'function' ? fetch : null;
    if (!fetchFn) {
      try {
        const mod = await import('node-fetch');
        fetchFn = mod.default || mod;
      } catch {
        return { success: false, error: 'No fetch implementation available for webFetch' };
      }
    }

    const response = await fetchWithSsrfGuard((signal) => fetchFn(url, {
      method: 'GET',
      signal,
      headers: { 'user-agent': 'khy-compat-webfetch/1.0' },
    }), { url, timeoutMs, operation: 'webFetch' });

    const text = await response.text();
    const contentType = response.headers?.get ? response.headers.get('content-type') : '';
    return {
      success: true,
      url,
      status: response.status,
      contentType: contentType || '',
      content: text.length > maxChars ? `${text.slice(0, maxChars)}\n... [truncated ${text.length - maxChars} chars]` : text,
      truncated: text.length > maxChars,
    };
  }

  if (compatCanonicalName === 'spawnAgent') {
    const prompt = String(normalizedParams.prompt || '').trim();
    if (!prompt) return { success: false, error: 'spawn_agent requires message/prompt' };
    const { spawnWorker } = require('../coordinator/workerAgent');
    const role = normalizedParams.role || 'general';
    const timeoutMs = Math.max(1000, Math.min(Number(normalizedParams.timeout_ms || normalizedParams.timeout * 1000) || 120000, 3600000));
    const worker = await spawnWorker(prompt, { role, timeout: timeoutMs });
    return {
      success: true,
      agent_id: worker.id,
      status: worker.status,
      role: worker.role || role,
      message: `Spawned agent ${worker.id} (${worker.role || role})`,
    };
  }

  if (compatCanonicalName === 'sendInput') {
    const agentId = String(normalizedParams.agent_id || '').trim();
    const message = String(normalizedParams.message || '').trim();
    if (!agentId) return { success: false, error: 'send_input requires target/agent id' };
    if (!message) return { success: false, error: 'send_input requires message' };
    const { sendMessage, getWorkerStatus } = require('../coordinator/workerAgent');
    const worker = getWorkerStatus(agentId);
    if (!worker) return { success: false, error: `Agent ${agentId} not found` };
    const ok = sendMessage(agentId, message);
    return {
      success: ok,
      agent_id: agentId,
      status: worker.status,
      message: ok ? `Message queued for ${agentId}` : `Agent ${agentId} is ${worker.status}, cannot receive message`,
    };
  }

  if (compatCanonicalName === 'waitAgent') {
    const targets = Array.isArray(normalizedParams.targets)
      ? normalizedParams.targets.map(v => String(v).trim()).filter(Boolean)
      : [];
    if (targets.length === 0) return { success: false, error: 'wait_agent requires targets[]' };

    const timeoutMs = Math.max(1000, Math.min(Number(normalizedParams.timeout_ms) || 30000, 3600000));
    const pollMs = Math.max(100, Math.min(Number(normalizedParams.poll_ms) || 250, 2000));
    const terminal = new Set(['completed', 'error', 'stopped']);
    const { getWorkerStatus } = require('../coordinator/workerAgent');
    const start = Date.now();

    while (Date.now() - start < timeoutMs) {
      for (const id of targets) {
        const worker = getWorkerStatus(id);
        if (!worker) continue;
        if (terminal.has(worker.status)) {
          return {
            success: true,
            agent_id: id,
            status: worker.status,
            output: worker.result || '',
            error: worker.error || null,
            elapsed_ms: Date.now() - start,
          };
        }
      }
      await new Promise(resolve => setTimeout(resolve, pollMs));
    }

    return {
      success: true,
      timeout: true,
      status: null,
      elapsed_ms: Date.now() - start,
      pending_targets: targets,
    };
  }

  if (compatCanonicalName === 'closeAgent') {
    const agentId = String(normalizedParams.agent_id || '').trim();
    if (!agentId) return { success: false, error: 'close_agent requires target/agent id' };
    const { shutdownWorker, getWorkerStatus } = require('../coordinator/workerAgent');
    const worker = getWorkerStatus(agentId);
    if (!worker) return { success: false, error: `Agent ${agentId} not found` };
    const previousStatus = worker.status;
    const closed = shutdownWorker(agentId);
    const latest = getWorkerStatus(agentId);
    return {
      success: closed,
      agent_id: agentId,
      previous_status: previousStatus,
      status: latest?.status || previousStatus,
      message: closed ? `Agent ${agentId} closed` : `Failed to close ${agentId}`,
    };
  }

  if (compatCanonicalName === 'resumeAgent') {
    const agentId = String(normalizedParams.agent_id || '').trim();
    if (!agentId) return { success: false, error: 'resume_agent requires id' };
    const { getWorkerStatus } = require('../coordinator/workerAgent');
    const worker = getWorkerStatus(agentId);
    if (!worker) return { success: false, error: `Agent ${agentId} not found` };
    return {
      success: true,
      agent_id: agentId,
      status: worker.status,
      resumed: worker.status === 'running' || worker.status === 'pending',
      message: worker.status === 'running' || worker.status === 'pending'
        ? `Agent ${agentId} is active`
        : `Agent ${agentId} is ${worker.status}; resume is best-effort only`,
    };
  }

  if (compatCanonicalName === 'slashCommand') {
    const raw = String(normalizedParams.command || '').trim();
    if (!raw) {
      return { success: false, error: 'SlashCommand requires command' };
    }
    const args = Array.isArray(normalizedParams.args)
      ? normalizedParams.args.map(v => String(v)).filter(Boolean)
      : [];
    const slash = raw.startsWith('/') ? raw : `/${raw}`;
    const commandLine = [slash, ...args].join(' ').trim();

    try {
      const router = require('../cli/router');
      const parsed = router.parseInput(commandLine);
      const routeResult = await router.route(parsed);

      if (routeResult === false) {
        const lower = slash.toLowerCase();

        // Claude-style fallback commands that may not exist in static slash table.
        if (lower === '/status') {
          const ai = require('../cli/ai');
          await ai.handleAiStatus();
          return { success: true, command: commandLine, routeResult: 'ai-status' };
        }
        if (lower === '/config') {
          const ai = require('../cli/ai');
          await ai.handleAiConfig();
          return { success: true, command: commandLine, routeResult: 'ai-config' };
        }
        if (lower === '/new' || lower === '/clear') {
          const ai = require('../cli/ai');
          if (typeof ai.clearHistory === 'function') ai.clearHistory();
          return { success: true, command: commandLine, routeResult: 'history-cleared' };
        }
        if (lower === '/tools') {
          return {
            success: true,
            command: commandLine,
            routeResult: 'tools-list',
            tools: listTools(),
          };
        }

        return {
          success: false,
          error: `Unrecognized slash command: ${slash}`,
          command: commandLine,
        };
      }

      return {
        success: true,
        command: commandLine,
        routeResult,
      };
    } catch (err) {
      return {
        success: false,
        error: err.message || `Failed to execute slash command: ${commandLine}`,
        command: commandLine,
      };
    }
  }

  if (compatCanonicalName === 'notebookRead') {
    const pathArg = normalizedParams.path || normalizedParams.file_path;
    if (!pathArg) return { success: false, error: 'NotebookRead requires path' };
    const readTool = _findRegistryTool('readFile') || _findBuiltinTool('read_file');
    if (!readTool) return { success: false, error: 'readFile tool is unavailable' };
    return readTool.execute({ path: pathArg, offset: normalizedParams.offset, limit: normalizedParams.limit }, {});
  }

  if (compatCanonicalName === 'notebookEdit') {
    const pathArg = normalizedParams.file_path || normalizedParams.path;
    if (!pathArg) return { success: false, error: 'NotebookEdit requires path/file_path' };

    if (typeof normalizedParams.old_string === 'string') {
      const editTool = _findRegistryTool('editFile') || _findBuiltinTool('editFile');
      if (!editTool) return { success: false, error: 'editFile tool is unavailable' };
      return editTool.execute({
        file_path: pathArg,
        old_string: normalizedParams.old_string,
        new_string: normalizedParams.new_string || '',
        replace_all: Boolean(normalizedParams.replace_all),
      }, {});
    }

    if (typeof normalizedParams.content === 'string') {
      const writeTool = _findRegistryTool('writeFile') || _findBuiltinTool('write_file');
      if (!writeTool) return { success: false, error: 'writeFile tool is unavailable' };
      return writeTool.execute({ path: pathArg, content: normalizedParams.content }, {});
    }

    return { success: false, error: 'NotebookEdit requires either old_string/new_string or content' };
  }

  return { success: false, error: `Unsupported compatibility tool: ${compatCanonicalName}` };
}

/**
 * Load saved tool permissions.
 */
function loadPermissions() {
  if (_permissions) return _permissions;
  try {
    if (fs.existsSync(PERMISSIONS_FILE)) {
      _permissions = JSON.parse(fs.readFileSync(PERMISSIONS_FILE, 'utf-8'));
    }
  } catch { /* ignore */ }
  _permissions = _permissions || { approved: {}, denied: {}, dangerousAcknowledged: false };
  return _permissions;
}

/**
 * Save permissions to disk.
 */
function savePermissions() {
  try {
    const dir = path.dirname(PERMISSIONS_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(PERMISSIONS_FILE, JSON.stringify(_permissions, null, 2), 'utf-8');
  } catch { /* ignore */ }
}

/**
 * Enable dangerous mode (skip all confirmations).
 * Returns false if user hasn't acknowledged the warning yet.
 */
function enableDangerousMode() {
  const perms = loadPermissions();
  _dangerousMode = true;
  return perms.dangerousAcknowledged === true;
}

/**
 * Acknowledge dangerous mode warning (first-time).
 */
function acknowledgeDangerousMode() {
  const perms = loadPermissions();
  perms.dangerousAcknowledged = true;
  savePermissions();
  _dangerousMode = true;
}

function isDangerousMode() {
  return _dangerousMode;
}

function disableDangerousMode() {
  _dangerousMode = false;
}

/**
 * Check if a tool call is pre-approved.
 */
function isApproved(toolName) {
  const perms = loadPermissions();
  return perms.approved[toolName] === true;
}

/**
 * Pre-approve a tool (remember for session).
 */
function approveTool(toolName, persist = false) {
  const perms = loadPermissions();
  perms.approved[toolName] = true;
  if (persist) savePermissions();
}

/**
 * Get the risk level info for a tool.
 */
function getToolRisk(toolName) {
  const descriptor = _resolveToolDescriptor(toolName);
  if (!descriptor || !descriptor.tool) return RISK_LEVELS.medium;
  return RISK_LEVELS[descriptor.tool.risk] || RISK_LEVELS.medium;
}

/**
 * Format tool call for display to user (for confirmation prompt).
 */
function formatToolCall(toolName, params) {
  const descriptor = _resolveToolDescriptor(toolName);
  const tool = descriptor?.tool || null;
  const risk = getToolRisk(toolName);
  const riskColor = chalk()[risk.color] || chalk().yellow;

  let display = '';
  display += chalk().bold(`  🔧 工具调用: ${toolName}\n`);
  display += `  ${riskColor(`[${risk.label}]`)} ${tool?.description || ''}\n`;

  if (params && Object.keys(params).length > 0) {
    display += chalk().dim('  参数:\n');
    for (const [key, value] of Object.entries(params)) {
      const displayVal = typeof value === 'string' && value.length > 100
        ? value.slice(0, 100) + '...'
        : JSON.stringify(value);
      display += chalk().dim(`    ${key}: `) + displayVal + '\n';
    }
  }

  return display;
}

/**
 * Request user confirmation for a tool call.
 * Returns: 'allow' | 'allow-always' | 'deny'
 *
 * Interactive selection (Claude Code style):
 *   1. Yes             — Execute this time only
 *   2. Yes, always     — Permanently trust this tool
 *   3. No              — Refuse execution
 *   Esc to cancel · Tab to amend
 */
async function requestPermission(toolName, params) {
  const descriptor = _resolveToolDescriptor(toolName);
  const permissionKey = descriptor?.resolvedName || toolName;

  // Preflight batch approval — if tool was already approved in a batch, skip prompt
  if (_preflightContext && (_preflightContext.has(toolName) || _preflightContext.has(permissionKey))) return 'allow';

  // New permission store check (if enabled)
  if (process.env.KHY_PERMISSION_STORE !== 'false') {
    try {
      const permStore = require('./permissionStore');
      const tool = descriptor?.tool || _findBuiltinTool(permissionKey);
      // Resolve behavioral declarations if available from new tool registry
      let isReadOnly = false;
      let isDestructive = false;
      try {
        const registry = require('../tools');
        const regTool = registry.get(permissionKey);
        if (regTool) {
          isReadOnly = typeof regTool.isReadOnly === 'function' ? regTool.isReadOnly(params) : false;
          isDestructive = typeof regTool.isDestructive === 'function' ? regTool.isDestructive(params) : false;
        }
      } catch { /* registry not available */ }
      const decision = permStore.check(permissionKey, params, {
        risk: tool?.risk || 'medium',
        isReadOnly,
        isDestructive,
      });
      if (decision === 'allow') return 'allow';
      if (decision === 'deny') return 'deny';
      // decision === 'ask' → fall through to interactive prompt
    } catch { /* permissionStore not available — fall through */ }
  }

  // Auto-approve safe and low-risk read-only tools
  const tool = descriptor?.tool || _findBuiltinTool(permissionKey);
  if (tool && tool.risk === 'safe') return 'allow';
  if (tool && tool.risk === 'low') {
    // Low-risk tools (read_file, glob, grep, etc.) are auto-approved
    // unless they are dynamically destructive based on params
    let isDestructive = false;
    try {
      const registry = require('../tools');
      const regTool = registry.get(permissionKey);
      if (regTool && typeof regTool.isDestructive === 'function') {
        isDestructive = regTool.isDestructive(params);
      }
    } catch { /* registry not available */ }
    if (!isDestructive) return 'allow';
  }

  // Dangerous mode = auto-approve everything
  if (_dangerousMode) return 'allow';

  // Previously approved (persisted or session)
  if (isApproved(toolName) || isApproved(permissionKey)) return 'allow';

  // Enhanced permission dialog (if not legacy mode)
  if (process.env.KHY_LEGACY_PERMISSION_UI !== 'true') {
    try {
      const { formatPermissionDialog } = require('../cli/ui/permissionDialog');
      const riskInfo = getToolRisk(toolName);
      const reasoning = params._reasoning || '';
      const result = await formatPermissionDialog(toolName, params, riskInfo, reasoning);

      // Map result to legacy approval storage + permissionStore
      if (result === 'allow-always') {
        approveTool(permissionKey, true);
        try {
          const permStore = require('./permissionStore');
          permStore.approve(permissionKey, 'forever');
        } catch { /* best effort */ }
      } else if (result === 'allow') {
        try {
          const permStore = require('./permissionStore');
          permStore.approve(permissionKey, 'once');
        } catch { /* best effort */ }
      } else if (result === 'deny') {
        try {
          const permStore = require('./permissionStore');
          permStore.deny(permissionKey, 'session');
        } catch { /* best effort */ }
      }
      return result;
    } catch { /* dialog not available — fall through to legacy */ }
  }

  // Legacy text-based approval (original code)
  console.log('');
  console.log(formatToolCall(toolName, params));

  // Show reasoning if available
  if (params._reasoning) {
    console.log(chalk().dim('  💭 AI 思考:'));
    console.log(chalk().dim(`     ${params._reasoning}`));
    console.log('');
  }

  // Interactive selection (Claude Code style)
  const riskInfo = getToolRisk(toolName);
  const question = chalk().yellow(`  Do you want to execute `) + chalk().bold(toolName) + chalk().yellow('?');
  console.log(question);
  console.log(`  ${chalk().white('❯ 1.')} ${chalk().green('Yes')}`);
  console.log(`    ${chalk().white('2.')} ${chalk().blue('Yes always')}`);
  console.log(`    ${chalk().white('3.')} ${chalk().red('No')}`);
  console.log('');
  console.log(chalk().dim('  Esc to cancel · Tab to amend'));

  const answer = await askUser(chalk().dim('  > '));
  const normalized = answer.trim().toLowerCase();

  switch (normalized) {
    case '1':
    case 'y':
    case 'yes':
    case '':
      return 'allow';

    case '2':
    case 'a':
    case 'always':
    case 'trust':
      approveTool(toolName, true); // Persist to disk
      console.log(chalk().green(`  ✓ Permanently trusted "${toolName}"`));
      return 'allow-always';

    case '3':
    case 'n':
    case 'no':
    case 'deny':
      console.log(chalk().red(`  ✗ Denied "${toolName}"`));
      return 'deny';

    // Backward-compatible aliases for previous "session trust" input
    case 's':
    case 'session':
      return 'allow';

    default:
      // Unknown input = deny for safety
      console.log(chalk().red(`  ✗ Unrecognized input, denied`));
      return 'deny';
  }
}

/**
 * Execute a tool call with permission checking.
 * Enhanced with permissionStore integration and audit logging.
 */
async function executeTool(toolName, params = {}, traceContext = {}) {
  const normalizedName = normalizeToolName(toolName) || toolName;
  const normalizedParams = _normalizePathLikeParams(
    normalizeToolParams(normalizedName, params)
  );
  const descriptor = _resolveToolDescriptor(normalizedName) || _resolveToolDescriptor(toolName);
  let traceAudit = null;
  try {
    traceAudit = require('./traceAuditService');
    traceAudit.ensureDiagnosticsBridge();
  } catch { /* trace audit optional */ }
  const traceCtx = {
    sessionId: traceContext?.sessionId || traceAudit?.getContext?.()?.sessionId || null,
    traceId: traceContext?.traceId || traceAudit?.getContext?.()?.traceId || null,
    role: traceContext?.role || traceAudit?.getContext?.()?.role || null,
    source: 'tool-calling',
    visibility: 'summary',
  };
  const onActivity = typeof traceContext?.onActivity === 'function'
    ? traceContext.onActivity
    : null;
  const onProgress = typeof traceContext?.onProgress === 'function'
    ? traceContext.onProgress
    : null;
  const emitActivity = (payload) => {
    if (!onActivity) return;
    try { onActivity(payload); } catch { /* non-critical */ }
  };
  const emitProgress = (payload) => {
    if (!onProgress) return;
    try { onProgress(payload); } catch { /* non-critical */ }
  };
  const wrapperStart = Date.now();
  const toolExecutionContext = {
    traceContext,
    onActivity: emitActivity,
    onProgress: emitProgress,
  };
  const emitWrapper = (phase, payload = {}, visibility = 'summary') => {
    try {
      if (!traceAudit || typeof traceAudit.logEvent !== 'function') return;
      traceAudit.logEvent(`tool.wrapper.${phase}`, payload, {
        ...traceCtx,
        visibility,
      });
    } catch { /* non-critical */ }
  };

  if (!descriptor) {
    emitWrapper('end', {
      tool: normalizedName || toolName,
      success: false,
      error: `Unknown tool: ${toolName}`,
      elapsedMs: Date.now() - wrapperStart,
    });
    try {
      const { ToolError } = require('./toolError');
      const names = listTools().map(t => t.name).slice(0, 14).join(', ');
      return new ToolError('TOOL_UNAVAILABLE', `Unknown tool: ${toolName}`, {
        hint: `Available tools: ${names}...`,
        recoverable: true,
        retryable: false,
      }).toStructuredResult();
    } catch {
      return { success: false, error: `Unknown tool: ${toolName}` };
    }
  }

  // Check permission
  const permissionKey = descriptor.resolvedName || normalizedName || toolName;
  emitWrapper('start', {
    tool: permissionKey,
    params: normalizedParams,
  });
  const permission = await requestPermission(permissionKey, normalizedParams);
  if (permission === 'deny') {
    emitWrapper('end', {
      tool: permissionKey,
      success: false,
      denied: true,
      permission: 'deny',
      elapsedMs: Date.now() - wrapperStart,
    });
    // Audit denied call
    try {
      const { logToolExecution } = require('./auditLog');
      logToolExecution({ tool: permissionKey, params: normalizedParams, result: { success: false }, permission: 'deny', elapsed: 0 });
    } catch { /* audit is non-critical */ }
    return { success: false, error: 'User denied tool execution', denied: true };
  }

  // Execute
  const start = Date.now();
  emitActivity({ phase: 'execute_start', tool: permissionKey });
  emitProgress(`Executing ${permissionKey}`);
  try {
    let result;
    if (descriptor.source === 'builtin') {
      result = await descriptor.tool.handler(normalizedParams, toolExecutionContext);
    } else if (descriptor.source === 'registry') {
      if (typeof descriptor.tool.validate === 'function') {
        const validation = descriptor.tool.validate(normalizedParams);
        if (!validation.valid) {
          return {
            success: false,
            error: `Validation failed: ${(validation.errors || []).join('; ')}`,
          };
        }
      }
      if (typeof descriptor.tool.validateInput === 'function') {
        const semantic = await descriptor.tool.validateInput(normalizedParams, toolExecutionContext);
        if (semantic && semantic.valid === false) {
          return {
            success: false,
            error: semantic.message || 'Semantic validation failed',
          };
        }
      }
      result = await descriptor.tool.execute(normalizedParams, toolExecutionContext);
    } else {
      result = await _executeCompatTool(descriptor.resolvedName, normalizedParams, traceContext);
    }

    // Wrap handler-returned error results as structured ToolError format
    if (result && result.success === false && result.error && typeof result.error === 'string') {
      try {
        const { ToolError } = require('./toolError');
        const wrapped = ToolError.fromGenericError(new Error(result.error));
        const structured = wrapped.toStructuredResult();
        // Preserve extra fields from original result (output, exitCode, etc.)
        Object.assign(structured, { output: result.output, exitCode: result.exitCode, denied: result.denied });
        // Audit
        try {
          const { logToolExecution } = require('./auditLog');
          logToolExecution({ tool: permissionKey, params: normalizedParams, result: structured, permission, elapsed: Date.now() - start });
        } catch { /* non-critical */ }
        emitWrapper('end', {
          tool: permissionKey,
          success: false,
          permission,
          elapsedMs: Date.now() - wrapperStart,
          error: structured.error || result.error,
        });
        return structured;
      } catch { /* toolError not available — return as-is */ }
    }
    // Audit successful call
    try {
      const { logToolExecution } = require('./auditLog');
      logToolExecution({ tool: permissionKey, params: normalizedParams, result, permission, elapsed: Date.now() - start });
    } catch { /* audit is non-critical */ }
    // Telemetry tracking
    try {
      const telemetry = require('./telemetryService');
      telemetry.trackToolCall({ tool: permissionKey, success: !!result.success, elapsed: Date.now() - start });
    } catch { /* telemetry is non-critical */ }
    emitWrapper('end', {
      tool: permissionKey,
      success: !!result?.success,
      permission,
      elapsedMs: Date.now() - wrapperStart,
      error: result?.success ? null : result?.error || null,
    });
    emitActivity({
      phase: 'execute_end',
      tool: permissionKey,
      success: !!result?.success,
      elapsedMs: Date.now() - start,
    });
    emitProgress(`${permissionKey} ${result?.success ? 'succeeded' : 'finished with error'}`);
    return result;
  } catch (err) {
    const elapsed = Date.now() - start;
    // Wrap as ToolError for structured error reporting
    let toolError;
    try {
      const { ToolError } = require('./toolError');
      toolError = ToolError.isToolError(err) ? err : ToolError.fromGenericError(err);
    } catch { toolError = null; }
    const structuredResult = toolError ? toolError.toStructuredResult() : { success: false, error: err.message };
    // Audit failed call
    try {
      const { logToolExecution } = require('./auditLog');
      logToolExecution({ tool: permissionKey, params: normalizedParams, result: structuredResult, permission, elapsed });
    } catch { /* audit is non-critical */ }
    try {
      const telemetry = require('./telemetryService');
      telemetry.trackToolCall({ tool: permissionKey, success: false, elapsed, error: err.message });
    } catch { /* telemetry is non-critical */ }
    emitWrapper('end', {
      tool: permissionKey,
      success: false,
      permission,
      elapsedMs: Date.now() - wrapperStart,
      error: err?.message || 'unknown error',
    });
    emitActivity({
      phase: 'execute_end',
      tool: permissionKey,
      success: false,
      elapsedMs: Date.now() - start,
      error: err?.message || 'unknown error',
    });
    emitProgress(`${permissionKey} failed`);
    return structuredResult;
  }
}

/**
 * Execute multiple tool calls in parallel (for concurrency-safe tools).
 * Each tool goes through full permission checking via executeTool().
 * Non-safe tools are executed sequentially after parallel batch completes.
 *
 * @param {Array<{name: string, params: object}>} calls - Tool calls to execute
 * @param {object} [options]
 * @param {function} [options.onResult] - Callback after each tool completes: (name, result, elapsed)
 * @returns {Promise<Array<{tool: string, params: object, result: object, elapsed: number}>>}
 */
async function executeToolsBatch(calls, options = {}) {
  if (!calls || calls.length === 0) return [];

  const { onResult } = options;
  const results = [];

  // Classify: concurrency-safe vs sequential
  const KNOWN_SAFE = new Set([
    'quote', 'data_fetch', 'search', 'strategy_list', 'web_search',
    'read_file', 'readFile', 'git_status', 'git_diff', 'git_log', 'tool_search',
    'grep', 'glob', 'ls', 'webSearch', 'webFetch', 'notebookRead',
  ]);

  const safeCalls = [];
  const unsafeCalls = [];

  for (const call of calls) {
    const normalizedName = normalizeToolName(call.name) || call.name;
    const normalizedParams = normalizeToolParams(normalizedName, call.params || {});
    const normalizedCall = { ...call, name: normalizedName, params: normalizedParams };

    // Try dynamic check from registry
    let isSafe = false;
    try {
      const registry = require('../tools');
      const regTool = registry.get(normalizedName);
      if (regTool && typeof regTool.isConcurrencySafe === 'function') {
        isSafe = regTool.isConcurrencySafe(normalizedParams);
      } else {
        isSafe = KNOWN_SAFE.has(normalizedName) || KNOWN_SAFE.has(call.name);
      }
    } catch {
      isSafe = KNOWN_SAFE.has(normalizedName) || KNOWN_SAFE.has(call.name);
    }

    if (isSafe) {
      safeCalls.push(normalizedCall);
    } else {
      unsafeCalls.push(normalizedCall);
    }
  }

  // Execute safe tools in parallel
  if (safeCalls.length > 0) {
    const promises = safeCalls.map(async (call) => {
      const start = Date.now();
      let result;
      try {
        result = await executeTool(call.name, call.params);
      } catch (err) {
        result = { success: false, error: err.message };
      }
      const elapsed = Date.now() - start;
      if (onResult) onResult(call.name, result, elapsed);
      return { tool: call.name, params: call.params, result, elapsed };
    });

    const settled = await Promise.allSettled(promises);
    for (const s of settled) {
      if (s.status === 'fulfilled') {
        results.push(s.value);
      } else {
        results.push({ tool: 'unknown', params: {}, result: { success: false, error: s.reason?.message || 'Promise rejected' }, elapsed: 0 });
      }
    }
  }

  // Execute unsafe tools sequentially
  for (const call of unsafeCalls) {
    const start = Date.now();
    let result;
    try {
      result = await executeTool(call.name, call.params);
    } catch (err) {
      result = { success: false, error: err.message };
    }
    const elapsed = Date.now() - start;
    if (onResult) onResult(call.name, result, elapsed);
    results.push({ tool: call.name, params: call.params, result, elapsed });
  }

  return results;
}

/**
 * Get the tool definitions in Claude/OpenAI function-calling format.
 * Used when sending messages to AI models that support tool use.
 */
function getToolDefinitions() {
  const defs = _allTools.map(tool => ({
    name: tool.name,
    description: tool.description,
    parameters: {
      type: 'object',
      properties: Object.fromEntries(
        Object.entries(tool.parameters || {}).map(([key, spec]) => [
          key,
          { type: spec.type || 'string', description: spec.description || '' },
        ])
      ),
      required: Object.entries(tool.parameters || {})
        .filter(([, spec]) => spec.required)
        .map(([key]) => key),
    },
  }));

  const registry = _getToolRegistry();
  if (registry && typeof registry.getDefinitions === 'function') {
    try {
      defs.push(...registry.getDefinitions());
    } catch { /* best effort */ }
  }

  defs.push(...getClaudeCompatToolDefinitions());

  const seen = new Set();
  const deduped = [];
  for (const def of defs) {
    const key = String(def?.name || '').trim();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    deduped.push(def);
  }
  return deduped;
}

/**
 * Register an MCP server connection.
 */
function registerMCPServer(server) {
  _mcpServers.push(server);
  // Register MCP tools into the tool registry
  if (server.tools) {
    for (const tool of server.tools) {
      _allTools.push({
        name: `mcp_${server.name}_${tool.name}`,
        description: `[MCP:${server.name}] ${tool.description}`,
        category: 'mcp',
        risk: 'medium',
        parameters: tool.inputSchema?.properties || {},
        handler: async (params) => {
          return server.callTool(tool.name, params);
        },
      });
    }
  }
}

/**
 * Register a custom tool (from plugin or skill).
 */
function registerTool(tool) {
  if (!tool.name || !tool.handler) throw new Error('Tool must have name and handler');
  tool.risk = tool.risk || 'medium';
  tool.category = tool.category || 'custom';
  _allTools.push(tool);
}

/**
 * List all registered tools.
 */
function listTools() {
  const list = _allTools.map(t => ({
    name: t.name,
    description: t.description,
    category: t.category,
    risk: t.risk,
  }));

  const registry = _getToolRegistry();
  if (registry) {
    try {
      const all = registry.getAll();
      if (all && typeof all.values === 'function') {
        for (const tool of all.values()) {
          list.push({
            name: tool.name,
            description: tool.description,
            category: tool.category,
            risk: tool.risk,
          });
        }
      }
    } catch { /* best effort */ }
  }

  list.push(..._claudeCompatTools);

  const seen = new Set();
  const deduped = [];
  for (const item of list) {
    const key = String(item?.name || '').trim();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    deduped.push(item);
  }
  return deduped;
}

/**
 * Get MCP servers.
 */
function getMCPServers() {
  return _mcpServers;
}

// ── Helper ──

// External readline provider — injected by REPL so permission prompts
// don't conflict with the active readline interface
let _rlProvider = null;

// Preflight context — set of tool names pre-approved in batch
let _preflightContext = null;

function setPreflightContext(approvedSet) { _preflightContext = approvedSet; }
function clearPreflightContext() { _preflightContext = null; }

function setReadlineProvider(rlOrFn) {
  _rlProvider = rlOrFn;
}

function getReadlineProvider() {
  return _rlProvider;
}

function askUser(prompt) {
  return new Promise((resolve) => {
    // If a REPL readline is active, use it directly (avoids stdin conflict)
    const rl = typeof _rlProvider === 'function' ? _rlProvider() : _rlProvider;
    if (rl && typeof rl.question === 'function') {
      rl.question(prompt, (answer) => {
        resolve(answer);
      });
      return;
    }

    // Fallback: create a temporary readline (works in standalone/non-REPL context)
    const tempRl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    tempRl.question(prompt, (answer) => {
      tempRl.close();
      resolve(answer);
    });
  });
}

module.exports = {
  // Core
  executeTool,
  executeToolsBatch,
  getToolDefinitions,
  listTools,
  formatToolCall,

  // Permissions
  requestPermission,
  enableDangerousMode,
  disableDangerousMode,
  isDangerousMode,
  acknowledgeDangerousMode,
  approveTool,
  isApproved,
  setReadlineProvider,
  getReadlineProvider,
  setPreflightContext,
  clearPreflightContext,

  // Registration
  registerTool,
  registerMCPServer,
  getMCPServers,

  // Bridge to new tool registry
  getToolRegistry: () => { try { return require('../tools'); } catch { return null; } },

  // Constants
  RISK_LEVELS,
  BUILTIN_TOOLS,

  // App launching helpers (reused by adapters)
  APP_ALIAS_MAP,
  _normalizeAppQuery,
  _buildAppCandidates,
};
