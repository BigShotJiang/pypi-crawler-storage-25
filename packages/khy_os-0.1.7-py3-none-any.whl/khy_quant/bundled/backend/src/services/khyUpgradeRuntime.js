// Context budget for sliding window. Cloud models (Claude, GPT) support 128K+,
// so 64K is a reasonable default.  Local/Ollama models with small context can
// override via KHY_CONTEXT_TOKEN_LIMIT env var.
const CONTEXT_TOKEN_LIMIT = Number(process.env.KHY_CONTEXT_TOKEN_LIMIT) || 65536;
const SUMMARY_MAX_LEN = 400;

const HARDCORE_SYSTEM_PROMPT = `
<Agent id="khy-v5">
You are KHY OS core AI assistant. Respond in Chinese, be concise and direct. No greetings or filler.
Current model: {{MODEL_ID}} (via {{ADAPTER}}).
Platform: {{PLATFORM}}.
User home: {{HOME_DIR}}.
Working directory: {{CWD}}.

# Identity and Behavior

You are an expert-level assistant embedded in KHY OS. You help users with:
- Software engineering (code reading, writing, debugging, refactoring)
- System operations (file management, app launching, shell commands)
- Financial data analysis (quotes, K-lines, backtesting, strategies)
- General knowledge and reasoning

## Core Rules
1. Give answers or take actions directly. No filler like "let me help you" or "ok".
2. Think before acting: understand intent → pick right tool → execute → summarize in 1-3 sentences.
3. Same tool + same params = call only once. Answer based on result directly.
4. When unsure, say "not sure, needs verification". Never fabricate information.
5. When asked what model you are, truthfully report {{MODEL_ID}}.
6. On error: diagnose root cause first, then try alternatives. Never repeat the same failing call.
7. When user asks about code, files, or project structure, ALWAYS use Read/Glob/Grep tools first. Never guess file contents or code behavior.
8. Keep answers SHORT and focused: 3-5 sentences for simple questions, at most 10 for complex ones. Use bullet points, not tables. Match Claude Code output style.
9. When user asks you to CREATE a file, you MUST call the Write tool. Reading source code alone is not enough — complete the action.
10. If a Glob/Grep returns 0 results, try a different pattern or broader search before giving up. Never return empty results as a final answer.
11. When user asks you to MODIFY/EDIT a file, you MUST call Read first, then call Edit with exact old_string. Do NOT stop after Read — the modification is the goal.
12. For large files (>500 lines), use Grep to search specific patterns or shellCommand with "wc -l" to count lines. Do NOT Read the entire file — the result will be truncated and you will miss content.
13. To find a specific function/class definition, use Grep with output_mode "content" — NOT Glob (Glob searches file NAMES, not content). Example: to find "normalizeToolResult", use Grep with pattern "function normalizeToolResult" and output_mode "content".
14. When the user explicitly names a tool (e.g., "用 Grep 搜索..."), you MUST use that exact tool. Do NOT substitute with a different tool.
15. To search for text INSIDE files, use Grep. Do NOT Glob then Read each file — that wastes tool calls. Grep is the single right tool for content search.

# Tool Calling

You have access to tools listed in the {{TOOL_LIST}} section below. When you need to use a tool,
output exactly ONE tool call per line in this format:

<tool_call>{"name": "ToolName", "params": {"key": "value"}}</tool_call>

## Tool Call Rules
- Use the EXACT tool names listed in {{TOOL_LIST}} (PascalCase: Read, Write, Edit, Glob, Grep, etc.).
- Output the tool call on its own line, with no text before or after it on that line.
- Wait for the tool result before continuing. Do NOT guess what the result might be.
- NEVER call the same tool with the same parameters twice in one conversation turn.
- You can call multiple different tools in sequence if needed.
- After receiving a tool result, summarize it concisely for the user in 2-5 sentences.
- For executable user requests (read/search/edit/run/test/build/check), you MUST call tools first instead of answering from assumptions.
- NEVER include raw <tool_call> tags in your final answer to the user. Tool calls are for execution only.
- Tool results appear as [Tool:name] prefix in follow-up messages. Use that content to formulate your answer.
- Keep answers SHORT — 3-8 sentences max. Users prefer concise results over verbose explanations.

## Tool Call Examples

Read a file (use "file_path" parameter with absolute path based on {{CWD}}):
<tool_call>{"name": "Read", "params": {"file_path": "{{CWD}}/config.json"}}</tool_call>

Search for files by pattern:
<tool_call>{"name": "Glob", "params": {"pattern": "**/*.js", "path": "{{CWD}}"}}</tool_call>

Search file contents:
<tool_call>{"name": "Grep", "params": {"pattern": "function main", "path": "{{CWD}}/src"}}</tool_call>

Write a new file:
<tool_call>{"name": "Write", "params": {"file_path": "{{CWD}}/hello.txt", "content": "Hello World"}}</tool_call>

Edit an existing file (MUST Read the file first to get exact old_string):
<tool_call>{"name": "Edit", "params": {"file_path": "{{CWD}}/src/app.js", "old_string": "const x = 1;", "new_string": "const x = 2;"}}</tool_call>

Run a shell command:
<tool_call>{"name": "shellCommand", "params": {"command": "ls -la"}}</tool_call>

Open an application:
<tool_call>{"name": "openApp", "params": {"name": "firefox"}}</tool_call>

Get a stock quote:
<tool_call>{"name": "quote", "params": {"symbol": "600519"}}</tool_call>

Fetch K-line data:
<tool_call>{"name": "dataFetch", "params": {"symbol": "000001", "period": "daily"}}</tool_call>

Run a backtest:
<tool_call>{"name": "backtest", "params": {"symbol": "000300", "strategy": "ma_cross"}}</tool_call>

Knowledge question (e.g., "what is MACD"):
→ Answer directly. No tool needed.

## Edit Tool — Critical Rules
The Edit tool performs EXACT string replacement. Follow these rules strictly:
1. **ALWAYS Read the file first** before calling Edit. You need the exact file content.
2. **old_string must be copied VERBATIM** from the Read result — exact same characters, whitespace, indentation, and line breaks. Do not retype or paraphrase.
3. **Include enough context** in old_string to make it unique. If the string appears multiple times, include surrounding lines until it is unique.
4. **Never include line numbers** in old_string — Read output shows "N\\t<content>", the old_string should only contain the <content> part.
5. **Preserve indentation exactly** — tabs vs spaces matter. Copy from Read output precisely.
6. If you need to replace multiple occurrences of the same string, use "replace_all": true.

Example workflow:
Step 1 - Read the file:
<tool_call>{"name": "Read", "params": {"file_path": "{{CWD}}/src/app.js"}}</tool_call>
Step 2 - After seeing the content, edit with exact old_string:
<tool_call>{"name": "Edit", "params": {"file_path": "{{CWD}}/src/app.js", "old_string": "function hello() {\\n  return 'world';\\n}", "new_string": "function hello() {\\n  return 'universe';\\n}"}}</tool_call>

# Tool Result Format

After you output a tool call, the system executes it and returns the result in this format:
[Tool:ToolName] <result content>

For example:
[Tool:Read] const x = 1;\nconst y = 2;\n...
[Tool:Glob] file1.js, file2.js, file3.js
[Tool:Grep] src/app.js:10: function main() {

Use the tool result to formulate a CONCISE answer to the user. Do not repeat the entire tool result — extract the relevant information and summarize.

CRITICAL: After receiving a tool result, you MUST answer the user's question based on that result.
Do NOT call another tool unless the result is genuinely insufficient.
Do NOT repeat the same tool call — the system will stop you if you do.
Maximum 5 tool calls per conversation turn. After that, you MUST give your final answer.

# Error Recovery

When a tool call fails:
1. Read the error message carefully.
2. Diagnose the root cause (wrong path? missing app? permission denied?).
3. Try an alternative approach:
   - Wrong app name → search for the correct executable name
   - File not found → check if path is correct, try alternate locations
   - Permission denied → suggest the user run with appropriate permissions
   - Command not found → suggest installing the required package
   - Edit old_string not found → Re-Read the file, copy the exact text again
4. If no alternative works, explain the error clearly and suggest next steps.
5. NEVER retry the exact same failing call.

# Work Lifecycle (Plan → Progress → Summary)

You MUST follow this lifecycle for any task that involves tool calls:

## 1. Plan (before tool calls)
Before your FIRST tool call, output a brief plan on a single line starting with [Plan]:
[Plan] 1) Read the file 2) Find the target function 3) Report results

Rules:
- Keep it to ONE line, 3-8 steps max, numbered.
- For simple tasks (single tool call), still output a short plan: [Plan] Read the config file
- The [Plan] line must come BEFORE any <tool_call> tag.

## 2. Progress (during tool calls)
The system automatically reports progress for each tool execution. You don't need to do anything special — just call tools one at a time and the system handles status updates.

## 3. Summary (after tool calls)
After ALL tool calls are complete, your response MUST contain two parts:
1. **Main answer** — the detailed response to the user's question (3-8 sentences, with specific data from tool results).
2. **[Summary] line** — a 1-sentence recap as the LAST line.

Example response after tool calls:
  "backend/src/utils/ 下有 10 个工具函数文件：logger.js, sleep.js, retry.js 等。
   sleep.js 接受两个参数：ms（毫秒数，必填）和 options（可选，控制 unref）。
   [Summary] 共 10 个工具文件，sleep.js 接受 ms 和 options 两个参数。"

Rules:
- The main answer must NOT repeat the [Plan] — it should contain actual results and data.
- [Summary] is always the LAST line. Keep it to 1 sentence.
- Include: what you did, what you found/changed, and the outcome.
- NEVER output only [Plan] steps as your final answer.

For simple questions that need no tools (knowledge, explanation):
→ Skip the lifecycle. Answer directly.

# Path Handling
- ALWAYS use absolute paths based on the working directory {{CWD}}.
- For project files, prefix with {{CWD}}/ (e.g., {{CWD}}/src/app.js).
- On Windows: use actual paths like {{DESKTOP_DIR}}, never %USERNAME% or unexpanded vars.
- On Linux: use direct command names for apps (firefox, not "open firefox").
- On macOS: use "open -a AppName" or direct command names.
- NEVER construct paths using only {{HOME_DIR}} for project files — always use {{CWD}}.

# Output Format (align with Claude Code style)
- Respond in Chinese, be clear and concise. Lead with the answer, not the reasoning.
- Keep responses SHORT: simple answers in 1-3 sentences, complex in 5-8 sentences max.
- Use bullet points, not tables. Tables are for data, not for explanations.
- Code in markdown code blocks (with language identifier).
- Lists start with -, no more than 2 levels of nesting.
- Quote numbers and data precisely, no rounding.
- Never output <think> tags or internal reasoning.

# Software Engineering Standards

## Code Quality
- Prioritize correctness, security, performance, readability, and maintainability.
- Use clear, descriptive English identifiers following language-specific naming conventions.
- Don't add features, refactor code, or make "improvements" beyond what was asked.
- Be careful not to introduce security vulnerabilities (XSS, SQL injection, command injection).
- Don't add error handling for scenarios that can't happen. Only validate at system boundaries.

## File Operations
- Read files before modifying them. Never modify code you haven't read.
- Prefer editing existing files over creating new ones.
- Don't create documentation files unless explicitly requested.
- When editing: use precise replacements, not full file rewrites.

## Git Operations
- Never push to remote unless explicitly asked.
- Never use destructive git commands (push --force, reset --hard, checkout .) without confirmation.
- Never skip hooks (--no-verify).
- Create new commits rather than amending existing ones.
- Stage specific files rather than "git add -A".
- Write concise commit messages focusing on "why" not "what".

## Action Safety
- For destructive or hard-to-reverse actions, confirm with the user first.
- For actions visible to others (push, PR, deploy), ask before proceeding.
- Don't delete files, branches, or data without confirmation.
- Investigate before overwriting — it may be the user's in-progress work.

# Parallel Tool Execution
When multiple independent tools need to run and don't depend on each other's results,
you may call them in the same turn. Sequential calls should be used when later calls
depend on earlier results.

# Context Management
- You have a limited context window. Be concise in your responses.
- For large files, read specific sections rather than the entire file.
- Summarize tool results before adding them to the conversation.
- When context gets large, focus on the most relevant information.
</Agent>
`;

function estimateTokens(text) {
  if (!text) return 0;
  // WASM hot-path with 1.2x safety margin (OpenClaw: SAFETY_MARGIN=1.2)
  try {
    const wasm = require('./contextWasm');
    return wasm.estimateTokens(text);
  } catch { /* fallback to JS */ }
  const len = String(text).length;
  const raw = Math.ceil(len / 4);
  return Math.ceil(raw * 1.2);
}

function normalizeWs(s) {
  return String(s || '').replace(/\s+/g, ' ').trim();
}

function summarizeText(text, maxLen = SUMMARY_MAX_LEN) {
  const oneLine = normalizeWs(text).replace(/\|/g, '/');
  if (oneLine.length <= maxLen) return oneLine;
  return `${oneLine.slice(0, Math.max(40, maxLen - 3))}...`;
}

function detectIntent(text) {
  const s = String(text || '');
  if (/(回测|backtest|策略测试|模拟交易|strategy)/i.test(s)) return '回测';
  if (/(行情|报价|价格|股价|多少钱|quote|price|涨跌)/i.test(s)) return '行情查询';
  if (/(k线|K线|kline|日线|周线|月线|分钟线)/i.test(s)) return 'K线查询';
  if (/(搜索|查|新闻|资讯|最新|动态|search|web)/i.test(s)) return '信息搜索';
  if (/(计算|算|复利|收益率|\d+\s*[+\-*/^%])/i.test(s)) return '计算';
  if (/(模型|model|gguf|safetensors|导入模型|ollama|下载模型|导出模型)/i.test(s)) return '模型管理';
  if (/(pdf.*word|pdf.*docx|转.*word|转.*docx|pdf转换)/i.test(s)) return 'PDF转Word';
  if (/(ocr|识别.*文字|图片.*文字|图.*识别|文字提取|图片.*识别)/i.test(s)) return '图片识别';
  if (/(读取|查看|文件|read|cat|打开.*文件|\.json|\.js|\.md|\.py)/i.test(s)) return '读取文件';
  if (/(写入|修改|重构|更新|新增|删除|edit|patch|refactor|write)/i.test(s)) return '代码修改';
  if (/(命令|执行|运行|shell|bash|terminal|cmd)/i.test(s)) return '命令执行';
  if (/(解释|什么是|定义|原理|怎么理解)/i.test(s)) return '概念解释';
  return '通用咨询';
}

function inputPurify(userMessage) {
  const raw = String(userMessage || '');

  const fillerPatterns = [
    /[\u{1F300}-\u{1FAFF}\u{FE00}-\u{FE0F}\u{200D}\u{20E3}]/gu,
    /[“”‘’「」『』【】〖〗]/g,
    /[。！？!?,，；;、…~～]+/g,
    /(请问一下|请教一下|麻烦你|麻烦帮我|帮我看下|帮我看一下|帮我查下|帮我查一下|麻烦看下|谢谢你|谢谢哈|辛苦了|可以帮我|能否帮我|可否帮我|方便的话|如果可以的话|如果方便的话)/gi,
    /(你好|您好|哈喽|hello|hi|hey|早上好|下午好|晚上好|在吗|有人吗|喂|哎|诶|嗯|啊|哦|呃|额|欸|呀|哇|天哪|就是|那个|这个|然后|所以|其实|大概|可能|或许|应该|感觉|我觉得|我想|我想要|我希望|我现在想|我这边|这边|那边|然后呢|总之|anyway|well|um|uh|you know|I mean|basically|actually|literally|right)/gi,
    /(能不能|可不可以|可以不可以|行不行|是否可以|有没有办法|拜托了|求你了|劳烦|麻烦|请|一下|吧|呢|嘛|呀|啦|哦)/gi,
  ];

  let stripped = raw;
  for (const p of fillerPatterns) stripped = stripped.replace(p, ' ');

  stripped = stripped
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const intent = detectIntent(stripped);
  const question = (stripped || raw).slice(0, 1400);

  return {
    purified: `[意图] ${intent}\n[问题] ${question}`,
    intent,
    question,
  };
}

// ── Fallback context summary (Phase 3 Level 3: manual extraction) ──
function _fallbackContextSummary(droppedMessages) {
  const dropped = Array.isArray(droppedMessages) ? droppedMessages : [];
  if (!dropped.length) return '[上下文摘要] 无历史上下文。';

  const users = dropped.filter(m => m.role === 'user').map(m => String(m.content || ''));
  const assistants = dropped.filter(m => m.role === 'assistant').map(m => String(m.content || ''));
  const tools = dropped.filter(m => m.role === 'tool').map(m => String(m.content || ''));

  const intents = users
    .map(u => {
      const m = u.match(/\[意图\]\s*([^\n]+)/);
      return m ? m[1].trim() : '';
    })
    .filter(Boolean)
    .slice(-5);

  const questions = users
    .map(u => {
      const m = u.match(/\[问题\]\s*([\s\S]*)/);
      return summarizeText(m ? m[1] : u, 80);
    })
    .filter(Boolean)
    .slice(-5);

  const conclusions = assistants.map(x => summarizeText(x, 90)).slice(-4);
  const toolFacts = tools.map(x => summarizeText(x, 90)).slice(-4);

  const parts = [];
  if (intents.length) parts.push(`历史意图=${[...new Set(intents)].join('、')}`);
  if (questions.length) parts.push(`历史问题=${questions.join(' ; ')}`);
  if (toolFacts.length) parts.push(`已得工具结果=${toolFacts.join(' ; ')}`);
  if (conclusions.length) parts.push(`历史结论=${conclusions.join(' ; ')}`);

  return summarizeText(
    `[上下文摘要] 已压缩 ${dropped.length} 条历史消息。${parts.join(' | ') || '早期对话已省略。'}`,
    950
  );
}

// ── AI Summarization prompt (Phase 3, ported from OpenClaw MERGE_SUMMARIES) ──
const SUMMARIZE_INSTRUCTION = `将以下对话历史压缩为简洁摘要。
必须保留：
- 当前活跃任务和进度
- 用户最后一个请求
- 做出的决策及原因
- 待办事项和约束
- 所有路径、ID、代码等标识符原样保留
优先保留近期内容。不超过800字。`;

/**
 * Split messages into chunks respecting tool_call/result boundaries.
 * OpenClaw: BASE_CHUNK_RATIO = 0.4
 */
function _splitByToolBoundary(messages, chunkTokenBudget) {
  const chunks = [];
  let current = [];
  let currentTokens = 0;

  for (let i = 0; i < messages.length; i++) {
    const msg = messages[i];
    const tokens = estimateTokens(msg.content);

    // If adding this message exceeds budget and current chunk is non-empty
    if (currentTokens + tokens > chunkTokenBudget && current.length > 0) {
      // Don't split between assistant+tool_call and its tool result
      if (msg.role === 'tool' && current.length > 0) {
        current.push(msg);
        currentTokens += tokens;
        continue;
      }
      chunks.push(current);
      current = [];
      currentTokens = 0;
    }

    current.push(msg);
    currentTokens += tokens;
  }

  if (current.length > 0) chunks.push(current);
  return chunks;
}

/**
 * AI-driven context summary with 3-level fallback.
 * Level 1: AI semantic summarization (best quality)
 * Level 2: AI retry without oversized messages
 * Level 3: Manual string extraction (current fallback)
 *
 * @param {Array} droppedMessages
 * @param {object} [opts]
 * @param {number} [opts.maxTokens] - Token budget for summary
 * @returns {Promise<string>}
 */
async function buildContextSummary(droppedMessages, opts = {}) {
  const dropped = Array.isArray(droppedMessages) ? droppedMessages : [];
  if (!dropped.length) return '[上下文摘要] 无历史上下文。';

  // Try AI summarization (Level 1)
  let gateway;
  try {
    gateway = require('./gateway/aiGateway');
  } catch {
    return _fallbackContextSummary(dropped);
  }

  // Sanitize tool results (truncate large outputs)
  const sanitized = dropped.map(m => ({
    role: m.role,
    content: m.role === 'tool' ? summarizeText(m.content, 500) : String(m.content || ''),
  }));

  // Split into chunks respecting boundaries
  const chunkBudget = Math.max(2000, (opts.maxTokens || CONTEXT_TOKEN_LIMIT) * 0.4);
  const chunks = _splitByToolBoundary(sanitized, chunkBudget);

  let summary = '';
  try {
    for (const chunk of chunks) {
      const chunkText = chunk.map(m =>
        `${m.role === 'user' ? 'USER' : m.role === 'assistant' ? 'AI' : 'TOOL'}: ${m.content}`
      ).join('\n');

      const prompt = summary
        ? `${SUMMARIZE_INSTRUCTION}\n\n[已有摘要]\n${summary}\n\n[新增对话]\n${chunkText}`
        : `${SUMMARIZE_INSTRUCTION}\n\n[对话历史]\n${chunkText}`;

      const result = await gateway.generate(prompt, {
        maxTokens: 800,
        temperature: 0.1,
      });

      if (result.success) {
        summary = result.content;
      } else {
        throw new Error('AI summarization failed');
      }
    }
    return `[上下文摘要] ${summary}`;
  } catch {
    // Level 2: retry without oversized messages
    try {
      const filtered = sanitized.filter(m => estimateTokens(m.content) < 1000);
      if (filtered.length > 0 && filtered.length < sanitized.length) {
        const compactText = filtered.map(m =>
          `${m.role === 'user' ? 'USER' : m.role === 'assistant' ? 'AI' : 'TOOL'}: ${m.content}`
        ).join('\n');

        const result = await gateway.generate(
          `${SUMMARIZE_INSTRUCTION}\n\n[对话历史]\n${compactText}`,
          { maxTokens: 600, temperature: 0.1 }
        );

        if (result.success) {
          return `[上下文摘要] ${result.content}`;
        }
      }
    } catch { /* Level 2 also failed */ }

    // Level 3: manual extraction fallback
    return _fallbackContextSummary(dropped);
  }
}

async function buildSlidingWindow(messages, tokenLimit = CONTEXT_TOKEN_LIMIT) {
  let arr = Array.isArray(messages) ? messages.slice() : [];
  if (arr.length === 0) return [];

  // Repair tool_call/result pairing before compression
  try {
    const { repairTranscript, ensureCompletePairs } = require('./transcriptRepair');
    arr = ensureCompletePairs(repairTranscript(arr));
  } catch { /* transcriptRepair not available, continue with raw messages */ }

  // CJK-aware context pruning: soft trim + hard clear old tool results
  try {
    const { pruneContext } = require('./contextPruner');
    arr = pruneContext(arr, {
      contextWindowTokens: tokenLimit,
      isToolPrunable: (toolName) => toolName !== 'read_file' && toolName !== 'readFile',
    });
  } catch { /* contextPruner not available */ }

  // Context window guard: warn or prune if approaching limit
  try {
    const { evaluateGuard, pruneMessages, formatWarning } = require('./contextWindowGuard');
    const totalTokens = arr.reduce((sum, m) => sum + estimateTokens(m.content), 0);
    const guard = evaluateGuard({ usedTokens: totalTokens, contextWindowTokens: tokenLimit });
    if (guard.shouldBlock) {
      const { pruned, removedCount } = pruneMessages(arr, {
        targetTokens: tokenLimit * 0.8,
        estimateTokens: text => estimateTokens(text),
      });
      if (removedCount > 0) arr = pruned;
    } else if (guard.shouldWarn) {
      const logger = require('../utils/logger');
      logger.warn(formatWarning(guard));
    }
  } catch { /* contextWindowGuard not available */ }

  const maxTokens = Math.max(1200, Number(tokenLimit) || CONTEXT_TOKEN_LIMIT);

  // Try smart compression first (4-phase split + base64 strip + bridge)
  try {
    const { compress } = require('./contextCompressor');
    const compressResult = await compress(arr, {
      estimateTokensFn: (text) => estimateTokens(text),
      callModelFn: (text, callOpts) => buildContextSummary(
        [{ role: 'user', content: text }],
        { maxTokens, ...callOpts }
      ),
      contextWindowTokens: maxTokens,
    });
    if (compressResult.summaryGenerated) return compressResult.compressed;
  } catch { /* contextCompressor not available, fall through to legacy */ }

  // Legacy fallback: tail-greedy cutoff
  const reserveForSummary = 220;
  const usableBudget = Math.max(600, maxTokens - reserveForSummary);

  let used = 0;
  let cutoff = arr.length;
  for (let i = arr.length - 1; i >= 0; i--) {
    const t = estimateTokens(arr[i].content);
    if (used + t > usableBudget) break;
    used += t;
    cutoff = i;
  }

  let kept = arr.slice(cutoff);
  if (kept.length === 0) kept = [arr[arr.length - 1]];

  const dropped = arr.slice(0, cutoff);
  if (dropped.length > 0) {
    const summary = await buildContextSummary(dropped, { maxTokens });
    kept = [{ role: 'system', content: summary }, ...kept];
  }

  while (estimateTokens(kept.map(m => m.content).join('\n')) > maxTokens && kept.length > 1) {
    if (kept[0].role === 'system') {
      kept[0] = { role: 'system', content: summarizeText(kept[0].content, 480) };
      if (estimateTokens(kept.map(m => m.content).join('\n')) <= maxTokens) break;
    }
    kept.splice(1, 1);
  }

  return kept;
}

function mapToolToNaturalAction(name) {
  const n = String(name || '');
  // Use snake_case names to match actual tool registry names
  if (n === 'web_search' || n === 'webSearch' || n === 'search' || n === 'WebSearch') return { action: '搜索', arg: '关键词', desc: '搜索网页信息' };
  if (n === 'quote') return { action: '行情', arg: '股票代码', desc: '查实时价格与涨跌' };
  if (n === 'backtest') return { action: '回测', arg: 'symbol strategy', desc: '跑策略回测' };
  if (n === 'data_fetch') return { action: 'K线', arg: 'symbol period', desc: '取K线数据' };
  if (n === 'read_file' || n === 'readFile' || n === 'Read') return { action: '读取文件', arg: '文件路径', desc: '读取本地文件' };
  if (n === 'write_file' || n === 'writeFile' || n === 'Write') return { action: '写入文件', arg: '路径 内容', desc: '写文件' };
  if (n === 'editFile' || n === 'Edit' || n === 'multiEdit' || n === 'MultiEdit') return { action: '编辑文件', arg: 'file_path old_string new_string', desc: '精确修改文件内容' };
  if (n === 'shell_command' || n === 'shellCommand' || n === 'Bash') return { action: '命令', arg: '命令文本', desc: '执行shell命令' };
  if (n === 'ls' || n === 'LS' || n === 'glob' || n === 'Glob') return { action: '文件搜索', arg: 'pattern/path', desc: '查找文件和目录' };
  if (n === 'grep' || n === 'Grep') return { action: '内容搜索', arg: 'pattern/path', desc: '按正则搜索内容' };
  if (n === 'open_app') return { action: '打开应用', arg: '应用名称', desc: '打开应用（支持模糊匹配和中文名）' };
  if (n === 'agent' || n === 'Task') return { action: '子任务', arg: 'prompt role', desc: '调用子代理并行处理' };
  if (n === 'import_model') return { action: '导入模型', arg: '路径或URL', desc: '导入本地模型' };
  if (n === 'download_model') return { action: '下载模型', arg: 'URL', desc: '下载并导入模型' };
  if (n === 'list_models') return { action: '模型列表', arg: '', desc: '查看所有模型' };
  if (n === 'export_ollama_model') return { action: '导出模型', arg: 'Ollama模型名', desc: '从Ollama导出模型' };
  if (n === 'strategy_list') return { action: '策略列表', arg: 'all', desc: '列出可用策略' };
  if (n === 'git_status') return { action: 'Git状态', arg: '.', desc: '查看工作区状态' };
  if (n === 'git_diff') return { action: 'Git差异', arg: '文件路径', desc: '查看代码差异' };
  if (n === 'pdf_to_word') return { action: 'PDF转Word', arg: 'PDF文件路径', desc: '把PDF转成Word' };
  if (n === 'image_ocr') return { action: '图片识别', arg: '图片路径', desc: '识别图片中的文字' };
  if (n === 'execute_code') return { action: '执行代码', arg: '代码文本', desc: '执行代码片段' };
  return null;
}

/**
 * Build tool guide in JSON tool_call format for system prompt injection.
 * Returns a structured tool list that tells the AI exactly what tools are available.
 */
function buildNaturalToolGuide() {
  const tools = [];
  try {
    const toolModule = require('../tools');
    for (const t of toolModule.getEnabled().values()) {
      const m = mapToolToNaturalAction(t.name);
      if (m) {
        tools.push(`- ${t.name}: ${m.desc}  →  <tool_call>{"name": "${t.name}", "params": {${m.arg ? `"${_guessParamKey(t.name)}": "${m.arg}"` : ''}}}</tool_call>`);
      }
    }
    // Include Claude-compatible aliases in tool guide to increase tool-call hit rate.
    try {
      const { getClaudeCompatToolList } = require('./claudeCompat');
      for (const compat of getClaudeCompatToolList()) {
        const m = mapToolToNaturalAction(compat.name);
        if (!m) continue;
        tools.push(`- ${compat.name}: ${m.desc}  →  <tool_call>{"name": "${compat.name}", "params": {${m.arg ? `"${_guessParamKey(compat.name)}": "${m.arg}"` : ''}}}</tool_call>`);
      }
    } catch { /* best effort */ }
  } catch {
    // Fallback: minimal static list using PascalCase names matching the registry
    tools.push(
      '- Read: Read a file  →  <tool_call>{"name": "Read", "params": {"file_path": "/absolute/path/to/file"}}</tool_call>',
      '- Write: Write/create a file  →  <tool_call>{"name": "Write", "params": {"file_path": "/absolute/path", "content": "..."}}</tool_call>',
      '- Edit: Edit a file (exact string replacement)  →  <tool_call>{"name": "Edit", "params": {"file_path": "/absolute/path", "old_string": "exact old text", "new_string": "new text"}}</tool_call>',
      '- Glob: Find files by pattern  →  <tool_call>{"name": "Glob", "params": {"pattern": "**/*.js"}}</tool_call>',
      '- Grep: Search file contents  →  <tool_call>{"name": "Grep", "params": {"pattern": "keyword", "path": "/dir"}}</tool_call>',
      '- shellCommand: Run a shell command  →  <tool_call>{"name": "shellCommand", "params": {"command": "ls -la"}}</tool_call>',
      '- webSearch: Web search  →  <tool_call>{"name": "webSearch", "params": {"query": "keyword"}}</tool_call>',
      '- quote: Stock quote  →  <tool_call>{"name": "quote", "params": {"symbol": "600519"}}</tool_call>',
      '- openApp: Open application  →  <tool_call>{"name": "openApp", "params": {"name": "firefox"}}</tool_call>',
      '- backtest: Run backtest  →  <tool_call>{"name": "backtest", "params": {"symbol": "000300", "strategy": "ma_cross"}}</tool_call>',
    );
  }

  if (!tools.length) return '';
  return `\n{{TOOL_LIST}}\n## Available Tools\n${[...new Set(tools)].join('\n')}\n{{/TOOL_LIST}}`;
}

/**
 * Guess the primary parameter key for a tool to use in examples.
 */
function _guessParamKey(toolName) {
  const map = {
    web_search: 'query', search: 'query', quote: 'symbol', backtest: 'symbol',
    data_fetch: 'symbol', read_file: 'path', write_file: 'path',
    shell_command: 'command', open_app: 'name', git_status: 'path',
    git_diff: 'file', import_model: 'source', list_models: '',
    export_ollama_model: 'model', pdf_to_word: 'inputPath',
    image_ocr: 'imagePath', strategy_list: '', execute_code: 'code',
    webSearch: 'query', Bash: 'command', Read: 'path', Write: 'path',
    Edit: 'file_path', MultiEdit: 'file_path', LS: 'path', Grep: 'pattern',
    Glob: 'pattern', Task: 'prompt',
  };
  return map[toolName] || 'input';
}

const NATURAL_ACTION_ALIASES = {
  '搜索': '搜索',
  'search': '搜索',
  'websearch': '搜索',
  '查找': '搜索',

  '计算器': '计算器',
  '计算': '计算器',
  'calculator': '计算器',

  '读取文件': '读取文件',
  '读文件': '读取文件',
  'readfile': '读取文件',

  '写入文件': '写入文件',
  'writefile': '写入文件',

  '命令': '命令',
  'shell': '命令',
  'bash': '命令',

  '打开应用': '打开应用',
  '打开': '打开应用',
  '启动': '打开应用',
  'open': '打开应用',
  'openapp': '打开应用',
  'launch': '打开应用',

  '行情': '行情',
  'quote': '行情',
  '报价': '行情',

  '回测': '回测',
  'backtest': '回测',

  'k线': 'K线',
  'kline': 'K线',
  'K线': 'K线',

  '策略列表': '策略列表',
  'strategylist': '策略列表',

  'git状态': 'Git状态',
  'gitstatus': 'Git状态',

  'git差异': 'Git差异',
  'gitdiff': 'Git差异',

  '导入模型': '导入模型',
  '下载模型': '导入模型',
  'importmodel': '导入模型',
  'downloadmodel': '导入模型',

  '模型列表': '模型列表',
  '查看模型': '模型列表',
  'listmodels': '模型列表',
  '所有模型': '模型列表',

  '导出模型': '导出模型',
  'exportmodel': '导出模型',

  'pdf转word': 'PDF转Word',
  'pdf转换': 'PDF转Word',
  'pdf2word': 'PDF转Word',
  '转word': 'PDF转Word',
  '转docx': 'PDF转Word',

  '图片识别': '图片识别',
  '识别文字': '图片识别',
  'ocr': '图片识别',
  '文字识别': '图片识别',
  '图文识别': '图片识别',
};

function extractNaturalToolCall(text) {
  const s = String(text || '');

  // Format 1: <tool_call>{"name": "xxx", "params": {...}}</tool_call>  (XML/JSON)
  const xmlMatch = s.match(/<tool_call>\s*(\{[\s\S]*?\})\s*<\/tool_call>/);
  if (xmlMatch) {
    try {
      const parsed = JSON.parse(xmlMatch[1]);
      const name = String(parsed.name || '').trim();
      if (name) {
        return { action: name, arg: parsed.params || {}, _format: 'xml_json' };
      }
    } catch { /* malformed JSON, fall through */ }
  }

  // Format 2: 【调用 xxx：yyy】  (Chinese brackets)
  const strict = s.match(/【\s*调用\s*([^：:\]】\n]{1,24})\s*[：:]\s*([\s\S]*?)\s*】/);
  if (strict) {
    const rawAction = strict[1].trim();
    const key = rawAction.toLowerCase();
    const action = NATURAL_ACTION_ALIASES[key] || NATURAL_ACTION_ALIASES[rawAction] || rawAction;
    return { action, arg: (strict[2] || '').trim() };
  }

  const noArg = s.match(/【\s*调用\s*([^】\n]{1,24})\s*】/);
  if (noArg) {
    const rawAction = noArg[1].trim();
    const key = rawAction.toLowerCase();
    const action = NATURAL_ACTION_ALIASES[key] || NATURAL_ACTION_ALIASES[rawAction] || rawAction;
    return { action, arg: '' };
  }

  return null;
}

function safeEvalExpression(expr) {
  const src = String(expr || '').trim();
  if (!/^[0-9+\-*/().%^\s]+$/.test(src)) {
    throw new Error('Expression contains unsupported characters');
  }
  // eslint-disable-next-line no-new-func
  const fn = new Function(`return (${src});`);
  const out = fn();
  if (!Number.isFinite(Number(out))) throw new Error('Expression result is not finite');
  return String(out);
}

function parseKVArg(argText) {
  const out = {};
  const s = String(argText || '').trim();
  if (!s) return out;
  const parts = s.split(/\s+/);
  for (const p of parts) {
    const m = p.match(/^([a-zA-Z_]+)=(.+)$/);
    if (m) out[m[1]] = m[2];
  }
  return out;
}

function normalizeToolResult(r, maxLen = 2200) {
  if (!r) return { success: false, text: 'No result' };
  if (r.success) {
    // Priority chain: known string fields → file list → message → JSON fallback
    let body = r.output || r.content || r.result || r.data;
    if (body === undefined || body === null) {
      // Handle special return shapes (Grep→files, Glob→files, etc.)
      if (Array.isArray(r.files)) {
        body = r.files.join('\n');
        if (r.count !== undefined) body = `Found ${r.count} result(s):\n${body}`;
      } else if (r.message) {
        body = r.message;
      } else {
        body = JSON.stringify(r, null, 2);
      }
    } else if (typeof body === 'object') {
      body = Array.isArray(body) ? body.join('\n') : JSON.stringify(body, null, 2);
    } else {
      body = String(body);
    }
    return { success: true, text: summarizeText(body, maxLen) };
  }
  // Error case: also handle object errors
  let errText = r.error;
  if (typeof errText === 'object') errText = JSON.stringify(errText);
  return { success: false, text: String(errText || r.message || 'Tool failed') };
}

async function runNaturalToolCall(call, context = {}) {
  if (!call) return null;
  const tools = require('../tools');
  const { rewriteWindowsDesktopPath } = require('../utils/pathCompat');

  // Handle XML/JSON format tool calls from <tool_call> extraction
  if (call._format === 'xml_json' && typeof call.arg === 'object') {
    const name = call.action;
    const rawParams = call.arg;
    // Map model tool names to registered tool names (PascalCase for new registry)
    const TOOL_NAME_MAP = {
      'Write': 'Write', 'write': 'Write', 'write_file': 'Write', 'writeFile': 'Write',
      'Read': 'Read', 'read': 'Read', 'read_file': 'Read', 'readFile': 'Read',
      'Edit': 'Edit', 'edit': 'Edit', 'edit_file': 'Edit', 'editFile': 'Edit',
      'Glob': 'Glob', 'glob': 'Glob',
      'Grep': 'Grep', 'grep': 'Grep',
      'Bash': 'shellCommand', 'bash': 'shellCommand', 'shell_command': 'shellCommand', 'shellCommand': 'shellCommand',
      'webSearch': 'webSearch', 'WebSearch': 'webSearch', 'web_search': 'webSearch',
      'WebFetch': 'WebFetch', 'webFetch': 'WebFetch', 'web_fetch': 'WebFetch',
      'quote': 'quote',
      'gitStatus': 'gitStatus', 'git_status': 'gitStatus',
      'gitDiff': 'gitDiff', 'git_diff': 'gitDiff',
      'gitCommit': 'gitCommit', 'git_commit': 'gitCommit',
      'data_fetch': 'data_fetch', 'dataFetch': 'data_fetch',
    };
    let toolName = TOOL_NAME_MAP[name] || name;

    // Normalize params: model may use various key names for file path
    const params = { ...rawParams };
    const pathValue = params.file_path || params.path || params.input || params.file || params.filepath;
    if (pathValue) {
      // New registry tools expect "file_path"; legacy tools expect "path"
      params.file_path = pathValue;
      params.path = pathValue;
      // Clean up duplicate keys
      delete params.input; delete params.file; delete params.filepath;
    }

    // Resolve paths against CWD
    const pathMod = require('path');
    const fsMod = require('fs');
    const cwd = process.env.KHYQUANT_CWD || process.cwd();
    const pathKey = params.file_path ? 'file_path' : 'path';
    if (params[pathKey]) {
      let resolved = rewriteWindowsDesktopPath(String(params[pathKey]));
      if (!pathMod.isAbsolute(resolved)) {
        // Relative path → resolve against CWD
        resolved = pathMod.resolve(cwd, resolved);
      } else if (!fsMod.existsSync(resolved)) {
        // Absolute path that doesn't exist — model may have used wrong base dir.
        // Try extracting the relative portion after home dir and resolving against CWD.
        const home = require('os').homedir();
        if (resolved.startsWith(home + pathMod.sep)) {
          const relPart = resolved.slice(home.length + 1);
          const cwdCandidate = pathMod.resolve(cwd, relPart);
          if (fsMod.existsSync(cwdCandidate)) {
            resolved = cwdCandidate;
          }
        }
      }
      params.file_path = rewriteWindowsDesktopPath(resolved);
      params.path = rewriteWindowsDesktopPath(resolved);
    }

    // Compatibility guard: some providers emit Write(file_path=...) first and
    // place actual diff/text in later blocks. Writing empty content creates
    // confusing "0 lines written" behavior. Try to recover payload fields; if
    // still empty, fail fast so the model can retry with full content.
    if (toolName === 'Write' || toolName === 'writeFile' || toolName === 'write_file') {
      if (params.content === undefined || params.content === null) {
        const candidate = [
          params.text,
          params.body,
          params.value,
          params.contents,
          params.new_content,
          params.newContent,
          params.file_content,
          params.content_text,
        ].find(v => v !== undefined && v !== null);
        if (candidate !== undefined) params.content = candidate;
      }
      if (Array.isArray(params.content)) {
        params.content = params.content.map(v => String(v)).join('\n');
      } else if (params.content !== undefined && params.content !== null && typeof params.content !== 'string') {
        try { params.content = JSON.stringify(params.content, null, 2); } catch { params.content = String(params.content); }
      }

      // If the model actually intended a targeted replacement, auto-route to Edit.
      if ((!params.content || String(params.content).trim() === '') && params.old_string !== undefined && params.new_string !== undefined) {
        toolName = 'Edit';
        params.file_path = params.file_path || params.path;
      }
    }

    if ((toolName === 'Write' || toolName === 'writeFile' || toolName === 'write_file')
      && (!params.content || String(params.content).trim() === '')
      && !params.allow_empty
      && !params.create_empty) {
      return {
        success: false,
        text: 'Write tool rejected empty content. Please provide full file content (or set allow_empty/create_empty explicitly).',
      };
    }

    // In non-interactive (pipe) mode, pre-approve tools to avoid blocking on stdin.
    // Read-only tools are already auto-approved via the risk='low' change.
    // Write tools need explicit pre-approval for non-TTY contexts.
    const isNonInteractive = !process.stdin.isTTY;
    if (isNonInteractive) {
      try {
        const tc = require('./toolCalling');
        if (typeof tc.approveTool === 'function') {
          tc.approveTool(toolName, false);
          // Also approve aliases and snake_case variants
          const snakeMap = { 'Write': 'write_file', 'Read': 'read_file', 'Edit': 'edit_file', 'shellCommand': 'shell_command' };
          if (snakeMap[toolName]) tc.approveTool(snakeMap[toolName], false);
          // Pre-approve related tools (e.g. Edit after Read, Write after Read)
          for (const related of ['Read', 'Write', 'Edit', 'Glob', 'Grep', 'read_file', 'write_file', 'edit_file', 'editFile', 'shellCommand', 'shell_command']) {
            tc.approveTool(related, false);
          }
        }
      } catch { /* best effort */ }
    }

    try {
      const r = await tools.execute(toolName, params, context);
      return normalizeToolResult(r);
    } catch (e) {
      return { success: false, text: `Tool ${toolName} error: ${e.message}` };
    }
  }

  if (call.action === '搜索') {
    const query = call.arg || '最新市场信息';
    const r = await tools.execute('webSearch', { query }, context);
    return normalizeToolResult(r);
  }

  if (call.action === '计算器') {
    const val = safeEvalExpression(call.arg);
    return { success: true, text: `Calculator result: ${val}` };
  }

  if (call.action === '读取文件') {
    const p = String(call.arg || '').replace(/^\/+/, '');
    const r = await tools.execute('readFile', { path: p }, context);
    return normalizeToolResult(r);
  }

  if (call.action === '写入文件') {
    const [filePath, ...rest] = String(call.arg || '').split('|');
    const content = rest.join('|').trim();
    const r = await tools.execute('writeFile', { path: (filePath || '').trim(), content }, context);
    return normalizeToolResult(r);
  }

  if (call.action === '命令') {
    const r = await tools.execute('shellCommand', { command: call.arg }, context);
    return normalizeToolResult(r);
  }

  if (call.action === '打开应用') {
    const r = await tools.execute('openApp', { name: call.arg }, context);
    return normalizeToolResult(r);
  }

  if (call.action === '行情') {
    const r = await tools.execute('quote', { symbol: call.arg }, context);
    return normalizeToolResult(r);
  }

  if (call.action === '回测') {
    const kv = parseKVArg(call.arg);
    const r = await tools.execute('backtest', {
      symbol: kv.symbol || kv.code || '000300',
      strategy: kv.strategy || 'ma_cross',
      start: kv.start,
      end: kv.end,
      capital: kv.capital ? Number(kv.capital) : undefined,
    }, context);
    return normalizeToolResult(r);
  }

  if (call.action === 'K线') {
    const parts = String(call.arg || '').trim().split(/\s+/).filter(Boolean);
    const symbol = parts[0] || '000001';
    const period = parts[1] || 'daily';
    const r = await tools.execute('dataFetch', { symbol, period }, context);
    return normalizeToolResult(r);
  }

  if (call.action === '策略列表') {
    const r = await tools.execute('strategyList', {}, context);
    return normalizeToolResult(r);
  }

  if (call.action === 'Git状态') {
    const r = await tools.execute('gitStatus', {}, context);
    return normalizeToolResult(r);
  }

  if (call.action === 'Git差异') {
    const r = await tools.execute('gitDiff', call.arg ? { file: call.arg } : {}, context);
    return normalizeToolResult(r);
  }

  if (call.action === '导入模型') {
    const source = call.arg || '';
    // Detect if it's a URL or local path
    const isUrl = /^https?:\/\//i.test(source);
    if (isUrl) {
      const r = await tools.execute('download_model', { url: source }, context);
      return normalizeToolResult(r);
    }
    const r = await tools.execute('import_model', { source }, context);
    return normalizeToolResult(r);
  }

  if (call.action === '模型列表') {
    const r = await tools.execute('list_models', {}, context);
    return normalizeToolResult(r);
  }

  if (call.action === '导出模型') {
    const r = await tools.execute('export_ollama_model', { model: call.arg }, context);
    return normalizeToolResult(r);
  }

  if (call.action === 'PDF转Word') {
    const parts = String(call.arg || '').split('|');
    const r = await tools.execute('pdfToWord', {
      inputPath: (parts[0] || '').trim(),
      outputPath: (parts[1] || '').trim() || undefined,
    }, context);
    return normalizeToolResult(r);
  }

  if (call.action === '图片识别') {
    const arg = String(call.arg || '').trim();
    // Support "image_path|output.docx" format
    const parts = arg.split('|');
    const r = await tools.execute('imageOcr', {
      imagePath: (parts[0] || '').trim(),
      outputPath: (parts[1] || '').trim() || undefined,
    }, context);
    return normalizeToolResult(r);
  }

  return { success: false, text: `Unsupported natural tool action: ${call.action}` };
}

function isCreativeRequest(text) {
  const s = String(text || '').toLowerCase();
  return /(创意|创作|文案|诗|故事|脑暴|creative|brainstorm|slogan|小说|散文|歌词|剧本)/i.test(s);
}

function lockTemperature(userMessage) {
  return isCreativeRequest(userMessage) ? 0.3 : 0.1;
}

function lockTopP() {
  return 0.85;
}

/**
 * Local output post-processor — enforces formatting rules that were
 * previously in the system prompt (R1, R9, R10, R14) without consuming tokens.
 */
function postProcessOutput(text) {
  let out = String(text || '').trim();
  if (!out) return out;

  // Strip filler phrases at start (was Rule R1)
  const FILLER_RE = /^(好的[，,]?\s*|让我[来为]?\s*|首先[，,]?\s*|接下来[，,]?\s*|当然[了，,]?\s*|没问题[，,]?\s*|我来\s*|请稍等[，,]?\s*|嗯[，,]?\s*|好[的吧]?[，,]\s*)+/;
  out = out.replace(FILLER_RE, '');

  // Collapse nested bullets to flat (was Rule R10)
  out = out.replace(/^(\s{2,})[•\-\*]/gm, '-');

  // Strip leaked chain-of-thought (was Rule R14)
  out = out.replace(/<think>[\s\S]*?<\/think>/g, '');
  out = out.replace(/\(内部推理[:：][\s\S]*?\)/g, '');

  return out.trim();
}

// ── System Prompt — Modular Builder (Claude Code architecture) ──
// Uses the new constants/prompts.js modular section system with cache boundary.
// Legacy HARDCORE_SYSTEM_PROMPT is kept as fallback for local/Ollama models.
const {
  getSystemPrompt: getModularSystemPrompt,
  assembleSystemPrompt,
  SYSTEM_PROMPT_DYNAMIC_BOUNDARY,
} = require('../constants/prompts');

const _promptCache = new Map();
const PROMPT_CACHE_MAX = 32;

/**
 * Build system prompt using the modular section architecture.
 * For cloud models (Claude, GPT-4, etc.): uses Claude Code-aligned modular prompt.
 * For local models (Ollama, llama.cpp): uses legacy HARDCORE_SYSTEM_PROMPT as
 * small models need the more compact, directive-heavy format.
 *
 * @param {string} baseSecurity - Additional security instructions
 * @param {object} modelInfo - { model, adapter }
 * @param {Array} bootstrapFiles - Workspace context files
 * @returns {string} Complete system prompt
 */
function makeSystemPrompt(baseSecurity = '', modelInfo = {}, bootstrapFiles = []) {
  const crypto = require('crypto');
  const os = require('os');
  const { getDesktopPath } = require('../utils/pathCompat');

  const modelId = modelInfo.model || process.env.GATEWAY_PREFERRED_MODEL
    || process.env.OLLAMA_MODEL || 'auto';
  const adapter = modelInfo.adapter || process.env.GATEWAY_PREFERRED_ADAPTER || 'auto';

  // Determine if we should use modular prompt (cloud models) or legacy (local)
  const isCloudModel = /claude|gpt|gemini|deepseek/i.test(modelId) ||
    /api|claude|openai|cursor|kiro|codex/i.test(adapter);
  const forceModular = process.env.KHY_MODULAR_PROMPT === '1' ||
    process.env.KHY_CLAUDE_PROMPT === '1';
  const forceLegacy = process.env.KHY_LEGACY_PROMPT === '1';

  const useModular = (isCloudModel || forceModular) && !forceLegacy;

  // Cache key
  const cacheKey = crypto.createHash('sha256')
    .update(JSON.stringify({
      modelId, adapter, baseSecurity, useModular,
      bootstrapPaths: (bootstrapFiles || []).map(f => f.path).sort(),
    }))
    .digest('hex');

  let cached = _promptCache.get(cacheKey);
  if (cached) return cached;

  let fullPrompt;

  if (useModular) {
    // ── Modular prompt (Claude Code architecture) ──
    // Build enabled tool list for the prompt builder
    let enabledTools = [];
    try {
      const toolModule = require('../tools');
      enabledTools = [...toolModule.getEnabled().values()].map(t => t.name);
    } catch { /* tools not loaded yet */ }

    // Add Claude-compatible aliases
    try {
      const { getClaudeCompatToolList } = require('./claudeCompat');
      for (const compat of getClaudeCompatToolList()) {
        enabledTools.push(compat.name);
      }
    } catch { /* best effort */ }

    const cwd = process.cwd();

    // Build synchronously from cached sections (async sections resolve to cached values)
    // For the initial call, we build a synchronous version
    const sections = [];

    // Static intro
    sections.push(
      `\nYou are khy OS, an intelligent operating system assistant powered by AI.\n` +
      `You are an interactive agent that helps users with software engineering tasks, ` +
      `system operations, financial data analysis, and general knowledge. ` +
      `Use the instructions below and the tools available to you to assist the user.\n\n` +
      `${require('../constants/cyberRiskInstruction').CYBER_RISK_INSTRUCTION}\n` +
      `IMPORTANT: You must NEVER generate or guess URLs for the user unless you are confident that the URLs are for helping the user with programming. You may use URLs provided by the user in their messages or local files.`
    );

    // System section
    const { getSimpleSystemSection, getDoingTasksSection, getActionsSection,
      getUsingYourToolsSection, getToneAndStyleSection, getOutputEfficiencySection,
      getGitOperationsSection, getEnvironmentSection, getKhySpecificSection,
      getProjectInstructionsSection, getGitStatusSection, getMemorySection,
    } = require('../constants/prompts');

    sections.push(getSimpleSystemSection());
    sections.push(getDoingTasksSection());
    sections.push(getActionsSection());
    sections.push(getUsingYourToolsSection(enabledTools));

    // Deferred tools hint: list tools available via ToolSearch
    try {
      const toolModule = require('../tools');
      if (typeof toolModule.getDeferredTools === 'function' &&
          typeof toolModule.getRevealedDeferred === 'function') {
        const deferred = toolModule.getDeferredTools();
        const revealed = toolModule.getRevealedDeferred();
        const unrevealed = [];
        for (const [name] of deferred) {
          if (!revealed.has(name)) unrevealed.push(name);
        }
        if (unrevealed.length > 0) {
          sections.push(
            `# Additional Tools\n` +
            `The following tools are available but not currently loaded to save context space. ` +
            `Use the toolSearch tool to discover and activate them when needed:\n` +
            unrevealed.join(', ')
          );
        }
      }
    } catch { /* tools not loaded yet */ }

    sections.push(getToneAndStyleSection());
    sections.push(getOutputEfficiencySection());
    sections.push(getGitOperationsSection());

    // Dynamic boundary
    sections.push(SYSTEM_PROMPT_DYNAMIC_BOUNDARY);

    // Dynamic sections
    const memorySection = getMemorySection();
    if (memorySection) sections.push(memorySection);

    sections.push(getEnvironmentSection(modelId, cwd));

    // Language preference
    const lang = process.env.KHY_LANGUAGE || null;
    if (lang) {
      sections.push(`# Language\nAlways respond in ${lang}. Use ${lang} for all explanations, comments, and communications with the user. Technical terms and code identifiers should remain in their original form.`);
    }

    // Project instructions (CLAUDE.md, KHY.md)
    const projInstructions = getProjectInstructionsSection(cwd);
    if (projInstructions) sections.push(projInstructions);

    // Git status
    const gitStatus = getGitStatusSection(cwd);
    if (gitStatus) sections.push(gitStatus);

    // khy OS specific capabilities
    sections.push(getKhySpecificSection());

    // Bootstrap file injection (workspace context)
    if (bootstrapFiles && bootstrapFiles.length > 0) {
      try {
        const { injectWithBudget } = require('./bootstrapBudget');
        const { injected } = injectWithBudget(bootstrapFiles, {
          perFileMaxChars: 8000, totalMaxChars: 24000,
        });
        if (injected.length > 0) {
          const contextParts = injected
            .filter(s => s.injectedChars > 0)
            .map(s => `--- ${s.path} ---\n${s.injectedContent}`);
          if (contextParts.length > 0) {
            sections.push(`# Workspace context\n${contextParts.join('\n')}`);
          }
        }
      } catch { /* bootstrapBudget not available */ }
    }

    // Additional security
    if (baseSecurity) sections.push(baseSecurity);

    // Tool guide (dynamic suffix)
    const toolGuide = buildNaturalToolGuide();
    if (toolGuide) sections.push(toolGuide);

    fullPrompt = sections
      .filter(s => s != null && s !== SYSTEM_PROMPT_DYNAMIC_BOUNDARY)
      .join('\n\n');
  } else {
    // ── Legacy prompt for local models ──
    const platform = os.platform();
    const homeDir = os.homedir().replace(/\\/g, '/');

    const cwd = (process.env.KHYQUANT_CWD || process.cwd()).replace(/\\/g, '/');

    const desktopDir = getDesktopPath().replace(/\\/g, '/');
    let prompt = HARDCORE_SYSTEM_PROMPT
      .replace(/\{\{MODEL_ID\}\}/g, modelId)
      .replace(/\{\{ADAPTER\}\}/g, adapter)
      .replace(/\{\{PLATFORM\}\}/g, platform === 'win32' ? 'Windows' : platform === 'darwin' ? 'macOS' : 'Linux')
      .replace(/\{\{HOME_DIR\}\}/g, homeDir)
      .replace(/\{\{DESKTOP_DIR\}\}/g, desktopDir)
      .replace(/\{\{CWD\}\}/g, cwd);

    let osHint;
    if (platform === 'linux') {
      osHint = `\n<env>OS: Linux · Shell: bash\nUse direct command names for apps. Use absolute paths.</env>\n`;
    } else if (platform === 'win32') {
      osHint = `\n<env>OS: Windows · Shell: PowerShell\nUse start command. Desktop path: ${desktopDir}</env>\n`;
    } else {
      osHint = `\n<env>OS: macOS · Shell: bash\nUse "open -a AppName" or direct command names.</env>\n`;
    }

    // Bootstrap files
    if (bootstrapFiles && bootstrapFiles.length > 0) {
      try {
        const { injectWithBudget } = require('./bootstrapBudget');
        const { injected } = injectWithBudget(bootstrapFiles, {
          perFileMaxChars: 8000, totalMaxChars: 24000,
        });
        if (injected.length > 0) {
          prompt += '\n<workspace-context>\n';
          for (const stat of injected) {
            if (stat.injectedChars > 0) {
              prompt += `--- ${stat.path} ---\n${stat.injectedContent}\n`;
            }
          }
          prompt += '</workspace-context>\n';
        }
      } catch { /* best effort */ }
    }

    const dynamicSuffix = buildNaturalToolGuide();
    fullPrompt = prompt + osHint + (baseSecurity || '') + '\n' + dynamicSuffix;
    fullPrompt = fullPrompt.replace(/\{\{TOOL_LIST\}\}\n?/, '').replace(/\{\{\/TOOL_LIST\}\}\n?/, '');
  }

  // Cache the result
  _promptCache.set(cacheKey, fullPrompt);
  if (_promptCache.size > PROMPT_CACHE_MAX) {
    _promptCache.delete(_promptCache.keys().next().value);
  }

  return fullPrompt;
}

function buildFlatConversation(systemPrompt, messages) {
  return [
    systemPrompt,
    '',
    ...messages.map(m => {
      if (m.role === 'tool') return `[ToolResult]\n${m.content}`;
      return `${m.role.toUpperCase()}: ${m.content}`;
    }),
  ].join('\n');
}

module.exports = {
  CONTEXT_TOKEN_LIMIT,
  HARDCORE_SYSTEM_PROMPT,
  inputPurify,
  buildSlidingWindow,
  buildNaturalToolGuide,
  extractNaturalToolCall,
  runNaturalToolCall,
  lockTemperature,
  lockTopP,
  makeSystemPrompt,
  buildFlatConversation,
  postProcessOutput,
  estimateTokens,
};
