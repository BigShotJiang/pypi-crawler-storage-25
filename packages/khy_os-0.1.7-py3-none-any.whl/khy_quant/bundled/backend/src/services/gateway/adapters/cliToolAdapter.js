/**
 * CLI Tool Adapter — detect and invoke local AI CLI tools
 * (Claude Code, Codex, Aider, etc.) via child processes.
 *
 * Supports streaming output for Claude Code (stream-json format)
 * so the user can see thinking and response in real-time.
 */
const { execFileSync, spawn, spawnSync } = require('child_process');

const TOOLS = [
  {
    name: 'Claude Code',
    cmd: 'claude',
    buildArgs: () => [
      '-p',
      '--output-format', 'stream-json',
      '--verbose',
      '--include-partial-messages',
      '--allowedTools', 'Bash,Read,LS,Grep,Glob,Edit,Write,MultiEdit,Task,TodoWrite,WebSearch,WebFetch,NotebookRead,NotebookEdit',
      '--permission-mode', 'bypassPermissions',
    ],
    useStdin: true,
    streaming: true,
    priority: 1,
  },
  {
    name: 'Codex',
    cmd: 'codex',
    buildArgs: () => ['exec', '--color', 'never', '--skip-git-repo-check', '--sandbox', 'read-only'],
    useStdin: true,
    streaming: false,
    priority: 2,
  },
  {
    name: 'Aider',
    cmd: 'aider',
    buildArgs: () => ['--message', '__PROMPT__', '--yes', '--no-auto-commits'],
    useStdin: false,
    streaming: false,
    priority: 3,
  },
];

const TIMEOUT_MS = 120_000;
const MAX_BUFFER = 10 * 1024 * 1024; // 10 MB

let _detected = null; // cached detection results

function classifyCliErrorType(message = '') {
  const lower = String(message || '').toLowerCase();
  if (/\baborted\b|\brequest aborted\b|\babort(ed)? by\b|signal aborted|user[-\s]?cancel/.test(lower)) return 'cancelled';
  if (/\bcancelled\b|\bcanceled\b/.test(lower)) return 'process';
  if (/timeout|timed out/.test(lower)) return 'timeout';
  if (/unauthorized|forbidden|not authenticated|apikeysource|auth|login/.test(lower)) return 'auth';
  if (/permission denied|operation not permitted|access denied|sandbox|eacces|eperm/.test(lower)) return 'permission';
  if (/\b(?:econnreset|econnrefused|enotfound|ehostunreach|enetunreach|eai_again)\b|network error|fetch failed|socket hang up|getaddrinfo|proxy/i.test(lower)) {
    return 'network';
  }
  if (/reconnecting|channel closed|failed to record rollout items|exited with code|without emitting stream-json|launch blocked|spawn|process error/.test(lower)) {
    return 'process';
  }
  if (/not installed|command .* not found|not found/.test(lower)) return 'unavailable';
  return 'unknown';
}

function resolveAggregateErrorType(attempts = []) {
  const failed = Array.isArray(attempts) ? attempts.filter(a => a && a.success === false) : [];
  if (failed.length === 0) return 'unavailable';

  const lastMsg = String(failed[failed.length - 1].error || '');
  const lastType = classifyCliErrorType(lastMsg);
  if (lastType && lastType !== 'unknown') return lastType;

  for (let i = failed.length - 1; i >= 0; i -= 1) {
    const t = classifyCliErrorType(failed[i].error || '');
    if (t && t !== 'unknown') return t;
  }
  return 'unavailable';
}

/**
 * Check if a command exists on the system PATH.
 */
function commandExists(cmd) {
  // Prefer direct execution check; more robust in restricted environments
  // where `which` may fail with EPERM even when command is runnable.
  try {
    const r = spawnSync(cmd, ['--version'], {
      stdio: 'ignore',
      timeout: 5000,
      env: process.env,
    });
    if (r && !r.error && r.status === 0) return true;
  } catch { /* fall through */ }

  try {
    const lookup = process.platform === 'win32' ? 'where' : 'which';
    execFileSync(lookup, [cmd], { stdio: 'pipe', timeout: 5000 });
    return true;
  } catch {
    return false;
  }
}

/**
 * Detect which CLI tools are available.
 * Returns boolean; caches the tool list internally.
 */
function detect(forceRefresh = false) {
  if (_detected !== null && !forceRefresh) return _detected.length > 0;

  _detected = TOOLS
    .filter(tool => commandExists(tool.cmd))
    .sort((a, b) => a.priority - b.priority);

  return _detected.length > 0;
}

/**
 * Get the list of detected tools (for status display).
 */
function getDetectedTools() {
  if (_detected === null) detect();
  return _detected;
}

/**
 * Invoke a streaming CLI tool (Claude Code) and emit chunks via callback.
 *
 * The onChunk callback receives objects like:
 *   { type: 'thinking', text: '...' }
 *   { type: 'text', text: '...' }
 *   { type: 'cost', cost: 0.05 }
 */
function invokeStreamingTool(tool, prompt, onChunk) {
  return new Promise((resolve, reject) => {
    try { onChunk({ type: 'status', text: `Launching ${tool.name}...` }); } catch { /* best effort */ }
    const args = tool.buildArgs();
    const child = spawn(tool.cmd, args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: process.env,
    });

    let finished = false;
    const done = (err, value) => {
      if (finished) return;
      finished = true;
      clearTimeout(hardTimer);
      if (err) reject(err);
      else resolve(value);
    };

    let fullContent = '';
    let buffer = '';
    let killedByTimeout = false;
    let claudeApiKeySourceNone = false;
    let claudeRetryCount = 0;
    const parserState = { blocks: new Map(), sawStreamEvent: false, sawAssistantText: false }; // idx -> { type, name, id, inputRaw }
    const hardTimer = setTimeout(() => {
      killedByTimeout = true;
      try { child.kill('SIGKILL'); } catch { /* ignore */ }
    }, TIMEOUT_MS);

    child.stdout.on('data', (chunk) => {
      buffer += chunk.toString();

      // Process complete JSON lines
      const lines = buffer.split('\n');
      buffer = lines.pop(); // keep incomplete last line

      for (const line of lines) {
        if (!line.trim()) continue;
        try {
          const event = JSON.parse(line);
          if (event.type === 'system' && event.subtype === 'init' && String(event.apiKeySource || '').toLowerCase() === 'none') {
            claudeApiKeySourceNone = true;
          }
          if (event.type === 'system' && event.subtype === 'api_retry' && claudeApiKeySourceNone) {
            claudeRetryCount += 1;
            if (claudeRetryCount >= 3) {
              try { child.kill('SIGKILL'); } catch { /* ignore */ }
              done(new Error('claude auth unavailable (apiKeySource:none)'));
              return;
            }
          }
          processStreamEvent(event, onChunk, (text) => { fullContent += text; }, parserState);
        } catch {
          // not valid JSON, ignore
        }
      }
    });

    let stderr = '';
    let stderrBytes = 0;
    child.stderr.on('data', (chunk) => {
      stderrBytes += chunk.length;
      if (stderrBytes <= MAX_BUFFER) stderr += chunk;
    });

    child.on('close', (code) => {
      if (finished) return;
      // Process any remaining buffer
      if (buffer.trim()) {
        try {
          const event = JSON.parse(buffer);
          processStreamEvent(event, onChunk, (text) => { fullContent += text; }, parserState);
        } catch { /* ignore */ }
      }

      if (killedByTimeout) {
        try { onChunk({ type: 'status', text: `${tool.name} timed out after ${TIMEOUT_MS}ms` }); } catch {}
        done(new Error(`Process timed out after ${TIMEOUT_MS}ms`));
        return;
      }

      if (code === 0 || fullContent.trim()) {
        done(null, fullContent.trim());
      } else {
        try { onChunk({ type: 'status', text: `${tool.name} failed: ${stderr.trim() || `exit ${code}`}` }); } catch {}
        done(new Error(stderr.trim() || `Process exited with code ${code}`));
      }
    });

    child.on('error', (err) => {
      try { onChunk({ type: 'status', text: `${tool.name} process error: ${err.message}` }); } catch {}
      done(err);
    });

    // Pipe prompt via stdin
    if (tool.useStdin) {
      child.stdin.on('error', () => {}); // Ignore EPIPE if child exits early
      child.stdin.write(prompt);
      child.stdin.end();
    }
  });
}

/**
 * Process a single stream-json event from Claude Code.
 */
function processStreamEvent(event, onChunk, appendContent, state = { blocks: new Map(), sawStreamEvent: false, sawAssistantText: false }) {
  const summarizeInput = (input) => {
    if (!input) return '';
    if (typeof input === 'string') return input.slice(0, 120);
    try {
      return Object.entries(input)
        .map(([k, v]) => `${k}=${String(typeof v === 'string' ? v : JSON.stringify(v)).slice(0, 40)}`)
        .join(', ')
        .slice(0, 120);
    } catch { return ''; }
  };
  const parseJsonMaybe = (str) => {
    if (!str || typeof str !== 'string') return null;
    try { return JSON.parse(str); } catch { return null; }
  };
  const summarizeText = (value, maxLen = 220) => {
    const text = typeof value === 'string' ? value : summarizeInput(value);
    if (!text) return '';
    return text.length > maxLen ? `${text.slice(0, maxLen - 1)}…` : text;
  };

  // Claude SDK-style progress event (stream-json top-level)
  if (event.type === 'tool_progress') {
    onChunk({
      type: 'tool_progress',
      id: event.tool_use_id || event.id || '',
      tool: event.tool_name || event.tool || 'tool',
      status: event.status || event.status_category || '',
      detail: summarizeText(event.status_detail || event.message || event.detail || ''),
      parentId: event.parent_tool_use_id || null,
    });
    return;
  }

  // Claude SDK-style auth status event
  if (event.type === 'auth_status') {
    onChunk({
      type: 'auth_status',
      isAuthenticating: !!event.isAuthenticating,
      output: summarizeText(event.output || ''),
      error: summarizeText(event.error || ''),
    });
    return;
  }

  // Claude SDK-style task lifecycle events (usually under system subtype)
  if (event.type === 'system' && event.subtype &&
      (event.subtype === 'task_started' || event.subtype === 'task_progress' || event.subtype === 'task_notification')) {
    onChunk({
      type: event.subtype,
      taskId: event.task_id || '',
      toolUseId: event.tool_use_id || '',
      status: event.status || '',
      summary: summarizeText(event.summary || event.message || ''),
      outputFile: event.output_file || '',
      usage: event.usage || null,
    });
    return;
  }

  // Newer Claude stream-json wrapper format: { type: "stream_event", event: {...} }
  if (event.type === 'stream_event' && event.event) {
    state.sawStreamEvent = true;
    const ev = event.event;

    if (ev.type === 'tool_progress') {
      onChunk({
        type: 'tool_progress',
        id: ev.tool_use_id || ev.id || '',
        tool: ev.tool_name || ev.tool || 'tool',
        status: ev.status || ev.status_category || '',
        detail: summarizeText(ev.status_detail || ev.message || ev.detail || ''),
        parentId: ev.parent_tool_use_id || null,
      });
      return;
    }

    if (ev.type === 'auth_status') {
      onChunk({
        type: 'auth_status',
        isAuthenticating: !!ev.isAuthenticating,
        output: summarizeText(ev.output || ''),
        error: summarizeText(ev.error || ''),
      });
      return;
    }

    if (ev.type === 'system' && ev.subtype &&
      (ev.subtype === 'task_started' || ev.subtype === 'task_progress' || ev.subtype === 'task_notification')) {
      onChunk({
        type: ev.subtype,
        taskId: ev.task_id || '',
        toolUseId: ev.tool_use_id || '',
        status: ev.status || '',
        summary: summarizeText(ev.summary || ev.message || ''),
        outputFile: ev.output_file || '',
        usage: ev.usage || null,
      });
      return;
    }

    if (ev.type === 'system' && ev.subtype === 'session_state_changed') {
      const stateText = ev.state || ev.session_state || '';
      if (stateText) onChunk({ type: 'status', text: `Session state: ${stateText}` });
      return;
    }

    if (ev.type === 'content_block_start') {
      const idx = Number(ev.index);
      const block = ev.content_block || {};
      state.blocks.set(idx, {
        type: block.type || '',
        name: block.name || '',
        id: block.id || '',
        inputRaw: '',
      });

      if (block.type === 'thinking' && block.thinking) {
        onChunk({ type: 'thinking', text: block.thinking });
      } else if (block.type === 'text' && block.text) {
        onChunk({ type: 'text', text: block.text });
        appendContent(block.text);
        state.sawAssistantText = true;
      } else if (block.type === 'tool_use') {
        const toolName = block.name || 'unknown';
        const inputSummary = summarizeInput(block.input);
        onChunk({ type: 'tool_use', tool: toolName, input: inputSummary, id: block.id });
      } else if (block.type === 'tool_result') {
        const content = typeof block.content === 'string' ? block.content : JSON.stringify(block.content || '');
        onChunk({ type: 'tool_result', id: block.tool_use_id || '', content: content.slice(0, 200) });
      }
      return;
    }

    if (ev.type === 'content_block_delta') {
      const idx = Number(ev.index);
      const delta = ev.delta || {};
      if (delta.type === 'thinking_delta' && delta.thinking) {
        onChunk({ type: 'thinking', text: delta.thinking });
      } else if (delta.type === 'text_delta' && delta.text) {
        onChunk({ type: 'text', text: delta.text });
        appendContent(delta.text);
        state.sawAssistantText = true;
      } else if (delta.type === 'input_json_delta' && typeof delta.partial_json === 'string') {
        const blk = state.blocks.get(idx);
        if (blk) blk.inputRaw += delta.partial_json;
      }
      return;
    }

    if (ev.type === 'content_block_stop') {
      const idx = Number(ev.index);
      const blk = state.blocks.get(idx);
      if (blk && blk.type === 'tool_use') {
        const parsed = parseJsonMaybe(blk.inputRaw);
        const summary = summarizeInput(parsed) || summarizeInput(blk.inputRaw);
        if (summary) onChunk({ type: 'tool_result', id: blk.id || '', content: `参数: ${summary}` });
      }
      state.blocks.delete(idx);
      return;
    }

    if (ev.type === 'message_delta' && ev.usage && typeof ev.usage.output_tokens === 'number') {
      onChunk({ type: 'cost', cost: ev.usage.output_tokens });
      return;
    }
  }

  // Some Claude CLI versions emit both stream_event and legacy assistant/user
  // payloads for the same output turn. Skip legacy payload once stream_event
  // has been observed to prevent duplicated response text.
  if (state.sawStreamEvent && (event.type === 'assistant' || event.type === 'user')) {
    return;
  }

  // Surface retry/system signals so UI doesn't appear stalled.
  if (event.type === 'system' && event.subtype) {
    if (event.subtype === 'api_retry') {
      const attempt = event.attempt || '?';
      const max = event.max_retries || '?';
      const reason = event.error || 'unknown';
      onChunk({ type: 'status', text: `Claude API retry ${attempt}/${max} (${reason})` });
      return;
    }
    if (event.subtype === 'error') {
      onChunk({ type: 'status', text: `Claude system error: ${event.error || 'unknown'}` });
      return;
    }
    if (event.subtype === 'session_state_changed') {
      const stateText = event.state || event.session_state || '';
      if (stateText) {
        onChunk({ type: 'status', text: `Session state: ${stateText}` });
      }
      return;
    }
  }

  // Handle top-level tool events emitted by some Claude CLI versions
  if (event.type === 'tool_use' || event.type === 'tool_call') {
    const toolName = event.name || event.tool || event.tool_name || 'unknown';
    const inputSummary = summarizeInput(event.input || event.arguments || event.params || {});
    onChunk({ type: 'tool_use', tool: toolName, input: inputSummary, id: event.id || '' });
    return;
  }
  if (event.type === 'tool_result') {
    const content = typeof event.content === 'string'
      ? event.content
      : JSON.stringify(event.content || event.result || '');
    onChunk({ type: 'tool_result', id: event.tool_use_id || event.id || '', content: content.slice(0, 200), isError: event.is_error });
    return;
  }

  // Handle assistant messages (thinking, text, tool_use)
  if (event.type === 'assistant' && event.message?.content) {
    for (const block of event.message.content) {
      if (block.type === 'thinking' && block.thinking) {
        onChunk({ type: 'thinking', text: block.thinking });
      } else if (block.type === 'text' && block.text) {
        onChunk({ type: 'text', text: block.text });
        appendContent(block.text);
        state.sawAssistantText = true;
      } else if (block.type === 'tool_use') {
        // Claude CLI is executing a tool internally — surface to UI
        const toolName = block.name || 'unknown';
        const inputSummary = summarizeInput(block.input);
        onChunk({ type: 'tool_use', tool: toolName, input: inputSummary, id: block.id });
      }
    }
  // Handle user messages containing tool_result
  } else if (event.type === 'user' && event.message?.content) {
    for (const block of event.message.content) {
      if (block.type === 'tool_result') {
        const content = typeof block.content === 'string' ? block.content : JSON.stringify(block.content || '');
        onChunk({ type: 'tool_result', id: block.tool_use_id, content: content.slice(0, 200), isError: block.is_error });
      }
    }
  } else if (event.type === 'result') {
    if (event.total_cost_usd) {
      onChunk({ type: 'cost', cost: event.total_cost_usd });
    }
    // Some variants only emit final text in result.result.
    if (!state.sawAssistantText && typeof event.result === 'string' && event.result.trim()) {
      onChunk({ type: 'text', text: event.result });
      appendContent(event.result);
      state.sawAssistantText = true;
    }
  }
}

/**
 * Invoke a non-streaming CLI tool (Codex, Aider).
 */
function invokeToolAsync(tool, prompt, options = {}) {
  return new Promise((resolve, reject) => {
    let args;
    if (tool.useStdin) {
      args = tool.buildArgs();
      if (tool.cmd === 'codex' && options.model) {
        args.push('--model', options.model);
      }
    } else {
      args = tool.buildArgs().map(a => a === '__PROMPT__' ? prompt : a);
    }

    const child = spawn(tool.cmd, args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      timeout: TIMEOUT_MS,
      env: process.env,
    });

    let stdout = '';
    let stderr = '';
    let totalBytes = 0;
    let finished = false;
    const done = (err, value) => {
      if (finished) return;
      finished = true;
      if (err) reject(err);
      else resolve(value);
    };

    child.stdout.on('data', (chunk) => {
      totalBytes += chunk.length;
      if (totalBytes <= MAX_BUFFER) stdout += chunk;
      if (tool.cmd === 'codex') {
        const s = chunk.toString();
        if (/ERROR:\s*Reconnecting|channel closed|failed to record rollout items/i.test(s)) {
          try { child.kill('SIGKILL'); } catch { /* ignore */ }
          done(new Error('codex backend reconnecting/channel closed'));
        }
      }
    });

    child.stderr.on('data', (chunk) => {
      stderr += chunk;
      if (tool.cmd === 'codex') {
        const s = chunk.toString();
        if (/ERROR:\s*Reconnecting|channel closed|failed to record rollout items/i.test(s)) {
          try { child.kill('SIGKILL'); } catch { /* ignore */ }
          done(new Error('codex backend reconnecting/channel closed'));
        }
      }
    });

    child.on('close', (code) => {
      if (finished) return;
      if (code === 0 && stdout.trim()) {
        done(null, stdout.trim());
      } else {
        done(new Error(stderr.trim() || `Process exited with code ${code}`));
      }
    });

    child.on('error', (err) => done(err));

    if (tool.useStdin) {
      child.stdin.on('error', () => {});
      child.stdin.write(prompt);
      child.stdin.end();
    }
  });
}

/**
 * Generate a response using the best available CLI tool.
 * Tries each detected tool in priority order.
 *
 * @param {string} prompt
 * @param {object} options
 * @param {function} [options.onChunk] - streaming callback for real-time output
 */
async function generate(prompt, options = {}) {
  const tools = getDetectedTools();
  if (tools.length === 0) {
    return { success: false, content: '', provider: '', adapter: 'cli', errorType: 'unavailable' };
  }

  const attempts = [];
  const onChunk = options.onChunk || (() => {});

  for (let idx = 0; idx < tools.length; idx += 1) {
    const tool = tools[idx];
    if (idx > 0) {
      const previous = attempts[idx - 1];
      const previousName = previous && previous.provider ? previous.provider : '上一通道';
      try {
        onChunk({ type: 'status', text: `CLI 工具桥接重试中：${previousName} 失败，切换到 ${tool.name}...` });
      } catch { /* best effort */ }
    }
    try {
      if (!tool.streaming) {
        try { onChunk({ type: 'status', text: `Launching ${tool.name}...` }); } catch { /* best effort */ }
      }
      let content;
      if (tool.streaming) {
        content = await invokeStreamingTool(tool, prompt, onChunk);
      } else {
        content = await invokeToolAsync(tool, prompt, options);
      }
      attempts.push({ provider: tool.name, success: true });
      return {
        success: true,
        content,
        provider: tool.name,
        adapter: 'cli',
        attempts,
      };
    } catch (err) {
      const errMsg = String(err && err.message ? err.message : err || 'unknown error');
      attempts.push({ provider: tool.name, success: false, error: errMsg });
      if (!tool.streaming) {
        try { onChunk({ type: 'status', text: `${tool.name} failed: ${errMsg}` }); } catch { /* best effort */ }
      }
    }
  }

  const lastErr = attempts.length > 0 ? attempts[attempts.length - 1].error : '';
  const errorType = resolveAggregateErrorType(attempts);
  return {
    success: false,
    content: '',
    provider: '',
    adapter: 'cli',
    error: lastErr || 'all cli tools failed',
    errorType,
    attempts,
  };
}

/**
 * Get adapter status for display.
 */
function getStatus() {
  detect(); // ensure detection has run
  const tools = getDetectedTools();
  return {
    name: 'CLI 工具桥接',
    type: 'cli',
    available: tools.length > 0,
    detail: tools.length > 0
      ? tools.map(t => t.name).join(', ')
      : '未检测到 (claude/codex/aider)',
  };
}

function destroy() {
  _detected = null;
}

module.exports = { detect, generate, getStatus, destroy, TOOLS };
