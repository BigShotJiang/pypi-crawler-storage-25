/**
 * Cursor Adapter — connect to Cursor IDE's AI models.
 *
 * Reads Cursor's auth token from local storage files and provides
 * access to Cursor's model catalog. Supports both local token detection
 * and account pool fallback.
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const { sanitizeOutgoingHeaders } = require('./ipAnonymizer');
const { requestJson } = require('./_proxyTunnel');

function parseList(raw) {
  return String(raw || '')
    .split(',')
    .map(v => v.trim())
    .filter(Boolean);
}

function dedupePaths(paths = []) {
  const out = [];
  const seen = new Set();
  for (const p of paths) {
    const key = String(p || '').trim();
    if (!key) continue;
    const normalized = path.normalize(key);
    if (seen.has(normalized)) continue;
    seen.add(normalized);
    out.push(normalized);
  }
  return out;
}

function resolveUserHomeRoots() {
  const roots = [
    os.homedir(),
    process.env.USERPROFILE,
    process.env.HOMEDRIVE && process.env.HOMEPATH
      ? path.join(process.env.HOMEDRIVE, process.env.HOMEPATH)
      : '',
  ];

  // WSL: also probe mounted Windows profiles.
  const isWsl = process.platform === 'linux'
    && (
      !!process.env.WSL_DISTRO_NAME
      || !!process.env.WSL_INTEROP
      || fs.existsSync('/mnt/c/Windows')
    );
  if (isWsl) {
    const userHints = dedupePaths([
      process.env.USERNAME ? `/mnt/c/Users/${process.env.USERNAME}` : '',
      process.env.USER ? `/mnt/c/Users/${process.env.USER}` : '',
    ]);
    roots.push(...userHints);
    for (const drive of ['c', 'd', 'e']) {
      const usersDir = `/mnt/${drive}/Users`;
      try {
        if (!fs.existsSync(usersDir)) continue;
        const entries = fs.readdirSync(usersDir, { withFileTypes: true });
        for (const entry of entries) {
          if (!entry.isDirectory()) continue;
          roots.push(path.join(usersDir, entry.name));
        }
      } catch {
        // ignore unreadable mounts
      }
    }
  }

  return dedupePaths(roots);
}

function buildCursorStoragePaths() {
  const out = [];
  for (const homeRoot of resolveUserHomeRoots()) {
    out.push(path.join(homeRoot, '.config', 'Cursor', 'User', 'globalStorage', 'storage.json'));
    out.push(path.join(homeRoot, 'Library', 'Application Support', 'Cursor', 'User', 'globalStorage', 'storage.json'));
    out.push(path.join(homeRoot, 'AppData', 'Roaming', 'Cursor', 'User', 'globalStorage', 'storage.json'));
  }
  for (const p of parseList(process.env.CURSOR_STORAGE_PATHS || process.env.CURSOR_STORAGE_PATH)) {
    out.push(p);
  }
  return dedupePaths(out);
}

function buildCursorDbPaths() {
  const out = [];
  for (const homeRoot of resolveUserHomeRoots()) {
    out.push(path.join(homeRoot, '.config', 'Cursor', 'User', 'globalStorage', 'state.vscdb'));
    out.push(path.join(homeRoot, 'Library', 'Application Support', 'Cursor', 'User', 'globalStorage', 'state.vscdb'));
    out.push(path.join(homeRoot, 'AppData', 'Roaming', 'Cursor', 'User', 'globalStorage', 'state.vscdb'));
    out.push(path.join(homeRoot, '.config', 'Cursor', 'User', 'globalStorage', 'state-global.vscdb'));
    out.push(path.join(homeRoot, 'Library', 'Application Support', 'Cursor', 'User', 'globalStorage', 'state-global.vscdb'));
    out.push(path.join(homeRoot, 'AppData', 'Roaming', 'Cursor', 'User', 'globalStorage', 'state-global.vscdb'));
  }
  for (const p of parseList(process.env.CURSOR_DB_PATHS || process.env.CURSOR_DB_PATH)) {
    out.push(p);
  }
  return dedupePaths(out);
}

const CURSOR_STORAGE_PATHS = buildCursorStoragePaths();
const CURSOR_DB_PATHS = buildCursorDbPaths();

const KNOWN_MODELS = [
  { id: 'claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', isDefault: false },
  { id: 'gpt-4o', name: 'GPT-4o', isDefault: true },
  { id: 'gpt-4o-mini', name: 'GPT-4o Mini', isDefault: false },
  { id: 'claude-3-opus', name: 'Claude 3 Opus', isDefault: false },
  { id: 'cursor-small', name: 'Cursor Small', isDefault: false },
];

const TIMEOUT_MS = 60_000;
const ACCOUNT_POOL_TYPE = 'cursor';
let _available = null;
let _token = null;

function normalizeToken(value) {
  return String(value || '').trim();
}

function hasTokenShape(value) {
  const token = normalizeToken(value);
  if (!token) return false;
  if (token.length < 20 || token.length > 4096) return false;
  if (/\s/.test(token)) return false;
  if (!/^[A-Za-z0-9._\-+/=~:]+$/.test(token)) return false;
  if (/^(null|undefined|token|access[_-]?token|bearer)$/i.test(token)) return false;
  return true;
}

function firstNonEmpty(values = []) {
  for (const value of values) {
    const text = String(value ?? '').trim();
    if (text) return text;
  }
  return '';
}

function extractTokenFromUnknown(value, depth = 0) {
  if (depth > 6 || value == null) return '';

  if (typeof value === 'string') {
    const raw = value.trim();
    if (!raw) return '';
    if (hasTokenShape(raw)) return normalizeToken(raw);
    if ((raw.startsWith('{') && raw.endsWith('}')) || (raw.startsWith('[') && raw.endsWith(']'))) {
      try {
        return extractTokenFromUnknown(JSON.parse(raw), depth + 1);
      } catch {
        return '';
      }
    }
    return '';
  }

  if (Buffer.isBuffer(value)) {
    return extractTokenFromUnknown(value.toString('utf8'), depth + 1);
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      const token = extractTokenFromUnknown(item, depth + 1);
      if (token) return token;
    }
    return '';
  }

  if (typeof value !== 'object') return '';

  const directKeys = [
    'accessToken',
    'access_token',
    'authToken',
    'idToken',
    'token',
    'userJwt',
    'cursorAuth/accessToken',
    'cursorAuth.accessToken',
    'cursor.accessToken',
  ];
  for (const key of directKeys) {
    const token = normalizeToken(value[key]);
    if (hasTokenShape(token)) return token;
  }

  const nested = ['cursorAuth', 'auth', 'session', 'credentials', 'login'];
  for (const key of nested) {
    const token = extractTokenFromUnknown(value[key], depth + 1);
    if (token) return token;
  }

  for (const [k, v] of Object.entries(value)) {
    if (/(refresh.?token)/i.test(k)) continue;
    if (/(access.?token|auth.?token|id.?token|jwt|bearer)/i.test(k)) {
      const token = extractTokenFromUnknown(v, depth + 1);
      if (token) return token;
    }
  }
  return '';
}

/**
 * Try to read Cursor auth token from local storage.
 */
function readCursorToken() {
  // Try SQLite database first (primary storage since Cursor 0.40+)
  for (const dbPath of CURSOR_DB_PATHS) {
    try {
      if (fs.existsSync(dbPath)) {
        const token = readTokenFromVscdb(dbPath);
        if (token) return { accessToken: token, source: 'state.vscdb', path: dbPath };
      }
    } catch { /* skip */ }
  }

  // Fallback: try storage.json (older versions)
  for (const p of CURSOR_STORAGE_PATHS) {
    try {
      if (fs.existsSync(p)) {
        const data = JSON.parse(fs.readFileSync(p, 'utf8'));
        // Cursor stores token under varying keys across versions.
        const token = firstNonEmpty([
          data.cursorAuth?.accessToken,
          data['cursorAuth/accessToken'],
          data['cursorAuth.accessToken'],
          data.cursorAuth?.token,
          data['cursorAuth/token'],
          data.cursorAuth?.authToken,
          data['cursorAuth/authToken'],
          data.accessToken,
          extractTokenFromUnknown(data),
        ]);
        if (hasTokenShape(token)) {
          return { accessToken: normalizeToken(token), source: 'storage.json', path: p };
        }
      }
    } catch { /* skip */ }
  }
  return null;
}

/**
 * Read token from Cursor's SQLite database (state.vscdb).
 * Uses better-sqlite3 if available, falls back to manual parsing.
 */
function readTokenFromVscdb(dbPath) {
  try {
    const Database = require('better-sqlite3');
    const db = new Database(dbPath, { readonly: true, fileMustExist: true });
    try {
      const tables = db.prepare('SELECT name FROM sqlite_master WHERE type = ?').all('table');
      const tableName = (
        tables.find(t => String(t.name || '') === 'ItemTable')
        || tables.find(t => String(t.name || '').toLowerCase() === 'itemtable')
        || tables.find(t => /itemtable/i.test(String(t.name || '')))
      )?.name;
      if (!tableName || !/^[A-Za-z0-9_]+$/.test(String(tableName))) return null;

      const tokenKeys = [
        'cursorAuth/accessToken',
        'cursorAuth.accessToken',
        'cursorAuth/token',
        'cursorAuth.authToken',
        'accessToken',
        'cursor.accessToken',
        'cursor.sessionToken',
      ];

      for (const key of tokenKeys) {
        try {
          const row = db.prepare(`SELECT value FROM "${tableName}" WHERE key = ?`).get(key);
          const token = extractTokenFromUnknown(row && row.value);
          if (hasTokenShape(token)) return normalizeToken(token);
        } catch { /* try next */ }
      }

      try {
        const rows = db.prepare(
          `SELECT key, value FROM "${tableName}" WHERE key LIKE ? OR key LIKE ? OR key LIKE ? LIMIT 200`
        ).all('%cursorAuth%', '%accessToken%', '%token%');
        for (const row of rows) {
          const key = String(row?.key || '');
          if (/refresh.?token/i.test(key)) continue;
          const token = extractTokenFromUnknown(row?.value);
          if (hasTokenShape(token)) return normalizeToken(token);
        }
      } catch {
        // ignore broad-scan failures
      }
    } finally {
      db.close();
    }
  } catch {
    // better-sqlite3 unavailable or DB layout changed: fallback to text scan
  }

  try {
    const buffer = fs.readFileSync(dbPath);
    const content = buffer.toString('utf8', 0, Math.min(buffer.length, 4 * 1024 * 1024));
    const tokenPatterns = [
      /cursorAuth[\/.]accessToken[^A-Za-z0-9._\-+/=~:]+([A-Za-z0-9._\-+/=~:]{20,4096})/,
      /cursorAuth[\/.]authToken[^A-Za-z0-9._\-+/=~:]+([A-Za-z0-9._\-+/=~:]{20,4096})/,
      /"accessToken"\s*:\s*"([A-Za-z0-9._\-+/=~:]{20,4096})"/,
      /"authToken"\s*:\s*"([A-Za-z0-9._\-+/=~:]{20,4096})"/,
      /\b(eyJ[A-Za-z0-9._\-+/=~:]{20,4096})\b/,
    ];
    for (const pattern of tokenPatterns) {
      const match = content.match(pattern);
      if (match && hasTokenShape(match[1])) return normalizeToken(match[1]);
    }
  } catch {
    // ignore final fallback failures
  }

  return null;
}

function detect(forceRefresh = false) {
  if (_available !== null && !forceRefresh) return _available;

  const localToken = readCursorToken();
  if (localToken && hasTokenShape(localToken.accessToken)) {
    _token = localToken;
    persistObservedToken(localToken);
  } else if (!(_token && hasTokenShape(_token.accessToken) && String(_token.source || '').startsWith('pool:'))) {
    _token = null;
  }
  _available = !!(_token && hasTokenShape(_token.accessToken));
  return _available;
}

function toPoolTokenShape(poolToken = null) {
  if (!poolToken || !hasTokenShape(poolToken.accessToken)) return null;
  return {
    accessToken: normalizeToken(poolToken.accessToken),
    refreshToken: poolToken.refreshToken ? String(poolToken.refreshToken).trim() : null,
    source: `pool:${poolToken.label || ACCOUNT_POOL_TYPE}`,
    path: poolToken.sourcePath || '',
    expiresAt: poolToken.expiresAt || null,
  };
}

async function detectAsync(forceRefresh = false) {
  const localDetected = detect(forceRefresh);
  if (localDetected) return true;

  const poolToken = await getPoolActiveToken();
  if (poolToken && hasTokenShape(poolToken.accessToken)) {
    _token = poolToken;
    _available = true;
    persistObservedToken(poolToken);
    return true;
  }
  _available = false;
  return false;
}

async function getPoolActiveToken() {
  try {
    const pool = require('../../accountPool');
    await pool.init();
    const token = await pool.getActiveToken(ACCOUNT_POOL_TYPE);
    return toPoolTokenShape(token);
  } catch {
    return null;
  }
}

function persistObservedToken(token = null) {
  if (!token || !token.accessToken) return;
  Promise.resolve().then(async () => {
    try {
      const pool = require('../../accountPool');
      await pool.init();
      await pool.saveObservedToken(ACCOUNT_POOL_TYPE, {
        accessToken: token.accessToken,
        refreshToken: token.refreshToken || null,
        sourcePath: token.path || '',
        label: token.source ? `${ACCOUNT_POOL_TYPE}:${token.source}` : ACCOUNT_POOL_TYPE,
        authData: {
          source: token.source || ACCOUNT_POOL_TYPE,
          path: token.path || '',
          expiresAt: token.expiresAt || null,
        },
      }, { activateIfNone: true });
    } catch { /* ignore */ }
  });
}

async function listModels() {
  detect(true);
  const poolToken = await getPoolActiveToken();
  if (poolToken && hasTokenShape(poolToken.accessToken)) {
    _token = poolToken;
    _available = true;
  }
  if (_token && hasTokenShape(_token.accessToken)) {
    persistObservedToken(_token);
  }
  return KNOWN_MODELS.map(m => ({
    ...m,
    provider: 'cursor',
    description: '',
  }));
}

/**
 * Generate a response using Cursor's API.
 * Falls back to OpenAI-compatible endpoint if direct API unavailable.
 */
async function generate(prompt, options = {}) {
  const poolToken = await getPoolActiveToken();
  if (poolToken && hasTokenShape(poolToken.accessToken)) {
    _token = poolToken;
    _available = true;
  }

  if (!detect()) {
    return { success: false, content: '', provider: 'Cursor', adapter: 'cursor', attempts: [] };
  }

  persistObservedToken(_token);

  const model = options.model || 'gpt-4o';
  const onChunk = options.onChunk || (() => {});

  try {
    // Use OpenAI-compatible endpoint
    const content = await cursorChat(prompt, model, onChunk);
    return {
      success: true,
      content,
      provider: `Cursor (${model})`,
      adapter: 'cursor',
      attempts: [{ provider: 'Cursor', success: true }],
    };
  } catch (err) {
    return {
      success: false,
      content: '',
      provider: 'Cursor',
      adapter: 'cursor',
      attempts: [{ provider: 'Cursor', success: false, error: err.message }],
    };
  }
}

/**
 * Call Cursor's API endpoint.
 */
function cursorChat(prompt, model, onChunk) {
  return requestJson(
    'https://api2.cursor.sh/v1/chat/completions',
    {
      method: 'POST',
      timeout: TIMEOUT_MS,
      headers: sanitizeOutgoingHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${_token.accessToken}`,
      }),
      body: {
        model,
        messages: [{ role: 'user', content: prompt }],
        stream: false,
      },
    },
    {
      namespace: 'cursor',
      envKeys: ['CURSOR_HTTP_PROXY', 'CURSOR_HTTPS_PROXY', 'CURSOR_PROXY', 'CURSOR_ALL_PROXY'],
      autoEnvKey: 'CURSOR_AUTO_PROXY',
      portsEnvKey: 'CURSOR_AUTO_PROXY_PORTS',
    }
  ).then((res) => {
    const statusCode = Number(res.status || 0);
    if (statusCode === 401 || statusCode === 403) {
      throw new Error(`Cursor auth failed (${statusCode})`);
    }
    if (statusCode < 200 || statusCode >= 300) {
      throw new Error(`Cursor API HTTP ${statusCode}`);
    }

    const result = res.data || {};
    if (result.choices?.[0]?.message?.content) {
      const text = result.choices[0].message.content;
      onChunk({ type: 'text', text });
      return text;
    }
    if (result.error) {
      throw new Error(result.error.message || 'Cursor API error');
    }
    throw new Error(`Invalid response from Cursor API (HTTP ${statusCode})`);
  });
}

function getStatus() {
  detect();
  return {
    name: 'Cursor IDE',
    type: 'cursor',
    available: _available,
    detail: _available
      ? `Token 有效 (${KNOWN_MODELS.length} 个模型)`
      : '未检测到 Cursor token — 请先登录 Cursor IDE',
  };
}

function destroy() {
  _available = null;
  _token = null;
}

module.exports = { detect, detectAsync, listModels, generate, getStatus, destroy };
