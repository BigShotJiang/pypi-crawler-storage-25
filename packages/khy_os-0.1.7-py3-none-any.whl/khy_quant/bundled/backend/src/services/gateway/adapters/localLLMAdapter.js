/**
 * Local LLM Adapter — run GGUF models directly via node-llama-cpp.
 *
 * No external service required. Model is loaded once into the Node.js process.
 * Detection: check if GGUF file exists at LOCAL_MODEL_PATH.
 * Generation: direct inference via node-llama-cpp.
 */
const localLLMService = require('../../localLLMService');
const runtime = require('../../khyUpgradeRuntime');
const { normalizeImages } = require('./_imageCompat');
const DEFAULT_MODEL = process.env.LOCAL_LLM_MODEL || 'qwen3.5:4b';

let _available = null;

function classifyLocalErrorType(message) {
  const lower = String(message || '').toLowerCase();
  if (/\baborted\b|\brequest aborted\b|\babort(ed)? by\b|signal aborted|user[-\s]?cancel/.test(lower)) return 'cancelled';
  if (/\bcancelled\b|\bcanceled\b/.test(lower)) return 'process';
  if (/timeout|timed out|stalled/.test(lower)) return 'timeout';
  if (/not support|unsupported|image/.test(lower)) return 'unsupported';
  if (/no inference backend available|not installed|not found|model file/.test(lower)) return 'unavailable';
  if (/eacces|eperm|permission/.test(lower)) return 'permission';
  return 'unknown';
}

/**
 * Detect if local model is available.
 */
function detect(forceRefresh = false) {
  if (_available !== null && !forceRefresh) return _available;
  _available = localLLMService.isModelAvailable();
  return _available;
}

/**
 * Async detection — check if model file exists (don't trigger loading).
 */
async function detectAsync() {
  _available = localLLMService.isModelAvailable();
  return _available;
}

/**
 * Generate response using local GGUF model.
 */
async function generate(prompt, options = {}) {
  // Graceful image degradation: strip images and proceed with text-only
  // (local GGUF models typically don't support vision; don't hard-fail)
  // Defensive normalize — gateway already does this, but keep it idempotent
  if (Array.isArray(options.images) && options.images.length > 0) {
    options.images = normalizeImages(options.images);
  }
  if (Array.isArray(options.images) && options.images.length > 0) {
    const stripped = { ...options, images: undefined };
    Object.assign(options, stripped);
    // Append a note so the model knows images were provided but not visible
    if (!prompt.includes('[Note: ')) {
      prompt += '\n\n[Note: The user attached image(s) but this local model does not support vision. Respond based on the text content only.]';
    }
  }

  const sourceText = options.userMessage || prompt || '';
  const forcedTemperature = runtime.lockTemperature(sourceText);
  const forcedTopP = runtime.lockTopP(sourceText);

  try {
    // Ensure model is loaded (first call triggers loading)
    await localLLMService.ensureLoaded();

    // Build prompt from structured messages if available
    let fullPrompt = prompt;
    if (options.messages && Array.isArray(options.messages) && options.messages.length > 0) {
      const parts = [];
      if (options.system) {
        parts.push(`<|im_start|>system\n${options.system}<|im_end|>`);
      }
      for (const msg of options.messages) {
        if (msg.role === 'user') {
          parts.push(`<|im_start|>user\n${msg.content}<|im_end|>`);
        } else if (msg.role === 'assistant') {
          parts.push(`<|im_start|>assistant\n${msg.content}<|im_end|>`);
        } else if (msg.role === 'tool') {
          parts.push(`<|im_start|>user\n[Tool Results]: ${msg.content}<|im_end|>`);
        }
      }
      parts.push('<|im_start|>assistant\n');
      fullPrompt = parts.join('\n');
    } else if (options.system) {
      fullPrompt = `<|im_start|>system\n${options.system}<|im_end|>\n<|im_start|>user\n${prompt}<|im_end|>\n<|im_start|>assistant\n`;
    }

    const response = await localLLMService.generate(fullPrompt, {
      temperature: forcedTemperature,
      top_p: forcedTopP,
      maxTokens: options.maxTokens || 1024,
      system: options.system,
      messages: options.messages,
      onChunk: typeof options.onChunk === 'function' ? options.onChunk : undefined,
      timeoutMs: options.timeoutMs || 120_000,
    });

    // generateRunner always returns { content, thinking, tokenUsage }
    const content = typeof response === 'object' ? response.content : response;
    const thinking = typeof response === 'object' ? response.thinking : undefined;
    const tokenUsage = typeof response === 'object' ? response.tokenUsage : undefined;

    const modelName = DEFAULT_MODEL;
    return {
      success: true,
      content,
      thinking,
      tokenUsage,
      provider: `Local (${modelName})`,
      adapter: 'localLLM',
      model: modelName,
      attempts: [{ provider: `Local (${modelName})`, success: true }],
    };
  } catch (err) {
    const message = String(err && err.message ? err.message : err || 'local llm error');
    const errorType = classifyLocalErrorType(message);
    return {
      success: false,
      content: '',
      provider: 'Local LLM',
      adapter: 'localLLM',
      error: message,
      errorType,
      attempts: [{ provider: `Local (${DEFAULT_MODEL})`, success: false, error: message, errorType }],
    };
  }
}

/**
 * Get adapter status.
 */
function getStatus() {
  const status = localLLMService.getStatus();
  const backendLabel = {
    'ollama-runner': 'ollama-runner 独立引擎',
    'node-llama-cpp': 'node-llama-cpp',
    'python-server': 'Python 推理服务器',
    'ollama': 'Ollama HTTP API',
  }[status.backend] || '未加载';

  return {
    name: '本地模型',
    type: 'localLLM',
    available: status.available,
    detail: status.loaded
      ? `模型已加载 (${backendLabel})，就绪`
      : status.available
        ? '模型文件就绪，等待首次加载'
        : `模型文件不存在: ${status.modelPath}`,
  };
}

/**
 * Get list of available models.
 */
function getModels() {
  return localLLMService.isModelAvailable() ? [DEFAULT_MODEL] : [];
}

async function listModels() {
  const models = getModels();
  if (models.length === 0) return [];
  return models.map((id, idx) => ({
    id,
    name: id,
    provider: 'localLLM',
    description: 'node-llama-cpp local model',
    isDefault: idx === 0,
  }));
}

function destroy() {
  localLLMService.dispose();
  _available = null;
}

module.exports = { detect, detectAsync, generate, getStatus, getModels, listModels, destroy };
