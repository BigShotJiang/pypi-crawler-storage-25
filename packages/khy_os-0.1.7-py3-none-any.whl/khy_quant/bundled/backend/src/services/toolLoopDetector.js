'use strict';

/**
 * toolLoopDetector.js — 8-detector tool loop detection system.
 *
 * Ported from OpenClaw's tool-loop-detection.ts concept with KHY-specific tuning,
 * enhanced with Qwen Code-inspired detectors 6-8.
 *
 * Detectors:
 *   1. genericRepeat     — Same tool+params hash appears repeatedly
 *   2. unknownToolRepeat — Model repeatedly calls non-existent tools
 *   3. noProgressStreak  — Same tool+params+result hash (output unchanged)
 *   4. pingPong          — Two tools alternate without progress
 *   5. circuitBreaker    — Global call count hard limit
 *   6. contentChanting   — AI output text loops (same fragment repeated)
 *   7. readFileLoop      — Excessive read-like tool calls (with cold-start gate)
 *   8. actionStagnation  — Same tool name repeatedly (regardless of params)
 *
 * Severity levels: 'ok' → 'warning' → 'critical' → 'circuit_breaker'
 */

const { fnv1aHash } = require('./contextWasm');

// ── Defaults ────────────────────────────────────────────────────────

const DEFAULT_CONFIG = {
  historySize: 30,
  warningThreshold: 5,
  criticalThreshold: 8,
  circuitBreakerThreshold: 12,
  unknownToolThreshold: 3,
  noProgressWarning: 3,
  noProgressCritical: 5,
  pingPongThreshold: 4,
  // Detector 6: content chanting
  contentChunkSize: 50,
  contentChantThreshold: 8,
  contentMaxBuffer: 1000,
  // Detector 7: read-file loop
  readFileWindow: 15,
  readFileThreshold: 8,
  // Detector 8: action stagnation
  stagnationThreshold: 8,
};

// ── Read-like tool classification ───────────────────────────────────

const READ_LIKE_EXACT = new Set([
  'read_file', 'readfile', 'read_many_files', 'readmanyfiles',
  'list_directory', 'listdirectory', 'listdir',
]);

function _isReadLikeTool(name) {
  const norm = _normalizeName(name);
  if (READ_LIKE_EXACT.has(norm)) return true;
  // Prefix match: read_*, list_* (but not "review", "listener", etc.)
  const lower = String(name).toLowerCase();
  return lower.startsWith('read_') || lower.startsWith('list_');
}

// ── Structural content filters (for chanting false-positive prevention) ──

const STRUCTURAL_PATTERNS = [
  /```/,                           // code fence
  /(^|\n)\s*(\|.*\||[|+-]{3,})/,  // table
  /(^|\n)\s*[*\-+]\s/,            // unordered list
  /(^|\n)\s*\d+\.\s/,             // ordered list
  /(^|\n)#+\s/,                   // heading
  /(^|\n)>\s/,                    // blockquote
];

// ── Name normalization (consistent with repl.js _formatToolResult) ───

function _normalizeName(name) {
  // Normalize aggressively so variants like:
  //   shell_command / shell-command / shellCommand / shell_command(...)
  // map to the same token and avoid false "unknown tool" loops.
  return String(name).toLowerCase().replace(/[^a-z0-9]/g, '');
}

// ── Stable hash helper ──────────────────────────────────────────────

function stableStringify(obj) {
  if (obj === null || obj === undefined) return '';
  if (typeof obj !== 'object') return String(obj);
  if (Array.isArray(obj)) return '[' + obj.map(stableStringify).join(',') + ']';
  const keys = Object.keys(obj).sort();
  return '{' + keys.map(k => `${k}:${stableStringify(obj[k])}`).join(',') + '}';
}

function hashCall(toolName, params) {
  return fnv1aHash(`${toolName}|${stableStringify(params)}`);
}

function hashResult(result) {
  if (!result) return '0';
  const key = result.success
    ? (result.output || result.content || result.result || 'ok')
    : (result.error || 'fail');
  return fnv1aHash(typeof key === 'string' ? key : stableStringify(key));
}

// ── Detector class ──────────────────────────────────────────────────

class ToolLoopDetector {
  constructor(config = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.history = [];       // ToolCallRecord[]
    this.totalCalls = 0;
    this.unknownToolCount = 0;

    // Track registered tool names for unknown-tool detection
    this._knownTools = new Set();

    // Detector 6: content chanting
    this._contentBuffer = '';
    this._contentHashes = new Map();  // hash → position[]
    this._contentLastIdx = 0;
    this._inCodeBlock = false;

    // Detector 7: read-file loop
    this._recentToolNames = [];
    this._hasSeenNonReadTool = false;

    // Detector 8: action stagnation
    this._lastToolName = null;
    this._sameNameStreak = 0;
  }

  /**
   * Register known tool names so we can detect unknown tool calls.
   * @param {Iterable<string>} names
   */
  registerTools(names) {
    for (const n of names) {
      this._knownTools.add(n);
      this._knownTools.add(_normalizeName(n));
    }
  }

  /**
   * Record a tool call (before execution).
   * @param {string} toolName
   * @param {object} params
   */
  recordCall(toolName, params) {
    const callHash = hashCall(toolName, params);
    const isUnknown = this._knownTools.size > 0
      && !this._knownTools.has(toolName)
      && !this._knownTools.has(_normalizeName(toolName));

    this.history.push({
      toolName,
      callHash,
      resultHash: null,
      isUnknown,
      timestamp: Date.now(),
    });

    this.totalCalls++;
    if (isUnknown) this.unknownToolCount++;

    // Update detector 7 (read-file loop) state
    this._recentToolNames.push(toolName);
    while (this._recentToolNames.length > this.config.readFileWindow) {
      this._recentToolNames.shift();
    }
    if (!this._hasSeenNonReadTool && !_isReadLikeTool(toolName)) {
      this._hasSeenNonReadTool = true;
    }

    // Update detector 8 (action stagnation) state
    const normName = _normalizeName(toolName);
    if (normName === _normalizeName(this._lastToolName || '')) {
      this._sameNameStreak++;
    } else {
      this._lastToolName = toolName;
      this._sameNameStreak = 1;
    }

    // Reset content tracking on tool call (AI producing tool calls, not text)
    this._contentBuffer = '';
    this._contentHashes.clear();
    this._contentLastIdx = 0;

    // Keep history bounded
    while (this.history.length > this.config.historySize) {
      const removed = this.history.shift();
      if (removed.isUnknown) this.unknownToolCount--;
    }
  }

  /**
   * Record tool execution outcome (after execution).
   * @param {string} toolName
   * @param {object} params
   * @param {object} result
   */
  recordOutcome(toolName, params, result) {
    const callHash = hashCall(toolName, params);
    const rHash = hashResult(result);

    // Find the most recent matching call record and attach the result hash
    for (let i = this.history.length - 1; i >= 0; i--) {
      if (this.history[i].callHash === callHash && this.history[i].resultHash === null) {
        this.history[i].resultHash = rHash;
        break;
      }
    }
  }

  /**
   * Check all 8 detectors before executing a tool call.
   * @param {string} toolName
   * @param {object} params
   * @returns {{ stuck: boolean, level: string, detector: string, message: string }}
   */
  check(toolName, params) {
    const results = [
      this._checkCircuitBreaker(),
      this._checkGenericRepeat(toolName, params),
      this._checkUnknownTool(toolName),
      this._checkNoProgress(toolName, params),
      this._checkPingPong(toolName),
      this._checkContentChanting(),
      this._checkReadFileLoop(),
      this._checkActionStagnation(),
    ];

    // Return the most severe detection
    const SEVERITY = { ok: 0, warning: 1, critical: 2, circuit_breaker: 3 };
    let worst = { stuck: false, level: 'ok', detector: 'none', message: '' };

    for (const r of results) {
      if (SEVERITY[r.level] > SEVERITY[worst.level]) {
        worst = r;
      }
    }

    return worst;
  }

  /**
   * Reset all state.
   */
  reset() {
    this.history = [];
    this.totalCalls = 0;
    this.unknownToolCount = 0;
    // Detector 6
    this._contentBuffer = '';
    this._contentHashes.clear();
    this._contentLastIdx = 0;
    this._inCodeBlock = false;
    // Detector 7
    this._recentToolNames = [];
    this._hasSeenNonReadTool = false;
    // Detector 8
    this._lastToolName = null;
    this._sameNameStreak = 0;
  }

  // ── Individual detectors ──────────────────────────────────────────

  _checkCircuitBreaker() {
    if (this.totalCalls >= this.config.circuitBreakerThreshold) {
      return {
        stuck: true,
        level: 'circuit_breaker',
        detector: 'circuitBreaker',
        message: `Circuit breaker tripped: ${this.totalCalls} total tool calls (limit: ${this.config.circuitBreakerThreshold}).`,
      };
    }
    return { stuck: false, level: 'ok', detector: 'circuitBreaker', message: '' };
  }

  _checkGenericRepeat(toolName, params) {
    const callHash = hashCall(toolName, params);
    let count = 0;
    for (const rec of this.history) {
      if (rec.callHash === callHash) count++;
    }

    if (count >= this.config.criticalThreshold) {
      return {
        stuck: true,
        level: 'critical',
        detector: 'genericRepeat',
        message: `Tool "${toolName}" called ${count} times with identical params (critical threshold: ${this.config.criticalThreshold}).`,
      };
    }
    if (count >= this.config.warningThreshold) {
      return {
        stuck: false,
        level: 'warning',
        detector: 'genericRepeat',
        message: `Tool "${toolName}" called ${count} times with identical params. Consider a different approach.`,
      };
    }
    return { stuck: false, level: 'ok', detector: 'genericRepeat', message: '' };
  }

  _checkUnknownTool(toolName) {
    if (this._knownTools.size === 0) {
      return { stuck: false, level: 'ok', detector: 'unknownTool', message: '' };
    }
    if (this._knownTools.has(toolName) || this._knownTools.has(_normalizeName(toolName))) {
      return { stuck: false, level: 'ok', detector: 'unknownTool', message: '' };
    }
    if (this.unknownToolCount >= this.config.unknownToolThreshold) {
      return {
        stuck: true,
        level: 'critical',
        detector: 'unknownTool',
        message: `Model has called ${this.unknownToolCount} unknown tools. Latest: "${toolName}".`,
      };
    }
    return {
      stuck: false,
      level: 'warning',
      detector: 'unknownTool',
      message: `Unknown tool "${toolName}". ${this.unknownToolCount} unknown calls so far.`,
    };
  }

  _checkNoProgress(toolName, params) {
    const callHash = hashCall(toolName, params);

    // Count consecutive entries with same call+result hash at the tail
    let streak = 0;
    let lastResultHash = null;
    for (let i = this.history.length - 1; i >= 0; i--) {
      const rec = this.history[i];
      if (rec.callHash !== callHash) break;
      if (rec.resultHash === null) continue; // not yet resolved

      if (lastResultHash === null) {
        lastResultHash = rec.resultHash;
        streak = 1;
      } else if (rec.resultHash === lastResultHash) {
        streak++;
      } else {
        break;
      }
    }

    if (streak >= this.config.noProgressCritical) {
      return {
        stuck: true,
        level: 'critical',
        detector: 'noProgress',
        message: `No progress: "${toolName}" returned identical results ${streak} times.`,
      };
    }
    if (streak >= this.config.noProgressWarning) {
      return {
        stuck: false,
        level: 'warning',
        detector: 'noProgress',
        message: `"${toolName}" returned the same result ${streak} times. Try a different approach.`,
      };
    }
    return { stuck: false, level: 'ok', detector: 'noProgress', message: '' };
  }

  _checkPingPong(toolName) {
    if (this.history.length < 4) {
      return { stuck: false, level: 'ok', detector: 'pingPong', message: '' };
    }

    // Look for A→B→A→B pattern at the tail
    const tail = this.history.slice(-this.config.pingPongThreshold * 2);
    if (tail.length < 4) {
      return { stuck: false, level: 'ok', detector: 'pingPong', message: '' };
    }

    const toolA = tail[tail.length - 2]?.toolName;
    const toolB = tail[tail.length - 1]?.toolName;

    if (!toolA || !toolB || toolA === toolB) {
      return { stuck: false, level: 'ok', detector: 'pingPong', message: '' };
    }

    let pingPongCount = 0;
    for (let i = tail.length - 1; i >= 1; i -= 2) {
      if (tail[i].toolName === toolB && tail[i - 1].toolName === toolA) {
        pingPongCount++;
      } else {
        break;
      }
    }

    if (pingPongCount >= this.config.pingPongThreshold) {
      return {
        stuck: true,
        level: 'warning',
        detector: 'pingPong',
        message: `Ping-pong detected: "${toolA}" ↔ "${toolB}" alternating ${pingPongCount} times.`,
      };
    }
    return { stuck: false, level: 'ok', detector: 'pingPong', message: '' };
  }

  // ── Detector 6: Content Chanting ───────────────────────────────────

  /**
   * Feed AI output text for chanting detection.
   * Call this with each text chunk from the AI response.
   * @param {string} text
   */
  feedContent(text) {
    if (!text || typeof text !== 'string') return;

    // Check for code fence toggle
    const fenceCount = (text.match(/```/g) || []).length;
    if (fenceCount % 2 !== 0) this._inCodeBlock = !this._inCodeBlock;

    // Skip structural content that would cause false positives
    if (this._inCodeBlock) return;
    for (const pat of STRUCTURAL_PATTERNS) {
      if (pat.test(text)) return;
    }

    // Accumulate buffer
    this._contentBuffer += text;

    // Cap buffer size — truncate from the front
    const maxBuf = this.config.contentMaxBuffer;
    if (this._contentBuffer.length > maxBuf) {
      const excess = this._contentBuffer.length - maxBuf;
      this._contentBuffer = this._contentBuffer.slice(excess);
      // Adjust all stored positions
      for (const [hash, positions] of this._contentHashes) {
        const adjusted = positions.map(p => p - excess).filter(p => p >= 0);
        if (adjusted.length === 0) {
          this._contentHashes.delete(hash);
        } else {
          this._contentHashes.set(hash, adjusted);
        }
      }
      this._contentLastIdx = Math.max(0, this._contentLastIdx - excess);
    }

    // Analyze new region: slide 1-char at a time, hash 50-char chunks
    const chunkSize = this.config.contentChunkSize;
    const buf = this._contentBuffer;

    while (this._contentLastIdx + chunkSize <= buf.length) {
      const slice = buf.slice(this._contentLastIdx, this._contentLastIdx + chunkSize);
      const hash = fnv1aHash(slice);

      if (!this._contentHashes.has(hash)) {
        this._contentHashes.set(hash, []);
      }
      this._contentHashes.get(hash).push(this._contentLastIdx);

      this._contentLastIdx++;
    }
  }

  _checkContentChanting() {
    const threshold = this.config.contentChantThreshold;
    const chunkSize = this.config.contentChunkSize;
    const maxAvgDist = chunkSize * 1.5;

    for (const [, positions] of this._contentHashes) {
      if (positions.length < threshold) continue;

      // Check average distance of last N positions
      const recent = positions.slice(-threshold);
      const first = recent[0];
      const last = recent[recent.length - 1];
      const avgDist = (last - first) / (recent.length - 1);

      if (avgDist <= maxAvgDist) {
        return {
          stuck: true,
          level: 'critical',
          detector: 'contentChanting',
          message: `Content chanting detected: same ${chunkSize}-char fragment repeated ${positions.length} times with avg distance ${Math.round(avgDist)} chars.`,
        };
      }
    }
    return { stuck: false, level: 'ok', detector: 'contentChanting', message: '' };
  }

  // ── Detector 7: Read-File Loop ────────────────────────────────────

  _checkReadFileLoop() {
    // Cold-start gate: don't trigger until we've seen at least one non-read tool
    if (!this._hasSeenNonReadTool) {
      return { stuck: false, level: 'ok', detector: 'readFileLoop', message: '' };
    }

    const window = this._recentToolNames;
    if (window.length < this.config.readFileThreshold) {
      return { stuck: false, level: 'ok', detector: 'readFileLoop', message: '' };
    }

    const readCount = window.filter(n => _isReadLikeTool(n)).length;
    if (readCount >= this.config.readFileThreshold) {
      return {
        stuck: true,
        level: 'warning',
        detector: 'readFileLoop',
        message: `Read-file loop: ${readCount} of last ${window.length} tool calls are read-like. Take action instead of just reading.`,
      };
    }
    return { stuck: false, level: 'ok', detector: 'readFileLoop', message: '' };
  }

  // ── Detector 8: Action Stagnation ─────────────────────────────────

  _checkActionStagnation() {
    if (this._sameNameStreak >= this.config.stagnationThreshold) {
      return {
        stuck: true,
        level: 'warning',
        detector: 'actionStagnation',
        message: `Action stagnation: tool "${this._lastToolName}" called ${this._sameNameStreak} times consecutively. Try a different tool.`,
      };
    }
    return { stuck: false, level: 'ok', detector: 'actionStagnation', message: '' };
  }
}

module.exports = { ToolLoopDetector, DEFAULT_CONFIG };
