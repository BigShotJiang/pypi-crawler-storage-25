/**
 * Command Registry — extensible, priority-based slash command system.
 *
 * Replaces the static SLASH_COMMANDS array with a dynamic registry that
 * supports registration from multiple sources (builtin, tools, plugins, MCP).
 *
 * Higher priority sources win on collision. Categories group commands
 * for display in the `/` menu.
 *
 * Falls back gracefully — router.js keeps _STATIC_SLASH_COMMANDS as safety net.
 */

// ── Priority levels (higher wins on collision) ────────────────────

const PRIORITY = {
  builtin: 100,
  tool: 80,
  plugin: 60,
  mcp: 40,
  user: 20,
};

// ── Category definitions ──────────────────────────────────────────

const CATEGORIES = {
  model:    'AI \u6a21\u578b',     // AI 模型
  data:     '\u6570\u636e\u7ba1\u7406', // 数据管理
  security: '\u5b89\u5168',       // 安全
  dev:      '\u5f00\u53d1\u5de5\u5177', // 开发工具
  workflow: '\u5de5\u4f5c\u6d41',   // 工作流
  system:   '\u7cfb\u7edf',       // 系统
};

// ── Registry state ────────────────────────────────────────────────

const _commands = new Map(); // cmd → { cmd, label, desc, route, flag, category, priority, source }
let _categoryCache = null;   // invalidated on mutation

// ── Category assignment for builtin commands ─────────────────────

const _builtinCategories = {
  '/model': 'model', '/models': 'model', '/gateway': 'model',
  '/max': 'model', '/high': 'model', '/medium': 'model', '/low': 'model',

  '/cost': 'data', '/history': 'data', '/prompt': 'data',
  '/knowledge': 'data', '/growth': 'data',

  '/permissions': 'security', '/security': 'security', '/scan': 'security',

  '/review': 'dev', '/doctor': 'dev', '/hardware': 'dev',
  '/clipboard': 'dev', '/websearch': 'dev', '/image': 'dev', '/paste': 'dev', '/image2web': 'dev',
  '/publish': 'dev',

  '/agent': 'workflow', '/skill': 'workflow', '/plan': 'workflow',
  '/profile': 'workflow', '/habit': 'workflow', '/resume': 'workflow',
  '/memory': 'workflow', '/proxy': 'workflow', '/subscribe': 'workflow',

  '/linux': 'system',
  '/help': 'system', '/clear': 'system', '/exit': 'system',
  '/update': 'system', '/cleanup': 'system',
};

// ── Public API ────────────────────────────────────────────────────

/**
 * Register a single command definition.
 * Lower priority sources do NOT overwrite higher priority ones.
 *
 * @param {object} cmdDef - { cmd, label, desc, route?, flag?, category? }
 * @param {string} [source='user'] - Source identifier (builtin|tool|plugin|mcp|user)
 */
function register(cmdDef, source = 'user') {
  if (!cmdDef || !cmdDef.cmd) return;
  const priority = PRIORITY[source] ?? PRIORITY.user;

  const existing = _commands.get(cmdDef.cmd);
  if (existing && existing.priority > priority) return; // higher priority already registered

  _commands.set(cmdDef.cmd, {
    cmd: cmdDef.cmd,
    label: cmdDef.label || cmdDef.cmd.slice(1),
    desc: cmdDef.desc || '',
    route: cmdDef.route || null,
    flag: cmdDef.flag || null,
    category: cmdDef.category || _builtinCategories[cmdDef.cmd] || 'system',
    priority,
    source,
    // Plugin SDK fields (preserved for dispatch)
    _pluginHandler: cmdDef._pluginHandler || null,
    _pluginNamespace: cmdDef._pluginNamespace || null,
    _aliases: cmdDef._aliases || null,
    _completer: cmdDef._completer || null,
  });
  _categoryCache = null;
}

/**
 * Bulk-register commands from a single source.
 *
 * @param {Array} commands - Array of command definitions
 * @param {string} [source='builtin'] - Source identifier
 */
function registerBulk(commands, source = 'builtin') {
  if (!Array.isArray(commands)) return;
  for (const cmd of commands) {
    register(cmd, source);
  }
}

/**
 * Get all commands sorted by category then priority.
 * @returns {Array}
 */
function getAll() {
  const arr = [..._commands.values()];
  arr.sort((a, b) => {
    const catOrder = Object.keys(CATEGORIES);
    const catA = catOrder.indexOf(a.category);
    const catB = catOrder.indexOf(b.category);
    if (catA !== catB) return (catA === -1 ? 999 : catA) - (catB === -1 ? 999 : catB);
    return b.priority - a.priority;
  });
  return arr;
}

/**
 * Get commands grouped by category.
 * @returns {object} { model: [...], data: [...], ... }
 */
function getByCategory() {
  if (_categoryCache) return _categoryCache;

  const grouped = {};
  for (const cat of Object.keys(CATEGORIES)) {
    grouped[cat] = [];
  }

  for (const cmd of _commands.values()) {
    const cat = cmd.category;
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(cmd);
  }

  // Sort each group by priority desc
  for (const cat of Object.keys(grouped)) {
    grouped[cat].sort((a, b) => b.priority - a.priority);
  }

  // Remove empty categories
  for (const cat of Object.keys(grouped)) {
    if (grouped[cat].length === 0) delete grouped[cat];
  }

  _categoryCache = grouped;
  return grouped;
}

/**
 * Tab-completion: return commands matching a partial prefix.
 * @param {string} partial - e.g. '/mo'
 * @returns {string[]} - e.g. ['/model', '/models']
 */
function getCompletions(partial) {
  if (!partial) return [];
  const lower = partial.toLowerCase();
  const matches = [];
  for (const cmd of _commands.keys()) {
    if (cmd.toLowerCase().startsWith(lower)) {
      matches.push(cmd);
    }
  }
  return matches.sort();
}

/**
 * Unregister a command by name.
 * @param {string} cmd
 */
function unregister(cmd) {
  _commands.delete(cmd);
  _categoryCache = null;
}

/**
 * Convert to the legacy SLASH_COMMANDS array format for backward compatibility.
 * @returns {Array<{cmd, label, desc, route, flag}>}
 */
function toSlashCommands() {
  return getAll().map(({ cmd, label, desc, route, flag }) => ({ cmd, label, desc, route, flag }));
}

/**
 * Clear internal caches (call when tools/plugins change).
 */
function clearCache() {
  _categoryCache = null;
}

/**
 * Get the total number of registered commands.
 * @returns {number}
 */
function count() {
  return _commands.size;
}

// ── Initialization: seed built-in commands ────────────────────────

const _BUILTIN_COMMANDS = [
  { cmd: '/model',       label: '\u5207\u6362 AI \u6a21\u578b',     desc: '\u9009\u62e9 AI \u670d\u52a1\u63d0\u4f9b\u5546\u548c\u6a21\u578b',           route: 'gateway model' },
  { cmd: '/memory',      label: '\u67e5\u770b\u6307\u4ee4\u6587\u4ef6',     desc: '\u7ba1\u7406 khy.md \u6307\u4ee4\u6587\u4ef6',               route: 'memory' },
  { cmd: '/plan',        label: '\u8ba1\u5212\u6a21\u5f0f',         desc: 'AI \u5236\u5b9a\u6267\u884c\u8ba1\u5212\u540e\u518d\u64cd\u4f5c',             route: null, flag: 'plan' },
  { cmd: '/cost',        label: '\u67e5\u770b\u8d39\u7528',         desc: '\u67e5\u770b Token \u7528\u91cf\u548c\u8d39\u7528\u7edf\u8ba1',           route: 'cost' },
  { cmd: '/permissions', label: '\u5b89\u5168\u6743\u9650',         desc: '\u67e5\u770b\u5b89\u5168\u72b6\u6001\u548c\u6743\u9650\u8bbe\u7f6e',              route: 'security status' },
  { cmd: '/history',     label: '\u5bf9\u8bdd\u5386\u53f2',         desc: '\u67e5\u770b\u548c\u6062\u590d\u5386\u53f2\u5bf9\u8bdd',                  route: 'history list' },
  { cmd: '/profile',     label: '\u7528\u6237\u753b\u50cf',         desc: '\u67e5\u770b\u4f7f\u7528\u4e60\u60ef\u548c\u7528\u6237\u753b\u50cf',              route: 'profile' },
  { cmd: '/growth',      label: '\u6210\u957f\u6863\u6848',         desc: '\u67e5\u770b\u91cf\u5316\u5b66\u4e60\u6210\u957f\u8fdb\u5ea6',                route: 'growth' },
  { cmd: '/knowledge',   label: '\u77e5\u8bc6\u5e93',           desc: '\u641c\u7d22\u548c\u7ba1\u7406\u91cf\u5316\u77e5\u8bc6',                  route: 'knowledge' },
  { cmd: '/agent',       label: '\u667a\u80fd\u4f53',           desc: '\u67e5\u770b\u591a\u667a\u80fd\u4f53\u534f\u4f5c\u72b6\u6001',                route: 'agent status' },
  { cmd: '/skill',       label: '\u6280\u80fd\u7ba1\u7406',         desc: '\u67e5\u770b\u3001\u5b89\u88c5\u548c\u7ba1\u7406 Skills',             route: 'skill list' },
  { cmd: '/resume',      label: '\u6062\u590d\u5bf9\u8bdd',         desc: '\u6062\u590d\u4e0a\u6b21\u7684 AI \u5bf9\u8bdd\u4e0a\u4e0b\u6587',            route: 'resume' },
  { cmd: '/gateway',     label: 'AI \u7f51\u5173',          desc: '\u7ba1\u7406 AI \u7f51\u5173\u548c\u9002\u914d\u5668',                route: 'gateway status' },
  { cmd: '/prompt',      label: '\u63d0\u793a\u8bcd\u5e93',         desc: '\u7ba1\u7406\u4fdd\u5b58\u7684\u63d0\u793a\u8bcd\u6a21\u677f',                route: 'prompt list' },
  { cmd: '/cleanup',     label: '\u6e05\u7406\u5b58\u50a8',         desc: '\u6e05\u7406\u5386\u53f2\u6570\u636e\u91ca\u653e\u78c1\u76d8\u7a7a\u95f4',            route: 'cleanup status' },
  { cmd: '/proxy',       label: '\u4ee3\u7406\u8bbe\u7f6e',         desc: '\u914d\u7f6e Clash/HTTP/SOCKS5 \u4ee3\u7406',         route: null, flag: 'proxy' },
  { cmd: '/models',      label: '\u6a21\u578b\u7ba1\u7406',         desc: 'Ollama/NVIDIA \u6a21\u578b\u4e0b\u8f7d\u7ba1\u7406',          route: null, flag: 'models' },
  { cmd: '/image',       label: '\u56fe\u7247\u5206\u6790',         desc: '\u52a0\u8f7d\u56fe\u7247\u6587\u4ef6\u8fdb\u884c\u89c6\u89c9\u5206\u6790\u6216\u7f51\u9875\u8fd8\u539f',          route: null, flag: 'image' },
  { cmd: '/image2web',   label: '\u7f51\u9875\u8fd8\u539f',         desc: '\u5c06\u7f51\u9875\u622a\u56fe\u8f6c\u4e3a\u53ef\u8fd0\u884c HTML \u5e76\u53ef\u9009\u81ea\u52a8\u4fdd\u5b58', route: 'image2web' },
  { cmd: '/paste',       label: '\u7c98\u8d34\u56fe\u7247',         desc: '\u4ece\u526a\u8d34\u677f\u7c98\u8d34\u56fe\u7247\u8fdb\u884c\u5206\u6790',            route: null, flag: 'paste' },
  { cmd: '/doctor',      label: '\u7cfb\u7edf\u8bca\u65ad',         desc: '\u68c0\u67e5\u4f9d\u8d56\u3001\u6570\u636e\u5e93\u3001\u7f51\u7edc\u72b6\u6001',          route: 'doctor' },
  { cmd: '/publish',     label: 'PyPI \u53d1\u5e03',       desc: '\u6784\u5efa/\u6821\u9a8c/\u53d1\u5e03 Python \u5305\u5230 PyPI',        route: 'publish check' },
  { cmd: '/scan',        label: '\u75c5\u6bd2\u626b\u63cf',         desc: 'ClamAV \u75c5\u6bd2\u626b\u63cf\u9879\u76ee\u6587\u4ef6',             route: null, flag: 'scan' },
  { cmd: '/security',    label: '\u5b89\u5168\u72b6\u6001',         desc: '\u5b89\u5168\u72b6\u6001\u3001\u5b8c\u6574\u6027\u6821\u9a8c\u3001\u5a01\u80c1\u626b\u63cf',      route: null, flag: 'security-full' },
  { cmd: '/hardware',    label: '\u786c\u4ef6\u4fe1\u606f',         desc: '\u67e5\u770b\u786c\u4ef6\u914d\u7f6e\u548c\u672c\u5730\u6a21\u578b\u63a8\u8350',          route: null, flag: 'hardware' },
  { cmd: '/review',      label: '\u4ee3\u7801\u5ba1\u67e5',         desc: 'AI \u5ba1\u67e5\u5f53\u524d Git \u6539\u52a8',                route: null, flag: 'review' },
  { cmd: '/clipboard',   label: '\u526a\u8d34\u677f\u4e2d\u7ee7',       desc: '\u901a\u8fc7\u526a\u8d34\u677f\u4f7f\u7528\u514d\u8d39 Web AI',           route: null, flag: 'clipboard' },
  { cmd: '/websearch',   label: '\u8054\u7f51\u641c\u7d22',         desc: '\u901a\u8fc7 Kiro \u641c\u7d22\u7f51\u9875\u83b7\u53d6\u6700\u65b0\u4fe1\u606f',      route: null, flag: 'websearch' },
  { cmd: '/linux',       label: 'Linux \u80fd\u529b',         desc: '\u7f51\u7edc\u8bca\u65ad\u4e0e\u57fa\u7840 Linux \u547d\u4ee4\u6267\u884c',      route: 'linux help' },
  { cmd: '/update',      label: '\u68c0\u67e5\u66f4\u65b0',         desc: '\u68c0\u67e5\u5e76\u5b89\u88c5\u6700\u65b0\u7248\u672c',                  route: 'update' },
  { cmd: '/subscribe',   label: '\u8ba2\u9605\u6307\u5f15',         desc: 'AI \u6a21\u578b\u8ba2\u9605\u4e0e\u83b7\u53d6\u6307\u5357 (\u542b\u56fd\u5185\u65b9\u6848)',  route: null, flag: 'subscribe' },
  { cmd: '/help',        label: '\u5e2e\u52a9',             desc: '\u663e\u793a\u6240\u6709\u53ef\u7528\u547d\u4ee4',                    route: 'help' },
  { cmd: '/clear',       label: '\u6e05\u5c4f',             desc: '\u6e05\u9664\u7ec8\u7aef\u5185\u5bb9',                        route: 'clear' },
  { cmd: '/max',         label: '\u6700\u9ad8\u7cbe\u5ea6',         desc: '\u5207\u6362 AI \u5230\u6700\u9ad8\u7cbe\u5ea6\u6a21\u5f0f',              route: null, flag: 'effort-max' },
  { cmd: '/high',        label: '\u9ad8\u7cbe\u5ea6',           desc: '\u5207\u6362 AI \u5230\u9ad8\u7cbe\u5ea6\u6a21\u5f0f',                route: null, flag: 'effort-high' },
  { cmd: '/medium',      label: '\u6807\u51c6\u7cbe\u5ea6',         desc: '\u5207\u6362 AI \u5230\u6807\u51c6\u7cbe\u5ea6\u6a21\u5f0f',              route: null, flag: 'effort-medium' },
  { cmd: '/low',         label: '\u5feb\u901f\u6a21\u5f0f',         desc: '\u5207\u6362 AI \u5230\u5feb\u901f\u54cd\u5e94\u6a21\u5f0f',              route: null, flag: 'effort-low' },
  { cmd: '/exit',        label: '\u9000\u51fa',             desc: '\u4fdd\u5b58\u5bf9\u8bdd\u5e76\u9000\u51fa khy OS',              route: 'exit' },
];

function _seedBuiltins() {
  registerBulk(_BUILTIN_COMMANDS, 'builtin');
}

// Lazy initialization flag
let _seeded = false;
function _ensureSeeded() {
  if (_seeded) return;
  _seeded = true;
  _seedBuiltins();
}

// Wrap public methods with lazy seeding
const _wrapped = {};
for (const fn of [getAll, getByCategory, getCompletions, toSlashCommands, count]) {
  _wrapped[fn.name] = function (...args) {
    _ensureSeeded();
    return fn(...args);
  };
}

// ── Exports ───────────────────────────────────────────────────────

module.exports = {
  register,
  registerBulk,
  getAll: _wrapped.getAll,
  getByCategory: _wrapped.getByCategory,
  getCompletions: _wrapped.getCompletions,
  toSlashCommands: _wrapped.toSlashCommands,
  count: _wrapped.count,
  unregister,
  clearCache,
  PRIORITY,
  CATEGORIES,
};
