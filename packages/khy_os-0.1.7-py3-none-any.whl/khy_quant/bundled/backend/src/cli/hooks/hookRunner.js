/**
 * Hook Runner — executes hook commands as child processes.
 *
 * Each hook receives context as JSON on stdin and can:
 *   - Exit 0: allow (pass through)
 *   - Exit 2: block (prevent the action)
 *   - Emit JSON on stdout: modify the context
 */
const { spawn } = require('child_process');
const { platformShell } = require('../../tools/platformUtils');

/**
 * Run a single hook (command-based or function-based).
 * @param {Object} hook - Hook definition from registry
 * @param {Object} context - Event context (toolName, args, prompt, etc.)
 * @returns {Promise<{action: 'allow'|'block'|'modify', output?: Object, error?: string}>}
 */
async function runHook(hook, context) {
  // Function-based hooks: call directly
  if (hook.type === 'function' && typeof hook.handler === 'function') {
    return _runFunctionHook(hook, context);
  }

  // Command-based hooks: spawn child process
  return _runCommandHook(hook, context);
}

/**
 * Execute a function-based hook.
 * @private
 */
async function _runFunctionHook(hook, context) {
  try {
    const result = await Promise.race([
      Promise.resolve(hook.handler(context)),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Hook function timed out')), hook.timeout || 10000)
      ),
    ]);

    // Normalize return value
    if (!result || typeof result !== 'object') {
      return { action: 'allow' };
    }
    if (result.action === 'block') {
      return { action: 'block', error: result.reason || 'Blocked by function hook' };
    }
    if (result.action === 'modify') {
      const { action, ...overrides } = result;
      return { action: 'modify', output: overrides };
    }
    return { action: result.action || 'allow', output: result };
  } catch (err) {
    return { action: 'allow', error: err.message };
  }
}

/**
 * Execute a command-based hook via child process.
 * @private
 */
async function _runCommandHook(hook, context) {
  return new Promise((resolve) => {
    const sh = platformShell(hook.command);
    const child = spawn(sh.cmd, sh.args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      timeout: hook.timeout || 10000,
      env: { ...process.env, HOOK_EVENT: hook.event },
    });

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', d => { stdout += d; });
    child.stderr.on('data', d => { stderr += d; });

    child.on('error', (err) => {
      resolve({ action: 'allow', error: err.message });
    });

    child.on('close', (code) => {
      if (code === 2) {
        return resolve({ action: 'block', error: stderr.trim() || 'Blocked by hook' });
      }

      let output;
      if (stdout.trim()) {
        try {
          output = JSON.parse(stdout.trim());
        } catch { /* not JSON, ignore */ }
      }

      resolve({
        action: output ? 'modify' : 'allow',
        output,
        error: code !== 0 ? (stderr.trim() || `Hook exited with code ${code}`) : undefined,
      });
    });

    // Send context as JSON on stdin
    try {
      child.stdin.write(JSON.stringify(context));
      child.stdin.end();
    } catch { /* broken pipe is fine */ }
  });
}

/**
 * Run all hooks for an event sequentially.
 * Returns the final context (potentially modified) and whether to proceed.
 */
async function runHooks(hooks, context) {
  let ctx = { ...context };

  for (const hook of hooks) {
    const result = await runHook(hook, ctx);

    if (result.action === 'block') {
      return { blocked: true, reason: result.error, context: ctx };
    }

    if (result.action === 'modify' && result.output) {
      ctx = { ...ctx, ...result.output };
    }
  }

  return { blocked: false, context: ctx };
}

module.exports = { runHook, runHooks };
