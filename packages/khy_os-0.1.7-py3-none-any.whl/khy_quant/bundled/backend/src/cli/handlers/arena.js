'use strict';

/**
 * CLI handler for the Arena command — run a prompt against multiple models.
 *
 * Usage:
 *   /arena "Implement quicksort" --models gpt-4,claude-sonnet,qwen-max
 *   /arena compare --models gpt-4,claude-sonnet
 *
 * @module handlers/arena
 */

const { ArenaManager, formatArenaResult } = require('../../services/arenaManager');

/**
 * Handle arena command.
 *
 * @param {string} input - The prompt or subcommand
 * @param {object} deps
 * @param {object} deps.aiModule - AI gateway module
 * @param {object} deps.chalk - Chalk instance
 * @param {object} [deps.options] - Parsed CLI options
 * @returns {Promise<void>}
 */
async function handleArena(input, deps) {
  const { aiModule, chalk: c } = deps;
  const options = deps.options || {};

  if (!input || input === 'help') {
    _printHelp(c);
    return;
  }

  // Parse models from --models flag or from config
  let models = [];
  if (options.models) {
    models = options.models.split(',').map((m) => m.trim()).filter(Boolean);
  }

  // Default: use 2-3 available models
  if (models.length === 0) {
    models = _getDefaultModels(aiModule);
  }

  if (models.length < 2) {
    console.log(c.yellow('  Arena requires at least 2 models. Use --models model1,model2'));
    console.log(c.dim('  Available models can be listed with: /models'));
    return;
  }

  // Extract prompt (everything that's not a flag)
  const prompt = input.replace(/--\w+\s+\S+/g, '').trim();
  if (!prompt) {
    console.log(c.yellow('  Please provide a prompt for the arena comparison.'));
    return;
  }

  console.log('');
  console.log(c.bold(`  Starting Arena with ${models.length} models...`));
  models.forEach((m) => console.log(c.dim(`    • ${m}`)));
  console.log('');

  // Create arena manager
  const gateway = aiModule.gateway || aiModule;
  const arena = new ArenaManager(gateway, {
    timeoutMs: options.timeout ? parseInt(options.timeout, 10) * 1000 : 60_000,
  });

  // Progress tracking
  const progress = {};
  const onProgress = (model, event) => {
    if (!progress[model]) progress[model] = { chunks: 0, chars: 0 };
    if (event.type === 'chunk') {
      progress[model].chunks++;
      progress[model].chars += (event.content || '').length;
      // Update spinner
      if (progress[model].chunks % 10 === 0) {
        const total = Object.entries(progress)
          .map(([m, p]) => `${m.split('/').pop()}: ${p.chars}ch`)
          .join(', ');
        process.stdout.write(`\r  ${c.dim(`Receiving... ${total}`)}`);
      }
    }
  };

  try {
    const result = await arena.run({
      prompt,
      models,
      system: options.system || undefined,
      maxTokens: options.maxTokens ? parseInt(options.maxTokens, 10) : undefined,
      temperature: options.temperature ? parseFloat(options.temperature) : undefined,
      onProgress,
    });

    // Clear progress line
    process.stdout.write('\r' + ' '.repeat(120) + '\r');

    // Print formatted result
    console.log(formatArenaResult(result, { chalk: c }));

    // Print individual responses if --verbose
    if (options.verbose) {
      for (const entry of result.entries) {
        if (entry.failed) continue;
        console.log(c.bold(`  ── ${entry.model} ──`));
        console.log('');
        // Indent each line
        const indented = entry.content.split('\n').map((l) => `    ${l}`).join('\n');
        console.log(indented);
        console.log('');
      }
    } else {
      console.log(c.dim('  Use --verbose to see individual model responses.'));
    }
  } catch (err) {
    console.log(c.red(`  Arena failed: ${err.message}`));
  }
}

/**
 * Get default models from the gateway configuration.
 * @param {object} aiModule
 * @returns {string[]}
 */
function _getDefaultModels(aiModule) {
  try {
    // Try to get available models from gateway
    const gw = aiModule.gateway || aiModule;
    if (typeof gw.listModels === 'function') {
      const models = gw.listModels();
      if (Array.isArray(models) && models.length >= 2) {
        return models.slice(0, 3).map((m) => m.id || m.name || m);
      }
    }
    if (typeof gw.getAvailableModels === 'function') {
      const models = gw.getAvailableModels();
      if (Array.isArray(models) && models.length >= 2) {
        return models.slice(0, 3).map((m) => m.id || m.name || m);
      }
    }
  } catch { /* ignore */ }

  return [];
}

/**
 * Print help for the arena command.
 */
function _printHelp(c) {
  console.log('');
  console.log(c.bold('  Arena — Multi-model comparison'));
  console.log('');
  console.log('  Usage:');
  console.log(c.dim('    /arena "Your prompt here" --models model1,model2,model3'));
  console.log('');
  console.log('  Options:');
  console.log(c.dim('    --models <list>      Comma-separated model identifiers'));
  console.log(c.dim('    --system <prompt>    System prompt override'));
  console.log(c.dim('    --maxTokens <n>      Max tokens per response'));
  console.log(c.dim('    --temperature <n>    Temperature (0-2)'));
  console.log(c.dim('    --timeout <s>        Per-model timeout in seconds (default: 60)'));
  console.log(c.dim('    --verbose            Show individual model responses'));
  console.log('');
  console.log('  Examples:');
  console.log(c.dim('    /arena "Implement quicksort" --models gpt-4,claude-sonnet'));
  console.log(c.dim('    /arena "Explain async/await" --models qwen-max,gpt-4,claude-haiku --verbose'));
  console.log('');
}

module.exports = { handleArena };
