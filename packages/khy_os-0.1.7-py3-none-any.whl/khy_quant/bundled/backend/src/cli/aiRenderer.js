/**
 * AI Output Renderer — Claude Code-style terminal output.
 *
 * 1:1 replication of Claude Code's visual system:
 *   - ⏺ dot indicators (not emoji) with exact RGB colors
 *   - English tool names: Bash, Read, Write, Search, Update
 *   - Red/green diff with word-level highlights
 *   - Tree-style collapsible tool use display
 *
 * Color reference (Claude Code dark theme):
 *   claude:    rgb(215,119,87)  — brand orange
 *   success:   rgb(78,186,101)  — green
 *   error:     rgb(255,107,128) — red/pink
 *   warning:   rgb(255,193,7)   — amber
 *   subtle:    rgb(80,80,80)    — dim gray
 *   bashBorder:rgb(253,93,177)  — pink
 *   diffAdded: rgb(34,92,43)    — deep green bg
 *   diffRemoved:rgb(122,41,54)  — deep red bg
 *   diffAddedWord: rgb(56,166,96) — bright green word highlight
 *   diffRemovedWord:rgb(179,89,107)— bright red word highlight
 */
let _chalk;
const c = () => (_chalk ??= (require('chalk').default || require('chalk')));
const { displayWidth, padToWidth } = require('./formatters');
let _interactiveGuard = null;

// ── Claude Code Theme Colors ───────────────────────────────────────────
const THEME = {
  claude:          '#D77757',  // rgb(215,119,87)
  success:         '#4EBA65',  // rgb(78,186,101)
  error:           '#FF6B80',  // rgb(255,107,128)
  warning:         '#FFC107',  // rgb(255,193,7)
  text:            '#FFFFFF',
  secondaryText:   '#A9A9A9',
  subtle:          '#505050',  // rgb(80,80,80)
  bashBorder:      '#FD5DB1',  // rgb(253,93,177)
  permission:      '#FFC107',
  link:            '#6495ED',  // rgb(100,149,237)
  diffAdded:       '#225C2B',  // rgb(34,92,43)
  diffRemoved:     '#7A2936',  // rgb(122,41,54)
  diffAddedDimmed:  '#475E4A', // rgb(71,88,74)
  diffRemovedDimmed:'#69484D', // rgb(105,72,77)
  diffAddedWord:   '#38A660',  // rgb(56,166,96)
  diffRemovedWord: '#B3596B',  // rgb(179,89,107)
};

function setInteractiveGuard(fn) {
  _interactiveGuard = typeof fn === 'function' ? fn : null;
}

function isInteractiveInputActive() {
  try {
    return !!(_interactiveGuard && _interactiveGuard());
  } catch {
    return false;
  }
}

// ── Dynamic Spinner (Claude Code SpinnerGlyph exact match) ────────────
// Spinner sequence adapted for Khy-OS parity:
// keep the first frame as a solid dot, then cycle sparkle glyphs.
// Animation bounces forward then reverse for smooth cycling.
function _getSpinnerCharacters() {
  if (process.platform === 'darwin') {
    return ['●', '✢', '✳', '✶', '✻', '✽'];
  }
  // Non-macOS fallback: simpler characters that render in most terminals
  return ['●', '*', '+', '×', '+', '*'];
}
const _SPINNER_CHARS = _getSpinnerCharacters();
// Bounce: forward + reverse (excluding endpoints to avoid double-pause)
const SPINNER_FRAMES = [..._SPINNER_CHARS, ..._SPINNER_CHARS.slice(1, -1).reverse()];
const SPINNER_ACTIVE_CHAR = _SPINNER_CHARS[0];
const REDUCED_MOTION_DOT = SPINNER_ACTIVE_CHAR;

// Claude Code rotates through creative verbs for the thinking phase
const THINKING_VERBS = [
  'Thinking', 'Reasoning', 'Inferring', 'Analyzing', 'Considering',
  'Evaluating', 'Reflecting', 'Pondering', 'Processing', 'Pollinating',
];

const PHASE_LABELS = {
  init:      'Initializing',
  security:  'Security check',
  preprocess:'Preprocessing',
  request:   'Thinking',
  thinking:  'Thinking',
  analyzing: 'Analyzing',
  generating:'Generating',
  tools:     'Running tools',
  explore:   'Searching',
  reading:   'Reading',
  writing:   'Writing',
  tool:      'Running tool',
  done:      'Done',
};

/**
 * Format elapsed seconds into human-readable "Xm Ys" or "Xs".
 */
function _formatElapsed(totalSec) {
  const sec = Math.floor(totalSec);
  if (sec < 60) return `${sec}s`;
  const min = Math.floor(sec / 60);
  const rem = sec % 60;
  return rem > 0 ? `${min}m ${rem}s` : `${min}m`;
}

// Map tool names to Claude Code's userFacingName
const TOOL_DISPLAY_NAMES = {
  bash:          'Bash',
  shell:         'Bash',
  shellcommand:  'Bash',
  command:       'Bash',
  read:          'Read',
  readfile:      'Read',
  write:         'Write',
  writefile:     'Write',
  createfile:    'Write',
  edit:          'Update',
  editfile:      'Update',
  multiedit:     'Update',
  notebookedit:  'Update',
  glob:          'Search',
  grep:          'Search',
  find:          'Search',
  findfiles:     'Search',
  search:        'Search',
  searchcontent: 'Search',
  websearch:     'Search',
  webfetch:      'Fetch',
  todowrite:     'Todo',
  notebookread:  'Read',
  agent:         'Agent',
  task:          'Task',
  ls:            'Search',
};

const TOOL_KIND_ALIASES = {
  read: 'reading',
  readfile: 'reading',
  ls: 'explore',
  glob: 'explore',
  grep: 'explore',
  find: 'explore',
  findfiles: 'explore',
  search: 'explore',
  searchcontent: 'explore',
  websearch: 'explore',
  webfetch: 'explore',
  todowrite: 'tools',
  notebookread: 'reading',
  task: 'explore',
  bash: 'explore',
  shell: 'explore',
  shellcommand: 'explore',
  command: 'explore',
  write: 'writing',
  writefile: 'writing',
  createfile: 'writing',
  edit: 'writing',
  editfile: 'writing',
  multiedit: 'writing',
  notebookedit: 'writing',
};

class DynamicSpinner {
  constructor() {
    this._frame = 0;
    this._timer = null;
    this._phase = 'init';
    this._detail = '';
    this._startTime = Date.now();
    this._phaseStartTime = Date.now();
    this._inputTokens = 0;   // ↑ tokens sent
    this._outputTokens = 0;  // ↓ tokens received
    this._effort = '';        // 'low' | 'medium' | 'high' | ''
    this._blinkState = true;
    this._verbIndex = 0;
    this._verbRotateAt = 0;  // frame count when we last rotated verb
    this._tipShown = false;
    this._promptShown = false;
    this._promptLines = 0;
    this._promptMode = 'plain'; // 'plain' | 'framed'
    this._promptRuleColor = THEME.claude;
    this._promptFooter = '';
    // Keep cursor on the interjection input line while spinner updates above.
    this._spinnerOffsetFromPrompt = 0;
    this._promptCursorAnchored = false;
  }

  start(phase = 'init') {
    if (this._timer) this.stop();
    this._phase = phase;
    this._phaseStartTime = Date.now();
    if (!this._startTime || phase === 'request') this._startTime = Date.now();
    this._timer = setInterval(() => this._render(), 120); // ~8fps matching Claude Code
  }

  setPhase(phase, detail = '') {
    this._phase = phase;
    this._detail = detail;
    this._phaseStartTime = Date.now();
  }

  /**
   * Reset the elapsed timer to now. Call this when the first SSE event
   * arrives so the displayed time reflects actual processing, not TTFB.
   */
  resetTimer() {
    this._startTime = Date.now();
  }

  setTokens(count, direction = 'output') {
    if (direction === 'input') {
      this._inputTokens = count;
    } else {
      this._outputTokens = count;
    }
  }

  setEffort(level) {
    this._effort = level || '';
  }

  /**
   * Configure how interjection prompt is rendered while spinner is active.
   * @param {'plain'|'framed'} mode
   * @param {{ruleColor?: string, footer?: string}} [opts]
   */
  setPromptMode(mode = 'plain', opts = {}) {
    this._promptMode = (mode === 'framed') ? 'framed' : 'plain';
    this._promptRuleColor = String(opts.ruleColor || THEME.claude);
    this._promptFooter = String(opts.footer || '');
  }

  _getThinkingVerb() {
    // Rotate through creative verbs every ~8 seconds (67 frames at 120ms)
    if (this._frame - this._verbRotateAt >= 67) {
      this._verbIndex = (this._verbIndex + 1) % THINKING_VERBS.length;
      this._verbRotateAt = this._frame;
    }
    return THINKING_VERBS[this._verbIndex];
  }

  _render() {
    if (!process.stdout.isTTY) return;
    if (isInteractiveInputActive()) return;
    if (process.stdin.isRaw) return;

    this._blinkState = !this._blinkState;
    this._frame++;

    const elapsedSec = (Date.now() - this._startTime) / 1000;
    const elapsedStr = _formatElapsed(elapsedSec);

    // Determine label — rotate verbs for thinking/request phases
    let label;
    if (this._phase === 'thinking' || this._phase === 'request') {
      label = this._getThinkingVerb();
    } else {
      label = PHASE_LABELS[this._phase] || this._phase;
    }

    const detail = this._detail ? ` ${this._detail}` : '';

    // Build status parts: (Xm Ys · ↑ 10.3k tokens · thinking with high effort)
    const fmtTokens = (n) => {
      if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
      return String(n);
    };
    const parts = [elapsedStr];
    if (this._inputTokens > 0) {
      parts.push(`↑ ${fmtTokens(this._inputTokens)} tokens`);
    }
    if (this._outputTokens > 0) {
      parts.push(`↓ ${fmtTokens(this._outputTokens)} tokens`);
    }
    if (this._effort && (this._effort === 'max' || this._effort === 'high')) {
      parts.push(`extended thinking · ${this._effort}`);
    } else if (this._effort) {
      parts.push(this._effort);
    }
    const statusStr = parts.join(' · ');

    // Active polling indicator: solid dot (Claude-style, no sparkle in main line)
    const spinnerChar = SPINNER_ACTIVE_CHAR;

    // Stalled detection: if no output after 3s in a phase, shift color toward red
    const phaseElapsed = (Date.now() - this._phaseStartTime) / 1000;
    let charColor;
    if (phaseElapsed > 8) {
      // Deep stall: interpolate toward error red
      const t = Math.min(1, (phaseElapsed - 8) / 12); // 0→1 over 12s
      const r = Math.round(215 + (171 - 215) * t);
      const g = Math.round(119 + (43 - 119) * t);
      const b = Math.round(87 + (63 - 87) * t);
      charColor = `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;
    } else {
      charColor = THEME.text;
    }

    const dot = c().hex(charColor)(spinnerChar);
    const line = `${dot} ${c().hex(THEME.text)(label + '...')}${c().dim(detail)} ${c().dim(`(${statusStr})`)}`;

    if (!this._promptShown) {
      // First render: draw spinner + prompt scaffold.
      process.stdout.write(`\r\x1b[K${line}`);
      this._promptShown = true;
      if (this._promptMode === 'framed') {
        const width = process.stdout.columns || 80;
        const rule = c().hex(this._promptRuleColor)('─'.repeat(width));
        const footer = this._promptFooter ? `\n${this._promptFooter}` : '';
        process.stdout.write(`\n${rule}\n> \n${rule}${footer}`);
        this._promptLines = this._promptFooter ? 4 : 3;
        // Cursor should stay on prompt line, spinner line is 2 rows above.
        this._spinnerOffsetFromPrompt = 2;
        this._promptCursorAnchored = true;
        // Footer mode: move up 2 lines (footer -> bottom rule -> prompt).
        // No footer: move up 1 line (bottom rule -> prompt).
        process.stdout.write(`\x1b[${this._promptFooter ? 2 : 1}A`);
        process.stdout.write('\r');
        try { require('readline').cursorTo(process.stdout, 2); } catch { /* best effort */ }
      } else {
        process.stdout.write('\n> ');
        this._promptLines = 1;
        // Plain mode keeps cursor on prompt line, spinner line is 1 row above.
        this._spinnerOffsetFromPrompt = 1;
        this._promptCursorAnchored = true;
      }
    } else if (this._promptCursorAnchored && this._spinnerOffsetFromPrompt > 0) {
      // Keep user cursor on input line while updating spinner line above.
      process.stdout.write('\x1b[s');
      process.stdout.write(`\x1b[${this._spinnerOffsetFromPrompt}A`);
      process.stdout.write(`\r\x1b[K${line}`);
      process.stdout.write('\x1b[u');
    } else {
      process.stdout.write(`\r\x1b[K${line}`);
    }

    // Show tip after 5 seconds, once per spinner lifetime
    if (!this._tipShown && elapsedSec >= 5) {
      this._tipShown = true;
    }
  }

  stop() {
    if (this._timer) {
      clearInterval(this._timer);
      this._timer = null;
    }
    if (!isInteractiveInputActive()) {
      if (this._promptShown && this._promptCursorAnchored && this._spinnerOffsetFromPrompt > 0) {
        // Cursor is on prompt line: jump to spinner line, clear scaffold, return to spinner line.
        process.stdout.write(`\x1b[${this._spinnerOffsetFromPrompt}A`);
        process.stdout.write('\r\x1b[K');
        for (let i = 0; i < this._promptLines; i++) {
          process.stdout.write('\x1b[1B\r\x1b[K');
        }
        if (this._promptLines > 0) {
          process.stdout.write(`\x1b[${this._promptLines}A`);
        }
      } else {
        // Cursor already at spinner line (legacy behavior).
        process.stdout.write('\r\x1b[K');
        if (this._promptShown) {
          for (let i = 0; i < this._promptLines; i++) {
            process.stdout.write('\x1b[1B\r\x1b[K');
          }
          if (this._promptLines > 0) {
            process.stdout.write(`\x1b[${this._promptLines}A`);
          }
        }
      }
      this._promptLines = 0;
      this._promptShown = false;
      this._spinnerOffsetFromPrompt = 0;
      this._promptCursorAnchored = false;
    }
  }
}

function normalizeToolKind(name = '') {
  const raw = String(name).toLowerCase().replace(/[\s_-]/g, '');
  return TOOL_KIND_ALIASES[raw] || 'tools';
}

/**
 * Map internal tool name to Claude Code's userFacingName.
 * e.g. "shell_command" → "Bash", "read_file" → "Read", "glob" → "Search"
 */
function getToolDisplayName(name = '') {
  const raw = String(name).toLowerCase().replace(/[\s_-]/g, '');
  return TOOL_DISPLAY_NAMES[raw] || name;
}

/**
 * Render a user message with gray background (Claude Code style).
 * Claude Code uses rgb(38,38,38) background for user messages.
 * @param {string} text - user message text
 */
function renderUserMessage(text) {
  // Claude Code: userMsgBg = rgb(38,38,38) — subtle dark background
  const bgColor = '#262626';
  const lines = text.split('\n');
  const maxLen = Math.max(...lines.map(l => l.length));
  console.log('');
  for (const line of lines) {
    const padded = line.padEnd(maxLen + 2);
    console.log(c().bgHex(bgColor).hex('#FFFFFF')(` ${padded}`));
  }
  console.log('');
}

function summarizeToolDetail(name = '', params = '') {
  const kind = normalizeToolKind(name);
  const text = String(params || '').trim().replace(/\s+/g, ' ');
  const short = text.length > 60 ? `${text.slice(0, 60)}...` : text;
  return { kind, short };
}

function getToolKindLabel(name = '') {
  const kind = normalizeToolKind(name);
  return PHASE_LABELS[kind] || '工具';
}

// ── Diff Renderer (Claude Code exact colors) ───────────────────────────

const DIFF_CONTEXT_LINES = 3;

/**
 * Render a unified diff with Claude Code's exact background colors.
 * Added lines: rgb(34,92,43) background
 * Removed lines: rgb(122,41,54) background
 * @@ headers: dim
 * Context lines: dim
 */
function renderDiff(diffText) {
  const lines = diffText.split('\n');
  const rendered = [];

  for (const line of lines) {
    if (line.startsWith('+++') || line.startsWith('---')) {
      rendered.push(c().bold.dim(line));
    } else if (line.startsWith('+')) {
      rendered.push(c().bgHex(THEME.diffAdded).hex('#FFFFFF')(line));
    } else if (line.startsWith('-')) {
      rendered.push(c().bgHex(THEME.diffRemoved).hex('#FFFFFF')(line));
    } else if (line.startsWith('@@')) {
      rendered.push(c().dim(line));
    } else {
      rendered.push(c().dim(line));
    }
  }

  return rendered.join('\n');
}

/**
 * Render a structured diff for file edits (Claude Code style).
 * Shows line numbers + add/remove markers with exact background colors.
 *
 * @param {string} oldContent - original file content
 * @param {string} newContent - modified file content
 * @param {string} [filePath] - file path for header
 * @returns {string} rendered diff
 */
function renderStructuredDiff(oldContent, newContent, filePath = '') {
  const oldLines = oldContent.split('\n');
  const newLines = newContent.split('\n');

  // Simple line-by-line diff (find common prefix/suffix, mark changes)
  const rendered = [];
  let i = 0, j = 0;
  const commonPrefixLen = (() => {
    let k = 0;
    while (k < oldLines.length && k < newLines.length && oldLines[k] === newLines[k]) k++;
    return k;
  })();
  const commonSuffixLen = (() => {
    let k = 0;
    while (k < (oldLines.length - commonPrefixLen) && k < (newLines.length - commonPrefixLen)
           && oldLines[oldLines.length - 1 - k] === newLines[newLines.length - 1 - k]) k++;
    return k;
  })();

  const removeStart = commonPrefixLen;
  const removeEnd = oldLines.length - commonSuffixLen;
  const addStart = commonPrefixLen;
  const addEnd = newLines.length - commonSuffixLen;

  // Context before
  const ctxStart = Math.max(0, removeStart - DIFF_CONTEXT_LINES);
  for (let k = ctxStart; k < removeStart; k++) {
    const num = String(k + 1).padStart(4);
    rendered.push(`  ${c().dim(num)}   ${c().dim(oldLines[k])}`);
  }

  // Removed lines
  for (let k = removeStart; k < removeEnd; k++) {
    const num = String(k + 1).padStart(4);
    rendered.push(c().bgHex(THEME.diffRemoved).hex('#FFFFFF')(`  ${num} - ${oldLines[k]}`));
  }

  // Added lines
  for (let k = addStart; k < addEnd; k++) {
    const num = String(k + 1).padStart(4);
    rendered.push(c().bgHex(THEME.diffAdded).hex('#FFFFFF')(`  ${num} + ${newLines[k]}`));
  }

  // Context after
  const ctxEnd = Math.min(oldLines.length, removeEnd + DIFF_CONTEXT_LINES);
  for (let k = removeEnd; k < ctxEnd; k++) {
    if (k < oldLines.length) {
      const num = String(k + 1).padStart(4);
      rendered.push(`  ${c().dim(num)}   ${c().dim(oldLines[k])}`);
    }
  }

  // Stats
  const added = addEnd - addStart;
  const removed = removeEnd - removeStart;
  const statParts = [];
  if (added > 0) statParts.push(`Added ${added} line${added !== 1 ? 's' : ''}`);
  if (removed > 0) statParts.push(`removed ${removed} line${removed !== 1 ? 's' : ''}`);
  if (statParts.length > 0) {
    rendered.push(`    ${c().dim('└')} ${c().dim(statParts.join(', '))}`);
  }

  return rendered.join('\n');
}

/**
 * Detect and render inline diffs within AI response text.
 * Looks for fenced diff blocks: ```diff ... ```
 */
function renderResponseWithDiffs(text) {
  const parts = text.split(/(```diff\n[\s\S]*?```)/g);
  const rendered = [];

  for (const part of parts) {
    if (part.startsWith('```diff\n') && part.endsWith('```')) {
      const diffContent = part.slice(8, -3);
      rendered.push(renderDiff(diffContent));
    } else {
      rendered.push(part);
    }
  }

  return rendered.join('\n');
}

// ── Inline Code Highlighting ────────────────────────────────────────────

/**
 * Light markdown rendering for AI responses.
 * Handles: headers, inline code, code blocks, bold.
 */
function renderMarkdownLite(text) {
  // Pre-pass: render tables before other transforms
  text = _renderMarkdownTables(text);

  return text
    // Code blocks (```...```) — cyan
    .replace(/```(\w*)\n([\s\S]*?)```/g, (_m, lang, code) => {
      const langTag = lang ? c().dim(` ${lang}`) : '';
      const codeLines = code.split('\n').map(l => `  ${c().dim('│')} ${c().white(l)}`).join('\n');
      return `${c().dim('  ┌──')}${langTag}\n${codeLines}\n${c().dim('  └──')}`;
    })
    // Horizontal rules (---, ***, ___)
    .replace(/^(\s*)[-*_]{3,}\s*$/gm, (_m, indent) => {
      const cols = (process.stdout.columns || 80) - 6;
      return `${indent}${c().dim('─'.repeat(Math.max(10, cols)))}`;
    })
    // Headers
    .replace(/^(#{1,3})\s+(.+)$/gm, (_m, hashes, title) => {
      return c().bold.cyan(`  ${title}`);
    })
    // Bold
    .replace(/\*\*(.+?)\*\*/g, (_m, text) => c().bold(text))
    // Italic
    .replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, (_m, text) => c().italic(text))
    // Inline code
    .replace(/`([^`]+)`/g, (_m, code) => c().cyan(code))
    // Links [text](url) — show text underlined, url dimmed
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, (_m, text, url) => {
      return `${c().hex(THEME.link).underline(text)} ${c().dim(`(${url})`)}`;
    })
    // Numbered lists (1. 2. 3.)
    .replace(/^(\s*)\d+\.\s+/gm, (_m, indent) => {
      return `${indent}${c().dim('›')} `;
    })
    // Bullet lists
    .replace(/^(\s*)[-*]\s+/gm, '$1• ')
    // Blockquotes (> text)
    .replace(/^>\s*(.*)/gm, (_m, text) => {
      return `  ${c().dim('│')} ${c().dim(text)}`;
    });
}

/**
 * Render Markdown tables with aligned columns using Unicode box drawing.
 * Detects table blocks (lines starting with |) and replaces them with
 * aligned, box-drawn tables.
 */
function _renderMarkdownTables(text) {
  const lines = text.split('\n');
  const out = [];
  let i = 0;

  while (i < lines.length) {
    // Detect table start: line must have at least 2 pipe characters
    if (/^\s*\|.*\|/.test(lines[i])) {
      const tableLines = [];
      const tableStart = i;
      while (i < lines.length && /^\s*\|.*\|/.test(lines[i])) {
        tableLines.push(lines[i]);
        i++;
      }
      // Need at least 2 rows (header + separator or header + data)
      if (tableLines.length >= 2) {
        const rendered = _formatTable(tableLines);
        out.push(rendered);
      } else {
        // Too short to be a table, pass through
        for (const tl of tableLines) out.push(tl);
      }
    } else {
      out.push(lines[i]);
      i++;
    }
  }

  return out.join('\n');
}

/**
 * Format a set of markdown table lines into an aligned box-drawn table.
 */
function _formatTable(tableLines) {
  // Parse cells from each row
  const rows = [];
  let separatorIdx = -1;

  for (let i = 0; i < tableLines.length; i++) {
    const line = tableLines[i].trim();
    // Check if this is a separator row (e.g. |---|---|)
    if (/^\|[\s:]*[-]+[\s:]*(\|[\s:]*[-]+[\s:]*)*\|$/.test(line)) {
      separatorIdx = i;
      continue;
    }
    // Split by | and trim, dropping empty first/last from leading/trailing |
    const cells = line.split('|')
      .map(cell => cell.trim())
      .filter((_, idx, arr) => idx > 0 && idx < arr.length - 1);
    rows.push(cells);
  }

  if (rows.length === 0) return tableLines.join('\n');

  // Determine column count and widths
  const colCount = Math.max(...rows.map(r => r.length));
  const colWidths = Array(colCount).fill(0);

  for (const row of rows) {
    for (let col = 0; col < colCount; col++) {
      const cell = row[col] || '';
      colWidths[col] = Math.max(colWidths[col], displayWidth(cell));
    }
  }

  // Enforce minimum column width
  for (let col = 0; col < colCount; col++) {
    colWidths[col] = Math.max(colWidths[col], 3);
  }

  // Build output
  const result = [];
  const dim = c().dim.bind(c());

  // Top border
  const topBorder = dim('  ┌' + colWidths.map(w => '─'.repeat(w + 2)).join('┬') + '┐');
  result.push(topBorder);

  for (let r = 0; r < rows.length; r++) {
    const row = rows[r];
    const cells = [];
    for (let col = 0; col < colCount; col++) {
      const cell = row[col] || '';
      cells.push(' ' + padToWidth(cell, colWidths[col]) + ' ');
    }
    const rowStr = dim('  │') + cells.join(dim('│')) + dim('│');
    result.push(rowStr);

    // After header row (first row), add separator
    if (r === 0 && rows.length > 1) {
      const sep = dim('  ├' + colWidths.map(w => '─'.repeat(w + 2)).join('┼') + '┤');
      result.push(sep);
    }
  }

  // Bottom border
  const bottomBorder = dim('  └' + colWidths.map(w => '─'.repeat(w + 2)).join('┴') + '┘');
  result.push(bottomBorder);

  return result.join('\n');
}

// ── Interactive Prompt ──────────────────────────────────────────────────

/**
 * Present numbered options to the user and wait for selection.
 * Returns the selected option(s) or null if cancelled.
 *
 * @param {string} question - The question to ask
 * @param {Array<{label: string, description?: string}>} options
 * @param {object} [opts]
 * @param {boolean} [opts.multiSelect=false]
 * @param {readline.Interface} [opts.rl] - existing readline to reuse
 * @returns {Promise<string|string[]|null>}
 */
async function askInlineQuestion(question, options, opts = {}) {
  const readline = require('readline');
  const stdin = process.stdin;
  const stdout = process.stdout;
  const canUseArrowMenu = !opts.multiSelect
    && Boolean(stdin && stdout && stdin.isTTY && stdout.isTTY && typeof stdin.setRawMode === 'function');

  // Claude Code style: arrow-key navigable menu for single-select
  if (canUseArrowMenu) {
    // Build choices compatible with promptChoiceMenu style
    const choices = options.map((opt, i) => ({
      label: opt.label + (opt.description ? c().dim(` — ${opt.description}`) : ''),
      value: opt.label,
      aliases: [String(i + 1)],
    }));
    // Add "Other" choice
    choices.push({
      label: c().dim('Other (free input)'),
      value: '__other__',
      aliases: [String(options.length + 1), 'o', 'other'],
    });

    const PURPLE = '#B388FF';
    return new Promise((resolve) => {
      let selected = 0;
      let typed = '';
      let renderedLines = 0;
      const wasRawMode = Boolean(stdin.isRaw);

      // Pause the REPL's readline if provided
      const rl = opts.rl;
      if (rl && typeof rl.pause === 'function') {
        try { rl.pause(); } catch { /* ignore */ }
      }

      const cleanup = (resultValue) => {
        stdin.off('data', onData);
        if (typeof stdin.setRawMode === 'function') {
          try { stdin.setRawMode(wasRawMode); } catch { /* ignore */ }
        }
        if (renderedLines > 0) {
          try { readline.moveCursor(stdout, 0, -renderedLines); } catch { /* ignore */ }
          try { readline.cursorTo(stdout, 0); } catch { /* ignore */ }
          try { readline.clearScreenDown(stdout); } catch { /* ignore */ }
        }
        const resumeMainRl = () => {
          if (rl && typeof rl.resume === 'function') {
            try { rl.resume(); } catch { /* ignore */ }
          }
        };
        // Handle "Other" — prompt for free text
        if (resultValue === '__other__') {
          // Keep main REPL paused while collecting free input.
          // Resuming it too early causes duplicate key handling.
          const rl2 = readline.createInterface({ input: stdin, output: stdout });
          rl2.question(c().dim('  Enter custom text: '), (text) => {
            rl2.close();
            try { stdin.resume(); } catch { /* ignore */ }
            resumeMainRl();
            resolve(text.trim() || null);
          });
          return;
        }
        resumeMainRl();
        resolve(resultValue);
      };

      const render = () => {
        if (renderedLines > 0) {
          try { readline.moveCursor(stdout, 0, -renderedLines); } catch { /* ignore */ }
          try { readline.cursorTo(stdout, 0); } catch { /* ignore */ }
          try { readline.clearScreenDown(stdout); } catch { /* ignore */ }
        }
        const lines = [];
        lines.push(`  ${c().hex(THEME.warning).bold(`? ${question}`)}`);
        for (let i = 0; i < choices.length; i++) {
          const marker = i === selected ? c().hex(PURPLE)('\u276F') : ' ';
          const num = `${i + 1}.`;
          const label = i === selected ? c().bold(choices[i].label) : choices[i].label;
          lines.push(`   ${marker} ${num} ${label}`);
        }
        lines.push('');
        lines.push(`  ${c().dim('Use arrow keys to navigate, Enter to select, Esc to skip')}`);
        stdout.write(`${lines.join('\n')}\n`);
        renderedLines = lines.length;
      };

      const onData = (chunk) => {
        const key = Buffer.isBuffer(chunk) ? chunk.toString('utf8') : String(chunk);
        // Esc or Ctrl+C → cancel
        if (key === '\u0003' || key === '\u001b') { cleanup(null); return; }
        // Arrow up
        if (key === '\u001b[A') { selected = (selected - 1 + choices.length) % choices.length; render(); return; }
        // Arrow down
        if (key === '\u001b[B') { selected = (selected + 1) % choices.length; render(); return; }
        // Tab
        if (key === '\t') { selected = (selected + 1) % choices.length; render(); return; }
        // Enter
        if (key === '\r' || key === '\n') { cleanup(choices[selected].value); return; }
        // Number keys for quick select
        if (key.length === 1 && key >= '1' && key <= '9') {
          const idx = parseInt(key, 10) - 1;
          if (idx >= 0 && idx < choices.length) { cleanup(choices[idx].value); return; }
        }
        // '0' → skip
        if (key === '0') { cleanup(null); return; }
      };

      try { stdin.resume(); } catch { /* ignore */ }
      try { stdin.setRawMode(true); } catch { /* ignore */ }
      stdin.on('data', onData);
      render();
    });
  }

  // Fallback for multiSelect or non-TTY: numbered list
  console.log('');
  console.log(c().hex(THEME.warning)(`  ? ${question}`));
  console.log('');

  options.forEach((opt, i) => {
    const num = c().cyan(`  [${i + 1}]`);
    const label = c().white(opt.label);
    const desc = opt.description ? c().dim(` — ${opt.description}`) : '';
    console.log(`${num} ${label}${desc}`);
  });
  console.log(c().dim(`  [${options.length + 1}] Other (free input)`));
  console.log(c().dim(`  [0] Skip`));
  console.log('');

  const rl = opts.rl || readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise((resolve) => {
    const prompt = opts.multiSelect
      ? c().dim('  Select (comma-separated, e.g. 1,3): ')
      : c().dim('  Select: ');

    rl.question(prompt, (answer) => {
      if (!opts.rl) rl.close();

      const trimmed = answer.trim();
      if (!trimmed || trimmed === '0') {
        resolve(null);
        return;
      }

      const lastIdx = options.length + 1;
      if (trimmed === String(lastIdx)) {
        const rl2 = readline.createInterface({ input: process.stdin, output: process.stdout });
        rl2.question(c().dim('  Enter: '), (text) => {
          rl2.close();
          resolve(text.trim() || null);
        });
        return;
      }

      if (opts.multiSelect) {
        const indices = trimmed.split(/[,，\s]+/).map(s => parseInt(s, 10) - 1);
        const selected = indices
          .filter(i => i >= 0 && i < options.length)
          .map(i => options[i].label);
        resolve(selected.length > 0 ? selected : null);
      } else {
        const idx = parseInt(trimmed, 10) - 1;
        if (idx >= 0 && idx < options.length) {
          resolve(options[idx].label);
        } else {
          resolve(trimmed);
        }
      }
    });
  });
}

// ── AI Response Renderer ────────────────────────────────────────────────

/**
 * Wrap a line at terminal width, preserving ANSI escape codes.
 * Skips lines inside code blocks (prefixed with │).
 * @param {string} line
 * @param {number} maxWidth
 * @returns {string}
 */
function wrapLine(line, maxWidth) {
  if (maxWidth <= 0) return line;
  // Strip ANSI for length measurement
  const stripped = line.replace(/\x1b\[[0-9;]*m/g, '');
  if (stripped.length <= maxWidth) return line;

  // Don't wrap code block lines (contain │ indicator)
  if (stripped.includes('│')) return line;

  // Simple word-boundary wrapping on the visible text
  const words = stripped.split(/(\s+)/);
  const lines = [];
  let current = '';
  let currentLen = 0;
  const indent = '    '; // continuation indent

  for (const word of words) {
    if (currentLen + word.length > maxWidth && current.length > 0) {
      lines.push(current);
      current = indent + word.trimStart();
      currentLen = indent.length + word.trimStart().length;
    } else {
      current += word;
      currentLen += word.length;
    }
  }
  if (current) lines.push(current);

  return lines.join('\n');
}

/**
 * Render a complete AI response with all formatting.
 * @param {string} text - raw AI response text
 * @param {object} [opts]
 * @param {object} [opts.chalk] - chalk instance
 * @returns {string} rendered text for console output
 */
function renderAiResponse(text) {
  if (!text) return '';

  // First handle diff blocks
  let rendered = renderResponseWithDiffs(text);

  // Then apply markdown-lite
  rendered = renderMarkdownLite(rendered);

  // Word-wrap long lines to terminal width
  const cols = (process.stdout.columns || 80) - 6; // leave margin for │ prefix
  if (cols > 20) {
    rendered = rendered.split('\n').map(l => wrapLine(l, cols)).join('\n');
  }

  return rendered;
}

// ── Process Step Indicators (Claude Code style) ────────────────────────

// Match Claude Code's exact indicator symbols
// Claude Code uses ● (BLACK_CIRCLE) for all statuses, colored by state
const _isMac = process.platform === 'darwin';
const DOT_PENDING  = '○';                     // not started
const DOT_INDICATOR = '●';                    // in-progress (colored by context)
const DOT_SUCCESS  = '●';                     // completed (green)
const DOT_ERROR    = '●';                     // failed (red)
const DOT_DONE     = '●';                     // finished (dimmed)
const TREE_LAST    = '⎿';                     // Claude Code uses ⎿ for tree branches
const TREE_MID     = '├';

let _sparkleTimers = new Set();

/**
 * Start an animated spinner for tool call in-progress display.
 * Uses a blinking solid dot to match Claude Code active step indicator.
 *
 * @param {string} label - tool display name (e.g. "Bash", "Read")
 * @param {string} target - parameter string
 * @param {string} detail - extra detail
 * @returns {{ stop: Function }}
 */
function startSparkle(label, target = '', detail = '') {
  if (!process.stdout.isTTY) return { stop() {} };

  let frame = 0;
  const startTime = Date.now();
  const timer = setInterval(() => {
    if (isInteractiveInputActive()) return;
    if (process.stdin.isRaw) return;
    frame++;
    const blinkDim = frame % 2 === 0;
    // Stall detection: shift color toward red after 8s
    const elapsed = (Date.now() - startTime) / 1000;
    let charColor;
    if (elapsed > 8) {
      const t = Math.min(1, (elapsed - 8) / 12);
      const r = Math.round(169 + (255 - 169) * t);
      const g = Math.round(169 + (107 - 169) * t);
      const b = Math.round(169 + (128 - 169) * t);
      charColor = `#${r.toString(16).padStart(2,'0')}${g.toString(16).padStart(2,'0')}${b.toString(16).padStart(2,'0')}`;
    } else {
      charColor = THEME.text;
    }
    const icon = blinkDim
      ? c().hex(charColor).dim(DOT_INDICATOR)
      : c().hex(charColor)(DOT_INDICATOR);
    const targetStr = target ? c().dim(`(${target})`) : '';
    const detailStr = detail ? c().dim(` ${detail}`) : '';
    const line = `  ${icon} ${c().bold(label)} ${targetStr}${detailStr}`;
    process.stdout.write(`\r\x1b[K${line}`);
  }, 120); // 120ms = ~8fps matching Claude Code

  _sparkleTimers.add(timer);

  return {
    stop() {
      clearInterval(timer);
      _sparkleTimers.delete(timer);
      if (!isInteractiveInputActive()) {
        process.stdout.write('\r\x1b[K');
      }
    },
  };
}

/**
 * Print a single process step line (Claude Code style).
 * @param {'pending'|'active'|'success'|'error'|'done'} status
 * @param {string} label - e.g. "Read", "Bash", "Write", "Search", "Update"
 * @param {string} [target] - e.g. "src/cli/repl.js", "node -c ..."
 * @param {string} [detail] - e.g. "(ctrl+o to expand)", "→ OK"
 */
function printStepLine(status, label, target = '', detail = '') {
  let dot;
  switch (status) {
    case 'active':  dot = c().hex(THEME.text)(DOT_INDICATOR); break;
    case 'success': dot = c().hex(THEME.success)(DOT_SUCCESS); break;
    case 'error':   dot = c().hex(THEME.error)(DOT_ERROR); break;
    case 'done':    dot = c().dim(DOT_DONE); break;
    default:        dot = c().dim(DOT_PENDING); break;
  }

  const targetStr = target ? c().dim(`(${target})`) : '';
  const detailStr = detail ? c().dim(` ${detail}`) : '';
  const labelColor = status === 'success' ? c().hex(THEME.success)(label)
                   : status === 'error'   ? c().hex(THEME.error)(label)
                   : status === 'active'  ? c().hex(THEME.text).bold(label)
                   : c().dim(label);

  console.log(`  ${dot} ${labelColor} ${targetStr}${detailStr}`);
}

/**
 * Print an indented detail line with tree branch character.
 * @param {string} text - detail text
 * @param {boolean} [isLast=true] - whether this is the last detail line
 */
function printStepDetail(text, isLast = true) {
  // Claude Code style: ⎿ prefix for result detail lines
  const branch = isLast ? TREE_LAST : TREE_MID;
  console.log(`  ${c().dim(branch)}  ${c().dim(text)}`);
}

/**
 * ProcessTracker — manages a sequence of process steps with live updates.
 *
 * Usage:
 *   const tracker = new ProcessTracker();
 *   tracker.start('Reading', 'src/cli/repl.js', '1 file...');
 *   // ... do work ...
 *   tracker.complete('Read 245 lines');
 *   tracker.start('Write', 'src/cli/ai.js');
 *   // ... do work ...
 *   tracker.complete('Added 3 lines');
 */
class ProcessTracker {
  constructor() {
    this._current = null;
    this._startTime = null;
    this._sparkle = null;
  }

  /**
   * Start a new step. Completes any previous in-progress step first.
   * @param {string} label - e.g. "Reading", "Write", "Bash", "AI 思考"
   * @param {string} [target] - e.g. file path, command, etc.
   * @param {string} [hint] - e.g. "1 file...", "ctrl+o to expand"
   */
  start(label, target = '', hint = '') {
    // Auto-complete previous step if still active
    if (this._current) {
      this._finishCurrent('done');
    }
    this._current = { label, target, hint };
    this._startTime = Date.now();

    // Print the initial static line, then overlay sparkle animation
    printStepLine('active', label, target, hint);
    this._sparkle = startSparkle(label, target, hint);

    // Sync to HUD
    try { require('./hudRenderer').toolStart(label, target); } catch {}
  }

  /**
   * Complete the current step — shows gray ✳ (finished, no longer active).
   * @param {string} [detail] - completion detail shown on tree line
   */
  complete(detail = '') {
    this._finishCurrent('done', detail);
  }

  /**
   * Mark the current step as failed.
   * @param {string} [detail] - error detail shown on tree line
   */
  fail(detail = '') {
    this._finishCurrent('error', detail);
  }

  /**
   * Internal: overwrite current active line with final status + detail.
   */
  _finishCurrent(status, detail = '') {
    if (!this._current) return;

    // Stop sparkle animation
    if (this._sparkle) {
      this._sparkle.stop();
      this._sparkle = null;
    }

    const elapsed = Date.now() - this._startTime;
    const elapsedStr = elapsed > 1000 ? ` (${(elapsed / 1000).toFixed(1)}s)` : '';

    // Sync to HUD
    try { require('./hudRenderer').toolEnd(this._current.label, status, elapsed); } catch {}

    if (process.stdout.isTTY && !isInteractiveInputActive()) {
      // Move cursor up to overwrite the active line
      process.stdout.write('\x1b[1A\r\x1b[K'); // up 1 line, clear
      const { label, target } = this._current;
      printStepLine(status, label, target, elapsedStr);
    } else if (process.stdout.isTTY) {
      // Keep output stable while user is typing a busy-time interjection.
      const { label, target } = this._current;
      printStepLine(status, label, target, elapsedStr);
    }
    // On non-TTY, skip rewrite — the active line stays as-is (no double output)

    if (detail) {
      printStepDetail(detail);
    }

    this._current = null;
    this._startTime = null;
  }

  /**
   * Whether a step is currently in progress.
   */
  get isActive() {
    return this._current !== null;
  }
}

// ── Task Plan Tracker (Claude Code style task list) ────────────────────

const TASK_PENDING     = '☐';
const TASK_IN_PROGRESS = '■';
const TASK_COMPLETED   = '✔';

/**
 * TaskPlanTracker — displays and updates a task checklist.
 *
 * Usage:
 *   const plan = new TaskPlanTracker();
 *   plan.addTask('Fetch market data');
 *   plan.addTask('Run backtest');
 *   plan.addTask('Generate report');
 *   plan.render();          // show all tasks
 *   plan.start(0);          // mark first as in-progress → re-render
 *   plan.complete(0);       // mark as done → re-render
 */
class TaskPlanTracker {
  constructor() {
    this._tasks = [];
    this._renderedLines = 0; // how many lines the last render() produced
  }

  /**
   * Add a task to the plan.
   * @param {string} description
   * @returns {number} task index
   */
  addTask(description) {
    this._tasks.push({ description, status: 'pending' });
    return this._tasks.length - 1;
  }

  /**
   * Mark a task as in-progress.
   */
  start(index) {
    if (this._tasks[index]) {
      this._tasks[index].status = 'in_progress';
      this._rerender();
    }
  }

  /**
   * Mark a task as completed.
   */
  complete(index) {
    if (this._tasks[index]) {
      this._tasks[index].status = 'completed';
      this._rerender();
    }
  }

  /**
   * Mark a task as failed.
   */
  fail(index) {
    if (this._tasks[index]) {
      this._tasks[index].status = 'error';
      this._rerender();
    }
  }

  /**
   * Get summary line: "4 tasks (2 done, 1 in progress, 1 open)"
   */
  getSummary() {
    const done = this._tasks.filter(t => t.status === 'completed').length;
    const inProgress = this._tasks.filter(t => t.status === 'in_progress').length;
    const open = this._tasks.filter(t => t.status === 'pending').length;
    const errored = this._tasks.filter(t => t.status === 'error').length;

    const parts = [];
    if (done > 0)       parts.push(`${done} done`);
    if (inProgress > 0) parts.push(`${inProgress} in progress`);
    if (open > 0)       parts.push(`${open} open`);
    if (errored > 0)    parts.push(`${errored} failed`);

    return `${this._tasks.length} tasks (${parts.join(', ')})`;
  }

  /**
   * Render the full task list to stdout.
   */
  render() {
    console.log('');
    console.log(c().dim(`  ${this.getSummary()}`));
    for (const task of this._tasks) {
      let icon, color;
      switch (task.status) {
        case 'completed':
          icon = c().green(TASK_COMPLETED);
          color = c().strikethrough.dim;
          break;
        case 'in_progress':
          icon = c().yellow(TASK_IN_PROGRESS);
          color = c().bold.white;
          break;
        case 'error':
          icon = c().red('✗');
          color = c().red;
          break;
        default:
          icon = c().dim(TASK_PENDING);
          color = c().white;
          break;
      }
      console.log(`    ${icon} ${color(task.description)}`);
    }
    this._renderedLines = this._tasks.length + 2; // summary + blank + tasks
  }

  /**
   * Re-render by clearing previous output and printing again.
   */
  _rerender() {
    if (this._renderedLines > 0 && process.stdout.isTTY) {
      // Move up and clear previous render
      for (let i = 0; i < this._renderedLines; i++) {
        process.stdout.write('\x1b[1A\r\x1b[K');
      }
    }
    this.render();
  }

  /**
   * Extract tasks from an AI response containing a numbered plan.
   * Looks for patterns like "1. xxx\n2. xxx\n3. xxx" under a "计划"/"步骤" heading.
   * @param {string} text - AI response text
   * @returns {boolean} true if tasks were extracted
   */
  extractFromResponse(text) {
    // Look for numbered items (Chinese or English)
    const planPattern = /(?:^|\n)\s*(\d+)[.、）)]\s*(.+)/g;
    const matches = [...text.matchAll(planPattern)];

    if (matches.length >= 2) {
      for (const m of matches) {
        this.addTask(m[2].trim().slice(0, 60));
      }
      return true;
    }
    return false;
  }

  get length() { return this._tasks.length; }
  get allDone() { return this._tasks.every(t => t.status === 'completed' || t.status === 'error'); }
}

// ── Context Compaction Notice ──────────────────────────────────────────

/**
 * Print a "Compacting conversation..." notice (Claude Code style).
 * @param {object} opts - { elapsed, tokens, thought }
 */
function printCompactingNotice(opts = {}) {
  const parts = [];
  if (opts.elapsed) parts.push(opts.elapsed);
  if (opts.tokens)  parts.push(`↑ ${opts.tokens} tokens`);
  if (opts.thought) parts.push(`thought for ${opts.thought}`);

  const meta = parts.length > 0 ? c().dim(` (${parts.join(' · ')})`) : '';
  // Claude Code style: ✻ Conversation compacted
  console.log(`  ${c().hex(THEME.warning)('✻')} ${c().hex(THEME.warning).bold('Conversation compacted')}${meta}`);

  if (opts.tip) {
    printStepDetail(`Tip: ${opts.tip}`);
  }
}

// ── Legacy helpers (preserved for backward compatibility) ──────────────

function printProcessStep(icon, message, detail = '') {
  const detailStr = detail ? c().dim(` (${detail})`) : '';
  console.log(`  ${icon} ${c().white(message)}${detailStr}`);
}

function printToolCall(toolName, args = '') {
  const displayName = getToolDisplayName(toolName);
  printStepLine('active', displayName, args);
}

/**
 * Print a brief description line before an action (Claude Code style).
 * Shows a dim one-liner explaining what will be done next.
 * @param {string} description - e.g. "Updating the spinner icon to use ✳"
 */
function printActionHint(description) {
  console.log(c().dim(`  ${description}`));
}

function printThinkingStep(thought) {
  const truncated = thought.length > 80 ? thought.slice(0, 80) + '...' : thought;
  console.log(`  ${c().dim(DOT_DONE)} ${c().dim(truncated)}`);
}

// ── Claude Code-style Tool Call Display ──────────────────────────────

/**
 * Print a tool call start line (Claude Code style).
 * Shows: ⏺ ToolName(param: "value", path: "file.js")
 *
 * @param {string} toolName - raw tool name, auto-mapped to display name
 * @param {object|string} params - tool parameters to display
 * @returns {number} line count printed (for cursor-up later)
 */
function printToolCallStart(toolName, params = {}) {
  const displayName = getToolDisplayName(toolName);
  const paramStr = _formatToolParams(toolName, params);
  const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');

  // Active state color alignment: white (running), green (success), red (error)
  console.log(`  ${c().hex(THEME.text)(DOT_INDICATOR)} ${c().hex(THEME.text).bold(displayName)}${c().dim(`(${paramStr})`)}`);

  // Box-drawn command preview for Bash tools (claw-code style)
  if ((name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') && params) {
    const cmd = params.command || params.cmd || '';
    if (cmd) {
      const cols = (process.stdout.columns || 80) - 8;
      const borderColor = c().hex(THEME.bashBorder);
      console.log(`    ${borderColor('╭─')}`);
      const cmdLines = cmd.split('\n');
      for (const line of cmdLines.slice(0, 8)) {
        const display = line.length > cols ? line.slice(0, cols - 3) + '...' : line;
        console.log(`    ${borderColor('│')} ${c().dim('$')} ${c().white(display)}`);
      }
      if (cmdLines.length > 8) console.log(`    ${borderColor('│')} ${c().dim(`... +${cmdLines.length - 8} lines`)}`);
      console.log(`    ${borderColor('╰─')}`);
    }
  }

  // Write/Edit: show file path with icon
  if ((name === 'write' || name === 'writefile' || name === 'createfile') && (params?.file_path || params?.filePath || params?.path)) {
    const filePath = params.file_path || params.filePath || params.path;
    console.log(`    ${c().dim('✏️  Writing')} ${c().cyan(filePath)} ${c().dim(`(${_estimateLines(params.content)} lines)`)}`);
  }
  if ((name === 'edit' || name === 'editfile' || name === 'multiedit') && params) {
    const filePath = params.file_path || params.filePath || params.path || '';
    if (filePath) {
      console.log(`    ${c().dim('📝 Editing')} ${c().cyan(filePath)}`);
    }
  }

  return 1;
}

function _estimateLines(content) {
  if (!content) return 0;
  return String(content).split('\n').length;
}

/**
 * Format tool parameters for display, tool-type-aware.
 * Claude Code shows different formats per tool:
 *   Read → file_path
 *   Bash → command (truncated to 120 chars)
 *   Search/Grep → pattern: "X", path: "Y"
 *   Write/Update → file_path
 */
function _formatToolParams(toolName, params) {
  if (!params) return '';
  if (typeof params === 'string') return params.slice(0, 100);
  const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');

  if (name === 'read' || name === 'readfile') {
    return params.file_path || params.filePath || params.path || '';
  }
  if (name === 'notebookread') {
    return params.path || params.file_path || '';
  }
  if (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command') {
    const cmd = params.command || params.cmd || '';
    return cmd.length > 120 ? cmd.slice(0, 120) + '...' : cmd;
  }
  if (name === 'websearch') {
    const q = params.query || params.q || '';
    return q.length > 120 ? q.slice(0, 120) + '...' : q;
  }
  if (name === 'webfetch') {
    const url = params.url || params.uri || params.href || '';
    return url.length > 120 ? url.slice(0, 120) + '...' : url;
  }
  if (name === 'grep' || name === 'search' || name === 'searchcontent') {
    const parts = [];
    if (params.pattern) parts.push(`pattern: "${params.pattern}"`);
    if (params.path) parts.push(`path: "${params.path}"`);
    return parts.join(', ') || '';
  }
  if (name === 'glob' || name === 'find' || name === 'findfiles' || name === 'ls') {
    return [params.pattern, params.path].filter(Boolean).join(', ') || params.path || '';
  }
  if (name === 'write' || name === 'writefile' || name === 'edit' || name === 'editfile' || name === 'multiedit' || name === 'notebookedit') {
    return params.file_path || params.filePath || params.path || '';
  }
  if (name === 'agent' || name === 'task') {
    const role = params.role || params.subagent_type || params.agent_type || '';
    const prompt = params.description || params.prompt || params.message || '';
    const rolePrefix = role ? `${role}: ` : '';
    return `${rolePrefix}${prompt.slice(0, 60)}`.trim();
  }
  if (name === 'todowrite') {
    const count = Array.isArray(params.todos) ? params.todos.length : 0;
    return count > 0 ? `${count} todos` : 'todos';
  }

  // Generic fallback
  if (typeof params === 'object') {
    return Object.entries(params).slice(0, 3)
      .map(([k, v]) => {
        const val = typeof v === 'string'
          ? (v.length > 40 ? v.slice(0, 40) + '...' : v)
          : String(v);
        return `${k}: ${val}`;
      }).join(', ');
  }
  return '';
}

/**
 * Print a tool call result, overwriting the active line.
 * Shows: ● ToolName(params) with green/red dot + tree detail line.
 *
 * @param {string} toolName
 * @param {object|string} params - same params as start (for redraw)
 * @param {'success'|'error'} status
 * @param {string} detail - result summary, e.g. "Found 3 matches", "245 lines"
 * @param {number} elapsed - ms elapsed
 */
// Store expanded outputs for ctrl+o expansion
const _expandableOutputs = [];

function printToolCallResult(toolName, params, status, detail = '', elapsed = 0) {
  const displayName = getToolDisplayName(toolName);
  const paramStr = _formatToolParams(toolName, params);
  const name = String(toolName).toLowerCase().replace(/[\s_-]/g, '');
  const isBash = (name === 'bash' || name === 'shell' || name === 'shellcommand' || name === 'command');

  // For bash tools with box preview, don't move cursor up (multiple lines rendered)
  // For other tools, overwrite the active line
  if (process.stdout.isTTY && !isBash) {
    process.stdout.write('\x1b[1A\r\x1b[K');
  }

  // Claude Code: success=green dot, error=red dot
  const dot = status === 'success'
    ? c().hex(THEME.success)(DOT_SUCCESS)
    : c().hex(THEME.error)(DOT_ERROR);
  const elapsedStr = elapsed > 0 ? c().dim(` ${(elapsed / 1000).toFixed(1)}s`) : '';
  console.log(`  ${dot} ${c().bold(displayName)}${c().dim(`(${paramStr})`)}${elapsedStr}`);

  // Claude Code: result on next line with ⎿ prefix, collapsible
  if (detail) {
    const lines = String(detail).split('\n');
    const MAX_VISIBLE = 6;

    // For bash tools, show output in a bordered box
    if (isBash && lines.length > 0) {
      const cols = (process.stdout.columns || 80) - 8;
      const visibleLines = lines.slice(0, MAX_VISIBLE);
      for (const line of visibleLines) {
        const display = line.length > cols ? line.slice(0, cols - 3) + '...' : line;
        console.log(`    ${c().dim('⎿')} ${c().dim(display)}`);
      }
      if (lines.length > MAX_VISIBLE) {
        const remaining = lines.length - MAX_VISIBLE;
        console.log(`    ${c().dim('⎿')} ${c().dim(`... +${remaining} lines`)} ${c().dim('(ctrl+o to expand)')}`);
        _expandableOutputs.push({ tool: displayName, detail: lines.join('\n'), paramStr });
      }
    } else if (lines.length > MAX_VISIBLE) {
      // Show first few lines + collapse hint
      const shown = lines.slice(0, MAX_VISIBLE);
      for (const line of shown) {
        console.log(`    ${c().dim('⎿')} ${c().dim(line)}`);
      }
      const remaining = lines.length - MAX_VISIBLE;
      console.log(`    ${c().dim('⎿')} ${c().dim(`... +${remaining} lines`)} ${c().dim('(ctrl+o to expand)')}`);
      _expandableOutputs.push({ tool: displayName, detail: lines.join('\n'), paramStr });
    } else {
      for (const line of lines) {
        console.log(`    ${c().dim('⎿')} ${c().dim(line)}`);
      }
    }
  }
}

function getLastExpandableOutput() {
  return _expandableOutputs.length > 0 ? _expandableOutputs[_expandableOutputs.length - 1] : null;
}

/**
 * Print a file operation result with line count statistics.
 * Shows Claude Code style: "Added N lines, removed M lines"
 *
 * @param {'update'|'create'|'delete'} operation
 * @param {string} filePath - file path relative to cwd
 * @param {object} [stats] - { added: number, removed: number, total: number }
 * @param {number} [elapsed] - ms elapsed
 */
function printFileOperation(operation, filePath, stats = {}, elapsed = 0) {
  // Claude Code: Update/Create/Write use green dot, Delete uses red dot
  const opColors = {
    update: { dot: c().hex(THEME.success)(DOT_SUCCESS), label: c().hex(THEME.success)('Update'), verb: 'Updated' },
    create: { dot: c().hex(THEME.success)(DOT_SUCCESS), label: c().hex(THEME.success)('Create'), verb: 'Created' },
    write:  { dot: c().hex(THEME.success)(DOT_SUCCESS), label: c().hex(THEME.success)('Write'), verb: 'Wrote' },
    delete: { dot: c().hex(THEME.error)(DOT_ERROR), label: c().hex(THEME.error)('Delete'), verb: 'Deleted' },
  };
  const op = opColors[operation] || opColors.update;
  const elapsedStr = elapsed > 500 ? c().dim(` (${(elapsed / 1000).toFixed(1)}s)`) : '';

  console.log(`  ${op.dot} ${c().bold(op.label)}${c().dim(`(${filePath})`)}${elapsedStr}`);

  // Claude Code: result line with ⎿ prefix — "Added X lines, removed Y lines"
  const statParts = [];
  if (stats.added > 0) statParts.push(`Added ${stats.added} line${stats.added !== 1 ? 's' : ''}`);
  if (stats.removed > 0) statParts.push(`removed ${stats.removed} line${stats.removed !== 1 ? 's' : ''}`);
  if (statParts.length > 0) {
    console.log(`  ${c().dim('\u23BF')}  ${c().dim(statParts.join(', '))}`);
  }
}

/**
 * Print a diff view with line numbers and red/green coloring.
 * Includes context lines around changes.
 *
 * @param {string} filePath
 * @param {Array<{lineNum: number, type: 'add'|'remove'|'context', content: string}>} lines
 * @param {object} [stats] - { added, removed }
 */
function printInlineDiff(filePath, lines, stats = {}) {
  const maxLineNum = Math.max(...lines.map(l => l.lineNum || 0));
  const lineNumWidth = String(maxLineNum).length;

  for (const line of lines) {
    const num = String(line.lineNum || '').padStart(lineNumWidth);
    switch (line.type) {
      case 'add':
        // Claude Code: rgb(34,92,43) background for added lines
        console.log(c().bgHex(THEME.diffAdded).hex('#FFFFFF')(`  ${num} + ${line.content}`));
        break;
      case 'remove':
        // Claude Code: rgb(122,41,54) background for removed lines
        console.log(c().bgHex(THEME.diffRemoved).hex('#FFFFFF')(`  ${num} - ${line.content}`));
        break;
      default:
        console.log(`  ${c().dim(num)}   ${c().dim(line.content)}`);
        break;
    }
  }
}

/**
 * Render "Running N agents..." header.
 * @param {number} count
 * @param {string} [hint] - e.g. "(ctrl+o to expand)"
 */
function renderAgentHeader(count, hint = '') {
  const hintStr = hint ? c().dim(`  ${hint}`) : '';
  console.log(`  ${c().hex(THEME.secondaryText)(DOT_INDICATOR)} ${c().bold(`Running ${count} agents...`)}${hintStr}`);
}

/**
 * Render tree-style agent progress.
 * @param {Array<{name: string, status: 'pending'|'running'|'completed'|'error', toolCalls?: number, tokens?: number, elapsed?: string, detail?: string}>} agents
 * @returns {number} lines rendered
 */
function renderAgentProgress(agents) {
  let lines = 0;
  for (let i = 0; i < agents.length; i++) {
    const agent = agents[i];
    const isLast = i === agents.length - 1;
    const branch = isLast ? '└' : '├';

    let statusIcon, nameColor;
    switch (agent.status) {
      case 'completed':
        statusIcon = c().hex(THEME.success)(DOT_DONE);
        nameColor = c().dim;
        break;
      case 'error':
        statusIcon = c().hex(THEME.error)(DOT_ERROR);
        nameColor = c().hex(THEME.error);
        break;
      case 'running':
        statusIcon = c().hex(THEME.secondaryText)(DOT_INDICATOR);
        nameColor = c().bold;
        break;
      default:
        statusIcon = c().dim(DOT_PENDING);
        nameColor = c().dim;
        break;
    }

    // Stats string: tool calls · tokens · elapsed
    const stats = [];
    if (agent.toolCalls > 0) stats.push(`${agent.toolCalls} tool uses`);
    if (agent.tokens > 0) {
      const tokenStr = agent.tokens >= 1000
        ? `${(agent.tokens / 1000).toFixed(1)}k tokens`
        : `${agent.tokens} tokens`;
      stats.push(tokenStr);
    }
    if (agent.elapsed) stats.push(agent.elapsed);
    const statsStr = stats.length > 0 ? c().dim(` · ${stats.join(' · ')}`) : '';

    // Claude Code style: ⏺ AgentName with status-colored dot
    console.log(`    ${statusIcon} ${nameColor(agent.name)}${statsStr}`);
    lines++;

    // Detail line with ⎿ prefix
    if (agent.detail) {
      console.log(`      ${c().dim('\u23BF')}  ${c().dim(agent.detail)}`);
      lines++;
    }
  }
  return lines;
}

/**
 * Render agent/task completion summary line.
 * Shows: Done (N tool uses · X.Xk tokens · Nm NNs)
 *
 * @param {object} stats - { toolCalls, tokens, elapsedMs }
 */
function renderAgentDone(stats = {}) {
  const parts = [];
  if (stats.toolCalls > 0) parts.push(`${stats.toolCalls} tool uses`);
  if (stats.tokens > 0) {
    parts.push(`${(stats.tokens / 1000).toFixed(1)}k tokens`);
  }
  if (stats.elapsedMs > 0) {
    const sec = Math.floor(stats.elapsedMs / 1000);
    const min = Math.floor(sec / 60);
    const remSec = sec % 60;
    parts.push(min > 0 ? `${min}m ${remSec}s` : `${sec}s`);
  }

  const detail = parts.length > 0 ? ` (${parts.join(' · ')})` : '';
  // Claude Code: ⎿ Done summary
  console.log(`  ${c().dim('\u23BF')}  ${c().hex(THEME.success)('Done')}${c().dim(detail)}`);
}

/**
 * Render "(ctrl+o to expand)" hint.
 */
function renderExpandHint() {
  console.log(c().dim('  (ctrl+o to expand)'));
}

/**
 * ExpandableSection — manages collapsible output sections.
 * Stores full output but displays only a summary until expanded.
 */
class ExpandableSection {
  constructor() {
    this._sections = [];
    this._expandedIndex = -1;
  }

  /**
   * Add a collapsible section.
   * @param {string} summary - one-line summary shown when collapsed
   * @param {string[]} fullOutput - full output lines shown when expanded
   */
  add(summary, fullOutput) {
    this._sections.push({ summary, fullOutput, expanded: false });
    return this._sections.length - 1;
  }

  /**
   * Toggle expand/collapse of a section.
   */
  toggle(index) {
    if (index >= 0 && index < this._sections.length) {
      this._sections[index].expanded = !this._sections[index].expanded;
    }
  }

  /**
   * Get all sections for display.
   */
  getSections() {
    return this._sections;
  }
}

/**
 * ToolUseTracker — Claude Code-style collapsible tool-use display.
 *
 * While running, shows:
 *   ● Explore(Explore training infrastructure)
 *     ├ Bash(grep -r "train.*start" /path/to/dir)
 *     │ Running...
 *     ├ Read(backend/src/cli/router.js)
 *     │ Running...
 *     └ +12 more tool uses (ctrl+o to expand)
 *     (ctrl+b to run in background)
 *
 * When done, collapses to:
 *   ● Explore(Explore training infrastructure)
 *     └ Done (24 tool uses · 60.9k tokens · 2m 15s)
 *     (ctrl+o to expand)
 */
class ToolUseTracker {
  /**
   * @param {string} label - Top-level label (e.g. "Explore", "Agent")
   * @param {string} description - Short description (e.g. "Explore training infrastructure")
   * @param {object} [opts]
   * @param {number} [opts.maxVisible=3] - Max tool calls visible before "+N more"
   */
  constructor(label, description, opts = {}) {
    this._label = label;
    this._description = description;
    this._maxVisible = opts.maxVisible || 3;
    this._tools = [];          // [{ name, params, status, elapsed, detail }]
    this._renderedLines = 0;
    this._startTime = Date.now();
    this._totalTokens = 0;
    this._finished = false;
    this._headerPrinted = false;
  }

  /**
   * Print the header line (call once before adding tools).
   * Claude Code style: ⏺ Agent(description)
   */
  printHeader() {
    if (this._headerPrinted) return;
    this._headerPrinted = true;
    const displayName = getToolDisplayName(this._label);
    console.log(`  ${c().hex(THEME.secondaryText)(DOT_INDICATOR)} ${c().bold(displayName)}${c().dim(`(${this._description})`)}`);
    this._renderedLines = 1;
  }

  /**
   * Record a tool call starting.
   * @param {string} name - Tool name (e.g. "Read", "Bash", "Grep")
   * @param {string} params - Brief param string
   */
  toolStart(name, params = '') {
    const summary = summarizeToolDetail(name, params);
    this._tools.push({ name, params: summary.short, kind: summary.kind, status: 'running', elapsed: 0, detail: '', startTime: Date.now() });
    this._rerender();
  }

  /**
   * Record a tool call completing.
   * @param {string} name - Tool name
   * @param {'success'|'error'} status
   * @param {string} [detail]
   * @param {number} [elapsed] - ms
   */
  toolEnd(name, status = 'success', detail = '', elapsed = 0) {
    // Find the most recent matching running tool
    for (let i = this._tools.length - 1; i >= 0; i--) {
      if (this._tools[i].name === name && this._tools[i].status === 'running') {
        this._tools[i].status = status;
        this._tools[i].detail = detail;
        this._tools[i].elapsed = elapsed || (Date.now() - this._tools[i].startTime);
        break;
      }
    }
    this._rerender();
  }

  /**
   * Add token count.
   * @param {number} tokens
   */
  addTokens(tokens) {
    this._totalTokens += tokens;
  }

  /**
   * Mark as finished and collapse to summary.
   */
  finish() {
    this._finished = true;
    this._rerender();
  }

  /**
   * Clear previously rendered lines and re-render.
   */
  _rerender() {
    if (!this._headerPrinted) this.printHeader();

    // Clear previous tool lines (not the header)
    if (process.stdout.isTTY && this._renderedLines > 1) {
      for (let i = 0; i < this._renderedLines - 1; i++) {
        process.stdout.write('\x1b[1A\r\x1b[K');
      }
    }

    let lines = 0;

    if (this._finished) {
      // Replace header with green dot (Claude Code: success color)
      if (process.stdout.isTTY) {
        process.stdout.write('\x1b[1A\r\x1b[K');
      }
      const displayName = getToolDisplayName(this._label);
      console.log(`  ${c().hex(THEME.success)(DOT_SUCCESS)} ${c().bold(displayName)}${c().dim(`(${this._description})`)}`);
      lines++;

      // Summary line
      const elapsed = Date.now() - this._startTime;
      const parts = [];
      parts.push(`${this._tools.length} tool uses`);
      if (this._totalTokens > 0) {
        parts.push(this._totalTokens >= 1000
          ? `${(this._totalTokens / 1000).toFixed(1)}k tokens`
          : `${this._totalTokens} tokens`);
      }
      const sec = Math.floor(elapsed / 1000);
      const min = Math.floor(sec / 60);
      const remSec = sec % 60;
      parts.push(min > 0 ? `${min}m ${remSec}s` : `${sec}s`);

      // Claude Code: ⎿ summary with (ctrl+o to expand)
      console.log(`  ${c().dim('\u23BF')}  ${c().hex(THEME.success)('Done')} ${c().dim(`(${parts.join(' · ')})`)}`);
      lines++;
      console.log(c().dim('    (ctrl+o to expand)'));
      lines++;

      this._renderedLines = 1 + lines;
      return;
    }

    // Running state: show recent tools with Claude Code tree style
    const visible = this._tools.slice(-this._maxVisible);
    const hiddenCount = Math.max(0, this._tools.length - this._maxVisible);

    for (let i = 0; i < visible.length; i++) {
      const tool = visible[i];
      const displayName = getToolDisplayName(tool.name);
      const paramStr = tool.params ? tool.params.slice(0, 80) : '';

      if (tool.status === 'running') {
        // Active tool: ⏺ ToolName(params) with blinking dot
        console.log(`    ${c().hex(THEME.secondaryText)(DOT_INDICATOR)} ${c().bold(displayName)}${paramStr ? c().dim(`(${paramStr})`) : ''}`);
        lines++;
        console.log(`      ${c().dim('Running\u2026')}`);
        lines++;
      } else if (tool.status === 'success') {
        // Completed: green ⏺ ToolName(params)
        console.log(`    ${c().hex(THEME.success)(DOT_SUCCESS)} ${c().bold(displayName)}${paramStr ? c().dim(`(${paramStr})`) : ''}`);
        lines++;
        if (tool.detail) {
          console.log(`      ${c().dim('\u23BF')}  ${c().dim(tool.detail)}`);
          lines++;
        }
      } else if (tool.status === 'error') {
        // Error: red ⏺ ToolName(params)
        console.log(`    ${c().hex(THEME.error)(DOT_ERROR)} ${c().bold(displayName)}${paramStr ? c().dim(`(${paramStr})`) : ''}`);
        lines++;
        const detail = tool.detail ? tool.detail : 'Failed';
        console.log(`      ${c().dim('\u23BF')}  ${c().hex(THEME.error)(detail)}`);
        lines++;
      }
    }

    if (hiddenCount > 0) {
      console.log(`    ${c().dim(`+${hiddenCount} more tool uses (ctrl+o to expand)`)}`);
      lines++;
    }

    console.log(c().dim('    (ctrl+b to run in background)'));
    lines++;

    this._renderedLines = 1 + lines;
  }

  /**
   * Get total tool count.
   */
  get toolCount() { return this._tools.length; }
  get totalTokens() { return this._totalTokens; }
  get elapsedMs() { return Date.now() - this._startTime; }
}

// ── Transparency Integration ──────────────────────────────────────────
// Wire transparencyService into the rendering pipeline.

let _transparency;
function _getTransparency() {
  if (_transparency !== undefined) return _transparency;
  try { _transparency = require('../services/transparencyService'); } catch { _transparency = null; }
  return _transparency;
}

/**
 * Print per-turn cost/token summary after an AI response.
 * Claude Code style: dim line below the response with token counts, cost, model.
 *
 * @param {object} usage - { inputTokens, outputTokens, cacheReadTokens, model, adapter, costUSD, durationMs }
 */
function printTurnCost(usage) {
  const t = _getTransparency();
  if (!t || !usage) return;
  const line = t.formatPostResponseLine(usage);
  if (line) console.log(line);
}

/**
 * Print cascade/fallback transparency when multiple adapters were tried.
 *
 * @param {Array<{adapter: string, success: boolean, error?: string, durationMs?: number}>} steps
 */
function printCascadeSteps(steps) {
  const t = _getTransparency();
  if (!t || !steps || steps.length <= 1) return;
  const line = t.formatCascadeSteps(steps);
  if (line) console.log(`  ${c().dim('cascade:')} ${line}`);
}

/**
 * Print permission tier for a shell command (inline, before execution).
 *
 * @param {object} classification - { tier, matchedRule, approved }
 */
function printPermissionTier(classification) {
  const t = _getTransparency();
  if (!t || !classification) return;
  // Only show for dangerous/critical (safe/moderate are quiet)
  if (classification.tier === 'safe' || classification.tier === 'moderate') return;
  const line = t.formatPermissionTier(classification);
  if (line) console.log(`    ${line}`);
}

/**
 * Print session recap on exit.
 *
 * @param {object} session - { durationMs, totalInputTokens, totalOutputTokens, totalCostUSD, requestCount, toolCallCount, model, topTools }
 */
function printSessionRecap(session) {
  const t = _getTransparency();
  if (!t || !session) return;
  const text = t.formatSessionRecap(session);
  if (text) process.stdout.write(text);
}

/**
 * Print a quota warning if approaching limit.
 *
 * @param {object} quota - { used, limit }
 */
function printQuotaWarning(quota) {
  const t = _getTransparency();
  if (!t || !quota) return;
  const warning = t.checkQuotaWarning(quota);
  if (warning) console.log(`  ${warning}`);
}

/**
 * Print context compaction notification.
 *
 * @param {object} compaction - { beforeTokens, afterTokens, durationMs }
 */
function printCompactionResult(compaction) {
  const t = _getTransparency();
  if (!t || !compaction) return;
  const line = t.formatCompactionNotice(compaction);
  if (line) console.log(`  ${line}`);
}

/**
 * Print edit diff preview before applying changes.
 *
 * @param {object} edit - { filePath, oldContent, newContent, lineStart }
 * @returns {boolean} true if preview was printed
 */
function printEditPreview(edit) {
  const t = _getTransparency();
  if (!t || !edit) return false;
  const preview = t.formatEditPreview(edit);
  if (!preview) return false;
  console.log(`    ${preview.header}`);
  for (const line of preview.diffLines) {
    console.log(`    ${line}`);
  }
  console.log(c().dim(`    ${preview.stats.removed} removed, ${preview.stats.added} added`));
  return true;
}

module.exports = {
  setInteractiveGuard,
  DynamicSpinner,
  ProcessTracker,
  TaskPlanTracker,
  ToolUseTracker,
  ExpandableSection,
  renderDiff,
  renderStructuredDiff,
  renderResponseWithDiffs,
  renderMarkdownLite,
  renderAiResponse,
  renderUserMessage,
  askInlineQuestion,
  printStepLine,
  printStepDetail,
  printCompactingNotice,
  printProcessStep,
  printToolCall,
  printActionHint,
  printToolCallStart,
  printToolCallResult,
  getLastExpandableOutput,
  printFileOperation,
  printInlineDiff,
  renderAgentHeader,
  renderAgentProgress,
  renderAgentDone,
  renderExpandHint,
  printThinkingStep,
  startSparkle,
  getToolDisplayName,
  normalizeToolKind,
  THEME,
  PHASE_LABELS,
  TOOL_DISPLAY_NAMES,
  DOT_PENDING,
  DOT_INDICATOR,
  DOT_SUCCESS,
  DOT_ERROR,
  DOT_DONE,
  TASK_PENDING,
  TASK_IN_PROGRESS,
  TASK_COMPLETED,
  // Transparency layer
  printTurnCost,
  printCascadeSteps,
  printPermissionTier,
  printSessionRecap,
  printQuotaWarning,
  printCompactionResult,
  printEditPreview,
};
