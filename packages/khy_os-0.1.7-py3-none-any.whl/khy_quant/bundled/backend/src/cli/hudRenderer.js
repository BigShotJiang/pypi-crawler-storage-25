/**
 * HUD Renderer — terminal-native status dashboard for KHY AI REPL.
 *
 * Two-layer design:
 *   1. Bottom status bar (1 line, always visible) — git branch, active tool,
 *      context bar, tokens, session duration, cost
 *   2. Expanded panel (/hud command) — full details on demand
 *
 * State is session-scoped (in-memory), driven by hooks from:
 *   - ProcessTracker (tool start/end)
 *   - ai.js (context estimation)
 *   - cliAgentRunner (agent progress)
 *   - tokenUsageService (token/cost data)
 */
const { execSync } = require('child_process');
const path = require('path');

// Lazy chalk
let _chalk;
const c = () => (_chalk ??= (require('chalk').default || require('chalk')));

// ── Model context window limits ──────────────────────────────────────
const MODEL_CONTEXT_LIMITS = {
  'claude-3-5-sonnet': 200000,
  'claude-3-haiku': 200000,
  'claude-sonnet-4': 200000,
  'claude-opus-4': 200000,
  'gpt-4o': 128000,
  'gpt-4o-mini': 128000,
  'gemini-2.0-flash': 1000000,
  'gemini-2.5-flash': 1000000,
  'qwen-turbo': 8000,
  'qwen-plus': 32000,
  'glm-4': 128000,
  'deepseek-v2': 128000,
  'llama-3.3': 128000,
  default: 128000,
};

// ── Session state store ──────────────────────────────────────────────
const hudState = {
  // Context / token tracking
  sessionTokens: { input: 0, output: 0, total: 0 },
  contextWindow: { used: 0, limit: 200000 },

  // Active tool tracking
  activeTool: null, // { name, target, startTime }
  toolHistory: [],  // last 10: [{ name, target, status, elapsed }]

  // Agent monitoring
  activeAgents: [], // [{ name, status, elapsed, detail }]

  // Todo progress
  todos: [], // [{ text, done }]

  // Git info (cached)
  git: { branch: '', dirty: false, dirtyCount: 0, ahead: 0, behind: 0 },
  _gitLastRefresh: 0,

  // Session stats
  sessionStart: Date.now(),
  requestCount: 0,

  // Model/adapter transparency
  lastModel: '',     // last model used (e.g. "claude-3.5-sonnet")
  lastAdapter: '',   // last adapter used (e.g. "relay")
  sessionCostUSD: 0, // running session cost
};

const GIT_CACHE_TTL = 30000; // 30 seconds
const MAX_TOOL_HISTORY = 10;

// ── State mutation API ───────────────────────────────────────────────

/**
 * Update token counts after an AI request.
 * @param {{ inputTokens?: number, outputTokens?: number, totalTokens?: number }} usage
 */
function updateTokens(usage) {
  if (!usage) return;
  hudState.sessionTokens.input += usage.inputTokens || 0;
  hudState.sessionTokens.output += usage.outputTokens || 0;
  hudState.sessionTokens.total += usage.totalTokens || (usage.inputTokens || 0) + (usage.outputTokens || 0);
  hudState.requestCount++;
}

/**
 * Update model/adapter info after an AI response.
 * @param {string} model
 * @param {string} [adapter]
 * @param {number} [turnCostUSD]
 */
function updateModelInfo(model, adapter, turnCostUSD) {
  if (model) hudState.lastModel = model;
  if (adapter) hudState.lastAdapter = adapter;
  if (turnCostUSD > 0) hudState.sessionCostUSD += turnCostUSD;
}

/**
 * Set estimated context window usage.
 * @param {number} inputTokens — approximate tokens sent as context
 * @param {number} [limit] — model context limit
 */
function setContextUsage(inputTokens, limit) {
  hudState.contextWindow.used = inputTokens;
  if (limit && limit > 0) hudState.contextWindow.limit = limit;
}

/**
 * Get context limit for a model name.
 * @param {string} model
 * @returns {number}
 */
function getContextLimit(model) {
  if (!model) return MODEL_CONTEXT_LIMITS.default;
  const lower = model.toLowerCase();
  for (const [key, limit] of Object.entries(MODEL_CONTEXT_LIMITS)) {
    if (key !== 'default' && lower.includes(key)) return limit;
  }
  return MODEL_CONTEXT_LIMITS.default;
}

/**
 * Record that a tool has started.
 * @param {string} name
 * @param {string} [target]
 */
function toolStart(name, target = '') {
  hudState.activeTool = { name, target, startTime: Date.now() };
}

/**
 * Record that a tool has finished.
 * @param {string} name
 * @param {'success'|'error'|'done'} status
 * @param {number} [elapsed]
 */
function toolEnd(name, status = 'done', elapsed = 0) {
  hudState.toolHistory.push({ name, target: hudState.activeTool?.target || '', status, elapsed });
  if (hudState.toolHistory.length > MAX_TOOL_HISTORY) {
    hudState.toolHistory.shift();
  }
  hudState.activeTool = null;
}

/**
 * Update agent monitoring state.
 * @param {Array<{name: string, status: string, elapsed?: number, detail?: string, tokens?: number}>} agents
 */
function agentUpdate(agents) {
  hudState.activeAgents = agents.map(a => ({
    name: a.name,
    status: a.status,
    elapsed: a.elapsed || 0,
    detail: a.detail || '',
    tokens: a.tokens || 0,
  }));
}

/**
 * Update todo progress (extracted from AI response).
 * @param {Array<{text: string, done: boolean}>} todos
 */
function updateTodos(todos) {
  hudState.todos = todos;
}

/**
 * Refresh git info (cached for 30s).
 */
function refreshGit() {
  const now = Date.now();
  if (now - hudState._gitLastRefresh < GIT_CACHE_TTL) return;
  hudState._gitLastRefresh = now;

  const cwd = process.env.KHYQUANT_CWD || process.cwd();
  try {
    const branch = execSync('git rev-parse --abbrev-ref HEAD', {
      cwd, timeout: 2000, encoding: 'utf-8', stdio: ['pipe', 'pipe', 'pipe'],
    }).trim();
    const status = execSync('git status --porcelain', {
      cwd, timeout: 2000, encoding: 'utf-8', stdio: ['pipe', 'pipe', 'pipe'],
    }).trim();
    const dirty = status.length > 0;
    const dirtyCount = dirty ? status.split('\n').length : 0;

    let ahead = 0, behind = 0;
    try {
      const ab = execSync('git rev-list --left-right --count HEAD...@{u}', {
        cwd, timeout: 2000, encoding: 'utf-8', stdio: ['pipe', 'pipe', 'pipe'],
      }).trim();
      [ahead, behind] = ab.split('\t').map(Number);
    } catch { /* no upstream tracking */ }

    hudState.git = { branch, dirty, dirtyCount, ahead, behind };
  } catch {
    // Not a git repo or git not installed
    hudState.git = { branch: '', dirty: false, dirtyCount: 0, ahead: 0, behind: 0 };
  }
}

/**
 * Get full state snapshot.
 * @returns {object}
 */
function getState() {
  return { ...hudState };
}

// ── Rendering helpers ────────────────────────────────────────────────

/**
 * Strip ANSI escape codes for width calculation.
 */
function stripAnsi(str) {
  return str.replace(/\x1b\[[0-9;]*m/g, '');
}

/**
 * Format token count (1000 → 1.0k, 1500 → 1.5k).
 */
function fmtTokens(n) {
  if (n >= 10000) return `${(n / 1000).toFixed(0)}k`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
  return String(n);
}

/**
 * Format elapsed time (seconds → Xm Xs, or Xs).
 */
function fmtDuration(ms) {
  const sec = Math.floor(ms / 1000);
  if (sec >= 3600) return `${Math.floor(sec / 3600)}h${Math.floor((sec % 3600) / 60)}m`;
  if (sec >= 60) return `${Math.floor(sec / 60)}m`;
  return `${sec}s`;
}

/**
 * Render a context usage progress bar.
 * @param {number} used
 * @param {number} limit
 * @param {number} [barLen=8]
 * @returns {string}
 */
function renderContextBar(used, limit, barLen = 8) {
  const chalk = c();
  const pct = limit > 0 ? Math.min(100, Math.round((used / limit) * 100)) : 0;
  const filled = Math.round(barLen * pct / 100);
  const colorName = pct > 80 ? 'red' : pct > 50 ? 'yellow' : 'green';
  const bar = chalk[colorName]('\u2588'.repeat(filled)) + chalk.dim('\u2591'.repeat(barLen - filled));
  return `${bar} ${chalk[colorName](pct + '%')} ctx`;
}

// ── Status bar (1 line, bottom of terminal) ──────────────────────────

/**
 * Render the enhanced status bar.
 * @param {number} cols — terminal width
 * @param {{ planMode?: boolean, studyMode?: boolean }} [opts]
 * @returns {string} — ANSI-colored single line
 */
function renderStatusBar(cols, opts = {}) {
  const chalk = c();

  // ── Left side: status + active operation ──
  const leftParts = [];

  // Claude Code style: status indicator with color changes
  // idle=dim, tool=orange, thinking=yellow, error=red
  if (hudState.activeTool) {
    const elapsed = Date.now() - hudState.activeTool.startTime;
    const toolName = hudState.activeTool.name;
    let toolStr = chalk.hex('#D77757')('·') + ' ' + chalk.bold(toolName);
    if (cols > 100 && hudState.activeTool.target) {
      toolStr += chalk.dim(` ${hudState.activeTool.target}`);
    }
    if (elapsed > 2000) toolStr += chalk.dim(` ${fmtDuration(elapsed)}`);
    leftParts.push(toolStr);
  } else if (opts.compacting) {
    // Claude Code: ✻ Coalescing... with amber color
    leftParts.push(chalk.hex('#FFC107')('✻ Coalescing...'));
    if (opts.compactingElapsed) leftParts.push(chalk.dim(opts.compactingElapsed));
    if (opts.compactingTokens) leftParts.push(chalk.dim(`↑ ${opts.compactingTokens} tokens`));
  } else if (opts.planMode) {
    leftParts.push(chalk.hex('#FFC107')('plan'));
  }

  // Context bar (only if we have data)
  if (hudState.contextWindow.used > 0) {
    const barLen = cols > 120 ? 8 : 5;
    leftParts.push(renderContextBar(hudState.contextWindow.used, hudState.contextWindow.limit, barLen));
  }

  const leftText = leftParts.length > 0
    ? leftParts.join(chalk.dim(' · '))
    : chalk.dim('> ready');

  // ── Right side: model, tokens, cost, git branch ──
  const rightParts = [];

  // Model name (transparency: show which model is answering)
  if (hudState.lastModel) {
    let modelStr = chalk.cyan(hudState.lastModel);
    if (hudState.lastAdapter && hudState.lastAdapter !== hudState.lastModel) {
      modelStr += chalk.dim(`/${hudState.lastAdapter}`);
    }
    rightParts.push(modelStr);
  }

  // Token count
  if (hudState.sessionTokens.total > 0) {
    rightParts.push(chalk.dim(fmtTokens(hudState.sessionTokens.total) + ' tokens'));
  }

  // Session cost
  if (hudState.sessionCostUSD > 0) {
    const cost = hudState.sessionCostUSD >= 0.01
      ? `$${hudState.sessionCostUSD.toFixed(2)}`
      : `$${hudState.sessionCostUSD.toFixed(4)}`;
    rightParts.push(chalk.yellow(cost));
  }

  // Git branch — Claude Code shows this on the right
  if (hudState.git.branch) {
    let gitStr = chalk.hex('#6495ED')(hudState.git.branch);
    if (hudState.git.dirty) gitStr += chalk.hex('#FFC107')('*');
    rightParts.push(gitStr);
  }

  const rightText = rightParts.join(chalk.dim(' · '));

  // Compose full line with padding
  const leftLen = stripAnsi(leftText).length;
  const rightLen = stripAnsi(rightText).length;
  const pad = Math.max(1, cols - leftLen - rightLen - 3);

  return chalk.bgBlack(
    ' ' + leftText + ' '.repeat(pad) + rightText + ' '
  );
}

// ── HUD expanded panel (/hud command) ────────────────────────────────

/**
 * Render the full HUD panel.
 * @param {number} cols — terminal width
 * @returns {string}
 */
function renderHudPanel(cols) {
  const chalk = c();
  const w = Math.min(cols - 4, 60);
  const lines = [];

  const hr = '\u2500'.repeat(w - 6);
  lines.push('');
  lines.push(chalk.cyan(`  \u250c\u2500 HUD ${hr}\u2510`));

  // ── Context ──
  const ctx = hudState.contextWindow;
  const ctxPct = ctx.limit > 0 ? Math.min(100, Math.round((ctx.used / ctx.limit) * 100)) : 0;
  const ctxBarLen = 20;
  const ctxFilled = Math.round(ctxBarLen * ctxPct / 100);
  const ctxColor = ctxPct > 80 ? 'red' : ctxPct > 50 ? 'yellow' : 'green';
  const ctxBar = chalk[ctxColor]('\u2588'.repeat(ctxFilled)) + chalk.dim('\u2591'.repeat(ctxBarLen - ctxFilled));
  lines.push(chalk.dim('  \u2502'));
  lines.push(chalk.dim('  \u2502  ') + chalk.white('Context   ') + ctxBar + ` ${chalk[ctxColor](ctxPct + '%')}  ${fmtTokens(ctx.used)} / ${fmtTokens(ctx.limit)}`);

  // ── Tokens ──
  const tok = hudState.sessionTokens;
  lines.push(chalk.dim('  \u2502  ') + chalk.white('Tokens    ') +
    chalk.dim('\u2191 ') + chalk.white(tok.input.toLocaleString()) +
    chalk.dim('  \u2193 ') + chalk.white(tok.output.toLocaleString()) +
    chalk.dim('  \u5408\u8ba1 ') + chalk.bold(tok.total.toLocaleString()));

  // ── Cost ──
  try {
    const tokenSvc = require('../services/tokenUsageService');
    const sessionCost = tokenSvc.getSessionCost();
    const monthUsage = tokenSvc.getMonthUsage();
    const monthCostUSD = (monthUsage.costUSD || 0);
    lines.push(chalk.dim('  \u2502  ') + chalk.white('Cost      ') +
      chalk.yellow(`\u00a5${(sessionCost.costCNY || 0).toFixed(4)}`) +
      chalk.dim(` ($${(sessionCost.costUSD || 0).toFixed(4)})`) +
      chalk.dim(`  \u672c\u6708 `) + chalk.yellow(`\u00a5${(monthCostUSD * 7.25).toFixed(2)}`));
  } catch {
    lines.push(chalk.dim('  \u2502  ') + chalk.white('Cost      ') + chalk.dim('N/A'));
  }

  lines.push(chalk.dim('  \u2502'));

  // ── Git ──
  const git = hudState.git;
  if (git.branch) {
    let gitLine = chalk.cyan(git.branch);
    if (git.dirty) gitLine += chalk.yellow(`*`);
    if (git.ahead > 0) gitLine += chalk.green(` +${git.ahead} ahead`);
    if (git.behind > 0) gitLine += chalk.red(` -${git.behind} behind`);
    if (git.dirtyCount > 0) gitLine += chalk.dim(`  ${git.dirtyCount} files dirty`);
    lines.push(chalk.dim('  \u2502  ') + chalk.white('Git       ') + gitLine);
  }

  // ── Session ──
  const dur = fmtDuration(Date.now() - hudState.sessionStart);
  lines.push(chalk.dim('  \u2502  ') + chalk.white('Session   ') +
    chalk.white(dur) + chalk.dim(` \u00b7 ${hudState.requestCount} requests`));

  lines.push(chalk.dim('  \u2502'));

  // ── Tool history ──
  if (hudState.toolHistory.length > 0) {
    lines.push(chalk.dim('  \u2502  ') + chalk.white('Tools'));
    for (const t of hudState.toolHistory.slice(-5)) {
      const icon = t.status === 'success' ? chalk.green('\u2713')
        : t.status === 'error' ? chalk.red('\u2717')
        : chalk.dim('\u2713');
      const elStr = t.elapsed > 0 ? chalk.dim(` ${(t.elapsed / 1000).toFixed(1)}s`) : '';
      const target = t.target ? chalk.dim(` ${t.target}`) : '';
      lines.push(chalk.dim('  \u2502  ') + `  ${icon} ${chalk.white(t.name)}${target}${elStr}`);
    }
    if (hudState.activeTool) {
      const elapsed = Date.now() - hudState.activeTool.startTime;
      lines.push(chalk.dim('  \u2502  ') + `  ${chalk.redBright('\u2733')} ${chalk.white(hudState.activeTool.name)} ${chalk.dim(hudState.activeTool.target || '')} ${chalk.dim(fmtDuration(elapsed) + '...')}`);
    }
    lines.push(chalk.dim('  \u2502'));
  }

  // ── Agents ──
  if (hudState.activeAgents.length > 0) {
    lines.push(chalk.dim('  \u2502  ') + chalk.white('Agents'));
    for (const a of hudState.activeAgents) {
      const icon = a.status === 'completed' ? chalk.green('\u25cf')
        : a.status === 'error' ? chalk.red('\u25cf')
        : a.status === 'running' ? chalk.redBright('\u2733')
        : chalk.dim('\u25cb');
      const detail = a.detail ? chalk.dim(`  ${a.detail}`) : '';
      const elapsed = a.elapsed > 0 ? chalk.dim(`  ${(a.elapsed / 1000).toFixed(1)}s`) : '';
      const tokens = a.tokens > 0 ? chalk.dim(`  ${fmtTokens(a.tokens)}`) : '';
      lines.push(chalk.dim('  \u2502  ') + `  ${icon} ${chalk.white(a.name)}${detail}${elapsed}${tokens}`);
    }
    lines.push(chalk.dim('  \u2502'));
  }

  // ── Todos ──
  if (hudState.todos.length > 0) {
    const done = hudState.todos.filter(t => t.done).length;
    const total = hudState.todos.length;
    const todoBar = '\u25a0'.repeat(done) + '\u25a1'.repeat(total - done);
    lines.push(chalk.dim('  \u2502  ') + chalk.white('Todo      ') +
      chalk.green(todoBar) + chalk.dim(` ${done}/${total}`));
    for (const t of hudState.todos) {
      const icon = t.done ? chalk.green('\u2714') : chalk.dim('\u2610');
      lines.push(chalk.dim('  \u2502  ') + `  ${icon} ${t.done ? chalk.dim(t.text) : chalk.white(t.text)}`);
    }
    lines.push(chalk.dim('  \u2502'));
  }

  // ── Quota ──
  try {
    const tokenSvc = require('../services/tokenUsageService');
    const quota = tokenSvc.getRemainingQuota();
    if (quota.limit !== -1) {
      const qPct = Math.round((quota.used / quota.limit) * 100);
      const qColor = qPct > 90 ? 'red' : qPct > 70 ? 'yellow' : 'green';
      const qBarLen = 15;
      const qFilled = Math.round(qBarLen * Math.min(qPct, 100) / 100);
      const qBar = chalk[qColor]('\u2588'.repeat(qFilled)) + chalk.dim('\u2591'.repeat(qBarLen - qFilled));
      lines.push(chalk.dim('  \u2502  ') + chalk.white('Quota     ') +
        qBar + ` ${chalk[qColor](qPct + '%')} ` +
        chalk.dim(`(${quota.used.toLocaleString()}/${quota.limit.toLocaleString()})`));
      lines.push(chalk.dim('  \u2502'));
    }
  } catch { /* ignore */ }

  lines.push(chalk.cyan(`  \u2514${'\u2500'.repeat(w - 4)}\u2518`));
  lines.push('');

  return lines.join('\n');
}

module.exports = {
  // State mutation
  updateTokens,
  updateModelInfo,
  setContextUsage,
  getContextLimit,
  toolStart,
  toolEnd,
  agentUpdate,
  updateTodos,
  refreshGit,

  // Rendering
  renderStatusBar,
  renderHudPanel,

  // Getters
  getState,

  // Constants
  MODEL_CONTEXT_LIMITS,
};
