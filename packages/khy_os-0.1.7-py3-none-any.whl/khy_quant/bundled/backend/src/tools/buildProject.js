/**
 * Tool: build_project — detect project type and run build with structured output.
 */
'use strict';

const { defineTool } = require('./_baseTool');
const fs = require('fs');
const path = require('path');
const { spawnWithIdleTimeout } = require('../utils/spawnWithIdleTimeout');

// ─── Project Type Detection ────────────────────────────────────────────────

const BUILD_CONFIGS = [
  { file: 'package.json', type: 'nodejs', detect: _detectNodeBuild },
  { file: 'Cargo.toml',   type: 'rust',   cmd: 'cargo build --release' },
  { file: 'go.mod',       type: 'go',     cmd: 'go build ./...' },
  { file: 'Makefile',     type: 'make',   cmd: 'make' },
  { file: 'makefile',     type: 'make',   cmd: 'make' },
  { file: 'CMakeLists.txt', type: 'cmake', cmd: 'mkdir -p build && cd build && cmake .. && make' },
  { file: 'build.gradle', type: 'gradle', cmd: './gradlew build' },
  { file: 'pom.xml',      type: 'maven',  cmd: 'mvn package -q' },
];

function _detectNodeBuild(cwd) {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(cwd, 'package.json'), 'utf-8'));
    if (pkg.scripts && pkg.scripts.build) return `npm run build`;
  } catch { /* ignore */ }
  return null;
}

function _detectProject(cwd) {
  for (const config of BUILD_CONFIGS) {
    if (fs.existsSync(path.join(cwd, config.file))) {
      const cmd = config.detect ? config.detect(cwd) : config.cmd;
      return { type: config.type, command: cmd };
    }
  }
  return null;
}

// ─── Output Parsers ────────────────────────────────────────────────────────

function _parseErrors(output, type) {
  const errors = [];
  const warnings = [];
  const lines = output.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    if (type === 'nodejs' || type === 'cmake') {
      // Webpack/TypeScript/ESBuild: ERROR in ./path:line:col
      const errMatch = line.match(/ERROR\s+in\s+(.+?)(?::(\d+):(\d+))?/);
      if (errMatch) { errors.push({ file: errMatch[1], line: _int(errMatch[2]), col: _int(errMatch[3]), message: lines[i + 1]?.trim() || '' }); continue; }
      const warnMatch = line.match(/WARNING\s+in\s+(.+?)(?::(\d+):(\d+))?/);
      if (warnMatch) { warnings.push({ file: warnMatch[1], line: _int(warnMatch[2]), col: _int(warnMatch[3]), message: lines[i + 1]?.trim() || '' }); continue; }
    }

    if (type === 'rust') {
      const errMatch = line.match(/^error(?:\[E\d+\])?: (.+)/);
      if (errMatch) { errors.push({ file: '', line: null, col: null, message: errMatch[1] }); continue; }
      const warnMatch = line.match(/^warning(?:\[.+?\])?: (.+)/);
      if (warnMatch) { warnings.push({ file: '', line: null, col: null, message: warnMatch[1] }); continue; }
    }

    if (type === 'go') {
      const goMatch = line.match(/^\.?\/?(.+?):(\d+):(\d+):\s*(.+)/);
      if (goMatch) {
        const entry = { file: goMatch[1], line: _int(goMatch[2]), col: _int(goMatch[3]), message: goMatch[4] };
        if (goMatch[4].includes('error')) errors.push(entry);
        else warnings.push(entry);
        continue;
      }
    }

    // GCC/Make generic: path:line:col: error/warning: message
    const gccMatch = line.match(/^(.+?):(\d+):(\d+):\s*(error|warning):\s*(.+)/);
    if (gccMatch) {
      const entry = { file: gccMatch[1], line: _int(gccMatch[2]), col: _int(gccMatch[3]), message: gccMatch[5] };
      if (gccMatch[4] === 'error') errors.push(entry);
      else warnings.push(entry);
    }
  }

  return { errors, warnings };
}

function _int(s) { return s ? parseInt(s, 10) : null; }

// ─── Tool Definition ───────────────────────────────────────────────────────

module.exports = defineTool({
  name: 'build_project',
  description: 'Detect project type and run build command, returning structured errors/warnings. Supports Node.js, Rust, Go, Make, CMake, Gradle, Maven.',
  category: 'execution',
  risk: 'medium',
  isReadOnly: false,
  isConcurrencySafe: false,

  inputSchema: {
    cwd: { type: 'string', required: false, description: 'Project directory (defaults to process.cwd)' },
    command: { type: 'string', required: false, description: 'Override build command' },
    timeout: { type: 'number', required: false, description: 'Idle timeout in ms (default 120000)' },
    idleTimeout: { type: 'number', required: false, description: 'Alias of timeout; idle timeout in ms' },
  },

  getActivityDescription(input) {
    return `Building project${input?.cwd ? ' in ' + input.cwd : ''}`;
  },

  async execute(params, context = {}) {
    const cwd = params.cwd || process.cwd();
    const idleTimeoutMs = Math.max(
      50,
      parseInt(
        String(params.idleTimeout || params.timeout || process.env.KHY_BUILD_IDLE_TIMEOUT_MS || '120000'),
        10
      ) || 120000
    );
    const startMs = Date.now();

    // Detect or use override
    const detected = _detectProject(cwd);
    const command = params.command || (detected ? detected.command : null);
    const projectType = detected ? detected.type : 'unknown';

    if (!command) {
      return {
        success: false,
        error: `No build configuration found in ${cwd}. Provide a command or ensure a build file exists.`,
      };
    }

    const traceCtx = (context && context.traceContext && typeof context.traceContext === 'object')
      ? context.traceContext
      : {};
    const spawnEnv = {
      ...process.env,
      ...(traceCtx.env || {}),
      FORCE_COLOR: '0',
      NO_COLOR: '1',
    };

    const isWin = process.platform === 'win32';
    const shellBin = isWin ? (process.env.ComSpec || 'cmd.exe') : '/bin/bash';
    const shellArgs = isWin ? ['/d', '/s', '/c', command] : ['-lc', command];
    const label = `build_project:${projectType}`;

    let stdout = '';
    let stderr = '';
    let exitCode = 0;
    let totalOutBytes = 0;
    let totalErrBytes = 0;
    const maxCaptureBytes = 10 * 1024 * 1024;

    try {
      const result = await spawnWithIdleTimeout(shellBin, shellArgs, {
        idleMs: idleTimeoutMs,
        spawnOpts: {
          cwd,
          env: spawnEnv,
          windowsHide: true,
        },
        label,
        onActivity: (payload) => {
          if (typeof context?.onActivity === 'function') {
            try { context.onActivity({ tool: 'build_project', projectType, ...payload }); } catch { /* non-critical */ }
          }
        },
        onStdoutChunk: (chunk) => {
          totalOutBytes += Buffer.byteLength(String(chunk || ''), 'utf8');
          if (typeof context?.onProgress === 'function') {
            try { context.onProgress(`build_project stdout ${Math.round(totalOutBytes / 1024)}KB`); } catch { /* non-critical */ }
          }
        },
        onStderrChunk: (chunk) => {
          totalErrBytes += Buffer.byteLength(String(chunk || ''), 'utf8');
          if (typeof context?.onProgress === 'function') {
            try { context.onProgress(`build_project stderr ${Math.round(totalErrBytes / 1024)}KB`); } catch { /* non-critical */ }
          }
        },
      });
      exitCode = Number.isFinite(result.code) ? result.code : 0;
      stdout = result.stdout || '';
      stderr = result.stderr || '';
    } catch (err) {
      exitCode = 1;
      stderr = String(err && err.message ? err.message : err || 'build_project failed');
    }

    const combined = stdout + '\n' + stderr;
    const capped = combined.length > maxCaptureBytes
      ? `${combined.slice(0, maxCaptureBytes)}\n... [truncated]`
      : combined;
    const { errors, warnings } = _parseErrors(capped, projectType);
    const outputLines = capped.split('\n');
    const tail = outputLines.slice(-50).join('\n');

    return {
      success: exitCode === 0,
      data: {
        projectType,
        command,
        exitCode,
        idleTimeoutMs,
        errors,
        warnings,
        errorCount: errors.length,
        warningCount: warnings.length,
        durationMs: Date.now() - startMs,
        outputTail: tail.slice(0, 5000),
      },
    };
  },
});
