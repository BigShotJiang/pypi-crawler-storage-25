/**
 * AI Gateway Admin REST API + SSE endpoints.
 *
 * Mounted at /api/ai-gateway in the main Express app.
 *
 * Endpoints:
 *   GET  /status              — Full gateway status
 *   GET  /pool                — API key pool status per provider
 *   POST /pool/:provider/keys — Add a key
 *   DELETE /pool/:provider/keys/:keyId — Remove a key
 *   GET  /monitor/traces      — Query traces
 *   GET  /monitor/stats       — Aggregated stats
 *   GET  /monitor/stream      — SSE real-time trace stream
 *   GET  /oauth/status        — OAuth token status
 *   POST /oauth/:provider/refresh — Force refresh
 *   GET  /plugins             — List gateway plugins
 *   POST /plugins/:name/toggle — Enable/disable plugin
 *   GET  /tls/status          — TLS sidecar status
 *   POST /tls/start           — Start sidecar
 *   POST /tls/stop            — Stop sidecar
 *   GET  /protocols           — Supported protocols
 *   GET  /slots               — Concurrency slot status
 *   GET  /health              — Channel health snapshot (Redis-backed)
 *   GET  /health/stream       — SSE real-time channel health updates
 */
const express = require('express');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const router = express.Router();

// All routes require admin authentication
router.use(authenticateToken, requireAdmin);

// ── Status ──

router.get('/status', async (req, res) => {
  try {
    const gateway = require('../services/gateway/aiGateway');
    if (!gateway._initialized) await gateway.init();
    const statuses = gateway.getStatus();
    const active = gateway.getActiveAdapter();
    res.json({ adapters: statuses, active: active ? { name: active.name, type: active.type } : null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Pool ──

router.get('/pool', (req, res) => {
  try {
    const pool = require('../services/apiKeyPool');
    pool.init();
    res.json(pool.getAllStatus());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/pool/:provider/keys', (req, res) => {
  try {
    const pool = require('../services/apiKeyPool');
    pool.init();
    const { key, endpoint, priority, label } = req.body;
    if (!key) return res.status(400).json({ error: 'key is required' });
    pool.addKey(req.params.provider, { key, endpoint, priority: priority || 10, label: label || '' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/pool/:provider/keys/:keyId', (req, res) => {
  try {
    const pool = require('../services/apiKeyPool');
    pool.init();
    pool.removeKey(req.params.provider, req.params.keyId);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Monitor ──

router.get('/monitor/traces', (req, res) => {
  try {
    const monitor = require('../services/aiMonitor');
    const { limit, offset, provider, success, since } = req.query;
    const filter = {};
    if (limit) filter.limit = parseInt(limit, 10);
    if (offset) filter.offset = parseInt(offset, 10);
    if (provider) filter.provider = provider;
    if (success !== undefined) filter.success = success === 'true';
    if (since) filter.since = since;
    res.json(monitor.getTraces(filter));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/monitor/stats', (req, res) => {
  try {
    const monitor = require('../services/aiMonitor');
    res.json(monitor.getStats());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/monitor/stream', (req, res) => {
  const monitor = require('../services/aiMonitor');
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
  });

  const events = monitor.createEventStream();
  const onTrace = (trace) => {
    res.write(`data: ${JSON.stringify(trace)}\n\n`);
  };

  events.on('trace:start', onTrace);
  events.on('trace:end', onTrace);
  events.on('trace:cascade', onTrace);

  req.on('close', () => {
    events.removeListener('trace:start', onTrace);
    events.removeListener('trace:end', onTrace);
    events.removeListener('trace:cascade', onTrace);
  });
});

// ── OAuth ──

router.get('/oauth/status', (req, res) => {
  try {
    const oauth = require('../services/gateway/oauthManager');
    oauth.init();
    res.json(oauth.getAllStatus());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/oauth/:provider/refresh', async (req, res) => {
  try {
    const oauth = require('../services/gateway/oauthManager');
    oauth.init();
    const token = await oauth.refreshToken(req.params.provider);
    res.json({ success: !!token, token: token ? '***' : null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Plugins ──

router.get('/plugins', (req, res) => {
  try {
    const chain = require('../services/gateway/pluginChain');
    res.json(chain.list());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/plugins/:name/toggle', (req, res) => {
  try {
    const chain = require('../services/gateway/pluginChain');
    const { enabled } = req.body;
    const success = chain.toggle(req.params.name, enabled !== false);
    res.json({ success });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── TLS Sidecar ──

router.get('/tls/status', (req, res) => {
  try {
    const sidecar = require('../services/gateway/tlsSidecar');
    res.json(sidecar.getStatus());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/tls/start', async (req, res) => {
  try {
    const sidecar = require('../services/gateway/tlsSidecar');
    const result = await sidecar.start(req.body || {});
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/tls/stop', async (req, res) => {
  try {
    const sidecar = require('../services/gateway/tlsSidecar');
    await sidecar.stop();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Protocols ──

router.get('/protocols', (req, res) => {
  try {
    const converter = require('../services/gateway/protocolConverter');
    res.json({ protocols: converter.getSupportedProtocols() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Concurrency Slots ──

router.get('/slots', (req, res) => {
  try {
    const slots = require('../services/concurrencySlots');
    res.json(slots.getAllStatus());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Channel Health (Redis-backed) ──

router.get('/health', async (req, res) => {
  try {
    const gateway = require('../services/gateway/aiGateway');
    if (!gateway._initialized) await gateway.init();
    const broadcaster = gateway._healthBroadcaster;
    if (!broadcaster) return res.json({ adapters: [], activity: [], timestamp: Date.now() });
    const snapshot = await broadcaster.getSnapshot();
    snapshot.activity = broadcaster.getRecentActivity();
    res.json(snapshot);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/health/stream', async (req, res) => {
  // SSE endpoint for real-time channel health updates
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
  });

  const send = (event, data) => {
    try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); } catch {}
  };

  try {
    const gateway = require('../services/gateway/aiGateway');
    if (!gateway._initialized) await gateway.init();
    const broadcaster = gateway._healthBroadcaster;

    if (!broadcaster) {
      send('error', { message: 'Health broadcaster not available' });
      return res.end();
    }

    // Send initial snapshot
    const snapshot = await broadcaster.getSnapshot();
    send('channel_health', snapshot);

    // Subscribe to health changes
    const onHealth = (snap) => send('channel_health', snap);
    broadcaster.onHealthChange(onHealth);

    // Keep-alive heartbeat
    const hb = setInterval(() => send('heartbeat', { ts: Date.now() }), 15000);
    if (hb.unref) hb.unref();

    req.on('close', () => {
      clearInterval(hb);
      // Remove listener (best effort — array filter)
      const idx = broadcaster._listeners.indexOf(onHealth);
      if (idx >= 0) broadcaster._listeners.splice(idx, 1);
    });
  } catch (err) {
    send('error', { message: err.message });
    res.end();
  }
});

module.exports = router;
