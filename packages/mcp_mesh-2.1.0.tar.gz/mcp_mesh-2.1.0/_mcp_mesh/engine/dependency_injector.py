"""
Dynamic dependency injection system for MCP Mesh.

Handles both initial injection and runtime updates when topology changes.
Focused purely on dependency injection - telemetry/tracing is handled at
the HTTP middleware layer for unified approach across MCP agents and FastAPI apps.
"""

import asyncio
import functools
import inspect
import logging
import weakref
from collections.abc import Callable, Iterable
from typing import Any, Optional

from ..shared.logging_config import (
    format_log_value,
    format_result_summary,
    get_trace_prefix,
)
from .signature_analyzer import get_mesh_agent_positions, has_llm_agent_parameter

logger = logging.getLogger(__name__)

# Internal parameter name used to receive FastMCP's auto-injected ``Context``
# in streaming wrappers. Must NOT collide with anything a user could plausibly
# declare on their own ``@mesh.tool`` function.
#
# Why not just call it ``ctx``? Users routinely declare ``ctx`` themselves —
# in particular ``@mesh.llm(context_param="ctx", ...)`` is the natural default
# and pairs with ``ctx: SomeContextModel`` on the function. If we synthesize a
# parameter with the same NAME but a different TYPE (``Context``), FastMCP's
# ``transform_context_annotations`` reads the user's annotation, doesn't see
# ``Context``, and silently never injects — streaming then degrades to a
# buffered single-chunk response. The ``_mesh_`` prefix signals "framework
# internal, don't touch" and avoids any realistic collision.
_MESH_PROGRESS_CTX_PARAM = "_mesh_progress_ctx"

# Cached convention for ctx.report_progress; resolved lazily per FastMCP
# version. Newer FastMCP exposes a ``message`` kwarg; older builds only accept
# ``(progress, total)`` positionally with a third positional ``message``.
_REPORT_PROGRESS_CONVENTION: Optional[str] = None


def _resolve_report_progress_convention(report_progress: Callable) -> str:
    """Detect whether ``ctx.report_progress`` accepts ``message`` as a kwarg.

    Returns ``"kwarg"`` when the bound method advertises a ``message``
    parameter; otherwise ``"positional"`` (fall back to passing the chunk as
    the third positional argument). Cached after the first probe.
    """
    global _REPORT_PROGRESS_CONVENTION
    if _REPORT_PROGRESS_CONVENTION is not None:
        return _REPORT_PROGRESS_CONVENTION
    try:
        sig = inspect.signature(report_progress)
        if "message" in sig.parameters:
            _REPORT_PROGRESS_CONVENTION = "kwarg"
        else:
            _REPORT_PROGRESS_CONVENTION = "positional"
    except (TypeError, ValueError):
        _REPORT_PROGRESS_CONVENTION = "positional"
    return _REPORT_PROGRESS_CONVENTION


async def _forward_chunk(ctx: Any, index: int, chunk: str) -> None:
    """Send a streaming chunk to the MCP client via ``ctx.report_progress``.

    No-ops gracefully when ``ctx`` is None (caller did not pass a
    ``progressToken``) or when the report itself fails — a transport hiccup
    must not abort the rest of the stream.
    """
    if ctx is None:
        return
    report = getattr(ctx, "report_progress", None)
    if report is None:
        return
    try:
        if _resolve_report_progress_convention(report) == "kwarg":
            await report(index, None, message=chunk)
        else:
            await report(index, None, chunk)
    except Exception as e:
        logger.debug(
            "stream wrapper: ctx.report_progress failed at index %d: %s", index, e
        )


def _is_stream_tool(func: Callable) -> bool:
    """True iff the user function should be wrapped as a streaming tool.

    Combines two signals: the metadata stamped by ``@mesh.tool`` /
    ``@mesh.llm`` (``stream_type == "text"``) and the runtime check
    ``inspect.isasyncgenfunction``. Either alone is sufficient — the
    metadata covers ``async def f() -> Stream[str]: yield ...`` (which is
    an async-generator function) and also any callable returning an async
    iterator (e.g. a coroutine that constructs and returns one).
    """
    if inspect.isasyncgenfunction(func):
        return True
    meta = getattr(func, "_mesh_tool_metadata", None)
    if isinstance(meta, dict) and meta.get("stream_type") == "text":
        return True
    return False


def _build_stream_signature(func: Callable) -> inspect.Signature:
    """Construct the FastMCP-facing signature for a streaming wrapper.

    Starts from the user function's clean signature (McpMeshTool /
    MeshLlmAgent params already removed) and appends a keyword-only
    ``_mesh_progress_ctx: Context | None = None`` so FastMCP's
    ``transform_context_annotations`` auto-fills it at call time without
    exposing it on the tool's input schema.

    The parameter is intentionally NOT named ``ctx``: users can (and often
    do) have their own ``ctx`` parameter — typically a ``MeshContextModel``
    paired with ``@mesh.llm(context_param="ctx", ...)``. Reusing the name
    would silently disable streaming because FastMCP injects ``Context``
    by type annotation, and the user's annotation wins. See
    ``_MESH_PROGRESS_CTX_PARAM`` for the full rationale.
    """
    from fastmcp import Context

    base = _build_clean_signature(func)
    if base is None:
        try:
            base = inspect.signature(func)
        except (TypeError, ValueError):
            base = inspect.Signature(parameters=[])

    # Idempotency: if we've already augmented this signature once, don't add
    # the synthesized parameter twice. (User parameters cannot collide with
    # the ``_mesh_`` prefix unless they're deliberately poking at internals.)
    if _MESH_PROGRESS_CTX_PARAM in base.parameters:
        return base

    params = list(base.parameters.values())
    ctx_param = inspect.Parameter(
        _MESH_PROGRESS_CTX_PARAM,
        kind=inspect.Parameter.KEYWORD_ONLY,
        default=None,
        annotation=Optional[Context],
    )
    return base.replace(parameters=params + [ctx_param])


def _make_stream_wrapper(
    func: Callable,
    mesh_positions: list[int],
    dependencies: list[str],
    get_dependency_fn: Callable[[str], Any | None],
    log: logging.Logger,
) -> Callable:
    """Build a wrapper that drives an async-iterator tool over MCP progress.

    FastMCP auto-fills ``Context`` for any tool parameter annotated with
    it. We declare that parameter under the internal name
    ``_mesh_progress_ctx`` (see ``_MESH_PROGRESS_CTX_PARAM``) so it cannot
    collide with the user's own ``ctx`` parameter. The wrapper pops it out
    of ``**kwargs`` and never forwards it to the user function. Each chunk
    yielded by the user function is forwarded via ``ctx.report_progress``
    as a progress notification, then accumulated; the final return value
    is the concatenated text so non-streaming consumers still get the full
    response in the ``CallToolResult``.

    Cancellation by the consumer propagates back to the user function via
    ``gen.aclose()`` so generators can run their ``finally`` blocks.
    """
    # Imported for side-effect of validating fastmcp is installed; the
    # actual Context type is referenced in the synthesized signature.
    from fastmcp import Context  # noqa: F401

    @functools.wraps(func)
    async def stream_wrapper(*args, **kwargs):
        # FastMCP injects its Context under our internal name; pop it so
        # it never leaks into the user function's kwargs.
        progress_ctx = kwargs.pop(_MESH_PROGRESS_CTX_PARAM, None)

        final_kwargs, injected_count = _prepare_injection_kwargs(
            func,
            kwargs,
            mesh_positions,
            dependencies,
            stream_wrapper._mesh_injected_deps,
            get_dependency_fn,
            log,
        )

        original = func._mesh_original_func

        if inspect.isasyncgenfunction(original):
            gen = original(*args, **final_kwargs)
        else:
            produced = original(*args, **final_kwargs)
            if inspect.iscoroutine(produced):
                produced = await produced
            gen = produced

        if not hasattr(gen, "__aiter__"):
            raise TypeError(
                f"Stream tool '{func.__name__}' did not return an async iterator "
                f"(got {type(gen).__name__})."
            )

        chunks: list[str] = []
        index = 0
        try:
            async for chunk in gen:
                if not isinstance(chunk, str):
                    raise TypeError(
                        f"Stream tool '{func.__name__}' yielded non-str chunk "
                        f"of type {type(chunk).__name__}; v1 supports str only."
                    )
                chunks.append(chunk)
                await _forward_chunk(progress_ctx, index, chunk)
                index += 1
        except asyncio.CancelledError:
            aclose = getattr(gen, "aclose", None)
            if aclose is not None:
                try:
                    await aclose()
                except Exception as e:
                    log.debug(
                        f"stream wrapper: aclose() failed during cancel: {e}"
                    )
            raise

        result = "".join(chunks)
        _log_wrapper_result(func, result, log)
        return result

    return stream_wrapper


def _build_clean_signature(func: Any) -> inspect.Signature | None:
    """Build a signature excluding McpMeshTool and MeshJob parameters.

    Uses type-based detection (not position-based) to avoid false positives
    from the injector heuristic that treats single/non-typed params as targets.

    Excludes both McpMeshTool and MeshJob (Phase 1 substrate) so neither
    framework-injected slot appears in the FastMCP-visible signature —
    otherwise FastMCP advertises them as user-callable args. MeshLlmAgent
    is excluded by the @mesh.llm decorator's own __signature__ override.

    Returns None if no parameters need removal.

    Errors:
        :class:`ValueError` from :func:`analyze_mesh_job_signature` is
        intentionally allowed to propagate. Per
        ``MESHJOB_DDDI_CONTRACT.md`` ("Multiple MeshJob params"), the
        resolver MUST reject a function with more than one ``MeshJob``
        parameter at registration / decoration time with a clear
        message. Swallowing it here would mean a misuse silently
        decorates and the user only sees a cryptic ``AttributeError``
        on first invocation. Other inspection failures (forward refs,
        broken signatures) still fall through to ``return None`` so the
        decorator path is unaffected.
    """
    from .signature_analyzer import (
        _get_original_func,
        analyze_mesh_job_signature,
        get_mesh_agent_parameter_names,
    )

    # Respect explicit ``__signature__`` overrides. Decorators (e.g.
    # ``@mesh.a2a_consumer``) may stamp a curated signature on their wrapper
    # to hide framework-injected parameters from FastMCP/Pydantic schema
    # introspection. Per Python convention, ``__signature__`` wins over
    # signature-from-source rebuilds — treat it as authoritative and skip
    # the rebuild path so we don't re-introduce the hidden params by
    # peeling back to the user's raw function via ``_get_original_func``.
    sig_override = getattr(func, "__signature__", None)
    if isinstance(sig_override, inspect.Signature):
        return sig_override

    try:
        original = _get_original_func(func)
        injectable_names = set(get_mesh_agent_parameter_names(original))
    except (TypeError, AttributeError):
        # Inspection failure on the user's function (e.g. a built-in or a
        # callable without a signature). Not a contract violation; fall
        # back to "no clean signature" so the wrapper uses the original.
        return None

    # Phase 1 MeshJob substrate: also strip the MeshJob slot so it
    # doesn't surface in FastMCP's tools/list schema as a user arg.
    # ``analyze_mesh_job_signature`` may raise ``ValueError`` when the
    # user declares multiple MeshJob parameters — we let that propagate
    # so @mesh.tool fails loudly at decoration time per the contract.
    mj = analyze_mesh_job_signature(original)
    if mj.mesh_job_param_name:
        injectable_names.add(mj.mesh_job_param_name)

    if not injectable_names:
        return None
    try:
        sig = inspect.signature(original)
    except (TypeError, ValueError):
        return None
    clean_params = [
        param
        for name, param in sig.parameters.items()
        if name not in injectable_names
    ]
    return sig.replace(parameters=clean_params)


def analyze_injection_strategy(func: Callable, dependencies: list[str]) -> list[int]:
    """
    Analyze function signature and determine injection strategy.

    Rules:
    1. Single parameter: inject regardless of typing (with warning if not McpMeshTool)
    2. Multiple parameters: only inject into McpMeshTool typed parameters
    3. Log warnings for mismatches and edge cases

    Args:
        func: Function to analyze
        dependencies: List of dependency names to inject

    Returns:
        List of parameter positions to inject into
    """
    sig = inspect.signature(func)
    params = list(sig.parameters.values())
    param_count = len(params)
    mesh_positions = get_mesh_agent_positions(func)
    func_name = f"{func.__module__}.{func.__qualname__}"

    # No parameters at all
    if param_count == 0:
        if dependencies:
            logger.warning(
                f"Function '{func_name}' has no parameters but {len(dependencies)} "
                f"dependencies declared. Skipping injection."
            )
        return []

    # Single parameter rule: inject regardless of typing
    if param_count == 1:
        if not mesh_positions:
            param_name = params[0].name
            logger.warning(
                f"Single parameter '{param_name}' in function '{func_name}' found, "
                f"injecting {dependencies[0] if dependencies else 'dependency'} proxy "
                f"(consider typing as McpMeshTool for clarity)"
            )
        return [0]  # Inject into the single parameter

    # Multiple parameters rule: only inject into McpMeshTool typed parameters
    if param_count > 1:
        if not mesh_positions:
            # Phase 1 MeshJob substrate: a function may declare a MeshJob
            # param without any McpMeshTool params — that's the consumer
            # pattern (commission a remote job). Don't shout WARNING in
            # that case; the MeshJob slot is wired by ``_prepare_injection_kwargs``
            # via a different code path.
            has_mesh_job_param = False
            try:
                from .signature_analyzer import analyze_mesh_job_signature

                _mj = analyze_mesh_job_signature(func)
                has_mesh_job_param = _mj.mesh_job_param_name is not None
            except Exception:
                pass

            if has_mesh_job_param:
                logger.debug(
                    f"Function '{func_name}' declares a MeshJob param but no "
                    f"McpMeshTool params; injection of {len(dependencies)} "
                    f"declared dependency(ies) will be handled via the "
                    f"MeshJob auto-injection path."
                )
            else:
                logger.warning(
                    f"⚠️ Function '{func_name}' has {param_count} parameters but none are "
                    f"typed as McpMeshTool. Skipping injection of {len(dependencies)} dependencies. "
                    f"Consider typing dependency parameters as McpMeshTool."
                )
            return []

        # Check for dependency/parameter count mismatches
        if len(dependencies) != len(mesh_positions):
            if len(dependencies) > len(mesh_positions):
                excess_deps = dependencies[len(mesh_positions) :]
                logger.warning(
                    f"Function '{func_name}' has {len(dependencies)} dependencies "
                    f"but only {len(mesh_positions)} McpMeshTool parameters. "
                    f"Dependencies {excess_deps} will not be injected."
                )
            else:
                excess_params = [
                    params[pos].name for pos in mesh_positions[len(dependencies) :]
                ]
                logger.warning(
                    f"Function '{func_name}' has {len(mesh_positions)} McpMeshTool parameters "
                    f"but only {len(dependencies)} dependencies declared. "
                    f"Parameters {excess_params} will remain None."
                )

        # Return positions we can actually inject into
        return mesh_positions[: len(dependencies)]

    return mesh_positions


def _prepare_injection_kwargs(
    func: Callable,
    kwargs: dict,
    mesh_positions: list[int],
    dependencies: list[str],
    injected_deps_array: list,
    get_dependency_fn: Callable[[str], Any | None],
    log: logging.Logger,
) -> tuple[dict, int]:
    """Prepare kwargs with injected dependencies and LLM agent.

    This contains the shared logic between async and sync dependency wrappers:
    dependency resolution, LLM agent injection, and invocation logging.

    Args:
        func: The original function being wrapped
        kwargs: Caller-supplied keyword arguments
        mesh_positions: Parameter positions that accept mesh dependencies
        dependencies: Dependency names declared on the function
        injected_deps_array: Wrapper's mutable array of cached dependency instances
        get_dependency_fn: Fallback lookup for dependencies not in the array
        log: Logger instance for debug output

    Returns:
        Tuple of (final_kwargs dict ready for invocation, injected_count)
    """
    tp = get_trace_prefix()

    # Log tool invocation
    arg_keys = list(kwargs.keys()) if kwargs else []
    log.debug(f"{tp}🔧 Tool '{func.__name__}' called with kwargs={arg_keys}")
    log.debug(f"{tp}🔧 Tool '{func.__name__}' args: {format_log_value(kwargs)}")

    # Build final kwargs with injected dependencies
    sig = inspect.signature(func)
    params = list(sig.parameters.keys())
    final_kwargs = kwargs.copy()

    injected_count = 0
    injected_deps: list[str] = []

    for dep_index, param_position in enumerate(mesh_positions):
        if dep_index < len(dependencies):
            dep_name = dependencies[dep_index]
            param_name = params[param_position]

            if param_name not in final_kwargs or final_kwargs.get(param_name) is None:
                dependency = None
                if dep_index < len(injected_deps_array):
                    dependency = injected_deps_array[dep_index]

                if dependency is None:
                    dep_key = f"{func.__module__}.{func.__qualname__}:dep_{dep_index}"
                    dependency = get_dependency_fn(dep_key)

                final_kwargs[param_name] = dependency
                injected_count += 1
                proxy_type = type(dependency).__name__ if dependency else "None"
                injected_deps.append(f"{dep_name} → {proxy_type}")

    if injected_count > 0:
        log.debug(
            f"{tp}🔧 Injected {injected_count} dependencies: {', '.join(injected_deps)}"
        )

    # Inject LLM agent if the function has @mesh.llm metadata
    if hasattr(func, "_mesh_llm_param_name"):
        llm_param = func._mesh_llm_param_name
        if llm_param not in final_kwargs or final_kwargs.get(llm_param) is None:
            llm_agent = getattr(func, "_mesh_llm_agent", None)
            final_kwargs[llm_param] = llm_agent
            log.debug(f"{tp}🤖 LLM_INJECTION: Injected {llm_param}={llm_agent}")

    # Phase 1 MeshJob substrate: consumer-side injection.
    # If the function declares a MeshJob-typed parameter whose name matches
    # one of its declared dependency capabilities, inject a
    # MeshJobSubmitter for that capability so the consumer can call
    # ``await submitter.submit(...)``. Per the resolver contract
    # (MESHJOB_DDDI_CONTRACT.md), MeshJob params are orthogonal to
    # McpMeshTool position-indexing — they're identified by name, not slot.
    try:
        from .signature_analyzer import analyze_mesh_job_signature

        # Use _mesh_original_func if present (set by injection wrapper) so
        # we read the user's source-level annotations, not the wrapper's.
        sig_target = getattr(func, "_mesh_original_func", func)
        resolution = analyze_mesh_job_signature(sig_target)
        mesh_job_param = resolution.mesh_job_param_name
    except Exception as e:
        log.debug(f"{tp}MeshJob analysis skipped for {func.__name__}: {e}")
        mesh_job_param = None

    if mesh_job_param and mesh_job_param in dependencies:
        # Only inject when the slot is currently empty / None — preserves
        # the test-friendly contract that callers can pass an explicit
        # MeshJob (e.g. a fake) and bypass the framework's auto-wiring.
        if (
            mesh_job_param not in final_kwargs
            or final_kwargs.get(mesh_job_param) is None
        ):
            from .mesh_job_submitter import MeshJobSubmitter
            import os as _os

            from .decorator_registry import DecoratorRegistry

            registry_url = _os.environ.get("MCP_MESH_REGISTRY_URL")
            # Single source of truth: the same DecoratorRegistry-resolved
            # agent_id that the heartbeat registers, the claim worker
            # sends on POST /jobs/claim, and the JobController stamps on
            # batch deltas. Reading from it here means submitted_by
            # lines up exactly with the eventual claim's
            # owner_instance_id when this agent submits to itself.
            instance_id = "unknown"
            try:
                cfg = DecoratorRegistry.get_resolved_agent_config()
                if isinstance(cfg, dict):
                    candidate = cfg.get("agent_id")
                    if candidate:
                        instance_id = candidate
            except Exception as exc:
                log.debug(
                    f"{tp}MeshJob param {mesh_job_param!r}: DecoratorRegistry "
                    f"agent_id lookup failed ({exc}); using 'unknown'"
                )
            if registry_url:
                submitter = MeshJobSubmitter(
                    capability=mesh_job_param,
                    submitted_by=instance_id,
                    registry_url=registry_url,
                )
                final_kwargs[mesh_job_param] = submitter
                log.debug(
                    f"{tp}📨 MESH_JOB_INJECTION: Injected MeshJobSubmitter "
                    f"for capability={mesh_job_param!r}"
                )
            else:
                log.warning(
                    f"{tp}MeshJob param {mesh_job_param!r} on {func.__name__} "
                    f"could not be wired: MCP_MESH_REGISTRY_URL not set"
                )

    return final_kwargs, injected_count


def _log_wrapper_result(func: Callable, result: Any, log: logging.Logger) -> None:
    """Log the result of a dependency-injected function call."""
    tp = get_trace_prefix()
    log.debug(
        f"{tp}🔧 Tool '{func.__name__}' returned: {format_result_summary(result)}"
    )
    log.debug(f"{tp}🔧 Tool '{func.__name__}' result: {format_log_value(result)}")


class DependencyInjector:
    """
    Manages dynamic dependency injection for mesh agents.

    This class:
    1. Maintains a registry of available dependencies (McpMeshTool)
    2. Coordinates with MeshLlmAgentInjector for LLM agent injection
    3. Tracks which functions depend on which services
    4. Updates function bindings when topology changes
    5. Handles graceful degradation when dependencies unavailable
    """

    def __init__(self):
        self._dependencies: dict[str, Any] = {}
        self._function_registry: weakref.WeakValueDictionary = (
            weakref.WeakValueDictionary()
        )
        self._dependency_mapping: dict[str, set[str]] = (
            {}
        )  # dep_name -> set of function_ids
        self._lock = asyncio.Lock()

        # LLM agent injector for MeshLlmAgent parameters
        from .mesh_llm_agent_injector import get_global_llm_injector

        self._llm_injector = get_global_llm_injector()
        logger.debug("🤖 DependencyInjector initialized with MeshLlmAgentInjector")

    def iter_dependency_keys(self) -> Iterable[str]:
        """Iterate over all currently-registered dependency keys.

        Each key has the shape ``"<module>.<qualname>:dep_<N>"`` where
        ``<module>`` is the fully-qualified module path the @mesh.tool
        decorator observed when the dependency was registered.

        Used by startup-time consistency checks (e.g.
        :class:`DualModuleCheckStep`) that need to inspect registrations
        across all modules. Public so callers don't depend on the private
        storage layout of the injector.

        The returned view reflects live mutations to the underlying mapping —
        callers that need a stable snapshot (e.g., for iteration that may
        overlap with register_dependency / unregister_dependency calls) should
        materialize via list(...) or tuple(...) explicitly.
        """
        return self._dependency_mapping.keys()

    async def register_dependency(self, name: str, instance: Any) -> None:
        """Register a new dependency or update existing one.

        Args:
            name: Composite key in format "function_id:dep_N" or legacy capability name
            instance: Proxy instance to register
        """
        async with self._lock:
            logger.debug(f"📦 Registering dependency: {name}")
            self._dependencies[name] = instance

            # Notify all functions that depend on this (using composite keys)
            if name in self._dependency_mapping:
                for func_id in self._dependency_mapping[name]:
                    if func_id in self._function_registry:
                        func = self._function_registry[func_id]
                        logger.debug(
                            f"🔄 UPDATING dependency '{name}' for {func_id} -> {func} at {hex(id(func))}"
                        )
                        if hasattr(func, "_mesh_update_dependency"):
                            # Extract dep_index from composite key (format: "function_id:dep_N")
                            if ":dep_" in name:
                                dep_index_str = name.split(":dep_")[-1]
                                try:
                                    dep_index = int(dep_index_str)
                                    func._mesh_update_dependency(dep_index, instance)
                                except ValueError:
                                    logger.warning(
                                        f"⚠️ Invalid dep_index in key '{name}', skipping update"
                                    )
                            else:
                                # Legacy format (shouldn't happen with new code)
                                logger.warning(
                                    f"⚠️ Legacy dependency key format '{name}' not supported in array-based injection"
                                )

    async def unregister_dependency(self, name: str) -> None:
        """Remove a dependency (e.g., service went down).

        Args:
            name: Composite key in format "function_id:dep_N" or legacy capability name
        """
        async with self._lock:
            logger.info(f"🗑️ INJECTOR: Unregistering dependency: {name}")
            if name in self._dependencies:
                del self._dependencies[name]
                logger.info(f"🗑️ INJECTOR: Removed {name} from dependencies registry")

                # Notify all functions that depend on this
                if name in self._dependency_mapping:
                    affected_functions = self._dependency_mapping[name]
                    logger.info(
                        f"🗑️ INJECTOR: Updating {len(affected_functions)} functions affected by {name} removal"
                    )

                    for func_id in affected_functions:
                        if func_id in self._function_registry:
                            func = self._function_registry[func_id]
                            if hasattr(func, "_mesh_update_dependency"):
                                logger.info(
                                    f"🗑️ INJECTOR: Removing {name} from function {func_id}"
                                )
                                # Extract dep_index from composite key
                                if ":dep_" in name:
                                    dep_index_str = name.split(":dep_")[-1]
                                    try:
                                        dep_index = int(dep_index_str)
                                        func._mesh_update_dependency(dep_index, None)
                                    except ValueError:
                                        logger.warning(
                                            f"⚠️ Invalid dep_index in key '{name}', skipping removal"
                                        )
                                else:
                                    # Legacy format
                                    logger.warning(
                                        f"⚠️ Legacy dependency key format '{name}' not supported in array-based injection"
                                    )
                            else:
                                logger.warning(
                                    f"🗑️ INJECTOR: Function {func_id} has no _mesh_update_dependency method"
                                )
                        else:
                            logger.warning(
                                f"🗑️ INJECTOR: Function {func_id} not found in registry"
                            )
                else:
                    logger.info(f"🗑️ INJECTOR: No functions mapped to dependency {name}")
            else:
                logger.info(f"🗑️ INJECTOR: Dependency {name} was not registered (no-op)")

    def get_dependency(self, name: str) -> Any | None:
        """Get current instance of a dependency."""
        return self._dependencies.get(name)

    def find_original_function(self, function_name: str) -> Any | None:
        """Find the original function by name from wrapper registry or decorator registry.

        This is used for self-dependency proxy creation to get the cached
        original function reference for direct calls.

        Args:
            function_name: Name of the function to find

        Returns:
            Original function if found, None otherwise
        """
        logger.debug(f"🔍 Searching for original function: '{function_name}'")

        # First, search through wrapper registry (functions with dependencies)
        for func_id, wrapper_func in self._function_registry.items():
            if hasattr(wrapper_func, "_mesh_original_func"):
                original = wrapper_func._mesh_original_func

                # Match by function name
                if hasattr(original, "__name__") and original.__name__ == function_name:
                    logger.debug(
                        f"✅ Found original function '{function_name}' in wrapper registry: {func_id}"
                    )
                    return original

        # If not found in wrapper registry, search in decorator registry (all functions)
        try:
            from .decorator_registry import DecoratorRegistry

            # Search through mesh tools (functions decorated with @mesh.tool)
            mesh_tools = DecoratorRegistry.get_mesh_tools()
            for tool_name, decorated_func in mesh_tools.items():
                original_func = decorated_func.function  # Get the original function
                if (
                    hasattr(original_func, "__name__")
                    and original_func.__name__ == function_name
                ):
                    logger.debug(
                        f"✅ Found original function '{function_name}' in decorator registry: {tool_name}"
                    )
                    return original_func

        except Exception as e:
            logger.warning(f"⚠️ Error searching decorator registry: {e}")

        # List available functions for debugging
        available_functions = []
        for wrapper_func in self._function_registry.values():
            if hasattr(wrapper_func, "_mesh_original_func"):
                original = wrapper_func._mesh_original_func
                if hasattr(original, "__name__"):
                    available_functions.append(original.__name__)

        # Also list functions from decorator registry
        try:
            from .decorator_registry import DecoratorRegistry

            mesh_tools = DecoratorRegistry.get_mesh_tools()
            for tool_name, decorated_func in mesh_tools.items():
                if hasattr(decorated_func.function, "__name__"):
                    available_functions.append(decorated_func.function.__name__)
        except (AttributeError, KeyError, TypeError):
            pass

        logger.warning(
            f"❌ Original function '{function_name}' not found. "
            f"Available functions: {list(set(available_functions))}"
        )
        return None

    def process_llm_tools(self, llm_tools: dict[str, list[dict[str, Any]]]) -> None:
        """
        Process llm_tools from registry response and delegate to MeshLlmAgentInjector.

        Args:
            llm_tools: Dict mapping function_id -> list of tool metadata
                      Format: {"function_id": [{"function_name": "...", "endpoint": {...}, ...}]}
        """
        logger.info(
            f"🤖 DependencyInjector processing llm_tools for {len(llm_tools)} functions"
        )
        self._llm_injector.process_llm_tools(llm_tools)

    def process_llm_providers(self, llm_providers: dict[str, dict[str, Any]]) -> None:
        """
        Process llm_providers from registry response and delegate to MeshLlmAgentInjector (v0.6.1).

        Args:
            llm_providers: Dict mapping function_name -> ResolvedLLMProvider
                          Format: {"function_name": {"agent_id": "...", "endpoint": "...", ...}}
        """
        logger.info(
            f"🔌 DependencyInjector processing llm_providers for {len(llm_providers)} functions"
        )
        self._llm_injector.process_llm_providers(llm_providers)

    def update_llm_tools(self, llm_tools: dict[str, list[dict[str, Any]]]) -> None:
        """
        Update llm_tools when topology changes (heartbeat updates).

        Args:
            llm_tools: Updated llm_tools dict from registry
        """
        logger.info(
            f"🔄 DependencyInjector updating llm_tools for {len(llm_tools)} functions"
        )
        self._llm_injector.update_llm_tools(llm_tools)

    def create_llm_injection_wrapper(
        self, func: Callable, function_id: str
    ) -> Callable:
        """
        Create wrapper for function with MeshLlmAgent parameter.

        Delegates to MeshLlmAgentInjector.

        Args:
            func: Function to wrap
            function_id: Unique function ID from @mesh.llm decorator

        Returns:
            Wrapped function with MeshLlmAgent injection
        """
        logger.debug(f"🤖 Creating LLM injection wrapper for {function_id}")
        return self._llm_injector.create_injection_wrapper(func, function_id)

    def create_injection_wrapper(
        self, func: Callable, dependencies: list[str]
    ) -> Callable:
        """
        Create in-place dependency injection by modifying the original function.

        This approach:
        1. Preserves the original function pointer for FastMCP
        2. Adds dynamic dependency injection capability
        3. Can be updated when topology changes
        4. Handles missing dependencies gracefully
        5. Logs warnings for configuration issues
        """
        func_id = f"{func.__module__}.{func.__qualname__}"

        # Use new smart injection strategy
        mesh_positions = analyze_injection_strategy(func, dependencies)

        # Track which dependencies this function needs (using composite keys)
        for dep_index, dep in enumerate(dependencies):
            dep_key = f"{func_id}:dep_{dep_index}"
            if dep_key not in self._dependency_mapping:
                self._dependency_mapping[dep_key] = set()
            self._dependency_mapping[dep_key].add(func_id)

        # Store current dependency values as array (indexed by position)
        if not hasattr(func, "_mesh_injected_deps"):
            func._mesh_injected_deps = [None] * len(dependencies)

        # Store original implementation if not already stored
        if not hasattr(func, "_mesh_original_func"):
            func._mesh_original_func = func

        # Create a wrapper function that handles dependency injection
        # Capture logger in local scope to avoid NameError
        wrapper_logger = logger

        is_stream = _is_stream_tool(func)

        # Phase 1 MeshJob substrate: detect if the function declares a
        # MeshJob param. If so, we must run the FULL DI path even when
        # ``mesh_positions`` is empty — otherwise ``_prepare_injection_kwargs``
        # never runs, the MeshJob auto-injection block never fires, and
        # consumer-side jobs silently lose their submitter (#bug 1).
        has_mesh_job_param = False
        try:
            from .signature_analyzer import analyze_mesh_job_signature

            _mj = analyze_mesh_job_signature(func)
            has_mesh_job_param = _mj.mesh_job_param_name is not None
        except Exception:
            pass

        # If no mesh positions to inject AND no MeshJob slot, fall back to
        # the minimal tracking wrapper. With a MeshJob slot we route to the
        # full path so the auto-injection block at line ~439 can fire.
        if not mesh_positions and not has_mesh_job_param:
            logger.debug(
                f"🔧 No injection positions for {func.__name__}, creating minimal wrapper for tracking"
            )

            if is_stream:
                minimal_wrapper = _make_stream_wrapper(
                    func,
                    mesh_positions,
                    dependencies,
                    self.get_dependency,
                    wrapper_logger,
                )
            elif inspect.iscoroutinefunction(func):

                @functools.wraps(func)
                async def minimal_wrapper(*args, **kwargs):
                    # Use ExecutionTracer for functions without dependencies (v0.4.0 style)
                    from ..tracing.execution_tracer import ExecutionTracer
                    from .job_dispatch import maybe_dispatch_as_job

                    wrapper_logger.debug(
                        f"🔧 DI: Executing async function {func.__name__} (no dependencies)"
                    )

                    # Phase 1 MeshJob substrate: wrap the user-function call in
                    # maybe_dispatch_as_job. For non-task tools this is a thin
                    # passthrough (zero overhead). For task=True tools invoked
                    # with X-Mesh-Job-Id, it binds the JobController + contexts
                    # for the duration of the call.
                    async def _invoke(kw: dict) -> Any:
                        return await ExecutionTracer.trace_function_execution_async(
                            func, args, kw, [], [], 0, wrapper_logger
                        )

                    return await maybe_dispatch_as_job(func, _invoke, kwargs)

            else:

                @functools.wraps(func)
                def minimal_wrapper(*args, **kwargs):
                    # Use ExecutionTracer for functions without dependencies (v0.4.0 style)
                    from ..tracing.execution_tracer import ExecutionTracer

                    wrapper_logger.debug(
                        f"🔧 DI: Executing sync function {func.__name__} (no dependencies)"
                    )

                    # Use original function tracer for functions without dependencies
                    return ExecutionTracer.trace_original_function(
                        func, args, kwargs, wrapper_logger
                    )

            # Add minimal metadata for compatibility (use array for consistency)
            minimal_wrapper._mesh_injected_deps = [None] * len(dependencies)
            minimal_wrapper._mesh_dependencies = dependencies
            minimal_wrapper._mesh_positions = mesh_positions
            minimal_wrapper._mesh_original_func = func

            # Override signature to hide injectable parameters from FastMCP
            if is_stream:
                minimal_wrapper.__signature__ = _build_stream_signature(func)
            else:
                clean_sig = _build_clean_signature(func)
                if clean_sig is not None:
                    minimal_wrapper.__signature__ = clean_sig

            def update_dependency(dep_index: int, instance: Any | None) -> None:
                """No-op update for functions without injection positions."""
                pass

            minimal_wrapper._mesh_update_dependency = update_dependency

            # Register this wrapper for dependency updates (even though it won't use them)
            logger.debug(
                f"🔧 REGISTERING minimal wrapper: {func_id} -> {minimal_wrapper} at {hex(id(minimal_wrapper))}"
            )
            self._function_registry[func_id] = minimal_wrapper

            return minimal_wrapper

        # Determine if we need async wrapper
        need_async_wrapper = inspect.iscoroutinefunction(func)

        if is_stream:
            dependency_wrapper = _make_stream_wrapper(
                func,
                mesh_positions,
                dependencies,
                self.get_dependency,
                wrapper_logger,
            )
        elif need_async_wrapper:

            @functools.wraps(func)
            async def dependency_wrapper(*args, **kwargs):
                final_kwargs, injected_count = _prepare_injection_kwargs(
                    func,
                    kwargs,
                    mesh_positions,
                    dependencies,
                    dependency_wrapper._mesh_injected_deps,
                    self.get_dependency,
                    wrapper_logger,
                )

                from ..tracing.execution_tracer import ExecutionTracer
                from .job_dispatch import maybe_dispatch_as_job

                # Phase 1 MeshJob substrate: wrap the user-function call in
                # maybe_dispatch_as_job. For non-task tools this is a thin
                # passthrough (zero overhead). For task=True tools invoked
                # with X-Mesh-Job-Id, it binds the JobController + contexts
                # for the duration of the call.
                async def _invoke(kw: dict) -> Any:
                    return await ExecutionTracer.trace_function_execution_async(
                        func._mesh_original_func,
                        args,
                        kw,
                        dependencies,
                        mesh_positions,
                        injected_count,
                        wrapper_logger,
                    )

                result = await maybe_dispatch_as_job(func, _invoke, final_kwargs)

                _log_wrapper_result(func, result, wrapper_logger)
                return result

        else:

            @functools.wraps(func)
            def dependency_wrapper(*args, **kwargs):
                final_kwargs, injected_count = _prepare_injection_kwargs(
                    func,
                    kwargs,
                    mesh_positions,
                    dependencies,
                    dependency_wrapper._mesh_injected_deps,
                    self.get_dependency,
                    wrapper_logger,
                )

                from ..tracing.execution_tracer import ExecutionTracer

                result = ExecutionTracer.trace_function_execution(
                    func._mesh_original_func,
                    args,
                    final_kwargs,
                    dependencies,
                    mesh_positions,
                    injected_count,
                    wrapper_logger,
                )

                _log_wrapper_result(func, result, wrapper_logger)
                return result

        # Override signature to hide injectable parameters from FastMCP schema generation
        if is_stream:
            dependency_wrapper.__signature__ = _build_stream_signature(func)
        else:
            clean_sig = _build_clean_signature(func)
            if clean_sig is not None:
                dependency_wrapper.__signature__ = clean_sig

        # Store dependency state on wrapper as array (indexed by position)
        dependency_wrapper._mesh_injected_deps = [None] * len(dependencies)

        # Add update method to wrapper (now uses index-based updates)
        def update_dependency(dep_index: int, instance: Any | None) -> None:
            """Called when a dependency changes (index-based for duplicate capability support)."""
            if dep_index < len(dependency_wrapper._mesh_injected_deps):
                dependency_wrapper._mesh_injected_deps[dep_index] = instance
                if instance is None:
                    wrapper_logger.debug(
                        f"Removed dependency at index {dep_index} from {func_id}"
                    )
                else:
                    wrapper_logger.debug(
                        f"Updated dependency at index {dep_index} for {func_id}"
                    )
                    wrapper_logger.debug(
                        f"🔗 Wrapper pointer receiving dependency: {dependency_wrapper} at {hex(id(dependency_wrapper))}"
                    )
            else:
                wrapper_logger.warning(
                    f"⚠️ Attempted to update dependency at index {dep_index} but wrapper only has {len(dependency_wrapper._mesh_injected_deps)} dependencies"
                )

        # Store update method on wrapper
        dependency_wrapper._mesh_update_dependency = update_dependency
        dependency_wrapper._mesh_dependencies = dependencies
        dependency_wrapper._mesh_positions = mesh_positions
        dependency_wrapper._mesh_original_func = func

        # Register this wrapper for dependency updates
        logger.debug(
            f"🔧 REGISTERING in function_registry: {func_id} -> {dependency_wrapper} at {hex(id(dependency_wrapper))}"
        )
        self._function_registry[func_id] = dependency_wrapper

        # Return the wrapper (which FastMCP will register)
        return dependency_wrapper


# Global injector instance
_global_injector = DependencyInjector()


def get_global_injector() -> DependencyInjector:
    """Get the global dependency injector instance."""
    return _global_injector
