"""
Rust-backed heartbeat implementation.

Replaces the Python heartbeat loop with the Rust core runtime.
The Rust core handles:
- Registry communication (HEAD/POST heartbeats)
- Topology change detection
- Event emission

Python handles:
- DI updates when topology changes
- LLM tools updates
"""

import asyncio
import json
import logging
import os
from typing import Any, Optional

logger = logging.getLogger(__name__)


def _cluster_strict_enabled() -> bool:
    """Issue #547 Phase 4: read MCP_MESH_SCHEMA_STRICT env var (cluster-wide knob).

    When true, WARN verdicts are promoted to BLOCK so ops can harden a whole
    cluster without changing every consumer.
    """
    return os.environ.get("MCP_MESH_SCHEMA_STRICT", "").strip().lower() in {
        "1",
        "true",
        "yes",
    }


def _should_refuse_startup(
    verdict: str, cluster_strict: bool, tool_strict: bool
) -> bool:
    """Issue #547 Phase 4: schema verdict policy.

    Composes two knobs:
      * cluster_strict (env MCP_MESH_SCHEMA_STRICT): promotes WARN→BLOCK.
      * tool_strict (per-tool output_schema_strict, default True): producer-side
        escape hatch. When False, BLOCK is demoted to WARN for that tool.

    Truth table:
      verdict=BLOCK + tool_strict=True  -> refuse
      verdict=BLOCK + tool_strict=False -> log only (override wins)
      verdict=WARN  + cluster_strict=True + tool_strict=True  -> refuse
      verdict=WARN  + cluster_strict=True + tool_strict=False -> log only
      verdict=WARN  + cluster_strict=False -> log only
      verdict=OK -> never refuse
    """
    if verdict == "BLOCK":
        return tool_strict
    if verdict == "WARN":
        return cluster_strict and tool_strict
    return False

# Lazy import to avoid ImportError if Rust core not built
_rust_core = None


def _get_rust_core():
    """Lazy import of Rust core module."""
    global _rust_core
    if _rust_core is None:
        try:
            import mcp_mesh_core

            _rust_core = mcp_mesh_core
            logger.debug("Rust core module loaded successfully")
        except ImportError as e:
            logger.warning(f"Rust core not available: {e}")
            raise
    return _rust_core


def _build_agent_spec(context: dict[str, Any]) -> Any:
    """
    Build AgentSpec from Python context.

    Converts the Python decorator registry state into a Rust AgentSpec.
    """
    core = _get_rust_core()

    # Get agent config from context
    agent_config = context.get("agent_config", {})
    agent_id = context.get("agent_id", "unknown-agent")

    # Get registry URL
    from ...shared.config_resolver import get_config_value

    # Default is handled by Rust core
    registry_url = get_config_value(
        "MCP_MESH_REGISTRY_URL",
        override=agent_config.get("registry_url"),
    )

    # Get heartbeat interval
    from ...shared.defaults import MeshDefaults

    heartbeat_interval = int(
        get_config_value(
            "MCP_MESH_HEALTH_INTERVAL",
            override=agent_config.get("health_interval"),
            default=MeshDefaults.HEALTH_INTERVAL,
        )
    )

    # Get HTTP config
    http_host = agent_config.get("http_host", "localhost")
    http_port = agent_config.get("http_port", 0)

    # If port=0 (auto-assign), check for detected port from server discovery
    if http_port == 0:
        existing_server = context.get("existing_server")
        if existing_server:
            detected_port = existing_server.get("port", 0)
            if detected_port > 0:
                logger.info(
                    f"Using detected port {detected_port} (agent_config had port=0)"
                )
                http_port = detected_port

    namespace = agent_config.get("namespace", "default")
    version = agent_config.get("version", "1.0.0")
    description = agent_config.get("description") or ""

    # Build tool specs from decorator registry
    from ...engine.decorator_registry import DecoratorRegistry

    tools = []
    mesh_tools = DecoratorRegistry.get_mesh_tools()
    mesh_llm_agents = DecoratorRegistry.get_mesh_llm_agents()

    # Import FastMCP schema extractor for input schema extraction
    from ...utils.fastmcp_schema_extractor import FastMCPSchemaExtractor

    # Get FastMCP server info from context (set by fastmcp-server-discovery step)
    # Convert to dict format expected by extract_from_fastmcp_servers
    fastmcp_server_info = context.get("fastmcp_server_info", [])
    fastmcp_servers = {}
    for server_info in fastmcp_server_info:
        server_name = server_info.get("server_name", "unknown")
        fastmcp_servers[server_name] = server_info
    logger.debug(
        f"FastMCP servers for schema extraction: {list(fastmcp_servers.keys())}"
    )

    cluster_strict = _cluster_strict_enabled()

    for tool_name, decorated_func in mesh_tools.items():
        tool_metadata = decorated_func.metadata or {}
        current_function = decorated_func.function
        # Issue #547 Phase 4: per-tool override (default True = current behavior).
        tool_strict = bool(tool_metadata.get("output_schema_strict", True))

        # Build dependency specs
        deps = []
        for dep_info in tool_metadata.get("dependencies", []):
            # Serialize tags to JSON to support nested arrays for OR alternatives
            # e.g., ["addition", ["python", "typescript"]] -> addition AND (python OR typescript)
            tags_json = json.dumps(dep_info.get("tags", []))

            # Issue #547 Phase 1D: normalize the consumer's expected schema
            # via the Rust normalizer (deferred from decorator time to keep
            # import cheap and consistent with producer-side normalization).
            expected_canonical: Optional[str] = None
            expected_hash: Optional[str] = None
            match_mode = dep_info.get("match_mode")
            expected_raw = dep_info.get("expected_schema_raw")
            if expected_raw is not None:
                try:
                    normalize_fn = getattr(core, "normalize_schema_py", None)
                    if normalize_fn is None:
                        raise AttributeError(
                            "normalize_schema_py not in mcp_mesh_core"
                        )
                    result = json.loads(
                        normalize_fn(json.dumps(expected_raw), "python")
                    )
                    verdict = result.get("verdict", "OK")
                    warnings_list = result.get("warnings") or []
                    # Issue #547 Phase 4: there's no per-tool override on the
                    # consumer side (the override is producer-side); use
                    # tool_strict=True so cluster_strict still promotes WARN.
                    if _should_refuse_startup(verdict, cluster_strict, True):
                        promoted = (
                            " (MCP_MESH_SCHEMA_STRICT=true upgraded WARN→BLOCK)"
                            if verdict == "WARN"
                            else ""
                        )
                        raise RuntimeError(
                            f"Schema normalization {verdict} for dependency on "
                            f"'{dep_info.get('capability', '')}'{promoted}: "
                            f"{warnings_list}. Cannot start agent."
                        )
                    if verdict == "WARN":
                        logger.warning(
                            f"Schema WARN for dependency on "
                            f"'{dep_info.get('capability', '')}': {warnings_list}"
                        )
                    if result.get("canonical"):
                        expected_canonical = json.dumps(result["canonical"])
                        expected_hash = result.get("hash")
                except RuntimeError:
                    raise
                except Exception as e:
                    logger.warning(
                        f"Could not normalize expected schema for dep "
                        f"'{dep_info.get('capability', '')}': {e}"
                    )
                    expected_canonical = None
                    expected_hash = None

            dep_spec = core.DependencySpec(
                capability=dep_info.get("capability", ""),
                tags=tags_json,
                version=dep_info.get("version"),
                expected_schema_canonical=expected_canonical,
                expected_schema_hash=expected_hash,
                match_mode=match_mode,
            )
            deps.append(dep_spec)

        # Extract input schema from FastMCP tool (like heartbeat_preparation.py)
        # This is critical for LLM tool filtering - registry requires inputSchema
        input_schema = tool_metadata.get("input_schema")
        if input_schema is None:
            # Primary method: Extract from FastMCP server tool managers
            input_schema = FastMCPSchemaExtractor.extract_from_fastmcp_servers(
                current_function, fastmcp_servers
            )
            if input_schema:
                logger.debug(
                    f"📋 Extracted inputSchema for {tool_name} from FastMCP servers: {list(input_schema.get('properties', {}).keys())}"
                )
            else:
                # Fallback: Try direct schema extraction (v2 _fastmcp_tool or v3 registry lookup)
                input_schema = FastMCPSchemaExtractor.extract_input_schema(
                    current_function
                )
                if input_schema:
                    logger.debug(
                        f"📋 Extracted inputSchema for {tool_name} via fallback: {list(input_schema.get('properties', {}).keys())}"
                    )
                else:
                    logger.warning(f"⚠️ No inputSchema found for {tool_name}")
        input_schema_json = json.dumps(input_schema) if input_schema else None

        # Issue #547: Extract output schema (best-effort, return type may not be annotated)
        output_schema = FastMCPSchemaExtractor.extract_output_schema(current_function)
        output_schema_json = json.dumps(output_schema) if output_schema else None

        # Issue #547: Normalize input + output schemas via Rust normalizer.
        # If the wheel hasn't been rebuilt to expose normalize_schema_py yet,
        # we register without schema fields so legacy environments keep working.
        input_canonical_json: Optional[str] = None
        input_hash: Optional[str] = None
        output_canonical_json: Optional[str] = None
        output_hash: Optional[str] = None
        combined_warnings: list[str] = []

        try:
            normalize_fn = getattr(core, "normalize_schema_py", None)
            if normalize_fn is None:
                raise AttributeError("normalize_schema_py not in mcp_mesh_core")

            def _apply_schema_policy(result: dict, kind: str) -> None:
                """Issue #547 Phase 4: enforce verdict policy for one schema slot.

                Mutates combined_warnings; raises RuntimeError when startup
                must be refused.
                """
                verdict = result.get("verdict", "OK")
                warnings_list = result.get("warnings") or []
                if _should_refuse_startup(verdict, cluster_strict, tool_strict):
                    promoted = (
                        " (MCP_MESH_SCHEMA_STRICT=true upgraded WARN→BLOCK)"
                        if verdict == "WARN"
                        else ""
                    )
                    raise RuntimeError(
                        f"Schema normalization {verdict} for tool "
                        f"'{tool_name}' {kind}{promoted}: {warnings_list}. "
                        "Cannot start agent."
                    )
                if verdict == "BLOCK":
                    # Demoted by per-tool override — log loudly + tag warnings.
                    logger.warning(
                        f"Schema BLOCK demoted to WARN for tool '{tool_name}' "
                        f"{kind} (output_schema_strict=False): {warnings_list}"
                    )
                    warnings_list = [
                        f"[demoted from BLOCK] {w}" for w in warnings_list
                    ]
                elif verdict == "WARN":
                    logger.warning(
                        f"Schema WARN for tool '{tool_name}' {kind}: {warnings_list}"
                    )
                combined_warnings.extend(warnings_list)

            if input_schema:
                result = json.loads(normalize_fn(json.dumps(input_schema), "python"))
                _apply_schema_policy(result, "input")
                if result.get("canonical"):
                    input_canonical_json = json.dumps(result["canonical"])
                    input_hash = result.get("hash")

            if output_schema:
                result = json.loads(normalize_fn(json.dumps(output_schema), "python"))
                _apply_schema_policy(result, "output")
                if result.get("canonical"):
                    output_canonical_json = json.dumps(result["canonical"])
                    output_hash = result.get("hash")
        except RuntimeError:
            # BLOCK verdict (or WARN promoted to BLOCK) - refuse agent startup.
            raise
        except Exception as e:
            logger.warning(
                f"Schema normalization unavailable for {tool_name} "
                f"(rebuild Rust wheel to enable): {e}"
            )
            input_canonical_json = None
            input_hash = None
            output_canonical_json = None
            output_hash = None
            combined_warnings = []

        schema_warnings = combined_warnings if combined_warnings else None

        # Get LLM filter/provider from mesh_llm_agents by matching function name
        # (The @mesh.llm decorator stores these, not @mesh.tool)
        llm_filter_json = None
        llm_provider_json = None

        func_name = decorated_func.function.__name__
        for llm_agent_id, llm_metadata in mesh_llm_agents.items():
            if llm_metadata.function.__name__ == func_name:
                # Found matching LLM agent - extract filter config
                raw_filter = llm_metadata.config.get("filter")
                filter_mode = llm_metadata.config.get("filter_mode", "all")

                # Normalize filter to array format
                if raw_filter is None:
                    normalized_filter = []
                elif isinstance(raw_filter, list):
                    normalized_filter = raw_filter
                elif isinstance(raw_filter, dict):
                    normalized_filter = [raw_filter]
                elif isinstance(raw_filter, str):
                    normalized_filter = [raw_filter] if raw_filter else []
                else:
                    normalized_filter = []

                if normalized_filter:
                    llm_filter_data = {
                        "filter": normalized_filter,
                        "filter_mode": filter_mode,
                    }
                    llm_filter_json = json.dumps(llm_filter_data)
                    logger.debug(
                        f"🤖 Extracted llm_filter for {func_name}: {len(normalized_filter)} filters, mode={filter_mode}"
                    )

                # Extract llm_provider (v0.6.1: LLM Mesh Delegation)
                provider = llm_metadata.config.get("provider")
                if isinstance(provider, dict):
                    llm_provider_data = {
                        "capability": provider.get("capability", "llm"),
                        "tags": provider.get("tags", []),
                        "version": provider.get("version", ""),
                        "namespace": provider.get("namespace", "default"),
                    }
                    llm_provider_json = json.dumps(llm_provider_data)
                    logger.debug(
                        f"🔌 Extracted llm_provider for {func_name}: {llm_provider_data}"
                    )
                break

        # Extract kwargs (non-standard fields like vendor)
        # These are spread as top-level keys in metadata by @mesh.tool(**kwargs)
        standard_fields = {
            "capability",
            "tags",
            "version",
            "description",
            "dependencies",
            "input_schema",
            # Issue #547 Phase 4: SDK-internal verdict policy flag — don't ship.
            "output_schema_strict",
            # Issue #879: per-tool retry whitelist is a tuple of exception
            # *classes* (Type[BaseException]). It's consumed SDK-locally by
            # the job_dispatch wrapper via DecoratorRegistry; the registry
            # has no use for it and json.dumps() would TypeError on the
            # class objects, killing the heartbeat loop. Strip it here.
            "retry_on",
        }
        kwargs_data = {
            k: v for k, v in tool_metadata.items() if k not in standard_fields
        }
        # Defensive: if a future SDK-local field with non-JSON-safe values
        # slips past the whitelist, coerce via str() rather than crashing the
        # heartbeat loop. Logged at DEBUG so the stowaway is discoverable.
        if kwargs_data:
            try:
                kwargs_json = json.dumps(kwargs_data)
            except (TypeError, ValueError) as e:
                logger.debug(
                    f"kwargs_data for tool '{tool_name}' contains non-JSON-"
                    f"serializable values; coercing via str(): {e}. "
                    f"Keys: {list(kwargs_data.keys())}"
                )
                kwargs_json = json.dumps(kwargs_data, default=str)
        else:
            kwargs_json = None

        # Defensive: if @mesh.a2a_consumer's deferred self-tag sentinel
        # survived to heartbeat time, the @mesh.agent decorator never
        # ran (no agent in this process). Strip the sentinel so we
        # don't publish a placeholder string to the registry, and warn
        # the user that capability+tag failover by consumer name won't
        # work.
        published_tags = tool_metadata.get("tags", []) or []
        if "__MESH_CONSUMER_SELF__" in published_tags:
            published_tags = [t for t in published_tags if t != "__MESH_CONSUMER_SELF__"]
            logger.warning(
                f"@mesh.a2a_consumer tool '{tool_name}': consumer-name self "
                "tag was never resolved (no @mesh.agent in this process at "
                "heartbeat time). Publishing without auto-tag — failover by "
                "consumer-name will not work. Declare a @mesh.agent in the "
                "same module to enable it."
            )

        tool_spec = core.ToolSpec(
            function_name=tool_name,
            capability=tool_metadata.get("capability", tool_name),
            version=tool_metadata.get("version", "1.0.0"),
            description=tool_metadata.get("description") or "",
            tags=published_tags,
            dependencies=deps if deps else None,
            input_schema=input_schema_json,
            output_schema=output_schema_json,
            input_schema_canonical=input_canonical_json,
            input_schema_hash=input_hash,
            output_schema_canonical=output_canonical_json,
            output_schema_hash=output_hash,
            schema_warnings=schema_warnings,
            llm_filter=llm_filter_json,
            llm_provider=llm_provider_json,
            kwargs=kwargs_json,
        )
        tools.append(tool_spec)
        logger.info(
            f"📤 Tool '{tool_name}': llm_filter={llm_filter_json}, llm_provider={llm_provider_json}"
        )

    # Build LLM agent specs
    llm_agents = []

    for func_id, llm_metadata in mesh_llm_agents.items():
        # LLMAgentMetadata is a dataclass with .config dict
        config = llm_metadata.config if hasattr(llm_metadata, "config") else {}

        provider = config.get("provider", {})
        provider_json = json.dumps(provider) if provider else "{}"

        filter_spec = config.get("filter")
        filter_json = json.dumps(filter_spec) if filter_spec else None

        llm_spec = core.LlmAgentSpec(
            function_id=func_id,
            provider=provider_json,
            filter=filter_json,
            filter_mode=config.get("filter_mode", "all"),
            max_iterations=config.get("max_iterations", 1),
        )
        llm_agents.append(llm_spec)

    # Base decorator name (shared across replicas) falls back to agent_id for
    # synthetic configs where @mesh.agent(name=...) wasn't used.
    base_name = agent_config.get("name") or agent_id

    # Issue #903 Phase 1B: gather @mesh.a2a surfaces. Presence flips
    # agent_type to "a2a" so the registry computes FQDNs and surfaces
    # this agent on GET /a2a/agents. The Rust core ships the surfaces
    # JSON string verbatim to the registry's `MeshAgentRegistration.surfaces`
    # field. Mesh tools coexist with A2A surfaces.
    a2a_surfaces = _build_a2a_surfaces_for_rust()
    agent_type = "a2a" if a2a_surfaces else None
    surfaces_json = json.dumps(a2a_surfaces) if a2a_surfaces else None

    # Issue #972: derive the A2A producer/consumer self-declared flags. Reuse
    # the already-computed `a2a_surfaces` list for the producer signal (any
    # @mesh.a2a / mount(...) surface flips the flag). For the consumer signal
    # walk `mesh_tools` and check the marker stamped by @mesh.a2a_consumer's
    # bridge (see `mesh/decorators.py::a2a_consumer`).
    a2a_producer = bool(a2a_surfaces)
    a2a_consumer = any(
        hasattr(decorated.function, "_mesh_a2a_consumer_metadata")
        for decorated in mesh_tools.values()
    )

    # Create AgentSpec
    spec = core.AgentSpec(
        name=base_name,
        registry_url=registry_url,
        version=version,
        description=description,
        http_port=http_port,
        http_host=http_host,
        namespace=namespace,
        agent_type=agent_type,
        tools=tools if tools else None,
        llm_agents=llm_agents if llm_agents else None,
        heartbeat_interval=heartbeat_interval,
        agent_id=agent_id,
        surfaces=surfaces_json,
        a2a_producer=a2a_producer,
        a2a_consumer=a2a_consumer,
    )

    logger.info(
        f"Built AgentSpec: name={base_name}, agent_id={agent_id}, "
        f"agent_type={agent_type or 'mcp_agent'}, tools={len(tools)}, "
        f"llm_agents={len(llm_agents)}, surfaces={len(a2a_surfaces)}, "
        f"registry={registry_url}"
    )

    return spec


def _build_a2a_surfaces_for_rust() -> list[dict[str, Any]]:
    """Collect ``@mesh.a2a`` surfaces in the registry-bound shape (issue #903 Phase 1B).

    Thin wrapper around :func:`a2a_surfaces.collect_a2a_surfaces` so the
    legacy Python heartbeat path, the Rust-backed mcp heartbeat, and the
    Rust-backed api heartbeat all emit identical JSON. See
    ``_mcp_mesh.engine.a2a_surfaces`` for shape rationale.
    """
    from ...engine.a2a_surfaces import collect_a2a_surfaces

    return collect_a2a_surfaces()


async def _handle_mesh_event(event: Any, context: dict[str, Any]) -> None:
    """
    Handle a mesh event from the Rust core.

    Dispatches to appropriate handler based on event type.
    """
    event_type = event.event_type

    if event_type == "agent_registered":
        logger.info(f"Agent registered with ID: {event.agent_id}")

    elif event_type == "registration_failed":
        logger.error(f"Agent registration failed: {event.error}")

    elif event_type == "dependency_available":
        await _handle_dependency_change(
            capability=event.capability,
            endpoint=event.endpoint,
            function_name=event.function_name,
            agent_id=event.agent_id,
            available=True,
            context=context,
            requesting_function=getattr(event, "requesting_function", None),
            dep_index=getattr(event, "dep_index", None),
            producer_kwargs=getattr(event, "kwargs", None),
        )

    elif event_type == "dependency_changed":
        await _handle_dependency_change(
            capability=event.capability,
            endpoint=event.endpoint,
            function_name=event.function_name,
            agent_id=event.agent_id,
            available=True,
            context=context,
            requesting_function=getattr(event, "requesting_function", None),
            dep_index=getattr(event, "dep_index", None),
            producer_kwargs=getattr(event, "kwargs", None),
        )

    elif event_type == "dependency_unavailable":
        await _handle_dependency_change(
            capability=event.capability,
            endpoint=None,
            function_name=None,
            agent_id=None,
            available=False,
            context=context,
            requesting_function=getattr(event, "requesting_function", None),
            dep_index=getattr(event, "dep_index", None),
            producer_kwargs=None,
        )

    elif event_type == "llm_tools_updated":
        if event.tools is None:
            logger.warning(
                f"llm_tools_updated event for '{event.function_id}' has no tools data, skipping"
            )
        else:
            await _handle_llm_tools_update(
                function_id=event.function_id,
                tools=event.tools,
                context=context,
            )

    elif event_type == "llm_provider_available":
        if event.provider_info is None:
            logger.warning(
                "llm_provider_available event has no provider_info, skipping"
            )
        else:
            await _handle_llm_provider_update(
                provider_info=event.provider_info,
                context=context,
            )

    elif event_type == "health_check_due":
        # Python can perform health check and report back
        logger.debug("Health check due (not implemented yet)")

    elif event_type == "registry_disconnected":
        logger.warning(f"Registry disconnected: {event.reason}")

    elif event_type == "shutdown":
        logger.info("Rust core shutdown event received")

    else:
        logger.debug(f"Unhandled event type: {event_type}")


async def _handle_dependency_change(
    capability: str,
    endpoint: str | None,
    function_name: str | None,
    agent_id: str | None,
    available: bool,
    context: dict[str, Any],
    requesting_function: str | None = None,
    dep_index: int | None = None,
    producer_kwargs: str | None = None,
) -> None:
    """
    Handle dependency availability change.

    Updates the DI system with new/changed/removed dependencies.

    If requesting_function and dep_index are provided (new behavior from Rust core),
    we can directly register/unregister at the exact position. Otherwise, we fall
    back to capability-based matching (backward compatibility).

    ``producer_kwargs`` is the producer's @mesh.tool kwargs as a JSON string
    (issue #645 bug 2). The proxy is configured from this — NOT from the
    consumer's locally-declared dep kwargs (which are almost always empty
    because consumers don't predict producer behavior).
    """
    parsed_producer_kwargs: dict = {}
    if producer_kwargs:
        try:
            parsed_producer_kwargs = json.loads(producer_kwargs) or {}
        except (TypeError, ValueError) as e:
            logger.warning(
                f"Could not parse producer kwargs for {capability}: {e}; "
                f"falling back to empty config"
            )
    logger.info(
        f"Dependency change: {capability} -> "
        f"{'available' if available else 'unavailable'} "
        f"at {endpoint}/{function_name}"
        + (
            f" (func: {requesting_function}, idx: {dep_index})"
            if requesting_function
            else ""
        )
    )

    # Import DI components
    from ...engine.decorator_registry import DecoratorRegistry
    from ...engine.dependency_injector import get_global_injector
    from ...engine.unified_mcp_proxy import EnhancedUnifiedMCPProxy
    from ...shared.config_resolver import get_config_value

    injector = get_global_injector()
    mesh_tools = DecoratorRegistry.get_mesh_tools()

    # If we have position info, use it directly (new behavior)
    if requesting_function is not None and dep_index is not None:
        # Build dep_key - requesting_function is the function_name from registry
        # We need to find the corresponding func_id
        func_id = requesting_function
        for tool_name, decorated_func in mesh_tools.items():
            if tool_name == requesting_function:
                func = decorated_func.function
                func_id = f"{func.__module__}.{func.__qualname__}"
                break

        dep_key = f"{func_id}:dep_{dep_index}"

        if not available:
            await injector.unregister_dependency(dep_key)
            logger.info(f"Unregistered dependency: {dep_key}")
            return

        # Issue #645 bug 2: kwargs_config must be the *producer's* @mesh.tool
        # kwargs, not the consumer's dep declaration. The consumer typically
        # declares no kwargs since it doesn't predict producer behavior. The
        # producer-side kwargs travel back from the registry on the resolved
        # dependency (event.kwargs) so the consumer's proxy can configure
        # itself against the producer's advertised behavior (e.g. stream_type).
        kwargs_config = dict(parsed_producer_kwargs)

        # Check for self-dependency
        current_agent_id = None
        try:
            config = DecoratorRegistry.get_resolved_agent_config()
            current_agent_id = config.get("agent_id")
        except Exception:
            # Use config resolver for consistent env var handling
            current_agent_id = get_config_value("MCP_MESH_AGENT_ID")

        is_self_dependency = (
            current_agent_id and agent_id and current_agent_id == agent_id
        )

        if is_self_dependency:
            from ...engine.self_dependency_proxy import SelfDependencyProxy

            wrapper_func = mesh_tools.get(function_name)
            if wrapper_func:
                proxy = SelfDependencyProxy(wrapper_func.function, function_name)
                logger.debug(f"Created SelfDependencyProxy for {capability}")
            else:
                proxy = EnhancedUnifiedMCPProxy(
                    endpoint, function_name, kwargs_config=kwargs_config
                )
                logger.debug(
                    f"Created EnhancedUnifiedMCPProxy (fallback) for {capability}"
                )
        else:
            proxy = EnhancedUnifiedMCPProxy(
                endpoint, function_name, kwargs_config=kwargs_config
            )
            logger.debug(
                f"Created EnhancedUnifiedMCPProxy for {capability} -> {endpoint}"
            )

        await injector.register_dependency(dep_key, proxy)
        logger.info(f"Registered dependency: {dep_key}")
        return

    # Fallback: capability-based matching (backward compatibility)
    if not available:
        # Dependency became unavailable - unregister it
        if hasattr(injector, "_dependencies"):
            keys_to_remove = [
                key for key in injector._dependencies.keys() if capability in key
            ]
            for dep_key in keys_to_remove:
                await injector.unregister_dependency(dep_key)
                logger.info(f"Unregistered dependency: {dep_key}")
        return

    # Dependency is available - create proxy and register
    # Map tool names to func_ids
    tool_name_to_func_id = {}
    for tool_name, decorated_func in mesh_tools.items():
        func = decorated_func.function
        func_id = f"{func.__module__}.{func.__qualname__}"
        tool_name_to_func_id[tool_name] = func_id

    # Find which functions depend on this capability
    for tool_name, decorated_func in mesh_tools.items():
        tool_metadata = decorated_func.metadata or {}
        dependencies = tool_metadata.get("dependencies", [])

        for idx, dep_info in enumerate(dependencies):
            if dep_info.get("capability") == capability:
                func_id = tool_name_to_func_id.get(tool_name, tool_name)
                dep_key = f"{func_id}:dep_{idx}"

                # Check for self-dependency
                current_agent_id = None
                try:
                    config = DecoratorRegistry.get_resolved_agent_config()
                    current_agent_id = config.get("agent_id")
                except Exception:
                    # Use config resolver for consistent env var handling
                    current_agent_id = get_config_value("MCP_MESH_AGENT_ID")

                is_self_dependency = (
                    current_agent_id and agent_id and current_agent_id == agent_id
                )

                # Issue #645 bug 2: kwargs_config is *only* the producer's
                # @mesh.tool kwargs. Consumer-side kwargs in dep declarations
                # are NOT propagated to the proxy — the producer's advertised
                # behavior (e.g. stream_type) wins, falling back to empty
                # when the producer ships nothing. Aligned with the
                # position-path above.
                kwargs_config = dict(parsed_producer_kwargs)

                if is_self_dependency:
                    # Create self-dependency proxy
                    from ...engine.self_dependency_proxy import SelfDependencyProxy

                    wrapper_func = mesh_tools.get(function_name)
                    if wrapper_func:
                        proxy = SelfDependencyProxy(
                            wrapper_func.function, function_name
                        )
                        logger.debug(f"Created SelfDependencyProxy for {capability}")
                    else:
                        # Fallback to HTTP proxy. Forward producer kwargs
                        # so streaming etc. still works in the fallback.
                        proxy = EnhancedUnifiedMCPProxy(
                            endpoint,
                            function_name,
                            kwargs_config=kwargs_config,
                        )
                        logger.debug(
                            f"Created EnhancedUnifiedMCPProxy (fallback) for {capability}"
                        )
                else:
                    # Create cross-service proxy.
                    proxy = EnhancedUnifiedMCPProxy(
                        endpoint, function_name, kwargs_config=kwargs_config
                    )
                    logger.debug(
                        f"Created EnhancedUnifiedMCPProxy for {capability} -> {endpoint}"
                    )

                await injector.register_dependency(dep_key, proxy)
                logger.info(f"Registered dependency: {dep_key}")


async def _handle_llm_tools_update(
    function_id: str,
    tools: list,
    context: dict[str, Any],
) -> None:
    """
    Handle LLM tools update event.

    Updates the LLM tools registry for the given function via the DI system.
    """
    logger.info(f"LLM tools update for {function_id}: {len(tools)} tools")

    # Import injector
    from ...engine.dependency_injector import get_global_injector

    # Convert tools to the expected format (using "name" for OpenAPI contract)
    tool_list = []
    for tool in tools:
        tool_info = {
            "name": tool.function_name,  # OpenAPI contract uses "name" not "function_name"
            "capability": tool.capability,
            "endpoint": tool.endpoint,
            "agent_id": tool.agent_id,
            "input_schema": (
                json.loads(tool.input_schema) if tool.input_schema else None
            ),
            "description": tool.description if tool.description else "",
        }
        tool_list.append(tool_info)

    # Update LLM tools via the dependency injector
    injector = get_global_injector()
    llm_tools = {function_id: tool_list}
    injector.update_llm_tools(llm_tools)
    logger.debug(f"Updated {len(tool_list)} LLM tools for {function_id}")


async def _handle_llm_provider_update(
    provider_info: Any,
    context: dict[str, Any],
) -> None:
    """
    Handle LLM provider resolution event.

    Updates the LLM provider for the given function via the DI system.

    ``provider_info.kwargs`` is the provider tool's @mesh.tool kwargs as a
    JSON string (issue #849 Stage A). The provider proxy is configured from
    this so producer-advertised behavior (e.g. ``stream_type=text``) reaches
    the consumer-side proxy. Mirrors the producer-kwargs propagation for
    regular tool dependencies.
    """
    function_id = provider_info.function_id
    logger.info(
        f"LLM provider resolved for {function_id}: "
        f"{provider_info.function_name} at {provider_info.endpoint}"
    )

    # Parse provider kwargs (JSON string from Rust event). Defensive parse
    # mirrors _handle_dependency_change for symmetry with regular tool deps.
    raw_provider_kwargs = getattr(provider_info, "kwargs", None)
    parsed_provider_kwargs: dict = {}
    if raw_provider_kwargs:
        try:
            _decoded = json.loads(raw_provider_kwargs)
        except (TypeError, ValueError) as e:
            logger.warning(
                f"Could not parse provider kwargs for {function_id}: {e}; "
                f"falling back to empty config"
            )
            _decoded = None
        if _decoded is None:
            parsed_provider_kwargs = {}
        elif isinstance(_decoded, dict):
            parsed_provider_kwargs = _decoded
        else:
            logger.warning(
                f"Provider kwargs for {function_id} parsed to "
                f"{type(_decoded).__name__}, expected object; "
                f"falling back to empty config"
            )
            parsed_provider_kwargs = {}

    # Import injector
    from ...engine.dependency_injector import get_global_injector
    from ...engine.unified_mcp_proxy import EnhancedUnifiedMCPProxy

    # Create proxy for the LLM provider. Forward producer kwargs so streaming
    # etc. is configured even on this generic-dependency registration path
    # (MeshLlmAgent uses a different proxy via the injector, but we keep
    # symmetry here too).
    proxy = EnhancedUnifiedMCPProxy(
        provider_info.endpoint,
        provider_info.function_name,
        kwargs_config=dict(parsed_provider_kwargs),
    )

    # Register as the LLM provider for this function
    injector = get_global_injector()
    provider_key = f"{function_id}:llm_provider"
    await injector.register_dependency(provider_key, proxy)

    # Also store provider metadata for the mesh agent to use (using "name" for OpenAPI contract).
    # ``kwargs`` carries the provider tool's @mesh.tool kwargs so the
    # MeshLlmAgentInjector can lift them onto the provider proxy's
    # kwargs_config (issue #849 Stage A).
    llm_providers = {
        function_id: {
            "agent_id": provider_info.agent_id,
            "endpoint": provider_info.endpoint,
            "name": provider_info.function_name,  # OpenAPI contract uses "name"
            "model": provider_info.model,
            "vendor": provider_info.vendor,  # For handler selection
            "kwargs": parsed_provider_kwargs,  # Producer @mesh.tool kwargs (e.g. stream_type)
        }
    }
    injector.process_llm_providers(llm_providers)
    logger.debug(f"Registered LLM provider for {function_id}")


def _start_claim_dispatchers_on_heartbeat_loop(context: dict[str, Any]) -> list:
    """Start any MeshJob claim dispatchers staged by ``JobsClaimWorkersStep``.

    Phase 1 MeshJob substrate (#bug 2 — local-validation fix)
    ---------------------------------------------------------
    The startup pipeline runs inside a transient ``asyncio.run`` loop on
    the main thread, while the FastAPI/uvicorn server runs on yet
    another thread (immediate-uvicorn flow). Neither of those loops is
    a stable home for the dispatcher tasks:

    * Pipeline loop closes when ``process_once()`` returns — any task
      created there dies immediately.
    * The immediate-uvicorn FastAPI app uses its own (FastMCP-supplied)
      lifespan that does NOT know about ``app.state.mesh_claim_dispatchers``,
      and even where the lifespan-factory lifespan IS in use, its startup
      section runs BEFORE the pipeline stages dispatchers — so the
      lifespan never sees them.

    The heartbeat thread, on the other hand, owns a long-lived
    ``loop.run_until_complete(heartbeat_task_fn(...))`` that lives for
    the whole agent lifetime. Starting the dispatchers from inside the
    heartbeat task binds them to that persistent loop — exactly what we
    want.

    Returns the list of dispatchers we started so the heartbeat task can
    stop them on shutdown.
    """
    dispatchers = list(context.get("claim_dispatchers", []) or [])
    if not dispatchers:
        return []

    started: list = []
    for d in dispatchers:
        try:
            d.start()  # idempotent: no-op if already running on this loop
            started.append(d)
        except Exception as e:
            logger.warning(
                "heartbeat: failed to start claim dispatcher for capability=%s: %s",
                getattr(d, "capability", "?"),
                e,
            )
    if started:
        logger.info(
            "📨 heartbeat: started %d MeshJob claim dispatcher(s) on heartbeat loop",
            len(started),
        )
    return started


async def _stop_claim_dispatchers(dispatchers: list) -> None:
    """Best-effort shutdown of claim dispatchers started by the heartbeat loop."""
    for d in dispatchers:
        try:
            await d.stop()
        except Exception as e:
            logger.warning(
                "heartbeat: error stopping claim dispatcher for capability=%s: %s",
                getattr(d, "capability", "?"),
                e,
            )


async def rust_heartbeat_task(heartbeat_config: dict[str, Any]) -> None:
    """
    Rust-backed heartbeat task that runs in FastAPI lifespan.

    This is a drop-in replacement for heartbeat_lifespan_task.
    Instead of running Python heartbeat loop, it starts the Rust core
    and listens for events.

    Args:
        heartbeat_config: Configuration containing agent_id, interval, context
    """
    agent_id = heartbeat_config["agent_id"]
    context = heartbeat_config["context"]
    standalone_mode = heartbeat_config.get("standalone_mode", False)

    if standalone_mode:
        logger.info(
            f"Rust heartbeat in standalone mode for agent '{agent_id}' "
            "(no registry communication)"
        )
        return

    try:
        core = _get_rust_core()
    except ImportError as e:
        logger.error(
            f"Rust core not available for agent '{agent_id}': {e}. "
            "The mcp_mesh_core module must be built and installed."
        )
        raise RuntimeError(
            f"Rust core (mcp_mesh_core) is required but not available: {e}"
        ) from e

    logger.info(f"Starting Rust-backed heartbeat for agent '{agent_id}'")

    handle = None
    claim_dispatchers: list = []
    try:
        # Build AgentSpec from context
        spec = _build_agent_spec(context)

        # Start Rust core runtime
        handle = core.start_agent(spec)
        logger.info(f"Rust core started for agent '{agent_id}'")

        # Track this handle in the process-wide registry so atexit can
        # drain it before Py_Finalize. Closes the pyo3-async-runtimes
        # Python::attach race during abnormal exits (uvicorn bind fail,
        # unhandled startup exception). See issue #877.
        try:
            from ...shared.simple_shutdown import register_rust_agent_handle

            register_rust_agent_handle(handle)
        except Exception as e:  # pragma: no cover - never block startup
            logger.debug(f"Could not register handle for atexit drain: {e}")

        # Phase 1 MeshJob substrate: start claim dispatchers on this
        # heartbeat loop (long-lived), not the transient pipeline loop
        # or the racy uvicorn-lifespan loop. See helper docstring for
        # the architectural rationale.
        claim_dispatchers = _start_claim_dispatchers_on_heartbeat_loop(context)

        # Event loop - process events from Rust core
        while True:
            # Check for Python shutdown signal
            try:
                from ...shared.simple_shutdown import should_stop_heartbeat

                if should_stop_heartbeat():
                    logger.info(
                        f"Stopping Rust heartbeat for agent '{agent_id}' due to shutdown"
                    )
                    handle.shutdown()
                    break
            except ImportError:
                pass

            try:
                # Wait for next event from Rust core with timeout
                # Timeout allows periodic shutdown checks
                try:
                    event = await asyncio.wait_for(handle.next_event(), timeout=1.0)
                except TimeoutError:
                    # No event in 1 second, loop back to check shutdown signal
                    continue

                if event.event_type == "shutdown":
                    logger.info(f"Rust core shutdown for agent '{agent_id}'")
                    break

                # Handle the event
                await _handle_mesh_event(event, context)

            except Exception as e:
                logger.error(f"Error handling Rust event: {e}")
                # Continue processing events

    except asyncio.CancelledError:
        logger.info(f"Rust heartbeat task cancelled for agent '{agent_id}'")
        raise
    except Exception as e:
        logger.error(f"Rust heartbeat failed for agent '{agent_id}': {e}")
        raise
    finally:
        # Stop claim dispatchers BEFORE Rust core shutdown so they get a
        # clean cancellation signal while the loop is still spinning.
        if claim_dispatchers:
            try:
                await _stop_claim_dispatchers(claim_dispatchers)
            except Exception as e:
                logger.warning(f"Error stopping claim dispatchers: {e}")

        # Always ensure graceful shutdown of Rust core to prevent daemon thread issues
        # This is critical: without shutdown(), Rust background threads may try to
        # write to stdout via tracing after Python's stdout is finalized
        if handle is not None:
            try:
                handle.shutdown()
                # Give Rust core a moment to clean up before Python exits
                # Use time.sleep as fallback if asyncio is shutting down
                try:
                    await asyncio.sleep(0.2)
                except (asyncio.CancelledError, RuntimeError):
                    # Event loop might be shutting down, use blocking sleep
                    import time

                    time.sleep(0.2)
                logger.debug(f"Rust core shutdown complete for agent '{agent_id}'")
                # Only drop from atexit registry on the success path. If
                # shutdown() raised, leave the handle registered so the
                # atexit hook can retry — `AgentHandle.shutdown` is
                # idempotent (sets a flag + try_send on a channel), so a
                # second call from atexit is safe. Best-effort.
                try:
                    from ...shared.simple_shutdown import (
                        unregister_rust_agent_handle,
                    )

                    unregister_rust_agent_handle(handle)
                except Exception:
                    pass
            except Exception as e:
                logger.warning(f"Error during Rust core shutdown: {e}")
