"""CLI entry point."""

from __future__ import annotations

import argparse
import os

import uvicorn


def main() -> None:
    """Start web application."""
    parser = _build_parser()
    args = parser.parse_args()

    # app.py resolves PROFILE_PATH during import, so set it before loading app.
    os.environ["PROFILE_PATH"] = args.profile_path

    if args.dev:
        uvicorn.run(
            "line_profiler_web.app:app",
            host="127.0.0.1",
            port=args.port,
            reload=True,
        )
        return

    from line_profiler_web.app import app  # pylint: disable=import-outside-toplevel

    uvicorn.run(app, host="127.0.0.1", port=args.port, reload=False)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Start the line-profiler web UI.")
    parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="Port to bind the web server to (default: 8080).",
    )
    parser.add_argument(
        "--profile-path",
        default="profile",
        help="Directory containing line-profiler output files (default: profile).",
    )
    parser.add_argument(
        "--dev",
        action="store_true",
        help="Run in development mode with auto-reload.",
    )
    return parser


if __name__ == "__main__":
    main()
