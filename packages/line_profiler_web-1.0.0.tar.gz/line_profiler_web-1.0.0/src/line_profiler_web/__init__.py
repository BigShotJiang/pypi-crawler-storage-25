"""Line profiler web interface."""

import os
import re
from os import PathLike

from line_profiler import LineProfiler

PathType = str | PathLike[str]


def save_stats(lp: LineProfiler, profile_dir: PathType = "profile") -> None:
    """Save profiling result to a file in the given directory."""
    if not os.path.exists(profile_dir):
        os.makedirs(profile_dir)
    next_index = _get_next_free_index(profile_dir, pattern="profile_*.txt")
    with open(f"{profile_dir}/profile_{next_index}.txt", "w", encoding="utf-8") as f:
        lp.print_stats(f, output_unit=1e-3)


def _get_next_free_index(directory: PathType, pattern: str) -> int:
    if pattern.count("*") != 1:
        raise ValueError("pattern must contain exactly one '*' wildcard")
    prefix, suffix = pattern.split("*")
    regex = re.compile(rf"^{re.escape(prefix)}(\d+){re.escape(suffix)}$")
    used_indices = set()
    for file_name in os.listdir(directory):
        match = regex.match(file_name)
        if match:
            used_indices.add(int(match.group(1)))
    index = 0
    while index in used_indices:
        index += 1
    return index
