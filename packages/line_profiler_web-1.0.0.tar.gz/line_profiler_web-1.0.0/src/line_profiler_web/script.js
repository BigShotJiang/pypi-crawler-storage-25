const state = {
  runs: [],
  currentRun: null,
  functions: [],
  totals: [],
  currentFunctionId: null,
  view: "lines",
  functionQuery: "",
  pollHandle: null,
};

const elements = {
  runsList: document.getElementById("runs-list"),
  runsEmpty: document.getElementById("runs-empty"),
  functionDropdownBtn: document.getElementById("function-dropdown-btn"),
  functionSearch: document.getElementById("function-search"),
  functionOptions: document.getElementById("function-options"),
  viewLines: document.getElementById("view-lines"),
  viewTotals: document.getElementById("view-totals"),
  statusPlaceholder: document.getElementById("status-placeholder"),
  lineView: document.getElementById("line-view"),
  totalsView: document.getElementById("totals-view"),
  selectedMeta: document.getElementById("selected-meta"),
  lineTableBody: document.getElementById("line-table-body"),
  totalsTableBody: document.getElementById("totals-table-body"),
  themeToggle: document.getElementById("theme-toggle"),
  themeIcon: document.getElementById("theme-icon"),
  reloadToggle: document.getElementById("reload-toggle"),
  reloadIcon: document.getElementById("reload-icon"),
  hljsThemeLight: document.getElementById("hljs-theme-light"),
  hljsThemeDark: document.getElementById("hljs-theme-dark"),
};

const STORAGE_KEY = "line-profile-view-state";
const THEME_KEY = "line-profile-view-theme";
const AUTO_RELOAD_KEY = "line-profile-view-auto-reload";
const POLL_MS = 2000;

function escapeHtml(value) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function normalizeNumber(value, fractionDigits = 2) {
  if (!Number.isFinite(value)) {
    return "0";
  }
  return value.toLocaleString(undefined, {
    minimumFractionDigits: 0,
    maximumFractionDigits: fractionDigits,
  });
}

function formatSeconds(value) {
  if (!Number.isFinite(value)) {
    return "0.000";
  }
  return Number(value).toFixed(3);
}

function literalCell(value) {
  return escapeHtml(String(value ?? ""));
}

function literalCellWithMute(value, muted) {
  const text = literalCell(value);
  if (!muted) {
    return text;
  }
  return `<span class="muted-zero-text">${text}</span>`;
}

function saveState() {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        currentRun: state.currentRun,
        currentFunctionId: state.currentFunctionId,
        view: state.view,
      })
    );
  } catch (_error) {
    // ignore storage errors
  }
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return;
    }
    const parsed = JSON.parse(raw);
    if (typeof parsed.currentRun === "string") {
      state.currentRun = parsed.currentRun;
    }
    if (typeof parsed.currentFunctionId === "string") {
      state.currentFunctionId = parsed.currentFunctionId;
    }
    if (parsed.view === "lines" || parsed.view === "totals") {
      state.view = parsed.view;
    }
  } catch (_error) {
    // ignore malformed data
  }
}

function isAutoReloadEnabled() {
  try {
    const raw = localStorage.getItem(AUTO_RELOAD_KEY);
    if (raw === null) {
      return true;
    }
    return raw === "true";
  } catch (_error) {
    return true;
  }
}

function setAutoReloadEnabled(enabled) {
  try {
    localStorage.setItem(AUTO_RELOAD_KEY, enabled ? "true" : "false");
  } catch (_error) {
    // ignore storage errors
  }
}

function renderReloadToggle(enabled) {
  elements.reloadToggle.className = enabled
    ? "btn btn-sm btn-outline-secondary"
    : "btn btn-sm btn-outline-danger";
  elements.reloadIcon.className = enabled ? "bi bi-arrow-repeat" : "bi bi-pause-circle";
  elements.reloadToggle.setAttribute(
    "data-bs-title",
    enabled ? "Disable auto reload" : "Enable auto reload"
  );
  refreshTooltips(elements.reloadToggle.parentElement || document);
}

function stopAutoReload() {
  if (state.pollHandle) {
    window.clearInterval(state.pollHandle);
    state.pollHandle = null;
  }
}

function disposeTooltips(root = document) {
  const tooltipTargets = root.querySelectorAll
    ? root.querySelectorAll('[data-bs-toggle="tooltip"]')
    : [];
  tooltipTargets.forEach((target) => {
    const existing = bootstrap.Tooltip.getInstance(target);
    if (existing) {
      existing.hide();
      existing.dispose();
    }
  });
}

function refreshTooltips(root = document) {
  disposeTooltips(root);
  const tooltipTargets = root.querySelectorAll
    ? root.querySelectorAll('[data-bs-toggle="tooltip"]')
    : [];
  tooltipTargets.forEach((target) => {
    bootstrap.Tooltip.getOrCreateInstance(target, { container: "body" });
  });
}

function startAutoReload() {
  stopAutoReload();
  state.pollHandle = window.setInterval(() => {
    refreshData();
  }, POLL_MS);
}

function getCurrentFunction() {
  if (!state.currentFunctionId) {
    return null;
  }
  return state.functions.find((fn) => fn.id === state.currentFunctionId) || null;
}

function setPlaceholder(message) {
  elements.statusPlaceholder.classList.remove("d-none");
  elements.statusPlaceholder.querySelector(".card-body").textContent = message;
  elements.lineView.classList.add("d-none");
  elements.totalsView.classList.add("d-none");
}

function parseFileName(pathValue) {
  const parts = String(pathValue || "").split(/[\\/]/);
  return parts.length > 0 ? parts[parts.length - 1] : "";
}

function heatColor(percentRatio) {
  const alpha = Math.min(0.48, Math.max(0, percentRatio * 0.48));
  return `rgba(207, 34, 46, ${alpha.toFixed(3)})`;
}

function applyCodeHighlighting(root) {
  if (typeof hljs === "undefined" || typeof hljs.highlightElement !== "function") {
    return;
  }
  const codeBlocks = root.querySelectorAll("code.language-python");
  codeBlocks.forEach((codeBlock) => {
    hljs.highlightElement(codeBlock);
  });
}

function renderRuns() {
  elements.runsList.innerHTML = "";
  if (state.runs.length === 0) {
    elements.runsEmpty.classList.remove("d-none");
    return;
  }
  elements.runsEmpty.classList.add("d-none");

  state.runs.forEach((run) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "list-group-item list-group-item-action run-item";
    if (run.name === state.currentRun) {
      button.classList.add("active");
    }
    button.innerHTML = `
      <div class="run-title">${escapeHtml(run.title)}</div>
      <div class="run-subtitle">${escapeHtml(run.relative_time)}</div>
    `;
    button.addEventListener("click", async () => {
      state.currentRun = run.name;
      saveState();
      renderRuns();
      await loadProfile();
    });
    elements.runsList.appendChild(button);
  });
}

function renderFunctionOptions() {
  const query = state.functionQuery.trim().toLowerCase();
  const filtered = state.functions.filter((fn) => {
    if (!query) {
      return true;
    }
    const combined = `${fn.name} ${fn.file}`.toLowerCase();
    return combined.includes(query);
  });

  elements.functionOptions.innerHTML = "";
  if (filtered.length === 0) {
    const empty = document.createElement("div");
    empty.className = "small text-muted px-2 py-1";
    empty.textContent = "No matching functions.";
    elements.functionOptions.appendChild(empty);
    return;
  }

  filtered.forEach((fn) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "function-item";
    if (fn.id === state.currentFunctionId) {
      button.classList.add("active");
    }
    button.innerHTML = `
      <div class="fn-label">${escapeHtml(fn.name)}</div>
      <div class="fn-file">${escapeHtml(parseFileName(fn.file))}:${fn.start_line}</div>
    `;
    button.addEventListener("click", () => {
      state.currentFunctionId = fn.id;
      state.view = "lines";
      state.functionQuery = "";
      elements.functionSearch.value = "";
      elements.functionDropdownBtn.textContent = fn.display_name;
      saveState();
      renderFunctionOptions();
      renderProfileView();
      const dropdown = bootstrap.Dropdown.getOrCreateInstance(elements.functionDropdownBtn);
      dropdown.hide();
    });
    elements.functionOptions.appendChild(button);
  });
}

function renderLineTable(currentFunction) {
  elements.lineTableBody.innerHTML = "";
  const rows = Array.isArray(currentFunction.lines) ? currentFunction.lines : [];
  const maxTime = rows.reduce((max, row) => Math.max(max, Number(row.time_ms) || 0), 0);

  rows.forEach((row) => {
    const tr = document.createElement("tr");
    const timeMs = Number(row.time_ms) || 0;
    const percent = Number(row.percent_time) || 0;
    const barWidth = maxTime > 0 ? Math.round((timeMs / maxTime) * 100) : 0;
    const heatRatio = Math.min(1, percent / 100);
    const isZeroTimeLiteral = ["", "0.0"].includes(String(row.time_ms_raw || "").trim());
    tr.innerHTML = `<td class="sticky-col col-line num-cell">${literalCellWithMute(
      row.line_raw
    , isZeroTimeLiteral)}</td><td class="sticky-col col-hits num-cell">${literalCellWithMute(
      row.hits_raw
    , isZeroTimeLiteral)}</td><td class="sticky-col col-time num-cell time-cell" style="--bar-width: ${barWidth}%">${literalCellWithMute(
      row.time_ms_raw
    , isZeroTimeLiteral)}</td><td class="sticky-col col-per-hit num-cell">${literalCellWithMute(
      row.per_hit_ms_raw
    , isZeroTimeLiteral)}</td><td class="sticky-col col-percent num-cell percent-cell" style="--bar-width: ${Math.round(
      Math.min(100, Math.max(0, percent))
    )}%">${literalCellWithMute(row.percent_time_raw, isZeroTimeLiteral)}</td><td class="sticky-col col-visual"><div class="percent-visual-track"><div class="percent-visual-fill" style="width: ${Math.round(
      Math.min(100, Math.max(0, percent))
    )}%"></div></div></td><td class="col-code code-cell" style="background-color: ${heatColor(
      heatRatio
    )}"><code class="code-text language-python">${escapeHtml(String(row.content || ""))}</code></td>`;
    elements.lineTableBody.appendChild(tr);
  });
  applyCodeHighlighting(elements.lineTableBody);
  updateStickyOffsets();
}

function updateStickyOffsets() {
  const table = elements.lineView.querySelector(".profile-table");
  if (!table || elements.lineView.classList.contains("d-none")) {
    return;
  }
  const lineHeader = table.querySelector("thead .col-line");
  const hitsHeader = table.querySelector("thead .col-hits");
  const timeHeader = table.querySelector("thead .col-time");
  const perHitHeader = table.querySelector("thead .col-per-hit");
  const percentHeader = table.querySelector("thead .col-percent");
  const visualHeader = table.querySelector("thead .col-visual");
  if (!lineHeader || !hitsHeader || !timeHeader || !perHitHeader || !percentHeader || !visualHeader) {
    return;
  }

  const lineWidth = lineHeader.getBoundingClientRect().width;
  const hitsWidth = hitsHeader.getBoundingClientRect().width;
  const timeWidth = timeHeader.getBoundingClientRect().width;
  const perHitWidth = perHitHeader.getBoundingClientRect().width;
  const percentWidth = percentHeader.getBoundingClientRect().width;

  elements.lineView.style.setProperty("--col-line-left", "0px");
  elements.lineView.style.setProperty("--col-hits-left", `${lineWidth.toFixed(3)}px`);
  elements.lineView.style.setProperty("--col-time-left", `${(lineWidth + hitsWidth).toFixed(3)}px`);
  elements.lineView.style.setProperty(
    "--col-per-hit-left",
    `${(lineWidth + hitsWidth + timeWidth).toFixed(3)}px`
  );
  elements.lineView.style.setProperty(
    "--col-percent-left",
    `${(lineWidth + hitsWidth + timeWidth + perHitWidth).toFixed(3)}px`
  );
  elements.lineView.style.setProperty(
    "--col-visual-left",
    `${(lineWidth + hitsWidth + timeWidth + perHitWidth + percentWidth).toFixed(3)}px`
  );
}

function renderTotalsTable() {
  elements.totalsTableBody.innerHTML = "";
  const maxTotal = state.totals.reduce(
    (max, item) => Math.max(max, Number(item.total_time_ms) || 0),
    0
  );
  state.totals.forEach((item, index) => {
    const tr = document.createElement("tr");
    tr.className = "totals-row";
    const totalMs = Number(item.total_time_ms) || 0;
    const barWidth = maxTotal > 0 ? Math.round((totalMs / maxTotal) * 100) : 0;
    tr.innerHTML = `
      <td>${index + 1}</td>
      <td>
        <div><strong>${escapeHtml(item.name)}</strong></div>
        <div class="small text-muted">${escapeHtml(parseFileName(item.file))}:${item.start_line}</div>
      </td>
      <td class="total-time-cell num-cell">${normalizeNumber(totalMs, 0)}</td>
      <td class="col-time-total-visual"><div class="percent-visual-track"><div class="percent-visual-fill" style="width: ${barWidth}%"></div></div></td>
    `;
    tr.addEventListener("click", () => {
      if (!item.id || !state.functions.some((fn) => fn.id === item.id)) {
        return;
      }
      state.currentFunctionId = item.id;
      state.view = "lines";
      saveState();
      renderFunctionOptions();
      renderProfileView();
    });
    elements.totalsTableBody.appendChild(tr);
  });
}

function renderViewToggle() {
  const linesActive = state.view === "lines";
  elements.viewLines.className = linesActive ? "btn btn-primary" : "btn btn-outline-primary";
  elements.viewTotals.className = linesActive ? "btn btn-outline-primary" : "btn btn-primary";
}

function renderProfileView() {
  renderViewToggle();
  const currentFunction = getCurrentFunction();
  const hasData = state.functions.length > 0;

  if (!hasData) {
    setPlaceholder("No functions found in this profile run.");
    elements.functionDropdownBtn.textContent = "No functions available";
    return;
  }

  if (!currentFunction) {
    setPlaceholder("Select a function to view line profiling.");
    elements.functionDropdownBtn.textContent = "Select a function";
    return;
  }

  elements.functionDropdownBtn.textContent = currentFunction.display_name;
  disposeTooltips(elements.selectedMeta);
  const fileName = parseFileName(currentFunction.file);
  elements.selectedMeta.innerHTML = `<strong>${escapeHtml(
    currentFunction.name
  )}</strong> at line ${currentFunction.start_line} in <span data-bs-toggle="tooltip" data-bs-placement="top" data-bs-custom-class="file-path-tooltip" data-bs-title="${escapeHtml(
    currentFunction.file
  )}">${escapeHtml(fileName)}</span> • total ${formatSeconds(currentFunction.total_time_s)} s`;
  refreshTooltips(elements.selectedMeta);
  elements.statusPlaceholder.classList.add("d-none");

  if (state.view === "lines") {
    elements.lineView.classList.remove("d-none");
    elements.totalsView.classList.add("d-none");
    renderLineTable(currentFunction);
    updateStickyOffsets();
  } else {
    elements.lineView.classList.add("d-none");
    elements.totalsView.classList.remove("d-none");
    renderTotalsTable();
  }
}

async function loadRuns() {
  try {
    const response = await fetch("/api/runs");
    const data = await response.json();
    state.runs = Array.isArray(data.runs) ? data.runs : [];
  } catch (_error) {
    state.runs = [];
  }

  if (!state.currentRun || !state.runs.some((run) => run.name === state.currentRun)) {
    state.currentRun = state.runs.length > 0 ? state.runs[state.runs.length - 1].name : null;
  }
  renderRuns();
}

async function loadProfile() {
  if (!state.currentRun) {
    state.functions = [];
    state.totals = [];
    renderFunctionOptions();
    setPlaceholder("No profile run selected.");
    return;
  }

  try {
    const response = await fetch(`/api/profile?run=${encodeURIComponent(state.currentRun)}`);
    if (!response.ok) {
      throw new Error(`Failed with ${response.status}`);
    }
    const data = await response.json();
    state.functions = Array.isArray(data.functions) ? data.functions : [];
    state.totals = Array.isArray(data.totals) ? data.totals : [];
  } catch (_error) {
    state.functions = [];
    state.totals = [];
    renderFunctionOptions();
    setPlaceholder("Failed to load profile.");
    return;
  }

  if (!state.functions.some((fn) => fn.id === state.currentFunctionId)) {
    state.currentFunctionId = state.functions.length > 0 ? state.functions[0].id : null;
  }

  saveState();
  renderFunctionOptions();
  renderProfileView();
}

async function refreshData() {
  const previousRun = state.currentRun;
  await loadRuns();
  const runChanged = previousRun !== state.currentRun;
  if (runChanged || state.functions.length === 0) {
    await loadProfile();
    return;
  }
  await loadProfile();
}

function applyTheme(theme) {
  const safeTheme = theme === "dark" ? "dark" : "light";
  document.documentElement.setAttribute("data-bs-theme", safeTheme);
  elements.themeIcon.className = safeTheme === "dark" ? "bi bi-sun" : "bi bi-moon";
  if (elements.hljsThemeLight && elements.hljsThemeDark) {
    const dark = safeTheme === "dark";
    elements.hljsThemeLight.disabled = dark;
    elements.hljsThemeDark.disabled = !dark;
  }
}

function initTheme() {
  let theme = "light";
  try {
    const stored = localStorage.getItem(THEME_KEY);
    if (stored === "light" || stored === "dark") {
      theme = stored;
    }
  } catch (_error) {
    // ignore storage errors
  }
  applyTheme(theme);
}

function bindEvents() {
  elements.functionSearch.addEventListener("input", (event) => {
    state.functionQuery = event.target.value || "";
    renderFunctionOptions();
  });
  elements.functionDropdownBtn.addEventListener("shown.bs.dropdown", () => {
    window.setTimeout(() => {
      elements.functionSearch.focus();
      elements.functionSearch.select();
    }, 0);
  });

  elements.viewLines.addEventListener("click", () => {
    state.view = "lines";
    saveState();
    renderProfileView();
  });
  elements.viewTotals.addEventListener("click", () => {
    state.view = "totals";
    saveState();
    renderProfileView();
  });

  elements.themeToggle.addEventListener("click", () => {
    const nextTheme =
      document.documentElement.getAttribute("data-bs-theme") === "dark" ? "light" : "dark";
    applyTheme(nextTheme);
    try {
      localStorage.setItem(THEME_KEY, nextTheme);
    } catch (_error) {
      // ignore storage errors
    }
  });

  window.addEventListener("resize", () => {
    updateStickyOffsets();
  });

  elements.reloadToggle.addEventListener("click", () => {
    const currentlyEnabled = isAutoReloadEnabled();
    const nextEnabled = !currentlyEnabled;
    setAutoReloadEnabled(nextEnabled);
    renderReloadToggle(nextEnabled);
    if (nextEnabled) {
      startAutoReload();
      refreshData();
    } else {
      stopAutoReload();
    }
  });
}

async function init() {
  loadState();
  initTheme();
  bindEvents();
  refreshTooltips();
  await refreshData();

  const autoReloadEnabled = isAutoReloadEnabled();
  renderReloadToggle(autoReloadEnabled);
  if (autoReloadEnabled) {
    startAutoReload();
  } else {
    stopAutoReload();
  }
}

init();
