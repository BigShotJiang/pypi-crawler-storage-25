"""FastAPI app."""

from __future__ import annotations

import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, cast

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

APP_DIR = Path(__file__).resolve().parent


def _resolve_profile_dir() -> Path:
    env_profile_path = os.environ.get("PROFILE_PATH")
    raw_path = env_profile_path or "profile"
    profile_dir = Path(raw_path).expanduser()
    if not profile_dir.is_absolute():
        profile_dir = Path.cwd() / profile_dir
    return profile_dir.resolve()


PROFILE_DIR = _resolve_profile_dir()

_RUN_RE = re.compile(r"^profile_(\d+)\.txt$")
_TOTAL_TIME_RE = re.compile(r"^Total time:\s*([0-9]*\.?[0-9]+)\s*s$")
_FILE_RE = re.compile(r"^File:\s*(.+)$")
_FUNCTION_RE = re.compile(r"^Function:\s*(.+)\s+at line\s+(\d+)\s*$")
_ROW_PREFIX_RE = re.compile(r"^\s*\d+")

_PROFILE_CACHE: dict[str, dict[str, Any]] = {}

app = FastAPI()
app.mount("/static", StaticFiles(directory=APP_DIR), name="static")


@app.get("/")
def read_index() -> FileResponse:
    """Read index.html file."""
    return FileResponse(APP_DIR / "index.html")


def _format_relative_time(ts: float) -> str:
    now = datetime.now(timezone.utc).timestamp()
    delta = max(0, int(now - ts))
    if delta < 10:
        return "just now"
    if delta < 60:
        return f"{delta} seconds ago"
    minutes = delta // 60
    if minutes < 60:
        return "1 minute ago" if minutes == 1 else f"{minutes} minutes ago"
    hours = minutes // 60
    if hours < 24:
        return "1 hour ago" if hours == 1 else f"{hours} hours ago"
    days = hours // 24
    return "1 day ago" if days == 1 else f"{days} days ago"


def _run_sort_key(path: Path) -> tuple[int, str]:
    match = _RUN_RE.match(path.name)
    if match:
        return (int(match.group(1)), path.name.lower())
    return (10**9, path.name.lower())


def _safe_float(value: str | None) -> float:
    if value is None:
        return 0.0
    try:
        return float(value)
    except ValueError:
        return 0.0


def _safe_int(value: str | None) -> int:
    if value is None:
        return 0
    try:
        return int(value)
    except ValueError:
        return 0


def _build_header_layout(header_line: str) -> dict[str, Any]:
    labels = ["Line #", "Hits", "Time", "Per Hit", "% Time", "Line Contents"]
    positions: dict[str, int] = {}
    for label in labels:
        idx = header_line.find(label)
        if idx < 0:
            raise ValueError(f"Missing header label: {label}")
        positions[label] = idx

    ends = {
        "line": positions["Line #"] + len("Line #") - 1,
        "hits": positions["Hits"] + len("Hits") - 1,
        "time": positions["Time"] + len("Time") - 1,
        "per_hit": positions["Per Hit"] + len("Per Hit") - 1,
        "percent": positions["% Time"] + len("% Time") - 1,
    }
    return {"ends": ends, "content_start": positions["Line Contents"]}


def _parse_right_aligned(raw: str, start: int, end: int) -> str:
    if end < start or start >= len(raw):
        return ""
    end = min(end, len(raw) - 1)
    start = max(start, 0)
    chunk = raw[start : (end + 1)]
    return chunk.strip()


def _parse_profile_row(raw: str, layout: dict[str, Any]) -> dict[str, Any] | None:
    if not _ROW_PREFIX_RE.match(raw):
        return None

    ends = layout["ends"]
    content_start = layout["content_start"]
    boundaries = [
        (0, ends["line"], "line_raw"),
        (ends["line"] + 1, ends["hits"], "hits_raw"),
        (ends["hits"] + 1, ends["time"], "time_ms_raw"),
        (ends["time"] + 1, ends["per_hit"], "per_hit_ms_raw"),
        (ends["per_hit"] + 1, ends["percent"], "percent_time_raw"),
    ]

    raw_values: dict[str, str] = {}
    for start, end, key in boundaries:
        raw_values[key] = _parse_right_aligned(raw, start, end)

    line_raw = raw_values["line_raw"]
    if not line_raw:
        return None

    content = raw[content_start:] if 0 <= content_start <= len(raw) else ""
    return {
        "line_number": _safe_int(line_raw),
        "line_raw": line_raw,
        "hits": _safe_int(raw_values["hits_raw"] or None),
        "hits_raw": raw_values["hits_raw"],
        "time_ms": _safe_float(raw_values["time_ms_raw"] or None),
        "time_ms_raw": raw_values["time_ms_raw"],
        "per_hit_ms": _safe_float(raw_values["per_hit_ms_raw"] or None),
        "per_hit_ms_raw": raw_values["per_hit_ms_raw"],
        "percent_time": _safe_float(raw_values["percent_time_raw"] or None),
        "percent_time_raw": raw_values["percent_time_raw"],
        "content": content,
    }


def _profile_path(run_name: str) -> Path:
    run_name = os.path.basename(run_name)
    return PROFILE_DIR / f"{run_name}.txt"


def _list_profile_files() -> list[Path]:
    if not PROFILE_DIR.exists():
        return []
    files = [p for p in PROFILE_DIR.iterdir() if p.is_file() and p.suffix.lower() == ".txt"]
    files.sort(key=_run_sort_key)
    return files


def _find_table_header_idx(lines: list[str], start_idx: int) -> int:
    idx = start_idx
    while idx < len(lines) and "Line #" not in lines[idx]:
        idx += 1
    return idx


def _parse_profile_rows(
    lines: list[str], start_idx: int, header_layout: dict[str, Any]
) -> tuple[list[dict[str, Any]], int]:
    idx = start_idx
    parsed_rows: list[dict[str, Any]] = []
    if idx < len(lines) and set(lines[idx].strip()) == {"="}:
        idx += 1

    while idx < len(lines):
        raw = lines[idx]
        if not raw.strip():
            idx += 1
            continue
        if _TOTAL_TIME_RE.match(raw.strip()):
            break
        parsed_row = _parse_profile_row(raw, header_layout)
        if parsed_row is not None:
            parsed_rows.append(parsed_row)
        idx += 1
    return parsed_rows, idx


def _parse_function_block(lines: list[str], start_idx: int) -> tuple[dict[str, Any] | None, int]:
    total_match = _TOTAL_TIME_RE.match(lines[start_idx].strip())
    if not total_match:
        return None, start_idx + 1
    if start_idx + 2 >= len(lines):
        return None, len(lines)

    file_match = _FILE_RE.match(lines[start_idx + 1].strip())
    func_match = _FUNCTION_RE.match(lines[start_idx + 2].strip())
    if not file_match or not func_match:
        return None, start_idx + 1

    file_path = file_match.group(1).strip()
    function_name = func_match.group(1).strip()
    start_line = _safe_int(func_match.group(2))
    total_time = _safe_float(total_match.group(1))

    header_idx = _find_table_header_idx(lines, start_idx + 3)
    if header_idx >= len(lines):
        return None, len(lines)
    try:
        header_layout = _build_header_layout(lines[header_idx])
    except ValueError:
        return None, start_idx + 1

    parsed_rows, next_idx = _parse_profile_rows(lines, header_idx + 1, header_layout)
    function_record = {
        "id": f"{file_path}::{function_name}",
        "name": function_name,
        "file": file_path,
        "start_line": start_line,
        "total_time_s": total_time,
        "total_time_ms": total_time * 1000.0,
        "display_name": f"{function_name} ({Path(file_path).name})",
        "lines": parsed_rows,
    }
    return function_record, next_idx


def _parse_profile_text(text: str) -> dict[str, Any]:
    lines = text.splitlines()
    functions: list[dict[str, Any]] = []
    i = 0
    while i < len(lines):
        function_record, next_idx = _parse_function_block(lines, i)
        if function_record is not None:
            functions.append(function_record)
        i = next_idx

    totals = sorted(
        (
            {
                "id": f["id"],
                "name": f["name"],
                "file": f["file"],
                "start_line": f["start_line"],
                "display_name": f["display_name"],
                "total_time_s": f["total_time_s"],
                "total_time_ms": f["total_time_ms"],
            }
            for f in functions
        ),
        key=lambda item: item["total_time_ms"],
        reverse=True,
    )
    return {"functions": functions, "totals": totals}


def _get_profile_data(run_name: str) -> dict[str, Any]:
    path = _profile_path(run_name)
    if not path.exists():
        raise HTTPException(status_code=404, detail="Profile run not found.")

    mtime = path.stat().st_mtime
    cached = _PROFILE_CACHE.get(run_name)
    if cached and cached.get("mtime") == mtime:
        return cast(dict[str, Any], cached["data"])

    parsed = _parse_profile_text(path.read_text(encoding="utf-8"))
    _PROFILE_CACHE[run_name] = {"mtime": mtime, "data": parsed}
    return parsed


@app.get("/api/runs")
def list_runs() -> dict[str, list[dict[str, Any]]]:
    """List all profile runs."""
    runs: list[dict[str, Any]] = []
    for profile_path in _list_profile_files():
        run_name = profile_path.stem
        match = _RUN_RE.match(profile_path.name)
        run_index = _safe_int(match.group(1)) if match else 0
        mtime = profile_path.stat().st_mtime
        runs.append(
            {
                "name": run_name,
                "title": f"Run {run_index + 1}",
                "index": run_index,
                "updated_at": datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat(),
                "relative_time": _format_relative_time(mtime),
            }
        )
    return {"runs": runs}


@app.get("/api/profile")
def get_profile(run: str) -> dict[str, Any]:
    """Get profile data for a given run."""
    profile = _get_profile_data(run)
    return {
        "run": run,
        "functions": profile["functions"],
        "totals": profile["totals"],
    }
