"""Application Factory for Idun Agent Engine.

This module provides the main entry point for users to create a FastAPI
application with their agent integrated. It handles all the complexity of
setting up routes, dependencies, and lifecycle management behind the scenes.
"""

from collections.abc import Awaitable, Callable
from typing import Any

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import Response

from .._version import __version__
from ..server.lifespan import lifespan
from ..server.routers.agent import agent_router, register_invoke_route
from ..server.routers.base import base_router
from .config_builder import ConfigBuilder
from .engine_config import EngineConfig


def create_app(
    config_path: str | None = None,
    config_dict: dict[str, Any] | None = None,
    engine_config: EngineConfig | None = None,
) -> FastAPI:
    """Create a FastAPI application with an integrated agent.

    This is the main entry point for users of the Idun Agent Engine. It creates a
    fully configured FastAPI application that serves your agent with proper
    lifecycle management, routing, and error handling.

    Args:
        config_path: Optional path to a YAML configuration file. If not provided,
            looks for 'config.yaml' in the current directory.
        config_dict: Optional dictionary containing configuration. If provided,
            takes precedence over config_path. Useful for programmatic configuration.
        engine_config: Pre-validated EngineConfig instance (from ConfigBuilder.build()).
        Takes precedence over other options.

    Returns:
        FastAPI: A configured FastAPI application ready to serve your agent.
    """
    # Resolve configuration from various sources using ConfigBuilder's umbrella function
    validated_config = ConfigBuilder.resolve_config(
        config_path=config_path, config_dict=config_dict, engine_config=engine_config
    )

    # Resolve input model for /invoke endpoint
    try:
        input_model = ConfigBuilder.resolve_input_model(validated_config)
    except Exception as e:
        raise ValueError(f"Failed to resolve input model: {e}") from e

    # Create the FastAPI application
    app = FastAPI(
        lifespan=lifespan,
        title="Idun Agent Engine Server",
        description="A production-ready server for conversational AI agents",
        version=__version__,
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # TODO: Add a proper CORS configuration feature. We currently keep wildcard
    # CORS behavior and layer Private Network Access support on top so the
    # hosted UI can reach localhost agents from the browser.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def allow_private_network_access(
        request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        response = await call_next(request)

        if request.headers.get("access-control-request-private-network") != "true":
            return response

        if "access-control-allow-origin" in response.headers:
            response.headers["Access-Control-Allow-Private-Network"] = "true"

        return response

    # Store configuration in app state for lifespan to use
    app.state.engine_config = validated_config

    # Include the routers
    app.include_router(agent_router, prefix="/agent", tags=["Agent"])
    app.include_router(base_router, tags=["Base"])

    # TODO: DEPRECATED — register_invoke_route uses ChatRequest only now.
    # Remove when /agent/invoke shim is fully removed.
    register_invoke_route(app, input_model)

    # Register integration routers based on config
    if validated_config.integrations:
        from idun_agent_schema.engine.integrations import IntegrationProvider

        from ..integrations.discord.handler import router as discord_router
        from ..integrations.whatsapp.handler import router as whatsapp_router

        for integration in validated_config.integrations:
            match integration.provider:
                case IntegrationProvider.WHATSAPP if integration.enabled:
                    app.include_router(
                        whatsapp_router,
                        prefix="/integrations/whatsapp",
                        tags=["WhatsApp"],
                    )
                case IntegrationProvider.DISCORD if integration.enabled:
                    app.include_router(
                        discord_router,
                        prefix="/integrations/discord",
                        tags=["Discord"],
                    )
                case _:
                    pass

    return app
