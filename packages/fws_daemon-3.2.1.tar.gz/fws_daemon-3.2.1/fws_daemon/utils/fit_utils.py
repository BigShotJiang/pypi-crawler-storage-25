import re
from dataclasses import dataclass
from typing import Any, List, Optional, Union

import numpy as np
from scipy.integrate import trapezoid
from scipy.signal import savgol_filter

# --- Configuration ---


@dataclass(frozen=True)
class SignalConfig:
    """
    Configuration for signal processing parameters.
    """

    # Smoothing
    min_points_for_smoothing: int = 20
    smoothing_window: int = 15

    # Peak Detection / ROI
    fwhm_height_ratio: float = 0.5  # Ratio of peak height to define width
    sigma_multiplier: float = 3.0  # Multiplier of half-width to cover full peak
    min_radius_pixels: int = 5  # Absolute minimum radius
    default_radius_pct: float = 0.02  # Fallback if dynamic detection fails (2%)
    min_roi_percent: float = 0.25

    # Clustering (Noise Filter)
    kmeans_iterations: int = 10
    noise_signal_ratio_cutoff: float = 2.0  # Signal must be > 2x Noise to be valid
    min_signal_intensity: float = 3.0  # Absolute floor for valid signal


# Global default instance (can be overridden)
DEFAULT_CONFIG = SignalConfig()

# --- Signal Processing Core ---


def gaussian_model(
    x: np.ndarray, amplitude: float, mean: float, stddev: float, offset: float
) -> np.ndarray:
    """
    Standard Gaussian function with vertical offset.

    Args:
        x: Input domain array.
        amplitude: Height of the peak.
        mean: Center position of the peak.
        stddev: Standard deviation (width) of the peak.
        offset: Vertical baseline shift.
    """
    # Prevent division by zero
    sigma = max(abs(stddev), 1e-9)
    return amplitude * np.exp(-((x - mean) ** 2) / (2 * sigma**2)) + offset


def apply_smoothing(
    y_data: np.ndarray, window_size: int = 11, poly_order: int = 2
) -> np.ndarray:
    """
    Applies Savitzky-Golay smoothing to the data.
    """
    if y_data.size < window_size:
        return y_data

    # Ensure window_size is odd
    if window_size % 2 == 0:
        window_size += 1

    return savgol_filter(y_data, window_length=window_size, polyorder=poly_order)


def find_peak_index(y_data: np.ndarray, config: SignalConfig = DEFAULT_CONFIG) -> int:
    """
    Finds the index of the maximum value.
    Uses a simple moving average first if data is noisy/long enough.
    """
    y_abs = np.abs(y_data)

    if y_abs.size > config.min_points_for_smoothing:
        window = config.smoothing_window
        kernel = np.ones(window) / window
        # 'same' mode returns output of length max(M, N)
        smoothed = np.convolve(y_abs, kernel, mode="same")
        return int(np.argmax(smoothed))

    return int(np.argmax(y_abs))


def _calculate_dynamic_radius(
    y_abs: np.ndarray, peak_idx: int, config: SignalConfig
) -> int:
    """
    Internal helper to calculate ROI radius based on FWHM.
    """
    peak_val = y_abs[peak_idx]
    threshold = peak_val * config.fwhm_height_ratio
    total_points = y_abs.size

    # Boolean mask where signal is below FWHM threshold
    below_thresh = y_abs < threshold

    # 1. Scan Left
    # Find indices to the left of peak that are below threshold
    left_mask = below_thresh[:peak_idx]
    # Find the *last* index that is True (closest to peak on the left)
    left_candidates = np.where(left_mask)[0]
    left_bound = left_candidates[-1] if left_candidates.size > 0 else 0

    # 2. Scan Right
    # Find indices to the right of peak
    right_mask = below_thresh[peak_idx + 1 :]
    right_candidates = np.where(right_mask)[0]
    # Find the *first* index that is True (closest to peak on the right)
    # Note: Add (peak_idx + 1) to offset the slice
    right_bound = (
        (peak_idx + 1 + right_candidates[0])
        if right_candidates.size > 0
        else (total_points - 1)
    )

    # 3. Calculate Width
    hw_left = peak_idx - left_bound
    hw_right = right_bound - peak_idx
    avg_half_width = (hw_left + hw_right) / 2.0

    # 4. Apply Heuristics
    estimated_radius = int(avg_half_width * config.sigma_multiplier)

    # Fallback to default percentage if radius is too small
    if estimated_radius < config.min_radius_pixels:
        default_radius = int(total_points * config.default_radius_pct)
        return max(default_radius, config.min_radius_pixels)

    return estimated_radius


def extract_peak_roi_mask(
    y_data: np.ndarray,
    roi_percent: Optional[float] = None,
    config: SignalConfig = DEFAULT_CONFIG,
) -> np.ndarray:
    """
    Generates a boolean mask for the Region of Interest (ROI) around the peak.

    The ROI can be determined either by a fixed percentage of the total data length
    or dynamically based on the Full Width at Half Maximum (FWHM).

    Returns:
        mask: Boolean array of the same shape as y_data, True for indices within ROI.
    """
    if y_data.size == 0:
        raise ValueError("y_data cannot be empty.")

    y_abs = np.abs(y_data)
    total_points = y_data.size

    # 1. Detect Peak
    peak_idx = find_peak_index(y_abs, config)

    # 2. Determine Initial Radius
    if roi_percent and roi_percent > 0:
        # Fixed Percentage Mode
        actual_percent = roi_percent
        radius = int(total_points * (actual_percent / 100.0))
    else:
        # Dynamic Mode (Dynamic ROI based on signal width)
        radius = _calculate_dynamic_radius(y_abs, peak_idx, config)
        actual_percent = (radius / total_points) * 100.0

    # 3. Apply Minimum ROI Constraints
    # Ensure we respect the minimum ROI percentage defined in the config
    if actual_percent < config.min_roi_percent:
        actual_percent = config.min_roi_percent
        radius = int(total_points * (actual_percent / 100.0))

    # Safety check: Ensure radius captures at least some pixels to avoid empty masks
    radius = max(radius, 2)

    # Account for potential peak detection shifts due to smoothing
    # Smoothing window can shift peak by up to smoothing_window//2 indices
    smoothing_shift_buffer = (
        config.smoothing_window // 2
        if total_points > config.min_points_for_smoothing
        else 0
    )
    radius = max(radius, smoothing_shift_buffer + 2)

    # 4. Generate Mask Boundaries
    # Note: end_idx is inclusive, so we use end_idx + 1 in the slice
    start_idx = max(0, peak_idx - radius)
    end_idx = min(total_points - 1, peak_idx + radius)

    # 5. Build Boolean Mask
    mask = np.zeros(total_points, dtype=bool)
    mask[start_idx : end_idx + 1] = True

    return mask


def separate_signal_noise(
    y_vals: np.ndarray, config: SignalConfig = DEFAULT_CONFIG
) -> np.ndarray:
    """
    Separates Signal from Noise using 1D K-Means clustering on Log-Intensity.

    Returns:
        Boolean mask where True represents 'Signal'.
    """
    y_arr = np.array(y_vals)
    n_points = len(y_arr)

    if n_points < 3:
        return np.ones(n_points, dtype=bool)

    # 1. Convert to Log-Space
    # Use log10 to handle varying orders of magnitude.
    # Clip at 1e-9 to handle zeros/negatives safely.
    y_log = np.log10(np.maximum(y_arr, 1e-9))

    # 2. Initialize Centroids (Min/Max initialization)
    centroid_noise = np.min(y_log)
    centroid_signal = np.max(y_log)

    # 3. K-Means Iteration
    # Usually converges very quickly for 1D bi-modal data.
    for _ in range(config.kmeans_iterations):
        dist_noise = np.abs(y_log - centroid_noise)
        dist_signal = np.abs(y_log - centroid_signal)

        # Assign clusters
        mask_signal = dist_signal < dist_noise
        mask_noise = ~mask_signal

        # Update centroids if clusters are not empty
        if np.any(mask_signal):
            centroid_signal = np.mean(y_log[mask_signal])
        if np.any(mask_noise):
            centroid_noise = np.mean(y_log[mask_noise])

        # Check convergence (optional optimization, purely distance based)
        if abs(centroid_signal - centroid_noise) < 0.05:
            break

    # 4. Determine Cutoff Threshold
    log_cutoff = (centroid_noise + centroid_signal) / 2.0
    threshold = 10**log_cutoff

    # 5. Safety Heuristics
    # Check if signal is actually distinguishable from noise
    signal_linear = 10**centroid_signal
    noise_linear = 10**centroid_noise

    ratio_check = signal_linear < (config.noise_signal_ratio_cutoff * noise_linear)
    absolute_check = signal_linear < config.min_signal_intensity

    if ratio_check or absolute_check:
        # If signal is too weak or too similar to noise, treat all as noise
        return np.zeros(n_points, dtype=bool)

    return y_arr > threshold


# --- Metrics & Analysis ---


def calculate_integral(
    x_data: np.ndarray, y_data: np.ndarray, baseline_val: Optional[float] = None
) -> float:
    """
    Calculates the physical area (trapezoidal integration).

    Args:
        x_data: x-axis array.
        y_data: y-axis array.
        baseline_val: If provided, this value is subtracted from y_data
                      before integration. If None, integrates raw data.
    """
    y_corr = y_data - baseline_val if baseline_val is not None else y_data
    area = trapezoid(y_corr, x_data)
    return abs(area)


def calculate_centroid(
    x_data: np.ndarray, y_data: np.ndarray, baseline_val: Optional[float] = None
) -> float:
    """
    Calculates the Center of Mass (Centroid).

    Args:
        x_data: x-axis array.
        y_data: y-axis array.
        baseline_val: If provided, subtracts baseline. Essential for accurate
                      centroid calculation to remove noise floor bias.
    """
    if y_data.size == 0:
        return 0.0

    y_corr = y_data - baseline_val if baseline_val is not None else y_data

    # Rectification: Zero out negative values after baseline subtraction
    # to prevent negative mass from skewing the centroid.
    y_rectified = np.maximum(y_corr, 0)

    total_mass = np.sum(y_rectified)

    if total_mass == 0:
        if y_data.size > 0:
            return float(x_data[np.argmax(y_data)])
        return 0.0

    centroid = np.sum(x_data * y_rectified) / total_mass
    return float(centroid)


def normalize_data(
    y_data: np.ndarray, norm_value: Union[float, np.ndarray, list]
) -> Optional[np.ndarray]:
    """
    Normalizes data by a scalar or array.
    Handles array wrapping safely.
    """
    scalar_norm: float = 0.0

    if isinstance(norm_value, (np.ndarray, list)):
        # Extract first element if array provided
        flat = np.ravel(norm_value)
        if flat.size > 0:
            scalar_norm = float(flat[0])
    else:
        scalar_norm = float(norm_value)

    if scalar_norm == 0:
        return None

    return y_data / scalar_norm


# --- HDF5 Utilities ---


def get_scan_keys(hdf_group: Any) -> List[str]:
    """
    Returns keys matching the 'scan_N' pattern from an HDF5 group.
    Assumes hdf_group behaves like h5py.Group.
    """
    pattern = re.compile(r"^scan_\d+$", re.IGNORECASE)
    # Use .keys() safely
    if not hasattr(hdf_group, "keys"):
        return []

    keys = [k for k in hdf_group.keys() if pattern.match(k)]

    # Sort naturally (e.g. scan_2 before scan_10)
    # This splits 'scan_10' into ['scan_', 10] for sorting
    def natural_sort_key(s):
        return [
            int(text) if text.isdigit() else text.lower()
            for text in re.split("([0-9]+)", s)
        ]

    return sorted(keys, key=natural_sort_key)


def get_scalar_from_dataset(hdf_group: Any, path: str, default: float = 0.0) -> float:
    """
    Safely extracts a single float value from an HDF5 dataset.
    """
    if path not in hdf_group:
        return default

    try:
        value = hdf_group[path][()]
        # Handle 0-d arrays or lists
        return float(np.ravel(value)[0])
    except (IndexError, TypeError, ValueError):
        return default
