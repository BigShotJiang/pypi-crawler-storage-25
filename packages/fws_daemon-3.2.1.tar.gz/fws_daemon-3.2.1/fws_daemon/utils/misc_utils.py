import datetime
import os
from typing import Optional


def _format_range(position_scan: Optional[tuple[float, float]]) -> str:
    """Format position range for filename: start_end in mm, or 'fix' if no range."""
    if position_scan is None:
        return "fix"
    start, end = position_scan
    return f"{start:.1f}_{end:.1f}".replace(".0", "")


def generate_filename(
    prefix: str,
    position_scan: Optional[tuple[float, float]] = None,
    num_scans: Optional[int] = None,
) -> str:
    """Generate a compact HDF5 filename: scanner, range, n-scans, timestamp.

    Format: {prefix}_{range}_{n}{num_scans}_{YYYYMMDD-HHMM}.h5
    Example: FWS01_0_10_n3_20250217-1430.h5

    Args:
        prefix: Scanner prefix (e.g. FWS01, PyTest). Must be non-empty.
        position_scan: Optional (start, end) tuple in mm.
        num_scans: Optional number of scan iterations.

    Returns:
        Formatted HDF5 filename string.

    Raises:
        ValueError: If prefix is empty or whitespace-only.
    """
    if not prefix or not prefix.strip():
        raise ValueError("prefix must be non-empty (scanner identifier is required)")
    range_str = _format_range(position_scan)
    scans_str = f"n{num_scans}" if num_scans is not None else "n?"
    timestamp = datetime.datetime.now().strftime("%Y%m%d-%H%M")
    return f"{prefix}_{range_str}_{scans_str}_{timestamp}.h5"


def create_output_path(folder_name: str) -> str:
    """
    Create a folder with the specified name if it does not already exist.

    Returns the full folder path, or None on failure.
    """
    try:
        os.makedirs(folder_name, exist_ok=True)
        return folder_name
    except Exception as e:
        print(f"An error occurred while creating the folder: {e}")
        return None


def generate_output_path(
    prefix: str,
    output_path: str,
    position_scan: Optional[tuple[float, float]] = None,
    num_scans: Optional[int] = None,
) -> Optional[str]:
    """
    Create the output folder (if needed) and return the full file path
    for the generated filename (scanner + range + n-scans + timestamp).
    """
    folder = create_output_path(output_path)
    if folder is None:
        return None

    filename = generate_filename(
        prefix=prefix,
        position_scan=position_scan,
        num_scans=num_scans,
    )
    return os.path.join(folder, filename)
