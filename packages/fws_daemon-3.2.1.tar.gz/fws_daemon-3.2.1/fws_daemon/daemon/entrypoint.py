"""
Entry point for the FWS scan daemon backed by epics-bridge.
"""
import argparse
import logging
import sys
from contextlib import ExitStack
from pathlib import Path
from typing import List

from epics_bridge import LoggingManager

from .callback_loader import load_callbacks
from .daemon import FWSScanBridgeDaemon
from .interface import FWSScanInterface, IOCPrefixes

logger = logging.getLogger(__name__)


def default_log_dir(scanner_index: int) -> Path:
    """Return the default log directory for the given scanner index."""
    return Path(f"var/log/fws-daemon/fws-{scanner_index:02d}")


def parse_args() -> argparse.Namespace:
    """Parse and validate command-line arguments for the FWS scan daemon."""
    parser = argparse.ArgumentParser(
        description="EPICS Bridge-based FWS Scan Daemon",
    )
    parser.add_argument(
        "scanner_index",
        type=int,
        help="Index of the FWS scanner (e.g., 1 for FWS 1)",
    )
    parser.add_argument(
        "--test-mode",
        action="store_true",
        default=False,
        help="Run the daemon in test mode (uses Test:SCAN: prefixes).",
    )
    parser.add_argument(
        "--log-dir",
        type=str,
        default=None,
        help=(
            "Directory for daemon logs. "
            "If omitted, defaults to var/log/fws-daemon/fws-<NN> where <NN> is the "
            "zero-padded scanner index (same numbering as the scanner instance)."
        ),
    )
    parser.add_argument(
        "--custom-callback",
        type=Path,
        default=None,
        help=(
            "Path to a Python script (.py) defining 'get_pre_callback' "
            "and/or 'get_post_callback'."
        ),
    )
    return parser.parse_args()


# -----------------------------------------------------------------------------
# Daemon wiring
# -----------------------------------------------------------------------------


def build_pv_prefixes(prefixes: IOCPrefixes) -> dict:
    """Build the PV prefix mapping expected by FWSScanInterface."""
    return {
        "main": prefixes.DAEMON_PV_PREFIX,
        "scan": prefixes.SCAN_PV_PREFIX,
        "idc": prefixes.IDC_PV_PREFIX,
        "evr": prefixes.EVR_PV_PREFIX,
        "struck": prefixes.STRUCK_PV_PREFIX,
        "be": prefixes.BE_PV_PREFIX,
    }


def create_daemon(
    args: argparse.Namespace,
    logging_manager: LoggingManager,
    pre_callbacks: List[object],
    post_callbacks: List[object],
) -> FWSScanBridgeDaemon:
    """Build the PV interface and daemon instance from parsed args and callbacks."""
    prefixes = IOCPrefixes(args.scanner_index, test_mode=args.test_mode)
    interface = FWSScanInterface(
        prefixes=build_pv_prefixes(prefixes),
    )
    return FWSScanBridgeDaemon(
        interface=interface,
        logging_manager=logging_manager,
        scanner_idx=args.scanner_index,
        test_mode=args.test_mode,
        pre_scan_callbacks=pre_callbacks,
        post_scan_callbacks=post_callbacks,
    )


def main() -> None:
    """Run the FWS scan daemon (epics-bridge backend)."""
    args = parse_args()
    log_dir = (
        args.log_dir
        if args.log_dir is not None
        else str(default_log_dir(args.scanner_index))
    )
    logging_manager = LoggingManager(
        daemon_log_dir=log_dir,
    )

    logger.info("Starting FWSScanBridgeDaemon with args: %s", args)
    logger.info("Log Directory: %s", log_dir)

    with ExitStack() as stack:
        pre_callbacks, post_callbacks = load_callbacks(args, stack, logger)
        daemon = create_daemon(args, logging_manager, pre_callbacks, post_callbacks)

        try:
            daemon.start()
        except KeyboardInterrupt:
            logger.info("KeyboardInterrupt received. Stopping daemon...")
            daemon.stop()
        except Exception:
            logger.exception("Fatal error during bridge daemon execution")
            sys.exit(1)
        finally:
            logging_manager.stop()


if __name__ == "__main__":
    main()
