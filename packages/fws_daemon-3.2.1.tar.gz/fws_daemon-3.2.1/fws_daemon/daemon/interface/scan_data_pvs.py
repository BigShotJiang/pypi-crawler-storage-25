"""PV suffix registry and YAML loaders for scan data collection."""

from functools import lru_cache
from pathlib import Path

import yaml

SuffixMap = dict[str, list[str]]

SCAN_DATA_FILE_NAME = "scan_data.yaml"
SCAN_METADATA_FILE_NAME = "scan_metadata.yaml"


def _validate_suffix_map(raw_value: object, source: Path) -> SuffixMap:
    """Validate and normalize a raw YAML value into a suffix map."""
    if not isinstance(raw_value, dict):
        raise ValueError(
            f"Invalid YAML format in {source}: expected mapping at top level"
        )

    validated: SuffixMap = {}
    for group_key, suffixes in raw_value.items():
        if not isinstance(group_key, str) or not group_key.strip():
            raise ValueError(f"Invalid group key in {source}: {group_key!r}")
        if not isinstance(suffixes, list):
            raise ValueError(
                f"Invalid group value in {source} for '{group_key}': expected list[str]"
            )
        if any(not isinstance(suffix, str) for suffix in suffixes):
            raise ValueError(
                f"Invalid suffix value in {source} for '{group_key}': expected list[str]"
            )
        validated[group_key] = list(suffixes)
    return validated


def _load_suffix_map(path: Path) -> SuffixMap:
    """Load and validate a YAML suffix map from disk."""
    if not path.exists():
        raise FileNotFoundError(f"Scan PV config file not found: {path}")
    if not path.is_file():
        raise ValueError(f"Scan PV config path is not a file: {path}")

    with path.open("r", encoding="utf-8") as handle:
        loaded = yaml.safe_load(handle)
    return _validate_suffix_map(loaded, path)


def _copy_suffix_map(source: SuffixMap) -> SuffixMap:
    """Create a deep copy of a suffix map."""
    return {group_key: list(suffixes) for group_key, suffixes in source.items()}


@lru_cache(maxsize=1)
def _load_default_scan_pv_suffixes() -> tuple[SuffixMap, SuffixMap]:
    """Load packaged scan-data and scan-metadata suffixes once."""
    base_dir = Path(__file__).resolve().parent
    data_path = base_dir / SCAN_DATA_FILE_NAME
    metadata_path = base_dir / SCAN_METADATA_FILE_NAME
    return _load_suffix_map(data_path), _load_suffix_map(metadata_path)


def load_scan_pv_suffixes() -> tuple[SuffixMap, SuffixMap]:
    """
    Load scan-data and scan-metadata suffixes from packaged YAML files.

    Returns defensive copies so callers cannot mutate shared cached defaults.
    """
    scan_data, scan_metadata = _load_default_scan_pv_suffixes()
    return _copy_suffix_map(scan_data), _copy_suffix_map(scan_metadata)


def load_scan_pv_suffixes_from_file(path: Path) -> SuffixMap:
    """Load and validate a suffix map from an explicit YAML file path."""
    return _load_suffix_map(path)


class ScanDataPVSuffixes:
    """Compatibility wrapper around lazily loaded scan PV suffix maps."""

    @classmethod
    def scan_data_suffixes(cls) -> SuffixMap:
        """Return a copy of packaged scan-data suffix mappings."""
        scan_data, _ = load_scan_pv_suffixes()
        return scan_data

    @classmethod
    def scan_metadata_suffixes(cls) -> SuffixMap:
        """Return a copy of packaged scan-metadata suffix mappings."""
        _, scan_metadata = load_scan_pv_suffixes()
        return scan_metadata
