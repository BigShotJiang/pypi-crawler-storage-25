"""
Canonical PV naming and IOC prefix configuration for the FWS scan daemon.

Public API — import from here:
  - FWSScanInterface: bridge-facing PV interface (epics-bridge)
  - IOCPrefixes: scanner index → prefix resolution (SCAN, IDC, EVR, etc.)
  - ScannerAuxiliary: BPM PV list per scanner index (for plots x_offset resolution)
  - ScanDataPVSuffixes: suffix mappings for scan data/metadata collection
"""

from .main_interface import FWSScanInterface
from .pv_prefixes import IOCPrefixes
from .scan_data_pvs import ScanDataPVSuffixes
from .scanner_auxiliary import ScannerAuxiliary

__all__ = [
    "FWSScanInterface",
    "IOCPrefixes",
    "ScanDataPVSuffixes",
    "ScannerAuxiliary",
]
