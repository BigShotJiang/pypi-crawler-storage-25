"""Channel list and PV-type definitions for scan statistics."""

from typing import Dict

from epics_bridge import PV

DAQ_PLACEHOLDER_TEMPLATE = "{main}"

CHANNELS: list[str] = [
    "v_pdr",
    "v_pdl",
    "h_pdt",
    "h_pdb",
    "v_apdt",
    "v_apdb",
    "h_apdr",
    "h_apdl",
]

CHANNEL_PV_TYPES: Dict[str, str] = {
    "integral": "Integral",
    "int_pos": "IntPos",
    "gauss_fit": "GaussFit",
    "fit_pos": "FitPos",
    "amp": "Amp",
    "mean": "Mean",
    "sigma": "Sigma",
    "fwhm": "FWHM",
}


def build_channel_map_pvs() -> Dict[str, Dict[str, str | PV]]:
    """Build channel map using PV objects for metric entries.

    This is the v3-facing map. It keeps `daq_match` as a plain string because
    it is used for key matching, not for EPICS I/O.
    """
    channel_map: Dict[str, Dict[str, str | PV]] = {}
    for channel in CHANNELS:
        pv_base = channel.replace("_", "-").upper()
        channel_map[channel] = {
            "daq_match": channel.upper().replace("_", "-"),
        }
        for pv_key, pv_suffix in CHANNEL_PV_TYPES.items():
            channel_map[channel][pv_key] = PV(
                f"{DAQ_PLACEHOLDER_TEMPLATE}{pv_base}-{pv_suffix}"
            )
    return channel_map
