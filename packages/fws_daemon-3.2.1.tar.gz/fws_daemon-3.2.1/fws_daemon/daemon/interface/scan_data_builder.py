"""Builders for grouped PV objects (scan data + scan metadata)."""

from __future__ import annotations

from typing import Dict, List

from epics_bridge import PV, PVField


def build_scan_data_pv_objects(
    template_map: Dict[str, List[str]],
) -> Dict[str, List[PV]]:
    """Build grouped PV objects from template strings per YAML group key.

    Entries use placeholders such as ``{idc}RdcSpd`` or ``{scan}ScanStatus``.
    Top-level keys are only for grouping (e.g. HDF5 subgroups); they do not
    select the prefix. Runtime YAML may use full PV names instead.
    """
    grouped: Dict[str, List[PV]] = {}
    for group_key, templates in template_map.items():
        grouped[group_key] = [
            PV(
                template,
                fields=[PVField("EGU", cast_type=str)],
            )
            for template in templates
        ]
    return grouped


def flatten_grouped_pv_objects(grouped: Dict[str, List[PV]]) -> List[PV]:
    """Flatten grouped PV object lists into a single list (stable order)."""
    pv_list: List[PV] = []
    for group in grouped.values():
        pv_list.extend(group)
    return pv_list
