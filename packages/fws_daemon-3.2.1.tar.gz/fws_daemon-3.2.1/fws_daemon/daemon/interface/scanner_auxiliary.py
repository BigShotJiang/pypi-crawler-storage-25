"""
Scanner-index–dependent BPM PV list for a given FWS scanner.

Separate from IOCPrefixes (PV prefixes only). Used by plots for x_offset
data path resolution. HDF5 file naming is derived from scanner index at the
call site (e.g. daemon).
"""


class ScannerAuxiliary:
    """
    BPM PV list for a given FWS scanner index.

    Attributes:
        BPMS: List of full BPM PV names used for x_offset path in HDF5.
    """

    def __init__(self, fws_index: int, test_mode: bool = False) -> None:
        if test_mode:
            self._set_test_values()
        else:
            self._set_production_values(fws_index)

    def _set_production_values(self, fws_index: int) -> None:
        related_scanner_bpms = {
            1: [
                "HEBT-090LWU:PBI-BPM-001:YP-AvgValue",
                "HEBT-100LWU:PBI-BPM-001:YP-AvgValue",
            ],
            2: [
                "HEBT-090LWU:PBI-BPM-001:XP-AvgValue",
                "HEBT-100LWU:PBI-BPM-001:XP-AvgValue",
            ],
            3: [
                "HEBT-120LWU:PBI-BPM-001:YP-AvgValue",
                "HEBT-130LWU:PBI-BPM-001:YP-AvgValue",
            ],
            4: [
                "HEBT-120LWU:PBI-BPM-001:XP-AvgValue",
                "HEBT-130LWU:PBI-BPM-001:XP-AvgValue",
            ],
            5: [
                "HEBT-150LWU:PBI-BPM-001:YP-AvgValue",
                "HEBT-160LWU:PBI-BPM-001:YP-AvgValue",
            ],
            6: [
                "HEBT-150LWU:PBI-BPM-001:XP-AvgValue",
                "HEBT-160LWU:PBI-BPM-001:XP-AvgValue",
            ],
            99: [
                "Test:BPM1:",
                "Test:BPM2:",
            ],
        }
        self.BPMS = related_scanner_bpms.get(fws_index, ["Test:BPM1:", "Test:BPM2:"])

    def _set_test_values(self) -> None:
        self.BPMS = ["Test:BPM1:", "Test:BPM2:"]
