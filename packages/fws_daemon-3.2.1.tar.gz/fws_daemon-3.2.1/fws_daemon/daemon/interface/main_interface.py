from typing import Dict

from epics_bridge import PV, BasePVInterface

from fws_daemon.scan.directive import ScanDirective

from .daq_channels import build_channel_map_pvs as _build_channel_map_pvs
from .scan_data_builder import build_scan_data_pv_objects, flatten_grouped_pv_objects
from .scan_data_pvs import load_scan_pv_suffixes


class FWSScanInterface(BasePVInterface):
    """
    EPICS Bridge interface for the FWS scan daemon.

    This mirrors the existing `PVConfigs` mapping used by `EpicsIO`, but expressed
    in the typed, prefix-aware style expected by `epics-bridge`.

    Prefix placeholders:
      - {main}: daemon PV prefix (e.g. "FWS:SCAN:01:DMN-"
        for Trigger/Busy/NumScans/etc.)
      - {scan}: scan IOC prefix for hardware PVs
        (e.g. "FWS:SCAN:01:" for RunHardScan/PosToDelay)

    Standard control/monitor PVs like Trigger/Busy/Heartbeat/TaskStatus are
    inherited from `BasePVInterface` and use {main}. Hardware PVs use {scan}.

    All PV groups (channel map, scan-data PVs, scan-metadata PVs) are resolved
    once at instantiation and exposed as attributes. No on-demand builders.
    """

    def __init__(
        self,
        prefixes: dict[str, str] | None = None,
    ) -> None:
        super().__init__(prefixes=prefixes)
        self.scan_data_suffixes, self.scan_metadata_suffixes = load_scan_pv_suffixes()

        # --- Input PVs (scan configuration) ---
        self.num_scans = PV("{main}NumScans", cast_type=int, tags=["input"])
        self.relative_scan = PV("{main}RelativeScan", cast_type=bool, tags=["input"])
        self.center_position = PV(
            "{main}CenterPosition", cast_type=float, tags=["input"]
        )
        self.scan_start = PV("{main}ScanStart", cast_type=float, tags=["input"])
        self.scan_end = PV("{main}ScanEnd", cast_type=float, tags=["input"])
        self.output_path = PV("{main}OutputPath", cast_type=str, tags=["input"])
        self.data_file_path = PV("{main}DataFilePath", cast_type=str, tags=["input"])
        self.metadata_file_path = PV(
            "{main}MetadataFilePath", cast_type=str, tags=["input"]
        )
        self.file_name = PV("{main}FileName", cast_type=str, tags=["status"])

        self.scan_current_step = PV(
            "{main}ScanCurrentStep", cast_type=int, tags=["status"]
        )
        self.scan_elapsed_time = PV(
            "{main}ScanElapsedTime", cast_type=float, tags=["status"]
        )

        # --- Scan control PV ---
        self.scan_control = PV(
            "{main}ScanControl", cast_type=ScanDirective, tags=["control"]
        )

        # --- Hardware PVs (scan hardware interface) ---
        self.cmd_hard_scan = PV("{scan}RunHardScan", cast_type=int, tags=["control"])
        self.cmd_soft_scan = PV("{scan}RunSoftScan", cast_type=int, tags=["control"])
        self.cmd_auto_calc = PV("{scan}TrigPosAuto", cast_type=int, tags=["control"])
        self.status_code = PV("{scan}ScanStatus", cast_type=int, tags=["status"])
        self.setting_pos = PV("{scan}PosToDelay", cast_type=float, tags=["control"])

        # v3 map with PV objects.
        self.channel_map_pvs: Dict[str, Dict[str, str | PV]] = _build_channel_map_pvs()

        # v3 grouped PV object collections (VAL + EGU).
        self.scan_data_pvs: dict[str, list[PV]] = build_scan_data_pv_objects(
            self.scan_data_suffixes,
        )
        self.scan_metadata_pvs_grouped: dict[
            str, list[PV]
        ] = build_scan_data_pv_objects(
            self.scan_metadata_suffixes,
        )
        self.scan_metadata_pvs: list[PV] = flatten_grouped_pv_objects(
            self.scan_metadata_pvs_grouped
        )
