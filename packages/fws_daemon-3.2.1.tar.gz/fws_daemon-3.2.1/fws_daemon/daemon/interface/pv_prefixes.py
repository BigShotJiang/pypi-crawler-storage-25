class IOCPrefixes:
    """EPICS PV prefix configuration for FWS scan IOC and daemon."""

    DAEMON_SUFFIX = "DMN-"
    EVR_PV_PREFIX = "PBI-WS06:Ctrl-EVR-101:"

    STRUCK_INDEXES = {
        1: "110",
        2: "110",
        3: "120",
        4: "120",
        5: "130",
        6: "130",
    }

    BE_INDEXES = {
        1: "001",
        2: "001",
        3: "002",
        4: "002",
        5: "003",
        6: "003",
    }

    IDC_DELAY_SUFFIX = {
        1: "DlyGen-1-Delay-SP",
        2: "DlyGen-2-Delay-SP",
        3: "DlyGen-4-Delay-SP",
        4: "DlyGen-5-Delay-SP",
        5: "DlyGen-7-Delay-SP",
        6: "DlyGen-8-Delay-SP",
    }

    def __init__(self, fws_index, test_mode=False):
        if test_mode:
            self.get_test_prefix()
        else:
            self.get_prefix(fws_index)

    def get_prefix(self, fws_index):
        # Generate base index dynamically for indices 0-99
        if not (0 <= fws_index <= 99):
            raise ValueError(f"fws_index must be between 0 and 99, got {fws_index}")
        base_idx = f"{fws_index:03d}"
        struck_idx = self.STRUCK_INDEXES[fws_index]
        be_idx = self.BE_INDEXES[fws_index]
        delay_suffix = self.IDC_DELAY_SUFFIX[fws_index]

        self.SCAN_PV_PREFIX = f"PBI-WS06:Ctrl-SCAN-{base_idx}:"
        self.DAEMON_PV_PREFIX = self.SCAN_PV_PREFIX + self.DAEMON_SUFFIX
        self.IDC_PV_PREFIX = f"PBI-WS06:Ctrl-IDC-{base_idx}:"
        self.STRUCK_PV_PREFIX = f"PBI-WS06:Ctrl-AMC-{struck_idx}:"
        self.BE_PV_PREFIX = f"PBI-WS06:PBI-WSBE-{be_idx}:"
        self.IDC_DELAY_PV = self.EVR_PV_PREFIX + delay_suffix

    def get_test_prefix(self):
        self.EVR_PV_PREFIX = "Test:EVR:"
        self.SCAN_PV_PREFIX = "Test:SCAN:"
        self.DAEMON_PV_PREFIX = self.SCAN_PV_PREFIX + self.DAEMON_SUFFIX
        self.IDC_PV_PREFIX = "Test:IDC:"
        self.STRUCK_PV_PREFIX = "Test:STRUCK:"
        self.BE_PV_PREFIX = "Test:BE:"
        self.IDC_DELAY_PV = "Test:EVR:DlyGen-1-Delay-SP"
