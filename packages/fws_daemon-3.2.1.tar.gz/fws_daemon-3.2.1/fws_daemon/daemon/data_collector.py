"""
Scan data collector — fetches PVs for each scan iteration.

Responsible for building PV name lists from suffix mappings and fetching
values via the daemon's io layer. Returns structured data dicts that
callbacks (like HDF5WriterCallback, GaussFitCallback) can consume.

Performance / grouping
---------------------
``_fetch_grouped_pvs()`` flattens grouped PVs once, builds a ``pv_to_group``
reverse map (O(n)), issues a single ``pvget`` for the flat list, then regroups
successful PVs. Failed fetches (``val is None``) are summarized in debug logs.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable, Dict, List, Tuple

from epics_bridge import PV, BridgeIO

from .interface import FWSScanInterface
from .interface.scan_data_builder import (
    build_scan_data_pv_objects,
    flatten_grouped_pv_objects,
)
from .interface.scan_data_pvs import load_scan_pv_suffixes_from_file

logger = logging.getLogger(__name__)


class ScanDataCollector:
    """Fetches EPICS PV data for scan iterations.

    Args:
        interface: Canonical PV naming interface (source of PV groups/lists).
        io: The daemon's IO layer (``epics_bridge.BridgeIO``).
    """

    DEFAULT_TIMEOUT = 2.0

    def __init__(self, interface: FWSScanInterface, io: BridgeIO):
        self.interface = interface
        self.io = io
        self._runtime_scan_data_path: str | None = None
        self._runtime_scan_data_pvs: Dict[str, List[PV]] = {}
        self._runtime_scan_metadata_path: str | None = None
        self._runtime_scan_metadata_pvs: List[PV] = []

    def collect_scan_data(self) -> Dict[str, List[PV]]:
        """Fetch all scan data PVs.

        Returns:
            Grouped PV objects: ``{group_key: [PV, ...]}``
        """
        grouped = self.interface.scan_data_pvs
        runtime_grouped = self._load_runtime_scan_data_pvs()
        merged = self._merge_grouped_pvs(grouped, runtime_grouped)
        return self._fetch_grouped_pvs(merged)

    def collect_scan_metadata(self) -> List[PV]:
        """Fetch scan metadata PVs.

        Returns:
            Flat PV list with in-place values populated.
        """
        pvs = self.interface.scan_metadata_pvs + self._load_runtime_scan_metadata_pvs()
        pvs = self._dedupe_pvs(pvs)

        if not pvs:
            return []

        self.io.pvget(pvs, only_val=True, timeout=self.DEFAULT_TIMEOUT)

        return [pv for pv in pvs if pv.val is not None]

    def format_scan_metadata_raw_attrs(self) -> Dict[str, Any]:
        """Format fetched scan metadata as raw-value root attributes.

        Returns:
            Dict keyed by full PV name with PV raw values.
        """
        attrs: Dict[str, Any] = {}
        for pv in self.collect_scan_metadata():
            attrs[pv.name] = pv.raw
        return attrs

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_runtime_scan_data_pvs(self) -> Dict[str, List[PV]]:
        """Load runtime scan-data PV groups from file path PV, if configured."""
        loaded = self._load_runtime_pvs_from_yaml(
            path_attr_name="data_file_path",
            cached_path_attr="_runtime_scan_data_path",
            cached_result_attr="_runtime_scan_data_pvs",
            result_transform=lambda grouped: grouped,
            empty_result={},
            context_label="scan-data",
        )
        return loaded if isinstance(loaded, dict) else {}

    def _load_runtime_scan_metadata_pvs(self) -> List[PV]:
        """Load runtime scan-metadata PV list from file path PV, if configured."""
        loaded = self._load_runtime_pvs_from_yaml(
            path_attr_name="metadata_file_path",
            cached_path_attr="_runtime_scan_metadata_path",
            cached_result_attr="_runtime_scan_metadata_pvs",
            result_transform=flatten_grouped_pv_objects,
            empty_result=[],
            context_label="scan-metadata",
        )
        return loaded if isinstance(loaded, list) else []

    def _load_runtime_pvs_from_yaml(
        self,
        path_attr_name: str,
        cached_path_attr: str,
        cached_result_attr: str,
        result_transform: Callable[[Dict[str, List[PV]]], Any],
        empty_result: Any,
        context_label: str,
    ) -> Any:
        """Shared runtime loader for optional YAML-driven PV collections (full names)."""
        path_val = self._read_optional_path_pv(path_attr_name)
        if not path_val:
            setattr(self, cached_path_attr, None)
            setattr(self, cached_result_attr, empty_result)
            return empty_result

        cached_path = getattr(self, cached_path_attr)
        if path_val == cached_path:
            return getattr(self, cached_result_attr)

        try:
            suffix_map = load_scan_pv_suffixes_from_file(Path(path_val))
            # Runtime files use full PV names (no placeholders / no substitution).
            grouped = build_scan_data_pv_objects(suffix_map)
            result = result_transform(grouped)
            setattr(self, cached_result_attr, result)
            setattr(self, cached_path_attr, path_val)
        except Exception as exc:
            logger.warning(
                "Failed to load runtime %s suffix file '%s': %s",
                context_label,
                path_val,
                exc,
            )
            setattr(self, cached_path_attr, None)
            setattr(self, cached_result_attr, empty_result)

        return getattr(self, cached_result_attr)

    def _read_optional_path_pv(self, attr_name: str) -> str | None:
        """Read an optional path PV attribute from the interface."""
        path_pv = getattr(self.interface, attr_name, None)
        if path_pv is None:
            return None
        self.io.pvget(path_pv, timeout=self.DEFAULT_TIMEOUT)
        value = path_pv.val
        if value is None:
            return None
        candidate = str(value).strip()
        return candidate if candidate else None

    @staticmethod
    def _merge_grouped_pvs(
        base_grouped: Dict[str, List[PV]], extra_grouped: Dict[str, List[PV]]
    ) -> Dict[str, List[PV]]:
        """Merge grouped PV dicts while preserving order and deduplicating by name."""
        merged: Dict[str, List[PV]] = {k: list(v) for k, v in base_grouped.items()}
        for group_key, pvs in extra_grouped.items():
            if group_key not in merged:
                merged[group_key] = []
            merged[group_key].extend(pvs)
            merged[group_key] = ScanDataCollector._dedupe_pvs(merged[group_key])
        return merged

    @staticmethod
    def _dedupe_pvs(pvs: List[PV]) -> List[PV]:
        """Return PV list keeping first occurrence of each PV name."""
        seen: set[str] = set()
        result: List[PV] = []
        for pv in pvs:
            if pv.name in seen:
                continue
            seen.add(pv.name)
            result.append(pv)
        return result

    @staticmethod
    def _build_flat_pvs_and_group_map(
        grouped_pvs: Dict[str, List[PV]],
    ) -> Tuple[List[PV], Dict[str, str]]:
        """Flatten grouped PVs and build name -> HDF5 group key map.

        Duplicate PV names in ``grouped_pvs`` keep the last-seen group key in
        the map (same as repeated assignment in a single loop).

        Args:
            grouped_pvs: Mapping of group key to PV objects for that group.

        Returns:
            Flat list of PVs in iteration order, and reverse lookup map.
        """
        all_pvs: List[PV] = []
        pv_to_group: Dict[str, str] = {}
        for group_key, group_pvs in grouped_pvs.items():
            for pv in group_pvs:
                all_pvs.append(pv)
                pv_to_group[pv.name] = group_key
        return all_pvs, pv_to_group

    def _collect_grouped_fetch_results(
        self,
        all_pvs: List[PV],
        pv_to_group: Dict[str, str],
    ) -> Tuple[Dict[str, List[PV]], int, List[str]]:
        """Partition fetched PVs into group buckets; count successes and failures."""
        data: Dict[str, List[PV]] = {}
        success = 0
        failed_pvs: List[str] = []

        for pv in all_pvs:
            if pv.val is None:
                failed_pvs.append(pv.name)
                continue

            group_key = pv_to_group.get(pv.name)
            if not group_key:
                logger.warning("  [Data] Unexpected PV %s not in key_map", pv.name)
                continue

            if group_key not in data:
                data[group_key] = []
            data[group_key].append(pv)
            success += 1

        return data, success, failed_pvs

    def _fetch_grouped_pvs(
        self, grouped_pvs: Dict[str, List[PV]]
    ) -> Dict[str, List[PV]]:
        """Fetch PVs and group them by HDF5 group key."""
        all_pvs, pv_to_group = self._build_flat_pvs_and_group_map(grouped_pvs)
        if not all_pvs:
            return {}

        logger.debug("Fetching %d PVs for scan data...", len(all_pvs))
        self.io.pvget(all_pvs, only_val=False, timeout=self.DEFAULT_TIMEOUT)

        data, success, failed_pvs = self._collect_grouped_fetch_results(
            all_pvs, pv_to_group
        )

        fail = len(failed_pvs)
        if failed_pvs and logger.isEnabledFor(logging.DEBUG):
            logger.debug(
                "  [Data] Failed PVs (%d): %s",
                len(failed_pvs),
                ", ".join(failed_pvs[:5]) + ("..." if len(failed_pvs) > 5 else ""),
            )
        logger.info("  [Data] Done. Success: %d, Failed: %d", success, fail)
        return data
