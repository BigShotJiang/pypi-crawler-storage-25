"""
FWS daemon package: bridge daemon, interface, and entrypoint support.
"""
