import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from epics_bridge import PV, BridgeIO
from scipy.optimize import curve_fit

import fws_daemon.utils.fit_utils as fu

from ..interface import FWSScanInterface

logger = logging.getLogger(__name__)

FWHM_SIGMA_RATIO: float = 2.0 * np.sqrt(2.0 * np.log(2.0))
FIT_CURVE_POINTS: int = 500
MIN_POINTS_FOR_FIT: int = 5
MAX_FIT_EVALUATIONS: int = 2000


@dataclass
class FitResult:
    """Structure to hold results of a Gaussian fit."""

    amplitude: float = 0.0
    mean: float = 0.0
    sigma: float = 0.0
    fwhm: float = 0.0
    offset: float = 0.0
    # Use default_factory for mutable numpy arrays
    x_fit: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))
    y_fit: np.ndarray = field(default_factory=lambda: np.array([], dtype=float))


class GaussFitCallback:
    """
    Real-time callback that processes incoming beam scan steps.
    Accumulates raw data, calculates integrals/centroids, and updates
    EPICS/HDF5 with Gaussian fit parameters.
    """

    def __init__(self, interface: FWSScanInterface, io: BridgeIO):
        """Initialize the Gauss fit callback.

        Args:
            interface: The FWS scan interface for PV access.
            io: The daemon's IO layer (``epics_bridge.BridgeIO``).
        """
        self.interface = interface
        self.io = io
        self.roi_percent = 0.0  # 0.0 = Auto-dynamic ROI

        # PV map is used internally for v3 object-based updates.
        self.channel_map_pvs = self.interface.channel_map_pvs
        self._filtered_pv_cache: Dict[str, PV] = {}

        # History buffer for current scan session
        self.history: Dict[str, Dict[str, List[Any]]] = {}
        self.reset_state()

        logger.info(
            f"GaussFitCallback initialized for {len(self.channel_map_pvs)} channels."
        )

    def reset_state(self):
        """Clears memory and flushes EPICS output records."""
        logger.info("Resetting GaussFitCallback state and history.")
        pvs_to_write: List[PV] = []

        for key, cfg in self.channel_map_pvs.items():
            self.history[key] = {
                "centroids": [],  # Center of mass per step
                "integrals": [],  # Area per step
                "raw_x": [],  # Position arrays
                "raw_y": [],  # Amplitude arrays
            }
            pvs_to_write.extend(self._build_zero_pv_updates(cfg, filtered=False))
            pvs_to_write.extend(self._build_zero_pv_updates(cfg, filtered=True))

        if self.io and pvs_to_write:
            self.io.pvput(pvs_to_write)

    def __call__(self, *args, **kwargs) -> None:
        """
        Main entry point called by the Daemon.
        Processes the 'scan_data' payload.

        Note: This callback mutates `scan_data` by merging formatted Gauss fit
        results into `scan_data["scan"]` so that HDF5WriterCallback can write
        them to the final HDF5 file.
        """
        group_name = kwargs.get("group_name", "?")
        logger.info("GaussFitCallback invoked (group=%s)", group_name)
        scan_data = kwargs.get("scan_data")
        if not scan_data:
            logger.warning("GaussFitCallback: no scan_data, exiting")
            return

        # 1. Extract reference position (X-axis)
        # InterpolatedPosCh1 is under scan prefix
        scan_prefix = self.interface.prefixes.get("scan", "")
        pos_pv = f"{scan_prefix}InterpolatedPosCh1"
        scan_pvs: List[PV] = scan_data.get("scan", [])
        pos_pv_obj = next((pv for pv in scan_pvs if pv.name == pos_pv), None)
        if pos_pv_obj is None or pos_pv_obj.val is None:
            logger.warning(
                "GaussFitCallback: missing %s: %s. Available keys: %s",
                pos_pv,
                "position PV not found or empty",
                [pv.name for pv in scan_pvs[:10]],
            )
            return
        full_x_arr = np.array(pos_pv_obj.val)

        updates: List[PV] = []
        struck_data: List[PV] = scan_data.get("struck", [])

        # 2. Iterate through configured channels (e.g., PDB, PDT, etc.)
        channels_processed = 0
        for logic_key, cfg in self.channel_map_pvs.items():
            y_arr = self._extract_waveform(struck_data, cfg["daq_match"])
            if y_arr is None or y_arr.size == 0:
                continue

            # Accumulate raw waveforms
            min_len = min(y_arr.size, full_x_arr.size)
            self.history[logic_key]["raw_y"].append(y_arr[:min_len])
            self.history[logic_key]["raw_x"].append(full_x_arr[:min_len])

            # 3. Calculate Step Metrics (Integral and Centroid)
            result = self._process_step_metrics(y_arr[:min_len], full_x_arr[:min_len])
            if result:
                integral, centroid = result
                self.history[logic_key]["integrals"].append(integral)
                self.history[logic_key]["centroids"].append(centroid)

                # 4. Update the Fit for this specific channel
                channel_updates = self._generate_channel_updates(logic_key, cfg)
                updates.extend(channel_updates)
                channels_processed += 1

        if updates:
            logger.info(
                "GaussFitCallback: processed %s channels, writing %s PVs",
                channels_processed,
                len(updates),
            )
            self.io.pvput(updates)
            # Merge formatted results into scan_data for HDF5WriterCallback
            try:
                prefix = self.interface.prefixes.get("main", "")
                formatted = self._format_for_storage(updates, prefix)
                scan_data.setdefault("scan", []).extend(formatted["scan"])
            except Exception as e:
                logger.error("GaussFitCallback: failed to merge results: %s", e)

    def _extract_waveform(
        self, struck_data: List[PV], key_match: str
    ) -> Optional[np.ndarray]:
        """Tries to find TRC2 (preferential) or TRC1 matching the channel key."""
        for suffix in ["TRC2", "TRC1"]:
            for pv in struck_data:
                if key_match in pv.name and suffix in pv.name and pv.val is not None:
                    return np.array(pv.val)
        return None

    def _process_step_metrics(
        self, y: np.ndarray, x: np.ndarray
    ) -> Optional[Tuple[float, float]]:
        """Calculates area and center for a single wire sweep step."""
        if y.size < MIN_POINTS_FOR_FIT:
            return None
        try:
            mask = fu.extract_peak_roi_mask(y, self.roi_percent)
            roi_x, roi_y = x[mask], y[mask]

            # Use smoothed data for metric stability
            y_smooth = fu.apply_smoothing(roi_y)
            return fu.calculate_integral(roi_x, y_smooth), fu.calculate_centroid(
                roi_x, y_smooth
            )
        except Exception as e:
            logger.error("GaussFitCallback: metric calculation failed: %s", e)
            return None

    def _generate_channel_updates(self, logic_key: str, cfg: dict) -> List[PV]:
        """Publishes both raw and filtered integral/centroid trends and fits."""
        updates_by_name: Dict[str, PV] = {}
        y_hist = np.array(self.history[logic_key]["integrals"])
        x_hist = np.array(self.history[logic_key]["centroids"])

        # Raw PVs: publish unfiltered history
        cfg["integral"].val = y_hist
        updates_by_name[cfg["integral"].name] = cfg["integral"]
        cfg["int_pos"].val = x_hist
        updates_by_name[cfg["int_pos"].name] = cfg["int_pos"]

        # Filter outliers/noise spikes in the trend
        mask = fu.separate_signal_noise(y_hist)
        y_clean, x_clean = y_hist[mask], x_hist[mask]

        # Filtered PVs: publish signal-only data
        integral_f = self._filtered_pv(cfg["integral"])
        integral_f.val = y_clean
        updates_by_name[integral_f.name] = integral_f
        int_pos_f = self._filtered_pv(cfg["int_pos"])
        int_pos_f.val = x_clean
        updates_by_name[int_pos_f.name] = int_pos_f

        # Attempt fit on filtered data if enough data points exist
        if x_clean.size >= MIN_POINTS_FOR_FIT:
            fit = self._perform_gaussian_fit(x_clean, y_clean)
            if fit:
                for pv in self._build_fit_pv_updates(cfg, fit, filtered=True):
                    updates_by_name[pv.name] = pv

        # Attempt fit on raw data if enough data points exist
        if x_hist.size >= MIN_POINTS_FOR_FIT and x_clean.size >= MIN_POINTS_FOR_FIT:
            fit_raw = self._perform_gaussian_fit(x_hist, y_hist)
            if fit_raw:
                for pv in self._build_fit_pv_updates(cfg, fit_raw, filtered=False):
                    updates_by_name[pv.name] = pv

        return list(updates_by_name.values())

    def _build_zero_pv_updates(self, cfg: dict, filtered: bool = False) -> List[PV]:
        """Builds zero/empty PV updates for a single channel."""
        resolve = self._filtered_pv if filtered else (lambda pv: pv)
        items = [
            (resolve(cfg["integral"]), np.array([], dtype=float)),
            (resolve(cfg["int_pos"]), np.array([], dtype=float)),
            (resolve(cfg["gauss_fit"]), np.array([], dtype=float)),
            (resolve(cfg["fit_pos"]), np.array([], dtype=float)),
            (resolve(cfg["amp"]), 0.0),
            (resolve(cfg["mean"]), 0.0),
            (resolve(cfg["sigma"]), 0.0),
            (resolve(cfg["fwhm"]), 0.0),
        ]
        updates: List[PV] = []
        for pv, val in items:
            pv.val = val
            updates.append(pv)
        return updates

    def _build_fit_pv_updates(
        self, cfg: dict, fit: FitResult, filtered: bool = False
    ) -> List[PV]:
        """Maps a FitResult to PV updates for a single channel."""
        resolve = self._filtered_pv if filtered else (lambda pv: pv)
        items = [
            (resolve(cfg["gauss_fit"]), fit.y_fit),
            (resolve(cfg["fit_pos"]), fit.x_fit),
            (resolve(cfg["amp"]), fit.amplitude),
            (resolve(cfg["mean"]), fit.mean),
            (resolve(cfg["sigma"]), fit.sigma),
            (resolve(cfg["fwhm"]), fit.fwhm),
        ]
        updates: List[PV] = []
        for pv, val in items:
            pv.val = val
            updates.append(pv)
        return updates

    def _perform_gaussian_fit(
        self, x: np.ndarray, y: np.ndarray
    ) -> Optional[FitResult]:
        """Fits Gaussian model with robust bounds and validation."""
        try:
            # Guessing parameters
            y_min, y_max = np.min(y), np.max(y)
            max_idx = np.argmax(y)

            p0 = [
                y_max - y_min,
                x[max_idx],
                (np.max(x) - np.min(x)) / 6.0 or 1.0,
                y_min,
            ]
            bounds = ([0, -np.inf, 1e-6, -np.inf], [np.inf, np.inf, np.inf, np.inf])

            popt, _ = curve_fit(
                fu.gaussian_model,
                x,
                y,
                p0=p0,
                bounds=bounds,
                maxfev=MAX_FIT_EVALUATIONS,
            )

            if not np.all(np.isfinite(popt)):
                return None

            # Generate smooth curve for UI display
            x_fine = np.linspace(np.min(x), np.max(x), FIT_CURVE_POINTS)
            y_fine = fu.gaussian_model(x_fine, *popt)

            return FitResult(
                amplitude=popt[0],
                mean=popt[1],
                sigma=popt[2],
                fwhm=FWHM_SIGMA_RATIO * popt[2],
                offset=popt[3],
                x_fit=x_fine,
                y_fit=y_fine,
            )
        except Exception:
            return None

    def _filtered_pv(self, base_pv: PV) -> PV:
        """Return cached filtered PV object for a base PV."""
        filtered_name = f"{base_pv.name}-F"
        if filtered_name not in self._filtered_pv_cache:
            self._filtered_pv_cache[filtered_name] = PV(
                filtered_name,
                cast_type=base_pv.cast_type,
            )
        return self._filtered_pv_cache[filtered_name]

    def _format_for_storage(self, updates: List[PV], prefix: str) -> Dict[str, Any]:
        """
        Converts internal update dict to the structured format
        required by the HDF writer.
        """
        storage_data: Dict[str, List[PV]] = {"scan": []}
        for pv in updates:
            pv_name = pv.name
            val = pv.val
            # Extract PV suffix from full PV name (remove prefix)
            # PV name format: "{prefix}V-PDR-Integral" -> "V-PDR-Integral"
            if prefix and pv_name.startswith(prefix):
                pv_suffix = pv_name[len(prefix) :]
            else:
                pv_suffix = pv_name

            # Unpack numpy scalars
            clean_val = (
                val.item() if isinstance(val, np.ndarray) and val.size == 1 else val
            )
            pv.val = clean_val
            if hasattr(pv, "egu"):
                pv.egu.val = (
                    "mm"
                    if any(s in pv_suffix for s in ["Pos", "Sigma", "FWHM", "Mean"])
                    else "V"
                )
            storage_data["scan"].append(pv)
        return storage_data
