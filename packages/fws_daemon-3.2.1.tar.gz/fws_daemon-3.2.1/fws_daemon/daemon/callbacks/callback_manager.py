"""
Callback management for FWS scan daemon.

This module handles initialization and lifecycle management of callbacks
used during scan execution.
"""

import logging
from typing import Callable, List, Optional

from epics_bridge import BridgeIO

from ..interface import FWSScanInterface
from .gauss_fit_callback import GaussFitCallback
from .hdf5_writer_callback import HDF5WriterCallback
from .status_callback import ScanStatusCallback

logger = logging.getLogger(__name__)


class CallbackManager:
    """
    Manages initialization and lifecycle of scan callbacks.

    Handles built-in callbacks (status and gauss fit) as well as
    custom callbacks provided during initialization.
    """

    def __init__(
        self,
        interface: FWSScanInterface,
        io: BridgeIO,
        pre_scan_callbacks: Optional[List[Callable[..., None]]] = None,
        post_scan_callbacks: Optional[List[Callable[..., None]]] = None,
    ):
        """
        Initialize the callback manager.

        Args:
            interface: The FWS scan interface for PV access.
            io: The daemon's IO layer (``epics_bridge.BridgeIO``).
            pre_scan_callbacks: Optional list of custom pre-scan callbacks.
            post_scan_callbacks: Optional list of custom post-scan callbacks.
        """
        self.interface = interface
        self.io = io
        self.pre_scan_callbacks: List[Callable[..., None]] = pre_scan_callbacks or []
        self.post_scan_callbacks: List[Callable[..., None]] = post_scan_callbacks or []

        # Initialize built-in callbacks
        self._initialize_built_in_callbacks()

        logger.debug(
            "Initialized callbacks - Pre: %d, Post: %d",
            len(self.pre_scan_callbacks),
            len(self.post_scan_callbacks),
        )

    def _initialize_built_in_callbacks(self) -> None:
        """Initialize built-in callbacks (status, gauss fit, and HDF5 writer)."""
        # Add status callback (updates scan_current_step PV)
        self.status_callback = ScanStatusCallback(self.interface, self.io)
        self.pre_scan_callbacks.append(self.status_callback)

        # Add gauss fit callback first (augments scan_data with fit results)
        self.gauss_fit_callback = GaussFitCallback(self.interface, self.io)
        self.post_scan_callbacks.append(self.gauss_fit_callback)

        # Add HDF5 writer callback after gauss fit
        # (writes scan_data including Gauss results)
        self.hdf5_writer_callback = HDF5WriterCallback(self.interface, self.io)
        self.post_scan_callbacks.append(self.hdf5_writer_callback)

    def reset_state(self) -> None:
        """Reset callback state before each scan sequence."""
        for cb in self.pre_scan_callbacks:
            if hasattr(cb, "reset_state"):
                cb.reset_state()
        for cb in self.post_scan_callbacks:
            if hasattr(cb, "reset_state"):
                cb.reset_state()
