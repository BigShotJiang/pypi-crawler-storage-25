import logging
import time
from typing import Optional

from epics_bridge import BridgeIO

from ..interface import FWSScanInterface

logger = logging.getLogger(__name__)


class ScanStatusCallback:
    """
    Callback to publish the current simulation scan index and elapsed time to EPICS PVs.
    """

    def __init__(self, interface: FWSScanInterface, io: BridgeIO):
        """
        Initialize the callback with the daemon's IO layer.

        Args:
            interface: The FWS scan interface for PV access.
            io: The daemon's IO layer (``epics_bridge.BridgeIO``).
        """
        self.io = io
        self.interface = interface
        self._start_time: Optional[float] = None

    def __call__(self, *args, **kwargs) -> None:
        """
        Invoked by the daemon/loop with the current state dictionary.

        Args:
            state_dict (dict): Expected to contain 'current_idx' (int).
        """

        logger.debug(
            "ScanStatusCallback called with args: %s, kwargs: %s", args, kwargs
        )

        # 1. Safely extract the scan index
        # We match the attribute name 'current_idx' from your HDF5ScanPlayer
        current_idx = kwargs.get("step_config", None).get("scan_idx", None)

        if current_idx is None:
            logger.warning(
                "ScanStatusCallback: 'step_config' or 'scan_idx' "
                "missing in state data. Keys found: %s",
                kwargs,
            )
            return

        # 2. Initialize start time on first call if not already set
        if self._start_time is None:
            self._start_time = time.time()

        # 3. Calculate elapsed time
        elapsed_time = time.time() - self._start_time

        # 4. Publish to EPICS via the Status channel
        try:
            self.interface.scan_current_step.val = current_idx
            self.interface.scan_elapsed_time.val = elapsed_time
            self.io.pvput(
                [
                    self.interface.scan_current_step,
                    self.interface.scan_elapsed_time,
                ]
            )
            logger.debug(
                "Updated PV status ['%s'] -> %s, ['%s'] -> %.2f",
                self.interface.scan_current_step.name,
                current_idx,
                self.interface.scan_elapsed_time.name,
                elapsed_time,
            )
        except Exception as e:
            logger.error("ScanStatusCallback failed to update EPICS: %s", e)

    def reset_state(self) -> None:
        """Reset the start time for a new scan sequence."""
        self._start_time = None
