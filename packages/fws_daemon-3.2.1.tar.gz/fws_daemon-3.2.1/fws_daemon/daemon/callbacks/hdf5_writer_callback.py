"""
HDF5 writer callback — appends scan data to HDF5 per iteration.

Follows the same callback protocol as `GaussFitCallback` and
`ScanStatusCallback`.  Creates the file lazily on first invocation, then
appends scan groups per step.

Contains all HDF5 file I/O logic internally (no external utility dependencies).
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional

import h5py
from epics_bridge import PV, BridgeIO

from ..interface import FWSScanInterface

logger = logging.getLogger(__name__)


class HDF5WriterCallback:
    """Writes scan data to HDF5 file per iteration.

    Instantiated once by the daemon. The file is created on the first
    `__call__` invocation using the `file_path` from kwargs. Subsequent
    calls append scan groups. The ``FileName`` PV is written once per output
    file (first iteration), then verified with a readback. ``reset_state()``
    clears file tracking and the publish flag so the next scan sequence can
    publish again.

    Args:
        interface: The FWSScanInterface (not currently used, but kept for
            protocol consistency with other callbacks).
        io: The daemon's IO layer (``epics_bridge.BridgeIO``; kept for
            protocol consistency with other callbacks).
    """

    def __init__(self, interface: FWSScanInterface, io: BridgeIO):
        """Initialize the HDF5 writer callback.

        Args:
            interface: The FWS scan interface for PV access.
            io: The daemon's IO layer (``epics_bridge.BridgeIO``).
        """
        self.interface = interface
        self.io = io
        self._current_file_path: Optional[str] = None
        self._file_name_published: bool = False

        logger.info("HDF5WriterCallback initialized.")

    def __call__(self, *args, **kwargs) -> None:
        """Write scan data to HDF5.

        Expected kwargs:
            - file_path: Output HDF5 path.
            - scan_data: Nested dict of PV data
            - group_name: Name for the scan group (e.g. 'scan_001')
            - metadata: Optional file-root metadata (only used on file creation)
            - scan_metadata: Optional per-scan attributes for ``group_name``
        """
        file_path = kwargs.get("file_path")
        scan_data = kwargs.get("scan_data")
        group_name = kwargs.get("group_name")

        if not file_path or scan_data is None or not group_name:
            logger.warning(
                "HDF5WriterCallback: Missing required kwargs. "
                "Expected 'file_path', 'scan_data', 'group_name'."
            )
            return

        # Lazy file creation on first call
        if self._current_file_path != file_path:
            self._create_file(file_path, kwargs.get("metadata", {}))
            self._current_file_path = file_path
            self._file_name_published = False

        self._publish_file_name_once(file_path)

        # Append scan group
        scan_attrs = kwargs.get("scan_metadata") or {}
        try:
            self._append_scan_group(
                file_path=file_path,
                group_name=group_name,
                attrs=dict(scan_attrs),
                data=scan_data,
            )
            logger.debug("Wrote scan group %s to %s", group_name, file_path)
        except Exception as e:
            logger.error("Failed to write scan group %s: %s", group_name, e)

    def reset_state(self) -> None:
        """Reset file tracking so a new file can be created next run."""
        logger.debug("HDF5WriterCallback: Resetting state.")
        self._current_file_path = None
        self._file_name_published = False

    # ------------------------------------------------------------------
    # HDF5 I/O internals
    # ------------------------------------------------------------------

    def _create_file(self, file_path: str, metadata: Dict[str, Any]) -> None:
        """Create the HDF5 file with root metadata."""
        try:
            logger.info("Creating HDF5 file: %s", file_path)
            with h5py.File(file_path, "w") as f:
                self._write_attributes(f, metadata)
        except Exception as e:
            logger.error("Failed to create HDF5 file %s: %s", file_path, e)
            raise

    def _append_scan_group(
        self,
        file_path: str,
        group_name: str,
        attrs: Dict[str, Any],
        data: Dict[str, Any],
    ) -> None:
        """Append a scan iteration group to the HDF5 file."""
        try:
            with h5py.File(file_path, "a") as f:
                group = f.require_group(group_name)
                self._write_attributes(group, attrs)
                self._write_datasets(group, data)
        except Exception as e:
            logger.error("Failed to write scan group %s: %s", group_name, e)
            raise

    def _publish_file_name_once(self, file_path: str) -> None:
        """Publish the output basename to FileName once per output file / scan cycle.

        Subsequent iterations appending to the same file skip re-publishing. The flag
        is cleared when switching to a new ``file_path`` or in ``reset_state()``.
        """
        if self._file_name_published:
            return

        basename = os.path.basename(file_path)
        try:
            self.interface.file_name.val = basename
            self.io.pvput(self.interface.file_name)
            self._file_name_published = True
        except Exception as exc:
            logger.warning("Failed to publish FileName PV from HDF5 callback: %s", exc)

    @staticmethod
    def _write_attributes(h5_group: Any, data: Dict[str, Any]) -> None:
        """Write key-value pairs as HDF5 group attributes."""
        for key, value in data.items():
            try:
                safe_val = HDF5WriterCallback._sanitize(value)
                h5_group.attrs[key] = safe_val
            except Exception as e:
                logger.error("HDF5 Attr Error [%s]: %s", key, e)

    @staticmethod
    def _write_datasets(h5_group: Any, data: Dict[str, list[PV]]) -> None:
        """Write nested dataset groups."""
        for key, pv_list in data.items():
            if key == "user":
                continue
            try:
                inner_group = h5_group.require_group(key)
                for pv in pv_list:
                    try:
                        val = HDF5WriterCallback._sanitize(pv.val)
                        dset = inner_group.create_dataset(pv.name, data=val)
                        if hasattr(pv, "egu") and pv.egu.val:
                            dset.attrs["egu"] = str(pv.egu.val)
                    except Exception as e:
                        logger.error("HDF5 Dataset Error [%s]: %s", pv.name, e)
            except Exception as e:
                logger.error("HDF5 Group Error [%s]: %s", key, e)

    @staticmethod
    def _sanitize(value: Any) -> Any:
        """Convert a Python value to an HDF5-compatible type."""
        if value is None:
            return "None"
        if hasattr(value, "tolist"):
            value = value.tolist()
        if isinstance(value, list):
            if not value:
                return []
            first = value[0]
            if not isinstance(first, (int, float, str, bytes, bool)):
                return [str(v) for v in value]
            return value
        if isinstance(value, (int, float, str, bytes, bool)):
            return value
        return str(value)
