import getpass
import logging
import os
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

from epics_bridge import BridgeDaemon, LoggingManager, TaskStatus

from fws_daemon.scan.config import ScanConfig
from fws_daemon.scan.orchestrator import ScanDirective, run_scan
from fws_daemon.utils.misc_utils import generate_output_path

from .callbacks.callback_manager import CallbackManager
from .data_collector import ScanDataCollector
from .interface import FWSScanInterface, IOCPrefixes, ScannerAuxiliary

logger = logging.getLogger(__name__)


class FWSScanBridgeDaemon(BridgeDaemon):
    """
    `epics-bridge` based implementation of the FWS scan daemon.

    This is a functional analogue of `FWSScanDaemon`, but it delegates
    lifecycle/heartbeat/TaskStatus handling to the `BridgeDaemon` base
    class instead of managing its own polling and watchdog threads.
    """

    def __init__(
        self,
        interface: FWSScanInterface,
        logging_manager: LoggingManager,
        scanner_idx: int,
        test_mode: bool,
        pre_scan_callbacks: Optional[List[Callable[..., None]]] = None,
        post_scan_callbacks: Optional[List[Callable[..., None]]] = None,
    ):
        super().__init__(interface, logging_manager)

        self.scanner_idx = scanner_idx
        self.test_mode = test_mode

        logger.info(
            "Initializing FWSScanBridgeDaemon [Scanner: %d | TestMode: %s]",
            scanner_idx,
            test_mode,
        )

        self.ioc_prefixes = IOCPrefixes(scanner_idx, test_mode=test_mode)
        self.scanner_config = ScannerAuxiliary(scanner_idx, test_mode=test_mode)

        # Initialize callback manager (handles built-in and custom callbacks)
        self.callback_manager = CallbackManager(
            interface=self.iface,
            io=self.io,
            pre_scan_callbacks=pre_scan_callbacks,
            post_scan_callbacks=post_scan_callbacks,
        )

        # Initialize scan data collector for PV fetching
        self.data_collector = ScanDataCollector(
            interface=self.iface,
            io=self.io,
        )

        # Track num_scans for dynamic stall limit calculation
        # Updated in run_task() when scan_config is available
        self.num_scans: int = 0

    # ------------------------------------------------------------------
    # Core synchronous task hook (called by BridgeDaemon main loop)
    # ------------------------------------------------------------------

    def get_max_stall_limit(self) -> float:
        """[Override] Maximum allowed main-loop inactivity (seconds)."""
        return 10 + self.num_scans * 30

    def run_task(self) -> TaskStatus:
        """
        Single scan cycle:
          1. Read configuration inputs
          2. Build ScanConfig and metadata
          3. Run scan via run_scan
          4. Publish output filename
        """

        self._read_inputs()
        scan_config = self._build_scan_params()
        if scan_config is None:
            logger.error("Failed to build scan parameters.")
            return TaskStatus.EXCEPTION

        self.num_scans = scan_config.num_scans

        # Reset callback state before each scan sequence
        self.callback_manager.reset_state()

        root_metadata = self._build_scan_metadata(scan_config)

        success = run_scan(
            scan_config=scan_config,
            interface=self.iface,
            io=self.io,
            data_collector=self.data_collector,
            scan_control=self._scan_control,
            pre_scan_callbacks=self.callback_manager.pre_scan_callbacks,
            post_scan_callbacks=self.callback_manager.post_scan_callbacks,
            metadata=root_metadata,
        )

        if not success:
            logger.error("Scan aborted due to hardware failure.")
            return TaskStatus.EXCEPTION

        logger.info("FWS scan sequence completed successfully.")
        return TaskStatus.SUCCESS

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _read_inputs(self) -> None:
        """Read current configuration from EPICS using the bridge IO layer."""
        self.io.pvget(self.iface.filter_pvs("input"))

    def _build_scan_params(self) -> Optional[ScanConfig]:
        """
        Transforms EPICS PV values into ScanConfig.

        Converts flat EPICS PV values (scan_start, scan_end) into structured
        arguments expected by ScanConfig.from_args (position_scan tuple).
        """
        args = {
            "num_scans": self.iface.num_scans.val,
            "relative_scan": self.iface.relative_scan.val,
            "center_position": self.iface.center_position.val,
            "scan_start": self.iface.scan_start.val,
            "scan_end": self.iface.scan_end.val,
            "output_path": self.iface.output_path.val,
        }

        # Transform scan_start/scan_end into position_scan tuple
        scan_start = args.get("scan_start")
        scan_end = args.get("scan_end")
        if scan_start is not None and scan_end is not None:
            args["position_scan"] = (float(scan_start), float(scan_end))
        else:
            args["position_scan"] = None

        if not args.get("output_path"):
            logger.warning(
                "Output folder argument is empty/None! Defaulting to current dir."
            )

        num_scans_raw = args.get("num_scans")
        prefix = f"FWS{self.scanner_idx:02d}"
        file_path = generate_output_path(
            prefix=prefix,
            output_path=args.get("output_path", ".") or ".",
            position_scan=args.get("position_scan"),
            num_scans=int(num_scans_raw) if num_scans_raw is not None else None,
        )
        args["file_path"] = file_path

        logger.info("Generated output path: %s", file_path)

        return ScanConfig.from_args(args)

    def _build_scan_metadata(self, scan_config: ScanConfig) -> Dict[str, Any]:
        """
        Build metadata dict for this scan (scan args, date, username).

        Written as file-root HDF5 attributes by the HDF5 writer callback.
        PV-backed scan metadata is written per ``scan_###`` group by the same
        callback (see orchestrator loop).
        """
        position_scan = scan_config.position_scan
        try:
            username = getpass.getuser()
        except Exception:
            username = os.environ.get("USER", "unknown")
        return {
            "num_scans": scan_config.num_scans,
            "position_scan": list(position_scan) if position_scan else None,
            "relative_scan": scan_config.relative_scan,
            "file_path": scan_config.file_path,
            "start_time": datetime.now(timezone.utc).isoformat(),
            "username": username,
            "source": "EpicsBridge",
        }

    def _scan_control(self) -> ScanDirective:
        """
        Hook passed to `run_scan` to provide scan control directive.

        Reads the scan_control PV already cast to ScanDirective.

        Returns:
            ScanDirective enum value (RESUME/PAUSE/ABORT).
        """
        self.io.pvget(self.iface.scan_control)
        directive = self.iface.scan_control.val
        if isinstance(directive, ScanDirective):
            return directive
        logger.warning(
            "Invalid scan_control value %r. Defaulting to RESUME.", directive
        )
        return ScanDirective.RESUME
