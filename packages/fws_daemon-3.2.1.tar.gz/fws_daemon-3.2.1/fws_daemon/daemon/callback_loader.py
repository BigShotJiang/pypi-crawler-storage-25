"""Callback loading utilities for the daemon entrypoint."""

from __future__ import annotations

import argparse
import importlib.util
import logging
import sys
from contextlib import ExitStack
from pathlib import Path
from typing import Callable, List, Optional, Tuple

logger = logging.getLogger(__name__)


def load_custom_callbacks(
    script_path: Path,
) -> Tuple[Optional[Callable], Optional[Callable]]:
    """Load a Python module and return pre/post scan callbacks."""
    if not script_path.exists():
        raise FileNotFoundError(f"Custom script not found: {script_path}")

    try:
        module_name = script_path.stem
        spec = importlib.util.spec_from_file_location(module_name, script_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load specification for {script_path}")

        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        logger.info("Loaded custom module: %s", module_name)

        pre_cb = getattr(module, "get_pre_callback", lambda: None)()
        post_cb = getattr(module, "get_post_callback", lambda: None)()
        if pre_cb is not None:
            logger.info("Found 'get_pre_callback' in custom script.")
        if post_cb is not None:
            logger.info("Found 'get_post_callback' in custom script.")
        if pre_cb is None and post_cb is None:
            logger.warning(
                "No 'get_pre_callback' or 'get_post_callback' found in %s",
                script_path.name,
            )
        return pre_cb, post_cb
    except Exception as exc:
        logger.exception("Failed to load custom script: %s", exc)
        sys.exit(1)


def _register_callback_cleanup(
    stack: ExitStack,
    callback: object,
    callback_label: str,
    log: logging.Logger,
) -> None:
    """If the callback has a .close() method, register it for cleanup on stack."""
    if hasattr(callback, "close"):
        stack.callback(callback.close)
        log.info("Registered cleanup for %s callback.", callback_label)


def load_callbacks(
    args: argparse.Namespace,
    stack: ExitStack,
    log: logging.Logger,
) -> Tuple[List[object], List[object]]:
    """Load pre/post callbacks from a custom script and register cleanup."""
    pre_callbacks: List[object] = []
    post_callbacks: List[object] = []
    if not args.custom_callback:
        return pre_callbacks, post_callbacks

    log.info("Injecting custom script: %s", args.custom_callback)
    pre_cb, post_cb = load_custom_callbacks(args.custom_callback)
    if pre_cb:
        _register_callback_cleanup(stack, pre_cb, "Pre-Scan", log)
        pre_callbacks.append(pre_cb)
    if post_cb:
        _register_callback_cleanup(stack, post_cb, "Post-Scan", log)
        post_callbacks.append(post_cb)
    return pre_callbacks, post_callbacks
