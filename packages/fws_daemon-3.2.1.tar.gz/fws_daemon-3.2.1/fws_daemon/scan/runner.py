"""
Scan runner: hardware abstraction layer for EPICS scan execution.

``FWSScanRunner`` provides a clean API for physical hardware actions.
It encapsulates EPICS PV names, timeouts, and retry logic, handling
the 'dirty' work of checking busy records and status codes.
"""

import logging
import time
from typing import TYPE_CHECKING, Any

from epics_bridge import BridgeIO

if TYPE_CHECKING:
    from fws_daemon.daemon.interface import FWSScanInterface

logger = logging.getLogger(__name__)


class FWSScanRunner:
    """
    SCAN RUNNER (Hardware Abstraction Layer)

    Responsibility:
    - Provides a clean API for physical hardware actions.
    - Encapsulates EPICS PV names, timeouts, and retry logic.
    - Handles the 'Dirty' work of checking busy records and status codes.
    """

    # Tunables
    SCAN_TIMEOUT = 10.0
    MAX_RETRIES = 3
    RETRY_DELAY = 1.0

    def __init__(self, io: BridgeIO, interface: "FWSScanInterface") -> None:
        """Initialize the scan runner with daemon-provided IO.

        Args:
            io: The daemon's IO layer (``epics_bridge.BridgeIO``).
            interface: PV interface with resolved hardware PV names
                (cmd_hard_scan, etc.).
        """
        self._io = io
        self._interface = interface

        logger.debug("Scan Runner Initialized.")

    # -------------------------------------------------------------------------
    # Actuation Commands (Motors & Settings)
    # -------------------------------------------------------------------------

    def set_interaction_position(self, position: float) -> None:
        """Sets the target interaction position (PosToDelay)."""
        logger.info("[HW] Setting Interaction Pos: %.4f", position)
        self._interface.setting_pos.val = position
        self._io.pvput(self._interface.setting_pos)

    def get_interaction_position(self) -> float:
        """Reads the current interaction position."""
        self._io.pvget(self._interface.setting_pos)
        val = self._interface.setting_pos.val
        return float(val) if val is not None else 0.0

    def trigger_auto_delay_calculation(self) -> None:
        """Triggers the IOC's internal auto-calculation procedure."""
        logger.info("[HW] Triggering Auto-Delay Calculation...")
        self._interface.cmd_auto_calc.val = 1
        self._io.pvput(self._interface.cmd_auto_calc)

    # -------------------------------------------------------------------------
    # Scan Execution (Triggers)
    # -------------------------------------------------------------------------

    def run_hard_scan(self) -> bool:
        """Trigger a hardware scan and wait for completion.

        Returns:
            True if the scan completed successfully (status=0), False otherwise.
        """
        pv_trigger = self._interface.cmd_hard_scan
        pv_status = self._interface.status_code

        start_time = time.perf_counter()

        for attempt in range(1, self.MAX_RETRIES + 1):
            logger.info(
                "[HW] Triggering Hard Scan (Attempt %d/%d)", attempt, self.MAX_RETRIES
            )

            try:
                self._put_hard_scan_trigger(pv_trigger)

                if self._wait_hard_scan_trigger_idle(pv_trigger):
                    scan_duration = time.perf_counter() - start_time
                    status = self._read_scan_status_after_idle(pv_status)

                    if status == 0:
                        logger.info("[HW] Hard scan success (%.2fs)", scan_duration)
                        return True

                    logger.warning("[HW] Scan finished with error code: %s", status)
                else:
                    logger.error("[HW] Timeout! %s stayed busy", pv_trigger)

            except Exception as e:
                logger.error("[HW] Exception during scan attempt %d: %s", attempt, e)

            if attempt < self.MAX_RETRIES:
                time.sleep(self.RETRY_DELAY)

        return False

    def run_soft_scan(self) -> bool:
        """Trigger a software scan and wait for completion.

        Returns:
            True if the trigger completed successfully, False otherwise.
        """
        pv_trigger = self._interface.cmd_soft_scan
        logger.info("[HW] Triggering Soft Scan...")

        try:
            pv_trigger.val = 1
            self._io.pvput(pv_trigger)
            return self._block_until_value(pv_trigger, 0, self.SCAN_TIMEOUT)
        except Exception as e:
            logger.error("[HW] Soft scan failed: %s", e)
            return False

    # -------------------------------------------------------------------------
    # Internal Helpers
    # -------------------------------------------------------------------------

    def _put_hard_scan_trigger(self, pv_trigger: Any) -> None:
        """Write 1 to the hard-scan command PV and allow IOC to process."""
        pv_trigger.val = 1
        self._io.pvput(pv_trigger)
        time.sleep(0.2)

    def _wait_hard_scan_trigger_idle(self, pv_trigger: Any) -> bool:
        """Return True when the hard-scan trigger PV reads idle (0)."""
        return self._block_until_value(pv_trigger, 0, self.SCAN_TIMEOUT)

    def _read_scan_status_after_idle(self, pv_status: Any) -> Any:
        """Read status PV after the trigger has cleared; small settle delay first."""
        time.sleep(0.1)
        self._io.pvget(pv_status)
        return pv_status.val

    def _block_until_value(self, pv: Any, target: Any, timeout: float) -> bool:
        """Waits for a PV to reach a specific value.

        Args:
            pv: PV name to monitor.
            target: Expected value.
            timeout: Maximum time to wait in seconds.

        Returns:
            True if the PV reached the target value, False if timeout.
        """
        start = time.time()
        while time.time() - start < timeout:
            self._io.pvget(pv)
            if pv.val == target:
                return True
            time.sleep(0.1)
        return False

    # -------------------------------------------------------------------------
    # Context Manager Support
    # -------------------------------------------------------------------------

    def __enter__(self):
        """Support for context manager protocol."""
        return self

    def __exit__(self, *args):
        """Support for context manager protocol."""
        # No cleanup needed for BridgeIO-based interface
        pass
