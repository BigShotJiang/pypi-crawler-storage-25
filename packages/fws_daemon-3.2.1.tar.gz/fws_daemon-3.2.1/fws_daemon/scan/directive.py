"""Shared scan control directive enum."""

import enum


class ScanDirective(enum.Enum):
    """Scan control directive enum."""

    RESUME = 0
    PAUSE = 1
    ABORT = 2
