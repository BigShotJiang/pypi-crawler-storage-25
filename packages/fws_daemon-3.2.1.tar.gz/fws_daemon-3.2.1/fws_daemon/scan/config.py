"""
Typed scan configuration.

``ScanConfig`` replaces the loose ``args`` dictionary that was threaded
through the controller, providing type safety, coercion, and validation
at the boundary.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


@dataclass(frozen=True)
class ScanConfig:
    """Immutable, validated configuration for a single scan sequence.

    Attributes:
        num_scans: Number of scan iterations to perform (>= 0).
        position_scan: (start, end) range in mm, or None if not a position scan.
        relative_scan: Whether the range is relative to the current position.
        file_path: Absolute path for the output HDF5 file.
    """

    num_scans: int
    position_scan: Optional[tuple[float, float]]
    relative_scan: bool
    file_path: str

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    def from_args(cls, args: dict[str, Any]) -> ScanConfig:
        """Build a ``ScanConfig`` from a raw arguments dictionary.

        Performs type coercion (e.g. float -> int for num_scans) and
        validation before returning an immutable instance.

        Args:
            args: Dictionary typically produced by the daemon's
                ``_read_inputs`` or by CLI parsing.

        Returns:
            A validated ``ScanConfig``.

        Raises:
            ValueError: If values are out of range or inconsistent.
            KeyError: If required keys are missing.
        """
        num_scans = int(args["num_scans"])
        file_path = str(args["file_path"])

        # Coerce position_scan
        raw_ps = args.get("position_scan")
        if raw_ps is not None:
            position_scan: Optional[tuple[float, float]] = (
                float(raw_ps[0]),
                float(raw_ps[1]),
            )
        else:
            position_scan = None

        relative_scan = bool(args.get("relative_scan", False))

        # --- Validation ---
        if num_scans < 0:
            raise ValueError(f"num_scans must be >= 0, got {num_scans}")

        if position_scan is not None:
            start, end = position_scan
            if start >= end:
                raise ValueError(
                    f"position_scan start ({start}) must be less than end ({end})"
                )

        return cls(
            num_scans=num_scans,
            position_scan=position_scan,
            relative_scan=relative_scan,
            file_path=file_path,
        )
