"""
Scan orchestration: entrypoint and execution loop.

``ScanOrchestrator`` orchestrates the main scan sequence: plan the steps,
iterate through them (move, trigger, collect), and invoke pre/post
callbacks at each iteration.  It delegates hardware actuation and data
storage to collaborators injected at construction time.

``run_scan`` is the public entrypoint that wires together config, hardware,
and orchestrator from ScanConfig, interface, and IO.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

from epics_bridge import BridgeIO

from fws_daemon.daemon.interface import FWSScanInterface

from .config import ScanConfig
from .directive import ScanDirective
from .planner import ScanPlanner
from .runner import FWSScanRunner

logger = logging.getLogger(__name__)


class ScanOrchestrator:
    """Runs the scan loop given typed config, hardware, and data collector.

    This class owns *no* EPICS resources — it receives fully constructed
    collaborators and drives them through the scan recipe.

    Args:
        config: Validated scan configuration.
        hardware: Hardware abstraction (``FWSScanRunner``).
        data_collector: Optional PV data collector (fetches scan data).
        metadata: Optional file-root metadata dict passed to callbacks (unchanged
            for the whole run). PV scan metadata is passed per iteration as
            ``scan_metadata`` when a ``data_collector`` is present.
    """

    DELAY_BETWEEN_SCANS = 1.0

    def __init__(
        self,
        config: ScanConfig,
        hardware: Any,
        data_collector: Optional[Any] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.config = config
        self.hardware = hardware
        self.data_collector = data_collector
        self.metadata = metadata or {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(
        self,
        scan_control: Callable[[], ScanDirective] = lambda: ScanDirective.RESUME,
        pre_scan_callbacks: Optional[List[Callable[..., None]]] = None,
        post_scan_callbacks: Optional[List[Callable[..., None]]] = None,
        file_path: Optional[str] = None,
    ) -> bool:
        """Execute the full scan sequence.

        Args:
            scan_control: Callable returning current scan directive
                (RESUME/PAUSE/ABORT).
            pre_scan_callbacks: Called before each move/trigger step.
            post_scan_callbacks: Called after each data collection step.
                Each receives ``metadata`` (file-root, constant) and, when a
                ``data_collector`` is configured, ``scan_metadata`` (fresh PV
                snapshot for that iteration).
            file_path: Optional output path passed to post_scan callbacks
                (e.g. for HDF5).

        Returns:
            True if the scan completed without a hardware trigger failure
            (including user abort or no steps). False if aborted due to
            run_hard_scan() failure.
        """
        pre_scan_callbacks = pre_scan_callbacks or []
        post_scan_callbacks = post_scan_callbacks or []

        logger.info("Initializing FWS Scan sequence...")

        self._initial_setup()

        scan_steps = self._plan_scan_steps()
        if scan_steps is None:
            logger.warning("No scan steps defined. Exiting scan run.")
            return True

        total = len(scan_steps)
        logger.info("Planned %d scans.", total)

        hardware_failed = False
        for i, step in enumerate(scan_steps):
            if not self._scan_control_allows_step(scan_control):
                break

            logger.info("--- Starting Iteration %03d ---", i + 1)

            if self._execute_iteration(
                i=i,
                step=step,
                total=total,
                pre_scan_callbacks=pre_scan_callbacks,
                post_scan_callbacks=post_scan_callbacks,
                file_path=file_path,
            ):
                hardware_failed = True
                break

        logger.info("FWS Scan sequence finished.")
        return not hardware_failed

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _plan_scan_steps(self) -> Optional[List[Any]]:
        """Build the planned scan step list, or None when there is nothing to run."""
        current_pos = (
            self.hardware.get_interaction_position()
            if self.config.relative_scan
            else None
        )
        return ScanPlanner.generate(self.config, current_position=current_pos)

    def _scan_control_allows_step(
        self, scan_control: Callable[[], ScanDirective]
    ) -> bool:
        """Return False when the outer loop should stop (abort or abort-while-paused)."""
        directive = scan_control()
        if directive == ScanDirective.ABORT:
            logger.warning("Scan aborted by user request.")
            return False
        if directive == ScanDirective.PAUSE:
            logger.info("Scan paused. Waiting for resume...")
            if not self._wait_while_paused(scan_control):
                logger.warning("Scan aborted while paused.")
                return False
        return True

    def _build_post_scan_payload(
        self, iteration_index: int
    ) -> Tuple[str, Dict[str, Any], Dict[str, Any]]:
        """Group name, scan datasets, and per-iteration metadata attributes."""
        group_name = f"scan_{str(iteration_index + 1).zfill(3)}"
        if self.data_collector:
            logger.info("Acquiring scan data...")
            scan_data = self.data_collector.collect_scan_data()
        else:
            scan_data = {}

        scan_metadata_attrs: Dict[str, Any] = {}
        if self.data_collector is not None:
            scan_metadata_attrs = self.data_collector.format_scan_metadata_raw_attrs()

        return group_name, scan_data, scan_metadata_attrs

    def _execute_iteration(
        self,
        i: int,
        step: Any,
        total: int,
        pre_scan_callbacks: List[Callable[..., None]],
        post_scan_callbacks: List[Callable[..., None]],
        file_path: Optional[str],
    ) -> bool:
        """Run one iteration: pre-callbacks, move, trigger, collect, post-callbacks.

        Returns:
            True if the hardware trigger failed and the scan sequence must stop.
        """
        step_config = {"scan_idx": i + 1, "step": step}

        self._run_callbacks(
            pre_scan_callbacks,
            stage_name=f"Pre-Scan {i + 1}",
            step_config=step_config,
        )

        self.hardware.set_interaction_position(step)

        if not self.hardware.run_hard_scan():
            logger.error("Hardware scan failed. Aborting scan sequence.")
            return True

        group_name, scan_data, scan_metadata_attrs = self._build_post_scan_payload(i)

        self._run_callbacks(
            post_scan_callbacks,
            stage_name=f"Post-Scan {i + 1}",
            scan_data=scan_data,
            group_name=group_name,
            metadata=self.metadata,
            scan_metadata=scan_metadata_attrs,
            file_path=file_path,
        )

        if i < total - 1:
            time.sleep(self.DELAY_BETWEEN_SCANS)

        return False

    def _wait_while_paused(
        self, scan_control: Callable[[], ScanDirective], poll_interval: float = 0.1
    ) -> bool:
        """Wait while scan is paused, checking for RESUME or ABORT.

        Args:
            scan_control: Callable returning current scan directive.
            poll_interval: Sleep interval between checks (seconds).

        Returns:
            True if resumed (RESUME directive), False if aborted (ABORT directive).
        """
        while True:
            directive = scan_control()
            if directive == ScanDirective.ABORT:
                return False
            if directive == ScanDirective.RESUME:
                logger.info("Scan resumed.")
                return True
            # Still paused, wait and check again
            time.sleep(poll_interval)

    def _initial_setup(self) -> None:
        """Perform initial setup (relative scan auto-calc if needed)."""
        logger.debug("Performing initial scan setup...")
        if self.config.relative_scan:
            logger.info("Relative scan mode enabled.")
            self.hardware.trigger_auto_delay_calculation()

    @staticmethod
    def _run_callbacks(callbacks: List[Callable[..., None]], **kwargs: Any) -> None:
        """Execute callbacks safely; log but swallow errors."""
        for cb in callbacks:
            try:
                cb(**kwargs)
            except Exception as e:
                logger.error(
                    "Callback error: callback: %s, error: %s", cb, e, exc_info=True
                )


def run_scan(
    scan_config: ScanConfig,
    interface: FWSScanInterface,
    io: BridgeIO,
    data_collector: Optional[Any] = None,
    scan_control: Callable[[], ScanDirective] = lambda: ScanDirective.RESUME,
    pre_scan_callbacks: Optional[List[Callable[..., None]]] = None,
    post_scan_callbacks: Optional[List[Callable[..., None]]] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> bool:
    """Run one FWS scan sequence: build orchestrator, run and return result.

    Args:
        scan_config: Validated scan configuration.
        interface: Scan PV interface (e.g. daemon's interface).
        io: PV IO layer (``epics_bridge.BridgeIO``).
        data_collector: Optional PV data collector.
        scan_control: Callable returning current scan directive (RESUME/PAUSE/ABORT).
        pre_scan_callbacks: Called before each move/trigger step.
        post_scan_callbacks: Called after each data collection step.
        metadata: Optional dict for file-root context (e.g. scan args, date,
            username) passed unchanged to each callback. Per-iteration PV metadata
            is supplied separately as ``scan_metadata`` by the orchestrator when
            ``data_collector`` is set.

    Returns:
        True if the scan completed without hardware trigger failure, False otherwise.
    """
    hardware = FWSScanRunner(io=io, interface=interface)
    orchestrator = ScanOrchestrator(
        config=scan_config,
        hardware=hardware,
        data_collector=data_collector,
        metadata=metadata or {},
    )
    return orchestrator.run(
        scan_control=scan_control,
        pre_scan_callbacks=pre_scan_callbacks or [],
        post_scan_callbacks=post_scan_callbacks or [],
        file_path=scan_config.file_path,
    )
