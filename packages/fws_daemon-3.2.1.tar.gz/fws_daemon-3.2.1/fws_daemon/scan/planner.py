"""
Scan path planning.

``ScanPlanner`` is a stateless helper that computes the sequence of
positions (steps) for a scan, given a ``ScanConfig`` and, for relative
scans, the current hardware position.
"""

from __future__ import annotations

import logging
from typing import Optional

import numpy as np

from .config import ScanConfig

logger = logging.getLogger(__name__)


class ScanPlanner:
    """Generates scan step arrays from typed configuration.

    All methods are static / class-level — no mutable state is held.
    """

    @staticmethod
    def generate(
        config: ScanConfig,
        current_position: Optional[float] = None,
    ) -> Optional[np.ndarray]:
        """Compute the array of scan positions.

        Args:
            config: Validated scan configuration.
            current_position: Current hardware position, required when
                ``config.relative_scan`` is True.

        Returns:
            1-D numpy array of positions, or ``None`` when there is
            nothing to scan (zero scans or no position range).

        Raises:
            ValueError: If a relative scan is requested but
                *current_position* is ``None``.
        """
        if config.num_scans == 0 or config.position_scan is None:
            return None

        start, end = config.position_scan

        if config.relative_scan:
            if current_position is None:
                raise ValueError("current_position is required for a relative scan")
            start += current_position
            end += current_position

        steps = np.linspace(start, end, config.num_scans)
        logger.debug("Planned %d scan steps: %s", len(steps), steps)
        return steps
