from typing import Dict, Optional

import h5py
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Button, Slider

import fws_daemon.utils.fit_utils as fu
from fws_daemon.daemon.interface import IOCPrefixes, ScannerAuxiliary


class PlotConfigs:
    """Standardized plot styling constants."""

    MULT = 1
    AXIS_LABEL_SIZE = 18 * MULT
    TITLE_SIZE = 20 * MULT
    LEGEND_SIZE = 20 * MULT
    TAG_SIZE = 10 * MULT
    TICK_SIZE = 12 * MULT


class BaseScannerPlot:
    """
    Superclass aligned with GaussFitCallback logic.
    Handles shared data management and the standardized processing pipeline.
    """

    def __init__(
        self,
        file_path: str,
        ioc_prefixes: IOCPrefixes,
        scanner_config: ScannerAuxiliary,
        iops_channel: str,
        struck_channel: str,
        normalize: bool = False,
        apply_filter: bool = False,
        apply_offset_correction: bool = False,
    ):
        self.file_path = file_path
        self.prefixes = ioc_prefixes
        self.scanner_config = scanner_config
        self.iops_channel = iops_channel.upper()
        self.struck_channel = struck_channel.upper()

        self.normalize = normalize
        self.apply_filter = apply_filter
        self.apply_offset_correction = apply_offset_correction
        self.roi_percent = 0.0  # 0.0 = Auto-dynamic
        self.reference_offset: Optional[float] = None

        self.paths = self._set_data_paths()
        self.raw_scans: Dict[str, dict] = {}
        self._load_all_raw_scans()

        if not self.raw_scans:
            raise ValueError(f"No valid scans found in {file_path}.")

        self.scan_keys = list(self.raw_scans.keys())
        self.total_scans = len(self.scan_keys)
        self.scan_start = 1
        self.scan_end = self.total_scans

    def _set_data_paths(self) -> dict:
        """Constructs HDF5 internal paths based on scanner hardware orientation."""
        pos_key = (
            "InterpolatedPosCh1" if self.iops_channel == "CH1" else "InterpolatedPosCh2"
        )
        return {
            "y_match": self.struck_channel.replace("_", "-"),
            "x": f"scan/{self.prefixes.SCAN_PV_PREFIX}{pos_key}",
            "norm": "beam/HEBT-010LWU:PBI-BCM-001:FlatTopCurrentR",
            "x_offset": f"beam/{self.scanner_config.BPMS[0]}",
        }

    def _load_all_raw_scans(self):
        """Standardized HDF5 loading (Cached)."""
        with h5py.File(self.file_path, "r") as hdf:
            for scan_key in fu.get_scan_keys(hdf):
                try:
                    x_path = f"{scan_key}/{self.paths['x']}"
                    if x_path not in hdf:
                        continue

                    y_raw = None
                    struck_group = hdf.get(f"{scan_key}/struck")
                    if struck_group:
                        match_str = self.paths["y_match"]
                        candidates = [
                            k for k in struck_group.keys() if match_str in k.upper()
                        ]
                        # Priority TRC2 then TRC1 (Matching _extract_waveform logic)
                        for suffix in ["TRC2", "TRC1"]:
                            hit = next((k for k in candidates if suffix in k), None)
                            if hit:
                                y_raw = struck_group[hit][()]
                                break

                    if y_raw is None:
                        continue

                    self.raw_scans[scan_key] = {
                        "x": hdf[x_path][()],
                        "y": y_raw,
                        "norm": fu.get_scalar_from_dataset(
                            hdf, f"{scan_key}/{self.paths['norm']}", 1.0
                        ),
                        "offset": fu.get_scalar_from_dataset(
                            hdf, f"{scan_key}/{self.paths['x_offset']}", 0.0
                        ),
                    }
                except Exception:
                    continue

    def _get_processed_metrics(self, scan_key: str):
        raw = self.raw_scans[scan_key]
        x, y = raw["x"].copy(), raw["y"].copy()
        min_len = min(x.size, y.size)
        x_step, y_step = x[:min_len], y[:min_len]

        # 1. Normalization Check
        if self.normalize:
            y_norm = fu.normalize_data(y_step, raw["norm"])
            if y_norm is None:
                print(
                    f"DEBUG: {scan_key} failed Normalization (Norm Val: {raw['norm']})"
                )
                return None
            y_step = y_norm

        # 2. ROI Mask Check
        try:
            mask = fu.extract_peak_roi_mask(y_step, self.roi_percent)
            if not np.any(mask):
                print(f"DEBUG: {scan_key} failed ROI Mask (Empty Mask)")
                return None

            roi_x, roi_y = x_step[mask], y_step[mask]
            y_smooth = fu.apply_smoothing(roi_y)

            # 3. Finite Check
            integral = fu.calculate_integral(roi_x, y_smooth)
            centroid = fu.calculate_centroid(roi_x, y_smooth)

            if not np.isfinite(integral) or not np.isfinite(centroid):
                print(
                    f"DEBUG: {scan_key} non-finite results "
                    f"(Int: {integral}, Cent: {centroid})"
                )
                return None

            return integral, centroid, roi_x, y_smooth
        except Exception as e:
            print(f"DEBUG: {scan_key} Exception: {e}")
            return None

    def setup_base_ui(self, title: str, ylabel: str):
        """Standardized UI layout."""
        self.fig, self.ax = plt.subplots(figsize=(11, 7))
        plt.subplots_adjust(left=0.1, right=0.9, top=0.9, bottom=0.35)

        self.ax_roi = plt.axes([0.1, 0.22, 0.35, 0.03])
        self.slider_roi = Slider(
            self.ax_roi, "ROI %", 0.0, 100.0, valinit=self.roi_percent, valstep=0.1
        )
        self.ax_s1 = plt.axes([0.55, 0.22, 0.35, 0.03])
        self.slider_s1 = Slider(
            self.ax_s1, "Scan Start", 1, self.total_scans, valinit=1, valstep=1
        )
        self.ax_s2 = plt.axes([0.55, 0.17, 0.35, 0.03])
        self.slider_s2 = Slider(
            self.ax_s2,
            "Scan End",
            1,
            self.total_scans,
            valinit=self.total_scans,
            valstep=1,
        )

        y_btn = 0.05
        self.btn_auto = Button(plt.axes([0.1, y_btn, 0.15, 0.05]), "Auto ROI")
        self.btn_norm = Button(
            plt.axes([0.3, y_btn, 0.15, 0.05]),
            f'Norm: {"ON" if self.normalize else "OFF"}',
        )
        self.btn_off = Button(
            plt.axes([0.5, y_btn, 0.15, 0.05]),
            f'Offset: {"ON" if self.apply_offset_correction else "OFF"}',
        )
        self.btn_filter = Button(
            plt.axes([0.7, y_btn, 0.15, 0.05]),
            f'Filter: {"ON" if self.apply_filter else "OFF"}',
        )

        self.slider_roi.on_changed(self._on_ui_update)
        self.slider_s1.on_changed(self._on_ui_update)
        self.slider_s2.on_changed(self._on_ui_update)
        self.btn_auto.on_clicked(lambda e: self.slider_roi.set_val(0))
        self.btn_norm.on_clicked(self._toggle_norm)
        self.btn_off.on_clicked(self._toggle_off)
        self.btn_filter.on_clicked(self._toggle_filter)

        self.ax.set_xlabel("Position (mm)", fontsize=PlotConfigs.AXIS_LABEL_SIZE)
        self.ax.set_ylabel(ylabel, fontsize=PlotConfigs.AXIS_LABEL_SIZE)
        self.ax.set_title(title, fontsize=PlotConfigs.TITLE_SIZE)
        self.ax.tick_params(labelsize=PlotConfigs.TICK_SIZE)
        self.ax.grid(True, alpha=0.2)

    def _on_ui_update(self, val):
        self.roi_percent = self.slider_roi.val
        self.scan_start = int(self.slider_s1.val)
        self.scan_end = int(self.slider_s2.val)
        self.refresh_ui()

    def _toggle_norm(self, e):
        self.normalize = not self.normalize
        self.btn_norm.label.set_text(f'Norm: {"ON" if self.normalize else "OFF"}')
        self.refresh_ui()

    def _toggle_off(self, e):
        self.apply_offset_correction = not self.apply_offset_correction
        self.btn_off.label.set_text(
            f'Offset: {"ON" if self.apply_offset_correction else "OFF"}'
        )
        self.reference_offset = None
        self.refresh_ui()

    def _toggle_filter(self, e):
        self.apply_filter = not self.apply_filter
        self.btn_filter.label.set_text(
            f'Filter: {"ON" if self.apply_filter else "OFF"}'
        )
        self.refresh_ui()

    def refresh_ui(self):
        raise NotImplementedError
