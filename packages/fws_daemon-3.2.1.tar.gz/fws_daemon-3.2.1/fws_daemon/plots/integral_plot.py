"""
integral_plot.py

A specialized visualization for analyzing beam intensity trends across multiple scans.
Plots Integrated Area vs. Centroid Position and provides Gaussian fitting.
"""

from typing import List, Tuple

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.path import Path
from matplotlib.widgets import LassoSelector
from scipy.optimize import curve_fit

import fws_daemon.utils.fit_utils as fu
from fws_daemon.daemon.interface import IOCPrefixes, ScannerAuxiliary

from .base_plot import BaseScannerPlot, PlotConfigs
from .utils import identify_scanner, parse_arguments


class IntegralPlot(BaseScannerPlot):
    """
    Child class that extracts high-level metrics (Integral, Centroid) from each
    scan and plots the resulting intensity profile across the scan range.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # Plot-specific data containers
        self.xdata = np.array([])  # Centroids
        self.ydata = np.array([])  # Integrals
        self.labels = []
        self.selected = np.array([], dtype=bool)
        self.text_annos = []

        # Initialize UI elements
        self.setup_plot()

    def setup_plot(self):
        """Initializes plot-specific widgets and base UI components."""
        self.setup_base_ui(
            title=f"Intensity Profile: {self.struck_channel}",
            ylabel="Profile Area (V·mm)",
        )
        self.ax.set_xlabel(
            "Centroid Position (mm)", fontsize=PlotConfigs.AXIS_LABEL_SIZE
        )

        # Plot elements
        self.scatter = self.ax.scatter(
            [], [], c="crimson", s=60, edgecolors="white", picker=5, zorder=3
        )
        (self.fit_line,) = self.ax.plot(
            [], [], color="navy", ls="--", lw=2, label="Gaussian Fit", zorder=2
        )

        self.param_box = self.ax.text(
            0.02,
            0.98,
            "",
            transform=self.ax.transAxes,
            fontsize=PlotConfigs.TAG_SIZE,
            va="top",
            bbox=dict(boxstyle="round", facecolor="white", alpha=0.9),
        )

        # Interactive selection tools
        self.lasso = LassoSelector(self.ax, self.onselect)
        self.fig.canvas.mpl_connect("pick_event", self.onpick)

        self.refresh_ui()

    def load_processed_data(self) -> Tuple[np.ndarray, np.ndarray, List[str]]:
        start_idx = max(0, int(self.scan_start) - 1)
        end_idx = min(self.total_scans, int(self.scan_end))
        active_keys = self.scan_keys[start_idx:end_idx]

        x_list, y_list, valid_keys = [], [], []

        for key in active_keys:
            # Call the aligned logic
            result = self._get_processed_metrics(key)
            if result:
                integral, centroid, _, _ = result
                if np.isfinite(integral) and np.isfinite(centroid):
                    x_list.append(centroid)
                    y_list.append(integral)
                    valid_keys.append(key)

        if not x_list:
            return np.array([]), np.array([]), []

        x_arr, y_arr = np.array(x_list), np.array(y_list)

        # Global Filter (K-Means) matching _generate_channel_updates logic
        if self.apply_filter and y_arr.size > 2:
            signal_mask = fu.separate_signal_noise(y_arr)
            return (
                x_arr[signal_mask],
                y_arr[signal_mask],
                [valid_keys[i] for i, m in enumerate(signal_mask) if m],
            )

        return x_arr, y_arr, valid_keys

    def refresh_ui(self):
        """Redraws the scatter plot and re-calculates the Gaussian fit."""
        # 1. Update data based on current flags (Norm, Filter, ROI)
        self.xdata, self.ydata, keys = self.load_processed_data()
        self.labels = [k.split("_")[-1] for k in keys]

        # 2. Synchronize selection mask
        if self.selected.size != self.xdata.size:
            self.selected = np.ones(self.xdata.size, dtype=bool)

        # 3. Update Scatter and Annotations
        self.scatter.set_offsets(np.c_[self.xdata, self.ydata])
        self.scatter.set_color(["crimson" if s else "lightgray" for s in self.selected])

        for t in self.text_annos:
            t.remove()
        self.text_annos = [
            self.ax.text(x, y, lbl, fontsize=8, ha="left", va="bottom", alpha=0.6)
            for x, y, lbl in zip(self.xdata, self.ydata, self.labels)
        ]

        # 4. Perform Fit on selected data
        self._run_fit()

        self.ax.relim()
        self.ax.autoscale_view()
        self.fig.canvas.draw_idle()

    def _run_fit(self):
        """Fits Gaussian to selected points and updates the parameter box."""
        mask = self.selected
        if np.sum(mask) < 5:
            self.fit_line.set_data([], [])
            self.param_box.set_text("Need 5+ points")
            return

        try:
            x_sel, y_sel = self.xdata[mask], self.ydata[mask]

            # Robust guesses for fitter stability
            y_span = np.max(y_sel) - np.min(y_sel)
            p0 = [
                y_span,
                x_sel[np.argmax(y_sel)],
                (np.max(x_sel) - np.min(x_sel)) / 6.0,
                np.min(y_sel),
            ]
            bounds = ([0, -np.inf, 1e-6, -np.inf], [np.inf, np.inf, np.inf, np.inf])

            popt, _ = curve_fit(
                fu.gaussian_model, x_sel, y_sel, p0=p0, bounds=bounds, maxfev=2000
            )

            x_fine = np.linspace(np.min(x_sel), np.max(x_sel), 500)
            self.fit_line.set_data(x_fine, fu.gaussian_model(x_fine, *popt))

            fwhm = 2.355 * popt[2]
            self.param_box.set_text(
                f"Amp:  {popt[0]:.2f}\nMean: {popt[1]:.2f}\n"
                f"Sig:  {popt[2]:.2f}\nFWHM: {fwhm:.2f}"
            )
        except Exception:
            self.fit_line.set_data([], [])
            self.param_box.set_text("Fit Failed")

    # --- Interaction Logic ---

    def onselect(self, verts):
        """Lasso tool selection handler."""
        path = Path(verts)
        self.selected ^= path.contains_points(np.c_[self.xdata, self.ydata])
        self.refresh_ui()

    def onpick(self, event):
        """Single point click handler."""
        if event.artist == self.scatter:
            self.selected[event.ind[0]] = not self.selected[event.ind[0]]
            self.refresh_ui()


if __name__ == "__main__":
    args = parse_arguments()
    scanner_idx = identify_scanner(args.file_path)
    test_mode = scanner_idx > 6
    ioc_prefixes = IOCPrefixes(scanner_idx, test_mode=test_mode)
    scanner_config = ScannerAuxiliary(scanner_idx, test_mode=test_mode)

    plot_ui = IntegralPlot(
        file_path=args.file_path,
        ioc_prefixes=ioc_prefixes,
        scanner_config=scanner_config,
        iops_channel=args.iops_channel,
        struck_channel=args.struck_channel,
    )
    plt.show()
