"""
roi_plot.py

A specialized visualization for overlaid ROI (Region of Interest) waveforms.
Inherits from BaseScannerPlot to leverage shared data loading and signal processing.
"""

import matplotlib.pyplot as plt
import numpy as np

from fws_daemon.daemon.interface import IOCPrefixes, ScannerAuxiliary

from .base_plot import BaseScannerPlot, PlotConfigs
from .utils import identify_scanner, parse_arguments


class ROIPlot(BaseScannerPlot):
    """
    Child class that visualizes smoothed ROI beam waveforms overlaid on a single plot.
    Aligned with GaussFitCallback logic to ensure offline visualization matches
    real-time metrics.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # Child-specific plot state
        self.lines = {}
        self.text_labels = {}

        # Initialize the specific UI for waveform plotting
        self.setup_plot()

    def setup_plot(self):
        """Initializes the base UI and child-specific plot elements."""
        self.setup_base_ui(
            title=f"ROI Waveforms: {self.struck_channel}", ylabel="Intensity (V)"
        )
        self.refresh_ui()

    def refresh_ui(self):
        """
        Implementation of the abstract method from BaseScannerPlot.
        Redraws the waveforms whenever parameters (ROI, range, filters) change.
        """
        # 1. Clear existing waveform lines and scan number labels
        for line in self.lines.values():
            line.remove()
        for txt in self.text_labels.values():
            txt.remove()

        self.lines.clear()
        self.text_labels.clear()

        # 2. Determine the active scan range from sliders
        start_idx = max(0, int(self.scan_start) - 1)
        end_idx = min(self.total_scans, int(self.scan_end))
        active_keys = self.scan_keys[start_idx:end_idx]

        if not active_keys:
            self.fig.canvas.draw_idle()
            return

        # 3. Process and Plot loop
        for scan_key in active_keys:
            # Call the synchronized processing pipeline from the base class
            # Returns: (integral, centroid, roi_x, y_smooth)
            result = self._get_processed_metrics(scan_key)

            if result is None:
                continue

            # Unpack the metrics and the arrays already sliced
            # and smoothed by the base class
            _, _, roi_x, roi_y = result

            if roi_x.size == 0:
                continue

            # Plot the individual scan waveform
            # This represents the EXACT signal used to calculate the area/integral
            (line,) = self.ax.plot(roi_x, roi_y, alpha=0.8, lw=1.5)
            self.lines[scan_key] = line

            # 4. Annotate the peak of each waveform with its scan index
            #
            peak_idx = np.argmax(np.abs(roi_y))
            scan_num = scan_key.split("_")[-1]

            txt = self.ax.text(
                roi_x[peak_idx],
                roi_y[peak_idx],
                scan_num,
                fontsize=PlotConfigs.TAG_SIZE - 2,
                color=line.get_color(),
                ha="left",
                va="bottom",
            )
            self.text_labels[scan_key] = txt

        # 5. Update plot limits and flush to canvas
        self.ax.relim()
        self.ax.autoscale_view()
        self.fig.canvas.draw_idle()


if __name__ == "__main__":
    args = parse_arguments()
    scanner_idx = identify_scanner(args.file_path)
    test_mode = scanner_idx > 6
    ioc_prefixes = IOCPrefixes(scanner_idx, test_mode=test_mode)
    scanner_config = ScannerAuxiliary(scanner_idx, test_mode=test_mode)

    plot_ui = ROIPlot(
        file_path=args.file_path,
        ioc_prefixes=ioc_prefixes,
        scanner_config=scanner_config,
        iops_channel=args.iops_channel,
        struck_channel=args.struck_channel,
    )
    plt.show()
