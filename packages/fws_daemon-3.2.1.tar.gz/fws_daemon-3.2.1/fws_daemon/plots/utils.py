import argparse
import os
import re


def parse_arguments():
    """Standard CLI parser for scanner analysis tools."""
    parser = argparse.ArgumentParser(description="FWS HDF5 Scan Analysis")
    parser.add_argument("file_path", type=str, help="Path to the .h5 file")
    parser.add_argument(
        "struck_channel", type=str, help="DAQ channel (e.g., 'PDB', 'PDT')"
    )
    parser.add_argument(
        "-ic", "--iops-channel", type=str, default="ch1", help="CH1 or CH2"
    )
    parser.add_argument("-si", "--scanner-index", type=int, help="Scanner index")
    return parser.parse_args()


def identify_scanner(filepath: str) -> int:
    """
    Extracts scanner index from filename.
    Examples: 'FWS03' -> 3, 'FWS01' -> 1, 'PyTest' -> 7.
    """
    filename = os.path.basename(filepath)
    # Match FWS followed by 1-2 digits (01-99, or 1-9 without leading zero)
    # Use negative lookahead to ensure we don't match part of a longer number
    match = re.search(r"FWS(\d{1,2})(?!\d)", filename, re.IGNORECASE)
    if match:
        idx = int(match.group(1))
        if 1 <= idx <= 99:
            return idx
    if "pytest" in filename.lower():
        return 7
    raise ValueError(
        f"No valid scanner pattern (FWS01–FWS99 or PyTest) found in: {filename}"
    )
