"""
main.py

The entry point for the FWS Scan Analysis tool.
Launches both the Profile Trend (IntegralPlot) and the Waveform Viewer
(ROIPlot).
"""

import matplotlib.pyplot as plt

from fws_daemon.daemon.interface import IOCPrefixes, ScannerAuxiliary

from .integral_plot import IntegralPlot
from .roi_plot import ROIPlot
from .utils import identify_scanner, parse_arguments


def main():
    # 1. Parse CLI arguments and determine scanner orientation from filename
    args = parse_arguments()
    scanner_idx = args.scanner_index

    if scanner_idx is None:
        try:
            scanner_idx = identify_scanner(args.file_path)
        except ValueError as e:
            print(f"Error: {e}")
            return

    if scanner_idx > 6:
        ioc_prefixes = IOCPrefixes(scanner_idx, test_mode=True)
        scanner_config = ScannerAuxiliary(scanner_idx, test_mode=True)
    else:
        ioc_prefixes = IOCPrefixes(scanner_idx)
        scanner_config = ScannerAuxiliary(scanner_idx)

    print(f"Analyzing {args.file_path}...")
    print(f"Scanner Index: {scanner_idx} | Channel: {args.struck_channel.upper()}")

    # 2. Launch the Intensity Profile (Trend) Plot
    # This window handles Gaussian fitting across multiple scans
    integral_ui = IntegralPlot(
        file_path=args.file_path,
        ioc_prefixes=ioc_prefixes,
        scanner_config=scanner_config,
        iops_channel=args.iops_channel,
        struck_channel=args.struck_channel,
    )
    integral_ui.fig.canvas.manager.set_window_title(
        f"FWS Intensity Profile - {args.struck_channel.upper()}"
    )

    # 3. Launch the ROI Waveform Viewer
    # This window allows detailed inspection of individual signal pulses
    roi_ui = ROIPlot(
        file_path=args.file_path,
        ioc_prefixes=ioc_prefixes,
        scanner_config=scanner_config,
        iops_channel=args.iops_channel,
        struck_channel=args.struck_channel,
    )
    roi_ui.fig.canvas.manager.set_window_title(
        f"FWS ROI Waveforms - {args.struck_channel.upper()}"
    )

    # 4. Display both windows
    # We show the first non-blockingly, then the second blockingly
    # to keep the process alive
    plt.show()


if __name__ == "__main__":
    main()
