"""unchainedsky-cli — browser automation over local Chrome CDP."""

__version__ = "0.1.0"
