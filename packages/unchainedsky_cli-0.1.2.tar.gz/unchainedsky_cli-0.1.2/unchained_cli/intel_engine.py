"""Public stub for proprietary page intelligence engine."""

raise RuntimeError(
    "intel_engine.py is proprietary and lives in unchained-core-private. "
    "Install the compiled binary or run private-integrated CI."
)
