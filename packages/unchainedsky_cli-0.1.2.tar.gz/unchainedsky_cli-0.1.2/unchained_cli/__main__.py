"""Support `python -m unchained_cli`."""
from .cli import main

main()
