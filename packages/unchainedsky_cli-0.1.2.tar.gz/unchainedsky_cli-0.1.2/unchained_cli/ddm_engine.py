"""Public stub for proprietary DDM engine."""

raise RuntimeError(
    "ddm_engine.py is proprietary and lives in unchained-core-private. "
    "Install the compiled binary or run private-integrated CI."
)
