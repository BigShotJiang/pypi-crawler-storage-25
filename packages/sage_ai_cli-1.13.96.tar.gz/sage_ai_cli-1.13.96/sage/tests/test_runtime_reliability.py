"""TDD tests for runtime reliability fixes.

These tests verify that SAGE handles real-world runtime issues:
1. First-token timeout for stalled models
2. Simple Q&A mode for non-agent prompts
3. Model availability validation
4. Grounding discipline in ask mode

Run with: pytest sage/tests/test_runtime_reliability.py -v
"""

from __future__ import annotations

import sys
import time
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

# =============================================================================
# P0-1: First-token timeout for streaming
# =============================================================================


class TestFirstTokenTimeout:
    """Tests that streaming has first-token timeout to prevent hangs."""

    def test_stream_tokens_has_timeout_parameter(self):
        """stream_tokens_with_phase must accept first_token_timeout parameter."""
        from sage.core.renderer import Renderer

        renderer = Renderer()

        # The function signature should accept timeout
        import inspect

        sig = inspect.signature(renderer.stream_tokens_with_phase)
        params = list(sig.parameters.keys())

        assert "first_token_timeout" in params or "timeout" in params, (
            "stream_tokens_with_phase must have a timeout parameter"
        )

    def test_timeout_raises_on_no_first_token(self):
        """If no token arrives within timeout, should raise TimeoutError."""
        from sage.core.renderer import StreamingTimeoutError

        # StreamingTimeoutError should exist
        assert issubclass(StreamingTimeoutError, Exception)

    def test_timeout_exception_has_helpful_message(self):
        """Timeout exception should explain what happened."""
        from sage.core.renderer import StreamingTimeoutError

        error = StreamingTimeoutError("No response from model within 30 seconds")
        assert "30 seconds" in str(error) or "timeout" in str(error).lower()


# =============================================================================
# P0-2: Simple Q&A mode vs Agent mode
# =============================================================================


class TestSimpleQAMode:
    """Tests that simple Q&A prompts don't get agent treatment."""

    def test_is_simple_qa_detects_math_questions(self):
        """Simple math questions should be detected as Q&A."""
        from sage.main import _is_simple_qa_prompt

        simple_prompts = [
            "What is 2+2?",
            "What's the capital of France?",
            "How do I print hello world in Python?",
            "Explain recursion",
        ]

        for prompt in simple_prompts:
            assert _is_simple_qa_prompt(prompt), f"Should detect '{prompt}' as simple Q&A"

    def test_is_simple_qa_rejects_agent_tasks(self):
        """Agent tasks should NOT be treated as simple Q&A."""
        from sage.main import _is_simple_qa_prompt

        agent_prompts = [
            "Analyze the codebase and list 100 improvements",
            "Fix the bug in auth.py",
            "Implement a new feature for user login",
            "Read main.py and refactor the function",
            "What were we doing last time?",
        ]

        for prompt in agent_prompts:
            assert not _is_simple_qa_prompt(prompt), f"Should NOT detect '{prompt}' as simple Q&A"

    def test_ask_command_uses_simple_mode_for_qa(self):
        """sage ask should use simple mode for Q&A, not agent mode."""
        from sage.main import _build_simple_qa_messages

        messages = _build_simple_qa_messages("What is 2+2?")

        assert messages[0].role == "system"
        assert "Answer the user's question directly" in messages[0].content
        assert "workflow narration" in messages[0].content
        assert messages[-1].content == "What is 2+2?"

    def test_run_loop_has_simple_mode_fast_path(self):
        """Interactive run path should bypass the heavy agent cycle for simple Q&A."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "_send_simple_qa_to_model(user_input)" in source
        assert "if _is_simple_qa_prompt(user_input):" in source

    def test_simple_qa_repl_path_uses_direct_generate(self):
        """Simple REPL answers should use direct generation instead of waiting on streaming."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("def _send_simple_qa_to_model(")
        end = source.index("    while True:", start)
        function_source = source[start:end]

        assert "router.generate(" in function_source
        assert "router.stream(" not in function_source

    def test_timeout_wrapper_fails_fast_for_stuck_simple_qa(self):
        """Simple-QA timeout wrapper should abort instead of hanging the REPL forever."""
        from sage.core.renderer import StreamingTimeoutError
        from sage.main import _run_callable_with_timeout

        with pytest.raises(StreamingTimeoutError):
            _run_callable_with_timeout(
                lambda: (time.sleep(0.05), "late")[1],
                timeout_seconds=0.01,
                timeout_message="timed out",
            )

    def test_hidden_agent_turn_timeout_stays_short_for_local_models(self):
        """Hidden non-stream agent turns should fail fast on local models."""
        from sage.main import _get_single_turn_agent_timeout

        assert _get_single_turn_agent_timeout("ollama") == 45.0
        assert _get_single_turn_agent_timeout("llama_cpp") == 60.0
        assert _get_single_turn_agent_timeout("unknown-provider") == 60.0

    def test_reasoning_sender_uses_timeout_wrapper(self):
        """Pre-orchestration reasoning calls should not bypass the timeout guard."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("def _send_for_reasoning(")
        end = source.index("reasoning_engine = ChainOfThoughtReasoner", start)
        section = source[start:end]

        assert "_get_single_turn_agent_timeout(provider_name)" in section
        assert "_run_callable_with_timeout(" in section


# =============================================================================
# P1-1: Grounding discipline in sage ask
# =============================================================================


class TestAskGroundingDiscipline:
    """Tests that sage ask has grounding checks for file-related questions."""

    def test_ask_with_file_reference_requires_read(self):
        """If ask mentions a file, it should READ it before answering."""
        from sage.main import _should_ground_ask_response

        # Prompt asks about a specific file
        prompt = "Read main.py and tell me what run() does"

        should_ground = _should_ground_ask_response(prompt)
        assert should_ground is True

    def test_ask_without_file_reference_no_grounding(self):
        """Simple Q&A without files doesn't need grounding."""
        from sage.main import _should_ground_ask_response

        prompt = "What is 2+2?"

        should_ground = _should_ground_ask_response(prompt)
        assert should_ground is False


# =============================================================================
# P1-2: Model availability validation
# =============================================================================


class TestModelAvailability:
    """Tests that model availability reflects actual usable files."""

    def test_llama_cpp_is_available_checks_file_exists(self):
        """llama_cpp provider is_available should check that files exist."""
        from sage.config import SageConfig
        from sage.providers.llama_cpp import LlamaCppProvider

        # Create a mock config with a non-existent model
        mock_config = MagicMock(spec=SageConfig)
        mock_config.local_model_names.return_value = ["test:model"]
        mock_model = MagicMock()
        mock_model.path = "/nonexistent/model.gguf"
        mock_config.get_local_model.return_value = mock_model

        provider = LlamaCppProvider(mock_config)

        # Mock llama_cpp as available
        with patch.dict("sys.modules", {"llama_cpp": MagicMock()}):
            # is_available should return False because file doesn't exist
            assert provider.is_available() is False

    def test_model_listing_shows_download_status(self):
        """Model listing should indicate if model needs download."""
        from sage.config import SageConfig
        from sage.main import _resolve_model_prefix

        cfg = SageConfig(models={"qwen2.5-coder-3b": {"path": "/missing/model.gguf"}})

        # Explicitly registered local aliases should not silently resolve
        # to an unrelated cloud model.
        resolved = _resolve_model_prefix("qwen2.5-coder-3b", cfg)
        assert resolved == "llama_cpp:qwen2.5-coder-3b"

    def test_gcs_prefix_resolves_to_local_catalog_model(self):
        """gcs: aliases should behave like downloadable local GGUF models."""
        from sage.config import SageConfig
        from sage.main import _resolve_model_prefix

        resolved = _resolve_model_prefix("gcs:qwen2.5-coder-3b", SageConfig())
        assert resolved == "llama_cpp:qwen2.5-coder-3b"

    def test_cloud_prefix_resolves_to_pollinations_model(self):
        """cloud: aliases should resolve to the actual cloud provider."""
        from sage.config import SageConfig
        from sage.main import _resolve_model_prefix

        resolved = _resolve_model_prefix("cloud:openai", SageConfig())
        assert resolved == "pollinations:openai"

    def test_package_version_matches_pyproject_metadata(self):
        """CLI version output should match the package metadata in pyproject."""
        from pathlib import Path
        import re
        import sage

        init_py = Path(__file__).parent.parent / "__init__.py"
        pyproject = Path(__file__).parent.parent.parent / "pyproject.toml"

        init_source = init_py.read_text()
        pyproject_source = pyproject.read_text()

        match = re.search(r'^version = "([^"]+)"', pyproject_source, re.MULTILINE)

        assert match is not None
        assert "__version__ = _discover_version()" in init_source
        assert sage.__version__ == match.group(1)

    def test_explicit_ollama_model_stays_exact_even_if_not_pulled(self):
        """An explicit ollama:model choice should not be silently remapped to cloud."""
        from sage.config import SageConfig
        from sage.main import _prepare_model_for_use

        cfg = SageConfig()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"models": []}

        with (
            patch("httpx.get", return_value=mock_response),
            patch(
                "sage.main.subprocess.run",
                return_value=SimpleNamespace(returncode=0, stderr="", stdout=""),
            ),
        ):
            result_cfg, model_id = _prepare_model_for_use(cfg, "ollama:qwen3.5")

        assert result_cfg is cfg
        assert model_id == "ollama:qwen3.5"
        assert not hasattr(cfg, "_ollama_fallback_needed")

    def test_explicit_ollama_model_raises_if_ollama_is_offline(self):
        """If the user explicitly asks for Ollama, we should fail clearly instead of drifting."""
        from sage.config import SageConfig
        from sage.main import _prepare_model_for_use

        with (
            patch("httpx.get", side_effect=RuntimeError("offline")),
            pytest.raises(RuntimeError, match="Ollama is not running"),
        ):
            _prepare_model_for_use(SageConfig(), "ollama:qwen3.5")

    def test_bare_ollama_catalog_name_prefers_local_provider(self):
        """Bare exact Ollama catalog names should resolve locally before cloud fuzzy fallback."""
        from sage.config import SageConfig
        from sage.main import _resolve_model_prefix

        resolved = _resolve_model_prefix("qwen3", SageConfig())
        assert resolved == "ollama:qwen3"

    def test_bare_ollama_catalog_name_stays_local_when_selected(self):
        """Bare exact Ollama selections like qwen3 should not drift to cloud providers."""
        from sage.config import SageConfig
        from sage.main import _prepare_model_for_use

        cfg = SageConfig()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"models": []}

        with (
            patch("httpx.get", return_value=mock_response),
            patch("sage.main.subprocess.run", return_value=SimpleNamespace(returncode=0, stderr="", stdout="")),
        ):
            result_cfg, model_id = _prepare_model_for_use(cfg, "qwen3")

        assert result_cfg is cfg
        assert model_id == "ollama:qwen3"
        assert not hasattr(cfg, "_ollama_fallback_needed")

    def test_missing_ollama_model_is_pulled_during_prepare(self):
        """Switching to an Ollama model in the CLI should eagerly pull it."""
        from sage.config import SageConfig
        from sage.main import _ensure_model_available

        cfg = SageConfig()
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"models": []}

        with (
            patch("httpx.get", return_value=mock_response),
            patch(
                "sage.main.subprocess.run",
                return_value=SimpleNamespace(returncode=0, stderr="", stdout=""),
            ) as mock_run,
        ):
            result = _ensure_model_available(cfg, "ollama:qwen3")

        assert result is cfg
        mock_run.assert_called_once()
        assert mock_run.call_args.args[0] == ["ollama", "pull", "qwen3"]

    def test_catalog_model_auto_downloads_when_selected(self):
        """Selecting a catalog-backed local model should trigger download + registration."""
        from sage.config import SageConfig
        from sage.main import _ensure_model_available

        fake_model = SimpleNamespace(name="test-gcs-model", backend="gguf")
        cfg = SageConfig()

        with (
            patch("sage.main._ensure_llama_cpp_runtime", return_value=True),
            patch.dict("sage.main.CATALOG_BY_NAME", {"test-gcs-model": fake_model}, clear=False),
            patch("sage.main.is_downloaded", return_value=False),
            patch("sage.main.download_model") as mock_download,
            patch("sage.main.register_model") as mock_register,
            patch("sage.main.load_config", return_value=cfg) as mock_load_config,
        ):
            result = _ensure_model_available(cfg, "gcs:test-gcs-model")

        mock_download.assert_called_once()
        assert mock_download.call_args.args[0] is fake_model
        assert "progress_callback" in mock_download.call_args.kwargs
        mock_register.assert_called_once_with(fake_model)
        mock_load_config.assert_called_once()
        assert result is cfg

    def test_catalog_model_downloads_before_runtime_fallback(self):
        """Even if llama_cpp runtime is unavailable, catalog assets should still be prepared."""
        from sage.config import SageConfig
        from sage.main import _ensure_model_available

        fake_model = SimpleNamespace(name="test-gcs-model-2", backend="gguf")
        cfg = SageConfig()

        with (
            patch("sage.main._ensure_llama_cpp_runtime", return_value=False),
            patch.dict("sage.main.CATALOG_BY_NAME", {"test-gcs-model-2": fake_model}, clear=False),
            patch("sage.main.is_downloaded", return_value=False),
            patch("sage.main.download_model") as mock_download,
            patch("sage.main.register_model") as mock_register,
            patch("sage.main.load_config", return_value=cfg),
        ):
            result = _ensure_model_available(cfg, "gcs:test-gcs-model-2")

        mock_download.assert_called_once()
        mock_register.assert_called_once_with(fake_model)
        assert getattr(result, "_llama_cpp_fallback_needed", False) is True

    def test_llama_cpp_runtime_bootstrap_can_install_dependency(self):
        """SAGE should attempt a one-time llama-cpp-python bootstrap when needed."""
        from sage import main as sage_main

        sage_main._llama_cpp_runtime_bootstrap_attempted = False
        sys.modules.pop("llama_cpp", None)

        def fake_run(*args, **kwargs):
            sys.modules["llama_cpp"] = MagicMock()
            return SimpleNamespace(returncode=0, stderr="")

        with patch.object(sage_main.subprocess, "run", side_effect=fake_run):
            assert sage_main._ensure_llama_cpp_runtime() is True

    def test_llama_cpp_install_attempts_try_binary_first(self):
        """Bootstrap should prefer a binary wheel before attempting a source build."""
        from sage.main import _llama_cpp_install_attempts

        attempts = _llama_cpp_install_attempts(
            {"cmake": False, "compiler": False, "darwin_arm64": False}
        )

        assert attempts[0][0] == "binary wheel install"
        assert "--only-binary=:all:" in attempts[0][1]
        assert len(attempts) == 1

    def test_llama_cpp_install_attempts_add_source_build_when_toolchain_present(self):
        """Bootstrap should try a source build when the local toolchain can support it."""
        from sage.main import _llama_cpp_install_attempts

        attempts = _llama_cpp_install_attempts(
            {"cmake": True, "compiler": True, "darwin_arm64": True}
        )

        assert len(attempts) == 2
        assert attempts[1][0] == "source build install"
        assert attempts[1][2] is not None
        assert "GGML_METAL=on" in attempts[1][2]["CMAKE_ARGS"]


class TestWorkspaceAccessGrounding:
    """Tests for workspace-root access messaging and dynamic recovery prompts."""

    def test_scan_project_context_with_files_returns_preview_paths(self, tmp_path):
        """Recursive scan should tell us which files were actually previewed."""
        from sage.main import _scan_project_context_with_files

        (tmp_path / "README.md").write_text("# Project\n")
        (tmp_path / "backend").mkdir()
        (tmp_path / "backend" / "app.py").write_text("print('backend')\n")
        (tmp_path / "frontend").mkdir()
        (tmp_path / "frontend" / "App.jsx").write_text("export default function App() {}\n")

        context, previewed_files = _scan_project_context_with_files(
            tmp_path,
            max_source_files=3,
            max_source_lines=10,
        )

        assert "backend/app.py" in context
        assert previewed_files
        assert all("/" in path or path.endswith((".py", ".jsx", ".md")) for path in previewed_files)

    def test_recursive_analysis_seed_reads_real_project_files(self, tmp_path):
        """Broad analysis bootstrap should recursively seed grounded file evidence."""
        from sage.core.tools import ExecutionLedger
        from sage.main import _seed_recursive_analysis_context

        (tmp_path / "README.md").write_text("# Project\n")
        (tmp_path / "pyproject.toml").write_text("[tool.pytest.ini_options]\n")
        (tmp_path / "backend").mkdir()
        (tmp_path / "backend" / "app.py").write_text("print('backend')\n")
        (tmp_path / "tests").mkdir()
        (tmp_path / "tests" / "test_app.py").write_text("def test_ok():\n    assert True\n")

        files_read: set[str] = set()
        execution_ledger = ExecutionLedger()
        execution_ledger.bind_project_root(str(tmp_path))

        context = _seed_recursive_analysis_context(
            tmp_path,
            is_local=True,
            files_read=files_read,
            execution_ledger=execution_ledger,
        )

        assert "backend/app.py" in context
        assert files_read
        assert execution_ledger.files_read

    def test_recursive_analysis_seed_selector_targets_broad_repo_audits(self):
        """Broad repo-wide analysis prompts should trigger recursive context seeding."""
        from sage.main import _classify_and_store_request, _should_seed_recursive_analysis_context

        prompt = "Analyze this codebase and tell me what needs to be fixed and improved."
        classification = _classify_and_store_request(prompt)

        assert _should_seed_recursive_analysis_context(prompt, classification) is True

    def test_multistep_pipeline_routes_seeded_broad_readonly_audits(self):
        """Broad seeded audits should use the grounded multistep path on local models."""
        from sage.main import _classify_and_store_request, _should_use_multistep_pipeline

        prompt = "Analyze this codebase and tell me what needs to be fixed and improved."
        classification = _classify_and_store_request(prompt)

        assert _should_use_multistep_pipeline(
            prompt,
            classification=classification,
            is_local_model=True,
        ) is True

    def test_collect_readonly_shell_inventory_uses_safe_bash_discovery(self, tmp_path):
        """Broad analysis bootstrap should collect a safe shell inventory from the repo root."""
        from sage.main import _collect_readonly_shell_inventory

        outputs = {
            "pwd": str(tmp_path),
            "ls -laR | head -200": ".:\ntotal 8\n-rw-r--r-- README.md\n\n./backend:\n-rw-r--r-- app.py",
            "find . -maxdepth 2 -type d | head -80": ".\n./backend\n./tests",
            "rg --files . | head -120": "README.md\nbackend/app.py\ntests/test_app.py",
        }

        with patch("sage.main._run_readonly_shell", side_effect=lambda cmd, *_args, **_kwargs: outputs[cmd]):
            inventory = _collect_readonly_shell_inventory(tmp_path, is_local=True)

        assert "BASH INVENTORY:" in inventory
        assert "$ ls -laR | head -200" in inventory
        assert "$ rg --files . | head -120" in inventory
        assert "backend/app.py" in inventory

    def test_iter_full_analysis_file_paths_includes_relevant_dotfiles(self, tmp_path):
        """Broad audits should include important hidden project files like .github workflows."""
        from sage.main import _iter_full_analysis_file_paths

        (tmp_path / ".github").mkdir()
        (tmp_path / ".github" / "workflows").mkdir()
        (tmp_path / ".github" / "workflows" / "ci.yml").write_text("name: ci\n")
        (tmp_path / ".gitignore").write_text("__pycache__/\n")
        (tmp_path / "backend").mkdir()
        (tmp_path / "backend" / "app.py").write_text("print('hi')\n")

        paths = _iter_full_analysis_file_paths(tmp_path)

        assert ".github/workflows/ci.yml" in paths
        assert ".gitignore" in paths
        assert "backend/app.py" in paths

    def test_iter_full_analysis_file_paths_excludes_runtime_conversation_logs(self, tmp_path):
        """Broad audits should skip runtime conversation logs that are not source code."""
        from sage.main import _iter_full_analysis_file_paths

        (tmp_path / "ai-platform").mkdir()
        (tmp_path / "ai-platform" / "data").mkdir()
        (tmp_path / "ai-platform" / "data" / "conversation_logs").mkdir()
        (tmp_path / "ai-platform" / "data" / "conversation_logs" / "run_outputs.json").write_text(
            "{}\n"
        )
        (tmp_path / "ai-platform" / "backend").mkdir()
        (tmp_path / "ai-platform" / "backend" / "app.py").write_text("print('hi')\n")

        paths = _iter_full_analysis_file_paths(tmp_path)

        assert "ai-platform/backend/app.py" in paths
        assert "ai-platform/data/conversation_logs/run_outputs.json" not in paths

    def test_collect_full_readonly_file_coverage_reads_all_small_project_files(self, tmp_path):
        """Broad repo analysis should READ every eligible small text file in the project."""
        from sage.core.tools import ExecutionLedger
        from sage.main import _collect_full_readonly_file_coverage

        (tmp_path / ".github").mkdir()
        (tmp_path / ".github" / "workflows").mkdir()
        (tmp_path / ".github" / "workflows" / "ci.yml").write_text("name: ci\n")
        (tmp_path / ".gitignore").write_text("__pycache__/\n")
        (tmp_path / "README.md").write_text("# Project\n")
        (tmp_path / "backend").mkdir()
        (tmp_path / "backend" / "app.py").write_text("print('backend')\n")
        (tmp_path / "tests").mkdir()
        (tmp_path / "tests" / "test_app.py").write_text("def test_ok():\n    assert True\n")

        files_read: set[str] = set()
        execution_ledger = ExecutionLedger()
        execution_ledger.bind_project_root(str(tmp_path))

        coverage = _collect_full_readonly_file_coverage(
            tmp_path,
            is_local=True,
            files_read=files_read,
            execution_ledger=execution_ledger,
        )

        assert "FULL FILE COVERAGE:" in coverage
        assert "backend/app.py" in coverage
        assert ".github/workflows/ci.yml" in coverage
        assert ".gitignore" in coverage
        assert {"README.md", "backend/app.py", "tests/test_app.py", ".gitignore", ".github/workflows/ci.yml"} <= files_read
        assert set(execution_ledger.files_read) >= {
            "README.md",
            "backend/app.py",
            "tests/test_app.py",
            ".gitignore",
            ".github/workflows/ci.yml",
        }

    def test_extract_grounded_file_references_matches_verified_paths(self):
        """Final analysis should only count file citations that match verified repo files."""
        from sage.main import _extract_grounded_file_references

        verified = {
            "ai-platform/sage/main.py",
            "ai-platform/sage/core/renderer.py",
            "README.md",
        }
        response = (
            "P0: retry loop in `ai-platform/sage/main.py:13382` still allows bad output.\n"
            "P1: parsing issue in `renderer.py:26` needs tightening.\n"
            "README.md should also be updated."
        )

        grounded = _extract_grounded_file_references(response, verified)

        assert grounded == {
            "ai-platform/sage/main.py",
            "ai-platform/sage/core/renderer.py",
            "README.md",
        }

    def test_requires_grounded_file_citations_for_broad_analysis(self):
        """Broad repo audits should require verified file citations in the final synthesis."""
        from sage.main import (
            _classify_and_store_request,
            _requires_grounded_file_citations,
        )

        prompt = "Analyze this codebase and tell me what needs to be fixed and improved."
        classification = _classify_and_store_request(prompt)

        assert _requires_grounded_file_citations(prompt, classification) is True

    def test_context_aware_validation_retry_prompt_prefers_final_synthesis_when_grounded(
        self, tmp_path
    ):
        """Once grounded evidence exists, retries should ask for corrected synthesis, not more tools."""
        from sage.main import _build_context_aware_validation_retry_prompt

        prompt = _build_context_aware_validation_retry_prompt(
            task_prompt="Analyze this codebase and tell me what needs to be fixed.",
            cwd=tmp_path,
            violations=["Grounded analysis requires explicit citations to real project files."],
            current_files_read=["ai-platform/sage/main.py", "README.md"],
            is_analysis=True,
        )

        assert "You ALREADY have grounded evidence" in prompt
        assert "Do NOT restart with READ:/SEARCH:" in prompt
        assert "Cite files such as: README.md, ai-platform/sage/main.py" in prompt or "Cite files such as:" in prompt
        assert "Do NOT include FILE: blocks" in prompt

    def test_actionable_numbered_list_detection_accepts_small_findings_lists(self):
        """A solid 3-item findings list should be reusable for follow-up implementation."""
        from sage.main import _looks_like_actionable_numbered_list

        response = (
            "1. Fix auth token retry loop in `ai-platform/sage/main.py:11900`.\n"
            "2. Add regression tests for stale context injection in `ai-platform/sage/tests/test_runtime_reliability.py:660`.\n"
            "3. Tighten plugin error handling in `ai-platform/sage/core/plugin_system.py:254`.\n"
        )

        assert _looks_like_actionable_numbered_list(response, min_items=3) is True
        assert _looks_like_actionable_numbered_list("1. One\n2. Two\n", min_items=3) is False

    def test_request_grounding_state_ignores_saved_session_reads(self, tmp_path):
        """Fresh analysis requests must not inherit stale evidence from prior sessions."""
        from sage.main import (
            _add_session_file_read,
            _initialize_request_grounding_state,
        )

        _add_session_file_read(tmp_path, "README.md")
        files_read, execution_ledger = _initialize_request_grounding_state(tmp_path)

        assert files_read == set()
        assert execution_ledger.files_read == []

    def test_request_grounding_state_seeds_only_explicit_pinned_context(self, tmp_path):
        """Files the user explicitly pinned with /read may seed the next request."""
        from sage.main import _initialize_request_grounding_state

        files_read, execution_ledger = _initialize_request_grounding_state(
            tmp_path,
            pinned_context_files={"./README.md", "src/app.py"},
        )

        assert files_read == {"README.md", "src/app.py"}
        assert execution_ledger.files_read == ["README.md", "src/app.py"]

    def test_workspace_access_note_covers_root_and_children(self, tmp_path):
        """The prompt note should make it clear that the whole invoked root is readable."""
        from sage.main import _build_workspace_access_note

        (tmp_path / "README.md").write_text("hello")
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("print('hi')\n")

        note = _build_workspace_access_note(tmp_path, max_files=10)

        assert f"Project root: {tmp_path}" in note
        assert "You may READ any file or directory inside this root and any child directory under it." in note
        assert "README.md" in note
        assert "src/main.py" in note
        assert "RUN: ls -laR | head -200" in note
        assert "RUN: rg --files . | head -120" in note

    def test_multistep_prompt_does_not_claim_listing_is_exhaustive(self, tmp_path):
        """The analysis prompt should not falsely imply the sample listing is the only readable content."""
        from sage.main import _build_multistep_phase_prompts

        (tmp_path / "pyproject.toml").write_text("[tool.pytest.ini_options]\n")
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "app.py").write_text("print('hi')\n")

        prompts = _build_multistep_phase_prompts(
            "Analyze this codebase and tell me what needs to be fixed.",
            cwd=tmp_path,
        )
        planning_prompt = prompts[0][1]

        assert "ONLY files in this project" not in planning_prompt
        assert "Use the verified paths below to start exploring; if you need more files, use SEARCH: first." in planning_prompt

    def test_workspace_map_summarizes_repo_structure(self, tmp_path):
        """CLI models should receive a grounded repo map, not just a few example paths."""
        from sage.main import _build_workspace_map

        (tmp_path / "README.md").write_text("# Project\n")
        (tmp_path / "pyproject.toml").write_text("[tool.pytest.ini_options]\n")
        (tmp_path / "backend").mkdir()
        (tmp_path / "backend" / "app.py").write_text("print('backend')\n")
        (tmp_path / "frontend").mkdir()
        (tmp_path / "frontend" / "App.jsx").write_text("export default function App() {}\n")
        (tmp_path / "tests").mkdir()
        (tmp_path / "tests" / "test_app.py").write_text("def test_ok():\n    assert True\n")

        workspace_map = _build_workspace_map(tmp_path, max_dirs=8, max_files_per_dir=3)

        assert "WORKSPACE MAP:" in workspace_map
        assert f"Project root: {tmp_path}" in workspace_map
        assert "Top-level directories: backend, frontend, tests" in workspace_map
        assert "Key config files:" in workspace_map
        assert "Directory snapshots:" in workspace_map
        assert "backend/" in workspace_map
        assert "frontend/" in workspace_map
        assert "tests/" in workspace_map
        assert "You may READ any file or directory under the project root." in workspace_map

    def test_run_bootstrap_uses_workspace_map_and_broader_local_scan(self):
        """The interactive CLI should seed startup with a workspace map and richer local scan."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "workspace_map = _build_workspace_map(" in source
        assert "You have a grounded map of the whole workspace" in source
        assert "max_tree=24" in source
        assert "max_source_files=3" in source
        assert "max_source_lines=12" in source

    def test_explicit_resume_request_requires_resume_language(self):
        """Fresh tasks should not inherit prior chat unless the user explicitly asks to resume."""
        from sage.main import _is_explicit_resume_request

        assert _is_explicit_resume_request("resume where we left off")
        assert _is_explicit_resume_request("what were we doing last time?")
        assert not _is_explicit_resume_request(
            "Analyze this codebase and tell me what needs to be fixed and improved."
        )

    def test_build_resume_context_from_memory_is_opt_in(self, tmp_path):
        """Stored conversation memory should stay dormant for normal fresh prompts."""
        from sage.main import _add_to_conversation_memory, _build_resume_context_from_memory

        _add_to_conversation_memory(tmp_path, "user", "Analyze this codebase.")
        _add_to_conversation_memory(tmp_path, "assistant", "The repo is clean and ready.")

        context = _build_resume_context_from_memory(
            tmp_path, "Analyze this codebase and tell me what needs to be fixed."
        )

        assert context == ""

    def test_build_resume_context_filters_invalid_prior_assistant_output(self, tmp_path):
        """Resume mode should filter obvious pseudo-tool garbage from prior assistant messages."""
        from sage.main import _add_to_conversation_memory, _build_resume_context_from_memory

        _add_to_conversation_memory(tmp_path, "user", "Continue debugging the repo.")
        _add_to_conversation_memory(
            tmp_path,
            "assistant",
            "<execute_bash>\npytest\n</execute_bash>\nWarning: Response has issues.",
        )
        _add_to_conversation_memory(
            tmp_path,
            "assistant",
            "I reviewed the auth flow and changed auth.py and tests/test_auth.py.",
            files_written=["auth.py", "tests/test_auth.py"],
        )

        context = _build_resume_context_from_memory(tmp_path, "resume what were we doing?")

        assert "PRIOR SESSION CONTEXT" in context
        assert "verify" in context.lower()
        assert "<execute_bash>" not in context
        assert "auth.py" in context
        assert "tests/test_auth.py" in context

    def test_recover_tasks_from_recent_analysis_memory(self, tmp_path):
        """Follow-up implementation should be able to recover recent numbered findings."""
        from sage.main import (
            DockerSandbox,
            TDDGate,
            TaskExecutionManager,
            _add_to_conversation_memory,
            _recover_tasks_from_recent_analysis_memory,
        )

        _add_to_conversation_memory(
            tmp_path,
            "assistant",
            (
                "1. Fix stale context injection in `ai-platform/sage/main.py:11737`.\n"
                "2. Add a regression test for broad-audit grounding in `ai-platform/sage/tests/test_runtime_reliability.py:700`.\n"
                "3. Downgrade invalid plugin plans to validation errors in `ai-platform/sage/core/plugin_system.py:254`.\n"
            ),
        )

        manager = TaskExecutionManager(
            tmp_path,
            TDDGate(DockerSandbox(tmp_path, network_enabled=False)),
        )

        tasks = _recover_tasks_from_recent_analysis_memory(tmp_path, manager)

        assert len(tasks) == 3
        assert tasks[0]["title"].startswith("Fix stale context injection")

    def test_recover_tasks_from_priority_heading_analysis_memory(self, tmp_path):
        """Follow-up implementation should recover tasks from Priority-style analysis headings."""
        from sage.main import (
            DockerSandbox,
            TDDGate,
            TaskExecutionManager,
            _add_to_conversation_memory,
            _recover_tasks_from_recent_analysis_memory,
        )

        _add_to_conversation_memory(
            tmp_path,
            "assistant",
            (
                "**Priority 1: CI/CD Workflow Integrity**\n"
                "- Review artifact handoff between workflows.\n"
                "- Ensure publish only runs after verified CI success.\n\n"
                "**Priority 2: Environment Configuration Management**\n"
                "- Consolidate required env var documentation.\n\n"
                "**Priority 3: Local Development Parity**\n"
                "- Align local and production config contracts.\n"
            ),
        )

        manager = TaskExecutionManager(
            tmp_path,
            TDDGate(DockerSandbox(tmp_path, network_enabled=False)),
        )

        tasks = _recover_tasks_from_recent_analysis_memory(tmp_path, manager)

        assert len(tasks) == 3
        assert tasks[0]["title"] == "CI/CD Workflow Integrity"
        assert "artifact handoff" in tasks[0]["description"].lower()

    def test_exact_prompt_pair_routes_analysis_then_tdd_followup(self, tmp_path, monkeypatch):
        """The exact user prompt pair should support analysis first, then TDD task execution."""
        from sage.main import (
            DockerSandbox,
            TDDGate,
            TaskExecutionManager,
            _add_to_conversation_memory,
            _classify_and_store_request,
            _recover_tasks_from_recent_analysis_memory,
            _should_seed_recursive_analysis_context,
            _should_use_multistep_pipeline,
        )

        analysis_prompt = "Analyze this codebase and tell me what needs to be fixed and improved."
        impl_prompt = "Implement all the fixes using TDD."
        impl_prompt_variant = "Implement with TDD to fix all the issues."

        analysis_classification = _classify_and_store_request(analysis_prompt)
        assert analysis_classification.read_only is True
        assert _should_seed_recursive_analysis_context(analysis_prompt, analysis_classification) is True
        assert _should_use_multistep_pipeline(
            analysis_prompt,
            classification=analysis_classification,
            is_local_model=True,
        ) is True

        _add_to_conversation_memory(
            tmp_path,
            "assistant",
            (
                "1. Fix weak config validation in `ai-platform/backend/config.py:12`.\n"
                "2. Add stricter request schemas in `ai-platform/backend/schemas.py:8`.\n"
                "3. Improve runtime guardrails in `ai-platform/backend/app.py:41`.\n"
            ),
        )

        manager = TaskExecutionManager(
            tmp_path,
            TDDGate(DockerSandbox(tmp_path, network_enabled=False)),
        )
        tasks = _recover_tasks_from_recent_analysis_memory(tmp_path, manager)

        assert len(tasks) == 3

        implementation_classification = _classify_and_store_request(impl_prompt)
        assert implementation_classification.read_only is False
        assert implementation_classification.requires_tdd is True

        implementation_variant_classification = _classify_and_store_request(impl_prompt_variant)
        assert implementation_variant_classification.read_only is False
        assert implementation_variant_classification.requires_tdd is True

        captured_prompts: list[str] = []

        def fake_sender(prompt: str) -> str:
            captured_prompts.append(prompt)
            return (
                "FILE: tests/test_runtime_fix.py\n"
                "```python\n"
                "def test_runtime_fix():\n"
                "    assert True\n"
                "```\n\n"
                "FILE: runtime_fix.py\n"
                "```python\n"
                "def runtime_fix():\n"
                "    return True\n"
                "```\n\n"
                "RUN: pytest tests/test_runtime_fix.py -v\n"
            )

        def fake_process_response(_response: str) -> list[str]:
            return ["tests/test_runtime_fix.py", "runtime_fix.py"]

        monkeypatch.setattr(manager, "verify_task_tests_pass", lambda task: (True, "ok"))
        success, files = manager.execute_task_with_tdd(tasks[0], fake_sender, fake_process_response)

        assert success is True
        assert files == ["tests/test_runtime_fix.py", "runtime_fix.py"]
        assert captured_prompts
        assert "Write a failing test FIRST" in captured_prompts[0]
        assert "Use FILE: blocks for code and RUN: commands for tests." in captured_prompts[0]

    def test_run_bootstrap_does_not_seed_request_reads_from_session_history(self):
        """Live REPL startup should not treat stale session history as fresh evidence."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "files_read, execution_ledger = _initialize_request_grounding_state(cwd)" in source
        assert "files_read: set[str] = set(\n        session_files" not in source
        assert "Pre-populate ledger with session files" not in source

    def test_run_bootstrap_no_longer_injects_prior_conversation_into_system_prompt(self):
        """Fresh REPL sessions should not preload stale prior assistant outputs into the system prompt."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "PREVIOUS CONVERSATION CONTEXT (CRITICAL - USE THIS)" not in source
        assert "## CRITICAL MEMORY RULES" not in source
        assert "_build_resume_context_from_memory(cwd, user_msg)" in source
        assert "_build_messages_with_optional_resume_context(engine, resume_context)" in source

    def test_manual_read_command_pins_context_for_followup_requests(self):
        """Explicit /read calls should pin files for the next request without relying on old sessions."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "sticky_context_files.add(normalized_arg)" in source
        assert "_add_session_file_read(cwd, normalized_arg)" in source
        assert "files_read, execution_ledger = _initialize_request_grounding_state(" in source

    def test_execute_task_prompt_applies_recursive_analysis_bootstrap(self):
        """Broad read-only analysis requests should receive auto-collected recursive codebase context."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "recursive_analysis_context = \"\"" in source
        assert "bash_inventory_context = \"\"" in source
        assert "full_file_coverage_context = \"\"" in source
        assert "_should_seed_recursive_analysis_context(task_prompt, classification)" in source
        assert "_seed_recursive_analysis_context(" in source
        assert "_collect_readonly_shell_inventory(" in source
        assert "_collect_full_readonly_file_coverage(" in source
        assert "## AUTO-COLLECTED RECURSIVE CODEBASE CONTEXT" in source
        assert "## AUTO-COLLECTED SHELL INVENTORY" in source
        assert "## AUTO-COLLECTED FULL FILE COVERAGE" in source

    def test_broad_local_analysis_skips_pre_multistep_ai_orchestration(self):
        """Broad local read-only analysis should skip extra orchestration model calls."""
        from sage.main import _classify_and_store_request, _should_skip_ai_orchestration

        analysis_prompt = "Analyze this codebase and tell me what needs to be fixed and improved."
        implementation_prompt = "Implement all the fixes using TDD."

        assert _should_skip_ai_orchestration(
            analysis_prompt,
            _classify_and_store_request(analysis_prompt),
            is_local=True,
        )
        assert not _should_skip_ai_orchestration(
            implementation_prompt,
            _classify_and_store_request(implementation_prompt),
            is_local=True,
        )

    def test_process_response_no_longer_salvages_descriptive_analysis_garbage(self):
        """Top-level analysis processing should reject described-tool prose without executable content."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "has_processable_content = has_valid_tool or has_file_blocks or has_bash_blocks" in source
        assert "if has_processable_content and not is_analysis_response:" in source
        assert "has_meaningful_content" not in source[source.index("behavioral_violations = []"):source.index("if _response_describes_code_without_file_blocks(response):")]

    def test_execute_task_prompt_requires_grounded_file_citations_for_broad_audits(self):
        """Broad analysis validation should reject final syntheses that lack verified file citations."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "_requires_grounded_file_citations(task_prompt, classification)" in source
        assert "_extract_grounded_file_references(" in source
        assert "Grounded analysis requires explicit citations to real project files." in source

    def test_multistep_implementation_has_direct_file_output_fallback(self):
        """If multistep implementation drifts into prose, SAGE should force a direct FILE-output retry."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "Multi-step execution produced no file writes" in source
        assert "Now execute the implementation directly." in source
        assert "Write failing tests FIRST using FILE: blocks." in source

    def test_multistep_readonly_synthesis_uses_grounding_validation(self):
        """Read-only multistep synthesis should apply the same grounding checks as single-shot analysis."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "_collect_analysis_validation_violations(" in source
        assert "requesting corrected final analysis" in source
        assert "_build_context_aware_validation_retry_prompt(" in source
        assert "_build_seeded_readonly_synthesis_prompt(" in source

    def test_recursive_followup_responses_do_not_bypass_behavioral_validation(self):
        """Recursive post-tool follow-up responses should still be behaviorally validated."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "Only validate at top level" not in source
        assert "Apply this even to recursive follow-up responses after tool execution." in source

    def test_tool_description_detector_is_tool_aware_for_batch_reads(self):
        """Valid READ batches should not be rejected as BAD_PATTERN just because paths repeat."""
        from sage.main import _detect_tool_description_vs_execution

        response = """READ: ai-platform/backend/config.py
READ: ai-platform/backend/app.py
READ: ai-platform/backend/conversations.py
READ: ai-platform/backend/prompt_engine.py
READ: ai-platform/backend/runtime_manager.py
"""

        is_descriptive, mentioned_tools = _detect_tool_description_vs_execution(response)

        assert is_descriptive is False
        assert mentioned_tools == ["READ", "READ", "READ", "READ", "READ"]

    def test_process_response_does_not_skip_file_blocks_when_tools_are_in_same_response(self):
        """Mixed READ/SEARCH plus FILE blocks must continue into the write step."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("if tool_commands:")
        end = source.index("        # ── Step 2: Write FILE: blocks", start)
        tool_section = source[start:end]

        assert 'has_embedded_actions = "FILE:" in response or bool(_extract_bash_blocks(response))' in tool_section
        assert "if not has_embedded_actions:" in tool_section
        assert "return _process_response(" in tool_section
        assert "send_fn=send" in tool_section

    def test_process_response_hides_readonly_tool_followups_until_validated(self):
        """Read-only post-tool follow-ups should not stream speculative prose before validation."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("if not has_embedded_actions:")
        end = source.index("        # ── Step 2: Write FILE: blocks", start)
        followup_section = source[start:end]

        assert "hide_readonly_followup = bool(" in followup_section
        assert "_send_single_turn_to_model(followup_prompt)" in followup_section
        assert "display_analysis_response=display_analysis_response" in followup_section
        assert "or hide_readonly_followup" in followup_section

    def test_process_response_can_print_validated_hidden_analysis_followup(self):
        """Hidden read-only follow-ups should still surface once they are validated and final."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "display_analysis_response: bool = False" in source
        assert "display_analysis_response\n            and is_analysis_response" in source
        assert 'renderer.console.print("[bold green]sage>[/bold green] ", end="")' in source

    def test_process_response_retries_behavioral_rejections_for_readonly_analysis(self):
        """Bad analysis output should trigger a corrective retry, not a terminal dead end."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("def _process_response(")
        end = source.index("        # ── Step 2: Write FILE: blocks", start)
        function_source = source[start:end]

        assert "def _retry_invalid_readonly_response(" in function_source
        assert "Behavioral violation:" in function_source
        assert "display_analysis_response=True" in function_source

    def test_process_response_retries_readonly_file_block_mode_violations(self):
        """Analysis responses that accidentally emit FILE blocks should be corrected automatically."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("if is_analysis_response and \"FILE:\" in response:")
        end = source.index("        # ── Step 2: Write FILE: blocks", start)
        mode_section = source[start:end]

        assert "Read-only mode violation: the response included FILE: blocks." in mode_section
        assert "provide findings, citations, or more READ:/SEARCH: commands instead." in mode_section

    def test_process_response_retries_prose_only_code_descriptions_in_analysis(self):
        """Read-only analysis should recover from implementation prose too, not just FILE blocks."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("if _response_describes_code_without_file_blocks(response):")
        end = source.index("        # P0-3: Use structured tool extraction instead of tuple parser", start)
        prose_section = source[start:end]

        assert "Response described code changes or implementation steps during read-only analysis." in prose_section
        assert "Provide grounded findings only." in prose_section

    def test_behavioral_detector_passes_structured_calls_to_renderer_validator(self):
        """Pattern checks should know when repeated paths come from valid parsed tool calls."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("def _detect_tool_description_vs_execution(")
        end = source.index("def _detect_repetitive_filler(", start)
        function_source = source[start:end]

        assert "structured_calls = _extract_tool_commands_structured(response)" in function_source
        assert "tool_calls=structured_calls" in function_source

    def test_recursive_followup_validation_uses_in_scope_classification(self):
        """Post-tool follow-up validation must not reference an undefined outer `classification`."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("if not has_embedded_actions:")
        end = source.index("display_analysis_response=display_analysis_response", start)
        followup_section = source[start:end]

        assert "followup_classification = (" in followup_section
        assert "effective_classification or _get_current_classification()" in followup_section
        assert "if classification and tool_depth < 4:" not in followup_section
        assert "is_analysis=followup_classification.read_only" in followup_section

    def test_recursive_followup_validation_uses_request_context_prompt(self):
        """Post-tool follow-up validation must not reference sibling-local `task_prompt`."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("if not has_embedded_actions:")
        end = source.index("display_analysis_response=display_analysis_response", start)
        followup_section = source[start:end]

        assert "current_task_prompt = _get_current_task_prompt()" in followup_section
        assert "if followup_classification and current_task_prompt and tool_depth < 4:" in followup_section
        assert "_collect_analysis_validation_violations(\n                                            followup,\n                                            current_task_prompt," in followup_section
        assert "task_prompt=task_prompt" not in followup_section

    def test_local_seeded_synthesis_prompt_prefers_recursive_context_over_shell_inventory(self):
        """Local synthesis should stay compact when recursive code context is already available."""
        from sage.main import _build_seeded_readonly_synthesis_prompt

        prompt = _build_seeded_readonly_synthesis_prompt(
            "TASK: Analyze this repo",
            seeded_recursive_analysis_context="CWD: /tmp/project\n--- app.py ---\n1| print('hi')",
            seeded_shell_inventory_context="BASH INVENTORY:\n$ ls -laR | head -200\n...",
            seeded_full_file_coverage_context="FULL FILE COVERAGE:\n...",
            verified_files={"README.md", "backend/app.py"},
            is_local=True,
        )

        assert "## AUTO-COLLECTED RECURSIVE CODEBASE CONTEXT" in prompt
        assert "VERIFIED FILE COVERAGE SUMMARY:" in prompt
        assert "## AUTO-COLLECTED SHELL INVENTORY" not in prompt

    def test_seeded_synthesis_prompt_falls_back_to_shell_inventory_without_recursive_context(self):
        """If no recursive code context exists, the shell inventory can still ground synthesis."""
        from sage.main import _build_seeded_readonly_synthesis_prompt

        prompt = _build_seeded_readonly_synthesis_prompt(
            "TASK: Analyze this repo",
            seeded_recursive_analysis_context="",
            seeded_shell_inventory_context="BASH INVENTORY:\n$ rg --files . | head -120\nREADME.md",
            seeded_full_file_coverage_context="",
            verified_files=set(),
            is_local=True,
        )

        assert "## AUTO-COLLECTED SHELL INVENTORY" in prompt
        assert "README.md" in prompt

    def test_grounded_analysis_failure_message_is_user_facing(self):
        """Fail-closed analysis messaging should stay clean and actionable."""
        from sage.main import _build_grounded_analysis_failure_message

        message = _build_grounded_analysis_failure_message()

        assert message.startswith("## Could not complete grounded analysis")
        assert "validated, file-grounded analysis response" in message

    def test_execute_task_prompt_seeds_execution_context_with_active_prompt(self):
        """The active request prompt should be stored in execution context for downstream retries."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "_current_execution_context = _RequestExecutionContext(task_prompt=task_prompt)" in source
        assert "def _get_current_task_prompt() -> str:" in source
        assert "return ctx.task_prompt if ctx else \"\"" in source

    def test_multistep_readonly_synthesis_is_hidden_until_validated(self):
        """Broad analysis synthesis should not stream speculative prose before validation."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert 'if phase_name == "synthesis" and send is _send_to_model:' in source
        assert "phase_sender = _send_single_turn_to_model" in source
        assert 'renderer.console.print("[bold green]sage>[/bold green] ", end="")' in source
        assert 'final_synthesis_response = "\\n\\n".join(cumulative_responses).strip()' in source

    def test_broad_analysis_can_skip_exploration_when_full_repo_coverage_is_seeded(self):
        """Broad local analysis should be able to synthesize directly from SAGE-collected evidence."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "def _should_use_seeded_synthesis_only(" in source
        assert "phases = _build_multistep_phase_prompts(task_prompt, classification, cwd)" in source
        assert "phases = [phase for phase in phases if phase[0] == \"synthesis\"]" in source

    def test_multistep_readonly_synthesis_fails_closed_after_retry_budget(self):
        """Invalid broad-analysis synthesis should not print ungrounded prose after retries."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "Final synthesis still ungrounded — requesting one last grounded correction..." in source
        assert "## Could not complete grounded analysis" in source
        assert "The model repeatedly failed to produce a file-grounded synthesis" in source

    def test_multistep_readonly_synthesis_no_response_fails_closed_visibly(self):
        """A timed-out hidden synthesis should not exit silently."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert (
            "if classification and classification.read_only and phase_name == \"synthesis\":"
            in source
        )
        assert "The model did not return a validated synthesis response in time." in source
        assert 'renderer.console.print("[bold green]sage>[/bold green] ", end="")' in source

    def test_hidden_send_mode_uses_non_stream_generate_path(self):
        """Silent synthesis mode should avoid streaming unvalidated output to the terminal."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("def _send_to_model(")
        end = source.index("# Always use phase streaming", start)
        hidden_section = source[start:end]

        assert "if not show_thinking:" in hidden_section
        assert "lambda: router.generate(" in hidden_section
        assert "engine.add_assistant(response)" in hidden_section

    def test_single_turn_hidden_sender_avoids_full_history_replay(self):
        """Read-only hidden synthesis should use a lightweight single-turn sender."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "def _send_single_turn_to_model(user_msg: str) -> str | None:" in source
        assert "from sage.providers.base import Message" in source
        assert 'Message(role="system", content=engine.system_prompt)' in source
        assert 'Message(role="user", content=user_msg)' in source

    def test_plugin_executor_treats_valueerror_as_validation(self):
        """Missing plugin args should be surfaced as validation problems, not internal crashes."""
        from sage.core.plugin_system import (
            PluginCapability,
            PluginErrorType,
            PluginExecutor,
            PluginInvocation,
            PluginRegistry,
        )

        class FakeAdapter:
            plugin_id = "fake"

            def capabilities(self):
                return [PluginCapability("fake", "need_name", "Needs a name arg")]

            def invoke(self, capability_name, args):
                raise ValueError("Missing required arg: name")

        registry = PluginRegistry()
        registry.register(FakeAdapter())
        executor = PluginExecutor(registry)

        result = executor.execute(PluginInvocation("fake.need_name", {}), allow_mutating=True)

        assert result.success is False
        assert result.error_type == PluginErrorType.VALIDATION
        assert result.error_message == "Missing required arg: name"

    def test_context_aware_validation_retry_prompt_prefers_direct_tdd_when_impl_is_grounded(
        self, tmp_path
    ):
        """Grounded implementation retries should push direct TDD execution, not ask for more input."""
        from sage.main import _build_context_aware_validation_retry_prompt

        prompt = _build_context_aware_validation_retry_prompt(
            task_prompt="Implement all the fixes using TDD.",
            cwd=tmp_path,
            violations=["TDD claim without files."],
            current_files_read=["ai-platform/sage/main.py", "README.md"],
            is_analysis=False,
        )

        assert "You ALREADY have verified workspace evidence" in prompt
        assert "Do NOT ask the user to provide file contents" in prompt
        assert "write failing tests FIRST using FILE: blocks" in prompt
        assert "Verified files include:" in prompt

    def test_tool_followup_prompt_for_implementation_forbids_user_handoff_and_requires_tdd(
        self, tmp_path
    ):
        """After tool results, implementation follow-ups should require direct TDD work."""
        from sage.main import _build_tool_followup_prompt, _classify_and_store_request

        classification = _classify_and_store_request("Implement all the fixes using TDD.")
        prompt = _build_tool_followup_prompt(
            "READ RESULT: ai-platform/sage/main.py",
            classification,
            tmp_path,
        )

        assert "Do NOT ask the user to provide file contents" in prompt
        assert "Write failing tests FIRST using FILE: blocks." in prompt
        assert "Use RUN: commands for the relevant tests." in prompt

    def test_bootstrap_tasks_for_multi_task_implementation_parses_hidden_numbered_list(
        self, tmp_path
    ):
        """If no prior findings list exists, SAGE should be able to bootstrap one for TDD execution."""
        from sage.main import (
            DockerSandbox,
            TDDGate,
            TaskExecutionManager,
            _bootstrap_tasks_for_multi_task_implementation,
        )

        manager = TaskExecutionManager(
            tmp_path,
            TDDGate(DockerSandbox(tmp_path, network_enabled=False)),
        )

        captured_prompts: list[str] = []

        def fake_sender(prompt: str) -> str:
            captured_prompts.append(prompt)
            return (
                "1. Tighten config validation: Strengthen env validation in ai-platform/backend/config.py.\n"
                "2. Improve schema enforcement: Add stricter request validation in ai-platform/backend/schemas.py.\n"
                "3. Harden runtime retries: Tighten invalid-output recovery in ai-platform/sage/main.py.\n"
            )

        tasks = _bootstrap_tasks_for_multi_task_implementation(
            "Implement with TDD to fix all the issues.",
            fake_sender,
            manager,
            cwd=tmp_path,
        )

        assert len(tasks) == 3
        assert tasks[0]["title"] == "Tighten config validation"
        assert "Output ONLY a numbered list" in captured_prompts[0]
        assert "No READ:, SEARCH:, RUN:, or FILE: commands." in captured_prompts[0]

    def test_standard_pipeline_forces_direct_tdd_retry_when_impl_writes_nothing(self):
        """Implementation requests should not stop after exploration or task planning alone."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "if is_implementation and not (written or all_written):" in source
        assert "Implementation produced no file changes — forcing direct TDD execution..." in source
        assert "current_files_read=list(files_read)" in source
        assert "is_analysis=False" in source

    def test_local_stream_timeouts_retry_with_non_stream_fallback(self):
        """Live local runs should not appear frozen when streaming never shows visible output."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert 'except renderer.StreamingTimeoutError as exc:' in source
        assert "Streaming produced no visible output — retrying with non-stream fallback..." in source
        assert "Retrying without streaming..." in source
        assert "lambda: router.generate(" in source

    def test_zero_write_fallback_rejects_plan_only_implementation_output(self):
        """The forced retry should explicitly call out exploration-without-execution as failure."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "No files were written or updated yet." in source
        assert "You may have only explored the repo, produced a task list," in source
        assert "or described changes without executing them." in source

    def test_execute_tool_commands_only_counts_successful_reads(self, tmp_path):
        """Failed READ guesses must not count as grounded file awareness."""
        from sage.main import _execute_tool_commands

        (tmp_path / "real.py").write_text("print('hi')\n")
        files_read: set[str] = set()
        execution_ledger = MagicMock()

        results = _execute_tool_commands(
            [("READ", "missing.py"), ("READ", "real.py")],
            tmp_path,
            files_read=files_read,
            execution_ledger=execution_ledger,
        )

        assert files_read == {"real.py"}
        combined = "\n".join(results)
        assert "[READ missing.py: file not found or empty]" in combined
        assert "File: real.py" in combined

        successes = [call.kwargs["success"] for call in execution_ledger.record_execution.call_args_list]
        assert successes == [False, True]

    def test_process_response_uses_executor_for_verified_read_tracking(self):
        """The response loop must defer read tracking to the executor, not pre-mark paths."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        start = source.index("def _process_response(")
        end = source.index("        # ── Step 2: Write FILE: blocks", start)
        function_source = source[start:end]

        assert "files_read.add(path)" not in function_source
        assert (
            "_execute_tool_commands(\n"
            "                tool_commands,\n"
            "                cwd,\n"
            "                files_read=files_read,\n"
            "                execution_ledger=execution_ledger,\n"
            "            )"
        ) in function_source

    def test_context_validator_allows_investigation_response_with_real_tools(self):
        """Read-only analysis may start with READ/SEARCH commands before any files are read."""
        from sage.main import _validate_context_gathering

        response = """I need to inspect the project structure first.

READ: README.md
SEARCH: *.py
READ: ai-platform/sage/main.py
"""

        is_valid, reason = _validate_context_gathering(
            response,
            files_read=[],
            is_analysis_request=True,
        )

        assert is_valid is True, reason

    def test_investigation_only_helper_accepts_planning_plus_real_read_commands(self):
        """A short evidence-gathering plan with real READ commands should be allowed to execute."""
        from sage.main import _is_investigation_only_response

        response = """The user is asking for a comprehensive review.

Plan:
1. Read README.md to confirm the project shape.
2. Read requirements.txt to inspect dependencies.
3. Read the main entrypoints before making claims.

READ: Dockerfile
READ: README.md
"""

        assert _is_investigation_only_response(response) is True

    def test_context_validator_allows_planning_plus_read_commands_before_findings(self):
        """Mixed planning prose plus valid tool commands should not be misclassified as findings."""
        from sage.main import _validate_context_gathering

        response = """The user is asking for a comprehensive, read-only code analysis of the entire codebase.

**Plan:**
1. Read `README.md` to confirm the project structure.
2. Read `requirements.txt` to inspect dependencies.
3. Read the main application files before making claims.
4. Read supporting modules to understand patterns.

Let's start by reading the dependencies and the main application file.

READ: Dockerfile
READ: README.md
"""

        is_valid, reason = _validate_context_gathering(
            response,
            files_read=[],
            is_analysis_request=True,
        )

        assert is_valid is True, reason

    def test_context_validator_does_not_treat_read_targets_as_hallucinated_paths(self):
        """Multiple READ targets in an investigation step should not be rejected as fake references."""
        from sage.main import _validate_context_gathering

        response = """READ: ai-platform/sage/main.py
READ: ai-platform/sage/core/prompts.py
READ: ai-platform/sage/core/renderer.py
READ: ai-platform/sage/core/tools.py
"""

        is_valid, reason = _validate_context_gathering(
            response,
            files_read=[],
            is_analysis_request=True,
        )

        assert is_valid is True, reason

    def test_source_quality_check_skips_investigation_only_responses(self):
        """Investigation-only retries should bypass list-completion quality checks."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "if is_analysis and _is_investigation_only_response(response):" in source

    def test_source_behavioral_validation_skips_effort_checks_for_investigation_only(self):
        """Read-only retries with real tool commands should not be blocked by quantity gates yet."""
        from pathlib import Path

        main_py = Path(__file__).parent.parent / "main.py"
        source = main_py.read_text()

        assert "investigation_only = is_analysis and _is_investigation_only_response(response)" in source
        assert "if quantity_expected > 0 and not investigation_only:" in source


# =============================================================================
# P1-3: Hard rejection of blank tool commands
# =============================================================================


class TestBlankToolRejection:
    """Tests that blank tool commands are hard rejected."""

    def test_blank_read_is_invalid(self):
        """READ: with no path must be rejected."""
        from sage.main import _extract_tool_commands_structured

        text = "READ:\nREAD:\nREAD:"

        calls = _extract_tool_commands_structured(text)

        # Must return empty - these are invalid
        assert len(calls) == 0

    def test_streaming_catches_blank_commands(self):
        """Streaming validator must catch blank commands early."""
        from sage.core.renderer import _detect_bad_streaming_patterns

        content = "READ:\nREAD:\nREAD:"

        is_bad, reason = _detect_bad_streaming_patterns(content)

        assert is_bad is True
        assert "blank" in reason.lower() or "empty" in reason.lower()


# =============================================================================
# P1-5: Project root binding
# =============================================================================


class TestProjectRootBinding:
    """Tests that project root is bound once per session."""

    def test_execution_ledger_binds_root_once(self):
        """ExecutionLedger should bind project root once and cache it."""
        from sage.core.tools import ExecutionLedger

        ledger = ExecutionLedger()

        # First bind
        root1 = ledger.bind_project_root("/test/path1")
        assert root1 == "/test/path1"

        # Second bind should return cached value
        root2 = ledger.bind_project_root("/test/path2")
        assert root2 == "/test/path1"  # Still first value

    def test_session_has_bound_root(self):
        """Session should have project root bound at startup."""
        # This test documents that the session initialization
        # should call ledger.bind_project_root(cwd) early
        pass


# =============================================================================
# Live model-matrix harness hygiene
# =============================================================================


class TestLiveMatrixHarness:
    """Tests for the gated live E2E model matrix harness."""

    def test_live_matrix_supports_env_filters(self):
        """The live E2E harness should support provider/model slicing."""
        from pathlib import Path

        e2e_py = Path(__file__).parent / "test_e2e_sage_models_live.py"
        source = e2e_py.read_text()

        assert "SAGE_E2E_PROVIDERS" in source
        assert "SAGE_E2E_MODEL_FILTER" in source
        assert "SAGE_E2E_MODEL_LIMIT" in source
        assert "SAGE_E2E_PROMPT_LIMIT" in source

    def test_live_matrix_avoids_import_time_ollama_probe(self):
        """Importing the live E2E file should not immediately probe Ollama."""
        from pathlib import Path

        e2e_py = Path(__file__).parent / "test_e2e_sage_models_live.py"
        source = e2e_py.read_text()

        assert "_ollama_test_bases() if _live_enabled()" not in source
        assert "bases = [" in source


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
