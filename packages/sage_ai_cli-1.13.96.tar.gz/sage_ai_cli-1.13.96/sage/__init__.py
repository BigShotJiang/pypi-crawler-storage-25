"""Sage — a local-first AI coding CLI."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
import re


def _discover_version() -> str:
    try:
        return version("sage-ai-cli")
    except PackageNotFoundError:
        pyproject = Path(__file__).resolve().parent.parent / "pyproject.toml"
        if pyproject.exists():
            match = re.search(r'^version = "([^"]+)"', pyproject.read_text(), re.MULTILINE)
            if match:
                return match.group(1)
        return "0.0.0"


__version__ = _discover_version()

