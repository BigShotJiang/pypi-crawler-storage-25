# fastncut

A Fast Algorithm for Normalized Cut with Applications on Bipartitioning Feature Maps in Deep Learning

A fast agnostic algorithm for bipartitioning images or feature maps.<BR/>Implemented in Pytorch.<BR/>Really cool!<BR/>The ingenious idea of Shi & Malik was brought into practice.
See <a href="https://github.com/andylucny/fastncut">https://github.com/andylucny/fastncut</a>

26.3.2026, 2.0.4, initial release on PyPY with documentation<BR/>
2.4.2026, 2.0.5, support of data formats nc and bnc<BR/>
3.4.2026, 2.0.6, support of masks for data formats nc and bnc<BR/>
