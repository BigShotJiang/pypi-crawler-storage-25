"""Generate model definitions."""
