"""Fetching model definitions."""
