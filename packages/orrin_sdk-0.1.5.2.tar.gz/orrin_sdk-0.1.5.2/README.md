# Orrin SDK

The Orrin SDK is the heart of the Orrin Apps infrastructure. This SDK enables developers to create the backends to the apps they host on Orrin Apps, as well as create tools to be used throughout the Stellr product ecosystem, and in their own applications.

## Usages
---

The Orrin SDK can be used for two things:

1. Backends for Orrin Apps
2. Backends for custom tools

### Backends for Orrin Apps
The Orrin SDK provides developers with the `OrrinAppsSDK` class, which is used to "register" functions as "actions" for the frontend. These actions can be used in the frontend to manipulate the UI via data.

This infrastructure is enforced to ensure stability and seggregation between the frontend that is hosted on OrrinApps and the backend. This effectively enables the backend to be completely separate from the frontend, which enables Stellr to manage apps more effeciently.

### Backends for custom tools
The Orrin SDK provides developers with the `OrrinToolsSDK` class, which is used to "register" functions as "actions" for the tools. These actions can then be utilized by AI models to perform tasks for users based on some sort of input. This entire infrastructure depends on our new protocol Exegesis, specifically the Exegesis Centralized Execution.

`OrrinToolsSDK` effectively enables users to create custom tools that can do virtually anything they'd like based on abstract inputs.

Please refer to [Stellr API Docs](https://api.stellr-company.com/ce/docs) for more information on getting started with creating a custom tool for the Stellr product ecosystem, as well as your own applications.

Please refer to the [Guide on Orrin SDK](https://stellr-company.com/orrin/sdk) for more information on the overarching SDK.

Both of these aforementioned sources provide elaborate explanations and detailed dives into how to get started with the Stellr API and Orrin SDK, as well as how to create custom app backends and custom tool backends.