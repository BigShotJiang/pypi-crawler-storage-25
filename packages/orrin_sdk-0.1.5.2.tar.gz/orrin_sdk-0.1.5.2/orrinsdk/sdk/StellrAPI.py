from dataclasses import dataclass
from typing import Any, Literal
import requests
from pydantic import BaseModel

class StellrAPI:
    class Actions:
        StartCEConnection = '_start_CE_connection_'
        GetCEConnectionHistory = '_get_CE_connection_history_'
        SendCEMessage = '_send_CE_message_'
        ExecuteRecommendedAction = '_execute_recommended_action_'
        ExecuteTool = '_execute_tool_'

    class StartCEConnection_Payload(BaseModel):
        tool_id: str

    class GetCEConnectionHistory_Payload(BaseModel):
        connection_id: str
    
    class SendCEMessage_Payload(BaseModel):
        connection_id: str
        message: str

    class ExecuteRecommendedAction_Payload(BaseModel):
        connection_id: str
        response_id: str

    class ExecuteTool_Payload(BaseModel):
        tool_id: str
        action: str
        payload: Any

    def __init__(self, developer_type: str, developer_api: str):
        self.developer_api = developer_api
        self.bearer_type = 'Dev Bearer' if developer_type == 'dev' else 'Bearer'
        self.base = 'https://api.stellr-company.com'

    def perform(
        self,
        action: Actions,
        startCEPayload: StartCEConnection_Payload = None,
        getCEConnectionHistoryPayload: GetCEConnectionHistory_Payload = None,
        sendCEMessagePayload: SendCEMessage_Payload = None,
        executeRecommendedActionPayload: ExecuteRecommendedAction_Payload = None,
        executeToolPayload: ExecuteTool_Payload = None
    ) -> tuple[int, Any] | tuple[int, str] | tuple[Literal[200], Any] | None:
        match action:
            case self.Actions.StartCEConnection:
                if startCEPayload is None:
                    raise Exception('`startCEPayload` expected for action `.StartCEConnection`.')

                return self.start_ce_connection(startCEPayload.tool_id)
            case self.Actions.GetCEConnectionHistory:
                if getCEConnectionHistoryPayload is None:
                    raise Exception('`getCEConnectionHistoryPayload` expected for action `.GetCEConnectionHistory`.')
                
                return self.get_connection_history(connection_id=getCEConnectionHistoryPayload.connection_id)
            case self.Actions.SendCEMessage:
                if sendCEMessagePayload is None:
                    raise Exception('`sendCEMessagePayload` expected for action `.SendCEMessage`.')
                
                return self.send_chat(
                    connection_id=sendCEMessagePayload.connection_id,
                    message=sendCEMessagePayload.message
                )
            case self.Actions.ExecuteRecommendedAction:
                if executeRecommendedActionPayload is None:
                    raise Exception('`executeRecommendedActionPayload` expected for action `.ExecuteRecommendedAction`.')

                return self.execute_recommended_action(
                    connection_id=executeRecommendedActionPayload.connection_id,
                    response_id=executeRecommendedActionPayload.response_id
                )
            case self.Actions.ExecuteTool:
                if executeToolPayload is None:
                    raise Exception('`executeToolPayload` expected for action `.ExecuteTool`.')

                return self.execute_tool(
                    tool_id=executeToolPayload.tool_id,
                    action=executeToolPayload.action,
                    payload=executeToolPayload.payload
                )
            
    def start_ce_connection(self, tool_id: str):
        resp = requests.post(
            f'{self.base}/v1/ce/start',
            headers={
                'Content-Type': 'application/json',
                'Authorization': f'{self.bearer_type} {self.developer_api}'
            },
            json={
                'connectedToolId': tool_id
            }
        )

        if not resp.ok:
            try:
                return resp.status_code, resp.json()
            except:
                return resp.status_code, resp.text
        
        return 200, resp.json()['connection_id']
    
    def get_connection_history(self, connection_id):
        resp = requests.get(
            f'{self.base}/v1/ce',
            headers={
                'Authorization': f'{self.bearer_type} {self.developer_api}',
                'Connection-Id': connection_id
            }
        )

        if not resp.ok:
            try:
                return resp.status_code, resp.json()
            except:
                return resp.status_code, resp.text
        
        return 200, resp.json()

    def send_chat(self, connection_id: str, message: str):
        resp = requests.post(
            f'{self.base}/v1/ce',
            headers={
                'Content-Type': 'application/json',
                'Authorization': f'{self.bearer_type} {self.developer_api}',
                'Connection-Id': connection_id
            },
            json={
                'message': message
            }
        )

        if not resp.ok:
            try:
                return resp.status_code, resp.json()
            except:
                return resp.status_code, resp.text
        
        return 200, resp.json()
    
    def execute_recommended_action(self, connection_id: str, response_id: str):
        resp = requests.get(
            f'{self.base}/v1/ce/execute',
            headers={
                'Authorization': f'{self.bearer_type} {self.developer_api}',
                'Connection-Id': connection_id,
                'Response-Id': response_id
            }
        )

        if not resp.ok:
            try:
                return resp.status_code, resp.json()
            except:
                return resp.status_code, resp.text
        
        return 200, resp.json()
    
    def execute_tool(
        self,
        tool_id: str,
        action: str,
        payload: any
    ):
        resp = requests.get(
            f'{self.base}/v1/ce/execute',
            headers={
                'Authorization': f'{self.bearer_type} {self.developer_api}'
            },
            json={
                'toolId': tool_id,
                'action': action,
                'payload': payload
            }
        )

        if not resp.ok:
            try:
                return resp.status_code, resp.json()
            except:
                return resp.status_code, resp.text
        
        return 200, resp.json()