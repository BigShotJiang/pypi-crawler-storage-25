import ast
from enum import Enum
import inspect
from json import dumps, loads
import pathlib
from typing import Dict, List
import requests
import sys
import yaml

API_BASE = "https://stellr-company.com"

class ProcessSource:
    def __init__(self):
        self.source_file = None
        self.source_content = ''

        self.allowed_imports = [
            'openai',
            'requests',
            'json',
            'datetime',
            'math',
            'numpy',
            'pandas',
            'beautifulsoup',
            'pydantic',
            'pillow',
            'nltk',
            'tiktoken',
            'anthropic',
            'google.generativeai',
            'orrinsdk'
        ]
    
    def assign_source_file(self, fn):
        try:
            self.source_file = pathlib.Path(inspect.getfile(fn))
        except Exception as e:
            print(f'Failed to obtain source file: {e}')
            sys.exit(1)

    def get_source(self):
        self.source_content = self.source_file.read_text()

    def validate_imports(self):
        tree = ast.parse(self.source_content)

        used_imports = set()

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top_level = alias.name.split('.')[0]
                    used_imports.add(top_level)

            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    top_level = node.module.split('.')[0]
                    used_imports.add(top_level)

        disallowed = used_imports - set(self.allowed_imports)

        if disallowed:
            raise ValueError(
                "\033[1;31m[orrin-sdk] DISALLOWED IMPORTS\033[0m\n\n"
                "\033[31mThe following imports are not permitted:\033[0m\n"
                "\t\033[1;37m" + ", ".join(sorted(disallowed)) + "\033[0m\n\n"
                "\033[32mAllowed imports:\033[0m\n"
                "\t\033[36m" + "\n\t".join(self.allowed_imports) + "\033[0m\n\n"
                "\033[90mPlease remove or replace the disallowed imports and try again.\033[0m"
            )
    
    def strip_with_ast(self) -> str:
        """
        Use AST to parse and remove OrrinSDK-related nodes, then unparse back to source.
        Handles various styles: aliases, multiline, etc.
        """
        tree = ast.parse(self.source_content)

        class OrrinRemover(ast.NodeTransformer):
            def visit_Import(self, node):
                # Remove imports like 'import orrinsdk' or aliases
                if any(alias.name == 'orrinsdk' for alias in node.names):
                    return None
                return node

            def visit_ImportFrom(self, node):
                # Remove 'from sdk import OrrinSDK' or 'from orrinsdk import OrrinSDK' (handle module variations)
                if node.module in {'sdk', 'orrinsdk'} and any(alias.name == 'OrrinAppsSDK' or alias.name == 'OrrinToolsSDK' for alias in node.names):
                    return None
                return node

            def visit_Assign(self, node):
                # Remove assignments like 'orrin_sdk = OrrinToolsSDK(...)' or 'orrin_sdk = OrrinAppsSDK(...)'
                if (isinstance(node.value, ast.Call) and 
                    isinstance(node.value.func, ast.Name) and 
                    node.value.func.id in {'OrrinAppsSDK', 'OrrinToolsSDK'}):
                    return None
                return node

            def visit_Expr(self, node):
                # Remove standalone calls like 'orrin_sdk.finalize()'
                if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute) and node.value.func.attr == 'finalize':
                    return None
                return node

            def visit_FunctionDef(self, node):
                # Remove decorators like '@orrin_sdk.action(...)'
                new_decorators = []
                for dec in node.decorator_list:
                    if not (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute) and dec.func.attr == 'action' or dec.func.attr == 'plugin_entry' or dec.func.attr == 'plugin_action'):
                        new_decorators.append(dec)
                node.decorator_list = new_decorators
                return self.generic_visit(node)

        remover = OrrinRemover()
        cleaned_tree = remover.visit(tree)
        ast.fix_missing_locations(cleaned_tree)
        return ast.unparse(cleaned_tree).strip()

    def strip_with_lines(self) -> str:
        """
        Fallback: Original line-based stripping, but improved to handle 'from sdk' and case-insensitivity.
        """
        lines = self.source_content.splitlines()
        filtered = []
        for l in lines:
            stripped_l = l.strip().lower()
            if (stripped_l.startswith("from sdk") or stripped_l.startswith("from orrinsdk") or
                stripped_l.startswith("import sdk") or stripped_l.startswith("import orrinsdk")):
                continue
            if 'orrinsdk' in stripped_l or '.action' in stripped_l or '.finalize' in stripped_l:
                continue
            filtered.append(l)
        return '\n'.join(filtered).strip()
        
    def exists(self):
        return self.source_file.exists()

from .OrrinToolsSDK import OrrinToolsSDK
from .OrrinAppsSDK import OrrinAppsSDK
from .OrrinAISDK import OrrinAISDK, Models