import ast
import inspect
from json import dumps
import pathlib
from .decorators import ProcessSource
import yaml, sys, requests, os, tomli

API_BASE = "https://stellr-company.com"
#API_BASE = 'http://192.168.1.96:8080'

class OrrinAppsSDK:
    def __init__(
        self,
        developer_api_key: str
    ):
        if not os.path.isfile(os.path.join(os.getcwd(), 'project.toml')):
            print(
                "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                f"\033[31mMissing `project.toml`.\033[0m\n\n"
                "Please see https://stellr-company.com/orrin/plugins for more information.\n"
                "\033[0m\n"
            )

            sys.exit(1)
            
        with open('project.toml', 'rb') as file:
            project_data = tomli.load(file)

        if not 'general' in project_data:
            print(
                "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                f"\033[31mMissing `general` section in `project.toml`.\033[0m\n\n"
                "Please see https://stellr-company.com/orrin/plugins for more information.\n"
                "\033[0m\n"
            )

            sys.exit(1)

        if not all(key in project_data['general'] for key in ['project_type', 'name', 'desc']):
            print(
                "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                f"\033[31mMissing keys for `general` section in `project.toml`.\033[0m\n\n"
                "Please see https://stellr-company.com/orrin/plugins for more information.\n"
                "\033[0m\n"
            )

            sys.exit(1)

        if not project_data['general']['project_type'] == 'app':
            print(
                "\n\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                f"\033[31mInvalid project type in `project.toml`.\033[0m\n\n"
                "\tProject type must be `app` to use `OrrinAppsSDK` class.\n\n"
                "Please see https://stellr-company.com/orrin/plugins for more information.\n"
                "\033[0m\n"
            )

            sys.exit(1)

        self.developer_api_key = developer_api_key
        self._registered_actions = []  # store action metadata
        self._source_file = None  # the file we will read later
        self.app_name = project_data['general']['name']
        self.description = project_data['general']['desc']
        self.allowed_imports = [
            'openai',
            'requests',
            'json',
            'datetime',
            'math',
            'numpy',
            'pandas',
            'beautifulsoup',
            'pydantic',
            'pillow',
            'nltk',
            'tiktoken',
            'anthropic',
            'google.generativeai',
            'orrinsdk'
        ]

    def action(self, name: str, required_payload: list = [], extra_metadata: dict = {}):
        """
        Decorator to mark a function as a platform action.
        Stores metadata but does not upload yet.
        """
        def decorator(fn):
            # Track the source file (once)
            if self._source_file is None:
                try:
                    self._source_file = pathlib.Path(inspect.getfile(fn))
                except Exception:
                    pass
            # Save action metadata
            action_data = {
                "action_name": name,
                "entrypoint": fn.__name__,
                "required_payload": required_payload,
                "runtime": "python",
                "extra_metadata": extra_metadata or None
            }
            self._registered_actions.append(action_data)
            return fn
        return decorator

    def finalize(self):
        """
        Read the full source file, strip Orrin-related code using AST (or fallback to line-based),
        and send all registered actions in one request to the backend.
        """
        if not self._registered_actions:
            print("[orrin-sdk] No actions registered, skipping upload.")
            return
        if not self._source_file or not self._source_file.exists():
            print("[orrin-sdk] Could not find source file.")
            return
        
        try:
            full_source = self._source_file.read_text()

            # 🔐 Validate imports BEFORE stripping
            self._validate_imports(full_source)

            stripped_source = self._strip_with_ast(full_source)

        except ValueError as e:
            print(f"{e}")
            return

        except Exception as e:
            print(f"[orrin-sdk] AST stripping failed ({e}), falling back to line-based.")
            stripped_source = self._strip_with_lines(full_source)

        if not stripped_source:
            print("[orrin-sdk] Stripped source is empty, aborting.")
            return

        payload = {
            'app_name': self.app_name,
            'desc': self.description,
            'source_code': stripped_source,
            'actions': self._registered_actions
        }

        try:
            response = requests.post(
                f"{API_BASE}/actions/register",
                json=payload,
                headers={
                    "Authorization": self.developer_api_key,
                    "fsdk": "yes"
                },
                timeout=10
            )
            if response.status_code == 200:
                print(
                    "\033[1;32m[orrin-sdk] SUCCESS\033[0m\n\n"
                    "\033[32mActions registered successfully!\033[0m\n\n"
                    "Approval Status: \033[1;33mPENDING\033[0m\n\n"
                    "App ID (save this — you will need it in your Next.js code):\n"
                    f"\t\033[1;36m{response.json()['AppID']}\033[0m\n\n"
                    "\033[90mAll changes or new apps must be approved after submission.\n"
                    "This process typically takes 1–3 days.\033[0m"
                )

            else:
                try:
                    data = response.json()

                    if data['ErrorCode'] == 0x60:
                        print(
                            "\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                            "\033[31mFailed to register actions.\033[0m\n\n"
                            f"The app \033[1;33m\"{self.app_name}\"\033[0m has recently been \033[1;31marchived\033[0m and is\n"
                            "not authorized for release.\n\n"
                            "If you believe this was an error, please contact Stellr:\n"
                            "\033[4;34mhttps://stellr-company.com/contact\033[0m\n\n"
                            "\033[90mPlease wait 3–7 days for the app to be completely wiped from our servers\n"
                            "before attempting to re-upload.\033[0m"
                        )

                    else:
                        print(
                            "\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                            f"\033[31mFailed to register actions\033[0m\n\n"
                            f"HTTP Status: \033[1;33m{response.status_code}\033[0m\n"
                            f"Message: \033[1;37m{response.json()['Message']}\033[0m"
                        )

                except:
                    print(
                        "\033[1;31m[orrin-sdk] ERROR\033[0m\n\n"
                        f"\033[31mFailed to register actions\033[0m\n\n"
                        f"HTTP Status: \033[1;33m{response.status_code}\033[0m\n"
                        f"Message: \033[1;37m{response.json()['Message']}\033[0m"
                    )
        except Exception as e:
            print(f"[orrin-sdk] Exception when sending actions: {e}")
    
    def _validate_imports(self, source: str):
        tree = ast.parse(source)

        used_imports = set()

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    top_level = alias.name.split('.')[0]
                    used_imports.add(top_level)

            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    top_level = node.module.split('.')[0]
                    used_imports.add(top_level)

        disallowed = used_imports - set(self.allowed_imports)

        if disallowed:
            raise ValueError(
                "\033[1;31m[orrin-sdk] DISALLOWED IMPORTS\033[0m\n\n"
                "\033[31mThe following imports are not permitted:\033[0m\n"
                "\t\033[1;37m" + ", ".join(sorted(disallowed)) + "\033[0m\n\n"
                "\033[32mAllowed imports:\033[0m\n"
                "\t\033[36m" + "\n\t".join(self.allowed_imports) + "\033[0m\n\n"
                "\033[90mPlease remove or replace the disallowed imports and try again.\033[0m"
            )


    def _strip_with_ast(self, source: str) -> str:
        """
        Use AST to parse and remove OrrinSDK-related nodes, then unparse back to source.
        Handles various styles: aliases, multiline, etc.
        """
        tree = ast.parse(source)

        class OrrinRemover(ast.NodeTransformer):
            def visit_Import(self, node):
                # Remove imports like 'import orrinsdk' or aliases
                if any(alias.name == 'orrinsdk' for alias in node.names):
                    return None
                return node

            def visit_ImportFrom(self, node):
                # Remove 'from sdk import OrrinSDK' or 'from orrinsdk import OrrinSDK' (handle module variations)
                if node.module in {'sdk', 'orrinsdk'} and any(alias.name == 'OrrinSDK' for alias in node.names):
                    return None
                return node

            def visit_Assign(self, node):
                # Remove assignments like 'orrin_sdk = OrrinSDK(...)'
                if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == 'OrrinSDK':
                    return None
                # Handle if assigned to different var names? For now, assume standard 'OrrinSDK' class name.
                return node

            def visit_Expr(self, node):
                # Remove standalone calls like 'orrin_sdk.finalize()'
                if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute) and node.value.func.attr == 'finalize':
                    return None
                return node

            def visit_FunctionDef(self, node):
                # Remove decorators like '@orrin_sdk.action(...)'
                new_decorators = []
                for dec in node.decorator_list:
                    if not (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute) and dec.func.attr == 'action'):
                        new_decorators.append(dec)
                node.decorator_list = new_decorators
                return self.generic_visit(node)

        remover = OrrinRemover()
        cleaned_tree = remover.visit(tree)
        ast.fix_missing_locations(cleaned_tree)
        return ast.unparse(cleaned_tree).strip()

    def _strip_with_lines(self, source: str) -> str:
        """
        Fallback: Original line-based stripping, but improved to handle 'from sdk' and case-insensitivity.
        """
        lines = source.splitlines()
        filtered = []
        for l in lines:
            stripped_l = l.strip().lower()
            if (stripped_l.startswith("from sdk") or stripped_l.startswith("from orrinsdk") or
                stripped_l.startswith("import sdk") or stripped_l.startswith("import orrinsdk")):
                continue
            if 'orrinsdk' in stripped_l or '.action' in stripped_l or '.finalize' in stripped_l:
                continue
            filtered.append(l)
        return '\n'.join(filtered).strip()