"""
model/cosmufr_config.py — CosmUFR v0.7 "Heavy UFR" configuration.
Target: ~125M params, 57.5M samples, k-continuous generative head.

Capacity allocation strategy:
  GenerativeHead  (k-continuous implicit field) — most capacity, d_h=2048, 6 blocks
  Encoders + Proposal                           — d_h=1024, 4 blocks each
  Energy heads                                  — d_h=512,  2-3 blocks (stable landscape)
  Settling preconditioner                       — d_h=256
  Task heads (param, unc, halo)                 — d_h=512, 2-3 blocks
"""
from dataclasses import dataclass


@dataclass
class CosmUFRConfig:
    # ── Observation ───────────────────────────────────────────────────────────
    d_obs:        int = 400    # log10 P(k): 200 k-modes x 2 redshifts
    d_obs_single: int = 200    # single redshift (sequential mode)
    n_k_modes:    int = 200    # wavenumber bins, k in [0.1, 4.5] h/Mpc
    n_k_train:    int = 100    # k-modes sampled per training step (subsampling)
                               # Run 2: 100 (2× Run 1) — richer k coverage per step
                               # B=2048×K=100×8-blocks×2048-wide = ~26M rows (monitor OOM)
                               # at inference: always queries full n_k_modes=200 grid
    n_mass_bins:  int = 20     # halo mass function bins

    # ── Belief state  b_t = [s_t | c_t | u_t | p_t] ─────────────────────────
    d_b: int = 1024   # total belief dim
    d_s: int = 512    # world-state
    d_c: int = 256    # context
    d_u: int = 128    # uncertainty
    d_p: int = 128    # prototype proximity
    # d_s + d_c + d_u + d_p == 1024 ✓

    # ── Per-component hidden dims and block counts ────────────────────────────
    # Encoders (ObsEncoder, ObsEncoderSingle, BeliefProposal)
    d_h_enc:        int = 1024   # ~8-18M per encoder
    n_blocks_enc:   int = 4

    # Generative head (k-continuous implicit field) — most capacity
    d_h_gen:        int = 2048   # ~69M — primary output head
    n_blocks_gen:   int = 8

    # Energy heads (stable landscape, don't need huge capacity)
    d_h_energy:     int = 512    # ~2M per head
    n_blocks_energy: int = 2

    # Task heads (param, uncertainty, halo)
    d_h_task:       int = 512    # ~1-4M
    n_blocks_task:  int = 2

    # Settling preconditioner/eta MLPs
    d_h_settle:     int = 256

    # ── Attractor bank ────────────────────────────────────────────────────────
    n_attractors:  int   = 4096
    attractor_top: int   = 16
    attractor_ema: float = 0.99

    # ── Settling ──────────────────────────────────────────────────────────────
    k_settle:         int   = 16
    k_backprop:       int   = 4
    P_min:            float = 0.01
    P_max:            float = 1.0
    eta_min:          float = 0.001
    eta_max:          float = 0.05
    belief_grad_clip: float = 5.0

    # ── Energy weights ────────────────────────────────────────────────────────
    l_obs:         float = 1.0
    l_con:         float = 0.5
    l_dyn:         float = 0.5
    energy_margin: float = 0.5

    # ── Two optimisers ────────────────────────────────────────────────────────
    lr_core:   float = 6e-4   # Run 2: 2× conservative (linear rule would be 4×; 2× safer)
    lr_energy: float = 2e-4   # Run 2: 2× conservative
    wd:        float = 0.01
    grad_clip: float = 1.0

    # ── Cosmological parameter ranges [Om, s8, h, ns, Ob, w0, mv, wa] ────────
    # Extended from 6→8 params to include neutrino mass mv and dark energy wa.
    # mv (neutrino mass sum): 0.0–0.4 eV;  wa (CPL dark energy): -0.5–0.5
    # Fiducial: mv=0.0 eV (massless), wa=0.0 (cosmological constant)
    n_cosmo_params: int   = 8
    om_min: float = 0.10;  om_max: float = 0.50
    s8_min: float = 0.52;  s8_max: float = 1.00
    h_min:  float = 0.60;  h_max:  float = 0.80
    ns_min: float = 0.90;  ns_max: float = 1.02
    ob_min: float = 0.03;  ob_max: float = 0.07
    w0_min: float = -1.20; w0_max: float = -0.80
    mv_min: float = 0.00;  mv_max: float = 0.40   # neutrino mass sum [eV]
    wa_min: float = -0.50; wa_max: float = 0.50   # dark energy CPL wa

    # ── k grid ────────────────────────────────────────────────────────────────
    k_min: float = 0.1
    k_max: float = 4.5

    # ── GCS paths ─────────────────────────────────────────────────────────────
    gcs_bucket: str = "cosmufr-training"
    gcs_data:   str = "gs://cosmufr-training/data/master"
    gcs_ckpts:  str = "gs://cosmufr-training/checkpoints/v07"
    gcs_results:str = "gs://cosmufr-training/results/v07"

    # ── Training ──────────────────────────────────────────────────────────────
    phase:      int = 0
    batch_size: int = 256
    version:    str = "0.7"
