"""
model/train_vertex.py — CosmUFR v0.7 "Heavy UFR" training on Vertex AI / local GPU.

Entry point for the Docker container on Vertex AI Custom Training.
Reads the master dataset from GCS, trains CosmUFRLite through 5 phases,
writes checkpoints + metrics back to GCS.

Master dataset layout (8-param, 94M samples):
  params_master.npy   [N, 8]   [Om, s8, h, ns, Ob, w0, mv, wa]
  pk_z0_master.npy    [N, 200] log P(k) at z=0  (resampled to k_common)
  pk_z047_master.npy  [N, 200] log P(k) at z=0.47
  k_bins_master.npy   [200]    k-grid in h/Mpc
  source_labels.npy   [N]      uint8 source ID {0..8}

Usage:
  # Validation (pipeline smoke test — 500 steps ~3 min)
  python model/train_vertex.py --validate_only --max_steps_per_epoch 500

  # Full curriculum with virtual epochs of 5000 steps (~16.5 hrs, ~$5.79 on T4 spot)
  python model/train_vertex.py --phase_schedule --max_steps_per_epoch 5000

  # Full curriculum with virtual epochs of 10000 steps (~33 hrs, ~$11.57 on T4 spot)
  python model/train_vertex.py --phase_schedule --max_steps_per_epoch 10000

  # NEVER run without --max_steps_per_epoch: 1 epoch = 657K steps = 70 hrs on T4!

Phase schedule (--phase_schedule):
  0 — warmup     (1 epoch,  no loss, collect b_star stats, seed AttractorBank)
  1 — recovery   (8 epochs, L_param + L_energy — encode P(k) -> all 8 params)
  2 — calibrate  (4 epochs, + L_nll uncertainty calibration)
  3 — generative (16 epochs, + L_gen k-continuous P(k) NLL + L_proto)    [Run 2: +4 vs Run 1]
  4 — sequential (16 epochs, + L_seq two-redshift sequential belief update) [Run 2: +10 vs Run 1]
  Total: 45 virtual epochs

Run 2 settings (A100 spot, B=2048, BF16, 8 workers):
  max_steps_per_epoch=5250 → ~7.5 min/epoch → 45 epochs = ~5.6 hrs = ~$10.1
  NO CAP                   → full dataset pass per epoch (use --max_steps_per_epoch!)
"""
import os, sys, time, json, argparse, logging
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler

sys.path.insert(0, str(Path(__file__).parent.parent))
from model.cosmufr_config   import CosmUFRConfig
from model.cosmufr_arch     import CosmUFRLite, make_optimizers
from model.cosmufr_losses   import compute_losses
from model.cosmufr_evaluate import evaluate_on_val

# ─────────────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s  %(levelname)s  %(message)s',
    datefmt='%H:%M:%S',
)
log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# GCS helpers
# ─────────────────────────────────────────────────────────────────────────────

def gcs_cp(src: str, dst: str, quiet: bool = False):
    cmd = f"gsutil cp {src} {dst}"
    if quiet:
        cmd += " 2>/dev/null"
    ret = os.system(cmd)
    return ret == 0


def gcs_rsync(src: str, dst: str):
    log.info(f"rsync {src} -> {dst}")
    os.system(f"gsutil -m rsync -r {src} {dst}")


# ─────────────────────────────────────────────────────────────────────────────
# Master dataset (memory-mapped numpy arrays)
# ─────────────────────────────────────────────────────────────────────────────

class MasterDataset(Dataset):
    """
    Memory-mapped CosmUFR v0.7 master dataset.

    Provides triplets: (obs [400], params [8], pk_z0 [200])
    where obs = concat[log10(pk_z0), log10(pk_z047)] — both redshifts stacked.

    Validation set: last val_frac of the dataset (stratified by source_labels
    to ensure all 9 sources are represented).
    """

    def __init__(self, data_dir: str, split: str = 'train', val_frac: float = 0.005):
        d = Path(data_dir)

        params_path   = d / "params_master.npy"
        pk_z0_path    = d / "pk_z0_master.npy"
        pk_z047_path  = d / "pk_z047_master.npy"
        labels_path   = d / "source_labels.npy"

        # Memory-map — no RAM cost until accessed
        self.params   = np.load(params_path,  mmap_mode='r')
        self.pk_z0    = np.load(pk_z0_path,   mmap_mode='r')
        self.pk_z047  = np.load(pk_z047_path, mmap_mode='r')
        labels        = np.load(labels_path)                   # uint8 [N]

        N = len(self.params)
        # Build stratified val indices: take last val_frac from each source
        n_val_per_src = max(1, int(N * val_frac / 9))
        val_idx = []
        for src_id in range(9):
            src_mask = np.where(labels == src_id)[0]
            if len(src_mask) > 0:
                val_idx.extend(src_mask[-n_val_per_src:].tolist())
        val_idx = sorted(set(val_idx))
        train_idx = np.setdiff1d(np.arange(N), val_idx)

        if split == 'train':
            self.indices       = train_idx
            self.source_labels = labels[train_idx].copy()            # [N_train] uint8
        else:
            self.indices       = np.array(val_idx, dtype=np.int64)
            self.source_labels = labels[np.array(val_idx)].copy()    # [N_val] uint8

        log.info(f"MasterDataset {split}: {len(self.indices):,} samples")

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, i):
        idx = int(self.indices[i])

        # Copy out of memmap to avoid pin_memory issues
        p0  = np.array(self.pk_z0[idx],   dtype=np.float32)
        p47 = np.array(self.pk_z047[idx], dtype=np.float32)
        par = np.array(self.params[idx],   dtype=np.float32)

        # log10 transform for observation (model input)
        log_pk_z0  = np.log10(np.maximum(p0,  1e-30))
        log_pk_z47 = np.log10(np.maximum(p47, 1e-30))
        obs = np.concatenate([log_pk_z0, log_pk_z47])  # [400]

        return (
            torch.from_numpy(obs),   # [400]
            torch.from_numpy(par),   # [8]
            torch.from_numpy(p0),    # [200] raw P(k) for loss
        )


# ─────────────────────────────────────────────────────────────────────────────
# Training epoch
# ─────────────────────────────────────────────────────────────────────────────

def train_epoch(model, loader, opt_core, opt_energy, cfg, phase, device, epoch,
                b_star_accum=None, max_steps=None):
    """
    Run one pass over the training loader, optionally capped at max_steps.

    max_steps: if set, stop after this many batches (virtual epoch).
               With 84M samples at batch=128 → 657K steps/full-epoch.
               max_steps=5000 → ~32 min on T4, covers ~640K samples/pass.
    b_star_accum: if provided (list), appends b_star tensors for AttractorBank init.
    Returns dict of averaged loss scalars.
    """
    model.train()
    running = {}
    n_batches = 0
    t_batch = time.time()

    for step, (obs, params, pk_z0) in enumerate(loader):
        if max_steps is not None and step >= max_steps:
            break
        obs    = obs.to(device,    non_blocking=True)
        params = params.to(device, non_blocking=True)
        pk_z0  = pk_z0.to(device,  non_blocking=True)

        b_prev = torch.zeros(obs.shape[0], cfg.d_b, device=device)

        # k-subsampling: sample n_k_train of 200 k-bins per step to cap GenerativeHead memory
        # B=128 x K=50 x 8 blocks x 2048 wide = ~6.4K rows (vs 51.2K at full resolution)
        if cfg.n_k_train < cfg.n_k_modes:
            k_idx   = torch.randperm(cfg.n_k_modes, device=device)[:cfg.n_k_train]
            log_k_s = model.log_k_train[k_idx]
            pk_z0_s = pk_z0[:, k_idx]
        else:
            log_k_s = None   # use full grid
            pk_z0_s = pk_z0

        # BF16 autocast — ~2× throughput on A100, no GradScaler needed
        with torch.autocast(device_type='cuda', dtype=torch.bfloat16,
                            enabled=(device == 'cuda')):
            out        = model(obs, b_prev, log_k=log_k_s)
            batch_dict = {'params': params, 'pk_z0': pk_z0_s}
            losses     = compute_losses(model, out, batch_dict, phase)

        if phase > 0:
            opt_core.zero_grad(set_to_none=True)
            opt_energy.zero_grad(set_to_none=True)
            (losses['L_core'] + losses['L_energy_total']).backward()
            nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            opt_core.step()
            opt_energy.step()

        # Accumulate b_star for phase 0 AttractorBank seeding
        if b_star_accum is not None and len(b_star_accum) < 16384:
            b_star_accum.append(out['b_star'].detach().cpu())

        # Update attractor EMA after each batch in phase 3+
        if phase >= 3:
            model.attractor_bank.ema_update(out['b_star'].detach())

        for k, v in losses.items():
            if hasattr(v, 'item'):
                running[k] = running.get(k, 0.0) + v.item()

        n_batches += 1

        # Progress log every 500 steps
        n_total = min(len(loader), max_steps) if max_steps else len(loader)
        if (step + 1) % 500 == 0:
            rate = 500 / (time.time() - t_batch)
            t_batch = time.time()
            log.info(
                f"  Ph{phase} Ep{epoch+1} step {step+1}/{n_total}"
                f"  L_core={losses.get('L_core', 0.0).item() if hasattr(losses.get('L_core', 0.0), 'item') else 0.0:.4f}"
                f"  {rate:.1f} it/s"
            )

    return {k: v / max(n_batches, 1) for k, v in running.items()}


# ─────────────────────────────────────────────────────────────────────────────
# LR scheduler factory
# ─────────────────────────────────────────────────────────────────────────────

def make_schedulers(opt_core, opt_energy, n_epochs):
    sched_core   = torch.optim.lr_scheduler.CosineAnnealingLR(opt_core,   T_max=n_epochs, eta_min=1e-5)
    sched_energy = torch.optim.lr_scheduler.CosineAnnealingLR(opt_energy, T_max=n_epochs, eta_min=1e-6)
    return sched_core, sched_energy


# ─────────────────────────────────────────────────────────────────────────────
# Checkpoint helpers
# ─────────────────────────────────────────────────────────────────────────────

def save_ckpt(path, model, phase, epoch, metrics=None):
    state = {
        'phase':   phase,
        'epoch':   epoch,
        'model':   model.state_dict(),
        'metrics': metrics or {},
    }
    torch.save(state, path)


def load_ckpt(path, model, device):
    state = torch.load(path, map_location=device)
    model.load_state_dict(state['model'])
    return state.get('phase', 0), state.get('epoch', 0), state.get('metrics', {})


# ─────────────────────────────────────────────────────────────────────────────
# Main training function
# ─────────────────────────────────────────────────────────────────────────────

def train(args):
    cfg    = CosmUFRConfig()
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    log.info(f"Device: {device}")
    log.info(f"CosmUFR v{cfg.version}  |  {cfg.n_cosmo_params}-param  |  d_b={cfg.d_b}")

    # ── Download data from GCS if not available locally ───────────────────────
    data_dir = Path(args.data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)

    if args.gcs_data:
        for fname in ['params_master.npy', 'pk_z0_master.npy', 'pk_z047_master.npy',
                      'k_bins_master.npy', 'source_labels.npy']:
            local = data_dir / fname
            if not local.exists():
                log.info(f"Downloading {fname} from GCS...")
                gcs_cp(f"{args.gcs_data}/{fname}", str(local))

    # ── Dataset and loaders ───────────────────────────────────────────────────
    log.info("Building datasets...")
    train_ds = MasterDataset(str(data_dir), split='train')
    val_ds   = MasterDataset(str(data_dir), split='val')

    n_workers = min(8, os.cpu_count() or 1)

    # Weighted sampler: 3× oversampling for source labels 5,6,7 (mν-rich sources)
    # ~68-82% of samples have mv=0; upweighting mν>0 sources improves mv recovery
    sample_weights          = np.ones(len(train_ds), dtype=np.float32)
    mv_mask                 = np.isin(train_ds.source_labels, [5, 6, 7])
    sample_weights[mv_mask] = 3.0
    train_sampler = WeightedRandomSampler(
        weights=torch.from_numpy(sample_weights),
        num_samples=len(train_ds),
        replacement=True,
    )
    log.info(f"WeightedSampler: {mv_mask.sum():,}/{len(train_ds):,} mν samples upweighted 3×")

    train_loader = DataLoader(
        train_ds, batch_size=args.batch_size, sampler=train_sampler,
        num_workers=n_workers, pin_memory=(device == 'cuda'),
        persistent_workers=(n_workers > 0),
        prefetch_factor=4 if n_workers > 0 else None,
    )
    val_loader = DataLoader(
        val_ds, batch_size=args.batch_size, shuffle=False,
        num_workers=2, pin_memory=(device == 'cuda'),
        prefetch_factor=2,
    )

    log.info(f"Train: {len(train_ds):,}  Val: {len(val_ds):,}  "
             f"Steps/epoch: {len(train_loader):,}")

    # ── Model ─────────────────────────────────────────────────────────────────
    model = CosmUFRLite(cfg).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    log.info(f"Model: {n_params/1e6:.1f}M params")

    # ── Checkpoint setup ──────────────────────────────────────────────────────
    ckpt_dir = Path(args.ckpt_dir)
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    latest_ckpt = ckpt_dir / 'latest.pt'
    best_ckpt   = ckpt_dir / 'best.pt'

    start_phase = 0
    start_epoch = 0

    if args.resume:
        # Try local first, then GCS (preemption recovery on spot instances)
        if not latest_ckpt.exists() and args.gcs_ckpts:
            log.info("Checking GCS for preemption checkpoint...")
            gcs_cp(f"{args.gcs_ckpts}/latest.pt", str(latest_ckpt), quiet=True)
        if latest_ckpt.exists():
            start_phase, start_epoch, ckpt_metrics = load_ckpt(latest_ckpt, model, device)
            log.info(f"Resumed from phase={start_phase} epoch={start_epoch}")

    # ── Phase schedule ────────────────────────────────────────────────────────
    if args.phase_schedule:
        # Run 2 curriculum — extended Ph3+Ph4 for gen-head re-adaptation & mν recovery.
        # A100 spot, B=2048, BF16, max_steps_per_epoch=5250:
        #   45 epochs x ~7.5 min/epoch = ~5.6 hrs = ~$10.1
        phase_epochs = [(0, 1), (1, 8), (2, 4), (3, 16), (4, 16)]
    elif args.validate_only:
        # 1-epoch pipeline validation: just phase 1 for 1 epoch (capped by max_steps_per_epoch)
        phase_epochs = [(1, 1)]
    else:
        phase_epochs = [(args.phase, args.epochs)]

    results_log = []
    best_r2_om  = -float('inf')

    for phase, n_epochs in phase_epochs:
        if phase < start_phase:
            log.info(f"Skipping phase {phase} (already completed)")
            continue

        cfg.phase = phase
        opt_core, opt_energy = make_optimizers(model, cfg)
        sched_core, sched_energy = make_schedulers(opt_core, opt_energy, n_epochs)

        log.info(f"{'='*60}")
        log.info(f"Phase {phase}  n_epochs={n_epochs}  lr_core={cfg.lr_core}")
        log.info(f"{'='*60}")

        resume_epoch = start_epoch if phase == start_phase else 0

        # Phase 0: collect b_star stats, seed AttractorBank
        b_star_accum = [] if phase == 0 else None

        for epoch in range(resume_epoch, n_epochs):
            t0 = time.time()

            train_metrics = train_epoch(
                model, train_loader, opt_core, opt_energy,
                cfg, phase, device, epoch, b_star_accum=b_star_accum,
                max_steps=args.max_steps_per_epoch,
            )
            sched_core.step()
            sched_energy.step()

            elapsed = time.time() - t0
            log.info(
                f"  Ph{phase} Ep{epoch+1}/{n_epochs}"
                f"  L_core={train_metrics.get('L_core', 0):.4f}"
                f"  L_energy={train_metrics.get('L_energy', 0):.4f}"
                f"  time={elapsed/60:.1f}min"
            )

            # Save latest for preemption recovery
            save_ckpt(latest_ckpt, model, phase, epoch + 1)
            if args.gcs_ckpts:
                gcs_cp(str(latest_ckpt), f"{args.gcs_ckpts}/latest.pt", quiet=True)

            # Validation every 2 epochs or final epoch
            if (epoch + 1) % 2 == 0 or epoch == n_epochs - 1:
                val_metrics = evaluate_on_val(model, val_loader, cfg, device)
                ece = val_metrics['ece']
                log.info(
                    f"    Val: "
                    f"rmse_Om={val_metrics['rmse_Om']:.4f}  "
                    f"rmse_s8={val_metrics['rmse_s8']:.4f}  "
                    f"rmse_mv={val_metrics['rmse_mv']:.4f}  "
                    f"r2_Om={val_metrics['r2_Om']:.3f}  "
                    f"pk_mse={val_metrics['pk_mse']:.4f}  "
                    f"ece={ece:.4f}"
                )

                record = {
                    'phase': phase, 'epoch': epoch + 1, 'elapsed_min': elapsed / 60,
                    **{f'train_{k}': v for k, v in train_metrics.items()},
                    **val_metrics,
                }
                results_log.append(record)

                # Re-save latest.pt with val_metrics embedded (so checkpoint carries metrics)
                save_ckpt(latest_ckpt, model, phase, epoch + 1, val_metrics)
                if args.gcs_ckpts:
                    gcs_cp(str(latest_ckpt), f"{args.gcs_ckpts}/latest.pt", quiet=True)

                r2_om = val_metrics['r2_Om']
                if phase >= 2 and r2_om > best_r2_om:
                    best_r2_om = r2_om
                    save_ckpt(best_ckpt, model, phase, epoch + 1, val_metrics)
                    if args.gcs_ckpts:
                        gcs_cp(str(best_ckpt), f"{args.gcs_ckpts}/best.pt", quiet=True)
                    log.info(f"    ★ New best R²_Om={r2_om:.4f}")

                model.train()

        # Phase 0: seed AttractorBank from collected b_star
        if phase == 0 and b_star_accum:
            log.info(f"Seeding AttractorBank from {sum(b.shape[0] for b in b_star_accum):,} belief vectors...")
            b_all = torch.cat(b_star_accum, dim=0)
            model.attractor_bank.initialize_from_beliefs(b_all.to(device))
            log.info("AttractorBank seeded.")

        # Phase checkpoint
        phase_ckpt = ckpt_dir / f'phase{phase}_final.pt'
        save_ckpt(phase_ckpt, model, phase, n_epochs)
        if args.gcs_ckpts:
            gcs_cp(str(phase_ckpt), f"{args.gcs_ckpts}/phase{phase}_final.pt", quiet=True)

        # Per-phase results JSON (in addition to cumulative end-of-run file)
        phase_results_path = ckpt_dir / f'results_phase{phase}.json'
        with open(phase_results_path, 'w') as f:
            json.dump(results_log, f, indent=2)
        if args.gcs_results:
            gcs_cp(str(phase_results_path),
                   f"{args.gcs_results}/results_phase{phase}.json", quiet=True)

        start_phase = phase + 1
        start_epoch = 0

    # ── Save cumulative results log ───────────────────────────────────────────
    results_path = ckpt_dir / 'training_results.json'
    with open(results_path, 'w') as f:
        json.dump(results_log, f, indent=2)
    if args.gcs_results:
        gcs_cp(str(results_path), f"{args.gcs_results}/training_results.json", quiet=True)

    log.info("Training complete.")
    log.info(f"Best R²_Om: {best_r2_om:.4f}")
    return best_r2_om


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='CosmUFR v0.7 training')
    parser.add_argument('--data_dir',       default='/tmp/cosmufr/master',
                        help='Local path to master dataset files')
    parser.add_argument('--ckpt_dir',       default='/tmp/cosmufr/checkpoints')
    parser.add_argument('--gcs_data',       default='gs://cosmufr-training/data/master',
                        help='GCS prefix for master dataset (set empty to skip download)')
    parser.add_argument('--gcs_ckpts',      default='gs://cosmufr-training/checkpoints/v07')
    parser.add_argument('--gcs_results',    default='gs://cosmufr-training/results/v07')
    parser.add_argument('--phase',          type=int,   default=1)
    parser.add_argument('--epochs',         type=int,   default=1)
    parser.add_argument('--batch_size',     type=int,   default=128)
    parser.add_argument('--phase_schedule', action='store_true',
                        help='Run full phase 0-4 curriculum')
    parser.add_argument('--validate_only',  action='store_true',
                        help='1-epoch pipeline validation (no GCS data required if local present)')
    parser.add_argument('--max_steps_per_epoch', type=int, default=None,
                        help='Cap steps per epoch (virtual epoch). With 84M samples at B=128 '
                             'a full epoch=657K steps=70hrs. Recommended: 5000 (32min) or 10000 (64min). '
                             'None = full pass through dataset.')
    parser.add_argument('--resume',         action='store_true',
                        help='Resume from latest checkpoint (preemption recovery)')
    parser.add_argument('--no_gcs',        action='store_true',
                        help='Disable all GCS downloads/uploads (local-only mode)')
    args = parser.parse_args()

    if args.no_gcs:
        args.gcs_data = ''
        args.gcs_ckpts = ''
        args.gcs_results = ''

    train(args)
