"""
model/cosmufr_evaluate.py — Validation metrics for CosmUFR v0.7.
8-param output: [Om, s8, h, ns, Ob, w0, mv, wa]
"""
import numpy as np
import torch

PARAM_LABELS = ['Om', 's8', 'h', 'ns', 'Ob', 'w0', 'mv', 'wa']


def rmse(y_pred: np.ndarray, y_true: np.ndarray) -> float:
    return float(np.sqrt(np.mean((y_pred - y_true) ** 2)))


def r2(y_pred: np.ndarray, y_true: np.ndarray) -> float:
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - y_true.mean()) ** 2)
    return float(1 - ss_res / (ss_tot + 1e-12))


def expected_calibration_error(y_pred: np.ndarray,
                                y_std:  np.ndarray,
                                y_true: np.ndarray,
                                n_bins: int = 10) -> float:
    """
    Coverage-based ECE for regression uncertainty calibration.

    For each confidence level α, check whether the fraction of true values
    that fall within the predicted α-confidence interval matches α.
    If the model is perfectly calibrated (z ~ N(0,1)), empirical coverage = α.

    z = (y_true - y_pred) / y_std — normalised residual.
    Threshold for level α: z_thr = Φ⁻¹((1+α)/2)  (two-sided normal quantile).
    Empirical coverage: fraction of |z| ≤ z_thr.
    ECE = mean |empirical_coverage(α) − α| over n_bins.
    Target: ECE < 0.10.
    """
    from scipy.special import ndtri          # Φ⁻¹  (inverse normal CDF)
    z      = (y_true - y_pred) / (y_std + 1e-8)   # normalised residual [N, 8]
    alphas = np.linspace(0.1, 0.9, n_bins)         # confidence levels 10% … 90%
    ece    = 0.0
    for alpha in alphas:
        z_thr    = float(ndtri((1.0 + alpha) / 2.0))    # e.g. α=0.9 → z_thr≈1.645
        empirical = float(np.mean(np.abs(z) <= z_thr))   # empirical coverage
        ece      += abs(empirical - alpha)
    return float(ece / n_bins)


@torch.no_grad()
def evaluate_on_val(model, val_loader, cfg, device='cpu') -> dict:
    """
    Run model on val_loader; return dict of scalar metrics.
    Expects batch = (obs [B,400], params [B,8], pk_z0 [B,200]).
    """
    model.eval()
    all_params_pred, all_params_true = [], []
    all_var, all_pk_mse = [], []

    for batch in val_loader:
        obs, params, pk_z0 = batch[0].to(device), batch[1].to(device), batch[2].to(device)
        out = model(obs)

        all_params_pred.append(out['params'].cpu().numpy())
        all_params_true.append(params.cpu().numpy())
        all_var.append(out['variances'].cpu().numpy())

        # P(k) reconstruction MSE (log-space)
        log_pk_true = torch.log10(pk_z0.clamp(min=1e-30))
        pk_mse = float(((out['pk_mean'] - log_pk_true) ** 2).mean().item())
        all_pk_mse.append(pk_mse)

    pred = np.concatenate(all_params_pred, axis=0)   # [N, 8]
    true = np.concatenate(all_params_true, axis=0)   # [N, 8]
    var  = np.concatenate(all_var,         axis=0)   # [N, 8]
    std  = np.sqrt(np.maximum(var, 1e-8))

    metrics = {}
    # Per-parameter RMSE and R²
    for i, lbl in enumerate(PARAM_LABELS):
        metrics[f'rmse_{lbl}'] = rmse(pred[:, i], true[:, i])
        metrics[f'r2_{lbl}']   = r2(pred[:, i],   true[:, i])

    # Overall ECE (all params flattened)
    metrics['ece']    = expected_calibration_error(pred, std, true)
    metrics['pk_mse'] = float(np.mean(all_pk_mse))

    # Energy descent ratio: average across logged energies
    # (reported separately from metrics, but log first/last if available)
    return metrics
