"""
model/cosmufr_losses.py — Phased loss functions for CosmUFR v0.7 "Heavy UFR".

Phase schedule
--------------
Phase 0 (warmup):      No gradient loss. Collect b_star stats; seed AttractorBank.
Phase 1 (recovery):    L_param — teach encoders to recover all 6 cosmo params.
Phase 2 (calibrate):   + L_nll — calibrate per-parameter uncertainties.
Phase 3 (generative):  + L_gen — k-continuous P(k) NLL (primary scientific loss).
                        + L_proto — belief coherence via attractor bank.
Phase 4 (sequential):  + L_seq — sequential belief update quality.

Energy heads are trained at all phases >= 1 via L_energy (separate optimizer).
"""
import torch
import torch.nn.functional as F


# ─────────────────────────────────────────────────────────────────────────────
# Individual loss components
# ─────────────────────────────────────────────────────────────────────────────

def param_loss(params_pred: torch.Tensor,
               params_true: torch.Tensor) -> torch.Tensor:
    """MSE over all 6 cosmological parameters [Om, s8, h, ns, Ob, w0].
    Normalised to unit-variance by parameter range widths."""
    # Physical ranges [Om, s8, h, ns, Ob, w0, mv, wa]
    # Normalise so all 8 parameters contribute equally to gradient signal.
    ranges = params_true.new_tensor([0.40, 0.48, 0.20, 0.12, 0.04, 0.40, 0.40, 1.00])
    diff = (params_pred - params_true) / ranges
    return diff.pow(2).mean()


def nll_loss(params_pred: torch.Tensor,
             variances: torch.Tensor,
             params_true: torch.Tensor) -> torch.Tensor:
    """Gaussian NLL over 6 params with predicted per-param variances.
    L = 0.5 * [err^2/var + log(var)]   averaged over batch x params."""
    err  = params_pred - params_true
    return (0.5 * (err.pow(2) / variances + variances.log())).mean()


def gen_nll_loss(pk_mean: torch.Tensor,
                 pk_logvar: torch.Tensor,
                 log_pk_true: torch.Tensor) -> torch.Tensor:
    """
    Gaussian NLL for k-continuous P(k) prediction.
    pk_mean, pk_logvar : [B, K]  (output of GenerativeHead)
    log_pk_true        : [B, K]  log10 P(k) from master dataset

    Numerically stable: clamp logvar to [-10, 10] before exp.
    """
    logvar = torch.clamp(pk_logvar, -10.0, 10.0)
    var    = torch.exp(logvar)
    err    = pk_mean - log_pk_true
    return (0.5 * (err.pow(2) / var + logvar)).mean()


def energy_loss(model, b_star: torch.Tensor,
                z: torch.Tensor,
                b_prev: torch.Tensor) -> torch.Tensor:
    """
    Train energy heads to give low energy at the settled belief b_star.
    Also adds a hinge margin so b_star is a proper minimum:
      E(b_star) + margin < E(b_noisy)   [contrastive]

    Gradient flows through energy heads only (opt_energy).
    b_star is detached so this does NOT update the core.
    """
    b_star_d = b_star.detach()
    z_d      = z.detach()
    b_prev_d = b_prev.detach()

    E_star = model.energy_fn(b_star_d, z_d, b_prev_d)   # [B]

    # Contrastive: compare to Gaussian-perturbed belief
    noise  = torch.randn_like(b_star_d) * 0.5
    b_neg  = b_star_d + noise
    E_neg  = model.energy_fn(b_neg, z_d, b_prev_d)      # [B]

    margin = 0.5
    contrastive = F.relu(margin + E_star - E_neg).mean()
    anchor      = E_star.mean()                           # push b_star to low energy

    return anchor + contrastive


def seq_consistency_loss(b_star_seq: torch.Tensor,
                         b_star_joint: torch.Tensor) -> torch.Tensor:
    """
    Encourages sequential update to reach the same settled belief as joint.
    b_star_seq   : [B, d_b]  belief after sequential z047 update
    b_star_joint : [B, d_b]  belief from joint obs encoder (detached target)
    """
    target = b_star_joint.detach()
    return F.mse_loss(b_star_seq, target)


# ─────────────────────────────────────────────────────────────────────────────
# Main loss dispatcher
# ─────────────────────────────────────────────────────────────────────────────

def compute_losses(model,
                   out: dict,
                   batch: dict,
                   phase: int) -> dict:
    """
    Parameters
    ----------
    model : CosmUFRLite  (needed for energy_fn in L_energy)
    out   : forward() output dict
              keys: z, b_hat, b_star, params, variances,
                    pk_mean [B,K], pk_logvar [B,K], nmass [B,20],
                    L_proto (scalar tensor), energy_log (list of floats)
    batch : {
        'params'   : [B, 6]   true [Om, s8, h, ns, Ob, w0]
        'pk_z0'    : [B, 200] log10 P(k) at z=0
        'pk_z047'  : [B, 200] log10 P(k) at z=0.47
        'b_star_seq': [B, d_b]  (optional, phase 4 sequential b_star)
    }
    phase : 0-4

    Returns
    -------
    dict with keys:
        L_core          — gradient into opt_core
        L_energy_total  — gradient into opt_energy
        + all sub-losses for logging
    """
    device = out['params'].device
    zero   = torch.tensor(0.0, device=device)

    # ── Phase 0: warmup ───────────────────────────────────────────────────────
    if phase == 0:
        return {
            'L_core':         zero,
            'L_energy_total': zero,
            'L_param':        zero,
        }

    # ── Ground truth tensors ──────────────────────────────────────────────────
    params_true = batch['params'].to(device)        # [B, 6]

    # ── L_param: normalised MSE over all 6 params (phases 1+) ────────────────
    L_param = param_loss(out['params'], params_true)

    # ── L_energy: train energy heads (phases 1+) ─────────────────────────────
    L_energy = energy_loss(model, out['b_star'], out['z'],
                           torch.zeros_like(out['b_star']))   # b_prev=0 default

    W_PARAM = 5.0   # param recovery dominates until phase 3

    # ── Phase 1 ───────────────────────────────────────────────────────────────
    if phase == 1:
        return {
            'L_core':         W_PARAM * L_param,
            'L_energy_total': L_energy,
            'L_param':        L_param,
            'L_energy':       L_energy,
        }

    # ── L_nll: uncertainty calibration (phases 2+) ───────────────────────────
    L_nll = nll_loss(out['params'], out['variances'], params_true)

    # ── Phase 2 ───────────────────────────────────────────────────────────────
    if phase == 2:
        return {
            'L_core':         W_PARAM * L_param + 0.1 * L_nll,
            'L_energy_total': L_energy,
            'L_param':        L_param,
            'L_nll':          L_nll,
            'L_energy':       L_energy,
        }

    # ── L_gen: k-continuous P(k) NLL (phases 3+) ─────────────────────────────
    # Use z=0 power spectrum (primary observable); pk_mean/pk_logvar from model
    log_pk_true = torch.log10(batch['pk_z0'].to(device).clamp(min=1e-30))
    L_gen = gen_nll_loss(out['pk_mean'], out['pk_logvar'], log_pk_true)

    # ── L_proto: attractor coherence (phases 3+) ─────────────────────────────
    L_proto = out.get('L_proto', zero)

    # ── Phase 3 ───────────────────────────────────────────────────────────────
    if phase == 3:
        L_core = (W_PARAM * L_param
                  + 0.1 * L_nll
                  + 1.0 * L_gen
                  + 0.1 * L_proto)
        return {
            'L_core':         L_core,
            'L_energy_total': L_energy,
            'L_param':        L_param,
            'L_nll':          L_nll,
            'L_gen':          L_gen,
            'L_proto':        L_proto,
            'L_energy':       L_energy,
        }

    # ── L_seq: sequential belief consistency (phase 4) ───────────────────────
    b_star_seq = batch.get('b_star_seq', None)
    if b_star_seq is not None:
        L_seq = seq_consistency_loss(b_star_seq.to(device), out['b_star'])
    else:
        L_seq = zero

    L_core = (W_PARAM * L_param
              + 0.1 * L_nll
              + 1.0 * L_gen
              + 0.1 * L_proto
              + 0.5 * L_seq)
    return {
        'L_core':         L_core,
        'L_energy_total': L_energy,
        'L_param':        L_param,
        'L_nll':          L_nll,
        'L_gen':          L_gen,
        'L_proto':        L_proto,
        'L_seq':          L_seq,
        'L_energy':       L_energy,
    }
