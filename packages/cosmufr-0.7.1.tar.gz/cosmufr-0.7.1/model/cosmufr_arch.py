"""
model/cosmufr_arch.py  —  CosmUFR v0.7 "Heavy UFR"
====================================================
125M-parameter cosmological emulator, fully UFR-native.
No attention, no transformers, no MoE.

Components
----------
ResidualBlock       : 2-layer MLP block with skip connection + LayerNorm
ResidualMLP         : stack of N ResidualBlocks with input/output projections
ObsEncoder          : log10 P(k) [400d] -> z_t [1024d]   (8-layer residual, 22M)
ObsEncoderSingle    : log10 P(k) [200d] -> z_t [1024d]   (8-layer residual, 21M)
BeliefProposal      : (z_t, b_prev) -> b_hat              (8-layer residual, 21M)
SettlingCore        : b_hat -> b_star via 16-step energy GD with preconditioner (3M)
AttractorBank       : 4096 prototype belief vectors [1024d]  (4.2M)
GenerativeHead      : (b_star, log_k) -> log P(k)  k-continuous implicit field (25M)
ObsEnergyHead       : E_obs(b, z)    [6-layer residual, 6M]
ConstraintHead      : E_con(b)       [4-layer MLP,      3M]
DynEnergyHead       : E_dyn(b,b_prev)[6-layer residual, 6M]
ParameterHead       : b_star -> [Om,s8,h,ns,Ob,w0]  [4-layer MLP, 4M]
UncertaintyHead     : b_star -> 6 variances          [3-layer MLP, 2M]
HaloMassHead        : b_star -> n(M) 20 bins         [5-layer residual, 8M]
CosmUFRLite         : full model assembling all components
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint as grad_ckpt
from model.cosmufr_config import CosmUFRConfig


# ─────────────────────────────────────────────────────────────────────────────
# Building blocks
# ─────────────────────────────────────────────────────────────────────────────

class ResidualBlock(nn.Module):
    """Linear(d,d) -> GELU -> LayerNorm -> Linear(d,d) + skip."""
    def __init__(self, d: int, dropout: float = 0.0):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d, d),
            nn.GELU(),
            nn.LayerNorm(d),
            nn.Linear(d, d),
        )
        self.norm = nn.LayerNorm(d)
        self.drop = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.norm(x + self.drop(self.net(x)))


class ResidualMLP(nn.Module):
    """
    in_dim -> Linear(in_dim, d_h) -> [n_blocks x ResidualBlock(d_h)] -> Linear(d_h, out_dim)

    use_checkpoint=True enables gradient checkpointing per block — recomputes activations
    during backward instead of storing them.  ~8x memory reduction for deep/wide MLPs,
    ~30% compute overhead.  Always enabled for GenerativeHead (B*K*d_h is huge).
    """
    def __init__(self, in_dim: int, out_dim: int, d_h: int, n_blocks: int,
                 dropout: float = 0.0, use_checkpoint: bool = False):
        super().__init__()
        self.proj_in        = nn.Sequential(nn.Linear(in_dim, d_h), nn.LayerNorm(d_h))
        self.blocks         = nn.ModuleList([ResidualBlock(d_h, dropout) for _ in range(n_blocks)])
        self.proj_out       = nn.Linear(d_h, out_dim)
        self.use_checkpoint = use_checkpoint

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.proj_in(x)
        for block in self.blocks:
            if self.use_checkpoint and h.requires_grad:
                h = grad_ckpt(block, h, use_reentrant=False)
            else:
                h = block(h)
        return self.proj_out(h)


# ─────────────────────────────────────────────────────────────────────────────
# Observation encoders
# ─────────────────────────────────────────────────────────────────────────────

class ObsEncoder(nn.Module):
    """log10 P(k) [400d: 200 k-bins x 2 redshifts] -> z_t [1024d].  ~8M params."""
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.net = ResidualMLP(cfg.d_obs, cfg.d_b, cfg.d_h_enc, cfg.n_blocks_enc)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class ObsEncoderSingle(nn.Module):
    """log10 P(k) [200d: single redshift] -> z_t [1024d].  ~8M params.
    Used in sequential mode (phase 4) when processing each redshift independently."""
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.net = ResidualMLP(cfg.d_obs_single, cfg.d_b, cfg.d_h_enc, cfg.n_blocks_enc)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


# ─────────────────────────────────────────────────────────────────────────────
# Belief proposal  (residual update: b_hat = b_prev + delta_b)
# ─────────────────────────────────────────────────────────────────────────────

class BeliefProposal(nn.Module):
    """(z_t [1024d], b_prev [1024d]) -> b_hat [1024d].  ~18M params.
    Outputs delta_b; b_hat = b_prev + delta_b (residual update preserves prior)."""
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.net = ResidualMLP(cfg.d_b + cfg.d_b, cfg.d_b, cfg.d_h_enc, cfg.n_blocks_enc)

    def forward(self, z: torch.Tensor, b_prev: torch.Tensor) -> torch.Tensor:
        delta = self.net(torch.cat([z, b_prev], dim=-1))
        return delta + b_prev


# ─────────────────────────────────────────────────────────────────────────────
# Energy heads  (updated by optimizer_energy ONLY)
# ─────────────────────────────────────────────────────────────────────────────

class ObsEnergyHead(nn.Module):
    """E_obs(b, z): inconsistency between belief and observation.  ~2M params."""
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.net = ResidualMLP(cfg.d_b + cfg.d_b, 1, cfg.d_h_energy, cfg.n_blocks_energy)

    def forward(self, b: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
        return self.net(torch.cat([b, z], dim=-1)).squeeze(-1)


class ConstraintHead(nn.Module):
    """E_con(b): internal belief consistency (physical priors).  ~1M params."""
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.net = ResidualMLP(cfg.d_b, 1, cfg.d_h_energy, cfg.n_blocks_energy)

    def forward(self, b: torch.Tensor) -> torch.Tensor:
        return self.net(b).squeeze(-1)


class DynEnergyHead(nn.Module):
    """E_dyn(b, b_prev): temporal belief consistency.  ~2M params."""
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.net = ResidualMLP(cfg.d_b + cfg.d_b, 1, cfg.d_h_energy, cfg.n_blocks_energy)

    def forward(self, b: torch.Tensor, b_prev: torch.Tensor) -> torch.Tensor:
        return self.net(torch.cat([b, b_prev], dim=-1)).squeeze(-1)


# ─────────────────────────────────────────────────────────────────────────────
# Settling core  —  16-step energy gradient descent with learned preconditioner
# ─────────────────────────────────────────────────────────────────────────────

class SettlingCore(nn.Module):
    """
    Finds b_star = argmin_b E(b, z, b_prev) via k_settle gradient descent steps.
    Per-step learned preconditioner P(b) and step-size eta(b).
    Last k_backprop steps retain computation graph; earlier steps are detached.
    """
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.cfg = cfg
        # Per-step preconditioner: b -> diag(R^d_b) in [P_min, P_max]
        self.precond = nn.ModuleList([
            nn.Sequential(nn.Linear(cfg.d_b, cfg.d_h_settle),
                          nn.GELU(),
                          nn.Linear(cfg.d_h_settle, cfg.d_b))
            for _ in range(cfg.k_settle)
        ])
        # Per-step step-size: b -> scalar in [eta_min, eta_max]
        self.eta_net = nn.ModuleList([
            nn.Sequential(nn.Linear(cfg.d_b, 64), nn.GELU(), nn.Linear(64, 1))
            for _ in range(cfg.k_settle)
        ])

    def forward(self, b_hat: torch.Tensor, energy_fn, z: torch.Tensor,
                b_prev: torch.Tensor):
        """
        Args:
            b_hat     : [B, d_b] initial belief proposal
            energy_fn : callable(b, z, b_prev) -> scalar energy per sample [B]
            z         : [B, d_b] observation embedding
            b_prev    : [B, d_b] previous belief
        Returns:
            b_star    : [B, d_b] settled belief
            energy_log: list of k_settle+1 energy scalars (for monitoring)
        """
        cfg = self.cfg
        b = b_hat
        energy_log = []

        with torch.no_grad():
            energy_log.append(energy_fn(b, z, b_prev).mean().item())

        for step in range(cfg.k_settle):
            retain = (step >= cfg.k_settle - cfg.k_backprop)

            b = b.detach()

            # Always enable grad for the energy gradient computation
            with torch.enable_grad():
                b_g = b.requires_grad_(True)
                E = energy_fn(b_g, z.detach(), b_prev.detach())
                grad = torch.autograd.grad(E.sum(), b_g, create_graph=retain)[0]
            grad = torch.clamp(grad, -cfg.belief_grad_clip, cfg.belief_grad_clip)

            # Preconditioner (diagonal approximation) — no grad needed
            with torch.no_grad():
                P = torch.sigmoid(self.precond[step](b))
                P = cfg.P_min + (cfg.P_max - cfg.P_min) * P
                eta_raw = self.eta_net[step](b)
                eta = cfg.eta_min + (cfg.eta_max - cfg.eta_min) * torch.sigmoid(eta_raw)

            # Gradient step: detach grad for non-backprop steps
            if retain:
                b = b - eta * P * grad           # retain graph for last k_backprop steps
            else:
                b = b - eta * P * grad.detach()  # detach: no graph needed

            with torch.no_grad():
                energy_log.append(energy_fn(b.detach(), z.detach(), b_prev.detach()).mean().item())

        return b, energy_log


# ─────────────────────────────────────────────────────────────────────────────
# Attractor bank  —  4096 prototype belief vectors
# ─────────────────────────────────────────────────────────────────────────────

class AttractorBank(nn.Module):
    """
    4096 prototype belief vectors in R^d_b.
    Matching via cosine similarity; EMA update during training.
    """
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.cfg = cfg
        self.attractors = nn.Parameter(
            torch.randn(cfg.n_attractors, cfg.d_b) * 0.02,
            requires_grad=False   # updated by EMA, not backprop
        )
        self._initialized = False

    @torch.no_grad()
    def initialize_from_beliefs(self, beliefs: torch.Tensor):
        """K-means init: called after warmup epoch with collected b_star samples."""
        if beliefs.shape[0] < self.cfg.n_attractors:
            # Fallback: random subset + random noise
            idx = torch.randint(0, beliefs.shape[0], (self.cfg.n_attractors,))
            self.attractors.data = F.normalize(beliefs[idx], dim=-1) + \
                                   0.01 * torch.randn_like(self.attractors)
        else:
            # Simple batched k-means (1 iteration — good enough for init)
            idx = torch.randperm(beliefs.shape[0])[:self.cfg.n_attractors]
            self.attractors.data = F.normalize(beliefs[idx], dim=-1)
        self._initialized = True

    @torch.no_grad()
    def ema_update(self, b_star: torch.Tensor):
        """Update attractors with EMA using assigned b_star samples."""
        a_norm = F.normalize(self.attractors, dim=-1)
        b_norm = F.normalize(b_star, dim=-1)
        sim = b_norm @ a_norm.T          # [B, n_attractors]
        assign = sim.argmax(dim=-1)      # [B]
        for i in range(self.cfg.n_attractors):
            mask = (assign == i)
            if mask.any():
                mean_b = b_star[mask].mean(0)
                self.attractors[i] = (self.cfg.attractor_ema * self.attractors[i] +
                                      (1 - self.cfg.attractor_ema) * mean_b)

    def prototype_loss(self, b_star: torch.Tensor) -> torch.Tensor:
        """L_proto: pull b_star toward nearest attractor."""
        a_norm = F.normalize(self.attractors.detach(), dim=-1)
        b_norm = F.normalize(b_star, dim=-1)
        sim = b_norm @ a_norm.T          # [B, n_attractors]
        max_sim = sim.max(dim=-1).values # [B]
        return -max_sim.mean()


# ─────────────────────────────────────────────────────────────────────────────
# k-continuous Generative Head  —  implicit neural field for P(k)
# ─────────────────────────────────────────────────────────────────────────────

class GenerativeHead(nn.Module):
    """
    k-continuous implicit neural field: (b_star, log_k) -> [log_pk_mean, log_pk_logvar]

    At training  : called with all n_k_modes k-values simultaneously via batch expansion.
    At inference : can query at ANY k value, not just training grid.

    Input  : concat[b_star (d_b=1024), log(k) (1)] = 1025 dims
    Output : [log_pk_mean, log_pk_logvar] — 2 scalars per (sample, k) pair
    """
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.cfg = cfg
        # use_checkpoint=True: recompute activations during backward (~8x less memory)
        # Essential for T4 16GB: B=128 x K=50 x 8 blocks x 2048 wide would OOM without it
        self.net = ResidualMLP(cfg.d_b + 1, 2, cfg.d_h_gen, cfg.n_blocks_gen,
                               use_checkpoint=True)

    def forward(self, b_star: torch.Tensor,
                log_k: torch.Tensor) -> tuple:
        """
        Args:
            b_star : [B, d_b]
            log_k  : [K]  or  [B, K]  log-wavenumber values to query
        Returns:
            pk_mean   : [B, K]
            pk_logvar : [B, K]
        """
        B = b_star.shape[0]
        if log_k.dim() == 1:
            K = log_k.shape[0]
            # Expand: b_star [B,d_b] -> [B,K,d_b], log_k [K] -> [B,K,1]
            b_exp  = b_star.unsqueeze(1).expand(B, K, -1)      # [B, K, d_b]
            k_exp  = log_k.unsqueeze(0).expand(B, K).unsqueeze(-1)  # [B, K, 1]
        else:
            K = log_k.shape[1]
            b_exp = b_star.unsqueeze(1).expand(B, K, -1)
            k_exp = log_k.unsqueeze(-1)

        inp = torch.cat([b_exp, k_exp], dim=-1)                # [B, K, d_b+1]
        out = self.net(inp.reshape(B * K, -1)).reshape(B, K, 2) # [B, K, 2]
        return out[..., 0], out[..., 1]   # pk_mean, pk_logvar


# ─────────────────────────────────────────────────────────────────────────────
# Task heads
# ─────────────────────────────────────────────────────────────────────────────

class ParameterHead(nn.Module):
    """b_star -> [Om, s8, h, ns, Ob, w0] clamped to physical ranges.  ~4M params."""
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.cfg = cfg
        self.net = ResidualMLP(cfg.d_b, cfg.n_cosmo_params, cfg.d_h_task, cfg.n_blocks_task)
        self.register_buffer('p_min', torch.tensor([
            cfg.om_min, cfg.s8_min, cfg.h_min,
            cfg.ns_min, cfg.ob_min, cfg.w0_min,
            cfg.mv_min, cfg.wa_min]))
        self.register_buffer('p_max', torch.tensor([
            cfg.om_max, cfg.s8_max, cfg.h_max,
            cfg.ns_max, cfg.ob_max, cfg.w0_max,
            cfg.mv_max, cfg.wa_max]))

    def forward(self, b: torch.Tensor) -> torch.Tensor:
        raw = self.net(b)
        return torch.sigmoid(raw) * (self.p_max - self.p_min) + self.p_min


class UncertaintyHead(nn.Module):
    """b_star -> 6 per-parameter variances (NLL-calibrated).  ~2M params."""
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.net = ResidualMLP(cfg.d_b, cfg.n_cosmo_params, cfg.d_h_task, cfg.n_blocks_task)

    def forward(self, b: torch.Tensor) -> torch.Tensor:
        return torch.clamp(F.softplus(self.net(b)) + 1e-2, max=4.0)


class HaloMassHead(nn.Module):
    """b_star -> n(M) halo mass function at n_mass_bins bins.  ~8M params."""
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.net = ResidualMLP(cfg.d_b, cfg.n_mass_bins, cfg.d_h_task, cfg.n_blocks_task)

    def forward(self, b: torch.Tensor) -> torch.Tensor:
        return self.net(b)


# ─────────────────────────────────────────────────────────────────────────────
# Belief sub-component helpers
# ─────────────────────────────────────────────────────────────────────────────

def split_belief(b: torch.Tensor, cfg: CosmUFRConfig):
    """[B, d_b] -> (s, c, u, p) named sub-beliefs."""
    s = b[:, :cfg.d_s]
    c = b[:, cfg.d_s:cfg.d_s + cfg.d_c]
    u = b[:, cfg.d_s + cfg.d_c:cfg.d_s + cfg.d_c + cfg.d_u]
    p = b[:, cfg.d_s + cfg.d_c + cfg.d_u:]
    return s, c, u, p


# ─────────────────────────────────────────────────────────────────────────────
# Full model
# ─────────────────────────────────────────────────────────────────────────────

class CosmUFRLite(nn.Module):
    """
    CosmUFR v0.7 "Heavy UFR"  —  ~125M parameters.

    Forward pass (joint, phase 0-3):
        obs [B, 400] -> ObsEncoder -> z [B, 1024]
        (z, b_prev)  -> BeliefProposal -> b_hat [B, 1024]
        b_hat        -> SettlingCore   -> b_star [B, 1024]
        b_star       -> ParameterHead  -> params [B, 6]
        b_star       -> UncertaintyHead -> variances [B, 6]
        (b_star, k)  -> GenerativeHead -> pk_mean, pk_logvar [B, K]
        b_star       -> HaloMassHead   -> nmass [B, 20]
        b_star       -> AttractorBank.prototype_loss()

    Forward pass (sequential, phase 4):
        obs_z0  [B, 200] -> ObsEncoderSingle -> z0  -> b_star_z0
        obs_z047[B, 200] -> ObsEncoderSingle -> z047 -> b_star_z047 (b_prev=b_star_z0)
    """
    def __init__(self, cfg: CosmUFRConfig):
        super().__init__()
        self.cfg = cfg

        # Encoders
        self.obs_encoder        = ObsEncoder(cfg)
        self.obs_encoder_single = ObsEncoderSingle(cfg)

        # Belief
        self.belief_proposal = BeliefProposal(cfg)
        self.settling        = SettlingCore(cfg)
        self.attractor_bank  = AttractorBank(cfg)

        # Energy heads (theta_E — updated by optimizer_energy only)
        self.obs_energy_head = ObsEnergyHead(cfg)
        self.constraint_head = ConstraintHead(cfg)
        self.dyn_energy_head = DynEnergyHead(cfg)

        # Task heads
        self.param_head = ParameterHead(cfg)
        self.unc_head   = UncertaintyHead(cfg)
        self.gen_head   = GenerativeHead(cfg)
        self.halo_head  = HaloMassHead(cfg)

        # Register training k-grid as buffer (used by forward for default queries)
        log_k = torch.linspace(math.log(cfg.k_min), math.log(cfg.k_max), cfg.n_k_modes)
        self.register_buffer('log_k_train', log_k)

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight, gain=0.5)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    # ── Energy functional ────────────────────────────────────────────────────
    def energy_fn(self, b: torch.Tensor, z: torch.Tensor,
                  b_prev: torch.Tensor) -> torch.Tensor:
        """E(b, z, b_prev) = l_obs*E_obs + l_con*E_con + l_dyn*E_dyn.  [B]"""
        cfg = self.cfg
        E_obs = self.obs_energy_head(b, z)
        E_con = self.constraint_head(b)
        E_dyn = self.dyn_energy_head(b, b_prev)
        return cfg.l_obs * E_obs + cfg.l_con * E_con + cfg.l_dyn * E_dyn

    # ── Forward ──────────────────────────────────────────────────────────────
    def forward(self, obs: torch.Tensor,
                b_prev: torch.Tensor = None,
                single_z: bool = False,
                log_k: torch.Tensor = None,
                return_full: bool = True) -> dict:
        """
        Args:
            obs       : [B, d_obs] or [B, d_obs_single] if single_z=True
            b_prev    : [B, d_b]  prior belief; zeros if None
            single_z  : use ObsEncoderSingle (200-dim input)
            log_k     : [K] wavenumbers to query; defaults to training grid
            return_full: if False, skip generative + halo heads (faster for warmup)
        Returns:
            dict with keys: z, b_hat, b_star, params, variances,
                            pk_mean, pk_logvar, nmass, energy_log, L_proto
        """
        B      = obs.shape[0]
        device = obs.device
        cfg    = self.cfg

        if b_prev is None:
            b_prev = torch.zeros(B, cfg.d_b, device=device)

        # 1. Encode observation
        if single_z:
            z = self.obs_encoder_single(obs)
        else:
            z = self.obs_encoder(obs)

        # 2. Belief proposal
        b_hat = self.belief_proposal(z, b_prev)

        # 3. Energy settling -> b_star
        b_star, energy_log = self.settling(b_hat, self.energy_fn, z, b_prev)

        # 4. Task heads
        params    = self.param_head(b_star)
        variances = self.unc_head(b_star)

        out = dict(
            z=z, b_hat=b_hat, b_star=b_star,
            params=params, variances=variances,
            energy_log=energy_log,
        )

        if return_full:
            if log_k is None:
                log_k = self.log_k_train
            pk_mean, pk_logvar = self.gen_head(b_star, log_k)
            nmass = self.halo_head(b_star)
            L_proto = self.attractor_bank.prototype_loss(b_star)
            out.update(pk_mean=pk_mean, pk_logvar=pk_logvar,
                       nmass=nmass, L_proto=L_proto)

        return out


# ─────────────────────────────────────────────────────────────────────────────
# Optimizer factory
# ─────────────────────────────────────────────────────────────────────────────

def make_optimizers(model: CosmUFRLite, cfg: CosmUFRConfig):
    """
    Two optimizers:
      opt_core   — all non-energy parameters (lr=3e-4)
      opt_energy — energy heads only         (lr=1e-4)
    """
    energy_ids = set(id(p) for p in [
        *model.obs_energy_head.parameters(),
        *model.constraint_head.parameters(),
        *model.dyn_energy_head.parameters(),
    ])
    core_params   = [p for p in model.parameters()
                     if id(p) not in energy_ids and p.requires_grad]
    energy_params = [p for p in model.parameters()
                     if id(p) in energy_ids and p.requires_grad]

    opt_core   = torch.optim.AdamW(core_params,   lr=cfg.lr_core,   weight_decay=cfg.wd)
    opt_energy = torch.optim.AdamW(energy_params, lr=cfg.lr_energy, weight_decay=cfg.wd)
    return opt_core, opt_energy
