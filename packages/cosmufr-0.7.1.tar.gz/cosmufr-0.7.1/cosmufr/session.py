"""
cosmufr/session.py — CosmUFRSession: stateful sequential inference
===================================================================
Threads belief state between observations. Each add_observation() call
uses the previous settled belief as b_prev, so the model accumulates
evidence across multiple telescopes/surveys.

This is the mechanism behind the Hubble tension demo:
  session.add_observation(*load_planck2018())  → first belief
  session.add_observation(*load_desi_dr2())    → belief updated with DESI
  session.param_evolution()                    → shows Omega_m / h shift
"""
from __future__ import annotations

from typing import Optional, TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from cosmufr.inference import CosmUFR, CosmUFRResult

try:
    import torch
    _TORCH_AVAILABLE = True
except ImportError:
    _TORCH_AVAILABLE = False


class CosmUFRSession:
    """
    Stateful sequential inference session.

    Manages b_prev threading between observations. Each call to
    add_observation() updates the internal belief state and returns
    a CosmUFRResult that reflects all evidence seen so far.

    Parameters
    ----------
    model : CosmUFR
        Loaded model from cosmufr.load().

    Example
    -------
    >>> session = CosmUFRSession(model)
    >>> r1 = session.add_observation(*load_planck2018(), label="Planck 2018")
    >>> r2 = session.add_observation(*load_desi_dr2(),   label="DESI DR2")
    >>> evol = session.param_evolution()
    >>> print(evol["Omega_m"])  # [planck_value, desi_value]
    """

    PARAM_NAMES = ["Omega_m", "sigma_8", "h", "n_s", "Omega_b", "w0", "mnu", "wa"]

    def __init__(self, model: "CosmUFR"):
        self.model = model
        self._b_prev: Optional["torch.Tensor"] = None
        self.belief_history:  list[np.ndarray]       = []
        self.result_history:  list["CosmUFRResult"]  = []
        self.labels:          list[str]              = []

    def add_observation(
        self,
        pk_z0:   np.ndarray,
        pk_z047: np.ndarray,
        label:   str = "",
    ) -> "CosmUFRResult":
        """
        Add a new P(k) observation and update the belief state.

        Parameters
        ----------
        pk_z0 : np.ndarray, shape [200]
            log10 P(k) at z=0 interpolated to model k-grid.
        pk_z047 : np.ndarray, shape [200]
            log10 P(k) at z≈0.47 interpolated to model k-grid.
        label : str, optional
            Human-readable label for this observation (e.g. "Planck 2018").

        Returns
        -------
        CosmUFRResult
            Inference result conditioned on all observations so far.
        """
        result = self.model.predict(pk_z0, pk_z047, b_prev=self._b_prev)

        if _TORCH_AVAILABLE:
            self._b_prev = (
                torch.tensor(result.belief, device=self.model._device)
                .unsqueeze(0)
            )

        self.belief_history.append(result.belief.copy())
        self.result_history.append(result)
        self.labels.append(label or f"obs_{len(self.labels)}")

        return result

    def reset(self) -> None:
        """Clear all history and reset belief to prior (zeros)."""
        self._b_prev = None
        self.belief_history.clear()
        self.result_history.clear()
        self.labels.clear()

    def param_evolution(self) -> dict[str, np.ndarray]:
        """
        Parameter values across all observations in this session.

        Returns
        -------
        dict mapping parameter name → np.ndarray of values, one per observation.

        Example
        -------
        >>> evol = session.param_evolution()
        >>> # Hubble tension: h shifts between Planck (0.674) and DESI (0.680)
        >>> print(evol["h"])
        """
        return {
            name: np.array([r.params[i] for r in self.result_history])
            for i, name in enumerate(self.PARAM_NAMES)
        }

    def uncertainty_evolution(self) -> dict[str, np.ndarray]:
        """
        1-sigma uncertainties across all observations. Should narrow as
        evidence accumulates.
        """
        return {
            name: np.array([r.uncertainties[i] for r in self.result_history])
            for i, name in enumerate(self.PARAM_NAMES)
        }

    def energy_evolution(self) -> np.ndarray:
        """Final settled energy for each observation."""
        return np.array([r.energy_log[-1] for r in self.result_history])

    def __len__(self) -> int:
        return len(self.result_history)

    def __repr__(self) -> str:
        return f"CosmUFRSession(n_observations={len(self)}, labels={self.labels})"
