"""
CosmUFR — Cosmological Parameter Inference via Unified Field Representations
============================================================================
125M-parameter belief-settling neural emulator.
Recovers 8 cosmological parameters from matter power spectrum P(k).

Quick start
-----------
>>> import cosmufr
>>> model = cosmufr.load("path/to/best.pt")
>>> result = model.predict(pk_z0, pk_z047)
>>> print(result.params)   # [Om, s8, h, ns, Ob, w0, mv, wa]
>>> print(result.e_con)    # constraint energy — anomaly indicator

Sequential update (Hubble tension demo)
---------------------------------------
>>> session = cosmufr.CosmUFRSession(model)
>>> r1 = session.add_observation(*cosmufr.data.load_planck2018(), label="Planck 2018")
>>> r2 = session.add_observation(*cosmufr.data.load_desi_dr2(),   label="DESI DR2")
>>> evol = session.param_evolution()   # param shift across observations

Model comparison
----------------
>>> from cosmufr import compare
>>> result = compare(model, pk_z0_lcdm, pk_z047_lcdm, pk_z0_wcdm, pk_z047_wcdm)
>>> print(result.preferred_model, result.sigma_significance)

Visualisation
-------------
>>> from cosmufr.viz import render_cosmic_web
>>> field = render_cosmic_web(result.pk_reconstructed, model.k_grid)  # [512, 512]
"""

from cosmufr.inference import CosmUFRResult, CosmUFR, load
from cosmufr.session import CosmUFRSession
from cosmufr.compare import compare, CompareResult
from cosmufr import data
from cosmufr.viz import render_cosmic_web

__version__ = "0.7.1"
__author__ = "Aaditya Rajgor"

PARAM_NAMES = ["Omega_m", "sigma_8", "h", "n_s", "Omega_b", "w0", "mnu", "wa"]

__all__ = [
    "load",
    "CosmUFR",
    "CosmUFRResult",
    "CosmUFRSession",
    "compare",
    "CompareResult",
    "render_cosmic_web",
    "data",
    "PARAM_NAMES",
    "__version__",
]
