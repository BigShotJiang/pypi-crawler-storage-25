from cosmufr.utils.interpolation import interpolate_to_model_grid

__all__ = ["interpolate_to_model_grid"]
