"""
cosmufr/compare.py — Model comparison engine
=============================================
compare() takes two P(k) inputs and returns which cosmological model
the settled belief assigns lower constraint energy to.

This is the mechanism behind the Stage 5 demo:
  compare(model, lcdm_pk_z0, lcdm_pk_z047, desi_pk_z0, desi_pk_z047)
  → preferred_model = "B", sigma_significance = 2.3σ

Requires E_con calibration baseline in the checkpoint for sigma_significance.
Run scripts/calibrate_econ.py after training to enable this.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from cosmufr.inference import CosmUFR


@dataclass
class CompareResult:
    """
    Output from compare().

    Fields
    ------
    delta_E : float
        E_con(model_b) - E_con(model_a).
        Positive means model A has lower energy → better supported by the belief.
        Negative means model B is preferred.

    delta_params : np.ndarray, shape [8]
        Parameter differences: params_b - params_a.
        Shows what changes when the model settles on each input.

    sigma_significance : float or None
        |delta_E| / sigma_E from the calibration baseline.
        None if econ_baseline is not in the checkpoint.
        Rule of thumb: < 1σ = inconclusive, > 2σ = meaningful preference.

    preferred_model : str
        "A" or "B" — whichever has lower E_con.

    energy_a : float
        Raw E_con for model A input.

    energy_b : float
        Raw E_con for model B input.

    result_a : CosmUFRResult
        Full inference result for input A.

    result_b : CosmUFRResult
        Full inference result for input B.
    """
    delta_E:             float
    delta_params:        np.ndarray
    sigma_significance:  float | None
    preferred_model:     str
    energy_a:            float
    energy_b:            float
    result_a:            object   # CosmUFRResult, typed as object to avoid circular import
    result_b:            object

    def summary(self) -> str:
        sig_str = (f"{self.sigma_significance:.2f}σ"
                   if self.sigma_significance is not None else "uncalibrated")
        pref = f"Model {self.preferred_model}"
        return (
            f"Comparison: {pref} preferred at {sig_str}\n"
            f"  E_con(A) = {self.energy_a:.4f}\n"
            f"  E_con(B) = {self.energy_b:.4f}\n"
            f"  ΔE       = {self.delta_E:+.4f}"
        )


def compare(
    model:     "CosmUFR",
    pk_z0_a:   np.ndarray,
    pk_z047_a: np.ndarray,
    pk_z0_b:   np.ndarray,
    pk_z047_b: np.ndarray,
) -> CompareResult:
    """
    Compare two cosmological models by settling beliefs on each and
    comparing constraint energies.

    Lower E_con = the model's belief is more strongly supported by the
    AttractorBank prototypes = more typical/plausible cosmology given training.

    Parameters
    ----------
    model : CosmUFR
        Loaded model with (ideally) calibrated econ_baseline.
    pk_z0_a, pk_z047_a : np.ndarray, shape [200]
        log10 P(k) at z=0 and z≈0.47 for model A (e.g. LCDM).
    pk_z0_b, pk_z047_b : np.ndarray, shape [200]
        log10 P(k) for model B (e.g. w0waCDM with DESI parameters).

    Returns
    -------
    CompareResult

    Notes
    -----
    Both beliefs start from the prior (b_prev=None). This is an independent
    comparison, not a sequential update. For sequential comparison (updating
    belief on A then updating on B), use CosmUFRSession.

    The sigma_significance is meaningful only if:
    1. model.econ_baseline is populated (run scripts/calibrate_econ.py)
    2. R²(w0) > 0.70 (only achievable from Run 3 with w0/wa upsampling)
    Until then, treat the comparison as directional but not quantitatively reliable.

    Example
    -------
    >>> result = compare(model, lcdm_pk_z0, lcdm_pk_z047, wcdm_pk_z0, wcdm_pk_z047)
    >>> print(result.summary())
    """
    result_a = model.predict(pk_z0_a, pk_z047_a)
    result_b = model.predict(pk_z0_b, pk_z047_b)

    delta_E = result_b.e_con - result_a.e_con

    sigma_significance = None
    if model.econ_baseline is not None:
        std = model.econ_baseline.get("std", 0.0)
        if std > 0:
            sigma_significance = abs(delta_E) / std

    preferred_model = "A" if delta_E > 0 else "B"

    return CompareResult(
        delta_E=delta_E,
        delta_params=result_b.params - result_a.params,
        sigma_significance=sigma_significance,
        preferred_model=preferred_model,
        energy_a=result_a.e_con,
        energy_b=result_b.e_con,
        result_a=result_a,
        result_b=result_b,
    )
