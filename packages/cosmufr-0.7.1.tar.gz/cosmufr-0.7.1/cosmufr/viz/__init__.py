from cosmufr.viz.cosmic_web import render_cosmic_web

__all__ = ["render_cosmic_web"]
