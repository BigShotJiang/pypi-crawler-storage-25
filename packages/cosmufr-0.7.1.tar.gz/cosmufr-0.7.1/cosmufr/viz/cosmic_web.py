"""
cosmufr/viz/cosmic_web.py — Lognormal cosmic web renderer
==========================================================
Generates a 2D density field from a matter power spectrum P(k).
Uses the lognormal approximation: compute a Gaussian random field in
Fourier space with amplitude sqrt(P(k)), then apply lognormal transform.

N=512 and smoothing_sigma=1.5 produce visually coherent filaments at
demo display scale. High-sigma_8 cosmologies show denser filaments than
low-sigma_8 — this difference should be visible in the rendered field.

No GPU required. Pure numpy + scipy.
"""
from __future__ import annotations

import numpy as np
from scipy.ndimage import gaussian_filter


def render_cosmic_web(
    pk:              np.ndarray,
    k_grid:          np.ndarray,
    N:               int   = 512,
    smoothing_sigma: float = 1.5,
    seed:            int   = 42,
    box_size:        float = 300.0,  # Mpc/h
) -> np.ndarray:
    """
    Generate a 2D lognormal density field from a power spectrum.

    Parameters
    ----------
    pk : np.ndarray, shape [n_k]
        Power spectrum values. If in log10 space (as returned by CosmUFR),
        will be automatically detected and converted.
    k_grid : np.ndarray, shape [n_k]
        Wavenumber grid in h/Mpc corresponding to pk.
        Must be in linear (not log) space.
    N : int
        Grid resolution. 512 recommended for demo quality.
        Do not go below 256 — filaments become unrecognisable.
    smoothing_sigma : float
        Gaussian smoothing applied after lognormal transform.
        1.5 produces clean filaments without over-smoothing.
    seed : int
        Random seed. Fixed seed ensures reproducible fields for the same P(k).
        Different seeds produce different realisations of the same cosmology.
    box_size : float
        Simulation box size in Mpc/h. Controls physical scale of the field.
        300 Mpc/h is typical for LSS visualisation.

    Returns
    -------
    np.ndarray, shape [N, N], dtype float64
        Density field normalised to [0, 1].
        Higher values = denser regions (filaments, clusters).
        Lower values = voids.

    Notes
    -----
    This uses a 2D slice of a 3D lognormal field — suitable for demo
    visualisation but not for rigorous statistical comparisons.
    The lognormal approximation is accurate to ~10% on large scales
    for LCDM-like cosmologies.

    Example
    -------
    >>> field = render_cosmic_web(result.pk_reconstructed, model.k_grid)
    >>> import matplotlib.pyplot as plt
    >>> plt.imshow(field, cmap='inferno', origin='lower')
    """
    rng = np.random.default_rng(seed)

    # Auto-detect log10 space (values typically -2 to 5 for P(k) in log10)
    if pk.min() < 0 and pk.max() < 10:
        pk_linear = 10.0 ** pk
    else:
        pk_linear = pk.copy()

    # --- 1. Build 2D Fourier k-grid ---
    # Pixel scale: box_size / N in Mpc/h
    # Fourier frequencies: 2π / box_size * [0, 1, ..., N/2, -N/2+1, ..., -1]
    dk = 2.0 * np.pi / box_size
    kx = np.fft.fftfreq(N, d=1.0 / N) * dk   # [N]
    ky = np.fft.fftfreq(N, d=1.0 / N) * dk   # [N]
    kx2d, ky2d = np.meshgrid(kx, ky, indexing="ij")
    kmag = np.sqrt(kx2d**2 + ky2d**2)         # [N, N]

    # Avoid k=0 singularity
    kmag[0, 0] = k_grid[1] if len(k_grid) > 1 else 0.1

    # --- 2. Interpolate P(k) onto 2D k-grid ---
    # Use log-log interpolation for accuracy across many decades in k
    log_k_obs   = np.log(k_grid)
    log_pk_obs  = np.log(np.maximum(pk_linear, 1e-30))
    log_k_2d    = np.log(np.maximum(kmag, 1e-10)).ravel()

    log_pk_2d = np.interp(
        log_k_2d,
        log_k_obs,
        log_pk_obs,
        left=log_pk_obs[0],
        right=log_pk_obs[-1],
    )
    pk_2d = np.exp(log_pk_2d).reshape(N, N)   # [N, N]

    # --- 3. Gaussian random field in Fourier space ---
    # White noise with amplitude sqrt(P(k) / 2) per real/imag component
    amplitude = np.sqrt(pk_2d / 2.0)
    noise_real = rng.standard_normal((N, N))
    noise_imag = rng.standard_normal((N, N))
    delta_k    = amplitude * (noise_real + 1j * noise_imag)

    # --- 4. Transform to real space ---
    delta_x = np.real(np.fft.ifft2(delta_k))

    # --- 5. Lognormal transform ---
    # delta_ln = exp(delta_gauss - sigma^2/2) enforces positivity
    var     = float(np.var(delta_x))
    field   = np.exp(delta_x - var / 2.0)

    # --- 6. Smooth and normalise ---
    field = gaussian_filter(field, sigma=smoothing_sigma)
    fmin, fmax = field.min(), field.max()
    if fmax > fmin:
        field = (field - fmin) / (fmax - fmin)
    else:
        field = np.zeros_like(field)

    return field.astype(np.float64)
