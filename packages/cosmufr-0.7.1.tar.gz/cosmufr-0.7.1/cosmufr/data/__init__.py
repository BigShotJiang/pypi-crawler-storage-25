"""
cosmufr.data — Real telescope data loaders
==========================================
Each loader returns (pk_z0, pk_z047): two np.ndarray of shape [200],
already interpolated to the model k-grid in log10 space.

Available loaders
-----------------
load_desi_dr2()     — DESI DR2 matter power spectrum (FITS)
load_planck2018()   — Planck 2018 CMB-derived P(k) (HDF5)
load_euclid_q1()    — Euclid Q1 weak lensing P(k) (HDF5)

All loaders cache downloaded files to ~/.cache/cosmufr/ on first call.
"""
from cosmufr.data.loaders import (
    load_desi_dr2,
    load_planck2018,
    load_euclid_q1,
)

__all__ = [
    "load_desi_dr2",
    "load_planck2018",
    "load_euclid_q1",
]
