"""
cosmufr/data/loaders.py — Real telescope P(k) loaders
======================================================
Sprint 2 implementation. Each function:
  1. Downloads the data file if not cached
  2. Parses the format-specific file (FITS / HDF5 / ASCII)
  3. Interpolates to the model k-grid via interpolate_to_model_grid()
  4. Returns (pk_z0, pk_z047) in log10 space, shape [200] each

Status
------
- load_desi_dr2()   : [Sprint 2] stub — implementation in progress
- load_planck2018() : [Sprint 2] stub — implementation in progress
- load_euclid_q1()  : [Sprint 2] stub — implementation in progress
"""
from __future__ import annotations

import hashlib
import os
import urllib.request
import warnings
from pathlib import Path
from typing import tuple as Tuple

import numpy as np

from cosmufr.utils.interpolation import interpolate_to_model_grid

CACHE_DIR = Path.home() / ".cache" / "cosmufr"


def _get_cached(url: str, filename: str) -> Path:
    """Download url to CACHE_DIR/filename if not already present."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    dest = CACHE_DIR / filename
    if not dest.exists():
        print(f"[cosmufr] Downloading {filename} ...")
        urllib.request.urlretrieve(url, dest)
        print(f"[cosmufr] Saved to {dest}")
    return dest


def load_desi_dr2() -> tuple[np.ndarray, np.ndarray]:
    """
    Load DESI DR2 matter power spectrum.

    Returns
    -------
    pk_z0 : np.ndarray, shape [200]
        log10 P(k) at z=0 on model k-grid.
    pk_z047 : np.ndarray, shape [200]
        log10 P(k) at z≈0.47 on model k-grid.

    Notes
    -----
    DESI DR2 data is available at https://data.desi.lbl.gov/public/dr2/
    File format: FITS with HDU[1] containing columns K, PK, PK_ERR.
    Requires astropy: pip install astropy

    This function is a placeholder. Implementation requires:
    1. Confirming the exact DESI DR2 power spectrum file URL
    2. Parsing FITS HDU structure
    3. Separating z=0 and z≈0.47 redshift slices
    4. Unit conversion if DESI uses different k-units

    Current status: Sprint 2 — returns LCDM-like synthetic P(k) as placeholder.
    """
    warnings.warn(
        "load_desi_dr2() is not yet implemented. "
        "Returning synthetic LCDM-like P(k) as placeholder. "
        "Sprint 2 will implement the real DESI DR2 loader.",
        UserWarning,
        stacklevel=2,
    )
    return _synthetic_lcdm_pk()


def load_planck2018() -> tuple[np.ndarray, np.ndarray]:
    """
    Load Planck 2018 CMB-derived matter power spectrum.

    Returns
    -------
    pk_z0 : np.ndarray, shape [200]
        log10 P(k) at z=0 on model k-grid.
    pk_z047 : np.ndarray, shape [200]
        log10 P(k) at z≈0.47 on model k-grid.

    Notes
    -----
    Planck 2018 provides CMB angular power spectra C_l, not P(k) directly.
    Conversion requires matter transfer function (via CAMB or EH fitting formulae).
    File: https://pla.esac.esa.int/pla/aio/product-action?COSMOLOGY.FILE_ID=COM_PowerSpect_CMB_R3.01.tar.gz

    Current status: Sprint 2 — returns synthetic Planck-best-fit P(k) as placeholder.
    """
    warnings.warn(
        "load_planck2018() is not yet implemented. "
        "Returning synthetic Planck-best-fit P(k) as placeholder. "
        "Sprint 2 will implement the real Planck 2018 loader.",
        UserWarning,
        stacklevel=2,
    )
    return _synthetic_planck_pk()


def load_euclid_q1() -> tuple[np.ndarray, np.ndarray]:
    """
    Load Euclid Q1 weak lensing power spectrum.

    Returns
    -------
    pk_z0 : np.ndarray, shape [200]
        log10 P(k) at z=0 on model k-grid.
    pk_z047 : np.ndarray, shape [200]
        log10 P(k) at z≈0.47 on model k-grid.

    Notes
    -----
    Euclid Q1 data is in HDF5 format. Requires h5py: pip install h5py
    Public release: https://euclid-ec.org/public/q1/

    Current status: Sprint 2 — returns synthetic P(k) as placeholder.
    """
    warnings.warn(
        "load_euclid_q1() is not yet implemented. "
        "Returning synthetic P(k) as placeholder. "
        "Sprint 2 will implement the real Euclid Q1 loader.",
        UserWarning,
        stacklevel=2,
    )
    return _synthetic_lcdm_pk()


# ─────────────────────────────────────────────────────────────────────────────
# Synthetic placeholders (removed in Sprint 2)
# ─────────────────────────────────────────────────────────────────────────────

def _synthetic_lcdm_pk() -> tuple[np.ndarray, np.ndarray]:
    """Approximate LCDM P(k) using Eisenstein-Hu fitting formula."""
    from cosmufr.utils.interpolation import get_model_k_grid
    k = get_model_k_grid()

    # Simple broken power-law approximation to LCDM
    # Not accurate — replace with real data in Sprint 2
    Om = 0.3; h = 0.67; ns = 0.966; s8 = 0.81
    k_eq = 0.073 * Om * h**2  # equality scale
    T_k = np.log(1 + 2.34 * k / k_eq) / (2.34 * k / k_eq)
    T_k *= (1 + (3.89 * k / k_eq) + (16.1 * k / k_eq)**2
            + (5.46 * k / k_eq)**3 + (6.71 * k / k_eq)**4)**(-0.25)
    pk = k**ns * T_k**2 * 5e4  # rough normalisation

    pk_z0   = np.log10(pk)
    pk_z047 = np.log10(pk * (1 - 0.05 * np.log(k / 0.1)))  # rough growth factor

    return pk_z0.astype(np.float32), pk_z047.astype(np.float32)


def _synthetic_planck_pk() -> tuple[np.ndarray, np.ndarray]:
    """Planck 2018 best-fit cosmology synthetic P(k)."""
    # Planck: Om=0.315, h=0.674, ns=0.965, s8=0.811
    # Same functional form, slightly different parameters
    from cosmufr.utils.interpolation import get_model_k_grid
    k = get_model_k_grid()
    Om = 0.315; h = 0.674; ns = 0.965
    k_eq = 0.073 * Om * h**2
    T_k = np.log(1 + 2.34 * k / k_eq) / (2.34 * k / k_eq)
    T_k *= (1 + (3.89 * k / k_eq) + (16.1 * k / k_eq)**2
            + (5.46 * k / k_eq)**3 + (6.71 * k / k_eq)**4)**(-0.25)
    pk = k**ns * T_k**2 * 5e4

    pk_z0   = np.log10(pk)
    pk_z047 = np.log10(pk * (1 - 0.05 * np.log(k / 0.1)))

    return pk_z0.astype(np.float32), pk_z047.astype(np.float32)
