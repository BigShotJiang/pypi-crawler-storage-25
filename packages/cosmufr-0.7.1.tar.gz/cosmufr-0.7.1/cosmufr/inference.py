"""
cosmufr/inference.py — CosmUFRResult dataclass and CosmUFR inference wrapper
=============================================================================
CosmUFRResult     : structured output from a single predict() call
CosmUFR           : loads checkpoint, exposes predict() and k_grid
load()            : convenience factory — cosmufr.load(path)
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np

# Lazy torch import — allows importing cosmufr on CPU-only machines for
# dataclass/utility use without requiring a GPU or torch installation.
try:
    import torch
    _TORCH_AVAILABLE = True
except ImportError:
    _TORCH_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# Output container
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CosmUFRResult:
    """
    Structured output from CosmUFR.predict().

    Fields
    ------
    params : np.ndarray, shape [8]
        Recovered cosmological parameters in order:
        [Omega_m, sigma_8, h, n_s, Omega_b, w0, mnu, wa]
        Normalised to physical units. Fiducial LCDM: Om=0.3, s8=0.8, h=0.67,
        ns=0.96, Ob=0.049, w0=-1.0, mnu=0.0, wa=0.0.

    uncertainties : np.ndarray, shape [8]
        1-sigma uncertainties on each parameter from the UncertaintyHead.
        These are calibrated in Run 2. In Run 1 they are indicative only.

    pk_reconstructed : np.ndarray, shape [200]
        Reconstructed log10 P(k) at z=0 on the model k-grid [0.1, 4.5] h/Mpc,
        200 bins. From the k-continuous GenerativeHead.

    belief : np.ndarray, shape [1024]
        Settled belief vector b_star. Thread this to the next predict() call
        via b_prev for sequential update. Or use CosmUFRSession which handles
        this automatically.

    energy_log : list[float], length 17
        Energy E_t at each of the 16 settling steps, plus the final value.
        Monotonically decreasing in a well-converged case. Plot this to show
        belief settling live in the demo.

    e_con : float
        Constraint energy E_con(b_star) — measures how well the settled belief
        is supported by the AttractorBank prototypes. Lower = more typical
        cosmology. High values flag anomalous or out-of-distribution inputs.
        Reported as z-score (sigma) if calibration baseline is available in
        the checkpoint. Raw value otherwise.

    e_con_zscore : float or None
        e_con expressed in sigma units relative to the validation set baseline.
        None if the checkpoint was not calibrated (run scripts/calibrate_econ.py).
        Demo anomaly card shows red if e_con_zscore > 2.0.

    nmass : np.ndarray, shape [20]
        Predicted log10 halo mass function n(M) in 20 mass bins,
        M in [10^11, 10^15] M_sun/h. From HaloMassHead.
    """
    params:           np.ndarray              # [8]
    uncertainties:    np.ndarray              # [8]
    pk_reconstructed: np.ndarray              # [200]
    belief:           np.ndarray              # [1024]
    energy_log:       list                    # length 17
    e_con:            float                   # raw constraint energy
    nmass:            np.ndarray              # [20]
    e_con_zscore:     Optional[float] = None  # sigma units, None if uncalibrated

    def summary(self) -> str:
        """Human-readable parameter summary."""
        names = ["Omega_m", "sigma_8", "h", "n_s", "Omega_b", "w0", "mnu", "wa"]
        lines = ["CosmUFR Parameter Recovery:"]
        lines.append("-" * 40)
        for name, val, unc in zip(names, self.params, self.uncertainties):
            lines.append(f"  {name:10s} = {val:+.4f}  ± {unc:.4f}")
        lines.append("-" * 40)
        e_str = (f"{self.e_con_zscore:+.2f}σ" if self.e_con_zscore is not None
                 else f"{self.e_con:.4f} (uncalibrated)")
        lines.append(f"  E_con      = {e_str}")
        lines.append(f"  Settling   = {len(self.energy_log)} steps, "
                     f"ΔE = {self.energy_log[0] - self.energy_log[-1]:.4f}")
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Inference wrapper
# ─────────────────────────────────────────────────────────────────────────────

class CosmUFR:
    """
    Inference wrapper around CosmUFRLite.

    Load via cosmufr.load(path) rather than constructing directly.

    Parameters
    ----------
    checkpoint_path : str or Path
        Path to a .pt checkpoint produced by model/train_vertex.py.
        Must contain 'model_state_dict' and 'cfg' keys.
    device : str, optional
        'cuda', 'cpu', or 'auto' (default). Auto selects CUDA if available.
    """

    def __init__(self, checkpoint_path: str | Path, device: str = "auto"):
        if not _TORCH_AVAILABLE:
            raise ImportError(
                "torch is required to load a CosmUFR model. "
                "Install with: pip install torch"
            )

        self._ckpt_path = Path(checkpoint_path)
        if not self._ckpt_path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {self._ckpt_path}")

        if device == "auto":
            self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self._device = torch.device(device)

        self._load_checkpoint()

    def _load_checkpoint(self) -> None:
        """Load model weights, config, and optional calibration baseline."""
        import sys
        import os
        # Allow importing model.* from the package root
        pkg_root = Path(__file__).parent.parent
        if str(pkg_root) not in sys.path:
            sys.path.insert(0, str(pkg_root))

        from model.cosmufr_arch import CosmUFRLite
        from model.cosmufr_config import CosmUFRConfig

        ckpt = torch.load(self._ckpt_path, map_location=self._device, weights_only=False)

        cfg = ckpt.get("cfg", CosmUFRConfig())
        self._cfg = cfg

        self._model = CosmUFRLite(cfg)
        state = ckpt.get("model_state_dict", ckpt)
        self._model.load_state_dict(state, strict=False)
        self._model.to(self._device)
        self._model.eval()

        # k-grid for queries (log-space, 200 bins)
        k = np.linspace(np.log(cfg.k_min), np.log(cfg.k_max), cfg.n_k_modes)
        self.k_grid = np.exp(k)  # [200] in h/Mpc

        # E_con calibration baseline (populated by scripts/calibrate_econ.py)
        self.econ_baseline: Optional[dict] = ckpt.get("econ_baseline", None)

    def predict(
        self,
        pk_z0:   np.ndarray,
        pk_z047: np.ndarray,
        b_prev:  Optional["torch.Tensor"] = None,
    ) -> CosmUFRResult:
        """
        Run inference on a single P(k) observation.

        Parameters
        ----------
        pk_z0 : np.ndarray, shape [200]
            log10 P(k) at redshift z=0 on the model k-grid.
            Interpolate observed P(k) via cosmufr.utils.interpolate_to_model_grid().
        pk_z047 : np.ndarray, shape [200]
            log10 P(k) at redshift z≈0.47 on the model k-grid.
        b_prev : torch.Tensor, shape [1, 1024], optional
            Prior belief from a previous predict() call. None = uniform prior (zeros).
            Use CosmUFRSession to manage this automatically.

        Returns
        -------
        CosmUFRResult
            Settled belief, 8 cosmological params + uncertainties,
            reconstructed P(k), energy trace, constraint energy, halo mass fn.
        """
        if not _TORCH_AVAILABLE:
            raise ImportError("torch required for predict()")

        # Stack z0 + z047 into 400-dim observation
        obs_np = np.concatenate([pk_z0, pk_z047], axis=-1).astype(np.float32)
        obs_t  = torch.tensor(obs_np, device=self._device).unsqueeze(0)  # [1, 400]

        with torch.no_grad():
            out = self._model(obs_t, b_prev=b_prev, return_full=True)

        # Extract params (denormalise from [0,1] to physical units)
        params_raw = out["params"][0].cpu().numpy()   # [8], normalised
        params     = self._denormalise_params(params_raw)

        # Uncertainties (sqrt of variances, in normalised space → scale to physical)
        variances  = out["variances"][0].cpu().numpy()  # [8]
        unc_norm   = np.sqrt(np.maximum(variances, 0.0))
        unc        = self._denormalise_uncertainties(unc_norm)

        # Reconstructed P(k) — take mean from generative head
        pk_mean    = out["pk_mean"][0].cpu().numpy()    # [200]

        # Belief vector
        belief     = out["b_star"][0].cpu().numpy()     # [1024]

        # Energy trace across settling steps
        energy_log = [float(e) for e in out["energy_log"]]

        # Constraint energy (L_proto from AttractorBank)
        e_con_raw  = float(out["L_proto"])

        # z-score if baseline is calibrated
        e_con_zscore = None
        if self.econ_baseline is not None:
            mu  = self.econ_baseline["mean"]
            std = self.econ_baseline["std"]
            if std > 0:
                e_con_zscore = (e_con_raw - mu) / std

        # Halo mass function
        nmass = out["nmass"][0].cpu().numpy()           # [20]

        return CosmUFRResult(
            params=params,
            uncertainties=unc,
            pk_reconstructed=pk_mean,
            belief=belief,
            energy_log=energy_log,
            e_con=e_con_raw,
            nmass=nmass,
            e_con_zscore=e_con_zscore,
        )

    def _denormalise_params(self, p: np.ndarray) -> np.ndarray:
        """Map normalised [0,1] params back to physical units."""
        cfg = self._cfg
        ranges = [
            (cfg.om_min, cfg.om_max),
            (cfg.s8_min, cfg.s8_max),
            (cfg.h_min,  cfg.h_max),
            (cfg.ns_min, cfg.ns_max),
            (cfg.ob_min, cfg.ob_max),
            (cfg.w0_min, cfg.w0_max),
            (cfg.mv_min, cfg.mv_max),
            (cfg.wa_min, cfg.wa_max),
        ]
        out = np.empty(8, dtype=np.float32)
        for i, (lo, hi) in enumerate(ranges):
            out[i] = p[i] * (hi - lo) + lo
        return out

    def _denormalise_uncertainties(self, u: np.ndarray) -> np.ndarray:
        """Scale normalised uncertainties to physical units."""
        cfg = self._cfg
        ranges = [
            (cfg.om_min, cfg.om_max),
            (cfg.s8_min, cfg.s8_max),
            (cfg.h_min,  cfg.h_max),
            (cfg.ns_min, cfg.ns_max),
            (cfg.ob_min, cfg.ob_max),
            (cfg.w0_min, cfg.w0_max),
            (cfg.mv_min, cfg.mv_max),
            (cfg.wa_min, cfg.wa_max),
        ]
        out = np.empty(8, dtype=np.float32)
        for i, (lo, hi) in enumerate(ranges):
            out[i] = u[i] * (hi - lo)
        return out

    def __repr__(self) -> str:
        cal = "calibrated" if self.econ_baseline else "uncalibrated"
        return (f"CosmUFR(checkpoint='{self._ckpt_path.name}', "
                f"device={self._device}, econ={cal})")


# ─────────────────────────────────────────────────────────────────────────────
# Convenience factory
# ─────────────────────────────────────────────────────────────────────────────

def load(checkpoint_path: str | Path, device: str = "auto") -> CosmUFR:
    """
    Load a CosmUFR model from a checkpoint file.

    Parameters
    ----------
    checkpoint_path : str or Path
        Path to .pt checkpoint (local file).
    device : str
        'cuda', 'cpu', or 'auto' (default — selects CUDA if available).

    Returns
    -------
    CosmUFR
        Ready for inference. Call .predict(pk_z0, pk_z047) to get results.

    Example
    -------
    >>> model = cosmufr.load("checkpoints/best.pt")
    >>> result = model.predict(pk_z0, pk_z047)
    """
    return CosmUFR(checkpoint_path, device=device)
