"""
setup.py — CosmUFR PyPI package
================================
Packages:
  cosmufr/   — user-facing inference API (CosmUFRResult, CosmUFR, session, compare, viz, data)
  model/     — model architecture (bundled so inference works without separate install)

Vertex AI training uses this same setup.py to install the package in the
training container, where model/ is the primary import path.
"""
from setuptools import setup, find_packages

setup(
    name="cosmufr",
    version="0.7.1",
    description=(
        "CosmUFR: Cosmological Parameter Inference via Unified Field Representations. "
        "125M-parameter belief-settling neural emulator. Recovers 8 cosmological "
        "parameters from matter power spectrum P(k)."
    ),
    long_description=open("dist/hf_README.md", encoding="utf-8", errors="ignore").read() if __import__("os").path.exists("dist/hf_README.md") else "",
    long_description_content_type="text/markdown",
    author="Aaditya Rajgor",
    author_email="arajgor1@gmail.com",
    url="https://github.com/arajgor1/calybre-ufr",
    license="MIT",
    python_requires=">=3.9",
    packages=find_packages(include=["cosmufr", "cosmufr.*", "model", "model.*"]),
    install_requires=[
        "numpy>=1.24.0",
        "scipy>=1.10.0",
        "torch>=2.0.0",
        "astropy>=5.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "twine>=4.0",
            "build>=0.10",
        ],
        "viz": [
            "matplotlib>=3.7",
        ],
        "demo": [
            "gradio>=4.0",
            "matplotlib>=3.7",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Astronomy",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords=[
        "cosmology", "machine learning", "power spectrum", "neural network",
        "parameter inference", "MCMC", "emulator", "DESI", "Euclid", "Planck",
    ],
    project_urls={
        "GitHub": "https://github.com/arajgor1/calybre-ufr",
        "HuggingFace": "https://huggingface.co/arajgor1/cosmufr-v07",
    },
)
