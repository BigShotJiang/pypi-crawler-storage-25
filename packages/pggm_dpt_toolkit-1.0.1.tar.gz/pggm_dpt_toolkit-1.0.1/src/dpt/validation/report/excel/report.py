import pandas as pd
from typing import List

from validation.report.compare import compare_keys, compare_columns, compare_values
from validation.report.excel.util import (
    create_worksheet,
    apply_column_compare_formatting,
    apply_key_compare_formatting,
    apply_value_compare_summary_formatting,
    apply_value_compare_formatting
)


def generate_excel_report(df_old, df_new, key_columns:List[str], file_name:str, tolerance=1):
    df_keys = compare_keys(df_old, df_new, key_columns=key_columns)
    df_cols = compare_columns(df_old, df_new)
    df_vals, df_vals_summary = compare_values(df_old, df_new, keys=key_columns)

    with pd.ExcelWriter(file_name, engine='openpyxl') as writer:
        columns_sheet = create_worksheet(writer, df_cols, sheet_name="Column Comparison")
        keys_sheet = create_worksheet(writer, df_keys, sheet_name="Key Comparison")
        values_summary_sheet = create_worksheet(writer, df_vals_summary, sheet_name="Value Comparison Summary")
        values_sheet = create_worksheet(writer, df_vals, sheet_name="Value Comparison")

        columns_sheet.freeze_panes = 'B2'
        keys_sheet.freeze_panes = 'B2'
        values_summary_sheet.freeze_panes = 'B2'

        alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        col = alphabet[len(key_columns)]  # Assuming key columns are at the beginning
        values_sheet.freeze_panes = f'{col}2'

        apply_column_compare_formatting(columns_sheet, df_cols)
        apply_key_compare_formatting(keys_sheet, df_keys)
        apply_value_compare_summary_formatting(values_summary_sheet, df_vals_summary)
        apply_value_compare_formatting(values_sheet, df_vals, tolerance=tolerance)
