import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font
from openpyxl.formatting.rule import CellIsRule
from openpyxl.utils import get_column_letter
from typing import Dict, List


# Define fill styles
red_fill = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")
green_fill = PatternFill(start_color="CCFFCC", end_color="CCFFCC", fill_type="solid")
yellow_fill = PatternFill(start_color="FFFFCC", end_color="FFFFCC", fill_type="solid")


def auto_size_column_widths(worksheet):
    for column in worksheet.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = int(len(str(cell.value))*1.2)
            except:
                pass
        # adjusted_width = min(max_length + 2, 50)
        adjusted_width = max_length + 6
        worksheet.column_dimensions[column_letter].width = adjusted_width


def apply_top_row_filters(worksheet, df):
    max_col = len(df.columns)   # max column index
    max_row = len(df) + 1       # max row index

    # Add auto-filter to all columns
    worksheet.auto_filter.ref = f"A1:{get_column_letter(max_col)}{max_row}"


def apply_column_compare_formatting(worksheet, df):
    apply_top_row_filters(worksheet, df)
    auto_size_column_widths(worksheet)
    for col_idx, column in enumerate(df.columns, 1):
        if column == 'status':
            col_letter = worksheet.cell(row=1, column=col_idx).column_letter

            # Red for missing keys
            red_rule = CellIsRule(
                operator='equal',
                formula=['"missing"'],
                fill=red_fill
            )

            # Green for keys in both tables
            green_rule = CellIsRule(
                operator='equal',
                formula=['"shared"'],
                fill=green_fill
            )

            # Orange for keys added
            orange_rule = CellIsRule(
                operator='equal',
                formula=['"added"'],
                fill=yellow_fill
            )

            # Apply rules to the column range
            range_string = f"{col_letter}2:{col_letter}{len(df)+1}"
            worksheet.conditional_formatting.add(range_string, red_rule)
            worksheet.conditional_formatting.add(range_string, green_rule)
            worksheet.conditional_formatting.add(range_string, orange_rule)


def apply_key_compare_formatting(worksheet, df):
    apply_top_row_filters(worksheet, df)
    auto_size_column_widths(worksheet)
    for col_idx, column in enumerate(df.columns, 1):
        if column == 'status':
            col_letter = worksheet.cell(row=1, column=col_idx).column_letter

            # Red for missing keys
            red_rule = CellIsRule(
                operator='equal',
                formula=['"missing"'],
                fill=red_fill
            )

            # Green for keys in both tables
            green_rule = CellIsRule(
                operator='equal',
                formula=['"shared"'],
                fill=green_fill
            )

            # Orange for keys added
            orange_rule = CellIsRule(
                operator='equal',
                formula=['"added"'],
                fill=yellow_fill
            )

            # Apply rules to the column range
            range_string = f"{col_letter}2:{col_letter}{len(df)+1}"
            worksheet.conditional_formatting.add(range_string, red_rule)
            worksheet.conditional_formatting.add(range_string, green_rule)
            worksheet.conditional_formatting.add(range_string, orange_rule)



def apply_value_compare_formatting(worksheet, df, tolerance=1):
    apply_top_row_filters(worksheet, df)
    auto_size_column_widths(worksheet)

    # Apply conditional formatting to DIFF columns
    for col_idx, column in enumerate(df.columns, 1):
        if column.endswith('_diff_percent'):
            col_letter = worksheet.cell(row=1, column=col_idx).column_letter

            # Red for differences > tolerance (changed values)
            red_rule = CellIsRule(
                operator='greaterThan',
                formula=[f'{tolerance}'],
                fill=red_fill
            )

            # Green for differences = 0 (unchanged values)
            green_rule = CellIsRule(
                operator='equal',
                formula=['0'],
                fill=green_fill
            )

            orange_rule = CellIsRule(
                operator='between',
                formula=['0', f'{tolerance}'],
                fill=yellow_fill
            )

            # Apply rules to the column range
            range_string = f"{col_letter}2:{col_letter}{len(df)+1}"
            worksheet.conditional_formatting.add(range_string, red_rule)
            worksheet.conditional_formatting.add(range_string, green_rule)
            worksheet.conditional_formatting.add(range_string, orange_rule)


def apply_value_compare_summary_formatting(worksheet, df):
    apply_top_row_filters(worksheet, df)
    auto_size_column_widths(worksheet)



def generate_excel_report(data: pd.DataFrame, filename: str, sheet_name: str = "Comparison", tolerance = 1) -> None:
    """
    Export dataframe to Excel with conditional formatting for difference columns
    """
    if type(data) == pd.DataFrame:
        df = data

        # Create Excel writer
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name=sheet_name, index=False)
            worksheet = writer.sheets[sheet_name]
            worksheet.freeze_panes = 'B2'
            apply_value_compare_formatting(worksheet, df, tolerance)

    if type(data) == dict:
        # Create Excel writer once for all sheets
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            for sheet_name, df in data.items():
                df.to_excel(writer, sheet_name=sheet_name, index=False)
                worksheet = writer.sheets[sheet_name]
                worksheet.freeze_panes = 'B2'
                apply_value_compare_formatting(worksheet, df, tolerance)



def create_worksheet(writer, df, sheet_name):
    df.to_excel(writer, sheet_name=sheet_name, index=False)
    worksheet = writer.sheets[sheet_name]
    return worksheet
