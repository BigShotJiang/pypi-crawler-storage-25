from duckdb import df
import pandas as pd


def compare_data_types(df_old: pd.DataFrame, df_new: pd.DataFrame, styled: bool = False) -> pd.DataFrame:
    cols_old = set(df_old.columns)
    cols_new = set(df_new.columns)
    shared_columns = [str(col) for col in list(cols_old.intersection(cols_new))]

    # Create comparison data for shared columns
    comparison_data = []
    for col in shared_columns:
        dtype_old = df_old[col].dtype
        dtype_new = df_new[col].dtype
        exact_match = dtype_old == dtype_new
        both_numeric = pd.api.types.is_numeric_dtype(dtype_old) and pd.api.types.is_numeric_dtype(dtype_new)
        both_datetime = pd.api.types.is_datetime64_any_dtype(dtype_old) and pd.api.types.is_datetime64_any_dtype(dtype_new)


        comparison_data.append({
            'column': col,
            'dtype_old': str(dtype_old),  # Convert to string only for display
            'dtype_new': str(dtype_new),  # Convert to string only for display
            'same_dtype': exact_match or both_numeric or both_datetime
        })

    df = pd.DataFrame(comparison_data).sort_values(by='column').reset_index(drop=True)


    if styled:
        style_map_dtype_status = {
            True: 'background-color: darkgreen; color: white',
            False: 'background-color: darkred; color: white',
        }
        df = df.style.map(lambda val: style_map_dtype_status[val], subset=['same_dtype'])

    return df


def compare_columns(df_old: pd.DataFrame, df_new: pd.DataFrame, styled=False) -> None:
    cols_old = set(df_old.columns)
    cols_new = set(df_new.columns)

    all_columns = [str(col) for col in list(cols_old.union(cols_new))]
    shared_columns = [str(col) for col in list(cols_old.intersection(cols_new))]
    missing_columns = [str(col) for col in list(cols_old - cols_new)]
    added_columns = [str(col) for col in list(cols_new - cols_old)]

    df = pd.DataFrame({'column': all_columns})
    df['status'] = df['column'].apply(lambda x: 'shared' if x in shared_columns else ('missing' if x in missing_columns else 'added'))
    df = df.sort_values(by=['status', 'column']).reset_index(drop=True)

    if styled:
        style_map_column_status = {
            "shared": 'background-color: darkgreen; color: white',
            "added": 'background-color: darkorange; color: white',
            "missing": 'background-color: darkred; color: white',
        }
        df = df.style.map(lambda val: style_map_column_status[val], subset=['status'])

    return df
