import pandas as pd


status_map = {
    'both': 'shared',
    'left_only': 'missing',
    'right_only': 'added'
}


def compare_keys(df_old: pd.DataFrame, df_new: pd.DataFrame, key_columns: str|list[str]) -> pd.DataFrame:
    if isinstance(key_columns, str):
        key_columns = [key_columns]

    # use .copy() to avoid modifying the original dataframes
    df_old = df_old.copy()
    df_new = df_new.copy()

    df_old['compare_key'] = df_old[key_columns].apply(lambda row: '_'.join(row.values.astype(str)), axis=1)
    df_new['compare_key'] = df_new[key_columns].apply(lambda row: '_'.join(row.values.astype(str)), axis=1)
    df = df_old.merge(df_new, on='compare_key', how='outer', indicator=True, suffixes=('_old', '_new'))

    for key in key_columns:
        df[key] = df[f'{key}_old'].combine_first(df[f'{key}_new'])

    df.rename(columns={'_merge': 'status'}, inplace=True)
    df['status'] = df['status'].map(status_map)
    output_columns = key_columns + ['status']
    df = df[output_columns]
    df.sort_values(by=['status'] + key_columns, inplace=True)
    return df
