import pandas as pd
from numpy import int16, int32, int64
from typing import List


status_map = {
    'both': 'shared',
    'left_only': 'missing',
    'right_only': 'added'
}




def compare_values(df_old: pd.DataFrame, df_new: pd.DataFrame, keys: str|List[str], compare_columns=None) -> pd.DataFrame:
    if isinstance(keys, str):
        keys = [keys]

    # use .copy() to avoid modifying the original dataframes
    df_old = df_old.copy()
    df_new = df_new.copy()

    cols_old = set(df_old.columns)
    cols_new = set(df_new.columns)
    shared_columns = list(cols_old.intersection(cols_new))
    # print(shared_columns)
    # print(compare_columns)

    for col in keys:
        if col not in shared_columns:
            raise ValueError(f"Key column {col} not in both dataframes")

    if compare_columns:
        for compare_col in compare_columns:
            if compare_col not in shared_columns:
                raise ValueError(f"Column {compare_col} not in both dataframes")
        shared_columns = [col for col in shared_columns if (col in compare_columns or col in keys)]

    df_old = df_old[shared_columns].copy()
    df_new = df_new[shared_columns].copy()

    # Strip whitespace from string columns
    for col in shared_columns:
        if pd.api.types.is_string_dtype(df_old[col]):
            df_old[col] = df_old[col].str.strip()
        if pd.api.types.is_string_dtype(df_new[col]):
            df_new[col] = df_new[col].str.strip()

    df_old['compare_key'] = df_old[keys].apply(lambda row: '_'.join(row.values.astype(str)), axis=1)
    df_new['compare_key'] = df_new[keys].apply(lambda row: '_'.join(row.values.astype(str)), axis=1)

    df = df_old.merge(df_new, on='compare_key', how='inner', suffixes=('_old', '_new'))

    # Calculate differences for shared columns (excluding the key column)
    columns = sorted([col for col in shared_columns if col not in keys and col != 'compare_key'])
    compared_columns = []
    for col in columns:
        is_numeric_old = pd.api.types.is_numeric_dtype(df_old[col])
        is_numeric_new = pd.api.types.is_numeric_dtype(df_new[col])

        if is_numeric_old != is_numeric_new:
            # raise ValueError(f"Data type mismatch for column '{col}': {df_old[col].dtype} vs {df_new[col].dtype}")
            print(f"WARNING: Data type mismatch for column '{col}': {df_old[col].dtype} vs {df_new[col].dtype} (skipping column value comparison)")
            continue

        if is_numeric_old and is_numeric_new:
            df[f'{col}_diff_absolute'] = abs(df[f'{col}_new'] - df[f'{col}_old'])
            df[f'{col}_diff_percent'] = (df[f'{col}_diff_absolute'] / df[f'{col}_old']) * 100
            df[f'{col}_diff_percent'] = df[f'{col}_diff_percent'].replace([float('inf'), float('-inf')], 100)
        else:
            # Check if both values are "empty" (None, NaN, empty string, or whitespace)
            def is_empty(val):
                return (
                    pd.isna(val)
                    or (
                        isinstance(val, str)
                        and (
                            val.strip() == ''
                            or val.strip().lower() == ' '
                            or val.strip().lower() == 'nan'
                            or val.strip().lower() == 'none'
                            or val.strip().lower() == 'null'
                            or val.strip().lower() == 'na'
                            or val.strip().lower() == 'n/a'
                        )
                    )
                )

            df[f'{col}_diff_absolute'] = df.apply(
                lambda row: False if (is_empty(row[f'{col}_old']) and is_empty(row[f'{col}_new']))
                else row[f'{col}_new'] != row[f'{col}_old'],
                axis=1
            )
            df[f'{col}_diff_percent'] = df[f'{col}_diff_absolute'].astype(int) * 100

        compared_columns.append(col)

    rename_dict = {f"{col}_old": col for col in keys}
    df.rename(columns=rename_dict, inplace=True)

    output_columns = keys.copy()
    for col in compared_columns:
        output_columns.extend([f'{col}_old', f'{col}_new', f'{col}_diff_absolute', f'{col}_diff_percent'])

    df = df[output_columns]

    data = {
        'column': compared_columns,
        'number of identical values': [],
        'number of values with small difference (<1%)': [],
        'number of values with big difference (>1%)': [],
    }
    for col in compared_columns:
        data['number of identical values'].append(len(df[df[f'{col}_diff_percent']==0]))
        data['number of values with small difference (<1%)'].append(len(df[(df[f'{col}_diff_percent']>0) & (df[f'{col}_diff_percent']<1)]))
        data['number of values with big difference (>1%)'].append(len(df[df[f'{col}_diff_percent']>1 ]))

    df_vals = df
    df_vals_summary = pd.DataFrame(data)

    return df_vals, df_vals_summary
