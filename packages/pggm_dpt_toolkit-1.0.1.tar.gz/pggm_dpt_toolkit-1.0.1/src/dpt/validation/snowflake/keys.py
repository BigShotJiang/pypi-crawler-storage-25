from IPython.display import Markdown, display
from validation.snowflake.table import Table
from snowflake.snowpark.functions import col
from snowflake.snowpark import DataFrame

from validation.snowflake.util import display_df


def compare_keys(table1:Table, table2:Table, key_columns:list[str], display_format='duckdb') -> DataFrame:
    '''
    Compare keys between two tables and display the result.

    This function counts the occurrences of each key combination in both tables. It then
    compares the key counts between the two tables by performing a full outer join on the
    key columns. It checks for missing key (combinations) in either table, and checks
    if there is a mismatch in key counts for any key combination. The results are
    displayed in a readable format using Markdown and DataFrame displays.

    Args:
        table1 (Table): The first table to compare.
        table2 (Table): The second table to compare.
        key_columns (list[str]): The list of key columns to compare between the tables.
        display_format (str): The output format for the DataFrame display ('duckdb', 'pandas', or 'snowpark').

    Returns:
        DataFrame: A Snowflake DataFrame containing the key comparison results (only rows with mismatches).
    '''
    if type(table1) != Table or type(table2) != Table:
        raise ValueError("Both inputs must be Table objects. Import using `from dpt.validation.snowflake import Table`")

    if table1.session != table2.session:
        raise ValueError("Both Table objects must use the same Snowflake session")

    if display_format not in ['duckdb', 'pandas', 'snowpark']:
        raise ValueError("Invalid display format. Supported formats are: 'duckdb', 'pandas', 'snowpark'")

    df1 = table1.df
    df2 = table2.df

    for key in key_columns:
        if key.startswith('"') and key.endswith('"'):
            key = key.strip('"')
        else:
            key = key.upper()
            
        if key not in df1.columns:
            raise ValueError(f"Key column '{key}' not found in table 1")
        if key not in df2.columns:
            raise ValueError(f"Key column '{key}' not found in table 2")

    df1 = df1.group_by(*key_columns).count().with_column_renamed('COUNT', 'key_count')
    df2 = df2.group_by(*key_columns).count().with_column_renamed('COUNT', 'key_count')

    src1 = table1.tag if table1.tag else '1'
    src2 = table2.tag if table2.tag else '2'

    df = df1.join(df2, on=key_columns, how='full_outer', lsuffix=f'_{src1}', rsuffix=f'_{src2}')

    df = df.where(
        col(f'key_count_{src1}').is_null()
        | col(f'key_count_{src2}').is_null()
        | (col(f'key_count_{src1}') != col(f'key_count_{src2}'))
    )

    if df.count() == 0:
        display(Markdown("✅ The tables have the same key counts"))
    else:
        display(Markdown("❌ The tables have different key counts"))
        display_df(df, display_format)

    return df
