import duckdb
from IPython.display import Markdown, display
from IPython import get_ipython
from dataclasses import dataclass
from snowflake.snowpark import Session, DataFrame


@dataclass
class Table:
    '''
    A class representing a Snwoflake table.

    This class is used to store the table name, schema, environment and session
    information. It also provides a method to get the table as a Snowpark DataFrame and to
    display the first few rows of the table.

    This class is used as part of the validation framework to compare different tables
    across environments and schemas.

    Attributes:
        session (Session): A Snowflake session object.
        env (str): The environment of the table (e.g., "PRD", "DEV").
        schema (str): The schema of the table.
        name (str): The name of the table.
        tag (str): An optional tag to identify the table in comparison overviews (e.g. "old", "new", "1", "2", "left", "right").
    '''

    session: Session = None
    db: str | None = None
    schema: str | None = None
    name: str | None = None
    tag: str | None = None

    def __post_init__(self):
        '''
        If no session is provided, try to get it from the global scope or the IPython user namespace.
        '''
        if self.session is None:
            self.session = globals().get('session')
        if self.session is None:
            ip = get_ipython()
            if ip is not None:
                self.session = ip.user_ns.get('session')

    @property
    def full_name(self) -> str:
        '''
        Returns the full_name (including database and schema) of the table in the format
        '''
        return f'{self.db}.{self.schema}.{self.name}'

    @property
    def df(self) -> DataFrame:
        '''
        Returns the Snowflake table as a Snowpark DataFrame.
        '''
        return self.session.table(self.full_name)

    def show(self, n=4) -> None:
        '''
        Uses DuckDB to display the first n rows of the table in a nice tabular format in Jupyter notebooks.
        '''
        display(Markdown(f"### `{self.name}`"))
        df = self.df.limit(n)
        duckdb.from_df(df.toPandas()).show()
