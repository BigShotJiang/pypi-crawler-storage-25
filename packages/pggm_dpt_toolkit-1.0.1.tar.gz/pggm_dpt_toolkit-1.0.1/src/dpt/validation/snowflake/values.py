
from IPython.display import Markdown, display
from snowflake.snowpark.functions import col, lit, when
from snowflake.snowpark.types import IntegerType, DecimalType, DoubleType, FloatType, LongType, ShortType, ByteType
from snowflake.snowpark import DataFrame

from validation.snowflake.util import display_df
from validation.snowflake.table import Table


snowflake_numeric_types = (IntegerType, DecimalType, DoubleType, FloatType, LongType, ShortType, ByteType)


def compare_values(table1:Table, table2:Table, key_columns:list[str], ignore_columns:list[str]=[], display_format='duckdb', tollerance=1) -> DataFrame:
    '''
    Compare values between two tables for shared keys and display the result.

    Given two Table objects, this function will identify the shared columns between the
    two tables, and then compare their values for a given set of key columns.
    For numeric columns, it checks if the relative difference doesn't exceed the specified
    tolerance. For non-numeric columns, it checks for exact matches. The results are
    displayed in a readable format using Markdown and DataFrame displays.

    Args:
        table1 (Table): The first table to compare.
        table2 (Table): The second table to compare.
        key_columns (list[str]): The list of key columns to compare between the tables.
        ignore_columns (list[str]): The list of columns to ignore in the comparison (default: []).
        display_format (str): The output format for the DataFrame display ('duckdb', 'pandas', or 'snowpark') (default: 'duckdb').
        tollerance (float): The percentage tolerance for numeric comparisons (default: 1).

    Returns:
        DataFrame: A Snowflake DataFrame containing the value comparison results (only rows with mismatches).
    '''
    df1 = table1.df
    df2 = table2.df

    cols1 = set(df1.columns)
    cols2 = set(df2.columns)

    joined_df = df1.join(df2, on=key_columns, how='inner', lsuffix='_1', rsuffix='_2')

    # columns that will be compared (i.e. all shared columns except for the key columns and any columns explicitly ignored)
    compare_columns = [c for c in cols1.intersection(cols2) if c not in key_columns and c not in ignore_columns]

    columns = []
    diff_conditions = []
    for column in compare_columns:
        # Handle quoted column names
        if column.startswith('"') and column.endswith('"'):
            column = column.strip('"')
            column_name_1 = f'"{column}_1"'
            column_name_2 = f'"{column}_2"'
        else:
            column_name_1 = f'{column}_1'
            column_name_2 = f'{column}_2'

        # create column objects for the two columns to compare
        c1 = col(column_name_1)
        c2 = col(column_name_2)

        # extract data type of the columns from the joined dataframe schema
        dtype1 = joined_df.schema[column_name_1].datatype
        dtype2 = joined_df.schema[column_name_2].datatype

        # check if the relative difference doesn't exceed the specified tolerance for numeric columns
        if isinstance(dtype1, snowflake_numeric_types) and isinstance(dtype2, snowflake_numeric_types):
            diff_expr = when(c1 == 0, lit(0)).otherwise((c1 - c2)/c1*100)
            # diff_condition = diff_expr > tollerance
            c_diff = diff_expr.alias(f'"{column}_pct_diff"')
            diff_condition = col(f'"{column}_pct_diff"') > tollerance

        # compare exact values for non-numeric columns
        else:
            diff_expr = (c1 == c2)
            # diff_condition = diff_expr == False
            c_diff = diff_expr.alias(f'"{column}_match"')
            diff_condition = col(f'"{column}_match"') == False

        # append columns in correct order
        columns.append(c1)
        columns.append(c2)
        columns.append(c_diff)

        # append condition to the list of conditions to filter on at the end
        diff_conditions.append(diff_condition)

    # final dataframe to display
    df = joined_df.select(
        *key_columns,
        *columns,
    )

    # only show rows where at least one compare column is different (OR semantics)
    combined_condition = diff_conditions[0]
    for condition in diff_conditions[1:]:
        combined_condition = combined_condition | condition
    df = df.where(combined_condition)

    if df.count() == 0:
        display(Markdown("✅ The tables have the same values for their shared keys"))
    else:
        display(Markdown("❌ The tables have different values for their shared keys"))
        display_df(df, display_format)

    return df
