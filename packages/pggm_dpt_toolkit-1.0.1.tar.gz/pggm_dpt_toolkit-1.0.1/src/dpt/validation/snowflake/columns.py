from IPython.display import Markdown, display
from validation.snowflake.table import Table
from snowflake.snowpark.functions import col
from snowflake.snowpark import DataFrame

from validation.snowflake.util import display_df


def get_columns_metadata_df(table:Table) -> DataFrame:
    '''
    Retrieve the column name and data type info for a Table object as a Snowflake DataFrame.

    Uses the information schema to retrieve the information. Expected the table object to
    have the session, environment, schema and name attributes properly set. Is used in the
    compare_columns function to compare the columns of two tables.
    '''
    session = table.session

    # remove quotes if present, as information_schema.columns stores unquoted column names
    name = table.name .strip('"') if table.name else None

    return (
        session.table(f'{table.db}.information_schema.columns')
        .where(col('table_schema')==table.schema)
        .where(col('table_name')==name)
        .select('column_name', 'data_type')
    )



def compare_columns(table1:Table, table2:Table, display_format:str='duckdb', check_dtypes:bool=True):
    '''
    Compare the columns of two tables and display the result.

    This function gathers the column metadata for both tables (column name and data type)
    and performs a full outer join on the column name to compare the columns. It checks
    for missing columns in either table (and, optionally, for data type mismatches).
    The results are displayed in a readable format using Markdown and DataFrame displays.

    Args:
        table1 (Table): The first table to compare.
        table2 (Table): The second table to compare.
        display_format (str): The output format for the DataFrame display ('duckdb', 'pandas', or 'snowpark').
        check_dtypes (bool): Whether to check for data type mismatches in addition to missing columns.
    '''
    if type(table1) != Table or type(table2) != Table:
        raise ValueError("Both inputs must be Table objects. Import using `from dpt.validation.snowflake import Table`")

    if table1.session != table2.session:
        raise ValueError("Both Table objects must use the same Snowflake session")

    if display_format not in ['duckdb', 'pandas', 'snowpark']:
        raise ValueError("Invalid display format. Supported formats are: 'duckdb', 'pandas', 'snowpark'")

    df1 = get_columns_metadata_df(table1)
    df2 = get_columns_metadata_df(table2)

    src1 = table1.tag if table1.tag else '1'
    src2 = table2.tag if table2.tag else '2'

    df_joined = df1.join(df2, on='column_name', how='full_outer', lsuffix=f'_{src1}', rsuffix=f'_{src2}')

    failed = False

    if check_dtypes:
        df_dtype_mismatches = df_joined.where(
            col(f'data_type_{src1}').is_not_null() & col(f'data_type_{src2}').is_not_null() & (col(f'data_type_{src1}') != col(f'data_type_{src2}'))
        )

        if df_dtype_mismatches.count() > 0:
            df = df_dtype_mismatches
            display(Markdown("⚠️ The tables have different data types for certain columns"))
            display_df(df, display_format)
            failed = True

    df_missing_columns = df_joined.where(
        col(f'data_type_{src1}').is_null() | col(f'data_type_{src2}').is_null()
    )

    if df_missing_columns.count() > 0:
        df = df_missing_columns
        display(Markdown("❌ The tables have different columns"))
        display_df(df, display_format)
        failed = True

    if not failed:
        display(Markdown("✅ The tables have the same columns"))
