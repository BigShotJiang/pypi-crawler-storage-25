from IPython.display import Markdown, display
from validation.snowflake.table import Table


def compare_row_counts(table1:Table, table2:Table) -> None:
    c1 = table1.df.count()
    c2 = table2.df.count()

    if c1 == c2:
        display(Markdown(f"✅ The tables have the same number of rows: {c1}"))
    else:
        display(Markdown(f"❌ The tables have different number of rows: {c1} vs {c2}"))
