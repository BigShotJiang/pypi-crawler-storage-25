import duckdb
from IPython.display import Markdown, display
from snowflake.snowpark import DataFrame


def display_df(df:DataFrame, format:str='duckdb') -> None:
    '''
    Display DataFrame in tabular format in Jupyter notebooks using the specified output format.

    Args:
        df (DataFrame): The Snowflake DataFrame to display.
        format (str): The output format for the DataFrame display. Supported formats are:
            - 'duckdb' (default)
            - 'pandas'
            - 'snowpark'
    '''
    if format not in ['duckdb', 'pandas', 'snowpark']:
        raise ValueError("Invalid output format. Supported formats are: 'duckdb', 'pandas', 'snowpark'")
    if format == 'duckdb':
        df = duckdb.from_df(df.toPandas())
        df.show()
    elif format == 'pandas':
        df = df.toPandas()
        display(df)
    elif format == 'snowpark':
        df.show()
    else:
        df.show()
