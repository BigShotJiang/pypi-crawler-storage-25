"""Data Platform Toolkit (DPT) — SQL magic for Jupyter + Snowflake, and a DBT compile CLI."""

__version__ = "1.0.0"
