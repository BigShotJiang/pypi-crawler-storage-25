from snowflake.snowpark import Session
from .. import config


def create_sf_session(email:str=None, domain:str=None, env:str=None, schema:str=None) -> Session:
    """
    Create and return a Snowflake session using Snowpark.

    Parameters:
        email (str): User email for Snowflake authentication.
        domain (str): Domain for the Snowflake account (e.g., "SHR.ESG").
        env (str): Environment to connect to (e.g., "PRD", "DEV").
        schema (str): Schema to use for the Snowflake session (default is "INFORMATION_SCHEMA").

    Returns:
        Session: A Snowflake session object.
    """
    email = email or config.require("DPT_SNOWFLAKE_EMAIL")
    domain = domain or config.require("DPT_DEFAULT_DOMAIN")
    env = env or config.DEFAULT_ENV
    schema = schema or config.DEFAULT_SCHEMA
    account = config.require("DPT_SNOWFLAKE_ACCOUNT")
    authenticator = config.SNOWFLAKE_AUTHENTICATOR

    domain_parts = domain.split(".")
    role_suffix = "STK" if env == "PRD" else "ENG"

    role = f"_{domain_parts[0]}_{domain_parts[1]}_{env}_ROLE_{role_suffix}"
    warehouse = f"_{domain_parts[0]}_{domain_parts[1]}_{env}_WH"
    database = f"_{domain_parts[0]}_{domain_parts[1]}_{env}_DB"

    connection_parameters = {
        "user": email,
        "account": account,
        "role": role,
        "warehouse": warehouse,
        "database": database,
        "schema": schema,
        "authenticator": authenticator,
    }
    return Session.builder.configs(connection_parameters).create()
