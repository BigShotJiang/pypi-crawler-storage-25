# Arguments that can be passed to the magic (e.g. %%sql --n_rows 10)
import argparse

def get_parser():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--n_rows",
        type=int,
        default=None,
        help="Limit the number of rows queried [input = number of rows]",
    )
    parser.add_argument(
        "--preview_max_rows",
        type=int,
        default=None,
        help="Limit the number of rows shown in notebook output cell",
    )

    parser.add_argument(
        "--display",
        type=str,
        choices=['pandas', 'duckdb', 'snowpark', 'polars', 'hidden'],
        default='duckdb',
        help="display as pandas, duckdb, snowpark, or polars dataframe [input = pandas/duckdb/snowpark/polars/hidden]",
    )

    parser.add_argument(
        "--df_pandas",
        type=str,
        default=None,
        help="store the data as a pandas dataframe to a variable [input = variable name]",
    )
    parser.add_argument(
        "--df_snowpark",
        type=str,
        default=None,
        help="store the query as a snowpark dataframe to a variable [input = variable name]",
    )
    parser.add_argument(
        "--df_duckdb",
        type=str,
        default=None,
        help="store the data as a duckdb dataframe to a variable [input = variable name]",
    )
    parser.add_argument(
        "--df_polars",
        type=str,
        default=None,
        help="store the data as a polars dataframe to a variable [input = variable name]",
    )
    parser.add_argument(
        "--str_query",
        type=str,
        default=None,
        help="store the query string to a variable [input = variable name]",
    )

    parser.add_argument(
        "--save_csv",
        type=str,
        default=None,
        help="save the query output to a csv file [input = file name]",
    )

    parser.add_argument(
        "--temp_table",
        type=str,
        default=None,
        help="store query output as a temporary table in Snowflake [input = table name]",
    )

    parser.add_argument(
        "--temp_view",
        type=str,
        default=None,
        help="store query output as a temporary view in Snowflake [input = view name]",
    )

    parser.add_argument(
        "--table",
        type=str,
        default=None,
        help="store query output as a temporary table in Snowflake [input = table name]",
    )

    parser.add_argument(
        "--view",
        type=str,
        default=None,
        help="store query output as a temporary view in Snowflake [input = view name]",
    )

    parser.add_argument(
        "--compile",
        action='store_true',
        help="compile the sql statement and return the compiled sql without executing it",
    )

    parser.add_argument(
        "--show_metadata",
        action='store_true',
        help="show metadata about the executed query",
    )

    return parser
