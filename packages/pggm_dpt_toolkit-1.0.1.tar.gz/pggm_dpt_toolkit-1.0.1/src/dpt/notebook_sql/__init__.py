from .magic import register_snowflake_session
from .session import create_sf_session
