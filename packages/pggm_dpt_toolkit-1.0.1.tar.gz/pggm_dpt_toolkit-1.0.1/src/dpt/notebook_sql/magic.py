import re

from snowflake.snowpark import Session
from snowflake import snowpark
from IPython.core.magic import (
    magics_class,
    Magics,
    cell_magic,
)
from IPython import get_ipython

import duckdb
import pandas as pd
import polars as pl
from .argument_parser import get_parser
from .session import create_sf_session

_IDENTIFIER_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')

def _validate_identifier(name: str) -> str:
    """Validate that a string is a safe SQL identifier."""
    if not _IDENTIFIER_RE.match(name):
        raise ValueError(f"Invalid SQL identifier: {name!r}")
    return name


def to_snowpark(df: snowpark.DataFrame, n_rows: int) -> snowpark.DataFrame:
    return df.limit(n_rows) if n_rows else df

def to_pandas(df: snowpark.DataFrame, n_rows: int) -> pd.DataFrame:
    df = df.limit(n_rows) if n_rows else df
    return df.toPandas()

def to_duckdb(df: snowpark.DataFrame, n_rows: int) -> duckdb.DuckDBPyRelation:
    df = df.limit(n_rows) if n_rows else df
    return duckdb.from_df(df.toPandas())

def to_polars(df: snowpark.DataFrame, n_rows: int):
    df = df.limit(n_rows) if n_rows else df
    return pl.from_pandas(df.toPandas())


def create_custom_magic(session: Session) -> Magics:
    """
    A function that creates a custom IPython magic class for executing SQL queries
    against the provided Snowflake session.

    Args:
        session (Session): A Snowflake session object used to execute the SQL queries.
    Returns:
        Magics: A custom IPython Magics class with a cell magic for SQL execution.
    """

    @magics_class
    class CustomMagic(Magics):

        @cell_magic
        def sql(self, line, cell):
            """
            Run a SQL query against the Snowflake session and handle various output options.

            This allows the user to write sql queries in a Jupyter notebook cell using the
            %%sql magic. The contents of the cell is passed along as a string through the
            `cell` parameter. Any arguments provided after %%sql are passed as the `line`
            parameter.

            The cell magic allows the user to execute SQL queries and control the output
            format and storage using command-line style arguments. See the `get_parser`
            function for more details on the available arguments and their usage.

            Args:
                line (str): The line arguments provided after %%sql.
                cell (str): The SQL query to be executed.

            Returns:
                Various outputs based on the provided arguments
            """
            # get arguments provided in the line (after %%sql, e.g. %%sql --n_rows 10)
            parser = get_parser()
            args = parser.parse_args(line.split())

            # Format the SQL query with variables from the user namespace
            query = cell.format_map(self.shell.user_ns)

            if args.compile:
                # Return the compiled SQL without executing it
                return print(query)

            # Execute SQL and store as snowpark DataFrame
            df = session.sql(query)

            if args.show_metadata:
                # Show metadata about the executed query
                print("Query Metadata:")
                print("---------------")
                # print(f"Query: \t {query}")
                print(f"Number of Rows: \t{df.count()}")
                print(f"Number of Columns: \t{len(df.columns)}")
                print(f"Column Names: \t \t{df.columns}")
                print()

            # --- STORE OUTPUT --- #
            if args.df_pandas:
                # Assign pd df to specified variable in user namespace
                self.shell.user_ns[args.df_pandas] = to_pandas(df, args.n_rows)

            if args.df_snowpark:
                # Assign snowpark df to specified variable in user namespace
                self.shell.user_ns[args.df_snowpark] = df

            if args.df_duckdb:
                # Assign duckdb df to specified variable in user namespace
                self.shell.user_ns[args.df_duckdb] = to_duckdb(df, args.n_rows)

            if args.str_query:
                # Assign the query string to specified variable in user namespace
                self.shell.user_ns[args.str_query] = query

            # --- SPECIAL COMMANDS --- #
            if args.temp_table:
                name = _validate_identifier(args.temp_table)
                session.sql(f"CREATE OR REPLACE TEMPORARY TABLE {name} AS ({query})").collect()

            if args.temp_view:
                name = _validate_identifier(args.temp_view)
                session.sql(f"CREATE OR REPLACE TEMPORARY VIEW {name} AS ({query})").collect()

            if args.table:
                name = _validate_identifier(args.table)
                session.sql(f"CREATE OR REPLACE TABLE {name} AS ({query})").collect()

            if args.view:
                name = _validate_identifier(args.view)
                session.sql(f"CREATE OR REPLACE VIEW {name} AS ({query})").collect()

            if args.save_csv:
                # save output of query to csv
                to_pandas(df, args.n_rows).to_csv(args.save_csv, index=False)

            # --- DISPLAY OUTPUT --- #
            if args.display == 'hidden':
                return

            if args.display == 'pandas':
                output = to_pandas(df, args.n_rows)
                return output.sample(args.preview_max_rows) if args.preview_max_rows else output

            if args.display == 'duckdb':
                output = to_duckdb(df, args.n_rows)
                return output.show(max_rows=args.preview_max_rows) if args.preview_max_rows else output.show()

            if args.display == 'snowpark':
                output = to_snowpark(df, args.n_rows)
                return output.show(args.preview_max_rows) if args.preview_max_rows else output.show()

            if args.display == 'polars':
                output = to_polars(df, args.n_rows)
                return output.head(args.preview_max_rows) if args.preview_max_rows else output

    return CustomMagic



def register_snowflake_session(email=None, domain=None, env=None, schema=None) -> Session:
    """
    Register the %%sql magic with a custom Snowflake session.

    The session that is created with the provided parameters is used to execute the SQL
    queries. This session is also returned by the function in case you want to use it
    directly with python code.

    Parameters default to values from your .env file / environment variables.

    Args:
        email (str): User email for Snowflake authentication.
        env (str): Environment to connect to (e.g., "PRD", "DEV").
        domain (str): Domain for the Snowflake account (e.g., "SHR.ESG").
        schema (str): Schema to use for the Snowflake session.
    Returns:
        Session: A Snowflake session object.
    """
    session = create_sf_session(email=email, env=env, domain=domain, schema=schema)
    ip = get_ipython()
    ip.register_magics(create_custom_magic(session))
    return session
