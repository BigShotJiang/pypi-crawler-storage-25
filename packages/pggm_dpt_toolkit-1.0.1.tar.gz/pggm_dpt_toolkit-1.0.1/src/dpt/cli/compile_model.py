import re
from pathlib import Path

from . import config


def get_compiled_model_path(model_name:str) -> Path:
    '''
    Retrieve the file path and schema of a compiled DBT model based on the model name.

    When you run the `dbt compile` command, DBT generates compiled SQL files in a specific
    directory structure. This function searches through the compiled directory to find the
    SQL file corresponding to the specified model name and returns its path along with the
    schema it belongs to.

    Args:
        model_name(str): name of the DBT model

    Returns:
        Path: The Path object of the compiled SQL file.
    '''
    current_dir = Path.cwd()
    current_parts = current_dir.parts

    # Find the root directory matching the repo pattern
    repo_pattern = re.compile(config.REPO_PATTERN)
    root_dir = None
    for i, part in enumerate(current_parts):
        if repo_pattern.search(part):
            root_dir = Path(*current_parts[:i + 1])
            break

    if root_dir is None:
        raise ValueError(f"Could not find a directory matching pattern '{config.REPO_PATTERN}' in current path")

    compiled_dir = root_dir / 'target' / 'compiled'
    # Get the first subdirectory in compiled_dir
    compiled_subdirs = [d for d in compiled_dir.iterdir() if d.is_dir()]
    if not compiled_subdirs:
        raise ValueError("No subdirectories found in compiled directory")

    compiled_models_dir = compiled_subdirs[0] / 'models'

    models_path = Path(compiled_models_dir)
    for directory in models_path.rglob('*'):
        if directory.is_file() and directory.suffix == '.sql' and f"{model_name}.sql" in str(directory) and directory.name == f"{model_name}.sql":
            model_path = directory
            break
    else:
        raise ValueError(f"Model {model_name}.sql not found")

    return model_path


def get_compiled_model_sql(model_path:Path, env:str, domain:str):
    '''
    Reads the SQL content of a compiled DBT model, and replaces the database & schema
    names based on the specified environment and domain.

    Args:
        model_path(Path): Path to the compiled SQL file
        env(str): Environment name (e.g., "PRD", "DEV", "TST", "ACC")
        domain(str): Domain name (e.g., "SHR.ESG")
        model_schema(str): Schema name

    Returns:
        str: The SQL content with updated database and schema names
    '''
    # SHR.ESG -> SHR_ESG
    domain = "_".join(domain.split("."))

    with open(model_path, 'r') as file:
        sql_content = file.read()

    if env in ["PRD", "DEV", "TST", "ACC"]:
        database = f"_{domain}_{env}_DB"
        database_default = f"_{domain}_DEV_DB"
        sql_content = sql_content.replace(database_default, database)

        schema_prefix = config.require("DPT_DBT_SCHEMA_PREFIX")
        for schema in ['_PRE', '_INT', '_DMT', '_APP', '_REF', '_LOG']:
            schema_default = f"{schema_prefix}{schema}"
            sql_content = sql_content.replace(schema_default, schema)

    return sql_content
