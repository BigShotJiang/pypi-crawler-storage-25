import shlex
import subprocess
import sys


def _split_command(command):
    """Split a command string into a list for safe execution."""
    if isinstance(command, str):
        return shlex.split(command)
    return command


def run_terminal_command(command, print_output=False):
    """Run a terminal command and handle output."""
    try:
        result = subprocess.run(
            _split_command(command),
            capture_output=True,
            text=True,
            check=True,
        )

        if result.stdout and print_output:
            print(result.stdout)

    except subprocess.CalledProcessError as e:
        print(f"Command failed with exit code {e.returncode}")
        if e.stdout:
            print("Output:", e.stdout)
        if e.stderr:
            print("Error:", e.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error running command: {e}")
        sys.exit(1)


def stream_terminal_command(command, print_output=False):
    """Run a terminal command and stream output."""
    try:
        process = subprocess.Popen(
            _split_command(command),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )

        for line in process.stdout:
            if print_output:
                print('\t' + line, end='')

        process.stdout.close()
        return_code = process.wait()
        if return_code != 0:
            raise subprocess.CalledProcessError(return_code, command)

    except subprocess.CalledProcessError as e:
        print(f"Command failed with exit code {e.returncode}")
        if e.stdout:
            print("Output:", e.stdout)
        if e.stderr:
            print("Error:", e.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error running command: {e}")
        sys.exit(1)
