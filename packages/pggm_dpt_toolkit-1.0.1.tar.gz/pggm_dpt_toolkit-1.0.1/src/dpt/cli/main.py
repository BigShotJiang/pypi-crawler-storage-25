import re
import shutil
from pathlib import Path

import click
import pyperclip

from . import config
from .compile_model import get_compiled_model_path, get_compiled_model_sql
from .config.domain import resolve_domain, set_domain, show_domain
from .terminal_commands import stream_terminal_command



# entry point for the CLI
@click.group()
def cli():
    pass


@click.command()
@click.option('--select', '-s', help='select a model')
@click.option('--env', '-e', help='select an environment', default='personal')
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose output')
def compile(select, env, verbose):
    '''
    Compiles a DBT model and copies the resulting SQL to the clipboard.

    The command takes the following options:
        - `--select` or `-s`: The name of the DBT model to compile (required).
        - `--env` or `-e`: The environment to use for the compiled SQL (default: "personal"). Valid options are "personal", "DEV", "TST", "ACC", and "PRD".
        - `--verbose` or `-v`: A flag to enable verbose output during the compilation process.
    '''
    valid_envs = config.ENVIRONMENTS
    if env not in valid_envs:
        click.secho(f'Error: Invalid environment "{env}". Please choose from {valid_envs}.', fg='red')
        return

    model_name = select

    domain = None
    # extract domain from the root directory using the configured repo pattern
    repo_pattern = re.compile(config.REPO_PATTERN)
    for part in Path.cwd().parts:
        match = repo_pattern.search(part)
        if match:
            domain = match.group(1).replace('.', '_')
            break

    # if domain is still None after parsing root directory, show error message and exit
    if domain is None:
        click.secho(f'Error: Could not determine domain from the current directory. No directory matching pattern "{config.REPO_PATTERN}" found.', fg='red')
        return

    # Compile the model using the DBT CLI and capture the output if verbose flag is set
    if verbose:
        click.secho(f'Sending {click.style("compile", fg="yellow")} command to dbt for model: {click.style(model_name, fg="blue")} \n')
        stream_terminal_command(f"dbt compile -s {model_name}", print_output=True)
    else:
        click.secho(f'Sending {click.style("compile", fg="yellow")} command to dbt for model: {click.style(model_name, fg="blue")}... \n')
        stream_terminal_command(f"dbt compile -s {model_name}", print_output=False)

    # compile SQL & copy to clipboard
    model_path = get_compiled_model_path(model_name)
    click.secho(f'\nCompiled model path: {click.style(model_path, fg="green")}\n')
    sql_content = get_compiled_model_sql(
        model_path=model_path,
        env=env,
        domain=domain,
    )

    click.secho(f'Compiled SQL for model {click.style(model_name, fg="blue")}:')
    click.secho(''.join(['------------------------', '-'*len(model_name), '\n']))
    click.secho(sql_content, fg='magenta')

    pyperclip.copy(model_path)
    pyperclip.copy(sql_content)

    click.secho(f'\nAbove query has been copied to clipboard :)\n')


cli.add_command(compile)


@click.command()
@click.argument('destination', default='.', type=click.Path())
@click.option('--list', '-l', 'list_examples', is_flag=True, help='List available example notebooks without copying.')
def examples(destination, list_examples):
    '''
    Copy the bundled example notebooks to a destination directory.

    By default, copies all example notebooks to the current directory.
    Use --list to see what's available without copying anything.
    '''
    import dpt.examples
    examples_dir = Path(dpt.examples.__file__).parent

    available = {
        'sql_notebook': 'SQL notebook — shows how to run SQL queries in Jupyter via %%sql magic',
        'validation':   'Validation notebooks — compare tables in Snowflake and generate reports',
    }

    if list_examples:
        click.secho('Available example notebooks:\n', bold=True)
        for name, desc in available.items():
            folder = examples_dir / name
            files = [f.name for f in folder.iterdir() if not f.name.startswith(('__', '~$', '.'))]
            click.secho(f'  {click.style(name, fg="blue")}  —  {desc}')
            for f in sorted(files):
                click.secho(f'    • {f}')
            click.echo()
        click.secho(f'Run {click.style("dpt examples", fg="green")} to copy them to the current directory.')
        return

    dest = Path(destination)
    dest.mkdir(parents=True, exist_ok=True)

    copied = 0
    for name in available:
        src_folder = examples_dir / name
        dst_folder = dest / 'dpt_examples' / name
        if dst_folder.exists():
            click.secho(f'  Skipping {name}/ (already exists at {dst_folder})', fg='yellow')
            continue
        shutil.copytree(
            src_folder, dst_folder,
            ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '~$*'),
        )
        copied += 1
        click.secho(f'  Copied {click.style(name + "/", fg="blue")} → {dst_folder}')

    if copied:
        click.secho(f'\n{copied} example folder(s) copied to {dest / "dpt_examples"}.', fg='green')
    else:
        click.secho('\nNo new examples to copy (all already exist).', fg='yellow')


cli.add_command(examples)

# deprecated functionality (domain is now obtained from the root directory of this repo (e.g., VB.SHR.DSO.DBT -> domain = SHR.DSO))
# cli.add_command(set_domain)
# cli.add_command(show_domain)
