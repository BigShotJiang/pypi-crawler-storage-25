from .config import load_config, save_config
import click


'''
UPDATE: The domain is now determined based on the name of the root directory of the repo.

For example for this repo, the root directory is "VB.SBX.DSO.DBT" from which the domain
SBX.DSO can be derived.

DEPRECATED:
-----------
The domain will be different for each repo this modules is used in, so the user can set
the relevant domain using the CLI interface or by passing it as an argument to the compile
command. If the user specifies a domain, it is stored in a config file in the user's home
directory.
'''


def validate_domain(domain):
    domain = domain.strip()
    if '.' not in domain:
        raise click.BadParameter('Domain must contain a dot, for example: SBX.DSO')
    return domain


def resolve_domain(domain_option):
    if domain_option:
        return validate_domain(domain_option)

    config = load_config()
    if 'domain' in config:
        return validate_domain(config['domain'])

    raise click.ClickException('No DOMAIN configured. Set it with: `dpt set-domain SBX.DSO` or pass `--domain`.')


@click.command(name='set-domain')
@click.argument('domain')
def set_domain(domain):
    domain = validate_domain(domain)
    config = load_config()
    config['domain'] = domain
    save_config(config)
    click.secho(f'DOMAIN set to {click.style(domain, fg="green")}', fg='white')


@click.command(name='show-domain')
def show_domain():
    config = load_config()
    domain = config.get('domain')

    if not domain:
        command = click.style('dpt set-domain', fg='green')
        example = click.style('dpt set-domain SBX.DSO', fg='green')
        click.secho(f'No DOMAIN configured. Use: {command} to configure, e.g.:  {example}')
        return

    click.secho(f'Current DOMAIN: {click.style(domain, fg="green")}', fg='white')
