import os
from pathlib import Path
from dotenv import load_dotenv


def _find_and_load_dotenv():
    """Search for .env file in cwd and parent directories, then load it."""
    current = Path.cwd()
    for directory in [current, *current.parents]:
        env_file = directory / ".env"
        if env_file.is_file():
            load_dotenv(env_file)
            return
    # Also check the dpt package directory itself (dpt/src/dpt/config.py -> dpt/)
    package_dir = Path(__file__).resolve().parent.parent.parent
    env_file = package_dir / ".env"
    if env_file.is_file():
        load_dotenv(env_file)


_find_and_load_dotenv()


def get(key: str, default: str | None = None) -> str | None:
    """Get a DPT configuration value from environment variables."""
    return os.environ.get(key, default)


def require(key: str) -> str:
    """Get a required DPT configuration value; raises if missing."""
    value = os.environ.get(key)
    if value is None:
        raise EnvironmentError(
            f"Required environment variable '{key}' is not set. "
            f"Please set it in your .env file or as an environment variable. "
            f"See .env.example for reference."
        )
    return value


# --- Snowflake Connection ---
SNOWFLAKE_ACCOUNT = get("DPT_SNOWFLAKE_ACCOUNT")
SNOWFLAKE_EMAIL = get("DPT_SNOWFLAKE_EMAIL")
SNOWFLAKE_AUTHENTICATOR = get("DPT_SNOWFLAKE_AUTHENTICATOR", "externalbrowser")

# --- Default Session Settings ---
DEFAULT_DOMAIN = get("DPT_DEFAULT_DOMAIN")
DEFAULT_ENV = get("DPT_DEFAULT_ENV", "DEV")
DEFAULT_SCHEMA = get("DPT_DEFAULT_SCHEMA", "INFORMATION_SCHEMA")

# --- CLI Settings ---
ENVIRONMENTS = get("DPT_ENVIRONMENTS", "personal,DEV,TST,ACC,PRD").split(",")
DBT_SCHEMA_PREFIX = get("DPT_DBT_SCHEMA_PREFIX")
REPO_PATTERN = get("DPT_REPO_PATTERN", r"VB\.(\w+\.\w+)\.DBT")
