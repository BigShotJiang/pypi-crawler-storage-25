"""UiPath evaluator implementations for agent performance evaluation."""

from typing import Any

# Current coded evaluators
from .base_evaluator import (
    BaseEvaluationCriteria,
    BaseEvaluator,
    BaseEvaluatorConfig,
    BaseEvaluatorJustification,
)
from .base_legacy_evaluator import BaseLegacyEvaluator
from .binary_classification_evaluator import BinaryClassificationEvaluator

# Legacy evaluators
from .contains_evaluator import ContainsEvaluator
from .exact_match_evaluator import ExactMatchEvaluator
from .json_similarity_evaluator import JsonSimilarityEvaluator
from .legacy_context_precision_evaluator import LegacyContextPrecisionEvaluator
from .legacy_csv_exact_match_evaluator import LegacyCSVExactMatchEvaluator
from .legacy_exact_match_evaluator import LegacyExactMatchEvaluator
from .legacy_faithfulness_evaluator import LegacyFaithfulnessEvaluator
from .legacy_json_similarity_evaluator import LegacyJsonSimilarityEvaluator
from .legacy_llm_as_judge_evaluator import LegacyLlmAsAJudgeEvaluator
from .legacy_trajectory_evaluator import LegacyTrajectoryEvaluator
from .llm_as_judge_evaluator import LLMJudgeJustification
from .llm_judge_output_evaluator import (
    BaseLLMOutputEvaluator,
    LLMJudgeOutputEvaluator,
    LLMJudgeStrictJSONSimilarityOutputEvaluator,
)
from .llm_judge_trajectory_evaluator import (
    BaseLLMTrajectoryEvaluator,
    LLMJudgeTrajectoryEvaluator,
    LLMJudgeTrajectorySimulationEvaluator,
)
from .multiclass_classification_evaluator import MulticlassClassificationEvaluator
from .output_evaluator import AggregationMethod
from .tool_call_args_evaluator import ToolCallArgsEvaluator
from .tool_call_count_evaluator import ToolCallCountEvaluator
from .tool_call_order_evaluator import ToolCallOrderEvaluator
from .tool_call_output_evaluator import ToolCallOutputEvaluator

EVALUATORS: list[type[BaseEvaluator[Any, Any, Any]]] = [
    ExactMatchEvaluator,
    ContainsEvaluator,
    BinaryClassificationEvaluator,
    MulticlassClassificationEvaluator,
    JsonSimilarityEvaluator,
    LLMJudgeOutputEvaluator,
    LLMJudgeStrictJSONSimilarityOutputEvaluator,
    LLMJudgeTrajectoryEvaluator,
    LLMJudgeTrajectorySimulationEvaluator,
    ToolCallOrderEvaluator,
    ToolCallArgsEvaluator,
    ToolCallCountEvaluator,
    ToolCallOutputEvaluator,
]
__all__ = [
    # Legacy evaluators
    "BaseLegacyEvaluator",
    "LegacyContextPrecisionEvaluator",
    "LegacyCSVExactMatchEvaluator",
    "LegacyExactMatchEvaluator",
    "LegacyFaithfulnessEvaluator",
    "LegacyLlmAsAJudgeEvaluator",
    "LegacyTrajectoryEvaluator",
    "LegacyJsonSimilarityEvaluator",
    # Current coded evaluators
    "BaseEvaluator",
    "BinaryClassificationEvaluator",
    "MulticlassClassificationEvaluator",
    "ContainsEvaluator",
    "ExactMatchEvaluator",
    "JsonSimilarityEvaluator",
    "BaseLLMOutputEvaluator",
    "LLMJudgeOutputEvaluator",
    "LLMJudgeStrictJSONSimilarityOutputEvaluator",
    "BaseLLMTrajectoryEvaluator",
    "LLMJudgeTrajectoryEvaluator",
    "LLMJudgeTrajectorySimulationEvaluator",
    "ToolCallOrderEvaluator",
    "ToolCallArgsEvaluator",
    "ToolCallCountEvaluator",
    "ToolCallOutputEvaluator",
    "BaseEvaluationCriteria",
    "BaseEvaluatorConfig",
    "BaseEvaluatorJustification",
    "LLMJudgeJustification",
    "AggregationMethod",
]
