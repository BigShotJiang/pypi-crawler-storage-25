"""
Face detection module.
"""
