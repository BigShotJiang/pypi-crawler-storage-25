"""
ConvNeXt model definitions.
"""

from collections import OrderedDict
from typing import Optional

from ..utils.types import ModelInfo, ModelInfoSet
from ..wrapper import MBLT_Engine


class ConvNeXt_Tiny_Set(ModelInfoSet):
    """Configuration set for ConvNeXt Tiny models."""

    IMAGENET1K_V1 = ModelInfo(
        model_cfg=OrderedDict(
            {
                "repo_id": "mobilint/ConvNext_Tiny",
                "filename": "convnext_tiny_IMAGENET1K_V1.mxq",
                "revision": "main",
            }
        ),
        pre_cfg=OrderedDict(
            {
                "Reader": {
                    "style": "pil",
                },
                "Resize": {
                    "size": 236,
                    "interpolation": "bilinear",
                },
                "CenterCrop": {
                    "size": [224, 224],
                },
                "SetOrder": {"shape": "HWC"},
                "Normalize": {
                    "style": "torch",
                },
            }
        ),
        post_cfg=OrderedDict(
            {
                "task": "image_classification",
            }
        ),
    )
    DEFAULT = IMAGENET1K_V1  # Default model


class ConvNeXt_Small_Set(ModelInfoSet):
    """Configuration set for ConvNeXt Small models."""

    IMAGENET1K_V1 = ModelInfo(
        model_cfg=OrderedDict(
            {
                "repo_id": "mobilint/ConvNext_Small",
                "filename": "convnext_small_IMAGENET1K_V1.mxq",
                "revision": "main",
            }
        ),
        pre_cfg=OrderedDict(
            {
                "Reader": {
                    "style": "pil",
                },
                "Resize": {
                    "size": 230,
                    "interpolation": "bilinear",
                },
                "CenterCrop": {
                    "size": [224, 224],
                },
                "SetOrder": {"shape": "HWC"},
                "Normalize": {
                    "style": "torch",
                },
            }
        ),
        post_cfg=OrderedDict(
            {
                "task": "image_classification",
            }
        ),
    )
    DEFAULT = IMAGENET1K_V1  # Default model


class ConvNeXt_Base_Set(ModelInfoSet):
    """Configuration set for ConvNeXt Base models."""

    IMAGENET1K_V1 = ModelInfo(
        model_cfg=OrderedDict(
            {
                "repo_id": "mobilint/ConvNext_Base",
                "filename": "convnext_base_IMAGENET1K_V1.mxq",
                "revision": "main",
            }
        ),
        pre_cfg=OrderedDict(
            {
                "Reader": {
                    "style": "pil",
                },
                "Resize": {
                    "size": 232,
                    "interpolation": "bilinear",
                },
                "CenterCrop": {
                    "size": [224, 224],
                },
                "SetOrder": {"shape": "HWC"},
                "Normalize": {
                    "style": "torch",
                },
            }
        ),
        post_cfg=OrderedDict(
            {
                "task": "image_classification",
            }
        ),
    )
    DEFAULT = IMAGENET1K_V1  # Default model


class ConvNeXt_Large_Set(ModelInfoSet):
    """Configuration set for ConvNeXt Large models."""

    IMAGENET1K_V1 = ModelInfo(
        model_cfg=OrderedDict(
            {
                "repo_id": "mobilint/ConvNext_Large",
                "filename": "convnext_large_IMAGENET1K_V1.mxq",
                "revision": "main",
            }
        ),
        pre_cfg=OrderedDict(
            {
                "Reader": {
                    "style": "pil",
                },
                "Resize": {
                    "size": 232,
                    "interpolation": "bilinear",
                },
                "CenterCrop": {
                    "size": [224, 224],
                },
                "SetOrder": {"shape": "HWC"},
                "Normalize": {
                    "style": "torch",
                },
            }
        ),
        post_cfg=OrderedDict(
            {
                "task": "image_classification",
            }
        ),
    )
    DEFAULT = IMAGENET1K_V1  # Default model


class ConvNeXt_Tiny(MBLT_Engine):
    """ConvNeXt_Tiny model engine."""

    def __init__(
        self,
        local_path: Optional[str] = None,
        model_type: str = "DEFAULT",
        infer_mode: str = "global8",
        product: str = "aries",
    ):
        """Initializes the ConvNeXt_Tiny engine.

        Args:
            local_path (str, optional): Path to a local model file. Defaults to None.
            model_type (str, optional): Model configuration type. Defaults to "DEFAULT".
            infer_mode (str, optional): Inference execution mode. Defaults to "global8".
            product (str, optional): Target hardware product. Defaults to "aries".
        """
        model_cfg, pre_cfg, post_cfg = self._get_configs(
            ConvNeXt_Tiny_Set,
            local_path=local_path,
            model_type=model_type,
            infer_mode=infer_mode,
            product=product,
        )
        super().__init__(model_cfg, pre_cfg, post_cfg)


class ConvNeXt_Small(MBLT_Engine):
    """ConvNeXt_Small model engine."""

    def __init__(
        self,
        local_path: Optional[str] = None,
        model_type: str = "DEFAULT",
        infer_mode: str = "global8",
        product: str = "aries",
    ):
        """Initializes the ConvNeXt_Small engine.

        Args:
            local_path (str, optional): Path to a local model file. Defaults to None.
            model_type (str, optional): Model configuration type. Defaults to "DEFAULT".
            infer_mode (str, optional): Inference execution mode. Defaults to "global8".
            product (str, optional): Target hardware product. Defaults to "aries".
        """
        model_cfg, pre_cfg, post_cfg = self._get_configs(
            ConvNeXt_Small_Set,
            local_path=local_path,
            model_type=model_type,
            infer_mode=infer_mode,
            product=product,
        )
        super().__init__(model_cfg, pre_cfg, post_cfg)


class ConvNeXt_Base(MBLT_Engine):
    """ConvNeXt_Base model engine."""

    def __init__(
        self,
        local_path: Optional[str] = None,
        model_type: str = "DEFAULT",
        infer_mode: str = "global8",
        product: str = "aries",
    ):
        """Initializes the ConvNeXt_Base engine.

        Args:
            local_path (str, optional): Path to a local model file. Defaults to None.
            model_type (str, optional): Model configuration type. Defaults to "DEFAULT".
            infer_mode (str, optional): Inference execution mode. Defaults to "global8".
            product (str, optional): Target hardware product. Defaults to "aries".
        """
        model_cfg, pre_cfg, post_cfg = self._get_configs(
            ConvNeXt_Base_Set,
            local_path=local_path,
            model_type=model_type,
            infer_mode=infer_mode,
            product=product,
        )
        super().__init__(model_cfg, pre_cfg, post_cfg)


class ConvNeXt_Large(MBLT_Engine):
    """ConvNeXt_Large model engine."""

    def __init__(
        self,
        local_path: Optional[str] = None,
        model_type: str = "DEFAULT",
        infer_mode: str = "global8",
        product: str = "aries",
    ):
        """Initializes the ConvNeXt_Large engine.

        Args:
            local_path (str, optional): Path to a local model file. Defaults to None.
            model_type (str, optional): Model configuration type. Defaults to "DEFAULT".
            infer_mode (str, optional): Inference execution mode. Defaults to "global8".
            product (str, optional): Target hardware product. Defaults to "aries".
        """
        model_cfg, pre_cfg, post_cfg = self._get_configs(
            ConvNeXt_Large_Set,
            local_path=local_path,
            model_type=model_type,
            infer_mode=infer_mode,
            product=product,
        )
        super().__init__(model_cfg, pre_cfg, post_cfg)
