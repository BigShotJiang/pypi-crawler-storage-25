# bitbucket - get_file_commit_hash

**Toolkit**: `bitbucket`
**Method**: `get_file_commit_hash`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def get_file_commit_hash(self, file_path: str, branch: str):
        """
        Get the commit hash of a file in a specific branch.
        Parameters:
            file_path (str): The path to the file.
            branch (str): The branch name.
        Returns:
            str: The commit hash of the file.
        """
        commits = self.repository.commits.get(path=file_path, branch=branch, pagelen=1)
        if commits['values']:
            return commits['values'][0]['hash']
        return None
```

## Helper Methods

```python
Helper: retry_on_rate_limit
def retry_on_rate_limit(
    max_retries: int = 5,
    base_delay: float = 1.0,
    max_delay: float = 60.0
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator to retry API calls on 429 rate limit errors with exponential backoff.

    When Bitbucket API returns HTTP 429 (Too Many Requests), the decorated function
    will automatically retry with exponential backoff delays.

    Args:
        max_retries: Maximum number of retry attempts (default: 5)
        base_delay: Initial delay in seconds before first retry (default: 1.0)
        max_delay: Maximum delay between retries in seconds (default: 60.0)

    Returns:
        Decorated function with retry logic

    Example:
        @retry_on_rate_limit(max_retries=3, base_delay=2.0)
        def list_branches(self):
            return self.api_client.get_branches()
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            last_exception = None

            for attempt in range(max_retries + 1):  # +1 for initial attempt
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e

                    if not is_rate_limit_error(e):
                        # Not a rate limit error - re-raise immediately
                        raise

                    if attempt < max_retries:
                        # Calculate delay with exponential backoff
                        delay = min(base_delay * (2 ** attempt), max_delay)
                        logger.warning(
                            f"Rate limit hit (429) in {func.__name__}, "
                            f"retrying in {delay:.1f}s (attempt {attempt + 1}/{max_retries})"
                        )
                        time.sleep(delay)
                    else:
                        # Max retries exceeded
                        logger.error(
                            f"Max retries ({max_retries}) exceeded for {func.__name__} "
                            f"due to rate limiting"
                        )
                        raise ToolException(
                            f"Bitbucket API rate limit exceeded after {max_retries} retries. "
                            f"Please wait a few minutes before trying again. "
                            f"Original error: {str(e)}"
                        ) from e

            # Should not reach here, but handle edge case
            if last_exception:
                raise last_exception

        return wrapper
    return decorator
```
