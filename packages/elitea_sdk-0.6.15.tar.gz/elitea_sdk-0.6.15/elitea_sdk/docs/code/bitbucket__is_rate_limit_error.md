# bitbucket - is_rate_limit_error

**Toolkit**: `bitbucket`
**Method**: `is_rate_limit_error`
**Source File**: `cloud_api_wrapper.py`

---

## Method Implementation

```python
def is_rate_limit_error(error: Exception) -> bool:
    """Check if the exception is a rate limit (429) error.

    Args:
        error: The exception to check

    Returns:
        True if this is a rate limit error, False otherwise
    """
    error_str = str(error).lower()
    return (
        "429" in error_str or
        "too many requests" in error_str or
        "rate limit" in error_str
    )
```
