# bitbucket - get_files_list

**Toolkit**: `bitbucket`
**Method**: `get_files_list`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def get_files_list(self, file_path: str, branch: str, recursive: bool = True) -> list:
        """Get list of files from a specific path and branch.

        Branch names with slashes are URL-encoded to ensure proper API requests.

        Parameters:
            file_path (str): The path to list files from
            branch (str): The branch name
            recursive (bool): Whether to list files recursively. If False, only direct children are returned.

        Returns:
            list: List of file paths
        """
        files_list = []
        # URL-encode branch name to handle special characters like forward slashes
        branch_hash = self._get_branch(branch).hash
        page = None

        while True:
            # Build the path with pagination
            path = f'src/{branch_hash}/{file_path}?max_depth=100&pagelen=100&fields=values.path,next&q=type="commit_file"'
            if page:
                path = page

            response = self.repository.get(path=path, advanced_mode=True)

            # Check status code
            status = getattr(response, "status_code", None)
            if status is not None and status != 200:
                raise ToolException(
                    f"Failed to list files from path '{file_path}' on branch '{branch}': HTTP {status}"
                )

            # Parse JSON response - handle empty responses
            response_text = getattr(response, "text", "")
            if not response_text or not response_text.strip():
                # Empty response - path doesn't exist or is not a directory
                break

            try:
                response_data = response.json() if hasattr(response, 'json') else {}
            except (ValueError, json.JSONDecodeError) as e:
                # JSON parsing failed - likely malformed response or empty body
                logger.warning(
                    f"Failed to parse JSON response for path '{file_path}' on branch '{branch}': {e}. "
                    f"Response text (first 200 chars): {response_text[:200]}"
                )
                break
            except Exception as e:
                # Unexpected error - don't silently ignore
                logger.error(f"Unexpected error parsing response for path '{file_path}' on branch '{branch}': {e}")
                raise ToolException(
                    f"Unexpected error listing files from path '{file_path}' on branch '{branch}': {e}"
                )

            for item in response_data.get('values', []):
                files_list.append(item['path'])

            # Check for next page
            page = response_data.get('next')
            if not page:
                break

        # Apply client-side filtering when recursive=False
        if not recursive:
            files_list = self._filter_non_recursive(files_list, file_path)

        return files_list
```

## Helper Methods

```python
Helper: retry_on_rate_limit
def retry_on_rate_limit(
    max_retries: int = 5,
    base_delay: float = 1.0,
    max_delay: float = 60.0
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator to retry API calls on 429 rate limit errors with exponential backoff.

    When Bitbucket API returns HTTP 429 (Too Many Requests), the decorated function
    will automatically retry with exponential backoff delays.

    Args:
        max_retries: Maximum number of retry attempts (default: 5)
        base_delay: Initial delay in seconds before first retry (default: 1.0)
        max_delay: Maximum delay between retries in seconds (default: 60.0)

    Returns:
        Decorated function with retry logic

    Example:
        @retry_on_rate_limit(max_retries=3, base_delay=2.0)
        def list_branches(self):
            return self.api_client.get_branches()
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            last_exception = None

            for attempt in range(max_retries + 1):  # +1 for initial attempt
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e

                    if not is_rate_limit_error(e):
                        # Not a rate limit error - re-raise immediately
                        raise

                    if attempt < max_retries:
                        # Calculate delay with exponential backoff
                        delay = min(base_delay * (2 ** attempt), max_delay)
                        logger.warning(
                            f"Rate limit hit (429) in {func.__name__}, "
                            f"retrying in {delay:.1f}s (attempt {attempt + 1}/{max_retries})"
                        )
                        time.sleep(delay)
                    else:
                        # Max retries exceeded
                        logger.error(
                            f"Max retries ({max_retries}) exceeded for {func.__name__} "
                            f"due to rate limiting"
                        )
                        raise ToolException(
                            f"Bitbucket API rate limit exceeded after {max_retries} retries. "
                            f"Please wait a few minutes before trying again. "
                            f"Original error: {str(e)}"
                        ) from e

            # Should not reach here, but handle edge case
            if last_exception:
                raise last_exception

        return wrapper
    return decorator
```
