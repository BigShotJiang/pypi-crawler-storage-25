"""Setup/build/install script for interpax_fft."""

import os

import versioneer
from setuptools import find_packages, setup

here = os.path.abspath(os.path.dirname(__file__))


with open(os.path.join(here, "README.rst"), encoding="utf-8") as f:
    long_description = f.read()

with open(os.path.join(here, "requirements.txt"), encoding="utf-8") as f:
    requirements = f.read().splitlines()

setup(
    name="interpax_fft",
    version=versioneer.get_version(),
    cmdclass=versioneer.get_cmdclass(),
    description=("Fourier interpolation and function approximation with JAX"),
    long_description=long_description,
    long_description_content_type="text/x-rst",
    url="https://github.com/unalmis/interpax_fft",
    author="Kaya Unalmis",
    author_email="kunalmis@stanford.edu",
    license="MIT",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Natural Language :: English",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Topic :: Scientific/Engineering",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Typing :: Typed",
    ],
    keywords="interpolation fourier approximation",
    packages=find_packages(exclude=["docs", "tests", "local", "report"]),
    include_package_data=True,
    install_requires=requirements,
    python_requires=">=3.10",
    project_urls={
        "Issues Tracker": "https://github.com/unalmis/interpax_fft/issues",
        "Contributing": "https://github.com/unalmis/interpax_fft/blob/master/CONTRIBUTING.rst",  # noqa: E501
        "Source Code": "https://github.com/unalmis/interpax_fft/",
        "Documentation": "https://unalmis.github.io/interpax_fft/",
    },
)
