cd "/Users/jkm/Projects/cvc" && rm -rf dist && uv build && uv publish --token pypi-AgEIcHlwaS5vcmcCJDM4YTQyMmI5LWQ1MWYtNGY5MS04NmI0LTZlYjgzNWE3NTFjYQACDVsxLFsidG0tYWkiXV0AAixbMixbIjNlZmRhOWRiLWIwMGUtNGFiMS04YmZlLTQ4NWY5ODQ5YzA0YSJdXQAABiCTXlhsmHS6JWE776o6W2WBd4Oot0hxkFmNqp-3cZzOHQ

