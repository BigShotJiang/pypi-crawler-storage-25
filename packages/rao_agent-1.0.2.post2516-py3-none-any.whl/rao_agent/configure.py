from typing import Any, Dict

from rao_agent import logger

AGENTS: Dict[str, Any] = {}
DRIVERS: Dict[str, Any] = {}

try:
    from nuclia_arag.configure import (
        agent,  # type: ignore
        driver,  # type: ignore
        get_agent_config_klass,  # type: ignore
        get_agent_klass,  # type: ignore
        get_driver_config_instance,  # type: ignore
        get_driver_config_klass,  # type: ignore
        get_driver_klass,  # type: ignore
    )
except ImportError:
    logger.warning(
        "nuclia_arag is not installed, using dummy agent configuration. Install nuclia_arag to use agent configuration and registration features."
    )

    def agent(*args, **kwargs):  # type: ignore
        def decorator(cls):
            AGENTS[kwargs["id"]] = {
                "class": cls,
                "config": kwargs,
            }
            return cls

        return decorator

    def driver(*args, **kwargs):  # type: ignore
        def decorator(cls):
            DRIVERS[kwargs["id"]] = {
                "class": cls,
                "config": kwargs,
            }
            return cls

        return decorator

    def get_agent_klass(agent_type: str):  # type: ignore
        raise ImportError("nuclia_arag is not installed, cannot get agent klass")

    def get_agent_config_klass(agent_type: str):  # type: ignore
        raise ImportError("nuclia_arag is not installed, cannot get agent config klass")

    def get_driver_klass(driver_provider: str):  # type: ignore
        return DRIVERS.get(driver_provider, {}).get("class")

    def get_driver_config_instance(driver_provider: str, config: dict):  # type: ignore
        for ident, x in DRIVERS.items():
            if ident == driver_provider and x["config"]["config_schema"] is not None:
                return x["config"]["config_schema"].model_validate(config)
        raise ValueError(f"No driver found for provider {driver_provider}")

    def get_driver_config_klass(driver_provider: str):  # type: ignore
        for ident, x in DRIVERS.items():
            if ident == driver_provider and x["config"]["config_schema"] is not None:
                return x["config"]["config_schema"]
        raise ValueError(f"No driver found for provider {driver_provider}")


__all__ = [
    "agent",
    "driver",
    "get_agent_klass",
    "get_agent_config_klass",
    "get_driver_klass",
    "get_driver_config_instance",
    "get_driver_config_klass",
]
