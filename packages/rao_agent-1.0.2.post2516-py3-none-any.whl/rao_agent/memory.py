import abc
import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional, OrderedDict, Union

from nuclia.lib.nua_responses import Image, Message, StoredLearningConfiguration
from nucliadb_models.resource import (
    ConversationFieldData,
    FileFieldData,
    GenericFieldData,
    LinkFieldData,
    TextFieldData,
)
from nucliadb_models.search import CatalogFacetsResponse, KnowledgeboxFindResults
from pydantic import BaseModel, Field

from rao_agent import PROMPT_ENVIRONMENT, logger

if TYPE_CHECKING:
    from rao_agent.interaction import Feedback, OAuthAuthenticateURL
    from rao_agent.pubsub import UserToAgentInteraction


class Metadata:
    pass


class KnowledgeGraph:
    pass


class Reason:
    pass


class NucliaDBMemoryConfig(BaseModel):
    key: Optional[str] = None
    url: str
    kbid: str
    internal: bool = True


class MemoryConfig(BaseModel):
    nucliadb: Optional[NucliaDBMemoryConfig] = None


class Rule(BaseModel):
    prompt: Optional[str] = None


class Rules(BaseModel):
    rules: List[Union[Rule, str]] = Field(
        default_factory=list,
        description="List of rules that the workflow should follow. Each rule can be a string or a Rule object with a prompt.",
    )


class Facets(BaseModel):
    chunks: Dict[str, int]
    fields: Dict[str, int]


class Source(BaseModel):
    id: str
    description: str
    labels: Dict[str, List[str]]
    facets_native: CatalogFacetsResponse
    paragraph_facets: Dict[str, int]
    learning_configuration: StoredLearningConfiguration


class CitationMetadata(BaseModel):
    context_id: str = Field(
        description="ID of the context this citation refers to",
    )
    origin_urls: list[str] = Field(
        default_factory=list,
        description="List of origin URLs that this citation refers to",
    )
    chunk_index: Optional[int] = Field(
        default=None,
        description="Index of the chunk in the context's chunks list. This is only set for chunk-level citations.",
    )


class AnswerCitations(BaseModel):
    metadata: dict[str, CitationMetadata] = Field(
        default_factory=dict,
        description="Map of citation_id to citation metadata. block-AA",
    )


class VegaLiteVisualization(BaseModel):
    type: Literal["vega_lite"] = "vega_lite"
    vega_lite_obj: Dict[str, Any] = Field(
        default_factory=dict,
        description="The Vega-Lite Object defining the visualization. Previously validated against the Vega-Lite schema.",
    )

    # If we do server-side rendering in the future, we can add fields like:
    # svg: Optional[str] = ...


# For once we add more visualization types, we can use a Discriminator
# Visualization = Annotated[Union[VegaLiteVisualization,NewType], Discriminator("type")]
# For now, we only have one type.
Visualization = Union[VegaLiteVisualization]


class Step(BaseModel):
    original_question_uuid: Optional[str]
    actual_question_uuid: Optional[str]
    module: str
    title: str
    value: Optional[str] = None
    agent_path: str
    reason: Optional[str] = None
    timeit: float
    input_nuclia_tokens: Optional[float]
    output_nuclia_tokens: Optional[float]
    error: Optional[str] = None

    def __str__(self):
        return f"({self.timeit:.2f}s) {self.module}: {self.title} \n {self.value} \n {self.reason} \n NT:({self.input_nuclia_tokens}:{self.output_nuclia_tokens})"

    def markdown(self):
        return f"""
## {self.title}

{self.value}

- reason: {self.reason}
- timeit: {self.timeit}
- input_tokens: {self.input_nuclia_tokens}
- output_tokens: {self.output_nuclia_tokens}
"""


class ChunkImages(BaseModel):
    table: Optional[str]
    chunk: Optional[str]
    page: Optional[str]


FieldTypes = Union[
    TextFieldData,
    ConversationFieldData,
    FileFieldData,
    LinkFieldData,
    GenericFieldData,
]


class Chunk(BaseModel):
    chunk_id: str
    title: Optional[str] = None
    source: Optional[str] = None
    text: str
    labels: List[str] = Field(default_factory=list)
    url: List[str] = Field(default_factory=list)
    metadata: Optional[Dict[str, Any]] = None
    action: Optional[str] = Field(
        default=None,
        description="agent and function called to get this chunk.",
    )
    origin_url: Optional[str] = Field(
        default=None,
        description="URL at the origin of the resource from which this chunk was extracted.",
    )
    origin_agent: Optional[str] = Field(
        default=None,
        description="Agent that originated this chunk. This is useful to keep track of the provenance of the information ",
    )

    def render(
        self,
        citations_id: Optional[str] = None,
    ) -> str:
        if citations_id:
            lines = [f"## Chunk: [{citations_id}] {self.title or self.chunk_id}"]
        else:
            lines = [f"## Chunk: {self.title or self.chunk_id}"]
        if self.action:
            lines.append(f"Result of running: {self.action}")
        if self.labels:
            lines.append(f"Tags: {', '.join(self.labels)}")
        if self.url:
            lines.append(f"URLs: {', '.join(self.url)}")
        lines.append(f"``` {self.text} ```\n")
        return "\n".join(lines)


class Prompt(BaseModel):
    prompt: str
    resources: List[str] = Field(default_factory=list)
    links: List[str] = Field(default_factory=list)
    description: Optional[str] = None

    def render(self) -> str:
        lines = ["## Prompt"]
        if self.description:
            lines.append(f"Description: {self.description}")
        if self.resources:
            lines.append(f"Resources: {', '.join(self.resources)}")
        if self.links:
            lines.append(f"Links: {', '.join(self.links)}")
        lines.append(f"```PROMPT\n{self.prompt}\n```\n")
        return "\n".join(lines)


class Answer(BaseModel):
    answer: str
    original_question_uuid: Optional[str]
    actual_question_uuid: Optional[str]
    module: str
    agent_path: str
    data_visualizations: Optional[list[Visualization]] = None
    citations: Optional[AnswerCitations] = None
    chunks: Optional[list[Chunk]] = None
    structured: Optional[list[str]] = None
    images: Optional[Dict[str, Image]] = None
    image_urls: Optional[list[str]] = None


CONTEXT_TEMPLATE = """

{% if con.citations_id is not none -%}
{% for chunk in con.chunks %}
{{chunk.render(citations_id=con.citations_id ~ "-" ~ loop.index0)}}
{% endfor -%}
{% else -%}
{% for chunk in con.chunks %}
{{chunk.render()}}
{% endfor -%}
{% endif -%}

{% if con.structured | length > 0 -%}
## Extra structured info:
{% for structured in con.structured %}
{{structured}}
{% endfor -%}
{% endif -%}
"""

CONTEXT_PROMPT_TEMPLATE = PROMPT_ENVIRONMENT.from_string(CONTEXT_TEMPLATE)


class Context(BaseModel):
    id: str = Field(
        default_factory=lambda: uuid.uuid4().hex,
        description="Unique identifier for this context instance",
    )
    original_question_uuid: Optional[str]
    actual_question_uuid: Optional[str]
    question: str
    chunks: List[Chunk] = Field(default_factory=list)
    images: Dict[str, Image] = Field(default_factory=dict)
    prompts: List[Prompt] = Field(default_factory=list)
    structured: List[str] = Field(default_factory=list)
    source: str
    agent: str
    # XXX: This is not actually a summary, but an answer attempt for now!
    summary: str = Field(
        default="",
        description="Partial or full answer to the question, generated by the context validation step inside a context agent.",
    )
    agent_id: str = ""
    title: Optional[str] = None
    missing: Optional[str] = None
    citations: list[str] | None = Field(
        default=None,
        description="List of chunk IDs that were considered relevant in the context validation step.",
    )
    citations_id: Optional[str] = Field(
        default=None,
        description="Block ID used for citations in this context.",
    )
    image_urls: List[str] = Field(
        default_factory=list,
        description="List of image URLs associated with this context.",
    )

    def answer_summary_markdown(self) -> str:
        return "# {question}\n\n {summary}".format(
            question=self.question, summary=self.summary
        )

    def context_markdown(self) -> str:
        return CONTEXT_PROMPT_TEMPLATE.render(con=self)

    def stats(self) -> Dict[str, int | str | None]:
        return {
            "chunks": len(self.chunks),
            "images": len(self.images),
            "structured": len(self.structured),
            "source": self.source,
            "question": self.question,
            "agent": self.agent,
            "summary": self.summary,
            "title": self.title,
            "missing": self.missing,
        }

    def prune_to_citations(self) -> None:
        if self.citations is None:
            logger.warning(
                "Cannot prune context as no citations are available.",
                extra={
                    "agent": self.agent,
                    "source": self.source,
                    "agent_id": self.agent_id,
                },
            )
            return
        self.chunks = [
            chunk for chunk in self.chunks if chunk.chunk_id in self.citations
        ]
        self.structured = [
            s
            for i, s in enumerate(self.structured)
            if f"structured-{i}" in self.citations
        ]


class HistoryQuestionAnswer(BaseModel):
    question: str
    answer: str


class QuestionMemory:
    headers: Dict[str, str]
    arguments: Dict[str, str]

    # Main RAG Block
    started_at: datetime
    original_actions: List[str]
    original_question: str
    original_question_uuid: str
    final_answer: Optional[str] = None
    final_answer_citations: Optional[AnswerCitations] = None
    final_answer_urls: List[str]
    answers: list[tuple[str, Optional[AnswerCitations]]]
    generated_texts: Dict[str, str]
    # Data visualizations generated
    data_visualizations: List[Visualization]

    # Whether after generation, we consider the question answered (for example we might have generated a response but the response was "not enough data to answer this")
    is_answered: bool = False

    # Short term memory
    steps: List[Step]
    contexts: List[Context]
    agent_contexts: Dict[str, Dict[str, List[Context]]]

    # Flow controls
    restart: bool = False
    secure: Optional[bool] = None

    future_questions: OrderedDict[str, str]
    context_questions: OrderedDict[str, str]
    actual_question: Optional[str] = None
    actual_question_uuid: Optional[str] = None

    generation_rules: OrderedDict[str, str]
    actual_action: Optional[str] = None
    actual_action_uuid: Optional[str] = None

    def __init__(self):
        self.started_at = datetime.now(timezone.utc)

        # Start of a new question by the user
        self.restart = True
        self.original_question_uuid = uuid.uuid4().hex

        self.headers = {}
        self.arguments = {}
        self.contexts = []
        self.steps = []

        self.context_questions = OrderedDict()
        self.original_actions = []
        self.future_questions = OrderedDict()
        self.answers: list[tuple[str, Optional[AnswerCitations]]] = []
        self.generated_texts = {}
        self.data_visualizations = []
        self.final_answer_urls = []
        self.agent_contexts = {}

    @abc.abstractmethod
    def context_user_info(self) -> str:
        """Returns a string with user information that can be used in the context of the agent. This can include information such as user preferences, user history, or any other relevant information about the user that can help the agent to generate a more personalized and accurate response."""
        ...

    @abc.abstractmethod
    def get_session_id(self) -> str:
        """Returns the session ID for the current question. The session ID is a unique identifier that is shared across all questions and interactions that belong to the same session. This can be used to group related interactions together, and to keep track of the conversation history in a coherent way."""
        ...

    @abc.abstractmethod
    def get_agent_id(self) -> str:
        """Returns the agent ID for the current question. The agent ID is a unique identifier that is shared across all questions and interactions that belong to the same agent. This can be used to group related interactions together, and to keep track of the conversation history in a coherent way."""
        ...

    @abc.abstractmethod
    def get_workflow_id(self) -> str:
        """Returns the workflow ID for the current question. The workflow ID is a unique identifier that is shared across all questions and interactions that belong to the same workflow. This can be used to group related interactions together, and to keep track of the conversation history in a coherent way."""
        ...

    @abc.abstractmethod
    def get_rules(self) -> list[Rule | str]:
        """Returns the rules for the current question. The rules are a unique identifier that is shared across all questions and interactions that belong to the same set of rules. This can be used to group related interactions together, and to keep track of the conversation history in a coherent way."""
        ...

    @abc.abstractmethod
    async def search_in_questions(
        self, question: str, all: bool = False
    ) -> KnowledgeboxFindResults:
        """Searches for similar questions in the conversation history. This can be used to find relevant information that has been previously discussed in the conversation, and to provide a more accurate and personalized response."""
        ...

    @abc.abstractmethod
    def user_info(self) -> Dict[str, str]:
        """Returns a dictionary with user information that can be used in the context of the agent. This can include information such as user preferences, user history, or any other relevant information about the user that can help the agent to generate a more personalized and accurate response."""
        ...

    @abc.abstractmethod
    async def set_session_source(self, source: Source):
        """Sets the source of the session. This can be used to keep track of where the information in the conversation is coming from, and to provide more context to the agent when generating a response."""
        ...

    @abc.abstractmethod
    async def get_session_source(self, source_id: str) -> Optional[Source]:
        """Gets the source of the session. This can be used to keep track of where the information in the conversation is coming from, and to provide more context to the agent when generating a response."""
        ...

    @abc.abstractmethod
    async def context_history(self) -> tuple[str, int]:
        """Returns a string with the context history of the conversation. This can include information such as previous questions and answers, previous interactions, or any other relevant information about the conversation history that can help the agent to generate a more accurate and personalized response. The integer returned is the token count of the context history."""
        ...

    @abc.abstractmethod
    async def get_chat_history(self) -> list[Message]:
        """Returns a list of tuples with the chat history of the conversation. Each tuple contains a question and an answer. This can be used to keep track of the conversation history in a more structured way, and to provide more context to the agent when generating a response."""
        ...

    @abc.abstractmethod
    async def save_context(self, flow_id: str, context: Context): ...

    @abc.abstractmethod
    async def save_image_urls(self, image_urls: list[str]): ...

    @abc.abstractmethod
    def get_agent_contexts(self, flow_id: str, agent_id: str) -> list[Context]:
        """Returns a list of contexts for the given agent and flow."""
        ...

    @abc.abstractmethod
    def get_agent_answer_summaries(self, flow_id: str, agent_id: str) -> list[str]:
        """Returns a list of answer summaries for the given agent and flow. If an answer summary is not available, it should return the full context text as a fallback."""
        ...

    @abc.abstractmethod
    def list_contexts_markdown(self) -> list[str]:
        """Returns a list of contexts in markdown format, including summaries if available, otherwise full context (i.e: the chunk texts)"""
        ...

    @abc.abstractmethod
    def list_chunks_markdown(self) -> list[str]:
        """Returns a list of contexts broken down purely by individual chunks in markdown format."""
        ...

    @abc.abstractmethod
    def contexts_markdown(self) -> str:
        """
        Returns the concatenated contexts as a single string. Includes full context (i.e: all the chunk texts)
        """
        ...

    @abc.abstractmethod
    def list_contexts_minimal(
        self,
    ) -> list[str]:
        """
        Returns a list of minimal contexts. Minimal contexts include summaries if available, otherwise full context (i.e: the chunk texts)
        """
        ...

    @abc.abstractmethod
    def contexts_minimal(self) -> str:
        """
        Returns the concatenated minimal contexts as a single string.
        Minimal contexts include summaries if available, otherwise full context (i.e: the chunk texts)
        """

    @abc.abstractmethod
    def get_prompt_texts(self) -> list[str]:
        """Returns the rendered prompt texts for all contexts."""
        ...

    @abc.abstractmethod
    async def add_generated_text(self, generation_id: str, generated_text: str):
        """Saves generated text (e.g: LLM output) to the memory, associated with a generation_id."""
        ...

    @abc.abstractmethod
    async def add_step(
        self,
        step_module: str,
        step_title: str,
        step_agent_path: str,
        timeit: float,
        input_nuclia_tokens: Optional[float] = None,
        output_nuclia_tokens: Optional[float] = None,
        step_value: Optional[str] = None,
        step_reason: Optional[str] = None,
        error: Optional[str] = None,
    ):
        """Saves an intermediate step to the memory, associated with the current question. This can be used to keep track of the agent's reasoning process, and to provide more detailed information in the final answer if needed."""
        ...

    @abc.abstractmethod
    def set_actual_question(self, question: str, uuid: Optional[str] = None):
        """Sets the actual question for the current context."""
        ...

    @abc.abstractmethod
    def add_future_questions(self, questions: List[str]):
        """Adds future questions to the memory, associated with the current question."""
        ...

    @abc.abstractmethod
    def add_context_questions(self, questions: list[str]):
        """Adds context questions to the memory, associated with the current question. Context questions are questions that are generated by the agent in order to gather more information to answer the actual question. They are different from future questions, which are questions that are generated by the agent as potential follow-up questions after answering the actual question."""
        ...

    @abc.abstractmethod
    def get_questions(self) -> list[tuple[str, str]]:
        """Returns  context questions if they exist, otherwise returns the original question."""
        ...

    @abc.abstractmethod
    async def add_answer(
        self,
        answer: str,
        module: str,
        agent_path: str,
        citations: Optional[AnswerCitations] = None,
        visualization: Visualization | None = None,
        chunks: Optional[list[Chunk]] = None,
        structured: Optional[list[str]] = None,
        images: Optional[Dict[str, Image]] = None,
        image_urls: Optional[list[str]] = None,
    ): ...

    @abc.abstractmethod
    async def add_final_answer(self):
        """Saves the final answer to the memory. This should be called after the agent has generated the final answer, and it can be used to keep track of the final answer in the memory, and to provide more detailed information in the final answer if needed."""

    @abc.abstractmethod
    async def send_final_answer(self):
        """Sends the final answer to the user. This should be called after add_final_answer, and it can be used to trigger any callbacks or notifications that are needed to send the final answer to the user."""
        ...

    @abc.abstractmethod
    async def send_oauth(self, oauth: "OAuthAuthenticateURL") -> None:
        """Sends an OAuth authentication request to the user."""
        ...

    @abc.abstractmethod
    async def send_feedback(
        self, feedback: "Feedback"
    ) -> Optional["UserToAgentInteraction"]:
        """Sends feedback request to the user, and returns the user response if applicable."""
        ...

    @abc.abstractmethod
    async def recv_oauth_callback(
        self, question_id: str, oauth_uuid: str
    ) -> Optional[str]:
        """Receive OAuth callback credentials."""
        ...

    @abc.abstractmethod
    async def save(self):
        """Saves the memory to a persistent storage. This should be called after the agent has finished processing the question, and it can be used to keep track of the memory in a database or any other persistent storage."""
        ...
