import json
from typing import Any, Dict, List, Optional, Tuple

from nuclia.lib.nua import AsyncNuaClient
from nuclia.lib.nua_responses import (
    ChatModel,
    Image,
    Message,
    RerankModel,
    RerankResponse,
    Tokens,
    UserPrompt,
)
from nuclia_models.predict.generative_responses import GenerativeFullResponse
from nuclia_models.predict.remi import RemiRequest, RemiResponse
from pydantic_core import ErrorDetails, ValidationError

from rao_agent.configure import get_driver_klass
from rao_agent.driver import Driver, DriverConfig


def convert_errors(e: ValidationError):
    new_errors: list[ErrorDetails] = e.errors()
    for error in new_errors:
        print(json.dumps(error, indent=1))


class Manager:
    drivers: Dict[str, Driver]
    nua: AsyncNuaClient

    def __init__(self) -> None:
        self.drivers: Dict[str, Driver] = {}

    @classmethod
    async def from_config(
        cls,
        drivers: List[DriverConfig],
        nua: AsyncNuaClient,
    ):
        manager = cls()

        manager.nua = nua
        for driver in drivers:
            driver_class = get_driver_klass(
                driver.provider
            )  # Check if driver provider is valid
            manager.drivers[driver.identifier] = await driver_class.init(driver)

        return manager

    def nucliadbs(self) -> list[str]:
        result = []
        for key, value in self.drivers.items():
            if value.provider == "nucliadb":
                result.append(key)
        return result

    async def rerank(self, rerank: RerankModel) -> RerankResponse:
        return await self.nua.rerank(rerank)

    async def tokens_predict(self, text: str, model: str) -> Tokens:
        return await self.nua.tokens_predict(text=text, model=model)

    async def remi(
        self, question: str | None, answer: str | None, contexts: List[str] | None
    ) -> RemiResponse:
        # Evaluate if we answered
        remi_response = await self.nua.remi(
            RemiRequest(
                user_id="arag_evaluate",
                question=question,
                answer=answer,
                contexts=contexts,
            )
        )
        return remi_response

    async def execute_raw(
        self, item: ChatModel
    ) -> Tuple[GenerativeFullResponse, float, float]:
        try:
            resp = await self.nua.generate(
                body=item,
                extra_headers={"x-show-consumption": "true", "x-origin": "RAO"},
            )
        except ValidationError as e:
            convert_errors(e)
            raise

        if resp.answer is None:
            raise Exception("No object")

        if resp.consumption is None or resp.consumption.normalized_tokens is None:
            input_tokens = 0.0
            output_tokens = 0.0
        else:
            input_tokens = resp.consumption.normalized_tokens.input
            output_tokens = resp.consumption.normalized_tokens.output
        return (
            resp,
            input_tokens,
            output_tokens,
        )

    async def execute(
        self,
        prompt: str,
        user_id: str,
        model: str,
        query_context_images: Dict[str, Image] = {},
        system: Optional[str] = None,
        max_tokens: int = 2000,
        chat_history: List[Message] = [],
    ) -> Tuple[str, float, float, str | None]:
        try:
            resp = await self.nua.generate(
                body=ChatModel(
                    system=system,
                    user_id=user_id,
                    question="",
                    user_prompt=UserPrompt(prompt=prompt),
                    format_prompt=False,
                    generative_model=model,
                    query_context_images=query_context_images,
                    max_tokens=max_tokens,
                    chat_history=chat_history,
                ),
                extra_headers={"x-show-consumption": "true", "x-origin": "RAO"},
            )
        except ValidationError as e:
            convert_errors(e)
            raise

        if resp is None or resp.answer is None:
            raise Exception("No object")
        if resp.consumption is None or resp.consumption.normalized_tokens is None:
            input_tokens = 0.0
            output_tokens = 0.0
        else:
            input_tokens = resp.consumption.normalized_tokens.input
            output_tokens = resp.consumption.normalized_tokens.output
        return (
            resp.answer,
            input_tokens,
            output_tokens,
            resp.code,
        )

    async def execute_from_context(
        self,
        prompt: str,
        user_id: str,
        model: str,
        images: Dict[str, Image],
        system: Optional[str] = None,
    ) -> Tuple[str, float, float]:
        try:
            resp = await self.nua.generate(
                body=ChatModel(
                    question="",
                    user_id=user_id,
                    user_prompt=UserPrompt(prompt=prompt),
                    format_prompt=False,
                    generative_model=model,
                    query_context_images=images,
                    system=system,
                ),
                extra_headers={"x-show-consumption": "true", "x-origin": "RAO"},
            )
        except ValidationError as e:
            convert_errors(e)
            raise

        if resp.answer is None:
            raise Exception("No object")
        if resp.consumption is None or resp.consumption.normalized_tokens is None:
            input_tokens = 0.0
            output_tokens = 0.0
        else:
            input_tokens = resp.consumption.normalized_tokens.input
            output_tokens = resp.consumption.normalized_tokens.output

        return (
            resp.answer,
            input_tokens,
            output_tokens,
        )

    async def execute_json(
        self,
        prompt: str,
        user_id: str,
        schema: Dict[str, Any],
        model: str,
        images: Dict[str, Image] = {},
        system: Optional[str] = None,
        max_tokens: int = 2000,
    ) -> Tuple[Dict[str, Any], float, float]:
        try:
            resp = await self.nua.generate(
                body=ChatModel(
                    user_id=user_id,
                    question="",
                    user_prompt=UserPrompt(prompt=prompt),
                    generative_model=model,
                    format_prompt=False,
                    query_context_images=images,
                    json_schema=schema,
                    system=system,
                    max_tokens=max_tokens,
                    citations=False,
                ),
                extra_headers={"x-show-consumption": "true", "x-origin": "RAO"},
            )

        except ValidationError as e:
            convert_errors(e)
            raise

        if resp.object is None:
            raise Exception("No object")

        if resp.consumption is None or resp.consumption.normalized_tokens is None:
            input_tokens = 0.0
            output_tokens = 0.0
        else:
            input_tokens = resp.consumption.normalized_tokens.input
            output_tokens = resp.consumption.normalized_tokens.output

        return (
            resp.object,
            input_tokens,
            output_tokens,
        )

    async def execute_json_citation(
        self,
        question: str,
        user_id: str,
        schema: Dict[str, Any],
        model: str,
        contexts: List[str] = [],
        images: Dict[str, Image] = {},
        system: Optional[str] = None,
    ) -> Tuple[Dict[str, Any], float, float, Dict[str, Any] | None]:
        try:
            resp = await self.nua.generate(
                body=ChatModel(
                    user_id=user_id,
                    question=question,
                    query_context=contexts,
                    generative_model=model,
                    format_prompt=True,
                    query_context_images=images,
                    json_schema=schema,
                    system=system,
                    max_tokens=2000,
                    citations=True,
                ),
                extra_headers={"x-show-consumption": "true", "x-origin": "RAO"},
            )

        except ValidationError as e:
            convert_errors(e)
            raise

        if resp.object is None:
            raise Exception("No object")

        if resp.consumption is None or resp.consumption.normalized_tokens is None:
            input_tokens = 0.0
            output_tokens = 0.0
        else:
            input_tokens = resp.consumption.normalized_tokens.input
            output_tokens = resp.consumption.normalized_tokens.output

        return (
            resp.object,
            input_tokens,
            output_tokens,
            resp.citations,
        )
