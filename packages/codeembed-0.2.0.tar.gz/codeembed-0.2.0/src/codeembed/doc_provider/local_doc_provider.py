import os
import subprocess
from datetime import datetime, timezone
from typing import Iterator, List

from codeembed.doc_provider.base import DocProviderBase
from codeembed.doc_provider.models import DocumentContent, DocumentMeta

_SKIP_DIRS = frozenset({"venv", ".venv", "node_modules", "dist", "build", "tests"})
_SKIP_FILES = frozenset({"__init__.py", ".env", ".env.local", "appsettings.json", "appsettings.Development.json"})


def _get_git_files(base_path: str) -> set[str]:
    result = subprocess.run(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard"],
        cwd=base_path,
        capture_output=True,
        text=True,
    )
    return set(result.stdout.splitlines())


class LocalDocProvider(DocProviderBase):
    def __init__(self, base_path: str, supported_file_extensions: List[str]) -> None:
        self._base_path = base_path
        self._supported_file_extensions = [ext.lower().split(".")[-1] for ext in supported_file_extensions]

    def iter(self) -> Iterator[DocumentMeta]:

        file_paths = _get_git_files(self._base_path)

        docs: List[DocumentMeta] = []
        for file_path in file_paths:
            ext = file_path.split(".")[-1]
            if ext.lower() not in self._supported_file_extensions:
                continue

            parts = file_path.split("/")
            if parts[-1] in _SKIP_FILES or any(d in _SKIP_DIRS for d in parts[:-1]):
                continue

            try:
                modified_ts = os.path.getmtime(file_path)
                modified_at = datetime.fromtimestamp(modified_ts, tz=timezone.utc)
            except OSError:
                continue

            docs.append(DocumentMeta(file_path=file_path, modified_at=modified_at))

        docs.sort(key=lambda d: d.modified_at, reverse=True)
        yield from docs

    def get_content(self, file_path: str) -> DocumentContent:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
        modified_ts = os.path.getmtime(file_path)
        modified_at = datetime.fromtimestamp(modified_ts, tz=timezone.utc)
        return DocumentContent(content=content, modified_at=modified_at)
