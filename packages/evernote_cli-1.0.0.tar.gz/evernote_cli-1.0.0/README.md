# Evernote CLI

Agent-first Python CLI for Evernote Cloud API (EDAM) with JSON output and explicit error codes.

## Installation

```bash
pip install -e .
```

## Quick Start

```bash
export EVERNOTE_AUTH_TOKEN=your_token
evernote account info
```

## Documentation

- [Agent Guide](docs/AGENT_GUIDE.md) - For AI agents
- [User Guide](docs/USER_GUIDE.md) - For humans
- [API Reference](docs/API_REFERENCE.md) - Command reference
