import os
from dataclasses import dataclass
from typing import Optional


@dataclass
class AuthManager:
    """Manages Evernote authentication (token, sandbox/prod, service host)."""
    token: str
    sandbox: bool = False

    @property
    def service_host(self) -> str:
        """Return appropriate service host for sandbox or production."""
        return "sandbox.evernote.com" if self.sandbox else "api.evernote.com"

    @classmethod
    def from_env(cls) -> "AuthManager":
        """Load auth from environment variables."""
        token = os.getenv("EVERNOTE_AUTH_TOKEN")
        if not token:
            raise ValueError(
                "EVERNOTE_AUTH_TOKEN environment variable is required. "
                "Get a token from https://dev.evernote.com"
            )

        sandbox = os.getenv("EVERNOTE_SANDBOX", "false").lower() == "true"
        return cls(token=token, sandbox=sandbox)
