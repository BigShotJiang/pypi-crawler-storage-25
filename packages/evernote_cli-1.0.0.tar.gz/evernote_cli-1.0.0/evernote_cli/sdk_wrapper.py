import os
from evernote.api.client import EvernoteClient
from evernote_cli.auth import AuthManager


class EvernoteSDKWrapper:
    """Wraps Evernote SDK with retry logic and error handling."""

    def __init__(self, auth: AuthManager):
        self.auth = auth
        self.client = EvernoteClient(
            consumer_key=os.getenv("EVERNOTE_CONSUMER_KEY", "YOUR_CONSUMER_KEY"),
            consumer_secret=os.getenv("EVERNOTE_CONSUMER_SECRET", "YOUR_CONSUMER_SECRET"),
            sandbox=auth.sandbox,
            service_host=auth.service_host
        )
        # Use direct token auth (not OAuth flow)
        self.client.token = auth.token

    def get_note_store(self):
        """Get NoteStore for note operations."""
        return self.client.get_note_store()

    def get_user_store(self):
        """Get UserStore for account operations."""
        return self.client.get_user_store()
