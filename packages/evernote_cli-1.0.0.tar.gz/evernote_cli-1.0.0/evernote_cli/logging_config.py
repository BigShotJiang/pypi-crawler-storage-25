import os
import sys
import json
import logging
from datetime import datetime
import structlog


def setup_logging():
    """Configure structured JSON logging to stderr."""
    log_level = os.getenv("EVERNOTE_LOG_LEVEL", "INFO").upper()

    # Set up root logger first
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)

    # Remove default handlers
    root_logger.handlers = []

    # Add stderr handler
    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(log_level)

    # Configure structlog with stdlib integration
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer()
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    # Set a plain formatter that just passes through the message
    # (structlog already formats as JSON)
    formatter = logging.Formatter(fmt='%(message)s')
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)

    # Return the root logger (which has been configured with structlog)
    return root_logger
