"""Click CLI for Evernote operations."""
import json
import sys
import click
from evernote_cli.logging_config import setup_logging
from evernote_cli.auth import AuthManager
from evernote_cli.commands.note import NoteCommands
from evernote_cli.commands.notebook import NotebookCommands
from evernote_cli.commands.tag import TagCommands
from evernote_cli.commands.search import SearchCommands
from evernote_cli.commands.account import AccountCommands
from evernote_cli.errors import get_exit_code, ErrorCode

# Configure logging at module level
setup_logging()


def output_response(response):
    """Output response as JSON and handle errors."""
    click.echo(json.dumps(response))
    if not response.get("success", False):
        error_code = response.get("error", {}).get("code")
        if error_code:
            try:
                exit_code = get_exit_code(ErrorCode[error_code])
                sys.exit(exit_code)
            except (KeyError, ValueError):
                sys.exit(1)
        else:
            sys.exit(1)


@click.group(invoke_without_command=True)
@click.version_option(version="1.0.0", prog_name="evernote-cli")
@click.pass_context
def main(ctx):
    """Evernote CLI - Manage notes, notebooks, tags, and more."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ============================================================================
# NOTE GROUP
# ============================================================================

@main.group()
def note():
    """Note operations."""
    pass


@note.command("create")
@click.option("--title", required=True, help="Note title")
@click.option("--notebook", required=True, help="Notebook name")
@click.option("--content-text", default=None, help="Note content as text")
@click.option("--content-file", default=None, help="Path to file with note content")
@click.option("--tags", default=None, help="Comma-separated tags")
def note_create(title, notebook, content_text, content_file, tags):
    """Create a new note."""
    auth = AuthManager.from_env()
    cmd = NoteCommands(auth=auth)

    tags_list = [t.strip() for t in tags.split(',')] if tags else []
    response = cmd.create(
        title=title,
        notebook=notebook,
        content_text=content_text,
        content_file=content_file,
        tags=tags_list
    )
    output_response(response)


@note.command("get")
@click.argument("guid")
def note_get(guid):
    """Get note details."""
    auth = AuthManager.from_env()
    cmd = NoteCommands(auth=auth)
    response = cmd.get(guid)
    output_response(response)


@note.command("update")
@click.argument("guid")
@click.option("--title", default=None, help="New title")
@click.option("--content-text", default=None, help="New content as text")
@click.option("--content-file", default=None, help="Path to file with new content")
@click.option("--tags", default=None, help="Comma-separated tags")
@click.option("--if-usn", type=int, default=None, help="Update only if USN matches")
def note_update(guid, title, content_text, content_file, tags, if_usn):
    """Update a note."""
    auth = AuthManager.from_env()
    cmd = NoteCommands(auth=auth)

    tags_list = [t.strip() for t in tags.split(',')] if tags else None
    response = cmd.update(
        guid=guid,
        title=title,
        content_text=content_text,
        content_file=content_file,
        tags=tags_list,
        if_usn=if_usn
    )
    output_response(response)


@note.command("delete")
@click.argument("guid")
@click.option("--force", is_flag=True, help="Confirm deletion")
def note_delete(guid, force):
    """Delete a note."""
    auth = AuthManager.from_env()
    cmd = NoteCommands(auth=auth)
    response = cmd.delete(guid, force=force)
    output_response(response)


@note.command("list")
@click.option("--notebook", default=None, help="Filter by notebook name")
@click.option("--tag", default=None, help="Filter by tag")
@click.option("--since", type=int, default=None, help="Created after timestamp")
@click.option("--until", type=int, default=None, help="Created before timestamp")
@click.option("--limit", type=int, default=50, help="Max results")
@click.option("--offset", type=int, default=0, help="Result offset")
@click.option("--sort-by", default="updated", help="Sort field (updated, created)")
def note_list(notebook, tag, since, until, limit, offset, sort_by):
    """List notes."""
    auth = AuthManager.from_env()
    cmd = NoteCommands(auth=auth)
    response = cmd.list(
        notebook=notebook,
        tag=tag,
        since=since,
        until=until,
        limit=limit,
        offset=offset,
        sort_by=sort_by
    )
    output_response(response)


@note.command("tag-add")
@click.argument("guid")
@click.option("--tag", required=True, help="Tag name to add")
def note_tag_add(guid, tag):
    """Add a tag to a note."""
    auth = AuthManager.from_env()
    cmd = NoteCommands(auth=auth)
    response = cmd.tag_add(guid, tag)
    output_response(response)


@note.command("tag-remove")
@click.argument("guid")
@click.option("--tag", required=True, help="Tag name to remove")
def note_tag_remove(guid, tag):
    """Remove a tag from a note."""
    auth = AuthManager.from_env()
    cmd = NoteCommands(auth=auth)
    response = cmd.tag_remove(guid, tag)
    output_response(response)


@note.command("move")
@click.argument("guid")
@click.option("--notebook", required=True, help="Target notebook name")
def note_move(guid, notebook):
    """Move a note to another notebook."""
    auth = AuthManager.from_env()
    cmd = NoteCommands(auth=auth)
    response = cmd.move(guid, notebook)
    output_response(response)


# ============================================================================
# NOTEBOOK GROUP
# ============================================================================

@main.group()
def notebook():
    """Notebook operations."""
    pass


@notebook.command("create")
@click.option("--name", required=True, help="Notebook name")
def notebook_create(name):
    """Create a new notebook."""
    auth = AuthManager.from_env()
    cmd = NotebookCommands(auth=auth)
    response = cmd.create(name)
    output_response(response)


@notebook.command("list")
def notebook_list():
    """List all notebooks."""
    auth = AuthManager.from_env()
    cmd = NotebookCommands(auth=auth)
    response = cmd.list()
    output_response(response)


@notebook.command("delete")
@click.argument("guid")
@click.option("--force", is_flag=True, help="Confirm deletion")
def notebook_delete(guid, force):
    """Delete a notebook."""
    auth = AuthManager.from_env()
    cmd = NotebookCommands(auth=auth)
    response = cmd.delete(guid, force=force)
    output_response(response)


@notebook.command("rename")
@click.argument("guid")
@click.option("--name", required=True, help="New notebook name")
def notebook_rename(guid, name):
    """Rename a notebook."""
    auth = AuthManager.from_env()
    cmd = NotebookCommands(auth=auth)
    response = cmd.rename(guid, name)
    output_response(response)


# ============================================================================
# TAG GROUP
# ============================================================================

@main.group()
def tag():
    """Tag operations."""
    pass


@tag.command("create")
@click.option("--name", required=True, help="Tag name")
def tag_create(name):
    """Create a new tag."""
    auth = AuthManager.from_env()
    cmd = TagCommands(auth=auth)
    response = cmd.create(name)
    output_response(response)


@tag.command("list")
def tag_list():
    """List all tags."""
    auth = AuthManager.from_env()
    cmd = TagCommands(auth=auth)
    response = cmd.list()
    output_response(response)


@tag.command("delete")
@click.argument("guid")
def tag_delete(guid):
    """Delete a tag."""
    auth = AuthManager.from_env()
    cmd = TagCommands(auth=auth)
    response = cmd.delete(guid)
    output_response(response)


@tag.command("rename")
@click.argument("guid")
@click.option("--name", required=True, help="New tag name")
def tag_rename(guid, name):
    """Rename a tag."""
    auth = AuthManager.from_env()
    cmd = TagCommands(auth=auth)
    response = cmd.rename(guid, name)
    output_response(response)


# ============================================================================
# SEARCH (TOP-LEVEL)
# ============================================================================

@main.command("search")
@click.argument("query")
@click.option("--notebook", default=None, help="Filter by notebook name")
@click.option("--tag", default=None, help="Filter by tag")
@click.option("--limit", type=int, default=50, help="Max results")
@click.option("--offset", type=int, default=0, help="Result offset")
def search(query, notebook, tag, limit, offset):
    """Search notes."""
    auth = AuthManager.from_env()
    cmd = SearchCommands(auth=auth)
    response = cmd.search(
        query=query,
        notebook=notebook,
        tag=tag,
        limit=limit,
        offset=offset
    )
    output_response(response)


# ============================================================================
# ACCOUNT GROUP
# ============================================================================

@main.group()
def account():
    """Account operations."""
    pass


@account.command("info")
def account_info():
    """Get account information."""
    auth = AuthManager.from_env()
    cmd = AccountCommands(auth=auth)
    response = cmd.info()
    output_response(response)


if __name__ == "__main__":
    main()
