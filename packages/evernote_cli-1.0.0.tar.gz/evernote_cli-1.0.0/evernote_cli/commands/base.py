import logging
from typing import Optional
from evernote_cli.auth import AuthManager
from evernote_cli.sdk_wrapper import EvernoteSDKWrapper

logger = logging.getLogger(__name__)


class BaseCommand:
    """Base class for all commands."""

    def __init__(self, auth: AuthManager):
        self.auth = auth
        self.sdk = EvernoteSDKWrapper(auth)
        self.note_store = self.sdk.get_note_store()
        self.user_store = self.sdk.get_user_store()
