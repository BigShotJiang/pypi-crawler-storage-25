import logging
from typing import Dict, Any
from evernote_cli.commands.base import BaseCommand
from evernote_cli.adapter import ResponseAdapter
from evernote_cli.errors import ErrorCode

logger = logging.getLogger(__name__)


class AccountCommands(BaseCommand):
    """Account operations."""

    def info(self) -> Dict[str, Any]:
        """Get account information."""
        try:
            user = self.user_store.getUser()

            return ResponseAdapter.success("account.info", {
                "username": user.username,
                "email": user.email if hasattr(user, 'email') else None,
                "serviceLevel": user.privilege if hasattr(user, 'privilege') else None,
                "sandbox": self.auth.sandbox
            })

        except Exception as e:
            logger.exception("account_info_error")
            return ResponseAdapter.error("account.info", ErrorCode.INTERNAL_ERROR, str(e))
