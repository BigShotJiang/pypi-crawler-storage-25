import logging
from typing import List, Optional, Dict, Any
from evernote.edam.type.ttypes import Note as EDAMNote
from evernote.edam.error.ttypes import EDAMUserException
from evernote.edam.notestore.ttypes import NoteFilter, NotesMetadataResultSpec
from evernote_cli.commands.base import BaseCommand
from evernote_cli.adapter import ResponseAdapter
from evernote_cli.errors import (
    ErrorCode, EvernoteCliError, NotebookNotFoundError
)
from evernote_cli.content_converter import ContentConverter

logger = logging.getLogger(__name__)


class NoteCommands(BaseCommand):
    """Note CRUD operations."""

    def __init__(self, auth, note_store=None):
        super().__init__(auth)
        self.note_store = note_store or self.note_store
        self.converter = ContentConverter()

    def create(
        self,
        title: str,
        notebook: str,
        content_text: Optional[str] = None,
        content_file: Optional[str] = None,
        tags: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Create a new note."""
        try:
            # Convert content
            content = content_text or ""
            if content_file:
                with open(content_file, 'r') as f:
                    content = f.read()

            enml = self.converter.markdown_to_enml(content)

            # Get notebook GUID
            notebook_guid = self._get_notebook_guid(notebook)

            # Create EDAM note
            edam_note = EDAMNote()
            edam_note.title = title
            edam_note.content = enml
            edam_note.notebookGuid = notebook_guid
            edam_note.tagNames = tags or []

            # Submit to Evernote
            created_note = self.note_store.createNote(edam_note)

            logger.info("note_created", extra={"guid": created_note.guid, "title": title})

            return ResponseAdapter.success("note.create", {
                "guid": created_note.guid,
                "title": created_note.title,
                "notebookGuid": created_note.notebookGuid,
                "notebookName": notebook,
                "tags": created_note.tagNames or [],
                "created": created_note.created,
                "updated": created_note.updated,
                "updateSequenceNumber": created_note.updateSequenceNumber,
                "contentLength": len(enml)
            })

        except NotebookNotFoundError as e:
            logger.warning("notebook_not_found", extra={"notebook": notebook})
            return ResponseAdapter.error(
                "note.create",
                e.code,
                e.message,
                e.details
            )
        except EDAMUserException as e:
            return self._handle_edam_error("note.create", e)
        except Exception as e:
            logger.exception("note_create_error", extra={"title": title})
            return ResponseAdapter.error(
                "note.create",
                ErrorCode.INTERNAL_ERROR,
                str(e)
            )

    def get(self, guid: str) -> Dict[str, Any]:
        """Get note details."""
        try:
            note = self.note_store.getNote(guid, True, True, False, False)
            plaintext = self.converter.enml_to_plaintext(note.content)

            return ResponseAdapter.success("note.get", {
                "guid": note.guid,
                "title": note.title,
                "contentPlainText": plaintext,
                "notebookGuid": note.notebookGuid,
                "tags": note.tagNames or [],
                "created": note.created,
                "updated": note.updated,
                "updateSequenceNumber": note.updateSequenceNumber,
                "contentLength": len(note.content)
            })

        except EDAMUserException as e:
            return self._handle_edam_error("note.get", e)
        except Exception as e:
            logger.exception("note_get_error", extra={"guid": guid})
            return ResponseAdapter.error("note.get", ErrorCode.INTERNAL_ERROR, str(e))

    def _get_notebook_guid(self, notebook_name: str) -> str:
        """Get notebook GUID by name."""
        notebooks = self.note_store.listNotebooks()
        for nb in notebooks:
            if nb.name == notebook_name:
                return nb.guid

        available = [nb.name for nb in notebooks]
        raise NotebookNotFoundError(notebook_name, available)

    def update(
        self,
        guid: str,
        title: Optional[str] = None,
        content_text: Optional[str] = None,
        content_file: Optional[str] = None,
        tags: Optional[List[str]] = None,
        if_usn: Optional[int] = None
    ) -> Dict[str, Any]:
        """Update note (with conflict detection via USN)."""
        try:
            # Fetch fresh note to check USN
            existing = self.note_store.getNote(guid, False, False, False, False)

            # Check for conflict if if_usn provided
            if if_usn is not None and existing.updateSequenceNumber != if_usn:
                return ResponseAdapter.error(
                    "note.update",
                    ErrorCode.CONFLICT,
                    "Note was edited by another agent (USN mismatch)",
                    details={
                        "expectedUsn": if_usn,
                        "currentUsn": existing.updateSequenceNumber
                    }
                )

            # Prepare update
            note_to_update = EDAMNote()
            note_to_update.guid = guid
            if title:
                note_to_update.title = title
            if content_text or content_file:
                content = content_text or ""
                if content_file:
                    with open(content_file, 'r') as f:
                        content = f.read()
                enml = self.converter.markdown_to_enml(content)
                note_to_update.content = enml
            if tags is not None:
                note_to_update.tagNames = tags

            # Submit update
            updated = self.note_store.updateNote(note_to_update)

            logger.info("note_updated", extra={"guid": guid, "title": updated.title})

            return ResponseAdapter.success("note.update", {
                "guid": updated.guid,
                "title": updated.title,
                "updateSequenceNumber": updated.updateSequenceNumber,
                "updated": updated.updated
            })

        except EDAMUserException as e:
            return self._handle_edam_error("note.update", e)
        except Exception as e:
            logger.exception("note_update_error", extra={"guid": guid})
            return ResponseAdapter.error("note.update", ErrorCode.INTERNAL_ERROR, str(e))

    def delete(self, guid: str, force: bool = False) -> Dict[str, Any]:
        """Delete note (soft delete by default)."""
        try:
            # Evernote API: deleteNote for soft delete
            self.note_store.deleteNote(guid)

            logger.info("note_deleted", extra={"guid": guid})

            return ResponseAdapter.success("note.delete", {
                "guid": guid,
                "deleted": True
            })

        except EDAMUserException as e:
            return self._handle_edam_error("note.delete", e)
        except Exception as e:
            logger.exception("note_delete_error", extra={"guid": guid})
            return ResponseAdapter.error("note.delete", ErrorCode.INTERNAL_ERROR, str(e))

    def list(
        self,
        notebook: Optional[str] = None,
        tag: Optional[str] = None,
        since: Optional[int] = None,
        until: Optional[int] = None,
        limit: int = 50,
        offset: int = 0,
        sort_by: str = "updated"
    ) -> Dict[str, Any]:
        """List notes with filtering and pagination."""
        try:
            # Build filter
            note_filter = NoteFilter()
            if notebook:
                nb_guid = self._get_notebook_guid(notebook)
                note_filter.notebookGuid = nb_guid
            if tag:
                note_filter.words = f"tag:{tag}"
            if since:
                note_filter.words = (note_filter.words or "") + f" created:{since}"
            if until:
                note_filter.words = (note_filter.words or "") + f" -created:{until}"

            # Sort mapping
            result_spec = NotesMetadataResultSpec()
            result_spec.includeTitle = True
            result_spec.includeTags = True
            result_spec.includeNotebookGuid = True
            result_spec.includeUpdated = True
            result_spec.includeCreated = True

            # Execute search
            result = self.note_store.findNotesMetadata(
                note_filter,
                offset,
                limit,
                result_spec
            )

            notes = [
                {
                    "guid": n.guid,
                    "title": n.title,
                    "tags": n.tagNames or [],
                    "notebookGuid": n.notebookGuid,
                    "created": n.created,
                    "updated": n.updated
                }
                for n in result.notes
            ]

            logger.info("notes_listed", extra={"count": len(notes), "total": result.totalNotes})

            return ResponseAdapter.success("note.list", {
                "notes": notes,
                "totalCount": result.totalNotes,
                "offset": offset,
                "limit": limit,
                "hasMore": offset + limit < result.totalNotes
            })

        except EDAMUserException as e:
            return self._handle_edam_error("note.list", e)
        except Exception as e:
            logger.exception("note_list_error")
            return ResponseAdapter.error("note.list", ErrorCode.INTERNAL_ERROR, str(e))

    def tag_add(self, guid: str, tag: str) -> Dict[str, Any]:
        """Add a tag to a note."""
        try:
            note = self.note_store.getNote(guid, False, False, False, False)

            # Add tag if not already present
            tags = set(note.tagNames or [])
            tags.add(tag)

            # Update note
            update = EDAMNote()
            update.guid = guid
            update.tagNames = list(tags)

            updated = self.note_store.updateNote(update)

            logger.info("note_tag_added", extra={"guid": guid, "tag": tag})

            return ResponseAdapter.success("note.tag_add", {
                "guid": updated.guid,
                "tags": updated.tagNames or []
            })

        except Exception as e:
            logger.exception("note_tag_add_error", extra={"guid": guid, "tag": tag})
            return ResponseAdapter.error("note.tag_add", ErrorCode.INTERNAL_ERROR, str(e))

    def tag_remove(self, guid: str, tag: str) -> Dict[str, Any]:
        """Remove a tag from a note."""
        try:
            note = self.note_store.getNote(guid, False, False, False, False)

            # Remove tag
            tags = set(note.tagNames or [])
            tags.discard(tag)

            # Update note
            update = EDAMNote()
            update.guid = guid
            update.tagNames = list(tags)

            updated = self.note_store.updateNote(update)

            logger.info("note_tag_removed", extra={"guid": guid, "tag": tag})

            return ResponseAdapter.success("note.tag_remove", {
                "guid": updated.guid,
                "tags": updated.tagNames or []
            })

        except Exception as e:
            logger.exception("note_tag_remove_error", extra={"guid": guid, "tag": tag})
            return ResponseAdapter.error("note.tag_remove", ErrorCode.INTERNAL_ERROR, str(e))

    def move(self, guid: str, notebook: str) -> Dict[str, Any]:
        """Move note to another notebook."""
        try:
            # Get target notebook GUID
            nb_guid = self._get_notebook_guid(notebook)

            # Update note
            update = EDAMNote()
            update.guid = guid
            update.notebookGuid = nb_guid

            updated = self.note_store.updateNote(update)

            logger.info("note_moved", extra={"guid": guid, "notebook": notebook})

            return ResponseAdapter.success("note.move", {
                "guid": updated.guid,
                "notebookGuid": updated.notebookGuid,
                "notebookName": notebook
            })

        except NotebookNotFoundError as e:
            logger.warning("notebook_not_found", extra={"notebook": notebook})
            return ResponseAdapter.error(
                "note.move",
                e.code,
                e.message,
                e.details
            )
        except EDAMUserException as e:
            return self._handle_edam_error("note.move", e)
        except Exception as e:
            logger.exception("note_move_error", extra={"guid": guid, "notebook": notebook})
            return ResponseAdapter.error("note.move", ErrorCode.INTERNAL_ERROR, str(e))

    def _handle_edam_error(self, command: str, error: EDAMUserException) -> Dict[str, Any]:
        """Handle Evernote EDAM errors."""
        if error.errorCode == 8:  # NOT_FOUND
            if "note" in (error.parameter or ""):
                code = ErrorCode.NOTE_NOT_FOUND
            else:
                code = ErrorCode.NOTEBOOK_NOT_FOUND
            return ResponseAdapter.error(
                command,
                code,
                f"Resource not found: {error.parameter}"
            )
        elif error.errorCode == 3:  # PERMISSION_DENIED
            return ResponseAdapter.error(
                command,
                ErrorCode.PERMISSION_DENIED,
                "Permission denied. Upgrade your account?"
            )
        else:
            return ResponseAdapter.error(
                command,
                ErrorCode.INTERNAL_ERROR,
                f"Evernote error: {error.errorMessage}"
            )
