import logging
from typing import Dict, Any
from evernote.edam.type.ttypes import Tag as EDAMTag
from evernote.edam.error.ttypes import EDAMUserException
from evernote_cli.commands.base import BaseCommand
from evernote_cli.adapter import ResponseAdapter
from evernote_cli.errors import ErrorCode

logger = logging.getLogger(__name__)


class TagCommands(BaseCommand):
    """Tag CRUD operations."""

    def create(self, name: str) -> Dict[str, Any]:
        """Create a new tag."""
        try:
            tag = EDAMTag()
            tag.name = name

            created = self.note_store.createTag(tag)

            logger.info("tag_created", extra={"guid": created.guid, "tag_name": name})

            return ResponseAdapter.success("tag.create", {
                "guid": created.guid,
                "name": created.name,
                "created": created.created
            })

        except Exception as e:
            logger.exception("tag_create_error", extra={"tag_name": name})
            return ResponseAdapter.error("tag.create", ErrorCode.INTERNAL_ERROR, str(e))

    def list(self) -> Dict[str, Any]:
        """List all tags."""
        try:
            tags_data = self.note_store.listTags()

            tags = [
                {
                    "guid": t.guid,
                    "name": t.name,
                    "created": t.created,
                    "updated": t.updated if hasattr(t, 'updated') else t.created,
                    "noteCount": 0  # Evernote API doesn't provide this in list
                }
                for t in tags_data
            ]

            logger.info("tags_listed", extra={"count": len(tags)})

            return ResponseAdapter.success("tag.list", {
                "tags": tags
            })

        except Exception as e:
            logger.exception("tag_list_error")
            return ResponseAdapter.error("tag.list", ErrorCode.INTERNAL_ERROR, str(e))

    def delete(self, guid: str) -> Dict[str, Any]:
        """Delete tag."""
        try:
            self.note_store.expungeTag(guid)

            logger.info("tag_deleted", extra={"guid": guid})

            return ResponseAdapter.success("tag.delete", {
                "guid": guid,
                "deleted": True
            })

        except Exception as e:
            logger.exception("tag_delete_error", extra={"guid": guid})
            return ResponseAdapter.error("tag.delete", ErrorCode.INTERNAL_ERROR, str(e))

    def rename(self, guid: str, new_name: str) -> Dict[str, Any]:
        """Rename tag."""
        try:
            tag = EDAMTag()
            tag.guid = guid
            tag.name = new_name

            self.note_store.updateTag(tag)

            logger.info("tag_renamed", extra={"guid": guid, "new_name": new_name})

            return ResponseAdapter.success("tag.rename", {
                "guid": guid,
                "name": new_name
            })

        except Exception as e:
            logger.exception("tag_rename_error", extra={"guid": guid, "new_name": new_name})
            return ResponseAdapter.error("tag.rename", ErrorCode.INTERNAL_ERROR, str(e))
