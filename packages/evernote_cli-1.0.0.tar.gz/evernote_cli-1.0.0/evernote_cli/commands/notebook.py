import logging
from typing import Dict, Any
from evernote.edam.type.ttypes import Notebook as EDAMNotebook
from evernote.edam.error.ttypes import EDAMUserException
from evernote_cli.commands.base import BaseCommand
from evernote_cli.adapter import ResponseAdapter
from evernote_cli.errors import ErrorCode

logger = logging.getLogger(__name__)


class NotebookCommands(BaseCommand):
    """Notebook CRUD operations."""

    def create(self, name: str) -> Dict[str, Any]:
        """Create a new notebook."""
        try:
            notebook = EDAMNotebook()
            notebook.name = name

            created = self.note_store.createNotebook(notebook)

            logger.info("notebook_created", extra={"guid": created.guid, "notebook_name": name})

            return ResponseAdapter.success("notebook.create", {
                "guid": created.guid,
                "name": created.name,
                "created": created.created
            })

        except EDAMUserException as e:
            if "duplicate" in str(e).lower():
                return ResponseAdapter.error(
                    "notebook.create",
                    ErrorCode.DUPLICATE_NOTEBOOK_NAME,
                    f"Notebook '{name}' already exists"
                )
            return self._handle_edam_error("notebook.create", e)
        except Exception as e:
            logger.exception("notebook_create_error", extra={"notebook_name": name})
            return ResponseAdapter.error("notebook.create", ErrorCode.INTERNAL_ERROR, str(e))

    def list(self) -> Dict[str, Any]:
        """List all notebooks."""
        try:
            notebooks_data = self.note_store.listNotebooks()

            notebooks = []
            for nb in notebooks_data:
                note_count = 0
                try:
                    if hasattr(nb, 'notes') and nb.notes is not None:
                        note_count = len(nb.notes)
                except (TypeError, AttributeError):
                    note_count = 0

                notebooks.append({
                    "guid": nb.guid,
                    "name": nb.name,
                    "created": nb.created,
                    "updated": nb.updated if hasattr(nb, 'updated') else nb.created,
                    "noteCount": note_count
                })

            logger.info("notebooks_listed", extra={"count": len(notebooks)})

            return ResponseAdapter.success("notebook.list", {
                "notebooks": notebooks
            })

        except Exception as e:
            logger.exception("notebook_list_error")
            return ResponseAdapter.error("notebook.list", ErrorCode.INTERNAL_ERROR, str(e))

    def delete(self, guid: str, force: bool = False) -> Dict[str, Any]:
        """Delete notebook (requires --force)."""
        if not force:
            return ResponseAdapter.error(
                "notebook.delete",
                ErrorCode.VALIDATION_ERROR,
                "Notebook deletion is destructive. Use --force to confirm.",
                details={"guid": guid}
            )

        try:
            self.note_store.expungeNotebook(guid)

            logger.info("notebook_deleted", extra={"guid": guid})

            return ResponseAdapter.success("notebook.delete", {
                "guid": guid,
                "deleted": True
            })

        except Exception as e:
            logger.exception("notebook_delete_error", extra={"guid": guid})
            return ResponseAdapter.error("notebook.delete", ErrorCode.INTERNAL_ERROR, str(e))

    def rename(self, guid: str, new_name: str) -> Dict[str, Any]:
        """Rename notebook."""
        try:
            notebook = EDAMNotebook()
            notebook.guid = guid
            notebook.name = new_name

            self.note_store.updateNotebook(notebook)

            logger.info("notebook_renamed", extra={"guid": guid, "new_name": new_name})

            return ResponseAdapter.success("notebook.rename", {
                "guid": guid,
                "name": new_name
            })

        except Exception as e:
            logger.exception("notebook_rename_error", extra={"guid": guid, "new_name": new_name})
            return ResponseAdapter.error("notebook.rename", ErrorCode.INTERNAL_ERROR, str(e))

    def _handle_edam_error(self, command: str, error: EDAMUserException) -> Dict[str, Any]:
        """Handle EDAM errors."""
        return ResponseAdapter.error(
            command,
            ErrorCode.INTERNAL_ERROR,
            f"Evernote error: {error.errorMessage}"
        )
