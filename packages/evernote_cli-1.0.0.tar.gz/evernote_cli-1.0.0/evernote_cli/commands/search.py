import logging
from typing import Dict, Any, Optional
from evernote.edam.notestore.ttypes import NoteFilter, NotesMetadataResultSpec
from evernote.edam.error.ttypes import EDAMUserException
from evernote_cli.commands.base import BaseCommand
from evernote_cli.adapter import ResponseAdapter
from evernote_cli.errors import ErrorCode, EvernoteCliError, NotebookNotFoundError

logger = logging.getLogger(__name__)


class SearchCommands(BaseCommand):
    """Search operations."""

    def __init__(self, auth, note_store=None):
        super().__init__(auth)
        self.note_store = note_store or self.note_store

    def search(
        self,
        query: str,
        notebook: Optional[str] = None,
        tag: Optional[str] = None,
        limit: int = 50,
        offset: int = 0
    ) -> Dict[str, Any]:
        """Search notes with Evernote query syntax."""
        try:
            # Validate inputs
            if not query and not notebook and not tag:
                return ResponseAdapter.error(
                    "search",
                    ErrorCode.VALIDATION_ERROR,
                    "At least one of query, notebook, or tag must be provided"
                )
            if limit <= 0 or limit > 1000:
                return ResponseAdapter.error(
                    "search",
                    ErrorCode.VALIDATION_ERROR,
                    "Limit must be between 1 and 1000"
                )
            if offset < 0:
                return ResponseAdapter.error(
                    "search",
                    ErrorCode.VALIDATION_ERROR,
                    "Offset must be non-negative"
                )

            # Build filter
            note_filter = NoteFilter()

            # Base query
            words = query

            # Add notebook filter if specified
            if notebook:
                nb_guid = self._get_notebook_guid(notebook)
                note_filter.notebookGuid = nb_guid

            # Add tag filter with security validation
            if tag:
                if " " in tag or '"' in tag:
                    return ResponseAdapter.error(
                        "search",
                        ErrorCode.VALIDATION_ERROR,
                        f"Tag cannot contain spaces or quotes: {tag}"
                    )
                words += f" tag:{tag}"

            note_filter.words = words

            # Request metadata
            result_spec = NotesMetadataResultSpec()
            result_spec.includeTitle = True
            result_spec.includeTags = True
            result_spec.includeNotebookGuid = True
            result_spec.includeUpdated = True
            result_spec.includeCreated = True

            # Execute search
            result = self.note_store.findNotesMetadata(
                note_filter,
                offset,
                limit,
                result_spec
            )

            notes = [
                {
                    "guid": n.guid,
                    "title": n.title,
                    "tags": n.tagNames or [],
                    "notebookGuid": n.notebookGuid,
                    "created": n.created,
                    "updated": n.updated
                }
                for n in result.notes
            ]

            logger.info("search_executed", extra={"query": query, "count": len(notes), "total": result.totalNotes})

            return ResponseAdapter.success("search", {
                "query": query,
                "notes": notes,
                "totalCount": result.totalNotes,
                "offset": offset,
                "limit": limit,
                "hasMore": offset + limit < result.totalNotes
            })

        except NotebookNotFoundError as e:
            logger.warning("notebook_not_found", extra={"notebook": notebook})
            return ResponseAdapter.error(
                "search",
                e.code,
                e.message,
                e.details
            )
        except EDAMUserException as e:
            # Check error code if available (more robust)
            if hasattr(e, 'errorCode') and e.errorCode == 6:  # INVALID_ARGUMENT
                logger.warning("invalid_search_query", extra={"query": query})
                return ResponseAdapter.error(
                    "search",
                    ErrorCode.INVALID_QUERY,
                    f"Invalid search query: {query}"
                )
            # Fallback to string matching
            if "InvalidQuery" in str(e) or "INVALID" in (e.errorMessage or ""):
                logger.warning("invalid_search_query", extra={"query": query})
                return ResponseAdapter.error(
                    "search",
                    ErrorCode.INVALID_QUERY,
                    f"Invalid search query: {query}"
                )
            return self._handle_edam_error("search", e)
        except Exception as e:
            logger.exception("search_error", extra={"query": query})
            return ResponseAdapter.error("search", ErrorCode.INTERNAL_ERROR, str(e))

    def _get_notebook_guid(self, notebook_name: str) -> str:
        """Get notebook GUID by name."""
        notebooks = self.note_store.listNotebooks()
        for nb in notebooks:
            if nb.name == notebook_name:
                return nb.guid

        available = [nb.name for nb in notebooks]
        raise NotebookNotFoundError(notebook_name, available)

    def _handle_edam_error(self, command: str, error: EDAMUserException) -> Dict[str, Any]:
        """Handle Evernote EDAM errors."""
        if error.errorCode == 8:  # NOT_FOUND
            return ResponseAdapter.error(
                command,
                ErrorCode.INTERNAL_ERROR,
                f"Resource not found: {error.parameter}"
            )
        elif error.errorCode == 3:  # PERMISSION_DENIED
            return ResponseAdapter.error(
                command,
                ErrorCode.PERMISSION_DENIED,
                "Permission denied. Upgrade your account?"
            )
        elif error.errorCode == 6:  # INVALID_ARGUMENT
            return ResponseAdapter.error(
                command,
                ErrorCode.INVALID_QUERY,
                f"Invalid query: {error.errorMessage}"
            )
        else:
            return ResponseAdapter.error(
                command,
                ErrorCode.INTERNAL_ERROR,
                f"Evernote error: {error.errorMessage}"
            )
