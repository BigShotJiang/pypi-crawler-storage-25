from datetime import datetime, timezone
from typing import Any, Dict, Optional
from evernote_cli.errors import ErrorCode, get_exit_code
from evernote_cli.utils import generate_request_id


class ResponseAdapter:
    """Transform SDK responses and errors into agent-optimized JSON."""

    @staticmethod
    def success(command: str, data: Any) -> Dict[str, Any]:
        """Create a success response."""
        return {
            "success": True,
            "command": command,
            "data": data,
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "requestId": generate_request_id(),
        }

    @staticmethod
    def error(
        command: str,
        code: ErrorCode,
        message: str,
        details: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Create an error response."""
        exit_code = get_exit_code(code)
        recoverable = exit_code == 2

        return {
            "success": False,
            "command": command,
            "error": {
                "code": code.value,
                "message": message,
                "recoverable": recoverable,
                "details": details or {},
            },
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "requestId": generate_request_id(),
        }
