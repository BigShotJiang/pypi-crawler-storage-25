from html.parser import HTMLParser
from html import escape
import re
import markdown2
import bleach


class ContentConverter:
    """Convert between markdown, plain text, and ENML."""

    ENML_HEADER = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE en-note SYSTEM "http://xml.evernote.com/pub/evernote-noteformat.dtd">\n'
    )

    def markdown_to_enml(self, content: str) -> str:
        """Convert markdown or plain text to valid ENML."""
        # Convert markdown to HTML
        html = markdown2.markdown(content, extras=["tables", "fenced-code-blocks"])

        # Sanitize HTML (remove dangerous tags)
        allowed_tags = [
            "p",
            "br",
            "b",
            "i",
            "u",
            "strong",
            "em",
            "s",
            "del",
            "h1",
            "h2",
            "h3",
            "h4",
            "h5",
            "h6",
            "ul",
            "ol",
            "li",
            "table",
            "thead",
            "tbody",
            "tr",
            "th",
            "td",
            "pre",
            "code",
            "blockquote",
            "a",
            "img",
            "div",
            "span",
        ]
        allowed_attrs = {"a": ["href"], "img": ["src", "alt"]}
        clean_html = bleach.clean(html, tags=allowed_tags, attributes=allowed_attrs)

        # Wrap in en-note tags with ENML header
        enml = self.ENML_HEADER + f"<en-note>{clean_html}</en-note>"
        return enml

    def enml_to_plaintext(self, enml: str) -> str:
        """Extract plain text from ENML."""
        # Remove XML declaration and DOCTYPE
        content = re.sub(r"<\?xml.*?\?>", "", enml)
        content = re.sub(r"<!DOCTYPE.*?>", "", content)

        # Parse HTML and extract text
        parser = PlaintextExtractor()
        parser.feed(content)
        return parser.get_text()


class PlaintextExtractor(HTMLParser):
    """Extract plain text from HTML."""

    def __init__(self):
        super().__init__()
        self.text = []
        self.in_script = False

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.in_script = True
        elif tag in ("br", "div", "p", "li"):
            if self.text and self.text[-1] != "\n":
                self.text.append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.in_script = False
        elif tag in ("div", "p", "li"):
            if self.text and self.text[-1] != "\n":
                self.text.append("\n")

    def handle_data(self, data):
        if not self.in_script:
            self.text.append(data)

    def get_text(self) -> str:
        """Get extracted text, cleaned up."""
        text = "".join(self.text).strip()
        # Remove multiple consecutive newlines
        text = re.sub(r"\n\n+", "\n", text)
        return text
