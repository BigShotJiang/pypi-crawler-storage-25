import uuid
import json
from typing import Any


def generate_request_id() -> str:
    """Generate a unique request ID for tracing."""
    return f"req-{uuid.uuid4().hex[:12]}"


def json_serialize(obj: Any) -> str:
    """Serialize object to JSON, handling edge cases."""
    return json.dumps(obj, default=str)
