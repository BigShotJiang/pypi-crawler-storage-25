from dataclasses import dataclass, asdict
from typing import List, Optional


@dataclass
class Note:
    """Represents an Evernote note."""
    guid: str
    title: str
    content: str  # ENML format (internal)
    notebook_guid: str
    notebook_name: str
    tags: List[str]
    created: int  # Unix timestamp ms
    updated: int  # Unix timestamp ms
    update_sequence_number: int  # For conflict detection
    content_length: int
    content_plain_text: Optional[str] = None
    source: Optional[str] = None

    def to_dict(self):
        """Convert to dict, excluding ENML content for agent response."""
        d = asdict(self)
        # Don't send ENML to agent; extract plain text instead
        d.pop('content', None)
        return {k: v for k, v in d.items() if v is not None}


@dataclass
class Notebook:
    """Represents an Evernote notebook."""
    guid: str
    name: str
    created: int
    updated: int
    note_count: int

    def to_dict(self):
        return asdict(self)


@dataclass
class Tag:
    """Represents an Evernote tag."""
    guid: str
    name: str
    created: int
    updated: int
    note_count: int

    def to_dict(self):
        return asdict(self)
