from enum import Enum
from typing import Optional


class ErrorCode(str, Enum):
    """Agent-friendly error codes with explicit exit semantics."""
    NOTEBOOK_NOT_FOUND = "NOTEBOOK_NOT_FOUND"
    NOTE_NOT_FOUND = "NOTE_NOT_FOUND"
    TAG_NOT_FOUND = "TAG_NOT_FOUND"
    DUPLICATE_NOTEBOOK_NAME = "DUPLICATE_NOTEBOOK_NAME"
    AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED"
    AUTHENTICATION_EXPIRED = "AUTHENTICATION_EXPIRED"
    RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED"
    INVALID_QUERY = "INVALID_QUERY"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    VALIDATION_ERROR = "VALIDATION_ERROR"
    CONFLICT = "CONFLICT"  # USN mismatch
    ENML_INVALID = "ENML_INVALID"


def get_exit_code(error: ErrorCode) -> int:
    """Map error code to exit code for agent interpretation."""
    # Exit 1: Non-recoverable
    non_recoverable = {
        ErrorCode.NOTEBOOK_NOT_FOUND,
        ErrorCode.NOTE_NOT_FOUND,
        ErrorCode.TAG_NOT_FOUND,
        ErrorCode.DUPLICATE_NOTEBOOK_NAME,
        ErrorCode.AUTHENTICATION_FAILED,
        ErrorCode.INVALID_QUERY,
        ErrorCode.PERMISSION_DENIED,
        ErrorCode.VALIDATION_ERROR,
        ErrorCode.ENML_INVALID,
    }
    if error in non_recoverable:
        return 1

    # Exit 2: Recoverable (retry)
    return 2


class EvernoteCliError(Exception):
    """Base exception for CLI errors."""
    def __init__(self, code: ErrorCode, message: str, details: Optional[dict] = None):
        self.code = code
        self.message = message
        self.details = details or {}
        super().__init__(message)


class NotebookNotFoundError(EvernoteCliError):
    def __init__(self, notebook_name: str, available: list):
        super().__init__(
            ErrorCode.NOTEBOOK_NOT_FOUND,
            f"Notebook '{notebook_name}' does not exist",
            {"requested_notebook": notebook_name, "available_notebooks": available}
        )
