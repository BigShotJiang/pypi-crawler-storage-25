#!/usr/bin/env python3

import os
import random
import signal
import sys
import json
from pathlib import Path

try:
    import readline
except ImportError:
    pass

from text_discoloration import (
    random_typewriter,
    separator,
    custom_print,
    gradient_text,
    success,
    error,
    info,
    progress_bar,
    COLOR_MAP,
    END,
)


CONFIG_PATH = Path.home() / ".th_config.json"
DEFAULT_CONFIG = {
    "loop_mode": True,
    "version": "1.0.0"
}

def load_config():
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
        except:
            return DEFAULT_CONFIG.copy()
    else:
        info("首次启动，正在初始化配置...")
        for i in range(0, 101, 20):
            progress_bar(i, width=30, color="cyan", auto_end=False)
            import time
            time.sleep(0.05)
        print()
        CONFIG_PATH.write_text(json.dumps(DEFAULT_CONFIG, indent=2), encoding='utf-8')
        success("配置文件已创建: ~/.th_config.json")
        return DEFAULT_CONFIG.copy()

def save_config(config):
    CONFIG_PATH.write_text(json.dumps(config, indent=2), encoding='utf-8')

def set_loop_mode(enabled):
    config = load_config()
    config["loop_mode"] = enabled
    save_config(config)
    status = "开启" if enabled else "关闭"
    success(f"循环模式已{status}")
    info(f"下次启动 th 将{'会' if enabled else '不会'}询问是否继续")


tmp_path = Path.home() / ".th_temp.py"

def clear_file():
    if tmp_path.exists():
        tmp_path.unlink()

def execute_temp_file():
    if tmp_path.exists():
        code = tmp_path.read_text(encoding='utf-8')
        exec(code, {"__name__": "__main__"})


def exit_handler(sig, frame):
    if tmp_path.exists():
        print("\n")
        info("检测到未执行的代码")
        choice = input("是否执行？(y/N): ").strip().lower()
        if choice == "y":
            execute_temp_file()
    clear_file()
    print()
    success("已退出")
    raise SystemExit

signal.signal(signal.SIGINT, exit_handler)
signal.signal(signal.SIGTERM, exit_handler)


def thv():
    config = load_config()
    print(f"th version {config.get('version', '0.0.2')}")


def main():
    config = load_config()
    loop_mode = config.get("loop_mode", True)

    while True:
        clear_file()

        random_typewriter("th-py Python编辑器", delay=0.03)
        separator(color="purple")
        info("输入代码，每行按回车")
        info("输入 end 执行代码")
        info("输入 quit 退出程序")
        info("按 Ctrl+C 可选择是否执行")
        if loop_mode:
            info("循环模式: 开启（执行完后询问是否继续）")
        else:
            info("循环模式: 关闭（执行完后自动退出）")
        separator(color="purple")

        while True:
            try:
                inp = input("> ")
            except EOFError:
                break

            if inp == "end":
                break
            elif inp == "quit":
                clear_file()
                success("已退出")
                separator(color="green")
                return

            with open(tmp_path, "a", encoding="utf-8") as f:
                f.write(inp + "\n")

        gradient_text("执行结果", (255, 0, 100), (0, 200, 255), delay=0.02)
        separator(color="cyan")

        execute_temp_file()
        clear_file()

        success("执行完成")
        separator(color="green")

        if not loop_mode:
            success("循环模式已关闭，程序退出")
            break

        again = input("\n是否继续编写代码？(y/N): ").strip().lower()
        if again != 'y':
            success("再见")
            break


if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "--version" or sys.argv[1] == "-v":
            thv()
        elif sys.argv[1] == "set" and len(sys.argv) > 2:
            if sys.argv[2] == "while" and len(sys.argv) > 3:
                if sys.argv[3].lower() == "true":
                    set_loop_mode(True)
                elif sys.argv[3].lower() == "false":
                    set_loop_mode(False)
                else:
                    print("用法: th set while true/false")
            else:
                print("用法: th set while true/false")
        elif sys.argv[1] == "care_py_main_python":
            try:
                import care
                print(f"彩蛋位置: {care.__file__}")
            except ImportError:
                print("彩蛋文件未找到，但你正在靠近真相")
        else:
            print(f"未知命令: {sys.argv[1]}")
            print("用法: th 或 th --version 或 th set while true/false")
    else:
        main()