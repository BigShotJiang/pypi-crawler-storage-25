__version__ = "1.0.0"

from .care import secret_easter_egg, th_py_egg_thv
from .egg import main_egg_input, Chinese_Error_py