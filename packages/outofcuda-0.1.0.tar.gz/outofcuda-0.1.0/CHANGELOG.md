# Changelog

All notable changes to **outofcuda** will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [0.1.0] — 2024-12-01

### Added
- **Zero-code installation** — CUDA optimisations are applied automatically
  at Python startup via a `.pth` hook; no `import` or function call needed.
- `OptConfig` dataclass with full environment-variable overrides.
- `apply()` — idempotent function to apply all optimisations.
- `CudaOptimizer` — stateful helper class bundling all features.
- `autocast_context()` — AMP context manager with auto bfloat16 on Ampere+.
- `compile_model()` — channels-last + `torch.compile()` wrapper.
- `smart_dataloader()` — pre-tuned `DataLoader` with pin_memory & prefetch.
- `memory_report()` — per-device VRAM statistics dict.
- `clear_cache()` — empty CUDA cache + optional GC.
- `MemoryMonitor` — daemon thread that auto-clears cache above a threshold.
- OOM recovery hook installed in `sys.excepthook`.
- TF32 matmul / cuDNN, cuDNN benchmark, SDPA backend selection, allocator
  config (`PYTORCH_CUDA_ALLOC_CONF`), and per-device memory fraction.
- Full environment-variable control (prefix `OUTOFCUDA_`).
- Type annotations + `py.typed` marker (PEP 561).
- MIT License.
