"""
outofcuda.monitor
~~~~~~~~~~~~~~~~~
Background thread that watches VRAM and auto-clears cache when usage is high.
"""
from __future__ import annotations

import threading
import time
import logging
from typing import Callable, Optional

_log = logging.getLogger("outofcuda.monitor")


class MemoryMonitor:
    """
    Lightweight VRAM watchdog that runs in a daemon thread.

    Automatically calls :func:`outofcuda.clear_cache` when allocated VRAM
    exceeds *threshold* (default 90 %).

    Usage::

        monitor = MemoryMonitor(threshold=0.85, interval=2.0)
        monitor.start()
        # ... training loop ...
        monitor.stop()

    Or use as a context manager::

        with MemoryMonitor(threshold=0.85):
            train(model, data)
    """

    def __init__(
        self,
        threshold: float = 0.90,
        interval: float = 2.0,
        on_threshold: Optional[Callable[[], None]] = None,
        device: int = 0,
    ) -> None:
        self.threshold = threshold
        self.interval = interval
        self.device = device
        self._on_threshold = on_threshold or self._default_action
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    # ── Default action ────────────────────────────────────────────────────────

    def _default_action(self) -> None:
        from outofcuda.optimizer import clear_cache
        _log.warning(
            "outofcuda.monitor: VRAM usage exceeded %.0f%% — clearing cache",
            self.threshold * 100,
        )
        clear_cache()

    # ── Thread target ─────────────────────────────────────────────────────────

    def _run(self) -> None:
        try:
            import torch
        except ImportError:
            _log.debug("monitor: torch not available")
            return

        while not self._stop_event.is_set():
            try:
                if torch.cuda.is_available():
                    total = torch.cuda.get_device_properties(self.device).total_memory
                    allocated = torch.cuda.memory_allocated(self.device)
                    if total > 0 and (allocated / total) >= self.threshold:
                        self._on_threshold()
            except Exception as exc:
                _log.debug("monitor error: %s", exc)
            self._stop_event.wait(self.interval)

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def start(self) -> "MemoryMonitor":
        """Start the background watchdog thread."""
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name="outofcuda-monitor",
            daemon=True,
        )
        self._thread.start()
        return self

    def stop(self) -> None:
        """Stop the watchdog thread."""
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=self.interval + 1)
            self._thread = None

    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    # ── Context manager ───────────────────────────────────────────────────────

    def __enter__(self) -> "MemoryMonitor":
        return self.start()

    def __exit__(self, *_: object) -> None:
        self.stop()

    def __repr__(self) -> str:
        status = "running" if self.is_running() else "stopped"
        return (
            f"MemoryMonitor(threshold={self.threshold:.0%}, "
            f"interval={self.interval}s, status={status})"
        )
