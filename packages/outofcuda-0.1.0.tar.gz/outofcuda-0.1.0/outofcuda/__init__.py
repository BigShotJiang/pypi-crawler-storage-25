"""
outofcuda — CUDA memory & compute optimizer that works just by being installed.
Applies high-level PyTorch / CUDA optimizations automatically at Python startup.
"""

from __future__ import annotations

__version__ = "0.1.0"
__author__ = "outofcuda contributors"
__license__ = "MIT"

import os as _os
import sys as _sys
import logging as _logging

_log = _logging.getLogger("outofcuda")

# ─── Public API re-exports ────────────────────────────────────────────────────
from outofcuda.optimizer import (
    apply,
    CudaOptimizer,
    autocast_context,
    smart_dataloader,
    compile_model,
    memory_report,
    clear_cache,
)
from outofcuda.monitor import MemoryMonitor
from outofcuda.config import OptConfig

__all__ = [
    "apply",
    "CudaOptimizer",
    "autocast_context",
    "smart_dataloader",
    "compile_model",
    "memory_report",
    "clear_cache",
    "MemoryMonitor",
    "OptConfig",
    "__version__",
]

# ─── Auto-apply on import (triggered by .pth hook at startup) ────────────────
def _auto_apply() -> None:
    """Called automatically at Python startup via the .pth hook."""
    try:
        from outofcuda.optimizer import apply as _apply
        _apply(verbose=_os.environ.get("OUTOFCUDA_VERBOSE", "0") == "1")
    except Exception as exc:  # pragma: no cover
        _log.debug("outofcuda auto-apply skipped: %s", exc)
