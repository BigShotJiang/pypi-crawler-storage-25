"""
outofcuda._hook
~~~~~~~~~~~~~~~
Imported at Python startup via the ``outofcuda.pth`` site-packages hook.
Must be safe to import even when torch is not installed.
"""
from __future__ import annotations

import sys


def _bootstrap() -> None:
    """Called once per interpreter startup by the .pth hook."""
    # Defer heavy imports — only run after torch is actually loaded
    import importlib

    class _TorchImportHook:
        """Meta path finder that triggers outofcuda after torch is imported."""

        _fired = False

        def find_module(self, fullname: str, path: object = None) -> None:  # type: ignore[return]
            return None  # we never intercept the import itself

        def find_spec(self, fullname: str, path: object, target: object = None):  # type: ignore[return]
            if fullname == "torch" and not _TorchImportHook._fired:
                # Install a post-import hook via sys.modules manipulation
                _install_post_import_hook()
            return None

    sys.meta_path.append(_TorchImportHook())


def _install_post_import_hook() -> None:
    """Schedule outofcuda.apply() to run after torch finishes importing."""
    import importlib

    # Use importlib.import_module lazy hook approach
    _orig = __builtins__.__import__ if hasattr(__builtins__, "__import__") else None  # type: ignore

    class _Hook:
        """Watches for torch to appear in sys.modules, then fires once."""

        _done = False

        def find_spec(self, fullname: str, path: object, target: object = None):  # type: ignore[return]
            if fullname == "torch" and not _Hook._done:
                # Defer via threading to avoid import cycle
                _Hook._done = True
                import threading

                def _apply_deferred() -> None:
                    import time
                    # Wait briefly so torch finishes its own __init__
                    time.sleep(0.05)
                    try:
                        from outofcuda import _auto_apply
                        _auto_apply()
                    except Exception:
                        pass

                t = threading.Thread(target=_apply_deferred, daemon=True)
                t.start()
            return None

    sys.meta_path.append(_Hook())


_bootstrap()
