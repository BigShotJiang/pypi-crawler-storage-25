"""
outofcuda.config
~~~~~~~~~~~~~~~~
Single source of truth for all optimisation knobs.
All values can be overridden via environment variables.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field


def _env_bool(key: str, default: bool) -> bool:
    v = os.environ.get(key, "").lower()
    if v in ("1", "true", "yes"):
        return True
    if v in ("0", "false", "no"):
        return False
    return default


def _env_float(key: str, default: float) -> float:
    try:
        return float(os.environ.get(key, default))
    except (TypeError, ValueError):
        return default


def _env_int(key: str, default: int) -> int:
    try:
        return int(os.environ.get(key, default))
    except (TypeError, ValueError):
        return default


@dataclass
class OptConfig:
    """
    Configuration for outofcuda optimisations.

    Environment variable overrides
    --------------------------------
    OUTOFCUDA_TF32            : enable TF32 for matmul / cuDNN   (default: 1)
    OUTOFCUDA_CUDNN_BENCHMARK : enable cuDNN autotuner            (default: 1)
    OUTOFCUDA_CHANNELS_LAST   : prefer channels-last memory fmt   (default: 1)
    OUTOFCUDA_COMPILE         : use torch.compile() by default    (default: 0)
    OUTOFCUDA_COMPILE_MODE    : torch.compile mode string         (default: reduce-overhead)
    OUTOFCUDA_AMP_DTYPE       : dtype string for autocast          (default: float16)
    OUTOFCUDA_MEMORY_FRACTION : max fraction of VRAM to allocate  (default: 0.95)
    OUTOFCUDA_ALLOC_CONF      : PYTORCH_CUDA_ALLOC_CONF string    (default: see below)
    OUTOFCUDA_GC_COLLECT      : run gc.collect on cache clear     (default: 1)
    OUTOFCUDA_VERBOSE         : print optimisation report         (default: 0)
    OUTOFCUDA_DISABLE         : set to 1 to fully disable         (default: 0)
    """

    # ── cuDNN / matmul ────────────────────────────────────────────────────────
    allow_tf32: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_TF32", True)
    )
    cudnn_benchmark: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_CUDNN_BENCHMARK", True)
    )
    cudnn_deterministic: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_CUDNN_DETERMINISTIC", False)
    )

    # ── Memory layout ─────────────────────────────────────────────────────────
    prefer_channels_last: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_CHANNELS_LAST", True)
    )

    # ── torch.compile ─────────────────────────────────────────────────────────
    use_compile: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_COMPILE", False)
    )
    compile_mode: str = field(
        default_factory=lambda: os.environ.get(
            "OUTOFCUDA_COMPILE_MODE", "reduce-overhead"
        )
    )
    compile_fullgraph: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_COMPILE_FULLGRAPH", False)
    )

    # ── AMP ───────────────────────────────────────────────────────────────────
    amp_dtype: str = field(
        default_factory=lambda: os.environ.get("OUTOFCUDA_AMP_DTYPE", "float16")
    )

    # ── Allocator ─────────────────────────────────────────────────────────────
    memory_fraction: float = field(
        default_factory=lambda: _env_float("OUTOFCUDA_MEMORY_FRACTION", 0.95)
    )
    alloc_conf: str = field(
        default_factory=lambda: os.environ.get(
            "OUTOFCUDA_ALLOC_CONF",
            "max_split_size_mb:128,garbage_collection_threshold:0.8,expandable_segments:True",
        )
    )

    # ── GC integration ────────────────────────────────────────────────────────
    gc_on_clear: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_GC_COLLECT", True)
    )

    # ── Flash / memory-efficient attention ────────────────────────────────────
    enable_flash_attention: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_FLASH_ATTN", True)
    )
    enable_mem_efficient_attention: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_MEM_EFF_ATTN", True)
    )
    enable_math_attention: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_MATH_ATTN", True)
    )

    # ── Misc ──────────────────────────────────────────────────────────────────
    verbose: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_VERBOSE", False)
    )
    disabled: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_DISABLE", False)
    )

    # ── DataLoader defaults ───────────────────────────────────────────────────
    dataloader_pin_memory: bool = field(
        default_factory=lambda: _env_bool("OUTOFCUDA_PIN_MEMORY", True)
    )
    dataloader_num_workers: int = field(
        default_factory=lambda: _env_int("OUTOFCUDA_NUM_WORKERS", 4)
    )
    dataloader_prefetch_factor: int = field(
        default_factory=lambda: _env_int("OUTOFCUDA_PREFETCH_FACTOR", 2)
    )


# Module-level default config (mutate freely)
DEFAULT_CONFIG = OptConfig()
