"""
outofcuda.optimizer
~~~~~~~~~~~~~~~~~~~
Core optimisation logic.  All heavy lifting happens here.
"""
from __future__ import annotations

import gc
import os
import sys
import contextlib
import logging
from typing import Any, Generator, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, Dataset

from outofcuda.config import OptConfig, DEFAULT_CONFIG

_log = logging.getLogger("outofcuda")
_applied = False  # guard against double-application


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _torch_available() -> bool:
    return "torch" in sys.modules or _find_spec("torch")


def _find_spec(name: str) -> bool:
    import importlib.util
    return importlib.util.find_spec(name) is not None


def _get_torch():
    try:
        import torch
        return torch
    except ImportError:
        return None


# ─────────────────────────────────────────────────────────────────────────────
# apply()
# ─────────────────────────────────────────────────────────────────────────────

def apply(config: OptConfig = DEFAULT_CONFIG, *, verbose: bool = False) -> bool:
    """
    Apply all CUDA/PyTorch optimisations defined in *config*.

    Returns True if optimisations were applied, False if skipped
    (e.g. no GPU, OUTOFCUDA_DISABLE=1, or already applied).

    This function is idempotent — calling it multiple times is safe.
    """
    global _applied

    if config.disabled:
        _log.debug("outofcuda disabled via OUTOFCUDA_DISABLE=1")
        return False

    torch = _get_torch()
    if torch is None:
        _log.debug("outofcuda: torch not installed, skipping")
        return False

    if not torch.cuda.is_available():
        _log.debug("outofcuda: CUDA not available, skipping GPU opts")
        return False

    if _applied:
        return True

    applied_opts: list[str] = []

    # ── 1. TF32 (A100 / RTX-30xx+) ───────────────────────────────────────────
    if config.allow_tf32:
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        applied_opts.append("TF32 matmul+cuDNN")

    # ── 2. cuDNN benchmark ────────────────────────────────────────────────────
    if config.cudnn_benchmark:
        torch.backends.cudnn.benchmark = True
        applied_opts.append("cuDNN benchmark")

    if config.cudnn_deterministic:
        torch.backends.cudnn.deterministic = True
        applied_opts.append("cuDNN deterministic")

    # ── 3. CUDA memory allocator tuning ───────────────────────────────────────
    if config.alloc_conf:
        existing = os.environ.get("PYTORCH_CUDA_ALLOC_CONF", "")
        if not existing:
            os.environ["PYTORCH_CUDA_ALLOC_CONF"] = config.alloc_conf
            # Re-apply via caching allocator API when possible
            try:
                torch.cuda.memory.set_per_process_memory_fraction(
                    config.memory_fraction
                )
            except Exception:
                pass
            applied_opts.append(f"allocator config: {config.alloc_conf}")

    # ── 4. Memory fraction ────────────────────────────────────────────────────
    try:
        for i in range(torch.cuda.device_count()):
            torch.cuda.set_per_process_memory_fraction(config.memory_fraction, i)
        applied_opts.append(f"memory fraction {config.memory_fraction:.0%}")
    except Exception:
        pass

    # ── 5. SDPA / Flash Attention backend ─────────────────────────────────────
    try:
        from torch.backends.cuda import sdp_kernel, SDPBackend  # type: ignore
        # Enable all fast backends so PyTorch picks the best one automatically
        _backends: list[SDPBackend] = []
        if config.enable_flash_attention:
            _backends.append(SDPBackend.FLASH_ATTENTION)
        if config.enable_mem_efficient_attention:
            _backends.append(SDPBackend.EFFICIENT_ATTENTION)
        if config.enable_math_attention:
            _backends.append(SDPBackend.MATH)
        if _backends:
            torch.backends.cuda.enable_flash_sdp(config.enable_flash_attention)
            torch.backends.cuda.enable_mem_efficient_sdp(
                config.enable_mem_efficient_attention
            )
            torch.backends.cuda.enable_math_sdp(config.enable_math_attention)
            applied_opts.append("SDPA backends configured")
    except (ImportError, AttributeError):
        pass

    # ── 6. BFloat16 autocast on Ampere+ ───────────────────────────────────────
    try:
        cap = torch.cuda.get_device_capability()
        if cap[0] >= 8 and config.amp_dtype == "float16":
            # Ampere+ supports bfloat16 natively — better dynamic range
            DEFAULT_CONFIG.amp_dtype = "bfloat16"
            applied_opts.append("AMP dtype → bfloat16 (Ampere+)")
    except Exception:
        pass

    # ── 7. GC integration — register a low-memory hook ────────────────────────
    try:
        _install_oom_hook(torch, config)
        applied_opts.append("OOM recovery hook")
    except Exception:
        pass

    # ── 8. Channels-last hint stored for compile_model() ─────────────────────
    if config.prefer_channels_last:
        applied_opts.append("channels-last preferred (use compile_model)")

    _applied = True

    if verbose or config.verbose:
        _print_report(applied_opts)

    return True


# ─────────────────────────────────────────────────────────────────────────────
# OOM hook
# ─────────────────────────────────────────────────────────────────────────────

def _install_oom_hook(torch: Any, config: OptConfig) -> None:
    """Monkey-patch torch.cuda.OutOfMemoryError handler at import time."""
    original_excepthook = sys.excepthook

    def _oom_excepthook(exc_type, exc_value, exc_tb):
        if issubclass(exc_type, torch.cuda.OutOfMemoryError):
            _log.warning(
                "outofcuda: CUDA OOM detected — clearing cache and retrying GC."
            )
            clear_cache(config)
        original_excepthook(exc_type, exc_value, exc_tb)

    sys.excepthook = _oom_excepthook


# ─────────────────────────────────────────────────────────────────────────────
# Public utilities
# ─────────────────────────────────────────────────────────────────────────────

def clear_cache(config: OptConfig = DEFAULT_CONFIG) -> None:
    """Free unused CUDA memory and (optionally) run Python GC."""
    torch = _get_torch()
    if torch and torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.synchronize()
    if config.gc_on_clear:
        gc.collect()


@contextlib.contextmanager
def autocast_context(
    config: OptConfig = DEFAULT_CONFIG,
    dtype: Optional[str] = None,
    device: str = "cuda",
) -> Generator[None, None, None]:
    """
    Drop-in context manager for Automatic Mixed Precision.

    Usage::

        with outofcuda.autocast_context():
            output = model(input)
    """
    import torch

    _dtype_map = {
        "float16": torch.float16,
        "bfloat16": torch.bfloat16,
        "float32": torch.float32,
    }
    _dtype = _dtype_map.get(dtype or config.amp_dtype, torch.float16)
    with torch.autocast(device_type=device, dtype=_dtype):
        yield


def compile_model(
    model: "nn.Module",
    config: OptConfig = DEFAULT_CONFIG,
    *,
    channels_last: Optional[bool] = None,
    mode: Optional[str] = None,
    fullgraph: Optional[bool] = None,
) -> "nn.Module":
    """
    Optimise a model for fast CUDA inference / training.

    Steps
    -----
    1. Convert to channels-last memory layout (better tensor-core usage).
    2. Wrap with ``torch.compile()`` when available and *use_compile* is set.

    Usage::

        model = outofcuda.compile_model(model)
    """
    import torch
    import torch.nn as nn

    cl = channels_last if channels_last is not None else config.prefer_channels_last
    if cl:
        try:
            model = model.to(memory_format=torch.channels_last)
        except Exception:
            pass

    do_compile = config.use_compile
    if do_compile and hasattr(torch, "compile"):
        _mode = mode or config.compile_mode
        _fg = fullgraph if fullgraph is not None else config.compile_fullgraph
        try:
            model = torch.compile(model, mode=_mode, fullgraph=_fg)
        except Exception as exc:
            _log.warning("outofcuda: torch.compile failed (%s), using eager mode", exc)

    return model


def smart_dataloader(
    dataset: "Dataset",
    config: OptConfig = DEFAULT_CONFIG,
    **kwargs: Any,
) -> "DataLoader":
    """
    Return a ``DataLoader`` with optimal CUDA-transfer settings pre-filled.

    Any kwarg overrides the default::

        loader = outofcuda.smart_dataloader(my_dataset, batch_size=64)
    """
    from torch.utils.data import DataLoader

    defaults: dict[str, Any] = {
        "pin_memory": config.dataloader_pin_memory,
        "num_workers": config.dataloader_num_workers,
        "prefetch_factor": config.dataloader_prefetch_factor if config.dataloader_num_workers > 0 else None,
        "persistent_workers": config.dataloader_num_workers > 0,
    }
    defaults.update(kwargs)
    # Drop None values so DataLoader doesn't choke
    defaults = {k: v for k, v in defaults.items() if v is not None}
    return DataLoader(dataset, **defaults)


def memory_report() -> dict[str, Any]:
    """
    Return a dict with current CUDA memory statistics for all devices.

    Keys per device: ``total_gb``, ``reserved_gb``, ``allocated_gb``, ``free_gb``
    """
    torch = _get_torch()
    if torch is None or not torch.cuda.is_available():
        return {}

    report: dict[str, Any] = {}
    for i in range(torch.cuda.device_count()):
        props = torch.cuda.get_device_properties(i)
        mem = torch.cuda.memory_stats(i)
        total = props.total_memory
        reserved = torch.cuda.memory_reserved(i)
        allocated = torch.cuda.memory_allocated(i)
        free = total - reserved
        report[f"cuda:{i}"] = {
            "name": props.name,
            "total_gb": round(total / 1e9, 2),
            "reserved_gb": round(reserved / 1e9, 2),
            "allocated_gb": round(allocated / 1e9, 2),
            "free_gb": round(free / 1e9, 2),
            "peak_allocated_gb": round(
                mem.get("allocated_bytes.all.peak", 0) / 1e9, 2
            ),
        }
    return report


# ─────────────────────────────────────────────────────────────────────────────
# CudaOptimizer convenience class
# ─────────────────────────────────────────────────────────────────────────────

class CudaOptimizer:
    """
    Stateful wrapper that bundles all outofcuda features.

    Usage::

        opt = CudaOptimizer()          # or CudaOptimizer(config)
        model = opt.prepare(model)
        with opt.autocast():
            loss = model(x)
        opt.clear()
        print(opt.report())
    """

    def __init__(self, config: OptConfig = DEFAULT_CONFIG) -> None:
        self.config = config
        apply(config)

    def prepare(self, model: "nn.Module", **kwargs: Any) -> "nn.Module":
        """Calls :func:`compile_model` and returns the optimised model."""
        return compile_model(model, self.config, **kwargs)

    def dataloader(self, dataset: "Dataset", **kwargs: Any) -> "DataLoader":
        """Calls :func:`smart_dataloader`."""
        return smart_dataloader(dataset, self.config, **kwargs)

    def autocast(self, **kwargs: Any) -> contextlib.AbstractContextManager:
        """Returns :func:`autocast_context`."""
        return autocast_context(self.config, **kwargs)

    def clear(self) -> None:
        """Calls :func:`clear_cache`."""
        clear_cache(self.config)

    def report(self) -> dict[str, Any]:
        """Calls :func:`memory_report`."""
        return memory_report()

    def __repr__(self) -> str:
        r = memory_report()
        lines = [f"CudaOptimizer(devices={len(r)})"]
        for dev, info in r.items():
            lines.append(
                f"  {dev} {info['name']}: "
                f"{info['allocated_gb']:.2f}/{info['total_gb']:.2f} GB used"
            )
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────────────

def _print_report(applied: list[str]) -> None:
    print("=" * 60)
    print("  outofcuda — CUDA optimisations applied")
    print("=" * 60)
    for item in applied:
        print(f"  ✓  {item}")
    try:
        r = memory_report()
        for dev, info in r.items():
            print(
                f"  📊 {dev} ({info['name']}): "
                f"{info['free_gb']:.1f} GB free / {info['total_gb']:.1f} GB total"
            )
    except Exception:
        pass
    print("=" * 60)
