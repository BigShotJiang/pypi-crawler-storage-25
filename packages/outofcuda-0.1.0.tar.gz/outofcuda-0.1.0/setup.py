"""
setup.py — installs outofcuda_hook.pth into site-packages.
All other metadata lives in pyproject.toml.

The .pth file is what makes outofcuda work without any import in user code:
Python processes every .pth in site-packages at startup, so our hook fires
before the user's first `import torch`.
"""
from setuptools import setup
from setuptools.command.install import install
from setuptools.command.develop import develop
import os, sys, site


def _site_packages_dir() -> str:
    """Return the first writable site-packages directory."""
    candidates = site.getsitepackages() if hasattr(site, "getsitepackages") else []
    if hasattr(site, "getusersitepackages"):
        candidates = [site.getusersitepackages()] + list(candidates)
    for p in candidates:
        if os.path.isdir(p) and os.access(p, os.W_OK):
            return p
    # Fallback: use the directory of the current site module
    return os.path.dirname(site.__file__)


def _install_pth() -> None:
    """Copy outofcuda_hook.pth into site-packages."""
    src = os.path.join(os.path.dirname(__file__), "outofcuda_hook.pth")
    dst_dir = _site_packages_dir()
    dst = os.path.join(dst_dir, "outofcuda_hook.pth")
    try:
        import shutil
        shutil.copy2(src, dst)
        print(f"outofcuda: installed startup hook → {dst}")
    except Exception as exc:
        print(f"outofcuda WARNING: could not install hook ({exc}). "
              "You can copy outofcuda_hook.pth manually into your site-packages.")


class _Install(install):
    def run(self):
        super().run()
        _install_pth()


class _Develop(develop):
    def run(self):
        super().run()
        _install_pth()


setup(
    cmdclass={"install": _Install, "develop": _Develop},
)

