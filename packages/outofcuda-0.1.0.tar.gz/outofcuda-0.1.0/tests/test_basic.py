"""
outofcuda tests — run without a GPU (CUDA not required).
"""
import importlib
import os
import sys


def test_import():
    import outofcuda
    assert outofcuda.__version__ == "0.1.0"


def test_apply_no_cuda():
    """apply() must not raise even when CUDA is unavailable."""
    import outofcuda
    result = outofcuda.apply()
    assert isinstance(result, bool)


def test_memory_report_no_cuda():
    import outofcuda
    report = outofcuda.memory_report()
    assert isinstance(report, dict)


def test_clear_cache_no_cuda():
    import outofcuda
    outofcuda.clear_cache()  # must not raise


def test_config_env_override(monkeypatch):
    monkeypatch.setenv("OUTOFCUDA_TF32", "0")
    monkeypatch.setenv("OUTOFCUDA_MEMORY_FRACTION", "0.5")
    # Re-import config with fresh environment
    import importlib
    import outofcuda.config as cfg
    importlib.reload(cfg)
    c = cfg.OptConfig()
    assert c.allow_tf32 is False
    assert c.memory_fraction == 0.5


def test_config_disable(monkeypatch):
    monkeypatch.setenv("OUTOFCUDA_DISABLE", "1")
    import importlib
    import outofcuda.config as cfg
    importlib.reload(cfg)
    c = cfg.OptConfig()
    assert c.disabled is True


def test_cuda_optimizer_instantiation():
    from outofcuda import CudaOptimizer
    opt = CudaOptimizer()
    assert repr(opt)  # must not raise


def test_memory_monitor_lifecycle():
    from outofcuda import MemoryMonitor
    m = MemoryMonitor(threshold=0.99, interval=0.1)
    m.start()
    assert m.is_running()
    m.stop()
    assert not m.is_running()


def test_memory_monitor_context_manager():
    from outofcuda import MemoryMonitor
    with MemoryMonitor(threshold=0.99, interval=0.1) as m:
        assert m.is_running()
    assert not m.is_running()
