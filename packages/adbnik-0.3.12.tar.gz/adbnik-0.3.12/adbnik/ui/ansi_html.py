"""Convert terminal streams with ANSI SGR codes into HTML for QTextEdit; also yield plain text for logs."""

from __future__ import annotations

import html
import re
from dataclasses import dataclass
from typing import List, Optional, Pattern, Tuple

# xterm 6×6×6 color cube + grayscale (standard mapping)
_CUBE = [0, 95, 135, 175, 215, 255]


def _256_to_rgb(n: int) -> str:
    n = int(n) & 255
    if n < 16:
        base = [
            "#000000",
            "#cd3131",
            "#0dbc79",
            "#e5e510",
            "#2472c8",
            "#bc3fbc",
            "#11a8cd",
            "#e5e5e5",
            "#666666",
            "#f14c4c",
            "#23d18b",
            "#f5f543",
            "#3b8eea",
            "#d670d6",
            "#29b8db",
            "#ffffff",
        ]
        return base[n] if n < len(base) else "#e0e0e0"
    if n < 232:
        n -= 16
        r = _CUBE[(n // 36) % 6]
        g = _CUBE[(n // 6) % 6]
        b = _CUBE[n % 6]
        return f"#{r:02x}{g:02x}{b:02x}"
    gscale = 8 + (n - 232) * 10
    return f"#{gscale:02x}{gscale:02x}{gscale:02x}"


_ANSI_FG = {
    30: "#000000",
    31: "#f44336",
    32: "#4caf50",
    33: "#ffeb3b",
    34: "#2196f3",
    35: "#e91e63",
    36: "#00bcd4",
    37: "#e0e0e0",
    90: "#666666",
    91: "#ff5252",
    92: "#69f0ae",
    93: "#fff59d",
    94: "#64b5f6",
    95: "#ea80fc",
    96: "#84ffff",
    97: "#ffffff",
}
_ANSI_BG = {
    40: "#000000",
    41: "#b71c1c",
    42: "#1b5e20",
    43: "#f9a825",
    44: "#0d47a1",
    45: "#880e4f",
    46: "#006064",
    47: "#e0e0e0",
    100: "#444444",
    101: "#c62828",
    102: "#2e7d32",
    103: "#fbc02d",
    104: "#1565c0",
    105: "#6a1b9a",
    106: "#00838f",
    107: "#f5f5f5",
}

_DEFAULT_FG = "#f0f3f6"

# When the PTY has not set SGR color (default fg), tint whole lines by keywords — Moba-style log reading.
_SEMANTIC_LINE_PATTERNS: List[Tuple[Pattern[str], str]] = [
    (re.compile(r"(?i).*\b(ERROR|FATAL|CRITICAL)\b.*"), "#ff5252"),
    (re.compile(r"(?i).*\b(EXCEPTION)\b.*"), "#ef5350"),
    (re.compile(r"(?i).*\b(FAIL|FAILED|FAILURE)\b.*"), "#ff7043"),
    (re.compile(r"(?i).*\b(WARN|WARNING)\b.*"), "#ffc107"),
    (re.compile(r"(?i).*\b(DEBUG|TRACE)\b.*"), "#78909c"),
    (re.compile(r"(?i).*\b(INFO|NOTICE)\b.*"), "#66bb6a"),
    (re.compile(r"(?i).*\b(SUCCESS|PASSED)\b.*"), "#4caf50"),
    (re.compile(r"(?i).*(timed out|connection refused|connection reset|no route to host|network is unreachable).*"), "#ff5252"),
]


def _semantic_fg_for_plain_line(line: str) -> Optional[str]:
    if not (line or "").strip():
        return None
    for pat, col in _SEMANTIC_LINE_PATTERNS:
        if pat.search(line):
            return col
    return None


def _split_params(s: str) -> List[int]:
    if not s.strip():
        return [0]
    out: List[int] = []
    for part in s.split(";"):
        part = part.strip()
        if not part:
            out.append(0)
        else:
            try:
                out.append(int(part))
            except ValueError:
                out.append(0)
    return out


@dataclass
class _SgrState:
    fg: str = _DEFAULT_FG
    bg: Optional[str] = None
    bold: bool = False

    def reset(self) -> None:
        self.fg = _DEFAULT_FG
        self.bg = None
        self.bold = False

    def css(self) -> str:
        parts = [f"color:{self.fg}"]
        if self.bg:
            parts.append(f"background-color:{self.bg}")
        if self.bold:
            parts.append("font-weight:600")
        return ";".join(parts) + ";"


def preprocess_pty_stream(data: str) -> str:
    """Normalize line endings; fix dropped ESC before CSI (%[); drop NUL/BEL; keep TAB/newline."""
    if not data:
        return data
    data = data.replace("\r\n", "\n").replace("\r", "\n")
    # UART / tooling sometimes drops ESC (0x1b) so CSI shows as %[ …
    data = re.sub(r"(?<!\x1b)%\[", "\x1b[", data)
    # Saved logs / some terminals show ESC as two chars ^[ — restore real ESC for SGR
    data = re.sub(r"\^\[", "\x1b[", data)
    # OSC hyperlinks / titles — strip (QTextEdit won't interpret)
    data = re.sub(r"\x1b\][^\x07]*(\x07|\x1b\\)", "", data)
    data = re.sub(r"[\x00\x07]", "", data)
    data = re.sub(r"[\x0b\x0c\x0e-\x1a]", "", data)
    # Collapse "reset-only" lines (common embedded log pattern) that double-space the view
    data = re.sub(r"\n(?:\s*\x1b\[[0-9;]*m)+\s*\n", "\n", data)
    # Drop lone SGR resets immediately before a newline (line discipline quirk on some UARTs)
    data = re.sub(r"\x1b\[[0-9;]*m(?=\r?\n)", "", data)
    # Remove lines that contain only whitespace and ANSI SGR sequences (common in embedded logs)
    data = re.sub(r"(?m)^(?:\s|\x1b\[[0-9;]*m)+\s*$", "", data)
    # Merge runs of blank lines after stripping
    data = re.sub(r"\n{3,}", "\n\n", data)
    return data


def preprocess_escape_noise(data: str) -> str:
    """Fix ESC/CSI split across newlines and orphan escape lines (SSH, serial, embedded Linux logs)."""
    data = preprocess_pty_stream(data)
    if not data:
        return data
    # Whitespace between ESC and '[' (some stacks insert a space)
    data = re.sub(r"\x1b\s+\[", "\x1b[", data)
    # ESC and '[' were split by CR/LF (common with conhost / UART / line discipline)
    data = re.sub(r"\x1b\s*\r?\n\s*\[", "\x1b[", data)
    # Line contains only ESC (often rendered as a lone “ESC” glyph / blank line)
    data = re.sub(r"(?m)^\s*\x1b\s*$", "", data)
    # Line is only a CSI SGR body like [1;36m (ESC was on the previous line)
    data = re.sub(r"(?m)^\s*\[(?:\d{1,4};)*\d{1,4}m\s*$", "", data)
    # CSI SGR without leading ESC (UART / logging dropped 0x1b) — strip anywhere
    data = re.sub(r"(?<!\x1b)\[(?:\d{1,4};)*\d{1,4}m", "", data)
    data = re.sub(r"\n{3,}", "\n\n", data)
    return data


def preprocess_serial_stream(data: str) -> str:
    """UART / miniterm: strip reset spam and CSI fragments when ESC is dropped or echoed oddly."""
    data = preprocess_escape_noise(data)
    if not data:
        return data
    # Qt paints raw 0x1B as a visible "ESC" glyph; strip lone ESC bytes that are not CSI (\x1b[).
    data = re.sub(r"\x1b(?!\[)", "", data)
    # Full reset sequences anywhere (not only before newline)
    data = re.sub(r"\x1b\[(?:0;)?39m", "", data)
    data = re.sub(r"\x1b\[0m", "", data)
    # UART sometimes drops ESC so "[0;39m" / "[39m" appears as plain text
    data = re.sub(r"(?<!\x1b)\[(?:0;)?39m", "", data)
    data = re.sub(r"(?<!\x1b)\[0m\b", "", data)
    # Lines that contain only SGR noise
    data = re.sub(r"(?m)^(?:\s|\x1b\[[0-9;]*m|\[(?:0;)?39m|\[0m)+\s*$", "", data)
    # Newline sandwiched between resets (still doubles vertical space)
    data = re.sub(r"\n(?:\s*\x1b\[[0-9;]*m)+\s*\n", "\n", data)
    data = re.sub(r"\n{3,}", "\n\n", data)
    return data


def strip_ansi_for_log(text: str) -> str:
    """Plain text for session log files."""
    if not text:
        return text
    text = preprocess_pty_stream(text)
    text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text)
    return text


_CSI_ANY = re.compile(r"\x1b\[[\x30-\x3f\x20-\x2f]*[\x40-\x7e]")


def _csi_is_complete(tail: str) -> bool:
    if not tail or tail[0] != "\x1b":
        return True
    if len(tail) == 1:
        return False
    if tail[1] != "[":
        return True
    if len(tail) < 3:
        return False
    for j in range(2, len(tail)):
        c = tail[j]
        if "\x40" <= c <= "\x7e":
            return True
    return False


def _carry_incomplete_esc(s: str) -> Tuple[str, str]:
    """Split into (complete, carry) when the end of s is an incomplete ESC/CSI sequence."""
    if not s:
        return "", ""
    last = s.rfind("\x1b")
    if last < 0:
        return s, ""
    tail = s[last:]
    if _csi_is_complete(tail):
        return s, ""
    return s[:last], tail


class AnsiToHtmlConverter:
    """Incremental ANSI → HTML (for QTextEdit) + parallel plain text (for prompts / logs)."""

    def __init__(self) -> None:
        self._pending = ""
        self._state = _SgrState()

    def reset(self) -> None:
        self._pending = ""
        self._state = _SgrState()

    def _apply_sgr(self, params: List[int]) -> None:
        i = 0
        while i < len(params):
            n = params[i]
            if n == 0:
                self._state.reset()
                i += 1
            elif n == 1:
                self._state.bold = True
                i += 1
            elif n == 22:
                self._state.bold = False
                i += 1
            elif 30 <= n <= 37:
                self._state.fg = _ANSI_FG.get(n, _DEFAULT_FG)
                i += 1
            elif 90 <= n <= 97:
                self._state.fg = _ANSI_FG.get(n, _DEFAULT_FG)
                i += 1
            elif n == 39:
                self._state.fg = _DEFAULT_FG
                i += 1
            elif 40 <= n <= 47:
                self._state.bg = _ANSI_BG.get(n)
                i += 1
            elif 100 <= n <= 107:
                self._state.bg = _ANSI_BG.get(n)
                i += 1
            elif n == 49:
                self._state.bg = None
                i += 1
            elif n == 38 and i + 2 < len(params) and params[i + 1] == 5:
                self._state.fg = _256_to_rgb(params[i + 2])
                i += 3
            elif n == 48 and i + 2 < len(params) and params[i + 1] == 5:
                self._state.bg = _256_to_rgb(params[i + 2])
                i += 3
            elif n == 38 and i + 1 < len(params) and params[i + 1] == 2 and i + 4 < len(params):
                r, g, b = params[i + 2], params[i + 3], params[i + 4]
                self._state.fg = f"#{r & 255:02x}{g & 255:02x}{b & 255:02x}"
                i += 5
            elif n == 48 and i + 1 < len(params) and params[i + 1] == 2 and i + 4 < len(params):
                r, g, b = params[i + 2], params[i + 3], params[i + 4]
                self._state.bg = f"#{r & 255:02x}{g & 255:02x}{b & 255:02x}"
                i += 5
            else:
                i += 1

    def _span_css(self, semantic_fg: Optional[str]) -> str:
        fg = semantic_fg if semantic_fg else self._state.fg
        parts = [f"color:{fg}"]
        if self._state.bg:
            parts.append(f"background-color:{self._state.bg}")
        if self._state.bold:
            parts.append("font-weight:600")
        return ";".join(parts) + ";"

    def _emit_text(self, raw: str, html_parts: List[str], plain_parts: List[str]) -> None:
        if not raw:
            return
        plain_parts.append(raw)
        use_semantic = self._state.fg == _DEFAULT_FG and self._state.bg is None
        lines = raw.split("\n")
        for i, line in enumerate(lines):
            if i > 0:
                html_parts.append("<br/>")
            esc = html.escape(line)
            if not esc:
                continue
            sem = _semantic_fg_for_plain_line(line) if use_semantic else None
            html_parts.append(f'<span style="{self._span_css(sem)}">{esc}</span>')

    def feed(self, chunk: str) -> Tuple[str, str]:
        """Return (html_fragment, plain_text) for this chunk."""
        if not chunk:
            return "", ""
        data = self._pending + chunk
        self._pending = ""
        complete, inc = _carry_incomplete_esc(data)
        self._pending = inc

        html_parts: List[str] = []
        plain_parts: List[str] = []
        pos = 0
        for m in _CSI_ANY.finditer(complete):
            start, end = m.start(), m.end()
            if start > pos:
                self._emit_text(complete[pos:start], html_parts, plain_parts)
            seq = complete[start:end]
            if seq.endswith("m") and len(seq) >= 3:
                param_s = seq[2:-1]
                self._apply_sgr(_split_params(param_s))
            pos = end
        if pos < len(complete):
            self._emit_text(complete[pos:], html_parts, plain_parts)

        return "".join(html_parts), "".join(plain_parts)
