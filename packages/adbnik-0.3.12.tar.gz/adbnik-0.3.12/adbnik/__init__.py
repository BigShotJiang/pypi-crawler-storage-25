__version__ = "0.3.12"
APP_TITLE = "Adbnik"
