"""src/gnokee/citations.py — Per-claim bi-temporal citation envelope builder.

ADR-0016 (issue #76). Builds the `citations: dict[str, Citation]` map that
ships alongside the existing `provenance` axis (FactStatement / LabRowOut /
MedRowOut / Excerpt / EpisodeFact handles) on every MCP read response.

The host LLM emits inline `[c1]`, `[c2]`, … markers in its answer text;
gnokee guarantees every entry carries both bi-temporal axes (`valid_at` +
`asserted_at`), the episode handle, and (when the extraction stage recorded
one) a verbatim `extracted_quote` body span.

v0.5 quote semantics: `extracted_quote` ships as `None` on every row. The
extraction stage does not yet record per-fact body spans — backfill will
land in a follow-up issue. NEVER synthesise a quote from an LLM paraphrase
(ADR-0016 § Anti-patterns to avoid).

Emission order is deterministic so the same query reproduces the same
`[cN]` labels across calls:

    facts (recall)            → c1, c2, …
    excerpts (recall)         → c{n+1}, c{n+2}, …
    episode_fallback (recall) → c{n+m+1}, c{n+m+2}, …
    lab rows (lab_query)      → c1, c2, … (rows-only response)
    med rows (med_query)      → c1, c2, … (rows-only response)

exports: build_recall_citations | build_row_citations | citation_key
used_by: src/gnokee/retrieval.py | src/gnokee/lab_query.py | src/gnokee/med_query.py
rules:   pure functions; no I/O; extracted_quote is verbatim-or-None
agent:   claude-opus-4-7 | 2026-05-11 | issue #76 ADR-0016 envelope wire-up
"""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from gnokee.models import (
    Citation,
    EpisodeFact,
    Excerpt,
    FactStatement,
)


def citation_key(index: int) -> str:
    """One-based `cN` label for inline-marker indexing.

    >>> citation_key(0)
    'c1'
    >>> citation_key(4)
    'c5'
    """
    return f"c{index + 1}"


def build_recall_citations(
    *,
    facts: list[FactStatement],
    excerpts: list[Excerpt],
    episode_fallback: list[EpisodeFact],
    extracted_quotes: dict[UUID, str | None],
    excerpt_metadata: dict[UUID, tuple[datetime, datetime]],
) -> dict[str, Citation]:
    """Build the citation envelope for ``RecallResponse``.

    Three emission lanes feed citations, in this order:

    1. ``facts`` — one citation per ``FactStatement``. ``fact_uuid`` is set;
       ``episode_uuid``, ``valid_at``, ``asserted_at`` come from the fact.
    2. ``excerpts`` — one citation per ``Excerpt``. ``fact_uuid`` is ``None``
       (the excerpt is a body-span surface, not a Graphiti edge fact).
       Bi-temporal axes are looked up in ``excerpt_metadata`` keyed by
       ``episode_uuid`` — the recall pipeline supplies this from its
       in-flight ``metadata_lookup``.
    3. ``episode_fallback`` — one citation per ``EpisodeFact`` body row.
       ``fact_uuid`` is ``None`` for the same reason; bi-temporal axes come
       directly off the ``EpisodeFact`` itself.

    ``extracted_quotes`` is the per-episode verbatim body span lookup from
    ``episode_metadata.extracted_quote``. The recall pipeline supplies this
    from its in-flight ``metadata_lookup``; entries default to ``None`` in
    v0.5 because the extraction stage does not yet record body spans.

    The map is keyed ``c1``, ``c2``, … in emission order. Empty when all
    three lanes are empty (early-return paths from the recall pipeline).

    Tenant scope: this function does not filter — callers must only pass
    rows from a single tenant-scoped recall response. Tenant isolation is
    enforced upstream by the recall pipeline's ``filter_visible`` /
    ``MetadataStore`` reads, both keyed on ``tenant_id``.
    """
    citations: dict[str, Citation] = {}
    n = 0
    for f in facts:
        citations[citation_key(n)] = Citation(
            episode_uuid=f.episode_uuid,
            fact_uuid=f.fact_uuid,
            valid_at=f.valid_at,
            asserted_at=f.asserted_at,
            extracted_quote=extracted_quotes.get(f.episode_uuid),
            source_uri=None,
        )
        n += 1
    for e in excerpts:
        meta = excerpt_metadata.get(e.episode_uuid)
        if meta is None:
            # Defensive: every excerpted episode passed filter_visible →
            # has a metadata row. Skip rather than fabricate timestamps.
            continue
        valid_at, asserted_at = meta
        citations[citation_key(n)] = Citation(
            episode_uuid=e.episode_uuid,
            fact_uuid=None,
            valid_at=valid_at,
            asserted_at=asserted_at,
            extracted_quote=extracted_quotes.get(e.episode_uuid),
            source_uri=None,
        )
        n += 1
    for body in episode_fallback:
        citations[citation_key(n)] = Citation(
            episode_uuid=body.episode_uuid,
            fact_uuid=None,
            valid_at=body.valid_at,
            asserted_at=body.asserted_at,
            extracted_quote=extracted_quotes.get(body.episode_uuid),
            source_uri=None,
        )
        n += 1
    return citations


def build_row_citations(
    rows: list[tuple[UUID, datetime, datetime]],
    extracted_quotes: dict[UUID, str | None] | None = None,
) -> dict[str, Citation]:
    """Build the citation envelope for ``LabQueryResponse`` / ``MedQueryResponse``.

    One entry per emitted row, in ``rows`` order. ``fact_uuid`` is always
    ``None`` because typed-store rows live outside the Graphiti edge graph
    (they carry their own bi-temporal half-pairs at the row level).

    ``rows`` is a list of ``(episode_uuid, valid_at, asserted_at)`` triples
    so this helper does not need to import ``LabRowOut`` / ``MedRowOut``
    (keeps the citation module dependency-free).

    Scalar-only ops (``min`` / ``max`` / ``avg`` / ``count`` on lab_query)
    emit zero rows → zero citations; callers pass ``rows=[]`` and get back
    an empty map.

    ``extracted_quotes`` lookup is optional. When ``None``, every citation's
    ``extracted_quote`` is ``None`` — the v0.5 default state. The lab / med
    pipelines pass ``None`` until the extraction stage records body spans.
    """
    quotes = extracted_quotes or {}
    citations: dict[str, Citation] = {}
    for index, (episode_uuid, valid_at, asserted_at) in enumerate(rows):
        citations[citation_key(index)] = Citation(
            episode_uuid=episode_uuid,
            fact_uuid=None,
            valid_at=valid_at,
            asserted_at=asserted_at,
            extracted_quote=quotes.get(episode_uuid),
            source_uri=None,
        )
    return citations


__all__ = [
    "build_recall_citations",
    "build_row_citations",
    "citation_key",
]
