"""src/gnokee/forget.py — forget / right-to-erasure pipeline (ADR-0026 / issue #130).

Walks the supersession DAG to compute the transitive descendant closure of
a target episode, then executes the Postgres DELETE sweep and the corresponding
Neo4j cleanup in a coordinated two-phase erasure.

exports: descendants_closure | ForgetPipeline | forget_episode | forget_tenant
used_by: src/gnokee/mcp.py | src/gnokee/maintenance.py
rules:   tenant_id on every call; SERIALIZABLE Postgres tx for the
         begin+sweep+commit triple; Neo4j sweep is a separate phase;
         tz-aware UTC throughout
agent:   claude-sonnet-4-6 | 2026-05-16 | issue #130 ADR-0026 impl
         claude-sonnet-4-6 | 2026-05-16 | issue #130 ADR-0026 T7 forget_episode pipeline
         claude-sonnet-4-6 | 2026-05-16 | issue #130 ADR-0026 T8 forget_tenant pipeline with dry_run
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, cast
from uuid import UUID

import asyncpg

from gnokee.bootstrap import App
from gnokee.errors import CannotForgetChainNode, ForgetContention, ForgetNeo4jPartial
from gnokee.models import ForgetReceiptDetail
from gnokee.storage import forget_audit, locks

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Recursive CTE — walks the superseded_by chain forward.
#
# Schema convention (migration 0001):
#   episode_metadata.superseded_by = <corrector_uuid>
# meaning "this row was superseded by (corrected by) corrector_uuid".
#
# Forward walk: start at `$2` (the target), follow each row's `superseded_by`
# until the chain ends.  This yields the target itself plus all transitive
# correctors — i.e. the full descendant closure per ADR-0026 §3.1.2.
# ---------------------------------------------------------------------------
_DESCENDANTS_CTE_SQL = """
WITH RECURSIVE chain(uuid) AS (
    SELECT $2::uuid
  UNION
    SELECT em.superseded_by
      FROM episode_metadata em
      JOIN chain c ON em.episode_uuid = c.uuid
     WHERE em.tenant_id = $1 AND em.superseded_by IS NOT NULL
)
SELECT uuid FROM chain;
"""

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
_DEFAULT_SERIALIZABLE_RETRIES = 3


def _serializable_retries() -> int:
    """Return the SERIALIZABLE-retry budget for the forget pipeline.

    Read at call time from ``GNOKEE_FORGET_RETRIES`` (default ``3``) so the
    knob is not hot-reloadable mid-tx but can be raised between calls to
    ride out transient contention or lowered to fail fast. Issue #158.

    A non-positive or non-integer env value falls back to the default —
    we never want to set this to zero by accident (which would skip the
    retry loop entirely and propagate the first ``SerializationError``).
    """
    raw = os.getenv("GNOKEE_FORGET_RETRIES")
    if raw is None:
        return _DEFAULT_SERIALIZABLE_RETRIES
    try:
        value = int(raw)
    except ValueError:
        log.warning(
            "gnokee.forget: GNOKEE_FORGET_RETRIES=%r is not an int — using default %d",
            raw,
            _DEFAULT_SERIALIZABLE_RETRIES,
        )
        return _DEFAULT_SERIALIZABLE_RETRIES
    if value < 1:
        log.warning(
            "gnokee.forget: GNOKEE_FORGET_RETRIES=%d is < 1 — using default %d",
            value,
            _DEFAULT_SERIALIZABLE_RETRIES,
        )
        return _DEFAULT_SERIALIZABLE_RETRIES
    return value


def _now() -> datetime:
    """Return current time as tz-aware UTC datetime."""
    return datetime.now(timezone.utc)


async def descendants_closure(
    conn: asyncpg.Connection,
    *,
    tenant_id: str,
    episode_uuid: UUID,
) -> list[UUID]:
    """Return target uuid + transitive descendant set via ``superseded_by``.

    Pure topology — no temporal predicate (ADR-0026 §6.1).  Walks the
    chain ``self.superseded_by → corrector → corrector's_corrector …``
    in forward order.

    Takes an asyncpg ``Connection`` (not a ``Pool``) so the caller can
    bind the walk to the SERIALIZABLE transaction that will execute the
    DELETE — required to avoid a concurrent ingest adding a new
    descendant after this returns. Issue #157 — the pre-#157 helper
    acquired its own connection from the pool, silently breaking the
    docstring's transactional guarantee.

    `_episode_postgres_phase` does not call this helper — it walks the
    same CTE inline (`conn.fetch(_DESCENDANTS_CTE_SQL, …)`) inside its
    own SERIALIZABLE tx. The helper remains exported for operator
    scripts / test harnesses that need the closure in isolation.
    """
    rows = await conn.fetch(_DESCENDANTS_CTE_SQL, tenant_id, episode_uuid)
    return [r["uuid"] for r in rows]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


class ForgetPipeline:
    """Orchestrates the two-phase erasure (Postgres + Neo4j) — T7/T8."""


async def forget_episode(
    app: App,
    *,
    tenant_id: str,
    episode_uuid: UUID,
    cascade: bool,
    reason: str,
    actor: str | None = None,
) -> ForgetReceiptDetail:
    """Hard-delete a single episode (and optionally its supersession
    descendants) across pgvector + Graphiti/Neo4j with verifiable audit.

    See ADR-0026 / spec §3.1 + §5 for semantics.

    Raises:
        CannotForgetChainNode: episode has descendants and cascade=False.
        ForgetContention: SERIALIZABLE retry budget exhausted.
        ForgetNeo4jPartial: Postgres committed but Neo4j sweep failed.
    """
    # 1. Idempotency check — prior commit returns cached receipt
    prior = await forget_audit.find_prior_commit(
        app.pool,
        tenant_id=tenant_id,
        scope="episode",
        episode_uuid=episode_uuid,
    )
    if prior is not None and prior.receipt is not None:
        return _detail_from_audit(prior, replayed=True)

    # 2. Postgres txn with SERIALIZABLE retry
    last_exc: BaseException | None = None
    audit_id: UUID
    detail: ForgetReceiptDetail
    cascade_uuids: list[UUID]
    for _attempt in range(_serializable_retries()):
        try:
            audit_id, detail, cascade_uuids = await _episode_postgres_phase(
                app,
                tenant_id=tenant_id,
                episode_uuid=episode_uuid,
                cascade=cascade,
                reason=reason,
                actor=actor,
            )
            break
        except asyncpg.exceptions.SerializationError as exc:
            last_exc = exc
            await asyncio.sleep(0.05 * (_attempt + 1))
            continue
    else:
        raise ForgetContention(tenant_id=tenant_id, cause=last_exc) from last_exc

    # 3. Neo4j phase — outside the Postgres tx, best-effort post-commit
    try:
        n4j_counts = await app.graph_store.remove_episodes_by_uuid(
            tenant_id=tenant_id,
            episode_uuids=cascade_uuids,
        )
    except Exception as exc:
        await forget_audit.mark_fail(
            app.pool,
            audit_id=audit_id,
            error={
                "kind": "neo4j_partial",
                "linked_audit_id": str(audit_id),
                "message": str(exc),
            },
        )
        raise ForgetNeo4jPartial(audit_id=str(audit_id), cause=exc) from exc

    detail = detail.model_copy(
        update={
            "neo4j_nodes_deleted": {k: v for k, v in n4j_counts.items() if k != "edges_total"},
            "neo4j_edges_deleted": {"total": n4j_counts.get("edges_total", 0)},
            "summary": _summary_episode(detail),
        },
    )
    await forget_audit.mark_commit(
        app.pool,
        audit_id=audit_id,
        receipt=detail.model_dump(mode="json"),
    )
    return detail


async def forget_tenant(
    app: App,
    *,
    tenant_id: str,
    dry_run: bool,
    reason: str,
    actor: str | None = None,
) -> ForgetReceiptDetail:
    """Hard-delete the entire tenant. ``dry_run=True`` (default) returns a
    planned ForgetReceiptDetail with no writes — caller must invoke a
    second time with ``dry_run=False`` to actually destroy.

    Closes #130: explicit DELETE on ingest_journal alongside the cascade
    via episode_metadata's FK chain.

    Raises:
        ForgetContention: SERIALIZABLE retry budget exhausted.
        ForgetNeo4jPartial: Postgres committed but Neo4j sweep failed.
    """
    if dry_run:
        return await _forget_tenant_dry_run(app, tenant_id=tenant_id, reason=reason, actor=actor)

    # Idempotency check — prior commit returns cached receipt
    prior = await forget_audit.find_prior_commit(
        app.pool,
        tenant_id=tenant_id,
        scope="tenant",
        episode_uuid=None,
    )
    if prior is not None and prior.receipt is not None:
        return _detail_from_audit(prior, replayed=True)

    # SERIALIZABLE-retry loop
    last_exc: BaseException | None = None
    audit_id: UUID
    detail: ForgetReceiptDetail
    for _attempt in range(_serializable_retries()):
        try:
            audit_id, detail = await _tenant_postgres_phase(
                app,
                tenant_id=tenant_id,
                reason=reason,
                actor=actor,
            )
            break
        except asyncpg.exceptions.SerializationError as exc:
            last_exc = exc
            await asyncio.sleep(0.05 * (_attempt + 1))
            continue
    else:
        raise ForgetContention(tenant_id=tenant_id, cause=last_exc) from last_exc

    # Neo4j phase — outside Postgres tx, best-effort post-commit
    try:
        n4j_counts = await app.graph_store.remove_tenant_group(
            tenant_id=tenant_id,
            chunk_threshold=app.settings.neo4j_detach_chunk_threshold,
            chunk_size=app.settings.neo4j_detach_chunk_size,
        )
    except Exception as exc:
        await forget_audit.mark_fail(
            app.pool,
            audit_id=audit_id,
            error={
                "kind": "neo4j_partial",
                "linked_audit_id": str(audit_id),
                "message": str(exc),
            },
        )
        raise ForgetNeo4jPartial(audit_id=str(audit_id), cause=exc) from exc

    _chunk_keys = {"edges_total", "chunks_executed", "chunk_size", "pre_count"}
    chunk_meta: dict[str, int] | None = None
    if "chunks_executed" in n4j_counts:
        chunk_meta = {
            "chunks_executed": int(n4j_counts["chunks_executed"]),
            "chunk_size": int(n4j_counts["chunk_size"]),
            "pre_count": int(n4j_counts["pre_count"]),
        }

    detail = detail.model_copy(
        update={
            "neo4j_nodes_deleted": {k: v for k, v in n4j_counts.items() if k not in _chunk_keys},
            "neo4j_edges_deleted": {"total": n4j_counts.get("edges_total", 0)},
            "neo4j_chunked": chunk_meta,
            "summary": _summary_tenant(detail),
        },
    )
    await forget_audit.mark_commit(
        app.pool,
        audit_id=audit_id,
        receipt=detail.model_dump(mode="json"),
    )
    return detail


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


async def _episode_postgres_phase(
    app: App,
    *,
    tenant_id: str,
    episode_uuid: UUID,
    cascade: bool,
    reason: str,
    actor: str | None,
) -> tuple[UUID, ForgetReceiptDetail, list[UUID]]:
    """Stages 2–6 inside one SERIALIZABLE Postgres tx.

    Returns (audit_id, detail-without-neo4j-fields-yet, cascade_uuids).

    Raises CannotForgetChainNode BEFORE beginning the transaction when
    descendants exist and cascade=False (no audit row on refusal).
    """
    async with app.pool.acquire() as conn:
        async with conn.transaction(isolation="serializable"):
            # Tenant GUC for any row-level hooks/policies. Parameterised via
            # `set_config(name, value, is_local=true)` — transaction-local,
            # releases when this tx commits/rolls back. `SET LOCAL` does not
            # accept positional placeholders, so the prior f-string was an
            # injection surface gated only by quote-doubling — fixed under
            # issue #157.
            await conn.execute(
                "SELECT set_config('app.current_tenant', $1, true)",
                tenant_id,
            )

            # Issue #140: exclusive forget lock — waits for any in-flight
            # ingest Stage-5 transaction on this tenant to commit / roll back
            # before proceeding. Transaction-scoped — releases on commit.
            # Issue #153: bounded wait — raises ForgetContention if no
            # shared holder releases within `forget_lock_timeout_ms`.
            await locks.acquire_forget_exclusive_with_timeout(
                conn,
                tenant_id,
                timeout_ms=app.settings.forget_lock_timeout_ms,
            )

            # 2. DAG walk inside tx
            descendants_rows = await conn.fetch(_DESCENDANTS_CTE_SQL, tenant_id, episode_uuid)
            cascade_set: list[UUID] = [r["uuid"] for r in descendants_rows]
            non_target = [u for u in cascade_set if u != episode_uuid]
            if non_target and not cascade:
                deepest = non_target[-1]
                raise CannotForgetChainNode(
                    descendant_count=len(non_target),
                    deepest_descendant_uuid=str(deepest),
                )
            scope_set: list[UUID] = cascade_set if cascade else [episode_uuid]

            # 3. Pre-DELETE captures (key_ids + bitemporal snap) under SELECT FOR UPDATE
            key_ids_rows = await conn.fetch(
                "SELECT key_id FROM episode_body_encrypted "
                "WHERE tenant_id = $1 AND episode_uuid = ANY($2::uuid[]) FOR SHARE",
                tenant_id,
                [str(u) for u in scope_set],
            )
            key_ids = [r["key_id"] for r in key_ids_rows]
            snap_rows = await conn.fetch(
                "SELECT episode_uuid, asserted_at, valid_at, valid_until "
                "  FROM episode_metadata "
                " WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[]) "
                "FOR UPDATE",
                tenant_id,
                [str(u) for u in scope_set],
            )
            snap = [
                {
                    "episode_uuid": str(r["episode_uuid"]),
                    "asserted_at": (r["asserted_at"].isoformat() if r["asserted_at"] else None),
                    "valid_at": (r["valid_at"].isoformat() if r["valid_at"] else None),
                    "valid_until": (r["valid_until"].isoformat() if r["valid_until"] else None),
                }
                for r in snap_rows
            ]

            # 4. Audit begin row — inside the tx for atomicity with the sweep
            audit_id = await _insert_begin_in_conn(
                conn,
                tenant_id=tenant_id,
                scope="episode",
                episode_uuid=episode_uuid,
                cascade=cascade,
                dry_run=False,
                reason=reason,
                actor=actor,
                cascade_uuids=[str(u) for u in scope_set],
                bitemporal_snap=snap,
            )

            # 5. Ancestor pointer cleanup BEFORE delete (spec §6.2)
            #    Nullify superseded_by on any row whose pointer targeted a scope member
            await conn.execute(
                "UPDATE episode_metadata SET superseded_by = NULL "
                " WHERE tenant_id=$1 AND superseded_by = ANY($2::uuid[])",
                tenant_id,
                [str(u) for u in scope_set],
            )

            # 6. Postgres sweep — delete in dependency order.
            #
            # fact_contradiction uses fact_uuid_a / fact_uuid_b (Graphiti
            # EntityEdge UUIDs, per 0003_fact_contradiction.sql), NOT
            # episode_uuid. Issue #218: the previous DELETE matched the
            # episode-UUID `scope_set` directly against the fact-UUID
            # columns and silently affected zero rows. Resolve via
            # `fact_revision` (0019), which carries every (tenant_id,
            # episode_uuid, fact_uuid) binding gnokee minted. Deletion is
            # the union over both endpoints — a contradiction row dangles
            # the moment EITHER half's fact is removed.
            await conn.execute(
                """
                DELETE FROM fact_contradiction
                 WHERE tenant_id = $1
                   AND (
                        fact_uuid_a IN (
                            SELECT fact_uuid FROM fact_revision
                             WHERE tenant_id = $1
                               AND episode_uuid = ANY($2::uuid[])
                        )
                     OR fact_uuid_b IN (
                            SELECT fact_uuid FROM fact_revision
                             WHERE tenant_id = $1
                               AND episode_uuid = ANY($2::uuid[])
                        )
                   )
                """,
                tenant_id,
                [str(u) for u in scope_set],
            )
            await conn.execute(
                "DELETE FROM ingest_journal  WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[])",
                tenant_id,
                [str(u) for u in scope_set],
            )
            del_metadata = await conn.execute(
                "DELETE FROM episode_metadata  WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[])",
                tenant_id,
                [str(u) for u in scope_set],
            )

    now = _now()
    detail = ForgetReceiptDetail(
        audit_id=audit_id,
        tenant_id=tenant_id,
        scope="episode",
        episode_uuid=episode_uuid,
        cascade=cascade,
        dry_run=False,
        summary="",  # filled after Neo4j phase
        affected_episode_count=len(scope_set),
        deepest_episode_uuid=(scope_set[-1] if cascade and len(scope_set) > 1 else None),
        affected_key_ids=key_ids,
        replayed=False,
        started_at=now,
        finished_at=now,
        actor=actor,
        reason=reason,
        postgres_rows_deleted={
            "episode_metadata": int(del_metadata.split()[-1]),
        },
        cascaded_episode_uuids=scope_set if cascade else [],
        partial=False,
        bitemporal_snap=snap,
    )
    return audit_id, detail, scope_set


async def _insert_begin_in_conn(
    conn: asyncpg.Connection,
    *,
    tenant_id: str,
    scope: str,
    episode_uuid: UUID | None,
    cascade: bool,
    dry_run: bool,
    reason: str,
    actor: str | None,
    cascade_uuids: list[str] | None,
    bitemporal_snap: list[dict[str, Any]] | None,
) -> UUID:
    """In-transaction INSERT; mirror of storage.forget_audit.insert_begin
    that does NOT acquire a fresh connection (stays in the open tx)."""
    row = await conn.fetchrow(
        """
        INSERT INTO gnokee_maintenance.forget_audit
            (tenant_id, scope, episode_uuid, cascade, dry_run, state,
             reason, actor, cascade_uuids, bitemporal_snap)
        VALUES ($1, $2, $3, $4, $5, 'begin', $6, $7, $8, $9)
        RETURNING audit_id;
        """,
        tenant_id,
        scope,
        episode_uuid,
        cascade,
        dry_run,
        reason,
        actor,
        json.dumps(cascade_uuids) if cascade_uuids is not None else None,
        json.dumps(bitemporal_snap) if bitemporal_snap is not None else None,
    )
    assert row is not None
    return cast(UUID, row["audit_id"])


def _summary_episode(detail: ForgetReceiptDetail) -> str:
    pg_rows = sum(detail.postgres_rows_deleted.values())
    n_nodes = sum(detail.neo4j_nodes_deleted.values())
    n_edges = sum(detail.neo4j_edges_deleted.values())
    return (
        f"Deleted {detail.affected_episode_count} episode(s): "
        f"{pg_rows} Postgres rows, {n_nodes} Neo4j nodes, {n_edges} Neo4j edges."
    )


def _detail_from_audit(row: Any, *, replayed: bool) -> ForgetReceiptDetail:
    """Reconstruct a ForgetReceiptDetail from a cached audit row."""
    receipt = row.receipt or {}
    return ForgetReceiptDetail(**{**receipt, "replayed": replayed})


async def _forget_tenant_dry_run(
    app: App,
    *,
    tenant_id: str,
    reason: str,
    actor: str | None,
) -> ForgetReceiptDetail:
    """Pure SELECTs — no audit row, no writes. Returns an ephemeral planned receipt."""
    from uuid import uuid4

    async with app.pool.acquire() as conn:
        async with conn.transaction():
            # Issue #154: dry-run SELECTs run under the same RLS GUC as the
            # destructive forget path so that the day a permissive RLS policy
            # lands the operator does not get all-zero counts (which would
            # invite "tenant must be empty" → destructive call against a
            # fully-populated tenant).
            # Issue #157: parameterised set_config(..., true) — transaction-
            # local; no f-string interpolation of tenant_id.
            await conn.execute(
                "SELECT set_config('app.current_tenant', $1, true)",
                tenant_id,
            )
            n_episodes = await conn.fetchval(
                "SELECT count(*) FROM episode_metadata WHERE tenant_id = $1",
                tenant_id,
            )
            key_id_rows = await conn.fetch(
                "SELECT DISTINCT key_id FROM episode_body_encrypted WHERE tenant_id = $1",
                tenant_id,
            )

    key_ids = [r["key_id"] for r in key_id_rows]
    n_episodes = int(n_episodes or 0)
    now = _now()
    summary = f"PLANNED (dry_run): tenant '{tenant_id}' — {n_episodes} episodes, {len(key_ids)} encrypted DEKs."
    return ForgetReceiptDetail(
        audit_id=uuid4(),
        tenant_id=tenant_id,
        scope="tenant",
        episode_uuid=None,
        cascade=False,
        dry_run=True,
        summary=summary,
        affected_episode_count=n_episodes,
        deepest_episode_uuid=None,
        affected_key_ids=key_ids,
        replayed=False,
        started_at=now,
        finished_at=now,
        actor=actor,
        reason=reason,
        postgres_rows_deleted={},
        neo4j_nodes_deleted={},
        neo4j_edges_deleted={},
        cascaded_episode_uuids=[],
        partial=False,
        bitemporal_snap=[],
    )


async def _tenant_postgres_phase(
    app: App,
    *,
    tenant_id: str,
    reason: str,
    actor: str | None,
) -> tuple[UUID, ForgetReceiptDetail]:
    """All Postgres writes for a tenant forget in one SERIALIZABLE tx.

    Returns (audit_id, detail-without-neo4j-fields-yet).
    """
    async with app.pool.acquire() as conn:
        async with conn.transaction(isolation="serializable"):
            # Issue #157: parameterised set_config(..., true) — transaction-
            # local; no f-string interpolation of tenant_id.
            await conn.execute(
                "SELECT set_config('app.current_tenant', $1, true)",
                tenant_id,
            )

            # Issue #140: exclusive forget lock — see _episode_postgres_phase
            # for rationale. Issue #153 bounded wait — see helper docstring.
            await locks.acquire_forget_exclusive_with_timeout(
                conn,
                tenant_id,
                timeout_ms=app.settings.forget_lock_timeout_ms,
            )

            # Capture key_ids before delete
            key_id_rows = await conn.fetch(
                "SELECT DISTINCT key_id FROM episode_body_encrypted WHERE tenant_id = $1",
                tenant_id,
            )
            key_ids = [r["key_id"] for r in key_id_rows]

            # Bitemporal snapshot
            snap_rows = await conn.fetch(
                "SELECT episode_uuid, asserted_at, valid_at, valid_until   FROM episode_metadata WHERE tenant_id = $1",
                tenant_id,
            )
            snap = [
                {
                    "episode_uuid": str(r["episode_uuid"]),
                    "asserted_at": (r["asserted_at"].isoformat() if r["asserted_at"] else None),
                    "valid_at": (r["valid_at"].isoformat() if r["valid_at"] else None),
                    "valid_until": (r["valid_until"].isoformat() if r["valid_until"] else None),
                }
                for r in snap_rows
            ]
            n_episodes = len(snap)

            # Audit begin row — atomically inside the sweep tx
            audit_id = await _insert_begin_in_conn(
                conn,
                tenant_id=tenant_id,
                scope="tenant",
                episode_uuid=None,
                cascade=False,
                dry_run=False,
                reason=reason,
                actor=actor,
                cascade_uuids=None,
                bitemporal_snap=snap,
            )

            # Sweep in spec §5.3 order: fact_contradiction → ingest_journal → episode_metadata
            # (FK CASCADE handles: content_embedding, content_text, episode_body_encrypted,
            #  episode_extracted_quote, lab_record, med_record)
            await conn.execute(
                "DELETE FROM fact_contradiction WHERE tenant_id = $1",
                tenant_id,
            )
            await conn.execute(
                "DELETE FROM ingest_journal WHERE tenant_id = $1",
                tenant_id,
            )
            # ADR-0027 / issue #197 — short_id_map + short_id_seq carry the
            # tenant's UUID ↔ short-ID bindings. The episode-grain forget
            # KEEPS these rows (audit-decodability rationale, ADR-0027
            # § Retention). Tenant-grain forget sweeps them — at this
            # point the tenant ceases to exist, so the bindings have no
            # audit consumer left.
            await conn.execute(
                "DELETE FROM short_id_map WHERE tenant_id = $1",
                tenant_id,
            )
            await conn.execute(
                "DELETE FROM short_id_seq WHERE tenant_id = $1",
                tenant_id,
            )
            del_metadata = await conn.execute(
                "DELETE FROM episode_metadata WHERE tenant_id = $1",
                tenant_id,
            )

    now = _now()
    detail = ForgetReceiptDetail(
        audit_id=audit_id,
        tenant_id=tenant_id,
        scope="tenant",
        episode_uuid=None,
        cascade=False,
        dry_run=False,
        summary="",  # filled after Neo4j phase
        affected_episode_count=n_episodes,
        deepest_episode_uuid=None,
        affected_key_ids=key_ids,
        replayed=False,
        started_at=now,
        finished_at=now,
        actor=actor,
        reason=reason,
        postgres_rows_deleted={
            "episode_metadata": int(del_metadata.split()[-1]),
        },
        cascaded_episode_uuids=[],
        partial=False,
        bitemporal_snap=snap,
    )
    return audit_id, detail


def _summary_tenant(detail: ForgetReceiptDetail) -> str:
    pg_rows = sum(detail.postgres_rows_deleted.values())
    n_nodes = sum(detail.neo4j_nodes_deleted.values())
    n_edges = sum(detail.neo4j_edges_deleted.values())
    return (
        f"Deleted tenant '{detail.tenant_id}': "
        f"{detail.affected_episode_count} episode(s), "
        f"{pg_rows} Postgres rows, {n_nodes} Neo4j nodes, {n_edges} Neo4j edges."
    )
