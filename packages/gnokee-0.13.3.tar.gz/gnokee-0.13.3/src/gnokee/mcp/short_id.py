"""src/gnokee/mcp/short_id.py — UUID ↔ short-ID translation at the MCP boundary.

Per ADR-0027 (issue #197). Every gnokee_* MCP tool replaces raw 36-char
UUID strings with stable per-tenant per-kind monotonic short IDs
(`ep_017`, `fact_042`, `ent_005`) before emitting. Input parameters
accept both forms — ``parse_short_or_uuid`` decodes whichever shape the
caller supplied.

Concurrency posture: ``encode`` is called inside the existing ingest /
recall tx but acquires its own connection from the pool and runs a
short tx-scoped advisory lock keyed on hashtext(tenant_id) +
hashtext(kind) before the counter bump + INSERT … ON CONFLICT DO
NOTHING + re-read. The re-read makes the function idempotent under any
rare advisory-lock collision (different (tenant, kind) pairs that
hashtext to the same key); concurrent first-emits agree on the same
short_id regardless.

exports: encode | decode | parse_short_or_uuid | SHORT_ID_RE | ShortIdKind
used_by: src/gnokee/mcp/__init__.py
rules:   tenant_id + kind mandatory on every encode; never let `None`
         flow into storage; raise ValidationError on unknown short_id
         so callers see a clean error instead of silent None
agent:   claude-opus-4-7 | 2026-05-17 | issue #197 / ADR-0027
"""

from __future__ import annotations

import re
from typing import Final, Literal
from uuid import UUID

import asyncpg

from gnokee.errors import ValidationError

ShortIdKind = Literal["ep", "fact", "ent"]

# `^[a-z]+_\d+$` — accept any lowercase-alpha prefix + underscore + digits.
# The prefix is validated against the {ep, fact, ent} vocabulary inside
# `decode` so we get a tight ValidationError on `foo_42`-style input.
SHORT_ID_RE: Final[re.Pattern[str]] = re.compile(r"^[a-z]+_\d+$")

_VALID_PREFIXES: Final[frozenset[str]] = frozenset({"ep", "fact", "ent"})


async def encode(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    kind: ShortIdKind,
    target_uuid: UUID,
) -> str:
    """Return the short_id for (tenant_id, kind, target_uuid).

    Idempotent: repeated calls with the same triple return the same
    string. Concurrent first-emits across multiple connections agree on
    the same short_id via the (tenant_id, kind) advisory lock + the
    ``INSERT … ON CONFLICT DO NOTHING`` + re-read pattern.

    The counter row in ``short_id_seq`` is the source of truth for the
    next sequence number per (tenant, kind). The map row in
    ``short_id_map`` is the cached binding; once a UUID has a short_id,
    subsequent encodes hit the unique index and return the cached value
    without bumping the counter.
    """
    if kind not in _VALID_PREFIXES:
        raise ValidationError(f"short_id.encode: invalid kind {kind!r}; expected one of {_VALID_PREFIXES}")

    async with pool.acquire() as conn:
        async with conn.transaction():
            # Fast-path: already encoded.  Cheap point-lookup on the PK.
            cached = await conn.fetchval(
                "SELECT short_id FROM short_id_map WHERE tenant_id = $1 AND target_kind = $2 AND target_uuid = $3",
                tenant_id,
                kind,
                target_uuid,
            )
            if cached is not None:
                return str(cached)

            # Slow-path: first emit. Serialise per (tenant, kind) so two
            # concurrent first-emits of *different* UUIDs do not collide
            # on the same next_seq. Transaction-scoped advisory lock —
            # auto-releases at COMMIT/ROLLBACK. hashtext keeps the pair
            # of bigints compact.
            await conn.execute(
                "SELECT pg_advisory_xact_lock(hashtext($1), hashtext($2))",
                tenant_id,
                kind,
            )

            # Re-check after taking the lock — another writer may have
            # populated the row while we waited for the advisory lock.
            cached = await conn.fetchval(
                "SELECT short_id FROM short_id_map WHERE tenant_id = $1 AND target_kind = $2 AND target_uuid = $3",
                tenant_id,
                kind,
                target_uuid,
            )
            if cached is not None:
                return str(cached)

            # Counter bump — UPSERT-style. The INSERT seeds the row at 2
            # when no row exists yet (we'll use seq=1 below); subsequent
            # calls bump next_seq and return the value we just consumed.
            seq_row = await conn.fetchrow(
                "INSERT INTO short_id_seq (tenant_id, target_kind, next_seq) "
                "VALUES ($1, $2, 2) "
                "ON CONFLICT (tenant_id, target_kind) DO UPDATE "
                "  SET next_seq = short_id_seq.next_seq + 1 "
                "RETURNING next_seq",
                tenant_id,
                kind,
            )
            assert seq_row is not None
            # next_seq returned is the value AFTER the bump; the seq we
            # just consumed is (returned - 1). On first insert we seeded
            # at 2 and consume 1.
            consumed: int = int(seq_row["next_seq"]) - 1
            short_id = f"{kind}_{consumed}"

            # Bind the UUID to the short_id. ON CONFLICT DO NOTHING is
            # the safety belt against a concurrent first-emit that
            # somehow slipped past the advisory lock (e.g. hashtext
            # collision under adversarial inputs). The re-read below
            # makes both writers agree on the SAME short_id.
            await conn.execute(
                "INSERT INTO short_id_map "
                "  (tenant_id, target_kind, target_uuid, short_id, seq) "
                "VALUES ($1, $2, $3, $4, $5) "
                "ON CONFLICT (tenant_id, target_kind, target_uuid) DO NOTHING",
                tenant_id,
                kind,
                target_uuid,
                short_id,
                consumed,
            )

            # Re-read: if ON CONFLICT swallowed our INSERT, the cached
            # row's short_id wins. Either way both callers return the
            # same value.
            final = await conn.fetchval(
                "SELECT short_id FROM short_id_map WHERE tenant_id = $1 AND target_kind = $2 AND target_uuid = $3",
                tenant_id,
                kind,
                target_uuid,
            )
            assert final is not None, "short_id row vanished after INSERT — impossible under tx"
            return str(final)


async def decode(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    short_id: str,
) -> UUID:
    """Return the UUID bound to (tenant_id, short_id), or raise ValidationError.

    Tight failure mode: any input that does not match SHORT_ID_RE, or
    that does match but has an unknown prefix, or that does match a
    known prefix but does not exist in the map for this tenant — all
    raise ValidationError. Callers see a clean error rather than a
    silent None that would later look like "UUID not found".
    """
    if not SHORT_ID_RE.match(short_id):
        raise ValidationError(f"short_id.decode: not a short_id {short_id!r}")
    prefix = short_id.split("_", 1)[0]
    if prefix not in _VALID_PREFIXES:
        raise ValidationError(
            f"short_id.decode: unknown prefix {prefix!r} in {short_id!r}; expected one of {_VALID_PREFIXES}"
        )
    async with pool.acquire() as conn:
        row_uuid = await conn.fetchval(
            "SELECT target_uuid FROM short_id_map WHERE tenant_id = $1 AND short_id = $2",
            tenant_id,
            short_id,
        )
    if row_uuid is None:
        raise ValidationError(f"short_id.decode: no such short_id {short_id!r} for tenant {tenant_id!r}")
    if isinstance(row_uuid, UUID):
        return row_uuid
    return UUID(str(row_uuid))


async def parse_short_or_uuid(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    value: str,
) -> UUID:
    """Accept either a short_id or a raw UUID string; return UUID.

    The MCP layer's accept-both input contract. Order: short_id form is
    checked first (regex match → decode); if regex does not match, fall
    back to ``uuid.UUID(value)`` parsing. Any failure mode raises
    ValidationError with a message that names the input.
    """
    if SHORT_ID_RE.match(value):
        return await decode(pool, tenant_id=tenant_id, short_id=value)
    try:
        return UUID(value)
    except (ValueError, AttributeError) as exc:
        raise ValidationError(f"parse_short_or_uuid: not a short_id or UUID: {value!r}") from exc


__all__ = [
    "SHORT_ID_RE",
    "ShortIdKind",
    "decode",
    "encode",
    "parse_short_or_uuid",
]
