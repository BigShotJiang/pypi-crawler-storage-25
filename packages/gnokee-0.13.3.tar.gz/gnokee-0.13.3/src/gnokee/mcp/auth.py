"""src/gnokee/mcp/auth.py — pluggable authentication surface for MCP server.

Per ADR-0030 (issue #244). Library-mode default (``auth=None`` on
``build_server``) preserves the v0.1 trust contract — caller-supplied
``tenant_id`` is trusted because the caller IS gnokee's trust boundary
(library callers in-process; stdio MCP subprocess). Production mode
binds a verified ``Principal`` to a contextvar; the per-tool guard
rejects any ``tenant_id`` outside ``Principal.allowed_tenants`` BEFORE
the tool body runs.

Integration with upstream ``mcp`` library: ``MCPTokenVerifier`` adapts
gnokee's ``AuthBackend`` to upstream's ``TokenVerifier`` Protocol so
``FastMCP(token_verifier=MCPTokenVerifier(backend))`` wires the
``BearerAuthBackend`` + ``AuthContextMiddleware`` Starlette chain
automatically (gate-2 finding, ADR-0030 §"What `mcp` library already
gives us").

exports: AuthBackend | Principal | AuthError | BearerJWTBackend |
         MCPTokenVerifier | current_principal | TENANT_SCOPE_PREFIX
used_by: src/gnokee/mcp/__init__.py (build_server keyword arg `auth`;
         per-tool `_tenant_guard` decorator)
rules:   gnokee verifies tokens; never issues, stores, refreshes, or
         revokes (AGENTS.md "do not host identity / do not host keys"
         invariant). AuthError.code MUST be 401 (verify-time) or 403
         (guard-time); no other codes. ``allowed_tenants`` empty set
         is legal (closed-fail principal) and distinct from ``auth=None``
         (library-mode, accept any tenant_id). Logging MUST NOT emit
         ``Principal.claims`` — subject + rejected tenant_id only.
agent:   claude-opus-4-7 | 2026-05-20 | issue #244 / ADR-0030
"""

from __future__ import annotations

import logging
import time
from collections.abc import Mapping
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

log = logging.getLogger(__name__)


TENANT_SCOPE_PREFIX = "tenant:"
"""Prefix gnokee uses when packing ``Principal.allowed_tenants`` into the
upstream ``mcp.server.auth.provider.AccessToken.scopes`` list. The
``MCPTokenVerifier`` adapter emits ``tenant:<id>`` for each allowed
tenant. The per-tool guard reads gnokee's own contextvar rather than
parsing scopes, but the encoding is documented + stable so upstream
clients reading ``AccessToken.scopes`` see a consistent shape."""


@dataclass(frozen=True)
class Principal:
    """Verified identity for one MCP request.

    Lifetime: bound to a single request via ``_current_principal``
    contextvar; never persisted.
    """

    subject: str
    """Opaque identifier (JWT ``sub``, mTLS CN, etc.). Stable per identity.
    Logged on auth-rejection lines."""

    allowed_tenants: frozenset[str]
    """The set of ``tenant_id`` values this principal may pass on tool
    calls. A request that names any ``tenant_id`` outside this set is
    rejected with 403 (per-tool guard). Empty set is legal (closed-fail
    principal — all tool calls fail) and is distinct from ``auth=None``
    (library mode — accept any ``tenant_id``)."""

    claims: Mapping[str, Any] = field(default_factory=dict)
    """Raw verified claims (JWT body, mTLS cert extensions, etc.).
    Available to downstream audit logging. Read-only — do NOT route
    business logic off custom claims without lifting them into a typed
    field on Principal. MUST NOT be emitted in log lines."""


class AuthError(Exception):
    """Raised by ``AuthBackend.verify`` and the per-tool guard.

    ``code`` MUST be 401 (auth material missing/invalid; verify-time) or
    403 (auth material valid but principal not authorized for the
    requested tenant_id; guard-time). No other codes.
    """

    def __init__(self, code: int, detail: str) -> None:
        if code not in (401, 403):
            raise ValueError(f"AuthError.code must be 401 or 403, got {code}")
        self.code = code
        self.detail = detail
        super().__init__(detail)


@runtime_checkable
class AuthBackend(Protocol):
    """Verifies the request's authentication material and returns a Principal.

    Implementations MUST be stateless across requests (or carry their
    own cache). They MUST raise ``AuthError(401, ...)`` on any
    verification failure; they MUST NOT return ``None`` to indicate
    failure.

    The Protocol is intentionally Header-shaped (not Starlette-Request-
    shaped) so backends can be tested + reused outside the FastMCP
    integration.
    """

    async def verify(self, *, request_headers: Mapping[str, str]) -> Principal: ...


_current_principal: ContextVar[Principal | None] = ContextVar("gnokee_mcp_current_principal", default=None)
"""Request-scoped principal binding. Set by ``MCPTokenVerifier`` on
successful upstream ``verify_token`` call; read by the per-tool
``_tenant_guard`` decorator. Default ``None`` = library mode (no auth
attached) — guard is a no-op."""


def current_principal() -> Principal | None:
    """Return the Principal bound to this request, or ``None`` in library mode."""
    return _current_principal.get()


# --------------------------------------------------------------------------
# BearerJWTBackend — reference impl, pyjwt-backed
# --------------------------------------------------------------------------


_ASYMMETRIC_ALGS = frozenset({"RS256", "RS384", "RS512", "ES256", "ES384", "ES512", "PS256", "PS384", "PS512"})
"""Public-key signature algorithms. ``public_key`` MUST be a PEM-encoded
verification key for these."""

_SYMMETRIC_ALGS = frozenset({"HS256", "HS384", "HS512"})
"""HMAC algorithms. ``public_key`` MUST be a shared secret string — NOT
a PEM. v0.12 hard rule: gnokee refuses HS* unless ``_allow_hmac=True``
is passed explicitly. Rationale in ``__post_init__`` docstring."""

_ALLOWED_ALGS = _ASYMMETRIC_ALGS | _SYMMETRIC_ALGS
"""Algorithm allowlist. ``none`` is NEVER allowed (alg=none attack
class). Any algorithm outside this set raises at construction."""

_PEM_HEADER = "-----BEGIN"
"""PEM-encoded keys start with ``-----BEGIN PUBLIC KEY-----`` /
``-----BEGIN RSA PUBLIC KEY-----`` / ``-----BEGIN CERTIFICATE-----``
etc. Any string starting with this prefix is treated as a PEM."""


@dataclass(frozen=True)
class BearerJWTBackend(AuthBackend):
    """Verifies ``Authorization: Bearer <jwt>`` against a fixed public key.

    Issuer signs the token; gnokee verifies the signature, the standard
    claims (iss / aud / exp / nbf), and reads ``tenant_claim`` (default
    ``"tenants"``) to populate ``Principal.allowed_tenants``.

    AGENTS.md invariant: gnokee NEVER issues tokens. This class only
    verifies tokens someone else issued.

    Algorithm/key consistency is enforced at construction time
    (``__post_init__``) to block the alg-confusion attack class —
    passing a PEM public key while declaring ``algorithm="HS256"``
    would let pyjwt treat the public key (which is, by definition,
    public) as the HMAC shared secret. See ``__post_init__`` for the
    full rule set.
    """

    public_key: str
    """Verification material. For asymmetric algorithms (RS*/ES*/PS*):
    PEM-encoded public key, MUST start with ``-----BEGIN``. For HMAC
    (HS*): shared secret string, MUST NOT start with ``-----BEGIN``."""

    algorithm: str
    """JWT algorithm whitelist. Single string from ``_ALLOWED_ALGS``;
    multi-alg deployments instantiate one backend per algorithm.
    Common: ``RS256`` (prod), ``HS256`` (test only — requires
    ``_allow_hmac=True``). ``none`` is rejected at construction."""

    tenant_claim: str = "tenants"
    """JWT claim name listing allowed tenant_ids. MUST be a JSON array
    of strings in the verified token."""

    issuer: str | None = None
    """Required ``iss`` value. ``None`` skips the check."""

    audience: str | None = None
    """Required ``aud`` value. ``None`` skips the check."""

    leeway_seconds: int = 30
    """Clock-skew leeway applied to ``exp`` and ``nbf``."""

    _allow_hmac: bool = False
    """Explicit opt-in required to use HMAC algorithms (HS256/HS384/HS512).
    Production deploys MUST use an asymmetric algorithm because HMAC
    requires gnokee to hold the same secret the issuer uses to sign —
    contradicting AGENTS.md "do not hold keys". HMAC is permitted only
    for in-process tests where the same code mints and verifies."""

    def __post_init__(self) -> None:
        """Validate algorithm + key-shape consistency.

        Three guards (each blocks a real attack/footgun):

        1. ``algorithm`` MUST be in ``_ALLOWED_ALGS``. Blocks
           ``alg=none`` plus any future pyjwt addition we haven't
           audited.
        2. Asymmetric algorithms MUST receive a PEM-encoded
           ``public_key``. Blocks the alg-confusion attack where an
           operator pastes an HMAC secret while declaring RS256 —
           pyjwt would refuse to decode but the failure mode is
           confusing.
        3. Symmetric algorithms MUST NOT receive a PEM. Blocks the
           classic alg-confusion attack (HS256 + RSA public key →
           pyjwt uses the public key as the HMAC secret → attacker
           who reads the public key mints valid tokens). Also requires
           ``_allow_hmac=True`` because production should never use
           HMAC: gnokee would have to hold the same shared secret the
           issuer uses, contradicting AGENTS.md "do not hold keys".
        """
        if self.algorithm not in _ALLOWED_ALGS:
            raise ValueError(
                f"BearerJWTBackend.algorithm={self.algorithm!r} not in allowlist "
                f"{sorted(_ALLOWED_ALGS)}; `none` and unaudited algorithms are refused"
            )
        looks_like_pem = self.public_key.lstrip().startswith(_PEM_HEADER)
        if self.algorithm in _ASYMMETRIC_ALGS and not looks_like_pem:
            raise ValueError(
                f"BearerJWTBackend.algorithm={self.algorithm!r} requires a PEM-encoded "
                f"public_key starting with {_PEM_HEADER!r}; got a non-PEM string. "
                f"Pass an RSA/EC/PS public key in PEM form."
            )
        if self.algorithm in _SYMMETRIC_ALGS:
            if looks_like_pem:
                raise ValueError(
                    f"BearerJWTBackend.algorithm={self.algorithm!r} (HMAC) was given a "
                    f"PEM-encoded public_key. This is the alg-confusion attack class: "
                    f"pyjwt would use the public key as the HMAC shared secret, letting "
                    f"anyone who reads the public key mint valid tokens. Either declare "
                    f"an asymmetric algorithm (RS256/ES256/PS256) or pass an HMAC secret."
                )
            if not self._allow_hmac:
                raise ValueError(
                    f"BearerJWTBackend.algorithm={self.algorithm!r} (HMAC) requires "
                    f"_allow_hmac=True. Production deploys MUST use an asymmetric algorithm; "
                    f"HMAC requires gnokee to hold the same secret the issuer signs with, "
                    f"contradicting AGENTS.md `do not hold keys`. HMAC is permitted only "
                    f"for in-process tests where the same code mints and verifies."
                )

    async def verify(self, *, request_headers: Mapping[str, str]) -> Principal:
        try:
            import jwt
            from jwt.exceptions import InvalidTokenError
        except ImportError as exc:  # pragma: no cover — pyjwt is in the [mcp] extra
            raise AuthError(401, "pyjwt not installed; install gnokee[mcp]") from exc

        token = _extract_bearer(request_headers)
        options: dict[str, Any] = {"require": ["exp", "sub"]}
        if self.issuer is None:
            options["verify_iss"] = False
        if self.audience is None:
            options["verify_aud"] = False

        try:
            claims: Mapping[str, Any] = jwt.decode(
                token,
                self.public_key,
                algorithms=[self.algorithm],
                audience=self.audience,
                issuer=self.issuer,
                leeway=self.leeway_seconds,
                options=options,  # type: ignore[arg-type]
            )
        except InvalidTokenError as exc:
            raise AuthError(401, f"invalid token: {exc}") from exc

        subject = claims.get("sub")
        if not isinstance(subject, str) or not subject:
            raise AuthError(401, "missing sub claim")

        raw_tenants = claims.get(self.tenant_claim)
        if not isinstance(raw_tenants, list) or not all(isinstance(t, str) for t in raw_tenants):
            raise AuthError(401, f"missing or malformed `{self.tenant_claim}` claim")

        return Principal(
            subject=subject,
            allowed_tenants=frozenset(raw_tenants),
            claims=dict(claims),
        )


def _extract_bearer(headers: Mapping[str, str]) -> str:
    """Pull the bearer token out of an Authorization header.

    Case-insensitive header lookup; rejects empty / malformed values.
    Raises AuthError(401) on absence — verify-time failure, not 403.
    """
    auth = None
    for k, v in headers.items():
        if k.lower() == "authorization":
            auth = v
            break
    if not auth:
        raise AuthError(401, "missing Authorization header")
    parts = auth.split(maxsplit=1)
    if len(parts) != 2 or parts[0].lower() != "bearer" or not parts[1].strip():
        raise AuthError(401, "malformed Authorization header")
    return parts[1].strip()


# --------------------------------------------------------------------------
# MCPTokenVerifier — adapts AuthBackend to upstream's TokenVerifier
# --------------------------------------------------------------------------


class MCPTokenVerifier:
    """Adapter from gnokee ``AuthBackend`` to upstream
    ``mcp.server.auth.provider.TokenVerifier``.

    On a successful ``backend.verify(...)`` call, packs ``Principal``
    into an upstream ``AccessToken`` (client_id=subject, scopes encode
    allowed_tenants as ``tenant:<id>``, expires_at carries the JWT
    ``exp`` if present) AND sets gnokee's ``_current_principal``
    contextvar so the per-tool guard can read a strongly-typed
    Principal without parsing scope strings.

    Failure paths return ``None`` per upstream Protocol contract
    (upstream interprets ``None`` as 401 + drop the request).
    """

    def __init__(self, backend: AuthBackend) -> None:
        self._backend = backend

    async def verify_token(self, token: str) -> Any:
        # Return type is upstream's `mcp.server.auth.provider.AccessToken | None`;
        # typed as `Any` so library-mode users (who never install [mcp]) can
        # import this module without needing the upstream `mcp` package.
        # Imported lazily for the same reason.
        from mcp.server.auth.provider import AccessToken

        # Defense-in-depth: clear any stale principal binding before
        # attempting verification. Starlette spawns a fresh task per
        # request in current versions, so the contextvar starts empty
        # already — but if a future upstream change pools tasks (or
        # invokes the verifier from a context that survived a previous
        # request), the explicit reset prevents the previous request's
        # principal from leaking into this verify path. Pairs with the
        # `.set(principal)` below; on failure (return None below) the
        # contextvar stays None so enforce_tenant_authority sees library
        # mode and the tool body never runs because upstream drops the
        # request on a None return anyway.
        _current_principal.set(None)

        try:
            principal = await self._backend.verify(request_headers={"Authorization": f"Bearer {token}"})
        except AuthError as exc:
            log.info("mcp.auth.rejected verify_time code=%d", exc.code)
            return None

        _current_principal.set(principal)
        exp_raw = principal.claims.get("exp")
        expires_at: int | None
        if isinstance(exp_raw, (int, float)):
            expires_at = int(exp_raw)
        else:
            expires_at = None
        return AccessToken(
            token=token,
            client_id=principal.subject,
            scopes=[TENANT_SCOPE_PREFIX + t for t in sorted(principal.allowed_tenants)],
            expires_at=expires_at,
        )


# --------------------------------------------------------------------------
# Per-tool guard
# --------------------------------------------------------------------------


def enforce_tenant_authority(tenant_id: str) -> None:
    """Per-tool guard. No-op in library mode (principal unset); raises
    ``AuthError(403)`` if a principal is bound and ``tenant_id`` is not
    in ``allowed_tenants``.

    Called at the top of every authenticated MCP tool wrapper BEFORE
    the tool body runs.
    """
    principal = _current_principal.get()
    if principal is None:
        return  # library mode — trust the caller's tenant_id
    if tenant_id not in principal.allowed_tenants:
        log.info(
            "mcp.auth.rejected guard_time subject=%s rejected_tenant=%s",
            principal.subject,
            tenant_id,
        )
        raise AuthError(403, "tenant_id not authorized for this principal")


__all__ = [
    "TENANT_SCOPE_PREFIX",
    "AuthBackend",
    "AuthError",
    "BearerJWTBackend",
    "MCPTokenVerifier",
    "Principal",
    "current_principal",
    "enforce_tenant_authority",
]

# Stamp `time` import so static analysers don't flag it; reserved for
# future caching of pubkey JWKS fetches (open Q3 in ADR-0030).
_ = time
