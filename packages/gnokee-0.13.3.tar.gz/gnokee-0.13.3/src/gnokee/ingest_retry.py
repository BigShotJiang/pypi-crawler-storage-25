"""src/gnokee/ingest_retry.py — Z4 retry helper (#111).

Wraps the graphiti enhancement call (Stage 6 of ingest pipeline) with
adaptive backoff. Retries on RateLimitError / APITimeoutError /
APIConnectionError; honours retry-after header; jittered exponential
backoff; max 3 retries by default. Falls through to lite-fallback after
exhaustion (caller observes result=None).

Module-private; not part of public API.

exports: _retry_enhancement
used_by: src/gnokee/ingest.py
rules:   no exception swallowing on CancelledError; honour retry-after
agent:   claude-opus-4-7 | 2026-05-15 | v0.6 Z4 #111
"""

from __future__ import annotations

import asyncio
import logging
import secrets
from collections.abc import Awaitable, Callable
from typing import TypeVar

import openai

log = logging.getLogger(__name__)

T = TypeVar("T")

_RETRYABLE: tuple[type[BaseException], ...] = (
    openai.RateLimitError,
    openai.APITimeoutError,
    openai.APIConnectionError,
)


async def _retry_enhancement(
    fn: Callable[[], Awaitable[T]],
    *,
    max_retries: int = 3,
    base_delay: float = 1.0,
    jitter_pct: float = 0.2,
) -> tuple[T | None, int]:
    """Run ``fn`` with retry on retryable exceptions.

    Returns ``(result, attempts)``. ``result=None`` means all retries
    exhausted. ``attempts`` is the number of retry attempts (NOT total
    calls — 0 means the first attempt succeeded).

    Honours ``RateLimitError.response.headers['retry-after']`` when set;
    falls back to exponential backoff ``base_delay * 2^attempt`` with
    ±``jitter_pct`` symmetric jitter.

    CancelledError is re-raised. Non-retryable exceptions (BadRequestError,
    AuthenticationError, graphiti_core.errors.*, Neo4j driver errors) are
    treated as immediate failure → return ``(None, 0)``.
    """
    last_exc: BaseException | None = None
    for attempt in range(max_retries + 1):  # +1 for the initial try
        try:
            result = await fn()
            return result, attempt
        except asyncio.CancelledError:
            raise
        except _RETRYABLE as exc:
            last_exc = exc
            if attempt >= max_retries:
                log.warning(
                    "gnokee.ingest_retry: exhausted %d retries on %s",
                    max_retries,
                    type(exc).__name__,
                )
                return None, max_retries
            delay = _compute_delay(exc, attempt, base_delay, jitter_pct)
            log.info(
                "gnokee.ingest_retry: attempt=%d/%d reason=%s retry_after=%.2fs",
                attempt + 1,
                max_retries,
                type(exc).__name__,
                delay,
            )
            await asyncio.sleep(delay)
        except Exception as exc:
            log.warning(
                "gnokee.ingest_retry: non-retryable %s — %s",
                type(exc).__name__,
                exc,
            )
            return None, attempt
    # Loop exhausted (shouldn't reach here, but defensive).
    log.warning("gnokee.ingest_retry: loop exhausted, last_exc=%r", last_exc)
    return None, max_retries


def _compute_delay(
    exc: BaseException,
    attempt: int,
    base_delay: float,
    jitter_pct: float,
) -> float:
    """Pick the next sleep duration.

    Priority: ``retry-after`` header on RateLimitError → exponential backoff
    with jitter. Jitter is symmetric (±jitter_pct of the base value).
    """
    retry_after = _retry_after_from_exception(exc)
    if retry_after is not None:
        return float(max(retry_after, base_delay * (2**attempt) * (1 - jitter_pct)))
    base = base_delay * (2**attempt)
    rng = secrets.SystemRandom()
    return float(base * (1 + rng.uniform(-jitter_pct, jitter_pct)))


def _retry_after_from_exception(exc: BaseException) -> float | None:
    """Extract retry-after header from openai.RateLimitError, if present."""
    if not isinstance(exc, openai.RateLimitError):
        return None
    response = getattr(exc, "response", None)
    if response is None:
        return None
    headers = getattr(response, "headers", None)
    if headers is None:
        return None
    getter = getattr(headers, "get", None)
    if getter is None:
        return None
    raw = getter("retry-after") or getter("Retry-After")
    if raw is None:
        return None
    try:
        return float(raw)
    except (TypeError, ValueError):
        return None


__all__ = ["_retry_enhancement"]
