"""src/gnokee/fact_history.py — gnokee.fact_history() public API (issue #73).

Fact-grain revision history. Caller passes either `fact_id` (logical
identifier) or `fact_uuid` (Graphiti edge uuid) — pipeline resolves
fact_uuid → fact_id via a single SELECT on `fact_revision_fact_uuid_idx`.

Returns a flat array of revisions sorted by `asserted_at` DESC (newest
first). `as_of` filters to `asserted_at <= as_of`. Per ADR-0014 the log
is append-only — every revision is preserved, including ones whose
underlying Graphiti edge has been invalidated. `superseded_at` on each
revision is joined from `RELATES_TO.invalid_at` via GraphitiStore so
the consumer can distinguish open from closed without an extra call.

Distinct from `gnokee.history_of` (#123, episode-grain DAG): this is
per-fact lineage, not per-episode.

exports: fact_history | FactHistoryPipeline | FactHistoryResponse | DEFAULT_MAX_REVISIONS
used_by: src/gnokee/mcp.py | src/gnokee/__init__.py
rules:   tenant_id mandatory; tz-aware UTC; no auto-resolve
agent:   claude-sonnet-4-6 | 2026-05-16 | issue #73 ADR-0014
         claude-opus-4-7   | 2026-05-16 | issue #177 superseded_at join + issue #178 stub removal
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

import asyncpg

from gnokee.config import utc_now
from gnokee.errors import ValidationError
from gnokee.models import FactRevision
from gnokee.storage.fact_revision import FactRevisionRow, FactRevisionStore
from gnokee.storage.graph import GraphitiStore

log = logging.getLogger(__name__)

DEFAULT_MAX_REVISIONS = 64


@dataclass(frozen=True, slots=True)
class FactHistoryResponse:
    fact_id: UUID
    revisions: list[FactRevision]
    truncated: bool = False
    truncation_note: str | None = None


class FactHistoryPipeline:
    def __init__(
        self,
        *,
        pool: asyncpg.Pool,
        store: FactRevisionStore,
        graph: GraphitiStore,
    ) -> None:
        self.pool = pool
        self.store = store
        self.graph = graph

    async def fact_history(
        self,
        *,
        tenant_id: str,
        fact_id: UUID,
        as_of: datetime | None = None,
        max_revisions: int = DEFAULT_MAX_REVISIONS,
    ) -> FactHistoryResponse:
        if not tenant_id:
            raise ValidationError("tenant_id is mandatory")
        if as_of is not None and as_of.tzinfo is None:
            raise ValidationError("as_of must be tz-aware UTC")

        effective_as_of = as_of if as_of is not None else utc_now()

        async with self.pool.acquire() as conn, conn.transaction():
            # Issue #220 — `fact_revision` reads run on a freshly-acquired
            # connection; set the `app.current_tenant` GUC so RLS is enforced
            # even after FORCE ROW LEVEL SECURITY lands. `set_config(..., true)`
            # is transaction-local, so the explicit `conn.transaction()`
            # block keeps the setting alive across the SELECTs below
            # (otherwise the GUC resets before the next statement and the
            # NOBYPASSRLS read returns empty silently).
            await conn.execute(
                "SELECT set_config('app.current_tenant', $1, true)",
                tenant_id,
            )
            resolved_fact_id = await self._resolve_fact_id(
                conn=conn,
                tenant_id=tenant_id,
                candidate=fact_id,
            )
            rows = await self.store.fetch_by_fact_id(
                conn=conn,
                tenant_id=tenant_id,
                fact_id=resolved_fact_id,
                as_of=effective_as_of,
            )

        # ADR-0014 §Decision 3 — join supersession close (`r.invalid_at`)
        # from Graphiti onto each revision. One Cypher round-trip for all
        # fact_uuids in the result set.
        if rows:
            invalid_ats = await self.graph.fact_invalid_at_lookup(
                tenant_id=tenant_id,
                fact_uuids=sorted({r.fact_uuid for r in rows}),
            )
            for r in rows:
                r.superseded_at = invalid_ats.get(r.fact_uuid)

        truncated = len(rows) > max_revisions
        if truncated:
            rows = rows[:max_revisions]

        revisions = [_to_public(r) for r in rows]
        return FactHistoryResponse(
            fact_id=resolved_fact_id,
            revisions=revisions,
            truncated=truncated,
            truncation_note=(f"capped at {max_revisions} revisions; older history omitted" if truncated else None),
        )

    async def _resolve_fact_id(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        candidate: UUID,
    ) -> UUID:
        """Treat `candidate` as fact_id first; if no rows, try as fact_uuid."""
        any_row = await conn.fetchval(
            "SELECT 1 FROM fact_revision WHERE tenant_id = $1 AND fact_id = $2 LIMIT 1",
            tenant_id,
            candidate,
        )
        if any_row is not None:
            return candidate
        resolved = await conn.fetchval(
            "SELECT fact_id FROM fact_revision WHERE tenant_id = $1 AND fact_uuid = $2 LIMIT 1",
            tenant_id,
            candidate,
        )
        return resolved if resolved is not None else candidate


def _to_public(row: FactRevisionRow) -> FactRevision:
    if row.revision_id is None or row.created_at is None:
        raise RuntimeError("fact_revision row missing DB-default fields (revision_id / created_at)")
    return FactRevision(
        revision_id=row.revision_id,
        fact_id=row.fact_id,
        fact_uuid=row.fact_uuid,
        episode_uuid=row.episode_uuid,
        valid_at=row.valid_at,
        asserted_at=row.asserted_at,
        created_at=row.created_at,
        fact_text=row.fact_text,
        source_node_uuid=row.source_node_uuid,
        predicate=row.predicate,
        target_node_uuid=row.target_node_uuid,
        prior_revision_id=row.prior_revision_id,
        superseded_at=row.superseded_at,
    )


async def fact_history(
    *,
    tenant_id: str,
    fact_id: UUID,
    pool: asyncpg.Pool,
    store: FactRevisionStore,
    graph: GraphitiStore,
    as_of: datetime | None = None,
    max_revisions: int = DEFAULT_MAX_REVISIONS,
) -> FactHistoryResponse:
    """Functional wrapper around `FactHistoryPipeline.fact_history`."""
    pipeline = FactHistoryPipeline(pool=pool, store=store, graph=graph)
    return await pipeline.fact_history(
        tenant_id=tenant_id,
        fact_id=fact_id,
        as_of=as_of,
        max_revisions=max_revisions,
    )


__all__ = [
    "DEFAULT_MAX_REVISIONS",
    "FactHistoryPipeline",
    "FactHistoryResponse",
    "fact_history",
]
