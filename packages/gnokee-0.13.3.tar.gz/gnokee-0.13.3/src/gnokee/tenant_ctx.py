"""src/gnokee/tenant_ctx.py — Optional tenant contextvar binder.

gnokee's public pipelines accept `tenant_id` as a positional/keyword
argument for back-compat. This module adds a process-local contextvar
that mirrors the value so structlog records and OTel baggage carry it
automatically. When `omkit` is installed, delegates to
`omkit.tenant.bind` / `omkit.tenant.current_or_none` so gnokee shares
the same contextvar as the rest of the Omur stack — log correlation
matches end-to-end.

Without `omkit`, the in-tree `contextvars.ContextVar` keeps the local
copy. Either way, `bind_tenant(...)` is a sync context manager that
resets cleanly on exit.

exports: bind_tenant | current_tenant | clear_tenant
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py | src/gnokee/mcp
rules:   must be safe to call from sync code; never raises if omkit missing; reset on exit even after exception.
agent:   claude-opus-4-7 | 2026-05-17 | omkit tenant integration
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import AbstractContextManager, contextmanager
from contextvars import ContextVar
from typing import Any

_native_tenant: ContextVar[str | None] = ContextVar("gnokee_tenant_id", default=None)


def _omkit_bind(tenant_id: str) -> AbstractContextManager[Any] | None:
    try:
        from omkit.tenant import bind as omkit_bind
    except ImportError:
        return None
    return omkit_bind(tenant_id)


@contextmanager
def bind_tenant(tenant_id: str) -> Iterator[None]:
    """Bind `tenant_id` to the current task. Resets on exit.

    No-op when `tenant_id` is falsy — callers can pass the raw arg without
    a guard.
    """
    if not tenant_id:
        yield
        return
    omkit_cm = _omkit_bind(tenant_id)
    token = _native_tenant.set(tenant_id)
    try:
        if omkit_cm is not None:
            with omkit_cm:
                yield
        else:
            yield
    finally:
        _native_tenant.reset(token)


def current_tenant() -> str | None:
    """Return the bound tenant ID or None.

    Reads omkit's contextvar first when available so callers see the same
    value as the rest of the Omur stack (set by upstream ASGI middleware).
    """
    try:
        from omkit.tenant import current_or_none
    except ImportError:
        return _native_tenant.get()
    return current_or_none() or _native_tenant.get()


def clear_tenant() -> None:
    """Reset the in-tree binding. Test utility; production code uses the CM."""
    _native_tenant.set(None)


__all__ = ["bind_tenant", "clear_tenant", "current_tenant"]
