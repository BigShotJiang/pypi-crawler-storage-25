"""src/gnokee/storage/locks.py — Postgres advisory-lock primitives.

Issue #140 / ADR-0026 §Concurrency. Both `gnokee.forget.forget_*` and
``gnokee.ingest.IngestPipeline`` race on the same tenant's storage:

* **Forget** acquires single-arg `pg_advisory_xact_lock(<bigint>)` —
  exclusive, transaction-scoped — at the top of its SERIALIZABLE
  transaction.
* **Ingest** acquires `pg_advisory_lock_shared(<bigint>)` — shared,
  **session-scoped** — on a dedicated pool connection held for the
  lifetime of Stages 4–6 (#150). The matching
  ``pg_advisory_unlock_shared`` runs in ``finally`` so the lock
  releases on success and on any exception.

The 64-bit lock key is derived as
``('x' || md5(tenant_id || ':forget'))::bit(64)::bigint`` — the leftmost
64 bits of ``md5(tenant_id || ':forget')`` interpreted as a signed
bigint. Issue #151: the prior two-int32 form (``pg_advisory_xact_lock(
hashtext(tenant_id), hashtext('forget'))``) gave a 32-bit primary slot
with ~69% birthday-collision probability at 100k tenants, leading to
silent cross-tenant contention. The 64-bit form drives the collision
probability at the same scale to ~2.5e-10.

Postgres semantics:

* Multiple ingests on the same tenant hold the shared lock together
  (typical case — zero contention).
* A forget waits for every in-flight ingest to release its shared lock
  before acquiring its exclusive lock.
* New ingests block on a held exclusive lock — by the time they resume,
  the forget has committed and the lookups (`corrects:` referenced row,
  episode_metadata snapshot, etc.) see the post-forget state.

The forget side stays transaction-scoped: it releases automatically on
commit / rollback. The ingest side is session-scoped so the lock can
span Stage 4 (Graphiti ``write_lite_episode``), Stage 5 (the Postgres
write tx — which commits and releases its own resources but does not
release the ingest's session-scoped lock), and Stage 6 (Graphiti
``add_episode``). Issue #150: the prior xact-scoped shared lock only
covered Stage 5, leaving Stages 4 and 6 outside the forget-vs-ingest
window and allowing orphan Neo4j nodes whose Postgres metadata had
already been deleted.

Issue #153: :func:`acquire_forget_exclusive_with_timeout` wraps the
bare exclusive acquire with ``SET LOCAL lock_timeout`` and maps the
resulting :class:`asyncpg.exceptions.LockNotAvailableError` (PG
sqlstate ``55P03``) to :class:`gnokee.errors.ForgetContention`.
Without the wrapper a long-running or stalled ingest can hold the
shared lock indefinitely; a contending forget would block until
``idle_in_transaction_session_timeout`` (often >5 min, not operator-
controllable from gnokee config).

exports: acquire_forget_exclusive | acquire_forget_exclusive_with_timeout
         | acquire_forget_shared_session | release_forget_shared_session
used_by: src/gnokee/forget.py | src/gnokee/ingest.py
rules:   ``acquire_forget_exclusive`` (and the timeout wrapper) must
         run inside an open Postgres transaction; the shared-session
         pair must run on the same dedicated asyncpg connection with
         a matching release in ``finally``; on release failure the
         caller terminates the conn so the pool does not return a
         lock-held connection.
agent:   claude-opus-4-7 | 2026-05-16 | issue #140 advisory-lock primitive
         claude-opus-4-7 | 2026-05-16 | issue #151 single-bigint key
         claude-opus-4-7 | 2026-05-16 | issue #150 session-scope shared lock
         claude-opus-4-7 | 2026-05-16 | issue #153 lock_timeout wrapper
"""

from __future__ import annotations

import time

import asyncpg

from gnokee.errors import ForgetContention

_FORGET_TAG = "forget"

# Single-arg bigint derivation: leftmost 64 bits of md5(tenant_id || ':' || tag)
# interpreted as a signed bigint. Replaces the prior two-int32 hashtext slots
# (issue #151). The leading 'x' makes the md5 hex output a bit-string literal;
# bit(64) cast truncates to 64 bits (Postgres truncates a longer bit string on
# the right when casting to a narrower bit(n)); the bit(64)::bigint cast
# reinterprets those 64 bits as a signed bigint.
_FORGET_LOCK_KEY_SQL = "('x' || md5($1 || ':' || $2))::bit(64)::bigint"


async def acquire_forget_exclusive(conn: asyncpg.Connection, tenant_id: str) -> None:
    """Acquire the per-tenant **exclusive** forget lock for this transaction.

    Called by `forget_episode` / `forget_tenant` at the top of their
    SERIALIZABLE Postgres transaction. Blocks until every in-flight
    shared lock on the same `(tenant_id, 'forget')` key — i.e. concurrent
    ingest Stage-4-to-6 sessions — releases.
    """
    await conn.execute(
        f"SELECT pg_advisory_xact_lock({_FORGET_LOCK_KEY_SQL})",
        tenant_id,
        _FORGET_TAG,
    )


async def acquire_forget_exclusive_with_timeout(
    conn: asyncpg.Connection,
    tenant_id: str,
    *,
    timeout_ms: int,
) -> int:
    """Acquire the exclusive forget lock under a `SET LOCAL lock_timeout` budget.

    Issue #153. When ``timeout_ms > 0`` runs ``SET LOCAL lock_timeout =
    <ms>`` immediately before :func:`acquire_forget_exclusive` and maps
    the resulting :class:`asyncpg.exceptions.LockNotAvailableError`
    (Postgres sqlstate ``55P03``) — and the related
    :class:`~asyncpg.exceptions.QueryCanceledError` (``57014``, which
    older PG configurations may surface for the same condition) — to
    :class:`~gnokee.errors.ForgetContention`. ``timeout_ms == 0``
    disables the timeout (effectively the same as
    :func:`acquire_forget_exclusive`).

    Returns the measured wait in milliseconds so callers can surface
    it in telemetry. On a clean acquire this is typically a few ms.
    """
    if timeout_ms < 0:
        raise ValueError(f"timeout_ms must be >= 0, got {timeout_ms}")
    if timeout_ms > 0:
        # `SET LOCAL lock_timeout = <int>` (units default ms). Validated
        # int → no SQL injection surface.
        await conn.execute(f"SET LOCAL lock_timeout = {int(timeout_ms)}")
    started = time.monotonic()
    try:
        await acquire_forget_exclusive(conn, tenant_id)
    except (
        asyncpg.exceptions.LockNotAvailableError,
        asyncpg.exceptions.QueryCanceledError,
    ) as exc:
        waited_ms = int((time.monotonic() - started) * 1000)
        raise ForgetContention(
            tenant_id=tenant_id,
            timeout_ms=timeout_ms,
            waited_ms=waited_ms,
            cause=exc,
        ) from exc
    return int((time.monotonic() - started) * 1000)


async def acquire_forget_shared_session(conn: asyncpg.Connection, tenant_id: str) -> None:
    """Acquire the per-tenant **session-scoped shared** forget lock.

    Issue #150: ingest holds this lock from before Stage 4
    (``write_lite_episode``) through after Stage 6 (``add_episode``) so a
    concurrent forget cannot delete Postgres metadata + sweep Neo4j
    while ingest is mid-Graphiti-write. Pair with
    :func:`release_forget_shared_session` on the same connection in a
    ``finally`` block. The lock is **session-scoped**, NOT transaction-
    scoped — Stage 5's transaction commit does not release it.
    """
    await conn.execute(
        f"SELECT pg_advisory_lock_shared({_FORGET_LOCK_KEY_SQL})",
        tenant_id,
        _FORGET_TAG,
    )


async def release_forget_shared_session(conn: asyncpg.Connection, tenant_id: str) -> None:
    """Release the session-scoped shared forget lock acquired above.

    Must run on the same asyncpg connection that acquired the lock.
    Caller wraps in ``finally`` so the lock releases on success and on
    exception; on release-call failure the caller should terminate the
    connection so the pool does not hand the lock-held conn to the next
    ingest (which would silently inherit a held session-scoped lock).
    """
    await conn.execute(
        f"SELECT pg_advisory_unlock_shared({_FORGET_LOCK_KEY_SQL})",
        tenant_id,
        _FORGET_TAG,
    )
