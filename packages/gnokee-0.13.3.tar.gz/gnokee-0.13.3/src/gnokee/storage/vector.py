"""src/gnokee/storage/vector.py — pgvector adapter for content_embedding.

Per ADR-0004: gnokee owns content embeddings in pg, keyed by
(tenant_id, episode_uuid). 1024-dim cosine vectors (bge-m3 per Q2).

Also owns the BM25 full-text search lane over episode_metadata.content_text
(stage 3a — issue #46, ADR-0012 Q11 fix).  Uses Postgres tsvector +
ts_rank_cd over the GIN index added in migration 0009.

``search_embeddings_with_scores`` (ADR-0022 Option A / issue #94) extends
``search_embeddings`` to return (uuid, cosine_similarity) pairs so the recall
pipeline can apply a ``cosine_floor`` prune before stage 4.  The hot path
(``search_embeddings`` alone) is unchanged for callers not opting in.

exports: class PgVectorStore
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py
rules:   tenant_id on every read+write; no business logic
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
         claude-sonnet-4-6 | 2026-05-12 | issue #89 cosine_top1 telemetry
         claude-sonnet-4-6 | 2026-05-12 | issue #94 / ADR-0022 Option A search_embeddings_with_scores
"""

from __future__ import annotations

from uuid import UUID

import asyncpg

from gnokee.errors import VectorStoreError


def _vector_literal(vec: list[float]) -> str:
    """Render a Python float list as the pgvector text literal `[v1,v2,...]`.

    Used so the connection does not need pgvector codec registration on every
    pool acquire — fits asyncpg-only path for v0.1.
    """
    return "[" + ",".join(repr(float(x)) for x in vec) + "]"


class PgVectorStore:
    """Async wrapper around the `content_embedding` table."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def write_embedding(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        episode_uuid: UUID,
        embedding: list[float],
        model: str = "bge-m3",
    ) -> None:
        """INSERT into content_embedding. Caller controls the transaction."""
        try:
            await conn.execute(
                """
                INSERT INTO content_embedding (tenant_id, episode_uuid, embedding, model)
                VALUES ($1, $2, $3::vector, $4)
                ON CONFLICT (tenant_id, episode_uuid) DO UPDATE
                  SET embedding = EXCLUDED.embedding, model = EXCLUDED.model
                """,
                tenant_id,
                episode_uuid,
                _vector_literal(embedding),
                model,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"write_embedding failed: {exc}") from exc

    async def search_embeddings(
        self,
        *,
        tenant_id: str,
        episode_uuids: list[UUID],
        query_vector: list[float],
        top_k: int,
    ) -> list[UUID]:
        """Cosine ANN over a candidate set, scoped to tenant. Returns ranked uuids.

        Issue #220 — sets the `app.current_tenant` GUC on the acquired
        connection so the RLS policy on `content_embedding` is enforced even
        when FORCE ROW LEVEL SECURITY is on. Safe today via the
        `WHERE tenant_id = $1` predicate alone (gnokee role owns the table),
        but the GUC closes the contract-level hole.
        """
        if not episode_uuids:
            return []
        try:
            async with self._pool.acquire() as conn, conn.transaction():
                # `set_config(..., is_local=true)` is transaction-local;
                # wrap so the `app.current_tenant` GUC stays set for the
                # SELECT below (otherwise FORCE RLS empties the result).
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                rows = await conn.fetch(
                    """
                    SELECT episode_uuid
                      FROM content_embedding
                     WHERE tenant_id = $1
                       AND episode_uuid = ANY($2::uuid[])
                  ORDER BY embedding <=> $3::vector ASC
                     LIMIT $4
                    """,
                    tenant_id,
                    episode_uuids,
                    _vector_literal(query_vector),
                    top_k,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"search_embeddings failed: {exc}") from exc
        return [r["episode_uuid"] for r in rows]

    async def search_embeddings_with_scores(
        self,
        *,
        tenant_id: str,
        episode_uuids: list[UUID],
        query_vector: list[float],
        top_k: int,
    ) -> list[tuple[UUID, float]]:
        """Cosine ANN over a candidate set, returning (uuid, distance) pairs.

        Returns ranked (uuid, cosine_distance) pairs — distance in [0, 2] for
        ``vector_cosine_ops`` (``<=>`` operator). Callers convert to similarity
        via ``1 - distance``.

        Used by:
        - ``include_cosine_top1`` telemetry path (issue #89) — per-fact recall
          envelope carries the raw cosine score from the content_embedding ANN.
        - ``cosine_floor`` prune path (ADR-0022 Option A, issue #94) — recall
          stage 3.6 drops episodes whose similarity falls below the floor.

        The existing ``search_embeddings`` method is kept unchanged for callers
        that only need the ranked uuid list (the hot path).

        Issue #220 — sets `app.current_tenant` GUC before SELECT for the same
        FORCE-RLS-safety reason as ``search_embeddings``.
        """
        if not episode_uuids:
            return []
        try:
            async with self._pool.acquire() as conn, conn.transaction():
                # `set_config(..., is_local=true)` is transaction-local;
                # wrap so the `app.current_tenant` GUC stays set for the
                # SELECT below (otherwise FORCE RLS empties the result).
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                rows = await conn.fetch(
                    """
                    SELECT episode_uuid,
                           (embedding <=> $3::vector) AS cosine_distance
                      FROM content_embedding
                     WHERE tenant_id = $1
                       AND episode_uuid = ANY($2::uuid[])
                  ORDER BY cosine_distance ASC
                     LIMIT $4
                    """,
                    tenant_id,
                    episode_uuids,
                    _vector_literal(query_vector),
                    top_k,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"search_embeddings_with_scores failed: {exc}") from exc
        return [(r["episode_uuid"], float(r["cosine_distance"])) for r in rows]

    async def search_bm25(
        self,
        *,
        tenant_id: str,
        episode_uuids: list[UUID],
        query_text: str,
        top_k: int,
    ) -> list[UUID]:
        """BM25 full-text search over episode_metadata.content_text.

        Uses Postgres ``plainto_tsquery('english', $query)`` + ``ts_rank_cd``
        over the GIN index added in migration 0009.  Restricted to the
        candidate uuid set from stage 2a so it respects the bi-temporal
        pre-filter.

        Returns ranked uuids ordered by BM25 score desc (best first).
        Returns ``[]`` when ``episode_uuids`` is empty, when no rows have
        content_text populated, or when no rows match the query — all
        degrade gracefully in the RRF fuser (cosine-only result).

        Multi-tenant isolation: the WHERE tenant_id = $1 predicate is the
        primary enforcement layer; the `app.current_tenant` GUC (set on the
        acquired connection, issue #220) is a second guard so FORCE RLS does
        not silently empty the result set.
        """
        if not episode_uuids or not query_text.strip():
            return []
        try:
            async with self._pool.acquire() as conn, conn.transaction():
                # `set_config(..., is_local=true)` is transaction-local;
                # wrap so the `app.current_tenant` GUC stays set for the
                # SELECT below (otherwise FORCE RLS empties the result).
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                rows = await conn.fetch(
                    """
                    SELECT episode_uuid
                      FROM episode_metadata
                     WHERE tenant_id = $1
                       AND episode_uuid = ANY($2::uuid[])
                       AND content_text IS NOT NULL
                       AND to_tsvector('english', content_text)
                           @@ plainto_tsquery('english', $3)
                  ORDER BY ts_rank_cd(
                               to_tsvector('english', content_text),
                               plainto_tsquery('english', $3)
                           ) DESC
                     LIMIT $4
                    """,
                    tenant_id,
                    episode_uuids,
                    query_text,
                    top_k,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"search_bm25 failed: {exc}") from exc
        return [r["episode_uuid"] for r in rows]

    async def write_content_text(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        episode_uuid: UUID,
        content_text: str,
    ) -> None:
        """UPDATE episode_metadata.content_text for BM25 indexing.

        Called from the ingest path after the episode row already exists.
        Uses ON CONFLICT DO UPDATE so it is idempotent on re-ingest.
        content_text='' is stored as NULL to exclude empty strings from
        the GIN tsvector index.
        """
        text_or_null: str | None = content_text if content_text.strip() else None
        try:
            await conn.execute(
                """
                UPDATE episode_metadata
                   SET content_text = $3
                 WHERE tenant_id    = $1
                   AND episode_uuid = $2
                """,
                tenant_id,
                episode_uuid,
                text_or_null,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"write_content_text failed: {exc}") from exc


__all__ = ["PgVectorStore"]
