-- 0021_fact_revision_autovacuum.sql
-- Issue #181 — autovacuum tuning for fact_revision.
--
-- Background. Migration 0019 introduced fact_revision (ADR-0014 fact-grain
-- lineage). The table is append-only on the hot path (every observation of
-- a logical fact writes a new revision row chained via prior_revision_id)
-- and absorbs bulk DELETE traffic from forget_episode cascades through
-- fact_revision_episode_fk. Hot tenants accumulate revisions quickly and
-- the global default autovacuum_*_scale_factor of 0.2 lets dead tuples and
-- stale planner statistics build up far enough to hurt the (tenant_id,
-- fact_id, asserted_at DESC) lookup that powers gnokee_fact_history.
--
-- Fix. Tighten the per-table thresholds to 0.05, matching the posture
-- migration 0018 established for forget_audit. Same churn profile
-- (append-only + bulk delete + JSONB-adjacent payload), same remedy.
--
-- Operator-facing only; schema layout, RLS posture, and fact_revision
-- semantics are unchanged.

ALTER TABLE fact_revision
    SET (
        autovacuum_vacuum_scale_factor  = 0.05,
        autovacuum_analyze_scale_factor = 0.05
    );
