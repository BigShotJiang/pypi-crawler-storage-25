-- 0009_episode_metadata_gin_fts.sql
-- GIN index on episode_metadata.episode_content for BM25 full-text search
-- (stage 3a BM25 sibling — issue #46, ADR-0012 Q11 fix).
--
-- The content_text column mirrors the Episodic.content body stored in
-- Neo4j.  It is written by the ingest path alongside the pgvector
-- embedding so that the BM25 lane can search without a Neo4j round-trip.
--
-- Design decisions:
--   - english configuration: matches the corpus language of the
--     LongMemEval-S benchmark and personal notes.  Non-EN corpora are
--     handled by v0.2 typed reads (ADR-0009 / ADR-0010) which bypass
--     this path entirely.
--   - GIN (not GiST): GIN is faster for read-heavy FTS workloads; GiST
--     has lower write cost but slower reads.  At gnokee ingest rates
--     (one episode per session, not streaming) GIN wins.
--   - CONCURRENTLY: index creation blocks no writes.  The column starts
--     NULL-filled; the backfill in 0009b sets the value from the ingest
--     path going forward.  Existing rows with NULL content_text produce
--     no tsvector entries (to_tsvector(NULL) = NULL, excluded by GIN).
--   - content_text is nullable: episodes with encrypted_body set have no
--     plaintext available for FTS; the column remains NULL and those
--     episodes are invisible to BM25 (they fall back to cosine-only RRF,
--     which is correct — BM25 over ciphertext is meaningless).
--   - RLS: episode_metadata has RLS enabled; the BM25 query uses the same
--     table and inherits the same app.current_tenant GUC policy.

ALTER TABLE episode_metadata
    ADD COLUMN IF NOT EXISTS content_text TEXT;

-- GIN index on the english tsvector of content_text.
-- CREATE INDEX CONCURRENTLY cannot run inside a transaction, but the
-- migration runner wraps each migration in a transaction.  We use a
-- plain CREATE INDEX IF NOT EXISTS here; the index build is fast on an
-- empty / low-row table at v0.1–v0.3 corpus sizes.  For production
-- tables with millions of rows a separate CONCURRENTLY migration would
-- be needed.
CREATE INDEX IF NOT EXISTS idx_episode_metadata_content_fts
    ON episode_metadata
    USING gin (to_tsvector('english', content_text))
    WHERE content_text IS NOT NULL;
