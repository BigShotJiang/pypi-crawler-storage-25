-- 0020_rls_original_tables.sql
-- Issue #180 — enable RLS at migration time on the original tenant-scoped
-- tables that shipped without it. Aligns these tables with the RLS-at-
-- migration posture established by 0015 (ingest_journal) and 0019
-- (fact_revision).
--
-- Background. Pre-0015, RLS on tenant-scoped tables was deferred to a
-- manual deployment-time step. A deployment that applied migrations but
-- skipped that step left these tables relying solely on application-level
-- ``WHERE tenant_id = $1`` for isolation — a regression risk the moment
-- any new read path forgets the predicate. Enabling RLS in the migration
-- itself closes that gap as defence-in-depth; the application predicates
-- remain the primary enforcement layer (see ADR + ingest_journal comment).
--
-- Scope. Every CREATE TABLE migration prior to 0015 that ships a
-- ``tenant_id`` column and is NOT schema-isolated:
--   * episode_metadata          (0001)
--   * content_embedding         (0002)
--   * fact_contradiction        (0003)
--   * lab_record                (0006)
--   * med_record                (0007)
--   * episode_body_encrypted    (0012)
-- ``gnokee_maintenance.forget_audit`` (0017) is intentionally excluded —
-- it uses schema-level isolation by design (see 0017 header comment).
--
-- Policy shape. Mirrors 0015/0019 exactly: ``USING (tenant_id =
-- current_setting('app.current_tenant', true))``. The ``true`` flag makes
-- the GUC return NULL when unset so operator/maintenance queries with the
-- connection role still work the same way (NULL never equals a row's
-- tenant_id, so a forgotten GUC fails closed under RLS — but the gnokee
-- ``gnokee`` role is the table owner and owners bypass RLS unless FORCE
-- is set; this migration deliberately does NOT FORCE because several
-- read paths in gnokee storage today do not set the GUC, and forcing
-- without first auditing those paths would break the app. FORCE is a
-- separate follow-up tracked alongside #180).
--
-- Idempotency. ``ENABLE ROW LEVEL SECURITY`` is naturally idempotent.
-- ``CREATE POLICY IF NOT EXISTS`` is Postgres 18+ only, so each policy
-- creation is wrapped in the DO-block guard pattern proven by 0015,
-- 0019, and migration 0015 #172. The guard checks pg_policy for the
-- (polrelid, polname) pair and skips the CREATE POLICY if present.
--
-- Forget pipeline. No changes needed. All six tables are already covered
-- by the existing gnokee_forget_tenant / gnokee_forget_episode cascades —
-- episode_metadata is the cascade root and the five siblings either FK
-- to it (ON DELETE CASCADE) or are scoped by the same tenant_id sweep.

-- ─── episode_metadata ────────────────────────────────────────────────
ALTER TABLE episode_metadata ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policy
        WHERE polrelid = 'episode_metadata'::regclass
          AND polname  = 'episode_metadata_tenant_isolation'
    ) THEN
        EXECUTE $p$
            CREATE POLICY episode_metadata_tenant_isolation ON episode_metadata
                USING (tenant_id = current_setting('app.current_tenant', true))
        $p$;
    END IF;
END
$$;

-- ─── content_embedding ───────────────────────────────────────────────
ALTER TABLE content_embedding ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policy
        WHERE polrelid = 'content_embedding'::regclass
          AND polname  = 'content_embedding_tenant_isolation'
    ) THEN
        EXECUTE $p$
            CREATE POLICY content_embedding_tenant_isolation ON content_embedding
                USING (tenant_id = current_setting('app.current_tenant', true))
        $p$;
    END IF;
END
$$;

-- ─── fact_contradiction ──────────────────────────────────────────────
ALTER TABLE fact_contradiction ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policy
        WHERE polrelid = 'fact_contradiction'::regclass
          AND polname  = 'fact_contradiction_tenant_isolation'
    ) THEN
        EXECUTE $p$
            CREATE POLICY fact_contradiction_tenant_isolation ON fact_contradiction
                USING (tenant_id = current_setting('app.current_tenant', true))
        $p$;
    END IF;
END
$$;

-- ─── lab_record ──────────────────────────────────────────────────────
ALTER TABLE lab_record ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policy
        WHERE polrelid = 'lab_record'::regclass
          AND polname  = 'lab_record_tenant_isolation'
    ) THEN
        EXECUTE $p$
            CREATE POLICY lab_record_tenant_isolation ON lab_record
                USING (tenant_id = current_setting('app.current_tenant', true))
        $p$;
    END IF;
END
$$;

-- ─── med_record ──────────────────────────────────────────────────────
ALTER TABLE med_record ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policy
        WHERE polrelid = 'med_record'::regclass
          AND polname  = 'med_record_tenant_isolation'
    ) THEN
        EXECUTE $p$
            CREATE POLICY med_record_tenant_isolation ON med_record
                USING (tenant_id = current_setting('app.current_tenant', true))
        $p$;
    END IF;
END
$$;

-- ─── episode_body_encrypted ──────────────────────────────────────────
ALTER TABLE episode_body_encrypted ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policy
        WHERE polrelid = 'episode_body_encrypted'::regclass
          AND polname  = 'episode_body_encrypted_tenant_isolation'
    ) THEN
        EXECUTE $p$
            CREATE POLICY episode_body_encrypted_tenant_isolation ON episode_body_encrypted
                USING (tenant_id = current_setting('app.current_tenant', true))
        $p$;
    END IF;
END
$$;
