-- 0023_ingest_audit.sql
-- ADR-0028 — system-scoped ingest audit (#198).
--
-- Schema-isolation rationale mirrors 0017_forget_audit: this table
-- survives gnokee_forget_tenant(t) as the compliance counterpart of
-- forget_audit. Operators read it directly; the application connection
-- writes it via gnokee.storage.ingest_audit module. No RLS — schema
-- placement is the isolation boundary.

CREATE SCHEMA IF NOT EXISTS gnokee_maintenance;

CREATE TABLE IF NOT EXISTS gnokee_maintenance.ingest_audit (
    audit_id           UUID        NOT NULL DEFAULT gen_random_uuid(),
    tenant_id          TEXT        NOT NULL,
    episode_uuid       UUID,
    our_id             TEXT,
    state              TEXT        NOT NULL CHECK (state IN ('begin', 'commit', 'fail')),
    actor              TEXT,
    source_url         TEXT,
    decision           TEXT,
    supersession_uuid  UUID,
    receipt            JSONB,
    error              JSONB,
    started_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at        TIMESTAMPTZ,
    PRIMARY KEY (audit_id)
);

CREATE INDEX IF NOT EXISTS ingest_audit_tenant_started_idx
    ON gnokee_maintenance.ingest_audit (tenant_id, started_at);
CREATE INDEX IF NOT EXISTS ingest_audit_episode_uuid_idx
    ON gnokee_maintenance.ingest_audit (tenant_id, episode_uuid)
    WHERE episode_uuid IS NOT NULL;
CREATE INDEX IF NOT EXISTS ingest_audit_failed_idx
    ON gnokee_maintenance.ingest_audit (tenant_id, started_at)
    WHERE state = 'fail';
