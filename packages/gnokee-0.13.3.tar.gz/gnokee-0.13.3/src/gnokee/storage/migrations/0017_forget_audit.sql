-- 0017_forget_audit.sql
-- ADR-0026 — system-scoped audit + journal for gnokee.forget pipeline (#130).
--
-- Schema isolation rationale: this table survives gnokee_forget_tenant(t).
-- That is its purpose — verifiable proof that the deletion happened, readable
-- by operators after the tenant is gone. Placing it in a separate schema
-- (gnokee_maintenance) decouples it from the per-tenant cascade and from
-- any future MCP audit-read surface that would need its own RLS pass.
--
-- The application connection retains full CRUD on this table because the
-- forget pipeline itself writes here; no SQL-pass-through surface in gnokee
-- today reaches this schema.
--
-- Row shape mirrors ingest_journal (ADR-0024) on its state-transition axis
-- (begin -> commit | fail). Resume semantics differ — see ADR-0026 §7.

CREATE SCHEMA IF NOT EXISTS gnokee_maintenance;

CREATE TABLE IF NOT EXISTS gnokee_maintenance.forget_audit (
    audit_id          UUID        NOT NULL DEFAULT gen_random_uuid(),
    tenant_id         TEXT        NOT NULL,
    scope             TEXT        NOT NULL CHECK (scope IN ('episode', 'tenant')),
    episode_uuid      UUID,
    cascade           BOOLEAN     NOT NULL DEFAULT FALSE,
    dry_run           BOOLEAN     NOT NULL DEFAULT FALSE,
    state             TEXT        NOT NULL CHECK (state IN ('begin', 'commit', 'fail')),
    actor             TEXT,
    reason            TEXT        NOT NULL,
    receipt           JSONB,        -- populated at 'commit'; ForgetReceiptDetail serialization
    error             JSONB,        -- populated at 'fail'; carries linked audit_id for Neo4j-only failures
    cascade_uuids     JSONB,        -- frozen descendant set when scope='episode' AND cascade=TRUE
    bitemporal_snap   JSONB,        -- per-deleted-uuid {asserted_at, valid_at, valid_until} captured pre-DELETE
    started_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at       TIMESTAMPTZ,
    PRIMARY KEY (audit_id),
    CHECK (
        (scope = 'episode' AND episode_uuid IS NOT NULL)
        OR
        (scope = 'tenant'  AND episode_uuid IS NULL)
    )
);

-- Resumable hot path: 'begin' state rows oldest-first per tenant.
CREATE INDEX IF NOT EXISTS forget_audit_resumable_idx
    ON gnokee_maintenance.forget_audit (tenant_id, started_at)
    WHERE state = 'begin';

-- 'fail' rows for resume_forget Neo4j-retry scan.
CREATE INDEX IF NOT EXISTS forget_audit_failed_idx
    ON gnokee_maintenance.forget_audit (tenant_id, started_at)
    WHERE state = 'fail';

-- No RLS. Schema-level isolation is the access model. Operator queries
-- this table directly; the application connection inserts/updates via
-- gnokee.storage.forget_audit module.
