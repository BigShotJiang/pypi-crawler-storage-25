-- 0001_episode_metadata.sql
-- Bi-temporal source-tx-time axis (per ADR-0004 + bi-temporal-auditor).
-- Graphiti's Episodic.created_at = ingest-system time only.
-- gnokee owns asserted_at = "when consumer learned of it".
-- NOTE: NO `DEFAULT now()` on asserted_at — Python layer resolves the
-- default to datetime.now(UTC) and passes the value explicitly. Otherwise
-- SQL insert-time would conflate with created_at semantics.

CREATE TABLE IF NOT EXISTS episode_metadata (
    tenant_id          TEXT        NOT NULL,
    episode_uuid       UUID        NOT NULL,
    valid_at           TIMESTAMPTZ NOT NULL,
    valid_until        TIMESTAMPTZ,
    asserted_at        TIMESTAMPTZ NOT NULL,
    asserted_until     TIMESTAMPTZ,
    superseded_by      UUID,
    sensitive          TEXT NOT NULL CHECK (sensitive IN ('public','private','clinical')),
    language           CHAR(2),
    PRIMARY KEY (tenant_id, episode_uuid)
);

CREATE INDEX IF NOT EXISTS idx_episode_metadata_valid_at
    ON episode_metadata (tenant_id, valid_at);

CREATE INDEX IF NOT EXISTS idx_episode_metadata_asserted_at
    ON episode_metadata (tenant_id, asserted_at);

-- v0.1: `superseded_by` is a Graphiti EntityEdge.uuid OR another episode_uuid.
-- No FK because Neo4j is the source of truth for fact existence + cross-store
-- FKs are not representable. Partial index supports v0.2 supersession queries.
CREATE INDEX IF NOT EXISTS idx_episode_metadata_superseded_by
    ON episode_metadata (tenant_id, superseded_by)
    WHERE superseded_by IS NOT NULL;
