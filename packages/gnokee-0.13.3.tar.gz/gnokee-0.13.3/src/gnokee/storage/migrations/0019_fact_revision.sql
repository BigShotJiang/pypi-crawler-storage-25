-- 0019_fact_revision.sql
-- ADR-0014 — fact-grain lineage: fact_revision table (#73).
--
-- Purpose. gnokee's recall pipeline currently surfaces facts at episode
-- granularity (one row in episode_metadata per ingest call). ADR-0014
-- introduces fact-grain tracking: every time the same logical fact
-- (identified by fact_id) is observed in a new episode, a new revision
-- row is written, forming an append-only audit chain via prior_revision_id.
--
-- Read path. gnokee_fact_history MCP tool (Task 9) reads this table via
-- (tenant_id, fact_id, asserted_at DESC) to reconstruct the full assertion
-- timeline for a single fact. World-time queries use (tenant_id, valid_at).
--
-- FK rationale.
--   fact_revision_episode_fk: composite FK to episode_metadata(tenant_id,
--     episode_uuid) because the episode PK is composite (ADR-0004). ON
--     DELETE CASCADE ensures forget_episode() removes revision rows without
--     requiring a separate DELETE in the forget pipeline.
--   fact_revision_prior_fk: self-referential, ON DELETE SET NULL so that
--     pruning an older revision does not orphan newer ones — the chain
--     simply becomes root-anchored at the surviving revision.
--
-- RLS. Matches existing posture (ingest_journal, 0015). The `true` flag
-- on current_setting makes the GUC return NULL when unset (operator
-- queries with the connection role bypass RLS rather than throwing).
-- A DO-block guard around CREATE POLICY keeps re-runs safe on PG15/16/17
-- (CREATE POLICY IF NOT EXISTS is PG18+ only).

CREATE TABLE IF NOT EXISTS fact_revision (
    revision_id        UUID        NOT NULL DEFAULT gen_random_uuid(),
    fact_id            UUID        NOT NULL,    -- gnokee LOGICAL identity (stable across corrects: chains; defaults to fact_uuid for fresh facts)
    fact_uuid          UUID        NOT NULL,    -- Graphiti EntityEdge.uuid (per-extraction; multiple fact_uuids may share one fact_id via prior_revision_id chain)
    tenant_id          TEXT        NOT NULL,
    episode_uuid       UUID        NOT NULL,
    valid_at           TIMESTAMPTZ NOT NULL,
    asserted_at        TIMESTAMPTZ NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    fact_text          TEXT        NOT NULL,
    source_node_uuid   UUID        NOT NULL,
    predicate          TEXT        NOT NULL,
    target_node_uuid   UUID        NOT NULL,
    prior_revision_id  UUID,
    PRIMARY KEY (revision_id),
    CONSTRAINT fact_text_nonempty CHECK (length(fact_text) > 0),
    CONSTRAINT fact_revision_episode_fk
        FOREIGN KEY (tenant_id, episode_uuid)
        REFERENCES episode_metadata (tenant_id, episode_uuid)
        ON DELETE CASCADE,
    CONSTRAINT fact_revision_prior_fk
        FOREIGN KEY (prior_revision_id)
        REFERENCES fact_revision (revision_id)
        ON DELETE SET NULL
);

-- Primary read path for gnokee_fact_history: history of a single fact
-- for a tenant, newest assertion first.
CREATE INDEX IF NOT EXISTS fact_revision_fact_history_idx
    ON fact_revision (tenant_id, fact_id, asserted_at DESC);

-- World-time filter: "what did we know was true at time T?"
CREATE INDEX IF NOT EXISTS fact_revision_valid_at_idx
    ON fact_revision (tenant_id, valid_at);

-- fact_uuid → fact_id resolution (Graphiti edge UUIDs are stable across
-- re-ingests; this index powers the deduplication lookup).
CREATE INDEX IF NOT EXISTS fact_revision_fact_uuid_idx
    ON fact_revision (tenant_id, fact_uuid);

-- Forget cascade + episode lineage: all revisions belonging to an episode.
CREATE INDEX IF NOT EXISTS fact_revision_episode_idx
    ON fact_revision (tenant_id, episode_uuid);

ALTER TABLE fact_revision ENABLE ROW LEVEL SECURITY;

-- ``CREATE POLICY IF NOT EXISTS`` is Postgres 18+ only. Use a DO guard
-- for idempotency on re-runs (narrow window: DDL committed, tracking
-- INSERT failed). Matches the safety intent of migration 0015.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policy
        WHERE polrelid = 'fact_revision'::regclass
          AND polname  = 'fact_revision_tenant_isolation'
    ) THEN
        EXECUTE $p$
            CREATE POLICY fact_revision_tenant_isolation ON fact_revision
                USING (tenant_id = current_setting('app.current_tenant', true))
        $p$;
    END IF;
END
$$;
