-- 0012_episode_body_encrypted.sql
-- Encrypted-body storage (issue #22, v0.3+).
--
-- Sibling table to episode_metadata. Holds consumer-supplied ciphertext +
-- nonce + key_id when the caller chose the `encrypted_body` branch at
-- ingest. gnokee NEVER sees plaintext for these episodes after the
-- (optional) embed-time pass — the consumer keeps the DEK in their KMS
-- (e.g. OpenBao for Omur) and decrypts on recall using `key_id`.
--
-- Sibling-table layout (over a column on episode_metadata):
--   * Keeps the unencrypted `content_text` path simple — the BM25
--     tsvector index, GIN, and the lite-mode rehydration column do not
--     fan out across an optional ciphertext column.
--   * Encrypted episodes are a minority of corpus rows; a sibling table
--     leaves episode_metadata at fixed-narrow row width.
--   * Cleanly separates the "no key material in gnokee" boundary from
--     the "narrative + bi-temporal axes" boundary.
--
-- FK + ON DELETE CASCADE matches the content_embedding pattern (0002):
-- gnokee deletes flow through episode_metadata → embeddings + body.
--
-- RLS: same model as content_embedding — predicate uses
-- (tenant_id = current_setting('app.current_tenant')) when the policy
-- gets enabled in deployment. v0.1/v0.3 leaves the policy disabled by
-- default (matches existing tables); WHERE tenant_id = $1 is the
-- enforcement layer in code.

CREATE TABLE IF NOT EXISTS episode_body_encrypted (
    tenant_id    TEXT  NOT NULL,
    episode_uuid UUID  NOT NULL,
    ciphertext   BYTEA NOT NULL,
    nonce        BYTEA NOT NULL,
    key_id       TEXT  NOT NULL,
    PRIMARY KEY (tenant_id, episode_uuid),
    FOREIGN KEY (tenant_id, episode_uuid)
        REFERENCES episode_metadata(tenant_id, episode_uuid) ON DELETE CASCADE
);

-- Tenant-scoped lookup index for the recall-side fetch:
--   SELECT ciphertext, nonce, key_id
--     FROM episode_body_encrypted
--    WHERE tenant_id = $1 AND episode_uuid = ANY($2::uuid[])
-- The PRIMARY KEY already covers (tenant_id, episode_uuid) so no
-- additional index is needed; this comment is a reminder for readers.
