-- 0024_clinical_record_source.sql
-- ADR-0009 + ADR-0010 amendments (#144). Adds 'source' column to
-- lab_record and med_record so caller-parsed rows (on encrypted_body
-- branch) can be distinguished from LLM-extracted rows.
--
-- Default 'llm_extracted' preserves the existing path; new
-- EpisodeIn.parsed_labs / parsed_meds writes flip the column to
-- 'caller_parsed'. CHECK constraint locks the allowed set so future
-- ingest paths can't silently coin a new source value.
--
-- Idempotent: `ADD COLUMN IF NOT EXISTS` is safe to re-run on already-
-- migrated databases (e.g. half-applied state recovery).

ALTER TABLE lab_record
    ADD COLUMN IF NOT EXISTS source TEXT NOT NULL DEFAULT 'llm_extracted'
        CHECK (source IN ('llm_extracted', 'caller_parsed'));

ALTER TABLE med_record
    ADD COLUMN IF NOT EXISTS source TEXT NOT NULL DEFAULT 'llm_extracted'
        CHECK (source IN ('llm_extracted', 'caller_parsed'));
