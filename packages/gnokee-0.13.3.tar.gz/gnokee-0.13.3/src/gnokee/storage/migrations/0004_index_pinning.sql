-- 0004_index_pinning.sql
-- Pin HNSW params explicitly + add `superseded_by` partial index.
-- 0002 originally relied on pgvector defaults; this migration makes the
-- params explicit on existing dev databases so the index plan is stable
-- across pgvector version bumps.
--
-- `CREATE INDEX IF NOT EXISTS` cannot modify an existing index; if the
-- existing index was built without explicit `m`/`ef_construction`, this
-- migration drops + recreates with pinned params. v0.1 dev only.

DROP INDEX IF EXISTS idx_content_embedding_hnsw;

CREATE INDEX IF NOT EXISTS idx_content_embedding_hnsw
    ON content_embedding USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);

CREATE INDEX IF NOT EXISTS idx_episode_metadata_superseded_by
    ON episode_metadata (tenant_id, superseded_by)
    WHERE superseded_by IS NOT NULL;
