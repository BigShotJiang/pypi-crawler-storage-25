-- 0005_episode_our_id.sql
-- Consumer-supplied stable id for ingest idempotency (v0.1.1).
-- Re-ingest with the same (tenant_id, our_id) returns the existing
-- episode_uuid instead of creating a duplicate Graphiti episode.
-- Q1 backlog item: prevent dups on identical `name` from re-fetched
-- sources (email connectors, calendar pollers, etc.).

ALTER TABLE episode_metadata
    ADD COLUMN IF NOT EXISTS our_id TEXT;

-- Partial unique index: NULL our_id is opt-out; only enforced when set.
CREATE UNIQUE INDEX IF NOT EXISTS episode_metadata_tenant_our_id_uq
    ON episode_metadata (tenant_id, our_id)
    WHERE our_id IS NOT NULL;
