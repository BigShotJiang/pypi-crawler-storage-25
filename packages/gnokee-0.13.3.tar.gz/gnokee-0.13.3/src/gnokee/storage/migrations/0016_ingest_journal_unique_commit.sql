-- 0016_ingest_journal_unique_commit.sql
-- ADR-0024 / issue #122 follow-up. Prevents concurrent maintenance.resume_ingest
-- calls for the same (tenant_id, episode_uuid) from writing two 'commit' rows.
--
-- Without this constraint, two operators calling resume_ingest in parallel
-- both pass scan_resumable (which only filters out begin-with-later-commit),
-- both re-execute Stage 4 + Stage 5 (idempotent thanks to ON CONFLICT), and
-- both append a 'commit' row. Data is safe (Stage 5 idempotency), but the
-- journal audit trail shows two commits for one logical ingest and two
-- callers each receive an IngestReceipt for what was a single replay.
--
-- Partial unique index on state='commit' guarantees at most one commit row
-- per (tenant_id, episode_uuid); the second concurrent resume hits a
-- UniqueViolationError at write_commit and surfaces as a typed error rather
-- than silent duplication.
--
-- 'begin' and 'fail' rows remain unconstrained — multiple attempts are
-- expected on those states (begin from the original crash, fail from each
-- failed resume retry).

CREATE UNIQUE INDEX IF NOT EXISTS ingest_journal_unique_commit_idx
    ON ingest_journal (tenant_id, episode_uuid)
    WHERE state = 'commit';
