-- 0025_autovacuum_content_embedding_ingest_audit.sql
-- Issue #230 — autovacuum tuning for the two remaining high-churn tables.
--
-- Background.
--   `content_embedding` (migration 0002) absorbs one 1024-dim insert per
--   `add_episode` on the hot path and bulk DELETE traffic from
--   `forget_episode` via FK cascade. HNSW indexes degrade with stale
--   dead tuples — both recall (ghost-row hits) and write-amp
--   compound at the global default `autovacuum_vacuum_scale_factor = 0.2`.
--
--   `gnokee_maintenance.ingest_audit` (migration 0023) is high UPDATE
--   churn: every ingest writes a `begin` row then UPDATEs to `commit`
--   or `fail`. The JSONB `receipt` / `error` columns TOAST-store and
--   leave dead tuples on every UPDATE, so the global default also
--   under-vacuums this table.
--
-- Fix. Tighten the per-table thresholds to 0.05, matching the posture
-- migrations 0018 (forget_audit) and 0021 (fact_revision) established.
--
-- Operator-facing only; schema layout, RLS posture (none on
-- `ingest_audit` by design — schema-isolated under `gnokee_maintenance`),
-- and table semantics are unchanged.

ALTER TABLE content_embedding
    SET (
        autovacuum_vacuum_scale_factor  = 0.05,
        autovacuum_analyze_scale_factor = 0.05
    );

ALTER TABLE gnokee_maintenance.ingest_audit
    SET (
        autovacuum_vacuum_scale_factor  = 0.05,
        autovacuum_analyze_scale_factor = 0.05
    );
