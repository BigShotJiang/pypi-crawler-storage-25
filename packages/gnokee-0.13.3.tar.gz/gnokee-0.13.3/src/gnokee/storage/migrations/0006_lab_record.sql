-- 0006_lab_record.sql
-- Structured clinical-lab store per ADR-0009.
--
-- Q7 spike (`evals/spike_q7_lab_results/`) showed graphiti's edge-fact
-- LLM strips numerics on lab panels (analyte values, reference ranges,
-- units) — episode retrieval works but value recall fails. v0.2 lifts
-- the structured half into this Postgres table; graphiti continues to
-- own the prose episode (panel notes, clinician comments, cross-doc
-- links). Recall federates the two stores like ADR-0008's
-- fact_contradiction does.
--
-- Bi-temporal half-pairs match `episode_metadata` (ADR-0004) so a
-- retroactive lab correction supersedes the same way panel narratives do:
--   - valid_at / valid_until = world-time the sample is true for
--   - asserted_at / asserted_until = source-tx-time the consumer learned of it
-- Python layer resolves both defaults; never DEFAULT now() in SQL (would
-- conflate with Graphiti's `created_at` ingest-system axis).

CREATE TABLE IF NOT EXISTS lab_record (
    tenant_id          TEXT        NOT NULL,
    episode_uuid       UUID        NOT NULL,
    analyte            TEXT        NOT NULL,         -- "Potassium", "Hemoglobin"
    loinc_code         TEXT        NULL,             -- when supplied
    value_numeric      NUMERIC     NULL,             -- machine-readable amount
    value_text         TEXT        NULL,             -- "<5", "trace", non-numeric
    unit               TEXT        NULL,             -- "mmol/L"
    ref_range_low      NUMERIC     NULL,
    ref_range_high     NUMERIC     NULL,
    abnormal_flag      TEXT        NULL CHECK (abnormal_flag IN ('L','H','C','N') OR abnormal_flag IS NULL),
    valid_at           TIMESTAMPTZ NOT NULL,         -- sample drawn time
    valid_until        TIMESTAMPTZ NULL,             -- supersession on correction
    asserted_at        TIMESTAMPTZ NOT NULL,         -- result reported time
    asserted_until     TIMESTAMPTZ NULL,
    PRIMARY KEY (tenant_id, episode_uuid, analyte, valid_at),
    FOREIGN KEY (tenant_id, episode_uuid)
        REFERENCES episode_metadata(tenant_id, episode_uuid) ON DELETE CASCADE
);

-- Time-pinned reads ("Potassium at 2024-04-01") are the dominant Q7 query
-- shape; index covers the (tenant, analyte, valid_at) lookup path.
CREATE INDEX IF NOT EXISTS idx_lab_record_tenant_analyte_valid
    ON lab_record (tenant_id, analyte, valid_at);

-- Range / aggregate reads ("min K+ in 2024") scan by analyte across time.
CREATE INDEX IF NOT EXISTS idx_lab_record_tenant_analyte_value
    ON lab_record (tenant_id, analyte, value_numeric)
    WHERE value_numeric IS NOT NULL;

-- Bi-temporal supersession trail ("show the original April panel pre-
-- correction"). Mirrors `idx_episode_metadata_asserted_at`.
CREATE INDEX IF NOT EXISTS idx_lab_record_asserted_at
    ON lab_record (tenant_id, asserted_at);
