-- 0018_forget_audit_prune_hardening.sql
-- Issue #155 — retention-prune hardening for gnokee_maintenance.forget_audit.
--
-- Background. Migration 0017 covered the hot resume/fail paths with two
-- partial indexes (state='begin', state='fail'). The retention pruner
-- (gnokee.maintenance.prune_forget_audit) scans the table on `started_at`
-- regardless of state, and the partial indexes do not cover that lookup.
-- Without a dedicated `started_at` index a global prune (`tenant_id=None`)
-- falls back to a seq scan, which is fine on a fresh deploy and ruinous on
-- a long-running operator install with high audit churn.
--
-- Additions in this migration:
--   1. Non-partial b-tree on `started_at` covering the prune cursor.
--   2. Per-table autovacuum thresholds tightened to 0.05 — append-only +
--      occasional UPDATE + bulk DELETE + JSONB columns benefit from more
--      aggressive dead-tuple reclamation than the 0.2 default.
--
-- Both changes are operator-facing only; the audit table semantics, RLS
-- posture, and schema layout are unchanged. ADR-0026 § Audit retention.

CREATE INDEX IF NOT EXISTS forget_audit_started_at_idx
    ON gnokee_maintenance.forget_audit (started_at);

ALTER TABLE gnokee_maintenance.forget_audit
    SET (
        autovacuum_vacuum_scale_factor  = 0.05,
        autovacuum_analyze_scale_factor = 0.05
    );
