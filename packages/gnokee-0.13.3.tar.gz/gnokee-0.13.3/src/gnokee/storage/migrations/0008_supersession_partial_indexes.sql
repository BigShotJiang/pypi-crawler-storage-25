-- 0008_supersession_partial_indexes.sql
-- Partial indexes on the OPEN subset of lab_record / med_record so
-- supersede_matching's UPDATE plan walks only currently-open rows
-- instead of full-PK + filter (issue #17).
--
-- v0.2.1 supersession-aware ingest (ADR-0009 status, ADR-0010 status)
-- closes prior rows by setting `asserted_until`. As corrections
-- accumulate, the open:closed ratio shrinks and the existing PK index
-- still has to read closed rows just to filter them out. The partial
-- indexes here let supersede_matching use a tighter index that only
-- contains rows where `asserted_until IS NULL`.
--
-- Read paths (`latest`, `history`, `aggregate`, `abnormal`) deliberately
-- DO NOT use this index — they need closed-but-tx-time-valid rows for
-- pre-correction `as_of` pins and would have to fall back to the PK
-- anyway. The index is supersession-only by design.
--
-- Pure perf win — non-load-bearing for v0.2.1 correctness; the PK
-- continues to satisfy the UPDATE if Postgres prefers it for any reason.

CREATE INDEX IF NOT EXISTS lab_record_open_idx
    ON lab_record (tenant_id, episode_uuid, analyte, valid_at)
    WHERE asserted_until IS NULL;

CREATE INDEX IF NOT EXISTS med_record_open_idx
    ON med_record (tenant_id, episode_uuid, drug_name, event_kind, valid_at)
    WHERE asserted_until IS NULL;
