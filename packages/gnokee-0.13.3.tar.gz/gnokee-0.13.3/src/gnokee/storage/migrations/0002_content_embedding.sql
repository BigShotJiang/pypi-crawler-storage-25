-- 0002_content_embedding.sql
-- Per-episode bge-m3 embedding (Q2 spike: 1024-dim, cosine).
-- Requires pgvector extension; the pgvector/pgvector:pg17 image enables it.

CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS content_embedding (
    tenant_id          TEXT         NOT NULL,
    episode_uuid       UUID         NOT NULL,
    embedding          vector(1024) NOT NULL,
    model              TEXT         NOT NULL DEFAULT 'bge-m3',
    PRIMARY KEY (tenant_id, episode_uuid),
    FOREIGN KEY (tenant_id, episode_uuid)
        REFERENCES episode_metadata(tenant_id, episode_uuid) ON DELETE CASCADE
);

-- HNSW params pinned (don't rely on pgvector defaults across versions).
-- m=16, ef_construction=64 = pgvector 0.5+ defaults; OK for v0.1 corpus size.
CREATE INDEX IF NOT EXISTS idx_content_embedding_hnsw
    ON content_embedding USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);
