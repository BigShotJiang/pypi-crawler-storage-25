-- 0014_episode_corrects_reason.sql
-- Per-episode supersession rationale string (issue #123, v0.7+).
--
-- Purpose: the `gnokee_history_of` MCP tool returns a supersession DAG with
-- a `rationale` field per node so an auditing LLM can surface "why was this
-- corrected" without re-summarizing the successor's body. `corrects_reason`
-- is the consumer-supplied rationale string declared via
-- `EpisodeIn.corrects_reason` at ingest time; capped at 500 chars to keep
-- the DAG payload inside the MCP token budget.
--
-- v0.7 ships the column as NULL on existing rows; pre-v0.7 supersessions
-- carry no rationale on the wire (`HistoryNode.rationale=null`). Newer
-- supersessions populate the column when the consumer passes it. No
-- backfill from `content_text` — that would be a heuristic paraphrase
-- without consumer consent.
--
-- Tenant scope: column lives on `episode_metadata`, same `(tenant_id,
-- episode_uuid)` PK + RLS contract as every other column. No new index
-- needed — `history_of` walks the supersession chain via existing
-- `superseded_by` pointers and reads `corrects_reason` along the way.

ALTER TABLE episode_metadata
    ADD COLUMN IF NOT EXISTS corrects_reason TEXT;
