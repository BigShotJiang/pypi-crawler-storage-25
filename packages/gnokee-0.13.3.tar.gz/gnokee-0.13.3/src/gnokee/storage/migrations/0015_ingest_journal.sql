-- 0015_ingest_journal.sql
-- ADR-0024 / issue #122 — append-only crash-recovery journal for the Stage 4 -> Stage 5
-- ingest boundary. One 'begin' row before Stage 4, one 'commit' row after Stage 5,
-- 'fail' rows on unhandled exceptions. Resume is opt-in via maintenance.resume_ingest;
-- gnokee never auto-replays.
--
-- Granularity decision: two rows per ingest, not per-Stage. Stage 5 is already one
-- atomic txn; Stage 6 has its own journal in episode_metadata.extraction_deferred
-- (ADR-0023). The only durability gap is Stage 4 lite-Episodic landed in Neo4j but
-- Stage 5 Postgres txn never committed.

CREATE TABLE IF NOT EXISTS ingest_journal (
    tenant_id        TEXT      NOT NULL,
    our_id           TEXT,                       -- nullable, mirrors episode_metadata
    episode_uuid     UUID      NOT NULL,         -- gnokee-generated at Stage 3.5
    payload_hash     CHAR(64)  NOT NULL,         -- hex SHA-256(tenant_id || our_id || valid_at)
    state            TEXT      NOT NULL CHECK (state IN ('begin', 'commit', 'fail')),
    seq              SERIAL    NOT NULL,
    stage_4_time     TIMESTAMPTZ NOT NULL,       -- replay-stable created_at for write_lite_episode
    error            TEXT,                       -- non-null on 'fail' rows
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant_id, episode_uuid, state, seq)
);

-- Hot path for scan_resumable: "begin rows for this tenant ordered oldest-first".
-- Partial index keeps the index small as 'commit' / 'fail' rows accumulate.
CREATE INDEX IF NOT EXISTS ingest_journal_resumable_idx
    ON ingest_journal (tenant_id, episode_uuid, created_at)
    WHERE state = 'begin';

-- RLS: tenant isolation via app.current_tenant GUC.
--
-- NOTE: this is the FIRST gnokee table that ships with RLS enabled
-- inline at migration time. Sibling tables (episode_metadata,
-- content_embedding, episode_body_encrypted, …) currently defer RLS
-- to a deployment-time step; their migration comments call this out.
-- Enabling RLS here is intentional: ingest_journal is a new write
-- surface and we want defence-in-depth from day one. A follow-up
-- issue tracks aligning the sibling tables to the same on-by-default
-- posture.
--
-- ``CREATE POLICY IF NOT EXISTS`` is Postgres 18+ only. Use a DO guard
-- for idempotency on re-runs (narrow window: DDL committed, tracking
-- INSERT failed). Matches the safety intent of migration 0019.
ALTER TABLE ingest_journal ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policy
        WHERE polrelid = 'ingest_journal'::regclass
          AND polname  = 'ingest_journal_tenant_isolation'
    ) THEN
        EXECUTE $p$
            CREATE POLICY ingest_journal_tenant_isolation ON ingest_journal
                USING (tenant_id = current_setting('app.current_tenant', true))
        $p$;
    END IF;
END
$$;

-- Forget-cascade dependency:
-- gnokee.forget(tenant_id) MUST include
--   DELETE FROM ingest_journal WHERE tenant_id = $1
-- alongside DELETE FROM episode_metadata WHERE tenant_id = $1.
-- We do NOT use a FK to episode_metadata(tenant_id, episode_uuid)
-- because the 'begin' row is written BEFORE the Stage 5 metadata
-- insert — a FK constraint would block the journal write. Cascade
-- responsibility therefore lives in the forget pipeline, not the FK.
-- Track in ADR-0024 §References + a follow-up issue once a concrete
-- gnokee.forget() implementation is on the roadmap.
