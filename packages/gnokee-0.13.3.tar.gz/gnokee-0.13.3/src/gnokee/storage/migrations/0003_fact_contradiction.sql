-- 0003_fact_contradiction.sql
-- Contradiction storage (per ADR-0008). Lives in pg, not Neo4j, because
-- Graphiti's edge-of-edge model is not representable in Neo4j.
-- fact_uuid_a and fact_uuid_b reference Graphiti EntityEdge.uuid (not pg-FK'd).
-- verdict echoes the Q4 classifier output verbatim.
-- `unrelated` verdicts are not stored; the table holds only rows worth surfacing.

CREATE TABLE IF NOT EXISTS fact_contradiction (
    tenant_id          TEXT        NOT NULL,
    fact_uuid_a        UUID        NOT NULL,
    fact_uuid_b        UUID        NOT NULL,
    verdict            TEXT        NOT NULL CHECK (verdict IN ('refinement','update','contradiction')),
    detected_at        TIMESTAMPTZ NOT NULL,
    summary_a          TEXT        NOT NULL,
    summary_b          TEXT        NOT NULL,
    PRIMARY KEY (tenant_id, fact_uuid_a, fact_uuid_b)
);

CREATE INDEX IF NOT EXISTS idx_fact_contradiction_a
    ON fact_contradiction (tenant_id, fact_uuid_a);

CREATE INDEX IF NOT EXISTS idx_fact_contradiction_b
    ON fact_contradiction (tenant_id, fact_uuid_b);
