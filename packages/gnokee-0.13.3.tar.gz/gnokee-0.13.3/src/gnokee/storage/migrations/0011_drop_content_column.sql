-- 0011_drop_content_column.sql
-- Consolidate episode_metadata.content + content_text (issue #51, v0.4).
--
-- Background: PR #46 (BM25/RRF) added content_text as the FTS source.
-- PR #47 (deferred extraction) added content as the rehydrate source for
-- maintenance.run_deferred_extraction(). For lite-mode plaintext episodes
-- both columns stored the same bytes; for full-mode plaintext episodes
-- only content_text was populated. Two columns, one fact — drop content.
--
-- Option A (taken): drop `content`, have run_deferred_extraction read
-- content_text. Single source of truth. PgVectorStore.write_content_text
-- remains the canonical write path.
-- Option B (rejected): drop content_text, force `content` for full-mode
-- too — undoes PR #47's storage-saving rationale (Graphiti already holds
-- the canonical body for full-mode episodes).
--
-- Backfill: copy content into content_text where content_text is NULL
-- but content is populated. In practice the lite-ingest write path always
-- populated both, so this is a defence-in-depth catch for any deferred
-- rows that a future code path could have written content-only.
-- Encrypted-body episodes leave both columns NULL and stay NULL — they
-- are out of scope for FTS and out of scope for deferred extraction
-- (issue #22 / encrypted_body branch).

UPDATE episode_metadata
   SET content_text = content
 WHERE content      IS NOT NULL
   AND content_text IS NULL;

ALTER TABLE episode_metadata
    DROP COLUMN IF EXISTS content;
