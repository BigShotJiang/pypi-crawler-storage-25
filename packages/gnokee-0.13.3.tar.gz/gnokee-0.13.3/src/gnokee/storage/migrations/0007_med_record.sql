-- 0007_med_record.sql
-- Structured medication-history store per ADR-0010.
--
-- Sibling to lab_record (ADR-0009 / migration 0006). Q8 spike
-- (`evals/spike_q8_med_supersession/`) showed graphiti's edge-fact LLM
-- preserves drug-name + clinical-narrative ("patient stopped Lisinopril
-- due to cough") but strips dates and dose numerals — same root cause
-- as Q7 labs, milder because narrative survives. v0.2 lifts the
-- structured half here.
--
-- Bi-temporal half-pairs match `episode_metadata` and `lab_record`:
--   - valid_at / valid_until = world-time the event happened (the next
--     event for the same drug supersedes by setting prior valid_until)
--   - asserted_at / asserted_until = source-tx-time the consumer learned

CREATE TABLE IF NOT EXISTS med_record (
    tenant_id          TEXT        NOT NULL,
    episode_uuid       UUID        NOT NULL,
    drug_name          TEXT        NOT NULL,         -- "Lisinopril"
    rxnorm_code        TEXT        NULL,             -- when supplied
    drug_class         TEXT        NULL,             -- "ACE inhibitor"
    dose_value         NUMERIC     NULL,
    dose_unit          TEXT        NULL,             -- "mg" / "mEq" / "mcg"
    frequency          TEXT        NULL,             -- "daily", "BID"
    route              TEXT        NULL,             -- "PO", "IV", "topical"
    event_kind         TEXT        NOT NULL CHECK (event_kind IN (
        'start','increase','decrease','stop','switch','allergy','documented'
    )),
    reason             TEXT        NULL,             -- "cough", "anemia resolved"
    valid_at           TIMESTAMPTZ NOT NULL,
    valid_until        TIMESTAMPTZ NULL,
    asserted_at        TIMESTAMPTZ NOT NULL,
    asserted_until     TIMESTAMPTZ NULL,
    PRIMARY KEY (tenant_id, episode_uuid, drug_name, event_kind, valid_at),
    FOREIGN KEY (tenant_id, episode_uuid)
        REFERENCES episode_metadata(tenant_id, episode_uuid) ON DELETE CASCADE
);

-- "active meds at YYYY-MM-DD" / "current BP med" / "history of Lisinopril"
-- — drug-name lookup over time-pinned reads is the dominant Q8 shape.
CREATE INDEX IF NOT EXISTS idx_med_record_tenant_drug_valid
    ON med_record (tenant_id, drug_name, valid_at);

-- Drug-class history ("ACE-inhibitor use"); skip rows with NULL class so
-- the index stays tight when classification is absent.
CREATE INDEX IF NOT EXISTS idx_med_record_tenant_class_valid
    ON med_record (tenant_id, drug_class, valid_at)
    WHERE drug_class IS NOT NULL;

-- Allergy lookup — frequent typed read, partial index keeps it small.
CREATE INDEX IF NOT EXISTS idx_med_record_allergies
    ON med_record (tenant_id, drug_name)
    WHERE event_kind = 'allergy';

-- Supersession trail — dose-change history needs asserted_at chronology.
CREATE INDEX IF NOT EXISTS idx_med_record_asserted_at
    ON med_record (tenant_id, asserted_at);
