-- 0022_short_id_map_seq.sql
-- ADR-0027 — MCP short-ID translation (#197).
--
-- Per-tenant per-kind monotonic counter + UUID ↔ short-ID map table.
-- Stable for the LLM consumer: replaces 36-char UUIDs with `ep_017`,
-- `fact_042`, `ent_005` in every gnokee_* MCP tool response.

CREATE TABLE IF NOT EXISTS short_id_map (
    tenant_id    TEXT  NOT NULL,
    target_kind  TEXT  NOT NULL CHECK (target_kind IN ('ep', 'fact', 'ent')),
    target_uuid  UUID  NOT NULL,
    short_id     TEXT  NOT NULL,
    seq          BIGINT NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant_id, target_kind, target_uuid),
    UNIQUE (tenant_id, short_id)
);

CREATE TABLE IF NOT EXISTS short_id_seq (
    tenant_id    TEXT NOT NULL,
    target_kind  TEXT NOT NULL,
    next_seq     BIGINT NOT NULL DEFAULT 1,
    PRIMARY KEY (tenant_id, target_kind)
);

ALTER TABLE short_id_map ENABLE ROW LEVEL SECURITY;
ALTER TABLE short_id_seq ENABLE ROW LEVEL SECURITY;

-- RLS policies follow the DO-block idiom from 0015 / 0019 / 0020.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policy
        WHERE polrelid = 'short_id_map'::regclass
          AND polname  = 'short_id_map_tenant_isolation'
    ) THEN
        EXECUTE $POL$
            CREATE POLICY short_id_map_tenant_isolation ON short_id_map
                USING (tenant_id = current_setting('app.current_tenant', true))
        $POL$;
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policy
        WHERE polrelid = 'short_id_seq'::regclass
          AND polname  = 'short_id_seq_tenant_isolation'
    ) THEN
        EXECUTE $POL$
            CREATE POLICY short_id_seq_tenant_isolation ON short_id_seq
                USING (tenant_id = current_setting('app.current_tenant', true))
        $POL$;
    END IF;
END $$;
