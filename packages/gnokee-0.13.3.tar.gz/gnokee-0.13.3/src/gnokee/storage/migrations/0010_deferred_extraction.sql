-- 0010_deferred_extraction.sql
-- Lite-ingest deferred-extraction columns (issue #47, v0.3).
--
-- extraction_deferred: set TRUE by ingest_episode(extract=False); cleared
--   to FALSE by maintenance.run_deferred_extraction() on success.
--   Graphiti add_episode + contradiction detection are skipped until this
--   flag is cleared; the episode is invisible to gnokee_recall narrative
--   facts while the flag is TRUE.
--   NO DEFAULT FALSE at SQL level — Python layer passes the value explicitly
--   (same convention as asserted_at: never rely on SQL DEFAULT for business
--   logic values).
--
-- extraction_completed_at: stamped to now(UTC) by the maintenance helper
--   on successful back-fill. NULL while the flag is TRUE or the episode was
--   never in lite mode (extraction_deferred=FALSE, extraction_completed_at NULL
--   = full-mode original ingest; FALSE + non-NULL = deferred then back-filled).
--
-- content: plaintext episode body stored for deferred-extraction rehydration.
--   Required when extract=False so the maintenance helper can call
--   graphiti.add_episode(content=...) without consumer involvement.
--   NULL for full-mode episodes (content is already in Graphiti's Episodic node
--   and is not re-stored here to avoid duplication).
--   Per AGENTS.md "no key" invariant: consumer must NOT pass encrypted_body
--   with extract=False in v0.3 — encrypted content cannot be rehydrated for
--   extraction without the DEK, which gnokee does not hold.

ALTER TABLE episode_metadata
    ADD COLUMN IF NOT EXISTS extraction_deferred      BOOLEAN     NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS extraction_completed_at  TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS content                  TEXT;

-- Index for the maintenance helper's WHERE clause:
-- SELECT ... FROM episode_metadata
--  WHERE tenant_id = $1 AND extraction_deferred = TRUE AND ...
-- Partial index on the deferred subset keeps the scan tight as the
-- table grows (deferred rows become a small minority over time).
CREATE INDEX IF NOT EXISTS idx_episode_metadata_deferred
    ON episode_metadata (tenant_id, valid_at)
    WHERE extraction_deferred = TRUE;
