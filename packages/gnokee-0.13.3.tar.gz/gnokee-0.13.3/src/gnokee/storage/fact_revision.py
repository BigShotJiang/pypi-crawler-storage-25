"""src/gnokee/storage/fact_revision.py — fact_revision CRUD (ADR-0014).

Append-only revision log keyed on `fact_id`. Written by Stage 6c in
src/gnokee/ingest.py; read by FactHistoryPipeline in
src/gnokee/fact_history.py.

Per ADR-0014: no UPDATE, no DELETE outside forget cascade. Empty
fact_text rejected at Python + SQL CHECK layers (tombstones DISALLOWED).

exports: FactRevisionRow | FactRevisionStore
used_by: src/gnokee/ingest.py | src/gnokee/fact_history.py | src/gnokee/bootstrap.py
rules:   tenant_id on every read/write; append-only; tz-aware UTC
agent:   claude-sonnet-4-6 | 2026-05-16 | issue #73 ADR-0014
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

import asyncpg

__all__ = ["FactRevisionRow", "FactRevisionStore"]


@dataclass(slots=True)
class FactRevisionRow:
    """Internal storage shape for a single fact_revision row.

    NOT frozen: `revision_id` and `created_at` are filled by DB DEFAULT
    after insert; callers may mutate those two fields post-insert.

    Validation rules (enforced in __post_init__):
    - fact_text must be non-empty (tombstones DISALLOWED per ADR-0014).
    - valid_at, asserted_at, and (when set) created_at must be tz-aware UTC.
    """

    fact_id: UUID
    fact_uuid: UUID
    tenant_id: str
    episode_uuid: UUID
    valid_at: datetime
    asserted_at: datetime
    fact_text: str
    source_node_uuid: UUID
    predicate: str
    target_node_uuid: UUID
    prior_revision_id: UUID | None
    revision_id: UUID | None = None  # filled by DB DEFAULT on insert
    created_at: datetime | None = None  # filled by DB DEFAULT on insert
    # Populated by FactHistoryPipeline via GraphitiStore.fact_invalid_at_lookup
    # (ADR-0014 §Decision 3); None = edge still open at lookup time.
    superseded_at: datetime | None = None

    def __post_init__(self) -> None:
        if not self.fact_text:
            raise ValueError("fact_text must be non-empty (tombstones DISALLOWED per ADR-0014)")
        # Issue #183 — `created_at` is filled by DB DEFAULT on insert, but
        # when callers (resume_ingest backfill, tests) supply it explicitly
        # it must satisfy the same tz-aware UTC invariant as the other two
        # timestamps. A naive datetime here would silently break downstream
        # comparators that assume tz-aware UTC.
        timestamps: tuple[tuple[str, datetime | None], ...] = (
            ("valid_at", self.valid_at),
            ("asserted_at", self.asserted_at),
            ("created_at", self.created_at),
        )
        for name, dt in timestamps:
            if dt is None:
                continue
            if dt.tzinfo is None or dt.utcoffset() is None:
                raise ValueError(f"{name} must be tz-aware UTC")


class FactRevisionStore:
    """Async CRUD for the fact_revision table.

    All methods accept a caller-owned `conn: asyncpg.Connection` so the
    caller controls transaction boundaries (gnokee convention — see
    src/gnokee/storage/forget_audit.py for the same pattern).

    Five methods only — per ADR-0014 this table is append-only:
      insert_batch                       — write N rows, returns new revision_ids
      fetch_by_fact_id                   — read all revisions for a fact (with optional as_of)
      fetch_by_fact_uuid                 — resolve fact_uuid → single row (or None)
      latest_revisions_at_for_fact_uuids — MAX(asserted_at <= as_of) per fact_id,
                                           resolved from caller-supplied fact_uuids
                                           (wiki_export past-snapshot render path, #170)
      existing_fact_uuids                — set-intersection: which fact_uuids already have
                                           a row (backfill idempotency, #169)
    """

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    async def insert_batch(
        self,
        *,
        conn: asyncpg.Connection,
        rows: list[FactRevisionRow],
    ) -> list[UUID]:
        """Insert N rows into fact_revision, RETURNING revision_id for each.

        Returns the list of new revision_ids in input order. Also mutates
        each input row to set `row.revision_id` for caller chaining.

        Empty list → returns [] without touching the DB.
        """
        if not rows:
            return []

        sql = """
            INSERT INTO fact_revision (
                fact_id, fact_uuid, tenant_id, episode_uuid,
                valid_at, asserted_at, fact_text,
                source_node_uuid, predicate, target_node_uuid,
                prior_revision_id
            ) VALUES (
                $1, $2, $3, $4,
                $5, $6, $7,
                $8, $9, $10,
                $11
            )
            RETURNING revision_id;
        """
        revision_ids: list[UUID] = []
        # TODO(perf): replace per-row fetchrow with single `INSERT ... SELECT ... FROM
        # unnest($1::uuid[], ...)` round-trip when typical Stage 6c N grows past ~10.
        # Current 1-roundtrip-per-row is acceptable at v0.9 throughput.
        for row in rows:
            record = await conn.fetchrow(
                sql,
                row.fact_id,
                row.fact_uuid,
                row.tenant_id,
                row.episode_uuid,
                row.valid_at,
                row.asserted_at,
                row.fact_text,
                row.source_node_uuid,
                row.predicate,
                row.target_node_uuid,
                row.prior_revision_id,
            )
            if record is None:
                raise RuntimeError("INSERT INTO fact_revision returned no row")
            rid: UUID = record["revision_id"]
            row.revision_id = rid
            revision_ids.append(rid)
        return revision_ids

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    async def fetch_by_fact_id(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        fact_id: UUID,
        as_of: datetime | None = None,
    ) -> list[FactRevisionRow]:
        """Return all revisions for a fact, newest-first.

        Filters:
        - tenant_id + fact_id always applied.
        - `as_of`: if set, adds `AND asserted_at <= as_of` (point-in-time
          query — returns only revisions asserted on or before that moment).

        Per ADR-0014 the log is append-only; every revision is preserved.
        Supersession closure (`superseded_at`) is joined onto each row by
        `FactHistoryPipeline` via `GraphitiStore.fact_invalid_at_lookup`,
        not filtered here.

        ORDER BY asserted_at DESC, revision_id DESC.
        """
        base_sql = """
            SELECT revision_id, fact_id, fact_uuid, tenant_id, episode_uuid,
                   valid_at, asserted_at, created_at, fact_text,
                   source_node_uuid, predicate, target_node_uuid, prior_revision_id
              FROM fact_revision
             WHERE tenant_id = $1
               AND fact_id = $2
        """
        params: list[object] = [tenant_id, fact_id]
        if as_of is not None:
            params.append(as_of)
            base_sql += f" AND asserted_at <= ${len(params)}"
        base_sql += " ORDER BY asserted_at DESC, revision_id DESC;"

        records = await conn.fetch(base_sql, *params)
        return [_row_from_record(r) for r in records]

    async def latest_revisions_at_for_fact_uuids(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        as_of: datetime,
        fact_uuids: list[UUID],
    ) -> dict[UUID, FactRevisionRow]:
        """Per-fact "what was believed at T" lookup, keyed by input fact_uuid.

        For each fact_uuid the caller passes (typically extracted from the
        current Graphiti snapshot), resolve its logical `fact_id` via the
        ``fact_revision_fact_uuid_idx`` index, then pick the
        MAX(asserted_at) revision where ``asserted_at <= as_of``. Returns
        ``{input_fact_uuid: revision}`` — entries are omitted when the
        fact has no revision asserted on or before ``as_of`` (i.e. the
        fact did not yet exist at time T).

        Used by the wiki_export render path (issue #170 / ADR-0014) to
        rewrite per-entity fact text when the caller pins ``as_of`` to a
        past timestamp. One SQL round-trip regardless of input length;
        the CTE resolves fact_uuid → fact_id and the outer query is the
        canonical PG ``DISTINCT ON (fact_id) ... ORDER BY fact_id,
        asserted_at DESC`` MAX-per-group idiom, which rides
        ``fact_revision_fact_history_idx`` (tenant_id, fact_id,
        asserted_at DESC) per migration 0019.

        Empty input → returns ``{}`` without touching the DB.
        """
        if not fact_uuids:
            return {}
        if as_of.tzinfo is None:
            raise ValueError("as_of must be tz-aware UTC")

        # Two CTEs:
        #   pairs        — input fact_uuids paired with their resolved fact_id.
        #                  We carry the input fact_uuid through so the caller
        #                  can splice the result back into its EntityFactRow
        #                  list without an extra reverse lookup.
        #   resolved     — MAX(asserted_at <= as_of) per fact_id.
        # Inputs that resolve to no fact_id (fact_uuid absent from
        # fact_revision) or whose fact_id has no revision <= as_of drop out
        # naturally via the INNER JOIN.
        #
        # The `LIMIT 1` in the LATERAL is safe because
        # `fact_revision_fact_uuid_idx ON fact_revision (tenant_id, fact_uuid)`
        # (migration 0019) plus the supersession invariant gives
        # (tenant_id, fact_uuid) → at-most-one fact_id. If a future
        # migration drops that index or relaxes the invariant, this LIMIT 1
        # silently picks the first row and the past-`as_of` render path
        # breaks. Re-evaluate before touching 0019 or the fact-grain
        # supersession story.
        sql = """
            WITH input_uuids AS (
                SELECT DISTINCT unnest($3::uuid[]) AS input_fact_uuid
            ),
            pairs AS (
                SELECT i.input_fact_uuid,
                       fr.fact_id
                  FROM input_uuids i
                  JOIN LATERAL (
                       SELECT fact_id
                         FROM fact_revision
                        WHERE tenant_id = $1
                          AND fact_uuid = i.input_fact_uuid
                        LIMIT 1
                  ) fr ON TRUE
            ),
            resolved AS (
                SELECT DISTINCT ON (fr.fact_id)
                       fr.revision_id, fr.fact_id, fr.fact_uuid, fr.tenant_id,
                       fr.episode_uuid, fr.valid_at, fr.asserted_at, fr.created_at,
                       fr.fact_text, fr.source_node_uuid, fr.predicate,
                       fr.target_node_uuid, fr.prior_revision_id
                  FROM fact_revision fr
                 WHERE fr.tenant_id = $1
                   AND fr.asserted_at <= $2
                   AND fr.fact_id IN (SELECT fact_id FROM pairs)
                 ORDER BY fr.fact_id, fr.asserted_at DESC
            )
            SELECT p.input_fact_uuid,
                   r.revision_id, r.fact_id, r.fact_uuid, r.tenant_id,
                   r.episode_uuid, r.valid_at, r.asserted_at, r.created_at,
                   r.fact_text, r.source_node_uuid, r.predicate,
                   r.target_node_uuid, r.prior_revision_id
              FROM pairs p
              JOIN resolved r ON r.fact_id = p.fact_id;
        """
        records = await conn.fetch(sql, tenant_id, as_of, fact_uuids)
        out: dict[UUID, FactRevisionRow] = {}
        for r in records:
            out[r["input_fact_uuid"]] = _row_from_record(r)
        return out

    async def existing_fact_uuids(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        fact_uuids: list[UUID],
    ) -> set[UUID]:
        """Return the subset of ``fact_uuids`` that already have a row.

        Used by ``maintenance.backfill_fact_revisions`` (issue #169 —
        Stage 6c crash-recovery class) for idempotency: edges whose
        ``fact_uuid`` already lives in ``fact_revision`` are filtered
        out of the backfill batch so re-running the maintenance task
        never double-writes.

        Empty input → returns ``set()`` without touching the DB.
        Single round-trip on ``fact_revision_fact_uuid_idx``.
        """
        if not fact_uuids:
            return set()
        sql = """
            SELECT DISTINCT fact_uuid
              FROM fact_revision
             WHERE tenant_id = $1
               AND fact_uuid = ANY($2::uuid[]);
        """
        records = await conn.fetch(sql, tenant_id, fact_uuids)
        return {r["fact_uuid"] for r in records}

    async def fetch_by_fact_uuid(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        fact_uuid: UUID,
    ) -> FactRevisionRow | None:
        """Return one row by fact_uuid, or None if absent.

        Used by FactHistoryPipeline to resolve fact_uuid → fact_id when
        the MCP caller passes either identifier.
        """
        sql = """
            SELECT revision_id, fact_id, fact_uuid, tenant_id, episode_uuid,
                   valid_at, asserted_at, created_at, fact_text,
                   source_node_uuid, predicate, target_node_uuid, prior_revision_id
              FROM fact_revision
             WHERE tenant_id = $1
               AND fact_uuid = $2
             LIMIT 1;
        """
        record = await conn.fetchrow(sql, tenant_id, fact_uuid)
        return _row_from_record(record) if record else None


# ------------------------------------------------------------------
# Internal helpers
# ------------------------------------------------------------------


def _row_from_record(r: asyncpg.Record) -> FactRevisionRow:
    """Deserialize one asyncpg Record into a FactRevisionRow."""
    return FactRevisionRow(
        revision_id=r["revision_id"],
        fact_id=r["fact_id"],
        fact_uuid=r["fact_uuid"],
        tenant_id=r["tenant_id"],
        episode_uuid=r["episode_uuid"],
        valid_at=r["valid_at"],
        asserted_at=r["asserted_at"],
        created_at=r["created_at"],
        fact_text=r["fact_text"],
        source_node_uuid=r["source_node_uuid"],
        predicate=r["predicate"],
        target_node_uuid=r["target_node_uuid"],
        prior_revision_id=r["prior_revision_id"],
    )
