"""src/gnokee/storage/med.py — med_record adapter (ADR-0010).

Sibling of `lab` (ADR-0009 / migration 0006). Same shape: structured
clinical write target the v0.1 stack off-ramped to a typed Postgres
table because graphiti's edge-fact LLM strips dates and dose numerals.

Bi-temporal half-pairs match `episode_metadata` / `lab_record`:
  - valid_at   = when the medication event happened
  - asserted_at = when the consumer documented it

exports: class MedStore | MedRecordRow
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py
rules:   tenant_id on every read+write; tz-aware UTC; never SQL DEFAULT now()
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0010
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from uuid import UUID

import asyncpg

from gnokee.errors import VectorStoreError

_VALID_EVENT_KINDS = frozenset(
    {"start", "increase", "decrease", "stop", "switch", "allergy", "documented"},
)


@dataclass(frozen=True)
class MedRecordRow:
    """One row destined for `med_record`. Temporal fields filled by caller.

    ``source`` discriminates ingest paths (migration 0024 / #144):
    ``'llm_extracted'`` (default) for Stage 4 deterministic-parser output
    on the plaintext branch; ``'caller_parsed'`` for ``EpisodeIn.parsed_meds``
    rows on the encrypted_body branch. CHECK constraint on the table
    locks the set.
    """

    tenant_id: str
    episode_uuid: UUID
    drug_name: str
    event_kind: str  # validated against _VALID_EVENT_KINDS at write time
    valid_at: datetime
    asserted_at: datetime
    rxnorm_code: str | None = None
    drug_class: str | None = None
    dose_value: Decimal | None = None
    dose_unit: str | None = None
    frequency: str | None = None
    route: str | None = None
    reason: str | None = None
    valid_until: datetime | None = None
    asserted_until: datetime | None = None
    source: str = "llm_extracted"


class MedStore:
    """Async wrapper around the `med_record` table."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def write_rows(
        self,
        *,
        conn: asyncpg.Connection,
        rows: list[MedRecordRow],
    ) -> int:
        """Insert all rows in the caller's transaction. Returns count inserted.

        Rejects unknown `event_kind` values pre-flight rather than relying
        on the SQL CHECK constraint to surface the error mid-txn (which
        would abort the txn and roll back the metadata + vector writes).
        """
        if not rows:
            return 0
        for row in rows:
            if row.event_kind not in _VALID_EVENT_KINDS:
                raise VectorStoreError(
                    f"med_record.write_rows: invalid event_kind {row.event_kind!r}",
                )
        try:
            inserted = 0
            for row in rows:
                result = await conn.fetchrow(
                    """
                    INSERT INTO med_record (
                        tenant_id, episode_uuid, drug_name, rxnorm_code,
                        drug_class, dose_value, dose_unit, frequency, route,
                        event_kind, reason,
                        valid_at, valid_until, asserted_at, asserted_until,
                        source
                    ) VALUES (
                        $1, $2, $3, $4,
                        $5, $6, $7, $8, $9,
                        $10, $11,
                        $12, $13, $14, $15,
                        $16
                    )
                    ON CONFLICT DO NOTHING
                    RETURNING drug_name
                    """,
                    row.tenant_id,
                    row.episode_uuid,
                    row.drug_name,
                    row.rxnorm_code,
                    row.drug_class,
                    row.dose_value,
                    row.dose_unit,
                    row.frequency,
                    row.route,
                    row.event_kind,
                    row.reason,
                    row.valid_at,
                    row.valid_until,
                    row.asserted_at,
                    row.asserted_until,
                    row.source,
                )
                if result is not None:
                    inserted += 1
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"med_record.write_rows failed: {exc}") from exc
        return inserted

    async def active(
        self,
        *,
        tenant_id: str,
        drug_name: str | None,
        as_of: datetime,
        valid_at: datetime,
    ) -> list[MedRecordRow]:
        """Currently-active meds visible at (`as_of`, `valid_at`).

        For each drug (or just the named one), returns the latest visible
        event ≤ `valid_at` whose `event_kind` is not `stop` or `allergy`.
        Single row per drug. Driven by Q8's `q_active_meds_at_time_pin`
        and `q_current_bp_med` shapes.
        """
        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    WITH latest AS (
                        SELECT DISTINCT ON (drug_name)
                               tenant_id, episode_uuid, drug_name, rxnorm_code,
                               drug_class, dose_value, dose_unit, frequency, route,
                               event_kind, reason,
                               valid_at, valid_until, asserted_at, asserted_until
                          FROM med_record
                         WHERE tenant_id = $1
                           AND ($2::text IS NULL OR drug_name = $2)
                           AND asserted_at <= $3
                           AND (asserted_until IS NULL OR asserted_until > $3)
                           AND (valid_until    IS NULL OR valid_until    > $4)
                           AND valid_at <= $4
                      ORDER BY drug_name, valid_at DESC
                    )
                    SELECT * FROM latest
                     WHERE event_kind NOT IN ('stop','allergy')
                  ORDER BY drug_name ASC
                    """,
                    tenant_id,
                    drug_name,
                    as_of,
                    valid_at,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"med_record.active failed: {exc}") from exc
        return [_row_to_dc(r) for r in rows]

    async def history(
        self,
        *,
        tenant_id: str,
        drug_name: str,
        since: datetime | None,
        until: datetime | None,
        as_of: datetime,
        valid_at: datetime,
        limit: int,
    ) -> list[MedRecordRow]:
        """All visible events for the named drug, ascending by `valid_at`."""
        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT tenant_id, episode_uuid, drug_name, rxnorm_code,
                           drug_class, dose_value, dose_unit, frequency, route,
                           event_kind, reason,
                           valid_at, valid_until, asserted_at, asserted_until
                      FROM med_record
                     WHERE tenant_id = $1
                       AND drug_name = $2
                       AND asserted_at <= $3
                       AND (asserted_until IS NULL OR asserted_until > $3)
                       AND (valid_until    IS NULL OR valid_until    > $4)
                       AND valid_at <= $4
                       AND ($5::timestamptz IS NULL OR valid_at >= $5)
                       AND ($6::timestamptz IS NULL OR valid_at <  $6)
                  ORDER BY valid_at ASC
                     LIMIT $7
                    """,
                    tenant_id,
                    drug_name,
                    as_of,
                    valid_at,
                    since,
                    until,
                    limit,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"med_record.history failed: {exc}") from exc
        return [_row_to_dc(r) for r in rows]

    async def by_event_kind(
        self,
        *,
        tenant_id: str,
        event_kind: str,
        as_of: datetime,
        valid_at: datetime,
        limit: int,
    ) -> list[MedRecordRow]:
        """Visible rows of a single event_kind (e.g. `allergy`, `switch`)."""
        if event_kind not in _VALID_EVENT_KINDS:
            raise VectorStoreError(f"med_record.by_event_kind: invalid {event_kind!r}")
        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT tenant_id, episode_uuid, drug_name, rxnorm_code,
                           drug_class, dose_value, dose_unit, frequency, route,
                           event_kind, reason,
                           valid_at, valid_until, asserted_at, asserted_until
                      FROM med_record
                     WHERE tenant_id = $1
                       AND event_kind = $2
                       AND asserted_at <= $3
                       AND (asserted_until IS NULL OR asserted_until > $3)
                       AND (valid_until    IS NULL OR valid_until    > $4)
                       AND valid_at <= $4
                  ORDER BY valid_at ASC
                     LIMIT $5
                    """,
                    tenant_id,
                    event_kind,
                    as_of,
                    valid_at,
                    limit,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"med_record.by_event_kind failed: {exc}") from exc
        return [_row_to_dc(r) for r in rows]

    async def supersede_matching(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        episode_uuid: UUID,
        keys: list[tuple[str, str, datetime]],
        asserted_until: datetime,
    ) -> int:
        """Close prior med_record rows on `episode_uuid` whose
        ``(drug_name, event_kind, valid_at)`` appears in ``keys``. Updates
        only rows currently open on the tx-time half-pair and currently
        visible on the world-time half-pair. Returns count updated;
        caller logs WARNING on partial-match miss.

        ``episode_uuid`` is the chain-walk-resolved head per
        :py:meth:`gnokee.storage.metadata.MetadataStore.supersede`,
        NOT necessarily the caller's ``corrects`` value.
        """
        if not keys:
            return 0
        drug_names = [k[0] for k in keys]
        event_kinds = [k[1] for k in keys]
        valid_ats = [k[2] for k in keys]
        try:
            result = await conn.execute(
                """
                UPDATE med_record
                   SET asserted_until = $6
                  FROM unnest($3::text[], $4::text[], $5::timestamptz[])
                       AS k(drug_name, event_kind, valid_at)
                 WHERE med_record.tenant_id      = $1
                   AND med_record.episode_uuid   = $2
                   AND med_record.asserted_until IS NULL
                   AND (med_record.valid_until IS NULL
                        OR med_record.valid_until > $6)
                   AND med_record.drug_name      = k.drug_name
                   AND med_record.event_kind     = k.event_kind
                   AND med_record.valid_at       = k.valid_at
                """,
                tenant_id,
                episode_uuid,
                drug_names,
                event_kinds,
                valid_ats,
                asserted_until,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"med_record.supersede_matching failed: {exc}") from exc
        return int(result.split()[-1])


def _row_to_dc(row: asyncpg.Record) -> MedRecordRow:
    return MedRecordRow(
        tenant_id=row["tenant_id"],
        episode_uuid=row["episode_uuid"],
        drug_name=row["drug_name"],
        rxnorm_code=row["rxnorm_code"],
        drug_class=row["drug_class"],
        dose_value=row["dose_value"],
        dose_unit=row["dose_unit"],
        frequency=row["frequency"],
        route=row["route"],
        event_kind=row["event_kind"],
        reason=row["reason"],
        valid_at=row["valid_at"],
        valid_until=row["valid_until"],
        asserted_at=row["asserted_at"],
        asserted_until=row["asserted_until"],
    )


__all__ = ["MedRecordRow", "MedStore"]
