"""src/gnokee/storage/key_resolver.py — Optional KeyResolver for encrypted_body recall.

gnokee NEVER stores or holds DEKs. The encrypted_body branch persists a
ciphertext + nonce + `key_id` triple verbatim (see
`storage/encrypted_body.py`); the consumer is responsible for unwrapping.

This module defines a tiny `KeyResolver` Protocol the recall path may
consult when a caller wants gnokee to call out to a configured KMS on
its behalf instead of decoding the row manually. Two adapters ship:

  * `NullKeyResolver` — explicit "no KMS configured". `unwrap` always
    returns `None` so the recall path returns the opaque triple to the
    caller, matching v0.6 behaviour.
  * `OmkitKeyResolver` — delegates to `omkit.kms.KMS` (LocalDev or
    OpenBao Transit). Wire it via `Settings.kms_backend = localdev |
    openbao` and the `GNOKEE_KMS_*` env vars.

gnokee does NOT enable KMS unwrap by default. Callers opt in by passing
a non-null resolver to `RecallPipeline.recall(... key_resolver=...)` or
by configuring `Settings.kms_backend`. The encrypted-body adapter API
(`EncryptedBodyStore`) stays unchanged — KMS is purely a recall-side
convenience.

exports: KeyResolver | NullKeyResolver | OmkitKeyResolver | build_key_resolver
used_by: src/gnokee/storage/encrypted_body.py | src/gnokee/retrieval.py | src/gnokee/bootstrap.py
rules:   gnokee never decrypts in this module — it forwards bytes through whatever resolver the caller supplies. Default is Null (no behaviour change). KMS auth errors propagate; transient KMS errors surface as ResolveFailure.
agent:   claude-opus-4-7 | 2026-05-17 | omkit KMS integration (issue #22 follow-on)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Protocol, cast, runtime_checkable

if TYPE_CHECKING:
    from gnokee.config import Settings

log = logging.getLogger(__name__)


class ResolveFailure(Exception):
    """KMS transient failure during unwrap. Caller may retry or surface ciphertext."""


@runtime_checkable
class KeyResolver(Protocol):
    """Unwrap a ciphertext using a configured KMS.

    Implementations MUST raise `ResolveFailure` on transient backend
    errors (5xx, network) and propagate auth errors unmodified so the
    caller can distinguish "tenant misconfigured" from "KMS down".
    Return None to indicate "this resolver does not handle this key_id"
    — the recall path then surfaces the opaque ciphertext as before.
    """

    async def unwrap(
        self,
        *,
        tenant_id: str,
        episode_uuid: str,
        ciphertext: bytes,
        nonce: bytes,
        key_id: str,
    ) -> bytes | None: ...


class NullKeyResolver:
    """No-op resolver. Always returns None; gnokee surfaces the opaque triple."""

    async def unwrap(
        self,
        *,
        tenant_id: str,
        episode_uuid: str,
        ciphertext: bytes,
        nonce: bytes,
        key_id: str,
    ) -> bytes | None:
        return None


class OmkitKeyResolver:
    """Adapter that calls `omkit.kms.KMS.unwrap`.

    `key_id` is treated as the wrap purpose; AAD is built from
    `tenant_id|episode_uuid|key_id` so cross-tenant or cross-episode
    unwrap attempts fail at the GCM auth tag. The ciphertext + nonce
    bytes are concatenated to match the omkit-go envelope shape
    (`nonce || ciphertext`) — omkit's KMS.unwrap expects one blob.

    Construct via `build_key_resolver(settings)` rather than directly so
    the optional-dep guard runs in one place.
    """

    def __init__(self, kms: object) -> None:
        self._kms = kms

    async def unwrap(
        self,
        *,
        tenant_id: str,
        episode_uuid: str,
        ciphertext: bytes,
        nonce: bytes,
        key_id: str,
    ) -> bytes | None:
        from omkit.kms.base import KMSError, KMSUnavailableError

        blob = nonce + ciphertext
        aad = f"{tenant_id}|{episode_uuid}|{key_id}".encode()
        try:
            plain = await self._kms.unwrap(key_id, blob, aad)  # type: ignore[attr-defined]
        except KMSUnavailableError as exc:
            raise ResolveFailure(str(exc)) from exc
        except KMSError:
            raise
        return cast("bytes | None", plain)


def build_key_resolver(settings: Settings) -> KeyResolver:
    """Construct a KeyResolver from Settings. Returns NullKeyResolver when disabled.

    Raises RuntimeError when `kms_backend` is set but `omkit` is not installed
    — that combination is a config bug, not a runtime fallback case.
    """
    backend = settings.kms_backend.lower()
    if backend == "disabled":
        return NullKeyResolver()
    try:
        from omkit.kms import LocalDevKMS, OpenBaoKMS
    except ImportError as exc:
        raise RuntimeError(
            f"gnokee.config: kms_backend={backend!r} requires `pip install gnokee[omkit]` (omkit not importable: {exc})"
        ) from exc

    if backend == "localdev":
        if not settings.kms_master_secret:
            raise RuntimeError("gnokee.config: kms_backend=localdev requires GNOKEE_KMS_MASTER_SECRET (hex-encoded)")
        try:
            secret = bytes.fromhex(settings.kms_master_secret)
        except ValueError as exc:
            raise RuntimeError(f"gnokee.config: GNOKEE_KMS_MASTER_SECRET must be hex-encoded ({exc})") from exc
        return OmkitKeyResolver(LocalDevKMS(master=secret))

    if backend == "openbao":
        if not settings.openbao_addr or not settings.openbao_role_id or not settings.openbao_secret_id:
            raise RuntimeError("gnokee.config: kms_backend=openbao requires GNOKEE_OPENBAO_{ADDR,ROLE_ID,SECRET_ID}")
        return OmkitKeyResolver(
            OpenBaoKMS(
                addr=settings.openbao_addr,
                role_id=settings.openbao_role_id,
                secret_id=settings.openbao_secret_id,
                key_name=settings.openbao_mount or "transit",
            )
        )

    raise RuntimeError(f"gnokee.config: unknown kms_backend={backend!r}; expected disabled | localdev | openbao")


__all__ = [
    "KeyResolver",
    "NullKeyResolver",
    "OmkitKeyResolver",
    "ResolveFailure",
    "build_key_resolver",
]
