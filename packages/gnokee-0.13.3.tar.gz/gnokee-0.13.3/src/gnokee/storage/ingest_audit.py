"""src/gnokee/storage/ingest_audit.py — gnokee_maintenance.ingest_audit CRUD.

Pure async helpers over the audit table introduced by migration 0023.
The pipeline (src/gnokee/ingest.py) is the only caller for INSERT /
UPDATE; operators read the table directly via SQL. Mirrors the shape
of `gnokee.storage.forget_audit` (ADR-0026) — the compliance
counterpart on the destructive side.

Distinct from `gnokee.storage.journal` (ADR-0024 / ingest_journal):
the journal is crash-recovery (prunable once resume_ingest no longer
needs the row); audit is per-call compliance (retained beyond tenant
lifetime). Schema-isolated under `gnokee_maintenance` so tenant
cascade does not reach it.

exports: IngestAuditRow | insert_begin | mark_commit | mark_fail | fetch
used_by: src/gnokee/ingest.py
rules:   tenant_id on every write; no RLS (schema-isolated); tz-aware UTC
agent:   claude-opus-4-7 | 2026-05-17 | issue #198 ADR-0028 impl
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, cast
from uuid import UUID

import asyncpg

State = Literal["begin", "commit", "fail"]


@dataclass(frozen=True, slots=True)
class IngestAuditRow:
    audit_id: UUID
    tenant_id: str
    episode_uuid: UUID | None
    our_id: str | None
    state: State
    actor: str | None
    source_url: str | None
    decision: str | None
    supersession_uuid: UUID | None
    receipt: dict[str, Any] | None
    error: dict[str, Any] | None
    started_at: datetime
    finished_at: datetime | None


async def insert_begin(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    our_id: str | None,
    actor: str | None,
    source_url: str | None,
) -> UUID:
    """INSERT a state='begin' row. Returns the generated `audit_id`.

    Standalone helper — acquires a fresh connection from `pool` and
    runs the INSERT in its own implicit transaction. The audit row is
    durable when this awaits returns.

    Called from `gnokee.ingest.IngestPipeline.ingest` immediately after
    Stage 1 boundary validation succeeds — the moment `tenant_id` is
    known and the content-xor-encrypted invariant holds. Pre-Stage-1
    failures (raised by `EpisodeIn` validators before pipeline entry)
    MUST NOT call this helper; the absence of a row distinguishes "the
    call never reached gnokee" from "gnokee tried and failed".
    """
    sql = """
        INSERT INTO gnokee_maintenance.ingest_audit
            (tenant_id, our_id, state, actor, source_url)
        VALUES
            ($1, $2, 'begin', $3, $4)
        RETURNING audit_id;
    """
    async with pool.acquire() as conn:
        row = await conn.fetchrow(sql, tenant_id, our_id, actor, source_url)
    assert row is not None
    return cast(UUID, row["audit_id"])


async def mark_commit(
    pool: asyncpg.Pool,
    *,
    audit_id: UUID,
    episode_uuid: UUID,
    decision: str,
    supersession_uuid: UUID | None,
    receipt: dict[str, Any],
) -> None:
    """UPDATE the row to state='commit' with the receipt + decision.

    `decision` is `"new"` for fresh ingests or `"replayed"` for
    idempotent re-ingests (matched on `(tenant_id, our_id)` partial
    unique index). `supersession_uuid` carries `EpisodeIn.corrects`
    when set, NULL otherwise.
    """
    sql = """
        UPDATE gnokee_maintenance.ingest_audit
           SET state = 'commit',
               episode_uuid = $2,
               decision = $3,
               supersession_uuid = $4,
               receipt = $5,
               finished_at = now()
         WHERE audit_id = $1;
    """
    async with pool.acquire() as conn:
        await conn.execute(
            sql,
            audit_id,
            episode_uuid,
            decision,
            supersession_uuid,
            json.dumps(receipt),
        )


async def mark_fail(
    pool: asyncpg.Pool,
    *,
    audit_id: UUID,
    error: dict[str, Any],
) -> None:
    """UPDATE the row to state='fail' with a structured error payload.

    Conventionally `{"type": type(exc).__name__, "message": str(exc)}`,
    but callers may supply richer dicts as needed. Best-effort write —
    a failure here would mask the original ingest exception; the
    pipeline should swallow audit-write errors in the exception path
    (the original error propagates regardless).
    """
    sql = """
        UPDATE gnokee_maintenance.ingest_audit
           SET state = 'fail',
               error = $2,
               finished_at = now()
         WHERE audit_id = $1;
    """
    async with pool.acquire() as conn:
        await conn.execute(sql, audit_id, json.dumps(error))


async def fetch(pool: asyncpg.Pool, *, audit_id: UUID) -> IngestAuditRow:
    """Return the audit row for `audit_id`. Raises LookupError if absent.

    Test / operator helper. The application connection does not need
    to read these rows during normal operation — they are forensic
    artefacts surfaced to operators via direct SQL.
    """
    sql = """
        SELECT audit_id, tenant_id, episode_uuid, our_id, state, actor,
               source_url, decision, supersession_uuid, receipt, error,
               started_at, finished_at
          FROM gnokee_maintenance.ingest_audit
         WHERE audit_id = $1;
    """
    async with pool.acquire() as conn:
        row = await conn.fetchrow(sql, audit_id)
    if row is None:
        raise LookupError(f"ingest_audit row not found: audit_id={audit_id}")
    return _row(row)


def _row(r: asyncpg.Record) -> IngestAuditRow:
    return IngestAuditRow(
        audit_id=r["audit_id"],
        tenant_id=r["tenant_id"],
        episode_uuid=r["episode_uuid"],
        our_id=r["our_id"],
        state=r["state"],
        actor=r["actor"],
        source_url=r["source_url"],
        decision=r["decision"],
        supersession_uuid=r["supersession_uuid"],
        receipt=json.loads(r["receipt"]) if r["receipt"] else None,
        error=json.loads(r["error"]) if r["error"] else None,
        started_at=r["started_at"],
        finished_at=r["finished_at"],
    )
