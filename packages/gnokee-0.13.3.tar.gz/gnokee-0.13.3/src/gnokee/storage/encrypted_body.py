"""src/gnokee/storage/encrypted_body.py — episode_body_encrypted adapter.

Sibling table to ``episode_metadata``. Stores consumer-supplied
ciphertext + nonce + key_id when the ingest caller chose the
``encrypted_body`` branch (issue #22).

gnokee NEVER decrypts. The ``key_id`` references a DEK in the consumer's
KMS (OpenBao for Omur, libsodium-via-pynacl in tests). On recall this
adapter returns the opaque triple verbatim — the consumer's session-side
code does the unwrap.

exports: class EncryptedBodyStore | EncryptedBodyRow
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py
rules:   tenant_id on every read+write; bytes round-trip exact (no codec)
agent:   claude-opus-4-7 | 2026-05-10 | issue #22 encrypted_body wire-up
"""

from __future__ import annotations

from dataclasses import dataclass
from uuid import UUID

import asyncpg

from gnokee.errors import VectorStoreError


@dataclass(frozen=True)
class EncryptedBodyRow:
    """Opaque ciphertext + envelope. ``key_id`` references consumer KMS."""

    tenant_id: str
    episode_uuid: UUID
    ciphertext: bytes
    nonce: bytes
    key_id: str


class EncryptedBodyStore:
    """Async wrapper around ``episode_body_encrypted``."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def write(
        self,
        *,
        conn: asyncpg.Connection,
        row: EncryptedBodyRow,
    ) -> None:
        """INSERT a ciphertext row. Caller controls the transaction.

        ``ON CONFLICT DO UPDATE`` so re-ingest on the same
        ``(tenant_id, episode_uuid)`` is idempotent — same shape as
        ``content_embedding`` to keep the cross-store atomicity story
        symmetric.
        """
        try:
            await conn.execute(
                """
                INSERT INTO episode_body_encrypted (
                    tenant_id, episode_uuid, ciphertext, nonce, key_id
                ) VALUES ($1, $2, $3, $4, $5)
                ON CONFLICT (tenant_id, episode_uuid) DO UPDATE
                  SET ciphertext = EXCLUDED.ciphertext,
                      nonce      = EXCLUDED.nonce,
                      key_id     = EXCLUDED.key_id
                """,
                row.tenant_id,
                row.episode_uuid,
                row.ciphertext,
                row.nonce,
                row.key_id,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"encrypted_body.write failed: {exc}") from exc

    async def get(
        self,
        *,
        tenant_id: str,
        episode_uuid: UUID,
    ) -> EncryptedBodyRow | None:
        """Single-row fetch for ``fact_provenance`` recall path."""
        try:
            async with self._pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT tenant_id, episode_uuid, ciphertext, nonce, key_id
                      FROM episode_body_encrypted
                     WHERE tenant_id = $1 AND episode_uuid = $2
                    """,
                    tenant_id,
                    episode_uuid,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"encrypted_body.get failed: {exc}") from exc
        if row is None:
            return None
        return _row_to_dc(row)

    async def fetch_many(
        self,
        *,
        tenant_id: str,
        episode_uuids: list[UUID],
    ) -> dict[UUID, EncryptedBodyRow]:
        """Batch fetch for ``recall`` body / excerpt skip-detection.

        Returns a dict so callers can do O(1) "is this episode encrypted?"
        lookups without rewalking the result set. Empty input → empty dict.
        """
        if not episode_uuids:
            return {}
        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT tenant_id, episode_uuid, ciphertext, nonce, key_id
                      FROM episode_body_encrypted
                     WHERE tenant_id = $1
                       AND episode_uuid = ANY($2::uuid[])
                    """,
                    tenant_id,
                    episode_uuids,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"encrypted_body.fetch_many failed: {exc}") from exc
        return {r["episode_uuid"]: _row_to_dc(r) for r in rows}


def _row_to_dc(row: asyncpg.Record) -> EncryptedBodyRow:
    return EncryptedBodyRow(
        tenant_id=row["tenant_id"],
        episode_uuid=row["episode_uuid"],
        ciphertext=bytes(row["ciphertext"]),
        nonce=bytes(row["nonce"]),
        key_id=row["key_id"],
    )


__all__ = ["EncryptedBodyRow", "EncryptedBodyStore"]
