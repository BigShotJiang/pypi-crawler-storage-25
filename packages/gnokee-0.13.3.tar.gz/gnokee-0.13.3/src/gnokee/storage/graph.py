"""src/gnokee/storage/graph.py — Graphiti / Neo4j adapter.

Wraps `graphiti-core` 0.29 + raw Cypher for stages 2a, 4, contradiction
cosine, and provenance fetch. `group_id = tenant_id` on every call.

exports: class GraphitiStore | EpisodeCandidate | FactRow | ProvenanceRow | EdgeTriple | EdgeInWindow | bootstrap_indices
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py | src/gnokee/contradiction.py
rules:   tenant_id → group_id; raw Cypher only for what graphiti-core does not cover; v0.1 ADR-0004 exception is fact-embedding cosine (vector lives on Graphiti edge)
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
         claude-sonnet-4-6 | 2026-05-16 | ADR-0026 remove_tenant_group + remove_episodes_by_uuid
         claude-opus-4-7   | 2026-05-18 | issue #290 fact_cosine projection on fetch_facts_for_episodes
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from uuid import UUID

import openai
from graphiti_core import Graphiti
from graphiti_core.cross_encoder.client import CrossEncoderClient
from graphiti_core.embedder.client import EmbedderClient
from graphiti_core.graphiti import AddEpisodeResults
from graphiti_core.llm_client.client import LLMClient
from graphiti_core.nodes import EpisodeType

from gnokee.errors import GraphStoreError

log = logging.getLogger("gnokee.forget")


@dataclass(frozen=True)
class EpisodeCandidate:
    """Stage 2a output: episodes whose `valid_at <= world_time`."""

    episode_uuid: UUID


@dataclass(frozen=True)
class FactRow:
    """Stage 4 output: a fact (EntityEdge) tied to a candidate episode.

    ``fact_cosine`` (issue #290 follow-up to #95) — Neo4j-side cosine
    similarity of the edge's ``fact_embedding`` vs the query embedding.
    ``None`` when ``query_vector`` was not passed (legacy callers) or the
    edge had no ``fact_embedding`` (older data). In [0, 1].
    """

    fact_uuid: UUID
    text: str
    valid_at: datetime
    episode_uuid: UUID
    fact_cosine: float | None = None


@dataclass(frozen=True)
class ProvenanceRow:
    """Output of `fetch_provenance`: full episode body + EntityEdge attrs."""

    fact_uuid: UUID
    fact_text: str
    fact_valid_at: datetime
    episode_uuid: UUID
    episode_content: str


@dataclass(frozen=True)
class CosineCandidate:
    """Output of `cosine_search_facts` (Q4 contradiction stage)."""

    fact_uuid: UUID
    fact_text: str
    valid_at: datetime
    score: float


@dataclass(frozen=True)
class EntitySummary:
    """Output of `list_entities_for_tenant` (ADR-0015 wiki export)."""

    entity_uuid: UUID
    name: str


@dataclass(frozen=True)
class EntityFactRow:
    """Output of `fetch_facts_for_entity` — one Graphiti edge per row.

    Used by the wiki export's `entities/<slug>.md` page builder. Each row
    carries the source-episode handle so the page can emit ADR-0016-style
    citation lines (`episode_uuid`, `valid_at`, `asserted_at`) alongside
    the verbatim fact text.

    `invalid_at` is the edge's world-time close (axis-1 per ADR-0004 —
    NOT source-tx-time; the axis-2 close lives on `episode_metadata.
    asserted_until`, not on the Graphiti edge). `None` means the edge
    is still open at as-of-now. The wiki page partitions rows on this
    field into "Current" (active) vs "History" (superseded);
    `scope=self` filters History out at the caller.
    """

    fact_uuid: UUID
    fact_text: str
    valid_at: datetime
    invalid_at: datetime | None
    episode_uuid: UUID
    other_entity_uuid: UUID
    other_entity_name: str


@dataclass(frozen=True, slots=True)
class EdgeTriple:
    """Subject-predicate-object triple for one EntityEdge.

    Used by Stage 6c (ingest.py) for fact_id inheritance via triple-match
    when `EpisodeIn.corrects:` is set. Identifies an edge by its
    semantically-stable shape rather than its uuid.
    """

    fact_uuid: UUID
    source_node_uuid: UUID
    predicate: str
    target_node_uuid: UUID
    fact_text: str
    valid_at: datetime | None


@dataclass(frozen=True, slots=True)
class EdgeInWindow:
    """Output of `list_edges_in_window` (issue #169 Stage 6c crash backfill).

    All attributes a `fact_revision` row needs are carried here so the
    backfill caller never has to reach back into Neo4j for follow-ups.
    `episode_uuid` is the `Episodic` that MENTIONS the edge source
    (first hit wins via Python-side de-dup); backfilled
    `fact_revision` rows need *an* anchor episode for audit /
    forget-cascade purposes — "which episode actually extracted this
    edge" is not recoverable from Neo4j after a Stage 6c crash.

    `edge_created_at` is the edge's `r.created_at` — Graphiti's
    ingest-system time on the edge (axis-3 per ADR-0004). Populated
    directly from Neo4j by `list_edges_in_window`.

    `asserted_at` is the axis-2 source-tx time of the originating
    episode (ADR-0004) and is always `None` as returned from this
    layer. The backfill caller (`maintenance.backfill_fact_revisions`)
    joins `episode_metadata.asserted_at` from Postgres and produces a
    new `EdgeInWindow` with the field populated via
    `dataclasses.replace`. Keeps `list_edges_in_window` PG-free —
    caller owns axis-2 enrichment.

    Issue #210: prior to the axis-2 fix, this dataclass carried a
    single `asserted_at` field populated from `r.created_at`
    (axis-3). That polluted `fact_revision.asserted_at` with axis-3
    timestamps for the Stage 6c crash-recovery class — silent
    bi-temporal corruption per ADR-0004. The fields are now
    axis-separated.
    """

    fact_uuid: UUID
    source_node_uuid: UUID
    predicate: str
    target_node_uuid: UUID
    fact_text: str
    valid_at: datetime
    edge_created_at: datetime
    episode_uuid: UUID
    asserted_at: datetime | None = None


class GraphitiStore:
    """Thin async wrapper over `Graphiti`.

    Construct with an already-initialised `Graphiti` instance — the v0.1 path
    builds it from `Settings` in `gnokee.config`.
    """

    def __init__(self, graphiti: Graphiti) -> None:
        self._g = graphiti

    @property
    def graphiti(self) -> Graphiti:
        return self._g

    async def add_episode(
        self,
        *,
        tenant_id: str,
        name: str,
        content: str,
        reference_time: datetime,
        uuid: UUID | None = None,
        source_description: str = "gnokee.ingest",
        entity_type_hints: list[str] | None = None,
        custom_extraction_instructions: str | None = None,
    ) -> AddEpisodeResults:
        """Wrap `graphiti.add_episode`. Always passes `group_id=tenant_id`.

        `reference_time` MUST be `valid_at` per ADR-0004 — never `now()`.
        `uuid` (v0.6 Z1) attaches this extraction to an Episodic node gnokee
        already wrote via `write_lite_episode`. graphiti uses MERGE+SET on the
        node (full property replacement, see ADR-0023 § axis-3 semantic);
        callers must accept that Episodic.created_at is overwritten with
        utc_now() each time this method runs against an existing node.
        Per AGENTS.md `entity_type_hints` is advisory; not threaded into
        Graphiti's extractor in v0.1. `custom_extraction_instructions`
        (issue #235) is graphiti-core's public hook for injecting
        per-tenant directives into the extraction prompt (e.g. preserve
        source-language entity names). None = upstream default behaviour.
        """
        try:
            return await self._g.add_episode(
                name=name,
                episode_body=content,
                source_description=source_description,
                reference_time=reference_time,
                source=EpisodeType.text,
                group_id=tenant_id,
                uuid=str(uuid) if uuid is not None else None,
                custom_extraction_instructions=custom_extraction_instructions,
            )
        except (openai.RateLimitError, openai.APITimeoutError, openai.APIConnectionError):
            # v0.6 Z4 (#111): let retryable openai exceptions bubble through
            # so `_retry_enhancement` can recognize the type, honour
            # `retry-after`, and back off. Wrapping these as GraphStoreError
            # was silently disabling Z4's retry chain — Q18 gate (2026-05-16)
            # observed 15/600 episodes hit lite-fallback on first-try
            # RateLimitError where Z4 would have recovered most of them.
            raise
        except Exception as exc:  # graphiti raises a heterogenous mix
            raise GraphStoreError(f"add_episode failed: {exc}") from exc

    async def remove_episode(self, episode_uuid: UUID) -> None:
        try:
            await self._g.remove_episode(str(episode_uuid))
        except Exception as exc:
            raise GraphStoreError(f"remove_episode failed: {exc}") from exc

    async def remove_lite_episode(
        self,
        *,
        tenant_id: str,
        episode_uuid: UUID,
    ) -> None:
        """Remove a lite-written ``Episodic`` by (group_id, uuid) directly.

        v0.6 Z1-B compensation (#111). graphiti-core's ``remove_episode``
        may rely on graphiti-internal indexing that doesn't see
        MERGE-only-written nodes; this helper goes through the same raw
        Cypher path used by ``write_lite_episode`` so compensation always
        targets the exact node we wrote. Tenant predicate prevents
        cross-tenant deletion.
        """
        cypher = """
        MATCH (n:Episodic {uuid: $uuid, group_id: $group_id})
        DETACH DELETE n
        """
        try:
            await self._g.driver.execute_query(
                cypher,
                uuid=str(episode_uuid),
                group_id=tenant_id,
            )
        except Exception as exc:
            raise GraphStoreError(f"remove_lite_episode failed: {exc}") from exc

    async def remove_tenant_group(
        self,
        *,
        tenant_id: str,
        chunk_threshold: int | None = None,
        chunk_size: int | None = None,
    ) -> dict[str, int]:
        """Hard-delete every node + edge keyed by ``group_id = tenant_id``.

        Two paths (issue #138):

        * **Monolithic (default).** When ``chunk_threshold`` is ``None`` or
          the tenant's total node count is at or below the threshold, runs
          two ``DETACH DELETE`` statements (Episodic + Entity) — identical
          to pre-#138 behaviour. Zero regression for typical deployments.

        * **Chunked.** When ``chunk_threshold`` is non-None and the total
          node count exceeds it, loops ``MATCH (n {group_id}) WITH n LIMIT
          $chunk_size DETACH DELETE n`` until no nodes remain. Each chunk
          runs in its own implicit transaction (no session-level open tx
          wrapping the loop), so a mid-sweep failure leaves the prefix
          deleted; ``resume_forget`` re-issues the same call which picks up
          where the failure left off because the per-tenant pre-count
          shrinks each iteration.

        The chunked path returns the same ``{Episodic, Entity, edges_total}``
        contract for ``ForgetReceiptDetail`` bookkeeping, plus extra keys
        ``chunks_executed`` + ``chunk_size`` + ``pre_count`` that the forget
        pipeline routes into ``ForgetReceiptDetail.neo4j_chunked``.

        ADR-0023: ``group_id`` is the tenant retention key in Neo4j; no
        cross-tenant link can exist by construction. ADR-0026.
        """
        try:
            async with self._g.driver.session() as session:
                if chunk_threshold is not None:
                    # Issue #183 — Neo4j 5.x deprecates `count(n)` aggregate
                    # outside a WITH/RETURN of grouped properties; the
                    # `COUNT { (n) }` subquery form is the forward-compatible
                    # spelling and avoids the 5.x deprecation warning.
                    count_result = await session.run(
                        "MATCH (n {group_id: $group_id}) RETURN COUNT { (n) } AS total",
                        group_id=tenant_id,
                    )
                    count_record = await count_result.single()
                    pre_count = int(count_record["total"]) if count_record else 0
                else:
                    pre_count = -1  # sentinel: chunked path disabled

                use_chunked = (
                    chunk_threshold is not None
                    and chunk_size is not None
                    and chunk_size > 0
                    and pre_count > chunk_threshold
                )

                if not use_chunked:
                    ep_result = await session.run(
                        "MATCH (ep:Episodic {group_id: $group_id}) DETACH DELETE ep",
                        group_id=tenant_id,
                    )
                    ep_summary = await ep_result.consume()
                    ent_result = await session.run(
                        "MATCH (e:Entity {group_id: $group_id}) DETACH DELETE e",
                        group_id=tenant_id,
                    )
                    ent_summary = await ent_result.consume()
                    return {
                        "Episodic": int(ep_summary.counters.nodes_deleted),
                        "Entity": int(ent_summary.counters.nodes_deleted),
                        "edges_total": int(
                            ep_summary.counters.relationships_deleted + ent_summary.counters.relationships_deleted
                        ),
                    }

                # Chunked path (issue #156). Two single-label loops so:
                #   1. The MATCH is bounded to gnokee-owned labels —
                #      previously an unlabelled `MATCH (n {group_id})` would
                #      have swept any future label gnokee or a consumer
                #      Cypher attached `group_id` to (custom Graphiti
                #      extension, ops node, migration scratch). The
                #      monolithic path already uses explicit labels; the
                #      chunked path now matches that semantic.
                #   2. Per-label counters are accurate. The prior code lied
                #      `Entity = 0` and credited every deleted node to
                #      Episodic — compliance audit reconstruction broke
                #      whenever a tenant had Entity nodes.
                # The Neo4j 5 planner uses the graphiti-managed per-label
                # `episode_group_id` / `entity_group_id` indexes (#152) for
                # each `MATCH (n:Label {group_id: $g})`, so the labelled
                # split has no plan-cost regression.
                assert chunk_size is not None and chunk_size > 0  # narrow for mypy
                nodes_by_label: dict[str, int] = {"Episodic": 0, "Entity": 0}
                edges_deleted_total = 0
                chunks_executed = 0
                # Issue #158 — progress logging. Total is an upper bound based
                # on pre_count; the loop may finish earlier when the per-label
                # subset is smaller. Operators get a stable "N/M" shape in
                # logs to track wall-clock vs. expected without parsing JSON.
                total_chunks_estimate = max(1, -(-pre_count // chunk_size))
                for label in ("Episodic", "Entity"):
                    while True:
                        chunk_result = await session.run(
                            f"MATCH (n:{label} {{group_id: $group_id}}) WITH n LIMIT $chunk_size DETACH DELETE n",
                            group_id=tenant_id,
                            chunk_size=chunk_size,
                        )
                        chunk_summary = await chunk_result.consume()
                        chunks_executed += 1
                        chunk_nodes = int(chunk_summary.counters.nodes_deleted)
                        nodes_by_label[label] += chunk_nodes
                        edges_deleted_total += int(chunk_summary.counters.relationships_deleted)
                        log.info(
                            "forget_tenant chunk %d/%d tenant=%s label=%s deleted_nodes=%d",
                            chunks_executed,
                            total_chunks_estimate,
                            tenant_id,
                            label,
                            chunk_nodes,
                        )
                        if chunk_nodes == 0:
                            break

                return {
                    "Episodic": nodes_by_label["Episodic"],
                    "Entity": nodes_by_label["Entity"],
                    "edges_total": edges_deleted_total,
                    "chunks_executed": chunks_executed,
                    "chunk_size": int(chunk_size),
                    "pre_count": pre_count,
                }
        except Exception as exc:
            raise GraphStoreError(f"remove_tenant_group failed: {exc}") from exc

    async def remove_episodes_by_uuid(
        self,
        *,
        tenant_id: str,
        episode_uuids: list[UUID],
    ) -> dict[str, int]:
        """Hard-delete a set of ``Episodic`` nodes by UUID + ``group_id``.

        Then removes orphan ``Entity`` nodes (no remaining ``:MENTIONS``).
        Returns combined counts for ``ForgetReceiptDetail`` bookkeeping.
        If ``episode_uuids`` is empty, returns zero counts without touching
        the driver. ADR-0026.
        """
        if not episode_uuids:
            return {"Episodic": 0, "Entity": 0, "edges_total": 0}
        try:
            async with self._g.driver.session() as session:
                ep_result = await session.run(
                    "UNWIND $uuids AS uuid MATCH (ep:Episodic {uuid: uuid, group_id: $group_id}) DETACH DELETE ep",
                    uuids=[str(u) for u in episode_uuids],
                    group_id=tenant_id,
                )
                ep_summary = await ep_result.consume()
                # Orphan-entity cleanup: entities with zero remaining MENTIONS.
                orphan_result = await session.run(
                    "MATCH (e:Entity {group_id: $group_id}) "
                    "WHERE NOT EXISTS { MATCH (e)<-[:MENTIONS]-(:Episodic) } "
                    "DETACH DELETE e",
                    group_id=tenant_id,
                )
                orphan_summary = await orphan_result.consume()
        except Exception as exc:
            raise GraphStoreError(f"remove_episodes_by_uuid failed: {exc}") from exc
        return {
            "Episodic": int(ep_summary.counters.nodes_deleted),
            "Entity": int(orphan_summary.counters.nodes_deleted),
            "edges_total": int(
                ep_summary.counters.relationships_deleted + orphan_summary.counters.relationships_deleted
            ),
        }

    async def write_lite_episode(
        self,
        *,
        tenant_id: str,
        episode_uuid: UUID,
        valid_at: datetime,
        name: str,
        content: str,
        created_at: datetime,
        source_description: str = "gnokee.ingest.lite",
    ) -> None:
        """Write a minimal ``Episodic`` node for issue #56 (lite-mode ingest).

        Lite mode (``extract=False``) skips Graphiti's LLM extractor, which
        previously meant NO ``Episodic`` node ever landed in Neo4j. Recall
        Stage 2a (``list_candidate_episodes``) is a Cypher query against
        Episodic nodes — without one, every recall short-circuited to an
        empty ``RecallResponse`` even though Postgres carried the row.

        This helper writes the node directly via raw Cypher so we don't
        invoke Graphiti's extractor / entity-resolution path. Only the
        Episodic node is written:

        - NO :MENTIONS edges (those gate behind extraction).
        - NO :Entity nodes.
        - NO :RELATES_TO edges / fact_embedding.

        Properties mirror the shape ``EpisodicNode.save`` writes
        (uuid, name, group_id, source, source_description, content,
        entity_edges=[], created_at, valid_at) so downstream graphiti-core
        reads stay schema-compatible. ``source`` is hardcoded to
        ``"text"`` (mirrors ``EpisodeType.text.value``) since lite-mode
        ingest only handles plaintext bodies.

        Tenant predicate: ``group_id`` is part of the MERGE key alongside
        ``uuid``. This matches ``remove_lite_episode`` MATCH semantics
        and makes the tenant scope explicit at the Cypher level rather
        than relying on uuid4 global uniqueness.

        Idempotency contract (ADR-0024 / #122 resume path): split into
        ``ON CREATE SET`` (initial property layout including
        ``created_at``) + ``ON MATCH SET`` (re-syncable properties
        only — name, source_description, content, valid_at). ``created_at``
        and ``entity_edges`` are NOT re-written on match — axis-3 ingest
        time is locked at creation (ADR-0004), and any entity edges
        Stage 6 wired in are preserved across a resume's re-MERGE.

        Issue #239: the encrypted-body branch (``ingest.py``) passes
        ``content=""`` because no plaintext is available. On a resume MERGE
        where the original write landed plaintext content and the resume
        re-enters via the encrypted branch (or a later same-episode write
        re-uses this helper without plaintext), an unconditional
        ``n.content = $content`` would zero the previously-stored
        plaintext. Guard with ``CASE`` so the empty string is treated as
        "no update" — non-empty inputs still overwrite as before.

        Compensation: caller invokes ``remove_lite_episode(uuid)`` on
        Stage 5 failure (raw Cypher matches the MERGE+SET path).
        """
        cypher = """
        MERGE (n:Episodic {uuid: $uuid, group_id: $group_id})
        ON CREATE SET
            n.uuid = $uuid,
            n.name = $name,
            n.group_id = $group_id,
            n.source_description = $source_description,
            n.source = 'text',
            n.content = $content,
            n.entity_edges = [],
            n.created_at = $created_at,
            n.valid_at = $valid_at
        ON MATCH SET
            n.name = $name,
            n.source_description = $source_description,
            n.content = CASE WHEN $content = '' THEN n.content ELSE $content END,
            n.valid_at = $valid_at
        """
        try:
            await self._g.driver.execute_query(
                cypher,
                uuid=str(episode_uuid),
                name=name,
                group_id=tenant_id,
                source_description=source_description,
                content=content,
                created_at=created_at,
                valid_at=valid_at,
            )
        except Exception as exc:
            raise GraphStoreError(f"write_lite_episode failed: {exc}") from exc

    async def overwrite_episode_content(
        self,
        *,
        tenant_id: str,
        episode_uuid: UUID,
        content: str,
    ) -> None:
        """Replace ``Episodic.content`` after a preprocessor-augmented
        ``add_episode``. Tenant predicate prevents cross-tenant write.

        Used by the v0.1.1 preprocessor (issues #2/#3/#4) so provenance
        returns the original markdown rather than the augmented body.
        """
        cypher = """
        MATCH (ep:Episodic {uuid: $uuid, group_id: $tenant})
        SET ep.content = $content
        """
        try:
            await self._g.driver.execute_query(
                cypher,
                uuid=str(episode_uuid),
                tenant=tenant_id,
                content=content,
            )
        except Exception as exc:
            raise GraphStoreError(
                f"overwrite_episode_content failed: {exc}",
            ) from exc

    async def list_candidate_episodes(
        self,
        *,
        tenant_id: str,
        valid_at: datetime,
        candidate_pool: int,
    ) -> list[EpisodeCandidate]:
        """Stage 2a: episodes whose world-time lower bound is satisfied.

        `EpisodicNode` has no `invalid_at` — half-pair only on the lower
        bound here. Upper bound + asserted-axis live in `MetadataStore`.
        """
        cypher = """
        MATCH (ep:Episodic)
        WHERE ep.group_id = $tenant
          AND ep.valid_at <= $valid_at
        RETURN ep.uuid AS uuid, ep.valid_at AS valid_at
        ORDER BY ep.valid_at DESC, ep.uuid
        LIMIT $limit
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                tenant=tenant_id,
                valid_at=valid_at,
                limit=candidate_pool,
            )
        except Exception as exc:
            raise GraphStoreError(f"list_candidate_episodes failed: {exc}") from exc
        return [EpisodeCandidate(episode_uuid=UUID(r["uuid"])) for r in records]

    async def fetch_facts_for_episodes(
        self,
        *,
        tenant_id: str,
        episode_uuids: list[UUID],
        valid_at: datetime,
        query_vector: list[float] | None = None,
    ) -> list[FactRow]:
        """Stage 4: edge half-pair `r.invalid_at IS NULL OR r.invalid_at > X`.

        Undirected `RELATES_TO` so the mentioned entity is matched on either side.
        Tenant predicate on every node + edge to prevent cross-tenant leakage.

        Issue #95 — `ep.uuid IN r.episodes` guard. Graphiti's `MENTIONS`
        chain attaches every fact about a shared entity hub (e.g. the
        subject of the corpus) to every episode that mentions that hub.
        Without the `r.episodes` filter, a 10-episode corpus about
        "Alex Morgan" surfaces ~10 cross-pollinated facts per episode, and
        Stage 6's token-budget loop emits the rank-1 episode's polluted
        list before reaching authoritative facts from rank 2+ (which can
        contain the actual answer — e.g. allergy facts in Q41 p_x1_03).
        `r.episodes[]` is Graphiti's authoritative attribution list for
        the edge, so this filter keeps only the facts an episode genuinely
        produced.

        Issue #290 — when ``query_vector`` is supplied, project
        ``vector.similarity.cosine(r.fact_embedding, $q_vec)`` so callers
        (RecallPipeline) can rerank or floor-filter by fact-vs-query
        topical similarity. Null on edges without ``fact_embedding``
        (older data) — the floor filter must treat ``None`` as
        unfilterable, not as zero.
        """
        if not episode_uuids:
            return []
        cosine_proj = (
            "vector.similarity.cosine(r.fact_embedding, $q_vec) AS fact_cosine"
            if query_vector is not None
            else "NULL AS fact_cosine"
        )
        cypher = f"""
        MATCH (ep:Episodic)-[:MENTIONS]->(n:Entity)-[r:RELATES_TO]-(m:Entity)
        WHERE ep.uuid IN $episode_uuids
          AND ep.group_id = $tenant
          AND n.group_id  = $tenant
          AND m.group_id  = $tenant
          AND r.group_id  = $tenant
          AND ep.uuid IN r.episodes
          AND (r.valid_at IS NULL OR r.valid_at <= $valid_at)
          AND (r.invalid_at IS NULL OR r.invalid_at > $valid_at)
        RETURN DISTINCT r.uuid AS fact_uuid,
                        r.fact AS fact_text,
                        r.valid_at AS valid_at,
                        ep.uuid AS episode_uuid,
                        {cosine_proj}
        """
        params: dict[str, object] = {
            "episode_uuids": [str(u) for u in episode_uuids],
            "tenant": tenant_id,
            "valid_at": valid_at,
        }
        if query_vector is not None:
            params["q_vec"] = query_vector
        try:
            records, _, _ = await self._g.driver.execute_query(cypher, **params)
        except Exception as exc:
            raise GraphStoreError(f"fetch_facts_for_episodes failed: {exc}") from exc
        out: list[FactRow] = []
        for r in records:
            v = r["valid_at"]
            if v is None:
                continue
            raw_cos = r["fact_cosine"]
            cos: float | None = float(raw_cos) if raw_cos is not None else None
            out.append(
                FactRow(
                    fact_uuid=UUID(r["fact_uuid"]),
                    text=r["fact_text"],
                    valid_at=_to_datetime(v),
                    episode_uuid=UUID(r["episode_uuid"]),
                    fact_cosine=cos,
                )
            )
        return out

    async def fact_valid_at_lookup(
        self,
        *,
        tenant_id: str,
        fact_uuids: list[UUID],
    ) -> dict[UUID, datetime]:
        """For contradiction surfacing: each counterpart's `r.valid_at` lookup
        keyed by edge uuid.

        v0.1: lookup is for *display* only (`ContradictionRef.valid_at` so the
        consuming LLM can apply a recency heuristic). It is intentionally NOT
        gated by `valid_at`/`invalid_at` half-pairs — a superseded counterpart
        is still meaningful context to surface.
        """
        if not fact_uuids:
            return {}
        cypher = """
        MATCH ()-[r:RELATES_TO]-()
        WHERE r.group_id = $tenant
          AND r.uuid IN $uuids
        RETURN DISTINCT r.uuid AS uuid, r.valid_at AS valid_at
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                tenant=tenant_id,
                uuids=[str(u) for u in fact_uuids],
            )
        except Exception as exc:
            raise GraphStoreError(f"fact_valid_at_lookup failed: {exc}") from exc
        out: dict[UUID, datetime] = {}
        for r in records:
            v = r["valid_at"]
            if v is None:
                continue
            out[UUID(r["uuid"])] = _to_datetime(v)
        return out

    async def fact_invalid_at_lookup(
        self,
        *,
        tenant_id: str,
        fact_uuids: list[UUID],
    ) -> dict[UUID, datetime | None]:
        """Per-edge `r.invalid_at` lookup keyed by edge uuid (ADR-0014).

        Source of `superseded_at` on fact-revision rows: gnokee owns the
        Postgres revision log but the supersession-close timestamp lives on
        the Graphiti `RELATES_TO` edge (`r.invalid_at`). This method does
        the join so `FactHistoryPipeline` can populate `superseded_at` on
        every revision in one Cypher round-trip.

        Returned mapping contains an entry for every input `fact_uuid` the
        graph actually has — open edges map to `None` (live now), closed
        edges to their UTC close datetime. Missing keys mean the edge was
        not found at all (forget cascade already pruned it, or fact_uuid
        is foreign).
        """
        if not fact_uuids:
            return {}
        cypher = """
        MATCH ()-[r:RELATES_TO]-()
        WHERE r.group_id = $tenant
          AND r.uuid IN $uuids
        RETURN DISTINCT r.uuid AS uuid, r.invalid_at AS invalid_at
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                tenant=tenant_id,
                uuids=[str(u) for u in fact_uuids],
            )
        except Exception as exc:
            raise GraphStoreError(f"fact_invalid_at_lookup failed: {exc}") from exc
        out: dict[UUID, datetime | None] = {}
        for r in records:
            v = r["invalid_at"]
            out[UUID(r["uuid"])] = _to_datetime(v) if v is not None else None
        return out

    async def fetch_provenance(
        self,
        *,
        tenant_id: str,
        fact_uuid: UUID,
    ) -> ProvenanceRow | None:
        """For `gnokee_fact_provenance`: full episode body + edge attrs."""
        cypher = """
        MATCH (ep:Episodic)-[:MENTIONS]->(n:Entity)-[r:RELATES_TO]-(m:Entity)
        WHERE r.uuid     = $fact_uuid
          AND r.group_id = $tenant
          AND ep.group_id = $tenant
        RETURN r.uuid AS fact_uuid,
               r.fact AS fact_text,
               r.valid_at AS fact_valid_at,
               ep.uuid AS episode_uuid,
               ep.content AS episode_content
        LIMIT 1
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                fact_uuid=str(fact_uuid),
                tenant=tenant_id,
            )
        except Exception as exc:
            raise GraphStoreError(f"fetch_provenance failed: {exc}") from exc
        if not records:
            return None
        r = records[0]
        return ProvenanceRow(
            fact_uuid=UUID(r["fact_uuid"]),
            fact_text=r["fact_text"],
            fact_valid_at=_to_datetime(r["fact_valid_at"]),
            episode_uuid=UUID(r["episode_uuid"]),
            episode_content=r["episode_content"] or "",
        )

    async def fetch_episode_contents(
        self,
        *,
        tenant_id: str,
        episode_uuids: list[UUID],
    ) -> dict[UUID, str]:
        """Batch-fetch ``Episodic.content`` for a list of UUIDs in one Cypher.

        Used by the recall path's currency-excerpt stage so it can scan
        the verbatim body for amount-bearing lines without running a
        round-trip per episode (gnokee #7).
        """
        if not episode_uuids:
            return {}
        cypher = """
        MATCH (ep:Episodic)
        WHERE ep.group_id = $tenant AND ep.uuid IN $uuids
        RETURN ep.uuid AS episode_uuid, ep.content AS episode_content
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                tenant=tenant_id,
                uuids=[str(u) for u in episode_uuids],
            )
        except Exception as exc:
            raise GraphStoreError(f"fetch_episode_contents failed: {exc}") from exc
        out: dict[UUID, str] = {}
        for r in records:
            try:
                uuid_value = UUID(r["episode_uuid"])
            except (ValueError, TypeError):
                continue
            out[uuid_value] = r["episode_content"] or ""
        return out

    async def list_entities_for_tenant(
        self,
        *,
        tenant_id: str,
        valid_at: datetime,
    ) -> list[EntitySummary]:
        """List entities for the requesting tenant (ADR-0015 wiki export).

        Surfaces `(uuid, name)` pairs for every `:Entity` node whose
        `group_id == tenant_id`. Ordered by name (case-insensitive) so the
        wiki `index.md` renders deterministically. The world-time predicate
        on `valid_at` is satisfied indirectly via the entities' mentioning
        episodes — entities themselves carry no `valid_at` on the Graphiti
        schema, so we narrow to those that have at least one `MENTIONS`
        edge from an `Episodic` node whose `valid_at <= $valid_at`. This
        keeps "the entity exists at this point in world-time" semantically
        coherent.

        Tenant predicate on both nodes prevents cross-tenant leakage.
        """
        cypher = """
        MATCH (ep:Episodic)-[:MENTIONS]->(n:Entity)
        WHERE ep.group_id = $tenant
          AND n.group_id  = $tenant
          AND ep.valid_at <= $valid_at
        RETURN DISTINCT n.uuid AS uuid, n.name AS name
        ORDER BY toLower(n.name), n.uuid
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                tenant=tenant_id,
                valid_at=valid_at,
            )
        except Exception as exc:
            raise GraphStoreError(f"list_entities_for_tenant failed: {exc}") from exc
        out: list[EntitySummary] = []
        for r in records:
            try:
                uuid_value = UUID(r["uuid"])
            except (ValueError, TypeError):
                continue
            name = r["name"] or ""
            out.append(EntitySummary(entity_uuid=uuid_value, name=name))
        return out

    async def fetch_facts_for_entity(
        self,
        *,
        tenant_id: str,
        entity_uuid: UUID,
        valid_at: datetime,
    ) -> list[EntityFactRow]:
        """List `(RELATES_TO)` edges touching `entity_uuid` (ADR-0015).

        Used by the wiki export's `entities/<slug>.md` page builder. Each
        row carries the edge's text + bi-temporal half-pair (`valid_at`,
        `invalid_at`) and the mentioning episode's UUID so the page can
        emit citation handles. `invalid_at` is preserved (NOT filtered) so
        the wiki page can partition rows into Current vs History; the
        wiki layer applies `scope=self|full` partition.

        World-time lower bound `ep.valid_at <= $valid_at` keeps episodes
        that haven't happened yet out of the wiki view; the edge's own
        `valid_at`/`invalid_at` are unfiltered here so superseded edges
        can land in the History section. Tenant predicate on every
        node + edge.

        Undirected `RELATES_TO` match so the entity is captured on
        either side of the edge; we then return the OTHER endpoint as
        `other_entity_*` so the page can render
        "entity A → fact → entity B".
        """
        cypher = """
        MATCH (ep:Episodic)-[:MENTIONS]->(n:Entity {uuid: $entity_uuid})-[r:RELATES_TO]-(m:Entity)
        WHERE ep.group_id = $tenant
          AND n.group_id  = $tenant
          AND m.group_id  = $tenant
          AND r.group_id  = $tenant
          AND ep.valid_at <= $valid_at
        RETURN DISTINCT r.uuid       AS fact_uuid,
                        r.fact       AS fact_text,
                        r.valid_at   AS valid_at,
                        r.invalid_at AS invalid_at,
                        ep.uuid      AS episode_uuid,
                        m.uuid       AS other_entity_uuid,
                        m.name       AS other_entity_name
        ORDER BY r.valid_at DESC, r.uuid
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                tenant=tenant_id,
                entity_uuid=str(entity_uuid),
                valid_at=valid_at,
            )
        except Exception as exc:
            raise GraphStoreError(f"fetch_facts_for_entity failed: {exc}") from exc
        out: list[EntityFactRow] = []
        for r in records:
            v = r["valid_at"]
            if v is None:
                continue
            try:
                fact_uuid = UUID(r["fact_uuid"])
                episode_uuid = UUID(r["episode_uuid"])
                other_uuid = UUID(r["other_entity_uuid"])
            except (ValueError, TypeError):
                continue
            invalid_raw = r["invalid_at"]
            invalid_at = _to_datetime(invalid_raw) if invalid_raw is not None else None
            out.append(
                EntityFactRow(
                    fact_uuid=fact_uuid,
                    fact_text=r["fact_text"] or "",
                    valid_at=_to_datetime(v),
                    invalid_at=invalid_at,
                    episode_uuid=episode_uuid,
                    other_entity_uuid=other_uuid,
                    other_entity_name=r["other_entity_name"] or "",
                )
            )
        return out

    async def list_episode_edge_triples(
        self,
        *,
        tenant_id: str,
        episode_uuid: UUID,
    ) -> list[EdgeTriple]:
        """Return all EntityEdge triples mentioning `episode_uuid`.

        Used by Stage 6c (`src/gnokee/ingest.py`) fact_id inheritance:
        when `EpisodeIn.corrects=X` fires, Stage 6c reads X's triples to
        match against the new episode's freshly extracted edges, inheriting
        `fact_id` for matched triples.

        Directional `(s)-[r:RELATES_TO]->(t)` so the subject/object axis is
        preserved — `(Vadim, takes, Metformin)` != `(Metformin, takes, Vadim)`.
        Tenant predicate on every node + edge per ADR-0023.

        Includes superseded edges (no `invalid_at` filter): Stage 6c needs
        the full universe of prior triples so the new revision can inherit
        even from edges that were later marked invalid.
        """
        cypher = """
        MATCH (ep:Episodic {uuid: $episode_uuid})
        MATCH (ep)-[:MENTIONS]->(s:Entity)-[r:RELATES_TO]->(t:Entity)
        WHERE ep.group_id = $tenant
          AND s.group_id  = $tenant
          AND t.group_id  = $tenant
          AND r.group_id  = $tenant
        RETURN r.uuid     AS fact_uuid,
               s.uuid     AS source_uuid,
               r.name     AS predicate,
               t.uuid     AS target_uuid,
               r.fact     AS fact_text,
               r.valid_at AS valid_at
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                episode_uuid=str(episode_uuid),
                tenant=tenant_id,
            )
        except Exception as exc:
            raise GraphStoreError(f"list_episode_edge_triples failed: {exc}") from exc

        out: list[EdgeTriple] = []
        for r in records:
            try:
                fact_uuid = UUID(r["fact_uuid"])
                source_uuid = UUID(r["source_uuid"])
                target_uuid = UUID(r["target_uuid"])
            except (ValueError, TypeError):
                continue
            predicate = r["predicate"] or ""
            fact_text = r["fact_text"] or ""
            if not predicate:
                continue
            v = r["valid_at"]
            valid_at = _to_datetime(v) if v is not None else None
            out.append(
                EdgeTriple(
                    fact_uuid=fact_uuid,
                    source_node_uuid=source_uuid,
                    predicate=predicate,
                    target_node_uuid=target_uuid,
                    fact_text=fact_text,
                    valid_at=valid_at,
                )
            )
        return out

    async def list_edges_in_window(
        self,
        *,
        tenant_id: str,
        created_at_start: datetime | None = None,
        created_at_end: datetime | None = None,
    ) -> list[EdgeInWindow]:
        """Scan EntityEdges (RELATES_TO) by tenant + optional created_at window.

        Issue #169: used by ``maintenance.backfill_fact_revisions`` to
        find edges in Neo4j that may have missing ``fact_revision`` rows
        in Postgres (Stage 6c crash-recovery class).

        Tenant predicate on every node + edge per ADR-0023.

        Window semantics (issue #210 rename): ``created_at_start`` and
        ``created_at_end`` bind ``r.created_at`` — Graphiti's
        ingest-system time on the edge (axis-3 per ADR-0004). The
        params were previously named ``window_start`` / ``window_end``
        which obscured which axis they filtered. Narrowing to a known
        crash window keeps the scan cheap on long-lived tenants.
        Both bounds optional: ``None`` = unbounded on that side.

        Directional ``(s)-[r:RELATES_TO]->(t)`` so subject/object axis is
        preserved (consistent with ``list_episode_edge_triples``).

        ``episode_uuid`` is resolved from any ``Episodic`` that
        ``MENTIONS`` the edge source — first hit wins via Python-side
        de-dup. Edges with NO mentioning episode in this tenant drop out
        of the result (orphan edges cannot be back-filled — no episode
        handle for the row).

        Each returned row carries ``edge_created_at`` (axis-3, set
        directly from Neo4j ``r.created_at``) and ``asserted_at=None``.
        The caller joins ``episode_metadata.asserted_at`` from Postgres
        to populate axis-2 — see ``EdgeInWindow`` docstring + issue
        #210 for the axis-confusion fix.

        Includes superseded edges (no ``invalid_at`` filter). The
        backfill caller filters out edges that already have a
        ``fact_revision`` row before inserting.
        """
        # Issue #243: static Cypher with parameterized predicates so the
        # Neo4j query-plan cache hits across calls. The previous f-string
        # path built one of four distinct strings depending on which
        # bounds were set, defeating plan reuse on the hot backfill loop.
        # `$created_at_start` / `$created_at_end` are always bound (NULL
        # when the caller omits the side) — the `IS NULL OR …` short-circuit
        # removes the predicate at planner time without changing the string.
        cypher = """
        MATCH (s:Entity)-[r:RELATES_TO]->(t:Entity)
        MATCH (ep:Episodic)-[:MENTIONS]->(s)
        WHERE ep.group_id = $tenant
          AND s.group_id  = $tenant
          AND t.group_id  = $tenant
          AND r.group_id  = $tenant
          AND ($created_at_start IS NULL OR r.created_at >= $created_at_start)
          AND ($created_at_end   IS NULL OR r.created_at <= $created_at_end)
        RETURN r.uuid       AS fact_uuid,
               s.uuid       AS source_uuid,
               r.name       AS predicate,
               t.uuid       AS target_uuid,
               r.fact       AS fact_text,
               r.valid_at   AS valid_at,
               r.created_at AS edge_created_at,
               ep.uuid      AS episode_uuid,
               ep.valid_at  AS episode_valid_at
        ORDER BY r.uuid, ep.uuid
        """
        params: dict[str, Any] = {
            "tenant": tenant_id,
            "created_at_start": created_at_start,
            "created_at_end": created_at_end,
        }
        try:
            records, _, _ = await self._g.driver.execute_query(cypher, **params)
        except Exception as exc:
            raise GraphStoreError(f"list_edges_in_window failed: {exc}") from exc

        # De-dup by fact_uuid — the MATCH on Episodic-MENTIONS-s produces
        # one row per (edge, mentioning_episode) pair; keep first.
        seen: set[UUID] = set()
        out: list[EdgeInWindow] = []
        for r in records:
            try:
                fact_uuid = UUID(r["fact_uuid"])
                source_uuid = UUID(r["source_uuid"])
                target_uuid = UUID(r["target_uuid"])
                episode_uuid = UUID(r["episode_uuid"])
            except (ValueError, TypeError):
                continue
            if fact_uuid in seen:
                continue
            predicate = r["predicate"] or ""
            fact_text = r["fact_text"] or ""
            if not predicate or not fact_text:
                continue
            v = r["valid_at"]
            ep_v = r["episode_valid_at"]
            created_raw = r["edge_created_at"]
            if created_raw is None:
                continue
            valid_at = _to_datetime(v) if v is not None else (_to_datetime(ep_v) if ep_v is not None else None)
            if valid_at is None:
                continue
            seen.add(fact_uuid)
            out.append(
                EdgeInWindow(
                    fact_uuid=fact_uuid,
                    source_node_uuid=source_uuid,
                    predicate=predicate,
                    target_node_uuid=target_uuid,
                    fact_text=fact_text,
                    valid_at=valid_at,
                    edge_created_at=_to_datetime(created_raw),
                    episode_uuid=episode_uuid,
                )
            )
        return out

    async def cosine_search_facts(
        self,
        *,
        tenant_id: str,
        embedding: list[float],
        top_k: int,
        threshold: float,
        exclude_fact_uuid: UUID | None = None,
    ) -> list[CosineCandidate]:
        """Q4 contradiction stage: cosine over `EntityEdge.fact_embedding`.

        Direct vector-index query (ADR-0004 deliberate exception — the
        target embedding lives on the Graphiti edge, not pgvector).
        """
        cypher = """
        CALL db.index.vector.queryRelationships('entity_edge_fact_embedding', $top_k, $embedding)
        YIELD relationship AS r, score
        WHERE r.group_id = $tenant
          AND ($exclude IS NULL OR r.uuid <> $exclude)
          AND score >= $threshold
        RETURN r.uuid AS uuid, r.fact AS fact_text, r.valid_at AS valid_at, score
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                top_k=top_k,
                embedding=embedding,
                tenant=tenant_id,
                exclude=str(exclude_fact_uuid) if exclude_fact_uuid else None,
                threshold=threshold,
            )
        except Exception as exc:
            raise GraphStoreError(f"cosine_search_facts failed: {exc}") from exc
        out: list[CosineCandidate] = []
        for r in records:
            v = r["valid_at"]
            if v is None:
                continue
            out.append(
                CosineCandidate(
                    fact_uuid=UUID(r["uuid"]),
                    fact_text=r["fact_text"],
                    valid_at=_to_datetime(v),
                    score=float(r["score"]),
                )
            )
        return out

    async def bootstrap_indices(self, *, embed_dim: int) -> None:
        """Run Graphiti's bootstrap + add gnokee-specific indexes.

        Notes:
        - Graphiti's `build_indices_and_constraints()` creates range +
          fulltext indices. As of graphiti-core 0.29 those include
          per-label range indexes on `group_id` for `Episodic`,
          `Entity`, `Community`, and the `RELATES_TO`/`MENTIONS`/
          `HAS_EPISODE`/`NEXT_EPISODE` relationship types. The Neo4j
          planner uses `NodeIndexSeek` on `(Episodic|Entity){group_id}`
          for every per-tenant filter gnokee emits (verified by
          `tests/integration/test_neo4j_group_id_indexes.py` — issue
          #152 regression guard). gnokee does NOT add its own
          `group_id` indexes because that would duplicate graphiti's
          and add pointless write amplification on every Episodic/
          Entity insert.
        - Vector indexes (HNSW) are NOT created by graphiti-core 0.29
          — gnokee creates them here. ``embed_dim`` is plumbed from the
          caller (`bootstrap.build_app` passes
          `gnokee.embeddings.EMBED_DIM`) so swapping the embedder dim
          cannot silently drift the schema. Threading the dim through
          the call signature keeps the tach contract (`storage.graph`
          must not import `embeddings`) and pins the value to the same
          source-of-truth used everywhere else in the pipeline.
        - `IF NOT EXISTS` does NOT correct a dim mismatch — if the
          embedder dim ever changes you must DROP and recreate these
          indexes (or run a re-embed migration). See issue #215.
        - `episodic_valid_at` is gnokee-specific (stage 2a candidate
          narrow).
        """
        try:
            await self._g.build_indices_and_constraints()
            await self._g.driver.execute_query(
                "CREATE INDEX episodic_valid_at IF NOT EXISTS FOR (e:Episodic) ON (e.valid_at)",
            )
            await self._g.driver.execute_query(
                f"""
                CREATE VECTOR INDEX entity_edge_fact_embedding IF NOT EXISTS
                FOR ()-[r:RELATES_TO]-() ON r.fact_embedding
                OPTIONS {{indexConfig: {{`vector.dimensions`: {embed_dim}, `vector.similarity_function`: 'cosine'}}}}
                """,
            )
            await self._g.driver.execute_query(
                f"""
                CREATE VECTOR INDEX entity_name_embedding IF NOT EXISTS
                FOR (n:Entity) ON n.name_embedding
                OPTIONS {{indexConfig: {{`vector.dimensions`: {embed_dim}, `vector.similarity_function`: 'cosine'}}}}
                """,
            )
        except Exception as exc:
            raise GraphStoreError(f"bootstrap_indices failed: {exc}") from exc


def _to_datetime(value: Any) -> datetime:
    """Coerce Neo4j temporal types or ISO strings to a tz-aware UTC datetime.

    Issue #183 — the Neo4j Python driver returns `neo4j.time.DateTime` with
    fixed-offset tzinfo (e.g. `+00:00` as a `pytz.FixedOffset`) or, on some
    driver/server combos, a *naive* datetime when the server stored the
    value without a zone. Both cases would propagate up to `FactRow`,
    `EpisodeMetadataRow` etc., where downstream code assumes tz-aware UTC.
    Normalize once at the boundary so callers can rely on the invariant.
    """
    if isinstance(value, datetime):
        result = value
    elif hasattr(value, "to_native"):
        # neo4j.time.DateTime
        native = value.to_native()
        if not isinstance(native, datetime):
            raise GraphStoreError(f"cannot coerce {type(value)} to datetime")
        result = native
    elif isinstance(value, str):
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    else:
        raise GraphStoreError(f"cannot coerce {type(value)} to datetime")
    # Normalize to tz-aware UTC. Naive inputs are interpreted as UTC (the
    # only timezone gnokee writes to Neo4j); aware inputs are converted.
    if result.tzinfo is None:
        return result.replace(tzinfo=timezone.utc)
    return result.astimezone(timezone.utc)


__all__ = [
    "CosineCandidate",
    "CrossEncoderClient",
    "EmbedderClient",
    "EntityFactRow",
    "EntitySummary",
    "EpisodeCandidate",
    "FactRow",
    "GraphitiStore",
    "LLMClient",
    "ProvenanceRow",
]
