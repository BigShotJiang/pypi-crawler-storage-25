"""src/gnokee/storage/__init__.py — Storage package.

exports: (none — submodules export their own surfaces)
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py | src/gnokee/contradiction.py
rules:   pg + Graphiti adapters live here; no business logic
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""
