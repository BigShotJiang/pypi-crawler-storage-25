"""src/gnokee/storage/forget_audit.py — gnokee_maintenance.forget_audit CRUD.

Pure async helpers over the audit table introduced by migration 0017.
The pipeline (src/gnokee/forget.py) is the only caller for INSERT /
UPDATE; maintenance.resume_forget reads via find_resumable.

exports: ForgetAuditRow | insert_begin | mark_commit | mark_fail | find_resumable | find_failed_neo4j_rows | find_all_failed_neo4j_rows | find_by_audit_id | find_prior_commit | find_for_prune | iter_for_prune | count_for_prune | delete_for_prune
used_by: src/gnokee/forget.py | src/gnokee/forget_cli.py | src/gnokee/maintenance.py
rules:   tenant_id on every read/write; no RLS (schema-isolated); tz-aware UTC
agent:   claude-sonnet-4-6 | 2026-05-16 | issue #130 ADR-0026 impl
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, cast
from uuid import UUID

import asyncpg

DEFAULT_PRUNE_CHUNK = 1000
DEFAULT_FAIL_SCAN_LIMIT = 500

Scope = Literal["episode", "tenant"]


@dataclass(frozen=True, slots=True)
class ForgetAuditRow:
    audit_id: UUID
    tenant_id: str
    scope: Scope
    episode_uuid: UUID | None
    cascade: bool
    dry_run: bool
    state: Literal["begin", "commit", "fail"]
    reason: str
    actor: str | None
    receipt: dict[str, Any] | None
    error: dict[str, Any] | None
    cascade_uuids: list[str] | None
    bitemporal_snap: list[dict[str, Any]] | None
    started_at: datetime
    finished_at: datetime | None


async def insert_begin(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    scope: Scope,
    episode_uuid: UUID | None,
    cascade: bool,
    dry_run: bool,
    reason: str,
    actor: str | None,
    cascade_uuids: list[str] | None,
    bitemporal_snap: list[dict[str, Any]] | None,
) -> UUID:
    """INSERT a state='begin' row. Returns the generated `audit_id`.

    Standalone helper — acquires a fresh connection from `pool` and runs
    the INSERT in its own implicit transaction. The audit row is
    durable when this awaits returns.

    The forget pipeline (gnokee.forget) does NOT use this helper. The
    pipeline needs the 'begin' insert to commit atomically with the
    Postgres sweep, so it issues the INSERT on the same connection as
    the sweep via `gnokee.forget._insert_begin_in_conn`. Do not call
    this function from inside an open transaction held on a different
    connection — you will get two independent transactions and lose the
    atomicity guarantee.
    """
    sql = """
        INSERT INTO gnokee_maintenance.forget_audit
            (tenant_id, scope, episode_uuid, cascade, dry_run, state,
             reason, actor, cascade_uuids, bitemporal_snap)
        VALUES
            ($1, $2, $3, $4, $5, 'begin', $6, $7, $8, $9)
        RETURNING audit_id;
    """
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            sql,
            tenant_id,
            scope,
            episode_uuid,
            cascade,
            dry_run,
            reason,
            actor,
            json.dumps(cascade_uuids) if cascade_uuids is not None else None,
            json.dumps(bitemporal_snap) if bitemporal_snap is not None else None,
        )
    assert row is not None
    return cast(UUID, row["audit_id"])


async def mark_commit(
    pool: asyncpg.Pool,
    *,
    audit_id: UUID,
    receipt: dict[str, Any],
) -> None:
    sql = """
        UPDATE gnokee_maintenance.forget_audit
           SET state = 'commit',
               receipt = $2,
               finished_at = now()
         WHERE audit_id = $1 AND state IN ('begin', 'fail');
    """
    async with pool.acquire() as conn:
        await conn.execute(sql, audit_id, json.dumps(receipt))


async def mark_fail(
    pool: asyncpg.Pool,
    *,
    audit_id: UUID,
    error: dict[str, Any],
) -> None:
    sql = """
        UPDATE gnokee_maintenance.forget_audit
           SET state = 'fail',
               error = $2,
               finished_at = now()
         WHERE audit_id = $1;
    """
    async with pool.acquire() as conn:
        await conn.execute(sql, audit_id, json.dumps(error))


async def find_resumable(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
) -> list[ForgetAuditRow]:
    """Return state='begin' rows for tenant, oldest-first.

    'fail' rows are surfaced separately via find_failed_neo4j_rows;
    resume_forget consumes both lists.
    """
    sql = """
        SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
               state, reason, actor, receipt, error, cascade_uuids,
               bitemporal_snap, started_at, finished_at
          FROM gnokee_maintenance.forget_audit
         WHERE tenant_id = $1 AND state = 'begin'
         ORDER BY started_at;
    """
    async with pool.acquire() as conn:
        rows = await conn.fetch(sql, tenant_id)
    return [_row(r) for r in rows]


async def find_failed_neo4j_rows(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
) -> list[ForgetAuditRow]:
    sql = """
        SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
               state, reason, actor, receipt, error, cascade_uuids,
               bitemporal_snap, started_at, finished_at
          FROM gnokee_maintenance.forget_audit
         WHERE tenant_id = $1 AND state = 'fail'
         ORDER BY started_at;
    """
    async with pool.acquire() as conn:
        rows = await conn.fetch(sql, tenant_id)
    return [_row(r) for r in rows]


async def find_all_failed_neo4j_rows(
    pool: asyncpg.Pool,
    *,
    limit: int = DEFAULT_FAIL_SCAN_LIMIT,
    after_started_at: datetime | None = None,
    after_audit_id: UUID | None = None,
) -> list[ForgetAuditRow]:
    """Return state='fail' rows across all tenants, oldest-first, paged.

    Operator-CLI helper for `gnokee-forget --scan`. Bounded by `limit`
    (default 500) and resumable via the composite keyset cursor
    `(after_started_at, after_audit_id)` — pass the last returned row's
    `started_at` AND `audit_id` to fetch the next page. The composite
    is required because `started_at` ties on concurrent inserts, and
    a single-column strict-`>` cursor would silently skip every tied
    row after the first.

    Pagination is keyset, not OFFSET, so resume cost stays O(limit)
    regardless of cursor position.
    """
    if after_started_at is None:
        sql = """
            SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
                   state, reason, actor, receipt, error, cascade_uuids,
                   bitemporal_snap, started_at, finished_at
              FROM gnokee_maintenance.forget_audit
             WHERE state = 'fail'
             ORDER BY started_at, audit_id
             LIMIT $1;
        """
        params: tuple[Any, ...] = (limit,)
    else:
        if after_audit_id is None:
            raise ValueError("after_audit_id is required when after_started_at is set")
        sql = """
            SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
                   state, reason, actor, receipt, error, cascade_uuids,
                   bitemporal_snap, started_at, finished_at
              FROM gnokee_maintenance.forget_audit
             WHERE state = 'fail' AND (started_at, audit_id) > ($2, $3)
             ORDER BY started_at, audit_id
             LIMIT $1;
        """
        params = (limit, after_started_at, after_audit_id)
    async with pool.acquire() as conn:
        rows = await conn.fetch(sql, *params)
    return [_row(r) for r in rows]


async def find_by_audit_id(pool: asyncpg.Pool, *, audit_id: UUID) -> ForgetAuditRow | None:
    """Return the audit row for `audit_id`, or None if absent."""
    sql = """
        SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
               state, reason, actor, receipt, error, cascade_uuids,
               bitemporal_snap, started_at, finished_at
          FROM gnokee_maintenance.forget_audit
         WHERE audit_id = $1;
    """
    async with pool.acquire() as conn:
        row = await conn.fetchrow(sql, audit_id)
    return _row(row) if row else None


async def find_prior_commit(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    scope: Scope,
    episode_uuid: UUID | None,
) -> ForgetAuditRow | None:
    """Idempotency helper. Returns the most-recent 'commit' row that
    matches the (tenant, scope, episode_uuid) lookup, or None."""
    if scope == "episode":
        sql = """
            SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
                   state, reason, actor, receipt, error, cascade_uuids,
                   bitemporal_snap, started_at, finished_at
              FROM gnokee_maintenance.forget_audit
             WHERE tenant_id = $1 AND scope = 'episode' AND episode_uuid = $2
               AND state = 'commit'
             ORDER BY started_at DESC
             LIMIT 1;
        """
        params: tuple[Any, ...] = (tenant_id, episode_uuid)
    else:
        sql = """
            SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
                   state, reason, actor, receipt, error, cascade_uuids,
                   bitemporal_snap, started_at, finished_at
              FROM gnokee_maintenance.forget_audit
             WHERE tenant_id = $1 AND scope = 'tenant' AND state = 'commit'
             ORDER BY started_at DESC
             LIMIT 1;
        """
        params = (tenant_id,)
    async with pool.acquire() as conn:
        row = await conn.fetchrow(sql, *params)
    return _row(row) if row else None


async def iter_for_prune(
    pool: asyncpg.Pool,
    *,
    tenant_id: str | None,
    before: datetime,
    chunk_size: int = DEFAULT_PRUNE_CHUNK,
) -> AsyncIterator[ForgetAuditRow]:
    """Yield audit rows older than `before` (started_at < before), oldest-first.

    Keyset cursor on `started_at` + `audit_id` (tiebreak), paging in
    chunks of `chunk_size`. Memory is bounded to one chunk regardless
    of total result size — the v0.8.x prune path used to fetch the
    whole result set into memory, which is OOM-prone on long-retention
    deploys with high audit churn (#155).

    Filters by `tenant_id` when non-None; otherwise across all tenants.
    Callers MUST consume the iterator fully or close it via `aclose()`;
    the underlying connection is acquired per chunk and released after
    each `fetch`, so an abandoned iterator leaks nothing.
    """
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    last_started_at: datetime | None = None
    last_audit_id: UUID | None = None
    while True:
        params: list[Any] = [before, chunk_size]
        sql = """
            SELECT audit_id, tenant_id, scope, episode_uuid, cascade, dry_run,
                   state, reason, actor, receipt, error, cascade_uuids,
                   bitemporal_snap, started_at, finished_at
              FROM gnokee_maintenance.forget_audit
             WHERE started_at < $1
        """
        if tenant_id is not None:
            params.append(tenant_id)
            sql += f" AND tenant_id = ${len(params)}"
        if last_started_at is not None:
            assert last_audit_id is not None
            params.extend([last_started_at, last_audit_id])
            sql += f" AND (started_at, audit_id) > (${len(params) - 1}, ${len(params)})"
        sql += " ORDER BY started_at, audit_id LIMIT $2;"
        async with pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        if not rows:
            return
        for r in rows:
            yield _row(r)
        last_started_at = rows[-1]["started_at"]
        last_audit_id = rows[-1]["audit_id"]
        if len(rows) < chunk_size:
            return


async def find_for_prune(
    pool: asyncpg.Pool,
    *,
    tenant_id: str | None,
    before: datetime,
) -> list[ForgetAuditRow]:
    """Eager wrapper over `iter_for_prune`. Materializes all rows.

    DEPRECATED for high-churn deployments — use `iter_for_prune` in any
    new code. Kept for test/CLI ergonomics where small audit sets are
    expected. `maintenance.prune_forget_audit` switched to the chunked
    iterator under #155.
    """
    return [r async for r in iter_for_prune(pool, tenant_id=tenant_id, before=before)]


async def count_for_prune(
    pool: asyncpg.Pool,
    *,
    tenant_id: str | None,
    before: datetime,
    state: str | None = None,
) -> int:
    """Count audit rows older than `before` matching optional filters.

    Cheaper than `find_for_prune` when the caller only needs a count
    (e.g. dry-run summary, fail-row safety probe).
    """
    base_sql = "SELECT count(*) AS n FROM gnokee_maintenance.forget_audit WHERE started_at < $1"
    params: list[Any] = [before]
    if tenant_id is not None:
        params.append(tenant_id)
        base_sql += f" AND tenant_id = ${len(params)}"
    if state is not None:
        params.append(state)
        base_sql += f" AND state = ${len(params)}"
    async with pool.acquire() as conn:
        row = await conn.fetchrow(base_sql, *params)
    return int(row["n"]) if row else 0


async def delete_for_prune(
    pool: asyncpg.Pool,
    *,
    tenant_id: str | None,
    before: datetime,
    chunk_size: int = DEFAULT_PRUNE_CHUNK,
) -> int:
    """Delete audit rows older than `before` in chunks. Returns total row count.

    Issued as a loop of `DELETE ... WHERE audit_id IN (SELECT audit_id
    ... LIMIT chunk_size)` so each statement holds only chunk-sized
    page locks and produces a small WAL record. Replaces a single
    unbounded DELETE that, on the prune window of a long-running deploy,
    held page locks for the duration and emitted a large WAL spike with
    TOAST chains on `bitemporal_snap`/`receipt` JSONB columns (#155).

    Each chunk runs in its own implicit transaction. Partial failure
    leaves the un-deleted tail intact; the operator may re-run the same
    `before` cutoff to resume.

    Caller MUST have verified there are zero ``state='fail'`` rows in the
    selection — this helper does not gate. ``maintenance.prune_forget_audit``
    is the guard layer.
    """
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    base_select = "SELECT audit_id FROM gnokee_maintenance.forget_audit WHERE started_at < $1"
    base_params: list[Any] = [before]
    if tenant_id is not None:
        base_params.append(tenant_id)
        base_select += f" AND tenant_id = ${len(base_params)}"
    base_select += f" ORDER BY started_at, audit_id LIMIT ${len(base_params) + 1}"
    # NB: SELECT subquery is bound in the same DELETE statement, so the
    # chunk_size parameter rides along as the final positional. `base_select`
    # is composed only from hard-coded SQL + numeric `$N` placeholders, so
    # this is not an injection vector.
    delete_sql = f"DELETE FROM gnokee_maintenance.forget_audit WHERE audit_id IN ({base_select})"  # noqa: S608
    total = 0
    async with pool.acquire() as conn:
        while True:
            result = await conn.execute(delete_sql, *base_params, chunk_size)
            try:
                n = int(result.split()[-1])
            except (ValueError, IndexError):
                n = 0
            total += n
            if n < chunk_size:
                return total


def _row(r: asyncpg.Record) -> ForgetAuditRow:
    return ForgetAuditRow(
        audit_id=r["audit_id"],
        tenant_id=r["tenant_id"],
        scope=r["scope"],
        episode_uuid=r["episode_uuid"],
        cascade=r["cascade"],
        dry_run=r["dry_run"],
        state=r["state"],
        reason=r["reason"],
        actor=r["actor"],
        receipt=json.loads(r["receipt"]) if r["receipt"] else None,
        error=json.loads(r["error"]) if r["error"] else None,
        cascade_uuids=json.loads(r["cascade_uuids"]) if r["cascade_uuids"] else None,
        bitemporal_snap=json.loads(r["bitemporal_snap"]) if r["bitemporal_snap"] else None,
        started_at=r["started_at"],
        finished_at=r["finished_at"],
    )
