"""src/gnokee/storage/fact_revision_stage.py — shared Stage 6c executor (ADR-0014).

Wraps the "append fact_revision rows for a freshly-extracted set of
EntityEdges" sub-pipeline so the SAME implementation is called from BOTH
the full ingest path (``gnokee.ingest.IngestPipeline.ingest`` Stage 6c)
AND the lite→full back-fill path
(``gnokee.maintenance._extract_one`` Stage 6c).

Before this helper existed (issue #179), the maintenance path ran Stage
4 + Stage 5 only and skipped Stage 6c — producing EntityEdges in Neo4j
with NO matching ``fact_revision`` rows in Postgres, silently breaking
``gnokee_fact_history`` for every lite-mode episode that ever got
back-filled. The fix is mechanical: extract the loop, share it.

Failure posture (unchanged from the pre-extraction ingest.py shape):
  * Best-effort; failure does NOT compensate Stage 4/5 state — Graphiti
    edges are already durable in Neo4j by this point, so failing here
    would leave Postgres absent but Neo4j present (a worse skew).
  * Failure increments the returned ``skew_count`` (callers surface it
    as ``IngestTelemetry.fact_revision_skew_count`` on the receipt).
  * Per-edge malformed-uuid / empty-predicate skips log WARNING and
    continue (do NOT count toward skew — those edges are unprocessable
    by design, not infrastructure-failure).

Prior-triple map: when ``corrects`` is supplied, the helper loads the
corrected episode's edge triples from Neo4j so new edges sharing a
``(source, predicate, target)`` triple inherit ``fact_id`` +
``prior_revision_id`` from the prior revision (ADR-0014 fact-grain
lineage). When ``corrects`` is None, each new edge gets a fresh
``fact_id = fact_uuid`` and ``prior_revision_id = None``.

exports: write_fact_revisions_for_edges
used_by: src/gnokee/ingest.py | src/gnokee/maintenance.py
rules:   tenant_id on every read/write; tz-aware UTC; never compensate
agent:   claude-opus-4-7 | 2026-05-16 | issue #179 ADR-0014
"""

from __future__ import annotations

import logging
import os
from collections.abc import Sequence
from datetime import datetime
from typing import Any
from uuid import UUID

import asyncpg

from gnokee.storage.fact_revision import FactRevisionRow, FactRevisionStore
from gnokee.storage.graph import GraphitiStore

__all__ = ["write_fact_revisions_for_edges"]

log = logging.getLogger(__name__)

# Test-harness escape hatch (issue #168). When set to "1", the Stage 6c
# helper short-circuits and returns 0 skew without touching Postgres or
# Neo4j. The ONLY supported caller is the A/B perf harness in
# tests/integration/test_fact_revision_ab_perf.py, which uses the toggle
# to measure delta_p95 = on_p95 - off_p95 against ADR-0014's
# "p95 added latency <= 10ms" acceptance criterion. Production code
# MUST NOT set this var — doing so silently disables fact_revision
# writes, breaking gnokee_fact_history for every episode ingested while
# it's active. A WARNING is emitted on first bypass to surface accidental
# production use.
_DISABLE_ENV_VAR = "GNOKEE_DISABLE_FACT_REVISION"
_warned_bypass = False


async def write_fact_revisions_for_edges(
    *,
    tenant_id: str,
    episode_uuid: UUID,
    episode_valid_at: datetime,
    asserted_at: datetime,
    edges: Sequence[Any],
    corrects: UUID | None,
    pool: asyncpg.Pool,
    graph: GraphitiStore,
    fact_revisions: FactRevisionStore,
    caller: str,
) -> int:
    """Append ``fact_revision`` rows for a freshly-extracted set of edges.

    Called from BOTH ``gnokee.ingest`` Stage 6c (full-mode ingest) AND
    ``gnokee.maintenance._extract_one`` (lite→full back-fill). Issue
    #179 — keep the two paths in lock-step to avoid silent
    history-shadow corruption on lite-mode episodes.

    Args:
        tenant_id: Tenant scope. Stamped on every written row.
        episode_uuid: Owning episode UUID for the new revisions.
        episode_valid_at: Fallback ``valid_at`` when an edge has no
            explicit ``valid_at`` (graphiti's extractor returns ``None``
            on edges whose temporal expression couldn't be parsed).
        asserted_at: Source-tx (axis-2) timestamp shared by every row.
        edges: Iterable of graphiti ``EntityEdge`` objects with
            ``.uuid``, ``.fact``, ``.name``, ``.source_node_uuid``,
            ``.target_node_uuid``, ``.valid_at`` attributes. Edges
            missing ``.uuid`` or ``.fact`` are skipped silently
            (consistent with ingest.py pre-#179 behavior).
        corrects: When set, the helper loads the corrected episode's
            triples and inherits ``fact_id`` / ``prior_revision_id``
            for any new edge whose ``(source, predicate, target)``
            triple matches. When ``None``, no inheritance; each new
            edge gets ``fact_id = fact_uuid``,
            ``prior_revision_id = None``.
        pool: asyncpg pool. The helper acquires its own connection +
            opens its own transaction for the batch insert. (Stage 6c
            is NOT inside the Stage 5 transaction — the helper writes
            a fresh, best-effort txn.)
        graph: GraphitiStore — used only when ``corrects`` is set, to
            look up the prior triples.
        fact_revisions: Store with the ``insert_batch`` +
            ``fetch_by_fact_uuid`` methods.
        caller: Free-form log tag ("ingest" or "maintenance") so
            failure log lines disambiguate the path under triage.

    Returns:
        ``skew_count`` — 0 when the batch insert succeeds (or when
        there were no rows to write); ``len(rows_to_write)`` when the
        batch insert raised. Callers wire this into
        ``IngestTelemetry.fact_revision_skew_count`` on the receipt.

    The helper NEVER raises. All exceptions are caught and logged;
    the skew count is the contract for downstream observability.

    Test-harness escape hatch (issue #168): when env var
    ``GNOKEE_DISABLE_FACT_REVISION=1`` is set, the helper short-circuits
    and returns 0 skew without touching Postgres or Neo4j. This exists
    ONLY for the A/B perf harness measuring ADR-0014's "p95 added
    latency <= 10ms" gate. Production callers MUST NOT set this var.
    """
    if os.environ.get(_DISABLE_ENV_VAR) == "1":
        global _warned_bypass
        if not _warned_bypass:
            _warned_bypass = True
            log.warning(
                "gnokee.%s: stage_6c bypassed via %s=1 — test-harness ONLY; "
                "production use silently breaks gnokee_fact_history",
                caller,
                _DISABLE_ENV_VAR,
            )
        return 0

    if not edges:
        return 0

    # Build prior-triple map when corrects: is set so new edges sharing a
    # triple with the prior episode inherit fact_id.
    prior_triple_map: dict[tuple[UUID, str, UUID], tuple[UUID, UUID]] = {}
    if corrects is not None:
        try:
            prior_triples = await graph.list_episode_edge_triples(
                tenant_id=tenant_id,
                episode_uuid=corrects,
            )
            async with pool.acquire() as _conn:
                for pt in prior_triples:
                    prior_rev = await fact_revisions.fetch_by_fact_uuid(
                        conn=_conn,
                        tenant_id=tenant_id,
                        fact_uuid=pt.fact_uuid,
                    )
                    if prior_rev is None or prior_rev.revision_id is None:
                        continue
                    prior_triple_map[(pt.source_node_uuid, pt.predicate, pt.target_node_uuid)] = (
                        prior_rev.fact_id,
                        prior_rev.revision_id,
                    )
        except Exception as exc:
            log.warning(
                "gnokee.%s: stage_6c prior-triple lookup failed tenant=%s corrects=%s: %s",
                caller,
                tenant_id,
                corrects,
                exc,
            )
            # Continue with empty map — new edges get fresh fact_ids.

    rows_to_write: list[FactRevisionRow] = []
    for edge in edges:
        if edge.uuid is None or not edge.fact:
            continue
        try:
            edge_fact_uuid = UUID(edge.uuid)
            edge_src = UUID(edge.source_node_uuid)
            edge_tgt = UUID(edge.target_node_uuid)
        except (ValueError, AttributeError) as exc:
            log.warning(
                "gnokee.%s: stage_6c skipped edge with malformed uuids: %s",
                caller,
                exc,
            )
            continue
        predicate = edge.name or ""
        if not predicate:
            log.warning(
                "gnokee.%s: stage_6c skipped edge %s with empty name",
                caller,
                edge.uuid,
            )
            continue
        key = (edge_src, predicate, edge_tgt)
        inherited = prior_triple_map.get(key)
        if inherited is not None:
            fact_id, prior_rev_id = inherited
        else:
            fact_id, prior_rev_id = edge_fact_uuid, None
        rows_to_write.append(
            FactRevisionRow(
                fact_id=fact_id,
                fact_uuid=edge_fact_uuid,
                tenant_id=tenant_id,
                episode_uuid=episode_uuid,
                valid_at=edge.valid_at or episode_valid_at,
                asserted_at=asserted_at,
                fact_text=edge.fact,
                source_node_uuid=edge_src,
                predicate=predicate,
                target_node_uuid=edge_tgt,
                prior_revision_id=prior_rev_id,
            )
        )

    if not rows_to_write:
        return 0

    try:
        async with pool.acquire() as conn:
            async with conn.transaction():
                await fact_revisions.insert_batch(conn=conn, rows=rows_to_write)
    except Exception as exc:
        skew = len(rows_to_write)
        log.warning(
            "gnokee.%s: stage_6c insert FAILED tenant=%s episode=%s skew=%d: %s",
            caller,
            tenant_id,
            episode_uuid,
            skew,
            exc,
        )
        return skew

    return 0
