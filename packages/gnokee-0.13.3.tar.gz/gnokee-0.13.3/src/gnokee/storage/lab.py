"""src/gnokee/storage/lab.py — lab_record adapter (ADR-0009).

Sibling of `metadata`, `vector`, `contradictions`. Owns the structured
clinical-lab table that ADR-0009 lifted out of graphiti's edge facts
because the edge-fact LLM strips numerics on lab panels.

Bi-temporal half-pairs match `episode_metadata`:
  - valid_at   = sample drawn time (parsed from the panel header)
  - asserted_at = result reported time (from `EpisodeIn.asserted_at`)

Population strategy is parser-driven for v0.2; structured-ingest (FHIR)
and LLM extraction land later.

exports: class LabStore | LabRecordRow
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py
rules:   tenant_id on every read+write; tz-aware UTC; never SQL DEFAULT now()
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0009
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from uuid import UUID

import asyncpg

from gnokee.errors import VectorStoreError


@dataclass(frozen=True)
class LabRecordRow:
    """One row destined for `lab_record`. Temporal fields filled by caller.

    ``source`` discriminates ingest paths (migration 0024 / #144):
    ``'llm_extracted'`` (default) for Stage 4 deterministic-parser output
    on the plaintext branch; ``'caller_parsed'`` for ``EpisodeIn.parsed_labs``
    rows on the encrypted_body branch. CHECK constraint on the table
    locks the set.
    """

    tenant_id: str
    episode_uuid: UUID
    analyte: str
    value_numeric: Decimal | None
    value_text: str | None
    unit: str | None
    ref_range_low: Decimal | None
    ref_range_high: Decimal | None
    abnormal_flag: str | None
    valid_at: datetime
    asserted_at: datetime
    loinc_code: str | None = None
    valid_until: datetime | None = None
    asserted_until: datetime | None = None
    source: str = "llm_extracted"


class LabStore:
    """Async wrapper around the `lab_record` table."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def write_rows(
        self,
        *,
        conn: asyncpg.Connection,
        rows: list[LabRecordRow],
    ) -> int:
        """Insert all rows in the caller's transaction. Returns count inserted.

        ``ON CONFLICT DO NOTHING`` absorbs PK collisions on idempotent
        ingest replay (same `(tenant_id, episode_uuid, analyte, valid_at)`
        tuple is allowed to recur safely — the row already exists).
        """
        if not rows:
            return 0
        try:
            inserted = 0
            for row in rows:
                result = await conn.fetchrow(
                    """
                    INSERT INTO lab_record (
                        tenant_id, episode_uuid, analyte, loinc_code,
                        value_numeric, value_text, unit,
                        ref_range_low, ref_range_high, abnormal_flag,
                        valid_at, valid_until, asserted_at, asserted_until,
                        source
                    ) VALUES (
                        $1, $2, $3, $4,
                        $5, $6, $7,
                        $8, $9, $10,
                        $11, $12, $13, $14,
                        $15
                    )
                    ON CONFLICT DO NOTHING
                    RETURNING analyte
                    """,
                    row.tenant_id,
                    row.episode_uuid,
                    row.analyte,
                    row.loinc_code,
                    row.value_numeric,
                    row.value_text,
                    row.unit,
                    row.ref_range_low,
                    row.ref_range_high,
                    row.abnormal_flag,
                    row.valid_at,
                    row.valid_until,
                    row.asserted_at,
                    row.asserted_until,
                    row.source,
                )
                if result is not None:
                    inserted += 1
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"lab_record.write_rows failed: {exc}") from exc
        return inserted

    async def latest(
        self,
        *,
        tenant_id: str,
        analyte: str,
        as_of: datetime,
        valid_at: datetime,
    ) -> LabRecordRow | None:
        """Most-recent visible row for the analyte, by `valid_at` desc.

        Both bi-temporal half-pairs are required — the typed-read path
        cannot ship a "still-valid" predicate without both halves
        (bi-temporal-auditor would flag).
        """
        try:
            async with self._pool.acquire() as conn, conn.transaction():
                # Issue #220 follow-up — `set_config(..., true)` is
                # transaction-local; the explicit transaction keeps the
                # `app.current_tenant` GUC alive across the SELECT so the
                # `lab_record` RLS policy is enforced under FORCE RLS.
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                row = await conn.fetchrow(
                    """
                    SELECT tenant_id, episode_uuid, analyte, loinc_code,
                           value_numeric, value_text, unit,
                           ref_range_low, ref_range_high, abnormal_flag,
                           valid_at, valid_until, asserted_at, asserted_until
                      FROM lab_record
                     WHERE tenant_id = $1
                       AND analyte = $2
                       AND asserted_at <= $3
                       AND (asserted_until IS NULL OR asserted_until > $3)
                       AND (valid_until    IS NULL OR valid_until    > $4)
                       AND valid_at <= $4
                  ORDER BY valid_at DESC
                     LIMIT 1
                    """,
                    tenant_id,
                    analyte,
                    as_of,
                    valid_at,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"lab_record.latest failed: {exc}") from exc
        if row is None:
            return None
        return _row_to_dc(row)

    async def history(
        self,
        *,
        tenant_id: str,
        analyte: str,
        since: datetime | None,
        until: datetime | None,
        as_of: datetime,
        valid_at: datetime,
        limit: int,
    ) -> list[LabRecordRow]:
        """Visible rows for analyte over `[since, until)`, asc by `valid_at`."""
        try:
            async with self._pool.acquire() as conn, conn.transaction():
                # Issue #220 follow-up — transaction wrapper keeps the
                # `app.current_tenant` GUC alive across the SELECT under
                # FORCE RLS (set_config(..., true) is transaction-local).
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                rows = await conn.fetch(
                    """
                    SELECT tenant_id, episode_uuid, analyte, loinc_code,
                           value_numeric, value_text, unit,
                           ref_range_low, ref_range_high, abnormal_flag,
                           valid_at, valid_until, asserted_at, asserted_until
                      FROM lab_record
                     WHERE tenant_id = $1
                       AND analyte = $2
                       AND asserted_at <= $3
                       AND (asserted_until IS NULL OR asserted_until > $3)
                       AND (valid_until    IS NULL OR valid_until    > $4)
                       AND valid_at <= $4
                       AND ($5::timestamptz IS NULL OR valid_at >= $5)
                       AND ($6::timestamptz IS NULL OR valid_at <  $6)
                  ORDER BY valid_at ASC
                     LIMIT $7
                    """,
                    tenant_id,
                    analyte,
                    as_of,
                    valid_at,
                    since,
                    until,
                    limit,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"lab_record.history failed: {exc}") from exc
        return [_row_to_dc(r) for r in rows]

    async def aggregate(
        self,
        *,
        tenant_id: str,
        analyte: str,
        op: str,  # "min" | "max" | "avg" | "count"
        since: datetime | None,
        until: datetime | None,
        as_of: datetime,
        valid_at: datetime,
    ) -> Decimal | None:
        """Numeric aggregate over visible rows. Returns None on empty set.

        ``count`` returns the row count. ``min`` / ``max`` / ``avg``
        operate on `value_numeric` and skip rows where it is NULL.
        """
        if op not in {"min", "max", "avg", "count"}:
            raise VectorStoreError(f"lab_record.aggregate: unknown op {op!r}")
        sql_expr = {
            "min": "MIN(value_numeric)",
            "max": "MAX(value_numeric)",
            "avg": "AVG(value_numeric)",
            "count": "COUNT(*)::numeric",
        }[op]
        value_filter = "" if op == "count" else "AND value_numeric IS NOT NULL"
        try:
            async with self._pool.acquire() as conn, conn.transaction():
                # Issue #220 follow-up — transaction wrapper keeps the
                # `app.current_tenant` GUC alive across the SELECT under
                # FORCE RLS (set_config(..., true) is transaction-local).
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                row = await conn.fetchrow(
                    f"""
                    SELECT {sql_expr} AS scalar
                      FROM lab_record
                     WHERE tenant_id = $1
                       AND analyte = $2
                       AND asserted_at <= $3
                       AND (asserted_until IS NULL OR asserted_until > $3)
                       AND (valid_until    IS NULL OR valid_until    > $4)
                       AND valid_at <= $4
                       AND ($5::timestamptz IS NULL OR valid_at >= $5)
                       AND ($6::timestamptz IS NULL OR valid_at <  $6)
                       {value_filter}
                    """,  # noqa: S608 — op is validated against literal set above
                    tenant_id,
                    analyte,
                    as_of,
                    valid_at,
                    since,
                    until,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"lab_record.aggregate failed: {exc}") from exc
        if row is None:
            return None
        scalar = row["scalar"]
        return Decimal(scalar) if scalar is not None else None

    async def abnormal(
        self,
        *,
        tenant_id: str,
        analyte: str | None,
        since: datetime | None,
        until: datetime | None,
        as_of: datetime,
        valid_at: datetime,
        limit: int,
    ) -> list[LabRecordRow]:
        """Visible rows with non-null `abnormal_flag` over `[since, until)`.

        Both bi-temporal half-pairs apply identically to the other read
        paths so retroactive corrections honour `as_of`/`valid_at` pins.
        ``analyte`` is optional — an unset value matches any analyte
        (callers asking "which electrolytes were abnormal" don't know
        the analyte ahead of time). Rows are ordered ascending by
        `valid_at` then `analyte` for stable presentation.
        """
        try:
            async with self._pool.acquire() as conn, conn.transaction():
                # Issue #220 follow-up — transaction wrapper keeps the
                # `app.current_tenant` GUC alive across the SELECT under
                # FORCE RLS (set_config(..., true) is transaction-local).
                await conn.execute(
                    "SELECT set_config('app.current_tenant', $1, true)",
                    tenant_id,
                )
                rows = await conn.fetch(
                    """
                    SELECT tenant_id, episode_uuid, analyte, loinc_code,
                           value_numeric, value_text, unit,
                           ref_range_low, ref_range_high, abnormal_flag,
                           valid_at, valid_until, asserted_at, asserted_until
                      FROM lab_record
                     WHERE tenant_id = $1
                       AND ($2::text IS NULL OR analyte = $2)
                       AND abnormal_flag IS NOT NULL
                       AND asserted_at <= $3
                       AND (asserted_until IS NULL OR asserted_until > $3)
                       AND (valid_until    IS NULL OR valid_until    > $4)
                       AND valid_at <= $4
                       AND ($5::timestamptz IS NULL OR valid_at >= $5)
                       AND ($6::timestamptz IS NULL OR valid_at <  $6)
                  ORDER BY valid_at ASC, analyte ASC
                     LIMIT $7
                    """,
                    tenant_id,
                    analyte,
                    as_of,
                    valid_at,
                    since,
                    until,
                    limit,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"lab_record.abnormal failed: {exc}") from exc
        return [_row_to_dc(r) for r in rows]

    async def supersede_matching(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        episode_uuid: UUID,
        keys: list[tuple[str, datetime]],
        asserted_until: datetime,
    ) -> int:
        """Close prior lab_record rows on `episode_uuid` whose
        ``(analyte, valid_at)`` appears in ``keys``. Updates only rows
        currently open on the tx-time half-pair (``asserted_until IS
        NULL``) and currently visible on the world-time half-pair
        (``valid_until IS NULL OR valid_until > asserted_until``).
        Returns the count of rows updated; the caller compares against
        ``len(keys)`` and logs a WARNING on a partial-match miss
        (parser drift on ``valid_at`` rounding would otherwise be a
        silent zero-match).

        ``episode_uuid`` is the chain-walk-resolved head per
        :py:meth:`gnokee.storage.metadata.MetadataStore.supersede`,
        NOT necessarily the caller's ``corrects`` value.
        """
        if not keys:
            return 0
        analytes = [k[0] for k in keys]
        valid_ats = [k[1] for k in keys]
        try:
            result = await conn.execute(
                """
                UPDATE lab_record
                   SET asserted_until = $5
                  FROM unnest($3::text[], $4::timestamptz[])
                       AS k(analyte, valid_at)
                 WHERE lab_record.tenant_id      = $1
                   AND lab_record.episode_uuid   = $2
                   AND lab_record.asserted_until IS NULL
                   AND (lab_record.valid_until IS NULL
                        OR lab_record.valid_until > $5)
                   AND lab_record.analyte        = k.analyte
                   AND lab_record.valid_at       = k.valid_at
                """,
                tenant_id,
                episode_uuid,
                analytes,
                valid_ats,
                asserted_until,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"lab_record.supersede_matching failed: {exc}") from exc
        # asyncpg returns "UPDATE N" on row-count operations.
        return int(result.split()[-1])


def _row_to_dc(row: asyncpg.Record) -> LabRecordRow:
    return LabRecordRow(
        tenant_id=row["tenant_id"],
        episode_uuid=row["episode_uuid"],
        analyte=row["analyte"],
        loinc_code=row["loinc_code"],
        value_numeric=row["value_numeric"],
        value_text=row["value_text"],
        unit=row["unit"],
        ref_range_low=row["ref_range_low"],
        ref_range_high=row["ref_range_high"],
        abnormal_flag=row["abnormal_flag"],
        valid_at=row["valid_at"],
        valid_until=row["valid_until"],
        asserted_at=row["asserted_at"],
        asserted_until=row["asserted_until"],
    )


__all__ = ["LabRecordRow", "LabStore"]
