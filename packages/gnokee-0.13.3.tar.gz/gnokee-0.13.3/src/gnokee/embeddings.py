"""src/gnokee/embeddings.py — Async embedder client.

Speaks two endpoint shapes interchangeably so gnokee can run against:

  * **HuggingFace TEI** (linux/amd64 docker image) — POSTs to ``/embed``,
    payload is ``{"inputs": [...], "truncate": bool}``, response is a
    plain ``list[list[float]]``.
  * **OpenAI-compatible** ``/v1/embeddings`` — Ollama on macOS (Metal),
    OpenAI cloud, LiteLLM proxies. Payload is
    ``{"model": "...", "input": [...]}``, response is the OpenAI
    embeddings shape (``{"data": [{"embedding": [...]}, ...]}``).

The mode is auto-detected from ``base_url``: ``/v1`` suffix → OpenAI
shape; otherwise TEI native.

Vectors are always 1024-dim bge-m3, locked across pgvector + Neo4j
vector indexes.

exports: class TEIClient | embed
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py | src/gnokee/bootstrap.py
rules:   1024-dim cosine vectors only; raise EmbeddingsUnavailable on transport failure
agent:   claude-opus-4-7 | 2026-05-08 | v0.1.1 — dual-shape extension
"""

from __future__ import annotations

import httpx

from gnokee.errors import EmbeddingsUnavailable

EMBED_DIM = 1024
"""bge-m3 dimensionality. Locked across pgvector + Neo4j vector indexes."""

DEFAULT_MAX_BATCH = 32
"""TEI default ``--max-client-batch-size`` ceiling. Larger batches return 422.
Graphiti's entity-resolution path can hand us 50+ extracted-entity queries on a
dense episode, so the client chunks defensively."""


class TEIClient:
    """Thin async embedder client. Speaks TEI native or OpenAI-compatible shape."""

    def __init__(
        self,
        base_url: str,
        *,
        model: str = "bge-m3",
        api_key: str = "",
        timeout: float = 30.0,
        truncate: bool = True,
        max_batch_size: int = DEFAULT_MAX_BATCH,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._model = model
        self._api_key = api_key
        self._timeout = timeout
        # bge-m3 max sequence length ≈ 8192 tokens. Long episodes (Notion
        # exports, full markdown notes, transcripts) blow past that and TEI
        # returns 422. Default to truncate; the lossy alternative is a
        # failed ingest. Caller can opt out via `truncate=False`.
        self._truncate = truncate
        if max_batch_size < 1:
            raise ValueError("max_batch_size must be >= 1")
        self._max_batch_size = max_batch_size
        # Mode select. `/v1` suffix → OpenAI-compatible /v1/embeddings; else
        # native TEI /embed. Ollama exposes an OpenAI-compat endpoint at
        # `/v1` so the same env var pivots the runtime cleanly.
        self._openai_shape = self._base_url.endswith("/v1")

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a batch of texts. Returns one vector per input.

        Chunks ``texts`` into ``max_batch_size`` slices to stay below TEI's
        ``--max-client-batch-size`` (32 by default). Slices are sent
        sequentially — graphiti's entity-resolution batches are typically
        small enough that a single chunk suffices, so we trade simplicity
        for the fan-out optimisation.
        """
        if not texts:
            return []
        out: list[list[float]] = []
        for i in range(0, len(texts), self._max_batch_size):
            chunk = texts[i : i + self._max_batch_size]
            try:
                async with httpx.AsyncClient(timeout=self._timeout) as client:
                    if self._openai_shape:
                        headers = {"Authorization": f"Bearer {self._api_key}"} if self._api_key else {}
                        resp = await client.post(
                            f"{self._base_url}/embeddings",
                            json={"model": self._model, "input": chunk},
                            headers=headers,
                        )
                        resp.raise_for_status()
                        body = resp.json()
                        if not isinstance(body, dict) or "data" not in body:
                            raise EmbeddingsUnavailable(
                                f"openai-compat embed returned unexpected payload: {type(body)}",
                            )
                        vectors = [item["embedding"] for item in body["data"] if "embedding" in item]
                    else:
                        resp = await client.post(
                            f"{self._base_url}/embed",
                            json={"inputs": chunk, "truncate": self._truncate},
                        )
                        resp.raise_for_status()
                        body = resp.json()
                        if not isinstance(body, list):
                            raise EmbeddingsUnavailable(
                                f"TEI returned non-list payload: {type(body)}",
                            )
                        vectors = body
            except httpx.HTTPError as exc:
                raise EmbeddingsUnavailable(f"embedder request failed: {exc}") from exc
            for vec in vectors:
                if not isinstance(vec, list) or len(vec) != EMBED_DIM:
                    raise EmbeddingsUnavailable(
                        f"embedder returned vector of dim "
                        f"{len(vec) if isinstance(vec, list) else '?'}; expected {EMBED_DIM}",
                    )
            out.extend([list(v) for v in vectors])
        return out

    async def embed_one(self, text: str) -> list[float]:
        """Embed a single text. Convenience over `embed`."""
        result = await self.embed([text])
        return result[0]
