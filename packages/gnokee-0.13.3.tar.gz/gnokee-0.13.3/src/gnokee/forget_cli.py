"""src/gnokee/forget_cli.py — operator CLI for the v0.8 forget pipeline.

Two subcommands wrap the maintenance API introduced by ADR-0026:

* ``gnokee-forget --scan`` — list pending ``state='fail'`` rows from
  ``gnokee_maintenance.forget_audit`` (one line per audit_id). Optional
  ``--tenant`` narrows the scan; without it every tenant is reported.
* ``gnokee-forget --resume <audit_id>`` — retry the Neo4j sweep for a
  single failed audit row and flip the row to ``state='commit'``.

The CLI honours the standard ``GNOKEE_PG_*`` and ``GNOKEE_NEO4J_*``
environment variables; it refuses ``--resume`` without ``--actor`` to keep
the audit trail complete.

exports: _cli_main | run_cli | run_cli_async | _run_scan | _run_resume
used_by: pyproject.toml console_scripts (gnokee-forget)
rules:   no auto-resolve; --resume requires --actor; --scan is read-only
agent:   claude-opus-4-7 | 2026-05-16 | issue #137 operator CLI
"""

from __future__ import annotations

import argparse
import asyncio
import sys
from collections.abc import Sequence
from uuid import UUID

from gnokee.bootstrap import build_app, shutdown_app
from gnokee.config import Settings
from gnokee.maintenance import resume_forget
from gnokee.storage import forget_audit


def _fmt_row(row: forget_audit.ForgetAuditRow) -> str:
    """One-line scan output: audit_id  tenant  scope  episode_uuid  started_at."""
    episode = str(row.episode_uuid) if row.episode_uuid is not None else "-"
    ts = row.started_at.isoformat()
    return f"{row.audit_id}\t{row.tenant_id}\t{row.scope}\t{episode}\t{ts}"


async def _run_scan(*, tenant: str | None) -> int:
    """``--scan`` implementation. Returns process exit code.

    Cross-tenant scan pages via the `after_started_at` keyset cursor
    (#155) — drains all `state='fail'` rows even when the count exceeds
    the per-call `limit` cap in `find_all_failed_neo4j_rows`.
    """
    settings = Settings()
    app = await build_app(settings, bootstrap_indices=False)
    rows: list[forget_audit.ForgetAuditRow] = []
    try:
        if tenant is None:
            cursor_ts = None
            cursor_aid = None
            while True:
                page = await forget_audit.find_all_failed_neo4j_rows(
                    app.pool,
                    after_started_at=cursor_ts,
                    after_audit_id=cursor_aid,
                )
                if not page:
                    break
                rows.extend(page)
                if len(page) < forget_audit.DEFAULT_FAIL_SCAN_LIMIT:
                    break
                cursor_ts = page[-1].started_at
                cursor_aid = page[-1].audit_id
        else:
            rows = await forget_audit.find_failed_neo4j_rows(app.pool, tenant_id=tenant)
    finally:
        await shutdown_app(app)

    if not rows:
        target = "any tenant" if tenant is None else f"tenant={tenant}"
        print(f"no pending forget_audit failures for {target}", file=sys.stderr)
        return 0

    print("audit_id\ttenant_id\tscope\tepisode_uuid\tstarted_at")
    for row in rows:
        print(_fmt_row(row))
    return 0


async def _run_resume(*, audit_id_str: str, actor: str) -> int:
    """``--resume <audit_id>`` implementation. Returns process exit code."""
    try:
        audit_id = UUID(audit_id_str)
    except ValueError:
        print(f"invalid audit_id: {audit_id_str!r}", file=sys.stderr)
        return 2

    settings = Settings()
    app = await build_app(settings, bootstrap_indices=False)
    try:
        row = await forget_audit.find_by_audit_id(app.pool, audit_id=audit_id)
        if row is None:
            print(f"audit_id not found: {audit_id}", file=sys.stderr)
            return 3
        if row.state != "fail":
            print(
                f"audit_id {audit_id} is in state={row.state!r}; only state='fail' rows are resumable",
                file=sys.stderr,
            )
            return 4

        print(
            f"resuming Neo4j sweep for audit_id={audit_id} tenant={row.tenant_id} scope={row.scope} actor={actor}",
            file=sys.stderr,
        )
        receipts = await resume_forget(app, tenant_id=row.tenant_id, audit_id=audit_id)
    finally:
        await shutdown_app(app)

    if not receipts:
        print(
            f"resume_forget returned no receipt for audit_id={audit_id} (row may have been retried concurrently)",
            file=sys.stderr,
        )
        return 5

    receipt = receipts[0]
    print(
        f"committed audit_id={audit_id} affected_episode_count="
        f"{receipt.affected_episode_count} replayed={receipt.replayed}"
    )
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gnokee-forget",
        description=("Operator CLI for gnokee_maintenance.forget_audit (ADR-0026). Wraps scan + resume_forget."),
    )
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument(
        "--scan",
        action="store_true",
        help="List pending state='fail' rows (read-only).",
    )
    mode.add_argument(
        "--resume",
        metavar="AUDIT_ID",
        help="Retry the Neo4j sweep for a single failed audit row.",
    )
    parser.add_argument(
        "--tenant",
        default=None,
        help="Narrow --scan to a single tenant_id.",
    )
    parser.add_argument(
        "--actor",
        default=None,
        help="Operator identity (required for --resume; recorded in audit log).",
    )
    return parser


async def run_cli_async(argv: Sequence[str] | None = None) -> int:
    """Async entrypoint — usable from tests that already own an event loop."""
    parser = _build_parser()
    args = parser.parse_args(argv)

    if args.resume is not None:
        if not args.actor:
            parser.error("--resume requires --actor (audit-trail completeness)")
        return await _run_resume(audit_id_str=args.resume, actor=args.actor)

    return await _run_scan(tenant=args.tenant)


def run_cli(argv: Sequence[str] | None = None) -> int:
    """Sync entrypoint — returns the would-be exit code."""
    return asyncio.run(run_cli_async(argv))


def _cli_main() -> None:
    sys.exit(run_cli())


__all__ = ["_cli_main", "run_cli", "run_cli_async"]


if __name__ == "__main__":
    _cli_main()
