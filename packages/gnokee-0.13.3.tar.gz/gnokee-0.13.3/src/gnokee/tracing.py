"""src/gnokee/tracing.py — OpenTelemetry adapter (omkit-backed, optional).

gnokee never imports OpenTelemetry directly. All tracing goes through
omkit so the W3C TraceContext + Baggage propagator stay consistent with
the rest of the Omur stack (spine, omur-business, noggin). Without
`pip install gnokee[omkit]`, `init_tracing` is a no-op and `tracer()`
returns a noop tracer — code can call `tracer().start_as_current_span(...)`
unconditionally without conditional wrapping.

exports: init_tracing | tracer | shutdown_tracing
used_by: src/gnokee/bootstrap.py | src/gnokee/ingest.py | src/gnokee/retrieval.py
rules:   never import opentelemetry in this module's top level; only inside try-blocks. gnokee MUST run with omkit absent.
agent:   claude-opus-4-7 | 2026-05-17 | omkit tracing integration
"""

from __future__ import annotations

import logging
from typing import Any

log = logging.getLogger(__name__)

_provider: Any | None = None


class _NoopSpan:
    def __enter__(self) -> _NoopSpan:
        return self

    def __exit__(self, *_: object) -> None:
        return None

    def set_attribute(self, _key: str, _value: object) -> None:
        return None

    def record_exception(self, _exc: BaseException) -> None:
        return None


class _NoopTracer:
    def start_as_current_span(self, _name: str, **_: object) -> _NoopSpan:
        return _NoopSpan()


_NOOP_TRACER = _NoopTracer()


def init_tracing(
    *,
    service_name: str = "gnokee",
    endpoint: str = "",
    enabled: bool = False,
) -> Any | None:
    """Initialise OTel via omkit. No-op when disabled or omkit absent.

    Returns the TracerProvider (when wired) or None. Idempotent: a second
    call with the same arguments is a no-op.
    """
    global _provider
    if not enabled:
        return None
    if _provider is not None:
        return _provider
    try:
        from omkit.tracing import init_tracing as omkit_init
    except ImportError:
        log.info("gnokee.tracing.omkit_unavailable")
        return None
    _provider = omkit_init(service_name, endpoint or None)
    return _provider


def tracer(name: str = "gnokee") -> Any:
    """Return an OTel tracer or a noop tracer. Always safe to call."""
    try:
        from opentelemetry import trace
    except ImportError:
        return _NOOP_TRACER
    return trace.get_tracer(name)


def shutdown_tracing() -> None:
    """Flush pending spans. Best-effort; never raises."""
    global _provider
    if _provider is None:
        return
    try:
        _provider.shutdown()
    except Exception:  # pragma: no cover
        log.exception("gnokee.tracing.shutdown_failed")
    finally:
        _provider = None


__all__ = ["init_tracing", "shutdown_tracing", "tracer"]
