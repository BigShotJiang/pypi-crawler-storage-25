"""src/gnokee/logging.py — structured-logging configuration.

JSON output. Always include: tenant_id, episode_uuid (when applicable),
latency_ms, stage. Never include: content, embedding vectors, LLM prompts.

When `omkit` is installed (`pip install gnokee[omkit]`) configure delegates
to `omkit.logging.configure_logging("gnokee")` so the contextvars-driven
tenant_id / request_id / trace_id fields auto-attach to every record and
match the rest of the Omur stack. Without `omkit`, the in-tree structlog
pipeline runs unchanged — gnokee remains a drop-in standalone library.

exports: configure | get_logger
used_by: src/gnokee/mcp.py | src/gnokee/demo.py
rules:   v0.1 = stdlib + structlog; omkit integration is opt-in, never required
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
         claude-opus-4-7 | 2026-05-17 | omkit logging integration
"""

from __future__ import annotations

import logging
from typing import Any

import structlog


def _configure_native(level: str) -> None:
    """Original in-tree structlog config. Kept as the fallback path."""
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(message)s",
    )
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.add_log_level,
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, level.upper(), logging.INFO),
        ),
        cache_logger_on_first_use=True,
    )


def configure(level: str = "info", *, service_name: str = "gnokee") -> None:
    """Configure structlog → stdlib bridge with JSON output.

    When `omkit` is importable, delegates to `omkit.logging.configure_logging`
    so the gnokee process emits the same correlation fields (`service`,
    `tenant_id`, `request_id`) as the rest of the Omur stack. The stdlib
    level is still set here so plain `logging.getLogger(...)` callers
    (graphiti_core, asyncpg) honour `level`.

    `LOG_FORMAT=console` (read by omkit) switches to human-readable output.
    """
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(message)s",
    )
    try:
        from omkit.logging import configure_logging
    except ImportError:
        _configure_native(level)
        return
    configure_logging(service_name)


def get_logger(name: str | None = None) -> Any:
    return structlog.get_logger(name)


__all__ = ["configure", "get_logger"]
