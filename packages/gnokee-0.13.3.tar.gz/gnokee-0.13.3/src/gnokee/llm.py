"""src/gnokee/llm.py — OpenAI-compatible LLM client wrapper.

gnokee never vendors an LLM. The consumer supplies `GNOKEE_OPENAI_BASE_URL`
+ `GNOKEE_OPENAI_API_KEY`. v0.1 uses gpt-4o-mini per Q4 spike.

exports: class OpenAIClient | classify_contradiction
used_by: src/gnokee/contradiction.py | src/gnokee/storage/graph.py (Graphiti LLM driver)
rules:   never hold keys; raise LLMUnavailable on transport faults; deterministic temperature=0
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

import json
from typing import Any

import httpx
from openai import AsyncOpenAI, OpenAIError

from gnokee.errors import LLMUnavailable
from gnokee.models import Verdict

Q4_SYSTEM_PROMPT = """You are a fact-relationship classifier for a memory system.

Classify the relationship between two facts (A and B) as exactly ONE label from this set:

  unrelated     - different topics; no semantic overlap
  refinement    - same fact, B adds detail or precision
  update        - world-state changed: A was true, then B replaced it
  contradiction - A and B make incompatible claims about the same point in time

Call the `classify_relationship` function with the label.
"""

Q4_USER_TEMPLATE = "Fact A: {a_text}\n\nFact B: {b_text}"


class OpenAIClient:
    """Async OpenAI-compatible chat client.

    Issue #228: self-hosted endpoints (vLLM, llama.cpp, Ollama, litellm)
    accept any non-empty string for the API key. Empty-key callers reach
    this class through ``bootstrap.build_app``; cloud-target misconfig is
    rejected upstream by ``_require_llm_credentials`` so any empty key
    arriving here is by design. We mirror the ``or "unused"`` placeholder
    already used for the graphiti AsyncOpenAI wiring so the openai-SDK
    constructor doesn't reject the empty string.
    """

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        model: str,
        temperature: float = 0.0,
    ) -> None:
        self._client = AsyncOpenAI(base_url=base_url, api_key=api_key or "unused")
        self._model = model
        self._temperature = temperature

    @property
    def model(self) -> str:
        return self._model

    async def complete(
        self,
        *,
        system: str,
        user: str,
        max_tokens: int = 32,
    ) -> str:
        try:
            resp = await self._client.chat.completions.create(
                model=self._model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                temperature=self._temperature,
                max_tokens=max_tokens,
            )
        except (OpenAIError, httpx.HTTPError) as exc:
            raise LLMUnavailable(f"chat.completions failed: {exc}") from exc
        if not resp.choices:
            raise LLMUnavailable("chat.completions returned no choices")
        content = resp.choices[0].message.content
        return (content or "").strip()

    async def classify_with_tool(
        self,
        *,
        system: str,
        user: str,
        tool_name: str,
        tool_description: str,
        param_name: str,
        enum_values: tuple[str, ...],
        max_tokens: int = 64,
    ) -> str:
        """Forced tool-call classification.

        Routes the response through an OpenAI tool-call with an `enum`-typed
        parameter so the wire shape carries the label structurally rather
        than as free-text. Eliminates the brittle ``raw.split()`` parsing
        path and works portably across any endpoint that implements the
        OpenAI tool-call spec (graphiti-core already requires the same).

        Returns the enum value the model picked. Raises
        :class:`LLMUnavailable` on transport faults, missing tool_calls,
        unparseable arguments, or out-of-enum values — callers decide
        whether to soft-fallback.
        """
        tool = {
            "type": "function",
            "function": {
                "name": tool_name,
                "description": tool_description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        param_name: {
                            "type": "string",
                            "enum": list(enum_values),
                        },
                    },
                    "required": [param_name],
                    "additionalProperties": False,
                },
            },
        }
        try:
            # openai SDK uses TypedDict overloads for `tools` / `tool_choice`;
            # passing plain dicts (so the same code runs against any
            # OpenAI-compatible endpoint) trips the overload resolver. The
            # JSON-on-the-wire is identical.
            resp = await self._client.chat.completions.create(  # type: ignore[call-overload]
                model=self._model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                temperature=self._temperature,
                max_tokens=max_tokens,
                tools=[tool],
                tool_choice={
                    "type": "function",
                    "function": {"name": tool_name},
                },
            )
        except (OpenAIError, httpx.HTTPError) as exc:
            raise LLMUnavailable(f"chat.completions tool-call failed: {exc}") from exc
        if not resp.choices:
            raise LLMUnavailable("chat.completions returned no choices")
        msg = resp.choices[0].message
        tool_calls = getattr(msg, "tool_calls", None)
        if not tool_calls:
            raise LLMUnavailable("tool-call response had no tool_calls")
        args_raw = tool_calls[0].function.arguments
        try:
            args = json.loads(args_raw)
        except json.JSONDecodeError as exc:
            raise LLMUnavailable(f"tool arguments not JSON: {args_raw!r}") from exc
        label = args.get(param_name) if isinstance(args, dict) else None
        if label not in enum_values:
            raise LLMUnavailable(f"tool returned out-of-enum value: {label!r}")
        return str(label)


VALID_VERDICTS: tuple[str, ...] = ("unrelated", "refinement", "update", "contradiction")


async def classify_contradiction(
    *,
    client: OpenAIClient,
    a_text: str,
    b_text: str,
) -> str:
    """Return one of `VALID_VERDICTS`.

    Raises `LLMUnavailable` on tool-call failure so the caller (per-pair loop
    in `contradiction.detect_for_facts`) can log the degraded path and count
    skipped pairs. An outer `try/except LLMUnavailable: return "unrelated"`
    here would mask transport failures from the caller (issue #229).

    v0.1 prompt is time-agnostic per Q4 spike — passing `valid_at` strings
    confused the classifier. The `update` vs `contradiction` distinction is
    inferred from semantic content alone; bi-temporal context is applied at
    retrieval-time, not classification-time.

    Uses forced tool-call mode (issue #175) so the label arrives structurally
    via an `enum`-typed function argument rather than as parsed free text.
    """
    user = Q4_USER_TEMPLATE.format(a_text=a_text, b_text=b_text)
    return await client.classify_with_tool(
        system=Q4_SYSTEM_PROMPT,
        user=user,
        tool_name="classify_relationship",
        tool_description=("Classify the relationship between fact A and fact B. Pick exactly one label from the enum."),
        param_name="label",
        enum_values=VALID_VERDICTS,
    )


def _coerce_verdict(label: str) -> Verdict | None:
    """Map a Q4 label to a persistable verdict (drops `unrelated`)."""
    if label in ("refinement", "update", "contradiction"):
        return label  # type: ignore[return-value]
    return None


def _safe_json_loads(s: str) -> dict[str, Any]:
    try:
        result = json.loads(s)
    except json.JSONDecodeError:
        return {}
    if isinstance(result, dict):
        return dict(result)
    return {}


__all__ = [
    "Q4_SYSTEM_PROMPT",
    "Q4_USER_TEMPLATE",
    "VALID_VERDICTS",
    "OpenAIClient",
    "_coerce_verdict",
    "_safe_json_loads",
    "classify_contradiction",
]
