"""src/gnokee/excerpts.py — Currency / med body-excerpt helpers.

Recall-side companion to the ingest-side preprocessor in ``gnokee.extract``.
Where the preprocessor lifts signal into derived sentences that *still*
get summarised by graphiti's edge-fact LLM, this module surfaces verbatim
``Episodic.content`` excerpts at recall time so the agent sees the
digits / drug names / dates the LLM stripped from edge text.

Pure functions only — no IO, no LLM. The retrieval pipeline calls these
when the user query references currency / amount-keyword tokens (Q1 + Q3
shape, gnokee #7) or med-history tokens (Q8 cheap mitigation, ADR-0010).

exports: query_wants_excerpt | find_currency_excerpt | find_med_excerpt
used_by: src/gnokee/retrieval.py
rules:   never raise on malformed input; cap output length deterministically
agent:   claude-opus-4-7 | 2026-05-09 | v0.1.x — gnokee #7 + ADR-0010 cheap path
"""

from __future__ import annotations

import re

_CURRENCY_PATTERN = re.compile(
    r"[€$£¥]\s?\d"  # symbol then digit:  €100
    r"|\d[\d,.\s]*\s*[€$£¥]"  # digit then symbol:   1,000 €  (common in EU)
    r"|\d[\d,.\s]*\s*(?:EUR|USD|GBP|JPY|BGN|CHF)\b",  # digit + ISO code
)
_AMOUNT_KEYWORD_PATTERN = re.compile(
    r"\b(total|subtotal|spent|spend|spending|cost|costs|budget|paid|"
    r"due|owed|balance|raised|sum|fee|tax|price|amount|invested|"
    r"outstanding|principal|invoice|expense|expenses|payment|payments)\b",
    re.IGNORECASE,
)
_MED_QUERY_PATTERN = re.compile(
    r"\b(medication|medications|meds|dose|doses|dosage|allergic|allergy|"
    r"allergies|prescribed|prescription|supplement|supplementation|"
    r"antibiotic|antibiotics|antihypertensive|diuretic|ACE-inhibitor|"
    r"ARB|statin|NSAID)\b",
    re.IGNORECASE,
)
_MED_UNIT_NEAR_DIGIT_PATTERN = re.compile(
    r"\d+\s*(?:mg|mcg|mEq|mL|IU|g)\b",
    re.IGNORECASE,
)
_MED_EVENT_VERB_PATTERN = re.compile(
    r"\b(started|stopped|discontinued|increased|decreased|added|switched|"
    r"continuing|holding|taking|took)\b",
    re.IGNORECASE,
)
_ALLERGY_LINE_PATTERN = re.compile(r"\bAllerg(?:y|ic)\b", re.IGNORECASE)
_DRUG_SUFFIX_PATTERN = re.compile(
    r"\b\w{2,}(?:pril|sartan|olol|statin|cillin|mycin|prazole|"
    r"semide|chloride|sulfate)\b",
    re.IGNORECASE,
)
_HEADING_PATTERN = re.compile(r"^#{1,6}\s+(.+?)\s*$")


def query_wants_excerpt(query: str) -> bool:
    """True if ``query`` references currency / amount or med-history tokens.

    Triggers excerpt fetch on the recall path. Returning False elsewhere
    is the cheap path: no extra Cypher round-trip, no extra response
    payload.
    """
    if not query:
        return False
    if _CURRENCY_PATTERN.search(query):
        return True
    if _AMOUNT_KEYWORD_PATTERN.search(query):
        return True
    if _MED_QUERY_PATTERN.search(query):
        return True
    return bool(_MED_UNIT_NEAR_DIGIT_PATTERN.search(query))


def find_currency_excerpt(content: str, max_chars: int = 200) -> str | None:
    """Return a short verbatim excerpt around the first amount in ``content``.

    Strategy:
      1. Walk lines; track the most-recent heading.
      2. First line containing a currency or amount-keyword + digit hits.
      3. Emit ``"<heading>: <line>"`` truncated to ``max_chars``; preserves
         the verbatim digits so the agent's recall reply can quote them.
      4. None when no amount-bearing line is found.
    """
    if not content:
        return None
    current_heading = ""
    for raw in content.splitlines():
        h = _HEADING_PATTERN.match(raw)
        if h:
            current_heading = h.group(1).strip()
            continue
        if not _line_has_amount(raw):
            continue
        line = raw.strip()
        excerpt = f"{current_heading}: {line}" if current_heading else line
        if len(excerpt) <= max_chars:
            return excerpt
        # Keep the amount visible: clip from the right rather than mid-line.
        return excerpt[: max(0, max_chars - 1)].rstrip() + "…"
    return None


def _line_has_amount(line: str) -> bool:
    if not line.strip():
        return False
    if _CURRENCY_PATTERN.search(line):
        return True
    if not re.search(r"\d", line):
        return False
    return bool(_AMOUNT_KEYWORD_PATTERN.search(line))


def find_med_excerpt(content: str, max_chars: int = 200) -> str | None:
    """Return a short verbatim excerpt around the first med-event line.

    Strategy mirrors :func:`find_currency_excerpt`:
      1. Walk lines; track the most-recent heading.
      2. First line carrying a med-event signal (verb, dose unit + digit,
         drug-suffix name, or allergy declaration) wins.
      3. Emit ``"<heading>: <line>"`` truncated to ``max_chars`` so the
         agent's recall reply can quote drug names + doses + dates.
      4. None when no med-shape line is found.

    Used by the recall pipeline as the Q8 cheap mitigation: graphiti's
    edge-fact extractor often summarises drug+dose tuples away. Surfacing
    the verbatim body line lets the agent answer "what dose of X was I
    on?" without a full structured ``med_record`` table (ADR-0010 v0.2).
    """
    if not content:
        return None
    current_heading = ""
    for raw in content.splitlines():
        h = _HEADING_PATTERN.match(raw)
        if h:
            current_heading = h.group(1).strip()
            continue
        if not _line_has_med_signal(raw):
            continue
        line = raw.strip()
        excerpt = f"{current_heading}: {line}" if current_heading else line
        if len(excerpt) <= max_chars:
            return excerpt
        return excerpt[: max(0, max_chars - 1)].rstrip() + "…"
    return None


def _line_has_med_signal(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if _ALLERGY_LINE_PATTERN.search(stripped):
        return True
    if _MED_UNIT_NEAR_DIGIT_PATTERN.search(stripped):
        return True
    if _DRUG_SUFFIX_PATTERN.search(stripped):
        return True
    if _MED_EVENT_VERB_PATTERN.search(stripped) and re.search(r"\d", stripped):
        return True
    return False


__all__ = ["find_currency_excerpt", "find_med_excerpt", "query_wants_excerpt"]
