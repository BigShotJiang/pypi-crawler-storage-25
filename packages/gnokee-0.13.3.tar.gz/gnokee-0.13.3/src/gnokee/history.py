"""src/gnokee/history.py — `gnokee.history_of` supersession-DAG public API (issue #123).

`gnokee_history_of` returns the bi-temporal supersession DAG for one
episode: forward + backward chain anchored at `episode_id`, every node
filtered by `(asserted_at <= as_of)` and `(valid_until > valid_at)` per
ADR-0004. Compact mode is the default LLM-facing shape (no episode
body). Verbatim mode attaches up to `top_k_bodies` bodies (newest by
`asserted_at`) capped at `per_body_char_cap` chars each. Encrypted
episodes always return `body_encrypted=True` + the ciphertext envelope —
gnokee NEVER returns plaintext for those.

The MCP tool wraps this surface 1:1 (no additional logic in
`src/gnokee/mcp.py`); the schema lives in `src/gnokee/mcp.py` and
forwards every parameter to `gnokee.history_of(...)`.

exports: history_of | HistoryPipeline
used_by: src/gnokee/mcp.py | src/gnokee/__init__.py
rules:   tenant_id on every read; tz-aware UTC; no auto-resolve;
         encrypted bodies return ciphertext only
agent:   claude-opus-4-7 | 2026-05-16 | issue #123 gnokee_history_of DAG
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

from gnokee.config import utc_now
from gnokee.errors import CorrectsChainError, ValidationError
from gnokee.models import (
    EncryptedEpisodeBody,
    HistoryEdge,
    HistoryNode,
    HistoryResponse,
    HistoryStatus,
)
from gnokee.storage.encrypted_body import EncryptedBodyStore
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore

log = logging.getLogger(__name__)

DEFAULT_MAX_NODES = 32
"""Storage chain-depth limit + DAG node bound. Matches
``MetadataStore._CHAIN_DEPTH_LIMIT``."""

DEFAULT_MAX_TOKENS = 800
"""Token budget for the assembled response. Larger than gnokee_query's
500 because verbatim mode legitimately carries more payload."""

DEFAULT_TOP_K_BODIES = 3
"""Maximum bodies attached in verbatim mode — newest by asserted_at."""

DEFAULT_PER_BODY_CHAR_CAP = 600
"""Per-body char cap mirroring ``retrieval.DEFAULT_PER_BODY_CHAR_CAP``."""


def _approx_tokens(text: str) -> int:
    """4-char-per-token estimate; matches ``retrieval._approx_tokens``."""
    return max(1, len(text) // 4)


def _estimate_node_tokens(node: HistoryNode) -> int:
    """Rough token budget for one HistoryNode JSON line.

    Compact base: ~40 tokens (UUIDs + timestamps + status + null fields).
    Add `rationale` and `episode_body` contributions when present.
    """
    base = 40
    if node.rationale:
        base += _approx_tokens(node.rationale)
    if node.episode_body:
        base += _approx_tokens(node.episode_body)
    return base


@dataclass
class HistoryPipeline:
    """Public surface for `gnokee.history_of(...)`.

    Two-store dependency: ``MetadataStore`` walks the supersession chain
    via recursive CTE, ``EncryptedBodyStore`` resolves ciphertext when a
    node's episode was ingested via the encrypted_body branch. No
    Graphiti dependency — supersession lineage lives entirely in
    Postgres per ADR-0004.
    """

    metadata: MetadataStore
    encrypted_body: EncryptedBodyStore

    async def history_of(
        self,
        *,
        tenant_id: str,
        episode_id: UUID,
        mode: str = "compact",
        as_of: datetime | None = None,
        valid_at: datetime | None = None,
        max_nodes: int = DEFAULT_MAX_NODES,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        top_k_bodies: int = DEFAULT_TOP_K_BODIES,
        per_body_char_cap: int = DEFAULT_PER_BODY_CHAR_CAP,
    ) -> HistoryResponse:
        if mode not in {"compact", "verbatim"}:
            raise ValidationError(f"history_of: mode must be 'compact' or 'verbatim', got {mode!r}")
        if max_nodes < 1:
            raise ValidationError("history_of: max_nodes must be >= 1")
        if max_tokens < 1:
            raise ValidationError("history_of: max_tokens must be >= 1")
        if top_k_bodies < 0:
            raise ValidationError("history_of: top_k_bodies must be >= 0")
        if per_body_char_cap < 1:
            raise ValidationError("history_of: per_body_char_cap must be >= 1")

        now = utc_now()
        effective_as_of = as_of if as_of is not None else now
        effective_valid_at = valid_at if valid_at is not None else now

        try:
            rows = await self.metadata.history_of(
                tenant_id=tenant_id,
                episode_uuid=episode_id,
                as_of=effective_as_of,
                valid_at=effective_valid_at,
                max_nodes=max_nodes,
            )
        except CorrectsChainError as exc:
            log.warning(
                "gnokee.history_of: cycle/depth-exceeded tenant=%s episode=%s: %s",
                tenant_id,
                episode_id,
                exc,
            )
            return HistoryResponse(
                nodes=[],
                edges=[],
                root=episode_id,
                head=episode_id,
                truncated=False,
                truncation_note=None,
                cycle_detected=True,
            )

        if not rows:
            raise ValidationError(
                f"history_of: episode {episode_id} not found for tenant "
                f"{tenant_id!r} (or filtered out by as_of/valid_at)"
            )

        # Storage returns dedup'd rows. Anchor visibility set on episode_uuid.
        visible_ids = {row.episode_uuid for row in rows}

        # Encrypted-body resolution (only when verbatim AND the node
        # would receive a body). Pre-compute the newest-N set so we don't
        # pay an EncryptedBodyStore round-trip for every node in compact
        # mode.
        verbatim = mode == "verbatim"
        body_node_ids: set[UUID] = set()
        if verbatim and top_k_bodies > 0:
            # Rows arrive from storage already sorted by asserted_at DESC.
            body_node_ids = {row.episode_uuid for row in rows[:top_k_bodies]}

        nodes: list[HistoryNode] = []
        for row in rows:
            superseded_by_in_set = row.superseded_by if row.superseded_by in visible_ids else None
            status: HistoryStatus = "active" if superseded_by_in_set is None else "superseded"

            episode_body: str | None = None
            body_encrypted = False
            encrypted_envelope: EncryptedEpisodeBody | None = None

            if verbatim and row.episode_uuid in body_node_ids:
                enc = await self.encrypted_body.get(
                    tenant_id=tenant_id,
                    episode_uuid=row.episode_uuid,
                )
                if enc is not None:
                    body_encrypted = True
                    encrypted_envelope = EncryptedEpisodeBody(
                        episode_uuid=enc.episode_uuid,
                        ciphertext=enc.ciphertext,
                        nonce=enc.nonce,
                        key_id=enc.key_id,
                    )
                elif row.content_text:
                    episode_body = row.content_text[:per_body_char_cap]

            nodes.append(
                HistoryNode(
                    episode_id=row.episode_uuid,
                    valid_at=row.valid_at,
                    asserted_at=row.asserted_at,
                    superseded_by=superseded_by_in_set,
                    status=status,
                    rationale=row.corrects_reason,
                    episode_body=episode_body,
                    body_encrypted=body_encrypted,
                    encrypted_body=encrypted_envelope,
                )
            )

        # Token-budget enforcement. Drop oldest first (preserve head).
        truncated_by_storage = len(rows) >= max_nodes
        truncated_by_tokens = False
        running_tokens = 0
        kept: list[HistoryNode] = []
        for node in nodes:  # asserted_at DESC — newest first
            cost = _estimate_node_tokens(node)
            if running_tokens + cost > max_tokens and kept:
                truncated_by_tokens = True
                break
            running_tokens += cost
            kept.append(node)
        nodes = kept

        kept_ids = {n.episode_id for n in nodes}
        edges = [
            HistoryEdge(from_id=n.episode_id, to_id=n.superseded_by)
            for n in nodes
            if n.superseded_by is not None and n.superseded_by in kept_ids
        ]

        # Head: node with no surviving outgoing edge → the chain terminus
        # within the kept set. Root: node with no incoming edge in the
        # kept set → oldest ancestor visible.
        targets = {e.to_id for e in edges}
        sources = {e.from_id for e in edges}
        head_candidates = [n for n in nodes if n.episode_id not in sources]
        root_candidates = [n for n in nodes if n.episode_id not in targets]
        head_uuid = head_candidates[0].episode_id if head_candidates else nodes[0].episode_id
        # nodes are newest-first; root = oldest kept = root_candidates[-1]
        root_uuid = root_candidates[-1].episode_id if root_candidates else nodes[-1].episode_id

        truncated = truncated_by_storage or truncated_by_tokens
        note: str | None = None
        if truncated_by_tokens and truncated_by_storage:
            note = f"DAG truncated by max_nodes={max_nodes} AND max_tokens={max_tokens}; oldest predecessors omitted."
        elif truncated_by_tokens:
            note = f"DAG truncated by max_tokens={max_tokens}; oldest predecessors omitted to fit the token budget."
        elif truncated_by_storage:
            note = (
                f"DAG truncated at max_nodes={max_nodes}; oldest predecessors "
                "omitted. Re-query with a later root episode_id to walk earlier "
                "history."
            )

        return HistoryResponse(
            nodes=nodes,
            edges=edges,
            root=root_uuid,
            head=head_uuid,
            truncated=truncated,
            truncation_note=note,
            cycle_detected=False,
        )


async def history_of(
    *,
    tenant_id: str,
    episode_id: UUID,
    metadata: MetadataStore,
    encrypted_body: EncryptedBodyStore,
    mode: str = "compact",
    as_of: datetime | None = None,
    valid_at: datetime | None = None,
    max_nodes: int = DEFAULT_MAX_NODES,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    top_k_bodies: int = DEFAULT_TOP_K_BODIES,
    per_body_char_cap: int = DEFAULT_PER_BODY_CHAR_CAP,
) -> HistoryResponse:
    """Functional wrapper around ``HistoryPipeline.history_of``."""
    pipeline = HistoryPipeline(metadata=metadata, encrypted_body=encrypted_body)
    return await pipeline.history_of(
        tenant_id=tenant_id,
        episode_id=episode_id,
        mode=mode,
        as_of=as_of,
        valid_at=valid_at,
        max_nodes=max_nodes,
        max_tokens=max_tokens,
        top_k_bodies=top_k_bodies,
        per_body_char_cap=per_body_char_cap,
    )


__all__ = [
    "DEFAULT_MAX_NODES",
    "DEFAULT_MAX_TOKENS",
    "DEFAULT_PER_BODY_CHAR_CAP",
    "DEFAULT_TOP_K_BODIES",
    "HistoryPipeline",
    "history_of",
]


# Silence unused-import warning — re-exported indirectly via models.
_ = EpisodeMetadataRow
