"""src/gnokee/med_query.py — Typed med-history read pipeline (ADR-0010).

Sibling of `lab_query` for the structured medication path. Where
`gnokee_recall` returns narrative facts (graphiti's edge-fact LLM
preserved drug names but stripped dates and dose numerals on Q8),
`gnokee_med_query` returns typed `med_record` rows so agents can answer
dose / start-date / current-meds questions without an extra
`gnokee_fact_provenance` round-trip.

Operations:
  - active     : currently-active meds at (`as_of`, `valid_at`); 1 row
                 per drug, latest visible event whose kind ≠ stop/allergy
  - history    : all visible events for a drug, asc valid_at, optional
                 date-range
  - allergies  : rows with event_kind='allergy'
  - switches   : rows with event_kind='switch'

Both bi-temporal half-pairs are mandatory on every read.

exports: MedQueryPipeline | MedQueryResponse | MedRowOut | med_query
used_by: src/gnokee/__init__.py | src/gnokee/mcp.py
rules:   tenant_id mandatory; both bi-temporal half-pairs always applied;
         history requires explicit drug_name
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0010
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from gnokee.citations import build_row_citations
from gnokee.config import utc_now
from gnokee.errors import ValidationError
from gnokee.models import Citation
from gnokee.storage.med import MedRecordRow, MedStore

MedOp = Literal["active", "history", "allergies", "switches"]

DEFAULT_HISTORY_LIMIT = 50
MAX_HISTORY_LIMIT = 500


@dataclass(frozen=True)
class MedRowOut:
    """Wire-shape for one med row in the MCP response."""

    episode_uuid: UUID
    drug_name: str
    drug_class: str | None
    dose_value: Decimal | None
    dose_unit: str | None
    frequency: str | None
    route: str | None
    event_kind: str
    reason: str | None
    valid_at: datetime
    asserted_at: datetime


@dataclass(frozen=True)
class MedQueryResponse:
    op: MedOp
    rows: list[MedRowOut] = field(default_factory=list)
    count: int = 0
    # ADR-0016 (issue #76) — per-claim bi-temporal citation envelope. One
    # entry per emitted row, keyed `c1`, `c2`, … in `rows` order. Additive
    # to the existing `rows[].episode_uuid` provenance handle.
    citations: dict[str, Citation] = field(default_factory=dict)


@dataclass
class MedQueryPipeline:
    """Bundles the MedStore for the orchestrator. One per process."""

    med: MedStore

    async def query(
        self,
        *,
        tenant_id: str,
        op: MedOp,
        drug_name: str | None,
        since: datetime | None,
        until: datetime | None,
        as_of: datetime,
        valid_at: datetime,
        limit: int,
    ) -> MedQueryResponse:
        if not tenant_id:
            raise ValidationError("tenant_id is required")
        if op not in {"active", "history", "allergies", "switches"}:
            raise ValidationError(f"unknown op: {op!r}")
        if since is not None and until is not None and since >= until:
            raise ValidationError("`since` must be < `until`")
        if limit < 1:
            raise ValidationError("limit must be >= 1")
        if limit > MAX_HISTORY_LIMIT:
            limit = MAX_HISTORY_LIMIT

        if op == "active":
            rows = await self.med.active(
                tenant_id=tenant_id,
                drug_name=drug_name,
                as_of=as_of,
                valid_at=valid_at,
            )
        elif op == "history":
            if not drug_name:
                raise ValidationError("op=history requires `drug_name`")
            rows = await self.med.history(
                tenant_id=tenant_id,
                drug_name=drug_name,
                since=since,
                until=until,
                as_of=as_of,
                valid_at=valid_at,
                limit=limit,
            )
        else:
            kind = "allergy" if op == "allergies" else "switch"
            rows = await self.med.by_event_kind(
                tenant_id=tenant_id,
                event_kind=kind,
                as_of=as_of,
                valid_at=valid_at,
                limit=limit,
            )

        rows_out = [_to_out(r) for r in rows]
        return MedQueryResponse(
            op=op,
            rows=rows_out,
            count=len(rows_out),
            citations=_row_citations(rows_out),
        )


def _to_out(row: MedRecordRow) -> MedRowOut:
    return MedRowOut(
        episode_uuid=row.episode_uuid,
        drug_name=row.drug_name,
        drug_class=row.drug_class,
        dose_value=row.dose_value,
        dose_unit=row.dose_unit,
        frequency=row.frequency,
        route=row.route,
        event_kind=row.event_kind,
        reason=row.reason,
        valid_at=row.valid_at,
        asserted_at=row.asserted_at,
    )


def _row_citations(rows: list[MedRowOut]) -> dict[str, Citation]:
    """Per-row citation envelope (ADR-0016 / issue #76).

    ``extracted_quote`` is ``None`` everywhere in v0.5 — the med pipeline
    does not yet fetch ``episode_metadata.extracted_quote``. Backfill
    arrives in a follow-up once the extraction stage records body spans.
    """
    return build_row_citations(
        rows=[(r.episode_uuid, r.valid_at, r.asserted_at) for r in rows],
        extracted_quotes=None,
    )


async def med_query(
    *,
    pipeline: MedQueryPipeline,
    tenant_id: str,
    op: MedOp,
    drug_name: str | None = None,
    since: datetime | None = None,
    until: datetime | None = None,
    as_of: datetime | None = None,
    valid_at: datetime | None = None,
    limit: int = DEFAULT_HISTORY_LIMIT,
) -> MedQueryResponse:
    return await pipeline.query(
        tenant_id=tenant_id,
        op=op,
        drug_name=drug_name,
        since=since,
        until=until,
        as_of=as_of or utc_now(),
        valid_at=valid_at or utc_now(),
        limit=limit,
    )


__all__ = [
    "DEFAULT_HISTORY_LIMIT",
    "MAX_HISTORY_LIMIT",
    "MedOp",
    "MedQueryPipeline",
    "MedQueryResponse",
    "MedRowOut",
    "med_query",
]
