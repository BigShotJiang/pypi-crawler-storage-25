"""src/gnokee/__init__.py — memory infrastructure for personal AI.

Bi-temporal facts, honest contradictions, autonomous maintenance,
verifiable forgetting. MCP-native, multi-tenant, multilingual.

v0.1 — minimum viable surface. See `docs/specs/v0.1.md`.

exports: ingest_episode | recall | fact_provenance | history_of | forget_episode | run_deferred_extraction | resume_ingest | EpisodeIn | IngestReceipt | RecallResponse | FactStatement | FactProvenance | ContradictionRef | DeferredExtractionReport | ExtractionFailure | EncryptedBody | EncryptedEpisodeBody | gnokee_query | QueryEnvelope | QueryResponse | HistoryNode | HistoryEdge | HistoryResponse | IngestJournalError
used_by: external consumers
rules:   public surface only here; impl lives under submodules
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
         claude-sonnet-4-6 | 2026-05-09 | issue #47 maintenance surface
         claude-opus-4-7 | 2026-05-11 | issue #72 / ADR-0013 gnokee_query envelope
         claude-opus-4-7 | 2026-05-16 | issue #123 history_of supersession DAG
         claude-opus-4-7 | 2026-05-16 | issue #122 ADR-0024 resume_ingest
         claude-opus-4-7 | 2026-05-19 | v0.11.3 forget_episode re-export (omur#598 Phase C)
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

from gnokee.forget import forget_episode
from gnokee.history import history_of
from gnokee.ingest import ingest_episode
from gnokee.maintenance import (
    DeferredExtractionReport,
    ExtractionFailure,
    resume_ingest,
    run_deferred_extraction,
)
from gnokee.models import (
    ContradictionRef,
    EncryptedBody,
    EncryptedEpisodeBody,
    EpisodeIn,
    FactProvenance,
    FactStatement,
    HistoryEdge,
    HistoryNode,
    HistoryResponse,
    IngestReceipt,
    RecallResponse,
    Sensitivity,
)
from gnokee.query import (
    QueryEnvelope,
    QueryResponse,
    gnokee_query,
)
from gnokee.retrieval import fact_provenance, recall
from gnokee.storage.journal import IngestJournalError

try:
    __version__ = _pkg_version("gnokee")
except PackageNotFoundError:
    # Editable install before metadata is built; only happens during a
    # fresh dev clone before the first `pip install -e .`.
    __version__ = "0+unknown"

__all__ = [
    "ContradictionRef",
    "DeferredExtractionReport",
    "EncryptedBody",
    "EncryptedEpisodeBody",
    "EpisodeIn",
    "ExtractionFailure",
    "FactProvenance",
    "FactStatement",
    "HistoryEdge",
    "HistoryNode",
    "HistoryResponse",
    "IngestJournalError",
    "IngestReceipt",
    "QueryEnvelope",
    "QueryResponse",
    "RecallResponse",
    "Sensitivity",
    "__version__",
    "fact_provenance",
    "forget_episode",
    "gnokee_query",
    "history_of",
    "ingest_episode",
    "recall",
    "resume_ingest",
    "run_deferred_extraction",
]
