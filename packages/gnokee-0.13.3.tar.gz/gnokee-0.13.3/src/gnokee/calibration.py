"""src/gnokee/calibration.py — onboarding-time embedding separation probe.

Consumers (noggin, Obsidian vault adapter, custom MCP clients) configure
per-source-type **etalons** at onboarding — short reference texts that
differentiate the kinds of records they intend to ingest (e.g. "lab
result", "med dose change", "wearable daily summary"). Those etalons
drive downstream classification + retrieval bias. If two etalons are not
well-separated in embedding space, the consumer biases the wrong
direction and never sees the failure mode until retrieval rankings degrade.

Raw cosine alone is noisy on bge-m3 (Q6 established this for the
TEI/Ollama parity check). **Mean-centered cosine** is a one-line
calibration probe that exposes weak prompts:

    raw_M[i, j]            = cosine(emb[i], emb[j])
    mean_centered_M[i, j]  = cosine(emb[i] - mean, emb[j] - mean)

For ``N`` etalons with maximal pairwise separation, the mean-centered
matrix approaches ``-1/(N-1)`` off-diagonal — e.g. ``-0.5`` for three
etalons, ``-0.33`` for four. Any pair whose mean-centered cosine is
**less negative than** ``warning_threshold`` (default ``-0.30``)
indicates the pair has too much shared signal after centroid removal —
surface a warning and ask the consumer to differentiate the prompts.

Pure-Python; numpy-only for the linear algebra. The helper accepts any
embedder satisfying :class:`EmbedFn` — production code passes the
``TEIClient.embed`` bound method; tests pass a deterministic fake. No
I/O beyond the embedder call.

exports: SeparationWarning | SeparationReport | check_etalon_separation | DEFAULT_WARNING_THRESHOLD
used_by: tests/unit/test_calibration.py | docs/integration_patterns.md
rules:   never raise on degenerate input (empty etalons → ValueError at boundary, never silent);
         numpy-only deps; no LLM; no network beyond the supplied embedder
agent:   claude-opus-4-7 | 2026-05-11 | issue #103 — onboarding separation health check
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field

import numpy as np

DEFAULT_WARNING_THRESHOLD = -0.30
"""Mean-centered cosine above this value flags a pair as weakly separated.

For ``N`` etalons with optimal separation the off-diagonal entries land
near ``-1/(N-1)``: ``-0.50`` for N=3, ``-0.33`` for N=4, ``-0.25`` for
N=5. ``-0.30`` catches all of the obvious mis-configurations without
flagging healthy 4+ etalon sets. Override via ``warning_threshold``
when calibrating for a larger N.
"""

EmbedFn = Callable[[list[str]], Awaitable[list[list[float]]]]
"""Minimal embedder contract — same shape as ``TEIClient.embed``.

Returns one vector per input text. Order MUST match the input order.
"""


@dataclass(frozen=True)
class SeparationWarning:
    """One weakly-separated pair surfaced by :func:`check_etalon_separation`.

    ``mean_centered_cosine`` is the load-bearing field — that is the
    signal the threshold compares against. ``raw_cosine`` is included
    so the consumer can sanity-check the magnitude (bge-m3 raw cosines
    are noisy, so the raw number alone is not actionable).
    """

    label_a: str
    label_b: str
    raw_cosine: float
    mean_centered_cosine: float


@dataclass(frozen=True)
class SeparationReport:
    """Output of :func:`check_etalon_separation`.

    ``raw_cosine_matrix`` and ``mean_centered_cosine_matrix`` are square,
    symmetric, indexed identically by ``labels``. Diagonals are always
    ``1.0`` for the raw matrix and ``1.0`` for the mean-centered matrix
    (self-cosine after self-mean removal is still 1).

    ``warnings`` is non-empty iff at least one off-diagonal mean-centered
    cosine sits above ``warning_threshold`` — call sites typically treat
    ``len(report.warnings) > 0`` as "halt onboarding, ask user to
    differentiate prompts".
    """

    labels: list[str]
    raw_cosine_matrix: list[list[float]]
    mean_centered_cosine_matrix: list[list[float]]
    warnings: list[SeparationWarning] = field(default_factory=list)
    warning_threshold: float = DEFAULT_WARNING_THRESHOLD

    def has_warnings(self) -> bool:
        return bool(self.warnings)


def _validate_etalons(etalons: list[tuple[str, str]]) -> None:
    if len(etalons) < 2:
        raise ValueError(
            "calibration needs at least two etalons; single-etalon configurations are not separable",
        )
    labels = [label for label, _ in etalons]
    if len(set(labels)) != len(labels):
        raise ValueError(f"duplicate etalon labels: {labels}")
    for label, text in etalons:
        if not isinstance(label, str) or not label.strip():
            raise ValueError("etalon labels must be non-empty strings")
        if not isinstance(text, str) or not text.strip():
            raise ValueError(f"etalon text for label {label!r} must be non-empty")


def _cosine_matrix(vectors: np.ndarray) -> np.ndarray:
    """Pairwise cosine of L2-normalised row vectors. Returns NxN matrix."""
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    # Guard against zero vectors so we never divide by zero — replaces with 1
    # so the resulting row is the zero vector and pairwise cosines come out 0.
    norms = np.where(norms == 0, 1.0, norms)
    normalised = vectors / norms
    matrix: np.ndarray = normalised @ normalised.T
    return matrix


async def check_etalon_separation(
    etalons: list[tuple[str, str]],
    embed: EmbedFn,
    *,
    warning_threshold: float = DEFAULT_WARNING_THRESHOLD,
) -> SeparationReport:
    """Probe pairwise separation of consumer-supplied onboarding etalons.

    ``etalons`` is a list of ``(label, text)`` pairs. Order is preserved
    in the returned matrices. Duplicate labels or empty text raises
    ``ValueError`` at the boundary — degenerate input is the consumer's
    bug, not ours.

    Embeds the etalons in one ``embed()`` call (consumers' onboarding
    sets are tiny; no batching needed). Computes raw + mean-centered
    cosine matrices. Surfaces a warning for any off-diagonal pair where
    ``mean_centered_cosine > warning_threshold``.

    Returns a :class:`SeparationReport`. Callers typically print the
    matrices for the operator's eye AND halt onboarding when
    ``report.has_warnings()``.
    """
    _validate_etalons(etalons)

    labels = [label for label, _ in etalons]
    texts = [text for _, text in etalons]
    raw_vectors = await embed(texts)
    if len(raw_vectors) != len(texts):
        raise RuntimeError(
            f"embedder returned {len(raw_vectors)} vectors for {len(texts)} texts",
        )

    vectors = np.asarray(raw_vectors, dtype=np.float64)
    if vectors.ndim != 2:
        raise RuntimeError(f"embedder returned {vectors.ndim}-D output; expected 2-D")

    raw_cos = _cosine_matrix(vectors)

    centroid = vectors.mean(axis=0, keepdims=True)
    centered = vectors - centroid
    mean_centered_cos = _cosine_matrix(centered)

    warnings: list[SeparationWarning] = []
    n = len(labels)
    for i in range(n):
        for j in range(i + 1, n):
            mc = float(mean_centered_cos[i, j])
            if mc > warning_threshold:
                warnings.append(
                    SeparationWarning(
                        label_a=labels[i],
                        label_b=labels[j],
                        raw_cosine=float(raw_cos[i, j]),
                        mean_centered_cosine=mc,
                    ),
                )

    return SeparationReport(
        labels=labels,
        raw_cosine_matrix=raw_cos.tolist(),
        mean_centered_cosine_matrix=mean_centered_cos.tolist(),
        warnings=warnings,
        warning_threshold=warning_threshold,
    )
