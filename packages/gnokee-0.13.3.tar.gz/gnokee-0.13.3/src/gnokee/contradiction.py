"""src/gnokee/contradiction.py — Q4 contradiction pipeline (ingest stage 7).

For each new fact F: cosine search EntityEdge.fact_embedding via Neo4j
vector index → top-K candidates ≥ threshold → gpt-4o-mini classifier →
{refinement, update, contradiction} written to `fact_contradiction`.
`unrelated` verdicts dropped per ADR-0008.

exports: detect_for_facts | DetectionResult
used_by: src/gnokee/ingest.py
rules:   ADR-0004 deliberate exception (fact-embedding cosine via Cypher); LLM degrade-tolerant
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

from gnokee.errors import GraphStoreError, LLMUnavailable
from gnokee.llm import OpenAIClient, _coerce_verdict, classify_contradiction
from gnokee.models import ContradictionRef, Verdict
from gnokee.storage.contradictions import ContradictionRow, ContradictionStore
from gnokee.storage.graph import GraphitiStore

log = logging.getLogger(__name__)

DEFAULT_TOP_K = 5
DEFAULT_THRESHOLD = 0.85


@dataclass(frozen=True)
class _Pair:
    a_uuid: UUID
    a_text: str
    a_valid_at: datetime
    b_uuid: UUID
    b_text: str
    b_valid_at: datetime
    verdict: Verdict


@dataclass(frozen=True)
class DetectionResult:
    contradicts: list[ContradictionRef]


async def detect_for_facts(
    *,
    tenant_id: str,
    new_facts: list[tuple[UUID, str, datetime, list[float]]],
    store: GraphitiStore,
    contradictions: ContradictionStore,
    llm: OpenAIClient,
    detected_at: datetime,
    top_k: int = DEFAULT_TOP_K,
    threshold: float = DEFAULT_THRESHOLD,
) -> DetectionResult:
    """Run Q4 over `new_facts`. Each tuple = (fact_uuid, fact_text, valid_at, embedding).

    On LLM unavailability: log + return empty contradicts (degraded mode per spec).
    """
    refs: list[ContradictionRef] = []
    pairs: list[_Pair] = []

    for fact_uuid, fact_text, fact_valid_at, embedding in new_facts:
        try:
            candidates = await store.cosine_search_facts(
                tenant_id=tenant_id,
                embedding=embedding,
                top_k=top_k,
                threshold=threshold,
                exclude_fact_uuid=fact_uuid,
            )
        except GraphStoreError as exc:
            log.warning("contradiction cosine search failed: %s", exc)
            continue

        for cand in candidates:
            try:
                label = await classify_contradiction(
                    client=llm,
                    a_text=fact_text,
                    b_text=cand.fact_text,
                )
            except LLMUnavailable as exc:
                # Per-pair degraded mode: log and continue with remaining
                # candidates instead of abandoning all subsequent classifications.
                log.warning("contradiction classifier degraded on pair (%s, %s): %s", fact_uuid, cand.fact_uuid, exc)
                continue
            verdict = _coerce_verdict(label)
            if verdict is None:
                continue
            pairs.append(
                _Pair(
                    a_uuid=fact_uuid,
                    a_text=fact_text,
                    a_valid_at=fact_valid_at,
                    b_uuid=cand.fact_uuid,
                    b_text=cand.fact_text,
                    b_valid_at=cand.valid_at,
                    verdict=verdict,
                )
            )

    for p in pairs:
        await contradictions.write(
            ContradictionRow(
                tenant_id=tenant_id,
                fact_uuid_a=p.a_uuid,
                fact_uuid_b=p.b_uuid,
                verdict=p.verdict,
                detected_at=detected_at,
                summary_a=_truncate(p.a_text),
                summary_b=_truncate(p.b_text),
            )
        )
        refs.append(
            ContradictionRef(
                fact_uuid=p.b_uuid,
                verdict=p.verdict,
                summary=_truncate(p.b_text),
                valid_at=p.b_valid_at,
            )
        )

    return DetectionResult(contradicts=refs)


def _truncate(text: str, limit: int = 200) -> str:
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "…"


__all__ = ["DEFAULT_THRESHOLD", "DEFAULT_TOP_K", "DetectionResult", "detect_for_facts"]
