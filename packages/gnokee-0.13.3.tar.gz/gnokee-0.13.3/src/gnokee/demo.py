"""src/gnokee/demo.py — M5 quickstart: ingest 5 facts, recall, surface contradictions.

Run: `python -m gnokee.demo` (after `make up && make migrate`).

exports: main
used_by: end users via `make demo`
rules:   reads GNOKEE_TENANT_DEFAULT only here + integration tests; never in src/gnokee proper
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone

from gnokee.bootstrap import build_app, shutdown_app
from gnokee.config import Settings
from gnokee.ingest import ingest_episode
from gnokee.retrieval import recall
from gnokee.storage.migrate import apply as apply_migrations

log = logging.getLogger(__name__)


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


SEED_EPISODES: list[tuple[str, datetime]] = [
    ("Alice moved to Berlin in June 2019.", _utc(2019, 6, 1)),
    ("Alice works at Stripe as a senior engineer.", _utc(2022, 3, 15)),
    ("Alice prefers Postgres for new projects.", _utc(2023, 9, 1)),
    ("Alice now uses DuckDB for ad-hoc analytics.", _utc(2024, 11, 10)),
    ("Alice moved to Lisbon in early 2025.", _utc(2025, 2, 1)),
]


async def _run() -> None:
    settings = Settings()
    assert settings.pg_dsn is not None
    tenant = settings.tenant_default

    print("→ applying migrations …")
    applied = await apply_migrations(settings.pg_dsn)
    print(f"  applied: {applied or 'no pending migrations'}")

    print("→ building app …")
    app = await build_app(settings)
    try:
        print(f"→ ingesting {len(SEED_EPISODES)} episodes for tenant={tenant!r} …")
        for content, valid_at in SEED_EPISODES:
            receipt = await ingest_episode(
                pipeline=app.ingest,
                tenant_id=tenant,
                content=content,
                valid_at=valid_at,
                sensitive="public",
            )
            print(
                f"  episode {receipt.episode_uuid}  facts={len(receipt.created_fact_uuids)}  contradicts={len(receipt.contradicts)}"
            )

        print("→ recall: 'where does Alice live?'")
        response = await recall(
            pipeline=app.recall,
            tenant_id=tenant,
            text="where does Alice live?",
            top_k=10,
        )
        print(f"  candidate_count={response.candidate_count}  truncated={response.truncated}")
        for f in response.facts:
            print(f"  • {f.text}")
            for c in f.contradicts:
                print(f"      ↪ contradicts ({c.verdict}): {c.summary}")
    finally:
        await shutdown_app(app)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s :: %(message)s")
    asyncio.run(_run())


if __name__ == "__main__":
    main()
