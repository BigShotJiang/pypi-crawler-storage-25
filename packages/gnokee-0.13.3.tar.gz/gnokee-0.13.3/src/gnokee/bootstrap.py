"""src/gnokee/bootstrap.py — Wire Settings → Graphiti, asyncpg pool, pipelines.

Single construction site for the v0.1 process. MCP server, demo script,
and integration tests all call `build_app(settings)` to get a ready
`App` with shared connection state.

exports: class App | build_app | shutdown_app
used_by: src/gnokee/mcp.py | src/gnokee/demo.py | tests/integration/*
rules:   one Graphiti per process; pool size is conservative (4); TEI = embed only
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import asyncpg
from graphiti_core import Graphiti
from graphiti_core.embedder.client import EmbedderClient, EmbedderConfig
from graphiti_core.llm_client.config import LLMConfig
from graphiti_core.llm_client.openai_client import OpenAIClient as GraphitiOpenAIClient
from openai import AsyncOpenAI

from gnokee.config import Settings
from gnokee.embeddings import EMBED_DIM, TEIClient
from gnokee.errors import EmbeddingsUnavailable, ValidationError
from gnokee.fact_history import FactHistoryPipeline
from gnokee.history import HistoryPipeline
from gnokee.ingest import IngestPipeline
from gnokee.lab_query import LabQueryPipeline
from gnokee.llm import OpenAIClient
from gnokee.med_query import MedQueryPipeline
from gnokee.retrieval import RecallPipeline
from gnokee.storage.contradictions import ContradictionStore
from gnokee.storage.encrypted_body import EncryptedBodyStore
from gnokee.storage.fact_revision import FactRevisionStore
from gnokee.storage.graph import GraphitiStore
from gnokee.storage.journal import IngestJournal
from gnokee.storage.key_resolver import KeyResolver, NullKeyResolver, build_key_resolver
from gnokee.storage.lab import LabStore
from gnokee.storage.med import MedStore
from gnokee.storage.metadata import MetadataStore
from gnokee.storage.vector import PgVectorStore
from gnokee.tracing import init_tracing, shutdown_tracing
from gnokee.wiki_export import WikiExportPipeline

log = logging.getLogger(__name__)


class TEIEmbedder(EmbedderClient):
    """Adapter so Graphiti's embedder interface uses our TEI client."""

    def __init__(self, tei: TEIClient) -> None:
        self._tei = tei
        self.config = EmbedderConfig(embedding_dim=EMBED_DIM)

    async def create(  # type: ignore[override]
        self,
        input_data: str | list[str],
    ) -> list[float]:
        """Per Graphiti's `EmbedderClient.create` contract: returns a single vector.

        Reject multi-element list inputs loudly — silent truncation would drop
        embeddings for entity names beyond the first one. Batch callers must
        use `create_batch`.
        """
        if isinstance(input_data, str):
            return await self._tei.embed_one(input_data)
        if isinstance(input_data, list):
            if not input_data:
                return []
            if not isinstance(input_data[0], str):
                raise EmbeddingsUnavailable("TEIEmbedder.create only supports str / list[str]")
            if len(input_data) > 1:
                raise EmbeddingsUnavailable(
                    f"TEIEmbedder.create received list of {len(input_data)}; use create_batch for multi-text",
                )
            return await self._tei.embed_one(input_data[0])
        raise EmbeddingsUnavailable("TEIEmbedder.create only supports str / list[str]")

    async def create_batch(self, input_data_list: list[str]) -> list[list[float]]:
        if not input_data_list:
            return []
        return await self._tei.embed(input_data_list)


@dataclass
class App:
    settings: Settings
    pool: asyncpg.Pool
    graphiti: Graphiti
    graph_store: GraphitiStore
    vector_store: PgVectorStore
    metadata_store: MetadataStore
    contradiction_store: ContradictionStore
    fact_revision_store: FactRevisionStore
    lab_store: LabStore
    med_store: MedStore
    encrypted_body_store: EncryptedBodyStore
    journal: IngestJournal
    tei: TEIClient
    llm: OpenAIClient | None
    key_resolver: KeyResolver = field(default_factory=NullKeyResolver)
    ingest: IngestPipeline = field(init=False)
    recall: RecallPipeline = field(init=False)
    lab_query: LabQueryPipeline = field(init=False)
    med_query: MedQueryPipeline = field(init=False)
    wiki_export: WikiExportPipeline = field(init=False)
    history: HistoryPipeline = field(init=False)
    fact_history: FactHistoryPipeline = field(init=False)

    def __post_init__(self) -> None:
        self.ingest = IngestPipeline(
            pool=self.pool,
            graph=self.graph_store,
            vector=self.vector_store,
            metadata=self.metadata_store,
            contradictions=self.contradiction_store,
            lab=self.lab_store,
            med=self.med_store,
            encrypted_body=self.encrypted_body_store,
            embeddings=self.tei,
            journal=self.journal,
            fact_revisions=self.fact_revision_store,
            llm=self.llm,
            contradiction_enabled=self.llm is not None,
            extraction_instructions=self.settings.graphiti_extraction_instructions,
        )
        self.recall = RecallPipeline(
            graph=self.graph_store,
            vector=self.vector_store,
            metadata=self.metadata_store,
            contradictions=self.contradiction_store,
            encrypted_body=self.encrypted_body_store,
            embeddings=self.tei,
        )
        self.lab_query = LabQueryPipeline(lab=self.lab_store)
        self.med_query = MedQueryPipeline(med=self.med_store)
        self.wiki_export = WikiExportPipeline(
            graph=self.graph_store,
            metadata=self.metadata_store,
            pool=self.pool,
            fact_revisions=self.fact_revision_store,
        )
        self.history = HistoryPipeline(
            metadata=self.metadata_store,
            encrypted_body=self.encrypted_body_store,
        )
        self.fact_history = FactHistoryPipeline(
            pool=self.pool,
            store=self.fact_revision_store,
            graph=self.graph_store,
        )


def _require_llm_credentials(settings: Settings) -> None:
    """Refuse to boot when api.openai.com is the target with no API key.

    The default ``openai_base_url`` is ``api.openai.com/v1``. Without a key
    the ``or "unused"`` fallback below would silently construct an
    ``AsyncOpenAI`` that 401s on every graphiti extraction call mid-ingest.
    Self-hosted shapes (litellm / ollama / vllm) keep working because they
    point ``base_url`` somewhere else.
    """
    base = settings.openai_base_url.rstrip("/").lower()
    targets_openai_cloud = base.endswith("api.openai.com/v1") or base.endswith("api.openai.com")
    if targets_openai_cloud and not settings.openai_api_key:
        raise ValidationError(
            "GNOKEE_OPENAI_API_KEY is empty but GNOKEE_OPENAI_BASE_URL targets "
            "api.openai.com. Set the key or point base_url at a self-hosted "
            "endpoint (litellm / ollama / vllm OpenAI-compat)."
        )


async def _probe_embedder(tei: TEIClient, settings: Settings) -> None:
    """Issue #238 — boot-time embedder probe.

    Catches wrong-model-behind-URL before any ingest accepts traffic. The
    per-vector dim guard at ``embeddings.py:115`` stays as belt+braces at
    runtime; this gate fires once, at process start, when
    ``GNOKEE_EMBED_PROBE=true``.

    No-op when the env flag is off so existing deploys are bit-for-bit
    unchanged. Probe text is a fixed throwaway literal; bge-m3 is
    stateless so the embedding is discarded immediately. Cold-TEI race
    (model still loading on first ``/embed`` call) surfaces as
    ``EmbeddingsUnavailable`` through ``TEIClient.embed`` — fail-fast is
    correct (gnokee depends on a ready embedder).
    """
    if not settings.embed_probe:
        return
    probe_vector = await tei.embed_one("gnokee embedder probe")
    if len(probe_vector) != EMBED_DIM:
        raise EmbeddingsUnavailable(
            f"GNOKEE_EMBED_PROBE: embedder at {settings.embed_base_url} "
            f"returned dim {len(probe_vector)}; expected {EMBED_DIM} "
            f"(bge-m3). Check GNOKEE_EMBED_MODEL / GNOKEE_EMBED_BASE_URL.",
        )
    log.info(
        "gnokee.bootstrap: embed probe OK dim=%d url=%s model=%s",
        EMBED_DIM,
        settings.embed_base_url,
        settings.embed_model,
    )


async def build_app(settings: Settings, *, bootstrap_indices: bool = True) -> App:
    """Construct shared connections + pipelines."""
    assert settings.pg_dsn is not None  # resolved by Settings.model_validator
    assert settings.embed_base_url is not None
    _require_llm_credentials(settings)
    # Tracing first so any spans emitted from build_app itself (graphiti
    # index bootstrap, pool warmup) land on the right TracerProvider.
    init_tracing(
        service_name=settings.otel_service_name,
        endpoint=settings.otel_endpoint,
        enabled=settings.otel_enabled,
    )
    pool = await asyncpg.create_pool(
        settings.pg_dsn,
        min_size=1,
        max_size=4,
    )
    if pool is None:  # pragma: no cover
        raise RuntimeError("asyncpg.create_pool returned None")

    tei = TEIClient(
        settings.embed_base_url,
        model=settings.embed_model,
        api_key=settings.embed_api_key,
    )
    embedder = TEIEmbedder(tei)
    # Issue #238 — boot-time embedder probe (opt-in via GNOKEE_EMBED_PROBE).
    await _probe_embedder(tei, settings)
    # Issue #235 — graphiti_llm_model defaults to llm_model when unset
    # (resolved in Settings.model_validator). Operators with cross-lingual
    # tenants override it independently while keeping the cheap classifier.
    assert settings.graphiti_llm_model is not None  # resolved by validator
    llm_config = LLMConfig(
        api_key=settings.openai_api_key or "unused",
        base_url=settings.openai_base_url,
        model=settings.graphiti_llm_model,
        temperature=0,
    )
    openai_async = AsyncOpenAI(
        base_url=settings.openai_base_url,
        api_key=settings.openai_api_key or "unused",
    )
    graphiti_llm = GraphitiOpenAIClient(config=llm_config, client=openai_async)

    # Issue #240 — gnokee owns retrieval (ADR-0004); we never call any
    # Graphiti search path that would invoke `cross_encoder`. Omit the
    # explicit `OpenAIRerankerClient` wiring so we don't construct a
    # dead client. Graphiti instantiates its own default reranker
    # internally, but it stays dormant — no API call is made.
    graphiti = Graphiti(
        uri=settings.neo4j_uri,
        user=settings.neo4j_user,
        password=settings.neo4j_password,
        embedder=embedder,
        llm_client=graphiti_llm,
    )
    graph_store = GraphitiStore(graphiti)
    if bootstrap_indices:
        # #215: keep the HNSW dim pinned to the same EMBED_DIM the rest of
        # the pipeline uses. Threaded as a kwarg so storage.graph stays
        # off the embeddings module (tach contract).
        await graph_store.bootstrap_indices(embed_dim=EMBED_DIM)

    vector_store = PgVectorStore(pool)
    metadata_store = MetadataStore(pool)
    contradiction_store = ContradictionStore(pool)
    fact_revision_store = FactRevisionStore()
    lab_store = LabStore(pool)
    med_store = MedStore(pool)
    encrypted_body_store = EncryptedBodyStore(pool)
    journal = IngestJournal(pool)
    key_resolver = build_key_resolver(settings)

    # Issue #228: construct the contradiction classifier whenever an
    # endpoint is configured, not only when an API key is set. Self-hosted
    # OpenAI-compatible endpoints (vLLM, llama.cpp, Ollama, litellm) often
    # accept an empty / dummy key; gating on the key silently disabled
    # contradiction detection for the entire self-hosted matrix. Cloud
    # misconfig (api.openai.com without a key) is rejected upstream by
    # `_require_llm_credentials`, so reaching here with an empty key means
    # the caller is intentionally pointed at a self-hosted endpoint.
    llm: OpenAIClient | None = OpenAIClient(
        base_url=settings.openai_base_url,
        api_key=settings.openai_api_key,
        model=settings.llm_model,
    )

    return App(
        settings=settings,
        pool=pool,
        graphiti=graphiti,
        graph_store=graph_store,
        vector_store=vector_store,
        metadata_store=metadata_store,
        contradiction_store=contradiction_store,
        fact_revision_store=fact_revision_store,
        lab_store=lab_store,
        med_store=med_store,
        encrypted_body_store=encrypted_body_store,
        journal=journal,
        tei=tei,
        llm=llm,
        key_resolver=key_resolver,
    )


async def shutdown_app(app: App) -> None:
    try:
        await app.graphiti.close()  # type: ignore[no-untyped-call]
    except Exception:  # pragma: no cover
        log.exception("graphiti close failed")
    try:
        await app.pool.close()
    except Exception:  # pragma: no cover
        log.exception("pool close failed")
    shutdown_tracing()


__all__ = ["App", "TEIEmbedder", "build_app", "shutdown_app"]
