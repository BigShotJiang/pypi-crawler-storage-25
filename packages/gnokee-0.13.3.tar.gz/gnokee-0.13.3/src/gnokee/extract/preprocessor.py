"""src/gnokee/extract/preprocessor.py — Top-level pre-extraction pass.

Runs all rules and appends a `Derived facts:` block to the body. Each rule
runs inside try/except so a single rule failure cannot block ingest.

exports: augment_for_extraction
used_by: src/gnokee/extract/__init__.py
rules:   pure function; never raises; original `content` is always a prefix
         of the returned string
agent:   claude-opus-4-7 | 2026-05-08 | v0.1.1
"""

from __future__ import annotations

import logging
from collections.abc import Callable

from gnokee.extract.rules.currency_anchor import extract as _extract_currency_anchors
from gnokee.extract.rules.identifier import extract as _extract_identifiers
from gnokee.extract.rules.med_event import extract as _extract_med_events
from gnokee.extract.rules.ranked_list import extract as _extract_ranked
from gnokee.extract.rules.table_amount import extract as _extract_table_amounts

log = logging.getLogger(__name__)

_DERIVED_HEADER = "\n\n---\nDerived facts:\n"


def augment_for_extraction(content: str) -> str:
    """Return content + derived sentences.

    `content` unchanged if empty or no rules fire.
    """
    if not content:
        return content

    rules: list[tuple[str, Callable[[str], list[str]]]] = [
        ("identifier", _extract_identifiers),
        ("ranked_list", _extract_ranked),
        ("table_amount", _extract_table_amounts),
        ("currency_anchor", _extract_currency_anchors),
        ("med_event", _extract_med_events),
    ]
    derived: list[str] = []
    for name, fn in rules:
        try:
            derived.extend(fn(content))
        except Exception as exc:
            log.warning("preprocessor rule %s failed: %s", name, exc)

    if not derived:
        return content
    bullets = "\n".join(f"- {s}" for s in derived)
    return content + _DERIVED_HEADER + bullets + "\n"


__all__ = ["augment_for_extraction"]
