"""src/gnokee/extract/clinical/lab_parser.py — Markdown lab-panel parser.

Recognises the bullet shape that dominates the Q7 corpus and the v0.1
clinical write path:

    - Analyte: value unit (ref: low-high)                         # plain
    - Potassium: 3.4 mmol/L (ref: 3.5-5.0) — slightly LOW          # flagged
    - Potassium: 2.8 mmol/L (ref: 3.5-5.0) **LOW — critical**      # critical
    - Hemoglobin: 14.2 g/dL (ref: 13.5-17.5)                       # ratio unit
    - WBC: 6.8 ×10^9/L (ref: 4.0-11.0)                             # exotic unit
    - Hematocrit: 42.1 % (ref: 39-50)                              # percent

Output: list[LabRow] with analyte / value_numeric / unit / ref-range /
abnormal flag fields populated. Caller (`gnokee.ingest`) wraps these
with the episode's tenant / episode_uuid / valid_at / asserted_at to
write `lab_record` rows.

exports: LabRow | parse_labs
used_by: src/gnokee/extract/clinical/__init__.py
rules:   pure function; never raises; bullet-line scan only — no LLM
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0009
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation

_BULLET_LINE = re.compile(
    r"""
    ^\s*-\s+                                # bullet
    (?P<analyte>[A-Za-z][A-Za-z0-9 ()/+-]*?) # analyte name (greedy stops at colon)
    \s*:\s+                                 # separator
    (?P<value>\d+(?:\.\d+)?)                # numeric value
    \s*
    (?P<unit>[^\s(]+(?:\s*[\^\d]+/?\w+)?)?  # unit token (allow exotic shapes)  # noqa: RUF001
    \s*
    (?:\(\s*ref:\s*                         # ref-range block (optional)
        (?P<lo>\d+(?:\.\d+)?)\s*-\s*
        (?P<hi>\d+(?:\.\d+)?)\s*\)
    )?
    (?P<rest>.*)$                           # tail — abnormal flag lives here
    """,
    re.VERBOSE,
)

_FLAG_RULES: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"\bcritical\b", re.IGNORECASE), "C"),
    (re.compile(r"\b(?:LOW|low)\b"), "L"),
    (re.compile(r"\b(?:HIGH|high)\b"), "H"),
    (re.compile(r"\bL\b"), "L"),
    (re.compile(r"\bH\b"), "H"),
)

MAX_ROWS_PER_DOC = 200


@dataclass(frozen=True)
class LabRow:
    """One parsed lab analyte. Temporal + tenant fields filled by caller."""

    analyte: str
    value_numeric: Decimal | None
    value_text: str | None
    unit: str | None
    ref_range_low: Decimal | None
    ref_range_high: Decimal | None
    abnormal_flag: str | None  # "L" / "H" / "C" / "N" / None


def parse_labs(content: str) -> list[LabRow]:
    """Return structured lab rows from a markdown panel body."""
    if not content:
        return []
    out: list[LabRow] = []
    seen: set[tuple[str, str | None]] = set()
    for raw in content.splitlines():
        if len(out) >= MAX_ROWS_PER_DOC:
            break
        m = _BULLET_LINE.match(raw)
        if m is None:
            continue
        analyte = m.group("analyte").strip()
        if not analyte or analyte.lower() in {"ref", "notes"}:
            continue
        value_str = m.group("value")
        value_num: Decimal | None
        try:
            value_num = Decimal(value_str)
        except InvalidOperation:  # pragma: no cover — regex guards numeric
            value_num = None
        unit_token = m.group("unit")
        unit = unit_token.strip() if unit_token else None
        # Strip trailing punctuation that the unit regex may have absorbed.
        if unit:
            unit = unit.rstrip(",;.")
            if not unit:
                unit = None

        lo_str = m.group("lo")
        hi_str = m.group("hi")
        try:
            ref_lo = Decimal(lo_str) if lo_str else None
            ref_hi = Decimal(hi_str) if hi_str else None
        except InvalidOperation:  # pragma: no cover
            ref_lo = ref_hi = None

        flag = _abnormal_flag(m.group("rest") or "")
        # Dedupe within the same panel (same analyte at same value text).
        key = (analyte.lower(), value_str)
        if key in seen:
            continue
        seen.add(key)
        out.append(
            LabRow(
                analyte=analyte,
                value_numeric=value_num,
                value_text=None,
                unit=unit,
                ref_range_low=ref_lo,
                ref_range_high=ref_hi,
                abnormal_flag=flag,
            ),
        )
    return out


def _abnormal_flag(rest: str) -> str | None:
    if not rest:
        return None
    for pattern, flag in _FLAG_RULES:
        if pattern.search(rest):
            return flag
    return None


__all__ = ["MAX_ROWS_PER_DOC", "LabRow", "parse_labs"]
