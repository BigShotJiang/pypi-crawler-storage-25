"""src/gnokee/extract/clinical/med_parser.py — Medication-event parser.

Sibling of `lab_parser`. Recognises the medication-event prose shapes
that dominate the Q8 corpus and the v0.1 clinical write path:

    Started Lisinopril 10 mg PO daily for stage-1 hypertension.
    Increased Lisinopril from 10 mg to 20 mg PO daily.
    Discontinued Lisinopril 20 mg today.
    Stopped Potassium Chloride 20 mEq daily ...
    Allergy documented: Penicillin — moderate reaction ...

Output: list[MedRow] with drug_name / dose / event_kind populated.
Caller (`gnokee.ingest`) attaches tenant / episode_uuid / valid_at /
asserted_at and writes `med_record` rows. The verbose `med_event`
preprocessor rule (`extract/rules/med_event.py`) continues to emit
derived sentences for graphiti's narrative half — this parser is
strictly the structured counterpart.

exports: MedRow | parse_meds
used_by: src/gnokee/extract/clinical/__init__.py
rules:   pure function; never raises; sentence-boundary scan only — no LLM
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0010
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Literal

EventKind = Literal[
    "start",
    "increase",
    "decrease",
    "stop",
    "switch",
    "allergy",
    "documented",
]

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+|\n+")

_DRUG = r"(?P<drug>[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)?)"
_DOSE_VALUE = r"(?P<dose_value>\d+(?:\.\d+)?)"
_DOSE_UNIT = r"(?P<dose_unit>mg|mcg|mEq|mL|IU|g)"
_DOSE_FROM_VALUE = r"(?P<from_value>\d+(?:\.\d+)?)"
_DOSE_FROM_UNIT = r"(?P<from_unit>mg|mcg|mEq|mL|IU|g)?"
_DOSE_TO_VALUE = r"(?P<to_value>\d+(?:\.\d+)?)"
_DOSE_TO_UNIT = r"(?P<to_unit>mg|mcg|mEq|mL|IU|g)"
_FREQ = r"(?:daily|BID|TID|QID|QHS|PRN|weekly|monthly)"
_ROUTE = r"(?:PO|IV|IM|SC|SQ|topical)"

_START_VERBS = {"started", "added", "continuing"}
_STOP_VERBS = {"stopped", "discontinued", "held", "holding"}
_SWITCH_VERBS = {"switched"}

_VERB_DRUG_DOSE = re.compile(
    rf"^\s*(?P<verb>started|stopped|discontinued|added|switched|continuing|holding|held)\s+"
    rf"{_DRUG}"
    rf"(?:\s+{_DOSE_VALUE}\s*{_DOSE_UNIT})?"
    rf"(?:\s+(?P<route>{_ROUTE}))?"
    rf"(?:\s+(?P<freq>{_FREQ}))?",
    re.IGNORECASE,
)
_DOSE_CHANGE = re.compile(
    rf"^\s*(?P<verb>increased|decreased|raised|lowered|titrated)\s+{_DRUG}\s+"
    rf"(?:from\s+{_DOSE_FROM_VALUE}\s*{_DOSE_FROM_UNIT}\s+)?"
    rf"to\s+{_DOSE_TO_VALUE}\s*{_DOSE_TO_UNIT}"
    rf"(?:\s+(?P<route>{_ROUTE}))?"
    rf"(?:\s+(?P<freq>{_FREQ}))?",
    re.IGNORECASE,
)
_ALLERGY = re.compile(rf"^\s*Allergy\s+documented:\s*{_DRUG}", re.IGNORECASE)

_INCREASE_VERBS = {"increased", "raised", "titrated"}

MAX_ROWS_PER_DOC = 30


@dataclass(frozen=True)
class MedRow:
    """One parsed medication event. Temporal + tenant fields filled by caller."""

    drug_name: str
    dose_value: Decimal | None
    dose_unit: str | None
    frequency: str | None
    route: str | None
    event_kind: EventKind
    reason: str | None  # free-text, optional


def parse_meds(content: str) -> list[MedRow]:
    """Return structured medication rows from prose body."""
    if not content:
        return []
    out: list[MedRow] = []
    seen: set[tuple[str, str, str | None]] = set()
    for raw in _SENTENCE_SPLIT.split(content):
        if len(out) >= MAX_ROWS_PER_DOC:
            break
        sentence = raw.strip()
        if not sentence:
            continue

        m_allergy = _ALLERGY.match(sentence)
        if m_allergy:
            row = MedRow(
                drug_name=m_allergy.group("drug").strip(),
                dose_value=None,
                dose_unit=None,
                frequency=None,
                route=None,
                event_kind="allergy",
                reason=None,
            )
            _emit(row, seen, out)
            continue

        m_change = _DOSE_CHANGE.match(sentence)
        if m_change:
            verb = m_change.group("verb").lower()
            event_kind: EventKind = "increase" if verb in _INCREASE_VERBS else "decrease"
            dose_value = _to_decimal(m_change.group("to_value"))
            dose_unit = m_change.group("to_unit")
            row = MedRow(
                drug_name=m_change.group("drug").strip(),
                dose_value=dose_value,
                dose_unit=dose_unit,
                frequency=m_change.group("freq"),
                route=m_change.group("route"),
                event_kind=event_kind,
                reason=None,
            )
            _emit(row, seen, out)
            continue

        m_verb = _VERB_DRUG_DOSE.match(sentence)
        if m_verb:
            verb = m_verb.group("verb").lower()
            kind: EventKind
            if verb in _START_VERBS:
                kind = "start"
            elif verb in _STOP_VERBS:
                kind = "stop"
            elif verb in _SWITCH_VERBS:
                kind = "switch"
            else:
                kind = "documented"
            dose_value = _to_decimal(m_verb.group("dose_value"))
            dose_unit = m_verb.group("dose_unit")
            row = MedRow(
                drug_name=m_verb.group("drug").strip(),
                dose_value=dose_value,
                dose_unit=dose_unit,
                frequency=m_verb.group("freq"),
                route=m_verb.group("route"),
                event_kind=kind,
                reason=None,
            )
            _emit(row, seen, out)

    return out


def _to_decimal(s: str | None) -> Decimal | None:
    if s is None:
        return None
    try:
        return Decimal(s)
    except InvalidOperation:  # pragma: no cover
        return None


def _emit(row: MedRow, seen: set[tuple[str, str, str | None]], out: list[MedRow]) -> None:
    key = (row.drug_name.lower(), row.event_kind, str(row.dose_value) if row.dose_value else None)
    if key in seen or len(out) >= MAX_ROWS_PER_DOC:
        return
    seen.add(key)
    out.append(row)


__all__ = ["MAX_ROWS_PER_DOC", "EventKind", "MedRow", "parse_meds"]
