"""src/gnokee/extract/clinical/ — Structured clinical-data parsers.

Deterministic markdown-aware parsers that lift structured rows out of the
clinical episode bodies that ADR-0009 (labs) and ADR-0010 (meds) decided
to off-ramp from graphiti's edge-fact extraction. Parsers are pure (no
IO, no LLM) and never raise — failures degrade silently to "no row" so
ingest is never blocked.

exports: parse_labs | parse_meds | LabRow | MedRow
used_by: src/gnokee/ingest.py
rules:   pure functions; tenant_id / temporal axes filled by caller;
         no LLM, no IO, no exceptions propagate
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0009 / ADR-0010
"""

from __future__ import annotations

from gnokee.extract.clinical.lab_parser import LabRow, parse_labs
from gnokee.extract.clinical.med_parser import MedRow, parse_meds

__all__ = ["LabRow", "MedRow", "parse_labs", "parse_meds"]
