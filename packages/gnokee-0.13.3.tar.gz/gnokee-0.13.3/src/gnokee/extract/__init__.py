"""src/gnokee/extract/ — Pre-extraction preprocessor.

Deterministic markdown-aware pass that augments episode body with derived
sentences before graphiti.add_episode runs entity extraction. Closes
v0.1.1 issues #2 (numbered identifiers), #3 (ranked priority), #4
(markdown-table currency amounts).

exports: augment_for_extraction
used_by: src/gnokee/ingest.py
rules:   pure function — no IO, no LLM, no exceptions propagate
agent:   claude-opus-4-7 | 2026-05-08 | v0.1.1
"""

from __future__ import annotations

from gnokee.extract.preprocessor import augment_for_extraction

__all__ = ["augment_for_extraction"]
