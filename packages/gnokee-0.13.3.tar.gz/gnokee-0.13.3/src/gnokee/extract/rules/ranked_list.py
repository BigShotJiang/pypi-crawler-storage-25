"""src/gnokee/extract/rules/ranked_list.py — Ranked priority rule.

Detects three flavours of ranked-priority signal:
  1. Markdown ordered lists (`1. … 2. …`) → "top item under '<H>' is …"
  2. P-prefix lines (`P0:`, `P1:`) → "P0 priority: …"
  3. "Top of stack" phrase → "Top of stack under '<H>': …"

Closes v0.1.1 issue #3.

exports: extract
used_by: src/gnokee/extract/preprocessor.py
rules:   cap ordered-list emit at MAX_LIST_ITEMS; never raise
agent:   claude-opus-4-7 | 2026-05-08 | v0.1.1
"""

from __future__ import annotations

import re

_HEADING_PATTERN = re.compile(r"^#{1,6}\s+(.+?)\s*$")
_ORDERED_ITEM_PATTERN = re.compile(r"^\s*(\d+)\.\s+(.+?)\s*$")
_P_PREFIX_PATTERN = re.compile(r"^\s*(P\d+)[:.\s]\s*(.+?)\s*$")
_TOP_OF_STACK_PATTERN = re.compile(r"^\s*Top\s+of\s+stack\s*[:\-]\s*(.+?)\s*$", re.IGNORECASE)

MAX_LIST_ITEMS = 3
_RANK_WORDS = ["top", "second", "third"]


def extract(content: str) -> list[str]:
    if not content:
        return []
    lines = content.splitlines()

    headings_at_or_before: list[str] = [""] * len(lines)
    current_heading = ""
    for i, line in enumerate(lines):
        m = _HEADING_PATTERN.match(line)
        if m:
            current_heading = m.group(1).strip()
        headings_at_or_before[i] = current_heading

    out: list[str] = []

    # Ordered-list groups: collect contiguous runs of `\d+. text`.
    i = 0
    while i < len(lines):
        m = _ORDERED_ITEM_PATTERN.match(lines[i])
        if not m:
            i += 1
            continue
        items: list[str] = []
        list_heading = headings_at_or_before[i]
        while i < len(lines):
            mm = _ORDERED_ITEM_PATTERN.match(lines[i])
            if not mm:
                break
            items.append(mm.group(2).strip())
            i += 1
        anchor = f" under '{list_heading}'" if list_heading else ""
        for rank_idx, item in enumerate(items[:MAX_LIST_ITEMS]):
            word = _RANK_WORDS[rank_idx]
            out.append(f"The {word} item{anchor} is: {item}.")

    # P-prefix lines.
    for line in lines:
        pm = _P_PREFIX_PATTERN.match(line)
        if pm:
            prefix = pm.group(1)
            rest = pm.group(2).strip()
            out.append(f"{prefix} priority: {rest}.")

    # "Top of stack" phrase.
    for i, line in enumerate(lines):
        tm = _TOP_OF_STACK_PATTERN.match(line)
        if tm:
            heading = headings_at_or_before[i]
            anchor = f" under '{heading}'" if heading else ""
            out.append(f"Top of stack{anchor}: {tm.group(1).strip()}.")

    return out


__all__ = ["MAX_LIST_ITEMS", "extract"]
