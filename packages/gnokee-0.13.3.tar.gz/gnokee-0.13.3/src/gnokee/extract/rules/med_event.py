"""src/gnokee/extract/rules/med_event.py — Medication-event rule.

Lifts start / stop / discontinue / dose-change drug events and allergy
declarations into short SVO derived sentences so graphiti's edge-fact
extractor preserves the drug-name + dose tuple.

Sample input:
    "Started Lisinopril 10 mg PO daily for stage-1 hypertension."
Sample derived:
    "Lisinopril 10 mg was started."

Sample input:
    "Increased Lisinopril from 10 mg to 20 mg PO daily."
Sample derived:
    "Lisinopril dose changed from 10 mg to 20 mg."

Sample input:
    "Allergy documented: Penicillin — moderate reaction ..."
Sample derived:
    "Penicillin allergy documented."

Closes the v0.1.x cheap-mitigation path for ADR-0010 (Q8 meds, adopt-
with-gaps). Typed ``med_record`` table arrives in v0.2.

exports: extract
used_by: src/gnokee/extract/preprocessor.py
rules:   cap derived sentences at MAX_PER_DOC; never raise; sentence-
         boundary scan only — no LLM.
agent:   claude-opus-4-7 | 2026-05-09 | v0.1.x
"""

from __future__ import annotations

import re

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")

_MED_VERB = r"(?P<verb>started|stopped|discontinued|added|switched|continuing|holding)"
_MED_VERB_PAST = {
    "started": "started",
    "stopped": "stopped",
    "discontinued": "discontinued",
    "added": "added",
    "switched": "switched",
    "continuing": "continued",
    "holding": "held",
}

_DRUG = r"(?P<drug>[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)?)"
_DOSE = r"(?P<dose>\d+(?:\.\d+)?\s*(?:mg|mcg|mEq|mL|IU|g))"
_DOSE_FROM = r"(?P<from>\d+(?:\.\d+)?\s*(?:mg|mcg|mEq|mL|IU|g))"
_DOSE_TO = r"(?P<to>\d+(?:\.\d+)?\s*(?:mg|mcg|mEq|mL|IU|g))"

_VERB_DRUG_DOSE_PATTERN = re.compile(
    rf"^\s*{_MED_VERB}\s+{_DRUG}(?:\s+{_DOSE})?",
    re.IGNORECASE,
)
_DOSE_CHANGE_PATTERN = re.compile(
    rf"^\s*(?P<verb>increased|decreased|raised|lowered|titrated)\s+{_DRUG}\s+"
    rf"(?:from\s+{_DOSE_FROM}\s+)?to\s+{_DOSE_TO}",
    re.IGNORECASE,
)
_ALLERGY_PATTERN = re.compile(
    rf"^\s*Allergy\s+documented:\s*{_DRUG}",
)

MAX_PER_DOC = 30


def extract(content: str) -> list[str]:
    """Return derived SVO sentences for med events in ``content``."""
    if not content:
        return []
    seen: set[str] = set()
    out: list[str] = []
    for raw in _SENTENCE_SPLIT.split(content):
        if len(out) >= MAX_PER_DOC:
            break
        sentence = raw.strip()
        if not sentence:
            continue

        m_allergy = _ALLERGY_PATTERN.match(sentence)
        if m_allergy:
            _emit(f"{m_allergy.group('drug').strip()} allergy documented.", seen, out)
            continue

        m_change = _DOSE_CHANGE_PATTERN.match(sentence)
        if m_change:
            drug = m_change.group("drug").strip()
            dose_from = m_change.group("from")
            dose_to = m_change.group("to").strip()
            if dose_from:
                _emit(f"{drug} dose changed from {dose_from.strip()} to {dose_to}.", seen, out)
            else:
                _emit(f"{drug} dose changed to {dose_to}.", seen, out)
            continue

        m_verb = _VERB_DRUG_DOSE_PATTERN.match(sentence)
        if m_verb:
            verb = m_verb.group("verb").lower()
            drug = m_verb.group("drug").strip()
            dose = m_verb.group("dose")
            past = _MED_VERB_PAST.get(verb, verb)
            if dose:
                _emit(f"{drug} {dose.strip()} was {past}.", seen, out)
            else:
                _emit(f"{drug} was {past}.", seen, out)

    return out


def _emit(sentence: str, seen: set[str], out: list[str]) -> None:
    if sentence in seen or len(out) >= MAX_PER_DOC:
        return
    seen.add(sentence)
    out.append(sentence)


__all__ = ["MAX_PER_DOC", "extract"]
