"""src/gnokee/extract/rules/ — Per-signal extraction rules.

Each rule exports `extract(content) -> list[str]`. Pure functions.

exports: (per-rule modules)
used_by: src/gnokee/extract/preprocessor.py
rules:   no IO; never raise on bad input
agent:   claude-opus-4-7 | 2026-05-08 | v0.1.1
"""
