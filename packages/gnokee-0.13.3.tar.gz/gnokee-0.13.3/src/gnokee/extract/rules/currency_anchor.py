"""src/gnokee/extract/rules/currency_anchor.py — Bold-currency anchor rule.

Two shapes the pipe-table rule cannot reach:

  1. Bold list-item total under a heading::

         ## Actual spend to date
         - **Total spent: 14,225.45**

  2. Bold declarative currency line at the start of a paragraph::

         ## Renovation — actuals
         **€14,225 spent through 20.04.2026.** Floors, kitchen install ahead.

For each match emits one derived sentence anchored to the nearest preceding
heading, so graphiti's edge facts inherit the amount text verbatim.

Closes v0.1.1 issue #6 (sibling of #4 — covers the non-pipe-table shapes
in the noggin real-corpus suite).

exports: extract
used_by: src/gnokee/extract/preprocessor.py
rules:   cap derived sentences per doc at MAX_PER_DOC; never raise; pipe-
         table rows are skipped (table_amount owns those)
agent:   claude-opus-4-7 | 2026-05-08 | v0.1.1
"""

from __future__ import annotations

import re

_HEADING_PATTERN = re.compile(r"^#{1,6}\s+(.+?)\s*$")
_LIST_BOLD_PATTERN = re.compile(r"^\s*[-*+]\s+\*\*([^*]+?)\*\*\s*$")
_LEAD_BOLD_PATTERN = re.compile(r"^\s*\*\*([^*\n]+?)\*\*")
_CURRENCY_PATTERN = re.compile(
    r"[€$£¥]\s?\d"  # symbol then digit
    r"|\d[\d,.\s]*\s*[€$£¥]"  # digit then symbol (EU convention)
    r"|\d[\d,.\s]*\s*(?:EUR|USD|GBP|JPY|BGN|CHF)\b",
)
_DIGIT_PATTERN = re.compile(r"\d")
_AMOUNT_KEYWORD_PATTERN = re.compile(
    r"\b(total|subtotal|spent|spend|cost|budget|paid|due|owed|balance|"
    r"raised|sum|fee|tax|price|amount|invested|outstanding|principal)\b",
    re.IGNORECASE,
)

MAX_PER_DOC = 30


def _is_amount_bearing(text: str) -> bool:
    """True if the bold inner carries a number we should preserve."""
    if _CURRENCY_PATTERN.search(text):
        return True
    return bool(_DIGIT_PATTERN.search(text) and _AMOUNT_KEYWORD_PATTERN.search(text))


_H1_PATTERN = re.compile(r"^#\s+(.+?)\s*$")


def _document_title(lines: list[str]) -> str:
    """Return the first H1 line text, or '' if absent."""
    for line in lines:
        m = _H1_PATTERN.match(line)
        if m:
            return m.group(1).strip()
    return ""


def extract(content: str) -> list[str]:
    if not content:
        return []
    lines = content.splitlines()
    document_title = _document_title(lines)
    current_heading = ""
    seen: set[str] = set()
    out: list[str] = []

    for raw in lines:
        if len(out) >= MAX_PER_DOC:
            break

        h = _HEADING_PATTERN.match(raw)
        if h:
            current_heading = h.group(1).strip()
            continue

        stripped = raw.lstrip()
        if stripped.startswith("|"):
            continue

        inner: str | None = None
        m_list = _LIST_BOLD_PATTERN.match(raw)
        if m_list:
            candidate = m_list.group(1).strip()
            if _is_amount_bearing(candidate):
                inner = candidate
        elif not stripped.startswith(("- ", "* ", "+ ")):
            m_lead = _LEAD_BOLD_PATTERN.match(raw)
            if m_lead:
                candidate = m_lead.group(1).strip()
                if _is_amount_bearing(candidate):
                    inner = candidate

        if not inner:
            continue

        # Pair the amount with the document-title entity so graphiti's
        # edge-fact extractor produces an S-V-O fact that preserves the
        # number verbatim. Section heading still appears as context tail.
        section = current_heading if current_heading and current_heading != document_title else ""
        if document_title and section:
            sentence = f"{document_title}: {inner.rstrip('.')} ({section})."
        elif document_title:
            sentence = f"{document_title}: {inner.rstrip('.')}."
        elif section:
            sentence = f"Under '{section}': {inner.rstrip('.')}."
        else:
            sentence = f"{inner.rstrip('.')}."

        if sentence in seen:
            continue
        seen.add(sentence)
        out.append(sentence)

    return out


__all__ = ["MAX_PER_DOC", "extract"]
