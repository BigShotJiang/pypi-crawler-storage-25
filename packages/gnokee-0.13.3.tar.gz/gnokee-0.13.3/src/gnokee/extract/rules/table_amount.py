"""src/gnokee/extract/rules/table_amount.py — Markdown-table currency rule.

Parses pipe-delimited markdown tables; for each data row containing a
currency cell, emits one derived sentence pairing the leftmost non-numeric
column value with the amount, anchored to the nearest preceding heading.

Closes v0.1.1 issue #4 (layer 2 of the suggested fix — table-aware ingest).

exports: extract
used_by: src/gnokee/extract/preprocessor.py
rules:   cap derived sentences per table at MAX_PER_TABLE; never raise on
         malformed rows (skip silently)
agent:   claude-opus-4-7 | 2026-05-08 | v0.1.1
"""

from __future__ import annotations

import re

_HEADING_PATTERN = re.compile(r"^#{1,6}\s+(.+?)\s*$")
_PIPE_ROW = re.compile(r"^\s*\|.+\|\s*$")
_SEPARATOR_ROW = re.compile(r"^\s*\|?\s*[-:|\s]+\s*$")
_CURRENCY_PATTERN = re.compile(
    r"(?P<sym>[€$£¥])\s?(?P<num>[\d][\d,.\s]*)(?P<suffix>[kKmM]|bn)?",
)

MAX_PER_TABLE = 20


def _split_row(row: str) -> list[str]:
    """Strip leading/trailing pipes; split. Whitespace-trim each cell."""
    s = row.strip()
    if s.startswith("|"):
        s = s[1:]
    if s.endswith("|"):
        s = s[:-1]
    return [c.strip() for c in s.split("|")]


def _is_separator_row(row: str) -> bool:
    s = row.strip()
    if not s.startswith("|") and "|" not in s:
        return False
    cells = _split_row(s)
    return all(c == "" or set(c) <= set("-:") for c in cells)


def extract(content: str) -> list[str]:
    if not content:
        return []
    lines = content.splitlines()
    out: list[str] = []

    i = 0
    current_heading = ""
    while i < len(lines):
        line = lines[i]
        h = _HEADING_PATTERN.match(line)
        if h:
            current_heading = h.group(1).strip()

        if not _PIPE_ROW.match(line):
            i += 1
            continue

        # Found a candidate header row. Look for a separator on the next line.
        if i + 1 >= len(lines) or not _is_separator_row(lines[i + 1]):
            i += 1
            continue
        header_cells = _split_row(line)
        # advance past header + separator
        j = i + 2
        emitted_for_table = 0
        table_heading = current_heading
        while j < len(lines):
            raw = lines[j]
            # Stop at first line that does not begin with '|' — table over.
            if not raw.lstrip().startswith("|"):
                break
            j += 1
            if not _PIPE_ROW.match(raw):
                # Tolerate malformed row (no trailing pipe etc.); skip and
                # keep scanning the rest of the table.
                continue
            row_cells = _split_row(raw)
            if not row_cells:
                continue
            # find leftmost non-numeric, non-empty cell
            label_idx = -1
            for k, cell in enumerate(row_cells):
                if cell and not _CURRENCY_PATTERN.search(cell):
                    label_idx = k
                    break
            if label_idx < 0:
                continue
            label_header = header_cells[label_idx] if label_idx < len(header_cells) else "Item"
            label_value = row_cells[label_idx]
            for k, cell in enumerate(row_cells):
                if k == label_idx:
                    continue
                m = _CURRENCY_PATTERN.search(cell)
                if not m:
                    continue
                amount_text = m.group(0).replace(" ", "")
                amount_header = header_cells[k] if k < len(header_cells) else "amount"
                anchor = f", as recorded in '{table_heading}'" if table_heading else ""
                out.append(f"{label_header}: {label_value} = {amount_text} ({amount_header.lower()}){anchor}.")
                emitted_for_table += 1
                if emitted_for_table >= MAX_PER_TABLE:
                    break
            if emitted_for_table >= MAX_PER_TABLE:
                break
        i = j
    return out


__all__ = ["MAX_PER_TABLE", "extract"]
