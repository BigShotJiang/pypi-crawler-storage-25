"""src/gnokee/extract/rules/identifier.py — Numbered identifier rule.

Detects ADR-NNN, Q\\d+, P\\d+\\.\\d+, RFC-\\d{4} patterns. For each unique
identifier, emits one derived sentence anchored to the nearest preceding
markdown heading + the line containing the match.

Closes v0.1.1 issue #2.

exports: extract
used_by: src/gnokee/extract/preprocessor.py
rules:   dedupe identifiers; cap at MAX_IDENTIFIERS; never raise
agent:   claude-opus-4-7 | 2026-05-08 | v0.1.1
"""

from __future__ import annotations

import re

_IDENTIFIER_PATTERN = re.compile(r"\b(ADR-\d{3}|Q\d+|P\d+\.\d+|RFC-\d{4})\b")
_HEADING_PATTERN = re.compile(r"^#{1,6}\s+(.+?)\s*$")

MAX_IDENTIFIERS = 20


def extract(content: str) -> list[str]:
    """Return derived sentences for each unique identifier in `content`."""
    if not content:
        return []

    lines = content.splitlines()
    headings_at_or_before: list[str] = [""] * len(lines)
    current_heading = ""
    for i, line in enumerate(lines):
        m = _HEADING_PATTERN.match(line)
        if m:
            current_heading = m.group(1).strip()
        headings_at_or_before[i] = current_heading

    seen: dict[str, str] = {}
    for i, line in enumerate(lines):
        for match in _IDENTIFIER_PATTERN.finditer(line):
            ident = match.group(1)
            if ident in seen:
                continue
            heading = headings_at_or_before[i]
            is_heading_line = bool(_HEADING_PATTERN.match(line))
            if is_heading_line:
                # Match landed on the heading itself — pull the first
                # non-empty body line below as the descriptive sentence.
                sentence_text = ""
                for j in range(i + 1, len(lines)):
                    candidate = lines[j].strip()
                    if not candidate or _HEADING_PATTERN.match(lines[j]):
                        if candidate and _HEADING_PATTERN.match(lines[j]):
                            break
                        continue
                    sentence_text = candidate
                    break
            else:
                sentence_text = line.strip()
            if heading and sentence_text:
                seen[ident] = f"{ident} is referenced in '{heading}': {sentence_text}"
            elif heading:
                seen[ident] = f"{ident} is referenced in '{heading}'."
            elif sentence_text:
                seen[ident] = f"{ident} is referenced: {sentence_text}"
            else:
                seen[ident] = f"{ident} is referenced."
            if len(seen) >= MAX_IDENTIFIERS:
                return list(seen.values())
    return list(seen.values())


__all__ = ["MAX_IDENTIFIERS", "extract"]
