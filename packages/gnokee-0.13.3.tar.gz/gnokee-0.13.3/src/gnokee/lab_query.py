"""src/gnokee/lab_query.py — Typed lab-row read pipeline (ADR-0009).

Sibling of `retrieval` for the structured clinical-lab path. Where
`gnokee_recall` returns natural-language fact statements with provenance
handles, `gnokee_lab_query` returns typed rows + scalar aggregates
keyed by ``(tenant, analyte, date_range)``.

Both bi-temporal half-pairs are mandatory on every read so retroactive
lab corrections (the dominant Q7 supersession path) honour `as_of` /
`valid_at` pins identically to `gnokee_recall`.

Operations:
  - latest    : 1 row, most recent visible by `valid_at`
  - history   : list of rows, ascending `valid_at`, optional date-range
  - min / max / avg / count : numeric scalar over visible numeric rows
  - abnormal  : list of rows where `abnormal_flag IS NOT NULL`; analyte
                is optional so callers can ask "which electrolytes were
                abnormal?" without naming each analyte up front.

exports: LabQueryPipeline | LabQueryResponse | LabRowOut | lab_query
used_by: src/gnokee/__init__.py | src/gnokee/mcp.py
rules:   tenant_id mandatory; both bi-temporal half-pairs always applied;
         scalar ops skip rows where value_numeric IS NULL;
         analyte mandatory for every op except `abnormal`
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0009
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from typing import Literal
from uuid import UUID

from gnokee.citations import build_row_citations
from gnokee.config import utc_now
from gnokee.errors import ValidationError
from gnokee.models import Citation
from gnokee.storage.lab import LabRecordRow, LabStore

LabOp = Literal["latest", "history", "min", "max", "avg", "count", "abnormal"]

DEFAULT_HISTORY_LIMIT = 50
MAX_HISTORY_LIMIT = 500


@dataclass(frozen=True)
class LabRowOut:
    """Wire-shape for one lab row in the MCP response."""

    episode_uuid: UUID
    analyte: str
    value_numeric: Decimal | None
    value_text: str | None
    unit: str | None
    ref_range_low: Decimal | None
    ref_range_high: Decimal | None
    abnormal_flag: str | None
    valid_at: datetime
    asserted_at: datetime


@dataclass(frozen=True)
class LabQueryResponse:
    op: LabOp
    rows: list[LabRowOut] = field(default_factory=list)
    scalar: Decimal | None = None  # populated for min/max/avg/count
    count: int = 0  # rows.len for history; scalar for count; else 0
    # ADR-0016 (issue #76) — per-claim bi-temporal citation envelope. One
    # entry per emitted row, keyed `c1`, `c2`, … in `rows` order. Empty
    # for scalar ops (no rows = no citations). Additive to the existing
    # `rows[].episode_uuid` provenance handle.
    citations: dict[str, Citation] = field(default_factory=dict)


@dataclass
class LabQueryPipeline:
    """Bundles the LabStore for the orchestrator. One per process."""

    lab: LabStore

    async def query(
        self,
        *,
        tenant_id: str,
        analyte: str | None,
        op: LabOp,
        since: datetime | None,
        until: datetime | None,
        as_of: datetime,
        valid_at: datetime,
        limit: int,
    ) -> LabQueryResponse:
        if not tenant_id:
            raise ValidationError("tenant_id is required")
        if op != "abnormal" and not analyte:
            raise ValidationError("analyte is required")
        if op not in {"latest", "history", "min", "max", "avg", "count", "abnormal"}:
            raise ValidationError(f"unknown op: {op!r}")
        if since is not None and until is not None and since >= until:
            raise ValidationError("`since` must be < `until`")
        if op in {"history", "abnormal"}:
            if limit < 1:
                raise ValidationError("limit must be >= 1")
            if limit > MAX_HISTORY_LIMIT:
                limit = MAX_HISTORY_LIMIT

        if op == "latest":
            assert analyte is not None  # guard above
            row = await self.lab.latest(
                tenant_id=tenant_id,
                analyte=analyte,
                as_of=as_of,
                valid_at=valid_at,
            )
            rows_out = [_to_out(row)] if row is not None else []
            return LabQueryResponse(
                op=op,
                rows=rows_out,
                count=len(rows_out),
                citations=_row_citations(rows_out),
            )

        if op == "history":
            assert analyte is not None  # guard above
            rows = await self.lab.history(
                tenant_id=tenant_id,
                analyte=analyte,
                since=since,
                until=until,
                as_of=as_of,
                valid_at=valid_at,
                limit=limit,
            )
            rows_out = [_to_out(r) for r in rows]
            return LabQueryResponse(
                op=op,
                rows=rows_out,
                count=len(rows_out),
                citations=_row_citations(rows_out),
            )

        if op == "abnormal":
            rows = await self.lab.abnormal(
                tenant_id=tenant_id,
                analyte=analyte,
                since=since,
                until=until,
                as_of=as_of,
                valid_at=valid_at,
                limit=limit,
            )
            rows_out = [_to_out(r) for r in rows]
            return LabQueryResponse(
                op=op,
                rows=rows_out,
                count=len(rows_out),
                citations=_row_citations(rows_out),
            )

        # aggregate ops
        assert analyte is not None  # guard above
        scalar = await self.lab.aggregate(
            tenant_id=tenant_id,
            analyte=analyte,
            op=op,
            since=since,
            until=until,
            as_of=as_of,
            valid_at=valid_at,
        )
        count = int(scalar) if op == "count" and scalar is not None else 0
        # Scalar ops emit zero rows → zero citations (ADR-0016 §
        # "rows-only response").
        return LabQueryResponse(op=op, scalar=scalar, count=count)


def _to_out(row: LabRecordRow) -> LabRowOut:
    return LabRowOut(
        episode_uuid=row.episode_uuid,
        analyte=row.analyte,
        value_numeric=row.value_numeric,
        value_text=row.value_text,
        unit=row.unit,
        ref_range_low=row.ref_range_low,
        ref_range_high=row.ref_range_high,
        abnormal_flag=row.abnormal_flag,
        valid_at=row.valid_at,
        asserted_at=row.asserted_at,
    )


def _row_citations(rows: list[LabRowOut]) -> dict[str, Citation]:
    """Per-row citation envelope (ADR-0016 / issue #76).

    ``extracted_quote`` is ``None`` everywhere in v0.5 — the lab pipeline
    does not yet fetch ``episode_metadata.extracted_quote``. Backfill
    arrives in a follow-up once the extraction stage records body spans.
    """
    return build_row_citations(
        rows=[(r.episode_uuid, r.valid_at, r.asserted_at) for r in rows],
        extracted_quotes=None,
    )


# Module-level coroutine for the MCP layer.
async def lab_query(
    *,
    pipeline: LabQueryPipeline,
    tenant_id: str,
    analyte: str | None,
    op: LabOp,
    since: datetime | None = None,
    until: datetime | None = None,
    as_of: datetime | None = None,
    valid_at: datetime | None = None,
    limit: int = DEFAULT_HISTORY_LIMIT,
) -> LabQueryResponse:
    return await pipeline.query(
        tenant_id=tenant_id,
        analyte=analyte,
        op=op,
        since=since,
        until=until,
        as_of=as_of or utc_now(),
        valid_at=valid_at or utc_now(),
        limit=limit,
    )


__all__ = [
    "DEFAULT_HISTORY_LIMIT",
    "MAX_HISTORY_LIMIT",
    "LabOp",
    "LabQueryPipeline",
    "LabQueryResponse",
    "LabRowOut",
    "lab_query",
]
