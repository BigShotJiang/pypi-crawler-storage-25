# Self-hosted GitHub Actions runner — gnokee operator runbook

Companion to PR #306 (CI migration to self-hosted runners). Current
runner host: an Unraid box on the maintainer's home network (labels
`[self-hosted, linux, x64]` + `[unraid, docker]` per workflow).

## RLIMIT_NOFILE — required for `tests/integration/test_mcp_streamable_http.py`

The 100-session pool-counter smoke test (issue #245 Step 4) opens 100
concurrent ingest+recall pairs against a live stack. Each session holds
a Postgres connection + a Neo4j bolt session + an ASGI request socket.
The default actions-runner systemd unit on most Linux hosts (including
the Unraid runner gnokee uses) ships with the soft cap
`LimitNOFILE=1024` — which the test will exhaust mid-run, producing a
false-negative fd-leak report unrelated to gnokee code.

### Verify

On the runner box (one-liner):

```sh
cat /proc/$(pgrep -f 'actions-runner' | head -1)/limits | grep 'Max open files'
```

Expected: `Max open files   65536   65536   files`.

If you see `1024 1024` or `4096 4096`, the runner needs the patch
below before the smoke test can run reliably.

### Patch (one-time per runner host)

Edit the actions-runner systemd unit (usually
`/etc/systemd/system/actions.runner.<org>.<runner-name>.service`):

```ini
[Service]
LimitNOFILE=65536
```

Reload + restart:

```sh
sudo systemctl daemon-reload
sudo systemctl restart actions.runner.<org>.<runner-name>.service
```

Re-verify with the one-liner above. The smoke test guards itself with
`_nofile_ulimit_ok()` so a runner without the patch will skip the
test rather than fail — but skipping is not "passing".

## TLS-at-proxy assumption

gnokee never holds TLS keys (AGENTS.md `do not hold keys`). The
self-hosted runner stack assumes a reverse proxy (Caddy / nginx) on the
same host terminates TLS for any externally-reachable port. Local
service-to-service traffic stays on `127.0.0.1:<port>` per the default
`GNOKEE_MCP_HOST=127.0.0.1` bind.

## PyPI Trusted Publishing

`.github/workflows/pypi-publish.yml` migrated to `runs-on: [self-hosted,
linux, x64]` on 2026-05-22 after GitHub Actions billing forced the
move. OIDC Trusted Publishing still works on self-hosted runners
because GitHub's OIDC provider (`iss = https://token.actions.
githubusercontent.com`) mints the token regardless of runner type —
the PyPI Trusted Publisher verifier matches on `repository`,
`workflow`, and `environment` claims, not on runner-environment. The
PyPI registration entry under [pypi.org/manage/project/gnokee/settings/
publishing/](https://pypi.org/manage/project/gnokee/settings/publishing/)
needs NO change.

If a future PyPI policy change tightens runner-environment matching,
fallback options are: (a) migrate just `publish-pypi` back to
`ubuntu-latest` after resolving GitHub Actions billing, (b) switch to
a stored API token (PyPI API token in `secrets.PYPI_API_TOKEN`,
removes OIDC dependency).
