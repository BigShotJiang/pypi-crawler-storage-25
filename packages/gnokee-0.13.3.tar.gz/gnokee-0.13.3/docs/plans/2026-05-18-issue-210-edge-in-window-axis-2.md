# Issue #210 — `EdgeInWindow` axis-2 fix (Option B + drop orphans)

- **Driver:** v0.11 final tracker (#273). Unblocks #232.
- **Author:** Vadim Yuzi
- **Date:** 2026-05-18
- **Status:** Designed, ready for execution. Not yet started.
- **Branch:** `fix/210-edge-in-window-axis-2`

## Problem (recap from #210)

`src/gnokee/storage/graph.py:131-148` — `EdgeInWindow.asserted_at` is assigned from Neo4j `r.created_at` (axis-3, Graphiti ingest-system time), not source-asserted-at (axis-2). Field name lies.

`backfill_fact_revisions` writes this value into `fact_revision.asserted_at`, polluting axis-2 audit log with axis-3 timestamps for the entire Stage 6c crash-recovery class.

Downstream `fact_revision.list_revisions` + `latest_revisions_at_for_fact_uuids` (`storage/fact_revision.py:191-192, 273-275`) filter by `asserted_at <= $N` — backfill rows with axis-3 produce wrong point-in-time cuts for `gnokee_fact_history` time-travel.

Per ADR-0004: valid_at = world time (axis-1), asserted_at = source-tx (axis-2, gnokee-managed), created_at = ingest-system (axis-3, Graphiti-managed). Conflation = silent corruption.

## Decision (locked)

- **Option B**: Join `episode_metadata.asserted_at` (Postgres) to populate axis-2.
- **Orphan policy**: Drop edges with no `episode_metadata` row from backfill result. Surface count in `BackfillFactRevisionsReport.dropped_orphan_count`. No mixed-axis fallback.
- **Rejected**: Option A (rename-only, leaves table mixed-axis indefinitely). Option C (two-field with axis-3 fallback, reintroduces narrower mixed-axis case). Hard-fail orphan policy (blocks resumability).

Rationale: pattern already exists at `maintenance.py:385` (`_extract_one` reads `episode_metadata.asserted_at` via PG). Maintenance-only path so the extra round-trip is acceptable. Drop-orphans keeps `fact_revision` table axis-uniform — the audit invariant. Coverage gap surfaces as a metric, not a silent corruption.

## Execution steps

### Step 1 — `src/gnokee/storage/graph.py`

`EdgeInWindow` dataclass changes:
- Rename `asserted_at: datetime` → `edge_created_at: datetime`. Populated from Neo4j `r.created_at` as before. Docstring: explicit "axis-3, ingest-system time".
- **Add** `asserted_at: datetime | None = None`. Always `None` at this layer. Populated by caller (`backfill_fact_revisions`) from Postgres join. Reason: keep `list_edges_in_window` PG-free; caller owns axis-2 enrichment.

`list_edges_in_window` signature changes:
- Rename params `window_start` → `created_at_start`, `window_end` → `created_at_end`. Param names then match what they actually bind in Cypher (`r.created_at`).
- Cypher `RETURN` alias for `r.created_at` → `edge_created_at` (was `asserted_at`).
- Docstring: explicit axis-3 semantics on params and return field.

### Step 2 — `src/gnokee/maintenance.py` (`backfill_fact_revisions`)

After `list_edges_in_window` returns:

1. Collect distinct `episode_uuid` set from returned edges.
2. Batch PG query: `SELECT episode_uuid, asserted_at FROM episode_metadata WHERE tenant_id = $1 AND episode_uuid = ANY($2)`. Build `{episode_uuid: asserted_at}` map.
3. Iterate edges:
   - If `edge.episode_uuid in map`: set `edge.asserted_at = map[edge.episode_uuid]`. Proceed.
   - Else: skip edge. Increment `dropped_orphan_count`. Log at DEBUG (not WARNING — orphans are expected for pre-ADR-0023 episodes; WARNING is noise).
4. `FactRevisionRow` construction (`maintenance.py:726`): `asserted_at=edge.asserted_at` (axis-2, guaranteed non-None at this point because orphans were dropped above).

Param-name update on `list_edges_in_window` call site (`maintenance.py:661-665`): `window_start=` → `created_at_start=`, etc.

### Step 3 — `BackfillFactRevisionsReport`

Add field `dropped_orphan_count: int = 0`. Wire from step 2.

### Step 4 — Tests

**Unit (`tests/unit/test_maintenance_backfill_fact_revisions.py`)**:
- `_edge()` helper (line ~51): rename `asserted_at` kwarg → `edge_created_at`. Add optional `asserted_at` kwarg defaulting to `None`.
- `test_all_edges_missing_backfilled` (line ~201): assertion `row.asserted_at == edge.asserted_at` is now correct semantics (axis-2 from PG). Test must mock the new PG batch fetch — add fixture for `episode_metadata.asserted_at` lookup.
- `assert_awaited_once_with` at lines ~339, ~357: update param names.
- **New test**: `test_orphan_edge_dropped` — edge with episode_uuid that has no `episode_metadata` row → not in `FactRevisionRow` writes; `report.dropped_orphan_count == 1`.
- **New test**: `test_asserted_at_from_episode_metadata` — three episodes with distinct `(valid_at, asserted_at, created_at)`; assert `fact_revision.asserted_at == episode_metadata.asserted_at` for each (not `r.created_at`).

**Integration (`tests/integration/test_maintenance_backfill_fact_revisions.py`)**:
- Extend Stage 6c crash-simulation corpus to set `valid_at != asserted_at != created_at` on at least one episode. Assert backfilled `fact_revision.asserted_at` matches `episode_metadata.asserted_at`, not `r.created_at`.
- Add orphan case: one edge whose episode is force-deleted from Postgres after Neo4j ingest. Assert backfill drops it + report counter increments.

### Step 5 — PR

- Conventional commit: `fix(maintenance): populate fact_revision.asserted_at from episode_metadata, not r.created_at (#210)`
- Body: refs #210, refs #273, notes "unblocks #232".
- Breaking-change note in PR body: `EdgeInWindow.asserted_at` renamed → `edge_created_at` (+ new `asserted_at` axis-2 field); `list_edges_in_window` param names changed. Only known callers are `maintenance.backfill_fact_revisions` and test fixtures — both updated in this PR.
- Specialist review: spawn `bi-temporal-auditor` and `postgres-pgvector-specialist` on the PR.

## Out-of-scope

- ADR-0004 wording is already correct; no doc change there.
- `gnokee_fact_history` MCP tool signature unchanged — fix is downstream-transparent (point-in-time cuts become correct; tool surface stays the same).
- #232 (`gnokee_wiki_export` `valid_at` param) is a separate PR after this lands.

## Stop conditions

- Integration test fails on baseline `main` before changes (signals branch is dirty).
- `episode_metadata` batch-fetch pattern at `maintenance.py:385` no longer matches what step 2 needs — re-evaluate before implementing.
- `bi-temporal-auditor` flags axis confusion in the diff — halt + re-design.

## Files touched (final list)

| Path | Change |
|---|---|
| `src/gnokee/storage/graph.py` | `EdgeInWindow` field rename + add `asserted_at`. `list_edges_in_window` param rename + Cypher RETURN alias. |
| `src/gnokee/maintenance.py` | `backfill_fact_revisions` PG join, orphan drop, report counter. Call-site param rename. |
| `tests/unit/test_maintenance_backfill_fact_revisions.py` | Helper kwarg rename, fixture mock for PG fetch, 2 new tests. |
| `tests/integration/test_maintenance_backfill_fact_revisions.py` | Corpus update for `valid_at != asserted_at != created_at`; orphan case. |
| `CHANGELOG.md` | `[Unreleased]` — fix entry referencing #210. |
