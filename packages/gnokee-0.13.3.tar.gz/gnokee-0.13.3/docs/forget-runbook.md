# Forget runbook

Operator playbook for the v0.8 forget pipeline (ADR-0026) and its v0.10
amendments (this document, issue #158).

The forget pipeline executes a coordinated two-phase erasure: Postgres
(SERIALIZABLE transaction with retry) and Neo4j (post-commit best-effort,
chunked above a threshold). See:

- `src/gnokee/forget.py` — `forget_episode` + `forget_tenant`.
- `src/gnokee/storage/graph.py` — `remove_tenant_group` (monolithic +
  chunked paths, issue #138).
- `docs/adr/0026-forget-pipeline.md` — full design.
- `docs/adr/0027-short-ids.md` — short_id_map / short_id_seq retention.
- `docs/adr/0028-ingest-audit.md` — `ingest_audit` retention.

---

## Retry knob

`GNOKEE_FORGET_RETRIES` (default `3`) controls the SERIALIZABLE-retry
budget on the Postgres phase of `forget_episode` and `forget_tenant`.

The env var is read at each call to `_serializable_retries()` inside
`src/gnokee/forget.py` — not at module import time, so a redeploy is not
required between calls, but a value change does not retro-actively reset
an in-flight transaction's retry counter.

| Value      | Effect                                                        |
|------------|---------------------------------------------------------------|
| unset / 3  | Default: tolerate transient `SerializationError` up to 3x.    |
| `5`–`10`   | Recommended ceiling when ingest contention is high.           |
| `< 1` / NaN| Falls back to default `3` with a `WARNING` log line.          |

After exhausting the budget the pipeline raises `ForgetContention`. Pair
with `GNOKEE_FORGET_LOCK_TIMEOUT_MS` (Settings.forget_lock_timeout_ms)
when the contention root cause is a stalled ingest holding the shared
forget lock.

---

## Progress logging

The chunked Neo4j sweep logs one `INFO` line per chunk under the
`gnokee.forget` logger namespace. Sample shape:

    INFO gnokee.forget: forget_tenant chunk 3/14 tenant=acme label=Episodic deleted_nodes=10000
    INFO gnokee.forget: forget_tenant chunk 4/14 tenant=acme label=Episodic deleted_nodes=10000
    ...
    INFO gnokee.forget: forget_tenant chunk 11/14 tenant=acme label=Entity deleted_nodes=437
    INFO gnokee.forget: forget_tenant chunk 12/14 tenant=acme label=Entity deleted_nodes=0

The `N/M` count is `chunks_executed / ceil(pre_count / chunk_size)` —
`M` is an upper bound; the loop terminates earlier than `M` when the
per-label sub-population is smaller than the global estimate would
suggest. The final per-label chunk shows `deleted_nodes=0` (sentinel
that ends the while-loop).

The monolithic path (tenants at or below `neo4j_detach_chunk_threshold`,
default 100k nodes) emits no chunk lines — the receipt's
`neo4j_chunked: null` is the marker.

### Wall-clock expectations

At a 10k-node tenant with `chunk_size=10_000`, chunked path engages only
above the 100k threshold. A 200k-node tenant with the default 10k chunk
size therefore runs ~20 chunks. At ~50 ms Neo4j RTT per chunk that is
~1 s of chunked DELETE plus the Postgres-side sweep (single SERIALIZABLE
transaction; typically <200 ms for tenants in this range).

---

## Audit-gap note

`gnokee_maintenance.forget_audit` (ADR-0026) **survives** a successful
`gnokee_forget_tenant(t)` by design. An audit row referencing a tenant
whose `episode_metadata` is empty is correct, not corruption — it proves
the deletion happened. Recovery / reconcile tooling that joins
`forget_audit ↔ episode_metadata` and treats empty-tenant rows as orphans
will mis-classify legitimate completed forgets.

The same applies to `gnokee_maintenance.ingest_audit` (ADR-0028 /
issue #198, v0.10): ingest audit rows record what was attempted and what
landed, and they outlive the tenant whose ingest they recorded.

To prune completed audit rows on a retention schedule, use
`prune_forget_audit` (see `src/gnokee/maintenance.py`) — it refuses to
delete `state='fail'` rows in the window, forcing the operator to
resolve them via `resume_forget` first. There is no equivalent prune for
`ingest_audit` in v0.10; gnokee never auto-DELETEs audit rows (retention
is bounded only by the deployment's compliance policy and the optional
operator-run pruner above). This is a *retention* property — write-side,
both `forget_audit` and `ingest_audit` are UPDATE-based state machines
on the `begin` row (see ADR-0026 and ADR-0028); only `ingest_journal`
(ADR-0024, crash recovery) is hard-append-only on writes.

---

## Quick reference

| Concern                              | Knob / source                                         |
|--------------------------------------|-------------------------------------------------------|
| SERIALIZABLE retry budget            | `GNOKEE_FORGET_RETRIES` (this doc)                    |
| Forget-lock acquire timeout          | `GNOKEE_FORGET_LOCK_TIMEOUT_MS` (Settings)            |
| Neo4j chunked-sweep threshold        | `GNOKEE_NEO4J_DETACH_CHUNK_THRESHOLD` (Settings, 100k)|
| Neo4j chunk size                     | `GNOKEE_NEO4J_DETACH_CHUNK_SIZE` (Settings, 10k)      |
| Resume a partial forget              | `gnokee_resume_forget` MCP tool / `maintenance.resume_forget` |
| Prune completed forget audit rows    | `prune_forget_audit` in `src/gnokee/maintenance.py`   |
