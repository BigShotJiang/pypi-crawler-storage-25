# Architecture

> Source-of-truth document for the gnokee memory layer. Mirrors the
> design originally drafted in Notion (`01 — Architecture`); from first
> commit forward, **this file** is canonical. Notion mirrors are
> discoverability surfaces only.

## Layered model

```text
┌─────────────────────────────────────────────────────────┐
│  Adapters (thin shims)                                  │
│  files / md-vault / api-push / rss / email / pulse-sdk  │
└────────────────┬────────────────────────────────────────┘
                  ↓ ingest_episode
┌─────────────────────────────────────────────────────────┐
│  gnokee core (the product)                              │
│    • ingestion: parse, normalize, classify, embed       │
│    • bi-temporal store, supersession, contradiction     │
│    • retrieval: semantic + BM25 + graph + temporal      │
│    • forgetting: tombstones + crypto erasure            │
│    • maintenance: dedupe, lint, synthesize              │
│    • MCP server (token-efficient)                       │
└────────────────┬────────────────────────────────────────┘
                  ↓
┌─────────────────────────────────────────────────────────┐
│  Backends (pluggable)                                   │
│  Graphiti (temporal KG) + Postgres + pgvector           │
│  Embeddings: bge-m3 via TEI / Ollama / OpenAI           │
└─────────────────────────────────────────────────────────┘
```

Top and bottom are commodity. The middle is where gnokee's IP lives.

## Service inventory (v0.1)

| Service       | Language               | Role                                                                          |
|---------------|------------------------|-------------------------------------------------------------------------------|
| `gnokee`      | Python 3.10+           | Single binary or compose stack: ingestion, retrieval, MCP, scheduler. Wraps Graphiti. |
| `gnokee-tei`  | Rust (HuggingFace TEI) | Embedding service, bge-m3 by default. Optional — consumer may bring own.      |
| `graphiti`    | (library)              | Bi-temporal KG primitive. Consumed in-process.                                |

v0.1 ships as `docker-compose.yml` (Postgres+pgvector + Neo4j + optional TEI).

## License boundary

**gnokee code is Apache 2.0.** Storage backends are external dependencies
that consumers run themselves; gnokee does not redistribute them.

| Layer | License | Provided by |
|---|---|---|
| `gnokee` Python package + container | Apache 2.0 | omurlabs (this repo) |
| `gnokee-tei` (optional) | Apache 2.0 | omurlabs (HuggingFace TEI as base) |
| Postgres + pgvector | PostgreSQL License | upstream / consumer-deployed |
| Neo4j Community server | GPLv3 | upstream / consumer-deployed |
| Graphiti library (Python dep) | Apache 2.0 | getzep/graphiti |
| bge-m3 weights | MIT | BAAI |

This is the same model pgvector users already accept for Postgres:
the application layer is permissively licensed; the storage layer is
whatever the consumer deploys, possibly under copyleft. Consumers
who need a strictly-permissive stack today can substitute Postgres
+ pgvector for the graph layer (with reduced functionality —
ADR-0005 documents the trade-off space).

## Core contracts

The shapes below live in [`src/gnokee/models.py`](../src/gnokee/models.py).

### Ingestion (`gnokee.ingest_episode(...)`)

- `tenant_id` — mandatory; `"default"` for single-user
- `content` xor `encrypted_body` — gnokee never holds keys when encrypted
- `valid_time_start` / `valid_time_end` — when the fact was true in the world
- `observed_time` — when the consumer learned of it (defaults to ingest time)
- `entity_type_hints` — advisory; Graphiti decides actual typing
- `sensitive` ∈ `public | private | clinical`
- `language` — ISO 639-1; auto-detect when null

### Retrieval (`gnokee.query(...)`)

- `as_of` — bi-temporal: "what did the system know on this date?"
- `valid_at` — bi-temporal: "facts true on this date?"
- `surface_contradictions=True` — return conflicting facts alongside primary
- `max_tokens=500` — response budget; ranker honors this
- Returns natural-language fact statements + lazy provenance + contradiction refs (not full bodies)

## Bi-temporal model

Every fact has two clocks:

- **valid time** — when the fact was true in the world
- **transaction time** — when the system learned of it

Queries can pin either or both. Supersession is **explicit and additive**:
fact A is never deleted when fact B replaces it; A's `transaction_time_end`
is set, A's `superseded_by = B.id`, B's `supersedes = A.id`. Time-travel
queries still find A.

## Contradiction handling

Contradictions are **detected at ingest, surfaced at retrieval, not auto-resolved**.

When a new episode produces fact F, gnokee searches for high-similarity
existing facts within the same entity context, asks an LLM whether each
candidate is `unrelated | refinement | update | contradiction`, and stores
the verdict as a graph edge. Retrieval returns F together with any live
`contradicts` edges. The MCP tool description nudges the consuming LLM to
reconcile (preferring more recent / higher confidence) **or** surface to
the user. gnokee never picks a winner.

## Forgetting

Three modes:

1. **Soft supersession** — `transaction_time_end` set; time-travel queries
   still find the old fact. Default for "I changed my mind" / "world changed".
2. **Hard delete with tombstone propagation** — vector index, graph,
   derived summaries all touched. Returns a `ForgetReceipt` enumerating
   affected artifacts.
3. **Cryptographic erasure** — destroy the per-fact DEK in the consumer's
   KMS; ciphertext becomes unreadable. Used when backups can't be selectively
   rewritten (clinical GDPR).

Hard delete is implemented by the `gnokee_forget_episode` + `gnokee_forget_tenant` MCP tools (ADR-0026). Both surfaces return a `ForgetReceipt` with `affected_key_ids[]` enumerating DEK identifiers the consumer must destroy in their KMS to complete Mode-3 cryptographic erasure (gnokee never holds keys).

**Time-travel incompatibility.** Mode 2 is incompatible with `valid_at` time-travel through pre-forget windows: a hard-deleted episode is unreachable via `as_of=<T before forget>` even when T predates the forget operation. Callers requiring time-travel through history must use Mode 1 (soft supersession via `EpisodeIn.corrects:`). See ADR-0026 §Consequences.

**gnokee never holds keys, never decrypts.** Per-tenant DEKs reference
consumer KMS (e.g. OpenBao for Omur). The `gnokee` name encodes this:
"no key" = arch invariant.

## Multi-tenancy

- `tenant_id` on every table, every API call, every MCP tool call
- Postgres RLS enforced via `set_config('app.current_tenant', ...)` GUC,
  set by gnokee's request middleware
- Per-tenant key envelope (`EncryptedBody.key_id` references consumer KMS)
- Tenant deletion (`gnokee_forget_tenant`) sweeps: `episode_metadata` + FK CASCADE through `content_embedding`, `content_text`, `episode_body_encrypted`, `episode_extracted_quote`, `lab_record`, `med_record`; explicit DELETEs for `fact_contradiction` + `ingest_journal` (no FK); Neo4j `DETACH DELETE` on `group_id`. A `forget_audit` row in the `gnokee_maintenance` schema survives tenant deletion as a verifiable-forgetting proof (ADR-0026).

## Concurrency

- **Ingest / forget mutual exclusion (issue #140).** `forget_episode` and `forget_tenant` acquire a per-tenant Postgres **exclusive** advisory lock — `pg_advisory_xact_lock(hashtext(tenant_id), hashtext('forget'))` — at the top of their SERIALIZABLE transaction. `ingest` Stage 5 acquires the **shared** flavour of the same key inside its own transaction. Multiple concurrent ingests on the same tenant coexist (shared with shared is non-blocking). A pending forget waits for every in-flight ingest to commit / roll back before its exclusive grant fires; new ingests then block until the forget commits, by which time they see the post-forget state (a `corrects:` pointer to a deleted episode fails the FK check honestly rather than producing an orphan). All locks are transaction-scoped — a crash mid-transaction releases the lock with the rollback.
- **Postgres SERIALIZABLE retry budget.** The forget pipeline retries the Postgres phase up to `_SERIALIZABLE_RETRIES` times before raising `ForgetContention`. Ingest does not retry serialization failures today — it surfaces them to the caller. The advisory lock above largely removes the need for retries on the ingest/forget axis; ingest/ingest contention is shaped by row-level locks on `episode_metadata` rather than serialization conflicts.
- **Forget lock timeout (issue #153).** Before each exclusive advisory-lock acquire, the forget pipeline runs `SET LOCAL lock_timeout = $GNOKEE_FORGET_LOCK_TIMEOUT_MS` (default `30000` — 30 seconds). If a long-running or stalled ingest holds the shared lock past this budget, Postgres cancels the lock-wait with sqlstate `55P03` and gnokee raises `ForgetContention(tenant_id=…, timeout_ms=…, waited_ms=…)` rather than blocking until `idle_in_transaction_session_timeout` (often >5 min, not operator-controllable from gnokee config). Raise the knob for tenants with very long ingests; lower it for fast probes; set it to `0` to disable the timeout entirely.
- **Neo4j sweep is post-Postgres.** The Neo4j phase of forget runs *outside* the Postgres transaction (and therefore outside the advisory-lock window). A Neo4j failure leaves a `state='fail'` audit row; `resume_forget` re-drives the sweep without re-acquiring the Postgres lock. Concurrent ingest during a Neo4j-only fail-window writes through normally — the Postgres state is already post-forget, the Neo4j gap converges on the next `resume_forget` call.

## Backend choices (v0.1)

- **Graph store:** Neo4j Community (Graphiti default). v0.1 *and* v0.2.
  Per [ADR-0005](adr/0005-graph-backend-tradeoff.md): FalkorDB
  dropped on SSPL grounds; Kùzu archived; Apache AGE deferred (5–7
  person-weeks realistic effort, blockers on vector cosine and
  fulltext). Re-open the decision when on-prem-non-GPL distribution
  or ops-consolidation triggers it.
- **Vector store:** pgvector. Postgres is already present for facts; one
  fewer service. **Stores per-episode `content_embedding`** keyed by
  `(tenant_id, episode_uuid)` — gnokee writes this alongside every
  `Graphiti.add_episode` call. See ADR-0004.
- **Embeddings:** bge-m3 via HuggingFace TEI, single instance, GPU-optional.
  Ollama embeddings as dev fallback. Q2 spike validated cross-lingual
  retrieval at 100% top-1 over en/ru/bg/he via direct cosine on
  full-episode content; this is the v0.1 retrieval primitive.
- **LLM (entity extraction + maintenance synthesis):** consumer-supplied via
  OpenAI-compatible endpoint. gnokee doesn't host LLMs.

## Retrieval path (v0.1, per ADR-0004)

`gnokee.query(...)` does **not** call `Graphiti.search_()`. Instead:

1. Embed the user query via the configured bge-m3 endpoint
2. Cypher narrows the candidate set: `MATCH (ep:Episodic)
   WHERE ep.group_id = $tenant AND <bi-temporal filters>` —
   `valid_at` ≤ as-of, optional `asserted_at` ≤ tx-as-of
   (gnokee-managed via `episode_metadata`, not Graphiti's `created_at`)
3. Fetch candidate `content_embedding`s from pgvector, rank by cosine
4. Join Graphiti's edge facts (supersession, contradictions) onto the
   top-K episodes for surfacing

Graphiti's `COMBINED_HYBRID_SEARCH_RRF` and the `SearchFilters` API
are **not** on the v0.1 hot path. The Q2 spike showed they rank
structurally rather than by query relevance at our corpus shape
(many short single-fact episodes).

## Durability — ingest crash-recovery journal (ADR-0024, v0.7+)

Stage 4 (Neo4j lite-Episodic) and Stage 5 (Postgres txn covering
`episode_metadata` + `content_embedding` + `content_text` +
`episode_body_encrypted` + `lab_record` + `med_record`) are written
in sequence on two stores that share no transaction. v0.6 Z1-B
(ADR-0023) closed the Graphiti half of the two-store coordination
problem; v0.7 closes the Postgres half with an append-only journal.

**Journal shape (`ingest_journal` table, migration `0015`).**

| Row | When written | Carries |
|---|---|---|
| `begin` | After Stage 3.5 (`episode_uuid` known), before Stage 4 | `payload_hash = SHA256(tenant_id ‖ our_id ‖ valid_at)` + `stage_4_time` |
| `commit` | After Stage 5 txn returns success (outside that txn) | same `payload_hash` + `stage_4_time` |
| `fail` | Exception escaped Stage 4 or Stage 5, after compensation | `error` string |

PK = `(tenant_id, episode_uuid, state, seq)`; partial index on
`state='begin'` keeps the resumable-scan path cheap. RLS via
`app.current_tenant` GUC isolates rows per tenant.

**What the journal closes.**

A controlled exception in Stage 5 (Postgres down, idempotency-race
vanished winner, etc.) goes through the existing `_compensate` path
that removes the lite-Episodic. The journal adds a `fail` row for
audit but does not change the outcome.

A **container kill / OOM / `KeyboardInterrupt`** between Stage 4
success and Stage 5 commit bypasses the `except` handlers entirely —
no compensation, no `fail` row. The Stage 4 Episodic survives in
Neo4j with no Postgres row keying it. Before ADR-0024 this was a
silent durability gap (recall Stage 2a could see the orphan).
Post-ADR-0024 the `begin` row stays in place and `scan_resumable`
surfaces it on the next ingest per tenant per process as a
`ResumableIngest` log warning. gnokee **never auto-replays.**

**Opt-in recovery.** Operators (or the consumer's runbook) call
`gnokee.resume_ingest(tenant_id, episode_uuid, episode, *, pipeline)`,
re-supplying the original `EpisodeIn`:

1. Payload hash validated against the journaled `begin` row — drift
   → `IngestJournalError`, no store touch.
2. Stage 4 re-executes with `created_at = stage_4_time`; Neo4j
   `MERGE` is idempotent on `uuid` so `Episodic.created_at` (ADR-0004
   axis-3) is preserved across replay.
3. Stage 5 re-executes; every Stage 5 insert uses `ON CONFLICT DO
   NOTHING` or `DO UPDATE` (audited 2026-05-16) so the whole txn is
   end-to-end idempotent.
4. `commit` row appended; `scan_resumable` no longer surfaces the
   entry.

Stage 6 (Graphiti narrative enhancement) is force-disabled on resume
— `run_deferred_extraction` covers that pass via the existing
`extraction_deferred` flag (ADR-0023).

**Cost.** Two extra Postgres inserts per ingest, plus one
`scan_resumable` SELECT per tenant per process. Q19 spike measured a
2.17% median regression on `extract=False` ingests (101.93 ms vs
99.76 ms baseline; threshold 10%).

**Why consumer-resupply over journaled payload.** Storing the
`EpisodeIn` bytes in the journal would persist plaintext (or force a
new encrypted-body branch for the journal), contradicting gnokee's
"never holds plaintext after embed" red line. The journal carries
only a hash; the consumer keeps the original until `commit` lands.

## Encrypted-body lifecycle (issue #22, v0.3+)

`EpisodeIn` accepts `content` xor `encrypted_body` (Pydantic
`model_validator`); both/neither are rejected at the Stage 1 boundary.
On the `encrypted_body` branch, gnokee NEVER holds key material and
NEVER decrypts: the consumer encrypts in-process with a DEK they own
and hands gnokee the `(ciphertext, nonce, key_id)` triple. Stage 4
(Graphiti `add_episode`) is force-skipped because the LLM extractor
needs plaintext narrative gnokee doesn't have. Stage 3 (embed) runs
ONLY when the consumer opted in via `EncryptedBody.content_for_embedding`
— the plaintext window is dropped immediately after `embed()` returns
and is never persisted; only the resulting 1024-dim cosine vector
lands in `content_embedding`. Ciphertext is stored in the sibling
`episode_body_encrypted` table (FK + ON DELETE CASCADE to
`episode_metadata`, same shape as `content_embedding`). On recall,
encrypted episodes are skipped from the plaintext-only `excerpts[]`
and `episode_fallback[]` lanes and surfaced verbatim in
`RecallResponse.encrypted_bodies[]` (and `FactProvenance.encrypted_body`
on lazy fetch). The consumer's session-side code decrypts via their
KMS using `key_id`. `corrects:` is orthogonal — supersession is
metadata on `episode_metadata`, not body shape, so encrypted episodes
participate in supersession chains exactly like plaintext ones.

## Out of scope for v0.1

- Federation between gnokee instances
- Real-time streaming retrieval
- UI of any kind
- Auth provider (consumer handles)
- Workflow orchestration (consumer handles)
- Document parsing pipeline (consumer hands episodes pre-parsed)
- Multi-modal beyond text (images, audio — v2)
- Federated learning, homomorphic encryption, ZK proofs (not in scope)

## Pre-implementation gates

Before any v0.1 feature work, the spikes in `docs/adr/` must resolve:

- ADR-0001: Graphiti's bi-temporal model fits the two consumer corpora.
  **Resolved 2026-05-08:** Accepted as storage primitive (Q1 v2.1).
- ADR-0004: gnokee owns retrieval; Graphiti is the storage primitive.
  **Resolved 2026-05-08:** Q2 direct-cosine baseline = 100% top-1
  cross-lingual on the same corpus where Graphiti's combined search
  scored 25%. Per-episode content embedding in pgvector + Cypher-side
  bi-temporal filter is the v0.1 retrieval primitive.
- (further ADRs added as decisions land)
