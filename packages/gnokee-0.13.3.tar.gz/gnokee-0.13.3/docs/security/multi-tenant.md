# Multi-tenant boundary — threat model + audit findings

- **Status:** v0.12 draft (2026-05-20)
- **Audit driver:** [#246](https://github.com/omurlabs/gnokee/issues/246) — tenant_id boundary audit for single-process MCP server.
- **Plan:** [docs/plans/2026-05-20-v0.12-mcp-revival.md](../plans/2026-05-20-v0.12-mcp-revival.md).
- **Pairs with:** [ADR-0030](../adr/0030-mcp-auth-surface.md) (auth surface). Auth answers "who can claim this `tenant_id`?"; this doc answers "even with the right `tenant_id`, can state leak across tenants in the layers underneath?".

## Trust boundary

gnokee is a **single-process, multi-tenant memory store**. In Option C deployment (omur#472), one OS process serves multiple tenant clients concurrently. Inside that process, the tenant boundary is:

- **Postgres:** Row-level security (RLS) gated by `set_config('app.current_tenant', <tenant_id>, true)` GUC, plus `WHERE tenant_id = $1` predicate in every application query. Belt-and-braces. ADR-0004, ADR-0026.
- **Neo4j:** `group_id` discipline. Every Cypher node and edge filter carries `group_id = $tenant`. ADR-0005 (Community edition — no enterprise RLS equivalent; predicate discipline IS the boundary).
- **Short-ID layer:** Lookup table keyed by `(tenant_id, kind, target_uuid)`. ADR-0027.
- **In-memory:** `App` singleton holds tenant-stateless objects (pools, HTTP clients). All per-tenant work flows through the `tenant_id` parameter on every public function.

## Trusted vs untrusted inputs

| Layer | Tenant input | Trust model |
|---|---|---|
| Python API (`gnokee.ingest_episode`, `gnokee.recall`, `gnokee.forget_episode`) | `tenant_id: str` arg | Trusted — caller IS the boundary (Marrow today; library-mode opt-out per ADR-0030 §"Library-mode opt-out invariant"). |
| MCP stdio | `tenant_id: str` arg | Trusted — OS process boundary IS the trust boundary (subprocess spawned by user session). |
| MCP streamable-http, `auth=None` | `tenant_id: str` arg | Trusted — operator opted into trust mode (dev / single-tenant deploy). |
| MCP streamable-http, `auth=BearerJWTBackend(...)` | `tenant_id: str` arg, validated against `Principal.allowed_tenants` from verified JWT | Untrusted at the wire; verified before tool body runs (per-tool `_tenant_guard` decorator, ADR-0030). |
| Postgres | application `tenant_id` arg + RLS GUC | Trusted application layer; RLS is defence-in-depth. |
| Neo4j | application `group_id` arg | Trusted — Community edition has no DB-level enforcement. Predicate discipline is the line. |

## Audit (2026-05-20)

Read-only sweep of six areas. No LEAK severity findings. Four NOTE-grade items documented below.

### Area 1 — Storage queries (Postgres)

`src/gnokee/storage/{metadata,vector,journal,contradictions,forget_audit}.py` — every self-contained method sets the `app.current_tenant` GUC at transaction start (per #220 sweep + v0.11.1 follow-up PRs #283 / #286) and applies `WHERE tenant_id = $1` in the query body. Verdict: **CLEAN**.

**NOTE-1 — `metadata.py:725` `supersede` chain-walk SELECT.** ~~The `FOR UPDATE` predicate is `WHERE episode_uuid = $1` only — no `tenant_id` column predicate at the DB level. Cross-tenant defence comes from the post-fetch Python guard (`row["tenant_id"] != tenant_id` → `CorrectsCrossTenantError`).~~ **Resolved 2026-05-20 (#297).** SELECT predicate now includes `AND tenant_id = $2`; the canonical `CorrectsCrossTenantError` surface is preserved via a follow-up probe when the predicate misses (so #234 hint + integration-test expectations stay intact).

**NOTE-2 — `forget_audit.py:276` operator-only methods.** `find_all_failed_neo4j_rows` and `iter_for_prune` / `delete_for_prune` accept `tenant_id=None` and produce cross-tenant SQL by design. Both target the `gnokee_maintenance` schema which is documented in ADR-0026 §"Schema isolation rationale" as having no RLS. These are operator-CLI paths, not MCP-surface paths. No tenant leak from any MCP tool. **Status:** working as designed.

**NOTE-3 — `metadata.py:240` `fetch_deferred`.** Receives a caller-supplied connection; depends on the maintenance caller setting the GUC before invocation. The docstring acknowledges this. The maintenance call-sites are out of this audit's scope (operator-only). **Status:** working as designed — discipline contract documented at the call-site.

### Area 2 — Neo4j / Graphiti

`src/gnokee/storage/graph.py` — every Cypher query filters by `group_id` on both nodes and edges. `add_episode`, `write_lite_episode`, `remove_lite_episode`, `fetch_provenance`, `fetch_facts_for_episodes`, `list_entities_for_tenant`, `fetch_facts_for_entity`, `list_episode_edge_triples`, `list_edges_in_window`, `remove_tenant_group`, `remove_episodes_by_uuid` — all confirmed. Graphiti `add_episode` calls in `src/gnokee/ingest.py` pass `group_id=tenant_id` on every call. Verdict: **CLEAN**.

**NOTE-4 — Neo4j vector index is global.** `graph.py:1157` `cosine_search_facts` calls `db.index.vector.queryRelationships` which returns the top-K nearest-neighbour edges across ALL tenants, then filters `WHERE r.group_id = $tenant` in the post-ANN clause. Standard Neo4j 5 Community limitation — vector indexes cannot be partitioned by a predicate. Cross-tenant edges are fetched from Neo4j's index machinery and discarded inside the Cypher engine before any data reaches the Python layer. No leak. Latency implications (cross-tenant ANN noise inflates K) and timing-side-channel implications (very narrow) are documented but not mitigated in v0.12. Mitigation candidates if a driver appears: (a) per-tenant Neo4j databases (Enterprise feature, rejected by ADR-0005), (b) per-tenant vector indexes (no Neo4j-level support), (c) increase ANN K with post-filter (already done by Graphiti search). **Status:** working as designed within Community-edition constraints.

### Area 3 — In-memory caches

`src/gnokee/bootstrap.py` — `App` holds `asyncpg.Pool`, `Graphiti` instance, `TEIClient`, `OpenAIClient`, `OmkitKeyResolver`. All connection-per-request or HTTP-client per-call. No tenant-keyed memoization. Pipeline objects (`IngestPipeline`, `RecallPipeline`, etc.) accept `tenant_id` per-call and hold no per-tenant mutable state. Verdict: **CLEAN**.

`OmkitKeyResolver` (line 104) wraps a KMS client shared across tenants; each `unwrap` call carries `tenant_id` + `episode_uuid` in AAD, so cross-tenant unwrap attempts fail at the GCM auth tag (encryption-layer defence, not RLS-layer).

### Area 4 — Short-ID translation

`src/gnokee/mcp/short_id.py` — table keyed by `(tenant_id, kind, target_uuid)`. `encode` fast-path SELECT, slow-path re-check, and `decode` all carry the three-column predicate. A short ID minted for tenant A (`ep_1`) returns NULL for tenant B and raises `ValidationError`. Verdict: **CLEAN**.

Advisory-lock key (line 86) is `hashtext(tenant_id) + hashtext(kind)` — two 32-bit slots, ~69% birthday collision at 100k tenants. Collision causes spurious contention only; the `INSERT … ON CONFLICT DO NOTHING` + final re-read guarantee correctness under collision. Same pattern as #151 fix in `locks.py` (which moved to 64-bit MD5). Contention-grade concern, not isolation. **Status:** acceptable for v0.12; revisit if tenant population approaches 100k.

### Area 5 — Async-context / contextvars

`src/gnokee/tenant_ctx.py:28` — `_native_tenant: ContextVar[str | None]` with `default=None`. `bind_tenant` uses `token = _native_tenant.set(...)` and `_native_tenant.reset(token)` in `finally` — task-local, resets correctly even on exception. Verdict: **CLEAN**.

Fall-through to omkit's contextvar (line 31) when omkit is installed: `current_tenant()` ORs `_native_tenant` with the omkit value. `current_tenant()` is used for log correlation only, NOT for storage scoping. `tenant_id` flows through explicit function arguments to every storage call. Even if an upstream ASGI middleware populated omkit's contextvar with a different tenant, no storage path would observe it. **Status:** working as designed.

`structlog.contextvars.merge_contextvars` in `src/gnokee/logging.py:35` reads from structlog's own per-task store — structlog-internal, task-scoped. **Status:** clean.

### Area 6 — Error paths + logs

Exception messages and log payloads were grepped for cross-tenant identifiers. None found. Module-level `log = logging.getLogger(__name__)` (line 90) binds no tenant data. `IngestJournalError` message embeds the affected row's own `tenant_id` + `episode_uuid` only — never a foreign tenant's. Verdict: **CLEAN**.

`forget_tenant` operator-telemetry INFO log (`graph.py:384`) emits the acting tenant's own `tenant_id`. PII-in-logs policy worth documenting if operator-log retention is reviewed, but no cross-tenant identifier appears.

## Summary

| Area | Verdict |
|---|---|
| 1. Storage queries (Postgres) | CLEAN; NOTE-1 (supersede SELECT belt+braces) **resolved 2026-05-20 (#297)**; NOTE-2/NOTE-3 (operator-only paths) |
| 2. Neo4j / Graphiti | CLEAN; NOTE-4 (global vector index — Community-edition limit, no leak) |
| 3. In-memory caches | CLEAN |
| 4. Short-ID translation | CLEAN; contention-only advisory-lock collision risk at 100k+ tenants |
| 5. Async-context / contextvars | CLEAN |
| 6. Error paths + logs | CLEAN |

**Follow-up status:** NOTE-1 belt+braces `tenant_id` predicate on `metadata.py` `supersede` chain-walk SELECT — **resolved 2026-05-20 (#297)**.

The process-level `App` singleton is safe for the single-process multi-tenant deployment shape as currently implemented. The remaining NOTEs are working-as-designed or document-only.

## What this audit does NOT cover

- **Authentication.** Who is allowed to claim a `tenant_id` at the MCP wire is a separate concern — see [ADR-0030](../adr/0030-mcp-auth-surface.md).
- **Streamable-http transport hardening.** Connection-lifecycle, TLS, back-pressure — see issue [#245](https://github.com/omurlabs/gnokee/issues/245) and `docs/deployment-mcp-http.md`.
- **Per-tool scoping** (read-only principal vs forget principal). Out of scope for v0.12; ADR-0030 §"Open questions".
- **Side-channel / timing attacks** at the global Neo4j vector-index level. Documented above; mitigation deferred.

## Test coverage

`tests/integration/test_tenant_isolation.py` (added in v0.12) is the regression bar. Six cases:

1. Ingest 3 episodes in tenant_a, 3 in tenant_b interleaved; `recall(tenant_a)` returns 3 a-episodes, 0 b-episodes; vice versa.
2. Short-ID `ep_1` minted in tenant_a does NOT resolve in tenant_b (`ValidationError`).
3. Provenance handle (`fact_uuid`) from tenant_a's recall is unusable in tenant_b's `history_of` (returns empty).
4. `forget_episode(tenant_a, ep_1)` does NOT touch any tenant_b episode.
5. Postgres `app.current_tenant` GUC interleaved — set tenant_a, call, set tenant_b, call — no spillover.
6. Graphiti `group_id` interleaved — `add_episode(group_id="tenant_a")` then `search_(group_id="tenant_b")` returns no a-results.

## Amendment 2026-05-22 — v0.12.2 specialist scope-verdict adjustments

Three defense-in-depth additions landed post-v0.12.1 (security-reviewer
HIGH findings + ci-engineer):

1. **`BearerJWTBackend` construction-time guards.** Algorithm allowlist
   (no `alg=none`), asymmetric-with-non-PEM refused, symmetric-with-PEM
   refused with explicit "alg-confusion attack class" message. HMAC
   gated behind explicit `_allow_hmac=True` (production deploys MUST
   use asymmetric to satisfy "gnokee never holds keys").
2. **`MCPTokenVerifier.verify_token` defensive contextvar reset.**
   `_current_principal.set(None)` at top of `verify_token` clears any
   stale binding from a (theoretical) pooled-task scenario. Pairs with
   the existing `.set(principal)` on success.
3. **`_assert_http_auth_safety` startup gate.** `GNOKEE_MCP_HTTP=1`
   with no `GNOKEE_MCP_AUTH_KIND` refuses to start. Escape hatch
   `GNOKEE_MCP_HTTP_ALLOW_UNAUTHENTICATED={1,true,yes}` for behind-a-
   trusted-reverse-proxy deploys; emits WARNING log at boot.

`/readyz` failure envelope emits literal `"err"` (not the Python
exception class name) — class names leak infrastructure topology on
an endpoint that MUST stay auth-bypassed. Detailed exception class
names land in structured logs only.

`GNOKEE_MCP_HOST` + `GNOKEE_MCP_PORT` env vars added; default
`127.0.0.1:8000` matches FastMCP upstream default (loopback-only).

## Cross-refs

- ADR-0004 (`tenant_id` contract on every API + table + MCP call).
- ADR-0005 (Neo4j Community edition; `group_id` discipline is the boundary).
- ADR-0026 (`gnokee_maintenance.forget_audit` no-RLS schema rationale; operator-only paths).
- ADR-0027 (short-ID translation, `(tenant_id, kind, target_uuid)` key).
- ADR-0030 (MCP auth surface; principal-to-`tenant_id` binding).
- PR #283 (RLS GUC sweep on `fact_history` + vector read paths).
- PR #286 (RLS GUC on remaining application read paths).
- Issue #151 (advisory-lock key migration to 64-bit MD5 in `locks.py`).
- Issue #246 (this audit's driver).
