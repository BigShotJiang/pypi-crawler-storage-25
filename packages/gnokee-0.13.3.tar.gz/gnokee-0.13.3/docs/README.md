# gnokee documentation

> Status: pre-1.0. The public Python API and MCP tool surface may
> break across minor versions per [ADRs](adr/). The bi-temporal
> storage contract, the "no key" invariant, and the contradiction
> non-resolution rule are stable design choices and will not change.

This is the entry map. The companion [`AGENTS.md`](../AGENTS.md) is
the agent-facing convention guide.

---

## Evaluating gnokee

Choose this branch if you're trying to decide whether gnokee fits
your problem.

| Doc | What's inside |
|---|---|
| [`../README.md`](../README.md) | Project overview, quickstart, MCP tool list, env vars, status. Start here. |
| [`faq.md`](faq.md) | "Is gnokee for me?", "why not Mem0?", "do I need Neo4j?", "Mac arm64 + TEI?", "production-ready?", "what's lite mode?", "what's encrypted_body?", "how is forgetting different?". |
| [`alternatives.md`](alternatives.md) | gnokee vs Mem0 / Graphiti-alone / Zep-OSS / basic-memory. Honest about [ADR-0012](adr/0012-cross-tool-eval-verdict.md) verdict (gnokee currently REJECT on LongMemEval-S strict; bottleneck = synth-prompt abstention bias per #62). |
| [`architecture.md`](architecture.md) | Layered model, service inventory, license boundary, bi-temporal model, contradiction handling, forgetting, multi-tenancy, retrieval path, encrypted-body lifecycle. The canonical design doc. |
| [`adr/`](adr/) | Architecture Decision Records — one file per locked decision. Skim ADR-0001, 0004, 0005, 0008, 0009, 0010, 0011, 0012 for the load-bearing ones. |
| [`evals/methodology.md`](evals/methodology.md) | How gnokee evaluates itself. Spike harness pattern, Q-numbered decisions, eval-delta gate. |
| [`eval_delta_gate.md`](eval_delta_gate.md) | The PR-merge gate that prevents eval regressions on ingest / retrieval / contradiction code. |

---

## Integrating gnokee

Choose this branch if you're wiring gnokee into a consumer
application as a library, MCP server, or both.

| Doc | What's inside |
|---|---|
| [`integration_patterns.md`](integration_patterns.md) | Lite vs full ingest, deferred extraction, recall behaviour across the backfill window, encrypted-body branch interaction. The integrator decision contract. |
| [`integration/consumer-patterns.md`](integration/consumer-patterns.md) | Body-render recipes for the typed parsers (lab + med), parser-driven vs hint-driven typed rows, async publish / outbox pattern, two-layer split, boundary invariants. |
| [`api/python.md`](api/python.md) | Python API reference. `ingest_episode`, `recall`, `fact_provenance`, `lab_query`, `med_query`, `run_deferred_extraction` — signatures, parameters, raises, examples. |
| [`api/mcp.md`](api/mcp.md) | MCP tool reference. Five `gnokee_*` tools — input/output schemas, parameter descriptions, JSON examples, transport modes. |
| [`extending.md`](extending.md) | Extension points: writing an ingest adapter, swapping the embedder, swapping the LLM endpoint, future Graphiti backend swaps. Stability promise per surface. |
| [`../examples/`](../examples/) | Runnable consumer recipes — quickstart, lite-mode + outbox, MCP-client config (Claude Desktop / Code / Cursor), encrypted-body, clinical body-render. |
| [`specs/v0.1.md`](specs/v0.1.md) + [`specs/v0.2.md`](specs/v0.2.md) | Implementation specs. Lower level than API ref; useful when integrating non-trivially. |

---

## Operating gnokee

Choose this branch if you're deploying gnokee somewhere a non-author
will run it.

| Doc | What's inside |
|---|---|
| [`deploy.md`](deploy.md) | Image pinning (TEI / Postgres / Neo4j), secrets, Postgres RLS GUC pattern, healthchecks, named volumes, scaling (single-tenant per binary, horizontal scaling on shared backends), resource floors. v0.1 docker-compose is dev-only. |
| [`observability.md`](observability.md) | What gnokee logs (structlog JSON: `tenant_id`, `episode_uuid`, `latency_ms`, `stage`); what gnokee never logs (content body, embeddings, LLM prompts). v0.1 logs only; v0.2+ Prometheus + OTel roadmap. Recall + ingest receipt telemetry shape. |
| [`privacy-posture.md`](privacy-posture.md) | Threat model, "no key" invariant, encrypted-body lifecycle, tenant isolation (Postgres RLS + Neo4j `group_id` discipline), what's stored vs not, LLM-endpoint exposure, GDPR alignment via three forgetting modes. What gnokee is NOT (not a HIPAA BAA, not a SOC2 attestation). |
| [`troubleshooting.md`](troubleshooting.md) | Symptom → cause → fix. Compose stack quirks, TEI on Mac arm64, pgvector dim mismatch, empty recall causes, contradiction degraded path, idempotency duplicates, MCP transport, RLS GUC. |

---

## Contributing to gnokee

Choose this branch if you're filing issues, opening PRs, or
maintaining the project.

| Doc | What's inside |
|---|---|
| [`../CONTRIBUTING.md`](../CONTRIBUTING.md) | Contribution stance (open with guardrails), dev setup, coding standards, workflow, review process. Start here. |
| [`../AGENTS.md`](../AGENTS.md) | Agent convention guide. Reviewer routing table, hard "do not" list, naming conventions. Normative for every PR. |
| [`releasing.md`](releasing.md) | Release flow (tag-driven, OIDC Trusted Publishing). Maintainer-facing. |
| [`eval_delta_gate.md`](eval_delta_gate.md) | The eval-delta contract for PRs touching ingest / retrieval / contradiction paths. |
| [`backlog.md`](backlog.md) | Living index of post-release work. GitHub issues are source-of-truth. |
| [`adr/`](adr/) | How to write a new ADR — copy the shape of an existing one. ADR-only PRs bypass reviewer routing. |
| [`specs/`](specs/) | Implementation specs. New specs land here as features stabilise. |
| [`upstream-contributions/`](upstream-contributions/) | Drafts of PRs we're sending upstream (graphiti-core, etc.). |
| [`superpowers/`](superpowers/) | Internal artefacts from brainstorming + plan sessions. Useful for tracing the *why* behind a feature. |
| [`../SECURITY.md`](../SECURITY.md) + [`../CODE_OF_CONDUCT.md`](../CODE_OF_CONDUCT.md) + [`../SUPPORT.md`](../SUPPORT.md) | Governance docs at the repo root. |

---

## Convention

- This file is the canonical entry map. Every other doc in `docs/`
  links back here.
- New docs added to `docs/` should also be linked from this index,
  in the audience section that fits best.
- Doc files don't move once published — external links (ADRs, PRs,
  Notion mirrors) depend on stable paths. Rewrite content in place;
  rename only via redirect.
