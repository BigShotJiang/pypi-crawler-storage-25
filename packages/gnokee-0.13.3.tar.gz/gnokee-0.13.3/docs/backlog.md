# gnokee backlog

Living index of post-v0.2.x work. Each item links to its tracking GitHub issue. Items get promoted from this doc to a release scope (v0.3, v0.4, etc.) as they pick up momentum.

Source of truth is the GitHub issue. This doc is the table of contents.

## v0.13.1 — patch scope (LANDED + CUT 2026-05-23 — "image-publish fix + post-tag CI hardening")

Tagged `v0.13.1` on 2026-05-23. PyPI live (`pip install gnokee==0.13.1`);
**first published container image** at `ghcr.io/omurlabs/gnokee:0.13.1`
+ `:0.13`. The image publish was scoped to v0.13.0 originally but a
Dockerfile-context bug (missing `static/` COPY → hatchling
`force-include` failed) and a Trivy action tag-prefix typo surfaced
post-tag; v0.13.0 ships PyPI-only and v0.13.1 lands the image.

Patch contents (commits on top of v0.13.0):

| # | Title | Where |
|---|---|---|
| fix(docker) | COPY `static/` for hatchling force-include manifests | PR `66a280c` |
| fix(ci) | Pin `aquasecurity/trivy-action@v0.36.0` (tag prefix + latest stable) | PR `bc0cbbf` |
| fix(lint) | Drop unused `asyncio` import in 100-session smoke scaffold | PR `90b1abe` |
| fix(lint) | `ruff format` collapse on `ForgetReceiptDetail.cascaded_episode_uuids` description | PR `5e4eaf8` |

## v0.13.0 — release scope (LANDED + CUT 2026-05-23 — "tenant-aware retrieval scaffolding")

Tagged `v0.13.0` on 2026-05-23. PyPI live (`pip install gnokee==0.13.0`).
**No published container image** in this tag — the image-publish work
surfaced two post-tag bugs (Dockerfile `static/` copy + Trivy action
tag prefix) and lands in v0.13.1. Release:
https://github.com/omurlabs/gnokee/releases/tag/v0.13.0

Source: 2026-05-22 specialist scope-verdict sweep over post-v0.12.2 open
issues + deferred items. v0.13.0 ships the GREEN + KILL + trivial
verdicts from the sweep autonomously; YELLOW items requiring design
decisions (#303-pg pgvector `iterative_scan` ADR, #71 competitive
landscape doc) carry to v0.13.1 / later.

| # | Title | Where |
|---|---|---|
| ADR-0005 90-day re-check log | Inline log table replacing GH-watch issue #91 (closed YELLOW→KILL per `neo4j-ops-specialist` sweep verdict) | PR `3285466` |
| Plan-doc `_tenant_guard` cleanup | Retired the decorator design; pinned shipped inline `enforce_tenant_authority(tenant_id)` per ADR-0030 amendment 2026-05-22 §D | PR `3285466` |
| ForgetReceipt `episode_id` alias | Additive `episode_id` / `deepest_episode_id` / `cascaded_episode_ids` on the forget envelope; legacy `*_uuid` keys drop in v0.13.1 (gnokee-mcp-tool-designer GREEN) | PR `0f5547c` |
| GHCR build+push + Trivy SARIF | First published container image + Dockerfile + Trivy SARIF on publish path (`ci-engineer` YELLOW); cosign + SBOM deferred to v0.13.1 | PR `43a100e` |
| Eval-delta gate scaffolding (#305) | Shared helper + Q1 reference impl + CI stub `continue-on-error: true`; Q3/Q4/Q7/Q8 wiring carries as #312 (`eval-spike-author` + `ci-engineer` YELLOW) | PR `6c6adb8` |

Pre-impl gates: per-item specialist scope-verdict reads (GREEN/YELLOW/KILL)
folded into the 2026-05-22 sweep before any code edit; impl-shape
verdicts re-dispatched at code time for the GHCR Dockerfile, the
ForgetReceipt validator, and the eval-delta helper module.

Out of scope for v0.13.0 (deferred to v0.13.1 / v0.13.2+ / later):

- #303-pg pgvector tenant-filter `iterative_scan` ADR — needs design
  decision (partial-HNSW vs `iterative_scan` defaults, ANN cutoff).
- #71 competitive landscape 2026-Q2 — market research, manual signal.
- Cosign signing + SBOM attestation on the GHCR image (v0.13.1).
- ForgetReceipt `episode_uuid` / `deepest_episode_uuid` /
  `cascaded_episode_uuids` legacy key drop (v0.13.1 after one
  deprecation cycle).
- Eval-delta gate Q3/Q4/Q7/Q8 runner wiring + baseline capture
  (#312 follow-up; gate stays `continue-on-error: true` until then).
- Neo4j PROFILE for #303-neo4j tenant pushdown decision (v0.13.1).
- Full live-stack 100-session HTTP smoke test (v0.13.1; needs runner-
  side `LimitNOFILE=65536` per `docs/ci/self-hosted-runner.md`).

## v0.12.2 — patch scope (LANDED + CUT 2026-05-22 — "specialist scope-verdict hardening")

Tagged `v0.12.2` on 2026-05-22T13:32Z. PyPI live (`pip install gnokee==0.12.2`).
Release: https://github.com/omurlabs/gnokee/releases/tag/v0.12.2

Source: 2026-05-22 specialist scope-verdict sweep (gnokee-mcp-tool-designer
+ security-reviewer + ci-engineer) over the v0.12 MCP-revival surface.
Three HIGH-severity security findings closed + /readyz hardening +
bind-address knobs + CI migration to self-hosted runners + docs sweep.
No behavior change for stdio / library-mode callers; production HTTP
deploys gain stricter construction-time + boot-time guards.

| # | Title | Where |
|---|---|---|
| ADR-0030 amendment 2026-05-22 | Four implementation-drift pin-downs (synthetic Bearer header / JWKS rotation gap / no-wildcard tenant_claim / inline enforce_tenant_authority) | PR `147a318` |
| Security HIGH #1 | `BearerJWTBackend` alg-confusion construction guards + `_allow_hmac` opt-in | PR `32ee55b` |
| Security HIGH #2 | `MCPTokenVerifier.verify_token` defensive contextvar reset | PR `5763787` |
| Security HIGH #3 | `_assert_http_auth_safety` startup gate (refuses `GNOKEE_MCP_HTTP=1` + `auth=None`) | PR `bba2e6a` |
| /readyz hardening | Error envelope strips Python exception class names + `GNOKEE_MCP_HOST/PORT` env vars | PR `178797f` |
| Smoke-test scaffold | `tests/integration/test_mcp_streamable_http.py` 100-session pool-counter check | PR `0b06e1f` |
| CI runbook | `docs/ci/self-hosted-runner.md` (ulimit + TLS-at-proxy + PyPI OIDC notes) | PR `f3c2864` |
| GHCR image note | Strip `ghcr.io/omurlabs/gnokee:0.12.x` from compose snippet; local-build path | PR `fa07477` |
| Docs sweep | README + CHANGELOG + `docs/security/multi-tenant.md` | PR `02a030d` |
| CI self-hosted migration | `pypi-publish.yml` to `[self-hosted, linux, x64]` + manual OIDC mint-token flow for DinD compat | PRs `4d1fcab`, `61af746` |

Pre-impl gates: parallel specialist scope-verdict reads (GREEN/YELLOW/RED)
ran 2026-05-22 before any code edit per `feedback_specialist_scope_first`.

Out of scope for v0.12.2 (deferred to v0.13+):
- Plan doc `docs/plans/2026-05-20-v0.12-mcp-revival.md` §Step 3 still
  describes the obsolete `_tenant_guard` decorator design (noted in
  ADR-0030 amendment §D; clean up in next PR cycle).
- JWKS rotation support (ADR-0030 §B closed restart-required posture
  for v0.12; v0.13+ if a deploy needs zero-downtime rotation).
- GHCR build+push workflow + SBOM/signing decision (own ADR scope).
- `ForgetReceipt` response-envelope `episode_uuid` → `episode_id`
  sweep (CHANGELOG asymmetry note pins the contract until then).
- Full live-stack 100-session HTTP smoke test (needs runner-side
  `LimitNOFILE>=65536` per `docs/ci/self-hosted-runner.md`).

Carryovers from the v0.12.x DRAFT that landed pre-tag:
- [#302](https://github.com/omurlabs/gnokee/issues/302) v0.12-step1
  tenant-isolation regression suite (closes #246) — landed post-v0.12.1
  pre-v0.12.2 cut.
- [#306](https://github.com/omurlabs/gnokee/issues/306) CI migration
  to self-hosted runners — landed pre-v0.12.2 cut.
- [#300](https://github.com/omurlabs/gnokee/issues/300) Q3 envelope
  re-run harness, `output_shape=fact` (closes #207) — landed
  pre-v0.12.2 cut.

### Specialist scope-verdict sweep — 2026-05-22 (post-v0.12.2)

Source: 8 specialists dispatched in parallel over 10 open GitHub issues +
5 deferred items from v0.12.2. Verdicts: GREEN = ship-ready, YELLOW =
ADR / spike / scaffolding gap, RED = invariant or policy blocker,
KILL = close with rationale. Per `feedback_specialist_scope_first`, no
implementation begins on a specialist-labelled item without a matching
scope read on file. Subsumes the earlier "turbovec dossier residue"
candidate table (verdicts now in line below).

#### Proposed milestones

**v0.13.0 minor — "tenant-aware retrieval scaffolding + first published image" (LANDED + CUT 2026-05-23 — see §v0.13.0 release scope above)**

| # | Title | Verdict | Specialist |
|---|---|---|---|
| [#305](https://github.com/omurlabs/gnokee/issues/305) | eval-delta gate: latency + recall@k + CI (needs `--check-baseline` plumbing + baseline JSON capture + services stanza) | YELLOW | `eval-spike-author` + `ci-engineer` |
| [#303-pg](https://github.com/omurlabs/gnokee/issues/303) | pgvector tenant filter pushdown — `iterative_scan` path (ADR + spike vs partial-index alternative) | YELLOW | `postgres-pgvector-specialist` |
| GHCR build+push workflow | first published image; Trivy SARIF in path; cosign + SBOM deferred to v0.13.1 | YELLOW | `ci-engineer` |
| ForgetReceipt `episode_id` alias (additive, dual-key release) | response-shape parity with v0.12.0 input rename | GREEN | `gnokee-mcp-tool-designer` |
| [#91](https://github.com/omurlabs/gnokee/issues/91) close → fold into ADR-0005 amendment footnote (no trigger movement since 2026-05-11) | YELLOW→KILL | `neo4j-ops-specialist` |
| [#71](https://github.com/omurlabs/gnokee/issues/71) competitive landscape 2026-Q2 doc | — | — |
| `_tenant_guard` cleanup in `docs/plans/2026-05-20-v0.12-mcp-revival.md` §Step 3 | trivial doc fix (per ADR-0030 amendment §D) | — | — |

**v0.13.1 patch — rolling, as items land**

| # | Title | Verdict | Specialist |
|---|---|---|---|
| [#303-neo4j](https://github.com/omurlabs/gnokee/issues/303) | Neo4j tenant pushdown — PROFILE + decision (wait-for-5.27 if upstream lands native filter; Community lacks composite vector+label index) | YELLOW | `neo4j-ops-specialist` |
| Full 100-session live-stack HTTP smoke | implement test body (currently pseudocode TODO line 70) + `workflow_dispatch` + runner `LimitNOFILE=65536` patch | YELLOW | `ci-engineer` |
| ForgetReceipt `episode_uuid` drop | after one-release deprecation window | GREEN | `gnokee-mcp-tool-designer` |

**v0.13.2+ patch candidates — gated by Q-spike outcomes**

| # | Title | Verdict | Specialist |
|---|---|---|---|
| [#78](https://github.com/omurlabs/gnokee/issues/78) | ADR-0017 declarative `gnokee.types.yaml` — blocked by [#307](https://github.com/omurlabs/gnokee/issues/307) (Q43 spike); bootstrap-time surface (NOT a `gnokee_*` call-time param) | YELLOW | `extraction-prompt-specialist` (prompt impact v0.13) + `gnokee-mcp-tool-designer` (surface scope pushes v0.14) |
| [#108](https://github.com/omurlabs/gnokee/issues/108) | Q16 Notion-via-Obsidian spike — synthetic corpus only (real Notion export = PII, cannot commit) | YELLOW eval / GREEN ingest | `eval-spike-author` + `ingest-pipeline-specialist` |

**v0.14.0 minor — "branching + framework adapters"**

| # | Title | Verdict | Specialist |
|---|---|---|---|
| [#79](https://github.com/omurlabs/gnokee/issues/79) | ADR-0018 supersession verb grammar + `branch_id` — blocked by [#308](https://github.com/omurlabs/gnokee/issues/308) (Q-spike vs Q41 corpus); `fact_contradiction.verdict` schema migration | YELLOW | `extraction-prompt-specialist` + `bi-temporal-auditor` |
| [#75](https://github.com/omurlabs/gnokee/issues/75) | Scheduled lint pass (rename from "Dreaming" — trademark) — blocked by [#311](https://github.com/omurlabs/gnokee/issues/311) (Q40 spike scaffold) + ADR-0031 | YELLOW | `ingest-pipeline-specialist` + `bi-temporal-auditor` |
| [#102](https://github.com/omurlabs/gnokee/issues/102) | Q15 cross-`group_id` semantic bridges — blocked by [#310](https://github.com/omurlabs/gnokee/issues/310) (ADR-0004 amendment); within-tenant multi-group only; cross-tenant explicit non-goal | RED eval / YELLOW bi-temporal | `eval-spike-author` + `bi-temporal-auditor` |
| [#304](https://github.com/omurlabs/gnokee/issues/304) | LlamaIndex VectorStore/Retriever adapter (LangChain deferred) — blocked by [#309](https://github.com/omurlabs/gnokee/issues/309) (ADR-0021 reassessment ADR); in-process Python API only | YELLOW | `gnokee-mcp-tool-designer` + `ingest-pipeline-specialist` |
| JWKS rotation (ADR-0030 §B) | open if a deploy demands zero-downtime; restart-required posture holds until then | — | — |

#### Load-bearing invariant calls from the sweep

- `branch_id` (#79) is a **partition key**, not a fourth temporal axis. The three axes remain per-episode across branches. Verb grammar ADR MUST declare whether new verbs override or coexist with the `unrelated | refinement | update | contradiction` Stage 7 classifier — silent winner-picking otherwise.
- Lint pass (#75) recency MUST sort by `asserted_at`, not `created_at` (the `_recency_proxy` axis-2/axis-3 swap closed in v0.11.0a0). Supersession MUST use `EpisodeIn.corrects:`, never raw UPDATE. Lint-generated episodes become permanent supersession-chain descendants — forget runbook addendum required.
- #102 cross-`group_id` is **architecturally blocked**: gnokee's retrieval contract takes a single `group_id` per query (`ep.group_id = $tenant` in retrieval.py Stage 2a). ADR-0004 amendment must define a `group_id_list` or "all-tenant-groups" mode before any spike. Cross-tenant is an ADR-0004 violation and is an explicit non-goal.
- #303 partial-HNSW-per-tenant is **not** safe without a measured cardinality cutoff — runtime DDL is irreversible catalog debt. `iterative_scan` (pgvector 0.8+) is the cheaper-to-roll-back default and the v0.13.0 target.
- #304 has an ADR-0021 policy block — must write reassessment ADR before any adapter ships. LlamaIndex first; LangChain deferred. In-process Python API only for v1; remote-MCP-HTTP later. Provenance preservation through `Document.metadata` is the load-bearing contract; tz-aware UTC coercion on `valid_at` is non-negotiable.
- #305 base-image stability (Postgres/Neo4j/TEI startup determinism) is a prerequisite — latency p95 under unstable startup is dominated by jitter, not retrieval code. Start the gate as `continue-on-error: true` PR comment until all three blockers (`--check-baseline` flag, baseline JSONs, services stanza) clear.
- #78 per-tenant type config MUST NOT be a `gnokee_*` call-time parameter — that would break ADR-0013 stable envelope contract. Bootstrap/admin surface only (`gnokee_register_types` or CLI), optional `gnokee_list_types(tenant_id)` introspection additive.

## v0.12.1 — patch scope (LANDED + CUT 2026-05-21 — "embed probe + extraction-model split")

Tagged `v0.12.1` on 2026-05-21T18:14Z. Two impl PRs landed under the
MCP-revival bundle that v0.12.0 scoped: #299 (closes #235 cross-lingual
extraction-prompt override + #238 embedder startup probe) and #298
(belt+braces tenant_id predicate on supersede chain-walk SELECT, closes
#297). See `## Closed in the v0.12 series` below for the rotation.

## v0.12.0 — release scope (LANDED + CUT 2026-05-21 — "MCP-revival pre-impl bundle")

Tagged `v0.12.0` on 2026-05-21T17:38Z. Scope-only release: PR #296
landed the pre-impl bundle docs for #233/#244/#245/#246; actual impl
shipped in the v0.12.1 patch cut later the same day. Closures
(#233/#244/#245/#246) rotated below.

## v0.11.3 — patch scope (LANDED + CUT 2026-05-19 — "forget_episode top-level re-export")

Tagged `v0.11.3` on 2026-05-19T21:10Z. Single-item DX cleanup — lifted
`forget_episode` to `gnokee/__init__.py` top-level + `__all__` for
parity with `ingest_episode` / `recall` / `history_of` (PR #295).
Driver: [omur#598](https://github.com/omurlabs/omur/pull/598) Phase C
GnokeeMemoryProvider via Marrow HTTP bridge. See `## Closed in the
v0.12 series` for the rotation.

ADR-0029 (`EpisodeRecord` provenance API) flipped to **Rejected**
during this cycle — Phase C used `history_of` + sibling-row join
instead; cross-repo `MemoryProvider.forget` Protocol reconcile not
needed (Marrow inlined the gnokee call on its HTTP route).

## v0.11 — release scope (LANDED 2026-05-18, both a0 and final)

Source: specialist sweep 2026-05-17. v0.11.0a0 (2026-05-18) absorbed the
overnight-autonomous batch; v0.11.0 final (same day) closed the four
human-driver tail issues (#210/#211/#218/#220) plus #232 and four P2
cleanups (#236/#237/#239/#243). See `## Closed in the v0.11 series`
below for the rotation.

## v0.11.2 — patch scope (LANDED + CUT 2026-05-19 — "Stage 4 retrieval correctness")

Tagged `v0.11.2` on 2026-05-19. Two retrieval fixes that landed
post-v0.11.1 tag: #95 (Stage 4 attribution-filter) and #290
(fact-cosine floor that closes the grader-artifact regression the
first fix surfaced). See `## Closed in the v0.11 series` for the
rotation.

Source: #95 unblocked by the post-v0.11.1 specialist-sweep root-cause
finding (Graphiti `MENTIONS` chain attributes every fact about a
shared `Entity` hub to every episode mentioning it). #290 surfaced
during #95 verification on Q41 — Q-X.3 went 10/10 → 9/10 on the
grounded-but-topically-unrelated £-quote fact, addressed via
fact-cosine floor knob rather than grader change.

| # | Title | Driver |
|---|---|---|
| _(empty — both items landed)_ | | |

## v0.11.1 — patch scope (LANDED + CUT 2026-05-18 — "FORCE-RLS readiness + dead-code mop-up")

Tagged `v0.11.1` on 2026-05-18. All six P1+P2 items closed
(PRs #283/#284/#285/#286/#287 plus #231 closed no-action). See
`## Closed in the v0.11 series` for the rotation. `#95` (Q41
rank-order tune) carried into v0.11.2 — single eval miss, no
FORCE-RLS dependency.

Source: post-v0.11.0 specialist-sweep residue + the natural continuation
of #220 (RLS GUC sweep). Driver = close the FORCE-RLS readiness gap
before any `FORCE ROW LEVEL SECURITY` migration ships.

Out of scope for v0.11.1 (saved for v0.12.0 minor):
- #233 — `gnokee_forget_episode.episode_uuid` → `episode_id` rename (breaking MCP param).
- #244 — MCP auth surface (new feature).
- #245 — productionize streamable-http transport (new feature).
- #246 — tenant_id boundary audit (new audit surface, may surface ADR).
- #235 — Graphiti LLMConfig cross-lingual prompt override (new integration surface).
- #238 — embedder startup probe (new bootstrap behavior).
- #207 — Q3 harness rewrite for `gnokee_query` envelope (eval scaffolding new).
- omkit `set_tenant_guc` upstream — new abstraction.
- #79 / #78 / #75 / #102 / #108 — ADR-grade work (next-quarter candidates).

## v0.10.x — release scope (carryovers from 2026-05-17)

`#207` landed post-v0.12.1 on `main` (PR #300); carries to next patch
cut. `#95` + `#290` landed in v0.11.2.

| # | Title | Driver |
|---|---|---|
| _(empty — rolled forward)_ | | |

## Closed in the v0.11 series

| # | Title | Where |
|---|---|---|
| [#210](https://github.com/omurlabs/gnokee/issues/210) | `EdgeInWindow.asserted_at` axis-3 pollution in backfill | v0.11.0 (PR #274) |
| [#211](https://github.com/omurlabs/gnokee/issues/211) | `list_episodes_for_tenant` missing `valid_until` upper bound + `corrects_reason` | v0.11.0 (PR #276) |
| [#212](https://github.com/omurlabs/gnokee/issues/212) | `gnokee_history_of` anchor missing `asserted_until` predicate | v0.11.0a0 |
| [#213](https://github.com/omurlabs/gnokee/issues/213) | `_recency_proxy` axis-2/axis-1 swap | v0.11.0a0 |
| [#215](https://github.com/omurlabs/gnokee/issues/215) | Neo4j HNSW DDL hardcoded dim | v0.11.0a0 |
| [#217](https://github.com/omurlabs/gnokee/issues/217) | `_OurIdRaceLost` bare `AssertionError` | pre-a0 (PR #263) |
| [#218](https://github.com/omurlabs/gnokee/issues/218) | `fact_contradiction` DELETE on wrong UUID column | v0.11.0 (PR #277) |
| [#220](https://github.com/omurlabs/gnokee/issues/220) | RLS GUC missing on `fact_history.py` + `vector.py` reads | v0.11.0 (PR #278) |
| [#221](https://github.com/omurlabs/gnokee/issues/221) | ADR-0028 amend vs insert-new-row | works-as-designed (PR #270) |
| [#222](https://github.com/omurlabs/gnokee/issues/222) | `gnokee_query` lazy provenance pointer | v0.11.0a0 |
| [#223](https://github.com/omurlabs/gnokee/issues/223) | `docs/api/mcp.md` tools-at-glance drift | v0.11.0a0 |
| [#224](https://github.com/omurlabs/gnokee/issues/224) | recall/query disambiguation in descriptions | v0.11.0a0 |
| [#225](https://github.com/omurlabs/gnokee/issues/225) | telemetry behind `include_telemetry` opt-in | v0.11.0a0 |
| [#226](https://github.com/omurlabs/gnokee/issues/226) | `gnokee_forget_episode` description trim | v0.11.0a0 |
| [#227](https://github.com/omurlabs/gnokee/issues/227) | `prior_revision_id` short-ID symmetry | v0.11.0a0 |
| [#228](https://github.com/omurlabs/gnokee/issues/228) | `OpenAIClient` empty-key guard | pre-a0 (PR #260) |
| [#232](https://github.com/omurlabs/gnokee/issues/232) | `gnokee_wiki_export` `valid_at` axis | v0.11.0 (PR #275) |
| [#236](https://github.com/omurlabs/gnokee/issues/236) | `DEFAULT_MAX_TOKENS` documentation | v0.11.0 (PR #280) |
| [#237](https://github.com/omurlabs/gnokee/issues/237) | caller-parsed Lab/Med fallback dead code | v0.11.0 (PR #280) |
| [#239](https://github.com/omurlabs/gnokee/issues/239) | `write_lite_episode` content-zero on encrypted resume | v0.11.0 (PR #279) |
| [#243](https://github.com/omurlabs/gnokee/issues/243) | `list_edges_in_window` static Cypher | v0.11.0 (PR #279) |
| _(no issue — #220 follow-up)_ | RLS GUC sweep + `set_config(..., true)` transaction wrap on `metadata.py` / `contradictions.py` / `lab.py` / `wiki_export.py` / `vector.py` / `fact_history.py` | v0.11.1 (PR #283) |
| [#240](https://github.com/omurlabs/gnokee/issues/240) | `OpenAIRerankerClient` wired but never exercised | v0.11.1 (PR #284) |
| [#234](https://github.com/omurlabs/gnokee/issues/234) | `ForgetNeo4jPartial` hint references Python `resume_forget` | v0.11.1 (PR #285) |
| [#242](https://github.com/omurlabs/gnokee/issues/242) | No duplicate-vector-index guard if graphiti-core upgrade adds vector DDL | v0.11.1 (PR #286) |
| [#230](https://github.com/omurlabs/gnokee/issues/230) | Autovacuum tuning missing on `content_embedding` + `ingest_audit` | v0.11.1 (PR #287) |
| [#231](https://github.com/omurlabs/gnokee/issues/231) | ADR-0004 reconciliation — `content_embedding` schema names diverge from spec | v0.11.1 (closed no-action — ADR-0004 already had the 2026-05-17 reconcile amendment) |
| [#95](https://github.com/omurlabs/gnokee/issues/95) | Graphiti fact-ranking: allergy episode outranked by medication (Q41 p_x1_03) | v0.11.2 (PR #291; fact-attribution `ep.uuid IN r.episodes` fix; ADR-0019 § Issue #95 verdict) |
| [#290](https://github.com/omurlabs/gnokee/issues/290) | Fact-cosine reranking + Q-X.3 grader refinement (follow-up to #95) | v0.11.2 (PR #292; `fact_cosine_floor` retrieval knob + `gnokee_recall` MCP param; ADR-0019 § Issue #290 verdict) |

## Closed in the v0.12 series

| # | Title | Where |
|---|---|---|
| _(no issue — omur#598 Phase C DX cleanup)_ | Lift `forget_episode` to `gnokee/__init__.py` top-level + `__all__` + `tests/unit/test_public_surface.py` identity pin | v0.11.3 (PR #295) |
| [#233](https://github.com/omurlabs/gnokee/issues/233) | `gnokee_forget_episode.episode_uuid` → `episode_id` MCP param rename | v0.12.0 (scope bundle PR #296) |
| [#244](https://github.com/omurlabs/gnokee/issues/244) | MCP auth surface (FastMCP `AuthBackend`) | v0.12.0 (scope bundle PR #296) |
| [#245](https://github.com/omurlabs/gnokee/issues/245) | Productionize streamable-http transport (lift "dev only" caveat) | v0.12.0 (scope bundle PR #296) |
| [#246](https://github.com/omurlabs/gnokee/issues/246) | `tenant_id` boundary audit (single-process server) | v0.12.0 scope (PR #296) → step-1 regression suite v0.12.x (PR #302, post-v0.12.1 on `main`) |
| [#297](https://github.com/omurlabs/gnokee/issues/297) | Belt+braces tenant_id predicate on supersede chain-walk SELECT | v0.12.1 (PR #298) |
| [#235](https://github.com/omurlabs/gnokee/issues/235) | Graphiti LLMConfig cross-lingual extraction-prompt override (Q2 Hebrew F4 bug class) | v0.12.1 (PR #299) |
| [#238](https://github.com/omurlabs/gnokee/issues/238) | Embedder startup probe asserting `EMBED_DIM=1024` before first ingest | v0.12.1 (PR #299) |
| [#207](https://github.com/omurlabs/gnokee/issues/207) | Q3 harness rewrite for `gnokee_query` envelope, `output_shape=fact` | v0.12.2 (PR #300) |
| _(no issue — CI infra)_ | Migrate all jobs to self-hosted runners | v0.12.2 (PR #306) |
| _(no issue — ADR-0030)_ | ADR-0030 amendment 2026-05-22 — four implementation-drift pin-downs (synthetic Bearer header / JWKS rotation gap / no-wildcard `tenant_claim` / inline `enforce_tenant_authority`) | v0.12.2 (`147a318`) |
| _(no issue — security HIGH)_ | `BearerJWTBackend` alg-confusion construction guards + `_allow_hmac` opt-in | v0.12.2 (`32ee55b`) |
| _(no issue — security HIGH)_ | `MCPTokenVerifier.verify_token` defensive contextvar reset | v0.12.2 (`5763787`) |
| _(no issue — security HIGH)_ | `_assert_http_auth_safety` startup gate (`GNOKEE_MCP_HTTP=1` + `auth=None` refused) | v0.12.2 (`bba2e6a`) |
| _(no issue — operational)_ | `/readyz` error envelope strips exception class names + `GNOKEE_MCP_HOST/PORT` bind-address env vars | v0.12.2 (`178797f`) |
| _(no issue — test scaffold)_ | 100-session pool-counter smoke-test scaffold (`tests/integration/test_mcp_streamable_http.py`) | v0.12.2 (`0b06e1f`) |
| _(no issue — operator runbook)_ | `docs/ci/self-hosted-runner.md` — RLIMIT_NOFILE patch + TLS-at-proxy posture + PyPI Trusted Publishing notes | v0.12.2 (`f3c2864`) |
| _(no issue — DinD compat)_ | `pypi-publish.yml` manual OIDC mint-token flow (pypa Docker action incompatible with `unraid, docker` runners) | v0.12.2 (`4d1fcab`, `61af746`) |

## v0.4.x — release scope

| # | Title | Driver |
|---|---|---|
| _(empty — #84 landed in v0.4.0 follow-up, see Closed in the v0.4.x series below)_ | | |

## v0.5.x — release scope (post-v0.5 follow-ups)

| # | Title | Driver |
|---|---|---|
| [#95](https://github.com/omurlabs/gnokee/issues/95) | Graphiti fact-ranking: allergy episode outranked by medication episode (Q41 p_x1_03) | Q41 follow-up; single eval miss, rank-order tune. Low priority. |

## v0.5 — release scope (LANDED 2026-05-12)

Source: [#71](https://github.com/omurlabs/gnokee/issues/71) competitive-landscape 2026-Q2 review.
Scope landed 2026-05-12 (commits b990f3f / e7e81b3 / d8fe1d5 / a013a49).
See "Closed in the v0.5 series" below for the rotation.

### Next-quarter candidates (post-v0.5)

| # | Title | Driver |
|---|---|---|
| ~~[#73](https://github.com/omurlabs/gnokee/issues/73)~~ | ~~ADR-0014 append-only `fact_revision` log + `gnokee_fact_history` MCP tool~~ — **SHIPPED v0.9.0a0** | GCP Memory Bank `MemoryRevision` + A-MEM bidirectional evolution. |
| [#79](https://github.com/omurlabs/gnokee/issues/79) | ADR-0018 typed supersession verb grammar + `branch_id` for what-if reasoning | Mem0 ADD/UPDATE/DELETE/NOOP grammar (DELETE-free variant) + Letta / TerminusDB branch axis. Depends on #73. |
| [#78](https://github.com/omurlabs/gnokee/issues/78) | ADR-0017 declarative `gnokee.types.yaml` surface | A-MEM tag-evolution + Fabric IQ ontology vocabulary alignment. |
| [#75](https://github.com/omurlabs/gnokee/issues/75) | Spike: scheduled dreaming lint pass for cross-session supersession | Anthropic Dreaming + A-MEM bidirectional evolution; cron infra (`scheduled_tasks.lock`) already present. |
| [#102](https://github.com/omurlabs/gnokee/issues/102) | Spike Q15: semantic bridges across `group_id` partitions (cross-source-type fact discovery) | NOUZ-MCP "semantic bridge" idea on `EntityEdge.fact_embedding`; lab↔med↔wearable see-also signal. |
| [#103](https://github.com/omurlabs/gnokee/issues/103) | Vault-adapter onboarding: mean-centered cosine separation health check on source-type prompts | NOUZ-MCP calibration ergonomic; one-shot probe, no infra, catches weak source-type prompts before retrieval. |
| [#104](https://github.com/omurlabs/gnokee/issues/104) | Obsidian vault adapter: opportunistic NOUZ frontmatter interop (read sign/level/parents/tags if present) | Co-marketing + zero-risk interop with NOUZ-managed vaults; follow-up to ADR-0020. |
| [#108](https://github.com/omurlabs/gnokee/issues/108) | Q16 — Notion export ingest quality through Obsidian adapter | ADR-0020 § Q14.2 follow-up; measures markdown→plaintext recall on heavy-formatted (Notion-noise) source. |

Items can move to `wontfix` after ADR debate per #71 § "What this issue is for".

## v0.6 — release scope (LANDED 2026-05-16)

Source: [#111](https://github.com/omurlabs/gnokee/issues/111) (Q18 silent-drop verdict).
Scope landed 2026-05-16 via PR #121 (squash commit 9b4cd54). Q18 release-cut gate PASS: recall@5 measurable = 100% (vs v0.5 baseline 17.6%); 0 silent-drops. See "Closed in the v0.6 series" below for the rotation.

## v0.7 — release scope (LANDED 2026-05-16)

"Durability + lineage" ramp. Scope locked 2026-05-15; full batch landed 2026-05-16 (#124 STRICT removal → #122 journal + ADR-0024 → #123 history_of DAG). See "Closed in the v0.7 series" below for the rotation.

## v0.7.x — release scope (post-v0.7 follow-ups)

| # | Title | Driver |
|---|---|---|
| ~~[#130](https://github.com/omurlabs/gnokee/issues/130)~~ | ~~Forget-cascade: include `ingest_journal` in tenant-deletion sweep~~ — **CLOSED 2026-05-16** | ADR-0024 follow-up; tenant-forget must wipe journal rows. |
| [#102](https://github.com/omurlabs/gnokee/issues/102) | Q15 cross-`group_id` semantic bridges spike | Adjacent retrieval primitive; carried over from v0.6.x. |

### Next-quarter candidates (post-v0.7)

| # | Title | Driver |
|---|---|---|
| ~~[#73](https://github.com/omurlabs/gnokee/issues/73)~~ | ~~ADR-0014 append-only `fact_revision` log + `gnokee_fact_history` MCP tool~~ — **SHIPPED v0.9.0a0** | GCP Memory Bank `MemoryRevision` + A-MEM bidirectional evolution. Natural successor to `gnokee_history_of` (episode-level → fact-level lineage). |
| [#79](https://github.com/omurlabs/gnokee/issues/79) | ADR-0018 typed supersession verb grammar + `branch_id` for what-if reasoning | Mem0 ADD/UPDATE/DELETE/NOOP grammar (DELETE-free variant) + Letta / TerminusDB branch axis. Depends on #73. |
| [#78](https://github.com/omurlabs/gnokee/issues/78) | ADR-0017 declarative `gnokee.types.yaml` surface | A-MEM tag-evolution + Fabric IQ ontology vocabulary alignment. |
| [#75](https://github.com/omurlabs/gnokee/issues/75) | Spike: scheduled dreaming lint pass for cross-session supersession | Anthropic Dreaming + A-MEM bidirectional evolution. |
| [#108](https://github.com/omurlabs/gnokee/issues/108) | Q16 Notion export ingest quality through Obsidian adapter | ADR-0020 § Q14.2 follow-up; markdown→plaintext recall on Notion-noise source. |
| Z2 (untracked) | `EpisodeIn.source_type` field + lite-mode default for prose | Deferred from v0.6 per ADR-0023 § Out-of-scope. Public API contract — own ADR. |
| LongMemEval-S publish | ADR-0019 stance `PUBLISH_POST_Z1`; publish recall@5 / recall@10 numbers | Q18 gate pass unlocks this. Separate PR. |

## How to add an item

1. Open a GitHub issue with a 1-line title and a short body covering: problem / decision / acceptance.
2. Label with the target release (`v0.3`, `v0.4`, etc.) and a category (`enhancement`, `documentation`, etc.).
3. Add a row to the appropriate table above. Keep the description column to one driver-sentence — the issue carries the detail.

## Closed in the v0.10.x series

v0.10.1 (2026-05-17) — specialist-sweep P1 mop-up:
- Issue #214 — Cypher deprecated `count()` after `DETACH DELETE` × 4 sites — landed (PR #248). Side-effect: kills the `UserWarning: Expected a result with a single record, but found multiple` from `graph.py`.
- Issue #216 — `EpisodeIn.asserted_at` doc claimed `now(UTC)` default; actual is `valid_at` — landed (PR #247).
- Issue #219 — `write_embedding` called without `model=` so column ignored `GNOKEE_EMBED_MODEL` — landed (PR #249).
- Issue #229 — `classify_contradiction` outer try/except swallowed `LLMUnavailable` past per-pair handler — landed (PR #250).
- Issue #241 — `add_episode(our_id=None)` silently disables dedup; emit ingest-time WARN — landed (PR #251).

Deferred to v0.10.x / unscoped:
- Issue #207 — Q3 harness rewrite driving `gnokee_query` envelope at `output_shape:fact` (median-token capture + ADR-0013 v0.10 footer amendment).
- Issue #95 — Graphiti fact-ranking allergy/med rank delta on Q41 `p_x1_03` (investigation; no acceptance contract yet).

## Closed in the v0.7 series

v0.7.0 (2026-05-16):
- Issue #122 — Ingest crash-recovery journal + `gnokee.resume_ingest` Python API — landed (PR #129, squash aa559da). Append-only `ingest_journal` Postgres table; `begin`/`commit`/`fail` rows; `IngestPipeline` surfaces orphans on first ingest per tenant per process. Operator-driven resume only — gnokee NEVER auto-replays. ADR-0024 Accepted. Q19 spike: 2.17% median latency regression (under ADR-0024 10% threshold).
- Issue #123 — `gnokee_history_of` supersession-DAG MCP tool + `gnokee.history_of` Python API — landed (#128). Cytoscape-flat envelope; `mode=compact` / `mode=verbatim`; `as_of` time-travel; `cycle_detected` instead of raising; encrypted episodes keep ciphertext. `EpisodeIn.corrects_reason` field added (Python API only; MCP exposure deferred).
- Issue #124 — Hard-removal of `GNOKEE_INGEST_STRICT` env var — landed (#126). v0.6 deprecation cycle closed; env var now a no-op. Replacement signals on `IngestReceipt.ingest_telemetry`.
- ADR-0024 — Ingest crash-recovery journal — Status `Accepted` (#127).

## Closed in the v0.6 series

v0.6.0 (2026-05-16):
- Issue #111 — Graphiti `add_episode` silent-drop ingest hardening — landed (#121). Z1 storage-first stage reorder + Z4 adaptive retry + concurrency cap. Q18 release-cut gate PASS: recall@5 measurable 17.6% → 100%; zero silent-drops. ADR-0023 Accepted. ADR-0012 + ADR-0019 amended.
- ADR-0023 — gnokee owns episode storage; Graphiti is enhancement-only — Status `Accepted`.
- `GNOKEE_INGEST_STRICT` env var — deprecated (DeprecationWarning); hard-removal v0.7.

## Closed in the v0.5 series

v0.5.0 (2026-05-12):
- Issue #72 — ADR-0013 `gnokee_query` declarative envelope MCP tool — landed (#100).
- Issue #74 — ADR-0015 `gnokee_wiki_export` + `llms.txt` manifest — landed (#99).
- Issue #76 — ADR-0016 per-claim bi-temporal citation envelope — landed (#92).
- Issue #77 — Source-grounded refusal Q-suite — consolidated into #109 / ADR-0022.
- Issue #80 — confidence-decay function open question — resolved by ADR-0019 (`SHIP_RECENCY_AS_PROXY`, PR #87).
- Issue #81 — LongMemEval-S v0.5 publish target — resolved as `DECLINE_TO_PUBLISH` (ADR-0019 amendment 2026-05-12); defer to v0.6 after #111.
- Issue #88 — Q13.1 confidence-model stage-2 spike at N≥30 — landed (#118). Verdict `KEEP_RECENCY_PROXY`: 0/48 composite variants cleared both Spearman + calibration gates at N=31. ADR-0019 § Follow-up closed.
- Issue #89 — per-fact `cosine_top1` telemetry on `gnokee_recall` — landed (#117); ADR-0019 § Follow-up amended (recency-proxy proxy reading retired).
- Issue #90 — Graphiti literal-numeric extraction gap — accepted (option 1 of 4); triple-coverage via `lab_record` / `med_record` / `excerpts[]` + `episode_fallback[]` suffices.
- Issue #94 — Refusal posture UX gap — ADR-0022 Option A landed (#119): `refused: bool` + `cosine_floor` knob on `RecallResponse` / `gnokee_recall`. Pulled forward from v0.5.x.
- Issue #97 / #96 — Obsidian vault adapter — landed (#101); ADR-0020 Q14 spike verdict `SHIP_ADAPTER`.
- Issue #103 — Vault-adapter mean-centered cosine separation probe — landed (#105).
- Issue #106 — ADR-0021 consumer surface strategy — accepted (#113).
- Issue #107 — Q14.1 sweep of past spike harnesses for threshold-semantics bug class — landed (#114).
- Issue #109 — Q17 refusal-posture spike + ADR-0022 draft — landed (#115); verdict `ADOPT_OPTION_D_CURRENT_POSTURE_CONTROLS_PARTIAL`.
- Issue #110 — v0.5 LongMemEval narrative note — landed (8743c25).
- Issue #111 (Z3 partial) — graphiti orphan-edge warnings on `IngestReceipt` — landed (#112). Z1/Z2 remain for v0.6.
- ADR-0022 — refusal posture — Status `Accepted` (verdict `ADOPT_OPTION_D`, Q17 spike; amended same-day for Option A landing) — landed (#116, #119).

## Closed in the v0.2.x maintenance series

v0.2.2 (2026-05-09):
- Issue #17 — partial open-subset indexes on `lab_record` / `med_record` for supersession perf — landed.
- Issue #18 — `gnokee_lab_query op=abnormal`; Q7 `q_electrolyte_abnormal_q2` PARTIAL → PASS — landed.
- Issue #19 — `gnokee_recall.supersession_hints[]` (Option A+, clinical-safe) — landed.

v0.2.3 (2026-05-09):
- Issue #20 — first PyPI publish; `pip install gnokee==0.2.3` works — landed.
- Issue #21 — `GNOKEE_SPIKE_SKIP_INGEST=1` env-var alignment for Q7 + Q8 harnesses — landed.

## Closed in the v0.3.x release scope

v0.3.0 (2026-05-09):
- Issue #16 — Lite ingest mode + integration patterns doc + eval-delta gate — landed.
- Issue #38 — `gnokee.recall` episode-cosine fallback when `fact_count == 0` (Path A) — landed.
- Issue #39 — Q10.1 Zep-OSS + basic-memory adapters + Stage C confirmation — landed; ADR-0012 Accepted-with-caveat.
- Issue #54 — per-lane budget + emitted telemetry on `RecallResponse` — landed.
- Issue #56 — lite-mode ingest writes minimal `Episodic` node so recall sees it — landed.

v0.4.0 (2026-05-10):
- Issue #22 — `encrypted_body` branch wires DEK pathway end-to-end (Stage 1 boundary, migration `0012_episode_body_encrypted`, recall surfacing) — landed.
- Issue #37 — ADR-0004 + ADR-0012 amendments for encrypted_body boundary + Q10 Stage C-pilot magnitude — landed.
- Issue #51 — consolidate `episode_metadata.content` + `content_text` (migration `0011_drop_content_column`) — landed.
- Issue #52 — `top_k_bodies` + `per_body_char_cap` knobs on `recall()` (Python API; MCP deferred) — landed.
- Issue #62 — Q12 abstain split + synth-v2 falsifies "retrieval is the bottleneck" hypothesis — landed.
- Issue #63 — `evals/q10/run.py` parallelize per-question + Mem0 adapter robustness — landed.
- Issue #64 — Q10 / Zep CE compose env keys + smoke step — landed.

## Closed in the v0.4.x series

(no v0.4.x point release cut yet; closures listed against the next tag)

- Issue #80 — confidence-decay function open question — resolved by ADR-0019 (Accepted-with-caveat, SHIP_RECENCY_AS_PROXY); merged in #87.
- Issue #84 — MCP `top_k_bodies` + `per_body_char_cap` exposure on `gnokee_recall` — merged in #85.
- Issue #90 — Graphiti literal-numeric extraction gap — **Accept** (option 1 of 4); triple-coverage via `lab_record` / `med_record` / `excerpts[]` + `episode_fallback[]` suffices; ADR-0019 § Follow-up amended + spike-author guidance added to `docs/evals/methodology.md`.

## Closed before v0.2.x

- Issue #15 — `chore(release): v0.2.0 typed clinical reads` — landed.
- Issues #2 / #3 / #4 / #5 / #6 / #7 / #8 — v0.1.1 extraction-quality work, all closed before v0.2.0.

ADRs that surface implicit backlog items but are not yet tracked as issues:
- ADR-0011 (wearables off-ramp) — depends on consumer TimescaleDB integration; not gnokee work.
- ADR-0008 (contradiction storage) — Q4 closed; orthogonal to supersession.
