# Extraction Preprocessor — Design Spec

**Date:** 2026-05-08
**Issues:** #2 (numbered refs), #3 (ranked priority), #4 (markdown-table amounts)
**Milestone:** v0.1.1
**Status:** Proposed

## Goal

Surface three classes of signal that Graphiti's vanilla entity extraction
flattens or drops on Notion-export markdown:

- Numbered identifiers — `ADR-NNN`, `Q\d+`, `P\d+\.\d+`, `RFC-\d{4}`
- Ranked priority — markdown ordered lists, `P0/P1/P2` prefixes, "top of stack"
- Currency amounts in markdown tables — `€14,225` paired with category headers

Recall must improve enough that the agent can answer "What does ADR-025
decide?", "What is the top open question?", and "How much was spent on Sofia
renovation?" using only memory.

## Non-Goals

- No change to graphiti-core's extractor or to gnokee's stance on
  `entity_type_hints` (still advisory in v0.1).
- No second LLM pass. No change to contradiction/maintenance daemon shape.
- No change to stored episode content — provenance returns the original
  markdown unchanged. (Per design call: "Extractor input only".)
- No change to `EpisodeIn` schema or MCP `gnokee_ingest_episode` surface.

## Approach: Pre-Extraction Preprocessor

A deterministic markdown-aware pass runs between Stage 3 (embed) and Stage 4
(graphiti.add_episode) of the ingest pipeline. It returns an *augmented*
content string consisting of:

```
{original content}

---
Derived facts:
- {derived sentence 1}
- {derived sentence 2}
…
```

The augmented content is passed to `graphiti.add_episode`. The original
content is what gnokee writes to `episode_metadata` / `Episodic.content` for
provenance. The graphiti extractor sees the derived sentences as plain
prose and lifts them into entities/edges via its normal pipeline.

### Why this shape

- **Deterministic** — pure regex + markdown parsing. Unit-testable without
  the LLM. Knocks the issue out from under the existing flake-quarantine
  pattern.
- **Boundary-respecting** — preprocessor runs inside ingest, owns no
  graphiti internals, modifies no schema.
- **Layer-able** — three rules are independent. Each has a single regex
  surface and a single derived-sentence template.
- **Cheap** — adds zero LLM calls and a few hundred bytes per episode.
- **Reversible** — flag-gated. If extraction quality regresses for some
  corpus, disable per tenant.

## Module Layout

```
src/gnokee/extract/
  __init__.py
  preprocessor.py     # main entry: augment_for_extraction(content) -> str
  rules/
    __init__.py
    identifier.py     # ADR-NNN / Q\d+ / P\d+\.\d+ / RFC-\d{4}
    ranked_list.py    # ordered lists, P0/P1/P2, "top of stack"
    table_amount.py   # markdown tables with currency cells
```

A new package `extract/` keeps it out of the hot ingest module. Each rule
exports `extract(content: str) -> list[str]` returning derived sentences.
The top-level `augment_for_extraction(content)` runs all three rules and
appends a `Derived facts:` block.

### Rule 1 — Identifier (issue #2)

**Detect:** `r"\b(ADR-\d{3}|Q\d+|P\d+\.\d+|RFC-\d{4})\b"` against the full
body. For each match, locate the nearest preceding markdown heading
(`#…######`) and the immediately following sentence/line.

**Emit:** `"{IDENT} is referenced in '{heading}': {first sentence after match}."`

**Example input:**
```
## ADR-025: Maintenance daemon cadence
We will run synthesis nightly at 02:00 UTC...
```
**Emit:** `ADR-025 is referenced in 'ADR-025: Maintenance daemon cadence': We will run synthesis nightly at 02:00 UTC.`

**Edge cases:** dedupe identical identifiers; cap at first 20 identifiers per
episode to bound preprocessor cost.

### Rule 2 — Ranked list (issue #3)

**Detect:** Markdown ordered lists (`1. ` / `2. ` …) AND lines beginning
with `P0/P1/P2/P3` AND lines containing literal "top of stack" or "top
priority". Capture list items in order, anchored by their preceding heading.

**Emit per list:**
- `"The top item under '{heading}' is: {item 1 text}."`
- `"The second item under '{heading}' is: {item 2 text}."`
  (capped at first 3 items per list)

**Emit per P-prefix:** `"{P-prefix} priority: {rest of line}."`

**Emit per "top of stack" line:** `"Top of stack under '{heading}': {rest of line}."`

**Example input:**
```
## Open questions for v0.1
Top of stack: validate before writing real code → Q1.
1. Q1 graphiti spike
2. Q2 cross-lingual recall
```
**Emit:**
- `Top of stack under 'Open questions for v0.1': validate before writing real code → Q1.`
- `The top item under 'Open questions for v0.1' is: Q1 graphiti spike.`
- `The second item under 'Open questions for v0.1' is: Q2 cross-lingual recall.`

### Rule 3 — Table amount (issue #4)

**Detect:** Markdown table blocks (`| … |` rows). Parse header row;
for each data row containing a currency cell (regex
`r"(?P<sym>[€$£¥])\s?(?P<num>[\d,.]+)\s*(?P<suffix>k|m|bn)?"`),
emit one sentence per amount cell.

**Resolve "what" column:** the leftmost non-numeric column whose value is
non-empty.

**Emit:** `"{leftmost col header}: {leftmost col value} = {currency}{amount}, as recorded in '{nearest heading}'."`

**Example input:**
```
## Sofia Apartment / Finance

| Category   | Vendor   | Amount    | As of |
| renovation | Foo Ltd. | €14,225   | 2026-04-20 |
```
**Emit:** `Category: renovation = €14,225, as recorded in 'Sofia Apartment / Finance' (vendor=Foo Ltd., as of 2026-04-20).`

**Edge cases:** skip tables with zero currency cells; cap derived sentences
per table at 20.

## Wiring into Ingest

Stage 3 (embed) runs against the original `content`. Stage 4 passes an
augmented body to graphiti. After Stage 4 returns, gnokee overwrites the
just-created `Episodic.content` back to the original — so provenance,
embedding, and stored content all reflect the unaugmented body. Graphiti
sees the derived sentences only during extraction.

```python
# Stage 4: graphiti add_episode
episode_name = _episode_name_from_content(content)
augmented = augment_for_extraction(content)
result = await self.graph.add_episode(
    tenant_id=episode.tenant_id,
    name=episode_name,
    content=augmented,
    reference_time=episode.valid_at,
    source_description="gnokee.ingest",
)
# Stage 4b: restore original body on Episodic.content
if augmented != content and result.episode.uuid is not None:
    await self.graph.overwrite_episode_content(
        tenant_id=episode.tenant_id,
        episode_uuid=UUID(result.episode.uuid),
        content=content,
    )
```

`GraphitiStore.overwrite_episode_content` is a new method:

```cypher
MATCH (ep:Episodic {uuid: $uuid, group_id: $tenant})
SET ep.content = $content
```

Tenant predicate prevents cross-tenant write (gnokee invariant). One
round-trip per ingest only when preprocessor produced derived sentences.

## Configuration

`Settings` adds:
- `preprocessor_enabled: bool = True` — global kill-switch.

Per-tenant disable is out of scope for v0.1.1 — global flag is enough.

## Failure mode

Preprocessor must never raise. Wrap each rule in try/except, log warning,
return empty list on failure. Original content always propagates.

## Test plan

### Unit tests (deterministic — primary verification)

`tests/unit/extract/test_preprocessor.py`:

- **Identifier rule:**
  - `ADR-025` under heading → emits expected sentence
  - `Q1`, `P1.3`, `RFC-7807` all detected
  - dedupe: same identifier mentioned twice yields one sentence
  - cap at 20 identifiers
  - no false positive on `ADR-X` or `Q` alone

- **Ranked-list rule:**
  - 3-item ordered list → emits "top", "second" sentences
  - `P0:` line → emits `P0 priority: …`
  - "Top of stack" line → emits with heading anchor
  - empty list → emits nothing
  - heading missing → emits with `''` heading anchor

- **Table-amount rule:**
  - 1-row table with `€14,225` → emits Sofia-style sentence
  - multi-currency table (€/$/£) → all detected
  - currency suffix `k`/`m` parsed
  - table without currency → emits nothing
  - malformed table row → no crash, no emit

- **augment_for_extraction:**
  - empty content → returns content unchanged (no `Derived facts:` block)
  - all three rules fire on a kitchen-sink fixture
  - rule exception → other rules still fire, content still returned
  - output format: original → blank line → `---` → blank → `Derived facts:` → bullet list

### Integration smoke tests (quarantined)

`tests/integration/test_preprocessor_recall.py` — three tests, each marked
with the existing LLM-flake retry-or-skip pattern:

- `test_adr_identifier_recall`: ingest a small ADR-025 fixture; query
  graphiti for fact text containing `ADR-025`; assert at least one match.
- `test_top_of_stack_recall`: ingest a 3-item ranked-priority fixture;
  query for "top" / "first"; assert match.
- `test_currency_amount_recall`: ingest a Sofia-style table fixture; query
  for `€14,225`; assert match.

These verify the end-to-end signal lifts but tolerate Graphiti LLM flake.
Hard verification is the unit tests.

### Provenance test

`tests/integration/test_preprocessor_provenance.py`:
- Ingest a doc that triggers preprocessor.
- Call `fetch_provenance` for any resulting fact.
- Assert returned `episode_content` does NOT contain `Derived facts:`.

## Module-boundary update

`tach.toml` adds:
- `gnokee.extract` — leaf module, no internal deps (depends_on = []).
- `gnokee.ingest.depends_on` += `"gnokee.extract"`.

`gnokee.extract` does not import other gnokee modules — keeps preprocessor
trivially testable in isolation.

## Roll-out

Single PR. Single commit (or 1-per-rule + wiring + tests if reviewer prefers).
Closes #2 #3 #4. Updates AGENTS.md note on `entity_type_hints` to reference
preprocessor as the chosen v0.1.1 alternative.

## Open risks

- **Heading anchor heuristic** can attribute facts to wrong section if
  markdown structure is irregular. Acceptable v0.1.1 — tests pin behavior;
  improve in v0.2.
- **Provenance overwrite Cypher** must use `group_id = $tenant` predicate
  to prevent cross-tenant write. Already a gnokee invariant.
- **Augmented body ~10–30% larger** → slightly more tokens to graphiti's
  extractor LLM. Acceptable trade for recall.
