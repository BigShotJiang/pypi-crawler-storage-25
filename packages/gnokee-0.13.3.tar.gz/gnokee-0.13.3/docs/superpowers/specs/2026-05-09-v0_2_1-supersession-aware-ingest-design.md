# v0.2.1 — supersession-aware ingest (`corrects:` signal)

- **Date:** 2026-05-09
- **Author:** brainstorming session, gnokee main
- **Status:** Approved (user) — ready for `writing-plans`
- **Related:** ADR-0009 (clinical labs typed store), ADR-0010 (med history typed store), ADR-0004 (gnokee owns retrieval, bi-temporal half-pairs)

## Problem

v0.2.0 landed `lab_record` + `med_record` typed stores with bi-temporal half-pairs. Reads (`gnokee_lab_query`, `gnokee_med_query`) already filter on `asserted_until`. But the **write path never closes prior rows on a correction** — a correction episode just inserts new rows. Result: aggregations (`MIN(value_numeric)`) include superseded values.

ADR-0009 named the missing piece:

> "the v0.2 ingest writes new `lab_record` rows on a correction but does not yet set `asserted_until` on the prior row, so visible `MIN(value_numeric)` includes the original 2.8 mmol/L instead of the corrected 3.6 mmol/L. **v0.2 follow-up gap.**"

> "needs an explicit `corrects: episode_uuid` signal from the caller per ADR-0009."

Q7 spike's `q_k_lowest_2024` is the named failing query.

## Decision (in scope)

Add an explicit `corrects: UUID | None` field to `EpisodeIn`. When set:

1. Validate at boundary + storage layer (same-tenant, episode-exists, axis-not-inverted).
2. Close matching `lab_record` rows from the corrected episode (`asserted_until = new.asserted_at`).
3. Close matching `med_record` rows from the corrected episode.
4. Close `episode_metadata` for the corrected episode (`asserted_until` + `superseded_by`).

All four steps run inside the existing Stage 6 single-txn block, **before** the new-row inserts. Atomic with the rest of the txn — supersession rolls back if any insert fails.

## Out of scope (explicit)

- **Graphiti edge supersession.** Narrative corrections continue to flow through ADR-0008's contradiction-surfacing system. ADR-0009 boundary holds: graphiti owns prose, gnokee owns typed half.
- **Auto-detected corrections.** No heuristic for "looks like a correction." Caller-asserted only — `corrects` MUST be explicit.
- **Schema migration.** `asserted_until` columns already exist on both tables (migrations `0006` + `0007`). No new migration.
- **Cross-row partial corrections.** Granularity is `(analyte, valid_at)` for labs and `(drug_name, event_kind, valid_at)` for meds. Caller-named subsets (`corrects: {episode_uuid, analytes: [...]}`) deferred — the parser-driven path doesn't need it.

## Components

### 1. Boundary contract — `src/gnokee/models.py`

Add to `EpisodeIn`:

```python
corrects: UUID | None = Field(
    default=None,
    description=(
        "When set, declares this episode supersedes a prior one. Same-tenant "
        "only; corrected episode must exist; new asserted_at must be > "
        "corrected.asserted_at. Closes matching lab_record + med_record rows "
        "from the corrected episode + episode_metadata.asserted_until + "
        "superseded_by. Caller-asserted only — no heuristic detection. "
        "Graphiti edges are NOT auto-superseded; narrative corrections flow "
        "through ADR-0008 contradiction surfacing."
    ),
)
```

`extra="forbid"` already on the model. Existing callers unaffected (default None).

Boundary validation (Stage 1) is shape-only — UUID parses. Existence + tenant + axis errors raise inside Stage 6 txn.

### 2. Errors — `src/gnokee/errors.py`

```python
class CorrectsError(VectorStoreError):
    """Base for `corrects:` validation failures (Stage 6 txn-scope)."""

class EpisodeNotFoundError(CorrectsError):
    def __init__(self, episode_uuid: UUID) -> None:
        super().__init__(f"corrects: episode {episode_uuid} not found")
        self.episode_uuid = episode_uuid

class CorrectsCrossTenantError(CorrectsError):
    """Raised when corrects targets a different tenant_id."""

class CorrectsAxisInversionError(CorrectsError):
    """Raised when new asserted_at <= corrected.asserted_at."""

class CorrectsChainError(CorrectsError):
    """Raised when superseded_by walk exceeds bounded depth (cycle or
    runaway chain). Distinct from axis inversion — cycle/depth is a
    structural invariant, not a tx-time inversion."""
```

`CorrectsChainError` is separate so callers and log parsers don't conflate "you tried to invert tx-time" with "the chain you named is malformed".

All subclass `VectorStoreError` so the existing Stage 6 `except VectorStoreError as exc: await _compensate(self.graph, episode_uuid, exc)` path catches them. Graphiti episode created at Stage 4 rolls back cleanly.

### 3. Storage adapters

**`LabStore.supersede_matching`** (`src/gnokee/storage/lab.py`):

```python
async def supersede_matching(
    self,
    *,
    conn: asyncpg.Connection,
    tenant_id: str,
    episode_uuid: UUID,                  # the resolved chain head, NOT necessarily caller's `corrects`
    keys: list[tuple[str, datetime]],    # (analyte, valid_at) tuples
    asserted_until: datetime,
) -> int:
    """Close prior lab_record rows on the named episode whose
    (analyte, valid_at) appears in `keys`. Only updates rows currently
    open on the tx-time half-pair (asserted_until IS NULL) and currently
    visible on the world-time half-pair (valid_until IS NULL OR
    valid_until > asserted_until). Returns the count of rows updated;
    the caller compares against len(keys) and warns on a partial-match
    miss (parser rounding produced a valid_at that doesn't exist on the
    prior episode)."""
```

Implementation:

```sql
UPDATE lab_record
   SET asserted_until = $5
  FROM unnest($3::text[], $4::timestamptz[]) AS k(analyte, valid_at)
 WHERE lab_record.tenant_id      = $1
   AND lab_record.episode_uuid   = $2
   AND lab_record.asserted_until IS NULL
   AND (lab_record.valid_until IS NULL OR lab_record.valid_until > $5)
   AND lab_record.analyte        = k.analyte
   AND lab_record.valid_at       = k.valid_at
```

`UPDATE … FROM unnest(...)` is the indexed-friendly form: nested-loop over the small `keys` array probes the PK `(tenant_id, episode_uuid, analyte, valid_at)`. Returns count updated; caller logs a warning when `count < len(keys)` (silent zero-match would mask a parser drift bug).

**`MedStore.supersede_matching`** (`src/gnokee/storage/med.py`):

Same pattern, three-column key:

```sql
UPDATE med_record
   SET asserted_until = $6
  FROM unnest($3::text[], $4::text[], $5::timestamptz[])
       AS k(drug_name, event_kind, valid_at)
 WHERE med_record.tenant_id      = $1
   AND med_record.episode_uuid   = $2
   AND med_record.asserted_until IS NULL
   AND (med_record.valid_until IS NULL OR med_record.valid_until > $6)
   AND med_record.drug_name      = k.drug_name
   AND med_record.event_kind     = k.event_kind
   AND med_record.valid_at       = k.valid_at
```

**`MetadataStore.supersede`** (`src/gnokee/storage/metadata.py`):

```python
async def supersede(
    self,
    *,
    conn: asyncpg.Connection,
    tenant_id: str,
    corrected_episode_uuid: UUID,
    new_episode_uuid: UUID,
    asserted_until: datetime,
) -> EpisodeMetadataRow:
    """Close prior episode_metadata. Validates same-tenant + exists +
    asserted_at axis. If named episode is already superseded, walks
    `superseded_by` chain to current head and supersedes the head
    instead. Raises CorrectsCrossTenantError / EpisodeNotFoundError /
    CorrectsAxisInversionError. Returns the head row (the row that
    was UPDATEd) — caller uses `.episode_uuid` for row-level supersession
    so lab/med rows close against the current head, not a stale alias."""
```

Validation lives here — single source of truth, runs inside the Stage 6 txn.

**Chain-walk semantics.** If caller names A in `corrects` but A is already superseded (`asserted_until IS NOT NULL`), `metadata.supersede` follows `superseded_by` repeatedly until it reaches a row with `asserted_until IS NULL` (the chain head), then supersedes that. Same-tenant + axis checks apply against the head.

**Chain-walk is a Python-side loop** with `SELECT … FOR UPDATE` on each hop — single-statement recursive CTE would be one round-trip but `FOR UPDATE` on a recursive CTE has Postgres-version-dependent gotchas; the depth-32 bound makes the loop's N+1 cost trivial in practice (1–3 hops typical). Each hop SELECTs `(tenant_id, asserted_at, asserted_until, superseded_by) FOR UPDATE` so a parallel ingest racing on the same chain serializes correctly.

Bounded depth — chains of length > 32 raise `CorrectsChainError` (defensive against cycles; migrations should make cycles impossible, but a runtime guard costs nothing).

**Concurrent-supersession serialization.** Default Postgres isolation is READ COMMITTED. Without explicit row locking, two concurrent ingests racing on `corrects=A` could both read `A.asserted_until IS NULL`, both UPDATE, and last-writer wins on `superseded_by` (silent data-loss on the chain). The chain-walk's `FOR UPDATE` SELECT on each hop locks the row through the ingest txn, so the second ingest blocks until the first commits or rolls back. After the first commits, the second's FOR UPDATE SELECT reads the now-closed row; the second walks `superseded_by` to the new head and supersedes that instead. Result: A → B → C linear chain even under concurrent corrects=A. No `superseded_by` overwrite.

Stage 6 wiring uses the returned head's UUID for row-level supersession so lab/med rows always close against the row that has open visible state.

### 4. Stage 6 wiring — `src/gnokee/ingest.py`

Inside `async with conn.transaction():`, **before** `metadata.write` / `vector.write_embedding` / `lab.write_rows` / `med.write_rows`:

```python
if episode.corrects is not None:
    head = await self.metadata.supersede(
        conn=conn,
        tenant_id=episode.tenant_id,
        corrected_episode_uuid=episode.corrects,
        new_episode_uuid=episode_uuid,
        asserted_until=asserted_at,
    )
    if lab_rows:
        await self.lab.supersede_matching(
            conn=conn,
            tenant_id=episode.tenant_id,
            episode_uuid=head.episode_uuid,
            keys=[(r.analyte, r.valid_at) for r in lab_rows],
            asserted_until=asserted_at,
        )
    if med_rows:
        await self.med.supersede_matching(
            conn=conn,
            tenant_id=episode.tenant_id,
            episode_uuid=head.episode_uuid,
            keys=[(r.drug_name, r.event_kind, r.valid_at) for r in med_rows],
            asserted_until=asserted_at,
        )
```

Note the parameter name is `episode_uuid` on the row-level adapters, not `corrected_episode_uuid` — the value passed in is the chain-walk-resolved head, which may be different from the user-supplied `corrects`. Naming the parameter `corrected_episode_uuid` would be a future-maintainer trap.

Order: validate-and-close-episode first (raises early), then row-level closes, then existing inserts.

Edge case — `corrects` set but no parseable lab/med rows in the new episode: episode-metadata supersession still runs. Row-level supersession is a no-op. Pure-narrative correction is supported.

### 5. Public helper signature — `src/gnokee/ingest.py`

The module-level `ingest_episode(...)` keyword-arg helper (the convenience surface alongside `IngestPipeline.ingest`) gains a `corrects: UUID | None = None` parameter that threads into the `EpisodeIn(...)` construction. Without this change, callers who use the helper instead of constructing `EpisodeIn` directly cannot pass `corrects`. Backward-compatible (default None).

## Validation rules (full table)

| Rule | When raised | Error class |
|---|---|---|
| Corrected episode must exist | `episode_metadata` SELECT returns no row | `EpisodeNotFoundError` |
| Same tenant | corrected row's `tenant_id` ≠ caller's `tenant_id` | `CorrectsCrossTenantError` |
| asserted_at axis | new `asserted_at <= corrected.asserted_at` (checked against the resolved chain head) | `CorrectsAxisInversionError` |
| Chain depth bounded | `superseded_by` walk exceeds 32 hops (cycle / runaway) | `CorrectsChainError` |
| Already-superseded is OK | not raised — chain-walk to head | (chained correction) |
| Partial-key UPDATE (zero or short match) | not raised — caller logs WARNING with `(updated_count, requested_count)` | (parser-drift signal) |

Chained correction semantics: A → B (corrects A) → C (corrects B). After C: `B.superseded_by = C` and `B.asserted_until = C.asserted_at`; A is left untouched (already pointed at B). Read-side time-travel (any reader filtering on `asserted_at <= as_of AND (asserted_until IS NULL OR asserted_until > as_of)` — the existing `lab.latest` / `lab.history` / `lab.aggregate` shape) walks the chain implicitly: at `as_of = T_B`, B is visible, A and C are not; at `as_of = T_C`, C is visible. `superseded_by` is provenance metadata for audit, not a read-path requirement.

If a caller mis-names A when the current head is B (i.e., `corrects=A` after A→B already happened), `metadata.supersede` walks `superseded_by` to find B (the open head) and supersedes B. Caller-friendly — clients don't have to track chain heads. Row-level updates target the resolved head's `episode_uuid` so lab/med supersession is consistent with episode-metadata supersession.

## Tests

### Unit (`tests/unit/`)

- `test_models.py`: `EpisodeIn(corrects=UUID("...")).corrects == UUID(...)`. Default is `None`. Empty-string-ish forms rejected by Pydantic UUID validator.

### Integration (`tests/integration/test_supersession_e2e.py`, new file)

Real Postgres + Neo4j + TEI. Ten cases:

1. **Lab happy path.** Panel A (K=2.8, Mg=1.4) + correction B (`corrects=A.uuid`, K=3.6 only). Assert: A.K closes, A.Mg stays open, B.K open.
2. **Med happy path.** "Started Lisinopril 10mg 2024-06-15" A + correction B (`corrects=A.uuid`, "Started Lisinopril 20mg 2024-06-15"). Assert: A's `event_kind=start` row closes, B's open.
3. **episode_metadata supersession.** After case 1: A's `asserted_until = B.asserted_at` and `superseded_by = B.uuid`.
4. **Aggregation respects supersession.** `lab_query.aggregate(min, K, 2024-Q2)` returns 3.6 (the v0.2.1 named bug).
5. **Cross-tenant rejected.** Tenant A ingest, tenant B tries `corrects=A_episode_uuid` → `CorrectsCrossTenantError`. No rows touched. No Graphiti orphan in tenant B's group.
6. **Episode not found.** `corrects=UUID("00000000-…")` → `EpisodeNotFoundError`. No Graphiti orphan.
7. **Axis inversion.** Explicit `asserted_at` older than corrected → `CorrectsAxisInversionError`.
8. **Chained correction.** A → B → C as above.
9. **Empty new rows + corrects.** Pure-narrative correction body. `episode_metadata` closes, no row UPDATEs, no error.
10. **Idempotent replay.** Same `our_id` + same `corrects` re-ingest. Two distinct flows:
    - **Stage 1b short-circuit** (`metadata.get_by_our_id` finds the row): supersession never enters the txn; `replayed=True` returned with the original receipt. No double-supersession.
    - **`_OurIdRaceLost`** (race past Stage 1b, supersession SQL executes inside the txn, `metadata.write` then raises): the txn rolls back, so the race-loser's supersession UPDATEs are reverted along with everything else. Winner's supersession (applied by the first ingest's committed txn) stays intact. The race-loser then recovers the winner via `get_by_our_id` and returns the winner's receipt with `replayed=True`. Net: supersession applied once, by the winner; race-loser's UPDATEs never persist.
11. **Chain-walk from stale target.** A → B → ingest C with `corrects=A` (caller named the original, not the current head B). Assert: B is what closes (`B.superseded_by=C`, `B.asserted_until=C.asserted_at`); A stays as-is (already closed by B); C's row-level supersession targets B's lab/med rows where keys match.

### Spike harness updates

Two structural harness changes are required before either spike can exercise `corrects:`. The existing `ingest_corpus` helper in both Q7 and Q8 calls `ingest_episode(...)` with a fixed parameter set (`content`, `valid_at`, `asserted_at`, `our_id`, `sensitive`) and does NOT thread arbitrary corpus fields through. Without harness plumbing, adding `corrects:` to corpus.jsonl is dead.

**Harness change 1 — `corrects:` plumbing in `ingest_corpus`.** Both `evals/spike_q7_lab_results/run.py` and `evals/spike_q8_med_supersession/run.py` extend their `ingest_corpus` helper:
- Read optional `corrects` (a stable corpus `our_id` reference, e.g. `"q7-spike:lab_2024_04_10"`) from each corpus entry.
- After the first ingest pass populates a `our_id → episode_uuid` map (from the receipt of each ingest), do a second pass / inline lookup: when an entry carries `corrects: <our_id>`, look up the runtime UUID from the map and pass `corrects=<that UUID>` into `ingest_episode(...)`.
- Episodes referencing a `corrects:` target MUST be ordered after the target in the corpus file (the harness ingests sequentially in file order).

This pattern is reusable for any future spike that needs intra-corpus episode dependencies (e.g. cross-document links, contradiction targets). One spike-harness primitive, two consumers.

**Harness change 2 — fresh tenant per re-spike.** Existing tenants `spike-q7-v0_2` and `spike-q8-v0_2` already have their corpus episodes ingested without `corrects:`. The `our_id`-based idempotency short-circuit (Stage 1b) returns `replayed=True` and skips Stage 6 entirely, so re-running the v0.2.0 harness against the existing tenant **never executes the supersession SQL**. Re-spike MUST use fresh tenant ids `spike-q7-v0_2_1` and `spike-q8-v0_2_1` (or a destructive-reset of the existing tenants — fresh tenants are simpler and document the methodology). The harness's `TENANT_ID` constant is bumped accordingly. Old fixtures may stay as historical references.

**Q7 corpus + queries** (`evals/spike_q7_lab_results/`):
- The existing April panel correction episode (search corpus.jsonl for the `our_id` matching the corrected April panel) gains `corrects: <our_id of original April panel>` field.
- `queries.yaml` is unchanged. `q_k_lowest_2024` already exists with the right `value_substring` shape; the supersession fix flips it from FAIL to PASS because the typed `min` op now skips the closed 2.8 mmol/L row.
- Re-spike runs **all 15 queries** (not just `q_k_lowest_2024`) — regression detection. Harness already loops unconditionally; the spec mandates the full run for the v0.2.1 grade.
- Expected outcome: pass = **11/15 (73.3 %)** (one more PASS than v0.2.0's 10/15). Verdict stays ADOPT_WITH_GAPS.

**Q8 corpus + queries** (`evals/spike_q8_med_supersession/`):
- Add one synthetic correction episode (e.g. `med_2024_02_03_lisinopril_correction` correcting `med_2024_02_01_lisinopril_start` to a different starting dose). The new episode carries `corrects: "q8-spike:med_2024_02_01_lisinopril_start"` (or whatever the original episode's `our_id` is).
- Add one query `q_lisinopril_dose_corrected` to `queries.yaml` — `value_substring` matches the corrected dose, expects the correction episode in retrieval, exercises `gnokee_med_query` typed read with `valid_at` pinned post-correction.
- Re-spike: pass = **16/16 (100 %)** — Q8 *extends to* 16 queries; the new query confirms med-side `corrects:` parity. Verdict stays ADOPT.

## Release flow

PR 1: `feat(ingest): EpisodeIn.corrects + Stage 6 supersession (v0.2.1)`
- All code + unit + integration tests
- Q7 corpus update + harness re-spike + ADR-0009 status note amendment
- Q8 corpus extension + ADR-0010 status note amendment

PR 2: `chore(release): v0.2.1` (mirrors v0.2.0 cut)
- pyproject `0.2.0 → 0.2.1`
- CHANGELOG `[0.2.1]` entry (drafted in design)
- Tag-cut + push + GitHub release

## Open questions resolved during brainstorm

| Q | Resolution |
|---|---|
| Granularity? | Per-row match on `(analyte, valid_at)` / `(drug_name, event_kind, valid_at)` |
| Episode-metadata supersession too? | Yes |
| Validation: same tenant? | Yes — mandatory |
| Validation: episode exists? | Yes — fail-fast |
| Validation: already-superseded OK? | Yes — chain naturally |
| Validation: asserted_at axis guard? | Yes |
| Graphiti edge supersession? | No — out of scope, document as known limitation |
| New migration needed? | No — schema already has `asserted_until` columns |
| SQL form for matching-row UPDATE? | `UPDATE … FROM unnest($a, $b) AS k(...) WHERE row.col = k.col` (PK-indexed nested loop) |
| Param name on row-level supersede? | `episode_uuid` (receives chain-walk-resolved head, NOT caller's `corrects`) |
| Chain depth / cycle error class? | `CorrectsChainError` — distinct from `CorrectsAxisInversionError` |
| Concurrent-supersession serialization? | `SELECT … FOR UPDATE` per chain-walk hop — second ingest blocks until first commits, walks to new head |
| Silent zero-match on UPDATE? | Caller logs WARNING when `count < len(keys)` — surfaces parser drift on `valid_at` rounding |
| `time_travel(as_of=t)` in v0.2.1 scope? | No — read-side time-travel is implicit in existing `lab.latest`/`lab.history`/`lab.aggregate` filter shape |
| `ingest_episode(...)` helper signature? | Threads `corrects: UUID \| None = None` through to `EpisodeIn(...)` |
| Q7/Q8 harness blocker? | `ingest_corpus` plumbing + fresh tenant ids `spike-q7-v0_2_1` / `spike-q8-v0_2_1` |

## Deferred to implementation plan (specialist findings, low-severity)

These items emerged from specialist review (gnokee-reviewer + bi-temporal-auditor + ingest-pipeline-specialist + postgres-pgvector-specialist + eval-spike-author) and are correct but small enough to live in the implementation plan rather than amend the design:

- **RLS GUC discipline.** `set_config('app.current_tenant', tenant_id, true)` MUST be set on the connection before the Stage 6 txn block. Existing ingest does this; spec confirms but doesn't repeat. Implementation plan re-states.
- **Partial index migration (perf).** `CREATE INDEX … ON lab_record (tenant_id, episode_uuid, analyte, valid_at) WHERE asserted_until IS NULL`. Pure perf win; non-load-bearing for v0.2.1 correctness. Optional v0.2.2.
- **Encrypted-body branch.** `corrects` is orthogonal to the body-shape boundary; encrypted-body is currently `NotImplementedYet` so the question is moot. Document explicitly when encrypted-body lands.
- **Chain-walk implementation primitive.** Python loop with `FOR UPDATE` SELECT per hop is the design choice (depth bound 32 makes N+1 trivial; recursive CTE has version-dependent `FOR UPDATE` gotchas). Plan re-confirms this.
- **`our_id` column in SELECT list.** When `metadata.supersede` SELECTs the corrected row to return as `EpisodeMetadataRow`, the SELECT list must include `our_id` (added in migration 0005, post-dates the original 0001 schema). Easy trap — call out in plan.
- **Re-spike methodology framing.** Headline metric uses "Q8 extends to 16/16" not "Q8 stays at 100%" (different denominator).
- **`--skip-ingest` env-var alignment.** Both Q7 and Q8 currently use `argparse --skip-ingest` rather than the template's `GNOKEE_SPIKE_SKIP_INGEST=1` env-var convention. Pre-existing template drift, not introduced by v0.2.1; orthogonal.

## Next step

Invoke `writing-plans` skill with this spec to produce a detailed implementation plan for execution.
