# Documentation overhaul — design

> Status: drafted 2026-05-10. Captures the gap audit and target shape
> for a four-PR documentation pass covering contributors, casual users,
> integrators, and operators.
>
> Brainstorming session origin: user request "review project
> documentation, identify gaps and proceed with creating proper
> documentation for anyone who may want to use or contribute to the
> project". Resolution: open-with-guardrails contribution stance,
> markdown-in-repo with `docs/README.md` ToC (no docs site), four
> staged PRs by audience.

## 1. Problem

gnokee is on PyPI at v0.4.0, supports two production consumers (Omur,
noggin), and has 30+ markdown docs across `docs/`, but the contributor
and operator on-ramps are missing or stale:

- `README.md` says *"Pre-v0.1: closed to external contributions"* —
  reality: project at v0.4.0 with monthly releases.
- No `CONTRIBUTING.md`, `SECURITY.md`, `CODE_OF_CONDUCT.md`,
  `SUPPORT.md`, issue templates, or PR template at the GitHub level.
- No `docs/README.md` index — visitors land on `docs/architecture.md`
  with no map of the rest.
- `docs/evals/methodology.md` is a 30-line placeholder; real
  methodology lives in `eval_delta_gate.md` + spike READMEs.
- No FAQ, troubleshooting, alternatives-comparison, or production
  deployment guide.
- No runnable `examples/` tree — recipes live as prose inside
  `docs/integration/consumer-patterns.md`.
- No standalone Python API or MCP API reference — schemas live across
  `docs/specs/v0.1.md` §4–6 + ADRs.
- No "extending gnokee" doc — extension points (adapters, embedders,
  LLM swap) exist but aren't surfaced for integrators.
- No privacy-posture / threat-model document — load-bearing for a
  project whose name encodes "no key" as an architectural invariant.

## 2. Goals

- Open-with-guardrails contribution stance, codified.
- Audience-grouped entry map for the existing 30+ doc tree.
- Casual-user friction at first touch reduced (FAQ, troubleshooting,
  alternatives, README polish).
- Integrator surface (API ref, examples, extending) made first-class
  rather than archaeology across specs and ADRs.
- Operator surface (deploy, observability, privacy posture) lifted
  from "buried in architecture.md" to standalone docs.
- Zero file moves — preserve every existing ADR / spec / integration
  link.

## 3. Non-goals

- Docs site (mkdocs / Sphinx / GitHub Pages). Defer until v1.0; the
  in-repo markdown design will consume cleanly into mkdocs later
  without reshape.
- Sphinx autodoc Python API reference. Hand-written markdown ref is
  cheaper at this codebase size and avoids the docstring-as-public-API
  weight.
- Restructuring `docs/` into audience subfolders. Existing files stay
  put; the ToC handles audience navigation.
- Translating any prose into other languages.
- Replacing AGENTS.md. AGENTS.md remains the agent-facing guide;
  `CONTRIBUTING.md` is the human-facing companion that defers to it
  on workflow specifics.

## 4. Layout (target final state)

```text
ROOT/
  CONTRIBUTING.md          (NEW)   thin landing → docs/
  CODE_OF_CONDUCT.md       (NEW)   Contributor Covenant 2.1
  SECURITY.md              (NEW)   vuln disclosure path
  SUPPORT.md               (NEW)   where questions go
  README.md                (EDIT)  Contributing rewrite, diagram,
                                   lite-mode + encrypted-body mention,
                                   doc-index link
  examples/                (NEW)
    README.md
    01_quickstart_demo.py
    02_lite_mode_with_outbox.py
    03_mcp_clients/
      claude_desktop.md
      claude_code.md
      cursor.md
    04_encrypted_body.py
    05_consumer_render_clinical.py

.github/
  ISSUE_TEMPLATE/
    bug_report.yml         (NEW)
    feature_request.yml    (NEW)
    config.yml             (NEW)
  PULL_REQUEST_TEMPLATE.md (NEW)

docs/
  README.md                (NEW)   audience-grouped ToC
  releasing.md             (NEW)   tag-driven release flow
  faq.md                   (NEW)
  troubleshooting.md       (NEW)
  alternatives.md          (NEW)
  api/
    python.md              (NEW)
    mcp.md                 (NEW)
  extending.md             (NEW)
  deploy.md                (NEW)
  observability.md         (NEW)
  privacy-posture.md       (NEW)
  evals/
    methodology.md         (REWRITE)
```

Net: 19 new files, 2 edits, 0 moves.

## 5. Audience answers (decisions baked in)

| Decision | Resolution |
|---|---|
| Audiences to cover end-to-end | All four — contributor, integrator, casual user, operator |
| Contribution stance | Open with guardrails (issues + PRs welcome; new MCP tools / breaking changes / new ADRs require maintainer pre-approval; AGENTS.md "do not" list normative) |
| Doc surface | Markdown-in-repo, indexed via `docs/README.md`. No site, no Sphinx |
| Delivery shape | Four staged PRs by audience |

## 6. PR breakdown

### PR1 — Contributor onramp

**Files (8 new + 1 edit):**

- `CONTRIBUTING.md` — welcome, scope, dev setup pointer, coding
  standards (ruff format, mypy strict on `src/gnokee/`, tach
  boundaries), commit-message style, test policy, eval-delta-gate
  policy, review process (lead reviewer + specialist routing pointer
  to AGENTS.md), license inbound = outbound.
- `CODE_OF_CONDUCT.md` — Contributor Covenant 2.1; reporting contact
  matches SECURITY.md.
- `SECURITY.md` — supported versions (latest minor only pre-v1.0),
  private vuln-disclosure path (GitHub Security Advisories preferred),
  SLO (acknowledge ≤5 days, fix ≤30 days when severe), scope
  (gnokee Python package + MCP server; not Postgres / Neo4j / TEI /
  consumer-supplied LLM), coordinated-disclosure expectation.
- `SUPPORT.md` — questions → Discussions; bugs/features → Issues;
  commercial / Omur ping a different channel; quick-answer pointers
  to FAQ / troubleshooting.
- `.github/ISSUE_TEMPLATE/bug_report.yml` — issue form (gnokee
  version, Python version, repro, env, redacted logs).
- `.github/ISSUE_TEMPLATE/feature_request.yml` — use case, proposed
  surface, ADR pre-flight checklist.
- `.github/ISSUE_TEMPLATE/config.yml` — disable blank issues, link to
  Discussions / SUPPORT / SECURITY.
- `.github/PULL_REQUEST_TEMPLATE.md` — what / why, AGENTS.md "do not"
  checklist, test plan, eval delta, ADR ref, reviewer routing
  self-suggestion.
- `docs/releasing.md` — versioning (SemVer), pre-release checks,
  release flow (bump pyproject.toml → CHANGELOG → `chore(release):`
  PR → tag `vX.Y.Z` → Trusted Publishing fires → verify on PyPI),
  rc-tag flow, rollback (yank + new patch), post-release rituals.
- `README.md` Contributing § rewrite — replace stale "Pre-v0.1
  closed" line; link to CONTRIBUTING / SECURITY / SUPPORT / CoC.

### PR2 — Doc index + casual-user polish

**Files (4 new + 1 rewrite + 1 edit):**

- `docs/README.md` — audience-grouped ToC (Evaluating /
  Integrating / Operating / Contributing), one-sentence "what's
  inside" per link.
- `docs/faq.md` — "is gnokee for me?", "why not Mem0?",
  "do I need Neo4j?", "Mac arm64 + TEI?", "production-ready?",
  "what's lite mode?", "what's encrypted_body?", "how is forgetting
  different?".
- `docs/troubleshooting.md` — symptom → cause → fix table for
  compose stack issues, TEI image arch, pgvector dim mismatch, empty
  recall causes, contradiction degraded path, idempotency duplicates,
  MCP transport, RLS GUC.
- `docs/alternatives.md` — comparison matrix vs Mem0 /
  Graphiti-alone / Zep-OSS / basic-memory across bi-temporal,
  contradiction handling, forgetting model, multi-tenancy,
  multilingual, MCP-native, license, deps. Cite ADR-0012 verdict
  honestly (gnokee currently REJECT on LongMemEval-S strict;
  bottleneck = synth-prompt abstention bias per #62).
- `docs/evals/methodology.md` rewrite — replace 30-line placeholder.
  Cover: spike harness pattern, eval-delta gate contract, cross-tool
  Q10 methodology, pointers to spike READMEs.
- `README.md` polish — ASCII architecture diagram from
  `architecture.md` lines 10–31; lite-mode mention; encrypted-body
  mention; "Documentation" section linking `docs/README.md`; "MCP
  client setup" link → `examples/03_mcp_clients/` (live after PR3).

### PR3 — Integrator surface

**Files (3 new docs + 8 examples files):**

- `docs/api/python.md` — `ingest_episode`, `recall`,
  `fact_provenance`, `lab_query`, `med_query`,
  `run_deferred_extraction`. Per function: signature, parameters,
  return type, raises, example, cross-reference to `models.py`.
  Boundary invariants, async-first, tz-aware datetime invariant,
  `our_id` idempotency rule.
- `docs/api/mcp.md` — five MCP tools: `gnokee_ingest_episode`,
  `gnokee_recall`, `gnokee_fact_provenance`, `gnokee_lab_query`,
  `gnokee_med_query`. Input/output schemas, parameter descriptions
  verbatim from `Field(description=…)`, JSON examples, transport
  modes (stdio default, HTTP dev-only).
- `docs/extending.md` — extension points and stability:
  (1) writing an ingest adapter; (2) swapping the embedder
  (bge-m3 1024-dim invariant, Q6 cosine-1.0000 parity, re-embed
  migration playbook); (3) swapping the LLM (OpenAI-compatible
  contract); (4) future Graphiti backend swap (ADR-0005, AGE
  blockers); (5) stability promise (pre-1.0 unstable, ADRs gate
  breaking changes).
- `examples/README.md` — index, run instructions, prerequisites
  per example.
- `examples/01_quickstart_demo.py` — standalone copy-pasteable
  ingest + recall + contradiction print.
- `examples/02_lite_mode_with_outbox.py` — outbox table DDL +
  producer + drainer worker, lite-mode `extract=False`,
  idempotency via `our_id`.
- `examples/03_mcp_clients/claude_desktop.md` —
  `claude_desktop_config.json` snippet + setup steps.
- `examples/03_mcp_clients/claude_code.md` — `.mcp.json` snippet.
- `examples/03_mcp_clients/cursor.md` — Cursor MCP config snippet.
- `examples/04_encrypted_body.py` — consumer-side libsodium
  SecretBox encrypt; build `EncryptedBody`; ingest; recall returns
  `encrypted_bodies[]`; consumer decrypts.
- `examples/05_consumer_render_clinical.py` — lab + med body
  render shapes; ingest; `gnokee_lab_query` (latest + history +
  abnormal); `gnokee_med_query` (active + switches).

### PR4 — Operator surface

**Files (3 new):**

- `docs/deploy.md` — image pinning (override `GNOKEE_TEI_IMAGE`
  with sha digest, pin pgvector + neo4j digests); secrets via env /
  secret manager; RLS GUC pattern (consumer middleware
  `set_config('app.current_tenant', …, true)` per request);
  healthchecks; volume strategy (named volumes, backup, no
  compose-managed volumes in prod); scaling (single-tenant per
  binary; multi-tenant with `group_id` discipline; horizontal
  scaling = N gnokee processes on shared Postgres + Neo4j); resource
  floors; v0.1 docker-compose dev-only warning.
- `docs/observability.md` — what gnokee logs (structlog JSON;
  mandatory fields `tenant_id`, `episode_uuid`, `latency_ms`,
  `stage`); what gnokee never logs (content body, embedding
  vectors, LLM prompts); v0.1 logs only; v0.2+ Prometheus + OTel
  roadmap; recall telemetry on `RecallResponse` (#54 lanes); ingest
  receipt telemetry; how to ship logs (consumer responsibility);
  recommended dashboards.
- `docs/privacy-posture.md` — threat model; "no key" invariant;
  encrypted-body lifecycle; tenant isolation (Postgres RLS +
  Neo4j `group_id` discipline); fields stored vs not (content
  plaintext unless encrypted_body; embedding vector retains
  semantic content — caveat); LLM endpoint exposure; GDPR
  alignment via 3 forgetting modes; what gnokee is NOT (not a HIPAA
  BAA, not a SOC2 attestation — gnokee is library code, hosting is
  consumer's call).

## 7. Cross-cutting design rules

- **Style:** terse, technical, AGENTS.md-style. No marketing fluff.
  Status banner at top of any pre-1.0 doc ("Status: pre-1.0 — public
  surface may break per ADR").
- **Cross-linking:** every new doc links back to `docs/README.md`
  ToC. Every claim about behaviour cites its ADR / spec / commit.
- **Single source of truth:** new prose docs lift content from
  existing authoritative files (ADRs, specs, integration_patterns).
  Don't duplicate; link.
- **Lint coverage:** new markdown should pass existing pre-commit
  hooks (trailing whitespace, end-of-file fixer, line-ending
  normalization). No new lint required.
- **Validation:** PR2 must include a smoke check that all internal
  `[…](path)` links in `docs/README.md` resolve. Optional GitHub
  Actions step running `lychee` or `markdown-link-check` on
  `docs/**.md`. Decide in PR2 review.
- **No new dependencies on the runtime / build path.** Examples may
  pull `pynacl` from the existing `[dev]` extra; nothing new is
  added to the `dependencies` list.
- **No file moves.** Every existing ADR / spec / integration link
  must continue to resolve.

## 8. Done definition

This pass is done when:

- All 19 new files + 2 rewrites/edits land on `main` across PRs 1–4.
- README's stale "Pre-v0.1: closed to external contributions" line
  is replaced.
- `docs/README.md` is the canonical doc-tree entry point.
- Every internal markdown link in the new docs resolves at PR-merge
  time.
- `examples/` scripts run cleanly against a local compose stack
  (manual smoke gate; no CI yet).
- v0.4.x backlog stays empty of doc-related items.

Out of scope for this pass: docs site, Sphinx autodoc, multi-language
docs, screencasts, marketing site copy.
