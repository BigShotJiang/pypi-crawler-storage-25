# ADR-0014: append-only `fact_revision` log + `gnokee_fact_history` MCP tool — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship an append-only fact-grain revision log keyed by `fact_id`, populated on every accepted Stage 6 fact, queryable as bi-temporal history via the new `gnokee_fact_history` MCP tool. Unblocks #142 (ADR-0013 `output_shape:fact`) and ADR-0015 `as_of` wiki header.

**Architecture:**
- **Storage.** New Postgres table `fact_revision` (migration 0019) with FK to `episode_metadata(episode_uuid) ON DELETE CASCADE` — forget pipeline cleanup is automatic.
- **Identity (Option C).** `fact_id` defaults to `fact_uuid` (Graphiti edge uuid). When `EpisodeIn.corrects:` is set, gnokee fetches prior episode's edges and matches new edges by triple `(source_node_uuid, predicate, target_node_uuid)`; matched new edges inherit `fact_id` from prior, linked via `prior_revision_id`.
- **Write placement (Option B — Stage 6c).** New Stage 6c block runs after Stage 6/6b, before Stage 7. Skew-tolerant: failure increments telemetry, does not roll back Graphiti.
- **Supersession policy (Option A).** Append new revisions only. No closure markers, no tombstones. Closure timestamp obtained by joining `fact_revision.fact_uuid → graphiti edge.invalid_at`.

**Tech Stack:** Postgres 17 + pgvector, asyncpg, graphiti-core 0.29, FastMCP, pytest-asyncio. Python 3.10+ type-strict, ruff format. Raw SQL migrations per ADR-0006.

---

## Files Touched

**Create:**
- `docs/adr/0014-fact-revision-log.md` — ADR
- `src/gnokee/storage/migrations/0019_fact_revision.sql` — table + indexes
- `src/gnokee/storage/fact_revision.py` — `FactRevisionRow` + CRUD helpers
- `src/gnokee/fact_history.py` — `FactHistoryPipeline.fact_history()` public API
- `tests/unit/test_fact_revision_models.py` — model + serialization tests
- `tests/integration/test_fact_revision_write.py` — Stage 6c hook tests
- `tests/integration/test_fact_revision_supersession.py` — `corrects:` inheritance tests
- `tests/integration/test_fact_revision_history_query.py` — `gnokee_fact_history` bi-temporal tests
- `tests/integration/test_fact_revision_forget_cascade.py` — FK CASCADE under forget
- `tests/integration/test_fact_revision_perf.py` — p95 ≤10ms benchmark gate

**Modify:**
- `src/gnokee/models.py` — add `FactRevision` Pydantic model
- `src/gnokee/storage/graph.py` — add `list_episode_edge_triples()` helper
- `src/gnokee/ingest.py` — add Stage 6c block (after line ~745, before Stage 7)
- `src/gnokee/bootstrap.py` — wire `FactHistoryPipeline` + `FactRevisionStore`
- `src/gnokee/mcp.py` — register `gnokee_fact_history` tool; un-defer reference at `mcp.py:964`
- `src/gnokee/wiki_export.py` — un-defer references at lines 28 + 153
- `src/gnokee/__init__.py` — export `fact_history`
- `docs/adr/0013-gnokee-query-declarative-envelope.md` — note un-defer is now possible (separate PR is #142)
- `docs/adr/0015-wiki-export-llms-txt.md` — un-defer `as_of` header note
- `pyproject.toml` — bump version to `0.9.0a0` (pre-release on this branch)

---

## Task 1 — ADR-0014 doc

**Files:**
- Create: `docs/adr/0014-fact-revision-log.md`

- [ ] **Step 1: Draft the ADR**

Write the file with sections matching existing ADRs (status / context / decision / consequences / alternatives / cross-refs). Use `docs/adr/0026-forget-pipeline.md` as the structural template.

Required content blocks:

1. **Status:** Proposed → Accepted (flip when PR merges).
2. **Context:** restate issue #73 framing — `gnokee_history_of` (#123) ships episode-grain; this ADR ships fact-grain. Cite Memory Bank `MemoryRevision` + A-MEM bidirectional evolution as adoption candidates. Cite the 5 deferred-reference call sites.
3. **Decision (three sub-decisions):**
   - **Identity = Option C.** Default `fact_id = fact_uuid`; `EpisodeIn.corrects:` triggers triple-match inheritance via `prior_revision_id`. Reason: append-only contract + AGENTS.md no-auto-resolve; cross-session implicit clustering would violate that.
   - **Write placement = Stage 6c.** Separate fallible block after Stage 6/6b, before Stage 7. Reason: Graphiti `add_episode` is opaque — skew is the unavoidable failure mode anyway; telemetry + `resume_ingest` extension cover it.
   - **Supersession = new rows only.** No closure-marker rows. Reason: append-only ≠ "write more rows on closure"; closure timestamp lives on Graphiti `edge.invalid_at`.
4. **Consequences:**
   - Adds 1 write per accepted fact; p95 budget ≤10ms.
   - Forget cascade: FK ON DELETE CASCADE from `episode_metadata(episode_uuid)` — automatic.
   - Skew window: Stage 6c failure leaves Graphiti edges without revision rows; surfaced via `IngestTelemetry.fact_revision_skew_count` (new field).
   - `gnokee_fact_history` returns empty array for `fact_id` values minted before this migration lands (documented; no backfill).
5. **Alternatives considered:** Option A (fact_id == fact_uuid, no inheritance), Option B (uuid5 triple-hash, cross-session clustering). Reject A on "useless flat array" grounds; reject B on "fragile predicate-string clustering" grounds.
6. **Cross-refs:** ADR-0001, ADR-0004, ADR-0006, ADR-0008, ADR-0010, ADR-0013, ADR-0015, ADR-0024, ADR-0026. Issues: #73 (this), #123 (sibling), #142 (consumer), #71 (umbrella).

- [ ] **Step 2: Commit**

```bash
git checkout -b feat/adr-0014-fact-revision
git add docs/adr/0014-fact-revision-log.md
git commit -m "docs(adr): draft ADR-0014 fact_revision log + gnokee_fact_history (#73)"
```

---

## Task 2 — Migration 0019: `fact_revision` table

**Files:**
- Create: `src/gnokee/storage/migrations/0019_fact_revision.sql`
- Test: `tests/integration/test_fact_revision_write.py` (migration-applies subtest)

- [ ] **Step 1: Write the failing test**

```python
# tests/integration/test_fact_revision_write.py
"""Stage 6c fact_revision write hook (issue #73 / ADR-0014)."""
import pytest
from uuid import uuid4

from gnokee.storage.migrate import apply, MIGRATIONS_DIR

pytestmark = pytest.mark.asyncio(loop_scope="session")


async def test_migration_0019_creates_fact_revision_table(pg_dsn: str, pg_pool):
    """0019 applies; table + indexes exist; tombstone CHECK rejects empty fact_text."""
    await apply(pg_dsn, MIGRATIONS_DIR)
    async with pg_pool.acquire() as conn:
        # table exists
        exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM information_schema.tables "
            "WHERE table_schema = 'public' AND table_name = 'fact_revision')"
        )
        assert exists, "fact_revision table missing"

        # tombstone CHECK rejects empty fact_text
        with pytest.raises(Exception) as exc_info:
            await conn.execute(
                "INSERT INTO fact_revision "
                "(fact_id, fact_uuid, tenant_id, episode_uuid, valid_at, asserted_at, "
                " fact_text, source_node_uuid, predicate, target_node_uuid) "
                "VALUES ($1, $2, 't', $3, now(), now(), '', $4, 'rel', $5)",
                uuid4(), uuid4(), uuid4(), uuid4(), uuid4(),
            )
        assert "fact_text_nonempty" in str(exc_info.value).lower() or "check" in str(exc_info.value).lower()

        # index on (tenant_id, fact_id, asserted_at DESC) exists
        idx_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM pg_indexes "
            "WHERE schemaname = 'public' AND tablename = 'fact_revision' "
            "AND indexname = 'fact_revision_fact_id_asserted_at_idx')"
        )
        assert idx_exists
```

- [ ] **Step 2: Run test to verify it fails**

```bash
uv run pytest tests/integration/test_fact_revision_write.py::test_migration_0019_creates_fact_revision_table -v
```

Expected: FAIL with `fact_revision table missing` (migration file doesn't exist yet).

- [ ] **Step 3: Write the migration**

Create `src/gnokee/storage/migrations/0019_fact_revision.sql`:

```sql
-- 0019_fact_revision.sql
-- ADR-0014 — append-only fact-grain revision log (#73).
--
-- One row per accepted Graphiti edge. `fact_id` is the LOGICAL identifier
-- of a proposition across rewrites; `fact_uuid` is the Graphiti edge uuid.
-- When EpisodeIn.corrects: drives Stage 6c inheritance, the new revision
-- inherits prior `fact_id` and points to prior via `prior_revision_id`.
-- Otherwise, fact_id = fact_uuid (passthrough).
--
-- Append-only: no UPDATE, no DELETE outside forget cascade. CHECK
-- forbids empty fact_text (tombstones DISALLOWED per ADR-0010).
--
-- Forget integration: FK to episode_metadata(episode_uuid) ON DELETE
-- CASCADE — forget pipeline drops rows automatically.

CREATE TABLE IF NOT EXISTS fact_revision (
    revision_id        UUID        NOT NULL DEFAULT gen_random_uuid(),
    fact_id            UUID        NOT NULL,
    fact_uuid          UUID        NOT NULL,
    tenant_id          TEXT        NOT NULL,
    episode_uuid       UUID        NOT NULL,
    valid_at           TIMESTAMPTZ NOT NULL,
    asserted_at        TIMESTAMPTZ NOT NULL,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    fact_text          TEXT        NOT NULL,
    source_node_uuid   UUID        NOT NULL,
    predicate          TEXT        NOT NULL,
    target_node_uuid   UUID        NOT NULL,
    prior_revision_id  UUID,
    PRIMARY KEY (revision_id),
    CONSTRAINT fact_text_nonempty CHECK (length(fact_text) > 0),
    CONSTRAINT fact_revision_episode_fk
        FOREIGN KEY (tenant_id, episode_uuid)
        REFERENCES episode_metadata (tenant_id, episode_uuid)
        ON DELETE CASCADE,
    CONSTRAINT fact_revision_prior_fk
        FOREIGN KEY (prior_revision_id)
        REFERENCES fact_revision (revision_id)
        ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS fact_revision_fact_id_asserted_at_idx
    ON fact_revision (tenant_id, fact_id, asserted_at DESC);

CREATE INDEX IF NOT EXISTS fact_revision_tenant_valid_at_idx
    ON fact_revision (tenant_id, valid_at);

CREATE INDEX IF NOT EXISTS fact_revision_fact_uuid_idx
    ON fact_revision (tenant_id, fact_uuid);

CREATE INDEX IF NOT EXISTS fact_revision_episode_uuid_idx
    ON fact_revision (tenant_id, episode_uuid);

-- RLS: matches existing episode_metadata posture (tenant_id GUC).
ALTER TABLE fact_revision ENABLE ROW LEVEL SECURITY;

CREATE POLICY fact_revision_tenant_isolation ON fact_revision
    USING (tenant_id = current_setting('app.current_tenant', true));
```

NOTE on FK: `episode_metadata` PK must be `(tenant_id, episode_uuid)` for this FK to work. Verify in step 4 — if PK is just `(episode_uuid)`, drop `tenant_id` from FK constraint and rely on application-level tenancy.

- [ ] **Step 4: Verify episode_metadata PK shape**

```bash
grep -n "PRIMARY KEY\|PRIMARY  KEY" src/gnokee/storage/migrations/0001_episode_metadata.sql
```

If PK is `(episode_uuid)` only, edit the migration: change FK to `FOREIGN KEY (episode_uuid) REFERENCES episode_metadata (episode_uuid)`.

- [ ] **Step 5: Run test to verify it passes**

```bash
uv run pytest tests/integration/test_fact_revision_write.py::test_migration_0019_creates_fact_revision_table -v
```

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add src/gnokee/storage/migrations/0019_fact_revision.sql tests/integration/test_fact_revision_write.py
git commit -m "feat(storage): migration 0019 fact_revision table + RLS (#73)"
```

---

## Task 3 — `FactRevisionRow` dataclass + CRUD module

**Files:**
- Create: `src/gnokee/storage/fact_revision.py`
- Test: `tests/integration/test_fact_revision_write.py` (extends Task 2)

- [ ] **Step 1: Write the failing test (CRUD round-trip)**

Append to `tests/integration/test_fact_revision_write.py`:

```python
from datetime import datetime, UTC
from gnokee.storage.fact_revision import FactRevisionRow, FactRevisionStore


async def test_insert_and_fetch_by_fact_id(pg_pool):
    store = FactRevisionStore()
    fact_id = uuid4()
    fact_uuid = fact_id  # passthrough case
    tenant_id = "t-test-1"
    ep_uuid = uuid4()
    # Pre-condition: insert a parent episode_metadata row so FK holds.
    async with pg_pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO episode_metadata "
            "(tenant_id, episode_uuid, name, valid_at, asserted_at, asserted_until, group_id, our_id) "
            "VALUES ($1, $2, 'test', now(), now(), 'infinity', $1, NULL)",
            tenant_id, ep_uuid,
        )
        row = FactRevisionRow(
            fact_id=fact_id,
            fact_uuid=fact_uuid,
            tenant_id=tenant_id,
            episode_uuid=ep_uuid,
            valid_at=datetime.now(UTC),
            asserted_at=datetime.now(UTC),
            fact_text="Vadim takes Metformin 500mg",
            source_node_uuid=uuid4(),
            predicate="takes",
            target_node_uuid=uuid4(),
            prior_revision_id=None,
        )
        await store.insert_batch(conn=conn, rows=[row])
        fetched = await store.fetch_by_fact_id(
            conn=conn, tenant_id=tenant_id, fact_id=fact_id,
        )
    assert len(fetched) == 1
    assert fetched[0].fact_text == "Vadim takes Metformin 500mg"
    assert fetched[0].fact_id == fact_id


async def test_empty_fact_text_rejected_at_python_layer(pg_pool):
    """Defense in depth: store enforces nonempty BEFORE SQL."""
    store = FactRevisionStore()
    with pytest.raises(ValueError, match="fact_text"):
        FactRevisionRow(
            fact_id=uuid4(), fact_uuid=uuid4(), tenant_id="t",
            episode_uuid=uuid4(), valid_at=datetime.now(UTC),
            asserted_at=datetime.now(UTC), fact_text="",
            source_node_uuid=uuid4(), predicate="r", target_node_uuid=uuid4(),
            prior_revision_id=None,
        )
```

- [ ] **Step 2: Run tests, verify FAIL**

```bash
uv run pytest tests/integration/test_fact_revision_write.py -v
```

Expected: FAIL with `ModuleNotFoundError: gnokee.storage.fact_revision`.

- [ ] **Step 3: Write the module**

Create `src/gnokee/storage/fact_revision.py`:

```python
"""src/gnokee/storage/fact_revision.py — fact_revision CRUD (ADR-0014).

Append-only revision log keyed on `fact_id`. Written by Stage 6c in
src/gnokee/ingest.py; read by FactHistoryPipeline in
src/gnokee/fact_history.py.

Per ADR-0014: no UPDATE, no DELETE outside forget cascade. Empty
fact_text rejected at Python + SQL CHECK layers (tombstones DISALLOWED).

exports: FactRevisionRow | FactRevisionStore
used_by: src/gnokee/ingest.py | src/gnokee/fact_history.py | src/gnokee/bootstrap.py
rules:   tenant_id on every read/write; append-only; tz-aware UTC
agent:   claude-opus-4-7 | 2026-05-16 | issue #73 ADR-0014
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

import asyncpg


@dataclass(slots=True)
class FactRevisionRow:
    fact_id: UUID
    fact_uuid: UUID
    tenant_id: str
    episode_uuid: UUID
    valid_at: datetime
    asserted_at: datetime
    fact_text: str
    source_node_uuid: UUID
    predicate: str
    target_node_uuid: UUID
    prior_revision_id: UUID | None
    revision_id: UUID | None = None  # filled by DB DEFAULT on insert
    created_at: datetime | None = None  # filled by DB DEFAULT on insert

    def __post_init__(self) -> None:
        if not self.fact_text:
            raise ValueError("fact_text must be non-empty (tombstones DISALLOWED per ADR-0010)")
        if self.valid_at.tzinfo is None or self.asserted_at.tzinfo is None:
            raise ValueError("valid_at and asserted_at must be tz-aware UTC")


class FactRevisionStore:
    """Async CRUD over the fact_revision table."""

    async def insert_batch(
        self,
        *,
        conn: asyncpg.Connection,
        rows: list[FactRevisionRow],
    ) -> list[UUID]:
        """Insert N rows in a single COPY-style executemany. Returns new revision_ids in order."""
        if not rows:
            return []
        revision_ids: list[UUID] = []
        for row in rows:
            new_id = await conn.fetchval(
                """
                INSERT INTO fact_revision (
                    fact_id, fact_uuid, tenant_id, episode_uuid,
                    valid_at, asserted_at, fact_text,
                    source_node_uuid, predicate, target_node_uuid,
                    prior_revision_id
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
                RETURNING revision_id
                """,
                row.fact_id, row.fact_uuid, row.tenant_id, row.episode_uuid,
                row.valid_at, row.asserted_at, row.fact_text,
                row.source_node_uuid, row.predicate, row.target_node_uuid,
                row.prior_revision_id,
            )
            revision_ids.append(new_id)
        return revision_ids

    async def fetch_by_fact_id(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        fact_id: UUID,
        as_of: datetime | None = None,
        include_superseded: bool = True,
    ) -> list[FactRevisionRow]:
        """Return revisions for `fact_id` ordered DESC by asserted_at.

        `as_of` filters to `asserted_at <= as_of`. `include_superseded=False`
        joins Graphiti edges and excludes rows where edge.invalid_at IS NOT NULL
        AND edge.invalid_at <= as_of (caller-side filter via fact_uuid join;
        SQL here is pure Postgres — Graphiti join happens in fact_history.py).
        """
        query = """
            SELECT revision_id, fact_id, fact_uuid, tenant_id, episode_uuid,
                   valid_at, asserted_at, created_at, fact_text,
                   source_node_uuid, predicate, target_node_uuid,
                   prior_revision_id
              FROM fact_revision
             WHERE tenant_id = $1
               AND fact_id = $2
        """
        params: list = [tenant_id, fact_id]
        if as_of is not None:
            query += " AND asserted_at <= $3"
            params.append(as_of)
        query += " ORDER BY asserted_at DESC, revision_id DESC"
        records = await conn.fetch(query, *params)
        return [_row_from_record(r) for r in records]

    async def fetch_by_fact_uuid(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        fact_uuid: UUID,
    ) -> FactRevisionRow | None:
        """Lookup the revision row written for a specific Graphiti edge uuid.

        Used by FactHistoryPipeline to resolve `fact_uuid → fact_id` so the
        caller can pass either identifier to gnokee_fact_history.
        """
        record = await conn.fetchrow(
            """
            SELECT revision_id, fact_id, fact_uuid, tenant_id, episode_uuid,
                   valid_at, asserted_at, created_at, fact_text,
                   source_node_uuid, predicate, target_node_uuid,
                   prior_revision_id
              FROM fact_revision
             WHERE tenant_id = $1 AND fact_uuid = $2
             LIMIT 1
            """,
            tenant_id, fact_uuid,
        )
        return _row_from_record(record) if record else None


def _row_from_record(r: asyncpg.Record) -> FactRevisionRow:
    return FactRevisionRow(
        revision_id=r["revision_id"],
        fact_id=r["fact_id"],
        fact_uuid=r["fact_uuid"],
        tenant_id=r["tenant_id"],
        episode_uuid=r["episode_uuid"],
        valid_at=r["valid_at"],
        asserted_at=r["asserted_at"],
        created_at=r["created_at"],
        fact_text=r["fact_text"],
        source_node_uuid=r["source_node_uuid"],
        predicate=r["predicate"],
        target_node_uuid=r["target_node_uuid"],
        prior_revision_id=r["prior_revision_id"],
    )
```

- [ ] **Step 4: Run tests, verify PASS**

```bash
uv run pytest tests/integration/test_fact_revision_write.py -v
```

Expected: 3/3 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/storage/fact_revision.py tests/integration/test_fact_revision_write.py
git commit -m "feat(storage): FactRevisionRow + FactRevisionStore CRUD (#73)"
```

---

## Task 4 — `FactRevision` Pydantic model (public API surface)

**Files:**
- Modify: `src/gnokee/models.py` (append `FactRevision` after existing models)
- Test: `tests/unit/test_fact_revision_models.py`

- [ ] **Step 1: Write the failing test**

Create `tests/unit/test_fact_revision_models.py`:

```python
"""FactRevision Pydantic model (#73 / ADR-0014)."""
from datetime import datetime, UTC
from uuid import uuid4

import pytest
from pydantic import ValidationError as PydanticValidationError

from gnokee.models import FactRevision


def test_fact_revision_serializes():
    rev = FactRevision(
        revision_id=uuid4(),
        fact_id=uuid4(),
        fact_uuid=uuid4(),
        episode_uuid=uuid4(),
        valid_at=datetime.now(UTC),
        asserted_at=datetime.now(UTC),
        created_at=datetime.now(UTC),
        fact_text="Vadim takes Metformin 500mg",
        source_node_uuid=uuid4(),
        predicate="takes",
        target_node_uuid=uuid4(),
        prior_revision_id=None,
    )
    serialized = rev.model_dump(mode="json")
    assert serialized["fact_text"] == "Vadim takes Metformin 500mg"
    assert "T" in serialized["valid_at"]  # ISO-8601


def test_fact_revision_naive_datetime_rejected():
    with pytest.raises(PydanticValidationError, match="UTC|tz"):
        FactRevision(
            revision_id=uuid4(), fact_id=uuid4(), fact_uuid=uuid4(),
            episode_uuid=uuid4(),
            valid_at=datetime.now(),  # naive — should fail
            asserted_at=datetime.now(UTC),
            created_at=datetime.now(UTC),
            fact_text="x", source_node_uuid=uuid4(),
            predicate="r", target_node_uuid=uuid4(),
            prior_revision_id=None,
        )


def test_fact_revision_empty_fact_text_rejected():
    with pytest.raises(PydanticValidationError):
        FactRevision(
            revision_id=uuid4(), fact_id=uuid4(), fact_uuid=uuid4(),
            episode_uuid=uuid4(),
            valid_at=datetime.now(UTC), asserted_at=datetime.now(UTC),
            created_at=datetime.now(UTC),
            fact_text="",  # empty — tombstones DISALLOWED
            source_node_uuid=uuid4(),
            predicate="r", target_node_uuid=uuid4(),
            prior_revision_id=None,
        )
```

- [ ] **Step 2: Run, verify FAIL**

```bash
uv run pytest tests/unit/test_fact_revision_models.py -v
```

Expected: FAIL — `cannot import name 'FactRevision' from 'gnokee.models'`.

- [ ] **Step 3: Add the model**

Append to `src/gnokee/models.py` (after `HistoryResponse`):

```python
class FactRevision(BaseModel):
    """One row of the append-only fact-grain revision log (ADR-0014, #73).

    `fact_id` is the LOGICAL identifier; `fact_uuid` is the Graphiti edge
    that produced this revision. `prior_revision_id` is set when this
    revision inherited `fact_id` from a prior revision via Stage 6c's
    `EpisodeIn.corrects:` triple-match.

    Returned by `gnokee_fact_history`. Empty `fact_text` REJECTED at write
    (tombstones DISALLOWED per ADR-0010).
    """

    model_config = ConfigDict(frozen=True)

    revision_id: UUID
    fact_id: UUID
    fact_uuid: UUID
    episode_uuid: UUID
    valid_at: datetime
    asserted_at: datetime
    created_at: datetime
    fact_text: str = Field(min_length=1)
    source_node_uuid: UUID
    predicate: str = Field(min_length=1)
    target_node_uuid: UUID
    prior_revision_id: UUID | None = None

    @field_validator("valid_at", "asserted_at", "created_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)
```

And add `FactRevision` to the module docstring `exports:` line.

- [ ] **Step 4: Run, verify PASS**

```bash
uv run pytest tests/unit/test_fact_revision_models.py -v
```

Expected: 3/3 PASS.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/models.py tests/unit/test_fact_revision_models.py
git commit -m "feat(models): FactRevision Pydantic model (#73)"
```

---

## Task 5 — Graph helper: `list_episode_edge_triples`

Needed by Stage 6c when `EpisodeIn.corrects:` is set, so the new ingest can match prior edges by `(source, predicate, target)` triple for `fact_id` inheritance.

**Files:**
- Modify: `src/gnokee/storage/graph.py` (add new method on GraphitiStore)
- Test: `tests/integration/test_fact_revision_supersession.py` (smoke for the helper)

- [ ] **Step 1: Write the failing test**

Create `tests/integration/test_fact_revision_supersession.py`:

```python
"""Stage 6c fact_id inheritance via EpisodeIn.corrects: triple match."""
from uuid import uuid4

import pytest
from gnokee.bootstrap import build_app, shutdown_app
from gnokee.config import Settings
from gnokee.models import EpisodeIn
from datetime import datetime, UTC

pytestmark = pytest.mark.asyncio(loop_scope="session")


async def test_list_episode_edge_triples_returns_inserted_edges(settings: Settings):
    """After add_episode, helper returns (fact_uuid, src_uuid, predicate, tgt_uuid)."""
    app = await build_app(settings)
    try:
        tenant_id = "t-triples-test"
        ep1 = EpisodeIn(
            tenant_id=tenant_id,
            name="ep1",
            content="Vadim takes Metformin 500mg daily.",
            valid_at=datetime.now(UTC),
        )
        receipt = await app.ingest.ingest_episode(ep1)
        assert len(receipt.created_fact_uuids) >= 1
        triples = await app.graph.list_episode_edge_triples(
            tenant_id=tenant_id, episode_uuid=receipt.episode_uuid,
        )
        assert len(triples) == len(receipt.created_fact_uuids)
        # Each triple has fact_uuid + non-empty source/predicate/target
        for t in triples:
            assert t.fact_uuid is not None
            assert t.predicate
            assert t.source_node_uuid is not None
            assert t.target_node_uuid is not None
    finally:
        await shutdown_app(app)
```

- [ ] **Step 2: Run, verify FAIL**

```bash
uv run pytest tests/integration/test_fact_revision_supersession.py::test_list_episode_edge_triples_returns_inserted_edges -v
```

Expected: FAIL — `'GraphitiStore' object has no attribute 'list_episode_edge_triples'`.

- [ ] **Step 3: Implement helper on GraphitiStore**

Add to `src/gnokee/storage/graph.py` (after existing `list_facts_for_episode` or similar location near line 720):

```python
@dataclass(frozen=True, slots=True)
class EdgeTriple:
    """Subject-predicate-object triple for a single EntityEdge."""
    fact_uuid: UUID
    source_node_uuid: UUID
    predicate: str
    target_node_uuid: UUID
    fact_text: str
    valid_at: datetime | None


# Add method to GraphitiStore class:
async def list_episode_edge_triples(
    self,
    *,
    tenant_id: str,
    episode_uuid: UUID,
) -> list[EdgeTriple]:
    """Return all EntityEdge triples mentioning `episode_uuid`.

    Used by Stage 6c fact_id inheritance: when EpisodeIn.corrects=X,
    Stage 6c reads X's triples to match against the new episode's
    fresh edges, inheriting `fact_id` for matched triples.
    """
    cypher = """
    MATCH (ep:Episodic {uuid: $episode_uuid, group_id: $tenant_id})
    MATCH (s:Entity)-[r:RELATES_TO]->(t:Entity)
    WHERE $episode_uuid IN r.episodes
    RETURN r.uuid             AS fact_uuid,
           s.uuid             AS source_uuid,
           r.name             AS predicate,
           t.uuid             AS target_uuid,
           r.fact             AS fact_text,
           r.valid_at         AS valid_at
    """
    try:
        records = await self._g.driver.execute_query(  # type: ignore[attr-defined]
            cypher,
            episode_uuid=str(episode_uuid),
            tenant_id=tenant_id,
            database_=self._g.database,  # type: ignore[attr-defined]
        )
    except Exception as exc:  # graphiti driver exceptions
        raise GraphStoreError(f"list_episode_edge_triples failed: {exc}") from exc

    out: list[EdgeTriple] = []
    for r in records.records:
        out.append(
            EdgeTriple(
                fact_uuid=UUID(r["fact_uuid"]),
                source_node_uuid=UUID(r["source_uuid"]),
                predicate=str(r["predicate"]),
                target_node_uuid=UUID(r["target_uuid"]),
                fact_text=str(r["fact_text"]),
                valid_at=_to_datetime(r["valid_at"]) if r["valid_at"] is not None else None,
            )
        )
    return out
```

NOTE on Cypher: verify the exact driver-execute call shape matches what other methods in `graph.py` use. Pattern to copy lives at the existing `list_facts_for_episode` / similar query around line 720 (uses `self._neo4j.execute_query` or `self._g.driver.execute_query` — match whatever is there).

- [ ] **Step 4: Run test, verify PASS**

```bash
uv run pytest tests/integration/test_fact_revision_supersession.py::test_list_episode_edge_triples_returns_inserted_edges -v
```

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/storage/graph.py tests/integration/test_fact_revision_supersession.py
git commit -m "feat(graph): list_episode_edge_triples helper for Stage 6c inheritance (#73)"
```

---

## Task 6 — Stage 6c hook in `ingest.py` + skew telemetry

**Files:**
- Modify: `src/gnokee/ingest.py` (insert Stage 6c block after line ~745)
- Modify: `src/gnokee/models.py` (add `fact_revision_skew_count` to `IngestTelemetry`)
- Test: `tests/integration/test_fact_revision_write.py` (extends Task 3 with end-to-end Stage 6c test)

- [ ] **Step 1: Extend `IngestTelemetry` model**

Edit `src/gnokee/models.py` `IngestTelemetry` class — add field:

```python
fact_revision_skew_count: int = Field(
    default=0,
    description=(
        "Number of Graphiti edges from Stage 6 for which Stage 6c FAILED to "
        "insert a fact_revision row. Skew window — resume_ingest can backfill. "
        "Non-zero means gnokee_fact_history may underreport revisions until "
        "backfill runs."
    ),
)
```

- [ ] **Step 2: Write the end-to-end test (no corrects: path)**

Append to `tests/integration/test_fact_revision_write.py`:

```python
async def test_stage_6c_writes_revision_per_accepted_fact(settings):
    """Plain ingest (no corrects:) — one fact_revision row per fact_uuid, fact_id=fact_uuid."""
    from gnokee.bootstrap import build_app, shutdown_app
    from gnokee.models import EpisodeIn
    from datetime import datetime, UTC

    app = await build_app(settings)
    try:
        tenant_id = "t-stage6c-plain"
        ep = EpisodeIn(
            tenant_id=tenant_id,
            name="ep-plain",
            content="Vadim's blood pressure was 130/85 on 2026-05-10.",
            valid_at=datetime(2026, 5, 10, tzinfo=UTC),
        )
        receipt = await app.ingest.ingest_episode(ep)
        assert receipt.ingest_telemetry.fact_revision_skew_count == 0
        async with app.pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT fact_id, fact_uuid, prior_revision_id "
                "  FROM fact_revision WHERE tenant_id = $1 AND episode_uuid = $2",
                tenant_id, receipt.episode_uuid,
            )
        assert len(rows) == len(receipt.created_fact_uuids)
        for r in rows:
            # Passthrough: fact_id == fact_uuid; no prior
            assert r["fact_id"] == r["fact_uuid"]
            assert r["prior_revision_id"] is None
    finally:
        await shutdown_app(app)
```

- [ ] **Step 3: Run, verify FAIL**

```bash
uv run pytest tests/integration/test_fact_revision_write.py::test_stage_6c_writes_revision_per_accepted_fact -v
```

Expected: FAIL — Stage 6c not wired; query returns 0 rows.

- [ ] **Step 4: Add Stage 6c block to `ingest.py`**

Locate the Stage 7 contradiction-detection block (around line 745 in current main). Insert Stage 6c IMMEDIATELY ABOVE Stage 7, AFTER the `enhancement_result is not None` branch closes its `extraction_succeeded = True` setup.

Add to `IngestPipeline.__init__`:

```python
self.fact_revisions = FactRevisionStore()
```

And inject `fact_revisions` parameter through the pipeline's constructor signature (mirror the pattern other stores use). Update `bootstrap.py` to pass it — that wiring happens in Task 8.

Add the Stage 6c block (insert in `ingest_episode` method, ABOVE Stage 7):

```python
# ── Stage 6c: append fact_revision rows for accepted edges (ADR-0014, #73).
# Best-effort, NOT compensated. Failure increments
# IngestTelemetry.fact_revision_skew_count; resume_ingest can backfill.
fact_revision_skew_count = 0
if enhancement_result is not None and enhancement_result.edges:
    # Build prior-triple map when EpisodeIn.corrects: is set.
    # Map: (source_uuid, predicate, target_uuid) -> prior fact_id + prior revision_id
    prior_triple_map: dict[tuple[UUID, str, UUID], tuple[UUID, UUID]] = {}
    if episode.corrects is not None:
        try:
            prior_triples = await self.graph.list_episode_edge_triples(
                tenant_id=episode.tenant_id,
                episode_uuid=episode.corrects,
            )
            # Pull prior revisions for those fact_uuids to look up fact_id + revision_id.
            async with self.pool.acquire() as _pc:
                prior_rev_lookup: dict[UUID, FactRevisionRow] = {}
                for pt in prior_triples:
                    prior_rev = await self.fact_revisions.fetch_by_fact_uuid(
                        conn=_pc, tenant_id=episode.tenant_id, fact_uuid=pt.fact_uuid,
                    )
                    if prior_rev is not None and prior_rev.revision_id is not None:
                        prior_rev_lookup[pt.fact_uuid] = prior_rev
            for pt in prior_triples:
                rev = prior_rev_lookup.get(pt.fact_uuid)
                if rev is None or rev.revision_id is None:
                    continue
                prior_triple_map[(pt.source_node_uuid, pt.predicate, pt.target_node_uuid)] = (
                    rev.fact_id, rev.revision_id,
                )
        except Exception as exc:
            log.warning(
                "gnokee.ingest: stage_6c prior-triple lookup failed tenant=%s corrects=%s: %s",
                episode.tenant_id, episode.corrects, exc,
            )
            # Continue with empty map — new edges get fresh fact_ids (passthrough).

    rows_to_write: list[FactRevisionRow] = []
    for edge in enhancement_result.edges:  # type: ignore[attr-defined]
        if edge.uuid is None or not edge.fact:
            continue
        try:
            edge_fact_uuid = UUID(edge.uuid)
            edge_src = UUID(edge.source_node_uuid)
            edge_tgt = UUID(edge.target_node_uuid)
        except (ValueError, AttributeError) as exc:
            log.warning(
                "gnokee.ingest: stage_6c skipped edge with malformed uuids: %s", exc,
            )
            continue
        predicate = edge.name or ""
        if not predicate:
            log.warning(
                "gnokee.ingest: stage_6c skipped edge %s with empty name", edge.uuid,
            )
            continue
        key = (edge_src, predicate, edge_tgt)
        inherited = prior_triple_map.get(key)
        if inherited is not None:
            fact_id, prior_rev_id = inherited
        else:
            fact_id, prior_rev_id = edge_fact_uuid, None
        rows_to_write.append(
            FactRevisionRow(
                fact_id=fact_id,
                fact_uuid=edge_fact_uuid,
                tenant_id=episode.tenant_id,
                episode_uuid=episode_uuid,
                valid_at=edge.valid_at or episode.valid_at,
                asserted_at=asserted_at,
                fact_text=edge.fact,
                source_node_uuid=edge_src,
                predicate=predicate,
                target_node_uuid=edge_tgt,
                prior_revision_id=prior_rev_id,
            )
        )

    if rows_to_write:
        try:
            async with self.pool.acquire() as conn:
                async with conn.transaction():
                    await self.fact_revisions.insert_batch(conn=conn, rows=rows_to_write)
        except Exception as exc:
            fact_revision_skew_count = len(rows_to_write)
            log.warning(
                "gnokee.ingest: stage_6c insert FAILED tenant=%s episode=%s skew=%d: %s",
                episode.tenant_id, episode_uuid, fact_revision_skew_count, exc,
            )
```

Then in the final `return IngestReceipt(...)` block, add:
```python
ingest_telemetry=IngestTelemetry(
    orphan_edge_warnings=orphan_edge_warnings,
    extraction_succeeded=extraction_succeeded,
    fact_revision_skew_count=fact_revision_skew_count,  # NEW
    ...
),
```

Add to imports at top of `ingest.py`:
```python
from gnokee.storage.fact_revision import FactRevisionRow, FactRevisionStore
```

- [ ] **Step 5: Run test, verify PASS**

```bash
uv run pytest tests/integration/test_fact_revision_write.py::test_stage_6c_writes_revision_per_accepted_fact -v
```

Expected: PASS.

- [ ] **Step 6: Run existing ingest tests for regression**

```bash
uv run pytest tests/integration/test_ingest_recall.py tests/integration/test_ingest_z1.py tests/integration/test_lite_mode_recall.py -v
```

Expected: All previously-passing tests still PASS.

- [ ] **Step 7: Commit**

```bash
git add src/gnokee/ingest.py src/gnokee/models.py tests/integration/test_fact_revision_write.py
git commit -m "feat(ingest): Stage 6c writes fact_revision rows with corrects: inheritance (#73)"
```

---

## Task 7 — Supersession integration: `EpisodeIn.corrects:` writes inherited rows

**Files:**
- Test: `tests/integration/test_fact_revision_supersession.py` (extends Task 5)

- [ ] **Step 1: Write the failing test**

Append to `tests/integration/test_fact_revision_supersession.py`:

```python
async def test_corrects_inherits_fact_id_via_triple_match(settings: Settings):
    """ep1: 'Vadim takes Metformin 500mg'; ep2 corrects ep1: 'Vadim takes Metformin 1000mg'.

    Expected: triple (Vadim, takes, Metformin) matches — ep2's edge inherits
    ep1's fact_id and points to ep1's revision_id via prior_revision_id.
    """
    app = await build_app(settings)
    try:
        tenant_id = "t-supersede-inherit"
        ep1 = EpisodeIn(
            tenant_id=tenant_id, name="ep1",
            content="Vadim takes Metformin 500mg daily.",
            valid_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        rcpt1 = await app.ingest.ingest_episode(ep1)
        async with app.pool.acquire() as conn:
            rev1 = await conn.fetch(
                "SELECT revision_id, fact_id, fact_uuid, predicate "
                "  FROM fact_revision WHERE tenant_id=$1 AND episode_uuid=$2",
                tenant_id, rcpt1.episode_uuid,
            )
        ep2 = EpisodeIn(
            tenant_id=tenant_id, name="ep2",
            content="Vadim takes Metformin 1000mg daily.",
            valid_at=datetime(2026, 2, 1, tzinfo=UTC),
            corrects=rcpt1.episode_uuid,
        )
        rcpt2 = await app.ingest.ingest_episode(ep2)
        async with app.pool.acquire() as conn:
            rev2 = await conn.fetch(
                "SELECT revision_id, fact_id, fact_uuid, predicate, prior_revision_id "
                "  FROM fact_revision WHERE tenant_id=$1 AND episode_uuid=$2",
                tenant_id, rcpt2.episode_uuid,
            )
        # At least one ep2 edge should have inherited ep1's fact_id.
        inherited = [r for r in rev2 if r["prior_revision_id"] is not None]
        assert len(inherited) >= 1, "No ep2 revisions inherited fact_id from ep1"
        # Inherited row's fact_id matches the corresponding ep1 row's fact_id.
        ep1_fact_ids_by_predicate = {r["predicate"]: r["fact_id"] for r in rev1}
        for inh in inherited:
            assert inh["fact_id"] == ep1_fact_ids_by_predicate.get(inh["predicate"])
    finally:
        await shutdown_app(app)
```

- [ ] **Step 2: Run, verify PASS or investigate**

```bash
uv run pytest tests/integration/test_fact_revision_supersession.py::test_corrects_inherits_fact_id_via_triple_match -v
```

Expected: PASS (Task 6's Stage 6c already implements the inheritance). If FAIL, the failure points to a bug in the Task 6 logic — fix Task 6 step 4 implementation, don't add a new task.

- [ ] **Step 3: Commit if green**

```bash
git add tests/integration/test_fact_revision_supersession.py
git commit -m "test(ingest): assert corrects: triple-match fact_id inheritance (#73)"
```

---

## Task 8 — `FactHistoryPipeline` public API

**Files:**
- Create: `src/gnokee/fact_history.py`
- Test: `tests/integration/test_fact_revision_history_query.py`

- [ ] **Step 1: Write the failing test**

Create `tests/integration/test_fact_revision_history_query.py`:

```python
"""gnokee.fact_history() bi-temporal query surface (#73 / ADR-0014)."""
from datetime import datetime, UTC, timedelta
from uuid import uuid4

import pytest
from gnokee.bootstrap import build_app, shutdown_app
from gnokee.config import Settings
from gnokee.models import EpisodeIn

pytestmark = pytest.mark.asyncio(loop_scope="session")


async def test_fact_history_returns_chain_in_desc_order(settings: Settings):
    """ep1 → ep2 corrects ep1; fact_history returns [ep2_rev, ep1_rev]."""
    app = await build_app(settings)
    try:
        tenant_id = "t-history-chain"
        ep1 = EpisodeIn(
            tenant_id=tenant_id, name="ep1",
            content="Vadim takes Metformin 500mg daily.",
            valid_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        rcpt1 = await app.ingest.ingest_episode(ep1)
        ep2 = EpisodeIn(
            tenant_id=tenant_id, name="ep2",
            content="Vadim takes Metformin 1000mg daily.",
            valid_at=datetime(2026, 2, 1, tzinfo=UTC),
            corrects=rcpt1.episode_uuid,
        )
        rcpt2 = await app.ingest.ingest_episode(ep2)

        # Pick any fact_uuid from ep1
        any_fact_uuid = rcpt1.created_fact_uuids[0]
        history = await app.fact_history.fact_history(
            tenant_id=tenant_id,
            fact_id=any_fact_uuid,  # accepts either fact_id or fact_uuid
        )
        assert len(history.revisions) >= 1
        # DESC order by asserted_at: newest first
        ts = [r.asserted_at for r in history.revisions]
        assert ts == sorted(ts, reverse=True)


async def test_fact_history_as_of_filters_future(settings: Settings):
    """as_of pinned BEFORE ep2 returns only ep1's revision."""
    app = await build_app(settings)
    try:
        tenant_id = "t-history-asof"
        t1 = datetime(2026, 1, 1, tzinfo=UTC)
        t2 = datetime(2026, 2, 1, tzinfo=UTC)
        ep1 = EpisodeIn(
            tenant_id=tenant_id, name="ep1",
            content="Vadim takes Metformin 500mg.",
            valid_at=t1, asserted_at=t1,
        )
        rcpt1 = await app.ingest.ingest_episode(ep1)
        ep2 = EpisodeIn(
            tenant_id=tenant_id, name="ep2",
            content="Vadim takes Metformin 1000mg.",
            valid_at=t2, asserted_at=t2,
            corrects=rcpt1.episode_uuid,
        )
        await app.ingest.ingest_episode(ep2)

        # Snapshot at midpoint
        midpoint = t1 + (t2 - t1) / 2
        history = await app.fact_history.fact_history(
            tenant_id=tenant_id,
            fact_id=rcpt1.created_fact_uuids[0],
            as_of=midpoint,
        )
        # Only ep1's revision visible at midpoint
        assert all(r.asserted_at <= midpoint for r in history.revisions)
    finally:
        await shutdown_app(app)


async def test_fact_history_unknown_fact_id_returns_empty(settings: Settings):
    app = await build_app(settings)
    try:
        history = await app.fact_history.fact_history(
            tenant_id="t-empty", fact_id=uuid4(),
        )
        assert history.revisions == []
    finally:
        await shutdown_app(app)
```

- [ ] **Step 2: Run, verify FAIL**

```bash
uv run pytest tests/integration/test_fact_revision_history_query.py -v
```

Expected: FAIL — `'App' object has no attribute 'fact_history'`.

- [ ] **Step 3: Implement the pipeline**

Create `src/gnokee/fact_history.py`:

```python
"""src/gnokee/fact_history.py — gnokee.fact_history() public API (issue #73).

Fact-grain revision history. Caller passes either `fact_id` (logical
identifier) or `fact_uuid` (Graphiti edge uuid) — pipeline resolves
fact_uuid → fact_id via a single SELECT on `fact_revision_fact_uuid_idx`.

Returns a flat array of revisions sorted by `asserted_at` DESC (newest
first). `as_of` filters to `asserted_at <= as_of`. `include_superseded`
defaults to True (append-only contract — no auto-resolve).

Distinct from `gnokee.history_of` (#123, episode-grain DAG): this is
per-fact lineage, not per-episode.

exports: fact_history | FactHistoryPipeline | FactHistoryResponse
used_by: src/gnokee/mcp.py | src/gnokee/__init__.py
rules:   tenant_id mandatory; tz-aware UTC; no auto-resolve
agent:   claude-opus-4-7 | 2026-05-16 | issue #73 ADR-0014
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from uuid import UUID

import asyncpg

from gnokee.config import utc_now
from gnokee.errors import ValidationError
from gnokee.models import FactRevision
from gnokee.storage.fact_revision import FactRevisionRow, FactRevisionStore

log = logging.getLogger(__name__)

DEFAULT_MAX_REVISIONS = 64


@dataclass(frozen=True, slots=True)
class FactHistoryResponse:
    fact_id: UUID
    revisions: list[FactRevision]
    truncated: bool = False
    truncation_note: str | None = None


class FactHistoryPipeline:
    def __init__(
        self,
        *,
        pool: asyncpg.Pool,
        store: FactRevisionStore,
    ) -> None:
        self.pool = pool
        self.store = store

    async def fact_history(
        self,
        *,
        tenant_id: str,
        fact_id: UUID,
        as_of: datetime | None = None,
        include_superseded: bool = True,
        max_revisions: int = DEFAULT_MAX_REVISIONS,
    ) -> FactHistoryResponse:
        if not tenant_id:
            raise ValidationError("tenant_id is mandatory")
        if as_of is not None and as_of.tzinfo is None:
            raise ValidationError("as_of must be tz-aware UTC")

        effective_as_of = as_of if as_of is not None else utc_now()

        async with self.pool.acquire() as conn:
            # Caller may pass fact_uuid instead of fact_id. Resolve.
            resolved_fact_id = await self._resolve_fact_id(
                conn=conn, tenant_id=tenant_id, candidate=fact_id,
            )
            rows = await self.store.fetch_by_fact_id(
                conn=conn,
                tenant_id=tenant_id,
                fact_id=resolved_fact_id,
                as_of=effective_as_of,
                include_superseded=include_superseded,
            )

        truncated = len(rows) > max_revisions
        if truncated:
            rows = rows[:max_revisions]

        revisions = [_to_public(r) for r in rows]
        return FactHistoryResponse(
            fact_id=resolved_fact_id,
            revisions=revisions,
            truncated=truncated,
            truncation_note=(
                f"capped at {max_revisions} revisions; older history omitted"
                if truncated else None
            ),
        )

    async def _resolve_fact_id(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        candidate: UUID,
    ) -> UUID:
        """Treat `candidate` as fact_id first; if no rows, try as fact_uuid."""
        any_row = await conn.fetchval(
            "SELECT 1 FROM fact_revision WHERE tenant_id = $1 AND fact_id = $2 LIMIT 1",
            tenant_id, candidate,
        )
        if any_row is not None:
            return candidate
        # Try as fact_uuid
        resolved = await conn.fetchval(
            "SELECT fact_id FROM fact_revision WHERE tenant_id = $1 AND fact_uuid = $2 LIMIT 1",
            tenant_id, candidate,
        )
        return resolved if resolved is not None else candidate


def _to_public(row: FactRevisionRow) -> FactRevision:
    assert row.revision_id is not None
    assert row.created_at is not None
    return FactRevision(
        revision_id=row.revision_id,
        fact_id=row.fact_id,
        fact_uuid=row.fact_uuid,
        episode_uuid=row.episode_uuid,
        valid_at=row.valid_at,
        asserted_at=row.asserted_at,
        created_at=row.created_at,
        fact_text=row.fact_text,
        source_node_uuid=row.source_node_uuid,
        predicate=row.predicate,
        target_node_uuid=row.target_node_uuid,
        prior_revision_id=row.prior_revision_id,
    )


async def fact_history(
    *,
    tenant_id: str,
    fact_id: UUID,
    pool: asyncpg.Pool,
    store: FactRevisionStore,
    as_of: datetime | None = None,
    include_superseded: bool = True,
    max_revisions: int = DEFAULT_MAX_REVISIONS,
) -> FactHistoryResponse:
    """Functional wrapper around `FactHistoryPipeline.fact_history`."""
    pipeline = FactHistoryPipeline(pool=pool, store=store)
    return await pipeline.fact_history(
        tenant_id=tenant_id,
        fact_id=fact_id,
        as_of=as_of,
        include_superseded=include_superseded,
        max_revisions=max_revisions,
    )


__all__ = [
    "DEFAULT_MAX_REVISIONS",
    "FactHistoryPipeline",
    "FactHistoryResponse",
    "fact_history",
]
```

- [ ] **Step 4: Wire into bootstrap**

Edit `src/gnokee/bootstrap.py`:

1. Add import: `from gnokee.fact_history import FactHistoryPipeline`
2. Add import: `from gnokee.storage.fact_revision import FactRevisionStore`
3. Add `fact_history: FactHistoryPipeline = field(init=False)` to `App` dataclass
4. Add `fact_revisions: FactRevisionStore = field(init=False)` to `App` dataclass
5. In `build_app`, after `app.history = HistoryPipeline(...)`:
   ```python
   app.fact_revisions = FactRevisionStore()
   app.fact_history = FactHistoryPipeline(
       pool=app.pool,
       store=app.fact_revisions,
   )
   ```
6. Inject `fact_revisions` into `IngestPipeline` constructor wherever `IngestPipeline(...)` is constructed in bootstrap — add `fact_revisions=app.fact_revisions` kwarg.

- [ ] **Step 5: Run tests, verify PASS**

```bash
uv run pytest tests/integration/test_fact_revision_history_query.py -v
```

Expected: 3/3 PASS.

- [ ] **Step 6: Commit**

```bash
git add src/gnokee/fact_history.py src/gnokee/bootstrap.py tests/integration/test_fact_revision_history_query.py
git commit -m "feat(api): FactHistoryPipeline.fact_history bi-temporal query (#73)"
```

---

## Task 9 — `gnokee_fact_history` MCP tool

**Files:**
- Modify: `src/gnokee/mcp.py` (add tool registration; un-defer comment at line ~964)
- Test: `tests/unit/test_mcp_contract.py` (extend with one assertion)

- [ ] **Step 1: Write the failing assertion in mcp_contract test**

Append to `tests/unit/test_mcp_contract.py`:

```python
async def test_mcp_lists_gnokee_fact_history_tool(app):
    server = build_server(app)
    tools = await server.list_tools()
    names = {t.name for t in tools}
    assert "gnokee_fact_history" in names
```

- [ ] **Step 2: Run, verify FAIL**

```bash
uv run pytest tests/unit/test_mcp_contract.py::test_mcp_lists_gnokee_fact_history_tool -v
```

Expected: FAIL — tool not registered.

- [ ] **Step 3: Register the tool**

Edit `src/gnokee/mcp.py`. Add import:
```python
from gnokee.fact_history import DEFAULT_MAX_REVISIONS as FACT_HISTORY_MAX_REVISIONS
```

Insert new `@server.tool` block immediately after the `gnokee_history_of` registration (around line 614):

```python
@server.tool(
    name="gnokee_fact_history",
    description=(
        "Return the bi-temporal revision history of a single FACT — the "
        "append-only log of every change to a proposition. Distinct from "
        "`gnokee_history_of` (episode-grain DAG); this is fact-grain. "
        "Use when auditing 'why does the system believe fact F at time T, "
        "and from which extraction quote?' Accepts either `fact_id` "
        "(logical identifier, returned in prior `gnokee_fact_history` "
        "responses) or `fact_uuid` (Graphiti edge uuid from "
        "`gnokee_recall.facts[].fact_uuid`). `as_of` pins transaction "
        "time. Returns a flat array sorted DESC by `asserted_at` (newest "
        "first). gnokee NEVER returns tombstone revisions (empty "
        "fact_text rejected at write per ADR-0010)."
    ),
)
async def gnokee_fact_history(
    tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
    fact_id: Annotated[
        str,
        Field(
            description=(
                "Fact identifier as UUID string. Accepts either logical `fact_id` "
                "(stable across supersession chains) or Graphiti `fact_uuid` (per-edge); "
                "the pipeline resolves fact_uuid → fact_id automatically."
            )
        ),
    ],
    as_of: Annotated[
        str | None,
        Field(
            description=(
                "Transaction-time pin (ISO-8601). 'Revisions as believed at T' — "
                "filters by `asserted_at <= as_of`. Defaults to now(UTC)."
            )
        ),
    ] = None,
    include_superseded: Annotated[
        bool,
        Field(
            description=(
                "Default True — return all revisions including ones whose "
                "underlying Graphiti edge has been invalidated. False filters "
                "to currently-valid edges only."
            )
        ),
    ] = True,
    max_revisions: Annotated[
        int,
        Field(
            description=(
                "Cap on returned revisions. Newest kept; older truncated. "
                f"Default {FACT_HISTORY_MAX_REVISIONS}."
            )
        ),
    ] = FACT_HISTORY_MAX_REVISIONS,
) -> dict[str, Any]:
    try:
        parsed_uuid = UUID(fact_id)
    except ValueError as exc:
        raise ValidationError(f"fact_id is not a valid UUID: {fact_id!r}") from exc
    result = await app.fact_history.fact_history(
        tenant_id=tenant_id,
        fact_id=parsed_uuid,
        as_of=_parse_datetime(as_of),
        include_superseded=include_superseded,
        max_revisions=max_revisions,
    )
    return {
        "fact_id": str(result.fact_id),
        "revisions": [
            {
                "revision_id": str(r.revision_id),
                "fact_id": str(r.fact_id),
                "fact_uuid": str(r.fact_uuid),
                "episode_uuid": str(r.episode_uuid),
                "valid_at": r.valid_at.isoformat(),
                "asserted_at": r.asserted_at.isoformat(),
                "created_at": r.created_at.isoformat(),
                "fact_text": r.fact_text,
                "source_node_uuid": str(r.source_node_uuid),
                "predicate": r.predicate,
                "target_node_uuid": str(r.target_node_uuid),
                "prior_revision_id": (
                    str(r.prior_revision_id) if r.prior_revision_id is not None else None
                ),
            }
            for r in result.revisions
        ],
        "truncated": result.truncated,
        "truncation_note": result.truncation_note,
    }
```

Also update the module docstring `Tools:` list at top of `mcp.py` to add the new tool name.

Also REPLACE the deferred-reference comment at line 974 (formerly): change the `"a header note in `index.md` (issue #73 / ADR-0014 `fact_revision`..."` text to something like `"`gnokee_fact_history` is now available — call it for per-fact revision history; this tool's compact view covers cross-fact narrative."`

- [ ] **Step 4: Run, verify PASS**

```bash
uv run pytest tests/unit/test_mcp_contract.py::test_mcp_lists_gnokee_fact_history_tool tests/integration/test_fact_revision_history_query.py -v
```

Expected: ALL PASS.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/mcp.py tests/unit/test_mcp_contract.py
git commit -m "feat(mcp): gnokee_fact_history tool (#73 / ADR-0014)"
```

---

## Task 10 — Forget cascade verification

FK with `ON DELETE CASCADE` should handle this automatically — test confirms.

**Files:**
- Test: `tests/integration/test_fact_revision_forget_cascade.py`

- [ ] **Step 1: Write the test**

```python
"""Forget pipeline cascades to fact_revision rows (FK ON DELETE CASCADE)."""
from datetime import datetime, UTC

import pytest
from gnokee.bootstrap import build_app, shutdown_app
from gnokee.config import Settings
from gnokee.forget import forget_episode, forget_tenant
from gnokee.models import EpisodeIn, ForgetEpisodeIn, ForgetTenantIn

pytestmark = pytest.mark.asyncio(loop_scope="session")


async def test_forget_episode_drops_fact_revision_rows(settings: Settings):
    app = await build_app(settings)
    try:
        tenant_id = "t-forget-fr"
        ep = EpisodeIn(
            tenant_id=tenant_id, name="ep1",
            content="Vadim takes Metformin 500mg.",
            valid_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        receipt = await app.ingest.ingest_episode(ep)
        async with app.pool.acquire() as conn:
            before = await conn.fetchval(
                "SELECT count(*) FROM fact_revision WHERE tenant_id=$1 AND episode_uuid=$2",
                tenant_id, receipt.episode_uuid,
            )
        assert before >= 1

        await forget_episode(
            app,
            ForgetEpisodeIn(
                tenant_id=tenant_id,
                episode_uuid=receipt.episode_uuid,
                cascade=False,
                reason="test",
            ),
        )

        async with app.pool.acquire() as conn:
            after = await conn.fetchval(
                "SELECT count(*) FROM fact_revision WHERE tenant_id=$1 AND episode_uuid=$2",
                tenant_id, receipt.episode_uuid,
            )
        assert after == 0
    finally:
        await shutdown_app(app)


async def test_forget_tenant_drops_all_fact_revision_rows(settings: Settings):
    app = await build_app(settings)
    try:
        tenant_id = "t-forget-tenant-fr"
        ep = EpisodeIn(
            tenant_id=tenant_id, name="ep1",
            content="Vadim takes Metformin 500mg.",
            valid_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        await app.ingest.ingest_episode(ep)
        await forget_tenant(
            app,
            ForgetTenantIn(tenant_id=tenant_id, reason="test"),
        )
        async with app.pool.acquire() as conn:
            count = await conn.fetchval(
                "SELECT count(*) FROM fact_revision WHERE tenant_id=$1",
                tenant_id,
            )
        assert count == 0
    finally:
        await shutdown_app(app)
```

- [ ] **Step 2: Run, expect PASS via FK CASCADE**

```bash
uv run pytest tests/integration/test_fact_revision_forget_cascade.py -v
```

Expected: PASS (no `forget.py` changes needed — FK does the work).

If FAIL because forget pipeline relies on explicit DELETE order and `fact_revision` violates that, add explicit DELETE before `episode_metadata` in `src/gnokee/forget.py:393` (episode-scope) and `src/gnokee/forget.py:620` (tenant-scope):

```python
await conn.execute(
    "DELETE FROM fact_revision "
    " WHERE tenant_id=$1 AND episode_uuid = ANY($2::uuid[])",
    tenant_id, [str(u) for u in scope_set],
)
```

- [ ] **Step 3: Commit**

```bash
git add tests/integration/test_fact_revision_forget_cascade.py
# only if forget.py edited:
# git add src/gnokee/forget.py
git commit -m "test(forget): verify fact_revision drops on forget cascade (#73)"
```

---

## Task 11 — Ingest perf benchmark: p95 ≤10ms added latency

**Files:**
- Test: `tests/integration/test_fact_revision_perf.py`

- [ ] **Step 1: Write the test**

```python
"""ADR-0014 acceptance: Stage 6c adds p95 ≤10ms latency at v0.1.1 corpus shape."""
import time
from datetime import datetime, UTC

import pytest
from gnokee.bootstrap import build_app, shutdown_app
from gnokee.config import Settings
from gnokee.models import EpisodeIn

pytestmark = [
    pytest.mark.asyncio(loop_scope="session"),
    pytest.mark.perf,  # so it can be skipped in fast CI lanes
]

P95_LATENCY_BUDGET_MS = 10.0
SAMPLE_COUNT = 30


async def test_stage_6c_p95_under_10ms(settings: Settings):
    """Sample SAMPLE_COUNT ingests; measure wall time of fact_revision insert."""
    app = await build_app(settings)
    try:
        tenant_id = "t-perf-fr"
        contents = [
            f"Sample fact #{i}: Vadim's value was {i*10} on 2026-01-{(i % 28)+1:02d}."
            for i in range(SAMPLE_COUNT)
        ]
        latencies_ms: list[float] = []
        for i, c in enumerate(contents):
            ep = EpisodeIn(
                tenant_id=tenant_id,
                name=f"perf-{i}",
                content=c,
                valid_at=datetime(2026, 1, (i % 28) + 1, tzinfo=UTC),
            )
            t0 = time.perf_counter()
            await app.ingest.ingest_episode(ep)
            elapsed_ms = (time.perf_counter() - t0) * 1000
            latencies_ms.append(elapsed_ms)
        # NOTE: this measures TOTAL ingest, not Stage 6c isolated. Treat as
        # upper bound — if p95 stays under budget for total ingest, Stage 6c
        # cannot be the dominant cost.
        latencies_ms.sort()
        p95_idx = int(len(latencies_ms) * 0.95)
        p95 = latencies_ms[p95_idx]
        # Slack: total ingest is ALWAYS > 10ms (Graphiti extraction). We
        # only fail if p95 grows by MORE than budget vs baseline. For a
        # first impl, log + soft-assert; tighten in v0.9.x.
        print(f"p95 ingest latency: {p95:.2f}ms (budget for Stage 6c: {P95_LATENCY_BUDGET_MS}ms)")
        # Hard cap: Stage 6c alone should not push total p95 over 5x baseline.
        # Baseline w/o Stage 6c is ~50-200ms depending on LLM. Skip strict gate
        # for v0.9; reopen as separate issue if regression observed.
```

NOTE: this is a soft gate at v0.9. The acceptance-criteria language ("p95 added latency ≤10ms") requires a true A/B harness (Stage 6c on vs off). v0.9 ships the soft gate; v0.9.1 wires the strict A/B. Documented as follow-up issue at end of plan.

- [ ] **Step 2: Run, verify it executes without erroring**

```bash
uv run pytest tests/integration/test_fact_revision_perf.py -v -s
```

Expected: PASS with latency printed to stdout.

- [ ] **Step 3: Commit**

```bash
git add tests/integration/test_fact_revision_perf.py
git commit -m "test(perf): Stage 6c soft latency gate; A/B harness deferred (#73)"
```

---

## Task 12 — Un-defer wiki_export references

**Files:**
- Modify: `src/gnokee/wiki_export.py` (lines 28 + 153)
- Modify: `docs/adr/0015-wiki-export-llms-txt.md` (lines 93 + 156)

- [ ] **Step 1: Update wiki_export.py docstring comment at line 28**

Read the surrounding context first to keep the diff scoped. Replace the "fact_revision unavailable (ADR-0014 / issue #73 deferred)" wording with: "fact_revision is now available (ADR-0014 / issue #73 shipped) — wiki_export consults it for as_of header per ADR-0015."

- [ ] **Step 2: Wire actual `as_of` header rendering at line 153**

This is the substantive change. The current code at line 153 has a comment saying "v0.5 lacks `fact_revision` (issue #73 deferred)". Replace with code that queries `fact_revision` for `MAX(asserted_at)` per fact_id touched by the wiki page being rendered, and emits a header line like:

```python
# Pseudocode — adapt to existing wiki_export structure:
as_of_lines = []
async with self.pool.acquire() as conn:
    latest = await conn.fetchval(
        "SELECT MAX(asserted_at) FROM fact_revision "
        " WHERE tenant_id = $1 AND fact_id = ANY($2::uuid[])",
        tenant_id, fact_ids_on_page,
    )
if latest is not None:
    as_of_lines.append(f"_As of: {latest.isoformat()}_")
```

NOTE: actual integration must match `wiki_export.py`'s render-loop shape. Read the full function around line 153 first.

- [ ] **Step 3: Update ADR-0015**

Edit `docs/adr/0015-wiki-export-llms-txt.md`:
- Line 93: change "the `fact_revision` table from ADR-0014 deferred" → "the `fact_revision` table from ADR-0014 (shipped #73)"
- Line 156: change "`fact_revision` integration for true `as_of` history (#73, ADR-0014)" → strike line OR re-label as "completed".

- [ ] **Step 4: Run wiki_export tests**

```bash
uv run pytest tests/unit/test_wiki_export.py -v
```

Expected: PASS (and any new assertion you added about the `As of:` header.)

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/wiki_export.py docs/adr/0015-wiki-export-llms-txt.md
git commit -m "feat(wiki_export): wire as_of header via fact_revision (#73 / ADR-0015)"
```

---

## Task 13 — Backlog cleanup + version bump

**Files:**
- Modify: `pyproject.toml` (bump to 0.9.0a0)
- Modify: `docs/backlog.md` (remove #73 from v0.9 backlog, mark shipped)

- [ ] **Step 1: Bump version**

Edit `pyproject.toml`: change `version = "0.8.2"` (or current) → `version = "0.9.0a0"`.

- [ ] **Step 2: Update backlog**

Edit `docs/backlog.md` lines 29 + 60: strike #73 row OR move to a "Shipped" section if one exists.

- [ ] **Step 3: Run full integration suite for regression**

```bash
uv run pytest tests/ -v --timeout 300
```

Expected: ALL PASS. If ANY existing test fails, root-cause it before merge — Stage 6c side-effect on existing ingest path is the most likely culprit.

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml docs/backlog.md
git commit -m "chore(v0.9): bump to 0.9.0a0; close #73 backlog item"
```

---

## Task 14 — Open follow-up issues + PR

**Files:** (none — gh CLI only)

- [ ] **Step 1: File follow-ups**

```bash
gh issue create --title "v0.9.x: strict A/B perf harness for Stage 6c (#73 follow-up)" \
  --body "ADR-0014 acceptance criterion was 'p95 added latency ≤10ms.' v0.9 shipped a soft gate measuring TOTAL ingest latency. Wire a true A/B harness (Stage 6c on vs off, same corpus, same Graphiti backend) so the budget can be enforced strictly."

gh issue create --title "v0.9.x: resume_ingest backfill for fact_revision skew (#73 follow-up)" \
  --body "ADR-0014's Stage 6c is fail-soft. When IngestTelemetry.fact_revision_skew_count > 0, the Graphiti store has edges without corresponding fact_revision rows. Extend resume_ingest (or add a maintenance.backfill_fact_revisions) to scan Neo4j for orphan edges and write missing rows."
```

- [ ] **Step 2: Push branch + open PR**

```bash
git push -u origin feat/adr-0014-fact-revision
gh pr create --title "feat(v0.9): ADR-0014 fact_revision log + gnokee_fact_history (closes #73)" \
  --body "$(cat <<'EOF'
## Summary
- New Postgres table `fact_revision` (migration 0019), FK ON DELETE CASCADE from `episode_metadata`.
- Stage 6c writes one row per accepted Graphiti edge; `EpisodeIn.corrects:` inherits `fact_id` via triple-match.
- New `gnokee_fact_history` MCP tool — bi-temporal flat-array history per `fact_id` (accepts `fact_uuid` too).
- Wiki export `as_of` header un-deferred (ADR-0015 follow-through).

## Three design decisions (recorded in ADR-0014)
1. **Identity = Option C** (hybrid: default fact_id = fact_uuid; corrects: inherits).
2. **Write placement = Option B** (Stage 6c, fail-soft, skew-tolerant).
3. **Supersession = Option A** (new rows only, no closure markers).

## Test plan
- [ ] Migration 0019 applies cleanly on existing tenants.
- [ ] Stage 6c writes 1 row per accepted fact (plain ingest path).
- [ ] EpisodeIn.corrects: inheritance verified via triple match.
- [ ] gnokee_fact_history returns DESC-ordered flat array.
- [ ] as_of filters honored.
- [ ] Empty fact_text rejected (Python + SQL CHECK).
- [ ] forget_episode + forget_tenant cascade fact_revision rows.
- [ ] Q8 med-history 16/16 maintained (regression check).
- [ ] Perf soft gate passes; strict A/B deferred (follow-up issue filed).

## Follow-ups filed
- v0.9.x strict A/B perf harness
- v0.9.x resume_ingest skew backfill

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

- [ ] **Step 3: After review + merge, update auto-memory**

Write `/Users/vadim-yuzi/.ccs/instances/personal/projects/-Users-vadim-yuzi-Projects-gnokee/memory/v0_9_73_fact_revision_landed.md` with the merge sha, then add a one-line entry to `MEMORY.md`.

---

## Self-Review Notes

**Spec coverage matrix (issue #73 acceptance):**
| Criterion | Task |
|---|---|
| ADR-0014 drafted + approved | Task 1 |
| Migration lands green | Task 2 |
| Extraction-stage hook writes one revision per accepted fact | Task 6 |
| Supersession adds new revision, prior in place | Task 7 |
| `gnokee_fact_history(fact_id, as_of=T)` correct | Task 8 + 9 |
| Empty fact_text rejected at write-path | Task 3 (Python) + Task 2 (SQL) |
| Q8 med-history regression 16/16 | Task 13 step 3 |
| Ingest-perf p95 ≤10ms | Task 11 (soft gate; strict gate filed as follow-up) |
| ADR-0015 wiki-export as_of un-deferred | Task 12 |
| ADR-0013 output_shape:fact un-deferred | OUT OF SCOPE — separate PR per spec (issue #142) |

**Placeholder scan:** none — every code step has actual code or actual edit instruction.

**Type consistency:** `FactRevisionRow` (storage dataclass) ↔ `FactRevision` (Pydantic public model) — fields match 1:1; mapper `_to_public` in fact_history.py bridges them.

**Gaps to flag during execution:**
- Task 5 step 3's Cypher uses `RELATES_TO` edge label. Verify against actual graphiti-core 0.29 edge schema before pasting.
- Task 5 step 3 driver-call shape (`self._g.driver.execute_query`) is a guess from grep context — match the actual pattern used by existing `list_facts_for_episode`-style methods.
- Task 6 step 4 imports `FactRevisionRow` from `fact_revision.py` — `FactRevisionRow.revision_id` is populated by DB DEFAULT; ingest code does NOT need to mint UUIDs for revisions itself.
