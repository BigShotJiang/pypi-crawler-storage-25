# v0.2.1 supersession-aware ingest — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add `EpisodeIn.corrects: UUID | None`. When set, a correction episode supersedes prior `lab_record` + `med_record` rows whose key matches the new rows AND closes the corrected `episode_metadata` row. All UPDATEs run atomically inside the existing Stage 6 txn, before the new-row inserts.

**Architecture:** Pydantic boundary field → Stage 6 supersession primitive (3 new storage methods, all parameterised on `tenant_id` + `episode_uuid`) → Python-side chain-walk with `SELECT … FOR UPDATE` in `metadata.supersede`. New typed errors subclass `VectorStoreError` so the existing Stage 6 compensate path catches them and rolls back the Graphiti episode created at Stage 4.

**Tech Stack:** Python 3.10+, Pydantic v2, asyncpg, pytest-asyncio (session loop scope per AGENTS.md), ruff format, mypy strict on `src/gnokee/`. Conventional Commits. Two-PR shape: `feat(ingest): …` then `chore(release): v0.2.1`.

**Source spec:** `docs/superpowers/specs/2026-05-09-v0_2_1-supersession-aware-ingest-design.md` (commit c409751).

---

## File structure

**Create:**
- `tests/integration/test_supersession_e2e.py` — 11 e2e cases against real Postgres + Neo4j + TEI

**Modify (PR 1 — feat):**
- `src/gnokee/errors.py` — 4 new error classes
- `src/gnokee/models.py` — `EpisodeIn.corrects` field
- `src/gnokee/storage/metadata.py` — `supersede` method + Python-loop chain-walk
- `src/gnokee/storage/lab.py` — `supersede_matching` method
- `src/gnokee/storage/med.py` — `supersede_matching` method
- `src/gnokee/ingest.py` — Stage 6 wiring + `ingest_episode` helper signature
- `tests/unit/test_models.py` — boundary-shape unit tests for `corrects`
- `evals/spike_q7_lab_results/run.py` — `ingest_corpus` plumbing + fresh tenant
- `evals/spike_q7_lab_results/corpus.jsonl` — `corrects:` on April-correction episode
- `evals/spike_q8_med_supersession/run.py` — same plumbing + fresh tenant
- `evals/spike_q8_med_supersession/corpus.jsonl` — synthetic correction episode
- `evals/spike_q8_med_supersession/queries.yaml` — `q_lisinopril_dose_corrected`
- `docs/adr/0009-clinical-labs-need-structured-store.md` — v0.2.1 status note
- `docs/adr/0010-meds-share-lab-record-shape.md` — v0.2.1 status note

**Modify (PR 2 — release):**
- `CHANGELOG.md` — `[0.2.1]` entry
- `pyproject.toml` — version 0.2.0 → 0.2.1

---

## Task 1: Add `Corrects*` exception classes

**Files:**
- Modify: `src/gnokee/errors.py`
- Test: `tests/unit/test_errors.py` (create if missing, otherwise extend)

**Why first:** Every downstream task depends on these types existing.

- [ ] **Step 1: Write the failing test**

Append to `tests/unit/test_errors.py` (create file if absent):

```python
"""Unit tests for gnokee.errors typed-exception hierarchy."""
from __future__ import annotations

from uuid import UUID

import pytest

from gnokee.errors import (
    CorrectsAxisInversionError,
    CorrectsChainError,
    CorrectsCrossTenantError,
    CorrectsError,
    EpisodeNotFoundError,
    VectorStoreError,
)


def test_corrects_error_subclasses_vector_store_error() -> None:
    assert issubclass(CorrectsError, VectorStoreError)


def test_episode_not_found_carries_uuid_attribute() -> None:
    u = UUID("00000000-0000-0000-0000-000000000001")
    exc = EpisodeNotFoundError(u)
    assert exc.episode_uuid == u
    assert str(u) in str(exc)


def test_each_subclass_inherits_corrects_error() -> None:
    for cls in (
        EpisodeNotFoundError,
        CorrectsCrossTenantError,
        CorrectsAxisInversionError,
        CorrectsChainError,
    ):
        assert issubclass(cls, CorrectsError), cls
        assert issubclass(cls, VectorStoreError), cls


def test_axis_and_chain_are_distinct_classes() -> None:
    """Cycle/depth must not be conflated with tx-time inversion."""
    assert CorrectsChainError is not CorrectsAxisInversionError
    assert not issubclass(CorrectsChainError, CorrectsAxisInversionError)
    assert not issubclass(CorrectsAxisInversionError, CorrectsChainError)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_errors.py -v`
Expected: FAIL with `ImportError: cannot import name 'CorrectsError' from 'gnokee.errors'`

- [ ] **Step 3: Add the error classes**

Append to `src/gnokee/errors.py`:

```python
from uuid import UUID  # at top of file alongside `from __future__ import annotations`


class CorrectsError(VectorStoreError):
    """Base for `corrects:` validation failures (Stage 6 txn-scope).

    Subclasses derive from `VectorStoreError` so the existing
    `IngestPipeline.ingest` compensate path catches them and rolls
    back the Graphiti episode created at Stage 4.
    """


class EpisodeNotFoundError(CorrectsError):
    """Raised when `corrects` targets an episode_uuid not in episode_metadata."""

    def __init__(self, episode_uuid: UUID) -> None:
        super().__init__(f"corrects: episode {episode_uuid} not found")
        self.episode_uuid = episode_uuid


class CorrectsCrossTenantError(CorrectsError):
    """Raised when `corrects` targets a different tenant_id."""


class CorrectsAxisInversionError(CorrectsError):
    """Raised when new asserted_at <= corrected.asserted_at.

    Bi-temporal axis integrity: a correction is always learned-later
    in tx-time than the row it corrects.
    """


class CorrectsChainError(CorrectsError):
    """Raised when `superseded_by` walk exceeds bounded depth.

    Distinct from `CorrectsAxisInversionError` — cycle / runaway
    chain is a structural invariant, not a tx-time inversion. Callers
    and log parsers must be able to tell them apart.
    """
```

Update the `exports:` line in the docstring to add the four new classes.

- [ ] **Step 4: Run tests to verify pass**

Run: `pytest tests/unit/test_errors.py -v`
Expected: PASS (4 tests).

Run: `ruff check src/gnokee/errors.py tests/unit/test_errors.py && ruff format --check src/gnokee/errors.py tests/unit/test_errors.py`
Expected: clean.

Run: `mypy src/gnokee/errors.py`
Expected: clean.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/errors.py tests/unit/test_errors.py
git commit -m "feat(errors): typed Corrects* hierarchy (v0.2.1 prep)"
```

---

## Task 2: Add `EpisodeIn.corrects` boundary field

**Files:**
- Modify: `src/gnokee/models.py` (the `EpisodeIn` class, around line 59)
- Test: `tests/unit/test_models.py` (create or extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/unit/test_models.py`:

```python
"""tests/unit/test_models.py — EpisodeIn.corrects boundary field."""
from __future__ import annotations

from datetime import datetime, timezone
from uuid import UUID

import pytest
from pydantic import ValidationError as PydanticValidationError

from gnokee.models import EpisodeIn


def _utc(year: int = 2024, month: int = 1, day: int = 1) -> datetime:
    return datetime(year, month, day, tzinfo=timezone.utc)


def test_corrects_default_is_none() -> None:
    ep = EpisodeIn(tenant_id="t", content="hi", valid_at=_utc())
    assert ep.corrects is None


def test_corrects_accepts_uuid() -> None:
    u = UUID("11111111-1111-1111-1111-111111111111")
    ep = EpisodeIn(tenant_id="t", content="hi", valid_at=_utc(), corrects=u)
    assert ep.corrects == u


def test_corrects_rejects_non_uuid_string() -> None:
    with pytest.raises(PydanticValidationError):
        EpisodeIn(tenant_id="t", content="hi", valid_at=_utc(), corrects="not-a-uuid")


def test_corrects_extra_forbid_unaffected() -> None:
    """Existing extra='forbid' still rejects unknown fields."""
    with pytest.raises(PydanticValidationError):
        EpisodeIn(  # type: ignore[call-arg]
            tenant_id="t",
            content="hi",
            valid_at=_utc(),
            unknown_field="x",
        )
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_models.py::test_corrects_default_is_none -v`
Expected: FAIL with Pydantic raising `Extra inputs are not permitted` on `corrects=` (because the field doesn't exist yet).

- [ ] **Step 3: Add the field**

Edit `src/gnokee/models.py`, inside the `EpisodeIn` class (after the `language` field, before the validators):

```python
    corrects: UUID | None = Field(
        default=None,
        description=(
            "When set, declares this episode supersedes a prior one. "
            "Same-tenant only; corrected episode must exist in "
            "episode_metadata; new asserted_at must be > "
            "corrected.asserted_at. Closes matching lab_record + "
            "med_record rows from the corrected episode and sets "
            "episode_metadata.asserted_until + superseded_by. "
            "Caller-asserted only — no heuristic detection. Graphiti "
            "edges are NOT auto-superseded; narrative corrections flow "
            "through ADR-0008 contradiction surfacing."
        ),
    )
```

The `EpisodeIn` import block already has `from uuid import UUID`. No new imports needed.

- [ ] **Step 4: Run tests to verify pass**

Run: `pytest tests/unit/test_models.py -v`
Expected: PASS (4 tests).

Run: `mypy src/gnokee/models.py`
Expected: clean.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/models.py tests/unit/test_models.py
git commit -m "feat(models): EpisodeIn.corrects: UUID | None (v0.2.1 boundary field)"
```

---

## Task 3: `LabStore.supersede_matching`

**Files:**
- Modify: `src/gnokee/storage/lab.py`
- Test: `tests/unit/test_lab_supersede.py` (new) — uses `asyncpg` real connection via the `pg_pool` fixture; this is a unit-of-storage test, not the full e2e flow.

> Note: gnokee storage adapters are tested against the live Postgres pool (Q4-validated convention; pg-stub mocks proved misleading). A bare connection is sufficient — Graphiti not required.

- [ ] **Step 1: Write the failing test**

Create `tests/unit/test_lab_supersede.py`:

```python
"""Unit tests for LabStore.supersede_matching.

Real Postgres via the session-scoped `pg_pool` fixture from
tests/integration/conftest.py; this file lives in tests/unit/ but
talks to the same compose-managed Postgres because asyncpg + a
schema migration are the unit under test.
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from uuid import uuid4

import asyncpg
import pytest
import pytest_asyncio

from gnokee.storage.lab import LabRecordRow, LabStore
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore
from gnokee.storage.migrate import apply as apply_migrations

pytestmark = pytest.mark.asyncio


@pytest_asyncio.fixture(scope="module")
async def pool() -> asyncpg.Pool:
    dsn = os.environ.get(
        "GNOKEE_PG_DSN",
        "postgresql://gnokee:gnokee@localhost:5432/gnokee",
    )
    await apply_migrations(dsn)
    pool = await asyncpg.create_pool(dsn, min_size=1, max_size=2)
    assert pool is not None
    try:
        yield pool
    finally:
        await pool.close()


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


@pytest_asyncio.fixture
async def fresh_tenant() -> str:
    return f"unit-lab-supersede-{uuid4().hex[:12]}"


async def _seed_episode(
    *,
    pool: asyncpg.Pool,
    tenant_id: str,
    asserted_at: datetime,
) -> EpisodeMetadataRow:
    """Insert a minimal episode_metadata row so lab_record's FK can resolve."""
    row = EpisodeMetadataRow(
        tenant_id=tenant_id,
        episode_uuid=uuid4(),
        valid_at=_utc(2024, 4, 10),
        valid_until=None,
        asserted_at=asserted_at,
        asserted_until=None,
        superseded_by=None,
        sensitive="clinical",
        language="en",
        our_id=None,
    )
    metadata = MetadataStore(pool)
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)",
            tenant_id,
        )
        await metadata.write(conn=conn, row=row)
    return row


async def test_supersede_matching_closes_named_keys(
    pool: asyncpg.Pool, fresh_tenant: str
) -> None:
    """Per-row match: K closes, Mg untouched."""
    tenant = fresh_tenant
    asserted_a = _utc(2024, 4, 12)
    asserted_b = _utc(2024, 4, 25)
    ep_a = await _seed_episode(pool=pool, tenant_id=tenant, asserted_at=asserted_a)

    lab = LabStore(pool)
    rows = [
        LabRecordRow(
            tenant_id=tenant,
            episode_uuid=ep_a.episode_uuid,
            analyte="Potassium",
            value_numeric=Decimal("2.8"),
            value_text=None,
            unit="mmol/L",
            ref_range_low=Decimal("3.5"),
            ref_range_high=Decimal("5.0"),
            abnormal_flag="L",
            valid_at=_utc(2024, 4, 10),
            asserted_at=asserted_a,
        ),
        LabRecordRow(
            tenant_id=tenant,
            episode_uuid=ep_a.episode_uuid,
            analyte="Magnesium",
            value_numeric=Decimal("1.5"),
            value_text=None,
            unit="mg/dL",
            ref_range_low=Decimal("1.7"),
            ref_range_high=Decimal("2.4"),
            abnormal_flag="L",
            valid_at=_utc(2024, 4, 10),
            asserted_at=asserted_a,
        ),
    ]
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", tenant
        )
        async with conn.transaction():
            await lab.write_rows(conn=conn, rows=rows)

    # Supersede only Potassium.
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", tenant
        )
        async with conn.transaction():
            updated = await lab.supersede_matching(
                conn=conn,
                tenant_id=tenant,
                episode_uuid=ep_a.episode_uuid,
                keys=[("Potassium", _utc(2024, 4, 10))],
                asserted_until=asserted_b,
            )
    assert updated == 1

    # Verify state.
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", tenant
        )
        records = await conn.fetch(
            "SELECT analyte, asserted_until FROM lab_record "
            "WHERE tenant_id = $1 ORDER BY analyte",
            tenant,
        )
    state = {r["analyte"]: r["asserted_until"] for r in records}
    assert state["Potassium"] == asserted_b
    assert state["Magnesium"] is None


async def test_supersede_matching_returns_zero_when_no_match(
    pool: asyncpg.Pool, fresh_tenant: str
) -> None:
    """Caller compares count vs len(keys) and warns; method itself returns 0 silently."""
    tenant = fresh_tenant
    asserted = _utc(2024, 4, 12)
    ep = await _seed_episode(pool=pool, tenant_id=tenant, asserted_at=asserted)
    lab = LabStore(pool)
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", tenant
        )
        async with conn.transaction():
            updated = await lab.supersede_matching(
                conn=conn,
                tenant_id=tenant,
                episode_uuid=ep.episode_uuid,
                keys=[("Nonexistent", _utc(2024, 4, 10))],
                asserted_until=asserted + timedelta(days=1),
            )
    assert updated == 0


async def test_supersede_matching_empty_keys_returns_zero(
    pool: asyncpg.Pool, fresh_tenant: str
) -> None:
    tenant = fresh_tenant
    asserted = _utc(2024, 4, 12)
    ep = await _seed_episode(pool=pool, tenant_id=tenant, asserted_at=asserted)
    lab = LabStore(pool)
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", tenant
        )
        async with conn.transaction():
            updated = await lab.supersede_matching(
                conn=conn,
                tenant_id=tenant,
                episode_uuid=ep.episode_uuid,
                keys=[],
                asserted_until=asserted + timedelta(days=1),
            )
    assert updated == 0
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_lab_supersede.py -v`
Expected: FAIL with `AttributeError: 'LabStore' object has no attribute 'supersede_matching'`

- [ ] **Step 3: Implement `supersede_matching`**

Append to the `LabStore` class in `src/gnokee/storage/lab.py` (after `aggregate`, before `__all__`):

```python
    async def supersede_matching(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        episode_uuid: UUID,
        keys: list[tuple[str, datetime]],
        asserted_until: datetime,
    ) -> int:
        """Close prior lab_record rows on `episode_uuid` whose
        (analyte, valid_at) appears in `keys`. Updates only rows
        currently open on the tx-time half-pair (asserted_until IS NULL)
        and currently visible on the world-time half-pair (valid_until
        IS NULL OR valid_until > asserted_until). Returns the count of
        rows updated; the caller compares against len(keys) and logs a
        WARNING on a partial-match miss (parser drift on valid_at
        rounding would otherwise be a silent zero-match).

        `episode_uuid` is the chain-walk-resolved head, NOT necessarily
        the caller's `corrects` value — see `MetadataStore.supersede`.
        """
        if not keys:
            return 0
        analytes = [k[0] for k in keys]
        valid_ats = [k[1] for k in keys]
        try:
            result = await conn.execute(
                """
                UPDATE lab_record
                   SET asserted_until = $5
                  FROM unnest($3::text[], $4::timestamptz[])
                       AS k(analyte, valid_at)
                 WHERE lab_record.tenant_id      = $1
                   AND lab_record.episode_uuid   = $2
                   AND lab_record.asserted_until IS NULL
                   AND (lab_record.valid_until IS NULL
                        OR lab_record.valid_until > $5)
                   AND lab_record.analyte        = k.analyte
                   AND lab_record.valid_at       = k.valid_at
                """,
                tenant_id,
                episode_uuid,
                analytes,
                valid_ats,
                asserted_until,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(
                f"lab_record.supersede_matching failed: {exc}"
            ) from exc
        # asyncpg returns "UPDATE N" — last token is the count.
        return int(result.split()[-1])
```

- [ ] **Step 4: Run tests to verify pass**

Run: `pytest tests/unit/test_lab_supersede.py -v`
Expected: PASS (3 tests).

Run: `mypy src/gnokee/storage/lab.py`
Expected: clean.

Run: `ruff check src/gnokee/storage/lab.py tests/unit/test_lab_supersede.py && ruff format --check src/gnokee/storage/lab.py tests/unit/test_lab_supersede.py`
Expected: clean.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/storage/lab.py tests/unit/test_lab_supersede.py
git commit -m "feat(storage): LabStore.supersede_matching (v0.2.1)"
```

---

## Task 4: `MedStore.supersede_matching`

Same shape as Task 3; three-column key.

**Files:**
- Modify: `src/gnokee/storage/med.py`
- Test: `tests/unit/test_med_supersede.py` (new)

- [ ] **Step 1: Write the failing test**

Create `tests/unit/test_med_supersede.py`:

```python
"""Unit tests for MedStore.supersede_matching."""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from uuid import uuid4

import asyncpg
import pytest
import pytest_asyncio

from gnokee.storage.med import MedRecordRow, MedStore
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore
from gnokee.storage.migrate import apply as apply_migrations

pytestmark = pytest.mark.asyncio


@pytest_asyncio.fixture(scope="module")
async def pool() -> asyncpg.Pool:
    dsn = os.environ.get(
        "GNOKEE_PG_DSN",
        "postgresql://gnokee:gnokee@localhost:5432/gnokee",
    )
    await apply_migrations(dsn)
    pool = await asyncpg.create_pool(dsn, min_size=1, max_size=2)
    assert pool is not None
    try:
        yield pool
    finally:
        await pool.close()


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


@pytest_asyncio.fixture
async def fresh_tenant() -> str:
    return f"unit-med-supersede-{uuid4().hex[:12]}"


async def _seed_episode(
    *,
    pool: asyncpg.Pool,
    tenant_id: str,
    asserted_at: datetime,
) -> EpisodeMetadataRow:
    row = EpisodeMetadataRow(
        tenant_id=tenant_id,
        episode_uuid=uuid4(),
        valid_at=_utc(2024, 6, 15),
        valid_until=None,
        asserted_at=asserted_at,
        asserted_until=None,
        superseded_by=None,
        sensitive="clinical",
        language="en",
        our_id=None,
    )
    metadata = MetadataStore(pool)
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", tenant_id
        )
        await metadata.write(conn=conn, row=row)
    return row


async def test_supersede_matching_closes_named_drug_event(
    pool: asyncpg.Pool, fresh_tenant: str
) -> None:
    tenant = fresh_tenant
    asserted_a = _utc(2024, 6, 15)
    asserted_b = _utc(2024, 6, 20)
    ep = await _seed_episode(pool=pool, tenant_id=tenant, asserted_at=asserted_a)
    med = MedStore(pool)
    rows = [
        MedRecordRow(
            tenant_id=tenant,
            episode_uuid=ep.episode_uuid,
            drug_name="Lisinopril",
            event_kind="start",
            valid_at=_utc(2024, 6, 15),
            asserted_at=asserted_a,
            dose_value=Decimal("10"),
            dose_unit="mg",
        ),
        MedRecordRow(
            tenant_id=tenant,
            episode_uuid=ep.episode_uuid,
            drug_name="Aspirin",
            event_kind="start",
            valid_at=_utc(2024, 6, 15),
            asserted_at=asserted_a,
            dose_value=Decimal("81"),
            dose_unit="mg",
        ),
    ]
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", tenant
        )
        async with conn.transaction():
            await med.write_rows(conn=conn, rows=rows)
        async with conn.transaction():
            updated = await med.supersede_matching(
                conn=conn,
                tenant_id=tenant,
                episode_uuid=ep.episode_uuid,
                keys=[("Lisinopril", "start", _utc(2024, 6, 15))],
                asserted_until=asserted_b,
            )
    assert updated == 1

    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", tenant
        )
        records = await conn.fetch(
            "SELECT drug_name, asserted_until FROM med_record "
            "WHERE tenant_id = $1 ORDER BY drug_name",
            tenant,
        )
    state = {r["drug_name"]: r["asserted_until"] for r in records}
    assert state["Lisinopril"] == asserted_b
    assert state["Aspirin"] is None


async def test_supersede_matching_empty_keys_returns_zero(
    pool: asyncpg.Pool, fresh_tenant: str
) -> None:
    tenant = fresh_tenant
    asserted = _utc(2024, 6, 15)
    ep = await _seed_episode(pool=pool, tenant_id=tenant, asserted_at=asserted)
    med = MedStore(pool)
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", tenant
        )
        async with conn.transaction():
            updated = await med.supersede_matching(
                conn=conn,
                tenant_id=tenant,
                episode_uuid=ep.episode_uuid,
                keys=[],
                asserted_until=asserted + timedelta(days=1),
            )
    assert updated == 0
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_med_supersede.py -v`
Expected: FAIL with `AttributeError: 'MedStore' object has no attribute 'supersede_matching'`

- [ ] **Step 3: Implement `supersede_matching`**

Append to the `MedStore` class in `src/gnokee/storage/med.py` (after `by_event_kind`, before `_row_to_dc`):

```python
    async def supersede_matching(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        episode_uuid: UUID,
        keys: list[tuple[str, str, datetime]],
        asserted_until: datetime,
    ) -> int:
        """Close prior med_record rows on `episode_uuid` whose
        (drug_name, event_kind, valid_at) appears in `keys`. Updates
        only rows currently open on the tx-time half-pair and currently
        visible on the world-time half-pair. Returns count updated;
        caller logs WARNING on partial-match miss.

        `episode_uuid` is the chain-walk-resolved head per
        `MetadataStore.supersede`, NOT necessarily caller's `corrects`.
        """
        if not keys:
            return 0
        drug_names = [k[0] for k in keys]
        event_kinds = [k[1] for k in keys]
        valid_ats = [k[2] for k in keys]
        try:
            result = await conn.execute(
                """
                UPDATE med_record
                   SET asserted_until = $6
                  FROM unnest($3::text[], $4::text[], $5::timestamptz[])
                       AS k(drug_name, event_kind, valid_at)
                 WHERE med_record.tenant_id      = $1
                   AND med_record.episode_uuid   = $2
                   AND med_record.asserted_until IS NULL
                   AND (med_record.valid_until IS NULL
                        OR med_record.valid_until > $6)
                   AND med_record.drug_name      = k.drug_name
                   AND med_record.event_kind     = k.event_kind
                   AND med_record.valid_at       = k.valid_at
                """,
                tenant_id,
                episode_uuid,
                drug_names,
                event_kinds,
                valid_ats,
                asserted_until,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(
                f"med_record.supersede_matching failed: {exc}"
            ) from exc
        return int(result.split()[-1])
```

- [ ] **Step 4: Run tests to verify pass**

Run: `pytest tests/unit/test_med_supersede.py -v`
Expected: PASS (2 tests).

Run: `mypy src/gnokee/storage/med.py && ruff check src/gnokee/storage/med.py tests/unit/test_med_supersede.py && ruff format --check src/gnokee/storage/med.py tests/unit/test_med_supersede.py`
Expected: clean.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/storage/med.py tests/unit/test_med_supersede.py
git commit -m "feat(storage): MedStore.supersede_matching (v0.2.1)"
```

---

## Task 5: `MetadataStore.supersede` with chain-walk + `FOR UPDATE`

**Files:**
- Modify: `src/gnokee/storage/metadata.py`
- Test: `tests/unit/test_metadata_supersede.py` (new)

This is the load-bearing primitive. Validates same-tenant + exists + axis. Walks `superseded_by` chain. `FOR UPDATE` locks each row through the txn so concurrent corrects-on-same-chain serialize.

- [ ] **Step 1: Write the failing test**

Create `tests/unit/test_metadata_supersede.py`:

```python
"""Unit tests for MetadataStore.supersede (chain-walk + validation)."""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from uuid import UUID, uuid4

import asyncpg
import pytest
import pytest_asyncio

from gnokee.errors import (
    CorrectsAxisInversionError,
    CorrectsChainError,
    CorrectsCrossTenantError,
    EpisodeNotFoundError,
)
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore
from gnokee.storage.migrate import apply as apply_migrations

pytestmark = pytest.mark.asyncio


@pytest_asyncio.fixture(scope="module")
async def pool() -> asyncpg.Pool:
    dsn = os.environ.get(
        "GNOKEE_PG_DSN",
        "postgresql://gnokee:gnokee@localhost:5432/gnokee",
    )
    await apply_migrations(dsn)
    pool = await asyncpg.create_pool(dsn, min_size=1, max_size=2)
    assert pool is not None
    try:
        yield pool
    finally:
        await pool.close()


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


@pytest_asyncio.fixture
async def fresh_tenant() -> str:
    return f"unit-metadata-supersede-{uuid4().hex[:12]}"


async def _insert(
    pool: asyncpg.Pool,
    *,
    tenant_id: str,
    asserted_at: datetime,
) -> UUID:
    row = EpisodeMetadataRow(
        tenant_id=tenant_id,
        episode_uuid=uuid4(),
        valid_at=_utc(2024, 4, 10),
        valid_until=None,
        asserted_at=asserted_at,
        asserted_until=None,
        superseded_by=None,
        sensitive="clinical",
        language="en",
        our_id=None,
    )
    md = MetadataStore(pool)
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", tenant_id
        )
        await md.write(conn=conn, row=row)
    return row.episode_uuid


async def test_episode_not_found(pool: asyncpg.Pool, fresh_tenant: str) -> None:
    md = MetadataStore(pool)
    bogus = uuid4()
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", fresh_tenant
        )
        async with conn.transaction():
            with pytest.raises(EpisodeNotFoundError):
                await md.supersede(
                    conn=conn,
                    tenant_id=fresh_tenant,
                    corrected_episode_uuid=bogus,
                    new_episode_uuid=uuid4(),
                    asserted_until=_utc(2024, 5, 1),
                )


async def test_cross_tenant_rejected(pool: asyncpg.Pool) -> None:
    tenant_a = f"unit-metadata-a-{uuid4().hex[:8]}"
    tenant_b = f"unit-metadata-b-{uuid4().hex[:8]}"
    a_uuid = await _insert(pool, tenant_id=tenant_a, asserted_at=_utc(2024, 4, 12))
    md = MetadataStore(pool)
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", tenant_b
        )
        async with conn.transaction():
            with pytest.raises(CorrectsCrossTenantError):
                await md.supersede(
                    conn=conn,
                    tenant_id=tenant_b,
                    corrected_episode_uuid=a_uuid,
                    new_episode_uuid=uuid4(),
                    asserted_until=_utc(2024, 5, 1),
                )


async def test_axis_inversion(pool: asyncpg.Pool, fresh_tenant: str) -> None:
    a = await _insert(
        pool, tenant_id=fresh_tenant, asserted_at=_utc(2024, 4, 25)
    )
    md = MetadataStore(pool)
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", fresh_tenant
        )
        async with conn.transaction():
            with pytest.raises(CorrectsAxisInversionError):
                await md.supersede(
                    conn=conn,
                    tenant_id=fresh_tenant,
                    corrected_episode_uuid=a,
                    new_episode_uuid=uuid4(),
                    asserted_until=_utc(2024, 4, 12),  # earlier than corrected
                )


async def test_happy_path_closes_metadata(
    pool: asyncpg.Pool, fresh_tenant: str
) -> None:
    a = await _insert(
        pool, tenant_id=fresh_tenant, asserted_at=_utc(2024, 4, 12)
    )
    new_uuid = uuid4()
    asserted_until = _utc(2024, 4, 25)
    md = MetadataStore(pool)
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", fresh_tenant
        )
        async with conn.transaction():
            head = await md.supersede(
                conn=conn,
                tenant_id=fresh_tenant,
                corrected_episode_uuid=a,
                new_episode_uuid=new_uuid,
                asserted_until=asserted_until,
            )
    assert head.episode_uuid == a

    refetched = await md.get(tenant_id=fresh_tenant, episode_uuid=a)
    assert refetched is not None
    assert refetched.asserted_until == asserted_until
    assert refetched.superseded_by == new_uuid


async def test_chain_walk_to_head(
    pool: asyncpg.Pool, fresh_tenant: str
) -> None:
    """If caller names A but the chain is A -> B, supersede walks to B."""
    a = await _insert(
        pool, tenant_id=fresh_tenant, asserted_at=_utc(2024, 4, 12)
    )
    b = await _insert(
        pool, tenant_id=fresh_tenant, asserted_at=_utc(2024, 4, 25)
    )
    md = MetadataStore(pool)
    # First close A with B as superseder.
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", fresh_tenant
        )
        async with conn.transaction():
            await md.supersede(
                conn=conn,
                tenant_id=fresh_tenant,
                corrected_episode_uuid=a,
                new_episode_uuid=b,
                asserted_until=_utc(2024, 4, 25),
            )

    # Now ingest C with corrects=A. Chain-walk should resolve to B.
    c_uuid = uuid4()
    c_asserted = _utc(2024, 5, 10)
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", fresh_tenant
        )
        async with conn.transaction():
            head = await md.supersede(
                conn=conn,
                tenant_id=fresh_tenant,
                corrected_episode_uuid=a,
                new_episode_uuid=c_uuid,
                asserted_until=c_asserted,
            )
    assert head.episode_uuid == b

    a_after = await md.get(tenant_id=fresh_tenant, episode_uuid=a)
    b_after = await md.get(tenant_id=fresh_tenant, episode_uuid=b)
    assert a_after is not None and b_after is not None
    # A unchanged.
    assert a_after.asserted_until == _utc(2024, 4, 25)
    assert a_after.superseded_by == b
    # B closed by C.
    assert b_after.asserted_until == c_asserted
    assert b_after.superseded_by == c_uuid


async def test_chain_depth_exceeded_raises(
    pool: asyncpg.Pool, fresh_tenant: str
) -> None:
    """Build a >32-hop chain (synthetic via direct SQL to bypass axis guard)."""
    md = MetadataStore(pool)
    # Insert 34 episodes: e0 -> e1 -> ... -> e33; close each to point at next.
    uuids: list[UUID] = []
    for i in range(34):
        u = await _insert(
            pool,
            tenant_id=fresh_tenant,
            asserted_at=_utc(2024, 1, 1) + timedelta(days=i),
        )
        uuids.append(u)
    # Wire superseded_by chain via direct SQL (bypass axis guard).
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)", fresh_tenant
        )
        for i in range(33):
            await conn.execute(
                "UPDATE episode_metadata SET asserted_until = $1, "
                "superseded_by = $2 WHERE tenant_id = $3 AND episode_uuid = $4",
                _utc(2024, 1, 1) + timedelta(days=i + 1),
                uuids[i + 1],
                fresh_tenant,
                uuids[i],
            )
        async with conn.transaction():
            with pytest.raises(CorrectsChainError):
                await md.supersede(
                    conn=conn,
                    tenant_id=fresh_tenant,
                    corrected_episode_uuid=uuids[0],
                    new_episode_uuid=uuid4(),
                    asserted_until=_utc(2025, 1, 1),
                )
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/unit/test_metadata_supersede.py -v`
Expected: FAIL with `AttributeError: 'MetadataStore' object has no attribute 'supersede'`

- [ ] **Step 3: Implement `supersede`**

Append to the `MetadataStore` class in `src/gnokee/storage/metadata.py` (after `get_by_our_id`):

```python
    _CHAIN_DEPTH_LIMIT = 32

    async def supersede(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        corrected_episode_uuid: UUID,
        new_episode_uuid: UUID,
        asserted_until: datetime,
    ) -> EpisodeMetadataRow:
        """Close `episode_metadata` for the corrected episode.

        Validates: same tenant, episode exists, asserted_at axis (new
        > corrected). If the named episode is already superseded, walks
        `superseded_by` chain to current head and supersedes the head
        instead. Each hop SELECT uses `FOR UPDATE` so concurrent
        corrects-on-the-same-chain serialize correctly under READ
        COMMITTED.

        Bounded depth: chains > 32 hops raise `CorrectsChainError`
        (defensive against cycles).

        Returns the head `EpisodeMetadataRow` (the row that was
        UPDATEd). Caller passes `head.episode_uuid` to
        `LabStore.supersede_matching` / `MedStore.supersede_matching`
        so row-level supersession lands on the same row that has open
        visible state.
        """
        from gnokee.errors import (  # local import to avoid module cycle
            CorrectsAxisInversionError,
            CorrectsChainError,
            CorrectsCrossTenantError,
            EpisodeNotFoundError,
        )

        current_uuid = corrected_episode_uuid
        try:
            for _ in range(self._CHAIN_DEPTH_LIMIT):
                row = await conn.fetchrow(
                    """
                    SELECT tenant_id, episode_uuid, valid_at, valid_until,
                           asserted_at, asserted_until, superseded_by,
                           sensitive, language, our_id
                      FROM episode_metadata
                     WHERE episode_uuid = $1
                       FOR UPDATE
                    """,
                    current_uuid,
                )
                if row is None:
                    raise EpisodeNotFoundError(current_uuid)
                if row["tenant_id"] != tenant_id:
                    raise CorrectsCrossTenantError(
                        f"corrects: episode {current_uuid} belongs to "
                        f"tenant {row['tenant_id']!r}, not {tenant_id!r}"
                    )
                if row["asserted_until"] is None:
                    head_row = row
                    break
                # Walk the chain.
                next_uuid = row["superseded_by"]
                if next_uuid is None:
                    # Closed but not pointing forward — treat as head
                    # (shouldn't happen via supersede; possible from
                    # historical data). Use this as the head.
                    head_row = row
                    break
                current_uuid = next_uuid
            else:
                raise CorrectsChainError(
                    f"corrects: superseded_by chain exceeded "
                    f"{self._CHAIN_DEPTH_LIMIT} hops starting at "
                    f"{corrected_episode_uuid}"
                )

            if asserted_until <= head_row["asserted_at"]:
                raise CorrectsAxisInversionError(
                    f"corrects: new asserted_at={asserted_until.isoformat()} "
                    f"<= corrected.asserted_at="
                    f"{head_row['asserted_at'].isoformat()} "
                    f"(head episode={head_row['episode_uuid']})"
                )
            await conn.execute(
                """
                UPDATE episode_metadata
                   SET asserted_until = $3,
                       superseded_by  = $4
                 WHERE tenant_id    = $1
                   AND episode_uuid = $2
                   AND asserted_until IS NULL
                """,
                tenant_id,
                head_row["episode_uuid"],
                asserted_until,
                new_episode_uuid,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.supersede failed: {exc}") from exc
        return _row_to_dc(head_row)
```

The local import at the top of the method body is intentional: `gnokee.errors` would otherwise pull `gnokee.models` via the `Sensitivity` re-export and cycle. The `from gnokee.errors import …` inside the method keeps the file's top-level imports exactly as they are today.

- [ ] **Step 4: Run tests to verify pass**

Run: `pytest tests/unit/test_metadata_supersede.py -v`
Expected: PASS (6 tests).

Run: `mypy src/gnokee/storage/metadata.py`
Expected: clean.

Run: `ruff check src/gnokee/storage/metadata.py tests/unit/test_metadata_supersede.py && ruff format --check src/gnokee/storage/metadata.py tests/unit/test_metadata_supersede.py`
Expected: clean.

- [ ] **Step 5: Commit**

```bash
git add src/gnokee/storage/metadata.py tests/unit/test_metadata_supersede.py
git commit -m "feat(storage): MetadataStore.supersede + FOR UPDATE chain-walk (v0.2.1)"
```

---

## Task 6: Stage 6 wiring in `IngestPipeline.ingest`

Wires the three new storage primitives. Must run before existing inserts. Also threads `corrects` through the module-level `ingest_episode(...)` helper.

**Files:**
- Modify: `src/gnokee/ingest.py` (Stage 6 transaction body, around line 192–223; module-level `ingest_episode` around line 369–402)

This task is integration-tested in Task 7 against real Postgres + Neo4j + TEI. It does not get a separate unit test because the wiring exists only in the txn body that the e2e suite covers end-to-end.

- [ ] **Step 1: Add the supersession block to Stage 6**

Edit `src/gnokee/ingest.py`. Inside `IngestPipeline.ingest`, find the Stage 6 txn body (the lines starting with `inserted = await self.metadata.write(...)`). Insert the supersession block **after** the `if not inserted: raise _OurIdRaceLost()` guard and **before** `await self.vector.write_embedding(...)`.

The completed Stage 6 txn body becomes:

```python
            async with self.pool.acquire() as conn:
                async with conn.transaction():
                    inserted = await self.metadata.write(conn=conn, row=row)
                    if not inserted:
                        # Race lost: another caller already inserted for our our_id.
                        # Roll back this txn, recover the winner outside.
                        raise _OurIdRaceLost()

                    # v0.2.1: supersede prior episode + matching rows when
                    # `corrects` is set. Runs inside the same txn as the
                    # new-row inserts so a downstream insert failure rolls
                    # the supersession back atomically. metadata.supersede
                    # validates same-tenant + exists + axis and walks the
                    # superseded_by chain to the current head; row-level
                    # supersession then targets the head's UUID, NOT the
                    # caller-supplied corrects (which may be stale).
                    if episode.corrects is not None:
                        head = await self.metadata.supersede(
                            conn=conn,
                            tenant_id=episode.tenant_id,
                            corrected_episode_uuid=episode.corrects,
                            new_episode_uuid=episode_uuid,
                            asserted_until=asserted_at,
                        )
                    else:
                        head = None

                    await self.vector.write_embedding(
                        conn=conn,
                        tenant_id=episode.tenant_id,
                        episode_uuid=episode_uuid,
                        embedding=vector,
                    )
                    lab_rows = _build_lab_rows(
                        parse_labs(content),
                        tenant_id=episode.tenant_id,
                        episode_uuid=episode_uuid,
                        valid_at=episode.valid_at,
                        asserted_at=asserted_at,
                    )
                    if head is not None and lab_rows:
                        updated = await self.lab.supersede_matching(
                            conn=conn,
                            tenant_id=episode.tenant_id,
                            episode_uuid=head.episode_uuid,
                            keys=[(r.analyte, r.valid_at) for r in lab_rows],
                            asserted_until=asserted_at,
                        )
                        if updated < len(lab_rows):
                            log.warning(
                                "lab.supersede_matching: matched %d of %d keys "
                                "(parser drift on valid_at?) tenant=%s "
                                "head=%s new=%s",
                                updated,
                                len(lab_rows),
                                episode.tenant_id,
                                head.episode_uuid,
                                episode_uuid,
                            )
                    if lab_rows:
                        await self.lab.write_rows(conn=conn, rows=lab_rows)
                    med_rows = _build_med_rows(
                        parse_meds(content),
                        tenant_id=episode.tenant_id,
                        episode_uuid=episode_uuid,
                        valid_at=episode.valid_at,
                        asserted_at=asserted_at,
                    )
                    if head is not None and med_rows:
                        updated = await self.med.supersede_matching(
                            conn=conn,
                            tenant_id=episode.tenant_id,
                            episode_uuid=head.episode_uuid,
                            keys=[
                                (r.drug_name, r.event_kind, r.valid_at)
                                for r in med_rows
                            ],
                            asserted_until=asserted_at,
                        )
                        if updated < len(med_rows):
                            log.warning(
                                "med.supersede_matching: matched %d of %d keys "
                                "(parser drift on valid_at?) tenant=%s "
                                "head=%s new=%s",
                                updated,
                                len(med_rows),
                                episode.tenant_id,
                                head.episode_uuid,
                                episode_uuid,
                            )
                    if med_rows:
                        await self.med.write_rows(conn=conn, rows=med_rows)
```

Note: the supersession-row-level UPDATEs run **before** the new-row inserts for each table — important because if `head.episode_uuid == episode_uuid` (which cannot happen given the axis guard, but defensively) the WHERE on the new rows wouldn't accidentally close the rows we just inserted (their `asserted_until` is `NULL` after insert, but `asserted_at` would equal `asserted_until` and the axis-equality guard rejects). The order is: episode-metadata supersede → row-level supersede → row-level insert.

- [ ] **Step 2: Update the module-level `ingest_episode` signature**

Edit the `ingest_episode` function (around line 369). Add `corrects: UUID | None = None` between `our_id` and `entity_type_hints`, and pass it through to the `EpisodeIn(...)` constructor:

```python
async def ingest_episode(
    *,
    pipeline: IngestPipeline,
    tenant_id: str,
    content: str | None = None,
    encrypted_body: object | None = None,
    valid_at: datetime,
    valid_until: datetime | None = None,
    asserted_at: datetime | None = None,
    our_id: str | None = None,
    corrects: UUID | None = None,
    entity_type_hints: list[str] | None = None,
    sensitive: Sensitivity = "private",
    language: str | None = None,
) -> IngestReceipt:
    """Public coroutine. Constructs `EpisodeIn` and dispatches to the pipeline."""
    try:
        episode = EpisodeIn(
            tenant_id=tenant_id,
            content=content,
            encrypted_body=encrypted_body,  # type: ignore[arg-type]
            valid_at=valid_at,
            valid_until=valid_until,
            asserted_at=asserted_at,
            our_id=our_id,
            corrects=corrects,
            entity_type_hints=entity_type_hints,
            sensitive=sensitive,
            language=language,
        )
    except PydanticValidationError as exc:
        raise ValidationError(str(exc)) from exc
    try:
        return await pipeline.ingest(episode)
    except GnokeeError:
        raise
```

- [ ] **Step 3: Run existing tests to verify no regression**

Run: `pytest tests/unit/ -v`
Expected: PASS (all existing + the 4 new tasks' unit tests).

Run: `pytest tests/integration/test_idempotency.py tests/integration/test_clinical_lab_e2e.py tests/integration/test_clinical_med_e2e.py -v`
Expected: PASS (Stage 6 changes are additive; existing flows shouldn't break).

Run: `mypy src/gnokee/ingest.py`
Expected: clean.

Run: `ruff check src/gnokee/ingest.py && ruff format --check src/gnokee/ingest.py`
Expected: clean.

- [ ] **Step 4: Commit**

```bash
git add src/gnokee/ingest.py
git commit -m "feat(ingest): Stage 6 supersession wiring + corrects on ingest_episode helper (v0.2.1)"
```

---

## Task 7: e2e supersession integration tests

The 11-case suite from the spec, against real Postgres + Neo4j + TEI. Mirrors `test_clinical_lab_e2e.py` patterns (uses `app: App` + `fresh_tenant: str` fixtures from `tests/integration/conftest.py`).

**Files:**
- Create: `tests/integration/test_supersession_e2e.py`

- [ ] **Step 1: Write the file (all 11 cases)**

Create `tests/integration/test_supersession_e2e.py`:

```python
"""tests/integration/test_supersession_e2e.py — v0.2.1 corrects: signal.

End-to-end supersession against real Postgres + Neo4j + TEI:
- lab + med row-level supersession
- episode_metadata supersession (asserted_until + superseded_by)
- aggregation respects supersession (Q7 q_k_lowest_2024 named bug)
- cross-tenant rejection
- chain-walk from stale target
- pure-narrative correction (no parsed rows)
- idempotent replay (Stage 1b short-circuit + race-lost rollback)
"""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from uuid import UUID, uuid4

import pytest

from gnokee.bootstrap import App
from gnokee.errors import (
    CorrectsAxisInversionError,
    CorrectsCrossTenantError,
    EpisodeNotFoundError,
)
from gnokee.ingest import ingest_episode
from gnokee.lab_query import lab_query

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not (os.environ.get("GNOKEE_OPENAI_API_KEY") or os.environ.get("GNOKEE_LLM_API_KEY")),
        reason="needs OpenAI-compatible LLM credentials for Graphiti entity extraction",
    ),
]


def _utc(year: int, month: int, day: int, hour: int = 12) -> datetime:
    return datetime(year, month, day, hour, 0, 0, tzinfo=timezone.utc)


_PANEL_APRIL = """\
Lab panel — drawn 2024-04-10, reported 2024-04-12.

Basic Metabolic Panel:
- Potassium: 2.8 mmol/L (ref: 3.5-5.0) **LOW — critical**
- Magnesium: 1.4 mg/dL (ref: 1.7-2.4) **LOW**
"""

_PANEL_APRIL_CORRECTION_K_ONLY = """\
CORRECTION — Lab panel from 2024-04-10
The Potassium result was reported incorrectly due to instrument calibration drift.

- Potassium: 3.6 mmol/L (ref: 3.5-5.0) — within range
"""

_PANEL_MARCH = """\
Lab panel — drawn 2024-03-15, reported 2024-03-15.

Basic Metabolic Panel:
- Potassium: 3.2 mmol/L (ref: 3.5-5.0) — borderline low
"""

_MED_LISINOPRIL_10 = """\
Started Lisinopril 10 mg PO daily on 2024-06-15 for mild hypertension.
"""

_MED_LISINOPRIL_20_CORRECTION = """\
CORRECTION — the Lisinopril start dose was 20 mg, not 10 mg. Increased
documentation only; clinical course unchanged.

Started Lisinopril 20 mg PO daily on 2024-06-15.
"""


# ---------- Lab cases ----------

@pytest.mark.asyncio
async def test_lab_happy_path_per_row_supersession(
    app: App, fresh_tenant: str
) -> None:
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    async with app.pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT analyte, episode_uuid, asserted_until "
            "FROM lab_record WHERE tenant_id = $1 ORDER BY analyte, asserted_at",
            fresh_tenant,
        )
    by_key = {(r["analyte"], r["episode_uuid"]): r["asserted_until"] for r in rows}
    # A's K row closed.
    assert by_key[("Potassium", receipt_a.episode_uuid)] == receipt_b.asserted_at
    # A's Mg row stays open (correction did not re-assert it).
    assert by_key[("Magnesium", receipt_a.episode_uuid)] is None
    # B's K row open.
    assert by_key[("Potassium", receipt_b.episode_uuid)] is None


@pytest.mark.asyncio
async def test_episode_metadata_supersession(
    app: App, fresh_tenant: str
) -> None:
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    async with app.pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT asserted_until, superseded_by FROM episode_metadata "
            "WHERE tenant_id = $1 AND episode_uuid = $2",
            fresh_tenant,
            receipt_a.episode_uuid,
        )
    assert row is not None
    assert row["asserted_until"] == receipt_b.asserted_at
    assert row["superseded_by"] == receipt_b.episode_uuid


@pytest.mark.asyncio
async def test_aggregation_respects_supersession(
    app: App, fresh_tenant: str
) -> None:
    """The named v0.2.1 bug: MIN(value_numeric) skips the superseded 2.8."""
    march = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_MARCH,
        valid_at=_utc(2024, 3, 15),
        asserted_at=_utc(2024, 3, 15),
        sensitive="clinical",
    )
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    response = await lab_query(
        app=app,
        tenant_id=fresh_tenant,
        op="min",
        analyte="Potassium",
        since=_utc(2024, 1, 1),
        until=_utc(2025, 1, 1),
        as_of=_utc(2024, 12, 31),
        valid_at=_utc(2024, 12, 31),
    )
    # March's 3.2 wins, because April's 2.8 is superseded by 3.6.
    assert "3.2" in response, f"expected 3.2 (March), got: {response}"


# ---------- Med cases ----------

@pytest.mark.asyncio
async def test_med_happy_path_per_row_supersession(
    app: App, fresh_tenant: str
) -> None:
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_MED_LISINOPRIL_10,
        valid_at=_utc(2024, 6, 15),
        asserted_at=_utc(2024, 6, 15),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_MED_LISINOPRIL_20_CORRECTION,
        valid_at=_utc(2024, 6, 15),
        asserted_at=_utc(2024, 6, 20),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    async with app.pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT episode_uuid, drug_name, event_kind, dose_value, "
            "asserted_until FROM med_record WHERE tenant_id = $1 "
            "ORDER BY asserted_at",
            fresh_tenant,
        )
    a_rows = [r for r in rows if r["episode_uuid"] == receipt_a.episode_uuid]
    b_rows = [r for r in rows if r["episode_uuid"] == receipt_b.episode_uuid]
    assert a_rows and a_rows[0]["asserted_until"] == receipt_b.asserted_at
    assert b_rows and b_rows[0]["asserted_until"] is None


# ---------- Validation cases ----------

@pytest.mark.asyncio
async def test_cross_tenant_rejected(app: App) -> None:
    tenant_a = f"e2e-supersede-a-{uuid4().hex[:8]}"
    tenant_b = f"e2e-supersede-b-{uuid4().hex[:8]}"
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=tenant_a,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    with pytest.raises(CorrectsCrossTenantError):
        await ingest_episode(
            pipeline=app.ingest,
            tenant_id=tenant_b,
            content=_PANEL_APRIL_CORRECTION_K_ONLY,
            valid_at=_utc(2024, 4, 10),
            asserted_at=_utc(2024, 4, 25),
            sensitive="clinical",
            corrects=receipt_a.episode_uuid,
        )


@pytest.mark.asyncio
async def test_episode_not_found(app: App, fresh_tenant: str) -> None:
    with pytest.raises(EpisodeNotFoundError):
        await ingest_episode(
            pipeline=app.ingest,
            tenant_id=fresh_tenant,
            content=_PANEL_APRIL_CORRECTION_K_ONLY,
            valid_at=_utc(2024, 4, 10),
            asserted_at=_utc(2024, 4, 25),
            sensitive="clinical",
            corrects=UUID("00000000-0000-0000-0000-000000000000"),
        )


@pytest.mark.asyncio
async def test_axis_inversion(app: App, fresh_tenant: str) -> None:
    receipt = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),  # late
        sensitive="clinical",
    )
    with pytest.raises(CorrectsAxisInversionError):
        await ingest_episode(
            pipeline=app.ingest,
            tenant_id=fresh_tenant,
            content=_PANEL_APRIL_CORRECTION_K_ONLY,
            valid_at=_utc(2024, 4, 10),
            asserted_at=_utc(2024, 4, 12),  # earlier than corrected
            sensitive="clinical",
            corrects=receipt.episode_uuid,
        )


# ---------- Chain + edge cases ----------

@pytest.mark.asyncio
async def test_chained_correction(app: App, fresh_tenant: str) -> None:
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    panel_april_re_correction = """\
CORRECTION 2 — Lab panel from 2024-04-10
- Potassium: 3.4 mmol/L (ref: 3.5-5.0) — slightly below
"""
    receipt_c = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=panel_april_re_correction,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 5, 5),
        sensitive="clinical",
        corrects=receipt_b.episode_uuid,
    )
    async with app.pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT episode_uuid, asserted_until, superseded_by "
            "FROM episode_metadata WHERE tenant_id = $1",
            fresh_tenant,
        )
    by_uuid = {r["episode_uuid"]: r for r in rows}
    assert by_uuid[receipt_a.episode_uuid]["asserted_until"] == receipt_b.asserted_at
    assert by_uuid[receipt_a.episode_uuid]["superseded_by"] == receipt_b.episode_uuid
    assert by_uuid[receipt_b.episode_uuid]["asserted_until"] == receipt_c.asserted_at
    assert by_uuid[receipt_b.episode_uuid]["superseded_by"] == receipt_c.episode_uuid
    assert by_uuid[receipt_c.episode_uuid]["asserted_until"] is None


@pytest.mark.asyncio
async def test_empty_new_rows_with_corrects(
    app: App, fresh_tenant: str
) -> None:
    """Pure-narrative correction: no parseable lab/med rows in the body.

    episode_metadata supersession runs; row-level supersession is a no-op.
    """
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=(
            "Note attached to the 2024-04-10 panel: instrument calibration "
            "review found drift. Caller should disregard the panel pending "
            "re-test. No values restated."
        ),
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    async with app.pool.acquire() as conn:
        meta = await conn.fetchrow(
            "SELECT asserted_until, superseded_by FROM episode_metadata "
            "WHERE tenant_id = $1 AND episode_uuid = $2",
            fresh_tenant,
            receipt_a.episode_uuid,
        )
        labs = await conn.fetch(
            "SELECT asserted_until FROM lab_record WHERE tenant_id = $1 "
            "AND episode_uuid = $2",
            fresh_tenant,
            receipt_a.episode_uuid,
        )
    assert meta is not None
    assert meta["asserted_until"] == receipt_b.asserted_at
    assert meta["superseded_by"] == receipt_b.episode_uuid
    # All A's lab rows still open (correction body had no parseable values).
    for r in labs:
        assert r["asserted_until"] is None


@pytest.mark.asyncio
async def test_idempotent_replay_with_corrects(
    app: App, fresh_tenant: str
) -> None:
    """Stage 1b short-circuit: same our_id + same corrects -> replayed."""
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    first = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
        our_id="april-correction",
    )
    second = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
        our_id="april-correction",
    )
    assert second.replayed is True
    assert second.episode_uuid == first.episode_uuid
    # Supersession applied exactly once on first call.
    async with app.pool.acquire() as conn:
        a_meta = await conn.fetchrow(
            "SELECT asserted_until, superseded_by FROM episode_metadata "
            "WHERE tenant_id = $1 AND episode_uuid = $2",
            fresh_tenant,
            receipt_a.episode_uuid,
        )
    assert a_meta is not None
    assert a_meta["asserted_until"] == first.asserted_at
    assert a_meta["superseded_by"] == first.episode_uuid


@pytest.mark.asyncio
async def test_chain_walk_from_stale_target(
    app: App, fresh_tenant: str
) -> None:
    """A -> B already; ingest C with corrects=A; B is what closes."""
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    re_correction = """\
CORRECTION 2 — Lab panel from 2024-04-10
- Potassium: 3.4 mmol/L (ref: 3.5-5.0)
"""
    receipt_c = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=re_correction,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 5, 5),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,  # caller named the original
    )
    async with app.pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT episode_uuid, asserted_until, superseded_by "
            "FROM episode_metadata WHERE tenant_id = $1",
            fresh_tenant,
        )
    by_uuid = {r["episode_uuid"]: r for r in rows}
    # A unchanged from the A->B step.
    assert by_uuid[receipt_a.episode_uuid]["asserted_until"] == receipt_b.asserted_at
    assert by_uuid[receipt_a.episode_uuid]["superseded_by"] == receipt_b.episode_uuid
    # B closed by C (chain walk resolved A -> B).
    assert by_uuid[receipt_b.episode_uuid]["asserted_until"] == receipt_c.asserted_at
    assert by_uuid[receipt_b.episode_uuid]["superseded_by"] == receipt_c.episode_uuid
    assert by_uuid[receipt_c.episode_uuid]["asserted_until"] is None
```

- [ ] **Step 2: Run the suite**

Run: `pytest tests/integration/test_supersession_e2e.py -v`
Expected: PASS (11 tests).

Run: `mypy tests/integration/test_supersession_e2e.py`
Expected: clean.

Run: `ruff check tests/integration/test_supersession_e2e.py && ruff format --check tests/integration/test_supersession_e2e.py`
Expected: clean.

If any case fails, the fix is in the implementation tasks 1–6, not the test — re-read the failing assertion against the spec, repair, re-run the unit tests (which are quicker), then re-run the e2e.

- [ ] **Step 3: Commit**

```bash
git add tests/integration/test_supersession_e2e.py
git commit -m "test(integration): 11-case supersession e2e suite (v0.2.1)"
```

---

## Task 8: Q7 spike harness — `corrects:` plumbing + fresh tenant

**Files:**
- Modify: `evals/spike_q7_lab_results/run.py` (`TENANT_ID`, `ingest_corpus`)
- Modify: `evals/spike_q7_lab_results/corpus.jsonl` (the existing `lab_2024_04_25_correction` entry)

- [ ] **Step 1: Bump tenant id**

Edit `evals/spike_q7_lab_results/run.py`. Change `TENANT_ID = "spike-q7-v0_2"` to:

```python
TENANT_ID = "spike-q7-v0_2_1"
```

- [ ] **Step 2: Plumb `corrects` through `ingest_corpus`**

Replace the existing `ingest_corpus` function in `evals/spike_q7_lab_results/run.py` with:

```python
async def ingest_corpus(app: Any, episodes: list[dict[str, Any]]) -> dict[UUID, str]:
    """Ingest every episode; return mapping {episode_uuid: our_id}.

    Supports `corrects: <our_id>` references between corpus entries.
    The harness builds the `our_id -> episode_uuid` map as it goes; an
    entry referencing `corrects` MUST be ordered after its target in
    the corpus file (sequential ingest in file order).
    """
    uuid_to_ours: dict[UUID, str] = {}
    our_id_to_uuid: dict[str, UUID] = {}
    for ep in episodes:
        valid_at = _parse_iso(ep["valid_time_start"])
        asserted_at = _parse_iso(ep["observed_time"]) if ep.get("observed_time") else None
        corrects_uuid: UUID | None = None
        corrects_ref = ep.get("corrects")
        if corrects_ref:
            target = our_id_to_uuid.get(f"q7-spike:{corrects_ref}")
            if target is None:
                raise RuntimeError(
                    f"corpus entry {ep['id']} corrects {corrects_ref!r} "
                    f"but target not yet ingested (fix corpus ordering)"
                )
            corrects_uuid = target
        receipt: IngestReceipt = await ingest_episode(
            pipeline=app.ingest,
            tenant_id=TENANT_ID,
            content=ep["content"],
            valid_at=valid_at,
            asserted_at=asserted_at,
            our_id=f"q7-spike:{ep['id']}",
            sensitive="clinical",
            corrects=corrects_uuid,
        )
        uuid_to_ours[receipt.episode_uuid] = ep["id"]
        our_id_to_uuid[f"q7-spike:{ep['id']}"] = receipt.episode_uuid
        replayed = " (replayed)" if receipt.replayed else ""
        suffix = f" corrects={corrects_ref}" if corrects_ref else ""
        print(f"  ingested {ep['id']} → {receipt.episode_uuid}{replayed}{suffix}")
    return uuid_to_ours
```

- [ ] **Step 3: Add `corrects:` to the April-correction corpus entry**

Edit `evals/spike_q7_lab_results/corpus.jsonl`. The existing line begins:

```
{"id": "lab_2024_04_25_correction", "tenant": "spike-q7", "source": "lab:synthetic", ...
```

Add a `"corrects": "lab_2024_04_10"` field (matching the `our_id` of the original April panel — verify by grepping `corpus.jsonl` for `lab_2024_04_10` and confirming that's the `id` of the original April panel; if the actual id is different, use that). Position the field anywhere in the JSON object; suggested placement after `"observed_time"`:

```jsonc
{"id": "lab_2024_04_25_correction", "tenant": "spike-q7", "source": "lab:synthetic", "valid_time_start": "2024-04-10T08:15:00Z", "observed_time": "2024-04-25T16:30:00Z", "corrects": "lab_2024_04_10", "language": "en", "content": "CORRECTION — ..."}
```

(All on one line; the file is jsonl.)

- [ ] **Step 4: Re-spike Q7**

Run: `cd evals/spike_q7_lab_results && ../../.venv/bin/python run.py`
Expected: ingest succeeds for all 15 episodes; the correction line prints `corrects=lab_2024_04_10`. Final summary: 11/15 PASS (one PASS lift over v0.2.0's 10/15 — `q_k_lowest_2024` flips).

If `q_k_lowest_2024` does NOT flip:
- Inspect the spike's results JSON (`results/<utc-stamp>.json`) for the typed-call response on that query.
- Verify in psql: `SELECT analyte, value_numeric, asserted_until FROM lab_record WHERE tenant_id='spike-q7-v0_2_1' AND analyte='Potassium' ORDER BY valid_at;` — the April 2.8 row should have `asserted_until` populated.

- [ ] **Step 5: Commit**

```bash
git add evals/spike_q7_lab_results/run.py evals/spike_q7_lab_results/corpus.jsonl
git commit -m "feat(evals,q7): corrects: plumbing + fresh tenant + April correction wires v0.2.1 (q_k_lowest_2024 PASS)"
```

Do NOT commit the new results JSON yet; that goes alongside the ADR amendment in Task 11.

---

## Task 9: Q8 spike harness — same plumbing + new corpus entry + new query

**Files:**
- Modify: `evals/spike_q8_med_supersession/run.py`
- Modify: `evals/spike_q8_med_supersession/corpus.jsonl`
- Modify: `evals/spike_q8_med_supersession/queries.yaml`

- [ ] **Step 1: Bump tenant id + plumb `corrects`**

Edit `evals/spike_q8_med_supersession/run.py`. Change `TENANT_ID` to:

```python
TENANT_ID = "spike-q8-v0_2_1"
```

Replace the existing `ingest_corpus` with the same shape as Task 8's, substituting the `q8-spike:` prefix for `q7-spike:`:

```python
async def ingest_corpus(app: Any, episodes: list[dict[str, Any]]) -> dict[UUID, str]:
    """Ingest every episode; return mapping {episode_uuid: our_id}.

    Supports `corrects: <our_id>` references; entries with `corrects`
    MUST appear AFTER their target in corpus.jsonl.
    """
    uuid_to_ours: dict[UUID, str] = {}
    our_id_to_uuid: dict[str, UUID] = {}
    for ep in episodes:
        valid_at = _parse_iso(ep["valid_time_start"])
        asserted_at = _parse_iso(ep["observed_time"]) if ep.get("observed_time") else None
        corrects_uuid: UUID | None = None
        corrects_ref = ep.get("corrects")
        if corrects_ref:
            target = our_id_to_uuid.get(f"q8-spike:{corrects_ref}")
            if target is None:
                raise RuntimeError(
                    f"corpus entry {ep['id']} corrects {corrects_ref!r} "
                    f"but target not yet ingested (fix corpus ordering)"
                )
            corrects_uuid = target
        receipt: IngestReceipt = await ingest_episode(
            pipeline=app.ingest,
            tenant_id=TENANT_ID,
            content=ep["content"],
            valid_at=valid_at,
            asserted_at=asserted_at,
            our_id=f"q8-spike:{ep['id']}",
            sensitive="clinical",
            corrects=corrects_uuid,
        )
        uuid_to_ours[receipt.episode_uuid] = ep["id"]
        our_id_to_uuid[f"q8-spike:{ep['id']}"] = receipt.episode_uuid
        replayed = " (replayed)" if receipt.replayed else ""
        suffix = f" corrects={corrects_ref}" if corrects_ref else ""
        print(f"  ingested {ep['id']} → {receipt.episode_uuid}{replayed}{suffix}")
    return uuid_to_ours
```

- [ ] **Step 2: Add the synthetic correction episode to `corpus.jsonl`**

Append to `evals/spike_q8_med_supersession/corpus.jsonl` (one line):

```jsonc
{"id": "med_2024_02_03_lisinopril_correction", "tenant": "spike-q8", "source": "med:synthetic", "valid_time_start": "2024-02-01T09:00:00Z", "observed_time": "2024-02-03T10:00:00Z", "corrects": "med_2024_02_01_lisinopril_start", "language": "en", "content": "CORRECTION — the Lisinopril start dose on 2024-02-01 was 20 mg, not 10 mg. Increased documentation only; clinical course unchanged.\n\nStarted Lisinopril 20 mg PO daily on 2024-02-01."}
```

(Verify the target `our_id` matches — open `corpus.jsonl` and look for the `id` of the Lisinopril-start episode. If the existing id differs, edit the `corrects:` value to match.)

The correction MUST appear after the Lisinopril-start episode in file order.

- [ ] **Step 3: Add the new query to `queries.yaml`**

Append to `evals/spike_q8_med_supersession/queries.yaml` (under the `queries:` list, as the 16th entry):

```yaml
  - id: q_lisinopril_dose_corrected
    pattern: "supersession-aware: typed read returns the corrected dose, not the original"
    query: "What was the starting dose of Lisinopril on 2024-02-01?"
    expects: [med_2024_02_03_lisinopril_correction]
    axes: tx_time
    valid_at: "2024-02-15T00:00:00Z"
    value_substring: "20"
    notes: "After the 2024-02-03 correction, typed history at valid_at=2024-02-15 must show 20 mg (corrected), not 10 mg (superseded)."
    typed:
      tool: gnokee_med_query
      op: history
      args:
        drug_name: Lisinopril
        since: "2024-02-01T00:00:00Z"
        until: "2024-02-02T00:00:00Z"
```

- [ ] **Step 4: Re-spike Q8**

Run: `cd evals/spike_q8_med_supersession && ../../.venv/bin/python run.py`
Expected: ingest succeeds for all 13 episodes (12 original + 1 correction). Final summary: 16/16 PASS (extends to 16; the new query must pass).

If `q_lisinopril_dose_corrected` fails:
- Inspect `results/<utc-stamp>.json` for the typed response.
- Verify in psql: `SELECT drug_name, dose_value, event_kind, asserted_until FROM med_record WHERE tenant_id='spike-q8-v0_2_1' AND drug_name='Lisinopril' ORDER BY asserted_at;` — the original 10mg row should have `asserted_until` populated; the 20mg row should be open.

- [ ] **Step 5: Commit**

```bash
git add evals/spike_q8_med_supersession/run.py evals/spike_q8_med_supersession/corpus.jsonl evals/spike_q8_med_supersession/queries.yaml
git commit -m "feat(evals,q8): corrects: plumbing + Lisinopril correction + q_lisinopril_dose_corrected (v0.2.1)"
```

---

## Task 10: ADR-0009 + ADR-0010 status notes

**Files:**
- Modify: `docs/adr/0009-clinical-labs-need-structured-store.md` (Status notes section)
- Modify: `docs/adr/0010-meds-share-lab-record-shape.md` (Status notes section)

- [ ] **Step 1: Append v0.2.1 result to ADR-0009**

Edit `docs/adr/0009-clinical-labs-need-structured-store.md`. After the existing `## Status notes` bullets, append:

```markdown
- **v0.2.1 supersession-aware ingest landed** (commit on 2026-05-09).
  `EpisodeIn.corrects: UUID | None` boundary signal closes prior
  `lab_record` rows and `episode_metadata.asserted_until` +
  `superseded_by` inside the Stage 6 single-txn block. Chain-walk +
  `SELECT … FOR UPDATE` serialize concurrent corrects-on-same-chain.
  Q7 re-spike (fresh tenant `spike-q7-v0_2_1`): pass = **11/15
  (73.3 %)** — `q_k_lowest_2024` flips PASS (typed `min` op now skips
  the closed 2.8 mmol/L April row, returns 3.2 mmol/L from March).
  Verdict stays ADOPT_WITH_GAPS. Remaining 4 partials unchanged
  (`q_correction_audit` narrative-only, `q_med_lab_link_furosemide`
  cross-domain narrative, `q_panel_count_2024` count-can't-backfill,
  `q_electrolyte_abnormal_q2` Mg row not routed to typed call).
```

- [ ] **Step 2: Append v0.2.1 result to ADR-0010**

Edit `docs/adr/0010-meds-share-lab-record-shape.md`. After the existing `## Status notes` bullets, append:

```markdown
- **v0.2.1 supersession-aware ingest landed** (commit on 2026-05-09).
  Same `EpisodeIn.corrects` boundary applies to `med_record`; key
  granularity is `(drug_name, event_kind, valid_at)`. Q8 re-spike
  (fresh tenant `spike-q8-v0_2_1`) extends to **16 queries** (the new
  `q_lisinopril_dose_corrected` exercises the corrects: signal
  end-to-end). Pass = **16/16 (100 %)**. Verdict stays ADOPT.
  Confirms med-side parity with the lab-side fix.
```

- [ ] **Step 3: Verify formatting**

Run: `python -c "import pathlib; [print(p, p.read_text().count('## Status notes')) for p in pathlib.Path('docs/adr').glob('00[09][09]*.md')]"`
Expected: each ADR has exactly one `## Status notes` section.

- [ ] **Step 4: Commit**

```bash
git add docs/adr/0009-clinical-labs-need-structured-store.md docs/adr/0010-meds-share-lab-record-shape.md
git commit -m "docs(adr): v0.2.1 status notes — Q7 11/15 + Q8 16/16 (corrects: signal)"
```

---

## Task 11: Open PR 1 (feat) + verify CI

**Files:** none (git operation)

- [ ] **Step 1: Push the feat branch**

Pre-flight: confirm the branch.

```bash
git status
git log --oneline -10
```

If on `main`, branch the work first (the conventions in this repo accept either feature-branch-PR or push-to-main-PR styles; the v0.2 history shows feature branches via PR — mirror that):

```bash
git checkout -b feat/v0_2_1-supersession-aware-ingest
git push -u origin feat/v0_2_1-supersession-aware-ingest
```

If working directly on `main` is preferred for this repo's solo-dev workflow, skip the branch step.

- [ ] **Step 2: Open the PR**

```bash
gh pr create \
  --title "feat(ingest): EpisodeIn.corrects + Stage 6 supersession (v0.2.1)" \
  --body "$(cat <<'EOF'
## Summary

- `EpisodeIn.corrects: UUID | None` boundary signal — when set, supersedes prior `lab_record` + `med_record` rows whose key matches the new rows AND closes the corrected `episode_metadata` row.
- 3 new storage primitives: `MetadataStore.supersede` (with `FOR UPDATE` chain-walk to head, depth bound 32), `LabStore.supersede_matching`, `MedStore.supersede_matching`.
- 4 new typed errors (`CorrectsError` base + `EpisodeNotFoundError`, `CorrectsCrossTenantError`, `CorrectsAxisInversionError`, `CorrectsChainError`); all subclass `VectorStoreError` so existing Stage 6 compensate path catches them and rolls back the Graphiti episode atomically.
- Q7 re-spike (fresh tenant `spike-q7-v0_2_1`): **11/15** (73.3 %) — `q_k_lowest_2024` flips PASS.
- Q8 extends to **16/16** (100 %) with new `q_lisinopril_dose_corrected`.
- Spec: `docs/superpowers/specs/2026-05-09-v0_2_1-supersession-aware-ingest-design.md` (commit c409751).

## Test plan

- [ ] `pytest tests/unit/ -v` — all unit tests green
- [ ] `pytest tests/integration/test_supersession_e2e.py -v` — 11 e2e cases green
- [ ] `pytest tests/integration/ -v` — full integration regression
- [ ] Q7 re-spike output committed via ADR-0009 status note (11/15)
- [ ] Q8 re-spike output committed via ADR-0010 status note (16/16)

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

- [ ] **Step 3: Watch CI**

Run: `gh pr checks --watch`
Expected: all green. If any test fails, fix on branch and push (do NOT amend a hook-failure commit; create a new commit per AGENTS.md guidance).

- [ ] **Step 4: Merge**

Run: `gh pr merge --squash --delete-branch`

---

## Task 12: PR 2 — version bump + CHANGELOG

**Files:**
- Modify: `pyproject.toml`
- Modify: `CHANGELOG.md`

- [ ] **Step 1: Branch from updated main**

```bash
git checkout main
git pull origin main
git checkout -b chore/release-v0_2_1
```

- [ ] **Step 2: Bump pyproject version**

Edit `pyproject.toml`. Find the `version = "0.2.0"` line and change it to:

```toml
version = "0.2.1"
```

- [ ] **Step 3: Add `[0.2.1]` entry to CHANGELOG.md**

Edit `CHANGELOG.md`. Insert above the existing `## [0.2.0]` entry (and below the format header):

```markdown
## [0.2.1] — 2026-05-09

Supersession-aware ingest. The named v0.2.0 follow-up gap closes:
correction episodes now propagate `asserted_until` to prior
`lab_record` + `med_record` rows and to `episode_metadata`. Q7's
`q_k_lowest_2024` flips from FAIL to PASS (typed `min` aggregation
now skips superseded values).

### Added

- **`EpisodeIn.corrects: UUID | None`** boundary signal. When set,
  declares this episode supersedes a prior one. Same-tenant only;
  corrected episode must exist; new `asserted_at` must be greater
  than the corrected episode's. Chain-walk follows `superseded_by`
  to the current head when the caller named a stale target.
- **3 new storage primitives:** `MetadataStore.supersede`
  (validates + walks the chain via `SELECT … FOR UPDATE` per hop;
  depth bound 32 raises `CorrectsChainError`), `LabStore.supersede_matching`
  (per-row `(analyte, valid_at)` UPDATE), `MedStore.supersede_matching`
  (per-row `(drug_name, event_kind, valid_at)` UPDATE). All
  parameterised on `tenant_id` + the chain-walk-resolved head's
  `episode_uuid`.
- **4 new typed errors:** `CorrectsError` (base) + `EpisodeNotFoundError`,
  `CorrectsCrossTenantError`, `CorrectsAxisInversionError`,
  `CorrectsChainError`. All subclass `VectorStoreError`, so the
  existing Stage 6 compensate path rolls back the Graphiti episode.
- **Module-level `ingest_episode(...)` helper** gains
  `corrects: UUID | None = None`. Backwards-compatible.
- **Stage 6 wiring:** supersession runs inside the existing
  single-txn block, between the `metadata.write` insert (which
  guards `_OurIdRaceLost`) and the `vector.write_embedding`
  insert. On row-level partial-key UPDATE (count < `len(keys)`),
  Stage 6 logs a `WARNING` — surfaces parser drift on `valid_at`
  rounding rather than a silent zero-match.
- **11-case integration suite** at
  `tests/integration/test_supersession_e2e.py`: lab + med happy
  paths, episode-metadata supersession, aggregation respects
  supersession (Q7's named bug), cross-tenant rejection, episode
  not found, axis inversion, chained correction, empty new rows
  with corrects, idempotent replay, chain-walk from stale target.

### Fixed

- **Q7 `q_k_lowest_2024`** — typed `MIN(value_numeric)` over
  Potassium 2024 now returns 3.2 mmol/L (March, open) instead of
  2.8 mmol/L (April, superseded). Q7 lifts 10/15 → 11/15
  (66.7 % → 73.3 %); verdict stays ADOPT_WITH_GAPS.

### Spike harness

- Q7 + Q8 `ingest_corpus` helpers gain `corrects:` plumbing —
  read an optional `corrects: <our_id>` from corpus entries and
  resolve to the runtime `episode_uuid` via the harness's growing
  `our_id → episode_uuid` map. Corpus entries referencing
  `corrects:` MUST appear after their target in file order.
- Fresh re-spike tenants `spike-q7-v0_2_1` and `spike-q8-v0_2_1`
  — re-running against the v0.2.0 tenants would short-circuit on
  `our_id` idempotency and skip Stage 6 entirely.
- Q8 extends to 16 queries: new
  `q_lisinopril_dose_corrected` exercises the corrects: signal
  on med-side. Q8 re-spike: 16/16 (100 %), verdict stays ADOPT.

### Known limitations

- **Graphiti edge supersession is NOT auto-run.** Narrative
  corrections continue to flow through ADR-0008 contradiction
  surfacing. ADR-0009 boundary holds: graphiti owns prose,
  gnokee owns the typed half. Correcting an episode does not
  retract its edges from the graph.
- **Encrypted-body branch is unaffected** — `corrects` is
  metadata, orthogonal to the body shape. Encrypted-body remains
  `NotImplementedYet` per v0.1 guard.

```

- [ ] **Step 4: Verify**

Run: `python -c "import tomllib; print(tomllib.loads(open('pyproject.toml','rb').read().decode())['project']['version'])"`
Expected: `0.2.1`

Run: `head -20 CHANGELOG.md`
Expected: shows the new `[0.2.1]` entry above `[0.2.0]`.

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml CHANGELOG.md
git commit -m "chore(release): v0.2.1 — supersession-aware ingest"
```

- [ ] **Step 6: Open release PR**

```bash
git push -u origin chore/release-v0_2_1
gh pr create \
  --title "chore(release): v0.2.1 — supersession-aware ingest" \
  --body "$(cat <<'EOF'
## Summary

- pyproject 0.2.0 → 0.2.1
- CHANGELOG `[0.2.1]` entry
- Mirrors v0.2.0 cut style; tag-cut + GitHub release follow once merged.

## Test plan

- [ ] CI green
- [ ] After merge: `git tag -a v0.2.1` + `git push origin v0.2.1` + `gh release create v0.2.1`

🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)"
```

- [ ] **Step 7: Merge after CI green**

Run: `gh pr checks --watch && gh pr merge --squash --delete-branch`

---

## Task 13: Tag-cut + GitHub release

**Files:** none (git + gh release)

- [ ] **Step 1: Update local main**

```bash
git checkout main
git pull origin main
```

- [ ] **Step 2: Confirm release commit on HEAD**

Run: `git log --oneline -3`
Expected: top commit is the squashed `chore(release): v0.2.1 …`.

- [ ] **Step 3: Annotated tag**

```bash
git tag -a v0.2.1 -m "v0.2.1 — supersession-aware ingest (corrects: signal); Q7 q_k_lowest_2024 fixed"
git push origin v0.2.1
```

- [ ] **Step 4: GitHub release**

```bash
gh release create v0.2.1 \
  --title "v0.2.1 — supersession-aware ingest (corrects: signal)" \
  --notes "$(cat <<'EOF'
## Headline

- **Q7 `q_k_lowest_2024`: FAIL → PASS** — typed `MIN(value_numeric)` skips superseded April Potassium 2.8 mmol/L; returns March 3.2 mmol/L. Q7 10/15 → **11/15 (73.3 %)**.
- **Q8 extends to 16/16 (100 %)** — new `q_lisinopril_dose_corrected` exercises med-side `corrects:` parity.
- Closes the named v0.2.0 follow-up gap from ADR-0009 + ADR-0010.

## Why

ADR-0009 / ADR-0010 prescribed an explicit `corrects: episode_uuid` signal from the caller. v0.2.0 landed the typed stores but the write path never closed prior rows — visible aggregations included superseded values. v0.2.1 wires the supersession primitive through Stage 6 atomically.

## Added

- **`EpisodeIn.corrects: UUID | None`** boundary signal. Same-tenant only; corrected episode must exist; `asserted_at` axis enforced. Chain-walks `superseded_by` to the current head when caller names a stale target.
- **3 new storage primitives:** `MetadataStore.supersede` (`FOR UPDATE` per chain hop, depth bound 32), `LabStore.supersede_matching`, `MedStore.supersede_matching`.
- **4 new typed errors:** `EpisodeNotFoundError`, `CorrectsCrossTenantError`, `CorrectsAxisInversionError`, `CorrectsChainError` — all subclass `VectorStoreError` so the existing Stage 6 compensate path rolls back the Graphiti episode atomically.
- **11-case integration suite** at `tests/integration/test_supersession_e2e.py`.
- **Q7 + Q8 spike harnesses** gain `corrects:` plumbing; re-spike on fresh tenants `spike-q7-v0_2_1` / `spike-q8-v0_2_1`.

## Known limitations

- **Graphiti edge supersession NOT auto-run.** Narrative corrections continue to flow through ADR-0008 contradiction surfacing. ADR-0009 boundary holds.
- **Encrypted-body branch unaffected** — `corrects` is metadata, orthogonal to body shape.

## Validation

- 11 new integration tests (real Postgres + Neo4j + TEI)
- 6 new metadata-supersede unit tests, 3 lab-supersede + 2 med-supersede unit tests
- Q7 re-spike: 11/15 (73.3 %) — ADOPT_WITH_GAPS
- Q8 re-spike: 16/16 (100 %) — ADOPT

Full changelog: https://github.com/omurlabs/gnokee/blob/main/CHANGELOG.md
EOF
)"
```

- [ ] **Step 5: Verify**

Run: `gh release view v0.2.1`
Expected: title, tag, draft=false.

Run: `git tag -l v0.2.1 --format='%(refname:short) %(taggerdate:short) %(subject)'`
Expected: `v0.2.1 2026-05-09 v0.2.1 — supersession-aware ingest (corrects: signal); Q7 q_k_lowest_2024 fixed`

---

## Self-review checklist

After completing all tasks, run the spec-coverage check:

- [ ] **Spec §1 boundary contract** → Task 2 (`EpisodeIn.corrects`)
- [ ] **Spec §2 errors** → Task 1 (4 classes including `CorrectsChainError`)
- [ ] **Spec §3 LabStore.supersede_matching** → Task 3 (real-Postgres unit tests)
- [ ] **Spec §3 MedStore.supersede_matching** → Task 4
- [ ] **Spec §3 MetadataStore.supersede + chain-walk + FOR UPDATE** → Task 5
- [ ] **Spec §4 Stage 6 wiring** → Task 6 (with parser-drift WARNING log)
- [ ] **Spec §5 ingest_episode helper signature** → Task 6 step 2
- [ ] **Spec validation rules table (5 rules)** → covered across Tasks 1, 5
- [ ] **Spec test §1–11** → Task 7 (all 11)
- [ ] **Spec Q7 spike updates** → Task 8 (fresh tenant + corrects plumbing + corpus)
- [ ] **Spec Q8 spike updates** → Task 9 (same + new query + new episode)
- [ ] **Spec Release flow PR 1** → Task 11
- [ ] **Spec Release flow PR 2** → Task 12
- [ ] **Tag-cut + GitHub release** → Task 13
- [ ] **ADR-0009 + ADR-0010 status note amendments** → Task 10
- [ ] **Deferred items (RLS GUC discipline, partial index, encrypted-body, our_id-in-SELECT trap)** — addressed inline (RLS is set in test fixtures + ingest path; partial-index migration deferred to v0.2.2; encrypted-body unchanged; `our_id` is included in `metadata.supersede`'s SELECT via `_row_to_dc`).
