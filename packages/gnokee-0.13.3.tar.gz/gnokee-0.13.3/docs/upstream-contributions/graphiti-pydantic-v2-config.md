# Upstream contribution: graphiti-core class-based `Config` → `ConfigDict`

## Status

- Issue: [getzep/graphiti#1477](https://github.com/getzep/graphiti/issues/1477)
- PR: [getzep/graphiti#1478](https://github.com/getzep/graphiti/pull/1478)
- Filed: 2026-05-08; awaiting maintainer review.

## What

`graphiti-core==0.29.0` declares a Pydantic v1-style `class Config:` inside
`SearchInterface` at
`graphiti_core/driver/search_interface/search_interface.py:350-351`. Pydantic
v2 deprecated this pattern and emits `PydanticDeprecatedSince20` on every
session that imports the module — including ours.

```python
# graphiti_core/driver/search_interface/search_interface.py:350
    class Config:
        arbitrary_types_allowed = True
```

The deprecation is currently a warning; in Pydantic v3 (eta 2026) it becomes
a hard error and gnokee's stack will fail to import.

## Fix

Replace the inner `Config` class with the v2 idiom:

```python
from pydantic import BaseModel, ConfigDict

class SearchInterface(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    # ... rest of the class unchanged ...
```

That's it. No behavioral change — `arbitrary_types_allowed=True` is preserved
verbatim.

## Why we don't ship a runtime monkey-patch

We considered patching `SearchInterface` at gnokee import time. Rejected:
- Hides the issue from CI on consumer projects that import graphiti-core
  without going through gnokee.
- The patch lifetime is exactly until upstream lands — every gnokee install
  carries dead code if it ever lingers.
- Pydantic-deprecation warnings are global; suppressing in-process doesn't
  change the underlying class, just the noise.

## Workaround (until merged)

`pyproject.toml` filters this exact warning category and module. Drop the
filter the moment upstream tags a release that includes the fix. Tracked in
the `[tool.pytest.ini_options].filterwarnings` block with a TODO pointing
back at this memo.

## Submission plan

1. File issue on `getzep/graphiti` referencing this file.
2. Open PR with the one-line ConfigDict swap.
3. Verify all graphiti-core tests still pass (no v1 `Config`-only behavior
   relied upon).
4. On merge: delete this memo and remove the pytest filterwarnings entry.
