"""docs/upstream-contributions/repro-small-model-404.py — Minimal reproduction for Graphiti issue:.

``LLMConfig.small_model=None`` falls through to hardcoded ``gpt-4.1-nano``.

Run against any OpenAI-compatible endpoint that does NOT host
``gpt-4.1-nano`` (Ollama, Groq, NIM, OpenRouter routing to a non-OpenAI
provider, etc.). Should ingest successfully; will instead 404 on the
first small-model call during entity extraction.

Prereqs:
    pip install graphiti-core>=0.29 neo4j>=5.20 python-dotenv
    docker run -d --name neo4j-repro \\
        -p 7687:7687 -p 7474:7474 \\
        -e NEO4J_AUTH=neo4j/repro-password neo4j:5-community
    ollama serve  &
    ollama pull llama3.1:8b

exports: main()
used_by: none
rules:   none
agent:   codedna-cli (no-llm) | codedna-cli | 2026-05-08 | codedna-cli | initial CodeDNA annotation pass
message:
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime, timezone

from graphiti_core import Graphiti
from graphiti_core.cross_encoder.openai_reranker_client import OpenAIRerankerClient
from graphiti_core.embedder import OpenAIEmbedder, OpenAIEmbedderConfig
from graphiti_core.llm_client import LLMConfig
from graphiti_core.llm_client.openai_generic_client import OpenAIGenericClient
from graphiti_core.nodes import EpisodeType


def main() -> None:
    # Same Ollama-compatible config for LLM, embedder, reranker.
    llm_cfg = LLMConfig(
        api_key="ollama",
        model="llama3.1:8b",
        base_url="http://localhost:11434/v1",
        # small_model intentionally left as None — the docstring says this is allowed.
        # In practice this triggers the bug: Graphiti hard-codes 'gpt-4.1-nano'.
    )
    embed_cfg = OpenAIEmbedderConfig(
        api_key="ollama",
        embedding_model="bge-m3",
        embedding_dim=1024,
        base_url="http://localhost:11434/v1",
    )

    g = Graphiti(
        uri="bolt://localhost:7687",
        user="neo4j",
        password=os.environ.get("NEO4J_PASSWORD", "repro-password"),
        llm_client=OpenAIGenericClient(config=llm_cfg),
        embedder=OpenAIEmbedder(config=embed_cfg),
        cross_encoder=OpenAIRerankerClient(config=llm_cfg),
    )

    async def run() -> None:
        await g.build_indices_and_constraints()
        await g.add_episode(
            name="repro_001",
            episode_body="The user prefers Postgres for the new project.",
            source_description="repro",
            reference_time=datetime.now(timezone.utc),
            source=EpisodeType.text,
            group_id="repro",
        )
        print("Ingest succeeded (bug NOT present).")

    try:
        asyncio.run(run())
    except Exception as exc:
        # Expected outcome on the bug path.
        print(f"BUG REPRODUCED: {type(exc).__name__}: {exc}")


if __name__ == "__main__":
    main()
