# Consumer Integration Patterns

Guidance for integrating gnokee into a consumer application. v0.2+ surface.

## 1. Render-to-episode-body for typed parsers

gnokee's deterministic clinical parsers (ADR-0009 / ADR-0010) infer
structured rows from the text of the episode body. The parser is called
inside Stage 6 of `IngestPipeline.ingest()` — no consumer action required.
The consumer controls what the parser sees by controlling the episode body.

### Lab results — bullet shape

The lab parser (`src/gnokee/extract/clinical/lab_parser.py`) recognises
**markdown-bullet lines** of the form:

```
- Analyte: value unit (ref: low-high)
- Analyte: value unit (ref: low-high) — flag text
- Analyte: value unit (ref: low-high) **LOW — critical**
```

Render each result to this bullet shape before passing the body to
`ingest_episode`. The parser is purely additive: if a line doesn't match,
no row is written and ingest continues normally.

Example body for a lab panel episode:

```
Lab panel — 2026-01-15 fasting lipids

- Total Cholesterol: 210 mg/dL (ref: 0-200) — borderline HIGH
- LDL: 138 mg/dL (ref: 0-100) **HIGH — borderline**
- HDL: 52 mg/dL (ref: 40-60)
- Triglycerides: 145 mg/dL (ref: 0-150)
```

### Medication events — sentence shape

The med parser (`src/gnokee/extract/clinical/med_parser.py`) recognises
**prose sentences** from a fixed vocabulary of event types:

```
Started <drug> <dose> <route> <frequency> [for <reason>].
Increased <drug> from <dose> to <dose> <route> <frequency>.
Discontinued <drug> <dose> [reason].
Stopped <drug> <dose> [reason].
Allergy documented: <drug> — <severity> reaction [description].
```

Render each medication event to one of these sentence shapes in the
episode body. Both the narrative extraction (Graphiti) and the structured
row write consume the same body; sentence shape satisfies both.

### Clinical ↔ Omur field reconciliation

The field-by-field mismatch matrix for `LabResult` ↔ `LabRecordRow` and
`Medication` ↔ `MedRecordRow`, plus the HL7 OBX-8 `HH/LL` → `C`
abnormal-flag mapping, is documented in Omur's internal ADR-033
(`docs/adr/ADR-033-marrow-gnokee-clinical-handoff.md`). See that document
for unit/normalisation decisions and field presence matrix.

---

## 2. Parser-driven vs hint-driven typed rows

gnokee has two mechanisms for attaching structured data to an episode:

| Mechanism | How | When to use |
|---|---|---|
| **Parser-driven** (ADR-0009/0010) | Regex over episode body at Stage 6; writes `lab_record` / `med_record` rows | Structured clinical data where the row fields can be inferred from the rendered body; the primary typed-read path |
| **`entity_type_hints`** (v0.1 advisory) | Passed through to `EpisodeIn`; NOT threaded into Graphiti extractor in v0.2 | Cosmetic / future use; load-bearing only for Graphiti narrative-side custom Pydantic entity types if your consumer extends Graphiti's entity model |

For v0.2 typed queries (`gnokee_lab_query`, `gnokee_med_query`):
- Reads go against `lab_record` / `med_record` tables — these are populated
  only by the parser-driven path.
- `entity_type_hints` has no effect on `gnokee_lab_query` / `gnokee_med_query`
  results.

Use `entity_type_hints` only if you are extending Graphiti's entity model
with custom Pydantic types and want Graphiti's extractor to preferentially
classify extracted entities.

---

## 3. Lite ingest for high-cadence sources

For workloads where Graphiti LLM-extraction latency (p50 ≈ 4.5 s, p95 ≈
7.1 s) is unacceptable — e.g. Omur Pulse 1-minute telemetry windows or
noggin continuous wearable summaries — use `extract=False`:

```python
receipt = await gnokee.ingest_episode(
    pipeline=pipeline,
    tenant_id="omur:tenant-xyz",
    content=rendered_episode_body,
    valid_at=window_start,           # NOT datetime.now() — use world-time
    our_id=f"pulse:{tenant}:{window_start.isoformat()}",
    extract=False,                   # skip Graphiti + contradiction
)
assert receipt.extraction_deferred is True
assert receipt.created_fact_uuids == []
```

What still runs in lite mode:

- Stage 1: boundary validation (tenant_id, content, UTC datetimes)
- Stage 1b: idempotency check on `(tenant_id, our_id)`
- Stage 2: language detection
- Stage 3: embedding (content_embedding written to pgvector)
- Stage 5: asserted_at resolve
- Stage 6: Postgres transaction — `episode_metadata`, `content_embedding`,
  `lab_record`, `med_record`

What is skipped:

- Stage 4: `graphiti.add_episode` (Graphiti LLM extraction)
- Stage 7: contradiction detection

The episode is queryable via `gnokee_lab_query` / `gnokee_med_query`
immediately. It will NOT appear in `gnokee_recall` narrative facts until
deferred extraction runs (see §3.2 below).

### 3.1 Async publish / outbox pattern

For the highest throughput, publish episodes to a Postgres outbox table
inside the same transaction as your domain write, then drain with an async
worker:

```sql
-- outbox table (consumer-owned, not gnokee schema)
CREATE TABLE gnokee_ingest_outbox (
    id          bigserial PRIMARY KEY,
    tenant_id   text NOT NULL,
    our_id      text NOT NULL,
    content     text NOT NULL,
    valid_at    timestamptz NOT NULL,
    asserted_at timestamptz,
    extract     boolean NOT NULL DEFAULT true,
    created_at  timestamptz NOT NULL DEFAULT now()
);
```

```python
# Domain write + outbox in one transaction (consumer-side)
async with pool.acquire() as conn:
    async with conn.transaction():
        await conn.execute("INSERT INTO pulse_reading ...")
        await conn.execute(
            "INSERT INTO gnokee_ingest_outbox "
            "(tenant_id, our_id, content, valid_at, extract) VALUES ($1, $2, $3, $4, $5)",
            tenant_id, our_id, rendered_body, window_start, False,
        )

# Worker (separate process / task)
async def drain_outbox():
    async for row in fetch_pending_outbox():
        receipt = await gnokee.ingest_episode(
            pipeline=pipeline,
            tenant_id=row.tenant_id,
            content=row.content,
            valid_at=row.valid_at,
            our_id=row.our_id,
            extract=row.extract,
        )
        await mark_outbox_done(row.id)
```

Backpressure: the worker should apply a rate limit (e.g. `asyncio.Semaphore`)
to cap concurrent Postgres + TEI connections. Lite mode (`extract=False`)
saturates faster than full mode because it skips the LLM call.

Idempotency: `our_id` ensures re-processing a row (e.g. after worker crash)
is safe — the second call returns `replayed=True` and is a no-op.

### 3.2 Deferred extraction

`gnokee.maintenance.run_deferred_extraction()` queries `episode_metadata`
for rows where `extraction_deferred=TRUE`, calls `graphiti.add_episode`
for each one, and stamps `extraction_completed_at` on success. Episodes
ingested with `extract=False` appear in typed queries immediately but are
invisible to `gnokee_recall` narrative facts until this helper runs.

**Signature:**

```python
async def run_deferred_extraction(
    tenant_id: str,
    *,
    pool: asyncpg.Pool,
    graph: GraphitiStore,
    metadata: MetadataStore,
    contradictions: ContradictionStore,
    llm: OpenAIClient | None = None,
    contradiction_enabled: bool = True,
    since: datetime | None = None,
    batch_size: int = 50,
    max_episodes: int | None = None,
) -> DeferredExtractionReport: ...
```

**Parameters:**

| Parameter | Purpose |
|---|---|
| `tenant_id` | Mandatory. Raises `ValidationError` when empty. |
| `since` | Restrict to episodes with `valid_at >= since`. Useful for targeted backfills (e.g. "last 7 days"). |
| `batch_size` | Episodes per DB fetch. Default 50. |
| `max_episodes` | Hard cap on total episodes this run. `None` = process all deferred. Spread cost over multiple cron ticks. |

**Return value:** `DeferredExtractionReport(processed, succeeded, failed, elapsed_ms)`

**Failure isolation:** one bad episode (Graphiti down, content NULL) does NOT
poison the batch. The failure is recorded in `report.failed`, the row's
`extraction_deferred` is left TRUE (next run retries), and processing
continues.

**Example — cron-style operator script:**

```python
import asyncio
from datetime import datetime, timezone
import asyncpg
import gnokee

async def nightly_backfill() -> None:
    pool = await asyncpg.create_pool(dsn="postgresql://...")
    # Build your pipeline dependencies (graph, metadata, contradictions, llm)
    # as you do in your normal ingest setup.
    report = await gnokee.run_deferred_extraction(
        tenant_id="omur:tenant-xyz",
        pool=pool,
        graph=graph,
        metadata=metadata,
        contradictions=contradictions,
        llm=llm,
        batch_size=100,        # tune to your LLM throughput
        max_episodes=500,      # cap cost per cron tick
    )
    print(
        f"Deferred extraction: {report.succeeded}/{report.processed} ok "
        f"in {report.elapsed_ms}ms, {len(report.failed)} failed"
    )
    for f in report.failed:
        print(f"  FAILED {f.episode_uuid}: {f.error}")

asyncio.run(nightly_backfill())
```

**Scheduling options (gnokee does NOT host a scheduler):**

- **System cron / cron daemon:** wrap the script above in a cron entry.
- **Postgres `pg_cron`:** call a stored procedure that invokes your worker
  via `pg_net` / NOTIFY, or use `pg_cron` to trigger an external HTTP
  endpoint that runs the helper.
- **External task runner (Celery, APScheduler, Temporal, modal.com):**
  import `gnokee.run_deferred_extraction` as a regular async function inside
  your task definition.

**`since` for incremental backfills:**

```python
from datetime import datetime, timezone, timedelta

# Only process episodes from the last 7 days
since = datetime.now(timezone.utc) - timedelta(days=7)
report = await gnokee.run_deferred_extraction(
    tenant_id="t1",
    pool=pool, graph=graph, metadata=metadata, contradictions=contradictions,
    since=since,
)
```

**Idempotency:** re-running against an already-extracted row is a no-op —
the `WHERE extraction_deferred=TRUE` clause excludes it. Safe to run
multiple times or overlap cron windows.

---

## 4. Two-layer split

gnokee is not a canonical clinical store. The recommended pattern is:

```
Consumer canonical store (FHIR / domain model)
    ↓  render to episode body
gnokee (bi-temporal narrative memory + typed clinical rows)
    ↓  recall via gnokee_recall / gnokee_lab_query / gnokee_med_query
LLM agent
```

The consumer keeps the authoritative structured record. gnokee re-extracts
from the rendered body. This avoids two failure modes:

1. **Schema fight:** gnokee's `LabRecordRow` has a different field surface
   than FHIR `Observation`. Trying to map FHIR → gnokee losslessly is
   error-prone; rendering to a canonical episode body and letting the parser
   re-infer is more robust.
2. **Dual write divergence:** If gnokee is the only structured store,
   gnokee schema changes require a migration of the consumer's canonical
   data. Two-layer split means gnokee schema changes require only a new
   render + re-ingest.

### Re-ingest on render change

When the episode body renderer changes (e.g. the lab bullet format is
updated), re-ingest affected episodes with the same `our_id`. The
idempotency check prevents duplicate Graphiti episodes; the new content
triggers a fresh parser run and updated `lab_record` rows if a `corrects:`
supersession is supplied.

```python
receipt = await gnokee.ingest_episode(
    pipeline=pipeline,
    tenant_id=tenant_id,
    content=new_rendered_body,
    valid_at=original_valid_at,
    our_id=original_our_id,
    corrects=original_episode_uuid,  # supersede the old rows
)
```

---

## 5. Boundary invariants (must not violate)

These are enforced at the gnokee ingest boundary and will return a
`ValidationError` if violated:

| Invariant | Rule |
|---|---|
| `tenant_id` mandatory | Empty string rejected. `"default"` is a valid single-user value, not a fallback. |
| `content` required | `encrypted_body` deferred to v0.3+; `content` must be set. |
| `valid_at` tz-aware UTC | Naive datetimes rejected hard. Use `datetime(…, tzinfo=timezone.utc)`. |
| `valid_at` is world-time | Pass the time the fact was true in the world, NOT `datetime.now()`. |
| `our_id` non-empty when set | Empty string or whitespace-only rejected. |

All ingest calls must supply `valid_at` as the UTC timestamp of when the
fact was true in the world — this is gnokee's `reference_time` for
Graphiti and the bi-temporal valid-time axis. Passing `datetime.now()` as
`valid_at` is the most common consumer bug; it corrupts the bi-temporal
record silently.
