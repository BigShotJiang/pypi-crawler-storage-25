# ADR-0020: Obsidian vault adapter — vault-as-source ingest path

- **Status:** Accepted — verdict `SHIP_ADAPTER` (Q14 spike, 2026-05-11;
  see § Spike verdict). v0.5+ ships a first-party
  `consumers/gnokee-obsidian/` package that walks an Obsidian vault and
  ingests each `.md` note as one `EpisodeIn`. The vault remains the
  user's source of truth; gnokee never writes back.
- **Date:** 2026-05-11
- **Decider:** Vadim Yuzi
- **Context:** Adapter sketched at
  `examples/06_obsidian_vault_ingest.py` (this PR). Spike at
  `evals/spike_q14_obsidian/` (this PR). Promotion to a standalone
  `consumers/gnokee-obsidian/` package tracked as a follow-up issue.

## Context

gnokee's v0.1–v0.4 ingest surface assumes consumers hand `EpisodeIn`
objects programmatically. The first natural "personal data" source for
many users is an Obsidian vault — a folder of frontmatter-tagged
markdown notes. Two paths were considered:

1. **Vault-as-source** (this ADR). Walk the vault; map each `.md` note
   to one `EpisodeIn`. Frontmatter drives `valid_at` / `asserted_at` /
   `our_id` / `corrects` / `sensitive` / `language` / tags →
   `entity_type_hints`. mtime sidecar (`.gnokee_sync.json` at vault
   root) gates re-walks. gnokee owns retrieval; the vault owns
   editing.
2. **Vault-as-store.** Replace pgvector + Graphiti with markdown
   files as the backing store. Kills bi-temporal retrieval,
   supersession edges, vector search, RLS, and the Q3-validated
   response shape. Rejected without spike.

Path 1 is a thin adapter. Path 2 would gut v0.1–v0.4. The interesting
question for path 1 is whether the indirection through markdown +
frontmatter loses recall signal compared to direct `ingest_episode()`
calls with the same content and timestamps.

## What the Q14 spike measured

`evals/spike_q14_obsidian/` runs a two-arm A/B harness over 12 matched
episodes:

- **A-arm** (`group_id=q14_obsidian_a_direct`): direct
  `ingest_episode(EpisodeIn(...))` calls from `corpus/episodes.jsonl`.
- **B-arm** (`group_id=q14_obsidian_b_vault`): identical content as
  `corpus/vault/*.md` notes with frontmatter, walked via the adapter's
  `_build_episode()` helper.

10 query probes: 2 controls, 1 `as_of` (valid-time axis), 1 supersession
(corrects link e07 → e08), 2 tag-hint, 4 plain semantic. Each probe
runs against both group_ids; harness compares top-K episode_uuid
ordering, fact text, and bi-temporal supersession behaviour.

Decision criterion (re-derived after a one-line decision-logic patch in
this PR — original threshold compared `>= 9` against `len(scored)=8`,
which was unsatisfiable; corrected to `len(results)` per the brief):

- `SHIP_ADAPTER` — A/B within 1 rank-correction on ≥9/10 probes AND no
  axis-confusion.
- `PATCH_ADAPTER` — parity fine, but a specific frontmatter field
  (e.g. tags-as-hints) measurably hurts ranking; name the field.
- `REWORK_ADAPTER` — ≥2 probes diverge, OR any axis-confusion fires.

## Spike verdict

**`SHIP_ADAPTER`** (`results/20260511T184004Z.json`, 2026-05-11):

- 10/10 arm-A pass.
- 10/10 arm-B pass.
- **0 divergences.** Every ranked top-K list byte-identical between
  arms.
- **0 axis-confusion.** `as_of=2024-03-15` correctly surfaced the
  February-2024 LDL panel from both arms with the same ordering.
- Supersession chain e07 → e08 (`corrects:` link) resolved
  identically; head=e08 in both arms.
- Tags → `entity_type_hints` bias did not reorder rankings on the two
  tag-hint probes (`q14_tag_nix`, `q14_tag_preference_coffee`).

The adapter neither helps nor hurts recall on this corpus; it is a
faithful pass-through over the `EpisodeIn` contract.

## Consequences

### Adopted

1. **Adapter graduates from `examples/` to `consumers/gnokee-obsidian/`**
   as a standalone package with its own `pyproject.toml`, a
   `python-frontmatter` dependency (replaces the tiny YAML-subset
   parser inlined in the sketch), and a `gnokee-obsidian sync` CLI.
   Tracked in a follow-up issue filed alongside this PR.
2. **Vault remains source of truth.** gnokee never writes to `.md`
   files. The mtime sidecar (`.gnokee_sync.json`) is the only file
   the adapter creates in the vault root.
3. **`our_id` is mandatory.** Frontmatter `id:` is preferred; the
   path-hash fallback (`vault-path:<sha1>`) only fires when `id:` is
   missing, and is documented as unstable across moves / renames.
   This dodges the Q1 Graphiti dup-on-same-name trap by giving every
   episode a stable consumer-side key.
4. **`corrects:` is caller-asserted only** (matches v0.2.1
   supersession contract). The adapter accepts a frontmatter UUID;
   no heuristic detection across notes.
5. **Tags → `entity_type_hints` is a bias hint, not an authority.**
   Q14 shows it neither helps nor hurts rankings. Kept for now; can
   be re-evaluated if Graphiti's extractor changes.

### Deferred

- **Markdown → plaintext conversion.** Bodies go in as-is. Consumers
  who want cleaner prose can pre-strip markdown before invoking the
  adapter.
- **Wikilink graph resolution.** Out of scope — Graphiti owns entity
  extraction from prose; vault structure does not become graph
  structure.
- **Heading-split mode.** One `.md` note → one Episode. Splitting on
  `## section` is a future option if a corpus calls for it.
- **Encrypted-vault path.** Add an `encrypted_body` branch when a
  consumer's vault holds secrets (pattern lives in
  `examples/04_encrypted_body.py`).
- **`--watch` / live-sync mode.** v1 ships a one-shot `sync` CLI
  gated by the mtime sidecar; fsnotify integration is a v2 nicety.

### Not adopted

- **Vault-as-store** (path 2 above). Permanent. Rejecting bi-temporal
  retrieval, supersession edges, vector search, and RLS is not a
  trade gnokee is willing to make for a flatter on-disk format.

## Open questions surfaced by this work

- **Q14.1: spike harness threshold semantics.** The decision-logic
  bug fixed in this PR (`>= 9` against `len(scored)` vs
  `len(results)`) likely repeats in the Q1–Q13 templates. Worth a
  sweep across the spike harnesses to make sure no other verdict
  silently misfired. Filed as a follow-up issue.
- **Q14.2: markdown → plaintext quality.** Q14 ingested raw markdown
  bodies. If users have heavy formatting (callouts, embedded code,
  link soup), the embed lane may suffer in ways this 12-episode
  corpus did not exercise. A "vault hygiene" eval over a real user's
  vault would be the next falsification target.
