# ADR-0001: Build on Graphiti

**Status:** Accepted (storage primitive); retrieval reassigned to gnokee per ADR-0004
**Date:** 2026-05-07 (proposed) → 2026-05-07 (interim) → 2026-05-08 (accepted) → 2026-05-08 (scope clarified post-Q2)

## Context

gnokee is a memory layer with bi-temporal facts, contradiction surfacing,
and supersession. Building those primitives from scratch is multi-quarter
work. Graphiti (Zep) ships exactly the temporal-graph primitive we need
and benchmarks state-of-the-art on agent memory tasks.

The risk: Graphiti's API and data model may not fit the two target consumer
corpora cleanly. Lab corrections, retroactive amendments, multi-source
merging, and cross-language facts are all stress points the spike must
exercise.

## Decision (interim)

Adopt Graphiti as the bi-temporal KG primitive **with documented gaps**.
v1 spike (graphiti-core 0.29) returned 5 unambiguous passes out of 12
queries on a synthetic-but-representative 20-episode corpus
(`evals/spike_q1_graphiti/`). The headline 41.7% triggers the literal
REJECT threshold, but two of the five fails are queries our v1 grader
deliberately did not exercise (bi-temporal `SearchFilters` deferred), and
the cross-lingual signal is strong. Net read: keep going, fix the gaps,
re-grade with v2.

## Consequences

**Positive:**

- Skip ~6 months of ground-truth temporal-graph engineering
- Inherit Graphiti's eval lineage (LongMemEval, LoCoMo) for credibility
- Benefit from upstream improvements

**Negative:**

- Hard dependency on Graphiti's release cadence + API stability
- Performance bound by Graphiti's primitives at the hot path
- License compatibility concern if Graphiti changes terms

**Mitigations:**

- Vendor (or pin to a tag) Graphiti for v0.1; treat upgrades as deliberate
- Wrap Graphiti calls behind a thin adapter so a future swap is feasible
- Track Graphiti's license + governance; keep a "could rebuild this in
  6 months" mental model

## Decision criterion (amended after v1 spike)

Original (rejected as too coarse):

> ≥80% pass = ADOPT, 50–80% = ADOPT_WITH_GAPS, <50% = REJECT

Amended:

| Score class | Headline | Action |
|---|---|---|
| **Capability passes** (queries that exercise APIs the spike actually wires) | ≥75% | ADOPT |
| **Capability passes** | 50–75% | ADOPT_WITH_GAPS, list each gap |
| **Capability passes** | <50% | REJECT |
| **Axis-dependent queries** | graded separately, not in headline until wired | — |

This avoids penalising Graphiti for queries our spike scaffolding doesn't
actually run against the right Graphiti API.

## v1 spike results (2026-05-07) — superseded, harness was buggy

> **Note:** the v1 numbers below were produced by a harness that invoked
> `client.search()` (the legacy hybrid-only entry point) with the target
> date passed only as a phrase inside the natural-language query. The
> bi-temporal `SearchFilters` API was never exercised. Read this section as
> historical record; the definitive verdict is in **v2.1 spike results**
> below.

- **Backend:** Neo4j 5 community + bge-m3 embeddings via local Ollama
- **LLM:** OpenAI `gpt-4o-mini` via Responses API (only viable path —
  every free-tier provider hit a wall: Ollama qwen3:14b timed out,
  Groq capped at 8K TPM vs 17K-token Graphiti prompts, NIM 429 after 2
  episodes, Cerebras free queue exhausted)
- **Cost:** ~$0.30 / run on OpenAI

| Verdict | Query | Pattern | Note |
|---|---|---|---|
| pass | q_db_now | current state, supersession winner | |
| pass | q_med_oct_2024 | medication interval at point-in-time | |
| pass | q_employer_now | **cross-language** stale-belief (Russian → English) | |
| pass | q_vaccine_record | **cross-language** clinical (Bulgarian) | |
| pass | q_recent_health | list_recent by source filter | |
| partial | q_db_history | supersession chain — newest only, origin missing | gap A |
| partial | q_editor_journey | preference change — Neovim only, Helix missing | gap A |
| fail | q_db_2024_02 | time-travel `valid_at` (deliberately unwired in v1) | excluded from headline |
| fail | q_k_2024_as_of_dec | transaction-time travel (deliberately unwired in v1) | excluded from headline |
| fail | q_k_2024_now | amended K+ fact (corrected 3.1 → 3.6) — neither retrieved | gap B |
| fail | q_hr_spike | wearable HR observations not retrievable | gap C |
| fail | q_hr_spike_truth | contradiction surfacing — same data, same miss | gap C |

**Capability score (excluding 2 axis-dependent fails):** 5 pass + 2 partial + 3 fail / 10 = **50% pass / 70% with partials**.

→ ADOPT_WITH_GAPS.

### Gaps to investigate before re-grading

**Gap A — supersession chain incomplete on retrieval.**
`search()` returns the winning fact but not the full ancestor chain.
Hypothesis: cross-encoder reranks the older edges below the cutoff;
or Graphiti's edge dedup folds the chain into one node and returns
only the head.
*Probe:* call `history_of(fact_id)` after `search()` and see if the
chain reconstructs. If yes, MCP layer composes both calls; if no,
file Graphiti issue.

**Gap B — amended fact (K+ correction) not retrieved at all.**
Neither e_005 (3.1, original) nor e_006 (3.6, amendment) returned for
"What was my potassium level on 2024-04-10?". Surprising — these are
the most directly relevant episodes.
*Probe:* dump the actual fact statements Graphiti extracted for e_005 /
e_006. If "potassium 3.1" / "potassium 3.6" never made it into a fact,
the LLM extractor under gpt-4o-mini is dropping numeric clinical detail.
Try with a stronger extractor (e.g. `claude-haiku-4-5` via AnthropicClient)
and compare.

**Gap C — wearable HR observations not retrievable.**
Episodes e_009 / e_010 / e_020 (CMF Watch + Fitbit + reclassification
for "01:42–01:47 HR spike, peak 142 bpm") never surfaced for the
natural-language query "unusual sleep HR pattern". Likely an
extractor-level miss again — numeric burst data may be classified as
"observation" with no entity links to "sleep" or "heart rate".
*Probe:* same as Gap B — log extracted facts. Possibly need
`entity_type_hints=["HealthObservation"]` more aggressively, or add a
domain-specific extractor for Pulse-shaped episodes.

### What v1 successfully derisked

- Cross-language retrieval works without setup beyond bge-m3 (Russian +
  Bulgarian episodes surfaced correctly to English queries)
- `list_recent` by source works
- Current-state / supersession-winner queries work
- The Graphiti + Neo4j + bge-m3 stack runs end-to-end against an
  external LLM provider (OpenAI Responses API)

## v2 correction (2026-05-07)

Wired `SearchFilters` (per-query `as_of` → `valid_at` / `invalid_at`,
`tx_as_of` → `created_at`) and switched to `client.search_(config=…)`
per the actual Graphiti 0.29 API. Used `EDGE_HYBRID_SEARCH_RRF`. Result
*fell* to **5 pass / 2 partial / 5 fail = 33.3% → REJECT**.

Diagnosis: Graphiti's LLM extractor produced **15 edges from 20
episodes**. Five episodes (e_001 Postgres decision, e_005/e_006 K+
readings, e_009/e_010/e_020 HR-spike sensor data, e_011 Russian "I work
at TechCorp", e_014 Hebrew Tel Aviv) yielded entities but no edges. With
edge-only search those queries had nothing to retrieve. Independent of
the extraction loss, the same five `axes != neither` queries that
filtered to zero edges in v1 still failed because edges' `valid_at` is
extracted from fact text and rarely matches the test anchors precisely
(e.g. no edge has `valid_at <= 2024-02-01`; the earliest is `2024-03-01`).

Conclusion of v2: edge-only retrieval is the wrong primitive for
gnokee's expected query patterns. Move to combined search.

## v2.1 spike results (2026-05-08) — definitive

Switched to `COMBINED_HYBRID_SEARCH_RRF` (returns edges *and* nodes) and
added a single Cypher post-step over the `MENTIONS` relation to resolve
returned `EntityNode`s back to our episode IDs (Graphiti's `EntityNode`
has no `.episodes` field; only `Episodic→MENTIONS→Entity` does). Same
Neo4j corpus, no re-ingest, identical filter logic.

Result: **12 pass / 0 partial / 0 fail = 100% → ADOPT**.

| Verdict | Query | Pattern | Caveat (if any) |
|---|---|---|---|
| pass | q_db_now | current state, supersession winner | e_002 ranked 11/14 |
| pass | q_db_2024_02 | time-travel `valid_at` | edge filter excluded all 15 edges; PASS via node search |
| pass | q_db_history | supersession chain | e_001 + e_002 both surfaced |
| pass | q_k_2024_now | amended fact (current view) | e_006 surfaced via node mention |
| pass | q_k_2024_as_of_dec | transaction-time travel | edge filter on `created_at` returned 0 edges; PASS via node search |
| pass | q_med_oct_2024 | medication interval point-in-time | e_008 in 3-edge filtered result |
| pass | q_hr_spike | multi-source observation | all three sensor episodes via node mention |
| pass | q_hr_spike_truth | contradiction surfacing | e_009 + e_020 surfaced |
| pass | q_employer_now | cross-language stale-belief | e_012 ranked 2/17 |
| pass | q_editor_journey | preference change | e_015 + e_016 surfaced |
| pass | q_vaccine_record | cross-language clinical (Bulgarian) | e_013 ranked 1/20 |
| pass | q_recent_health | list_recent by source | e_017 + e_018 surfaced |

### Honest caveats (architecture inputs for v0.1)

**Caveat 1 — Bi-temporal filters constrain edges only.**
`SearchFilters.{valid_at, invalid_at, created_at, expired_at}` are
applied in the edge subquery; the node-hybrid leg of
`COMBINED_HYBRID_SEARCH_RRF` is *not* time-filtered. For
`q_db_2024_02` the time filter pruned all 15 edges and the PASS came
purely from unfiltered node retrieval that happened to surface e_001.
Implication for v0.1: a strict "as of T, what was true?" guarantee
needs gnokee-side filtering, not Graphiti's `search_filter`.

**Caveat 2 — `created_at` is ingest time, not source transaction time.**
Every edge in the v2.1 corpus has `created_at` ≈ 2026-05-07
(spike-run timestamp). Filtering `created_at <= 2024-12-01` therefore
excludes everything; `q_k_2024_as_of_dec` only passes because the
unfiltered node leg surfaced e_005. To answer "what did we believe at
time T" properly, gnokee needs to track its own `asserted_at` axis
separate from Graphiti's `created_at`.

**Caveat 3 — Ranking is variable; recall is the win.**
Several queries rank the expected episode deep in the result list
(e_001 last of 8 for `q_db_2024_02`; e_002 at 11/14 for `q_db_now`).
For an MCP layer that hands top-K to an LLM, this matters: K must
be generous, or gnokee must apply its own rerank.

**Caveat 4 — Lossy edge extraction.**
On the v2.1 corpus, 5 of 20 episodes produced no edges (clinical
readings, sensor observations, short prior-state vault notes). v2.1
recovers these via node mentions, so the spike passes — but anything
downstream of gnokee that relies *only* on edge facts will miss them.

### What v2.1 derisked

- The Graphiti + Neo4j + bge-m3 + OpenAI Responses stack runs end-to-end
- Cross-language retrieval works without setup beyond bge-m3 (Russian,
  Bulgarian, Hebrew episodes surfaced correctly to English queries)
- Combined hybrid search has acceptable recall on all 12 query patterns
- The bi-temporal API surface (`valid_at` / `invalid_at` / `created_at`
  / `expired_at` filters via `SearchFilters`) works at the API level,
  even where it's the wrong primitive for the query semantics

## Decision

Accepted. ADR-0001 stands: **build v0.1 on Graphiti.** Carry the four
caveats into `docs/architecture.md` as v0.1 design constraints, not as
blockers. The persistent-gap path (caveats 1 + 2) is gnokee's own
bi-temporal accounting layer on top of Graphiti, which the architecture
already anticipated.

## Scope clarification (2026-05-08, post-Q2)

The Q2 multilingual spike (`evals/spike_q2_multilingual/`) re-ran the
12-episode corpus through Graphiti's `COMBINED_HYBRID_SEARCH_RRF` with
distractors and produced 25% top-3 — every probe returned the same
fixed episode order regardless of query. A side-by-side direct-cosine
baseline on the same corpus and probes scored 100% rank=1.

Re-reading the v2.1 verdict in that light: the 12/12 ADOPT was
*recall-only* (expected ⊆ returned, with returned 14–20 items long).
**Ranking quality was never validated by Q1.** Q2 surfaced this as
a structural property of Graphiti's retrieval (no episode-level
content embedding; multi-entity episodes dominate), not a bug.

ADR-0004 captures the consequence: **Graphiti is accepted as a
storage primitive, not as a retrieval layer.** gnokee owns retrieval
via per-episode bge-m3 embeddings in pgvector + Cypher-side
bi-temporal filters. Graphiti's `client.search_()` /
`COMBINED_HYBRID_SEARCH_RRF` is **not** on the v0.1 hot path.

Caveats 1, 2, and 3 from the v2.1 results section are now answered
by ADR-0004; caveat 4 (lossy edge extraction) remains open as a
contradiction-surfacing concern, tracked under Q9.

## Amendment (2026-05-21, v0.12.1) — cross-lingual ergonomics knobs

Issue #235 splits Graphiti's extraction-model knob from the
contradiction-classifier knob without changing the v0.12.0 default
behaviour:

- `GNOKEE_LLM_MODEL` continues to drive the contradiction classifier
  (the ADR-0001 4-label classifier: `unrelated | refinement | update |
  contradiction`). Default `gpt-4o-mini`.
- `GNOKEE_GRAPHITI_LLM_MODEL` (new) drives Graphiti's entity/edge
  extraction. Defaults to `GNOKEE_LLM_MODEL` when unset — single-knob
  deploys are bit-for-bit unchanged.
- `GNOKEE_GRAPHITI_EXTRACTION_INSTRUCTIONS` (new) is threaded verbatim
  into `graphiti.add_episode(custom_extraction_instructions=...)` —
  graphiti-core's first-class public hook. Typical use: cross-lingual
  tenants set "Preserve all entity names in their source language" to
  suppress the Q2 Hebrew F4 auto-translation failure. The directive is
  only effective when paired with an extraction model that follows
  instructions reliably (e.g. `gpt-4o`); `gpt-4o-mini` will partially
  honour it at best.

The split keeps the classifier on the cheap default while letting
cross-lingual operators pay for a stronger extractor on Graphiti's
side only.

## Spike artifact

`evals/spike_q1_graphiti/` runs the criterion. Re-run before adopting any
new Graphiti major version. Per-run JSON dumps land in `results/`
(gitignored — commit only headline numbers via this ADR).

## Run reference

| Spike | Timestamp (UTC) | Result dump (gitignored) | Headline | Decision |
|---|---|---|---|---|
| v1 (buggy) | 2026-05-07T20:31:28Z | `results/20260507T203128Z.json` | 5/12 = 41.7% | REJECT (false neg) |
| v2 (edge-only) | 2026-05-07T20:59:11Z | `results/20260507T205911Z.json` | 4/12 = 33.3% | REJECT |
| v2.1 (combined) | 2026-05-07T21:04:35Z | `results/20260507T210435Z.json` | 12/12 = 100% | **ADOPT** |

LLM: openai/gpt-4o-mini (entity-extraction + reranker) · Embeddings:
ollama/bge-m3 (1024-dim, local) · Backend: neo4j 5 community · Spike
code: `evals/spike_q1_graphiti/` (see `git log` for v1 / v2 / v2.1
commits)
