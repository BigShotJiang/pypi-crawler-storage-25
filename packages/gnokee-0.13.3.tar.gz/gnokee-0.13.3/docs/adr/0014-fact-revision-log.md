# ADR-0014: Fact-revision log — append-only `fact_revision` table + `gnokee_fact_history` MCP tool

- **Status:** Accepted
- **Date:** 2026-05-16
- **Driver:** Issue [#73](https://github.com/omurlabs/gnokee/issues/73) — fact-grain revision lineage
- **Supersedes:** none
- **Amends:** [ADR-0023](0023-gnokee-owns-episode-storage.md) (adds a second write-path artefact gnokee owns per ingest run); [ADR-0026](0026-forget-pipeline.md) (introduces a new FK-cascade target that the forget pipeline must sweep)
- **Refs:** [ADR-0001](0001-build-on-graphiti.md), [ADR-0004](0004-gnokee-owns-retrieval.md), [ADR-0006](0006-postgres-raw-sql-migrations.md), [ADR-0008](0008-contradiction-storage-pg-table.md), [ADR-0010](0010-meds-share-lab-record-shape.md), [ADR-0013](0013-gnokee-query-declarative-envelope.md), [ADR-0015](0015-wiki-export-llms-txt.md), [ADR-0024](0024-ingest-crash-recovery-journal.md), [ADR-0026](0026-forget-pipeline.md); Issues [#71](https://github.com/omurlabs/gnokee/issues/71), [#123](https://github.com/omurlabs/gnokee/issues/123), [#142](https://github.com/omurlabs/gnokee/issues/142)

gnokee shipped `gnokee_history_of` in v0.7 (issue #123) as an episode-grain supersession DAG: given an `episode_uuid`, it walks `episode_metadata.superseded_by` edges via recursive CTE and returns the correction chain. That surface answers *"was this episode overwritten?"* but cannot answer *"how has a specific extracted fact evolved across ingest runs?"* — a different grain, different query shape, different table.

This ADR ships the sibling surface. A new Postgres table `fact_revision` logs every accepted Graphiti edge as an immutable revision row. A new MCP tool `gnokee_fact_history` answers *"give me the revision history of fact F across all episodes that touched it."* Five deferred references in shipped code (`src/gnokee/mcp.py:964`, `src/gnokee/wiki_export.py:28,153`, `docs/adr/0015-wiki-export-llms-txt.md:93,156`) are un-deferred by this ADR. Two additional deferred references in `docs/adr/0013-gnokee-query-declarative-envelope.md:419,424` remain out of scope — they track `output_shape:fact` consumption, which is issue #142.

## Context

Graphiti produces `EntityEdge` objects for each accepted extraction: a directed triple `(source_node_uuid, predicate, target_node_uuid)` with a `uuid` (referred to here as `fact_uuid`) and a `fact` text string. gnokee passes these edges to Graphiti's `add_episode`, but until this ADR there is no gnokee-owned record of which edges came from which episode, what text they carried, or how they relate to prior edges extracted from the same logical fact.

This gap creates three concrete problems:

1. **Wiki `as_of` header (ADR-0015).** `wiki_export.py` generates an `as_of` timestamp for each exported fact. Without a fact-revision log, the only `as_of` candidate is the episode's `valid_at` — which is world-time of the *episode*, not world-time of the most recently extracted *edge*. The `as_of` header is a lie on any corpus where a fact has been revised across episodes. ADR-0015 marked this deferred at `docs/adr/0015-wiki-export-llms-txt.md:93` and `153`.

2. **`gnokee_fact_history` tool (issue #73).** Several downstream consumers (noggin, the wiki pipeline) want to ask: *"show me every version of this fact."* That query is impossible without a persistent fact-grain revision log — Graphiti does not expose edge history, and `EntityEdge.invalid_at` (when populated) only tells you the edge was superseded, not what superseded it.

3. **`output_shape:fact` consumers (ADR-0013, issue #142).** The declarative envelope ADR deferred a `fact` output shape pending this table existing. Once `fact_revision` lands, ADR-0013 consumers can request per-fact lineage alongside their query results.

The Google Cloud Memory Bank `MemoryRevision` object (GA 2026-04-22) ships an append-only revision log per fact with a 48-hour grace window. A-MEM (NeurIPS 2025) formalises bidirectional memory evolution — gnokee's `EpisodeIn.corrects:` field is the structural analogue. gnokee's design follows the append-only invariant but rejects the grace-window and tombstone patterns (the append-only invariant: gnokee never soft-deletes fact rows; closure timestamp lives on `EntityEdge.invalid_at`, not on a tombstone row).

## Decision

**gnokee introduces an append-only `fact_revision` table populated at Stage 6c (after Graphiti `add_episode`, before contradiction detection). Each accepted `EntityEdge` produces one INSERT. A new `fact_id` column provides logical identity across revisions: it equals `fact_uuid` by default and is inherited from the prior revision when `EpisodeIn.corrects:` fires and a matching triple is found in the prior episode's edge set. A new MCP tool `gnokee_fact_history` reads the revision chain for a given `fact_id` or `fact_uuid`.**

### Decision 1: `fact_id` identity — hybrid passthrough + corrects-path inheritance (Option C)

`fact_id` is a stable UUID that tracks one logical fact across all its revisions. Three options were evaluated:

**Option A — `fact_id == fact_uuid` forever.** Every Graphiti edge gets its own `fact_id` equal to its `fact_uuid`. No inheritance. Simple, zero write-time risk.

**Option B — `fact_id == uuid5(source_node_uuid ‖ predicate ‖ target_node_uuid)`.** Cross-session clustering by triple content. Implicit: any two edges with the same (subject, predicate, object) cluster under one `fact_id` automatically, even without `corrects:` being set.

**Option C (chosen) — hybrid passthrough + explicit-corrects inheritance.** Default: `fact_id = fact_uuid` (passthrough, same as Option A). When `EpisodeIn.corrects:` is set on the new episode, Stage 6c fetches the prior episode's edges, builds a triple-map `(source_node_uuid, predicate, target_node_uuid) → prior fact_id`, and for each new edge: inherits `prior fact_id` if the triple matches, mints a fresh `fact_id` (= `fact_uuid`) when it does not.

**Why Option C, not A:** Option A makes `gnokee_fact_history` nearly useless for any corpus using `EpisodeIn.corrects:`. The wiki `as_of` header problem remains unsolvable without lineage threading. Option C degrades to Option A on any corpus that never uses `corrects:` — zero downside vs A on day-1 corpora.

**Why Option C, not B:** Option B ties `fact_id` to LLM-extracted predicate strings. Predicates are prompt-version-dependent: when the extraction prompt changes, the same real-world relation surfaces with a different predicate string, silently minting a new `fact_id` cluster and orphaning the old lineage thread. Option B also clusters across episodes without explicit caller intent, violating AGENTS.md's "no auto-resolve" principle. gnokee should not infer that two separately extracted edges describe the same logical fact without a human-readable signal in the ingest call.

**`prior_revision_id` column:** When `fact_id` is inherited, Stage 6c writes the `revision_id` of the most recent prior `fact_revision` row for that `fact_id` into the new row's `prior_revision_id`. This creates a linked-list chain navigable without a recursive CTE. When `fact_id` is not inherited (passthrough), `prior_revision_id` is NULL.

### Decision 2: write placement — Stage 6c, fail-soft (Option B)

**Option A — inside the Graphiti `add_episode` call.** Write `fact_revision` rows inside the same transaction that writes Graphiti edges. Would require gnokee to intercept Graphiti's internal edge-commit path.

**Option B (chosen) — Stage 6c, after Stage 6 returns, fail-soft with telemetry skew counter.** A new Stage 6c block runs after Stage 6 (`graphiti.add_episode`) and after Stage 6b (restore-original-body), before Stage 7 (contradiction detection). Stage 6c reads `created_fact_uuids` (already populated by Stage 6's return), iterates the new edges, and issues one INSERT per edge. Stage 6c failure does not abort the ingest run; it increments the new telemetry counter `IngestTelemetry.fact_revision_skew_count` and proceeds.

**Why Option B, not A:** Graphiti's `add_episode` is opaque — gnokee receives no progress events and cannot intercept mid-write. Wrapping `fact_revision` inserts inside a try block after `add_episode` returns IS Option B by construction. Stage 7 already reads `created_fact_uuids` after Stage 6 returns; Stage 6c slots in symmetrically between Stage 6b and Stage 7 without disturbing the existing stage sequence.

**Fail-hard (raising on Stage 6c errors) is strictly worse:** Graphiti `add_episode` is non-transactional with Postgres, so by the time Stage 6c runs the edges are already durable in Neo4j — failing the ingest would leave Stage 5's Postgres row absent but the Graphiti edges live, a worse skew than the inverse. Fail-soft + telemetry keeps the invariant "Postgres row exists ⇒ Stage 5 committed" and surfaces the recoverable gap.

**Skew window:** If Stage 6c fails, the Graphiti edge exists without a corresponding `fact_revision` row. This skew is detectable via `IngestTelemetry.fact_revision_skew_count`. Backfill tooling (scan edges lacking `fact_revision` rows, INSERT missing rows) is a follow-up issue deferred to v0.9.x. `gnokee_fact_history` returns an empty revision array for any `fact_uuid` not yet in `fact_revision` — documented as expected behaviour, not an error.

### Decision 3: supersession-row policy — new rows only, no closure markers (Option A)

When `EpisodeIn.corrects:` fires and Stage 6 produces fresh `EntityEdge` objects (with Graphiti potentially invalidating prior edges via `invalid_at`), Stage 6c writes `fact_revision` rows for the **new** edges only. It does not write closure-marker rows for the prior revision.

**Option A (chosen) — new rows only.** The closure timestamp for any revision is obtained at read time by joining `fact_revision.fact_uuid → EntityEdge.invalid_at`. `gnokee_fact_history` performs this join when constructing the revision list.

**Option B — new rows + closure-marker rows for superseded revisions.** Write two rows per superseded revision at write time: one for the new edge, one marking the prior revision closed.

**Why Option A, not B:** Append-only means *never UPDATE or DELETE existing rows* — it does not mean *write more rows on closure*. Option B would produce 2N rows for N supersessions with no new `fact_text` content, doubling storage, duplicating text, and creating a forget-cascade headache (closure-marker rows must also be DELETEd when their episode is forgotten, but their `episode_uuid` FK points to the *new* episode, not the closed one). Memory Bank uses empty-fact tombstones for this pattern; gnokee explicitly rejects tombstones (ADR-0010).

### Schema

```sql
-- Migration 0019: 0019_fact_revision.sql

CREATE TABLE fact_revision (
    revision_id        UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    fact_id            UUID        NOT NULL,
    fact_uuid          UUID        NOT NULL,        -- Graphiti EntityEdge.uuid
    tenant_id          TEXT        NOT NULL,
    episode_uuid       UUID        NOT NULL,
    valid_at           TIMESTAMPTZ NOT NULL,        -- world-time of this revision (from EpisodeIn.valid_at)
    asserted_at        TIMESTAMPTZ NOT NULL,        -- transaction-time of originating episode
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    fact_text          TEXT        NOT NULL CHECK (length(fact_text) > 0),
    source_node_uuid   UUID        NOT NULL,
    predicate          TEXT        NOT NULL,
    target_node_uuid   UUID        NOT NULL,
    prior_revision_id  UUID        REFERENCES fact_revision(revision_id) ON DELETE SET NULL,
    FOREIGN KEY (episode_uuid)
        REFERENCES episode_metadata (episode_uuid) ON DELETE CASCADE
);

-- Lookup by logical fact_id (primary read path for gnokee_fact_history)
CREATE INDEX fact_revision_fact_id_idx
    ON fact_revision (fact_id, valid_at DESC);

-- Lookup by Graphiti edge uuid (for Stage 6c skew detection + backfill)
CREATE UNIQUE INDEX fact_revision_fact_uuid_idx
    ON fact_revision (fact_uuid);

-- Tenant sweep (for gnokee_forget_tenant, RLS enforcement)
CREATE INDEX fact_revision_tenant_idx
    ON fact_revision (tenant_id);
```

The FK is `episode_uuid`-only (not `(tenant_id, episode_uuid)`) pending confirmation of `episode_metadata`'s PK shape in the migration task; the migration may upgrade to the composite form if the PK supports it.

`prior_revision_id` uses `ON DELETE SET NULL` rather than `CASCADE` so forgetting a prior revision breaks the chain at the deleted link without cascade-deleting every later revision that referenced it — later revisions survive as standalone history rows.

### MCP tool: `gnokee_fact_history`

```
gnokee_fact_history(
    tenant_id,
    fact_id,                     -- logical UUID (fact_revision.fact_id)
    *,
    fact_uuid=None,              -- Graphiti edge UUID; pipeline resolves to fact_id
    as_of=None,                  -- TIMESTAMPTZ; filters to revisions with valid_at <= as_of
    include_superseded=True,
    max_revisions=64
) -> {
    fact_id: UUID,
    revisions: [
        {
            revision_id: UUID,
            fact_uuid: UUID,
            episode_uuid: UUID,
            valid_at: datetime,
            asserted_at: datetime,
            fact_text: str,
            source_node_uuid: UUID,
            predicate: str,
            target_node_uuid: UUID,
            superseded_at: datetime | None,   -- EntityEdge.invalid_at, joined at read time
            prior_revision_id: UUID | None
        },
        ...
    ],
    truncated: bool,
    truncation_note: str | None
}
```

Accepts either `fact_id` (logical, stable across revisions) or `fact_uuid` (Graphiti edge UUID for a specific extraction). When `fact_uuid` is provided without `fact_id`, the pipeline resolves `fact_id` via `SELECT fact_id FROM fact_revision WHERE fact_uuid = $1`. Revisions are ordered `asserted_at DESC` (system-learned-most-recently first; this is the bi-temporal transaction-time axis, NOT world-time). `max_revisions` caps the result set; `truncated=True` when more rows exist than the cap. `include_superseded=False` filters to revisions whose `EntityEdge.invalid_at` is NULL (live edges only).

The tool is exposed in `src/gnokee/mcp.py` alongside `gnokee_history_of`. The Python API mirrors at `gnokee.fact_revision.fact_history(app, tenant_id, fact_id, ...)`.

### Un-deferred references

This ADR un-defers five deferred references in shipped code:

- `src/gnokee/mcp.py:964` — stub comment pointing to this ADR; replaced by real `gnokee_fact_history` registration.
- `src/gnokee/wiki_export.py:28` — `as_of` header derivation; now reads `MAX(fact_revision.valid_at)` per fact rather than episode `valid_at`.
- `src/gnokee/wiki_export.py:153` — same wiki export path, per-fact `as_of` assignment.
- `docs/adr/0015-wiki-export-llms-txt.md:93` — the deferred note is struck; `fact_revision` is the source of truth for wiki `as_of`.
- `docs/adr/0015-wiki-export-llms-txt.md:156` — same.

Two references in `docs/adr/0013-gnokee-query-declarative-envelope.md:419,424` are **not** un-deferred by this ADR — they track `output_shape:fact` consumption, which is issue #142, a separate PR.

### Module layout

```
src/gnokee/fact_revision/__init__.py      # public API: fact_history, write_fact_revisions
src/gnokee/fact_revision/models.py        # FactRevision, FactHistoryOut, FactRevisionIn
src/gnokee/fact_revision/store.py         # FactRevisionStore — INSERT + read path
src/gnokee/fact_revision/resolution.py   # fact_id resolution: passthrough vs corrects-path inheritance
src/gnokee/ingest.py                      # Stage 6c block added (after Stage 6b, before Stage 7)
src/gnokee/mcp.py                         # gnokee_fact_history tool registration (un-defers :964)
src/gnokee/wiki_export.py                 # as_of header updated to use fact_revision (un-defers :28, :153)
migrations/0019_fact_revision.sql         # table + indexes
```

## Consequences

### Positive

- **`gnokee_fact_history` closes issue #73.** Fact-grain revision lineage is queryable for any corpus using `EpisodeIn.corrects:`. Consumers no longer need to reconstruct fact evolution from episode-grain supersession edges.
- **Wiki `as_of` header un-deferred (ADR-0015).** `wiki_export.py` can now report a per-fact `as_of` timestamp derived from `MAX(fact_revision.valid_at)` — accurate to the most recent extraction, not merely the originating episode.
- **Append-only invariant held.** `fact_revision` is never UPDATEd or DELETEd by the ingest path; the only DELETE path is the forget cascade (ADR-0026 FK ON DELETE CASCADE).
- **Forget cascade automatic.** `fact_revision.episode_uuid` carries a FK to `episode_metadata(episode_uuid) ON DELETE CASCADE`. When `gnokee_forget_episode` or `gnokee_forget_tenant` sweeps `episode_metadata`, all `fact_revision` rows for those episodes are removed without requiring a manual sweep step. This keeps ADR-0026's sweep-order invariant intact.
- **Sibling surface to `gnokee_history_of` is coherent.** Episode-grain (`gnokee_history_of`) and fact-grain (`gnokee_fact_history`) coexist as orthogonal views over the same ingest history — neither subsumes the other.

### Negative — accepted

- **1 INSERT per accepted Graphiti edge at Stage 6c.** p95 latency budget is ≤10ms per INSERT (soft gate in v0.9; strict A/B harness deferred to v0.9.x as a follow-up issue). On high-edge-count episodes this compounds. Batching all edge INSERTs into a single `executemany` call within Stage 6c is the implementation strategy.
- **Skew window.** Stage 6c failure leaves Graphiti edges without corresponding `fact_revision` rows. The window is surfaced via `IngestTelemetry.fact_revision_skew_count`. Backfill tooling (scan `EntityEdge` by episode, INSERT missing rows) is deferred to v0.9.x.
- **No backfill for pre-migration corpus.** `fact_revision` rows do not exist for edges extracted before migration 0019 lands. `gnokee_fact_history` returns an empty `revisions` array for pre-migration `fact_uuid` values. This is documented as expected behaviour, not an error. Backfill of the pre-migration corpus is explicitly out of scope.
- **`prior_revision_id` chain is best-effort.** The `prior_revision_id` linked-list is populated only when `EpisodeIn.corrects:` fires AND a matching triple is found in the prior episode's edge set. Two independently ingested episodes describing the same fact — without an explicit `corrects:` link — do not cluster under one `fact_id`. This is intentional (Option C vs B rationale above) but means lineage is incomplete for corpora that were ingested without explicit correction signals.
- **`EntityEdge.invalid_at` join at read time.** The supersession timestamp is not stored in `fact_revision`; it is joined from Graphiti's edge storage on each `gnokee_fact_history` call. If Graphiti's edge storage is unavailable, the read path falls back to `superseded_at: null` rather than failing. This is a soft dependency.

## Alternatives considered

### Alternative: store revision history inside Graphiti / Neo4j only

Graphiti stores `EntityEdge.invalid_at` on superseded edges. A consumer could reconstruct fact history by querying Neo4j directly via Cypher. **Rejected:** ADR-0004 establishes that gnokee owns retrieval; consumers should not need raw Cypher access. Graphiti also does not expose edge history as a stable API surface — `invalid_at` is a property gnokee reads, not a Graphiti-managed version chain. Relying on it exclusively couples `gnokee_fact_history` to Graphiti internals that can change under a minor version bump.

### Alternative: embed revision log in `episode_metadata` as JSONB column

Store `created_fact_uuids` + `fact_texts` as a JSONB blob on `episode_metadata`. Simple, no new table. **Rejected:** JSONB blob makes cross-episode fact-ID threading impossible — there is no row-level key to join on when tracing a fact across episodes. Querying "all episodes that touched fact F" requires a full table scan + JSONB containment check. The JSONB approach also cannot represent `prior_revision_id` (the linked-list chain) without embedding nested objects, which collapses into an unindexable structure.

### Alternative: use `fact_contradiction` table (ADR-0008) as the revision store

`fact_contradiction` already holds `fact_uuid_a`, `fact_uuid_b`, and contradiction text. **Rejected:** `fact_contradiction` stores *pair-wise semantic conflicts*, not ordered revision chains. It is populated by Stage 7 (contradiction detection), which runs *after* Stage 6c. Using it as the revision log would conflate two orthogonal concepts — lineage and conflict — and break Stage 7's assumption that it is the first gnokee code to assess semantic relationships between edges.

## Cross-refs

- [ADR-0001](0001-build-on-graphiti.md) — build on Graphiti; `EntityEdge.uuid` is the `fact_uuid` passthrough into `fact_revision`.
- [ADR-0004](0004-gnokee-owns-retrieval.md) — gnokee owns retrieval; `gnokee_fact_history` is the fact-grain retrieval surface, not a Cypher passthrough.
- [ADR-0006](0006-postgres-raw-sql-migrations.md) — raw SQL migrations; migration 0019 follows the established naming and placement convention.
- [ADR-0008](0008-contradiction-storage-pg-table.md) — contradiction storage; `fact_contradiction` and `fact_revision` coexist as distinct tables with distinct responsibilities.
- [ADR-0010](0010-meds-share-lab-record-shape.md) — meds supersession adopt-with-gaps; same append-only posture as `fact_revision`.
- [ADR-0013](0013-gnokee-query-declarative-envelope.md) — declarative envelope; `output_shape:fact` consumption depends on this ADR but is implemented separately in issue #142.
- [ADR-0015](0015-wiki-export-llms-txt.md) — wiki export; `as_of` header un-deferred by this ADR.
- [ADR-0024](0024-ingest-crash-recovery-journal.md) — ingest crash-recovery journal; Stage 6c runs within the same ingest pipeline that ADR-0024's journal wraps; a Stage 6c failure increments the skew counter rather than triggering journal-based replay (the journal boundary is Stage 4–Stage 5; Stage 6c skew has its own backfill path).
- [ADR-0026](0026-forget-pipeline.md) — forget pipeline; `fact_revision` FK ON DELETE CASCADE integrates automatically with the ADR-0026 sweep; no explicit `DELETE FROM fact_revision` needed in the forget pipeline's sweep-order list.
- Issue [#71](https://github.com/omurlabs/gnokee/issues/71) — umbrella competitive-landscape; Google Cloud Memory Bank `MemoryRevision` and A-MEM are the prior art references for this ADR.
- Issue [#73](https://github.com/omurlabs/gnokee/issues/73) — this issue; ADR driver.
- Issue [#123](https://github.com/omurlabs/gnokee/issues/123) — `gnokee_history_of` (episode-grain sibling surface, v0.7).
- Issue [#142](https://github.com/omurlabs/gnokee/issues/142) — `output_shape:fact` consumer; depends on this ADR, implemented in a separate PR.
