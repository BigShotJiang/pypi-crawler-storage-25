# ADR-0011: Wearable streams are batched or off-ramped; raw per-sample never goes through `add_episode`

- **Status:** Accepted
- **Date:** 2026-05-09
- **Decider:** Vadim Yuzi
- **Context:** Q9 spike — `evals/spike_q9_wearable_throughput/`. Closes
  the third Omur clinical-shape question alongside Q7 (labs) and Q8
  (meds). Where Q7 / Q8 are *summarisation-quality* problems, Q9 is
  the *cost-and-throughput* problem.

## Context

ADR-0001 adopted graphiti for both target consumers, with the unstated
implication that *all* clinical streams flow through
`gnokee.ingest_episode → graphiti.add_episode`. Q1 only validated that
on engineering / personal-AI notes. Q9 measures whether that
implication survives wearable rates.

## Result

Measured per-episode cost on the v0.1.1 stack against three corpus
shapes (n = 20 total):

| Shape | avg LLM calls/ep | avg latency | cost / ep | volume / metric / yr | $ / user / yr (5 metrics) |
|---|---|---|---|---|---|
| Raw 1/min sample | 2.12 | 5.63 s | $0.00043 | 525,000 | **$1,115.63** |
| Hourly summary | 2.00 | 4.99 s | $0.0004 | 8,760 | **$17.52** |
| Daily summary | 2.62 | 5.88 s | $0.00053 | 365 | **$0.96** |

Cost is `gpt-4o-mini` at the conservative midpoint $0.0002 per LLM
call (graphiti makes ~2–3 LLM calls per episode for
extraction + entity-dedup). Latency is wall-clock against the
v0.1.1 compose stack; the cost figure matters more here because the
projection ceiling is dominated by token spend, not request rate.

Headline verdict per the spike's `<$5 / $5–$50 / >$50` thresholds:
**BATCH_AND_SUMMARISE**.

But the raw stream is unambiguously **HARD_OFF_RAMP** territory on its
own ($1.1k / user / year for 5 metrics is a non-starter for a
$10–$30 / month consumer SaaS), and the latency arithmetic is just as
damning: 5.6 s per `add_episode` against a 1 Hz workout HR feed
(60 samples / minute) means each minute of wearable wall time generates
5.6 × 60 = 336 seconds of ingest work — a 5.6× lag that compounds
linearly while the user's watch keeps streaming.

## Decision

**The raw per-sample wearable stream never enters
`gnokee.ingest_episode`. Period.** This is a hard architectural
boundary, not a guideline.

Two layers, picked per use case:

### 1. Edge / consumer-side time-series store (load-bearing default)

Raw wearable samples (1 Hz / 1 minute) land in a dedicated
time-series store at the consumer (Omur). v0.2 Omur ships with
TimescaleDB (Postgres extension; same operational footprint as the
existing `gnokee-postgres` container — adds a hypertable, not a new
database family) for metric streams and aggregations
(`AVG / PERCENTILE_CONT`, `time_bucket`, retention policies).

The consumer queries TimescaleDB directly for "average HR last 30
days" / "sleep score yesterday" / "steps this week" / "time-in-range
for glucose". gnokee is **not** the path. This is the same pattern
ADR-0009 / ADR-0010 commit for typed clinical reads (`lab_record`,
`med_record` Postgres tables): typed structured data lives next to,
not inside, the graphiti graph.

### 2. Synthesised summary + anomaly facts (when gnokee adds value)

A periodic daemon — same daemon-shape that #8 punted to v0.2.x —
emits **daily / weekly summary episodes** and **anomaly events**
into gnokee:

- *Daily summary* — "Resting HR 58 bpm 2024-08-15; sleep score 84;
  HRV 42 ms." One episode per metric per day = 365 / metric / yr;
  Q9 measured this at **$0.96 / user / yr**, easily affordable.
- *Anomaly* — "Resting HR jumped 12 % between 2024-03-01 and
  2024-03-15 (mean 58 → 65 bpm) coincident with starting Lisinopril
  10 mg on 2024-02-01." Event-driven, low volume, narrative-shape
  graphiti handles well (Q1 validated this kind of "X coincident with
  Y" link).

These summary / anomaly episodes are exactly the shape graphiti's
edge-fact extractor preserves cleanly — short noun-verb-object
sentences with a date, no value-stream. Q1 / Q3 / Q8 give us
confidence here.

### 3. Hourly stays available (batched ingest, gated by use case)

Hourly summaries land in the **$17.52 / user / yr** band. That is
viable but not free. Default off; an Omur consumer flag
(`omur.feature.hourly_wearable_to_gnokee`) opts a tenant in when
narrative-grade hourly recall ("how was my HR this morning before
the workout?") is part of the product surface. For most consumers
the daily-summary band suffices; hourly is the upgrade path.

## Schema / surface implications

- **No new gnokee table for wearables.** TimescaleDB is the
  consumer-side store; gnokee neither owns it nor proxies it. This
  preserves the AGENTS.md "no LLM hosting / no key holding /
  no UI / no time-series store" boundary.
- The daemon producing summary + anomaly episodes lives in the
  consumer (Omur), not gnokee. gnokee remains a passive memory
  surface. v0.2.x or v0.3 may revisit `gnokee.maintenance` (the same
  daemon shape #8 deferred); if so, wearable-summary synthesis is
  one of the named jobs alongside `total_spend` aggregation.
- **MCP** gains nothing here. `gnokee_recall` is the same; it just
  happens to be queried for wearable-summary episodes that the
  consumer authored upstream. `gnokee_lab_query` /
  `gnokee_med_query` (ADR-0009 / ADR-0010) do *not* gain a wearable
  sibling — wearables stay typed at the consumer's TimescaleDB.

## Rationale

Three forces converge:

1. **Cost** — $1.1k / user / yr at raw rates is unrecoverable in a
   consumer-grade SaaS price band, and per-tenant LLM-call caps would
   throttle Omur into incoherence. The cost gradient between raw and
   daily is **1,160×**; that's not a tunable, it's a tier change.
2. **Latency** — 5.6 s / episode × 1 Hz live stream = guaranteed lag.
   No amount of horizontal scaling fixes this without making graphiti
   skip extraction for wearable shapes, which defeats the purpose of
   running them through graphiti at all.
3. **Quality** — graphiti's edge-fact extractor sees no narrative in
   `"HR 67 bpm at 2024-08-15 07:00"`. The fact it produces is
   uninteresting in isolation; what's interesting is the *summary*
   ("HR low this morning") and the *anomaly* ("HR jumped 12 % when
   Lisinopril started"). That synthesis is exactly what the daemon
   shape produces — and it produces a fact graphiti's extractor
   handles well.

The structured-table direction from ADR-0009 / ADR-0010 is
deliberately not extended here. Lab and med data are *user-relevant
records* that justify durable typed storage in gnokee's surface;
wearables are *observation streams* that justify durable typed
storage at the consumer. The boundary is that gnokee owns the
narrative *interpretations* of wearables, not the streams themselves.

## Consequences

- **Out of scope for v0.1.x.** Like ADR-0009 / ADR-0010, this is a
  v0.2 commitment. v0.1.1 ships unchanged.
- **Omur (the consumer) takes on TimescaleDB.** This is a v0.2
  Omur architecture decision, captured in `omur-core` and not
  here, but flagged so the gnokee → Omur boundary stays clean.
- **The daemon shape from #8** gets a second use case, strengthening
  the case for landing it in v0.2.x. Spend aggregation +
  wearable summary synthesis share periodicity, supersession
  discipline, and `source_description` tagging.
- **Q-spike progression.** Q1 (graphiti fit on notes) → Q7 (labs,
  off-ramp) → Q8 (meds, adopt-with-gaps) → Q9 (wearables, batch or
  off-ramp). Q1's promise is now fully validated for both consumers
  with documented gap-fillers per shape. Tag-cut for v0.2 reads
  ADR-0009 / 0010 / 0011 as the design quartet.

## Status notes

- Spike artefacts: `evals/spike_q9_wearable_throughput/` — corpus,
  harness with httpx-monkey-patched call counter, results JSON.
  Re-runnable per README.
- Cost projection assumes `gpt-4o-mini` at $0.0002 / call. Migration
  to a heavier extractor (e.g. `gpt-4.1`) would worsen all three
  bands proportionally and not change the verdict; migration to a
  cheaper or self-hosted extractor (`qwen3:4b` on Ollama) might bring
  hourly into the adopt-as-is band on a per-user basis but raw stays
  off-ramp by latency alone.
- The `embed_calls` column read 0 across the run because the host
  classifier didn't catch the `localhost:8080` (TEI) and
  `localhost:11434` (Ollama) host strings — embed traffic was
  classified as `other`. Cost dominated by LLM calls regardless;
  fix the classifier before reusing this harness for embed-cost
  spikes.
