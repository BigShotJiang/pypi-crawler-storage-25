# ADR-0030: MCP authentication surface — pluggable `AuthBackend`, principal-to-`tenant_id` binding, library-mode opt-out

- **Status:** Accepted
- **Date:** 2026-05-20
- **Driver:** Issue [#244](https://github.com/omurlabs/gnokee/issues/244) — "mcp/security: authentication surface for production MCP server"; bundled into [Plan: docs/plans/2026-05-20-v0.12-mcp-revival.md](../plans/2026-05-20-v0.12-mcp-revival.md) alongside [#246](https://github.com/omurlabs/gnokee/issues/246) (tenant-boundary audit), [#245](https://github.com/omurlabs/gnokee/issues/245) (streamable-http production-readiness), [#233](https://github.com/omurlabs/gnokee/issues/233) (param rename). v0.12 ships consumer-agnostic: gnokee MCP as a standalone product surface, ready when any consumer appears. (Omur consumes the Marrow HTTP bridge today via omur#598; may switch to MCP later but is not the v0.12 driver.)
- **Supersedes:** none
- **Amends:** none — additive to `build_server(app)` (new keyword arg `auth=None`)
- **Refs:** [ADR-0004](0004-bi-temporal-storage-shape.md) (`tenant_id` contract on every API + table + MCP call), [ADR-0026 amendment 2026-05-19](0026-forget-pipeline.md#amendment-2026-05-19--public-forget-surface-is-episode-level-and-tenant-level-only) (forget surface is episode + tenant only), [ADR-0027](0027-mcp-short-id-translation.md) (short-ID translation; tenant-keyed table), AGENTS.md "do not host keys / do not host identity" invariant.

The MCP server is marked `v0.1 unauthenticated` (`src/gnokee/mcp/__init__.py:21`). Every tool takes `tenant_id: str` as a plain parameter — caller asserts the partition, gnokee trusts it. That ceiling holds for in-process library use (caller already trusts itself) and stdio MCP (caller is a desktop client running as the same user). It breaks once the MCP server is hosted as a network-reachable service for multi-tenant consumers — Omur Option C. This ADR adds an authentication surface that binds a verified principal to the `tenant_id` parameter without losing the library-mode trust path that Marrow (and stdio MCP clients) depend on.

## Context

gnokee's tenant boundary today is a **trust assertion**: the caller passes a `tenant_id`, every storage call partitions by it, and Postgres RLS plus the Graphiti `group_id` discipline guarantee that data from another tenant is unreachable *given a correct `tenant_id`*. The unsolved problem is the word "correct" — nothing in gnokee verifies that the caller is entitled to act on that `tenant_id`.

That unsolved problem is acceptable in three current deployment shapes:

1. **In-process library use.** Marrow imports `gnokee.ingest_episode` / `gnokee.recall` / `gnokee.forget_episode` directly. Marrow has already authenticated the user and resolved the session's `tenant_id`. gnokee is downstream of Marrow's trust boundary; double-checking would be theatre.
2. **Stdio MCP.** Claude Desktop / Cursor / Code spawn `python -m gnokee.mcp` as a child process. The OS process boundary IS the trust boundary — only the user's session can launch that subprocess, and the subprocess inherits the user's filesystem authority.
3. **Local dev / single-tenant deploys.** One operator, one tenant, no network.

It breaks once gnokee MCP runs as a **standalone, network-reachable product surface** — multiple consumers, no shared trust boundary. Each consumer must prove tenant authority to gnokee, not just declare it. (Omur Option C was the original motivating use case but is not the v0.12 driver — v0.12 ships consumer-agnostic.)

### What "auth surface" means for gnokee specifically

gnokee is infrastructure, not a product. AGENTS.md spells out the invariants:

- **gnokee never hosts identity.** No user database, no signup flow, no password storage.
- **gnokee never holds keys.** KMS reference passed via `kms_ref`; gnokee never sees DEKs in plaintext beyond the per-call body decrypt; never sees signing keys at all.
- **gnokee never federates.** No SSO mediation, no OAuth client registration on gnokee's side.

The auth surface therefore reduces to one thing: **verify a token someone else issued**, decode the principal, enforce the principal-to-`tenant_id` binding on every tool call. gnokee verifies; it does not issue, store, refresh, or revoke. Identity provider (Omur, in the Option C case) signs the token; gnokee checks the signature, the claims, and the binding.

### What `mcp` library already gives us

(**Gate-2 finding, 2026-05-20** — `mcp==current pin in `.venv`, Python 3.14`)

`.venv/lib/python3.14/site-packages/mcp/server/auth/` exposes a clean resource-server hook:

- `provider.py:92` — `TokenVerifier` Protocol — `async def verify_token(self, token: str) -> AccessToken | None`. This is the public, resource-server-side hook: gnokee implements this Protocol, FastMCP calls it on every authenticated request.
- `middleware/bearer_auth.py` — `BearerAuthBackend(verifier)` Starlette middleware; reads `Authorization: Bearer …` headers, delegates to the verifier, attaches the resulting `AccessToken` to the request.
- `middleware/auth_context.py` — `AuthContextMiddleware`; binds the decoded `AuthenticatedUser` (wrapping the `AccessToken`) to a Starlette request scope contextvar.
- `provider.py:OAuthAuthorizationServerProvider` — issuer-side Protocol (NOT what we need; gnokee does not issue tokens).
- `routes.py` — full OAuth 2.1 + RFC 7591 dynamic-client-registration routes; intended for servers that ARE the IdP (NOT what we need).

`FastMCP(..., token_verifier=..., auth=AuthSettings(...))` constructor accepts the verifier directly (`server.py:153,174`). When set, `BearerAuthBackend` + `AuthContextMiddleware` are wired automatically inside `streamable_http_app()` (`server.py:858`). We do not need to write our own ASGI middleware.

`AccessToken` shape (`provider.py:37`) is `client_id: str` + `scopes: list[str]` + `expires_at: int | None`. We pack `Principal` into `AccessToken` via the adapter: `client_id = principal.subject`, `scopes = ["tenant:" + t for t in principal.allowed_tenants]`, `expires_at = jwt.exp`.

**Integration pattern:** gnokee defines its own `AuthBackend` Protocol (domain shape — `Principal.allowed_tenants` is the load-bearing concept). A thin adapter `MCPTokenVerifier(backend: AuthBackend)` implements upstream's `TokenVerifier` by calling `backend.verify(...)` and packing the result into an `AccessToken`. The adapter also sets gnokee's own `_current_principal` contextvar so the per-tool guard can read it cleanly without depending on Starlette request-scope details.

**Implication for the rest of this ADR:** the `AuthBackend` Protocol below stays — it is the gnokee-facing public API. The "wrap FastMCP `streamable_http_app()` with our own ASGI middleware" claim in earlier drafts is OBSOLETE — we plug into upstream's `TokenVerifier` Protocol instead, which is cleaner and stable public API.

### Why not "remove `tenant_id` from tool args entirely"

The symmetry is tempting: if auth knows the tenant, the param is redundant. Rejected because library-mode (`auth=None`) remains a first-class supported use case. Removing the param would force every library caller to fake a principal or set a contextvar before calling — surface-area increase for the most common use case to optimize the rarer one. Keep the param; let the middleware validate it.

## Decision

**Ship `AuthBackend` as a small Protocol injected via `build_server(app, *, auth=None)`. When `auth is None`, the server attaches no middleware — current behavior preserved bit-for-bit; this is the library-mode opt-out. When `auth` is set, an ASGI middleware in front of the FastMCP `streamable_http_app()` decodes the principal once per request, binds it to a contextvar, and every tool wrapper validates `tenant_id ∈ principal.allowed_tenants` before the tool body runs. Bearer-JWT is the reference implementation shipped in v0.12; mTLS is a placeholder slot only.**

### `AuthBackend` Protocol (canonical contract)

```python
# src/gnokee/mcp/auth.py (new module)

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class Principal:
    """Verified identity for one MCP request.

    Lifetime: bound to a single request via contextvar; never persisted.
    """

    subject: str
    """Opaque identifier (JWT `sub`, mTLS CN, etc.). Stable per identity. Logged."""

    allowed_tenants: frozenset[str]
    """The set of `tenant_id` values this principal may pass on tool calls.
    A request that names any `tenant_id` outside this set is rejected with 403.
    Empty set is legal (principal has no tenant authority — all tool calls fail
    closed) and is distinct from `None`, which means "auth is off, accept any
    tenant_id" (library mode)."""

    claims: Mapping[str, object]
    """Raw verified claims (JWT body, mTLS cert extensions, etc.). Available to
    downstream audit logging. Read-only — do NOT route business logic off
    custom claims without lifting them into a typed field on Principal."""


class AuthBackend(Protocol):
    """Verifies the request's authentication material and returns a Principal.

    Implementations MUST be stateless across requests (or carry their own
    cache). They MUST raise `AuthError` on any failure; they MUST NOT return
    `None` to indicate failure.
    """

    async def verify(self, *, request_headers: Mapping[str, str]) -> Principal:
        ...


class AuthError(Exception):
    """Raised by `AuthBackend.verify` on missing/malformed/expired/invalid auth.

    `code` MUST be 401 (auth material missing/invalid) or 403 (auth material
    valid, but principal not authorized for the requested tenant_id). 403 is
    raised by the per-tool guard, NOT by `verify`."""

    def __init__(self, code: int, detail: str) -> None:
        if code not in (401, 403):
            raise ValueError(f"AuthError.code must be 401 or 403, got {code}")
        self.code = code
        self.detail = detail
        super().__init__(detail)
```

### Library-mode opt-out invariant (load-bearing)

`build_server(app, auth=None)` MUST produce a server with **zero auth middleware attached** and **zero contextvar reads in the tool guards**. The library-mode use case is not "auth backend that accepts everything" — it is "no auth machinery at all." This is the invariant that protects Marrow's in-process use case and the stdio MCP path from accidental regression as the auth surface evolves.

Test invariant: `tests/integration/test_mcp_auth.py::test_library_mode_no_auth` asserts that `build_server(app, auth=None)` accepts a tool call with an arbitrary `tenant_id` and returns the same payload as a direct `app.ingest_episode(...)` call. Any future change to the auth surface that breaks this test is a breaking change requiring an ADR amendment.

### Token-to-tenant binding semantics

The per-tool guard is the enforcement point, not `AuthBackend.verify`. `verify` answers "who are you?"; the guard answers "are you allowed to act on *this* `tenant_id`?". Splitting it this way means:

- A single `Principal` can authorize calls across multiple tenants (multi-tenant operator scenarios) by listing all of them in `allowed_tenants`.
- `verify` is decoupled from any specific tool signature — backends are easier to write and test.
- The 401-vs-403 split is preserved: 401 = "I don't know who you are"; 403 = "I know who you are, but you can't do that".

### Where the guard lives

`MCPTokenVerifier` adapter (gnokee module `src/gnokee/mcp/auth.py`) implements upstream `TokenVerifier`. On a successful `backend.verify(...)` it ALSO sets gnokee's `_current_principal: ContextVar[Principal | None]` for the per-tool guard to read. `_current_principal` is reset in a `finally` block at the end of each request (Starlette task-local pattern).

Single decorator `_tenant_guard(tenant_id_arg="tenant_id")` applied via wrapper to every `@server.tool()` registration inside `build_server`. Decorator behavior:

- Reads `_current_principal` contextvar.
- If unset (library mode) → no-op; tool body runs with the `tenant_id` arg verbatim.
- If set and `tenant_id ∈ principal.allowed_tenants` → tool body runs.
- If set and `tenant_id ∉ principal.allowed_tenants` → raises `MCPError(403, "tenant_id not authorized for this principal")` BEFORE tool body runs; emits an audit log line with `principal.subject` + the rejected `tenant_id`.

The guard MUST NOT log the principal's claims dict — only `subject` + the rejected `tenant_id`. Claims may contain caller-side secrets we never asked for.

### Bearer-JWT reference implementation

```python
# src/gnokee/mcp/auth.py (same module)

@dataclass(frozen=True)
class BearerJWTBackend(AuthBackend):
    """Verifies `Authorization: Bearer <jwt>` against a fixed public key.

    Issuer (Omur, in the Option C case) signs the token; gnokee verifies the
    signature, the standard claims (iss/aud/exp), and reads `tenant_claim`
    (default `"tenants"`) to populate `Principal.allowed_tenants`.
    """

    public_key: str  # PEM-encoded RSA/EC public key, or HMAC secret for HS256
    algorithm: str  # "RS256" | "ES256" | "HS256"
    tenant_claim: str = "tenants"  # JWT claim name listing allowed tenant_ids
    issuer: str | None = None  # required-iss check; None = skip
    audience: str | None = None  # required-aud check; None = skip
    leeway_seconds: int = 30

    async def verify(self, *, request_headers: Mapping[str, str]) -> Principal:
        # 1. Extract bearer token from Authorization header → AuthError(401) on missing/malformed.
        # 2. pyjwt.decode(token, public_key, algorithms=[algorithm], audience=..., issuer=..., leeway=...) → AuthError(401) on any pyjwt exception.
        # 3. Read `tenant_claim` → list of strings → frozenset. Missing claim → AuthError(401, "no tenant claim").
        # 4. Return Principal(subject=claims["sub"], allowed_tenants=..., claims=...).
        ...
```

`pyjwt` is added to `pyproject.toml`. Pinned minor version. Choice rationale: most-maintained, smallest surface, widely audited; rejected alternatives (`python-jose` — unmaintained for 18 months; `jwcrypto` — heavier, fewer reviewers).

### mTLS placeholder

mTLS is in-scope for the **Protocol** (any `AuthBackend` impl can read mTLS cert info from request headers populated by a TLS-terminating reverse proxy) but **no concrete `MTLSBackend` ships in v0.12**. The bearer-JWT reference impl is the v0.12 deliverable. Driver for mTLS: an Omur deploy that mandates client-cert auth. v0.13+ if it materializes.

## Consequences

### Positive

- **Option C is unblocked.** gnokee MCP server can be hosted as a network-reachable service for multi-tenant consumers without trusting caller-supplied `tenant_id`.
- **Library-mode is preserved.** Marrow's in-process use case (today's primary consumer) is untouched; opt-in surface, no default behavior change.
- **AGENTS.md invariants hold.** gnokee verifies tokens, never issues them; no identity database; no key holding.
- **The 401/403 split is honest.** Auditing distinguishes "unauthenticated" from "authenticated but unauthorized" — load-bearing for forensics.
- **Backend pluggability.** Future deploys can swap `BearerJWTBackend` for `MTLSBackend` or a custom `AuthBackend` without touching `build_server` callers.

### Negative

- **One more contextvar in the request hot path.** Negligible cost (~µs per call) but adds a debug dimension when something looks wrong: "is the principal set or not?" becomes part of every triage.
- **Dependency on `pyjwt`.** New supply-chain surface. Mitigation: pinned, vendored if needed, narrow API use (only `decode` + algorithm whitelist).
- **The library-mode invariant is a discipline contract.** A future contributor wiring auth in by default would break Marrow. The invariant lives in ADR-0030 + the test; it has no compile-time enforcement.

### Neutral

- **Per-tool scoping (read-only vs forget) is NOT delivered in v0.12.** `Principal` has `allowed_tenants` but no `allowed_operations`. A principal that can pass `tenant_id=t` can call any tool with that `tenant_id`. Per-tool scoping is a separate ADR if/when a driver appears.
- **No quota / rate-limiting.** Principal carries no quota field; enforcement deferred. Reverse proxy or a future ADR handles it.
- **Audit log lives at the per-tool guard, not in `AuthBackend`.** Backends focus on verification; logging is gnokee's responsibility (consistent with omkit logger usage elsewhere).

## Alternatives considered

### Alt 1 — Reuse `mcp` library's `TokenVerifier` directly (no gnokee `AuthBackend` Protocol)

Closest off-the-shelf option. Plug `BearerJWTBackend` directly into `FastMCP(token_verifier=...)`, drop the gnokee-defined `AuthBackend` Protocol entirely. Rejected (narrowly): the upstream `AccessToken` shape (`client_id` / `scopes` / `expires_at`) is OAuth-ergonomic but a poor fit for the gnokee domain concept of `allowed_tenants`. Encoding tenants as `scopes=["tenant:t_alice", ...]` works but pushes the per-tool guard into string-parsing scope strings on every call. The gnokee `AuthBackend` + `Principal` Protocol is ~25 lines of code, decouples the domain shape from upstream's OAuth shape, and lets the per-tool guard read a strongly-typed `frozenset[str]` instead of parsing scope strings. We DO use the upstream `TokenVerifier` hook as the integration point (gate-2 finding above) — we just adapt across it rather than expose it as our public API.

### Alt 2 — Remove `tenant_id` from tool args; derive it from `Principal`

Tempting symmetry. Rejected because library-mode (`auth=None`) remains a first-class supported path. Removing the param forces every library caller (Marrow today) to fake a principal or set a contextvar before calling — surface increase for the common case to optimize the rarer one.

### Alt 3 — Embed identity provider in gnokee (sign + verify)

Rejected on AGENTS.md "do not host identity / do not host keys" grounds. gnokee is infrastructure; signing tokens means storing signing keys, rotating them, exposing JWKS, handling revocation lists — all of which are Omur's (or any consumer's) job, not gnokee's.

### Alt 4 — Per-tool scoping in the same ADR

Considered bundling `Principal.allowed_operations: frozenset[str]` into v0.12. Rejected as scope creep — no current driver names the operation split (Option C wants "this client can talk to gnokee for tenant X", not "this client can read but not forget"). Defer to a follow-up ADR when a driver lands.

### Alt 5 — Stop trusting `tenant_id` even in library mode (force principal everywhere)

Rejected for the third time, for the avoidance of doubt: library mode is the primary deployment shape today (Marrow in-process). Forcing principal-everywhere would break Marrow and every stdio MCP client without measurable security gain (those callers are already trust-boundary-adjacent). The opt-out is load-bearing.

## Open questions

1. **`Principal.subject` format.** JWT `sub` is opaque; mTLS CN is a DN string. Do we normalize at the backend boundary, or let consumers handle the variance? Lean: let consumers handle; document the backend-specific shape in the docstring.
2. **Audit-log destination for rejected calls.** Reuse omkit logger with a dedicated `gnokee.mcp.auth.rejected` channel? Or a dedicated `gnokee_maintenance.mcp_auth_audit` table (a la `forget_audit`)? Lean: logger-only in v0.12; promote to a table if compliance requirements appear.
3. **`AuthBackend.verify` caching.** Some backends (e.g., a remote JWKS-fetching variant) will want per-key caching. Cache lives inside the backend impl, not the Protocol — confirmed.

## Amendment 2026-05-22 — implementation-drift pin-down

Specialist scope-verdict review (gnokee-mcp-tool-designer + security-reviewer, 2026-05-22) flagged four points where the ADR-as-shipped and the impl-as-landed had drifted or left load-bearing details implicit. This amendment pins each:

### A. `MCPTokenVerifier` adapter contract (synthetic Bearer header)

The adapter at `src/gnokee/mcp/auth.py:255` calls `backend.verify(request_headers={"Authorization": f"Bearer {token}"})` — it **synthesizes** an Authorization header from the raw token string that upstream `FastMCP` already extracted. This is the load-bearing seam between the upstream `TokenVerifier.verify_token(token: str)` shape and gnokee's header-shaped `AuthBackend.verify(request_headers=...)` Protocol.

The decision is intentional: the gnokee Protocol stays Header-shaped so backends are testable + reusable outside FastMCP (an mTLS backend, a future header-based custom-auth backend, etc., all share one shape). The cost is that `BearerJWTBackend` reads the bearer prefix twice on each request — once by upstream's `BearerAuthBackend` middleware, once by `_extract_bearer` in our backend. This is acceptable (microseconds per call, no security implication).

Future auth backends MUST consume `request_headers: Mapping[str, str]` and MUST tolerate the synthetic-header pattern. The adapter MUST NOT pass any other request metadata (cookies, query params, path) — the seam is bearer-token-only.

### B. JWKS rotation gap — restart-required (Q3 closed against caching)

`BearerJWTBackend.public_key` is a fixed PEM/secret string set at construction time. There is **no `kid` header handling**, **no JWKS endpoint fetching**, **no in-process key rotation**. Key rotation requires a gnokee MCP process restart.

This is the deliberate v0.12 ceiling. JWKS support is a follow-up ADR if a deploy materializes that requires zero-downtime rotation; the cost is non-trivial (JWKS cache, refresh schedule, cache-poisoning defenses). Operators MUST document the restart-required posture in their runbook. Open Q3 (`AuthBackend.verify` caching) is closed in v0.12 — no caching needed because there is no remote fetch.

### C. `tenant_claim` allowlist semantics — no wildcard

Three observed values + how each is interpreted:

- **Missing claim** (`tenant_claim` key absent from JWT body) → `AuthError(401, "missing or malformed tenant claim")`. Closed-fail.
- **Empty list** (`"tenants": []`) → `Principal(allowed_tenants=frozenset())`. Verify-time success; per-tool guard then rejects every call (403). Distinguishes "authenticated but unauthorized for any tenant" from "missing claim" — useful for "user exists in IdP but has no gnokee tenant grants yet" flows.
- **String `"*"` in the list** (`"tenants": ["*"]`) → treated as the literal `tenant_id` equal to `"*"`. There is **no wildcard semantic**. A backend that wants wildcard-grant authority must implement it explicitly (e.g., a custom `AuthBackend` that returns `allowed_tenants=frozenset(all_known_tenants)`).

The no-wildcard invariant is load-bearing — any wildcard expansion would shift gnokee from "verify what someone else asserted" toward "make tenant authority decisions of its own," violating the "gnokee never hosts identity" rule.

### D. Per-tool guard is inline, not a decorator (plan-doc drift)

ADR §"Where the guard lives" describes a `_tenant_guard(tenant_id_arg="tenant_id")` decorator applied to every `@server.tool()` registration. The shipped impl uses **inline `enforce_tenant_authority(tenant_id)` calls at the top of each tool body** (one call per `@server.tool` registration; 11 sites in `src/gnokee/mcp/__init__.py`).

The inline pattern is preferred — it keeps `tenant_id` visibly in scope at the call site, avoids decorator argument-inspection magic, and trivially supports tools where the tenant-bound parameter is not literally named `tenant_id` (currently none, but future-proof). This amendment retires the decorator design and pins the inline-call contract. Future tool registrations MUST call `enforce_tenant_authority(tenant_id)` as the first statement in the wrapped function body.

The plan doc (`docs/plans/2026-05-20-v0.12-mcp-revival.md` §Step 3) carries the obsolete decorator description; it will be updated in the v0.12.2 docs sweep.

## Acceptance evidence

- This ADR Status: `Accepted` (flipped in same PR as `src/gnokee/mcp/auth.py` introduction).
- `tests/integration/test_mcp_auth.py` 4 cases green: library-mode-no-auth / authorized-call / unauthorized-tenant / expired-or-malformed-token.
- `tests/integration/test_mcp_auth.py::test_library_mode_no_auth` invariant test green.
- `src/gnokee/mcp/__init__.py::build_server` signature: `build_server(app: App, *, auth: AuthBackend | None = None) -> FastMCP`.
- `src/gnokee/mcp/auth.py` ships `AuthBackend`, `Principal`, `AuthError`, `BearerJWTBackend`.
- `pyproject.toml` adds `pyjwt` dependency, pinned.
- README MCP-server section documents production config; `examples/03_mcp_clients/authenticated_client.py` runs end-to-end.

### Amendment 2026-05-22 acceptance evidence

- §A synthetic-header pattern pinned at `src/gnokee/mcp/auth.py:255`.
- §B no-JWKS posture pinned; Open Q3 closed in v0.12.
- §C no-wildcard `tenant_claim` semantics pinned; matches `BearerJWTBackend.verify` line 194-200.
- §D inline `enforce_tenant_authority` contract pinned; matches 11 tool registrations in `src/gnokee/mcp/__init__.py`.
