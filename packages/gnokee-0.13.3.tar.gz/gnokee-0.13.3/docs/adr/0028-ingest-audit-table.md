# ADR-0028: `ingest_audit` table — per-call compliance log for ingest

- **Status:** Accepted
- **Date:** 2026-05-17
- **Driver:** Issue [#198](https://github.com/omurlabs/gnokee/issues/198) — `gnokee_maintenance.ingest_audit` (compliance counterpart of `forget_audit`)
- **Supersedes:** none
- **Amends:** none — additive
- **Refs:** [ADR-0024](0024-ingest-crash-recovery-journal.md) (crash-recovery journal), [ADR-0026](0026-forget-pipeline.md) (forget pipeline + `forget_audit` precedent), [Plan: docs/superpowers/plans/2026-05-17-v0.10-clinical-mcp-polish.md](../superpowers/plans/2026-05-17-v0.10-clinical-mcp-polish.md), [Spec: docs/superpowers/specs/2026-05-17-v0.10-clinical-mcp-polish-design.md](../superpowers/specs/2026-05-17-v0.10-clinical-mcp-polish-design.md)

`forget_audit` (ADR-0026) gives operators a verifiable trail of every destructive operation that touched a tenant — survives tenant deletion by design, lives in `gnokee_maintenance` so it is not cascaded away. v0.9 ships nothing equivalent on the **ingest** side. Compliance reviews of personal-health and regulated-data deployments require a symmetric trail: *every episode that entered gnokee* must be auditable post-hoc, with the row surviving tenant forget. `ingest_journal` (ADR-0024) is not that trail — it is a crash-recovery journal with different retention semantics (the application connection prunes journals once recovery windows close), and it lives under the application schema where tenant cascade reaches it. This ADR adds `gnokee_maintenance.ingest_audit` as the compliance counterpart of `forget_audit`.

## Context

The pre-ADR-0028 ingest surface has three durable artefacts per call:

- **Stage 4 Episodic node** (Neo4j) — the body itself, written via `graph.write_lite_episode`. Cascaded away by `gnokee_forget_tenant`.
- **Stage 5 Postgres rows** — `episode_metadata`, `content_embedding`, `episode_body_encrypted`, `lab_record`, `med_record`. Cascaded away by `gnokee_forget_tenant`.
- **`ingest_journal` row** (`begin → commit | fail`) — crash-recovery only, lives under the application schema so tenant cascade reaches it (ADR-0024 §Decision + #130 cascade fix). `maintenance.run_deferred_extraction` / `resume_ingest` reads it; operators do not.

After `gnokee_forget_tenant(t)` runs, **no record exists** that the tenant's episodes were ever ingested. That is correct for the GDPR right-to-be-forgotten payload — the data is gone — but it is wrong for the compliance posture: an operator cannot prove to a regulator that ingest A happened, then forget B happened, and the system honoured both. The auditor sees an empty hole and has no way to distinguish "tenant was never here" from "tenant was forgotten last week".

`forget_audit` already solves the symmetric problem on the destructive side: schema-isolated under `gnokee_maintenance`, untouched by tenant cascade, holds the full receipt of every forget call. The pattern is sound — ADR-0026 §Schema isolation rationale is the canonical reference. This ADR applies the same pattern to ingest.

The distinction between `ingest_journal` (ADR-0024) and `ingest_audit` is load-bearing and must be explicit:

- `ingest_journal` is **operational**: it exists to recover an in-flight ingest from a crash between Stage 4 and Stage 6, retained until the recovery window closes (currently lifetime-of-tenant, but the operational team may prune older entries once `resume_ingest` is known not to need them). It carries `payload_hash` + `stage_4_time` so resume can replay deterministically. It does NOT carry actor / source_url / receipt — none of that is needed to resume a crashed ingest.
- `ingest_audit` is **compliance**: it exists to prove to an auditor that ingest happened, retained beyond tenant lifetime, indexed for human-readable forensics. It carries `actor` + `source_url` + the full `receipt` JSONB + the structured `error` payload on failure. It does NOT carry `payload_hash` or `stage_4_time` — none of that is meaningful to a compliance reviewer reading the row years later.

Conflating the two — either by reusing `ingest_journal` for both purposes, or by placing audit rows under the application schema with a tenant FK — is the rejected alternative below.

## Decision

**Ship `gnokee_maintenance.ingest_audit` as a schema-isolated per-call audit log mirroring the shape of `forget_audit`. State machine `begin → commit | fail`. Application writes via `gnokee.storage.ingest_audit` module; operators read directly. No RLS; schema placement is the access boundary, matching `forget_audit` precedent.**

### Schema (migration 0023)

```sql
CREATE SCHEMA IF NOT EXISTS gnokee_maintenance;

CREATE TABLE IF NOT EXISTS gnokee_maintenance.ingest_audit (
    audit_id           UUID        NOT NULL DEFAULT gen_random_uuid(),
    tenant_id          TEXT        NOT NULL,
    episode_uuid       UUID,
    our_id             TEXT,
    state              TEXT        NOT NULL CHECK (state IN ('begin', 'commit', 'fail')),
    actor              TEXT,
    source_url         TEXT,
    decision           TEXT,
    supersession_uuid  UUID,
    receipt            JSONB,
    error              JSONB,
    started_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at        TIMESTAMPTZ,
    PRIMARY KEY (audit_id)
);
```

Indexes: `(tenant_id, started_at)` for tenant timelines; `(tenant_id, episode_uuid) WHERE episode_uuid IS NOT NULL` for per-episode lookups; `(tenant_id, started_at) WHERE state = 'fail'` for failure forensics. No FK to `episode_metadata` — the audit row outlives the row it references, and `episode_uuid` is NULL on rows that failed before Stage 4 produced a UUID.

### State machine

`Ingestor.ingest_episode` writes:

1. **begin** — INSERTED immediately after Stage 1 boundary validation succeeds (the moment `tenant_id` is known and the content-xor-encrypted invariant is validated). Returns `audit_id`.
2. **commit** — UPDATE on the same `audit_id` after the receipt is built. Sets `episode_uuid`, `decision` (`"new"` | `"replayed"`), `supersession_uuid` (from `EpisodeIn.corrects`), `receipt` JSONB (`IngestReceipt.model_dump_json()` round-tripped), `finished_at`.
3. **fail** — UPDATE on the same `audit_id` from inside the pipeline's outer `try/except`. Sets `error` JSONB (`{type, message}`), `finished_at`.

Pre-Stage-1 validation failures (empty `tenant_id`, missing content xor encrypted_body, naive datetimes) DO NOT write a row — the `ValidationError` is raised before `insert_begin` is called.

**On UPDATE vs append-only:** the `begin → commit | fail` transitions are deliberately UPDATE-in-place on a single `audit_id`, mirroring the [ADR-0026 `forget_audit` precedent](0026-forget-pipeline.md). This is the *intended* design for `gnokee_maintenance.*_audit` tables and is *not* a violation of the append-only invariant that governs [ADR-0024 `ingest_journal`](0024-ingest-crash-recovery-journal.md) — `ingest_journal` is the only audit-shaped surface that forbids UPDATE on write (its `fail` rows are new INSERTs per ADR-0024 §Open questions). The `*_audit` tables are append-only in the *retention* sense — gnokee never auto-DELETEs rows, only the optional operator-run `prune_forget_audit` does. See `docs/forget-runbook.md` §Audit-gap note for the retention contract.

### EpisodeIn surface

Two optional fields appended to `EpisodeIn`:

- `actor: str | None` (max 120 chars) — caller-supplied identity for the audit trail.
- `source_url: str | None` (max 2048 chars) — caller-supplied source pointer.

Both default to `None`. `extra="forbid"` is preserved.

## Consequences

- **Audit row survives tenant deletion.** `gnokee_forget_tenant(t)` cascades the application schema; `gnokee_maintenance.ingest_audit` is in a separate schema and untouched. The row is the verifiable-ingest proof — the counterpart of `forget_audit`'s verifiable-deletion proof.
- **No plaintext content body in the audit row.** Only metadata (`tenant_id`, `episode_uuid`, `our_id`, `actor`, `source_url`, `decision`, `supersession_uuid`) and the structured `IngestReceipt` JSONB. The `IngestReceipt` itself carries no raw episode body — it surfaces UUIDs + telemetry counts. Compliance-readable; GDPR-safe.
- **GDPR posture.** Right-to-be-forgotten under GDPR Article 17 includes the *substance* of the personal data, not the *fact* that processing happened — Article 30 (records of processing) explicitly requires the controller to retain processing logs. `ingest_audit` is the processing log; the surviving row contains no personal data beyond the `tenant_id` and the timestamps. Where deployments need to redact `actor` / `source_url` post-forget, they MAY do so via an operator-side `UPDATE` (gnokee does not run this automatically — the right policy varies by jurisdiction).
- **Storage cost.** One row per ingest call, ~200 bytes plus the receipt JSONB (~500 bytes typical). On a million-ingest deployment that is ~700 MB — comparable to `forget_audit` retention costs, well within deployment budgets.
- **No public API break.** `EpisodeIn.actor` + `EpisodeIn.source_url` are optional and default to `None`. v0.9 callers continue to work unchanged.

## Rejected alternatives

### Tenant-scoped table with cascade

Place `ingest_audit` under the application schema with a `tenant_id` FK so it cascades away on `gnokee_forget_tenant`. **Rejected** — violates the compliance posture. The whole point of the audit is to survive forget; cascading it away leaves the same forensic hole the pre-ADR-0028 state has.

### Reuse `ingest_journal`

Extend `ingest_journal` with `actor` / `source_url` / `receipt` columns and treat it as both crash-recovery and compliance log. **Rejected** — conflates retention semantics. `ingest_journal` is prunable once `resume_ingest` no longer needs the row; `ingest_audit` is retained for the compliance window (years). Stuffing both into one table forces the more restrictive retention to win — meaning either the audit is pruned too aggressively or the journal grows unboundedly. Two tables, one purpose each, is the cheaper engineering posture.

### In-process logging only

Emit a structured log line (`log.info("ingest_audit", extra={...})`) per call and rely on the operator's log aggregator to retain it. **Rejected** — not durable. The compliance auditor reads SQL, not Loki / CloudWatch. A log-only audit also dies with the process if the log shipper is misconfigured; a DB row survives by virtue of being committed in the same connection pool the application is already using.

## Cross-refs

- [ADR-0024](0024-ingest-crash-recovery-journal.md) — `ingest_journal` is the crash-recovery counterpart; `ingest_audit` is the compliance counterpart. Both live under `gnokee_maintenance` for the schema-isolation guarantee.
- [ADR-0026](0026-forget-pipeline.md) — `forget_audit` precedent. `ingest_audit` mirrors its schema-isolation rationale, state machine, and write-via-storage-module + read-via-operator-SQL access model.
