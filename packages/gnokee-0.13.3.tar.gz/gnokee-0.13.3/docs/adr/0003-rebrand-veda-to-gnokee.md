# ADR-0003: Rebrand from "Veda" to "gnokee"

**Status:** Accepted
**Date:** 2026-05-07

## Context

The project was drafted in Notion under the working name **Veda**
(Sanskrit *veda* = knowledge; cognate with Slavic *ведать* "to know").
Availability sweep on 2026-05-07 found:

| Resource                                       | Status   |
|------------------------------------------------|----------|
| GitHub org `vedalabs`                          | TAKEN    |
| GitHub user `veda`                             | TAKEN    |
| PyPI `veda` (v2.3.1)                           | TAKEN    |
| npm `veda` (v0.2.0)                            | TAKEN    |
| Docker Hub user `veda`                         | TAKEN    |
| `veda.dev`, `vedalabs.dev`, `vedalabs.io`,     | all      |
| `veda.io`, `veda.ai`, `veda.sh`                | TAKEN    |

Wider sweep across veda+suffix variants and Sanskrit/Greek/Slavic/Hebrew
alternatives produced **`gnokee`** as the only quad-clean candidate
(GitHub org + PyPI + npm + .dev) plus all of `.com`/`.io`/`.ai` also
available.

## Decision

Rename the project to **`gnokee`**. Org becomes `omurlabs` (parallels
existing `omurlabs`). Python package, npm package, Docker images, env
vars, MCP tool names — all rebranded.

## Etymology

`gnokee` = *gno* (Greek γνῶσις, *gnosis* = knowledge) + *kee* (English
*keep*, custodian). 6 letters. Bonus: phonetic "no key" matches the arch
invariant in `architecture.md` § Forgetting — gnokee never holds keys,
never decrypts. Phonetic collision noted: *gnocchi* (Italian pasta —
non-tech, accepted).

## Registered as of 2026-05-07

- GitHub org `omurlabs` ✅
- Repo `omurlabs/gnokee` ✅ (this repo)
- Domains `gnokee.com`, `gnokee.dev`, `gnokee.io` ✅
- PyPI `gnokee@0.0.0` ✅ (placeholder)
- npm `gnokee@0.0.0` ✅ (placeholder)

## Skipped / deferred

- `gnokee.ai` — too expensive at registration time
- Docker Hub org `omurlabs` — paid for orgs; defer until announcement
- USPTO / EUIPO trademark search — before public announcement, not before code
