# ADR-0029: Episode-record provenance API (`gnokee.get_episodes`)

- **Status:** Rejected (2026-05-19)
- **Date:** 2026-05-19
- **Driver:** [omur-core#472](https://github.com/omurlabs/omur/issues/472) — Real `GnokeeMemoryProvider` Marrow HTTP bridge requires episode-body lookup by UUID set; gnokee surfaces today (`fact_provenance`, `history_of`) do not return Episode bodies + metadata
- **Supersedes:** none
- **Amends:** none — additive
- **Refs:** [ADR-0004](0004-gnokee-owns-retrieval.md) (retrieval boundary), [ADR-0023](0023-gnokee-owns-episode-storage.md) (gnokee owns Episodic storage), [ADR-0026](0026-forget-pipeline.md) (forget pipeline + soft-delete semantics), [ADR-0016](0016-per-claim-citation-envelope.md) (citation envelope shape), [ADR-0028](0028-ingest-audit-table.md) (ingest_audit precedent)

## Rejection note (2026-05-19)

This ADR was proposed in the same PR (#294) that bundled the v0.12 plan, gated on Omur's reply to [omur-core#472 contract questions Q1–Q4](https://github.com/omurlabs/omur/issues/472#issuecomment-4484974929).

Before the reply arrived, [omur#598](https://github.com/omurlabs/omur/pull/598) merged ("Phase C — GnokeeMemoryProvider via Marrow HTTP bridge", 2026-05-19T20:45Z). That PR implemented `GET /memory/provenance/{episode_id}` against the existing `gnokee.history.history_of(tenant_id=..., episode_id=...) → HistoryResponse` API, joined with Marrow's `public.episodes` sibling row for `subject_id`, `payload_text`, `provenance`, `language`, and `recorded_at`. The DAG nodes (`HistoryNode`) cover the bi-temporal fields (`valid_at`); the sibling row covers the rest. `MemoryProvider.provenance` arity also narrowed to singular `episode_id: UUID` (Phase A.2 in omur-core#472 body), removing the batch-by-UUID need that motivated the plural `get_episodes(... episode_ids)` shape in this ADR.

Consequence: no consumer remains for `gnokee.get_episodes` or the `EpisodeRecord` dataclass. Adding the surface speculatively would violate AGENTS.md "smallest change that closes the immediate need". The ADR is closed Rejected rather than Deferred — re-opening requires a *new* concrete consumer ask (omur#598 cemented the alternative path).

What stays valid from the original draft:

- The encrypted-body passthrough contract idea (consumer-supplied DEK; gnokee never holds key material) — already covered for `ingest_episode` per [ADR-0021](0021-encrypted-body-storage.md). Re-stating it here added no new surface.
- The soft-delete silent-drop semantics on a UUID-set lookup — `history_of` already filters Postgres `episode_metadata.forgotten_at IS NOT NULL` ancestors out of the DAG walk; Marrow further drops sibling rows where `forgotten_at IS NOT NULL` (see `services/marrow/api/memory_provenance.py` in omur#598).
- The 100-UUID batch cap — moot; the consumer is singular.

The ADR text below is preserved unchanged from the Proposed draft so the rejection rationale stays readable against the original argument. Do not implement.

`services/frontal/long_term_memory.py:133` declares the `MemoryProvider.provenance` Protocol:

```python
async def provenance(
    self,
    *,
    tenant_id: UUID,
    episode_ids: Iterable[UUID],
) -> list[Episode]
```

Marrow's `/memory/provenance/{id}` HTTP route (planned in omur-core#472) wraps this. gnokee today exposes `fact_provenance(fact_id) → FactProvenance` (fact-level, returns citations) and `history_of(episode_id) → HistoryResponse` (supersession DAG). Neither answers "given a set of episode UUIDs, return the bodies + bi-temporal metadata". This ADR adds the missing public Python API as `gnokee.get_episodes(app, *, tenant_id, episode_ids) → list[EpisodeRecord]`.

## Context

Three call paths drive the need:

1. **Marrow `/memory/provenance/{id}`** — Frontal "show your work" UI surface. Renders the episode bodies that support an assertion. Episode IDs come from a prior `gnokee_query` response (via `provenance[]`) or a Frontal-side store of `(assertion_id → episode_id[])` mappings.
2. **External audit / compliance** — Operator hands an `ingest_audit.audit_id` to support, gets back the corresponding episode metadata. Today this requires the operator to hand-write Cypher / SQL.
3. **Cross-tool consumers** — `evals/`, `examples/03_mcp_clients/`, future Notion-vault sync — all need a stable "fetch episodes by UUID" primitive that respects RLS + encrypted-body semantics.

Today's surface gap is asymmetric:

- **Write side:** `gnokee.ingest_episode(...)` is the single entry point. Public, documented, exported from `gnokee/__init__.py`.
- **Read side (analytic):** `gnokee.recall(...)` and `gnokee.gnokee_query(...)` cover semantic search. Cover the "I have a query string" path.
- **Read side (by-ID):** `fact_provenance(fact_id)` and `history_of(episode_id)` exist but are not the right shape. `fact_provenance` returns `FactProvenance` (fact-level, includes per-claim citations). `history_of` returns `HistoryResponse` (Cytoscape-flat supersession DAG). Both pre-suppose the caller has a fact-id or wants the supersession chain.
- **Read side (batch by-UUID):** `src/gnokee/storage/graph.py:793` has `fetch_episode_contents(tenant_id, episode_uuids) → dict[UUID, str]` — content-only, private, no metadata. `src/gnokee/storage/metadata.py:347` has `list_episodes_for_tenant(...)` — paginated by tenant, not filtered by UUID set.

The natural shape — "give me the episodes for this UUID set, with metadata, RLS-scoped" — does not exist as a public API.

### Why this is ADR-grade

This is new public Python surface: stable name, stable parameter set, stable return shape, semver-meaningful. Per [ADR-0021](0021-consumer-surface-strategy.md) §"What counts as public" any addition to `gnokee/__init__.py` `__all__` requires an ADR-grade design pass before the first tagged release exposes it. Three load-bearing decisions need to land in writing:

1. **Encrypted-body branch behavior.** `episode_metadata.sensitive` ranges over `Sensitivity = Literal["public", "private", "phi", "confidential"]`. For non-public episodes, the body lives in `episode_body_encrypted` as ciphertext + AAD + KMS ref. gnokee never holds keys (ADR-0004 §"What gnokee owns vs what the consumer owns"). The `provenance` return shape must pass the encrypted envelope through without attempting decrypt.
2. **Soft-deleted episode handling.** ADR-0026 §3 forget pipeline removes Postgres + Graphiti rows on `forget_episode`. After forget, the UUID no longer maps to any row. Decision: `get_episodes` returns the subset that exists, silently drops missing UUIDs. Caller compares input set vs returned set to detect forgets.
3. **Supersession status surfacing.** `episode_metadata.superseded_by` and `asserted_until` carry the "this episode is no longer the current view" signal. Marrow's `/memory/provenance/{id}` should be able to render both current and superseded episodes (the UI may want to grey out the superseded ones). Include both fields in `EpisodeRecord`; let the caller decide rendering policy.

## Decision

**Ship `gnokee.get_episodes(app, *, tenant_id, episode_ids) → list[EpisodeRecord]` as the public batch-by-UUID episode lookup. Returns the subset that exists, RLS-scoped via `set_config('app.current_tenant', tenant_id, true)`. Non-public episodes return their `EncryptedBody` envelope as-is; gnokee never decrypts. Soft-deleted UUIDs are silently dropped from the response. Implementation reads `episode_metadata` (authoritative for bi-temporal + sensitivity + corrects_reason) and joins `episode_body_encrypted` when sensitivity != "public".**

### Public API (export from `gnokee/__init__.py`)

```python
async def get_episodes(
    app: App,
    *,
    tenant_id: str,
    episode_ids: list[UUID],
) -> list[EpisodeRecord]:
    """Batch-fetch episode bodies + bi-temporal metadata by UUID.

    Returns the subset of `episode_ids` that exist under `tenant_id`.
    Silently drops:
      * UUIDs that never existed under this tenant (no leakage signal).
      * UUIDs that were forgotten via `gnokee.forget_episode` (ADR-0026).

    For `sensitive != "public"` rows, `content` is None and `encrypted_body`
    carries the on-disk envelope verbatim. gnokee never decrypts; consumer
    holds the DEK and decrypts after fetch (ADR-0004 boundary).

    Order is NOT guaranteed to match the input list. Callers that need
    input-order alignment should key the response by `episode_id`.

    RLS-scoped: sets `app.current_tenant` GUC inside a single transaction
    for the full batch read.

    Raises:
      TenantNotFound:  no such tenant under `episode_metadata`.
      GraphStoreError: underlying Postgres / Neo4j failure.
    """
```

### Return shape — `EpisodeRecord`

```python
@dataclass(frozen=True)
class EpisodeRecord:
    # Identity
    episode_id: UUID
    tenant_id: str
    our_id: str | None              # consumer-supplied stable key when set

    # Bi-temporal (ADR-0004 axes)
    valid_at: datetime              # world-time start
    valid_until: datetime | None    # world-time end (NULL = open)
    asserted_at: datetime           # source-tx-time start
    asserted_until: datetime | None # source-tx-time end (NULL = still-asserted)

    # Body
    content: str | None             # plaintext, populated when sensitive == "public"
    encrypted_body: EncryptedBody | None  # ciphertext envelope, populated otherwise

    # Classification
    sensitive: Sensitivity          # "public" | "private" | "phi" | "confidential"
    language: str | None            # ISO 639-1; may be None when auto-detect punted

    # Lineage (ADR-0026 + #123 corrects_reason)
    superseded_by: UUID | None      # set when this episode has been superseded
    corrects_reason: str | None     # rationale for THIS episode's supersession of its parent
```

Invariant: `content` xor `encrypted_body` — exactly one is non-None per row. Matches the `EpisodeIn` ingest-side invariant.

### Tenant isolation

Same pattern as ADR-0026 + the `metadata.py` / `vector.py` reads:

```sql
BEGIN;
SELECT set_config('app.current_tenant', $1, true);  -- $1 = tenant_id
SELECT em.tenant_id, em.episode_uuid, em.valid_at, em.valid_until,
       em.asserted_at, em.asserted_until, em.our_id,
       em.sensitive, em.language, em.superseded_by, em.corrects_reason,
       em.content_text,            -- public-body branch
       eb.ciphertext, eb.aad, eb.kms_ref, eb.dek_wrapped, eb.dek_alg, eb.body_alg
  FROM episode_metadata em
  LEFT JOIN episode_body_encrypted eb
    ON eb.tenant_id = em.tenant_id AND eb.episode_uuid = em.episode_uuid
 WHERE em.tenant_id  = $1
   AND em.episode_uuid = ANY($2::uuid[]);
COMMIT;
```

`set_config(..., true)` scopes the GUC to the transaction, matching the FORCE-RLS readiness work that landed in v0.11.1 (PR #283). Read-only — no write side-effects regardless of soft-delete state, so no `forget_audit` row.

### Encrypted-body branch (ADR-0004 boundary)

For `sensitive != "public"`:

- `content` returned as `None`.
- `encrypted_body` populated with `EncryptedBody(ciphertext=, aad=, kms_ref=, dek_wrapped=, dek_alg=, body_alg=)` — the exact wire shape gnokee already accepts on the ingest side.
- gnokee never attempts decrypt. Marrow's KMS adapter holds the DEK; HTTP-bridge consumer calls `kms_adapter.decrypt(envelope)` after fetch.

For `sensitive == "public"`:

- `content` populated from `episode_metadata.content_text`.
- `encrypted_body` returned as `None`.

This mirrors the existing `EpisodeIn` ingest-side branch precisely. The serialization contract is symmetric: what went in via `ingest_episode` is what comes out via `get_episodes`.

### Soft-delete + supersession semantics

- **Forgotten episodes** — ADR-0026 §3 hard-deletes `episode_metadata` + `episode_body_encrypted` rows on `forget_episode` (idempotent, audit-trailed). `get_episodes` therefore returns no row for those UUIDs. Silent drop is correct: surfacing "this UUID was forgotten" would itself be a side-channel leak.
- **Superseded episodes** — `episode_metadata.superseded_by` set; `asserted_until` set; row not deleted. `get_episodes` returns the row with both fields populated. Caller renders accordingly.
- **As-of replay** — out of scope for v1. Callers that want "what did this episode look like at time T" use `gnokee.history_of(episode_id, as_of=T)`.

### Order + batch size

- Order: not guaranteed. Implementation may parallelize the encrypted-body join. Callers key the response by `episode_id` if order matters.
- Batch size: cap at 100 UUIDs per call. Beyond that, `IngestPipeline`-style batching at the call site. Matches the per-tenant query budget on `gnokee_query`. Raises `ValueError` on overflow rather than silently truncating.

### MCP exposure (deferred)

This ADR ships the Python API only. MCP-tool exposure (`gnokee_get_episodes`) is **out of scope** for v0.12 — gates on the parked Option C MCP transport work (#244 / #245 / #246). Once those unparkable, the MCP tool wraps the Python API verbatim; short-ID translation lands per ADR-0027.

## Considered alternatives

### Alt A — Document `history_of` as the answer

Tell Marrow's `MemoryProvider.provenance` to call `history_of(episode_id)` for each UUID and pull the matching `HistoryNode` out of the returned DAG.

**Rejected.** Three reasons:

1. **N-round-trip cost.** `provenance(episode_ids=[a, b, c])` → 3 separate `history_of` calls. Each one walks the supersession DAG, which is wasted work when the caller wants flat episode metadata.
2. **Wrong shape.** `HistoryNode` carries `rationale`, `supersession_chain`, etc. — fields shaped for the DAG-rendering use case. Marrow's `/memory/provenance/{id}` UI does not need them; just the body + bi-temporal axes.
3. **Encrypted-body story missing.** `HistoryNode` today does not surface `encrypted_body` cleanly; would need a parallel amendment.

### Alt B — Promote `fact_provenance` to do double duty

Add an `episode_ids` parameter to `fact_provenance` so the same function answers "given a fact, return the supporting episodes" and "given an episode UUID list, return episode bodies".

**Rejected.** Two function signatures sharing one name is a documentation footgun. `fact_provenance` is already load-bearing on ADR-0016 (per-claim citation envelope) — overloading it risks subtle regressions when the citation contract changes. Separate function, separate signature, separate ADR.

### Alt C — Expose `fetch_episode_contents` as public

Take the existing `src/gnokee/storage/graph.py:793` helper, lift it to `gnokee.__init__`, rename `fetch_episode_contents` → `get_episode_bodies`.

**Rejected.** Two reasons:

1. **Content-only, no metadata.** Returns `dict[UUID, str]`. Marrow needs `tenant_id`, `valid_at`, `asserted_at`, `sensitive`, `superseded_by`, etc. The metadata lives in Postgres (`episode_metadata`), not in Neo4j Episodic nodes.
2. **Reads from Neo4j, not Postgres.** Bi-temporal authoritative source is Postgres per ADR-0004 + ADR-0023. Reading from Neo4j risks stale views during in-flight ingest. `get_episodes` reads Postgres; Neo4j is enhancement.

### Alt D — `EpisodeMetadataRow` direct passthrough

Lift `storage.metadata.EpisodeMetadataRow` to public + add a `get_by_uuids` method on `MetadataStore`.

**Rejected.** `EpisodeMetadataRow` is an internal storage row; it has fields like `extraction_deferred`, `extraction_completed_at`, `extracted_quote` that are storage-internal and would be a leaky abstraction on the public API. `EpisodeRecord` is the curated public shape; mapping from `EpisodeMetadataRow` happens inside `get_episodes`.

## Consequences

### Positive

- Unblocks omur-core#472 `/memory/provenance/{id}` HTTP route + `GnokeeMemoryProvider.provenance` impl.
- Unblocks omur-core#471 extractor wire-up downstream of #472.
- Symmetric ingest/get surface — `ingest_episode` ↔ `get_episodes` use the same `EncryptedBody` envelope on both directions.
- One canonical "fetch episode by UUID" primitive; eval harnesses + examples + future adapters share it.
- Order-by-key contract is explicit, preventing implicit ordering bugs on the consumer side.

### Negative

- **New public surface area.** Once exported from `gnokee/__init__.py` `__all__`, the function name + signature + `EpisodeRecord` shape are semver-locked. Field additions to `EpisodeRecord` are minor-bump-safe; field removals or renames are breaking. Per ADR-0021 §"Versioning the public surface" the cost is real but bounded.
- **Postgres + Neo4j read amplification.** Each call hits `episode_metadata` + `episode_body_encrypted` join. For batches of 100 with mixed sensitivities, plan analysis (EXPLAIN) needed on the v0.12 PR to confirm index usage. Existing indexes: `episode_metadata (tenant_id, episode_uuid)` PK; `episode_body_encrypted (tenant_id, episode_uuid)` PK. Single index scan per side; planner should pick `ANY($2)` → nested-loop on the PK.
- **`EncryptedBody` envelope leakage risk.** If a caller misuses the envelope (e.g., logs it), the ciphertext + AAD + KMS ref leak together — same risk as ingest-side, no new exposure, but worth flagging in the API docstring with a security note.
- **Encrypted-body branch test surface doubles.** Integration tests must cover both sensitivity branches across `get_episodes`. Adds ~6 cases to the test matrix; manageable.

### Risks tracked elsewhere

- **Cross-tenant via short-ID translation** — out of scope for this ADR (caller passes UUID, not short-ID). When MCP exposure lands, ADR-0027 short-ID translation rules apply.
- **As-of replay** — deferred; `history_of(as_of=)` is the answer for time-travel reads.
- **Per-tenant rate limits** — deferred. v0.12 ships with the 100-UUID batch cap; rate-limiting is a separate concern across `gnokee_query` + `get_episodes` + `recall`.

## Acceptance

- `gnokee.get_episodes` exported from `gnokee/__init__.py` `__all__`.
- `EpisodeRecord` exported from `gnokee/__init__.py` `__all__`.
- Integration test class `tests/integration/test_get_episodes.py`:
  - Batch fetch of 5 episodes across 2 tenants → returns 5 from caller's tenant, 0 from other.
  - Public + encrypted body mix in one batch → correct branch per row.
  - Soft-deleted UUID in input → silently dropped from output.
  - Superseded episode → returned with `superseded_by` + `asserted_until` populated.
  - 101-UUID batch → `ValueError`.
  - RLS GUC set per call → confirmed via SET-LOCAL probe.
- `docs/api/python.md` documents the function + the `EncryptedBody`-on-return contract.
- `CHANGELOG` notes new public API.

## Open questions (resolved by omur-core#472 reply)

1. **Encrypted-body return shape** — `EncryptedBody` envelope passthrough OK, or do we need a thinner `EncryptedBodyRef` (KMS ref + AAD only) that forces a second round-trip to fetch ciphertext on demand? Default: full envelope passthrough, matches ingest-side symmetry.
2. **Batch cap** — 100 UUIDs reasonable for `/memory/provenance/{id}` usage, or does Marrow expect higher? Default: 100, revisit on first per-tenant rate-limit ADR.
3. **`our_id`-keyed lookup variant** — should there be a parallel `get_episodes_by_our_id(tenant_id, our_ids)` for callers that hold consumer-supplied keys, not gnokee UUIDs? Default: defer to a separate ADR; v0.12 is UUID-only.
