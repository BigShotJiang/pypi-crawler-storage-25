# ADR-0013: declarative envelope MCP tool `gnokee_query`

- **Status:** Proposed — schema, validation, and the bi-temporal /
  confidence_floor / topics / budget composition ship in v0.5. The
  `value` field is reserved-but-`null` (gnokee does not host an LLM;
  AGENTS.md "do not" list § "no LLM hosting"). Bi-temporal range
  filtering is implemented as a **post-recall filter** in v0.5: the
  caller's `valid_at_range.lte` becomes the recall pipeline's
  world-time pin, and the resulting facts are filtered against the
  full `valid_at_range` + `asserted_at_range` bounds before envelope
  assembly. Pushing the bounds down into Graphiti `SearchFilters` is
  deferred to v0.5.x. Status moves to Accepted once at least one host
  (Omur / noggin) calls the tool against a real corpus.
- **Date:** 2026-05-11
- **Decider:** Vadim Yuzi
- **Context:** Adoption candidate #1 from competitive-landscape 2026-Q2
  ([umbrella #71](https://github.com/omurlabs/gnokee/issues/71)),
  tracking [#72](https://github.com/omurlabs/gnokee/issues/72).
  Gated by ADR-0019 (confidence-decay, verdict
  `SHIP_RECENCY_AS_PROXY`) — this ADR consumes the recency-proxy as
  the `confidence_floor` semantics. Pairs with ADR-0016 (per-claim
  citation envelope) — `gnokee_query` returns the same `citations`
  map shape on the response.

## Context

gnokee today exposes five MCP tools: `gnokee_ingest_episode`,
`gnokee_recall`, `gnokee_fact_provenance`, `gnokee_lab_query`,
`gnokee_med_query`. Each is a vertical surface — recall returns
natural-language fact statements, the typed clinical queries return
typed rows. There is no **declarative envelope** that:

1. Lets the caller assert a bi-temporal filter range (both `valid_at`
   and `asserted_at`) on the read — recall accepts a single point
   pin, not a range.
2. Lets the caller assert a `confidence_floor` cutoff — recall has
   no such knob.
3. Routes between the vertical pipelines based on a `topics` hint
   without the caller knowing which tool serves which topic.
4. Surfaces contradictions as a flat list independent of any specific
   fact — recall attaches `contradicts[]` per `FactStatement`.

Pinecone Nexus shipped **KnowQL** in early-access 2026-05-04 with six
declarative primitives (`intent`, `filter`, `provenance`,
`output_shape`, `confidence`, `budget`). Google Cloud Memory Bank
shipped `lookup_context` (GA 2026-04-22) as a single-call grounding
surface with per-claim citations. Both compress the read surface to a
single envelope-shaped tool.

Source: synthesis at `research/competitive_landscape_2026-05-10.md`,
dossiers `research/_dossier_pinecone_nexus.md`,
`research/_dossier_gcp_knowledge.md`,
`research/_dossier_pinecone.md`.

**Observation:** the envelope shape is converging across peers, but
none of them ships **bi-temporal** filtering. KnowQL has zero time
axes; Memory Bank has one (created_at). gnokee already has both
(`valid_at` world-time, `asserted_at` source-tx-time, ADR-0001).
Adopting a declarative envelope and putting both axes on it is
differentiator-positive — strictly stronger than peer envelopes — and
keeps gnokee's existing red lines intact (no DSL, no auto-resolve, no
LLM hosting).

## Decision

Ship one new MCP tool `gnokee_query` accepting a declarative envelope
and returning a structured response that combines provenance, the
ADR-0016 citation envelope, ADR-0019 recency-proxy confidence, and
ADR-0008 contradiction surfacing. **Additive** to the existing tool
surface — `gnokee_recall` / `gnokee_lab_query` / `gnokee_med_query`
keep working unchanged. `gnokee_query` is the **general escape hatch**
for callers that want a single declarative call; the verticals stay
for callers that want a focused read.

### Module placement

A new module `src/gnokee/query.py` (sibling of `lab_query.py` /
`med_query.py`) hosts the Pydantic envelope models, the orchestrator
function `gnokee_query()`, and the response model. `src/gnokee/mcp.py`
adds one tool registration block — the registration footprint is
minimised so it merges cleanly against the parallel issue-#74
(`gnokee_wiki_export`) edits to the same file.

The issue body's `src/gnokee/mcp/tools/query.py` path is aspirational
— the repo today has a flat `mcp.py`, and refactoring it to a
`mcp/tools/` package is not justified by this PR alone. **Flat
sibling-module wins.** When v0.6 adds enough MCP tools to make the
flat file unwieldy, the package refactor is a separate ADR.

### Envelope — request shape

```jsonc
{
  "ask": "string — natural-language question",  // REQUIRED
  "filter": {                                    // REQUIRED
    "tenant_id":          "uuid",                // REQUIRED — see § Tenant scope
    "valid_at_range":     {"gte": "ISO-8601",    // OPTIONAL
                           "lte": "ISO-8601"},
    "asserted_at_range":  {"gte": "ISO-8601",    // OPTIONAL
                           "lte": "ISO-8601"},
    "topics":             ["clinical.lab",       // OPTIONAL
                           "clinical.med",
                           "general"]
  },
  "output_shape": "fact | episode | mixed",      // OPTIONAL, default "mixed"
  "budget": {
    "max_episodes":  20,                         // OPTIONAL
    "max_tokens":   200                          // OPTIONAL, default 200
  },
  "confidence_floor": 0.0                        // OPTIONAL, default 0.0
}
```

JSON-Schema validation runs at the MCP boundary via Pydantic v2
(`extra="forbid"`, `_require_utc` on every datetime field). Malformed
envelopes raise `ValidationError` and surface to the MCP client as a
structured error (FastMCP converts the Pydantic exception into a
JSON-RPC error envelope). The `tenant_id` field is mandatory — empty
string is rejected at the model boundary, missing field is rejected
at the JSON-Schema boundary.

### Envelope — response shape

```jsonc
{
  "value": null,                                 // RESERVED — see § value field
  "provenance": [
    {
      "episode_uuid": "uuid",
      "fact_uuid":    "uuid | null",
      "valid_at":     "ISO-8601",
      "asserted_at":  "ISO-8601",
      "source_uri":   "string | null",
      "score":        "float | null"
    }
  ],
  "confidence":      0.0,                        // recency-proxy aggregate, ADR-0019
  "contradictions": [
    { "episode_a":  "uuid",
      "episode_b":  "uuid",
      "fact_a":     "uuid | null",
      "fact_b":     "uuid",
      "verdict":    "refinement|update|contradiction",
      "axis":       "asserted_at" }              // v0.5: only asserted_at
  ],
  "citations": {                                 // ADR-0016 envelope
    "c1": { "episode_uuid": "uuid",
            "fact_uuid":    "uuid | null",
            "valid_at":     "ISO-8601",
            "asserted_at":  "ISO-8601",
            "extracted_quote": "string | null",
            "source_uri":      "string | null" },
    ...
  },
  "query_telemetry": {                           // extends #54 telemetry shape
    "topic":                  "general|clinical.lab|clinical.med",
    "max_episodes":           20,
    "max_tokens":             200,
    "facts_considered":       12,
    "facts_after_floor":      8,
    "facts_after_range":      5,
    "confidence_floor":       0.5,
    "recall_telemetry":       { ... },           // inline copy of RecallTelemetry
    "post_recall_filter":     true               // v0.5 always true
  }
}
```

### `value` is `null` in v0.5

gnokee does not host an LLM (AGENTS.md "do not" list § "no LLM
hosting"). The consumer's LLM synthesises the answer prose from
`provenance` + `citations`. The `value` field is **reserved** in the
envelope so a future host that wants to expose a synth-side adapter
can populate it without a breaking schema change. v0.5 emits `null`
everywhere — documented in the tool description.

This is the **NotebookLM-class trust posture** applied at the
envelope level: gnokee refuses to synthesise prose for the same
reason ADR-0016 refuses to synthesise an `extracted_quote` and
ADR-0019 refuses to synthesise a calibrated confidence. Each is a
deliberate "no" not a deferral — the consumer holds the LLM.

### `confidence_floor` semantics — ADR-0019 recency proxy

ADR-0019 verdict `SHIP_RECENCY_AS_PROXY` (Q13 spike, N=13): gnokee's
`confidence` is `exp(-Δt_days / 365)` where `Δt = caller_as_of -
fact.valid_at`. `gnokee_query.confidence_floor` filters facts whose
recency proxy is below the floor. Top-level `confidence` is the
arithmetic mean of the post-floor facts' proxies (or `0.0` when zero
facts survive the floor).

Documented in the tool description as **"minimum age-credibility
cutoff"** — NOT as a probability threshold. Cal_max = 0.41 from the
spike means a fact tagged `confidence=0.7` could actually be believed
by ~30–50% of users; consumers do not get to claim it as a
probability. Same caveat as `gnokee_recall.facts[].confidence`.

### `valid_at_range` / `asserted_at_range` — post-recall filter

The recall pipeline filters edges on `r.valid_at <= $valid_at` and
`r.invalid_at > $valid_at` (Cypher in `storage/graph.py
fetch_facts_for_episodes`). It accepts a single point pin, not a
range. v0.5 implements range filtering as a **post-recall filter**:

1. Set the recall pipeline's `valid_at` = `filter.valid_at_range.lte`
   (default: `utc_now()`) — keeps existing edge-half-pair semantics.
2. Set the recall pipeline's `as_of` = `filter.asserted_at_range.lte`
   (default: `utc_now()`) — keeps existing source-tx-time semantics.
3. After recall returns, post-filter the resulting `FactStatement`
   list:
   - drop facts whose `valid_at < valid_at_range.gte`
   - drop facts whose `asserted_at < asserted_at_range.gte` or
     `asserted_at > asserted_at_range.lte`
4. Compute `confidence` on the surviving facts (post-floor and
   post-range).

This is correct (edges that pass the half-pair filter are still
visible at the `lte`; the `gte` is a strict drop) and **bi-temporal
axis-safe** (`valid_at_range` filters `edge.valid_at` only;
`asserted_at_range` filters `edge.asserted_at` only via the metadata
lookup; neither touches `created_at`).

**v0.5.x follow-up:** push `valid_at_range.gte` and
`asserted_at_range` down into the Cypher edge filter as
`r.valid_at >= $valid_at_gte` and an `edge_asserted_at` index lookup.
Requires schema work on the metadata join (`episode_metadata.asserted_at`
already exists; the Cypher needs to JOIN through it).

### `topics` — v0.5 vocabulary

```
general       — default; routes to gnokee_recall
clinical.lab  — routes to gnokee_lab_query (history op, analyte from ask)
clinical.med  — routes to gnokee_med_query (history op, drug from ask)
```

The list is **open** — additional topics can be added without a
schema change (they are routed through `general` by default if not
recognised, with a `query_telemetry.unknown_topics[]` array surfacing
the unrecognised entries for debugging).

`topics` is a hint, not a hard filter. Multiple topics select a union
of pipelines; provenance from each is merged in stable order
(general → clinical.lab → clinical.med) before envelope assembly.

The intent extraction from `ask` for clinical topics (which analyte?
which drug?) is **out of scope for v0.5** — when a clinical topic is
selected without an explicit analyte/drug in the envelope, the
clinical pipeline returns empty rows. v0.6 may add an `ask`-parsing
helper to extract the analyte/drug name; v0.5 keeps the parsing
caller-side.

### `output_shape` — v0.5 semantics

```
fact     — only FactStatement-backed facts in provenance (drop excerpt + body rows)
episode  — only episode-body rows (drop facts; uses recall's episode_fallback lane)
mixed    — default; both
```

Fact shape requires the `fact_uuid` axis to be populated on every
provenance entry; `episode` shape drops `fact_uuid` (set to `null`).
`mixed` returns whatever the recall pipeline emits — facts +
excerpts + episode_fallback — with `fact_uuid` populated where
available.

### `budget` — extends #54 telemetry

`budget.max_tokens` maps to `recall(max_tokens=...)` directly. The
existing per-lane telemetry (`RecallTelemetry` — fact_budget,
excerpt_budget, body_budget) is mirrored into
`query_telemetry.recall_telemetry`. `budget.max_episodes` caps the
provenance list length (post-filter) — defaults to 20.

`query_telemetry` adds new counters specific to the envelope:

- `topic` — which pipeline served the request.
- `facts_considered` — count emitted by the underlying pipeline.
- `facts_after_floor` — count surviving `confidence_floor`.
- `facts_after_range` — count surviving range filter.
- `post_recall_filter` — always `true` in v0.5 (documents that
  bi-temporal range is implemented as a post-filter, not a
  Cypher-side push-down).

### Contradictions — surfaced, never auto-resolved

The contradiction list is built from the `surface_contradictions=True`
path in the recall pipeline. Each `FactStatement.contradicts[]` is
unwrapped into a flat list with both `fact_a` (the primary fact) and
`fact_b` (the counterpart). The `axis` field is fixed to
`"asserted_at"` in v0.5 — the `fact_contradiction` table records
`detected_at` (source-tx-time), not which axis the contradiction
fires on. A v0.6 amendment can split contradictions by axis if a real
consumer asks for it.

`tenant_scope: cross` is permanently rejected at the model boundary —
federation across tenants is a hard non-goal (AGENTS.md "do not"
list § "no federation"). The envelope accepts `tenant_scope: self`
(default) only; any other value raises `ValidationError`.

## Why it fits gnokee's red lines

- **Bi-temporal range filter is the primitive Pinecone cannot match**
  — `valid_at` + `asserted_at` are first-class on gnokee since
  ADR-0001. KnowQL has no temporal axis; Memory Bank has one. gnokee
  has two.
- **`confidence` is the ADR-0019 recency proxy**, not retrieval
  rerank score. Tool description documents it as a proxy, not a
  probability.
- **`budget` matches existing per-lane budget telemetry (#54)** — no
  new telemetry shape, just a new envelope-level surface.
- **Output is composition target for `gnokee_lab_query` /
  `gnokee_med_query`** — those stay as vertical helpers,
  `gnokee_query` is the general escape hatch.
- **`tenant_id` is on every read path** — same posture as every
  other gnokee MCP tool.
- **`value` is null** — gnokee does not host an LLM (AGENTS.md "do
  not" list).
- **Contradictions never auto-resolved** — surfaced as flat list,
  consumer decides (AGENTS.md "do not" list § "no auto-resolve").

## Why it differs from peers

- vs Pinecone KnowQL `confidence` = reranker score: gnokee
  `confidence` is the ADR-0019 recency proxy. Different semantics,
  documented in the tool description.
- vs KnowQL no temporal axis: gnokee has two (`valid_at` +
  `asserted_at`) plus the meta `created_at` (NOT exposed as a filter
  — `created_at` is ingest-system time, not a knowledge axis).
- vs KnowQL DSL: gnokee envelope is a single MCP tool. No DSL ships
  in v0.5 — the envelope IS the contract. The shape matches MCP
  tool-call shape directly.
- vs Memory Bank `lookup_context`: gnokee surfaces the citation
  envelope (ADR-0016) AND the contradiction list AND bi-temporal
  filter axes. Memory Bank ships citations + a single creation-time
  pin; gnokee ships citations + two world-meaningful axes + active
  contradiction surfacing.

## Schema change

None. `gnokee_query` reuses the existing tables (`episode_metadata`,
`lab_record`, `med_record`, `fact_contradiction`, Graphiti edges).
Migration `0013_episode_extracted_quote.sql` already landed for
ADR-0016 (issue #76) — it backs the citation envelope. The envelope
ships entirely on the read path; no DDL.

## Wire surface — `gnokee_query`

```jsonc
{
  "name": "gnokee_query",
  "input_schema": "QueryEnvelope (Pydantic v2)",
  "output": "QueryResponse",
  "description": "Single-call declarative envelope: ask + bi-temporal
    range filter + confidence_floor + topics + budget. Returns a
    structured response with provenance, citations (ADR-0016),
    recency-proxy confidence (ADR-0019), and contradictions
    (ADR-0008). gnokee never auto-resolves contradictions. The `value`
    field is reserved-but-null in v0.5 — the consumer's LLM
    synthesises the answer from provenance + citations."
}
```

## Why a single envelope (not a DSL)

KnowQL is a domain-specific query language with its own grammar. gnokee
deliberately does NOT ship one in v0.5:

1. **MCP-native.** The envelope shape matches the MCP tool-call shape
   directly — no parser, no error-prone grammar to evolve.
2. **JSON-Schema discoverability.** MCP clients introspect the input
   schema and get a typed view of every primitive (filter ranges,
   confidence_floor, topics, budget) for free.
3. **No grammar drift.** A DSL gains primitives over time and the
   parser becomes a load-bearing component. The envelope's set of
   keys is the contract; adding a key is a schema bump (which
   `extra="forbid"` makes loud).

## Anti-patterns to avoid

- **Auto-resolving contradictions inside the envelope.** Always
  return both sides + `contradictions[]`. The host LLM decides.
- **`tenant_scope: cross`.** Federation across tenants is a hard
  non-goal. Reject at the model boundary.
- **Populating `value` with an LLM-generated answer.** gnokee does
  not host an LLM. `value` stays `null` in v0.5.
- **Renaming the envelope to "knowledge engine"** — Pinecone-
  trademarked feel.
- **Synthesising a `valid_at_range` lower bound when the caller did
  not supply one.** Defaults to no `gte` bound (everything older
  than `lte` is in). Surfacing `valid_at_range.gte = utc_now()` by
  default would silently drop every fact.
- **Confusing `created_at` with `asserted_at` / `valid_at`.**
  `created_at` is ingest-system time — NEVER exposed as a filter
  axis. Only the two ADR-0001 axes are filterable.
- **Pushing the range filter down into Cypher in the same PR as the
  envelope.** v0.5 ships post-recall filtering; v0.5.x decides
  whether the push-down is worth it after a real consumer runs the
  envelope.

## Sequencing

- v0.5 — envelope, validation, post-recall range filter, `value: null`,
  ADR-0019 recency-proxy `confidence`, ADR-0016 citation envelope,
  ADR-0008 contradiction list, Q10 harness optional call path.
- v0.5.x — push range filters down into Cypher / metadata-join SQL
  if a real consumer runs envelope-shaped reads enough to make the
  post-filter latency a problem.
- v0.6 — clinical typed-store routing wired (#134): `clinical.lab` →
  `lab_pipeline.query(op="abnormal", analyte=None, ...)`; `clinical.med`
  → `med_pipeline.query(op="active", drug_name=None, ...)`. Safe-
  defaults posture — the envelope today carries no analyte/drug_name
  slot, so the orchestrator picks the most-common typed-store surface
  per topic. Typed-store rows extend the c-namespace contiguously and
  surface with `provenance[].source_uri = "lab_record" | "med_record"`;
  row counts surface in `query_telemetry.clinical_lab_rows` /
  `clinical_med_rows`. Per-axis contradiction labels; optional `value`
  populator adapter if a real consumer wires their own LLM.
- v0.6.1 — `ask`-parsing for clinical topics (analyte / drug-name
  extraction) so callers can ask "latest hemoglobin?" and get a
  typed-store latest-row response instead of the safe-default
  abnormal-labs lane. Heuristic only — no LLM (AGENTS.md no-LLM rule).
- Pairs naturally with ADR-0016 (#76) and ADR-0019 (#80) — all three
  target the MCP read surface in v0.5.

## Out of scope

- **DSL.** Not now, not in v0.5.x. The envelope IS the contract.
- **`gnokee_fact_history`.** That is #73 / ADR-0014 — fact-revision
  ledger. `gnokee_query` does point-in-time reads only.
- **Federation / `tenant_scope: cross`.** Permanent non-goal.
- **LLM-hosted `value` field.** gnokee does not host an LLM.
- **Per-tenant envelope-shape overrides.** v0.5 is single-default.

## Cross-refs

- Tracking issue: [#72](https://github.com/omurlabs/gnokee/issues/72).
- Umbrella: [#71](https://github.com/omurlabs/gnokee/issues/71)
  competitive landscape 2026-Q2.
- Gates: ADR-0019 confidence-decay (#80,
  `SHIP_RECENCY_AS_PROXY`); ADR-0016 per-claim citation envelope
  (#76) — same MCP read surface.
- Pairs with: ADR-0014 fact-revision ledger (#73, not yet drafted) —
  fact-history surface goes in `gnokee_fact_history`, not in
  `gnokee_query`.
- ADR-0001 (bi-temporal axes — `valid_at` vs `asserted_at` semantics).
- ADR-0004 (gnokee owns retrieval — envelope is the retrieval surface,
  not Graphiti's).
- ADR-0008 (contradiction storage — envelope surfaces the flat list).
- ADR-0009 (clinical lab typed store — clinical.lab topic routes here).
- ADR-0010 (med supersession adopt-with-gaps — clinical.med topic
  routes here).
- ADR-0012 (Path A recall fallback — envelope `output_shape: episode`
  consumes the same `episode_fallback` lane).
- AGENTS.md "do not" list — no UI, no LLM hosting, no key holding,
  no federation, no auto-resolve. Envelope respects each.
- Implementation: `src/gnokee/query.py` (orchestrator + Pydantic
  models), `src/gnokee/mcp.py` `gnokee_query` tool registration.
- Contract test: `tests/unit/test_query_envelope.py` — one test per
  axis (filter, budget, confidence_floor, output_shape) plus the
  rejection paths (missing tenant_id, `tenant_scope: cross`).
- Q10 LongMemEval harness amendment: optional call path through
  `gnokee_query` in `evals/spike_q10_cross_tool/adapters/gnokee_adapter.py`,
  selected via `GNOKEE_Q10_USE_QUERY_ENVELOPE=1` env flag. Do NOT
  change Q10 scoring — the path is additive so future runs can
  compare.

## Amendment 2026-05-17 — `output_shape:fact` adopted (#142, ADR-0014)

`output_shape: fact` is shipped in v0.10. When the consumer selects
`output_shape: "fact"` and provides `as_of`, every emitted fact's
`fact_text` + `valid_at` come from the latest `fact_revision` row at
`as_of` (per `FactRevisionStore.latest_revisions_at_for_fact_uuids`).
Facts with no revision at `as_of` drop out (consistent with
`wiki_export` past-`as_of` semantics).

`output_shape:"fact"` drops `excerpts[]` and `episode_fallback[]` from
the response; only `FactStatement` rows survive. Every provenance entry
populates `fact_uuid` (ADR-0013 hard requirement).

Q3 eval re-run on the v0.10 stack: median tokens = **172.5** (Q1
corpus, `top_k=3`, 12 queries; `tenant_id =
"q3-output-shape-fact"`; dump at
`evals/spike_q3_token_efficiency/results/20260521T192244Z-output-shape-fact.json`).
Validated baseline: 125 from Q3-mixed. Delta = **+47.5 tok / +38.0 %**
— the v0.10 envelope rendering came in *longer* than the Q3-mixed
baseline on this corpus, not shorter. The envelope is text-less by
design (consumer LLM synthesises prose); the harness renders the
Q3-shape comparison by looking the substituted `fact_text` up through
`FactRevisionStore.latest_revisions_at_for_fact_uuids` at the same
`as_of` `gnokee_query` used internally. The delta is therefore a
direct apples-to-apples token cost vs. the 125-tok Q3-mixed baseline.
Open question for the v0.10 sweep: whether the longer rendering is
intrinsic (fact statements are more verbose than the Q3-mixed first-
sentence excerpts), corpus-specific (Q1 vs the original Q3 mix), or a
budget knob worth tuning — recorded here for downstream investigation,
not auto-resolved.
