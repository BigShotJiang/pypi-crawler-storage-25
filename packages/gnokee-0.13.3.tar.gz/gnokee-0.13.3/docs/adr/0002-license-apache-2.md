# ADR-0002: License Apache 2.0

**Status:** Accepted
**Date:** 2026-05-07

## Context

gnokee is consumed by Omur — a managed personal-health-AI SaaS that the
project author operates. Under AGPL-3.0, Omur would inherit
source-publication obligations on internal modifications. AGPL also
introduces friction for any future commercial consumer (e.g. another
SaaS adopting gnokee).

## Decision

Apache License 2.0.

## Alternatives considered

| License        | Rejected because…                                                       |
|----------------|-------------------------------------------------------------------------|
| AGPL-3.0       | Friction for Omur and future commercial adopters                        |
| MIT            | Maximum permissiveness; no patent grant; no protection                  |
| BUSL           | Time-limited proprietary then OSS; community-unfriendly                 |
| SSPL           | Mongo's; controversial; few adopters                                    |

## Consequences

- Hyperscaler-fork extraction is theoretically possible but the moat is
  engineering quality + eval numbers, not the license
- Re-evaluate at v1.0 if hyperscaler-fork pressure appears
- Patent grant is automatic under Apache; no separate CLA needed at v0.x
- Compatible with Graphiti's current license (review before each major
  upstream upgrade)
