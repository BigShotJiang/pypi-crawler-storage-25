# ADR-0008: Contradiction storage in `fact_contradiction` Postgres table

- **Status:** Accepted
- **Date:** 2026-05-08
- **Decider:** Vadim Yuzi
- **Context:** v0.1 specialist sweep on `docs/specs/v0.1.md`

## Context

The Q4 spike validated that gpt-4o-mini classifies fact pairs into
`unrelated | refinement | update | contradiction` with ~80% recall.
The original v0.1 spec stored each verdict as a CONTRADICTS edge in
Graphiti. The graphiti-specialist review on commit 4190708 surfaced
that this is not representable in Neo4j: Graphiti models facts as
`(EntityNode)-[EntityEdge: RELATES_TO]->(EntityNode)`, and Neo4j does
not allow a relationship to be the source or target of another
relationship.

## Decision

Store contradictions in a Postgres table:

```sql
CREATE TABLE fact_contradiction (
    tenant_id          TEXT        NOT NULL,
    fact_uuid_a        UUID        NOT NULL,
    fact_uuid_b        UUID        NOT NULL,
    verdict            TEXT        NOT NULL,
    detected_at        TIMESTAMPTZ NOT NULL,
    summary_a          TEXT        NOT NULL,
    summary_b          TEXT        NOT NULL,
    PRIMARY KEY (tenant_id, fact_uuid_a, fact_uuid_b)
);
```

`fact_uuid_a` and `fact_uuid_b` reference Graphiti `EntityEdge.uuid`
values. They are not pg foreign keys — Neo4j is the source of truth
for fact existence.

## Rationale

- Faithful to Neo4j's model: edges connect nodes, not other edges.
- Avoids inventing synthetic Entity nodes ("Contradiction_<uuid>")
  which would pollute Graphiti's entity graph and confuse the
  extractor.
- pg already owns `episode_metadata` and `content_embedding`. Adding
  one more table preserves the "Graphiti for graph storage; pg for
  retrieval-side metadata" boundary established in ADR-0004.
- `(tenant_id, fact_uuid_a, fact_uuid_b)` PK gives O(1) lookup and
  easy `UNION ALL` for stage 5 contradiction join in retrieval.

## Consequences

- Contradiction detection writes pg, not Neo4j. ADR-0004 reserves pg
  for retrieval-side metadata; this is consistent.
- Stage 7 of ingest (Q4 contradiction pipeline) does cosine search via
  raw Cypher against Neo4j's vector index on `EntityEdge.fact_embedding`,
  then writes the verdict to pg. The cosine search is a *read* against
  Neo4j; the write is to pg. Boundary preserved.
- Cross-tenant isolation enforced at `WHERE tenant_id = $tenant`.
- v0.2 supersession write paths must add a temporal filter to the
  retrieval-side join (`exclude contradictions where either fact has
  asserted_until <= $as_of`). Tracked in spec §5 stage 5.

## Alternatives considered

- **Edge property `contradicts: list[uuid]` on each EntityEdge.** Works
  but no relationship between counterpart edges is queryable
  symmetrically without two reads. Cypher must scan all edges to find
  contradictions involving a target uuid. Worse for retrieval.
- **Synthetic Entity nodes per contradiction.** Pollutes the entity
  graph, breaks the assumption that EntityNodes are real-world things.
  Confuses Graphiti's deduplication.

## Revisit triggers

- A future Graphiti version supports edge-of-edge relationships
  (unlikely; would need a Neo4j model change).
- Cross-tenant federated retrieval where a single SQL view across
  tenants is needed — a graph-side representation may simplify it.

## Amendment: Q41 spike verdict (2026-05-11)

`evals/spike_q41_refusal/` ran end-to-end against the live gnokee stack
(v0.4+) with 40 corpus episodes ingested across four `group_id` namespaces.
Full-run JSON dump: `evals/spike_q41_refusal/results/20260511T183112Z.json`
(gitignored; summary inlined below for the durable record).

### Verdict: ADOPT

All four source-grounded refusal contracts were enforced by the shipped stack
without any prompt tuning or code change.

### Per-sub-type results

| Sub-type | Shape | Pass | Threshold | Verdict |
|---|---|---|---|---|
| Q-X.1 (fully answerable) | 10 probes, single-citation answers | 9/10 (90%) | >= 80% | MET |
| Q-X.2 (partially answerable) | 10 probes, partial coverage | 10/10 (100%) | >= 60% | MET |
| Q-X.3 (not answerable) | 10 probes, strict zero hallucination | 10/10 (100%) | 100% | MET |
| Q-X.4 (contradicting episodes) | 10 probes, both-sides surfacing | 10/10 (100%) | >= 70% | MET |
| Q-X.5 (cross-tenant, stretch) | 5 probes, empty tenant isolation | 5/5 (100%) | 100% | MET |

### Per-query notes

**Q-X.1 — single miss (p_x1_03):** "Does Alex Morgan have any drug
allergies?" returned 7 facts but none contained the keywords `sulfonamide`,
`trimethoprim`, or `allergy`. Graphiti extracted the clinical episode as a
medication fact (levothyroxine / Dr. Mackay) rather than an allergy entity.
This is the same Graphiti literal-extraction gap observed in Q13 (numeric
phrases). The allergy was in the corpus; retrieval scored it below top-7.
**Not a hallucination** — all returned facts are grounded. This is a recall
ranking issue, not a refusal contract violation.

**Q-X.2 — over-generation note:** All 10 probes returned 7-9 facts, exceeding
`expected_max_facts` (set to 4-5 in queries). This reflects `top_k=10` on a
10-episode corpus — gnokee returns most of the corpus for every query. The
over-generation does not cause hallucination: all returned facts are corpus-
grounded. The `expected_max_facts` field was informational only (not a pass/
fail gate for this spike). A separate spike on top_k calibration is warranted.

**Q-X.3 — clean refusal with non-zero facts:** gnokee returned 7-8 renovation
facts in response to investment queries. This is correct behavior: the corpus
exists under `spike_q41_x3` and is recalled against any query. The strict
check is that returned facts contain no forbidden investment entity — all 10
probes passed this check. gnokee does NOT refusal-suppress off-topic corpus
facts; it simply has nothing hallucinated to return. This is weaker than
NotebookLM's explicit "I can't answer that from these sources" refusal. The
distinction is a product UX gap, not a contract violation at the data layer.
Filed as a follow-up under issue #77.

**Q-X.4 — contradiction surface firing reliably:** All 10 probes showed
`contradictions` non-empty (3-6 per response). The contradiction pipeline
(ADR-0008 `fact_contradiction` table, Stage 5 retrieval join) fires correctly
on all four contradiction pairs (salary, heart rate, work arrangement, GP).
Several probes also passed the text-level both-sides check (both salary figures
or both GP names in fact texts). The no-auto-resolve contract is enforced.

**Q-X.5 — cross-tenant isolation holds:** All 5 probes against the empty
`spike_q41_x5` tenant returned zero facts. No bleed from the x1 corpus.
The `WHERE tenant_id = $tenant` isolation in both Neo4j Cypher and Postgres
queries is effective.

### What this confirms for ADR-0008

1. The `fact_contradiction` table + Stage 5 retrieval join surfaces both sides
   of a contradiction in every probe (10/10). The no-auto-resolve contract is
   enforced end-to-end on the Python API surface.
2. Cross-tenant isolation via `tenant_id` predicate holds (5/5 cross-tenant
   stretch probes clean).
3. The `contradictions[]` field on `FactStatement` is populated with
   `ContradictionRef` objects for all contradiction pairs in the corpus.
4. `supersession_hints[]` was not needed for any contradiction probe — the
   contradiction table alone was sufficient. This is expected: the x4 corpus
   does not use `corrects:` (supersession chain); it relies on temporal
   contradiction detection at ingest.

### Open gap to file

- gnokee does not emit an explicit "I cannot answer from my sources" refusal
  signal when no corpus facts address the query domain. It returns off-topic
  facts from the corpus (renovation facts in response to investment queries).
  This is weaker than NotebookLM-class refusal. Filing as a follow-up UX issue
  separate from the data-layer contract tested here.
- The allergy extraction gap (p_x1_03) is a Graphiti literal-extraction
  coverage issue tracked in Q13 follow-up. Not a refusal contract issue.

### Cross-refs

- Issue [#77](https://github.com/omurlabs/gnokee/issues/77) (spike request).
- Issue [#94](https://github.com/omurlabs/gnokee/issues/94) (Q-X.3 refusal-posture
  UX gap follow-up — gnokee returns off-topic facts instead of explicit
  refusal).
- Issue [#95](https://github.com/omurlabs/gnokee/issues/95) (Q-X.1 allergy
  fact-ranking follow-up — medication episode outranked allergy episode;
  distinct from #90 literal-numeric extraction gap).
- `evals/spike_q41_refusal/` spike directory.
- ADR-0019 (confidence model) — Q-X.3 finding (returns off-topic facts, not
  explicit refusal) connects to confidence surfacing: a consumer agent using
  the `confidence` recency proxy can rank off-topic facts low even if returned.
