# ADR-0006: Postgres migrations via raw SQL files

- **Status:** Accepted
- **Date:** 2026-05-08
- **Decider:** Vadim Yuzi
- **Context:** v0.1 implementation, `docs/specs/v0.1.md`

## Context

gnokee v0.1 introduces three Postgres tables (`episode_metadata`,
`content_embedding`, `fact_contradiction`) plus an HNSW index on the
embedding column. Schema evolution will continue through v0.2+ as
forget paths, RLS, and KMS hooks land.

Two options for managing DDL changes:

1. **Alembic** — the de-facto Python migration tool. Auto-generates
   migration scripts from SQLAlchemy models; supports up/down with a
   versions DAG.
2. **Raw SQL files** — `migrations/NNNN_<name>.sql` applied in order
   by a one-shot runner; tracked in `gnokee_schema_migrations`.

## Decision

Use raw SQL files. v0.1 ships three tables. The schema is small,
hand-authored, and PR-reviewable as plain SQL — exactly the level of
control we want for an audit-grade memory store.

## Rationale

- Alembic adds a SQLAlchemy ORM dependency we do not otherwise need.
  All gnokee Postgres code in v0.1 uses asyncpg directly.
- Auto-generation requires a model→DDL bidirection that does not exist
  yet; we would author the migrations by hand anyway.
- Raw SQL makes ADR review of schema changes immediate — no Alembic
  diff to read.
- Drift between models and DDL is a real concern at v0.5+; revisit
  then if it materialises.

## Consequences

- One additional Python module: `gnokee.storage.migrate` (≤80 LOC).
- No down-migration support in v0.1; reset = drop the database.
  Acceptable for a project with no shipped consumers.
- Migrations applied at startup of integration tests and `make migrate`.

## Revisit triggers

- ≥10 cumulative migrations.
- Need for non-trivial backfills (data migrations as opposed to schema).
- Multiple developers landing migrations concurrently and order conflicts.
