# ADR-0027: MCP short-ID translation — stable per-tenant per-kind identifiers at the MCP boundary

- **Status:** Accepted
- **Date:** 2026-05-17
- **Driver:** Issue [#197](https://github.com/omurlabs/gnokee/issues/197) — replace raw 36-char UUIDs in `gnokee_*` MCP tool responses with stable, short, human-recognisable identifiers
- **Supersedes:** none
- **Amends:** none (additive — accept-both input preserves existing UUID callers)
- **Refs:** [ADR-0013](0013-gnokee-query-envelope.md) (declarative envelope surface), [ADR-0014](0014-fact-revision-log.md) (fact-grain lineage IDs), [ADR-0016](0016-per-claim-citation-envelope.md) (citation envelope), [ADR-0026](0026-forget-pipeline.md) (forget sweep covers short_id tables), [Plan: docs/superpowers/plans/2026-05-17-v0.10-clinical-mcp-polish.md](../superpowers/plans/2026-05-17-v0.10-clinical-mcp-polish.md), [Spec: docs/superpowers/specs/2026-05-17-v0.10-clinical-mcp-polish-design.md](../superpowers/specs/2026-05-17-v0.10-clinical-mcp-polish-design.md)

## Context

Every `gnokee_*` MCP tool today emits raw 36-character UUID strings for `episode_uuid`, `fact_uuid`, and `target_node_uuid` / `source_node_uuid`. UUIDs are the right primary key for storage — globally unique, allocation-free, never collide across tenants — but they are the wrong surface for an LLM consumer:

- An LLM that needs to reference the same episode twice in one answer must echo the full 36 characters each time. Token cost compounds: in a recall response with 10 facts + 5 citations + a contradiction lane, the wire envelope carries 15–20 UUIDs ≈ 600–800 tokens of identifier noise before the first fact text.
- The LLM cannot easily eyeball whether two `[c2]`/`[c4]` markers point at the same source. The `c1, c2, …` keys in the ADR-0016 citation envelope work as conversation-local handles but do not survive tool-call boundaries — re-recall returns fresh `c1`/`c2` keys.
- Operators reading audit logs (forget_audit, ingest_journal) eyeball UUIDs every day. Short IDs make those logs an order of magnitude more scannable.
- Test fixtures and CLI output (`gnokee_history_of`, `gnokee_fact_history`) become 5× more readable when the UUID column collapses from `8f3a…-ed8c-…-9b4c` to `ep_017`.

gnokee already runs a per-tenant Postgres state space (RLS on every tenant-scoped table) and already issues a SERIALIZABLE ingest transaction per episode. The cost of allocating a monotonic per-tenant per-kind sequence number alongside the existing write is negligible — one extra UPSERT + one INSERT inside the same transaction.

## Decision

**gnokee translates every UUID emitted by a `gnokee_*` MCP tool through a per-tenant per-kind monotonic short-ID map. Short IDs use the regex `^(ep|fact|ent)_\d+$` (e.g. `ep_017`, `fact_042`, `ent_005`). Input parameters accept BOTH short IDs and raw UUIDs — `parse_short_or_uuid` decodes whichever form the caller supplied. The map is stored in two new Postgres tables (`short_id_map` + `short_id_seq`) with RLS for tenant isolation. The forget pipeline sweeps both tables on tenant delete.**

### Prefix vocabulary

| Prefix | Kind | Source UUID column |
|---|---|---|
| `ep`   | episode  | `episode_metadata.episode_uuid` |
| `fact` | fact     | Graphiti edge UUID (Entity-Edge-Entity) |
| `ent`  | entity   | Graphiti node UUID (planned for v0.10+) |

Three prefixes only. We deliberately do NOT add `rev` for `FactRevision.revision_id` — revisions are scoped under a fact and identified by their position in the fact's history; the LLM-facing handle stays the fact short ID + `as_of`.

### Translation rules

1. **Encode (UUID → short_id).** On every emit site in `mcp.py`, replace `str(some_uuid)` with `await short_id.encode(pool, tenant_id=..., kind=..., target_uuid=...)`. First emit allocates a row in `short_id_map` and bumps the per-tenant per-kind counter in `short_id_seq`; subsequent emits hit the unique index and return the cached value.

2. **Decode (short_id → UUID).** `short_id.decode(pool, tenant_id, short_id)` looks up `(tenant_id, short_id)` in the unique index and returns the UUID, or raises `ValidationError` if no row exists.

3. **Parse-either input.** `short_id.parse_short_or_uuid(pool, tenant_id, value)` first tests `value` against `SHORT_ID_RE`; on match it decodes, otherwise it parses as a `uuid.UUID`. This is the only function the MCP layer should call when accepting an ID from the caller. The Python API (direct library callers) keeps UUID-only signatures — short IDs are a wire-format concern.

### Concurrency

Two concurrent ingests of the same UUID under the same tenant could race the `INSERT … ON CONFLICT DO NOTHING` window. We need both writers to agree on the same short_id. The implementation uses a per-(tenant_id, kind) Postgres advisory lock for the duration of the encode transaction:

```python
await conn.execute(
    "SELECT pg_advisory_xact_lock(hashtext($1), hashtext($2))",
    tenant_id, kind,
)
```

This serialises the counter bump + insert per `(tenant_id, kind)`. The lock is transaction-scoped — `_xact_` variants auto-release at COMMIT/ROLLBACK — and `hashtext` keeps the lock-key pair compact (Postgres advisory locks take a pair of `bigint`). Different `(tenant_id, kind)` pairs do not block each other.

After the lock, the encode uses an UPSERT-style counter bump + `INSERT … ON CONFLICT (tenant_id, target_kind, target_uuid) DO NOTHING` followed by a re-read. The re-read makes the function idempotent under the rare case where the advisory lock somehow fails to serialise (e.g. mis-configured `hashtext` collision): both writers re-read the same row and return the same short_id.

### Retention — survive forget at episode grain, swept at tenant grain

The forget pipeline sweep matrix:

| Operation | `short_id_map` behaviour |
|---|---|
| `gnokee_forget_episode(cascade=False)` | KEEP rows — audit logs reference deleted episodes by short_id; we must remain able to decode `ep_017` to the original UUID for the audit story |
| `gnokee_forget_episode(cascade=True)`  | KEEP rows — same rationale |
| `gnokee_forget_tenant(dry_run=False)`  | DELETE rows — entire tenant is gone, no audit consumer for stale IDs |

The audit-decodability rationale: `gnokee_maintenance.forget_audit` survives tenant deletion (schema-isolated, per ADR-0026 §4.2), but it stores raw UUIDs. The short_id_map gives operators reading forget_audit a way to translate audit-row UUIDs back to the short IDs they saw in earlier MCP responses. Sweeping the map on tenant-forget aligns with "tenant deletion erases all tenant-scoped state"; episode-forget is a narrower operation where the IDs remain useful for audit reconstruction.

### Schema (migration 0022)

```sql
CREATE TABLE short_id_map (
    tenant_id    TEXT  NOT NULL,
    target_kind  TEXT  NOT NULL CHECK (target_kind IN ('ep', 'fact', 'ent')),
    target_uuid  UUID  NOT NULL,
    short_id     TEXT  NOT NULL,
    seq          BIGINT NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (tenant_id, target_kind, target_uuid),
    UNIQUE (tenant_id, short_id)
);

CREATE TABLE short_id_seq (
    tenant_id    TEXT NOT NULL,
    target_kind  TEXT NOT NULL,
    next_seq     BIGINT NOT NULL DEFAULT 1,
    PRIMARY KEY (tenant_id, target_kind)
);

ALTER TABLE short_id_map ENABLE ROW LEVEL SECURITY;
ALTER TABLE short_id_seq ENABLE ROW LEVEL SECURITY;
-- + tenant_isolation policies via DO-block guard (mirror 0020)
```

The composite PK `(tenant_id, target_kind, target_uuid)` is the encode lookup index; the `UNIQUE (tenant_id, short_id)` is the decode lookup index and the safety belt against concurrent first-emits diverging.

## Consequences

### Positive

- LLM-facing tool output drops 25–35 characters per ID emit. Compounding across a typical 10-fact recall response, this saves 300–500 tokens.
- Audit logs become scannable. `forget_audit` rows joined against `short_id_map` give operators a human-readable trace.
- Tests + CLI demos look better. `gnokee_history_of(ep_007)` reads naturally.
- Accept-both input means existing in-flight conversations using full UUIDs keep working — zero break.

### Negative

- One extra Postgres round-trip per emitted ID per tool call. The encode is cached after the first emit (subsequent calls hit the unique index), but the first emit pays an INSERT + counter bump. For a recall response with 10 fresh facts this is 10 extra writes inside the existing transaction.
- The `short_id_map` table grows linearly with the number of distinct facts + episodes per tenant. For a single-user noggin/gnokee deployment this is bounded (≤10k rows over a lifetime); for a multi-tenant hosted scenario it is one row per `(tenant, fact_uuid)` pair. Both fit comfortably in pgvector-sized Postgres.
- A new pair of tables to forget-sweep. The sweep is a two-line addition to `forget_tenant`'s SERIALIZABLE transaction; the cost is negligible.
- Short IDs are not globally unique — `ep_017` exists per tenant. This is by design (per-tenant counter), but means cross-tenant audit tooling must always carry the tenant_id alongside the short_id. Operators reading `forget_audit` already do this.

## Rejected alternatives

### Deterministic hash of (tenant_id, uuid)

A short ID derived as `ep_` + 8 chars of base32(sha256(tenant_id || uuid)) would avoid the counter table entirely. Rejected because:

- The output is not monotonic — operator-friendly ordering (`ep_001 < ep_002 < ep_003`) is lost.
- Hash output is collision-prone in a per-tenant scope: with ~10⁵ facts per tenant and 8 chars of base32 (40 bits ≈ 10¹²), Birthday-paradox collisions appear at ~10⁶ facts — borderline but not zero. A counter is collision-free by construction.
- A hash is not idempotent across deployments if we ever salt it; a counter row is the explicit storage of the binding.

### UUID suffix (last 8 hex chars)

`ep_` + UUID's last 8 hex chars (e.g. `ep_8f3aed8c`). Rejected because:

- Same Birthday-paradox collision concern as the deterministic hash (8 hex chars = 32 bits, collisions at ~10⁵ facts in a single tenant).
- Not monotonic.
- The output looks like part of the UUID — caller confusion when debugging.

### In-memory map only

Hold the `uuid → short_id` map in a process-local dict, repopulate from storage on cold start. Rejected because:

- Multi-process MCP deployments (gnokee + noggin both connect to the same Postgres) need a shared truth source. A per-process dict diverges across processes.
- Cold-start cost is O(facts × episodes) on every process boot — not acceptable for a low-latency MCP tool.
- The state IS data — putting it in Postgres alongside the rest of the gnokee state is the obvious place.

## Cross-refs

- **ADR-0013** — the declarative envelope returns `provenance[].episode_uuid` and `provenance[].fact_uuid`; both flow through `short_id.encode` in this ADR.
- **ADR-0014** — `gnokee_fact_history` returns `fact_id` + per-revision `revision_id`. The fact_id is the logical UUID, translated to `fact_<seq>`; revision_id stays UUID for now (revisions are scoped under the fact).
- **ADR-0016** — citation envelope `c1, c2, …` keys are conversation-local; ADR-0027's short IDs are tenant-scoped and persistent. The two systems compose: a citation entry now carries a short `episode_uuid` instead of a 36-char one.
- **ADR-0026** — `gnokee_forget_tenant` sweep extended to cover `short_id_map` + `short_id_seq`.
