# ADR-0009: Clinical lab results need a structured store; off-ramp from graphiti edge facts

- **Status:** Accepted
- **Date:** 2026-05-08
- **Decider:** Vadim Yuzi
- **Context:** Q7 spike — `evals/spike_q7_lab_results/` v0.1.1 validation against
  Omur clinical-lab query patterns. Closes the open promise from ADR-0001 + Q1
  ("graphiti's bi-temporal model handles … both target consumers (Omur health-AI
  SaaS + personal-AI agents)") that v0.1's Q1 spike never validated on lab data.

## Context

ADR-0001 adopted graphiti based on the Q1 spike against engineering /
personal-AI notes. ADR-0001 § "Open questions" leaves for a later spike:

> *"Q1 only exercised personal-AI / engineering notes. Validate the
> bi-temporal claim on Omur's clinical shapes (labs, meds, wearables)
> before v0.2."*

Q7 ran the v0.1.1 stack (preprocessor + recall + currency-anchor +
excerpts) against a synthetic 10-panel longitudinal lab corpus
(BMP / CBC / iron studies over 12 months, including one lab correction
exercising the supersession axis), with 15 query patterns covering:

- single-value-on-date (post-correction + pre-correction via `as_of`)
- trend across episodes
- reference-range comparison
- min / max aggregations
- anomaly filters (abnormal in date range)
- supersession trail
- cross-domain link (med-explains-lab)
- panel count / units recall

Per `evals/spike_q7_lab_results/README.md`, decision criterion:

| pass% | outcome |
|---|---|
| ≥ 80 % | Adopt for clinical labs |
| 50 % – 80 % | Adopt with documented gap-fillers |
| < 50 % | Off-ramp |

Result: **pass = 2 / 15 (13.3 %), partial = 10, fail = 3, error = 0** →
**OFF-RAMP**.

## Decision

**Clinical labs do not go through graphiti's edge-fact extraction
in v0.2.** A structured Postgres table sibling to `content_embedding` —
working name `lab_record` — stores parsed analyte / value / unit /
reference-range / valid_at / asserted_at rows. graphiti continues to
own the *prose* episode (the panel notes, the clinician comments,
cross-document links to medications). Recall federates the two stores
on the read path the same way Q4 contradictions already federate
graphiti edges with the `fact_contradiction` Postgres table (ADR-0008).

The v0.1.1 stack is **not** wrong for clinical labs in shape — it just
hits a single hard limit (described below) — but the cost / reliability
of working around that limit at the LLM layer (prompt engineering the
extractor to never normalise numerics) is higher than landing a typed
table for the structured part.

## Rationale — what Q7 actually showed

The `partial` verdicts dominate (10 / 15). In every partial, recall
returns the *correct* episode set: cosine over `content_embedding`
already lands the lab panels that match the question. What fails is
the *value* — the literal `2.8 mmol/L`, the `3.5-5.0` reference range,
the `mg/dL` unit. Graphiti's edge-fact LLM consistently summarises
these into category-level facts:

- expected: `Potassium: 2.8 mmol/L (ref: 3.5-5.0) — critical low`
- got (`r.fact`): `The patient had a critical hypokalemia event in April 2024.`

The narrative is preserved, the numerics are gone. Excerpts from #7
recover *one* line per ranked episode (the first amount-bearing
match), but multi-analyte panels carry 8–12 amount lines and the agent
gets one. The same root cause filed #6 / #7 / #8 in the personal-AI
domain; in clinical, the cost of the workaround is no longer worth it
because every panel is structured by definition (analyte / value /
unit / range, in fixed columns).

The `fail` verdicts are the deliberately-hard aggregations
(`q_k_lowest_2024`, `q_panel_count_2024`, `q_creatinine_latest`).
gnokee never promised SQL-style aggregation through `gnokee_recall`;
the failures here are diagnostic, confirming a structured table is
needed for reliable answers.

The `pass` verdicts (`q_k_specific_date_post_correction`,
`q_full_panel_dec`) confirm the bi-temporal supersession axis works
on the panel-level *narrative* — the corrected April panel surfaces
when `valid_at = 2024-04-10`, the original surfaces when
`as_of = 2024-04-20` (pre-correction tx-time pin). The half-pair
discipline from ADR-0004 carries clinical labs *as documents*, just
not as values.

## Consequences

### Schema (v0.2 implementation)

```sql
CREATE TABLE lab_record (
    tenant_id        TEXT        NOT NULL,
    episode_uuid     UUID        NOT NULL,
    analyte          TEXT        NOT NULL,         -- "Potassium", "Hemoglobin"
    loinc_code       TEXT        NULL,              -- when available
    value_numeric    NUMERIC     NULL,              -- machine-readable amount
    value_text       TEXT        NULL,              -- "<5", "trace", non-numeric
    unit             TEXT        NULL,              -- "mmol/L"
    ref_range_low    NUMERIC     NULL,
    ref_range_high   NUMERIC     NULL,
    abnormal_flag    TEXT        NULL,              -- "L" / "H" / "C" / NULL
    valid_at         TIMESTAMPTZ NOT NULL,          -- sample drawn time
    valid_until      TIMESTAMPTZ NULL,              -- supersession on correction
    asserted_at      TIMESTAMPTZ NOT NULL,          -- result reported time
    asserted_until   TIMESTAMPTZ NULL,
    PRIMARY KEY (tenant_id, episode_uuid, analyte, valid_at)
);
```

Bi-temporal half-pairs match `episode_metadata` so retroactive
corrections supersede in the same way panel narratives do. Population
strategies (in priority order):

1. **Structured ingest.** When the consumer hands gnokee a panel as
   structured data (HL7, FHIR, lab CSV), gnokee writes `lab_record`
   rows directly. No LLM extraction needed.
2. **Deterministic parser.** When the consumer hands gnokee a markdown
   panel (the v0.1 shape), a `gnokee.extract.rules.lab_parser` extends
   the preprocessor pipeline to recognise the
   `- Analyte: value unit (ref: low-high)` shape and emit `lab_record`
   rows alongside the existing `Derived facts:` block. Falls back to
   `value_text` when the value isn't parseable.
3. **LLM-extracted (last resort).** Only for truly free-form panels;
   gnokee does not vendor the LLM, the consumer's endpoint runs.

### MCP surface

`gnokee_recall` gains an `analyte` filter parameter; structured rows
are returned in a new `RecallResponse.lab_rows[]` field alongside
`facts[]` / `excerpts[]`. Token budget gets a fourth slice. Backwards
compatible — existing consumers see empty `lab_rows`.

A new MCP tool `gnokee_lab_query` exposes typed aggregations
(`min`, `max`, `avg`, `latest`, `count`) over `(tenant, analyte,
date_range)` so agents stop trying to coerce SQL math out of fact
text. Mirrors the `gnokee_fact_provenance` lazy-handle pattern.

### Out of scope for v0.1.x

This ADR commits the *design*; the implementation is v0.2 work. v0.1.1
ships as-is; clinical Omur consumers who need lab math today should
either:

- Carry the structured shape themselves (Omur's existing
  Marrow / parsing layer is a natural home), and emit pre-flattened
  natural-language facts as gnokee episodes for the narrative half.
- Wait for v0.2 — `lab_record` table + parser will land before tag-cut
  for the clinical consumer.

### Wearables (Q9, not yet run)

Wearable time-series at sample-per-minute rates is a different
problem (cost, not summarisation). Q9 spike will measure ingest cost
and decide a separate off-ramp; this ADR does not pre-commit a
direction for that domain.

## Status notes

- **Schema landed:** migration `0006_lab_record.sql` (commit on
  2026-05-09).
- **Write path landed:** PR #9 (`feat(clinical): lab + med structured
  write path during ingest`) — deterministic markdown parser
  `extract/clinical/lab_parser.py` writes `lab_record` rows inside
  Stage 6 of the ingest txn.
- **Read path landed:** PR #10 (`feat(mcp): gnokee_lab_query — typed
  clinical-lab reads (ADR-0009)`) — `lab_query.py` orchestrator +
  `gnokee_lab_query` MCP tool with `latest | history | min | max |
  avg | count` ops. Both bi-temporal half-pairs mandatory.
- **v0.2 re-spike (2026-05-09, fresh tenant `spike-q7-v0_2`):**
  pass = **10/15 (66.7 %) → ADOPT_WITH_GAPS**, up from v0.1.1's
  **2/15 (13.3 %) OFF-RAMP**. The +53.4 percentage-point lift
  validates the typed-store decision. Remaining failures:
  - `q_k_lowest_2024` (FAIL): supersession-aware `min` aggregation —
    the v0.2 ingest writes new `lab_record` rows on a correction but
    does not yet set `asserted_until` on the prior row, so visible
    `MIN(value_numeric)` includes the original 2.8 mmol/L instead of
    the corrected 3.6 mmol/L. **v0.2 follow-up gap.**
  - `q_correction_audit` (PARTIAL): narrative-only — graphiti's
    edge-fact LLM doesn't preserve the literal `CORRECTION` marker.
    Unchanged from v0.1.1; orthogonal to typed store.
  - `q_med_lab_link_furosemide` (PARTIAL): cross-domain narrative;
    typed store doesn't help. Same as v0.1.1.
  - `q_panel_count_2024` (PARTIAL): `count` op returns scalar but
    can't backfill episode_uuids; passes count substring but missing
    episode-coverage. Acceptable v0.2 limitation.
  - `q_electrolyte_abnormal_q2` (PARTIAL): multi-analyte abnormal
    filter; one Mg-LOW row not yet routed to typed call.
- Spike artefacts: `evals/spike_q7_lab_results/` — corpus, queries
  (now with `typed:` block on value-bearing patterns), harness,
  results JSON. Re-runnable via `python run.py [--skip-ingest]`.
- ADR-0001 is amended in spirit (clinical labs no longer "fit
  graphiti natively"); the amendment is not retro-actively logged in
  ADR-0001 because the change of scope is large enough to warrant its
  own decision rather than a footnote.
- Q9 (wearable throughput) remains open; independent (cost, not
  summarisation).
- **v0.2.1 supersession-aware ingest landed** (commit on 2026-05-09).
  `EpisodeIn.corrects: UUID | None` boundary signal closes prior
  `lab_record` rows and `episode_metadata.asserted_until` +
  `superseded_by` inside the Stage 6 single-txn block. Chain-walk +
  `SELECT … FOR UPDATE` serialize concurrent corrects-on-same-chain.
  Q7 re-spike (fresh tenant `spike-q7-v0_2_1`): pass = **10/15
  (66.7 %)** — net headline unchanged from v0.2.0 but with
  `q_k_lowest_2024` flipped FAIL → **PASS** (the v0.2.1 named bug —
  typed `min` op now skips the closed 2.8 mmol/L April row, returns
  3.2 mmol/L from March). Verdict stays ADOPT_WITH_GAPS.
  Internal trade-off:
  - `q_k_lowest_2024`: FAIL → **PASS** (named-bug fix).
  - `q_electrolyte_abnormal_q2`: PARTIAL → FAIL — supersession of the
    April panel's `episode_metadata` correctly hides it from default
    `gnokee_recall`, but the test expects both the original (Mg LOW)
    AND the correction. Designed-correct: agent should query
    `gnokee_lab_query` with abnormal-flag filter (not yet a typed op)
    or pin `as_of` pre-correction.
  - `q_units_potassium`: PASS → PARTIAL — LLM extraction variance on
    fresh tenant; orthogonal to v0.2.1.
- Spike artefacts: `evals/spike_q7_lab_results/results/20260509T082332Z.json`.
- **v0.2.x — `gnokee_lab_query` `op=abnormal` lands** (issue #18,
  branch `feat/lab-query-abnormal-op`, 2026-05-09). New typed op
  filters visible `lab_record` rows on `abnormal_flag IS NOT NULL`,
  with optional `analyte` so callers can ask "which electrolytes were
  abnormal?" without naming each analyte upfront. Both bi-temporal
  half-pairs apply identically to the other read paths so retroactive
  corrections honour `as_of` / `valid_at`. Q7 re-spike (same
  `spike-q7` tenant, `--skip-ingest`): pass = **11/15 (73.3 %)** —
  `q_electrolyte_abnormal_q2` flips PARTIAL → **PASS** (typed call
  surfaces the persistent Mg LOW row from `lab_2024_04_10` while
  correctly skipping the corrected K+ row from
  `lab_2024_04_25_correction`, which is no longer abnormal — that is
  the correct supersession behaviour, so the query's `expects` now
  drops the correction). Verdict stays ADOPT_WITH_GAPS but the
  v0.2.1 supersession regression is now closed on the typed path.
  Spike artefacts: `evals/spike_q7_lab_results/results/20260509T091504Z.json`.
- **v0.2.x — `gnokee_recall.supersession_hints[]` lands** (issue #19,
  2026-05-09). Closes the remaining footgun from v0.2.1: the original
  April panel narrative was hidden from default `gnokee_recall` even
  when row-level data on unrelated analytes (Mg LOW) remained open.
  **Decision: Option A+ — leave the recall narrative-truth contract
  alone, add a discovery hint.** When cosine ranks a superseded
  episode in the top-K, recall now emits a `SupersessionHint` with
  `(superseded_uuid, current_head_uuid, superseded_at)` instead of
  surfacing the stale narrative. Rationale: clinical safety. The
  April panel narrative says "Critical hypokalemia 2.8" — that
  diagnosis was rescinded; surfacing it without an explicit
  supersession marker is dangerous. The agent reads the hint and
  follows up via `gnokee_lab_query` / `gnokee_med_query` (which
  honour row-level openness independently) or pins `as_of`
  pre-correction for the original narrative. Hint cap = 5 per
  recall; `RecallResponse.supersession_hints` is empty by default
  (backwards compatible). Rejected alternatives: Option B (mixed-
  visibility recall — extra join on every recall + identity
  confusion when same `episode_uuid` carries stale narrative + fresh
  row data), Option C (always surface chain — token cost + same
  stale-narrative safety problem).
- **v0.3.x — encrypted_body interaction (issue #22 / PR #68).**
  `gnokee_lab_query` will NOT find lab rows parsed from an episode
  ingested via `encrypted_body`. The clinical parser
  (`extract/clinical/lab_parser.py`) needs plaintext narrative to
  identify analyte / value / unit / date triples; gnokee never holds
  the plaintext on the encrypted branch. Consumer workaround: for
  episodes that contain both narrative + lab data, ingest the
  plaintext body once (so `lab_record` rows materialise) AND store
  the encrypted narrative under a separate `our_id`, since
  `lab_record` is keyed by `(tenant_id, episode_uuid, …)` and lives
  independently from the encrypted body table. The two are not
  joined on the same episode UUID; that is by design — encryption
  is for the narrative, structured data is for typed reads.

## Amendment 2026-05-17 — `source` column + caller-parsed branch (#144)

Migration 0024 adds `source TEXT NOT NULL DEFAULT 'llm_extracted'`
with CHECK constraint accepting `'llm_extracted' | 'caller_parsed'`
to `lab_record`. New `EpisodeIn.parsed_labs` field lets the consumer
hand structured rows alongside `encrypted_body` (LLM extraction
cannot run on ciphertext). Caller-parsed rows are flagged
`source = 'caller_parsed'`; existing LLM-extracted rows take the
default. Validator rejects `parsed_labs` on the plaintext branch
(double-count footgun — Stage 4's deterministic parser already owns
that path).

Stage 4c in `ingest.py` writes the rows inside the existing Stage 5
transaction so atomicity guarantees match the LLM-extracted path.
`gnokee_lab_query` now returns lab rows on the encrypted branch when
the consumer supplied `parsed_labs`; the v0.3.x interaction note
above is superseded for consumers that adopt the side-channel.

Forget cascade behaviour unchanged — FK to `episode_metadata`
cascades either source equivalently.
