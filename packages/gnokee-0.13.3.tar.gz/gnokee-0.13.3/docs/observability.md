# Observability

> Status: pre-1.0. v0.x ships logs only. Prometheus metrics + OTel
> tracing are the v0.2+ roadmap. Pair with
> [`deploy.md`](deploy.md) (operator contract) and
> [`privacy-posture.md`](privacy-posture.md) (what gnokee never
> logs, by design).

## What gnokee logs

`structlog` JSON, configured in `gnokee.logging` and respected by
every gnokee module. Default level is `info` via
`GNOKEE_LOG_LEVEL`.

Mandatory fields on every log record where applicable:

| Field | Meaning |
|---|---|
| `tenant_id` | Tenant partition. Always present on per-request logs. |
| `episode_uuid` | When the log is about a specific episode (ingest, recall fetch, deferred extraction). |
| `latency_ms` | Per-stage or end-to-end latency. |
| `stage` | Pipeline stage label (`ingest.embed`, `ingest.graphiti_add`, `recall.cypher_narrow`, etc.). |
| `event` | Event name (`structlog` convention). |

Sample log line (pretty-printed):

```json
{
  "event": "ingest.complete",
  "tenant_id": "omur:tenant-xyz",
  "episode_uuid": "1e8f...",
  "stage": "ingest",
  "latency_ms": 4521,
  "facts_created": 7,
  "contradicts": 1,
  "extraction_deferred": false,
  "level": "info",
  "timestamp": "2026-05-10T12:34:56.123Z"
}
```

## What gnokee never logs

By design, the following are **never** written to logs:

- `content` — episode bodies. Even at `debug` level. Logging
  user-visible text would defeat the privacy contract that
  consumers rely on.
- Embedding vectors — 1024 floats per episode is noise; also they
  retain semantic content of the input.
- LLM prompts — the prompt template embeds the episode `content`,
  so the same rule applies.
- LLM responses — they may carry user data extracted from the
  episode.
- DEKs, `key_id` material, ciphertext bodies — encrypted-body
  branch leaves no plaintext fingerprint anywhere.
- Postgres `password` / Neo4j `password` / `OPENAI_API_KEY` — env
  vars are loaded but never echoed.

If you find a log line carrying any of the above, file a security
report per [`SECURITY.md`](../SECURITY.md). It's a privacy bug.

## Stages instrumented

| Pipeline | Stages with `stage=` log labels |
|---|---|
| Ingest (full) | `validate`, `langdetect`, `embed`, `graphiti_add`, `pg_writes`, `contradiction`, `complete` |
| Ingest (lite) | `validate`, `langdetect`, `embed`, `pg_writes`, `complete` |
| Recall | `embed_query`, `cypher_narrow`, `pg_filter`, `cosine_rerank`, `fact_fetch`, `contradiction_join`, `shape_response`, `complete` |
| Deferred extraction | `fetch_batch`, `extract_one`, `mark_complete`, `report` |
| Lab / med query | `validate`, `pg_query`, `complete` |

Latency per stage is the workhorse metric for "where's my time
going?". Filtering logs by `stage=…` gives a per-stage breakdown.

## Recall response telemetry

`RecallResponse.recall_telemetry` (issue #54) carries per-lane
budget vs emitted accounting on every recall:

```python
class RecallTelemetry(BaseModel):
    budget_max_tokens: int
    fact_budget: int                       # split derived from max_tokens
    excerpt_budget: int
    body_budget: int
    fact_tokens_emitted: int
    excerpt_tokens_emitted: int
    body_tokens_emitted: int
    fact_count: int
    excerpt_count: int
    body_count: int
    body_first_row_oversize: bool          # true iff a single body row blew the budget
```

Useful for:

- **Eval harnesses** measuring how far real usage falls from the
  `max_tokens` cap.
- **Production dashboards** measuring lane utilisation per tenant.
- **Diagnosing truncation** — `body_first_row_oversize=True`
  signals "single row blew the budget; raise the cap".

The consumer can log this dict alongside their own request log to
build per-recall accounting.

## Ingest receipt telemetry

`IngestReceipt` itself is the observability handle for ingest:

```python
class IngestReceipt(BaseModel):
    episode_uuid: UUID
    asserted_at: datetime
    created_fact_uuids: list[UUID]
    contradicts: list[ContradictionRef]
    replayed: bool                  # idempotency hit on (tenant_id, our_id)
    extraction_deferred: bool       # lite-mode ingest
```

Operationally interesting events:

- `replayed=True` — duplicate ingest from the same source. Useful
  to monitor "outbox draining replays".
- `extraction_deferred=True` — lite-mode count. Pair with deferred
  backfill volume to confirm your schedule keeps up.
- `contradicts` non-empty — count of contradictions surfaced at
  ingest. Climbing volume signals data hygiene issues upstream.

## Operational dashboards (recommended)

gnokee doesn't ship dashboards, but these are the canonical
panels for a Grafana / equivalent setup:

### Ingest

- Episodes/sec by `tenant_id`, split full vs lite.
- Latency p50 / p95 / p99 by stage (`embed`, `graphiti_add`,
  `pg_writes`, `contradiction`).
- `contradicts.length` rate (signal of data conflicts).
- `replayed=True` rate (signal of outbox replays).
- `LLMUnavailable` / `EmbeddingsUnavailable` /
  `GraphStoreError` / `VectorStoreError` rates.

### Recall

- Recalls/sec by `tenant_id`.
- p50 / p95 latency end-to-end.
- `body_used` rate (fraction of recalls that fell back to body
  lane — high rate suggests Graphiti edge facts aren't satisfying
  queries).
- `truncated=True` rate (raise `max_tokens` if it climbs).
- `candidate_count` distribution (low values suggest a corpus
  problem).

### Deferred extraction

- Backlog size — count of `episode_metadata` rows where
  `extraction_deferred=TRUE`. If this climbs without bound, your
  cron interval is too long.
- Per-run `processed / succeeded / failed / elapsed_ms`.
- Failure rate, broken down by failure class.

### Postgres + Neo4j + TEI

These are commodity panels. Standard postgres-exporter,
neo4j-exporter, and TEI's `/metrics` endpoint apply. gnokee adds
nothing on top.

## Log shipping

gnokee writes logs to stdout. Shipping is the operator's call:

- **systemd** → journald → forward to your aggregator.
- **k8s** → stdout → cluster log collector (Fluentd / Vector /
  Filebeat → Elasticsearch / Loki / Datadog).
- **ECS / Cloud Run** → cloud-native log aggregation.

For local dev, `make logs` tails the compose stack.

## Metrics + tracing roadmap

| Surface | Status |
|---|---|
| structlog JSON logs | ✓ shipped (v0.1+) |
| `RecallResponse.recall_telemetry` | ✓ shipped (v0.3, #54) |
| Prometheus `/metrics` endpoint on the MCP server | planned (v0.5+) |
| OpenTelemetry traces (per-request, per-stage spans) | planned (v0.5+) |
| Per-tenant cost accounting (LLM tokens, embeddings, storage) | not planned in v0.x; consumer-side concern |

Order of investment is dictated by what the two production
consumers ask for. If your deployment needs metrics or traces
before v0.5, you can wrap gnokee's API surface with your own
OTel SDK / Prometheus client — gnokee's `async def` boundaries are
clean instrumentation points.

## Sample structured log shapes

**Ingest start:**

```json
{
  "event": "ingest.start",
  "tenant_id": "omur:tenant-xyz",
  "stage": "ingest",
  "extract": true,
  "encrypted": false,
  "level": "info"
}
```

**Ingest stage transition:**

```json
{
  "event": "ingest.stage",
  "tenant_id": "omur:tenant-xyz",
  "episode_uuid": "1e8f...",
  "stage": "graphiti_add",
  "latency_ms": 4012,
  "level": "info"
}
```

**Contradiction degraded path:**

```json
{
  "event": "contradiction.unavailable",
  "tenant_id": "omur:tenant-xyz",
  "episode_uuid": "1e8f...",
  "stage": "contradiction",
  "reason": "LLMUnavailable: 503 from upstream",
  "level": "warning"
}
```

**Recall complete:**

```json
{
  "event": "recall.complete",
  "tenant_id": "omur:tenant-xyz",
  "stage": "recall",
  "latency_ms": 320,
  "candidate_count": 47,
  "facts": 5,
  "body_used": false,
  "truncated": false,
  "level": "info"
}
```

**Deferred extraction batch:**

```json
{
  "event": "deferred_extraction.report",
  "tenant_id": "omur:tenant-xyz",
  "stage": "deferred_extraction",
  "processed": 42,
  "succeeded": 41,
  "failed": 1,
  "elapsed_ms": 31200,
  "level": "info"
}
```

## See also

- [`deploy.md`](deploy.md) — process supervision, healthchecks.
- [`privacy-posture.md`](privacy-posture.md) — what gnokee never
  logs and why.
- [`api/python.md`](api/python.md) — `RecallTelemetry` + `IngestReceipt` shapes.
- [`troubleshooting.md`](troubleshooting.md) — common log signals
  and what to do about them.
