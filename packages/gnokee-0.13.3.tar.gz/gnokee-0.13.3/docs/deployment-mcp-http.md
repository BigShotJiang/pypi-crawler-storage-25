# gnokee MCP — streamable-http deployment guide

- **Status:** v0.12 — production-ready (2026-05-20)
- **Driver:** [#245](https://github.com/omurlabs/gnokee/issues/245) — lift "dev only" caveat on the streamable-http transport.
- **Plan:** [docs/plans/2026-05-20-v0.12-mcp-revival.md](plans/2026-05-20-v0.12-mcp-revival.md).
- **Pairs with:** [ADR-0030](adr/0030-mcp-auth-surface.md) (auth), `docs/security/multi-tenant.md` (tenant boundary).

Production deployment for the gnokee MCP server. Stdio remains the default for desktop clients (Claude Desktop / Code / Cursor); this doc covers the network-reachable streamable-http path for service-to-service consumers (Frontal / Synapse / Marrow over Option C, omur#472).

## Status

This guide is the v0.12 deliverable that flips the README HTTP block from "dev only" to "production-ready". The flip is conditional on:

- `auth=BearerJWTBackend(...)` (or another `AuthBackend` impl) wired on `build_server` per ADR-0030. Library-mode (`auth=None`) is NOT production-supported over the network — the wire is untrusted.
- TLS terminated by an upstream reverse proxy (gnokee never holds keys per AGENTS.md).
- Connection-lifecycle defaults reviewed (idle timeout, max in-flight per session).
- `/healthz` + `/readyz` ASGI routes wired separately from MCP routes.
- Concurrency back-pressure surfaces as HTTP 503, not hang.

## TODO sections (v0.12 implementation work)

### Bind + serve

```bash
GNOKEE_MCP_HTTP=1 \
GNOKEE_MCP_AUTH_KIND=bearer-jwt \
GNOKEE_MCP_JWT_PUBKEY_PATH=/etc/gnokee/idp-pubkey.pem \
GNOKEE_MCP_JWT_ALG=RS256 \
GNOKEE_MCP_JWT_AUDIENCE=gnokee-mcp \
GNOKEE_MCP_JWT_ISSUER=https://idp.example.com \
python -m gnokee.mcp
```

### Reverse proxy (Caddy example)

```caddyfile
gnokee.example.com {
    encode zstd gzip

    handle /healthz {
        reverse_proxy 127.0.0.1:8080
    }
    handle /readyz {
        reverse_proxy 127.0.0.1:8080
    }
    handle /mcp* {
        reverse_proxy 127.0.0.1:8080
    }
    handle /.well-known/oauth-protected-resource* {
        reverse_proxy 127.0.0.1:8080
    }
}
```

### Reverse proxy (nginx example)

```nginx
upstream gnokee_mcp {
    server 127.0.0.1:8080 max_fails=3 fail_timeout=30s;
    keepalive 16;
}

server {
    listen 443 ssl http2;
    server_name gnokee.example.com;

    ssl_certificate     /etc/letsencrypt/live/gnokee.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/gnokee.example.com/privkey.pem;

    location = /healthz { proxy_pass http://gnokee_mcp; }
    location = /readyz  { proxy_pass http://gnokee_mcp; }
    location /          {
        proxy_pass http://gnokee_mcp;
        proxy_http_version 1.1;
        proxy_set_header Authorization $http_authorization;
        proxy_set_header Host          $host;
        proxy_read_timeout 60s;
    }
}
```

### systemd unit

```ini
# /etc/systemd/system/gnokee-mcp.service
[Unit]
Description=gnokee MCP server (streamable-http)
After=network-online.target postgresql.service neo4j.service
Wants=network-online.target

[Service]
Type=simple
User=gnokee
Group=gnokee
EnvironmentFile=/etc/gnokee/gnokee-mcp.env
ExecStart=/opt/gnokee/.venv/bin/gnokee-mcp
Restart=on-failure
RestartSec=5s
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
```

`/etc/gnokee/gnokee-mcp.env`:

```ini
GNOKEE_MCP_HTTP=1
# Bind address. Default `127.0.0.1` is loopback-only — reverse proxy on
# the same host terminates TLS + (optional) auth. Set to `0.0.0.0` ONLY
# when GNOKEE_MCP_AUTH_KIND is also set (per ADR-0030); the
# `_assert_http_auth_safety` startup gate refuses unauthenticated HTTP
# unless GNOKEE_MCP_HTTP_ALLOW_UNAUTHENTICATED=1 is explicitly set.
GNOKEE_MCP_HOST=127.0.0.1
GNOKEE_MCP_PORT=8000
GNOKEE_MCP_AUTH_KIND=bearer-jwt
GNOKEE_MCP_JWT_PUBKEY_PATH=/etc/gnokee/idp-pubkey.pem
GNOKEE_MCP_JWT_ALG=RS256
GNOKEE_MCP_JWT_ISSUER=https://idp.example.com
GNOKEE_MCP_JWT_AUDIENCE=gnokee-mcp
GNOKEE_MCP_AUTH_ISSUER_URL=https://idp.example.com
GNOKEE_MCP_AUTH_RESOURCE_URL=https://gnokee.example.com
GNOKEE_PG_DSN=postgresql://gnokee:CHANGEME@127.0.0.1/gnokee
GNOKEE_NEO4J_URI=bolt://127.0.0.1:7687
GNOKEE_NEO4J_USER=neo4j
GNOKEE_NEO4J_PASSWORD=CHANGEME
GNOKEE_TEI_URL=http://127.0.0.1:8088
GNOKEE_OPENAI_BASE_URL=https://api.openai.com/v1
GNOKEE_OPENAI_API_KEY=CHANGEME
```

### docker-compose snippet

**Container image note (2026-05-22, updated for v0.13.0):**
Starting with **v0.13.0**, gnokee publishes a container image to
`ghcr.io/omurlabs/gnokee:<X.Y.Z>` (and the minor-float
`ghcr.io/omurlabs/gnokee:<X.Y>`) on every `v*.*.*` tag push, via
`.github/workflows/ghcr-publish.yml`. The v0.12.x line is PyPI-only;
there is no published image for those tags. `:latest` is deliberately
unset — operators MUST pin a tag.

Cosign signature verification + SBOM attestation are deferred to
v0.13.1; for v0.13.0 the publish chain is GHCR push + Trivy SARIF
upload to the Security tab (CRITICAL findings hard-stop the
publish). If you need pre-release smoke verification ahead of a tag
cut, build locally: `docker build -t gnokee:local .` and substitute
`image: gnokee:local` below.

```yaml
services:
  gnokee-mcp:
    image: ghcr.io/omurlabs/gnokee:0.13  # minor-float; pin :0.13.0 for byte-stable
    command: ["gnokee-mcp"]
    environment:
      GNOKEE_MCP_HTTP: "1"
      GNOKEE_MCP_AUTH_KIND: "bearer-jwt"
      GNOKEE_MCP_JWT_PUBKEY_PATH: "/etc/gnokee/idp-pubkey.pem"
      GNOKEE_MCP_JWT_ALG: "RS256"
      GNOKEE_MCP_AUTH_ISSUER_URL: "https://idp.example.com"
      GNOKEE_MCP_AUTH_RESOURCE_URL: "https://gnokee.example.com"
      GNOKEE_PG_DSN: "postgresql://gnokee:${PG_PWD}@postgres/gnokee"
      GNOKEE_NEO4J_URI: "bolt://neo4j:7687"
      GNOKEE_NEO4J_USER: "neo4j"
      GNOKEE_NEO4J_PASSWORD: "${NEO4J_PWD}"
      GNOKEE_TEI_URL: "http://tei:8088"
      GNOKEE_OPENAI_BASE_URL: "${OPENAI_BASE}"
      GNOKEE_OPENAI_API_KEY: "${OPENAI_KEY}"
    volumes:
      - ./idp-pubkey.pem:/etc/gnokee/idp-pubkey.pem:ro
    ports:
      - "127.0.0.1:8080:8000"
    depends_on:
      postgres: { condition: service_healthy }
      neo4j:    { condition: service_healthy }
    healthcheck:
      test: ["CMD", "curl", "-fsS", "http://127.0.0.1:8000/healthz"]
      interval: 10s
      timeout: 3s
      retries: 3
    restart: unless-stopped
```

Pair with `caddy` or `nginx` service in front for TLS termination.

### Health endpoints

- `GET /healthz` — process alive. Always 200 unless gnokee is shutting down.
- `GET /readyz` — process alive AND can reach Postgres + Neo4j. 200 when ready, 503 when a backend pool is exhausted or unreachable.

### Concurrency + back-pressure

- `asyncpg.Pool` size = N (default: 10; tune via `GNOKEE_POSTGRES_POOL_MAX`).
- Neo4j driver session pool = M (default: 10; tune via `GNOKEE_NEO4J_POOL_MAX`).
- When either pool is saturated, the tool call surfaces as HTTP 503 with `Retry-After: 1` rather than hanging.

### Observability

- Structured logs via omkit logger.
- Per-tool latency + error counters (`gnokee.mcp.tool.<name>.latency`, `.errors`).
- Auth rejection log channel: `gnokee.mcp.auth.rejected` (subject + rejected tenant_id only; never the claims dict).

### TLS posture

gnokee NEVER terminates TLS in-process. Terminate at the reverse proxy. AGENTS.md "do not host keys" invariant applies — gnokee owns no signing key, no certificate private key, no JWKS endpoint.

### What this doc does NOT cover

- Identity provider setup (Omur supplies its own; gnokee only verifies tokens).
- Per-tool scoping (read-only vs forget). Out of scope for v0.12 — see ADR-0030 §"Open questions".
- mTLS auth backend — placeholder hook exists in `AuthBackend` Protocol; no shipped impl in v0.12. Driver-gated for v0.13+.
- Quota / rate-limiting. Reverse proxy or follow-up ADR.

## Cross-refs

- ADR-0030 (MCP auth surface).
- ADR-0027 (short-ID translation — visible at the MCP boundary; client tools see `ep_017` not raw UUIDs).
- `docs/security/multi-tenant.md` (tenant-boundary threat model).
- Issue #244 (auth driver), #245 (this transport hardening driver), #246 (audit driver).
- omur#472 (Option C deployment driver).
