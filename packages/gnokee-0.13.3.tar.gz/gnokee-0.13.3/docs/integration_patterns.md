# Integration patterns (v0.3)

> Authoritative integrator-facing guide for choosing between gnokee's
> ingest modes, combining them with deferred extraction, and reasoning
> about the recall surfaces they unlock. Pairs with the
> consumer-pattern recipes in
> [`integration/consumer-patterns.md`](integration/consumer-patterns.md);
> this document is the ramp-decision contract.
>
> Assumes #56 is fixed: lite-mode ingest writes a minimal `Episodic`
> node to Neo4j so `gnokee_recall` Stage 2a sees the candidate. Without
> that fix lite-mode episodes remain queryable through the typed
> `gnokee_lab_query` / `gnokee_med_query` paths but invisible to
> `gnokee_recall` until deferred extraction backfills them. See
> §4.3 for what changes once #56 lands.

## 1. Two ingest modes, one ingest function

`gnokee.ingest_episode(...)` (the same call signature used since v0.1)
exposes a single boolean flag that selects the ingest mode:

| Mode      | Call                                            | Latency profile                       | Surfaces episode in ...                |
|-----------|-------------------------------------------------|---------------------------------------|----------------------------------------|
| Full      | `ingest_episode(..., extract=True)`  (default)  | p50 ≈ 4.5 s, p95 ≈ 7.1 s              | `gnokee_recall` + typed reads          |
| Lite      | `ingest_episode(..., extract=False)`            | p50 ≈ 200 ms (Postgres + TEI only)    | typed reads immediately; `gnokee_recall` only after backfill |

The flag was added in #47; the implementation lives in
[`src/gnokee/ingest.py`](../src/gnokee/ingest.py) (see the
`IngestPipeline.ingest()` docstring for the canonical stage list).
The two modes share Stages 1–3, 5, 6 and the receipt shape; the
difference is the LLM-driven Graphiti `add_episode` (Stage 4) and
contradiction detection (Stage 7), which lite mode skips.

```text
                ┌──────────── full mode ────────────┐
                │                                   │
EpisodeIn ─►  Stage 1   Stage 2   Stage 3   Stage 4   Stage 5   Stage 6   Stage 7   Stage 8
              validate  langdet   embed     graphiti  resolve   pg writes contradict receipt
                │         │         │         │         │         │         │         │
                │         │         │         X         │         │         X         │
                │                            (skip)              (skip)
                └──────────── lite mode ────────────┘
                              extract=False
```

Stages 4 + 7 are the two LLM-bound stages; everything else is
millisecond-class deterministic Python + Postgres + TEI.

## 2. When to use lite mode

Use `extract=False` when **all** the following hold:

- The ingest source is **high-cadence** — telemetry windows, IoT
  sensors, conversation streams, log scrapes, wearable summaries — and
  the consumer cannot afford the 4–7 s LLM-extraction wall time per
  episode.
- The downstream read path is one of:
  - the typed clinical reads `gnokee_lab_query` / `gnokee_med_query`,
    which read Postgres `lab_record` / `med_record` tables directly
    and never touch Neo4j or Graphiti facts; or
  - a vector / BM25 lane on `episode_metadata + content_embedding`
    surfaced through `gnokee_recall` body emission (post-#41), which
    works on lite-mode episodes once #56 lands.
- The consumer has a **deferred-extraction schedule** in place (cron,
  pg_cron, Celery, Temporal, modal.com, …) so narrative facts catch
  up within the SLO the consumer cares about. See §4.

Concrete examples that fit this profile:

| Source                                     | Why lite                                                                 |
|--------------------------------------------|--------------------------------------------------------------------------|
| Omur Pulse 1-minute telemetry windows      | LLM call per 1-minute window unaffordable; window emits a narrative summary that becomes a fact later via backfill |
| Wearable daily summaries (ADR-0011)        | Daily summary already structured; the narrative add only matters for `gnokee_recall` synthesis, which can lag |
| IoT sensor anomalies / log scrapes         | Volume × cost; the typed-read path is irrelevant, but the embedding-only recall lane is enough for "find the spike" UX |
| Live conversation transcripts (chunked)    | The consumer wants the chunk in pgvector immediately; entity extraction can run in the next maintenance window |

## 3. When NOT to use lite mode

Do not use `extract=False` when **any** of the following hold:

- The consumer expects **fact-shaped recall** (Graphiti edge facts,
  contradiction surfacing, supersession chains) on the next read after
  ingest. Lite-mode episodes carry no edge facts until extraction
  backfills, so `gnokee_recall` returns the body lane only and
  `contradicts: []` is structurally empty (not "no contradictions
  found"; "contradiction detection has not run yet").
- The episode is part of an **interactive supersession chain** that
  needs `corrects:` linkage (Stage 6 supersession still runs in lite
  mode, but the contradiction story between the new and old facts will
  not exist until extraction runs).
- The consumer is running a **clinical read** that depends on
  contradiction surfacing for safety (e.g. duplicate-prescription
  detection that pivots on the contradiction edge, not the
  `med_record` row). Use full mode for those.
- The episode is **one-off / low-cadence** (manual journal entry, a
  daily clinical note typed by a clinician). The 4–7 s wall time is
  acceptable, and full mode means narrative recall works on the next
  read with no operator involvement.

Rule of thumb: pick lite when the source produces > 1 episode/minute
per tenant; pick full otherwise.

## 4. Backfill pattern: deferred extraction

Lite mode is only useful in combination with a periodic backfill that
lifts narrative facts for the deferred episodes.
[`gnokee.maintenance.run_deferred_extraction`](../src/gnokee/maintenance.py)
is the helper. It walks `episode_metadata` rows where
`extraction_deferred = TRUE`, calls `graphiti.add_episode` for each
one (using the original `valid_at`, never `now()`), and stamps
`extraction_completed_at` on success.

### 4.1 Scheduling

gnokee does **not** host a scheduler. Pick whichever the consumer
already runs:

- System cron / cron daemon — wrap the script below in a `crontab` entry.
- Postgres `pg_cron` — call a procedure that fires `pg_net` / `NOTIFY`
  out to a worker; or have `pg_cron` invoke an HTTP endpoint that runs
  the helper.
- External task runner (Celery, APScheduler, Temporal, modal.com,
  noggin maintenance) — import `gnokee.run_deferred_extraction` as a
  regular async function inside a task definition.

### 4.2 Code sketch

```python
import asyncio
from datetime import datetime, timedelta, timezone
import asyncpg
import gnokee

async def nightly_backfill() -> None:
    pool = await asyncpg.create_pool(dsn="postgresql://...")
    # Build pipeline deps (graph, metadata, contradictions, llm) the
    # same way you build them for normal ingest.
    since = datetime.now(timezone.utc) - timedelta(days=1)
    report = await gnokee.run_deferred_extraction(
        tenant_id="omur:tenant-xyz",
        pool=pool,
        graph=graph,
        metadata=metadata,
        contradictions=contradictions,
        llm=llm,
        since=since,
        batch_size=100,        # tune to LLM throughput
        max_episodes=500,      # cap cost per cron tick
    )
    print(
        f"backfill: {report.succeeded}/{report.processed} ok in "
        f"{report.elapsed_ms} ms, {len(report.failed)} failed"
    )

asyncio.run(nightly_backfill())
```

Key invariants the helper enforces, lifted from
`maintenance.run_deferred_extraction`:

- `tenant_id` is mandatory; empty / whitespace-only raises
  `ValidationError`. There is no implicit fallback.
- `reference_time = row.valid_at`, **never** `utc_now()`. Using `now()`
  here would corrupt the bi-temporal valid-time axis for every
  backfilled episode.
- Failure isolation — one bad episode (Graphiti down, content NULL,
  preprocessor failure) does not poison the batch. `report.failed`
  carries the per-episode error; `extraction_deferred` stays TRUE so
  the next run retries.
- RLS defence-in-depth — the helper sets `app.current_tenant` GUC on
  every acquired connection before any SELECT or UPDATE.

### 4.3 Recall behaviour across the backfill window

Once #56 ships:

| Read surface                       | Lite, before backfill                | Lite, after backfill            | Full mode                       |
|------------------------------------|--------------------------------------|---------------------------------|---------------------------------|
| `gnokee_lab_query`                 | byte-identical to full mode          | byte-identical                  | byte-identical                  |
| `gnokee_med_query`                 | byte-identical to full mode          | byte-identical                  | byte-identical                  |
| `gnokee_recall` body lane          | works (cosine + BM25 over content)   | works                           | works                           |
| `gnokee_recall` fact lane          | empty (`fact_count = 0`)             | populated (via deferred edges)  | populated at ingest             |
| `gnokee_recall.contradicts[]`      | `[]` (detection has not run)         | populated                       | populated at ingest             |

Before #56: lite-mode episodes are invisible to `gnokee_recall`
entirely (Stage 2a returns 0 → empty `RecallResponse`). The typed
reads are unaffected because they do not go through Neo4j.

## 5. Interaction with typed reads (`gnokee_lab_query` / `gnokee_med_query`)

Both v0.2 typed clinical reads are **mode-agnostic**.

- They read Postgres `lab_record` / `med_record` rows directly. See
  [ADR-0009](adr/0009-clinical-labs-need-structured-store.md) and
  [ADR-0010](adr/0010-meds-share-lab-record-shape.md).
- The deterministic parsers that populate those tables run inside
  Stage 6 of `IngestPipeline.ingest()`. Stage 6 runs unchanged in lite
  mode.
- Neither tool calls Graphiti, Neo4j, the contradiction store, or the
  LLM. They go straight to Postgres with `(tenant_id, …)` filtering.

```text
gnokee_lab_query  ──►  Postgres lab_record  ──► (tenant_id, analyte, valid_at)
gnokee_med_query  ──►  Postgres med_record  ──► (tenant_id, drug_name, event_kind, valid_at)
```

The consequence is the **two-customer test invariant** below.

## 6. Two-customer test invariant: typed reads are byte-identical

Stated as a contract:

> For any episode body that the deterministic clinical parsers
> recognise, the rows produced in `lab_record` and `med_record` MUST
> be byte-identical regardless of whether the episode was ingested
> with `extract=True` or `extract=False`.

This is load-bearing for both consumers gnokee serves:

- **Omur (managed health-AI SaaS)** uses `gnokee_lab_query` /
  `gnokee_med_query` as the clinical read surface. Pulse-style
  high-cadence telemetry rides through lite mode; clinician-typed
  notes ride through full mode. Both must produce the same typed
  rows for the same body — the read layer cannot tell them apart.
- **Personal AI (noggin)** uses lite mode for wearable summaries and
  full mode for journal entries. The personal corpus must merge cleanly
  in `lab_record` / `med_record` without "mode-shaped" duplicates.

Why it holds: the parsers are pure (no I/O, no LLM, no clock), they
run inside the Stage 6 transaction in both code paths, and the input
they see (`episode.content`) is identical in both modes. The branches
that differ between modes (Stage 4 Graphiti, Stage 7 contradictions)
are downstream of the parser and never feed back into it.

Operators can verify this invariant locally:

```python
from gnokee.extract.clinical import parse_labs, parse_meds

body = "..."  # consumer-rendered episode body
assert parse_labs(body) == parse_labs(body)  # tautology, but fixes the contract
assert parse_meds(body) == parse_meds(body)
```

The integration test that exercises the invariant end-to-end lives
in `tests/integration/test_lite_mode_typed_reads.py` (added in #47).

## 7. AGENTS.md "do not" list compliance

Lite mode and deferred extraction must not regress any of the project
invariants in [`AGENTS.md`](../AGENTS.md) §"Hard 'do not' list":

| Invariant                                | How lite mode honours it                                                                  |
|------------------------------------------|-------------------------------------------------------------------------------------------|
| No UI / chat shells                      | Both modes are headless library calls; no surface added.                                  |
| No vendored LLM                          | The consumer supplies the LLM endpoint; full mode and deferred extraction both call it.   |
| No federation                            | Lite mode adds no peer-to-peer write path; the outbox/cron pattern is single-tenant.      |
| No auto-resolve of contradictions        | Lite mode emits `contradicts: []` until backfill; backfill runs the same Q4 pipeline that surfaces (does not resolve) conflicts. |
| No deletion of superseded facts          | `corrects:` still uses tombstones in Stage 6; lite mode does not change supersession.    |
| No key holding by gnokee                 | Encrypted-body branch in v0.3+ (#22) follows the same rule (see §8).                      |

The deferred-extraction helper is "do not auto-resolve" by
construction — it calls `detect_for_facts(...)` (degraded-tolerant),
which writes `fact_contradiction` rows but never picks a winner. The
consuming LLM still gets every conflicting fact at recall time and
must reconcile.

## 8. Per-tenant key flow (encrypted-body branch, v0.3+ via #22)

gnokee never holds encryption keys. The v0.3 encrypted-body work in
#22 follows the same rule the unencrypted branch follows today:

```text
Consumer KMS  ──►  consumer wraps EpisodeIn.encrypted_body
                     │
                     ▼
              gnokee.ingest_episode(content=None, encrypted_body=...)
                     │
                     ▼
              Stage 1: validate (no decryption)
              Stage 3: embed REJECTED — no plaintext to embed
              Stage 6: store ciphertext + key_id reference (consumer KMS)
                     │
                     ▼
              gnokee_recall: returns lazy ciphertext handle; consumer decrypts
                     │
                     ▼
              gnokee_forget (cryptographic erasure): consumer destroys DEK
```

When `encrypted_body` is set, gnokee:

- never decrypts;
- never stores plaintext (`episode_metadata.content` stays NULL);
- never sees the DEK (only the consumer's `key_id` reference);
- skips Stage 3 embedding and Stage 7 contradiction (no plaintext to
  embed, no edge facts to compare).

Lite mode and the encrypted-body branch are **orthogonal**: a
consumer can pick one, the other, both (encrypted lite ingest is the
worst-latency-budget path), or neither. The Stage 6 transaction shape
is identical across all four combinations.

The architectural reason gnokee is named gnokee: "no key" =
arch invariant. See [ADR-0004](adr/0004-gnokee-owns-retrieval.md) §
"License boundary" and `docs/architecture.md` § "Multi-tenancy".

## 9. Cross-references

- **ADRs**
  - [ADR-0004 — gnokee owns retrieval](adr/0004-gnokee-owns-retrieval.md) — bge-m3 cosine on per-episode `content_embedding` is the v0.1 retrieval primitive; lite mode preserves this exactly.
  - [ADR-0009 — Clinical labs need a structured store](adr/0009-clinical-labs-need-structured-store.md) — `lab_record` table; `gnokee_lab_query` consumes it.
  - [ADR-0010 — Meds share the lab-record shape](adr/0010-meds-share-lab-record-shape.md) — `med_record` table; `gnokee_med_query` consumes it.
  - [ADR-0012 — Cross-tool eval verdict](adr/0012-cross-tool-eval-verdict.md) — Q10 spike status; informs the eval-delta gate (see [`eval_delta_gate.md`](eval_delta_gate.md)).
- **Maintenance helper**
  - [`src/gnokee/maintenance.py`](../src/gnokee/maintenance.py) — `run_deferred_extraction` signature, RLS GUC handling, failure isolation contract.
- **Companion docs**
  - [`integration/consumer-patterns.md`](integration/consumer-patterns.md) — body-rendering recipes for the typed parsers + outbox pattern.
  - [`eval_delta_gate.md`](eval_delta_gate.md) — what regressions block a v0.3 retrieval / ingest PR.

## 10. Quick decision flow

```text
                         ┌──────────────────────────────┐
                         │  Will the next read be a     │
                         │  typed clinical query?       │
                         └─────┬────────────────────────┘
                               │ yes                        no
                               ▼                            ▼
              ┌───────────────────────────┐   ┌─────────────────────────────┐
              │  Source > 1 episode/min ? │   │  Source > 1 episode/min ?   │
              └─────┬─────────────────────┘   └─────┬───────────────────────┘
                    │ yes        no                 │ yes              no
                    ▼            ▼                  ▼                  ▼
              ┌─────────┐   ┌─────────┐      ┌────────────┐      ┌──────────┐
              │ LITE +  │   │  FULL   │      │ LITE +     │      │   FULL   │
              │ daily   │   │         │      │ aggressive │      │          │
              │ backfill│   │         │      │ backfill   │      │          │
              └─────────┘   └─────────┘      └────────────┘      └──────────┘
```

"Aggressive" backfill = every 5–15 min via cron; "daily" = once a day
in a maintenance window. Tune `batch_size` and `max_episodes` to the
LLM throughput available to your tenants.

## 11. Consumer onboarding: etalon separation health check

Consumers that classify ingested content by **source-type** (lab record
vs. med dose change vs. wearable summary vs. journal note) typically
hold one or more short reference "etalon" prompts per source-type.
Those etalons drive downstream routing and retrieval bias — if two
etalons are not well-separated in embedding space, the consumer biases
the wrong direction and retrieval rankings degrade silently.

Raw cosine alone is noisy on bge-m3 (Q6 established this for
TEI/Ollama parity). **Mean-centered cosine** is a one-line probe that
exposes weak prompts:

```python
from gnokee.calibration import check_etalon_separation
from gnokee.embeddings import TEIClient

embed = TEIClient(...)  # or whatever EmbedFn you already have

report = await check_etalon_separation(
    [
        ("lab",    "Patient blood draw; LDL 142 mg/dL on 2024-02-15"),
        ("med",    "Started lisinopril 10mg PO daily on 2024-01-10"),
        ("daily",  "Morning run, 5k along the river, felt good"),
    ],
    embed.embed,
)

if report.has_warnings():
    for w in report.warnings:
        print(
            f"weak separation between {w.label_a!r} and {w.label_b!r}: "
            f"mean_centered={w.mean_centered_cosine:+.2f}"
        )
    raise SystemExit("differentiate your source-type prompts and retry")
```

For ``N`` etalons with optimal separation, off-diagonal mean-centered
cosines land near ``-1/(N-1)``. The default warning threshold is
``-0.30``: any pair MORE positive than ``-0.30`` (less negative, i.e.
sharing a common direction after centroid removal) gets flagged. Pass
``warning_threshold=`` to tune for larger ``N`` or stricter onboarding
gates.

This is **read-only, one-shot, no infra** — typically run at consumer
install/onboarding time as a CLI helper or interactive notebook step.
gnokee never stores the etalons or the matrix; the consumer owns the
UX (warning, blocker, ignore, etc.).

See [`src/gnokee/calibration.py`](../src/gnokee/calibration.py) and
the unit-test fixtures at [`tests/unit/test_calibration.py`](../tests/unit/test_calibration.py)
for the well-separated and pathological cases.
