# FAQ

> Frequently asked questions about gnokee. Pairs with
> [`alternatives.md`](alternatives.md) (vs Mem0 / Graphiti / Zep /
> basic-memory) and [`troubleshooting.md`](troubleshooting.md)
> (symptom → cause → fix).

## Is gnokee for me?

**Probably yes if:**

- You're building an LLM-driven application that needs durable
  memory across sessions, with bi-temporal queries (*"what did the
  system know on this date?"*, *"what was true in the world on this
  date?"*).
- You need contradictions surfaced honestly rather than silently
  resolved.
- You need verifiable forgetting (a `ForgetReceipt` enumerating
  affected artefacts) to satisfy GDPR / HIPAA-adjacent obligations.
- You're multi-tenant from day one — `tenant_id` partitioning is
  built into every API, table, and MCP tool call.
- You speak more than English — bge-m3 cross-lingual retrieval
  validated at 100% top-1 across en / ru / bg / he via direct cosine
  ([Q2 spike, ADR-0004](adr/0004-gnokee-owns-retrieval.md)).

**Probably no if:**

- You want a vendored chat UI. gnokee ships only a library and an
  MCP server.
- You want gnokee to host the LLM. It doesn't — supply your own
  OpenAI-compatible endpoint (Ollama, LiteLLM, OpenAI direct,
  Anthropic via litellm-proxy, etc.).
- You need conversation-style chat memory primarily (LongMemEval-S
  shape). gnokee currently scores 0/30 strict on that benchmark —
  see [ADR-0012](adr/0012-cross-tool-eval-verdict.md). Mem0 and
  others may fit better for that specific shape today.
- Your storage backend constraint is "must be a single Apache-2.0
  binary with no GPL anywhere". Neo4j Community is GPLv3; see
  [ADR-0005](adr/0005-graph-backend-tradeoff.md) for the trade-off
  space.

## Why not just use Mem0?

Three load-bearing differences:

1. **Bi-temporal contract.** gnokee tracks both *valid time* (when
   the fact was true in the world) and *transaction time* (when the
   system learned of it). You can pin either or both at query time.
   Mem0's model is conversation-shaped — different problem domain.
2. **Contradictions surface, never auto-resolve.** When two facts
   conflict, gnokee returns both with a `verdict`
   (`refinement | update | contradiction`) and lets the consuming
   LLM (or the user) decide. The architectural rule "do not pick a
   winner" comes from [`AGENTS.md`](../AGENTS.md) and is not
   overridable.
3. **Forgetting actually deletes.** Three modes — soft supersession,
   hard delete with tombstone propagation, cryptographic erasure
   via consumer-KMS DEK destruction. Q5 spike validated propagation
   across pgvector, Neo4j, contradiction store, and derived
   summaries.

For benchmark numbers see
[`alternatives.md`](alternatives.md).

## Why Graphiti underneath?

Graphiti is the bi-temporal knowledge-graph primitive gnokee builds
on, validated in [Q1 spike, ADR-0001](adr/0001-build-on-graphiti.md)
as the storage primitive. gnokee owns retrieval (per
[ADR-0004](adr/0004-gnokee-owns-retrieval.md)) — Graphiti's combined
hybrid search ranked structurally rather than by query relevance at
gnokee's corpus shape (many short single-fact episodes). The Q2
direct-cosine baseline beat it 100% to 25% top-1 cross-lingual.

## Do I really need Neo4j?

For v0.1 and v0.2: yes. Neo4j Community is the Graphiti default and
the only backend gnokee tests integration against today.

We evaluated alternatives in
[ADR-0005](adr/0005-graph-backend-tradeoff.md):

- **FalkorDB** — dropped on SSPL grounds (license-incompatible with
  Omur SaaS plans).
- **Kùzu** — archived 2025-10-10 by upstream.
- **Apache AGE** — 5–7 person-weeks effort with structural blockers
  on vector cosine + fulltext. Deferred until on-prem-non-GPL or
  ops-consolidation triggers materialise.

If you can't run Neo4j, you can substitute Postgres + pgvector for
the graph layer with reduced functionality (no Cypher edge facts,
no contradiction edges through Graphiti) — the architecture page
documents the trade-off.

## What's the deal with Mac arm64 and TEI?

Apple-Silicon Docker (linux/arm64) needs an arm64-native TEI image.
gnokee defaults to `ghcr.io/huggingface/text-embeddings-inference:cpu-arm64-latest`
in `docker-compose.yml`. Override `GNOKEE_TEI_IMAGE` if you need a
specific sha or the amd64 image (`cpu-1.9`).

For local development on Mac you can also skip the TEI container
and run TEI from Homebrew (Metal-accelerated), or use Ollama on
`/v1/embeddings` — gnokee's embedder client auto-detects the
endpoint shape. Q6 validated cosine parity (1.0000) between TEI
and Ollama for bge-m3 embeddings.

## Is gnokee production-ready?

Pre-1.0. Two production consumers (Omur, noggin) are running
against it; that's the source of churn that drives the project. The
honest read:

- **Stable contracts:** bi-temporal storage, no-key invariant,
  contradiction non-resolution, multi-tenant `tenant_id`
  partitioning, forgetting model.
- **May break across minor versions:** Python API signatures, MCP
  tool surface, internal storage layout, prompt templates.
- **Ops gaps:** v0.1 docker-compose is dev-only. Production needs
  pinned images, real secret management, RLS GUC wiring per request
  ([`deploy.md`](deploy.md)).
- **Eval status:** [ADR-0012](adr/0012-cross-tool-eval-verdict.md)
  REJECT-with-caveat on LongMemEval-S strict scoring. Bottleneck
  is synth-prompt abstention bias, not retrieval (per #62). For
  the workloads gnokee targets — Q7 clinical labs ADOPT_WITH_GAPS,
  Q8 medication history ADOPT — numbers are public per spike
  README.

Pin a specific version, read [`CHANGELOG.md`](../CHANGELOG.md)
before upgrading, and watch for `Breaking` headings.

## What's lite mode?

`gnokee.ingest_episode(..., extract=False)` (added in v0.3, #47).
Skips the LLM-driven Graphiti `add_episode` (Stage 4) and
contradiction detection (Stage 7). Latency drops from p50 ≈ 4.5 s
to p50 ≈ 200 ms (Postgres + TEI only). The episode is queryable via
the typed `gnokee_lab_query` / `gnokee_med_query` tools immediately
and shows up in `gnokee_recall` body lane after #56 lands; fact /
contradiction lanes light up only after deferred extraction
backfills.

Use it for high-cadence sources — telemetry, wearable summaries,
log scrapes — and pair with
`gnokee.maintenance.run_deferred_extraction()` on a cron / pg_cron
schedule.

Full flow in [`integration_patterns.md`](integration_patterns.md).

## What's encrypted_body?

v0.4 (#22). `EpisodeIn` accepts `content` xor `encrypted_body`.
When `encrypted_body` is set:

- gnokee **never decrypts**.
- gnokee **never sees the DEK** — only the consumer's `key_id`
  reference.
- Ciphertext lands verbatim in `episode_body_encrypted` (sibling
  Postgres table, FK + ON DELETE CASCADE to `episode_metadata`).
- Stage 4 (Graphiti narrative extraction) is force-skipped — no
  plaintext for the LLM.
- Stage 3 (embedding) runs only if the consumer supplies
  `EncryptedBody.content_for_embedding` plaintext, which gnokee
  drops immediately after `embed()` returns and never persists.

On recall, encrypted episodes surface verbatim ciphertext via
`RecallResponse.encrypted_bodies[]`. The consumer decrypts with
their own KMS using `key_id`. Crypto-erasure (forgetting mode 3)
works by destroying the DEK in the consumer's KMS — ciphertext
becomes unreadable.

The "no key" architectural invariant is what the project name
encodes (*gno-kee* = "no key").

## How is forgetting different?

gnokee implements three modes (per
[`architecture.md`](architecture.md)):

1. **Soft supersession.** Set `transaction_time_end`. Time-travel
   queries still find the old fact. For "I changed my mind".
2. **Hard delete with tombstone propagation.** Vector index, graph,
   derived summaries all touched. Returns a `ForgetReceipt`
   enumerating affected artefacts. Q5 spike validated 2/2 probes —
   propagation is real.
3. **Cryptographic erasure.** Destroy the per-fact DEK in the
   consumer's KMS. Ciphertext becomes unreadable. For backups that
   can't be selectively rewritten (clinical GDPR).

Other systems often only do mode 1 ("soft delete"). gnokee makes
modes 2 and 3 first-class because the consumers we serve need
deletion to be verifiable, not aspirational.

## Why bge-m3?

Validated as the v0.1 retrieval primitive in Q2 spike
([ADR-0004](adr/0004-gnokee-owns-retrieval.md)):

- 100% top-1 cross-lingual on en / ru / bg / he via direct cosine
  on full-episode content.
- 1024-dim, single-shot, multilingual by default (100+ languages
  upstream).
- Permissively licensed (MIT, BAAI).
- Commodity inference via HuggingFace TEI (CPU or GPU) or Ollama.

The 1024-dim invariant is locked across pgvector
(`vector(1024)`) and Neo4j vector indexes. Swapping the embedder
to a different dim is a destructive re-embed migration; see
[`extending.md`](extending.md) for the playbook.

## What languages does it support?

Validated: English, Russian, Bulgarian, Hebrew (Q2 corpus).
Nominal: 100+ via bge-m3 upstream.

`langdetect` runs on ingest unless the caller passes
`language=...`. The detected ISO 639-1 code lands in
`episode_metadata.language` for downstream filtering.

## Why is the token-efficiency claim 60% reduction?

Q3 spike. gnokee's MCP response shape is *compact natural-language
fact statements with lazy provenance handles* — median 125 tokens,
91.7% top-3 recall, vs Graphiti-raw at 367 tokens and 50% recall.

The provenance handle (`fact_uuid`) lets the LLM call
`gnokee_fact_provenance(fact_uuid)` to fetch the full episode body
on demand. Most of the time the LLM doesn't need the body — the
fact statement is enough.

## Can I use my own LLM?

Yes. gnokee consumes any OpenAI-compatible endpoint via
`GNOKEE_OPENAI_BASE_URL` + `GNOKEE_OPENAI_API_KEY`. Tested:

- OpenAI (gpt-4o-mini per Q4, gpt-4o, etc.)
- Anthropic via `litellm-proxy`.
- Local Ollama with the OpenAI-compatibility endpoint
  (`/v1/chat/completions`).
- LiteLLM standalone.
- Anthropic Bedrock / Vertex via the corresponding proxy.

The Q4 contradiction-classifier prompt is internal and doesn't
expose a swap surface. If you need a different classifier, see
[`extending.md`](extending.md).

## Can I use my own embedder?

Yes — any endpoint that returns 1024-dim vectors and speaks either
the TEI `/embed` shape or the OpenAI-compatible
`/v1/embeddings` shape. gnokee's embedder client (`TEIClient`)
auto-detects which one. The 1024-dim invariant is non-negotiable
without a re-embed migration.

## Why no UI / chat shell?

Architectural decision. gnokee is memory infrastructure, like a
database. The `AGENTS.md` "do not" list is explicit: no UI, no chat
shells, no front-end code in core. Use any MCP client (Claude
Desktop, Claude Code, Cursor, Continue, etc.) or wire gnokee into
your own application.

## Will gnokee ship a Slack / Discord / gdrive / voice-memo / browser-clipper consumer?

Short answer: **no, not as first-party**. The full policy is in
[ADR-0021](adr/0021-consumer-surface-strategy.md). The summary:

- **Two first-party (Tier 1) consumers**: `noggin` and
  `gnokee-obsidian`. Adding a third requires its own ADR + passing
  Q-spike + a maintainer for ≥one release cycle.
- **Permanently rejected** (Tier 1 is not on the table for these):
  - Slack / Discord bots — break ADR-0004's single-tenant assumption.
  - Email / calendar / cloud-drive **API** bridges (Gmail, Google
    Calendar, Google Drive API, Dropbox API, iCloud CloudKit, MS
    Graph) — token storage = key holding, breaks the AGENTS.md
    "do not" list.
  - Whisper / voice-memo first-party — vendor-an-LLM analog,
    breaks ADR-0001 / ADR-0004 boundaries.
  - Apple Health / wearable bridges first-party — already off-ramped
    by [ADR-0011](adr/0011-wearables-batch-or-off-ramp.md). Consumer
    owns raw stream; gnokee gets daily summaries.
- **Deferred** (revisit at v0.6, may become Tier 2 template content
  or Tier 3 community projects):
  - Photo / OCR ingest, browser clipper, IDE plugin
    (Claude Code / Cursor), mixed-folder ingest
    (`.docx` / `.pdf` / `.xlsx` / etc).
- **Already works via existing adapters, no new consumer needed**:
  - Google Drive / Dropbox / iCloud / OneDrive **mounted as a local
    folder** by their sync daemons — the Obsidian adapter walks any
    local path. Put your vault in `~/Google Drive/notes/`, run
    `gnokee-obsidian sync`, done.

If you want to build one yourself, the
`gnokee-consumer-template` repo (Tier 2 scaffold) will publish a
Python skeleton + worked examples covering: file-walk adapter,
SQLite-as-source adapter, summarise-then-ingest pattern for chat
exports, and per-type document conversion via pandoc / marker /
docling.

## Can I ingest my password manager export / API keys / encrypted backups?

**No.** This is a hard charter rule (AGENTS.md "do not" list,
reinforced as a threat-model rule in
[SECURITY.md](../SECURITY.md#secrets-and-credential-exports-are-out-of-scope-as-input)
per [ADR-0021](adr/0021-consumer-surface-strategy.md)).

Specifically, do not feed gnokee:

- Password manager exports (1Password `.1pif` / `.csv`, Bitwarden
  `.json`, KeePass `.kdbx` / `.csv`, browser saved-passwords).
- Raw API tokens, OAuth refresh tokens, SSH private keys, GPG
  private keys, cloud-provider access keys, database passwords.
- Encrypted vaults / backups gnokee cannot decrypt
  (Signal `.backup`, age-encrypted blobs without an identity,
  sealed boxes).

The threat model: extracted facts ride the same retrieval surface as
everything else. Any embedding-leak path (model inversion, prompt
injection forcing recall, log retention by the consumer LLM) turns
a stored credential into a leaked credential. gnokee is memory
infrastructure, not a secrets manager — use one of those for
secrets.

If you genuinely need to remember *"I store credential X in vault
Y"*, ingest a **non-secret index** of that fact — e.g. *"my work
SSH key lives in 1Password vault 'work'"* — never the credential
body itself.

## What's the "two-customer test"?

From [`AGENTS.md`](../AGENTS.md):

> Must comfortably serve both Omur (managed health-AI SaaS) and
> personal-AI agents. If only one is happy, design is wrong.

Every API decision is checked against both. This is why gnokee has
both narrative recall (`gnokee_recall`) and typed clinical reads
(`gnokee_lab_query`, `gnokee_med_query`) — Omur needs the latter
for safety-critical reads, while noggin / personal corpora need the
former.

## How do I report a bug or ask a question?

See [`SUPPORT.md`](../SUPPORT.md). Quick version: bugs / features →
GitHub Issues with the templates; questions → GitHub Discussions;
security → [`SECURITY.md`](../SECURITY.md).
