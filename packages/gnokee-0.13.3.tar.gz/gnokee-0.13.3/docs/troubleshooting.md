# Troubleshooting

> Symptom → cause → fix. If something here is wrong or missing,
> open a [bug report](https://github.com/omurlabs/gnokee/issues/new?template=bug_report.yml)
> or a doc PR.

## Compose stack

### `make up` hangs / Neo4j healthcheck fails

**Symptom.** `docker compose ps` shows Neo4j as `(unhealthy)` or
healthcheck never reports healthy.

**Cause.** Neo4j 5 takes ~10–30 s to come up cold; the healthcheck
runs `cypher-shell` which itself requires the bolt port to be
listening.

**Fix.** Wait. The healthcheck has 10 retries with 10 s interval
(see `docker-compose.yml`); first start is the slow one. If it
hasn't come up after 5 minutes, check `docker compose logs neo4j`
for OOM / port-conflict errors. On a Mac, ensure Docker Desktop has
≥ 4 GB RAM allocated.

### TEI image fails to pull on linux/amd64

**Symptom.** `docker compose pull tei` fails with
`no matching manifest for linux/amd64 in the manifest list entries`.

**Cause.** The default `cpu-arm64-latest` tag is arm64-only.

**Fix.** Override `GNOKEE_TEI_IMAGE` for amd64:

```bash
GNOKEE_TEI_IMAGE=ghcr.io/huggingface/text-embeddings-inference:cpu-1.9 make up
```

Or set it permanently in `.env`:

```text
GNOKEE_TEI_IMAGE=ghcr.io/huggingface/text-embeddings-inference:cpu-1.9
```

### `make up` doesn't start TEI

**Symptom.** Postgres + Neo4j come up, TEI is missing.

**Cause.** TEI is behind the `embeddings` profile in
`docker-compose.yml`. Plain `docker compose up -d` skips it.

**Fix.** Use `make up` (it passes `--profile embeddings`) or
`docker compose --profile embeddings up -d`.

### Postgres port collision

**Symptom.** `Bind for 0.0.0.0:5432 failed: port is already
allocated`.

**Cause.** A local Postgres (Homebrew, system) is already on 5432.

**Fix.** Remap in `.env`:

```text
GNOKEE_PG_PORT=5433
GNOKEE_PG_DSN=postgresql://gnokee:gnokee@localhost:5433/gnokee
```

Both vars need updating — the port in the DSN and the host-port
mapping must match.

## Embeddings

### `pgvector dim mismatch: expected 1024 got N`

**Symptom.** Insert into `content_embedding` fails with a
dimension-mismatch error.

**Cause.** The embedder returned a vector of the wrong dimension.
gnokee's `vector(1024)` column is locked to bge-m3.

**Fix.** Confirm `GNOKEE_EMBED_MODEL=bge-m3` and that the TEI / Ollama
endpoint is serving bge-m3 specifically. If you swapped to a different
model, you need a destructive re-embed migration — see
[`extending.md`](extending.md) §"Swapping the embedder".

### Embedder timeouts under load

**Symptom.** `EmbeddingsUnavailable` raised on ingest, recall slow.

**Cause.** TEI is single-process by default; concurrent ingest +
recall can saturate it. Mac CPU image is also slow on large
batches.

**Fix.**

- Increase `--max-batch-tokens` in the TEI command (default 4096
  in `docker-compose.yml`).
- Switch to the GPU image for production.
- For Mac dev, use Homebrew TEI binary (Metal) or Ollama
  `/v1/embeddings`.
- Reduce concurrency at the ingest call site (`asyncio.Semaphore`).

### Ollama embeddings shape mismatch

**Symptom.** Embedder returns `{"embedding": [...]}` instead of
TEI's `[[...]]` shape, or vice versa.

**Cause.** Two endpoint shapes exist. gnokee's `TEIClient`
auto-detects via fallback (TEI `/embed` first, OpenAI-compatible
`/v1/embeddings` second).

**Fix.** None needed in v0.3+ — Q6 validated dual-shape parity
(cosine 1.0000 between TEI and Ollama). If you're on an older
version, upgrade.

## Ingest

### Ingest accepts a naive datetime then crashes

**Symptom.** `ValidationError: datetime is not timezone-aware`.

**Cause.** gnokee enforces tz-aware UTC datetimes at the Pydantic
boundary. Passing `datetime.now()` (naive) fails.

**Fix.**

```python
from datetime import datetime, timezone

valid_at = datetime.now(timezone.utc)
# or for a known historical time:
valid_at = datetime(2026, 5, 1, tzinfo=timezone.utc)
```

### Ingest creates duplicate Graphiti episodes for the same source event

**Symptom.** Re-running an ingest for the same logical event creates
multiple `EpisodicNode`s in Neo4j.

**Cause.** Q1 spike found that Graphiti deduplicates on `name`, not
on a stable consumer-side ID.

**Fix.** Pass `our_id="..."` on every ingest. gnokee's idempotency
check returns `replayed=True` when `(tenant_id, our_id)` already
exists — no duplicate Graphiti episode is created.

```python
receipt = await gnokee.ingest_episode(
    pipeline=pipeline,
    tenant_id="t1",
    content="...",
    valid_at=valid_at,
    our_id=f"pulse:{tenant}:{window_start.isoformat()}",
)
```

### `ValidationError: tenant_id required`

**Symptom.** Ingest or recall raises on missing `tenant_id`.

**Cause.** Production code paths require `tenant_id` explicitly —
there is no implicit fallback. `GNOKEE_TENANT_DEFAULT` is read
**only** by `gnokee.demo` and integration tests.

**Fix.** Pass `tenant_id="..."` on every API call. For single-user
workloads `"default"` is a valid value, but it's still passed
explicitly.

### Ingest succeeds but `gnokee_recall` returns nothing

Check, in order:

1. **Did you pass the same `tenant_id`?** Cross-tenant queries
   return zero by design.
2. **Is `valid_at` ≤ now?** `gnokee_recall.valid_at` defaults to
   `datetime.now(UTC)` and stage 2a filters
   `ep.valid_at <= $valid_at`. A future-dated episode is invisible
   under the default.
3. **Is the episode lite-mode without #56?** v0.3 lite-mode
   episodes were invisible to `gnokee_recall` until #56 wired the
   minimal `Episodic` node write. If you're on v0.3.0 lite mode,
   upgrade or run `gnokee.maintenance.run_deferred_extraction()` to
   backfill the narrative side.
4. **Empty content embedding?** A zero-norm embedding (all-zero
   vector) ranks last in cosine. Check the TEI response shape and
   that content actually reached the embedder.
5. **Bi-temporal supersession?** `asserted_until <= as_of` filters
   the episode out. Pass an earlier `as_of` to time-travel.

## Recall

### Recall returns facts from another tenant

**Treat this as a security report.** See
[`SECURITY.md`](../SECURITY.md). Cross-tenant leak is a critical
bug.

### Recall returns empty `contradicts: []` even though contradictions exist

**Possible causes:**

- `surface_contradictions=False` was passed.
- LLM was unavailable during the original ingest — Q4 contradiction
  pipeline degraded gracefully and skipped detection. Re-ingest the
  episode with the LLM up, or re-run contradiction detection
  manually.
- Lite-mode ingest skipped Stage 7 (contradiction). Run deferred
  extraction; contradictions populate as part of the narrative
  backfill.

### `gnokee_recall.encrypted_bodies[]` is non-empty but I want plaintext

**Cause.** The episode was ingested with `encrypted_body=...` (v0.4
DEK pathway). gnokee never decrypts.

**Fix.** Decrypt on the consumer side using `key_id` and your KMS.
The plaintext text body is never available from gnokee for
encrypted episodes — that's the architectural invariant.

## Forgetting

### `gnokee_forget` left rows behind in pgvector

Q5 spike validated propagation across pgvector + Neo4j +
contradiction store + derived summaries. If you see residue:

1. Confirm you're on a version that ships `gnokee_forget` (v0.2+).
2. Check the returned `ForgetReceipt` — it enumerates affected
   artefacts. If a store is missing, file a bug.

## MCP server

### MCP tool not visible to Claude Desktop / Code / Cursor

**Cause.** Most likely the wrong transport.

**Fix.** All three clients use stdio. Confirm `GNOKEE_MCP_HTTP=0` (or
unset) and that your client config invokes `python -m gnokee.mcp` as
a stdio process — not HTTP. See
[`../examples/03_mcp_clients/`](../examples/03_mcp_clients/) for
known-good config snippets.

### MCP HTTP transport fails with 404

**Cause.** HTTP transport is dev-only and behind
`GNOKEE_MCP_HTTP=1`. The path is `/mcp` (FastMCP default).

**Fix.** Use `GNOKEE_MCP_HTTP=1 python -m gnokee.mcp` and connect to
`http://localhost:PORT/mcp` (default port published by FastMCP). For
production, use stdio + a wrapping process supervisor.

### MCP tool ignores `tenant_id`

**Cause.** Bug, or a stale gnokee version.

**Fix.** Confirm gnokee version (`pip show gnokee`). If the MCP tool
schema doesn't list `tenant_id` as a required arg in
`mcp.list_tools()` output, file a security report — every tool
requires it.

## Multi-tenancy

### Postgres RLS not enforced on a per-request basis

**Cause.** Consumer middleware did not call
`set_config('app.current_tenant', $tenant, true)` on the connection
before issuing queries.

**Fix.** Wire the GUC at connection acquire. See
[`deploy.md`](deploy.md) §"RLS GUC pattern" for the canonical
shape. The `true` third-arg makes it transaction-local — required
when reusing pooled connections across tenants.

### Neo4j cross-tenant query

**Cause.** A Cypher query missing the `group_id` predicate. Neo4j
Community has no row-level security; isolation is `group_id`
discipline.

**Fix.** Every gnokee Cypher includes `WHERE n.group_id = $tenant`
on every node and edge in the pattern. If you're writing your own
Cypher (e.g. extending gnokee), follow the same rule.

## Migrations

### Migration file ordering issue

**Cause.** Migrations run in lexicographic order by filename. A
filename out of order will run before its dependencies.

**Fix.** Filenames are `NNNN_<name>.sql` with monotonic 4-digit
prefixes. New migrations should pick the next free number, not
re-use a gap.

### Migration partial-applied after a failure

gnokee's runner does **not** auto-rollback partially-applied
migrations. If a migration crashes mid-flight:

1. Inspect Postgres state — what did it apply?
2. Either complete the migration manually (psql) and stamp the
   `schema_migrations` table, or roll back the partial state and
   re-run.
3. Investigate the original failure — it's almost always missing
   prerequisite state (a column the migration assumed existed).

## LLM endpoint

### `LLMUnavailable` during ingest

**Cause.** The contradiction pipeline (Stage 7) needs the LLM.
gnokee degrades gracefully: ingest succeeds with `contradicts=[]`
and the failure is logged.

**Fix.** Confirm `GNOKEE_OPENAI_BASE_URL` + `GNOKEE_OPENAI_API_KEY`
in env and that the endpoint accepts gpt-4o-mini (or whichever
`GNOKEE_LLM_MODEL` you set). Run a manual `curl` against
`{base_url}/chat/completions` with the same key to confirm.

### `OpenAI auth error: 401 Unauthorized`

**Cause.** Wrong key, wrong base URL, or a key that's out of credit.

**Fix.** Check the value of `GNOKEE_OPENAI_API_KEY`. For Anthropic
via `litellm-proxy`, confirm the proxy is forwarding the right
header.

### Hosted-LLM rate limits during eval runs

**Fix.** Cap candidate-pair count per ingest run, or move evals to
a self-hosted LLM (Ollama, vLLM). The Q4 minicorpus tests cap at
≤20 candidate-pairs and cache responses; copy that pattern.

## Tests

### Integration test fails with "compose stack not running"

**Fix.** `make up && make test-integration` — the integration
tests are marked `@pytest.mark.integration` and require live
Postgres + Neo4j + TEI + an LLM endpoint.

### Pytest hangs on session-scoped fixtures

**Cause.** Some fixtures are session-scoped (asyncpg pool, Neo4j
driver). pytest-asyncio needs `asyncio_default_fixture_loop_scope =
"session"` (already set in `pyproject.toml`). If you're running
tests outside the project root, the config may not load.

**Fix.** Run pytest from the project root, or pass
`-c pyproject.toml`.

## Where else to look

- [`faq.md`](faq.md) — design questions, "is gnokee right for me".
- [`alternatives.md`](alternatives.md) — gnokee vs Mem0 / Graphiti
  / Zep / basic-memory.
- [`integration_patterns.md`](integration_patterns.md) +
  [`integration/consumer-patterns.md`](integration/consumer-patterns.md)
  — integrator recipes.
- [`adr/`](adr/) — design decisions and the *why* behind them.
- [GitHub Issues](https://github.com/omurlabs/gnokee/issues) +
  [Discussions](https://github.com/omurlabs/gnokee/discussions).
