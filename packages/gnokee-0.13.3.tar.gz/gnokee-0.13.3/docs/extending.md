# Extending gnokee

> Status: pre-1.0. Extension points exist but their stability mirrors
> the rest of the public surface — additive changes are common,
> breaking changes are gated by ADRs.

gnokee is library + MCP server. There are five places where a
consumer plausibly extends it without forking:

1. **Ingest adapter** — turns a source format into `EpisodeIn` + a
   call to `gnokee.ingest_episode`.
2. **Embedder** — any endpoint returning 1024-dim vectors and
   speaking either the TEI `/embed` or OpenAI-compatible
   `/v1/embeddings` shape.
3. **LLM endpoint** — any OpenAI-compatible endpoint for entity
   extraction (Graphiti) and contradiction classification (Q4).
4. **Storage backends** — Postgres + Neo4j Community is the v0.x
   contract. Future swaps go through ADR-0005.
5. **Custom MCP tools wrapping gnokee** — your own `gnokee_*` tools
   that call the gnokee Python API. Discouraged in core; encouraged
   in consumer apps.

Beyond these, you should fork. Substantive changes to the
contradiction model, bi-temporal axes, supersession behaviour, or
forgetting modes are architectural decisions; please open an ADR
or an issue rather than monkey-patching.

## 1. Writing an ingest adapter

Adapters are thin shims. The shape:

```text
source-specific input  →  parse / normalise  →  render to episode body
                                                         ↓
                              gnokee.ingest_episode(content=..., valid_at=...)
```

There is no Python interface to implement. An adapter is whatever
async function turns your source into a `gnokee.ingest_episode`
call.

### Minimal example — RSS adapter

```python
import asyncio
from datetime import datetime, timezone
import feedparser
import gnokee

async def ingest_rss_feed(pipeline, tenant_id: str, feed_url: str):
    feed = feedparser.parse(feed_url)
    for entry in feed.entries:
        await gnokee.ingest_episode(
            pipeline=pipeline,
            tenant_id=tenant_id,
            content=f"# {entry.title}\n\n{entry.summary}\n\nSource: {entry.link}",
            valid_at=datetime(*entry.published_parsed[:6], tzinfo=timezone.utc),
            our_id=f"rss:{feed_url}:{entry.id}",
            sensitive="public",
        )
```

### Adapter checklist

- [ ] **`tenant_id` is mandatory.** No implicit fallback.
- [ ] **`valid_at` is world-time** — when the fact was true. NOT
      `datetime.now()`. Hard rule. The most common adapter bug.
- [ ] **`our_id` is recommended.** Re-running the adapter must be
      idempotent on `(tenant_id, our_id)`. Otherwise duplicate
      episodes accumulate.
- [ ] **Tz-aware UTC datetimes only.** Naive datetimes are rejected
      at the Pydantic boundary.
- [ ] **Pick the right ingest mode.**
      - High-cadence (> 1 episode/min/tenant) → `extract=False`
        (lite mode) + a deferred-extraction schedule.
      - One-off / low-cadence → `extract=True` (full).
      See [`integration_patterns.md`](integration_patterns.md).
- [ ] **Body shape matters for typed parsers.** If your data
      contains lab results or medication events, render them in the
      shapes documented in
      [`integration/consumer-patterns.md`](integration/consumer-patterns.md)
      so the deterministic parsers populate `lab_record` / `med_record`.
- [ ] **Backpressure.** TEI is single-threaded by default; cap
      concurrent ingest with `asyncio.Semaphore`.

### Failure handling

`ingest_episode` raises typed errors:

- `ValidationError` — fix the adapter input.
- `EmbeddingsUnavailable` / `GraphStoreError` / `VectorStoreError`
  → retry with backoff. The compose stack may have a transient
  issue.
- `LLMUnavailable` → ingest succeeded; contradiction detection was
  skipped. Re-run contradiction detection later or accept the
  degraded `contradicts=[]`.

### Where adapters do NOT live

In core. The architecture page is explicit: adapters are thin
shims, consumer-owned. gnokee does not ship `files`, `md-vault`,
`api-push`, `rss`, `email`, or `pulse-sdk` adapters. Examples in
[`../examples/`](../examples/) demonstrate shapes; production
adapters live in the consumer's repo.

## 2. Swapping the embedder

The embedder contract:

- Input: a list of UTF-8 strings.
- Output: a list of 1024-dim float vectors.
- Wire shape: TEI `/embed` (`{"inputs": [...]}` → `[[...]]`) **or**
  OpenAI-compatible `/v1/embeddings`
  (`{"input": [...], "model": "..."}` →
  `{"data": [{"embedding": [...]}, ...]}`).

gnokee's `TEIClient` auto-detects the shape via fallback (TEI first,
OpenAI-compatible second). Q6 spike validated parity: cosine 1.0000
between TEI bge-m3 and Ollama bge-m3.

Set `GNOKEE_TEI_URL` to your endpoint:

```text
# TEI native
GNOKEE_TEI_URL=http://localhost:8080
GNOKEE_EMBED_MODEL=bge-m3

# Ollama fallback (Mac dev with Metal)
GNOKEE_TEI_URL=http://localhost:11434/v1
GNOKEE_EMBED_MODEL=bge-m3:latest
```

### The 1024-dim invariant

gnokee's `content_embedding.embedding` column is `vector(1024)`.
Graphiti's vector indexes are also 1024-dim. **Switching to a
different-dim model is a destructive re-embed migration**, not a
configuration change.

### Re-embed migration playbook (e.g. swapping bge-m3 → a 768-dim model)

This is destructive. Plan an outage window.

1. **Stop ingest.** No new episodes during migration.
2. **Add v2 embedding column** alongside the old one:
   ```sql
   ALTER TABLE content_embedding ADD COLUMN embedding_v2 vector(768);
   ```
3. **Backfill v2.** Re-embed every existing episode body with the
   new model; populate `embedding_v2`.
4. **Switch reads to v2.** Update `gnokee.retrieval` Cypher / SQL
   to read `embedding_v2`. Deploy.
5. **Cutover writes.** Update `gnokee.ingest` to write to
   `embedding_v2`. Deploy.
6. **Drop v1.** After confidence window:
   ```sql
   ALTER TABLE content_embedding DROP COLUMN embedding;
   ALTER TABLE content_embedding RENAME COLUMN embedding_v2 TO embedding;
   ```
7. **Re-spike.** Re-run Q2 cross-lingual on the new model. If it
   doesn't beat the bge-m3 baseline, revert.
8. **Re-bootstrap Neo4j vector indexes.** Graphiti's
   `entity_edge_fact_embedding` and `entity_node_name_embedding`
   indexes are 1024-dim today; rebuild at the new dim.

This playbook is the same shape used in the Q1 → Q2 transition.
If you need this in production, open an ADR — it's a load-bearing
decision.

### Custom embedder contract

If you need a non-OpenAI / non-TEI shape, subclass or replace
`gnokee.embeddings.TEIClient`. The interface is small:

```python
class EmbeddingClient(Protocol):
    async def embed(self, texts: list[str]) -> list[list[float]]: ...
    async def embed_one(self, text: str) -> list[float]: ...
```

Wire your replacement when constructing `IngestPipeline` and
`RecallPipeline`.

## 3. Swapping the LLM endpoint

gnokee uses an OpenAI-compatible endpoint for two purposes:

- **Graphiti narrative extraction** (Stage 4 of ingest).
- **Q4 contradiction classifier** (Stage 7 of ingest).

Both go through `gnokee.llm.OpenAIClient`, which respects
`GNOKEE_OPENAI_BASE_URL` + `GNOKEE_OPENAI_API_KEY` +
`GNOKEE_LLM_MODEL`.

### Tested endpoints

- **OpenAI direct.** `base_url="https://api.openai.com/v1"`. Default.
- **Anthropic via litellm-proxy.** Run `litellm` locally; point
  `GNOKEE_OPENAI_BASE_URL` at it.
- **Ollama with OpenAI compat.** `base_url="http://localhost:11434/v1"`,
  model = whatever ollama is serving.
- **vLLM serving.** `base_url="http://vllm-host:8000/v1"`.
- **Bedrock / Vertex via proxy.** Use a proxy that exposes
  OpenAI-compatible `/chat/completions`.

### Why no prompt-swap surface

The Q4 contradiction prompt is a load-bearing internal —
swapping it changes the eval-delta gate baseline. If you need a
different classifier, that's an ADR conversation, not a config
toggle. The Q4 minicorpus + 80% accuracy threshold is the contract.

For Graphiti's entity-extraction prompt, see graphiti-core
upstream — gnokee inherits its prompt; a custom prompt requires
forking graphiti-core. We track upstream at
`docs/upstream-contributions/`.

### Token + cost guards

There is no built-in per-tenant LLM-cost guard in v0.x. Implement
it consumer-side via a litellm-proxy with rate limits, or wrap
the LLM endpoint with your own quota layer.

## 4. Storage backends

The v0.x storage contract is Postgres + Neo4j Community + bge-m3.
Substituting any layer is non-trivial.

### Why Neo4j Community

Per [ADR-0005](adr/0005-graph-backend-tradeoff.md):

- FalkorDB dropped on SSPL grounds (incompatible with Omur SaaS
  plans).
- Kùzu archived 2025-10-10 by upstream.
- Apache AGE: 5–7 person-weeks effort with structural blockers on
  vector cosine + fulltext. Deferred until on-prem-non-GPL or
  ops-consolidation triggers materialise.

If you need an Apache-2.0-pure stack today, run pgvector-only and
accept the trade-offs (no Cypher edge facts, no contradiction
edges through Graphiti). The architecture page documents the
trade-off space.

### Why pgvector

Per [ADR-0004](adr/0004-gnokee-owns-retrieval.md): pgvector is
already required for facts + multi-tenancy + RLS. Adding it costs
zero extra services. Q2 spike validated direct cosine retrieval at
100% top-1 cross-lingual on the same corpus where Graphiti's
combined hybrid search scored 25%.

### Future backend swaps

If you fork to swap a backend:

- Preserve the bi-temporal axes — `valid_at`, `valid_until`,
  `asserted_at`, `asserted_until`. The retrieval Cypher / SQL
  half-pairs ride on these.
- Preserve `tenant_id` on every row, every node, every edge.
- Preserve `group_id = tenant_id` discipline if the new backend
  has no row-level security.
- Re-run the Q2 + Q3 + Q4 + Q5 spike harnesses to confirm no
  regression.
- Open an ADR amendment to ADR-0005.

## 5. Custom MCP tools

You can wrap gnokee in your own MCP server with consumer-specific
tools. The shape:

```python
import mcp.server.fastmcp as fm
import gnokee

server = fm.FastMCP("my-app-mcp")

@server.tool("my_app_search")
async def my_app_search(tenant_id: str, query: str) -> dict:
    resp = await gnokee.recall(
        pipeline=pipeline,
        tenant_id=tenant_id,
        text=query,
    )
    # post-process, filter, re-shape...
    return {"results": [{"text": f.text, "uuid": str(f.fact_uuid)} for f in resp.facts]}
```

Custom tools should:

- Always require `tenant_id` from the caller.
- Never bypass gnokee's bi-temporal filters by reading the
  underlying tables directly without applying `tenant_id`.
- Surface contradictions; never auto-resolve.

If your custom tool would benefit other consumers, propose it as a
new core `gnokee_*` tool via a feature-request issue — see the
contribution stance in [`../CONTRIBUTING.md`](../CONTRIBUTING.md).

## Stability promise per surface

| Surface | Stability (pre-1.0) |
|---|---|
| Adapter pattern (call `gnokee.ingest_episode` per source event) | stable |
| `EpisodeIn` field set | additive only |
| Embedder wire shape (TEI / OpenAI-compat) | stable |
| 1024-dim invariant | stable; change requires ADR + re-embed migration |
| LLM endpoint contract (OpenAI-compatible) | stable |
| `GNOKEE_*` env vars | stable; new vars may appear |
| Internal pipeline shapes (`IngestPipeline`, `RecallPipeline`) | unstable |
| Q4 prompt template | unstable; change requires eval-delta gate |
| Graphiti version pin | bump = ADR per `pyproject.toml` floor |

## See also

- [`integration_patterns.md`](integration_patterns.md) — lite vs full ingest.
- [`integration/consumer-patterns.md`](integration/consumer-patterns.md) — typed-parser body shapes.
- [`api/python.md`](api/python.md) — full Python API reference.
- [`adr/0004-gnokee-owns-retrieval.md`](adr/0004-gnokee-owns-retrieval.md) — retrieval design.
- [`adr/0005-graph-backend-tradeoff.md`](adr/0005-graph-backend-tradeoff.md) — backend choice.
- [`upstream-contributions/`](upstream-contributions/) — drafts of PRs we send upstream (graphiti-core, etc.).
