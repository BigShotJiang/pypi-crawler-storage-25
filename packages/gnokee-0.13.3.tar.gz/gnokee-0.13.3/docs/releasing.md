# Releasing gnokee

> Status: pre-1.0. Releases are tag-driven; PyPI publishes via OIDC
> Trusted Publishing (no PyPI token in GitHub secrets). Most
> contributors don't cut releases — this doc is for the maintainer.

## Versioning policy

[Semantic Versioning 2.0](https://semver.org/spec/v2.0.0.html), with
the pre-1.0 caveat: minor versions may carry breaking changes when
gated by an ADR. We mark every breaking change in
[`CHANGELOG.md`](../CHANGELOG.md) under a `### Breaking` heading and
the migration is documented inline.

| Bump | When |
|---|---|
| Patch (`0.4.0 → 0.4.1`) | Bug fixes, doc-only changes, internal refactors with no behaviour change. No new public surface. |
| Minor (`0.4.x → 0.5.0`) | New features, new MCP tools, new ADRs landed, additive Python API surface. May break pre-1.0. |
| Major (`0.x → 1.0`) | First stable line; API stability commitment. See `docs/specs/v1.md` (TBD). |
| Release-candidate (`0.5.0-rc1`) | Optional. Triggers TestPyPI publish for end-to-end smoke against a real installer. |

## Release cadence

Tag-driven, not calendar-driven. A release is cut when:

- A coherent batch of work is on `main` (one or more PRs already merged).
- CHANGELOG `[Unreleased]` is non-empty and accurately describes the
  shape of the next version.
- CI is green on `main`.
- Eval-delta gate (per [`eval_delta_gate.md`](eval_delta_gate.md))
  has not regressed against the previous release line.

There is no minimum interval. Recent cadence has been ~1 week
between minor releases during active development; expect that to
slow as v0.x stabilises.

## Pre-release checklist

Run before tagging:

- [ ] `git status` clean on `main`, latest pulled.
- [ ] CI green on the most recent `main` commit.
- [ ] `make test-unit` and `make test-integration` pass locally
      against the compose stack with a real LLM key.
- [ ] `pip-audit . --strict` clean (CI runs this; double-check after
      dependency bumps).
- [ ] Release notes already populated in
      [`CHANGELOG.md`](../CHANGELOG.md) under the new version
      heading. `[Unreleased]` reset to empty.
- [ ] `pyproject.toml` `version` bumped.
- [ ] `docs/backlog.md` rolled forward — items closed in this
      release moved into the "Closed in v0.x.y" section; new
      release scope table reset.
- [ ] If any ADR landed, it's referenced in CHANGELOG.

## Release flow

### 1. Prep PR — `chore(release): vX.Y.Z prep`

Single commit on a release-prep branch:

- Bump `pyproject.toml` `version`.
- Move `CHANGELOG.md` `[Unreleased]` content into a dated `## [X.Y.Z] — YYYY-MM-DD` section. Keep `[Unreleased]` empty above it.
- Update `docs/backlog.md` per the checklist above.
- Update README status / roadmap if the release shifts a phase.

PR title: `chore(release): vX.Y.Z prep`. Conventional Commits.

Merge to `main` on green CI. Do **not** tag from the PR branch.

### 2. Tag

After the prep PR merges, on `main`:

```bash
git pull --ff-only
git tag -a vX.Y.Z -m "vX.Y.Z"
git push origin vX.Y.Z
```

The push to a `v*` tag triggers
[`.github/workflows/pypi-publish.yml`](../.github/workflows/pypi-publish.yml).

### 3. CI publishes

`pypi-publish.yml` does:

1. Build wheel + sdist with `python -m build`.
2. Verify the wheel has no duplicate entries (regression guard for
   the v0.2.3 `force-include` double-shipping bug).
3. Upload the dist artefacts.
4. **If tag matches `v*-rc*`**: publish to TestPyPI via OIDC.
5. **If tag matches `v*` and is not an `-rc`**: publish to PyPI via
   OIDC.

The PyPI environments (`pypi`, `testpypi`) and the OIDC trust
relationships are pre-registered in
[`pypi-publish.yml`](../.github/workflows/pypi-publish.yml) header.
Re-registration is one-time per environment and only the maintainer
needs it.

### 4. Verify

After CI finishes:

- Check the new version is visible at
  https://pypi.org/project/gnokee/ (or
  https://test.pypi.org/project/gnokee/ for an `-rc`).
- Run `pip install --upgrade gnokee` in a clean venv. Run
  `python -c "import gnokee; print(gnokee.__version__)"` —
  should print the new version.
- For minor releases, run `make demo` against the new wheel.

### 5. Announce

- GitHub release notes: copy the relevant CHANGELOG section into the
  `gh release create vX.Y.Z` body. Mark as latest.
- README badges (`pypi`, `npm`) auto-update.
- For meaningful releases, post a short note in Discussions.

## Manual TestPyPI dry-run

Before a real release that lands non-trivial dependency changes or
build-config changes, exercise TestPyPI manually:

```text
GitHub → Actions → pypi-publish → Run workflow
  Branch: main
  target: testpypi
```

This builds, publishes to TestPyPI, and skips the real PyPI step.
Useful for catching wheel-content regressions without burning a real
version number (PyPI does not allow re-upload of the same version,
even if yanked).

## Release-candidate flow (`-rc*`)

For risky releases (new MCP tool surface, new dependency, new
storage backend):

```bash
git tag -a v0.5.0-rc1 -m "v0.5.0-rc1"
git push origin v0.5.0-rc1
```

`-rc` tags publish to TestPyPI via the same workflow. Iterate (`rc1`,
`rc2`, …) until ready, then tag the final `vX.Y.Z` from the same
commit.

## Rollback / hotfix

PyPI **does not allow re-uploading the same version**, even after
yanking. If a release is broken:

1. **Yank the bad release** on PyPI:
   `pypi.org/project/gnokee/X.Y.Z/ → Manage → Yank`.
2. **Cut a patch** on the same minor line: bump to `X.Y.Z+1`, follow
   the normal release flow.
3. Update `CHANGELOG.md`: keep the yanked version's section, add a
   note under it: `> Yanked YYYY-MM-DD — see X.Y.Z+1.`
4. Don't `--force-push` to rewrite the tag. Tags are immutable once
   pushed; a new patch is the only safe path.

## Post-release

- Move new candidates from the v0.4 backlog to v0.5.x scope, etc.
- Reset `[Unreleased]` in CHANGELOG (already empty after step 1, but
  confirm).
- Close any GitHub issues referenced as "fixed in vX.Y.Z" in the
  CHANGELOG.

## Maintainer notes

- The PyPI Trusted Publishing setup is repo + workflow + environment
  scoped — re-creating the workflow file or moving it requires
  re-registering on PyPI / TestPyPI per the comments at the top of
  `.github/workflows/pypi-publish.yml`.
- npm package ownership is held under the same name (`gnokee`) but
  no JS code is published yet — the npm release flow does not exist.
  Add it when there's a JS surface to ship.
- `pyproject.toml` `version` is the single source of truth. Do not
  duplicate it elsewhere.
