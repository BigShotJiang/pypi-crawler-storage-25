# MCP tool reference

> Status: pre-1.0 — tool schemas may break across minor versions
> when gated by an ADR. Authoritative schema source is
> `mcp.list_tools()` against a running gnokee MCP server.

gnokee exposes eleven MCP tools via FastMCP. Default transport is
stdio (for Claude Desktop, Claude Code, Cursor, Continue, and any
other stdio MCP client). HTTP transport is dev-only behind
`GNOKEE_MCP_HTTP=1`.

```bash
python -m gnokee.mcp                         # stdio
GNOKEE_MCP_HTTP=1 python -m gnokee.mcp       # HTTP (dev only)
```

Client config snippets live under
[`../../examples/03_mcp_clients/`](../../examples/03_mcp_clients/).

## Tools at a glance

| Tool | Purpose |
|---|---|
| [`gnokee_ingest_episode`](#gnokee_ingest_episode) | Store a fact / event / observation in bi-temporal memory. |
| [`gnokee_recall`](#gnokee_recall) | Natural-language fact retrieval with provenance handles. |
| [`gnokee_query`](#gnokee_query) | Declarative envelope retrieval (date-range, topic routing, `output_shape`). |
| [`gnokee_fact_provenance`](#gnokee_fact_provenance) | Fetch the original episode body behind a `fact_uuid`. |
| [`gnokee_history_of`](#gnokee_history_of) | Supersession-DAG for an episode (Cytoscape-flat envelope; time-travel via `as_of`). |
| [`gnokee_fact_history`](#gnokee_fact_history) | Append-only revision log for a single fact (lineage + `superseded_at`). |
| [`gnokee_lab_query`](#gnokee_lab_query) | Typed clinical-lab reads (`latest \| history \| min \| max \| avg \| count \| abnormal`). |
| [`gnokee_med_query`](#gnokee_med_query) | Typed medication-history reads (`active \| history \| allergies \| switches`). |
| [`gnokee_wiki_export`](#gnokee_wiki_export) | llms.txt manifest + per-entity wiki bundle export. |
| [`gnokee_forget_episode`](#gnokee_forget_episode) | Hard-delete a single episode; refuses on supersession chain unless `cascade=True`. |
| [`gnokee_forget_tenant`](#gnokee_forget_tenant) | Hard-delete an entire tenant's memory; defaults to `dry_run=True`. |

All eleven are unauthenticated in v0.x — gnokee trusts the
caller-supplied `tenant_id`. Any deployment shared across tenants
must wrap gnokee with an auth proxy. Real auth is post-v0.x scope.

## Common parameters

These appear on multiple tools and behave identically across them:

| Parameter | Type | Notes |
|---|---|---|
| `tenant_id` | string | Mandatory on every tool. |
| `valid_at` | ISO 8601 string \| null | World-time pin. Nullable; MCP handler resolves null → `datetime.now(UTC)` *before* the Python call. |
| `as_of` | ISO 8601 string \| null | Source-tx-time pin. Nullable; same null handling. |
| `since` / `until` | ISO 8601 string \| null | Range bounds for clinical typed reads. |

ISO 8601 timestamps must be UTC (`Z` suffix or `+00:00`). The
Pydantic boundary rejects naive datetimes as defence-in-depth.

## `gnokee_ingest_episode`

Store a new fact, event, or observation in bi-temporal memory. Call
this whenever the user states something worth remembering, or when
an external source delivers a new fact-bearing payload.

`valid_at` = when the fact was true in the world (not the ingestion
time); `asserted_at` = when you learned of it (defaults to now).
Returns the episode UUID, the UUIDs of any facts created, and any
contradictions detected against existing facts; gnokee never
auto-resolves — surface contradictions to the user.

### Input

| Field | Type | Required | Description |
|---|---|---|---|
| `tenant_id` | string | yes | Memory partition. |
| `content` | string | xor `encrypted_body` | Plaintext episode body. |
| `encrypted_body` | object | xor `content` | `{ciphertext, nonce, key_id, content_for_embedding?}` — pre-encrypted body, gnokee never decrypts. |
| `valid_at` | ISO 8601 | yes | When the fact was true in the world. |
| `valid_until` | ISO 8601 \| null | no | World-time end of validity. |
| `asserted_at` | ISO 8601 \| null | no | When you learned of it. Default `now()`. |
| `our_id` | string \| null | no | Consumer-supplied stable id for idempotency on `(tenant_id, our_id)`. |
| `corrects` | UUID string \| null | no | UUID of a prior episode this one supersedes. |
| `sensitive` | `"public" \| "private" \| "clinical"` | no | Default `"private"`. |
| `language` | ISO 639-1 \| null | no | Auto-detected when null. |
| `extract` | bool | no | Default `true` (full mode). `false` = lite (Stages 4 + 7 skipped). |

### Output

```json
{
  "episode_uuid": "string",
  "asserted_at": "ISO 8601",
  "created_fact_uuids": ["string"],
  "contradicts": [
    {
      "fact_uuid": "string",
      "verdict": "refinement|update|contradiction",
      "summary": "string",
      "valid_at": "ISO 8601"
    }
  ],
  "replayed": false,
  "extraction_deferred": false
}
```

When `replayed=true` (idempotency hit on `(tenant_id, our_id)`),
`created_fact_uuids` is `[]`. When `extraction_deferred=true`
(`extract=false`), same.

### Example call

```json
{
  "tool": "gnokee_ingest_episode",
  "input": {
    "tenant_id": "omur:tenant-xyz",
    "content": "Started lisinopril 10mg PO daily for hypertension.",
    "valid_at": "2026-05-01T00:00:00Z",
    "our_id": "omur:meds:lisinopril:start:2026-05-01",
    "sensitive": "clinical"
  }
}
```

## `gnokee_recall`

Retrieve facts from bi-temporal memory. Call this before answering
questions about past user state, prior decisions, or stored
knowledge.

`valid_at` pins world-time (default: now); `as_of` pins source-time
(default: now). For most queries leave both unset. Returns
natural-language fact statements with provenance handles (UUIDs);
fetch full episode bodies via `gnokee_fact_provenance(fact_uuid)`
when a fact is contested or carries an `update` verdict and you
need the original source text. If `surface_contradictions`,
conflicting facts are returned alongside primaries with a `verdict`
(`refinement` / `update` / `contradiction`) and the conflicting
fact's `valid_at` — do not auto-pick a winner.

### Input

| Field | Type | Required | Description |
|---|---|---|---|
| `tenant_id` | string | yes | |
| `text` | string | yes | Natural-language query. |
| `as_of` | ISO 8601 \| null | no | Source-tx-time pin. Default `now()`. |
| `valid_at` | ISO 8601 \| null | no | World-time pin. Default `now()`. |
| `surface_contradictions` | bool | no | Default `true`. |
| `max_tokens` | int | no | Default `200`. Total response budget across lanes. |
| `top_k` | int | no | Default `10`. Candidate-pool size after rerank. |
| `top_k_bodies` | int | no | Default `3` (v0.4.x — issue #84). Max `episode_fallback` body rows emitted by the body lane. |
| `per_body_char_cap` | int | no | Default `600` (v0.4.x — issue #84). Per-body character cap before token accounting + emission. |

### Output

```json
{
  "facts": [
    {
      "text": "string",
      "fact_uuid": "string",
      "episode_uuid": "string",
      "valid_at": "ISO 8601",
      "asserted_at": "ISO 8601",
      "confidence": null,
      "contradicts": []
    }
  ],
  "truncated": false,
  "candidate_count": 0,
  "excerpts": [],
  "supersession_hints": [],
  "episode_fallback": [],
  "body_used": false,
  "retrieved_episode_external_ids": [],
  "recall_telemetry": { "...": "see python.md" },
  "encrypted_bodies": []
}
```

`encrypted_bodies` is non-empty when ranked episodes were ingested
via the encrypted-body branch — the consumer decrypts with their
KMS using `key_id`.

### Token-budget guidance

Default `max_tokens=200` matches the Q3 spike's median (125) plus
~60% headroom. For longer-form synthesis tasks, raise to 500. For
chat-style autocomplete, drop to 100. The Stage 6 budget split
across fact / excerpt / body lanes is reflected in
`recall_telemetry`.

### Example call

```json
{
  "tool": "gnokee_recall",
  "input": {
    "tenant_id": "omur:tenant-xyz",
    "text": "What is the user's current blood pressure medication?"
  }
}
```

## `gnokee_fact_provenance`

Fetch the full episode body and metadata behind a `fact_uuid`
returned by `gnokee_recall` or `gnokee_ingest_episode`. Call when a
fact is contested, carries an `update` / `contradiction` verdict,
or its source text is needed for the user-facing answer.

### Input

| Field | Type | Required |
|---|---|---|
| `tenant_id` | string | yes |
| `fact_uuid` | UUID string | yes |

### Output

```json
{
  "fact_uuid": "string",
  "fact_text": "string",
  "episode_uuid": "string",
  "episode_content": "string",
  "valid_at": "ISO 8601",
  "valid_until": null,
  "asserted_at": "ISO 8601",
  "asserted_until": null,
  "language": "en",
  "sensitive": "private",
  "encrypted_body": null
}
```

When the episode was ingested via `encrypted_body`,
`episode_content` is `""` and `encrypted_body` is populated with
`{episode_uuid, ciphertext, nonce, key_id}`. The consumer decrypts.

Returns `null` when no edge fact with that uuid exists for the
tenant (rather than throwing).

## `gnokee_lab_query`

Typed clinical-lab reads over the `lab_record` Postgres table. v0.2+.

### Input

| Field | Type | Required | Description |
|---|---|---|---|
| `tenant_id` | string | yes | |
| `analyte` | string \| null | required for ops other than `abnormal` | e.g. `"LDL"`, `"Total Cholesterol"`, `"HbA1c"`. |
| `op` | `"latest" \| "history" \| "min" \| "max" \| "avg" \| "count" \| "abnormal"` | yes | |
| `since` / `until` | ISO 8601 \| null | no | Range bounds for `history` / aggregate ops. |
| `as_of` / `valid_at` | ISO 8601 \| null | no | Bi-temporal pins. Default `now()`. |
| `limit` | int | no | Default 50; capped at 500. Applies to `history` and `abnormal`. |

### Output

```json
{
  "op": "latest",
  "rows": [
    {
      "episode_uuid": "string",
      "analyte": "LDL",
      "value_numeric": "138",
      "value_text": null,
      "unit": "mg/dL",
      "ref_range_low": "0",
      "ref_range_high": "100",
      "abnormal_flag": "H",
      "valid_at": "ISO 8601",
      "asserted_at": "ISO 8601"
    }
  ],
  "scalar": null,
  "count": 1
}
```

For `op="min" \| "max" \| "avg" \| "count"`, `scalar` is populated
and `rows` is empty. Aggregate ops skip rows with
`value_numeric IS NULL`.

`abnormal_flag` ∈ `{"L", "H", "C", null}` (low / high / critical).

### Example call

```json
{
  "tool": "gnokee_lab_query",
  "input": {
    "tenant_id": "omur:tenant-xyz",
    "analyte": "LDL",
    "op": "history",
    "since": "2026-01-01T00:00:00Z",
    "limit": 12
  }
}
```

## `gnokee_med_query`

Typed medication-history reads over the `med_record` Postgres
table. v0.2+.

### Input

| Field | Type | Required | Description |
|---|---|---|---|
| `tenant_id` | string | yes | |
| `op` | `"active" \| "history" \| "allergies" \| "switches"` | yes | |
| `drug_name` | string \| null | required for `op="history"` | |
| `since` / `until` | ISO 8601 \| null | no | Range bounds for `history`. |
| `as_of` / `valid_at` | ISO 8601 \| null | no | Bi-temporal pins. Default `now()`. |
| `limit` | int | no | Default 50; capped at 500. |

### Output

```json
{
  "op": "active",
  "rows": [
    {
      "episode_uuid": "string",
      "drug_name": "lisinopril",
      "drug_class": "ACE inhibitor",
      "dose_value": "10",
      "dose_unit": "mg",
      "frequency": "daily",
      "route": "PO",
      "event_kind": "start",
      "reason": "hypertension",
      "valid_at": "ISO 8601",
      "asserted_at": "ISO 8601"
    }
  ],
  "count": 1
}
```

`op="active"` returns the per-drug latest visible event with
`event_kind NOT IN ('stop', 'allergy')`.

`event_kind` vocabulary: `"start" | "increase" | "decrease" | "stop" | "switch" | "allergy" | …`.

### Example call

```json
{
  "tool": "gnokee_med_query",
  "input": {
    "tenant_id": "omur:tenant-xyz",
    "op": "active"
  }
}
```

## Token efficiency

The MCP response shape is the Q3-validated *compact natural-language
fact statements + lazy provenance handles*: median 125 tokens at
91.7% top-3 recall, vs Graphiti-raw 367 tokens at 50% recall.

For consumers that need the original episode body, follow the
two-step pattern:

1. `gnokee_recall` returns facts with `fact_uuid` handles.
2. Call `gnokee_fact_provenance(fact_uuid)` only for facts the LLM
   actually needs to ground in source text.

This keeps the recall response under budget for the common case
while preserving lossless provenance.

## Error handling

MCP errors surface as JSON-RPC errors with the gnokee error-class
name in the message:

- `ValidationError` — bad input (naive datetime, missing
  `tenant_id`, both/neither content/encrypted_body, invalid `op`,
  empty `analyte` where required).
- `EmbeddingsUnavailable` — TEI down on ingest / recall.
- `GraphStoreError` — Neo4j / Graphiti fault.
- `VectorStoreError` — Postgres fault.
- `LLMUnavailable` — contradiction degraded path on ingest.

The `gnokee_recall` and `gnokee_fact_provenance` tools never
auto-resolve contradictions — that's an architectural invariant
(`AGENTS.md` "do not" list), not a configuration choice.

## See also

- [`python.md`](python.md) — same logic, Python API.
- [`../../examples/03_mcp_clients/`](../../examples/03_mcp_clients/) — Claude Desktop, Claude Code, Cursor config snippets.
- [`../specs/v0.1.md`](../specs/v0.1.md) §6 — original tool spec.
- [`../adr/0009-clinical-labs-need-structured-store.md`](../adr/0009-clinical-labs-need-structured-store.md) — `gnokee_lab_query` rationale.
- [`../adr/0010-meds-share-lab-record-shape.md`](../adr/0010-meds-share-lab-record-shape.md) — `gnokee_med_query` rationale.
