# Python API reference

> Status: pre-1.0 — signatures may break across minor versions when
> gated by an ADR. The Pydantic shapes in
> [`src/gnokee/models.py`](../../src/gnokee/models.py) are the
> authoritative source; this doc is a curated tour.

The public surface is what `gnokee/__init__.py` re-exports:

```python
from gnokee import (
    # functions
    ingest_episode,
    recall,
    fact_provenance,
    run_deferred_extraction,
    # input shapes
    EpisodeIn,
    EncryptedBody,
    # output shapes
    IngestReceipt,
    RecallResponse,
    FactProvenance,
    FactStatement,
    ContradictionRef,
    EncryptedEpisodeBody,
    DeferredExtractionReport,
    ExtractionFailure,
    Sensitivity,  # type alias: Literal["public", "private", "clinical"]
)
```

`gnokee.lab_query.lab_query` and `gnokee.med_query.med_query` are
module-level coroutines for the typed clinical reads — covered in
their own sections below.

Everything is `async def`. Sync wrappers are not provided in v0.x.

## Boundary invariants

These are enforced at the Pydantic boundary and raise
`gnokee.errors.ValidationError`:

| Invariant | Rule |
|---|---|
| `tenant_id` mandatory | Empty string rejected. `"default"` is a valid single-user value, not a fallback. |
| `content` xor `encrypted_body` | Pass exactly one. Both = ambiguous. Neither = nothing to ingest. |
| Datetimes tz-aware UTC | Naive datetimes rejected. Use `datetime(..., tzinfo=timezone.utc)` or `datetime.now(timezone.utc)`. |
| `valid_at` is world-time | Time the fact was true in the world, not `datetime.now()`. Most common consumer bug. |
| `our_id` non-empty when set | Empty / whitespace-only rejected. |

## `gnokee.ingest_episode`

Store a fact / event / observation in bi-temporal memory.

```python
async def ingest_episode(
    *,
    pipeline: IngestPipeline,
    tenant_id: str,
    content: str | None = None,
    encrypted_body: EncryptedBody | None = None,
    valid_at: datetime,
    valid_until: datetime | None = None,
    asserted_at: datetime | None = None,
    our_id: str | None = None,
    corrects: UUID | None = None,
    entity_type_hints: list[str] | None = None,
    sensitive: Sensitivity = "private",
    language: str | None = None,
    extract: bool = True,
) -> IngestReceipt: ...
```

### Parameters

| Name | Required | Description |
|---|---|---|
| `pipeline` | yes | An `IngestPipeline` instance (see [`docs/specs/v0.1.md`](../specs/v0.1.md) §2 module table). One per process; wires GraphitiStore + PgVectorStore + MetadataStore + ContradictionStore + LLM + embedder. |
| `tenant_id` | yes | Tenant partition. Stored as `group_id` on every Graphiti node and edge; predicate on every Postgres row. |
| `content` | xor with `encrypted_body` | Plaintext episode body. UTF-8. |
| `encrypted_body` | xor with `content` | Pre-encrypted body — see [`EncryptedBody`](#encryptedbody) below. v0.4+. |
| `valid_at` | yes | World-time when the fact was true. tz-aware UTC. |
| `valid_until` | no | World-time end of validity. `None` = open-ended. |
| `asserted_at` | no | Source-tx-time when the consumer learned of the fact. Defaults to `datetime.now(UTC)` at the API boundary. |
| `our_id` | no | Consumer-supplied stable id. Idempotency key on `(tenant_id, our_id)` — re-ingest with the same key returns `replayed=True` and is a no-op. Strongly recommended. |
| `corrects` | no | UUID of a prior episode this one supersedes. Same-tenant only; corrected episode must exist; new `asserted_at` > corrected. Closes matching `lab_record` / `med_record` rows and sets `episode_metadata.asserted_until` + `superseded_by`. Caller-asserted only. |
| `entity_type_hints` | no | Advisory list passed to the Graphiti extractor. Not on the MCP surface in v0.1. |
| `sensitive` | no | `"public" \| "private" \| "clinical"`. Default `"private"`. Drives downstream gating. |
| `language` | no | ISO 639-1 (`"en"`, `"ru"`, `"bg"`, `"he"`, …). Auto-detected via `langdetect` when `None`. |
| `extract` | no | `True` (default) = full pipeline incl. Graphiti + contradictions. `False` = lite mode (Stages 4 + 7 skipped; p50 ≈ 200 ms). v0.3+. Force-disabled on the encrypted-body branch. |

### Returns

`IngestReceipt`:

```python
class IngestReceipt(BaseModel):
    episode_uuid: UUID
    asserted_at: datetime          # echoed resolved value
    created_fact_uuids: list[UUID] # uuids of EntityEdges produced; pass to fact_provenance
    contradicts: list[ContradictionRef]
    replayed: bool                 # True iff (tenant_id, our_id) idempotency hit
    extraction_deferred: bool      # True iff extract=False
```

When `replayed=True` or `extraction_deferred=True`, `created_fact_uuids` is empty.

### Raises

- `gnokee.errors.ValidationError` — bad input, naive datetime, missing `tenant_id`, both/neither of content/encrypted_body.
- `gnokee.errors.EmbeddingsUnavailable` — TEI down. No Graphiti write occurs.
- `gnokee.errors.GraphStoreError` — Graphiti / Neo4j fault.
- `gnokee.errors.VectorStoreError` — pg fault. Compensating `Graphiti.remove_episode` is issued.
- `gnokee.errors.LLMUnavailable` — contradiction detection degraded; ingest succeeds with `contradicts=[]`.

### Example — full ingest

```python
import asyncio
from datetime import datetime, timezone
import gnokee

async def main(pipeline):
    receipt = await gnokee.ingest_episode(
        pipeline=pipeline,
        tenant_id="omur:tenant-xyz",
        content="Started lisinopril 10mg PO daily for hypertension.",
        valid_at=datetime(2026, 5, 1, tzinfo=timezone.utc),
        our_id="omur:meds:lisinopril:start:2026-05-01",
        sensitive="clinical",
        language="en",
    )
    print(receipt.episode_uuid, receipt.created_fact_uuids)
    for c in receipt.contradicts:
        print("conflict:", c.verdict, c.summary)
```

### Example — lite mode

```python
receipt = await gnokee.ingest_episode(
    pipeline=pipeline,
    tenant_id="omur:tenant-xyz",
    content=rendered_episode_body,
    valid_at=window_start,
    our_id=f"pulse:{tenant}:{window_start.isoformat()}",
    extract=False,
)
assert receipt.extraction_deferred is True
assert receipt.created_fact_uuids == []
```

Backfill via `run_deferred_extraction()` later.

### Example — idempotent re-ingest

```python
# First ingest
r1 = await gnokee.ingest_episode(..., our_id="src:42")
# Replay
r2 = await gnokee.ingest_episode(..., our_id="src:42")
assert r2.replayed is True
assert r2.episode_uuid == r1.episode_uuid
```

## `gnokee.recall`

Retrieve facts from bi-temporal memory.

```python
async def recall(
    *,
    pipeline: RecallPipeline,
    tenant_id: str,
    text: str,
    as_of: datetime | None = None,
    valid_at: datetime | None = None,
    surface_contradictions: bool = True,
    max_tokens: int = 200,
    top_k: int = 10,
    top_k_bodies: int = 3,
    per_body_char_cap: int = 600,
) -> RecallResponse: ...
```

### Parameters

| Name | Description |
|---|---|
| `tenant_id` | Mandatory partition. |
| `text` | Natural-language query. |
| `as_of` | Source-tx-time pin: "what did the system know on this date?". `None` = `datetime.now(UTC)`. |
| `valid_at` | World-time pin: "facts true in the world on this date?". `None` = `datetime.now(UTC)`. |
| `surface_contradictions` | When `True`, populates `FactStatement.contradicts[]`. |
| `max_tokens` | Total response budget. Stage 6 splits across fact / excerpt / body lanes. |
| `top_k` | Candidate-pool size after pgvector cosine rerank. |
| `top_k_bodies` | v0.4+ — how many `episode_fallback` body rows to fetch when the body lane fires. |
| `per_body_char_cap` | v0.4+ — per-body character cap to bound the body lane's token cost. |

### Returns

`RecallResponse`:

```python
class RecallResponse(BaseModel):
    facts: list[FactStatement]                    # primary answer surface — Graphiti edge facts
    truncated: bool                               # True if max_tokens hit
    candidate_count: int                          # pre-rerank pool size
    excerpts: list[Excerpt]                       # currency / amount-keyword snippets
    supersession_hints: list[SupersessionHint]    # issue #19 — typed-read pivot hints
    episode_fallback: list[EpisodeFact]           # body lane (#41 hybrid + Path A empty-fact fallback)
    body_used: bool                               # True iff body lane fired
    retrieved_episode_external_ids: list[str]     # consumer our_ids for ranked visible episodes (#50)
    recall_telemetry: RecallTelemetry             # per-lane budget + emitted (#54)
    encrypted_bodies: list[EncryptedEpisodeBody]  # ciphertext envelopes for encrypted-body episodes
```

### Example

```python
from datetime import datetime, timezone
resp = await gnokee.recall(
    pipeline=pipeline,
    tenant_id="omur:tenant-xyz",
    text="What is the user's current blood pressure medication?",
    valid_at=datetime.now(timezone.utc),
)
for fact in resp.facts:
    print(fact.text, fact.fact_uuid)
    for c in fact.contradicts:
        print("  conflict:", c.verdict, c.summary)
if resp.body_used:
    for body in resp.episode_fallback:
        print("body:", body.text[:200])
for hint in resp.supersession_hints:
    print("hint:", hint.superseded_uuid, "->", hint.current_head_uuid)
```

## `gnokee.fact_provenance`

Fetch the original episode body behind a `fact_uuid`.

```python
async def fact_provenance(
    *,
    pipeline: RecallPipeline,
    tenant_id: str,
    fact_uuid: UUID,
) -> FactProvenance | None: ...
```

Returns `None` when no edge fact with that uuid exists for the tenant.

`FactProvenance` carries the full episode body and metadata. For
encrypted-body episodes, `episode_content` is `""` and
`encrypted_body` is populated; the consumer decrypts using their
KMS via `key_id`.

## `gnokee.history_of`

Return the supersession DAG for a single episode (issue #123). Walks
both directions from the anchor (predecessors + successors) and returns
a flat Cytoscape-style envelope filtered bi-temporally per ADR-0004.

```python
from gnokee.history import HistoryPipeline, history_of

async def history_of(
    *,
    tenant_id: str,
    episode_id: UUID,
    metadata: MetadataStore,
    encrypted_body: EncryptedBodyStore,
    mode: str = "compact",          # "compact" | "verbatim"
    as_of: datetime | None = None,  # default: now(UTC)
    valid_at: datetime | None = None,
    max_nodes: int = 32,
    max_tokens: int = 800,
    top_k_bodies: int = 3,
    per_body_char_cap: int = 600,
) -> HistoryResponse: ...
```

### Modes

- **`compact`** (default) — `HistoryNode` carries `episode_id`, `valid_at`,
  `asserted_at`, `superseded_by`, `status` (`active` | `superseded`), and
  `rationale` (from the successor's `EpisodeIn.corrects_reason`). No body.
  Fits in the MCP token budget; use for LLM-facing lineage audits.
- **`verbatim`** — same DAG; the newest `top_k_bodies` nodes additionally
  carry `episode_body` capped at `per_body_char_cap` chars. Older nodes
  stay compact. Use for human-facing drill-down.

### Encrypted bodies

When a node's episode was ingested via `encrypted_body`, the response
sets `body_encrypted=True`, leaves `episode_body=None`, and surfaces the
ciphertext envelope on `encrypted_body`. gnokee NEVER returns plaintext
for those episodes; the consumer decrypts via their KMS using `key_id`.

### Bi-temporal axes

- `as_of` pins transaction time. Filters every node by
  `asserted_at <= as_of`. "Show me the lineage as it was believed at T."
- `valid_at` pins world time. Filters by `valid_until > valid_at`
  (or `valid_until IS NULL`). Rarely narrows a DAG since most episodes
  describe a single world-moment; ship for ADR-0016 contract consistency.

### Truncation

`truncated=True` is set when either:
- the storage CTE hit `max_nodes` (oldest predecessors dropped first), or
- the token-budget guard kicked in (`max_tokens` exceeded, head + recent
  predecessors preserved).

`truncation_note` carries a human-readable explanation. Re-query with a
later root `episode_id` to walk earlier history.

### Cycle / depth

When the storage chain-walk exceeds `_CHAIN_DEPTH_LIMIT` (32), the
response returns `cycle_detected=True` with `nodes=[]` instead of raising.
By construction the supersession chain is acyclic (write-path
`MetadataStore.supersede` rejects axis-inversions); this is a defensive
envelope, not an expected path.

### Example

```python
import asyncio
from datetime import datetime, timezone
from uuid import UUID
from gnokee import history_of

async def main() -> None:
    resp = await history_of(
        tenant_id="alice",
        episode_id=UUID("11111111-..."),
        metadata=app.metadata_store,
        encrypted_body=app.encrypted_body_store,
        mode="compact",
        as_of=datetime(2024, 5, 1, tzinfo=timezone.utc),
    )
    print(f"DAG: {len(resp.nodes)} nodes, root={resp.root}, head={resp.head}")
    for node in resp.nodes:
        print(f"  {node.status} {node.episode_id} → {node.superseded_by}")
        if node.rationale:
            print(f"    reason: {node.rationale}")

asyncio.run(main())
```

## `gnokee.run_deferred_extraction`

Backfill Graphiti narrative extraction for lite-ingest episodes.

```python
async def run_deferred_extraction(
    tenant_id: str,
    *,
    pool: asyncpg.Pool,
    graph: GraphitiStore,
    metadata: MetadataStore,
    contradictions: ContradictionStore,
    llm: OpenAIClient | None = None,
    contradiction_enabled: bool = True,
    since: datetime | None = None,
    batch_size: int = 50,
    max_episodes: int | None = None,
) -> DeferredExtractionReport: ...
```

Walks `episode_metadata` rows where `extraction_deferred=TRUE`,
calls `graphiti.add_episode` for each (using the original
`valid_at`, never `now()`), and stamps `extraction_completed_at`
on success.

Failure isolation: one bad episode does not poison the batch.
`report.failed` carries per-episode errors; `extraction_deferred`
stays `True` so the next run retries.

RLS: sets `app.current_tenant` GUC on every acquired connection
before any SELECT or UPDATE.

```python
class DeferredExtractionReport:
    processed: int                    # episodes attempted
    succeeded: int
    failed: list[ExtractionFailure]   # each carries episode_uuid + error string
    elapsed_ms: int
```

### Example — nightly backfill

```python
import asyncio
from datetime import datetime, timezone, timedelta
import asyncpg
import gnokee

async def nightly_backfill():
    pool = await asyncpg.create_pool(dsn="postgresql://...")
    since = datetime.now(timezone.utc) - timedelta(days=1)
    report = await gnokee.run_deferred_extraction(
        tenant_id="omur:tenant-xyz",
        pool=pool, graph=graph, metadata=metadata,
        contradictions=contradictions, llm=llm,
        since=since, batch_size=100, max_episodes=500,
    )
    print(f"{report.succeeded}/{report.processed} ok in {report.elapsed_ms} ms")
    for f in report.failed:
        print(f"  FAILED {f.episode_uuid}: {f.error}")

asyncio.run(nightly_backfill())
```

Schedule via cron, pg_cron, Celery, APScheduler, Temporal,
modal.com — gnokee does not host a scheduler. See
[`integration_patterns.md`](../integration_patterns.md) §4.

## `gnokee.resume_ingest`

Opt-in replay for a journaled `begin` row that never received a matching
`commit` — typically a container kill or OOM between Stage 4 and Stage 5
(see [ADR-0024](../adr/0024-ingest-crash-recovery-journal.md) /
[#122](https://github.com/omurlabs/gnokee/issues/122)).

```python
async def resume_ingest(
    tenant_id: str,
    episode_uuid: UUID,
    episode: EpisodeIn,
    *,
    pipeline: IngestPipeline,
) -> IngestReceipt: ...
```

The consumer re-supplies the original `EpisodeIn`. gnokee never auto-replays
and never stores the payload itself — only a hash. On invocation:

1. Validates `episode.tenant_id == tenant_id` and a resumable `begin`
   row exists for `(tenant_id, episode_uuid)`.
2. Validates `SHA256(tenant_id ‖ our_id ‖ valid_at)` matches the
   journaled `payload_hash`. Drift → `IngestJournalError`, no store touch.
3. Re-executes Stage 4 (Neo4j `MERGE` on `uuid` is idempotent; pinned
   `stage_4_time` preserves `Episodic.created_at` per ADR-0004 axis-3).
4. Re-executes Stage 5 (`episode_metadata`, `content_embedding`,
   `content_text`, `episode_body_encrypted`, `lab_record`, `med_record`
   inserts all use `ON CONFLICT … DO NOTHING/UPDATE`; idempotent end-to-end).
5. Appends a `commit` row to the journal.

Stage 6 (Graphiti narrative enhancement) is **force-disabled** on resume —
use `gnokee.run_deferred_extraction` for that pass.

If resume itself fails: a new `fail` row is appended; the original
`begin` stays in place; the exception propagates.

### Raises

- `ValidationError` — empty `tenant_id`.
- `IngestJournalError` — `tenant_id`/`episode.tenant_id` mismatch; no
  resumable row for the given `(tenant_id, episode_uuid)`; payload-hash
  drift.
- Whatever Stage 4 / Stage 5 themselves raise on the retry (same
  surface as `ingest_episode`).

### Surfacing resumable rows

`IngestPipeline` logs a `ResumableIngest` warning on the **first**
`ingest_episode` call per tenant per process for every `begin` row
without a matching `commit`. Operators can also call the journal
directly:

```python
resumables = await app.ingest.journal.scan_resumable(tenant_id="t-abc")
for entry in resumables:
    print(entry.episode_uuid, entry.our_id, entry.stage_4_time)
```

### Example — operator-driven recovery

```python
import asyncio
import gnokee

async def recover(app, tenant_id, original_episode):
    resumables = await app.ingest.journal.scan_resumable(tenant_id)
    for entry in resumables:
        if entry.our_id != original_episode.our_id:
            continue
        receipt = await gnokee.resume_ingest(
            tenant_id, entry.episode_uuid, original_episode,
            pipeline=app.ingest,
        )
        print(f"resumed {receipt.episode_uuid}")
```

Q19 spike measured the journal's per-call overhead at 2.17% median
regression on `extract=False` ingests (~2 ms on top of a ~100 ms
lite-mode call) — well under ADR-0024's 10% threshold. The cost is two
Postgres inserts (`begin` + `commit`) per ingest, plus one
`scan_resumable` SELECT per tenant per process.

## `gnokee.lab_query.lab_query`

Typed clinical-lab reads over the `lab_record` table.

```python
LabOp = Literal["latest", "history", "min", "max", "avg", "count", "abnormal"]

async def lab_query(
    *,
    pipeline: LabQueryPipeline,
    tenant_id: str,
    analyte: str | None,
    op: LabOp,
    since: datetime | None = None,
    until: datetime | None = None,
    as_of: datetime | None = None,
    valid_at: datetime | None = None,
    limit: int = 50,         # max 500
) -> LabQueryResponse: ...
```

`analyte` is required for every op except `"abnormal"`.

### Returns

```python
@dataclass(frozen=True)
class LabRowOut:
    episode_uuid: UUID
    analyte: str
    value_numeric: Decimal | None
    value_text: str | None
    unit: str | None
    ref_range_low: Decimal | None
    ref_range_high: Decimal | None
    abnormal_flag: str | None       # "L" | "H" | "C" | None
    valid_at: datetime
    asserted_at: datetime

@dataclass(frozen=True)
class LabQueryResponse:
    op: LabOp
    rows: list[LabRowOut]
    scalar: Decimal | None    # populated for min/max/avg/count
    count: int
```

`min` / `max` / `avg` / `count` skip rows with `value_numeric IS NULL`.

### Example

```python
from gnokee.lab_query import lab_query

resp = await lab_query(
    pipeline=lab_pipeline,
    tenant_id="omur:tenant-xyz",
    analyte="LDL",
    op="latest",
)
if resp.rows:
    row = resp.rows[0]
    print(f"LDL {row.value_numeric} {row.unit} (flag={row.abnormal_flag})")
```

See [ADR-0009](../adr/0009-clinical-labs-need-structured-store.md)
for the schema rationale.

## `gnokee.med_query.med_query`

Typed medication-history reads over the `med_record` table.

```python
MedOp = Literal["active", "history", "allergies", "switches"]

async def med_query(
    *,
    pipeline: MedQueryPipeline,
    tenant_id: str,
    op: MedOp,
    drug_name: str | None = None,
    since: datetime | None = None,
    until: datetime | None = None,
    as_of: datetime | None = None,
    valid_at: datetime | None = None,
    limit: int = 50,         # max 500
) -> MedQueryResponse: ...
```

`drug_name` is required for `op="history"`.

### Returns

```python
@dataclass(frozen=True)
class MedRowOut:
    episode_uuid: UUID
    drug_name: str
    drug_class: str | None
    dose_value: Decimal | None
    dose_unit: str | None
    frequency: str | None
    route: str | None
    event_kind: str        # "start" | "increase" | "decrease" | "stop" | "switch" | "allergy" | ...
    reason: str | None
    valid_at: datetime
    asserted_at: datetime

@dataclass(frozen=True)
class MedQueryResponse:
    op: MedOp
    rows: list[MedRowOut]
    count: int
```

`op="active"` returns the per-drug latest visible event with
`event_kind NOT IN ('stop', 'allergy')` (`DISTINCT ON (drug_name)`).

### Example

```python
from gnokee.med_query import med_query

resp = await med_query(
    pipeline=med_pipeline,
    tenant_id="omur:tenant-xyz",
    op="active",
)
for row in resp.rows:
    print(f"{row.drug_name} {row.dose_value} {row.dose_unit} {row.frequency}")
```

See [ADR-0010](../adr/0010-meds-share-lab-record-shape.md) for the
schema rationale.

## Pydantic shapes

### `EncryptedBody`

Pre-encrypted episode body. Consumer-side encryption with a DEK
the consumer owns; gnokee never decrypts.

```python
class EncryptedBody(BaseModel):
    ciphertext: bytes
    nonce: bytes
    key_id: str                              # references DEK in consumer KMS
    content_for_embedding: str | None = None # optional embed-only window
```

When `content_for_embedding` is set, gnokee runs the plaintext
through the embedder and stores ONLY the 1024-dim
`content_embedding` row — the plaintext bytes are dropped after
`embed()` returns and never persisted. When `None`, the episode is
absent from the semantic-recall lane.

### `EncryptedEpisodeBody`

Recall-side ciphertext envelope.

```python
class EncryptedEpisodeBody(BaseModel):
    episode_uuid: UUID
    ciphertext: bytes
    nonce: bytes
    key_id: str
```

Returned in `RecallResponse.encrypted_bodies` and
`FactProvenance.encrypted_body` for episodes ingested via the
encrypted-body branch.

### `ContradictionRef`

```python
class ContradictionRef(BaseModel):
    fact_uuid: UUID                                       # the OTHER side
    verdict: Literal["refinement", "update", "contradiction"]
    summary: str                                          # 1-line snapshot
    valid_at: datetime                                    # world-time of the OTHER fact
```

The consuming LLM uses `valid_at` to apply a "more-recent-wins"
heuristic without a `gnokee_fact_provenance` round-trip. gnokee
itself never picks a winner.

### `RecallTelemetry`

Per-lane budget vs emitted accounting (issue #54).

```python
class RecallTelemetry(BaseModel):
    budget_max_tokens: int
    fact_budget: int
    excerpt_budget: int
    body_budget: int
    fact_tokens_emitted: int
    excerpt_tokens_emitted: int
    body_tokens_emitted: int
    fact_count: int
    excerpt_count: int
    body_count: int
    body_first_row_oversize: bool
```

Useful for eval harnesses that want to record actual budget usage
per call instead of inferring from row counts.

### `SupersessionHint`

```python
class SupersessionHint(BaseModel):
    superseded_uuid: UUID
    current_head_uuid: UUID
    superseded_at: datetime
```

Surfaced when an episode is cosine-relevant but hidden by
supersession at the caller's `as_of`. Lets the agent pivot to
typed reads (`gnokee_lab_query` / `gnokee_med_query`) or
re-pin `as_of` pre-correction.

## Errors

```python
class GnokeeError(Exception): ...
class ValidationError(GnokeeError): ...     # boundary input bad
class EmbeddingsUnavailable(GnokeeError): ...
class GraphStoreError(GnokeeError): ...
class VectorStoreError(GnokeeError): ...
class LLMUnavailable(GnokeeError): ...      # contradiction degraded
class NotImplementedYet(GnokeeError): ...
```

All defined in `gnokee.errors`. Catch `GnokeeError` for any
gnokee-originating failure.

## Stability

| Surface | Stability (pre-1.0) |
|---|---|
| Function names + import paths in `gnokee/__init__.py` | stable; renames go through deprecation if at all |
| Required parameters | stable |
| Optional parameters | additive only — new ones may appear; existing ones don't disappear |
| Return shape — fields | additive — new fields may appear; existing fields don't disappear |
| Return shape — types | stable |
| Error class hierarchy | stable; new subclasses may appear |
| Internal `pipeline.*` shapes (`IngestPipeline`, `RecallPipeline`, etc.) | unstable; treat as private |

The MCP tool surface (see [`mcp.md`](mcp.md)) follows the same
stability model.

## See also

- [`mcp.md`](mcp.md) — MCP tool reference (same logic, JSON wire format).
- [`../specs/v0.1.md`](../specs/v0.1.md) — implementation spec for ingest + recall + contradiction.
- [`../specs/v0.2.md`](../specs/v0.2.md) — typed clinical reads delta.
- [`../integration_patterns.md`](../integration_patterns.md) — lite vs full mode decision contract.
- [`../integration/consumer-patterns.md`](../integration/consumer-patterns.md) — body-render recipes for typed parsers.
- [`../extending.md`](../extending.md) — write your own adapter; swap embedder / LLM.
- [`../../examples/`](../../examples/) — runnable code.
