# Spike Q14 — Obsidian vault-as-source ingest parity

> Addresses the pre-promotion gate question for `examples/06_obsidian_vault_ingest.py`
> and `docs/evals/methodology.md` target dimension: **adapter fidelity** —
> does a storage-layer indirection preserve retrieval quality?

## Goal

Before promoting the Obsidian adapter (`examples/06_obsidian_vault_ingest.py`)
to a `consumers/gnokee-obsidian/` package, verify that ingesting content via
`.md` frontmatter + body produces **identical recall ranking quality** to
equivalent direct `gnokee.ingest_episode(...)` calls.

Two concrete failure modes drive the experiment:

1. **Frontmatter axis assignment** — does the adapter set `valid_at` /
   `asserted_at` correctly so bi-temporal queries (`as_of`, supersession)
   behave identically to a direct ingest with the same datetimes?
2. **Body fidelity + tags→hints effect** — does markdown prose parsed through
   the adapter produce the same Graphiti edge facts and cosine-recall top-K
   as the direct path? Does `entity_type_hints` (from frontmatter `tags:`)
   measurably shift rankings?

The harness runs **two arms back-to-back** under distinct `group_id`s:

- **A-arm** (`q14_obsidian_a_direct`): loads `corpus/episodes.jsonl` →
  calls `gnokee.ingest_episode(...)` directly.
- **B-arm** (`q14_obsidian_b_vault`): walks `corpus/vault/*.md` via the
  adapter's `_build_episode` + ingest path.

Both arms share identical ground-truth labels.

## Decision criterion

| Condition | Verdict | Action |
|---|---|---|
| A-arm and B-arm recall scores within 1 rank-correction on ≥ 9/10 queries **AND** no axis-confusion case | **SHIP_ADAPTER** | Promote adapter to `consumers/gnokee-obsidian/`. |
| Recall parity fine, but a specific frontmatter field (e.g. `tags→hints`) measurably hurts ≥ 1 query | **PATCH_ADAPTER** | Fix the named field; re-run. |
| ≥ 2 queries diverge by > 1 rank-correction, **OR** any axis-confusion fires | **REWORK_ADAPTER** | Block promotion; open backlog issue with details. |

**Definitions:**

- *Rank-correction*: a query where `pass` in one arm becomes `partial` or
  `fail` in the other (or vice-versa). Ties (`pass`/`pass` or `fail`/`fail`)
  are not divergences even if the returned ID lists differ.
- *Axis-confusion*: a query with an `as_of` constraint where the B-arm returns
  a fact the A-arm correctly hides (or vice-versa) at the same `as_of`.

Decision is computed by the harness from graded results — never hardcoded.

## Methodology

### Corpus

12 episodes covering a personal-knowledge slice:

- 4 people notes (names, roles, last-contact)
- 3 place / preference notes
- 2 clinical-style notes (one supersession pair — the second `corrects:` the first)
- 2 project notes
- 1 tag-heavy note (to probe `entity_type_hints` bias)

Each episode has a parallel representation:

| Artifact | Format | Ingest path |
|---|---|---|
| `corpus/episodes.jsonl` | JSON, one object per line | A-arm: `ingest_episode(EpisodeIn(...))` |
| `corpus/vault/<id>.md` | Obsidian-style `.md` with frontmatter | B-arm: adapter `_build_episode` → `ingest_episode` |

Both representations share the same `our_id`, `valid_at`, `asserted_at`,
`content`, `corrects` UUID, `sensitive`, `language`, `tags`/`entity_type_hints`.

### Probe set

10 queries in `queries.yaml`:

- 1 `as_of` query (valid-time filter — axis assignment check)
- 1 supersession query (must hit the `corrects:` link from the B-arm note)
- 1 tag/hint query (probes `entity_type_hints` ranking bias)
- 7 plain semantic recalls across people, places, preferences, projects

### Scoring

For each query, each arm independently produces a `pass | partial | fail | error` verdict
using the same grading rule as Q1: `pass` iff all expected `our_id`s appear in the
top-K returned set (K=10 by default; overridable via `GNOKEE_SPIKE_SEARCH_LIMIT`).

A-vs-B comparison computes:

- Per-query *divergence flag*: verdict differs between arms.
- *Axis-confusion flag*: `as_of`-gated query where one arm returns a superseded
  episode the other correctly hides.
- Summary counts → `decision` ∈ `{SHIP_ADAPTER, PATCH_ADAPTER, REWORK_ADAPTER, INVALID_CONTROLS_FAILED}`.

### Sanity controls

Two control queries with trivially distinct content are ingested into both arms.
If both arms fail the same control, the harness emits `INVALID_CONTROLS_FAILED`
and the cross-arm results are discarded — the Graphiti/stack setup is broken.

## What this does NOT cover

- **Markdown→plaintext conversion quality.** Bodies go in as-is; this spike
  does not test a pre-processing stripper. A consumer running `mdformat` or
  `markdown-it-py` before ingestion would change body text — that is a
  different spike.
- **Wikilink-graph resolution.** `[[Note]]` wikilinks are NOT resolved to
  entities here. Graphiti discovers entities from prose; this spike does not
  test vault-structure-aware entity linking.
- **Encrypted-vault path.** `encrypted_body=EncryptedBody(...)` branch is
  exercised in Q4+; out of scope here.
- **`--watch` / live-sync mode.** mtime sidecar gating is not evaluated;
  the sidecar file is cleared between arms.
- **Heading-split mode.** One Episode per `## section` is a TODO in the
  adapter; this spike uses whole-note episodes only.
- **Performance / throughput.** Q9 covers wearable throughput; Q14 is
  fidelity-only.

## Cost & time

| Component | Calls | Est. tokens | Backend (default) |
|---|---|---|---|
| Ingest — A-arm (12 episodes) | 12 × `ingest_episode` | ~600 in + ~300 out per ep | Ollama / OpenAI |
| Ingest — B-arm (12 notes) | 12 × adapter + `ingest_episode` | same as A | same |
| Query — 10 probes × 2 arms | 20 × `recall` | ~200 in + ~100 out per call | same |
| **Total** | ~44 LLM calls | ~24 k tokens | |

With OpenAI `gpt-4o-mini`: ~$0.05. Wall time ~3–6 min.
With Ollama local (`llama3.1:8b`): ~20–35 min, $0.

## Run

```bash
# From repo root:
docker compose up -d neo4j postgres

cd evals/spike_q14_obsidian
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp ../../.env.example ../../.env   # edit GNOKEE_* vars

# Full run (ingest both arms + queries):
python run.py

# Skip ingest (re-run queries against already-loaded stack):
GNOKEE_SPIKE_SKIP_INGEST=1 python run.py

# Override search limit:
GNOKEE_SPIKE_SEARCH_LIMIT=5 python run.py
```

Output:

- Console: per-query A/B verdicts + summary counts + `decision`
- JSON dump: `results/<UTC-stamp>.json` with `summary` + per-query A-vs-B details
