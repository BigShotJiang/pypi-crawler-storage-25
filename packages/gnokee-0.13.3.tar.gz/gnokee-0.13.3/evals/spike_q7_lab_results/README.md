# Spike Q7 — Lab-result bi-temporal fit on the gnokee v0.1.1 stack

> Validates the open promise from `evals/spike_q1_graphiti/` ADR-0001:
> *"Graphiti's bi-temporal node + edge model handles the query patterns
> gnokee promises, against representative episodes from both target
> consumers (Omur health-AI SaaS + personal-AI agents)."*
>
> Q1 only exercised personal-AI / engineering notes. Q7 exercises the
> Omur clinical-labs shape that ADR-0001 promised but never validated.

## Goal

Determine whether gnokee v0.1.1 (preprocessor + recall + excerpts)
can answer the query patterns Omur needs over a synthetic clinical-lab
corpus that mirrors a real outpatient longitudinal panel set:

- 9 lab panels over 12 months
- 1 lab correction (later `asserted_at`, same `valid_at`) — exercises
  ADR-0004 supersession axis
- realistic analytes (BMP / CBC) with reference ranges and units
- one cross-domain link (a panel mentions an active medication —
  furosemide — to test "med-explains-lab" reasoning)

## Decision criterion

| % of expected query patterns that pass | Outcome |
|---|---|
| ≥ 80 % | **Adopt for clinical labs** (amend ADR-0001 + new ADR-0009) |
| 50 % – 80 % | **Adopt with documented gap-fillers** (likely a structured `lab_record` table siblings to `content_embedding`) |
| < 50 % | **Off-ramp** clinical labs to a structured store; gnokee owns summaries / anomalies only |

A query "passes" when **all expected episode IDs** appear in the
returned recall set **and** the returned response (facts + excerpts)
contains the value the query targets, not just the panel reference.
Partial overlap = `partial` (counts as fail for the headline).

## Methodology

1. Boot the v0.1.1 compose stack (`make up && make migrate`).
2. `python run.py` walks `corpus.jsonl`, runs `gnokee.ingest_episode`
   for each (preprocessor active; `tenant_id = "spike-q7"`).
3. For each query in `queries.yaml`, invoke `gnokee.recall` with the
   declared `as_of` / `valid_at`, and grade the response.
4. Emit `results/<utc-stamp>.json` with per-query verdicts.

The harness uses **gnokee's** recall pipeline (not `graphiti.search`)
because the question is whether the v0.1.1 stack as shipped fits
labs — including the preprocessor, excerpts, and contradiction surface.

## What this does NOT cover

- **PHI / encryption**. The `EncryptedBody` path remains stubbed; this
  spike uses plaintext synthetic data. Encryption is ADR-0010 territory.
- **Wearable throughput**. Time-series at sample-per-minute rates is
  Q9, not Q7.
- **Aggregations** (e.g. `AVG(K+)`, `MIN(creatinine) over 90d`). These
  are deliberately graded as `fail` if they require client-side math
  outside `gnokee.recall` — that result informs whether a structured
  lab table is needed.
- **Med supersession**. Dose-change shapes are Q8.

## Cost & time

- **Ingest**: 10 episodes × graphiti `add_episode` (≈ 1 LLM call + ~5
  embedding calls each) ≈ $0.10–$0.20 with `gpt-4o-mini`.
- **Recall**: 15 queries × stage 1 embedding ≈ negligible.
- **Wall clock**: ~3–5 min ingest, ~30 s recall, ~5 min total.

## Run

```bash
cd evals/spike_q7_lab_results
docker compose --project-directory ../.. up -d gnokee-postgres gnokee-neo4j gnokee-tei
set -a && source ../../.env && set +a
../../.venv/bin/python run.py
```

Re-run with `GNOKEE_SPIKE_SKIP_INGEST=1` to grade against the
already-ingested corpus without paying the LLM cost again:

```bash
GNOKEE_SPIKE_SKIP_INGEST=1 ../../.venv/bin/python run.py
```
