# evals/baselines/

Pinned per-spike baselines for the v0.3 eval-delta gate.

See [`docs/eval_delta_gate.md`](../../docs/eval_delta_gate.md) §3 for the
JSON shape and `evals/_eval_delta.py` for the helper module that reads
+ writes these files.

## v0.13.0 scaffolding state

Every baseline in this directory currently carries
`"_scaffolding": true`. The helper module detects the sentinel and
exits `0` with a `SKIPPING` status — the gate is wired but not yet
load-bearing. The sentinel disappears the first time a maintainer
runs `--capture-baseline` against the spike at a known-good commit:

```bash
# Maintainer gesture, NOT a developer gesture. Requires Postgres /
# Neo4j / TEI up at a known-good state matching the target tag.
.venv/bin/python evals/spike_q1_graphiti/run.py --capture-baseline
```

Once captured, the gate becomes load-bearing — PRs that touch
`src/gnokee/retrieval.py`, `src/gnokee/ingest.py`,
`src/gnokee/extract/**`, `src/gnokee/contradiction/**` (and the
scaffolding itself) fail CI on regression per §2 of the doc.

## Re-pinning

See `docs/eval_delta_gate.md` §8. A re-pin is documented in the PR
description that lands it; reviewers should never be surprised by a
silent baseline shift.
