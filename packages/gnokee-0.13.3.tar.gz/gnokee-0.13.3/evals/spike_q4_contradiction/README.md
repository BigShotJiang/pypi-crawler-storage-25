# Spike Q4 — Contradiction-handling smoke test

## Goal

Validate the LLM-classifier step from `docs/architecture.md`:

> When a new episode produces fact F, gnokee searches for high-similarity
> existing facts within the same entity context, asks an LLM whether
> each candidate is `unrelated | refinement | update | contradiction`,
> and stores the verdict as a graph edge.

The architecture promises four-way classification of fact pairs. This
spike measures whether `gpt-4o-mini` (the cheap default) reliably
returns the right verdict on labeled pairs from the Q1 corpus.

## Decision criterion

**Classification accuracy ≥80% on the labeled set.**

If `gpt-4o-mini` clears the bar, v0.1 ships with it as the default
contradiction classifier; if not, the consumer must supply a stronger
model (or gnokee falls back to a heavier default).

## Labeled pair set

10 pairs from the Q1 corpus, hand-labeled per the four classes:

| Pair | A | B | Label | Why |
|---|---|---|---|---|
| 1 | e_005 (K+ 3.1, original) | e_006 (K+ 3.6, amendment) | **update** | Lab amendment — same fact, corrected value |
| 2 | e_009 (CMF HR spike) | e_010 (Fitbit HR spike) | **refinement** | Two sources, same event, slight reading variance |
| 3 | e_009 (CMF HR spike) | e_020 (sensor-anomaly reclass) | **contradiction** | Real spike vs sensor noise — incompatible |
| 4 | e_010 (Fitbit HR spike) | e_020 (sensor-anomaly reclass) | **contradiction** | Same as 3, other source |
| 5 | e_001 (Postgres) | e_002 (MongoDB migration) | **update** | World changed — Postgres superseded by MongoDB |
| 6 | e_007 (metoprolol started) | e_008 (metoprolol stopped, bisoprolol started) | **update** | Medication change — same regimen evolving |
| 7 | e_011 (RU: I work at TechCorp) | e_012 (EN: left TechCorp, joined startup) | **update** | Stale belief vs current — also cross-language |
| 8 | e_015 (Helix preference) | e_016 (switched back to Neovim) | **update** | Preference change |
| 9 | e_003 (CachyOS build) | e_005 (K+ lab) | **unrelated** | No semantic overlap — devops vs clinical |
| 10 | e_015 (Helix editor) | e_002 (MongoDB migration) | **unrelated** | No semantic overlap — editor vs database |

7 update / refinement / contradiction labels + 2 unrelated controls + 1 contradiction (pair 4) = 10 total.

## Methodology

For each pair:

1. Take both episode contents verbatim.
2. Prompt `gpt-4o-mini` with a fixed instruction:
   > Classify the relationship between fact A and fact B. Output one
   > word: `unrelated`, `refinement`, `update`, or `contradiction`.
   > - **unrelated**: different topics
   > - **refinement**: same fact, more detail
   > - **update**: world-state changed; A was true, then B
   > - **contradiction**: A and B claim incompatible truths about the
   >   same point in time
3. Parse the response, compare to the label.

## Output

`results/<UTC-timestamp>.json` with per-pair model verdict + correctness
flag, and a summary block: total / correct / accuracy / decision.

## Cost & time

10 LLM calls × `gpt-4o-mini` ≈ $0.005 / run, ~30 seconds wall.
