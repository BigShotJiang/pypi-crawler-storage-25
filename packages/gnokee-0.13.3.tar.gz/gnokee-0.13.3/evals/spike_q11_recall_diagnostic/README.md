# Spike Q11 — Recall Ranking-Surface Diagnostic

> Closes the recall-gap investigation gate from `docs/adr/0012-cross-tool-eval-verdict.md`
> § Diagnosis (Q11). Issue #42.

## Goal

Stage A of Q10 shows gnokee recall@5 = 50 % (2/4 gold-bearing questions) vs
graphiti-alone 87.5 % (3.5/4) on the same 10-question × 10-session
LongMemEval-S haystack. Both systems share the same Neo4j cluster and bge-m3
embedder; the gap is a ranking-surface difference, not an ingest difference.

This spike instruments each retrieval primitive that differs between the two
paths and, for each Stage A miss where gnokee failed but graphiti-alone
succeeded, dumps:

1. gnokee stage 2a Cypher candidate list (with `valid_at` per candidate)
2. gnokee stage 3 pgvector cosine top-K + scores
3. graphiti-alone hybrid edge top-K + composite scores
4. Which primitive surfaces the gold session in graphiti-alone but ranks it
   outside top-K in gnokee

This answers the design question in ADR-0012: is the recall gap caused by
(a) pure cosine over episode bodies being weaker than hybrid RRF over edge
facts, (b) stage 2a over-filtering, (c) DEFAULT_CANDIDATE_POOL being too
narrow, or (d) per-episode content_embedding dilution?

## Decision criterion

The spike does not produce an ADOPT/REJECT verdict — it produces a ranked
diagnosis. Outputs are measured per hypothesis:

| Hypothesis | Measured as | Evidence threshold |
|---|---|---|
| H1 — Hybrid > pure cosine | graphiti edge RRF rank of gold episode vs gnokee cosine rank | gold in graphiti top-K but outside gnokee top-K on same question |
| H2 — valid_at over-filter | candidate count with `valid_at = far_future` vs default | candidate count changes |
| H3 — pool too narrow | candidate count vs haystack size | pool < haystack at any question |
| H4 — embedding dilution | gold episode cosine score vs non-gold episode cosine scores | gold score below top-K threshold |

Recommendation thresholds:

| Finding | Recommendation |
|---|---|
| H1 confirmed (gold missing from gnokee top-K, present in graphiti top-K) | MEDIUM — add BM25 sibling query alongside pgvector cosine |
| H2 confirmed (candidate count changes with far_future pin) | CHEAP — config knob on valid_at default |
| H3 confirmed (pool < haystack) | CHEAP — raise DEFAULT_CANDIDATE_POOL |
| H4 confirmed (gold scores below non-gold) | EXPENSIVE — sub-episode chunking |

## Methodology

Reads the Q10 Stage A result JSON (`results/stageA_pathA_*.json` or rebuilds
from the two-miss question IDs embedded in `queries.yaml`). For each miss
question, this spike:

1. Reproduces gnokee's stage 2a candidate query directly against Neo4j using
   the tenant_id from the Q10 run — reads `valid_at` per candidate.
2. Runs pgvector cosine for the same query embedding over the candidate set,
   returning scores alongside the ranked uuids.
3. Runs graphiti `search_()` with `COMBINED_HYBRID_SEARCH_RRF` for the same
   query + group_id + returns the edge set + mapped episode external_ids.
4. For the gold external_id of each miss, checks: (a) is it in the stage 2a
   candidate set? (b) what was its cosine score? (c) what was its composite
   rank in graphiti RRF?
5. Emits a per-probe diagnostic row and a summary ranking the hypotheses.

The spike is read-only against the live gnokee + Neo4j + Postgres stack used
by Q10. It does NOT re-ingest — uses existing tenant data via
`GNOKEE_SPIKE_Q11_TENANT_PREFIX` (must match Q10's `run_id`).

### Corpus

Two-miss questions from Q10 Stage A re-run (`stageA_pathA`):
- `q_single_session_user` type questions where `gnokee.any_hit = False` and
  `graphiti-alone.any_hit = True`.

Questions are encoded in `queries.yaml` with the tenant_id from the Q10 run
so the spike can reconnect to existing ingested data.

### Scoring rules

- `stage_2a_found`: bool — gold episode_uuid in stage 2a candidate list
- `cosine_score`: float — gold episode's cosine distance (lower = closer);
  `None` if gold not in candidate set
- `cosine_rank`: int — gold episode's rank in pgvector top-K; `None` if outside
- `graphiti_edge_rank`: int — rank of first edge whose `episodes` contains gold;
  `None` if no edge links to gold
- `graphiti_episode_rank`: int — rank in MENTIONS backwalk; `None` if not found

### What this does NOT exercise

- Re-ingest. All data comes from the Q10 Stage A run; this spike never calls
  `ingest_episode`.
- Stage C (full haystack, 100 Q). Pool-size hypothesis H3 can only be
  confirmed at Stage C scale — H3 assessment here is theoretical (pool vs
  haystack count).
- Sub-episode chunking (H4 fix). Out of scope — that is a v0.4 design
  decision.
- Accuracy / literal-stripping. This spike measures recall only (is the gold
  episode retrieved?), not whether facts contain the literal answer.
- Any fix implementation. The spike is read-only on `src/gnokee/`.

## Cost & time

- **LLM calls**: 0 — no extraction or judge. Pure retrieval instrumentation.
- **Embed calls**: 2 × n_miss_questions via gnokee's TEI (bge-m3, 1024-dim),
  one embed per question.
- **Graphiti search calls**: n_miss_questions × `COMBINED_HYBRID_SEARCH_RRF`
  (1 search per question, each internally fires 1 BM25 + 1 cosine + 1 reranker
  → ~3 LLM-side calls via OpenAI reranker).
- **Wall time**: < 2 min for 2-question subset from Q10 Stage A misses.
- **$ estimate**: < $0.05 (reranker cross-encoder on 2 queries × ~10 candidates).

## Run

```bash
cd evals/spike_q11_recall_diagnostic
set -a && source ../../.env && set +a

# Dry-run mode (prints diagnostic only, no live network):
GNOKEE_SPIKE_Q11_DRY_RUN=1 ../../.venv/bin/python run.py

# Live mode (needs running Postgres + Neo4j with Q10 data):
GNOKEE_SPIKE_Q11_TENANT_PREFIX=stageA_pathA ../../.venv/bin/python run.py

# Override search limit:
GNOKEE_SPIKE_SEARCH_LIMIT=20 ../../.venv/bin/python run.py
```
