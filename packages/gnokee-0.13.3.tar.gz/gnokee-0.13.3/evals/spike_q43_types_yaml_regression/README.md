# Q43 — Types-YAML regression: per-tenant extraction prompt A/B

> **Status**: scaffold only — ADR-0017 amendment deferred pending Q43 numbers.
> Invoke manually: `python evals/spike_q43_types_yaml_regression/run.py --arm=per_tenant_yaml`

---

## 1. Goal

Measure whether per-tenant `gnokee.types.yaml` rendered into Graphiti's
extraction system prompt at ingest time regresses entity deduplication within a
single tenant on a corpus exercising the tenant's full type vocabulary, vs the
current static `GNOKEE_GRAPHITI_EXTRACTION_INSTRUCTIONS` baseline.

The design question this answers (`docs/adr/0017-types-yaml.md`, issue #78):

> Does injecting per-tenant type vocabulary into `custom_extraction_instructions`
> on every `add_episode` call (a) preserve within-tenant entity-dedup quality
> relative to the static-instruction baseline, and (b) stay within a 2×
> extraction-prompt token budget relative to the current static instruction?

Related: ADR-0017 (`docs/adr/0017-types-yaml.md`), issue #307, issue #78.

---

## 2. Decision criterion

| Score class | Headline | Action |
|---|---|---|
| within-tenant dedup F1 within ±5pp of baseline **AND** extraction prompt p95 token count grows ≤1.5× **AND** total LLM spend ≤2× of baseline | Type-YAML injection safe for ADR-0017 | **ADOPT** — promote ADR-0017 to Accepted |
| F1 within ±5pp **BUT** token p95 ratio > 1.5× or cost ratio > 2× | Quality OK, budget exceeded | **ADOPT_WITH_GAPS** — ADR-0017 Accepted with token-budget caveat; open follow-up to trim instruction template |
| F1 drops > 5pp vs static baseline | Type injection degrades extraction | **REJECT** — rework extraction prompt template |

Exact thresholds (constants block in `run.py`):

- `F1_PARITY_THRESHOLD_PP = 5.0` — max F1 drop (percentage points) from static → per_tenant_yaml arm
- `TOKEN_P95_RATIO_THRESHOLD = 1.5` — `per_tenant_yaml` extraction prompt p95 token count ÷ `static_instruction` p95; >1.5× → ADOPT_WITH_GAPS if F1 OK
- `COST_RATIO_THRESHOLD = 2.0` — total estimated USD cost ratio; >2× → ADOPT_WITH_GAPS if F1 OK
- `N_RUNS = 3` — runs per arm; median F1 reported

The `decision` field in output JSON is computed from data; it is never hardcoded
in the harness.

---

## 3. Methodology

### Corpus shape

One tenant, 30 synthetic EHR episodes:

| Tenant | `tenant_id` | `group_id` | Episodes | Type vocabulary |
|---|---|---|---|---|
| Fixture tenant | `q43-fixture-tenant` | `q43-fixture-tenant` | 30 | `lab_result`, `clinician`, `specimen`, `facility` |

`group_id = tenant_id` per gnokee production invariant (`src/gnokee/storage/graph.py:200`).
The corpus covers diverse lab-result types (electrolytes, metabolic panels, coagulation,
immunology, pathology) from four recurring clinicians across three facility names.

### Probe set

`queries.yaml` contains 10 queries exercising the tenant's type vocabulary:

- 5 original within-tenant recall queries
- 5 additional single-tenant probes targeting underexercised entity types (clinician × facility
  co-occurrence, specimen-type recall, domain-narrow thyroid + immunology queries)

### Arms

**arm_A — `static_instruction`** (current behavior):
`GNOKEE_GRAPHITI_EXTRACTION_INSTRUCTIONS` env var (or its default empty string)
passed as `custom_extraction_instructions` to every `add_episode` call.

**arm_B — `per_tenant_yaml`**:
`types.yaml` is loaded for the tenant, rendered to a `custom_extraction_instructions`
string listing entity and relationship types, and injected via
`add_episode(..., custom_extraction_instructions=<rendered>)`.

**Wiring decision — per-call, not per-startup.**
`custom_extraction_instructions` is a parameter on `add_episode` in
`graphiti-core>=0.29`, not a field on `LLMConfig`. The harness uses one shared
`Graphiti` client and dispatches per-episode with the per-tenant instruction
string. This matches gnokee's production `IngestPipeline` wiring confirmed in
`src/gnokee/storage/graph.py:198`.

### Gold dedup labels

Each episode in `corpus.jsonl` carries an `expected_entities` list — the
canonical entity names that should survive Graphiti's dedup for that episode.
Within-tenant F1 is computed by comparing the set of `EntityNode.name` values
Graphiti extracted and stored against the gold set across all 30 episodes.
Dedup correctness is scored at the entity-name level (not UUID level)
because Graphiti may assign different UUIDs across runs.

### Determinism

LLM: `gpt-4o-mini`, temperature=0. `gpt-4o-mini` is not byte-deterministic;
N=3 runs per arm. Reported metric: median F1 and p95 prompt tokens across runs.

### Scoring rule

Per query: `PASS` iff the within-tenant F1 for that query's arm meets or exceeds
baseline F1 − 5pp. Summary decision falls out of the aggregate F1 delta, p95
token ratio, and cost ratio vs the static arm.

2026-05-23 — methodology revised from #307's original two-tenant shared-group_id
design after gnokee-specialist verified `group_id = tenant_id` invariant. The
cross-tenant leak test would have been degenerate (always-pass).

---

## 4. What this does NOT cover

- **Cross-tenant entity-leak under shared `group_id`** — this scenario is
  structurally impossible in current gnokee (`group_id = tenant_id` per
  `src/gnokee/storage/graph.py:200`). Any test for it would be degenerate
  (trivially always-pass). If a future ADR ever permits shared-`group_id`
  multi-tenant graphs, that is a SEPARATE spike (not Q43).
- **Mid-stream type-vocabulary changes** — what happens when a tenant's
  `gnokee.types.yaml` changes between ingest runs. Out of scope per #307.
- **`gnokee_list_types` MCP tool** — the read-path companion to type injection.
  Out of scope per #307.
- **Graphiti extractor model extension** — custom entity-type classes. Out of
  scope per #307.
- **Multi-model validation** — this spike uses `gpt-4o-mini` only. Validation
  against gpt-4 / Claude Sonnet is a separate spike if extraction-prompt-specialist
  requests it after reviewing Q43 results.
- **Concurrent-ingest scenarios** — episodes are ingested serially. Concurrent-load
  silent-drop measurement is Q18's domain.
- **Temporal filters on entity recall** — bi-temporal query correctness is Q1's
  domain. Q43 measures dedup quality at a single reference time.
- **YAML schema validation** — Q43 does not test the `gnokee_types_yaml` schema
  validator itself; it assumes valid YAML input.

---

## 5. Cost & time

| Resource | Notes |
|---|---|
| LLM model | `gpt-4o-mini`, temperature=0 |
| LLM calls | 30 episodes × 2 arms × N=3 runs = 180 `add_episode` calls |
| Token estimate | ~800 tokens/call (episode + extraction prompt) → ~144k input tokens |
| LLM spend | ~$0.05 per full sweep (2 arms × 3 runs × 30 episodes at `gpt-4o-mini` rates) |
| Wall-clock | ~5 min per full sweep (Neo4j + OpenAI latency, serial ingest) |
| API key required | Maintainer supplies `GNOKEE_LLM_API_KEY` or `GNOKEE_OPENAI_API_KEY` |
| gnokee LLM policy | gnokee never vendors an LLM — endpoints supplied via env vars only |

---

## 6. ADR amendment

**No ADR amendment in this PR.** The amendment to
`docs/adr/0017-types-yaml.md` is gated on Q43 numbers. The amendment block
will:

- Record `decision` + `f1_within_5pp_of_baseline` + `token_p95_ratio_vs_static` + `cost_ratio_vs_static`
- Reference `evals/spike_q43_types_yaml_regression/results/<utc>.json`
- Update ADR-0017's "Status" from Proposed to Accepted (or add a Rework section)

---

## 7. Refs

- Issue #307 — Q43 spike brief
- Issue #78 — ADR-0017 `gnokee.types.yaml` design
- `docs/adr/0017-types-yaml.md` — ADR under test
- `docs/adr/0004-bi-temporal-and-storage.md` — group_id = tenant_id invariant (ADR-0004)
- `research/_dossier_umbrella_adjacent.md`
- `research/_dossier_fabric_iq.md`
- Specialist scope verdicts: extraction-prompt-specialist + graphiti-specialist (#307)
