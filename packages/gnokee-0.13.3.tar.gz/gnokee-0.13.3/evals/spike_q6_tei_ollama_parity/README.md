# Spike Q6 — TEI vs Ollama bge-m3 parity

> Closes the open question pinned in `v0.1_landed.md`:
> *"TEI default vs Ollama dev fallback parity, not yet measured."*
>
> v0.1.1 made the embedder dual-shape (TEI native ``/embed`` + OpenAI-
> compat ``/v1/embeddings``). Mac dev now defaults to system Ollama;
> Linux prod stays on TEI. This spike answers whether vectors written
> under one runtime can be queried under the other.

## Goal

Quantify drift between TEI (HuggingFace text-embeddings-inference,
bge-m3 FP16, candle/Rust, amd64 docker on Mac via Rosetta) and Ollama
(GGUF-quantised bge-m3, llama.cpp, Metal native on Mac) for the same
inputs. Decide whether the two runtimes are interchangeable for an
existing `content_embedding` corpus.

## Decision criterion

| Mean cosine (TEI-vec vs Ollama-vec, same input) | Outcome |
|---|---|
| ≥ 0.99 | **Interchangeable** — swap freely; no re-ingest needed |
| 0.95 – 0.99 | **Document drift** — flag in `bootstrap.py`; re-ingest recommended on swap |
| < 0.95 | **Non-interchangeable** — refuse boot when `embed_base_url` runtime differs from the runtime that wrote `content_embedding`; require explicit `GNOKEE_EMBED_RUNTIME_ACK=1` |

Retrieval-stability secondary criterion (decides "documented drift" vs
"interchangeable in practice"):

| Top-3 set overlap on synthetic query corpus | Notes |
|---|---|
| 100 % | drift is metric-only; rankings invariant |
| ≥ 80 % | safe for personal-AI / engineering notes |
| < 80 % | clinical / cross-lingual tail at risk; treat as non-interchangeable |

Throughput is reported but not gated.

## Methodology

1. Boot `gnokee-tei` container + system Ollama.
2. `python run.py` walks `corpus.jsonl` (50 texts spanning English /
   Russian / Bulgarian / Hebrew, plus numeric-dense, medical-panel, and
   code-snippet shapes) and embeds each text under both backends.
3. Compute per-text cosine `(tei_vec, ollama_vec)`; aggregate
   `mean / median / min / p10`.
4. Walk `queries.yaml`; embed each query under both backends; do top-3
   nearest-neighbor against the two corpus matrices; report set
   overlap per query.
5. Time both runs (sec / embed) for the throughput line.
6. Emit `results/<utc-stamp>.json` with per-text and per-query data.

## What this does NOT cover

- **Multi-language pairwise drift across languages** (e.g. en→ru retrieval
  parity). That's Q2's territory; here we only check that *within* each
  language the two runtimes agree on the same input.
- **Long-document parity** (>1000 tokens). bge-m3 truncates at 8192;
  TEI's `truncate=True` and Ollama's GGUF tokenizer may truncate
  slightly differently. Out of scope; flag if cosine is anomalously low
  on the long-document subset.
- **GPU TEI**. Production GPU TEI vectors will differ subtly from CPU
  TEI vectors; not measured here.

## Cost & time

- **Embed**: 50 texts × 2 runtimes = 100 calls. Negligible cost
  (zero LLM); wall ~1 minute on Metal Ollama, ~2 minutes on TEI Rosetta.
- **Disk**: ~400 KB JSON results per run.

## Run

```bash
docker start gnokee-tei
cd evals/spike_q6_tei_ollama_parity
../../.venv/bin/python run.py
```
