# Q44 — Tenant filter pushdown: profile before DDL ships

> **Status**: scaffold only — ADR amendment deferred pending Q44 numbers.
> **No `make eval-delta` integration** — Q44 takes ~5–15 min per fixture size.
> Invoke manually: `python evals/spike_q44_tenant_filter_pushdown/run.py --path=all --fixture-size=10k`

---

## 1. Goal

Measure the per-path latency cost and recall fidelity of five tenant-filter
strategies on a realistic multi-tenant synthetic fixture, producing the
numbers that issue #303 ("tenant filter pushdown into ANN scoring") needs
before any DDL or query rewrite ships in v0.14.

The design question this answers (docs/evals/methodology.md §retrieval-cost):

> At what per-tenant vector cardinality, if any, does moving the tenant
> filter *into* the index traversal (pgvector partial-index or
> iterative_search) outperform gnokee's current candidate-pool pre-filter
> pattern?  Does the answer differ between the Postgres path and the Neo4j
> path?

Both specialist scope verdicts (postgres-pgvector-specialist + neo4j-ops-specialist,
see #303 PR comment summary) were **YELLOW — spike first** because:

1. The issue's premise (~99% of candidates thrown out post-hoc) is incorrect.
   gnokee's Stage 2a narrows to `candidate_pool=500` UUIDs before the pgvector
   call, so the HNSW index is effectively bypassed for small-to-medium pools.
2. pgvector `iterative_search` only helps if Stage 2a is dropped — an
   architectural shift that conflicts ADR-0004.
3. Neo4j 5 Community's `CREATE VECTOR INDEX` has no `WHERE` clause support;
   filtering is always post-ANN.

Q44 does not implement the optimisation.  It only profiles.

Related: ADR-0004, ADR-0005, `research/_dossier_turbovec.md`.

---

## 2. Decision criterion

| Score class | Headline | Action |
|---|---|---|
| `partial_index` p95 improves ≥30% over `baseline_candidate_pool` **AND** `recall@10 == 1.0` at tested fixture sizes | Partial-index is a net win at this cardinality | **ADOPT** partial-index in v0.14 above the identified `cardinality_cutoff` |
| `iterative_search` p95 is within 10% of `baseline_candidate_pool` AND it removes Stage 2a | iterative_search is a safe drop-in | **ADOPT** iterative_search (also drops Neo4j pre-filter step) |
| Neither improvement meets threshold but numbers reveal a cutoff between 5k–20k vectors/tenant | Mixed — benefit accrues above a specific cardinality | **ADOPT_WITH_GAPS** — adopt above `cardinality_cutoff`, keep candidate-pool below |
| p95 improvement <30% for partial-index AND iterative_search p95 >10% worse | No meaningful gain | **REJECT** — keep current architecture, close #303 as won't-fix-v0.14 |

Exact thresholds:

- `ADOPT_PARTIAL_INDEX_THRESHOLD_PCT = 30.0` — p95 improvement over baseline required for partial-index
- `ADOPT_ITERATIVE_SEARCH_TOLERANCE_PCT = 10.0` — max p95 regression allowed for iterative_search to qualify
- `RECALL_REQUIRED = 1.0` — both paths must return exactly the ground-truth top-10 (synthetic corpus has a deterministic oracle)

The `decision` field in the output JSON is computed from data; it is never
hardcoded in the harness.

---

## 3. Methodology

### Fixture shape

| Segment | Tenant ID | Vector count | Purpose |
|---|---|---|---|
| Fat tenant | `q44-fixture-fat` | 5k / 10k / 20k | Primary measurement target — exercises index selectivity |
| Lean tenants (×10) | `q44-fixture-lean-0` … `q44-fixture-lean-9` | 100 vectors each | Realistic multi-tenant background noise |

All vectors are 1024-dim (bge-m3 shape) random unit-norm float32, generated
deterministically from `numpy.random.default_rng(seed=44)`.  Each tenant has
one "cluster center" drawn first; 80% of its vectors are Gaussian perturbations
of that center (cosine noise σ=0.15), 20% are pure uniform random.  This gives
a realistic near-cluster query with a deterministic ground truth.

### Probe set

One query per tenant per fixture-size variant (see `queries.yaml`).  The query
vector for each tenant is the cluster center itself.  The oracle top-10 is
computed by exact cosine over all vectors for that tenant at seed time and
stored alongside the fixture.

### Measurement loop

- Warmup: 5 runs per path, discarded.
- Timed: 50 runs per `(path, fixture_size, query)`.
- Timer: `time.perf_counter_ns()` wrapped around the SQL/Cypher call only,
  not the Python overhead.
- Summary stats: min, p50, p95, p99, max (all in ms).
- Recall@10: `|returned_uuids ∩ oracle_uuids| / 10`.

### Paths benchmarked

| Path key | Description |
|---|---|
| `baseline_candidate_pool` | Current gnokee shape: sample 500 UUIDs from target tenant (simulates Neo4j Stage 2a), then `SELECT … WHERE tenant_id=$1 AND episode_uuid=ANY($2)` cosine top-10 |
| `iterative_search` | `SET hnsw.iterative_scan=relaxed_order` + `SELECT … WHERE tenant_id=$1 ORDER BY embedding<=>$2 LIMIT 10` — no UUID pre-filter |
| `partial_index` | `CREATE INDEX CONCURRENTLY` per fat tenant at seed time; same query shape as iterative_search but hits the per-tenant index |
| `neo4j_post_filter` | `CALL db.index.vector.queryRelationships(…, 500, $vec) YIELD … MATCH (r {group_id:$tenant}) RETURN … LIMIT 10` (current Neo4j shape) |
| `neo4j_pre_narrow` | Same but vector budget reduced to top_k=50 + tighter post-filter (tests whether a smaller ANN budget recovers latency) |

### Scoring rules

`verdict = "PASS"` per `(fixture_size, path)` iff:
- `recall_at_10 == 1.0`
- `p95_ms < baseline_p95_ms * 1.2`  (within 20% latency budget of the current baseline)

This is a stretch fit of the Q1 row-verdict contract onto a latency benchmark.
The primary decision criterion is the p95 improvement percentage, not the
per-row pass/fail.  See "What this does NOT cover" §1.

---

## 4. What this does NOT cover

1. **Eval-delta gate row semantics**: the `(fixture_size, path)` row verdict
   (`recall@10 AND p95 within 20% of baseline`) is a pragmatic adapter so
   `--check-baseline / --capture-baseline` compile.  The real decision comes
   from the `decision_table` block in the JSON output, not from the pass-rate.
   Do not interpret a sub-100% pass rate as "recall is broken."

2. **Production query patterns**: vectors are synthetic random unit-norms.
   Real gnokee content embeddings have cluster structure and temporal locality
   that may change the crossover cardinality.

3. **Full gnokee retrieval pipeline**: Q44 isolates the vector index call.
   Stage 2a (Neo4j BFS), BM25 reranking, cross-encoder, and temporal filters
   are all excluded.  The end-to-end pipeline latency budget is different.

4. **Cross-tenant data leakage / RLS semantics**: covered by Q5 and
   `test_rls_guc_read_paths.py`.  Q44 uses a dedicated `q44-fixture-*`
   namespace and teardown.

5. **Neo4j Enterprise features**: `WHERE` clauses on `CREATE VECTOR INDEX`
   require Enterprise.  Community 5.x is the only target.

6. **Concurrent load**: Q44 runs queries serially.  Concurrent-ingest silent-
   drop measurement is Q18's domain.

7. **Partial-index maintenance cost** (index rebuild on insert): out of scope.
   Q44 only measures read-path latency; write amplification from per-tenant
   indexes is a v0.14 DDL design concern.

---

## 5. Cost & time

| Resource | Notes |
|---|---|
| Embedding generation | None — vectors are synthetic random unit-norms |
| LLM calls | None |
| Postgres container | Existing `docker compose` stack |
| Neo4j container | Existing `docker compose` stack |
| Wall-clock (fixture seed, 10k) | ~30–60 s (20k vectors × numpy + asyncpg bulk insert) |
| Wall-clock (full path sweep, 10k) | ~5 min (5 paths × 50 iters × ~100 ms each + warmup) |
| Wall-clock (all three fixture sizes) | ~15–20 min |
| Storage | ~80 MB for 20k × 1024 float32 in Postgres; not committed to git |

---

## 6. ADR amendment

**No ADR amendment in this PR.**  The amendment to
`docs/adr/0004-bi-temporal-and-storage.md` (or a new ADR on tenant-filter
strategy) is gated on Q44 numbers.  The amendment block will reference
`evals/spike_q44_tenant_filter_pushdown/results/<utc>.json` and record the
`decision_table.winner_by_p95` + `cardinality_cutoff_estimate_vectors_per_tenant`
values.

---

## 7. Refs

- Issue #303 — "tenant filter pushdown into ANN scoring"
- Specialist verdicts — postgres-pgvector-specialist + neo4j-ops-specialist (#303 PR comment)
- `research/_dossier_turbovec.md`
- ADR-0004 (`docs/adr/0004-bi-temporal-and-storage.md`)
- ADR-0005 (`docs/adr/0005-pgvector-embedding-store.md`)
- pgvector iterative scan docs: https://github.com/pgvector/pgvector#iterative-index-scans
- Neo4j 5 vector index: https://neo4j.com/docs/cypher-manual/current/indexes/semantic-indexes/vector-indexes/
