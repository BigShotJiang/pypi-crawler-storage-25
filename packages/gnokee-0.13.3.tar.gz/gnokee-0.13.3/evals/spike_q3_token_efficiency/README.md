# Spike Q3 — MCP token-efficiency

## Goal

Validate gnokee's "token-efficient by default" promise against the
naive baseline of dumping Graphiti's raw search results.

Per `docs/evals/methodology.md`: "**Token efficiency** — mean tokens
per query vs answer quality." This spike uses the Q1 corpus (already
in Neo4j under `group_id=spike`, 20 episodes) and the Q1 query set
(`evals/spike_q1_graphiti/queries.yaml`, 12 queries) to A/B two
response shapes over the same probes.

## Decision criterion

- **gnokee-shape mean tokens per query ≤ 70% of Graphiti-raw mean**
  (≥30% reduction, the bar set when this spike was scoped)
- **Top-3 recall must hold ≥80%** for the gnokee shape (the bar for
  the retrieval primitive itself, inherited from ADR-0001 / Q2)

If both are met → ADOPT the gnokee response shape for v0.1 MCP.

## Response shapes

### Mode A: `graphiti_raw` (the naive baseline)

Dumps the top-K edges from Graphiti's `client.search_()` with
`COMBINED_HYBRID_SEARCH_RRF` as the response, with all per-edge
metadata that an MCP integration might naively pipe through:

```text
Edge {uuid}:
  Fact: {edge.fact}
  Valid at: {valid_at}
  Invalid at: {invalid_at}
  Episodes: {comma-joined episode UUIDs}
```

This is what a "wire it through and ship it" MCP server would return.

### Mode B: `gnokee` (the design per ADR-0004 + architecture.md)

Per `docs/architecture.md` Retrieval contract: "natural-language fact
statements + lazy provenance + contradiction refs (not full bodies)".

Concretely, for the spike:

```text
{N}. {first_sentence_of_episode_content} [ep:{episode_id}, valid_at:{date}]
```

Top-K episodes by direct bge-m3 cosine over full episode content
(Q2's `direct_cosine.py` retrieval primitive), each rendered as a
single-sentence fact statement plus a lazy provenance handle. No edge
dump, no full episode body, no UUID soup.

## Methodology

For each of the 12 Q1 queries:

1. Run mode A (`graphiti_raw`) — call `client.search_()` with the same
   `SearchFilters` Q1 v2.1 used; format response per Mode A above.
2. Run mode B (`gnokee`) — embed query via bge-m3 (Ollama),
   cosine-rank Q1's 20 episodes by content, take top-3, format
   response per Mode B above.
3. Count tokens for each response via `tiktoken` (`cl100k_base`).
4. Score top-3 recall for each: did the Q1-expected episode appear
   in the top-3 of the response?

Headline number: **mean tokens per query (gnokee / graphiti_raw)**.

## What this spike does NOT cover

- Cross-tool comparison (Mem0, basic-memory, mcp-memory-service) —
  deferred to v1.0 published evals per `docs/evals/methodology.md`
- MCP wire-format overhead (tool descriptions, schemas, system
  messages) — different question
- LLM-rendering quality of the gnokee response shape — the spike
  measures token cost only, not whether the shape is pleasant for an
  LLM to consume. That belongs to a Q4-style follow-up against an
  agent-task eval

## Cost & time

Reuses the Q1 corpus already in Neo4j (no re-ingest). Direct cosine
runs against bge-m3 via Ollama (no LLM calls). 12 Graphiti `search_`
calls (entity reranking via gpt-4o-mini) ≈ $0.05 / run, ~2 minutes
wall.

## Sibling harness — `run_output_shape_fact.py` (issue #207, v0.12+)

`run.py` measures token cost of two **response shapes** at retrieval
time (raw Graphiti edges vs gnokee fact statements) and does NOT
invoke the v0.10 declarative envelope. The footer of ADR-0013 v0.10
Amendment carried `median tokens = (pending — Q3 re-run deferred)`
for the new `output_shape="fact"` mode.

`run_output_shape_fact.py` closes that gap by driving the production
`gnokee.query.gnokee_query` orchestrator end-to-end:

```bash
python run_output_shape_fact.py
```

Differences from `run.py`:

| Axis | `run.py` | `run_output_shape_fact.py` |
|---|---|---|
| Retrieval surface | `graphiti.search_()` vs direct bge-m3 cosine | `gnokee_query` envelope (production path) |
| Output shape | naive raw + compact A/B | `output_shape="fact"` (facts + lazy provenance only) |
| Corpus seed | reuses Q1 Neo4j data | re-ingests Q1 corpus via `ingest_episode(extract=True)` under `tenant_id="q3-output-shape-fact"` |
| `fact_revision` rows | not exercised | required for `output_shape="fact"` substitution; seeded by the re-ingest |
| Cost | ~$0.05 / run, ~2 min | ~$0.10-0.20 / first run (LLM extraction), ~5-10 min wall; re-runs short-circuit on idempotent ingest |
| Result file | `results/<utc-stamp>.json` | `results/<utc-stamp>-output-shape-fact.json` |

The harness writes a `delta_vs_baseline` field into the summary
comparing the new median against the 125-token Q3-mixed baseline so
ADR-0013's footer can be updated mechanically from the JSON dump.

Headline number for the ADR amendment: **median tokens for
`output_shape="fact"`**.
