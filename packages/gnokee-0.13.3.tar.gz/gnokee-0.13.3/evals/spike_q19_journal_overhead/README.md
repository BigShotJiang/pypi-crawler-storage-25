# Spike Q19 — ingest_journal overhead

> **Verdict (2026-05-16, run `20260516T085012`):** **PASS.**
> `regression_pct(median) = 2.17%` (journal-on 101.93 ms vs
> journal-off 99.76 ms median; N=50 lite-mode ingests per condition on
> Docker compose stack pg17 + neo4j-5-community + tei-cpu-arm64).
> Two extra Postgres inserts (`begin` + `commit`) add ~2 ms to a
> ~100 ms lite-mode ingest. Threshold (< 10%) clears with margin.

Threshold per ADR-0024 §Acceptance: **median(ingest_episode) regression
must be < 10%** vs v0.6 Z1-B baseline (journal disabled).

ADR-0024 / issue #122 adds two Postgres inserts to every `ingest_episode`
call — one `begin` row before Stage 4, one `commit` row after Stage 5 —
plus a once-per-tenant-per-process `scan_resumable` SELECT. This spike
measures the per-ingest latency delta against the same-process baseline
where the journal is replaced with a no-op stub.

## Goal

Confirm the journal's per-call overhead stays under 10% of median
end-to-end ingest latency on a v0.1.1-shape corpus. If exceeded, the
impl PR (#129) cannot flip out of draft.

## Decision criterion

- **PASS** — `regression_pct(median) < 10.0`
- **FAIL** — otherwise; investigate or amend ADR-0024.

## Methodology

1. Boot a real `App` (Postgres + Neo4j + TEI; `docker compose ps`
   green).
2. For each condition (`journal_off`, `journal_on`):
   a. Spin a fresh tenant id.
   b. Ingest `N = 50` synthetic English episodes via
      `app.ingest.ingest(episode, extract=False)` — lite mode so Stage 6
      LLM cost is not in the measurement.
   c. Time each call (`time.perf_counter`) to nanosecond resolution.
3. `journal_off` swaps `app.ingest.journal` with a no-op stub
   (write_begin / write_commit / write_fail / scan_resumable return
   constants; no DB roundtrip).
4. Compute median, p95, mean per condition; report regression on
   median.
5. Dump raw timings + summary to `results/<utc-stamp>.json`.

`extract=False` isolates the journal cost from Graphiti LLM extraction
variance (which dominates total ingest latency in full mode and would
swamp the journal's tens-of-µs noise floor).

## What this does NOT cover

- **Full-mode ingest** (Stage 6 graphiti enhancement). Stage 6 dominates
  total ingest latency by ~2 orders of magnitude when an OpenAI-tier
  LLM is in the path. The journal's relative cost there is vanishingly
  small; lite mode is the worst case.
- **Resume latency.** `resume_ingest` cost is bounded by Stage 4 +
  Stage 5 + one `scan_resumable` and is not a hot-path concern.
- **Concurrent ingest.** Single-flight measurement; the Z4 semaphore
  shape and its TPM-aware behaviour are covered by Q18.
- **Encrypted-body branch.** Same Stage 5 idempotency contract; cost
  delta is identical.

## Cost & time

- 50 × 2 conditions = 100 lite-mode ingests, ~150 ms each end-to-end
  on a healthy stack → ~15 s total.
- No LLM calls; no embedding-model cost beyond TEI's local CPU work.
- No tenant data persists beyond the run — synthetic content, fresh
  tenant per condition.

## Reproduction

```bash
make up                              # if not already running
.venv/bin/python evals/spike_q19_journal_overhead/run.py
```

Output: `evals/spike_q19_journal_overhead/results/<utc>.json` with raw
per-call timings and the summary block. Exit code 0 on PASS, 1 on FAIL.
