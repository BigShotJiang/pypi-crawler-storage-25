# Spike Q2 — Multilingual cross-lingual retrieval (bge-m3)

## Goal

Verify that bge-m3 (the embedding model gnokee defaults to) retrieves the
right facts when **query language and episode language differ**. Q1 v2.1
incidentally cleared two cross-lingual hits (Russian e_011, Bulgarian
e_013); Q2 stresses this on purpose across the four languages
[`docs/evals/methodology.md`](../../docs/evals/methodology.md) names as
in-scope: **en, ru, bg, he** — the languages the project author writes
in.

## Decision criterion

Per the amended ADR-0001 framing (capability headline, axis-dependent
queries graded separately):

| Score class | Headline | Action |
|---|---|---|
| Cross-lingual top-3 hit rate | ≥80% | ADOPT bge-m3 as default |
| Cross-lingual top-3 hit rate | 50–80% | ADOPT_WITH_GAPS — list each pair that misses |
| Cross-lingual top-3 hit rate | <50% | REJECT bge-m3, evaluate alternatives (multilingual-e5-large, jina-embeddings-v3) |

"Top-3 hit rate" = fraction of probes where the expected episode appears
in positions 1, 2, or 3 of the search result. Top-3 (not top-1) because
gnokee's MCP layer typically hands an LLM the top few facts; ranking
slack is acceptable as long as the right hit is reachable in a small
window.

## Test design

A 4-language matrix. For each language pair `(query_lang, target_lang)`
write **one factual probe** — query phrased in `query_lang`, expected
target episode authored in `target_lang`. With 4 languages this is **16
probes** (4 same-language + 12 cross-lingual). Same-language probes are
the control: if same-language fails, we have a retrieval problem
unrelated to multilinguality.

### Topics

Each probe targets a specific *fact* — a concrete claim that should
match a single source episode. **Each fact is stored in exactly one
language** (one fact per language: F1=en, F2=ru, F3=bg, F4=he) so that
"can the query language reach the storage language" is the direct
question. Storing each fact in all four languages would conflate
"retrieved any sibling" with "bridged the language gap".

### Topics to cover

Four facts, each stored in exactly one language — **4 episodes total**:

| Episode ID | Domain | Lang | Content (gist) |
|---|---|---|---|
| q2_f1_en | identity | en | Joined Lumen Health (health-AI startup) in April 2025 |
| q2_f2_ru | clinical | ru | Flu vaccine 2024-2025 received in November |
| q2_f3_bg | journal | bg | Tel Aviv week with family, January 2025 |
| q2_f4_he | preferences | he | Switched to Neovim with LazyVim, December 2025 |

The four-fact set deliberately mirrors content shapes already exercised
by Q1, so any pass/fail in Q2 is attributable to the **language axis**,
not a re-test of fact extraction or temporal reasoning.

### Probe matrix

For each query language ∈ {en, ru, bg, he}, one probe per fact —
**16 probes total**. Naming: `p_<query_lang>_f<n>` (e.g. `p_en_f2`).

| Probe | Query lang | Target | Target lang | Type |
|---|---|---|---|---|
| p_en_f1 | en | q2_f1_en | en | control |
| p_en_f2 | en | q2_f2_ru | ru | cross (en→ru) |
| p_en_f3 | en | q2_f3_bg | bg | cross (en→bg) |
| p_en_f4 | en | q2_f4_he | he | cross (en→he) |
| p_ru_f1 | ru | q2_f1_en | en | cross (ru→en) |
| p_ru_f2 | ru | q2_f2_ru | ru | control |
| p_ru_f3 | ru | q2_f3_bg | bg | cross (ru→bg) |
| p_ru_f4 | ru | q2_f4_he | he | cross (ru→he) |
| p_bg_f1 | bg | q2_f1_en | en | cross (bg→en) |
| p_bg_f2 | bg | q2_f2_ru | ru | cross (bg→ru) |
| p_bg_f3 | bg | q2_f3_bg | bg | control |
| p_bg_f4 | bg | q2_f4_he | he | cross (bg→he) |
| p_he_f1 | he | q2_f1_en | en | cross (he→en) |
| p_he_f2 | he | q2_f2_ru | ru | cross (he→ru) |
| p_he_f3 | he | q2_f3_bg | bg | cross (he→bg) |
| p_he_f4 | he | q2_f4_he | he | control |

4 controls + 12 cross probes covering **all 12 directed language pairs**
exactly once.

## Decision

Single headline number: **top-3 hit rate over 12 cross-lingual probes**.
Same-language controls graded separately (must hit 4/4 or the whole
result is invalid — the bug is upstream of multilinguality).

## Reuse from Q1 v2.1

- Same harness pattern (`COMBINED_HYBRID_SEARCH_RRF`, node-mention
  Cypher resolve)
- Same Neo4j + bge-m3 + OpenAI Responses stack
- Same group_id partitioning (`spike` per Q1 → `spike_q2` here so they
  don't collide if both volumes are live)
- Per-run JSON dumps to `results/<UTC-timestamp>.json`, gitignored

## Cost & time

Much smaller than Q1: 4 episodes (vs 20) and 16 probes (vs 12). Expect
~$0.10–0.15 per run on OpenAI cloud, ~3–5 minutes wall.

## Author + proofread protocol

LLM drafts the four episodes (en / ru / bg / he); user proofreads each
non-English episode for fluency and natural phrasing before the spike
runs. If a draft reads as machine-translated to a native eye, the
artificial awkwardness will bias retrieval and invalidate the result.
