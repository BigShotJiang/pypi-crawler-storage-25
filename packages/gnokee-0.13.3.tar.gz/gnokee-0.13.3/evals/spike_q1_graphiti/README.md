# Spike Q1 — Graphiti fitness for gnokee

> Per `docs/adr/0001-build-on-graphiti.md` and Notion `10 — Open Questions / Backlog` Q1.
> Wired against `graphiti-core>=0.29` (released 2026-04-27).

## Goal

Validate that Graphiti's bi-temporal node + edge model handles the query
patterns gnokee promises, against representative episodes from both
target consumers (Omur health-AI SaaS + personal-AI agents).

## Decision criterion

| % of expected query patterns that pass | Outcome |
|---|---|
| ≥ 80% | **Adopt Graphiti** (ADR-0001 → Accepted) |
| 50% – 80% | **Adopt with documented gap-fillers** (amend `docs/architecture.md`) |
| < 50% | **Reject** — consider XTDB or roll our own |

A query "passes" when **all expected episode IDs** appear in the returned
edge set. Partial overlap = `partial` (counted as fail for the headline).

## Prerequisites

1. **Docker** running (for Neo4j)
2. **An OpenAI-compatible LLM endpoint** — one of:
   - OpenAI cloud (set `GNOKEE_LLM_API_KEY` + leave `GNOKEE_LLM_BASE_URL` unset; default model `gpt-4o-mini`)
   - **Ollama** locally (set `GNOKEE_LLM_BASE_URL=http://localhost:11434/v1`, `GNOKEE_LLM_API_KEY=ollama`, `GNOKEE_LLM_MODEL=llama3.1:8b` or larger; needs at least 16 GB RAM)
   - Anthropic via LiteLLM proxy (set `GNOKEE_LLM_BASE_URL` to the proxy URL)
3. **An OpenAI-compatible embeddings endpoint** — defaults to OpenAI; for
   Ollama with bge-m3 set:
   ```
   GNOKEE_EMBED_BASE_URL=http://localhost:11434/v1
   GNOKEE_EMBED_API_KEY=ollama
   GNOKEE_EMBED_MODEL=bge-m3
   GNOKEE_EMBED_DIM=1024
   ```
4. **Python 3.10+**

## Run

```bash
# 1. Bring up Neo4j (and Postgres, harmless idle).
cd ../..                          # repo root
docker compose up -d neo4j

# 2. Spike venv (separate from main package venv).
cd evals/spike_q1_graphiti
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# 3. Configure environment (creates .env at the repo root).
cp ../../.env.example ../../.env
# Edit ../../.env. Mandatory:
#   GNOKEE_NEO4J_URI=bolt://localhost:7687
#   GNOKEE_NEO4J_USER=neo4j
#   GNOKEE_NEO4J_PASSWORD=gnokee-dev-password
# Plus the LLM and embeddings vars from "Prerequisites" above.

# 4. Run.
python run.py
```

Output:

- Console summary: `{pass, partial, fail, error}` counts + headline % + `decision ∈ {ADOPT, ADOPT_WITH_GAPS, REJECT}`
- JSON dump: `results/<UTC-timestamp>.json` with per-query verdicts and
  episode-id round-trips for analysis

## Cost & time

| Backend | Time | $ |
|---|---|---|
| OpenAI cloud (`gpt-4o-mini` + `text-embedding-3-small`) | ~5–10 min | ~$0.30 |
| Ollama local (`llama3.1:8b` + `bge-m3`) | ~25–45 min | $0 (electricity) |

Each ingest call invokes the configured LLM for entity extraction; ~20
episodes × 1–3 LLM calls per episode + per-query LLM calls during search
reranking.

## Re-running on Graphiti major upgrades

This spike is the regression suite for the Graphiti dependency. Re-run on
every major Graphiti version bump. If pass% drops below the threshold,
**do not upgrade in production** until the gap is understood.

## Known limitations of v1 spike

- **Bi-temporal axes** (`as_of`, `valid_at`) are recorded per-query in
  `queries.yaml` but not yet exercised via `SearchFilters`. Add filter
  construction in v2 to actually verify time-travel.
- **`neo4j` driver 6.x compatibility** — `requirements.txt` allows
  `neo4j>=5.20,<7`; if Graphiti 0.29 needs 5.x specifically, pip will
  resolve down. Watch the install log.
- **Ranking signal** is whatever Graphiti's default reranker emits.
  We don't tune; the question is *capability*, not *quality*.

## Reading the JSON dump

```jsonc
{
  "graphiti_version": "0.29",
  "counts": {"pass": 9, "partial": 2, "fail": 1, "error": 0},
  "headline_pass_pct": 75.0,
  "decision": "ADOPT_WITH_GAPS",
  "results": [
    {
      "id": "q_db_now",
      "pattern": "current state — single-property entity",
      "verdict": "pass",
      "expected": ["e_002"],
      "returned": ["e_002", "e_001"],
      "edge_count": 7,
      "tokens": 220,
      "bi_temporal_attempted": true,
      "error": null
    }
  ]
}
```

`returned` is a superset of `expected` for `pass`; ordered by appearance
across edges. `tokens` is a rough char/4 estimate over edge fact strings.
