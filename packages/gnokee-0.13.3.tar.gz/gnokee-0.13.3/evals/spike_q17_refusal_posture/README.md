# Spike Q17 — Refusal Posture

> Consolidates GitHub issues [#77](https://github.com/omurlabs/gnokee/issues/77)
> (source-grounded refusal Q-suite) and [#94](https://github.com/omurlabs/gnokee/issues/94)
> (refusal posture UX gap) under tracking issue
> [#109](https://github.com/omurlabs/gnokee/issues/109).
> Verdict feeds ADR-0022.

## Goal

gnokee today enforces a zero-hallucination contract: when asked an
out-of-domain question, `gnokee_recall` returns off-topic facts (grounded
in the corpus) rather than fabricated answers. This satisfies the contract
but does NOT match the NotebookLM-class explicit-refusal posture, where the
system signals "I cannot answer from these sources" when the corpus does not
carry the answer.

Issue #94 calls this a UX gap. Issue #77 asks for a Q-suite that measures it.
Issue #109 consolidates both: stage the spike, measure the current posture
across three tenant shapes, and decide the design.

This spike evaluates the shipped gnokee stack (v0.4+) against N=30 Q-X.3
(not-answerable) probes across three tenant shapes:

- **Clinical-only** — lab and medication corpus; questions about unrelated
  topics (programming preferences, travel plans).
- **Prose-only** — personal journal / lifestyle corpus; questions about clinical
  details not in the corpus.
- **Mixed** — combined personal + clinical corpus; questions that span both
  domains but also include fully out-of-domain probes.

For each probe the harness records: `refusal_explicit` (empty fact-list or
structured `refused` signal), `refusal_implicit` (off-topic facts returned
with no forbidden entities), and `hallucination` (forbidden entity present in
any returned fact). These three categories then feed the per-design-option
rubric in § Verdict.

The connection to `docs/evals/methodology.md` § Target dimensions: this spike
exercises the **abstention behaviour** dimension (Q12's Q-X.3 subtype) and
the **refusal accuracy** dimension, extending both to a multi-tenant scenario.
The four design options evaluated here gate ADR-0022 (refusal posture decision).

## Decision criterion

| Score class | Headline | Action |
|---|---|---|
| ADOPT (Option A — `refused` field) | hallucination_rate <= 5% AND refusal_explicit_rate >= 70% | Ship typed `refused: bool` on `RecallResponse`. Document in ADR-0022. |
| ADOPT (Option B — confidence_floor) | hallucination_rate <= 5% AND refusal_explicit_rate >= 70% via empty fact-list at threshold | Ship `confidence_floor` parameter that returns empty set when no fact clears the threshold. |
| ADOPT (Option C — consumer-LLM-owned) | hallucination_rate <= 5% AND refusal_implicit_rate >= 70% | Do nothing in gnokee; document that consumer LLM must own the "I cannot answer" signal. |
| ADOPT (Option D — stay silent) | hallucination_rate <= 5% | gnokee remains silent; surface off-topic facts and let consumer decide. Explicitly document this as gnokee's posture. |
| REJECT | hallucination_rate > 5% | Any design option moot — fix the zero-hallucination contract first. |
| INVALID_CONTROLS_FAILED | answerable-topic control probes fail | Harness is broken; run is invalid. |

Exact thresholds:

- `REFUSAL_RATE_THRESHOLD = 0.70` — fraction of probes that return zero facts
  (explicit refusal posture, current stack without changes).
- `HALLUCINATION_RATE_THRESHOLD = 0.05` — fraction of probes where any returned
  fact contains a forbidden entity. Must stay at or below 5% to hold the
  zero-hallucination contract.

The per-design-option rubric (§ Verdict) evaluates each option against:

1. **ADR-0004 "gnokee owns retrieval"** — does the option keep the retrieval
   surface clean without delegating retrieval decisions to the consumer LLM?
2. **ADR-0019 confidence model** — does the option integrate coherently with the
   recency-proxy `confidence` field already shipped?
3. **AGENTS.md "no auto-resolve" red line** — does the option risk silently
   picking one side when the corpus contains contradictions?
4. **Measured current posture** — what does gnokee actually do today on the
   30 Q-X.3 probes?

## Methodology

### Corpus shape

Three hand-curated corpora, 10 episodes each, ingest under separate group_ids.

- `corpus.jsonl` sections tagged by `tenant_shape`:
  - **`clinical`** — 10 lab and medication episodes (synthetic, same shape as
    Q7/Q8 corpora). Topics: thyroid labs, cholesterol panel, metformin regimen.
  - **`prose`** — 10 personal-journal episodes. Topics: running, travel planning,
    reading notes, home improvement.
  - **`mixed`** — 10 episodes spanning both clinical and prose. Topics: GP visit
    notes, fitness recovery, book club, medication reminder.

All episodes use the subject "Jordan Reeves" (distinct from Q41's Alex Morgan
and Q13's subject to avoid cross-corpus contamination in the same Neo4j instance).

### Probe set

`queries.yaml` — 10 probes per tenant shape = 30 Q-X.3 probes total. Each probe:

- `probe_type`: `control | unanswerable`
- `gold_topic_excluded`: which topic the correct answer would require — never
  present in the corpus under that tenant.
- `forbidden_entities[]`: entity names or topic tokens that must NOT appear in
  any returned fact (case-insensitive). Presence = hallucination.
- `tenant_shape`: `clinical | prose | mixed`
- `corpus_group`: group_id used during ingest

Control probes (2 per tenant shape, 6 total) ask an answerable question from
that tenant's corpus to verify the harness is correctly wired.

### Scoring rules per probe

- `refusal_explicit`: `len(response.facts) == 0` — gnokee returned nothing (the
  tightest form of refusal; no separate signal today, just empty set).
- `refusal_implicit`: `len(response.facts) > 0 AND no forbidden_entity in any fact`
  — gnokee returned something but it was not forbidden (off-topic facts about the
  corpus domain, not the question domain).
- `hallucination`: `any forbidden_entity in any fact.text` (case-insensitive).
- `passed`: `NOT hallucination` — both explicit and implicit refusal count as
  pass for the zero-hallucination contract.

### Ingest-completeness pre-flight

Per `docs/evals/methodology.md` § "Authoring a new spike" rule (2026-05-12):
before scoring, the harness asserts `SELECT count(*) FROM episode_metadata WHERE
tenant_id = ANY(...)` equals the expected episode count. If the count is short,
the run aborts with a clear message rather than publishing an artefact.

### GROUP_ID convention

- `spike_q17_clinical` — clinical-only corpus
- `spike_q17_prose` — prose-only corpus
- `spike_q17_mixed` — mixed corpus

### What the harness does NOT exercise

See § What this does NOT cover.

## What this does NOT cover

- **Q-X.1 / Q-X.2 probes** — fully answerable and partially answerable recall is
  covered by Q41 (landed PR #93). This spike extends only Q-X.3.
- **Contradiction surfacing (Q-X.4)** — covered by Q41 and ADR-0008. The refusal
  posture design options must not break contradiction surfacing, but this spike
  does not re-measure it.
- **Cross-source-type bridges** — issue #102 / Q15. Bridge recall is orthogonal;
  refusal posture applies after retrieval finds nothing.
- **MCP tool-description copy** — the exact wording of any "gnokee cannot answer"
  signal in tool descriptions is a follow-up copy decision, not a spike measurement.
- **LLM-graded refusal quality** — all grading is keyword-based against
  `forbidden_entities[]`. No LLM-as-judge. Implicit refusal (off-topic facts
  returned) passes as long as no forbidden entity appears.
- **Multilingual probes** — all episodes and queries are English only.
- **Encrypted-body path** — plaintext episodes only; encrypted body tested in
  issue #22 / v0.3.

## Cost and time

| Item | Count | Estimate |
|---|---|---|
| Ingest LLM calls (graphiti extraction) | 30 episodes | ~$0.01–0.03 (gpt-4o-mini @ ~1k tokens/episode) |
| Recall API calls | 30 probes | ~$0.005 (embed only — no LLM on read path) |
| Embed calls (TEI/Ollama bge-m3) | 30+30 | $0.00 (local) |
| Neo4j Cypher queries | ~150 | $0.00 (local) |
| Postgres queries | ~90 | $0.00 (local) |
| **Total (full run)** | | **~$0.01–$0.05 / run** |
| **Wall time** | | **~5–15 minutes** |

No LLM judge: grading is purely keyword-based. The `graphiti_core.add_episode`
extraction calls are the only non-free component, and the 30-episode corpus
is well under the $1 infeasibility ceiling documented in ADR-0019 § Re-spike
attempt.

## Run

```bash
cd evals/spike_q17_refusal_posture
set -a && source ../../.env && set +a

# Full run (ingest + eval):
../../.venv/bin/python run.py

# Skip ingest (corpus already loaded):
GNOKEE_SPIKE_SKIP_INGEST=1 ../../.venv/bin/python run.py

# Run only one tenant shape:
GNOKEE_SPIKE_SEARCH_MODE=clinical ../../.venv/bin/python run.py

# Override search limit:
GNOKEE_SPIKE_SEARCH_LIMIT=20 ../../.venv/bin/python run.py
```

## Verdict

Live run: `results/20260511T213407Z.json` (2026-05-12, N=30 probes — 24 unanswerable
+ 6 controls). Re-run with `GNOKEE_SPIKE_SKIP_INGEST=1` after fresh ingest.

**Overall verdict: `ADOPT_OPTION_D_CURRENT_POSTURE_CONTROLS_PARTIAL`**

### Measured posture (Q17 live run, 2026-05-12)

| Tenant shape | N unanswerable | hallucination | refusal_explicit | refusal_implicit | passed |
|---|---|---|---|---|---|
| clinical | 8 | 0% | 0% | 100% | 8/8 (100%) |
| prose | 8 | 0% | 0% | 100% | 8/8 (100%) |
| mixed | 8 | 0% | 0% | 100% | 8/8 (100%) |
| **Total** | **24** | **0%** | **0%** | **100%** | **24/24 (100%)** |

Controls: 4/6 pass. Two controls failed due to graphiti literal-extraction gap
(documented in ADR-0019 § Follow-up, issue #90 — accepted). The failed controls:

- `q17_clin_ctrl_02` (allergy query) — graphiti did not extract "penicillin" or
  "allergy" as entity/fact nodes from the allergy episode. Known pattern: state-of-
  being medical assertions are paraphrased or dropped during extraction. This is
  the same gap that produced 6/13 failures in Q13. Verdict suffix `_CONTROLS_PARTIAL`
  is correct — the harness is not broken; the extraction gap is documented.
- `q17_mix_ctrl_02` (yoga class query) — graphiti did not extract yoga-specific
  facts from the mixed episode. The episode's principal entity was coded as
  "Meadows Yoga Studio" but the fact node did not survive with "yoga" as a
  keyword-level string.

These gaps do not affect the Q17 primary question: hallucination_rate = 0% is
valid across all 24 unanswerable probes regardless of control outcome.

### Key finding

gnokee currently has `explicit_refusal_rate = 0%`. On every out-of-domain query,
facts from the corpus ARE returned — they are grounded (no forbidden entities), but
they are off-topic relative to the query. The consumer receives facts about Jordan
Reeves's weight, physiotherapy, or coding project when asked about the subject's
investment portfolio or travel hotel.

This is Option D as-shipped: gnokee is silent (no `refused` signal), surfaces
off-topic but grounded facts, and lets the consumer decide. The zero-hallucination
contract holds (100% of 24 probes pass), but the NotebookLM-class "I cannot answer
from these sources" signal is NOT present.

### Per-design-option rubric

| Criterion | Option A: `refused` field | Option B: `confidence_floor` | Option C: consumer-LLM-owned | Option D: stay silent |
|---|---|---|---|---|
| ADR-0004 (gnokee owns retrieval) | Retrieval runs; flag added post-retrieval. Owned. | Retrieval runs; threshold filters result. Owned. | Retrieval runs; signal delegated downstream. Partial — gnokee does the retrieval work, consumer does the posture. | Retrieval runs; no additional logic. Fully owned. |
| ADR-0019 (confidence model) | `refused` would correlate with low confidence. Coherent. | `confidence_floor` IS the existing ADR-0013 parameter; aligns naturally. | No interaction — confidence field unchanged. | No interaction. |
| AGENTS.md no-auto-resolve | Flag is additive; does not suppress contradictions. Safe. | Empty result set could hide a contradiction. Risk: returning nothing when both sides exist. Needs guard. | Consumer decides — risk consumer auto-resolves. Out of gnokee's control. | gnokee surfaces all facts including contradictions. Safest. |
| Current posture fit | Not shipped. Requires code (~10 LOC). | `confidence_floor` exists in ADR-0013; needs threshold calibration (no measured threshold yet). | Already the de facto posture. Zero code. | Already the de facto posture. Zero code. |
| UX gap closed (#94) | Yes — explicit signal in response payload. | Partially — empty set is implicit; no human-readable signal. | No — consumer must add the message. | No. |
| Risk | Low — additive field, no retrieval change. | Medium — miscalibrated floor hides contradictions. Needs Q17.1 spike. | Low for gnokee; risk shifts to consumer. | Zero additional risk; #94 remains open. |

### Recommended option

**ADR-0022 Decision: Option D is the documented v0.5 posture (zero code); Option A
is the recommended v0.5.x follow-up to close #94.**

Rationale:

1. The live run confirms hallucination_rate = 0% across 24 probes and three tenant
   shapes. gnokee's zero-hallucination contract holds in its current form. No
   regression risk from maintaining Option D.

2. Option A (`refused: bool` on `RecallResponse`) closes #94 with the lowest risk of
   any of the four options. It is additive (no change to the retrieval path),
   coherent with ADR-0019 confidence model, and safe for the no-auto-resolve red line.
   The implementation is a post-retrieval check: if `len(facts) == 0 AND
   len(episode_fallback) == 0`, set `refused=True`.

3. Option B (`confidence_floor` empty-set) requires a threshold calibration spike
   (Q17.1) before it can be shipped — the current run shows 100% implicit refusal
   with non-zero fact lists, so there is no existing floor that would produce
   explicit refusal without also filtering valid answers.

4. Option C (consumer-LLM-owned) conflicts with ADR-0004's "gnokee owns retrieval"
   framing. It is acceptable only if gnokee explicitly commits to never owning the
   refusal signal — which contradicts the NotebookLM-class posture that motivated
   issue #77.

5. Option D is what ships in v0.5 today (no change). Document it explicitly in
   ADR-0022 as a deliberate decision, not silent drift.
