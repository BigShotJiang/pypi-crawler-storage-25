# Spike Q5 — Forgetting smoke test

## Goal

Validate the **propagation chain** in `gnokee.forget(X)` per
`docs/architecture.md`:

> Hard delete with tombstone propagation — vector index, graph,
> derived summaries all touched. Returns a `ForgetReceipt`
> enumerating affected artifacts.

A successful `forget` must remove the episode from **every retrieval
surface** simultaneously. This spike does not test cryptographic
erasure (that requires a KMS) or soft supersession (that requires
`transaction_time_end` machinery). It tests the **hard-delete path**
end-to-end against the Q1 corpus.

## Decision criterion

After `forget(e_X)`:

1. The Neo4j `Episodic` node, all `MENTIONS` relations from it, and
   any `RELATES_TO` edges that referenced it as their sole episode,
   are gone (and orphaned `Entity`s with zero remaining mentions are
   cleaned up).
2. The gnokee-side content-embedding map (the v0.1 pgvector path)
   no longer contains the episode's embedding.
3. A retrieval query that previously surfaced `e_X` no longer
   surfaces it (any rank).

ADOPT if all three hold for **2/2 forget operations** on episodes
that were verifiably retrievable beforehand.

## Test design

Two probes against the Q1 corpus (already in Neo4j under
`group_id=spike`, `episodes.jsonl` available):

| Probe | Forget target | Pre-forget query | Pre-forget expectation |
|---|---|---|---|
| 1 | `e_005` (K+ 3.1 original) | "What was my potassium reading on 2024-04-10?" | `e_005` in top-3 by cosine |
| 2 | `e_002` (MongoDB migration) | "What database does the project use?" | `e_002` in top-3 by cosine |

For each probe:

1. Embed the corpus, compute baseline cosine ranking — assert target
   is in top-3 (otherwise the probe itself is invalid)
2. Read pre-forget Neo4j state: count `Episodic`, `Entity`, `MENTIONS`,
   `RELATES_TO` for the target's neighborhood (provenance for the
   `ForgetReceipt`)
3. Execute `forget(e_X)` against the gnokee-managed in-memory
   embedding map AND the Graphiti-managed Neo4j store (single Cypher
   transaction)
4. Re-rank — assert `e_X` is gone (no longer in any returned
   position)
5. Re-read Neo4j — assert provenance counts have decremented as
   expected
6. Emit a `ForgetReceipt`-shaped record per probe

## What this spike does NOT cover

- **Soft supersession.** Different code path (set
  `transaction_time_end`, leave row queryable via time-travel).
  Belongs in a v0.1 retrieval spec test, not here.
- **Cryptographic erasure.** Requires a KMS-backed DEK; deferred to a
  v0.2+ test against OpenBao or similar.
- **Tombstone propagation to derived summaries.** v0.1 doesn't yet
  generate maintenance summaries; their forget-cascade design lands
  with the maintenance scheduler.
- **Tenant-scoped forget isolation.** Multi-tenancy validation is a
  separate question (Q8-equivalent); this spike runs single-tenant
  on `group_id=spike`.

## Cost & time

No LLM calls. ~12 cosine computations (corpus + 2 queries) via local
bge-m3, plus ~6 Cypher round-trips. Under 30 seconds wall, $0.

---

## Probes 3+4 (v0.8 production surface)

### Background

v0.8 (PR #133, ADR-0026) ships hard-delete via `gnokee.forget.forget_episode` /
`forget_tenant` backed by a `gnokee_maintenance.forget_audit` two-phase audit
table (begin → commit, or begin → fail for crash-recovery). Probes 1+2 above
use raw Cypher and predate this surface. Probes 3+4 exercise the public API
end-to-end against real Postgres + Neo4j, with fixtures hand-seeded via direct
SQL (bypassing Stage 6 / LLM enrichment — per issue #141 § Out of scope).

### How to run

```
pip install -r requirements.txt   # once; includes gnokee from repo root
python evals/spike_q5_forgetting/run_v08.py
```

Required env (or `.env` at repo root):

| Var | Default |
|---|---|
| `GNOKEE_PG_*` (USER/PASSWORD/DB/HOST/PORT) | — Settings assembles DSN |
| `GNOKEE_NEO4J_URI` | `bolt://localhost:7687` |
| `GNOKEE_NEO4J_USER` | `neo4j` |
| `GNOKEE_NEO4J_PASSWORD` | — (required) |
| `GNOKEE_OPENAI_BASE_URL` | `http://localhost:11434/v1` |
| `GNOKEE_EMBED_BASE_URL` | `http://localhost:11434/v1` |
| `GNOKEE_EMBED_MODEL` | `bge-m3` |

Results are written to `evals/spike_q5_forgetting/results/v08_<utc>.json`.

### Probe descriptions

**Probe 3 — chain refusal + cascade**

Seeds A → B → C via `episode_metadata.superseded_by`.
1. `forget_episode(B, cascade=False)` must raise `CannotForgetChainNode`
   with `descendant_count==1`.
2. `forget_episode(B, cascade=True)` must return a receipt with
   `affected_episode_count==2`; B and C must be absent from
   `episode_metadata`; A must still be present with `superseded_by==NULL`.

**Probe 4 — tenant sweep**

Seeds N=3 episodes + corresponding `ingest_journal` rows for one tenant.
1. `forget_tenant(dry_run=True)` must return a planned receipt with no
   `state='commit'` row in `gnokee_maintenance.forget_audit`.
2. `forget_tenant(dry_run=False)` must: (a) write a `state='commit'` row in
   `forget_audit` scoped to `tenant`; (b) clear all `ingest_journal` rows for
   the tenant (closes #130); (c) remove all `episode_metadata` rows; (d) leave
   the `forget_audit` row intact (schema is in `gnokee_maintenance`, outside
   the tenant sweep).

### Decision criterion

ADOPT if 2/2 probes pass. Decision is computed from data and written to
`summary.decision` in the JSON output — never hardcoded.

### Out of scope for Probes 3+4

- Neo4j graph-layer granular coverage (integration tests cover that).
- Cryptographic erasure / DEK handoff (`affected_key_ids[]` path).
- Concurrent ingest + forget contention (`test_serialization_retry` in
  integration suite).
- Probes 3+4 do NOT modify `run.py` (legacy Probes 1+2).
