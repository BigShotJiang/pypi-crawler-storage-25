# Spike Q9 — Wearable throughput cost projection

> Closes the third Omur clinical-shape question (Q7 = labs, Q8 = meds,
> Q9 = wearables). Q9 is *not* a query-quality spike — it's a
> **cost-and-throughput** measurement, because the load-bearing risk
> for wearables is whether graphiti's per-episode LLM extraction can
> sustain real wearable rates without making Omur unviable per-user.

## Goal

Measure the per-episode cost of ingesting wearable-shape data through
gnokee's v0.1.1 stack (`gnokee.ingest_episode` → graphiti
`add_episode` → entity extraction LLM + embedding fan-out + edge
synthesis) and project to realistic wearable-stream volumes.

Three representative shapes:

- **Per-sample raw** — one episode per HR / HRV / SpO2 sample
  (e.g. 1/min via Apple Health). Volume ceiling: ~525k events/metric/year.
- **Hourly summary** — one episode per metric per hour
  ("HR last hour: avg 72, min 58, max 121, samples 60"). Volume:
  ~8.7k events/metric/year.
- **Daily summary** — one episode per metric per day
  ("Sleep score 84, total 7h12m, deep 1h45m, REM 1h28m"). Volume:
  ~365 events/metric/year.

## Decision criterion

Project per-user-per-year ingest cost against three thresholds:

| Per-user-per-year ingest cost | Outcome |
|---|---|
| < $5 / user / year | **Adopt as-is** — graphiti per-episode is fine |
| $5 – $50 / user / year | **Batch-and-summarise** — daily/hourly summary episodes; raw stream goes elsewhere or stays in the consumer's edge |
| > $50 / user / year | **Hard off-ramp** — raw wearable stream lands in TimescaleDB / Prometheus; gnokee owns only synthesised summary + anomaly facts |

Cost dominates here because graphiti's per-episode LLM extraction is
the bottleneck. Wall-clock latency is reported as a secondary metric
(throughput ceiling = `top_hourly_summary_rate / latency_per_episode`).

## Methodology

1. Boot the v0.1.1 compose stack (`make up && make migrate`).
2. Ingest the small representative corpus under each shape (raw,
   hourly, daily) and time `ingest_episode` per call.
3. Read the LLM cost back from `gnokee_llm_call_log` (a thin httpx
   middleware the spike installs to count + size each LLM request).
4. Project the per-episode cost / latency to the volume ceiling for
   each shape.
5. Emit `results/<utc-stamp>.json` with measured + projected numbers.

This spike does *not* re-ingest at wearable scale. We measure on a
representative N=20 corpus and extrapolate, because actually running
525k ingests would cost the very thing this spike is here to estimate.

## What this does NOT cover

- **Storage cost** — Postgres + Neo4j growth at wearable scale is real
  (`fact_embedding` HNSW index gets large) but is dwarfed by ingest
  LLM cost. Out of scope.
- **Recall cost on wearable corpus** — we don't expect wearable
  queries to hit the read path often enough to matter; agents query
  summaries, not individual samples.
- **Model variation** — measurements are against the configured
  `GNOKEE_LLM_MODEL`. A future GPU-served local LLM would change the
  cost dimension to wall-clock + GPU-hours rather than per-token $.

## Cost & time

- ~20 episodes × $0.001 ≈ $0.02 LLM cost.
- Wall ~3–5 min on the v0.1.1 compose stack.

## Run

```bash
cd evals/spike_q9_wearable_throughput
docker compose --profile embeddings --project-directory ../.. up -d gnokee-postgres gnokee-neo4j tei
set -a && source ../../.env && set +a
../../.venv/bin/python run.py
```
