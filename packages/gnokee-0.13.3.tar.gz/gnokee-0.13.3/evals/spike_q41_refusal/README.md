# Spike Q41 — Source-Grounded Refusal Q-Suite (Boundary + Contradiction Class)

> Implements spike plan from GitHub issue [#77](https://github.com/omurlabs/gnokee/issues/77).
> Verdict feeds ADR-0008 amendment (§ Spike verdict).
> Tracking issue: [#77](https://github.com/omurlabs/gnokee/issues/77).

## Goal

gnokee's MCP read path must enforce three contracts that distinguish it from
peers (NotebookLM, Pinecone KnowQL, GCP Memory Bank):

1. **Refusal at the boundary** — when the corpus does not contain an answer,
   `gnokee_recall` returns zero facts and a low confidence score; it does NOT
   hallucinate. NotebookLM scores full marks here; gnokee must match it.
2. **Partial coverage honesty** — when the corpus partially answers, `facts[]`
   carries only what is grounded; no gap-filling from the LLM's parametric
   knowledge.
3. **No-auto-resolve on contradiction** — when both sides of a contradiction
   exist in the corpus, `gnokee_recall` surfaces BOTH via `contradictions[]`
   or `supersession_hints[]`. gnokee is uniquely positioned here; NotebookLM
   has no bi-temporal model.

This spike evaluates the shipped gnokee stack (v0.4+) against all three
contracts using four hand-curated corpora and four question sub-types (Q-X.1
through Q-X.4). The spike answers whether gnokee's recall surface already
enforces these contracts or whether code changes are required before the
contracts can be documented in ADR-0008 and surfaced to consumers.

The connection to the methodology target dimensions in `docs/evals/methodology.md`:
refusal accuracy (boundary class), partial-recall honesty (coverage class), and
no-auto-resolve (contract enforcement class). All three feed ADR-0008.

## Decision criterion

| Score class | Headline | Action |
|---|---|---|
| ADOPT | Q-X.1 >= 80% pass AND Q-X.2 >= 60% pass AND Q-X.3 strict zero-hallucination pass rate = 100% AND Q-X.4 both-sides rate >= 70% | All three contracts hold; document in ADR-0008; unblock consumer-facing guarantee language. |
| ADOPT_WITH_GAPS | Q-X.3 = 100% AND Q-X.4 >= 50% AND (Q-X.1 < 80% OR Q-X.2 < 60%) | Refusal and contradiction contracts hold; recall coverage has gaps; file follow-up. |
| REJECT | Q-X.3 < 100% (any hallucinated fact) OR Q-X.4 < 50% (auto-resolve bias) | Fundamental contract violations; block consumer-facing guarantee language until fixed. |
| INVALID_CONTROLS_FAILED | Any Q-X.1 control probe fails | Harness itself is broken; run is invalid. |

Exact thresholds:

- **Q-X.1 (fully answerable)**: pass = response has >= 1 fact AND fact text
  contains a keyword from `expected_keywords[]`. Threshold: `>= 80%` of probes
  pass.
- **Q-X.2 (partially answerable)**: pass = response contains SOME facts but
  not all expected; partial coverage signalled (facts list non-empty but
  incomplete). Threshold: `>= 60%` of probes pass.
- **Q-X.3 (not answerable)**: pass = response contains zero facts OR all
  returned facts are grounded in corpus entities. `strict_zero_hallucination`
  pass = 100% required. Any fabricated entity name against the `forbidden_entities`
  list = immediate REJECT.
- **Q-X.4 (contradicting episodes)**: pass = response surfaces `contradictions[]`
  on at least one FactStatement OR returns both sides as separate FactStatements
  with conflicting `valid_at` values. Threshold: `>= 70%` of probes pass.

## Methodology

### Corpus shape

Four hand-curated corpora, ~10 episodes each, realistic personal-AI shape
(location, health, finance, work). All use the same character "Alex Morgan"
as the subject. Each corpus is designed to exercise exactly one sub-type.

- `corpus_x1_answerable.jsonl` — 10 episodes with clear single-citation answers.
  No contradictions, no supersession chains. Fully answerable at 2025-06-01.
- `corpus_x2_partial.jsonl` — 10 episodes where some questions can only be
  partially answered (one leg of a two-part question exists in corpus, other
  does not; or answer exists but is incomplete without corpus context).
- `corpus_x3_unanswerable.jsonl` — 10 episodes about a distinct topic domain
  (home renovation projects). Questions ask about a completely unrelated topic
  (stock investments). Zero overlap — the corpus is genuinely not answereable.
- `corpus_x4_contradiction.jsonl` — 10 episodes containing deliberate
  contradictions (same fact asserted at two different `valid_at` timestamps).
  Four explicit contradiction pairs. gnokee's contradiction pipeline must fire
  on ingest.

### Probe set

`queries.yaml` — 10 probes per sub-type (40 total + 5 optional Q-X.5
cross-tenant probes). Each probe specifies:
- `probe_type`: `control | answerable | partial | unanswerable | contradiction | cross_tenant`
- `expected_keywords[]`: what must appear in a passing fact for Q-X.1 / Q-X.2
- `forbidden_entities[]`: entity names that must NOT appear in responses for Q-X.3
- `expected_both_sides[]`: for Q-X.4, the two conflicting fact fragments
- `sub_type`: `x1 | x2 | x3 | x4 | x5`

### Scoring rules

- **Q-X.1 hit**: `len(response.facts) >= 1 AND any keyword in any fact.text`
- **Q-X.2 partial hit**: `len(response.facts) >= 1 AND len(response.facts) < expected_max_facts`
- **Q-X.3 clean**: `len(response.facts) == 0 OR all fact.text contains no forbidden_entity substring`
  (case-insensitive). Strict: any forbidden entity in any fact = FAIL.
- **Q-X.4 both-sides**: `any(f.contradicts for f in response.facts) OR len(response.supersession_hints) >= 1`
  AND response contains fact text fragments from BOTH `expected_both_sides`.

### What the harness does NOT exercise

See § What this does NOT cover below.

### GROUP_ID convention

Each sub-type uses its own `GROUP_ID` to avoid cross-contamination:

- `spike_q41_x1` — Q-X.1 corpus
- `spike_q41_x2` — Q-X.2 corpus
- `spike_q41_x3` — Q-X.3 corpus
- `spike_q41_x4` — Q-X.4 corpus

The `as_of` for all queries is pinned to `2025-06-01T00:00:00Z`.

## What this does NOT cover

- **No LLM prompt tuning** — the spike measures the SHIPPED gnokee system as-is.
  Hand-tuning prompts to force Q-X.3 compliance would defeat the eval.
- **No regression on Q1–Q12** — separate concern; those spikes cover recall
  floor and extraction quality.
- **No Q10 LongMemEval-S overlap** — Q10 is recall floor; Q41 is contract
  enforcement. Different failure modes.
- **No cross-tenant query execution** — Q-X.5 is listed in `queries.yaml` as
  a stretch goal, but the harness does not actually impersonate a second tenant.
  It ingests corpus under tenant A's group_id and asks a question scoped to
  tenant B's group_id; expects zero results. Cross-tenant federation attack is
  out of scope for this spike.
- **No encryption path** — episodes are plaintext. Encrypted body path tested
  separately in issue #22 / v0.3.
- **No MCP layer** — this spike calls `gnokee.recall()` directly via the Python
  API. MCP JSON serialisation is tested by integration tests, not here.
- **No LLM output grading** — all grading is keyword-based against `queries.yaml`
  labels. No LLM-as-judge. This means Q-X.2 pass/fail is conservative (a
  partially-correct response that uses synonyms instead of keywords may fail).
- **No multi-language** — all episodes and queries are English only. Q2 covers
  multilingual.

## Cost and time

| Item | Count | Estimate |
|---|---|---|
| Ingest LLM calls (graphiti episode extraction) | ~40 episodes | ~$0.02–0.08 (gpt-4o-mini @ ~1k tokens/episode) |
| Recall API calls | 40 probes | ~$0.01 (embed only — gnokee.recall() does not call LLM) |
| Embed calls (TEI / Ollama bge-m3) | 40+40 (ingest+recall) | $0.00 (local) |
| Neo4j Cypher queries | ~200 (5 per recall call) | $0.00 (local) |
| Postgres queries | ~120 | $0.00 (local) |
| **Total (full run)** | | **~$0.03–$0.10 / run** |
| **Wall time** | | **~10–20 minutes** (including ingest with LLM extraction) |

Cost is well under the $5 gate — no additional env flag required. If LLM
extraction costs exceed $1, the run is likely misconfigured (wrong model).

Run model: `gpt-4o-mini` (graphiti extraction default). Recall calls: 0 LLM
calls (gnokee recall does not invoke LLM on the read path).

## Run

```bash
cd evals/spike_q41_refusal
set -a && source ../../.env && set +a

# Full run (ingest + eval):
../../.venv/bin/python run.py

# Skip ingest (corpus already loaded under spike_q41_x1/x2/x3/x4):
GNOKEE_SPIKE_SKIP_INGEST=1 ../../.venv/bin/python run.py

# Only run a specific sub-type:
GNOKEE_SPIKE_SUB_TYPE=x3 ../../.venv/bin/python run.py

# Override search limit:
GNOKEE_SPIKE_SEARCH_LIMIT=20 ../../.venv/bin/python run.py
```
