# Spike Q13 — Confidence-Decay Function Evaluation

> Implements spike plan from `docs/adr/0019-confidence-model.md` (Proposed).
> Gates ADR-0013 (#72) + ADR-0016 (#76).
> Tracking issue: [#80](https://github.com/omurlabs/gnokee/issues/80).

## Goal

gnokee's MCP read responses carry a `confidence` field today populated as
`null` or a Graphiti-supplied edge score. ADR-0013 wants to expose
`confidence_floor` on the declarative envelope; ADR-0016 wants per-citation
`confidence`. Both adoption candidates need a defensible semantics for what the
number actually means.

This spike evaluates three candidate confidence-decay functions (A, B, C) from
ADR-0019 against a hand-curated 15-20-episode corpus. The corpus contains
explicit contradiction pairs, supersession chains, stale facts, and
reinforcement groups — the four gnokee-native primitives the composite function
uses. The spike answers whether function C (contradiction-aware composite)
beats the simpler baselines by a margin large enough to justify the added
complexity, or whether gnokee should ship `confidence: null` in v0.5 until a
defensible model lands.

The spike never calls any consumer LLM. All grading is against hand-curated
labels (`grading.yaml`). SHIP_NULL is an explicit, acceptable outcome per
ADR-0019 § Acceptable null outcome.

## Decision criterion

| Score class | Headline | Action |
|---|---|---|
| SHIP_COMPOSITE | composite Spearman >= baseline + 0.10 AND calibration max <= 0.15 | Adopt function C; update ADR-0019; unblock ADR-0013 / ADR-0016 |
| SHIP_RECENCY_AS_PROXY | recency Spearman > baseline + 0.05 (but composite does not clear the full bar) | Adopt function B, documented as "recency proxy" not "confidence model" |
| SHIP_NULL | neither function clears its respective threshold | Ship `confidence: null` in v0.5; ADR-0019 documents deliberate absence |

Exact thresholds (all taken from ADR-0019 § Decision rule):
- Composite must beat constant baseline by **>= 0.10 Spearman**.
- Composite calibration max bucket deviation must be **<= 0.15**.
- Recency proxy bar: **> 0.05** Spearman improvement over constant.

The SHIP_NULL outcome is not a failure of the spike. It means gnokee refuses to
ship a number it cannot defend, which is the correct NotebookLM-class trust
posture when no candidate clears its threshold.

## Methodology

Three candidate functions from ADR-0019:

- **A. Constant baseline** — `1.0` when active, `null` when not. Matches
  today's Graphiti default. Baseline for Spearman comparison.
- **B. Recency-only (Ebbinghaus)** — `exp(-delta_days / 365)`. Hypothesis:
  time alone predicts confidence better than constant 1.0.
- **C. Contradiction-aware composite** — ADR-0019 formula:
  `clip(0, 1, reinforcement_score - 0.5 * contradiction_score + 0.2 * recency_factor)`.
  Uses all four gnokee-native primitives.

**Corpus**: 15-20 hand-curated episodes ingested under
`GROUP_ID = "spike_q13_confidence"`. The corpus contains 5 contradiction pairs
(different `valid_at` dates to give bi-temporal signal), 3 supersession chains
(using `corrects:` field), 2 entirely-stale facts (asserted years ago, never
refreshed), and 5-10 supporting episodes that reinforce primary facts via
independent mentions.

**Probe set**: 12 questions in `queries.yaml`. Each has a hand-graded
`expected_confidence [0,1]` and a `believed` bool. Distribution: 4 high
(0.8+), 4 mid (0.4-0.7), 4 low/stale (0.0-0.3). Two or three probes use a
historical `as_of` pin to test bi-temporal sensitivity.

**Scoring rules**:
- `accuracy_at_0.5` — binary classification of `believed` at threshold 0.5.
- `spearman_r` — `scipy.stats.spearmanr` between function outputs and
  `expected_confidence` across 12 probes.
- `calibration_max` — 5-bucket predicted-mean vs actual-believed-rate; maximum
  absolute deviation from the diagonal.
- `latency_ms_p50` — confidence computation time only, separate from recall.
- `reranker_delta` — `spearman(composite) - spearman(cosine_only_top1)` for
  composite; if delta < 0.05, flagged as "reranker in disguise".

The harness pulls fact-graph counts (reinforcement count, contradiction count)
via raw Cypher through `app.recall.graph._g.driver` and contradiction rows
through `app.recall.contradictions`, following the patterns established in
Q11. The `ContradictionStore.lookup_counterparts` method is used directly.
Reinforcement count is derived from
`COUNT { (e:Episodic)-[:MENTIONS]->(f:Entity) }` per fact within `GROUP_ID`.

**Anti-patterns this spike must avoid** (ADR-0019 § Anti-patterns):

1. **Reranker score in disguise.** The spike explicitly computes a
   `reranker_delta` check. If composite Spearman improvement over cosine is
   < 0.05, the verdict notes "reranker in disguise" even if Spearman is
   otherwise good.
2. **LLM-supplied confidence.** Zero LLM calls in this spike. All grading is
   from hand-curated `grading.yaml` labels.
3. **Time-only decay.** Function B is a hypothesis, not a foregone conclusion.
   It ships only if it actually outperforms constant 1.0 by the stated margin.
4. **Auto-resolution disguised as confidence.** The confidence model ranks
   facts — it never silences one side of a contradiction. The corpus contains
   deliberate contradiction pairs that must appear together in results with
   different confidence values, not with one filtered out.

## What this does NOT cover

- **Source-trust prior (option D).** Caller-supplied per-topic priors
  (`clinical.lab` > `email` > `scraped_web`) are deferred. Needs
  `tenant_metadata` table that does not exist yet.
- **Per-tenant confidence-model overrides.** v0.5 is single-default.
- **Cross-tenant corpus.** All episodes share one `GROUP_ID`; multi-tenant
  isolation is not exercised.
- **LLM-graded confidence.** Anti-pattern per ADR-0019 and AGENTS.md "do not"
  list. No LLM calls here.
- **Per-topic priors.** Clinical facts vs. personal facts vs. email facts are
  not distinguished by topic weight in functions A/B/C.
- **Confidence for typed clinical reads** (`lab_record`, `med_record` tables).
  Those carry their own bi-temporal validity independent of the fact-graph
  model. This spike covers only the generic fact-graph path.

## Cost & time

- **LLM calls**: 0. The spike never invokes any LLM for grading or
  classification.
- **Embed calls**: 12 (one per query probe, via gnokee TEI bge-m3). Optional
  if `GNOKEE_SPIKE_SKIP_INGEST=1` and cosine baseline is read from stored
  embeddings.
- **Neo4j calls**: ~24 Cypher queries (2 per probe: reinforcement count +
  MENTIONS walk).
- **Postgres calls**: ~12 (contradiction lookup via `ContradictionStore`,
  1 per probe fact).
- **Wall time**: < 5 minutes for 12 probes on local docker-compose stack.
- **$ estimate**: $0.00 (no LLM calls; all compute is local).
- **Model**: none.

## Run

```bash
cd evals/spike_q13_confidence
set -a && source ../../.env && set +a

# With ingest (first run):
../../.venv/bin/python run.py

# Skip ingest (corpus already under spike_q13_confidence group_id):
GNOKEE_SPIKE_SKIP_INGEST=1 ../../.venv/bin/python run.py

# Override search mode or limit:
GNOKEE_SPIKE_SEARCH_MODE=cosine GNOKEE_SPIKE_SEARCH_LIMIT=10 ../../.venv/bin/python run.py
```
