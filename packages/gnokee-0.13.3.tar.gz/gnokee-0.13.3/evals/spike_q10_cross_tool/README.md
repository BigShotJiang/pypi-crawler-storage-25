# Spike Q10 — Cross-tool eval (gnokee vs Mem0 / Graphiti-alone / Zep-OSS / basic-memory)

> Closes the "**Eval suite formalised across cross-tool**" gate in
> `README.md` Status block, and unblocks Omur ADR-028 § Sequencing
> (parallel-publish plan currently DRAFT). v0.3 milestone in
> `README.md:114` ("Omur consumes gnokee; multi-tenant validation;
> encrypted-body branch") sequences in front of this spike.
>
> Verdict lands in **ADR-0012**.

## Goal

Produce a publishable, reproducible cross-tool comparison table that
puts gnokee's headline number alongside the public memory-tool
landscape on a benchmark Mem0's authors have already published numbers
on (LongMemEval-S → Mem0 reports 93.4), and gnokee's typed clinical
surface (Q7 + Q8) where competitors are expected to N/A or
underperform honestly.

Per `docs/evals/methodology.md`: "**published eval numbers**, not
feature lists." This spike is the first eval in the repo that puts
gnokee in a comparison table.

## Systems under test

The original Q10 plan named five SUTs (gnokee, graphiti-alone, mem0,
zep-oss, basic-memory). The first three cover the load-bearing
comparisons (Mem0's published 93.4 anchor + the
graphiti-alone-vs-gnokee architectural delta) and are wired + smoked
for the pilot. Zep-OSS and basic-memory are deferred to Q10.1 — Zep
needs a Docker-compose stack (Postgres + Zep server + their
migrations); basic-memory requires the full alembic/project state
machinery to call its `SearchService` from outside its CLI/MCP shell.
Both are real work that would block the ADR-0012 cycle without
adding new headline signal beyond the wired three.

**Wired (Stage A onwards):**

| Tool | Version | Retrieval primitive | Default embedder | Notes |
|---|---|---|---|---|
| `gnokee` | v0.2.3 | `gnokee_recall` (pgvector + Graphiti hybrid + preprocessor) | bge-m3 1024-dim | Primary SUT — what Q10 asks about |
| `graphiti-alone` | matches gnokee's pin | `client.search_()` `COMBINED_HYBRID_SEARCH_RRF` | bge-m3 1024-dim (same Neo4j cluster) | Validates gnokee adds value over the primitive |
| `mem0` | OSS 2.0.x, pinned `gpt-4o-mini-2024-07-18` extractor | `m.search(query, filters={'user_id': ...})` | OpenAI `text-embedding-3-small` 1536-dim (Track 1) / bge-m3 (Track 2) | Mem0 reports **93.4** on LongMemEval-S |

**Wired (Q10.1 additions):**

| Tool | Version | Retrieval primitive | Default embedder | Notes |
|---|---|---|---|---|
| `zep-oss` | 2.x CE (ghcr.io/getzep/zep:latest) | `client.memory.search_sessions(user_id, text, limit)` fact search | Zep CE default (Graphiti core) | Architectural cousin via Graphiti core; CE docker-compose at `docker-compose.zep.yml`. Requires `ZEP_API_URL`. |
| `basic-memory` | 0.20.x (pip) | SQLite FTS5 BM25 (`aiosqlite` direct; no server) | None — FTS5 only | "Do you even need a vector store?" baseline. Metric: answer-recall via BM25, NOT cosine-precision. Track 2 N/A. |

**Deferred:**

| Tool | Reason |
|---|---|
| `letta` / `mcp-memory-service` | Tier-3 in the original plan — defer to a future spike. |

Zep and basic-memory are wired as of Q10.1 (2026-05-09).
ADR-0012 is amended with the new rows; the headline ADOPT/REJECT verdict
stands on the three original SUTs (Stage A data).

**Stage C-pilot landed 2026-05-10** (run-id `stageC_30q20s`, 30 Q × 20-session
× gnokee + graphiti-alone + basic-memory × Track 1) — confirms Stage A magnitude
(0/30 strict across all three SUTs). ADR-0012 status flipped Draft → Accepted.
Mem0 dropped after silent crash (#63); Zep CE config mismatch deferred (separate
issue). Full Stage C (100 Q × full ~47-session haystack × Track 1 + Track 2)
remains pending under #63 — needs `asyncio.gather` parallelism and Mem0 root-cause.

**Q12 spike landed 2026-05-10** (synth-v2 prompt + judge abstain split,
re-run on `stageC_30q20s.json`) — falsifies issue #62's "synth abstention
dominates" hypothesis. v1 → v2 prompt loosening unlocked 3 extra attempts
across 90 rows; **all 5 attempts judged `wrong`**. Bottleneck is retrieval,
not synth. New `accuracy_strict_attempted` + `abstain_rate` metrics land in
`q12_judge_v2`. Issue #62 closed-as-falsified. See ADR-0012 § "Q12 spike —
synth abstention is symptom, not cause."

## Decision criterion

Single ADOPT/REJECT bar with regression guards.

| Metric | Condition | Outcome |
|---|---|---|
| LongMemEval-S accuracy (judge) | gnokee ≥ Mem0_published − 5 pp (≥ **88.4 %** if Mem0 = 93.4) | **ADOPT** |
| LongMemEval-S accuracy | gnokee ≥ 70 % | **ADOPT_WITH_GAPS** |
| LongMemEval-S accuracy | gnokee < 70 % | **REJECT** |
| Q7 pass rate | ≥ 11/15 (v0.2.3 baseline) | regression guard |
| Q8 pass rate | ≥ 16/16 (v0.2.1 baseline) | regression guard |

Q7 or Q8 regression → decision = `INVALID_REGRESSION` (the spike does
not ship until the regression is explained or fixed).

5 pp slack against Mem0's published 93.4 explicitly absorbs:
- LLM-judge variance at gpt-4o-mini scale (~5 % from prompt-specialist);
- Mem0's published number was measured on its default stack (OpenAI
  embedder + their own judge prompt) and is not strictly apples-to-apples.

The slack is documented, not papered over.

## Methodology

### Two reporting tracks

Per embedding-specialist review, every metric ships in both tracks.

- **Track 1 — As-published.** Each tool runs on its default stack.
  Mem0 on `text-embedding-3-small` + GPT-4o-mini, gnokee on bge-m3,
  Zep-OSS on its default, basic-memory on FTS5+LLM. This is the
  "which product as-shipped" answer.
- **Track 2 — Iso-embedder.** Mem0 reconfigured to bge-m3 (matches
  gnokee + graphiti-alone + Zep-OSS). This isolates the
  memory-architecture contribution from the embedder contribution.
  basic-memory is N/A (no embedder).

The disclosure table lists *retrieval mechanism*, not just embedder,
so basic-memory's FTS5+LLM-rerank is honestly different metric
(answer-recall, not top-k precision) — flagged in the table footer.

The Q10-pre micro-spike (`evals/spike_q10_pre_embedder/`) supplies a
quantitative footnote on bge-m3 vs text-embedding-3-small on the Q2
multilingual subset, bounding the embedder-only gap.

**Q10-pre measurement** (`evals/spike_q10_pre_embedder/results/20260509T111608Z.json`,
multilingual_v2 corpus: 24 episodes × 64 probes across 8 languages
en/ru/bg/he/ar/zh-Hans/es/tr, 5 scripts; direct cosine top-3, no
graph, no rerank):

| Embedder | Controls | Cross-lingual | Overall |
|---|---|---|---|
| bge-m3 (gnokee + graphiti-alone + Zep-OSS default) | 8/8 | 56/56 | **64/64 (100.0 %)** |
| text-embedding-3-small (Mem0 default) | 7/8 | 48/56 | **55/64 (85.9 %)** |

Failure clustering for `text-embedding-3-small`: **all 8 F5 probes
(Arabic-stored fact) miss top-3, including the `ar→ar` control**. The
single non-Arabic miss is `he→en` (F1) — same probe pattern that
appeared in the original Q2-corpus run.

Interpretation: OpenAI's default embedder appears to embed Arabic
queries and Arabic episodes into incompatible regions of vector
space; bge-m3 handles all 8 languages × 5 scripts cleanly.
Embedder-only contribution to gnokee's multilingual advantage is
bounded at **~14 pp** on this corpus. Track 2 (iso-embedder, Mem0
reconfigured to bge-m3) controls for this in the Q10 LongMemEval-S
report.

### Corpora

- **Primary public**: LongMemEval-S (cleaned), 500 Q. Pinned via
  `corpus/pin_longmemeval.py` against the upstream HuggingFace
  dataset `xiaowu0162/longmemeval-cleaned`, file
  `longmemeval_s_cleaned.json`, SHA256
  `d6f21ea9d60a0d56f34a05b609c79c88a451d2ae03597821ea3d5a9678c3a442`,
  HF repo SHA `98d7416c24c778c2fee6e6f3006e7a073259d48f`,
  MIT-licensed. The script downloads + verifies + emits a
  deterministic stratified-sampled `pilot_100.jsonl`
  (round-robin over the 6 alphabetically-sorted `question_type`
  buckets, `question_id`-ordered within each: knowledge-update 17,
  multi-session 17, single-session-assistant 17,
  single-session-preference 17, single-session-user 16,
  temporal-reasoning 16). Full 500 only if pilot lands in the ±5 pp
  zone around the ADOPT threshold. Raw + JSONL + pilot are gitignored
  (~265 MB / 52 MB); only `pin_longmemeval.py` + `SOURCE.md` are
  committed.
- **Secondary gnokee-side**: Q7 lab corpus + Q8 med corpus, reused
  via `GNOKEE_SPIKE_SKIP_INGEST=1` against existing fixtures. The
  cross-tool harness reads Q7 + Q8 result JSONs for the gnokee
  column and re-runs Q7+Q8 query patterns against the other 4 tools
  (where they can answer at all).
- **Multilingual subset**: Q2 corpus en/ru/bg/he, reported as a
  separate sub-table — not aggregated into LongMemEval-S — with
  explicit framing "cross-lingual retrieval is gnokee's primary
  use-case; not part of Mem0's published eval scope."

### Metrics

Mirror the published eval shape of Mem0 + LongMemEval to keep the
comparison readable.

1. **LongMemEval-S accuracy** — gpt-4o-mini LLM-as-judge, three-way
   `correct | partial | wrong`, plus a row-level `abstain` annotation
   set BEFORE the judge runs when the candidate is empty / "I don't
   know." (Q12 / ADR-0012 amendment, 2026-05-10). Reported metrics:
   `accuracy_strict`, `accuracy_lenient`, `abstain_rate`, and the
   attempted-only variants `accuracy_strict_attempted` /
   `accuracy_lenient_attempted` that exclude abstains from the
   denominator. Identical judge prompt across all 5 SUTs. See
   § Judge protocol below.
2. **Tokens / query** — `tiktoken cl100k_base` over the response
   payload (mirrors Q3 metric).
3. **Wall-clock p50** — query latency. `p95` deferred (eval-spike-author
   scope cut).
4. **Q7 + Q8 pass rate** — gnokee read from fixture results;
   competitors run live.
5. **$ / 100 Q** — LLM + embed, summed per tool.

Reported per-tool, per-track, per-corpus.

### Judge protocol (per prompt-specialist)

- Model: `gpt-4o-mini-2024-07-18` (pinned snapshot, **never** floating
  `gpt-4o-mini`).
- `temperature=0`, `seed=42`, per-question independent calls (no
  pairwise / quadwise prompting → kills position bias).
- Strip provenance handles (`[ep:...]`, UUIDs, edge UUIDs) + truncate
  response to 300 tokens before the judge sees it (kills length /
  verbosity bias against gnokee's compact shape vs graphiti-raw JSON
  dump).
- Tool-call structured output `emit_verdict(label, confidence, reason)`
  forced via `tool_choice` (portability across OpenAI-compat
  endpoints; not JSON-schema mode).
- Tool name hidden from judge — label assignment in harness post-hoc.
- Judge prompt body in `judge_prompt.txt` (committed literal bytes,
  diff-able across runs).

#### Disagreement protocol

- Run the full judge pass twice (same seed, same model snapshot,
  different wall-clock).
- `disagreement_rate = |run1 != run2| / total`.
- > 10 % → escalate disagreed question IDs to `gpt-4o`. Majority of
  (run1, run2, escalation) wins.
- > 25 % → flag the entire eval `JUDGE_UNSTABLE` and abort. Cross-tool
  ranking does not ship until the prompt is hardened.

#### Multilingual judge risk

gpt-4o-mini auto-translates Hebrew (Q2 finding). he subset gets a
second-pass `gpt-4o` judge for sanity; if verdict distribution
diverges > 15 % from gpt-4o-mini, the he column is reported with a
"judge-capability gap" footnote, never silently aggregated into the
en/ru/bg score.

### Multi-tenant + isolation discipline (per gnokee-reviewer)

- **Distinct `group_id` per (SUT × corpus × track)** —
  e.g., `q10_gnokee_longmem_t1`, `q10_graphiti_longmem_t1`,
  `q10_mem0_longmem_t2`, `q10_gnokee_q7`, …
- **Distinct `tenant_id`** — `q10-{sut}-{track}` UUIDs scoped to this
  spike; never shared with Q1–Q9.
- **`spike_id` audit column** on any harness-owned Postgres table.
- Judge lives in `evals/spike_q10_cross_tool/judge.py`. **Never**
  imported into `src/gnokee/`. AGENTS.md: gnokee never vendors an
  LLM.
- Env-var prefix `EVAL_*` (not `GNOKEE_*`) for cross-tool harness
  config — `EVAL_JUDGE_MODEL`, `EVAL_LONGMEMEVAL_PATH`, etc.
  Per-tool credentials stay under their native prefix
  (`OPENAI_API_KEY`, `MEM0_API_KEY` if Cloud is used, `ZEP_API_URL`).
- No vendor API keys committed. `.env` only.

### Adapter fairness rule

Each adapter exposes:

```python
class Adapter:
    name: str
    def ingest(self, episodes: Iterable[Episode]) -> None: ...
    def query(self, q: str, top_k: int) -> ResponsePayload: ...
```

`top_k` is a single harness constant applied uniformly across all 5
SUTs. No per-SUT retrieval tuning mid-run. Each SUT's retrieval
primitive is invoked at its primary entry point (gnokee
`gnokee_recall`, graphiti `client.search_()` RRF, mem0 `m.search`,
Zep `client.memory.search`, basic-memory MCP `search_notes`).

`ResponsePayload` is the raw, unstripped tool output. The judge
normalisation step (strip + truncate) lives in `judge.py`, applied
identically across SUTs.

### Sequencing

Per eval-spike-author scope-cut analysis, target timeline 5–7 days
(Q10-pre adds ~1 day, two-track methodology adds ~1 day on top of the
3–4 day base estimate).

Ingest cost dominates wall time. Concurrent `add_episode`
(`INGEST_CONCURRENCY = 4` in both shipped adapters) brings the
2-SUT × 100-Q × 47-session pilot from ~30 h to ~3.4 h. This frames
a stepwise ramp:

| Stage | Shape | Wall (2 SUTs) | LLM cost (rough) | Purpose |
|---|---|---|---|---|
| **A — sniff** | 10 Q × 10 sessions | ~10 min | ~$0.50 | Validate end-to-end + judge once `mem0`/`zep`/`basic-memory` adapters land |
| **B — micro-pilot** | 30 Q × 30 sessions | ~1 h | ~$3 | 5-SUT cross-tool table; first defensible ADR-0012 draft |
| **C — pilot** | 100 Q × full haystack | ~3.5 h | ~$10 | If pilot lands inside the ±5 pp zone around the ADOPT threshold, otherwise stop |
| **D — full** | 500 Q × full haystack | ~17 h | ~$50 | Only if pilot is inconclusive |

Stage A and B run on the wiring-validated path; C is the
ADOPT/REJECT decision; D only if needed.

1. Q10-pre micro-spike runs first → footnote number for the
   disclosure column. ✅ landed (`spike_q10_pre_embedder/`).
2. Harness + adapters smoke-tested. ✅ gnokee + graphiti-alone wired
   and smoked end-to-end (`run.py --smoke`).
3. Stage A sniff once `mem0`/`zep`/`basic-memory` land.
4. Stage B micro-pilot, all 5 SUTs, Track 1, double-run judge.
5. Layer Q7 + Q8 gnokee-side (skip-ingest); run live on the other 4.
6. Stage C pilot if Stage B is inconclusive vs the ADOPT bar.
7. Stage D full-500 only if Stage C is inconclusive.
8. Track 2 (iso-embedder): Mem0 reconfigured to bge-m3, repeat
   LongMemEval-S only at Stage C/D's chosen size. Q7 + Q8 +
   multilingual stay Track 1 only.
9. ADR-0012 + amend `docs/evals/methodology.md` (currently 52-line
   placeholder) + flip README "Status" gate.

### Open: synthesis step?

Wiring smokes against LongMemEval show graphiti-alone retrieving the
gold session (recall@5 = 100 %) yet judge-graded `wrong` because its
edge-fact summary shape (e.g. "Switched from Helix to Neovim") never
contains the answer's literal value (e.g. "25 postcards"). Mem0's
published 93.4 is end-to-end (memory retrieval **+ LLM synthesis**),
so a retrieval-only Q10 number is structurally lower.

**Decision needed before Stage A**: add a synthesis step
(`gpt-4o-mini-2024-07-18` consumes the SUT's `raw` payload + the
question, emits a 1–2-sentence answer; judge grades the synthesised
answer instead of `raw`). Not yet wired; tracked as a Q10 sub-decision
ADR-0012 will resolve. If we ship without synthesis, the disclosure
must explicitly say so to keep the comparison honest against Mem0's
end-to-end published number.

## Stage A results (2026-05-09)

10 LongMemEval-S pilot questions × 10-session haystack truncation,
top_k=5, Track 1, double-run judge.

### Original (run-id `stageA-v3`, morning)

| SUT | recall@5 (gold-bearing) | accuracy_strict | accuracy_lenient | mean ingest | mean query |
|---|---|---|---|---|---|
| `gnokee` v0.2.3 | 0 / 4 (0 %) | 0 / 10 (0 %) | 0 / 10 (0 %) | 120 s | 0.14 s |
| `graphiti-alone` | 3.5 / 4 (87.5 %) | 0 / 10 (0 %) | 1 / 10 (10 %) | 120 s | 0.16 s |
| `mem0` | 3 / 4 (75 %) | 1 / 10 (10 %) | 1 / 10 (10 %) | **22 s** | 0.18 s |

### Re-run after #38 (run-id `stageA_pathA`, evening)

| SUT | recall@5 (gold-bearing) | accuracy_strict | accuracy_lenient | mean ingest | mean query |
|---|---|---|---|---|---|
| `gnokee` (Path A + adapter axis fix) | **2 / 4 (50 %)** ↑ | 0 / 10 (0 %) | 0 / 10 (0 %) | 124 s | 0.13 s |
| `graphiti-alone` (unchanged) | 3.5 / 4 (87.5 %) | 0 / 10 (0 %) | 1 / 10 (10 %) | 120 s | 0.16 s |
| `mem0` (unchanged) | 3 / 4 (75 %) | 1 / 10 (10 %) | 1 / 10 (10 %) | **22 s** | 0.18 s |

Judge disagreement_rate = 0.0000 (perfect A/B agreement) on both
runs. Decision `JUDGED_DOUBLE_AGREED`.

### Read-out (post-#38)

1. **`gnokee` retrieves the right session 50 % of the time but
   answers none of them.** The recall@5 lift came from the Q10
   adapter axis fix (chat-time `asserted_at`); Path A's strict
   trigger (`fact_count == 0`) never fired because Graphiti DOES
   extract edges from conversation logs once stage 2b admits them.
   But the edge-fact triples are summaries of topical relations
   ("Eiffel Tower at Night and 1920s Paris Postcard are both part
   of the user's postcard collection") and drop the literal numbers
   gold answers reference (25 postcards, 2 doctor's appointments,
   38 study subjects). Same regime graphiti-alone occupies.
2. **`graphiti-alone` retrieves well, answers poorly.** Unchanged
   from the original Stage A — hybrid edge-search + MENTIONS
   Cypher backwalk surfaces the right sessions (87.5 % recall) but
   the synthesiser only sees edge-fact triples that strip
   literals. One partial on a chess-move probe where the edge fact
   happened to carry the move notation.
3. **`mem0` is the only SUT producing real answers.** 1 of 10
   strict (the `031748ae` knowledge-update on email count, against
   gold "31"; mem0 retrieved enough memory turns for the
   synthesiser to count). 5.5× faster ingest than gnokee /
   graphiti — single extraction LLM call per `add` vs Graphiti's
   3–5. Reinforces `#16 item 1` (lite-ingest mode) as the v0.3
   latency intervention.
4. **10-session truncation is structural.** 6 of 10 questions
   have gold sessions outside the first-10 window; recall@5 is
   `n/a` for those. Stage C (full haystacks) gives the real
   number — ADR-0012 verdict carries that, not Stage A.

### Implication for ADR-0012

The first-draft ADR-0012 attributed gnokee's 0/10 to "Graphiti
synthesises no `EntityEdge` facts." The #38 re-run proved that
wrong on two counts: stage 2b `filter_visible` was the actual
gating factor (rejected by axis-mismatch), and Graphiti DOES
extract edges from conversation turns once the stage 2b filter is
appeased. The real bottleneck is "edge-fact triples strip literal
answer values."

Path A is shipped as a defensive escape hatch but did not move
strict accuracy on this dataset. The architectural follow-ups now
sit at:
- `#16 item 1` (lite-ingest) — surfaces verbatim content alongside
  facts; addresses literal-stripping directly.
- A new v0.3 follow-up — hybrid emission of facts plus episode
  bodies, not as a fallback. Tracked separately from #38.

## What this does NOT cover

- Conversation-memory shape (LoCoMo) — overlaps LongMemEval-S; defer
  to a follow-up if the cross-tool number ever needs a second public
  benchmark.
- Tier-3 tools (Letta, mcp-memory-service, Cognee) — Q10.1 follow-up.
- Encrypted-body branch — orthogonal; v0.3 issue #22.
- Lite ingest / `extract=False` — orthogonal; v0.3 issue #16 item 1.
- p95 latency — eval-spike-author scope cut; p50 only this round.
- LongMemEval-S corpus generation from scratch — we pin the published
  fixture; if the upstream dataset is unavailable, the spike fails
  loudly rather than regenerating.
- ChatGPT memory / Claude Projects / Cursor memory comparisons — proprietary,
  not runnable.

## Known gnokee retrieval characteristics surfaced during adapter smoke

Wiring smoke against the shared 5-episode short-body corpus
(`evals/spike_q10_cross_tool/adapters/_smoke_corpus.py`) revealed
two gnokee-as-shipped behaviours Q10 main will measure honestly
under the LLM-judge protocol:

1. **Graphiti orphan-edge warnings on short bodies.** On 1–2-sentence
   episodes Graphiti's extraction LLM (gpt-4o-mini) emits
   `Target entity not found in nodes for edge relation: WORKS_AT /
   SWITCHED` warnings — node + edge come out of the same call and
   sometimes disagree. Effect: those episodes may not produce
   `EntityEdge` facts and so do not contribute to gnokee's
   `RecallResponse.facts`. LongMemEval-S sessions are multi-KB
   conversations rather than 1–2 sentences, so this concern is
   bounded; if it surfaces in the pilot we will note in ADR-0012.
2. **gnokee `recall()` is fact-only.** It does not include the
   `MENTIONS` Cypher backwalk that `graphiti-alone` uses to surface
   *entity-mentioning episodes* when no extracted fact exists. On the
   smoke corpus, `graphiti-alone` retrieves `smk_lumen` via the node
   walk where gnokee's recall does not (no extracted fact about
   "Lumen Health" cleared the extraction step). Q10 will report this
   delta directly; we do **not** patch `gnokee.recall()` to add the
   MENTIONS walk for the eval — that would be Q10-tuning. If the
   pattern recurs at LongMemEval-S scale, the finding goes into
   ADR-0012's recommendation (alongside #16 item 1's lite-ingest
   path).

## Cost & time

- **LLM**: ~$15–25 at 5 SUTs × LongMemEval-S 100-Q pilot + Q7 + Q8
  pass + judge double-run on `gpt-4o-mini-2024-07-18`. Full 500 Q
  doubles to ~$30–50 if the pilot is inconclusive. + escalation
  budget ~$5 for `gpt-4o` re-judge on disagreed IDs.
- **OpenAI embed** (Mem0 Track 1): ~$1 across LongMemEval-S 500 Q.
- **Wall**: 5–7 days end-to-end including ADR-0012 write-up.

## Run

```bash
# Q10-pre footnote first
cd evals/spike_q10_pre_embedder
set -a && source ../../.env && set +a
../../.venv/bin/python run.py

# Q10 main
cd ../spike_q10_cross_tool
docker compose --profile embeddings --project-directory ../.. up -d gnokee-postgres gnokee-neo4j tei
../../.venv/bin/python run.py --pilot   # 100 Q, all 5 SUTs, Track 1
../../.venv/bin/python judge.py --double-run
../../.venv/bin/python run.py --full    # full 500 Q only if pilot inconclusive
../../.venv/bin/python run.py --track 2 # Mem0 reconfigured to bge-m3
```

## File layout

```
evals/spike_q10_cross_tool/
├── README.md                      ← this file
├── queries.yaml                   ← LongMemEval-S 100-Q pilot subset (ids: lme_*)
├── requirements.txt
├── judge_prompt.txt               ← committed literal judge prompt
├── adapters/
│   ├── __init__.py
│   ├── gnokee_adapter.py
│   ├── graphiti_adapter.py
│   ├── mem0_adapter.py
│   ├── zep_adapter.py
│   └── basic_memory_adapter.py
├── corpus/                        ← gitignored if large; SHA pinned in README
│   └── longmemeval_s_500.jsonl
├── gnokee_side/
│   ├── q7_queries.yaml            ← copy or symlink of spike_q7's
│   └── q8_queries.yaml            ← copy or symlink of spike_q8's
├── run.py                         ← orchestrator
├── judge.py                       ← gpt-4o-mini judge, double-run, escalation
└── results/                       ← gitignored
    ├── pilot/<utc>.json
    ├── full/<utc>.json
    └── track2/<utc>.json
```
