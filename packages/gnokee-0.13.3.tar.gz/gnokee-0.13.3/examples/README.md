# gnokee examples

Runnable consumer recipes. Pair with
[`../docs/integration_patterns.md`](../docs/integration_patterns.md)
(decision contract) and
[`../docs/integration/consumer-patterns.md`](../docs/integration/consumer-patterns.md)
(body-render shapes).

## Prerequisites

All examples assume:

- Python 3.10+ in a venv.
- `pip install -e ".[mcp,dev]"` from the repo root (or a published
  `pip install gnokee` and your own venv).
- `make up` for the compose stack (Postgres + Neo4j + TEI). Some
  examples don't need TEI; noted per example.
- `cp .env.example .env` and an `GNOKEE_OPENAI_API_KEY` set for
  examples that exercise full ingest.
- `make migrate` once on a fresh stack.

Each script is self-contained — it builds the gnokee `Pipeline`
objects in `main()` rather than referring to a project-shared
fixture.

## Inventory

| File | What it shows | Compose stack needed | LLM key needed |
|---|---|---|---|
| [`01_quickstart_demo.py`](01_quickstart_demo.py) | Smallest working ingest + recall round-trip with contradictions. | yes (full) | yes |
| [`02_lite_mode_with_outbox.py`](02_lite_mode_with_outbox.py) | Outbox table + drainer for high-cadence sources; lite-mode ingest; deferred-extraction backfill. | yes (full) | yes (for backfill) |
| [`03_mcp_clients/claude_desktop.md`](03_mcp_clients/claude_desktop.md) | `claude_desktop_config.json` snippet to wire gnokee MCP into Claude Desktop. | yes | yes |
| [`03_mcp_clients/claude_code.md`](03_mcp_clients/claude_code.md) | `.mcp.json` snippet for Claude Code. | yes | yes |
| [`03_mcp_clients/cursor.md`](03_mcp_clients/cursor.md) | Cursor MCP config snippet. | yes | yes |
| [`04_encrypted_body.py`](04_encrypted_body.py) | Consumer-side libsodium SecretBox encryption; encrypted-body ingest; recall with `encrypted_bodies[]`; consumer-side decrypt. | yes (full) | yes |
| [`05_consumer_render_clinical.py`](05_consumer_render_clinical.py) | Lab + medication body-render shapes; ingest; `gnokee_lab_query` (latest / history / abnormal); `gnokee_med_query` (active / switches). | yes (full) | yes |

## Running

```bash
# from repo root
source .venv/bin/activate
make up              # bring up the compose stack
make migrate         # one-time

# pick an example
python examples/01_quickstart_demo.py
```

Each script logs to stdout. Stop the compose stack with `make down`
when you're done.

## Patterns these examples don't cover

- **Production deployment.** See
  [`../docs/deploy.md`](../docs/deploy.md).
- **MCP server hosted in production.** Examples use the local
  compose stack; production wraps the MCP stdio process in a
  supervisor (systemd / launchd / k8s).
- **Multi-tenant isolation under load.** Examples use a single
  `tenant_id`. For multi-tenant patterns see
  [`../docs/deploy.md`](../docs/deploy.md) §"RLS GUC pattern".

## Contributing examples

If you have a working integration that demonstrates a new pattern,
open a PR. Keep examples self-contained, single-file when possible,
and runnable against a clean compose stack.
