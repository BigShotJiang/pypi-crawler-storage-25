# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.13.3] — 2026-05-23

v0.13.3 patch — eval-delta gate unblocked on the self-hosted runner +
graphiti-core 0.29.1 precision/guardrail uplift. Two orthogonal
follow-ups on top of v0.13.2:

### Fixed

- **`fix(evals)`** Eval-delta gate spike runners crashed on
  `_require("GNOKEE_NEO4J_URI")` inside `amain()` *before*
  `handle_baseline()`'s `_scaffolding: true` sentinel ever fired,
  so the gate died with `missing required env var: GNOKEE_NEO4J_URI`
  and no spike actually ran. Lifted the sentinel guard ahead of
  `asyncio.run(amain())` in all five in-scope runners (Q1/Q3/Q4/Q7/Q8)
  via a new `peek_scaffolding(baseline_path) -> bool` helper in
  `evals/_eval_delta.py`. Pure JSON read, no env touch — short-circuits
  cleanly before any Postgres / Neo4j / TEI / LLM contact. Closes
  #320. (#321)

- **`fix(ci)`** eval-delta workflow now skips the Compose stack
  bring-up step when every baseline is still `_scaffolding: true`
  (saves the 5-8 min TEI cold-start window per PR while the v0.3
  ramp continues). Resumes automatically once a maintainer captures
  a real baseline with `--capture-baseline`. Permission narrowed
  `pull-requests: write` → `read` (Job summary goes to
  `$GITHUB_STEP_SUMMARY`, not a PR comment — unused write surface
  was a security smell). (#321)

### Changed

- **`chore(deps)`** Bumped `graphiti-core` pin floor from
  `>=0.29,<0.30` to `>=0.29.1,<0.30`. Upstream v0.29.1 is a pure
  precision/guardrail release with no public API drift —
  `client.search_()`, `SearchFilters`, `EpisodicNode`,
  `EntityNode.name_embedding`, and `EntityEdge.fact_embedding` are
  unchanged. The release adds three-layer attribute-hallucination
  guards, a `cap_string_attributes` structural backstop
  (250-char default, configurable via `GRAPHITI_ATTRIBUTE_MAX_LENGTH`),
  combined-extraction noise-class filtering (-40% to -93% on six
  targeted classes, fact-text Jaccard 0.341 → 0.381 on Locomo
  500-example eval), and saga episode-time watermarks
  (`SagaNode.last_summarized_episode_valid_at`). gnokee defines no
  custom Pydantic `EntityNode`/`EntityEdge` subclasses, so the
  attribute cap requires no per-field `max_length` overrides; the
  250-char default is fine for gnokee's corpus
  (`EpisodicNode.content` is not capped, `EntityEdge.fact` is
  required-field carve-out). No schema migration required —
  `cap_string_attributes` is a write-path guard, not retroactive.
  No gnokee code changes; venv re-pin only. Closes #317. (#322)

- **`chore(deps)`** Added `tiktoken>=0.7` to the `[dev]` extra. The
  Q3 token-efficiency spike imports `tiktoken` at module-load time
  (the `cl100k_base` encoder is the portable proxy for "what an
  MCP-attached LLM will see"), so the eval-delta gate's module
  import path needs it even when the scaffolding sentinel
  short-circuits the run. Previously listed in
  `evals/spike_q3_token_efficiency/requirements.txt` only;
  `pip install -e .[mcp,dev]` did not pull it. (#321)

## [0.13.2] — 2026-05-23

v0.13.2 patch — supply-chain hardening + eval-delta wiring +
tenant-filter pushdown spike scaffold. Cut a few hours after
v0.13.1; small surface, three orthogonal pieces:

### Added

- **`feat(ci)`** Cosign keyless signing + CycloneDX SBOM attestation
  on every published GHCR image (paid down the v0.13.1 defer noted
  in the v0.13.0 release notes). Signatures bind to the image
  **digest** from the Push step (`steps.push.outputs.digest`), not
  the tag — the `:X.Y` minor float is re-pointed on each patch and
  will not match an older signature. Verify a release with:

  ```
  cosign verify \
    --certificate-identity-regexp \
      "^https://github\.com/omurlabs/gnokee/\.github/workflows/ghcr-publish\.yml@refs/tags/v[0-9.]+$" \
    --certificate-oidc-issuer https://token.actions.githubusercontent.com \
    ghcr.io/omurlabs/gnokee:0.13.2
  ```

  SBOM attestation verifies the same digest via
  `cosign verify-attestation --type cyclonedx` with the same identity
  flags. `sigstore/cosign-installer` pinned to commit SHA
  `6f9f17788090df1f26f669e9d70d6ae9567deba6` (v4.1.2, 2026-05-07);
  Trivy reused for CycloneDX SBOM generation (one scanner, fewer
  action pins). Self-hosted runner requires outbound HTTPS to
  `fulcio.sigstore.dev` and `rekor.sigstore.dev`. (#313)

- **`feat(evals)`** `--check-baseline` / `--capture-baseline` now
  wired on Q3 (token efficiency), Q4 (contradiction), Q7 (lab
  results), Q8 (med supersession) — Q1 was the v0.13.0 reference
  impl, the other four were `TODO(v0.13.x)` lines in the Makefile.
  `make eval-delta` invokes all five with `--check-baseline`;
  baselines remain `_scaffolding: true` until a maintainer captures
  real values against a v0.13.x-stable stack. Closes #312. (#314)

- **`feat(evals)`** Q44 spike scaffold —
  `evals/spike_q44_tenant_filter_pushdown/` lands the five-path
  benchmark harness (3 pgvector + 2 Neo4j) that **gates** #303
  implementation. Both postgres-pgvector-specialist and
  neo4j-ops-specialist returned YELLOW + spike-first on #303 in the
  2026-05-23 scope-verdict sweep; the original "~99% candidates
  discarded post-hoc" premise was incorrect (Stage 2a already
  narrows to `candidate_pool=500` UUIDs), and Neo4j 5 Community has
  no native predicate pushdown into vector indexes. #303 moves to
  v0.14.0 conditional on Q44 numbers. Closes #315, gates #303.
  (#316)

### Fixed

- **`docs(ci)`** `docs/ci/self-hosted-runner.md` + comments in
  `tests/integration/test_mcp_streamable_http.py` no longer claim
  the runner host runs Hetzner Ubuntu — the actual runner host is
  an Unraid box on the maintainer's home network (labels
  `[self-hosted, linux, x64]` + `[unraid, docker]`). PR #306's
  original wording was wrong and propagated through several
  agent-authored references; corrected on sight per a maintainer
  catch.

## [0.13.1] — 2026-05-23

v0.13.1 patch — image-publish fix + post-tag CI hardening. Bundles
the Dockerfile + workflow corrections that surfaced minutes after the
v0.13.0 tag push:

- **`fix(docker)`** Dockerfile now COPYs `static/` into the build
  stage. Without it hatchling raised `FileNotFoundError: Forced
  include not found: /build/static/.well-known/gnokee.txt` (ADR-0015
  / issue #74 `.well-known/` manifests). v0.13.0's PyPI wheel
  published fine because pypi-publish.yml builds via `python -m
  build` against the full repo tree; only the Dockerfile context
  needed `static/`.
- **`fix(ci)`** `aquasecurity/trivy-action@0.28.0` → `@v0.36.0`
  (missing `v` prefix on the original pin made the action
  unresolvable; bumped to latest stable while fixing).
- **`fix(lint)`** Drop unused `asyncio` import in
  `tests/integration/test_mcp_streamable_http.py`
  (pre-existing F401 from v0.12.2 commit `0b06e1f`, surfaced in CI on
  the eval-delta scaffolding commit). `ruff format` collapse on
  `ForgetReceiptDetail.cascaded_episode_uuids` description.

**First published container image lands here**, not in v0.13.0:
`ghcr.io/omurlabs/gnokee:0.13.1` + `:0.13`. v0.13.0 remains PyPI-only.

## [0.13.0] — 2026-05-23

v0.13.0 minor — "tenant-aware retrieval scaffolding + first published
image". Cut against the 2026-05-22 specialist scope-verdict sweep
(docs/backlog.md §Specialist scope-verdict sweep — 2026-05-22). The
sweep's GREEN + KILL + trivial verdicts shipped autonomously; YELLOW
items requiring design decisions (#303-pg pgvector `iterative_scan`
ADR, #71 competitive landscape doc) carry to v0.13.1 / later.

Highlights:

- First published container image to `ghcr.io/omurlabs/gnokee`
  (`:0.13.0` + `:0.13`; `:latest` deliberately unset). Trivy SARIF
  on the publish path. Cosign + SBOM deferred to v0.13.1.
- `ForgetReceipt` response-shape parity with the v0.12.0 input
  rename — `episode_id` / `deepest_episode_id` / `cascaded_episode_ids`
  land as additive aliases; legacy `*_uuid` keys drop in v0.13.1.
- Eval-delta regression gate scaffolding (#305) — shared helper +
  `--check-baseline` / `--capture-baseline` flags + placeholder
  baselines. Q1 graphiti wired as reference impl; Q3/Q4/Q7/Q8
  wiring tracked under #312. CI workflow runs `continue-on-error:
  true` until baselines pin.
- ADR-0005 90-day re-check log inline (closes the GH-watch issue
  #91). Plan-doc cleanup for the `_tenant_guard` decorator design
  retired in ADR-0030 amendment 2026-05-22 §D.

### Added

- **Eval-delta gate scaffolding (#305).** Per docs/backlog.md
  §Specialist scope-verdict sweep 2026-05-22 (`eval-spike-author` +
  `ci-engineer` YELLOW, v0.13.0 minor). New shared helper
  `evals/_eval_delta.py` (`add_baseline_args` / `handle_baseline` /
  `check_baseline` / `capture_baseline` / `harness_hash`). Per-row
  PASS→FAIL and pp-drop > 5 gates per `docs/eval_delta_gate.md` §2.
  Two flags: `--check-baseline` (read + gate) and `--capture-baseline`
  (maintainer-only re-pin gesture). Placeholder baselines for all
  five in-scope spikes (Q1/Q3/Q4/Q7/Q8) under `evals/baselines/` with
  `"_scaffolding": true` sentinel — the helper detects the sentinel
  and exits `SKIPPING` until a maintainer captures real baselines
  against a known-good v0.13.0 stack. Q1 graphiti wired as the
  reference impl (`evals/spike_q1_graphiti/run.py`); Q3/Q4/Q7/Q8
  wiring is a v0.13.x follow-up. New CI workflow
  `.github/workflows/eval-delta.yml` runs `make eval-delta` on PRs
  that touch the hot-path glob, `continue-on-error: true` until
  baselines pin. `docs/eval_delta_gate.md` updated with the
  scaffolding state, the maintainer capture gesture (§4a), and the
  DinD constraint that rules out the `services:` keyword on the
  self-hosted runner.

- **First published container image — `ghcr.io/omurlabs/gnokee`.**
  Per docs/backlog.md §Specialist scope-verdict sweep 2026-05-22
  (`ci-engineer` YELLOW, v0.13.0 minor). New `.github/workflows/ghcr-publish.yml`
  + multi-stage `Dockerfile` (python:3.12-slim base, non-root `gnokee`
  user, no baked `GNOKEE_*` env defaults — default mode is stdio, the
  HTTP-safety gate from ADR-0030 §Library-mode opt-out enforces auth
  at runtime). Image tags: `:X.Y.Z` (precise) + `:X.Y` (minor float).
  `:latest` deliberately unset. Trivy scans the image before push;
  CRITICAL CVEs hard-stop the publish. SARIF uploads to the Security
  tab (best-effort, upload flake does not gate the publish). Cosign
  signing + SBOM attestation deferred to v0.13.1. `docs/deployment-mcp-http.md`
  re-instates the GHCR snippet that v0.12.2 (PR `fa07477`) stripped.

- **`ForgetReceipt` response-shape parity with the v0.12.0 input rename.**
  Per docs/backlog.md §Specialist scope-verdict sweep 2026-05-22
  (`gnokee-mcp-tool-designer` GREEN, v0.13.0 minor): three additive
  alias keys land on the forget envelope:
  - `episode_id` (alongside legacy `episode_uuid`)
  - `deepest_episode_id` (alongside legacy `deepest_episode_uuid`)
  - `cascaded_episode_ids` on `ForgetReceiptDetail` (alongside legacy
    `cascaded_episode_uuids`)

  The MCP wire envelope encodes the new `*_id` keys to ADR-0027
  short-ID form (`ep_<n>`) — matches the encoding pattern already used
  by `gnokee_history_of` / `gnokee_recall` / `gnokee_query`. The
  legacy `*_uuid` keys keep their raw-UUID payload for one release of
  consumer-side compatibility; they drop in v0.13.1. A
  `@model_validator(mode="before")` cross-fills the alias pair on
  construction so legacy `forget_audit.receipt` JSONB rows written
  under v0.12.x rehydrate without a Postgres migration. Mismatched
  alias pairs (both keys passed with divergent values) raise
  `ValidationError` rather than silently picking one. Closes the
  asymmetry note flagged in v0.12.2 CHANGELOG §Changed.

## [0.12.2] — 2026-05-22

v0.12.2 patch — specialist scope-verdict hardening (2026-05-22). Three
HIGH-severity security findings fixed (alg-confusion, contextvar leak
risk, refuse-startup gate) + /readyz error-envelope strip + bind-address
knobs + docs sweep. No behavior change for stdio / library-mode
callers; production HTTP deploys gain stricter construction-time + boot-
time guards. Closes Task #1-#11 of the v0.12.2 patch backlog.

### Changed

- **`gnokee_forget_episode` MCP param renamed `episode_uuid` →
  `episode_id` (#233).** Breaking MCP-schema change shipped in v0.12.0;
  documented here for completeness. **Response-envelope asymmetry note:**
  the *input parameter* is now `episode_id`, but the response envelope
  emitted by `ForgetReceipt.model_dump` still uses the key
  `episode_uuid`. The response-shape sweep is deferred to a follow-up
  ticket (planned for v0.13.x). Consumers reading the response should
  continue keying on `episode_uuid`; consumers passing the input
  should switch to `episode_id`. No behavior change beyond the schema.

### Security

- **`BearerJWTBackend` alg-confusion guards (ADR-0030 amendment 2026-05-22).**
  Construction-time validation in `src/gnokee/mcp/auth.py:__post_init__`
  refuses three attack/footgun cases: (1) `algorithm` outside the
  allowlist — `none` and unaudited algorithms blocked; (2) asymmetric
  algorithm (`RS*`/`ES*`/`PS*`) paired with a non-PEM `public_key`
  (operator footgun); (3) symmetric algorithm (`HS*`) paired with a
  PEM-encoded key — the **classic alg-confusion attack** where pyjwt
  would use the public key as the HMAC shared secret, letting anyone
  who reads the public key mint valid tokens. HMAC algorithms also
  require explicit `_allow_hmac=True`; production deploys MUST use an
  asymmetric algorithm because HMAC requires gnokee to hold the same
  secret the issuer signs with, contradicting AGENTS.md "do not hold
  keys".
- **`MCPTokenVerifier.verify_token` defensive contextvar reset.**
  Clears any stale `_current_principal` binding at the top of
  `verify_token` before invoking the backend. Starlette spawns a fresh
  task per request in current versions so the contextvar starts empty
  in practice — but if a future upstream change pools tasks (or
  invokes the verifier from a context that survived a previous
  request), the explicit `.set(None)` prevents the previous request's
  principal from leaking into the next request.
- **`_assert_http_auth_safety` startup gate.** Refuses to start with
  `ValueError` when `GNOKEE_MCP_HTTP=1` is set without
  `GNOKEE_MCP_AUTH_KIND` — library-mode (`auth=None`) over a network
  transport would expose every tenant's data on the wire. Escape
  hatch: `GNOKEE_MCP_HTTP_ALLOW_UNAUTHENTICATED={1,true,yes}` for
  behind-a-trusted-reverse-proxy deploys where TLS + auth terminate
  upstream; emits a WARNING log line so the unauthenticated posture
  is audited at boot.

### Added

- **`GNOKEE_MCP_HOST` + `GNOKEE_MCP_PORT` env vars.** Streamable-http
  bind address knobs. Default `127.0.0.1:8000` (loopback-only —
  reverse proxy on same host terminates TLS + auth). Operators wiring
  `0.0.0.0` MUST also set `GNOKEE_MCP_AUTH_KIND` or the startup gate
  refuses. Threaded through `build_server(host=..., port=...)` into
  `FastMCP(host=..., port=...)`.
- **`docs/ci/self-hosted-runner.md`.** Operator runbook for the
  Hetzner self-hosted GitHub Actions runner (PR #306). Pins the
  `RLIMIT_NOFILE>=65536` requirement for the 100-session pool-counter
  smoke test (`tests/integration/test_mcp_streamable_http.py`); stock
  Ubuntu images ship with `LimitNOFILE=1024` which exhausts mid-test
  and produces false-negative fd-leak reports.
- **`tests/integration/test_mcp_streamable_http.py` scaffold.** Stub
  for issue #245 Step 4 100-session smoke test. Pins the acceptance
  shape: `pool.get_idle_size() == pool.get_size()` post-teardown,
  NOT OS-level fd count delta (unreliable on macOS socket recycling).
  Currently skips pending runner ulimit verification + live-stack
  fixture wiring.
- **Q3 v0.10 envelope re-run harness (#207, eval-only).**
  `evals/spike_q3_token_efficiency/run_output_shape_fact.py` drives the
  production `gnokee.query.gnokee_query` orchestrator end-to-end with
  `output_shape="fact"` against the Q1 corpus. Owns its corpus state —
  re-ingests Q1 through `ingest_episode(extract=True)` under
  `tenant_id="q3-output-shape-fact"` so `fact_revision` rows are seeded
  in the same harness run. Idempotent on `(tenant_id, our_id)` for
  re-runs. Dumps `results/<utc-stamp>-output-shape-fact.json` with a
  `delta_vs_baseline` field comparing the new median against the
  125-token Q3-mixed baseline. ADR-0013 v0.10 Amendment footer updated
  to reference the harness; operator runs the harness to fill in the
  actual median (pending — requires a live gnokee stack + LLM endpoint).

## [0.12.1] — 2026-05-21

v0.12.1 patch — cross-lingual ergonomics + embedder boot probe. Pure
additive; existing single-knob / no-probe deploys behave identically to
v0.12.0. Closes #235 + #238.

### Added

- **Boot-time embedder probe (#238).** New `GNOKEE_EMBED_PROBE` env
  flag. When `true`, `build_app` embeds a fixed throwaway string
  against the configured embedder and asserts `len(result) ==
  EMBED_DIM` before any ingest accepts traffic. Catches wrong-model-
  behind-URL at process start rather than first-ingest. Default off so
  existing deploys are bit-for-bit unchanged. The per-vector dim guard
  at `embeddings.py:115` stays as belt+braces. Cold-TEI race (model
  still loading) surfaces as `EmbeddingsUnavailable` — pair with
  `depends_on: condition: service_healthy` or a startup retry loop in
  production.
- **Graphiti extraction-model split (#235).** New
  `GNOKEE_GRAPHITI_LLM_MODEL` env var drives Graphiti's entity/edge
  extraction (`LLMConfig.model`) independently of
  `GNOKEE_LLM_MODEL`. Defaults to `GNOKEE_LLM_MODEL` via
  `Settings.model_validator(mode="after")` so single-knob deploys are
  unchanged. Operators with cross-lingual tenants (Q2 Hebrew F4 failure
  class) point Graphiti at a stronger model (e.g. `gpt-4o`) while
  keeping the cheap default on the contradiction classifier.
- **Per-tenant extraction-prompt override (#235).** New
  `GNOKEE_GRAPHITI_EXTRACTION_INSTRUCTIONS` env var threaded verbatim
  into `graphiti.add_episode(custom_extraction_instructions=...)` —
  graphiti-core's first-class public hook. Typical use: preserve
  source-language entity names for cross-lingual tenants. Effective
  only when paired with an instruction-following extractor (the split
  above). Also threaded into `maintenance.run_deferred_extraction`
  via a new optional kwarg.
- **`docs/deploy.md` § Model selection (split knobs).** Documents the
  three new env vars, the cross-lingual recommended pairing, and the
  back-compat invariant.
- **ADR-0001 amendment.** "Amendment (2026-05-21, v0.12.1) — cross-
  lingual ergonomics knobs" paragraph appended.

### Changed

- `bootstrap.build_app` now passes
  `settings.graphiti_llm_model` (resolved by `Settings.model_validator`
  to `llm_model` when unset) to `LLMConfig.model` instead of
  `settings.llm_model` directly. No behaviour change for single-knob
  deploys.
- `GraphitiStore.add_episode` (storage/graph.py) gains optional
  `custom_extraction_instructions: str | None = None` kwarg passed
  through to graphiti-core. Default `None` = upstream default.

## [0.12.0] — 2026-05-20

v0.12 ships the MCP-revival bundle: gnokee MCP as a standalone product
surface, consumer-agnostic. Driver = decision 2026-05-20 to make gnokee
MCP production-ready independently of any specific upstream consumer.
Closes four MCP-cluster issues blocked behind the same v0.1
unauthenticated ceiling.

Breaking changes ship in a single minor — see **Changed** below.

### Added

- **Pluggable MCP authentication ([ADR-0030](docs/adr/0030-mcp-auth-surface.md);
  #244).** New `gnokee.mcp.auth` module exposes `AuthBackend` Protocol +
  `Principal` frozen dataclass + `AuthError(401|403)` + `BearerJWTBackend`
  reference impl (pyjwt-backed, HS256/RS256/ES256). `build_server` grows
  `auth=None` keyword arg; production deploys pass an `AuthBackend` impl
  + OAuth Protected-Resource metadata URLs. **Library-mode opt-out
  invariant pinned by `tests/unit/test_mcp_auth.py::test_library_mode_no_principal_is_noop`** —
  breaking it requires an ADR-0030 amendment. gnokee NEVER issues tokens
  (AGENTS.md "do not host identity / do not host keys").
- **Per-tool tenant guard.** Every `gnokee_*` MCP tool calls
  `enforce_tenant_authority(tenant_id)` at the top of its body. No-op
  when no principal is bound (library mode); raises `AuthError(403)`
  before the tool body runs when the requested `tenant_id` is not in
  `Principal.allowed_tenants`. Audit log emits `subject` +
  `rejected_tenant_id` only (never `claims`).
- **Streamable-http production-readiness (#245).** `/healthz` (liveness)
  + `/readyz` (Postgres + Neo4j connectivity) endpoints attached
  outside the auth middleware. New env-var knobs: `GNOKEE_MCP_AUTH_KIND`,
  `GNOKEE_MCP_JWT_PUBKEY_PATH`, `GNOKEE_MCP_JWT_ALG`,
  `GNOKEE_MCP_JWT_AUDIENCE`, `GNOKEE_MCP_JWT_ISSUER`,
  `GNOKEE_MCP_JWT_TENANT_CLAIM`, `GNOKEE_MCP_AUTH_ISSUER_URL`,
  `GNOKEE_MCP_AUTH_RESOURCE_URL`, `GNOKEE_MCP_AUTH_REQUIRED_SCOPES`.
  README `dev only` caveat dropped.
- **Tenant-boundary threat model (#246).** New
  [`docs/security/multi-tenant.md`](docs/security/multi-tenant.md) with
  the canonical statement of the boundary + the 2026-05-20 audit
  findings (no LEAK; 4 NOTEs documented).
- **Deployment guide.** New
  [`docs/deployment-mcp-http.md`](docs/deployment-mcp-http.md) with
  TLS-at-reverse-proxy posture, healthz/readyz expectations, and
  back-pressure semantics.

### Changed

- **BREAKING — `gnokee_forget_episode.episode_uuid` → `episode_id` (#233).**
  MCP tool input parameter renamed for naming-convention consistency
  with `gnokee_history_of.episode_id` (both accept the ADR-0027 short-ID
  form or a full UUID). Response-envelope key `episode_uuid` is NOT
  renamed in this release — that's a separate sweep tracked separately.
  Update MCP client configs that hardcode the input param name.

### Dependencies

- `pyjwt[crypto]>=2.9,<3` added under the `[mcp]` extra. Library users
  who do not install `gnokee[mcp]` are unaffected.

## [0.11.3] — 2026-05-19

v0.11.3 patch cycle — `forget_episode` top-level re-export. Pure DX
cleanup driven by [omur#598](https://github.com/omurlabs/omur/pull/598)
("GnokeeMemoryProvider via Marrow HTTP bridge", Phase C, merged
2026-05-19T20:45Z) shipping against the existing v0.11 API. No
behavioural change.

This release supersedes the previously-drafted v0.12.0 plan
(`docs/plans/2026-05-19-v0.12-marrow-bridge.md`). Phase C inlined
`gnokee.forget.forget_episode` (via module path) and
`gnokee.history.history_of` (Phase A.2 singular `episode_id` arity)
into the Marrow routes, removing the need for both the new
`gnokee.get_episodes` / `EpisodeRecord` surface ([ADR-0029](docs/adr/0029-episode-record-provenance-api.md)
now **Rejected**) and the `MemoryProvider.forget` Protocol contract
reconcile. The [ADR-0026 amendment 2026-05-19](docs/adr/0026-forget-pipeline.md#amendment-2026-05-19--public-forget-surface-is-episode-level-and-tenant-level-only)
stays in force — public forget surface remains episode + tenant only.

### Added

- **`gnokee.forget_episode` top-level re-export.** `from gnokee import
  forget_episode` now resolves to `gnokee.forget.forget_episode`
  (identity, not a wrapper). Existing `from gnokee.forget import
  forget_episode` continues to work unchanged — module-path import is
  what omur#598 actually uses. New `tests/unit/test_public_surface.py`
  pins both the identity check and the broader invariant that every
  name in `gnokee.__all__` is bound on the module.

## [0.11.2] — 2026-05-19

v0.11.2 patch cycle — Stage 4 retrieval correctness. Two retrieval
fixes that landed post-v0.11.1 tag: the Stage 4 attribution-filter
fix (#95) and the fact-cosine floor knob that closes the grader-
artifact regression the first fix surfaced (#290). No public API
change; one additive MCP knob (`gnokee_recall.fact_cosine_floor`,
default `None`).

### Fixed

- **Stage 4 fact attribution scoped to `ep.uuid IN r.episodes`
  (#95; PR #291).** `RecallPipeline.fetch_facts_for_episodes` Cypher
  walks `(:Episodic)-[:MENTIONS]->(:Entity)-[r:RELATES_TO]-(:Entity)`,
  so every fact about a shared `Entity` hub (the corpus subject) was
  attributed to every episode that mentioned it. Stage 6's 134-token
  budget then emitted the rank-1 episode's polluted fact list and
  crowded out authoritative facts from rank 2+. The added
  `AND ep.uuid IN r.episodes` clause restricts to facts each episode
  genuinely produced per Graphiti's attribution list. Q-X.1 went
  9/10 → 10/10 on the Q41 spike; rank-1 fact rows dropped from 11
  polluted → 2 authoritative on `spike_q41_x1`. ADR-0019 amended
  with the root-cause investigation + grader-artifact regression
  on Q-X.3 (handed off to #290). New unit test asserts the
  attribution filter is in the Cypher; new diagnostic harness
  `evals/spike_q41_refusal/diag_p_x1_03.py` dumps per-lane signals
  (cosine + BM25 ranks + RRF + raw fact_rows) so the bug stays
  reproducible.

### Added

- **`fact_cosine_floor` retrieval knob (#290; PR #292).** Stage 4
  Cypher now projects `vector.similarity.cosine(r.fact_embedding,
  $q_vec) AS fact_cosine` when callers pass `query_vector`;
  `FactRow.fact_cosine` carries the value. `RecallPipeline.recall()`
  + module-level `recall()` gain `fact_cosine_floor: float | None =
  None`; fact rows below the floor are pruned before the token-budget
  loop. Episode-rank order preserved (relevance prune, not rerank).
  `None` cosine (older edges without `fact_embedding`) is **kept**,
  not zeroed — three-layer null-safety: Cypher branches on
  `query_vector`, Python coerces `None`, filter passes through.
  `FactStatement.fact_cosine` surfaced via existing
  `include_cosine_top1` knob; `gnokee_recall` MCP tool gains matching
  `fact_cosine_floor: float | None` (Pydantic `ge=0.0, le=1.0`).
  Default stays `None` — floor value is corpus-shape sensitive
  (bge-m3 cross-domain cosines vary with subject/genre); publishable
  per call / per harness, not a baked-in heuristic. Q41 spike with
  `GNOKEE_SPIKE_FACT_COSINE_FLOOR=0.76` → Q-X.3 9/10 → 10/10, no
  regression elsewhere. ADR-0019 amended with Issue #290 verdict.

## [0.11.1] — 2026-05-18

v0.11.1 patch cycle — "FORCE-RLS readiness + dead-code mop-up". Closes
the six P1+P2 items the v0.11.0 specialist sweep left on the table.
No public API change.

### Fixed

- **RLS GUC sweep + `set_config(..., is_local=true)` transaction wrap
  (#220 follow-up + PR #278 bug fix; PR #283).**
  `set_config(setting, value, true)` is transaction-local — outside an
  explicit transaction it resets before the next statement, so any
  follow-up SELECT runs without the `app.current_tenant` GUC set. On
  the gnokee owner role (RLS-bypass) the SELECT still returns rows by
  predicate, but the moment a deployment swaps to a `NOBYPASSRLS` role
  or enables `FORCE ROW LEVEL SECURITY`, every read silently empties
  — exactly the failure mode #220 was meant to guard against. PR #278
  had shipped this pattern unwrapped on `src/gnokee/storage/vector.py`
  + `src/gnokee/fact_history.py`; the regression was invisible because
  CI only runs `tests/unit`. PR #283 wraps every `pool.acquire` GUC
  site in `conn.transaction()`:
    * `src/gnokee/storage/vector.py` (`search_embeddings`,
      `search_embeddings_with_scores`, `search_bm25`).
    * `src/gnokee/fact_history.py` (fact-history pipeline).
    * `src/gnokee/storage/metadata.py` (`filter_visible`, `get`,
      `get_by_our_id`, `list_episodes_for_tenant`,
      `latest_write_clock`, `chain_head_at`, `history_of`).
    * `src/gnokee/storage/contradictions.py` (`write`,
      `lookup_counterparts`).
    * `src/gnokee/storage/lab.py` (`latest`, `history`, `aggregate`,
      `abnormal`).
    * `src/gnokee/wiki_export.py` (past-`as_of` fact-revision rewrite
      branch).
  `gnokee_maintenance.ingest_audit` deliberately excluded — schema is
  RLS-excluded by design (migration 0023 header).
  `tests/integration/test_rls_guc_read_paths.py` extended with
  `NOBYPASSRLS` probe coverage for every new path (probe role
  authenticates with `NOBYPASSRLS`; pre-seed under owner role; assert
  the read returns the seeded row through the probe pool — fires if
  the GUC is missing).

### Changed

- **`OpenAIRerankerClient` removed from bootstrap (#240; PR #284).**
  gnokee owns retrieval per ADR-0004 — no Graphiti search path is ever
  invoked from gnokee, so the `cross_encoder` wiring was dead.
  Graphiti still instantiates its own default reranker internally
  when the kwarg is omitted, but it stays dormant.
- **`gnokee_forget_episode` `forget_neo4j_partial` hint rewritten
  (#234; PR #285).** Previous hint referenced
  `gnokee.maintenance.resume_forget(...)` — a Python library call
  with no MCP exposure. New hint surfaces both operator surfaces:
  CLI (`gnokee forget resume --audit-id <id>`, with the audit_id
  pre-filled from the exception) and Python signature for operators
  running maintenance scripts. Explicitly states no MCP tool re-runs
  the Neo4j sweep — matches v0.8.0 design (forget retry is
  operator-side only).

### Storage / Operator

- **Autovacuum tuned on the two remaining high-churn tables (#230;
  PR #287, migration 0025).** `public.content_embedding` and
  `gnokee_maintenance.ingest_audit` both get
  `autovacuum_vacuum_scale_factor = 0.05` +
  `autovacuum_analyze_scale_factor = 0.05`, matching the posture
  migrations 0018 (forget_audit) and 0021 (fact_revision) already
  established. `content_embedding` writes one 1024-dim INSERT per
  `add_episode` and absorbs bulk DELETEs from `forget_episode` FK
  cascades; HNSW indexes degrade with stale dead tuples under the
  global default 0.2. `ingest_audit` writes one INSERT + one UPDATE
  per ingest with TOAST-stored JSONB `receipt` / `error` columns.
  `tests/integration/test_autovacuum_tuning.py` asserts the
  reloptions are present after migrations apply, so a future
  drop/recreate that forgets the ALTER TABLE fails loudly.

### Internal / Tests

- **Neo4j vector-index duplicate-DDL regression guard (#242;
  PR #286).** `tests/integration/test_neo4j_vector_indexes_singleton.py`
  asserts there is exactly one VECTOR index per `(label-or-type,
  property)` pair gnokee depends on after `bootstrap_indices` runs.
  graphiti-core 0.29's `build_indices_and_constraints()` does not
  emit vector DDL today; a future upgrade that starts shipping it
  for the same label+property would land duplicate indexes (Neo4j
  tolerates it, every Entity/edge insert pays write amplification on
  both). Failure message points at the exact remediation: drop the
  gnokee-managed `CREATE VECTOR INDEX` in `bootstrap_indices`.

### Documented

- **ADR-0004 schema-name reconcile closed no-action (#231).** Specialist
  sweep flagged a suspected drift between ADR-0004 spec names and
  migration `0002_content_embedding.sql`. Investigation surfaced the
  ADR already carried the 2026-05-17 reconcile amendment; the cited
  divergent strings (`episode_embedding` / `embedding_model`) do not
  appear in the gnokee corpus. Issue closed with explanatory comment;
  no doc change needed.

### Files

- `pyproject.toml`: version 0.11.0 → 0.11.1.
- `CHANGELOG.md`: `[Unreleased]` block moved into `[0.11.1] — 2026-05-18`
  with Fixed / Changed / Storage-Operator / Internal-Tests / Documented
  sections.
- `docs/backlog.md`: v0.11.1 active table cleared; closures rotated
  into `Closed in the v0.11 series`. `#95` carried forward as the
  sole open patch-class item.

### Carryover

- **#95** — Graphiti fact-ranking: allergy episode outranked by
  medication (Q41 p_x1_03). Single eval miss, rank-order tune. No
  FORCE-RLS dependency, deferred to its own cycle.

## [0.11.0] — 2026-05-18

v0.11.0 final cut — closes the human-driver tail of the v0.11 sweep
(#273) plus four post-sweep cleanups. Promotes v0.11.0a0 (2026-05-18)
with bi-temporal correctness fixes, an MCP world-time axis on
wiki-export, the forget-pipeline contradiction-resolver fix, and the
RLS-GUC plumbing required before any FORCE-RLS migration. No public
API break from v0.11.0a0 (additive params + bug fixes).

### Added

- **#232 — `gnokee_wiki_export` accepts `valid_at` (world-time pin).**
  Per ADR-0004 both bi-temporal axes are available on every retrieval
  tool. `valid_at: str | None` (ISO-8601 UTC) threads through
  `WikiExportPipeline.export()` → `GraphitiStore.list_entities_for_tenant` +
  `.fetch_facts_for_entity` + `MetadataStore.list_episodes_for_tenant`
  (storage signatures already accepted the param). Backward-compatible:
  `valid_at=None` falls back to `as_of_eff`, preserving the v0.5
  "anchored on as_of for both axes" semantics for callers that pass
  only `as_of`.

### Fixed

- **#210 — `fact_revision.asserted_at` no longer poisoned with axis-3.**
  `maintenance.backfill_fact_revisions` (Stage 6c crash-recovery
  path) now populates `fact_revision.asserted_at` from
  `episode_metadata.asserted_at` (axis-2, source-tx) via a Postgres
  batch join, not from `EntityEdge.created_at` (axis-3, Graphiti
  ingest-system time). Conflation was silently producing wrong
  point-in-time cuts for `gnokee_fact_history` time-travel on every
  back-filled row. Orphan edges (no `episode_metadata` row for the
  tenant) are dropped with a new
  `BackfillFactRevisionsReport.dropped_orphan_count` surface — no
  mixed-axis fallback.
- **#211 — `list_episodes_for_tenant` applies world-time upper bound +
  surfaces `corrects_reason`.** Both `scope=self` and `scope=full`
  branches now apply `valid_until IS NULL OR valid_until > $valid_at`,
  so episodes explicitly closed on the world-time axis no longer leak
  into the wiki view. Both SELECT lists now include `corrects_reason`
  so the consumer-supplied supersession rationale renders verbatim on
  wiki history nodes (previously silently `None` via the defensive
  fallback in `_row_to_dc`).
- **#218 — `forget_episode` deletes `fact_contradiction` rows by
  fact-uuid, not episode-uuid.** `_episode_postgres_phase` previously
  matched `fact_uuid_a` / `fact_uuid_b` against the episode-UUID
  `scope_set` and silently affected zero rows. Now resolves
  `scope_set` → `fact_uuid` via `fact_revision` (migration 0019) and
  unions both endpoint columns — a contradiction row drops the moment
  either half's fact is gone. DELETE order unchanged (fact_contradiction
  first, episode_metadata last) so the `fact_revision` rows the
  subquery reads are still present until the `ON DELETE CASCADE`
  fires.
- **#220 — RLS GUC (`app.current_tenant`) set on `fact_history` +
  `vector.py` read paths.** `FactHistoryPipeline.fact_history`,
  `PgVectorStore.search_embeddings`, `.search_embeddings_with_scores`,
  and `.search_bm25` now call
  `SELECT set_config('app.current_tenant', $1, true)` on every
  acquired connection. Today's `WHERE tenant_id = $1` predicate keeps
  results correct on the gnokee owner role (RLS does not FORCE on
  owners), but the moment a deployment swaps to a NOBYPASSRLS role
  the per-table policy filters every row out and the read silently
  returns empty. ADR-0004 expects the GUC on every read path as the
  second-guard layer; this closes the gap before the FORCE-RLS
  migration.
- **#239 — `write_lite_episode` resume no longer zeroes plaintext
  content.** `ON MATCH SET n.content = $content` was unconditional;
  the encrypted-body branch in `ingest.py` passes `content=""`
  because no plaintext is available, so a resume MERGE re-entering
  via the encrypted branch zeroed previously-stored plaintext
  silently. Guard now uses
  `CASE WHEN $content = '' THEN n.content ELSE $content END`; empty
  input is "no update", non-empty input still overwrites.
- **#243 — `list_edges_in_window` Cypher is static.** Rewrote the
  variable-WHERE f-string with `IS NULL OR …` short-circuits and
  always-bound parameters so the Neo4j query-plan cache hits once
  per `maintenance.backfill_fact_revisions` call site instead of
  four times.
- **#237 — caller-parsed lab/med fallback path removed.**
  `_build_caller_lab_rows` / `_build_caller_med_rows` accepted
  `fallback_valid_at` / `fallback_asserted_at` parameters and used
  `p.valid_at or fallback_valid_at`. The pydantic models reject
  `None` at the boundary, so the fallback branch was unreachable.
  Removed both parameters + the `or fallback_*` shortcuts on both
  adapters and updated the single call-site in `_ingest_inner`.

### Documented

- **#236 — `DEFAULT_MAX_TOKENS = 200` documented as conservative.**
  Library callers reaching `RecallPipeline.recall(...)` directly
  inherit 200 silently — below the Q3-validated 500 ceiling the MCP
  layer enforces via `MAX_TOKENS_CEILING`. A block comment now points
  at the MCP ceiling + the Q3 spike's tuning trail so operators see
  the intent. The value stays at 200 to preserve the legacy contract.

### Changed (breaking, internal storage surface)

- `gnokee.storage.graph.EdgeInWindow.asserted_at` renamed →
  `edge_created_at` (axis-3 semantic explicit); a new
  `asserted_at: datetime | None = None` field is populated by the
  backfill caller after the Postgres join.
- `GraphitiStore.list_edges_in_window` params renamed
  `window_start` → `created_at_start`, `window_end` → `created_at_end`
  (param names now match the `r.created_at` they bind). Public
  `backfill_fact_revisions(window_start=, window_end=)` operator
  signature is unchanged.

## [0.11.0a0] — 2026-05-18

v0.11 overnight-autonomous batch — 11 PRs from specialist-sweep
release scope. Bi-temporal axis correctness + MCP surface polish.
No public API break from v0.10.1 (additive params + bug fixes).
Alpha cut precedes v0.11.0 final, which is gated on the touchier
issues left for human-driver review (#210, #211, #218, #220, #221,
#232) per `docs/plans/2026-05-18-v0.11-overnight-batch.md`.

**MCP surface polish (6 PRs):**

- **PR #255 (closes #223)** — `docs(mcp): list all 11 registered
  tools in tools-at-glance table`. `docs/api/mcp.md` enumerated 5
  of 11 registered `gnokee_*` tools; expanded to full set.
- **PR #256 (closes #222)** — `mcp(query): add lazy
  gnokee_fact_provenance pointer to tool description`. Matches
  `gnokee_recall` pattern so a fact-shape consumer discovers the
  provenance follow-up without reading two tool descriptions.
- **PR #257 (closes #226)** — `mcp(forget): trim cascade safety
  imperative from tool description`. 14-token safety imperative
  duplicated between the tool-level description and the
  `cascade` parameter description; trimmed at the tool level.
- **PR #258 (closes #227)** — `mcp(fact_history): encode
  prior_revision_id as fact_<seq> short-ID`. Compact-mode
  response previously emitted `prior_revision_id` as raw UUID
  while every sibling field used `fact_<seq>` short-IDs; routed
  through `_encode_fact` for symmetry.
- **PR #266 (closes #225)** — `mcp(recall+query): gate telemetry
  behind include_telemetry opt-in`. ~80 tokens/turn of
  LLM-invisible telemetry now default-off; opt-in via
  `include_telemetry=true`.
- **PR #267 (closes #224)** — `mcp(recall+query): cross-reference
  each tool from the other's description`. Disambiguation line
  on both `gnokee_recall` and `gnokee_query` so the LLM picks the
  right surface without reading both descriptions in full.

**Bi-temporal + storage correctness (3 PRs):**

- **PR #259 (closes #213)** — `fix(query): pin _recency_proxy to
  valid_pin (axis-1), not asserted_pin`. `query.py:853` passed
  `asserted_pin` (axis-2 source-tx-time) as `as_of` to
  `_recency_proxy` instead of `valid_pin` (axis-1 world-time);
  Δt computation used the wrong axis. Single-line swap.
- **PR #261 (closes #215)** — `fix(storage): interpolate EMBED_DIM
  into Neo4j HNSW index DDL`. HNSW vector-index DDL in
  `storage/graph.py` hardcoded dim `1024` instead of importing
  `EMBED_DIM` from `embeddings.py`; on dim change the
  `IF NOT EXISTS` would silently keep the stale-dim index and
  retrieval would zero out without error.
- **PR #262 (closes #212)** — `fix(storage): add asserted_until
  guard to history_of anchor SELECTs`. `gnokee_history_of` anchor
  CTEs missed an `asserted_until` predicate, so a superseded
  anchor stayed visible past its `as_of`. Added
  `AND (em.asserted_until IS NULL OR em.asserted_until > $3)`
  to both anchor CTEs.

**Ingest + LLM hardening (2 PRs):**

- **PR #260 (closes #228)** — `fix(llm): accept empty api_key for
  self-hosted OpenAI-compat endpoints`. `OpenAIClient.__init__`
  empty-key guard broke self-hosted endpoints (vLLM, llama.cpp,
  Ollama) that don't require auth; relaxed guard + error message
  now references `GNOKEE_OPENAI_API_KEY` not `OPENAI_API_KEY`.
- **PR #263 (closes #217)** — `fix(ingest): structured error when
  episode_metadata insert fails with our_id=None`. Concurrent
  ingest with `our_id=None` raised a bare `AssertionError` via
  `_OurIdRaceLost`; replaced with structured `VectorStoreError`
  carrying tenant + idempotency context.

Carryovers for v0.11.0 final (human-driver required, tracked in
the v0.11 overnight-batch plan § Out-of-scope):
#210 (axis-2/3 conflation in `EdgeInWindow`), #211 (`valid_until`
upper bound on `list_episodes_for_tenant`), #218 (`fact_contradiction`
DELETE axis bug), #220 (RLS GUC threading), #221 (ingest_audit
append-only invariant), #232 (`gnokee_wiki_export` `valid_at` —
depends on #210).

## [0.10.1] — 2026-05-17

v0.10.x specialist-sweep P1 mop-up. Five issues, all bug fixes /
observability nits, no public API break from v0.10.0.

**Per-issue close-out (5 PRs):**

- **PR #248 (closes #214)** — `fix(cypher): drop deprecated count()
  after DETACH DELETE`. Four sites in `src/gnokee/storage/graph.py`
  returned `count(<var>) AS deleted_nodes` after a `DETACH DELETE`
  — pattern-expression form deprecated by the Neo4j 5 planner.
  Callers already read `.counters.nodes_deleted` from the result
  summary, so the RETURN was unused. Side-effect: eliminates the
  `UserWarning: Expected a result with a single record, but found
  multiple` previously emitted from these sites.

- **PR #247 (closes #216)** — `docs(ingest): correct
  EpisodeIn.asserted_at default description`. Field docstring
  claimed `Defaults to now(UTC)`; actual default since #183 is
  `valid_at` with an INFO log when the default fires. Brings
  pydantic schema export in line with `ingest.py` behaviour.

- **PR #249 (closes #219)** — `fix(embedding): thread model= into
  write_embedding call`. `ingest.py` called `write_embedding`
  without `model=`, so the stored `content_embedding.model`
  column always recorded the `PgVectorStore` default `"bge-m3"`
  regardless of `GNOKEE_EMBED_MODEL`. Cross-model contamination
  detection at query time silently failed when operators swapped
  the embedder.

- **PR #250 (closes #229)** — `fix(llm): drop outer try/except in
  classify_contradiction`. The outer
  `except LLMUnavailable: return "unrelated"` in `llm.py` masked
  transport failures from `contradiction.py`'s per-pair handler,
  which already logs the degraded path + counts skipped pairs.
  Removing the wrapper lets the exception reach the caller as
  designed.

- **PR #251 (closes #241)** — `feat(ingest): warn when our_id=None
  disables graphiti dedup`. `add_episode(our_id=None)` silently
  disables graphiti dedup; every bare call creates a new episode
  (Q1 duplicate-on-reruns finding). Emit a single `log.warning`
  per ingest call so operators detect inadvertent duplicate
  accumulation without scraping metrics. Resume path is skipped
  — the journal row already pins identity past dedup.

Two v0.10.x items remain deferred: #207 (Q3 harness rewrite —
validates `output_shape:fact` token cost) and #95 (Graphiti
fact-ranking allergy/medication rank delta on Q41 `p_x1_03`).

## [0.10.0] — 2026-05-17

Clinical/MCP polish + fact-shape envelope. Five issues, three new
ADRs, three new migrations, no public API break.

**Theme.** Drains the v0.9.x carry-over and un-defers ADR-0013's
read-surface counterpart to v0.9's `fact_revision` write surface.

**Per-issue close-out (5 PRs):**

- **PR #204 (closes #197)** — `feat(mcp): short-ID translation at MCP
  boundary` (ADR-0027). Per-tenant per-kind monotonic counter
  (`ep_017`, `fact_042`, `ent_005`) replaces 36-char UUIDs in every
  `gnokee_*` MCP tool response. Accept-both input means in-flight
  LLM conversations using full UUIDs keep working. Migration 0022
  adds `short_id_map` + `short_id_seq` with RLS + tenant isolation.
  `mcp.py` → `mcp/__init__.py` package conversion so `mcp/short_id.py`
  can live alongside. Forget pipeline sweeps both tables on tenant
  delete.

- **PR #205 (closes #198)** — `feat(audit): ingest_audit table for
  compliance` (ADR-0028). New `gnokee_maintenance.ingest_audit`
  table (migration 0023) mirrors `forget_audit` shape; survives
  `gnokee_forget_tenant` by design as the compliance counterpart
  of forget_audit. State machine `begin → commit | fail`.
  `EpisodeIn` gains optional `actor` + `source_url` fields. Ingest
  pipeline writes audit row at Stage 1 boundary; closes on commit
  or fail. Pre-validation failures DO NOT write a row.

- **PR #206 (closes #142)** — `feat(query): un-defer
  output_shape:fact`. When `gnokee_query(envelope={output_shape:
  "fact"})` is selected and `as_of` is set, each fact's `text` +
  `valid_at` come from `FactRevisionStore.latest_revisions_at_for_fact_uuids`
  at `as_of`; facts with no revision drop out. Drops `excerpts[]` +
  `episode_fallback[]` from the response. ADR-0013 footer flip
  removes the v0.5 deferral. `gnokee_query` MCP tool gains the
  `as_of` keyword. Q3 eval re-run deferred to #207.

- **PR #208 (closes #144)** — `feat(ingest): EpisodeIn.parsed_labs
  + parsed_meds`. Caller-side structured side-channel for
  encrypted-body episodes (LLM extraction cannot run on
  ciphertext). New `LabRowIn` + `MedRowIn` Pydantic models mirror
  migrations 0006 + 0007 column shapes. Migration 0024 adds
  `source` column to `lab_record` + `med_record` distinguishing
  `llm_extracted` (default) from `caller_parsed`. Validator rejects
  `parsed_*` on plaintext branch (double-count footgun). ADR-0009
  + ADR-0010 amendments document the additive path.

- **PR #209 (closes #158)** — `docs(forget): runbook gaps +
  GNOKEE_FORGET_RETRIES env`. `GNOKEE_FORGET_RETRIES` (default `3`)
  replaces the previously-hardcoded Postgres SERIALIZABLE retry
  budget; read per-call so effectively hot-changeable. New
  `docs/forget-runbook.md` documents the retry knob, the
  per-chunk INFO progress log shape under `gnokee.forget`, and
  the audit-gap rationale covering both forget_audit (ADR-0026)
  and ingest_audit (ADR-0028).

**Migrations.** 0022 `short_id_map_seq`, 0023 `ingest_audit`,
0024 `clinical_record_source`. Migration count: 21 → 24.

**ADRs.** Two new (0027 + 0028), one footer flip (0013), two
amendments (0009 + 0010).

**Public API delta.** `EpisodeIn` gains four optional fields:
`actor`, `source_url`, `parsed_labs`, `parsed_meds`. `gnokee_query`
MCP tool gains `as_of` keyword. No breaks from v0.9.0.

**Deferred to v0.10.x or beyond.**

- **#207** — Q3 eval harness rewrite. The existing
  `evals/spike_q3_token_efficiency/run.py` is a fixed A/B between
  Graphiti raw `client.search_()` output and direct bge-m3 cosine;
  it does NOT exercise `gnokee_query` or the declarative envelope.
  Rewriting the harness to drive the v0.10 stack with
  `output_shape=fact` + `as_of=<corpus T>` unblocks the
  ADR-0013 v0.10 Amendment footer's median-tokens delta.

## [0.9.0] — 2026-05-17

First v0.9 stable. Tag-cuts the **fact-grain lineage** theme. No
public API break from `0.9.0a1`.

**Theme recap — fact-grain lineage (ADR-0014).** `0.9.0a0` landed the
`fact_revision` log + `gnokee_fact_history` MCP tool: every Stage 6c
edge-write durably records `(fact_id, fact_uuid, revision_id,
fact_text, valid_at, asserted_at, prior_revision_id)` so callers can
walk a fact's revision DAG across supersession boundaries — the
v0.9 promise. `0.9.0a1` closed the specialist-review bucket from
the 2026-05-16 full-project pass (8 issues: #168 backfill, #169
deferred-extraction skew, #170 wiki-export past-`as_of` render, plus
#179 / #180 / #181 / #182 / #183 P1–P3 hardening), shipped migrations
`0020_rls_original_tables.sql` (RLS on the remaining six tenant tables)
and `0021_fact_revision_secondary_indexes.sql` (covering indexes for
`gnokee_fact_history` Cypher), and added `gnokee_fact_history`'s
`compact` + `superseded_at` shape from #182.

**v0.9.0 final close-out.** Two PRs land on top of `0.9.0a1`:

- **PR #202 (closes #194)** — `wiki-export.py` / `fact_revision.py`
  observability nits flagged by gnokee-reviewer during PR #193:
  inline doc on the `latest_revisions_at_for_fact_uuids` `LATERAL`
  + `LIMIT 1` precondition (migration 0019 index + (tenant_id,
  fact_uuid) uniqueness); strict-`<` semantic on `past_as_of`
  documented; `log.debug()` when a misconfigured bootstrap with only
  one of `pool` / `fact_revisions` wired would silently fall back to
  current-snapshot text under `past_as_of=True`. No API change.

- **PR #203 (closes #199)** — ADR-0004 schema-name reconcile audit
  flagged by the 2026-05-16 hygiene sweep (#183). The cited drift
  (`episode_embedding` / `embedding_model`) was a misreading — ADR
  has always used `content_embedding` / `embedding` / `model`,
  matching migration 0002. Audit did surface one real minor drift:
  the Q2 template Cypher sketch returned `ep.content_embedding_id`
  (column never landed). Sketch corrected and a canonical-schema
  Amendment block added at end of ADR-0004 for future reviewers.
  Pure docs.

**v0.9.x bucket closed.** Issues #197 (short-ID at MCP boundary) and
#198 (`ingest_audit` table) re-triaged 2026-05-17: both are real
ADR-led features, not v0.9.x hygiene, and moved to v0.10 alongside
#144 / #158.

## [0.9.0a1] — 2026-05-17

Second v0.9 alpha. Closes the v0.9.x specialist-review bucket from
the 2026-05-16 full-project pass: eight P1 / P2 / P3 issues shipped
on top of `0.9.0a0` (which landed ADR-0014 `fact_revision` + the
`gnokee_fact_history` MCP tool). No public API break.

**RLS at migration time on six tenant-scoped tables (BLOCKER).**
Migration `0020_rls_original_tables.sql` enables RLS + adds
`*_tenant_isolation` policies on `episode_metadata`,
`content_embedding`, `fact_contradiction`, `lab_record`, `med_record`,
and `episode_body_encrypted` — six tables that previously deferred RLS
to a manual deploy step. Pattern matches `0015_ingest_journal.sql` /
`0019_fact_revision.sql` (DO-block `pg_policy` lookup +
`CREATE POLICY ... USING (tenant_id = current_setting('app.current_tenant', true))`).
Integration test spins a `gnokee_rls_probe` NOBYPASSRLS role and
asserts cross-tenant SELECT under the wrong GUC returns zero rows on
each table. Issue #180 / PR #189.

**Stage 6c on the deferred-extraction back-fill path (BLOCKER).**
`maintenance.run_deferred_extraction` ran Stage 4 + Stage 5 to back-fill
lite-mode episodes with full edge extraction but contained no Stage 6c
equivalent — `fact_revision` rows were never written for the back-filled
edges, leaving `gnokee_fact_history` silently empty for the lite → full
class. Extracted Stage 6c into a shared `write_fact_revisions_for_edges`
helper in `src/gnokee/storage/fact_revision_stage.py` and call it from
both `ingest.py` Stage 6c and `maintenance._extract_one` after Stage 4b
restore. `DeferredExtractionReport.fact_revision_skew_count` mirrors
the ingest-path telemetry. Issue #179 / PR #192.

**`backfill_fact_revisions` for Stage 6c crash skew (BLOCKER).** Stage
6c runs after Stage 5 commits — a crash between Stage 5 commit and
Stage 6c commit leaves Neo4j with EntityEdges but Postgres with no
`fact_revision` rows for those edges. New opt-in maintenance helper
`backfill_fact_revisions(*, tenant_id, pool, graph, fact_revisions,
window_start=None, window_end=None)` scans `RELATES_TO` edges in
window, set-intersects against existing `fact_uuid`s, and inserts the
missing rows with `fact_id = fact_uuid` (no inheritance attempted on
backfill). `asserted_at` uses the Neo4j edge's `r.created_at` (graphiti's
Stage 5 commit stamp) so the axis-2 timestamp aligns with the original
ingest moment, not the backfill tick. Per ADR-0024, `resume_ingest`
was NOT extended — operators invoke `backfill_fact_revisions`
explicitly. Issue #169 / PR #196.

**`wiki_export` `as_of` consults `fact_revision` (BLOCKER).**
`WikiExportPipeline` now takes `pool` + `fact_revisions` and — when
the caller pins to a past `as_of` — substitutes per-fact `fact_text`
+ `valid_at` from the revision history (DISTINCT ON + LATERAL,
single round-trip via `fact_revision_fact_history_idx`). Facts with
no revision at or before `T` are dropped from the snapshot. The
`as_of_history_unavailable` flag + the index.md "history unavailable"
banner are removed from `WikiExportResponse`. Three 🟡 review nits
filed as issue #194 for v0.9.x. Issue #170 / PR #193.

**Strict A/B perf harness for Stage 6c.** New
`tests/integration/test_fact_revision_ab_perf.py` runs the helper N
times with `GNOKEE_DISABLE_FACT_REVISION=1` (off) and N times unset
(on), computes `delta_p95 = on_p95 − off_p95`, strict-asserts
`<= 10ms` (ADR-0014 acceptance gate). One-shot WARNING on first
bypass activation surfaces accidental production use. Measured
locally (Apple Silicon + PG17 docker, N=30, 5 edges/batch):
`off_p95 ≈ 0ms`, `on_p95 ≈ 1.77ms`, `delta_p95 ≈ 1.77ms` — 5×
headroom under the 10ms gate. Replaces the v0.9.0a0 SOFT total-
ingest gate that was masked by ~5s LLM dominance. Issue #168 /
PR #195.

**`fact_revision` autovacuum tuning.** New migration
`0021_fact_revision_autovacuum.sql` sets `autovacuum_vacuum_scale_factor
= 0.05` + `autovacuum_analyze_scale_factor = 0.05` on `fact_revision`,
matching the `forget_audit` posture from `0018`. Default 0.2 lets
planner stats + dead tuples accumulate on hot-tenant append-only
workloads. Pure ALTER TABLE, no behavioural change. Issue #181 /
PR #190.

**Evals: judge.py drops hard-coded vendor knobs.**
`evals/spike_q10_cross_tool/judge.py` previously hard-coded
`gpt-4o-mini-2024-07-18`, `https://api.openai.com/v1/chat/completions`,
and `OPENAI_API_KEY`. Refactored through a shared `_llm_client()`
helper that reads `GNOKEE_LLM_BASE_URL`, `GNOKEE_LLM_API_KEY`,
`GNOKEE_JUDGE_MODEL`, `GNOKEE_ESCALATION_MODEL` (with `OPENAI_API_KEY`
legacy fallback). Defaults match prior hard-coded values for
backwards compat. Restores the load-bearing no-vendoring invariant.
Issue #182 / PR #191.

**P3 hygiene sweep — 12 small fixes from the 2026-05-16 specialist
review.** `count(n)` → `COUNT { (n) }` for Neo4j 5.x forward compat
(`graph.py:275`); `_to_datetime` normalizes Neo4j driver returns to
tz-aware UTC; `created_at` added to `fact_revision.__post_init__` tz
validation; `gnokee_recall.max_tokens` + `gnokee_query.max_tokens`
capped at the Q3-validated 500 ceiling; `gnokee_query.tenant_scope`
removed from the MCP surface (single-value enum, dead parameter slot;
model-layer `cross` rejection retained); `asserted_at` defaults to
`episode.valid_at` (axis-2-from-axis-1 conservative default for
historical material) with a `log.info` audit line on default-firing;
`our_id` dedup-disable behaviour explicitly documented in the public
docstring; loud `log.warning` when legacy `gnokee` / `gnokee-dev-password`
defaults are active AND base URL is non-localhost; `docker-compose.yml`
commented Neo4j memory-tuning block; `.env.example` gains
`GNOKEE_EMBED_BASE_URL` (Ollama dev path) + Neo4j heap/pagecache
guidance; ADR-0014 + ADR-0026 status flipped Proposed → Accepted;
`storage/migrate.py` comment on `CREATE INDEX CONCURRENTLY` being
incompatible with the transactional wrapper. Three items deferred:
MCP short-ID translation (#197), `ingest_audit` compliance table
(#198), ADR-0004 vs migration 0002 column-name drift (#199). Issue
#183 / PR #200.

## [0.8.2] — 2026-05-16

Six-issue concurrency + correctness patch on the v0.8 forget surface,
all surfaced by the v0.8.1 specialist-reviewer pass. No public API
break.

**Advisory-lock key — `pg_advisory_xact_lock` cross-tenant collision
(BLOCKER).** Replaced the prior two-int32 `hashtext(tenant_id),
hashtext('forget')` form with a single bigint key derived as
`('x' || md5(tenant_id || ':forget'))::bit(64)::bigint`. The 32-bit
primary slot of the old form gave ~69% cross-tenant birthday-collision
probability at 100k tenants — two tenants would silently serialize
against each other's forget and ingest. The bigint key drops the same-
scale collision probability to ~2.5e-10. Issue #151 / PR #159.

**Advisory-lock window — Stages 4 + 6 outside the forget guard
(BLOCKER).** The v0.8.1 ingest-side lock only spanned Stage 5's
Postgres tx, leaving Stage 4 (`write_lite_episode`) and Stage 6
(`add_episode`) outside the forget-vs-ingest window — a concurrent
forget could complete its Postgres DELETE + Neo4j sweep mid-Graphiti-
write, producing orphan Neo4j nodes whose `episode_metadata` row had
already been deleted. Ingest now acquires the shared forget lock on a
dedicated pool connection via `pg_advisory_lock_shared` (session-scope
variant) at the top of an `_forget_shared_session` context manager
spanning Stage 4 → Stage 8, and explicitly releases in `finally`; on
release-call failure the conn is terminated so the pool drops it
instead of returning a lock-held connection to the next ingest. Issue
#150 / PR #160.

**Neo4j `group_id` indexes — verified, not duplicated (BLOCKER →
no-op).** Issue #152 flagged a suspected missing `group_id` index that
would let every per-tenant Cypher fall back to `NodeByLabelScan +
Filter`. Investigation found graphiti-core 0.29's
`build_indices_and_constraints()` already creates RANGE indexes on
`Episodic.group_id` (`episode_group_id`) and `Entity.group_id`
(`entity_group_id`) plus every relationship type carrying `group_id`;
`EXPLAIN` already plans `NodeIndexSeek`. gnokee does NOT add
duplicate indexes (would only add write amplification on every
Episodic/Entity insert).
`tests/integration/test_neo4j_group_id_indexes.py` is the regression
guard: if a future graphiti upgrade renames or drops the indexes the
test fails before per-tenant Cypher silently degrades. ADR-0005
amendment carries the finding. Issue #152 / PR #161.

**`lock_timeout` + `ForgetContention` with context (HIGH).** Without
`lock_timeout` the forget pipeline could hang indefinitely if a
long-running or stalled ingest held the shared advisory lock. The
contending forget would block until Postgres's
`idle_in_transaction_session_timeout` fired (often >5 min, not
operator-controllable from gnokee config). New
`Settings.forget_lock_timeout_ms` (env
`GNOKEE_FORGET_LOCK_TIMEOUT_MS`, default 30000, `0` disables) drives a
`SET LOCAL lock_timeout` before the exclusive acquire; the new
`storage/locks.acquire_forget_exclusive_with_timeout` catches
`asyncpg.LockNotAvailableError` (sqlstate `55P03`) +
`QueryCanceledError` (`57014`) and raises
`ForgetContention(tenant_id, timeout_ms, waited_ms, cause)`. Issue
#153 / PR #162.

**RLS GUC — `app.current_tenant` on ingest tx + forget dry-run
(HIGH).** Two paths failed to set the per-tx `app.current_tenant`
GUC: ingest Stage 5 (silent reject on any `USING (tenant_id =
current_setting('app.current_tenant', true))` policy the day RLS
lands) and `_forget_tenant_dry_run` (all-zero counts → operator runs
destructive forget on a tenant they think is empty). Both paths now
mirror `_episode_postgres_phase` / `_tenant_postgres_phase`: open a
tx, `SET LOCAL "app.current_tenant" = '<tenant>'` with defensive
quote-escaping, then proceed. Issue #154 / PR #163.

**Chunked DETACH — labelled MATCH + honest per-label counters (MED).**
Two issues on the v0.8.1 chunked Neo4j sweep landed in #138: (a) the
unlabelled `MATCH (n {group_id})` risked over-deletion of any future
label gnokee or a consumer attached `group_id` to; (b) the receipt
lied — `ForgetReceiptDetail.neo4j_chunked` always reported
`Entity = 0` regardless of reality, breaking compliance audit
reconstruction. The chunked path now uses two single-label loops
(`:Episodic` then `:Entity`); per-label counters are honest. Uses
graphiti's per-label `group_id` indexes — no plan-cost regression
(verified via #152's regression guard). Issue #156 / PR #164.

## [0.8.1] — 2026-05-16

Six-issue patch ramp on the v0.8 forget surface. Closes the v0.8.x
backlog with one merged PR per issue.

**Operator surfaces.** `gnokee-forget` lands as a console-script
alongside `gnokee-mcp` and `gnokee-migrate`. `--scan` lists pending
`state='fail'` rows in `gnokee_maintenance.forget_audit` (optionally
narrowed by `--tenant`); `--resume <audit_id> --actor <op>` re-drives
the Neo4j sweep for one failed row and flips it to `state='commit'`.
Refuses `--resume` without `--actor` (audit-trail completeness). Backs
onto two new storage helpers: `find_all_failed_neo4j_rows` (global
scan) + `find_by_audit_id` (resume lookup). Issue #137 / PR #145.

**Retention pruner.** `gnokee.maintenance.prune_forget_audit(app, *,
tenant_id=None, before, dry_run=True, archive_path=None)` is the only
sanctioned path to delete from the append-only audit table. Refuses
with `PruneRefused` when any `state='fail'` row sits in the window —
operator must `resume_forget` first. Optional NDJSON archive-to-file
before delete (compliance posture: deletion is recorded somewhere even
when not in the live table). `docs/privacy-posture.md` carries the
operator retention guidance (healthcare 7y / general 1y / ephemeral).
Issue #139 / PR #147.

**Chunked Neo4j DETACH on huge tenants.** `Settings.neo4j_detach_chunk_threshold`
(default 100k) + `neo4j_detach_chunk_size` (default 10k) gate the
chunked sweep. Below the threshold the sweep stays monolithic — zero
behaviour change for typical deployments. Above it,
`GraphitiStore.remove_tenant_group` loops `MATCH (n {group_id}) WITH n
LIMIT $chunk_size DETACH DELETE n` until empty; each chunk in its own
implicit tx so a mid-sweep failure leaves the prefix deleted and
`resume_forget` continues via the shrinking pre-count. New
`ForgetReceiptDetail.neo4j_chunked` carries `{chunks_executed,
chunk_size, pre_count}` for verification — `None` on the monolithic
path. Issue #138 / PR #148.

**Advisory-lock ingest/forget contention.** `gnokee.storage.locks`
ships `acquire_forget_exclusive` (forget side, exclusive) +
`acquire_forget_shared` (ingest Stage 5, shared) — both
transaction-scoped on `pg_advisory_xact_lock[_shared](hashtext(tenant_id),
hashtext('forget'))`. Multiple ingests on the same tenant share freely;
a pending forget waits for in-flight shared holders; new ingests block
while exclusive held. `docs/architecture.md` gains a § Concurrency
section. Issue #140 / PR #149.

**Q5 spike close-out + Q13 harness rewire.** `evals/spike_q5_forgetting/run_v08.py`
exercises the v0.8 public API end-to-end (chain refusal + tenant
sweep); ADR-0026 § Acceptance carries the **ADOPT — 2/2** verdict.
`evals/spike_q13_confidence/run.py` + `spike_q13.1_confidence_v2/run.py`
replace the `_cosine_top1_score = confidence_recency` proxy with the
real cosine surfaced by `recall(include_cosine_top1=True)`; ADR-0019 §
Follow-up amended. Issues #141 / #89, PRs #143 / #146.

No surface breakage; v0.8.0 callers continue to work unchanged.

## [0.8.0] — 2026-05-16

The "verifiable forgetting" ramp. gnokee finally ships Mode 2 of the
three forgetting modes enumerated in `docs/architecture.md §Forgetting`:
hard-delete with a verifiable audit trail. ADR-0026.

**Two MCP tools land.** `gnokee_forget_episode(tenant_id, episode_uuid,
*, cascade=False, reason, actor=None)` hard-deletes one episode and all
derived data from both Postgres and Neo4j; on a chain node it refuses
with `cannot_forget_chain_node` (ADR-0022 refusal posture) unless
`cascade=True` is set, in which case descendants are also deleted —
ancestors are never cascaded, their `superseded_by` pointer is cleared
via explicit UPDATE. `gnokee_forget_tenant(tenant_id, *, dry_run=True,
reason, actor=None)` defaults to a planning call that returns counts
without writing; the caller MUST issue a second call with
`dry_run=False` to execute — the two-call ceremony is the guard for an
irreversible op (no `confirm_tenant_id` parameter).

**Audit-row-as-journal.** A new schema-isolated table
`gnokee_maintenance.forget_audit` records a `begin → commit` pair per
forget call inside the SERIALIZABLE Postgres transaction that covers
the sweep DELETEs. The schema isolation is load-bearing: the
`gnokee_maintenance` schema survives a `gnokee_forget_tenant` sweep,
which is its purpose — proof the deletion happened. The `commit` row's
`receipt` JSONB carries the frozen `cascade_uuids[]` list and a
per-uuid `bitemporal_snap` (`{asserted_at, valid_at, valid_until}`)
captured pre-DELETE for compliance completeness. A `state='fail'` row
is appended when the post-commit Neo4j sweep raises;
`gnokee.resume_forget(tenant_id, *, pipeline)` retries Neo4j-only
failures using the frozen cascade UUIDs from the committed audit row
(mirror of `gnokee.resume_ingest` from ADR-0024).

**`ingest_journal` cascade gap closed (issue #130).** `ingest_journal`
has no FK to `episode_metadata` (designed append-only per ADR-0024), so
the v0.7 `gnokee_forget_tenant` plan would have left orphaned journal
rows after tenant deletion. The v0.8 sweep DELETEs `ingest_journal`
explicitly inside the same SERIALIZABLE tx as the
`episode_metadata` + FK-cascade chain.

**Consumer-side KMS handoff.** `ForgetReceipt.affected_key_ids[]`
surfaces the DEK identifiers attached to deleted encrypted episodes;
the consumer is responsible for KMS destruction. gnokee never holds
DEKs, so Mode 3 (cryptographic erasure) remains a documentation note —
this field is the handoff point for any consumer who wants to
approximate Mode 3 after a Mode 2 call.

### Added

- **`gnokee_forget_episode` + `gnokee_forget_tenant` MCP tools and
  `gnokee.forget.forget_episode` / `gnokee.forget.forget_tenant`
  Python APIs (#133, ADR-0026).** Both return a compact
  `ForgetReceipt` on the MCP surface (summary string + key fields)
  and a richer `ForgetReceiptDetail` on the Python surface (full
  storage metrics + frozen cascade UUIDs). DAG behaviour matrix:
  `cascade=False` refuses chain nodes (`cannot_forget_chain_node`,
  no descendant UUIDs inlined); `cascade=True` hard-deletes target +
  all descendants transitively; ancestors are never touched but
  their `superseded_by` pointer is cleared via explicit UPDATE
  (no FK exists). Tenant tool defaults `dry_run=True` — first call is
  always a planning call. `affected_key_ids[]` on the receipt
  surfaces consumer-KMS handoff (gnokee never holds DEKs). See
  `docs/api/python.md` § `gnokee.forget`.

- **`gnokee_maintenance.forget_audit` table + migration
  `0017_forget_audit.sql` (#133).** Schema-isolated audit table that
  survives `gnokee_forget_tenant` — proof of deletion lives outside
  the public schema the sweep clears. Records a `begin → commit`
  pair per forget call inside the SERIALIZABLE Postgres tx covering
  the sweep DELETEs; `state='fail'` rows are appended on post-commit
  Neo4j sweep errors. `receipt` JSONB carries frozen
  `cascade_uuids[]` + per-uuid `bitemporal_snap`
  (`{asserted_at, valid_at, valid_until}`) captured pre-DELETE.

- **`gnokee.resume_forget(tenant_id, *, pipeline)` Python API (#133,
  ADR-0026).** Retries Neo4j-only sweep failures using the frozen
  cascade UUIDs from the committed audit row. Mirrors
  `gnokee.resume_ingest` (ADR-0024) for operator-driven recovery
  after partial Neo4j outage. Python-API only in v0.8; CLI
  (`scan-forgets` / `resume-forget`) deferred — matches
  `resume_ingest` precedent.

### Fixed

- **Clinical-topic routing in `gnokee_query` (#134, fixed in #135).**
  v0.7.0 shipped the typed-store back-ends for labs (ADR-0009,
  v0.2) and meds (ADR-0010, v0.2) but `gnokee_query` ask-parsing
  never wired `topic="clinical.lab"` / `topic="clinical.med"` to
  `gnokee_lab_query` / `gnokee_med_query`. Bug surfaced when MCP
  callers received the graph-only path on clinical asks instead of
  the typed-store path that already existed. ADR-0013 §sequencing:
  v0.6 row shipped end-to-end; v0.6.1 row (ask-parsing) closed
  here.

- **Encrypted-body plaintext window dropped before persistence
  (#132, fixed in #136).** On the encrypted-branch + opt-in
  `EncryptedBody.content_for_embedding=PLAINTEXT`, the v0.6.0–v0.7.0
  ingest path leaked plaintext into `Episodic.content` +
  `Episodic.name` on Neo4j and into `lab_record.*` /
  `med_record.*` typed-store columns. The pre-fix surface
  contradicted the privacy posture promised by `EncryptedBody` —
  this was a privacy-contract violation, not just doc rot. v0.8.0
  drops `content_for_embedding` from local scope after Stage 3
  (embed) returns; Stage 4 (`graph.write_lite_episode`) branches on
  `is_encrypted` directly and always lands `content=""`,
  `name="[encrypted episode]"`,
  `source_description="gnokee.ingest.encrypted"`. Stage 6
  (`parse_labs` / `parse_meds`) is force-disabled on the encrypted
  branch. The opt-in plaintext window now leaves the gnokee process
  only over the TEI socket and is dropped before any persistence
  step touches it. See `docs/privacy-posture.md` § "What
  encrypted-body delivers" / § "What gnokee stores in plaintext".

## [0.7.0] — 2026-05-16

The "durability + lineage" ramp. Two things ship together:

1. **Durability.** Ingest now writes an append-only `ingest_journal` row
   before Stage 4 (lite-Episodic Neo4j MERGE) and after Stage 5 (PG txn).
   On container kill / OOM between Stage 4 and Stage 5 the orphan
   `begin` row is surfaced (never auto-replayed); operators call
   `gnokee.resume_ingest()` to finish the half-written episode using
   the journaled `stage_4_time` so the resumed `Episodic.created_at`
   matches the original ingest-time clock. ADR-0024.

2. **Lineage.** `gnokee_history_of` returns the full supersession DAG
   (Cytoscape-flat envelope: `nodes` + `edges` + `head` + `root`) for
   any episode in a tenant; `mode=compact` keeps it LLM-cheap,
   `mode=verbatim` attaches body text on the newest `top_k_bodies`
   nodes. Encrypted episodes never leak plaintext. `as_of` gives
   bi-temporal time-travel; `cycle_detected=true` reports DAG defects
   without raising.

Companion: hard-removal of the v0.6-deprecated `GNOKEE_INGEST_STRICT`
env var. v0.6 already neutralized it (no-op-with-warning) once
ADR-0023 made lite-fallback the contract — v0.7 finishes the cleanup.

### Added

- **Ingest crash-recovery journal + `gnokee.resume_ingest` Python API (#122, ADR-0024).**
  Append-only `ingest_journal` Postgres table records one `begin` row
  before Stage 4 (lite-Episodic Neo4j MERGE) and one `commit` row after
  Stage 5 (PG txn) on every `ingest_episode` call; `fail` rows are
  appended on unhandled exceptions (compensation runs first). On
  container kill / OOM between Stage 4 and Stage 5, the `begin`
  without matching `commit` is surfaced by `IngestPipeline` on the
  first ingest per tenant per process as a `ResumableIngest` log
  warning — gnokee NEVER auto-replays. Operators call
  `gnokee.resume_ingest(tenant_id, episode_uuid, episode, *, pipeline)`
  to re-execute Stage 4 (Neo4j MERGE preserves the journaled
  `stage_4_time` → `Episodic.created_at`) + Stage 5 (idempotent
  inserts) + write the `commit` row. The consumer re-supplies the
  original `EpisodeIn`; gnokee refuses with `IngestJournalError` on
  payload-hash drift (`SHA256(tenant_id ‖ our_id ‖ valid_at)`). Stage
  6 (Graphiti enhancement) stays the domain of
  `run_deferred_extraction` and is force-disabled on resume. Q19
  spike: 2.17% median latency regression (101.93 ms on / 99.76 ms off
  on `extract=False` ingests), well under ADR-0024's 10% threshold.
  See `docs/architecture.md` § Durability and
  `docs/api/python.md` § `gnokee.resume_ingest`.

- **`gnokee_history_of` MCP tool + `gnokee.history_of` Python API (#123).**
  Returns the supersession DAG for an episode in flat Cytoscape-style
  envelope (`nodes`, `edges`, `head`, `root`, `truncated`,
  `cycle_detected`). `mode=compact` (default) ships LLM-facing nodes
  with no body; `mode=verbatim` attaches body text to the newest
  `top_k_bodies` nodes capped at `per_body_char_cap` chars. Encrypted
  episodes return `body_encrypted=true` + ciphertext envelope —
  plaintext NEVER leaves gnokee for those. `as_of` filters every node
  by `asserted_at <= as_of`; nodes whose `superseded_by` points outside
  the visible set are reported as `active` for that time-travel slice.
  Storage walk uses a Postgres recursive CTE bounded by `max_nodes` (32);
  on cycle/depth-exceeded the response carries `cycle_detected=true`
  instead of raising. See `docs/api/python.md` § `gnokee.history_of`.

- **`EpisodeIn.corrects_reason: str | None` field (#123).** Optional
  consumer-supplied rationale (≤500 chars) for the supersession declared
  via `corrects:`. Persisted on `episode_metadata.corrects_reason` via
  migration `0014_episode_corrects_reason.sql` and surfaced verbatim on
  `HistoryNode.rationale` in DAG responses. Only honored when `corrects:`
  is also set; ignored otherwise. Python-API only in v0.7; MCP exposure
  on `gnokee_ingest_episode` deferred to a follow-up.

### Removed

- **BREAKING: `GNOKEE_INGEST_STRICT` env var removed (#124).** Deprecated in
  v0.6 (PR #111, H3) after ADR-0023 made gnokee own Episodic storage and
  failure semantics uniform (lite-fallback + `extraction_deferred` flag).
  Setting `GNOKEE_INGEST_STRICT=1` is now a no-op — the env var is no longer
  read. No behavior change for production callers: the v0.6 deprecation
  path already neutralized the loud-failure mode. Replacement signals on
  `IngestReceipt.ingest_telemetry`: `lite_fallback_engaged`,
  `enhancement_retries`, `orphan_edge_warnings`.

## [0.6.0] — 2026-05-16

The "ingest hardening" ramp. gnokee never loses an episode regardless of
Graphiti state. Closes the Q18 silent-drop bug class (`INGEST_GAP_NOT_RETRIEVAL_GAP`
verdict, 2026-05-12) on the LongMemEval-S corpus. Architectural shift per
[ADR-0023](docs/adr/0023-gnokee-owns-episode-storage.md): gnokee owns the
Episodic write surface, Graphiti is best-effort enhancement.

**Q18 release-cut gate (2026-05-16, stageC_30q20s @ conc=4):**
- silent-drops: 0 (v0.5 baseline: 14/17)
- recall@5 measurable: 100% (v0.5: 17.6%) — 5.7× improvement
- recall@1: 88.2% / recall@3: 94.1%
- 600 episodes ingested @ tier-1 200K TPM with 4-way concurrency; Z1 + Z4
  preserved all of them; 15 (2.5%) hit Z1 lite-fallback on genuine rate-limits.

### Added

- **v0.6 Z1 ingest hardening (#111):** storage-first ingest pipeline —
  gnokee writes Episodic + episode_metadata + content_embedding FIRST
  using a gnokee-generated `episode_uuid`; Graphiti's `add_episode`
  runs after as best-effort enhancement. On graphiti failure (RateLimitError
  exhaustion or non-retryable raise), episode stays retrievable;
  `IngestReceipt.extraction_deferred=True` flags rehydration via
  `maintenance.run_deferred_extraction`. Closes the Q18 silent-drop bug
  class. See [ADR-0023](docs/adr/0023-gnokee-owns-episode-storage.md).

- **v0.6 Z4 adaptive ingest retry (#111):** `IngestPipeline` gains
  `extraction_concurrency: int = 2` kwarg; `asyncio.Semaphore` bounds
  parallel graphiti enhancement calls. Per-call adaptive backoff via
  `_retry_enhancement` (max 3 retries, ±20% jitter, honours
  `RateLimitError.retry_after`). Receipt surfaces
  `IngestTelemetry.enhancement_retries` + `lite_fallback_engaged`.

- **`GraphitiStore.remove_lite_episode`** — direct Cypher `MATCH ... DETACH DELETE`
  that reaches lite-written Episodic nodes for compensate-on-failure.
  `GraphitiStore.add_episode` gains `uuid: UUID | None = None` kwarg.

- **`MetadataStore.set_extraction_deferred`** — flips the column
  post-Stage-6 when lite-fallback engages.

- **Q18 spike `--gate` mode** — `python evals/spike_q18_recall_at_k_diagnostic/run.py --gate`
  asserts the v0.6 release-cut thresholds (≥14/17 measurable in storage,
  ≥80% recall@5 on measurable).

- **MCP `gnokee_recall` exposes `top_k_bodies` + `per_body_char_cap`**
  (issue #84). The two body-coverage knobs shipped in v0.4.0 (#52)
  were Python-API only; MCP consumers (noggin, Claude / Cursor,
  third-party MCP clients) were pinned to `DEFAULT_TOP_K_BODIES = 3`
  and `DEFAULT_PER_BODY_CHAR_CAP = 600`. Both parameters now appear
  on the MCP tool surface with the same defaults, forwarded into the
  Python `recall()` call. No behavioural change at defaults.

### Fixed

- **`maintenance.run_deferred_extraction` invalid SQL** (#111 M4 side-fix):
  parametrized `SET app.current_tenant = $1` does not work in Postgres
  (SET rejects positional params). Replaced with
  `SELECT set_config('app.current_tenant', $1, false)`. Pre-existing
  latent bug surfaced by the Z1.7 rehydration test.

- **`maintenance.run_deferred_extraction` missing uuid plumbing** (#111 M4):
  `graphiti.add_episode` was called without `uuid=episode_uuid` during
  rehydration, creating new graphiti-owned Episodic nodes instead of
  attaching entities to the existing lite Episodic. Now passes the
  gnokee-owned uuid + pre-overwrites the lite Episodic content to
  `augment_for_extraction(...)` so graphiti's load-by-uuid extraction
  sees the augmented form.

- `docs/api/python.md` `per_body_char_cap` example default corrected
  from `800` → `600` to match `src/gnokee/retrieval.py`
  `DEFAULT_PER_BODY_CHAR_CAP`.

### Deprecated

- **`GNOKEE_INGEST_STRICT` env var:** emits `DeprecationWarning` on
  `IngestPipeline.__init__` when set. Hard-removal in v0.7. Z1 closes
  the silent-drop class by architecture (ADR-0023); the env-flag-based
  "fail loud on orphan-edge warnings" surface is no longer load-bearing.
  Replacement: `IngestTelemetry.lite_fallback_engaged` +
  `enhancement_retries` + `orphan_edge_warnings`.

### Notes

- ADR-0012 (cross-tool eval verdict) amended with § v0.6 ingest hardening.
- ADR-0019 (confidence model) amended with § LongMemEval-S publish
  stance refresh — once the Q18 re-spike passes, the publish stance
  lifts from `DECLINE_TO_PUBLISH` to `PUBLISH_POST_Z1`.

## [0.5.0] — 2026-05-12

The "read-side hardening" ramp. v0.5 keeps the v0.1 core surface
unchanged and lands six adopt-decisions that sharpen the MCP read
contract: declarative `gnokee_query` envelope (ADR-0013), per-claim
bi-temporal citation envelope (ADR-0016), `confidence` recency-proxy
field (ADR-0019, `SHIP_RECENCY_AS_PROXY` confirmed at N=31 in stage-2
spike), Obsidian vault adapter (ADR-0020 `SHIP_ADAPTER`),
three-tier consumer-surface strategy (ADR-0021), and explicit refusal
posture (`refused: bool` + `cosine_floor` knob; ADR-0022 Option A on
top of Option D). Adds per-fact `cosine_top1` telemetry on
`gnokee_recall` (#89, opt-in flag, default off). v0.5 narrative on
LongMemEval-S: `DECLINE_TO_PUBLISH` (ADR-0019 amendment) — Q18
verdict isolated the gap to `add_episode` ingest, not retrieval; the
re-publish gates on v0.6 Z-series ingest hardening (#111).

> **Backfilled 2026-05-16.** Tag `v0.5.0` (commit `ed8cec7`) shipped
> on 2026-05-12 without promoting `[Unreleased]` → `[0.5.0]` in this
> file. Section reconstructed from the GitHub release notes + commit
> log `git log v0.4.0..v0.5.0`.

### Added

- **ADR-0013 — `gnokee_query` declarative envelope MCP tool** (issue
  #72, PR #100). Pinecone KnowQL + GCP Memory Bank `lookup_context`
  shape on top of the v0.1 `gnokee_recall` primitive. `confidence_floor`
  parameter applies on top of the recency-proxy `confidence` value per
  ADR-0019.
- **ADR-0015 — `gnokee_wiki_export` + `llms.txt` manifest** (issue
  #74, PR #99). Karpathy LLM-wiki + `llms.txt` convention; one-shot
  fetch of all per-tenant facts in LLM-readable form.
- **ADR-0016 — per-claim bi-temporal citation envelope on MCP read
  responses** (issue #76, PR #92). NotebookLM / GraphRAG / KnowQL
  field-level provenance baseline. Each fact statement carries
  `Citation(fact_uuid, valid_at, asserted_at, confidence)`.
- **ADR-0019 — `confidence` field on read-tool responses** (issue
  #80, PR #87). Function B (recency-only Ebbinghaus, `SHIP_RECENCY_AS_PROXY`)
  ships as the v0.5 `confidence`. Documented as a recency proxy, not a
  calibrated model. Stage-2 spike (#88, PR #118) reconfirmed at N=31
  with 48 composite variants — 0/48 cleared both Spearman + calibration
  gates → ADR-0019 § Follow-up closed; recency proxy is durable.
- **ADR-0020 — Obsidian vault adapter** (issues #96/#97, PR #101).
  Q14 spike verdict `SHIP_ADAPTER`. Drops markdown vaults into gnokee
  via the consumer-side adapter pattern (ADR-0021 tier).
- **ADR-0021 — Consumer surface strategy** (issue #106, PR #113).
  Three-tier policy + source-to-shape routing; closes the recurring
  "which consumer next" question; gates `gnokee-consumer-template`
  sibling repo.
- **ADR-0022 — Refusal posture** (issue #109, PRs #115/#116/#119).
  Q17 spike (`evals/spike_q17_refusal_posture/`) verdict
  `ADOPT_OPTION_D_CURRENT_POSTURE_CONTROLS_PARTIAL` — Option D
  (current "zero refusal envelope" posture, consumer LLM renders the
  refusal) accepted as v0.5 posture. Option A landed same day:
  `refused: bool = False` on `RecallResponse`, set `True` when
  `len(facts) == 0 AND len(episode_fallback) == 0`. Companion knob
  `cosine_floor: float | None = None` on `recall()` /
  `gnokee_recall` MCP tool: when set (0.0-1.0), episodes whose
  cosine similarity falls below the floor are pruned at stage 3.6,
  making `refused=true` observable in default mode.
- **Per-fact `cosine_top1` telemetry on `gnokee_recall`** (issue
  #89, PR #117). Each `facts[]` entry gains
  `cosine_top1: float | None` when `include_cosine_top1=true`.
  Pgvector cosine similarity in `[0, 1]` of the source episode vs
  query; `null` for Path-A fallback facts. Telemetry only — does
  NOT reorder or threshold-prune. Closes the "recency-proxy as
  cosine proxy" caveat in ADR-0019. Default off — wire shape stable
  for non-opt-in consumers.
- **Q14.1 — threshold-semantics sweep across past spike harnesses**
  (issue #107, PR #114). ADR-0020 follow-up; confirmed no past spike
  verdict silently misfired due to threshold-direction bugs.
- **Z3 — graphiti orphan-edge warnings on `IngestReceipt`** (issue
  #111 partial, PR #112). Loud telemetry surface for the
  `add_episode` silent-drop class. Z1 + Z2 remain for v0.6.
- **ADR-0005 amended** — AGE v1.7.0 maturity correction + concrete
  7–8wk cost (#91, commit `fda572c`); 90-day watch issue filed.
- **Mean-centered cosine etalon separation probe** (#103, PR #105) —
  calibration tooling for embedding diagnostics.
- **Q41 source-grounded refusal spike** verdict ADOPT (#77, PR #93,
  ADR-0008 extension).

### Changed

- **README status banner refreshed** to v0.5; lists v0.5 ADRs +
  `cosine_top1` telemetry.
- **Documentation overhaul** — contributor / user / integrator /
  operator surfaces split (commit `32f0342`).
- **CI deps:** `actions/download-artifact` 4 → 8 (#82),
  `actions/upload-artifact` 4 → 7 (#83).

### Resolved (no-code amendments)

- **#81 — LongMemEval-S v0.5 target** — `DECLINE_TO_PUBLISH` (ADR-0019
  amendment 2026-05-12). Q18 verdict (`evals/spike_q18_recall_at_k_diagnostic/`)
  isolated the gap to graphiti `add_episode` silent-drop ingest, not
  retrieval — 14/17 measurable LongMemEval-S rows had gold sessions
  silently dropped. Re-publish gates on v0.6 #111 Z1 + Z2 landing.
- **#90 — Graphiti literal-numeric extraction gap** — Accept (option
  1 of 4); triple-coverage via `lab_record` / `med_record` /
  `excerpts[]` + `episode_fallback[]` suffices for the v0.5 read
  contract.

### Carryover

- **v0.5.x:** [#95](https://github.com/omurlabs/gnokee/issues/95)
  Graphiti fact-ranking allergy-vs-medication edge case (Q41 p_x1_03).
  Low priority single eval miss.
- **v0.6 lead:** [#111](https://github.com/omurlabs/gnokee/issues/111)
  graphiti `add_episode` silent-drop ingest hardening (Z1 + Z2);
  Z3 already landed. Highest-leverage retrieval-quality fix.
  Unblocks LongMemEval-S re-publish. **Landed v0.6.0.**

## [0.4.0] — 2026-05-10

The "encrypted_body + body knobs" ramp. Closes the v0.1-deferred
`encrypted_body` `NotImplementedYet` boundary (issue #22): Stage 1
ingest now accepts `content xor encrypted_body`, lands ciphertext
unmodified in a sibling Postgres table, and surfaces it on recall
without ever decrypting. Adds Python-API-only knobs for tighter
body-emission control on `recall()` (#52). Consolidates the duplicate
`episode_metadata.content` + `content_text` plaintext columns into a
single canonical column (#51). Extends the cross-tool eval harness for
LongMemEval-S scale (#62, #63, #64). MCP `gnokee_recall` parameter
surface stays byte-identical to v0.3 — `top_k_bodies` /
`per_body_char_cap` exposure on MCP is deferred to a v0.4.x
maintenance bump.

### Added

- **`encrypted_body` DEK pathway — Stage 1 boundary accepts
  `content xor encrypted_body`** (issue #22).
  `EpisodeIn._content_xor_encrypted_body` Pydantic `model_validator`
  rejects both/neither. Encrypted episodes land
  `(ciphertext, nonce, key_id)` in the new sibling table
  `episode_body_encrypted` via raw-SQL migration
  `0012_episode_body_encrypted.sql` — PK on
  `(tenant_id, episode_uuid)`, FK to `episode_metadata` with
  `ON DELETE CASCADE`. gnokee NEVER holds key material and NEVER
  decrypts: `EncryptedBody.content_for_embedding` plaintext is
  local-scope only, passed to `embeddings.embed_one()` and dropped at
  end of `ingest()`. Recall surfaces
  `RecallResponse.encrypted_bodies[]` carrying
  `EncryptedEpisodeBody(episode_uuid, ciphertext, nonce, key_id)`
  verbatim; excerpt and body lanes filter encrypted episodes out
  before fetching plaintext from Graphiti, and
  `FactProvenance.episode_content` is forced to `""` with the
  ciphertext envelope riding on `FactProvenance.encrypted_body` for
  encrypted rows. New
  `EncryptedBodyStore.{write, get, fetch_many}` all require
  `tenant_id` in the `WHERE` clause. Postgres RLS reuses the existing
  `app.current_tenant` GUC pattern at deployment time. Unblocks
  clinical-Omur phase-1 ingest.
- **`top_k_bodies` + `per_body_char_cap` knobs on `recall()`** (issue
  #52). `_build_episode_body_rows` now truncates each body to
  `per_body_char_cap` chars (default 600 ≈ 150 approx-tokens) before
  token accounting + emission, and stops after `top_k_bodies` rows
  (default 3). Surfaced by Q10 Stage A re-run after #41 hybrid body
  emission landed: every fired body call hit
  `body_first_row_oversize=True` because a single conversation-turn
  body is ~3700 approx-tokens against the 66-token `body_budget` at
  `max_tokens=200` (telemetry from #54). Cap-and-count lets multiple
  ranked episodes share the lane on larger budgets while preserving
  the always-emit-first guard semantics on tight ones. Knob is
  Python-API-only for v0.4; MCP `gnokee_recall` keeps the v0.3
  parameter surface unchanged. **MCP exposure deferred to v0.4.x.**

### Changed

- **Consolidated `episode_metadata.content` + `content_text`** (issue
  #51). After PRs #48 (BM25/RRF) and #49 (deferred extraction) both
  landed in v0.3, `episode_metadata` carried two TEXT columns storing
  identical plaintext for lite-mode episodes. Migration
  `0011_drop_content_column` backfills `content_text` from `content`
  (defence-in-depth) then drops `content`.
  `maintenance.run_deferred_extraction()` now reads `content_text`
  instead. `PgVectorStore.write_content_text` remains the canonical
  write path. `IngestPipeline` Stage 6 metadata write no longer
  carries the dropped column.

### Documentation

- **ADR-0004 amended** for the `encrypted_body` boundary rules: gnokee
  never holds key material; ciphertext + nonce + key_id are the only
  shapes that touch storage; `content_for_embedding` is a local-scope
  embedding window dropped after `embed()` returns (issue #37, PR
  #69).
- **ADR-0012 amendment** bundled: Q10 Stage C-pilot magnitude
  confirmation + `run.py` recovery primitives narrative captured in a
  single doc-only PR (issue #37, PR #69).

### Evals

- **Q12 abstain split + synth-v2 falsifies #62** (issue #62, PR #65).
  Adds the abstain-rate split to LongMemEval-S analysis and lands a
  synth-v2 prompt that pins synthesizer abstention as the dominant
  failure mode at 20-session scale; closes the original Q12 question
  about whether retrieval or synthesis was the bottleneck.
- **`evals/q10/run.py` parallelize per-question + Mem0 adapter
  robustness** (issue #63, PR #66). Per-question execution now runs
  in parallel across the SUT × question matrix; the Mem0 adapter
  recovers from per-call transient errors instead of failing the
  whole grid.
- **Q10 / Zep CE compose env keys + smoke** (issue #64, PR #67).
  Fixes the `store.type must be set` server-exit by aligning the
  docker-compose env keys to what Zep CE actually reads, plus a smoke
  step so future env-key drift fails fast.

## [0.3.0] — 2026-05-09

The "telemetry + integration patterns" ramp. Promotes the recall surface
from "fires and emits a result" to "fires, emits, and reports its own
budget vs emitted accounting." Documents the lite-ingest + deferred-
extraction integration patterns introduced in v0.2.x. Lands the
lite-mode-recall fix that makes `extract=False` actually queryable via
the main retrieval surface.

### Added

- **`RecallResponse.recall_telemetry: RecallTelemetry`** (issue #54).
  Stage 6 per-lane budget vs emitted-token accounting:
  `budget_max_tokens`, `fact_budget`/`excerpt_budget`/`body_budget`,
  `fact_tokens_emitted`/`excerpt_tokens_emitted`/`body_tokens_emitted`,
  `fact_count`/`excerpt_count`/`body_count`, `body_first_row_oversize`.
  Lets eval harnesses + observability record actual budget usage per
  call instead of inferring it from row counts.
- **`gnokee_recall` MCP response carries `recall_telemetry{}`** (issue
  #54). Surfaced to MCP consumers so model-side observability can graph
  body-coverage distributions per session.
- **`_compute_budget_split(...) -> BudgetSplit`** pure helper in
  `retrieval.py`. Replaces the inline four-branch budget split (Path A
  / `wants_excerpt` / hybrid / no-signal) with a unit-tested function;
  same shape powers Stage 6 emission and `RecallTelemetry` reporting.
- **`docs/integration_patterns.md`** (issue #16). Authoritative
  integrator-facing doc on lite-ingest + deferred extraction patterns:
  when to use, when not, backfill scheduling, typed-reads interaction,
  two-customer byte-identical invariant, AGENTS.md compliance matrix.
- **`docs/eval_delta_gate.md`** (issue #16). Documents the v0.3 manual
  eval-delta gate: 5 pp pass-rate floor + per-question PASS→FAIL
  guard; baseline JSONs under `evals/baselines/<spike>.json`. Manual
  gate this ramp; CI in v0.4.
- **`make eval-delta`** Makefile target (issue #16). Stub invoking
  spike runners with `--check-baseline` (flag wired in v0.3 follow-up).
- **Lite-mode recall path: minimal `Episodic` node written to Neo4j on
  `extract=False` ingest** (issue #56). `uuid` (gnokee-owned),
  `group_id`, `valid_at`, `name`, `content`, `created_at`,
  `source_description = "gnokee.ingest.lite"`. No entity nodes, no
  `MENTIONS` / `RELATES_TO` edges. Recall Stage 2a now surfaces
  lite-mode episodes via the BM25 / cosine path; Stage 4 fact-fetch
  returns 0 → Path A body emission fires correctly.

### Changed

- **`_build_episode_body_rows` now returns `BodyRowsResult`** (rows,
  truncated, tokens_emitted, first_row_oversize) instead of a 2-tuple.
  Stage 6 mirrors `tokens_emitted` and `first_row_oversize` into
  `recall_telemetry`. Existing callers updated.
- **ADR-0012 status: Draft → Accepted-with-caveat.** Stage C
  confirmation deferred post-v0.3 tag. See § "v0.3 status decision
  (2026-05-09)" in the ADR for the cost / signal-saturation reasoning.

### Fixed

- **Lite-mode ingest no longer breaks recall** (issue #56). Previously,
  `extract=False` wrote no `Episodic` node to Neo4j, causing Stage 2a
  (`list_candidate_episodes`) to return 0 candidates → empty
  `RecallResponse`. The recall surface now sees lite-mode episodes
  natively.

## [0.2.3] — 2026-05-09

First PyPI publish (closes #20). Restructures install UX so naked
`pip install gnokee` works and the wheel ships without duplicate
migration files. No retrieval / ingest behaviour changes; no new
migrations.

### Added

- **`.github/workflows/pypi-publish.yml`** — Trusted Publishing
  (OIDC) workflow that builds sdist + wheel on `v*` tag pushes,
  guards against duplicate-entry regressions in the wheel, and
  uploads to PyPI (or TestPyPI via `workflow_dispatch`) without a
  stored API token.

### Changed

- **`[core]` extras → mandatory `dependencies`.** `gnokee/__init__.py`
  eagerly imports `ingest` + `retrieval`, both of which need
  `asyncpg` / `graphiti-core` / `neo4j` / `pgvector` / `httpx` /
  `openai` / `structlog` / `langdetect`. Naked `pip install gnokee`
  used to `ImportError` on first import; it now works. The `[core]`
  extra is retained as a no-op alias so existing `pip install
  gnokee[core]` invocations keep working without surprise.
- **`gnokee.__version__` now reads from `importlib.metadata`** so it
  stays in sync with `pyproject.toml` automatically. Was hardcoded
  to `"0.1.0"` since v0.1, drifting silently across every release.
- **README install line** drops the `[core]` extra (now redundant);
  recommended dev install becomes `pip install -e ".[mcp,dev]"`.

### Fixed

- **Wheel no longer ships duplicate migration SQL files.** The
  `tool.hatch.build.targets.wheel.force-include` directive was
  redundant with `packages = ["src/gnokee"]` and caused each
  `0001…0008_*.sql` to appear twice in the wheel zip (eight
  `UserWarning: Duplicate name` warnings on every build, ~12 KB
  unnecessary payload). The new pypi-publish workflow has a
  regression guard step that fails CI on any future duplicate.

## [0.2.2] — 2026-05-09

Maintenance bundle closing the three named v0.2.1 footguns plus a CI
hardening pass. Q7 lifts to **11/15 (73.3 %)** via a new typed
`op=abnormal`. Recall now surfaces a `supersession_hints[]` discovery
field instead of either hiding superseded episodes silently or
surfacing their stale narratives unsafely. Storage gains partial
indexes on the open subset of `lab_record` / `med_record` so
supersede UPDATEs scale with the open-subset cardinality, not the
full PK. Net: backwards-compatible — no v0.2.1 contract changes; one
new migration (`0008_supersession_partial_indexes.sql`).

### Added

- **`gnokee_lab_query` `op=abnormal`** (issue #18). Returns visible
  `lab_record` rows whose `abnormal_flag` is set within an optional
  `(since, until]` window. `analyte` is optional for this op so
  callers can ask "which electrolytes were abnormal?" without naming
  every analyte upfront; when supplied, it acts as a narrowing
  filter. Both bi-temporal half-pairs apply identically to the other
  read paths so retroactive corrections honour `as_of` / `valid_at`.
- **`gnokee_recall.supersession_hints[]`** (issue #19, ADR-0009 status
  note). When cosine ranks a superseded episode in the top-K, recall
  now emits a `SupersessionHint(superseded_uuid, current_head_uuid,
  superseded_at)` instead of surfacing the stale narrative. Closes
  the v0.2.1 footgun where row-level data on unrelated analytes
  remained open while episode-level supersession hid the original
  panel from default recall. Decision: Option A+ (clinical-safe —
  stale narrative never surfaces; agent follows up via
  `gnokee_lab_query` / `gnokee_med_query` typed reads, or pins
  `as_of` pre-correction). Hint cap = 5 per recall;
  `RecallResponse.supersession_hints` defaults to empty list
  (backwards compatible).
- **`MetadataStore.chain_head_at(tenant, start_uuid, as_of)`** —
  read-only chain-walk used by retrieval to resolve hints to their
  current head. Bounded depth = 32 (matches `supersede`).

### Changed

- **`gnokee_lab_query.analyte` is now optional** at the typed-pipeline
  surface (`str | None`). It remains required for every op except
  `abnormal`. The validator raises `ValidationError("analyte is
  required")` for any other op when missing.

### Performance

- **Partial indexes on the open subset of `lab_record` / `med_record`**
  (issue #17, migration `0008_supersession_partial_indexes.sql`). New
  `lab_record_open_idx` and `med_record_open_idx` cover only rows
  where `asserted_until IS NULL` so `LabStore.supersede_matching` /
  `MedStore.supersede_matching` walk an index whose size is bounded by
  the open-subset cardinality instead of the full PK. Read paths
  (`latest`, `history`, `aggregate`, `abnormal`) are unaffected by
  design — they need closed-but-tx-time-valid rows for pre-correction
  `as_of` pins. Pure perf win; non-load-bearing for v0.2.1
  correctness (the PK still satisfies the UPDATE if the planner
  prefers it for any reason). Apply with `make migrate`.

### Evals

- Q7 re-spike on the v0.2.2 stack (`spike-q7` tenant,
  `--skip-ingest`) lifts headline pass = **11/15 (73.3 %)** (was
  10/15 / 66.7 % at v0.2.1 ship). `q_electrolyte_abnormal_q2` flips
  PARTIAL → **PASS** via the new typed `abnormal` op. Verdict stays
  ADOPT_WITH_GAPS.
- Q8 re-spike unchanged (16/16 — already at ADOPT ceiling at v0.2.1).

### CI / tooling

- **Dependabot** (PR #26) — weekly Monday updates for `pip` (root
  pyproject), `github-actions`, and `docker` (compose image tags).
  Eval-spike `requirements.txt` files deliberately excluded (frozen-
  in-time records per AGENTS.md spike workflow).
- **`pip-audit` CI job** (PR #26) — scans `pyproject.toml`-declared
  deps against the PyPI advisory DB on every push and PR. Currently
  green ("No known vulnerabilities found").
- **`gitleaks` CI job** (PR #26) — server-side secret-scan backup
  for the local pre-commit hook. Pinned to v8.21.2 to match
  `.pre-commit-config.yaml`.

### Migration

```sh
make migrate   # applies 0008_supersession_partial_indexes.sql
```

No application-code changes required for upgraders.

## [0.2.1] — 2026-05-09

Supersession-aware ingest. The named v0.2.0 follow-up gap closes:
correction episodes now propagate `asserted_until` to prior
`lab_record` + `med_record` rows and to `episode_metadata`. Q7's
`q_k_lowest_2024` flips from FAIL to PASS (typed `min` aggregation
now skips superseded values).

### Added

- **`EpisodeIn.corrects: UUID | None`** boundary signal. When set,
  declares this episode supersedes a prior one. Same-tenant only;
  corrected episode must exist; new `asserted_at` must be greater
  than the corrected episode's. Chain-walk follows `superseded_by`
  to the current head when the caller named a stale target.
- **3 new storage primitives.** `MetadataStore.supersede`
  (validates + walks the chain via `SELECT … FOR UPDATE` per hop;
  depth bound 32 raises `CorrectsChainError`),
  `LabStore.supersede_matching` (per-row `(analyte, valid_at)`
  UPDATE), `MedStore.supersede_matching` (per-row
  `(drug_name, event_kind, valid_at)` UPDATE). All parameterised on
  `tenant_id` + the chain-walk-resolved head's `episode_uuid`.
- **4 new typed errors:** `CorrectsError` (base) +
  `EpisodeNotFoundError`, `CorrectsCrossTenantError`,
  `CorrectsAxisInversionError`, `CorrectsChainError`. All subclass
  `VectorStoreError`, so the existing Stage 6 compensate path rolls
  back the Graphiti episode.
- **Module-level `ingest_episode(...)` helper** gains
  `corrects: UUID | None = None`. Backwards-compatible.
- **Stage 6 wiring.** Supersession runs inside the existing
  single-txn block, between the `metadata.write` insert (which
  guards `_OurIdRaceLost`) and the `vector.write_embedding` insert.
  On row-level partial-key UPDATE (count < `len(keys)`), Stage 6
  logs a `WARNING` — surfaces parser drift on `valid_at` rounding
  rather than a silent zero-match.
- **11-case integration suite** at
  `tests/integration/test_supersession_e2e.py`: lab + med happy
  paths, episode-metadata supersession, aggregation respects
  supersession (Q7's named bug), cross-tenant rejection, episode
  not found, axis inversion, chained correction, empty new rows
  with corrects, idempotent replay, chain-walk from stale target.

### Fixed

- **Q7 `q_k_lowest_2024`** — typed `MIN(value_numeric)` over
  Potassium 2024 now returns 3.2 mmol/L (March, open) instead of
  2.8 mmol/L (April, superseded). Q7 verdict stays ADOPT_WITH_GAPS
  (10/15) — the fix is offset by a designed-correct regression on
  `q_electrolyte_abnormal_q2`: episode-metadata supersession hides
  the original April panel from default `gnokee_recall`, breaking
  a query that expected both the original (Mg LOW) and the
  correction. The agent should query `gnokee_lab_query` typed
  surface for abnormal-flag filtering, or pin `as_of` pre-correction.

### Spike harness

- Q7 + Q8 `ingest_corpus` helpers gain `corrects:` plumbing — read
  an optional `corrects: <our_id>` from corpus entries and resolve
  to the runtime `episode_uuid` via the harness's growing
  `our_id → episode_uuid` map. Corpus entries referencing
  `corrects:` MUST appear after their target in file order.
- Fresh re-spike tenants `spike-q7-v0_2_1` and `spike-q8-v0_2_1c`
  — re-running against the v0.2.0 tenants would short-circuit on
  `our_id` idempotency and skip Stage 6 entirely.
- Q8 extends to 16 queries: new `q_metoprolol_dose_corrected`
  exercises the corrects: signal on med-side via a synthetic
  Metoprolol start (25 mg) + correction (50 mg). Picked an
  orthogonal drug to avoid clashing with existing Lisinopril
  dose-pinned queries. Q8 re-spike: **16/16 (100 %)**, verdict
  stays ADOPT.

### Known limitations

- **Graphiti edge supersession is NOT auto-run.** Narrative
  corrections continue to flow through ADR-0008 contradiction
  surfacing. ADR-0009 boundary holds: graphiti owns prose, gnokee
  owns the typed half. Correcting an episode does not retract its
  edges from the graph.
- **Episode-metadata supersession hides original episodes from
  `gnokee_recall`** even when their unrelated rows (e.g. Mg LOW
  on a panel where only K was corrected) remain row-level open.
  Designed-correct per the bi-temporal model, but biases recall
  away from row-level data on superseded episodes. Workaround: use
  `gnokee_lab_query` / `gnokee_med_query` for typed reads, or pin
  `as_of` pre-correction for narrative recall.
- **Encrypted-body branch is unaffected** — `corrects` is
  metadata, orthogonal to the body shape. Encrypted-body remains
  `NotImplementedYet` per v0.1 guard.

## [0.2.0] — 2026-05-09

Typed clinical-data reads land — first net-new MCP surface since v0.1.
Closes the v0.1.x carry-over from ADR-0009 (Q7 labs OFF-RAMP at 13.3 %)
and ADR-0010 (Q8 meds ADOPT_WITH_GAPS at 53.3 %): structured Postgres
siblings to graphiti's narrative half preserve the numerics the
edge-fact LLM was stripping. Q7 lifts to 66.7 % (ADOPT_WITH_GAPS); Q8
lifts to **100 %** (ADOPT) once `event_kind` is rendered in human
form. Purely additive — no v0.1 contract changes.

### Added

- **`gnokee_lab_query` MCP tool** (ADR-0009) — typed reads against the
  new `lab_record` table. Ops: `latest | history | min | max | avg |
  count` over `(tenant, analyte, date_range)`. Returns parsed
  `value_numeric` / `unit` / `ref_range_*` / `abnormal_flag` plus the
  `episode_uuid` provenance handle. Both bi-temporal half-pairs
  mandatory.
- **`gnokee_med_query` MCP tool** (ADR-0010) — sibling typed reads
  over `med_record`. Ops: `active | history | allergies | switches`.
  `active` returns one row per drug whose latest visible event isn't
  `stop` / `allergy`; pin `valid_at` for historical "active on …".
- **`gnokee.extract.clinical.{lab_parser,med_parser}`** — pure-Python
  deterministic parsers. Lab: bullet-line panel shape (`- Analyte:
  value unit (ref: low-high)`). Med: sentence-boundary med-event
  shapes (`Started X N mg`, `Increased X from N to M mg`,
  `Discontinued X`, `Allergy documented: X`). Never raise; empty
  parse → no rows.
- **Stage 6 ingest writes lab + med rows** — `IngestPipeline.ingest()`
  Stage 6 now writes `lab_record` + `med_record` rows inside the same
  Postgres txn as `episode_metadata` + `content_embedding`, so
  retroactive corrections stay atomic with the narrative episode.
- **`gnokee.{lab_query,med_query}` orchestrators** — sit between the
  MCP layer and the storage adapters; clean tach boundary (mcp does
  not reach into `gnokee.storage.*` directly).
- **Integration tests** — `tests/integration/test_clinical_lab_e2e.py`
  + `tests/integration/test_clinical_med_e2e.py`. 11 tests covering
  ingest writes, all typed-read ops, valid_at-pinned active, tenant
  isolation, against real Postgres + Neo4j + TEI.
- **Re-spike harnesses** — Q7 + Q8 `queries.yaml` gained per-query
  `typed: {tool, op, args}` blocks; spike `run.py` merges typed
  responses into `value_substring` grading. Recall path stays as
  v0.1.1 baseline reference, typed calls are additive.
- **Docs** — new `docs/specs/v0.2.md` captures the additive surface;
  ADR-0009 / ADR-0010 status notes amended with v0.2 headline +
  remaining-gap inventory; README tools-surfaced list expanded.
- **noggin sister repo** — bumped 0.0.1 → 0.0.2 with prompt guidance
  teaching the agent when to reach for the typed clinical tools.

### Known limitations

- **Supersession-aware ingest is incomplete.** A correction episode
  writes a new `lab_record` row but does not set `asserted_until` on
  the prior row — visible `MIN(value_numeric)` therefore still
  includes superseded values. Tracked as v0.2.1 candidate; needs an
  explicit `corrects: episode_uuid` signal from the caller per
  ADR-0009.
- **Q7 5/15 still partial** (cross-domain narrative, count→episode
  backfill, multi-analyte abnormal filter, narrative-only correction
  audit). Documented in ADR-0009 status notes.

## [0.1.2] — 2026-05-09

Cheap-path recall improvements and v0.2 schema groundwork. Q8 (med
supersession) lifts from 53.3 % → 73.3 % (ADOPT_WITH_GAPS) on the same
graph just from recall-side changes. v0.2 implementation follows under
ADR-0009 + ADR-0010.

### Added

- **`med_event` preprocessor rule** (`src/gnokee/extract/rules/med_event.py`)
  — fifth deterministic rule lifting `Started X N mg` / `Increased X
  from N to M mg` / `Discontinued X` / `Allergy documented: X` shapes
  into short SVO derived sentences so graphiti's edge-fact extractor
  preserves the drug-name + dose tuple. ADR-0010 cheap-path piece.
- **Med-aware excerpt path** (`src/gnokee/excerpts.py`) —
  `query_wants_excerpt` now fires on med tokens (`medication / dose /
  allergic / mg / mcg / mEq / drug-class names`); new `find_med_excerpt`
  surfaces verbatim Episodic.content med-event lines as a sibling to
  `find_currency_excerpt`. Body-side finders are English-aware for
  v0.1.x; non-EN bodies fall back to facts and v0.2 typed reads.
- **Date prefix on excerpts** — every `Excerpt.text` is prepended with
  `[YYYY-MM-DD]` from the episode `valid_at`, so date-asking variants
  ("when was the renovation invoice?") can quote the date even when
  the body says "today". Inner `max_chars` adjusts so total stays ≤
  `DEFAULT_EXCERPT_CHARS`.
- **Recency rerank** (stage 3c) — when the query carries a temporal-
  current marker (`currently / now / today / latest / current / active /
  am i on / am i taking`), the cosine top-K is sorted by `valid_at` desc
  before fact fetch, so "what am I currently on?" picks the most recent
  semantically-near episode instead of the highest cosine match.
  English markers only; non-EN time-pin reads land in v0.2 typed
  `med_record` / `lab_record`. Unit-tested via `_query_wants_recency` +
  `_sort_by_recency`.
- **`lab_record` schema** (`migrations/0006_lab_record.sql`) — Postgres
  table per ADR-0009. Stores parsed analyte / value_numeric / unit /
  ref_range / abnormal_flag with bi-temporal half-pairs matching
  `episode_metadata`. ON DELETE CASCADE so tenant forgetting is clean.
  Indexes for time-pin / range / supersession reads.
- **`med_record` schema** (`migrations/0007_med_record.sql`) — sibling
  Postgres table per ADR-0010 with drug_name / drug_class / dose /
  event_kind. Partial indexes for drug-class history (NOT NULL) and
  allergy lookups (`event_kind = 'allergy'`).

### Fixed

- **`bootstrap.py` silent-leak footgun** —
  `build_app(settings)` now refuses to boot when `openai_base_url`
  targets `api.openai.com/v1` AND `openai_api_key` is empty. Previously
  fell back to `api_key="unused"` and 401'd mid-ingest on every
  graphiti extraction call. Self-hosted endpoints (litellm / ollama /
  vllm OpenAI-compat) keep working with no key.
- **Q7 / Q8 spike harness `--skip-ingest`** — both referenced a
  nonexistent `app.metadata._pool`; corrected to `app.pool` so
  re-grading against an existing tenant works without re-ingest cost.

### Validation

- 117 / 117 unit tests green (10 new for retrieval helpers, 11 new for
  med excerpts, 11 new for `med_event`, 5 new for bootstrap pre-flight).
- 22 integration tests against the live compose stack (smoke updated
  for migrations 0006 + 0007).
- Q8 spike re-grade against `spike-q8` tenant: **53.3 % → 73.3 %**
  (`ADOPT_WITH_GAPS`). Q7 spike unchanged at 13.3 % `OFF-RAMP` (typed
  `lab_record` table is the right v0.2 fix, not the cheap path).
- Downstream noggin real-corpus suite: 6 / 7 (one likely-flaky LLM-
  variance test on a query with no recall-path-affecting keywords).

## [0.1.1] — 2026-05-08

Patch release focused on extraction quality on real-corpus shapes that
the v0.1 surface left under-served. Spec gates from v0.1 stay green;
no public-API breakage.

### Added

- **Pre-extraction preprocessor** (`src/gnokee/extract/`) — a deterministic
  pass that augments the body sent to graphiti's edge-fact extractor with
  derived sentences for shapes the LLM tends to drop. Three rules ship:
  `identifier` (numbered references such as ADR-025, Q1, P1.3), `ranked_list`
  (top-of-stack / P-prefix / ordered-list priority), and `table_amount`
  (pipe-table currency rows). Closes #2 / #3 / #4.
- **`currency_anchor` rule** — fourth preprocessor rule covering the two
  non-pipe-table shapes the original `table_amount` rule cannot reach:
  bold list-item totals (`- **Total spent: 14,225.45**`) and bold
  declarative currency lines (`**€14,225 spent through 20.04.2026.**`).
  Pairs the amount with the document's first H1 so derived sentences
  read like `Sofia Apartment: €14,225 spent through 20.04.2026
  (Renovation — actuals).`. Closes #6 (layer 2 piece).
- **`gnokee_recall` body excerpts** — `RecallResponse.excerpts[]` now
  surfaces verbatim `Episodic.content` lines containing currency or
  amount-keyword digits when the query is amount-bearing. Recall reserves
  ~⅓ of `max_tokens` for the excerpt slice so the LLM-summarised fact
  list cannot crowd out the verbatim numerics. Tool description nudges
  the agent to quote excerpts when answering numeric questions.
  Closes #7. New leaf module `gnokee.excerpts` (pure helpers).
- **`Excerpt` model** on the public surface
  (`src/gnokee/models.py`) and serialised by the `gnokee_recall` MCP tool.
- **`GraphitiStore.fetch_episode_contents`** — batch episode-body fetch
  in one Cypher round-trip, used by the recall excerpt stage.
- **`our_id` idempotency** on `EpisodeIn` — re-ingest with the same
  `(tenant_id, our_id)` returns the existing receipt and skips graphiti
  extraction, vector write, and contradiction detection.

### Changed

- **Currency pattern** in both ingest- and recall-side scanners now
  matches the EU-suffix shape (`1,000 €`) in addition to the prefix
  form (`€1,000`).
- **TEI embeddings** — client-side batch chunking + `truncate=true`
  makes the embedder resilient to long inputs without surfacing
  413/max-token errors at ingest time.

### Validation

- 79/79 unit tests green (12 new for excerpts, 13 new for
  `currency_anchor`).
- 21/21 integration tests against the live compose stack.
- Downstream noggin real-corpus suite goes from 4/4 → 7/7 passing
  (the three previously known recall gaps from #2 / #3 / #4 are now
  promoted to tests and pass).

## [0.1.0] — 2026-05-08

Initial release. Spec frozen, gates green.

### Added

- Ingest pipeline (`src/gnokee/ingest.py`): tenant-validated ingress,
  `valid_at` / `asserted_at` half-pair invariants, content-embedding
  via TEI, graphiti `add_episode` extraction, contradiction detection.
- Recall pipeline (`src/gnokee/retrieval.py`): six-stage recall with
  bi-temporal filtering, pgvector rerank, Cypher fact fetch, Q3
  response shaping (~125 median tokens, 67 % win vs graphiti raw).
- Q4 contradiction surface — `unrelated | refinement | update |
  contradiction` 4-label classifier; persisted as symmetric edges in
  Postgres `fact_contradiction`; surfaced on recall, never auto-resolved.
- MCP server (`src/gnokee/mcp.py`): `gnokee_ingest_episode`,
  `gnokee_recall`, `gnokee_fact_provenance`. stdio transport.
- Postgres schema (Alembic migrations): `episode_metadata`,
  `content_embedding` (1024-dim bge-m3, HNSW), `fact_contradiction`,
  RLS gated on `app.current_tenant` GUC.
- Neo4j 5 Community via graphiti-core 0.29; gnokee-managed HNSW
  indexes on `name_embedding` + `fact_embedding`.
- Docker compose for the v0.1 stack (`gnokee-postgres`, `gnokee-neo4j`,
  `gnokee-tei`); arm64 platform pin for TEI on Apple Silicon (Rosetta).
- Eval spikes Q1–Q5 under `evals/` validating the v0.1 architecture.

[0.1.2]: https://github.com/omurlabs/gnokee/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/omurlabs/gnokee/compare/v0.1...v0.1.1
[0.1.0]: https://github.com/omurlabs/gnokee/releases/tag/v0.1
