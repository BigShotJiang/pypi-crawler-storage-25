# SPDX-License-Identifier: Apache-2.0
# Copyright 2025 Abdelhak Zabour
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# ---------------------------------------------------------------------
# MIT-LICENSED PORTIONS (ATTRIBUTION)
# Portions of this file are derived from mcp-vertica by nolleh
# https://github.com/nolleh/mcp-vertica
# Copyright (c) 2024-2025 nolleh
# Licensed under the MIT License (see LICENSE for full text)
# ---------------------------------------------------------------------

"""Server module for Vertica MCP. Provides API endpoints and database utilities."""


import asyncio
import hashlib
import logging
import os
import re
import socket
import sys
import time
import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import datetime
from functools import lru_cache
from typing import Any

import jwt
import uvicorn
import vertica_python
from dotenv import find_dotenv, load_dotenv
from jwt import PyJWKClient
from mcp.server.fastmcp import Context, FastMCP
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.cors import CORSMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from vertica_mcp.connection import (
    OperationType,
    VerticaConfig,
    VerticaConnectionManager,
)


class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.method == "OPTIONS":
            return await call_next(request)

        issuer = os.getenv("JWT_ISSUER")
        audience = os.getenv("JWT_AUDIENCE")

        if not issuer or not audience:
            # Fallback to API Key if JWT is not configured
            api_key = os.getenv("MCP_API_KEY")
            if api_key:
                auth_header = request.headers.get("Authorization")
                if not auth_header or auth_header != f"Bearer {api_key}":
                    return JSONResponse({"error": "Unauthorized"}, status_code=401)
            return await call_next(request)

        auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            return JSONResponse(
                {"error": "Unauthorized: Missing or invalid Bearer token"},
                status_code=401,
            )

        token = auth_header.split(" ")[1]
        try:
            jwks_client = PyJWKClient(f"{issuer.rstrip('/')}/.well-known/jwks.json")
            signing_key = jwks_client.get_signing_key_from_jwt(token)
            jwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                audience=audience,
                issuer=issuer,
            )
        except jwt.ExpiredSignatureError:
            logging.getLogger("vertica-mcp").warning("JWT token has expired")
            return JSONResponse(
                {"error": "Unauthorized: Token has expired"}, status_code=401
            )
        except jwt.InvalidTokenError as e:
            # SECURITY: Log details server-side but return generic message to prevent information disclosure
            logging.getLogger("vertica-mcp").warning(
                f"JWT validation failed: {type(e).__name__} - {str(e)}"
            )
            return JSONResponse(
                {"error": "Unauthorized: Invalid token"}, status_code=401
            )
        except Exception as e:
            # SECURITY: Generic error message to prevent leaking JWT configuration details
            logging.getLogger("vertica-mcp").error(
                f"Unexpected JWT error: {type(e).__name__} - {str(e)}"
            )
            return JSONResponse(
                {"error": "Unauthorized: Authentication error"}, status_code=401
            )

        return await call_next(request)


MCP_SERVER_NAME = "vertica-mcp"
DEPENDENCIES = [
    "vertica-python",
    "pydantic",
    "starlette",
    "uvicorn",
    "pyjwt",
    "cryptography",
]

# Configure logging
logger = logging.getLogger("vertica-mcp")

# Configuration from environment
QUERY_TIMEOUT = int(os.getenv("VERTICA_QUERY_TIMEOUT", "600"))  # 10 minutes default
MAX_RETRY_ATTEMPTS = int(os.getenv("VERTICA_MAX_RETRIES", "3"))
RETRY_DELAY_BASE = float(os.getenv("VERTICA_RETRY_DELAY", "1.0"))
CACHE_TTL_SECONDS = int(os.getenv("VERTICA_CACHE_TTL", "300"))  # 5 minutes
MAX_RESULT_SIZE_MB = int(os.getenv("VERTICA_MAX_RESULT_MB", "100"))
RATE_LIMIT_PER_MINUTE = int(os.getenv("VERTICA_RATE_LIMIT", "60"))

# Query execution constants (previously magic numbers)
DEFAULT_ROW_LIMIT = 1000  # Auto-applied LIMIT for queries without one
PREVIEW_ROW_COUNT = 50  # Number of rows shown in preview
MAX_PAGINATION_ROWS = 100  # Maximum rows per page in pagination
CONNECTION_HEALTH_CHECK_INTERVAL = int(os.getenv("VERTICA_HEALTH_CHECK_INTERVAL", "60"))

# Cache for metadata queries
metadata_cache: dict[str, tuple[Any, float]] = {}
# Rate limiting tracking
rate_limit_tracker: dict[str, list[float]] = {}


def _strip_sql_comments(q: str) -> str:
    # remove /* ... */ and -- ... EOL
    q = re.sub(r"/\*.*?\*/", "", q, flags=re.S)
    q = re.sub(r"--[^\n]*", "", q)
    return q


def _is_select(query: str) -> bool:
    """SELECT-like statements (WITH/SELECT/EXPLAIN/PROFILE)."""
    q = _strip_sql_comments(query).strip()
    while q.startswith("(") and q.endswith(")"):
        q = q[1:-1].strip()
    return re.match(r"^(WITH|SELECT|EXPLAIN|PROFILE)\b", q, flags=re.I) is not None


def _wrap_subquery(sql: str) -> str:
    """Wrap a subquery in a SELECT statement."""
    sql = sql.replace(";", "").strip()
    return f"SELECT * FROM ({sql}) q"


def _sanitize_query(query: str) -> str:
    """
    Enhanced SQL injection prevention with whitelist validation.

    SECURITY STRATEGY:
    1. Whitelist-based: Only allow safe read-only operations
    2. Blacklist dangerous patterns as defense-in-depth
    3. Detect common injection techniques
    """
    if not query or not isinstance(query, str):
        raise ValueError("Query must be a non-empty string")

    query_trimmed = query.strip()
    query_upper = query_trimmed.upper()

    # WHITELIST: Only allow read-only operations
    allowed_statements = ("SELECT", "WITH", "EXPLAIN", "SHOW", "DESCRIBE", "DESC")
    if not query_upper.startswith(allowed_statements):
        raise ValueError(
            f"Only read-only queries are allowed (SELECT, WITH, EXPLAIN, SHOW, DESCRIBE). "
            f"Query starts with: {query_trimmed[:50]}"
        )

    # BLACKLIST: Comprehensive dangerous pattern detection (defense-in-depth)
    dangerous_patterns = [
        (
            r";\s*(DROP|DELETE|UPDATE|INSERT|ALTER|CREATE|TRUNCATE|GRANT|REVOKE)\s+",
            "SQL command injection",
        ),
        (r"(xp_cmdshell|sp_executesql|exec\s*\()", "Command execution attempt"),
        (r"(EXPORT_OBJECTS|COPY\s+.*\s+TO)", "Vertica-specific data exfiltration"),
        (r"--[^\n]*\bOR\b", "Comment-based SQL injection"),
        (r"/\*.*\bOR\b.*\*/", "Block comment injection"),
        (r"\bUNION\s+ALL\s+SELECT", "UNION-based injection"),
        (r"\bOR\s+['\"]?\d+['\"]?\s*=\s*['\"]?\d+", "Boolean-based injection (OR 1=1)"),
        (
            r"\bAND\s+['\"]?\d+['\"]?\s*=\s*['\"]?\d+",
            "Boolean-based injection (AND 1=1)",
        ),
        (r"';.*--", "SQL termination with comment"),
        (r"\b(SLEEP|WAITFOR|BENCHMARK|PG_SLEEP)\s*\(", "Time-based blind injection"),
    ]

    for pattern, description in dangerous_patterns:
        if re.search(pattern, query, re.IGNORECASE):
            raise ValueError(f"Security violation: {description} detected in query")

    # Check for excessive length (potential DoS)
    if len(query) > 50000:  # 50KB max
        raise ValueError(
            f"Query too long ({len(query)} chars). Maximum 50,000 characters allowed."
        )

    return query


def _check_rate_limit(client_id: str) -> bool:
    """Check if client has exceeded rate limit."""
    now = time.time()
    if client_id not in rate_limit_tracker:
        rate_limit_tracker[client_id] = []

    # Clean old entries
    rate_limit_tracker[client_id] = [
        t for t in rate_limit_tracker[client_id] if now - t < 60
    ]

    if len(rate_limit_tracker[client_id]) >= RATE_LIMIT_PER_MINUTE:
        return False

    rate_limit_tracker[client_id].append(now)
    return True


def _extract_client_id_from_auth(ctx) -> str:
    """Extract client ID from authorization context for rate limiting.

    For stateless HTTP sessions where ctx.request_context doesn't have client_id,
    this extracts a stable identifier from the Authorization header.

    Args:
        ctx: The MCP context object

    Returns:
        A stable client identifier string for rate limiting
    """
    # Try to get from request headers if available
    request = getattr(ctx.request_context, "request", None)
    if request and hasattr(request, "headers"):
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            # Use hash of API key as client identifier
            key = auth_header[7:]  # Remove "Bearer " prefix
            return hashlib.sha256(key.encode()).hexdigest()[:16]

    # Fallback for stateless sessions without auth header
    return "stateless-http-client"


@lru_cache(maxsize=128)
def _get_cached_metadata(cache_key: str) -> Any | None:
    """Get cached metadata if not expired."""
    if cache_key in metadata_cache:
        data, timestamp = metadata_cache[cache_key]
        if time.time() - timestamp < CACHE_TTL_SECONDS:
            return data
        else:
            del metadata_cache[cache_key]
    return None


def _set_cached_metadata(cache_key: str, data: Any):
    """Set metadata cache with timestamp."""
    metadata_cache[cache_key] = (data, time.time())


async def _validate_connection(conn) -> bool:
    """Validate database connection is alive."""
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()
        cursor.close()
        return True
    except Exception:
        return False


async def _execute_query_async(
    manager: VerticaConnectionManager,
    query: str,
    params: Any = None,
    fetch: str = "all",
    timeout: int = 30,
    commit: bool = False,
    max_rows: int = 1000,
) -> Any:
    """Safely execute a query in a background thread without blocking the async event loop."""

    # SECURITY: Validate timeout is an integer to prevent SQL injection
    try:
        timeout = int(timeout)
        if timeout < 1 or timeout > 3600:  # 1 second to 1 hour max
            raise ValueError(
                f"timeout must be between 1 and 3600 seconds, got {timeout}"
            )
    except (TypeError, ValueError) as e:
        raise ValueError(f"Invalid timeout parameter: {e}")

    def _sync_execute():
        conn = manager.get_connection()
        try:
            cursor = conn.cursor()
            # Safe: timeout is now guaranteed to be an integer after validation above
            cursor.execute(f"SET SESSION RUNTIMECAP '{timeout}s'")
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)

            result = None
            if fetch == "all":
                result = cursor.fetchall(), (
                    [col[0] if isinstance(col, tuple) else getattr(col, 'name', col[0]) for col in cursor.description]
                    if cursor.description
                    else []
                )
            elif fetch == "many":
                result = cursor.fetchmany(max_rows), (
                    [col[0] if isinstance(col, tuple) else getattr(col, 'name', col[0]) for col in cursor.description]
                    if cursor.description
                    else []
                )
            elif fetch == "none":
                result = getattr(cursor, "rowcount", None), []

            if commit:
                conn.commit()

            return result
        except vertica_python.errors.Error as e:
            logger.error(f"Database error executing query: {e}")
            raise
        finally:
            manager.release_connection(conn)

    return await asyncio.to_thread(_sync_execute)


def extract_operation_type(query: str) -> OperationType | None:
    """Extract the operation type from a SQL query."""
    query = query.strip().upper()

    if query.startswith("INSERT"):
        return OperationType.INSERT
    elif query.startswith("UPDATE"):
        return OperationType.UPDATE
    elif query.startswith("DELETE"):
        return OperationType.DELETE
    elif any(query.startswith(op) for op in ["CREATE", "ALTER", "DROP", "TRUNCATE"]):
        return OperationType.DDL
    return None


def extract_schema_from_query(query: str) -> str | None:
    """Extract the schema from a SQL query."""
    q = query.strip().lower()
    m = re.search(r"([a-zA-Z0-9_]+)\.[a-zA-Z0-9_]+", q)
    if m:
        return m.group(1)
    return None


def _print_banner(
    transport: str, endpoint: str | None, *, to_stderr: bool = False
) -> None:
    """Pretty banner without polluting STDOUT for stdio."""
    out = sys.stderr if to_stderr else sys.stdout
    width = 100

    print(f"\n╔{'═' * width}╗", file=out, flush=True)
    print(f"║{'Vertica MCP Server':^{width}}║", file=out, flush=True)
    print(f"╠{'═' * width}╣", file=out, flush=True)

    # Transport line
    pad_t = width - len("  Transport : ")  # account for borders
    print(f"║  Transport : {transport:<{pad_t}}║", file=out, flush=True)

    # Endpoint line (optional, truncated if too long)
    if endpoint:
        max_ep_len = width - len("  Endpoint  : ")
        ep = (
            endpoint
            if len(endpoint) <= max_ep_len
            else endpoint[: max_ep_len - 1] + "…"
        )
        print(f"║  Endpoint  : {ep:<{max_ep_len}}║", file=out, flush=True)

    # Status line
    pad_s = width - len("  Status    : Ready")
    print(f"║  Status    : Ready{' ' * pad_s}║", file=out, flush=True)
    print(f"╚{'═' * width}╝\n", file=out, flush=True)


async def run_stdio() -> None:
    """Launch the MCP server with STDIO transport (safe banner on STDERR)."""
    logger.info("Starting MCP server with STDIO transport")

    _print_banner("STDIO", None, to_stderr=True)
    print(
        "📝 Connect MCP clients via STDIO integration (no URL)",
        file=sys.stderr,
        flush=True,
    )

    # Prefer the async stdio runner if present
    if hasattr(mcp, "run_stdio_async"):
        await mcp.run_stdio_async()
    else:
        # Fallback: run the blocking mcp.run() (which calls anyio.run) in a worker thread
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, mcp.run)


@asynccontextmanager
async def server_lifespan(_server: FastMCP) -> AsyncIterator[dict[str, Any]]:
    """Server lifespan context manager with improved error handling."""

    # SECURITY FIX (P2-3): Use absolute paths to prevent directory traversal
    # Load environment with secure fallback methods
    env_loaded = False

    # Method 1: Explicit path from module location (most secure)
    module_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    env_path = os.path.abspath(os.path.join(module_dir, ".env"))

    if os.path.exists(env_path):
        load_dotenv(env_path, override=False)
        logger.info(f"Loaded environment from {env_path}")
        env_loaded = True
    else:
        # Method 2: Try find_dotenv (walks up directory tree safely)
        try:
            found_env = find_dotenv(usecwd=True)
            if found_env and os.path.exists(found_env):
                load_dotenv(found_env, override=False)
                logger.info(f"Loaded environment from {found_env}")
                env_loaded = True
        except Exception as e:
            logger.debug(f"find_dotenv failed: {e}")

    if not env_loaded:
        load_dotenv()  # Try default (uses os.environ)
        logger.warning("Using system environment variables or defaults")

    # --- Startup configuration validation (fail-fast for critical settings) ---
    jwt_issuer = os.getenv("JWT_ISSUER")
    jwt_audience = os.getenv("JWT_AUDIENCE")
    if jwt_issuer or jwt_audience:
        # Both must be set if either is present
        if not jwt_issuer:
            raise OSError(
                "JWT_AUDIENCE is set but JWT_ISSUER is missing. Both must be configured together."
            )
        if not jwt_audience:
            raise OSError(
                "JWT_ISSUER is set but JWT_AUDIENCE is missing. Both must be configured together."
            )
        # Validate issuer looks like a URL
        if not jwt_issuer.startswith(("http://", "https://")):
            raise OSError(
                f"JWT_ISSUER must be a valid HTTP/HTTPS URL, got: {jwt_issuer!r}"
            )
        logger.info(
            f"JWT authentication enabled: issuer={jwt_issuer}, audience={jwt_audience}"
        )
    else:
        api_key = os.getenv("MCP_API_KEY")
        if api_key:
            logger.info("API key authentication enabled (JWT not configured)")
        else:
            # CRITICAL SECURITY: Refuse to start without authentication in production
            raise OSError(
                "SECURITY ERROR: No authentication configured. Server cannot start without authentication. "
                "Set JWT_ISSUER + JWT_AUDIENCE for JWT auth, or MCP_API_KEY for API key auth. "
                "This check prevents accidental deployment of an unauthenticated server."
            )

    manager = None
    retry_count = 0
    max_init_retries = 3

    while retry_count < max_init_retries:
        try:
            manager = VerticaConnectionManager()
            config = VerticaConfig.from_env()

            # Validate configuration
            if not config.host or not config.database:
                raise ValueError("Missing required database configuration")

            logger.info(
                f"Vertica config: host={config.host} port={config.port} "
                f"db={config.database} user={config.user} ssl={config.ssl}"
            )

            # Test TCP connectivity
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(10)
                result = sock.connect_ex((config.host, config.port))
                sock.close()

                if result != 0:
                    raise ConnectionError(f"TCP connection failed with code {result}")

                logger.info("✅ TCP connectivity successful")
            except Exception as e:
                logger.error(f"❌ Network connectivity test failed: {e}")
                raise

            # Initialize connection manager
            manager.initialize_default(config)
            logger.info("Connection manager initialized")

            # Test database connection
            conn = None
            try:
                conn = manager.get_connection()
                if await _validate_connection(conn):
                    cursor = conn.cursor()
                    cursor.execute("SELECT version()")
                    version = cursor.fetchone()[0]
                    logger.info(f"✅ Connected to Vertica: {version}")
                    cursor.close()
                    break  # Success
                else:
                    raise ConnectionError("Connection validation failed")

            finally:
                if conn:
                    manager.release_connection(conn)

        except Exception as e:
            retry_count += 1
            logger.error(
                f"Initialization attempt {retry_count}/{max_init_retries} failed: {e}"
            )

            if retry_count < max_init_retries:
                await asyncio.sleep(2**retry_count)  # Exponential backoff
            else:
                logger.error("Failed to initialize after all retries")
                # Continue anyway but mark as degraded

    # Start background health check task
    health_check_task = None
    if manager:

        async def health_check_loop():
            while True:
                try:
                    await asyncio.sleep(CONNECTION_HEALTH_CHECK_INTERVAL)
                    conn = manager.get_connection()
                    if not await _validate_connection(conn):
                        logger.warning("Health check failed, attempting reconnection")
                        # Trigger reconnection logic here
                    manager.release_connection(conn)
                except Exception as e:
                    logger.error(f"Health check error: {e}")

        health_check_task = asyncio.create_task(health_check_loop())

    try:
        yield {"vertica_manager": manager, "health_task": health_check_task}
    finally:
        if health_check_task:
            health_check_task.cancel()
        if manager:
            try:
                manager.close_all()
                logger.info("Closed all Vertica connections")
            except Exception as e:
                logger.error(f"Error closing connections: {e}")


# Create FastMCP instance with SSE support
mcp = FastMCP(
    MCP_SERVER_NAME,
    dependencies=DEPENDENCIES,
    lifespan=server_lifespan,
    stateless_http=True,
)


# Add CORS configuration for SSE app
async def run_sse(host: str = "localhost", port: int = 8000) -> None:
    """Launch the MCP server with HTTP-SSE transport."""
    logger.info(f"Starting MCP server with SSE transport on {host}:{port}")

    sse_app = mcp.sse_app()

    # Add auth middleware
    sse_app.add_middleware(AuthMiddleware)

    # SECURITY: CORS configuration with credential safety validation
    cors_origins_str = os.getenv("MCP_CORS_ORIGINS", "")
    if not cors_origins_str:
        logger.warning(
            "MCP_CORS_ORIGINS not set. CORS will block all cross-origin requests. "
            "Set explicit origins for production (e.g., 'https://app.example.com,https://admin.example.com')"
        )
        cors_origins = []
    else:
        cors_origins = [o.strip() for o in cors_origins_str.split(",") if o.strip()]

        # CRITICAL SECURITY CHECK: Forbid wildcard with credentials
        if "*" in cors_origins:
            raise OSError(
                "SECURITY ERROR: Cannot use CORS wildcard (*) with allow_credentials=True. "
                "This combination allows any website to steal user credentials. "
                "Set MCP_CORS_ORIGINS to explicit domain list: 'https://app1.com,https://app2.com'"
            )

    # Add CORS middleware
    sse_app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Banner to STDOUT is fine for network transports
    _print_banner("SSE", f"http://{host}:{port}")

    # Friendly hint
    print(f"🔌 Connect MCP clients to: http://{host}:{port}/sse", flush=True)

    config = uvicorn.Config(
        sse_app,
        host=host,
        port=port,
        log_level="info",
        access_log=True,
        use_colors=True,
        timeout_keep_alive=30,
        limit_max_requests=1000,
    )
    server = uvicorn.Server(config)

    try:
        await server.serve()
    except KeyboardInterrupt:
        logger.info("Received interrupt signal, shutting down gracefully")
    except Exception as e:
        logger.error(f"Server error: {e}")
        raise


async def run_http(
    host: str = "127.0.0.1",
    port: int = 8000,
    path: str = "/mcp",
    json_response: bool = True,
    stateless_http: bool = True,
) -> None:
    """Launch the MCP server with Streamable HTTP transport."""
    logger.info(f"Starting MCP server with Streamable HTTP on {host}:{port}{path}")

    mcp.settings.host = host
    mcp.settings.port = port
    mcp.settings.streamable_http_path = path
    mcp.settings.json_response = json_response
    mcp.settings.stateless_http = stateless_http

    # Banner to STDOUT is fine for network transports
    _print_banner("Streamable HTTP", f"http://{host}:{port}{path}")

    app = mcp.streamable_http_app()

    # Add auth middleware
    app.add_middleware(AuthMiddleware)

    # SECURITY: CORS configuration with credential safety validation
    cors_origins_str = os.getenv("MCP_CORS_ORIGINS", "")
    if not cors_origins_str:
        logger.warning(
            "MCP_CORS_ORIGINS not set. CORS will block all cross-origin requests. "
            "Set explicit origins for production (e.g., 'https://app.example.com,https://admin.example.com')"
        )
        cors_origins = []
    else:
        cors_origins = [o.strip() for o in cors_origins_str.split(",") if o.strip()]

        # CRITICAL SECURITY CHECK: Forbid wildcard with credentials
        if "*" in cors_origins:
            raise OSError(
                "SECURITY ERROR: Cannot use CORS wildcard (*) with allow_credentials=True. "
                "This combination allows any website to steal user credentials. "
                "Set MCP_CORS_ORIGINS to explicit domain list: 'https://app1.com,https://app2.com'"
            )

    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    config = uvicorn.Config(
        app,
        host=host,
        port=port,
        log_level="info",
        access_log=True,
        use_colors=True,
        timeout_keep_alive=30,
        limit_max_requests=1000,
    )
    server = uvicorn.Server(config)

    try:
        await server.serve()
    except KeyboardInterrupt:
        logger.info("Received interrupt signal, shutting down gracefully")
    except Exception as e:
        logger.error(f"Server error: {e}")
        raise


# --------------------------------------------
# ---------- Run Query Safely ------------------
# --------------------------------------------
@mcp.tool()
async def run_query_safely(
    ctx: Context,
    query: str,
    row_threshold: int = 1000,
    proceed: bool = False,
    mode: str = "page",
    page_limit: int = 2000,
    include_columns: bool = True,
    precount: bool = False,
    timeout: int | None = None,
) -> dict:
    """
    Safe query execution with size detection, pagination, and timeout support.

    Args:
        query: SQL query to execute
        row_threshold: Maximum rows before requiring confirmation
        proceed: Whether to proceed with large result set
        mode: Execution mode ('page' or 'stream')
        page_limit: Rows per page when paginating
        include_columns: Include column names in response
        precount: Count total rows for large results (expensive)
        timeout: Query timeout in seconds (default from env)
    """
    await ctx.info("run_query_safely called")

    # SECURITY FIX (P2-1): Rate limiting requires authenticated client_id
    # For stateless HTTP sessions, extract from Authorization header as fallback
    client_id = (
        getattr(ctx.request_context, "client_id", None)
        or getattr(ctx.request_context, "connection_id", None)
        or _extract_client_id_from_auth(ctx)
    )

    if not _check_rate_limit(client_id):
        raise RuntimeError(
            f"Rate limit exceeded for client {client_id[:8]}... "
            f"Maximum {os.getenv('VERTICA_RATE_LIMIT', '60')} requests per minute. "
            "Please wait before retrying."
        )

    # Sanitize query
    try:
        query = _sanitize_query(query)
    except ValueError as e:
        await ctx.error(f"Query validation failed: {e}")
        raise RuntimeError(f"Query validation failed: {e}")

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    # Permission checks
    schema = extract_schema_from_query(query)
    operation = extract_operation_type(query)
    if operation and not manager.is_operation_allowed(schema or "default", operation):
        msg = f"Operation {operation.name} not allowed for schema {schema}"
        await ctx.error(msg)
        raise RuntimeError(msg)

    # Set timeout
    query_timeout = timeout or QUERY_TIMEOUT

    # Auto-enforce LIMIT 1000 on unpaginated SELECT queries that have no LIMIT clause
    if _is_select(query) and not proceed:
        stripped_upper = _strip_sql_comments(query).upper()
        if not re.search(r"\bLIMIT\s+\d", stripped_upper):
            query = f"{_wrap_subquery(query)} LIMIT 1000"
            await ctx.info("Auto-applied LIMIT 1000 to unbounded SELECT query")

    # Non-SELECT execution
    if not _is_select(query):
        try:
            commit_needed = operation in [
                OperationType.INSERT,
                OperationType.UPDATE,
                OperationType.DELETE,
            ]
            affected, _ = await _execute_query_async(
                manager,
                query,
                fetch="none",
                timeout=query_timeout,
                commit=commit_needed,
            )
            await ctx.info(f"Non-SELECT executed, affected_rows={affected}")
            return {"ok": True, "affected_rows": affected}
        except vertica_python.errors.Error as e:
            msg = f"Database error executing statement: {e}"
            await ctx.error(msg)
            raise RuntimeError(msg) from e
        except Exception as e:
            logger.exception("Unexpected error executing non-select query")
            raise RuntimeError(f"Unexpected error: {e}") from e

    # SELECT query handling
    if not proceed:
        # Probe for size
        probe_limit = row_threshold + 1
        probe_sql = f"{_wrap_subquery(query)} LIMIT {probe_limit}"

        try:
            rows, cols = await _execute_query_async(
                manager, probe_sql, timeout=query_timeout
            )
            if not include_columns:
                cols = None

            is_large = len(rows) > row_threshold
            preview = rows[: min(50, len(rows))]

            exact_count = None
            if is_large and precount:
                await ctx.info("Computing exact COUNT(*)")
                count_rows, _ = await _execute_query_async(
                    manager, f"SELECT COUNT(*) FROM ({query}) q", timeout=query_timeout
                )
                exact_count = int(count_rows[0][0]) if count_rows else 0

            if not is_large:
                await ctx.info(f"Small result (<= {row_threshold})")
                return {
                    "ok": True,
                    "rows": rows,
                    "count": len(rows),
                    "done": True,
                    "columns": cols,
                    "large": False,
                }

            # Large result - require confirmation
            human_msg = (
                f"Large result detected (> {row_threshold} rows)"
                + (f": about {exact_count} rows." if exact_count else ".")
                + " Proceed?"
            )
            await ctx.warning(human_msg)

            return {
                "ok": True,
                "large": True,
                "requires_confirmation": True,
                "threshold": row_threshold,
                "exact_count": exact_count,
                "message": human_msg,
                "preview": preview,
                "columns": cols,
                "next_step": {
                    "tool": "run_query_safely",
                    "arguments": {
                        "query": query,
                        "row_threshold": row_threshold,
                        "proceed": True,
                        "mode": "page",
                        "page_limit": page_limit,
                        "include_columns": include_columns,
                    },
                },
            }

        except vertica_python.errors.Error as e:
            msg = f"Database error probing query: {e}"
            await ctx.error(msg)
            raise RuntimeError(msg) from e
        except Exception as e:
            logger.exception("Unexpected error probing query")
            raise RuntimeError(f"Unexpected error: {e}") from e

    # Proceed with large result
    await ctx.info(f"Proceeding with mode={mode}")

    if mode == "page":
        return await execute_query_paginated(
            ctx=ctx,
            query=query,
            limit=page_limit,
            offset=0,
            include_columns=include_columns,
            timeout=query_timeout,
        )
    elif mode == "stream":
        return await execute_query_stream(
            ctx=ctx,
            query=query,
            batch_size=max(page_limit, 1000),
            timeout=query_timeout,
        )
    else:
        raise RuntimeError(f"Unknown mode: {mode}")


# --------------------------------------------
# ---------- Execute Query Paginated ------------------
# --------------------------------------------
@mcp.tool()
async def execute_query_paginated(
    ctx: Context,
    query: str,
    limit: int = 2000,
    offset: int = 0,
    include_columns: bool = True,
    timeout: int | None = None,
) -> dict:
    """Execute query with pagination support and result size limits."""
    await ctx.info(f"Paginated query: limit={limit}, offset={offset}")

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    # Validate it's a SELECT
    op = extract_operation_type(query)
    if op:
        raise RuntimeError("Paginated execution only supports SELECT statements")

    paged_sql = f"{_wrap_subquery(query)} LIMIT {int(limit)} OFFSET {int(offset)}"
    query_timeout = timeout or QUERY_TIMEOUT

    try:
        rows, cols = await _execute_query_async(
            manager, paged_sql, timeout=query_timeout
        )
        if not include_columns:
            cols = None

        # Check result size
        import sys

        result_size = sys.getsizeof(rows) / (1024 * 1024)  # MB
        if result_size > MAX_RESULT_SIZE_MB:
            await ctx.warning(f"Result size ({result_size:.2f}MB) exceeds limit")
            rows = rows[: len(rows) // 2]  # Truncate to half

        done = len(rows) < limit

        return {
            "rows": rows,
            "count": len(rows),
            "next_offset": offset + len(rows),
            "done": done,
            "columns": cols,
        }

    except vertica_python.errors.Error as e:
        msg = f"Database error in paginated query: {str(e)}"
        await ctx.error(msg)
        raise RuntimeError(msg) from e
    except Exception as e:
        logger.exception("Unexpected error in paginated query")
        raise RuntimeError(f"Unexpected error: {str(e)}") from e


# --------------------------------------------
# ---------- Execute Query Stream ------------------
# --------------------------------------------
@mcp.tool()
async def execute_query_stream(
    ctx: Context,
    query: str,
    batch_size: int = 1000,
    max_rows: int = 100000,
    timeout: int | None = None,
) -> dict:
    """Stream query results with batching and size limits."""
    await ctx.info(f"Streaming query with batch_size={batch_size}")

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    schema = extract_schema_from_query(query)
    operation = extract_operation_type(query)
    if operation and not manager.is_operation_allowed(schema or "default", operation):
        raise RuntimeError(f"Operation {operation.name} not allowed")

    query_timeout = timeout or QUERY_TIMEOUT

    def _sync_stream():
        conn = cursor = None
        try:
            conn = manager.get_connection()
            cursor = conn.cursor()
            cursor.execute(f"SET SESSION RUNTIMECAP '{query_timeout}s'")
            cursor.execute(query)

            all_results = []
            total_rows = 0
            total_size_mb = 0
            import sys

            while True:
                batch = cursor.fetchmany(batch_size)
                if not batch:
                    break

                batch_size_mb = sys.getsizeof(batch) / (1024 * 1024)
                total_size_mb += batch_size_mb

                if total_size_mb > MAX_RESULT_SIZE_MB:
                    break

                total_rows += len(batch)
                all_results.extend(batch)

                if total_rows >= max_rows:
                    break

            return {
                "result": all_results,
                "total_rows": total_rows,
                "truncated": total_rows >= max_rows
                or total_size_mb >= MAX_RESULT_SIZE_MB,
                "size_mb": round(total_size_mb, 2),
            }

        except vertica_python.errors.Error as e:
            raise RuntimeError(f"Database stream error: {str(e)}") from e
        except Exception as e:
            raise RuntimeError(f"Unexpected stream error: {str(e)}") from e
        finally:
            if cursor:
                cursor.close()
            if conn:
                manager.release_connection(conn)

    try:
        return await asyncio.to_thread(_sync_stream)
    except Exception as e:
        error_msg = f"Stream error: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e


# --------------------------------------------
# ---------- Get Table Structure ------------------
# --------------------------------------------
@mcp.tool()
async def get_table_structure(
    ctx: Context, table_name: str, schema_name: str = "public"
) -> dict:
    """Get table structure with caching support."""
    cache_key = f"table_structure:{schema_name}.{table_name}"
    cached = _get_cached_metadata(cache_key)
    if cached:
        await ctx.info(f"Using cached structure for {schema_name}.{table_name}")
        return cached

    await ctx.info(f"Fetching structure for {schema_name}.{table_name}")

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    query = """
    SELECT column_name, data_type, character_maximum_length,
           numeric_precision, numeric_scale, is_nullable, column_default
    FROM v_catalog.columns
    WHERE table_schema = %s AND table_name = %s
    ORDER BY ordinal_position;
    """

    constraint_query = """
            SELECT constraint_name, constraint_type, column_name
            FROM v_catalog.constraint_columns
            WHERE table_schema = %s AND table_name = %s;
        """
    try:
        columns, _ = await _execute_query_async(
            manager, query, (schema_name, table_name)
        )

        if not columns:
            raise RuntimeError(f"Table not found: {schema_name}.{table_name}")

        constraints, _ = await _execute_query_async(
            manager, constraint_query, (schema_name, table_name)
        )

        # Format result
        result = f"Table: {schema_name}.{table_name}\n\nColumns:\n"
        for col in columns:
            result += f"- {col[0]}: {col[1]}"
            if col[2]:
                result += f"({col[2]})"
            elif col[3]:
                result += f"({col[3]},{col[4]})"
            result += f" {'NULL' if col[5] == 'YES' else 'NOT NULL'}"
            if col[6]:
                result += f" DEFAULT {col[6]}"
            result += "\n"

        if constraints:
            result += "\nConstraints:\n"
            for const in constraints:
                result += f"- {const[0]} ({const[1]}): {const[2]}\n"

        response = {
            "result": result,
            "table_name": table_name,
            "schema": schema_name,
            "column_count": len(columns),
            "constraint_count": len(constraints),
        }

        _set_cached_metadata(cache_key, response)
        return response

    except vertica_python.errors.Error as e:
        error_msg = f"Database error getting table structure: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e
    except Exception as e:
        error_msg = f"Error getting table structure: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e


@mcp.tool()
async def get_table_projections(
    ctx: Context, table_name: str, schema_name: str = "public"
) -> dict:
    """List projections for a table."""
    await ctx.info(f"Listing projections for {schema_name}.{table_name}")

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    query = """
    SELECT projection_name, is_super_projection, anchor_table_name, create_type
    FROM v_catalog.projections
    WHERE projection_schema = %s AND anchor_table_name = %s
    ORDER BY projection_name;
    """

    try:
        projections, _ = await _execute_query_async(
            manager, query, (schema_name, table_name)
        )

        if not projections:
            raise RuntimeError(f"No projections found for {schema_name}.{table_name}")

        result = f"Projections for {schema_name}.{table_name}:\n\n"
        for proj in projections:
            result += f"- {proj[0]} (Super: {proj[1]}, Type: {proj[3]})\n"

        return {
            "result": result,
            "table_name": table_name,
            "schema": schema_name,
            "projection_count": len(projections),
        }

    except vertica_python.errors.Error as e:
        error_msg = f"Database error listing projections: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e
    except Exception as e:
        error_msg = f"Error listing projections: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e


# --------------------------------------------
# ---------- Get Schema Views ------------------
# --------------------------------------------
@mcp.tool()
async def get_schema_views(ctx: Context, schema_name: str = "public") -> dict:
    """List views in schema with caching."""
    cache_key = f"schema_views:{schema_name}"
    cached = _get_cached_metadata(cache_key)
    if cached:
        return cached

    await ctx.info(f"Listing views in schema: {schema_name}")

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    query = """
    SELECT table_name, view_definition
    FROM v_catalog.views
    WHERE table_schema = %s
    ORDER BY table_name;
    """

    try:
        views, _ = await _execute_query_async(manager, query, (schema_name,))

        if not views:
            raise RuntimeError(f"No views found in schema: {schema_name}")

        result = f"Views in {schema_name}:\n\n"
        for view in views:
            result += f"- {view[0]}\n"

        response = {"result": result, "schema": schema_name, "view_count": len(views)}
        _set_cached_metadata(cache_key, response)
        return response

    except vertica_python.errors.Error as e:
        error_msg = f"Database error listing views: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e
    except Exception as e:
        error_msg = f"Error listing views: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e


# --------------------------------------------
# ---------- Get Schema Tables ------------------
# --------------------------------------------
@mcp.tool()
async def get_schema_tables(ctx: Context, schema_name: str = "public") -> dict:
    """List tables in schema with caching."""
    cache_key = f"schema_tables:{schema_name}"
    cached = _get_cached_metadata(cache_key)
    if cached:
        return cached

    await ctx.info(f"Listing tables in schema: {schema_name}")

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    query = """
    SELECT table_name
    FROM v_catalog.tables
    WHERE table_schema = %s
    ORDER BY table_name;
    """

    try:
        tables, _ = await _execute_query_async(manager, query, (schema_name,))

        if not tables:
            raise RuntimeError(f"No tables found in schema: {schema_name}")

        result = f"Tables in {schema_name}:\n\n"
        for table in tables:
            result += f"- {table[0]}\n"

        response = {"result": result, "schema": schema_name, "table_count": len(tables)}
        _set_cached_metadata(cache_key, response)
        return response

    except vertica_python.errors.Error as e:
        error_msg = f"Database error listing tables: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e
    except Exception as e:
        error_msg = f"Error listing tables: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e


# --------------------------------------------
# ---------- Get Database Schemas ------------------
# --------------------------------------------
@mcp.tool()
async def get_database_schemas(ctx: Context) -> dict:
    """List database schemas with caching."""
    cache_key = "database_schemas"
    cached = _get_cached_metadata(cache_key)
    if cached:
        return cached

    await ctx.info("Listing database schemas")

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    query = """
    SELECT schema_name, is_system_schema
    FROM v_catalog.schemata
    ORDER BY schema_name;
    """

    try:
        schemas, _ = await _execute_query_async(manager, query)

        if not schemas:
            raise RuntimeError("No schemas found")

        result = "Database schemas:\n\n"
        for schema in schemas:
            result += f"- {schema[0]} {'(system)' if schema[1] else ''}\n"

        response = {"result": result, "schema_count": len(schemas)}
        _set_cached_metadata(cache_key, response)
        return response

    except vertica_python.errors.Error as e:
        error_msg = f"Database error listing schemas: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e
    except Exception as e:
        error_msg = f"Error listing schemas: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e


# --------------------------------------------
# ---------- Profile Query ------------------
# --------------------------------------------
def _inject_label(sql: str, label: str) -> str:
    """Insert /*+LABEL('...')*/ after the first top-level SELECT."""
    # 1) Strip any existing label hints
    sql = re.sub(
        r"/\*\+\s*label\s*\(\s*(['\"]).*?\1\s*\)\s*\*/",
        "",
        sql,
        flags=re.I | re.S,
    )

    s = sql
    n = len(s)
    i = 0
    depth = 0
    in_sq = False  # '...'
    in_dq = False  # "..."
    in_block = False  # /* ... */
    in_line = False  # -- ...

    def is_word_char(ch: str) -> bool:
        return ch.isalnum() or ch == "_"

    while i < n:
        ch = s[i]

        # line comment
        if (
            not (in_sq or in_dq or in_block)
            and ch == "-"
            and i + 1 < n
            and s[i + 1] == "-"
        ):
            in_line = True
            i += 2
            while i < n and s[i] not in "\r\n":
                i += 1
            in_line = False
            i += 1
            continue

        # block comment
        if (
            not (in_sq or in_dq or in_line)
            and ch == "/"
            and i + 1 < n
            and s[i + 1] == "*"
        ):
            in_block = True
            i += 2
            while i < n - 1:
                if s[i] == "*" and s[i + 1] == "/":
                    in_block = False
                    i += 2
                    break
                i += 1
            continue

        if in_line or in_block:
            continue

        # strings
        if not in_dq and ch == "'":
            # handle escaped ''
            if in_sq and i + 1 < n and s[i + 1] == "'":
                i += 2
                continue
            in_sq = not in_sq
            i += 1
            continue

        if not in_sq and ch == '"':
            # handle escaped ""
            if in_dq and i + 1 < n and s[i + 1] == '"':
                i += 2
                continue
            in_dq = not in_dq
            i += 1
            continue

        if in_sq or in_dq:
            i += 1
            continue

        # parens
        if ch == "(":
            depth += 1
            i += 1
            continue
        if ch == ")":
            if depth > 0:
                depth -= 1
            i += 1
            continue

        # first top-level SELECT
        if depth == 0 and (ch == "s" or ch == "S") and i + 6 <= n:
            word = s[i : i + 6]
            if word.lower() == "select":
                prev_ok = (i == 0) or (not is_word_char(s[i - 1]))
                next_ok = (i + 6 == n) or (not is_word_char(s[i + 6]))
                if prev_ok and next_ok:
                    return s[: i + 6] + f" /*+LABEL('{label}')*/" + s[i + 6 :]

        i += 1

    # Fallback: prepend (still labels the statement in Vertica)
    return f"/*+LABEL('{label}')*/ " + sql


@mcp.tool()
async def profile_query(
    ctx: Context, query: str, timeout: int | None = None
) -> dict:
    """Profile query execution with improved error handling."""
    await ctx.info("Profiling query")

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    label = f"mcp_profile_{uuid.uuid4().hex[:12]}"
    query_timeout = timeout or QUERY_TIMEOUT

    def _sync_profile():
        conn = cursor = None
        try:
            conn = manager.get_connection()
            cursor = conn.cursor()
            cursor.execute(f"SET SESSION RUNTIMECAP '{query_timeout}s'")

            labeled_sql = _inject_label(query, label)

            # Execute with PROFILE
            start_time = time.time()
            cursor.execute(f"PROFILE {labeled_sql}")
            execution_time = time.time() - start_time

            import time as _time

            _time.sleep(1)  # Wait for monitoring data to be recorded

            # Strategy 1: query_profiles table
            trxid = stmtid = duration_us = None
            cursor.execute(
                """
                SELECT transaction_id, statement_id, query_duration_us
                FROM v_monitor.query_profiles
                WHERE identifier = %s
                ORDER BY query_start_epoch DESC
                LIMIT 1
            """,
                (label,),
            )
            row = cursor.fetchone()
            if row:
                trxid, stmtid, duration_us = row
            else:
                # Strategy 2: query_requests table
                cursor.execute(
                    """
                    SELECT transaction_id, statement_id, request_duration_ms
                    FROM v_monitor.query_requests
                    WHERE request_label = %s
                    ORDER BY start_timestamp DESC
                    LIMIT 1
                """,
                    (label,),
                )
                row = cursor.fetchone()
                if row:
                    trxid, stmtid, duration_ms = row
                    duration_us = int(duration_ms) * 1000 if duration_ms else None

            if not trxid:
                # Strategy 3: Look for recent queries
                cursor.execute(
                    """
                    SELECT transaction_id, statement_id, query_duration_us
                    FROM v_monitor.query_profiles
                    WHERE query_start_epoch > %s
                    ORDER BY query_start_epoch DESC
                    LIMIT 5
                """,
                    (start_time - 5,),
                )
                recent_queries = cursor.fetchall()
                if recent_queries:
                    trxid, stmtid, duration_us = recent_queries[0]

            if not trxid:
                return {
                    "result": f"Query executed in {execution_time:.2f}s\nProfiling data not available",
                    "query": labeled_sql,
                    "label": label,
                    "execution_time_seconds": execution_time,
                    "note": "Could not resolve query IDs - profiling data unavailable",
                }

            cursor.execute(
                """
                SELECT path_line
                FROM v_internal.dc_explain_plans
                WHERE transaction_id = %s
                AND statement_id = %s
                ORDER BY path_id, path_line_index
            """,
                (trxid, stmtid),
            )
            plan_rows = cursor.fetchall()
            plan_lines = (
                [r[0] for r in plan_rows] if plan_rows else ["Plan not available"]
            )

            result = (
                f"Execution Time: {duration_us or int(execution_time * 1000000)}μs\n"
            )
            result += f"Transaction ID: {trxid}\n"
            result += f"Statement ID: {stmtid}\n\n"
            result += "Execution Plan:\n"
            result += "\n".join(plan_lines)

            return {
                "result": result,
                "query": query[:500],
                "label": label,
                "transaction_id": str(trxid),
                "statement_id": str(stmtid),
                "duration_us": duration_us,
                "plan_line_count": len(plan_lines),
            }
        except vertica_python.errors.Error as e:
            raise RuntimeError(f"Database profile error: {str(e)}") from e
        finally:
            if cursor:
                cursor.close()
            if conn:
                manager.release_connection(conn)

    try:
        return await asyncio.to_thread(_sync_profile)
    except Exception as e:
        error_msg = f"Profile error: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e


# --------------------------------------------
# ---------- Database Status ------------------
# --------------------------------------------
@mcp.tool()
async def database_status(ctx: Context) -> dict:
    """Get database status with improved error handling and formatting."""
    await ctx.info("Retrieving database status")

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    def _sync_status():
        conn = cursor = None
        try:
            conn = manager.get_connection()
            cursor = conn.cursor()

            cursor.execute("SELECT version()")
            row = cursor.fetchone()
            version = row[0] if row else "Unknown"

            current_usage_query = """
            SELECT
                (license_size_bytes / 1024^3)::NUMERIC(10, 2) AS license_gb,
                (database_size_bytes / 1024^3)::NUMERIC(10, 2) AS db_gb,
                (usage_percent * 100)::NUMERIC(5, 2) AS usage_pct,
                audit_start_timestamp,
                audit_end_timestamp
            FROM v_catalog.license_audits
            WHERE audit_end_timestamp = (
                SELECT MAX(audit_end_timestamp)
                FROM v_catalog.license_audits
            )
            LIMIT 1;
            """
            cursor.execute(current_usage_query)
            current = cursor.fetchone()

            trend_query = """
            SELECT
                DATE(audit_end_timestamp) as audit_date,
                AVG((usage_percent * 100))::NUMERIC(5, 2) AS avg_usage_pct,
                MAX((database_size_bytes / 1024^3))::NUMERIC(10, 2) AS max_db_gb
            FROM v_catalog.license_audits
            WHERE audit_end_timestamp >= CURRENT_DATE - INTERVAL '7 days'
            GROUP BY DATE(audit_end_timestamp)
            ORDER BY audit_date DESC
            LIMIT 7;
            """
            cursor.execute(trend_query)
            trend_data = cursor.fetchall()

            result = "Database Status Report\n"
            result += f"Version: {version[:60]}\n\n"

            if current:
                license_gb, db_gb, usage_pct, start_time, end_time = current
                result += "Current Usage:\n"
                result += f"- Database Size: {db_gb} GB\n"
                result += f"- License Capacity: {license_gb} GB\n"
                result += f"- Utilization: {usage_pct}% ({db_gb}/{license_gb} GB)\n"
                result += f"- Last Updated: {end_time}\n\n"
                if usage_pct > 90:
                    result += "\u26a0\ufe0f  Status: CRITICAL - Near capacity limit\n"
                elif usage_pct > 75:
                    result += "\u26a1 Status: WARNING - High utilization\n"
                else:
                    result += "\u2705 Status: HEALTHY - Normal utilization\n"
            else:
                result += "Current Usage: No audit data available\n"

            if trend_data:
                result += "\n7-Day Usage Trend:\n"
                for date, avg_usage, max_db in trend_data:
                    result += f"- {date}: {avg_usage}% ({max_db} GB)\n"

            cursor.execute(
                "SELECT COUNT(*) FROM v_catalog.nodes WHERE node_state = 'UP'"
            )
            node_count = cursor.fetchone()[0]
            result += "\nCluster Info:\n"
            result += f"- Active Nodes: {node_count}\n"

            return {
                "result": result,
                "version": version,
                "current_usage_pct": float(current[2]) if current else 0,
                "current_db_size_gb": float(current[1]) if current else 0,
                "license_capacity_gb": float(current[0]) if current else 0,
                "trend_data_points": len(trend_data),
                "cluster_nodes": node_count,
            }
        except vertica_python.errors.Error as e:
            raise RuntimeError(f"Database error getting status: {str(e)}") from e
        finally:
            if cursor:
                cursor.close()
            if conn:
                manager.release_connection(conn)

    try:
        return await asyncio.to_thread(_sync_status)
    except Exception as e:
        error_msg = f"Error getting status: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e


# --------------------------------------------
# ---------- System Performance ------------------
# --------------------------------------------
@mcp.tool()
async def analyze_system_performance(
    ctx: Context,
    window_minutes: int = 10,
    bucket: str = "minute",
    top_n: int = 5,
    flush: bool = True,
) -> dict:
    """Analyze system performance with improved efficiency."""
    await ctx.info(f"Analyzing performance (window={window_minutes}m)")

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    # SECURITY: Validate all parameters BEFORE SQL construction to prevent injection
    bucket = bucket.lower()
    if bucket not in {"second", "minute", "hour"}:
        raise ValueError(
            f"Invalid bucket value: {bucket}. Must be 'second', 'minute', or 'hour'"
        )

    # Strict type validation to prevent SQL injection via type coercion
    try:
        window_minutes = int(window_minutes)
        if window_minutes < 1 or window_minutes > 1440:  # Max 24 hours
            raise ValueError(
                f"window_minutes must be between 1 and 1440, got {window_minutes}"
            )
    except (TypeError, ValueError) as e:
        raise ValueError(f"window_minutes must be a valid integer: {e}")

    try:
        top_n = int(top_n)
        if top_n < 1 or top_n > 100:
            raise ValueError(f"top_n must be between 1 and 100, got {top_n}")
    except (TypeError, ValueError) as e:
        raise ValueError(f"top_n must be a valid integer: {e}")

    def _rows_to_dicts(cols, rows):
        return [dict(zip(cols, r, strict=False)) for r in rows]

    def _sync_perf():
        conn = cursor = None
        try:
            conn = manager.get_connection()
            cursor = conn.cursor()

            if flush:
                try:
                    cursor.execute("SELECT FLUSH_DATA_COLLECTOR();")
                    cursor.fetchall()
                except Exception:
                    pass  # Non-critical

            ts_expr = f"DATE_TRUNC('{bucket}', end_time)"
            where = (
                f"end_time >= CURRENT_TIMESTAMP - INTERVAL '{window_minutes} minutes'"
            )

            cpu_sql = f"""
                SELECT node_name, {ts_expr} AS ts,
                       AVG(average_cpu_usage_percent) AS cpu_pct
                FROM v_monitor.cpu_usage
                WHERE {where}
                GROUP BY node_name, ts
                ORDER BY node_name, ts
                LIMIT 100
            """
            cursor.execute(cpu_sql)
            cpu_desc = [d[0] for d in cursor.description] if cursor.description else []
            cpu_rows = _rows_to_dicts(cpu_desc, cursor.fetchall())

            mem_sql = f"""
                SELECT node_name, {ts_expr} AS ts,
                       AVG(average_memory_usage_percent) AS mem_pct
                FROM v_monitor.memory_usage
                WHERE {where}
                GROUP BY node_name, ts
                ORDER BY node_name, ts
                LIMIT 100
            """
            cursor.execute(mem_sql)
            mem_desc = [d[0] for d in cursor.description] if cursor.description else []
            mem_rows = _rows_to_dicts(mem_desc, cursor.fetchall())

            top_tables_sql = f"""
                SELECT anchor_table_schema, anchor_table_name,
                       SUM(ros_count) AS total_ros_containers
                FROM v_monitor.projection_storage
                GROUP BY 1,2
                ORDER BY total_ros_containers DESC
                LIMIT {top_n}
            """
            cursor.execute(top_tables_sql)
            top_desc = [d[0] for d in cursor.description] if cursor.description else []
            top_tables = _rows_to_dicts(top_desc, cursor.fetchall())

            return {
                "cpu": cpu_rows[:50],
                "memory": mem_rows[:50],
                "top_tables_by_ros": top_tables,
                "meta": {
                    "window_minutes": window_minutes,
                    "bucket": bucket,
                    "top_n": top_n,
                },
            }
        except vertica_python.errors.Error as e:
            raise RuntimeError(f"Database performance error: {str(e)}") from e
        finally:
            if cursor:
                cursor.close()
            if conn:
                manager.release_connection(conn)

    try:
        return await asyncio.to_thread(_sync_perf)
    except Exception as e:
        error_msg = f"Performance analysis error: {str(e)}"
        await ctx.error(error_msg)
        raise RuntimeError(error_msg) from e


# --------------------------------------------
# ---------- Generate Health Dashboard ------------------
# --------------------------------------------
@mcp.tool()
async def generate_health_dashboard(
    ctx: Context, output_format: str = "compact"
) -> dict:
    """Generate consolidated health dashboard with controlled output.
    Args:
        ctx: The context object.
        output_format: The format of the dashboard (default: compact, detailed, json).
    Returns:
        A dictionary containing the health dashboard.
    """

    manager = ctx.request_context.lifespan_context.get("vertica_manager")
    if not manager:
        raise RuntimeError("No database connection manager available")

    # Collect metrics efficiently
    try:
        status = await database_status(ctx)
        perf = await analyze_system_performance(ctx, window_minutes=5, top_n=3)
    except Exception as e:
        return {"error": f"Failed to collect metrics: {e}"}

    if output_format == "json":
        # Extract key metrics
        cpu_avg = _calculate_avg(perf.get("cpu", []), "cpu_pct")
        mem_avg = _calculate_avg(perf.get("memory", []), "mem_pct")

        return {
            "timestamp": datetime.now().isoformat(),
            "version": status.get("version", "Unknown")[:50],
            "metrics": {
                "cpu_pct": round(cpu_avg, 1),
                "memory_pct": round(mem_avg, 1),
            },
            "alerts": _generate_alerts(perf),
            "top_ros": [
                t["anchor_table_name"] for t in perf.get("top_tables_by_ros", [])
            ][:3],
        }

    elif output_format == "compact":
        return {
            "result": _format_compact_dashboard(status, perf),
            "token_estimate": 150,
        }

    else:  # detailed
        return {
            "result": _format_detailed_dashboard(status, perf),
            "token_estimate": 400,
        }


def _format_compact_dashboard(status: dict, perf: dict) -> str:
    """Ultra-compact dashboard."""
    cpu_avg = _calculate_avg(perf.get("cpu", []), "cpu_pct")
    mem_avg = _calculate_avg(perf.get("memory", []), "mem_pct")

    alerts = _generate_alerts(perf)
    alert_str = f"{len(alerts)} alerts" if alerts else "OK"

    return f"""Health Summary
CPU: {cpu_avg:.1f}% | Mem: {mem_avg:.1f}%
Status: {alert_str}"""


def _format_detailed_dashboard(status: dict, perf: dict) -> str:
    """Detailed but controlled dashboard."""
    try:
        cpu_avg = _calculate_avg(perf.get("cpu", []), "cpu_pct")
        mem_avg = _calculate_avg(perf.get("memory", []), "mem_pct")

        result = "Database Health Report\n"
        result += f"Version: {status.get('version', 'Unknown')[:50]}\n\n"
        result += "Resources:\n"
        result += f"- CPU: {cpu_avg:.1f}%\n"
        result += f"- Memory: {mem_avg:.1f}%\n\n"

        # Debug: Add performance data info
        result += f"Performance Data Keys: {list(perf.keys())}\n"
        result += f"CPU Records: {len(perf.get('cpu', []))}\n"
        result += f"Memory Records: {len(perf.get('memory', []))}\n\n"

        # Safe alert generation
        try:
            alerts = _generate_alerts(perf)
            if alerts:
                result += f"Alerts ({len(alerts)}):\n"
                for alert in alerts[:3]:
                    result += f"- {alert.get('type', 'Unknown')}: {alert.get('value', 'N/A')}\n"
            else:
                result += "Alerts: None\n"
        except Exception as e:
            result += f"Alert Generation Error: {str(e)}\n"

        # Add top tables info
        try:
            top_tables = perf.get("top_tables_by_ros", [])
            if top_tables:
                result += "\nTop ROS Tables:\n"
                for table in top_tables[:3]:
                    name = table.get("anchor_table_name", "Unknown")
                    ros_count = table.get("total_ros_containers", 0)
                    result += f"- {name}: {ros_count} containers\n"
            else:
                result += "\nTop Tables: No data available\n"
        except Exception as e:
            result += f"\nTop Tables Error: {str(e)}\n"

        return result

    except Exception as e:
        return f"Dashboard Generation Error: {str(e)}\nRaw Status: {status}\nRaw Perf: {perf}"


def _calculate_avg(data: list, field: str) -> float:
    """Calculate field average."""
    if not data:
        return 0.0
    values = [float(d.get(field, 0)) for d in data if field in d]
    return sum(values) / len(values) if values else 0.0


def _generate_alerts(perf: dict) -> list:
    """Generate performance alerts with better error handling."""
    alerts = []

    try:
        # CPU alerts
        cpu_data = perf.get("cpu", [])
        if cpu_data:
            cpu_avg = _calculate_avg(cpu_data, "cpu_pct")
            if cpu_avg > 85:
                alerts.append({"type": "cpu_high", "value": f"{cpu_avg:.1f}%"})

        # Memory alerts
        mem_data = perf.get("memory", [])
        if mem_data:
            mem_avg = _calculate_avg(mem_data, "mem_pct")
            if mem_avg > 85:
                alerts.append({"type": "memory_high", "value": f"{mem_avg:.1f}%"})

        # ROS container alerts
        top_tables = perf.get("top_tables_by_ros", [])
        for table in top_tables:
            ros_count = table.get("total_ros_containers", 0)
            if ros_count > 5000:
                alerts.append(
                    {
                        "type": "ros_high",
                        "table": table.get("anchor_table_name", "Unknown"),
                        "value": f"{ros_count:,} containers",
                    }
                )

    except Exception as e:
        alerts.append({"type": "error", "value": f"Alert generation failed: {str(e)}"})

    return alerts


# --------------------------------------------
# ---------- Health Dashboard Prompt ------------------
# --------------------------------------------
@mcp.prompt()
async def vertica_database_health_dashboard() -> str:
    """Compact health dashboard."""
    return """HEALTH DASHBOARD
Call: generate_health_dashboard(format="compact")
Show: Version, usage%, alerts only"""


# --------------------------------------------
# ---------- System Monitor Prompt ------------------
# --------------------------------------------
@mcp.prompt()
async def vertica_database_system_monitor() -> str:
    """System performance monitor."""
    return """SYSTEM MONITOR
Call: analyze_system_performance(window_minutes=5, top_n=3)
Show: CPU/Mem avg, top ROS tables
Alert if >85% usage or >5000 ROS"""


# --------------------------------------------
# ---------- Compact Health Report Prompt ------------------
# --------------------------------------------
@mcp.prompt()
async def vertica_compact_health_report() -> str:
    """Token-efficient health report."""
    return """COMPACT REPORT
Call: generate_health_dashboard(format="json")
Return JSON with summary + alerts only
Max 300 tokens"""


# --------------------------------------------
# ---------- SQL Safety Guard Prompt ------------------
# --------------------------------------------
@mcp.prompt()
async def sql_query_safety_guard() -> str:
    """SQL safety guard."""
    return """SQL SAFETY
1. Call run_query_safely with row_threshold=1000
2. If large, ask user to confirm
3. Use pagination for results"""


# --------------------------------------------
# ---------- Query Performance Analyzer Prompt ------------------
# --------------------------------------------
@mcp.prompt()
async def vertica_query_performance_analyzer() -> str:
    """
    Vertica Performance Analyzer - Deep-dive query performance analysis with actionable optimization recommendations.

    Analyzes the given query execution plans, identifies bottlenecks, and provides concrete DDL suggestions
    for optimal Vertica projections, join strategies, and ROS container health.
    """
    return """VERTICA PERFORMANCE ANALYSIS

ANALYSIS WORKFLOW:
1) IMPORTANT: ALWAYS SUGGEST TO THE USER TO USE DATABASE DESIGNER (DBD) COMPREHENSIVE AND INCREMENTAL TO OPTIMIZE THE QUERY FIRST
2) **PROFILE EXECUTION**: Call `profile_query` to get actual runtime and execution plan
3) **PARSE OPERATORS**: Identify all operators (Scan, Hash Join, Merge Join, GroupBy, Sort, Exchange)
4) **COST ANALYSIS**: Find the 3-5 highest-cost operations with row estimates
5) **JOIN OPTIMIZATION**: For each Hash Join → propose Merge Join strategy
6) **AGGREGATION TUNING**: For each Hash GroupBy → propose Pipelined GroupBy
7) **PROJECTION HEALTH**: Audit ROS container counts for projections used
8) **CONCRETE RECOMMENDATIONS**: Specific DDL for optimal projections

OPTIMIZATION FOCUS:
- **Merge Joins**: Require pre-sorted data (ORDER BY) and co-location (SEGMENTED BY HASH)
- **Pipelined GroupBy**: Needs input sorted on GROUP BY columns
- **ROS Container Health**: Flag projections with >5000 containers for maintenance

OUTPUT SECTIONS:
1. **Executive Summary**: Duration, row estimates, performance grade
2. **Top Cost Operations**: Operator | Input | Rows | Cost/Notes
3. **Join Optimization**: Current → Target with specific ORDER BY/SEGMENTED BY
4. **GroupBy Optimization**: Hash → Pipelined with projection requirements  
5. **Projection Health**: Base Projection | ROS Containers | Status
6. **Action Items**: Concrete DDL statements and maintenance tasks

RULES:
- Start with `profile_query` - no exceptions
- Use `execute_query_paginated` for large result sets, never full table scans
- Normalize projection names (strip _b0/_b1 suffixes)
- Be specific: exact column lists, not generic advice
- Flag urgent issues: >5000 ROS containers, inefficient operators"""


# --------------------------------------------
# ---------- SQL Assistant Prompt ------------------
# --------------------------------------------
@mcp.prompt()
async def vertica_sql_assistant() -> str:
    """
    Vertica SQL Assistant - Expert SQL query generation with Vertica-specific optimizations.

    Generates efficient, Vertica-optimized SQL queries following a structured approach:
    analyze → research → generate → execute → fix → deliver
    """
    return """VERTICA SQL QUERY GENERATION

As a Vertica SQL expert, I follow a structured approach to deliver optimized queries.

PROCESS WORKFLOW:
1. **ANALYZE** - Understand the user's request and data requirements
2. **RESEARCH** - Check Vertica documentation for native functions before writing custom logic
3. **GENERATE** - Create optimized SQL using Vertica-specific features
4. **EXECUTE** - Run the query to validate functionality
5. **FIX** - Debug and resolve any errors that occur
6. **DELIVER** - Provide the final, tested query with explanations

RESEARCH FIRST RULE:
- ALWAYS search Vertica documentation for native functions before implementing custom solutions
- Use web_search to find official Vertica docs for specific operations (sessionization, window functions, analytics, etc.)
- Leverage Vertica's specialized functions like CONDITIONAL_TRUE_EVENT, CONDITIONAL_CHANGE_EVENT, etc.

VERTICA BEST PRACTICES:
- **Native Functions**: Prioritize Vertica-specific functions over custom implementations
- **Performance**: Use efficient window functions, projections, and partitioning
- **Joins**: Prefer INNER joins when possible, optimize join order
- **Aggregations**: Leverage APPROXIMATE_COUNT_DISTINCT, analytical functions
- **Formatting**: Clean, readable SQL with proper indentation and comments

IMPLEMENTATION APPROACH:
1. **Schema Discovery**: Use `get_schema_tables`, `get_database_schemas`, `get_table_structure` if needed
2. **Documentation Check**: Search for Vertica-specific functions before custom coding
3. **Query Generation**: Write optimized SQL with Vertica best practices
4. **Execution**: Always execute the query using `run_query_safely`
5. **Error Handling**: If execution fails, analyze errors and fix immediately
6. **Validation**: Ensure query produces expected results

QUERY STANDARDS:
- Clear, commented SQL with logical structure
- Proper use of CTEs for complex operations
- Vertica-optimized functions and syntax
- Performance-conscious design patterns
- Error-free, tested implementation

EXECUTION PROTOCOL:
- Generate query based on requirements
- Execute immediately to validate functionality  
- Fix any errors encountered during execution
- Provide final working query with performance notes
- Suggest optimizations or projection improvements where applicable

CRITICAL: Always execute queries to ensure they work correctly before presenting the final solution."""
