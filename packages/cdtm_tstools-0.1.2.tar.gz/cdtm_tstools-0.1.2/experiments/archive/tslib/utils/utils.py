"""
Utilities for the Trend Seminar Workspace.
"""

import glob
import json
import os
import re

from docx import Document
from openai import OpenAI
import pandas as pd
from tqdm.auto import tqdm
from difflib import SequenceMatcher

from .segregate_prompt import segregate  # type: ignore


def read_docx(file_path):
    doc = Document(file_path)
    text = []
    for para in doc.paragraphs:
        if para.text.strip():  # skip empty lines
            text.append(para.text)
    return "\n".join(text)


def call_segregate(apa_citation: str, client: OpenAI) -> dict:
    """
    Calls OpenAI's ChatCompletion with a function calling request to segregate an APA citation.

    Args:
        apa_citation (str): The APA citation text.

    Returns:
        dict: A dictionary with keys:
              'Organization/Author', 'Title', 'Link', 'Access Date', 'Publish Year',
              'Journal Name', 'Journal Volume', 'Journal Issue', 'Journal Page',
              and 'Formatting Error Flag'
    """

    # Define the system and user messages.
    messages = [
        {
            "role": "system",
            "content": (
                "You are an APA citation parser. You can receive a journal or a web citation or an unknow kind, When provided with an APA citation, "
                "extract the following components: Organization/Author, Title, Link, "
                "Access Date, Publish Year, Journal Name, Journal Volume, Journal Issue, "
                "Journal Page, and a Formatting Error Flag if any issues are detected. Flagging is the most improtant part. Pick up any and all issues."
            ),
        },
        {
            "role": "user",
            "content": f"Please check this APA citation of a web article: {apa_citation}",
        },
    ]

    # Define the function schema for segregate.
    tools = [{"type": "function", "function": segregate}]

    # Call the OpenAI ChatCompletion API.
    response = client.chat.completions.create(
        model="gpt-4.1",
        messages=messages,  # type: ignore
        tools=tools,  # type: ignore
    )

    # Process the function call response.
    tool_call = response.choices[0].message.tool_calls[0]  # type: ignore
    args = json.loads(tool_call.function.arguments)  # type: ignore

    return args


def call_segregate_on_dataset(
    dataset: pd.DataFrame,
    client: OpenAI,
    apa_citation_col_name: str,
) -> pd.DataFrame:
    """
    Calls the segregate function on a dataset of citations.

    Args:
        dataset (pd.DataFrame): The dataset of citations with a column
        client (OpenAI): The OpenAI client.

    Returns:
        pd.DataFrame: The dataset with the AI information.
    """

    ai_returned_infos = []
    for _, row in tqdm(dataset.iterrows()):
        citation = row[apa_citation_col_name]
        result = call_segregate(citation, client)
        result["Number"] = row["Number"]

        ai_returned_infos.append(result)
    df = pd.DataFrame(ai_returned_infos)
    return df


def citations_similar(text1, text2, threshold=0.9) -> bool:
    """
    Determine if two citation texts are substantially similar based on a given threshold.

    Parameters:
        text1 (str): The first citation reference.
        text2 (str): The second citation reference.
        threshold (float): A similarity ratio threshold (0 to 1).

    Returns:
        bool: True if similarity ratio is greater than or equal to threshold.
    """
    # Handle the case where the entry is empty
    if pd.isna(text1) or pd.isna(text2):
        return False

    # Ensure both inputs are strings
    text1 = str(text1)
    text2 = str(text2)

    return SequenceMatcher(None, text1, text2).ratio() >= threshold


def find_similar_citations(
    df: pd.DataFrame,
    threshold: float = 0.9,
    citation_id_col_name: str = "Number",
    citation_text_col_name: str = "Reference (APA7)",
) -> list:
    """
    Groups citations by testing whether their APA references are substantially similar.

    Parameters:
        df (pandas.DataFrame): DataFrame containing at least two columns:
            'Number' or 'citation_id_col_name', and 'Reference (APA7)' or 'citation_text_col_name'.
        threshold (float): A threshold for fuzzy matching (default 0.9).
        citation_id_col_name (str): The name of the column containing the citation IDs i.e., [T-TEC-0-01].
        citation_text_col_name (str): The name of the column containing the citation texts i.e., "Mustermann, M. M. (2025). The title of the work. Publisher. URL (doi for journals)."

    Returns:
        list: A list of lists, where each sublist contains the citation numbers
              that have substantially similar references (only groups with >1 item are returned).
    """
    n = len(df)
    # Initialize union-find structure: parent and rank for each citation
    parent = list(range(n))
    rank = [0] * n

    def find(x):
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]

    def union(x, y):
        root_x = find(x)
        root_y = find(y)
        if root_x != root_y:
            if rank[root_x] < rank[root_y]:
                parent[root_x] = root_y
            elif rank[root_x] > rank[root_y]:
                parent[root_y] = root_x
            else:
                parent[root_y] = root_x
                rank[root_x] += 1

    # Convert the column of references to a list
    citations = df[citation_text_col_name].tolist()

    # Compare each pair of citations. If they are sufficiently similar,
    # union their indices.
    for i in range(n):
        for j in range(i + 1, n):
            if citations_similar(citations[i], citations[j], threshold):
                union(i, j)

    # Group citation numbers by their root parent
    groups: dict[int, list[str]] = {}
    for i in range(n):
        root = find(i)
        citation_id = df.iloc[i][citation_id_col_name]

        # Only add if the citation_id is not NaN
        if pd.notna(citation_id):
            groups.setdefault(root, []).append(citation_id)

    # Only include groups with more than one citation number
    result = [group for group in groups.values() if len(group) > 1]
    return result


def replace_text_in_run_aware(paragraph, numbering_dict):
    full_text = "".join(run.text for run in paragraph.runs)
    replaced_text = full_text

    # First, handle multiple citations that appear together
    # Pattern to match multiple citations like [T-TEC-0-2], [T-TEC-1-15], [T-TEC-0-1]
    # This regex looks for one or more occurrences of [citation], optionally separated by commas and spaces
    multi_citation_pattern = (
        r"(\[[A-Z]-[A-Z]{3}-\d-\d{1,3}\](?:\s*,\s*\[[A-Z]-[A-Z]{3}-\d-\d{1,3}\])*)"
    )

    def replace_multiple_citations(match):
        citation_group = match.group(1)
        # Extract individual citation IDs from the group
        individual_citation_pattern = r"[A-Z]-[A-Z]{3}-\d-\d{1,3}"
        citation_ids = re.findall(individual_citation_pattern, citation_group)

        # Convert to numbers and sort them
        numbers = []
        for citation_id in citation_ids:
            if citation_id in numbering_dict:
                numbers.append(numbering_dict[citation_id])

        # Sort the numbers and create the combined reference
        if numbers:
            numbers = sorted(set(numbers))  # Remove duplicates and sort
            return "[" + ", ".join(map(str, numbers)) + "]"
        else:
            return citation_group  # Return original if no matches found

    # Replace multiple citations first
    replaced_text = re.sub(
        multi_citation_pattern, replace_multiple_citations, replaced_text
    )

    # Then handle any remaining individual citations (not in brackets)
    for key, index in numbering_dict.items():
        pattern = r"\b" + re.escape(key) + r"\b"
        replaced_text = re.sub(pattern, str(index), replaced_text)

    # Only rewrite runs if replacements occurred
    if full_text != replaced_text:
        # Clear current runs
        for run in paragraph.runs:
            run.text = ""
        # Re-assign all as a single run (or optionally, split into multiple runs if needed)
        paragraph.runs[0].text = replaced_text


def replace_text_in_table(table, numbering_dict):
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                replace_text_in_run_aware(paragraph, numbering_dict)


def replace_text_in_header_footer(section, numbering_dict):
    header = section.header
    footer = section.footer
    for paragraph in header.paragraphs + footer.paragraphs:
        replace_text_in_run_aware(paragraph, numbering_dict)


def validate_citation_id_format(citation_id: str) -> list[str]:
    """
    Validate citation ID format and return specific error details if issues are found.

    Expected format: X-XXX-N-NN where:
    - X is single uppercase letter
    - XXX is 3 uppercase letters
    - N is single digit (no leading zeros)
    - NN is 2+ digits with leading zeros allowed

    Args:
        citation_id (str): The citation ID to validate

    Returns:
        list: List of error messages, empty if no issues found
    """
    errors = []

    # Split the ID by hyphens
    parts = citation_id.split("-")

    if len(parts) != 4:
        errors.append(
            f"Invalid format - expected 4 parts separated by hyphens, got {len(parts)}"
        )
        return errors

    # Check 2nd position (index 2). It must have 3 characters only
    second_part = parts[1]
    if len(second_part) != 3:
        errors.append(
            f"Invalid 2nd position '{second_part}' - should have 3 characters only"
        )

    # Check 3rd position (index 2) for leading zeros
    third_part = parts[2]
    if len(third_part) > 1:
        errors.append(
            f"Invalid 3rd position '{third_part}' - should have only one digit (e.g., use '5' not '05')"
        )

    # Check 4th position (index 3) for minimum 2 digits
    fourth_part = parts[3]
    if len(fourth_part) < 2:
        errors.append(
            f"Invalid 4th position '{fourth_part}' - should have at least 2 digits (e.g., use '04' not '4')"
        )

    return errors


def check_all_citation_ids_format(citation_ids: list[str]) -> None:
    """
    Check all citation IDs for format issues and raise error if any problems found.

    Args:
        citation_ids (list): List of citation IDs to check

    Raises:
        ValueError: If any citation IDs have format issues
    """
    all_errors = {}

    for citation_id in citation_ids:
        errors = validate_citation_id_format(citation_id)
        if errors:
            all_errors[citation_id] = errors

    if all_errors:
        error_msg = "Citation ID format validation failed!\n\n"
        for citation_id, errors in all_errors.items():
            error_msg += f"ID: {citation_id}\n"
            for error in errors:
                error_msg += f"  - {error}\n"
            error_msg += "\n"

        raise ValueError(error_msg)

    print(f"All {len(citation_ids)} citation IDs passed format validation!")


def find_pattern_in_files(files: list[str], pattern: str) -> list[str]:
    """
    Find all citations in the files that match the pattern.

    Args:
        files (list[str]): List of file paths to search
        pattern (str): Pattern to search for

    Returns:
        list[str]: List of citations found
    """
    citations_indexes = []
    for file in files:
        document_text = read_docx(file)
        matches = re.findall(pattern, document_text)
        citations_indexes += matches

    return citations_indexes


def check_abbreviations_usage(
    abbreviations_df: pd.DataFrame,
    docs_directory: str,
    abbreviation_col_name: str = "Abbreviation",
) -> pd.DataFrame:
    """
    Check if abbreviations from a dataframe are actually used in documents.

    Args:
        abbreviations_df (pd.DataFrame): DataFrame containing abbreviations with at least an 'Abbreviation' column
        docs_directory (str): Path to directory containing .docx files to search
        abbreviation_col_name (str): Name of the column containing abbreviations (default: 'Abbreviation')

    Returns:
        pd.DataFrame: Original dataframe with an additional 'used' column (True/False)
    """
    # Create a copy to avoid modifying the original
    result_df = abbreviations_df.copy()

    # Get all .docx files from the directory (excluding temp files starting with ~$)
    docx_files = [
        f
        for f in glob.glob(os.path.join(docs_directory, "*.docx"))
        if not os.path.basename(f).startswith("~$")
    ]

    print(f"Found {len(docx_files)} .docx files in {docs_directory}")

    # Read and combine all document texts
    combined_text = ""
    print("Reading documents...")
    for file_path in tqdm(docx_files, desc="Loading documents"):
        try:
            doc_text = read_docx(file_path)
            combined_text += " " + doc_text
        except Exception as e:
            print(f"Warning: Could not read {file_path}: {e}")

    print(f"Total combined text length: {len(combined_text)} characters")

    # Check each abbreviation
    print("Checking abbreviations usage...")
    used_flags = []

    for idx, row in tqdm(
        result_df.iterrows(), total=len(result_df), desc="Checking abbreviations"
    ):
        abbreviation = row[abbreviation_col_name]

        # Check if abbreviation exists in the combined text
        # Using word boundary regex to avoid partial matches
        if pd.notna(abbreviation):
            # Create a pattern that matches the abbreviation as a whole word
            pattern = r"\b" + re.escape(str(abbreviation)) + r"\b"
            is_used = bool(re.search(pattern, combined_text))
            used_flags.append(is_used)
        else:
            used_flags.append(False)

    # Add the 'used' column to the dataframe
    result_df["used"] = used_flags

    # Print summary
    used_count = sum(used_flags)
    total_count = len(used_flags)
    print("\nSummary:")
    print(f"  Total abbreviations: {total_count}")
    print(f"  Used in documents: {used_count}")
    print(f"  Not used: {total_count - used_count}")

    return result_df
