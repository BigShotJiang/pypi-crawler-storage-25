segregate = {
    "name": "segregate",
    "description": (
        "Segregates an APA7 citation into its components: Organization/Author, Title, "
        "Link, Access Date, Publish Year, Journal Name, Journal Volume, Journal Issue, etc."
        "The APA7 format is as follows: "
        "Author, A. A. (Date (Access/Published)). Title of the work. Publisher. URL (doi for journals)."
        "Remeber that the date today is 27-09-2025. Journal Page, and a Formatting Error Flag. Looking for errors is a really important part. Look for formatting issues, missing commas and connotation, names that dont seem right. The format must adhere to APA7 guidelines."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "Type": {
                "type": "string",
                "description": "The type of citation (e.g., journal, web, etc.).",
                "enum": ["report", "website", "journal", "book", "other"],
            },
            "Organization/Author": {
                "type": "string",
                "description": "The organization or author extracted from the citation.",
            },
            "Title": {
                "type": "string",
                "description": "The title extracted from the citation.",
            },
            "Link": {
                "type": "string",
                "description": "The URL link extracted from the citation, if present.",
            },
            "Date": {
                "type": "string",
                "description": "The publication or access date in APA7 format extracted from the citation.",
            },
            "Publisher Information": {
                "type": "string",
                "description": "The info about the publisher. If it is a journal, it should contain the journal name, volume, issue, and page numbers.",
            },
            "Formatting Error Flag": {
                "type": "string",
                "description": "Any formatting errors or missing information detected in the citation like missing author name, wrong format.",
            },
            "Original Citation": {
                "type": "string",
                "description": "Just the original citation without any changes.",
            },
            "Final Corrected Citation": {
                "type": "string",
                "description": "Corrected citation in APA7 format. If the citation is correct, just return the original",
            },
        },
        "required": [
            "type",
            "Organization/Author",
            "Title",
            "Link",
            "Access Date",
            "Publish Year",
            "Journal Name",
            "Journal Volume",
            "Journal Issue",
            "Journal Page",
            "Formatting Error Flag",
            "Original Citation",
            "Final Corrected Citation",
        ],
    },
}
