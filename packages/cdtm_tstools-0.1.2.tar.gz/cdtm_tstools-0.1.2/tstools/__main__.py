from tstools.main import main

main()
