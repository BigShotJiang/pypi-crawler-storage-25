"""
URL → AMA 11th edition citation.

DOI URLs  → CrossRef API (structured JSON, no scraping)
Other URLs → Crawl4AI (stealth) → first 2000 chars

Both paths feed metadata into GPT-4o-mini for final formatting.

Usage:
    python -m tstools.utils.cite_from_url --url "https://example.com/article"
    python -m tstools.utils.cite_from_url   # prompts interactively
"""

import asyncio
import os
import re
from datetime import date

import click
import httpx
from dotenv import load_dotenv
from openai import AsyncOpenAI
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode

load_dotenv()

METADATA_WINDOW = 2000
_DOI_RE = re.compile(r"\b(10\.\d{4,}/[^\s\"'<>]+)")

_CROSSREF_FIELDS = [
    ("author",               None),
    ("title",                lambda v: v[0]),
    ("container-title",      lambda v: v[0]),
    ("short-container-title", lambda v: v[0]),
    ("volume",               None),
    ("issue",                None),
    ("page",                 None),
    ("DOI",                  None),
]


# ── CrossRef path ─────────────────────────────────────────────────────────────

def _extract_doi(url: str) -> str | None:
    m = _DOI_RE.search(url)
    return m.group(1).rstrip(".,;)") if m else None


async def _fetch_crossref(doi: str) -> dict | None:
    url = f"https://api.crossref.org/works/{doi}"
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(url, headers={"User-Agent": "cite_from_url/1.0"})
        return r.json().get("message") if r.status_code == 200 else None


def _crossref_to_text(data: dict) -> str:
    lines = []

    authors = data.get("author", [])
    if authors:
        names = [f"{a.get('family','')} {(a.get('given','')[:1])}".strip() for a in authors]
        lines.append("Authors: " + ", ".join(names))

    pub_date = data.get("published", {}).get("date-parts", [[]])[0]
    if pub_date:
        lines.append(f"Year: {pub_date[0]}")

    for key, transform in _CROSSREF_FIELDS:
        if key == "author":
            continue
        val = data.get(key)
        if not val:
            continue
        lines.append(f"{key}: {transform(val) if transform else val}")

    return "\n".join(lines)


# ── Crawl4AI path ─────────────────────────────────────────────────────────────

def _filter_metadata(markdown) -> str:
    text = markdown.raw_markdown if hasattr(markdown, "raw_markdown") else markdown
    kept, chars = [], 0
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("![") or (len(s) < 4 and not s.startswith("#")):
            continue
        kept.append(s)
        chars += len(s)
        if chars >= METADATA_WINDOW:
            break
    return "\n".join(kept)


async def _crawl(url: str) -> str:
    browser_cfg = BrowserConfig(
        headless=True,
        browser_type="chromium",
        headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                 "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"},
    )
    run_cfg = CrawlerRunConfig(cache_mode=CacheMode.ENABLED, simulate_user=True, magic=True)

    async with AsyncWebCrawler(config=browser_cfg) as crawler:
        result = await crawler.arun(url=url, config=run_cfg)
    if not result.success:
        raise RuntimeError(f"Crawl failed for {url}: {result.error_message}")
    return _filter_metadata(result.markdown)


# ── LLM ───────────────────────────────────────────────────────────────────────

_PROMPT = """You are an AMA 11th edition citation formatter.

URL : {url}
Date: {today}  (use as "Accessed" date when page doesn't specify one)

FORMAT
  Author AA, Author BB. Title. Abbreviated Source. Year;Vol(Issue):pages. doi:10.xxxx/xxx
  • LastName Initials — no periods between initials, comma-separated, ≤6 then "et al."
  • No personal author → use organisation / website name as author.
  • DOI present   → end with doi:… (no trailing period)
  • No DOI, URL   → end with Accessed {today}. <URL> (no trailing period)
  • Never combine DOI + accessed-date/URL.
  • If the source/publisher name is identical to the author, omit it — do not repeat it.
    e.g. "Munich Re. Title. Munich Re. ..." → "Munich Re. Title. Published ... Accessed ..."

EXAMPLES
  Towfighi A, Markovic D, Ovbiagele B. Utility of Framingham coronary disease risk score for predicting cardiac risk after stroke. Stroke. 2012;43(11):2942-2947. doi:10.1161/STROKEAHA.112.668319

  Ng L, Karunasinghe N, Benjamin CS, Ferguson LR. Beyond PSA: are new prostate cancer biomarkers of potential value to New Zealand doctors? N Z Med J. 2012;125(1353). Accessed April 15, 2020. https://www.nzma.org.nz/journal-articles/beyond-psa/

  Grand View Research. Edge AI market size, share & trends analysis report. Published 2024. Accessed {today}. https://www.grandviewresearch.com/industry-analysis/edge-ai-market-report

  Munich Re. Pay-per-part: TRUMPF and Munich Re plan new business model for the manufacturing industry. Published October 14, 2020. Accessed {today}. https://www.munichre.com/en/solutions/for-industry-clients/pay-per-part.html

Return ONLY the citation — nothing else."""


async def _format(url: str, metadata: str) -> str:
    today = date.today().strftime("%B %d, %Y")
    client = AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    r = await client.chat.completions.create(
        model="gpt-4o-mini",
        temperature=0,
        messages=[
            {"role": "system", "content": _PROMPT.format(url=url, today=today)},
            {"role": "user", "content": metadata},
        ],
    )
    return r.choices[0].message.content.strip()


# ── Public API ────────────────────────────────────────────────────────────────

async def cite_url(url: str) -> str:
    """Generate an AMA 11th edition citation for a URL."""
    doi = _extract_doi(url)

    if doi:
        print("  → DOI detected — querying CrossRef …")
        data = await _fetch_crossref(doi)
        metadata = _crossref_to_text(data) if data else await _crawl(url)
    else:
        print("  → Crawling page …")
        metadata = await _crawl(url)

    return await _format(url, metadata)


# ── CLI ───────────────────────────────────────────────────────────────────────

@click.command()
@click.option("--url", prompt="Enter URL", help="URL of the page to cite.")
def main(url: str):
    """Generate an AMA 11th edition citation for a given URL."""
    async def _run():
        print(f"\nFetching {url} …")
        print(f"\n{await cite_url(url)}\n")
    asyncio.run(_run())


if __name__ == "__main__":
    main()
