"""
Inline citation replacement in .docx files.

Maps local reference numbers (1, 2, 3 …) → global UniqueIDs from dedup.
Saves modified copies to an output folder; originals are never touched.
Removes the References section from each output file.

Supported input formats:
  Superscript  5  |  2,3          (converted to bracket output)
  Brackets     [1]  |  [1,2]  |  [1-4]

Output is always square brackets: [42]  |  [18,27]  |  [42-45]
"""

import os
import re

import docx

from tstools import FILE_ORDER

_BRACKET_RE = re.compile(r'\[(\d[\d,\s\-]*)\]')
_REF_HEADING_RE = re.compile(
    r'^(References|Citations|Bibliography|Sources)\s*:?$', re.IGNORECASE
)
_MANUAL_BULLET = re.compile(r'^[\t ]*[\u2022\u00b7\-\*][\t ]+')  # tab-bullet-tab patterns


def _build_local_map(stem: str, dedup_results: dict) -> dict:
    """Return {local_num: unique_id} for citations belonging to *stem*."""
    prefix = stem + "-"
    out = {}
    for cid, r in dedup_results.items():
        if not cid.startswith(prefix):
            continue
        try:
            num = int(cid[len(prefix):])
        except ValueError:
            continue
        uid = r.get("unique_id")
        if uid is not None:
            out[num] = uid
    return out


def _map_superscript_to_brackets(text: str, local_map: dict) -> str | None:
    """
    Convert a superscript run (e.g. '2,3' or '5') to bracket form '[18,27]' or '[42]'.
    Returns the bracket string if any number was mapped, else None (leave run untouched).
    """
    tokens = re.split(r'(\s*,\s*)', text)
    mapped = []
    any_hit = False
    for tok in tokens:
        s = tok.strip()

        if s.isdigit():
            n = int(s)

            if n in local_map:
                mapped.append(str(local_map[n]))
                any_hit = True

            else:
                mapped.append(s)

        else:
            mapped.append(tok)

    if not any_hit:
        return None

    inner = "".join(mapped)

    # 
    return f"[{inner}]"


def _expand_bracket_nums(content: str, local_map: dict) -> tuple[str, bool]:
    stripped = content.strip()

    # Pure range: n-m → uid_n-uid_m
    rm = re.match(r'^(\d+)\s*-\s*(\d+)$', stripped)

    if rm:
        s, e = int(rm.group(1)), int(rm.group(2))
        su, eu = local_map.get(s, s), local_map.get(e, e)
        return f"{su}-{eu}", (su != s) or (eu != e)

    # Comma / single
    nums = [int(x) for x in re.split(r'\s*,\s*', stripped) if x.strip().isdigit()]
    if not nums:
        return content, False

    changed = False
    mapped = []

    for n in nums:
        if n in local_map:
            mapped.append(str(local_map[n]))
            changed = True

        else:
            mapped.append(str(n))

    return ", ".join(mapped), changed


def _replace_brackets(text: str, local_map: dict) -> tuple[str, bool]:

    new = _BRACKET_RE.sub(
        lambda m: f"[{_expand_bracket_nums(m.group(1), local_map)[0]}]", text
    )

    return new, new != text


def _remove_references(doc: docx.Document) -> bool:
    idx = next(
        (i for i, p in enumerate(doc.paragraphs) if _REF_HEADING_RE.match(p.text.strip())),
        None,
    )

    if idx is None:
        return False

    for elem in [p._element for p in doc.paragraphs[idx:]]:
        elem.getparent().remove(elem)

    return True


def replace_inline_citations(file_path: str, dedup_results: dict, output_folder: str) -> str:
    """Replace citation markers in one .docx, save to *output_folder*. Returns output path."""
    stem = os.path.splitext(os.path.basename(file_path))[0]
    local_map = _build_local_map(stem, dedup_results)

    if not local_map:
        print(f"  {stem}: no citation map — skipped")
        return ""

    doc = docx.Document(file_path)
    count = 0

    for para in doc.paragraphs:
        for run in para.runs:

            cleaned = _MANUAL_BULLET.sub("", run.text)
            if cleaned != run.text:
                run.text = cleaned

            # Converts superscripts to brackets.
            if run.font.superscript and run.text.strip():
                mapped = _map_superscript_to_brackets(run.text, local_map)
                if mapped is not None:
                    run.text = mapped
                    run.font.superscript = False
                    count += 1

            elif _BRACKET_RE.search(run.text):
                new, ok = _replace_brackets(run.text, local_map)
                if ok:
                    run.text = new
                    count += 1

    os.makedirs(output_folder, exist_ok=True)
    refs = _remove_references(doc)
    out = os.path.join(output_folder, os.path.basename(file_path))
    doc.save(out)

    note = " (refs removed)" if refs else ""
    print(f"  {stem}: {count} replaced{note} → {out}")
    return out


def replace_all_inline_citations(folder: str, dedup_results: dict, output_folder: str) -> list:
    """Run replacement on every .docx in *folder*."""
    present = {f for f in os.listdir(folder) if f.endswith(".docx") and not f.startswith("~$")}

    files = [f for f in FILE_ORDER if f in present]
    files += sorted(present - set(files))  # If any more files are present, add them. 

    paths = [
        p for f in files
        if (p := replace_inline_citations(os.path.join(folder, f), dedup_results, output_folder))
    ]
    print(f"\nReplacement done: {len(paths)} file(s) → {output_folder}")

    return paths
