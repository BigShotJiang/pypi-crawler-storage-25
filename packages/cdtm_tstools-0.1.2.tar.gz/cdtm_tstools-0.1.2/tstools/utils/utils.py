"""
Core utilities: DOCX reading, citation extraction, CSV/JSON storage of the citations,
verification gate, and bibliography generation.
"""

import csv
import json
import os
import re

from tstools import FILE_ORDER

import docx

_REF_HEADING  = re.compile(
    r'^(References|Citations|Bibliography|Sources)\s*:?$', re.IGNORECASE
)
_LEADING_JUNK  = re.compile(r'^[\u2022\u00b7\-\*\t\s]+')   # bullets, tabs, dashes
_LEADING_NUM   = re.compile(r'^\[?\d+\]?\.?\s+')            # [1] / 1. / [1]. at the start
_TRAILING_NUM  = re.compile(r'\s*\[\d+\]\s*$')              # [1] at the end (brackets required)

# Accessed and strip the date when a DOI is already present.
_ACCESSED_TAIL = re.compile(r'[.,]?\s+Accessed\b.*$', re.IGNORECASE | re.DOTALL)

_HAS_DOI = re.compile(r'(doi:\s*|10\.\d{4,9}/|https?://doi\.org/)', re.IGNORECASE)


#* Reading 

def read_docx(file_path: str) -> str:
    try:
        doc = docx.Document(file_path)
        return '\n'.join(p.text for p in doc.paragraphs)
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return ""


#* Extraction

def extract_citations_from_file(file_path: str) -> dict:
    """Extract citations after the References heading in a single .docx file."""
    stem = os.path.splitext(os.path.basename(file_path))[0]
    text = read_docx(file_path)
    if not text:
        return {}

    lines = [l.strip() for l in text.splitlines()]

    # Regex search for the references heading
    ref_idx = next(
        (i for i, l in enumerate(lines) if _REF_HEADING.match(l)), -1
    )
    if ref_idx == -1:
        print(f"  [!] No references section in {os.path.basename(file_path)}")
        return {}

    # Remove the junk like [1], - or bullet points
    cleaned = {}
    for n, l in enumerate((l for l in lines[ref_idx + 1:] if l.strip()), 1):
        l = _LEADING_JUNK.sub("", l).strip()
        l = _LEADING_NUM.sub("", l).strip()
        cleaned[f"{stem}-{n}"] = l
    return cleaned


def extract_all_citations(folder_path: str) -> dict:
    """Extract citations from every .docx in *folder_path* (sorted, skips temp files)."""
    try:
        present = {
            f for f in os.listdir(folder_path)
            if f.endswith(".docx") and not f.startswith("~$")
        }
        files = [f for f in FILE_ORDER if f in present]
        files += sorted(present - set(files))
    except FileNotFoundError:
        print(f"Folder not found: {folder_path}")
        return {}

    all_cit: dict = {}
    for fname in files:
        fc = extract_citations_from_file(os.path.join(folder_path, fname))
        all_cit.update(fc)
        print(f"  {fname}: {len(fc)} citations")

    print(f"\nTotal: {len(all_cit)} citations from {len(files)} file(s)")
    return all_cit


def fix_citations(citations: dict) -> dict:
    """
    Apply mechanical fixes that need no LLM.

    Currently: strip 'Accessed ...' tail when a DOI is already present
    (unnecessary_accessed issue).
    """
    fixed: dict = {}
    count = 0

    for cid, text in citations.items():

        # Strip trailing [n] reference numbers left over from source documents
        text = _TRAILING_NUM.sub("", text).strip()

        # If the citation has a DOI and the accessed date is present, remove the accessed date
        if _HAS_DOI.search(text) and _ACCESSED_TAIL.search(text):
            text = _ACCESSED_TAIL.sub("", text).strip()
            count += 1
        fixed[cid] = text

    if count:
        print(f"Auto-fixed {count} citation(s): removed unnecessary accessed date")

    return fixed


#* Verification

def verify_output_ready(validation_results: dict, dedup_results: dict) -> bool:
    """Print verification report; return True when everything is clean."""
    issues: dict = {}

    for cid, data in validation_results.items():
        for issue in data.get("issues", []):
            issues.setdefault(issue, []).append(cid)

    reviews = [c for c, r in dedup_results.items() if r.get("review_flag") == "review_needed"]
    clean = not issues and not reviews

    print("\n* Verification")
    if issues:
        print(f"  Validation: {sum(len(v) for v in issues.values())} issue(s)")
        for code, ids in sorted(issues.items()):
            print(f"    {code}: {len(ids)}")
    else:
        print("  Validation: clean")

    if reviews:
        print(f"  Dedup: {len(reviews)} flagged for review")
        for c in reviews:
            print(f"    {c}")
    else:
        print("  Dedup: no pending reviews")

    print(f"  Status: {'READY' if clean else 'NOT READY'}")
    print("\n")
    return clean


#* Persistence

def save_with_validation(
    citations: dict,
    validation_results: dict,
    file_path: str,
    dedup_results: dict | None = None,
):
    """Save citations CSV with validation + optional dedup columns."""
    has_dedup = dedup_results is not None
    header = ["ID", "Citation", "Valid", "Issues"]

    if has_dedup:
        header += ["UniqueID", "DuplicateOf", "MatchType", "ReviewFlag"]

    # Save the citations to the CSV file.
    with open(file_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        
        for cid, text in citations.items():
            v = validation_results.get(cid, {})
            row = [cid, text, v.get("valid", ""), "|".join(v.get("issues", []))]

            if has_dedup:
                d = dedup_results.get(cid, {})
                row += [d.get("unique_id", ""), d.get("duplicate_of", ""),
                        d.get("match_type", ""), d.get("review_flag", "")]

            w.writerow(row)

    print(f"Saved {len(citations)} citations → {file_path}")


def save_dedup_map(dedup_results: dict, file_path: str, citations: dict | None = None):
    """Persist dedup map. If *citations* is provided, embeds the citation text in each entry."""
    output = {}

    for cid, entry in dedup_results.items():

        record = dict(entry)
        if citations and "citation" not in record:
            record["citation"] = citations.get(cid, "")

        output[cid] = record

    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)

    print(f"Dedup map → {file_path}")


def load_dedup_map(file_path: str) -> dict:
    if not os.path.exists(file_path):
        return {}
    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    _warn_duplicate_uids(data)
    return data

#? Just a safety check to not have multiple same unique_ids. 
def _warn_duplicate_uids(dedup_map: dict) -> None:
    """Warn if multiple canonical entries share the same unique_id (indicates a manual edit error)."""
    seen: dict = {}

    for cid, entry in dedup_map.items():
        if entry.get("duplicate_of"):
            continue

        uid = entry.get("unique_id")

        if uid is None:
            continue

        if uid in seen:
            print(f"  [!] unique_id {uid} is shared by two canonicals: "
                  f"'{seen[uid]}' and '{cid}' — fix dedup_map.json manually")
                  
        else:
            seen[uid] = cid


def save_bibliography(citations: dict, dedup_results: dict, file_path: str):
    """Save numbered bibliography: UniqueID | Citation | SourceIDs."""
    bib: dict = {}
    for cid, result in dedup_results.items():

        uid = result.get("unique_id")

        if uid is None:
            continue
        if uid not in bib:
            text = citations.get(cid) or result.get("citation", "")
            bib[uid] = {"citation": text, "ids": []}

        if not result.get("duplicate_of"):
            text = citations.get(cid) or result.get("citation", "")
            bib[uid]["citation"] = text

        bib[uid]["ids"].append(cid)

    with open(file_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["UniqueID", "Citation", "SourceIDs"])
        
        for uid in sorted(bib):
            e = bib[uid]
            w.writerow([uid, e["citation"], "|".join(e["ids"])])

    print(f"Bibliography: {len(bib)} unique → {file_path}")
