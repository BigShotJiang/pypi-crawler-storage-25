# Configure these paths before running

DATA_DIRECTORY    = "data/spring26"
OUTPUT_DIRECTORY  = "data/spring26/output"
SAVE_PATH         = "data/spring26/citations.csv"
DEDUP_MAP_PATH    = "data/spring26/dedup_map.json"
BIBLIOGRAPHY_PATH = "data/spring26/bibliography.csv"
ISSUES_PATH       = "data/spring26/output/issues.md"

FILE_ORDER = [
    "E-Human-AI Teams-Intro.docx",
    "E-Human-AI Teams-2.docx",
    "E-Human-AI Teams-3.docx",
    "E-Industrial Data Flows-Intro.docx",
    "E-Industrial Data Flows-1.docx",
    "E-Industrial Data Flows-2.docx",
    "E-Industrial Data Flows-3.docx",
    "E-Machine-Oriented Factories-Intro.docx",
    "E-Machine-Oriented Factories-1.docx",
    "E-Machine-Oriented Factories-2.docx",
    "E-Machine-Oriented Factories-3.docx",
    "E-Orchestrating the Resource Loop-Intro.docx",
    "E-Orchestrating the Resource Loop-1.docx",
    "E-Orchestrating the Resource Loop-2.docx",
    "E-Orchestrating the Resource Loop-3.docx",
    "I-Complena.docx",
    "I-Flare.docx",
    "I-RiskFlowOS.docx",
    "T-Society-1.docx",
]