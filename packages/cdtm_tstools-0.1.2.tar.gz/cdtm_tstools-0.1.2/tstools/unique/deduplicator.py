"""
Four-phase citation deduplication:
  1. URL/DOI identifier match  (definitive)
  2. Exact normalised text     (definitive)
  3. Title match               (definitive)
  4. Fuzzy similarity ≥ 0.70   (flagged for manual review, not auto-merged)

Pass existing_map to deduplicate() for incremental mode:
  - Known citations are carried forward unchanged (permanent IDs preserved).
  - New citations are matched against the registry first, then each other.
  - Human decisions (match_type='manual', review_flag='confirmed_distinct') are never touched.
"""

import re
from difflib import SequenceMatcher

FUZZY_THRESHOLD = 0.70

_DOI_URL_RE    = re.compile(r'https?://doi\.org/(\S+)', re.IGNORECASE)
_DOI_INLINE_RE = re.compile(r'10\.\d{4,9}/\S+', re.IGNORECASE)
_URL_RE        = re.compile(r'https?://\S+', re.IGNORECASE)
_CIT_NUM_RE    = re.compile(r'^\[?\d+\]?\.?\s*')   # strip leading [1] / 1.


def _extract_identifier(text: str) -> str | None:
    """Return a canonical DOI or URL from the citation, or None."""
    m = _DOI_URL_RE.search(text)
    if m:
        return "doi:" + m.group(1).lower().rstrip(".,)")
    m = _DOI_INLINE_RE.search(text)
    if m:
        return "doi:" + m.group(0).lower().rstrip(".,)")
    m = _URL_RE.search(text)
    if m:
        return m.group(0).lower().rstrip(".,)")
    return None


def _extract_title(text: str) -> str | None:
    """
    Return the normalised title segment of a citation, or None.

    AMA structure: Authors. Title. Source. Year;...
    After stripping a leading citation number the title is always the
    second period-separated segment.  We require ≥ 20 chars so short
    abbreviations or bare years are never mistaken for titles.
    """
    clean = _CIT_NUM_RE.sub("", text.strip())
    parts = re.split(r'\.\s+', clean)
    if len(parts) >= 2:
        title = parts[1].strip()
        if len(title) >= 20:
            return re.sub(r'\s+', ' ', title.lower())
    return None

# Normalize meaning to lowercase and remove extra spaces.
def _normalize(text: str) -> str:
    return re.sub(r'\s+', ' ', text.lower().strip())


def deduplicate(citations: dict, existing_map: dict | None = None) -> dict:
    """
    Four-phase deduplication.

    Clean run (existing_map=None or {}):
      All citations are processed from scratch; unique IDs start at 1.

    Incremental run (existing_map provided):
      - Citations already in the map are carried forward unchanged.
      - New citations are matched against the registry (phases 1-3), then
        within the new batch. Registry matches reuse the existing unique_id.
      - New canonical citations receive IDs continuing from the highest
        existing unique_id.
      - Human decisions are never overwritten -> `manual` and `confirmed_distinct`.
    """
    existing = existing_map or {}

    # Carry forward all existing entries unchanged
    merged: dict = {cid: dict(entry) for cid, entry in existing.items()}

    # Only process citations not already registered
    new_cids = [cid for cid in citations if cid not in merged]

    if existing and not new_cids:
        print("Dedup: no new citations — registry unchanged.")
        return merged

    # Starting uid: 1 for clean run, max+1 for incremental
    next_uid = (
        max((e["unique_id"] for e in merged.values() if e.get("unique_id")), default=0) + 1
        if existing else 1
    )

    # Build lookup indices seeded from the existing registry.
    # Values are ints (existing unique_id) or strs (new-batch citation ID).
    id_index:    dict = {}
    norm_index:  dict = {}
    title_index: dict = {}

    _missing_text = []
    for cid, entry in merged.items():
        if entry.get("duplicate_of"):
            continue

        uid  = entry.get("unique_id")
        text = entry.get("citation", "")

        if uid is None:
            continue
        if not text:
            _missing_text.append(cid)
            continue

        ident = _extract_identifier(text)
        if ident:
            id_index[ident] = uid

        norm_index[_normalize(text)] = uid

        ttl = _extract_title(text)
        if ttl:
            title_index[ttl] = uid

    if _missing_text:
        print(f"  [!] {len(_missing_text)} canonical entry(s) in registry have no citation text — "
              f"matching against them is impossible. Re-run with all source files present to fix.")

    results: dict = {
        cid: {"unique_id": None, "duplicate_of": "", "match_type": "", "review_flag": ""}
        for cid in new_cids
    }

    def _resolve(match_val, cid: str, phase: str) -> None:
        """Apply a match: int means matched existing registry uid, str means matched new-batch cid."""

        if isinstance(match_val, int):
            results[cid]["duplicate_of"] = f"uid:{match_val}"
            results[cid]["unique_id"]    = match_val

        else:
            results[cid]["duplicate_of"] = match_val

        results[cid]["match_type"] = phase

    # Phase 1 — URL/DOI
    for cid in new_cids:
        ident = _extract_identifier(citations[cid])

        if ident is None:
            continue

        if ident in id_index:
            _resolve(id_index[ident], cid, "url_doi")
        else:
            id_index[ident] = cid

    # Phase 2 — Exact text
    for cid in new_cids:
        if results[cid]["duplicate_of"]:
            continue

        norm = _normalize(citations[cid])

        if norm in norm_index:
            _resolve(norm_index[norm], cid, "exact")
        else:
            norm_index[norm] = cid

    # Phase 3 — Title
    for cid in new_cids:
        if results[cid]["duplicate_of"]:
            continue

        ttl = _extract_title(citations[cid])

        if ttl is None:
            continue

        if ttl in title_index:
            _resolve(title_index[ttl], cid, "title")

        else:
            title_index[ttl] = cid

    # Assign unique IDs to new canonicals
    canon_uid: dict = {}

    for cid in new_cids:
        if not results[cid]["duplicate_of"]:

            canon_uid[cid] = next_uid
            results[cid]["unique_id"] = next_uid
            next_uid += 1

    # Propagate uid to within-batch duplicates
    for cid in new_cids:
        dup = results[cid]["duplicate_of"]
        if dup and results[cid]["unique_id"] is None:
            results[cid]["unique_id"] = canon_uid.get(dup)

    # Phase 4 — Fuzzy flag among new canonicals only
    canonicals = [(c, citations[c]) for c in new_cids if not results[c]["duplicate_of"]]
    for i, (a, ta) in enumerate(canonicals):
        for b, tb in canonicals[i + 1:]:
            if SequenceMatcher(None, ta, tb).ratio() >= FUZZY_THRESHOLD:
                results[a]["review_flag"] = "review_needed"
                results[b]["review_flag"] = "review_needed"

    merged.update(results)

    url_doi = sum(1 for r in results.values() if r["match_type"] == "url_doi")
    exact   = sum(1 for r in results.values() if r["match_type"] == "exact")
    title   = sum(1 for r in results.values() if r["match_type"] == "title")
    fuzzy   = sum(1 for r in results.values() if r["review_flag"] == "review_needed")
    new_u   = len(canon_uid)

    # For verbosity and debugging.
    if existing:
        print(f"Incremental dedup: {len(new_cids)} new | {new_u} new unique | "
              f"{url_doi} URL/DOI | {exact} exact | {title} title | {fuzzy} flagged")
    else:
        print(f"Dedup: {next_uid - 1} unique | {url_doi} URL/DOI | {exact} exact | "
              f"{title} title | {fuzzy} flagged")

    return merged
