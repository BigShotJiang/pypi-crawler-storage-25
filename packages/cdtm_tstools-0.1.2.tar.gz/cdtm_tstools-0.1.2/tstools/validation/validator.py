"""AMA 11th edition citation validation."""

import re

from tstools import FILE_ORDER

_STEM_ORDER = [f.removesuffix(".docx") for f in FILE_ORDER]

def _sort_stems(stems):
    """Return stems in FILE_ORDER order; any unlisted stems go to the end, sorted."""
    ordered = [s for s in _STEM_ORDER if s in stems]
    ordered += sorted(s for s in stems if s not in set(_STEM_ORDER))
    return ordered


YEAR_RE     = re.compile(r'\b(19|20)\d{2}\b')
URL_RE      = re.compile(r'https?://', re.IGNORECASE)
DOI_URL_RE  = re.compile(r'https?://doi\.org/', re.IGNORECASE)
DOI_RE      = re.compile(r'(doi:\s*|10\.\d{4,9}/)', re.IGNORECASE)
ACCESSED_RE = re.compile(r'\baccessed\b', re.IGNORECASE)
ONLY_URL_RE = re.compile(r'^https?://\S+$', re.IGNORECASE)
JOURNAL_RE  = re.compile(r';\d+(\(\d+\))?:\d+(-\d+)?')

# Validate a single citation by using regular expressions.
def validate_citation(text: str) -> dict:
    text = text.strip()
    issues = []

    if ONLY_URL_RE.match(text):
        return {"valid": False, "issues": ["url_only"]}

    has_doi     = bool(DOI_RE.search(text)) or bool(DOI_URL_RE.search(text))
    has_url     = bool(URL_RE.search(text)) and not bool(DOI_URL_RE.search(text))
    has_journal = bool(JOURNAL_RE.search(text))
    segments    = re.split(r'\.\s+', text)

    first = segments[0].strip()
    if not first or first[0].isdigit() or URL_RE.match(first):
        issues.append("missing_author")
    if len(segments) < 2:
        issues.append("missing_title")
    if len(segments) < 3:
        issues.append("missing_source")
    if not YEAR_RE.search(text):
        issues.append("missing_year")
    if not (has_url or has_doi or has_journal):
        issues.append("missing_locator")
    if has_url and not has_doi and not ACCESSED_RE.search(text):
        issues.append("missing_accessed")
    if has_doi and ACCESSED_RE.search(text):
        issues.append("unnecessary_accessed")

    return {"valid": len(issues) == 0, "issues": issues}


def validate_all(citations: dict) -> dict:
    results = {}
    valid = 0
    for cid, text in citations.items():

        r = validate_citation(text)
        results[cid] = {"citation": text, "valid": r["valid"], "issues": r["issues"]}
        valid += r["valid"]

    print(f"Validation: {valid}/{len(results)} valid | {len(results) - valid} issues")
    return results


def summarise_issues(validation_results: dict) -> dict:
    breakdown: dict = {}

    for cid, data in validation_results.items():
        for issue in data["issues"]:
            breakdown.setdefault(issue, []).append(cid)

    return breakdown


def _group_by_file(validation_results: dict) -> dict:
    """Return {stem: [(cid, issues), ...]} for citations that have issues."""
    files: dict = {}

    for cid, data in validation_results.items():
        if not data["issues"]:
            continue
        stem = "-".join(cid.split("-")[:-1])
        files.setdefault(stem, []).append((cid, data["issues"]))

    return files

# Split pair meaning : Citations are split into parts due to new lines.
def _detect_split_pairs(entries: list) -> set:
    """
    Return set of entry indices that form a split-citation pair:
    missing_locator at index i immediately followed by url_only at i+1.
    """
    nums  = [int(cid.split("-")[-1]) for cid, _ in entries]
    pairs: set = set()

    for i, (n, (_, issues)) in enumerate(zip(nums, entries)):
        if "missing_locator" in issues and i + 1 < len(entries):
            if nums[i + 1] == n + 1 and "url_only" in entries[i + 1][1]:
                pairs.add(i)
                pairs.add(i + 1)

    return pairs

# Markdown format for the issues report code.
def summarise_by_file(validation_results: dict) -> None:
    """Print a per-file breakdown of validation issues to the terminal."""
    files = _group_by_file(validation_results)

    if not files:
        print("  All citations valid — no issues to report.")
        return

    total = sum(len(v) for v in files.values())
    W = 55

    print(f"\n{'─' * W}")
    print(f"  Validation issues  ·  {total} citation(s) across {len(files)} file(s)")
    print(f"{'─' * W}")

    for stem in _sort_stems(files):
        entries = files[stem]
        pairs   = _detect_split_pairs(entries)

        print(f"\n  {stem}.docx  [{len(entries)}]")

        skip = False

        for i, (cid, issues) in enumerate(entries):
            if skip:
                skip = False
                continue

            num     = cid.split("-")[-1]
            text    = validation_results[cid]["citation"]
            preview = (text[:58] + "…") if len(text) > 58 else text

            if i in pairs and "missing_locator" in issues:

                url_cid  = entries[i + 1][0]
                url_text = validation_results[url_cid]["citation"]
                url_prev = (url_text[:58] + "…") if len(url_text) > 58 else url_text
                num_next = url_cid.split("-")[-1]
                
                print(f"    #{num}+{num_next}  split_citation")
                print(f"           {preview}")
                print(f"        →  {url_prev}")
                skip = True

            else:
                print(f"    #{num:<4} {', '.join(issues):<22}  {preview}")

    print(f"\n{'─' * W}\n")


def save_issues_md(validation_results: dict, file_path: str) -> None:
    """Write a Markdown report of all citation issues grouped by file."""
    from datetime import date

    files = _group_by_file(validation_results)
    total = sum(len(v) for v in files.values())
    lines = []

    lines.append("# Citation Issues Report")
    lines.append(f"\n_Generated {date.today().strftime('%B %d, %Y')}_\n")

    if not files:
        lines.append("**All citations valid — no issues to report.**")

    else:
        lines.append(
            f"**{total} citation(s) with issues across {len(files)} file(s)**\n"
        )

        for stem in _sort_stems(files):
            entries = files[stem]
            pairs   = _detect_split_pairs(entries)
            lines.append(f"---\n")
            lines.append(f"## {stem}.docx  `[{len(entries)}]`\n")

            skip = False
            for i, (cid, issues) in enumerate(entries):

                if skip:
                    skip = False
                    continue

                num  = cid.split("-")[-1]
                text = validation_results[cid]["citation"]

                if i in pairs and "missing_locator" in issues:

                    url_cid  = entries[i + 1][0]
                    url_text = validation_results[url_cid]["citation"]
                    num_next = url_cid.split("-")[-1]
                    lines.append(f"**#{num}+{num_next}** &nbsp; `split_citation`")
                    lines.append(f"> {text}")
                    lines.append(f"> → {url_text}\n")
                    skip = True
                    
                else:
                    badges = " ".join(f"`{issue}`" for issue in issues)
                    lines.append(f"**#{num}**; {badges}")
                    lines.append(f"> {text}\n")

    import os
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    print(f"Issues report → {file_path}")