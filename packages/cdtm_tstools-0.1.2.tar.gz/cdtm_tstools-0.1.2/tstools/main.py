import json
import os

import click

import tstools
from tstools.utils import (
    extract_all_citations, fix_citations, save_with_validation,
    save_dedup_map, load_dedup_map, save_bibliography, verify_output_ready,
    replace_all_inline_citations,
)
from tstools.validation import validate_all, summarise_issues, summarise_by_file, save_issues_md
from tstools.unique import deduplicate


@click.command()
@click.option("--data-dir", default=None, help="Path to the data directory (default: data/spring26).")
@click.option("--replace", is_flag=True, default=False, help="Run inline citation replacement.")
@click.option("--force", is_flag=True, default=False, help="Force replacement even with unresolved issues.")
@click.option("--file-order", default=None, type=click.Path(exists=True),
              help="Path to a JSON file containing the file processing order.")
def main(data_dir, replace, force, file_order):
    """CDTM citation pipeline: extract, validate, deduplicate, replace."""

    if data_dir:
        tstools.DATA_DIRECTORY    = data_dir
        tstools.OUTPUT_DIRECTORY  = os.path.join(data_dir, "output")
        tstools.SAVE_PATH         = os.path.join(data_dir, "citations.csv")
        tstools.DEDUP_MAP_PATH    = os.path.join(data_dir, "dedup_map.json")
        tstools.BIBLIOGRAPHY_PATH = os.path.join(data_dir, "bibliography.csv")
        tstools.ISSUES_PATH       = os.path.join(data_dir, "output", "issues.md")

    if file_order:
        with open(file_order, "r", encoding="utf-8") as f:
            tstools.FILE_ORDER[:] = json.load(f)
    else:
        auto_path = os.path.join(tstools.DATA_DIRECTORY, "file_order.json")
        if os.path.exists(auto_path):
            with open(auto_path, "r", encoding="utf-8") as f:
                tstools.FILE_ORDER[:] = json.load(f)

    citations = extract_all_citations(tstools.DATA_DIRECTORY)
    citations = fix_citations(citations)
    val       = validate_all(citations)

    print("\nIssue breakdown:")
    for code, ids in summarise_issues(val).items():
        print(f"  {code}: {len(ids)}")

    summarise_by_file(val)
    save_issues_md(val, tstools.ISSUES_PATH)

    existing_map = load_dedup_map(tstools.DEDUP_MAP_PATH)
    dedup = deduplicate(citations, existing_map)

    save_with_validation(citations, val, tstools.SAVE_PATH, dedup)
    save_dedup_map(dedup, tstools.DEDUP_MAP_PATH, citations)
    save_bibliography(citations, dedup, tstools.BIBLIOGRAPHY_PATH)

    ready = verify_output_ready(val, dedup)

    if replace:
        if ready or force:
            if not ready:
                print("  --force — proceeding despite issues\n")
            replace_all_inline_citations(tstools.DATA_DIRECTORY, dedup, tstools.OUTPUT_DIRECTORY)
        else:
            print("  Blocked. Fix issues or pass --force.\n")
    else:
        print("  Pass --replace to run inline replacement.\n")


if __name__ == "__main__":
    main()
