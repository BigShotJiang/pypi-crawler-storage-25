# Citation Issues Report

_Generated March 29, 2026_

**29 citation(s) with issues across 7 file(s)**

---

## E-Human-AI Teams-Intro.docx  `[4]`

**#2**; `missing_locator`
> Stracke L, Burggräf P, Sauer CR, Schütz M, Kaiser J. From human to machine: high-impact tasks for AI in production management — an expert study to reshape decision-making. Production Engineering. 2026.

**#3**; `missing_locator`
> Langer M, Baum K, Schlicker N. Effective human oversight of AI-based systems: a signal detection perspective on the detection of inaccurate and unfair outputs. Minds and Machines. 2025.

**#4**; `missing_locator`
> Romeo G, Conti D. Exploring automation bias in human-AI collaboration: a review and implications for explainable AI. AI & Society. 2026.

**#10**; `missing_locator`
> Contreras CA, Rastegarpanah A, Chiou M, Stolkin R. A mini-review on mobile manipulators with variable autonomy. Frontiers in Robotics and AI. 2025.

---

## E-Industrial Data Flows-3.docx  `[4]`

**#1**; `missing_locator`
> Lycklama H, Burkhalter L, Viand A, Küchler N, Hithnawi A. RoFL: Robustness of secure federated learning. Proc IEEE Symp Secur Priv. 2023:453-476

**#2**; `missing_locator`
> Zhao JC, Sharma A, Elkordy AR, Ezzeldin YH, Avestimehr S, Bagchi S. LOKI: Large-scale data reconstruction attack against federated learning through model manipulation. Proc IEEE Symp Secur Priv. 2024:1287-1305

**#6**; `missing_locator`
> Nguyen NB, Chandrasegaran K, Abdollahzadeh M, Cheung NM. Label-only model inversion attacks via knowledge transfer. Adv Neural Inf Process Syst. 2023;36

**#7**; `missing_locator`
> Struppek L, Hintersdorf D, Kersting K. Be careful what you smooth for: Label smoothing can be a privacy shield but also a catalyst for model inversion attacks. Proc Int Conf Learn Represent. 2024

---

## E-Machine-Oriented Factories-1.docx  `[1]`

**#2**; `missing_accessed`
> [2] Verband der Automobilindustrie (VDA). Interface for the communication between automated guided vehicles (AGV) and a master control (VDA 5050). Version 2.1.0. January 2025. Published by VDA; 2025. https://www.vda.de/dam/jcr:f0c9c019-1506-4dee-998a-e92723fbf025/EN-VDA5050-V2_0_0.pdf

---

## E-Machine-Oriented Factories-2.docx  `[13]`

**#4**; `missing_accessed`
> [4] Dassault Systèmes. How Digital Twins Transform Greenfield and Brownfield Steel Plant Projects. 3DS Blog. Published November 11, 2025. https://blog.3ds.com/brands/delmia/how-digital-twins-transform-greenfield-and-brownfield-steel-plant-projects/ [4]

**#5**; `missing_accessed`
> [5] Winterhoff S. Vertical production: The solution for ultra-modern and resource-efficient production buildings. Rothbaum Consulting Blog. Published 2025. https://www.rothbaum-consulting.com/en/blog/vertical-production/ [5]

**#6**; `missing_accessed`
> [6] Johansson A. Corner Factory: Revisiting Urban Manufacturing. Chalmers University of Technology. 2019. https://publications.lib.chalmers.se/records/fulltext/241042/241042.pdf [6]

**#9**; `missing_title` `missing_source` `missing_year` `missing_locator`
> (original)

**#10**; `missing_title` `missing_source` `missing_year` `missing_locator`
> MACHINE-NATIVE AND VERTICAL INFRASTRUCTURE

**#11**; `missing_title` `missing_source` `missing_year` `missing_locator`
> Redesigning industrial facilities as vertically integrated, autonomy-ready systems

**#12**; `missing_year` `missing_locator`
> The transition to autonomous manufacturing would constitute a departure from human-centric facility design toward machine-native infrastructure. This would involve two shifts, modularity and vertical stack integration. Modular factories utilize Reconfigurable Manufacturing Systems (RMS) to allow units to be redeployed as product cycles shorten.[1,2] Parallel modular construction methodologies compress the timelines of overarching facility projects by 30–50%.[3] While greenfield sites are theorized to offer better cost efficiency by eliminating human-centric overhead like HVAC and ambient lighting, the immediate, verifiable market gap is in "autonomy-ready" retrofit stacks for brownfield facilities, supported by digital twin ROI modeling.[4]

**#13**; `missing_source` `missing_year` `missing_locator`
> A big opportunity lies in physically stacking these modular units into high-rise factory configurations. Vertical designs reduce total land footprints, allowing for high-density production without expansive horizontal sprawl, optimizing constrained urban plots.[5] This spatial shift can also incorporate logistical gravity, in which vertical material flows leverage gravity via chutes, slides, or automated downward systems to achieve energy-efficient movement during the assembly process.[6] Furthermore, these facilities drive circular metabolism by reclaiming waste heat from high-density machinery on lower levels to power climate control for the entire stack or adjacent urban structures.[7] Beyond spatial efficiency, transitioning to localized, smart urban manufacturing provides a critical climate-resilient hedge against increasing environmental risks and supply chain shocks, protecting high-value autonomous assets.[8]

**#14**; `missing_year` `missing_locator`
> “The philosophy of the past years has been value-stream centric factory design. This value-stream centricity will prevail but factories will look different. We won’t see a future where humans are replaced by humanoids, but it’s more about smart workflows, maxed out automations, where AI closes gaps.” - Benjamin Erhart, Partner at UVC Partners and Jana Petry, Investment Manager at UVC Partners

**#15**; `missing_title` `missing_source` `missing_year` `missing_locator`
> Sources:

**#19**; `missing_accessed`
> [4] Dassault Systèmes. How Digital Twins Transform Greenfield and Brownfield Steel Plant Projects. 3DS Blog. Published November 11, 2025. https://blog.3ds.com/brands/delmia/how-digital-twins-transform-greenfield-and-brownfield-steel-plant-projects/

**#20**; `missing_accessed`
> [5] Winterhoff S. Vertical production: The solution for ultra-modern and resource-efficient production buildings. Rothbaum Consulting Blog. Published 2025. https://www.rothbaum-consulting.com/en/blog/vertical-production/

**#21**; `missing_accessed`
> [6] Johansson A. Corner Factory: Revisiting Urban Manufacturing. Chalmers University of Technology. 2019. https://publications.lib.chalmers.se/records/fulltext/241042/241042.pdf

---

## E-Machine-Oriented Factories-Intro.docx  `[1]`

**#5**; `missing_locator`
> [5] Piccialli, F., Chiaro, D., et al. AgentAI: A comprehensive survey on autonomous agents in distributed AI for industry 4.0. Expert Systems with Applications. Published June 2, 2025

---

## E-Orchestrating the Resource Loop-1.docx  `[2]`

**#9**; `missing_locator`
> Anonymous Partner, UVC Partners. Interview conducted by Max van Bentum CDTM. March 16, 2026.

**#11**; `missing_accessed`
> European Parliament and Council of the European Union. Regulation (EU) 2024/1252 of the European Parliament and of the Council of 11 April 2024 establishing a framework for ensuring a secure and sustainable supply of critical raw materials and amending Regulations (EU) No 168/2013, (EU) 2018/858, (EU) 2018/1724 and (EU) 2019/1020. Official Journal of the European Union. Published May 3, 2024. Art 18(1)(c). https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32024R1252

---

## E-Orchestrating the Resource Loop-2.docx  `[4]`

**#7+8** &nbsp; `split_citation`
> Hilton B. Design for Remanufacturing. REMADE Institute / US Department of Energy; 2021.
> → https://doi.org/10.2172/1876418

**#11+12** &nbsp; `split_citation`
> Arnold M, Palomäki K, Le Blévennec K, Koop C, Geerken T. Contribution of remanufacturing to circular economy. Eionet Report ETC/WMGE. 2021. Accessed March 18, 2026.
> → https://www.eionet.europa.eu/etcs/etc-wmge/products/etc-wmge-reports/contribution-of-remanufacturing-to-circular-economy/@@download/file

