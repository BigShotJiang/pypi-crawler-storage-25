"""analog-mcp: placeholder for the Analog MCP server.

This release is a name-claim stub. The real MCP server lands in a
follow-up release.
"""

from __future__ import annotations

__version__ = "0.0.1"

__all__ = ["__version__"]
