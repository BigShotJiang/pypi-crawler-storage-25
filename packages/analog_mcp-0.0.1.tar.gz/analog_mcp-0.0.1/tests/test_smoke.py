"""Smoke tests for the analog-mcp stub."""

from __future__ import annotations

import analog_mcp


def test_version_is_set() -> None:
    """__version__ is exposed and is a non-empty string."""
    assert isinstance(analog_mcp.__version__, str)
    assert analog_mcp.__version__
