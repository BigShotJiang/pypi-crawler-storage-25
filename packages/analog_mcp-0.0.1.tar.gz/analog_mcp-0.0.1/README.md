# analog-mcp

Placeholder release for the Analog MCP server.

This version (`0.0.1`) is a name-claim stub. It exposes only a
`__version__` attribute and contains no functional code. The real MCP
server implementation lands in a follow-up release.

## Install

```bash
pip install analog-mcp
```

## License

MIT — see [LICENSE](./LICENSE).

## Links

- Homepage: <https://getanalog.io>
