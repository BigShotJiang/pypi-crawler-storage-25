"""AIL — AI-Intent Language interpreter."""
from __future__ import annotations
from pathlib import Path
from typing import Any, Optional

from .parser import parse
from .runtime import Executor, ConfidentValue, MockAdapter
from .runtime.model import ModelAdapter

__version__ = "1.69.1"


def compile_source(source: str):
    """Parse source to a Program AST."""
    return parse(source)


class _NoCredentialsAdapter:
    """Returned when no credentials are configured.

    Pure-fn programs run fine — this adapter is never called.
    Programs with `intent` will get a clear error at the point the LLM
    is actually needed, not at program startup.
    """
    name = "no_credentials"

    def invoke(self, **_kwargs):
        raise RuntimeError(
            "No model credentials found. Set one of: ANTHROPIC_API_KEY, "
            "AIL_OLLAMA_MODEL, AIL_OPENAI_COMPAT_MODEL + AIL_OPENAI_COMPAT_BASE_URL, "
            "or OPENAI_API_KEY. "
            "For tests or offline use, pass adapter=MockAdapter() explicitly "
            "or use `ail run --mock`."
        )


def _default_adapter() -> ModelAdapter:
    """Pick an adapter based on the environment.

    Preference order:
      1. `AIL_OLLAMA_MODEL` set → OllamaAdapter (local, no API key)
      2. `ANTHROPIC_API_KEY` set → AnthropicAdapter
      3. `AIL_OPENAI_COMPAT_MODEL` or `OPENAI_API_KEY` set → OpenAICompatibleAdapter
      4. No credentials → raise RuntimeError (no silent mock fallback)

    Use MockAdapter() explicitly in tests or pass --mock to `ail run`.
    Implicit fallback to mock was removed to prevent false successes in
    production when credentials are missing.

    Before checking the environment, load a .env file from the current
    working directory or from the parent directories up to a reasonable
    depth. Missing the file is not an error.
    """
    _load_dotenv_if_present()
    return adapter_from_name(_resolve_adapter_name_from_env())


def _resolve_adapter_name_from_env() -> str:
    """Inspect env vars and return the name of the adapter that
    `_default_adapter()` would pick. Used by the CLI to print a
    'using X' banner before any model call so the user is never
    left wondering which model is running (Arche v1.60.9 review)."""
    import os
    if os.environ.get("AIL_OLLAMA_MODEL"):
        return "ollama"
    if os.environ.get("ANTHROPIC_API_KEY"):
        return "anthropic"
    if os.environ.get("AIL_OPENAI_COMPAT_MODEL") or os.environ.get("OPENAI_API_KEY"):
        return "openai"
    return "none"


def adapter_from_name(name: str) -> ModelAdapter:
    """Build an adapter by explicit name. Used by `ail run --adapter NAME`
    and by `_default_adapter()` after env resolution.

    Names: ollama | anthropic | openai | mock | none

    Raises RuntimeError on `none` (no credentials configured) so the
    caller fails fast instead of silently mocking — same behaviour as
    before, but the dispatch point is now a single function.
    """
    name = (name or "").lower()
    if name == "ollama":
        from .runtime.ollama_adapter import OllamaAdapter
        return OllamaAdapter()
    if name == "anthropic":
        from .runtime.anthropic_adapter import AnthropicAdapter
        return AnthropicAdapter()
    if name in ("openai", "openai_compat"):
        from .runtime.openai_adapter import OpenAICompatibleAdapter
        return OpenAICompatibleAdapter()
    if name == "mock":
        return MockAdapter()
    return _NoCredentialsAdapter()


def describe_adapter(adapter: ModelAdapter) -> str:
    """Short single-line description: `<name> (model=<model_id>)`.
    Used by the CLI startup banner so the user always knows which
    adapter is in play."""
    name = getattr(adapter, "name", adapter.__class__.__name__)
    model = getattr(adapter, "model", None)
    if model:
        return f"{name} (model={model})"
    return f"{name}"


def _load_dotenv_file(path: Path) -> None:
    """Load KEY=VALUE pairs from `path` into os.environ (no-overwrite)."""
    import os
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def _load_dotenv_if_present() -> None:
    """Populate os.environ from .env files.

    Search order (all loaded, earlier entries win):
    1. The first .env found in cwd and its parents up to 4 levels.
    2. ~/.ail/.env — the global key store written by `ail` setup wizard.

    Existing os.environ values are never overwritten.
    """
    for base in [Path.cwd()] + list(Path.cwd().parents)[:4]:
        candidate = base / ".env"
        if candidate.is_file():
            _load_dotenv_file(candidate)
            break
    global_env = Path.home() / ".ail" / ".env"
    if global_env.is_file():
        _load_dotenv_file(global_env)


def run(
    source_or_path: str,
    *,
    input: Any = None,
    inputs: Optional[dict[str, Any]] = None,
    adapter: Optional[ModelAdapter] = None,
    ask_human=None,
    metric_fn=None,
    approve_review=None,
    calibrator=None,
    log_callback=None,
) -> tuple[ConfidentValue, "Trace"]:
    """Run an AIL program. Returns (result, trace).

    `source_or_path` can be a path to a .ail file or a source string.
    `input` is a convenience alias for the first entry parameter.
    `inputs` is a dict of all entry parameters.
    `metric_fn(intent_name, value, confidence) -> (metric, rollback)`
       supplies feedback for evolving intents AND updates the
       confidence calibrator. The metric signal (in [0, 1]) is
       interpreted as ground truth for calibration bucketing.
    `approve_review(info) -> bool` handles `require review_by: human`
       gates. Returns True to approve, False to hold.
    `calibrator` — optional Calibrator instance to share across
       multiple run() invocations (useful for programs that run a
       pipeline many times and want calibration to accumulate).
       When None, the executor builds a default one that honors
       AIL_CALIBRATION_PATH for persistence.
    """
    text: str
    looks_like_path = (
        len(source_or_path) < 4096
        and "\n" not in source_or_path
        and "{" not in source_or_path
    )
    if looks_like_path:
        try:
            p = Path(source_or_path)
            if p.exists() and p.is_file():
                text = p.read_text(encoding="utf-8")
            else:
                # Field test 2026-04-29 (박상현): `ail run universal_agent.ail`
                # against a missing file silently fell through to "treat the
                # filename as source", which then parsed `universal_agent.ail`
                # as an IDENT and failed deep inside the parser with a
                # cryptic top-level error. If the arg looks like a path with
                # an .ail extension, fail loudly instead of pretending it's
                # source.
                if source_or_path.endswith(".ail"):
                    raise FileNotFoundError(
                        f"AIL source file not found: {source_or_path} "
                        f"(cwd={Path.cwd()})")
                text = source_or_path
        except (OSError, ValueError):
            if source_or_path.endswith(".ail"):
                raise FileNotFoundError(
                    f"AIL source file not found: {source_or_path} "
                    f"(cwd={Path.cwd()})")
            text = source_or_path
    else:
        text = source_or_path

    program = parse(text)

    project_root = None
    if looks_like_path:
        try:
            p = Path(source_or_path)
            if p.exists() and p.is_file():
                project_root = p.parent.resolve()
        except (OSError, ValueError):
            pass

    adapter = adapter or _default_adapter()
    executor = Executor(
        program, adapter, ask_human=ask_human,
        metric_fn=metric_fn, approve_review=approve_review,
        calibrator=calibrator, log_callback=log_callback,
        project_root=project_root,
    )

    # Server evolve block takes precedence over entry when present
    from .parser.ast import EvolveDecl
    server_evolves = [
        d for d in program.declarations
        if isinstance(d, EvolveDecl) and d.server_arm is not None
    ]
    if server_evolves:
        executor.run_server(server_evolves[0])
        return ConfidentValue(None, 1.0), executor.trace  # type: ignore[return-value]

    entry = program.entry()
    if entry is None:
        raise ValueError("program has no entry declaration")

    resolved_inputs: dict[str, Any] = dict(inputs or {})
    if input is not None and entry.params:
        first_param_name = entry.params[0][0]
        resolved_inputs.setdefault(first_param_name, input)

    result = executor.run_entry(resolved_inputs)
    return result, executor.trace


from .authoring import ask, AskResult, AuthoringError

__all__ = [
    "run", "compile_source", "MockAdapter",
    "ask", "AskResult", "AuthoringError",
    "__version__",
]
