from plum import dispatch
import numpy as np
import numpy.lib.format as nf

from types import NoneType
from dataclasses import replace

from bigraph_schema.schema import (
    Atom,
    Node,
    Union,
    Tuple,
    Boolean,
    Number,
    Integer,
    Float,
    Complex,
    Delta,
    Nonnegative,
    NPRandom,
    String,
    Enum,
    Wrap,
    Maybe,
    Overwrite,
    Const,
    Range,
    List,
    Set,
    Map,
    Tree,
    Array,
    Frame,
    Key,
    Path,
    Wires,
    Schema,
    Link,
    Object,
    schema_dtype,
    is_schema_field,
)

# aligning parameters takes them from positioned arguments and gives them keys
# in a dict.

# reifying the schema takes a dict of representations and turns them into schemas
# according to the parameters

# handling parameters combines these operations to go from positioned arguments to schemas

# we need aligning when parsing, but only reifying when inferring from state
# hence the distinction here

def schema_keys(schema):
    keys = []
    for key in schema.__dataclass_fields__:
        if key.startswith('_') and is_schema_field(schema, key):
            keys.append(key)

    return keys

@dispatch
def align_parameters(schema: Tuple, parameters):
    return {
        '_values': parameters}

@dispatch
def align_parameters(schema: Enum, parameters):
    return {
        '_values': parameters}

@dispatch
def align_parameters(schema: Union, parameters):
    return {
        '_options': parameters}

@dispatch
def align_parameters(schema: Map, parameters):
    align = {}

    if len(parameters) == 1:
        align['_value'] = parameters[0]
    elif len(parameters) == 2:
        align['_key'], align['_value'] = parameters

    return align

@dispatch
def align_parameters(schema: Array, parameters):
    if len(parameters) == 1:
        param = parameters[0]
        if isinstance(param, dict):
            # Structured array: array[field1:type|field2:type]
            return {'_data': param}
        elif isinstance(param, str):
            # Could be shape ("5") or data type name ("float")
            try:
                int(param)
                return {'_shape': param}
            except ValueError:
                return {'_data': param}
        elif isinstance(param, Node):
            # Schema node as data type: array[float] -> Float node
            return {'_data': param}
        else:
            # Assume shape
            return {'_shape': param}
    elif len(parameters) >= 2:
        # Shape + data: array[5,float] or array[5,field1:type|field2:type]
        return {
            '_shape': parameters[0],
            '_data': parameters[1]}

@dispatch
def align_parameters(schema: Frame, parameters):
    return {
        '_columns': parameters[0]}

@dispatch
def align_parameters(schema: Link, parameters):
    align = {
        '_inputs': parameters[0],
        '_outputs': parameters[1]}

    return align

@dispatch
def align_parameters(schema: Range, parameters):
    return {
        '_min': parameters[0],
        '_max': parameters[1]}

_VALID_BITS = {'8', '16', '32', '64', '128'}

@dispatch
def align_parameters(schema: Number, parameters):
    """Parse numeric type parameters: bits and/or units.

    Examples::

        integer[64]      → _bits=64
        float[32]        → _bits=32
        float[fg]        → _units='fg'
        float[64,fg]     → _bits=64, _units='fg'
    """
    result = {}
    for p in parameters:
        if isinstance(p, str) and p in _VALID_BITS:
            result['_bits'] = p
        elif isinstance(p, (int, float)) and str(int(p)) in _VALID_BITS:
            result['_bits'] = str(int(p))
        else:
            result['_units'] = p
    return result

@dispatch
def align_parameters(schema: Set, parameters):
    return {
        '_element': parameters[0]}

@dispatch
def align_parameters(schema: Node, parameters):
    align = {}
    keys = schema_keys(schema)
    for key, parameter in zip(keys, parameters):
        align[key] = parameter
    return align

@dispatch
def align_parameters(schema: Object, parameters):
    """object[module.path.ClassName] — single parameter is the class path."""
    if len(parameters) == 1:
        return {'_class': parameters[0]}
    return {}

@dispatch
def reify_schema(core, schema: Object, parameters):
    if '_class' in parameters:
        cls_param = parameters['_class']
        if isinstance(cls_param, str):
            schema._class = cls_param
    return schema

@dispatch
def align_parameters(schema, parameters):
    raise Exception(f'unknown parameters for schema {schema}: {parameters}')

@dispatch
def reify_schema(core, schema: Range, parameters):
    if '_min' in parameters:
        schema._min = float(parameters['_min'])
    if '_max' in parameters:
        schema._max = float(parameters['_max'])
    return schema

@dispatch
def reify_schema(core, schema: Number, parameters):
    """Set bit width and/or unit string on a Number schema."""
    if '_bits' in parameters:
        bits_param = parameters['_bits']
        schema._bits = int(bits_param) if isinstance(bits_param, str) else bits_param
    if '_units' in parameters:
        units_param = parameters['_units']
        if isinstance(units_param, str):
            schema._units = units_param
    return schema

@dispatch
def reify_schema(core, schema: Enum, parameters):
    if '_values' in parameters:
        schema._values = parameters['_values']
    return schema

@dispatch
def reify_schema(core, schema: Array, parameters):
    shape = parameters.get('_shape', (1,))
    if isinstance(shape, str):
        shape = int(shape)
    if isinstance(shape, list):
        shape = tuple(shape)
    if not isinstance(shape, tuple):
        shape = (shape,)

    schema._shape = tuple([
        int(value)
        for value in shape])

    data = parameters.get('_data', 'float')
    data_schema = core.access(data)
    # Lift _units from inner Number type to the Array itself.
    # array[float[fg]] becomes Array(_data=float, _units='fg').
    if isinstance(data_schema, Number) and data_schema._units:
        schema._units = data_schema._units
    # if isinstance(data, Node):
    #     data = core.render(data)
    # schema._data = nf.descr_to_dtype(data)
    dtype = schema_dtype(data)
    if isinstance(dtype, Array):
        schema = replace(schema, **{'_shape': schema._shape + dtype._shape})
    else:
        schema._data = dtype

    return schema

@dispatch
def reify_schema(core, schema: Frame, parameters):
    schema._columns = parameters['_columns']
    return schema

@dispatch
def reify_schema(core, schema: Union, parameters):
    return replace(schema, **parameters)


def reify_schema_link(core, schema, parameters):
    if 'address' in parameters:
        schema.address = core.access(parameters['address'])
    if 'config' in parameters:
        schema.config = core.access(parameters['config'])
    if 'inputs' in parameters:
        schema.inputs = core.access(parameters['inputs'])
    if 'outputs' in parameters:
        schema.outputs = core.access(parameters['outputs'])
    if '_inputs' in parameters:
        schema._inputs = core.access(parameters['_inputs'])
    if '_outputs' in parameters:
        schema._outputs = core.access(parameters['_outputs'])

    return schema

@dispatch
def reify_schema(core, schema: Link, parameters):
    return reify_schema_link(core, schema, parameters)

@dispatch
def reify_schema(core, schema: Node, parameters):
    for key, parameter in parameters.items():
        subkey = core.access(parameter)

        if hasattr(schema, key):
            field = getattr(schema, key)
            resolve = core.resolve(field, subkey)
        else:
            resolve = subkey

        setattr(schema, key, resolve)

    return schema

@dispatch
def reify_schema(core, schema, parameters):
    raise Exception(f'cannot reify schema {schema} with parameters {parameters}')

def handle_parameters(core, schema, parameters):
    align = align_parameters(schema, parameters)
    return reify_schema(core, schema, align)
