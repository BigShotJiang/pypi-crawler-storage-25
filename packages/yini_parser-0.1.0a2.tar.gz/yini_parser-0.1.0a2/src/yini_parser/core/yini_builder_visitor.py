"""
Transform / build_model -> visitor converts tree to Python values
"""

# src/yini_parser/core/yini_builder_visitor.py
from __future__ import annotations

from typing import Any

from ..api.errors import YiniParseError
from ..grammar.generated.YiniParser import YiniParser
from ..grammar.generated.YiniParserVisitor import YiniParserVisitor
from ..utils.antlr import ctx_location

from .section_headers import parse_section_head
from .value_decoders import decode_string_token, parse_number_literal
from .validator import YiniValidator


class YiniBuilderVisitor(YiniParserVisitor):
    """
    Builds a Python dictionary from the parsed YINI tree.

    Current behavior:
    - Top-level sections become nested dicts.
    - Assignments go into the current section.
    - Lists become Python lists.
    - Inline objects become Python dicts.
    - Booleans become True/False.
    - Null becomes None.
    - Strings become Python str.
    - Numbers become int or float.

    Conflict behavior:
    - lenient mode: first definition wins, later conflicting definitions warn
    - strict mode: conflicting definitions raise YiniParseError
    """

    def __init__(self, strict: bool = False) -> None:
        super().__init__()
        self._strict = strict
        self._root: dict[str, Any] = {}
        self._section_stack: list[dict[str, Any]] = []
        self._section_names: list[str] = []
        self._ignored_section_level: int | None = None
        self._top_level_section_count = 0
        self._validator = YiniValidator(strict=strict)

    # ------------------------------------------------------------
    # Public/root
    # ------------------------------------------------------------

    def visitYini(self, ctx: YiniParser.YiniContext) -> dict[str, Any]:
        for stmt_ctx in ctx.stmt():
            self.visit(stmt_ctx)

        if self._strict:
            if self._top_level_section_count != 1:
                raise YiniParseError(
                    "Strict mode requires exactly one explicit top-level section."
                )

            if ctx.terminal_stmt() is None:
                raise YiniParseError(
                    "Strict mode requires exactly one document terminator."
                )

        return self._root

    # ------------------------------------------------------------
    # Statements
    # ------------------------------------------------------------

    def visitStmt(self, ctx: YiniParser.StmtContext) -> Any:
        section_token = ctx.SECTION_HEAD()
        if section_token is not None:
            symbol = section_token.getSymbol()
            line = symbol.line
            column = symbol.column + 1

            level, name = parse_section_head(
                section_token.getText(),
                line=line,
                column=column,
            )

            # If we are inside an ignored duplicate/conflicting section block,
            # skip deeper nested sections too. Resume only at same or shallower level.
            if self._ignored_section_level is not None:
                if level > self._ignored_section_level:
                    return None
                self._ignored_section_level = None

            if self._strict and level == 1:
                self._top_level_section_count += 1
                if self._top_level_section_count > 1:
                    raise YiniParseError(
                        "Strict mode allows exactly one explicit top-level section.",
                        line=line,
                        column=column,
                    )

            self._enter_section_with_parsed(
                level,
                name,
                line=line,
                column=column,
            )
            return None

        # Skip assignments while inside an ignored duplicate/conflicting section block.
        if self._ignored_section_level is not None:
            return None

        meta_ctx = ctx.meta_stmt()
        if meta_ctx is not None:
            return self.visit(meta_ctx)

        invalid_section_ctx = ctx.invalid_section_stmt()
        if invalid_section_ctx is not None:
            return self.visit(invalid_section_ctx)

        assignment_ctx = ctx.assignment()
        if assignment_ctx is not None:
            return self.visit(assignment_ctx)

        bad_member_ctx = ctx.bad_member()
        if bad_member_ctx is not None:
            return self.visit(bad_member_ctx)

        return None

    def visitMeta_stmt(self, ctx: YiniParser.Meta_stmtContext) -> None:
        """
        Handles metadata-level statements.

        A meta statement can be:
        - A valid directive, such as `@yini`, `@yini strict`, or `@include`.
        - A valid annotation, currently recognized but ignored.
        - Invalid metadata text, which must raise a parse error.
        """

        directive_ctx = ctx.directive()
        if directive_ctx is not None:
            return self.visit(directive_ctx)

        annotation_ctx = ctx.annotation()
        if annotation_ctx is not None:
            return self.visit(annotation_ctx)

        bad_meta_ctx = ctx.bad_meta_text()
        if bad_meta_ctx is not None:
            return self.visit(bad_meta_ctx)

        return None

    def visitDirective(self, ctx: YiniParser.DirectiveContext) -> None:
        """
        Handles parser directives.

        Important:
        - `@yini strict` and `@yini lenient` are document-mode declarations.
        - They do not silently switch parser mode.
        - IMPORTANT: Parser mode is selected by the caller when the parser is invoked.
        - If the declared document mode does not match the selected parser mode,
        parsing fails.
        """

        # `@include` is recognized by the grammar, but currently has no runtime
        # behavior in this parser implementation.
        if ctx.YINI_TOKEN() is None:
            return None

        mode_ctx = getattr(ctx, "yini_mode", lambda: None)()

        # Plain `@yini` is valid and does not declare a required mode.
        if mode_ctx is None:
            return None

        mode = mode_ctx.getText().strip().lower()
        line, column = ctx_location(mode_ctx)

        if mode not in {"strict", "lenient"}:
            raise YiniParseError(
                f"Invalid @yini mode: {mode!r}. Expected 'strict' or 'lenient'.",
                line=line,
                column=column,
            )

        if mode == "strict" and not self._strict:
            raise YiniParseError(
                "This document declares '@yini strict', but the parser is running in lenient mode.",
                line=line,
                column=column,
            )

        if mode == "lenient" and self._strict:
            raise YiniParseError(
                "This document declares '@yini lenient', but the parser is running in strict mode.",
                line=line,
                column=column,
            )

        return None

    def visitAnnotation(self, ctx: YiniParser.AnnotationContext) -> None:
        """
        Handles metadata annotations.

        Annotations are recognized syntax, but they currently do not affect the
        parsed data model. They are ignored by this builder for now.
        """

        return None

    def visitBad_meta_text(self, ctx: YiniParser.Bad_meta_textContext) -> None:
        line, column = ctx_location(ctx)
        raise YiniParseError(
            f"Invalid YINI directive or metadata statement: {ctx.getText()!r}",
            line=line,
            column=column,
        )

    def visitInvalid_section_stmt(self, ctx: YiniParser.Invalid_section_stmtContext) -> None:
        line, column = ctx_location(ctx)
        raise YiniParseError(
            f"Invalid section statement: {ctx.getText()!r}",
            line=line,
            column=column,
        )

    def visitBad_member(self, ctx: YiniParser.Bad_memberContext) -> None:
        line, column = ctx_location(ctx)
        raise YiniParseError(
            f"Invalid member statement: {ctx.getText()!r}",
            line=line,
            column=column,
        )

    def visitAssignment(self, ctx: YiniParser.AssignmentContext) -> None:
        key, value = self.visit(ctx.member())
        target = self._current_container()

        line = ctx.start.line if ctx.start is not None else None
        column = ctx.start.column + 1 if ctx.start is not None else None

        # Assignment-level key/section collision:
        # if an earlier section already exists with this name, the first definition wins.
        existing = target.get(key)
        if isinstance(existing, dict):
            if not self._validator.handle_key_section_collision(
                name=key,
                existing_kind="section",
                incoming_kind="key",
                line=line,
                column=column,
            ):
                return None

        # Duplicate key:
        if key in target:
            if not self._validator.handle_duplicate_key(
                key,
                line=line,
                column=column,
            ):
                return None

        target[key] = value
        return None

    def visitMember(self, ctx: YiniParser.MemberContext) -> tuple[str, Any]:
        key = ctx.KEY().getText()
        value_ctx = ctx.value()

        # In grammar, empty value is allowed and intended to mean null.
        value = self.visit(value_ctx) if value_ctx is not None else None
        return key, value

    # ------------------------------------------------------------
    # Values
    # ------------------------------------------------------------

    def visitValue(self, ctx: YiniParser.ValueContext) -> Any:
        concat_ctx = getattr(ctx, "concat_expression", lambda: None)()
        if concat_ctx is not None:
            return self.visit(concat_ctx)

        scalar_ctx = getattr(ctx, "scalar_value", lambda: None)()
        if scalar_ctx is not None:
            return self.visit(scalar_ctx)

        list_ctx = getattr(ctx, "list_literal", lambda: None)()
        if list_ctx is not None:
            return self.visit(list_ctx)

        object_ctx = getattr(ctx, "object_literal", lambda: None)()
        if object_ctx is not None:
            return self.visit(object_ctx)

        return None

    def visitScalar_value(self, ctx: YiniParser.Scalar_valueContext) -> Any:
        string_ctx = getattr(ctx, "string_literal", lambda: None)()
        if string_ctx is not None:
            return self.visit(string_ctx)

        number_ctx = getattr(ctx, "number_literal", lambda: None)()
        if number_ctx is not None:
            return self.visit(number_ctx)

        null_ctx = getattr(ctx, "null_literal", lambda: None)()
        if null_ctx is not None:
            return self.visit(null_ctx)

        boolean_ctx = getattr(ctx, "boolean_literal", lambda: None)()
        if boolean_ctx is not None:
            return self.visit(boolean_ctx)

        return self.visitChildren(ctx)

    def visitConcat_expression(self, ctx: YiniParser.Concat_expressionContext) -> str:
        first_token = ctx.STRING().getSymbol()
        line = first_token.line
        column = first_token.column + 1

        parts: list[str] = [
            decode_string_token(
                ctx.STRING().getText(),
                line=line,
                column=column,
            )
        ]

        for tail_ctx in ctx.concat_tail():
            parts.append(self.visit(tail_ctx))

        return "".join(parts)

    def visitConcat_tail(self, ctx: YiniParser.Concat_tailContext) -> str:
        return self.visit(ctx.concat_operand())

    def visitConcat_operand(self, ctx: YiniParser.Concat_operandContext) -> str:
        line, column = ctx_location(ctx)

        string_token = ctx.STRING()
        if string_token is not None:
            return decode_string_token(
                string_token.getText(),
                line=line,
                column=column,
            )

        if self._strict:
            raise YiniParseError(
                "Strict mode only allows string literals in string concatenation.",
                line=line,
                column=column,
            )

        number_token = ctx.NUMBER()
        if number_token is not None:
            return number_token.getText()

        true_token = ctx.BOOLEAN_TRUE()
        if true_token is not None:
            return true_token.getText()

        false_token = ctx.BOOLEAN_FALSE()
        if false_token is not None:
            return false_token.getText()

        null_token = ctx.NULL()
        if null_token is not None:
            return null_token.getText()

        return ""

    def visitString_literal(self, ctx: YiniParser.String_literalContext) -> str:
        line, column = ctx_location(ctx)
        return decode_string_token(
            ctx.getText(),
            line=line,
            column=column,
        )

    def visitNull_literal(self, ctx: YiniParser.Null_literalContext) -> None:
        return None

    def visitBoolean_literal(self, ctx: YiniParser.Boolean_literalContext) -> bool:
        text = ctx.getText().strip().lower()
        return text in {"true", "on", "yes"}

    def visitNumber_literal(self, ctx: YiniParser.Number_literalContext) -> int | float:
        line, column = ctx_location(ctx)
        return parse_number_literal(
            ctx.getText().strip(),
            line=line,
            column=column,
        )    

    def visitList_literal(self, ctx: YiniParser.List_literalContext) -> list[Any]:
        if ctx.EMPTY_LIST() is not None:
            return []

        elements_ctx = ctx.elements()
        if elements_ctx is None:
            return []

        return self.visit(elements_ctx)

    def visitElements(self, ctx: YiniParser.ElementsContext) -> list[Any]:
        return [self.visit(value_ctx) for value_ctx in ctx.value()]

    def visitObject_literal(self, ctx: YiniParser.Object_literalContext) -> dict[str, Any]:
        if ctx.EMPTY_OBJECT() is not None:
            return {}

        object_members_ctx = ctx.object_members()
        if object_members_ctx is None:
            return {}

        return self.visit(object_members_ctx)

    def visitObject_members(self, ctx: YiniParser.Object_membersContext) -> dict[str, Any]:
        result: dict[str, Any] = {}

        for member_ctx in ctx.object_member():
            key, value = self.visit(member_ctx)
            
            line = member_ctx.start.line if member_ctx.start is not None else None
            column = member_ctx.start.column + 1 if member_ctx.start is not None else None

            if key in result:
                if not self._validator.handle_duplicate_key(
                    key,
                    line=line,
                    column=column,
                ):
                    continue

            result[key] = value
        return result

    def visitObject_member(self, ctx: YiniParser.Object_memberContext) -> tuple[str, Any]:
        """
        - Lenient mode allows `=`.
        - Strict mode rejects `=` inside inline objects.
        - The canonical inline object member separator remains `:`.
        """

        key = ctx.KEY().getText()
        value = self.visit(ctx.value())

        separator_ctx = ctx.object_member_separator()
        separator = separator_ctx.getText().strip() if separator_ctx is not None else ":"

        if self._strict and separator == "=":
            line, column = ctx_location(separator_ctx or ctx)
            raise YiniParseError(
                "Inline object members must use ':' in strict mode.",
                line=line,
                column=column,
            )

        return key, value

    # ------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------

    def _current_container(self) -> dict[str, Any]:
        if self._section_stack:
            return self._section_stack[-1]
        return self._root

    def _enter_section_with_parsed(
        self,
        level: int,
        name: str,
        *,
        line: int | None = None,
        column: int | None = None,
    ) -> None:
            
        # Root-level section is level 1.
        # level N means nesting depth N.
        while len(self._section_stack) >= level:
            self._section_stack.pop()
            self._section_names.pop()

        parent = self._section_stack[-1] if self._section_stack else self._root
        existing = parent.get(name)

        if existing is None:
            new_section: dict[str, Any] = {}
            parent[name] = new_section
            self._section_stack.append(new_section)
            self._section_names.append(name)
            return

        # Duplicate section name: first definition wins.
        if isinstance(existing, dict):
            if not self._validator.handle_duplicate_section(
                name,
                line=line,
                column=column,
            ):
                self._ignored_section_level = level
                return

            # If validator policy ever changes to allow this.
            self._section_stack.append(existing)
            self._section_names.append(name)
            return

        # Existing scalar/other value, incoming section -> collision.
        if not self._validator.handle_key_section_collision(
            name=name,
            existing_kind="key",
            incoming_kind="section",
            line=line,
            column=column,
        ):
            self._ignored_section_level = level
            return
