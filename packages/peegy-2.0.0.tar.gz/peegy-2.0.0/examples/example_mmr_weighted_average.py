"""
.. _tut-mmr-pipeline-sim:

#########################################################################
Mismatch Response (MMR) analysis with using the Fmpi method (Simulated)
#########################################################################

In this example we simulate a standard and a deviant response and estimate the response using the Fmpi detector.
Here, the noise of the standard and deviant waveforms are considered to correct for the estimation of the MMR and
prevent false response detections.
"""

from peegy.processing.pipe.pipeline import PipePool
from peegy.processing.pipe.simulate import GenerateInputData
from peegy.processing.tools.detection.definitions import TimePeakWindow, PeakToPeakMeasure, TimeROI
from peegy.processing.tools.template_generator.auditory_waveforms import aep
from peegy.processing.pipe.general import FilterData, RemoveBadChannels
from peegy.processing.pipe.epochs import EpochData, AverageEpochs
from peegy.processing.pipe.statistics.f_test import FmpiTestTimeMMR, FmpiTestTime
from peegy.processing.pipe.detection import PeakDetectionTimeDomain
from peegy.processing.pipe.plot import PlotWaveforms, PlotTopographicMap
from peegy.processing.pipe.attach import AppendGFPChannel
from peegy.processing.pipe.storage import MeasurementInformation, SubjectInformation, SaveToDatabase
import os
import numpy as np
import astropy.units as u
# Enable below for interactive backend
# import matplotlib
# if 'qt5agg' in matplotlib.backends.backend_registry.list_builtin():
#     matplotlib.use('qt5agg')

# %%
# Time windows
# ============================
# Time windows are used to define where to look for different peaks


tw = np.array([TimePeakWindow(ini_time=50 * u.ms, end_ref='N1', label='P1', positive_peak=True,
                              exclude_channels=['GFP']),
               TimePeakWindow(ini_time=80 * u.ms, end_time=200 * u.ms, label='N1', positive_peak=False,
                              exclude_channels=['GFP']),
               TimePeakWindow(ini_ref='N1', end_time=300 * u.ms, label='P2', positive_peak=True,
                              exclude_channels=['GFP']),
               TimePeakWindow(ini_time=50 * u.ms, end_time=150 * u.ms, label='gfp1', positive_peak=True,
                              target_channels=['GFP']),
               TimePeakWindow(ini_time=150 * u.ms, end_time=500 * u.ms, label='gfp2', positive_peak=True,
                              target_channels=['GFP'])])

# %%
# Peak-to-peak Measures
# ============================
# Peak-to-peak measures are defined based on the labels of the TimePeaks defined above.


pm = np.array([PeakToPeakMeasure(ini_peak='N1', end_peak='P2')])

# %%
# Time regions of interest
# ============================
# TimeROI are defined as time regions where different measures will be performed, e.g. SNR measure or statistical
# measures


roi_windows = np.array(
    [TimeROI(ini_time=100.0 * u.ms, end_time=250.0 * u.ms, window_label="mmr"),
     TimeROI(ini_time=500.0 * u.ms, end_time=600.0 * u.ms, window_label="control")])

# %%
# Generate some data
# ===================
# First we generate some ACC data

n_channels = 32
fs = 512.0 * u.Hz
return_noise_only=False
template_waveform, _ = aep(fs=fs)
event_times = np.arange(0, 300.0, 1.0) * u.s
noise_attenuation = 3
standard = GenerateInputData(template_waveform=template_waveform,
                             fs=fs,
                             n_channels=n_channels,
                             mixing_matrix=np.diag(np.arange(1, n_channels + 1))/n_channels,
                             layout_file_name='biosemi32.lay',
                             snr=0.05,
                             event_times=event_times,
                             event_code=1.0,
                             figures_subset_folder='mmr_test',
                             include_eog_events=False,
                             noise_attenuation=noise_attenuation,
                             neural_ini_time_snr=0 * u.s,
                             neural_end_time_snr=1 * u.s,
                             return_noise_only=return_noise_only
                             )
standard.run()

event_times = np.arange(0, 60.0, 1.0) * u.s
template_waveform_deviant, _ = aep(fs=fs)
deviant = GenerateInputData(template_waveform=template_waveform_deviant * 3,
                            fs=fs,
                            n_channels=n_channels,
                            mixing_matrix=np.diag(np.arange(1, n_channels + 1))/n_channels,
                            layout_file_name='biosemi32.lay',
                            snr=0.05,
                            event_times=event_times,
                            event_code=1.0,
                            figures_subset_folder='mmr_test',
                            include_eog_events=False,
                            noise_attenuation=noise_attenuation,
                            neural_ini_time_snr=0 * u.s,
                            neural_end_time_snr=1 * u.s,
                            return_noise_only=return_noise_only
                            )
deviant.run()


# %%
# Start the pipeline
# ============================
# Now we proceed with our basic processing pipeline


pipeline = PipePool()
# pipeline['referenced'] = ReferenceData(reader,
#                                        reference_channels=['Cz'],
#                                        invert_polarity=True)
pipeline['channel_cleaned_standard'] = RemoveBadChannels(standard, bad_channels=['EOG1'])
pipeline['channel_cleaned_deviant'] = RemoveBadChannels(deviant, bad_channels=['EOG1'])
# %%
# Continue with the pipeline
# ------------------------------------

pipeline['time_filtered_standard'] = FilterData(pipeline['channel_cleaned_standard'],
                                                high_pass=2.0 * u.Hz,
                                                low_pass=30.0 * u.Hz)
pipeline['time_filtered_deviant'] = FilterData(pipeline['channel_cleaned_deviant'],
                                               high_pass=2.0 * u.Hz,
                                               low_pass=30.0 * u.Hz)

pipeline.run()

# %%
# Get Epochs
# ------------------------------------
# We partition the data into epochs or trials based on the event code used.


pipeline['time_epochs_standard'] = EpochData(pipeline['time_filtered_standard'],
                                             event_code=1.0,
                                             pre_stimulus_interval=200 * u.ms,
                                             post_stimulus_interval=1.0 * u.s)
pipeline.run()

pipeline['time_epochs_deviant'] = EpochData(pipeline['time_filtered_deviant'],
                                            event_code=1.0,
                                            pre_stimulus_interval=200 * u.ms,
                                            post_stimulus_interval=1.0 * u.s)
pipeline.run()

# %%
# Compute MMR
# ------------------------------------
# Using the raw epochs we estimate Hotelling-T2 statistics
pipeline['fmpi_standard'] = FmpiTestTime(pipeline['time_epochs_standard'],
                                         roi_windows=roi_windows,
                                         weighted_average=True,
                                         weight_across_epochs=False,
                                         block_size=1,
                                         )

pipeline['fmpi_deviant'] = FmpiTestTime(pipeline['time_epochs_deviant'],
                                        roi_windows=roi_windows,
                                        weighted_average=True,
                                        weight_across_epochs=False,
                                        block_size=1,
                                        )

pipeline['fmpi_mmr'] = FmpiTestTimeMMR(input_process_deviant=pipeline['time_epochs_deviant'],
                                       input_process_standard=pipeline['time_epochs_standard'],
                                       roi_windows=roi_windows,
                                       weighted_average=True,
                                       weight_across_epochs=False,
                                       block_size=1,
                                       )
pipeline.run()

# %%
# Detect peaks
# ------------------------------------
# Using the average data, we proceed detecting peaks

pipeline['fmpi_mmr_with_peaks'] = PeakDetectionTimeDomain(
    pipeline['fmpi_mmr'],
    time_peak_windows=tw,
    peak_to_peak_measures=pm)

# %%
# Show some waveforms
# ------------------------------------

channels = np.array(['T7', 'C4', 'CP2', 'GFP', 'T8'])
pipeline['plotter'] = PlotWaveforms(pipeline['fmpi_mmr_with_peaks'],
                                    ch_to_plot=channels,
                                    overlay=[pipeline['fmpi_standard'],
                                             pipeline['fmpi_deviant'],
                                             ],
                                    statistical_test='f_test_time',
                                    show_following_stats=['f', 'rn'],
                                    return_figures=True,
                                    )
pipeline.run()

# %%
# Show some topographic maps
# ------------------------------------

pipeline['topographic_map_1'] = PlotTopographicMap(pipeline['fmpi_mmr_with_peaks'],
                                                   topographic_channels=channels,
                                                   plot_x_lim=[0, 0.8],
                                                   plot_y_lim=[-3, 3],
                                                   return_figures=True,
                                                   save_to_file=True)

pipeline['topographic_map_1'] = PlotTopographicMap(pipeline['fmpi_standard'],
                                                   topographic_channels=channels,
                                                   plot_x_lim=[0, 0.8],
                                                   plot_y_lim=[-3, 3],
                                                   return_figures=True,
                                                   save_to_file=True)
pipeline['topographic_map_2'] = PlotTopographicMap(pipeline['fmpi_deviant'],
                                                   topographic_channels=channels,
                                                   plot_x_lim=[0, 0.8],
                                                   plot_y_lim=[-3, 3],
                                                   return_figures=True,
                                                   save_to_file=True)
pipeline.run()

# now we save our data to a database
subject_info = SubjectInformation(subject_id='Test_Subject')
measurement_info = MeasurementInformation(
    date='Today',
    experiment='sim')

_parameters = {'Type': 'ACC'}
database_path = standard.input_node.paths.test_path.joinpath('mmr_test_data_weighted_average_types.sqlite')
pipeline['database'] = SaveToDatabase(database_path=database_path,
                                      measurement_information=measurement_info,
                                      subject_information=subject_info,
                                      recording_information={'recording_device': 'dummy_device'},
                                      stimuli_information=_parameters,
                                      processes_list=[pipeline['fmpi_standard'],
                                                      pipeline['fmpi_deviant'],
                                                      pipeline['fmpi_mmr'],
                                                      # pipeline['fmpi_mmr_uncorrected'],
                                                      ]
                                      )
pipeline.run()

# %%
# Generate pipeline diagram
# ------------------------------------
pipeline.diagram(file_name=standard.output_node.paths.figures_current_dir + 'pipeline.png',
                 return_figure=True,
                 dpi=600)
