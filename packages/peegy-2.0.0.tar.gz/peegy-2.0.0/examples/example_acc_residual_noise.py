"""
.. _tut-acc-standard-residual-noise-pipeline-sim:

#################################################
ACC Standard analysis residual noise (Simulated)
#################################################

In this example we simulate an ACC response and detect the peaks using n standard pipeline.

"""
# Enable below for interactive backend
# import matplotlib
# if 'qt5agg' in matplotlib.backends.backend_registry.list_builtin():
#     matplotlib.use('qt5agg')
from peegy.processing.pipe.pipeline import PipePool
from peegy.processing.pipe.simulate import GenerateInputData
from peegy.processing.tools.detection.definitions import TimeROI
from peegy.processing.tools.template_generator.auditory_waveforms import aep
from peegy.processing.pipe.general import FilterData, ReSampling, ReferenceData
from peegy.processing.pipe.epochs import EpochData
from peegy.processing.pipe.epoching.epoching import EpochsByStep
from peegy.processing.pipe.statistics.f_test import FmpiTestTime
from peegy.processing.pipe.storage import MeasurementInformation, SubjectInformation, SaveToDatabase
import os
import numpy as np
import astropy.units as u

# %%
# Time regions of interest
# ============================
# TimeROI are defined as time regions where different measures will be performed, e.g. SNR measure or statistical
# measures


roi_windows = np.array(
    [TimeROI(ini_time=100.0 * u.ms, end_time=600.0 * u.ms, window_label="acc_snr")])

# %%
# Generate some data
# ===================
# First we generate some ACC data

n_channels = 1
fs = 512.0 * u.Hz
template_waveform, _ = aep(fs=fs, time_length=1 * u.s)
n_epochs = 200
event_times = np.linspace(0, n_epochs-1, n_epochs) * u.s
reader = GenerateInputData(template_waveform=template_waveform,
                           fs=fs,
                           n_channels=n_channels,
                           mixing_matrix=np.diag(np.ones(n_channels)),
                           layout_file_name='biosemi32.lay',
                           snr=0.05,
                           event_times=event_times,
                           event_code=1.0,
                           figures_subset_folder='acc_test_residual_noise',
                           include_eog_events=True,
                           return_eog_channel=False,
                           noise_attenuation=3,
                           return_noise_only=True,
                           )
reader.run()

# %%
# Start the pipeline
# ============================
# Now we proceed with our basic processing pipeline


pipeline = PipePool()
pipeline['down_sampled'] = ReSampling(reader,
                                      new_sampling_rate=256. * u.Hz)
pipeline.run()

# %%
# Continue with the pipeline
# ------------------------------------

pipeline['time_filtered_data'] = FilterData(pipeline['down_sampled'],
                                            high_pass=2.0 * u.Hz,
                                            low_pass=30.0 * u.Hz)

pipeline.run()

# %%
# Get Epochs
# ------------------------------------
# We partition the data into epochs or trials based on the event code used.


pipeline['time_epochs'] = EpochData(pipeline['time_filtered_data'],
                                    event_code=1.0,
                                    post_stimulus_interval=1 * u.s)
pipeline.run()


# %%
# Compute F-value responses
# ------------------------------------
# We compute weighted average on epochs with and without spatial filtering (DSS)

per_epoch_pipeline = PipePool()
per_epoch_pipeline['fmpi'] = FmpiTestTime(pipeline['time_epochs'],
                                          roi_windows=roi_windows,
                                          weight_across_epochs=False,
                                          weighted_average=True)

# now we save our data to a database
subject_info = SubjectInformation(subject_id='Test_Subject')
measurement_info = MeasurementInformation(
    date='Today',
    experiment='sim')

_parameters = {'Type': 'ACC'}
database_path = reader.input_node.paths.test_path.joinpath('acc_test_data_residual_noise.sqlite')
per_epoch_pipeline['database'] = SaveToDatabase(database_path=database_path,
                                                measurement_information=measurement_info,
                                                subject_information=subject_info,
                                                recording_information={'recording_device': 'dummy_device'},
                                                stimuli_information=_parameters,
                                                processes_list=[per_epoch_pipeline['fmpi']]
                                                )
block_size = 1  # defines the average block size used to compute weights
min_epochs = 1  # defines the minium number of epoch. Data with no enough epochs will not be processed.
max_epochs = n_epochs
epoch_block_size = 1
runner = EpochsByStep(at_each_epoch_block_do=per_epoch_pipeline,
                      max_epochs=max_epochs,
                      epochs_step_size=epoch_block_size,
                      event_code=1.0,
                      origin_input_processes=[pipeline['time_epochs']],
                      deep_break=False
                      )
runner.run()


# %%
# Generate pipeline diagram
# ------------------------------------
pipeline.diagram(file_name=reader.output_node.paths.figures_current_dir + 'pipeline.png',
                 return_figure=True,
                 dpi=600)
