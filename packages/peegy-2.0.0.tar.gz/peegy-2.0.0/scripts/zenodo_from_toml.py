import tomllib
import json
from pathlib import Path

# Load pyproject.toml
with open("pyproject.toml", "rb") as f:
    pyproject = tomllib.load(f)

project = pyproject.get("project", {})

# Build creators list
creators = []
for author in project.get("authors", []):
    entry = {"name": author["name"]}
    if "orcid" in author:
        entry["orcid"] = author["orcid"]
    creators.append(entry)

metadata = {
    "title": project.get("name", ""),
    "upload_type": "software",
    "version": project.get("version", ""),
    "description": project.get("description", ""),
    "license": {
        "id": project.get("license", {}).get("text", "")
    },
    "creators": creators
}

zenodo = {"metadata": metadata}

Path("zenodo.json").write_text(
    json.dumps(zenodo, indent=2),
    encoding="utf-8"
)

print("✅ zenodo.json generated from pyproject.toml")