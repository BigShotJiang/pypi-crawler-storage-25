"""
Created on Tue Dec 16 10:55:37 2014

@author: jundurraga-ucl
"""
from peegy.processing.tools import epochs_processing_tools as ept
from peegy.processing.tools import eeg_epoch_operators as eop
from peegy.processing.tools.template_generator.auditory_waveforms import abr
from peegy.tools.signal_generator.noise_functions import generate_modulated_noise
import numpy as np
import matplotlib.pyplot as plt
import astropy.units as u
# Enable below for interactive backend
import matplotlib
if 'qt5agg' in matplotlib.backends.backend_registry.list_builtin():
    matplotlib.use('qt5agg')


def get_cumulative_average(data: np.array = None,
                           target_signal: np.array = None,
                           block_size: int = None,
                           weight_across_epochs: bool = True,
                           samples_distance: int = 10,
                           weighted: bool = False
                           ):

    cumulative_snr = np.array([])
    cumulative_snr_data = np.array([])
    for i in range(data.shape[2] // block_size):
        end_pos = block_size + i * block_size
        sub_set = data[:, :, 0: end_pos]
        ave = ept.et_mean(epochs=sub_set,
                          block_size=block_size,
                          weight_across_epochs=weight_across_epochs,
                          samples_distance=samples_distance,
                          weighted=weighted,
                          fs=fs)

        _rn_data = np.std(ave.average - target_signal[:, :, 0], axis=0)
        snr, s_var, *_ = ept.et_snr_in_rois(data=ave.average, rn=ave.rn)
        snr_data, var_data, *_ = ept.et_snr_in_rois(data=ave.average, rn=_rn_data)
        if i == 0:
            cumulative_snr = snr
            cumulative_snr_data = snr_data
        else:
            cumulative_snr = np.hstack([cumulative_snr, snr])
            cumulative_snr_data = np.hstack([cumulative_snr_data, snr_data])
    return ave, cumulative_snr, cumulative_snr_data


# create synthetic data
fs = 8000.0 * u.Hz
duration = 16 * u.ms
n_channels = 4
n_trials = 1200
noise_dim = 4  # dimensionality of noise
source, _ = abr(fs=fs, time_length=duration)
n_samples = source.shape[0]
coeff = np.ones(n_channels//2) * 0.5 / (n_channels / 2)
coeff = np.expand_dims(np.hstack((coeff, coeff)), 0)
block_size = 100
s = source * coeff
s_std = np.std(s, axis=0)
s = np.tile(np.expand_dims(s, axis=2), (1, 1, n_trials))

desired_snr = 15.0
ini_std = 10.0 ** (-desired_snr / 20.0) * s_std * n_trials ** 0.5
theoretical_rn = ini_std / n_trials ** 0.5

noise = generate_modulated_noise(fs=fs.value,
                                 duration=source.shape[0] * n_trials / fs.value,
                                 f_noise_low=0,
                                 f_noise_high=4000,
                                 attenuation=0,
                                 n_channels=n_channels) * u.uV

noise = ini_std * noise / np.std(noise, axis=0)
noise = eop.et_fold(noise, n_samples)

# # add non-stationary noise
for i in range(3):
    _ini = n_trials//4 + i * 6 * block_size
    noise[:, :, _ini: _ini + block_size] = noise[:, :, _ini: _ini + block_size] * 5
s[:, 0] = s[:, 0] * 0.5

data = noise + s
ave_wae = ept.et_mean(epochs=data,
                      block_size=block_size,
                      samples_distance=10,
                      weighted=True,
                      fs=fs)

ave_wwe = ept.et_mean(epochs=data,
                      weight_across_epochs=False,
                      weighted=True,
                      fs=fs)

ave_s = ept.et_mean(epochs=data,
                    block_size=block_size,
                    weight_across_epochs=True,
                    samples_distance=10,
                    weighted=False,
                    fs=fs)

ave_s_2 = ept.et_mean(epochs=data,
                      block_size=block_size,
                      weight_across_epochs=False,
                      samples_distance=10,
                      weighted=False,
                      fs=fs)

snr_wae, s_var_wae, *_ = ept.et_snr_in_rois(data_node=ave_wae)
snr_wwe, s_var_wwe, *_ = ept.et_snr_in_rois(data_node=ave_wwe)
snr_s, s_var_s, *_ = ept.et_snr_in_rois(data_node=ave_s)
snr_s_2, s_var_s_2, *_ = ept.et_snr_in_rois(data_node=ave_s_2)

print('snr_wae in dB = {:}'.format(10 * np.log10(snr_wae)))
print('snr_wwe in dB = {:}'.format(10 * np.log10(snr_wwe)))
print('snr_s in dB = {:}'.format(10 * np.log10(snr_s)))
print('snr_s_2 in dB = {:}'.format(10 * np.log10(snr_s_2)))

colour_w = 'red'
colour_w_2 = 'orange'
colour_s = 'blue'

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(ave_wae.weights[0, :, :].T, color=colour_w, label='wae')
ax.plot(ave_wwe.weights[0, :, :].T, color=colour_w, label='wwe')
ax.plot(ave_s.weights[0, :, :].T, color=colour_s, label='s')
ax.plot(ave_s_2.weights[0, :, :].T, color=colour_s, label='s2')
ax.set_ylabel("W ")
ax.set_xlabel("Block number")
plt.show()

fig = plt.figure()
ax = fig.add_subplot(111)
ax.set_title('Noise')
ax.plot(np.std(noise, axis=0).T)
ax.set_ylabel("Noise RMS")
ax.set_xlabel("Trial number")
plt.show()


fig = plt.figure()
ax = fig.add_subplot(151)
ax.plot(np.mean(s, axis=2))
ax.set_title('Target signal')

ax = fig.add_subplot(152)
ax.plot(data[:, 0, :], color=colour_w, alpha=0.005)
ax.plot(ave_wae.average, color='black')
ax.set_title('WAE')

ax = fig.add_subplot(153)
ax.plot(data[:, 0, :], color=colour_w_2, alpha=0.005)
ax.plot(ave_wwe.average, color='black')
ax.set_title('WWE')

ax = fig.add_subplot(154)
ax.plot(data[:, 0, :], color=colour_s, alpha=0.005)
ax.plot(ave_s.average, color='black')
ax.set_title('Standard average')
plt.show()

ax = fig.add_subplot(155)
ax.plot(data[:, 0, :], color=colour_s, alpha=0.005)
ax.plot(ave_s_2.average, color='black')
ax.set_title('Standard average 2')
plt.show()
fig.legend()

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(ave_s.cumulative_rn, color=colour_s, label='s')
ax.plot(ave_s_2.cumulative_rn, color=colour_s, label='s2')
ax.set_title('Residual noise')
ax.plot(ave_wae.cumulative_rn, color=colour_w, label='wae')
ax.plot(ave_wwe.cumulative_rn, color=colour_w_2, label='wwe')
fig.legend()
plt.show()


fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(10 * np.log10(snr_s), label='final snr_s', color=colour_s)
ax.plot(10 * np.log10(snr_s_2), label='final snr_s2', color=colour_s)
ax.plot(10 * np.log10(snr_wae), label='final snr_wae', color=colour_w)
ax.plot(10 * np.log10(snr_wwe), label='final snr_wwe', color=colour_w_2)
ax.set_ylabel("SNR [dB]")
ax.set_xlabel("Channel")
ax.axhline(y=desired_snr)
fig.legend()
plt.show()

ave_wae, cum_snr_wae, cum_snr_wae_data = get_cumulative_average(data=data,
                                                                block_size=block_size,
                                                                samples_distance=10,
                                                                weighted=True,
                                                                weight_across_epochs=True,
                                                                target_signal=s)
ave_wwe, cum_snr_wwe, cum_snr_wwe_data = get_cumulative_average(data=data,
                                                                block_size=block_size,
                                                                samples_distance=10,
                                                                weighted=True,
                                                                weight_across_epochs=False,
                                                                target_signal=s)
ave_s, cum_snr_s, cum_snr_s_data = get_cumulative_average(data=data,
                                                          block_size=block_size,
                                                          samples_distance=10,
                                                          weighted=False,
                                                          weight_across_epochs=True,
                                                          target_signal=s)
ave_s_2, cum_snr_s_2, cum_snr_s_data_2 = get_cumulative_average(data=data,
                                                                block_size=block_size,
                                                                samples_distance=10,
                                                                weighted=False,
                                                                weight_across_epochs=False,
                                                                target_signal=s)

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(10 * np.log10(cum_snr_wae.T + 1e-3), color=colour_w, label='WAE')
ax.plot(10 * np.log10(cum_snr_wwe.T + 1e-3), color=colour_w_2, label='WWE')
ax.plot(10 * np.log10(cum_snr_s.T + 1e-3), color=colour_s, label='S')
ax.axhline(y=desired_snr)
ax.set_ylabel("SNR [dB]")
ax.set_xlabel("Block number")
plt.show()

fig = plt.figure()
ax = fig.add_subplot(421)
ax.plot(10 * np.log10(cum_snr_wae.T + 1e-3), color=colour_w)
ax.axhline(y=desired_snr)
ax.set_title("SNRwae [dB]")
ax.set_ylabel("SNR [dB]")
ax.set_xlabel("Block number")

ax = fig.add_subplot(422)
ax.plot(10 * np.log10(cum_snr_wae_data.T + 1e-3), color=colour_w)
ax.axhline(y=desired_snr)
ax.set_title("SNRwae real [dB]")
ax.set_ylabel("SNR [dB]")
ax.set_xlabel("Block number")

ax = fig.add_subplot(423)
ax.plot(10 * np.log10(cum_snr_wwe.T + 1e-3), color=colour_w_2)
ax.axhline(y=desired_snr)

ax.set_title("SNRwwe [dB]")
ax.set_ylabel("SNR [dB]")
ax.set_xlabel("Block number")

ax = fig.add_subplot(424)
ax.plot(10 * np.log10(cum_snr_wwe_data.T + 1e-3), color=colour_w_2)
ax.axhline(y=desired_snr)
ax.set_title("SNRwwe real [dB]")
ax.set_ylabel("SNR [dB]")
ax.set_xlabel("Block number")

ax = fig.add_subplot(425)
ax.plot(10 * np.log10(cum_snr_s.T + 1e-3), color=colour_s)
ax.axhline(y=desired_snr)
ax.set_title("SNRs [dB]")
ax.set_ylabel("SNR [dB]")
ax.set_xlabel("Block number")

ax = fig.add_subplot(426)
ax.set_title("SNRs real [dB]")
ax.plot(10 * np.log10(cum_snr_s_data.T + 1e-3), color=colour_s)
ax.axhline(y=desired_snr)
ax.set_ylabel("SNR [dB]")
ax.set_xlabel("Block number")

ax = fig.add_subplot(427)
ax.plot(10 * np.log10(cum_snr_s_2.T + 1e-3), color=colour_s)
ax.axhline(y=desired_snr)
ax.set_title("SNRs [dB]")
ax.set_ylabel("SNR [dB]")
ax.set_xlabel("Block number")

ax = fig.add_subplot(428)
ax.set_title("SNRs real [dB]")
ax.plot(10 * np.log10(cum_snr_s_data_2.T + 1e-3), color=colour_s)
ax.axhline(y=desired_snr)
ax.set_ylabel("SNR [dB]")
ax.set_xlabel("Block number")
plt.show()
