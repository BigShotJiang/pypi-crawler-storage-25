# -*- coding: utf-8 -*-
"""
Created on Tue Dec 16 10:55:37 2014

@author: jundurraga-ucl
"""
import itertools

# Enable below for interactive backend
import matplotlib
import tqdm
if 'qt5agg' in matplotlib.backends.backend_registry.list_builtin():
    matplotlib.use('qt5agg')


from peegy.definitions.eeg_definitions import TimeROI
from peegy.tools.signal_generator import noise_functions as nf
from peegy.processing.statistics.eeg_statistic_tools import hotelling_t_square_test
import numpy as np
import matplotlib.pyplot as plt
from astropy import units as u
# create  data


def repeat_median(data: np.array = None, n_samples: int = None):
    out = data.copy()
    n_chunks = data.shape[0] // n_samples
    for _chunk in np.arange(n_chunks):
        _ini_sample = _chunk * n_samples
        _end_sample = np.minimum(_ini_sample + n_samples, data.shape[0])
        out[_ini_sample: _end_sample, ...] = np.median(data[_ini_sample: _end_sample], axis=0)
    return out


fs = 8000.0 * u.Hz
epoch_length = 0.03 * 2 * u.s  # in seconds
analysis_window_length = 0.015 * 1 * u.s  # in seconds
n_samples = int(epoch_length * fs)  # samples per epoch
n_trials = 200  # number of epochs per block to test
repetitions = 1000
block_sizes = [n_trials]
block_time = 2 * u.ms
# defines number of sequential tests that will be performed
n_seq_test = np.arange(0, 1).astype(int)
# defines number of samples in analysis windows (which is smaller than epoch length)
n_window = int(analysis_window_length * fs)
# hi-pass cutoff filter should be >= 1 / analysis_window
freq_ini = 1 / (n_window / fs)

uncorrelated_epochs = True
for _block_size in block_sizes:
    p_full_dof = np.zeros((n_seq_test.size, repetitions))
    f_full_dof = np.zeros((n_seq_test.size, repetitions))
    dof_num = np.zeros((n_seq_test.size, repetitions))
    dof_den = np.zeros((n_seq_test.size, repetitions))
    rn_all = np.zeros((n_seq_test.size, repetitions))
    tsq = np.zeros((n_seq_test.size, repetitions))
    items = list(itertools.product(n_seq_test, np.arange(repetitions)))
    for _seq, _rep in tqdm.tqdm(items):
        # The seed is fix for repetitions so that the sequential test has the samples in each block
        # np.random.seed(_rep)
        # noise = np.random.normal(1, size=(n_samples * n_trials * (_seq + 1), 1))
        # uncomment below to play with filter
        noise = nf.generate_modulated_noise(
            fs=fs.value,
            f_noise_low=30,
            f_noise_high=1350,
            duration=n_samples * n_trials * (_seq + 1) / fs.value,
            n_channels=1,
            attenuation=3,
            noise_seed=_rep)
        # noise = repeat_median(noise, n_samples=1)

        noise_filtered = noise
        # apply hi- and low-pass filter (we apply filtfilt twice to increase the order of the filter as
        # low frequency leakage will bias the F-value and will become conservative
        # noise_filtered = filtfilt(b_hp, a_hp, noise_filtered, axis=0)
        # noise_filtered = filtfilt(b_hp, a_hp, noise_filtered, axis=0)
        # noise_filtered = filtfilt(b_lp, a_lp, noise_filtered, axis=0)
        # noise_filtered = filtfilt(b_lp, a_lp, noise_filtered, axis=0)

        # for uncorrelated epochs
        if uncorrelated_epochs:
            data_filtered = noise_filtered.reshape(
                [n_samples, 1, n_trials * (_seq + 1)], order='F')
        else:
            data_filtered = np.zeros((n_samples, 1,  n_trials * (_seq + 1)))
            for n_e in range(n_trials):
                _ini = int(n_samples // 16) * n_e
                _end = _ini + n_samples
                data_filtered[:, :, n_e] = noise_filtered[_ini: _end, :]
        data_filtered = data_filtered * u.dimensionless_unscaled
        # get Fmpi via time domain
        rn_window = np.array([0, n_samples])
        roi_windows = np.array([TimeROI(ini_time=0 * u.s, end_time=n_window / fs)])

        feature_size = int(block_time * fs)

        n_blocks = np.maximum(
            1, np.floor(n_window / feature_size).astype(int)
        )
        # compute features (mean) within ROI
        data_filtered = data_filtered - np.mean(data_filtered[0:n_window, ...], axis=0)
        _ini, _end = 0, n_window
        samples = (np.array(
            [np.mean(data_filtered[_ini + _i * feature_size: _ini + (_i + 1) * feature_size, 0, ...], axis=0,
                     keepdims=True) for _i in range(n_blocks)]) * data_filtered.unit)

        ht_test = hotelling_t_square_test(
            samples
        )

        _iseq = _seq - n_seq_test.min()
        p_full_dof[_iseq, _rep] = ht_test.p_value
        f_full_dof[_iseq, _rep] = ht_test.f
        dof_num[_iseq, _rep] = ht_test.df_1
        dof_den[_iseq, _rep] = ht_test.df_2
        rn_all[_iseq, _rep] = ht_test.rn
        tsq[_iseq, _rep] = ht_test.t_square

    n_bins = 100
    fig = plt.figure()
    gs = fig.add_gridspec(ncols=1, nrows=1)
    ax1 = fig.add_subplot(gs[0, 0])

    fig2 = plt.figure()
    gs2 = fig2.add_gridspec(ncols=1, nrows=1)
    bx1 = fig2.add_subplot(gs[0, 0])

    y_intercept = 1 / n_bins
    for _i, _seq in enumerate(n_seq_test):
        histogram_fill_dof, bin_edges = np.histogram(p_full_dof[_i, :], density=False, bins=n_bins)
        ax1.plot(bin_edges[:-1], histogram_fill_dof / np.sum(histogram_fill_dof), label=str(_i))
        ax1.axhline(y_intercept)
        ax1.set_ylim(0, 10 * y_intercept)

        target_value = np.linspace(0, 1, 1001)
        actual_pvalue_ht2 = []
        for _p in target_value:
            actual_pvalue_ht2.append(np.sum(np.array(p_full_dof[_i, :]).squeeze() < _p) /
                                     np.array(p_full_dof[_i, :]).squeeze().size)

        bx1.plot(target_value, np.array(actual_pvalue_ht2))
    ax1.set_title('HT2')
    ax1.set_xlim(0, 1)

    fig.legend()
    fig2.legend()
    plt.show(block=True)

    fig = plt.figure()
    gs = fig.add_gridspec(ncols=5, nrows=1)
    ax1 = fig.add_subplot(gs[0, 0])
    histogram_dof, bin_edges = np.histogram(dof_num[_i, :], density=False, bins=n_bins)
    ax1.plot(bin_edges[:-1], histogram_dof / np.sum(histogram_dof), label=str(_i))
    ax2 = fig.add_subplot(gs[0, 1])
    histogram_dof, bin_edges = np.histogram(dof_den[_i, :], density=False, bins=n_bins)
    ax2.plot(bin_edges[:-1], histogram_dof / np.sum(histogram_dof), label=str(_i))

    ax3 = fig.add_subplot(gs[0, 2])
    histogram_dof, bin_edges = np.histogram(rn_all[_i, :], density=False, bins=n_bins)
    ax3.plot(bin_edges[:-1], histogram_dof / np.sum(histogram_dof), label=str(_i))

    ax4 = fig.add_subplot(gs[0, 3])
    histogram_dof, bin_edges = np.histogram(f_full_dof[_i, :], density=False, bins=n_bins)
    ax4.plot(bin_edges[:-1], histogram_dof / np.sum(histogram_dof), label=str(_i))
    ax5 = fig.add_subplot(gs[0, 4])
    histogram_dof, bin_edges = np.histogram(tsq[_i, :], density=False, bins=n_bins)
    ax5.plot(bin_edges[:-1], histogram_dof / np.sum(histogram_dof), label=str(_i))
    plt.show(block=True)

print('detection rate for sequential tests: {:}. \n Total detection rate: {:}'.format(
    np.sum(p_full_dof < 0.05 / n_seq_test.size, axis=1) / p_full_dof.shape[1],
    np.sum(np.sum(p_full_dof < 0.05 / n_seq_test.size)) / p_full_dof.shape[1]))
