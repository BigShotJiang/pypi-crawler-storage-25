"""
Created on Tue Dec 16 10:55:37 2014

@author: jundurraga-ucl
"""
from peegy.tools.signal_generator.noise_functions import generate_modulated_noise
import numpy as np
from peegy.processing.statistics.eeg_statistic_tools import analytical_dof, dof_from_psd
from matplotlib.pyplot import cm
import matplotlib.pyplot as plt
import itertools
import astropy.units as u
from scipy.signal import butter, filtfilt
# Enable below for interactive backend
import matplotlib
if 'qt5agg' in matplotlib.backends.backend_registry.list_builtin():
    matplotlib.use('qt5agg')

# create synthetic data
fs = 1000.0 * u.Hz
all_factor = [1]
epoch_length = np.round((2000 * u.ms) * fs) / fs

for factor in all_factor:
    duration = epoch_length * factor
    f_resolution = 1 / duration.to(u.s)
    n_channels = 1
    n_epochs = 1000
    p = np.linspace(0, 3, 7)
    f_low = np.linspace(2, 6, 5) * u.Hz
    f_high = np.linspace(30, 100., 21) * u.Hz
    items = list(itertools.product(p, f_low, f_high))
    analytical = np.zeros((p.size, f_low.size, f_high.size))
    estimated = np.zeros((p.size, f_low.size, f_high.size))
    analytical_reps = []
    estimated_reps = []
    ave_noise = 0
    color = cm.rainbow(np.linspace(0, 1, p.size))

    fig1 = plt.figure()
    for i in range(1):
        for _i_p, _p in enumerate(p):
            for _i_fl, _f_low in enumerate(f_low):
                b_hp, a_hp = butter(3, _f_low.value, 'high', fs=fs.value)
                for _i_fh, _f_high in enumerate(f_high):
                    b_lp, a_lp = butter(3, _f_high.value, 'low', fs=fs.value)
                    attenuation = -_p * 10 * np.log10(0.5)
                    noise = generate_modulated_noise(fs=fs.value,
                                                     duration=duration.to(u.s).value * n_epochs,
                                                     f_noise_low=0,
                                                     f_noise_high=fs.value / 2,
                                                     attenuation=attenuation,
                                                     n_channels=n_channels,
                                                     noise_seed=None)
                    noise_filtered = filtfilt(b_hp, a_hp, noise, axis=0)
                    noise_filtered = filtfilt(b_hp, a_hp, noise_filtered, axis=0)
                    noise_filtered = filtfilt(b_lp, a_lp, noise_filtered, axis=0)
                    noise_filtered = filtfilt(b_lp, a_lp, noise_filtered, axis=0)

                    epoch_noise = noise_filtered[0:int(np.floor(duration.to(u.s) * fs).value) * n_epochs]

                    epoch_noise = np.reshape(epoch_noise, [int(np.floor(duration.to(u.s) * fs).value), 1, n_epochs],
                                             order='F')
                    _fft_power = np.mean(np.abs(np.fft.rfft(epoch_noise, axis=0)) ** 2, axis=2)
                    df_signal = dof_from_psd(psd_noise=_fft_power, psd_noise_n=epoch_noise.shape[0])
                    dof_analytical = analytical_dof(f_low=_f_low,
                                                    f_high=_f_high,
                                                    p=_p,
                                                    length=int(np.floor(duration.to(u.s) * fs).value) / fs) / factor
                    target_psd = np.abs(np.abs(np.fft.rfft(noise_filtered, axis=0)) ** 2) / noise_filtered.shape[0]
                    dof_analytical_2 = dof_from_psd(psd_noise=target_psd, psd_noise_n=epoch_noise.shape[0])
                    target_freq = np.arange(target_psd.shape[0]) * fs / noise_filtered.shape[0]
                    freq_fft = np.arange(_fft_power.shape[0]) * fs / epoch_noise.shape[0]
                    analytical[_i_p, _i_fl, _i_fh] = dof_analytical
                    dof_estimation = df_signal / factor
                    estimated[_i_p, _i_fl, _i_fh] = dof_estimation
                    if _i_fl == 0 and _i_fh == 0:
                        if _i_p == 0:
                            fig1.suptitle('{:} - {:}, {:.2f} resolution'.format(_f_low, _f_high, f_resolution.to(u.Hz)))
                        ax = fig1.add_subplot(p.size, 1, _i_p + 1)
                        ax.set_title('p = {:}'.format(_p), y=0.85)
                        text_legend_analytical = '{:.1f}'.format(dof_analytical)
                        text_legend_empirical = '{:.1f}'.format(dof_estimation[0])
                        ax.plot(target_freq, target_psd, label=text_legend_analytical)
                        ax.plot(freq_fft, _fft_power / epoch_noise.shape[0], label=text_legend_empirical, alpha=0.5)
                        ax.legend(loc="upper right", frameon=False, framealpha=0.0)
                        ax.set_xlim([0, 120])
                        ax.set_xlabel('Frequency [Hz]')
                        if _i_p == p.size // 2:
                            ax.set_ylabel('PSD [A.U. / Hz]')
        analytical_reps.append(analytical)
        estimated_reps.append(estimated)

    analytical = np.mean(analytical_reps, axis=0)
    estimated = np.mean(estimated_reps, axis=0)

    all_axes = fig1.get_axes()
    for ax in all_axes:
        ax.spines['top'].set_visible(False)
        if not ax.get_subplotspec().is_last_row():
            ax.set_xticklabels([])
            ax.set_xlabel('')
        ax.spines['left'].set_visible(True)
        ax.spines['right'].set_visible(False)
    inch = 2.54
    fig1.set_size_inches(10 / inch, 18 / inch)

    fig2 = plt.figure()
    for _i_p, _p in enumerate(p):
        for _i_fl, _f_low in enumerate(f_low):
            if _i_p == 0:
                ax = fig2.add_subplot(1, f_low.size, _i_fl + 1)
            else:
                ax = fig2.get_axes()[_i_fl]
            text_legend_analytical = ''
            text_legend_empirical = ''
            if _i_fl == 0:
                text_legend_analytical = 'Analytical, p = {:}'.format(_p)
                text_legend_empirical = 'Empirical, p = {:}'.format(_p)
            ax.plot(f_high, analytical[_i_p, _i_fl, :], '-*', label=text_legend_analytical, color=color[_i_p], )
            ax.plot(f_high, estimated[_i_p, _i_fl, :], '-o', label=text_legend_empirical, color=color[_i_p])
            ax.set_xlabel("LP [Hz]")
            ax.set_title("HP {:} Hz".format(np.round(_f_low, decimals=1)))
            if _p == 1.0 and _f_low == 200:
                ax.plot(1000, 15, label='', color='black', marker='+', markersize=8)

    fig2.legend()
    fig2.suptitle('{:.2f} resolution'.format(f_resolution.to(u.Hz)))
    print(df_signal)
    error = np.abs(analytical - estimated)
    print(error.max())
    fig2.set_size_inches(24, 12)
    plt.show(block=True)
