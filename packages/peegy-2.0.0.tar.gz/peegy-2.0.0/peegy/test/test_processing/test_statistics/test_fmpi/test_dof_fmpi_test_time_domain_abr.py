# -*- coding: utf-8 -*-
"""
Created on Tue Dec 16 10:55:37 2014

@author: jundurraga-ucl
"""
import itertools

# Enable below for interactive backend
import matplotlib
import tqdm
if 'qt5agg' in matplotlib.backends.backend_registry.list_builtin():
    matplotlib.use('qt5agg')


from peegy.processing.tools import epochs_processing_tools as ept
from peegy.processing.statistics import eeg_statistic_tools as espt
from peegy.definitions.eeg_definitions import TimeROI
from peegy.processing.pipe.simulate import generate_eeg_noise
import peegy.processing.tools.filters.eegFiltering as eegf
from peegy.processing.tools.multiprocessing.multiprocessesing_filter import filt_data
import numpy as np
import matplotlib.pyplot as plt
from astropy import units as u


def repeat_median(data: np.array = None, n_samples: int = None):
    out = data.copy()
    n_chunks = data.shape[0] // n_samples
    for _chunk in np.arange(n_chunks):
        _ini_sample = _chunk * n_samples
        _end_sample = np.minimum(_ini_sample + n_samples, data.shape[0])
        out[_ini_sample: _end_sample, ...] = np.median(data[_ini_sample: _end_sample], axis=0)
    return out


#  create  data
fs = 4000.0 * u.Hz
epoch_length = 20 * u.ms  # in seconds
analysis_window_length = 15 * u.ms  # in seconds
n_samples = int(epoch_length * fs)  # samples per epoch
#  defines number of samples in analysis windows (which is smaller than epoch length)
n_trials = 200  # number of epochs per block to test
repetitions = 1000

f_h = 1 / (n_samples / fs)
block_sizes = [n_trials]

# defines number of sequential tests that will be performed
n_seq_test = np.arange(0, 1).astype(int)


# hi-pass cutoff filter should be >= 1 / analysis_window
freq_ini = (1 / analysis_window_length).to(u.Hz)

n_trials_for_target_snr = 1200
desired_snr_db = 3
target_snr = 10 ** (desired_snr_db / 10) / n_trials_for_target_snr
neural_var = 1  # 0.01503602

_b = eegf.bandpass_fir_win(high_pass=(1 / analysis_window_length).to(u.Hz),
                           low_pass=1350 * u.Hz,
                           fs=fs,
                           ripple_db=60,
                           transition_width=1 * u.Hz,
                           filt_filt_cutoff=False)
_b = _b * u.dimensionless_unscaled

for _block_size in block_sizes:
    p_full_dof = np.zeros((n_seq_test.size, repetitions))
    p_classic_dof = np.zeros((n_seq_test.size, repetitions))
    p_partial_dof = np.zeros((n_seq_test.size, repetitions))
    f_full_dof = np.zeros((n_seq_test.size, repetitions))
    dof_num = np.zeros((n_seq_test.size, repetitions))
    dof_den = np.zeros((n_seq_test.size, repetitions))
    rn_all = np.zeros((n_seq_test.size, repetitions))
    items = list(itertools.product(n_seq_test, np.arange(repetitions)))
    for _seq, _rep in tqdm.tqdm(items):
        # The seed is fix for repetitions so that the sequential test has the samples in each block
        # np.random.seed(_rep)
        # noise = np.random.normal(1, size=(n_samples * n_trials * (_seq + 1), 1))
        # uncomment below to play with filter
        # noise = nf.generate_modulated_noise(
        #     fs=fs,
        #     f_noise_low= 1/analysis_window_length,
        #     f_noise_high=1350, # fs / 2,
        #     f_var_high=30,
        #     f_var_low=1350,
        #     duration=n_samples * n_trials * (_seq + 1) / fs,
        #     n_channels=1,
        #     attenuation=3,
        #     noise_seed=_rep)
        # generate eeg noise
        noise, noise_var = generate_eeg_noise(f_noise_high=fs / 2,
                                              f_noise_low=0 * u.Hz,
                                              f_var_high=1350 * u.Hz,
                                              f_var_low=1 / analysis_window_length.to(u.s),
                                              n_channels=1,
                                              fs=fs,
                                              noise_attenuation=3,
                                              noise_seed=_rep,
                                              noise_covariance_matrix=None,
                                              size=n_samples * n_trials * (_seq + 1),
                                              noise_generation_length_factor=1.0,
                                              include_non_stationary_noise=False,
                                              noise_events_duration=15 * u.s,
                                              noise_events_interval=25 * u.s,
                                              noise_events_power_delta_db=6,
                                              noise_jitter_percentage=0
                                              )
        # noise = repeat_median(noise, n_samples=1)
        scaled_noise = (neural_var * u.uV ** 2 / (target_snr * noise_var)) ** 0.5 * noise
        noise_filtered = filt_data(data=scaled_noise * u.dimensionless_unscaled, b=_b, mode='original')

        data_filtered = noise_filtered.reshape(
            [n_samples, 1, n_trials * (_seq + 1)], order='F') * u.dimensionless_unscaled
        # get Fmpi via time domain
        rn_window = np.array([0, n_samples])
        ave_ap = ept.et_mean(epochs=data_filtered,
                             block_size=1,
                             weighted=True,
                             samples_distance=1,
                             weight_across_epochs=False,  # for cortical
                             demean_epochs=True,
                             demeaned_noise=False,
                             fs=fs,
                             remove_average_for_dof_estimation=True,
                             rn_window=rn_window  # to see the effect of low frequency leak you can,
                             # comment this line and pink noise (attenuation=3 in noise generator) and a number of
                             # samples in n_window
                             )
        roi_windows = np.array([TimeROI(ini_time=0 * u.s, end_time=analysis_window_length)])
        snr, _, _fvalue, _ = ept.et_snr_in_rois(ave_ap.average,
                                                roi_windows=roi_windows,
                                                )
        _roi_samples = int((roi_windows[0].end_time - roi_windows[0].ini_time) * fs)
        _roi_samples = _roi_samples
        _dof_num = ave_ap.dof_within_epochs * _roi_samples / float(np.diff(rn_window))
        f_critic, p_value = espt.f_test(dof_num=_dof_num,
                                        dof_den=ave_ap.dof_rn,
                                        f_value=_fvalue)
        _iseq = _seq - n_seq_test.min()
        p_full_dof[_iseq, _rep] = p_value
        f_full_dof[_iseq, _rep] = _fvalue
        dof_num[_iseq, _rep] = _dof_num
        dof_den[_iseq, _rep] = ave_ap.dof_rn
        rn_all[_iseq, _rep] = ave_ap.rn.value[0]
        f_critic, p_value = espt.f_test(dof_num=np.ones(ave_ap.dof_within_epochs.shape) * 5,
                                        dof_den=data_filtered.shape[2] - 1,
                                        f_value=_fvalue)
        p_classic_dof[_iseq, _rep] = p_value

        f_critic, p_value = espt.f_test(dof_num=ave_ap.dof_within_epochs * _roi_samples / float(np.diff(rn_window)),
                                        dof_den=(data_filtered.shape[2] - 1),
                                        f_value=_fvalue)
        p_partial_dof[_iseq, _rep] = p_value

    n_bins = 200
    fig = plt.figure()
    gs = fig.add_gridspec(ncols=3, nrows=1)
    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[0, 1])
    ax3 = fig.add_subplot(gs[0, 2])
    fig2 = plt.figure()
    gs2 = fig2.add_gridspec(ncols=3, nrows=1)
    bx1 = fig2.add_subplot(gs[0, 0])
    bx2 = fig2.add_subplot(gs[0, 1])
    bx3 = fig2.add_subplot(gs[0, 2])
    y_intercept = 1 / n_bins
    for _i, _seq in enumerate(n_seq_test):
        histogram_fill_dof, bin_edges = np.histogram(p_full_dof[_i, :], density=False, bins=n_bins)
        ax1.plot(bin_edges[:-1], histogram_fill_dof / np.sum(histogram_fill_dof), label=str(_i))
        ax1.axhline(y_intercept)
        ax1.set_ylim(0, 10 * y_intercept)

        histogram_classic_dof, bin_edges = np.histogram(p_classic_dof[_i, :], density=False, bins=n_bins)
        ax2.plot(bin_edges[:-1], histogram_classic_dof / np.sum(histogram_classic_dof))
        ax2.axhline(y_intercept)
        ax2.set_ylim(0, 10 * y_intercept)

        histogram_partial_dof, bin_edges = np.histogram(p_partial_dof[_i, :], density=False, bins=n_bins)
        ax3.plot(bin_edges[:-1], histogram_partial_dof / np.sum(histogram_partial_dof))
        ax3.axhline(y_intercept)
        ax3.set_ylim(0, 10 * y_intercept)

        target_value = np.linspace(0, 1, 1001)
        actual_pvalue_fmpi = []
        actual_pvalue_classic = []
        actual_pvalue_partial_dof = []
        for _p in target_value:
            actual_pvalue_fmpi.append(np.sum(np.array(p_full_dof[_i, :]).squeeze() < _p) /
                                      np.array(p_full_dof[_i, :]).squeeze().size)
            actual_pvalue_classic.append(np.sum(np.array(p_classic_dof[_i, :]).squeeze() < _p) /
                                         np.array(p_classic_dof[_i, :]).squeeze().size)
            actual_pvalue_partial_dof.append(np.sum(np.array(p_partial_dof[_i, :]).squeeze() < _p) /
                                             np.array(p_partial_dof[_i, :]).squeeze().size)

        bx1.plot(target_value, np.array(actual_pvalue_fmpi))
        bx2.plot(target_value, np.array(actual_pvalue_classic))
        bx3.plot(target_value, np.array(actual_pvalue_partial_dof))
    ax1.set_title('Fmpi')
    ax1.set_xlim(0, 1)
    ax2.set_title('Classic')
    ax2.set_xlim(0, 1)
    ax3.set_title('Alternative')
    ax3.set_xlim(0, 1)
    fig.legend()
    fig2.legend()
    plt.show(block=True)

    fig = plt.figure()
    gs = fig.add_gridspec(ncols=3, nrows=1)
    ax1 = fig.add_subplot(gs[0, 0])
    histogram_dof, bin_edges = np.histogram(dof_num[_i, :], density=False, bins=n_bins)
    ax1.plot(bin_edges[:-1], histogram_dof / np.sum(histogram_dof), label=str(_i))
    ax2 = fig.add_subplot(gs[0, 1])
    histogram_dof, bin_edges = np.histogram(dof_den[_i, :], density=False, bins=n_bins)
    ax2.plot(bin_edges[:-1], histogram_dof / np.sum(histogram_dof), label=str(_i))

    ax3 = fig.add_subplot(gs[0, 2])
    histogram_dof, bin_edges = np.histogram(rn_all[_i, :], density=False, bins=n_bins)
    ax3.plot(bin_edges[:-1], histogram_dof / np.sum(histogram_dof), label=str(_i))
    plt.show(block=True)

print('detection rate for sequential tests: {:}. \n Total detection rate: {:}'.format(
    np.sum(p_full_dof < 0.05 / n_seq_test.size, axis=1) / p_full_dof.shape[1],
    np.sum(np.sum(p_full_dof < 0.05 / n_seq_test.size)) / p_full_dof.shape[1]))
