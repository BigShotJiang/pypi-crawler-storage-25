# -*- coding: utf-8 -*-
"""
Created on Tue Dec 16 10:55:37 2014

@author: jundurraga-ucl
"""
import itertools

# Enable below for interactive backend
import matplotlib
import tqdm
if 'qt5agg' in matplotlib.backends.backend_registry.list_builtin():
    matplotlib.use('qt5agg')

from peegy.processing.tools.detection.definitions import TimeROI
from peegy.processing.tools import epochs_processing_tools as ept
from peegy.processing.statistics import eeg_statistic_tools as espt
from peegy.tools.signal_generator import noise_functions as nf
from peegy.definitions.channel_definitions import Domain
import numpy as np
import matplotlib.pyplot as plt
from astropy import units as u
# from scipy.signal import butter
# create  data
fs = 252.0
n_samples = 252  # samples per epoch
n_trials = 20  # number of epochs per block to test
repetitions = 1000
f_h = 1 / (n_samples / fs)
# b_hp, a_hp = butter(3, f_h, 'high', fs=fs)
# b_lp, a_lp = butter(3, 1500, 'low', fs=fs)
block_sizes = [1]
# defines number of sequential tests that will be performed
n_seq_test = np.arange(0, 1).astype(int)
# defines number of samples in analysis windows (which is smaller than epoch length)
n_window = 252 // 1
# hi-pass cutoff filter should be >= 1 / analysis_window
freq_ini = 1 / (n_window / fs) * u.Hz
freq_end = 128 * u. Hz
# frequency_resolution = 1 / (n_samples / (fs * u.Hz))
frequency_resolution = None
# freq_ini = None
# freq_end = None
# frequency_resolution = None
roi_windows = np.array(
        [
            TimeROI(
                ini_time=0 * u.ms,
                end_time=np.inf * u.ms,
                show_window=True,
                show_label=False,
            )
        ]
    )
for _block_size in block_sizes:
    p_full_dof = np.zeros((n_seq_test.size, repetitions))
    p_classic_dof = np.zeros((n_seq_test.size, repetitions))
    p_partial_dof = np.zeros((n_seq_test.size, repetitions))
    f_full_dof = np.zeros((n_seq_test.size, repetitions))
    items = list(itertools.product(n_seq_test, np.arange(repetitions)))
    for _seq, _rep in tqdm.tqdm(items):
        # The seed is fix for repetitions so that the sequential test has the samples in each block
        # np.random.seed(_rep)
        # noise = np.random.normal(1, size=(n_samples * n_trials * (_seq + 1), 1))
        # uncomment below to play with filter
        # use code below if you want to use perfect noise with the caveat that your f values will by an almost perfect 1
        # and your p value 0.5!
        noise = nf.generate_modulated_noise(
            fs=fs,
            f_noise_low=0,
            f_noise_high=fs / 2,
            duration=n_samples * n_trials * (_seq + 1) / fs,
            n_channels=1,
            attenuation=3,
            noise_seed=_rep)

        data_unfiltered = noise.reshape([n_samples, 1,  n_trials * (_seq + 1)], order='F') * u.dimensionless_unscaled
        # get Fmpi via frequency domain using raw data (spectral filter)
        data_unfiltered = np.pad(data_unfiltered, ((0, 260), (0, 0), (0, 0)), 'constant',
                                 constant_values=0)
        ave_ap = ept.et_mean(epochs=data_unfiltered,
                             block_size=1,
                             weighted=True,
                             samples_distance=1,
                             weight_across_epochs=False,
                             demean_epochs=True,
                             freq_ini=freq_ini,
                             freq_end=freq_end,
                             fs=fs * u. Hz,
                             rn_domain=Domain.frequency,  # This defines that we will use a pure frequency-base approach
                             )
        snr, _, _fvalue, _ = ept.et_snr_in_rois(ave_ap.average,
                                                roi_windows=roi_windows,
                                                freq_ini=freq_ini,
                                                freq_end=freq_end,
                                                frequency_resolution=frequency_resolution  # this is important as we
                                                # don't want the energy to change due to different time window lengths
                                                )
        f_critic, p_value = espt.f_test(dof_num=ave_ap.dof_within_epochs * n_window / ave_ap.average.data.shape[0],
                                        dof_den=ave_ap.dof_rn,
                                        f_value=_fvalue)
        _iseq = _seq - n_seq_test.min()
        p_full_dof[_iseq, _rep] = p_value
        f_full_dof[_iseq, _rep] = _fvalue

        f_critic, p_value = espt.f_test(dof_num=np.ones(ave_ap.dof_within_epochs.shape) * 5,
                                        dof_den=data_unfiltered.shape[2] - 1,
                                        f_value=_fvalue)
        p_classic_dof[_iseq, _rep] = p_value

        f_critic, p_value = espt.f_test(dof_num=ave_ap.dof_within_epochs * n_window / ave_ap.average.data.shape[0],
                                        dof_den=(data_unfiltered.shape[2] - 1),
                                        f_value=_fvalue)
        p_partial_dof[_iseq, _rep] = p_value

    n_bins = 100
    fig = plt.figure()
    gs = fig.add_gridspec(ncols=3, nrows=1)
    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[0, 1])
    ax3 = fig.add_subplot(gs[0, 2])
    fig2 = plt.figure()
    gs2 = fig2.add_gridspec(ncols=3, nrows=1)
    bx1 = fig2.add_subplot(gs[0, 0])
    bx2 = fig2.add_subplot(gs[0, 1])
    bx3 = fig2.add_subplot(gs[0, 2])
    y_intercept = 1 / n_bins
    for _i, _seq in enumerate(n_seq_test):
        histogram_fill_dof, bin_edges = np.histogram(p_full_dof[_i, :], density=False, bins=n_bins)
        ax1.plot(bin_edges[:-1], histogram_fill_dof / np.sum(histogram_fill_dof), label=str(_i))
        ax1.axhline(y_intercept)
        ax1.set_ylim(0, 2 * y_intercept)

        histogram_classic_dof, bin_edges = np.histogram(p_classic_dof[_i, :], density=False, bins=n_bins)
        ax2.plot(bin_edges[:-1], histogram_classic_dof / np.sum(histogram_classic_dof))
        ax2.axhline(y_intercept)
        ax2.set_ylim(0, 2 * y_intercept)

        histogram_partial_dof, bin_edges = np.histogram(p_partial_dof[_i, :], density=False, bins=n_bins)
        ax3.plot(bin_edges[:-1], histogram_partial_dof / np.sum(histogram_partial_dof))
        ax3.axhline(y_intercept)
        ax3.set_ylim(0, 2 * y_intercept)

        target_value = np.linspace(0, 1, 1001)
        actual_pvalue_fmpi = []
        actual_pvalue_classic = []
        actual_pvalue_partial_dof = []
        for _p in target_value:
            actual_pvalue_fmpi.append(np.sum(np.array(p_full_dof[_i, :]).squeeze() < _p) /
                                      np.array(p_full_dof[_i, :]).squeeze().size)
            actual_pvalue_classic.append(np.sum(np.array(p_classic_dof[_i, :]).squeeze() < _p) /
                                         np.array(p_classic_dof[_i, :]).squeeze().size)
            actual_pvalue_partial_dof.append(np.sum(np.array(p_partial_dof[_i, :]).squeeze() < _p) /
                                             np.array(p_partial_dof[_i, :]).squeeze().size)

        bx1.plot(target_value, np.array(actual_pvalue_fmpi))
        bx2.plot(target_value, np.array(actual_pvalue_classic))
        bx3.plot(target_value, np.array(actual_pvalue_partial_dof))
    ax1.set_title('Fmpi')
    ax1.set_xlim(0, 1)
    ax2.set_title('Classic')
    ax2.set_xlim(0, 1)
    ax3.set_title('Alternative')
    ax3.set_xlim(0, 1)
    fig.legend()
    fig2.legend()
    plt.show(block=True)

print('detection rate for sequential tests: {:}. \n Total detection rate: {:}'.format(
    np.sum(p_full_dof < 0.05 / n_seq_test.size, axis=1) / p_full_dof.shape[1],
    np.sum(np.sum(p_full_dof < 0.05 / n_seq_test.size)) / p_full_dof.shape[1]))
