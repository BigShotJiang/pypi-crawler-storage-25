# -*- coding: utf-8 -*-
"""
Created on Tue Dec 16 10:55:37 2014

@author: jundurraga
"""
import itertools
import matplotlib
import tqdm
# Enable below for interactive backend
if 'qt5agg' in matplotlib.backends.backend_registry.list_builtin():
    matplotlib.use('qt5agg')


from peegy.processing.tools import epochs_processing_tools as ept
from peegy.processing.statistics import eeg_statistic_tools as espt
from peegy.tools.signal_generator import noise_functions as nf
import numpy as np
import matplotlib.pyplot as plt
from astropy import units as u
# define data parameters ##############
fs = 252.0
n_samples = 252  # samples per epoch
n_trials_1 = 4 * 64 // 10  # number of epochs per block to test 1
n_trials_2 = 4 * 64 // 1  # number of epochs per block to test 2
attenuation_1 = 0  # noise type 1
attenuation_2 = 0  # noise type 2
repetitions = 10000

# defines number of samples in analysis windows (which should be equal or smaller than epoch length)
n_window = 252 // 1

p_merged_fmpi = np.zeros((1, repetitions))
p_fmpi = np.zeros((1, repetitions))

items = list(itertools.product(np.arange(repetitions)))
for rep in tqdm.tqdm(items):
    # generate noise for data set_1
    noise_1 = nf.generate_modulated_noise(
        fs=fs,
        f_noise_low=0,
        f_noise_high=fs / 2,
        duration=n_samples * n_trials_1 / fs,
        n_channels=1,
        attenuation=attenuation_1)
    data_filtered_1 = noise_1.reshape(
        [n_samples, 1, n_trials_1], order='F') * u.dimensionless_unscaled

    # get mean of data set_1 (time domain)
    ave_1 = ept.et_mean(epochs=data_filtered_1,
                        block_size=1,
                        weighted=True,
                        samples_distance=1,
                        weight_across_epochs=False,  # for cortical
                        demean_epochs=True,
                        fs=fs * u.Hz,
                        rn_window=np.array([0, n_window])
                        )

    # generate noise for data set_2
    noise_2 = nf.generate_modulated_noise(
        fs=fs,
        f_noise_low=0,
        f_noise_high=fs / 2,
        duration=n_samples * n_trials_2 / fs,
        n_channels=1,
        attenuation=attenuation_2)

    data_filtered_2 = noise_2.reshape(
        [n_samples, 1, n_trials_2], order='F') * u.dimensionless_unscaled

    # get mean of data set_2 (time domain)
    ave_2 = ept.et_mean(epochs=data_filtered_2,
                        block_size=1,
                        weighted=True,
                        samples_distance=1,
                        weight_across_epochs=False,  # for cortical
                        demean_epochs=True,
                        fs=fs * u.Hz,
                        rn_window=np.array([0, n_window])
                        )

    # combine all epochs (ideal case)
    data_3 = np.concatenate([data_filtered_1, data_filtered_2], axis=2)
    # compute mean of all epochs (data set_1 and set_2)
    ave_3 = ept.et_mean(epochs=data_3,
                        block_size=1,
                        weighted=True,
                        samples_distance=1,
                        weight_across_epochs=False,  # for cortical
                        demean_epochs=True,
                        fs=fs * u.Hz,
                        rn_window=np.array([0, n_window])
                        )

    # now the tricks to estimate the RN, F-value, and pvalue from the two averaged data sets
    # estimate effective number of trials
    n_t1 = ave_1.dof_rn / ave_1.dof_within_epochs
    n_t2 = ave_2.dof_rn / ave_2.dof_within_epochs

    # estimate the variance of the background noise from each data set and put them in vector
    bn2 = np.array([n_t1 * ave_1.rn ** 2, n_t2 * ave_2.rn ** 2])
    # estimate the weights to combine the two averages
    w = 1 / bn2

    # get the combined residual noise
    total_rn = np.sqrt(1 / np.sum(n_t1 / bn2[0] + n_t2 / bn2[1]))

    # estimate the total degrees of freedom for the denominator
    total_dof_den = ave_1.dof_rn + ave_2.dof_rn

    # estimate weighted averaged waveform
    total_average = ((n_t1 * ave_1.average * w[0] + n_t2 * ave_2.average * w[1]) /
                     (n_t1 * w[0] + n_t2 * w[1]))

    # estimate the new degrees of freedom of the numerator
    total_dof_num = ((n_t1 * ave_1.dof_within_epochs * w[0] + n_t2 * ave_2.dof_within_epochs * w[1]) /
                     (n_t1 * w[0] + n_t2 * w[1]))

    # compute the f- and p-value for the estimation
    roi_windows = [np.array([0, n_window])]

    snr, _, _fvalue, _ = ept.et_snr_in_rois(total_average,
                                            roi_windows=roi_windows,
                                            rn=total_rn,
                                            fs=fs * u.Hz
                                            )
    f_critic, p_value = espt.f_test(dof_num=total_dof_num * n_window / total_average.shape[0],
                                    dof_den=total_dof_den,
                                    f_value=_fvalue)
    p_merged_fmpi[0, rep] = float(p_value)

    # compute the f- and p-value for all epochs (ideal case)
    snr, _, _fvalue, _ = ept.et_snr_in_rois(ave_3.average,
                                            roi_windows=roi_windows,
                                            rn=ave_3.rn,
                                            fs=fs * u.Hz
                                            )
    f_critic, p_value = espt.f_test(dof_num=ave_3.dof_within_epochs * n_window / ave_3.average.shape[0],
                                    dof_den=ave_3.dof_rn,
                                    f_value=_fvalue)
    p_fmpi[0, rep] = float(p_value)
    # plot the waveform just for the first case
    # uncomment below
    # if rep == 0:
    #     plt.plot(ave_1.average)
    #     plt.plot(ave_2.average)
    #     plt.plot(total_average)
    #     plt.show()


n_bins = 100
fig = plt.figure()
gs = fig.add_gridspec(ncols=2, nrows=1)
ax1 = fig.add_subplot(gs[0, 0])
ax2 = fig.add_subplot(gs[0, 1])
fig2 = plt.figure()
gs2 = fig2.add_gridspec(ncols=2, nrows=1)
bx1 = fig2.add_subplot(gs[0, 0])
bx2 = fig2.add_subplot(gs[0, 1])
y_intercept = 1 / n_bins


histogram_fill_dof, bin_edges = np.histogram(p_merged_fmpi[0, :], density=False, bins=n_bins)
ax1.plot(bin_edges[:-1], histogram_fill_dof / np.sum(histogram_fill_dof), label=str(0))
ax1.axhline(y_intercept)
ax1.set_ylim(0, 2 * y_intercept)

histogram_classic_dof, bin_edges = np.histogram(p_fmpi[0, :], density=False, bins=n_bins)
ax2.plot(bin_edges[:-1], histogram_classic_dof / np.sum(histogram_classic_dof))
ax2.axhline(y_intercept)
ax2.set_ylim(0, 2 * y_intercept)
target_value = np.linspace(0, 1, 1001)
actual_pvalue_merged_fmpi = []
actual_pvalue_fmpi = []
for _p in target_value:
    actual_pvalue_merged_fmpi.append(np.sum(np.array(p_merged_fmpi[0, :]).squeeze() < _p) /
                                     np.array(p_merged_fmpi[0, :]).squeeze().size)
    actual_pvalue_fmpi.append(np.sum(np.array(p_fmpi[0, :]).squeeze() < _p) /
                              np.array(p_fmpi[0, :]).squeeze().size)
bx1.plot(target_value, np.array(actual_pvalue_merged_fmpi))
bx2.plot(target_value, np.array(actual_pvalue_fmpi))

ax1.set_title('Fmpi-Merged')
ax1.set_xlim(0, 1)
ax2.set_title('Fmpi-Using-all-data')
ax2.set_xlim(0, 1)
bx1.set_title('Fmpi-Merged')
bx2.set_title('Fmpi-Using-all-data')
fig.legend()
fig2.legend()
plt.show()

print('detection rate for combined parameters: {:}. \n Total detection rate: {:}'.format(
    np.sum(p_fmpi < 0.05, axis=1) / p_fmpi.shape[1],
    np.sum(np.sum(p_fmpi < 0.05)) / p_fmpi.shape[1]))

print('detection rate for estimated parameters: {:}. \n Total detection rate: {:}'.format(
    np.sum(p_merged_fmpi < 0.05, axis=1) / p_merged_fmpi.shape[1],
    np.sum(np.sum(p_merged_fmpi < 0.05)) / p_merged_fmpi.shape[1]))

print('estimated RN {:} vs. ideal case RN {:}'.format(total_rn, ave_3.rn))

print('estimated DOF numerator {:} and denominator {:} vs. ideal case numerator {:} and denominator {:}'.format(
    total_dof_num, total_dof_den,
    ave_3.dof_within_epochs, ave_3.dof_rn))
