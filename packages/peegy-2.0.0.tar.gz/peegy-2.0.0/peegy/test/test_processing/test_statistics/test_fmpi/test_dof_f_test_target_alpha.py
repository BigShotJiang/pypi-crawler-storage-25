# -*- coding: utf-8 -*-
"""
Created on Tue Dec 16 10:55:37 2014

@author: jundurraga-ucl
"""
# import itertools

# Enable below for interactive backend
# import matplotlib
import tqdm
from peegy.processing.tools import epochs_processing_tools as ept
from peegy.processing.statistics import eeg_statistic_tools as espt
from peegy.tools.signal_generator import noise_functions as nf
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import butter
from astropy import units as u
from peegy.processing.tools.detection.definitions import TimeROI
# from scipy import integrate
# if 'qt5agg' in matplotlib.backends.backend_registry.list_builtin():
#     matplotlib.use('qt5agg')

"""
This file intends to provide a simple python implementation of harmonic mean p-values.
The original r file is available on cran as: 'harmonicmeanp'.
Wilson, D. J. (2019). The harmonic mean p-value for combining dependent tests. Proceedings of the National Academy of
Sciences, 116(4), 1195-1200.
All implementations (and errors) here are my own, with no affiliation to Wilson.
"""


def stat(p_values, weights=None):
    """
    Uses the harmonic mean to combine p-values. This is the raw harmonic mean p_value calculation,
    but using hmp() should be preferred which transforms to an asymptotically exact test.
    For the original reference, see:
       Wilson, D. J. (2019). The harmonic mean p-value for combining dependent tests. Proceedings of the National
       Academy of Sciences, 116(4), 1195-1200.

    """
    L = p_values.shape[0]

    if weights is None:
        weights = np.ones(p_values.shape) * (1. / L)  # Assume uniform

    assert len(weights) == len(p_values)
    assert np.all(weights >= 0)
    assert np.all(np.isclose(np.sum(weights, axis=0), 1))  # Should sum to 1

    p_values = np.asarray(p_values)
    return 1 / np.sum(weights / p_values, axis=0)

#
# def upper_bound(p_values, weights=None):
#     """
#     A worst case upper bound can be estimated by noting the harmonic mean
#     is never more anti-conservative than a factor of e*ln(L).
#     where L=|p_values|.
#     See: Vovk, V., & Wang, R. (2020). Combining p-values via averaging. Biometrika, 107(4), 791-808.
#     """
#     L = len(p_values)
#     assert L >= 2  # Only defined with multiple values
#     harmonic_mean = stat(p_values, weights)
#
#     # Note: as k->∞, the e term can be dropped. Todo: Implement?
#     return harmonic_mean * np.e * np.log(L)
#
#
# def _landau_density(x, mu, sigma):
#     """
#     Computes the density of the Landau distribution. Note: This could be improved for efficiency,
#     for example, using pylandau. Here I have used a naive implementation to keep dependencies small.
#     """
#     fn = lambda t: np.exp(-t * ((x - mu) / sigma) - (2 / np.pi) * t * np.log(t)) * np.sin(2 * t)
#     integral = 1 / (np.pi * sigma) * integrate.quad(fn, 0, np.inf)[0]
#     return integral
#
#
# def hmp(p_values, weights=None,
#         l: int = None):
#     """
#     Uses the harmonic mean to combine p-values. This is an asymptotically exact transformation of HMP,
#     using the landau distribution.
#     For the original reference, see:
#        Wilson, D. J. (2019). The harmonic mean p-value for combining dependent tests. Proceedings of the National
#        Academy of Sciences, 116(4), 1195-1200.
#     """
#     harmonic_mean = stat(p_values, weights)
#     if l is None:
#         l = p_values.shape[0]
#     mu = np.log(l) + 0.874
#     sigma = np.pi / 2
#     landau = lambda x: _landau_density(x, mu, sigma)
#     hmp_val = np.zeros(harmonic_mean.shape[0])
#     for i, h in enumerate(harmonic_mean):
#         hmp_val[i] = integrate.quad(landau, 1 / h, np.inf)[0]
#     return hmp_val


p = np.array([[0.1, 0.5, 0.9],
              [0.1, 0.5, 0.9]]).T
# hmp(p)
# create  data
fs = 5000.0
n_samples = 64 * 10  # samples per epoch
n_trials = 64     # number of epochs per block to test
repetitions = 1000
f_h = 1 / (n_samples / fs)
b_hp, a_hp = butter(3, f_h, 'high', fs=fs)
b_lp, a_lp = butter(3, 1500, 'low', fs=fs)
block_sizes = [64]
# defines number of sequential tests that will be performed
n_seq_test = np.arange(0, 81).astype(int)
# apply correct alpha for target number of false positives after m sequential tests
# alpha = 1 - (1 - 0.05) ** (1 / n_seq_test.size)
alpha = 0.05

for _block_size in block_sizes:
    p_full_dof = np.empty((n_seq_test.size, repetitions))
    p_full_dof[:] = np.nan
    rn_vector = np.empty((n_seq_test.size, repetitions))
    rn_vector[:] = np.nan
    # p_corrected = np.empty((n_seq_test.size, repetitions))
    # p_corrected[:] = np.nan
    # p_classic_dof = np.empty((n_seq_test.size, repetitions))
    # p_classic_dof[:] = np.nan
    # p_partial_dof = np.empty((n_seq_test.size, repetitions))
    # p_partial_dof[:] = np.nan
    f_full_dof = np.empty((n_seq_test.size, repetitions))
    drops = np.empty((n_seq_test.size, 1))
    n_tests = n_seq_test.size - 1
    alpha = 0.05 / n_tests
    for _seq in tqdm.tqdm(n_seq_test):
        if _seq == 0:
            # set starting pool
            all_reps = np.arange(repetitions)
            reps = all_reps
        if _seq >= 2:
            # keep only non-significant responses from previous pool
            w_p = np.ones((_seq, 1)) / _seq
            # p_corrected[_seq - 1, :] = np.sum(w_p) / np.sum(w_p / p_full_dof[0: _seq, :], axis=0)
            # p_corrected = np.zeros(all_reps.shape)
            # for i_ps in range(p_full_dof.shape[1]):
            #     if np.any(np.isnan(p_full_dof[0: _seq, i_ps])):
            #         continue
            #     # p_corrected[i_ps] = p_full_dof[0: _seq, i_ps][:, None]
            #     p_corrected = p_full_dof[0: _seq, i_ps][:, None]

            cov = (rn_vector[_seq - 1, :] / rn_vector[_seq-2, :]) ** 2
            # alpha = 0.05 / ((1 - n_tests) * (cov - 1) + 1)
            # alpha = 0.05 * (1 - cov) / (n_tests - 1)
            # alpha = 0.05 * cov ** 0.5 * (_seq - 1) / n_tests + 0.05 / n_tests
            to_keep = p_full_dof[_seq - 1, :] >= alpha
            drops[_seq - 2] = reps.size - np.sum(to_keep)
            reps = all_reps[np.argwhere(to_keep)]
            delta_alpha = (1 - cov) * alpha
            alpha = alpha - delta_alpha + 0.05 / n_tests

        for _rep in tqdm.tqdm(reps):
            # The seed is fix for repetitions so that the sequential test has the samples in each block
            np.random.seed(_rep)
            # noise = np.random.normal(1, size=(n_samples * n_trials * (_seq + 1), 1))
            # use code below if you want to use perfect noise with the caveat that your f values will by an almost
            # perfect 1 and your p value 0.5!

            noise = nf.generate_modulated_noise(
                fs=fs,
                f_noise_low=0,
                f_noise_high=fs / 2,
                duration=n_samples * n_trials * (_seq + 1) / fs,
                n_channels=1,
                attenuation=0,
                noise_seed=_rep)

            # uncomment below to play with filter
            # noise = filtfilt(b_hp, a_hp, noise, axis=0)
            # noise = filtfilt(b_lp, a_lp, noise, axis=0)

            data = noise.reshape([n_samples, 1,  n_trials * (_seq + 1)], order='F') * u.dimensionless_unscaled
            ave_ap = ept.et_mean(epochs=data,
                                 block_size=_block_size,
                                 weighted=True,
                                 samples_distance=1,
                                 weight_across_epochs=False,
                                 demean_epochs=True,
                                 rn_window=np.array([0, data.shape[0]]),
                                 fs=fs * u.Hz
                                 )
            roi_windows = np.array(
                [
                    TimeROI(
                        ini_time=0 * u.ms,
                        end_time=np.inf * u.ms,
                        show_window=True,
                        show_label=False,
                    )
                ]
            )
            snr, _, _fvalue, _ = ept.et_snr_in_rois(ave_ap.average,
                                                    roi_windows=roi_windows
                                                    )
            f_critic, p_value = espt.f_test(dof_num=ave_ap.dof_within_epochs,
                                            dof_den=ave_ap.dof_rn,
                                            f_value=_fvalue)
            _iseq = _seq - n_seq_test.min()
            # p_full_dof[_iseq, _rep] = p_value
            p_full_dof[_iseq, _rep] = p_value
            f_full_dof[_iseq, _rep] = _fvalue
            rn_vector[_iseq, _rep] = ave_ap.rn
            # f_critic, p_value = espt.f_test(dof_num=np.ones(ave_ap.dof_within_epochs.shape) * 5,
            #                                 dof_den=data.shape[2] - 1,
            #                                 f_value=_fvalue)
            # p_classic_dof[_iseq, _rep] = p_value
            #
            # f_critic, p_value = espt.f_test(dof_num=ave_ap.dof_within_epochs,
            #                                 dof_den=(data.shape[2] - 1),
            #                                 f_value=_fvalue)
            # p_partial_dof[_iseq, _rep] = p_value

fig = plt.figure()
gs = fig.add_gridspec(ncols=1, nrows=1)

cor = rn_vector[1::, :] ** 2 / rn_vector[0:-1, :] ** 2


for _seq in tqdm.tqdm(n_seq_test):
    # n_bins = np.round(1 / alpha).astype(int)
    n_bins = 100
    if _seq == 0:
        fig = plt.figure()
        gs = fig.add_gridspec(ncols=3, nrows=1)
        ax1 = fig.add_subplot(gs[0, 0])
        ax2 = fig.add_subplot(gs[0, 1])
        ax3 = fig.add_subplot(gs[0, 2])
        fig2 = plt.figure()
        gs2 = fig2.add_gridspec(ncols=3, nrows=1)
        bx1 = fig2.add_subplot(gs[0, 0])
        bx2 = fig2.add_subplot(gs[0, 1])
        bx3 = fig2.add_subplot(gs[0, 2])
    y_intercept = 1 / n_bins

    histogram_fill_dof, bin_edges = np.histogram(1 - p_full_dof[_seq, :][~np.isnan(p_full_dof[_seq, :])],
                                                 density=False, bins=n_bins)
    ax1.plot(bin_edges[:-1], histogram_fill_dof / np.sum(histogram_fill_dof), label=str(_seq))
    ax1.axhline(y_intercept)
    ax1.set_ylim(0, 2 * y_intercept)

    # histogram_classic_dof, bin_edges = np.histogram(1 - p_classic_dof[_seq, :][~np.isnan(p_classic_dof[_seq, :])],
    #                                                 density=False, bins=n_bins)
    # ax2.plot(bin_edges[:-1], histogram_classic_dof / np.sum(histogram_classic_dof))
    # ax2.axhline(y_intercept)
    # ax2.set_ylim(0, 2 * y_intercept)
    #
    # histogram_partial_dof, bin_edges = np.histogram(1 - p_partial_dof[_seq, :][~np.isnan(p_partial_dof[_seq, :])],
    #                                                 density=False, bins=n_bins)
    # ax3.plot(bin_edges[:-1], histogram_partial_dof / np.sum(histogram_partial_dof))
    # ax3.axhline(y_intercept)
    # ax3.set_ylim(0, 2 * y_intercept)

    target_value = np.linspace(0, 1, 1001)
    actual_pvalue_fmpi = []
    actual_pvalue_classic = []
    actual_pvalue_partial_dof = []
    for _p in target_value:
        actual_pvalue_fmpi.append(np.sum(np.array(p_full_dof[_seq, :]).squeeze() < _p) /
                                  np.sum(~np.isnan(np.array(p_full_dof[_seq, :]).squeeze())))
        # actual_pvalue_classic.append(np.sum(np.array(p_classic_dof[_seq, :]).squeeze() < _p) /
        #                              np.sum(~np.isnan(np.array(p_classic_dof[_seq, :]).squeeze())))
        #
        # actual_pvalue_partial_dof.append(np.sum(np.array(p_partial_dof[_seq, :]).squeeze() < _p) /
        #                                  np.sum(~np.isnan(np.array(p_partial_dof[_seq, :]).squeeze())))

    bx1.plot(target_value, np.array(actual_pvalue_fmpi), label=str(_seq))
    bx1.axline((0, 0), slope=1, color='k')
    bx2.plot(target_value, np.array(actual_pvalue_classic), label=str(_seq))
    bx2.axline((0, 0), slope=1, color='k')
    bx3.plot(target_value, np.array(actual_pvalue_partial_dof), label=str(_seq))
    bx3.axline((0, 0), slope=1, color='k')
    ax1.set_title('Fmpi')
    ax1.set_xlim(0, 1)
    ax2.set_title('Classic')
    ax2.set_xlim(0, 1)
    ax3.set_title('Alternative')
    ax3.set_xlim(0, 1)
    fig.legend()
    fig2.legend()
plt.show()

print('detection rate for sequential tests: {:}. \n Total detection rate: {:}'.format(
    np.nansum(p_full_dof < alpha, axis=1) / p_full_dof.shape[1],
    np.nansum(p_full_dof < alpha) / p_full_dof.size))

_idx_subset = np.arange(0, repetitions)
_p_subset = p_full_dof[:, _idx_subset]
_idx_target = np.any(np.array([_p_subset[:, _i] < 0.05 for _i in np.arange(_p_subset.shape[1])]), axis=1)
_p_subset_target = _p_subset[:, _idx_target]
fig2 = plt.figure()
gs = fig2.add_gridspec(ncols=2, nrows=1)
ax = fig2.add_subplot(gs[0, 0])
ax.plot(_p_subset, color='grey')
ax.plot(_p_subset_target)
ax.axhline(y=0.05, color='k')

f_full_subset = f_full_dof[:, _idx_subset]
_f_subset_target = f_full_subset[:, _idx_target]
gs = fig2.add_gridspec(ncols=2, nrows=1)
ax = fig2.add_subplot(gs[0, 1])
ax.plot(f_full_subset, color='grey')
ax.plot(_f_subset_target)
ax.axhline(y=1, color='k')
