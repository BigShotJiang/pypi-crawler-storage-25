# -*- coding: utf-8 -*-
"""
Created on Tue Dec 16 10:55:37 2014

@author: jundurraga-ucl
"""
import itertools

# Enable below for interactive backend
import matplotlib
import pandas as pd
import tqdm
if 'qt5agg' in matplotlib.backends.backend_registry.list_builtin():
    matplotlib.use('qt5agg')

from peegy.processing.tools.detection.definitions import TimeROI
from peegy.processing.tools import epochs_processing_tools as ept
from peegy.processing.statistics import eeg_statistic_tools as espt
from peegy.tools.signal_generator import noise_functions as nf
from peegy.definitions.channel_definitions import Domain
import numpy as np
import matplotlib.pyplot as plt
from astropy import units as u
# from scipy.signal import butter


def simulator(n_seq_test: list = None,
              repetitions: list = None,
              test_frequencies: np.array(u.Quantity) = None,
              noise_attenuation: float = 0,
              delta_frequency_noise: u.Quantity = 5 * u.Hz,
              offset_frequency_noise: u.Quantity = 0 * u.Hz,
              block_size: int = 1,
              weighted: bool = True
              ):
    p_full_dof = np.zeros((n_seq_test.size, repetitions))
    p_classic_dof = np.zeros((n_seq_test.size, repetitions))
    p_partial_dof = np.zeros((n_seq_test.size, repetitions))
    f_full_dof = np.zeros((n_seq_test.size, repetitions))
    items = list(itertools.product(n_seq_test, np.arange(repetitions)))
    roi_windows = np.array(
        [
            TimeROI(
                ini_time=0 * u.ms,
                end_time=np.inf * u.ms,
                show_window=True,
                show_label=False,
            )
        ]
    )
    for _seq, _rep in tqdm.tqdm(items):
        # The seed is fix for repetitions so that the sequential test has the samples in each block
        np.random.seed(_rep)
        # noise = np.random.normal(1, size=(n_samples * n_trials * (_seq + 1), 1))
        # uncomment below to play with filter
        # use code below if you want to use perfect noise with the caveat that your f values will by an almost perfect 1
        # and your p value 0.5!
        noise = nf.generate_modulated_noise(
            fs=fs,
            f_noise_low=0,
            f_noise_high=fs / 2,
            duration=n_samples * n_trials * (_seq + 1) / fs,
            n_channels=n_ch,
            attenuation=noise_attenuation,
            noise_seed=_rep)

        data_unfiltered = noise.reshape([n_samples, n_ch, n_trials * (_seq + 1)], order='F') * u.dimensionless_unscaled
        # get Fmpi via frequency domain using raw data (spectral filter)
        ave_ap = ept.et_mean(epochs=data_unfiltered,
                             block_size=block_size,
                             weighted=weighted,
                             samples_distance=1,
                             weight_across_epochs=False,
                             demean_epochs=True,
                             test_frequencies=test_frequencies,
                             fs=fs * u.Hz,
                             rn_domain=Domain.frequency,
                             delta_frequency_noise=delta_frequency_noise,
                             offset_frequency_noise=offset_frequency_noise
                             )
        snr, _, _fvalue, _ = ept.et_snr_in_rois(ave_ap.average,
                                                roi_windows=roi_windows,
                                                test_frequencies=test_frequencies,
                                                )
        f_critic, p_value = espt.f_test(dof_num=ave_ap.dof_within_epochs * n_window / ave_ap.average.data.shape[0],
                                        dof_den=ave_ap.dof_rn,
                                        f_value=_fvalue)
        _iseq = _seq - n_seq_test.min()
        p_full_dof[_iseq, _rep] = p_value
        f_full_dof[_iseq, _rep] = _fvalue

        f_critic, p_value = espt.f_test(dof_num=np.ones(ave_ap.dof_within_epochs.shape) * 5,
                                        dof_den=data_unfiltered.shape[2] - 1,
                                        f_value=_fvalue)
        p_classic_dof[_iseq, _rep] = p_value

        f_critic, p_value = espt.f_test(dof_num=ave_ap.dof_within_epochs * n_window / ave_ap.average.data.shape[0],
                                        dof_den=(data_unfiltered.shape[2] - 1),
                                        f_value=_fvalue)
        p_partial_dof[_iseq, _rep] = p_value
    return p_full_dof, p_classic_dof, p_partial_dof


# create  data
fs = 2024.0
n_samples = 5000  # samples per epoch
n_trials = 40  # number of epochs per block to test
repetitions = 1000
noise_attenuation = 0
alpha_target = 0.05
f_h = 1 / (n_samples / fs)
block_sizes = [1]
weighted = [False, True]
n_ch = 1
# defines number of samples in analysis windows (which is smaller than epoch length)
n_window = n_samples
frequencies = [np.linspace(1, nf, nf) * 40 * u.Hz for nf in np.linspace(1, 12, 12, dtype=int)]
figures_path = r'/home/jundurraga/Documents/source_code/iru/DOFs/simulations/figures/assr_noise_frequency_bins_number/'
data_path = r'/home/jundurraga/Documents/source_code/iru/DOFs/simulations/figures/assr_noise_frequency_bins_number/'
delta_freq = 1 / (n_samples / fs) * u.Hz
deltas = np.arange(22, step=2) * delta_freq
items_to_run = list(itertools.product(block_sizes, deltas, frequencies, weighted))
data = pd.DataFrame()
for _item in items_to_run:
    _block_size, _delta, _freqs, _weighted = _item
    p_full_dof, p_classic_dof, p_partial_dof = simulator(n_seq_test=np.array([0]),
                                                         repetitions=repetitions,
                                                         block_size=_block_size,
                                                         noise_attenuation=noise_attenuation,
                                                         delta_frequency_noise=_delta,
                                                         test_frequencies=_freqs,
                                                         weighted=_weighted)
    n_bins = 100
    y_intercept = 1 / n_bins
    _label = 'nf_{:}-{:.1f}'.format(_freqs.size, _delta)
    histogram_fill_dof, bin_edges = np.histogram(p_full_dof[0, :], density=False, bins=n_bins)
    fig = plt.figure()
    gs = fig.add_gridspec(ncols=3, nrows=2)
    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[0, 1])
    ax3 = fig.add_subplot(gs[0, 2])
    bx1 = fig.add_subplot(gs[1, 0])
    bx2 = fig.add_subplot(gs[1, 1])
    bx3 = fig.add_subplot(gs[1, 2])
    ax1.plot(bin_edges[:-1], histogram_fill_dof / np.sum(histogram_fill_dof),
             label=_label)
    ax1.axhline(y_intercept)
    ax1.set_ylim(0, 2 * y_intercept)

    histogram_classic_dof, bin_edges = np.histogram(p_classic_dof[0, :], density=False, bins=n_bins)
    ax2.plot(bin_edges[:-1], histogram_classic_dof / np.sum(histogram_classic_dof))
    ax2.axhline(y_intercept)
    ax2.set_ylim(0, 2 * y_intercept)

    histogram_partial_dof, bin_edges = np.histogram(p_partial_dof[0, :], density=False, bins=n_bins)
    ax3.plot(bin_edges[:-1], histogram_partial_dof / np.sum(histogram_partial_dof))
    ax3.axhline(y_intercept)
    ax3.set_ylim(0, 2 * y_intercept)

    target_value = np.linspace(0, 1, 1001)
    actual_pvalue_fmpi = []
    actual_pvalue_classic = []
    actual_pvalue_partial_dof = []
    for _p in target_value:
        actual_pvalue_fmpi.append(np.sum(np.array(p_full_dof[0, :]).squeeze() < _p) /
                                  np.array(p_full_dof[0, :]).squeeze().size)
        actual_pvalue_classic.append(np.sum(np.array(p_classic_dof[0, :]).squeeze() < _p) /
                                     np.array(p_classic_dof[0, :]).squeeze().size)
        actual_pvalue_partial_dof.append(np.sum(np.array(p_partial_dof[0, :]).squeeze() < _p) /
                                         np.array(p_partial_dof[0, :]).squeeze().size)

    bx1.plot(target_value, np.array(actual_pvalue_fmpi))
    bx2.plot(target_value, np.array(actual_pvalue_classic))
    bx3.plot(target_value, np.array(actual_pvalue_partial_dof))
    ax1.set_title('Fmpi')
    ax1.set_xlim(0, 1)
    ax2.set_title('Classic')
    ax2.set_xlim(0, 1)
    ax3.set_title('Alternative')
    ax3.set_xlim(0, 1)
    fig.supxlabel('p-value')
    fig.legend()
    inch = 2.54
    fig_name = r'frequency_analysis_bs_{:}_nf_{:}-{:.1f}_wa_{:}'.format(_block_size,
                                                                        _freqs.size,
                                                                        _delta,
                                                                        _weighted)
    fig.set_size_inches(20 / inch, 16 / inch)
    fig.tight_layout()
    fig.savefig(fname=figures_path + fig_name + '.png', dpi=600)
    # fig.savefig(fname=figures_path + fig_name + '.pdf', dpi=600)
    plt.close(fig)

    print('detection rate for sequential tests: {:}. \n Total detection rate: {:}'.format(
        np.sum(p_full_dof < alpha_target, axis=1) / p_full_dof.shape[1],
        np.sum(np.sum(p_full_dof < alpha_target)) / p_full_dof.shape[1]))
    _data = {'block_size': _block_size,
             'frequency_tested': _freqs[0],
             'n_harmonics': _freqs.size,
             'n_epochs': n_trials,
             'n_samples_per_epochs': n_samples,
             'n_repetitions': repetitions,
             'fs': fs,
             'weighted': _weighted,
             'noise_attenuation': noise_attenuation,
             'delta_frequency': _delta,
             'alpha_target': alpha_target,
             'fdr_fmpi': np.sum(p_full_dof < 0.05, axis=1) / p_full_dof.shape[1],
             'fdr_fmp': np.sum(p_classic_dof < 0.05, axis=1) / p_classic_dof.shape[1],
             'fdr_fmpi_alternative': np.sum(p_classic_dof < 0.05, axis=1) / p_classic_dof.shape[1]
             }
    data = pd.concat([data, pd.DataFrame(_data)])
    json_data = data.to_json(
        data_path + 'data.json',
        orient='records',
        lines=True)
