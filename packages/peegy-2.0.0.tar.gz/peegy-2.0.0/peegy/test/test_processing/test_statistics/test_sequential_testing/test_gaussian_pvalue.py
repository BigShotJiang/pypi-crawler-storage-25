# -*- coding: utf-8 -*-
"""
Created on Tue Dec 16 10:55:37 2014

@author: jundurraga-ucl
"""
# Enable below for interactive backend
import matplotlib
import tqdm
if 'qt5agg' in matplotlib.backends.backend_registry.list_builtin():
    matplotlib.use('qt5agg')

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
# create  data
fs = 5000.0
repetitions = 100000
# defines number of sequential tests that will be performed
n_seq_test = np.arange(0, 10).astype(int)
# apply correct alpha for target number of false positives after m sequential tests
alpha = 1 - (1 - 0.05) ** (1 / n_seq_test.size)
p_full_dof = np.empty((n_seq_test.size, repetitions))
p_full_dof[:] = np.nan
f_full_dof = np.empty((n_seq_test.size, repetitions))
for _seq in tqdm.tqdm(n_seq_test):
    if _seq == 0:
        # set starting pool
        all_reps = np.arange(repetitions)
        reps = all_reps
    else:
        # keep only non-significant responses from previous pool
        reps = all_reps[np.argwhere(p_full_dof[_seq - 1] >= alpha)]
    for _rep in tqdm.tqdm(reps):
        # The seed is fix for repetitions so that the sequential test has the samples in each block
        np.random.seed(_rep)
        noise = np.random.normal(loc=0, scale=1,  size=((_seq + 1), 1))
        p_value = 1 - norm(loc=0, scale=1).cdf(noise[_seq])
        _iseq = _seq - n_seq_test.min()
        p_full_dof[_iseq, _rep] = p_value


for _seq in tqdm.tqdm(n_seq_test):
    n_bins = np.round(1 / alpha).astype(int)
    if _seq == 0:
        fig = plt.figure()
        gs = fig.add_gridspec(ncols=1, nrows=1)
        ax1 = fig.add_subplot(gs[0, 0])
        fig2 = plt.figure()
        gs2 = fig2.add_gridspec(ncols=3, nrows=1)
        bx1 = fig2.add_subplot(gs[0, 0])
    y_intercept = 1 / n_bins

    histogram_fill_dof, bin_edges = np.histogram(1 - p_full_dof[_seq, :][~np.isnan(p_full_dof[_seq, :])],
                                                 density=False, bins=n_bins)
    ax1.plot(bin_edges[:-1], histogram_fill_dof / np.sum(histogram_fill_dof), label=str(_seq))
    ax1.axhline(y_intercept)
    ax1.set_ylim(0, 2 * y_intercept)

    target_value = np.linspace(0, 1, 1001)
    actual_pvalue_fmpi = []
    for _p in target_value:
        actual_pvalue_fmpi.append(np.sum(np.array(p_full_dof[_seq, :]).squeeze() < _p) /
                                  np.sum(~np.isnan(np.array(p_full_dof[_seq, :]).squeeze())))

    bx1.plot(target_value, np.array(actual_pvalue_fmpi), label=str(_seq))
    bx1.axline((0, 0), slope=1, color='k')
    ax1.set_title('Gaussian noise')
    ax1.set_xlim(0, 1)
    fig.legend()
    fig2.legend()
plt.show()

print('detection rate for sequential tests: {:}. \n Total detection rate: {:}'.format(
    np.sum(p_full_dof < alpha, axis=1) / np.nansum(p_full_dof, axis=1),
    np.sum(p_full_dof < alpha) / p_full_dof.shape[1]))
