# -*- coding: utf-8 -*-
"""
Created on Tue Dec 16 10:55:37 2014

@author: jundurraga-ucl
"""
from peegy.processing.tools import epochs_processing_tools as ept
from peegy.processing.statistics import eeg_statistic_tools as espt
import numpy as np
import matplotlib.pyplot as plt
import astropy.units as u

# create synthetic data
fs = 1000.0
nsamples = np.round(1 * fs).astype(int)
nchans = 12
ntrials = 100
noise_dim = 12  # dimensionality of noise
f1 = 40

freq_ini = 1 / (nsamples/fs)
freq_end = fs / 2
source = np.expand_dims(np.sin(2 * np.pi * f1 * np.arange(nsamples) / fs), axis=1)
coeff = np.ones(nchans//2) * 0.5 / (nchans / 2)
coeff = np.expand_dims(np.hstack((coeff, coeff)), 0)

s = source * coeff
s_std = np.std(s, axis=0)
s = np.tile(np.expand_dims(s, axis=2), (1, 1, ntrials))

desired_snr = 40.0
ini_std = 10.0 ** (-desired_snr / 20.0) * s_std * ntrials ** 0.5
theoretical_rn = ini_std / ntrials ** 0.5
np.random.seed(0)
noise = np.random.normal(0, ini_std[0], size=(nsamples, nchans, ntrials))
# s[:, 0] = s[:, 0] * 0.5
data = noise + s

# get samples
block_size = int(0.040*fs)
samples = np.array([np.mean(data[_samp*block_size:(_samp + 1) * block_size, :, :], 0) for _samp in range(9)])
out = []
for _ch in range(nchans):
    out.append(espt.hotelling_t_square_test(samples[:, [_ch], :]))
print(np.array([_x.p_value for _x in out]).T < 0.05)

roi_windows = np.array([100, 500])

w_ave = ept.et_mean(epochs=data,
                    block_size=1,
                    samples_distance=1,
                    fs=fs * u.Hz,
                    rn_window=roi_windows,
                    weighted=True,
                    demeaned_noise=False,
                    weight_across_epochs=False
                    )


print(["Theoretic RN", theoretical_rn, "Estimated rn (time)", w_ave.rn])
print(["Theoretic SRN", desired_snr, "Estimated srn (time)", 10 * np.log10(w_ave.snr)])

fig = plt.figure()
ax = fig.add_subplot(131)
ax.plot(np.mean(s, axis=2))
ax = fig.add_subplot(132)
ax.plot(w_ave.average.data)
ax = fig.add_subplot(133)
plt.plot(np.array(w_ave.cumulative_rn))
plt.show()
plt.show()
