from peegy.definitions.channel_definitions import Domain


class TestType(object):
    hotelling_t2 = 'hotelling_t2'  # hotelling-t2 test in time- or frequency-domain
    f_test = 'f_test'  # f-ratio in time- or frequency-domain
    rayleigh_test = 'rayleigh_test'  # phase-locking value
    covariance = 'covariance'  # covariance
    bootstrap = 'bootstrap'
    q_samples_test = 'q_samples_test'  # covariance

    def get_available_methods(self):
        members = [attr for attr in dir(self) if not callable(getattr(self, attr)) and not attr.startswith("__")]
        return members


class HotellingTSquareTestOutput(object):
    def __init__(self,
                 test_name='HT2',
                 df_1=None,
                 df_2=None,
                 t_square=None,
                 f=None,
                 f_critic=None,
                 p_value=None,
                 amplitude=None,
                 phase=None,
                 rn=None,
                 n_epochs=None,
                 snr=None,
                 snr_db=None,
                 snr_critic_db=None,
                 snr_critic=None,
                 channel=None,
                 domain: Domain | None = None,
                 tested_frequencies=None,
                 ini_time: float | None = None,
                 end_time: float | None = None,
                 window_label: str | None = None,
                 ):
        self.test_name = test_name
        self.df_1 = df_1
        self.df_2 = df_2
        self.t_square = t_square
        self.f = f
        self.f_critic = f_critic
        self.p_value = p_value
        self.amplitude = amplitude
        self.phase = phase
        self.rn = rn
        self.n_epochs = n_epochs
        self.snr = snr
        self.snr_db = snr_db
        self.snr_critic_db = snr_critic_db
        self.snr_critic = snr_critic
        self.channel = channel
        self.tested_frequencies = tested_frequencies
        self.ini_time = ini_time
        self.end_time = end_time
        self.window_label = window_label
        self.domain = domain


class FTestOutput(object):
    def __init__(self,
                 test_name='F-test',
                 tested_frequencies=None,
                 df_1=None,
                 df_2=None,
                 f=None,
                 p_value=None,
                 amplitude=None,
                 rms=None,
                 phase=None,
                 rn=None,
                 bn=None,
                 snr=None,
                 snr_db=None,
                 f_critic=None,
                 ini_time: float | None = None,
                 end_time: float | None = None,
                 n_epochs: int | None = None,
                 effective_n_epochs: float | None = None,
                 domain: Domain | None = None,
                 channel=None,
                 window_label: str | None = None
                 ):
        self.test_name = test_name
        self.tested_frequencies = tested_frequencies
        self.df_1 = df_1
        self.df_2 = df_2
        self.f = f
        self.p_value = p_value
        self.amplitude = amplitude
        self.rms = rms
        self.phase = phase
        self.rn = rn
        self.bn = bn
        self.snr = snr
        self.snr_db = snr_db
        self.f_critic = f_critic
        self.channel = channel
        self.ini_time = ini_time
        self.end_time = end_time
        self.n_epochs = n_epochs
        self.effective_n_epochs = effective_n_epochs
        self.domain = domain
        self.window_label = window_label


class PhaseLockingValueTest(object):
    def __init__(self,
                 test_name='rayleigh_test',
                 plv=None,
                 df_1=None,
                 z_value=None,
                 z_critic=None,
                 p_value=None,
                 phase=None,
                 channel=None,
                 tested_frequencies=None,
                 rn=None,
                 window_label: str | None = None,
                 domain: Domain | None = None,
                 ini_time: float | None = None,
                 end_time: float | None = None
                 ):
        self.test_name = test_name
        self.plv = plv
        self.df_1 = df_1
        self.z_value = z_value
        self.z_critic = z_critic
        self.p_value = p_value
        self.phase = phase
        self.channel = channel
        self.tested_frequencies = tested_frequencies
        self.rn = rn
        self.ini_time = ini_time
        self.end_time = end_time
        self.window_label = window_label
        self.domain = domain


class QSamplesTestResults(object):
    def __init__(self,
                 test_name='q_samples_test',
                 window_label: str | None = None,
                 q: float | None = None,
                 mean: float | None = None,
                 median: float | None = None,
                 ci_lower: float | None = None,
                 ci_upper: float | None = None,
                 p_value: float | None = None,
                 ini_time: float | None = None,
                 end_time: float | None = None,
                 n_epochs: int | None = None,
                 channel: str | None = None,
                 n_bootstrapping: int | None = None,
                 alpha_level: float | None = None,
                 tested_frequencies: str | None = None,
                 domain: Domain | None = None):
        self.test_name = test_name
        self.window_label = window_label
        self.q = q
        self.mean = mean
        self.median = median
        self.ci_lower = ci_lower
        self.ci_upper = ci_upper
        self.alpha_level = alpha_level
        self.p_value = p_value
        self.ini_time = ini_time
        self.end_time = end_time
        self.n_epochs = n_epochs
        self.channel = channel
        self.n_bootstrapping = n_bootstrapping
        self.tested_frequencies = tested_frequencies
        self.domain = domain
