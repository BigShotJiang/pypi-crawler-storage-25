import numpy as np
from peegy.processing.statistics.definitions import HotellingTSquareTestOutput
from peegy.processing.tools.eeg_epoch_operators import w_mean, et_weighted_covariance
from peegy.processing.tools.epochs_frequency_processing_tools import goertzel
from peegy.processing.tools import eeg_epoch_operators as eo
from peegy.tools.units.unit_tools import set_default_unit
import astropy.units as u
import scipy.stats as st
import numba


def hotelling_t_square_test(samples=np.array([]),
                            dof_within_epochs: type(np.array) | None = None,
                            dof_across_epochs: type(np.array) | None = None,
                            weights: type(np.array) | None = None,
                            ini_time: u.Quantity | None = None,
                            end_time: u.Quantity | None = None,
                            window_label: str | None = None,
                            diagonal_covariance: bool = False):
    """
    Compute Hotelling T2 test on samples
    :param samples: np.array with samples to perform the test (time x 1 x trials)
    :param dof_within_epochs: number of degrees of freedom for the samples estimated for the samples for each channel.
    If samples are independent this would be equal to the number of point being sampled. Otherwise, a better
    estimation can be passed here.
    :param dof_across_epochs: number of degrees of freedom across epochs estimated for each channel.
    If samples are independent this would be equal to the number of epochs. Otherwise, a better
    estimation can be passed here.
    :param weights: if passed, statistics will be computed using weighted statistics
    :param diagonal_covariance: if True, the covariance matrix will be assumed to be zero outside the diagonal.
    Chesnaye et al. 10.1177/23312165231154035
    :return: pandas data frame with statistical tests
    """
    samples = set_default_unit(samples, u.uV)
    _weights = weights
    if not samples.size:
        return None
    if weights is None:
        _weights = np.ones(samples.shape) * u.dimensionless_unscaled
    if _weights.ndim == 3:
        # we assume that the same weight is use for each row
        _weights = _weights[0, :, :]

    mean_data = w_mean(samples, weights=_weights)
    if dof_across_epochs is None:
        dof_across_epochs = float(effective_sampling_size(_weights, axis=1))

    with np.errstate(divide='ignore', invalid='ignore'):
        data_demeaned = samples - mean_data[..., None]
        # _cov_mat = np.cov(data_ch.value.squeeze(), aweights=_weights.value.squeeze()) * data_ch.unit ** 2.0
        _cov_mat, tw0 = et_weighted_covariance(data_demeaned.T[:, 0, :], w=_weights.T)
        _cov_mat = _cov_mat / tw0
        if diagonal_covariance or (_cov_mat.size == 1):
            _t_square = float(dof_across_epochs * mean_data.T.dot(np.diag(1 / np.diag(_cov_mat))).dot(mean_data))
        else:
            _t_square = float(dof_across_epochs * mean_data.T.dot(np.linalg.pinv(_cov_mat, hermitian=True)).dot(
                mean_data))

        if dof_within_epochs is None:
            n_p = data_demeaned.shape[0]
        else:
            n_p = dof_within_epochs
        n_n = dof_across_epochs
        _f = (n_n - n_p) / (n_p * (n_n - 1.0)) * _t_square
        _d1 = n_p
        _d2 = np.maximum(n_n - n_p, 0)
        if _d2 > 0:
            p = 1 - st.f.cdf(_f, _d1, _d2)
            _f_95 = st.f.ppf(0.95, _d1, _d2)
        else:
            p = 1
            _f_95 = np.inf
        # compute residual noise from circular variance
        _rms = np.sqrt(np.mean(mean_data ** 2.0))
        _rn = np.sqrt(np.sum(data_demeaned ** 2.0)) / (data_demeaned.shape[2] - 1)
        _snr = np.maximum(_f - 1, 0.0 * u.dimensionless_unscaled)

        test = HotellingTSquareTestOutput(t_square=_t_square,
                                          df_1=_d1,
                                          df_2=_d2,
                                          amplitude=_rms,
                                          phase=0 * u.rad,
                                          n_epochs=samples.shape[2],
                                          f=_f,
                                          p_value=p,
                                          rn=_rn,
                                          snr=_snr,
                                          snr_db=10 * np.log10(_snr) if _snr > 0.0 else
                                          -np.inf * u.dimensionless_unscaled,
                                          snr_critic_db=10 * np.log10(_f_95 - 1),
                                          snr_critic=_f_95 - 1,
                                          f_critic=_f_95,
                                          ini_time=ini_time,
                                          end_time=end_time,
                                          window_label=window_label
                                          )
    return test


def f_test(dof_num: type(np.array) | None = None,
           dof_den: type(np.array) | None = None,
           f_value: np.array([]) = None,
           alpha: float = 0.05
           ) -> (float, float, float):
    """
    Compute F-Test for input samples.
    The degrees of freedom for signal are estimated from the frequency-domain.
    The assumption is similar to that used by effective_sampling_size with weighted average.
    A full white spectrum will have all degrees of freedoms which in the time-domain will correspond to the number of
    time points.
    When data are correlated (e.g., when data is filtered or because of un underlying signal), degrees of freedom will
    be reduced. This will be reflected by the relative energy in the spectrum. Thus, the estimation produces estimated
    degrees of freedom between zeros and the number of time x samples by weighting the spectral energy.
    Donelan, Mark, and Willard J. Pierson. 1983. “The Sampling Variability of Estimates of Spectra of Wind-Generated
    Gravity Waves.” Journal of Geophysical Research: Oceans 88 (C7): 4381–92. https://doi.org/10.1029/JC088iC07p04381.
    Medina, Josep R., José Aguilar, and J. Javier Diez. 1985. “Distortions Associated with Random Sea Simulators.”
    Journal of Waterway, Port, Coastal, and Ocean Engineering 111 (4): 603–28.
    https://doi.org/10.1061/(ASCE)0733-950X(1985)111:4(603).
    :param dof_num: degrees of freedom of the numerator
    :param dof_den: degrees of freedom of the denominator
    :param f_value: ratio var(signal + noise) / var(noise) for each channel
    :param alpha: the statistical level for significance
    :return: critical value and p-value
    """
    f_critic = st.f.ppf(1 - alpha, dof_num, dof_den)
    p_value = 1 - st.f.cdf(f_value, dof_num, dof_den)

    return f_critic, p_value


def dof_from_psd(psd_noise=np.array([]),
                 dof_factor: float = 1,
                 psd_noise_n: int | None = None,
                 freq_indexes: np.array(int) = None
                 ) -> float:
    """
    Computes the degrees of freedom from the power spectral density.
    A full white spectrum will have all degrees of freedoms which in the time-domain will correspond to the number of
    time points.
    When data are correlated (e.g., when data is filtered or because of un underlying signal), degrees of freedom will
    be reduced. This will be reflected by the relative energy in the spectrum. Thus, the estimation produces estimated
    degrees of freedom between zeros and the number of time x samples by weighting the spectral energy.
    Donelan, Mark, and Willard J. Pierson. 1983. “The Sampling Variability of Estimates of Spectra of Wind-Generated
    Gravity Waves.” Journal of Geophysical Research: Oceans 88 (C7): 4381–92. https://doi.org/10.1029/JC088iC07p04381.
    Medina, Josep R., José Aguilar, and J. Javier Diez. 1985. “Distortions Associated with Random Sea Simulators.”
    Journal of Waterway, Port, Coastal, and Ocean Engineering 111 (4): 603–28.
    https://doi.org/10.1061/(ASCE)0733-950X(1985)111:4(603).
    :param psd_noise: estimated power spectral density (freq x channels)
    :param dof_factor: ratio between samples used to compute SNR and samples to estimate the psd of the noise
    :param psd_noise_n: integer indicating the number of samples used to estimate the rfft
    :param freq_indexes: numpy array with frequency indexes to compute DOF
    :return: degrees of freedom
    """
    # correct initial and end frequency bins when using real fft function
    if freq_indexes is None:
        freq_indexes = np.arange(0, psd_noise.shape[0])
    freq_indexes = np.minimum(np.maximum(0, freq_indexes), psd_noise.shape[0])
    psd = psd_noise.copy()
    psd[0, :] = psd_noise[0, :] / 2
    if np.mod(psd_noise_n, 2) == 0:
        psd[-1, :] = psd[-1, :] / 2
    dof = 2 * effective_sampling_size(psd[freq_indexes, ...], axis=0) / dof_factor
    return dof


@numba.jit(nogil=True, nopython=True)
def effective_sampling_size(weights: np.array,
                            axis=2):
    """
    compute the effective sample size resulting from the use of weights based on Welch-Satterthwaite approach.
    Satterthwaite, FE. An Approximate Distribution of Estimates of Variance Components.
    Biometrics Bulletin (1946).
    See
    - Satterthwaite, FE. Synthesis of Variance. Psychometrika (1941).
    - Welch, BL. On Linear Combinations of Several Variances. Journal of the American Statistical
    Association (1956).
    - Welch, BL. The Generalization of ‘Student’s’ Problem When Several Different Population
    Variances Are Involved. Biometrika (1947).
    - Kish, Leslie(1965). "Survey Sampling".New York: John  Wiley & Sons, Inc.ISBN 0 - 471 - 10949 - 5.
    "Design Effects and Effective Sample Size".
    https://docs.displayr.com/wiki/Design_Effects_and_Effective_Sample_Size

    :param weights: array of weights
    :param axis: direction indicating how weights are summed
    :return: corrected sampling size
    """
    # weights = set_default_unit(weights, u.dimensionless_unscaled)
    ess = np.sum(weights, axis=axis) ** 2.0 / (np.sum(weights ** 2.0, axis=axis))
    return ess


def phase_locking_value(
        data: type(np.array) | None = None,
        alpha: float = 0.05,
        weights: type(np.array) | None = None) -> np.array:
    """
    Compute phase-locking value (PLV) using Rayleigh test
    :param data: time x channels x trials numpy array in the time domain
    :param alpha: float indicating the alpha value for significance
    :param weights: trial by trial weights
    :return: phase-locking value (frequency x channels), z-scores (frequency x channels), z_critic (float), p_values
    (frequency x channels), mean angles (frequency x channels in rads), degrees of freedom, residual_noise estimation
    """
    if weights is None:
        weights = np.ones(data.shape)
    _dof = effective_sampling_size(weights)
    # for the moment we assume that the same weight across time is applied so that it can be factor out from fft
    dof = np.min(_dof, axis=0, keepdims=False).squeeze()[None, :]
    _weights = np.min(weights, axis=0)[None, :, :]
    yfft = np.fft.rfft(data, axis=0)
    spectral_mean = w_mean(yfft, _weights)
    diff = yfft - spectral_mean[:, :, None]
    # compute weighted standard deviation
    noise = np.sqrt(w_mean(np.abs(diff) ** 2, _weights) / dof)
    # scale to match time domain amplitudes
    spectral_amp = 2 * np.abs(spectral_mean) / data.shape[0]
    residual_noise = 2 * np.abs(noise) / data.shape[0]
    # normalize
    norm = np.sqrt(np.abs(yfft * np.conj(yfft)))
    yfft = np.divide(yfft, norm, out=np.zeros_like(yfft), where=norm != 0)
    angles = np.angle(w_mean(yfft, _weights))
    plv = np.abs(w_mean(yfft, _weights))
    z = dof * plv ** 2

    # D.Wilkie. Rayleigh Test for Randomness of Circular Data".Applied Statistics.1983.
    tmp = np.ones(z.shape)
    _idx_tmp = (dof < 50).squeeze()

    if np.any(_idx_tmp):
        _tmp_correction = 1.0 + (2.0 * z - z * z) / (4.0 * dof) - (
                24.0 * z - 132.0 * z ** 2.0 + 76.0 * z ** 3.0 - 9.0 * z ** 4.0) / (288.0 * dof * dof)
        tmp[:, _idx_tmp] = _tmp_correction
    z_crit = -np.log(alpha) - (2 * np.log(alpha) + np.log(alpha) ** 2.0) / (4 * dof)
    p_values = np.exp(-z) * tmp

    return spectral_amp, plv, z, z_crit, p_values, angles, dof, residual_noise


def discrete_phase_locking_value(
        data: type(np.array) | None = None,
        alpha: float = 0.05,
        fs: float | None = None,
        frequency: float | None = None,
        weights: type(np.array) | None = None) -> np.array:
    """
    Compute spectral amplitude, phase, and  phase-locking value (PLV) using Rayleigh test for a single frequency
    component.
    :param data: time x channels x trials numpy array in the time domain
    :param alpha: float indicating the alpha value for significance
    :param fs: float indicating the sampling rate in Hz
    :param frequency: float indicating the frequency of interest
    :param weights: trial by trial weights
    :return: phase-locking value (frequency x channels), z-scores (frequency x channels), z_critic (float), p_values
    (frequency x channels), mean angles (frequency x channels in rads), degrees of freedom, residual_noise estimation
    """
    if weights is None:
        weights = np.ones((1, data.shape[1], data.shape[2]))
    _dof = effective_sampling_size(weights)
    # for the moment we assume that the same weight across time is applied so that it can be factor out from fft
    dof = np.min(_dof, axis=0, keepdims=False).squeeze()[None, :]

    yfft, exact_frequency = goertzel(data, fs, frequency)
    spectral_amp = np.abs(np.sum(yfft * weights, axis=2) / np.sum(weights, axis=2))
    diff = yfft - spectral_amp[:, :, None]
    noise = np.sqrt(np.var(diff, ddof=1, axis=2) / dof)
    # scale to match time domain amplitudes
    spectral_amp = 2 * spectral_amp / data.shape[0]
    residual_noise = 2 * noise / data.shape[0]
    yfft = yfft / np.abs(yfft)
    angles = np.angle(np.sum(yfft * weights, axis=2) / np.sum(weights, axis=2))
    plv = np.abs(np.sum(yfft * weights, axis=2) / np.sum(weights, axis=2))
    z = dof * plv ** 2
    # D.Wilkie. Rayleigh Test for Randomness of Circular Data".Applied Statistics.1983.
    tmp = np.ones(z.shape)
    _idx_tmp = (dof < 50).squeeze()

    if np.any(_idx_tmp):
        _tmp_correction = 1.0 + (2.0 * z - z * z) / (4.0 * dof) - (24.0 * z - 132.0 * z ** 2.0 +
                                                                   76.0 * z ** 3.0 - 9.0 * z ** 4.0) / (
                                      288.0 * dof * dof)
        tmp[:, _idx_tmp] = _tmp_correction
    z_crit = -np.log(alpha) - (2 * np.log(alpha) + np.log(alpha) ** 2.0) / (4 * dof)
    p_values = np.exp(-z) * tmp

    return spectral_amp, plv, z, z_crit, p_values, angles, dof, residual_noise


def get_discrete_frequency_value(
        data: type(np.array) | None = None,
        fs: float | None = None,
        frequency: float | None = None,
        weights: type(np.array) | None = None) -> np.array:
    """
    Compute spectral amplitude for a single frequency
    component.
    :param data: time x channels x trials numpy array in the time domain
    :param fs: float indicating the sampling rate in Hz
    :param frequency: float indicating the frequency of interest
    :param weights: trial by trial weights
    :return: frequency amplitudes
    """
    if weights is None:
        weights = np.ones(data.shape[1::])
    if weights.ndim == 3:
        # we assume that the same weight is use for each row
        weights = weights[0, :, :]
    dof = effective_sampling_size(weights, axis=1)
    yfft, _exact_freq = goertzel(data, fs, frequency)

    spectral_amp = np.abs(np.sum(yfft * weights, axis=2) / np.sum(weights, axis=1))
    diff = yfft - spectral_amp[:, :, None]
    noise = np.sqrt(np.var(diff, ddof=1, axis=2) / dof)
    # scale to match time domain amplitudes
    spectral_amp = 2 * spectral_amp / data.shape[0]
    residual_noise = 2 * noise / data.shape[0]
    yfft = 2 * yfft / data.shape[0]
    return yfft, spectral_amp, residual_noise


def freq_bin_phase_locking_value(
        yfft: type(np.array) | None = None,
        alpha: float = 0.05,
        weights: type(np.array) | None = None) -> np.array:
    """
    Compute phase, and  phase-locking value (PLV) using Rayleigh test for an array of trials from a single frequency
    component.
    :param yfft: fft_bin (complex) x channels x trials numpy array in the time domain
    :param alpha: float indicating the alpha value for significance
    :param weights: trial by trial weights
    :return: phase-locking value (frequency x channels), z-scores (frequency x channels), z_critic (float), p_values
    (frequency x channels), mean angles (frequency x channels in rads), degrees of freedom, residual_noise estimation
    """
    if weights is None:
        weights = np.ones(yfft.shape[1::])
    if weights.ndim == 3:
        # we assume that the same weight is use for each row
        weights = weights[0, :, :]
    dof = effective_sampling_size(weights, axis=1)
    spectral_mean = np.sum(yfft * weights, axis=2) / np.sum(weights, axis=1)
    spectral_amp = np.abs(spectral_mean)
    # subtract evoked response from all epochs
    noise_epochs = yfft - spectral_mean[:, :, None]
    noise_epochs_amp = np.abs(noise_epochs)
    noise_epochs_ang = np.angle(noise_epochs)
    mean_x = np.sum(noise_epochs_amp * np.cos(noise_epochs_ang) * weights,
                    axis=2,
                    keepdims=True) / np.sum(weights, axis=1, keepdims=True)
    mean_y = np.sum(noise_epochs_amp * np.sin(noise_epochs_ang) * weights,
                    axis=2,
                    keepdims=True) / np.sum(weights, axis=1, keepdims=True)
    var_x = np.sum(((noise_epochs_amp * np.cos(noise_epochs_ang) - mean_x) ** 2.0) * weights,
                   axis=2,
                   keepdims=True) / np.sum(weights, axis=1, keepdims=True)
    var_y = np.sum(((noise_epochs_amp * np.sin(noise_epochs_ang) - mean_y) ** 2.0) * weights,
                   axis=2,
                   keepdims=True) / np.sum(weights, axis=1, keepdims=True)
    # we assumed that variance on x and y-axis are independent of each other
    # this encapsulates the variance: sigma_r^2 <= variance <= sigma_r^2 + 4 * sum(w_angular*r_i*mean(r_i))
    total_var = var_x + var_y
    noise = np.sqrt(total_var / dof[:, None])
    # the same than np.std(yfft, axis=2) / np.sqrt(yfft.shape[2])
    residual_noise = noise[:, :, 0]
    # scale to match time domain amplitudes
    yfft = yfft / np.abs(yfft)
    angles = np.angle(np.sum(yfft * weights, axis=2) / np.sum(weights, axis=1))
    plv = np.abs(np.sum(yfft * weights, axis=2) / np.sum(weights, axis=1))
    z = dof * plv ** 2

    # D.Wilkie. Rayleigh Test for Randomness of Circular Data".Applied Statistics.1983.
    tmp = np.ones(z.shape)
    _idx_tmp = (dof < 50).squeeze()

    if np.any(_idx_tmp):
        _tmp_correction = 1.0 + (2.0 * z - z * z) / (4.0 * dof) - (
                24.0 * z - 132.0 * z ** 2.0 + 76.0 * z ** 3.0 - 9.0 * z ** 4.0) / (288.0 * dof * dof)
        tmp[:, _idx_tmp] = _tmp_correction
    z_crit = -np.log(alpha) - (2 * np.log(alpha) + np.log(alpha) ** 2.0) / (4 * dof)
    p_values = np.exp(-z) * tmp

    return spectral_amp, plv, z, z_crit, p_values, angles, dof, residual_noise


def analytical_dof(f_low: u.Quantity = 0 * u.Hz,
                   f_high: u.Quantity = 1000 * u.Hz,
                   p: float = 0,
                   length: u.Quantity = 1 * u.s) -> float:
    """
    This function returns the expected degrees of freedom for a coloured noise in the form of 1 / p ** 2, in which the
    colour of the noise is defined the exponent p, with white noise for p=0, pink noise for p =1, and brown noise for
    p = 2.0.
    The length defines the duration of the time window of the noise for which the degrees of freedom are returned.
    :param f_low: lowest frequency in the noise spectrum
    :param f_high: highest frequency in the noise spectrum
    :param p: exponent of the noise for which the power spectral density follows a 1 / f ** 2 function
    :param length: length in seconds for which the degrees of freedom are returned.
    :return: analytical degrees of freedom
    """
    if p == 1:
        num = (np.log(f_high/f_low)) ** 2.0
    else:
        num = ((f_high ** (1 - p) - f_low ** (1 - p)) / (1 - p)) ** 2
    if p == 0.5:
        den = (1 / length) * (np.log(f_high/f_low))
    else:
        den = (1 / length) * (f_high ** (1 - 2 * p) - f_low ** (1 - 2 * p)) / (1 - 2 * p)
    return 2 * num / den


def analytical_dof_discrete(f_low: u.Quantity = 0 * u.Hz,
                            f_high: u.Quantity = 1000 * u.Hz,
                            p: float = 0,
                            length: u.Quantity = 1 * u.s,
                            fs: u.Quantity | None = None) -> float:
    n_samples = int(length * fs)
    freq = np.arange(0, n_samples // 2).reshape([-1, 1]) * fs / n_samples
    _ini_freq = np.argmin(np.abs(freq - f_low))
    _end_freq = np.argmin(np.abs(freq - f_high))
    noise_psd = 1 / (freq.value ** p).reshape([-1, 1])
    noise_psd[0: _ini_freq] = 0
    noise_psd[_end_freq::] = 0
    _filter_psd = noise_psd
    dof = dof_from_psd(psd_noise=_filter_psd,
                       dof_factor=1,
                       psd_noise_n=n_samples)
    return float(dof)


def q_samples_mod_3(fft_input: type(np.array) | None = None,
                    idx: type(np.array) | None = None,
                    rankings_per_epoch: bool = False):
    """
    This function  computes the statistical significance of an input frequency array (samples x channels x epochs)
    using the modified non-parametric Q-samples Test. This method ranks both phase and spectral magnitude.
    1. Cebulla M., Sturzebecher E. & Elberling C. 2006. Objective detection of Auditory Steady State Responses:
    Comparison of One-Sample and q-Sample Tests. J. Am. Acad. Audiol. 17, 93103.
    :param fft_input: numpy array with the frequency response of the data to be analysed.
    :param idx: frequency indexes that should be taken into account for the analysis
    :param rankings_per_epoch: if True, the rankings are created on an epoch basis, from 1 to the number of frequencies
    :return: modified q-sample statistic V3 (ranking of amplitudes only. The phase is the original one
    """
    nch, m = fft_input.shape[1::]
    q = idx.shape[0]
    mq = m * q
    phi = np.angle(fft_input[idx, :, :])
    amp = abs(fft_input[idx, :, :])
    if rankings_per_epoch:
        scaling_constant = (1 / m) * ((2 ** 2) / ((q ** 2) * ((q + 1) ** 2)))
        ranks = np.arange(1, amp.shape[0] + 1)[:, None, None] * np.ones(amp.shape)
        m_idx = np.argsort(amp, axis=0, kind='quicksort')
        amp_ranks = np.take_along_axis(ranks, m_idx, axis=0)
    else:
        scaling_constant = (2 / m) * ((2 ** 2) / ((q ** 2) * ((q + 1) ** 2)))
        amp_ranks = np.zeros((mq, nch))
        m2 = eo.et_unfold(amp)
        m_idx = np.argsort(m2, axis=0, kind='quicksort')
        for _ch in range(nch):
            amp_ranks[m_idx[:, _ch], _ch] = np.arange(1, mq + 1)
        amp_ranks = eo.et_fold(amp_ranks, q)
    ck = np.sum(amp_ranks * np.cos(phi), axis=2)
    sk = np.sum(amp_ranks * np.sin(phi), axis=2)
    w = scaling_constant * np.sum((ck ** 2) + (sk ** 2), axis=0)
    return w
