from peegy.processing.pipe.definitions import InputOutputProcess
from peegy.processing.tools.epochs_processing_tools import et_mean
from peegy.definitions.eeg_definitions import EegPeak
from peegy.definitions.channel_definitions import Domain
from peegy.processing.statistics.definitions import PhaseLockingValueTest, TestType
from peegy.tools.units.unit_tools import set_default_unit
from peegy.processing.statistics.eeg_statistic_tools import phase_locking_value
from peegy.definitions.tables import Tables
import numpy as np
import pandas as pd
import os
import astropy.units as u
from PyQt5.QtCore import QLibraryInfo
os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = QLibraryInfo.location(QLibraryInfo.PluginsPath)


class PhaseLockingValue(InputOutputProcess):
    def __init__(self, input_process=InputOutputProcess,
                 n_tracked_points: int = None,
                 block_size: int = 1,
                 test_frequencies: np.array([u.Quantity]) = None,
                 n_fft: int = None,
                 alpha=0.05,
                 weight_data: bool = True,
                 weight_across_epochs: bool = True,
                 **kwargs):
        """
        This InputOutputProcess compute phase-locking value in the frequency domain
        :param input_process: InputOutputProcess Class
        :param n_tracked_points: number of equally spaced points over time used to estimate residual noise
        :param block_size: number of trials that will be stacked together to estimate the residual noise
        :param test_frequencies: numpy array with frequencies that will be used to compute statistics (Hotelling test)
        :param n_fft: number of fft points
        :param alpha: level for statistical significance
        :para, weight_data: If true, weights will be applied. If there are no weights, these will be calculated from
        weighted average.
        :param weight_across_epochs: if True, weights are computed across epochs (as in Elbeling 1984) otherwise
        weights are computed within epoch (1 / variance across time)
        :param kwargs: extra parameters to be passed to the superclass
        """
        super(PhaseLockingValue, self).__init__(input_process=input_process, **kwargs)
        self.n_tracked_points = n_tracked_points
        self.block_size = block_size
        self.test_frequencies = set_default_unit(np.unique(test_frequencies), u.Hz)
        self.n_fft = n_fft
        self.weight_data = weight_data
        self.weight_across_epochs = weight_across_epochs
        self.alpha = alpha

    def transform_data(self):
        self.test_frequencies = np.unique(self.test_frequencies)
        # average processed data across epochs including frequency average
        if self.n_fft is None:
            self.n_fft = self.input_node.data.shape[0]
        # we will use whatever weights are present in input_process
        weights = self.input_node.w
        if self.n_tracked_points is None:
            self.n_tracked_points = self.input_node.data.shape[0]
        samples_distance = int(max(self.input_node.data.shape[0] // self.n_tracked_points, 1))

        # we compute weights if required
        if self.weight_data and weights is None:
            # run weighted average to provide weights
            _w_average = et_mean(
                epochs=self.input_node.data,
                block_size=self.block_size,
                samples_distance=samples_distance,
                weighted=True,
                weight_across_epochs=self.weight_across_epochs,
                fs=self.input_node.fs
            )
            weights = _w_average.weights

        amp, plv, z, z_critic, p_values, angles, dof, rn = phase_locking_value(
            self.input_node.data,
            weights=weights,
            alpha=self.alpha)
        self.output_node.data = plv
        self.output_node.n_fft = self.n_fft
        self.output_node.domain = Domain.frequency
        self.output_node.frequency_resolution = self.input_node.fs / self.n_fft
        _stats = self.get_plv_tests_as_pandas(
            plv=plv,
            angles=angles,
            z=z,
            z_critic=z_critic,
            p_values=p_values,
            dof=dof,
            rn=rn)
        self.output_node.statistical_tests = Tables(table_name=TestType.rayleigh_test,
                                                    data=_stats,
                                                    data_source=self.name)
        self.output_node.peaks = self.get_plv_peaks_as_pandas(plv=plv,
                                                              p_values=p_values,
                                                              angles=angles)

    def get_plv_peaks_as_pandas(self, plv: np.array = None,
                                p_values: np.array = None,
                                angles: np.array = None):
        f_peaks = []
        freq_position = self.output_node.x_to_samples(self.test_frequencies)
        for _i, _ch in enumerate(self.input_node.layout):
            for _fpos, _f in zip(freq_position, self.test_frequencies):
                _f_peak = EegPeak(channel=_ch.label,
                                  x=_f,
                                  amplitude=plv[_fpos, _i],
                                  significant=bool(p_values[_fpos, _i] < self.alpha),
                                  peak_label="{:10.1f}".format(_f),
                                  show_label=True,
                                  positive=True,
                                  domain=Domain.frequency,
                                  phase=angles[_fpos, _i])
                f_peaks.append(_f_peak.__dict__)
        _data_pd = pd.DataFrame(f_peaks)
        return _data_pd

    def get_plv_tests_as_pandas(self, plv: np.array,
                                angles: np.array = None,
                                z: float = None,
                                z_critic: float = None,
                                p_values: np.array = None,
                                dof: float = None,
                                rn: float = None):
        r_tests = []
        freq_position = self.output_node.x_to_samples(self.test_frequencies)
        for _i, _ch in enumerate(self.input_node.layout):
            for _fpos, _f in zip(freq_position, self.test_frequencies):
                _test = PhaseLockingValueTest(p_value=p_values[_fpos, _i],
                                              phase=angles[_fpos, _i],
                                              plv=plv[_fpos, _i],
                                              z_critic=z_critic[0, _i],
                                              z_value=z[_fpos, _i],
                                              df_1=dof[0, _i],
                                              channel=_ch.label,
                                              tested_frequencies=_f,
                                              rn=rn[_fpos, _i])
                r_tests.append(_test.__dict__)
        _data_pd = pd.DataFrame(r_tests)
        return _data_pd
