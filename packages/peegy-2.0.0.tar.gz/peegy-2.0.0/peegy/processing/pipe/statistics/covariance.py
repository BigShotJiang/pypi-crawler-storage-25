from peegy.processing.pipe.definitions import InputOutputProcess
from peegy.processing.statistics.definitions import TestType
from peegy.definitions.tables import Tables
from peegy.tools.units.unit_tools import set_default_unit
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import astropy.units as u
import gc
from PyQt5.QtCore import QLibraryInfo
os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = QLibraryInfo.location(QLibraryInfo.PluginsPath)


class Covariance(InputOutputProcess):
    def __init__(self, input_process: InputOutputProcess = None,
                 normalized=True,
                 return_figures: bool = False,
                 ini_time: u.Quantity = 0 * u.s,
                 end_time: u.Quantity = np.inf * u.s,
                 fig_format: str = '.png',
                 fontsize: float = 12,
                 user_naming_rule: str = '',
                 save_to_file: bool = True,
                 **kwargs):
        """
        This class will estimate the covariance matrix
        :param input_process: an SpatialFilter InputOutputProcess Class
        :param normalized: if true, covariance will be normalized (i.e. correlation)
        :param return_figures: If true, handle to figure will be passed to self.figures
        :param ini_time: float indicating the starting time to compute covariance
        :param end_time: float indicating the ending time to compute covariance
        :param fig_format: string indicating the format of the output figure (e.g. '.png' or '.pdf')
        :param fontsize: size of fonts in plot
        :param idx_channels_to_plot: np.array indicating the index of the channels to plot
        :param user_naming_rule: string indicating a user naming to be included in the figure file name
        :param kwargs: extra parameters to be passed to the superclass
        """
        super(Covariance, self).__init__(input_process=input_process, **kwargs)
        self.normalized = normalized
        self.ini_time = set_default_unit(ini_time, u.s)
        self.end_time = set_default_unit(end_time, u.s)
        self.fig_format = fig_format
        self.fontsize = fontsize
        self.user_naming_rule = user_naming_rule
        self.return_figures = return_figures
        self.save_to_file = save_to_file
        self.figures = None

    def transform_data(self):
        data = self.input_node.data.value
        _ini_time = np.minimum(np.maximum(0,
                               self.input_node.x_to_samples(np.array([self.ini_time.to(u.s).value]) * u.s).squeeze()),
                               data.shape[0]).astype(int)
        _end_time = np.maximum(0,
                               np.minimum(
                                   data.shape[0],
                                   self.input_node.x_to_samples(np.array([self.end_time.to(u.s).value]) * u.s).squeeze()
                               )).astype(int)
        data = self.input_node.data.value[_ini_time: _end_time, :]
        if self.normalized:
            cov = np.corrcoef(data.T)
            v_min = -1 * u.dimensionless_unscaled
            v_max = 1 * u.dimensionless_unscaled
        else:
            cov = np.cov(data.T.value)
            v_min = np.min(cov)
            v_max = np.max(cov)

        self.output_node.data = cov
        # generate table
        table = pd.DataFrame()
        channels = [_ch.label for _ch in self.input_node.layout]
        for _i in range(cov.shape[0]):
            ch_i = channels[_i]
            for _j in range(cov.shape[1]):
                ch_j = channels[_j]
                table = pd.concat([table, pd.DataFrame([{'channel_x': ch_i,
                                                         'channel_y': ch_j,
                                                         'covariance': cov[_i, _j],
                                                         'normalized:': self.normalized}])],
                                  ignore_index=True)
        _stats = table
        self.output_node.statistical_tests = Tables(table_name=TestType.covariance,
                                                    data=_stats,
                                                    data_source=self.name)
        fig = plt.figure()
        ax = fig.add_subplot()
        maxis = ax.matshow(cov, vmin=v_min.value, vmax=v_max.value)
        ax.set_xticks(np.arange(0, len(channels)))
        ax.set_yticks(np.arange(0, len(channels)))
        ax.set_xticklabels(channels)
        ax.set_yticklabels(channels)
        plt.colorbar(maxis)
        mask = np.ones(cov.shape, dtype=bool)
        np.fill_diagonal(mask, 0)
        max_value = cov[mask].max()
        min_value = cov[mask].min()
        print('Maximum / Minimum covariance: {:} / {:}'.format(max_value, min_value))
        if self.save_to_file:
            figure_dir_path = self.input_node.paths.figures_current_dir
            _sep = '_' if self.user_naming_rule is not None else ''
            figure_basename = self.input_process.name + _sep + self.user_naming_rule
            fig.savefig(figure_dir_path + figure_basename + 'covariance' + self.fig_format)
        if self.return_figures:
            self.figures = fig
        else:
            plt.close(fig)
            gc.collect()
