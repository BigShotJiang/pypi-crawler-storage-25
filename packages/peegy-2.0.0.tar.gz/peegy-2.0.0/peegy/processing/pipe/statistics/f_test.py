import copy
import matplotlib.pyplot as plt
from peegy.processing.pipe.definitions import InputOutputProcess
from peegy.processing.tools.epochs_processing_tools import et_mean, et_snr_in_rois
from peegy.processing.statistics.eeg_statistic_tools import f_test
from peegy.processing.tools.detection.definitions import TimeROI, Marker
from peegy.definitions.eeg_definitions import EegPeak
from peegy.definitions.channel_definitions import Domain
from peegy.processing.statistics.definitions import FTestOutput, TestType
from peegy.definitions.tables import Tables
from peegy.tools.units.unit_tools import set_default_unit
import pyfftw
import numpy as np
import pandas as pd
from scipy.stats import f
import os
import astropy.units as u
from PyQt5.QtCore import QLibraryInfo
from tqdm import tqdm

os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = QLibraryInfo.location(
    QLibraryInfo.PluginsPath
)


class FTestFrequency(InputOutputProcess):
    def __init__(
            self,
            input_process=InputOutputProcess,
            delta_frequency: u.Quantity = 10.0 * u.Hz,
            test_frequencies: np.array([u.Quantity]) = None,
            alpha: float = 0.05,
            power_line_removal: bool = False,
            power_line_frequency: u.Quantity = 50 * u.Hz,
            power_line_delta_freq: u.Quantity = 0 * u.Hz,
            ignored_frequency_width: u.Quantity = 1 * u.Hz,
            n_fft: int = None,
            pool_frequencies: bool = True,
            **kwargs,
    ) -> InputOutputProcess:
        """
        This class computes a FTest in the frequency domain of a signal.
        :param input_process: InputOutputProcess Class
        :param delta_frequency: the length in Hz around each target frequency to compute statistics
        :param test_frequencies: a numpy array with the frequencies that will be tested
        :param alpha: level to assess significance of the test
        :param power_line_frequency: frequency of local power line frequency. This will be used to prevent using
        this frequency or its multiples when performing the FTest
        :param power_line_delta_freq: Tolerance to consider a frequency as powerline multiple. For example, if 1 Hz,
        then any multiple of a 50 Hz within 49 Hz to 51 Hz will be considered a power line multiple
        :param ignored_frequency_width: width, in Hz, indicating the with around the target frequency that will be
        ignored when estimating the F-ratio. Neighbors frequencies within +- this value will not be considered for the
        F-test.
        :param n_fft: number of points to perform fft transformation
        :param kwargs: extra parameters to be passed to the superclass
        """
        super(FTestFrequency, self).__init__(input_process=input_process, **kwargs)
        self.delta_frequency = set_default_unit(delta_frequency, u.Hz)
        self.ignored_frequency_width = set_default_unit(ignored_frequency_width, u.Hz)
        self.test_frequencies = set_default_unit(test_frequencies, u.Hz)
        self.fft_frequencies: np.array = None
        self.power_line_removal = power_line_removal
        self.power_line_frequency = power_line_frequency
        self.power_line_delta_freq = power_line_delta_freq
        self.alpha = alpha
        self.n_fft = n_fft
        self.pool_frequencies = pool_frequencies

    def transform_data(self):
        if self.input_node.domain == Domain.time:
            if self.n_fft is None:
                self.n_fft = self.input_node.data.shape[0]
            fft = pyfftw.builders.rfft(
                self.input_node.data,
                overwrite_input=False,
                planner_effort="FFTW_ESTIMATE",
                axis=0,
                threads=1,
                n=self.n_fft,
            )
            w_fft = fft() * self.input_node.data.unit

            psd = 1 / (self.n_fft ** 2) * 2 * np.abs(w_fft) ** 2
            w_fft = (2 / self.n_fft) * w_fft
            self.fft_frequencies = (
                    np.arange(w_fft.shape[0]) * self.input_node.fs / self.n_fft
            )
        else:
            self.n_fft = self.input_node.n_fft
            w_fft = self.input_node.data
            self.fft_frequencies = self.input_node.x
            # for  the psd we assume that the spectra are already scaled
            psd = (1 / 2) * np.abs(w_fft) ** 2

        self.output_node.data = w_fft
        self.output_node.n_fft = self.n_fft
        self.output_node.domain = Domain.frequency
        self.output_node.frequency_resolution = self.input_node.fs / self.input_node.data.shape[0]

        results = [[]] * self.input_node.data.shape[1]
        all_makers = np.array([])
        self.test_frequencies = np.unique(self.test_frequencies)
        if np.any(self.test_frequencies >= self.input_node.fs / 2):
            frequencies_to_remove = self.test_frequencies[
                self.test_frequencies >= self.input_node.fs / 2
                ]
            print(
                "Removing frequencies {:} >= Nyquest frequency {:}".format(
                    frequencies_to_remove, self.input_node.fs / 2
                )
            )
            self.test_frequencies = self.test_frequencies[
                self.test_frequencies < self.input_node.fs / 2
                ]
        if self.pool_frequencies:
            _target_bin = self.output_node.x_to_samples(self.test_frequencies)
            _neighbours_idx = self.get_neightboring_frequencies(frequencies=self.test_frequencies,
                                                                delta_frequency=self.delta_frequency)
            _noise_power = 0
            # compute the noise power for all frequencies used for the noise estimation
            for _nidx in _neighbours_idx:
                _noise_power = _noise_power + np.mean(psd[_nidx, :], axis=0)
            _total_target_power = np.sum(psd[_target_bin, :], axis=0)
            _total_angle = np.angle(np.sum(w_fft[_target_bin, :], axis=0))
            _f_tests = _total_target_power / _noise_power
            _n = np.unique(np.concatenate(_neighbours_idx)).size
            _d1 = 2 * self.test_frequencies.size
            _d2 = 2 * _n
            _f_critic = f.ppf(1 - self.alpha, _d1, _d2)

            for _ch, _f in enumerate(_f_tests):
                _p_values = 1 - f.cdf(_f, _d1, _d2)
                _snr = np.maximum(_f - 1, 0.0)
                _test_out = FTestOutput(
                    tested_frequencies=str(self.test_frequencies),
                    df_1=_d1,
                    df_2=_d2,
                    f=_f,
                    p_value=_p_values,
                    amplitude=(2 * _total_target_power[_ch]) ** 0.5,  # scale from power to amplitude as for a pure tone
                    rms=_total_target_power[_ch] ** 0.5,
                    phase=_total_angle[_ch],
                    rn=_noise_power[_ch] ** 0.5,  # scale from power to amplitude
                    snr=_snr,
                    snr_db=10 * np.log10(_snr)
                    if _snr > 0.0
                    else -np.inf * u.dimensionless_unscaled,
                    domain=Domain.frequency,
                    f_critic=_f_critic,
                    ini_time=self.input_node.x[0],
                    end_time=self.input_node.x[-1],
                    n_epochs=self.input_node.n
                )
                results[_ch] = np.append(results[_ch], [_test_out])
        else:
            for _freq in tqdm(self.test_frequencies, desc="F-Test"):
                _target_bin = self.output_node.x_to_samples([_freq])
                _neighbours_idx = self.get_neightboring_frequencies(frequencies=[_freq],
                                                                    delta_frequency=self.delta_frequency)

                _n = _neighbours_idx.size
                _f_critic = f.ppf(1 - self.alpha, 2, 2 * _n)
                # compute the noise power for all frequencies used for the noise estimation
                _noise_power = np.mean(psd[_neighbours_idx, :], axis=0)
                _f_tests = psd[_target_bin, :] / _noise_power

                for _ch, _f in enumerate(_f_tests):
                    _d1 = 2
                    _d2 = 2 * _n
                    _p_values = 1 - f.cdf(_f, _d1, _d2)
                    _snr = np.maximum(_f - 1, 0.0)
                    _test_out = FTestOutput(
                        tested_frequencies=_freq,
                        df_1=_d1,
                        df_2=_d2,
                        f=_f,
                        p_value=_p_values,
                        amplitude=np.abs(w_fft[_target_bin, _ch]),
                        rms=psd[_target_bin, :] ** 0.5,
                        phase=np.angle(w_fft[_target_bin, _ch]),
                        rn=_noise_power[_ch] ** 0.5,
                        snr=_snr,
                        snr_db=10 * np.log10(_snr)
                        if _snr > 0.0
                        else -np.inf * u.dimensionless_unscaled,
                        domain=Domain.frequency,
                        f_critic=_f_critic,
                        ini_time=self.input_node.x[0],
                        end_time=self.input_node.x[-1],
                        n_epochs=self.input_node.n
                    )
                    results[_ch] = np.append(results[_ch], [_test_out])
                # generate markers for plots
                _neighbours_idx = np.sort(_neighbours_idx)
                _marker_splits = np.argwhere(np.diff(_neighbours_idx) > 1)
                if _marker_splits.size:
                    _ini_bins = _neighbours_idx[np.append(0, _marker_splits + 1)]
                    _end_bins = _neighbours_idx[
                        np.append(_marker_splits, _neighbours_idx.size - 1)
                    ]
                    for _ini_m, _end_m in zip(_ini_bins, _end_bins):
                        _marker = [
                            Marker(
                                x_ini=self.fft_frequencies[_ini_m],
                                x_end=self.fft_frequencies[_end_m],
                                channel=_ch.label,
                            )
                            for _ch in self.input_node.layout
                        ]
                        all_makers = np.concatenate((all_makers, _marker))
            self.output_node.markers = pd.DataFrame([_m.__dict__ for _m in all_makers])
            self.output_node.peaks = self.get_frequency_peaks_as_pandas(f_tests=results)

        _stats = self.get_f_tests_as_pandas(results)
        self.output_node.statistical_tests = Tables(
            table_name=TestType.f_test, data=_stats, data_source=self.name
        )

    def get_frequency_peaks_as_pandas(self, f_tests: [np.array(FTestOutput)] = None):
        f_peaks = []
        for _i, (_f_ch, _ch) in enumerate(zip(f_tests, self.input_node.layout)):
            for _s_ft in _f_ch:
                _s_ft.label = _ch.label
                _f_peak = EegPeak(
                    channel=_ch.label,
                    x=_s_ft.tested_frequencies,
                    rn=_s_ft.rn,
                    amplitude=_s_ft.amplitude,
                    amplitude_snr=_s_ft.snr,
                    significant=bool(_s_ft.p_value < 0.05),
                    peak_label="{:10.1f}".format(_s_ft.tested_frequencies),
                    show_label=True,
                    positive=True,
                    domain=Domain.frequency,
                    phase=_s_ft.phase,
                )
                f_peaks.append(_f_peak.__dict__)
        _data_pd = pd.DataFrame(f_peaks)
        return _data_pd

    def freq_to_samples(
            self, value: np.array, delta_freq: u.Quantity = np.inf * u.Hz
    ) -> np.array:
        if isinstance(value, float) or value.size == 1:
            value = [value]
        out = np.array([])
        for _v in value:
            _idx = np.argmin(np.abs(self.fft_frequencies - _v))
            _meet_creteria = (
                    np.abs(self.fft_frequencies[_idx] - delta_freq) <= delta_freq
            )
            if _meet_creteria:
                out = np.append(out, _idx).astype(int)
        return np.squeeze(out)

    def get_f_tests_as_pandas(self, f_tests: [np.array(FTestOutput)] = None):
        f_peaks = []
        for _i, (_ht_ch, _ch) in enumerate(zip(f_tests, self.input_node.layout)):
            for _s_ht in _ht_ch:
                _s_ht.channel = _ch.label
                f_peaks.append(_s_ht.__dict__)
        _data_pd = pd.DataFrame(f_peaks)
        return _data_pd

    def get_neightboring_frequencies(self,
                                     frequencies: np.array(u.Quantity),
                                     delta_frequency: u.Quantity):
        all_bins = []
        for _freq in frequencies:
            _target_bin = self.output_node.x_to_samples([_freq])
            # compute array of bins around target frequency
            _ini_bin = self.output_node.x_to_samples(u.Quantity([_freq - self.delta_frequency]))
            _end_bin = self.output_node.x_to_samples(u.Quantity([_freq + self.delta_frequency]))

            _neighbours_idx_left = np.arange(_ini_bin, _target_bin)
            _neighbours_idx_right = np.arange(_target_bin + 1, _end_bin + 1)
            _neighbours_idx = np.concatenate(
                (_neighbours_idx_left, _neighbours_idx_right)
            )
            # compute array of bins around target frequency
            _ini_ignore = self.output_node.x_to_samples(u.Quantity([_freq - self.ignored_frequency_width]))
            _end_ignore = self.output_node.x_to_samples(u.Quantity([_freq + self.ignored_frequency_width]))
            _neighbours_to_ignore_idx = np.concatenate(
                (
                    np.arange(_ini_ignore, _target_bin),
                    np.arange(_target_bin + 1, _end_ignore + 1),
                )
            )
            if self.power_line_removal:
                # compute power line frequencies
                _power_idx = np.array(
                    [
                        self.output_node.x_to_samples([_power_freq])
                        for _power_freq in
                        self.power_line_frequency *
                        np.arange(1, np.round(0.5 * self.output_node.fs / self.power_line_frequency))],
                    dtype=object)
                # remove bins
                _neighbours_idx = np.setdiff1d(_neighbours_idx, _power_idx)
                assert _neighbours_idx.size > 0, (
                    "All frequency bins were removed as they all fit your powerline"
                    " criteria, check criteria or disable powerline"
                )
            # remove other bins
            _neighbours_idx = np.setdiff1d(_neighbours_idx, _neighbours_to_ignore_idx)
            all_bins.append(_neighbours_idx)
        return all_bins


class FmpiTestTime(InputOutputProcess):
    def __init__(
            self,
            input_process=InputOutputProcess,
            weighted_average: bool = True,
            n_tracked_points: int = None,
            block_size: int = 1,
            roi_windows: np.array([TimeROI]) = np.array(TimeROI()),
            weight_across_epochs: bool = False,
            remove_average_for_dof_estimation: bool = False,
            demeaned_noise: bool = False,
            rn_roi_window: TimeROI = TimeROI(),
            **kwargs,
    ):
        """
        This InputOutputProcess average epochs and compute F-test on ROI windows
        :param input_process: InputOutputProcess Class
        :param weighted_average: if True, weighted average will be used
        :param n_tracked_points: number of equally spaced points over time used to estimate residual noise
        :param block_size: number of trials that will be stacked together to estimate the residual noise
        :param roi_windows: time windows used to perform some measures (snr, rms)
        :param weight_across_epochs: if True, weights are computed across epochs (as in Elbeling 1984) otherwise weights
        are computed within epoch (1 / variance across time)
        :param remove_average_for_dof_estimation: If true, the average across epochs will be removed for each of the
        epochs before estimating the PSD
        :param freq_ini: initial frequency to estimate the degrees of freedom of the F-Test
        :param freq_end: ending frequency to estimate the degrees of freedom of the F-Test
        :param demeaned_noise: if true, the mean of the data will be removed from each epoch before computing residual
        noise.
        :param delta_frequency_noise: frequency offset to estimate residual noise in the frequency domain. Useful for
        discrete frequency analysis
        :param rn_roi_window: if not None, the residual noise will be estiamted from the ROI window passed
        :param kwargs: extra parameters to be passed to the superclass
        """
        super(FmpiTestTime, self).__init__(input_process=input_process, **kwargs)
        self.weighted_average = weighted_average
        self.weight_across_epochs = weight_across_epochs
        self.n_tracked_points = n_tracked_points
        self.block_size = block_size
        self.roi_windows = roi_windows
        self.noise_estimation = None
        self.dof_within_epochs = None
        self.dof_across_epochs = None
        self.psd_within_epochs = None
        self.dof_rn = None
        self.remove_average_for_dof_estimation = remove_average_for_dof_estimation
        self.demeaned_noise = demeaned_noise
        self.rn_roi_window = rn_roi_window

    def transform_data(self):
        block_size = max(self.block_size, 1)
        if self.n_tracked_points is None:
            self.n_tracked_points = self.input_node.data.shape[0]
        samples_distance = int(
            max(self.input_node.data.shape[0] // self.n_tracked_points, 1)
        )
        _samples = self.rn_roi_window.get_roi_samples(data_node=self.input_node)
        rn_window = [_samples[0], _samples[-1]]

        _average = et_mean(
            epochs=self.input_node.data,
            block_size=block_size,
            samples_distance=samples_distance,
            weighted=self.weighted_average,
            weight_across_epochs=self.weight_across_epochs,
            remove_average_for_dof_estimation=self.remove_average_for_dof_estimation,
            fs=self.input_node.fs,
            demeaned_noise=self.demeaned_noise,
            rn_window=rn_window,
            rn_domain=Domain.time,
        )
        self.output_node.data = _average.average.data
        self.output_node.rn = _average.rn
        self.output_node.cum_rn = _average.cumulative_rn
        self.output_node.w = _average.weights
        self.output_node.n = _average.n_epochs
        self.dof_within_epochs = _average.dof_within_epochs
        self.dof_across_epochs = _average.dof_across_epochs
        self.psd_within_epochs = _average.psd_within_epochs
        self.dof_rn = _average.dof_rn
        self.output_node.snr = _average.snr
        _stats = self.get_snr_table()
        self.output_node.statistical_tests = Tables(
            table_name=TestType.f_test, data=_stats, data_source=self.name
        )
        self.output_node.roi_windows = self.roi_windows

    def get_snr_table(self):
        final_snr, final_s_var, fvalues, frequencies, _ = et_snr_in_rois(
            data_node=self.output_node,
            roi_windows=self.roi_windows
        )
        tests = []
        for _iw, _roi in enumerate(self.roi_windows):
            roi_samples = _roi.get_roi_samples(data_node=self.output_node)
            _ini = roi_samples[0]
            _end = roi_samples[-1]
            _label = _roi.window_label
            _chunk_size = roi_samples.shape[0]
            dof_num = (
                    self.dof_within_epochs * _chunk_size / self.output_node.data.shape[0]
            )
            f_value = fvalues[:, _iw]
            snr = final_snr[:, _iw]
            rms = np.sqrt(final_s_var[:, _iw])
            f_critic, p_value = f_test(
                dof_num=dof_num,
                dof_den=self.dof_rn,
                f_value=f_value,
                alpha=self.output_node.alpha,
            )
            for _idx_ch, _ch in enumerate(self.output_node.layout):
                tests.append(
                    FTestOutput(
                        df_1=dof_num[_idx_ch],
                        df_2=self.dof_rn[_idx_ch],
                        f=f_value[_idx_ch],
                        f_critic=f_critic[_idx_ch],
                        p_value=p_value[_idx_ch],
                        rn=self.output_node.rn[_idx_ch],
                        bn=self.output_node.rn[_idx_ch] * np.sqrt(self.output_node.n),
                        snr=snr[_idx_ch],
                        rms=rms[_idx_ch],
                        domain=Domain.time,
                        ini_time=self.output_node.samples_to_x([_ini])[0],
                        end_time=self.output_node.samples_to_x([_end])[0],
                        n_epochs=self.output_node.n,
                        effective_n_epochs=self.dof_across_epochs[_idx_ch],
                        channel=_ch.label,
                        tested_frequencies=str(frequencies),
                        window_label=_label,
                    ).__dict__
                )
        out = pd.DataFrame(tests)
        return out

    def plot_psd(self):
        fig, ax = plt.subplots(1)
        freq = (
                np.arange(0, self.psd_within_epochs.shape[0])
                * self.output_node.fs
                / self.output_node.data.shape[0]
        )
        ax.plot(freq, self.psd_within_epochs / self.dof_across_epochs)
        _data = self.output_node.data
        ax.plot(freq, np.abs(2 / _data.shape[0] * np.fft.rfft(_data, axis=0)) ** 2.0)
        fig.show()


class FmpiTestFrequency(InputOutputProcess):
    def __init__(
            self,
            input_process=InputOutputProcess,
            weighted_average: bool = True,
            n_tracked_points: int = None,
            block_size: int = 1,
            roi_windows: np.array([TimeROI]) = np.array([TimeROI()]),
            remove_average_for_dof_estimation: bool = True,
            freq_ini: u.Quantity = None,
            freq_end: u.Quantity = None,
            test_frequencies: np.array(u.Quantity) = None,
            demeaned_noise: bool = False,
            offset_frequency_noise: u.Quantity = 0 * u.Hz,
            delta_frequency_noise: u.Quantity = 0 * u.Hz,
            rn_roi_window: TimeROI = TimeROI(),
            power_line_removal: bool = False,
            power_line_frequency: u.Quantity = 50 * u.Hz,
            power_line_delta_freq: u.Quantity = 0 * u.Hz,
            include_test_frequencies_in_noise_estimation: bool = True,
            **kwargs,
    ):
        """
        This InputOutputProcess average epochs and compute F-test on ROI windows
        :param input_process: InputOutputProcess Class
        :param weighted_average: if True, weighted average will be used
        :param n_tracked_points: number of equally spaced points over time used to estimate residual noise
        :param block_size: number of trials that will be stacked together to estimate the residual noise
        :param roi_windows: time windows used to perform some measures (snr, rms)
        :param remove_average_for_dof_estimation: If true, the average across epochs will be removed for each of the
        epochs before estimating the PSD
        :param freq_ini: initial frequency to estimate the variance of the signal in the frequency domain
        :param freq_end: ending frequency to estimate the variance of the signal in the frequency domain
        :param test_frequencies: array of frequencies to estimate the variances of the signal in the frequency domain
        :param demeaned_noise: if True, noise estimation will be performed by first subtracting the mean across epochs
        :param demeaned_noise: if true, the mean of the data will be removed from each epoch before computing residual
        noise.
        :param offset_frequency_noise: frequency offset to estimate residual noise in the frequency domain. Useful for
        discrete frequency analysis
        :param delta_frequency_noise: frequency delta to estimate residual noise in the frequency domain. In this case
        noise frequency bins will be centered at offset_frequency_noise but including plus/minus delta_frequency_noise
        :param rn_roi_window: if not None, the residual noise will be estimated from the ROI window passed
        :param power_line_removal: if True, frequency components matching powerline base frequency and harmonics will be
        removed from the analysis
        :param power_line_frequency: frequency of local power line frequency. This will be used to prevent using
        this frequency or its multiples when performing the FTest
        :param power_line_delta_freq: Tolerance to consider a frequency as powerline multiple. For example, if 1 Hz,
        then any multiple of a 50 Hz within 49 Hz to 51 Hz will be considered a power line multiple
        :param include_test_frequencies_in_noise_estimation: if True, test frequencies will be used for niose estimation
        :param kwargs: extra parameters to be passed to the superclass
        """
        super(FmpiTestFrequency, self).__init__(input_process=input_process, **kwargs)
        self.weighted_average = weighted_average
        self.n_tracked_points = n_tracked_points
        self.block_size = block_size
        self.roi_windows = roi_windows
        self.noise_estimation = None
        self.dof_within_epochs = None
        self.dof_across_epochs = None
        self.psd_within_epochs = None
        self.dof_rn = None
        self.remove_average_for_dof_estimation = remove_average_for_dof_estimation
        self.freq_ini = freq_ini
        self.freq_end = freq_end
        self.test_frequencies = test_frequencies
        self.demeaned_noise = demeaned_noise
        self.offset_frequency_noise = offset_frequency_noise
        self.delta_frequency_noise = delta_frequency_noise
        self.rn_roi_window = rn_roi_window
        self.power_line_removal = power_line_removal
        self.power_line_frequency = power_line_frequency
        self.power_line_delta_freq = power_line_delta_freq
        self.include_test_frequencies_in_noise_estimation = include_test_frequencies_in_noise_estimation

    def transform_data(self):
        block_size = max(self.block_size, 1)
        if self.test_frequencies is not None:
            if np.any(self.test_frequencies >= self.input_node.fs / 2):
                frequencies_to_remove = self.test_frequencies[
                    self.test_frequencies >= self.input_node.fs / 2
                    ]
                print(
                    "Removing frequencies {:} >= Nyquest frequency {:}".format(
                        frequencies_to_remove, self.input_node.fs / 2
                    )
                )
                self.test_frequencies = self.test_frequencies[
                    self.test_frequencies < self.input_node.fs / 2
                    ]

        if self.n_tracked_points is None:
            self.n_tracked_points = self.input_node.data.shape[0]
        samples_distance = int(
            max(self.input_node.data.shape[0] // self.n_tracked_points, 1)
        )
        _samples = self.rn_roi_window.get_roi_samples(data_node=self.input_node)
        rn_window = [_samples[0], _samples[-1]]
        _average = et_mean(
            epochs=self.input_node.data,
            block_size=block_size,
            samples_distance=samples_distance,
            weighted=self.weighted_average,
            weight_across_epochs=False,
            remove_average_for_dof_estimation=self.remove_average_for_dof_estimation,
            freq_ini=self.freq_ini,
            freq_end=self.freq_end,
            test_frequencies=self.test_frequencies,
            fs=self.input_node.fs,
            demean_epochs=True,
            demeaned_noise=self.demeaned_noise,
            delta_frequency_noise=self.delta_frequency_noise,
            offset_frequency_noise=self.offset_frequency_noise,
            rn_window=rn_window,
            rn_domain=Domain.frequency,
            include_test_frequencies_in_noise_estimation=self.include_test_frequencies_in_noise_estimation,
        )
        self.output_node.data = _average.average.data
        self.output_node.rn = _average.rn
        self.output_node.cum_rn = _average.cumulative_rn
        self.output_node.w = _average.weights
        self.output_node.n = _average.n_epochs
        self.dof_within_epochs = _average.dof_within_epochs
        self.dof_across_epochs = _average.dof_across_epochs
        self.psd_within_epochs = _average.psd_within_epochs
        self.dof_rn = _average.dof_rn
        self.output_node.snr = _average.snr

        _stats = self.get_snr_table()
        self.output_node.statistical_tests = Tables(
            table_name=TestType.f_test, data=_stats, data_source=self.name
        )
        self.output_node.roi_windows = self.roi_windows
        # rewrite output data in frequency-domain if test_frequencies were used
        if self.test_frequencies is not None:
            self.output_node.data = _average.fft
            self.output_node.n_fft = self.input_node.data.shape[0]
            self.output_node.domain = Domain.frequency
            self.output_node.frequency_resolution = self.input_node.fs / self.input_node.data.shape[0]

        self.output_node.peaks = self.get_frequency_peaks_as_pandas(f_tests=_stats)
        self.output_node.markers = self.get_markers()

    def get_snr_table(self):
        if self.rn_roi_window is not None:
            _samples = self.rn_roi_window.get_roi_samples(self.input_node)
            frequency_resolution = 1 / (_samples.size / self.input_node.fs)
        else:
            frequency_resolution = 1 / (
                    self.input_node.data.shape[0] / self.input_node.fs
            )

        final_snr, final_s_var, fvalues, frequencies, _phase = et_snr_in_rois(
            data_node=self.output_node,
            roi_windows=self.roi_windows,
            freq_ini=self.freq_ini,
            freq_end=self.freq_end,
            test_frequencies=self.test_frequencies,
            frequency_resolution=frequency_resolution,
        )
        tests = []
        domain = Domain.frequency if self.test_frequencies is not None else Domain.time
        for _iw, _roi in enumerate(self.roi_windows):
            _samples = _roi.get_roi_samples(data_node=self.output_node)
            _ini, _end = _samples[0], _samples[-1]
            _label = _roi.window_label

            _chunk_size = _samples.size
            dof_num = (
                    self.dof_within_epochs * _chunk_size / self.output_node.data.shape[0]
            )
            f_value = fvalues[:, _iw]
            snr = final_snr[:, _iw]
            rms = np.sqrt(final_s_var[:, _iw])
            phase = _phase[:, _iw]
            f_critic, p_value = f_test(
                dof_num=dof_num,
                dof_den=self.dof_rn,
                f_value=f_value,
                alpha=self.output_node.alpha,
            )
            for _idx_ch, _ch in enumerate(self.output_node.layout):
                tests.append(
                    FTestOutput(
                        df_1=dof_num[_idx_ch],
                        df_2=self.dof_rn[_idx_ch],
                        f=f_value[_idx_ch],
                        amplitude=np.sqrt(2) * rms[_idx_ch],
                        rms=rms[_idx_ch],
                        phase=phase[_idx_ch],
                        f_critic=f_critic[_idx_ch],
                        p_value=p_value[_idx_ch],
                        rn=self.output_node.rn[_idx_ch],
                        bn=self.output_node.rn[_idx_ch] * np.sqrt(self.output_node.n),
                        snr=snr[_idx_ch],
                        domain=domain,
                        ini_time=self.output_node.samples_to_x([_ini])[0],
                        end_time=self.output_node.samples_to_x([_end])[0],
                        n_epochs=self.output_node.n,
                        effective_n_epochs=self.dof_across_epochs[_idx_ch],
                        channel=_ch.label,
                        tested_frequencies=str(frequencies),
                        window_label=_label,
                    ).__dict__
                )
        out = pd.DataFrame(tests)
        return out

    def plot_psd(self):
        fig, ax = plt.subplots(1)
        freq = (
                np.arange(0, self.psd_within_epochs.shape[0])
                * self.output_node.fs
                / self.output_node.data.shape[0]
        )
        ax.plot(freq, self.psd_within_epochs / self.dof_across_epochs)
        _data = self.output_node.data
        ax.plot(freq, np.abs(2 / _data.shape[0] * np.fft.rfft(_data, axis=0)) ** 2.0)
        fig.show()

    def get_frequency_peaks_as_pandas(self, f_tests: pd.DataFrame = None):
        f_peaks = []
        temp_ftest = copy.copy(f_tests)
        temp_ftest['significant'] = temp_ftest.p_value < 0.05
        _data_pd = pd.DataFrame()
        if self.test_frequencies is not None:
            for _f in self.test_frequencies:
                _idx_freq = self.output_node.x_to_samples([_f])
                for _idx_ch, _ch in enumerate(self.input_node.layout):
                    amp = np.abs(self.output_node.data[_idx_freq, _idx_ch])
                    phase = np.angle(self.output_node.data[_idx_freq, _idx_ch])
                    sig = temp_ftest.loc[temp_ftest['channel'] == _ch.label]['significant'].values[0]
                    _f_peak = EegPeak(
                        channel=_ch.label,
                        x=self.output_node.x[_idx_freq],
                        rn=None,
                        amplitude=amp,
                        amplitude_snr=None,
                        significant=sig,
                        peak_label="{:10.1f}".format(self.output_node.x[_idx_freq][0]),
                        show_label=True,
                        positive=True,
                        domain=Domain.frequency,
                        phase=phase,
                    )
                    f_peaks.append(_f_peak.__dict__)
                    _data_pd = pd.DataFrame(f_peaks)
        return _data_pd

    def get_markers(self):
        all_makers = np.array([])
        if self.test_frequencies is not None:
            # generate markers for plots
            _neighbours_idx = self.get_neightboring_frequencies(frequencies=self.test_frequencies,
                                                                delta_frequency=self.delta_frequency_noise)
            if len(_neighbours_idx):
                _ini_bins = np.array([_n_idx[0] for _n_idx in _neighbours_idx])
                _end_bins = np.array([_n_idx[-1] for _n_idx in _neighbours_idx])
                for _ini_m, _end_m in zip(_ini_bins, _end_bins):
                    _marker = [
                        Marker(
                            x_ini=self.output_node.x[_ini_m],
                            x_end=self.output_node.x[_end_m],
                            channel=_ch.label,
                        )
                        for _ch in self.input_node.layout
                    ]
                    all_makers = np.concatenate((all_makers, _marker))
        markers_df = None
        if all_makers.size:
            markers_df = pd.DataFrame()
            markers_df = pd.DataFrame([_m.__dict__ for _m in all_makers])
        return markers_df

    def get_neightboring_frequencies(self,
                                     frequencies: np.array(u.Quantity),
                                     delta_frequency: u.Quantity):
        all_bins = []
        for _freq in frequencies:
            _target_bin = self.output_node.x_to_samples([_freq])
            # compute array of bins around target frequency
            _ini_bin = self.output_node.x_to_samples(u.Quantity([_freq - delta_frequency]))
            _end_bin = self.output_node.x_to_samples(u.Quantity([_freq + delta_frequency]))

            _neighbours_idx_left = np.arange(_ini_bin, _target_bin)
            _neighbours_idx_right = np.arange(_target_bin + 1, _end_bin + 1)
            _neighbours_idx = np.concatenate(
                (_neighbours_idx_left, _neighbours_idx_right)
            )
            if self.power_line_removal:
                # compute power line frequencies
                _power_idx = np.array(
                    [
                        self.output_node.x_to_samples([_power_freq])
                        for _power_freq in
                        self.power_line_frequency *
                        np.arange(1, np.round(0.5 * self.output_node.fs / self.power_line_frequency))],
                    dtype=object)
                # remove bins
                _neighbours_idx = np.setdiff1d(_neighbours_idx, _power_idx)
                assert _neighbours_idx.size > 0, (
                    "All frequency bins were removed as they all fit your powerline"
                    " criteria, check criteria or disable powerline"
                )
            # remove other bins
            all_bins.append(_neighbours_idx)
        all_bins = [np.sort(_bins) for _bins in all_bins]
        return all_bins


class FmpiTestTimeMMR(InputOutputProcess):
    def __init__(
            self,
            input_process_standard=InputOutputProcess,
            input_process_deviant=InputOutputProcess,
            weighted_average: bool = True,
            n_tracked_points: int = None,
            block_size: int = 1,
            roi_windows: np.array([TimeROI]) = np.array(TimeROI()),
            weight_across_epochs: bool = False,
            remove_average_for_dof_estimation: bool = False,
            demeaned_noise: bool = False,
            rn_roi_window: TimeROI = TimeROI(),
            correct_deviant_noise: bool = True,
            **kwargs,
    ):
        """
        This InputOutputProcess average standard and deviant epochs and compute F-test on ROI windows
        :param input_process_standard: InputOutputProcess Class
        :param input_process_deviant: InputOutputProcess Class
        :param weighted_average: if True, weighted average will be used
        :param n_tracked_points: number of equally spaced points over time used to estimate residual noise
        :param block_size: number of trials that will be stacked together to estimate the residual noise
        :param roi_windows: time windows used to perform some measures (snr, rms)
        :param weight_across_epochs: if True, weights are computed across epochs (as in Elbeling 1984) otherwise weights
        are computed within epoch (1 / variance across time)
        :param remove_average_for_dof_estimation: If true, the average across epochs will be removed for each of the
        epochs before estimating the PSD
        :param freq_ini: initial frequency to estimate the degrees of freedom of the F-Test
        :param freq_end: ending frequency to estimate the degrees of freedom of the F-Test
        :param demeaned_noise: if true, the mean of the data will be removed from each epoch before computing residual
        noise.
        :param delta_frequency_noise: frequency offset to estimate residual noise in the frequency domain. Useful for
        discrete frequency analysis
        :param rn_roi_window: if not None, the residual noise will be estiamted from the ROI window passed
        :param correct_deviant_noise: if True, the variance of the average MMR will be corrected to account for
        the noise in the deviation waveform
        :param kwargs: extra parameters to be passed to the superclass
        """
        super(FmpiTestTimeMMR, self).__init__(input_process=None, **kwargs)
        self.input_process_standard = input_process_standard
        self.input_process_deviant = input_process_deviant
        self.weighted_average = weighted_average
        self.weight_across_epochs = weight_across_epochs
        self.n_tracked_points = n_tracked_points
        self.block_size = block_size
        self.roi_windows = roi_windows
        self.noise_estimation = None
        self.dof_within_epochs = None
        self.dof_across_epochs = None
        self.psd_within_epochs = None
        self.dof_rn = None
        self.remove_average_for_dof_estimation = remove_average_for_dof_estimation
        self.demeaned_noise = demeaned_noise
        self.rn_roi_window = rn_roi_window
        self.average_standard = None
        self.average_deviant = None
        self.correct_deviant_noise = correct_deviant_noise

    def transform_data(self):
        self.input_process_standard.run()
        self.input_process_deviant.run()
        block_size = max(self.block_size, 1)
        if self.n_tracked_points is None:
            self.n_tracked_points = self.input_process_standard.output_node.data.shape[0]
        samples_distance = int(
            max(self.input_process_standard.output_node.data.shape[0] // self.n_tracked_points, 1)
        )
        _samples = self.rn_roi_window.get_roi_samples(data_node=self.input_process_standard.output_node)
        rn_window = [_samples[0], _samples[-1]]

        _average_deviant = et_mean(
            epochs=self.input_process_deviant.output_node.data,
            block_size=block_size,
            samples_distance=samples_distance,
            weighted=self.weighted_average,
            weight_across_epochs=self.weight_across_epochs,
            remove_average_for_dof_estimation=self.remove_average_for_dof_estimation,
            fs=self.input_process_deviant.output_node.fs,
            demeaned_noise=self.demeaned_noise,
            rn_window=rn_window,
            rn_domain=Domain.time,
        )

        _average_standard = et_mean(
            epochs=self.input_process_standard.output_node.data,
            block_size=block_size,
            samples_distance=samples_distance,
            weighted=self.weighted_average,
            weight_across_epochs=self.weight_across_epochs,
            remove_average_for_dof_estimation=self.remove_average_for_dof_estimation,
            fs=self.input_process_standard.output_node.fs,
            demeaned_noise=self.demeaned_noise,
            rn_window=rn_window,
            rn_domain=Domain.time,
        )
        mmr_data = _average_deviant.average.data - _average_standard.average.data
        _mmr_psd_within_epochs = (_average_deviant.psd_within_epochs + _average_standard.psd_within_epochs) / 2
        mmr_dof_rn_across_epochs = _average_deviant.dof_across_epochs
        _mmr_dof_within_epochs = (_average_deviant.dof_within_epochs + _average_standard.dof_within_epochs) / 2
        _mmr_rn = np.sqrt(_average_deviant.rn ** 2 + _average_standard.rn ** 2)
        _mmr_dof_rn = _mmr_dof_within_epochs * mmr_dof_rn_across_epochs

        self.average_standard = _average_standard
        self.average_deviant = _average_deviant

        self.output_node.data = mmr_data
        self.output_node.layout = self.input_process_deviant.output_node.layout
        self.output_node.rn = _mmr_rn
        self.output_node.cum_rn = np.sqrt(_average_deviant.cumulative_rn ** 2 + _average_standard.rn ** 2)
        self.output_node.w = _average_deviant.weights
        self.output_node.n = _average_deviant.n_epochs
        self.output_node.fs = _average_deviant.fs
        self.output_node.x_offset = self.input_process_deviant.output_node.x_offset
        self.dof_within_epochs = _mmr_dof_within_epochs
        self.dof_across_epochs = mmr_dof_rn_across_epochs
        self.psd_within_epochs = _mmr_psd_within_epochs
        self.dof_rn = _mmr_dof_rn
        self.output_node.snr = np.maximum(np.var(mmr_data, ddof=1, axis=0) / self.output_node.rn ** 2.0 - 1, 0)
        _stats = self.get_snr_table()
        self.output_node.statistical_tests = Tables(
            table_name=TestType.f_test, data=_stats, data_source=self.name
        )
        self.output_node.roi_windows = self.roi_windows

    def get_snr_table(self):
        final_snr, final_s_var, fvalues, frequencies, _ = et_snr_in_rois(
            data_node=self.output_node,
            roi_windows=self.roi_windows,
        )
        tests = []
        for _iw, _roi in enumerate(self.roi_windows):
            roi_samples = _roi.get_roi_samples(data_node=self.output_node)
            _ini = roi_samples[0]
            _end = roi_samples[-1]
            _label = _roi.window_label
            _chunk_size = roi_samples.shape[0]
            dof_num = (
                    self.dof_within_epochs * _chunk_size / self.output_node.data.shape[0]
            )
            f_value = fvalues[:, _iw]
            snr = final_snr[:, _iw]
            rms = np.sqrt(final_s_var[:, _iw])
            f_critic, p_value = f_test(
                dof_num=dof_num,
                dof_den=self.dof_rn,
                f_value=f_value,
                alpha=self.output_node.alpha,
            )
            for _idx_ch, _ch in enumerate(self.output_node.layout):
                tests.append(
                    FTestOutput(
                        df_1=dof_num[_idx_ch],
                        df_2=self.dof_rn[_idx_ch],
                        f=f_value[_idx_ch],
                        f_critic=f_critic[_idx_ch],
                        p_value=p_value[_idx_ch],
                        rn=self.output_node.rn[_idx_ch],
                        bn=self.output_node.rn[_idx_ch] * np.sqrt(self.output_node.n),
                        snr=snr[_idx_ch],
                        rms=rms[_idx_ch],
                        domain=Domain.time,
                        ini_time=self.output_node.samples_to_x([_ini])[0],
                        end_time=self.output_node.samples_to_x([_end])[0],
                        n_epochs=self.output_node.n,
                        effective_n_epochs=self.dof_across_epochs[_idx_ch],
                        channel=_ch.label,
                        tested_frequencies=str(frequencies),
                        window_label=_label,
                    ).__dict__
                )
        out = pd.DataFrame(tests)
        return out

    def plot_psd(self):
        fig, ax = plt.subplots(1)
        freq = (
                np.arange(0, self.psd_within_epochs.shape[0])
                * self.output_node.fs
                / self.output_node.data.shape[0]
        )
        ax.plot(freq, self.psd_within_epochs / self.dof_across_epochs)
        _data = self.output_node.data
        ax.plot(freq, np.abs(2 / _data.shape[0] * np.fft.rfft(_data, axis=0)) ** 2.0)
        fig.show()
