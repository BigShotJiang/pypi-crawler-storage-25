from peegy.processing.pipe.definitions import InputOutputProcess
from peegy.processing.tools.epochs_processing_tools import et_mean
from peegy.processing.tools.detection.definitions import TimeROI
from peegy.definitions.channel_definitions import Domain
from peegy.processing.statistics.definitions import TestType
from peegy.definitions.tables import Tables
from peegy.tools.units.unit_tools import set_default_unit
from peegy.processing.statistics.eeg_statistic_tools import hotelling_t_square_test
import pyfftw
import numpy as np
import pandas as pd
import os
import astropy.units as u
from PyQt5.QtCore import QLibraryInfo
from tqdm import tqdm

os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = QLibraryInfo.location(
    QLibraryInfo.PluginsPath
)


class HotellingT2TestTime(InputOutputProcess):
    def __init__(
            self,
            input_process=InputOutputProcess,
            block_time: u.quantity.Quantity = 0.040 * u.s,
            roi_windows: np.array(TimeROI) = None,
            weight_data: bool = True,
            block_size: int = 5,
            weight_across_epochs: bool = True,
            **kwargs,
    ) -> InputOutputProcess:
        """
        This class computes the statistical significance of a region of interest in the  time-domain using a Hotelling
        T2 test.
        The time region where a response is expected is tested to assess whether the linear combination of data points
        within this region is significantly different of a random linear combination of points.

        :param input_process: InputOutputProcess Class
        :param block_time: the length (in secs) of each average window within a region of interest (roi). A ROI will be
        divided in several points of duration block_time. The average of each block_time will represent a sample passed
        for the statistical test
        :param roi_windows: a region of windows containing the response of interest
        :param weight_data: if True, estimations are based on weights from input node. If empty, weights are
        estimated from weighted average.
        :param block_size: number of epochs used to estimate weights when weight_data is True
        :param weight_across_epochs: if True, weights are computed across epochs (as in Elbeling 1984) otherwise weights
        are computed within epoch (1 / variance across time)
        :param kwargs: extra parameters to be passed to the superclass
        """
        super(HotellingT2TestTime, self).__init__(input_process=input_process, **kwargs)
        self.block_time = set_default_unit(block_time, u.s)
        self.roi_windows = roi_windows
        self.weight_data = weight_data
        self.weight_across_epochs = weight_across_epochs
        self.block_size = block_size

    def transform_data(self):
        data = self.input_node.data.copy()
        # remove mean
        data = data - np.mean(data, axis=0)
        # compute average and extract weights
        _w_average = et_mean(
            epochs=data,
            block_size=self.block_size,
            samples_distance=1,
            weighted=self.weight_data,
            weight_across_epochs=self.weight_across_epochs,
            fs=self.input_node.fs,
        )
        weights = _w_average.weights
        if weights is None:
            weights = np.ones(data.shape)
        h_tests = []
        for _roi_idx, _roi in enumerate(self.roi_windows):
            _samples = _roi.get_roi_samples(data_node=self.input_node)
            _ini, _end = _samples[0], _samples[-1]
            _chunk_size = _samples.size
            block_size = np.ones(
                data.shape[1],
            ) * int(self.block_time * self.input_node.fs)
            block_size = np.minimum(block_size, _chunk_size).astype(int)

            for _ch in tqdm(range(data.shape[1]), desc="Hotelling-T2"):
                n_blocks = np.maximum(
                    1, np.floor(_chunk_size / block_size[_ch]).astype(int)
                )
                # compute features (mean) within ROI
                data = data - np.mean(data[_samples, ...], axis=0)
                samples = (np.array(
                    [np.mean(data[_ini + _i * block_size[_ch]: _ini + (_i + 1) * block_size[_ch], _ch, ...], axis=0,
                             keepdims=True) for _i in range(n_blocks)]) * data.unit)
                _mean_w = (np.array(
                    [np.mean(weights[_ini + _i * block_size[_ch]: _ini + (_i + 1) * block_size[_ch], _ch, ...], axis=0,
                             keepdims=True) for _i in range(n_blocks)]) * data.unit)
                _roi_h_tests = hotelling_t_square_test(
                    samples,
                    dof_within_epochs=n_blocks,
                    dof_across_epochs=_w_average.dof_across_epochs[_ch],
                    ini_time=_roi.ini_time,
                    end_time=_roi.end_time,
                    window_label=_roi.window_label,
                    weights=_mean_w,
                )
                _roi_h_tests.ini_time = self.input_node.x[_ini]
                _roi_h_tests.end_time = self.input_node.x[_end]
                channels = self.input_node.layout
                if channels is not None:
                    _channel = channels[_ch].label
                else:
                    _channel = str(_ch)
                _roi_h_tests.channel = _channel
                _roi_h_tests.domain = Domain.time
                h_tests = h_tests + [_roi_h_tests]

            _stats = pd.DataFrame([_ht.__dict__ for _ht in h_tests])
        self.output_node.statistical_tests = Tables(
            table_name=TestType.hotelling_t2, data=_stats, data_source=self.name
        )


class HotellingT2TestFreq(InputOutputProcess):
    def __init__(
            self,
            input_process=InputOutputProcess,
            test_frequencies: u.Quantity = None,
            freq_ini: u.Quantity = None,
            freq_end: u.Quantity = None,
            pool_frequencies: bool = True,
            roi_windows: np.array([TimeROI]) = np.array([TimeROI()]),
            alpha_level: int = 0.05,
            n_fft: int = None,
            power_line_removal: bool = False,
            power_line_frequency: u.Quantity = 50 * u.Hz,
            power_line_delta_freq: u.Quantity = 0 * u.Hz,
            diagonal_covariance: bool = False,
            **kwargs,
    ) -> InputOutputProcess:
        """
        This class computes the statistical significance of a region of interest in the  frequency-domain using the
        Hotelling T2 test.
        The results are put into a pandas table with the statistics for each channel (f-value, degrees of freedom,
         p_values, etc). See HotellingTSquareTest
        :param input_process: InputOutputProcess Class
        :param test_frequencies: an array with frequencies to be tested
        :param freq_ini: the initial frequency of a range to be tested (in this case, the target_frequencies will be
        estimated from the range between freq_ini and freq_end)
        :param pool_frequencies: if True, HT2 test is based on the statistical significance obtained by pooling all
        frequencies as explanatory, otherwise, the HT2 test is applied individually to each freuqency.
        :param freq_end: the end frequency of the range of frequencies to be tested
        :param roi_windows: array with region of interest windows where the response will be evaluated. The test will be
        applied on each window
        :param alpha_level: float indicating the level for statistical significance
        :param n_fft: integer indicating the number of points for the FFT
        :param power_line_removal: if True, frequency components matching powerline base frequency and harmonics will be
        removed from the analysis
        :param power_line_frequency: frequency of local power line frequency. This will be used to prevent using
        this frequency or its multiples when performing the FTest
        :param power_line_delta_freq: Tolerance to consider a frequency as powerline multiple. For example, if 1 Hz,
        then any multiple of a 50 Hz within 49 Hz to 51 Hz will be considered a power line multiple
        :param diagonal_covariance: if True, the covariance matrix will be assumed to be zero outside the diagonal.
        Chesnaye et al. 10.1177/23312165231154035
        :param kwargs: extra parameters to be passed to the superclass
        """
        super(HotellingT2TestFreq, self).__init__(input_process=input_process, **kwargs)
        self.test_frequencies = set_default_unit(test_frequencies, u.Hz)
        self.freq_ini = set_default_unit(freq_ini, u.Hz)
        self.freq_end = set_default_unit(freq_end, u.Hz)
        self.pool_frequencies = pool_frequencies
        self.roi_windows = roi_windows
        self.alpha_level = alpha_level
        self.n_fft = n_fft
        self.power_line_removal = power_line_removal
        self.power_line_frequency = power_line_frequency
        self.power_line_delta_freq = power_line_delta_freq
        self.fft_frequencies = None
        self.diagonal_covariance = diagonal_covariance

    def transform_data(self):
        if self.test_frequencies is not None:
            self.test_frequencies = np.unique(self.test_frequencies)
            if np.any(self.test_frequencies >= self.input_node.fs / 2):
                frequencies_to_remove = self.test_frequencies[
                    self.test_frequencies >= self.input_node.fs / 2
                    ]
                print(
                    "Removing frequencies {:} >= Nyquest frequency {:}".format(
                        frequencies_to_remove, self.input_node.fs / 2)
                )
                self.test_frequencies = self.test_frequencies[
                    self.test_frequencies < self.input_node.fs / 2
                    ]
            assert self.freq_ini is None and self.freq_end is None
        if self.freq_ini is not None or self.freq_end is not None:
            assert self.test_frequencies is None
        data = self.input_node.data
        # remove mean
        data = data - np.mean(data, axis=0)
        h_tests = []
        for _roi_idx, _roi in enumerate(self.roi_windows):
            _samples = _roi.get_roi_samples(data_node=self.input_node)
            _ini, _end = _samples[0], _samples[-1]
            n_fft = self.n_fft
            if self.n_fft is None:
                n_fft = _samples.size

            fft = pyfftw.builders.rfft(
                data[_samples, ...],
                overwrite_input=False,
                planner_effort="FFTW_ESTIMATE",
                axis=0,
                threads=1,
                n=n_fft,
            )
            w_fft = fft() * self.input_node.data.unit
            w_fft /= self.input_node.data.shape[0] / 2
            self.fft_frequencies = (
                    np.arange(w_fft.shape[0]) * self.input_node.fs / n_fft
            )
            if self.test_frequencies is not None:
                freq_idx = self.freq_to_samples(self.test_frequencies)
            else:
                _ini_f = self.freq_to_samples(self.freq_ini)
                _end_f = self.freq_to_samples(self.freq_end)
                freq_idx = np.arange(_ini_f, _end_f + 1).astype(int)
            # remove powerline frequency bins
            if self.power_line_removal:
                # compute power line frequencies
                _power_idx = np.array(
                    [self.freq_to_samples(_power_freq, self.power_line_delta_freq) for _power_freq in
                     self.power_line_frequency * np.arange(1, np.round(
                         0.5 * self.input_node.fs / self.power_line_frequency))],
                    dtype=object,
                )

                freq_idx = np.setdiff1d(freq_idx, _power_idx)
                assert freq_idx.size > 0, (
                    "All frequency bins were removed as they all fit your powerline criteria, "
                    "check criteria or disable powerline"
                )

            freq_samples = w_fft[freq_idx, ...]
            for _ch_idx, _ch in enumerate(self.input_node.layout):
                if self.pool_frequencies:
                    real_samples = np.real(freq_samples)
                    imag_samples = np.imag(freq_samples)
                    h_samples = np.vstack((real_samples, imag_samples))
                    _roi_h_tests = hotelling_t_square_test(
                        h_samples[:, [_ch_idx], :],
                        diagonal_covariance=self.diagonal_covariance,
                        ini_time=_roi.ini_time,
                        end_time=_roi.end_time,
                        window_label=_roi.window_label,
                    )
                    _roi_h_tests.tested_frequencies = str(
                        self.fft_frequencies[freq_idx]
                    )
                    _roi_h_tests.channel = _ch.label
                    _roi_h_tests.domain = Domain.frequency
                    _roi_h_tests.ini_time = self.input_node.samples_to_x([_ini])[0]
                    _roi_h_tests.end_time = self.input_node.samples_to_x([_end])[0]
                    _roi_h_tests.amplitude = np.sum(
                        np.abs(np.mean(freq_samples[:, _ch_idx, :], axis=1)), axis=0
                    )
                    h_tests = h_tests + [_roi_h_tests]
                else:
                    for _i, _fi in enumerate(freq_idx):
                        _f_samples = freq_samples[[_i], ...]
                        real_samples = np.real(_f_samples)
                        imag_samples = np.imag(_f_samples)
                        h_samples = np.vstack((real_samples, imag_samples))
                        _roi_h_tests = hotelling_t_square_test(
                            h_samples[:, [_ch_idx], :],
                            diagonal_covariance=self.diagonal_covariance,
                            ini_time=_roi.ini_time,
                            end_time=_roi.end_time,
                            window_label=_roi.window_label,
                        )
                        _roi_h_tests.tested_frequencies = str(self.fft_frequencies[_fi])
                        _roi_h_tests.channel = _ch.label
                        _roi_h_tests.domain = Domain.frequency
                        _roi_h_tests.ini_time = self.input_node.samples_to_x([_ini])[0]
                        _roi_h_tests.end_time = self.input_node.samples_to_x([_end])[0]
                        _roi_h_tests.amplitude = np.abs(
                            np.mean(_f_samples[:, _ch_idx, :], axis=1)
                        ).squeeze()
                        _roi_h_tests.phase = np.angle(
                            np.mean(_f_samples[:, _ch_idx, :], axis=1)
                        ).squeeze()
                        h_tests = h_tests + [_roi_h_tests]

        _stats = pd.DataFrame([_ht.__dict__ for _ht in h_tests])

        self.output_node.statistical_tests = Tables(
            table_name=TestType.hotelling_t2,
            data=_stats,
            data_source=self.name
        )

    def freq_to_samples(
            self, value: np.array, delta_freq: u.Quantity = np.inf * u.Hz
    ) -> np.array:
        if isinstance(value, float) or value.size == 1:
            value = [value]
        out = np.array([])
        for _v in value:
            _idx = np.argmin(np.abs(self.fft_frequencies - _v))
            _meet_creteria = np.abs(self.fft_frequencies[_idx] - _v) <= delta_freq
            if _meet_creteria:
                out = np.append(out, _idx).astype(int)
        out = np.unique(out)
        return np.atleast_1d(out)
