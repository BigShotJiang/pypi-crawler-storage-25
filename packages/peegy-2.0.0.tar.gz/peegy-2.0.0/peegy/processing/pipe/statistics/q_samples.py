from peegy.processing.pipe.definitions import InputOutputProcess, Domain
from peegy.processing.tools.detection.definitions import TimeROI
from peegy.processing.statistics.definitions import TestType, QSamplesTestResults
from peegy.definitions.tables import Tables
from peegy.tools.units.unit_tools import set_default_unit
from peegy.processing.statistics.eeg_statistic_tools import q_samples_mod_3
import pyfftw
import numpy as np
import pandas as pd
import os
import astropy.units as u
from PyQt5.QtCore import QLibraryInfo
os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = QLibraryInfo.location(QLibraryInfo.PluginsPath)


class QSamplesTest(InputOutputProcess):
    def __init__(self, input_process=InputOutputProcess,
                 test_frequencies: u.Quantity = None,
                 freq_ini: u.Quantity = None,
                 freq_end: u.Quantity = None,
                 roi_windows: np.array(TimeROI) = None,
                 n_fft: int = None,
                 power_line_removal: bool = False,
                 power_line_frequency: u.Quantity = 50 * u.Hz,
                 power_line_delta_freq: u.Quantity = 0 * u.Hz,
                 rankings_per_epoch: bool = False,
                 **kwargs) -> InputOutputProcess:
        """
        This class computes the q-samples statistics of a region of interest in the  frequency-domain using the
        modified non-parametric Q-samples Test. This method ranks both phase and spectral magnitude.
        1. Cebulla M., Sturzebecher E. & Elberling C. 2006. Objective detection of Auditory Steady State Responses:
        Comparison of One-Sample and q-Sample Tests. J. Am. Acad. Audiol. 17, 93103.

        :param input_process: InputOutputProcess Class
        :param test_frequencies: an array with frequencies to be tested
        :param freq_ini: the initial frequency of a range to be tested (in this case, the test_frequencies will be
        estimated from the range between freq_ini and freq_end)
        :param freq_end: the end frequency of the range of frequencies to be tested
        :param roi_windows: array with region of interest windows where the response will be evaluated. The test will be
        applied on each window
        :param n_fft: integer indicating the number of points for the FFT
        :param power_line_removal: if True, frequency components matching powerline base frequency and harmonics will be
        removed from the analysis
        :param power_line_frequency: frequency of local power line frequency. This will be used to prevent using
        this frequency or its multiples when performing the FTest
        :param power_line_delta_freq: Tolerance to consider a frequency as powerline multiple. For example, if 1 Hz,
        then any multiple of a 50 Hz within 49 Hz to 51 Hz will be considered a power line multiple
        :rankings_per_epoch: if True, the rankings are created on an epoch basis, from 1 to the number of frequencies
        :param kwargs: extra parameters to be passed to the superclass
        """
        super(QSamplesTest, self).__init__(input_process=input_process, **kwargs)
        self.test_frequencies = set_default_unit(test_frequencies, u.Hz)
        self.freq_ini = set_default_unit(freq_ini, u.Hz)
        self.freq_end = set_default_unit(freq_end, u.Hz)
        self.roi_windows = roi_windows
        self.n_fft = n_fft
        self.power_line_removal = power_line_removal
        self.power_line_frequency = power_line_frequency
        self.power_line_delta_freq = power_line_delta_freq
        self._fft_frequencies = None
        self.rankings_per_epoch = rankings_per_epoch

    def transform_data(self):
        if self.test_frequencies is not None:
            self.test_frequencies = np.unique(self.test_frequencies)
            if np.any(self.test_frequencies >= self.input_node.fs / 2):
                frequencies_to_remove = self.test_frequencies[
                    self.test_frequencies >= self.input_node.fs / 2
                ]
                print(
                    "Removing frequencies {:} >= Nyquest frequency {:}".format(
                        frequencies_to_remove, self.input_node.fs / 2)
                )
                self.test_frequencies = self.test_frequencies[
                    self.test_frequencies < self.input_node.fs / 2
                ]
            assert self.freq_ini is None and self.freq_end is None
        if self.freq_ini is not None or self.freq_end is not None:
            assert self.test_frequencies is None

        data = self.input_node.data.copy()
        q_tests = []
        if self.roi_windows is None:
            self.roi_windows = np.array([TimeROI(ini_time=self.input_node.x[0],
                                                 end_time=np.inf * u.s,
                                                 window_label='')])

        for _roi_idx, _roi in enumerate(self.roi_windows):
            _samples = _roi.get_roi_samples(data_node=self.input_node)
            _ini, _end = _samples[0], _samples[-1]
            n_fft = self.n_fft
            if self.n_fft is None:
                n_fft = _samples.size
            # remove mean
            _data = data[_samples, ...]
            _data = _data - np.mean(_data, axis=0)
            fft = pyfftw.builders.rfft(_data,
                                       overwrite_input=False,
                                       planner_effort='FFTW_ESTIMATE',
                                       axis=0,
                                       threads=1,
                                       n=n_fft)
            w_fft = fft() * data.unit
            w_fft /= data.shape[0] / 2
            self._fft_frequencies = np.arange(w_fft.shape[0]) * self.input_node.fs / n_fft

            if self.test_frequencies is not None:
                freq_idx = self.freq_to_samples(self.test_frequencies)
            else:
                _ini_f = self.freq_to_samples(self.freq_ini)
                _end_f = self.freq_to_samples(self.freq_end)
                freq_idx = np.arange(_ini_f, _end_f + 1).astype(int)
            # remove powerline frequency bins
            if self.power_line_removal:
                # compute power line frequencies
                _power_idx = np.array(
                    [self.freq_to_samples(_power_freq, self.power_line_delta_freq) for _power_freq in
                     self.power_line_frequency * np.arange(
                         1,
                         np.round(0.5 * self.input_node.fs / self.power_line_frequency))],
                    dtype=object)

                freq_idx = np.setdiff1d(freq_idx, _power_idx)
                assert freq_idx.size > 0, 'All frequency bins were removed as they all fit your powerline criteria, ' \
                                          'check criteria or disable powerline'
            freq_idx = np.unique(freq_idx)
            q = q_samples_mod_3(fft_input=w_fft,
                                idx=freq_idx,
                                rankings_per_epoch=self.rankings_per_epoch)

            channels = self.input_node.layout
            for _ch, _q in zip(channels, q):
                _q_test = QSamplesTestResults(channel=_ch.label,
                                              test_name=TestType.q_samples_test,
                                              q=_q,
                                              ini_time=self.input_node.samples_to_x([_ini])[0],
                                              end_time=self.input_node.samples_to_x([_end])[0],
                                              n_epochs=data.shape[2],
                                              window_label=_roi.window_label,
                                              domain=Domain.frequency,
                                              tested_frequencies=str(self._fft_frequencies[freq_idx])
                                              )
                q_tests.append(_q_test)
        _stats = pd.DataFrame([_qt.__dict__ for _qt in q_tests])
        self.output_node.statistical_tests = Tables(table_name=TestType.q_samples_test,
                                                    data=_stats,
                                                    data_source=self.name)

    def freq_to_samples(self,
                        value: np.array,
                        delta_freq: u.Quantity = np.inf * u.Hz) -> np.array:
        if isinstance(value, float) or value.size == 1:
            value = [value]
        out = np.array([])
        for _v in value:
            _idx = np.argmin(np.abs(self._fft_frequencies - _v))
            _meet_creteria = np.abs(self._fft_frequencies[_idx] - delta_freq) <= delta_freq
            if _meet_creteria:
                out = np.append(out, _idx).astype(int)
        out = np.unique(out)
        return np.squeeze(out)
