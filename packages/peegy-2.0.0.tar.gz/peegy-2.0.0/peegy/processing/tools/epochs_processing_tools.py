import numpy as np
from peegy.processing.pipe.definitions import DataNode
from peegy.processing.tools.detection.definitions import TimeROI
from peegy.processing.tools import eeg_epoch_operators as eo
from peegy.definitions.channel_definitions import Domain
import peegy.processing.tools.filters.eegFiltering as eegf
from peegy.processing.tools.multiprocessing.multiprocessesing_filter import filt_data
from peegy.processing.tools.filters.eog_tools.tools import (
    generate_eog_template,
    reconstruct_eog,
)
from peegy.processing.statistics.eeg_statistic_tools import (
    dof_from_psd,
    effective_sampling_size,
)
from sklearn import linear_model
import matplotlib.pyplot as plt
import peegy.processing.tools.filters.spatial_filtering.spatial_filtering as sf
from peegy.processing.tools.epochs_frequency_processing_tools import (
    get_pooled_frequency_weights, et_get_fft_settings
)
from peegy.tools.units.unit_tools import set_default_unit
import pyfftw
from scipy import signal
from sklearn.linear_model import LinearRegression
import astropy.units as u
from tqdm import tqdm
from peegy.processing.pipe.definitions import InputOutputProcess


__author__ = "jaime undurraga"


class AverageOutput(InputOutputProcess):
    def __init__(
            self,
            average: np.array = None,  # array with the average (samples x channel)
            weights: np.array = None,  # array with the weights (samples x channel)
            snr: np.array = None,  # array with SNR (n channels)
            rn: np.array = None,  # array with RN (n channels)
            noise: np.array = None,  # array with noise (samples x channel)
            psd_within_epochs: np.array = None,  # PSD within epochs
            dof_within_epochs: np.array = None,  # DOF within epochs
            dof_across_epochs: np.array = None,  # DOF across epochs
            dof_rn: np.array = None,  # DOF of estimated RN
            cumulative_rn: np.array = None,  # cumulative RN
            n_tracked_points: np.array = None,  # number of tracked points per epoch (n channels)
            fft: np.array = None,  # array with the real FFT (samples // 2 x channel)
            n_epochs: int = None,  # number of epochs
            weights_ber_block: np.array = None,
            n_blocks: np.array = None,
            n_epochs_per_block: np.array = None,
            domain: Domain = Domain.time,
            frequencies: np.array(u.Quantity) = None,
            fs: u.Quantity = None,
    ):
        super(AverageOutput, self).__init__()
        self.average = average
        self.weights = weights
        self.snr = snr
        self.rn = rn
        self.noise = noise
        self.psd_within_epochs = psd_within_epochs
        self.dof_within_epochs = dof_within_epochs
        self.dof_across_epochs = dof_across_epochs
        self.dof_rn = dof_rn
        self.cumulative_rn = cumulative_rn
        self.fft = fft
        self.weights_ber_block = weights_ber_block  # calculated weights for each block
        self.n_blocks = n_blocks  # number of epochs per plock
        self.n_epochs_per_block = n_epochs_per_block
        self.n_tracked_points = n_tracked_points
        self.n_epochs = n_epochs
        self.domain = domain
        self.frequencies = frequencies
        self.fs = fs

    def set_average(self, value: np.array([u.Quantity]) = None):
        if value is not None:
            self._average = DataNode(fs=self.fs,
                                     domain=self.domain,
                                     data=value)
            self._average.rn = self.rn

    def get_average(self):
        return self._average

    average = property(get_average, set_average)


def et_get_epoch_weights_and_rn_weighted_average(
        epochs: np.array = np.array([]),
        block_size: int = 5,
        samples_distance: int = 10,
        dof_epochs_spectral=True,
        demean_epochs: bool = True,
        weighted: bool = True,
        n_jobs: int = 1,
        rn_window: np.array = None,
        fs: u.Quantity = None
):
    """
    This function computes the weights and residual noise for weighted averaging.
    :param epochs: samples x channels x trials numpy array
    :param block_size: number of trials used to estimate noise and weights
    :param samples_distance: separation between samples to estimate noise and weights
    :param demean_epochs: if True, individual epochs will be demeaned
    :param dof_epochs_spectral: if true, degrees of freedom across epochs are estimated in the frequency domain
    :param weighted: if true, weights are estimated from the variance of the signal
    :param n_jobs: number of CPUs to compute FFT
    :param demean_epochs: if True, individual epochs will be demeaned
    :param rn_window: [initial_sample, end_sample] range used to estimate the residual noise
    :return: weights, residual noise, cumulative residual noise over trials,
    array with number of sources per noise source

    """
    # compute weights for averaging and residual noise estimation
    if rn_window is None:
        ini_sample_rn = 0
        end_sample_rn = epochs.shape[0] - 1
    else:
        ini_sample_rn, end_sample_rn = rn_window
        end_sample_rn = np.minimum(epochs.shape[0] - 1, end_sample_rn)
    if demean_epochs:
        epochs = epochs - np.mean(epochs, 0)
        # data_variance = data_variance - np.mean(data_variance, 0)
    data_variance = epochs[ini_sample_rn:end_sample_rn + 1, ...]
    data_variance = data_variance - np.mean(data_variance, axis=0)

    block_size = np.minimum(data_variance.shape[2], block_size)
    blocks = np.arange(0, data_variance.shape[2] + 1, block_size).astype(int)
    _data_variance = data_variance[
                     np.arange(0, data_variance.shape[0], samples_distance), :, :
                     ]
    blocks[-1] = np.maximum(blocks[-1], _data_variance.shape[2])
    unfolded_epochs = eo.et_unfold(
        np.transpose(_data_variance, [0, 2, 1]), orthogonal=True
    )
    var = np.var(unfolded_epochs[:, blocks[0]: blocks[1]], axis=1, ddof=1)
    # var2 = np.expand_dims(np.mean(np.var(_epochs[:, :, blocks[0]: blocks[1]], ddof=1, axis=2), axis=0), axis=1)
    nb = np.diff(blocks)
    for i in range(1, len(blocks) - 1):
        var = np.vstack(
            (var, np.var(unfolded_epochs[:, blocks[i]: blocks[i + 1]], axis=1, ddof=1))
        )
    var = var[None, :]
    folded_var = eo.et_fold(var.T, _data_variance.shape[1])
    block_var = np.mean(folded_var, axis=2)
    if weighted:
        wb = 1.0 / block_var
    else:
        wb = 1.0 / np.mean(block_var, axis=1, keepdims=True) * np.ones(block_var.shape)
    if np.all(wb == np.inf):
        wb[:] = 1 * wb[:].unit

    w = np.ones((_data_variance.shape[1], nb[0])) * np.expand_dims(wb[:, 0], 1)
    expanded_var = np.ones((epochs.shape[1], nb[0])) * np.expand_dims(
        block_var[:, 0], 1
    )
    for i, n in enumerate(nb[1:]):
        w = np.concatenate((w, np.ones(n) * np.expand_dims(wb[:, i + 1], 1)), axis=1)
        expanded_var = np.concatenate(
            (expanded_var, np.ones(n) * np.expand_dims(block_var[:, i + 1], 1)), axis=1
        )

    ess = effective_sampling_size(w, axis=1)
    if dof_epochs_spectral:
        # estimate noise power spectral density across epochs to obtain smooth representation.
        _mean_across_epochs = eo.w_mean(epochs, w)
        data_noise = epochs - _mean_across_epochs[:, :, None]
        # demean within epoch
        data_noise = data_noise - np.mean(data_noise, axis=0)

        # DOF across epochs estimated from the spectrum but scaling by effective number of DOF estimated from the
        # weights
        fft_within_across_epoch = pyfftw.builders.rfft(
            data_noise * w,
            overwrite_input=False,
            planner_effort="FFTW_ESTIMATE",
            axis=2,
            threads=n_jobs,
            )

        psd_noise_across_epoch = eo.w_mean(
            np.abs(fft_within_across_epoch()) ** 2.0, axis=0
        )
        dof_across_epochs = dof_from_psd(
            psd_noise=psd_noise_across_epoch.T,
            dof_factor=epochs.shape[2] / ess,
            psd_noise_n=epochs.shape[2],
        )
    else:
        dof_across_epochs = ess

    # rn = np.sqrt(1.0 / np.sum(w, axis=1))
    # residual noise is adjusted taking into account the effective sample size
    # rn = np.sqrt(1 / np.sum(w, axis=1))
    # correct for for bias.
    # weighted_covariance = np.sum(((nb * wb) ** 2)[:, :, np.newaxis] * var,
    #                              axis=1) / np.sum(((nb * wb)[:, :, np.newaxis] ** 2), axis=1)
    # rn = np.sqrt(np.mean(weighted_covariance.T / dof_across_epochs, axis=0))
    rn = np.sqrt((dof_across_epochs / ess) / np.sum(w, axis=1))
    # print('diff in estimation {:}'.format(np.sqrt((dof_across_epochs / ess) / np.sum(w, axis=1)) - rn))
    cumulative_rn = None
    for _i in range(w.shape[1]):
        if weighted:
            if _i == 0:
                cumulative_rn = np.sqrt(1.0 / np.sum(w[:, 0: _i + 1], axis=1))
            else:
                cumulative_rn = np.vstack(
                    (cumulative_rn, np.sqrt(1.0 / np.sum(w[:, 0: _i + 1], axis=1)))
                )
        else:
            if _i == 0:
                cumulative_rn = np.sqrt(
                    np.sum(expanded_var[:, 0: _i + 1] / (_i + 1) ** 2, axis=1)
                )
            else:
                cumulative_rn = np.vstack(
                    (
                        cumulative_rn,
                        np.sqrt(
                            np.sum(expanded_var[:, 0: _i + 1] / (_i + 1) ** 2, axis=1)
                        ),
                    )
                )

    n_total = np.sum(nb)
    n_tracked_points = _data_variance.shape[0]
    out = AverageOutput(
        weights=w,
        rn=rn,
        cumulative_rn=cumulative_rn,
        n_epochs=n_total,
        weights_ber_block=wb,
        n_blocks=wb.shape[0],
        n_tracked_points=n_tracked_points,
        dof_across_epochs=dof_across_epochs,
        n_epochs_per_block=nb,
        fs=fs
    )
    return out


def et_get_epoch_weights_and_rn_weighted_average_within_epoch(
        epochs: np.array = np.array([]),
        dof_epochs_spectral=True,
        demean_epochs: bool = True,
        freq_ini: u.Quantity = None,
        freq_end: u.Quantity = None,
        fs: u.Quantity = None,
        block_size: int = 1,
        weighted: bool = True,
        demeaned_noise: bool = True,
        rn_window: np.array = None,
        rn_domain: Domain = Domain.time,
):
    """
    This function computes the weights and residual noise for weighted averaging by estimating the weights within each
    epoch. This is useful for long epochs (cortical responses) as artefacts, such as eye blinks, can be captured by the
    variance within epochs.
    :param epochs: samples x channels x trials numpy array
    :param demean_epochs: if True, individual epochs will be demeaned
    :param dof_epochs_spectral: if true, degrees of freedom across epochs are estimated in the frequency domain
    :param demean_epochs: if True, individual epochs will be demeaned
    :param freq_ini: starting frequency to compute energy of F test
    :param freq_end: ending frequency to compute energy of F test
    :param fs: sampling frequency
    :param block_size: integer indicating how many epochs will be averaged to smooth the weights
    :param weighted: if true, weights are estimated from the variance of the signal
    :param demeaned_noise: if True, the mean across epochs will be removed from the individual epochs
    :param rn_window: [initial_sample, end_sample] range used to estimate the residual noise
    :param rn_domain: the Domain in which the power of the noise will be estimated
    :return: weights, residual noise, cumulative residual noise over trials,
    array with number of sources per noise source

    """
    if rn_window is None:
        ini_sample_rn = 0
        end_sample_rn = epochs.shape[0] - 1
    else:
        ini_sample_rn, end_sample_rn = rn_window
    data_variance = epochs[ini_sample_rn: end_sample_rn + 1, ...]

    if demean_epochs:
        data_variance = data_variance - np.mean(data_variance, 0)

    block_size = np.minimum(data_variance.shape[2], block_size)
    blocks = np.arange(0, data_variance.shape[2] + 1, block_size).astype(int)
    blocks[-1] = np.maximum(blocks[-1], data_variance.shape[2])
    noise_estimate = data_variance.copy()
    if demeaned_noise:
        noise_estimate = noise_estimate - np.mean(noise_estimate, axis=2, keepdims=True)
    # compute weights for averaging and residual noise estimation
    if (rn_domain == Domain.frequency and
            ((freq_ini is not None) or (freq_end is not None))):
        assert fs is not None
        # this is just to get the fft settings
        n, n_rfft, frequencies, freq_indexes = et_get_fft_settings(
            n_samples=noise_estimate.shape[0],
            fs=fs,
        )
        # compute power in the frequency domain
        _, _, frequencies, freq_indexes = et_get_fft_settings(
            frequencies=None,
            freq_ini=freq_ini,
            freq_end=freq_end,
            n_samples=noise_estimate.shape[0],
            fs=fs,
        )
        scaling_factor = np.maximum(n, noise_estimate.shape[0]) / (
                noise_estimate.shape[0] - 1
        )

        _y_fft = pyfftw.builders.rfft(
            noise_estimate,
            n=n,
            overwrite_input=False,
            planner_effort="FFTW_ESTIMATE",
            axis=0,
            threads=1,
        )
        _psd = np.abs(_y_fft()) ** 2.0

        psd = scaling_factor * 1 / (n ** 2) * 2 * _psd
        var = np.sum(psd[freq_indexes, ...], axis=0) * noise_estimate.unit ** 2
    else:
        var = np.var(noise_estimate, ddof=1, axis=0, keepdims=False)

    b_var = np.zeros((noise_estimate.shape[1], len(blocks) - 1)) * var.unit
    block_var = np.zeros((noise_estimate.shape[1], len(blocks) - 1)) * var.unit
    for _idx in range(len(blocks) - 1):
        block_var[:, _idx] = np.mean(var[:, blocks[_idx]: blocks[_idx + 1]], axis=1)
        if weighted:
            b_var[:, _idx] = block_var[:, _idx]
        else:
            b_var[:, _idx] = np.mean(var, axis=1)

    wb = 1 / b_var
    nb = np.diff(blocks)
    w = np.ones((noise_estimate.shape[1], nb[0])) * np.expand_dims(wb[:, 0], 1)
    expanded_var = np.ones((noise_estimate.shape[1], nb[0])) * np.expand_dims(
        block_var[:, 0], 1)

    for i, n in enumerate(nb[1:]):
        w = np.concatenate((w, np.ones(n) * np.expand_dims(wb[:, i + 1], 1)), axis=1)
        expanded_var = np.concatenate(
            (expanded_var, np.ones(n) * np.expand_dims(block_var[:, i + 1], 1)), axis=1
        )

    # estimate noise power spectral density across epochs to obtain smooth representation.
    _mean_across_epochs = eo.w_mean(epochs, w)
    ess = effective_sampling_size(w, axis=1)
    if dof_epochs_spectral:
        # remove potential coherence average signal from individual epochs
        data_noise = epochs - _mean_across_epochs[:, :, None]
        # demean within epoch; this is very important, otherwise DC noise will bias the estimation
        data_noise = data_noise - np.mean(data_noise, axis=0)

        # DOF across epochs estimated from the spectrum but scaling by effective number of DOF estimated from the
        # weights
        fft_within_across_epoch = pyfftw.builders.rfft(
            data_noise * w,
            overwrite_input=False,
            planner_effort="FFTW_ESTIMATE",
            axis=2,
            threads=1,
            )

        psd_noise_across_epoch = eo.w_mean(
            np.abs(fft_within_across_epoch()) ** 2.0, axis=0
        )
        dof_across_epochs = dof_from_psd(
            psd_noise=psd_noise_across_epoch.T,
            dof_factor=epochs.shape[2] / ess,
            psd_noise_n=epochs.shape[2],
        )
    else:
        dof_across_epochs = ess

    # rn = np.sqrt(1.0 / np.sum(w, axis=1))
    # residual noise is adjusted taking into account the effective sample size
    # rn = np.sqrt(1 / np.sum(w, axis=1))
    # weighted_covariance = np.sum(w * var, axis=1) / np.sum(w ** 2, axis=1)
    # rn = np.sqrt(np.mean(weighted_covariance / dof_across_epochs))
    rn = np.sqrt((dof_across_epochs / ess) / np.sum(w, axis=1))
    cumulative_rn = None
    for _i in range(w.shape[1]):
        if weighted:
            if _i == 0:
                cumulative_rn = np.sqrt(1.0 / np.sum(w[:, 0: _i + 1], axis=1))
            else:
                cumulative_rn = np.vstack(
                    (cumulative_rn, np.sqrt(1.0 / np.sum(w[:, 0: _i + 1], axis=1)))
                )
        else:
            if _i == 0:
                cumulative_rn = np.sqrt(
                    np.sum(expanded_var[:, 0: _i + 1] / (_i + 1) ** 2, axis=1)
                )
            else:
                cumulative_rn = np.vstack(
                    (
                        cumulative_rn,
                        np.sqrt(
                            np.sum(expanded_var[:, 0: _i + 1] / (_i + 1) ** 2, axis=1)
                        ),
                    )
                )
    n_tracked_points = data_variance.shape[0]
    out = AverageOutput(
        weights=w,
        rn=rn,
        cumulative_rn=cumulative_rn,
        n_epochs=epochs.shape[2],
        weights_ber_block=1,
        n_blocks=epochs.shape[2],
        n_tracked_points=n_tracked_points,
        dof_across_epochs=dof_across_epochs,
        n_epochs_per_block=1,
        fs=fs
    )
    return out


def et_get_epoch_weights_and_rn_weighted_average_within_epoch_frequency_specific(
        epochs: np.array = np.array([]),
        dof_epochs_spectral=True,
        demean_epochs: bool = True,
        test_frequencies: u.Quantity = None,
        fs: u.Quantity = None,
        block_size: int = 1,
        weighted: bool = True,
        demeaned_noise: bool = False,
        include_test_frequencies_in_noise_estimation: bool = False,
        offset_frequency_noise: u.Quantity = 0 * u.Hz,
        delta_frequency_noise: u.Quantity = 0 * u.Hz,
        rn_window: np.array = None):
    """
    This function computes the weights and residual noise for weighted averaging by estimating the weights within each
    epoch. This is useful for long epochs (cortical responses) as artefacts, such as eye blinks, can be captured by the
    variance within epochs.
    :param epochs: samples x channels x trials numpy array
    :param demean_epochs: if True, individual epochs will be demeaned
    :param dof_epochs_spectral: if true, degrees of freedom across epochs are estimated in the frequency domain
    :param demeaned_noise: if True, the average across epochs will be removed from individual epochs
    :param include_test_frequencies_in_noise_estimation: if True, test frequencies will be used for niose estimation
    :param test_frequencies: array with frequencies to be used. If not None, it will overwrite freq_ini and freq_end
    :param fs: sampling frequency
    :param block_size: integer indicating how many epochs will be averaged to smooth the weights
    :param weighted: if true, weights are estimated from the variance of the signal
    :param delta_frequency_noise: frequency width to estimate residual noise around offset_frequency_noise in the
     frequency domain. Useful for discrete frequency analysis
    :param offset_frequency_noise: frequency offset to estimate residual noise in the frequency domain. Useful for
     discrete frequency analysis
    :return: weights, residual noise, cumulative residual noise over trials,
    array with number of sources per noise source

    """
    assert test_frequencies is not None
    assert fs is not None
    if rn_window is None:
        ini_sample_rn = 0
        end_sample_rn = epochs.shape[0] - 1
    else:
        ini_sample_rn, end_sample_rn = rn_window
    data_variance = epochs[ini_sample_rn: end_sample_rn + 1, ...]

    if demean_epochs:
        data_variance = data_variance - np.mean(data_variance, 0)

    block_size = np.minimum(data_variance.shape[2], block_size)
    blocks = np.arange(0, data_variance.shape[2] + 1, block_size).astype(int)
    blocks[-1] = np.maximum(blocks[-1], data_variance.shape[2])
    noise_estimate = data_variance.copy()
    if demeaned_noise:
        noise_estimate = noise_estimate - np.mean(noise_estimate, axis=2, keepdims=True)
    # compute weights for averaging and residual noise estimation
    # this is just to get the fft settings
    n, n_rfft, _frequencies, freq_indexes = et_get_fft_settings(
        n_samples=noise_estimate.shape[0],
        fs=fs,
    )
    scaling_factor = np.maximum(n, noise_estimate.shape[0]) / (
            noise_estimate.shape[0] - 1
    )

    _y_fft = pyfftw.builders.rfft(
        noise_estimate,
        n=n,
        overwrite_input=False,
        planner_effort="FFTW_ESTIMATE",
        axis=0,
        threads=1,
    )
    _psd = np.abs(_y_fft()) ** 2.0
    psd = scaling_factor * 1 / (n ** 2) * 2 * _psd
    # compute power in the frequency domain
    _noise_center_frequencies = None

    _noise_center_frequencies = test_frequencies + offset_frequency_noise
    _partial_psd = np.zeros((_noise_center_frequencies.shape[0], psd.shape[1], psd.shape[2]))
    used_frequencies = np.array([])
    for _i, _ncf in enumerate(_noise_center_frequencies):
        _f_ini = np.maximum(0 * u.Hz, _ncf - delta_frequency_noise)
        _f_end = np.minimum(_ncf + delta_frequency_noise, fs / 2)
        _, _, frequencies, freq_indexes = et_get_fft_settings(
            freq_ini=_f_ini,
            freq_end=_f_end,
            n_samples=noise_estimate.shape[0],
            fs=fs,
        )
        if not include_test_frequencies_in_noise_estimation:
            _, _, c_frequencies, c_freq_index = et_get_fft_settings(
                frequencies=_noise_center_frequencies,
                n_samples=noise_estimate.shape[0],
                fs=fs,
            )
            freq_indexes = np.setdiff1d(freq_indexes, c_freq_index)
            frequencies = np.setdiff1d(frequencies, c_frequencies)
        _partial_psd[_i, ...] = np.mean(psd[freq_indexes, ...], axis=0)
        used_frequencies = np.concatenate((used_frequencies, frequencies))
    used_frequencies = np.unique(used_frequencies)
    var = np.sum(_partial_psd, axis=0) * (noise_estimate.unit ** 2)

    b_var = np.zeros((noise_estimate.shape[1], len(blocks) - 1)) * var.unit
    block_var = np.zeros((noise_estimate.shape[1], len(blocks) - 1)) * var.unit
    for _idx in range(len(blocks) - 1):
        block_var[:, _idx] = np.mean(var[:, blocks[_idx]: blocks[_idx + 1]], axis=1)
        if weighted:
            b_var[:, _idx] = block_var[:, _idx]
        else:
            b_var[:, _idx] = np.mean(var, axis=1)

    wb = 1 / b_var
    nb = np.diff(blocks)
    w = np.ones((noise_estimate.shape[1], nb[0])) * np.expand_dims(wb[:, 0], 1)
    expanded_var = np.ones((noise_estimate.shape[1], nb[0])) * np.expand_dims(
        block_var[:, 0], 1
    )

    for i, n in enumerate(nb[1:]):
        w = np.concatenate((w, np.ones(n) * np.expand_dims(wb[:, i + 1], 1)), axis=1)
        expanded_var = np.concatenate(
            (expanded_var, np.ones(n) * np.expand_dims(block_var[:, i + 1], 1)), axis=1
        )

    # estimate noise power spectral density across epochs to obtain smooth representation.
    _mean_across_epochs = eo.w_mean(epochs, w)
    ess = effective_sampling_size(w, axis=1)
    if dof_epochs_spectral:
        # remove potential coherence average signal from individual epochs
        data_noise = epochs - _mean_across_epochs[:, :, None]
        # demean within epoch; this is very important, otherwise DC noise will bias the estimation
        data_noise = data_noise - np.mean(data_noise, axis=0)

        # DOF across epochs estimated from the spectrum but scaling by effective number of DOF estimated from the
        # weights
        fft_within_across_epoch = pyfftw.builders.rfft(
            data_noise * w,
            overwrite_input=False,
            planner_effort="FFTW_ESTIMATE",
            axis=2,
            threads=1,
            )

        psd_noise_across_epoch = eo.w_mean(
            np.abs(fft_within_across_epoch()) ** 2.0, axis=0
        )
        dof_across_epochs = dof_from_psd(
            psd_noise=psd_noise_across_epoch.T,
            dof_factor=epochs.shape[2] / ess,
            psd_noise_n=epochs.shape[2],
        )
    else:
        dof_across_epochs = ess

    # rn = np.sqrt(1.0 / np.sum(w, axis=1))
    # residual noise is adjusted taking into account the effective sample size
    # rn = np.sqrt(1 / np.sum(w, axis=1))
    # weighted_covariance = np.sum(w * var, axis=1) / np.sum(w ** 2, axis=1)
    # rn = np.sqrt(np.mean(weighted_covariance / dof_across_epochs))
    rn = np.sqrt((dof_across_epochs / ess) / np.sum(w, axis=1))
    cumulative_rn = None
    for _i in range(w.shape[1]):
        if weighted:
            if _i == 0:
                cumulative_rn = np.sqrt(1.0 / np.sum(w[:, 0: _i + 1], axis=1))
            else:
                cumulative_rn = np.vstack(
                    (cumulative_rn, np.sqrt(1.0 / np.sum(w[:, 0: _i + 1], axis=1)))
                )
        else:
            if _i == 0:
                cumulative_rn = np.sqrt(
                    np.sum(expanded_var[:, 0: _i + 1] / (_i + 1) ** 2, axis=1)
                )
            else:
                cumulative_rn = np.vstack(
                    (
                        cumulative_rn,
                        np.sqrt(
                            np.sum(expanded_var[:, 0: _i + 1] / (_i + 1) ** 2, axis=1)
                        ),
                    )
                )
    n_tracked_points = data_variance.shape[0]
    out = AverageOutput(
        fs=fs,
        weights=w,
        rn=rn,
        cumulative_rn=cumulative_rn,
        n_epochs=epochs.shape[2],
        weights_ber_block=1,
        n_blocks=epochs.shape[2],
        n_tracked_points=n_tracked_points,
        dof_across_epochs=dof_across_epochs,
        n_epochs_per_block=1,
        domain=Domain.time,
        frequencies=used_frequencies
    )
    return out


def et_get_epoch_weights_and_rn_standard_average(
        epochs: np.array = np.array([]),
        block_size: int = 5,
        samples_distance: int = 10,
        dof_epochs_spectral: bool = False,
        demean_epochs: bool = True,
        freq_ini: u.Quantity = None,
        freq_end: u.Quantity = None,
        test_frequencies: u.Quantity = None,
        fs: u.Quantity = None,
        frequency_resolution: u.Quantity = 1 * u.Hz,
):
    """
    This function computes the weights and residual noise for standard averaging.
    :param epochs: samples x channels x trials numpy array
    :param block_size: number of trials used to estimate noise and weights
    :param samples_distance: separation between samples to estimate noise and weights
    :param demean_epochs: if True, individual epochs will be demeaned
    :param dof_epochs_spectral: if true, degrees of freedom across epochs are estimated in the frequency domain
    :param demean_epochs: if True, individual epochs will be demeaned
    :return: weights, residual noise, cumulative residual noise over trials,
    :param freq_ini: starting frequency to compute energy of F test
    :param freq_end: ending frequency to compute energy of F test
    :param test_frequencies: array with frequencies to be used. If not None, it will overwrite freq_ini and freq_end
    :param fs: sampling frequency
    :param frequency_resolution: desired frequency resolution to compute power in frequency domain
    array with number of sources per noise source
    """
    if demean_epochs:
        epochs = epochs - np.mean(epochs, 0)
    # compute weights for averaging an residual noise estimation
    block_size = np.minimum(epochs.shape[2], block_size)
    blocks = np.arange(0, epochs.shape[2] + 1, block_size).astype(int)
    _epochs = epochs[np.arange(0, epochs.shape[0], samples_distance), :, :]
    blocks[-1] = np.maximum(blocks[-1], _epochs.shape[2])
    unfolded_epochs = eo.et_unfold(np.transpose(_epochs, [0, 2, 1]), orthogonal=True)
    var = np.var(unfolded_epochs[:, blocks[0]: blocks[1]], axis=1, ddof=1)[None, :]
    for i in range(1, len(blocks) - 1):
        var = np.vstack(
            (var, np.var(unfolded_epochs[:, blocks[i]: blocks[i + 1]], axis=1, ddof=1))
        )
    # nb_var = np.mean(eo.et_fold(var.T, _epochs.shape[1]), axis=2)
    wb = np.ones((_epochs.shape[1], var.shape[0]))
    nk = np.diff(blocks)
    w = (
            np.ones((_epochs.shape[1], nk[0]))
            * np.expand_dims(wb[:, 0], 1)
            * u.dimensionless_unscaled
    )
    for i, n in enumerate(nk[1:]):
        w = np.concatenate((w, np.ones(n) * np.expand_dims(wb[:, i + 1], 1)), axis=1)

    ess = effective_sampling_size(w, axis=1)
    if dof_epochs_spectral:
        # estimate noise power spectral density across epochs to obtain smooth representation.
        _mean_across_epochs = eo.w_mean(epochs * w, axis=2)
        data_noise = epochs - _mean_across_epochs[:, :, None]

        # DOF across epochs estimated from the spectrum but scaling by effective number of weights
        _fft = pyfftw.builders.rfft(
            data_noise * w,
            overwrite_input=False,
            planner_effort="FFTW_ESTIMATE",
            axis=2,
            threads=1,
            )
        psd_noise_across_epoch = eo.w_mean(np.abs(_fft()) ** 2.0, axis=0)
        dof_across_epochs = dof_from_psd(
            psd_noise=psd_noise_across_epoch.T,
            dof_factor=epochs.shape[2] / ess,
            psd_noise_n=epochs.shape[2],
        )
    else:
        dof_across_epochs = ess

    # nk = nk / np.sum(nk)
    # rn = np.sqrt(np.sum(nk * nb_var, axis=1) / (np.sum(nk) ** 2.0))
    rn = np.sqrt(np.mean(np.var(_epochs, axis=2, ddof=1), 0) / dof_across_epochs)
    cumulative_rn = None
    for _i in range(w.shape[1]):
        if _i == 0:
            cumulative_rn = np.sqrt(1.0 / np.sum(w[:, 0: _i + 1], axis=1))
        else:
            cumulative_rn = np.vstack(
                (cumulative_rn, np.sqrt(1.0 / np.sum(w[:, 0: _i + 1], axis=1)))
            )

    n_epochs = np.sum(nk)
    n_tracked_points = _epochs.shape[0]
    out = AverageOutput(
        weights=w,
        rn=rn,
        cumulative_rn=cumulative_rn,
        n_epochs=n_epochs,
        weights_ber_block=wb,
        n_blocks=wb.shape[0],
        n_tracked_points=n_tracked_points,
        dof_across_epochs=dof_across_epochs,
        n_epochs_per_block=nk,
        fs=fs
    )
    return out


def et_mean(
        epochs: np.array = np.array([]),
        block_size: int = 1,
        samples_distance: int = 1,
        weighted: bool = True,
        demean_epochs: bool = True,
        dof_epochs_spectral: bool = False,
        weight_across_epochs: bool = True,
        remove_average_for_dof_estimation: bool = True,
        freq_ini: u.Quantity = None,
        freq_end: u.Quantity = None,
        test_frequencies: u.Quantity = None,
        fs: u.Quantity = None,
        n_jobs: int = 1,
        demeaned_noise: bool = False,
        delta_frequency_noise: u.Quantity = 0 * u.Hz,
        offset_frequency_noise: u.Quantity = 0 * u.Hz,
        rn_window: np.array = None,
        rn_domain: Domain = Domain.time,
        include_test_frequencies_in_noise_estimation: bool = False
):
    """
    Compute the mean of the input epochs
    :param epochs: samples x channels x trials numpy array
    :param block_size: number of trials used to estimate noise and weights
    :param samples_distance: separation between samples to estimate noise and weights
    :param weighted: boolean indicating if weighted average is used
    :param demean_epochs: if True, individual epochs will be demeaned
    :param weight_across_epochs: if True, weights are computed across epochs (as in Elbeling 1984) otherwise weights are
    computed within epoch (1 / variance across time)
    :param remove_average_for_dof_estimation: if True, average will be subtracted from individual epochs before
    computing the PSD
    :param n_jobs: number of CPUs to compute FFT
    :param dof_epochs_spectral: if true, degrees of freedom across epochs are estimated in the
    frequency domain, otherwise the estimation is based on
    :param weight_across_epochs: if True, weights are computed across epochs (as in Elbeling 1984) otherwise weights are
    computed within epoch (1 / variance across time)
    :param demean_epochs: if True, individual epochs will be demeaned
    :param fs: sampling frequency in Hz
    :param freq_ini: start frequency to compute the residual noise in the frequency domain
    :param freq_end: end frequency to compute the residual noise in the frequency domain
    :param test_frequencies: array with frequencies to be used. If not None, it will overwrite freq_ini and freq_end
    :param demeaned_noise: if True, noise estimation will be performed by first subtracting the mean across epochs
    :param delta_frequency_noise: frequency offset to estimate residual noise in the frequency domain. Useful for
        discrete frequency analysis
    :param offset_frequency_noise: frequency width around delta_frequency_noise to estimate residual noise in the
    frequency domain. Useful for discrete frequency analysis
    :param rn_window: [ini_sample, end_sample] pair used to compute the residual noise. If not given the entire epoch is
    used.
    :param rn_domain: specify in which domain the residual noise will be estimated. The default domain is time. For the
    frequency domain it needs freq_ini or freq_end or test_frequencies.
    :param include_test_frequencies_in_noise_estimation: if True, test frequencies will be used for niose estimation
    :return: average data (standard or weighted), weights, residual noise, cumulative residual noise over trials,
    spectrum of final average scaled to time domain amplitudes, array with number of sources per noise source
    """
    epochs = set_default_unit(epochs, u.dimensionless_unscaled)
    data = epochs.copy()
    data = set_default_unit(data, u.dimensionless_unscaled)
    if weight_across_epochs:
        block_size = max(block_size, 2)
        _average = et_get_epoch_weights_and_rn_weighted_average(
            epochs=epochs,
            block_size=block_size,
            samples_distance=samples_distance,
            demean_epochs=demean_epochs,
            dof_epochs_spectral=dof_epochs_spectral,
            weighted=weighted,
            fs=fs,
            rn_window=rn_window,
        )
    elif test_frequencies is None:
        _average = et_get_epoch_weights_and_rn_weighted_average_within_epoch(
            epochs=epochs,
            demean_epochs=demean_epochs,
            block_size=block_size,
            dof_epochs_spectral=dof_epochs_spectral,
            freq_ini=freq_ini,
            freq_end=freq_end,
            fs=fs,
            weighted=weighted,
            demeaned_noise=demeaned_noise,
            rn_window=rn_window,
            rn_domain=rn_domain,
        )
    else:
        _average = et_get_epoch_weights_and_rn_weighted_average_within_epoch_frequency_specific(
            epochs=epochs,
            demean_epochs=demean_epochs,
            block_size=block_size,
            dof_epochs_spectral=dof_epochs_spectral,
            test_frequencies=test_frequencies,
            fs=fs,
            weighted=weighted,
            demeaned_noise=demeaned_noise,
            rn_window=rn_window,
            delta_frequency_noise=delta_frequency_noise,
            offset_frequency_noise=offset_frequency_noise,
            include_test_frequencies_in_noise_estimation=include_test_frequencies_in_noise_estimation,
        )

    _average.weights = np.tile(_average.weights, (data.shape[0], 1, 1))
    ini_mean = 0
    end_mean = data.shape[0] - 1
    # if rn_window is not None:
    #     ini_mean, end_mean = rn_window
    data = data - np.mean(data[ini_mean: end_mean + 1, ...], axis=0)
    w_ave = eo.w_mean(data, _average.weights)
    if rn_window is None:
        ini_sample_rn = 0
        end_sample_rn = data.shape[0] - 1
    else:
        ini_sample_rn, end_sample_rn = rn_window

    data_noise = data[ini_sample_rn: end_sample_rn + 1, ...]
    if remove_average_for_dof_estimation:
        # remove potential coherence average signal from individual epochs
        data_noise = data - w_ave[:, :, None]

    # demean noise within epoch; this is very important, otherwise DC noise will bias the estimation
    data_noise = data_noise - np.mean(data_noise, axis=0)
    # estimate noise power spectral density across epochs to obtain smooth representation.
    # if frequencies is not None:
    noise_frequencies = None
    if test_frequencies is not None:
        noise_frequencies = test_frequencies + offset_frequency_noise

    if not weight_across_epochs and freq_ini is None:
        freq_ini = 1 / (_average.n_tracked_points / fs)
    n, n_rfft, frequencies, freq_indexes = et_get_fft_settings(
        frequencies=noise_frequencies,
        freq_ini=freq_ini,
        freq_end=freq_end,
        n_samples=data_noise.shape[0],
        fs=fs,
    )

    fft_within_epoch = pyfftw.builders.rfft(
        data_noise,
        n=n,
        overwrite_input=False,
        planner_effort="FFTW_ESTIMATE",
        axis=0,
        threads=n_jobs,
    )
    _fft = fft_within_epoch()
    _psd_epochs = 1 / (data_noise.shape[0] ** 2) * 2 * np.abs(_fft) ** 2 * data_noise.unit
    psd_noise_within_epoch = eo.w_mean(_psd_epochs,
                                       _average.weights[0, :, :])
    # remove DC component of DOF
    if np.any(frequencies == 0):
        freq_indexes = freq_indexes[frequencies != 0]
    dof_within_epochs = dof_from_psd(
        psd_noise=psd_noise_within_epoch,
        dof_factor=(n / data_noise.shape[0]),
        psd_noise_n=n,
        freq_indexes=freq_indexes)

    if _average.domain == Domain.time and rn_domain == Domain.time:
        # compute residual noise DOF considering the number of points tracked and the number of independent
        # DOF in the data the minimum dof is set to 1
        dof_n_tracked_samples = (
                                        _average.n_tracked_points / data_noise.shape[0]
                                ) * dof_within_epochs
        rn_dof = _average.dof_across_epochs * np.maximum(1, dof_n_tracked_samples)
    else:
        n, _, rn_frequencies, rn_freq_indexes = et_get_fft_settings(
            frequencies=_average.frequencies,
            n_samples=data_noise.shape[0],
            fs=fs,
        )
        dof_bn = dof_from_psd(
            psd_noise=psd_noise_within_epoch,
            dof_factor=(n / data_noise.shape[0]),
            psd_noise_n=n,
            freq_indexes=rn_freq_indexes)
        rn_dof = _average.dof_across_epochs * np.maximum(1, dof_bn)

    # estimate residual noise waveform using the same weights as with the original epochs
    data[:, :, 0:-1:2] = -data[:, :, 0:-1:2]
    w_noise = eo.w_mean(data, _average.weights)
    # inverting every second epoch so that average cancels out biological signal

    fft = pyfftw.builders.rfft(
        w_ave,
        overwrite_input=False,
        planner_effort="FFTW_ESTIMATE",
        axis=0,
        threads=n_jobs,
    )
    scaling_factor = 2 / data.shape[0] * data.unit
    w_fft = fft() * scaling_factor
    # estimate snr across entire waveform
    snr = np.maximum(np.var(w_ave, ddof=1, axis=0) / _average.rn**2.0 - 1, 0)
    _average.average = w_ave
    _average.snr = snr
    _average.noise = w_noise
    _average.fft = w_fft
    _average.dof_rn = rn_dof
    _average.psd_within_epochs = psd_noise_within_epoch
    _average.dof_within_epochs = dof_within_epochs

    return _average


def et_snr_in_rois(data_node: DataNode = None,
                   roi_windows: np.array([TimeROI]) = np.array([TimeROI()]),
                   freq_ini: u.Quantity = None,
                   freq_end: u.Quantity = None,
                   test_frequencies: u.Quantity = None,
                   frequency_resolution: u.Quantity = None,
                   # rn_correction: u.Quantity = 0,
                   ):
    """
    Estimate the SNR within time regions of interests. If no frequencies are passed, the variance of the signal is
    estimated in the time domain. Otherwise, estimations are derived from the frequency-domain (FFT filtering-like)
    :param data_node: input data_node
    :param roi_windows: numpy array of [[initial_sample, end_sample], ...]
    :param rn: numpy array with estimated residual noise
    :param freq_ini: initial frequency to estimate the variance of the signal in the frequency domain
    :param freq_end: ending frequency to estimate the variance of the signal in the frequency domain
    :param test_frequencies: array with frequencies to be used. If not None, it will overwrite freq_ini and freq_end
    :param frequency_resolution: desired frequency resolution to compute power in frequency domain. This is only safe
    when asking for a higher resolution (equivalent to zero padding)
    :param rn_correction: vector with additive residual noise correction. This is used to account for biases when
    subtracting or adding average waveforms from individual epochs. The subtraction of an average waveform will
    add the noise which and this needs to be taken into account to prevent false positives.
    :return: SNR, VAR, F-value
    """
    data_in_windows = get_in_window_data(data_node=data_node, roi_windows=roi_windows)
    data = data_node.data
    # data_mean = np.mean(data, axis=0, keepdims=True)
    rn = data_node.rn

    if rn is None:
        rn = [np.array([])]
    final_snr = np.zeros((data.shape[1], len(data_in_windows)))
    final_s_var = np.zeros((data.shape[1], len(data_in_windows))) * data.unit ** 2.0
    f_value = np.zeros((data.shape[1], len(data_in_windows)))
    snr = np.zeros((data.shape[1]))
    phase = np.full((data.shape[1], len(data_in_windows)), fill_value=None)
    for _i, _data in enumerate(data_in_windows):
        frequencies = None
        if (
                (freq_ini is not None)
                or (freq_end is not None)
                or (test_frequencies is not None)
        ):
            n, n_rfft, frequencies, freq_indexes = et_get_fft_settings(
                frequencies=test_frequencies,
                freq_ini=freq_ini,
                freq_end=freq_end,
                frequency_resolution=frequency_resolution,
                n_samples=_data.shape[0],
                fs=data_node.fs)
            # demean
            _data = _data - np.mean(_data, axis=0)
            _fft = pyfftw.builders.rfft(
                _data,
                n=n,
                overwrite_input=False,
                planner_effort="FFTW_ESTIMATE",
                axis=0,
                threads=1,
            )

            scaling_factor = np.maximum(n, _data.shape[0]) / (_data.shape[0] - 1)
            yfft = _fft()

            phase = np.angle(np.sum(yfft[freq_indexes, ...], axis=0)).reshape(-1, 1)
            psd = scaling_factor * 1 / (n ** 2) * 2 * np.abs(yfft) ** 2.0

            s_var = np.sum(psd[freq_indexes, ...], axis=0) * _data.unit ** 2.0
            s_var = s_var.reshape(
                -1,
            )
        else:
            s_var = np.var(_data, axis=0, ddof=1).reshape(
                -1,
            )

        _noise_var = rn ** 2.0
        _idx_valid = _noise_var != 0
        _f_value = s_var[_idx_valid] / _noise_var[_idx_valid]
        snr[_idx_valid] = np.maximum(_f_value - 1.0, 0)
        _idx_invalid = _noise_var == 0
        snr[_idx_invalid] = np.inf * u.dimensionless_unscaled
        final_snr[:, _i] = snr
        final_s_var[:, _i] = s_var
        f_value[:, _i] = _f_value
    return final_snr, final_s_var, f_value, frequencies, phase


def get_in_window_data(data_node: DataNode = None,
                       roi_windows: np.array([TimeROI]) = np.array([TimeROI()])):
    roi_samples = [roi.get_roi_samples(data_node=data_node) for roi in roi_windows]
    output = []
    data = data_node.data
    for _i, _samples in enumerate(roi_samples):
        output.append(data[_samples, ...])
    return output


def et_snr_weighted_mean(
        averaged_epochs: np.array = np.array([]),
        rn: np.array = np.array([]),
        snr: np.array = np.array([]),
        roi_windows: [np.array] = None,
        n_ch: int = None,
        channel_idx: np.array = np.array([]),
):
    if not channel_idx.size:
        if n_ch is None:
            _v = np.arange(averaged_epochs.shape[1])
        else:
            _v = np.argsort(snr)[::-1][0:n_ch]
    else:
        _v = channel_idx
    _snr = snr
    if not np.any(snr):
        _snr = np.ones(snr.shape)
    w_ave = np.sum(averaged_epochs[:, _v] * _snr[_v].T, axis=1) / sum(_snr[_v])
    total_noise_var = rn[_v] ** 2.0
    w_total_noise_var = 1.0 / sum(1.0 / total_noise_var)
    total_rn = w_total_noise_var**0.5
    total_snr, _signal_var = et_snr_in_rois(
        data=np.expand_dims(w_ave, 1), roi_windows=roi_windows, rn=total_rn
    )
    return np.expand_dims(w_ave, axis=1), total_rn, total_snr, _signal_var


def et_subtract_correlated_ref(
        data: np.array = np.array([]),
        idx_ref: np.array = np.array([]),
        high_pass: u.Quantity = 0.1 * u.Hz,
        low_pass: u.Quantity = 20.0 * u.Hz,
        plot_results=False,
        fs: u.Quantity = 1.0 * u.Hz,
        figure_path: str = "",
        figure_basename: str = "",
):
    data = np.atleast_3d(data)
    origin_data = data.copy()
    fig = None
    # filter
    _b_h, _b_l = None, None
    if high_pass is not None:
        _b_h = eegf.bandpass_fir_win(high_pass=high_pass, low_pass=None, fs=fs)
    if low_pass is not None:
        _b_l = eegf.bandpass_fir_win(high_pass=None, low_pass=low_pass, fs=fs)
    for _trial in np.arange(data.shape[2]):
        reg = linear_model.LinearRegression()
        x = np.arange(0, data.shape[0])[:, None]
        reg.fit(x, data[:, :, _trial])
        data[:, :, _trial] = data[:, :, _trial] - reg.predict(x) * data.unit
        temp_data = data[:, :, _trial]
        if high_pass is not None:
            temp_data = filt_data(data=data[:, :, _trial], b=_b_h)
        if low_pass is not None:
            temp_data = filt_data(data=temp_data, b=_b_l)
        ref = temp_data[:, idx_ref]
        for _idx in np.arange(ref.shape[1]):
            _current_ref = ref[:, _idx]
            transmission_index = temp_data.T.dot(_current_ref) / np.expand_dims(
                np.sum(np.square(_current_ref)), axis=0
            )
            data[:, :, _trial] -= _current_ref[:, None].dot(transmission_index[None, :])
            temp_data -= _current_ref[:, None].dot(transmission_index[None, :])
    figures = []
    if plot_results:
        time = np.arange(0, data.shape[0]) / fs
        fig = plt.figure()
        ax = fig.add_subplot(121)
        ax.plot(time, origin_data[:, 0, :].squeeze())
        ax.set_title("original")
        ax.legend(loc="upper right")
        ax = fig.add_subplot(122, sharey=ax)
        ax.plot(time, data[:, 0, :].squeeze())
        ax.set_title("eog removed")
        ax.legend(loc="upper right")
        fig.savefig(figure_path + figure_basename + ".png")
        figures.append(fig)
    return data, figures


def clean_peaks(
        peaks_amp: np.array = None,
        peaks_pos: np.array = None,
        minimum_width_samples: int = None,
):
    assert peaks_amp.size == peaks_pos.size
    (_idx_diff,) = np.where(np.append(0, np.diff(peaks_pos)) > minimum_width_samples)
    plt.plot(peaks_pos, peaks_amp)


def et_subtract_oeg_template(
        data: np.array = np.array([]),
        fs: u.Quantity = None,
        idx_ref: np.array = np.array([]),
        high_pass: u.Quantity = 1 * u.Hz,
        low_pass: u.Quantity = 20 * u.Hz,
        template_width: u.Quantity = 1.4 * u.s,
        crest_factor_threshold=10,
        plot_results=False,
        figure_path: str = "",
        figure_basename: str = "",
        minimum_interval_width: u.Quantity = 0.075 * u.s,
        eog_peak_width: u.Quantity = 0.02 * u.s,
        n_iterations: int = 10,
        kernel_bandwidth: float = 0.15,
        use_initial_template: bool = True,
):
    """
    This function removes EOG artefacts via a variation of the template subtraction method described in Valderrama
    et al., 2018.The algorithm performs several steps:
    1 - Blinks are detected in the EOG channel using a peak detection and generating a starting template.
    2 - The template is iteratively adjusted using  a math-filter.
    The location of the events is recomputed using the match filter and a new template is estimated over each iteration.
    3 - Once the template and the location of the EOG events are obtained, an EOG signal is generated by convolving the
    template with the location of the events (scaled to maximize the similarity between the template and the actual
    events.
    3 - The generated EOG signal is subtracted from the raw EEG signal, thus leading to a clean EEG signal.
    See Valderrama, J. T., de la Torre, A., & Van Dun, B. (2018). An automatic algorithm for blink-artifact suppression
    based on iterative template matching: Application to single channel recording of cortical auditory evoked
    potentials. Journal of Neural Engineering, 15(1), 016008. https://doi.org/10.1088/1741-2552/aa8d95

    The variations used in this implementation are
    1 - the initial template is generated from the data itself, without requiring any template.
    :param data: numpy array with the data to be cleaned (samples x channels) matrix
    :param fs: sampling rate
    :param idx_ref: index indicating the EOG reference channel
    :param high_pass: cutoff frequency for the high-pass filter
    :param low_pass: cutoff frequency for the low-pass filter
    :param template_width: width of the EOG template
    :param crest_factor_threshold: crest factor (in dB) used to detect and provide a first guess template from the data
    :param plot_results: if True, output plots will be generated
    :param figure_path: string indicating the path where to save the figures
    :param figure_basename: name of generated figure
    :param minimum_interval_width: minimum interval between eye blinks (only used for initial guess)
    :param eog_peak_width: empirical width of an EOG blink (only used for initial guess)
    :param n_iterations: number of iterations to improve the template estimation
    :param kernel_bandwidth: factor use to control the with of the Gaussian kernel in threshold detection
    :param use_initial_template: if true, a template eye blinking will be used as starting point to find events
    :return: clean data, figure
    """
    output_data = data.copy()
    # filter data
    if high_pass is not None or low_pass is not None:
        _b = eegf.bandpass_fir_win(high_pass=high_pass, low_pass=low_pass, fs=fs)
        data = filt_data(data=data, b=_b)

    original_ref = output_data[:, idx_ref]
    ref = data[:, idx_ref]

    # generate, reconstruct and remove EOG artefacts
    for _idx_eog_ch in range(ref.shape[1]):
        _current_eog = ref[:, [_idx_eog_ch]]
        template, eog_events, z = generate_eog_template(
            eog_data=_current_eog,
            template_width=template_width,
            fs=fs,
            low_pass=low_pass,
            eog_peak_width=eog_peak_width,
            crest_factor_threshold=crest_factor_threshold,
            minimum_interval_width=minimum_interval_width,
            n_iterations=n_iterations,
            kernel_bandwidth=kernel_bandwidth,
            use_initial_template=use_initial_template,
        )
        reconstructed = reconstruct_eog(
            data=data, template=template, blink_positions=eog_events
        )

        # remove from original data (untouched)
        output_data = output_data - reconstructed * data.unit
        # also remove from filtered data used to reconstruct, otherwise the reconstructed data will have EOG components
        # what were previously removed.
        data = data - reconstructed * data.unit
        figures = []
        if plot_results:
            time = np.arange(0, output_data.shape[0]) / fs
            time_template = (
                                    np.arange(0, template.shape[0]) - template.shape[0] / 2
                            ) / fs
            fig = plt.figure()
            ax = fig.add_subplot(311)
            ax.plot(time_template, template, label="fitted template")
            ax.legend(loc="upper right")

            ax = fig.add_subplot(312)
            ax.plot(time, _current_eog, label="reference eog")
            ax.plot(
                time, reconstructed[:, idx_ref[_idx_eog_ch]], label="reconstructed eog"
            )
            if eog_events.size:
                peak_pos = eog_events + np.argmax(template)
                ax.plot(
                    time[peak_pos], reconstructed[peak_pos, idx_ref[_idx_eog_ch]], "o"
                )
            ax.legend(loc="upper right")

            ax = fig.add_subplot(313)
            ax.plot(time, original_ref[:, _idx_eog_ch], label="reference eog")
            ax.plot(time, output_data[:, idx_ref[_idx_eog_ch]], label="eog removed")
            ax.legend(loc="upper right")
            fig.savefig(
                figure_path + figure_basename + "eog_ref_{:}.png".format(_idx_eog_ch)
            )
            figures.append(fig)
    return output_data, figures, template, z, eog_events


def et_get_spatial_filtering(
        epochs: np.array = np.array([]),
        fs: u.Quantity = None,
        sf_join_frequencies: np.array = None,
        weight_data: bool = True,
        weighted_frequency_domain: bool = False,
        weight_across_epochs: bool = True,
        weights: np.array = None,
        demean_data: bool = True,
        keep0: int = None,
        keep1: float = 1e-9,
        perc0: float = 1,
        perc1: float = None,
        block_size: int = 10,
        n_tracked_points: int = None,
        delta_frequency: u.Quantity = 5 * u.Hz,
        n_jobs: int = 1,
):
    """

    :param epochs: m x n x l (samples, channels, epochs)
    :param fs: sampling rate
    :param sf_join_frequencies: numpy array with frequencies to bias the filter
    :param weight_data: if True, covariance and mean will be estimated using weights
    :param weighted_frequency_domain: boll indicating if the weghts are compute in the time or frequency domain
    :param weight_across_epochs: if True, weights are computed across epochs (as in Elbeling 1984) otherwise weights are
    computed within epoch (1 / variance across time)
    :param weights: array of weights to use when weighted_average is true. If none and weighted_average is true,
    these will be estimated.
    :param demean_data: if True, data will be demeaned prior weights estimation.
    :param keep0: integer controlling  whitening of unbiased components in DSS. This integer value represent the number
    of components to keep.
    :param keep1: float controlling  whitening of unbiased components in DSS. This value will remove components below
    keep1 which is relative to the maximum eigen value.
    :param perc0: float (between 0 and 1) controlling whitening of unbiased components in DSS.
    This value will preserve components that explain the percentage of variance.
    :param perc1: float (between 0 and 1) controlling the number of biased components kept in DSS.
    This value will preserve the components of the biased PCA analysis that explain the percentage of variance.
    :param block_size: integer indicating the number of trials that would be use to estimate the weights
    :param n_tracked_points: number of equally spaced points over time used to estimate residual noise and weights
    :param delta_frequency: frequency size around each sf_join_frequency to estimate noise
    :param n_jobs: number of CPUs to compute FFT
    :return: z, pwr0, pwr1, cov_1, weights: components, unbiased power, biased power, covariance rotation,
    estimated weights
    """
    print("computing spatial filter")

    # bias function uses weighted mean or standard mean
    if weight_data and weights is None:
        if weighted_frequency_domain:
            weights, *_ = get_pooled_frequency_weights(
                epochs=epochs,
                fs=fs,
                frequencies=sf_join_frequencies,
                weighted_average=weight_data,
                block_size=block_size,
                delta_frequency=delta_frequency,
            )
        else:
            if n_tracked_points is None:
                n_tracked_points = epochs.shape[0]
            samples_distance = int(max(epochs.shape[0] // n_tracked_points, 1))
            _average = et_mean(
                epochs,
                weighted=weight_data,
                weight_across_epochs=weight_across_epochs,
                block_size=block_size,
                samples_distance=samples_distance,
                fs=fs,
            )
            weights = _average.weights

    if weights is None:
        weights = np.ones(epochs.shape) * u.dimensionless_unscaled
    if demean_data:
        epochs = eo.et_demean(epochs, w=weights)

    average = eo.w_mean(epochs, weights=weights)

    if sf_join_frequencies is not None:
        n_frequencies = sf_join_frequencies / fs
        c0, t0 = eo.et_freq_weighted_cov(
            epochs, normalized_frequencies=n_frequencies, n_jobs=n_jobs
        )
        c1, t1 = eo.et_freq_weighted_cov(
            average, normalized_frequencies=n_frequencies, n_jobs=n_jobs
        )
        c0 = c0 / t0
        c1 = c1 / t1
        todss, pwr0, pwr1, n_0, n_1 = sf.nt_dss0(
            c0, c1, keep0=keep0, keep1=keep1, perc0=perc0, perc1=perc1
        )
        z = eo.et_mmat(epochs, todss)
        cov_1, tw_cov = eo.et_freq_shifted_xcovariance(
            z,
            epochs,
            normalized_frequencies=n_frequencies,
            wy=weights.value,
            n_jobs=n_jobs,
        )
        cov_1 = cov_1 / tw_cov
    else:
        # clean data using dss with weighted average as bias. Data covariance weighted with same weights
        c0, tw0 = eo.et_weighted_covariance(epochs)
        c1, tw1 = eo.et_weighted_covariance(average)
        c0 = c0 / tw0
        c1 = c1 / tw1
        todss, pwr0, pwr1, n_0, n_1 = sf.nt_dss0(
            c0, c1, keep0=keep0, keep1=keep1, perc0=perc0, perc1=perc1
        )
        z = eo.et_mmat(epochs, todss)
        cov_1, tw_cov = eo.et_time_shifted_xcovariance(z,
                                                       epochs,
                                                       wy=weights.value
                                                       )
        cov_1 = cov_1 / tw_cov

    return z, pwr0, pwr1, cov_1, n_0, n_1, weights


def et_apply_spatial_filtering(
        z=np.array([]),
        pwr0=np.array([]),
        pwr1=np.array([]),
        cov_1=np.array([]),
        sf_components=np.array([]),
        sf_thr=0.8,
):
    print("applying spatial filter")
    max_num_components = z.shape[1]
    if sf_components is None or not sf_components.size:
        # threshold is set to account for st_thr variance of the evoked power
        pos = np.maximum(np.where(np.cumsum(pwr1) / np.sum(pwr1) >= sf_thr)[0][0], 1)
        n_components = np.arange(pos)
    else:
        n_components = sf_components
    n_components = n_components[n_components < max_num_components]
    cleaned_data = eo.et_mmat(z[:, n_components, :], cov_1[n_components, :])
    _total_explained_var = (
                                   np.sum(pwr1[n_components]) / np.sum(pwr0[n_components])
                           ) / np.sum(pwr1 / pwr0)
    _evoked_explained_var = np.sum(pwr1[n_components]) / np.sum(pwr1)
    print(
        "DSS keeping {:} out of {:} components accounting for {:}% of the total variance and {:}% of "
        "evoked variance".format(
            n_components.size,
            pwr0.size,
            np.round(_total_explained_var * 100, decimals=2),
            np.round(_evoked_explained_var * 100, decimals=2),
        )
    )
    return cleaned_data, n_components


def estimate_rn_from_trace(
        data=np.array([]), rn_ini_sample=0, rn_end_sample=-1, plot_estimation=False
):
    x = np.expand_dims(
        np.arange(0, data[rn_ini_sample:rn_end_sample, :].shape[0]), axis=1
    )
    _subset = data[rn_ini_sample:rn_end_sample, :]
    regression = linear_model.LinearRegression()
    regression.fit(x, _subset)
    rn = np.std(_subset - regression.predict(x), axis=0)
    if plot_estimation:
        plt.plot(x, _subset)
        plt.plot(x, regression.predict(x))
        plt.title("rn regression, rn:" + str(rn))
        plt.show()

    return rn


def estimate_srn_from_trace(
        data=np.array([]), snr_ini_sample=0, snr_end_sample=-1, **kwargs
):
    rn = estimate_rn_from_trace(data=data, **kwargs)
    _subset = data[snr_ini_sample:snr_end_sample, :]
    snr = np.var(_subset, ddof=1, axis=0) / rn**2.0 - 1
    return snr, rn


def eye_artifact_subtraction(
        epochs: np.array = np.array([]), oeg_epochs: np.array = np.array([])
):
    # subtract eye artifacts
    print("removing oeg artifacts")
    clean_data = et_subtract_correlated_ref(epochs=epochs, ref=oeg_epochs)
    return clean_data


def et_impulse_response_artifact_subtraction(
        data: np.array = None,
        stimulus_waveform: np.array = None,
        ir_length: int = 100,
        ir_max_lag: int = 0,
        regularization_factor: float = 1,
        plot_results: bool = False,
        n_jobs: int = 1,
) -> np.array:
    """
    This function will remove an artifact which has the shape of the input stimulus_waveform.
    Here, artifact is estimated from the impulse response. The latter is estimated by averaging individual
    impulse responses across epochs.
    :param data: data samples x channels x trials
    :param stimulus_waveform: single column numpy array with the target waveform artifact
    :param ir_length: estimated impulse response length in samples
    :param ir_max_lag: maximum lag or sydtem delay (from zero). Impulse response window will be centered around the max
    within the max_lag.
    :param regularization_factor: This value is used to regularize the deconvolution based on Tikhonov regularization
    allow to estimate the transfer function when the input signal is sparse in frequency components
    :param plot_results: if True, figures with results will be shown
    :param n_jobs: number of CPUs to compute FFT
    :return: data without artifacts
    """
    original_data_shape = data.shape
    # compute impulse response; data padded to next power of 2 to speed process
    n_fft = next_power_two(data.shape[0])

    data = np.atleast_3d(data)
    _stim_template = stimulus_waveform[0: data.shape[0]]
    data = np.pad(
        data,
        ((0, n_fft - data.shape[0]), (0, 0), (0, 0)),
        constant_values=(0, 0),
        mode="constant",
    )
    _stim_template = np.pad(
        _stim_template,
        ((0, n_fft - _stim_template.shape[0]), (0, 0)),
        constant_values=(0, 0),
        mode="constant",
    )
    _fft = pyfftw.builders.rfft(
        _stim_template,
        overwrite_input=False,
        planner_effort="FFTW_ESTIMATE",
        axis=0,
        threads=n_jobs,
    )
    x_fft = _fft()
    _fft = pyfftw.builders.rfft(
        data, overwrite_input=False, planner_effort="FFTW_ESTIMATE", axis=0, threads=1
    )
    y_fft = _fft()

    # estimate impulse response for each epoch via Tikhonov regularization
    x_fft = np.atleast_3d(x_fft)
    h_fft = (
            y_fft
            * np.conjugate(x_fft)
            / (x_fft * np.conjugate(x_fft) + regularization_factor)
    )

    _ifft = pyfftw.builders.irfft(
        h_fft,
        n=data.shape[0],
        overwrite_input=False,
        planner_effort="FFTW_ESTIMATE",
        axis=0,
        threads=n_jobs,
    )
    h = _ifft()
    h = np.mean(h, axis=2, keepdims=True)
    w = np.zeros(h.shape)
    ws = np.repeat(signal.windows.hanning(ir_length).reshape(-1, 1), h.shape[1], axis=1)
    w[0: ws.shape[0], :, :] = np.atleast_3d(ws)
    _max_ir = np.argmax(h[0: ir_max_lag + 1])
    w = np.roll(w, -ir_length // 2 + _max_ir, axis=0)
    h_ave_w = h * w
    # estimate artifact by convolution
    _fft = pyfftw.builders.rfft(
        h_ave_w,
        overwrite_input=False,
        planner_effort="FFTW_ESTIMATE",
        axis=0,
        threads=n_jobs,
    )
    h_ave_w_fft = _fft()
    # convolve
    fft_artifact = h_ave_w_fft * x_fft
    _ifft = pyfftw.builders.irfft(
        fft_artifact,
        n=data.shape[0],
        overwrite_input=False,
        planner_effort="FFTW_ESTIMATE",
        axis=0,
        threads=n_jobs,
    )
    _recovered_artifact = _ifft() * data.unit
    _clean_data = data - _recovered_artifact
    if plot_results:
        plt.figure()
        plt.plot(h.squeeze(), label="full IR")
        plt.plot(h_ave_w.squeeze(), label="windowed IR")
        plt.legend()
        plt.show()
    clean_data = np.resize(_clean_data, original_data_shape)
    recovered_artifact = np.resize(_recovered_artifact, original_data_shape)
    return clean_data, recovered_artifact


def next_power_two(n):
    # Returns next power of two following 'number'
    return int(2 ** np.ceil(np.log2(n)))


def et_regression_subtraction(
        data: np.array = None,
        stimulus_waveform: np.array = None,
        max_lag: int = 0,
        max_length: int = None,
        plot_results: bool = False,
) -> np.array:
    """
    This function will remove an artifact which has the shape of the input stimulus_waveform.
    Here, artifact is estimated from the impulse response. The latter is estimated by averaging individual
    impulse responses across epochs.
    :param data: data samples x channels x trials
    :param stimulus_waveform: single column numpy array with the target waveform artifact
    :param max_lag: max expected delay between artifact and stimulus waveform. The maximum correlation will be searched
     within this  0 to max_lag
    :param max_length: determines the maxlegnth to search for correlation between stimulus artifact and data. This is
    useful if the desire response has a delay relative to the stimulus artifact. You could limit the correlation to look
    only on the region containing only the artifact,
    :param plot_results: if True, figures with results will be shown
    :return: data without artifacts
    """
    clean_data = np.zeros(data.shape)
    subset_idx = np.arange(0, data.shape[0])
    if max_length is not None:
        subset_idx = np.arange(0, np.minimum(max_length, data.shape[0]))
    sub_stimulus_waveform = stimulus_waveform[subset_idx]
    sub_data_set = data[subset_idx, :]
    _optimal_lag = 0
    # first we detect the lag to which regression fit is maximal across channels
    if max_lag > 0:
        score = np.zeros((max_lag, data.shape[1]))
        for _idx in np.arange(data.shape[1]):
            for _i_lag in range(max_lag):
                regression = LinearRegression()
                _delayed_sub_stimulus_waveform = np.pad(
                    sub_stimulus_waveform,
                    ((_i_lag, 0), (0, 0)),
                    "constant",
                    constant_values=(0, 0),
                )
                _delayed_sub_stimulus_waveform.resize(
                    sub_stimulus_waveform.shape, refcheck=False
                )
                regression.fit(_delayed_sub_stimulus_waveform, sub_data_set[:, _idx])
                score[_i_lag, _idx] = regression.score(
                    _delayed_sub_stimulus_waveform, sub_data_set[:, _idx]
                )
        # we define the optimal lag as the average one across all channel
        _optimal_lag = np.round(np.mean(np.argmax(score, axis=0))).astype(int)

    # now we use optimal lag to subtract artifact
    for _idx in tqdm(np.arange(data.shape[1]), desc="Artefact regression"):
        regression = LinearRegression()
        _delayed_sub_stimulus_waveform = np.pad(
            sub_stimulus_waveform,
            ((_optimal_lag, 0), (0, 0)),
            "constant",
            constant_values=(0, 0),
        )
        _delayed_sub_stimulus_waveform.resize(
            sub_stimulus_waveform.shape, refcheck=False
        )
        regression.fit(_delayed_sub_stimulus_waveform, sub_data_set[:, _idx])
        delayed_stimulus_waveform = np.pad(
            stimulus_waveform,
            ((_optimal_lag, 0), (0, 0)),
            "constant",
            constant_values=(0, 0),
        )
        delayed_stimulus_waveform.resize(stimulus_waveform.shape, refcheck=False)
        recovered_artifact = regression.predict(delayed_stimulus_waveform)
        clean_data[:, _idx] = data[:, _idx] - recovered_artifact

    if plot_results:
        plt.plot(data[:, -1], label="original data")
        plt.plot(recovered_artifact[:, -1], label="recovered artifact")
        plt.plot(clean_data[:, -1], label="clean data")
        plt.legend()
        plt.show()
    return clean_data, recovered_artifact


def et_xcorr_subtraction(
        data: np.array = None,
        stimulus_waveform: np.array = None,
        max_lag: int = 0,
        max_length: int = None,
        plot_results: bool = False,
) -> np.array:
    """
    This function will remove an artifact which has the shape of the input stimulus_waveform.
    Here, artifact is estimated from the impulse response. The latter is estimated by averaging individual
    impulse responses across epochs.
    :param data: data samples x channels x trials
    :param stimulus_waveform: single column numpy array with the target waveform artifact
    :param max_lag: max expected delay between artifact and stimulus waveform. The maximum correlation will be searched
     within this  0 to max_lag as we assume only a positive delay
    :param max_length: determines the maxlegnth to search for correlation between stimulus artifact and data. This is
    useful if the desire response has a delay relative to the stimulus artifact. You could limit the correlation to look
    only on the region containing only the artifact,
    :param plot_results: if True, figures with results will be shown
    :return: data without artifacts
    """
    original_shape = data.shape
    data = np.atleast_3d(data)
    clean_data = np.zeros(data.shape)
    subset_idx = np.arange(0, data.shape[0])
    if max_length is not None:
        subset_idx = np.arange(0, np.minimum(max_length, data.shape[0]))
    sub_stimulus_waveform = stimulus_waveform[subset_idx]
    sub_data_set = data[subset_idx, ::]
    _optimal_lag = 0
    if max_lag > 0:
        score = np.zeros((max_lag, data.shape[1]))
        for _i_lag in range(max_lag):
            _delayed_sub_stimulus_waveform = np.pad(
                sub_stimulus_waveform,
                ((_i_lag, 0), (0, 0)),
                "constant",
                constant_values=(0, 0),
            )
            _delayed_sub_stimulus_waveform.resize(
                sub_stimulus_waveform.shape, refcheck=False
            )
            ave_data = np.mean(sub_data_set, 2)
            transmission_index = ave_data.T.dot(
                _delayed_sub_stimulus_waveform
            ) / np.expand_dims(
                np.sum(np.square(_delayed_sub_stimulus_waveform)), axis=0
            )
            recovered_artifact = np.tile(
                np.atleast_3d(stimulus_waveform * transmission_index.T),
                (1, 1, data.shape[2]),
            )
            clean_data = data - recovered_artifact
            score[_i_lag, :] = np.mean(
                np.std(np.mean(data - recovered_artifact, axis=2), axis=0)
            )
        # we define the optimal lag as the average one across all channel
        _optimal_lag = np.round(np.mean(np.argmax(score, axis=0))).astype(int)

    # remove artifact at optimal lag
    _delayed_sub_stimulus_waveform = np.pad(
        sub_stimulus_waveform,
        ((_optimal_lag, 0), (0, 0)),
        "constant",
        constant_values=(0, 0),
    )
    _delayed_sub_stimulus_waveform.resize(sub_stimulus_waveform.shape, refcheck=False)
    ave_data = np.mean(sub_data_set, 2)
    transmission_index = ave_data.T.dot(
        _delayed_sub_stimulus_waveform
    ) / np.expand_dims(np.sum(np.square(_delayed_sub_stimulus_waveform)), axis=0)

    delayed_stimulus_waveform = np.pad(
        stimulus_waveform,
        ((_optimal_lag, 0), (0, 0)),
        "constant",
        constant_values=(0, 0),
    )
    delayed_stimulus_waveform.resize(stimulus_waveform.shape, refcheck=False)

    recovered_artifact = np.tile(
        np.atleast_3d(delayed_stimulus_waveform * transmission_index.T),
        (1, 1, data.shape[2]),
    )
    clean_data = data - recovered_artifact

    if plot_results:
        plt.plot(data[:, -1], label="original data")
        plt.plot(recovered_artifact[:, -1], label="recovered artifact")
        plt.plot(clean_data[:, -1], label="clean data")
        plt.legend()
        plt.show()
    clean_data = clean_data.reshape(original_shape)
    return clean_data, recovered_artifact


def et_ica_epochs(
        data: np.array = np.array([]), tol: float = 1e-4, iterations: int = 200
):
    """
    This function computes and sorts the components of an input matrix using ICA. The components are sorted by their
    power.
    :param data: np.array where components are obtained for each column
    :param tol: float indicating the tolerance for the difference between previous and updated weights to stop the
    iteration
    :param iterations: maximum number of iterations to estimate the components
    :return: components, unmixing matrix (used to obtain the components), mixing_matrix (used to project the components
    back to the original space, power of components, whitening matrix
    """

    no_chans = data.shape[1]
    whitened_ave, whitening_m = et_ica_whitening(data)

    # Implement ICA
    # Guess random initial value for W (inverse mixing matrix) and update until it is orthogonal
    # (ie. multiplied by transverse = 1)
    # Initialise array for w
    w = np.zeros((no_chans, no_chans))

    # Iterate through W matrix and update it - ie. calculate new value for w
    # Based on formula from https://towardsdatascience.com/independent-component-analysis-ica-in-python-a0ef0db0955e
    for i in range(no_chans):
        W = np.random.rand(no_chans)

        j = 0
        tol_lim = 1

        while (j < iterations) and (tol_lim > tol):
            u = np.dot(W, whitened_ave)
            g = np.tanh(u)
            g_dash = 1 - np.square(np.tanh(u))
            W_update = (whitened_ave * g).mean(axis=1) - (g_dash.mean() * W.squeeze())
            # Decorrelating w
            W_update = W_update - np.dot(np.dot(W_update, w[:i].T), w[:i])
            W_update = W_update / np.sqrt((W_update**2).sum())
            # Create a limit condition using the current value of w
            tol_lim = np.abs(np.abs((W_update * W).sum()) - 1)
            # Update original w with the new values
            W = W_update
            # Iterator counter
            j += 1
        w[i, :] = W.T

    # Unmix Signals
    components = np.dot(w, whitened_ave)
    components = components.T
    mixing = np.linalg.pinv(np.dot(w, whitening_m))

    # Sorting by power
    # Calculate and sort a power array (large to small)
    pwr = np.max(np.abs(mixing), axis=0)
    idx_pwr = np.argsort(-pwr)
    s_pwr = pwr[idx_pwr]

    # Sort mixing matrix and components by power
    unmixing = w.T
    s_unmixing = unmixing[:, idx_pwr].T
    s_mixing = mixing[:, idx_pwr]
    s_components = components[:, idx_pwr]

    # Projection back into cortical space
    # proj = (np.dot(mixing, components.T)).T

    return s_components, s_unmixing, s_mixing, s_pwr, whitening_m


def et_ica_whitening(data: np.array = None):
    # Preprocessing
    data = data.T

    # Centering - subtracting the mean from the observed data
    mean = np.mean(data, axis=1, keepdims=True)
    centered_data = data - mean

    # Whitening x - removing correlations between components
    # Calculate covariance matrix
    covar = (centered_data.dot(centered_data.T)) / (np.shape(centered_data)[1] - 1)

    # Use single value decomposition to describe the matrix using its constituents
    # Breaking it down into left singular vectors (U) or eigenvectors, the singular values or eigenvalues (K)
    # and right singular vectors (V)
    u, k, v = np.linalg.svd(covar)

    # Create a diagonal matrix of the eigenvalues (inverse square)
    d = np.diag(1 / np.sqrt(k))

    # Calculate the matrix which will whiten the weight averaged epochs
    whitening_m = np.dot(u, np.dot(d, u.T))

    # Whiten EEG averaged data using above whitening matrix
    whitened_ave = np.dot(whitening_m, data)

    return whitened_ave, whitening_m
