import numpy as np
from peegy.processing.tools import eeg_epoch_operators as eo
from peegy.processing.system.memory import enough_memory
import pyfftw
from peegy.tools.units.unit_tools import set_default_unit
import astropy.units as u
from tqdm import tqdm

__author__ = 'jaime undurraga'


def et_get_fft_settings(
    frequencies: np.array(u.Quantity) = None,
    freq_ini: u.Quantity = None,
    freq_end: u.Quantity = None,
    fs: u.Quantity = None,
    frequency_resolution: u.Quantity = None,
    n_samples: int = None,
):
    """
    Helper function. Get frequency indexes for freq_ini and freq_end based on given sampling rate and desired frequency
    resolution in FFT.
    :param frequencies: Frequencies in Hz to provide indexes
    :param freq_ini: starting frequency to return indexes
    :param freq_end: ending frequency to return indexes
    :param fs: sampling frequency
    :param frequency_resolution: desired frequency resolution
    :param n_samples: number of samples of the original data set of which the FFT will be computed
    :return: n of points necessary to obtain desired resolution, number of positive frequencies, frequency indexes of
    input frequency vector
    """
    frequency_indexes = None
    if frequency_resolution is not None:
        n = int(np.round(fs / frequency_resolution).to(u.dimensionless_unscaled))
    else:
        n = n_samples
    n_rfft = n // 2 + 1
    freqs = np.arange(0, n_rfft) * fs / n
    # remove frequencies that can't be represented in window
    frequency_indexes = np.arange(0, n_rfft, dtype=int)
    if frequencies is not None and frequencies.size:
        frequency_indexes = []
        for _f in frequencies:
            frequency_indexes.append(np.argmin(np.abs(freqs - _f)))
        frequency_indexes = np.unique(np.array([frequency_indexes]))
    elif (freq_ini is not None) or (freq_end is not None):
        _ini_index = 0
        if freq_ini is not None:
            _ini_index = np.argmin(np.abs(freqs - freq_ini))
        _end_index = n_rfft
        if freq_end is not None:
            _end_index = np.argmin(np.abs(freqs - freq_end)) + 1
        frequency_indexes = np.arange(_ini_index, _end_index)
    return n, n_rfft, freqs[frequency_indexes], frequency_indexes


def et_frequency_mean(epochs=np.array([]),
                      fs: u.Quantity = None,
                      n_fft: int = None,
                      block_size: int = 10,
                      test_frequencies: np.array([u.Quantity]) = None,
                      scale_frequency_data: bool = True,
                      weighted_average: bool = True,
                      delta_frequency: u.Quantity = 2 * u.Hz,
                      power_line_frequency: u.Quantity = 50 * u.Hz):
    epochs = set_default_unit(epochs, u.uV)
    fs = set_default_unit(fs, u.Hz)
    delta_frequency = set_default_unit(delta_frequency, u.Hz)
    test_frequencies = set_default_unit(test_frequencies, u.Hz)

    weights, pooled_rn, pooled_snr, by_freq_rn, by_freq_snr, freq_samples, exact_frequencies = \
        get_pooled_frequency_weights(
            epochs=epochs,
            fs=fs,
            block_size=block_size,
            frequencies=test_frequencies,
            weighted_average=weighted_average,
            delta_frequency=delta_frequency,
            power_line_frequency=power_line_frequency,
        )

    w_ave = eo.w_mean(epochs=epochs,
                      weights=weights[0, :, :])
    fft = pyfftw.builders.rfft(w_ave,
                               n=n_fft,
                               overwrite_input=False,
                               planner_effort='FFTW_ESTIMATE',
                               axis=0,
                               threads=1)
    scaling_factor = 1.0
    if scale_frequency_data:
        fft_size_factor = 1
        if n_fft is not None:
            fft_size_factor = np.maximum(w_ave.shape[0] / n_fft, 1.0)
        scaling_factor = fft_size_factor * 2 / epochs.shape[0]

    w_fft = fft() * scaling_factor * w_ave.unit
    freq_samples = scaling_factor * freq_samples
    pooled_rn = scaling_factor * pooled_rn
    return w_ave, pooled_snr, pooled_rn, by_freq_snr, by_freq_snr, w_fft, weights, freq_samples, exact_frequencies


def et_average_frequency_transformation(epochs: np.array = np.array([]),
                                        fs=0.0,
                                        ave_mode='magnitude'):

    fft = pyfftw.builders.rfft(epochs, overwrite_input=False, planner_effort='FFTW_ESTIMATE', axis=0,
                               threads=1)
    _fft = fft()

    if ave_mode == 'magnitude':
        _fft = np.abs(_fft)
    ave = np.abs(np.mean(_fft, axis=2))
    ave *= 2/epochs.shape[0]
    freqs = np.arange(0, _fft.shape[0]) * fs / epochs.shape[0]
    return ave, freqs


def goertzel(data, fs, frequency):
    """
    Implementation of the Goertzel algorithm, to calculate individual frequency Fourier values.
    :param data: (time x channels) numpy arra
    :param fs: float indicating the sampling rate
    :param frequency: frequency to be estimated in Hz
    :return: np.array with Fourier frequency term for each channel (1 x channels)
    Frequency amplitude will match that of numpy.fft.fft, exact frequency bin tested
    """
    n = data.shape[0]
    freqs = np.arange(0, n) * fs / n
    k = np.argmin(np.abs(freqs - frequency))
    cr = np.cos(2.0 * np.pi * k / n)
    ci = np.sin(2.0 * np.pi * k / n)
    coeff = 2.0 * cr
    sprev = 0.0
    sprev2 = 0.0
    for _i in tqdm(np.arange(n).astype(int), desc='DFT estimation {:}'.format(frequency)):
        s = data[[_i], :] + coeff * sprev - sprev2
        sprev2 = sprev
        sprev = s
    real = sprev * cr - sprev2
    imag = sprev * ci
    exact_frequency = freqs[k]
    return real + 1j * imag, exact_frequency


def discrete_dft(data: np.array = None,
                 fs: float = None,
                 frequencies: float = None,
                 method: str = 'auto'):
    """
    Gets individual frequency Fourier values using either fast fft or Goertzel depending on available memory.
    :param data: (time x channels) numpy array
    :param fs: float indicating the sampling rate
    :param frequencies: frequencies to be estimated in Hz
    :param method: string specifying how to compute DFT
    :return: np.array with Fourier frequency term for each channel (1 x channels)
    """
    data = set_default_unit(data, u.uV)
    frequencies = set_default_unit(frequencies, u.Hz)
    n = data.shape[0]
    freqs = np.arange(0, n) * fs / n
    k = np.array([np.argmin(np.abs(freqs - _f)) for _f in frequencies])
    dft = np.zeros((k.size, data.shape[1], data.shape[2])) * data.unit
    exact_frequencies = np.zeros(k.size) * frequencies.unit
    _memory = enough_memory(data)
    if method == 'auto':
        _method = 'fft' if _memory else 'goertzel'

    if _method == 'fft':
        fft = pyfftw.builders.rfft(data, overwrite_input=False, planner_effort='FFTW_ESTIMATE', axis=0,
                                   threads=1)
        _fft = fft()
        dft = _fft[k, :] * data.unit
        exact_frequencies = freqs[k]
    elif _method == 'goertzel':
        for _i, _f in enumerate(frequencies):
            _dft, _exact_frequency = goertzel(data, fs, _f)
            dft[_i] = _dft
            exact_frequencies[_i] = _exact_frequency
    else:
        raise 'no implemented method'

    return dft, exact_frequencies


def get_discrete_frequencies_weights(
        epochs: np.array = None,
        fs: float = None,
        frequencies: float = None,
        block_size: int = 5,
        weighted_average=True) -> np.array:
    """
    Compute spectral amplitude for a given frequencies
    component.
    :param epochs: time x channels x trials numpy array in the time domain
    :param fs: float indicating the sampling rate in Hz
    :param frequencies: array with the frequencies of interest
    :param block_size: integer indicating the number of trials that would be use to estimate the weights
    :param weighted_average: if false, frequency bins will not be weighted to compute mean and std
    """
    epochs = set_default_unit(epochs, u.uV)
    fs = set_default_unit(fs, u.Hz)
    frequencies = set_default_unit(frequencies, u.Hz)

    y_fft, exact_frequencies = discrete_dft(epochs, fs, frequencies)
    # y_noise, exact_frequencies = discrete_dft(epochs - np.mean(epochs, axis=2, keepdims=True), fs, frequencies)

    block_size = np.minimum(epochs.shape[2], block_size)
    blocks = np.arange(0, epochs.shape[2] + 1, block_size).astype(int)
    blocks[-1] = np.maximum(blocks[-1], epochs.shape[2])
    n_blocks = np.maximum(len(blocks) - 1, 1)
    r = np.zeros((y_fft.shape[0], epochs.shape[1], n_blocks))
    norm_r = np.zeros((y_fft.shape[0], epochs.shape[1], n_blocks))
    total_var = np.zeros((y_fft.shape[0], epochs.shape[1], n_blocks)) * epochs.unit ** 2.0
    # r = np.zeros((y_noise.shape[0], epochs.shape[1], n_blocks))
    # norm_r = np.zeros((y_noise.shape[0], epochs.shape[1], n_blocks))
    # total_var = np.zeros((y_noise.shape[0], epochs.shape[1], n_blocks)) * epochs.unit ** 2.0
    wb = np.ones(total_var.shape) * total_var.unit
    ini_block, end_block = blocks[:-1], np.cumsum(np.diff(blocks))[::1]
    for i, (_ini_trial, _end_trial) in enumerate(zip(ini_block, end_block)):
        mag = np.abs(y_fft[:, :, _ini_trial: _end_trial])
        ang = np.angle(y_fft[:, :, _ini_trial: _end_trial]).value
        # mag = np.abs(y_noise[:, :, _ini_trial: _end_trial])
        # ang = np.angle(y_noise[:, :, _ini_trial: _end_trial]).value
        if weighted_average:
            angular_weights = mag ** 2.0
            angular_weights = angular_weights / np.sum(angular_weights, axis=2, keepdims=True)
        else:
            angular_weights = 1.0

        norm_r[:, :, i] = np.abs(np.sum((angular_weights * np.exp(1j * ang)), axis=2))
        mean_x = np.sum((mag * angular_weights * np.cos(ang)), axis=2, keepdims=True)
        mean_y = np.sum((mag * angular_weights * np.sin(ang)), axis=2, keepdims=True)
        r[:, :, i] = np.sqrt(mean_x ** 2.0 + mean_y ** 2)[:, :, 0]
        var_x = np.sum(angular_weights * (mag * np.cos(ang) - mean_x) ** 2.0, axis=2)
        var_y = np.sum(angular_weights * (mag * np.sin(ang) - mean_y) ** 2.0, axis=2)
        # we assumed that variance on x and y axis are independent from each other
        # this encapsulates the variance: sigma_r^2 <= variance <= sigma_r^2 + 4 * sum(w_angular*r_i*mean(r_i))
        total_var[:, :, i] = var_x + var_y
        # purely radial
        # mean_r = np.sum(mag * angular_weights, axis=2, keepdims=True)
        # total_var[:, :, i] = np.sum(angular_weights * (mag - mean_r) ** 2.0, axis=2)

        # fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})
        # ax.plot(ang.T.squeeze(), mag.T.squeeze(), 'o')
        # ax.plot(np.angle(mean_x + 1j*mean_y).squeeze(), r[:, :, i].squeeze(), 'o', markersize=8, color='k')

    if weighted_average:
        wb = 1 / total_var
    if np.all(wb == np.inf):
        wb[:] = 1
    w = np.zeros(y_fft.shape) * wb.unit
    # w = np.zeros(y_noise.shape) * wb.unit
    for i, (_ini_trial, _end_trial) in enumerate(zip(ini_block, end_block)):
        w[:, :, _ini_trial: _end_trial] = wb[:, :, [i]]
    if weighted_average:
        rn = np.sqrt(1.0 / np.sum(block_size / total_var, axis=2))
    else:
        rn = np.sqrt(np.sum(block_size * total_var, axis=2) / ((block_size * n_blocks) ** 2.0))
    spectral_magnitude = np.abs(eo.w_mean(y_fft, weights=w))
    sig_plus_noise_var = spectral_magnitude ** 2.0
    snr = sig_plus_noise_var / (rn ** 2) - 1
    return w, spectral_magnitude, sig_plus_noise_var, rn, snr, exact_frequencies, y_fft


def get_pooled_frequency_weights(
        epochs: np.array = None,
        fs: float = None,
        frequencies: float = None,
        block_size: int = 5,
        weighted_average=True,
        delta_frequency: u.Quantity = 5 * u.Hz,
        power_line_frequency: u.Quantity = 50 * u.Hz) -> np.array:
    """
    Compute spectral amplitude and pooled weights for set of frequencies.
    :param epochs: time x channels x trials numpy array in the time domain
    :param fs: float indicating the sampling rate in Hz
    :param frequencies: numpy array indicating the frequency of interest
    :param block_size: integer indicating the number of trials that would be use to estimate the weights
    :param weighted_average: if false, frequency bins will not be weighted to compute mean and std
    :param delta_frequency: frequency size around each frequency used to estimate the noise
    :param power_line_frequency: frequency of local power line frequency. This will be used to prevent using
        this frequency or its multiples when performing frequency statistics
    :return: weights, complex frequencies, exact tested frequencies, estimate of residual noise and snr at those
    frequencies
    """
    epochs = set_default_unit(epochs, u.uV)
    fs = set_default_unit(fs, u.Hz)
    frequencies = set_default_unit(frequencies, u.Hz)
    delta_frequency = set_default_unit(delta_frequency, u.Hz)
    freq_axis = np.fft.rfftfreq(epochs.shape[0], 1 / fs)
    power_line_frequencies = power_line_frequency * np.arange(1,
                                                              np.round(0.5 * fs / power_line_frequency))
    _power_idx = np.array([np.argmin(np.abs(freq_axis - _freq)) for _freq in power_line_frequencies])
    _target_idx = np.array([np.argmin(np.abs(freq_axis - _freq)) for _freq in frequencies])
    # we always keep the input frequencies, even if they are multiple of line_power
    _power_idx = np.setdiff1d(_power_idx, _target_idx).astype(int)
    # get all frequencies for the analysis
    _idx_to_include_all = np.array([])
    for _idx_t, _f in enumerate(frequencies):
        # _idx_target = np.argmin(np.abs(freq_axis - _f))
        # _f_target = freq_axis[_idx_target]
        _ini_bin = np.maximum(np.argmin(np.abs(freq_axis - (_f - delta_frequency))), 0)
        _end_bin = np.minimum(np.argmin(np.abs(freq_axis - (_f + delta_frequency))), freq_axis.size - 1)
        _idx_freq = np.arange(_ini_bin, _end_bin + 1)
        _idx_to_include_all = np.concatenate((_idx_to_include_all, _idx_freq))
    _idx_to_include_all = np.unique(_idx_to_include_all)
    # remove power line bins
    _idx_to_include = np.setdiff1d(_idx_to_include_all, _power_idx).astype(int)
    _idx_excluded = np.setdiff1d(_idx_to_include, _idx_to_include_all)
    if _idx_excluded.size > 0:
        print('Excluding {:} to avoid power line harmonics'.format(
            freq_axis[_idx_excluded]))
    # print('Test frequency {:}. Noise estimation between {:} and {:}'.format(_f_target,
    #                                                                         freq_axis[_ini_bin],
    #                                                                         freq_axis[_end_bin]))

    # get target and surrounding frequency bins first
    _w, _amp, _, _rn, _snr, _exact_frequencies, y_fft = get_discrete_frequencies_weights(
        epochs=epochs,
        fs=fs,
        block_size=block_size,
        frequencies=freq_axis[_idx_to_include],
        weighted_average=weighted_average
    )
    _signal_plus_noise_var = _amp ** 2.0
    # pool across frequencies
    _var_ave = 1 / _w
    total_variance = np.mean(_var_ave, axis=0, keepdims=True)
    weights = 1 / total_variance
    # ensure same size as input epochs. All time examples are weighted the same
    weights = np.ones(epochs.shape) * weights
    pooled_rn = np.sqrt(np.mean(_rn ** 2.0, axis=0))
    pooled_snr = np.mean(_signal_plus_noise_var, axis=0) / (pooled_rn ** 2) - 1
    _idx_targets = np.array([np.argmin(np.abs(_exact_frequencies - _f)) for _f in frequencies])
    by_freq_rn = _rn[_idx_targets]
    freq_samples = y_fft[_idx_targets]
    exact_frequencies = _exact_frequencies[_idx_targets]
    by_freq_snr = _snr[_idx_targets]

    print("Weights, noise, and snr estimated by pooling {:} individual measures, each estimated with a delta of "
          "{:} around each frequency.".format(frequencies, delta_frequency))
    return weights, pooled_rn, pooled_snr, by_freq_rn, by_freq_snr, freq_samples, exact_frequencies
