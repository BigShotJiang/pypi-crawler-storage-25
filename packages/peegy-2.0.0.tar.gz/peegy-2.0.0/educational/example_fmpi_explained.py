"""
.. _tut-fmpi-explained-sim:

##################################
Fmpi explained (Simulated)
##################################

This example provides a depth insight into the Fmpi method

.. contents:: Page contents
   :local:
   :depth: 2
"""

import astropy.units as u
import numpy as np
from peegy.processing.tools.template_generator.auditory_waveforms import abr
from peegy.tools.signal_generator.noise_functions import generate_modulated_noise
from peegy.processing.tools import eeg_epoch_operators as eop
from peegy.processing.tools import epochs_processing_tools as ept
import matplotlib.pyplot as plt
from peegy.processing.statistics.eeg_statistic_tools import effective_sampling_size
import matplotlib.gridspec as gridspec
from scipy.stats import norm, chi2
import matplotlib
from tqdm import tqdm
from peegy.processing.statistics.eeg_statistic_tools import dof_from_psd
# Enable below for interactive backend
# if 'Qt5Agg' in matplotlib.rcsetup.all_backends:
#    matplotlib.use('Qt5Agg')

# %%
# The Fmpi method
# =================================================================
# The Fmpi method is based on the measurement of the F-value, which is the ratio shown in the equation below and is
# directly associated to the signal-to-noise (SNR) ratio.

# %%
# .. math::
#    :label: eq_1
#
#    SNR = \frac{\sigma_{\mathrm{s}}^2}{\sigma_{\mathrm{RN}}^2} - 1 = F - 1
#
# Here, :math:`\sigma_{\mathrm{s}}^2` is the variance of the averaged response (signal plus any residual noise),
# and :math:`\sigma_{\mathrm{RN}}^2` is the variance of the residual noise.
# The probability to reject the null-hypothesis, i.e. the probability that the F-value in a given recording is just
# obtained by chance, is given by :eq:`eq_2`

# %%
# .. math::
#    :label: eq_2
#
#    p = 1 - F_{CDF}\left( F, v_s, v_{RN}\right)

# %%
# Where :math:`F_{CDF}\left( F, v_s, v_{RN}\right)` is the cumulative distribution function of an F-distributed
# random variable with degrees of freedom (DOF) :math:`v_s`, the DOF of :math:`\sigma_{\mathrm{s}}^2`, and :math:`v_{RN}`,
# the DOF of :math:`\sigma_{\mathrm{RN}}^2`.
# The DOF can be understood as the number of independent samples (i.e., samples that share no common information) that
# contributed to the estimation of the variances in the F-ratio.


# %%
# The Fmpi method estimates :math:`v_s` and :math:`v_{RN}` by

# %%
# .. math::
#    :label: eq_3
#
#       v_s = v_1 \frac{T'}{T} \\
#       v_{RN} = v_1 \frac{\left[ \sum_{i=1}^{N}{w_i} \right]^2}{\sum_{i=1}^{N}{w_i^2}}

# %%
# Where

# %%
# .. math::
#    :label: eq_4
#
#    v_1 \approx \frac{2 \left[\sum_{i=1}^{N_\omega} \hat G_{xx}\left(\omega_i \right) \right] ^2}{
#    \sum_{i=1}^{N_\omega}  \left[ \hat G_{xx} \left(\omega_i \right) \right] ^2}

# %%
# Here, :math:`T` is the duration of each trial (or epoch) used for the analysis, and :math:`T'` is the duration of the
# analysis window which that we want to analyze :math:`(T' \leq T)`.


# %%
# .. math::
#    :label: eq_5
#
#    \hat{G}_{xx} \left( \omega \right) = \frac{2}{T} \sum_{i=1}^{N} w_i \lvert X_i \left(\omega, T \right) \lvert ^2 =
#    \frac{2}{T} \overline{\lvert X \left(\omega, T \right) \lvert ^2}

# %%
# As it can be seen, the DOF of the denominator given in :eq:`eq_3` consists two parts.
# The first part :math:`\left( v_1 \frac{T'}{T} \right)` represents the effective number of DOF within the analysis
# windows whilst the second part
# :math:`\left( \frac{\left[ \sum_{i=1}^{N}{w_i} \right]^2}{\sum_{i=1}^{N}{w_i^2}} \right)`
# corresponds to the effective DOF due to the weighting of the data.
# In other words, the effective number of epochs.
# Let's now consider these two components separately.

# %%
# ============================================
# DOF across trials: the effect of weighting
# ============================================
# First, let's consider the scenario where :math:`v_1 \frac{T'}{T} = 1`.
# This is the case when the analysis window is as long as the recorded epoch, and we have only one independent sample
# per epoch to measure :math:`\sigma_{RN}^2`.
#
# In this case, the effective DOF of the denominator depends only on the weights.
#
# Furthermore, let's also consider that the weights are calculated inversely proportional to the variance within each
# epoch (eq. :eq:`eq_6`)

# %%
# .. math::
#    :label: eq_6
#
#    \hat{\sigma}_{\mathrm{BN}_k}^2 = \frac{1}{P-1}\sum_{n=1}^{P} \left(s_k\left(n \Delta t\right) -
#    \overline{s_k\left(n \Delta t\right)}\right)^2

# %%
# Where :math:`s_k\left( t \right)` corresponds to the data of the k-trial (or epoch), P is the number of samples
# within an epoch, and :math:`\Delta t` is the sampling period.

# %%
# Let's now generate an artificial noisy signal which fluctuates overtime (non-stationary noise).

# %%
# Create synthetic ABR data with noise
# ------------------------------------
# Here, we generate 1200 trials (or epochs) of an ABR signal under the presence of background noise in which a
# quarter of the data is contaminated by a much powerful noise (5 times higher power than the baseline).


fs = 8000.0 * u.Hz
duration = 16.5 * u.ms
n_trials = 1200
source, _ = abr(fs=fs, time_length=duration)
n_samples = source.shape[0]
block_size = 100
s = source
s_std = np.std(s, axis=0)
s = np.tile(np.expand_dims(s, axis=2), (1, 1, n_trials))
desired_snr = 15.0
ini_std = 10.0 ** (-desired_snr / 20.0) * s_std * n_trials ** 0.5
theoretical_rn = ini_std / n_trials ** 0.5

noise = generate_modulated_noise(fs=fs.value,
                                 duration=source.shape[0] * n_trials / fs.value,
                                 f_noise_low=0,
                                 f_noise_high=4000,
                                 attenuation=0,
                                 n_channels=1) * u.uV

noise = ini_std * noise / np.std(noise, axis=0)
noise = eop.et_fold(noise, n_samples)

#  add non-stationary noise
for i in range(3):
    _ini = n_trials//4 + i * n_trials // 4
    _end = _ini + 100
    noise[:, :, _ini: _end] = noise[:, :, _ini: _end] * 5  # increase the noise power by 5

s[:, 0] = s[:, 0] * 0.5
data = noise + s


# %%
# The generated noisy signal is shown below

fig = plt.figure()
ax = fig.add_subplot(111)
ax.set_title('Signal + Noise')
ax.plot(np.std(data, axis=0).T)
ax.set_ylabel("RMS")
ax.set_xlabel("Trial number")


# %%
# Let's now compute the weights and plot them

ave_wwe = ept.et_mean(epochs=data,
                      weight_across_epochs=False,
                      weighted=True,
                      fs=fs)

fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(ave_wwe.weights[0, :, :].T)
ax.set_ylabel("W ")
ax.set_xlabel("Trial number")
ax.set_title('Weights')

# %%
# From the previous figure, it can be observed that the weights will be close to zero for the trials with
# a high level of noise.
# If we use weighted average to estimate the response, this is the equivalent to averaging
# approximately three quarters of all recorded trials (900 trials).
# Now, if we use the obtained weights to compute the DOF due to the weights only we obtain

ess = effective_sampling_size(ave_wwe.weights[0, ...], axis=1)
print('Effective number of DOF across epochs is: {:}'.format(ess))

# %%
# This result is much closer to 900 trials (which would be the case  if we only include the clean trials), and provides
# a good estimation to the effective number of DOF that the weights allow for when averaging the data.
# The consequence is (see figure below) that weighted average (orange line) produces a response which is
# almost unaffected by the non-stationary segments of the noise and closer to the underlying ABR response (green line)
# than when using standard unweighted average (blue line).

fig = plt.figure()
ax = fig.add_subplot(111)
time = np.arange(0, ave_wwe.average.data.shape[0]) / fs
ax.plot(time, np.mean(data, 2), label='standard average')
ax.plot(time, ave_wwe.average.data, label='weighted average')
ax.plot(time, np.mean(s, 2), label='target response')
ax.set_ylabel('Amplitude [uV]')
ax.set_xlabel('Time [s]')
ax.legend()
fig.tight_layout()

# %%
# Let's now explore the other component of equations :eq:`eq_3`,  :math:`v_1`.

# %%
# ===============================================
# DOF within trials: the effect of correlation
# ===============================================
# When estimating the F-ratio, the DOF within a given time window are given by :math:`v_1 \frac{T'}{T}`
# (see :eq:`eq_3`).
# This quantity affects the DOF of both the numerator and denominator of the F-ratio, and it tells us about the amount
# of interdependence (or correlation) among the samples used to estimate the variance within a given time window.

# %%
# Whilst its mathematical estimation is simply given by equation :eq:`eq_4`, which is very similar—in terms of form—to
# that of the weights (the square of the sum divided by sum of the squares for both equations), its interpretation can
# be abstract at first.

# %%
# To better understand the concept of interdependence or correlation, let's consider the following case.
#
# Consider an independent stationary noise, i.e., a noise where all the samples are independent of each other.
# Next, let's further filter the noisy signal using a mean filter, i.e., a filter which computes the mean
# across number of consecutive samples, and it returns the mean as the output (a mean
# filter with no overlapping between sections).
# The original noise is shown below


# define the mean filter
def mean_filter(data: np.array = None, n_samples: int = None):
    out = data.copy()
    n_chunks = np.round(data.shape[0] / n_samples).astype(int)
    for _chunk in np.arange(n_chunks):
        _ini_sample = _chunk * n_samples
        _end_sample = np.minimum(_ini_sample + n_samples, data.shape[0])
        out[_ini_sample:_end_sample, ...] = np.mean(
            data[_ini_sample:_end_sample], axis=0
        )
    return out


# generate stationary independent noise
noise = np.random.randn(source.shape[0], 1)
noise = ini_std * noise / np.std(noise, axis=0)
# plot that stationary noise
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set_title('Unfiltered noise')
ax.plot(noise)
ax.set_ylabel("Amplitude")
ax.set_xlabel("Samples")

# %%
# Now, let's filter the data with the mean filter and show the resulting data.
# This is an extreme example of correlation or interdependency, in which the points within every block of 11 samples
# are fully correlated.

# filter noise with mean filter
samples_filter = 11
data_filter_mean = mean_filter(noise, n_samples=samples_filter)

# plot that filter output
fig = plt.figure()
ax = fig.add_subplot(111)
ax.set_title('Mean filter output')
ax.plot(data_filter_mean)
ax.set_ylabel("Amplitude [A.U.]")
ax.set_xlabel("Samples")

# %%
# The question now is how correlation affects how much we know about the underlying background noise.
# Since the Fmpi method compares the ratio between the variance of the signal plus the noise
# (:math:`\sigma_{\mathrm{s}}^2`) with the variance of the residual noise (:math:`\sigma_{\mathrm{RN}}^2`), we need
# to have certainty about the statistical properties of these estimated variances.
# To better understand this, let's generate some figures and compare what the effect of correlation is.

figure = plt.figure()
gs = gridspec.GridSpec(2, 1)
ax = plt.subplot(gs[0, 0])
ax.plot(noise,
        color="gray")
ax.plot(noise,
        "o",
        markersize=3,
        color="blue")
ax.plot(np.arange(samples_filter // 2, noise.shape[0], samples_filter),
        noise[np.arange(samples_filter // 2, noise.shape[0], samples_filter), :],
        "o",
        color="red",
        markersize=3)
ax.set_ylim([-3, 3])
ax.text(
    100,
    2,
    "$\\sigma^2_{0} = \\frac{1}{N - 1} \\sum\\left( x - \\bar{x} \\right)^2$",
    color="blue",
    size=12,
)

ax.text(-0.1, 1.15,
        "A",
        transform=ax.transAxes,
        fontsize=16, fontweight='bold', va='top', ha='right')
ax.set_ylabel("Amplitude [A.U.]")
ax.set_xlabel("Samples")

ax = plt.subplot(gs[1, 0])
ax.plot(data_filter_mean,
        color="gray")
ax.plot(data_filter_mean,
        "o",
        markersize=3,
        color="blue")

ax.plot(np.arange(samples_filter // 2, noise.shape[0], samples_filter),
        data_filter_mean[np.arange(samples_filter // 2, noise.shape[0], samples_filter), :],
        "o",
        color="red",
        markersize=3)
ax.set_xlabel("Time [s]")
ax.set_xlabel("Time")
ax.text(
    100,
    2,
    "$\\sigma^2_{1} = \\frac{1}{N - 1} \\sum\\left( x - \\bar{x} \\right)^2$",
    color="blue",
    size=12,
)
ax.text(
    100,
    -2,
    "$\\sigma^2_{2} = \\frac{1}{P - 1} \\sum\\left( x - \\bar{x} \\right)^2$",
    color="red",
    size=12,
)
ax.set_ylim([-3, 3])
ax.text(-0.1, 1.15,
        "B",
        transform=ax.transAxes,
        fontsize=16, fontweight='bold', va='top', ha='right')
ax.set_ylabel("Amplitude [A.U.]")
ax.set_xlabel("Samples")

# %%
# The figure above shows two different cases.
# Panel A shows noise in which all samples are independent of each other (uncorrelated or no interdependency),
# Panel B shows the output of the mean filter using blocks of 11 samples, in which all 11 samples within a block are
# completely correlated but the blocks are uncorrelated.

# %%
# Since many readers may be used to the concept of mean and the standard error of the mean, we can first start with an
# example of the effect of correlation in the estimation of these two statistical parameters.
#
# Let's consider that we are interested in computing the mean and the standard error of the underlying noise shown in
# the previous figure.
# These are given by.

# %%
# .. math::
#    :label: eq_7
#
#    \hat{x} = \frac{1}{N}\sum_{i=1}^{N} x_i \\
#    se = \frac{\hat{\sigma}}{\sqrt{N}}

# %%
# For the independent noise (panel A), it is evident that both measurements will be more precise if we include all the
# samples (blue dots) than just a few samples (red dots).
# That is, the more the samples we use, the better the estimations are.
# In other words, by including more independent samples we learn more about the properties of the underlying noise and
# we improve the estimation of the mean and the variance.
# Next, let's compare what happens when we apply the same rationale with the highly correlated noise (panel B).
# In this case, it makes no numerical difference if we compute the mean and the standard error using all the samples
# (blue dots) or only a few independent samples (red dots).
# In fact, the two results will be almost identical.
# This is because by including more highly correlated points, we gain little (or in this case none) additional
# information about the underlying noise.
# Importantly, whilst the two results are identical, there are important implications when we need to characterize
# the underlying distribution based on a parametric model.

# %%
# When we compute the variance for the F test, we need to provide the DOF for the variance of the numerator and the
# variance of the denominator.
# If the noise was fully independent (like in Panel A), the unbiased variance
# (:math:`\sigma_{0}^2`) would have in fact :math:`N - 1` DOF.
# However, when dealing with the correlated noise in panel B, the number of DOF of the variance obtained with all the
# samples (:math:`\sigma_{1}^2`) is no longer :math:`N - 1`, but in fact :math:`P - 1`, which is the
# variance obtained by using only one independent sample from each block (red dots in panel B).

# %%
# This can be further illustrated by comparing the empirical distribution of the mean of 10000 repetitions
# with the expected normal distribution using uncorrelated and correlated noise as shown below.


# generate independent noise
n_reps = 10000
n_samples = 132
samples_filter = 11
_noise = np.random.randn(n_samples, n_reps)

# compute the mean and std for n_reps of completely independent samples
empirical_mean = np.mean(_noise, axis=0)
empirical_var = np.var(_noise, ddof=1, axis=0)

# compute the mean and std for n_reps of completely independent samples but using a fraction of points only
sparse_data = _noise[np.arange(samples_filter // 2, noise.shape[0], samples_filter), :]
empirical_mean_sparse = np.mean(sparse_data, axis=0)
empirical_var_sparse = np.var(sparse_data, ddof=1, axis=0)
n_used_samples = sparse_data.shape[0]
# filter data to generate correlation and compute the mean and std for n_reps
data_filter_mean = mean_filter(_noise, n_samples=samples_filter)
empirical_mean_filtered = np.mean(data_filter_mean, axis=0)
empirical_var_filtered = np.var(data_filter_mean, ddof=1, axis=0)

# compute sparse variance from filtered data
sparse_data_filtered = data_filter_mean[np.arange(samples_filter // 2,
                                                  data_filter_mean.shape[0], samples_filter), :]
empirical_mean_filtered_sparse = np.mean(sparse_data_filtered, axis=0)
empirical_var_filtered_sparse = np.var(sparse_data_filtered, ddof=1, axis=0)


# plot the PDF for independent noise using all samples to estimate mean and std.
figure = plt.figure()
gs = gridspec.GridSpec(3, 1)
ax = plt.subplot(gs[0, 0])
ax.hist(empirical_mean, bins=100, density=True, alpha=0.6, color='b')
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax, 1000)
p = norm.pdf(x, np.mean(empirical_mean), np.sqrt(np.mean(empirical_var) / n_samples))
ax.plot(x, p, 'k', linewidth=2, label='all samples')
ax.set_xlim(-1, 1)
ax.text(-0.1, 1.15,
        "A",
        transform=ax.transAxes,
        fontsize=16, fontweight='bold', va='top', ha='right')

# plot the PDF for independent noise using a few samples only to estimate mean and std.
# ax = plt.subplot(gs[1, 0])
ax.hist(empirical_mean_sparse, bins=100, density=True, alpha=0.6, color='r')
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax, 1000)
# plot the parametric PDF for independent samples using a few samples only
p = norm.pdf(x, np.mean(empirical_mean_sparse), np.sqrt(np.mean(empirical_var_sparse) / n_used_samples))
ax.plot(x, p, linewidth=2, color='r', label='few samples')
ax.set_xlim(-1, 1)
ax.set_ylabel('PDF')
ax.set_title('Independent samples')

ax.legend()

# plot the PDF for filtered noise using all samples
ax = plt.subplot(gs[1, 0])
ax.hist(empirical_mean.squeeze(), bins=100, density=True, alpha=0.6, color='b')
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax, 1000)
# plot the parametric PDF for filtered noise using all samples
p = norm.pdf(x, np.mean(empirical_mean_filtered), np.sqrt(np.mean(empirical_var_filtered) / n_samples))
ax.plot(x, p, 'k', linewidth=2, label='all samples')
# plot the parametric PDF for filtered noise using the effective number of independent samples
p = norm.pdf(x, np.mean(empirical_mean_filtered), np.sqrt(np.mean(empirical_var_filtered) / n_used_samples))
ax.plot(x, p, 'g', linewidth=2, label='corrected DOF')
ax.set_xlim(-1, 1)
ax.set_title('Correlated samples (mean filter)')
ax.set_ylabel('PDF')
ax.legend()
ax.text(-0.1, 1.15,
        "B",
        transform=ax.transAxes,
        fontsize=16, fontweight='bold', va='top', ha='right')
ax.set_xlabel('Mean values')
ymin, ymax = ax.get_ylim()
figure.tight_layout()

# plot the PDF for sparse filtered noise using all samples
ax = plt.subplot(gs[2, 0])
ax.hist(empirical_mean.squeeze(), bins=100, density=True, alpha=0.6, color='b')
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax, 1000)
# plot the parametric PDF for filtered noise using all samples
p = norm.pdf(x, np.mean(empirical_mean_filtered_sparse),
             np.sqrt(np.mean(empirical_var_filtered_sparse) / sparse_data_filtered.shape[0]))
ax.plot(x, p, 'k', linewidth=2, label='all samples')
ax.set_xlim(-1, 1)
ax.set_ylim(ymin, ymax)
ax.set_title('Correlated samples (mean filter) with one sample per correlated block')
ax.set_ylabel('PDF')
ax.legend()
ax.text(-0.1, 1.15,
        "C",
        transform=ax.transAxes,
        fontsize=16, fontweight='bold', va='top', ha='right')
ax.set_xlabel('Mean values')
figure.tight_layout()

# %%
# In the example above, each trial consisted of 132 samples.
# That is, the maximum number of independent samples contributing to the mean is bounded by 132.
# When all samples are independent (panel A) the empirical distribution—shown in terms of the
# probability density function (PDF)—of the 10000 means (blue histogram) fits well the underlying theoretical normal
# distribution generating those samples (solid black line in panel A), i.e., a normal distribution with zero mean and
# the standard deviation given by :math:`\sigma / \sqrt{132}` (eq. :eq:`eq_7`).
#
# When taking only a few independent samples (12 samples), the distribution becomes wider, reflecting
# the lost of information or certainty about the true mean (red histogram and line in panel A).
# When we apply the mean filter, and we include all the samples to compute the mean (blue histogram
# in panel B), we can now see that the theoretical distribution (black solid line) obtained under the assumption of
# independence between samples does no longer fit the empirical data.
# If we instead use the effective number of independent samples (the total number of red samples in the
# time series of the filtered noise), we obtain a much better fit with the sampled histogram (green line in panel B).
# Finally, when we compute the distribution of the empirical mean including only one independent sample per block
# (red dots in filtered waveform) we can see that the distribution (panel C) is not different of that including all the
# samples (panel B), reflecting that the amount of information did not change by including only the independent samples.

# %%
# Effective number of DOF and its relation with the spectrum
# ===========================================================
# The Fmpi method uses equation :eq:`eq_4` to estimate the effective number of independent samples for the variance
# calculation within an epoch.
# This equation tells us that the number of independent samples can be estimated by the square of the sum divided by
# the sum of the squares of the power spectral density (PSD).
# This is very similar to the equation used to compute the effective number of epochs from the weights.

# %%
# To better understand why is it that we can estimate the effective number of DOF from the PSD,
# it is easier to look at extreme examples.


# generate independent noise
n_trials = 10000
_noise_0 = np.random.randn(n_samples, n_trials)
time = np.arange(_noise_0.shape[0])[:, None] / fs
phase = np.ones(_noise_0.shape) * np.random.rand(1, _noise_0.shape[1]) * 2 * np.pi
_sin_signal_1 = np.sin(2 * np.pi * u.rad * 200 * u.Hz * time + phase * u.rad)
_sin_signal_2 = np.sin(2 * np.pi * u.rad * 2000 * u.Hz * time + phase * u.rad)
_scaled_1 = (4 * np.mean(np.std(_noise_0, axis=0)) / np.std(_sin_signal_1) * _sin_signal_1 +
             1 * np.mean(np.std(_noise_0, axis=0)) / np.std(_sin_signal_2) * _sin_signal_2)
_scaled_2 = (1 * np.mean(np.std(_noise_0, axis=0)) / np.std(_sin_signal_1) * _sin_signal_1 +
             4 * np.mean(np.std(_noise_0, axis=0)) / np.std(_sin_signal_2) * _sin_signal_2)

_noise_1 = _noise_0 + _scaled_1
_noise_2 = _noise_0 + _scaled_2
# compute the PSD
psd_0 = np.mean(np.abs(np.fft.rfft(_noise_0, axis=0)), axis=1) ** 2 / (_noise_0.shape[0] ** 2)
psd_1 = np.mean(np.abs(np.fft.rfft(_noise_1, axis=0)), axis=1) ** 2 / (_noise_1.shape[0] ** 2)
psd_2 = np.mean(np.abs(np.fft.rfft(_noise_2, axis=0)), axis=1) ** 2 / (_noise_2.shape[0] ** 2)
mean_0 = np.mean(_noise_0, axis=1)
mean_1 = np.mean(_noise_1, axis=1)
mean_2 = np.mean(_noise_2, axis=1)

freq = np.arange(0, psd_0.shape[0]) * fs / _noise_0.shape[0]

figure = plt.figure()
gs = gridspec.GridSpec(2, 1)
ax = plt.subplot(gs[0, 0])
ax.plot(freq, 10 * np.log10(psd_0), 'k', label='white noise')
ax.plot(freq, 10 * np.log10(psd_1), 'r', label='low-frequency noise')
ax.plot(freq, 10 * np.log10(psd_2), 'b', label='high-frequency noise')
ax.set_xlim([0, fs.value / 2])
ax.set_xlabel('Frequency [Hz]')
ax.set_ylabel('PSD [A.U./ Hz] dB')
ax.text(-0.1, 1.15,
        "A",
        transform=ax.transAxes,
        fontsize=16, fontweight='bold', va='top', ha='right')
ax.legend()
ax = plt.subplot(gs[1, 0])
ax.plot(time, mean_0, 'k', label='white noise')
ax.plot(time, mean_1, 'r', label='low-frequency noise')
ax.plot(time, mean_2, 'b', label='high-frequency noise')
ax.text(-0.1, 1.15,
        "B",
        transform=ax.transAxes,
        fontsize=16, fontweight='bold', va='top', ha='right')
ax.set_xlabel('Time [s]')
ax.set_ylabel('Amplitude [A.U.]')
figure.tight_layout()

# %%
# The figure above shows the PSD (panel A) for a white noise (black line) in which all 132 samples
# are independent, and two different coloured noises (blue and red lines).
# 'Coloured noise' means that the energy of the noise is not equal across frequencies.
# The red line correspond to additive noise in which two random sinusoidal signals (random phases per trial) at 200
# and 2000 Hz were added to a stationary white noise.
# The energy of the low-frequency noise is 4 times larger than for the high frequency noise component, thus referred as
# 'low-frequency noise'.
# The blue line corresponds to a 'high-frequency noise' which involved the same manipulations, but in this case the
# high-frequency noise was 4 times larger than the low-frequency noise component.
# Panel B shows the resulting waveforms averaging 10000 trials for the three noise types.

# %%
# What is important to understand here is that just like in the case of the mean filter, the presence of strong
# periodicity in the noise, implies strong correlation among samples.
# For example, if we focus on the time-domain low-frequency waveform (red line, panel B), neighbouring samples are
# very similar in terms of amplitude, which introduces a similar loss of independence as shown with the mean filter.
# This will, therefore reduce the effective number of DOF.
# Furthermore, the amount of new independent information after one period will be rather negligible as the periodicity
# per se implies that samples spaced by one period are highly correlated to each other.

# %%
# Note that if the final averaged waveforms were those shown in panel B, the calculation of the variance for the F-test
# (:math:`\sigma_{\mathrm{s}}^2` in :eq:`eq_1`) will be largely dominated by the strength of the noise at those specific
# frequencies, i.e.,  200-Hz energy in the case of 'low-frequency noise' (red line in panel B) or 2000-Hz in the case of
# 'high-frequency noise' (blue line in panel B).
# On the contrary, for the white noise example, where all frequencies have the same energy, the variance will reflex
# the even contribution of all frequencies.

# %%
# Let's now estimate the distribution of the variance for 1000 repetitions of the previous case.

n_repetitions = 1000
n_trials = 10000
var_0 = np.zeros((n_repetitions, ))
var_1 = np.zeros((n_repetitions, ))
var_2 = np.zeros((n_repetitions, ))

time = np.arange(_noise_0.shape[0])[:, None] / fs
freq = np.arange(0, _noise_0.shape[0]) * fs / _noise_0.shape[0]
n_samples = _noise_0.shape[0]
for i in tqdm(range(n_repetitions)):
    _noise_0 = np.random.randn(n_samples, n_trials)
    _noise_0 = _noise_0 - np.mean(_noise_0, axis=0, keepdims=True)
    phase = np.ones(_noise_0.shape) * np.random.rand(1, _noise_0.shape[1]) * 2 * np.pi
    _sin_signal_1 = np.sin(2 * np.pi * u.rad * 200 * u.Hz * time + phase * u.rad)
    _sin_signal_2 = np.sin(2 * np.pi * u.rad * 2000 * u.Hz * time + phase * u.rad)
    _scaled_1 = (4 * np.mean(np.std(_noise_0, axis=0)) / np.std(_sin_signal_1) * _sin_signal_1 +
                 1 * np.mean(np.std(_noise_0, axis=0)) / np.std(_sin_signal_2) * _sin_signal_2)
    _scaled_2 = (1 * np.mean(np.std(_noise_0, axis=0)) / np.std(_sin_signal_1) * _sin_signal_1 +
                 4 * np.mean(np.std(_noise_0, axis=0)) / np.std(_sin_signal_2) * _sin_signal_2)

    _noise_1 = _noise_0 + _scaled_1
    _noise_2 = _noise_0 + _scaled_2
    # compute the PSD
    mean_0 = np.mean(_noise_0, axis=1)
    mean_1 = np.mean(_noise_1, axis=1)
    mean_2 = np.mean(_noise_2, axis=1)
    var_0[i] = np.var(mean_0, axis=0, ddof=1)
    var_1[i] = np.var(mean_1, axis=0, ddof=1)
    var_2[i] = np.var(mean_2, axis=0, ddof=1)

# estimate PDF once only

psd_0 = np.mean(np.abs(np.fft.rfft(_noise_0, axis=0)), axis=1) ** 2 / (n_samples ** 2)
psd_1 = np.mean(np.abs(np.fft.rfft(_noise_1, axis=0)), axis=1) ** 2 / (n_samples ** 2)
psd_2 = np.mean(np.abs(np.fft.rfft(_noise_2, axis=0)), axis=1) ** 2 / (n_samples ** 2)

# convert variance to Chi² distribution assuming that all samples are independent
chi_0 = (n_samples - 1) * var_0 / np.mean(var_0)
chi_1 = (n_samples - 1) * var_1 / np.mean(var_1)
chi_2 = (n_samples - 1) * var_2 / np.mean(var_2)

# estimate DOF from the PSD
dof_0 = dof_from_psd(psd_noise=psd_0[:, None],
                     psd_noise_n=n_samples)
dof_1 = dof_from_psd(psd_noise=psd_1[:, None],
                     psd_noise_n=n_samples)
dof_2 = dof_from_psd(psd_noise=psd_2[:2, None],
                     psd_noise_n=n_samples)

# convert variance to Chi² distribution using the effective number of DOF
effective_chi_0 = dof_0 * var_0 / np.mean(var_0)
effective_chi_1 = dof_1 * var_1 / np.mean(var_1)
effective_chi_2 = dof_2 * var_2 / np.mean(var_2)

# %%
# Let's plot the results
#

# plot sampled distributions and PDFs based on DOF for all noises
figure = plt.figure()
gs = gridspec.GridSpec(3, 2)
# independent data
ax = plt.subplot(gs[0, 0])
ax.hist(chi_0, density=True, bins='auto', histtype='stepfilled', alpha=0.2, color='r')
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax, 1000)
p = chi2(n_samples)
ax.plot(x, p.pdf(x), 'k', linewidth=2, label='DOF: {:.1f}'.format(n_samples - 1))
ax.set_ylabel('PDF')
ax.set_title(r'Uncorrected DOF \n independent noise')
ax.legend()

ax = plt.subplot(gs[0, 1])
ax.hist(effective_chi_0, density=True, bins='auto', histtype='stepfilled', alpha=0.2)
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax, 1000)
p = chi2(dof_0)
ax.plot(x, p.pdf(x), 'k', linewidth=2, label='DOF: {:.1f}'.format(dof_0.squeeze()))
ax.set_ylabel('PDF')
ax.set_title(r'Corrected DOF \n independent noise')
ax.legend()


# noise 1
ax = plt.subplot(gs[1, 0])
ax.hist(chi_1, density=True, bins='auto', histtype='stepfilled', alpha=0.2, color='r')
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax, 1000)
p = chi2(n_samples)
ax.plot(x, p.pdf(x), 'k', linewidth=2, label='DOF: {:.1f}'.format(n_samples - 1))
ax.set_ylabel('PDF')
ax.set_title(r'Uncorrected DOF \n low-frequency noise')
ax.legend()


ax = plt.subplot(gs[1, 1])
ax.hist(effective_chi_1, density=True, bins='auto', histtype='stepfilled', alpha=0.2)
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax, 1000)
p = chi2(dof_1)
ax.plot(x, p.pdf(x), 'k', linewidth=2, label='DOF: {:.1f}'.format(dof_1.squeeze()))
ax.set_ylabel('PDF')
ax.set_title(r'Corrected DOF \n low-frequency noise')
ax.legend()


# noise 2
ax = plt.subplot(gs[2, 0])
ax.hist(chi_2, density=True, bins='auto', histtype='stepfilled', alpha=0.2, color='r')
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax, 1000)
p = chi2(n_samples)
ax.plot(x, p.pdf(x), 'k', linewidth=2, label='DOF: {:.1f}'.format(n_samples - 1))
ax.set_ylabel('PDF')
ax.set_xlabel(r'$\chi^2$')
ax.set_title(r'Uncorrected DOF \n high-frequency noise')
ax.legend()


ax = plt.subplot(gs[2, 1])
ax.hist(effective_chi_2, density=True, bins='auto', histtype='stepfilled', alpha=0.2)
xmin, xmax = ax.get_xlim()
x = np.linspace(xmin, xmax, 1000)
p = chi2(dof_2)
ax.plot(x, p.pdf(x), 'k', linewidth=2, label='DOF: {:.1f}'.format(dof_2.squeeze()))
ax.set_ylabel('PDF')
ax.set_xlabel(r'$\chi^2$')
ax.set_title(r'Corrected DOF \n high-frequency noise')
ax.legend()
figure.tight_layout()

# %%
# The figure above shows the distribution of the variance (converted to a :math:`\chi^2` variable) either assuming that
# all the samples are independent (left column) or by using the estimated DOF based on equation :eq:`eq_4`.
# It can be observed that for white noise (top row), the assumption of independence of all samples is correct, and
# the histogram of the sampled data fits well the :math:`\chi^2` (the theoretical parametric function describing the
# distribution of the sampled variance) with 131 DOF (remember that we have N=132 samples to estimate the unbiased
# variance with N - 1 DOF).
# However, the histograms and the parametric :math:`\chi^2` (black solid line) do not agree under the assumption of
# independence for low-frequency or high-frequency noise (middle and bottom rows, left column).
# This is not the case when we estimate the corrected DOF (eq. :eq:`eq_3`, accounting for correlation within a trial),
# where we see a much accurate match between the empirical and the parametric :math:`\chi^2` PDF using the corrected
# DOF.

# %%
# Summary
# ===================
# The take-home messages are:
#

# %%
# * Uneven energy in the spectrum of the underlying noise and/or filtering will increase the amount of interdependency
#   or correlation in the data.
#
# * Correlation in the data will affect (reduce) the effective number of 'independent samples' or DOF contributing to
#   the estimation of the variances used to obtain the F-value (the variance of the averaged response and the variance
#   of the residual noise).
#
# * Non-stationary noise will also reduce the effective number of trials contributing to the final average.
#
# * The Fmpi method provides an effective means to estimate both the effective number of independent samples within a
#   trial and the effective number of trials in the data, thus allowing for a much better parametrization of the
#   statistic (F-value) used to assess the presence of a neural response.
