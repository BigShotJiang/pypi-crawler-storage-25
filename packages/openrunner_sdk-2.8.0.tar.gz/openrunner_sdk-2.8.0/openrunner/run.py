"""Run lifecycle class -- init, log, finish, properties.

The Run object manages:
- API client connection
- Write buffer for non-blocking metric logging
- Background sender thread for flush + heartbeat
- Config and Summary objects
- Step counter with W&B-compatible semantics
- Metric definitions (custom x-axes and summary aggregation via define_metric)
"""

from __future__ import annotations

import fnmatch
import logging
import secrets
import string
import sys
from datetime import datetime, timezone
from typing import Any

from openrunner.api_client import APIClient
from openrunner.artifact import Artifact
from openrunner.buffer import WriteBuffer
from openrunner.cache import ArtifactCache
from openrunner.config import Config
from openrunner.environment import capture_environment
from openrunner.git_info import capture_git_info
from openrunner.media import (
    Audio,
    AudioComparison,
    BoundingBoxes2D,
    Embedding,
    Histogram,
    Html,
    Image,
    MatplotlibFigure,
    Molecule,
    Plotly,
    PlotlyChart,
    PointCloud3D,
    SpectrogramImage,
    Table,
    Transcript,
    Video,
)
from openrunner.offline import OfflineStorage
from openrunner.sender import Sender
from openrunner.wal import WriteAheadLog
from openrunner.settings import SDKSettings
from openrunner.summary import Summary

logger = logging.getLogger("openrunner")

_ALPHABET = string.ascii_lowercase + string.digits


class _TeeWriter:
    """Wraps an IO stream to capture output while still writing to the original.

    Each line is buffered and sent to the Sender's console log buffer
    with a timestamp and stream identifier (stdout or stderr).
    """

    def __init__(self, original, stream_name: str, sender) -> None:
        self._original = original
        self._stream_name = stream_name
        self._sender = sender
        self._line_buffer = ""

    def write(self, text: str) -> int:
        self._original.write(text)
        # Buffer and split lines
        self._line_buffer += text
        while "\n" in self._line_buffer:
            line, self._line_buffer = self._line_buffer.split("\n", 1)
            if line:  # skip empty lines from trailing newlines
                ts = datetime.now(timezone.utc).isoformat()
                self._sender.add_console_line(ts, self._stream_name, line)
        return len(text)

    def flush(self) -> None:
        self._original.flush()
        # Flush partial line if any
        if self._line_buffer:
            ts = datetime.now(timezone.utc).isoformat()
            self._sender.add_console_line(ts, self._stream_name, self._line_buffer)
            self._line_buffer = ""

    def __getattr__(self, name):
        return getattr(self._original, name)


class _LogCaptureHandler(logging.Handler):
    """Captures Python logging output and sends it to OpenRunner console logs.

    This catches output from frameworks that use `logging` instead of `print()`
    (HuggingFace Transformers, PyTorch Lightning, etc.)
    """

    def __init__(self, sender) -> None:
        super().__init__()
        self._sender = sender
        # Don't capture openrunner's own logs to avoid recursion
        self.addFilter(lambda record: not record.name.startswith("openrunner"))

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            ts = datetime.now(timezone.utc).isoformat()
            stream = "stderr" if record.levelno >= logging.WARNING else "stdout"
            self._sender.add_console_line(ts, stream, msg)
        except Exception:
            pass


def _generate_run_id() -> str:
    """Generate a W&B-style 8-character run ID."""
    return "".join(secrets.choice(_ALPHABET) for _ in range(8))


def _parse_fork_spec(spec: str) -> tuple[str, int | None]:
    """Parse a fork/resume spec: 'run_id?_step=N' or just 'run_id'.

    Returns (run_id, step) where step may be None.
    """
    if "?_step=" in spec:
        run_id, step_str = spec.split("?_step=", 1)
        return run_id, int(step_str)
    return spec, None


class Run:
    """An experiment run with lifecycle management.

    Created by ``openrunner.init()``, provides ``log()`` and ``finish()`` methods.
    The Run starts a background sender thread that flushes buffered metrics
    to the server and sends heartbeats.
    """

    def __init__(
        self,
        project: str,
        name: str | None = None,
        config_dict: dict[str, Any] | None = None,
        tags: list[str] | None = None,
        notes: str | None = None,
        group: str | None = None,
        job_type: str | None = None,
        run_id: str | None = None,
        settings: SDKSettings | None = None,
        resume: bool | str | None = None,
        fork_from: str | None = None,
        resume_from: str | None = None,
        allow_val_change: bool = True,
    ) -> None:
        # Parse "org/project" format (like W&B's "entity/project")
        if "/" in project:
            self._org, self._project = project.split("/", 1)
        else:
            self._org = None
            self._project = project
        self._name = name
        self._tags = tags
        self._notes = notes
        self._group = group
        self._job_type = job_type

        # Internal state
        self._summary = Summary()
        self._buffer = WriteBuffer()
        self._step = 0
        self._state = "running"
        self._artifact_cache = ArtifactCache()
        self._offline_storage: OfflineStorage | None = None
        self._metric_definitions: dict[str, dict] = {}
        self._start_time = datetime.now(timezone.utc)
        self._sweep_id: str | None = None
        self._alert_cooldowns: dict[str, float] = {}

        # Settings
        settings = settings or SDKSettings()

        # Git info
        git_info = capture_git_info()

        # Environment capture (Python, OS, packages, GPU, CUDA)
        self._environment = capture_environment()

        # API client
        self._client = APIClient(
            base_url=settings.base_url,
            api_key=settings.api_key or "",
        )

        # -- Resume handling --------------------------------------------------
        resumed_from_id: str | None = None
        merged_config = dict(config_dict) if config_dict else {}

        if fork_from:
            # Fork from an existing run: "run_id?_step=N" or just "run_id"
            parent_id, fork_step = _parse_fork_spec(fork_from)
            parent_data = self._client.get_run(parent_id)
            if parent_data is None:
                raise RuntimeError(
                    f"Cannot fork: run '{parent_id}' not found"
                )

            # Create a new run with fresh ID
            self._id = _generate_run_id()
            resumed_from_id = parent_id
            parent_config = parent_data.get("config", {}) or {}
            merged_config = {**parent_config, **merged_config}

            # Copy metrics up to the specified step on server side
            result = self._client.fork_run(parent_id, fork_step)
            if result and result.get("new_run_id"):
                self._id = result["new_run_id"]

            # Set step counter past the fork point
            if fork_step is not None:
                self._step = fork_step + 1
            else:
                max_step = self._client.get_run_max_step(parent_id)
                self._step = max_step + 1

        elif resume_from:
            # Resume from a specific step: "run_id?_step=N" or just "run_id"
            parent_id, resume_step = _parse_fork_spec(resume_from)
            parent_data = self._client.get_run(parent_id)
            if parent_data is None:
                raise RuntimeError(
                    f"Cannot resume_from: run '{parent_id}' not found"
                )

            # Continue as the same run ID
            self._id = parent_id
            resumed_from_id = parent_id
            parent_config = parent_data.get("config", {}) or {}
            merged_config = {**parent_config, **merged_config}

            # Truncate history at the specified step
            if resume_step is not None:
                self._client.truncate_run_history(parent_id, resume_step)
                self._step = resume_step + 1
            else:
                max_step = self._client.get_run_max_step(parent_id)
                self._step = max_step + 1

        elif resume:
            parent_id = run_id
            parent_data = self._client.get_run(parent_id) if parent_id else None

            if parent_data is not None:
                # Parent found: generate new ID, merge config, offset steps
                self._id = _generate_run_id()
                resumed_from_id = parent_id
                parent_config = parent_data.get("config", {}) or {}
                merged_config = {**parent_config, **merged_config}
                max_step = self._client.get_run_max_step(parent_id)
                self._step = max_step + 1
            elif resume == "must":
                raise RuntimeError(
                    f"Cannot resume: run '{parent_id}' not found"
                )
            else:
                # resume=True or "allow" with missing parent: fresh run
                self._id = run_id or _generate_run_id()
        else:
            self._id = run_id or _generate_run_id()

        self._name = self._name or self._id
        self._config = Config(merged_config or None, allow_val_change=allow_val_change)

        # -- Offline mode -----------------------------------------------------
        if settings.mode == "offline":
            self._offline_storage = OfflineStorage(
                self._id, base_dir=settings.offline_dir
            )
            self._offline_storage.write_meta({
                "project": self._project,
                "name": self._name,
                "tags": self._tags,
                "notes": self._notes,
                "group": self._group,
                "job_type": self._job_type,
            })
            self._offline_storage.write_config(self._config.as_dict())
        else:
            # Create run on server (config sent at init, SDK-12)
            payload: dict[str, Any] = {
                "id": self._id,
                "project": self._project,
                "org": self._org,
                "display_name": self._name,
                "config": self._config.as_dict(),
                "tags": self._tags,
                "notes": self._notes,
                "group_name": self._group,
                "job_type": self._job_type,
            }
            if git_info is not None:
                payload["git_info"] = git_info
            if self._environment is not None:
                payload["environment"] = self._environment
            if resumed_from_id is not None:
                payload["resumed_from_id"] = resumed_from_id

            self._client.create_run(payload)

        # Write-ahead log for crash recovery (online mode only)
        self._wal: WriteAheadLog | None = None
        if self._offline_storage is None:
            self._wal = WriteAheadLog(self._id)

        # Start background sender
        self._sender = Sender(
            buffer=self._buffer,
            client=self._client,
            run_id=self._id,
            system_metrics_enabled=settings.system_metrics_enabled,
            offline_storage=self._offline_storage,
            wal=self._wal,
        )
        self._sender.start()

        # Inject GPU info into config if available
        if self._sender._system_metrics is not None:
            gpu_info = self._sender._system_metrics.gpu_info
            if gpu_info:
                self._config.update({"_system": gpu_info})

        # Console log capture: redirect stdout/stderr through TeeWriter
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr
        sys.stdout = _TeeWriter(sys.stdout, "stdout", self._sender)
        sys.stderr = _TeeWriter(sys.stderr, "stderr", self._sender)

        # Also capture Python logging output (used by HuggingFace, PyTorch, etc.)
        self._log_handler = _LogCaptureHandler(self._sender)
        logging.root.addHandler(self._log_handler)

        # Rich console output at init (like W&B)
        if not settings.quiet:
            url = self.get_url()
            print(f"openrunner: Run {self._id} initialized", file=sys.stderr)
            print(f"openrunner: View run at: {url}", file=sys.stderr)
            if self._config and self._config.as_dict():
                preview = dict(list(self._config.as_dict().items())[:5])
                print(f"openrunner: Config: {preview}", file=sys.stderr)
            if self._tags:
                print(f"openrunner: Tags: {self._tags}", file=sys.stderr)

    # -- Properties -----------------------------------------------------------

    @property
    def should_stop(self) -> bool:
        """True if the server has requested this run to stop."""
        return self._sender._stop_requested

    @property
    def id(self) -> str:
        """The unique run ID (8-char alphanumeric)."""
        return self._id

    @property
    def name(self) -> str:
        """The display name of the run."""
        return self._name

    @property
    def project(self) -> str:
        """The project name."""
        return self._project

    @property
    def config(self) -> Config:
        """The run's hyperparameter config."""
        return self._config

    @property
    def summary(self) -> Summary:
        """The run's summary metrics."""
        return self._summary

    @property
    def entity(self) -> str | None:
        """The entity (org) -- None for now."""
        return None

    @property
    def url(self) -> str:
        """Constructed URL to the run."""
        return f"{self._client._client.base_url}/runs/{self._id}"

    @property
    def start_time(self) -> datetime:
        """The UTC timestamp when the run was created."""
        return self._start_time

    @property
    def sweep_id(self) -> str | None:
        """The sweep ID if running inside a sweep, else None."""
        return self._sweep_id

    @property
    def dir(self) -> str:
        """Local directory for run artifacts."""
        import os
        return os.path.join(os.getcwd(), ".openrunner", self._id)

    @property
    def path(self) -> tuple[str, str, str]:
        """The (entity, project, run_id) tuple."""
        return (self._org or "", self._project, self._id)

    def get_url(self) -> str:
        """Construct the full URL to this run's page."""
        settings = SDKSettings()
        base = settings.base_url.replace("/api/v1", "")
        return f"{base}/{self._org or ''}/{self._project}/runs/{self._id}"

    def get_project_url(self) -> str:
        """Construct the full URL to this run's project page."""
        settings = SDKSettings()
        base = settings.base_url.replace("/api/v1", "")
        return f"{base}/{self._org or ''}/{self._project}/runs"

    # -- Metric definitions ---------------------------------------------------

    def define_metric(
        self,
        name: str,
        step_metric: str | None = None,
        step_sync: bool | None = None,
        summary: str | None = None,
        goal: str | None = None,
        hidden: bool = False,
        overwrite: bool = False,
    ) -> None:
        """Define how a metric is tracked and summarized.

        Supports glob patterns (e.g., ``"train/*"``) that apply to all
        matching metric keys.

        Args:
            name: Metric key name or glob pattern (e.g., ``"train/*"``).
            step_metric: Use this metric's value as the x-axis instead of ``_step``.
            step_sync: If True, sync step values with the step_metric.
            summary: Aggregation mode for the summary: ``"min"``, ``"max"``,
                ``"mean"``, ``"last"``, ``"best"``, ``"copy"``, or ``"none"``.
            goal: ``"minimize"`` or ``"maximize"`` -- used with ``summary="best"``.
            hidden: If True, the frontend should not render a chart for this metric.
            overwrite: If True, replace any existing definition for this name.
        """
        if name in self._metric_definitions and not overwrite:
            return

        definition: dict = {}
        if step_metric is not None:
            definition["step_metric"] = step_metric
        if step_sync is not None:
            definition["step_sync"] = step_sync
        if summary is not None:
            definition["summary"] = summary
        if goal is not None:
            definition["goal"] = goal
        if hidden:
            definition["hidden"] = True

        self._metric_definitions[name] = definition

        # Configure summary aggregation if specified
        if summary is not None:
            self._summary._set_aggregation(name, summary, goal)

        # Send to server (merge on server side)
        if self._offline_storage is None:
            self._client.update_run(
                self._id,
                {"metric_definitions": {name: definition}},
            )

    def define_computed_metric(self, name: str, expression: str) -> None:
        """Define a computed metric from an expression.

        Supports basic arithmetic on existing metrics:
        - ``"train/loss - val/loss"`` computes the difference
        - ``"accuracy * 100"`` scales a metric
        - ``"loss / initial_loss"`` normalizes

        The expression is evaluated client-side using logged metric values
        at each step.

        Args:
            name: Name for the computed metric (e.g., ``"loss_gap"``).
            expression: Arithmetic expression referencing other metric keys
                and operators ``+``, ``-``, ``*``, ``/``.
        """
        definition = {
            "computed": True,
            "expression": expression,
        }
        self._metric_definitions[name] = definition

        # Send to server (merge on server side)
        if self._offline_storage is None:
            self._client.update_run(
                self._id,
                {"metric_definitions": {name: definition}},
            )

    def _resolve_metric_def(self, key: str) -> dict | None:
        """Resolve the metric definition for a key, checking exact then glob."""
        # Exact match first
        if key in self._metric_definitions:
            return self._metric_definitions[key]
        # Glob match
        for pattern, defn in self._metric_definitions.items():
            if "*" in pattern or "?" in pattern or "[" in pattern:
                if fnmatch.fnmatch(key, pattern):
                    # Apply summary aggregation for newly matched keys
                    if "summary" in defn and key not in self._summary._aggregation:
                        self._summary._set_aggregation(
                            key, defn["summary"], defn.get("goal")
                        )
                    return defn
        return None

    # -- Logging --------------------------------------------------------------

    def log(
        self,
        data: dict[str, Any],
        step: int | None = None,
        commit: bool = True,
    ) -> None:
        """Log metrics to the buffer.

        Detects Image and Table values and routes them to background
        media upload via the sender thread, keeping log() non-blocking.

        Args:
            data: Dict of metric key-value pairs (may include Image/Table).
            step: Explicit step value. If None, uses internal counter.
            commit: If True (default), increment the step counter.
        """
        current_step = step if step is not None else self._step
        timestamp = datetime.now(timezone.utc).isoformat()

        for key, value in data.items():
            if isinstance(value, Image):
                # Queue media upload (non-blocking -- sender handles serialization)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "image",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_image_obj": value,
                })
            elif isinstance(value, Table):
                # Queue table upload (non-blocking, inline JSONB)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "table",
                    "key": key,
                    "step": current_step,
                    "_table_data": value._serialize(),
                })
            elif isinstance(value, Html):
                # Queue HTML data (inline JSONB, no S3 upload)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "html",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_html_data": value._serialize(),
                })
            elif isinstance(value, Audio):
                # Queue audio upload (sender serializes to WAV)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "audio",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_audio_obj": value,
                })
            elif isinstance(value, Video):
                # Queue video upload (sender serializes to MP4/WebM)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "video",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_video_obj": value,
                })
            elif isinstance(value, Histogram):
                # Queue histogram data (inline JSONB, no S3)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "histogram",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_histogram_data": value._serialize(),
                })
            elif isinstance(value, PlotlyChart):
                # Enhanced Plotly: JSON + optional static PNG (inline JSONB)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "plotly",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_plotly_data": value._serialize(),
                })
            elif isinstance(value, Plotly):
                # Queue plotly figure (inline JSONB, no S3)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "plotly",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_plotly_data": value._serialize(),
                })
            elif isinstance(value, MatplotlibFigure):
                # Capture matplotlib figure as PNG image
                self._buffer.put({
                    "_media": True,
                    "_media_type": "image",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_image_obj": value,
                })
            elif isinstance(value, PointCloud3D):
                # Queue point cloud data (inline JSONB, no S3)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "point_cloud_3d",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_point_cloud_data": value._serialize(),
                })
            elif isinstance(value, Embedding):
                # Queue embedding data (inline JSONB, no S3)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "embedding",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_embedding_data": value._serialize(),
                })
            elif isinstance(value, Transcript):
                # Queue transcript data (inline JSONB)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "transcript",
                    "key": key,
                    "step": current_step,
                    "caption": value._text[:100] if value._text else None,
                    "_transcript_data": value._serialize(),
                })
                # Also log linked audio if attached
                if value._audio is not None:
                    self._buffer.put({
                        "_media": True,
                        "_media_type": "audio",
                        "key": f"{key}/audio",
                        "step": current_step,
                        "caption": value._audio.caption,
                        "_audio_obj": value._audio,
                    })
            elif isinstance(value, AudioComparison):
                # Queue comparison metadata (inline JSONB)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "audio_comparison",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_comparison_data": value._serialize(),
                })
                # Upload reference and synthesized audio as separate media
                if value._reference is not None:
                    self._buffer.put({
                        "_media": True,
                        "_media_type": "audio",
                        "key": f"{key}/reference",
                        "step": current_step,
                        "caption": "Reference",
                        "_audio_obj": value._reference,
                    })
                if value._synthesized is not None:
                    self._buffer.put({
                        "_media": True,
                        "_media_type": "audio",
                        "key": f"{key}/synthesized",
                        "step": current_step,
                        "caption": "Synthesized",
                        "_audio_obj": value._synthesized,
                    })
            elif isinstance(value, SpectrogramImage):
                # Log as a regular image via the rendered Image object
                img = value._get_image()
                self._buffer.put({
                    "_media": True,
                    "_media_type": "image",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_image_obj": img,
                })
            elif isinstance(value, BoundingBoxes2D):
                # Queue bbox overlay (image bytes + JSON box data)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "bounding_boxes_2d",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_bbox_obj": value,
                })
            elif isinstance(value, Molecule):
                # Queue molecule data (inline JSONB, no S3)
                self._buffer.put({
                    "_media": True,
                    "_media_type": "molecule",
                    "key": key,
                    "step": current_step,
                    "caption": value.caption,
                    "_molecule_data": value._serialize(),
                })
            else:
                # Regular metric
                self._summary._auto_update({key: value})

                # Resolve step_metric from metric definitions
                metric_step = current_step
                metric_def = self._resolve_metric_def(key)
                if metric_def is not None:
                    sm = metric_def.get("step_metric")
                    if sm is not None and sm in data:
                        metric_step = data[sm]

                self._buffer.put({
                    "key": key,
                    "value": value,
                    "step": metric_step,
                    "timestamp": timestamp,
                })

        # Increment step counter on commit
        if commit and step is None:
            self._step += 1

    # -- Artifacts ------------------------------------------------------------

    def log_artifact(self, artifact: Artifact) -> dict[str, Any] | None:
        """Upload an artifact: create version, upload files, confirm.

        Files are uploaded via presigned URLs. Content-hash deduplication
        on the server means duplicate content is not re-uploaded.

        When the artifact was created with ``Artifact.from_version()``, only
        new/changed files are uploaded.  Unchanged base files are reused via
        their existing storage key (``reuse: true`` in the manifest).

        Args:
            artifact: The Artifact object with files added via add_file/add_dir.

        Returns:
            Server response dict with version info, or None on failure.
        """
        try:
            manifest = []
            new_file_names: set[str] = set()

            # Add explicitly added files (new or overriding base files)
            for f in artifact._files:
                entry: dict[str, Any] = {
                    "name": f["name"],
                    "size": f["size"],
                    "content_hash": f["content_hash"],
                }
                if f.get("is_reference"):
                    entry["is_reference"] = True
                    entry["reference_uri"] = f.get("reference_uri", "")
                manifest.append(entry)
                new_file_names.add(f["name"])

            # For draft-mode artifacts, carry over unchanged base files
            if artifact._base_version_id and artifact._base_files:
                for path, bf in artifact._base_files.items():
                    # Skip removed files and files overridden by new additions
                    if path in artifact._removed_files:
                        continue
                    if path in new_file_names:
                        continue
                    manifest.append({
                        "name": path,
                        "size": bf.get("size_bytes", 0),
                        "content_hash": bf.get("content_hash", ""),
                        "reuse": True,
                    })

            result = self._client.create_artifact_version(
                self._id,
                artifact.name,
                artifact.type,
                manifest,
                description=artifact.description,
                metadata=artifact.metadata,
                base_version_id=artifact._base_version_id,
            )
            if not result:
                return None

            # Upload files that need uploading (dedup may skip some)
            # Reference files and reused files never have upload URLs.
            all_uploaded = True
            for url_entry in result.get("upload_urls", []):
                local = next(
                    f for f in artifact._files if f["name"] == url_entry["name"]
                )
                ok = self._client.upload_file_to_presigned_url(
                    url_entry["presigned_url"], local["local_path"]
                )
                if not ok:
                    logger.warning("upload failed for %s", url_entry["name"])
                    all_uploaded = False

            if not all_uploaded:
                logger.error("artifact upload incomplete — not confirming version")
                return None

            # Confirm the version
            self._client.confirm_artifact_version(result["version_id"])
            return result
        except Exception as e:
            logger.warning("log_artifact failed: %s", e)
            return None

    def finish_artifact(self, artifact: Artifact) -> dict[str, Any] | None:
        """Finalize an artifact that was incrementally built.

        Flushes any buffered data and confirms the artifact upload.
        This is called automatically by log_artifact(), but can be
        called explicitly for artifacts built incrementally.

        Args:
            artifact: The Artifact object to finalize.

        Returns:
            Server response dict with version info, or None on failure.
        """
        # Delegate to log_artifact -- our draft mode already handles this
        return self.log_artifact(artifact)

    def link_artifact(
        self, artifact: Artifact, aliases: list[str] | None = None
    ) -> dict[str, Any] | None:
        """Upload an artifact and set aliases on the created version.

        This is a convenience method that combines log_artifact with alias
        setting. The "latest" alias is automatically set by the server on
        confirmation; additional aliases (e.g., "production", "staging") are
        set via explicit API calls.

        Args:
            artifact: The Artifact object with files added.
            aliases: List of alias names to set (e.g., ["production"]).

        Returns:
            Server response dict with version info, or None on failure.
        """
        result = self.log_artifact(artifact)
        if result is None or not aliases:
            return result

        try:
            # We need the artifact_id to set aliases. Get it from the server.
            # The version_id is in the result; we can look up the artifact_id
            # from the artifact detail endpoint.
            version_id = result.get("version_id", "")

            # Get artifact by project lookup
            art_result = self._client._client.get(
                f"/projects/{self._project}/artifacts"
            )
            if art_result.status_code == 200:
                arts = art_result.json()
                artifact_id = None
                for a in arts:
                    if a.get("name") == artifact.name:
                        artifact_id = str(a["id"])
                        break

                if artifact_id and version_id:
                    for alias_name in aliases:
                        self._client.set_alias(artifact_id, alias_name, version_id)

        except Exception as e:
            logger.warning("link_artifact alias setting failed: %s", e)

        return result

    def use_artifact(
        self, name: str, version: int | None = None, alias: str | None = None
    ) -> "Path | None":
        """Download an artifact and cache locally.

        Uses an LRU cache to avoid re-downloading unchanged files.
        Supports alias-based lookup and "name:alias" syntax.

        Args:
            name: Artifact name. Can use "name:alias" syntax (e.g., "my-model:production").
            version: Specific version number, or None for latest.
            alias: Alias name to resolve (e.g., "production", "latest").

        Returns:
            Path to the local artifact directory, or None on failure.
        """
        try:
            from pathlib import Path

            # Support "name:alias" syntax
            if ":" in name and alias is None:
                name, alias = name.rsplit(":", 1)

            result = self._client.use_artifact(self._id, name, version, alias)
            if not result:
                return None

            # Prepare local artifact directory
            artifact_dir = (
                self._artifact_cache._dir
                / name
                / f"v{result.get('version', 0)}"
            )
            artifact_dir.mkdir(parents=True, exist_ok=True)

            for file_info in result.get("files", []):
                content_hash = file_info.get("content_hash") or ""
                file_path = file_info.get("name") or file_info.get("path") or "file"
                cached = self._artifact_cache.get(content_hash) if content_hash else None

                dest = artifact_dir / file_path
                dest.parent.mkdir(parents=True, exist_ok=True)

                if cached:
                    # Copy from cache if not already at destination
                    if not dest.exists():
                        import shutil

                        shutil.copy2(str(cached), str(dest))
                else:
                    # Download and cache
                    url = file_info.get("download_url") or file_info.get("presigned_url", "")
                    data = None
                    if url.startswith("/"):
                        # Relative proxy URL — use authenticated client
                        # Strip /api/v1/ prefix since _request prepends it via base_url
                        api_path = url.replace("/api/v1/", "/", 1) if url.startswith("/api/v1/") else url
                        try:
                            resp = self._client._request("get", api_path)
                            if resp.status_code == 200:
                                data = resp.content
                        except Exception:
                            pass
                    else:
                        data = self._client.download_file_from_presigned_url(url)
                    if data:
                        if content_hash:
                            self._artifact_cache.put(content_hash, data)
                        dest.write_bytes(data)

            return artifact_dir
        except Exception as e:
            logger.warning("use_artifact failed: %s", e)
            return None

    # -- Code logging ---------------------------------------------------------

    def log_code(
        self,
        root: str = ".",
        name: str | None = None,
        include_fn: Any = None,
        exclude_fn: Any = None,
    ) -> dict[str, Any] | None:
        """Capture source code as an artifact.

        Walks the directory tree starting at ``root``, collects matching
        files, and uploads them as a versioned artifact of type ``"code"``.

        Args:
            root: Root directory to capture (default: current directory).
            name: Artifact name (default: ``"source-code"``).
            include_fn: Optional filter ``(path: str) -> bool``.  When
                provided, only files for which the function returns True
                are included.  Receives the path relative to *root*.
            exclude_fn: Optional filter ``(path: str) -> bool``.  When
                provided, files for which the function returns True are
                excluded.  Applied after *include_fn*.

        Returns:
            Server response dict with version info, or None on failure.
        """
        try:
            from pathlib import Path as _Path

            root_path = _Path(root).resolve()
            if not root_path.is_dir():
                logger.warning("log_code(): root '%s' is not a directory", root)
                return None

            artifact_name = name or "source-code"
            artifact = Artifact(artifact_name, type="code")

            for fpath in sorted(root_path.rglob("*")):
                if not fpath.is_file():
                    continue

                rel = str(fpath.relative_to(root_path))

                # Default: include .py files only
                if include_fn is not None:
                    if not include_fn(rel):
                        continue
                else:
                    if not rel.endswith(".py"):
                        continue

                if exclude_fn is not None:
                    if exclude_fn(rel):
                        continue

                # Skip hidden directories / common non-source dirs
                parts = _Path(rel).parts
                if any(p.startswith(".") or p in ("__pycache__", "node_modules", ".git") for p in parts):
                    continue

                artifact.add_file(str(fpath), name=rel)

            if not artifact._files:
                logger.info("log_code(): no matching files found in '%s'", root)
                return None

            return self.log_artifact(artifact)
        except Exception as e:
            logger.warning("log_code() failed: %s", e)
            return None

    # -- Console logging ------------------------------------------------------

    def log_text(self, text: str) -> None:
        """Explicitly log text to the console log without printing.

        Args:
            text: Text to log. Sent as stdout stream.
        """
        ts = datetime.now(timezone.utc).isoformat()
        self._sender.add_console_line(ts, "stdout", text)

    # -- Alerts ---------------------------------------------------------------

    def alert(
        self,
        title: str,
        text: str | None = None,
        level: str = "INFO",
        wait_duration: float | None = None,
    ) -> dict[str, Any] | None:
        """Send an alert for this run.

        Alerts are stored on the server and dispatched to configured
        notification channels (console, Slack webhook).

        Args:
            title: Short alert title.
            text: Detailed alert description (optional).
            level: Alert severity -- INFO, WARN, or ERROR. Default INFO.
            wait_duration: Minimum seconds between alerts with the same
                title. If set and the same title was alerted less than
                ``wait_duration`` seconds ago, the alert is silently
                skipped (throttled).

        Returns:
            Server response dict with alert details, or None if failed
            or throttled.
        """
        try:
            if wait_duration is not None:
                import time

                last = self._alert_cooldowns.get(title, 0)
                if time.monotonic() - last < wait_duration:
                    return None  # throttled
                self._alert_cooldowns[title] = time.monotonic()

            return self._client.create_alert(
                self._id,
                title=title,
                text=text,
                level=level,
            )
        except Exception as e:
            logger.warning("alert() failed: %s", e)
            return None

    # -- Run control ----------------------------------------------------------

    def mark_preempting(self) -> None:
        """Mark this run as preempted (e.g., spot instance eviction).

        Sets the run state to 'preempting' on the server, signaling
        that the run was interrupted by infrastructure (not by user action).
        """
        self._client.update_run(self._id, {"state": "preempting"})

    def status(self) -> dict:
        """Get server-side run status.

        Returns:
            Server-side run data dict, or empty dict on failure.
        """
        return self._client.get_run(self._id) or {}

    def join(self, timeout: float | None = None) -> None:
        """Block until the run finishes (mainly for async/notebook use).

        Waits for the background sender thread to drain and stop.

        Args:
            timeout: Max seconds to wait. Defaults to 300 (5 minutes).
        """
        self._sender.stop(timeout=timeout or 300)

    # -- Model convenience methods --------------------------------------------

    def log_model(
        self,
        path: str,
        name: str = "model",
        aliases: list[str] | None = None,
    ) -> None:
        """Convenience: create a model artifact, add the path, log it.

        Args:
            path: Path to a file or directory containing the model.
            name: Artifact name (default "model").
            aliases: Optional list of aliases (e.g., ["production"]).
        """
        import os

        artifact = Artifact(name=name, type="model")
        if os.path.isdir(path):
            artifact.add_dir(path)
        else:
            artifact.add_file(path)
        self.log_artifact(artifact)
        if aliases:
            self.link_artifact(artifact, aliases=aliases)

    def use_model(
        self,
        name: str,
        version: int | None = None,
        alias: str | None = None,
        dest_dir: str = "./artifacts",
    ) -> str | None:
        """Download a model artifact to disk.

        Args:
            name: Model artifact name (supports "name:alias" syntax).
            version: Specific version number, or None for latest.
            alias: Alias name to resolve.
            dest_dir: Local directory for downloaded files.

        Returns:
            Path to the local artifact directory, or None on failure.
        """
        return self.use_artifact(name, version=version, alias=alias)

    def link_model(
        self,
        path: str,
        name: str,
        aliases: list[str] | None = None,
    ) -> None:
        """Convenience: log and link a model to the registry.

        Args:
            path: Path to a file or directory containing the model.
            name: Artifact name for the model.
            aliases: List of aliases (defaults to ["latest"]).
        """
        self.log_model(path, name=name, aliases=aliases or ["latest"])

    # -- Finish ---------------------------------------------------------------

    def finish(
        self,
        exit_code: int | None = None,
        quiet: bool = False,
    ) -> None:
        """Finish the run: stop sender, send final summary, close client.

        Args:
            exit_code: Optional exit code for the run.
            quiet: If True, suppress the finish message.
        """
        # Remove logging handler
        if hasattr(self, "_log_handler"):
            logging.root.removeHandler(self._log_handler)

        # Restore original stdout/stderr before stopping sender
        if hasattr(self, "_original_stdout"):
            # Flush any remaining captured output
            sys.stdout.flush()
            sys.stderr.flush()
            sys.stdout = self._original_stdout
            sys.stderr = self._original_stderr

        # Stop sender (drains buffer, closes offline storage)
        self._sender.stop()

        if self._offline_storage is not None:
            # Offline mode: write summary to disk
            self._offline_storage.write_summary(self._summary.as_dict())
        else:
            # Online mode: send final update to server
            update_payload: dict[str, Any] = {
                "state": "finished",
                "summary": self._summary.as_dict(),
            }
            if exit_code is not None:
                update_payload["exit_code"] = exit_code

            self._client.update_run(self._id, update_payload)

        # Clean up WAL on successful finish
        if self._wal is not None:
            self._wal.cleanup()

        # Close API client
        self._client.close()

        self._state = "finished"

        if not quiet:
            settings = SDKSettings()
            if not settings.quiet:
                url = self.get_url()
                print(f"openrunner: Run {self._id} finished", file=sys.stderr)
                print(f"openrunner: View run at: {url}", file=sys.stderr)
                summary_items = list(self._summary.as_dict().items())[:8]
                if summary_items:
                    print("openrunner: Summary:", file=sys.stderr)
                    for k, v in summary_items:
                        val = f"{v:.4f}" if isinstance(v, float) else str(v)
                        print(f"openrunner:   {k}: {val}", file=sys.stderr)
                elapsed = datetime.now(timezone.utc) - self._start_time
                print(
                    f"openrunner: Duration: {elapsed.total_seconds():.1f}s",
                    file=sys.stderr,
                )
