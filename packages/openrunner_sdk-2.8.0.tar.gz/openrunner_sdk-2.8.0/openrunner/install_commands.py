"""Install OpenRunner slash commands for AI coding tools.

Supports:
- Claude Code: ~/.claude/commands/openrunner/
- Codex (OpenAI): ~/.codex/commands/ or AGENTS.md instructions
- Qwen Code: ~/.qwen-code/commands/
- OpenCode: ~/.opencode/commands/

Usage:
    openrunner install          # auto-detect and install all
    openrunner install claude   # Claude Code only
    openrunner install codex    # Codex only
    openrunner install qwen     # Qwen Code only
    openrunner install opencode # OpenCode only
"""

from __future__ import annotations

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Command templates
# ---------------------------------------------------------------------------

SYNC_SESSION_CMD = """---
name: {prefix}sync-session
description: Sync current coding session to OpenRunner as a research log
argument-hint: "[org/project]"
allowed-tools:
  - Bash
  - Read
  - AskUserQuestion
---

Sync the current Claude Code session to OpenRunner.

## Process

### Step 1: Check configuration

Run this to check if session config exists:

```bash
python3 -c "
import json
from pathlib import Path
config_file = Path.home() / '.openrunner' / 'session_config.json'
if config_file.exists():
    config = json.loads(config_file.read_text())
    if config.get('api_key') and config.get('project'):
        print('CONFIGURED')
        print(f'project={{config[\"project\"]}}')
    else:
        print('INCOMPLETE')
else:
    print('NOT_CONFIGURED')
"
```

### Step 2a: If NOT_CONFIGURED or INCOMPLETE

Ask the user for their OpenRunner API key and base URL. Then list projects and ask them to pick one. Save to ~/.openrunner/session_config.json.

### Step 2b: If CONFIGURED (or after setup)

Sync the current session. Use $ARGUMENTS as project override if provided:

```bash
python3 -c "
import sys, os
from pathlib import Path
for p in [os.path.expanduser(f'~/.local/lib/python3.{{v}}/site-packages') for v in (12,11,10)]:
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.session import parse_claude_session, sync_session_to_openrunner, get_session_config

cwd = Path.cwd()
cwd_key = '-' + str(cwd).replace('/', '-').lstrip('-')
project_dir = Path.home() / '.claude' / 'projects' / cwd_key
if not project_dir.exists():
    for d in (Path.home() / '.claude' / 'projects').iterdir():
        if d.is_dir() and cwd_key in d.name:
            project_dir = d
            break

sessions = sorted(
    [f for f in project_dir.rglob('*.jsonl') if f.stat().st_size > 100 and '.meta.' not in f.name],
    key=lambda f: f.stat().st_mtime, reverse=True,
) if project_dir.exists() else []

if not sessions:
    print('No session files found.')
    sys.exit(1)

latest = sessions[0]
print(f'Syncing: {{latest.name}} ({{latest.stat().st_size // 1024}} KB)')
parsed = parse_claude_session(latest)
print(f'  Messages: {{parsed[\"message_count\"]}} ({{parsed[\"user_message_count\"]}} user)')
print(f'  Tokens: {{parsed.get(\"total_tokens\", 0):,}}')

project_override = '$ARGUMENTS'.strip() or None
run_id = sync_session_to_openrunner(parsed, project=project_override)
if run_id:
    config = get_session_config()
    base = config.get('base_url', 'https://openrun.gladia.io')
    print(f'Synced -> {{base}}/runs/{{run_id}}')
else:
    print('Sync failed. Run: openrunner session setup')
"
```

### Step 3: Report the run URL and stats to the user.
"""

LOG_NOTE_CMD = """---
name: {prefix}log-note
description: Log a research note to OpenRunner
---

Log the user's note text to OpenRunner as a quick research entry. Run:

```bash
python3 -c "
import os, sys, json
from pathlib import Path

for p in [os.path.expanduser('~/.local/lib/python3.12/site-packages'),
          os.path.expanduser('~/.local/lib/python3.11/site-packages')]:
    if os.path.isdir(p):
        sys.path.insert(0, p)

from openrunner.api_client import APIClient

settings_file = Path.home() / '.openrunner' / 'settings.json'
settings = json.loads(settings_file.read_text()) if settings_file.exists() else {{}}
api_key = os.environ.get('OPENRUNNER_API_KEY') or settings.get('api_key')
base_url = os.environ.get('OPENRUNNER_BASE_URL') or settings.get('base_url', 'https://openrun.gladia.io')
project = os.environ.get('OPENRUNNER_SESSION_PROJECT', 'research-sessions')

note = '''$ARGUMENTS'''

client = APIClient(base_url=base_url, api_key=api_key)
result = client.create_run({{
    'project': project,
    'display_name': f'note: {{note[:50]}}',
    'notes': note,
    'tags': ['note', 'quick'],
    'state': 'finished',
}})
if result:
    print(f'Note logged: run {{result[\"id\"]}}')
else:
    print('Failed. Run: openrunner login')
client.close()
"
```
"""

# ---------------------------------------------------------------------------
# Installers per tool
# ---------------------------------------------------------------------------


def install_claude_code() -> list[str]:
    """Install commands in ~/.claude/commands/openrunner/."""
    cmd_dir = Path.home() / ".claude" / "commands" / "openrunner"
    cmd_dir.mkdir(parents=True, exist_ok=True)

    files = []

    sync_path = cmd_dir / "sync-session.md"
    sync_path.write_text(SYNC_SESSION_CMD.format(prefix="openrunner:"))
    files.append(str(sync_path))

    note_path = cmd_dir / "log-note.md"
    note_path.write_text(LOG_NOTE_CMD.format(prefix="openrunner:"))
    files.append(str(note_path))

    return files


def install_codex() -> list[str]:
    """Install commands for Codex CLI."""
    # Codex uses ~/.codex/ with instructions or custom commands
    cmd_dir = Path.home() / ".codex" / "commands"
    cmd_dir.mkdir(parents=True, exist_ok=True)

    files = []

    sync_path = cmd_dir / "sync-session.md"
    sync_path.write_text(SYNC_SESSION_CMD.format(prefix="openrunner:"))
    files.append(str(sync_path))

    note_path = cmd_dir / "log-note.md"
    note_path.write_text(LOG_NOTE_CMD.format(prefix="openrunner:"))
    files.append(str(note_path))

    # Also add to AGENTS.md if it exists
    agents_file = Path.home() / ".codex" / "AGENTS.md"
    instruction = "\n\n## OpenRunner Integration\nUse `/openrunner:sync-session` to log this session to OpenRunner.\nUse `/openrunner:log-note <text>` to save a research note.\n"
    if agents_file.exists():
        content = agents_file.read_text()
        if "openrunner" not in content.lower():
            agents_file.write_text(content + instruction)
            files.append(str(agents_file))
    else:
        agents_file.write_text("# Codex Agent Instructions" + instruction)
        files.append(str(agents_file))

    return files


def install_qwen_code() -> list[str]:
    """Install commands for Qwen Code."""
    cmd_dir = Path.home() / ".qwen-code" / "commands"
    cmd_dir.mkdir(parents=True, exist_ok=True)

    files = []

    sync_path = cmd_dir / "sync-session.md"
    sync_path.write_text(SYNC_SESSION_CMD.format(prefix="openrunner:"))
    files.append(str(sync_path))

    note_path = cmd_dir / "log-note.md"
    note_path.write_text(LOG_NOTE_CMD.format(prefix="openrunner:"))
    files.append(str(note_path))

    return files


def install_opencode() -> list[str]:
    """Install commands for OpenCode."""
    cmd_dir = Path.home() / ".opencode" / "commands"
    cmd_dir.mkdir(parents=True, exist_ok=True)

    files = []

    sync_path = cmd_dir / "sync-session.md"
    sync_path.write_text(SYNC_SESSION_CMD.format(prefix="openrunner:"))
    files.append(str(sync_path))

    note_path = cmd_dir / "log-note.md"
    note_path.write_text(LOG_NOTE_CMD.format(prefix="openrunner:"))
    files.append(str(note_path))

    return files


# ---------------------------------------------------------------------------
# Main installer
# ---------------------------------------------------------------------------

TOOLS = {
    "claude": ("Claude Code", install_claude_code),
    "codex": ("Codex", install_codex),
    "qwen": ("Qwen Code", install_qwen_code),
    "opencode": ("OpenCode", install_opencode),
}


def install_all(targets: list[str] | None = None) -> dict[str, list[str]]:
    """Install commands for specified tools (or all if None).

    Returns dict of tool_name -> list of installed file paths.
    """
    results = {}

    if targets:
        to_install = [(k, v) for k, v in TOOLS.items() if k in targets]
    else:
        # Auto-detect: install for all tools
        to_install = list(TOOLS.items())

    for key, (name, installer) in to_install:
        files = installer()
        results[name] = files

    return results
