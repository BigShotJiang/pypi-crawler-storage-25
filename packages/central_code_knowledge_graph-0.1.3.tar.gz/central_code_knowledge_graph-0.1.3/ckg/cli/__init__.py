"""ckg CLI package."""
