"""FastAPI app package."""
