#!/usr/bin/env python3
"""
@file __init__.py
@brief InsightOS Logging SDK - Python 统一入口

使用方式:
    import insightoslog as ios
    
    ios.init({"service_name": "my-service"})
    ios.info("Hello World")
    
    # 或使用类封装
    from insightoslog import Logger, Trace
    Logger.init({"service_name": "my-service"})
    Logger.info("Hello World")
"""

import sys
from . import _impl

# 挂载常用函数到模块级别，实现 import insightoslog as ios
trace = _impl.trace
debug = _impl.debug
info = _impl.info
warn = _impl.warn
error = _impl.error
fatal = _impl.fatal
init = _impl.init
init_from_config = _impl.init_from_config
generate_trace_id = _impl.generate_trace_id
generate_span_id = _impl.generate_span_id
current_context = _impl.current_context
make_context = _impl.make_context
global_resource = _impl.global_resource
refresh_pid = _impl.refresh_pid
set_global_resource = _impl.set_global_resource
extract_from_headers = _impl.extract_from_headers
LogLevel = _impl.LogLevel
InsightOSLogContext = _impl.InsightOSLogContext
LogContext = _impl.InsightOSLogContext  # 别名
Trace = _impl.Trace
Logger = _impl.Logger
Context = _impl.Context
Resource = _impl.Resource
Caller = _impl.Caller
Meta = _impl.Meta
Data = _impl.Data
EventRequest = _impl.EventRequest
LogError = _impl.LogError
InitParam = _impl.InitParam
LogBuilder = _impl.LogBuilder
ContextWithLog = _impl.ContextWithLog
with_context = _impl.with_context
with_context_from_ctx = _impl.with_context_from_ctx
Logger2 = _impl.Logger2
Trace2 = _impl.Trace2
HEADER_TRACE_ID = _impl.HEADER_TRACE_ID
HEADER_SPAN_ID = _impl.HEADER_SPAN_ID
HEADER_PARENT_SPAN_ID = _impl.HEADER_PARENT_SPAN_ID
mask_sensitive = _impl.mask_sensitive

# 级别管理
get_level = _impl.get_level
set_level = _impl.set_level
GetLevel = _impl.Logger.get_level
SetLevel = _impl.Logger.set_level

# 传播 Header
get_propagation_headers = _impl.Trace.get_propagation_headers

# 线程传播
prepare_for_child_thread = _impl.Trace.prepare_for_child_thread
inherit_from_prepared = _impl.Trace.inherit_from_prepared
inherit_from_parent = _impl.Trace.inherit_from_parent

# 挂载到当前模块
sys.modules[__name__].trace = trace
sys.modules[__name__].debug = debug
sys.modules[__name__].info = info
sys.modules[__name__].warn = warn
sys.modules[__name__].error = error
sys.modules[__name__].fatal = fatal
sys.modules[__name__].init = init
sys.modules[__name__].init_from_config = init_from_config
sys.modules[__name__].get_level = get_level
sys.modules[__name__].set_level = set_level
sys.modules[__name__].GetLevel = GetLevel
sys.modules[__name__].SetLevel = SetLevel
sys.modules[__name__].generate_trace_id = generate_trace_id
sys.modules[__name__].generate_span_id = generate_span_id
sys.modules[__name__].current_context = current_context
sys.modules[__name__].make_context = make_context
sys.modules[__name__].global_resource = global_resource
sys.modules[__name__].refresh_pid = refresh_pid
sys.modules[__name__].set_global_resource = set_global_resource
sys.modules[__name__].extract_from_headers = extract_from_headers
sys.modules[__name__].LogLevel = LogLevel
sys.modules[__name__].InsightOSLogContext = InsightOSLogContext
sys.modules[__name__].LogContext = LogContext
sys.modules[__name__].Trace = Trace
sys.modules[__name__].Logger = Logger
sys.modules[__name__].Context = Context
sys.modules[__name__].Resource = Resource
sys.modules[__name__].Caller = Caller
sys.modules[__name__].Meta = Meta
sys.modules[__name__].Data = Data
sys.modules[__name__].EventRequest = EventRequest
sys.modules[__name__].LogError = LogError
sys.modules[__name__].InitParam = InitParam
sys.modules[__name__].LogBuilder = LogBuilder
sys.modules[__name__].ContextWithLog = ContextWithLog
sys.modules[__name__].with_context = with_context
sys.modules[__name__].with_context_from_ctx = with_context_from_ctx
sys.modules[__name__].Logger2 = Logger2
sys.modules[__name__].Trace2 = Trace2
sys.modules[__name__].HEADER_TRACE_ID = HEADER_TRACE_ID
sys.modules[__name__].HEADER_SPAN_ID = HEADER_SPAN_ID
sys.modules[__name__].HEADER_PARENT_SPAN_ID = HEADER_PARENT_SPAN_ID
sys.modules[__name__].mask_sensitive = mask_sensitive
sys.modules[__name__].GetLevel = GetLevel
sys.modules[__name__].SetLevel = SetLevel
sys.modules[__name__].get_propagation_headers = get_propagation_headers
sys.modules[__name__].prepare_for_child_thread = prepare_for_child_thread
sys.modules[__name__].inherit_from_prepared = inherit_from_prepared
sys.modules[__name__].inherit_from_parent = inherit_from_parent
