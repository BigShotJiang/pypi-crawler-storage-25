#!/usr/bin/env python3
"""
@file __init__.py
@brief InsightOS Logging SDK - Python 公共入口

使用方式:
    import insightoslog as ios

    ios.init({"service_name": "my-service"})
    ios.info("Hello World")

    # 或使用类封装
    from insightoslog import Logger, Trace
    Logger.init({"service_name": "my-service"})
    Logger.info("Hello World")
"""

# 从 wrapper 模块导入所有公共接口
from .wrapper import (
    # 日志函数
    trace, debug, info, warn, error, fatal,
    # 初始化函数
    init, init_from_config,
    # 级别管理
    get_level, set_level, GetLevel, SetLevel,
    # Trace 函数
    generate_trace_id, generate_span_id,
    current_context, make_context,
    global_resource, refresh_pid, set_global_resource,
    extract_from_headers,
    # 上下文管理器
    with_context, with_context_from_ctx,
    # 类型
    LogLevel,
    LogContext,
    InsightOSLogContext,
    Trace,
    Logger,
    Context,
    Resource,
    Caller,
    Meta,
    Data,
    EventRequest,
    LogError,
    InitParam,
    LogBuilder,
    ContextWithLog,
    # 全局实例
    Logger2, Trace2,
    # HTTP Header 常量
    HEADER_TRACE_ID,
    HEADER_SPAN_ID,
    HEADER_PARENT_SPAN_ID,
    # 传播函数
    get_propagation_headers,
    # 线程传播
    prepare_for_child_thread,
    inherit_from_prepared,
    inherit_from_parent,
    # 工具函数
    mask_sensitive,
)

__all__ = [
    # 日志函数
    "trace", "debug", "info", "warn", "error", "fatal",
    # 初始化
    "init", "init_from_config",
    # 级别管理
    "get_level", "set_level", "GetLevel", "SetLevel",
    # Trace
    "generate_trace_id", "generate_span_id",
    "current_context", "make_context",
    # 上下文管理器
    "with_context", "with_context_from_ctx",
    # 类型
    "LogLevel", "LogContext", "InsightOSLogContext", "Trace", "Logger",
    "Context", "Resource", "Caller", "Meta", "Data",
    "EventRequest", "LogError", "InitParam",
    "LogBuilder", "ContextWithLog",
    # 全局实例
    "Logger2", "Trace2",
    # 常量
    "HEADER_TRACE_ID", "HEADER_SPAN_ID", "HEADER_PARENT_SPAN_ID",
    # 传播函数
    "get_propagation_headers",
    # 线程传播
    "prepare_for_child_thread", "inherit_from_prepared", "inherit_from_parent",
    # 工具
    "mask_sensitive",
]

__version__ = "1.0.13"
