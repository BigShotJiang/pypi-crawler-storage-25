"""Task scheduler with dependency and optional resource constraints."""

from bisect import bisect_right
from dataclasses import dataclass
import logging
import math
from collections import deque
from datetime import date, timedelta
from typing import Any, Dict, List, Literal, Set, overload

import numpy as np

from mcprojsim.config import Config
from mcprojsim.models.project import CalendarSpec, Project, ResourceSpec

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ResourceCalendarState:
    """Resolved per-resource calendar data reused within one iteration."""

    resource: ResourceSpec
    work_days: frozenset[int]
    holidays: frozenset[date]
    planned_absence: frozenset[date]
    capacity_per_hour: float
    work_end_hour: float


@dataclass(frozen=True)
class ResourceAvailabilityState:
    """Per-iteration availability windows and lookup tables for one resource."""

    calendar_state: ResourceCalendarState
    sickness_absence: frozenset[date]
    windows: tuple[tuple[float, float], ...]
    starts: tuple[float, ...]
    ends: tuple[float, ...]


class TaskScheduler:
    """Scheduler for tasks with dependencies.

    Resource-cap heuristic constants:

        - ``MIN_EFFORT_PER_ASSIGNEE_HOURS = 16.0``
            Sets the minimum expected task effort per assigned resource when
            auto-capping staffing. This prevents unrealistic compression of short
            tasks by requiring each assignee to have a meaningful chunk of work.
            Example: an 24h task is auto-capped to at most ``max(1, ceil(24/16))=2`` assignees.

        - ``MAX_ASSIGNEES_PER_TASK = 3``
            A global coordination ceiling to avoid over-parallelization on very large
            tasks. Beyond this point, communication and synchronization overhead tend
            to dominate and pure linear speedup assumptions become less realistic.

    Together, the practical cap is:
    ``min(floor(task_effort_hours / MIN_EFFORT_PER_ASSIGNEE_HOURS), MAX_ASSIGNEES_PER_TASK)``,
    with a minimum of 1 assignee.
    """

    MIN_EFFORT_PER_ASSIGNEE_HOURS = 16.0
    MAX_ASSIGNEES_PER_TASK = 3

    def __init__(
        self,
        project: Project,
        random_state: np.random.RandomState | None = None,
        config: Config | None = None,
    ):
        """Initialize scheduler with project.

        Args:
            project: Project with tasks and dependencies
            random_state: NumPy random state for reproducibility
        """
        self.project = project
        self.task_map = {task.id: task for task in project.tasks}
        self.random_state = random_state or np.random.RandomState()
        self.config = config or Config.get_default()
        self._topological_order, self._successor_map = self._build_static_graph_data()

    @overload
    def schedule_tasks(
        self,
        task_durations: Dict[str, float],
        *,
        use_resource_constraints: bool = False,
        return_diagnostics: Literal[False] = False,
        start_date: date | None = None,
        hours_per_day: float = 8.0,
        task_priority: Dict[str, float] | None = None,
    ) -> Dict[str, Dict[str, Any]]: ...

    @overload
    def schedule_tasks(
        self,
        task_durations: Dict[str, float],
        *,
        use_resource_constraints: bool = False,
        return_diagnostics: Literal[True],
        start_date: date | None = None,
        hours_per_day: float = 8.0,
        task_priority: Dict[str, float] | None = None,
    ) -> tuple[Dict[str, Dict[str, Any]], Dict[str, float]]: ...

    def schedule_tasks(
        self,
        task_durations: Dict[str, float],
        *,
        use_resource_constraints: bool = False,
        return_diagnostics: bool = False,
        start_date: date | None = None,
        hours_per_day: float = 8.0,
        task_priority: Dict[str, float] | None = None,
    ) -> Dict[str, Dict[str, Any]] | tuple[Dict[str, Dict[str, Any]], Dict[str, float]]:
        """Schedule tasks respecting dependencies.

        Args:
            task_durations: Dictionary mapping task IDs to their durations
            use_resource_constraints: Whether to enforce resource assignment
                constraints when scheduling. Defaults to False.
            return_diagnostics: Whether to return constrained-mode diagnostics.
            start_date: Project start date used for calendar-aware scheduling.
                Defaults to project metadata start date when omitted.
            hours_per_day: Working hours per day fallback when calendar does not
                define explicit daily work hours.
            task_priority: Optional per-task priority scores (higher = dispatched
                first). When provided and resource constraints are active, ready
                tasks are ordered by descending priority then ascending task ID.
                Has no effect when resource constraints are inactive.

        Returns:
            Dictionary mapping task IDs to their schedule info:
            {'start': start_time, 'end': end_time, 'duration': duration}
        """
        if use_resource_constraints and self.project.resources:
            effective_start_date = start_date or self.project.project.start_date
            schedule, diagnostics = self._schedule_tasks_with_resources(
                task_durations,
                start_date=effective_start_date,
                hours_per_day=hours_per_day,
                task_priority=task_priority,
            )
            if return_diagnostics:
                return schedule, diagnostics
            return schedule

        schedule = self._schedule_tasks_dependency_only(task_durations)
        if return_diagnostics:
            return schedule, {
                "resource_wait_time_hours": 0.0,
                "resource_utilization": 0.0,
                "calendar_delay_time_hours": 0.0,
            }
        return schedule

    def _schedule_tasks_dependency_only(
        self, task_durations: Dict[str, float]
    ) -> Dict[str, Dict[str, Any]]:
        """Schedule tasks using dependency-only earliest-start logic."""
        schedule: Dict[str, Dict[str, Any]] = {}

        for task_id in self._topological_order:
            duration = task_durations[task_id]
            task = self.task_map[task_id]

            # Find earliest start time based on dependencies
            start_time = 0.0
            for dep_id in task.dependencies:
                if dep_id in schedule:
                    dep_end = schedule[dep_id]["end"]
                    start_time = max(start_time, dep_end)

            schedule[task_id] = {
                "start": start_time,
                "end": start_time + duration,
                "duration": duration,
                "assigned": [],
            }

        return schedule

    def _schedule_tasks_with_resources(
        self,
        task_durations: Dict[str, float],
        *,
        start_date: date,
        hours_per_day: float,
        task_priority: Dict[str, float] | None = None,
    ) -> tuple[Dict[str, Dict[str, Any]], Dict[str, float]]:
        """Schedule tasks with dependency and resource constraints.

        This first implementation is deterministic and non-preemptive. It
        enforces:
        - dependency precedence
        - per-task ``max_resources``
        - per-task ``min_experience_level``
        - exclusive resource assignment (one task at a time)

        Args:
            task_durations: Sampled task durations in hours.
            start_date: Project start date for calendar-aware scheduling.
            hours_per_day: Working hours per day.
            task_priority: Optional mapping of task_id -> priority score.
                When provided, ready tasks are sorted by descending priority
                score with task_id as tie-break (criticality-two-pass policy).
                When ``None`` the default greedy ID-order policy is used.
        """
        schedule: Dict[str, Dict[str, Any]] = {}

        remaining = set(self._topological_order)
        active: list[tuple[float, str, list[str]]] = []
        current_time = 0.0
        resource_wait_time_hours = 0.0
        calendar_delay_time_hours = 0.0

        resource_map = {
            resource.name: resource
            for resource in self.project.resources
            if resource.name is not None
        }
        all_resource_names = tuple(sorted(resource_map.keys()))
        free_resources = set(resource_map.keys())

        calendar_map = {calendar.id: calendar for calendar in self.project.calendars}
        default_calendar = calendar_map.get("default")
        if default_calendar is None:
            # Materialise the fallback calendar once for the iteration-local
            # calendar state cache used by constrained scheduling.
            default_calendar = CalendarSpec(
                id="default",
                work_hours_per_day=hours_per_day,
                work_days=[1, 2, 3, 4, 5],
                holidays=[],
            )
        resource_calendar_states = self._build_resource_calendar_states(
            resource_map,
            calendar_map,
            default_calendar,
            hours_per_day,
        )
        horizon_days = self._estimate_sickness_horizon_days(
            task_durations,
            resource_map,
            hours_per_day,
        )
        sickness_absence = self._generate_sickness_absence(
            resource_map,
            start_date,
            horizon_days,
            calendar_map,
            default_calendar,
            resource_calendar_states=resource_calendar_states,
        )
        resource_availability_states = self._build_resource_availability_states(
            resource_calendar_states,
            start_date,
            horizon_days,
            sickness_absence,
        )

        while remaining:
            # Release completed tasks at current time
            finished = [entry for entry in active if entry[0] <= current_time + 1e-9]
            for _, _, assigned in finished:
                for resource_name in assigned:
                    free_resources.add(resource_name)
            active = [entry for entry in active if entry[0] > current_time + 1e-9]

            # Find tasks ready by dependency constraints and sort by policy.
            # Default (greedy_single_pass): ascending task_id.
            # With task_priority map (criticality_two_pass): descending priority,
            # then ascending task_id as deterministic tie-break.
            ready_unsorted = [
                task_id
                for task_id in remaining
                if all(
                    dep_id in schedule
                    and schedule[dep_id]["end"] <= current_time + 1e-9
                    for dep_id in self.task_map[task_id].dependencies
                )
            ]
            if task_priority is not None:
                ready = sorted(
                    ready_unsorted,
                    key=lambda tid: (-task_priority.get(tid, 0.0), tid),
                )
            else:
                ready = sorted(ready_unsorted)

            started_any = False
            for task_id in ready:
                task = self.task_map[task_id]
                eligible_pool = (
                    [r for r in task.resources if r in resource_map]
                    if task.resources
                    else all_resource_names
                )

                eligible_free = [
                    name
                    for name in sorted(eligible_pool)
                    if name in free_resources
                    and resource_map[name].experience_level >= task.min_experience_level
                ]

                if not eligible_free:
                    continue

                practical_cap = self._practical_task_resource_cap(
                    task_durations[task_id]
                )
                effective_cap = min(task.max_resources, practical_cap)

                assigned = eligible_free[:effective_cap]
                if not assigned:
                    continue

                dependency_ready_time = max(
                    (
                        schedule[dep_id]["end"]
                        for dep_id in task.dependencies
                        if dep_id in schedule
                    ),
                    default=0.0,
                )
                if current_time > dependency_ready_time:
                    resource_wait_time_hours += current_time - dependency_ready_time

                actual_start = self._find_next_time_with_capacity(
                    current_time,
                    assigned,
                    resource_availability_states,
                )

                if actual_start is None:
                    continue

                if actual_start > current_time:
                    calendar_delay_time_hours += actual_start - current_time

                end_time, execution_calendar_delay = (
                    self._compute_task_end_with_calendars(
                        actual_start,
                        task_durations[task_id],
                        assigned,
                        resource_availability_states,
                    )
                )
                calendar_delay_time_hours += execution_calendar_delay
                elapsed_duration = end_time - actual_start

                for resource_name in assigned:
                    free_resources.remove(resource_name)

                schedule[task_id] = {
                    "start": actual_start,
                    "end": end_time,
                    "duration": elapsed_duration,
                    "assigned": assigned,
                }
                active.append((end_time, task_id, assigned))
                remaining.remove(task_id)
                started_any = True

            if started_any:
                continue

            if active:
                current_time = min(end_time for end_time, _, _ in active)
            else:
                # Fallback safety (should not happen for valid inputs)
                # Use dependency-only schedule for any unscheduled tasks.
                logger.warning(
                    "Resource-constrained scheduler stalled with %d task(s) "
                    "remaining; falling back to dependency-only scheduling.",
                    len(remaining),
                )
                fallback = self._schedule_tasks_dependency_only(task_durations)
                for task_id in remaining:
                    schedule[task_id] = fallback[task_id]
                break

        project_end = max((info["end"] for info in schedule.values()), default=0.0)
        total_effort = float(sum(task_durations.values()))
        total_available_capacity = self._integrate_available_capacity(
            0.0,
            project_end,
            all_resource_names,
            resource_availability_states,
        )
        utilization = (
            min(1.0, total_effort / total_available_capacity)
            if total_available_capacity > 0
            else 0.0
        )

        return schedule, {
            "resource_wait_time_hours": resource_wait_time_hours,
            "resource_utilization": utilization,
            "calendar_delay_time_hours": calendar_delay_time_hours,
        }

    @classmethod
    def _practical_task_resource_cap(cls, effort_hours: float) -> int:
        """Compute an automatic practical assignee cap for one task.

        Heuristic:
        - Every assignee should have at least ``MIN_EFFORT_PER_ASSIGNEE_HOURS``
          of expected work.
        - Even for large tasks, cap by ``MAX_ASSIGNEES_PER_TASK`` to avoid
          unrealistic compression from pure parallelization assumptions.

                Constant selection rationale:
                - ``16.0`` hours is a one and a half-day granularity baseline that avoids assigning
                    many people to tasks that are too small to split productively.
                - ``3`` assignees is a conservative coordination ceiling that keeps
                    schedules deterministic and realistic without introducing heavier
                    optimization or communication-overhead models.
        """
        if effort_hours <= 0:
            return 1

        granularity_cap = max(
            1,
            int(math.floor(effort_hours / cls.MIN_EFFORT_PER_ASSIGNEE_HOURS)),
        )
        return max(1, min(cls.MAX_ASSIGNEES_PER_TASK, granularity_cap))

    @staticmethod
    def _estimate_sickness_horizon_days(
        task_durations: Dict[str, float],
        resource_map: Dict[str, ResourceSpec],
        hours_per_day: float,
    ) -> int:
        """Estimate sickness simulation horizon in days for one iteration."""
        total_effort = sum(task_durations.values())
        total_capacity = sum(
            resource.productivity_level * resource.availability
            for resource in resource_map.values()
        )
        if total_capacity <= 0:
            total_capacity = 0.1

        effort_days = total_effort / (hours_per_day * total_capacity)
        return max(30, int(math.ceil(effort_days)) + 60)

    def _generate_sickness_absence(
        self,
        resource_map: Dict[str, ResourceSpec],
        start_date: date,
        horizon_days: int,
        calendar_map: Dict[str, CalendarSpec],
        default_calendar: CalendarSpec | None,
        *,
        resource_calendar_states: Dict[str, ResourceCalendarState] | None = None,
    ) -> Dict[str, Set[date]]:
        """Generate sickness absence days per resource for an iteration."""
        sickness_by_resource: Dict[str, Set[date]] = {
            name: set() for name in resource_map.keys()
        }
        resolved_calendar_states = resource_calendar_states or (
            self._build_resource_calendar_states(
                resource_map,
                calendar_map,
                default_calendar,
                self.project.project.hours_per_day,
            )
        )

        sickness_defaults = self.config.sprint_defaults.sickness
        mu = sickness_defaults.duration_log_mu
        sigma = sickness_defaults.duration_log_sigma

        for resource_name, resource in resource_map.items():
            resource_calendar_state = resolved_calendar_states[resource_name]
            sickness_prob = self._resource_sickness_probability(resource)
            current_day = 0
            while current_day < horizon_days:
                d = start_date + timedelta(days=current_day)
                if self._is_resource_working_day_in_state(
                    resource_calendar_state,
                    d,
                    preplanned_absence_only=True,
                ):
                    if self.random_state.random() < sickness_prob:
                        sickness_len = max(
                            1, int(round(self.random_state.lognormal(mu, sigma)))
                        )
                        for offset in range(sickness_len):
                            sickness_by_resource[resource_name].add(
                                d + timedelta(days=offset)
                            )
                        current_day += sickness_len
                        continue
                current_day += 1

        return sickness_by_resource

    def _resource_sickness_probability(self, resource: ResourceSpec) -> float:
        """Resolve per-resource sickness probability with config fallback.

        Precedence:
        1. Explicit `resource.sickness_prob` in project file
        2. `config.constrained_scheduling.sickness_prob`
        """
        if "sickness_prob" in resource.model_fields_set:
            return resource.sickness_prob
        return self.config.constrained_scheduling.sickness_prob

    def _resolve_calendar(
        self,
        resource: ResourceSpec,
        calendar_map: Dict[str, CalendarSpec],
        default_calendar: CalendarSpec | None,
        hours_per_day: float,
    ) -> CalendarSpec:
        """Resolve resource calendar with sensible defaults."""
        calendar = calendar_map.get(resource.calendar) or default_calendar
        if calendar is None:
            return CalendarSpec(
                id="default",
                work_hours_per_day=hours_per_day,
                work_days=[1, 2, 3, 4, 5],
                holidays=[],
            )
        return calendar

    def _build_resource_calendar_states(
        self,
        resource_map: Dict[str, ResourceSpec],
        calendar_map: Dict[str, CalendarSpec],
        default_calendar: CalendarSpec | None,
        hours_per_day: float,
    ) -> Dict[str, ResourceCalendarState]:
        """Resolve per-resource calendar attributes once for an iteration."""
        resource_calendar_states: Dict[str, ResourceCalendarState] = {}

        for resource_name, resource in resource_map.items():
            calendar = self._resolve_calendar(
                resource,
                calendar_map,
                default_calendar,
                hours_per_day,
            )
            resource_calendar_states[resource_name] = ResourceCalendarState(
                resource=resource,
                work_days=frozenset(calendar.work_days),
                holidays=frozenset(calendar.holidays),
                planned_absence=frozenset(resource.planned_absence),
                capacity_per_hour=resource.productivity_level * resource.availability,
                work_end_hour=min(calendar.work_hours_per_day, 24.0),
            )

        return resource_calendar_states

    def _is_resource_working_day(
        self,
        resource: ResourceSpec,
        d: date,
        calendar_map: Dict[str, CalendarSpec],
        default_calendar: CalendarSpec | None,
        *,
        preplanned_absence_only: bool = False,
        sickness_absence: Dict[str, Set[date]] | None = None,
    ) -> bool:
        """Check whether a date is a working day for a resource."""
        resource_name = resource.name or resource.id
        if resource_name is None:
            return False

        calendar_state = self._build_resource_calendar_states(
            {resource_name: resource},
            calendar_map,
            default_calendar,
            self.project.project.hours_per_day,
        )[resource_name]
        sickness_days = (
            sickness_absence.get(resource_name)
            if sickness_absence is not None
            else None
        )
        return self._is_resource_working_day_in_state(
            calendar_state,
            d,
            preplanned_absence_only=preplanned_absence_only,
            sickness_absence=sickness_days,
        )

    def _is_resource_working_day_in_state(
        self,
        resource_calendar_state: ResourceCalendarState,
        d: date,
        *,
        preplanned_absence_only: bool = False,
        sickness_absence: Set[date] | frozenset[date] | None = None,
    ) -> bool:
        """Check whether a date is workable using cached calendar state."""
        weekday = d.weekday() + 1  # Monday=1

        if weekday not in resource_calendar_state.work_days:
            return False
        if d in resource_calendar_state.holidays:
            return False
        if d in resource_calendar_state.planned_absence:
            return False
        if (
            not preplanned_absence_only
            and sickness_absence is not None
            and d in sickness_absence
        ):
            return False
        return True

    def _build_resource_availability_states(
        self,
        resource_calendar_states: Dict[str, ResourceCalendarState],
        start_date: date,
        horizon_days: int,
        sickness_absence: Dict[str, Set[date]],
    ) -> Dict[str, ResourceAvailabilityState]:
        """Build per-resource availability windows for one iteration."""
        resource_availability_states: Dict[str, ResourceAvailabilityState] = {}

        for resource_name, calendar_state in resource_calendar_states.items():
            windows: list[tuple[float, float]] = []
            sickness_days = frozenset(sickness_absence.get(resource_name, set()))

            for current_day in range(horizon_days):
                current_date = start_date + timedelta(days=current_day)
                if not self._is_resource_working_day_in_state(
                    calendar_state,
                    current_date,
                    sickness_absence=sickness_days,
                ):
                    continue

                start_hour = current_day * 24.0
                end_hour = start_hour + calendar_state.work_end_hour
                if end_hour > start_hour:
                    windows.append((start_hour, end_hour))

            resource_availability_states[resource_name] = ResourceAvailabilityState(
                calendar_state=calendar_state,
                sickness_absence=sickness_days,
                windows=tuple(windows),
                starts=tuple(start for start, _ in windows),
                ends=tuple(end for _, end in windows),
            )

        return resource_availability_states

    @staticmethod
    def _resource_has_capacity_at_time(
        resource_availability_state: ResourceAvailabilityState,
        t: float,
    ) -> bool:
        """Return whether a resource is available at time ``t``."""
        idx = bisect_right(resource_availability_state.starts, t) - 1
        return idx >= 0 and t < resource_availability_state.ends[idx] - 1e-9

    @staticmethod
    def _next_resource_change_after(
        resource_availability_state: ResourceAvailabilityState,
        t: float,
    ) -> float | None:
        """Return the next start or end boundary for one resource after ``t``."""
        idx = bisect_right(resource_availability_state.starts, t) - 1
        if idx >= 0 and t < resource_availability_state.ends[idx] - 1e-9:
            return resource_availability_state.ends[idx]

        next_idx = bisect_right(resource_availability_state.starts, t + 1e-9)
        if next_idx < len(resource_availability_state.starts):
            return resource_availability_state.starts[next_idx]
        return None

    def _capacity_at_time(
        self,
        t: float,
        assigned: list[str] | tuple[str, ...],
        resource_availability_states: Dict[str, ResourceAvailabilityState],
    ) -> float:
        """Compute effective capacity (person-hours/clock-hour) at time t."""
        capacity = 0.0
        for resource_name in assigned:
            resource_availability_state = resource_availability_states[resource_name]
            if self._resource_has_capacity_at_time(resource_availability_state, t):
                capacity += resource_availability_state.calendar_state.capacity_per_hour
        return capacity

    def _next_capacity_change(
        self,
        t: float,
        assigned: list[str] | tuple[str, ...],
        resource_availability_states: Dict[str, ResourceAvailabilityState],
    ) -> float | None:
        """Find the next time where assigned aggregate capacity may change."""
        candidates = [
            next_change
            for resource_name in assigned
            if (
                next_change := self._next_resource_change_after(
                    resource_availability_states[resource_name],
                    t,
                )
            )
            is not None
        ]
        if not candidates:
            return None
        return min(candidates)

    def _find_next_time_with_capacity(
        self,
        start_t: float,
        assigned: list[str],
        resource_availability_states: Dict[str, ResourceAvailabilityState],
    ) -> float | None:
        """Find next time point with non-zero available capacity."""
        t = start_t
        max_search_hours = 24.0 * 730.0  # Safety bound: ~2 years
        while t - start_t < max_search_hours:
            if self._capacity_at_time(t, assigned, resource_availability_states) > 0:
                return t
            next_change = self._next_capacity_change(
                t,
                assigned,
                resource_availability_states,
            )
            if next_change is None:
                return None
            t = next_change
        return None

    def _compute_task_end_with_calendars(
        self,
        start_t: float,
        effort_hours: float,
        assigned: list[str],
        resource_availability_states: Dict[str, ResourceAvailabilityState],
    ) -> tuple[float, float]:
        """Integrate effort over cached resource-capacity windows."""
        remaining_effort = effort_hours
        t = start_t
        calendar_delay_hours = 0.0

        while remaining_effort > 1e-9:
            cap = self._capacity_at_time(t, assigned, resource_availability_states)
            next_change = self._next_capacity_change(
                t,
                assigned,
                resource_availability_states,
            )

            if next_change is None:
                raise RuntimeError(
                    "Resource-constrained scheduler exhausted precomputed capacity "
                    "windows before task completion."
                )

            if cap <= 0:
                calendar_delay_hours += max(0.0, next_change - t)
                t = next_change
                continue

            dt = next_change - t
            producible = cap * dt
            if producible >= remaining_effort:
                t += remaining_effort / cap
                remaining_effort = 0.0
            else:
                remaining_effort -= producible
                t = next_change

        return t, calendar_delay_hours

    def _integrate_available_capacity(
        self,
        start_t: float,
        end_t: float,
        resource_names: list[str] | tuple[str, ...],
        resource_availability_states: Dict[str, ResourceAvailabilityState],
    ) -> float:
        """Integrate available capacity (person-hours) over a timeline."""
        if end_t <= start_t:
            return 0.0

        t = start_t
        total_capacity = 0.0
        while t < end_t - 1e-9:
            cap = self._capacity_at_time(
                t,
                resource_names,
                resource_availability_states,
            )
            next_change = self._next_capacity_change(
                t,
                resource_names,
                resource_availability_states,
            )
            if next_change is None:
                break
            segment_end = min(end_t, next_change)
            dt = max(0.0, segment_end - t)
            total_capacity += cap * dt
            t = segment_end

        return total_capacity

    def _build_static_graph_data(
        self,
    ) -> tuple[tuple[str, ...], Dict[str, tuple[str, ...]]]:
        """Compute task graph data that stays constant for one scheduler instance."""
        # Calculate in-degree for each task
        in_degree: Dict[str, int] = {task.id: 0 for task in self.project.tasks}
        adjacency: Dict[str, List[str]] = {task.id: [] for task in self.project.tasks}

        for task in self.project.tasks:
            for dep_id in task.dependencies:
                adjacency[dep_id].append(task.id)
                in_degree[task.id] += 1

        # Queue of tasks with no dependencies
        queue = deque(task_id for task_id, degree in in_degree.items() if degree == 0)
        sorted_tasks: List[str] = []

        while queue:
            task_id = queue.popleft()
            sorted_tasks.append(task_id)

            # Reduce in-degree for dependent tasks
            for dependent_id in adjacency[task_id]:
                in_degree[dependent_id] -= 1
                if in_degree[dependent_id] == 0:
                    queue.append(dependent_id)

        # Check if all tasks were sorted (no cycles)
        if len(sorted_tasks) != len(self.project.tasks):
            raise ValueError("Circular dependency detected in project tasks")

        successor_map = {task_id: tuple(adjacency[task_id]) for task_id in sorted_tasks}
        return tuple(sorted_tasks), successor_map

    def _topological_sort(self) -> List[str]:
        """Return the cached topological task order as a list."""
        return list(self._topological_order)

    def calculate_slack(
        self, schedule: Dict[str, Dict[str, float]]
    ) -> Dict[str, float]:
        """Calculate total float (slack) for each task.

        Total float is the amount of time a task can be delayed without
        delaying the project. Computed via a backward pass from the
        project end time.

        Args:
            schedule: Task schedule from schedule_tasks()

        Returns:
            Dictionary mapping task IDs to their total float in hours
        """
        if not schedule:
            return {}

        project_end = max(info["end"] for info in schedule.values())

        # Backward pass: compute latest start
        latest_start: Dict[str, float] = {}
        for task_id in reversed(self._topological_order):
            successors = self._successor_map[task_id]
            if not successors:
                # No successors: latest finish = project end
                latest_start[task_id] = project_end - schedule[task_id]["duration"]
            else:
                # LF = min(LS of successors), LS = LF - duration
                min_succ_ls = min(latest_start[succ] for succ in successors)
                latest_start[task_id] = min_succ_ls - schedule[task_id]["duration"]

        slack: Dict[str, float] = {}
        for task_id, info in schedule.items():
            slack[task_id] = max(0.0, latest_start[task_id] - info["start"])

        return slack

    def max_parallel_tasks(self, schedule: Dict[str, Dict[str, float]]) -> int:
        """Compute the peak number of concurrently running tasks.

        Uses a sweep-line over task start/end events.  At a given point in
        time a task is considered active during the half-open interval
        ``[start, end)`` so that a task ending exactly when another begins
        does not count as concurrent.

        Args:
            schedule: Task schedule from schedule_tasks()

        Returns:
            Maximum number of tasks active at any single point in time
        """
        if not schedule:
            return 0

        # Build event list: +1 for a task starting, -1 for a task ending.
        events: list[tuple[float, int]] = []
        for info in schedule.values():
            events.append((info["start"], 1))
            events.append((info["end"], -1))

        # Sort by time; at equal times process end events before start
        # events so that back-to-back tasks are not counted as parallel.
        events.sort(key=lambda e: (e[0], e[1]))

        current = 0
        peak = 0
        for _, delta in events:
            current += delta
            if current > peak:
                peak = current

        return peak

    def get_critical_path(self, schedule: Dict[str, Dict[str, float]]) -> Set[str]:
        """Identify critical path tasks.

        Args:
            schedule: Task schedule from schedule_tasks()

        Returns:
            Set of task IDs on the critical path
        """
        critical_paths = self.get_critical_paths(schedule)
        return {task_id for path in critical_paths for task_id in path}

    def get_critical_paths(
        self, schedule: Dict[str, Dict[str, float]]
    ) -> list[tuple[str, ...]]:
        """Identify all full critical path sequences.

        Args:
            schedule: Task schedule from `schedule_tasks()`

        Returns:
            Sorted list of critical path sequences from start task to end task
        """
        if not schedule:
            return []

        project_end = max(info["end"] for info in schedule.values())
        critical_paths: set[tuple[str, ...]] = set()
        cache: Dict[str, set[tuple[str, ...]]] = {}

        for task_id, info in schedule.items():
            if abs(info["end"] - project_end) < 1e-9:  # Float comparison tolerance
                critical_paths.update(
                    self._trace_critical_paths(task_id, schedule, cache)
                )

        return sorted(critical_paths)

    def _trace_critical_paths(
        self,
        task_id: str,
        schedule: Dict[str, Dict[str, float]],
        cache: Dict[str, set[tuple[str, ...]]],
    ) -> set[tuple[str, ...]]:
        """Recursively trace all critical paths backwards.

        Args:
            task_id: Current task ID
            schedule: Task schedule
            cache: Memoized critical paths ending at each task

        Returns:
            Set of critical path sequences ending at `task_id`
        """
        if task_id in cache:
            return cache[task_id]

        task = self.task_map[task_id]
        task_start = schedule[task_id]["start"]
        matching_dependencies = [
            dep_id
            for dep_id in task.dependencies
            if abs(schedule[dep_id]["end"] - task_start) < 1e-9
        ]

        if not matching_dependencies:
            leaf_paths: set[tuple[str, ...]] = {(task_id,)}
            cache[task_id] = leaf_paths
            return leaf_paths

        paths: set[tuple[str, ...]] = set()
        for dep_id in sorted(matching_dependencies):
            for path in self._trace_critical_paths(dep_id, schedule, cache):
                paths.add(path + (task_id,))

        cache[task_id] = paths
        return paths
