"""Export objects with their versions to a portable format.

Exports respect isolation: only objects owned by (or visible to) the
exporting principal are included. The export format is a self-contained
JSON-serializable package that can be imported into another Scoped instance.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import sqlalchemy as sa

from scoped.exceptions import AccessDeniedError
from scoped.storage._query import compile_for
from scoped.storage._schema import object_versions, scoped_objects
from scoped.storage.interface import StorageBackend
from scoped.types import now_utc


# ---------------------------------------------------------------------------
# Export data models
# ---------------------------------------------------------------------------

FORMAT_VERSION = "1.0"


@dataclass(frozen=True, slots=True)
class ExportedVersion:
    """A single object version in the export package."""

    version: int
    data: dict[str, Any]
    created_at: str
    created_by: str
    change_reason: str
    checksum: str


@dataclass(frozen=True, slots=True)
class ExportedObject:
    """A complete object with all its versions in the export package."""

    id: str
    object_type: str
    owner_id: str
    created_at: str
    lifecycle: str
    versions: list[ExportedVersion]


@dataclass(frozen=True, slots=True)
class ExportManifest:
    """Metadata about the export package."""

    format_version: str
    exported_at: str
    exported_by: str
    object_count: int
    version_count: int


@dataclass(frozen=True, slots=True)
class ExportPackage:
    """A portable, self-contained export of objects and their versions."""

    manifest: ExportManifest
    objects: list[ExportedObject]

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-compatible dict."""
        return {
            "manifest": {
                "format_version": self.manifest.format_version,
                "exported_at": self.manifest.exported_at,
                "exported_by": self.manifest.exported_by,
                "object_count": self.manifest.object_count,
                "version_count": self.manifest.version_count,
            },
            "objects": [
                {
                    "id": obj.id,
                    "object_type": obj.object_type,
                    "owner_id": obj.owner_id,
                    "created_at": obj.created_at,
                    "lifecycle": obj.lifecycle,
                    "versions": [
                        {
                            "version": v.version,
                            "data": v.data,
                            "created_at": v.created_at,
                            "created_by": v.created_by,
                            "change_reason": v.change_reason,
                            "checksum": v.checksum,
                        }
                        for v in obj.versions
                    ],
                }
                for obj in self.objects
            ],
        }

    def to_json(self, **kwargs: Any) -> str:
        """Serialize to a JSON string."""
        return json.dumps(self.to_dict(), **kwargs)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ExportPackage:
        """Deserialize from a dict."""
        m = data["manifest"]
        manifest = ExportManifest(
            format_version=m["format_version"],
            exported_at=m["exported_at"],
            exported_by=m["exported_by"],
            object_count=m["object_count"],
            version_count=m["version_count"],
        )
        objects = [
            ExportedObject(
                id=obj["id"],
                object_type=obj["object_type"],
                owner_id=obj["owner_id"],
                created_at=obj["created_at"],
                lifecycle=obj["lifecycle"],
                versions=[
                    ExportedVersion(
                        version=v["version"],
                        data=v["data"],
                        created_at=v["created_at"],
                        created_by=v["created_by"],
                        change_reason=v["change_reason"],
                        checksum=v["checksum"],
                    )
                    for v in obj["versions"]
                ],
            )
            for obj in data["objects"]
        ]
        return cls(manifest=manifest, objects=objects)

    @classmethod
    def from_json(cls, raw: str) -> ExportPackage:
        """Deserialize from a JSON string."""
        return cls.from_dict(json.loads(raw))


# ---------------------------------------------------------------------------
# Exporter
# ---------------------------------------------------------------------------

class Exporter:
    """Exports scoped objects to portable ExportPackage format.

    Only objects owned by the principal can be exported (Layer 3 isolation).
    For scope-aware export, pre-filter object_ids using VisibilityEngine.
    """

    def __init__(self, backend: StorageBackend) -> None:
        self._backend = backend

    def export_object(
        self,
        object_id: str,
        *,
        principal_id: str,
    ) -> ExportPackage:
        """Export a single object with all its versions."""
        return self.export_objects([object_id], principal_id=principal_id)

    def export_objects(
        self,
        object_ids: list[str],
        *,
        principal_id: str,
    ) -> ExportPackage:
        """Export multiple objects with all their versions.

        Only includes objects owned by principal_id. Objects not found
        or not owned are silently skipped.
        """
        exported: list[ExportedObject] = []
        total_versions = 0

        for oid in object_ids:
            obj_stmt = sa.select(scoped_objects).where(
                (scoped_objects.c.id == oid)
                & (scoped_objects.c.owner_id == principal_id)
            )
            sql, params = compile_for(obj_stmt, self._backend.dialect)
            obj_row = self._backend.fetch_one(sql, params)
            if obj_row is None:
                continue

            ver_stmt = sa.select(object_versions).where(
                object_versions.c.object_id == oid,
            ).order_by(object_versions.c.version)
            sql, params = compile_for(ver_stmt, self._backend.dialect)
            version_rows = self._backend.fetch_all(sql, params)

            versions = [
                ExportedVersion(
                    version=vr["version"],
                    data=json.loads(vr["data_json"]),
                    created_at=vr["created_at"],
                    created_by=vr["created_by"],
                    change_reason=vr["change_reason"],
                    checksum=vr["checksum"],
                )
                for vr in version_rows
            ]

            exported.append(ExportedObject(
                id=obj_row["id"],
                object_type=obj_row["object_type"],
                owner_id=obj_row["owner_id"],
                created_at=obj_row["created_at"],
                lifecycle=obj_row["lifecycle"],
                versions=versions,
            ))
            total_versions += len(versions)

        ts = now_utc()
        manifest = ExportManifest(
            format_version=FORMAT_VERSION,
            exported_at=ts.isoformat(),
            exported_by=principal_id,
            object_count=len(exported),
            version_count=total_versions,
        )

        return ExportPackage(manifest=manifest, objects=exported)

    def export_by_type(
        self,
        object_type: str,
        *,
        principal_id: str,
        limit: int = 1000,
    ) -> ExportPackage:
        """Export all objects of a given type owned by the principal."""
        stmt = sa.select(scoped_objects.c.id).where(
            (scoped_objects.c.object_type == object_type)
            & (scoped_objects.c.owner_id == principal_id)
        ).limit(limit)
        sql, params = compile_for(stmt, self._backend.dialect)
        rows = self._backend.fetch_all(sql, params)
        object_ids = [r["id"] for r in rows]
        return self.export_objects(object_ids, principal_id=principal_id)

    # ------------------------------------------------------------------
    # Streaming export (NDJSON)
    # ------------------------------------------------------------------

    def stream_export(
        self,
        object_ids: list[str],
        *,
        principal_id: str,
    ) -> Iterator[str]:
        """Export objects as a stream of NDJSON lines.

        Yields one JSON line per object (including all its versions).
        First line is always a manifest header with ``_type: "manifest"``.
        Memory usage is O(single_object) not O(all_objects).
        """
        ts = now_utc()
        manifest_line = json.dumps({
            "_type": "manifest",
            "format_version": FORMAT_VERSION,
            "exported_at": ts.isoformat(),
            "exported_by": principal_id,
        })
        yield manifest_line

        for oid in object_ids:
            line = self._export_object_line(oid, principal_id)
            if line is not None:
                yield line

    def stream_export_by_type(
        self,
        object_type: str,
        *,
        principal_id: str,
        batch_size: int = 100,
    ) -> Iterator[str]:
        """Export all objects of a type as a stream of NDJSON lines.

        Object IDs are fetched in pages of ``batch_size`` to avoid
        loading all IDs at once.
        """
        ts = now_utc()
        manifest_line = json.dumps({
            "_type": "manifest",
            "format_version": FORMAT_VERSION,
            "exported_at": ts.isoformat(),
            "exported_by": principal_id,
        })
        yield manifest_line

        offset = 0
        while True:
            stmt = sa.select(scoped_objects.c.id).where(
                (scoped_objects.c.object_type == object_type)
                & (scoped_objects.c.owner_id == principal_id)
            ).limit(batch_size).offset(offset)
            sql, params = compile_for(stmt, self._backend.dialect)
            rows = self._backend.fetch_all(sql, params)
            if not rows:
                break
            for row in rows:
                line = self._export_object_line(row["id"], principal_id)
                if line is not None:
                    yield line
            offset += batch_size

    def _export_object_line(self, object_id: str, principal_id: str) -> str | None:
        """Fetch a single object + versions and return as a JSON line.

        Returns None if the object doesn't exist or isn't owned by principal.
        """
        obj_stmt = sa.select(scoped_objects).where(
            (scoped_objects.c.id == object_id)
            & (scoped_objects.c.owner_id == principal_id)
        )
        sql, params = compile_for(obj_stmt, self._backend.dialect)
        obj_row = self._backend.fetch_one(sql, params)
        if obj_row is None:
            return None

        ver_stmt = sa.select(object_versions).where(
            object_versions.c.object_id == object_id,
        ).order_by(object_versions.c.version)
        sql, params = compile_for(ver_stmt, self._backend.dialect)
        version_rows = self._backend.fetch_all(sql, params)

        obj_dict = {
            "id": obj_row["id"],
            "object_type": obj_row["object_type"],
            "owner_id": obj_row["owner_id"],
            "created_at": obj_row["created_at"],
            "lifecycle": obj_row["lifecycle"],
            "versions": [
                {
                    "version": vr["version"],
                    "data": json.loads(vr["data_json"]),
                    "created_at": vr["created_at"],
                    "created_by": vr["created_by"],
                    "change_reason": vr["change_reason"],
                    "checksum": vr["checksum"],
                }
                for vr in version_rows
            ],
        }
        return json.dumps(obj_dict)
