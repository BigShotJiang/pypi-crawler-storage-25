"""Shared helpers for taibai commands."""

import asyncio
import os
from collections.abc import Coroutine
from html.parser import HTMLParser
from typing import Any

from longwei import APClient
from longwei import RatelimitError
from longwei import Visibility
from longwei.models import Account
from rich.console import Console

from taibai.config import get_profile
from taibai.credentials import load_token

err_console = Console(stderr=True)


class _HTMLStripper(HTMLParser):
    """Minimal HTML tag stripper using stdlib html.parser."""

    def __init__(self) -> None:
        """Initialise with an empty text buffer."""
        super().__init__()
        self._parts: list[str] = []

    def handle_data(self, data: str) -> None:
        """Accumulate text nodes."""
        self._parts.append(data)

    def get_text(self) -> str:
        """Return the accumulated plain text."""
        return "".join(self._parts)


def _strip_html(html: str) -> str:
    """Strip all HTML tags from a string and return plain text."""
    stripper = _HTMLStripper()
    stripper.feed(html)
    return stripper.get_text()


def _ratelimit_message(exc: RatelimitError) -> str:
    """Return a human-readable rate-limit error message.

    Args:
        exc: The RatelimitError raised by longwei.

    Returns:
        A human-readable string describing the rate limit and when to retry.

    """
    if exc.ratelimit_reset is not None:
        return f"Rate limit exceeded. Retry after {exc.ratelimit_reset.strftime('%H:%M:%S UTC')}."
    return "Rate limit exceeded. Please try again later."


def _resolve_status_id(url_or_id: str) -> str:
    """Extract a numeric status ID from a URL or return the ID as-is.

    Args:
        url_or_id: A full status URL or a bare numeric ID.

    Returns:
        The status ID string.

    """
    if url_or_id.startswith("http"):
        return url_or_id.rstrip("/").rsplit("/", 1)[-1]
    return url_or_id


async def _resolve_account(ap: APClient, handle_or_id: str) -> Account:
    """Resolve a handle (user@host or @user@host) or numeric ID to an Account.

    Args:
        ap: An authenticated APClient instance.
        handle_or_id: A ``user@domain`` handle, a handle with a leading ``@``,
            or a bare numeric account ID.

    Returns:
        The resolved :class:`Account`.

    """
    acct = handle_or_id.lstrip("@")
    if "@" in acct or not acct.isdigit():
        return await ap.lookup_account(acct)
    return await ap.get_account(acct)


def resolve_auth(profile: str) -> tuple[str, str]:
    """Return (instance_url, access_token) from env vars or a stored profile.

    Checks TAIBAI_INSTANCE_URL and TAIBAI_ACCESS_TOKEN first. Both must be set
    together for env-var mode; setting only one is an error. Falls back to the
    named profile in config + keyring when neither var is present.

    Args:
        profile: Profile name used when env vars are absent.

    Returns:
        A ``(instance_url, access_token)`` tuple ready for ``APClient.create``.

    """
    env_url = os.environ.get("TAIBAI_INSTANCE_URL", "").rstrip("/")
    env_token = os.environ.get("TAIBAI_ACCESS_TOKEN", "")

    if env_url and env_token:
        return env_url, env_token
    if env_url and not env_token:
        die("TAIBAI_INSTANCE_URL is set but TAIBAI_ACCESS_TOKEN is missing.")
    if env_token and not env_url:
        die("TAIBAI_ACCESS_TOKEN is set but TAIBAI_INSTANCE_URL is missing.")

    stored_profile = get_profile(profile)
    if stored_profile is None:
        die(f"Profile '{profile}' not found. Run `taibai init --profile {profile}`.")
        return "", ""  # unreachable; die() raises SystemExit
    access_token = load_token(profile)
    if access_token is None:
        die(f"No credentials for profile '{profile}'. Run `taibai init --profile {profile}`.")
        return stored_profile.instance_url, ""  # unreachable
    return stored_profile.instance_url, access_token


def _resolve_visibility(visibility: str) -> Visibility:
    """Resolve a visibility string to a Visibility enum value, dying on invalid input.

    Args:
        visibility: One of 'public', 'unlisted', 'private', or 'direct'.

    Returns:
        The matching Visibility enum value.

    """
    try:
        return Visibility(visibility)
    except ValueError:
        valid = ", ".join(v.value for v in Visibility)
        die(f"Invalid visibility {visibility!r}. Choose from: {valid}.")
        return Visibility.PUBLIC  # unreachable


def run_async(coro: Coroutine[Any, Any, Any]) -> Any:
    """Run an async coroutine from a synchronous command."""
    return asyncio.run(coro)


def die(message: str, exit_code: int = 1) -> None:
    """Print an error to stderr and exit."""
    err_console.print(f"[bold red]Error:[/bold red] {message}")
    raise SystemExit(exit_code)
