"""Shared Rich rendering helpers for status display."""

from longwei.models import Status
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from taibai._utils import _strip_html

_TRUNCATE = 120


def _fmt_time(created_at: str | None) -> str:
    """Format an ISO 8601 timestamp to ``YYYY-MM-DD HH:MM``."""
    if not created_at:
        return ""
    return created_at[:16].replace("T", " ")


def _status_row(status: Status) -> tuple[str, str, str]:
    """Extract displayable fields from a status for table rendering.

    Args:
        status: The status to display.

    Returns:
        A 3-tuple of Rich-markup strings: (from_cell, content_cell, stats_cell).

    """
    src = status.reblog or status
    acct = f"@{src.account.acct}" if src.account and src.account.acct else ""
    if status.reblog and status.account and src.account:
        acct = f"↩ @{status.account.acct} → @{src.account.acct}"

    from_cell = f"[green]{acct}[/green]\n[dim]{_fmt_time(src.created_at)}[/dim]\n[dim]{src.id or ''}[/dim]"

    cw = src.spoiler_text or ""
    body = _strip_html(src.content or "")[:_TRUNCATE]
    content_cell = f"[yellow bold]CW:[/yellow bold] [yellow]{cw}[/yellow]\n{body}" if cw else body

    stats_cell = f"[red]♥ {src.favourites_count or 0}[/red]\n[cyan]♺ {src.reblogs_count or 0}[/cyan]"

    return from_cell, content_cell, stats_cell


def _render_status_table(statuses: list[Status], console: Console) -> None:
    """Render a list of statuses as a Rich Table.

    Args:
        statuses: Statuses to display.
        console: Rich Console to print to.

    """
    if not statuses:
        console.print("[dim]No statuses.[/dim]")
        return

    table = Table(show_header=True, header_style="bold magenta", show_lines=True)
    table.add_column("From", no_wrap=True, width=30)
    table.add_column("Content", overflow="fold")
    table.add_column("", no_wrap=True, width=6)

    for status in statuses:
        table.add_row(*_status_row(status))

    console.print(table)


def _render_status_panel(status: Status, console: Console, label: str = "") -> None:
    """Render a single status as a Rich Panel.

    Args:
        status: Status to display.
        console: Rich Console to print to.
        label: Optional label shown in the panel border (e.g. "↑ ancestor").

    """
    acct = f"@{status.account.acct}" if status.account and status.account.acct else "unknown"
    time_str = _fmt_time(status.created_at)
    visibility = status.visibility or ""
    cw = status.spoiler_text or ""
    content = _strip_html(status.content or "")
    boosts = status.reblogs_count or 0
    favs = status.favourites_count or 0
    replies = status.replies_count or 0
    url = status.url or ""

    parts: list[str] = []
    if cw:
        parts.append(f"[yellow]CW:[/yellow] {cw}\n")
    parts.append(content)
    parts.append(f"\n[dim]{replies} replies  ♺ {boosts}  ♥ {favs}[/dim]")
    if url:
        parts.append(f"\n[dim]{url}[/dim]")

    title = f"[green]{acct}[/green]  [dim]{time_str}[/dim]  [dim]{visibility}[/dim]"
    if label:
        title = f"[dim]{label}[/dim]  {title}"

    console.print(Panel("".join(parts), title=title, expand=False))
