"""Taibai CLI entry point."""

from cyclopts import App

from taibai.commands.account import block_command
from taibai.commands.account import follow_command
from taibai.commands.account import mute_command
from taibai.commands.account import profile_command
from taibai.commands.account import unblock_command
from taibai.commands.account import unfollow_command
from taibai.commands.account import unmute_command
from taibai.commands.edit import edit_command
from taibai.commands.init import init_command
from taibai.commands.interact import bookmark_command
from taibai.commands.interact import bookmarks_command
from taibai.commands.interact import boost_command
from taibai.commands.interact import delete_command
from taibai.commands.interact import fav_command
from taibai.commands.interact import favourites_command
from taibai.commands.interact import pin_command
from taibai.commands.interact import unbookmark_command
from taibai.commands.interact import unboost_command
from taibai.commands.interact import unfav_command
from taibai.commands.interact import unpin_command
from taibai.commands.notifications import notifications_command
from taibai.commands.post import post_command
from taibai.commands.search import search_command
from taibai.commands.thread import thread_command
from taibai.commands.timeline import timeline_command
from taibai.commands.view import view_command
from taibai.commands.whoami import whoami_command

app = App(
    name="taibai",
    help="Fediverse CLI — celestial messenger for the federation.",
)

app.command(name="init")(init_command)
app.command(name="post")(post_command)
app.command(name="notifications")(notifications_command)
app.command(name="timeline")(timeline_command)
app.command(name="view")(view_command)
app.command(name="whoami")(whoami_command)
app.command(name="fav")(fav_command)
app.command(name="unfav")(unfav_command)
app.command(name="boost")(boost_command)
app.command(name="unboost")(unboost_command)
app.command(name="bookmark")(bookmark_command)
app.command(name="unbookmark")(unbookmark_command)
app.command(name="pin")(pin_command)
app.command(name="unpin")(unpin_command)
app.command(name="delete")(delete_command)
app.command(name="edit")(edit_command)
app.command(name="bookmarks")(bookmarks_command)
app.command(name="favourites")(favourites_command)
app.command(name="follow")(follow_command)
app.command(name="unfollow")(unfollow_command)
app.command(name="mute")(mute_command)
app.command(name="unmute")(unmute_command)
app.command(name="block")(block_command)
app.command(name="unblock")(unblock_command)
app.command(name="profile")(profile_command)
app.command(name="search")(search_command)
app.command(name="thread")(thread_command)
