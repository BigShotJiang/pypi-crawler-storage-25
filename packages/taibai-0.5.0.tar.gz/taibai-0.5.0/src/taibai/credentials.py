"""Credential storage for taibai.

Tokens are stored in the OS keyring where available. On headless systems
(no SecretService / D-Bus), the module falls back to the config file and
prints a one-time warning. The fallback is plaintext; users can migrate to a
real keyring at any time by re-running `taibai init`.
"""

import logging

import keyring
import keyring.errors
from rich.console import Console

from taibai.config import config_path
from taibai.config import load_config
from taibai.config import save_config

logger = logging.getLogger(__name__)

_KEYRING_SERVICE = "taibai"
_WARNED: set[str] = set()  # profiles for which the headless warning was printed
_err = Console(stderr=True)


def _key(profile_name: str) -> str:
    """Return the keyring username key for a profile."""
    return f"taibai::{profile_name}"


def _warn_headless(profile_name: str) -> None:
    """Print a one-time warning that the file fallback is active."""
    if profile_name not in _WARNED:
        _WARNED.add(profile_name)
        _err.print(
            "[yellow]Warning:[/yellow] No keyring backend available. "
            f"Token for profile '{profile_name}' is stored in plaintext at "
            f"{config_path()} — protect this file accordingly."
        )


# ── file-based fallback ────────────────────────────────────────────────────


def _save_fallback(profile_name: str, access_token: str) -> None:
    """Persist token in config.json under _tokens."""
    cfg = load_config()
    cfg.setdefault("_tokens", {})[profile_name] = access_token
    save_config(cfg)


def _load_fallback(profile_name: str) -> str | None:
    """Load token from config.json fallback store."""
    return load_config().get("_tokens", {}).get(profile_name)


def _delete_fallback(profile_name: str) -> None:
    """Remove token from config.json fallback store."""
    cfg = load_config()
    cfg.get("_tokens", {}).pop(profile_name, None)
    save_config(cfg)


# ── public API ─────────────────────────────────────────────────────────────


def save_token(profile_name: str, access_token: str) -> None:
    """Save an access token to the OS keyring, falling back to config file."""
    try:
        keyring.set_password(_KEYRING_SERVICE, _key(profile_name), access_token)
    except Exception as exc:  # broad catch intentional: covers dbus/headless variants
        logger.debug("Keyring unavailable for save (%s); using file fallback.", exc)
        _warn_headless(profile_name)
        _save_fallback(profile_name, access_token)


def load_token(profile_name: str) -> str | None:
    """Load an access token. Checks keyring first, then config-file fallback."""
    try:
        token = keyring.get_password(_KEYRING_SERVICE, _key(profile_name))
        if token is not None:
            return token
    except Exception as exc:  # broad catch intentional: covers dbus/headless variants
        logger.debug("Keyring unavailable for load (%s); using file fallback.", exc)
    return _load_fallback(profile_name)


def delete_token(profile_name: str) -> None:
    """Delete an access token from keyring and config-file fallback."""
    try:
        keyring.delete_password(_KEYRING_SERVICE, _key(profile_name))
    except Exception as exc:  # broad catch intentional: covers PasswordDeleteError + dbus variants
        logger.debug("Keyring delete skipped (%s).", exc)
    _delete_fallback(profile_name)
