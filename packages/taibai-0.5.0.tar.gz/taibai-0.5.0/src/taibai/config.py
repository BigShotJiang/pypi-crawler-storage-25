"""Profile configuration management for taibai."""

import json
import os
from dataclasses import asdict
from dataclasses import dataclass
from pathlib import Path

import platformdirs


@dataclass
class Profile:
    """A named account profile storing instance and app registration data."""

    name: str
    instance_url: str
    client_id: str
    client_secret: str
    username: str
    last_seen_notification_id: str | None = None


def config_path() -> Path:
    """Return the path to config.json, creating the parent directory if needed."""
    config_dir = Path(platformdirs.user_config_dir("taibai", ensure_exists=True))
    return config_dir / "config.json"


def load_config() -> dict:
    """Load and return the raw config dict. Returns empty dict if file absent."""
    path = config_path()
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def save_config(config: dict) -> None:
    """Atomically write the config dict to config.json."""
    path = config_path()
    tmp = path.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        json.dump(config, fh, indent=2)
        fh.write("\n")
    os.replace(tmp, path)


def get_profile(name: str) -> Profile | None:
    """Return the named Profile, or None if it does not exist."""
    config = load_config()
    raw = config.get("profiles", {}).get(name)
    if raw is None:
        return None
    return Profile(**raw)


def save_profile(profile: Profile) -> None:
    """Insert or update a profile in config.json."""
    config = load_config()
    config.setdefault("profiles", {})[profile.name] = asdict(profile)
    if "default_profile" not in config:
        config["default_profile"] = profile.name
    save_config(config)


def delete_profile(name: str) -> None:
    """Remove a profile from config.json. Silent if not found."""
    config = load_config()
    config.get("profiles", {}).pop(name, None)
    if config.get("default_profile") == name:
        remaining = list(config.get("profiles", {}).keys())
        config["default_profile"] = remaining[0] if remaining else None
    save_config(config)


def get_default_profile_name() -> str | None:
    """Return the name of the default profile, or None if no profiles exist."""
    config = load_config()
    return config.get("default_profile")


def set_default_profile(name: str) -> None:
    """Set the named profile as the default."""
    config = load_config()
    config["default_profile"] = name
    save_config(config)


def update_last_seen_notification(profile_name: str, notification_id: str) -> None:
    """Update last_seen_notification_id for a profile."""
    config = load_config()
    profiles = config.get("profiles", {})
    if profile_name in profiles:
        profiles[profile_name]["last_seen_notification_id"] = notification_id
        save_config(config)
