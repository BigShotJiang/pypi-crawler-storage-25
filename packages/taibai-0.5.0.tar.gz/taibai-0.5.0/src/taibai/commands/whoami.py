"""The `whoami` command: verify credentials and display the current account."""

import json as json_mod
from typing import Annotated

import httpx
from cyclopts import Parameter
from longwei import ActivityPubError
from longwei import APClient
from longwei import NetworkError
from longwei import UnauthorizedError
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from taibai._utils import die
from taibai._utils import resolve_auth
from taibai._utils import run_async

console = Console()


def whoami_command(
    json_out: Annotated[
        bool, Parameter(name="--json", negative="", help="Dump account info as JSON instead of a panel.")
    ] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Verify stored credentials and display the current account."""
    instance_url, access_token = resolve_auth(profile)

    try:
        run_async(_do_whoami(instance_url, access_token, json_out=json_out))
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


async def _do_whoami(instance_url: str, access_token: str, json_out: bool = False) -> None:
    """Fetch and display account info.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        json_out: When True, dump account info as JSON instead of a panel.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        account = await ap.verify_credentials()

    if json_out:
        console.print_json(json_mod.dumps(account.model_dump(exclude_none=True)))
        return

    display = account.display_name or account.username or account.acct
    text = Text()
    text.append(f"{display}\n", style="bold")
    text.append(f"@{account.acct}\n", style="green")
    text.append(f"{instance_url}\n\n", style="dim")
    text.append(
        f"Followers: {account.followers_count}  Following: {account.following_count}  Posts: {account.statuses_count}"
    )

    console.print(Panel(text, title="Account Info", border_style="blue"))
