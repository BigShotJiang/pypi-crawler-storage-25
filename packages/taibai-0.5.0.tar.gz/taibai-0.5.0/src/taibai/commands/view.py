"""The `view` command: fetch and display a single status or thread."""

import json as json_mod
from typing import Annotated

import httpx
from cyclopts import Parameter
from longwei import ActivityPubError
from longwei import APClient
from longwei import NetworkError
from longwei import UnauthorizedError
from rich.console import Console

from taibai._render import _render_status_panel
from taibai._utils import _resolve_status_id
from taibai._utils import die
from taibai._utils import resolve_auth
from taibai._utils import run_async

console = Console()


def view_command(
    status_id: Annotated[str, Parameter(show=True, help="Status URL or ID.")],
    show_context: Annotated[
        bool, Parameter(name="--context", negative="", help="Show the full thread (ancestors and descendants).")
    ] = False,
    json_out: Annotated[
        bool, Parameter(name="--json", negative="", help="Dump status as JSON (all fields with values).")
    ] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Fetch and display a status by URL or ID."""
    resolved_id = _resolve_status_id(status_id)

    instance_url, access_token = resolve_auth(profile)

    try:
        run_async(
            _do_view(
                instance_url,
                access_token,
                status_id=resolved_id,
                show_context=show_context,
                json_out=json_out,
            )
        )
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


async def _do_view(
    instance_url: str,
    access_token: str,
    status_id: str,
    show_context: bool,
    json_out: bool = False,
) -> None:
    """Fetch and render a single status or thread.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        status_id: The numeric status ID to fetch.
        show_context: Whether to fetch and display the surrounding thread.
        json_out: When True, dump the status as JSON instead of a rendered panel.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        status = await ap.get_status(status_id)
        if json_out:
            console.print_json(json_mod.dumps(status.model_dump(exclude_none=True)))
            return
        ctx = await ap.get_status_context(status_id) if show_context else None

    if ctx:
        for ancestor in ctx.ancestors:
            _render_status_panel(ancestor, console, label="↑ ancestor")

    _render_status_panel(status, console, label="")

    if ctx:
        for descendant in ctx.descendants:
            _render_status_panel(descendant, console, label="↓ reply")
