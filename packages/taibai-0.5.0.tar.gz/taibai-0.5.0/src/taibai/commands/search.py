"""Search command: statuses, accounts, and hashtags."""

import json as json_mod
from typing import Annotated

import httpx
from cyclopts import Parameter
from longwei import ActivityPubError
from longwei import APClient
from longwei import NetworkError
from longwei import RatelimitError
from longwei import SearchType
from longwei import UnauthorizedError
from rich.console import Console
from rich.table import Table

from taibai._render import _render_status_table
from taibai._utils import _ratelimit_message
from taibai._utils import die
from taibai._utils import resolve_auth
from taibai._utils import run_async

console = Console()

_SEARCH_TYPES: dict[str, SearchType] = {
    "statuses": SearchType.STATUSES,
    "accounts": SearchType.ACCOUNTS,
    "hashtags": SearchType.HASHTAGS,
}

_VALID_TYPES = ("statuses", "accounts", "hashtags", "all")


def _render_accounts_table(accounts: list, con: Console) -> None:  # type: ignore[type-arg]
    """Render a list of accounts as a Rich table.

    Args:
        accounts: Account objects to display.
        con: Rich Console to print to.

    """
    table = Table(show_header=True, header_style="bold magenta", show_lines=True)
    table.add_column("Handle", no_wrap=True)
    table.add_column("Display name")
    table.add_column("Followers", no_wrap=True)
    for acct in accounts:
        handle = f"@{acct.acct}" if acct.acct else ""
        display = acct.display_name or ""
        followers = str(acct.followers_count or 0)
        table.add_row(handle, display, followers)
    con.print(table)


def _render_hashtags_table(hashtags: list, con: Console) -> None:  # type: ignore[type-arg]
    """Render a list of hashtags as a Rich table.

    Args:
        hashtags: Tag objects to display.
        con: Rich Console to print to.

    """
    table = Table(show_header=True, header_style="bold magenta", show_lines=True)
    table.add_column("Tag", no_wrap=True)
    table.add_column("URL")
    for tag in hashtags:
        table.add_row(f"#{tag.name}", tag.url or "")
    con.print(table)


async def _search_one_type(
    ap: APClient,
    query: str,
    query_type: SearchType,
    limit: int,
    resolve: bool,
) -> tuple[list, list, list]:  # type: ignore[type-arg]
    """Search for a single type and return (statuses, accounts, hashtags).

    Args:
        ap: An authenticated APClient instance.
        query: The search query.
        query_type: The type of results to fetch.
        limit: Maximum results to return.
        resolve: Whether to perform a remote WebFinger lookup.

    Returns:
        A 3-tuple of (statuses, accounts, hashtags) lists.

    """
    results = await ap.search(query, query_type, resolve=resolve, limit=limit)
    return results.statuses or [], results.accounts or [], results.hashtags or []


def _print_search_results(
    all_statuses: list,  # type: ignore[type-arg]
    all_accounts: list,  # type: ignore[type-arg]
    all_hashtags: list,  # type: ignore[type-arg]
) -> None:
    """Print the combined search results to console.

    Args:
        all_statuses: Collected status results.
        all_accounts: Collected account results.
        all_hashtags: Collected hashtag results.

    """
    found = False
    if all_statuses:
        found = True
        console.print("[bold]Statuses[/bold]")
        _render_status_table(all_statuses, console)
    if all_accounts:
        found = True
        console.print("[bold]Accounts[/bold]")
        _render_accounts_table(all_accounts, console)
    if all_hashtags:
        found = True
        console.print("[bold]Hashtags[/bold]")
        _render_hashtags_table(all_hashtags, console)
    if not found:
        console.print("No results found.")


async def _do_search(  # noqa: PLR0913
    instance_url: str,
    access_token: str,
    query: str,
    search_type: str,
    limit: int,
    *,
    resolve: bool = False,
    json_out: bool = False,
) -> None:
    """Run the search and display or dump results.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        query: The search query string.
        search_type: One of ``statuses``, ``accounts``, ``hashtags``, or ``all``.
        limit: Maximum results per type.
        resolve: Whether to force remote WebFinger resolution.
        json_out: When True, dump results as JSON.

    """
    types_to_query = list(_SEARCH_TYPES.values()) if search_type == "all" else [_SEARCH_TYPES[search_type]]

    all_statuses: list = []  # type: ignore[type-arg]
    all_accounts: list = []  # type: ignore[type-arg]
    all_hashtags: list = []  # type: ignore[type-arg]

    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        for qtype in types_to_query:
            ss, aa, hh = await _search_one_type(ap, query, qtype, limit, resolve)
            all_statuses.extend(ss)
            all_accounts.extend(aa)
            all_hashtags.extend(hh)

    if json_out:
        data = {
            "statuses": [s.model_dump(exclude_none=True) for s in all_statuses],
            "accounts": [a.model_dump(exclude_none=True) for a in all_accounts],
            "hashtags": [h.model_dump(exclude_none=True) for h in all_hashtags],
        }
        console.print_json(json_mod.dumps(data))
        return

    _print_search_results(all_statuses, all_accounts, all_hashtags)


def search_command(  # noqa: PLR0913
    query: Annotated[str, Parameter(show=True, help="Search query.")],
    search_type: Annotated[
        str,
        Parameter(
            name="--type",
            help="Result type: statuses, accounts, hashtags, or all (default).",
        ),
    ] = "all",
    limit: Annotated[int, Parameter(name=["--limit", "-n"], help="Maximum results per type.")] = 20,
    resolve: Annotated[
        bool, Parameter(name="--resolve", negative="", help="Force remote WebFinger lookup for accounts.")
    ] = False,
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump results as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Search for statuses, accounts, and hashtags."""
    if search_type not in _VALID_TYPES:
        die(f"Invalid type '{search_type}'. Use: statuses, accounts, hashtags, or all.")
        return

    instance_url, access_token = resolve_auth(profile)

    try:
        run_async(
            _do_search(
                instance_url,
                access_token,
                query,
                search_type,
                limit,
                resolve=resolve,
                json_out=json_out,
            )
        )
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except RatelimitError as exc:
        die(_ratelimit_message(exc))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")
