"""Interaction commands: fav, boost, bookmark, pin, delete, and listing commands."""

import json as json_mod
from typing import Annotated

import httpx
from cyclopts import Parameter
from longwei import ActivityPubError
from longwei import APClient
from longwei import NetworkError
from longwei import RatelimitError
from longwei import UnauthorizedError
from rich.console import Console

from taibai._render import _render_status_table
from taibai._utils import _ratelimit_message
from taibai._utils import _resolve_status_id
from taibai._utils import die
from taibai._utils import resolve_auth
from taibai._utils import run_async

console = Console()


def _run_action(
    status_id: str,
    profile: str,
    method_name: str,
    verb: str,
    *,
    json_out: bool = False,
) -> None:
    """Load credentials and call ap.<method_name>(resolved_id), then print or dump JSON.

    Args:
        status_id: Status URL or bare ID.
        profile: Profile name to use.
        method_name: Name of the APClient async method to call.
        verb: Past-tense verb for the success message (e.g. "Favourited").
        json_out: When True, dump the returned status as JSON.

    """
    resolved_id = _resolve_status_id(status_id)
    instance_url, access_token = resolve_auth(profile)

    try:
        run_async(_do_action(instance_url, access_token, resolved_id, method_name, verb, json_out=json_out))
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except RatelimitError as exc:
        die(_ratelimit_message(exc))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


async def _do_action(  # noqa: PLR0913
    instance_url: str,
    access_token: str,
    status_id: str,
    method_name: str,
    verb: str,
    *,
    json_out: bool = False,
) -> None:
    """Call the named APClient method and print the result.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        status_id: Resolved numeric status ID.
        method_name: APClient async method to call.
        verb: Past-tense label for the confirmation message.
        json_out: When True, dump the returned status as JSON.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        method = getattr(ap, method_name)
        status = await method(status_id)

    if json_out:
        console.print_json(json_mod.dumps(status.model_dump(exclude_none=True)))
        return
    url = status.url or status.uri
    console.print(f"{verb}: [link={url}]{url}[/link]")


def fav_command(
    status_id: Annotated[str, Parameter(show=True, help="Status URL or ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the status as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Mark a status as favourite."""
    _run_action(status_id, profile, "favourite", "Favourited", json_out=json_out)


def unfav_command(
    status_id: Annotated[str, Parameter(show=True, help="Status URL or ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the status as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Remove a favourite from a status."""
    _run_action(status_id, profile, "undo_favourite", "Unfavourited", json_out=json_out)


def boost_command(
    status_id: Annotated[str, Parameter(show=True, help="Status URL or ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the status as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Boost (reblog) a status."""
    _run_action(status_id, profile, "reblog", "Boosted", json_out=json_out)


def unboost_command(
    status_id: Annotated[str, Parameter(show=True, help="Status URL or ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the status as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Undo a boost on a status."""
    _run_action(status_id, profile, "undo_reblog", "Unboosted", json_out=json_out)


def bookmark_command(
    status_id: Annotated[str, Parameter(show=True, help="Status URL or ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the status as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Bookmark a status."""
    _run_action(status_id, profile, "bookmark", "Bookmarked", json_out=json_out)


def unbookmark_command(
    status_id: Annotated[str, Parameter(show=True, help="Status URL or ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the status as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Remove a bookmark from a status."""
    _run_action(status_id, profile, "unbookmark", "Unbookmarked", json_out=json_out)


def pin_command(
    status_id: Annotated[str, Parameter(show=True, help="Status URL or ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the status as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Pin a status to your profile."""
    _run_action(status_id, profile, "pin_status", "Pinned", json_out=json_out)


def unpin_command(
    status_id: Annotated[str, Parameter(show=True, help="Status URL or ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the status as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Unpin a status from your profile."""
    _run_action(status_id, profile, "unpin_status", "Unpinned", json_out=json_out)


def delete_command(
    status_id: Annotated[str, Parameter(show=True, help="Status URL or ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the deleted status as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Delete one of your statuses."""
    resolved_id = _resolve_status_id(status_id)
    instance_url, access_token = resolve_auth(profile)

    try:
        run_async(_do_delete(instance_url, access_token, resolved_id, json_out=json_out))
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except RatelimitError as exc:
        die(_ratelimit_message(exc))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


async def _do_delete(
    instance_url: str,
    access_token: str,
    status_id: str,
    *,
    json_out: bool = False,
) -> None:
    """Delete the given status and print confirmation.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        status_id: Resolved numeric status ID.
        json_out: When True, dump the deleted status as JSON.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        status = await ap.delete_status(status_id)

    if json_out:
        console.print_json(json_mod.dumps(status.model_dump(exclude_none=True)))
        return
    console.print(f"Deleted: {status_id}")


def bookmarks_command(
    limit: Annotated[int, Parameter(name=["--limit", "-n"], help="Maximum number of statuses to return.")] = 20,
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump statuses as a JSON array.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """List your bookmarked statuses."""
    instance_url, access_token = resolve_auth(profile)

    try:
        run_async(_do_list(instance_url, access_token, "get_bookmarks", limit, json_out=json_out))
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except RatelimitError as exc:
        die(_ratelimit_message(exc))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


def favourites_command(
    limit: Annotated[int, Parameter(name=["--limit", "-n"], help="Maximum number of statuses to return.")] = 20,
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump statuses as a JSON array.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """List your favourited statuses."""
    instance_url, access_token = resolve_auth(profile)

    try:
        run_async(_do_list(instance_url, access_token, "get_favourites", limit, json_out=json_out))
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except RatelimitError as exc:
        die(_ratelimit_message(exc))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


async def _do_list(
    instance_url: str,
    access_token: str,
    method_name: str,
    limit: int,
    *,
    json_out: bool = False,
) -> None:
    """Fetch and render a list of statuses from the named APClient method.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        method_name: APClient async method to call (e.g. 'get_bookmarks').
        limit: Maximum number of statuses to fetch.
        json_out: When True, dump statuses as a JSON array.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        method = getattr(ap, method_name)
        statuses = await method(limit=limit)

    if json_out:
        console.print_json(json_mod.dumps([s.model_dump(exclude_none=True) for s in statuses]))
        return
    if not statuses:
        console.print("No statuses found.")
        return
    _render_status_table(statuses, console)
