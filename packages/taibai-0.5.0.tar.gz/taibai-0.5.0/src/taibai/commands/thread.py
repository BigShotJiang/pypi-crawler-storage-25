"""The `thread` command: post a multi-part thread from a formatted text file."""

from dataclasses import dataclass
from pathlib import Path
from typing import Annotated

import httpx
from cyclopts import Parameter
from longwei import ActivityPubError
from longwei import APClient
from longwei import NetworkError
from longwei import RatelimitError
from longwei import UnauthorizedError
from rich.console import Console

from taibai._utils import _ratelimit_message
from taibai._utils import _resolve_visibility
from taibai._utils import die
from taibai._utils import resolve_auth
from taibai._utils import run_async

console = Console()

_ALLOWED_KEYS = frozenset({"visibility", "cw"})


@dataclass
class ThreadPost:
    """A single post extracted from a thread file."""

    text: str
    visibility: str | None
    cw: str | None


@dataclass
class ThreadFile:
    """Parsed representation of a thread file."""

    visibility: str
    cw: str | None
    posts: list[ThreadPost]


def _parse_kv_block(raw: str) -> dict[str, str]:
    """Parse key: value lines from a raw text block.

    Used for both frontmatter and validation of per-post metadata blocks.
    Skips blank lines. Dies on unknown keys or lines missing a colon.

    Args:
        raw: Text containing zero or more ``key: value`` lines.

    Returns:
        Dict mapping each key to its stripped value.

    """
    result: dict[str, str] = {}
    for raw_line in raw.splitlines():
        stripped = raw_line.strip()
        if not stripped:
            continue
        if ":" not in stripped:
            die(f"Malformed line {stripped!r}. Expected 'key: value'.")
        key, _, val = stripped.partition(":")
        key = key.strip()
        if key not in _ALLOWED_KEYS:
            die(f"Unknown key {key!r}. Allowed: {', '.join(sorted(_ALLOWED_KEYS))}.")
        result[key] = val.strip()
    return result


def _parse_post_segment(segment: str) -> tuple[dict[str, str], str]:
    """Strip optional leading key: value metadata from a post segment.

    Metadata parsing stops at the first blank line or any line that is not a
    recognised ``key: value`` pair. Unknown-key lines are treated as text, not
    errors, so that prose containing colons is handled gracefully.

    Args:
        segment: Raw post text, possibly starting with metadata lines.

    Returns:
        A ``(metadata_dict, remaining_text)`` tuple.  ``remaining_text`` is
        stripped of leading/trailing whitespace.

    """
    lines = segment.split("\n")
    meta: dict[str, str] = {}
    cut = 0
    for idx, line in enumerate(lines):
        if not line.strip():
            cut = idx + 1
            break
        if ":" in line:
            key, _, val = line.partition(":")
            if key.strip() in _ALLOWED_KEYS:
                meta[key.strip()] = val.strip()
                cut = idx + 1
                continue
        cut = idx
        break
    return meta, "\n".join(lines[cut:]).strip()


def _split_posts(body: str) -> list[str]:
    """Split a thread body on ``===`` separators and strip each segment.

    Args:
        body: Thread body text (everything after the optional frontmatter block).

    Returns:
        List of non-empty stripped post strings in order.

    """
    raw_segments = body.split("===")
    has_separator = len(raw_segments) > 1
    posts: list[str] = []
    for i, seg in enumerate(raw_segments):
        stripped = seg.strip()
        if not stripped:
            if has_separator:
                die(f"Post {i + 1} is empty after stripping whitespace.")
        else:
            posts.append(stripped)
    if not posts:
        die("Thread file contains no posts.")
    return posts


def parse_thread_file(path: Path) -> ThreadFile:
    """Read and parse a thread file into a ThreadFile dataclass.

    The optional YAML-style frontmatter block is delimited by ``---`` lines.
    Posts are separated by ``===`` lines. Each post may begin with optional
    ``key: value`` metadata lines that override the global frontmatter values.

    Args:
        path: Path to the thread file.

    Returns:
        Parsed :class:`ThreadFile` with resolved posts, visibility, and cw.

    """
    try:
        content = path.read_text(encoding="utf-8")
    except OSError as exc:
        die(f"Cannot read thread file '{path}': {exc}")
        return ThreadFile(visibility="public", cw=None, posts=[])  # unreachable

    fm: dict[str, str] = {}
    body = content
    lines = content.split("\n")
    if lines and lines[0].rstrip() == "---":
        try:
            end_idx = lines.index("---", 1)
        except ValueError:
            die("Unclosed frontmatter block: missing closing '---'.")
            return ThreadFile(visibility="public", cw=None, posts=[])  # unreachable
        fm = _parse_kv_block("\n".join(lines[1:end_idx]))
        body = "\n".join(lines[end_idx + 1 :])

    global_visibility = fm.get("visibility", "public")
    global_cw: str | None = fm.get("cw") or None
    _resolve_visibility(global_visibility)

    posts: list[ThreadPost] = []
    for i, segment in enumerate(_split_posts(body), 1):
        post_meta, text = _parse_post_segment(segment)
        if not text:
            die(f"Post {i} has no text after stripping metadata.")
        if "visibility" in post_meta:
            _resolve_visibility(post_meta["visibility"])
        posts.append(
            ThreadPost(
                text=text,
                visibility=post_meta.get("visibility"),
                cw=post_meta.get("cw"),
            )
        )

    return ThreadFile(visibility=global_visibility, cw=global_cw, posts=posts)


async def _do_thread(instance_url: str, access_token: str, thread: ThreadFile) -> None:
    """Post all statuses in a thread, each replying to the previous.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        thread: Parsed :class:`ThreadFile` containing posts and global metadata.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        reply_id: str | None = None
        total = len(thread.posts)
        for i, post in enumerate(thread.posts, 1):
            vis = _resolve_visibility(post.visibility or thread.visibility)
            effective_cw = post.cw if post.cw is not None else thread.cw
            status = await ap.post_status(
                post.text,
                visibility=vis,
                spoiler_text=effective_cw,
                in_reply_to_id=reply_id,
            )
            if status.id is None:
                die(f"Post {i} returned no ID; thread is incomplete.")
                return  # unreachable
            reply_id = status.id
            url = status.url or status.uri
            console.print(f"[{i}/{total}] Posted: [link={url}]{url}[/link]")


def thread_command(
    file: Annotated[Path, Parameter(help="Path to thread file.")],
    visibility: Annotated[
        str,
        Parameter(name=["--visibility", "-v"], help="Override frontmatter visibility."),
    ] = "",
    cw: Annotated[str | None, Parameter(name=["--cw"], help="Override frontmatter content warning.")] = None,
    dry_run: Annotated[bool, Parameter(name=["--dry-run"], help="Parse and preview posts without sending.")] = False,
    profile: Annotated[
        str,
        Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE"),
    ] = "default",
) -> None:
    """Post a multi-part thread from a formatted text file."""
    thread = parse_thread_file(file)

    if visibility:
        _resolve_visibility(visibility)
        thread.visibility = visibility
    if cw is not None:
        thread.cw = cw

    if dry_run:
        console.print(
            f"Thread preview — {len(thread.posts)} posts, "
            f"default visibility: {thread.visibility}" + (f", cw: {thread.cw}" if thread.cw else "")
        )
        for i, post in enumerate(thread.posts, 1):
            effective_vis = post.visibility or thread.visibility
            console.print(f"  [{i}/{len(thread.posts)}] {effective_vis} | {len(post.text)} chars — {post.text!r}")
        return

    instance_url, access_token = resolve_auth(profile)
    try:
        run_async(_do_thread(instance_url, access_token, thread))
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except RatelimitError as exc:
        die(_ratelimit_message(exc))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")
