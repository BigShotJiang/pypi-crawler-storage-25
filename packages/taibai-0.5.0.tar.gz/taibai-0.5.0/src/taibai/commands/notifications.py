"""The `notifications` command: display unread (or all) notifications."""

import json as json_mod
from typing import Annotated

import httpx
from cyclopts import Parameter
from longwei import ActivityPubError
from longwei import APClient
from longwei import NetworkError
from longwei import Notification
from longwei import UnauthorizedError
from rich.console import Console
from rich.table import Table

from taibai._utils import _strip_html
from taibai._utils import die
from taibai._utils import resolve_auth
from taibai._utils import run_async
from taibai.config import get_profile
from taibai.config import update_last_seen_notification

console = Console()


def notifications_command(
    all_notifications: Annotated[
        bool, Parameter(name=["--all"], negative="", help="Show all notifications, not just new ones.")
    ] = False,
    limit: Annotated[
        int | None, Parameter(name=["--limit", "-n"], help="Maximum number of notifications to fetch.")
    ] = None,
    json_out: Annotated[
        bool, Parameter(name="--json", negative="", help="Dump notifications as JSON (all fields with values).")
    ] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Show notifications. Defaults to unread only; use --all to show everything."""
    instance_url, access_token = resolve_auth(profile)

    since_id: str | None = None
    if not all_notifications:
        stored_profile = get_profile(profile)
        if stored_profile is not None:
            since_id = stored_profile.last_seen_notification_id

    try:
        run_async(
            _do_notifications(
                instance_url,
                access_token,
                profile,
                since_id=since_id,
                limit=limit,
                json_out=json_out,
            )
        )
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


async def _do_notifications(  # noqa: PLR0913
    instance_url: str,
    access_token: str,
    profile_name: str,
    since_id: str | None,
    limit: int | None,
    json_out: bool = False,
) -> None:
    """Fetch and display notifications, updating last-seen state.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        profile_name: Profile name used to persist the last-seen ID.
        since_id: Only return notifications newer than this ID.
        limit: Maximum number of notifications to fetch.
        json_out: When True, dump notifications as JSON instead of rendering a table.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        notifications: list[Notification] = await ap.get_notifications(
            since_id=since_id,
            limit=limit,
        )

    if not notifications:
        if json_out:
            console.print_json("[]")
        else:
            console.print("[dim]No new notifications.[/dim]")
        return

    # Update last-seen to the first (newest) notification ID.
    if notifications[0].id is not None:
        update_last_seen_notification(profile_name, notifications[0].id)

    if json_out:
        console.print_json(json_mod.dumps([n.model_dump(exclude_none=True) for n in notifications]))
        return

    table = Table(show_header=True, header_style="bold magenta", show_lines=False)
    table.add_column("Type", style="cyan", width=14, no_wrap=True)
    table.add_column("From", style="green", width=28, no_wrap=True)
    table.add_column("Preview", overflow="fold")
    table.add_column("Time", style="dim", width=16, no_wrap=True)

    for notif in notifications:
        from_acct = notif.account.acct if notif.account else "unknown"
        preview = ""
        if notif.status is not None and notif.status.content:
            preview = _strip_html(notif.status.content)[:100]
        time_str = (notif.created_at[:16] if notif.created_at else "").replace("T", " ")
        table.add_row(notif.type, f"@{from_acct}", preview, time_str)

    console.print(table)
