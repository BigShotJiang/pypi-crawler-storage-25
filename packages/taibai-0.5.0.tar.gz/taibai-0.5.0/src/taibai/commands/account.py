"""Account social-graph commands: follow, unfollow, mute, unmute, block, unblock, profile."""

import json as json_mod
from typing import Annotated

import httpx
from cyclopts import Parameter
from longwei import ActivityPubError
from longwei import APClient
from longwei import NetworkError
from longwei import RatelimitError
from longwei import UnauthorizedError
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from taibai._render import _render_status_table
from taibai._utils import _ratelimit_message
from taibai._utils import _resolve_account
from taibai._utils import die
from taibai._utils import resolve_auth
from taibai._utils import run_async

console = Console()


def _run_account_action(
    handle_or_id: str,
    profile: str,
    method_name: str,
    verb: str,
    *,
    json_out: bool = False,
) -> None:
    """Load credentials and dispatch to _do_account_action.

    Args:
        handle_or_id: Account handle or numeric ID.
        profile: Profile name to use.
        method_name: Name of the APClient async method to call.
        verb: Past-tense verb for the confirmation message.
        json_out: When True, dump the returned relationship as JSON.

    """
    instance_url, access_token = resolve_auth(profile)

    try:
        run_async(_do_account_action(instance_url, access_token, handle_or_id, method_name, verb, json_out=json_out))
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except RatelimitError as exc:
        die(_ratelimit_message(exc))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


async def _do_account_action(  # noqa: PLR0913
    instance_url: str,
    access_token: str,
    handle_or_id: str,
    method_name: str,
    verb: str,
    *,
    json_out: bool = False,
) -> None:
    """Resolve the account, call the named APClient method, and print confirmation.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        handle_or_id: Account handle or numeric ID.
        method_name: APClient async method to call.
        verb: Past-tense label for the confirmation message.
        json_out: When True, dump the returned relationship as JSON.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        account = await _resolve_account(ap, handle_or_id)
        if account.id is None:
            raise ActivityPubError(0, None, f"Could not resolve account ID for: {handle_or_id}")
        method = getattr(ap, method_name)
        relationship = await method(account.id)

    if json_out:
        console.print_json(json_mod.dumps(relationship.model_dump(exclude_none=True)))
        return
    console.print(f"{verb}: {handle_or_id}")


async def _do_mute(  # noqa: PLR0913
    instance_url: str,
    access_token: str,
    handle_or_id: str,
    *,
    json_out: bool = False,
    duration: int | None = None,
    notifications: bool | None = None,
) -> None:
    """Mute an account with optional duration and notification settings.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        handle_or_id: Account handle or numeric ID.
        json_out: When True, dump the returned relationship as JSON.
        duration: Mute duration in seconds; ``None`` means indefinite.
        notifications: Whether to also mute notifications. Defaults to True server-side.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        account = await _resolve_account(ap, handle_or_id)
        if account.id is None:
            raise ActivityPubError(0, None, f"Could not resolve account ID for: {handle_or_id}")
        relationship = await ap.mute_account(account.id, notifications=notifications, duration=duration)

    if json_out:
        console.print_json(json_mod.dumps(relationship.model_dump(exclude_none=True)))
        return
    console.print(f"Muted: {handle_or_id}")


async def _do_profile(
    instance_url: str,
    access_token: str,
    handle_or_id: str,
    limit: int,
    *,
    json_out: bool = False,
) -> None:
    """Fetch an account and its recent statuses, then display them.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        handle_or_id: Account handle or numeric ID.
        limit: Maximum number of statuses to fetch.
        json_out: When True, dump account and statuses as JSON.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        account = await _resolve_account(ap, handle_or_id)
        if account.id is None:
            raise ActivityPubError(0, None, f"Could not resolve account ID for: {handle_or_id}")
        statuses = await ap.get_account_statuses(account.id, limit=limit)

    if json_out:
        data = {
            "account": account.model_dump(exclude_none=True),
            "statuses": [s.model_dump(exclude_none=True) for s in statuses],
        }
        console.print_json(json_mod.dumps(data))
        return

    display = account.display_name or account.username or account.acct
    text = Text()
    text.append(f"{display}\n", style="bold")
    text.append(f"@{account.acct}\n", style="green")
    text.append(f"{account.url}\n\n", style="dim")
    text.append(
        f"Followers: {account.followers_count}  Following: {account.following_count}  Posts: {account.statuses_count}"
    )
    console.print(Panel(text, title="Profile", border_style="blue"))

    if statuses:
        console.print()
        _render_status_table(statuses, console)
    else:
        console.print("[dim]No recent posts.[/dim]")


def follow_command(
    account: Annotated[str, Parameter(show=True, help="Account handle (user@host) or numeric ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the relationship as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Follow an account."""
    _run_account_action(account, profile, "follow_account", "Following", json_out=json_out)


def unfollow_command(
    account: Annotated[str, Parameter(show=True, help="Account handle (user@host) or numeric ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the relationship as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Unfollow an account."""
    _run_account_action(account, profile, "unfollow_account", "Unfollowed", json_out=json_out)


def block_command(
    account: Annotated[str, Parameter(show=True, help="Account handle (user@host) or numeric ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the relationship as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Block an account."""
    _run_account_action(account, profile, "block_account", "Blocked", json_out=json_out)


def unblock_command(
    account: Annotated[str, Parameter(show=True, help="Account handle (user@host) or numeric ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the relationship as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Unblock an account."""
    _run_account_action(account, profile, "unblock_account", "Unblocked", json_out=json_out)


def mute_command(
    account: Annotated[str, Parameter(show=True, help="Account handle (user@host) or numeric ID.")],
    duration: Annotated[
        int | None, Parameter(name="--duration", help="Mute duration in seconds (omit for indefinite).")
    ] = None,
    notifications: Annotated[
        bool, Parameter(name="--notifications", negative="--no-notifications", help="Also mute notifications.")
    ] = True,
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the relationship as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Mute an account."""
    instance_url, access_token = resolve_auth(profile)

    notifications_arg = None if notifications else False

    try:
        run_async(
            _do_mute(
                instance_url,
                access_token,
                account,
                json_out=json_out,
                duration=duration,
                notifications=notifications_arg,
            )
        )
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except RatelimitError as exc:
        die(_ratelimit_message(exc))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


def unmute_command(
    account: Annotated[str, Parameter(show=True, help="Account handle (user@host) or numeric ID.")],
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the relationship as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Unmute an account."""
    _run_account_action(account, profile, "unmute_account", "Unmuted", json_out=json_out)


def profile_command(
    account: Annotated[str, Parameter(show=True, help="Account handle (user@host) or numeric ID.")],
    limit: Annotated[int, Parameter(name=["--limit", "-n"], help="Maximum number of recent posts to show.")] = 20,
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump account and posts as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """View an account profile and recent posts."""
    instance_url, access_token = resolve_auth(profile)

    try:
        run_async(_do_profile(instance_url, access_token, account, limit, json_out=json_out))
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except RatelimitError as exc:
        die(_ratelimit_message(exc))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")
