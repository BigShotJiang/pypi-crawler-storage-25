"""The `timeline` command: fetch and display Fediverse timelines."""

import json as json_mod
from typing import Annotated
from typing import Literal

import httpx
from cyclopts import Parameter
from longwei import ActivityPubError
from longwei import APClient
from longwei import NetworkError
from longwei import Status
from longwei import UnauthorizedError
from rich.console import Console

from taibai._render import _render_status_table
from taibai._utils import die
from taibai._utils import resolve_auth
from taibai._utils import run_async

console = Console()


def timeline_command(  # noqa: PLR0913
    feed: Annotated[
        Literal["home", "public", "tag", "list"],
        Parameter(show=True, help="Timeline to fetch: home, public, tag, or list."),
    ] = "home",
    limit: Annotated[int, Parameter(name=["--limit", "-n"], help="Maximum number of statuses to fetch.")] = 20,
    tag: Annotated[str | None, Parameter(name="--tag", help="Hashtag to fetch (required for 'tag' feed).")] = None,
    list_id: Annotated[
        str | None, Parameter(name="--list-id", help="List ID to fetch (required for 'list' feed).")
    ] = None,
    local: Annotated[
        bool, Parameter(name="--local", negative="", help="Show only local statuses (public feed).")
    ] = False,
    remote: Annotated[
        bool, Parameter(name="--remote", negative="", help="Show only remote statuses (public feed).")
    ] = False,
    json_out: Annotated[
        bool, Parameter(name="--json", negative="", help="Dump statuses as JSON (all fields with values).")
    ] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Fetch and display a Fediverse timeline.

    FEED selects which timeline to show: home (default), public, tag, or list.
    """
    if feed == "tag" and not tag:
        die("'tag' feed requires --tag.")
        return
    if feed == "list" and not list_id:
        die("'list' feed requires --list-id.")
        return

    instance_url, access_token = resolve_auth(profile)

    try:
        run_async(
            _do_timeline(
                instance_url,
                access_token,
                feed=feed,
                limit=limit,
                tag=tag,
                list_id=list_id,
                local=local,
                remote=remote,
                json_out=json_out,
            )
        )
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


async def _do_timeline(  # noqa: PLR0913
    instance_url: str,
    access_token: str,
    feed: str,
    limit: int,
    tag: str | None,
    list_id: str | None,
    local: bool,
    remote: bool,
    json_out: bool = False,
) -> None:
    """Fetch and display the requested timeline.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        feed: One of "home", "public", "tag", "list".
        limit: Maximum number of statuses to fetch.
        tag: Hashtag for the "tag" feed (without leading #).
        list_id: List ID for the "list" feed.
        local: Restrict public timeline to local statuses.
        remote: Restrict public timeline to remote statuses.
        json_out: When True, dump statuses as JSON instead of rendering a table.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        statuses: list[Status]
        if feed == "home":
            statuses = await ap.get_home_timeline(limit=limit)
        elif feed == "public":
            statuses = await ap.get_public_timeline(local=local, remote=remote, limit=limit)
        elif feed == "tag":
            statuses = await ap.get_hashtag_timeline(hashtag=tag or "", limit=limit)
        else:
            statuses = await ap.get_list_timeline(list_id=list_id or "", limit=limit)

    if json_out:
        console.print_json(json_mod.dumps([s.model_dump(exclude_none=True) for s in statuses]))
        return
    _render_status_table(statuses, console)
