"""The `post` command: publish a status."""

import json as json_mod
import mimetypes
import sys
from collections.abc import Sequence
from pathlib import Path
from typing import Annotated

import httpx
from cyclopts import Parameter
from longwei import ActivityPubError
from longwei import APClient
from longwei import NetworkError
from longwei import RatelimitError
from longwei import UnauthorizedError
from longwei import Visibility
from rich.console import Console

from taibai._utils import _ratelimit_message
from taibai._utils import _resolve_status_id
from taibai._utils import _resolve_visibility
from taibai._utils import die
from taibai._utils import resolve_auth
from taibai._utils import run_async

console = Console()


def _resolve_text(text: str | None, file: Path | None) -> str:
    """Resolve status text from positional arg, --file, or stdin.

    Args:
        text: Positional text argument (None if omitted, '-' for stdin).
        file: Optional path to a text file containing the status body.

    Returns:
        The resolved status text string.

    """
    if file is not None:
        if text is not None:
            die("Cannot combine --file with a positional text argument or stdin ('-').")
        return file.read_text(encoding="utf-8")
    if text == "-":
        return sys.stdin.read()
    if text is not None:
        return text
    die("Provide status text, --file PATH, or pipe via stdin ('-').")
    return ""  # unreachable; die() raises SystemExit


def _validate_post_options(poll_options: Sequence[str], attach: Sequence[str], poll_expires: int) -> None:
    """Validate poll and attachment option combinations.

    Args:
        poll_options: Poll option strings.
        attach: File paths to attach.
        poll_expires: Poll expiry duration in seconds.

    """
    if len(poll_options) == 1:
        die("A poll requires at least 2 options.")
    if len(poll_options) > 4:
        die("Mastodon supports at most 4 poll options.")
    if poll_options and attach:
        die("Cannot combine a poll with media attachments (Mastodon limitation).")
    if poll_options and poll_expires < 300:
        die("Poll expiry must be at least 300 seconds (5 minutes).")


async def _upload_attachments(
    ap: APClient,
    attach: Sequence[str],
    alt_texts: Sequence[str],
) -> list[str]:
    """Upload media attachments and return their IDs.

    Args:
        ap: Authenticated APClient instance.
        attach: Local file paths to upload.
        alt_texts: Alt-text strings, paired positionally with attach.

    Returns:
        List of media attachment IDs ready to pass to post_status().

    """
    media_ids: list[str] = []
    for i, path_str in enumerate(attach):
        alt: str | None = alt_texts[i] if i < len(alt_texts) else None
        mime, _ = mimetypes.guess_type(path_str)
        with Path(path_str).open("rb") as fh:
            attachment = await ap.post_media(fh, mime_type=mime or "application/octet-stream", description=alt)
        if attachment.id is None:
            die(f"Server did not return an ID for attachment '{path_str}'.")
            return media_ids  # unreachable
        media_ids.append(attachment.id)
    return media_ids


def _post_impl(  # noqa: PLR0913
    text: str | None,
    file: Path | None,
    visibility: str,
    cw: str | None,
    attach: list[str],
    alt_text: list[str],
    sensitive: bool,
    poll_option: list[str],
    poll_expires: int,
    poll_multiple: bool,
    poll_hide_totals: bool,
    profile: str,
    json_out: bool = False,
    reply_to: str | None = None,
) -> None:
    """Execute post logic: resolve text, validate options, load credentials, run async call.

    Args:
        text: Raw text argument (may be None or '-').
        file: Optional path to read status text from.
        visibility: Visibility string ('public', 'unlisted', etc.).
        cw: Optional content warning / spoiler text.
        attach: Local file paths to upload as media.
        alt_text: Alt texts positionally paired with attach.
        sensitive: Whether to mark media as sensitive.
        poll_option: Poll option strings.
        poll_expires: Poll duration in seconds.
        poll_multiple: Allow multiple selections.
        poll_hide_totals: Hide vote totals until closed.
        profile: Profile name to use.
        json_out: When True, dump the posted status as JSON instead of printing its URL.
        reply_to: Optional status URL or ID to reply to.

    """
    resolved_text = _resolve_text(text, file)
    _validate_post_options(poll_option, attach, poll_expires)
    vis = _resolve_visibility(visibility)

    instance_url, access_token = resolve_auth(profile)

    resolved_reply_to = _resolve_status_id(reply_to) if reply_to else None

    try:
        run_async(
            _do_post(
                instance_url,
                access_token,
                resolved_text,
                vis,
                cw,
                attach=attach,
                alt_texts=alt_text,
                sensitive=sensitive,
                poll_options=poll_option,
                poll_expires_in=poll_expires,
                poll_multiple=poll_multiple,
                poll_hide_totals=poll_hide_totals,
                json_out=json_out,
                in_reply_to_id=resolved_reply_to,
            )
        )
    except OSError as exc:
        die(f"Could not read attachment: {exc}")
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except RatelimitError as exc:
        die(_ratelimit_message(exc))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


def post_command(  # noqa: PLR0913
    text: Annotated[
        str | None, Parameter(help="Text to post. Use '-' to read from stdin.", allow_leading_hyphen=True)
    ] = None,
    visibility: Annotated[
        str, Parameter(name=["--visibility", "-v"], help="Visibility: public, unlisted, private, or direct.")
    ] = "public",
    cw: Annotated[str | None, Parameter(name=["--cw"], help="Content warning / subject line.")] = None,
    file: Annotated[Path | None, Parameter(name=["--file"], help="Read status text from this file.")] = None,
    attach: Annotated[
        list[str] | None,
        Parameter(name=["--attach"], help="Media file to attach (repeatable; server enforces max)."),
    ] = None,
    alt_text: Annotated[
        list[str] | None,
        Parameter(name=["--alt-text"], help="Alt text for the corresponding --attach (positionally paired)."),
    ] = None,
    sensitive: Annotated[bool, Parameter(name=["--sensitive"], help="Mark attached media as sensitive.")] = False,
    poll_option: Annotated[
        list[str] | None,
        Parameter(name=["--poll-option"], help="Add a poll option (repeatable, min 2, max 4)."),
    ] = None,
    poll_expires: Annotated[
        int, Parameter(name=["--poll-expires"], help="Poll duration in seconds (default: 86400, min: 300).")
    ] = 86400,
    poll_multiple: Annotated[
        bool, Parameter(name=["--poll-multiple"], help="Allow voters to select multiple options.")
    ] = False,
    poll_hide_totals: Annotated[
        bool, Parameter(name=["--poll-hide-totals"], help="Hide vote totals until poll closes.")
    ] = False,
    json_out: Annotated[
        bool, Parameter(name="--json", negative="", help="Dump the posted status as JSON instead of printing its URL.")
    ] = False,
    reply_to: Annotated[str | None, Parameter(name="--reply-to", help="Reply to this status URL or ID.")] = None,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Publish a status to the Fediverse."""
    _post_impl(
        text=text,
        file=file,
        visibility=visibility,
        cw=cw,
        attach=attach or [],
        alt_text=alt_text or [],
        sensitive=sensitive,
        poll_option=poll_option or [],
        poll_expires=poll_expires,
        poll_multiple=poll_multiple,
        poll_hide_totals=poll_hide_totals,
        profile=profile,
        json_out=json_out,
        reply_to=reply_to,
    )


async def _do_post(  # noqa: PLR0913
    instance_url: str,
    access_token: str,
    text: str,
    visibility: Visibility,
    cw: str | None,
    *,
    attach: Sequence[str],
    alt_texts: Sequence[str],
    sensitive: bool,
    poll_options: Sequence[str],
    poll_expires_in: int,
    poll_multiple: bool,
    poll_hide_totals: bool,
    json_out: bool = False,
    in_reply_to_id: str | None = None,
) -> None:
    """Upload any attachments then post the status and print its URL.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        text: Status body text.
        visibility: Visibility level for the post.
        cw: Optional content warning / spoiler text.
        attach: Local file paths to upload as media.
        alt_texts: Alt texts positionally paired with attach.
        sensitive: Whether to mark media as sensitive.
        poll_options: Poll option strings.
        poll_expires_in: Poll duration in seconds.
        poll_multiple: Allow multiple selections.
        poll_hide_totals: Hide vote totals until poll closes.
        json_out: When True, dump the posted status as JSON instead of printing its URL.
        in_reply_to_id: Optional status ID to reply to.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)

        if len(attach) > ap.max_attachments:
            die(f"Cannot attach more than {ap.max_attachments} files on this instance.")

        media_ids = await _upload_attachments(ap, attach, alt_texts) if attach else []

        status = await ap.post_status(
            text,
            visibility=visibility,
            spoiler_text=cw,
            media_ids=media_ids or None,
            sensitive=sensitive if media_ids else False,
            poll_options=list(poll_options) if poll_options else None,
            poll_expires_in=poll_expires_in if poll_options else None,
            poll_multiple=poll_multiple if poll_options else False,
            poll_hide_totals=poll_hide_totals if poll_options else False,
            in_reply_to_id=in_reply_to_id,
        )

    if json_out:
        console.print_json(json_mod.dumps(status.model_dump(exclude_none=True)))
        return
    url = status.url or status.uri
    console.print(f"Posted: [link={url}]{url}[/link]")
