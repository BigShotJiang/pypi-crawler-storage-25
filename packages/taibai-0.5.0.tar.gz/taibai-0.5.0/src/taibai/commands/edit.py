"""The `edit` command: update the text of an existing status."""

import json as json_mod
from pathlib import Path
from typing import Annotated

import httpx
from cyclopts import Parameter
from longwei import ActivityPubError
from longwei import APClient
from longwei import NetworkError
from longwei import RatelimitError
from longwei import UnauthorizedError
from rich.console import Console

from taibai._utils import _ratelimit_message
from taibai._utils import _resolve_status_id
from taibai._utils import die
from taibai._utils import resolve_auth
from taibai._utils import run_async
from taibai.commands.post import _resolve_text

console = Console()


def edit_command(  # noqa: PLR0913
    status_id: Annotated[str, Parameter(show=True, help="Status URL or ID to edit.")],
    text: Annotated[
        str | None, Parameter(help="Replacement text. Use '-' to read from stdin.", allow_leading_hyphen=True)
    ] = None,
    file: Annotated[Path | None, Parameter(name="--file", help="Read replacement text from this file.")] = None,
    cw: Annotated[str | None, Parameter(name="--cw", help="Content warning / subject line.")] = None,
    sensitive: Annotated[bool, Parameter(name="--sensitive", help="Mark attached media as sensitive.")] = False,
    json_out: Annotated[bool, Parameter(name="--json", negative="", help="Dump the edited status as JSON.")] = False,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Edit the text of one of your existing statuses."""
    resolved_id = _resolve_status_id(status_id)
    resolved_text = _resolve_text(text, file)

    instance_url, access_token = resolve_auth(profile)

    try:
        run_async(
            _do_edit(
                instance_url,
                access_token,
                resolved_id,
                resolved_text,
                cw=cw,
                sensitive=sensitive,
                json_out=json_out,
            )
        )
    except UnauthorizedError:
        die(f"Access token rejected. Re-run `taibai init --profile {profile}`.")
    except RatelimitError as exc:
        die(_ratelimit_message(exc))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance_url}. {exc.message or ''}")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance_url}.")


async def _do_edit(  # noqa: PLR0913
    instance_url: str,
    access_token: str,
    status_id: str,
    text: str,
    *,
    cw: str | None = None,
    sensitive: bool = False,
    json_out: bool = False,
) -> None:
    """Edit the status and print the updated URL or JSON.

    Args:
        instance_url: The Fediverse instance base URL.
        access_token: The OAuth access token.
        status_id: Resolved numeric status ID.
        text: Replacement status text.
        cw: Optional content warning / spoiler text.
        sensitive: Whether to mark media as sensitive.
        json_out: When True, dump the edited status as JSON.

    """
    async with httpx.AsyncClient() as http_client:
        ap = await APClient.create(instance_url, http_client, access_token)
        status = await ap.edit_status(status_id, text, spoiler_text=cw, sensitive=sensitive)

    if json_out:
        console.print_json(json_mod.dumps(status.model_dump(exclude_none=True)))
        return
    url = status.url or status.uri
    console.print(f"Edited: [link={url}]{url}[/link]")
