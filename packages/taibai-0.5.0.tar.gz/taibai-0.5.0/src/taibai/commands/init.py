"""The `init` command: register an app and complete the OAuth flow."""

import sys
from importlib.metadata import version
from typing import Annotated

import httpx
from cyclopts import Parameter
from longwei import ActivityPubError
from longwei import APClient
from longwei import NetworkError
from longwei import UnauthorizedError
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.prompt import Prompt

from taibai._utils import die
from taibai._utils import run_async
from taibai.config import Profile
from taibai.config import get_profile
from taibai.config import save_profile
from taibai.credentials import save_token

console = Console()

_CLIENT_WEBSITE = "https://codeberg.org/MarvinsMastodonTools/taibai"
_USER_AGENT = f"taibai_v{version('taibai')}_Python_{sys.version.split()[0]}"


def init_command(
    instance: Annotated[str | None, Parameter(name=["--instance", "-i"], help="Fediverse instance URL.")] = None,
    profile: Annotated[
        str, Parameter(name=["--profile", "-p"], help="Profile name.", env_var="TAIBAI_PROFILE")
    ] = "default",
) -> None:
    """Register an app with a Fediverse instance and store credentials locally."""
    if instance is None:
        instance = Prompt.ask("Instance URL (e.g. https://mastodon.social)")

    instance = instance.rstrip("/")
    if "://" not in instance:
        instance = f"https://{instance}"

    existing = get_profile(profile)
    if existing is not None:
        confirmed = Confirm.ask(
            f"Profile '{profile}' already exists ({existing.username} on {existing.instance_url}). Overwrite?"
        )
        if not confirmed:
            raise SystemExit(0)

    try:
        run_async(_do_init(instance, profile))
    except NetworkError as exc:
        die(f"Network error: could not reach {instance}. {exc.message or ''}")
    except UnauthorizedError:
        die("Authorization code was rejected. Please try `taibai init` again.")
    except ActivityPubError as exc:
        die(f"Fediverse error: {exc.message or str(exc)}")
    except httpx.ConnectError:
        die(f"Could not connect to {instance}. Check the URL and your network connection.")


async def _do_init(instance_url: str, profile_name: str) -> None:
    """Perform the OAuth flow and save credentials."""
    async with httpx.AsyncClient() as http_client:
        client_id, client_secret = await APClient.create_app(
            instance_url,
            http_client,
            user_agent=_USER_AGENT,
            client_website=_CLIENT_WEBSITE,
        )

        auth_url = await APClient.generate_authorization_url(instance_url, client_id)

        console.print(f"\nOpen this URL in your browser:\n\n  [link={auth_url}]{auth_url}[/link]\n")

        code = Prompt.ask("Paste the authorization code")
        code = code.strip()

        access_token = await APClient.validate_authorization_code(
            http_client,
            instance_url,
            code,
            client_id,
            client_secret,
        )

        ap = await APClient.create(instance_url, http_client, access_token)
        account = await ap.verify_credentials()

        save_profile(
            Profile(
                name=profile_name,
                instance_url=instance_url,
                client_id=client_id,
                client_secret=client_secret,
                username=account.acct or "",
            )
        )
        save_token(profile_name, access_token)

    console.print(
        Panel(
            f"[bold]@{account.acct}[/bold]\n[dim]{instance_url}[/dim]",
            title="[green]Connected[/green]",
            border_style="green",
        )
    )
    console.print(f"Profile [bold]{profile_name!r}[/bold] saved.")
