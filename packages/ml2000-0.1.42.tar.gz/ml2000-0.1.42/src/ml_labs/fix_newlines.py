with open('generator.py', 'r') as f:
    content = f.read()

# Replace newlines in f-strings and normal prints
content = content.replace('print(f\"\\n---', 'print(f\"---')
content = content.replace('print(\"\\n---', 'print(\"---')
content = content.replace(':.4f}\\n\")', ':.4f}\")')
content = content.replace('print(\"\\nRecommendations', 'print(\"Recommendations')
content = content.replace('---\\n\",', '---\",')

with open('generator.py', 'w') as f:
    f.write(content)
