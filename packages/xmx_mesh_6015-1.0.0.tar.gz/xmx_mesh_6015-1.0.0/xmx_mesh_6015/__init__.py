"""River Frame for Dot"""
__version__ = "1.0.0"
