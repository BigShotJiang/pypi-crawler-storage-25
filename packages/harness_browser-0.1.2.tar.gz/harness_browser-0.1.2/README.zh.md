# harness-browser

面向 AI Agent 的浏览器自动化工具，基于 Chrome DevTools Protocol（CDP）。

[![PyPI](https://img.shields.io/pypi/v/harness-browser)](https://pypi.org/project/harness-browser/)
[![CI](https://github.com/harness/harness-browser/actions/workflows/ci.yml/badge.svg)](https://github.com/harness/harness-browser/actions)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

[English](README.md) · **中文**

> 为 AI Agent 打造的浏览器运行时。直连 CDP，无需 Playwright；DOM 输出稳定可控，
> 登录态随 profile 长期保留，API 全程类型化，天然契合 LLM 的工具调用范式。

## 为什么选择 harness-browser

| 关注点 | 解决方式 |
|--------|----------|
| **Token 成本** | 四级 DOM 输出，`interactive` 模式（~200–500 token）只返回带稳定 ref 的可交互元素，绝非原始 HTML |
| **稳定的元素定位** | Ref（如 `btn_2`、`inp_search`）跨布局重排依然稳定，导航后自动失效，杜绝 Agent 引用过期节点 |
| **登录态复用** | 每个 profile 对应一个独立的 Chrome user-data-dir（`~/.harness-browser/profiles/<name>/`）——只需登录一次，后续运行自动复用 cookie 与本地存储 |
| **告别 Playwright 依赖** | 纯 CDP over WebSocket（`websockets>=12.0`）；不打包浏览器二进制、不依赖修改版 Chromium、不需要 driver 层 |
| **可观测性** | 每次操作都会产出 `ActionMetrics`（`duration_ms`、`dom_nodes_scanned`、`estimated_tokens`、`screenshot_size_kb`），并支持 `before_action` / `after_action` / `action_error` / `page_navigated` 钩子 |
| **配置灵活** | 7 个 `BROWSER_USE_*` 环境变量覆盖路径、端口、超时；通过 `BROWSER_USE_CDP_WS_URL` 支持远程/Docker 内的 Chrome——开发、CI、生产无需改代码 |
| **Agent 集成** | 提供无状态的 `browser_tool(action=..., profile=...)`、MCP 服务（`python -m harness_browser.mcp_server`），以及 `skills/` 下可直接复制的 Claude Code skill |

## 核心特性

- **纯 CDP** —— 直连 WebSocket，零 Playwright 依赖
- **基于 profile 的登录持久化** —— 每个 profile 对应一个 user-data-dir，cookie/会话跨运行复用
- **四级 DOM 输出** —— `minimal`（~50 token）、`interactive`（~200–500 token）、`full`（~1000–3000 token）、`structured`（JSON）
- **Ref 系统** —— 跨操作稳定的元素引用，导航时自动失效
- **钩子系统** —— `before_action`、`after_action`、`action_error`、`page_navigated`
- **每次操作的 metrics** —— `duration_ms`、`estimated_tokens`、`screenshot_size_kb`
- **环境变量配置** —— 路径、端口、超时全部可通过环境变量调整，无需改代码
- **远程/Docker Chrome** —— 通过 `BROWSER_USE_CDP_WS_URL` 跳过启动器直接连接
- **MCP Server** —— 将操作以 MCP 工具形式暴露给 Claude Code 等 MCP 客户端
- **可直接复制的 Claude Code skill** —— 复制 `skills/harness-browser/` 到任何 agent 项目即可
- **严格类型** —— mypy strict、ruff 干净，34 个单元测试覆盖 DOM、ref、hook、settings、CDP framing

## 环境要求

- Python 3.11+
- Chrome 或 Chromium

```bash
# Ubuntu/Debian
sudo apt install chromium-browser

# macOS
brew install --cask google-chrome
```

## 安装

```bash
pip install harness-browser
```

## 快速开始

### Python API

```python
import asyncio
from harness_browser import BrowserSession

async def main():
    async with await BrowserSession.create(profile="default") as sess:
        await sess.navigate("https://example.com")
        result = await sess.dom_tree(level="interactive")
        print(result.content)
        # → [ref=inp_1] input[text] placeholder="Search"
        # → [ref=btn_2] button "Go"
        await sess.click(ref="btn_2")

asyncio.run(main())
```

### AI 框架用法（无状态）

```python
from harness_browser import browser_tool

# 所有调用按 profile 名称路由到同一个会话
result = await browser_tool(action="navigate", url="https://github.com", profile="work")
result = await browser_tool(action="dom_tree", level="interactive", profile="work")
result = await browser_tool(action="click", ref="btn_search", profile="work")
result = await browser_tool(action="type", text="harness", profile="work")
```

## DOM 等级

| 等级 | Token 量 | 适用场景 |
|------|----------|----------|
| `minimal` | ~50 | 确认页面已加载、获取标题/URL |
| `interactive` | ~200–500 | 寻找可点击/可输入元素（默认） |
| `full` | ~1000–3000 | 阅读页面正文 |
| `structured` | 视情况 | 程序化处理的 JSON |

## 登录态复用

Profile 在 `~/.harness-browser/profiles/<name>/` 持久化 Chrome 会话：

```python
# 首次：打开登录页，手动登录
await browser_tool(action="navigate", url="https://github.com/login", profile="github")

# 之后：登录态自动复用
await browser_tool(action="navigate", url="https://github.com/settings", profile="github")
```

## 钩子系统

```python
async with await BrowserSession.create(profile="work") as sess:
    @sess.on("before_action")
    async def log_action(event):
        print(f"[{event['action']}] starting")

    @sess.on("after_action")
    async def log_metrics(metrics):
        print(f"  done in {metrics.duration_ms}ms (~{metrics.estimated_tokens} tokens)")

    await sess.navigate("https://example.com")
```

## MCP Server

```bash
python -m harness_browser.mcp_server
```

添加到 Claude Code `settings.json`：

```json
{
  "mcpServers": {
    "harness-browser": {
      "command": "python",
      "args": ["-m", "harness_browser.mcp_server"],
      "env": {
        "BROWSER_USE_MODE": "auto",
        "BROWSER_USE_PROFILES_DIR": "/data/browser-profiles"
      }
    }
  }
}
```

所有 `BROWSER_USE_*` 环境变量都可以通过 MCP 的 `env` 块注入——这是配置 MCP 浏览器
模式、profile 路径、远端 CDP 地址的推荐方式。

可用的 MCP 工具：`browser_navigate`、`browser_dom_tree`、`browser_screenshot`、
`browser_click`、`browser_type`、`browser_eval_js`。

## 截图

`screenshot` 直接落盘并返回**文件路径**，而不是 base64 字符串。这样无论图片
多大，token 消耗都是常数，dashboard 也能直接读取文件预览。

```python
# 默认：在 BROWSER_USE_SCREENSHOTS_DIR 下生成带时间戳的文件
result = await sess.screenshot()
print(result.content)
# → /home/user/.harness-browser/screenshots/harness-1779462725763.png

# 整页滚动截图（用 Page.getLayoutMetrics + captureBeyondViewport 单次完成）
await sess.screenshot(full_page=True)

# 通过 dom_tree 拿到 ref 后，对单个元素截图
await sess.screenshot(element_ref="btn_2")

# 显式指定路径——每次调用覆盖同一文件
await sess.screenshot(path="/tmp/latest.png")
```

`result.metadata` 还会带回 `url` / `title` / `width` / `height` / `size_kb` /
`full_page`，调用方无需再发一次 `Runtime.evaluate` 取页面信息。

## Claude Code Skill

`skills/` 下提供了开箱即用的 skill：

```bash
# 复制到其他 agent 项目（Claude Code 标准位置）
cp -r skills/harness-browser /path/to/other-project/.codebuddy/skills/
# 或中文版本
cp -r skills/harness-browser-zh /path/to/other-project/.codebuddy/skills/
```

Skill 会教 Agent 标准的 navigate → `dom_tree` → click/type 流程，
以及 ref 纪律（导航后必须重新获取 DOM）。

## Action 速查

| Action | 必填 | 可选 |
|--------|------|------|
| `navigate` | `url` | |
| `dom_tree` | | `level`（默认 `interactive`） |
| `screenshot` | | `element_ref`、`full_page`、`path` |
| `click` | `ref`、`selector`、`x`+`y` 三选一 | |
| `type` | `text` | `ref` |
| `scroll` | | `direction`、`amount` |
| `hover` | `ref` | |
| `eval_js` | `expression` | |
| `go_back` | | |
| `go_forward` | | |
| `reload` | | |
| `list_tabs` | | |
| `new_tab` | | `url` |
| `switch_tab` | `tab_id` | |
| `close_tab` | | `tab_id` |
| `close_session` | | |

## 配置

所有配置均可通过环境变量调整，无需改代码。

| 环境变量 | 默认值 | 说明 |
|----------|--------|------|
| `BROWSER_USE_PROFILES_DIR` | `~/.harness-browser/profiles` | Chrome user-data-dir 的根目录 |
| `BROWSER_USE_SCREENSHOTS_DIR` | `~/.harness-browser/screenshots` | `screenshot` 动作写入 PNG 的目录 |
| `BROWSER_USE_CDP_HOST` | `localhost` | 提供 CDP HTTP/WebSocket 服务的主机名或 IP |
| `BROWSER_USE_CDP_PORT_START` | `9222` | 第一个 profile 使用的 CDP 调试端口 |
| `BROWSER_USE_MODE` | `auto` | 启动模式：`auto` / `headed` / `headless`。`auto` 会在检测到 `DISPLAY`/`WAYLAND_DISPLAY`（或 macOS/Windows）时走有头，否则走无头 |
| `BROWSER_USE_CHROME_BIN` | 自动探测 | Chrome/Chromium 可执行文件绝对路径 |
| `BROWSER_USE_CDP_TIMEOUT` | `30.0` | 等待 CDP 命令返回的秒数 |
| `BROWSER_USE_LAUNCH_RETRIES` | `20` | Chrome 启动后轮询次数 |
| `BROWSER_USE_LAUNCH_DELAY` | `0.25` | 每次轮询间隔（秒） |
| `BROWSER_USE_CDP_WS_URL` | — | **直连模式**：跳过启动器，直接连到该 WebSocket URL |

### 常见场景

**自定义 profile 存储路径：**

```bash
export BROWSER_USE_PROFILES_DIR=/data/browser-profiles
```

**强制有头或无头模式**（默认 `auto`，按 `DISPLAY` 自动判定）：

```bash
export BROWSER_USE_MODE=headless   # 始终无头（CI、容器）
export BROWSER_USE_MODE=headed     # 始终有头（即便没有 DISPLAY 也强制开窗）
# 未设置 / "auto" → 检测到桌面环境时走有头，否则走无头
```

**非标准 Chrome 路径：**

```bash
export BROWSER_USE_CHROME_BIN=/opt/google/chrome/chrome
```

**连接远程或 Docker 内的 Chrome**（完全跳过启动器）：

```bash
# Chrome 用 --remote-debugging-port=9222 --remote-debugging-address=0.0.0.0 启动
export BROWSER_USE_CDP_WS_URL="ws://remote-host:9222/devtools/browser/xxxxxxxx"
```

**指向另一台主机或容器上的 Chrome**（保留 attach/启动逻辑，仅切换主机）：

```bash
# 远端 Chrome 已用 --remote-debugging-port=9222 --remote-debugging-address=0.0.0.0 启动
export BROWSER_USE_CDP_HOST=10.0.0.42
# harness 会请求 http://10.0.0.42:9222/json/version 并取其 WebSocket URL
```

**在代码中覆盖配置**（适合测试或多实例场景）：

```python
from harness_browser import BrowserSession, HarnessSettings

cfg = HarnessSettings(
    cdp_port_start=9300,
    cdp_timeout=60.0,
    profiles_dir="/data/profiles",
)
sess = await BrowserSession.create(profile="work", settings=cfg)
```

## 开发

```bash
# 克隆
git clone https://git.woa.com/orcakit/browser-use.git
cd browser-use

# 安装开发依赖
uv sync --extra dev

# 安装 pre-commit 钩子
pre-commit install

# 运行测试
make test

# Lint + 类型检查
make lint

# 格式化
make format

# 构建 wheel
make build
```

## 贡献

参见 [CONTRIBUTING.md](CONTRIBUTING.md)。

## 许可

MIT
