# 更新日志

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [未发布]

## [0.1.2] - 2026-05-24

### 修复

- `switch_tab` 切换标签页后，CDP WebSocket 现在会重连到新 target。
  之前 `switch_tab` 仅调用了 `Target.activateTarget`（前台化窗口），
  但会话内的 WebSocket 仍连在旧 tab 上，导致后续 `navigate` /
  `click` / `dom_tree` / `screenshot` 全部作用在被切走的那个 tab
  上，调用方看到的现象是"切完没反应"。新增 `get_target_ws_url`
  与 `_InternalCDPSession.reconnect_to_target`，切换时会关闭旧
  WS、按 target id 重新连、重新 enable Page/DOM/Runtime 并重放
  viewport override，并清空 ref 缓存（旧 nodeId 在新 tab 上无效）。

### 新增

- `navigate(url, reuse_tab=True)` 默认开启"已有同 URL 标签页则切过去"
  的行为：导航前先查 `/json` target 列表，命中则走 `switch_tab`
  路径并返回 `Reused existing tab for {url}`，避免在 agent 反复
  调用同一 URL 时堆出一串重复 tab。需要严格新开导航的调用方可显式
  传 `reuse_tab=False`。

## [0.1.1] - 2026-05-24

### 新增

- 新增 `HarnessSettings.viewport_width` / `viewport_height`(默认 1440×900),
  以及环境变量 `BROWSER_USE_VIEWPORT_WIDTH` / `BROWSER_USE_VIEWPORT_HEIGHT`。
  会话 connect 后自动调用 `Emulation.setDeviceMetricsOverride` 把视口尺寸
  锁到配置值。否则全新启动的 headless Chromium 会使用约 800×600 的内置
  默认值,导致 `screenshot` 出来的 PNG 极小、agent 几乎读不出页面内容。
- `screenshot` action 在默认(viewport)模式下,会通过
  `Page.getLayoutMetrics().cssVisualViewport` 把当前视口宽高回填到
  `metadata.width` / `metadata.height`,方便上层 UI 显示分辨率徽章。

### 修复

- CDP WebSocket 连接现在使用 32 MiB(可配)的 ``max_size``,而不是
  ``websockets`` 默认的 1 MiB。之前 ``Page.captureScreenshot`` 一旦回传
  超过 1 MiB 的 base64(1440×900 彩色页面常见),WebSocket 会以 code 1009
  ``message too big`` 直接 close,工具调用方拿到 ``sent 1009 (message
  too big) frame ... exceeds limit of 1048576 bytes; no close frame
  received`` 这条不知所云的错误,而页面其实截图成功只是发不回来。
  新增 ``BROWSER_USE_CDP_MAX_MESSAGE_SIZE``(字节,设 0 表示不限,默认
  32 MiB 足以覆盖任何 viewport 截图)。
- `_build_flags` 现在会自动给容器/受限沙箱里的 Chromium 加 `--no-sandbox`。
  之前只在 `os.getuid() == 0` 时才加，导致在 Docker / chroot / restricted
  systemd 单元里以非 root 用户启动时，Chrome zygote 会以
  `Failed to move to new namespace: Operation not permitted` 直接 fatal，
  CDP 端口永远起不来，调用方拿到 `Chrome did not start on localhost:9222
  after 20 attempts`。

  现在通过 `fork()` + `unshare(CLONE_NEWUSER)` 直接探测当前进程能否创建
  unprivileged user namespace；若不能，自动追加 `--no-sandbox`。新增环境
  变量 `BROWSER_USE_NO_SANDBOX`：设为 `1`/`true`/`yes` 强制开启，设为
  `0`/`false` 强制关闭自动检测（用于已正确配置 caps 的强化生产主机）。

### 变更

- `screenshot` 文档新增提示：`full_page=True` 在长页面上会触发整页渲染 +
  大尺寸 PNG 编码，延迟与体积都显著高于默认 viewport 模式，仅在确实需要
  时使用。

## [0.1.0] - 2026-05-22

首个开发版本。

### Python API

- `BrowserSession` —— 基于 profile 的异步 Python 浏览器操作 API。`create()`
  接受 `profile`、`mode`（`auto`/`headed`/`headless`）、`settings` 等参数。
- `browser_tool()` —— 无状态 AI 框架桥接函数，按 profile 名称路由会话。
- `HarnessSettings` —— 集中式配置：所有路径、端口、超时均可通过环境变量或
  构造参数覆盖。模块级 `settings` 单例在 import 时读取环境变量。
- `BrowserMode = Literal["auto", "headed", "headless"]`：`auto` 在
  macOS/Windows 或 `$DISPLAY`/`$WAYLAND_DISPLAY` 存在时走有头，否则无头。
- `ToolResult.metadata`：可选的结构化"侧通道"，目前 `screenshot` 借助它带回
  url/title/full_page/width/height/size_kb，调用方无需再 `Runtime.evaluate`。
- `ActionMetrics`：`duration_ms` / `dom_nodes_scanned` / `estimated_tokens` /
  `screenshot_size_kb`，每个 action 都会产出。
- `HooksMixin`：4 个事件 `before_action` / `after_action` / `action_error` /
  `page_navigated`，可注册同步或异步回调。

### Action 集

- 导航：`navigate`、`go_back`、`go_forward`、`reload`
- 检视：`dom_tree`（4 级：`minimal`/`interactive`/`full`/`structured`）、
  `screenshot`（落盘并返回路径，**不返回 base64**；支持 `full_page=True`、
  `element_ref` 元素裁剪、`path` 自定义文件位置）、`eval_js`
- 交互：`click`（`ref`/`selector`/`x`+`y`）、`type`、`scroll`、`hover`
- 标签页：`new_tab`、`switch_tab`、`close_tab`、`list_tabs`（全部返回
  `ToolResult` 以便 hooks 与 metrics 一致）
- 生命周期：`close_session`

### CDP 客户端 / 启动器

- `CDPClient` —— 直连 WebSocket（`websockets>=12.0`），无 Playwright/driver。
- `ProfileManager` —— 每个 profile 一个独立 Chrome `--user-data-dir`，登录态
  跨运行复用，端口由 `cdp_port_start + index` 分配。
- `launch_or_attach()` —— 已有 Chrome 在监听就直接 attach，否则启动新进程。
- `find_chrome()` 自动发现规则（按优先级）：
  1. `BROWSER_USE_CHROME_BIN` 环境变量
  2. 系统标准安装路径（macOS / Linux 各一组）
  3. `PATH` 中的 `google-chrome` / `chromium` / `chromium-browser`
  4. **Playwright 缓存目录下的 Chromium**（`$PLAYWRIGHT_BROWSERS_PATH` 或
     `~/.cache/ms-playwright/chromium-*`），多版本时挑 revision 最大的

### 配置（环境变量，统一前缀 `BROWSER_USE_`）

| 变量 | 默认 | 说明 |
|------|------|------|
| `BROWSER_USE_PROFILES_DIR` | `~/.harness-browser/profiles` | Chrome user-data-dir 根目录 |
| `BROWSER_USE_SCREENSHOTS_DIR` | `~/.harness-browser/screenshots` | 截图落盘目录 |
| `BROWSER_USE_MODE` | `auto` | `auto` / `headed` / `headless` |
| `BROWSER_USE_CHROME_BIN` | 自动探测 | Chrome 可执行文件绝对路径 |
| `BROWSER_USE_CDP_HOST` | `localhost` | CDP HTTP/WebSocket 主机或 IP |
| `BROWSER_USE_CDP_PORT_START` | `9222` | profile 起始端口 |
| `BROWSER_USE_CDP_TIMEOUT` | `30.0` | CDP 命令超时（秒） |
| `BROWSER_USE_CDP_WS_URL` | — | 直连模式：跳过启动器，直接连 WS URL |
| `BROWSER_USE_LAUNCH_RETRIES` | `20` | 启动后轮询次数 |
| `BROWSER_USE_LAUNCH_DELAY` | `0.25` | 每次轮询间隔（秒） |

`BROWSER_USE_CDP_HOST` 为非 loopback 时，启动 Chrome 自动追加
`--remote-debugging-address`；如果远端 Chrome 未监听该端口，会建议改用
`BROWSER_USE_CDP_WS_URL` 直连而不是尝试在远端"启动"。

### 集成

- MCP Server（`python -m harness_browser.mcp_server`），暴露常用 action 为
  MCP 工具；推荐通过 `mcpServers.<name>.env` 注入 `BROWSER_USE_*` 变量。
- Claude Code skill（`skills/harness-browser/SKILL.md`，含中文版
  `harness-browser-zh`），可整目录复制到任何 agent 项目。
- GitHub Actions：CI（lint + 测试）、release（PyPI trusted publisher）、
  CodeQL 安全扫描。
- Dependabot：pip 和 GitHub Actions 依赖自动更新。
- pre-commit hooks：ruff + mypy strict。

[0.1.0]: https://git.woa.com/orcakit/harness-browser/releases/tag/v0.1.0
