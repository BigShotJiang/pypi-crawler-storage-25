---
name: harness-browser
description: AI browser automation via CDP. Use when you need to control a browser, navigate pages, click elements, fill forms, extract content, or take screenshots.
allowed-tools: Bash
---

# harness-browser Browser Automation

You are controlling a real Chrome browser via the Chrome DevTools Protocol (CDP).

## Core Rules

1. **Always call `dom_tree` before `click`** — refs expire on navigation.
2. **Default to `level="interactive"`** (~200-500 tokens) to get clickable/typeable elements.
3. **Use `level="minimal"`** (~50 tokens) only to confirm page state or URL.
4. **Use `level="full"`** (~1000-3000 tokens) only when reading page content.
5. **Use `level="structured"`** when you need JSON for programmatic processing.
6. **Never hardcode coordinates** — always use `ref` from `dom_tree`.
7. **Use named profiles** to persist login state across runs: `profile="work"`, `profile="github"`.
8. **On CDP error**: call `dom_tree(level="minimal")` to check state, then retry.

## Standard Workflow

```python
from harness_browser import browser_tool

# 1. Navigate
await browser_tool(action="navigate", url="https://example.com", profile="default")

# 2. Get interactive elements with refs
result = await browser_tool(action="dom_tree", level="interactive", profile="default")
# Output:
# [ref=inp_1] input[text] placeholder="Search"
# [ref=btn_2] button "Search"

# 3. Act using refs — never use coordinates
await browser_tool(action="click", ref="inp_1", profile="default")
await browser_tool(action="type", text="hello", profile="default")
await browser_tool(action="click", ref="btn_2", profile="default")
```

## Actions Reference

| Action | Required | Optional |
|--------|----------|----------|
| `navigate` | `url` | |
| `dom_tree` | | `level` (default: `interactive`) |
| `screenshot` | | `element_ref`, `full_page`, `path` |
| `click` | one of: `ref` / `selector` / `x`+`y` | |
| `type` | `text` | `ref` (click before typing) |
| `scroll` | | `direction` (up/down/left/right), `amount` |
| `hover` | `ref` | |
| `eval_js` | `expression` | |
| `go_back` | | |
| `go_forward` | | |
| `reload` | | |
| `list_tabs` | | |
| `new_tab` | | `url` |
| `switch_tab` | `tab_id` | |
| `close_tab` | | `tab_id` |
| `close_session` | | |

## Screenshots

`screenshot` writes a PNG to disk and returns its **path** (never base64).
`result.metadata` carries `url` / `title` / `width` / `height` / `size_kb` /
`full_page` so you don't need an extra `eval_js` to learn the page state.

- Default file: `BROWSER_USE_SCREENSHOTS_DIR/harness-<timestamp>.png`
  (default `~/.harness-browser/screenshots/`)
- `full_page=True` — capture the entire scrollable page in one call
- `element_ref="btn_2"` — crop to a specific element (mutually exclusive
  with `full_page`; element wins)
- `path="/tmp/latest.png"` — pin the file path; every call overwrites it

## Configuration (environment variables)

All knobs are env-driven; no code changes between dev / CI / prod.

| Variable | Default | Use |
|---|---|---|
| `BROWSER_USE_MODE` | `auto` | `auto` / `headed` / `headless` (auto picks based on `DISPLAY`) |
| `BROWSER_USE_PROFILES_DIR` | `~/.harness-browser/profiles` | Where Chrome user-data-dirs live |
| `BROWSER_USE_SCREENSHOTS_DIR` | `~/.harness-browser/screenshots` | Default screenshot output directory |
| `BROWSER_USE_CHROME_BIN` | auto-detect | Path to Chrome (also auto-detects Playwright's bundled Chromium) |
| `BROWSER_USE_CDP_HOST` | `localhost` | Remote/Docker Chrome host |
| `BROWSER_USE_CDP_WS_URL` | — | Bypass launcher; connect directly to a WS URL |

## Login State Reuse

Profile data is stored in `~/.harness-browser/profiles/<name>/`. Using the same profile name
in future sessions reuses Chrome cookies — no re-authentication needed.

```python
# First run: log in manually
await browser_tool(action="navigate", url="https://github.com/login", profile="github")
# ... complete login in browser ...

# All future runs: login reused automatically
await browser_tool(action="navigate", url="https://github.com", profile="github")
```

## Installation

```bash
pip install harness-browser

# Chrome or Chromium required:
# Ubuntu: sudo apt install chromium-browser
# macOS:  brew install --cask google-chrome
```

## Repository

https://git.woa.com/orcakit/browser-use.git
