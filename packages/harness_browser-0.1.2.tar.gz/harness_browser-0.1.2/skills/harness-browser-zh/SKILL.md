---
name: harness-browser-zh
description: AI 浏览器自动化工具，基于 CDP 协议。需要控制浏览器、页面导航、点击元素、填写表单、提取内容或截图时使用。
allowed-tools: Bash
---

# harness-browser 浏览器自动化

你正在通过 Chrome DevTools Protocol (CDP) 控制一个真实的 Chrome 浏览器。

## 核心规则

1. **点击前必须先调用 `dom_tree`** — 页面导航后 ref 会失效，每次操作前重新获取。
2. **默认使用 `level="interactive"`**（约 200-500 token），获取所有可交互元素。
3. **仅需确认页面状态时用 `level="minimal"`**（约 50 token），只返回 URL 和标题。
4. **需要读取页面内容时才用 `level="full"`**（约 1000-3000 token）。
5. **需要 JSON 结构化数据时用 `level="structured"`**，适合程序化处理。
6. **禁止硬编码坐标** — 始终用 `dom_tree` 返回的 `ref` 操作元素。
7. **用命名 profile 持久化登录态**，如 `profile="work"`、`profile="github"`。
8. **遇到 CDP 错误时**：先调用 `dom_tree(level="minimal")` 确认页面状态，再重试。

## 标准工作流

```python
from harness_browser import browser_tool

# 1. 导航
await browser_tool(action="navigate", url="https://example.com", profile="default")

# 2. 获取可交互元素和 ref
result = await browser_tool(action="dom_tree", level="interactive", profile="default")
# 输出示例：
# [ref=inp_1] input[text] placeholder="搜索"
# [ref=btn_2] button "搜索"

# 3. 用 ref 操作元素 — 禁止猜测坐标
await browser_tool(action="click", ref="inp_1", profile="default")
await browser_tool(action="type", text="hello", profile="default")
await browser_tool(action="click", ref="btn_2", profile="default")
```

## 操作速查表

| 操作 | 必填参数 | 可选参数 |
|------|---------|---------|
| `navigate` | `url` | |
| `dom_tree` | | `level`（默认 `interactive`） |
| `screenshot` | | `element_ref`、`full_page`、`path` |
| `click` | 三选一：`ref` / `selector` / `x`+`y` | |
| `type` | `text` | `ref`（先点击该元素再输入） |
| `scroll` | | `direction`（up/down/left/right）, `amount` |
| `hover` | `ref` | |
| `eval_js` | `expression` | |
| `go_back` | | |
| `go_forward` | | |
| `reload` | | |
| `list_tabs` | | |
| `new_tab` | | `url` |
| `switch_tab` | `tab_id` | |
| `close_tab` | | `tab_id` |
| `close_session` | | |

## 截图

`screenshot` 直接落盘并返回**文件路径**（不是 base64）。`result.metadata` 同时
带回 `url` / `title` / `width` / `height` / `size_kb` / `full_page`，无需再发
一次 `eval_js` 取页面信息。

- 默认文件：`BROWSER_USE_SCREENSHOTS_DIR/harness-<时间戳>.png`
  （默认 `~/.harness-browser/screenshots/`）
- `full_page=True` —— 一次抓取整页可滚动区域
- `element_ref="btn_2"` —— 截某个元素（与 `full_page` 互斥，元素优先）
- `path="/tmp/latest.png"` —— 显式指定路径，重复调用覆盖同一文件

## 配置（环境变量）

所有配置都通过环境变量驱动，开发/CI/生产无需改代码。

| 变量 | 默认 | 用途 |
|---|---|---|
| `BROWSER_USE_MODE` | `auto` | `auto` / `headed` / `headless`（auto 按 `DISPLAY` 自动判定） |
| `BROWSER_USE_PROFILES_DIR` | `~/.harness-browser/profiles` | Chrome user-data-dir 根目录 |
| `BROWSER_USE_SCREENSHOTS_DIR` | `~/.harness-browser/screenshots` | 截图默认输出目录 |
| `BROWSER_USE_CHROME_BIN` | 自动探测 | Chrome 路径（也会自动发现 Playwright 自带的 Chromium） |
| `BROWSER_USE_CDP_HOST` | `localhost` | 远端/Docker 中的 Chrome 主机 |
| `BROWSER_USE_CDP_WS_URL` | — | 跳过启动器，直接连指定 WebSocket URL |

## 登录态复用

Profile 数据存储在 `~/.harness-browser/profiles/<名称>/`，后续使用相同 profile 名称
自动复用 Chrome cookies，无需重新认证。

```python
# 首次运行：手动完成登录
await browser_tool(action="navigate", url="https://github.com/login", profile="github")
# ... 在浏览器中完成登录 ...

# 后续所有调用：自动复用登录态
await browser_tool(action="navigate", url="https://github.com", profile="github")
```

## 安装

```bash
pip install harness-browser

# 需要安装 Chrome 或 Chromium：
# Ubuntu: sudo apt install chromium-browser
# macOS:  brew install --cask google-chrome
```

## 代码仓库

https://git.woa.com/orcakit/browser-use.git
