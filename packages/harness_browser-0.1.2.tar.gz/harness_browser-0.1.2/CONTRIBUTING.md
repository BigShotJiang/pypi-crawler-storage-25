# 贡献指南

欢迎为 harness-browser 贡献代码！

## 环境搭建

```bash
git clone https://git.woa.com/orcakit/browser-use.git
cd browser-use
uv sync --extra dev
pre-commit install
```

## 开发工作流

```bash
make test      # 运行完整测试套件
make lint      # ruff 检查 + mypy 类型检查
make format    # ruff 自动格式化
make build     # 构建 wheel + sdist
```

## 运行测试

单元测试无需 Chrome：

```bash
uv run pytest tests/unit/ -v
```

集成测试需要 Chrome/Chromium，未安装时自动跳过：

```bash
uv run pytest tests/ -v
```

## 提交 Pull Request

1. 从 `main` 创建特性分支
2. 为改动补充测试（优先 TDD）
3. 在 `CHANGELOG.md` 的 `[未发布]` 节下记录变更
4. 确认 `make lint` 和 `make test` 全部通过
5. 按 PR 模板提交

## 代码规范

- 使用 ruff 做 lint 和格式化（`line-length = 88`）
- mypy strict 模式类型检查
- 支持 Python 3.11+ 语法特性
- 所有公开函数需要 docstring
- 异步优先：所有浏览器 I/O 用 `async def`

## 发布流程

打 tag 后由 GitHub Actions 自动发布到 PyPI：

```bash
git tag v0.2.0
git push origin v0.2.0
# CI 通过 trusted publisher 自动构建并发布到 PyPI
```
