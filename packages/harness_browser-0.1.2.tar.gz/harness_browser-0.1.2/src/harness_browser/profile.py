"""Profile management for browser session persistence."""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path

from harness_browser.settings import settings as _settings


@dataclass
class Profile:
    """A named browser profile backed by a Chrome user-data-dir."""

    name: str
    data_dir: Path
    cdp_port: int


class ProfileManager:
    """Creates and tracks browser profiles with stable CDP ports."""

    def __init__(self, base_dir: Path | None = None) -> None:
        if base_dir is None:
            base_dir = _settings.profiles_dir
        self._base_dir = base_dir
        self._profiles: dict[str, Profile] = {}

    def get_or_create(self, name: str) -> Profile:
        """Return an existing profile or create a new one."""
        if name in self._profiles:
            return self._profiles[name]
        data_dir = self._base_dir / name
        data_dir.mkdir(parents=True, exist_ok=True)
        port = _settings.cdp_port_start + len(self._profiles)
        profile = Profile(name=name, data_dir=data_dir, cdp_port=port)
        self._profiles[name] = profile
        return profile

    def list_profiles(self) -> list[Profile]:
        """Return all known profiles."""
        return list(self._profiles.values())

    def delete(self, name: str) -> None:
        """Remove a profile and its data directory."""
        if name not in self._profiles:
            return
        profile = self._profiles.pop(name)
        if profile.data_dir.exists():
            shutil.rmtree(profile.data_dir)
