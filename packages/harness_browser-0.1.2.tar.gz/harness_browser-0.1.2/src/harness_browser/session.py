"""BrowserSession: the primary user-facing API."""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from harness_browser.actions import capture, interact, js_eval
from harness_browser.actions import navigate as nav_actions
from harness_browser.cdp.client import CDPClient
from harness_browser.cdp.launcher import (
    get_page_ws_url,
    get_target_ws_url,
    launch_or_attach,
)
from harness_browser.dom.builder import DOMBuilder, DOMLevel
from harness_browser.dom.refs import RefCache
from harness_browser.hooks import HooksMixin
from harness_browser.mode import BrowserMode, normalize_mode, resolve_headless
from harness_browser.models import ActionMetrics, TabInfo, ToolResult
from harness_browser.profile import Profile, ProfileManager
from harness_browser.settings import HarnessSettings
from harness_browser.settings import settings as _default_settings

logger = logging.getLogger(__name__)

_default_profile_manager = ProfileManager()


class _InternalCDPSession:
    """Low-level CDP session: owns a CDPClient and RefCache for one page."""

    def __init__(self, profile: Profile, cfg: HarnessSettings) -> None:
        self._profile = profile
        self._cfg = cfg
        self._client = CDPClient(timeout=cfg.cdp_timeout)
        self._ref_cache = RefCache()
        self._connected = False

    async def connect(self, headless: bool = False) -> None:
        """Launch/attach Chrome and connect CDP to the active page.

        If ``BROWSER_USE_CDP_WS_URL`` is set (or ``cfg.cdp_ws_url`` is provided),
        skip the launcher and connect directly to that WebSocket address.
        """
        if self._cfg.cdp_ws_url:
            ws_url = self._cfg.cdp_ws_url
            logger.debug("Direct CDP connect to %s", ws_url)
        else:
            await launch_or_attach(self._profile, headless=headless)
            ws_url = await get_page_ws_url(self._profile.cdp_port)
        await self._client.connect(ws_url)
        await self._client.enable_domain("Page")
        await self._client.enable_domain("DOM")
        await self._client.enable_domain("Runtime")
        # Note: the "Input" domain has no .enable method in CDP — input events
        # are dispatched directly via Input.dispatch* commands without enabling.
        await self._apply_viewport()
        self._connected = True

    async def _apply_viewport(self) -> None:
        """Pin the page viewport to the configured CSS-pixel dimensions.

        Without this, a freshly-launched Chromium uses an unpredictable
        default viewport (often ~800×600 in headless mode), so screenshots
        come back tiny. ``Emulation.setDeviceMetricsOverride`` fixes the
        viewport without resizing the window — the same approach finnie's
        screencast uses for its remote-browser stream.
        """
        width = max(int(self._cfg.viewport_width), 1)
        height = max(int(self._cfg.viewport_height), 1)
        try:
            await self._client.send(
                "Emulation.setDeviceMetricsOverride",
                {
                    "width": width,
                    "height": height,
                    "deviceScaleFactor": 1,
                    "mobile": False,
                },
            )
        except Exception:  # pragma: no cover - best effort
            logger.debug("setDeviceMetricsOverride failed", exc_info=True)

    async def close(self) -> None:
        await self._client.close()
        self._connected = False

    async def reconnect_to_target(self, target_id: str) -> None:
        """Close the current CDP WebSocket and reconnect to a different tab.

        After reconnecting, Page/DOM/Runtime domains are re-enabled and the
        viewport override is re-applied so subsequent actions target the new
        tab correctly.
        """
        await self._client.close()
        self._ref_cache.invalidate()
        ws_url = await get_target_ws_url(self._profile.cdp_port, target_id)
        self._client = CDPClient(timeout=self._cfg.cdp_timeout)
        await self._client.connect(ws_url)
        await self._client.enable_domain("Page")
        await self._client.enable_domain("DOM")
        await self._client.enable_domain("Runtime")
        await self._apply_viewport()

    @property
    def client(self) -> CDPClient:
        return self._client

    @property
    def ref_cache(self) -> RefCache:
        return self._ref_cache


class BrowserSession(HooksMixin):
    """
    Profile-aware browser session with a clean Python API.

    Login state is persisted via Chrome's user-data-dir (per profile).
    All methods return :class:`~harness_browser.models.ToolResult`.

    Usage::

        async with await BrowserSession.create(profile="work") as sess:
            await sess.navigate("https://github.com")
            tree = await sess.dom_tree(level="interactive")
            await sess.click(ref="btn_1")
    """

    def __init__(self, internal: _InternalCDPSession, profile_name: str) -> None:
        super().__init__()
        self._internal = internal
        self._profile_name = profile_name
        self._action_count = 0
        self._total_duration_ms = 0
        self._total_tokens = 0
        self._errors = 0

    @classmethod
    async def create(
        cls,
        profile: str = "default",
        headless: bool | None = None,
        mode: BrowserMode | None = None,
        profile_manager: ProfileManager | None = None,
        settings: HarnessSettings | None = None,
    ) -> "BrowserSession":
        """Create a new BrowserSession, launching or re-attaching Chrome.

        Args:
            profile: Profile name — maps to a Chrome user-data-dir for login
                persistence.
            headless: Legacy override. ``True``/``False`` forces a specific
                launch mode regardless of ``mode``/settings. Prefer ``mode``.
            mode: ``"auto"`` | ``"headed"`` | ``"headless"``. Overrides
                ``settings.browser_mode``. ``auto`` picks based on
                ``DISPLAY``/``WAYLAND_DISPLAY``.
            profile_manager: Custom :class:`ProfileManager` (for testing or
                non-default base directories).
            settings: :class:`HarnessSettings` instance. Defaults to the module-level
                singleton which reads from environment variables.
        """
        cfg = settings or _default_settings
        pm = profile_manager or _default_profile_manager
        p = pm.get_or_create(profile)
        # Resolve launch mode: explicit headless wins, else explicit mode,
        # else cfg.browser_mode.
        if headless is not None:
            is_headless = headless
        else:
            effective_mode = normalize_mode(mode) if mode else cfg.browser_mode
            is_headless = resolve_headless(effective_mode)
        internal = _InternalCDPSession(p, cfg)
        await internal.connect(headless=is_headless)
        return cls(internal, profile)

    async def __aenter__(self) -> "BrowserSession":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    async def navigate(self, url: str, reuse_tab: bool = True) -> ToolResult:
        """Navigate to a URL, optionally reusing an existing tab.

        When ``reuse_tab=True`` (default), if the exact URL is already open
        in another tab, the session switches to that tab instead of
        navigating the current page. This avoids duplicate tabs for the same
        resource.
        """
        if reuse_tab:
            reused = await self._try_reuse_tab(url)
            if reused is not None:
                return reused

        await self._fire(
            "before_action", {"action": "navigate", "params": {"url": url}}
        )
        result = await nav_actions.navigate(
            self._internal.client, self._internal.ref_cache, url
        )
        await self._record(result)
        return result

    async def _try_reuse_tab(self, url: str) -> ToolResult | None:
        """If ``url`` is already open in a tab, switch to it and return a result.

        Returns None if no matching tab was found, meaning the caller should
        proceed with a normal navigation.
        """
        import aiohttp

        try:
            host = self._internal._cfg.cdp_host
            port = self._internal._profile.cdp_port
            async with aiohttp.ClientSession() as http:
                async with http.get(
                    f"http://{host}:{port}/json",
                    timeout=aiohttp.ClientTimeout(total=3),
                ) as resp:
                    targets = await resp.json(content_type=None)
        except Exception:
            return None

        # Normalize for comparison: strip trailing slashes.
        normalized = url.rstrip("/")
        for target in targets:
            if target.get("type") != "page":
                continue
            target_url = (target.get("url") or "").rstrip("/")
            if target_url == normalized:
                tab_id = target["id"]
                # Check if our current client is already connected to this tab
                # by comparing target ids. Reconnect would be wasteful.
                current_ws = getattr(self._internal._client, "_ws", None)
                if current_ws is not None:
                    current_url_str = getattr(current_ws, "uri", "") or ""
                    if tab_id in current_url_str:
                        return None  # Already on this tab, just re-navigate.
                try:
                    result = await self.switch_tab(tab_id)
                    if result.success:
                        return ToolResult(
                            success=True,
                            content=f"Reused existing tab for {url}",
                            metrics=result.metrics,
                        )
                except Exception:
                    pass
        return None

    async def go_back(self) -> ToolResult:
        await self._fire("before_action", {"action": "go_back", "params": {}})
        result = await nav_actions.go_back(
            self._internal.client, self._internal.ref_cache
        )
        await self._record(result)
        return result

    async def go_forward(self) -> ToolResult:
        await self._fire("before_action", {"action": "go_forward", "params": {}})
        result = await nav_actions.go_forward(
            self._internal.client, self._internal.ref_cache
        )
        await self._record(result)
        return result

    async def reload(self) -> ToolResult:
        await self._fire("before_action", {"action": "reload", "params": {}})
        result = await nav_actions.reload(
            self._internal.client, self._internal.ref_cache
        )
        await self._record(result)
        return result

    # ------------------------------------------------------------------
    # Page state
    # ------------------------------------------------------------------

    async def dom_tree(self, level: DOMLevel = "interactive") -> ToolResult:
        start = time.monotonic()
        await self._fire(
            "before_action", {"action": "dom_tree", "params": {"level": level}}
        )
        try:
            doc = await self._internal.client.send("DOM.getDocument", {"depth": -1})
            root = doc["root"]
            info = await self._internal.client.send(
                "Runtime.evaluate",
                {
                    "expression": (
                        "JSON.stringify({url: location.href, title: document.title})"
                    ),
                    "returnByValue": True,
                },
            )
            page_info = json.loads(info.get("result", {}).get("value", "{}"))
            url = page_info.get("url", "")
            title = page_info.get("title", "")
            builder = DOMBuilder(
                dom=root,
                url=url,
                title=title,
                ref_cache=self._internal.ref_cache,
            )
            content = builder.build(level=level)
            tokens = len(content) // 4
            metrics = ActionMetrics(
                action="dom_tree",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=tokens,
            )
            result = ToolResult(success=True, content=content, metrics=metrics)
        except Exception as exc:
            metrics = ActionMetrics(
                action="dom_tree",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=0,
            )
            result = ToolResult(
                success=False, content="", error=str(exc), metrics=metrics
            )
        await self._record(result)
        return result

    async def screenshot(
        self,
        crop: bool = False,
        element_ref: str | None = None,
        full_page: bool = False,
        path: str | None = None,
    ) -> ToolResult:
        """Capture a screenshot. Returns a ToolResult whose content is the
        saved PNG file path (not raw base64) and ``metadata`` carries the
        page url/title/dimensions. See ``actions.capture.screenshot`` for
        path resolution and ``BROWSER_USE_SCREENSHOTS_DIR`` env.
        """
        await self._fire("before_action", {"action": "screenshot", "params": {}})
        result = await capture.screenshot(
            self._internal.client,
            self._internal.ref_cache,
            crop=crop,
            element_ref=element_ref,
            full_page=full_page,
            path=path,
            settings=self._internal._cfg,
        )
        await self._record(result)
        return result

    # ------------------------------------------------------------------
    # Interaction
    # ------------------------------------------------------------------

    async def click(
        self,
        ref: str | None = None,
        selector: str | None = None,
        x: int | None = None,
        y: int | None = None,
    ) -> ToolResult:
        await self._fire("before_action", {"action": "click", "params": {"ref": ref}})
        result = await interact.click(
            self._internal.client,
            self._internal.ref_cache,
            ref=ref,
            selector=selector,
            x=x,
            y=y,
        )
        await self._record(result)
        return result

    async def type(self, text: str, ref: str | None = None) -> ToolResult:
        await self._fire("before_action", {"action": "type", "params": {"ref": ref}})
        result = await interact.type_text(
            self._internal.client, self._internal.ref_cache, text=text, ref=ref
        )
        await self._record(result)
        return result

    async def scroll(self, direction: str = "down", amount: int = 300) -> ToolResult:
        await self._fire("before_action", {"action": "scroll", "params": {}})
        result = await interact.scroll(
            self._internal.client,
            self._internal.ref_cache,
            direction=direction,
            amount=amount,
        )
        await self._record(result)
        return result

    async def hover(self, ref: str) -> ToolResult:
        await self._fire("before_action", {"action": "hover", "params": {"ref": ref}})
        result = await interact.hover(
            self._internal.client, self._internal.ref_cache, ref=ref
        )
        await self._record(result)
        return result

    # ------------------------------------------------------------------
    # JavaScript
    # ------------------------------------------------------------------

    async def eval_js(self, expression: str) -> ToolResult:
        await self._fire("before_action", {"action": "eval_js", "params": {}})
        result = await js_eval.eval_js(self._internal.client, expression)
        await self._record(result)
        return result

    # ------------------------------------------------------------------
    # Tabs
    # ------------------------------------------------------------------

    async def new_tab(self, url: str | None = None) -> ToolResult:
        start = time.monotonic()
        await self._fire("before_action", {"action": "new_tab", "params": {"url": url}})
        try:
            cdp_result = await self._internal.client.send(
                "Target.createTarget", {"url": url or "about:blank"}
            )
            target_id = str(cdp_result.get("targetId", ""))
            metrics = ActionMetrics(
                action="new_tab",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=0,
            )
            result = ToolResult(success=True, content=target_id, metrics=metrics)
        except Exception as exc:
            metrics = ActionMetrics(
                action="new_tab",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=0,
            )
            result = ToolResult(
                success=False, content="", error=str(exc), metrics=metrics
            )
        await self._record(result)
        return result

    async def switch_tab(self, tab_id: str) -> ToolResult:
        start = time.monotonic()
        await self._fire(
            "before_action", {"action": "switch_tab", "params": {"tab_id": tab_id}}
        )
        try:
            await self._internal.client.send(
                "Target.activateTarget", {"targetId": tab_id}
            )
            # Reconnect the CDP WebSocket to the new tab so subsequent
            # navigate/click/dom_tree/screenshot commands target the correct
            # page. Without this, the session would keep talking to the
            # previously-connected tab.
            await self._internal.reconnect_to_target(tab_id)
            metrics = ActionMetrics(
                action="switch_tab",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=0,
            )
            result = ToolResult(
                success=True,
                content=f"Switched to tab {tab_id}",
                metrics=metrics,
            )
        except Exception as exc:
            metrics = ActionMetrics(
                action="switch_tab",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=0,
            )
            result = ToolResult(
                success=False, content="", error=str(exc), metrics=metrics
            )
        await self._record(result)
        return result

    async def close_tab(self, tab_id: str | None = None) -> ToolResult:
        start = time.monotonic()
        await self._fire(
            "before_action", {"action": "close_tab", "params": {"tab_id": tab_id}}
        )
        try:
            if tab_id:
                await self._internal.client.send(
                    "Target.closeTarget", {"targetId": tab_id}
                )
                msg = f"Closed tab {tab_id}"
            else:
                msg = "No tab_id supplied; nothing to close."
            metrics = ActionMetrics(
                action="close_tab",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=0,
            )
            result = ToolResult(success=True, content=msg, metrics=metrics)
        except Exception as exc:
            metrics = ActionMetrics(
                action="close_tab",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=0,
            )
            result = ToolResult(
                success=False, content="", error=str(exc), metrics=metrics
            )
        await self._record(result)
        return result

    async def list_tabs(self) -> ToolResult:
        import aiohttp

        start = time.monotonic()
        await self._fire("before_action", {"action": "list_tabs", "params": {}})
        try:
            host = self._internal._cfg.cdp_host
            port = self._internal._profile.cdp_port
            async with aiohttp.ClientSession() as http:
                async with http.get(f"http://{host}:{port}/json") as resp:
                    targets = await resp.json(content_type=None)
            tabs = [
                TabInfo(
                    tab_id=t["id"],
                    url=t.get("url", ""),
                    title=t.get("title", ""),
                    active=t.get("type") == "page",
                )
                for t in targets
                if t.get("type") == "page"
            ]
            content = (
                "\n".join(
                    f"[{t.tab_id}] {t.title or '(no title)'} — {t.url}" for t in tabs
                )
                or "(no open tabs)"
            )
            metrics = ActionMetrics(
                action="list_tabs",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=len(content) // 4,
            )
            result = ToolResult(success=True, content=content, metrics=metrics)
        except Exception as exc:
            metrics = ActionMetrics(
                action="list_tabs",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=0,
            )
            result = ToolResult(
                success=False, content="", error=str(exc), metrics=metrics
            )
        await self._record(result)
        return result

    # ------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------

    def metrics_summary(self) -> dict[str, Any]:
        return {
            "total_actions": self._action_count,
            "total_duration_ms": self._total_duration_ms,
            "total_estimated_tokens": self._total_tokens,
            "errors": self._errors,
        }

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close the CDP connection (Chrome process keeps running for profile reuse)."""
        await self._internal.close()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _record(self, result: ToolResult) -> None:
        self._action_count += 1
        self._total_duration_ms += result.metrics.duration_ms
        self._total_tokens += result.metrics.estimated_tokens
        if not result.success:
            self._errors += 1
            await self._fire("action_error", result)
        else:
            await self._fire("after_action", result.metrics)
