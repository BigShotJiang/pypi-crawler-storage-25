"""Chrome process management: launch, attach, and discover."""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path

import aiohttp

from harness_browser.profile import Profile

logger = logging.getLogger(__name__)

_CHROME_PATHS_LINUX = [
    "/usr/bin/google-chrome",
    "/usr/bin/google-chrome-stable",
    "/usr/bin/chromium-browser",
    "/usr/bin/chromium",
    "/snap/bin/chromium",
]

_CHROME_PATHS_MAC = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
]

# Linux clone flag for creating a new user namespace; used by
# ``_user_namespaces_available()`` to probe whether Chrome's zygote will
# be allowed to start.
_CLONE_NEWUSER = 0x10000000


def _find_playwright_chromium() -> str | None:
    """Locate a Chromium binary previously downloaded by Playwright.

    Playwright stores browsers under ``$PLAYWRIGHT_BROWSERS_PATH`` (when set)
    or ``~/.cache/ms-playwright`` on Linux, ``~/Library/Caches/ms-playwright``
    on macOS, and ``%USERPROFILE%\\AppData\\Local\\ms-playwright`` on Windows.
    Inside that root, each browser revision lives at
    ``chromium-<rev>/chrome-<platform>/chrome`` (or ``Chromium.app/...`` on
    macOS). We pick the highest-numbered revision so a freshly-installed
    Playwright build wins automatically.
    """
    env_root = os.environ.get("PLAYWRIGHT_BROWSERS_PATH")
    candidates: list[Path] = []
    if env_root:
        candidates.append(Path(env_root))
    if sys.platform == "darwin":
        candidates.append(Path.home() / "Library" / "Caches" / "ms-playwright")
    elif sys.platform.startswith("win"):
        local = os.environ.get("LOCALAPPDATA")
        if local:
            candidates.append(Path(local) / "ms-playwright")
    else:
        candidates.append(Path.home() / ".cache" / "ms-playwright")

    for root in candidates:
        if not root.is_dir():
            continue
        # chromium-<rev> directories; sort numerically by revision so we
        # pick the newest install.
        chromium_dirs = sorted(
            (p for p in root.glob("chromium-*") if p.is_dir()),
            key=lambda p: _parse_pw_revision(p.name),
            reverse=True,
        )
        for cdir in chromium_dirs:
            if sys.platform == "darwin":
                exe = (
                    cdir
                    / "chrome-mac"
                    / "Chromium.app"
                    / "Contents"
                    / "MacOS"
                    / "Chromium"
                )
            elif sys.platform.startswith("win"):
                exe = cdir / "chrome-win" / "chrome.exe"
            else:
                # chrome-linux64 (newer) or chrome-linux (older) layout
                exe = cdir / "chrome-linux64" / "chrome"
                if not exe.exists():
                    exe = cdir / "chrome-linux" / "chrome"
            if exe.exists():
                logger.debug("Found Playwright Chromium at %s", exe)
                return str(exe)
    return None


def _parse_pw_revision(name: str) -> int:
    """Parse a ``chromium-<rev>`` directory name into an int for sorting."""
    suffix = name.rsplit("-", 1)[-1]
    try:
        return int(suffix)
    except ValueError:
        return -1


def find_chrome() -> str | None:
    """Return the path to the first available Chrome/Chromium executable.

    Search order:
      1. ``BROWSER_USE_CHROME_BIN`` (explicit override)
      2. Standard system install paths (``/usr/bin/google-chrome``, …)
      3. ``PATH`` lookup for ``google-chrome`` / ``chromium`` / …
      4. Playwright's downloaded Chromium under ``~/.cache/ms-playwright``
         (or ``$PLAYWRIGHT_BROWSERS_PATH``)
    """
    from harness_browser.settings import settings as _settings

    if _settings.chrome_bin and Path(_settings.chrome_bin).exists():
        return _settings.chrome_bin
    if sys.platform == "darwin":
        candidates = _CHROME_PATHS_MAC
    else:
        candidates = _CHROME_PATHS_LINUX
    for path in candidates:
        if Path(path).exists():
            return path
    # PATH lookup
    on_path = (
        shutil.which("google-chrome")
        or shutil.which("chromium")
        or shutil.which("chromium-browser")
    )
    if on_path:
        return on_path
    # Last resort: Playwright's bundled Chromium (common on dev machines and
    # in projects that already depend on Playwright).
    return _find_playwright_chromium()


def _build_flags(profile: Profile, headless: bool) -> list[str]:
    from harness_browser.settings import settings as _settings

    flags = [
        f"--remote-debugging-port={profile.cdp_port}",
        f"--user-data-dir={profile.data_dir}",
        "--disable-background-networking",
        "--disable-sync",
        "--disable-translate",
        "--disable-extensions",
        "--disable-default-apps",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-popup-blocking",
        "--metrics-recording-only",
        "--safebrowsing-disable-auto-update",
    ]
    # If user is binding Chrome to a non-loopback host (e.g. for Docker port
    # forwarding), pass --remote-debugging-address so Chrome listens externally.
    if _settings.cdp_host not in ("localhost", "127.0.0.1"):
        flags.append(f"--remote-debugging-address={_settings.cdp_host}")
    if headless:
        flags.append("--headless=new")
    if _should_disable_sandbox():
        flags.append("--no-sandbox")
    return flags


def _should_disable_sandbox() -> bool:
    """Return True if Chromium should be launched with ``--no-sandbox``.

    Chromium uses Linux user namespaces to isolate renderer processes. In
    containers / chroots / restricted sandboxes that don't grant the
    ``CLONE_NEWUSER`` capability, the zygote crashes with
    ``Failed to move to new namespace: ... Operation not permitted``
    and Chrome never binds to the CDP port.

    The flag is needed when:
      * running as root (the kernel itself rejects user-ns + setuid), OR
      * ``BROWSER_USE_NO_SANDBOX`` is truthy in the environment, OR
      * we're on Linux and a quick probe shows the kernel won't allow
        unprivileged user namespaces.

    Set ``BROWSER_USE_NO_SANDBOX=0`` to force-disable this auto-detection
    (e.g. on a hardened production host where you've already arranged
    the right caps and want Chrome's full sandbox).
    """
    override = os.environ.get("BROWSER_USE_NO_SANDBOX")
    if override is not None:
        return override.strip().lower() in ("1", "true", "yes", "on")
    if not sys.platform.startswith("linux"):
        return False
    if os.getuid() == 0:
        return True
    return not _user_namespaces_available()


_user_ns_cache: bool | None = None


def _user_namespaces_available() -> bool:
    """Best-effort probe: can this process create unprivileged user namespaces?

    Direct probe: spawn a fresh ``python -c ...`` that calls
    ``unshare(CLONE_NEWUSER)`` via ctypes; if it returns -EPERM (or any
    non-zero), Chrome's zygote will fail too and we should add
    ``--no-sandbox``.

    We use ``subprocess`` rather than ``os.fork()`` because Python 3.12
    raises a DeprecationWarning when fork() is called from a process that
    has imported any threading-using module (covers most asyncio servers).
    The result is cached for the process lifetime — kernel namespace
    policy doesn't change at runtime.
    """
    global _user_ns_cache
    if _user_ns_cache is not None:
        return _user_ns_cache
    code = (
        "import ctypes, sys; "
        "libc = ctypes.CDLL('libc.so.6', use_errno=True); "
        f"sys.exit(0 if libc.unshare({_CLONE_NEWUSER}) == 0 else 1)"
    )
    try:
        result = subprocess.run(  # noqa: S603
            [sys.executable, "-c", code],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=2.0,
        )
        _user_ns_cache = result.returncode == 0
    except Exception:
        _user_ns_cache = False
    return _user_ns_cache


async def _get_ws_url(
    port: int,
    retries: int | None = None,
    delay: float | None = None,
) -> str:
    """Poll Chrome's /json/version endpoint until it responds."""
    from harness_browser.settings import settings as _settings

    _retries = retries if retries is not None else _settings.launch_retries
    _delay = delay if delay is not None else _settings.launch_delay
    url = f"http://{_settings.cdp_host}:{port}/json/version"
    for attempt in range(_retries):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url, timeout=aiohttp.ClientTimeout(total=2)
                ) as resp:
                    data = await resp.json(content_type=None)
                    ws_url: str = data["webSocketDebuggerUrl"]
                    logger.debug("Chrome ready at %s", ws_url)
                    return ws_url
        except Exception:  # noqa: BLE001
            if attempt < _retries - 1:
                await asyncio.sleep(_delay)
    raise RuntimeError(
        f"Chrome did not start on {_settings.cdp_host}:{port} after {_retries} attempts"
    )


async def _port_in_use(port: int) -> bool:
    """Check if Chrome is already listening on the given port."""
    from harness_browser.settings import settings as _settings

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"http://{_settings.cdp_host}:{port}/json/version",
                timeout=aiohttp.ClientTimeout(total=1),
            ) as resp:
                return resp.status == 200
    except Exception:  # noqa: BLE001
        return False


async def launch_or_attach(profile: Profile, headless: bool = False) -> str:
    """
    Ensure Chrome is running for this profile and return a CDP WebSocket URL.

    If Chrome is already running on the profile's CDP port, re-attach.
    Otherwise, launch a new Chrome process.

    Returns the browser-level WebSocket URL.
    """
    from harness_browser.settings import settings as _settings

    if await _port_in_use(profile.cdp_port):
        logger.debug(
            "Attaching to existing Chrome on %s:%d",
            _settings.cdp_host,
            profile.cdp_port,
        )
        return await _get_ws_url(profile.cdp_port)

    # Refuse to "launch" a remote browser — only local hosts can spawn Chrome.
    if _settings.cdp_host not in ("localhost", "127.0.0.1"):
        raise RuntimeError(
            f"Cannot launch Chrome on remote host '{_settings.cdp_host}'. "
            "Start Chrome there manually with --remote-debugging-port and "
            "--remote-debugging-address=0.0.0.0, or set BROWSER_USE_CDP_WS_URL "
            "to connect directly."
        )

    chrome = find_chrome()
    if chrome is None:
        raise RuntimeError(
            "Chrome/Chromium not found. Install Google Chrome or Chromium.\n"
            "On Ubuntu: sudo apt install chromium-browser\n"
            "On macOS: brew install --cask google-chrome"
        )

    flags = _build_flags(profile, headless=headless)
    cmd = [chrome, *flags, "about:blank"]
    logger.debug("Launching Chrome: %s", " ".join(cmd))
    subprocess.Popen(  # noqa: S603
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return await _get_ws_url(profile.cdp_port)


async def get_page_ws_url(port: int) -> str:
    """Return the WebSocket URL of the first open page/tab."""
    from harness_browser.settings import settings as _settings

    url = f"http://{_settings.cdp_host}:{port}/json"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
            targets = await resp.json(content_type=None)
    for target in targets:
        if target.get("type") == "page":
            return str(target["webSocketDebuggerUrl"])
    raise RuntimeError("No open page found in Chrome")


async def get_target_ws_url(port: int, target_id: str) -> str:
    """Return the WebSocket URL for a specific tab by its target ID.

    Queries Chrome's ``/json`` endpoint and looks up the target with the
    matching ``id``.  Raises ``RuntimeError`` if the target is not found
    (e.g. tab was closed between list_tabs and switch_tab).
    """
    from harness_browser.settings import settings as _settings

    url = f"http://{_settings.cdp_host}:{port}/json"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
            targets = await resp.json(content_type=None)
    for target in targets:
        if target.get("id") == target_id:
            ws_url = target.get("webSocketDebuggerUrl")
            if ws_url:
                return str(ws_url)
            break
    raise RuntimeError(f"Target {target_id!r} not found or has no WebSocket URL")
