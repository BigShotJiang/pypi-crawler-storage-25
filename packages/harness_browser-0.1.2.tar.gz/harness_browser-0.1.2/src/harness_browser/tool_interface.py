"""Stateless browser_tool() entry point for AI frameworks."""

from __future__ import annotations

import logging
from typing import Any

from harness_browser.mode import BrowserMode
from harness_browser.models import ActionMetrics, ToolResult
from harness_browser.session import BrowserSession

logger = logging.getLogger(__name__)

_registry: dict[str, BrowserSession] = {}
_global_hooks: dict[str, list[Any]] = {}

_KNOWN_ACTIONS = frozenset(
    [
        "navigate",
        "dom_tree",
        "screenshot",
        "click",
        "type",
        "scroll",
        "hover",
        "eval_js",
        "go_back",
        "go_forward",
        "reload",
        "new_tab",
        "switch_tab",
        "close_tab",
        "list_tabs",
        "close_session",
    ]
)


def _error_result(action: str, message: str) -> ToolResult:
    return ToolResult(
        success=False,
        content="",
        error=message,
        metrics=ActionMetrics(
            action=action, duration_ms=0, dom_nodes_scanned=0, estimated_tokens=0
        ),
    )


async def _get_or_create_session(
    profile: str,
    headless: bool | None = None,
    mode: BrowserMode | None = None,
) -> BrowserSession:
    if profile not in _registry:
        sess = await BrowserSession.create(
            profile=profile, headless=headless, mode=mode
        )
        _registry[profile] = sess
    return _registry[profile]


async def browser_tool(
    action: str,
    profile: str = "default",
    headless: bool | None = None,
    mode: BrowserMode | None = None,
    **kwargs: Any,
) -> ToolResult:
    """
    Stateless entry point for AI frameworks.

    Routes to the correct :class:`BrowserSession` by ``profile`` name.
    Creates a new session lazily if none exists for the profile.

    Args:
        action: One of the supported action strings.
        profile: Profile name (maps to a Chrome user-data-dir).
        headless: Legacy boolean override (only honored on first call per
            profile). Prefer ``mode``.
        mode: ``"auto"`` | ``"headed"`` | ``"headless"``. Defaults to the
            ``BROWSER_USE_MODE`` environment variable, then ``"auto"``.
            Only honored on first call per profile.
        **kwargs: Action-specific parameters.

    Returns:
        A :class:`ToolResult`.
    """
    if action not in _KNOWN_ACTIONS:
        return _error_result(
            action, f"Unknown action '{action}'. Valid: {sorted(_KNOWN_ACTIONS)}"
        )

    if action == "close_session":
        if profile in _registry:
            await _registry[profile].close()
            del _registry[profile]
        return ToolResult(
            success=True,
            content=f"Session '{profile}' closed.",
            metrics=ActionMetrics(
                action="close_session",
                duration_ms=0,
                dom_nodes_scanned=0,
                estimated_tokens=0,
            ),
        )

    try:
        sess = await _get_or_create_session(profile, headless=headless, mode=mode)
    except Exception as exc:
        return _error_result(action, f"Failed to create session: {exc}")

    try:
        method = getattr(sess, action)
        result: ToolResult = await method(**kwargs)
        return result
    except TypeError as exc:
        return _error_result(action, f"Invalid parameters for '{action}': {exc}")
    except Exception as exc:
        logger.exception("browser_tool error for action=%s profile=%s", action, profile)
        return _error_result(action, str(exc))
