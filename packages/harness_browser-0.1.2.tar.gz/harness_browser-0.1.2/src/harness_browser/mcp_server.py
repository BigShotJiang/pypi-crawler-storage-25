"""MCP Server: expose browser_tool actions as MCP tools."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from harness_browser.tool_interface import browser_tool

logger = logging.getLogger(__name__)

app = Server("harness-browser")

_TOOLS = [
    Tool(
        name="browser_navigate",
        description="Navigate browser to a URL",
        inputSchema={
            "type": "object",
            "properties": {
                "url": {"type": "string"},
                "profile": {"type": "string", "default": "default"},
            },
            "required": ["url"],
        },
    ),
    Tool(
        name="browser_dom_tree",
        description="Get page DOM tree (level: minimal/interactive/full/structured)",
        inputSchema={
            "type": "object",
            "properties": {
                "level": {
                    "type": "string",
                    "enum": ["minimal", "interactive", "full", "structured"],
                    "default": "interactive",
                },
                "profile": {"type": "string", "default": "default"},
            },
        },
    ),
    Tool(
        name="browser_screenshot",
        description=(
            "Capture a PNG screenshot. Writes to disk and returns the file "
            "path (not base64). Use full_page=true for the entire scrollable "
            "page; element_ref=<ref> for a single element."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "profile": {"type": "string", "default": "default"},
                "element_ref": {"type": "string"},
                "full_page": {"type": "boolean", "default": False},
                "path": {
                    "type": "string",
                    "description": (
                        "Optional output path. Absolute paths are used "
                        "verbatim; relative paths resolve under "
                        "BROWSER_USE_SCREENSHOTS_DIR."
                    ),
                },
            },
        },
    ),
    Tool(
        name="browser_click",
        description="Click an element by ref, selector, or coordinates",
        inputSchema={
            "type": "object",
            "properties": {
                "ref": {"type": "string"},
                "selector": {"type": "string"},
                "x": {"type": "integer"},
                "y": {"type": "integer"},
                "profile": {"type": "string", "default": "default"},
            },
        },
    ),
    Tool(
        name="browser_type",
        description="Type text into the page",
        inputSchema={
            "type": "object",
            "properties": {
                "text": {"type": "string"},
                "ref": {"type": "string"},
                "profile": {"type": "string", "default": "default"},
            },
            "required": ["text"],
        },
    ),
    Tool(
        name="browser_eval_js",
        description="Execute JavaScript in the page",
        inputSchema={
            "type": "object",
            "properties": {
                "expression": {"type": "string"},
                "profile": {"type": "string", "default": "default"},
            },
            "required": ["expression"],
        },
    ),
]

_ACTION_MAP = {
    "browser_navigate": "navigate",
    "browser_dom_tree": "dom_tree",
    "browser_screenshot": "screenshot",
    "browser_click": "click",
    "browser_type": "type",
    "browser_eval_js": "eval_js",
}


@app.list_tools()  # type: ignore[no-untyped-call, untyped-decorator]
async def list_tools() -> list[Tool]:
    return _TOOLS


@app.call_tool()  # type: ignore[untyped-decorator]
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    action = _ACTION_MAP.get(name)
    if action is None:
        return [TextContent(type="text", text=f"Unknown tool: {name}")]
    result = await browser_tool(action=action, **arguments)
    text = result.content if isinstance(result.content, str) else str(result.content)
    if not result.success:
        text = f"ERROR: {result.error}"
    return [TextContent(type="text", text=text)]


async def _main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(_main())
