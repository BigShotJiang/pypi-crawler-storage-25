"""Tiered DOM output builder for AI-friendly page state representation."""

from __future__ import annotations

import json
from typing import Any, Literal

from harness_browser.dom.refs import RefCache

DOMLevel = Literal["minimal", "interactive", "full", "structured"]

_INTERACTIVE_TAGS = frozenset(
    ["button", "input", "select", "textarea", "a", "label", "form"]
)
_STRUCTURAL_TAGS = frozenset(
    [
        "header",
        "nav",
        "main",
        "footer",
        "section",
        "article",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "p",
        "table",
    ]
)
_INTERACTIVE_ROLES = frozenset(
    [
        "button",
        "link",
        "textbox",
        "combobox",
        "checkbox",
        "radio",
        "menuitem",
        "option",
        "switch",
        "tab",
        "searchbox",
    ]
)
_SKIP_TAGS = frozenset(
    [
        "script",
        "style",
        "meta",
        "link",
        "noscript",
        "svg",
        "path",
        "head",
        "html",
        "#document",
    ]
)


def _attrs_to_dict(attrs: list[str]) -> dict[str, str]:
    """Convert CDP flat attributes list ['key','val',...] to dict."""
    return dict(zip(attrs[::2], attrs[1::2])) if attrs else {}


def _node_text(node: dict[str, Any]) -> str:
    """Return the direct text content of a node (first text child only)."""
    for child in node.get("children", []):
        if child.get("nodeName") == "#text":
            val: str = child.get("nodeValue", "")
            return val.strip()
    return ""


def _make_ref(tag: str, counter: dict[str, int]) -> str:
    prefix = {
        "input": "inp",
        "button": "btn",
        "a": "lnk",
        "select": "sel",
        "textarea": "txt",
    }.get(tag, tag[:3])
    idx = counter.get(prefix, 0)
    counter[prefix] = idx + 1
    return f"{prefix}_{idx}"


class DOMBuilder:
    """
    Converts a raw CDP DOM tree into one of four output levels.

    Args:
        dom: The CDP ``DOM.getDocument`` root node dict.
        url: Current page URL.
        title: Current page title.
        ref_cache: A ``RefCache`` instance to populate with ref→node_id mappings.
    """

    def __init__(
        self,
        dom: dict[str, Any],
        url: str,
        title: str,
        ref_cache: RefCache,
    ) -> None:
        self._dom = dom
        self._url = url
        self._title = title
        self._ref_cache = ref_cache

    def build(self, level: DOMLevel = "interactive") -> str:
        """Build and return the DOM representation at the requested level."""
        ref_counter: dict[str, int] = {}
        interactive: list[dict[str, Any]] = []
        structural: list[str] = []

        self._walk(self._dom, interactive, structural, ref_counter, depth=0)

        if level == "minimal":
            return self._build_minimal(len(interactive))
        if level == "interactive":
            return self._build_interactive(interactive)
        if level == "full":
            return self._build_full(interactive, structural)
        if level == "structured":
            return self._build_structured(interactive)
        raise ValueError(f"Unknown DOM level: {level!r}")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _walk(
        self,
        node: dict[str, Any],
        interactive: list[dict[str, Any]],
        structural: list[str],
        counter: dict[str, int],
        depth: int,
    ) -> None:
        tag = node.get("nodeName", "").lower()
        if tag in ("#text", "#comment"):
            return
        if tag in _SKIP_TAGS:
            # Still recurse into #document
            for child in node.get("children", []):
                self._walk(child, interactive, structural, counter, depth)
            return

        attrs = _attrs_to_dict(node.get("attributes", []))
        role = attrs.get("role", "")
        aria_label = attrs.get("aria-label", "")
        is_interactive = tag in _INTERACTIVE_TAGS or role in _INTERACTIVE_ROLES
        # Anchor must have href to count as interactive
        if tag == "a" and not attrs.get("href"):
            is_interactive = False

        if is_interactive:
            ref = _make_ref(tag, counter)
            self._ref_cache.store(ref, node["nodeId"])
            interactive.append(
                {
                    "ref": ref,
                    "tag": tag,
                    "type": attrs.get("type", ""),
                    "role": role or tag,
                    "label": aria_label or attrs.get("label", ""),
                    "placeholder": attrs.get("placeholder", ""),
                    "text": _node_text(node),
                    "href": attrs.get("href", ""),
                    "node_id": node["nodeId"],
                    "attrs": attrs,
                    "depth": depth,
                }
            )
        elif tag in _STRUCTURAL_TAGS:
            text = _node_text(node)
            indent = "  " * depth
            structural.append(f"{indent}<{tag}>{(' ' + text) if text else ''}")

        for child in node.get("children", []):
            self._walk(child, interactive, structural, counter, depth + 1)

    def _build_minimal(self, interactive_count: int) -> str:
        return (
            f'Page: {self._url} | "{self._title}"\n'
            f"Interactive elements: {interactive_count} | Scroll: yes"
        )

    def _build_interactive(self, interactive: list[dict[str, Any]]) -> str:
        lines = [
            f'Page: {self._url} | "{self._title}"',
            f"Interactive elements ({len(interactive)}):",
        ]
        for el in interactive:
            tag = el["tag"]
            ref = el["ref"]
            if tag == "input":
                type_part = f"[{el['type'] or 'text'}]"
                label_part = ""
                if el["placeholder"]:
                    label_part = f' placeholder="{el["placeholder"]}"'
                elif el["label"]:
                    label_part = f' label="{el["label"]}"'
                lines.append(f"  [ref={ref}] input{type_part}{label_part}")
            elif tag == "button":
                text = el["text"] or el["label"] or ""
                lines.append(f'  [ref={ref}] button "{text}"')
            elif tag == "a":
                text = el["text"] or el["label"] or el["href"]
                lines.append(f'  [ref={ref}] a "{text}"')
            elif tag == "select":
                label = el["label"] or el["placeholder"] or ""
                lines.append(f'  [ref={ref}] select "{label}"')
            elif tag == "textarea":
                placeholder = el["placeholder"] or ""
                lines.append(f'  [ref={ref}] textarea placeholder="{placeholder}"')
            else:
                label = el["text"] or el["label"] or ""
                lines.append(f'  [ref={ref}] {tag} "{label}"')
        return "\n".join(lines)

    def _build_full(
        self, interactive: list[dict[str, Any]], structural: list[str]
    ) -> str:
        parts = [f'Page: {self._url} | "{self._title}"\n']
        if structural:
            parts.extend(structural)
            parts.append("")
        if interactive:
            parts.append(f"Interactive elements ({len(interactive)}):")
            for el in interactive:
                ref = el["ref"]
                tag = el["tag"]
                attrs_str = ""
                if el["type"]:
                    attrs_str += f" type={el['type']}"
                if el["placeholder"]:
                    attrs_str += f' placeholder="{el["placeholder"]}"'
                text = el["text"] or el["label"]
                text_str = f" {text}" if text else ""
                parts.append(f"  <{tag} ref={ref}{attrs_str}>{text_str}")
        return "\n".join(parts)

    def _build_structured(self, interactive: list[dict[str, Any]]) -> str:
        elements = []
        for el in interactive:
            entry: dict[str, Any] = {
                "ref": el["ref"],
                "tag": el["tag"],
                "role": el["role"],
                "node_id": el["node_id"],
            }
            if el["type"]:
                entry["type"] = el["type"]
            if el["label"]:
                entry["label"] = el["label"]
            if el["placeholder"]:
                entry["placeholder"] = el["placeholder"]
            if el["text"]:
                entry["text"] = el["text"]
            if el["href"]:
                entry["href"] = el["href"]
            elements.append(entry)
        data: dict[str, Any] = {
            "url": self._url,
            "title": self._title,
            "elements": elements,
        }
        return json.dumps(data, indent=2, ensure_ascii=False)
