"""harness-browser: AI-friendly browser automation via CDP."""

from harness_browser.mode import BrowserMode
from harness_browser.models import ActionMetrics, TabInfo, ToolResult
from harness_browser.session import BrowserSession
from harness_browser.settings import HarnessSettings, settings
from harness_browser.tool_interface import browser_tool

__all__ = [
    "BrowserSession",
    "browser_tool",
    "BrowserMode",
    "HarnessSettings",
    "settings",
    "ToolResult",
    "ActionMetrics",
    "TabInfo",
]
