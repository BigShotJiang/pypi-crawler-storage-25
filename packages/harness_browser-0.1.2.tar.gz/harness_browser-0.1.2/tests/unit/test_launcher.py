"""Tests for harness_browser.cdp.launcher.find_chrome auto-discovery."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from harness_browser.cdp.launcher import _find_playwright_chromium, _parse_pw_revision


def test_parse_pw_revision_valid():
    assert _parse_pw_revision("chromium-1223") == 1223
    assert _parse_pw_revision("chromium-9999") == 9999


def test_parse_pw_revision_invalid():
    assert _parse_pw_revision("not-a-version") == -1
    assert _parse_pw_revision("chromium") == -1


@pytest.mark.skipif(
    sys.platform.startswith("win"),
    reason="Layout differs on Windows; covered by separate path branch.",
)
def test_find_playwright_chromium_picks_highest_revision(monkeypatch, tmp_path):
    """Given two installed Chromium revisions, pick the newer one."""
    # Pretend $PLAYWRIGHT_BROWSERS_PATH points at our tmp dir
    monkeypatch.setenv("PLAYWRIGHT_BROWSERS_PATH", str(tmp_path))

    if sys.platform == "darwin":
        platform_subdir = "chrome-mac/Chromium.app/Contents/MacOS"
        binary_name = "Chromium"
    else:
        platform_subdir = "chrome-linux64"
        binary_name = "chrome"

    # Old revision
    old_dir = tmp_path / "chromium-1000" / platform_subdir
    old_dir.mkdir(parents=True)
    (old_dir / binary_name).write_text("#!/bin/sh\nexit 0\n")
    (old_dir / binary_name).chmod(0o755)

    # New revision
    new_dir = tmp_path / "chromium-1500" / platform_subdir
    new_dir.mkdir(parents=True)
    (new_dir / binary_name).write_text("#!/bin/sh\nexit 0\n")
    (new_dir / binary_name).chmod(0o755)

    found = _find_playwright_chromium()
    assert found is not None
    assert "chromium-1500" in found
    assert "chromium-1000" not in found


def test_find_playwright_chromium_returns_none_when_missing(monkeypatch, tmp_path):
    """No installs anywhere → returns None."""
    monkeypatch.setenv("PLAYWRIGHT_BROWSERS_PATH", str(tmp_path / "empty"))
    # Also redirect HOME so the default ~/.cache/ms-playwright is empty too.
    monkeypatch.setenv("HOME", str(tmp_path))
    # On macOS the default uses ~/Library/Caches; redirect via HOME above.
    assert _find_playwright_chromium() is None


@pytest.mark.skipif(
    sys.platform != "linux",
    reason="Linux falls back to chrome-linux when chrome-linux64 is absent.",
)
def test_find_playwright_chromium_falls_back_to_old_layout(monkeypatch, tmp_path):
    """Older Playwright builds use chrome-linux/ instead of chrome-linux64/."""
    monkeypatch.setenv("PLAYWRIGHT_BROWSERS_PATH", str(tmp_path))
    old_layout = tmp_path / "chromium-900" / "chrome-linux"
    old_layout.mkdir(parents=True)
    binary = old_layout / "chrome"
    binary.write_text("#!/bin/sh\nexit 0\n")
    binary.chmod(0o755)

    found = _find_playwright_chromium()
    assert found is not None
    assert Path(found) == binary


# ---------------------------------------------------------------------------
# --no-sandbox auto-detection
# ---------------------------------------------------------------------------


def test_no_sandbox_env_override_truthy(monkeypatch):
    """``BROWSER_USE_NO_SANDBOX=1`` forces --no-sandbox unconditionally."""
    from harness_browser.cdp.launcher import _should_disable_sandbox

    monkeypatch.setenv("BROWSER_USE_NO_SANDBOX", "1")
    assert _should_disable_sandbox() is True
    monkeypatch.setenv("BROWSER_USE_NO_SANDBOX", "true")
    assert _should_disable_sandbox() is True
    monkeypatch.setenv("BROWSER_USE_NO_SANDBOX", "yes")
    assert _should_disable_sandbox() is True


def test_no_sandbox_env_override_falsy(monkeypatch):
    """``BROWSER_USE_NO_SANDBOX=0`` force-disables auto-detect even on
    container hosts where the kernel would otherwise refuse user
    namespaces."""
    from harness_browser.cdp.launcher import _should_disable_sandbox

    monkeypatch.setenv("BROWSER_USE_NO_SANDBOX", "0")
    assert _should_disable_sandbox() is False
    monkeypatch.setenv("BROWSER_USE_NO_SANDBOX", "false")
    assert _should_disable_sandbox() is False


def test_no_sandbox_off_on_macos(monkeypatch):
    """On macOS / Windows we never need --no-sandbox."""
    from harness_browser.cdp import launcher as _l

    monkeypatch.delenv("BROWSER_USE_NO_SANDBOX", raising=False)
    monkeypatch.setattr(_l.sys, "platform", "darwin")
    assert _l._should_disable_sandbox() is False
    monkeypatch.setattr(_l.sys, "platform", "win32")
    assert _l._should_disable_sandbox() is False


def test_user_namespaces_available_returns_bool():
    """Direct probe — just verify it returns a bool without crashing."""
    from harness_browser.cdp.launcher import _user_namespaces_available

    assert isinstance(_user_namespaces_available(), bool)
