from unittest.mock import AsyncMock, patch

from harness_browser.models import ActionMetrics, ToolResult
from harness_browser.tool_interface import browser_tool


def make_tool_result(action: str = "navigate") -> ToolResult:
    return ToolResult(
        success=True,
        content="ok",
        metrics=ActionMetrics(
            action=action, duration_ms=10, dom_nodes_scanned=0, estimated_tokens=5
        ),
    )


async def test_browser_tool_unknown_action():
    result = await browser_tool(
        action="nonexistent_action_xyz", profile="_test_unknown_"
    )
    assert result.success is False
    assert "Unknown action" in (result.error or "")


async def test_browser_tool_missing_required_param():
    # navigate requires url; omitting it should return error
    with patch("harness_browser.tool_interface._get_or_create_session") as mock_get:
        mock_sess = AsyncMock()
        mock_sess.navigate = AsyncMock(side_effect=TypeError("missing url"))
        mock_get.return_value = mock_sess
        result = await browser_tool(action="navigate", profile="_test_missing_")
    assert result.success is False
