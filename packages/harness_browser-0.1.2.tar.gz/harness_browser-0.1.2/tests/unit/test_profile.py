from pathlib import Path

import pytest

from harness_browser.profile import ProfileManager


@pytest.fixture()
def tmp_profiles_dir(tmp_path: Path) -> Path:
    return tmp_path / "profiles"


def test_get_or_create_creates_directory(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    p = pm.get_or_create("work")
    assert p.name == "work"
    assert p.data_dir.exists()
    assert p.data_dir == tmp_profiles_dir / "work"


def test_get_or_create_is_idempotent(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    p1 = pm.get_or_create("work")
    p2 = pm.get_or_create("work")
    assert p1.cdp_port == p2.cdp_port


def test_default_profile_gets_port_9222(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    p = pm.get_or_create("default")
    assert p.cdp_port == 9222


def test_second_profile_gets_incremented_port(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    pm.get_or_create("default")
    p2 = pm.get_or_create("other")
    assert p2.cdp_port == 9223


def test_list_profiles(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    pm.get_or_create("a")
    pm.get_or_create("b")
    names = [p.name for p in pm.list_profiles()]
    assert set(names) == {"a", "b"}


def test_delete_profile(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    pm.get_or_create("temp")
    pm.delete("temp")
    assert not any(p.name == "temp" for p in pm.list_profiles())


def test_delete_nonexistent_profile_is_noop(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    pm.delete("nonexistent")  # should not raise
