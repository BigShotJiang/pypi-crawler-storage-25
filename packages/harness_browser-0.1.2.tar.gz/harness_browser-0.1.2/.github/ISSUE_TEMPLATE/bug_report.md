---
name: Bug Report
about: Report a bug
labels: bug
---

## Description

## Steps to Reproduce

1.
2.

## Expected Behavior

## Actual Behavior

## Environment

- OS:
- Python version:
- harness-browser version:
- Chrome version:
