# orckit-browser-use Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build and publish `orckit-browser-use`, an AI-friendly browser automation pip package built on pure CDP with profile-based login persistence, tiered DOM output, hooks, metrics, MCP server mode, and a Claude Code skill.

**Architecture:** `BrowserSession` is the user-facing Python API backed by `_InternalCDPSession` which owns a `CDPClient` (pure asyncio WebSocket). A stateless `browser_tool()` function routes calls to the correct session by `profile` name, enabling AI frameworks to call it without managing objects. Chrome is launched and managed via `cdp/launcher.py` with per-profile user-data-dirs for login state persistence.

**Tech Stack:** Python 3.11+, `websockets` (CDP), `pydantic` v2, `aiohttp` (HTTP for CDP target discovery), `mcp` (MCP server), `uv` (project management), `ruff` + `mypy` (linting), `pytest` + `pytest-asyncio` (testing).

---

## File Map

| File | Create/Modify | Responsibility |
|------|--------------|----------------|
| `orckit-browser-use/pyproject.toml` | Create | Project metadata, deps, tool config |
| `orckit-browser-use/Makefile` | Create | run/test/lint/format/build/publish/mcp/clean |
| `orckit-browser-use/.pre-commit-config.yaml` | Create | ruff + mypy pre-commit hooks |
| `orckit-browser-use/src/orckit_browser/__init__.py` | Create | Public API exports |
| `orckit-browser-use/src/orckit_browser/models.py` | Create | `ActionMetrics`, `ToolResult`, `TabInfo` Pydantic models |
| `orckit-browser-use/src/orckit_browser/profile.py` | Create | `Profile` dataclass + `ProfileManager` |
| `orckit-browser-use/src/orckit_browser/cdp/client.py` | Create | `CDPClient` — asyncio WebSocket CDP |
| `orckit-browser-use/src/orckit_browser/cdp/launcher.py` | Create | Chrome launch/attach, `launch_or_attach()` |
| `orckit-browser-use/src/orckit_browser/dom/refs.py` | Create | `RefCache` — ref→node_id mapping |
| `orckit-browser-use/src/orckit_browser/dom/builder.py` | Create | `DOMBuilder.build()` — 4-level DOM output |
| `orckit-browser-use/src/orckit_browser/hooks.py` | Create | `HooksMixin` — event registration + firing |
| `orckit-browser-use/src/orckit_browser/actions/navigate.py` | Create | `navigate`, `go_back`, `go_forward`, `reload` |
| `orckit-browser-use/src/orckit_browser/actions/interact.py` | Create | `click`, `type_text`, `scroll`, `hover` |
| `orckit-browser-use/src/orckit_browser/actions/capture.py` | Create | `screenshot` |
| `orckit-browser-use/src/orckit_browser/actions/js_eval.py` | Create | `eval_js` |
| `orckit-browser-use/src/orckit_browser/session.py` | Create | `BrowserSession` + `_InternalCDPSession` |
| `orckit-browser-use/src/orckit_browser/tool_interface.py` | Create | `browser_tool()` stateless bridge |
| `orckit-browser-use/src/orckit_browser/mcp_server.py` | Create | MCP Server exposing all actions |
| `orckit-browser-use/skill/orckit-browser-use.md` | Create | Claude Code skill file |
| `orckit-browser-use/tests/unit/test_models.py` | Create | Unit tests for Pydantic models |
| `orckit-browser-use/tests/unit/test_profile.py` | Create | Unit tests for ProfileManager |
| `orckit-browser-use/tests/unit/test_dom_builder.py` | Create | Unit tests for 4-level DOM output |
| `orckit-browser-use/tests/unit/test_refs.py` | Create | Unit tests for RefCache |
| `orckit-browser-use/tests/unit/test_hooks.py` | Create | Unit tests for HooksMixin |
| `orckit-browser-use/tests/unit/test_tool_interface.py` | Create | Unit tests for browser_tool dispatch |
| `orckit-browser-use/tests/integration/test_session.py` | Create | Integration tests (real Chrome headless) |
| `orckit-browser-use/README.md` | Create | Quickstart, API ref, profile guide |
| `orckit-browser-use/CHANGELOG.md` | Create | Keep a Changelog format |
| `orckit-browser-use/CONTRIBUTING.md` | Create | Dev setup, PR process |
| `orckit-browser-use/.github/workflows/ci.yml` | Create | lint + test CI |
| `orckit-browser-use/.github/workflows/release.yml` | Create | build + PyPI publish |
| `orckit-browser-use/.github/workflows/codeql.yml` | Create | CodeQL security scan |
| `orckit-browser-use/.github/dependabot.yml` | Create | Dependency auto-updates |
| `orckit-browser-use/.github/ISSUE_TEMPLATE/bug_report.md` | Create | Bug report template |
| `orckit-browser-use/.github/ISSUE_TEMPLATE/feature_request.md` | Create | Feature request template |
| `orckit-browser-use/.github/pull_request_template.md` | Create | PR checklist template |

---

## Task 1: Project Scaffold

**Files:**
- Create: `orckit-browser-use/pyproject.toml`
- Create: `orckit-browser-use/Makefile`
- Create: `orckit-browser-use/.pre-commit-config.yaml`
- Create: `orckit-browser-use/src/orckit_browser/__init__.py`
- Create: `orckit-browser-use/src/orckit_browser/cdp/__init__.py`
- Create: `orckit-browser-use/src/orckit_browser/dom/__init__.py`
- Create: `orckit-browser-use/src/orckit_browser/actions/__init__.py`
- Create: `orckit-browser-use/tests/__init__.py`
- Create: `orckit-browser-use/tests/unit/__init__.py`
- Create: `orckit-browser-use/tests/integration/__init__.py`

- [ ] **Step 1: Initialize uv project**

```bash
cd /workspace
uv init orckit-browser-use --lib --python 3.11
cd orckit-browser-use
```

Expected output: creates `pyproject.toml`, `src/orckit_browser_use/`, `README.md`.

- [ ] **Step 2: Rename package directory to match import name**

```bash
mv src/orckit_browser_use src/orckit_browser
```

- [ ] **Step 3: Write `pyproject.toml`**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "orckit-browser-use"
version = "0.1.0"
description = "AI-friendly browser automation via CDP with profile-based login persistence"
readme = "README.md"
license = { text = "MIT" }
requires-python = ">=3.11"
keywords = ["browser", "automation", "ai", "cdp", "devtools"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
]
dependencies = [
    "websockets>=12.0",
    "pydantic>=2.0",
    "aiohttp>=3.9",
    "mcp>=1.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.23",
    "ruff>=0.4",
    "mypy>=1.9",
    "coverage[toml]>=7.5",
    "pre-commit>=3.7",
]

[tool.hatch.build.targets.wheel]
packages = ["src/orckit_browser"]

[tool.ruff]
line-length = 88

[tool.ruff.lint]
select = ["E", "F", "I", "N", "W"]

[tool.mypy]
strict = true
python_version = "3.11"

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]

[tool.coverage.run]
source = ["orckit_browser"]
```

- [ ] **Step 4: Write `Makefile`**

```makefile
.PHONY: run test lint format build publish mcp clean

run:
	uv run python -m orckit_browser

test:
	uv run pytest tests/ -v --cov=orckit_browser --cov-report=term-missing

lint:
	uv run ruff check src/ tests/
	uv run mypy src/

format:
	uv run ruff format src/ tests/

build:
	uv build

publish:
	uv publish

mcp:
	uv run python -m orckit_browser.mcp_server

clean:
	rm -rf dist/ build/ .coverage htmlcov/ .mypy_cache/ .ruff_cache/ __pycache__
```

- [ ] **Step 5: Write `.pre-commit-config.yaml`**

```yaml
repos:
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.4.4
    hooks:
      - id: ruff
        args: [--fix]
      - id: ruff-format
  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.9.0
    hooks:
      - id: mypy
        additional_dependencies: [pydantic, websockets, aiohttp, types-aiohttp]
```

- [ ] **Step 6: Create all `__init__.py` stubs**

```bash
touch src/orckit_browser/__init__.py
mkdir -p src/orckit_browser/cdp src/orckit_browser/dom src/orckit_browser/actions
touch src/orckit_browser/cdp/__init__.py
touch src/orckit_browser/dom/__init__.py
touch src/orckit_browser/actions/__init__.py
mkdir -p tests/unit tests/integration
touch tests/__init__.py tests/unit/__init__.py tests/integration/__init__.py
```

- [ ] **Step 7: Install dev dependencies**

```bash
uv sync --extra dev
```

Expected: resolves and installs all dependencies.

- [ ] **Step 8: Verify project is importable**

```bash
uv run python -c "import orckit_browser; print('OK')"
```

Expected output: `OK`

- [ ] **Step 9: Commit**

```bash
git init
git add .
git commit -m "chore: initialize project scaffold with uv"
```

---

## Task 2: Pydantic Models

**Files:**
- Create: `src/orckit_browser/models.py`
- Create: `tests/unit/test_models.py`

- [ ] **Step 1: Write failing tests**

Create `tests/unit/test_models.py`:

```python
import pytest
from orckit_browser.models import ActionMetrics, ToolResult, TabInfo


def test_action_metrics_defaults():
    m = ActionMetrics(
        action="click",
        duration_ms=120,
        dom_nodes_scanned=45,
        estimated_tokens=180,
    )
    assert m.screenshot_size_kb == 0


def test_tool_result_success():
    m = ActionMetrics(action="navigate", duration_ms=300, dom_nodes_scanned=0, estimated_tokens=20)
    r = ToolResult(success=True, content="Navigated to https://example.com", metrics=m)
    assert r.error is None
    assert r.success is True


def test_tool_result_failure():
    m = ActionMetrics(action="click", duration_ms=10, dom_nodes_scanned=0, estimated_tokens=0)
    r = ToolResult(success=False, content="", error="Element not found", metrics=m)
    assert r.success is False
    assert r.error == "Element not found"


def test_tool_result_structured_content():
    m = ActionMetrics(action="dom_tree", duration_ms=200, dom_nodes_scanned=120, estimated_tokens=350)
    data = {"url": "https://example.com", "elements": []}
    r = ToolResult(success=True, content=data, metrics=m)
    assert isinstance(r.content, dict)


def test_tab_info():
    t = TabInfo(tab_id="tab_0", url="https://example.com", title="Example", active=True)
    assert t.active is True
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/unit/test_models.py -v
```

Expected: `ImportError` or `ModuleNotFoundError` — models not yet defined.

- [ ] **Step 3: Implement `src/orckit_browser/models.py`**

```python
"""Pydantic models for orckit-browser-use."""

from __future__ import annotations

from typing import Union

from pydantic import BaseModel


class ActionMetrics(BaseModel):
    """Per-action performance and token metrics."""

    action: str
    duration_ms: int
    dom_nodes_scanned: int
    estimated_tokens: int
    screenshot_size_kb: int = 0


class ToolResult(BaseModel):
    """Result returned by every BrowserSession method and browser_tool()."""

    success: bool
    content: Union[str, dict]  # noqa: UP007
    error: str | None = None
    metrics: ActionMetrics


class TabInfo(BaseModel):
    """Information about a browser tab."""

    tab_id: str
    url: str
    title: str
    active: bool
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/unit/test_models.py -v
```

Expected: 5 passed.

- [ ] **Step 5: Commit**

```bash
git add src/orckit_browser/models.py tests/unit/test_models.py
git commit -m "feat: add Pydantic models (ActionMetrics, ToolResult, TabInfo)"
```

---

## Task 3: Profile Management

**Files:**
- Create: `src/orckit_browser/profile.py`
- Create: `tests/unit/test_profile.py`

- [ ] **Step 1: Write failing tests**

Create `tests/unit/test_profile.py`:

```python
import shutil
from pathlib import Path

import pytest

from orckit_browser.profile import Profile, ProfileManager


@pytest.fixture()
def tmp_profiles_dir(tmp_path: Path) -> Path:
    return tmp_path / "profiles"


def test_get_or_create_creates_directory(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    p = pm.get_or_create("work")
    assert p.name == "work"
    assert p.data_dir.exists()
    assert p.data_dir == tmp_profiles_dir / "work"


def test_get_or_create_is_idempotent(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    p1 = pm.get_or_create("work")
    p2 = pm.get_or_create("work")
    assert p1.cdp_port == p2.cdp_port


def test_default_profile_gets_port_9222(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    p = pm.get_or_create("default")
    assert p.cdp_port == 9222


def test_second_profile_gets_incremented_port(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    pm.get_or_create("default")
    p2 = pm.get_or_create("other")
    assert p2.cdp_port == 9223


def test_list_profiles(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    pm.get_or_create("a")
    pm.get_or_create("b")
    names = [p.name for p in pm.list_profiles()]
    assert set(names) == {"a", "b"}


def test_delete_profile(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    pm.get_or_create("temp")
    pm.delete("temp")
    assert not any(p.name == "temp" for p in pm.list_profiles())


def test_delete_nonexistent_profile_is_noop(tmp_profiles_dir: Path) -> None:
    pm = ProfileManager(base_dir=tmp_profiles_dir)
    pm.delete("nonexistent")  # should not raise
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
uv run pytest tests/unit/test_profile.py -v
```

Expected: `ImportError`.

- [ ] **Step 3: Implement `src/orckit_browser/profile.py`**

```python
"""Profile management for browser session persistence."""

from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from pathlib import Path

_DEFAULT_PORT = 9222


@dataclass
class Profile:
    """A named browser profile backed by a Chrome user-data-dir."""

    name: str
    data_dir: Path
    cdp_port: int


class ProfileManager:
    """Creates and tracks browser profiles with stable CDP ports."""

    def __init__(self, base_dir: Path | None = None) -> None:
        if base_dir is None:
            base_dir = Path.home() / ".orckit" / "profiles"
        self._base_dir = base_dir
        self._profiles: dict[str, Profile] = {}

    def get_or_create(self, name: str) -> Profile:
        """Return an existing profile or create a new one."""
        if name in self._profiles:
            return self._profiles[name]
        data_dir = self._base_dir / name
        data_dir.mkdir(parents=True, exist_ok=True)
        port = _DEFAULT_PORT + len(self._profiles)
        profile = Profile(name=name, data_dir=data_dir, cdp_port=port)
        self._profiles[name] = profile
        return profile

    def list_profiles(self) -> list[Profile]:
        """Return all known profiles."""
        return list(self._profiles.values())

    def delete(self, name: str) -> None:
        """Remove a profile and its data directory."""
        if name not in self._profiles:
            return
        profile = self._profiles.pop(name)
        if profile.data_dir.exists():
            shutil.rmtree(profile.data_dir)
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/unit/test_profile.py -v
```

Expected: 8 passed.

- [ ] **Step 5: Commit**

```bash
git add src/orckit_browser/profile.py tests/unit/test_profile.py
git commit -m "feat: add ProfileManager with stable CDP port assignment"
```

---

## Task 4: CDP Client

**Files:**
- Create: `src/orckit_browser/cdp/client.py`

No unit tests here — CDP requires a real WebSocket server. This component is covered by integration tests in Task 12.

- [ ] **Step 1: Implement `src/orckit_browser/cdp/client.py`**

```python
"""Pure asyncio Chrome DevTools Protocol WebSocket client."""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Callable
from typing import Any

import websockets
from websockets.asyncio.client import ClientConnection

logger = logging.getLogger(__name__)

_DEFAULT_TIMEOUT = 30.0


class CDPSessionError(Exception):
    """Raised when a CDP command fails or the session is invalid."""


class CDPClient:
    """
    Manages a single CDP WebSocket connection to one browser page.

    Usage::

        client = CDPClient()
        await client.connect("ws://localhost:9222/devtools/page/ABC")
        result = await client.send("Page.navigate", {"url": "https://example.com"})
        await client.close()
    """

    def __init__(self, timeout: float = _DEFAULT_TIMEOUT) -> None:
        self._timeout = timeout
        self._ws: ClientConnection | None = None
        self._pending: dict[int, asyncio.Future[dict[str, Any]]] = {}
        self._listeners: dict[str, list[Callable[..., Any]]] = {}
        self._recv_task: asyncio.Task[None] | None = None
        self._id = 0

    async def connect(self, ws_url: str) -> None:
        """Connect to a CDP WebSocket endpoint."""
        self._ws = await websockets.connect(ws_url)  # type: ignore[attr-defined]
        self._recv_task = asyncio.create_task(self._recv_loop())
        logger.debug("CDP connected to %s", ws_url)

    async def send(self, method: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """Send a CDP command and await its response."""
        if self._ws is None:
            raise CDPSessionError("Not connected")
        self._id += 1
        msg_id = self._id
        payload = json.dumps({"id": msg_id, "method": method, "params": params or {}})
        future: asyncio.Future[dict[str, Any]] = asyncio.get_event_loop().create_future()
        self._pending[msg_id] = future
        await self._ws.send(payload)
        try:
            result = await asyncio.wait_for(future, timeout=self._timeout)
        except asyncio.TimeoutError as exc:
            self._pending.pop(msg_id, None)
            raise CDPSessionError(f"Timeout waiting for response to {method}") from exc
        if "error" in result:
            raise CDPSessionError(f"CDP error for {method}: {result['error']}")
        return result.get("result", {})

    async def enable_domain(self, domain: str) -> None:
        """Enable a CDP domain (e.g. 'DOM', 'Page', 'Input')."""
        await self.send(f"{domain}.enable")

    def on(self, event: str, callback: Callable[..., Any]) -> None:
        """Register a listener for a CDP event."""
        self._listeners.setdefault(event, []).append(callback)

    def off(self, event: str, callback: Callable[..., Any]) -> None:
        """Unregister a listener."""
        listeners = self._listeners.get(event, [])
        if callback in listeners:
            listeners.remove(callback)

    async def close(self) -> None:
        """Close the WebSocket connection."""
        if self._recv_task:
            self._recv_task.cancel()
            try:
                await self._recv_task
            except asyncio.CancelledError:
                pass
        if self._ws:
            await self._ws.close()
            self._ws = None
        logger.debug("CDP connection closed")

    async def _recv_loop(self) -> None:
        """Background task: read messages and dispatch to pending futures or listeners."""
        assert self._ws is not None
        try:
            async for raw in self._ws:
                msg: dict[str, Any] = json.loads(raw)
                if "id" in msg:
                    future = self._pending.pop(msg["id"], None)
                    if future and not future.done():
                        future.set_result(msg)
                elif "method" in msg:
                    method: str = msg["method"]
                    params: dict[str, Any] = msg.get("params", {})
                    for cb in self._listeners.get(method, []):
                        result = cb(params)
                        if asyncio.iscoroutine(result):
                            asyncio.create_task(result)
        except Exception as exc:  # noqa: BLE001
            logger.debug("CDP recv loop ended: %s", exc)
            for future in self._pending.values():
                if not future.done():
                    future.set_exception(CDPSessionError(f"Connection lost: {exc}"))
            self._pending.clear()
```

- [ ] **Step 2: Verify it imports cleanly**

```bash
uv run python -c "from orckit_browser.cdp.client import CDPClient; print('OK')"
```

Expected output: `OK`

- [ ] **Step 3: Commit**

```bash
git add src/orckit_browser/cdp/client.py
git commit -m "feat: add CDPClient — pure asyncio WebSocket CDP"
```

---

## Task 5: Chrome Launcher

**Files:**
- Create: `src/orckit_browser/cdp/launcher.py`

- [ ] **Step 1: Implement `src/orckit_browser/cdp/launcher.py`**

```python
"""Chrome process management: launch, attach, and discover."""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path

import aiohttp

from orckit_browser.profile import Profile

logger = logging.getLogger(__name__)

_CHROME_PATHS_LINUX = [
    "/usr/bin/google-chrome",
    "/usr/bin/google-chrome-stable",
    "/usr/bin/chromium-browser",
    "/usr/bin/chromium",
    "/snap/bin/chromium",
]

_CHROME_PATHS_MAC = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
]


def find_chrome() -> str | None:
    """Return the path to the first available Chrome/Chromium executable."""
    if sys.platform == "darwin":
        candidates = _CHROME_PATHS_MAC
    else:
        candidates = _CHROME_PATHS_LINUX
    for path in candidates:
        if Path(path).exists():
            return path
    # Also try PATH
    return shutil.which("google-chrome") or shutil.which("chromium") or shutil.which("chromium-browser")


def _build_flags(profile: Profile, headless: bool) -> list[str]:
    flags = [
        f"--remote-debugging-port={profile.cdp_port}",
        f"--user-data-dir={profile.data_dir}",
        "--disable-background-networking",
        "--disable-sync",
        "--disable-translate",
        "--disable-extensions",
        "--disable-default-apps",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-popup-blocking",
        "--metrics-recording-only",
        "--safebrowsing-disable-auto-update",
    ]
    if headless:
        flags.append("--headless=new")
    if os.getuid() == 0:  # running as root
        flags.append("--no-sandbox")
    return flags


async def _get_ws_url(port: int, retries: int = 20, delay: float = 0.25) -> str:
    """Poll Chrome's /json/version endpoint until it responds."""
    url = f"http://localhost:{port}/json/version"
    for attempt in range(retries):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=2)) as resp:
                    data = await resp.json(content_type=None)
                    ws_url: str = data["webSocketDebuggerUrl"]
                    logger.debug("Chrome ready at %s", ws_url)
                    return ws_url
        except Exception:  # noqa: BLE001
            if attempt < retries - 1:
                await asyncio.sleep(delay)
    raise RuntimeError(f"Chrome did not start on port {port} after {retries} attempts")


async def _port_in_use(port: int) -> bool:
    """Check if Chrome is already listening on the given port."""
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"http://localhost:{port}/json/version",
                timeout=aiohttp.ClientTimeout(total=1),
            ) as resp:
                return resp.status == 200
    except Exception:  # noqa: BLE001
        return False


async def launch_or_attach(profile: Profile, headless: bool = False) -> str:
    """
    Ensure Chrome is running for this profile and return a CDP WebSocket URL.

    If Chrome is already running on the profile's CDP port, re-attach.
    Otherwise, launch a new Chrome process.

    Returns the browser-level WebSocket URL (used for Target operations).
    """
    if await _port_in_use(profile.cdp_port):
        logger.debug("Attaching to existing Chrome on port %d", profile.cdp_port)
        return await _get_ws_url(profile.cdp_port)

    chrome = find_chrome()
    if chrome is None:
        raise RuntimeError(
            "Chrome/Chromium not found. Install Google Chrome or Chromium.\n"
            "On Ubuntu: sudo apt install chromium-browser\n"
            "On macOS: brew install --cask google-chrome"
        )

    flags = _build_flags(profile, headless=headless)
    cmd = [chrome, *flags, "about:blank"]
    logger.debug("Launching Chrome: %s", " ".join(cmd))
    subprocess.Popen(  # noqa: S603
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return await _get_ws_url(profile.cdp_port)


async def get_page_ws_url(port: int) -> str:
    """Return the WebSocket URL of the first open page/tab."""
    url = f"http://localhost:{port}/json"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
            targets = await resp.json(content_type=None)
    for target in targets:
        if target.get("type") == "page":
            return str(target["webSocketDebuggerUrl"])
    raise RuntimeError("No open page found in Chrome")
```

- [ ] **Step 2: Verify import**

```bash
uv run python -c "from orckit_browser.cdp.launcher import find_chrome; print(find_chrome() or 'not found')"
```

Expected: prints a Chrome path (or `not found` if Chrome isn't installed — that's fine).

- [ ] **Step 3: Commit**

```bash
git add src/orckit_browser/cdp/launcher.py
git commit -m "feat: add Chrome launcher with attach/launch support"
```

---

## Task 6: Ref Cache

**Files:**
- Create: `src/orckit_browser/dom/refs.py`
- Create: `tests/unit/test_refs.py`

- [ ] **Step 1: Write failing tests**

Create `tests/unit/test_refs.py`:

```python
import pytest
from orckit_browser.dom.refs import RefCache


def test_store_and_lookup():
    cache = RefCache()
    cache.store("btn_1", node_id=42)
    assert cache.lookup("btn_1") == 42


def test_lookup_missing_returns_none():
    cache = RefCache()
    assert cache.lookup("nonexistent") is None


def test_invalidate_clears_all():
    cache = RefCache()
    cache.store("btn_1", node_id=42)
    cache.store("inp_2", node_id=99)
    cache.invalidate()
    assert cache.lookup("btn_1") is None
    assert cache.lookup("inp_2") is None


def test_store_overwrites():
    cache = RefCache()
    cache.store("btn_1", node_id=42)
    cache.store("btn_1", node_id=100)
    assert cache.lookup("btn_1") == 100


def test_all_refs():
    cache = RefCache()
    cache.store("btn_1", node_id=1)
    cache.store("inp_2", node_id=2)
    refs = cache.all_refs()
    assert refs == {"btn_1": 1, "inp_2": 2}
```

- [ ] **Step 2: Run to verify failure**

```bash
uv run pytest tests/unit/test_refs.py -v
```

Expected: `ImportError`.

- [ ] **Step 3: Implement `src/orckit_browser/dom/refs.py`**

```python
"""Ref-to-node_id cache for the DOM builder."""

from __future__ import annotations


class RefCache:
    """Maps short ref strings (e.g. 'btn_1') to CDP node IDs.

    The cache is invalidated after any cross-document navigation.
    """

    def __init__(self) -> None:
        self._refs: dict[str, int] = {}

    def store(self, ref: str, node_id: int) -> None:
        """Register a ref → node_id mapping."""
        self._refs[ref] = node_id

    def lookup(self, ref: str) -> int | None:
        """Return the node_id for a ref, or None if not found."""
        return self._refs.get(ref)

    def invalidate(self) -> None:
        """Clear all refs (called after navigation)."""
        self._refs.clear()

    def all_refs(self) -> dict[str, int]:
        """Return a copy of all current mappings."""
        return dict(self._refs)
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/unit/test_refs.py -v
```

Expected: 5 passed.

- [ ] **Step 5: Commit**

```bash
git add src/orckit_browser/dom/refs.py tests/unit/test_refs.py
git commit -m "feat: add RefCache for DOM ref→node_id mapping"
```

---

## Task 7: DOM Builder

**Files:**
- Create: `src/orckit_browser/dom/builder.py`
- Create: `tests/unit/test_dom_builder.py`

The builder takes a raw CDP `DOM.getDocument` node tree (as a dict) and produces the tiered output. In unit tests we construct synthetic node trees.

- [ ] **Step 1: Write failing tests**

Create `tests/unit/test_dom_builder.py`:

```python
import json
import pytest
from orckit_browser.dom.builder import DOMBuilder
from orckit_browser.dom.refs import RefCache

# Minimal synthetic CDP DOM tree
SAMPLE_DOM = {
    "nodeId": 1,
    "nodeType": 9,
    "nodeName": "#document",
    "children": [
        {
            "nodeId": 2,
            "nodeType": 1,
            "nodeName": "HTML",
            "children": [
                {
                    "nodeId": 3,
                    "nodeType": 1,
                    "nodeName": "BODY",
                    "children": [
                        {
                            "nodeId": 10,
                            "nodeType": 1,
                            "nodeName": "H1",
                            "children": [{"nodeId": 11, "nodeType": 3, "nodeName": "#text", "nodeValue": "Login"}],
                            "attributes": [],
                        },
                        {
                            "nodeId": 20,
                            "nodeType": 1,
                            "nodeName": "INPUT",
                            "children": [],
                            "attributes": ["type", "text", "placeholder", "Username"],
                        },
                        {
                            "nodeId": 30,
                            "nodeType": 1,
                            "nodeName": "BUTTON",
                            "children": [{"nodeId": 31, "nodeType": 3, "nodeName": "#text", "nodeValue": "Sign in"}],
                            "attributes": [],
                        },
                        {
                            "nodeId": 40,
                            "nodeType": 1,
                            "nodeName": "A",
                            "children": [{"nodeId": 41, "nodeType": 3, "nodeName": "#text", "nodeValue": "Forgot?"}],
                            "attributes": ["href", "/forgot"],
                        },
                    ],
                    "attributes": [],
                }
            ],
            "attributes": [],
        }
    ],
}


def make_builder():
    cache = RefCache()
    return DOMBuilder(
        dom=SAMPLE_DOM,
        url="https://example.com/login",
        title="Login Page",
        ref_cache=cache,
    ), cache


def test_minimal_output():
    builder, _ = make_builder()
    out = builder.build(level="minimal")
    assert "https://example.com/login" in out
    assert "Login Page" in out
    assert "Interactive elements:" in out


def test_interactive_output_has_refs():
    builder, cache = make_builder()
    out = builder.build(level="interactive")
    assert "[ref=" in out
    assert "input" in out.lower() or "button" in out.lower()
    # refs should be populated in cache
    assert len(cache.all_refs()) > 0


def test_full_output_has_h1():
    builder, _ = make_builder()
    out = builder.build(level="full")
    assert "H1" in out.upper() or "h1" in out


def test_structured_output_is_valid_json():
    builder, _ = make_builder()
    result = builder.build(level="structured")
    data = json.loads(result)
    assert data["url"] == "https://example.com/login"
    assert isinstance(data["elements"], list)
    assert any(e["tag"].lower() == "button" for e in data["elements"])


def test_interactive_refs_stored_in_cache():
    builder, cache = make_builder()
    builder.build(level="interactive")
    refs = cache.all_refs()
    # Button and input should be in cache
    node_ids = set(refs.values())
    assert 20 in node_ids  # input
    assert 30 in node_ids  # button
```

- [ ] **Step 2: Run to verify failure**

```bash
uv run pytest tests/unit/test_dom_builder.py -v
```

Expected: `ImportError`.

- [ ] **Step 3: Implement `src/orckit_browser/dom/builder.py`**

```python
"""Tiered DOM output builder for AI-friendly page state representation."""

from __future__ import annotations

import json
from typing import Any, Literal

from orckit_browser.dom.refs import RefCache

DOMLevel = Literal["minimal", "interactive", "full", "structured"]

_INTERACTIVE_TAGS = frozenset(
    ["button", "input", "select", "textarea", "a", "label", "form"]
)
_STRUCTURAL_TAGS = frozenset(
    ["header", "nav", "main", "footer", "section", "article",
     "h1", "h2", "h3", "h4", "h5", "h6", "p", "table"]
)
_INTERACTIVE_ROLES = frozenset(
    ["button", "link", "textbox", "combobox", "checkbox", "radio", "menuitem",
     "option", "switch", "tab", "searchbox"]
)
_SKIP_TAGS = frozenset(
    ["script", "style", "meta", "link", "noscript", "svg", "path",
     "head", "html", "#document"]
)
_REF_COUNTER: dict[str, int] = {}


def _attrs_to_dict(attrs: list[str]) -> dict[str, str]:
    """Convert CDP flat attributes list ['key','val',...] to dict."""
    return dict(zip(attrs[::2], attrs[1::2])) if attrs else {}


def _node_text(node: dict[str, Any]) -> str:
    """Return the direct text content of a node (first text child only)."""
    for child in node.get("children", []):
        if child.get("nodeName") == "#text":
            return child.get("nodeValue", "").strip()
    return ""


def _make_ref(tag: str, counter: dict[str, int]) -> str:
    prefix = {"input": "inp", "button": "btn", "a": "lnk",
               "select": "sel", "textarea": "txt"}.get(tag, tag[:3])
    idx = counter.get(prefix, 0)
    counter[prefix] = idx + 1
    return f"{prefix}_{idx}"


class DOMBuilder:
    """
    Converts a raw CDP DOM tree into one of four output levels.

    Args:
        dom: The CDP ``DOM.getDocument`` root node dict.
        url: Current page URL.
        title: Current page title.
        ref_cache: A ``RefCache`` instance to populate with ref→node_id mappings.
    """

    def __init__(
        self,
        dom: dict[str, Any],
        url: str,
        title: str,
        ref_cache: RefCache,
    ) -> None:
        self._dom = dom
        self._url = url
        self._title = title
        self._ref_cache = ref_cache

    def build(self, level: DOMLevel = "interactive") -> str:
        """Build and return the DOM representation at the requested level."""
        ref_counter: dict[str, int] = {}
        interactive: list[dict[str, Any]] = []
        structural: list[str] = []

        self._walk(self._dom, interactive, structural, ref_counter, depth=0)

        if level == "minimal":
            return self._build_minimal(len(interactive))
        if level == "interactive":
            return self._build_interactive(interactive)
        if level == "full":
            return self._build_full(interactive, structural)
        if level == "structured":
            return self._build_structured(interactive)
        raise ValueError(f"Unknown DOM level: {level!r}")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _walk(
        self,
        node: dict[str, Any],
        interactive: list[dict[str, Any]],
        structural: list[str],
        counter: dict[str, int],
        depth: int,
    ) -> None:
        tag = node.get("nodeName", "").lower()
        if tag in _SKIP_TAGS or tag.startswith("#"):
            # Still recurse into #document children
            if tag not in ("#text", "#comment"):
                for child in node.get("children", []):
                    self._walk(child, interactive, structural, counter, depth)
            return

        attrs = _attrs_to_dict(node.get("attributes", []))
        role = attrs.get("role", "")
        aria_label = attrs.get("aria-label", "")
        is_interactive = (
            tag in _INTERACTIVE_TAGS or role in _INTERACTIVE_ROLES
        )
        # Anchor must have href to count as interactive
        if tag == "a" and not attrs.get("href"):
            is_interactive = False

        if is_interactive:
            ref = _make_ref(tag, counter)
            self._ref_cache.store(ref, node["nodeId"])
            interactive.append({
                "ref": ref,
                "tag": tag,
                "type": attrs.get("type", ""),
                "role": role or tag,
                "label": aria_label or attrs.get("label", ""),
                "placeholder": attrs.get("placeholder", ""),
                "text": _node_text(node),
                "href": attrs.get("href", ""),
                "node_id": node["nodeId"],
                "attrs": attrs,
                "depth": depth,
            })
        elif tag in _STRUCTURAL_TAGS:
            text = _node_text(node)
            indent = "  " * depth
            structural.append(f"{indent}<{tag}>{(' ' + text) if text else ''}")

        for child in node.get("children", []):
            self._walk(child, interactive, structural, counter, depth + 1)

    def _build_minimal(self, interactive_count: int) -> str:
        return (
            f'Page: {self._url} | "{self._title}"\n'
            f"Interactive elements: {interactive_count} | Scroll: yes"
        )

    def _build_interactive(self, interactive: list[dict[str, Any]]) -> str:
        lines = [f'Page: {self._url} | "{self._title}"',
                 f"Interactive elements ({len(interactive)}):"]
        for el in interactive:
            tag = el["tag"]
            ref = el["ref"]
            if tag == "input":
                type_part = f"[{el['type'] or 'text'}]"
                label_part = ""
                if el["placeholder"]:
                    label_part = f' placeholder="{el["placeholder"]}"'
                elif el["label"]:
                    label_part = f' label="{el["label"]}"'
                lines.append(f'  [ref={ref}] input{type_part}{label_part}')
            elif tag == "button":
                text = el["text"] or el["label"] or ""
                lines.append(f'  [ref={ref}] button "{text}"')
            elif tag == "a":
                text = el["text"] or el["label"] or el["href"]
                lines.append(f'  [ref={ref}] a "{text}"')
            elif tag == "select":
                label = el["label"] or el["placeholder"] or ""
                lines.append(f'  [ref={ref}] select "{label}"')
            elif tag == "textarea":
                placeholder = el["placeholder"] or ""
                lines.append(f'  [ref={ref}] textarea placeholder="{placeholder}"')
            else:
                label = el["text"] or el["label"] or ""
                lines.append(f'  [ref={ref}] {tag} "{label}"')
        return "\n".join(lines)

    def _build_full(
        self, interactive: list[dict[str, Any]], structural: list[str]
    ) -> str:
        parts = [f'Page: {self._url} | "{self._title}"\n']
        # Structural elements
        if structural:
            parts.extend(structural)
            parts.append("")
        # Interactive elements (same format as interactive level)
        if interactive:
            parts.append(f"Interactive elements ({len(interactive)}):")
            for el in interactive:
                ref = el["ref"]
                tag = el["tag"]
                attrs_str = ""
                if el["type"]:
                    attrs_str += f" type={el['type']}"
                if el["placeholder"]:
                    attrs_str += f' placeholder="{el["placeholder"]}"'
                text = el["text"] or el["label"]
                text_str = f" {text}" if text else ""
                parts.append(f"  <{tag} ref={ref}{attrs_str}>{text_str}")
        return "\n".join(parts)

    def _build_structured(self, interactive: list[dict[str, Any]]) -> str:
        elements = []
        for el in interactive:
            entry: dict[str, Any] = {
                "ref": el["ref"],
                "tag": el["tag"],
                "role": el["role"],
                "node_id": el["node_id"],
            }
            if el["type"]:
                entry["type"] = el["type"]
            if el["label"]:
                entry["label"] = el["label"]
            if el["placeholder"]:
                entry["placeholder"] = el["placeholder"]
            if el["text"]:
                entry["text"] = el["text"]
            if el["href"]:
                entry["href"] = el["href"]
            elements.append(entry)
        data = {
            "url": self._url,
            "title": self._title,
            "elements": elements,
        }
        return json.dumps(data, indent=2, ensure_ascii=False)
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/unit/test_dom_builder.py -v
```

Expected: 5 passed.

- [ ] **Step 5: Commit**

```bash
git add src/orckit_browser/dom/builder.py tests/unit/test_dom_builder.py
git commit -m "feat: add DOMBuilder with 4-level tiered output"
```

---

## Task 8: Hook System

**Files:**
- Create: `src/orckit_browser/hooks.py`
- Create: `tests/unit/test_hooks.py`

- [ ] **Step 1: Write failing tests**

Create `tests/unit/test_hooks.py`:

```python
import asyncio
import pytest
from orckit_browser.hooks import HooksMixin
from orckit_browser.models import ActionMetrics


class FakeSession(HooksMixin):
    pass


@pytest.fixture()
def sess():
    return FakeSession()


def make_metrics(action: str = "click") -> ActionMetrics:
    return ActionMetrics(action=action, duration_ms=50, dom_nodes_scanned=10, estimated_tokens=30)


async def test_before_action_fires(sess):
    events = []

    @sess.on("before_action")
    async def handler(event):
        events.append(event)

    await sess._fire("before_action", {"action": "click", "params": {}})
    assert len(events) == 1


async def test_after_action_fires(sess):
    events = []

    @sess.on("after_action")
    async def handler(event):
        events.append(event.action)

    m = make_metrics()
    await sess._fire("after_action", m)
    assert events == ["click"]


async def test_multiple_handlers_all_fire(sess):
    count = []

    @sess.on("before_action")
    async def h1(e): count.append(1)

    @sess.on("before_action")
    async def h2(e): count.append(2)

    await sess._fire("before_action", {})
    assert count == [1, 2]


async def test_unregistered_event_is_noop(sess):
    # firing an event with no handlers should not raise
    await sess._fire("page_navigated", {})


async def test_decorator_returns_callback(sess):
    @sess.on("before_action")
    async def handler(e): ...
    assert callable(handler)
```

- [ ] **Step 2: Run to verify failure**

```bash
uv run pytest tests/unit/test_hooks.py -v
```

Expected: `ImportError`.

- [ ] **Step 3: Implement `src/orckit_browser/hooks.py`**

```python
"""Hook system for BrowserSession event callbacks."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable, Coroutine
from typing import Any, TypeVar

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Coroutine[Any, Any, None]])

_VALID_EVENTS = frozenset(
    ["before_action", "after_action", "action_error", "page_navigated"]
)


class HooksMixin:
    """Mixin that adds event hook registration and firing to a class."""

    def __init__(self) -> None:
        self._hooks: dict[str, list[Callable[..., Any]]] = {
            event: [] for event in _VALID_EVENTS
        }

    def on(self, event: str) -> Callable[[F], F]:
        """Decorator to register an async callback for an event.

        Valid events: ``before_action``, ``after_action``,
        ``action_error``, ``page_navigated``.
        """
        if event not in _VALID_EVENTS:
            raise ValueError(f"Unknown event {event!r}. Valid: {sorted(_VALID_EVENTS)}")

        def decorator(fn: F) -> F:
            self._hooks[event].append(fn)
            return fn

        return decorator

    async def _fire(self, event: str, payload: Any) -> None:
        """Fire all registered callbacks for an event."""
        for callback in self._hooks.get(event, []):
            try:
                result = callback(payload)
                if asyncio.iscoroutine(result):
                    await result
            except Exception:  # noqa: BLE001
                logger.exception("Hook callback raised for event %r", event)
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
uv run pytest tests/unit/test_hooks.py -v
```

Expected: 5 passed.

- [ ] **Step 5: Commit**

```bash
git add src/orckit_browser/hooks.py tests/unit/test_hooks.py
git commit -m "feat: add HooksMixin for before/after action event hooks"
```

---

## Task 9: Action Modules

**Files:**
- Create: `src/orckit_browser/actions/navigate.py`
- Create: `src/orckit_browser/actions/interact.py`
- Create: `src/orckit_browser/actions/capture.py`
- Create: `src/orckit_browser/actions/js_eval.py`

These modules contain pure functions that take a `CDPClient` + `RefCache` and return a `ToolResult`. They are tested indirectly via integration tests.

- [ ] **Step 1: Implement `src/orckit_browser/actions/navigate.py`**

```python
"""Navigation actions: navigate, go_back, go_forward, reload."""

from __future__ import annotations

import time
from typing import Any

from orckit_browser.cdp.client import CDPClient
from orckit_browser.dom.refs import RefCache
from orckit_browser.models import ActionMetrics, ToolResult


def _metrics(action: str, start: float) -> ActionMetrics:
    return ActionMetrics(
        action=action,
        duration_ms=int((time.monotonic() - start) * 1000),
        dom_nodes_scanned=0,
        estimated_tokens=20,
    )


async def navigate(client: CDPClient, ref_cache: RefCache, url: str) -> ToolResult:
    """Navigate the page to a URL and wait for load."""
    start = time.monotonic()
    ref_cache.invalidate()
    result = await client.send("Page.navigate", {"url": url})
    # Wait for load event
    import asyncio
    load_event: asyncio.Future[None] = asyncio.get_event_loop().create_future()

    def on_load(_params: dict[str, Any]) -> None:
        if not load_event.done():
            load_event.set_result(None)

    client.on("Page.loadEventFired", on_load)
    try:
        await asyncio.wait_for(load_event, timeout=30.0)
    except asyncio.TimeoutError:
        pass
    finally:
        client.off("Page.loadEventFired", on_load)

    frame_url = result.get("frameId", url)
    content = f"Navigated to {url}"
    return ToolResult(success=True, content=content, metrics=_metrics("navigate", start))


async def go_back(client: CDPClient, ref_cache: RefCache) -> ToolResult:
    """Navigate back in browser history."""
    start = time.monotonic()
    ref_cache.invalidate()
    await client.send("Runtime.evaluate", {"expression": "history.back()"})
    return ToolResult(success=True, content="Navigated back", metrics=_metrics("go_back", start))


async def go_forward(client: CDPClient, ref_cache: RefCache) -> ToolResult:
    """Navigate forward in browser history."""
    start = time.monotonic()
    ref_cache.invalidate()
    await client.send("Runtime.evaluate", {"expression": "history.forward()"})
    return ToolResult(success=True, content="Navigated forward", metrics=_metrics("go_forward", start))


async def reload(client: CDPClient, ref_cache: RefCache) -> ToolResult:
    """Reload the current page."""
    start = time.monotonic()
    ref_cache.invalidate()
    await client.send("Page.reload", {"ignoreCache": False})
    return ToolResult(success=True, content="Page reloaded", metrics=_metrics("reload", start))
```

- [ ] **Step 2: Implement `src/orckit_browser/actions/interact.py`**

```python
"""Interaction actions: click, type_text, scroll, hover."""

from __future__ import annotations

import time

from orckit_browser.cdp.client import CDPClient, CDPSessionError
from orckit_browser.dom.refs import RefCache
from orckit_browser.models import ActionMetrics, ToolResult


def _metrics(action: str, start: float) -> ActionMetrics:
    return ActionMetrics(
        action=action,
        duration_ms=int((time.monotonic() - start) * 1000),
        dom_nodes_scanned=1,
        estimated_tokens=10,
    )


async def _get_center(client: CDPClient, node_id: int) -> tuple[float, float]:
    """Get the center coordinates of a DOM node."""
    box = await client.send("DOM.getBoxModel", {"nodeId": node_id})
    model = box.get("model", {})
    content = model.get("content", [0, 0, 0, 0, 0, 0, 0, 0])
    # content is [x0,y0, x1,y1, x2,y2, x3,y3] (clockwise from top-left)
    cx = (content[0] + content[4]) / 2
    cy = (content[1] + content[5]) / 2
    return cx, cy


async def _resolve_coords(
    client: CDPClient,
    ref_cache: RefCache,
    ref: str | None,
    selector: str | None,
    x: int | None,
    y: int | None,
) -> tuple[float, float, str]:
    """Resolve click target to (x, y, description)."""
    if ref is not None:
        node_id = ref_cache.lookup(ref)
        if node_id is None:
            raise CDPSessionError(f"Ref '{ref}' not found. Call dom_tree() first.")
        cx, cy = await _get_center(client, node_id)
        return cx, cy, f"ref={ref}"
    if selector is not None:
        doc = await client.send("DOM.getDocument", {"depth": 0})
        root_id = doc["root"]["nodeId"]
        result = await client.send("DOM.querySelector", {"nodeId": root_id, "selector": selector})
        node_id = result.get("nodeId", 0)
        if not node_id:
            raise CDPSessionError(f"Selector '{selector}' matched no elements.")
        cx, cy = await _get_center(client, node_id)
        return cx, cy, f"selector={selector}"
    if x is not None and y is not None:
        return float(x), float(y), f"({x}, {y})"
    raise ValueError("Must provide ref, selector, or (x, y)")


async def click(
    client: CDPClient,
    ref_cache: RefCache,
    ref: str | None = None,
    selector: str | None = None,
    x: int | None = None,
    y: int | None = None,
) -> ToolResult:
    """Click an element identified by ref, selector, or coordinates."""
    start = time.monotonic()
    cx, cy, desc = await _resolve_coords(client, ref_cache, ref, selector, x, y)
    for event_type in ("mousePressed", "mouseReleased"):
        await client.send("Input.dispatchMouseEvent", {
            "type": event_type,
            "x": cx,
            "y": cy,
            "button": "left",
            "clickCount": 1,
        })
    return ToolResult(
        success=True,
        content=f"Clicked {desc} at ({cx:.0f}, {cy:.0f})",
        metrics=_metrics("click", start),
    )


async def type_text(
    client: CDPClient,
    ref_cache: RefCache,
    text: str,
    ref: str | None = None,
) -> ToolResult:
    """Type text, optionally clicking a target element first."""
    start = time.monotonic()
    if ref is not None:
        await click(client, ref_cache, ref=ref)
    for char in text:
        await client.send("Input.dispatchKeyEvent", {"type": "char", "text": char})
    return ToolResult(
        success=True,
        content=f"Typed {len(text)} character(s)",
        metrics=_metrics("type", start),
    )


async def scroll(
    client: CDPClient,
    ref_cache: RefCache,
    direction: str = "down",
    amount: int = 300,
) -> ToolResult:
    """Scroll the page in a direction by pixel amount."""
    start = time.monotonic()
    delta_y = amount if direction == "down" else -amount
    delta_x = amount if direction == "right" else (-amount if direction == "left" else 0)
    await client.send("Input.dispatchMouseEvent", {
        "type": "mouseWheel",
        "x": 400,
        "y": 300,
        "deltaX": delta_x,
        "deltaY": delta_y,
    })
    return ToolResult(
        success=True,
        content=f"Scrolled {direction} by {amount}px",
        metrics=_metrics("scroll", start),
    )


async def hover(
    client: CDPClient,
    ref_cache: RefCache,
    ref: str,
) -> ToolResult:
    """Move the mouse over an element."""
    start = time.monotonic()
    node_id = ref_cache.lookup(ref)
    if node_id is None:
        raise CDPSessionError(f"Ref '{ref}' not found. Call dom_tree() first.")
    cx, cy = await _get_center(client, node_id)
    await client.send("Input.dispatchMouseEvent", {
        "type": "mouseMoved",
        "x": cx,
        "y": cy,
    })
    return ToolResult(
        success=True,
        content=f"Hovered over ref={ref} at ({cx:.0f}, {cy:.0f})",
        metrics=_metrics("hover", start),
    )
```

- [ ] **Step 3: Implement `src/orckit_browser/actions/capture.py`**

```python
"""Screenshot capture action."""

from __future__ import annotations

import base64
import time

from orckit_browser.cdp.client import CDPClient, CDPSessionError
from orckit_browser.dom.refs import RefCache
from orckit_browser.models import ActionMetrics, ToolResult


async def screenshot(
    client: CDPClient,
    ref_cache: RefCache,
    crop: bool = False,
    element_ref: str | None = None,
) -> ToolResult:
    """
    Capture a screenshot.

    Args:
        crop: If True, crop to the visible content area.
        element_ref: If set, crop to the bounding box of this element ref.

    Returns:
        ToolResult with content as base64-encoded PNG string.
    """
    start = time.monotonic()
    params: dict = {"format": "png"}

    if element_ref is not None:
        node_id = ref_cache.lookup(element_ref)
        if node_id is None:
            raise CDPSessionError(f"Ref '{element_ref}' not found. Call dom_tree() first.")
        box = await client.send("DOM.getBoxModel", {"nodeId": node_id})
        model = box.get("model", {})
        content = model.get("content", [0, 0, 100, 0, 100, 100, 0, 100])
        x = min(content[0::2])
        y = min(content[1::2])
        width = max(content[0::2]) - x
        height = max(content[1::2]) - y
        params["clip"] = {
            "x": x, "y": y, "width": width, "height": height, "scale": 1
        }

    result = await client.send("Page.captureScreenshot", params)
    data: str = result.get("data", "")
    size_kb = int(len(base64.b64decode(data)) / 1024)

    return ToolResult(
        success=True,
        content=data,  # base64 PNG
        metrics=ActionMetrics(
            action="screenshot",
            duration_ms=int((time.monotonic() - start) * 1000),
            dom_nodes_scanned=0,
            estimated_tokens=0,
            screenshot_size_kb=size_kb,
        ),
    )
```

- [ ] **Step 4: Implement `src/orckit_browser/actions/js_eval.py`**

```python
"""JavaScript evaluation action."""

from __future__ import annotations

import json
import time

from orckit_browser.cdp.client import CDPClient
from orckit_browser.models import ActionMetrics, ToolResult


async def eval_js(client: CDPClient, expression: str) -> ToolResult:
    """
    Execute a JavaScript expression in the page context.

    Returns the serialized result as a JSON string in content.
    """
    start = time.monotonic()
    result = await client.send("Runtime.evaluate", {
        "expression": expression,
        "returnByValue": True,
        "awaitPromise": True,
    })
    value = result.get("result", {})
    if value.get("subtype") == "error":
        description = value.get("description", "Unknown JS error")
        return ToolResult(
            success=False,
            content="",
            error=description,
            metrics=ActionMetrics(
                action="eval_js",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=0,
            ),
        )
    raw = value.get("value")
    content: str | dict
    if isinstance(raw, (dict, list)):
        content = raw
    else:
        content = json.dumps(raw, ensure_ascii=False) if raw is not None else "null"
    tokens = len(str(content)) // 4
    return ToolResult(
        success=True,
        content=content,
        metrics=ActionMetrics(
            action="eval_js",
            duration_ms=int((time.monotonic() - start) * 1000),
            dom_nodes_scanned=0,
            estimated_tokens=tokens,
        ),
    )
```

- [ ] **Step 5: Verify all action modules import cleanly**

```bash
uv run python -c "
from orckit_browser.actions.navigate import navigate
from orckit_browser.actions.interact import click, type_text, scroll, hover
from orckit_browser.actions.capture import screenshot
from orckit_browser.actions.js_eval import eval_js
print('OK')
"
```

Expected output: `OK`

- [ ] **Step 6: Commit**

```bash
git add src/orckit_browser/actions/
git commit -m "feat: add navigate, interact, capture, js_eval action modules"
```

---

## Task 10: BrowserSession

**Files:**
- Create: `src/orckit_browser/session.py`
- Modify: `src/orckit_browser/__init__.py`

- [ ] **Step 1: Implement `src/orckit_browser/session.py`**

```python
"""BrowserSession: the primary user-facing API."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Literal

from orckit_browser.actions import capture, js_eval, navigate as nav_actions, interact
from orckit_browser.cdp.client import CDPClient, CDPSessionError
from orckit_browser.cdp.launcher import get_page_ws_url, launch_or_attach
from orckit_browser.dom.builder import DOMBuilder, DOMLevel
from orckit_browser.dom.refs import RefCache
from orckit_browser.hooks import HooksMixin
from orckit_browser.models import ActionMetrics, TabInfo, ToolResult
from orckit_browser.profile import Profile, ProfileManager

logger = logging.getLogger(__name__)

_default_profile_manager = ProfileManager()


class _InternalCDPSession:
    """Low-level CDP session: owns a CDPClient and RefCache for one page."""

    def __init__(self, profile: Profile) -> None:
        self._profile = profile
        self._client = CDPClient()
        self._ref_cache = RefCache()
        self._connected = False

    async def connect(self, headless: bool = False) -> None:
        """Launch/attach Chrome and connect CDP to the active page."""
        await launch_or_attach(self._profile, headless=headless)
        ws_url = await get_page_ws_url(self._profile.cdp_port)
        await self._client.connect(ws_url)
        await self._client.enable_domain("Page")
        await self._client.enable_domain("DOM")
        await self._client.enable_domain("Runtime")
        await self._client.enable_domain("Input")
        self._connected = True

    async def close(self) -> None:
        await self._client.close()
        self._connected = False

    @property
    def client(self) -> CDPClient:
        return self._client

    @property
    def ref_cache(self) -> RefCache:
        return self._ref_cache


class BrowserSession(HooksMixin):
    """
    Profile-aware browser session with a clean Python API.

    Login state is persisted via Chrome's user-data-dir (per profile).
    All methods return :class:`~orckit_browser.models.ToolResult`.

    Usage::

        async with await BrowserSession.create(profile="work") as sess:
            await sess.navigate("https://github.com")
            tree = await sess.dom_tree(level="interactive")
            await sess.click(ref="btn_1")
    """

    def __init__(self, internal: _InternalCDPSession, profile_name: str) -> None:
        super().__init__()
        self._internal = internal
        self._profile_name = profile_name
        self._action_count = 0
        self._total_duration_ms = 0
        self._total_tokens = 0
        self._errors = 0

    @classmethod
    async def create(
        cls,
        profile: str = "default",
        headless: bool = False,
        profile_manager: ProfileManager | None = None,
    ) -> "BrowserSession":
        """Create a new BrowserSession, launching or re-attaching Chrome."""
        pm = profile_manager or _default_profile_manager
        p = pm.get_or_create(profile)
        internal = _InternalCDPSession(p)
        await internal.connect(headless=headless)
        return cls(internal, profile)

    async def __aenter__(self) -> "BrowserSession":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    async def navigate(self, url: str) -> ToolResult:
        await self._fire("before_action", {"action": "navigate", "params": {"url": url}})
        result = await nav_actions.navigate(
            self._internal.client, self._internal.ref_cache, url
        )
        await self._record(result)
        return result

    async def go_back(self) -> ToolResult:
        await self._fire("before_action", {"action": "go_back", "params": {}})
        result = await nav_actions.go_back(self._internal.client, self._internal.ref_cache)
        await self._record(result)
        return result

    async def go_forward(self) -> ToolResult:
        await self._fire("before_action", {"action": "go_forward", "params": {}})
        result = await nav_actions.go_forward(self._internal.client, self._internal.ref_cache)
        await self._record(result)
        return result

    async def reload(self) -> ToolResult:
        await self._fire("before_action", {"action": "reload", "params": {}})
        result = await nav_actions.reload(self._internal.client, self._internal.ref_cache)
        await self._record(result)
        return result

    # ------------------------------------------------------------------
    # Page state
    # ------------------------------------------------------------------

    async def dom_tree(self, level: DOMLevel = "interactive") -> ToolResult:
        start = time.monotonic()
        await self._fire("before_action", {"action": "dom_tree", "params": {"level": level}})
        try:
            doc = await self._internal.client.send("DOM.getDocument", {"depth": -1})
            root = doc["root"]
            # Get current URL + title
            info = await self._internal.client.send("Runtime.evaluate", {
                "expression": "JSON.stringify({url: location.href, title: document.title})",
                "returnByValue": True,
            })
            import json
            page_info = json.loads(info.get("result", {}).get("value", "{}"))
            url = page_info.get("url", "")
            title = page_info.get("title", "")
            builder = DOMBuilder(
                dom=root,
                url=url,
                title=title,
                ref_cache=self._internal.ref_cache,
            )
            content = builder.build(level=level)
            tokens = len(content) // 4
            metrics = ActionMetrics(
                action="dom_tree",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=tokens,
            )
            result = ToolResult(success=True, content=content, metrics=metrics)
        except Exception as exc:
            metrics = ActionMetrics(
                action="dom_tree",
                duration_ms=int((time.monotonic() - start) * 1000),
                dom_nodes_scanned=0,
                estimated_tokens=0,
            )
            result = ToolResult(success=False, content="", error=str(exc), metrics=metrics)
        await self._record(result)
        return result

    async def screenshot(
        self,
        crop: bool = False,
        element_ref: str | None = None,
    ) -> ToolResult:
        await self._fire("before_action", {"action": "screenshot", "params": {}})
        result = await capture.screenshot(
            self._internal.client,
            self._internal.ref_cache,
            crop=crop,
            element_ref=element_ref,
        )
        await self._record(result)
        return result

    # ------------------------------------------------------------------
    # Interaction
    # ------------------------------------------------------------------

    async def click(
        self,
        ref: str | None = None,
        selector: str | None = None,
        x: int | None = None,
        y: int | None = None,
    ) -> ToolResult:
        await self._fire("before_action", {"action": "click", "params": {"ref": ref}})
        result = await interact.click(
            self._internal.client, self._internal.ref_cache,
            ref=ref, selector=selector, x=x, y=y,
        )
        await self._record(result)
        return result

    async def type(self, text: str, ref: str | None = None) -> ToolResult:
        await self._fire("before_action", {"action": "type", "params": {"ref": ref}})
        result = await interact.type_text(
            self._internal.client, self._internal.ref_cache, text=text, ref=ref
        )
        await self._record(result)
        return result

    async def scroll(self, direction: str = "down", amount: int = 300) -> ToolResult:
        await self._fire("before_action", {"action": "scroll", "params": {}})
        result = await interact.scroll(
            self._internal.client, self._internal.ref_cache,
            direction=direction, amount=amount,
        )
        await self._record(result)
        return result

    async def hover(self, ref: str) -> ToolResult:
        await self._fire("before_action", {"action": "hover", "params": {"ref": ref}})
        result = await interact.hover(
            self._internal.client, self._internal.ref_cache, ref=ref
        )
        await self._record(result)
        return result

    # ------------------------------------------------------------------
    # JavaScript
    # ------------------------------------------------------------------

    async def eval_js(self, expression: str) -> ToolResult:
        await self._fire("before_action", {"action": "eval_js", "params": {}})
        result = await js_eval.eval_js(self._internal.client, expression)
        await self._record(result)
        return result

    # ------------------------------------------------------------------
    # Tabs
    # ------------------------------------------------------------------

    async def new_tab(self, url: str | None = None) -> str:
        result = await self._internal.client.send("Target.createTarget", {
            "url": url or "about:blank"
        })
        return str(result.get("targetId", ""))

    async def switch_tab(self, tab_id: str) -> None:
        await self._internal.client.send("Target.activateTarget", {"targetId": tab_id})

    async def close_tab(self, tab_id: str | None = None) -> None:
        if tab_id:
            await self._internal.client.send("Target.closeTarget", {"targetId": tab_id})

    async def list_tabs(self) -> list[TabInfo]:
        import aiohttp
        port = self._internal._profile.cdp_port
        async with aiohttp.ClientSession() as http:
            async with http.get(f"http://localhost:{port}/json") as resp:
                targets = await resp.json(content_type=None)
        return [
            TabInfo(
                tab_id=t["id"],
                url=t.get("url", ""),
                title=t.get("title", ""),
                active=t.get("type") == "page",
            )
            for t in targets
            if t.get("type") == "page"
        ]

    # ------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------

    def metrics_summary(self) -> dict[str, Any]:
        return {
            "total_actions": self._action_count,
            "total_duration_ms": self._total_duration_ms,
            "total_estimated_tokens": self._total_tokens,
            "errors": self._errors,
        }

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close the CDP connection (Chrome process keeps running for profile reuse)."""
        await self._internal.close()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    async def _record(self, result: ToolResult) -> None:
        self._action_count += 1
        self._total_duration_ms += result.metrics.duration_ms
        self._total_tokens += result.metrics.estimated_tokens
        if not result.success:
            self._errors += 1
            await self._fire("action_error", result)
        else:
            await self._fire("after_action", result.metrics)
```

- [ ] **Step 2: Update `src/orckit_browser/__init__.py`**

```python
"""orckit-browser-use: AI-friendly browser automation via CDP."""

from orckit_browser.models import ActionMetrics, TabInfo, ToolResult
from orckit_browser.session import BrowserSession

__all__ = [
    "BrowserSession",
    "ToolResult",
    "ActionMetrics",
    "TabInfo",
]
```

- [ ] **Step 3: Verify import**

```bash
uv run python -c "from orckit_browser import BrowserSession, ToolResult; print('OK')"
```

Expected output: `OK`

- [ ] **Step 4: Commit**

```bash
git add src/orckit_browser/session.py src/orckit_browser/__init__.py
git commit -m "feat: add BrowserSession with full Python API"
```

---

## Task 11: Stateless AI Bridge + Global Hook

**Files:**
- Create: `src/orckit_browser/tool_interface.py`
- Modify: `src/orckit_browser/__init__.py`
- Create: `tests/unit/test_tool_interface.py`

- [ ] **Step 1: Write failing tests**

Create `tests/unit/test_tool_interface.py`:

```python
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from orckit_browser.tool_interface import _registry, browser_tool
from orckit_browser.models import ActionMetrics, ToolResult


def make_tool_result(action: str = "navigate") -> ToolResult:
    return ToolResult(
        success=True,
        content="ok",
        metrics=ActionMetrics(
            action=action, duration_ms=10, dom_nodes_scanned=0, estimated_tokens=5
        ),
    )


async def test_browser_tool_unknown_action():
    result = await browser_tool(action="nonexistent_action_xyz", profile="_test_unknown_")
    assert result.success is False
    assert "Unknown action" in (result.error or "")


async def test_browser_tool_missing_required_param():
    # navigate requires url; omitting it should return error
    with patch("orckit_browser.tool_interface._get_or_create_session") as mock_get:
        mock_sess = AsyncMock()
        mock_sess.navigate = AsyncMock(side_effect=TypeError("missing url"))
        mock_get.return_value = mock_sess
        result = await browser_tool(action="navigate", profile="_test_missing_")
    assert result.success is False
```

- [ ] **Step 2: Run to verify failure**

```bash
uv run pytest tests/unit/test_tool_interface.py -v
```

Expected: `ImportError`.

- [ ] **Step 3: Implement `src/orckit_browser/tool_interface.py`**

```python
"""Stateless browser_tool() entry point for AI frameworks."""

from __future__ import annotations

import logging
from typing import Any

from orckit_browser.models import ActionMetrics, ToolResult
from orckit_browser.session import BrowserSession

logger = logging.getLogger(__name__)

_registry: dict[str, BrowserSession] = {}
_global_hooks: dict[str, list] = {}

_KNOWN_ACTIONS = frozenset([
    "navigate", "dom_tree", "screenshot", "click", "type", "scroll",
    "hover", "eval_js", "go_back", "go_forward", "reload",
    "new_tab", "switch_tab", "close_tab", "list_tabs", "close_session",
])


def _error_result(action: str, message: str) -> ToolResult:
    return ToolResult(
        success=False,
        content="",
        error=message,
        metrics=ActionMetrics(
            action=action, duration_ms=0, dom_nodes_scanned=0, estimated_tokens=0
        ),
    )


async def _get_or_create_session(profile: str, headless: bool = False) -> BrowserSession:
    if profile not in _registry:
        sess = await BrowserSession.create(profile=profile, headless=headless)
        _registry[profile] = sess
    return _registry[profile]


async def browser_tool(
    action: str,
    profile: str = "default",
    headless: bool = False,
    **kwargs: Any,
) -> ToolResult:
    """
    Stateless entry point for AI frameworks.

    Routes to the correct :class:`BrowserSession` by ``profile`` name.
    Creates a new session lazily if none exists for the profile.

    Args:
        action: One of the supported action strings.
        profile: Profile name (maps to a Chrome user-data-dir).
        headless: Launch Chrome in headless mode (only on first launch).
        **kwargs: Action-specific parameters.

    Returns:
        A :class:`ToolResult`.
    """
    if action not in _KNOWN_ACTIONS:
        return _error_result(action, f"Unknown action '{action}'. Valid: {sorted(_KNOWN_ACTIONS)}")

    if action == "close_session":
        if profile in _registry:
            await _registry[profile].close()
            del _registry[profile]
        return ToolResult(
            success=True,
            content=f"Session '{profile}' closed.",
            metrics=ActionMetrics(
                action="close_session", duration_ms=0, dom_nodes_scanned=0, estimated_tokens=0
            ),
        )

    try:
        sess = await _get_or_create_session(profile, headless=headless)
    except Exception as exc:
        return _error_result(action, f"Failed to create session: {exc}")

    try:
        method = getattr(sess, action)
        result: ToolResult = await method(**kwargs)
        return result
    except TypeError as exc:
        return _error_result(action, f"Invalid parameters for '{action}': {exc}")
    except Exception as exc:
        logger.exception("browser_tool error for action=%s profile=%s", action, profile)
        return _error_result(action, str(exc))
```

- [ ] **Step 4: Update `__init__.py` to export `browser_tool`**

```python
"""orckit-browser-use: AI-friendly browser automation via CDP."""

from orckit_browser.models import ActionMetrics, TabInfo, ToolResult
from orckit_browser.session import BrowserSession
from orckit_browser.tool_interface import browser_tool

__all__ = [
    "BrowserSession",
    "browser_tool",
    "ToolResult",
    "ActionMetrics",
    "TabInfo",
]
```

- [ ] **Step 5: Run tests**

```bash
uv run pytest tests/unit/test_tool_interface.py -v
```

Expected: 2 passed.

- [ ] **Step 6: Commit**

```bash
git add src/orckit_browser/tool_interface.py src/orckit_browser/__init__.py tests/unit/test_tool_interface.py
git commit -m "feat: add browser_tool() stateless AI bridge"
```

---

## Task 12: Integration Tests

**Files:**
- Create: `tests/integration/test_session.py`
- Create: `tests/integration/conftest.py`

These tests require a real Chrome installation. They are skipped automatically if Chrome is not found (using `pytest.mark.skipif`).

- [ ] **Step 1: Create `tests/integration/conftest.py`**

```python
import pytest
from orckit_browser.cdp.launcher import find_chrome


def pytest_collection_modifyitems(config, items):
    """Skip all integration tests if Chrome is not installed."""
    if find_chrome() is None:
        skip = pytest.mark.skip(reason="Chrome/Chromium not installed")
        for item in items:
            if "integration" in str(item.fspath):
                item.add_marker(skip)
```

- [ ] **Step 2: Create `tests/integration/test_session.py`**

```python
"""Integration tests: real Chrome headless + CDP."""

import pytest
from orckit_browser.session import BrowserSession
from orckit_browser.profile import ProfileManager
from pathlib import Path


@pytest.fixture()
async def sess(tmp_path: Path):
    pm = ProfileManager(base_dir=tmp_path / "profiles")
    s = await BrowserSession.create(profile="test", headless=True, profile_manager=pm)
    yield s
    await s.close()


async def test_navigate_returns_success(sess: BrowserSession):
    result = await sess.navigate("data:text/html,<h1>Hello</h1>")
    assert result.success is True
    assert "Navigated" in result.content


async def test_dom_tree_minimal(sess: BrowserSession):
    await sess.navigate("data:text/html,<h1>Test</h1><button>Click me</button>")
    result = await sess.dom_tree(level="minimal")
    assert result.success is True
    assert "Interactive elements" in result.content


async def test_dom_tree_interactive_has_button(sess: BrowserSession):
    await sess.navigate("data:text/html,<button>Submit</button>")
    result = await sess.dom_tree(level="interactive")
    assert result.success is True
    assert "button" in result.content.lower()
    assert "[ref=" in result.content


async def test_dom_tree_structured_is_json(sess: BrowserSession):
    import json
    await sess.navigate("data:text/html,<input type='text' placeholder='Name'><button>Go</button>")
    result = await sess.dom_tree(level="structured")
    assert result.success is True
    data = json.loads(result.content)
    assert "elements" in data


async def test_click_by_ref(sess: BrowserSession):
    await sess.navigate(
        "data:text/html,"
        "<button id='b' onclick=\"this.textContent='clicked'\">Click me</button>"
    )
    await sess.dom_tree(level="interactive")  # populate refs
    # find the button ref
    from orckit_browser.dom.refs import RefCache
    refs = sess._internal.ref_cache.all_refs()
    assert len(refs) > 0
    ref = next(iter(refs))
    result = await sess.click(ref=ref)
    assert result.success is True


async def test_eval_js(sess: BrowserSession):
    await sess.navigate("data:text/html,<p>hi</p>")
    result = await sess.eval_js("1 + 2")
    assert result.success is True
    assert "3" in str(result.content)


async def test_screenshot_returns_base64(sess: BrowserSession):
    await sess.navigate("data:text/html,<p>Screenshot test</p>")
    result = await sess.screenshot()
    assert result.success is True
    assert len(result.content) > 100  # base64 PNG non-empty


async def test_metrics_accumulate(sess: BrowserSession):
    await sess.navigate("data:text/html,<p>hi</p>")
    await sess.dom_tree(level="interactive")
    summary = sess.metrics_summary()
    assert summary["total_actions"] == 2
    assert summary["total_duration_ms"] >= 0


async def test_hooks_fire(sess: BrowserSession):
    events = []

    @sess.on("after_action")
    async def record(event):
        events.append(event.action)

    await sess.navigate("data:text/html,<p>test</p>")
    assert "navigate" in events
```

- [ ] **Step 3: Run integration tests**

```bash
uv run pytest tests/integration/ -v
```

Expected: all pass (or all skip if Chrome not installed in current environment).

- [ ] **Step 4: Commit**

```bash
git add tests/integration/
git commit -m "test: add integration tests for BrowserSession (real Chrome)"
```

---

## Task 13: MCP Server

**Files:**
- Create: `src/orckit_browser/mcp_server.py`

- [ ] **Step 1: Implement `src/orckit_browser/mcp_server.py`**

```python
"""MCP Server: expose browser_tool actions as MCP tools."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from orckit_browser.tool_interface import browser_tool
logger = logging.getLogger(__name__)

app = Server("orckit-browser-use")

_TOOLS = [
    Tool(
        name="browser_navigate",
        description="Navigate browser to a URL",
        inputSchema={"type": "object", "properties": {"url": {"type": "string"}, "profile": {"type": "string", "default": "default"}}, "required": ["url"]},
    ),
    Tool(
        name="browser_dom_tree",
        description="Get page DOM tree (level: minimal/interactive/full/structured)",
        inputSchema={"type": "object", "properties": {"level": {"type": "string", "enum": ["minimal", "interactive", "full", "structured"], "default": "interactive"}, "profile": {"type": "string", "default": "default"}}},
    ),
    Tool(
        name="browser_screenshot",
        description="Capture a screenshot",
        inputSchema={"type": "object", "properties": {"profile": {"type": "string", "default": "default"}, "element_ref": {"type": "string"}}},
    ),
    Tool(
        name="browser_click",
        description="Click an element by ref, selector, or coordinates",
        inputSchema={"type": "object", "properties": {"ref": {"type": "string"}, "selector": {"type": "string"}, "x": {"type": "integer"}, "y": {"type": "integer"}, "profile": {"type": "string", "default": "default"}}},
    ),
    Tool(
        name="browser_type",
        description="Type text into the page",
        inputSchema={"type": "object", "properties": {"text": {"type": "string"}, "ref": {"type": "string"}, "profile": {"type": "string", "default": "default"}}, "required": ["text"]},
    ),
    Tool(
        name="browser_eval_js",
        description="Execute JavaScript in the page",
        inputSchema={"type": "object", "properties": {"expression": {"type": "string"}, "profile": {"type": "string", "default": "default"}}, "required": ["expression"]},
    ),
]

_ACTION_MAP = {
    "browser_navigate": "navigate",
    "browser_dom_tree": "dom_tree",
    "browser_screenshot": "screenshot",
    "browser_click": "click",
    "browser_type": "type",
    "browser_eval_js": "eval_js",
}


@app.list_tools()
async def list_tools() -> list[Tool]:
    return _TOOLS


@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    action = _ACTION_MAP.get(name)
    if action is None:
        return [TextContent(type="text", text=f"Unknown tool: {name}")]
    result = await browser_tool(action=action, **arguments)
    text = result.content if isinstance(result.content, str) else str(result.content)
    if not result.success:
        text = f"ERROR: {result.error}"
    return [TextContent(type="text", text=text)]


async def _main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(_main())
```

- [ ] **Step 2: Verify import**

```bash
uv run python -c "from orckit_browser.mcp_server import app; print('MCP OK')"
```

Expected output: `MCP OK`

- [ ] **Step 3: Commit**

```bash
git add src/orckit_browser/mcp_server.py
git commit -m "feat: add MCP server exposing all browser actions as MCP tools"
```

---

## Task 14: Skill File

**Files:**
- Create: `skill/orckit-browser-use.md`

- [ ] **Step 1: Create `skill/orckit-browser-use.md`**

The skill file content (save exactly as shown):

```
---
name: orckit-browser-use
description: AI system prompt and usage guide for orckit-browser-use browser automation
---

# orckit-browser-use Browser Automation

## Installation

pip install orckit-browser-use

Chrome or Chromium must be installed:
- Ubuntu: sudo apt install chromium-browser
- macOS: brew install --cask google-chrome

## Core Rules for AI Agents

1. Always call dom_tree before click — refs expire on navigation.
2. Use level="interactive" by default (~200-500 tokens).
3. Use level="minimal" to confirm page state cheaply (~50 tokens).
4. Use level="full" only when reading page content.
5. Use level="structured" when you need JSON for programmatic processing.
6. Always use named profiles to persist login state: profile="work", profile="github".
7. Never hardcode coordinates — use ref from dom_tree instead.
8. On CDP error: call dom_tree(level="minimal") to check state, then retry.

## Actions Reference

action=navigate      required: url
action=dom_tree      optional: level (minimal/interactive/full/structured)
action=screenshot    optional: element_ref, crop
action=click         one of: ref, selector, x+y
action=type          required: text   optional: ref
action=scroll        optional: direction (up/down/left/right), amount
action=hover         required: ref
action=eval_js       required: expression
action=go_back
action=go_forward
action=reload
action=list_tabs
action=new_tab       optional: url
action=switch_tab    required: tab_id
action=close_tab     optional: tab_id
action=close_session

## Efficient Workflow

# 1. Navigate
browser_tool(action="navigate", url="https://example.com", profile="work")

# 2. Confirm (minimal)
browser_tool(action="dom_tree", level="minimal", profile="work")

# 3. Get refs (interactive)
browser_tool(action="dom_tree", level="interactive", profile="work")
# → [ref=inp_1] input[text] placeholder="Search"
# → [ref=btn_2] button "Search"

# 4. Act using refs
browser_tool(action="click", ref="inp_1", profile="work")
browser_tool(action="type", text="hello", profile="work")
browser_tool(action="click", ref="btn_2", profile="work")

## Login Reuse

Profiles persist Chrome cookies and sessions in ~/.orckit/profiles/<name>/.
Use the same profile name in future calls to reuse login state without re-authenticating.
```

- [ ] **Step 2: Commit**

```bash
mkdir -p skill
git add skill/orckit-browser-use.md
git commit -m "feat: add orckit-browser-use Claude Code skill"
```

---

## Task 15: GitHub Configuration + Workflows

**Files:**
- Create: `.github/workflows/ci.yml`
- Create: `.github/workflows/release.yml`
- Create: `.github/workflows/codeql.yml`
- Create: `.github/dependabot.yml`
- Create: `.github/ISSUE_TEMPLATE/bug_report.md`
- Create: `.github/ISSUE_TEMPLATE/feature_request.md`
- Create: `.github/pull_request_template.md`

- [ ] **Step 1: Create `.github/workflows/ci.yml`**

```yaml
name: CI
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]
jobs:
  lint-and-test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.11", "3.12"]
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
        with:
          python-version: ${{ matrix.python-version }}
      - run: uv sync --extra dev
      - run: uv run ruff check src/ tests/
      - run: uv run mypy src/
      - name: Install Chrome
        run: sudo apt-get install -y chromium-browser
      - run: uv run pytest tests/ -v --cov=orckit_browser --cov-report=xml
      - uses: codecov/codecov-action@v4
        with:
          files: coverage.xml
```

- [ ] **Step 2: Create `.github/workflows/release.yml`**

```yaml
name: Release
on:
  push:
    tags:
      - "v*.*.*"
jobs:
  release:
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv build
      - uses: pypa/gh-action-pypi-publish@release/v1
        with:
          packages-dir: dist/
```

- [ ] **Step 3: Create `.github/workflows/codeql.yml`**

```yaml
name: CodeQL
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]
  schedule:
    - cron: "0 3 * * 1"
jobs:
  analyze:
    runs-on: ubuntu-latest
    permissions:
      security-events: write
    steps:
      - uses: actions/checkout@v4
      - uses: github/codeql-action/init@v3
        with:
          languages: python
      - uses: github/codeql-action/autobuild@v3
      - uses: github/codeql-action/analyze@v3
```

- [ ] **Step 4: Create `.github/dependabot.yml`**

```yaml
version: 2
updates:
  - package-ecosystem: pip
    directory: "/"
    schedule:
      interval: monthly
    open-pull-requests-limit: 5
  - package-ecosystem: github-actions
    directory: "/"
    schedule:
      interval: monthly
    open-pull-requests-limit: 5
```

- [ ] **Step 5: Create issue templates and PR template**

`.github/ISSUE_TEMPLATE/bug_report.md`:
```markdown
---
name: Bug Report
about: Report a bug
labels: bug
---
## Description
## Steps to Reproduce
1.
2.
## Expected Behavior
## Actual Behavior
## Environment
- OS:
- Python version:
- orckit-browser-use version:
- Chrome version:
```

`.github/ISSUE_TEMPLATE/feature_request.md`:
```markdown
---
name: Feature Request
about: Suggest a feature
labels: enhancement
---
## Problem
## Proposed Solution
## Alternatives Considered
```

`.github/pull_request_template.md`:
```markdown
## Summary

## Checklist
- [ ] Tests added or updated
- [ ] CHANGELOG.md updated under [Unreleased]
- [ ] No breaking changes (or documented)
- [ ] `make lint` passes
- [ ] `make test` passes
```

- [ ] **Step 6: Commit**

```bash
mkdir -p .github/workflows .github/ISSUE_TEMPLATE
git add .github/
git commit -m "ci: add GitHub Actions workflows, issue templates, PR template"
```

---

## Task 16: Documentation Files

**Files:**
- Create: `README.md`
- Create: `CHANGELOG.md`
- Create: `CONTRIBUTING.md`

- [ ] **Step 1: Create `README.md`**

```markdown
# orckit-browser-use

AI-friendly browser automation via Chrome DevTools Protocol (CDP).

[![PyPI](https://img.shields.io/pypi/v/orckit-browser-use)](https://pypi.org/project/orckit-browser-use/)
[![CI](https://github.com/orckit/orckit-browser-use/actions/workflows/ci.yml/badge.svg)](https://github.com/orckit/orckit-browser-use/actions)

## Features
- Pure CDP (no Playwright), asyncio + websockets
- Profile-based login persistence via Chrome user-data-dir
- 4-level DOM output: minimal / interactive / full / structured
- Hook system + per-action metrics
- MCP Server mode
- Claude Code skill

## Installation
pip install orckit-browser-use

## Quick Start
```python
import asyncio
from orckit_browser import BrowserSession

async def main():
    async with await BrowserSession.create(profile="default") as sess:
        await sess.navigate("https://example.com")
        result = await sess.dom_tree(level="interactive")
        print(result.content)

asyncio.run(main())
```

## AI Framework Usage
```python
from orckit_browser import browser_tool

result = await browser_tool(action="navigate", url="https://github.com", profile="work")
result = await browser_tool(action="dom_tree", level="interactive", profile="work")
result = await browser_tool(action="click", ref="btn_search", profile="work")
```

## MCP Server
python -m orckit_browser.mcp_server

## Development
uv sync --extra dev && make test
```

- [ ] **Step 2: Create `CHANGELOG.md`**

```markdown
# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

### Added
- Initial release: BrowserSession, browser_tool(), tiered DOM output, hooks, metrics, MCP server, Claude Code skill
```

- [ ] **Step 3: Create `CONTRIBUTING.md`**

```markdown
# Contributing

## Setup
git clone https://github.com/orckit/orckit-browser-use
cd orckit-browser-use
uv sync --extra dev
pre-commit install

## Workflow
make test      # run tests
make lint      # ruff + mypy
make format    # auto-format

## Pull Requests
1. Create a branch from main
2. Write tests for changes
3. Update CHANGELOG.md under [Unreleased]
4. Submit PR using the PR template

## Release Process
git tag v0.2.0 && git push origin v0.2.0
# CI automatically publishes to PyPI
```

- [ ] **Step 4: Commit**

```bash
git add README.md CHANGELOG.md CONTRIBUTING.md
git commit -m "docs: add README, CHANGELOG, CONTRIBUTING"
```

---

## Task 17: Final Wiring and Lint Pass

- [ ] **Step 1: Run full test suite**

```bash
uv run pytest tests/ -v --cov=orckit_browser --cov-report=term-missing
```

Expected: all unit tests pass; integration tests pass or skip (Chrome dependency).

- [ ] **Step 2: Run lint**

```bash
uv run ruff check src/ tests/
uv run mypy src/
```

Fix any reported issues inline.

- [ ] **Step 3: Run format**

```bash
uv run ruff format src/ tests/
```

- [ ] **Step 4: Verify public API**

```bash
uv run python -c "
from orckit_browser import BrowserSession, browser_tool, ToolResult, ActionMetrics, TabInfo
print('All exports OK')
"
```

Expected output: `All exports OK`

- [ ] **Step 5: Run build**

```bash
uv build
```

Expected: creates `dist/orckit_browser_use-0.1.0-py3-none-any.whl` and `.tar.gz`.

- [ ] **Step 6: Tag and announce**

```bash
git add -u
git commit -m "chore: final lint and format pass" --allow-empty
git tag v0.1.0
echo "Ready: run 'make publish' to push to PyPI"
```

---

## Self-Review Against Spec

| Spec Requirement | Covered By | Status |
|-----------------|-----------|--------|
| Pure CDP, no Playwright | Task 4+5 | ✅ |
| Profile-based login persistence | Task 3 | ✅ |
| BrowserSession Python API (all methods) | Task 10 | ✅ |
| Stateless browser_tool() | Task 11 | ✅ |
| 4-level DOM output | Task 7 | ✅ |
| Ref cache + invalidation on nav | Task 6 | ✅ |
| Hook system (4 events) | Task 8 | ✅ |
| ActionMetrics on every action | Tasks 2+9 | ✅ |
| screenshot (viewport + element crop) | Task 9 | ✅ |
| All 16 browser_tool actions | Tasks 9+10+11 | ✅ |
| MCP Server | Task 13 | ✅ |
| Claude Code skill | Task 14 | ✅ |
| pyproject.toml + uv | Task 1 | ✅ |
| Makefile (8 targets) | Task 1 | ✅ |
| pre-commit config | Task 1 | ✅ |
| CI, release, CodeQL, Dependabot workflows | Task 15 | ✅ |
| Issue templates + PR template | Task 15 | ✅ |
| README, CHANGELOG, CONTRIBUTING | Task 16 | ✅ |
| Unit tests (models, profile, refs, dom, hooks, tool_interface) | Tasks 2,3,6,7,8,11 | ✅ |
| Integration tests (real Chrome) | Task 12 | ✅ |
