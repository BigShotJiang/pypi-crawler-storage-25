# orckit-browser-use Design Spec

**Date:** 2026-05-22  
**Status:** Approved  
**Author:** Claude (via brainstorming session)

---

## 1. Overview

`orckit-browser-use` is a Python package that provides AI-friendly browser automation built on pure Chrome DevTools Protocol (CDP). It is distributed as a pip package and includes a Claude Code skill (`orckit-browser-use`) containing the AI system prompt and installation guide.

**Design goals:**
- Minimal token consumption through tiered DOM output
- Profile-based login state persistence across sessions
- Clean Python API (`BrowserSession`) with an AI-friendly stateless bridge (`browser_tool`)
- Built-in Hook system and per-action metrics
- MCP Server mode for exposing browser tools as MCP tools
- Zero dependency on Playwright (pure asyncio CDP via websockets)

---

## 2. Architecture

### 2.1 Layer Overview

```
AI Framework / User Code
        ↓
tool_interface.py     (browser_tool — stateless AI bridge)
        ↓
BrowserSession        (Python API, profile-aware)
        ↓
_InternalCDPSession   (CDP connection, DOM cache, actions)
        ↓
cdp/client.py         (raw CDP WebSocket via asyncio + websockets)
        ↓
Chrome Process        (managed by cdp/launcher.py)
```

### 2.2 Directory Structure

```
orckit-browser-use/
├── src/
│   └── orckit_browser/
│       ├── __init__.py              # Public API: BrowserSession, browser_tool
│       ├── session.py               # BrowserSession (user-facing API)
│       ├── profile.py               # Profile management (Chrome user data dirs)
│       ├── cdp/
│       │   ├── __init__.py
│       │   ├── client.py            # CDP WebSocket client (pure asyncio)
│       │   └── launcher.py          # Chrome process launch/discovery/attach
│       ├── dom/
│       │   ├── __init__.py
│       │   ├── builder.py           # Tiered DOM output (minimal/interactive/full/structured)
│       │   └── refs.py              # node_id ref cache
│       ├── actions/
│       │   ├── __init__.py
│       │   ├── navigate.py          # navigate / go_back / go_forward / reload
│       │   ├── interact.py          # click / type / scroll / hover
│       │   ├── capture.py           # screenshot (viewport / element crop)
│       │   └── js_eval.py           # eval_js
│       ├── hooks.py                 # Hook system (before/after action callbacks)
│       ├── models.py                # Pydantic models: ToolInput, ToolResult, ActionMetrics
│       ├── tool_interface.py        # browser_tool() — stateless AI bridge
│       └── mcp_server.py            # MCP Server mode (optional)
├── skill/
│   └── orckit-browser-use.md       # Claude Code skill: system prompt + install guide
├── tests/
│   ├── unit/
│   └── integration/
├── docs/
│   └── superpowers/specs/
├── .github/
│   ├── workflows/
│   │   ├── ci.yml
│   │   ├── release.yml
│   │   ├── codeql.yml
│   │   └── dependabot.yml
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md
│   │   └── feature_request.md
│   └── pull_request_template.md
├── .pre-commit-config.yaml
├── Makefile
├── pyproject.toml
├── README.md
├── CHANGELOG.md
└── CONTRIBUTING.md
```

---

## 3. Core Components

### 3.1 Profile Management (`profile.py`)

Each `Profile` maps to a Chrome user data directory under `~/.orckit/profiles/<name>/`. This directory persists cookies, local storage, and session state across Chrome restarts, enabling login state reuse.

```python
@dataclass
class Profile:
    name: str
    data_dir: Path          # ~/.orckit/profiles/<name>/
    cdp_port: int           # assigned port (default: 9222, increments for multiple profiles)

class ProfileManager:
    def get_or_create(name: str) -> Profile
    def list_profiles() -> list[Profile]
    def delete(name: str) -> None
```

**Key behavior:** When `BrowserSession` is created with a `profile`, `ProfileManager` ensures the Chrome user data directory exists and assigns a stable CDP port to that profile. If a Chrome process is already running on that port, it is re-attached rather than relaunched.

### 3.2 CDP Client (`cdp/client.py`)

Pure asyncio WebSocket implementation, no Playwright dependency.

```python
class CDPClient:
    async def connect(ws_url: str) -> None
    async def send(method: str, params: dict) -> dict
    async def enable_domain(domain: str) -> None    # e.g. DOM, Page, Input
    async def close() -> None

    # Event subscription
    def on(event: str, callback: Callable) -> None
    def off(event: str, callback: Callable) -> None
```

**Timeouts:** All `send()` calls have a configurable timeout (default 30s). CDP session invalidation (post-navigation) is detected via `Target.detachedFromTarget` events and triggers automatic session re-attachment.

### 3.3 Chrome Launcher (`cdp/launcher.py`)

Responsible for:
1. Finding Chrome/Chromium executable (macOS and Linux, searches common paths)
2. Building launch flags (`--remote-debugging-port`, `--user-data-dir`, `--no-sandbox` for root, etc.)
3. Launching Chrome subprocess and waiting for CDP WebSocket URL
4. Detecting already-running Chrome on the target port (attach mode)
5. Orphaned process detection to avoid port conflicts

```python
async def launch_or_attach(profile: Profile) -> str:
    """Returns WebSocket URL for CDP connection."""
```

### 3.4 DOM Builder (`dom/builder.py`)

Converts raw CDP DOM tree into four output levels, each optimized for a different use case.

**Level: `minimal`** (~50 tokens)
```
Page: https://github.com/login | "Sign in to GitHub"
Interactive elements: 12 | Scroll: yes
```

**Level: `interactive`** (~200–500 tokens)
```
Page: https://github.com/login | "Sign in to GitHub"
Interactive elements (12):
  [ref=inp_1] input[text] placeholder="Username or email address"
  [ref=inp_2] input[password] placeholder="Password"
  [ref=btn_3] button "Sign in"
  [ref=lnk_4] a "Forgot password?"
  ...
```

**Level: `full`** (~1000–3000 tokens)
```
<body>
  <header>
    <nav>
      <a ref=lnk_0 href="/">GitHub</a>
  <main>
    <h1>Sign in to GitHub</h1>
    <form>
      <input ref=inp_1 type=text placeholder="Username or email address">
      <input ref=inp_2 type=password placeholder="Password">
      <button ref=btn_3>Sign in</button>
```

**Level: `structured`** (JSON, for programmatic use)
```json
{
  "url": "https://github.com/login",
  "title": "Sign in to GitHub",
  "elements": [
    {
      "ref": "inp_1",
      "tag": "input",
      "type": "text",
      "role": "textbox",
      "label": "Username or email address",
      "placeholder": "Username or email address",
      "node_id": 42,
      "bounds": {"x": 320, "y": 280, "width": 320, "height": 40}
    }
  ]
}
```

**Filtering logic:** Elements included are: `button`, `input`, `select`, `textarea`, `a` (with href), `label`, `form`, plus elements with ARIA roles `button`, `link`, `textbox`, `combobox`, `checkbox`, `radio`, `menuitem`. Structural elements (`header`, `nav`, `main`, `h1`–`h6`) are included in `full` and `structured` modes only.

**Ref cache (`dom/refs.py`):**  After each `dom_tree()` call, the ref→node_id mapping is cached in `_InternalCDPSession`. Refs are invalidated after any cross-document navigation.

### 3.5 BrowserSession (`session.py`)

The primary user-facing class. Wraps `_InternalCDPSession` and provides the Python API.

```python
class BrowserSession:
    # Construction
    @classmethod
    async def create(
        cls,
        profile: str = "default",
        headless: bool = False,
    ) -> "BrowserSession": ...

    # Context manager support
    async def __aenter__(self) -> "BrowserSession": ...
    async def __aexit__(self, *args) -> None: ...

    # Navigation
    async def navigate(self, url: str) -> ToolResult: ...
    async def go_back(self) -> ToolResult: ...
    async def go_forward(self) -> ToolResult: ...
    async def reload(self) -> ToolResult: ...

    # Page state
    async def dom_tree(
        self,
        level: Literal["minimal", "interactive", "full", "structured"] = "interactive"
    ) -> ToolResult: ...
    async def screenshot(
        self,
        crop: bool = False,
        element_ref: str | None = None,
    ) -> ToolResult: ...

    # Interaction
    async def click(
        self,
        ref: str | None = None,
        selector: str | None = None,
        x: int | None = None,
        y: int | None = None,
    ) -> ToolResult: ...
    async def type(self, text: str, ref: str | None = None) -> ToolResult: ...
    async def scroll(self, direction: str, amount: int = 300) -> ToolResult: ...
    async def hover(self, ref: str) -> ToolResult: ...

    # JavaScript
    async def eval_js(self, expression: str) -> ToolResult: ...

    # Tabs
    async def new_tab(self, url: str | None = None) -> str: ...         # returns tab_id
    async def switch_tab(self, tab_id: str) -> None: ...
    async def close_tab(self, tab_id: str | None = None) -> None: ...
    async def list_tabs(self) -> list[TabInfo]: ...

    # Metrics
    def metrics_summary(self) -> dict: ...

    # Lifecycle
    async def close(self) -> None: ...
```

**Element location priority:** When `click()` is called:
1. `ref` → look up cached node_id → use `DOM.getBoxModel` for coordinates → `Input.dispatchMouseEvent`
2. `selector` → `DOM.querySelector` → get coordinates → dispatch
3. `x`, `y` → dispatch directly

### 3.6 Hook System (`hooks.py`)

Hooks are registered on a `BrowserSession`. They fire synchronously (awaited) before and after each action. Global hooks (applying to all sessions) can be registered via `orckit_browser.add_global_hook(event, callback)`, which wraps the module-level session registry in `tool_interface.py`.

```python
# Session-level hooks
sess = await BrowserSession.create(profile="work")

@sess.on("before_action")
async def log(event: ActionEvent) -> None:
    print(f"[{event.profile}] {event.action}")

@sess.on("after_action")
async def metrics(event: ActionEvent) -> None:
    print(f"  done in {event.metrics.duration_ms}ms, ~{event.metrics.estimated_tokens} tokens")

@sess.on("action_error")
async def on_err(event: ErrorEvent) -> None:
    print(f"  ERROR: {event.error}")

@sess.on("page_navigated")
async def on_nav(event: NavigationEvent) -> None:
    print(f"  → {event.url}")
```

Events:
- `ActionEvent`: `profile`, `action`, `params`, `metrics: ActionMetrics`
- `ErrorEvent`: `profile`, `action`, `error: Exception`
- `NavigationEvent`: `profile`, `url`, `title`

### 3.7 Models (`models.py`)

```python
class ActionMetrics(BaseModel):
    action: str
    duration_ms: int
    dom_nodes_scanned: int
    estimated_tokens: int
    screenshot_size_kb: int = 0

class ToolResult(BaseModel):
    success: bool
    content: str | dict
    error: str | None = None
    metrics: ActionMetrics

class TabInfo(BaseModel):
    tab_id: str
    url: str
    title: str
    active: bool
```

### 3.8 Stateless AI Bridge (`tool_interface.py`)

Maintains a module-level dict of `{profile: BrowserSession}`. Called by AI frameworks as a single tool.

```python
async def browser_tool(
    action: str,
    profile: str = "default",
    **kwargs,
) -> ToolResult:
    """
    Stateless entry point for AI frameworks.
    Routes to the correct BrowserSession by profile name.
    Creates a new session if one does not exist for the profile.
    """
```

**Supported actions via `browser_tool`:**

| action | key kwargs | description |
|--------|-----------|-------------|
| `navigate` | `url` | Navigate to URL |
| `dom_tree` | `level` | Get page DOM (default: `interactive`) |
| `screenshot` | `crop`, `element_ref` | Capture page/element |
| `click` | `ref`, `selector`, `x`, `y` | Click element |
| `type` | `text`, `ref` | Type text |
| `scroll` | `direction`, `amount` | Scroll page |
| `hover` | `ref` | Hover over element |
| `eval_js` | `expression` | Execute JavaScript |
| `go_back` | — | Browser back |
| `go_forward` | — | Browser forward |
| `reload` | — | Reload page |
| `new_tab` | `url` | Open new tab |
| `switch_tab` | `tab_id` | Switch active tab |
| `close_tab` | `tab_id` | Close a tab |
| `list_tabs` | — | List open tabs |
| `close_session` | — | Close session and Chrome |

### 3.9 MCP Server (`mcp_server.py`)

Exposes all `browser_tool` actions as MCP tools, enabling any MCP-compatible client (Claude Desktop, etc.) to use browser automation.

```python
# Launch MCP server
python -m orckit_browser.mcp_server

# Or via Makefile
make mcp
```

Each action maps to one MCP tool with JSON Schema parameters matching the `browser_tool` kwargs. The MCP server manages one default `BrowserSession` per MCP session.

---

## 4. Skill: `orckit-browser-use.md`

The skill file is a Claude Code skill placed in the `skill/` directory of the repo. Users install it by copying or symlinking it to their `.codebuddy/skills/` directory.

**Contents:**
1. **Installation guide** — `pip install orckit-browser-use` + `playwright install chromium` (optional)
2. **System prompt** — Instructs the AI on:
   - How to use `browser_tool()` with correct action names and parameters
   - When to use each DOM level (`interactive` for actions, `full` for reading, `minimal` for confirmation)
   - The ref system: always call `dom_tree` before `click`, use refs not selectors when available
   - How to handle login: use named profiles, if page looks like login ask user to authenticate manually or attempt automation
   - Error recovery: on CDP error, call `dom_tree(level="minimal")` to check current state before retrying
3. **Usage examples** — Annotated example interactions showing efficient token usage

---

## 5. Data Flow

### 5.1 Typical AI interaction

```
AI: browser_tool(action="navigate", url="https://github.com", profile="work")
  → launcher: attach to Chrome on port 9222 (profile "work")
  → CDPClient: Page.navigate(url)
  → wait for Page.loadEventFired
  ← ToolResult(success=True, content="Navigated to https://github.com | 'GitHub'")

AI: browser_tool(action="dom_tree", level="interactive", profile="work")
  → CDPClient: DOM.getDocument()
  → dom/builder.py: filter interactive elements
  → dom/refs.py: cache ref→node_id mapping
  ← ToolResult(success=True, content="Page: https://github.com | ...\n[ref=inp_1]...")

AI: browser_tool(action="click", ref="btn_search", profile="work")
  → dom/refs.py: lookup node_id for "btn_search"
  → CDPClient: DOM.getBoxModel(nodeId=...)
  → CDPClient: Input.dispatchMouseEvent(type=mousePressed, x=..., y=...)
  ← ToolResult(success=True, content="Clicked button 'Search' at (820, 48)")
```

### 5.2 Error recovery

If CDP session becomes invalid (page navigated without `browser_tool`):
1. `CDPClient.send()` raises `CDPSessionError`
2. `_InternalCDPSession` catches it, invalidates ref cache, re-attaches CDP
3. Action is retried once; if retry fails, returns `ToolResult(success=False, error=...)`

---

## 6. Engineering Standards

### 6.1 `pyproject.toml`

```toml
[project]
name = "orckit-browser-use"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = [
    "websockets>=12.0",
    "pydantic>=2.0",
    "aiohttp>=3.9",
    "mcp>=1.0",              # for MCP server mode
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.23",
    "ruff>=0.4",
    "mypy>=1.9",
    "coverage[toml]>=7.5",
    "pre-commit>=3.7",
]

[tool.ruff]
line-length = 88
select = ["E", "F", "I", "N", "W"]

[tool.mypy]
strict = true
python_version = "3.11"

[tool.pytest.ini_options]
asyncio_mode = "auto"
```

### 6.2 Makefile

```makefile
run:
    uv run python -m orckit_browser

test:
    uv run pytest tests/ -v --cov=orckit_browser --cov-report=term-missing

lint:
    uv run ruff check src/ tests/
    uv run mypy src/

format:
    uv run ruff format src/ tests/

build:
    uv build

publish:
    uv publish

mcp:
    uv run python -m orckit_browser.mcp_server

clean:
    rm -rf dist/ build/ .coverage htmlcov/ .mypy_cache/ .ruff_cache/
```

### 6.3 Pre-commit Hooks (`.pre-commit-config.yaml`)

```yaml
repos:
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.4.0
    hooks:
      - id: ruff
        args: [--fix]
      - id: ruff-format
  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.9.0
    hooks:
      - id: mypy
        additional_dependencies: [pydantic, websockets]
```

### 6.4 GitHub Workflows

| File | Trigger | Jobs |
|------|---------|------|
| `ci.yml` | push + PR to `main` | lint (ruff + mypy), test (pytest, Python 3.11/3.12) |
| `release.yml` | push tag `v*.*.*` | build, publish to PyPI via trusted publisher |
| `codeql.yml` | weekly + PR | CodeQL security scan (Python) |
| `dependabot.yml` | monthly | Bump pip + GitHub Actions dependencies |

**Additional GitHub configuration:**
- **Branch protection on `main`:** require CI passing + 1 review
- **Issue templates:** Bug Report, Feature Request
- **PR template:** checklist for tests, changelog entry, breaking change flag
- **CHANGELOG.md:** Keep a Changelog format (Unreleased → versioned on release)
- **CONTRIBUTING.md:** dev setup, coding standards, test requirements, PR process

---

## 7. Testing Strategy

- **Unit tests** (`tests/unit/`): DOM builder output correctness, model serialization, ref cache invalidation, Hook firing order
- **Integration tests** (`tests/integration/`): Full CDP cycle against a real Chrome instance (headless), navigate → dom_tree → click → screenshot
- **Coverage target:** 80% line coverage (enforced in CI)
- **No mocking of CDP** for integration tests; a real Chrome process is launched in CI using `--headless=new`

---

## 8. Deliverables Checklist

- [ ] `orckit-browser-use` pip package on PyPI
- [ ] `skill/orckit-browser-use.md` — Claude Code skill
- [ ] MCP server mode (`python -m orckit_browser.mcp_server`)
- [ ] README with quickstart, API reference, profile reuse guide
- [ ] CHANGELOG.md
- [ ] CONTRIBUTING.md
- [ ] GitHub Actions: ci, release, codeql, dependabot
- [ ] Pre-commit config
- [ ] Makefile with run/test/lint/format/build/publish/mcp/clean
