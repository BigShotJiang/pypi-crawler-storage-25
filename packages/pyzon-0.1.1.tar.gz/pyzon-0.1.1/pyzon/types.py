class ZigUndef:
    def __repr__(self) -> str:
        return "Undefined"


class EnumLiteral(str):
    def enum_literal(self) -> str:
        string = super().__str__()
        if self.isascii():
            return f".{string}"
        return f'.@"{string}"'

    def __repr__(self) -> str:
        return self.enum_literal()


Undefined = ZigUndef()
