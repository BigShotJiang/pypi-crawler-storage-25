from __future__ import annotations
from typing import Any
from json import dumps as json_dumps

from pyzon.parser import ZonParser
from pyzon.types import EnumLiteral

__all__ = (
    "load",
    "loads",
    "dump",
    "dumps",
)


def load(fp) -> Any:
    return loads(fp.read())


def loads(s: str) -> Any:
    return ZonParser(s).parse()


def dump(obj, fp) -> Any:
    fp.truncate(0)
    fp.write(dumps(obj))


def dumps(obj) -> str:

    if isinstance(obj, dict):
        struct_items = []
        for key, val in obj.items():
            if not isinstance(key, str):
                raise Exception("key of dictionary must be a string or a literal")
            key_literal = EnumLiteral(key)
            struct_items.append(f"{key_literal.enum_literal()} = {dumps(val)}")

        struct_body = ", ".join(struct_items)
        return f".{{{struct_body}}}"
    elif isinstance(obj, list):
        tuple_body = ", ".join([dumps(o) for o in obj])
        return f".{{{tuple_body}}}"
    elif isinstance(obj, EnumLiteral):
        return obj.enum_literal()
    elif isinstance(obj, str):
        return json_dumps(obj)
    elif isinstance(obj, int):
        return json_dumps(obj)
    elif isinstance(obj, float):
        return json_dumps(obj)
    else:
        raise Exception(f"Unsupported obj {obj}")
