from typing import Any
from string import whitespace, digits, octdigits, hexdigits

from pyzon.types import Undefined, EnumLiteral

DOT = r"."
LBRACE = r"{"
RBRACE = r"}"
EQUAL = r"="
COMMA = r","
QUOTE = r"'"
DOUBLEQUOTE = '"'
BACKSLASH = "\\"
SLASH = r"/"
MINUS = r"-"
PLUS = r"+"
AT = r"@"


class ZonParser:
    def __init__(self, content: str):
        self.object_stack: list[Any] = []
        self.stack_index: int = -1

        self.content: str = content
        self.pos: int = 0

        self.key: Any = Undefined
        self.value: Any = Undefined
        self.sign: int = 1

    def _advance_pos(self, pos, ext):
        new_pos = pos + ext
        if new_pos >= len(self.content):
            raise Exception(f"{new_pos} out of bounds")

        return new_pos

    def _start_object(self) -> None:
        obj: dict[Any, Any] = dict()
        self.object_stack.append(obj)
        if self.key is not Undefined:
            assert self.value == Undefined
            self.object_stack[self.stack_index][self.key] = obj
            self.key = Undefined

        self.stack_index += 1

    def _end_object(self) -> None:
        assert self.value == Undefined
        self.value = self.object_stack.pop(self.stack_index)

        self.stack_index -= 1
        self.pos += 1

    def _insert_element(self) -> None:
        obj = self.object_stack[self.stack_index]
        if self.key is not Undefined and self.value is not Undefined:
            obj[self.key] = self.value

        elif self.value is not Undefined:
            if isinstance(obj, dict) and not obj:
                assert len(obj) == 0
                new_obj: list[Any] = list()
                self.object_stack[self.stack_index] = new_obj

                # We gotta patch the previous entry
                if self.stack_index > 0:
                    prev_obj = self.object_stack[self.stack_index - 1]

                    if isinstance(prev_obj, dict):
                        for k, v in prev_obj.items():
                            if v is obj:
                                prev_obj[k] = new_obj
                    elif isinstance(prev_obj, list):
                        for v in prev_obj:
                            if v is obj:
                                prev_obj[k] = new_obj

                obj = new_obj

            if isinstance(obj, list):
                obj.append(self.value)

        else:
            assert self.key is Undefined

        self.key = Undefined
        self.value = Undefined

    def _parse_character(self) -> int:
        next_pos = self._advance_pos(self.pos, 1)

        char = self.content[next_pos]
        if char == BACKSLASH:
            next_pos += 1
            char = self.content[next_pos]
            if char == "n":
                char = "\n"
            elif char == "t":
                char = "\t"

        assert self.content[next_pos + 1] == QUOTE

        assert self.value is Undefined
        self.value = char

        return next_pos + 2

    def _parse_string(self) -> int:
        next_pos = self._advance_pos(self.pos, 1)

        begin = next_pos
        while True:
            if (
                self.content[next_pos] == DOUBLEQUOTE
                and self.content[next_pos - 1] != BACKSLASH
            ):
                break
            next_pos = self._advance_pos(next_pos, 1)

        string = self.content[begin:next_pos]
        assert self.value is Undefined
        self.value = string

        return next_pos + 1

    def _parse_multiline_string(self) -> int:
        next_pos = self._advance_pos(self.pos, 2)

        next_char = self.content[next_pos - 1]
        assert next_char == BACKSLASH

        full_string = ""

        start = self.pos + 2

        while True:
            while True:
                if self.content[next_pos] == "\n":
                    break
                next_pos = self._advance_pos(next_pos, 1)

            part = self.content[start:next_pos]
            full_string += part

            while next_pos < len(self.content):
                if self.content[next_pos] not in whitespace:
                    break
                next_pos += 1

            if next_pos >= len(self.content):
                break
            elif self.content[next_pos] != BACKSLASH:
                break

            full_string += "\n"

            start = self._advance_pos(next_pos, 2)
            next_pos = self._advance_pos(next_pos, 1)

            next_char = self.content[next_pos]
            assert next_char == BACKSLASH

        assert self.value is Undefined
        self.value = full_string

        return next_pos

    def _parse_number(self) -> int:
        base = 10
        base_content = digits + "."

        next_pos = self.pos + 1
        if next_pos < len(self.content):
            if self.content[self.pos] == "0":
                next_char = self.content[next_pos]
                if next_char == "b":
                    base = 2
                    base_content = "01"
                    next_pos = self._advance_pos(next_pos, 1)
                elif next_char == "o":
                    base = 8
                    base_content = octdigits
                    next_pos = self._advance_pos(next_pos, 1)
                elif next_char == "x":
                    base = 16
                    base_content = hexdigits
                    next_pos = self._advance_pos(next_pos, 1)

        base_content += "_"

        while next_pos < len(self.content):
            if self.content[next_pos] not in base_content:
                break
            next_pos += 1

        strnum = self.content[self.pos : next_pos]
        if "." in strnum:
            number = float(strnum) * self.sign
        else:
            number = int(strnum, base) * self.sign

        assert self.value is Undefined
        self.value = number
        self.sign = 1

        return next_pos

    def _parse_keyword(self) -> int:
        next_pos = self.pos
        while next_pos < len(self.content):
            if not self.content[next_pos].isalpha():
                break
            next_pos += 1

        keyword = self.content[self.pos : next_pos]

        keyvalue: bool | float | None
        if keyword == "true":
            keyvalue = True
        elif keyword == "false":
            keyvalue = False
        elif keyword == "null":
            keyvalue = None
        elif keyword == "nan":
            keyvalue = float("nan") * self.sign
            self.sign = 1
        elif keyword == "inf":
            keyvalue = float("inf") * self.sign
            self.sign = 1
        else:
            raise Exception(f"Unknown keyword {keyword}")

        assert self.value is Undefined
        self.value = keyvalue

        return next_pos

    def _skip_comment(self) -> int:
        next_pos = self._advance_pos(self.pos, 1)
        next_char = self.content[next_pos]
        if next_char == SLASH:
            while True:
                if self.content[next_pos] == "\n":
                    break
                next_pos = self._advance_pos(next_pos, 1)

        return self._advance_pos(next_pos, 1)

    def parse(self) -> Any:
        assert self.pos == 0
        assert self.stack_index == -1

        while self.pos < len(self.content):
            char = self.content[self.pos]
            if char in whitespace:
                self.pos += 1
                continue

            if char == DOT:
                next_pos = self._advance_pos(self.pos, 1)
                next_char = self.content[next_pos]
                if next_char == LBRACE:
                    self.pos = next_pos + 1
                    self._start_object()
                    continue

                second_next_pos = next_pos + 1
                if second_next_pos < len(self.content):
                    second_next_char = self.content[second_next_pos]

                    if next_char == AT and second_next_char == DOUBLEQUOTE:
                        self.pos = second_next_pos
                        self.pos = self._parse_string()
                        continue

                begin = next_pos
                while next_pos < len(self.content):
                    c = self.content[next_pos]
                    if not (c.isalnum() or c == "_"):
                        break

                    next_pos += 1

                indent = EnumLiteral(self.content[begin:next_pos])
                assert self.value is Undefined
                self.value = indent

                self.pos = next_pos
                continue

            elif char == RBRACE:
                self._insert_element()
                self._end_object()
                continue

            elif char == EQUAL:
                assert self.key is Undefined
                assert self.value is not Undefined
                self.key = self.value
                self.value = Undefined

                self.pos += 1
                continue

            elif char == SLASH:
                self.pos = self._skip_comment()
                continue

            elif char == COMMA:
                self._insert_element()
                self.pos += 1
                continue

            elif char == QUOTE:
                self.pos = self._parse_character()
                continue

            elif char == DOUBLEQUOTE:
                self.pos = self._parse_string()
                continue

            elif char == BACKSLASH:
                self.pos = self._parse_multiline_string()
                continue

            elif char == MINUS:
                self.sign *= -1
                self.pos += 1
                continue

            elif char == PLUS:
                self.pos += 1
                continue

            elif char.isdigit():
                self.pos = self._parse_number()
                continue

            elif char.isalpha():
                self.pos = self._parse_keyword()
                continue

            raise Exception(f"Unhandled data at {self.pos}: {char} ({ord(char)})")

        if self.object_stack or self.key is not Undefined:
            raise Exception("Incomplete data")

        return self.value
