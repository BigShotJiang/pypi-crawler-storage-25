import os
import io
from math import isnan
import pytest

from pyzon import load, dumps
from pyzon.types import Undefined, EnumLiteral


def load_test(str):
    f = io.StringIO(str)
    a = load(f)
    return a


def test_bool() -> None:
    assert load_test("true") == True
    assert load_test("false") == False


def test_numbers() -> None:
    assert load_test("1") == 1
    assert load_test("0x10") == 0x10
    assert load_test("0o07") == 0o07
    assert load_test("0b11") == 0b11

    assert load_test("-1") == -1
    assert load_test("+1") == +1
    assert load_test("--1") == +1
    assert load_test("-+-1") == +1
    assert load_test("---1") == -1

    assert load_test("3.14") == 3.14


def test_nan_and_inf() -> None:
    assert isnan(load_test("nan"))
    assert isnan(load_test("-nan"))
    assert load_test("inf") == float("inf")
    assert load_test("-inf") == float("-inf")


def test_string() -> None:
    assert load_test("'a'") == "a"
    assert load_test("'\\a'") == "a"
    assert load_test("'\\n'") == "\n"
    assert load_test("'\\t'") == "\t"
    assert load_test('"Hello World"') == "Hello World"
    assert load_test('"Hello\\ Escaped"') == "Hello\\ Escaped"

    assert (
        load_test("""
        \\\\Multiline
        \\\\String
    """)
        == "Multiline\nString"
    )

    with pytest.raises(Exception):
        load_test('"Incomplete')

    with pytest.raises(Exception):
        load_test("bla")


def test_literals() -> None:
    assert load_test(".bla") == "bla"
    assert load_test(".hello_world") == "hello_world"

    assert load_test('.@"äöü"') == "äöü"

    with pytest.raises(Exception):
        load_test(".")


def test_tuple() -> None:
    assert load_test(".{1,2,3}") == [1, 2, 3]
    assert load_test(".{ .{1,2,3} }") == [[1, 2, 3]]
    assert load_test(".{ .{ .{1,2,3} } }") == [[[1, 2, 3]]]

    with pytest.raises(Exception):
        load_test(".{ 1, 2, 3")


def test_struct() -> None:
    assert load_test(".{.a = 1, .b = 2, .c = 3}") == {"a": 1, "b": 2, "c": 3}
    assert load_test(".{ .{.a = 1} }") == [{"a": 1}]
    assert load_test(".{ .{ .{.a = 1} } }") == [[{"a": 1}]]

    with pytest.raises(Exception):
        load_test(".{ .a = 1, .b = 2, .c = 3")


def test_undefined_repr() -> None:
    assert repr(Undefined) == "Undefined"


def test_decl_repr() -> None:
    assert repr(EnumLiteral("test")) == ".test"
    assert repr(EnumLiteral("äöü")) == '.@"äöü"'


def test_dump() -> None:
    tests = [
        1,
        "abc",
        [1, 2, 3],
        {"a": 1, "b": "test"},
        {"a": EnumLiteral("decl")},
    ]

    for t in tests:
        assert load_test(dumps(t)) == t


@pytest.fixture
def zon_data(tmpdir, request):
    filename = request.module.__file__
    test_dir = os.path.dirname(filename)
    zon_dir = os.path.join(test_dir, "zon")

    test_files = {}

    for test_file in os.listdir(zon_dir):
        if not test_file.endswith(".zon"):
            continue

        with open(os.path.join(zon_dir, test_file)) as fp:
            test_files[test_file] = fp.read()

    return test_files


def test_zon_files(zon_data):
    for file, data in zon_data.items():
        try:
            load_test(data)
        except Exception as e:
            raise Exception(f"Failed to parse {file}") from e
