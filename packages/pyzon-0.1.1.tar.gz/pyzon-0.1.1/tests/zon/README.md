All of these files originate from [`ziglang/zig`](https://codeberg.org/ziglang/zig) specifically `test/behavior/zon`.
They are covered by the same license as the entire pyzon library.
