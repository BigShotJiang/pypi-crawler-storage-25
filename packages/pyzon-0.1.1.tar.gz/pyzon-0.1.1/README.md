
# PyZon

a standalone python parser for the Zig Object Notation format from the [Zig Programming Language](https://ziglang.org/).

At the moment the library only supports reading Zon file

## How to use
```py
import pyzon

with open("build.zig.zon") as fp:
    pyzon.load(fp)
# {.name: .zig, .version: '0.0.0', .dependencies: {.standalone_test_cases: {.path: 'test/standalone'}, .link_test_cases: {.path: 'test/link'}}, .paths: [''], .fingerprint: 13965117641364839958}

pyzon.loads(".{1, .b, \"b\", 'c'}")
# [1, .b, 'b', 'c']

pyzon.dumps({"name": pyzon.EnumLiteral("test"), "version": "0.0.0"})
# '.{.name = .test, .version = "0.0.0"}'
```

## Limitations
PyZon was only intended to ever parse `build.zig.zon` files and may not support everything expressable within a Zon file however it is also a bit more lax and can parse zon files that Zig itself will reject, for example in the case of keywords being used in literals.

If you find a zon file that does not parse correctly please open an issue to document this and give me the ability to fix it.

## License
PyZon uses the MIT License
