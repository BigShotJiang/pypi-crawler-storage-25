"""DART API 요청 간격 관리.

개발 단계에서는 최소한의 딜레이만 적용.
서비스 런칭 시 rate limiting 재검토.
"""
