"""A2A protocol client — stdlib only (no external dependencies)."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
import uuid
from typing import Any

# Per A2A spec (a2a.utils.constants).
AGENT_CARD_PATH = "/.well-known/agent-card.json"
LEGACY_AGENT_CARD_PATH = "/.well-known/agent.json"


class A2AError(Exception):
    """Error from an A2A JSON-RPC response."""

    def __init__(self, code: int, message: str, data: Any = None):
        self.code = code
        self.data = data
        super().__init__(message)


class A2AClient:
    def __init__(self, base_url: str, api_key: str | None = None):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    def get_agent_card(self) -> dict:
        """Fetch the agent card.

        Tries the current spec path first
        (``/.well-known/agent-card.json``), falls back to the legacy
        ``/.well-known/agent.json`` for older A2A servers.
        """
        for path in (AGENT_CARD_PATH, LEGACY_AGENT_CARD_PATH):
            try:
                return self._get(self.base_url + path)
            except A2AError as e:
                if e.code != 404:
                    raise
        raise A2AError(404, "Agent card not found at either spec or legacy path")

    def send_message(self, text: str, task_id: str | None = None) -> dict:
        """JSON-RPC ``message/send``.

        If *text* is valid JSON, it is sent as a DataPart so the agent
        can extract structured parameters. Otherwise it is sent as a
        TextPart.
        """
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                part = {"kind": "data", "data": data}
            else:
                part = {"kind": "text", "text": text}
        except (json.JSONDecodeError, ValueError):
            part = {"kind": "text", "text": text}

        message: dict[str, Any] = {
            "role": "user",
            "kind": "message",
            "messageId": str(uuid.uuid4()),
            "parts": [part],
        }
        if task_id:
            message["taskId"] = task_id
        return self._jsonrpc("message/send", {"message": message})

    def get_task(self, task_id: str) -> dict:
        """JSON-RPC ``tasks/get``."""
        return self._jsonrpc("tasks/get", {"id": task_id})

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json", "Accept": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def _get(self, url: str) -> dict:
        headers = {"Accept": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        req = urllib.request.Request(url, headers=headers)
        try:
            resp = urllib.request.urlopen(req, timeout=30)
            return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = e.read().decode() if e.fp else ""
            raise A2AError(e.code, f"HTTP {e.code}: {body}")

    def _jsonrpc(self, method: str, params: dict) -> dict:
        """Send a JSON-RPC 2.0 request and return the result."""
        payload = {
            "jsonrpc": "2.0",
            "id": str(uuid.uuid4()),
            "method": method,
            "params": params,
        }
        data = json.dumps(payload).encode()
        # A2A servers (and their gateway proxies) typically expect the JSON-RPC
        # endpoint at the trailing-slash form; without it Starlette returns 307
        # which urllib can't auto-follow for POST.
        req = urllib.request.Request(
            self.base_url + "/", data=data, headers=self._headers(), method="POST"
        )
        try:
            resp = urllib.request.urlopen(req, timeout=120)
            body = json.loads(resp.read())
        except urllib.error.HTTPError as e:
            raw = e.read().decode() if e.fp else ""
            try:
                body = json.loads(raw)
            except (json.JSONDecodeError, ValueError):
                raise A2AError(e.code, f"HTTP {e.code}: {raw}")

        if "error" in body:
            err = body["error"]
            # JSON-RPC-compliant servers return an error object (dict with
            # `code` / `message` / `data`), but some proxies (and FastAPI's
            # default exception handlers) return `{"error": "<string>"}`
            # instead. Handle both shapes rather than crashing on .get().
            if isinstance(err, dict):
                raise A2AError(
                    err.get("code", -1),
                    err.get("message", "Unknown error"),
                    err.get("data"),
                )
            raise A2AError(-1, str(err))
        return body.get("result", body)
