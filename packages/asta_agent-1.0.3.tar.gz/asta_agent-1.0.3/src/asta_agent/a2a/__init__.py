"""A2A protocol client utilities (CLI + Python client).

The ``[a2a-client]`` install extra is required for the Click CLI commands.
The :class:`A2AClient` itself uses only the Python standard library and is
importable without the extra.

Protocol types come from ``a2a.types`` (a2a-sdk >= 0.3) — see the A2A spec
at https://a2a-protocol.org/latest/specification/.
"""

from asta_agent.a2a.client import A2AClient, A2AError

__all__ = ["A2AClient", "A2AError"]
