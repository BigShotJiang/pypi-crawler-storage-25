"""A2A CLI commands.

Exposes a ``a2a`` Click group (``card``, ``send-message``, ``task``).
Plugins (e.g. asta-plugins) register this group inside their own ``asta``
CLI; a standalone ``asta-a2a`` console_script is also provided.

``make_a2a_group`` creates a named Click group with the same three
subcommands but with the agent URL baked in — useful for plugin commands
like ``asta generate-theories`` that always talk to the same backend.
"""

import json
import os
import sys
from collections.abc import Callable

import click
from a2a.types import AgentCard, Task

from asta_agent.a2a.client import A2AClient, A2AError


def _get_api_key(api_key: str | None) -> str | None:
    """Resolve the bearer token in priority order.

    1. ``--api-key`` flag
    2. ``ASTA_A2A_API_KEY`` / ``API_KEY`` env vars
    3. ``asta auth`` token (lazy import; only present in asta-plugins envs)
    """
    if api_key:
        return api_key
    if env := (os.environ.get("ASTA_A2A_API_KEY") or os.environ.get("API_KEY")):
        return env
    try:
        from asta.utils.auth_helper import get_access_token
    except ImportError:
        # asta-sdk-only env: plugins not installed. Return None and let the
        # caller surface a "no token" error.
        return None
    try:
        return get_access_token()
    except Exception as e:
        raise click.UsageError(
            f"No API key provided and `asta auth` lookup failed: {e}\n"
            "Pass --api-key, set ASTA_A2A_API_KEY, or run `asta auth login`."
        ) from e


@click.group()
def a2a():
    """A2A (Agent-to-Agent) protocol client commands."""
    pass


@a2a.command()
@click.option("--url", required=True, help="Base URL of the A2A agent")
@click.option(
    "--api-key",
    default=None,
    help="Bearer token (or set ASTA_A2A_API_KEY / API_KEY, or run `asta auth login`)",
)
def card(url: str, api_key: str | None):
    """Fetch an agent's Agent Card."""
    try:
        client = A2AClient(url, api_key=_get_api_key(api_key))
        result = client.get_agent_card()
        agent_card = AgentCard.model_validate(result)
        click.echo(agent_card.model_dump_json(by_alias=True, indent=2, exclude_none=True))
    except A2AError as e:
        click.echo(
            json.dumps({"error": {"code": e.code, "message": str(e)}}, indent=2),
            err=True,
        )
        sys.exit(1)
    except Exception as e:
        click.echo(json.dumps({"error": {"message": str(e)}}, indent=2), err=True)
        sys.exit(1)


@a2a.command("send-message")
@click.option("--url", required=True, help="Base URL of the A2A agent")
@click.option(
    "--api-key",
    default=None,
    help="Bearer token (or set ASTA_A2A_API_KEY / API_KEY, or run `asta auth login`)",
)
@click.option("--task-id", default=None, help="Existing task ID to continue")
@click.option(
    "--file",
    "-f",
    multiple=True,
    type=(str, click.Path(exists=True)),
    help="Merge a JSON file into the message: --file key path.json",
)
@click.argument("message")
def send_message(
    url: str,
    api_key: str | None,
    task_id: str | None,
    file: tuple[tuple[str, str], ...],
    message: str,
):
    """Send a message to an A2A agent.

    MESSAGE is JSON or plain text. Use --file to merge large JSON files
    into the message without inlining them.

    Examples:

        asta a2a send-message --url http://localhost:9000 '{"theory_query": "X?"}'

        asta a2a send-message --url http://localhost:9000 \\
          --file paper_store /path/to/papers.json \\
          '{"theory_query": "X?", "max_papers_to_retrieve": 10}'
    """
    try:
        if file:
            try:
                data = json.loads(message)
            except (json.JSONDecodeError, ValueError):
                raise click.UsageError("MESSAGE must be valid JSON when using --file")
            if not isinstance(data, dict):
                raise click.UsageError("MESSAGE must be a JSON object when using --file")
            for key, path in file:
                with open(path) as f:
                    data[key] = json.load(f)
            message = json.dumps(data)

        client = A2AClient(url, api_key=_get_api_key(api_key))
        result = client.send_message(message, task_id=task_id)
        click.echo(json.dumps(result, indent=2))
    except A2AError as e:
        click.echo(
            json.dumps({"error": {"code": e.code, "message": str(e)}}, indent=2),
            err=True,
        )
        sys.exit(1)
    except Exception as e:
        click.echo(json.dumps({"error": {"message": str(e)}}, indent=2), err=True)
        sys.exit(1)


@a2a.command()
@click.option("--url", required=True, help="Base URL of the A2A agent")
@click.option(
    "--api-key",
    default=None,
    help="Bearer token (or set ASTA_A2A_API_KEY / API_KEY, or run `asta auth login`)",
)
@click.argument("task_id")
def task(url: str, api_key: str | None, task_id: str):
    """Poll a task's current status.

    Example:

        asta a2a task --url http://localhost:9000 abc-123-def
    """
    try:
        client = A2AClient(url, api_key=_get_api_key(api_key))
        result = client.get_task(task_id)
        parsed = Task.model_validate(result)
        click.echo(parsed.model_dump_json(by_alias=True, indent=2, exclude_none=True))
    except A2AError as e:
        click.echo(
            json.dumps({"error": {"code": e.code, "message": str(e)}}, indent=2),
            err=True,
        )
        sys.exit(1)
    except Exception as e:
        click.echo(json.dumps({"error": {"message": str(e)}}, indent=2), err=True)
        sys.exit(1)


def make_a2a_group(
    name: str,
    url_factory: Callable[[], str],
    help: str | None = None,
) -> click.Group:
    """Create a Click group with baked-in A2A agent URL.

    The returned group has ``card``, ``send-message``, and ``task``
    subcommands identical to the generic ``a2a`` group, but without a
    ``--url`` flag — the URL is resolved at call time via ``url_factory``.

    Usage::

        def _url() -> str:
            base = os.environ.get("ASTA_GATEWAY_URL", "https://...")
            return f"{base}/api/my-agent"

        my_agent = make_a2a_group(name="my-agent", url_factory=_url,
                                  help="Talk to My Agent.")
        cli.add_command(my_agent)
    """

    def _error(e: Exception) -> None:
        if isinstance(e, A2AError):
            payload = {"error": {"code": e.code, "message": str(e)}}
        else:
            payload = {"error": {"message": str(e)}}
        click.echo(json.dumps(payload, indent=2), err=True)
        sys.exit(1)

    group = click.Group(name=name, help=help)

    @group.command()
    @click.option(
        "--api-key",
        default=None,
        help="Bearer token (falls back to ASTA_A2A_API_KEY or `asta auth`).",
    )
    def card(api_key: str | None) -> None:
        """Fetch the agent card."""
        try:
            result = A2AClient(url_factory(), api_key=_get_api_key(api_key)).get_agent_card()
            click.echo(AgentCard.model_validate(result).model_dump_json(by_alias=True, indent=2, exclude_none=True))
        except Exception as e:
            _error(e)

    @group.command("send-message")
    @click.option(
        "--api-key",
        default=None,
        help="Bearer token (falls back to ASTA_A2A_API_KEY or `asta auth`).",
    )
    @click.option("--task-id", default=None, help="Existing task ID to continue.")
    @click.option(
        "--file",
        "-f",
        multiple=True,
        type=(str, click.Path(exists=True)),
        help="Merge a JSON file into the message: --file key path.json",
    )
    @click.argument("message")
    def send_message(
        api_key: str | None,
        task_id: str | None,
        file: tuple[tuple[str, str], ...],
        message: str,
    ) -> None:
        """Submit a new task or continue an existing one.

        MESSAGE is a JSON object with the agent's task parameters.
        """
        try:
            if file:
                try:
                    data = json.loads(message)
                except (json.JSONDecodeError, ValueError):
                    raise click.UsageError("MESSAGE must be valid JSON when using --file")
                if not isinstance(data, dict):
                    raise click.UsageError("MESSAGE must be a JSON object when using --file")
                for key, path in file:
                    with open(path) as f:
                        data[key] = json.load(f)
                message = json.dumps(data)
            result = A2AClient(url_factory(), api_key=_get_api_key(api_key)).send_message(message, task_id=task_id)
            click.echo(json.dumps(result, indent=2))
        except Exception as e:
            _error(e)

    @group.command()
    @click.option(
        "--api-key",
        default=None,
        help="Bearer token (falls back to ASTA_A2A_API_KEY or `asta auth`).",
    )
    @click.argument("task_id")
    def task(api_key: str | None, task_id: str) -> None:
        """Poll a task's current status."""
        try:
            result = A2AClient(url_factory(), api_key=_get_api_key(api_key)).get_task(task_id)
            click.echo(Task.model_validate(result).model_dump_json(by_alias=True, indent=2, exclude_none=True))
        except Exception as e:
            _error(e)

    return group


if __name__ == "__main__":
    a2a()
