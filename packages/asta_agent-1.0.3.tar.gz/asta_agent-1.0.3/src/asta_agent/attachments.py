"""Utilities for parsing and fetching attachments from A2A message text."""

from __future__ import annotations

import json
import logging
import re

log = logging.getLogger(__name__)

_ATTACHMENT_RE = re.compile(
    r'<astaattachment[^>]+s3_uri="(s3://[^"]+)"[^>]*>[^<]*</astaattachment>',
    re.IGNORECASE,
)


def extract_attachments(text: str) -> tuple[str, list[str]]:
    """Extract S3 URIs from <astaattachment> tags in text.

    Returns (cleaned_text, list_of_s3_uris).
    """
    uris = _ATTACHMENT_RE.findall(text)
    cleaned = _ATTACHMENT_RE.sub("", text).strip()
    return cleaned, uris


def fetch_s3_json(s3_uri: str) -> dict | None:
    """Fetch and parse a JSON file from S3. Returns None on failure."""
    try:
        import boto3
        parts = s3_uri.replace("s3://", "").split("/", 1)
        bucket, key = parts[0], parts[1]
        s3 = boto3.client("s3")
        resp = s3.get_object(Bucket=bucket, Key=key)
        return json.loads(resp["Body"].read())
    except Exception:
        log.exception("Failed to fetch %s", s3_uri)
        return None


def extract_s3_json(text: str) -> tuple[str, dict | None]:
    """Extract the first <astaattachment> from text, fetch its JSON from S3.

    Returns (cleaned_text, parsed_json_or_none).
    """
    cleaned, uris = extract_attachments(text)
    if not uris:
        return text, None
    log.info("Found attachment: %s", uris[0])
    data = fetch_s3_json(uris[0])
    if data:
        log.info("Loaded JSON from %s", uris[0])
    return cleaned, data
