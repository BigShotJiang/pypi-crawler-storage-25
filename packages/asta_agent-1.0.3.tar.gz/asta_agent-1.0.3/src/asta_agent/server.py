"""FastAPI server builder for Asta agents."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from a2a.server.apps.jsonrpc.fastapi_app import A2AFastAPIApplication
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.tasks import InMemoryTaskStore
from a2a.server.tasks.inmemory_push_notification_config_store import (
    InMemoryPushNotificationConfigStore,
)

from asta_agent.executor import AstaAgentExecutor
from asta_agent.registry import build_agent_card

if TYPE_CHECKING:
    from fastapi import FastAPI

    from asta_agent.registry import TaskDef


def _make_store(storage: str | None) -> Any:
    """Create a TaskStore from a storage URL string.

    Args:
        storage: One of:
            - None or "memory" → InMemoryTaskStore
            - "sqlite:///path" → DatabaseTaskStore (SQLite)
            - "postgresql://..." → DatabaseTaskStore (Postgres)
    """
    if storage is None or storage == "memory":
        return InMemoryTaskStore()

    from a2a.server.tasks import DatabaseTaskStore
    from sqlalchemy.ext.asyncio import create_async_engine

    # Convert sync driver URLs to async equivalents
    url = storage
    if url.startswith("postgresql://"):
        url = url.replace("postgresql://", "postgresql+asyncpg://", 1)
    elif url.startswith("sqlite:///"):
        url = url.replace("sqlite:///", "sqlite+aiosqlite:///", 1)

    engine = create_async_engine(url)
    return DatabaseTaskStore(engine, create_table=True)


def build_app(
    name: str,
    description: str,
    version: str,
    tasks: list[TaskDef],
    *,
    storage: str | None = None,
    url: str = "",
    api_key: str | None = None,
) -> FastAPI:
    """Build a FastAPI application for the given Asta agent configuration."""
    agent_card = build_agent_card(
        name=name,
        description=description,
        version=version,
        url=url,
        tasks=tasks,
    )
    task_store = _make_store(storage)
    push_config_store = InMemoryPushNotificationConfigStore()
    executor = AstaAgentExecutor(
        tasks, task_store=task_store, push_config_store=push_config_store,
    )
    handler = DefaultRequestHandler(
        agent_executor=executor,
        task_store=task_store,
        push_config_store=push_config_store,
    )
    a2a_app = A2AFastAPIApplication(
        agent_card=agent_card,
        http_handler=handler,
    )
    app = a2a_app.build()

    @app.get("/healthz")
    async def healthz():
        return {"status": "ok"}

    if api_key:
        from starlette.responses import JSONResponse

        @app.middleware("http")
        async def check_bearer_token(request, call_next):
            if request.url.path == "/healthz":
                return await call_next(request)
            auth = request.headers.get("authorization", "")
            if auth != f"Bearer {api_key}":
                return JSONResponse(status_code=401, content={"error": "Unauthorized"})
            return await call_next(request)

    return app
