"""Step progress model for tracking task execution steps."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Annotated, Any, Optional

from pydantic import BaseModel, Field, PlainSerializer, PrivateAttr

if TYPE_CHECKING:
    from asta_agent.context import AstaContext

UuidStr = Annotated[uuid.UUID, PlainSerializer(lambda x: str(x), return_type=str)]
DatetimeStr = Annotated[
    datetime, PlainSerializer(lambda x: x.isoformat(), return_type=str)
]


class RunState(str, Enum):
    CREATED = "created"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


class StepProgress(BaseModel):
    short_desc: str
    long_desc: Optional[str] = None
    step_id: UuidStr = Field(default_factory=uuid.uuid4)
    parent_step_id: Optional[UuidStr] = None
    task_id: Optional[str] = None
    run_state: RunState = RunState.CREATED
    created_at: Optional[DatetimeStr] = None
    started_at: Optional[DatetimeStr] = None
    finish_est: Optional[DatetimeStr] = None
    finished_at: Optional[DatetimeStr] = None
    error_message: Optional[str] = None

    _ctx: Any = PrivateAttr(default=None)

    def update(self, text: str) -> None:
        """Update this step's description in-place."""
        if self._ctx:
            self._ctx.update_step(short_desc=text, step=self)

    def finish(self, is_success: bool = True) -> None:
        """Finish this step."""
        if self._ctx:
            self._ctx.finish_step(is_success=is_success, step=self)
