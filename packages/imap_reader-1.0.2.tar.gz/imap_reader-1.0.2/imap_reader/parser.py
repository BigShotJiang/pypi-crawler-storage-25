"""
parser.py - Utilities for extracting OTP codes, verification links, and
            parsing email body content from raw IMAP messages.
"""

import re
import quopri
import base64
from email.header import decode_header, make_header
from email.message import Message
from html.parser import HTMLParser
from typing import List, Tuple


# ─── Regex Patterns ───────────────────────────────────────────────────────────

# Matches 5–6 digit OTP codes that are isolated (not part of longer numbers)
_OTP_PATTERN = re.compile(r"(?<!\d)(\d{5,6})(?!\d)")

# Matches http/https URLs
_URL_PATTERN = re.compile(
    r"https?://[^\s\"'<>\)\]]+",
    re.IGNORECASE,
)

# Common verification-related keywords in URLs
_VERIFY_KEYWORDS = re.compile(
    r"(verif|confirm|activate|token|auth|reset|otp|code|validate|secure)",
    re.IGNORECASE,
)


# ─── HTML Stripper ────────────────────────────────────────────────────────────

class _HTMLStripper(HTMLParser):
    """Lightweight HTML-to-text converter."""

    def __init__(self) -> None:
        super().__init__()
        self._parts: List[str] = []

    def handle_data(self, data: str) -> None:
        stripped = data.strip()
        if stripped:
            self._parts.append(stripped)

    def get_text(self) -> str:
        return " ".join(self._parts)

def html_to_text(html: str) -> str:
    """Convert HTML content to plain text."""
    stripper = _HTMLStripper()
    try:
        stripper.feed(html)
        return stripper.get_text()
    except Exception:
        # Fallback: strip tags with regex if parser fails
        return re.sub(r"<[^>]+>", " ", html)


# ─── Header Decoding ──────────────────────────────────────────────────────────

def decode_mime_header(raw_header: str) -> str:
    """Decode MIME-encoded email headers (e.g. =?utf-8?b?...?=)."""
    if not raw_header:
        return ""
    try:
        return str(make_header(decode_header(raw_header)))
    except Exception:
        return raw_header


# ─── Body Decoding ────────────────────────────────────────────────────────────

def decode_payload(part: Message) -> str:
    """Decode a message part payload to a UTF-8 string."""
    payload: bytes = part.get_payload(decode=True) # type: ignore
    if not payload:
        return ""

    charset = part.get_content_charset() or "utf-8"
    encoding = part.get("Content-Transfer-Encoding", "").lower()

    try:
        if encoding == "quoted-printable":
            payload: bytes = quopri.decodestring(payload)
        elif encoding == "base64":
            payload = base64.decodebytes(payload)

        return payload.decode(charset, errors="replace")
    except Exception:
        return payload.decode("utf-8", errors="replace")


# ─── Email Body Extraction ────────────────────────────────────────────────────

def extract_bodies(msg: Message) -> Tuple[str, str]:
    """
    Walk a parsed email message and extract plain text and HTML bodies.

    Returns:
        (text_body, html_body) as strings.
    """
    text_parts: List[str] = []
    html_parts: List[str] = []

    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            disposition = part.get("Content-Disposition", "")

            if "attachment" in disposition:
                continue

            if content_type == "text/plain":
                text_parts.append(decode_payload(part))
            elif content_type == "text/html":
                html_parts.append(decode_payload(part))
    else:
        content_type = msg.get_content_type()
        if content_type == "text/plain":
            text_parts.append(decode_payload(msg))
        elif content_type == "text/html":
            html_parts.append(decode_payload(msg))

    return "\n".join(text_parts), "\n".join(html_parts)


# ─── OTP & Link Extraction ────────────────────────────────────────────────────

def extract_otp_codes(text: str) -> List[str]:
    """
    Extract likely OTP/verification codes from text content.
    Deduplicates and returns in order of appearance.
    """
    matches = _OTP_PATTERN.findall(text)
    seen: set = set()
    result: List[str] = []
    for code in matches:
        if code not in seen:
            seen.add(code)
            result.append(code)
    return result

def extract_verification_links(text: str, html: str) -> List[str]:
    """
    Extract verification/confirmation URLs from text and HTML content.
    Prioritizes links with verification-related keywords.
    """
    # Search both plain text and raw HTML for URLs
    combined = f"{text}\n{html}"
    all_urls = _URL_PATTERN.findall(combined)

    # Clean trailing punctuation that may be part of surrounding text
    cleaned = [url.rstrip(".,;:!?)>]\"'") for url in all_urls]

    # Deduplicate while preserving order
    seen: set = set()
    unique_urls: List[str] = []
    for url in cleaned:
        if url not in seen:
            seen.add(url)
            unique_urls.append(url)

    # Sort: verification links first, rest after
    verify_links = [u for u in unique_urls if _VERIFY_KEYWORDS.search(u)]
    other_links = [u for u in unique_urls if not _VERIFY_KEYWORDS.search(u)]

    return verify_links + other_links


# ─── Anchor Link by Text ──────────────────────────────────────────────────────

class _AnchorTextParser(HTMLParser):
    """
    Parse HTML and collect <a href="..."> whose visible text
    matches a given keyword (case-insensitive, searches inner text + child tags).
    """

    def __init__(self, keyword: str) -> None:
        super().__init__()
        self.keyword = keyword.lower()
        self.results: List[str] = []

        self._current_href: str = ""
        self._current_text: str = ""
        self._inside_anchor: bool = False
        self._depth: int = 0  # track nested tags inside <a>

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag == "a":
            href = dict(attrs).get("href", "")
            self._current_href = href or ""
            self._current_text = ""
            self._inside_anchor = True
            self._depth = 0
        elif self._inside_anchor:
            self._depth += 1

    def handle_endtag(self, tag: str) -> None:
        if self._inside_anchor:
            if tag == "a" and self._depth == 0:
                # Closing the <a> tag — check collected text
                if self.keyword in self._current_text.lower():
                    href = self._current_href.strip()
                    if href and href not in self.results:
                        self.results.append(href)
                self._inside_anchor = False
                self._current_href = ""
                self._current_text = ""
            elif self._depth > 0:
                self._depth -= 1

    def handle_data(self, data: str) -> None:
        if self._inside_anchor:
            self._current_text += data

def extract_link_by_anchor_text(html: str, keyword: str) -> List[str]:
    """
    Find all <a href="..."> whose visible inner text contains the keyword.

    Case-insensitive. Works even when the text is inside a child <span> or
    any nested tag within the anchor element.

    Args:
        html:    Raw HTML string from the email body.
        keyword: Text to search for inside the anchor (e.g. "Izinkan Log In").

    Returns:
        List of matching href URLs. Empty list if none found.

    Example:
        links = extract_link_by_anchor_text(msg.body_html, "Izinkan Log In")
        # ['https://id.shp.ee/dlink/gokn2xmv']
    """
    parser = _AnchorTextParser(keyword)
    try:
        parser.feed(html)
    except Exception:
        pass
    return parser.results