"""
client.py - Core ImapClient client for connecting to IMAP servers,
            fetching messages, and extracting OTP codes / verification links.
"""

import imaplib
import socket
import threading
from email import message_from_bytes
from typing import Generator, List, Optional

from .exceptions import (
    AuthenticationError,
    ConnectionTimeoutError,
    ImapNotFoundError,
)
from .models import DEFAULT_IMAP_LIST, EmailMessage, ImapItemModel, ImapCriteria, ImapFolder, EmailStr
from .parser import (
    decode_mime_header,
    extract_bodies,
    extract_otp_codes,
    extract_verification_links,
    html_to_text,
)

# ─── Type Aliases ─────────────────────────────────────────────────────────────


class ImapClient:
    """
    IMAP email client with automatic provider detection, OTP extraction,
    verification link parsing, and configurable login timeout.

    Example:
        with ImapClient(
            email_address="user@gmail.com",
            password_email="app_password",
            timeout=45,
        ) as client:
            for msg in client.get_messages("UNSEEN"):
                print(msg.subject, msg.otp_codes, msg.verification_links)
    """

    def __init__(
        self,
        email_address: EmailStr | str,
        password_email: str,
        imap_list: Optional[List[ImapItemModel]] = None,
        use_default_imap: bool = True,
        timeout: int = 30,
    ) -> None:
        """
        Args:
            email_address:      Full email address (e.g. user@gmail.com).
            password_email:     IMAP password or app-specific password.
            imap_list:          List of ImapItemModel providers to search.
                                Falls back to DEFAULT_IMAP_LIST if not provided.
            use_default_imap:   set imap to "imap.{domain}" if domain is not in imap_list.        
            timeout:            Seconds to wait for IMAP connection + login
                                before raising ConnectionTimeoutError (default 30,
                                recommended range 30-60).
        """
        self.email_address = EmailStr(email_address.strip().lower())
        self.password_email = password_email
        self.imap_list = imap_list or DEFAULT_IMAP_LIST
        self.timeout = timeout

        self._imap_config: ImapItemModel = self._resolve_imap_config(use_default_imap)
        self._connection: Optional[imaplib.IMAP4] = None

    # ─── Public API ───────────────────────────────────────────────────────────

    def get_messages(
        self,
        criteria: ImapCriteria = "UNSEEN",
        folder: ImapFolder = "INBOX",
        limit: Optional[int] = None,
        mark_seen: bool = True,
    ) -> Generator[EmailMessage, None, None]:
        """
        Fetch and yield parsed email messages from the mailbox.

        Args:
            criteria:   IMAP search criteria: "ALL", "SEEN", or "UNSEEN".
            folder:     Mailbox folder to search (default "INBOX").
            limit:      Maximum number of messages to return. None = all.
            mark_seen:  If True, mark fetched messages as seen (default False).

        Yields:
            EmailMessage objects.
        """
        conn = self._get_connection()

        conn.select(folder, readonly=not mark_seen)
        _, uid_data = conn.uid("search", None, criteria) # type: ignore

        uids = uid_data[0].split() if uid_data and uid_data[0] else []

        if limit is not None:
            uids = uids[-limit:]  # take the most recent N

        for uid in uids:
            msg = self._fetch_message(conn, uid)
            if msg:
                yield msg

    def get_latest_message(
        self,
        criteria: ImapCriteria = "UNSEEN",
        folder: ImapFolder = "INBOX",
    ) -> Optional[EmailMessage]:
        """
        Convenience method: fetch only the single latest matching message.

        Returns None if no messages match the criteria.
        """
        messages = list(self.get_messages(criteria=criteria, folder=folder, limit=1))
        return messages[0] if messages else None

    def delete_messages(
        self,
        criteria: ImapCriteria = "ALL",
        folder: ImapFolder = "INBOX",
    ) -> int:
        """
        Delete all messages matching the given criteria from the folder.

        Messages are first marked with the \\Deleted flag, then permanently
        removed via EXPUNGE.

        Args:
            criteria:   Which messages to delete: "ALL", "SEEN", or "UNSEEN".
            folder:     Mailbox folder to target (default "INBOX").

        Returns:
            Number of messages deleted.

        Example:
            count = client.delete_messages("SEEN")
            print(f"Deleted {count} read emails.")
        """
        conn = self._get_connection()

        conn.select(folder, readonly=False)
        _, uid_data = conn.uid("search", None, criteria) # type: ignore

        uids = uid_data[0].split() if uid_data and uid_data[0] else []

        for uid in uids:
            conn.uid("store", uid, "+FLAGS", "\\Deleted")

        conn.expunge()
        return len(uids)

    def close(self) -> None:
        """Gracefully close the IMAP connection."""
        if self._connection:
            try:
                self._connection.close()
                self._connection.logout()
            except Exception:
                pass
            finally:
                self._connection = None

    # ─── Context Manager Support ──────────────────────────────────────────────

    def __enter__(self) -> "ImapClient":
        return self

    def __exit__(self, *_) -> None:
        self.close()

    # ─── Internal Helpers ─────────────────────────────────────────────────────

    def _resolve_imap_config(self, use_default_imap: bool) -> ImapItemModel:
        """Match the email domain to a known IMAP provider config."""
        domain = self.email_address.split("@")[-1]
        for item in self.imap_list:
            if item.domain == domain:
                return item
        
        if use_default_imap:
            return ImapItemModel(domain=domain, imap_host=f'mail.{domain}')
            
        raise ImapNotFoundError(
            f"No IMAP configuration found for domain '{domain}'. "
            "Add a custom ImapItemModel to imap_list."
        )

    def _connect_with_timeout(self) -> imaplib.IMAP4 | imaplib.IMAP4_SSL:
        """
        Establish an IMAP connection and authenticate within the timeout window.

        Raises:
            ConnectionTimeoutError: If login takes longer than self.timeout seconds.
            AuthenticationError:    If credentials are rejected by the server.
        """
        result: dict = {}
        exception_holder: dict = {}

        def _do_connect() -> None:
            try:
                cfg = self._imap_config
                if cfg.use_ssl:
                    conn = imaplib.IMAP4_SSL(host=cfg.imap_host, port=cfg.imap_port)
                else:
                    conn = imaplib.IMAP4(host=cfg.imap_host, port=cfg.imap_port)
                conn.login(self.email_address, self.password_email)
                result["conn"] = conn
            except imaplib.IMAP4.error as exc:
                exception_holder["error"] = AuthenticationError(
                    f"IMAP login failed for '{self.email_address}': {exc}"
                )
            except (OSError, socket.error) as exc:
                exception_holder["error"] = ConnectionError(
                    f"Could not reach IMAP server '{self._imap_config.imap_host}': {exc}"
                )

        thread = threading.Thread(target=_do_connect, daemon=True)
        thread.start()
        thread.join(timeout=self.timeout)

        if thread.is_alive():
            raise ConnectionTimeoutError(
                f"IMAP login timed out after {self.timeout}s "
                f"for '{self.email_address}' on '{self._imap_config.imap_host}'."
            )

        if "error" in exception_holder:
            raise exception_holder["error"]

        return result["conn"]

    def _get_connection(self) -> imaplib.IMAP4:
        """Return existing connection or create a new one."""
        if self._connection is None:
            self._connection = self._connect_with_timeout()
        return self._connection

    def _fetch_message(
        self,
        conn: imaplib.IMAP4,
        uid: bytes,
    ) -> Optional[EmailMessage]:
        """Fetch a single message by UID and return a parsed EmailMessage."""
        _, msg_data = conn.uid("fetch", uid, "(RFC822)") # type: ignore

        if not msg_data or msg_data[0] is None:
            return None

        raw_email = msg_data[0][1]
        if not isinstance(raw_email, bytes):
            return None

        parsed = message_from_bytes(raw_email)
        text_body, html_body = extract_bodies(parsed)

        # Use HTML-stripped text for OTP/link extraction if plain text is empty
        searchable_text = text_body or html_to_text(html_body)

        return EmailMessage(
            uid=uid.decode(),
            subject=decode_mime_header(parsed.get("Subject", "")),
            sender=decode_mime_header(parsed.get("From", "")),
            date=parsed.get("Date", ""),
            body_text=text_body,
            body_html=html_body,
            otp_codes=extract_otp_codes(searchable_text),
            verification_links=extract_verification_links(text_body, html_body),
        )