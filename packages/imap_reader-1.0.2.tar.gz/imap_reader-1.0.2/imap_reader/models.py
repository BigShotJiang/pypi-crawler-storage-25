"""
models.py - Data models and default IMAP provider configurations.
"""

from dataclasses import dataclass, field
from typing import List, Literal
import re

ImapCriteria = Literal["ALL", "SEEN", "UNSEEN"]
ImapFolder   = Literal["INBOX", "SENT", "DRAFTS", "TRASH", "SPAM", "JUNK"]

@dataclass
class ImapItemModel:
    """Represents an IMAP server configuration for a specific email domain."""

    domain: str
    imap_host: str
    imap_port: int = 993
    use_ssl: bool = True

    def __repr__(self) -> str:
        return f"ImapItemModel(domain='{self.domain}', host='{self.imap_host}:{self.imap_port}')"

class EmailStr(str):
    """
    Custom email string type with validation.
    Behaves like a str but validates email format on creation.
    
    Example:
        email = EmailStr("user@gmail.com")  # ✅
        email = EmailStr("invalid-email")   # ❌ raises ValueError
    """
    
    _pattern = re.compile(
        r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"
    )
    
    def __new__(cls, value: str) -> "EmailStr":
        if not isinstance(value, str):
            raise TypeError(f"EmailStr requires a string, got {type(value).__name__}")
        value = value.strip().lower()
        if not cls._pattern.match(value):
            raise ValueError(f"Invalid email address: {value!r}")
        return super().__new__(cls, value)
    
    @property
    def domain(self) -> str:
        return self.split("@")[1]
    
    @property
    def username(self) -> str:
        return self.split("@")[0]

@dataclass
class EmailMessage:
    """Parsed email message with all relevant fields."""

    uid: str
    subject: str
    sender: str
    date: str
    body_text: str
    body_html: str
    otp_codes: List[str] = field(default_factory=list)
    verification_links: List[str] = field(default_factory=list)

    def __repr__(self) -> str:
        return (
            f"EmailMessage(uid='{self.uid}', subject='{self.subject}', "
            f"from='{self.sender}', otps={self.otp_codes}), date={self.date},"
            f"verification_links='{self.verification_links}')"
        )

# ─── Default IMAP Providers ───────────────────────────────────────────────────

DEFAULT_IMAP_LIST: List[ImapItemModel] = [
    ImapItemModel(domain="gmail.com",       imap_host="imap.gmail.com"),
    ImapItemModel(domain="yahoo.com",       imap_host="imap.mail.yahoo.com"),
    ImapItemModel(domain="yahoo.co.id",     imap_host="imap.mail.yahoo.com"),
    ImapItemModel(domain="outlook.com",     imap_host="outlook.office365.com"),
    ImapItemModel(domain="hotmail.com",     imap_host="outlook.office365.com"),
    ImapItemModel(domain="protonmail.com",  imap_host="127.0.0.1",  imap_port=1143, use_ssl=False),
    ImapItemModel(domain="proton.me",       imap_host="127.0.0.1",  imap_port=1143, use_ssl=False),
    ImapItemModel(domain="zoho.com",        imap_host="imap.zoho.com"),
    ImapItemModel(domain="aol.com",         imap_host="imap.aol.com"),
]
