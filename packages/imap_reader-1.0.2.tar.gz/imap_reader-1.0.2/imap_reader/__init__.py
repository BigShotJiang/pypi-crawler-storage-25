"""
imap_reader - A clean, efficient Python library for reading verification emails via IMAP.
"""

from .client import ImapClient
from .models import ImapItemModel, DEFAULT_IMAP_LIST
from .parser import extract_link_by_anchor_text
from .exceptions import (
    ImapClientError,
    AuthenticationError,
    ConnectionTimeoutError,
    ImapNotFoundError,
)

__version__ = "1.0.2"
__all__ = [
    "ImapClient",
    "ImapItemModel",
    "DEFAULT_IMAP_LIST",
    "extract_link_by_anchor_text",
    "ImapClientError",
    "AuthenticationError",
    "ConnectionTimeoutError",
    "ImapNotFoundError",
]