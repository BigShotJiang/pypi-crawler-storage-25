"""
exceptions.py - Custom exceptions for imap_reader library.
"""


class ImapClientError(Exception):
    """Base exception for all imap_reader errors."""


class AuthenticationError(ImapClientError):
    """Raised when IMAP login fails due to wrong credentials."""


class ConnectionTimeoutError(ImapClientError):
    """Raised when the IMAP connection or login exceeds the timeout limit."""


class ImapNotFoundError(ImapClientError):
    """Raised when no matching IMAP config is found for the given email domain."""
