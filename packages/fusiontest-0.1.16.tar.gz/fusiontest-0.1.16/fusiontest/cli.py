"""
fusiontest/cli.py

The `fusiontest` CLI — run tests from the command line or CI.

Commands:
  fusiontest run    — run a test goal or goal file
  fusiontest demo   — run a pre-built demo against a public site (no app needed)
  fusiontest init   — scaffold a fusiontest.config.yaml in the current directory
  fusiontest report — print the last run result
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import click
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

console = Console()


@click.group()
@click.version_option(version="0.1.16", prog_name="FusionTest")
def main():
    """FusionTest — AI-powered UI testing for mobile and desktop.\n\nby FusionLeap.io"""
    pass


# ── fusiontest run ──────────────────────────────────────────────────────────────

@main.command()
@click.option("--goal", "-g", multiple=True, help="Natural language test goal (repeatable)")
@click.option("--file", "-f", "goal_file", type=click.Path(exists=True), help="YAML file of goals")
@click.option("--platform", "-p",
              type=click.Choice(["android", "ios", "playwright", "electron"]),
              default="playwright", show_default=True)
@click.option("--app", type=click.Path(), help="Path to .apk / .ipa / Electron binary")
@click.option("--url", help="URL to open (for playwright/web targets)")
@click.option("--locale", default="en-US", show_default=True, help="Locale for the test run")
@click.option("--backend", type=click.Choice(["gpt4o", "claude", "gemini", "groq", "ollama", "mpnet"]),
              default="gpt4o", show_default=True, help="AI model backend")
@click.option("--headless/--no-headless", default=False, show_default=True)
@click.option("--output", "-o", type=click.Path(), help="Write JSON report to this path")
@click.option("--config", "config_file", type=click.Path(),
              default=None, help="Config file (default: fusiontest.config.yaml if present)")
def run(goal, goal_file, platform, app, url, locale, backend, headless, output, config_file):
    """Run a FusionTest test — provide goals via --goal or --file."""

    from dotenv import load_dotenv
    load_dotenv(override=True)

    import os as _os

    # Load config file first so it can be overridden by goal-file or explicit flags.
    cfg = {}
    config_path = Path(config_file) if config_file else Path("fusiontest.config.yaml")
    if config_path.exists():
        with open(config_path) as f:
            cfg = yaml.safe_load(f) or {}

    # Resolve goals
    goals = list(goal)
    goal_urls: list[str | None] = []   # per-goal URL overrides (from dict-style goals)
    if goal_file:
        with open(goal_file) as f:
            data = yaml.safe_load(f)
        raw_goals = data.get("goals", [])
        platform = data.get("platform", platform)
        locale = data.get("locale", locale)
        # Goals file can override backend; config file sets the project default.
        backend = data.get("backend", backend)
        if not url and data.get("url"):
            url = data["url"]

        # Goals can be plain strings OR dicts with {name, url, goal} keys
        for g in raw_goals:
            if isinstance(g, dict):
                goals.append(g.get("goal") or g.get("name") or str(g))
                goal_urls.append(g.get("url"))
            else:
                goals.append(str(g))
                goal_urls.append(None)

    if not goals:
        console.print("[red]Error:[/red] No goals provided. Use --goal or --file.")
        sys.exit(1)

    # Backend resolution — priority (highest to lowest):
    #   1. --backend CLI flag (already set above if explicitly passed)
    #   2. backend: key in goals YAML file       (set above in goal_file block)
    #   3. backend: key in fusiontest.config.yaml (project-level preference)
    #   4. Auto-detect from available API keys    (no config needed)
    if backend == "gpt4o":  # "gpt4o" is the Click default — treat as "not explicitly set"
        cfg_backend = cfg.get("backend", "")
        if cfg_backend in ("groq", "claude", "gemini", "ollama", "gpt4o", "mpnet"):
            backend = cfg_backend
        # If still at default and OPENAI_API_KEY is absent, auto-detect from env
        if backend == "gpt4o" and not _os.getenv("OPENAI_API_KEY"):
            if _os.getenv("GROQ_API_KEY"):
                backend = "groq"
            elif _os.getenv("ANTHROPIC_API_KEY"):
                backend = "claude"
            elif _os.getenv("GEMINI_API_KEY"):
                backend = "gemini"
            elif _is_ollama_running():
                backend = "ollama"
            else:
                console.print()
                console.print(Panel(
                    "[bold red]No AI backend configured.[/bold red]\n\n"
                    "FusionTest needs an LLM key to run. Quickest option (free):\n\n"
                    "  [bold]1.[/bold] Get a free Groq key at [link=https://console.groq.com]https://console.groq.com[/link]\n"
                    "  [bold]2.[/bold] Add it to your environment:\n"
                    "     [cyan]export GROQ_API_KEY=gsk_...[/cyan]\n"
                    "     [dim](or add to a .env file in this directory)[/dim]\n\n"
                    "Other options:\n"
                    "  [cyan]export ANTHROPIC_API_KEY=sk-ant-...[/cyan]  (Claude)\n"
                    "  [cyan]export GEMINI_API_KEY=AIza...[/cyan]         (Gemini, free)\n"
                    "  [cyan]export OPENAI_API_KEY=sk-...[/cyan]          (GPT-4o)\n\n"
                    "Or run a local model with Ollama:\n"
                    "  [cyan]ollama pull qwen2.5:7b && ollama serve[/cyan]",
                    title="Setup required",
                    border_style="red",
                ))
                sys.exit(1)

    # Print header
    console.print()
    console.print(Panel.fit(
        f"[bold]FusionTest[/bold] by FusionLeap.io\n"
        f"Platform: [cyan]{platform}[/cyan]  ·  Backend: [cyan]{backend}[/cyan]  ·  Locale: [cyan]{locale}[/cyan]",
        border_style="blue",
    ))
    # Build adapter
    adapter = _build_adapter(platform, app, url, headless)

    # Build runner — enable step logging when an API key is present so every
    # (goal, screen, action, outcome) tuple is captured for training-data.
    import os as _os
    import tempfile
    _api_key  = _os.getenv("FUSIONTEST_API_KEY")
    _step_log_tmp: str | None = None
    if _api_key:
        _fd, _step_log_tmp = tempfile.mkstemp(suffix=".jsonl", prefix="ft-steps-")
        _os.close(_fd)

    from fusiontest.core.runner import FusionTestRunner, RunnerConfig
    from fusiontest.guardrails.engine import GuardrailsConfig

    # Load named secrets from the config file's `secrets:` block.
    # Each value is resolved from environment variables so the config file
    # itself never contains plaintext credentials — only variable names.
    #
    # fusiontest.config.yaml example:
    #   secrets:
    #     EMAIL: MY_APP_EMAIL       # → reads os.environ["MY_APP_EMAIL"]
    #     PASSWORD: MY_APP_PASSWORD # → reads os.environ["MY_APP_PASSWORD"]
    #
    # Goals reference them as: {{EMAIL}} and {{PASSWORD}}
    # Values can also be inlined directly (not recommended for passwords):
    #   secrets:
    #     EMAIL: user@example.com
    cfg_secrets_raw: dict = cfg.get("secrets", {})
    cfg_secrets: dict[str, str] = {}
    for key, val in cfg_secrets_raw.items():
        str_val = str(val)
        # If the value looks like an env-var name (ALL_CAPS / underscores),
        # try to resolve it from the environment first.
        env_resolved = _os.getenv(str_val)
        cfg_secrets[str(key)] = env_resolved if env_resolved is not None else str_val

    runner_cfg = RunnerConfig(
        backend=backend,
        guardrails=GuardrailsConfig(
            loop_window=cfg.get("guardrails", {}).get("loop_detection_window", 5),
            max_invalid_retries=cfg.get("guardrails", {}).get("max_retries", 3),
        ),
        screenshot_on_failure=True,
        step_log_path=_step_log_tmp,
        secrets=cfg_secrets,
    )
    runner = FusionTestRunner(adapter, runner_cfg)

    # Display goals with secrets redacted — never print plaintext credentials.
    # Also validate that every {{VAR}} has a value BEFORE starting the browser.
    from fusiontest.core.secrets import resolve_goals as _resolve_goals
    _display_resolved, _display_resolver = _resolve_goals(goals, cfg_secrets)
    if _display_resolver.unresolved_vars:
        missing = sorted(_display_resolver.unresolved_vars)
        console.print()
        console.print(Panel(
            "[bold red]Unresolved secret variable(s):[/bold red] "
            + "  ".join(f"[cyan]{{{{{v}}}}}[/cyan]" for v in missing)
            + "\n\n"
            "FusionTest cannot find a value for these placeholders.\n"
            "Fix one of:\n\n"
            + "\n".join(
                f"  [bold]export {v}=<value>[/bold]   (set as env var)"
                for v in missing
            )
            + "\n\n"
            "Or map them in [cyan]fusiontest.config.yaml[/cyan]:\n"
            "  [cyan]secrets:\n"
            + "\n".join(f"    {v}: MY_{v}" for v in missing)
            + "[/cyan]\n\n"
            "Or add them in the dashboard: [link=https://app.fusiontest.fusionleap.io]Settings → Test Secrets[/link]",
            title="Missing secrets",
            border_style="red",
        ))
        sys.exit(1)

    console.print(f"\n[bold]Goals ({len(goals)}):[/bold]")
    for i, g in enumerate(_display_resolved, 1):
        console.print(f"  {i}. {_display_resolver.redact(g)}")
    console.print()

    # Run with live progress
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Running tests...", total=None)
        time.time()
        try:
            result = runner.run(goals=goals, goal_urls=goal_urls or None, platform=platform, locale=locale)
        except KeyboardInterrupt:
            console.print("\n[yellow]Interrupted by user[/yellow]")
            sys.exit(1)
        finally:
            progress.stop()

    # Print results table
    _print_results(result)

    # Save JSON report locally
    if output:
        _save_report(result, output)
        console.print(f"\n[dim]Report saved to: {output}[/dim]")

    # Upload report to FusionTest dashboard
    uploaded_run_id = _upload_report(result)

    # Upload step telemetry (best-effort, non-blocking)
    if _api_key and _step_log_tmp:
        _upload_step_logs(_step_log_tmp, uploaded_run_id)
        import os as _os2
        try:
            _os2.unlink(_step_log_tmp)
        except OSError:
            pass

    sys.exit(0 if result.success else 1)


# ── fusiontest demo ─────────────────────────────────────────────────────────────

# Maps demo target names → (goal file path relative to package root, description)
_DEMOS: dict[str, tuple[str, str]] = {
    "dashboard":   ("tests/goals/demos/fusiontest_dashboard.yaml",
                    "FusionTest dashboard self-test (requires: fusiontest-api + npm run dev)"),
    "todomvc":     ("tests/goals/demos/todomvc.yaml",
                    "TodoMVC — full CRUD flow on the React TodoMVC demo app"),
    "wikipedia":   ("tests/goals/demos/wikipedia.yaml",
                    "Wikipedia — search, navigate, and read an article"),
    "hackernews":  ("tests/goals/demos/hacker_news.yaml",
                    "Hacker News — front page browsing and comment navigation"),
    "github":      ("tests/goals/demos/github.yaml",
                    "GitHub — browse the fusion-test public repo (no login)"),
    "httpbin":     ("tests/goals/demos/httpbin.yaml",
                    "httpbin.org — HTTP form submission and response inspection"),
}


@main.command()
@click.argument("target", required=False)
@click.option("--backend", type=click.Choice(["gpt4o", "claude", "gemini", "groq", "ollama", "mpnet"]),
              default="gpt4o", show_default=True)
@click.option("--headless/--no-headless", default=False, show_default=True)
@click.option("--output", "-o", type=click.Path(), help="Write JSON report to this path")
@click.option("--list", "list_demos", is_flag=True, help="List all available demo targets")
def demo(target, backend, headless, output, list_demos):
    """Run a pre-built demo against a public site — no app setup required.

    \b
    Available targets:
      dashboard   FusionTest dashboard self-test
      todomvc     TodoMVC React CRUD flow
      wikipedia   Wikipedia search and navigation
      hackernews  Hacker News browsing
      github      GitHub public repo browsing
      httpbin     httpbin.org form submission

    \b
    Examples:
      fusiontest demo todomvc
      fusiontest demo wikipedia --backend claude
      fusiontest demo --list
    """
    from dotenv import load_dotenv
    load_dotenv()

    if list_demos or not target:
        console.print()
        console.print(Panel.fit(
            "[bold]FusionTest Demo Targets[/bold]\n"
            "Run any of these with: [cyan]fusiontest demo <target>[/cyan]",
            border_style="blue",
        ))
        console.print()
        table = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
        table.add_column("Target", style="cyan", width=14)
        table.add_column("Description")
        for name, (_, desc) in _DEMOS.items():
            table.add_row(name, desc)
        console.print(table)
        console.print()
        if not target:
            sys.exit(0)

    target = target.lower().replace("-", "").replace("_", "")
    # Allow partial matches (e.g. "todo" → "todomvc", "hack" → "hackernews")
    matched = [k for k in _DEMOS if k.startswith(target)]
    if not matched:
        console.print(f"[red]Unknown demo target:[/red] {target}")
        console.print("Run [cyan]fusiontest demo --list[/cyan] to see all available targets.")
        sys.exit(1)
    if len(matched) > 1:
        console.print(f"[yellow]Ambiguous target '{target}':[/yellow] matches {matched}")
        sys.exit(1)

    demo_key = matched[0]
    goal_rel_path, description = _DEMOS[demo_key]

    # Resolve path: first relative to repo root, then as an installed package resource
    repo_root = Path(__file__).parent.parent
    goal_path = repo_root / goal_rel_path
    if not goal_path.exists():
        console.print(f"[red]Demo goal file not found:[/red] {goal_path}")
        sys.exit(1)

    with open(goal_path) as f:
        data = yaml.safe_load(f)

    goals    = data.get("goals", [])
    platform = data.get("platform", "playwright")
    locale   = data.get("locale", "en-US")
    url      = data.get("url")
    name     = data.get("name", description)

    # Dashboard self-test: warn if services aren't running
    if demo_key == "dashboard":
        console.print()
        console.print(Panel(
            "[bold yellow]Dashboard self-test requires two services to be running:[/bold yellow]\n\n"
            "  Terminal 1:  [cyan]fusiontest-api[/cyan]\n"
            "  Terminal 2:  [cyan]cd dashboard && npm run dev[/cyan]\n\n"
            "Then press Enter to continue, or Ctrl-C to cancel.",
            border_style="yellow",
        ))
        try:
            input()
        except KeyboardInterrupt:
            console.print("\n[yellow]Cancelled.[/yellow]")
            sys.exit(0)

    console.print()
    console.print(Panel.fit(
        f"[bold]FusionTest Demo[/bold] — {name}\n"
        f"Platform: [cyan]{platform}[/cyan]  ·  Backend: [cyan]{backend}[/cyan]  ·  "
        f"URL: [cyan]{url or '(none)'}[/cyan]",
        border_style="blue",
    ))
    console.print(f"\n[bold]Goals ({len(goals)}):[/bold]")
    for i, g in enumerate(goals, 1):
        console.print(f"  {i}. {g}")
    console.print()

    adapter = _build_adapter(platform, None, url, headless)

    from fusiontest.core.runner import FusionTestRunner, RunnerConfig
    runner = FusionTestRunner(adapter, RunnerConfig(backend=backend))

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
                  console=console) as progress:
        progress.add_task(f"Running {demo_key} demo...", total=None)
        try:
            result = runner.run(goals=goals, name=name, platform=platform, locale=locale)
        except KeyboardInterrupt:
            console.print("\n[yellow]Interrupted.[/yellow]")
            sys.exit(1)
        finally:
            progress.stop()

    _print_results(result)

    if output:
        _save_report(result, output)
        console.print(f"\n[dim]Report saved to: {output}[/dim]")

    if result.success:
        console.print(
            f"\n[green]✓ Demo passed![/green] FusionTest successfully navigated "
            f"[bold]{demo_key}[/bold] using the [bold]{backend}[/bold] backend.\n"
            f"Run [cyan]fusiontest demo --list[/cyan] to try another target."
        )
    else:
        console.print(
            "\n[red]✗ Demo had failures.[/red] Check the output above for details.\n"
            "Tip: re-run with [cyan]--no-headless[/cyan] to watch the browser."
        )

    sys.exit(0 if result.success else 1)


# ── fusiontest init ─────────────────────────────────────────────────────────────

@main.command()
def init():
    """Scaffold a fusiontest.config.yaml in the current directory."""
    config_path = Path("fusiontest.config.yaml")
    if config_path.exists():
        if not click.confirm(f"{config_path} already exists. Overwrite?"):
            return

    example_goals_path = Path("tests/goals/smoke.yaml")
    example_goals_path.parent.mkdir(parents=True, exist_ok=True)

    # Auto-detect the best available backend to pre-fill the config
    import os as _os
    if _os.getenv("GROQ_API_KEY"):
        detected_backend = "groq"
    elif _os.getenv("ANTHROPIC_API_KEY"):
        detected_backend = "claude"
    elif _os.getenv("GEMINI_API_KEY"):
        detected_backend = "gemini"
    elif _os.getenv("OPENAI_API_KEY"):
        detected_backend = "gpt4o"
    else:
        detected_backend = "groq"   # recommended default (free)

    config = {
        # backend: which LLM to use — groq | claude | gemini | gpt4o | ollama | mpnet
        # Free options: groq (recommended), gemini, ollama
        # Paid options: claude, gpt4o
        # Leave unset to auto-detect from whichever API key is present.
        "backend": detected_backend,
        "runner": {
            "max_steps_per_goal": 25,
        },
        "guardrails": {
            "loop_detection": True,
            "loop_detection_window": 5,
            "max_retries": 3,
            "backtrack_on_invalid": True,
        },
        "reporting": {
            "save_recordings": True,
        },
    }

    with open(config_path, "w") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)

    smoke_goals = {
        "name": "Smoke test",
        "platform": "playwright",
        "locale": "en-US",
        "url": "https://your-app-url.com",
        "goals": [
            "Verify the page loads and the main navigation is visible",
            "Click the login button and verify the login form appears",
        ],
    }
    with open(example_goals_path, "w") as f:
        yaml.dump(smoke_goals, f, default_flow_style=False, sort_keys=False)

    console.print(f"[green]✓[/green] Created {config_path}")
    console.print(f"[green]✓[/green] Created {example_goals_path}")
    console.print(f"\n[dim]Detected backend:[/dim] [cyan]{detected_backend}[/cyan]")
    console.print("\nNext steps:")
    if detected_backend == "groq":
        console.print("  1. Get a free Groq key at [link]https://console.groq.com[/link] → set GROQ_API_KEY")
    else:
        console.print(f"  1. Confirm {detected_backend.upper()}_API_KEY is set in your .env")
    console.print("  2. Edit fusiontest.config.yaml to change backend if needed")
    console.print("  3. Run: [bold]fusiontest run --file tests/goals/smoke.yaml[/bold]")


# ── fusiontest report ───────────────────────────────────────────────────────────

@main.command()
@click.argument("report_file", type=click.Path(exists=True))
def report(report_file):
    """Pretty-print a JSON report from a previous run."""
    with open(report_file) as f:
        data = json.load(f)
    _print_report_data(data)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _is_ollama_running() -> bool:
    """Return True if Ollama is reachable at OLLAMA_HOST (default localhost:11434)."""
    import os
    import urllib.request
    host = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    try:
        urllib.request.urlopen(f"{host}/api/tags", timeout=1)  # noqa: S310
        return True
    except Exception:
        return False


def _build_adapter(platform: str, app: str | None, url: str | None, headless: bool):
    if platform == "playwright":
        from fusiontest.desktop.playwright_adapter import PlaywrightAdapter
        adapter = PlaywrightAdapter(browser_type="chromium", headless=headless)
        adapter.start(url=url)
        return adapter

    elif platform == "electron":
        if not app:
            console.print("[red]--app is required for electron platform[/red]")
            sys.exit(1)
        from fusiontest.desktop.playwright_adapter import PlaywrightAdapter
        adapter = PlaywrightAdapter(electron_app_path=app, headless=headless)
        adapter.start()
        return adapter

    elif platform == "android":
        from fusiontest.mobile.android_adapter import AndroidAdapter
        caps = {}
        if app:
            caps["app"] = app
        adapter = AndroidAdapter(desired_caps=caps)
        adapter.start()
        return adapter

    elif platform == "ios":
        from fusiontest.mobile.ios_adapter import IOSAdapter
        caps = {}
        if app:
            caps["app"] = app
        adapter = IOSAdapter(desired_caps=caps)
        adapter.start()
        return adapter

    else:
        console.print(f"[red]Unknown platform: {platform}[/red]")
        sys.exit(1)


def _print_results(result) -> None:
    status = "[green]PASS ✓[/green]" if result.success else "[red]FAIL ✗[/red]"
    console.print(f"\n{'─'*50}")
    console.print(f"Result: {status}  Stability: [bold]{result.stability_score:.0%}[/bold]  "
                  f"Duration: {result.total_duration_seconds:.1f}s")
    console.print()

    table = Table(show_header=True, header_style="bold", box=None, pad_edge=False)
    table.add_column("#", style="dim", width=3)
    table.add_column("Goal", min_width=30)
    table.add_column("Status", width=8)
    table.add_column("Steps", width=6)
    table.add_column("Time", width=7)

    for i, step in enumerate(result.steps, 1):
        status_cell = "[green]PASS[/green]" if step.success else "[red]FAIL[/red]"
        error_note = f"\n  [dim red]{step.error}[/dim red]" if step.error else ""
        table.add_row(
            str(i),
            step.goal + error_note,
            status_cell,
            str(step.steps_taken),
            f"{step.duration_seconds:.1f}s",
        )

    console.print(table)


def _save_report(result, path: str) -> None:
    data = {
        "name": result.name,
        "platform": result.platform,
        "locale": result.locale,
        "success": result.success,
        "stability_score": result.stability_score,
        "total_duration_seconds": result.total_duration_seconds,
        "steps": [
            {
                "goal": s.goal,
                "success": s.success,
                "steps_taken": s.steps_taken,
                "actions": s.actions,
                "error": s.error,
                "duration_seconds": s.duration_seconds,
            }
            for s in result.steps
        ],
    }
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def _upload_report(result) -> str | None:
    """POST the run report to the FusionTest dashboard API (best-effort, never blocks the exit).
    Returns the run_id if the upload succeeded, otherwise None."""
    import os
    api_key = os.getenv("FUSIONTEST_API_KEY")
    api_url = os.getenv("FUSIONTEST_API_URL", "https://api.fusiontest.fusionleap.io")

    if not api_key:
        console.print(
            "\n[dim]Tip: set [bold]FUSIONTEST_API_KEY[/bold] to automatically upload results to your dashboard.[/dim]"
        )
        return None

    import json as _json

    import httpx

    payload = {
        "name": result.name,
        "platform": result.platform,
        "locale": result.locale,
        "success": result.success,
        "stability_score": result.stability_score,
        "total_duration_seconds": result.total_duration_seconds,
        "steps": [
            {
                "goal": s.goal,
                "success": s.success,
                "steps_taken": s.steps_taken,
                "actions": s.actions,
                "error": s.error,
                "duration_seconds": s.duration_seconds,
            }
            for s in result.steps
        ],
    }

    try:
        resp = httpx.post(
            f"{api_url}/api/runs",
            content=_json.dumps(payload),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=15,
        )
        resp.raise_for_status()
        run_id = resp.json().get("id", "")
        dashboard_url = f"https://app.fusiontest.fusionleap.io/runs/{run_id}" if run_id else "https://app.fusiontest.fusionleap.io/runs"
        console.print(f"\n[green]✓[/green] Report uploaded to dashboard: [cyan]{dashboard_url}[/cyan]")
        return run_id or None
    except Exception as e:
        console.print(f"\n[yellow]Warning:[/yellow] Could not upload report to dashboard: {e}")
        return None


def _upload_step_logs(step_log_path: str, run_id: str | None) -> None:
    """POST per-step training data to /api/telemetry/steps (best-effort)."""
    import hashlib
    import json as _json
    import os

    import httpx

    api_key = os.getenv("FUSIONTEST_API_KEY")
    api_url = os.getenv("FUSIONTEST_API_URL", "https://api.fusiontest.fusionleap.io")
    if not api_key:
        return

    try:
        steps: list[dict] = []
        with open(step_log_path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = _json.loads(line)
                    screen_text = entry.get("screen_text", "")
                    steps.append({
                        "run_id": run_id or "",
                        "goal": entry.get("goal", ""),
                        "screen_hash": hashlib.md5(screen_text.encode()).hexdigest() if screen_text else "",
                        "action": entry.get("action", ""),
                        "outcome": entry.get("outcome", ""),
                    })
                except Exception:
                    continue

        if not steps:
            return

        resp = httpx.post(
            f"{api_url}/api/telemetry/steps",
            content=_json.dumps(steps),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=20,
        )
        resp.raise_for_status()
        ingested = resp.json().get("ingested", len(steps))
        console.print(f"[dim]  Step telemetry: {ingested} steps logged.[/dim]")
    except Exception:
        pass  # telemetry upload is non-critical


def _print_report_data(data: dict) -> None:
    console.print(Panel.fit(
        f"[bold]{data['name']}[/bold]\n"
        f"Platform: {data['platform']}  ·  Locale: {data['locale']}  ·  "
        f"Stability: {data['stability_score']:.0%}",
        border_style="blue" if data["success"] else "red",
    ))
    for _i, step in enumerate(data.get("steps", []), 1):
        icon = "✓" if step["success"] else "✗"
        color = "green" if step["success"] else "red"
        console.print(f"  [{color}]{icon}[/{color}] {step['goal']}  [{step['steps_taken']} steps, {step['duration_seconds']:.1f}s]")
        if step.get("error"):
            console.print(f"     [dim red]{step['error']}[/dim red]")


if __name__ == "__main__":
    main()
