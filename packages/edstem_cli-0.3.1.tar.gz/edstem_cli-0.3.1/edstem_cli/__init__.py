"""edstem-cli: A CLI for Ed Discussion."""

__version__ = "0.3.1"
