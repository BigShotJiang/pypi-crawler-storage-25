---
name: memory
description: "Cross-agent memory operations using FalkorDB graph database. Store, recall, and share persistent memories across Claude, Codex, and Gemini agents."
user-invocable: true
---

# Memory Skill

Access and manage persistent, cross-agent memory using the FalkorDB graph database.

## Overview

This skill provides tools for:
- **Storing memories**: Learning, decisions, code snippets, concepts
- **Recalling memories**: Semantic search, text search, graph traversal
- **Sharing memories**: Cross-agent knowledge sharing
- **Session management**: Track work context across sessions
- **OMC integration**: Sync with notepad and project-memory

## Quick Start

```
/memory remember learning "Always use async/await for database operations in this project"
/memory recall "database operations"
/memory share <memory_id> with claude codex
/memory stats
```

## Commands

### Storage Commands

| Command | Description |
|---------|-------------|
| `/memory remember <type> <content>` | Store a new memory |
| `/memory recall <query>` | Search memories |
| `/memory forget <id>` | Remove a memory |
| `/memory associate <from_id> <relation> <to_id>` | Link two memories |

### Session Commands

| Command | Description |
|---------|-------------|
| `/memory session start` | Start a new session |
| `/memory session end` | End current session |
| `/memory session list` | List recent sessions |

### Sharing Commands

| Command | Description |
|---------|-------------|
| `/memory share <id> with <agent>` | Share memory with agent |
| `/memory query-agent <agent_id>` | Query agent's shared memories |

### Utility Commands

| Command | Description |
|---------|-------------|
| `/memory stats` | Show memory statistics |
| `/memory cleanup` | Remove expired memories |
| `/memory sync` | Sync with OMC notepad |

## Memory Types

| Type | Description | Use Case |
|------|-------------|----------|
| `learning` | Patterns, insights, tips | "Always validate input before processing" |
| `decision` | Architecture/design choices | "Chose Redis for caching because..." |
| `code` | Code snippets with context | "Utility function for date parsing" |
| `concept` | Domain concepts | "What is a circuit breaker pattern" |
| `task` | Work items and objectives | "Implement user authentication" |

## Examples

### Store a Learning

```
/memory remember learning "Use connection pooling for FalkorDB to handle concurrent requests efficiently" --tags performance,database
```

### Store a Decision

```
/memory remember decision "Chose FalkorDB over Neo4j because it's Redis-based and we already have Redis infrastructure" --type architecture --confidence 0.9
```

### Recall Memories

```
/memory recall "database performance"
/memory recall "circuit breaker" --type concept
/memory recall "authentication" --limit 5
```

### Search with Filters

```
/memory recall "API" --filters '{"category": "learning"}'
/memory recall "error handling" --mode semantic
```

### Share Knowledge

```
/memory share 123 with codex gemini
/memory query-agent codex
```

### Session Tracking

```
/memory session start --objective "Implement user authentication" --ttl 86400
/memory session end --summary "Completed OAuth2 integration"
```

## MCP Tools Available

The following MCP tools are exposed by the FalkorDB memory server:

### Graph Operations
- `memory_query` - Execute Cypher queries
- `memory_create_node` - Create graph nodes
- `memory_create_edge` - Create relationships
- `memory_delete` - Remove nodes/edges

### Memory Primitives
- `memory_remember` - Store memories
- `memory_recall` - Retrieve memories
- `memory_associate` - Link memories
- `memory_forget` - Remove memories

### Session Management
- `memory_start_session` - Begin session
- `memory_end_session` - End session

### Semantic Search
- `memory_semantic_search` - Vector similarity search
- `memory_embed` - Generate embeddings

### Cross-Agent
- `memory_share` - Share with agents
- `memory_query_agent` - Query shared memories

### Maintenance
- `memory_stats` - Get statistics
- `memory_cleanup` - Remove expired

## Configuration

The memory server is configured via environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `FALKORDB_URL` | `redis://localhost:6379` | FalkorDB connection URL |
| `GRAPH_NAME` | `agent_memory` | Graph database name |
| `EMBEDDING_MODEL` | `all-MiniLM-L6-v2` | Sentence transformer model |
| `DEFAULT_TTL` | `604800` | Default TTL (7 days) |

## Graph Schema

### Node Types

- **Session**: Agent work sessions
- **Agent**: AI agent identities
- **Decision**: Architectural/implementation choices
- **Learning**: Patterns, tips, insights
- **Code**: Code snippets with context
- **Concept**: Domain concepts

### Relationships

- `STARTED_BY`: Session → Agent
- `LED_TO`: Decision → Decision
- `DERIVED_FROM`: Learning → Source
- `KNOWS`: Agent → Concept
- `RELATED_TO`: Concept → Concept
- `SHARED_WITH`: Memory → Agent

## Integration with OMC

### Notepad Sync

Memories tagged with `notepad` are synced with `.omc/notepad.md`:

```python
# Sync notepad to graph
/memory sync notepad

# Sync graph to notepad
/memory sync notepad --export
```

### Project Memory Sync

Project-level knowledge syncs with `.omc/project-memory.json`:

```python
# Import project memory
/memory sync project

# Export to project memory
/memory sync project --export
```

## Best Practices

1. **Tag your memories**: Use consistent tags for easier retrieval
2. **Set appropriate TTL**: Transient data should have shorter TTLs
3. **Link related memories**: Use `memory_associate` to build knowledge graphs
4. **Share useful patterns**: Share learnings that benefit other agents
5. **Clean up regularly**: Run `memory_cleanup` periodically

## Troubleshooting

### Semantic search not working

Ensure the embedding model is downloaded:
```bash
pip install sentence-transformers
python -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('all-MiniLM-L6-v2')"
```

### Connection errors

Check FalkorDB is running:
```bash
docker-compose up -d falkordb
redis-cli ping
```

### Memories not persisting

Check TTL settings and run cleanup:
```
/memory stats
/memory cleanup --dry-run
```