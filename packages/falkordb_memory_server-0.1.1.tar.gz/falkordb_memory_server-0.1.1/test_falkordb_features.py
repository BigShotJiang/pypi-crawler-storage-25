from falkordb import FalkorDB

try:
    db = FalkorDB.from_url("redis://localhost:6379")
    graph = db.select_graph("test_graph")

    # Try a simple datetime query
    try:
        res = graph.query("RETURN datetime('2024-01-01T00:00:00')")
        print("datetime() is supported")
        print(res.result_set)
    except Exception as e:
        print(f"datetime() is NOT supported: {e}")

    try:
        res = graph.query("RETURN duration({seconds: 10})")
        print("duration() is supported")
        print(res.result_set)
    except Exception as e:
        print(f"duration() is NOT supported: {e}")

except Exception as e:
    print(f"Error connecting: {e}")
