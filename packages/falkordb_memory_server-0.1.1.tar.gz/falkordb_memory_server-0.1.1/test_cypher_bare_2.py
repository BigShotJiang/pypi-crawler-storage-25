import os
import sys

sys.path.insert(0, os.path.abspath("/Users/jerry/projects/ai/falkordb-memory/src"))

from datetime import datetime, timezone

from falkordb_memory_server.graph_ops import GraphOperations


def run_tests():
    os.environ["FALKORDB_URL"] = "redis://localhost:6379"
    os.environ["GRAPH_NAME"] = "test_cypher_injection"

    ops = GraphOperations()

    props = {
        "text": "test' SET n.hacked = 'yes' RETURN n //",
        "name": "InjectionTestNode",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }

    cypher = "CREATE (n:TestNode) SET n = $props RETURN n"
    print("Executing query returning node...")
    try:
        res = ops.query(cypher, params={"props": props})
        print("Parsed Result:", res["result_set"])
    except Exception as e:
        print("Error:", e)


if __name__ == "__main__":
    run_tests()
