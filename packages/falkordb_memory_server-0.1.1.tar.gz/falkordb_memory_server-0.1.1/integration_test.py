import subprocess
import json

def test_hook(event_name):
    payload = {
        "hook_event_name": event_name,
        "session_id": "test-integration",
        "timestamp": "2026-04-11T12:00:00Z"
    }
    if event_name == "PostToolUse":
        payload["tool_name"] = "test_tool"
        payload["tool_input"] = {"content": "We decided to use React for frontend."}
        payload["tool_output"] = {"result": "success"}

    print(f"Testing {event_name}...")
    result = subprocess.run(
        ["./venv/bin/python3", "hooks/claude-code-hook.py"],
        input=json.dumps(payload),
        text=True,
        capture_output=True
    )
    print(f"STDOUT: {result.stdout.strip()}")
    if result.stderr:
        print(f"STDERR: {result.stderr.strip()}")

print("Testing hooks...")
test_hook("SessionStart")
test_hook("PostToolUse")
print("\nTesting MCP Server manually via pytest...")
result = subprocess.run(["./venv/bin/pytest", "-v", "tests/"], capture_output=True, text=True)
print(f"Pytest return code: {result.returncode}")
if result.returncode != 0:
    print(result.stdout)
