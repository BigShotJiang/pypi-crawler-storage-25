from falkordb_memory_server.graph_ops import get_graph_ops


def check_graph():
    ops = get_graph_ops()

    # Check labels
    # FalkorDB doesn't have a direct "list labels" like Neo4j's db.labels()
    # but we can try some common ones or use a generic match

    # Try to find all labels by matching nodes and getting labels(n)
    # Note: FalkorDB supports labels(n) but it returns a list.
    try:
        result = ops.query("MATCH (n) RETURN DISTINCT labels(n) as labels")
        print("Labels found:", result.get("result_set"))
    except Exception as e:
        print("Error getting labels:", e)

    # Check some nodes
    try:
        result = ops.query("MATCH (n) RETURN n LIMIT 5")
        print("Sample nodes:", result.get("result_set"))
    except Exception as e:
        print("Error getting nodes:", e)


if __name__ == "__main__":
    check_graph()
