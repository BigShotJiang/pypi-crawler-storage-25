import logging

from falkordb_memory_server.graph_ops import get_graph_ops

logging.basicConfig(level=logging.INFO)


def test_injection():
    ops = get_graph_ops()
    if not ops.is_connected():
        print("Skipping test: FalkorDB not connected")
        return

    print("Attempting Cypher injection via node label...")
    # This label attempts to break out of the CREATE clause and execute a DELETE
    # The actual query would be: CREATE (n:User) DETACH DELETE (n) SET n = $props RETURN n
    malicious_label = "User) DETACH DELETE (n"

    try:
        result = ops.create_node(malicious_label, {"content": "test"})
        print(f"Injection result: {result}")
    except Exception as e:
        print(f"Caught expected error or injection failed: {e}")


if __name__ == "__main__":
    test_injection()
