#!/usr/bin/env bash
set -euo pipefail

# falkordb-memory OpenClaw Plugin Installer
# Registers the falkordb-memory MCP server into OpenClaw's configuration.
#
# Usage:
#   curl -fsSL https://raw.githubusercontent.com/goodideal/falkordb-memory/main/scripts/install_openclaw.sh | bash

# Colors
if [[ -t 1 ]] && [[ "${TERM:-}" != "dumb" ]]; then
  readonly COLOR_RED='\033[0;31m'
  readonly COLOR_GREEN='\033[0;32m'
  readonly COLOR_YELLOW='\033[0;33m'
  readonly COLOR_CYAN='\033[0;36m'
  readonly COLOR_BOLD='\033[1m'
  readonly COLOR_RESET='\033[0m'
else
  readonly COLOR_RED=''
  readonly COLOR_GREEN=''
  readonly COLOR_YELLOW=''
  readonly COLOR_CYAN=''
  readonly COLOR_MAGENTA=''
  readonly COLOR_BOLD=''
  readonly COLOR_RESET=''
fi

info()    { echo -e "${COLOR_CYAN}ℹ${COLOR_RESET}  $*"; }
success() { echo -e "${COLOR_GREEN}✓${COLOR_RESET}  $*"; }
warn()    { echo -e "${COLOR_YELLOW}⚠${COLOR_RESET}  $*"; }
error()   { echo -e "${COLOR_RED}✗${COLOR_RESET}  $*" >&2; }

print_banner() {
  echo -e "${COLOR_MAGENTA}${COLOR_BOLD}"
  echo "  ┌──────────────────────────────────────────┐"
  echo "  │     falkordb-memory OpenClaw Installer   │"
  echo "  └──────────────────────────────────────────┘"
  echo -e "${COLOR_RESET}"
}

# Find the python executable where falkordb-memory is installed
find_python_env() {
  local py_cmd=""
  
  # Check if uv is installed and manages the package
  if command -v uv &>/dev/null; then
     if uv run python -c "import falkordb_memory_server" &>/dev/null; then
       # Get path to uv's python
       py_cmd="$(uv run which python)"
       success "Found falkordb-memory in uv environment: $py_cmd"
       echo "$py_cmd"
       return 0
     fi
  fi
  
  # Check global or current virtualenv python
  if command -v python3 &>/dev/null; then
    if python3 -c "import falkordb_memory_server" &>/dev/null; then
      py_cmd="$(command -v python3)"
      success "Found falkordb-memory in python environment: $py_cmd"
      echo "$py_cmd"
      return 0
    fi
  fi
  
  if command -v python &>/dev/null; then
    if python -c "import falkordb_memory_server" &>/dev/null; then
      py_cmd="$(command -v python)"
      success "Found falkordb-memory in python environment: $py_cmd"
      echo "$py_cmd"
      return 0
    fi
  fi
  
  return 1
}

main() {
  print_banner
  
  info "Locating OpenClaw configuration..."
  local config_file="${HOME}/.openclaw/openclaw.json"
  
  if [[ ! -f "$config_file" ]]; then
    error "OpenClaw configuration not found at ${config_file}"
    error "Please install and initialize OpenClaw first."
    exit 1
  fi
  success "Found OpenClaw config at ${config_file}"
  
  info "Locating falkordb-memory installation..."
  local py_path
  if ! py_path="$(find_python_env)"; then
    error "falkordb_memory_server module not found."
    error "Please install it first: pip install falkordb-memory-server"
    exit 1
  fi
  # py_path might have logs from success() so we need to isolate the path
  py_path=$(echo "$py_path" | tail -n 1)

  info "Registering MCP server in OpenClaw config..."
  
  # Check if node is available for JSON manipulation
  if ! command -v node &>/dev/null; then
    error "Node.js is required to update the configuration safely."
    exit 1
  fi
  
  FALKORDB_URL="${FALKORDB_URL:-redis://localhost:6379}" \
  GRAPH_NAME="${GRAPH_NAME:-agent_memory}" \
  EXTRACTION_MODE="${EXTRACTION_MODE:-office}" \
  INSTALLER_PY_PATH="$py_path" INSTALLER_CONFIG_FILE="$config_file" node -e "
    const fs = require('fs');
    const configPath = process.env.INSTALLER_CONFIG_FILE;
    const pyPath = process.env.INSTALLER_PY_PATH;
    
    let config = {};
    try {
      config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    } catch (e) {
      console.error('Failed to parse openclaw.json');
      process.exit(1);
    }
    
    if (!config.mcp) config.mcp = {};
    if (!config.mcp.servers) config.mcp.servers = {};
    
    config.mcp.servers['falkordb-memory'] = {
      command: pyPath,
      args: ['-m', 'falkordb_memory_server'],
      env: {
        FALKORDB_URL: process.env.FALKORDB_URL,
        GRAPH_NAME: process.env.GRAPH_NAME,
        EXTRACTION_MODE: process.env.EXTRACTION_MODE
      }
    };
    
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2) + '\n', 'utf8');
  "
  
  if [[ $? -ne 0 ]]; then
    error "Failed to update OpenClaw configuration."
    exit 1
  fi
  
  success "MCP server registered successfully!"
  
  echo ""
  echo -e "  ${COLOR_BOLD}What's next?${COLOR_RESET}"
  echo -e "  ${COLOR_CYAN}1.${COLOR_RESET} Ensure FalkorDB is running: ${COLOR_BOLD}docker run -d -p 6379:6379 falkordb/falkordb:latest${COLOR_RESET}"
  echo -e "  ${COLOR_CYAN}2.${COLOR_RESET} Restart OpenClaw to apply the new MCP configuration."
  echo ""
}

main "$@"
main "$@"