import logging
import os
import sys

logging.basicConfig(level=logging.DEBUG)

# Add src to PYTHONPATH
sys.path.insert(0, os.path.abspath("/Users/jerry/projects/ai/falkordb-memory/src"))

from falkordb import FalkorDB  # noqa: E402


def run_tests():
    os.environ["FALKORDB_URL"] = "redis://localhost:6379"
    os.environ["GRAPH_NAME"] = "test_cypher_injection"

    print("Testing bare FalkorDB connection")
    db = FalkorDB.from_url("redis://localhost:6379")
    graph = db.select_graph("test_cypher_injection")
    print("Graph selected")

    props = {"text": "test' SET n.hacked = 'yes' RETURN n //", "name": "InjectionTestNode"}

    print("Executing query...")
    try:
        res = graph.query(
            "CREATE (n:TestNode) SET n = $props RETURN id(n)", params={"props": props}
        )
        print("Result:", res.result_set)
    except Exception as e:
        print("Error:", e)


if __name__ == "__main__":
    run_tests()
