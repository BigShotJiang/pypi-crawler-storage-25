import os
import sys

# Add src to PYTHONPATH
sys.path.insert(0, os.path.abspath("/Users/jerry/projects/ai/falkordb-memory/src"))

from falkordb_memory_server.graph_ops import GraphOperations


def run_tests():
    # Force connection string if needed
    os.environ["FALKORDB_URL"] = "redis://localhost:6379"
    os.environ["GRAPH_NAME"] = "test_cypher_injection"

    ops = GraphOperations()

    print("Connecting to DB...")
    malicious_string = "test' SET n.hacked = 'yes' RETURN n //"

    properties = {"text": malicious_string, "name": "InjectionTestNode"}

    print(f"Testing create_node with malicious property: {malicious_string}")
    try:
        res = ops.create_node(label="TestNode", properties=properties)
        node_id = res.get("id") if "id" in res else res.get("node_id")

        print("create_node returned node_id:", node_id)
    except Exception as e:
        print("Error during create_node:", e)
        return

    # Verify that the malicious property is exactly as we passed it and no injection happened
    print("Verifying node properties...")
    try:
        # We need to get the node by its ID
        verify_res = ops.query("MATCH (n:TestNode) RETURN id(n) as id, n.text, n.hacked")

        found = False
        for row in verify_res["result_set"]:
            if row[0] == node_id:
                found = True
                text_prop = row[1]
                hacked_prop = row[2]
                print(f"Found node {node_id}: text='{text_prop}', hacked='{hacked_prop}'")

                if text_prop == malicious_string and hacked_prop is None:
                    print(
                        "[PASS] Property was stored correctly as a string. No injection occurred."
                    )
                else:
                    print("[FAIL] Property storage mismatched or injection succeeded.")
                break

        if not found:
            print(f"[FAIL] Could not find node with id {node_id}")

    except Exception as e:
        print("Error during verification:", e)

    # Check delete_nodes
    print("Testing delete_nodes...")
    try:
        del_res = ops.delete_nodes(node_ids=[node_id])
        print("delete_nodes returned:", del_res)
    except Exception as e:
        print("Error during delete_nodes:", e)


if __name__ == "__main__":
    run_tests()
