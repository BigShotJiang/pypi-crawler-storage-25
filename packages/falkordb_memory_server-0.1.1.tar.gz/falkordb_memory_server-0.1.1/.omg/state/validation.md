## Guardrails & Validation

### Build / Format / Lint Commands
- **Dependency Manager**: `hatchling` (pyproject.toml)
- **Linter & Formatter**: `ruff`
- **Check Command**: `ruff check --fix src/ tests/ && ruff format src/ tests/`

### Test Commands
- **Framework**: `pytest` with `pytest-asyncio`
- **Execution Command**: `pytest tests/`

### Known Constraints
1. **PII Masking Stability**: The `ExtractionMode` rules aggressively mask private information (`OFFICE` / `LIFE` modes). Be cautious when modifying core extraction regex boundaries so that performance latency is not heavily impacted.
2. **Local Model Dependency**: Sentence Embeddings download a local HuggingFace model (`all-MiniLM-L6-v2`) on initialization, which requires some bandwidth and isolated disk cache paths.
3. **Stateless MCP Execution**: MCP requests are stateless. All agent facts must be synchronized correctly back to FalkorDB via `graph_ops.py`.
4. **Hook Dependency**: Modifying OpenClaw hook interception logic (once built) requires extreme care around parsing raw CLI STDOUT without breaking regular JSON payloads.