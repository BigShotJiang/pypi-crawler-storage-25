## Project Map

### Modules & Responsibilities
- **`src/falkordb_memory_server/server.py`**: MCP Server Entry Point. Registers standard MCP tools and boots standard I/O communication.
- **`src/falkordb_memory_server/extractor.py`**: Rule-based (Regex) & LLM memory extraction engine. Supports 3 categories/modes: `PROGRAMMING`, `OFFICE`, and `LIFE` (handles PII redacting for phone, ID card, bank card, etc.).
- **`src/falkordb_memory_server/hook_adapter.py`**: Passive memory capture logic intercepting Claude Code and Gemini CLI background hooks. *(OpenClaw parsing is missing)*.
- **`src/falkordb_memory_server/graph_ops.py`**: FalkorDB connection pool & graph-native operations (Cypher queries).
- **`src/falkordb_memory_server/handlers/`**: The action layer translating incoming MCP JSON RPCs into direct logic (`extraction.py`, `memory.py`, `session.py`).
- **`scripts/install_openclaw.sh`**: Setup script designed to safely modify `openclaw.json` to inject this server as an MCP tool provider with the correct isolated Python `sys.executable`.

### Dependency Hotspots
- **FalkorDB Database**: System expects port `6379` accessible (`FALKORDB_URL` environment dependency).
- **`sentence-transformers` & `torch`**: Heavy offline computation resources for generating semantic vectors of memories locally.
- **`hook_adapter.py`**: Crucial coupling layer where different CLI agent stdout/logs are unified into a normalized format.