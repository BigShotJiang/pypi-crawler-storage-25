# 任务看板 (Taskboard) - OpenClaw 后台 Hook 解析支持 (OpenClaw Hooks Integration)

**目标 (Objective)**: 实现针对 OpenClaw 后台 hook 拦截机制的日志解析与事件映射，补齐 `falkordb-memory` 在 OpenClaw 下被动无感提取记忆的能力。

## 阶段 1: 事件映射与基础定义 (Event Mapping Definition)
| ID | 状态 | 优先级 | 任务标题 | 负责人 |
|---|---|---|---|---|
| **T-01** | ✅ `done` | p0 | 在 `hook_adapter.py` 中定义 `OPENCLAW_TO_UNIFIED`，将 OpenClaw 的内部 hook 事件映射至统一生命周期。 | omg-executor |

## 阶段 2: Payload 解析逻辑 (Input Parsing)
| ID | 状态 | 优先级 | 任务标题 | 负责人 |
|---|---|---|---|---|
| **T-02** | ✅ `done` | p0 | 增加 `_parse_openclaw_input` 方法，解构时间戳、会话、工作区及模型/工具调用详细信息，将松散 JSON 转换为标准 `UnifiedHookInput`。 | omg-executor |
| **T-03** | ✅ `done` | p0 | 更新 `normalize_input`，依据 `HookSource` 将 Claude, Gemini, OpenClaw 的输入分发至各专有解析器。 | omg-executor |

## 阶段 3: 输出格式化与适配路由 (Output Routing)
| ID | 状态 | 优先级 | 任务标题 | 负责人 |
|---|---|---|---|---|
| **T-04** | ✅ `done` | p1 | 在 `UnifiedHookOutput` 中实现 `to_openclaw_output`，返回 OpenClaw 需要的响应结构。 | omg-executor |
| **T-05** | ✅ `done` | p0 | 更新 `normalize_output` 将 OpenClaw 下的输出正确路由给 `to_openclaw_output()`。 | omg-executor |

## 阶段 4: 健壮性与测试 (Testing)
| ID | 状态 | 优先级 | 任务标题 | 负责人 |
|---|---|---|---|---|
| **T-06** | ✅ `done` | p0 | 更新 `tests/test_hook_adapter.py`，增加对 OpenClaw Hook 全生命周期 payload 格式解析及输出正确性的测试覆盖。 | omg-verifier |
