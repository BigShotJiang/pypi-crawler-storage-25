## Deep Init Summary

`falkordb-memory-server` is an MCP server providing graph-based memory capabilities for AI agents using FalkorDB. It extracts, categorizes, and stores knowledge automatically utilizing rule-based pattern matching (regex) and local semantic embeddings (Sentence Transformers).

### Core Query Answer
**Q:** openclaw上的hooks功能是否没有？
**A:** 是的，目前针对 OpenClaw 的 **Hooks 被动拦截流功能是缺失的**。
虽然代码在 `hook_adapter.py` 中定义了枚举 `HookSource.OPENCLAW` 并借此将提取模式切换至 `ExtractionMode.OFFICE`，但**并没有实现任何 OpenClaw 专属的 Event 映射（类似于 `CLAUDE_TO_UNIFIED`）和日志/事件解析逻辑（类似于解析 Claude 或 Gemini CLI 格式输出的逻辑）**。这意味着目前 OpenClaw 仅能主动调用 `falkordb-memory` 提供的 MCP Tools (`memory_extract`, `memory_remember` 等)，无法像 Claude/Gemini 那样在后台通过拦截终端流被动无感地提取记忆。若需要被动流拦截，必须对 `hook_adapter.py` 进行后续开发。

## Recommended Next Command
`/omg:team-plan --intent "实现 OpenClaw 的后台 hook 日志解析流和事件映射，补齐被动记忆截获能力"`