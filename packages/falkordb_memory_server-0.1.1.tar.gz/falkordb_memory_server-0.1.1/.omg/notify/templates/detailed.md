# {{event_type}} Report

**Time**: {{timestamp}}
**Source**: {{source}}
**Message**: {{message}}

## Context
{{context}}
