🚨 **INCIDENT ALERT: {{event_type}}** 🚨

**Time**: {{timestamp}}
**Message**: {{message}}

**Blocker Details / Failure Trace**:
```text
{{trace}}
```

**Required Action**: {{action}}
