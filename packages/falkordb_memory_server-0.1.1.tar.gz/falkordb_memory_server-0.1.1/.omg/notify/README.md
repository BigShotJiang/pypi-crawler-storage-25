# OmG Notification Manager

This directory stores configuration, templates, and logs for the OmG Notification Manager.

## Extension Boundary
OmG manages the trigger policy, templates, and state artifacts. The actual OS/webhook delivery is handled by Gemini host hooks, shell scripts, or project-specific bridges.

Worker/delegated sessions stay read-only and do not dispatch external notifications.

## Templates
- `compact.md`: Concise, single-line summary.
- `detailed.md`: Full event context with structured metadata.
- `incident.md`: High-priority alert format for blockers and failures.
