#!/usr/bin/env python3
import json
import os
import sys
import traceback
import urllib.error
import urllib.request
from collections import Counter
from pathlib import Path


def debug_log(msg):
    try:
        with open("/tmp/feishu-debug.log", "a") as f:
            f.write(f"{msg}\n")
    except Exception:
        pass


debug_log("--- WEBHOOK STARTED ---")
debug_log(f"CWD: {os.getcwd()}")
debug_log(f"ARGS: {sys.argv}")

# Paths
WORKSPACE_ROOT = Path(os.getcwd())
NOTIFY_STATE = WORKSPACE_ROOT / ".omg" / "state" / "notify.json"


def main():
    debug_log(f"Looking for state at {NOTIFY_STATE}")
    if not NOTIFY_STATE.exists():
        debug_log("NOTIFY_STATE does not exist. Exiting.")
        sys.exit(0)

    try:
        with open(NOTIFY_STATE) as f:
            notify_data = json.load(f)
    except Exception as e:
        debug_log(f"Failed to load NOTIFY_STATE: {e}")
        sys.exit(0)

    # Check if webhook is enabled and configured
    if not notify_data.get("enabled", False):
        debug_log("notify_data['enabled'] is False.")
        sys.exit(0)
    if not notify_data.get("channels", {}).get("webhook", False):
        debug_log("webhook channel is disabled.")
        sys.exit(0)

    webhook_url = notify_data.get("webhook_config", {}).get("url")
    if not webhook_url:
        debug_log("No webhook URL configured.")
        sys.exit(0)

    header = "📢 系统通知"
    if len(sys.argv) > 2:
        event_type = sys.argv[1]
        message = sys.argv[2]
        debug_log(f"Event: {event_type}, Message: {message}")
        if (
            "fail" in event_type.lower()
            or "blocked" in event_type.lower()
            or "error" in event_type.lower()
        ):
            header = "🚨 异常告警"
        elif (
            "pass" in event_type.lower()
            or "done" in event_type.lower()
            or "success" in event_type.lower()
        ):
            header = "✅ 成功通知"
    else:
        # Check taskboard status for all items
        taskboard_path = WORKSPACE_ROOT / ".omg" / "state" / "taskboard.json"
        debug_log(f"Looking for taskboard at {taskboard_path}")
        if not taskboard_path.exists():
            debug_log("Taskboard does not exist. Exiting.")
            sys.exit(0)

        with open(taskboard_path) as f:
            tb_data = json.load(f)

        tasks = tb_data.get("tasks", [])
        if not tasks:
            debug_log("Taskboard is empty. Exiting.")
            sys.exit(0)

        status_counts = Counter(t.get("status", "unknown") for t in tasks)
        blocked_tasks = [t for t in tasks if t.get("status") == "blocked"]

        status_summary = ", ".join(f"{k}: {v}" for k, v in status_counts.items())
        message = f"任务看板状态: {status_summary}\n"

        if blocked_tasks:
            event_type = "verify-failed"
            header = "🚨 异常告警"
            blocked_ids = [t["id"] for t in blocked_tasks]
            message += f"被阻塞的任务: {', '.join(blocked_ids)}。"
        else:
            event_type = "status-update"
            header = "✅ 状态更新"
            message += "所有进行中的任务都在正常推进或已完成。"

    # Create payload
    payload = {
        "msg_type": "text",
        "content": {"text": f"{header}: {event_type} \n\n详细信息: {message}"},
    }

    debug_log(f"Sending payload: {payload} to {webhook_url}")
    req = urllib.request.Request(
        webhook_url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        urllib.request.urlopen(req, timeout=5)
        debug_log("Webhook sent successfully.")
    except Exception as e:
        debug_log(f"Feishu webhook failed: {e}")
        print(f"Feishu webhook failed: {e}", file=sys.stderr)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        debug_log(f"Unhandled exception: {traceback.format_exc()}")
