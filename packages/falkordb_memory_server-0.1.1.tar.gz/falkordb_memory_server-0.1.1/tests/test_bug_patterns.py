"""Tests for bug pattern registry (SOLVED_BY edges)."""

import sys
from unittest.mock import MagicMock, patch

sys.path.insert(0, "src")

from falkordb_memory_server.memory_tools import MemoryManager
from falkordb_memory_server.schema import MemoryType, NodeLabel


class TestBugPatterns:
    """Test Bug Pattern Registry logic."""

    def test_remember_problem(self):
        """Test storing a problem memory."""
        mock_ops = MagicMock()
        manager = MemoryManager(ops=mock_ops)

        content = {"error": "Connection timeout", "category": "network"}
        manager.remember(MemoryType.PROBLEM, content)

        # Verify node creation with correct label
        call_args = mock_ops.create_node.call_args
        label = call_args[0][0]
        properties = call_args[0][1]

        assert label == NodeLabel.PROBLEM
        assert properties["error"] == "Connection timeout"
        assert properties["category"] == "network"

    def test_remember_solution(self):
        """Test storing a solution memory."""
        mock_ops = MagicMock()
        manager = MemoryManager(ops=mock_ops)

        content = {"fix": "Add connection pool", "code": "pool = Pool()"}
        manager.remember(MemoryType.SOLUTION, content)

        # Verify node creation with correct label
        call_args = mock_ops.create_node.call_args
        label = call_args[0][0]
        properties = call_args[0][1]

        assert label == NodeLabel.SOLUTION
        assert properties["fix"] == "Add connection pool"
        assert properties["code"] == "pool = Pool()"

    def test_get_bug_patterns(self):
        """Test retrieving bug patterns."""
        mock_ops = MagicMock()
        manager = MemoryManager(ops=mock_ops)

        manager.get_bug_patterns(category="network")

        # Verify correct Cypher query and params
        call_args = mock_ops.query.call_args
        cypher = call_args[0][0]
        params = call_args[1].get("params")

        assert "MATCH (p:Problem)-[r:SOLVED_BY]->(s:Solution)" in cypher
        assert "WHERE p.category = $category" in cypher
        assert params["category"] == "network"
        assert "LIMIT 50" in cypher
        assert call_args[1].get("read_only") is True


@patch("falkordb_memory_server.memory_tools.MemoryManager")
def test_handle_get_bug_patterns(mock_manager_class):
    """Test handle_get_bug_patterns tool handler."""
    from falkordb_memory_server.server import handle_get_bug_patterns

    mock_ops = MagicMock()

    mock_manager = MagicMock()
    mock_manager_class.return_value = mock_manager
    mock_manager.get_bug_patterns.return_value = {"result_set": []}

    args = {"problem_id": 789, "category": "database"}
    result = handle_get_bug_patterns(mock_ops, args)

    assert len(result) == 1
    assert "result_set" in result[0].text
    mock_manager.get_bug_patterns.assert_called_with(789, "database")
