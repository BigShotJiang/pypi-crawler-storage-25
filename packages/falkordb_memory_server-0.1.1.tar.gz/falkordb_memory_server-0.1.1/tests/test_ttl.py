from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock

import pytest

from falkordb_memory_server.ttl import TTLManager, get_ttl_manager


@pytest.fixture
def mock_ops():
    ops = MagicMock()
    return ops


@pytest.fixture
def ttl_manager(mock_ops):
    return TTLManager(ops=mock_ops)


def test_singleton_get_ttl_manager():
    tm1 = get_ttl_manager()
    tm2 = get_ttl_manager()
    assert tm1 is tm2


def test_get_expired_nodes(ttl_manager, mock_ops):
    now = datetime.now(timezone.utc)
    old_time = (now - timedelta(seconds=2000)).isoformat()
    new_time = now.isoformat()

    mock_ops.query.return_value = {
        "result_set": [
            [1, ["Memory"], 1000, old_time],  # expired (2000s > 1000s)
            [2, ["Memory"], 3000, new_time],  # not expired
            [3, ["Memory"], 1000, "invalid_time"],  # error parsing
        ]
    }

    expired = ttl_manager.get_expired_nodes(batch_size=10)
    assert len(expired) == 1
    assert expired[0]["node_id"] == 1
    assert expired[0]["ttl"] == 1000


def test_cleanup_expired(ttl_manager, mock_ops):
    now = datetime.now(timezone.utc)
    old_time = (now - timedelta(seconds=2000)).isoformat()
    mock_ops.query.return_value = {"result_set": [[1, ["Memory"], 1000, old_time]]}
    mock_ops.delete_nodes.return_value = {"deleted_count": 1}

    # Dry run
    res1 = ttl_manager.cleanup_expired(dry_run=True)
    assert res1["dry_run"] is True
    assert res1["expired_count"] == 1

    # Actual run
    res2 = ttl_manager.cleanup_expired(dry_run=False)
    assert res2["deleted_count"] == 1
    mock_ops.delete_nodes.assert_called_once_with([1], cascade=True)


def test_cleanup_expired_empty(ttl_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": []}
    res = ttl_manager.cleanup_expired()
    assert res["deleted_count"] == 0


def test_cleanup_expired_error(ttl_manager, mock_ops):
    now = datetime.now(timezone.utc)
    old_time = (now - timedelta(seconds=2000)).isoformat()
    mock_ops.query.return_value = {"result_set": [[1, ["Memory"], 1000, old_time]]}
    mock_ops.delete_nodes.side_effect = Exception("Delete error")
    res = ttl_manager.cleanup_expired()
    assert res["deleted_count"] == 0
    assert "Delete error" in res["errors"]


def test_get_ttl_stats(ttl_manager, mock_ops):
    # Setup multiple queries return values
    mock_ops.query.side_effect = [
        {"result_set": [[15]]},  # total_with_ttl
        {"result_set": []},  # expired (get_expired_nodes)
        {"result_set": [["Memory", 10], ["Agent", 5]]},  # by_label
    ]

    stats = ttl_manager.get_ttl_stats()
    assert stats["total_with_ttl"] == 15
    assert stats["expired_count"] == 0
    assert stats["by_label"] == {"Memory": 10, "Agent": 5}


def test_set_ttl(ttl_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [["node"]]}

    res = ttl_manager.set_ttl(1, 3600)
    assert res["result_set"] == [["node"]]

    res2 = ttl_manager.set_ttl(1, 0)
    assert res2["result_set"] == [["node"]]


def test_extend_ttl(ttl_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [[4600]]}
    res = ttl_manager.extend_ttl(1, 1000)
    assert res["result_set"] == [[4600]]


def test_refresh_ttl(ttl_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [["node"]]}
    res = ttl_manager.refresh_ttl(1)
    assert res["result_set"] == [["node"]]


@pytest.mark.asyncio
async def test_background_cleanup(ttl_manager, mock_ops):
    # Test start and stop
    mock_ops.query.return_value = {"result_set": []}  # get_expired_nodes

    await ttl_manager.start_background_cleanup(interval_seconds=1)
    assert ttl_manager._running is True
    assert ttl_manager._cleanup_task is not None

    # Test start again does nothing
    await ttl_manager.start_background_cleanup(interval_seconds=1)

    await ttl_manager.stop_background_cleanup()
    assert ttl_manager._running is False
    assert ttl_manager._cleanup_task is None
