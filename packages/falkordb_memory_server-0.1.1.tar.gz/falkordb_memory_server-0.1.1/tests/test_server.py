"""Tests for MCP server tools."""

import sys

sys.path.insert(0, "src")

from unittest.mock import Mock

from falkordb_memory_server.server import (
    TOOLS,
    handle_extract,
    handle_mine,
)


class TestToolDefinitions:
    """Test MCP tool definitions."""

    def test_tool_count(self):
        """Test that all expected tools are defined."""
        assert len(TOOLS) == 30

    def test_memory_invalidate_tool_exists(self):
        """Test memory_invalidate tool is defined."""
        tool_names = [t.name for t in TOOLS]
        assert "memory_invalidate" in tool_names

    def test_memory_get_conventions_tool_exists(self):
        """Test memory_get_conventions tool is defined."""
        tool_names = [t.name for t in TOOLS]
        assert "memory_get_conventions" in tool_names

    def test_memory_get_refactors_tool_exists(self):
        """Test memory_get_refactors tool is defined."""
        tool_names = [t.name for t in TOOLS]
        assert "memory_get_refactors" in tool_names

    def test_memory_get_test_coverage_tool_exists(self):
        """Test memory_get_test_coverage tool is defined."""
        tool_names = [t.name for t in TOOLS]
        assert "memory_get_test_coverage" in tool_names

    def test_memory_get_api_usage_tool_exists(self):
        """Test memory_get_api_usage tool is defined."""
        tool_names = [t.name for t in TOOLS]
        assert "memory_get_api_usage" in tool_names

    def test_memory_get_reviews_tool_exists(self):
        """Test memory_get_reviews tool is defined."""
        tool_names = [t.name for t in TOOLS]
        assert "memory_get_reviews" in tool_names

    def test_memory_load_project_context_tool_exists(self):
        """Test memory_load_project_context tool is defined."""
        tool_names = [t.name for t in TOOLS]
        assert "memory_load_project_context" in tool_names

    def test_memory_extract_tool_exists(self):
        """Test memory_extract tool is defined."""
        tool_names = [t.name for t in TOOLS]
        assert "memory_extract" in tool_names

    def test_memory_mine_tool_exists(self):
        """Test memory_mine tool is defined."""
        tool_names = [t.name for t in TOOLS]
        assert "memory_mine" in tool_names

    def test_memory_wake_up_tool_exists(self):
        """Test memory_wake_up tool is defined."""
        tool_names = [t.name for t in TOOLS]
        assert "memory_wake_up" in tool_names

    def test_memory_extract_schema(self):
        """Test memory_extract tool schema."""
        tool = next(t for t in TOOLS if t.name == "memory_extract")

        assert "text" in tool.inputSchema["properties"]
        assert "text" in tool.inputSchema["required"]

    def test_memory_mine_schema(self):
        """Test memory_mine tool schema."""
        tool = next(t for t in TOOLS if t.name == "memory_mine")

        assert "path" in tool.inputSchema["properties"]
        assert "path" in tool.inputSchema["required"]

    def test_memory_wake_up_schema(self):
        """Test memory_wake_up tool schema."""
        tool = next(t for t in TOOLS if t.name == "memory_wake_up")

        assert "project_path" in tool.inputSchema["properties"]
        assert "limit" in tool.inputSchema["properties"]

    def test_memory_get_conventions_schema(self):
        """Test memory_get_conventions tool schema."""
        tool = next(t for t in TOOLS if t.name == "memory_get_conventions")

        assert "convention_type" in tool.inputSchema["properties"]
        assert "project_path" in tool.inputSchema["properties"]

    def test_memory_get_refactors_schema(self):
        """Test memory_get_refactors tool schema."""
        tool = next(t for t in TOOLS if t.name == "memory_get_refactors")

        assert "target" in tool.inputSchema["properties"]
        assert "include_invalid" in tool.inputSchema["properties"]

    def test_memory_get_test_coverage_schema(self):
        """Test memory_get_test_coverage tool schema."""
        tool = next(t for t in TOOLS if t.name == "memory_get_test_coverage")

        assert "target" in tool.inputSchema["properties"]
        assert "include_invalid" in tool.inputSchema["properties"]

    def test_memory_get_api_usage_schema(self):
        """Test memory_get_api_usage tool schema."""
        tool = next(t for t in TOOLS if t.name == "memory_get_api_usage")

        assert "api_name" in tool.inputSchema["properties"]
        assert "include_invalid" in tool.inputSchema["properties"]

    def test_memory_get_reviews_schema(self):
        """Test memory_get_reviews tool schema."""
        tool = next(t for t in TOOLS if t.name == "memory_get_reviews")

        assert "target" in tool.inputSchema["properties"]
        assert "include_invalid" in tool.inputSchema["properties"]


class TestHandleExtract:
    """Test handle_extract function."""

    def test_extract_basic(self):
        """Test basic extraction."""
        mock_ops = Mock()
        args = {
            "text": "We decided to use Python for the backend.",
            "min_confidence": 0.2,
            "store": False,
        }

        result = handle_extract(mock_ops, args)

        assert len(result) == 1
        assert "decision" in result[0].text.lower()

    def test_extract_with_store(self):
        """Test extraction with storing to graph."""
        mock_ops = Mock()
        # Mock create_node to return a dict
        mock_ops.create_node.return_value = {"id": 123, "properties": {}}
        # Mock query for auto-invalidation
        mock_ops.query.return_value = {"result_set": []}

        args = {
            "text": "We decided to use Python.",
            "min_confidence": 0.2,
            "store": True,
        }

        handle_extract(mock_ops, args)

        # Should have called create_node via MemoryManager
        assert mock_ops.create_node.called

    def test_extract_empty_text(self):
        """Test extraction with empty text."""
        mock_ops = Mock()
        args = {"text": ""}

        result = handle_extract(mock_ops, args)

        assert len(result) == 1
        # Should return valid JSON even for empty input


class TestHandleMine:
    """Test handle_mine function."""

    def test_mine_file(self):
        """Test mining a file."""
        mock_ops = Mock()
        args = {
            "path": "src/falkordb_memory_server/extractor.py",
            "store": False,
        }

        result = handle_mine(mock_ops, args)

        assert len(result) == 1
        # Should find some memories in the file

    def test_mine_nonexistent_path(self):
        """Test mining a non-existent path."""
        mock_ops = Mock()
        args = {
            "path": "/nonexistent/path",
        }

        result = handle_mine(mock_ops, args)

        assert len(result) == 1
        assert "Error" in result[0].text

    def test_mine_with_store(self):
        """Test mining with storing to graph."""
        mock_ops = Mock()
        # Mock create_node to return a dict
        mock_ops.create_node.return_value = {"id": 123, "properties": {}}
        # Mock query for Artifact merge and auto-invalidation
        mock_ops.query.return_value = {"result_set": []}
        mock_ops.safe_query.return_value = {"result_set": []}

        args = {
            "path": "src/falkordb_memory_server/schema.py",
            "store": True,
            "recursive": False,
        }

        handle_mine(mock_ops, args)

        # Artifact query should have been called
        assert mock_ops.safe_query.called
