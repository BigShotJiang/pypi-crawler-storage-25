"""Tests for wake-up command (Load project-critical facts)."""

import json
import sys
from unittest.mock import MagicMock, patch

sys.path.insert(0, "src")

from falkordb_memory_server.memory_tools import MemoryManager


class TestWakeUp:
    """Test Wake-up Command logic."""

    def test_wake_up_no_project_path(self):
        """Test wake_up without a specific project path."""
        mock_ops = MagicMock()
        manager = MemoryManager(ops=mock_ops)

        # Mock responses for the 5 queries
        mock_ops.query.side_effect = [
            {"result_set": [["session1"]]},  # session
            {"result_set": [["decision1"]]},  # decisions
            {"result_set": [["learning1"]]},  # learnings
            {"result_set": [["context1"]]},  # project context
            {"result_set": [["task1"]]},  # tasks
        ]

        limit = 3
        result = manager.wake_up(limit=limit)

        # Verify result structure
        assert "active_session" in result
        assert "decisions" in result
        assert "critical_learnings" in result
        assert "project_context" in result
        assert "tasks" in result

        assert result["active_session"] == ["session1"]
        assert result["decisions"] == ["decision1"]
        assert result["critical_learnings"] == ["learning1"]
        assert result["project_context"] == ["context1"]
        assert result["tasks"] == ["task1"]

        # Verify 5 queries were made
        assert mock_ops.query.call_count == 5

        # Check first query (session)
        args, kwargs = mock_ops.query.call_args_list[0]
        assert "MATCH (s:Session {status: 'active'})" in args[0]
        assert "project_path" not in args[0]

        # Check second query (decisions)
        args, kwargs = mock_ops.query.call_args_list[1]
        assert "MATCH (d:Decision)" in args[0]
        assert f"LIMIT {limit}" in args[0]

    def test_wake_up_with_project_path(self):
        """Test wake_up with a specific project path."""
        mock_ops = MagicMock()
        manager = MemoryManager(ops=mock_ops)

        # Mock responses for the 5 queries
        mock_ops.query.side_effect = [
            {"result_set": [["session1"]]},  # session
            {"result_set": [["decision1"]]},  # decisions
            {"result_set": [["learning1"]]},  # learnings
            {"result_set": [["context1"]]},  # project context
            {"result_set": [["task1"]]},  # tasks
        ]

        project_path = "/path/to/project"
        result = manager.wake_up(project_path=project_path)

        # Verify result
        assert result["active_session"] == ["session1"]

        # Verify 5 queries were made
        assert mock_ops.query.call_count == 5

        # Check first query (session) - should have project_path filter
        args, kwargs = mock_ops.query.call_args_list[0]
        assert "WHERE s.project_path = $project_path" in args[0]
        assert kwargs["params"]["project_path"] == project_path

        # Check second query (decisions)
        args, kwargs = mock_ops.query.call_args_list[1]
        assert "d.context CONTAINS $project_path" in args[0]
        assert kwargs["params"]["project_path"] == project_path


@patch("falkordb_memory_server.memory_tools.get_memory_manager")
def test_handle_wake_up(mock_get_manager):
    """Test handle_wake_up tool handler."""
    from falkordb_memory_server.server import handle_wake_up

    mock_ops = MagicMock()
    mock_manager = MagicMock()
    mock_get_manager.return_value = mock_manager

    expected_result = {"active_session": [], "decisions": [], "critical_learnings": [], "tasks": []}
    mock_manager.wake_up.return_value = expected_result

    args = {"project_path": "/path/to/project", "limit": 5}
    result = handle_wake_up(mock_ops, args)

    assert len(result) == 1
    result_data = json.loads(result[0].text)
    assert result_data == expected_result
    mock_manager.wake_up.assert_called_with("/path/to/project", 5)
