from unittest.mock import MagicMock, patch

import pytest

from falkordb_memory_server.session import SessionManager, get_session_manager


@pytest.fixture
def mock_ops():
    ops = MagicMock()
    return ops


@pytest.fixture
def mock_settings():
    with patch("falkordb_memory_server.session.get_settings") as mock_get_settings:
        settings = MagicMock()
        settings.default_ttl = 3600
        mock_get_settings.return_value = settings
        yield settings


@pytest.fixture
def session_manager(mock_ops, mock_settings):
    manager = SessionManager(ops=mock_ops)
    manager.settings = mock_settings
    return manager


def test_singleton_get_session_manager():
    sm1 = get_session_manager()
    sm2 = get_session_manager()
    assert sm1 is sm2


def test_start_session(session_manager, mock_ops):
    mock_ops.create_node.side_effect = [
        {"node_id": 1, "session_id": "mock_id"},  # Session node
        {"node_id": 2},  # Agent node
    ]
    mock_ops.query.return_value = {"result_set": [[{"id": "agent1"}]]}

    res = session_manager.start_session(
        "claude", "agent1", project_path="/path/to/project", objective="test"
    )

    assert "session_id" in res
    assert res["agent_node_id"] == "agent1"
    assert session_manager._current_session_id == res["session_id"]
    mock_ops.create_edge.assert_called_with(1, "STARTED_BY", "agent1")


def test_end_session(session_manager, mock_ops):
    session_manager._current_session_id = "sess1"
    mock_ops.query.return_value = {"result_set": [[{"id": "sess1"}]]}

    res = session_manager.end_session("sess1", status="completed", summary="done")

    assert res["session_id"] == "sess1"
    assert res["status"] == "completed"
    assert session_manager._current_session_id is None


def test_continue_session(session_manager, mock_ops):
    def mock_query(cypher, params=None, *args, **kwargs):
        if cypher and "CONTINUES" in cypher:
            return {"result_set": []}
        if cypher and "old_sess" in str(params):
            return {
                "result_set": [
                    [
                        {
                            "properties": {
                                "agent_type": "claude",
                                "agent_id": "a1",
                                "project_path": "/p",
                            }
                        }
                    ]
                ]
            }
        return {"result_set": [[{"id": "a2"}]]}

    mock_ops.query.side_effect = mock_query

    # start_session calls inside continue_session
    mock_ops.create_node.side_effect = [
        {"node_id": 3},  # new session node
        {"node_id": 4},  # agent node
    ]

    res = session_manager.continue_session("old_sess", new_agent_id="a2", new_objective="new goal")
    assert "session_id" in res
    assert res["continued_from"] == "old_sess"


def test_continue_session_not_found(session_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": []}
    res = session_manager.continue_session("old_sess")
    assert "error" in res


def test_get_current_session(session_manager, mock_ops):
    session_manager._current_session_id = "sess1"
    mock_ops.query.return_value = {"result_set": [[{"properties": {"objective": "test"}}]]}

    res = session_manager.get_current_session()
    assert res["session_id"] == "sess1"
    assert res["properties"]["objective"] == "test"

    session_manager._current_session_id = None
    assert session_manager.get_current_session() is None


def test_get_session_memories(session_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [["mem1", "OCCURRED_IN"]]}

    res = session_manager.get_session_memories("sess1")
    assert res["result_set"] == [["mem1", "OCCURRED_IN"]]

    res2 = session_manager.get_session_memories("sess1", memory_types=["Learning"])
    assert res2["result_set"] == [["mem1", "OCCURRED_IN"]]


def test_add_memory_to_session(session_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [["OCCURRED_IN"]]}
    res = session_manager.add_memory_to_session("sess1", 5, "OCCURRED_IN")
    assert res["result_set"] == [["OCCURRED_IN"]]


def test_list_sessions(session_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [["sess1"], ["sess2"]]}

    res = session_manager.list_sessions(agent_type="claude", status="active")
    assert res["result_set"] == [["sess1"], ["sess2"]]


def test_ensure_agent(session_manager, mock_ops):
    # Agent exists
    mock_ops.query.side_effect = [
        {"result_set": [[{"id": 10}]]},
        {"result_set": []},  # update query
    ]
    res = session_manager._ensure_agent("claude", "a1")
    assert res["node_id"] == 10

    # Agent doesn't exist
    mock_ops.query.side_effect = [{"result_set": []}]
    mock_ops.create_node.return_value = {"node_id": 11}
    res2 = session_manager._ensure_agent("claude", "a2")
    assert res2["node_id"] == 11
