import os
import sys
from unittest.mock import MagicMock, patch

import pytest

# Add src to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from falkordb_memory_server.semantic_tools import SemanticSearchEngine


@pytest.fixture
def mock_ops():
    return MagicMock()


@pytest.fixture
def mock_embedding_service():
    service = MagicMock()
    service.is_available.return_value = True
    embedding = MagicMock()
    embedding.vector = [0.1, 0.2, 0.3]
    embedding.model = "test-model"
    embedding.dimension = 3
    embedding.text_preview = "test"
    service.generate_embedding.return_value = embedding
    return service


@pytest.fixture
def engine(mock_ops, mock_embedding_service):
    with patch("falkordb_memory_server.semantic_tools.get_settings") as mock_settings:
        mock_settings.return_value.embedding_dimension = 3
        return SemanticSearchEngine(ops=mock_ops, embedding_service=mock_embedding_service)


def test_progressive_search_layer1(engine, mock_ops):
    # Layer 1 should just call search
    mock_ops.semantic_search.return_value = [
        {"node": {"id": 1, "properties": {"content": "test1"}}, "score": 0.9}
    ]

    results = engine.progressive_search(query="test", layer=1)

    assert len(results) == 1
    assert results[0]["node"]["id"] == 1
    mock_ops.semantic_search.assert_called_once()
    mock_ops.query.assert_not_called()


def test_progressive_search_layer2(engine, mock_ops):
    # Layer 2 should call search AND query for 1-hop neighbors
    mock_ops.semantic_search.return_value = [
        {"node": {"id": 1, "properties": {"content": "test1"}}, "score": 0.9}
    ]

    # Mock neighbor query result
    # In reality falkordb-py returns list of rows, each row is a list of results
    mock_ops.query.return_value = {
        "result_set": [[{"id": 2, "properties": {"content": "neighbor"}}]]
    }

    results = engine.progressive_search(query="test", layer=2)

    assert len(results) == 2
    assert results[0]["node"]["id"] == 1
    assert results[1]["node"]["id"] == 2
    assert "2-layer context" in results[1]["context"]
    assert "1-hop neighbor" in results[1]["context"]

    # Check if correct cypher was called
    args, kwargs = mock_ops.query.call_args
    assert "MATCH (n)-[*1..1]-(m)" in args[0]
    assert kwargs["params"]["ids"] == [1]


def test_progressive_search_layer3(engine, mock_ops):
    # Layer 3 should call search AND query for 2-hop traversal
    mock_ops.semantic_search.return_value = [
        {"node": {"id": 1, "properties": {"content": "test1"}}, "score": 0.9}
    ]

    # Mock neighbor query result
    mock_ops.query.return_value = {
        "result_set": [[{"id": 2, "properties": {"content": "neighbor"}}]]
    }

    results = engine.progressive_search(query="test", layer=3)

    assert len(results) == 2
    assert "3-layer context" in results[1]["context"]
    assert "2-hop neighbor" in results[1]["context"]

    # Check if correct cypher was called
    args, kwargs = mock_ops.query.call_args
    assert "MATCH (n)-[*1..2]-(m)" in args[0]


def test_progressive_search_no_results(engine, mock_ops):
    mock_ops.semantic_search.return_value = []

    results = engine.progressive_search(query="test", layer=2)

    assert len(results) == 0
    mock_ops.query.assert_not_called()


def test_progressive_search_duplicate_neighbors(engine, mock_ops):
    # Neighbors that are already in base results should be filtered out
    mock_ops.semantic_search.return_value = [
        {"node": {"id": 1, "properties": {"content": "test1"}}, "score": 0.9}
    ]

    mock_ops.query.return_value = {
        "result_set": [
            [{"id": 1, "properties": {"content": "test1"}}],  # Duplicate
            [{"id": 2, "properties": {"content": "neighbor"}}],
        ]
    }

    results = engine.progressive_search(query="test", layer=2)

    assert len(results) == 2  # Base node 1 and neighbor node 2
    # Convert ids to int for comparison
    ids = []
    for r in results:
        node = r["node"]
        node_id = node.get("id") if isinstance(node, dict) else getattr(node, "id", None)
        ids.append(int(node_id))

    assert ids == [1, 2]


def test_handle_semantic_search_layer_param(mock_ops):
    # Test that the server handler passes the layer parameter
    from falkordb_memory_server.server import handle_semantic_search

    with patch("falkordb_memory_server.handlers.semantic.get_semantic_engine") as mock_get_engine:
        mock_engine = MagicMock()
        mock_get_engine.return_value = mock_engine

        args = {"query": "test", "layer": 2}
        handle_semantic_search(mock_ops, args)

        mock_engine.progressive_search.assert_called_once()
        _, kwargs = mock_engine.progressive_search.call_args
        assert kwargs["layer"] == 2
