"""Tests for memory extractor."""

import sys

sys.path.insert(0, "src")

from falkordb_memory_server.extractor import (
    ExtractedMemory,
    ExtractionResult,
    MemoryCategory,
    MemoryExtractor,
    mine_file,
)


class TestMemoryExtractor:
    """Test MemoryExtractor class."""

    def test_extract_decision(self):
        """Test extraction of decision memories."""
        extractor = MemoryExtractor(min_confidence=0.2)
        text = "We decided to use PostgreSQL because it handles JSON better."

        result = extractor.extract(text)

        assert len(result.memories) >= 1
        assert result.memories[0].category == MemoryCategory.DECISION

    def test_extract_preference(self):
        """Test extraction of preference memories."""
        extractor = MemoryExtractor(min_confidence=0.2)
        text = "I always use functional components in React."

        result = extractor.extract(text)

        assert len(result.memories) >= 1
        assert result.memories[0].category == MemoryCategory.PREFERENCE

    def test_extract_milestone(self):
        """Test extraction of milestone memories."""
        extractor = MemoryExtractor(min_confidence=0.2)
        text = "It worked! The feature is now fully implemented."

        result = extractor.extract(text)

        assert len(result.memories) >= 1
        # Milestone or problem resolved
        assert result.memories[0].category in [
            MemoryCategory.MILESTONE,
            MemoryCategory.PROBLEM,
        ]

    def test_extract_learning(self):
        """Test extraction of learning memories."""
        extractor = MemoryExtractor(min_confidence=0.2)
        text = "We learned that caching is essential for performance."

        result = extractor.extract(text)

        assert len(result.memories) >= 1
        assert result.memories[0].category == MemoryCategory.LEARNING

    def test_extract_multiple_paragraphs(self):
        """Test extraction from multiple paragraphs."""
        extractor = MemoryExtractor(min_confidence=0.2)
        text = """
We decided to use Python for the backend.

I always use pytest for testing.

It worked! The bug is fixed.
"""

        result = extractor.extract(text)

        assert len(result.memories) >= 2
        assert result.total_chunks >= 3

    def test_extract_from_tool_use(self):
        """Test extraction from tool usage."""
        extractor = MemoryExtractor()

        memory = extractor.extract_from_tool_use(
            tool_name="read_file",
            tool_input={"path": "/src/main.py"},
            tool_output="def main(): pass",
        )

        assert memory is not None
        assert memory.metadata.get("tool_name") == "read_file"

    def test_confidence_threshold(self):
        """Test confidence threshold filtering."""
        extractor_high = MemoryExtractor(min_confidence=0.8)
        extractor_low = MemoryExtractor(min_confidence=0.1)

        text = "We decided to use Python."

        result_high = extractor_high.extract(text)
        result_low = extractor_low.extract(text)

        # Lower threshold should return more or equal memories
        assert len(result_low.memories) >= len(result_high.memories)

    def test_office_mode_extraction(self):
        """Test extraction in office mode."""
        from falkordb_memory_server.extractor import ExtractionMode

        extractor = MemoryExtractor(min_confidence=0.1, mode=ExtractionMode.OFFICE)

        # Test daily office task
        text = "请安排明天下午的周会并发送邮件确认"
        result = extractor.extract(text)

        tasks = [m for m in result.memories if m.category == MemoryCategory.TASK]
        assert len(tasks) > 0
        assert "安排明天下午的周会并发送邮件确认" in tasks[0].content

        # In office mode, dev categories should not be extracted
        # "refactor" is a dev category
        text_dev = "I will refactor the backend."
        result_dev = extractor.extract(text_dev)
        refactors = [m for m in result_dev.memories if m.category == MemoryCategory.REFACTOR]
        assert len(refactors) == 0

    def test_empty_text(self):
        """Test extraction from empty text."""
        extractor = MemoryExtractor()
        result = extractor.extract("")

        assert len(result.memories) == 0

    def test_code_block_skip(self):
        """Test that code blocks are skipped during extraction."""
        extractor = MemoryExtractor(min_confidence=0.2)
        text = """
We decided to use this pattern:

```python
def hello():
    print("world")
```

This approach is better.
"""

        result = extractor.extract(text)

        # Should still extract the decision
        assert len(result.memories) >= 1


class TestMineFile:
    """Test file mining functions."""

    def test_mine_nonexistent_file(self):
        """Test mining a non-existent file."""
        result = mine_file("/nonexistent/path/file.txt")

        assert len(result.memories) == 0
        assert result.total_chunks == 0

    def test_mine_python_file(self):
        """Test mining a Python file."""
        # Mine the extractor.py file itself
        result = mine_file("src/falkordb_memory_server/extractor.py")

        # Should find some memories
        assert result.total_chunks > 0


class TestMemoryCategory:
    """Test MemoryCategory enum."""

    def test_category_values(self):
        """Test that all category values exist."""
        expected = {
            "decision",
            "preference",
            "milestone",
            "problem",
            "emotional",
            "learning",
            "solution",
            "context",
            "dependency",
            "convention",
            "refactor",
            "test",
            "api",
            "review",
            "task",
            "general",
        }
        actual = {c.value for c in MemoryCategory}

        assert expected == actual


class TestExtractionResult:
    """Test ExtractionResult model."""

    def test_empty_result(self):
        """Test empty extraction result."""
        result = ExtractionResult()

        assert len(result.memories) == 0
        assert result.total_chunks == 0
        assert result.by_category == {}

    def test_result_with_memories(self):
        """Test result with memories."""
        memory = ExtractedMemory(
            content="Test content",
            category=MemoryCategory.DECISION,
            confidence=0.5,
        )
        result = ExtractionResult(
            memories=[memory],
            total_chunks=1,
            by_category={"decision": 1},
        )

        assert len(result.memories) == 1
        assert result.by_category["decision"] == 1
