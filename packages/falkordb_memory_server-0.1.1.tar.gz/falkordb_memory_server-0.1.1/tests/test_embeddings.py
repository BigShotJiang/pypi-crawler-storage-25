"""Tests for embedding service."""

import sys

sys.path.insert(0, "src")

from unittest.mock import MagicMock, patch


class TestEmbeddingService:
    """Test embedding service functionality."""

    def test_get_embedding_model_lazy_load(self):
        """Test that embedding model is loaded lazily."""
        with patch.dict("sys.modules", {"sentence_transformers": MagicMock()}):
            # Reset the global model
            import falkordb_memory_server.embeddings as emb_module

            emb_module._model = None

            # First call should trigger load
            with patch("falkordb_memory_server.embeddings.get_settings") as mock_settings:
                mock_settings.return_value.embedding_model = "test-model"
                # Don't actually call get_embedding_model to avoid loading real model
                # Just verify the module structure

    def test_embedding_service_init(self):
        """Test EmbeddingService initialization."""
        from falkordb_memory_server.embeddings import EmbeddingService

        service = EmbeddingService()

        assert service.settings is not None
        assert service._model is None  # Lazy loaded

    def test_compute_similarity(self):
        """Test cosine similarity computation."""
        from falkordb_memory_server.embeddings import EmbeddingService

        service = EmbeddingService()

        # Identical vectors should have similarity 1.0
        vec1 = [1.0, 0.0, 0.0]
        vec2 = [1.0, 0.0, 0.0]
        similarity = service.compute_similarity(vec1, vec2)
        assert abs(similarity - 1.0) < 0.001

        # Orthogonal vectors should have similarity 0.0
        vec1 = [1.0, 0.0, 0.0]
        vec2 = [0.0, 1.0, 0.0]
        similarity = service.compute_similarity(vec1, vec2)
        assert abs(similarity - 0.0) < 0.001

        # Opposite vectors should have similarity -1.0
        vec1 = [1.0, 0.0, 0.0]
        vec2 = [-1.0, 0.0, 0.0]
        similarity = service.compute_similarity(vec1, vec2)
        assert abs(similarity - (-1.0)) < 0.001

    def test_prepare_text_for_embedding(self):
        """Test text preparation for embedding."""
        from falkordb_memory_server.embeddings import EmbeddingService

        service = EmbeddingService()

        # Test with full content
        content = {
            "title": "Test Title",
            "content": "Test content",
            "context": "Test context",
            "tags": ["tag1", "tag2"],
            "category": "learning",
        }
        text = service.prepare_text_for_embedding(content, "memory")

        assert "Type: memory" in text
        assert "Title: Test Title" in text
        assert "Content: Test content" in text
        assert "Context: Test context" in text
        assert "Tags: tag1, tag2" in text
        assert "Category: learning" in text

    def test_prepare_text_for_embedding_decision(self):
        """Test text preparation for decision content."""
        from falkordb_memory_server.embeddings import EmbeddingService

        service = EmbeddingService()

        content = {
            "title": "Database Decision",
            "content": "Choose PostgreSQL",
            "rationale": "Better JSON support",
        }
        text = service.prepare_text_for_embedding(content, "decision")

        assert "Type: decision" in text
        assert "Rationale: Better JSON support" in text

    def test_is_available_without_model(self):
        """Test is_available returns False when model is not loaded."""
        from unittest.mock import PropertyMock

        from falkordb_memory_server.embeddings import EmbeddingService

        service = EmbeddingService()
        service._model = None

        # Mock the model property to avoid triggering sentence_transformers import
        with patch.object(EmbeddingService, "model", new_callable=PropertyMock, return_value=None):
            # Without model loaded, is_available should return False
            result = service.is_available()
            assert result is False

    def test_get_dimension(self):
        """Test getting embedding dimension."""
        from falkordb_memory_server.embeddings import EmbeddingService

        service = EmbeddingService()

        # Should return the configured dimension
        dim = service.get_dimension()
        assert dim > 0
        assert dim in [384, 768]  # Common dimensions


class TestEmbeddingResult:
    """Test EmbeddingResult model."""

    def test_embedding_result_creation(self):
        """Test creating an EmbeddingResult."""
        from falkordb_memory_server.embeddings import EmbeddingResult

        result = EmbeddingResult(
            vector=[0.1, 0.2, 0.3],
            dimension=3,
            model="test-model",
            text_preview="test text",
        )

        assert result.vector == [0.1, 0.2, 0.3]
        assert result.dimension == 3
        assert result.model == "test-model"
        assert result.text_preview == "test text"

    def test_embedding_result_text_preview_truncation(self):
        """Test that text preview is truncated for long text."""
        from falkordb_memory_server.embeddings import EmbeddingResult

        long_text = "x" * 200
        result = EmbeddingResult(
            vector=[0.1],
            dimension=1,
            model="test",
            text_preview=long_text[:100] + "...",
        )

        assert len(result.text_preview) == 103  # 100 + "..."
        assert result.text_preview.endswith("...")


class TestGetEmbeddingService:
    """Test global embedding service instance."""

    def test_get_embedding_service_singleton(self):
        """Test that get_embedding_service returns a singleton."""
        from falkordb_memory_server.embeddings import get_embedding_service

        service1 = get_embedding_service()
        service2 = get_embedding_service()

        assert service1 is service2
