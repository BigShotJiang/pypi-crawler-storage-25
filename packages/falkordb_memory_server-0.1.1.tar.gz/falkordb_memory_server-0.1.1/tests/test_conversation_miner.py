import json

import pytest

from falkordb_memory_server.conversation_miner import ConversationMiner


@pytest.fixture
def miner():
    return ConversationMiner()


def test_mine_claude_json(miner, tmp_path):
    data = [
        {
            "name": "Test Conversation",
            "chat_messages": [
                {"sender": "human", "text": "We decided to use Python for this project."},
                {"sender": "assistant", "text": "That's a good choice. I'll remember that."},
            ],
        }
    ]
    file_path = tmp_path / "claude.json"
    file_path.write_text(json.dumps(data))

    result = miner.mine_claude_json(file_path)
    assert result.total_chunks > 0
    assert any(m.category.value == "decision" for m in result.memories)
    decision_memories = [m for m in result.memories if m.category.value == "decision"]
    assert "Python" in decision_memories[0].content


def test_mine_chatgpt_json(miner, tmp_path):
    data = [
        {
            "title": "ChatGPT Test",
            "mapping": {
                "node1": {
                    "message": {
                        "author": {"role": "user"},
                        "content": {
                            "content_type": "text",
                            "parts": ["I always use functional components in React."],
                        },
                    }
                }
            },
        }
    ]
    file_path = tmp_path / "conversations.json"
    file_path.write_text(json.dumps(data))

    result = miner.mine_chatgpt_json(file_path)
    assert result.total_chunks > 0
    assert any(m.category.value == "preference" for m in result.memories)
    preference_memories = [m for m in result.memories if m.category.value == "preference"]
    assert "React" in preference_memories[0].content


def test_mine_slack_json(miner, tmp_path):
    # Create a mock slack export structure
    channel_dir = tmp_path / "general"
    channel_dir.mkdir()
    day_file = channel_dir / "2023-01-01.json"

    data = [
        {"user": "U123", "text": "The bug in the auth module is fixed! It worked!"},
        {"user": "U456", "text": "Great milestone."},
    ]
    day_file.write_text(json.dumps(data))

    result = miner.mine_slack_json(tmp_path)
    assert result.total_chunks > 0
    assert any(m.category.value == "milestone" for m in result.memories)
    assert "auth module" in str(result.memories)


def test_mine_conversations_auto(miner, tmp_path):
    # Test auto-detection
    file_path = tmp_path / "conversations.json"
    data = [
        {
            "title": "T",
            "mapping": {
                "n": {"message": {"content": {"content_type": "text", "parts": ["We decided X"]}}}
            },
        }
    ]
    file_path.write_text(json.dumps(data))

    result = miner.mine_conversations(file_path)
    assert any(m.category.value == "decision" for m in result.memories)


def test_mine_claude_md(miner, tmp_path):
    file_path = tmp_path / "claude.md"
    file_path.write_text("# Conversation\n\nHuman: We decided to use React.\n\nAssistant: OK.")

    result = miner.mine_claude_md(file_path)
    assert any(m.category.value == "decision" for m in result.memories)
    assert "React" in str(result.memories)
