from unittest.mock import MagicMock

import pytest

from falkordb_memory_server.memory_tools import MemoryManager
from falkordb_memory_server.schema import MemoryType
from falkordb_memory_server.tier import TierManager, get_tier_manager


@pytest.fixture
def mock_ops():
    ops = MagicMock()
    return ops


@pytest.fixture
def tier_manager(mock_ops):
    return TierManager(ops=mock_ops)


@pytest.fixture
def memory_manager(mock_ops):
    return MemoryManager(ops=mock_ops)


def test_singleton_get_tier_manager():
    tm1 = get_tier_manager()
    tm2 = get_tier_manager()
    assert tm1 is tm2


def test_remember_with_tier(memory_manager, mock_ops):
    content = {"content": "test learning"}
    mock_ops.create_node.return_value = {"id": 1, "tier": 2}

    # Store with explicit tier L2
    result = memory_manager.remember(memory_type=MemoryType.LEARNING, content=content, tier=2)

    assert result["tier"] == 2
    args, kwargs = mock_ops.create_node.call_args
    assert args[1]["tier"] == 2


def test_remember_default_tier(memory_manager, mock_ops):
    content = {"content": "test learning"}
    mock_ops.create_node.return_value = {"id": 1, "tier": 1}

    # Store without tier (should default to L1)
    result = memory_manager.remember(memory_type=MemoryType.LEARNING, content=content)

    assert result["tier"] == 1
    args, kwargs = mock_ops.create_node.call_args
    assert args[1]["tier"] == 1


def test_set_tier(tier_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [[1]]}

    # Set to L3
    success = tier_manager.set_tier(1, 3)
    assert success is True

    # Check query
    args, kwargs = mock_ops.query.call_args
    assert "SET n.tier = $tier" in args[0]
    assert args[1]["tier"] == 3


def test_promote(tier_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [[2]]}

    # Promote node 1
    success = tier_manager.promote(1)
    assert success is True

    # Check query
    args, kwargs = mock_ops.query.call_args
    assert "SET n.tier = current_tier + 1" in args[0]


def test_demote(tier_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [[1]]}

    # Demote node 1
    success = tier_manager.demote(1)
    assert success is True

    # Check query
    args, kwargs = mock_ops.query.call_args
    assert "SET n.tier = current_tier - 1" in args[0]


def test_get_memories_by_tier(tier_manager, mock_ops):
    mock_ops.query.return_value = {
        "result_set": [[{"id": "mem1", "tier": 2}], [{"id": "mem2", "tier": 2}]]
    }

    memories = tier_manager.get_memories_by_tier(2)
    assert len(memories) == 2
    assert memories[0]["id"] == "mem1"

    args, kwargs = mock_ops.query.call_args
    assert args[1]["tier"] == 2


def test_get_tier_stats(tier_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [[0, 5], [1, 10], [2, 3], [3, 1]]}

    stats = tier_manager.get_tier_stats()
    assert stats[0] == 5
    assert stats[1] == 10
    assert stats[2] == 3
    assert stats[3] == 1


def test_consolidate_session(tier_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [[5]]}

    result = tier_manager.consolidate_session("session-123")
    assert result["promoted_count"] == 5
    assert result["session_id"] == "session-123"

    args, kwargs = mock_ops.query.call_args
    assert "MATCH (s:Session {id: $session_id})<-[:OCCURRED_IN]-(m)" in args[0]
    assert "SET m.tier = 2" in args[0]
