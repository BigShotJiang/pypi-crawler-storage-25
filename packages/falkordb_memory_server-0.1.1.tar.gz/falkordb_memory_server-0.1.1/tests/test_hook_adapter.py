"""Tests for hook adapter system."""

import sys

sys.path.insert(0, "src")

from unittest.mock import MagicMock

from falkordb_memory_server.hook_adapter import (
    HookAdapter,
    HookSource,
    MemoryHookHandler,
    UnifiedEvent,
    UnifiedHookInput,
    UnifiedHookOutput,
)


class TestHookSource:
    """Test HookSource enum."""

    def test_hook_sources_exist(self):
        """Test that all expected hook sources are defined."""
        assert HookSource.CLAUDE
        assert HookSource.GEMINI

    def test_hook_source_values(self):
        """Test hook source string values."""
        assert HookSource.CLAUDE.value == "claude"
        assert HookSource.GEMINI.value == "gemini"


class TestUnifiedEvent:
    """Test UnifiedEvent enum."""

    def test_unified_events_exist(self):
        """Test that all expected unified events are defined."""
        assert UnifiedEvent.SESSION_START
        assert UnifiedEvent.SESSION_END
        assert UnifiedEvent.BEFORE_TOOL
        assert UnifiedEvent.AFTER_TOOL
        assert UnifiedEvent.USER_PROMPT


class TestUnifiedHookInput:
    """Test UnifiedHookInput model."""

    def test_unified_input_creation(self):
        """Test creating a UnifiedHookInput."""
        input_data = UnifiedHookInput(
            hook_event=UnifiedEvent.AFTER_TOOL,
            tool_name="test_tool",
            tool_input={"arg": "value"},
            tool_output={"result": "data"},
            session_id="session-123",
            source_cli=HookSource.CLAUDE,
        )

        assert input_data.hook_event == UnifiedEvent.AFTER_TOOL
        assert input_data.tool_name == "test_tool"
        assert input_data.tool_input == {"arg": "value"}
        assert input_data.tool_output == {"result": "data"}
        assert input_data.session_id == "session-123"
        assert input_data.source_cli == HookSource.CLAUDE

    def test_unified_input_optional_fields(self):
        """Test that optional fields can be omitted."""
        input_data = UnifiedHookInput(
            hook_event=UnifiedEvent.SESSION_START,
        )

        assert input_data.hook_event == UnifiedEvent.SESSION_START
        assert input_data.tool_name is None
        assert input_data.tool_input is None
        assert input_data.tool_output is None


class TestUnifiedHookOutput:
    """Test UnifiedHookOutput model."""

    def test_unified_output_creation(self):
        """Test creating a UnifiedHookOutput."""
        output = UnifiedHookOutput(
            decision="allow",
            reason="Memory captured",
            system_message="Test message",
        )

        assert output.decision == "allow"
        assert output.reason == "Memory captured"
        assert output.system_message == "Test message"

    def test_unified_output_default_decision(self):
        """Test default decision is allow."""
        output = UnifiedHookOutput()

        assert output.decision == "allow"
        assert output.reason is None

    def test_to_claude_output(self):
        """Test converting to Claude output format."""
        output = UnifiedHookOutput(decision="allow", reason="test")
        claude_output = output.to_claude_output()

        assert claude_output["decision"] == "approve"
        assert claude_output["reason"] == "test"

    def test_to_gemini_output(self):
        """Test converting to Gemini output format."""
        output = UnifiedHookOutput(
            decision="allow",
            system_message="test message",
        )
        gemini_output = output.to_gemini_output()

        assert gemini_output["decision"] == "allow"

    def test_to_openclaw_output(self):
        """Test converting to OpenClaw output format."""
        output = UnifiedHookOutput(
            decision="allow",
            system_message="test message",
            additional_context="some context",
            openclaw_specific={"custom": "value"},
        )
        openclaw_output = output.to_openclaw_output()

        assert openclaw_output["decision"] == "allow"
        assert openclaw_output["systemMessage"] == "test message"
        assert openclaw_output["additionalContext"] == "some context"
        assert openclaw_output["custom"] == "value"


class TestHookAdapter:
    """Test HookAdapter class."""

    def test_adapter_creation_claude(self):
        """Test creating adapter for Claude Code."""
        adapter = HookAdapter(source_cli=HookSource.CLAUDE)

        assert adapter.source_cli == HookSource.CLAUDE

    def test_adapter_creation_gemini(self):
        """Test creating adapter for Gemini CLI."""
        adapter = HookAdapter(source_cli=HookSource.GEMINI)

        assert adapter.source_cli == HookSource.GEMINI

    def test_normalize_claude_post_tool_use(self):
        """Test normalizing Claude Code PostToolUse event."""
        adapter = HookAdapter(source_cli=HookSource.CLAUDE)

        raw_input = {
            "hook_event_name": "PostToolUse",
            "tool_name": "memory_query",
            "tool_input": {"query": "MATCH (n) RETURN n"},
            "tool_output": {"result": []},
            "session_id": "sess-1",
        }

        normalized = adapter.normalize_input(raw_input)

        assert normalized.hook_event == UnifiedEvent.AFTER_TOOL
        assert normalized.tool_name == "memory_query"
        assert normalized.source_cli == HookSource.CLAUDE

    def test_normalize_gemini_after_tool(self):
        """Test normalizing Gemini CLI AfterTool event."""
        adapter = HookAdapter(source_cli=HookSource.GEMINI)

        raw_input = {
            "hook_event_name": "AfterTool",
            "tool_name": "memory_recall",
            "tool_input": {"query": "auth"},
            "tool_output": {"result": "data"},
        }

        normalized = adapter.normalize_input(raw_input)

        assert normalized.hook_event == UnifiedEvent.AFTER_TOOL
        assert normalized.tool_name == "memory_recall"

    def test_normalize_openclaw_after_tool(self):
        """Test normalizing OpenClaw tool_result event."""
        adapter = HookAdapter(source_cli=HookSource.OPENCLAW)

        raw_input = {
            "event": "tool_result",
            "tool_name": "memory_extract",
            "tool_args": {"text": "some text"},
            "tool_result": {"memories": []},
            "session_id": "sess-oc-1",
            "working_dir": "/path/to/project",
        }

        normalized = adapter.normalize_input(raw_input)

        assert normalized.hook_event == UnifiedEvent.AFTER_TOOL
        assert normalized.tool_name == "memory_extract"
        assert normalized.tool_input == {"text": "some text"}
        assert normalized.tool_output == {"memories": []}
        assert normalized.session_id == "sess-oc-1"
        assert normalized.cwd == "/path/to/project"
        assert normalized.source_cli == HookSource.OPENCLAW

    def test_normalize_output(self):
        """Test normalizing output for different CLIs."""
        adapter_claude = HookAdapter(source_cli=HookSource.CLAUDE)
        adapter_gemini = HookAdapter(source_cli=HookSource.GEMINI)
        adapter_openclaw = HookAdapter(source_cli=HookSource.OPENCLAW)

        result = UnifiedHookOutput(
            decision="allow",
            reason="Memory captured",
        )

        output_claude = adapter_claude.normalize_output(result)
        assert output_claude["decision"] == "approve"

        output_gemini = adapter_gemini.normalize_output(result)
        assert output_gemini["decision"] == "allow"

        output_openclaw = adapter_openclaw.normalize_output(result)
        assert output_openclaw["decision"] == "allow"


class TestMemoryHookHandler:
    """Test MemoryHookHandler class."""

    def test_handler_creation(self):
        """Test creating a MemoryHookHandler."""
        handler = MemoryHookHandler()

        assert handler._extractor is None
        assert handler._graph_ops is None
        assert handler._db_available is True

    def test_handler_with_custom_url(self):
        """Test creating handler with custom FalkorDB URL."""
        handler = MemoryHookHandler(falkordb_url="redis://custom:6379")

        assert handler._falkordb_url == "redis://custom:6379"

    def test_handle_session_start(self):
        """Test handling session_start event with mocked DB."""
        handler = MemoryHookHandler()
        # Mock graph_ops to prevent actual DB connection
        handler._graph_ops = MagicMock()
        handler._db_available = True

        input_data = UnifiedHookInput(
            hook_event=UnifiedEvent.SESSION_START,
            session_id="sess-123",
            source_cli=HookSource.CLAUDE,
        )

        result = handler.handle(input_data)

        assert result.decision == "allow"

    def test_handle_after_tool(self):
        """Test handling after_tool event with mocked components."""
        handler = MemoryHookHandler()
        # Mock both graph_ops and extractor to prevent real operations
        handler._graph_ops = MagicMock()
        handler._db_available = True

        # Mock extractor with a return value
        mock_extractor = MagicMock()
        mock_memory = MagicMock()
        mock_memory.confidence = 0.5
        mock_extractor.extract_from_tool_use.return_value = mock_memory
        handler._extractor = mock_extractor

        input_data = UnifiedHookInput(
            hook_event=UnifiedEvent.AFTER_TOOL,
            tool_name="memory_query",
            tool_input={"query": "MATCH (n) RETURN n"},
            tool_output={"result": {"data": "test"}},
            session_id="sess-1",
            source_cli=HookSource.CLAUDE,
        )

        result = handler.handle(input_data)

        # Should allow the operation
        assert result.decision == "allow"

    def test_handle_after_tool_no_memory(self):
        """Test handling after_tool when no memory is extracted."""
        handler = MemoryHookHandler()
        handler._graph_ops = MagicMock()
        handler._db_available = True

        # Mock extractor returning None (no memory extracted)
        mock_extractor = MagicMock()
        mock_extractor.extract_from_tool_use.return_value = None
        handler._extractor = mock_extractor

        input_data = UnifiedHookInput(
            hook_event=UnifiedEvent.AFTER_TOOL,
            tool_name="test_tool",
            tool_input={},
            tool_output={},
        )

        result = handler.handle(input_data)
        assert result.decision == "allow"

    def test_handle_graceful_degradation(self):
        """Test that handler gracefully handles database unavailability."""
        handler = MemoryHookHandler()
        handler._db_available = False  # Simulate unavailable database

        input_data = UnifiedHookInput(
            hook_event=UnifiedEvent.AFTER_TOOL,
            tool_name="test_tool",
            tool_input={},
            tool_output={},
        )

        # Should not raise exception
        result = handler.handle(input_data)
        assert result.decision == "allow"

    def test_safe_graph_op_with_unavailable_db(self):
        """Test _safe_graph_op returns default when DB unavailable."""
        handler = MemoryHookHandler()
        handler._db_available = False

        result = handler._safe_graph_op(
            lambda: "should not be called",
            default="default value",
        )

        assert result == "default value"

    def test_safe_graph_op_with_available_db(self):
        """Test _safe_graph_op executes operation when DB available."""
        handler = MemoryHookHandler()
        handler._db_available = True

        result = handler._safe_graph_op(
            lambda: "operation result",
            default="default value",
        )

        assert result == "operation result"

    def test_handle_user_prompt(self):
        """Test handling user_prompt event."""
        handler = MemoryHookHandler()
        handler._graph_ops = MagicMock()
        handler._db_available = True

        # Mock extractor
        mock_extractor = MagicMock()
        mock_result = MagicMock()
        mock_result.memories = []
        mock_extractor.extract.return_value = mock_result
        handler._extractor = mock_extractor

        input_data = UnifiedHookInput(
            hook_event=UnifiedEvent.USER_PROMPT,
            prompt="Test prompt",
        )

        result = handler.handle(input_data)
        assert result.decision == "allow"

    def test_handle_unknown_event(self):
        """Test handling unknown event returns allow."""
        handler = MemoryHookHandler()

        input_data = UnifiedHookInput(
            hook_event=UnifiedEvent.NOTIFICATION,
        )

        result = handler.handle(input_data)
        assert result.decision == "allow"


class TestEventMapping:
    """Test event name mapping between CLIs."""

    def test_claude_event_mapping_pre_tool(self):
        """Test Claude Code PreToolUse event mapping."""
        from falkordb_memory_server.hook_adapter import CLAUDE_TO_UNIFIED

        assert CLAUDE_TO_UNIFIED["PreToolUse"] == UnifiedEvent.BEFORE_TOOL

    def test_claude_event_mapping_post_tool(self):
        """Test Claude Code PostToolUse event mapping."""
        from falkordb_memory_server.hook_adapter import CLAUDE_TO_UNIFIED

        assert CLAUDE_TO_UNIFIED["PostToolUse"] == UnifiedEvent.AFTER_TOOL

    def test_gemini_event_mapping_session_start(self):
        """Test Gemini CLI SessionStart event mapping."""
        from falkordb_memory_server.hook_adapter import GEMINI_TO_UNIFIED

        assert GEMINI_TO_UNIFIED["SessionStart"] == UnifiedEvent.SESSION_START

    def test_gemini_event_mapping_after_tool(self):
        """Test Gemini CLI AfterTool event mapping."""
        from falkordb_memory_server.hook_adapter import GEMINI_TO_UNIFIED

        assert GEMINI_TO_UNIFIED["AfterTool"] == UnifiedEvent.AFTER_TOOL


class TestMemoryExtraction:
    """Test memory extraction in hooks."""

    def test_extract_from_tool_input_with_mock(self):
        """Test that tool inputs are processed with mocked extractor."""
        handler = MemoryHookHandler()
        handler._graph_ops = MagicMock()
        handler._db_available = True

        # Mock extractor
        mock_extractor = MagicMock()
        mock_memory = MagicMock()
        mock_memory.confidence = 0.6
        mock_extractor.extract_from_tool_use.return_value = mock_memory
        handler._extractor = mock_extractor

        input_data = UnifiedHookInput(
            hook_event=UnifiedEvent.AFTER_TOOL,
            tool_name="chat",
            tool_input={"query": "We decided to use PostgreSQL for the database"},
            tool_output={},
        )

        result = handler.handle(input_data)
        assert result.decision == "allow"
        # Verify extractor was called
        mock_extractor.extract_from_tool_use.assert_called_once()
