"""Tests for Convention Registry."""

import json
import os
import sys
from unittest.mock import Mock, patch

# Add src to path for direct imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from falkordb_memory_server.memory_tools import MemoryManager
from falkordb_memory_server.server import handle_get_conventions


class TestConventions:
    """Test convention registry functionality."""

    def test_get_conventions_all(self):
        """Test retrieving all conventions."""
        mock_ops = Mock()
        # Mock query result
        mock_ops.query.return_value = {
            "result_set": [
                [
                    {
                        "id": "conv1",
                        "type": "naming",
                        "name": "Snake Case",
                        "description": "Use snake_case for variables",
                    }
                ]
            ]
        }

        manager = MemoryManager(ops=mock_ops)
        result = manager.get_conventions()

        assert "result_set" in result
        assert len(result["result_set"]) == 1
        assert result["result_set"][0][0]["id"] == "conv1"

        # Verify Cypher
        args, kwargs = mock_ops.query.call_args
        assert "MATCH (c:Convention)" in args[0]
        assert "WHERE c.valid_to IS NULL" in args[0]

    def test_get_conventions_filtered(self):
        """Test retrieving filtered conventions."""
        mock_ops = Mock()
        mock_ops.query.return_value = {"result_set": []}

        manager = MemoryManager(ops=mock_ops)

        # Filter by type
        manager.get_conventions(convention_type="style")
        args, kwargs = mock_ops.query.call_args
        assert "c.type = $type" in args[0]
        assert kwargs["params"]["type"] == "style"

        # Filter by project_path
        manager.get_conventions(project_path="/path/to/project")
        args, kwargs = mock_ops.query.call_args
        assert "c.context CONTAINS $project_path" in args[0]
        assert kwargs["params"]["project_path"] == "/path/to/project"

    def test_handle_get_conventions(self):
        """Test the memory_get_conventions tool handler."""
        mock_ops = Mock()

        with patch("falkordb_memory_server.memory_tools.MemoryManager") as mock_manager_class:
            mock_manager = Mock()
            mock_manager.get_conventions.return_value = {"status": "success", "conventions": []}
            mock_manager_class.return_value = mock_manager

            args = {"convention_type": "naming", "project_path": "/test"}
            content_list = handle_get_conventions(mock_ops, args)

            assert len(content_list) == 1
            result_data = json.loads(content_list[0].text)
            assert result_data["status"] == "success"

            # Verify manager was called with correct args
            mock_manager.get_conventions.assert_called_once_with("naming", "/test")
