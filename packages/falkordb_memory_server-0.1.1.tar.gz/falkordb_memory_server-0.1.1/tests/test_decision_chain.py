"""Tests for decision chain queries."""

import sys
from unittest.mock import MagicMock, patch

sys.path.insert(0, "src")

from falkordb_memory_server.memory_tools import MemoryManager


class TestDecisionChain:
    """Test Decision Chain Query logic."""

    def test_get_decision_chain_with_start_id(self):
        """Test getting chain with a starting node ID."""
        mock_ops = MagicMock()
        manager = MemoryManager(ops=mock_ops)

        start_id = 123
        max_depth = 3

        manager.get_decision_chain(start_node_id=start_id, max_depth=max_depth)

        # Verify correct Cypher query and params
        call_args = mock_ops.query.call_args
        cypher = call_args[0][0]
        params = call_args[1].get("params")

        assert "MATCH path = (d:Decision)-[:LED_TO*1..3]->(c)" in cypher
        assert "WHERE id(d) = $start_id" in cypher
        assert params["start_id"] == 123
        assert call_args[1].get("read_only") is True

    def test_get_decision_chain_without_start_id(self):
        """Test getting chain without a starting node ID."""
        mock_ops = MagicMock()
        manager = MemoryManager(ops=mock_ops)

        manager.get_decision_chain(max_depth=5)

        # Verify correct Cypher query
        call_args = mock_ops.query.call_args
        cypher = call_args[0][0]

        assert "MATCH path = (d:Decision)-[:LED_TO*1..5]->(c)" in cypher
        assert "WHERE id(d)" not in cypher
        assert "LIMIT 50" in cypher
        assert call_args[1].get("read_only") is True


@patch("falkordb_memory_server.memory_tools.MemoryManager")
def test_handle_get_decision_chain(mock_manager_class):
    """Test handle_get_decision_chain tool handler."""
    from falkordb_memory_server.server import handle_get_decision_chain

    mock_ops = MagicMock()

    mock_manager = MagicMock()
    mock_manager_class.return_value = mock_manager
    mock_manager.get_decision_chain.return_value = {"result_set": []}

    args = {"start_node_id": 456, "max_depth": 2}
    result = handle_get_decision_chain(mock_ops, args)

    assert len(result) == 1
    assert "result_set" in result[0].text
    mock_manager.get_decision_chain.assert_called_with(456, 2)
