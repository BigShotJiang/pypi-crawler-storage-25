from unittest.mock import MagicMock

import pytest

from falkordb_memory_server.sharing import SharingManager, SharingPermission, get_sharing_manager


@pytest.fixture
def mock_ops():
    ops = MagicMock()
    return ops


@pytest.fixture
def sharing_manager(mock_ops):
    return SharingManager(ops=mock_ops)


def test_singleton_get_sharing_manager():
    sm1 = get_sharing_manager()
    sm2 = get_sharing_manager()
    assert sm1 is sm2


def test_register_agent_existing(sharing_manager, mock_ops):
    mock_ops.query.side_effect = [
        {"result_set": [[{"id": "agent1"}]]},  # check exists
        {"result_set": [[{"id": "agent1", "name": "new_name"}]]},  # update
    ]

    res = sharing_manager.register_agent(
        "agent1", "claude", name="new_name", namespace="ns1", capabilities=["read"]
    )
    assert res["result_set"] == [[{"id": "agent1", "name": "new_name"}]]


def test_register_agent_new(sharing_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": []}
    mock_ops.create_node.return_value = {"node_id": 5}

    res = sharing_manager.register_agent("agent2", "codex", capabilities=["write"])
    assert res["node_id"] == 5


def test_share_memory(sharing_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": []}  # register_agent new
    mock_ops.create_node.return_value = {"node_id": 6}  # register_agent create
    mock_ops.create_edge.return_value = {"edge_id": 10}

    perm = SharingPermission(read=True, write=True)
    res = sharing_manager.share_memory(1, ["agent3", "agent4"], perm)

    assert res["memory_id"] == 1
    assert res["total_shared"] == 2
    assert all(x["success"] for x in res["shared_with"])


def test_query_agent_memories(sharing_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [["mem1"]]}

    res = sharing_manager.query_agent_memories(
        agent_type="claude", agent_id="a1", memory_types=["Learning"]
    )
    assert res["result_set"] == [["mem1"]]

    res2 = sharing_manager.query_agent_memories()
    assert res2["result_set"] == [["mem1"]]


def test_get_agent_knowledge(sharing_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [["knowledge"]]}

    res = sharing_manager.get_agent_knowledge("a1", include_shared=True)
    assert res["result_set"] == [["knowledge"]]

    res2 = sharing_manager.get_agent_knowledge("a1", include_shared=False)
    assert res2["result_set"] == [["knowledge"]]


def test_check_permission(sharing_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [[True]]}
    assert sharing_manager.check_permission(1, "a1", "read") is True

    mock_ops.query.return_value = {"result_set": [[False]]}
    assert sharing_manager.check_permission(1, "a1", "write") is False

    mock_ops.query.return_value = {"result_set": []}
    assert sharing_manager.check_permission(1, "a1", "delete") is False

    with pytest.raises(ValueError):
        sharing_manager.check_permission(1, "a1", "invalid_perm")


def test_revoke_sharing(sharing_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [[2]]}

    res = sharing_manager.revoke_sharing(1, ["a1", "a2"])
    assert res["memory_id"] == 1
    assert res["revoked_count"] == 2

    res2 = sharing_manager.revoke_sharing(1)
    assert res2["revoked_count"] == 2


def test_get_namespace_memories(sharing_manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [["mem1"], ["mem2"]]}
    res = sharing_manager.get_namespace_memories("ns1")
    assert res["result_set"] == [["mem1"], ["mem2"]]
