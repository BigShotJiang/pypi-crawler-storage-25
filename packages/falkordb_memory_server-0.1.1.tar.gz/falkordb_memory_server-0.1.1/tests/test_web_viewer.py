"""Tests for the web viewer UI."""

from fastapi.testclient import TestClient

from falkordb_memory_server.web_viewer import app

client = TestClient(app)


def test_get_viewer():
    """Test the root HTML viewer endpoint."""
    response = client.get("/")
    assert response.status_code == 200
    assert "FalkorDB Memory Graph Viewer" in response.text
    assert "d3.v7.min.js" in response.text


def test_get_graph_data():
    """Test the graph data API endpoint."""
    response = client.get("/api/graph")
    assert response.status_code == 200
    data = response.json()
    assert "nodes" in data
    assert "links" in data
    assert isinstance(data["nodes"], list)
    assert isinstance(data["links"], list)
