"""Tests for privacy control (<private> tag exclusion)."""

import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from falkordb_memory_server.extractor import MemoryExtractor


class TestPrivacyControl:
    """Test <private> tag exclusion in memory extraction."""

    def test_private_tag_exclusion_single_line(self):
        """Test that single-line <private> tags are excluded."""
        extractor = MemoryExtractor(min_confidence=0.1)
        text = "We decided to use PostgreSQL. <private>I am using a secret password '123456'.</private> It handles JSON well."

        result = extractor.extract(text)

        # Should extract the decision but not the private info
        # Check that none of the extracted memories contain the secret
        for memory in result.memories:
            assert "123456" not in memory.content
            assert "<private>" not in memory.content
            assert "</private>" not in memory.content

    def test_private_tag_exclusion_multi_line(self):
        """Test that multi-line <private> tags are excluded."""
        extractor = MemoryExtractor(min_confidence=0.1)
        text = """
We decided to use PostgreSQL.
<private>
The database credentials are:
host: localhost
user: admin
pass: secret_pass
</private>
The reason is performance.
"""

        result = extractor.extract(text)

        # Should not extract the credentials
        for memory in result.memories:
            assert "secret_pass" not in memory.content
            assert "admin" not in memory.content
            assert "<private>" not in memory.content

    def test_private_tag_no_extraction(self):
        """Test that if a whole memory is inside <private>, it's not extracted."""
        extractor = MemoryExtractor(min_confidence=0.1)
        text = "<private>We decided to use a secret algorithm.</private>"

        result = extractor.extract(text)

        # Should extract nothing
        assert len(result.memories) == 0

    def test_multiple_private_tags(self):
        """Test that multiple <private> tags are excluded."""
        extractor = MemoryExtractor(min_confidence=0.1)
        text = "Start. <private>secret 1</private> Middle. <private>secret 2</private> End."
        # Add some markers to trigger extraction
        text = "We decided to start. <private>I decided to use 'pwd1'.</private> We also decided to finish. <private>I chose 'pwd2'.</private>"

        result = extractor.extract(text)

        # Should extract the start and finish decisions, but not the secrets
        for memory in result.memories:
            assert "pwd1" not in memory.content
            assert "pwd2" not in memory.content
            assert "decided" in memory.content or "chose" in memory.content

    def test_private_tag_case_insensitive(self):
        """Test that <PRIVATE> tags are also excluded."""
        extractor = MemoryExtractor(min_confidence=0.1)
        text = "We decided to use PostgreSQL. <PRIVATE>Secret</PRIVATE>"

        result = extractor.extract(text)

        for memory in result.memories:
            assert "Secret" not in memory.content

    def test_extract_from_tool_use_with_private(self):
        """Test that tool usage with private tags is filtered."""
        extractor = MemoryExtractor()

        # Tool input with private tag
        memory = extractor.extract_from_tool_use(
            tool_name="write_file",
            tool_input={
                "path": "config.json",
                "content": '{"key": "secret", "private": "<private>HIDDEN</private>"}',
            },
            tool_output="Success",
        )

        assert memory is not None
        assert "HIDDEN" not in memory.content
        assert "<private>" not in memory.content

    def test_private_tag_nesting(self):
        """Test that nested <private> tags are excluded."""
        extractor = MemoryExtractor(min_confidence=0.1)
        text = (
            "Outer before <private> inner <private> secret </private> outer after </private> final."
        )

        # Add some markers to trigger extraction
        text = "We decided: Outer before <private> inner <private> secret </private> outer after </private> final."

        result = extractor.extract(text)

        # Should only contain "We decided: Outer before final."
        for memory in result.memories:
            assert "inner" not in memory.content
            assert "secret" not in memory.content
            assert "outer after" not in memory.content
            assert "Outer before" in memory.content
            assert "final" in memory.content

    def test_private_tag_unclosed(self):
        """Test that unclosed <private> tags are excluded."""
        extractor = MemoryExtractor(min_confidence=0.1)
        text = "Public. <private> Secret content without closing tag"

        # Add some markers to trigger extraction
        text = "We decided: Public. <private> Secret content without closing tag"

        result = extractor.extract(text)

        # Should only contain "We decided: Public."
        for memory in result.memories:
            assert "Secret content" not in memory.content
            assert "Public" in memory.content
