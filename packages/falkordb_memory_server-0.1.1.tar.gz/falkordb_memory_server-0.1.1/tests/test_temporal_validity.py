from unittest.mock import MagicMock, patch

import pytest

from falkordb_memory_server.memory_tools import MemoryManager
from falkordb_memory_server.schema import MemoryType
from falkordb_memory_server.semantic_tools import SemanticSearchEngine


@pytest.fixture
def mock_ops():
    return MagicMock()


@pytest.fixture
def manager(mock_ops):
    return MemoryManager(ops=mock_ops)


def test_remember_sets_temporal_properties(manager, mock_ops):
    mock_ops.create_node.return_value = {"id": 1, "properties": {}}

    content = {"title": "Test Decision", "status": "accepted"}
    manager.remember(MemoryType.DECISION, content)

    # Check if create_node was called with temporal properties
    args, kwargs = mock_ops.create_node.call_args
    properties = args[1]

    assert "valid_from" in properties
    assert "valid_to" in properties
    assert properties["valid_to"] is None
    assert properties["valid_from"] == properties["created_at"]


def test_invalidate_memory(manager, mock_ops):
    mock_ops.query.return_value = {"result_set": [[1]]}

    # Test with string ID
    success = manager.invalidate_memory("mem-123")
    assert success is True

    # Check query calls
    found_invalidate_query = False
    for call in mock_ops.query.call_args_list:
        query_str = call[0][0]
        # Access positional argument instead of keyword argument
        params = call[0][1] if len(call[0]) > 1 else {}
        if "n.id = $id SET n.valid_to = $at" in query_str and params.get("id") == "mem-123":
            found_invalidate_query = True
            assert "at" in params
            break
    assert found_invalidate_query

    # Test with integer ID
    success = manager.invalidate_memory(456)
    assert success is True

    found_invalidate_query_int = False
    for call in mock_ops.query.call_args_list:
        query_str = call[0][0]
        params = call[0][1] if len(call[0]) > 1 else {}
        if "id(n) = $id SET n.valid_to = $at" in query_str and params.get("id") == 456:
            found_invalidate_query_int = True
            assert "at" in params
            break
    assert found_invalidate_query_int


def test_auto_invalidate_convention(manager, mock_ops):
    # Setup for a new convention
    content = {"name": "indentation", "type": "style", "value": "4 spaces"}

    # Need to mock create_node to avoid error
    mock_ops.create_node.return_value = {"id": 1, "properties": {}}

    manager.remember(MemoryType.CONVENTION, content)

    # Check if _auto_invalidate was called and executed the query
    any_auto_invalidate_call = False
    for call in mock_ops.query.call_args_list:
        query_str = call[0][0]
        params = call[0][1] if len(call[0]) > 1 else {}
        if "MATCH (c:Convention)" in query_str and "SET c.valid_to = $now" in query_str:
            any_auto_invalidate_call = True
            assert params["name"] == "indentation"
            assert params["type"] == "style"
            break

    assert any_auto_invalidate_call is True


def test_recall_delegation(manager, mock_ops):
    # manager.recall should delegate to semantic engine
    # In temporal_validity.py, we patch where the code being tested will look for it
    with patch("falkordb_memory_server.memory_tools.get_semantic_engine") as mock_get_engine:
        mock_engine = MagicMock()
        mock_get_engine.return_value = mock_engine

        manager.recall(query_type="semantic", query="test", include_invalid=True)
        mock_engine.recall.assert_called_with(
            query="test", query_type="semantic", filters={}, limit=10, include_invalid=True
        )

        manager.recall(query_type="semantic", query="test", include_invalid=False)
        mock_engine.recall.assert_called_with(
            query="test", query_type="semantic", filters={}, limit=10, include_invalid=False
        )


def test_semantic_search_filtering(mock_ops):
    mock_embedding = MagicMock()
    mock_embedding.is_available.return_value = True

    engine = SemanticSearchEngine(ops=mock_ops, embedding_service=mock_embedding)

    # Mock semantic_search results
    # One valid, one invalid (properties are usually in 'properties' key of 'node')
    mock_ops.semantic_search.return_value = [
        {"node": {"properties": {"content": "valid", "valid_to": None}}, "score": 0.9},
        {"node": {"properties": {"content": "invalid", "valid_to": "2023-01-01"}}, "score": 0.8},
    ]

    # Search with include_invalid=False
    results = engine.search(query="test", include_invalid=False)
    assert len(results) == 1
    assert results[0]["node"]["properties"]["content"] == "valid"

    # Search with include_invalid=True
    results = engine.search(query="test", include_invalid=True)
    assert len(results) == 2


def test_text_recall_temporal_clause(mock_ops):
    mock_embedding = MagicMock()
    engine = SemanticSearchEngine(ops=mock_ops, embedding_service=mock_embedding)

    # Mock query result
    mock_ops.query.return_value = {"result_set": [], "statistics": {}}

    # Test include_invalid=False
    engine.recall(query="test", query_type="text", include_invalid=False)
    args, kwargs = mock_ops.query.call_args
    assert "WHERE node.valid_to IS NULL" in args[0]

    # Test include_invalid=True
    engine.recall(query="test", query_type="text", include_invalid=True)
    args, kwargs = mock_ops.query.call_args
    assert "WHERE node.valid_to IS NULL" not in args[0]
