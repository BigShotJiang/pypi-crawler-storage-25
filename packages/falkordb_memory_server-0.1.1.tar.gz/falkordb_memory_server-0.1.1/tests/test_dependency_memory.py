"""Tests for dependency decision memory."""

import os
import sys

# Add src to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from falkordb_memory_server.extractor import (
    MemoryCategory,
    MemoryExtractor,
)
from falkordb_memory_server.memory_tools import MemoryManager
from falkordb_memory_server.schema import (
    MemoryType,
    NodeLabel,
)


class MockGraphOps:
    """Mock GraphOperations for testing MemoryManager."""

    def __init__(self):
        self.created_nodes = []

    def create_node(self, label, properties, return_node=True):
        node = {"id": properties.get("id"), "labels": [label], "properties": properties}
        self.created_nodes.append(node)
        return node

    def query(self, cypher, params=None, read_only=False):
        """Mock query for auto-invalidation."""
        return {"result_set": []}


class TestDependencyMemory:
    """Test dependency memory extraction and storage."""

    def test_extract_dependency(self):
        """Test extraction of dependency memories."""
        extractor = MemoryExtractor(min_confidence=0.2)
        texts = [
            "We decided to add the requests library because it's easier to use than urllib.",
            "Let's install falkordb for the graph database.",
            "We chose to use pytest instead of unittest for our testing framework.",
            "Migrated from redis-py to falkordb-py for better graph support.",
            "引入 requests 库来处理 HTTP 请求。",
            "选择 falkordb 库是因为它提供了原生的向量搜索支持。",
        ]

        for text in texts:
            result = extractor.extract(text)
            if not result.memories or result.memories[0].category != MemoryCategory.DEPENDENCY:
                actual = result.memories[0].category if result.memories else "None"
                print(f"Failed for: {text}")
                print(f"Actual category: {actual}")
                if result.memories:
                    print(f"Keywords: {result.memories[0].keywords}")
            assert len(result.memories) >= 1, f"Failed to extract from: {text}"
            assert result.memories[0].category == MemoryCategory.DEPENDENCY, (
                f"Wrong category for: {text}"
            )

    def test_remember_dependency(self):
        """Test storing dependency memory via MemoryManager."""
        mock_ops = MockGraphOps()
        manager = MemoryManager(ops=mock_ops)

        content = {
            "name": "falkordb",
            "version": "1.0.0",
            "rationale": "Better performance for graph queries.",
            "alternatives": ["Neo4j", "RedisGraph"],
        }

        result = manager.remember(
            memory_type=MemoryType.DEPENDENCY, content=content, generate_embedding=False
        )

        assert result["memory_type"] == "dependency"
        assert len(mock_ops.created_nodes) == 1
        node = mock_ops.created_nodes[0]
        assert NodeLabel.DEPENDENCY in node["labels"]
        assert node["properties"]["name"] == "falkordb"
        assert node["properties"]["rationale"] == "Better performance for graph queries."
        assert node["properties"]["alternatives"] == ["Neo4j", "RedisGraph"]

    def test_remember_dependency_enrichment(self):
        """Test enrichment of dependency memory."""
        mock_ops = MockGraphOps()
        manager = MemoryManager(ops=mock_ops)

        # Minimal content, should be enriched from "content" field
        content = {"content": "Use requests instead of urllib because of easier API."}

        manager.remember(
            memory_type=MemoryType.DEPENDENCY, content=content, generate_embedding=False
        )

        node = mock_ops.created_nodes[0]
        assert node["properties"]["name"] == "Use"  # Simple heuristic: first word
        assert node["properties"]["rationale"] == content["content"]
        assert node["properties"]["alternatives"] == []


if __name__ == "__main__":
    # Run tests if executed directly
    test = TestDependencyMemory()
    test.test_extract_dependency()
    test.test_remember_dependency()
    test.test_remember_dependency_enrichment()
    print("All tests passed!")
