"""Tests for code pattern memory (IMPLEMENTS edges)."""

import sys
from unittest.mock import MagicMock, patch

sys.path.insert(0, "src")

from falkordb_memory_server.memory_tools import MemoryManager
from falkordb_memory_server.schema import MemoryType, NodeLabel


class TestCodePatterns:
    """Test Code Pattern logic."""

    def test_remember_code(self):
        """Test storing a code memory."""
        mock_ops = MagicMock()
        manager = MemoryManager(ops=mock_ops)

        content = {
            "file": "server.py",
            "language": "python",
            "snippet": "def handle_get_code_patterns...",
        }
        manager.remember(MemoryType.CODE, content)

        # Verify node creation with correct label
        call_args = mock_ops.create_node.call_args
        label = call_args[0][0]
        properties = call_args[0][1]

        assert label == NodeLabel.CODE
        assert properties["file"] == "server.py"
        assert properties["language"] == "python"

    def test_remember_pattern(self):
        """Test storing a pattern memory."""
        mock_ops = MagicMock()
        manager = MemoryManager(ops=mock_ops)

        content = {"name": "MCP Tool Handler", "type": "architectural"}
        manager.remember(MemoryType.PATTERN, content)

        # Verify node creation with correct label
        call_args = mock_ops.create_node.call_args
        label = call_args[0][0]
        properties = call_args[0][1]

        assert label == NodeLabel.PATTERN
        assert properties["name"] == "MCP Tool Handler"
        assert properties["type"] == "architectural"

    def test_get_code_patterns(self):
        """Test retrieving code patterns."""
        mock_ops = MagicMock()
        manager = MemoryManager(ops=mock_ops)

        manager.get_code_patterns(pattern_type="architectural")

        # Verify correct Cypher query and params
        call_args = mock_ops.query.call_args
        cypher = call_args[0][0]
        params = call_args[1].get("params")

        assert "MATCH (c:Code)-[r:IMPLEMENTS]->(p:Pattern)" in cypher
        assert "WHERE p.type = $pattern_type" in cypher
        assert params["pattern_type"] == "architectural"
        assert "LIMIT 50" in cypher
        assert call_args[1].get("read_only") is True


@patch("falkordb_memory_server.memory_tools.MemoryManager")
def test_handle_get_code_patterns(mock_manager_class):
    """Test handle_get_code_patterns tool handler."""
    from falkordb_memory_server.server import handle_get_code_patterns

    mock_ops = MagicMock()

    mock_manager = MagicMock()
    mock_manager_class.return_value = mock_manager
    mock_manager.get_code_patterns.return_value = {"result_set": []}

    args = {"code_id": 123, "pattern_type": "architectural"}
    result = handle_get_code_patterns(mock_ops, args)

    assert len(result) == 1
    assert "result_set" in result[0].text
    mock_manager.get_code_patterns.assert_called_with(123, "architectural")
