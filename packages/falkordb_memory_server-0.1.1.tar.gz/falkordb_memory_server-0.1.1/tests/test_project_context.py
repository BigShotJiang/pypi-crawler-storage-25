"""Tests for project context auto-load."""

import os
import sys
import tempfile
from pathlib import Path

# Add src to path for direct imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from falkordb_memory_server.extractor import (
    MemoryCategory,
    MemoryExtractor,
    mine_project_context,
)
from falkordb_memory_server.server import handle_load_project_context


class TestProjectContext:
    """Test project context auto-load functionality."""

    def test_extract_context_markers(self):
        """Test extraction of context memories using markers."""
        extractor = MemoryExtractor(min_confidence=0.2)

        # Test English markers
        text_en = (
            "This project uses the provided pyproject.toml and CLAUDE.md for global configuration."
        )
        result_en = extractor.extract(text_en)
        assert len(result_en.memories) >= 1
        assert result_en.memories[0].category == MemoryCategory.CONTEXT

        # Test Chinese markers
        text_zh = "项目依赖于项目配置文件进行全局设置。"
        result_zh = extractor.extract(text_zh)
        assert len(result_zh.memories) >= 1
        assert result_zh.memories[0].category == MemoryCategory.CONTEXT

    def test_mine_project_context(self):
        """Test scanning PROJECT_CONTEXT_FILES in a directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)

            # Create a mock CLAUDE.md with context
            claude_md = tmp_path / "CLAUDE.md"
            claude_md.write_text(
                "# Project Conventions\n\n- Use 4 spaces for indentation.\n- Follow PEP 8 style guide."
            )

            # Create a mock README.md
            readme_md = tmp_path / "README.md"
            readme_md.write_text("# My Project\n\nThis is a test project configuration.")

            # Mine context
            result = mine_project_context(tmp_path)

            # Should have found memories from CLAUDE.md (at least the conventions)
            assert len(result.memories) >= 1
            # Check if any memory is categorized as CONTEXT
            context_memories = [m for m in result.memories if m.category == MemoryCategory.CONTEXT]
            assert len(context_memories) >= 1

    def test_handle_load_project_context(self, mocker=None):
        """Test the memory_load_project_context tool handler."""

        # Mock GraphOperations
        class MockOps:
            def __init__(self):
                self.nodes_created = []
                self.query_results = []

            def create_node(self, label, props, return_node=False):
                self.nodes_created.append((label, props))
                if return_node:
                    return {"id": "test_id", "properties": props}
                return {"node_id": "test_id"}

            def create_nodes_batch(self, label, props_list):
                self.nodes_created.append((label, props_list))
                return [f"node_{i}" for i in range(len(props_list))]

            def query(self, cypher, params=None, read_only=False):
                # Return empty for file states check
                return {"result_set": []}

            def safe_query(self, cypher, params=None, read_only=False):
                return self.query(cypher, params, read_only)

        ops = MockOps()

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)

            # Create a mock file
            gemini_md = tmp_path / "GEMINI.md"
            gemini_md.write_text("## Rules\n\n- Always use Chinese for communication.")

            # Call handler
            args = {"project_path": str(tmp_path), "incremental": False}
            content_list = handle_load_project_context(ops, args)

            # Verify results
            assert len(content_list) == 1
            import json

            result_data = json.loads(content_list[0].text)

            assert "memories" in result_data
            assert result_data["stored_count"] > 0
            assert result_data["files_checked"] > 0

            # Verify nodes were created in "MockOps"
            assert len(ops.nodes_created) > 0
