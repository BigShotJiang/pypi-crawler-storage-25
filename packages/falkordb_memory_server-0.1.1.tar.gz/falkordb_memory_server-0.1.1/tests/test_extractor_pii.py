from falkordb_memory_server.extractor import ExtractionMode, MemoryExtractor, PIIRedactor


def test_pii_redactor_aws_key():
    text = "Here is my key: AKIAIOSFODNN7EXAMPLE and another one AKIAIOSFODNN7EXAMPLX."
    redacted = PIIRedactor.redact(text)
    assert "AKIA" not in redacted
    assert "[REDACTED_AWS_KEY]" in redacted


def test_pii_redactor_jwt():
    jwt_token = "eyJhbGciOiJIUzI1NiIsInR5cCI.eyJzdWIiOiIxMjM0NTY3ODkw.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
    text = f"My token is {jwt_token}"
    redacted = PIIRedactor.redact(text)
    assert jwt_token not in redacted
    assert "[REDACTED_JWT]" in redacted


def test_pii_redactor_email():
    text = "Contact me at user@example.com or admin.test@company.co.uk."
    redacted = PIIRedactor.redact(text)
    assert "user@example.com" not in redacted
    assert "admin.test@company.co.uk" not in redacted
    assert "[REDACTED_EMAIL]" in redacted


def test_pii_redactor_public_ip():
    text = "Server IP is 8.8.8.8 and local is 127.0.0.1, internal 192.168.1.5, 10.0.0.1"
    redacted = PIIRedactor.redact(text)
    assert "8.8.8.8" not in redacted
    assert "[REDACTED_PUBLIC_IP]" in redacted
    assert "127.0.0.1" in redacted  # Local IP should NOT be redacted
    assert "192.168.1.5" in redacted  # Local IP should NOT be redacted
    assert "10.0.0.1" in redacted  # Local IP should NOT be redacted


def test_pii_redactor_secret_field():
    text = "conn = DB(password='supersecret123', API_KEY=\"xyz789\")"
    redacted = PIIRedactor.redact(text)
    assert "supersecret123" not in redacted
    assert "xyz789" not in redacted
    assert "password='[REDACTED_SECRET]'" in redacted
    assert "API_KEY='[REDACTED_SECRET]'" in redacted


def test_pii_redactor_secret_field_dummy():
    # Should ignore dummy passwords
    text = "DB(password='test', api_key='your_api_key')"
    redacted = PIIRedactor.redact(text)
    assert "password='test'" in redacted
    assert "api_key='your_api_key'" in redacted


def test_memory_extractor_integration():
    extractor = MemoryExtractor()
    text = "We decided to use Postgres because it's fast. Also, the DB password='supersecret'"
    result = extractor.extract(text)
    # Check that memory doesn't contain the password
    for m in result.memories:
        assert "supersecret" not in m.content
        assert "password='[REDACTED_SECRET]'" in m.content


def test_pii_redactor_office_mode():
    text = "My phone is 13812345678 and my ID is 110105199001011234. Card: 6222021234567890"

    # In programming mode, it shouldn't redact these
    redacted_prog = PIIRedactor.redact(text, mode=ExtractionMode.PROGRAMMING)
    assert "13812345678" in redacted_prog

    # In office mode, it should redact
    redacted_office = PIIRedactor.redact(text, mode=ExtractionMode.OFFICE)
    assert "13812345678" not in redacted_office
    assert "[REDACTED_PHONE]" in redacted_office
    assert "110105199001011234" not in redacted_office
    assert "[REDACTED_ID_CARD]" in redacted_office
    assert "6222021234567890" not in redacted_office
    assert "[REDACTED_BANK_CARD]" in redacted_office
