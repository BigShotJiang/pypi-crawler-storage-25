from unittest.mock import MagicMock, patch

import pytest

from falkordb_memory_server.graph_ops import (
    DatabaseConnectionError,
    GraphOperationError,
    GraphOperations,
    get_graph_ops,
)
from falkordb_memory_server.schema import NodeLabel, RelationType


@pytest.fixture
def mock_settings():
    with patch("falkordb_memory_server.graph_ops.get_settings") as mock_get_settings:
        settings = MagicMock()
        settings.redis_url = "redis://localhost:6379"
        settings.graph_name = "test_graph"
        mock_get_settings.return_value = settings
        yield settings


@pytest.fixture
def mock_falkordb(mock_settings):
    with patch("falkordb_memory_server.graph_ops.FalkorDB") as mock_db_class:
        mock_db_instance = MagicMock()
        mock_db_instance.connection.ping.return_value = True
        mock_graph = MagicMock()
        mock_db_instance.select_graph.return_value = mock_graph
        mock_db_class.from_url.return_value = mock_db_instance
        yield mock_db_class, mock_db_instance, mock_graph


@pytest.fixture
def graph_ops(mock_falkordb):
    ops = GraphOperations()
    # To avoid the delay on first test if it fails
    ops._lock = MagicMock()
    ops._lock.__enter__ = MagicMock(return_value=None)
    ops._lock.__exit__ = MagicMock(return_value=None)
    return ops


def test_singleton_get_graph_ops(mock_falkordb):
    ops1 = get_graph_ops()
    ops2 = get_graph_ops()
    assert ops1 is ops2


def test_connection_success(graph_ops, mock_falkordb):
    _, mock_db_instance, _ = mock_falkordb
    assert graph_ops.is_connected() is True
    mock_db_instance.connection.ping.assert_called()


def test_connection_failure(graph_ops, mock_falkordb):
    mock_db_class, mock_db_instance, _ = mock_falkordb
    mock_db_instance.connection.ping.side_effect = Exception("Connection failed")

    # Try fetching the db property which should raise DatabaseConnectionError
    # First, need to clear _db
    graph_ops._db = None
    with pytest.raises(DatabaseConnectionError):
        _ = graph_ops.db


def test_select_graph_failure(graph_ops, mock_falkordb):
    _, mock_db_instance, _ = mock_falkordb
    mock_db_instance.select_graph.side_effect = Exception("Graph fail")
    graph_ops._graph = None
    with pytest.raises(GraphOperationError):
        _ = graph_ops.graph


def test_validate_label(graph_ops):
    assert graph_ops._validate_label("Memory") == "Memory"
    assert graph_ops._validate_label(NodeLabel.SESSION) == NodeLabel.SESSION.value

    with pytest.raises(GraphOperationError):
        graph_ops._validate_label("")

    with pytest.raises(GraphOperationError):
        graph_ops._validate_label("Invalid-Label!")


def test_validate_relation(graph_ops):
    assert graph_ops._validate_relation("RELATES_TO") == "RELATES_TO"
    assert graph_ops._validate_relation(RelationType.OCCURRED_IN) == RelationType.OCCURRED_IN.value

    with pytest.raises(GraphOperationError):
        graph_ops._validate_relation("")

    with pytest.raises(GraphOperationError):
        graph_ops._validate_relation("Invalid-Rel!")


def test_safe_query_success(graph_ops, mock_falkordb):
    _, _, mock_graph = mock_falkordb
    mock_result = MagicMock()
    mock_result.result_set = [["a", "b"]]
    mock_result.statistics = {"query_time": 10}
    mock_graph.query.return_value = mock_result

    res = graph_ops.safe_query("MATCH (n) RETURN n")
    assert res["result_set"] == [["a", "b"]]
    assert res["statistics"] == {"query_time": 10}


def test_safe_query_failure(graph_ops, mock_falkordb):
    _, _, mock_graph = mock_falkordb
    mock_graph.query.side_effect = Exception("Query error")

    res = graph_ops.safe_query("MATCH (n) RETURN n")
    assert res["result_set"] == []
    assert res["statistics"] == {}
    assert "Query error" in res["error"]


def test_query_database_error(graph_ops, mock_falkordb):
    _, _, mock_graph = mock_falkordb
    mock_graph.query.side_effect = Exception("Connection error: closed")

    with pytest.raises(DatabaseConnectionError):
        graph_ops.query("MATCH (n) RETURN n")


def test_create_vector_index(graph_ops, mock_falkordb):
    _, _, mock_graph = mock_falkordb
    mock_graph.query.return_value = MagicMock(result_set=[], statistics={})

    assert graph_ops.create_vector_index("Memory", "embedding", 1536) is True
    # Test index already exists
    mock_graph.query.side_effect = Exception("Index already exists")
    assert graph_ops.create_vector_index("Memory", "embedding", 1536) is True

    mock_graph.query.side_effect = Exception("Other error")
    assert graph_ops.create_vector_index("Memory", "embedding", 1536) is False


def test_create_node(graph_ops, mock_falkordb):
    _, _, mock_graph = mock_falkordb
    mock_result = MagicMock()
    mock_node = MagicMock()
    mock_node.id = 1
    mock_node.labels = ["Memory"]
    mock_node.properties = {"key": "value"}
    mock_result.result_set = [[mock_node]]
    mock_graph.query.return_value = mock_result

    res = graph_ops.create_node("Memory", {"key": "value"}, return_node=True)
    assert res["id"] == 1
    assert res["labels"] == ["Memory"]
    assert res["properties"] == {"key": "value"}


def test_create_node_no_return(graph_ops, mock_falkordb):
    _, _, mock_graph = mock_falkordb
    mock_result = MagicMock()
    mock_result.result_set = [[123]]
    mock_graph.query.return_value = mock_result

    res = graph_ops.create_node("Memory", {"key": "value"}, return_node=False)
    assert res == {"node_id": 123}


def test_create_edge(graph_ops, mock_falkordb):
    _, _, mock_graph = mock_falkordb
    mock_result = MagicMock()
    mock_edge = MagicMock()
    mock_edge.id = 1
    mock_edge.properties = {"weight": 0.8}
    mock_result.result_set = [[mock_edge]]
    mock_graph.query.return_value = mock_result

    res = graph_ops.create_edge(1, "RELATES_TO", 2, {"weight": 0.8})
    assert res["id"] == 1
    assert res["properties"] == {"weight": 0.8}


def test_delete_nodes(graph_ops, mock_falkordb):
    _, _, mock_graph = mock_falkordb
    mock_result = MagicMock()
    mock_result.result_set = [[2]]
    mock_graph.query.return_value = mock_result

    res = graph_ops.delete_nodes([1, 2], cascade=True)
    assert res["deleted_count"] == 2

    res = graph_ops.delete_nodes([])
    assert res["deleted_count"] == 0


def test_semantic_search(graph_ops, mock_falkordb):
    _, _, mock_graph = mock_falkordb
    mock_result = MagicMock()
    mock_node = MagicMock()
    mock_node.id = 1
    mock_result.result_set = [[mock_node, 0.95]]
    mock_graph.query.return_value = mock_result
    mock_graph.ro_query.return_value = mock_result

    res = graph_ops.semantic_search([0.1, 0.2], label="Memory", k=5, min_score=0.8)
    assert len(res) == 1
    assert res[0]["node"]["id"] == 1
    assert res[0]["score"] == 0.95


def test_get_stats(graph_ops, mock_falkordb):
    _, _, mock_graph = mock_falkordb
    mock_labels = MagicMock()
    mock_labels.result_set = [["Memory"], ["Agent"]]
    mock_rels = MagicMock()
    mock_rels.result_set = [["RELATES_TO"]]
    mock_nodes = MagicMock()
    mock_nodes.result_set = [[10]]
    mock_edges = MagicMock()
    mock_edges.result_set = [[15]]

    mock_graph.query.side_effect = [mock_labels, mock_rels, mock_nodes, mock_edges]

    stats = graph_ops.get_stats()
    assert stats["node_count"] == 10
    assert stats["edge_count"] == 15
    assert stats["labels"] == ["Memory", "Agent"]
    assert stats["relationship_types"] == ["RELATES_TO"]


def test_serialize_value(graph_ops):
    assert graph_ops._serialize_value(None) is None
    assert graph_ops._serialize_value("test") == "test"
    assert graph_ops._serialize_value([1, "a"]) == [1, "a"]
    assert graph_ops._serialize_value({"k": "v"}) == {"k": "v"}

    class MockNode:
        id = 1
        labels = ["Test"]
        properties = {"a": "b"}

    res = graph_ops._serialize_value(MockNode())
    assert res == {"id": 1, "labels": ["Test"], "properties": {"a": "b"}}
