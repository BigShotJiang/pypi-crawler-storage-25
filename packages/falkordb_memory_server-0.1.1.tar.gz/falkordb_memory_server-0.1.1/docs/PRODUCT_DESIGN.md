# FalkorDB 跨 Agent 记忆系统 - 产品设计文档

**版本**: 1.6.0
**日期**: 2026-04-11
**状态**: 包含主动推送特性 (v1.2-v1.6) 已全部实现

---

## 1. 产品概述

### 1.1 背景

随着 AI Agent 技术的发展，企业和开发者越来越多地使用多种 AI Agent（Claude、Codex、Gemini）协同工作。然而，这些 Agent 之间缺乏统一的记忆共享机制，导致：

- **知识孤岛**: 每个 Agent 独立工作，无法共享学习成果
- **上下文丢失**: 会话结束后，重要决策和发现难以持久化
- **重复劳动**: 相同问题被多次解决，效率低下
- **协作困难**: 多 Agent 协作时缺乏共享上下文

### 1.2 产品定位

**FalkorDB 跨 Agent 记忆系统**是一个基于图数据库的持久化记忆层，为多种 AI Agent 提供：

- 统一的记忆存储和检索接口
- 语义搜索能力
- 跨 Agent 知识共享
- 会话上下文追踪
- 自动过期清理

### 1.3 核心价值主张

| 价值 | 描述 |
|------|------|
| **知识持久化** | Agent 的学习、决策、代码片段永久保存 |
| **语义检索** | 通过自然语言查询相关记忆 |
| **跨平台共享** | Claude、Codex、Gemini 共享同一知识库 |
| **关系发现** | 通过图结构发现知识间的隐含关系 |
| **自动治理** | TTL 机制确保记忆库整洁 |

---

## 2. 目标用户

### 2.1 主要用户画像

#### 画像 1: 企业 AI 团队

- **角色**: AI 工程师、技术负责人
- **场景**: 管理多个 AI Agent 协作完成复杂项目
- **痛点**: Agent 间知识不同步，重复训练成本高
- **需求**: 统一的知识管理平台

#### 画像 2: 独立开发者

- **角色**: 全栈开发者、AI 应用开发者
- **场景**: 使用多种 AI 工具辅助开发
- **痛点**: 每个 AI 工具独立运作，无法利用之前的学习
- **需求**: 轻量级的跨工具记忆同步

#### 画像 3: DevOps 团队

- **角色**: SRE、平台工程师
- **场景**: 自动化运维中使用 AI 辅助决策
- **痛点**: AI 决策缺乏历史上下文
- **需求**: 可追溯的决策记录系统

### 2.2 使用场景

| 场景 | 描述 | 价值 |
|------|------|------|
| **代码审查** | Claude 发现问题，Codex 修复，Gemini 验证 | 避免重复发现问题 |
| **架构决策** | 记录技术选型的理由和权衡 | 新成员快速了解背景 |
| **故障排查** | 记录问题根因和解决方案 | 相似问题快速定位 |
| **知识传承** | 记录最佳实践和经验教训 | 组织知识资产化 |

---

## 3. 功能规格

### 3.1 功能矩阵

| 功能模块 | 功能点 | 优先级 | 状态 |
|----------|--------|--------|------|
| **图操作** | Cypher 查询 | P0 | ✅ |
| | 创建节点 | P0 | ✅ |
| | 创建关系 | P0 | ✅ |
| | 删除节点/关系 | P0 | ✅ |
| **记忆原语** | 存储记忆 | P0 | ✅ |
| | 检索记忆 | P0 | ✅ |
| | 关联记忆 | P0 | ✅ |
| | 删除记忆 | P0 | ✅ |
| **记忆提取** | 规则模式匹配 | P0 | ✅ |
| | 工具使用捕获 | P0 | ✅ |
| | 批量文件挖掘 | P1 | ✅ |
| | 情感消歧 | P1 | ✅ |
| **语义搜索** | 向量相似度搜索 | P1 | ✅ |
| | 生成 Embedding | P1 | ✅ |
| | 混合搜索 | P1 | ✅ |
| **会话管理** | 开始会话 | P0 | ✅ |
| | 结束会话 | P0 | ✅ |
| | 继续会话 | P1 | ✅ |
| **Hook 系统** | Claude Code Hook | P0 | ✅ |
| | Gemini CLI Hook | P0 | ✅ |
| | 统一事件适配 | P0 | ✅ |
| | 优雅降级 | P0 | ✅ |
| **跨 Agent** | 共享记忆 | P1 | ✅ |
| | 查询 Agent 记忆 | P1 | ✅ |
| | 权限控制 | P2 | ✅ |
| **维护** | TTL 清理 | P1 | ✅ |
| | 统计信息 | P2 | ✅ |
| **集成** | OMC Notepad 同步 | P2 | ✅ |
| | OMC Project Memory 同步 | P2 | ✅ |
| | Claude Code MCP | P0 | ✅ |
| | Gemini CLI 适配 | P1 | ✅ |
| | Codex CLI 适配 | P1 | ✅ |

### 3.2 MCP 工具详细规格

#### 3.2.1 memory_query

**描述**: 执行 Cypher 查询

**输入参数**:
```json
{
  "query": "string (required) - Cypher 查询字符串",
  "params": "object (optional) - 查询参数",
  "read_only": "boolean (default: false) - 是否只读模式"
}
```

**输出**:
```json
{
  "result_set": [[]],
  "statistics": {
    "nodes_created": 0,
    "relationships_created": 0,
    "properties_set": 0
  }
}
```

**使用示例**:
```
memory_query "MATCH (n:Learning) WHERE n.category = 'security' RETURN n LIMIT 10"
```

#### 3.2.2 memory_remember

**描述**: 存储记忆

**输入参数**:
```json
{
  "memory_type": "enum (learning|decision|code|concept|task) - 记忆类型",
  "content": "object (required) - 记忆内容（类型特定）",
  "context": "object (optional) - 会话/项目上下文",
  "ttl": "integer (optional) - 生存时间（秒）",
  "generate_embedding": "boolean (default: true) - 是否生成嵌入向量"
}
```

**记忆类型内容规格**:

| 类型 | 必填字段 | 可选字段 |
|------|----------|----------|
| learning | content | title, category, tags, applicability |
| decision | context, rationale | type, alternatives, confidence, outcome |
| code | content, name | path, language, type, description |
| concept | name | description, category |
| task | title | description, status, priority |

**输出**:
```json
{
  "node_id": 123,
  "memory_id": "uuid-string",
  "memory_type": "learning",
  "properties": {}
}
```

#### 3.2.3 memory_recall

**描述**: 检索记忆

**输入参数**:
```json
{
  "query_type": "enum (semantic|text|cypher|traversal) - 查询类型",
  "query": "string (required) - 查询字符串或 Cypher",
  "filters": "object (optional) - 属性过滤器",
  "limit": "integer (default: 10, max: 1000) - 最大结果数",
  "include_context": "boolean (default: true) - 是否包含相关节点"
}
```

**查询类型说明**:

| 类型 | 描述 | 使用场景 |
|------|------|----------|
| semantic | 向量相似度搜索 | 查找语义相关的记忆 |
| text | 全文搜索 | 精确关键词匹配 |
| cypher | 直接 Cypher 查询 | 复杂图遍历 |
| traversal | 从起点遍历 | 发现关联记忆 |

#### 3.2.4 memory_semantic_search

**描述**: 语义搜索

**输入参数**:
```json
{
  "query": "string (required) - 搜索文本",
  "node_label": "string (optional) - 过滤节点类型",
  "k": "integer (default: 10) - 返回结果数",
  "min_score": "float (default: 0.0) - 最小相似度阈值"
}
```

**输出**:
```json
[
  {
    "node": {
      "id": 123,
      "labels": ["Learning"],
      "properties": {}
    },
    "score": 0.85
  }
]
```

#### 3.2.5 memory_share

**描述**: 共享记忆给其他 Agent

**输入参数**:
```json
{
  "memory_id": "integer (required) - 记忆节点 ID",
  "target_agents": ["string"] // Agent ID 列表
}
```

#### 3.2.6 memory_start_session / memory_end_session

**描述**: 会话生命周期管理

**start_session 输入**:
```json
{
  "agent_type": "string (required) - claude|codex|gemini",
  "agent_id": "string (required) - Agent 实例标识",
  "project_path": "string (optional) - 工作目录",
  "objective": "string (optional) - 会话目标",
  "ttl": "integer (optional) - 会话 TTL"
}
```

**end_session 输入**:
```json
{
  "session_id": "string (required)",
  "status": "enum (completed|abandoned)",
  "summary": "string (optional) - 会话总结"
}
```

---

## 4. 技术架构

### 4.1 系统架构图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              Agent Layer                                     │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐             │
│  │   Claude Code   │  │   Gemini CLI    │  │   Codex CLI     │             │
│  │  (Anthropic)    │  │  (Google AI)    │  │   (OpenAI)      │             │
│  └────────┬────────┘  └────────┬────────┘  └────────┬────────┘             │
│           │                    │                    │                       │
│           │ MCP Protocol       │ MCP Protocol       │ MCP Protocol          │
│           ▼                    ▼                    ▼                       │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        MCP Server Layer                                      │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                    FalkorDB Memory MCP Server                         │  │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────────┐  │  │
│  │  │ Graph Tools │ │Memory Tools │ │Search Tools │ │Session Tools    │  │  │
│  │  │ - query     │ │ - remember  │ │ - semantic  │ │ - start_session │  │  │
│  │  │ - create    │ │ - recall    │ │ - embed     │ │ - end_session   │  │  │
│  │  │ - delete    │ │ - associate │ │ - hybrid    │ │ - continue      │  │  │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────────┘  │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          Service Layer                                       │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐            │
│  │ MemoryManager    │ │ EmbeddingService │ │ SessionManager   │            │
│  │ - CRUD 操作      │ │ - 向量生成       │ │ - 会话生命周期   │            │
│  │ - 记忆分类       │ │ - 相似度计算     │ │ - Agent 追踪     │            │
│  └──────────────────┘ └──────────────────┘ └──────────────────┘            │
│  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐            │
│  │ TTLManager       │ │ SharingManager   │ │ OMCSyncService   │            │
│  │ - 过期检测       │ │ - 权限管理       │ │ - Notepad 同步   │            │
│  │ - 后台清理       │ │ - 跨 Agent 共享  │ │ - Memory 同步    │            │
│  └──────────────────┘ └──────────────────┘ └──────────────────┘            │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        Data Layer                                            │
│  ┌───────────────────────────────────────────────────────────────────────┐  │
│  │                         FalkorDB (Redis-based)                        │  │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────────┐  │  │
│  │  │ Node Store  │ │ Edge Store  │ │Vector Index │ │ Full-Text Index │  │  │
│  │  │ Sessions    │ │ Relations   │ │ Embeddings  │ │ Text Search     │  │  │
│  │  │ Agents      │ │ Properties  │ │ Cosine Sim  │ │ Keywords        │  │  │
│  │  │ Memories    │ │             │ │             │ │                 │  │  │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────────┘  │  │
│  └───────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 技术栈

| 层级 | 技术选型 | 版本要求 | 说明 |
|------|----------|----------|------|
| **Agent 层** | Claude Code | >= 2.0 | Anthropic CLI |
| | Gemini CLI | latest | Google AI CLI |
| | Codex CLI | latest | OpenAI CLI |
| **MCP 层** | mcp (Python) | >= 1.0.0 | MCP SDK |
| **服务层** | Python | >= 3.10 | 运行时 |
| | pydantic | >= 2.0.0 | 数据验证 |
| | sentence-transformers | >= 2.2.0 | 嵌入模型 |
| **数据层** | FalkorDB | >= 4.0 | 图数据库 |
| | Redis | >= 7.0 | 存储后端 |

### 4.3 部署架构

#### 开发环境

```yaml
# docker-compose.yml
services:
  falkordb:
    image: falkordb/falkordb:latest
    ports:
      - "6379:6379"
    volumes:
      - falkordb_data:/data
    command: ["--save", "60", "1000", "--appendonly", "yes"]
```

#### 生产环境

```
┌─────────────────────────────────────────────────────────────┐
│                      Load Balancer                          │
└─────────────────────────────────────────────────────────────┘
                              │
              ┌───────────────┼───────────────┐
              ▼               ▼               ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│  MCP Server 1   │ │  MCP Server 2   │ │  MCP Server N   │
│  (Stateless)    │ │  (Stateless)    │ │  (Stateless)    │
└────────┬────────┘ └────────┬────────┘ └────────┬────────┘
         │                   │                   │
         └───────────────────┼───────────────────┘
                             ▼
              ┌──────────────────────────────┐
              │    FalkorDB Cluster          │
              │  ┌─────────┐  ┌─────────┐   │
              │  │ Master  │  │ Replica │   │
              │  └─────────┘  └─────────┘   │
              └──────────────────────────────┘
```

---

## 5. 数据模型

### 5.1 图 Schema

#### 节点类型

```cypher
// Session - 会话节点
CREATE CONSTRAINT session_id_unique IF NOT EXISTS
FOR (s:Session) REQUIRE s.id IS UNIQUE;

// Agent - Agent 节点
CREATE CONSTRAINT agent_id_unique IF NOT EXISTS
FOR (a:Agent) REQUIRE a.id IS UNIQUE;

// Decision - 决策节点
CREATE CONSTRAINT decision_id_unique IF NOT EXISTS
FOR (d:Decision) REQUIRE d.id IS UNIQUE;

// Learning - 学习节点
CREATE CONSTRAINT learning_id_unique IF NOT EXISTS
FOR (l:Learning) REQUIRE l.id IS UNIQUE;

// Code - 代码节点
CREATE CONSTRAINT code_id_unique IF NOT EXISTS
FOR (c:Code) REQUIRE c.id IS UNIQUE;

// Concept - 概念节点
CREATE CONSTRAINT concept_id_unique IF NOT EXISTS
FOR (c:Concept) REQUIRE c.id IS UNIQUE;
```

#### 节点属性详细定义

```yaml
Session:
  id: string (UUID) - 唯一标识
  agent_type: string - claude|codex|gemini
  agent_id: string - Agent 实例 ID
  project_path: string - 工作目录
  started_at: datetime - 开始时间 (ISO 8601)
  ended_at: datetime - 结束时间
  status: string - active|completed|abandoned
  objective: string - 会话目标
  ttl: integer - 生存时间（秒）
  summary: string - 会话总结
  metadata: object - 扩展元数据

Agent:
  id: string - 唯一标识
  type: string - claude|codex|gemini
  name: string - 显示名称
  namespace: string - 命名空间
  capabilities: string[] - 能力列表
  preferences: object - 偏好设置
  first_seen: datetime - 首次出现
  last_active: datetime - 最后活跃

Decision:
  id: string (UUID)
  type: string - architecture|implementation|refactor|etc
  context: string - 决策背景
  rationale: string - 决策理由
  alternatives: string[] - 备选方案
  outcome: string - 结果
  confidence: float (0.0-1.0) - 置信度
  created_at: datetime
  embedding: float[] - 语义向量

Learning:
  id: string (UUID)
  category: string - pattern|anti-pattern|tip|insight
  title: string - 标题
  content: string - 内容
  tags: string[] - 标签
  applicability: string - 适用场景
  source: string - 来源
  created_at: datetime
  last_applied: datetime
  application_count: integer
  embedding: float[]

Code:
  id: string (UUID)
  path: string - 文件路径
  language: string - 编程语言
  name: string - 名称
  type: string - function|class|module|file
  content: string - 代码内容
  description: string - 描述
  hash: string - 内容哈希
  created_at: datetime
  embedding: float[]

Concept:
  id: string (UUID)
  name: string - 概念名称
  description: string - 描述
  category: string - 分类
  created_at: datetime
  embedding: float[]
```

#### 关系类型

```cypher
// 时间/会话关系
(:Session)-[:STARTED_BY]->(:Agent)
(:Session)-[:CONTINUES]->(:Session)
(:Decision)-[:OCCURRED_IN]->(:Session)

// 因果/依赖关系
(:Decision)-[:LED_TO]->(:Decision)
(:Task)-[:DEPENDS_ON]->(:Task)
(:Learning)-[:DERIVED_FROM]->(:Code|Decision)

// 结构关系
(:Project)-[:CONTAINS]->(:Code)
(:Code)-[:IMPLEMENTS]->(:Concept)
(:Agent)-[:USES]->(:Skill)

// 知识关系
(:Agent)-[:KNOWS]->(:Concept)
(:Concept)-[:RELATED_TO]->(:Concept)
(:Code)-[:SIMILAR_TO]->(:Code)  // 带 embedding 属性

// 记忆关系
(:Agent)-[:REMEMBERS]->(:Learning)
(:Session)-[:DISCOVERED]->(:Artifact)
(:Session)-[:APPLIED]->(:Skill)

// 共享关系
(:Memory)-[:SHARED_WITH]->(:Agent)  // 带权限属性
```

### 5.2 索引策略

#### 向量索引

```python
# 为每种记忆类型创建向量索引
graph.create_node_vector_index(
    "Learning",
    "embedding",
    dim=384,  # all-MiniLM-L6-v2
    similarity_function="cosine"
)

graph.create_node_vector_index(
    "Decision",
    "embedding",
    dim=384,
    similarity_function="cosine"
)

graph.create_node_vector_index(
    "Code",
    "embedding",
    dim=384,
    similarity_function="cosine"
)

graph.create_node_vector_index(
    "Concept",
    "embedding",
    dim=384,
    similarity_function="cosine"
)
```

#### 全文索引

```python
# 为常用搜索字段创建全文索引
graph.create_node_fulltext_index("Learning", "title", "content", "tags")
graph.create_node_fulltext_index("Decision", "context", "rationale")
graph.create_node_fulltext_index("Code", "name", "description", "content")
graph.create_node_fulltext_index("Concept", "name", "description")
```

### 5.3 查询模式

#### 语义搜索查询

```cypher
// 向量相似度搜索
CALL db.idx.vector.queryNodes('embedding', 10, $query_vector)
YIELD node, score
WHERE score >= 0.5
RETURN node, score
ORDER BY score DESC
```

#### 记忆链查询

```cypher
// 获取记忆的知识图谱
MATCH path = (start:Learning {id: $id})-[:DERIVED_FROM|RELATED_TO*1..3]-(related)
RETURN nodes(path), relationships(path)
```

#### Agent 记忆查询

```cypher
// 获取 Agent 的所有记忆
MATCH (a:Agent {id: $agent_id})-[:STARTED_BY]-(s:Session)-[r]-(m)
WHERE NOT m:Session AND NOT m:Agent
RETURN m, type(r) as relation
ORDER BY m.created_at DESC
```

---

## 6. API 设计

### 6.1 MCP 工具完整列表

| 工具名称 | 类别 | 描述 | 只读 |
|----------|------|------|------|
| `memory_query` | Graph | 执行 Cypher 查询 | 可选 |
| `memory_create_node` | Graph | 创建节点 | 否 |
| `memory_create_edge` | Graph | 创建关系 | 否 |
| `memory_delete` | Graph | 删除节点/关系 | 否 |
| `memory_remember` | Memory | 存储记忆 | 否 |
| `memory_recall` | Memory | 检索记忆 | 是 |
| `memory_associate` | Memory | 关联记忆 | 否 |
| `memory_forget` | Memory | 删除记忆 | 否 |
| `memory_extract` | Extraction | 从文本提取记忆 | 否 |
| `memory_mine` | Extraction | 批量挖掘文件记忆 | 否 |
| `memory_start_session` | Session | 开始会话 | 否 |
| `memory_end_session` | Session | 结束会话 | 否 |
| `memory_continue_session` | Session | 继续会话 | 否 |
| `memory_semantic_search` | Search | 语义搜索 | 是 |
| `memory_embed` | Search | 生成嵌入 | 是 |
| `memory_share` | Sharing | 共享记忆 | 否 |
| `memory_query_agent` | Sharing | 查询 Agent 记忆 | 是 |
| `memory_stats` | Admin | 统计信息 | 是 |
| `memory_cleanup` | Admin | 清理过期 | 否 |

### 6.2 记忆提取工具

#### 6.2.1 memory_extract

**描述**: 从文本中自动提取记忆

**输入参数**:
```json
{
  "text": "string (required) - 待提取的文本内容",
  "source_file": "string (optional) - 来源文件路径",
  "min_confidence": "float (default: 0.3) - 最小置信度阈值",
  "store": "boolean (default: false) - 是否自动存储到图"
}
```

**输出**:
```json
{
  "memories": [
    {
      "content": "We decided to use PostgreSQL...",
      "category": "decision",
      "confidence": 0.6,
      "keywords": ["decided", "because"],
      "chunk_index": 0,
      "source_file": null
    }
  ],
  "total_chunks": 1,
  "by_category": {"decision": 1},
  "stored_count": 1,
  "stored_ids": [123]
}
```

**记忆类型**:

| 类型 | 描述 | 匹配模式示例 |
|------|------|-------------|
| `decision` | 决策、选择 | "We decided to...", "instead of" |
| `preference` | 偏好、约定 | "I always use...", "never do" |
| `milestone` | 里程碑 | "It worked!", "fixed", "solved" |
| `problem` | 问题、故障 | "error", "crash", "bug" |
| `learning` | 学习、洞察 | "learned", "insight", "tip" |
| `emotional` | 情感 | "love", "proud", "frustrated" |
| `general` | 通用 | - |

#### 6.2.2 memory_mine

**描述**: 从文件或目录批量挖掘记忆

**输入参数**:
```json
{
  "path": "string (required) - 文件或目录路径",
  "recursive": "boolean (default: true) - 是否递归子目录",
  "file_extensions": ["string"] // 文件扩展名列表
}
```

**输出**:
```json
{
  "memories": [...],
  "total_chunks": 150,
  "by_category": {
    "decision": 12,
    "learning": 8
  },
  "stored_count": 20,
  "stored_ids": [1, 2, 3]
}
```

### 6.3 Hook 系统

#### 6.3.1 支持的 CLI

| CLI | Hook 事件 | 配置文件 |
|-----|----------|---------|
| Claude Code | `PreToolUse`, `PostToolUse`, `UserPromptSubmit` | `~/.claude/settings.json` |
| Gemini CLI | `BeforeTool`, `AfterTool`, `SessionStart`, `SessionEnd`, `BeforeAgent` | `~/.gemini/settings.json` |

#### 6.3.2 统一事件映射

```
Claude Code          Gemini CLI           统一事件
─────────────────────────────────────────────────────
PreToolUse      →   BeforeTool      →   before_tool
PostToolUse     →   AfterTool       →   after_tool
UserPromptSubmit→   BeforeAgent     →   user_prompt
-               →   SessionStart    →   session_start
-               →   SessionEnd      →   session_end
-               →   AfterAgent      →   agent_response
```

#### 6.3.3 Hook 配置示例

**Claude Code** (`~/.claude/settings.json`):
```json
{
  "hooks": {
    "SessionStart": [{
      "matcher": ".*",
      "hooks": [{
        "type": "command",
        "command": "python /path/to/hooks/claude-code-hook.py"
      }]
    }],
    "PostToolUse": [{
      "matcher": ".*",
      "hooks": [{
        "type": "command",
        "command": "python /path/to/hooks/claude-code-hook.py"
      }]
    }]
  }
}
```

**Gemini CLI** (`~/.gemini/settings.json`):
```json
{
  "hooks": {
    "AfterTool": [{
      "matcher": ".*",
      "hooks": [{
        "type": "command",
        "command": "python /path/to/hooks/gemini-cli-hook.py"
      }]
    }],
    "SessionStart": [{
      "hooks": [{
        "type": "command",
        "command": "python /path/to/hooks/gemini-cli-hook.py"
      }]
    }]
  }
}
```

#### 6.3.4 Hook 行为

| 事件 | 行为 |
|------|------|
| `session_start` | 创建 Session 节点，注入相关记忆上下文 |
| `session_end` | 更新 Session 状态，清理资源 |
| `after_tool` | 提取工具使用记忆，存储到图 |
| `user_prompt` | 从用户输入提取记忆 |

### 6.4 配置 API

#### 环境变量

```bash
# 连接配置
FALKORDB_URL=redis://localhost:6379
FALKORDB_HOST=localhost
FALKORDB_PORT=6379
FALKORDB_PASSWORD=

# 图配置
GRAPH_NAME=agent_memory

# 嵌入配置
EMBEDDING_MODEL=all-MiniLM-L6-v2
EMBEDDING_DIMENSION=384

# 记忆配置
DEFAULT_TTL=604800
MAX_RESULTS=100

# 日志
LOG_LEVEL=INFO
```

### 6.3 Python SDK

```python
from falkordb_memory_server import (
    MemoryManager,
    SessionManager,
    SemanticSearchEngine,
    GeminiMemoryAdapter,
    CodexMemoryAdapter,
)

# 直接使用记忆管理器
manager = MemoryManager()
manager.remember(
    memory_type="learning",
    content={
        "title": "Connection Pooling Best Practices",
        "content": "Always use connection pooling for database operations",
        "category": "performance",
        "tags": ["database", "performance"]
    }
)

# 使用 Agent 适配器
gemini = GeminiMemoryAdapter(agent_id="gemini-1")
gemini.start_session(objective="Implement authentication")
gemini.remember("Use JWT for stateless auth")
results = gemini.recall("authentication")
gemini.end_session(summary="Auth implementation complete")
```

---

## 7. 安全与隐私

### 7.1 安全措施

| 措施 | 描述 |
|------|------|
| **网络隔离** | FalkorDB 仅监听本地或内网 |
| **认证** | 支持 Redis AUTH 密码 |
| **权限控制** | 共享机制支持读写权限分离 |
| **数据加密** | 传输层 TLS（可选） |
| **审计日志** | 所有操作记录到慢查询日志 |

### 7.2 隐私考虑

- 记忆内容可能包含敏感信息，建议对敏感内容加密
- TTL 机制确保过期数据自动清理
- 命名空间隔离支持多租户场景

### 7.3 合规建议

- 配置适当的数据保留策略
- 定期清理包含 PII 的记忆
- 记录数据访问日志用于审计

---

## 8. 性能指标

### 8.1 目标 SLA

| 指标 | 目标值 | 说明 |
|------|--------|------|
| 查询延迟 P50 | < 50ms | 简单查询 |
| 查询延迟 P99 | < 200ms | 复杂图遍历 |
| 语义搜索延迟 | < 500ms | 包含嵌入生成 |
| 吞吐量 | > 1000 QPS | 单实例 |
| 可用性 | 99.9% | 月度 |

### 8.2 性能优化建议

1. **嵌入模型选择**:
   - `all-MiniLM-L6-v2`: 384 维，速度快
   - `all-mpnet-base-v2`: 768 维，精度高

2. **索引优化**:
   - 为常用查询路径创建索引
   - 定期重建碎片化索引

3. **缓存策略**:
   - 热点记忆缓存
   - 嵌入向量缓存

---

## 9. 路线图

### 9.1 已完成 (v1.0)

- ✅ 核心 MCP 服务器
- ✅ 图操作工具
- ✅ 记忆原语
- ✅ 会话管理
- ✅ 语义搜索
- ✅ 跨 Agent 共享
- ✅ Gemini/Codex 适配器
- ✅ OMC 集成

### 9.2 已完成 (v1.1)

- ✅ 记忆提取系统（规则模式匹配）
- ✅ 工具使用捕获
- ✅ 批量文件挖掘
- ✅ Claude Code Hook 集成
- ✅ Gemini CLI Hook 集成
- ✅ 统一 Hook 适配器
- ✅ 优雅降级处理

### 9.3 已完成 (v1.2-v1.5 核心流程增强)

- ✅ Decision Chain 决策链查询
- ✅ Bug Pattern 问题库记忆
- ✅ Code Pattern 代码范式记忆
- ✅ 项目上下文自动加载 (Wake-up)
- ✅ 测试用例、重构与 API 调用记忆
- ✅ 增量挖掘 (跳过未修改文件)
- ✅ 图可视化 Web UI
- ✅ 3层渐进式搜索 (Progressive Disclosure)
- ✅ L0-L3 层级记忆栈 (Endless Mode)
- ✅ 三方会话历史挖矿 (Claude/ChatGPT/Slack)

### 9.4 未来规划 (v2.0)

- 🔲 多租户支持
- 🔲 高级权限控制
- 🔲 记忆质量评分
- 🔲 AI 增强记忆提取
- 🔲 Agent 行为分析

---

## 10. 附录

### 10.1 术语表

| 术语 | 定义 |
|------|------|
| MCP | Model Context Protocol，模型上下文协议 |
| FalkorDB | 基于 Redis 的图数据库 |
| Cypher | 图查询语言（Neo4j 兼容） |
| Embedding | 语义向量表示 |
| TTL | Time To Live，生存时间 |
| OMC | oh-my-claudecode，Claude Code 增强层 |
| Hook | Agent CLI 生命周期事件钩子 |
| Extraction | 记忆提取，从文本中自动识别和分类记忆 |

### 10.2 参考资料

- [FalkorDB 官方文档](https://docs.falkordb.com/)
- [MCP 协议规范](https://modelcontextprotocol.io/)
- [Sentence Transformers](https://www.sbert.net/)
- [Claude Code 文档](https://docs.anthropic.com/claude-code)
- [Gemini CLI Hooks](https://geminicli.com/docs/hooks/)
- [MemPalace](https://github.com/mempathy-labs/mempalace) - 记忆提取设计参考
- [Claude-Mem](https://github.com/anthropics/claude-mem) - Hook 生命周期参考

### 10.3 变更日志

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0.0 | 2026-04-09 | 初始版本发布 |
| 1.1.0 | 2026-04-09 | 添加记忆提取系统、Hook 系统集成 |
| 1.6.0 | 2026-04-11 | 增加 Proactive Insights 主动洞察推送机制 |
| 1.7.0 | 2026-04-11 | 增加 PII 与 Secrets 脱敏防线 (PIIRedactor) |

---

## 11. 核心机制设计

### 11.1 主动洞察推送 (Proactive Insights)

为了打破 Agent 只有被动 Recall 才能获取图谱架构知识的限制，系统引入了**主动洞察推送机制**。在确保不增加执行延迟和防止上下文污染的前提下，采用混合方案：

1. **回合驱动拦截 (Turn-Driven for Gemini)**
   - 拦截 `USER_PROMPT` (即每次对话周期的起点)。
   - 提取用户的 prompt 中的关键词和文件路径，通过图查询检索过去 1 小时内未被推送过的 `Decision`、`Convention` 或 `Learning` 节点。
   - 使用 `additionalContext` 响应，使 AI 在接下来的任务执行前拥有历史架构对齐的心智。
   - 查询限制在 100ms 内完成，每次推送不超过 3 条高置信度（>=0.8）历史决策。

2. **异步文件渲染 (Async State for Claude Code)**
   - 由于 Claude 不支持通过 Hook 进行直接的上下文附加，系统在拦截 `USER_PROMPT` 时，会自动将检索到的洞察结果写入当前工程的 `.omg/state/active-architecture.md` 文件中。
   - 利用 Claude 本身的 Workspace 状态自动感知能力，实现“无感”防御式的上下文对齐。

3. **Session 级排重 (Deduplication)**
   - 本地写入缓存 `.omg/state/insights_cache_{session_id}.json` 记录已推送节点 ID。
   - 冷却时间设为 1 小时，防止多次 Prompt 提及同名文件时重复产生大批量相同推送，严格控制 Token 污染。

### 11.2 PII 与密钥脱敏 (PII & Secrets Redaction)

为保障企业级应用的安全合规性，系统在提取层 (`MemoryExtractor`) 的入口处前置注入了 **PII 与密钥脱敏防线 (`PIIRedactor`)**：

1. **强力正则匹配拦截**: 拦截 AWS Keys、JWT Tokens、RSA Private Keys、Email、以及公网 IP。
2. **凭证脱敏替换**: 识别形如 `password="xxx"` 的上下文，替换为 `[REDACTED_SECRET]`。
3. **白名单旁路机制**: 支持常见局域网 IP (如 `127.0.0.1`、`192.168.*`) 和 `dummy/test` 密码值的旁路过滤，防止本地调试受阻。

**文档维护者**: OMC Team
**最后更新**: 2026-04-11