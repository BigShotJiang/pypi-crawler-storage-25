# Proactive Insights Architecture Design

## 1. 拦截与推送机制 (Interception & Delivery)
为了避免 `BEFORE_TOOL` 带来的高频延迟和上下文污染，采用混合推送模式：
- **Gemini CLI**: 在 `USER_PROMPT` 阶段拦截。此时 Agent 的工作循环刚刚开始。我们将从用户的 prompt 中提取可能涉及的文件名、技术栈或操作意图，向图谱查询关联的 `Decision` (架构决策) 和 `Convention` (规范)。将查询结果封装到 `additionalContext` 返回，确保该回合的回答或工具调用天然带有架构认知。
- **Claude Code**: 由于其 `PreToolUse` 的限制，采用被动注入模式。在 `SESSION_START` 阶段除了初始化图节点外，后台异步将项目高优决策和规范生成到工作区文件 `.omg/state/active-architecture.md` 中。Claude Code 会在随后的上下文中自动感知该文件（如果在 `.claude/settings.json` 或 `CLAUDE.md` 中引用了它）。

## 2. 上下文防重与排重策略 (Deduplication)
在内存中或者本地状态文件中维护一个 Session 级别的缓存 (Session LRU Cache) 或记录文件：
- **缓存键**: `session_id:memory_node_id`
- 当一个架构决策 (Node ID) 被推送给特定的 Agent Session 后，记录其推送时间。
- **排重机制**: 在同一 Session 期间，如果某项 Decision 在过去 1 小时内已经推送过，则跳过不再推送。这确保即使用户在多个 prompt 中反复提及同一个文件，底层设计规范只会注入一次。
- **优先级截断**: 每次 `USER_PROMPT` 注入的 Insight 数量硬性限制为最多 3 条，按相关性得分 (Score) 和置信度 (Confidence > 0.8) 降序排序。

## 3. 多路推送协议兼容性矩阵 (Compatibility Matrix)
| Agent CLI | 拦截节点 | 上下文注入方式 | 优点 | 缺点 |
|-----------|----------|----------------|------|------|
| **Gemini CLI** | `USER_PROMPT` (`BeforeAgent`) | Native `additionalContext` 返回 | 无缝嵌入当前 Prompt 对话中，零文件污染 | 只有 Gemini 原生支持该字段 |
| **Claude Code** | `SESSION_START` | 渲染至本地文件 `.omg/state/active-architecture.md` | 对 Claude 完全透明，利用其自带的文件阅读机制 | 实时性稍弱，无法针对单个特定 prompt 注入，偏向全局。 |

---
*上述设计已满足 T1.1, T1.2, T1.3 的目标。*