# 跨 CLI Hook 机制设计

## 概述

FalkorDB Memory 需要支持 Claude Code 和 Gemini CLI 两种 Agent CLI 的 hook 机制，实现统一的记忆捕获和存储。

---

## Hook 事件对比

### Gemini CLI vs Claude Code

| 事件类型 | Gemini CLI | Claude Code | 统一名称 |
|---------|------------|-------------|---------|
| 会话开始 | `SessionStart` | - | `session_start` |
| 会话结束 | `SessionEnd` | - | `session_end` |
| 用户提交 | `BeforeAgent` | `UserPromptSubmit` | `user_prompt` |
| Agent 完成 | `AfterAgent` | - | `agent_response` |
| 模型请求前 | `BeforeModel` | - | `before_model` |
| 模型响应后 | `AfterModel` | - | `after_model` |
| 工具选择前 | `BeforeToolSelection` | - | `tool_selection` |
| 工具执行前 | `BeforeTool` | `PreToolUse` | `before_tool` |
| 工具执行后 | `AfterTool` | `PostToolUse` | `after_tool` |
| 压缩前 | `PreCompress` | - | `pre_compress` |
| 通知 | `Notification` | `Notification` | `notification` |

---

## 通信协议对比

### Gemini CLI

```json
// Input (stdin)
{
  "session_id": "string",
  "transcript_path": "string",
  "cwd": "string",
  "hook_event_name": "BeforeTool",
  "timestamp": "2026-01-01T00:00:00Z",
  "tool_name": "read_file",
  "tool_input": {...}
}

// Output (stdout)
{
  "decision": "allow" | "deny",
  "reason": "string",
  "systemMessage": "string",
  "hookSpecificOutput": {...}
}
```

**Exit Codes:**
- `0`: Success, stdout parsed as JSON
- `2`: Block, stderr used as rejection reason
- Other: Warning, continues with original params

### Claude Code

```json
// Input (stdin)
{
  "session_id": "string",
  "transcript_path": "string",
  "cwd": "string",
  "hook_event_name": "PreToolUse",
  "tool_name": "Read",
  "tool_input": {...}
}

// Output (stdout)
{
  "decision": "approve" | "deny",
  "reason": "string"
}
```

**Exit Codes:**
- `0`: Success
- `2`: Blocking error (stderr shown to user)

---

## 统一 Hook 适配器

### 设计目标

1. **单一代码库**: 一套 hook 逻辑，两种 CLI 配置
2. **自动检测**: 根据 `hook_event_name` 自动适配
3. **数据标准化**: 统一输入/输出格式
4. **记忆捕获**: 自动提取并存储记忆

### 架构

```
┌─────────────────────────────────────────────────────────┐
│                  Agent CLI Layer                         │
│   Claude Code │ Gemini CLI │ Future Agents              │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              Hook Adapter (hook_adapter.py)              │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────────┐│
│  │Input Normal.│ │Event Router │ │Output Normalizer   ││
│  └─────────────┘ └─────────────┘ └─────────────────────┘│
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              Memory Hook Handler                         │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────────┐│
│  │Extractor    │ │Graph Store  │ │Context Injector     ││
│  └─────────────┘ └─────────────┘ └─────────────────────┘│
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│                    FalkorDB                              │
└─────────────────────────────────────────────────────────┘
```

---

## 实现细节

### 输入标准化

```python
class UnifiedHookInput(BaseModel):
    """统一 hook 输入格式。"""
    # 基础字段
    session_id: str
    cwd: str
    timestamp: datetime
    hook_event: str  # 标准化后的事件名

    # 原始数据
    raw_event: str  # 原始事件名 (BeforeTool/PreToolUse)
    source_cli: str  # "claude" | "gemini"

    # 事件相关字段
    prompt: str | None = None
    tool_name: str | None = None
    tool_input: dict | None = None
    tool_output: dict | None = None
    model_response: str | None = None
```

### 输出标准化

```python
class UnifiedHookOutput(BaseModel):
    """统一 hook 输出格式。"""
    decision: Literal["allow", "deny"] = "allow"
    reason: str | None = None
    system_message: str | None = None

    # CLI 特定输出
    claude_specific: dict = {}
    gemini_specific: dict = {}

    def to_claude_output(self) -> dict:
        """转换为 Claude Code 输出格式。"""
        return {
            "decision": "approve" if self.decision == "allow" else "deny",
            "reason": self.reason,
        }

    def to_gemini_output(self) -> dict:
        """转换为 Gemini CLI 输出格式。"""
        result = {
            "decision": self.decision,
            "reason": self.reason,
            "systemMessage": self.system_message,
        }
        if self.gemini_specific:
            result["hookSpecificOutput"] = self.gemini_specific
        return result
```

---

## Hook 脚本实现

### Claude Code Hook (`hooks/claude-hook.py`)

```python
#!/usr/bin/env python3
"""Claude Code hook for FalkorDB Memory."""

import sys
import json
from hook_adapter import HookAdapter

def main():
    # 读取 Claude Code 输入
    input_data = json.load(sys.stdin)
    event_name = input_data.get("hook_event_name", "")

    # 创建适配器
    adapter = HookAdapter(source_cli="claude")

    # 处理事件
    result = adapter.handle(event_name, input_data)

    # 输出 Claude Code 格式
    print(json.dumps(result.to_claude_output()))
    sys.exit(0)

if __name__ == "__main__":
    main()
```

### Gemini CLI Hook (`hooks/gemini-hook.py`)

```python
#!/usr/bin/env python3
"""Gemini CLI hook for FalkorDB Memory."""

import sys
import json
from hook_adapter import HookAdapter

def main():
    # 读取 Gemini CLI 输入
    input_data = json.load(sys.stdin)
    event_name = input_data.get("hook_event_name", "")

    # 创建适配器
    adapter = HookAdapter(source_cli="gemini")

    # 处理事件
    result = adapter.handle(event_name, input_data)

    # 输出 Gemini CLI 格式
    print(json.dumps(result.to_gemini_output()))
    sys.exit(0)

if __name__ == "__main__":
    main()
```

---

## 配置文件

### Claude Code (`~/.claude/settings.json`)

```json
{
  "hooks": {
    "SessionStart": [
      {
        "matcher": ".*",
        "hooks": [
          {
            "type": "command",
            "command": "python /path/to/hooks/claude-hook.py"
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": ".*",
        "hooks": [
          {
            "type": "command",
            "command": "python /path/to/hooks/claude-hook.py"
          }
        ]
      }
    ]
  }
}
```

### Gemini CLI (`~/.gemini/settings.json`)

```json
{
  "hooks": {
    "BeforeTool": [
      {
        "matcher": ".*",
        "hooks": [
          {
            "type": "command",
            "command": "python /path/to/hooks/gemini-hook.py"
          }
        ]
      }
    ],
    "AfterTool": [
      {
        "matcher": ".*",
        "hooks": [
          {
            "type": "command",
            "command": "python /path/to/hooks/gemini-hook.py"
          }
        ]
      }
    ],
    "SessionStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python /path/to/hooks/gemini-hook.py"
          }
        ]
      }
    ],
    "SessionEnd": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python /path/to/hooks/gemini-hook.py"
          }
        ]
      }
    ]
  }
}
```

---

## 记忆捕获策略

### 工具使用捕获 (`before_tool` / `after_tool`)

```python
def capture_tool_memory(self, tool_name: str, tool_input: dict, tool_output: dict):
    """捕获工具使用记忆。"""
    from extractor import MemoryExtractor

    extractor = MemoryExtractor()
    memory = extractor.extract_from_tool_use(
        tool_name=tool_name,
        tool_input=tool_input,
        tool_output=tool_output,
        context={
            "session_id": self.session_id,
            "cwd": self.cwd,
        }
    )

    if memory:
        self.store_memory(memory)
```

### 会话上下文注入 (`session_start`)

```python
def inject_context(self, session_id: str) -> str:
    """注入相关记忆作为上下文。"""
    # 查询相关记忆
    memories = self.recall_relevant_memories(session_id)

    if memories:
        context = "# Relevant Memories\n\n"
        for m in memories[:10]:
            context += f"- [{m.category}] {m.content}\n"
        return context

    return ""
```

---

## 安全考虑

1. **指纹验证**: 验证 hook 脚本完整性
2. **权限控制**: 限制敏感工具访问
3. **数据过滤**: 过滤敏感信息再存储
4. **超时处理**: 设置合理的 hook 超时时间

---

## 后续扩展

1. **Codex 支持**: OpenAI Codex CLI 发布后适配
2. **自定义 Agent**: 提供 SDK 让自定义 Agent 接入
3. **Hook 链**: 支持多个 hook 按顺序执行
4. **条件触发**: 基于规则的条件性记忆存储