# FalkorDB Memory Server API Reference

This document provides a comprehensive API reference for the core modules of the `falkordb_memory_server`.

## 1. Graph Operations (`graph_ops.py`)

The `graph_ops` module provides the foundational layer for interacting with FalkorDB. It handles connection pooling, Cypher query execution, and basic graph manipulations.

### `GraphOperations` Class

The primary class for executing graph commands.

| Method | Description |
| :--- | :--- |
| `is_connected() -> bool` | Checks if the FalkorDB connection is active and responsive. |
| `query(cypher: str, params: dict = None, read_only: bool = False) -> dict` | Executes a Cypher query and returns parsed results and statistics. |
| `safe_query(cypher: str, params: dict = None, read_only: bool = False) -> dict` | Executes a query with built-in error handling, returning an empty result set on failure. |
| `create_node(label: str, properties: dict, return_node: bool = True) -> dict` | Creates a new node with automatic `created_at` timestamping. |
| `create_edge(from_id: int, relation: str, to_id: int, properties: dict = None) -> dict` | Creates a directed relationship between two nodes. |
| `delete_nodes(node_ids: list[int], cascade: bool = False) -> dict` | Deletes nodes by ID. If `cascade` is true, performs a `DETACH DELETE`. |
| `semantic_search(query_vector: list[float], label: str = None, k: int = 10, min_score: float = 0.0) -> list` | Performs vector similarity search using FalkorDB's vector index. |
| `create_vector_index(label: str, property_name: str, dimension: int, similarity_function: str = "cosine") -> bool` | Initializes a vector index on a specific node label and property. |
| `get_stats() -> dict` | Retrieves global graph statistics, including node counts and available labels. |

---

## 2. Session Management (`session.py`)

The `session` module manages agent interaction context. It tracks when sessions start and end, and links memories to the specific session where they originated.

### `SessionManager` Class

Manages the lifecycle of agent sessions.

| Method | Description |
| :--- | :--- |
| `start_session(...) -> dict` | Initializes a new session for an agent (Claude, Codex, Gemini, etc.). |
| `end_session(session_id: str, status: str = "completed", summary: str = None) -> dict` | Updates a session status and records the end time and optional summary. |
| `continue_session(...) -> dict` | Creates a new session that explicitly links back to a previous session ID. |
| `get_current_session() -> dict \| None` | Returns information about the currently active session in the manager instance. |
| `get_session_memories(session_id: str, ...) -> dict` | Retrieves all memories (nodes) associated with a specific session. |
| `add_memory_to_session(session_id: str, memory_id: int \| str, ...) -> dict` | Manually links an existing memory node to a session. |
| `list_sessions(agent_type: str = None, status: str = None, limit: int = 20) -> dict` | Lists sessions with filtering options. |

---

## 3. Cross-Agent Sharing (`sharing.py`)

The `sharing` module handles multi-agent collaboration. it allows agents to register their identities and share memories with specific permissions.

### `SharingManager` Class

Handles agent registration and memory sharing permissions.

| Method | Description |
| :--- | :--- |
| `register_agent(agent_id: str, agent_type: str, ...) -> dict` | Registers or updates an agent's profile in the graph. |
| `share_memory(memory_id: int \| str, target_agent_ids: list[str], ...) -> dict` | Grants specific agents access to a memory node. |
| `query_agent_memories(agent_id: str = None, ...) -> dict` | Finds memories that have been shared by a specific agent. |
| `get_agent_knowledge(agent_id: str, include_shared: bool = True, ...) -> dict` | Aggregates all knowledge an agent has access to (own + shared). |
| `check_permission(memory_id: int \| str, agent_id: str, permission: str = "read") -> bool` | Checks if an agent has the required permission (read/write/delete/share) for a node. |
| `revoke_sharing(memory_id: int \| str, agent_ids: list[str] = None) -> dict` | Removes sharing relationships for a memory. |
| `get_namespace_memories(namespace: str, limit: int = 50) -> dict` | Queries all memories within a specific isolated namespace. |

---

## 4. TTL and Cleanup (`ttl.py`)

The `ttl` module ensures graph health by managing data expiration. It allows nodes to have a Time-To-Live (TTL) and provides tools for cleaning up expired data.

### `TTLManager` Class

Manages memory expiration logic and background cleanup.

| Method | Description |
| :--- | :--- |
| `set_ttl(node_id: int \| str, ttl_seconds: int) -> dict` | Sets or updates the TTL (in seconds) for a specific node. |
| `extend_ttl(node_id: int \| str, additional_seconds: int) -> dict` | Adds additional time to a node's existing TTL. |
| `refresh_ttl(node_id: int \| str) -> dict` | Resets the expiration countdown for a node by updating its `created_at` timestamp. |
| `get_expired_nodes(batch_size: int = 100) -> list` | Scans the graph for nodes that have exceeded their TTL. |
| `cleanup_expired(dry_run: bool = False, ...) -> dict` | Deletes nodes that have expired. |
| `get_ttl_stats() -> dict` | Returns statistics on how many nodes have TTLs and how many are expired. |
| `start_background_cleanup(...) -> None` | (Async) Starts a background task to periodically clean up expired memories. |
| `stop_background_cleanup() -> None` | (Async) Stops the background cleanup task. |
