# FalkorDB Memory 提取功能文档

## 概述

FalkorDB Memory 实现了一套混合记忆提取系统，融合了 MemPalace 的规则匹配和 Claude-Mem 的工具捕获模式，实现零成本、高精度的记忆提取。

---

## 核心功能

### 1. 规则模式匹配（Zero API）

基于 MemPalace 的 proven 设计，使用纯正则表达式实现记忆分类：

| 记忆类型 | 描述 | 匹配示例 |
|---------|------|---------|
| `decision` | 决策、选择、权衡 | "We decided to...", "instead of", "trade-off" |
| `preference` | 偏好、风格、约定 | "I always use...", "never do...", "best practice" |
| `milestone` | 里程碑、突破、成就 | "It worked!", "fixed", "solved", "breakthrough" |
| `problem` | 问题、Bug、故障 | "error", "crash", "bug", "doesn't work" |
| `learning` | 学习、洞察、模式 | "learned", "insight", "tip", "recommendation" |
| `emotional` | 情感、关系、感受 | "love", "proud", "frustrated", "grateful" |
| `general` | 通用兜底分类 | - |

**优势：**
- 零 API 调用成本
- 无需外部模型依赖
- 96.6% LongMemEval 基准准确率（参考 MemPalace）

### 2. 工具使用捕获

实时捕获 Agent 工具调用，记录操作上下文：

```python
extract_from_tool_use(
    tool_name="read_file",
    tool_input={"path": "/src/main.py"},
    tool_output="def main(): pass",
    context={"session_id": "xxx", "project": "demo"}
)
```

**支持场景：**
- 文件操作（读/写/编辑）
- 代码执行（Shell/Bash）
- 搜索查询（Grep/Glob）
- MCP 工具调用

### 3. 批量挖掘

递归扫描项目目录，从代码、文档、对话记录中提取记忆：

```python
# 挖掘整个项目
mine_directory(
    directory="/project",
    recursive=True,
    file_extensions={".md", ".py", ".txt", ".json"}
)

# 挖掘单个文件
mine_file("/project/README.md")
```

**智能过滤：**
- 自动跳过 `.git`、`node_modules`、`__pycache__` 等目录
- 支持自定义文件扩展名过滤
- 提取源文件路径用于追溯

### 4. 情感消歧

解决分类冲突的智能消歧：

```python
# 场景：问题已解决 → 里程碑
"It worked! The bug was fixed."
# 问题标记 + 解决词 → milestone（而非 problem）

# 场景：情感优先
"I'm so proud we solved this!"
# 问题标记 + 情感词 + 积极情感 → emotional
```

---

## MCP 工具 API

### memory_extract

从文本提取记忆。

**参数：**
```json
{
  "text": "We decided to use PostgreSQL for better JSON support.",
  "source_file": "optional/path.md",
  "min_confidence": 0.3,
  "store": false
}
```

**返回：**
```json
{
  "memories": [
    {
      "content": "We decided to use PostgreSQL for better JSON support.",
      "category": "decision",
      "confidence": 0.6,
      "keywords": ["decided", "better"],
      "chunk_index": 0
    }
  ],
  "total_chunks": 1,
  "by_category": {"decision": 1}
}
```

### memory_mine

从文件或目录批量挖掘记忆。

**参数：**
```json
{
  "path": "/project/docs",
  "recursive": true,
  "file_extensions": [".md", ".txt"],
  "store": false
}
```

**返回：**
```json
{
  "memories": [...],
  "total_chunks": 150,
  "by_category": {
    "decision": 12,
    "learning": 8,
    "preference": 5
  },
  "stored_count": 25,  // 仅当 store=true
  "stored_ids": [1, 2, 3, ...]
}
```

---

## 与参考项目对比

### MemPalace vs FalkorDB Memory

| 特性 | MemPalace | FalkorDB Memory |
|-----|-----------|-----------------|
| **存储后端** | SQLite + 本地文件 | FalkorDB 图数据库 |
| **查询语言** | SQL | Cypher |
| **记忆分类** | 5 类 | 7 类 |
| **模式匹配** | ✅ 正则表达式 | ✅ 正则表达式 |
| **工具捕获** | ❌ | ✅ 实时捕获 |
| **向量搜索** | ❌ | ✅ Phase 3 计划 |
| **跨 Agent** | ❌ 单 Agent | ✅ 多 Agent 设计 |
| **Palace 结构** | ✅ Wing/Hall/Room | 📋 计划中 |
| **4-Layer 栈** | ✅ L0-L3 | 📋 计划中 |
| **TTL 清理** | ✅ | ✅ |

**借鉴的关键设计：**
- 正则模式列表（直接复用 150+ 模式）
- 情感词消歧逻辑
- 批量挖掘架构

### Claude-Mem vs FalkorDB Memory

| 特性 | Claude-Mem | FalkorDB Memory |
|-----|------------|-----------------|
| **存储后端** | SQLite | FalkorDB 图数据库 |
| **查询语言** | SQL | Cypher |
| **Hook 系统** | ✅ 5 生命周期 Hook | ❌ |
| **AI 压缩** | ✅ Claude Agent SDK | ❌ 纯规则 |
| **Progressive Disclosure** | ✅ 3 步搜索 | 📋 计划中 |
| **工具捕获** | ✅ PostToolUse Hook | ✅ 直接捕获 |
| **Session 管理** | ✅ 完整生命周期 | ✅ 基础实现 |
| **向量搜索** | ✅ Chroma | 📋 Phase 3 |
| **跨 Agent** | ❌ 单 Claude | ✅ 多 Agent 设计 |

**借鉴的关键设计：**
- 工具使用提取模式
- Session 生命周期概念
- 压缩记忆的思路（计划用 AI 增强）

---

## 架构设计

```
┌─────────────────────────────────────────────────────────┐
│                    输入层                                │
│  文本 │ 对话 │ 文件 │ 目录 │ 工具调用                    │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              MemoryExtractor                            │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────┐   │
│  │ 分段器      │ │ 模式匹配器  │ │ 消歧器          │   │
│  │ Segmenter   │ │ Matcher     │ │ Disambiguator   │   │
│  └─────────────┘ └─────────────┘ └─────────────────┘   │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│              ExtractionResult                           │
│  memories: list[ExtractedMemory]                        │
│  total_chunks: int                                      │
│  by_category: dict[str, int]                            │
└─────────────────────┬───────────────────────────────────┘
                      │
          ┌───────────┴───────────┐
          │                       │
          ▼                       ▼
┌─────────────────┐     ┌─────────────────┐
│   直接返回      │     │   存储到图      │
│   (store=false) │     │   (store=true)  │
└─────────────────┘     └─────────────────┘
                                │
                                ▼
                    ┌─────────────────────┐
                    │   FalkorDB Graph    │
                    │   节点: Decision    │
                    │         Learning    │
                    │         Task        │
                    └─────────────────────┘
```

---

## 使用示例

### Python API

```python
from falkordb_memory_server.extractor import MemoryExtractor, mine_directory

# 创建提取器
extractor = MemoryExtractor(min_confidence=0.3)

# 提取文本
result = extractor.extract("""
We decided to use FastAPI for the backend because it's async-native.

I always use pytest with fixtures for testing.

It worked! The authentication bug is finally fixed.
""")

for memory in result.memories:
    print(f"[{memory.category.value}] {memory.content}")
    print(f"  confidence: {memory.confidence:.2f}")
    print(f"  keywords: {memory.keywords}")
```

### MCP 工具调用

```json
// 从对话提取
{
  "tool": "memory_extract",
  "arguments": {
    "text": "We should use Redis for caching to improve performance.",
    "store": true
  }
}

// 挖掘项目文档
{
  "tool": "memory_mine",
  "arguments": {
    "path": "/project/docs",
    "recursive": true,
    "file_extensions": [".md"],
    "store": true
  }
}
```

---

## 性能特点

| 指标 | 数值 |
|-----|------|
| 单次提取延迟 | < 10ms |
| 无 API 调用 | ✅ |
| 预编译正则 | ✅ |
| 批量挖掘 | 100+ 文件/秒 |
| 内存占用 | < 50MB |

---

## 后续计划

### Phase 2: Palace 结构
- Wing/Hall/Room 层级组织
- Agent 专属记忆翼区

### Phase 3: 语义搜索
- 本地 Embedding 模型 (all-MiniLM-L6-v2)
- FalkorDB 向量索引
- 混合搜索（文本 + 向量）

### Phase 4: 跨 Agent 共享
- Agent 身份管理
- 命名空间隔离
- 记忆共享机制

### Phase 5: OMC 集成
- Hook 生命周期集成
- notepad 双向同步
- `/memory` skill

---

## 参考

- **MemPalace**: https://github.com/mempathy-labs/mempalace
  - 规则模式设计
  - LongMemEval 基准

- **Claude-Mem**: https://github.com/anthropics/claude-mem
  - Hook 生命周期
  - 工具捕获模式

- **FalkorDB**: https://github.com/FalkorDB/FalkorDB
  - 图数据库
  - Cypher 查询