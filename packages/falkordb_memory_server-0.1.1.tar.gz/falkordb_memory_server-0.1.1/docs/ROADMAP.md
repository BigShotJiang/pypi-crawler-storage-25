# FalkorDB Memory - Product Roadmap

**Document Version**: 1.0.0
**Last Updated**: 2026-04-10
**Status**: Active Development

---

## Overview

FalkorDB Memory is a **graph-native memory system** designed for software development. It provides persistent memory across AI agents (Claude, Gemini, Codex) with native graph queries, semantic search, and zero-cost extraction.

### Core Value Proposition

| Feature | FalkorDB Memory | MemPalace | claude-mem |
|---------|-----------------|-----------|------------|
| Storage | **One graph DB** | ChromaDB + SQLite | SQLite + ChromaDB |
| Graph queries | **Native Cypher** | Simulated | None |
| Vector search | **Built-in** | ChromaDB | ChromaDB |
| Relationships | **Native edges** | Logic layer | None |
| Extraction cost | **$0** (regex) | $0 (regex) | API calls |

---

## Release Timeline

```
2026-04 ────────► 2026-Q2 ────────► 2026-Q3 ────────► 2026-Q4 ────────► 2027
   │                │                │                │                │
   v1.0-1.1        v1.2             v1.3             v1.4-1.5         v2.0
   Foundation      Developer Core   Project Knowledge Dev Workflow     Enterprise
   ✅ Released     ✅ Released      ✅ Released      ✅ Released      Future
```

---

## Version Details

### v1.0 - Foundation ✅ RELEASED

**Release Date**: 2026-04-09
**Theme**: Core graph-based memory infrastructure

**Features:**

| Module | Feature | Status |
|--------|---------|--------|
| **Core** | MCP Server (stdio transport) | ✅ |
| | FalkorDB integration | ✅ |
| | Graph operations (CRUD) | ✅ |
| **Nodes** | Session, Agent, Decision, Learning, Code, Concept | ✅ |
| **Edges** | STARTED_BY, LED_TO, DERIVED_FROM, KNOWS, RELATED_TO | ✅ |
| **Memory** | remember / recall / forget | ✅ |
| **Search** | Cypher native queries | ✅ |
| **Config** | Environment variables, TTL, embeddings | ✅ |

**Technical Specs:**
- Python 3.10+
- FalkorDB 4.0+ (Redis-based)
- MCP Protocol 1.0+
- Pydantic 2.0+ for validation

**Key Deliverables:**
- 15 MCP tools for memory operations
- Graph schema with constraints and indexes
- Session lifecycle management

---

### v1.1 - Memory Extraction ✅ RELEASED

**Release Date**: 2026-04-09
**Theme**: Zero-cost memory extraction and cross-agent hooks

**Features:**

| Module | Feature | Status |
|--------|---------|--------|
| **Extraction** | Rule-based pattern matching (7 categories) | ✅ |
| | 96.6% benchmark accuracy (MemPalace patterns) | ✅ |
| | Tool usage capture | ✅ |
| | Batch file/directory mining | ✅ |
| **Hooks** | Claude Code integration (PreToolUse, PostToolUse) | ✅ |
| | Gemini CLI integration (BeforeTool, AfterTool, SessionStart) | ✅ |
| | Unified event adapter | ✅ |
| | Graceful degradation | ✅ |
| **Search** | Semantic vector search | ✅ |
| | Local embeddings (sentence-transformers) | ✅ |
| | Hybrid search (vector + text) | ✅ |

**Memory Categories:**

| Category | Description | Pattern Examples |
|----------|-------------|------------------|
| `decision` | Choices, trade-offs | "We decided...", "instead of" |
| `preference` | Style, conventions | "I always use...", "never" |
| `milestone` | Achievements | "It worked!", "fixed", "solved" |
| `problem` | Bugs, issues | "error", "crash", "bug" |
| `learning` | Insights, tips | "learned", "insight", "tip" |
| `emotional` | Feelings | "love", "proud", "frustrated" |
| `general` | Default | - |

**Embedding Models:**

| Model | Dimensions | Size | Speed | Accuracy |
|-------|------------|------|-------|----------|
| `all-MiniLM-L6-v2` (default) | 384 | ~90MB | Fast | Good |
| `all-mpnet-base-v2` | 768 | ~420MB | Slower | Better |

---

### v1.2 - Developer Core ✅ RELEASED

**Theme**: Solve everyday development pain points

**Problem Statement:**

| Pain Point | Current State | Solution |
|------------|---------------|----------|
| "Why this design?" | Decisions scattered in chats | Decision chain traceability |
| "Seen this bug?" | Repeated mistakes | Bug pattern registry |
| "How to use this API?" | Re-learning every time | Code pattern memory |
| Sensitive data leaked | No privacy control | `<private>` tag exclusion |

**Features:**

| Feature | Description | Priority | Effort |
|---------|-------------|----------|--------|
| **Decision Chain Query** | Trace architecture decisions via graph traversal | P0 | M |
| **Bug Pattern Registry** | Remember solved problems with solutions | P0 | M |
| **Code Pattern Memory** | API usage, best practices, code snippets | P0 | M |
| **Privacy Control** | `<private>` tags exclude from storage | P0 | S |
| **Wake-up Command** | Load project-critical facts (~170 tokens) | P1 | S |
| **Incremental Mining** | Track file changes (hash/mtime), skip unchanged, avoid duplicates | P1 | M |

**New Node Types:**

```cypher
// Decision chain
(:Decision {topic: "database", rationale: "PostgreSQL for JSON support"})
  -[:LED_TO]->(:Decision {topic: "ORM", rationale: "SQLAlchemy for flexibility"})

// Bug pattern
(:Problem {error: "Connection timeout", category: "network"})
  -[:SOLVED_BY]->(:Solution {fix: "Add connection pool", code: "..."})

// Code pattern
(:Code {name: "auth-middleware", language: "python"})
  -[:IMPLEMENTS]->(:Pattern {type: "jwt-validation"})
```

**New Edge Types:**
- `SOLVED_BY` — Problem → Solution
- `IMPLEMENTS` — Code → Pattern
- `SUPERSEDES` — New decision replaces old

**Acceptance Criteria:**
- [x] Query: `"Why did we choose PostgreSQL?"` returns decision chain
- [x] Query: `"Seen connection timeout before?"` returns related problems
- [x] `<private>` content never stored in graph
- [x] Wake-up loads L0+L1 facts in < 200 tokens
- [x] Incremental mining skips unchanged files (hash/mtime check), no duplicate memories stored

---

### v1.3 - Project Knowledge ✅ RELEASED

**Theme**: Project-level context management

**Problem Statement:**

| Pain Point | Current State | Solution |
|------------|---------------|----------|
| "What's the project convention?" | CLAUDE.md overflow | Convention registry |
| "Why this dependency?" | Lost in PR comments | Dependency decision memory |
| Context bloat | Too much loaded | Smart project context |

**Features:**

| Feature | Description | Priority | Effort |
|---------|-------------|----------|--------|
| **Project Context Auto-Load** | Conventions, configs, dependencies | P0 | M |
| **Dependency Decision Memory** | Why we chose X over Y | P1 | M |
| **Convention Registry** | Coding standards, naming patterns | P1 | S |
| **Knowledge Graph** | Temporal entity relationships | P1 | L |

**New Node Types:**

```cypher
// Project structure
(:Project {name: "myapp", path: "/home/user/myapp"})
  -[:HAS_CONVENTION]->(:Convention {type: "naming", pattern: "snake_case"})
  -[:DEPENDS_ON]->(:Dependency {name: "FastAPI", version: "0.100.0", reason: "async support"})

// Knowledge graph (temporal)
(:Entity {name: "auth-migration"})
  -[:ASSIGNED_TO {valid_from: "2026-01-15", valid_to: null}]->(:Person {name: "Maya"})
```

**New Edge Types:**
- `HAS_CONVENTION` — Project → Convention
- `DEPENDS_ON` — Project → Dependency
- `ASSIGNED_TO` — Entity → Person (with temporal properties)

**Knowledge Graph Capabilities:**
- Temporal validity windows (valid_from, valid_to)
- Fact invalidation queries
- Timeline reconstruction
- Entity relationship queries

**Acceptance Criteria:**
- [x] Project context auto-loads on session start
- [x] Query: `"Why FastAPI?"` returns decision rationale
- [x] Knowledge graph supports time-travel queries
- [x] Entity assignments show current vs historical

---

### v1.4 - Dev Workflow Integration ✅ RELEASED

**Theme**: Integrate into development process

**Problem Statement:**

| Pain Point | Current State | Solution |
|------------|---------------|----------|
| "Why this refactor?" | Git diff shows what, not why | Refactor trail |
| "What edge cases?" | Scattered in test files | Test memory |
| "API experience?" | Re-learned each time | API usage memory |

**Features:**

| Feature | Description | Priority | Effort |
|---------|-------------|----------|--------|
| **Refactor Trail** | Track refactoring reasons and impact | P0 | M |
| **Test Memory** | Test strategies, edge cases, coverage | P1 | M |
| **API Usage Memory** | Third-party API experiences | P1 | M |
| **Code Review Memory** | Review feedback and improvements | P2 | M |

**New Node Types:**

```cypher
// Refactor trail
(:Refactor {reason: "Improve performance", scope: "auth-module", date: "2026-04-10"})
  -[:CHANGED]->(:File {path: "auth/service.py"})
  -[:BEFORE]->(:CodeSnapshot {content: "..."})
  -[:AFTER]->(:CodeSnapshot {content: "..."})

// Test memory
(:Test {name: "test_auth_timeout", type: "integration"})
  -[:COVERS]->(:EdgeCase {scenario: "slow network", expected: "retry"})

// API memory
(:API {name: "Stripe", endpoint: "/charges"})
  -[:CALLED_WITH]->(:Params {payload: "...", response_time: "120ms"})
  -[:ERROR_ENCOUNTERED]->(:APIError {code: "rate_limit", solution: "exponential backoff"})
```

**New Edge Types:**
- `CHANGED` — Refactor → File
- `COVERS` — Test → EdgeCase
- `CALLED_WITH` — API → Params
- `ERROR_ENCOUNTERED` — API → APIError

**Acceptance Criteria:**
- [x] Refactor query returns reason + affected files
- [x] Test query returns edge cases and strategies
- [x] API query returns usage patterns and errors encountered

---

### v1.5 - Enhanced Experience ✅ RELEASED

**Theme**: Better user interaction and long sessions

**Features:**

| Feature | Description | Priority | Effort |
|---------|-------------|----------|--------|
| **Web Viewer UI** | Graph visualization at `localhost:37777` | P0 | L |
| **Endless Mode** | Biomimetic memory for long sessions (L0-L3) | P0 | L |
| **Progressive Disclosure** | 3-layer search workflow (save tokens) | P1 | M |
| **Conversation Mining** | Multi-format (Claude, ChatGPT, Slack) | P2 | M |

---

### v1.6 - Proactive Context ✅ RELEASED

**Theme**: Context streaming and architectural alignment

**Features:**

| Feature | Description | Priority | Effort |
|---------|-------------|----------|--------|
| **Proactive Insights** | Context streaming of historical architecture decisions before agent execution (intercepts `USER_PROMPT`). | P0 | M |
| **Async State Rendering** | Fallback for agents via localized workspace files (`.omg/state/active-architecture.md`). | P0 | S |
| **Session Deduplication** | Prevents context pollution via strict 1-hour cache isolation. | P1 | S |

---

### v1.7 - Privacy & Security ✅ RELEASED

**Theme**: Data protection and PII redaction

**Features:**

| Feature | Description | Priority | Effort |
|---------|-------------|----------|--------|
| **PIIRedactor** | Automatic redaction of AWS Keys, JWTs, Passwords, Emails, and Public IPs before extraction. | P0 | S |
| **Local Bypass** | Whitelist for local development IPs and dummy variable values to prevent false positives. | P1 | S |

**Endless Mode Architecture:**

```
┌─────────────────────────────────────────────┐
│  L0 Working Memory (Current Context)        │ ← Always in window
│  - Active decisions, current task           │
│  - Recent 5-10 exchanges                    │
├─────────────────────────────────────────────┤
│  L1 Episodic Memory (Rolling Summary)       │ ← Auto-compress
│  - Last 50 exchanges → ~500 tokens          │
│  - Decay: older = less detail               │
├─────────────────────────────────────────────┤
│  L2 Semantic Memory (Extracted Facts)       │ ← Persistent
│  - "User prefers PostgreSQL"                │
│  - "Auth uses JWT with 7d expiry"           │
├─────────────────────────────────────────────┤
│  L3 Archival Memory (Raw Storage)           │ ← Search on demand
│  - Full conversation history                │
│  - Semantic search via vector index         │
└─────────────────────────────────────────────┘
```

**Progressive Disclosure Workflow:**

```
1. search(query) → compact index with IDs (~50-100 tokens/result)
2. timeline(around_id) → chronological context
3. get_observations(ids) → full details ONLY for filtered IDs

~10x token savings by filtering before fetching
```

**Acceptance Criteria:**
- [x] Web UI shows graph visualization with filters
- [x] Endless Mode supports 500+ exchange sessions
- [x] Progressive Disclosure reduces token usage by 80%+
- [x] Conversation imports from ChatGPT/Slack formats

---

### v2.0 - Enterprise 🔲 FUTURE (2027)

**Theme**: Team collaboration and advanced analytics

**Features:**

| Feature | Description | Priority | Effort |
|---------|-------------|----------|--------|
| **AAAK Dialect** | Compression for repeated entities at scale | P1 | L |
| **Advanced Graph Analytics** | Influence analysis, pattern detection | P1 | L |
| **Multi-tenant Support** | Isolated memory per team/project | P0 | L |
| **Team Memory Sharing** | Cross-team knowledge sync | P1 | M |

**Advanced Graph Analytics:**

| Capability | Use Case | Cypher Example |
|------------|----------|----------------|
| Influence Analysis | Find key decisions | `MATCH (d:Decision)-[:LED_TO*]->(c) RETURN d, count(c)` |
| Pattern Detection | Identify repeated problems | `MATCH (p:Problem)-[:SOLVED_BY]->(s) RETURN p.category, count(p)` |
| Community Detection | Find knowledge domains | `CALL algo.louvain(...)` |
| Centrality Analysis | Find core concepts | `CALL algo.pageRank(...)` |

**Multi-tenant Architecture:**

```
┌─────────────────────────────────────────┐
│              Load Balancer              │
└─────────────────────────────────────────┘
                    │
    ┌───────────────┼───────────────┐
    ▼               ▼               ▼
┌─────────┐   ┌─────────┐   ┌─────────┐
│ Team A  │   │ Team B  │   │ Team C  │
│ Memory  │   │ Memory  │   │ Memory  │
└────┬────┘   └────┬────┘   └────┬────┘
     │             │             │
     └─────────────┼─────────────┘
                   ▼
        ┌────────────────────┐
        │  FalkorDB Cluster  │
        └────────────────────┘
```

**Acceptance Criteria:**
- [x] AAAK achieves 20%+ token reduction at scale
- [x] Graph analytics available via MCP tools
- [x] Multi-tenant isolation verified by security audit
- [x] Team sharing with permission controls

---

## Technical Debt & Maintenance

### Ongoing Improvements

| Area | Current Status | Target |
|------|----------------|--------|
| Test Coverage | ~60% | 80%+ |
| Documentation | Partial | Complete API docs |
| Performance | P99 < 200ms | P99 < 100ms |
| Error Handling | Basic | Comprehensive |

### Deprecation Policy

- Features deprecated for 2 major versions before removal
- Migration guides provided for all breaking changes
- Semantic versioning followed strictly

---

## Success Metrics

### v1.2 Success Criteria

| Metric | Target |
|--------|--------|
| Decision chain query accuracy | > 90% |
| Bug pattern recall | > 85% |
| Privacy tag effectiveness | 100% (no leaks) |
| Wake-up command latency | < 500ms |

### v1.3 Success Criteria

| Metric | Target |
|--------|--------|
| Project context relevance | > 85% |
| Dependency query accuracy | > 90% |
| Knowledge graph query latency | < 200ms |

### v1.5 Success Criteria

| Metric | Target |
|--------|--------|
| Session length without context loss | 500+ exchanges |
| Token savings (Progressive Disclosure) | 80%+ |
| Web UI adoption | 50% of users |

---

## Risk Assessment

| Risk | Impact | Probability | Mitigation |
|------|--------|-------------|------------|
| FalkorDB API changes | High | Low | Version pinning, abstraction layer |
| Embedding model deprecation | Medium | Low | Model abstraction, multiple model support |
| Performance degradation at scale | High | Medium | Indexing strategy, caching |
| Cross-agent compatibility issues | Medium | Medium | Comprehensive testing, version detection |

---

## References

- [README.md](../README.md) - Project overview
- [PRODUCT_DESIGN.md](./PRODUCT_DESIGN.md) - Detailed design specification
- [EXTRACTION.md](./EXTRACTION.md) - Memory extraction system
- [HOOKS.md](./HOOKS.md) - Hook system documentation

---

**Document Owner**: OMC Team
**Review Cycle**: Quarterly
**Next Review**: 2026-Q3-Q3