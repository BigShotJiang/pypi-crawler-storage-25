import re
import os
import json
from pathlib import Path
from datetime import datetime, timezone, timedelta

def get_proactive_insights(graph_ops, prompt: str, cwd: str, session_id: str) -> list[str]:
    """Retrieve proactive insights based on user prompt, deduplicated per session."""
    if not graph_ops or not prompt:
        return []
        
    # Simple extraction of potential file names or core keywords
    words = re.findall(r'[a-zA-Z0-9_\-\./]+', prompt)
    keywords = [w for w in words if len(w) > 3]
    
    if not keywords:
        return []
        
    # Limit to top 5 keywords
    keywords = keywords[:5]
    
    # Query graph
    # We want Decision or Convention related to these keywords or cwd
    cypher = """
    MATCH (n)
    WHERE (n:Decision OR n:Convention OR n:Learning)
      AND (n.source_file CONTAINS $cwd OR n.context CONTAINS $cwd)
      AND any(kw IN $keywords WHERE n.content CONTAINS kw OR n.source_file CONTAINS kw)
    RETURN id(n) as node_id, n.category as category, n.content as content, n.confidence as confidence
    ORDER BY n.confidence DESC
    LIMIT 10
    """
    try:
        result = graph_ops.safe_query(cypher, params={"cwd": cwd, "keywords": keywords}, read_only=True)
        rows = result.get("result_set", [])
    except Exception:
        return []
        
    # Deduplicate via local state file
    cache_dir = Path(".omg/state")
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / f"insights_cache_{session_id}.json"
    
    pushed = {}
    if cache_file.exists():
        try:
            with open(cache_file, "r") as f:
                pushed = json.load(f)
        except Exception:
            pass
            
    now = datetime.now(timezone.utc)
    insights = []
    new_pushed = False
    
    for row in rows:
        node_id, category, content, confidence = row
        nid_str = str(node_id)
        
        # Check if pushed in last hour
        if nid_str in pushed:
            last_push = datetime.fromisoformat(pushed[nid_str])
            if now - last_push < timedelta(hours=1):
                continue
                
        insights.append(f"[{category.upper()}] {content}")
        pushed[nid_str] = now.isoformat()
        new_pushed = True
        
        if len(insights) >= 3:
            break
            
    if new_pushed:
        try:
            with open(cache_file, "w") as f:
                json.dump(pushed, f)
        except Exception:
            pass
            
    return insights

def update_active_architecture(insights: list[str]):
    """Update async state file."""
    if not insights:
        return
        
    try:
        cache_dir = Path(".omg/state")
        cache_dir.mkdir(parents=True, exist_ok=True)
        arch_file = cache_dir / "active-architecture.md"
        
        content = "# Active Architecture Insights\n\n"
        content += "Automatically pushed context based on recent activity:\n\n"
        for i in insights:
            content += f"- {i}\n"
            
        with open(arch_file, "w") as f:
            f.write(content)
    except Exception:
        pass
