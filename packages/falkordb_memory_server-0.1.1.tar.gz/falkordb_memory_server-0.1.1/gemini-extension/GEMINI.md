# FalkorDB Memory Extension

Cross-agent memory system that persists knowledge across sessions using a graph database.

## Features

- **Memory Extraction**: Automatically extracts decisions, learnings, preferences from conversations
- **Semantic Search**: Find relevant memories using natural language queries
- **Cross-Agent Sharing**: Share knowledge between Claude, Gemini, and other AI agents
- **Graph Storage**: Memories stored as nodes with relationships in FalkorDB

## Available Tools

| Tool | Description |
|------|-------------|
| `memory_remember` | Store a new memory |
| `memory_recall` | Search and retrieve memories |
| `memory_extract` | Extract memories from text |
| `memory_mine` | Mine memories from files |
| `memory_associate` | Create relationships between memories |
| `memory_semantic_search` | Vector similarity search |
| `memory_stats` | View memory statistics |

## Memory Categories

- **decision**: Choices made, trade-offs
- **preference**: Coding style, conventions
- **milestone**: Achievements, breakthroughs
- **problem**: Bugs, issues, failures
- **learning**: Insights, patterns, tips
- **emotional**: Feelings, reactions

## Usage Examples

```
# Store a memory
"Remember that we decided to use PostgreSQL for the database"

# Recall memories
"What do you remember about authentication?"

# Extract from conversation
"Extract the key decisions from this discussion"
```

## Configuration

The extension uses these environment variables:

- `FALKORDB_URL`: Redis connection URL (default: redis://localhost:6379)
- `GRAPH_NAME`: Graph name for memory storage (default: agent_memory)
- `EXTRACTION_MODE`: The extraction context (`programming`, `office`, `life`), defaults to `programming` but is automatically detected as `office` for OpenClaw agents.

## Requirements

- Python 3.10+
- FalkorDB running locally or accessible via URL
- Required Python packages: falkordb, mcp, pydantic, sentence-transformers