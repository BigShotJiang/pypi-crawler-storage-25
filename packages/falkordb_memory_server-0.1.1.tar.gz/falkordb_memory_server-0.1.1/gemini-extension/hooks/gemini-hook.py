#!/usr/bin/env python3
"""
Gemini CLI Extension Hook for FalkorDB Memory.

This hook is bundled with the Gemini CLI extension and delegates to the
main hook adapter for memory capture and context injection.
"""

import json
import os
import sys
import traceback
from pathlib import Path

# Add the main src directory to path
# The extension is installed in ~/.gemini/extensions/falkordb-memory/
# We need to find the actual falkordb-memory installation
# If running via Gemini CLI, the extension path is passed in settings or can be derived.
extension_dir = Path(__file__).parent.parent

# Search for the src directory in the current project or installed package
possible_paths = [
    extension_dir / "src",  # If installed as extension
    extension_dir.parent / "src",  # Development: gemini-extension/../src
]

# Check environment for explicit SRC path
if "FALKORDB_MEMORY_SRC" in os.environ:
    possible_paths.insert(0, Path(os.environ["FALKORDB_MEMORY_SRC"]))

found_src = False
for src_path in possible_paths:
    if src_path.exists():
        sys.path.insert(0, str(src_path))
        found_src = True
        break

try:
    from falkordb_memory_server.hook_adapter import (
        HookAdapter,
        HookSource,
        MemoryHookHandler,
    )
except ImportError:
    # If import fails, log to stderr and just allow the operation
    if found_src:
        print(
            f"Error: Found src at {src_path} but could not import falkordb_memory_server",
            file=sys.stderr,
        )
    else:
        print(
            f"Error: Could not find falkordb-memory src directory. Tried: {[str(p) for p in possible_paths]}",
            file=sys.stderr,
        )

    print(json.dumps({"decision": "allow"}))
    sys.exit(0)


def main():
    """Main hook entry point."""
    # Read input from stdin
    try:
        raw_input = json.load(sys.stdin)
    except json.JSONDecodeError as e:
        print(f"Error: Failed to decode JSON input: {e}", file=sys.stderr)
        print(json.dumps({"decision": "allow"}))
        sys.exit(0)

    # Create adapter for Gemini CLI
    adapter = HookAdapter(source_cli=HookSource.GEMINI)
    handler = MemoryHookHandler()

    # Normalize and process
    try:
        unified_input = adapter.normalize_input(raw_input)
        result = handler.handle(unified_input)
        output = adapter.normalize_output(result)

        print(json.dumps(output))
        sys.exit(0)

    except Exception as e:
        # Log error to stderr and graceful degradation on any error
        print(f"Error in gemini-hook.py: {e}", file=sys.stderr)
        traceback.print_exc(file=sys.stderr)
        print(json.dumps({"decision": "allow"}))
        sys.exit(0)


if __name__ == "__main__":
    main()
