# FalkorDB Memory - Gemini CLI Extension

Cross-agent memory system for Gemini CLI with graph storage and semantic search.

## Installation

```bash
gemini extensions install https://github.com/goodideal/falkordb-memory
```

Or install from local directory:

```bash
cd falkordb-memory
gemini extensions link ./gemini-extension
```

## Requirements

1. **FalkorDB** running locally:
   ```bash
   docker run -d -p 6379:6379 falkordb/falkordb:latest
   ```

2. **Python packages**:
   ```bash
   # Create and activate a virtual environment
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate

   # Install dependencies
   pip install falkordb mcp pydantic sentence-transformers
   ```

## Features

- **Automatic Memory Extraction**: Captures decisions, learnings, and preferences from conversations
- **Session Context**: Injects relevant memories at session start
- **Tool Capture**: Records tool usage for future reference
- **Semantic Search**: Find memories by meaning, not just keywords

## Configuration

Set environment variables or let the extension prompt you:

```bash
export FALKORDB_URL=redis://localhost:6379
export GRAPH_NAME=agent_memory
export EXTRACTION_MODE=programming # Options: programming, office, life
```

## Usage

After installation, the extension automatically:

1. **On Session Start**: Loads relevant memories as context
2. **On Tool Use**: Extracts and stores memory-worthy content
3. **On Session End**: Updates session state

### Manual Memory Operations

Use the MCP tools through Gemini:

```
"Store that we decided to use PostgreSQL for the database"
"What do you remember about authentication?"
"Extract key decisions from our conversation"
```

## Memory Categories

| Category | Description |
|----------|-------------|
| `decision` | Choices made, trade-offs |
| `preference` | Coding style, conventions |
| `milestone` | Achievements, breakthroughs |
| `problem` | Bugs, issues, failures |
| `learning` | Insights, patterns |
| `emotional` | Feelings, reactions |

## Files

```
gemini-extension/
├── gemini-extension.json  # Extension manifest
├── GEMINI.md              # Context instructions
├── hooks/
│   └── gemini-hook.py     # Hook handler
└── README.md              # This file
```

## Uninstall

```bash
gemini extensions uninstall falkordb-memory
```