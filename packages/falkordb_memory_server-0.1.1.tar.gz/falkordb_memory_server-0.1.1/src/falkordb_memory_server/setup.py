import os
from pathlib import Path


def interactive_setup() -> None:
    """Interactive CLI wizard to configure default ExtractionMode."""
    print("\n" + "=" * 50)
    print("🔮 Welcome to FalkorDB Memory Server Setup")
    print("=" * 50 + "\n")

    print("Please select your primary use case for this environment:")
    print(
        "  1. 💻 Programming (Default) - Optimized for software architecture, code snippets & technical decisions."
    )
    print("  2. 🏢 Office - Optimized for emails, scheduling, meeting summaries & daily tasks.")
    print("  3. ☕ Life - Optimized for personal reminders, home tasks & finances.")

    choice = input("\nEnter choice [1/2/3]: ").strip()

    mode_map = {"1": "PROGRAMMING", "2": "OFFICE", "3": "LIFE"}

    mode = mode_map.get(choice, "PROGRAMMING")

    # Write to local .env in current directory or user home
    # Check if we are in a project directory with .env
    env_path = Path(".env")
    if not env_path.exists():
        # Try to put it in user home if we are not in a typical project
        user_dir = Path(os.path.expanduser("~")) / ".falkordb_memory"
        user_dir.mkdir(exist_ok=True)
        env_path = user_dir / ".env"
        # We also need to update python-dotenv to load from here if we do this,
        # but for simplicity, let's just write to .env in cwd.
        env_path = Path(".env")

    env_content = ""
    if env_path.exists():
        env_content = env_path.read_text()

    lines = env_content.splitlines()
    new_lines = []
    found = False
    for line in lines:
        if line.startswith("EXTRACTION_MODE="):
            new_lines.append(f"EXTRACTION_MODE={mode}")
            found = True
        else:
            new_lines.append(line)

    if not found:
        new_lines.append(f"EXTRACTION_MODE={mode}")

    env_path.write_text("\n".join(new_lines) + "\n")

    print(f"\n✅ Successfully set ExtractionMode to {mode}")
    print(f"📄 Saved to {env_path.absolute()}")
    print("\nYou can now start the server or connect it to your Agent.")


if __name__ == "__main__":
    interactive_setup()
