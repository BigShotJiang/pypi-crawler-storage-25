"""High-level memory primitives for agent memory system."""

import json
import uuid
from datetime import datetime, timezone
from typing import Any

from falkordb_memory_server.config import get_settings
from falkordb_memory_server.graph_ops import GraphOperations, get_graph_ops
from falkordb_memory_server.schema import (
    MemoryType,
    NodeLabel,
    RelationType,
)
from falkordb_memory_server.semantic_tools import get_semantic_engine


class MemoryManager:
    """High-level memory operations manager."""

    def __init__(self, ops: GraphOperations | None = None) -> None:
        """Initialize memory manager."""
        self.ops = ops or get_graph_ops()
        self.settings = get_settings()

    def remember(
        self,
        memory_type: MemoryType | str,
        content: dict[str, Any],
        context: dict[str, Any] | None = None,
        ttl: int | None = None,
        generate_embedding: bool = True,
        tier: int | None = None,
    ) -> dict[str, Any]:
        """
        Store a memory with automatic categorization and temporal validity.

        Args:
            memory_type: Type of memory (learning, decision, code, concept, task)
            content: Memory content (type-specific)
            context: Session/project context
            ttl: Time-to-live in seconds
            generate_embedding: Whether to generate embedding (Phase 3)
            tier: Memory tier (0=L0, 1=L1, 2=L2, 3=L3)

        Returns:
            Created memory node information
        """
        # Normalize memory type
        if isinstance(memory_type, str):
            memory_type = MemoryType(memory_type.lower())

        # Generate unique ID
        memory_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()

        # Build properties
        properties = content.copy()
        properties["id"] = memory_id
        if "created_at" not in properties:
            properties["created_at"] = now

        # Set tier (default to L1 if not provided)
        if tier is not None:
            properties["tier"] = int(tier)
        elif "tier" not in properties:
            properties["tier"] = 1  # Default to Session (L1)

        # Temporal validity
        if "valid_from" not in properties:
            properties["valid_from"] = properties["created_at"]
        if "valid_to" not in properties:
            properties["valid_to"] = None

        # Apply TTL
        if ttl is None:
            ttl = self.settings.default_ttl
        if ttl:
            properties["ttl"] = ttl

        # Merge context
        if context:
            properties["context"] = json.dumps(context)

        # Map to node label
        type_to_label = {
            MemoryType.LEARNING: NodeLabel.LEARNING,
            MemoryType.DECISION: NodeLabel.DECISION,
            MemoryType.CODE: NodeLabel.CODE,
            MemoryType.CONCEPT: NodeLabel.CONCEPT,
            MemoryType.TASK: NodeLabel.TASK,
            MemoryType.PROBLEM: NodeLabel.PROBLEM,
            MemoryType.SOLUTION: NodeLabel.SOLUTION,
            MemoryType.PATTERN: NodeLabel.PATTERN,
            MemoryType.DEPENDENCY: NodeLabel.DEPENDENCY,
            MemoryType.CONVENTION: NodeLabel.CONVENTION,
            MemoryType.REFACTOR: NodeLabel.REFACTOR,
            MemoryType.TEST: NodeLabel.TEST,
            MemoryType.API: NodeLabel.API,
            MemoryType.REVIEW: NodeLabel.REVIEW,
        }
        label = type_to_label.get(memory_type, NodeLabel.LEARNING)

        # Type-specific validation and enrichment
        properties = self._enrich_properties(memory_type, properties)

        # Automatic invalidation of outdated facts
        self._auto_invalidate(label, properties)

        # Create node
        result = self.ops.create_node(label, properties, return_node=True)
        result["memory_type"] = memory_type.value
        result["memory_id"] = memory_id

        return result

    def invalidate_memory(
        self,
        memory_id: str | int,
        invalidated_at: str | None = None,
    ) -> bool:
        """
        Mark a memory as no longer valid.

        Args:
            memory_id: ID of the memory node
            invalidated_at: Timestamp to set as valid_to (default: now)

        Returns:
            Success status
        """
        if invalidated_at is None:
            invalidated_at = datetime.now(timezone.utc).isoformat()

        # Handle both internal ID (int) and property id (str)
        if isinstance(memory_id, int):
            cypher = "MATCH (n) WHERE id(n) = $id SET n.valid_to = $at RETURN id(n)"
            params = {"id": memory_id, "at": invalidated_at}
        else:
            cypher = "MATCH (n) WHERE n.id = $id SET n.valid_to = $at RETURN id(n)"
            params = {"id": memory_id, "at": invalidated_at}

        result = self.ops.query(cypher, params)
        return len(result.get("result_set", [])) > 0

    def _auto_invalidate(self, label: NodeLabel, properties: dict[str, Any]) -> None:
        """Automatically invalidate previous versions of the same fact."""
        now = datetime.now(timezone.utc).isoformat()

        if label == NodeLabel.CONVENTION:
            # Invalidate conventions with same name and type
            name = properties.get("name")
            type_val = properties.get("type")
            if name and type_val:
                cypher = """
                MATCH (c:Convention)
                WHERE c.name = $name AND c.type = $type AND c.valid_to IS NULL
                SET c.valid_to = $now
                """
                self.ops.query(cypher, {"name": name, "type": type_val, "now": now})

        elif label == NodeLabel.DEPENDENCY:
            # Invalidate dependencies with same name
            name = properties.get("name")
            if name:
                cypher = """
                MATCH (d:Dependency)
                WHERE d.name = $name AND d.valid_to IS NULL
                SET d.valid_to = $now
                """
                self.ops.query(cypher, {"name": name, "now": now})

        elif label == NodeLabel.TASK:
            # Invalidate tasks with same title (maybe too aggressive?)
            # Usually tasks are moved to 'completed' status, but this is another way.
            pass

    def recall(
        self,
        query_type: str,
        query: str,
        filters: dict[str, Any] | None = None,
        limit: int = 10,
        include_context: bool = True,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """
        Retrieve memories matching criteria.

        Args:
            query_type: Query type (semantic, text, cypher, traversal)
            query: Query string or Cypher
            filters: Property filters
            limit: Maximum results
            include_context: Include related nodes
            include_invalid: Include facts marked as invalid (valid_to is set)

        Returns:
            Query results with memories
        """
        filters = filters or {}

        if query_type == "cypher":
            # Direct Cypher query - user is responsible for temporal filtering
            return self.ops.query(query, filters, read_only=True)

        elif query_type == "semantic":
            # Delegate to semantic engine
            return get_semantic_engine().recall(
                query=query,
                query_type="semantic",
                filters=filters,
                limit=limit,
                include_invalid=include_invalid,
            )

        elif query_type == "text":
            # Full-text search
            return self._text_search(query, filters, limit, include_invalid)

        elif query_type == "traversal":
            # Graph traversal from a starting point
            return self._traversal_search(query, filters, limit, include_invalid)

        else:
            # Default: basic pattern matching
            return self._pattern_search(query, filters, limit, include_context, include_invalid)

    def associate(
        self,
        from_id: int | str,
        relation: RelationType | str,
        to_id: int | str,
        properties: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Create a relationship between two memories.

        Args:
            from_id: Source node ID
            relation: Relationship type
            to_id: Target node ID
            properties: Edge properties

        Returns:
            Created edge information
        """
        return self.ops.create_edge(from_id, relation, to_id, properties)

    def forget(
        self,
        ref: dict[str, Any],
        cascade: bool = False,
    ) -> dict[str, Any]:
        """
        Remove memories from the graph.

        Args:
            ref: Reference to what to forget (id, query, or older_than_seconds)
            cascade: Remove connected nodes

        Returns:
            Deletion result
        """
        if "id" in ref:
            return self.ops.delete_nodes([ref["id"]], cascade)

        elif "query" in ref:
            # Find and delete by query
            result = self.ops.query(ref["query"], read_only=True)
            node_ids = [row[0] for row in result.get("result_set", [])]
            return self.ops.delete_nodes(node_ids, cascade)

        elif "older_than_seconds" in ref:
            # Delete by TTL
            return self._delete_expired(ref["older_than_seconds"], cascade)

        else:
            return {"error": "Invalid reference. Provide id, query, or older_than_seconds"}

    def get_memory_chain(
        self,
        memory_id: int | str,
        direction: str = "both",
        max_depth: int = 3,
    ) -> dict[str, Any]:
        """
        Get the chain of memories related to a specific memory.

        Args:
            memory_id: Starting memory ID
            direction: Direction to traverse (in, out, both)
            max_depth: Maximum traversal depth

        Returns:
            Related memories chain
        """
        if direction == "out":
            pattern = f"-[r*1..{max_depth}]->"
        elif direction == "in":
            pattern = f"<-[r*1..{max_depth}]-"
        else:
            pattern = f"-[r*1..{max_depth}]-"

        cypher = f"""
        MATCH path = (start)-{pattern}(related)
        WHERE id(start) = {int(memory_id)}
        RETURN nodes(path) as nodes, relationships(path) as edges
        LIMIT 50
        """

        return self.ops.query(cypher, read_only=True)

    def get_decision_chain(
        self,
        start_node_id: int | str | None = None,
        max_depth: int = 5,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """
        Retrieve decision chains (MATCH (d:Decision)-[:LED_TO*]->(c)).

        Args:
            start_node_id: Optional starting node ID (Decision label)
            max_depth: Maximum traversal depth
            include_invalid: Include invalid decisions

        Returns:
            Decision chains results
        """
        where_clauses = []
        params = {}

        if start_node_id:
            where_clauses.append("id(d) = $start_id")
            params["start_id"] = int(start_node_id)

        if not include_invalid:
            where_clauses.append("d.valid_to IS NULL")

        where_str = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        cypher = f"""
        MATCH path = (d:Decision)-[:LED_TO*1..{max_depth}]->(c)
        {where_str}
        RETURN path
        LIMIT 50
        """

        return self.ops.query(cypher, params=params, read_only=True)

    def get_bug_patterns(
        self,
        problem_id: int | str | None = None,
        category: str | None = None,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """
        Retrieve bug patterns (MATCH (p:Problem)-[:SOLVED_BY]->(s)).

        Args:
            problem_id: Optional specific problem ID
            category: Optional category filter
            include_invalid: Include invalid problems/solutions

        Returns:
            Bug patterns results
        """
        where_clauses = []
        params = {}

        if problem_id:
            where_clauses.append("id(p) = $problem_id")
            params["problem_id"] = int(problem_id)

        if category:
            where_clauses.append("p.category = $category")
            params["category"] = category

        if not include_invalid:
            where_clauses.append("p.valid_to IS NULL")
            where_clauses.append("s.valid_to IS NULL")

        where_str = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        cypher = f"""
        MATCH (p:Problem)-[r:SOLVED_BY]->(s:Solution)
        {where_str}
        RETURN p as problem, r as relation, s as solution
        LIMIT 50
        """

        return self.ops.query(cypher, params=params, read_only=True)

    def get_code_patterns(
        self,
        code_id: int | str | None = None,
        pattern_type: str | None = None,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """
        Retrieve code patterns (MATCH (c:Code)-[:IMPLEMENTS]->(p:Pattern)).

        Args:
            code_id: Optional specific code node ID
            pattern_type: Optional pattern type filter
            include_invalid: Include invalid code/patterns

        Returns:
            Code patterns results
        """
        where_clauses = []
        params = {}

        if code_id:
            where_clauses.append("id(c) = $code_id")
            params["code_id"] = int(code_id)

        if pattern_type:
            where_clauses.append("p.type = $pattern_type")
            params["pattern_type"] = pattern_type

        if not include_invalid:
            where_clauses.append("c.valid_to IS NULL")
            where_clauses.append("p.valid_to IS NULL")

        where_str = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        cypher = f"""
        MATCH (c:Code)-[r:IMPLEMENTS]->(p:Pattern)
        {where_str}
        RETURN c as code, r as relation, p as pattern
        LIMIT 50
        """

        return self.ops.query(cypher, params=params, read_only=True)

    def get_conventions(
        self,
        convention_type: str | None = None,
        project_path: str | None = None,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """
        Retrieve coding conventions (MATCH (c:Convention)).

        Args:
            convention_type: Optional convention type filter (naming, style, etc.)
            project_path: Optional project path filter
            include_invalid: Include invalid conventions

        Returns:
            Convention results
        """
        where_clauses = []
        params = {}

        if convention_type:
            where_clauses.append("c.type = $type")
            params["type"] = convention_type

        if project_path:
            where_clauses.append("c.context CONTAINS $project_path")
            params["project_path"] = project_path

        if not include_invalid:
            where_clauses.append("c.valid_to IS NULL")

        where_str = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        cypher = f"""
        MATCH (c:Convention)
        {where_str}
        RETURN c as convention
        ORDER BY c.created_at DESC
        LIMIT 100
        """

        return self.ops.query(cypher, params=params, read_only=True)

    def get_refactors(
        self,
        target: str | None = None,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """
        Retrieve refactoring history (MATCH (r:Refactor)-[:CHANGED]->(c:Code)).

        Args:
            target: Optional target filter (file or function name)
            include_invalid: Include invalid refactors

        Returns:
            Refactor results
        """
        where_clauses = []
        params = {}

        if target:
            where_clauses.append("(r.target CONTAINS $target OR c.name CONTAINS $target)")
            params["target"] = target

        if not include_invalid:
            where_clauses.append("r.valid_to IS NULL")
            where_clauses.append("c.valid_to IS NULL")

        where_str = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        cypher = f"""
        MATCH (r:Refactor)-[rel:CHANGED]->(c:Code)
        {where_str}
        RETURN r as refactor, rel as relation, c as code
        ORDER BY r.created_at DESC
        LIMIT 50
        """

        return self.ops.query(cypher, params=params, read_only=True)

    def get_test_coverage(
        self,
        target: str | None = None,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """
        Retrieve test coverage (MATCH (t:Test)-[:COVERS]->(c:Code)).

        Args:
            target: Optional target filter
            include_invalid: Include invalid tests

        Returns:
            Test coverage results
        """
        where_clauses = []
        params = {}

        if target:
            where_clauses.append("(t.target CONTAINS $target OR c.name CONTAINS $target)")
            params["target"] = target

        if not include_invalid:
            where_clauses.append("t.valid_to IS NULL")
            where_clauses.append("c.valid_to IS NULL")

        where_str = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        cypher = f"""
        MATCH (t:Test)-[rel:COVERS]->(c:Code)
        {where_str}
        RETURN t as test, rel as relation, c as code
        LIMIT 100
        """

        return self.ops.query(cypher, params=params, read_only=True)

    def get_api_usage(
        self,
        api_name: str | None = None,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """
        Retrieve API usage (MATCH (c:Code)-[:CALLED_WITH]->(a:API)).

        Args:
            api_name: Optional API name filter
            include_invalid: Include invalid usage

        Returns:
            API usage results
        """
        where_clauses = []
        params = {}

        if api_name:
            where_clauses.append("a.name CONTAINS $api_name")
            params["api_name"] = api_name

        if not include_invalid:
            where_clauses.append("c.valid_to IS NULL")
            where_clauses.append("a.valid_to IS NULL")

        where_str = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        cypher = f"""
        MATCH (c:Code)-[rel:CALLED_WITH]->(a:API)
        {where_str}
        RETURN c as code, rel as relation, a as api
        LIMIT 100
        """

        return self.ops.query(cypher, params=params, read_only=True)

    def get_reviews(
        self,
        target: str | None = None,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """
        Retrieve code review history (MATCH (r:Review)-[:REVIEWS]->(c:Code)).

        Args:
            target: Optional target filter (file or function name)
            include_invalid: Include invalid reviews

        Returns:
            Review results
        """
        where_clauses = []
        params = {}

        if target:
            where_clauses.append("(r.target CONTAINS $target OR c.name CONTAINS $target)")
            params["target"] = target

        if not include_invalid:
            where_clauses.append("r.valid_to IS NULL")
            where_clauses.append("c.valid_to IS NULL")

        where_str = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""

        cypher = f"""
        MATCH (r:Review)-[rel:REVIEWS]->(c:Code)
        {where_str}
        RETURN r as review, rel as relation, c as code
        ORDER BY r.created_at DESC
        LIMIT 50
        """

        return self.ops.query(cypher, params=params, read_only=True)

    def wake_up(self, project_path: str | None = None, limit: int = 3) -> dict[str, Any]:
        """
        Load project-critical facts into context (Wake-up command).

        Retrieves:
        L0: Active session and objectives
        L1: Critical decisions, facts (learnings), and pending tasks.

        Args:
            project_path: Optional filter by project working directory
            limit: Number of items for each category (default 3 to keep token count low)

        Returns:
            Project-critical facts dictionary
        """
        results = {}
        params = {}
        if project_path:
            params["project_path"] = project_path

        # 1. Get current active session (L0)
        session_cypher = "MATCH (s:Session {status: 'active'}) "
        if project_path:
            session_cypher += "WHERE s.project_path = $project_path "
        session_cypher += "RETURN s ORDER BY s.started_at DESC LIMIT 1"

        session_result = self.ops.query(session_cypher, params=params, read_only=True)
        results["active_session"] = [row[0] for row in session_result.get("result_set", [])]

        # 2. Get latest decisions (L1)
        decision_cypher = "MATCH (d:Decision) WHERE d.valid_to IS NULL "
        if project_path:
            decision_cypher += "AND d.context CONTAINS $project_path "
        decision_cypher += f"RETURN d ORDER BY d.created_at DESC LIMIT {limit}"
        decision_result = self.ops.query(decision_cypher, params=params, read_only=True)
        results["decisions"] = [row[0] for row in decision_result.get("result_set", [])]

        # 3. Get latest critical learnings/facts (L1)
        # Critical facts usually tagged with 'priority' or 'critical' or category 'context'
        learning_cypher = "MATCH (l:Learning) "
        where_clauses = [
            "l.valid_to IS NULL",
            "(l.category = 'context' OR 'priority' IN l.tags OR 'critical' IN l.tags)",
        ]
        if project_path:
            where_clauses.append("l.context CONTAINS $project_path")

        learning_cypher += "WHERE " + " AND ".join(where_clauses)
        learning_cypher += f" RETURN l ORDER BY l.created_at DESC LIMIT {limit}"
        learning_result = self.ops.query(learning_cypher, params=params, read_only=True)
        results["critical_learnings"] = [row[0] for row in learning_result.get("result_set", [])]

        # 4. Get project conventions/configs (context category)
        # These are specifically category='context'
        context_cypher = "MATCH (l:Learning {category: 'context'}) WHERE l.valid_to IS NULL "
        if project_path:
            context_cypher += "AND l.context CONTAINS $project_path "
        context_cypher += f"RETURN l ORDER BY l.created_at DESC LIMIT {limit * 2}"
        context_result = self.ops.query(context_cypher, params=params, read_only=True)
        results["project_context"] = [row[0] for row in context_result.get("result_set", [])]

        # 5. Get latest active tasks (L1)
        task_cypher = "MATCH (t:Task) WHERE t.valid_to IS NULL AND (t.status = 'todo' OR t.status = 'in_progress') "
        if project_path:
            task_cypher += "AND t.context CONTAINS $project_path "
        task_cypher += f"RETURN t ORDER BY t.created_at DESC LIMIT {limit}"
        task_result = self.ops.query(task_cypher, params=params, read_only=True)
        results["tasks"] = [row[0] for row in task_result.get("result_set", [])]

        return results

    # ============================================================
    # Private helper methods
    # ============================================================

    def _enrich_properties(
        self,
        memory_type: MemoryType,
        properties: dict[str, Any],
    ) -> dict[str, Any]:
        """Enrich properties based on memory type."""
        if memory_type == MemoryType.LEARNING:
            # Ensure required learning fields
            if "category" not in properties:
                properties["category"] = "insight"
            if "title" not in properties and "content" in properties:
                # Generate title from first 50 chars of content
                content = properties["content"]
                properties["title"] = content[:50] + "..." if len(content) > 50 else content
            if "tags" not in properties:
                properties["tags"] = []

        elif memory_type == MemoryType.DECISION:
            # Ensure required decision fields
            if "type" not in properties:
                properties["type"] = "implementation"
            if "confidence" not in properties:
                properties["confidence"] = 0.8
            if "alternatives" not in properties:
                properties["alternatives"] = []

        elif memory_type == MemoryType.CODE:
            # Ensure required code fields
            if "type" not in properties:
                properties["type"] = "snippet"
            if "language" not in properties:
                # Try to detect language
                properties["language"] = self._detect_language(properties.get("content", ""))

        elif memory_type == MemoryType.PROBLEM:
            # Ensure required problem fields
            if "error" not in properties and "content" in properties:
                properties["error"] = properties["content"]
            if "category" not in properties:
                properties["category"] = "bug"

        elif memory_type == MemoryType.SOLUTION:
            # Ensure required solution fields
            if "fix" not in properties and "content" in properties:
                properties["fix"] = properties["content"]

        elif memory_type == MemoryType.PATTERN:
            # Ensure required pattern fields
            if "type" not in properties and "content" in properties:
                properties["type"] = properties["content"]
            if "type" not in properties:
                properties["type"] = "unknown"

        elif memory_type == MemoryType.DEPENDENCY:
            # Ensure required dependency fields
            if "name" not in properties and "content" in properties:
                # Try to extract name from content (e.g., "Use requests instead of urllib")
                content = properties["content"]
                # Simple heuristic: first word if no better match
                properties["name"] = content.split()[0] if content.split() else "unknown"
            if "rationale" not in properties and "content" in properties:
                properties["rationale"] = properties["content"]
            if "alternatives" not in properties:
                properties["alternatives"] = []

        elif memory_type == MemoryType.REFACTOR:
            # Ensure required refactor fields
            if "target" not in properties:
                properties["target"] = "unknown"
            if "description" not in properties and "content" in properties:
                properties["description"] = properties["content"]

        elif memory_type == MemoryType.TEST:
            # Ensure required test fields
            if "name" not in properties:
                properties["name"] = "unknown"
            if "type" not in properties:
                properties["type"] = "unit"
            if "target" not in properties:
                properties["target"] = "unknown"

        elif memory_type == MemoryType.API:
            # Ensure required api fields
            if "name" not in properties:
                properties["name"] = "unknown"
            if "parameters" not in properties:
                properties["parameters"] = "{}"
            elif isinstance(properties["parameters"], dict):
                properties["parameters"] = json.dumps(properties["parameters"])

        elif memory_type == MemoryType.REVIEW:
            # Ensure required review fields
            if "target" not in properties:
                properties["target"] = "unknown"
            if "comments" not in properties and "content" in properties:
                properties["comments"] = properties["content"]

        return properties

    def _detect_language(self, code: str) -> str:
        """Detect programming language from code snippet."""
        if not code:
            return "unknown"

        # Simple heuristics
        if "def " in code or "import " in code or "from " in code:
            return "python"
        elif "function " in code or "const " in code or "let " in code:
            return "javascript"
        elif "func " in code or "package " in code:
            return "go"
        elif "class " in code and "{" in code:
            return "java"
        elif "fn " in code or "let mut" in code:
            return "rust"
        else:
            return "unknown"

    def _text_search(
        self,
        query: str,
        filters: dict[str, Any],
        limit: int,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """Perform full-text search."""
        # Build filter clauses
        filter_clauses = []
        params = {}

        for key, value in filters.items():
            filter_clauses.append(f"n.{key} = ${key}")
            params[key] = value

        if not include_invalid:
            filter_clauses.append("n.valid_to IS NULL")

        where_clause = " AND ".join(filter_clauses) if filter_clauses else "true"

        # Escape query for Cypher
        escaped_query = query.replace("\\", "\\\\").replace("'", "\\'")

        cypher = f"""
        MATCH (n)
        WHERE ({where_clause})
        AND (n.content CONTAINS '{escaped_query}' OR n.title CONTAINS '{escaped_query}' OR n.name CONTAINS '{escaped_query}')
        RETURN n
        ORDER BY n.created_at DESC
        LIMIT {limit}
        """

        return self.ops.query(cypher, params, read_only=True)

    def _pattern_search(
        self,
        query: str,
        filters: dict[str, Any],
        limit: int,
        include_context: bool,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """Perform pattern matching search."""
        escaped_query = query.replace("\\", "\\\\").replace("'", "\\'")

        filter_clauses = []
        params = filters.copy()

        for key, value in filters.items():
            filter_clauses.append(f"n.{key} = ${key}")

        if not include_invalid:
            filter_clauses.append("n.valid_to IS NULL")

        where_parts = [
            f"n.content CONTAINS '{escaped_query}' OR n.title CONTAINS '{escaped_query}'"
        ]
        if filter_clauses:
            where_parts.extend(filter_clauses)

        where_clause = " AND ".join(["(" + " OR ".join(where_parts[:2]) + ")"] + filter_clauses)

        if include_context:
            cypher = f"""
            MATCH (n)
            WHERE {where_clause}
            OPTIONAL MATCH (n)-[r]-(related)
            RETURN n as node, collect({{relation: type(r), node: related}}) as context
            ORDER BY n.created_at DESC
            LIMIT {limit}
            """
        else:
            cypher = f"""
            MATCH (n)
            WHERE {where_clause}
            RETURN n as node
            ORDER BY n.created_at DESC
            LIMIT {limit}
            """

        return self.ops.query(cypher, params, read_only=True)

    def _traversal_search(
        self,
        query: str,
        filters: dict[str, Any],
        limit: int,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """Perform graph traversal search."""
        # Parse query as starting node criteria
        # Format: "label:property:value" or just "id:123"
        parts = query.split(":")

        if len(parts) >= 2:
            if parts[0] == "id":
                start_clause = f"id(n) = {int(parts[1])}"
            else:
                label = parts[0]
                prop = parts[1]
                val = ":".join(parts[2:]) if len(parts) > 2 else ""
                start_clause = f"n:{label} AND n.{prop} CONTAINS '{val}'"
        else:
            start_clause = f"n.id CONTAINS '{query}'"

        temporal_clause = " AND n.valid_to IS NULL" if not include_invalid else ""

        cypher = f"""
        MATCH (n)
        WHERE {start_clause}{temporal_clause}
        MATCH (n)-[r*1..2]-(related)
        WHERE ALL(rel IN nodes(r) WHERE rel.valid_to IS NULL) OR $include_invalid
        RETURN n as start, collect(DISTINCT related) as connected, collect(DISTINCT type(r)) as relations
        LIMIT {limit}
        """
        # Note: Cypher traversal filtering is tricky, let's simplify for now
        cypher = f"""
        MATCH (n)
        WHERE {start_clause}{temporal_clause}
        MATCH (n)-[r*1..2]-(related)
        RETURN n as start, collect(DISTINCT related) as connected, collect(DISTINCT type(r)) as relations
        LIMIT {limit}
        """

        return self.ops.query(cypher, read_only=True)

    def _delete_expired(
        self,
        older_than_seconds: int,
        cascade: bool,
    ) -> dict[str, Any]:
        """Delete nodes older than specified TTL."""
        cypher = f"""
        MATCH (n)
        WHERE n.created_at IS NOT NULL AND n.ttl IS NOT NULL
        WITH n, datetime() as now, datetime(n.created_at) as created
        WHERE duration.inSeconds(created, now).seconds > {older_than_seconds}
        RETURN id(n) as node_id
        """

        result = self.ops.query(cypher, read_only=True)
        node_ids = [row[0] for row in result.get("result_set", [])]

        if node_ids:
            return self.ops.delete_nodes(node_ids, cascade)

        return {"deleted_count": 0, "cascade": cascade}


# Global instance
_memory_manager: MemoryManager | None = None


def get_memory_manager() -> MemoryManager:
    """Get the global MemoryManager instance."""
    global _memory_manager
    if _memory_manager is None:
        _memory_manager = MemoryManager()
    return _memory_manager
