"""Embedding service using sentence-transformers for semantic search."""

import logging
from typing import Any

from pydantic import BaseModel

from falkordb_memory_server.config import get_settings

logger = logging.getLogger(__name__)

# Lazy-loaded model
_model = None


def get_embedding_model():
    """Get or load the embedding model (lazy initialization)."""
    global _model
    if _model is None:
        try:
            from sentence_transformers import SentenceTransformer

            settings = get_settings()
            logger.info(f"Loading embedding model: {settings.embedding_model}")
            _model = SentenceTransformer(settings.embedding_model)
            logger.info(
                f"Model loaded successfully (dimension: {_model.get_sentence_embedding_dimension()})"
            )
        except ImportError:
            logger.warning("sentence-transformers not installed. Semantic search will be limited.")
            return None
    return _model


class EmbeddingResult(BaseModel):
    """Result of embedding generation."""

    vector: list[float]
    dimension: int
    model: str
    text_preview: str


class EmbeddingService:
    """Service for generating and managing embeddings."""

    def __init__(self) -> None:
        """Initialize embedding service."""
        self.settings = get_settings()
        self._model = None

    @property
    def model(self):
        """Get the embedding model (lazy load)."""
        if self._model is None:
            self._model = get_embedding_model()
        return self._model

    def generate_embedding(
        self,
        text: str,
        normalize: bool = True,
    ) -> EmbeddingResult | None:
        """
        Generate embedding for text.

        Args:
            text: Text to embed
            normalize: Whether to normalize the vector

        Returns:
            Embedding result or None if model unavailable
        """
        if not self.model:
            logger.warning("Embedding model not available")
            return None

        try:
            import numpy as np

            # Generate embedding
            vector = self.model.encode(
                text,
                normalize_embeddings=normalize,
                convert_to_numpy=True,
            )

            # Convert to list
            vector_list = vector.tolist() if isinstance(vector, np.ndarray) else list(vector)

            return EmbeddingResult(
                vector=vector_list,
                dimension=len(vector_list),
                model=self.settings.embedding_model,
                text_preview=text[:100] + "..." if len(text) > 100 else text,
            )

        except Exception as e:
            logger.error(f"Error generating embedding: {e}")
            return None

    def generate_embeddings(
        self,
        texts: list[str],
        normalize: bool = True,
    ) -> list[list[float]] | None:
        """
        Generate embeddings for multiple texts.

        Args:
            texts: List of texts to embed
            normalize: Whether to normalize vectors

        Returns:
            List of embedding vectors or None if model unavailable
        """
        if not self.model:
            logger.warning("Embedding model not available")
            return None

        try:
            import numpy as np

            vectors = self.model.encode(
                texts,
                normalize_embeddings=normalize,
                convert_to_numpy=True,
                show_progress_bar=len(texts) > 100,
            )

            return [v.tolist() if isinstance(v, np.ndarray) else list(v) for v in vectors]

        except Exception as e:
            logger.error(f"Error generating embeddings: {e}")
            return None

    def compute_similarity(
        self,
        vector1: list[float],
        vector2: list[float],
    ) -> float:
        """
        Compute cosine similarity between two vectors.

        Args:
            vector1: First vector
            vector2: Second vector

        Returns:
            Similarity score (0-1)
        """
        try:
            import numpy as np

            v1 = np.array(vector1)
            v2 = np.array(vector2)

            # Normalize vectors
            v1_norm = v1 / np.linalg.norm(v1)
            v2_norm = v2 / np.linalg.norm(v2)

            # Cosine similarity
            similarity = np.dot(v1_norm, v2_norm)
            return float(similarity)

        except Exception as e:
            logger.error(f"Error computing similarity: {e}")
            return 0.0

    def get_dimension(self) -> int:
        """Get the embedding dimension."""
        return self.settings.embedding_dimension

    def is_available(self) -> bool:
        """Check if embedding model is available."""
        try:
            return self.model is not None
        except Exception as e:
            logger.warning(f"Embedding model not available: {e}")
            return False

    def prepare_text_for_embedding(
        self,
        content: dict[str, Any],
        content_type: str = "memory",
    ) -> str:
        """
        Prepare memory content for embedding.

        Args:
            content: Memory content dictionary
            content_type: Type of content (memory, code, decision, etc.)

        Returns:
            Text ready for embedding
        """
        parts = []

        # Add type context
        parts.append(f"Type: {content_type}")

        # Add title if present
        if "title" in content:
            parts.append(f"Title: {content['title']}")

        # Add main content
        if "content" in content:
            parts.append(f"Content: {content['content']}")
        elif "description" in content:
            parts.append(f"Description: {content['description']}")

        # Add context
        if "context" in content:
            parts.append(f"Context: {content['context']}")

        # Add rationale for decisions
        if "rationale" in content:
            parts.append(f"Rationale: {content['rationale']}")

        # Add tags if present
        if "tags" in content and isinstance(content["tags"], list):
            parts.append(f"Tags: {', '.join(content['tags'])}")

        # Add category if present
        if "category" in content:
            parts.append(f"Category: {content['category']}")

        return "\n".join(parts)


# Global instance
_embedding_service: EmbeddingService | None = None


def get_embedding_service() -> EmbeddingService:
    """Get the global EmbeddingService instance."""
    global _embedding_service
    if _embedding_service is None:
        _embedding_service = EmbeddingService()
    return _embedding_service
