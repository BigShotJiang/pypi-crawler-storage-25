"""Session management for agent memory tracking."""

import uuid
from datetime import datetime, timezone
from typing import Any

from falkordb_memory_server.config import get_settings
from falkordb_memory_server.graph_ops import GraphOperations, get_graph_ops
from falkordb_memory_server.schema import NodeLabel, RelationType


class SessionManager:
    """Manage agent sessions in the memory graph."""

    def __init__(self, ops: GraphOperations | None = None) -> None:
        """Initialize session manager."""
        self.ops = ops or get_graph_ops()
        self.settings = get_settings()
        self._current_session_id: str | None = None

    def start_session(
        self,
        agent_type: str,
        agent_id: str,
        project_path: str | None = None,
        objective: str | None = None,
        ttl: int | None = None,
    ) -> dict[str, Any]:
        """
        Start a new agent session.

        Args:
            agent_type: Type of agent (claude, codex, gemini)
            agent_id: Agent instance identifier
            project_path: Working directory
            objective: Session goal
            ttl: Session TTL in seconds

        Returns:
            Created session information
        """
        session_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc)

        # Create session node
        session_props = {
            "id": session_id,
            "agent_type": agent_type,
            "agent_id": agent_id,
            "project_path": project_path,
            "objective": objective,
            "started_at": now.isoformat(),
            "status": "active",
        }

        if ttl is None:
            ttl = self.settings.default_ttl
        if ttl:
            session_props["ttl"] = ttl

        # Create Session node
        result = self.ops.create_node(NodeLabel.SESSION, session_props)

        # Ensure Agent node exists
        agent_result = self._ensure_agent(agent_type, agent_id)

        # Create STARTED_BY relationship
        if result.get("node_id"):
            self.ops.create_edge(
                result["node_id"],
                RelationType.STARTED_BY,
                agent_result.get("node_id"),
            )

        # Track current session
        self._current_session_id = session_id

        result["session_id"] = session_id
        result["agent_node_id"] = agent_result.get("node_id")
        return result

    def end_session(
        self,
        session_id: str,
        status: str = "completed",
        summary: str | None = None,
    ) -> dict[str, Any]:
        """
        End an agent session.

        Args:
            session_id: Session ID to end
            status: End status (completed, abandoned)
            summary: Session summary

        Returns:
            Updated session information
        """
        now = datetime.now(timezone.utc)

        # Build update query
        cypher = """
        MATCH (s:Session {id: $session_id})
        SET s.status = $status, s.ended_at = $ended_at
        """

        params = {"session_id": session_id, "status": status, "ended_at": now.isoformat()}
        if summary:
            cypher += ", s.summary = $summary"
            params["summary"] = summary

        cypher += " RETURN s"

        result = self.ops.query(cypher, params)

        # Clear current session if matching
        if self._current_session_id == session_id:
            self._current_session_id = None

        return {
            "session_id": session_id,
            "status": status,
            "ended_at": now.isoformat(),
            "result": result,
        }

    def continue_session(
        self,
        previous_session_id: str,
        new_agent_id: str | None = None,
        new_objective: str | None = None,
    ) -> dict[str, Any]:
        """
        Continue from a previous session.

        Args:
            previous_session_id: Previous session ID
            new_agent_id: Optional new agent ID
            new_objective: Optional new objective

        Returns:
            New session linked to previous
        """
        # Get previous session info
        prev_result = self.ops.query(
            "MATCH (s:Session {id: $session_id}) RETURN s",
            params={"session_id": previous_session_id},
            read_only=True,
        )

        if not prev_result.get("result_set"):
            return {"error": f"Session {previous_session_id} not found"}

        prev_session = prev_result["result_set"][0][0] if prev_result["result_set"] else None
        if not prev_session:
            return {"error": "Could not retrieve previous session"}

        prev_props = prev_session.get("properties", {})

        # Create new session with inherited context
        new_session = self.start_session(
            agent_type=prev_props.get("agent_type", "unknown"),
            agent_id=new_agent_id or prev_props.get("agent_id", "unknown"),
            project_path=prev_props.get("project_path"),
            objective=new_objective or prev_props.get("objective"),
        )

        # Create CONTINUES relationship
        if new_session.get("node_id"):
            self.ops.query(
                """
                MATCH (old:Session {id: $old_id}), (new:Session {id: $new_id})
                CREATE (new)-[:CONTINUES]->(old)
                """,
                params={"old_id": previous_session_id, "new_id": new_session["session_id"]},
            )

        new_session["continued_from"] = previous_session_id
        return new_session

    def get_current_session(self) -> dict[str, Any] | None:
        """
        Get the current active session.

        Returns:
            Current session information or None
        """
        if not self._current_session_id:
            return None

        result = self.ops.query(
            "MATCH (s:Session {id: $session_id}) RETURN s",
            params={"session_id": self._current_session_id},
            read_only=True,
        )

        if result.get("result_set"):
            session = result["result_set"][0][0]
            return {
                "session_id": self._current_session_id,
                "properties": session.get("properties", {}),
            }

        return None

    def get_session_memories(
        self,
        session_id: str,
        memory_types: list[str] | None = None,
        limit: int = 50,
    ) -> dict[str, Any]:
        """
        Get all memories associated with a session.

        Args:
            session_id: Session ID
            memory_types: Filter by memory types
            limit: Maximum results

        Returns:
            List of memories in the session
        """
        params = {"session_id": session_id, "limit": limit}
        if memory_types:
            labels = " OR ".join([f"m:{t}" for t in memory_types])
            cypher = f"""
            MATCH (s:Session {{id: $session_id}})-[:OCCURRED_IN|DISCOVERED|APPLIED]-(m)
            WHERE {labels}
            RETURN m
            ORDER BY m.created_at DESC
            LIMIT $limit
            """
        else:
            cypher = """
            MATCH (s:Session {id: $session_id})-[r]-(m)
            WHERE NOT m:Session AND NOT m:Agent
            RETURN m, type(r) as relation
            ORDER BY m.created_at DESC
            LIMIT $limit
            """

        return self.ops.query(cypher, params=params, read_only=True)

    def add_memory_to_session(
        self,
        session_id: str,
        memory_id: int | str,
        relation_type: str = "OCCURRED_IN",
    ) -> dict[str, Any]:
        """
        Associate a memory with a session.

        Args:
            session_id: Session ID
            memory_id: Memory node ID
            relation_type: Relationship type

        Returns:
            Created relationship info
        """
        cypher = f"""
        MATCH (s:Session {{id: $session_id}}), (m)
        WHERE id(m) = $memory_id
        CREATE (m)-[r:{relation_type}]->(s)
        RETURN type(r) as relation
        """

        return self.ops.query(
            cypher, params={"session_id": session_id, "memory_id": int(memory_id)}
        )

    def list_sessions(
        self,
        agent_type: str | None = None,
        status: str | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        """
        List sessions with optional filters.

        Args:
            agent_type: Filter by agent type
            status: Filter by status
            limit: Maximum results

        Returns:
            List of sessions
        """
        filters = []
        params = {"limit": limit}
        if agent_type:
            filters.append("s.agent_type = $agent_type")
            params["agent_type"] = agent_type
        if status:
            filters.append("s.status = $status")
            params["status"] = status

        where_clause = " AND ".join(filters) if filters else "true"

        cypher = f"""
        MATCH (s:Session)
        WHERE {where_clause}
        RETURN s
        ORDER BY s.started_at DESC
        LIMIT $limit
        """

        return self.ops.query(cypher, params=params, read_only=True)

    def _ensure_agent(
        self,
        agent_type: str,
        agent_id: str,
    ) -> dict[str, Any]:
        """Ensure an Agent node exists."""
        now = datetime.now(timezone.utc).isoformat()

        # Check if agent exists
        result = self.ops.query(
            "MATCH (a:Agent {id: $agent_id}) RETURN a",
            params={"agent_id": agent_id},
            read_only=True,
        )

        if result.get("result_set"):
            # Update last_active
            self.ops.query(
                "MATCH (a:Agent {id: $agent_id}) SET a.last_active = $now",
                params={"agent_id": agent_id, "now": now},
            )
            return {"node_id": result["result_set"][0][0].get("id")}

        # Create new agent
        agent_props = {
            "id": agent_id,
            "type": agent_type,
            "name": f"{agent_type}_{agent_id[:8]}",
            "first_seen": now,
            "last_active": now,
        }

        return self.ops.create_node(NodeLabel.AGENT, agent_props)


# Global instance
_session_manager: SessionManager | None = None


def get_session_manager() -> SessionManager:
    """Get the global SessionManager instance."""
    global _session_manager
    if _session_manager is None:
        _session_manager = SessionManager()
    return _session_manager
