"""Cross-agent memory sharing and identity management."""

import logging
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel

from falkordb_memory_server.config import get_settings
from falkordb_memory_server.graph_ops import GraphOperations, get_graph_ops
from falkordb_memory_server.schema import NodeLabel

logger = logging.getLogger(__name__)


class AgentIdentity(BaseModel):
    """Agent identity information."""

    agent_id: str
    agent_type: str
    name: str | None = None
    namespace: str | None = None
    capabilities: list[str] = []
    metadata: dict[str, Any] = {}


class SharingPermission(BaseModel):
    """Sharing permission configuration."""

    read: bool = True
    write: bool = False
    delete: bool = False
    share: bool = False


class SharingManager:
    """Manage cross-agent memory sharing."""

    def __init__(self, ops: GraphOperations | None = None) -> None:
        """Initialize sharing manager."""
        self.ops = ops or get_graph_ops()
        self.settings = get_settings()

    def register_agent(
        self,
        agent_id: str,
        agent_type: str,
        name: str | None = None,
        namespace: str | None = None,
        capabilities: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Register or update an agent identity.

        Args:
            agent_id: Unique agent identifier
            agent_type: Type of agent (claude, codex, gemini)
            name: Human-readable name
            namespace: Optional namespace for isolation
            capabilities: List of agent capabilities

        Returns:
            Agent node information
        """
        now = datetime.now(timezone.utc).isoformat()

        # Check if agent exists
        existing = self.ops.query(
            "MATCH (a:Agent {id: $agent_id}) RETURN a",
            params={"agent_id": agent_id},
            read_only=True,
        )

        if existing.get("result_set"):
            # Update existing agent
            cypher = "MATCH (a:Agent {id: $agent_id}) SET a.last_active = $now"
            params = {"agent_id": agent_id, "now": now}

            if name:
                cypher += ", a.name = $name"
                params["name"] = name
            if namespace:
                cypher += ", a.namespace = $namespace"
                params["namespace"] = namespace
            if capabilities:
                cypher += ", a.capabilities = $capabilities"
                params["capabilities"] = capabilities
            cypher += " RETURN a"

            return self.ops.query(cypher, params=params)

        # Create new agent
        props = {
            "id": agent_id,
            "type": agent_type,
            "name": name or f"{agent_type}_{agent_id[:8]}",
            "namespace": namespace or f"{agent_type}:{agent_id}",
            "first_seen": now,
            "last_active": now,
        }
        if capabilities:
            props["capabilities"] = capabilities

        return self.ops.create_node(NodeLabel.AGENT, props)

    def share_memory(
        self,
        memory_id: int | str,
        target_agent_ids: list[str],
        permissions: SharingPermission | None = None,
    ) -> dict[str, Any]:
        """
        Share a memory with other agents.

        Args:
            memory_id: Memory node ID
            target_agent_ids: List of agent IDs to share with
            permissions: Sharing permissions

        Returns:
            Sharing result
        """
        permissions = permissions or SharingPermission()
        results = []

        for agent_id in target_agent_ids:
            # Ensure agent exists
            self.register_agent(agent_id, "unknown")

            # Create SHARED_WITH relationship
            perm_props = {
                "read": permissions.read,
                "write": permissions.write,
                "delete": permissions.delete,
                "share": permissions.share,
                "shared_at": datetime.now(timezone.utc).isoformat(),
            }

            result = self.ops.create_edge(
                memory_id,
                "SHARED_WITH",
                agent_id,
                perm_props,
            )
            results.append(
                {
                    "agent_id": agent_id,
                    "success": "edge_id" in result,
                }
            )

        return {
            "memory_id": memory_id,
            "shared_with": results,
            "total_shared": len(results),
        }

    def query_agent_memories(
        self,
        agent_type: str | None = None,
        agent_id: str | None = None,
        memory_types: list[str] | None = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        """
        Query memories shared by a specific agent.

        Args:
            agent_type: Filter by agent type
            agent_id: Specific agent ID
            memory_types: Filter by memory types
            limit: Maximum results

        Returns:
            List of shared memories
        """
        filters = []
        params = {"limit": limit}
        if agent_type:
            filters.append("a.type = $agent_type")
            params["agent_type"] = agent_type
        if agent_id:
            filters.append("a.id = $agent_id")
            params["agent_id"] = agent_id

        where_clause = " AND ".join(filters) if filters else "true"

        if memory_types:
            label_clause = " OR ".join([f"m:{t}" for t in memory_types])
            cypher = f"""
            MATCH (a:Agent)-[s:SHARED_WITH]->(m)
            WHERE {where_clause} AND ({label_clause})
            RETURN m, s, a
            ORDER BY s.shared_at DESC
            LIMIT $limit
            """
        else:
            cypher = f"""
            MATCH (a:Agent)-[s:SHARED_WITH]->(m)
            WHERE {where_clause}
            RETURN m, s, a
            ORDER BY s.shared_at DESC
            LIMIT $limit
            """

        return self.ops.query(cypher, params=params, read_only=True)

    def get_agent_knowledge(
        self,
        agent_id: str,
        include_shared: bool = True,
        limit: int = 50,
    ) -> dict[str, Any]:
        """
        Get all knowledge/memories associated with an agent.

        Args:
            agent_id: Agent ID
            include_shared: Include memories shared with this agent
            limit: Maximum results

        Returns:
            Agent's knowledge graph
        """
        if include_shared:
            cypher = """
            MATCH (a:Agent {id: $agent_id})
            OPTIONAL MATCH (a)-[:STARTED_BY]-(s:Session)-[r]-(m)
            WHERE NOT m:Session AND NOT m:Agent
            OPTIONAL MATCH (a)-[shared:SHARED_WITH]->(shared_mem)
            RETURN a as agent,
                   collect(DISTINCT m) as own_memories,
                   collect(DISTINCT shared_mem) as shared_memories
            LIMIT $limit
            """
        else:
            cypher = """
            MATCH (a:Agent {id: $agent_id})
            OPTIONAL MATCH (a)-[:STARTED_BY]-(s:Session)-[r]-(m)
            WHERE NOT m:Session AND NOT m:Agent
            RETURN a as agent,
                   collect(DISTINCT m) as own_memories
            LIMIT $limit
            """

        return self.ops.query(cypher, params={"agent_id": agent_id, "limit": limit}, read_only=True)

    def check_permission(
        self,
        memory_id: int | str,
        agent_id: str,
        permission: str = "read",
    ) -> bool:
        """
        Check if an agent has permission to access a memory.

        Args:
            memory_id: Memory node ID
            agent_id: Agent ID
            permission: Permission type (read, write, delete, share)

        Returns:
            True if permission granted
        """
        # We can't parameterize dynamic property access in RETURN, so we validate it
        if permission not in ("read", "write", "delete", "share"):
            raise ValueError(f"Invalid permission type: {permission}")

        cypher = f"""
        MATCH (m)-[s:SHARED_WITH]->(a:Agent {{id: $agent_id}})
        WHERE id(m) = $memory_id
        RETURN s.{permission} as has_permission
        """

        result = self.ops.query(
            cypher, params={"agent_id": agent_id, "memory_id": int(memory_id)}, read_only=True
        )
        if result.get("result_set") and result["result_set"][0]:
            return bool(result["result_set"][0][0])
        return False

    def revoke_sharing(
        self,
        memory_id: int | str,
        agent_ids: list[str] | None = None,
    ) -> dict[str, Any]:
        """
        Revoke sharing permissions.

        Args:
            memory_id: Memory node ID
            agent_ids: Specific agents to revoke (None = all)

        Returns:
            Revocation result
        """
        params = {"memory_id": int(memory_id)}

        if agent_ids:
            cypher = """
            MATCH (m)-[s:SHARED_WITH]->(a:Agent)
            WHERE id(m) = $memory_id AND a.id IN $agent_ids
            DELETE s
            RETURN count(s) as deleted
            """
            params["agent_ids"] = agent_ids
        else:
            cypher = """
            MATCH (m)-[s:SHARED_WITH]->(a:Agent)
            WHERE id(m) = $memory_id
            DELETE s
            RETURN count(s) as deleted
            """

        result = self.ops.query(cypher, params=params)
        deleted_count = result["result_set"][0][0] if result.get("result_set") else 0

        return {
            "memory_id": memory_id,
            "revoked_count": deleted_count,
        }

    def get_namespace_memories(
        self,
        namespace: str,
        limit: int = 50,
    ) -> dict[str, Any]:
        """
        Get all memories in a namespace.

        Args:
            namespace: Namespace to query
            limit: Maximum results

        Returns:
            List of memories in namespace
        """
        cypher = """
        MATCH (m)
        WHERE m.namespace = $namespace
        RETURN m
        ORDER BY m.created_at DESC
        LIMIT $limit
        """

        return self.ops.query(
            cypher, params={"namespace": namespace, "limit": limit}, read_only=True
        )


# Global instance
_sharing_manager: SharingManager | None = None


def get_sharing_manager() -> SharingManager:
    """Get the global SharingManager instance."""
    global _sharing_manager
    if _sharing_manager is None:
        _sharing_manager = SharingManager()
    return _sharing_manager
