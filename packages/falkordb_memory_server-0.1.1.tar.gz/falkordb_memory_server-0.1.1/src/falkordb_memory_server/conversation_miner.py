"""Conversation mining from various export formats.

Supported formats:
- Claude: JSON (export), Markdown (saved)
- ChatGPT: JSON (export), HTML (saved)
- Slack: JSON (export), Text (copy-pasted)
"""

import json
import re
from pathlib import Path

from .extractor import ExtractionResult, MemoryExtractor


class ConversationMiner:
    """Mines memories from conversation exports."""

    def __init__(self, extractor: MemoryExtractor | None = None):
        self.extractor = extractor or MemoryExtractor()

    def mine_claude_json(self, file_path: str | Path) -> ExtractionResult:
        """Mine memories from Claude JSON export."""
        path = Path(file_path)
        if not path.exists():
            return ExtractionResult()

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        # Claude export is usually a list of conversations
        if not isinstance(data, list):
            data = [data]

        all_memories = []
        total_chunks = 0
        by_category = {}

        for conv in data:
            title = conv.get("name", "Untitled")
            chat_messages = conv.get("chat_messages", [])

            # Concatenate messages for extraction
            text_parts = [f"Title: {title}"]
            for msg in chat_messages:
                sender = msg.get("sender", "unknown")
                text = msg.get("text", "")
                text_parts.append(f"{sender}: {text}")

            full_text = "\n\n".join(text_parts)
            result = self.extractor.extract(full_text, source_file=str(path))

            all_memories.extend(result.memories)
            total_chunks += result.total_chunks
            for cat, count in result.by_category.items():
                by_category[cat] = by_category.get(cat, 0) + count

        return ExtractionResult(
            memories=all_memories,
            total_chunks=total_chunks,
            by_category=by_category,
        )

    def mine_claude_md(self, file_path: str | Path) -> ExtractionResult:
        """Mine memories from Claude Markdown file."""
        path = Path(file_path)
        if not path.exists():
            return ExtractionResult()

        with open(path, encoding="utf-8") as f:
            text = f.read()

        return self.extractor.extract(text, source_file=str(path))

    def mine_chatgpt_json(self, file_path: str | Path) -> ExtractionResult:
        """Mine memories from ChatGPT JSON export (conversations.json)."""
        path = Path(file_path)
        if not path.exists():
            return ExtractionResult()

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            data = [data]

        all_memories = []
        total_chunks = 0
        by_category = {}

        for conv in data:
            title = conv.get("title", "Untitled")
            mapping = conv.get("mapping", {})

            text_parts = [f"Title: {title}"]

            # Sort messages by time if possible, or just iterate mapping
            # In ChatGPT export, mapping contains the message tree.
            # We'll just extract all text content from messages.
            for node_id, node in mapping.items():
                message = node.get("message")
                if message and message.get("content"):
                    author = message.get("author", {}).get("role", "unknown")
                    content = message.get("content", {})
                    if content.get("content_type") == "text":
                        parts = content.get("parts", [])
                        text = " ".join(parts)
                        text_parts.append(f"{author}: {text}")

            full_text = "\n\n".join(text_parts)
            result = self.extractor.extract(full_text, source_file=str(path))

            all_memories.extend(result.memories)
            total_chunks += result.total_chunks
            for cat, count in result.by_category.items():
                by_category[cat] = by_category.get(cat, 0) + count

        return ExtractionResult(
            memories=all_memories,
            total_chunks=total_chunks,
            by_category=by_category,
        )

    def mine_chatgpt_html(self, file_path: str | Path) -> ExtractionResult:
        """Mine memories from ChatGPT HTML file."""
        path = Path(file_path)
        if not path.exists():
            return ExtractionResult()

        with open(path, encoding="utf-8") as f:
            html = f.read()

        # Simple approach: strip HTML tags and extract
        # A better approach would use BeautifulSoup but we want to keep dependencies low
        text = re.sub(r"<[^>]+>", " ", html)
        text = re.sub(r"\s+", " ", text).strip()

        return self.extractor.extract(text, source_file=str(path))

    def mine_slack_json(self, path: str | Path) -> ExtractionResult:
        """Mine memories from Slack JSON export (directory or single file)."""
        root_path = Path(path)
        if not root_path.exists():
            return ExtractionResult()

        all_memories = []
        total_chunks = 0
        by_category = {}

        files_to_process = []
        if root_path.is_file():
            files_to_process.append(root_path)
        else:
            # Recursively find all JSON files
            files_to_process.extend(root_path.glob("**/*.json"))

        for file_path in files_to_process:
            if file_path.name in ["users.json", "channels.json", "integration_logs.json"]:
                continue

            with open(file_path, encoding="utf-8") as f:
                try:
                    data = json.load(f)
                except json.JSONDecodeError:
                    continue

            if not isinstance(data, list):
                continue

            text_parts = []
            for msg in data:
                user = msg.get("user", msg.get("user_profile", {}).get("real_name", "unknown"))
                text = msg.get("text", "")
                if text:
                    text_parts.append(f"{user}: {text}")

            if text_parts:
                full_text = "\n\n".join(text_parts)
                result = self.extractor.extract(full_text, source_file=str(file_path))

                all_memories.extend(result.memories)
                total_chunks += result.total_chunks
                for cat, count in result.by_category.items():
                    by_category[cat] = by_category.get(cat, 0) + count

        return ExtractionResult(
            memories=all_memories,
            total_chunks=total_chunks,
            by_category=by_category,
        )

    def mine_slack_txt(self, file_path: str | Path) -> ExtractionResult:
        """Mine memories from Slack text file."""
        path = Path(file_path)
        if not path.exists():
            return ExtractionResult()

        with open(path, encoding="utf-8") as f:
            text = f.read()

        return self.extractor.extract(text, source_file=str(path))

    def mine_conversations(
        self, path: str | Path, source_type: str = "auto", store: bool = False
    ) -> ExtractionResult:
        """
        Mine memories from conversations at path.

        Args:
            path: Path to file or directory
            source_type: One of 'claude_json', 'claude_md', 'chatgpt_json',
                        'chatgpt_html', 'slack_json', 'slack_txt', 'auto'
            store: Whether to store extracted memories in the graph

        Returns:
            ExtractionResult
        """
        path = Path(path)
        if not path.exists():
            return ExtractionResult()

        if source_type == "auto":
            if path.suffix == ".json":
                # Try to guess based on content or filename
                if "conversations" in path.name.lower():
                    source_type = "chatgpt_json"
                else:
                    # Peek at content
                    with open(path, encoding="utf-8") as f:
                        try:
                            peek = f.read(1000)
                            if '"chat_messages"' in peek:
                                source_type = "claude_json"
                            elif '"mapping"' in peek:
                                source_type = "chatgpt_json"
                            else:
                                source_type = "slack_json"
                        except Exception:
                            source_type = "slack_json"
            elif path.suffix == ".md":
                source_type = "claude_md"
            elif path.suffix in [".html", ".htm"]:
                source_type = "chatgpt_html"
            elif path.suffix == ".txt":
                source_type = "slack_txt"
            elif path.is_dir():
                source_type = "slack_json"
            else:
                source_type = "slack_txt"

        if source_type == "claude_json":
            result = self.mine_claude_json(path)
        elif source_type == "claude_md":
            result = self.mine_claude_md(path)
        elif source_type == "chatgpt_json":
            result = self.mine_chatgpt_json(path)
        elif source_type == "chatgpt_html":
            result = self.mine_chatgpt_html(path)
        elif source_type == "slack_json":
            result = self.mine_slack_json(path)
        elif source_type == "slack_txt":
            result = self.mine_slack_txt(path)
        else:
            # Fallback to plain text extraction
            with open(path, encoding="utf-8", errors="ignore") as f:
                result = self.extractor.extract(f.read(), source_file=str(path))

        if store and result.memories:
            from .config import get_config
            from .graph_ops import GraphOps

            config = get_config()
            ops = GraphOps(config.falkordb_url, config.graph_name)

            stored_ids = []
            for memory in result.memories:
                m_id = ops.add_memory(
                    content=memory.content,
                    category=memory.category.value,
                    metadata={
                        **memory.metadata,
                        "confidence": memory.confidence,
                        "source_file": memory.source_file,
                        "keywords": memory.keywords,
                        "mined_from": source_type,
                    },
                )
                stored_ids.append(m_id)

            result.metadata = result.metadata or {}
            result.metadata["stored_count"] = len(stored_ids)
            result.metadata["stored_ids"] = stored_ids

        return result
