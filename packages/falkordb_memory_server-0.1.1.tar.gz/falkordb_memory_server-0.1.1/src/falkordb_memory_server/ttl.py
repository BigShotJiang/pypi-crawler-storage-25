"""TTL (Time-To-Live) management and cleanup for memories."""

import asyncio
import logging
import threading
from datetime import datetime, timezone
from typing import Any

from falkordb_memory_server.config import get_settings
from falkordb_memory_server.graph_ops import GraphOperations, get_graph_ops

logger = logging.getLogger(__name__)


class TTLManager:
    """Manage memory expiration and cleanup."""

    def __init__(self, ops: GraphOperations | None = None) -> None:
        """Initialize TTL manager."""
        self.ops = ops or get_graph_ops()
        self.settings = get_settings()
        self._cleanup_task: asyncio.Task | None = None
        self._running = False
        self._lock: asyncio.Lock | None = None

    def _get_lock(self) -> asyncio.Lock:
        """Get or create the asyncio lock."""
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    def get_expired_nodes(
        self,
        batch_size: int = 100,
    ) -> list[dict[str, Any]]:
        """
        Find all expired nodes.

        Args:
            batch_size: Maximum number of nodes to return

        Returns:
            List of expired node information
        """
        # Get current timestamp in ISO format
        datetime.now(timezone.utc).isoformat()

        # Find nodes where ttl + created_at < now
        # We compare ISO timestamps as strings (works for UTC format)
        cypher = """
        MATCH (n)
        WHERE n.ttl IS NOT NULL AND n.created_at IS NOT NULL
        RETURN id(n) as node_id, labels(n) as labels, n.ttl as ttl, n.created_at as created_at
        LIMIT $batch_size
        """

        result = self.ops.query(cypher, params={"batch_size": batch_size}, read_only=True)

        expired = []
        now_dt = datetime.now(timezone.utc)
        for row in result.get("result_set", []):
            try:
                created_at_str = row[3]
                ttl_seconds = row[2]
                # Parse the created_at timestamp
                created_at = datetime.fromisoformat(created_at_str.replace("Z", "+00:00"))
                # Check if expired
                age_seconds = (now_dt - created_at).total_seconds()
                if age_seconds > ttl_seconds:
                    expired.append(
                        {
                            "node_id": row[0],
                            "labels": row[1],
                            "ttl": row[2],
                            "created_at": row[3],
                        }
                    )
            except (ValueError, TypeError) as e:
                logger.warning(f"Failed to parse timestamp for node {row[0]}: {e}")
                continue

        return expired

    def cleanup_expired(
        self,
        dry_run: bool = False,
        batch_size: int = 100,
        cascade: bool = True,
    ) -> dict[str, Any]:
        """
        Remove expired memories.

        Args:
            dry_run: If True, only report what would be deleted
            batch_size: Number of nodes to process per batch
            cascade: Delete connected relationships

        Returns:
            Cleanup statistics
        """
        # Find expired nodes first
        expired = self.get_expired_nodes(batch_size)

        if dry_run:
            return {
                "dry_run": True,
                "expired_count": len(expired),
                "expired_nodes": expired,
            }

        if not expired:
            return {
                "deleted_count": 0,
                "errors": None,
            }

        # Delete expired nodes by their IDs in a single query
        node_ids = [int(node["node_id"]) for node in expired]

        try:
            result = self.ops.delete_nodes(node_ids, cascade=cascade)
            return {
                "deleted_count": result.get("deleted_count", 0),
                "errors": None,
            }
        except Exception as e:
            logger.warning(f"Failed to delete expired nodes: {e}")
            return {
                "deleted_count": 0,
                "errors": str(e),
            }

    def get_ttl_stats(self) -> dict[str, Any]:
        """
        Get TTL statistics.

        Returns:
            Statistics about TTL usage and expiration
        """
        # Total nodes with TTL
        total_cypher = """
        MATCH (n)
        WHERE n.ttl IS NOT NULL
        RETURN count(n) as count
        """
        total_result = self.ops.query(total_cypher, read_only=True)
        total_with_ttl = total_result["result_set"][0][0] if total_result.get("result_set") else 0

        # Expired nodes
        expired = self.get_expired_nodes()
        expired_count = len(expired)

        # By label breakdown
        by_label_cypher = """
        MATCH (n)
        WHERE n.ttl IS NOT NULL
        RETURN labels(n)[0] as label, count(n) as count
        ORDER BY count DESC
        """
        by_label_result = self.ops.query(by_label_cypher, read_only=True)
        by_label = {row[0]: row[1] for row in by_label_result.get("result_set", [])}

        return {
            "total_with_ttl": total_with_ttl,
            "expired_count": expired_count,
            "by_label": by_label,
        }

    def set_ttl(
        self,
        node_id: int | str,
        ttl_seconds: int,
    ) -> dict[str, Any]:
        """
        Set or update TTL for a node.

        Args:
            node_id: Node ID
            ttl_seconds: TTL in seconds (0 to remove)

        Returns:
            Update result
        """
        params = {"node_id": int(node_id), "ttl": ttl_seconds}
        if ttl_seconds > 0:
            cypher = """
            MATCH (n)
            WHERE id(n) = $node_id
            SET n.ttl = $ttl
            RETURN n
            """
        else:
            cypher = """
            MATCH (n)
            WHERE id(n) = $node_id
            REMOVE n.ttl
            RETURN n
            """

        return self.ops.query(cypher, params=params)

    def extend_ttl(
        self,
        node_id: int | str,
        additional_seconds: int,
    ) -> dict[str, Any]:
        """
        Extend TTL for a node.

        Args:
            node_id: Node ID
            additional_seconds: Additional seconds to add

        Returns:
            Update result
        """
        cypher = """
        MATCH (n)
        WHERE id(n) = $node_id AND n.ttl IS NOT NULL
        SET n.ttl = n.ttl + $additional
        RETURN n.ttl as new_ttl
        """

        return self.ops.query(
            cypher, params={"node_id": int(node_id), "additional": additional_seconds}
        )

    def refresh_ttl(
        self,
        node_id: int | str,
    ) -> dict[str, Any]:
        """
        Refresh a node's TTL by resetting created_at.

        Args:
            node_id: Node ID

        Returns:
            Update result
        """
        now = datetime.now(timezone.utc).isoformat()
        cypher = """
        MATCH (n)
        WHERE id(n) = $node_id
        SET n.created_at = $now
        RETURN n
        """

        return self.ops.query(cypher, params={"node_id": int(node_id), "now": now})

    async def start_background_cleanup(
        self,
        interval_seconds: int = 3600,  # Default: 1 hour
        batch_size: int = 100,
    ) -> None:
        """
        Start background cleanup task.

        Args:
            interval_seconds: Cleanup interval
            batch_size: Nodes per cleanup batch
        """
        async with self._get_lock():
            if self._running:
                logger.warning("Background cleanup already running")
                return

            self._running = True

            async def cleanup_loop():
                while self._running:
                    try:
                        logger.info("Running TTL cleanup...")
                        result = self.cleanup_expired(dry_run=False, batch_size=batch_size)
                        logger.info(
                            f"Cleanup complete: deleted {result.get('deleted_count', 0)} nodes"
                        )
                    except Exception as e:
                        logger.error(f"Cleanup error: {e}")

                    await asyncio.sleep(interval_seconds)

            self._cleanup_task = asyncio.create_task(cleanup_loop())
            logger.info(f"Started background TTL cleanup (interval: {interval_seconds}s)")

    async def stop_background_cleanup(self) -> None:
        """Stop background cleanup task."""
        async with self._get_lock():
            self._running = False
            if self._cleanup_task:
                self._cleanup_task.cancel()
                try:
                    await self._cleanup_task
                except asyncio.CancelledError:
                    pass
                self._cleanup_task = None
            logger.info("Stopped background TTL cleanup")


# Global instance
_ttl_manager: TTLManager | None = None
_ttl_manager_lock = threading.Lock()


def get_ttl_manager() -> TTLManager:
    """Get the global TTLManager instance."""
    global _ttl_manager
    if _ttl_manager is None:
        with _ttl_manager_lock:
            if _ttl_manager is None:
                _ttl_manager = TTLManager()
    return _ttl_manager
