"""Memory tier management for Endless Mode (biomimetic stack)."""

import logging
from typing import Any

from falkordb_memory_server.config import get_settings
from falkordb_memory_server.graph_ops import GraphOperations, get_graph_ops
from falkordb_memory_server.schema import MemoryTier

logger = logging.getLogger(__name__)


class TierManager:
    """Manage memory tiers (L0-L3) and their promotion/demotion."""

    def __init__(self, ops: GraphOperations | None = None) -> None:
        """Initialize Tier manager."""
        self.ops = ops or get_graph_ops()
        self.settings = get_settings()

    def set_tier(self, node_id: int | str, tier: MemoryTier | int) -> bool:
        """
        Explicitly set the tier of a memory node.

        Args:
            node_id: ID of the memory node (internal int or property id)
            tier: The tier to set (0-3)

        Returns:
            Success status
        """
        tier_val = int(tier)
        if tier_val < 0 or tier_val > 3:
            raise ValueError(f"Invalid tier: {tier_val}. Must be 0-3.")

        if isinstance(node_id, int):
            cypher = "MATCH (n) WHERE id(n) = $id SET n.tier = $tier RETURN id(n)"
        else:
            cypher = "MATCH (n) WHERE n.id = $id SET n.tier = $tier RETURN id(n)"

        result = self.ops.query(cypher, {"id": node_id, "tier": tier_val})
        return len(result.get("result_set", [])) > 0

    def promote(self, node_id: int | str) -> bool:
        """
        Promote a memory to the next tier (e.g., L1 -> L2).

        Args:
            node_id: ID of the memory node

        Returns:
            Success status
        """
        if isinstance(node_id, int):
            match_clause = "WHERE id(n) = $id"
        else:
            match_clause = "WHERE n.id = $id"

        cypher = f"""
        MATCH (n)
        {match_clause}
        WITH n, COALESCE(n.tier, 1) as current_tier
        WHERE current_tier < 3
        SET n.tier = current_tier + 1
        RETURN n.tier as new_tier
        """

        result = self.ops.query(cypher, {"id": node_id})
        return len(result.get("result_set", [])) > 0

    def demote(self, node_id: int | str) -> bool:
        """
        Demote a memory to the previous tier (e.g., L2 -> L1).

        Args:
            node_id: ID of the memory node

        Returns:
            Success status
        """
        if isinstance(node_id, int):
            match_clause = "WHERE id(n) = $id"
        else:
            match_clause = "WHERE n.id = $id"

        cypher = f"""
        MATCH (n)
        {match_clause}
        WITH n, COALESCE(n.tier, 1) as current_tier
        WHERE current_tier > 0
        SET n.tier = current_tier - 1
        RETURN n.tier as new_tier
        """

        result = self.ops.query(cypher, {"id": node_id})
        return len(result.get("result_set", [])) > 0

    def get_memories_by_tier(
        self, tier: MemoryTier | int, limit: int = 100
    ) -> list[dict[str, Any]]:
        """
        Retrieve memories in a specific tier.

        Args:
            tier: Memory tier (0-3)
            limit: Maximum results

        Returns:
            List of memory nodes
        """
        cypher = """
        MATCH (n)
        WHERE n.tier = $tier AND n.valid_to IS NULL
        RETURN n
        ORDER BY n.created_at DESC
        LIMIT $limit
        """
        result = self.ops.query(cypher, {"tier": int(tier), "limit": limit}, read_only=True)
        return [row[0] for row in result.get("result_set", [])]

    def get_tier_stats(self) -> dict[str, int]:
        """
        Get count of memories in each tier.

        Returns:
            Dictionary mapping tier level to node count
        """
        cypher = """
        MATCH (n)
        WHERE n.tier IS NOT NULL
        RETURN n.tier as tier, count(n) as count
        """
        result = self.ops.query(cypher, read_only=True)
        stats = {0: 0, 1: 0, 2: 0, 3: 0}
        for row in result.get("result_set", []):
            stats[int(row[0])] = row[1]
        return stats

    def consolidate_session(self, session_id: str) -> dict[str, Any]:
        """
        Consolidate memories from a finished session (L1) into project scope (L2).
        By default, moves all L1 memories associated with the session to L2.

        Args:
            session_id: ID of the session to consolidate

        Returns:
            Consolidation statistics
        """
        cypher = """
        MATCH (s:Session {id: $session_id})<-[:OCCURRED_IN]-(m)
        WHERE m.tier = 1
        SET m.tier = 2
        RETURN count(m) as promoted_count
        """
        result = self.ops.query(cypher, {"session_id": session_id})
        count = result.get("result_set", [[0]])[0][0]
        return {"session_id": session_id, "promoted_count": count}


# Global instance
_tier_manager: TierManager | None = None


def get_tier_manager() -> TierManager:
    """Get the global TierManager instance."""
    global _tier_manager
    if _tier_manager is None:
        _tier_manager = TierManager()
    return _tier_manager
