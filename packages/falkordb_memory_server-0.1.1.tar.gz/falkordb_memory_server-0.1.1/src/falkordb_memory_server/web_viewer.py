"""Web Viewer for FalkorDB Memory Graph."""

import logging
import os

import uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse

from falkordb_memory_server.graph_ops import get_graph_ops

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="FalkorDB Memory Graph Viewer")


@app.get("/", response_class=HTMLResponse)
async def get_viewer():
    """Serve the single-page HTML viewer."""
    html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FalkorDB Memory Graph Viewer</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            overflow: hidden;
            background-color: #f8f9fa;
            color: #212529;
        }
        #controls {
            position: absolute;
            top: 20px;
            left: 20px;
            z-index: 100;
            background: rgba(255, 255, 255, 0.95);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            max-width: 320px;
            border: 1px solid #dee2e6;
        }
        #graph {
            width: 100vw;
            height: 100vh;
            cursor: grab;
        }
        #graph:active {
            cursor: grabbing;
        }
        .node {
            stroke: #fff;
            stroke-width: 2px;
            cursor: pointer;
            transition: r 0.2s;
        }
        .node:hover {
            stroke: #333;
        }
        .link {
            stroke: #adb5bd;
            stroke-opacity: 0.5;
            stroke-width: 1.5px;
            fill: none;
        }
        .label {
            font-size: 11px;
            pointer-events: none;
            fill: #495057;
            font-weight: 500;
        }
        #tooltip {
            position: absolute;
            visibility: hidden;
            background: #212529;
            color: #fff;
            padding: 12px;
            border-radius: 8px;
            font-size: 13px;
            pointer-events: none;
            z-index: 1000;
            max-width: 350px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            opacity: 0.95;
        }
        #tooltip pre {
            margin: 8px 0 0 0;
            white-space: pre-wrap;
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
            font-size: 11px;
            background: rgba(255,255,255,0.1);
            padding: 8px;
            border-radius: 4px;
        }
        h1 {
            margin: 0 0 10px 0;
            font-size: 20px;
            color: #007bff;
            display: flex;
            align-items: center;
        }
        .status-container {
            margin-bottom: 15px;
            font-size: 13px;
            color: #6c757d;
        }
        .legend {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        .legend-title {
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            color: #adb5bd;
            margin-bottom: 10px;
        }
        .legend-item {
            display: flex;
            align-items: center;
            margin-bottom: 6px;
            font-size: 12px;
        }
        .legend-color {
            width: 14px;
            height: 14px;
            border-radius: 4px;
            margin-right: 10px;
            flex-shrink: 0;
        }
        .btn-refresh {
            display: block;
            width: 100%;
            background: #007bff;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 6px;
            cursor: pointer;
            margin-top: 20px;
            font-weight: 600;
            transition: background 0.2s;
        }
        .btn-refresh:hover {
            background: #0056b3;
        }
        .node-highlight {
            stroke: #000 !important;
            stroke-width: 3px !important;
        }
        .link-highlight {
            stroke: #007bff !important;
            stroke-opacity: 1 !important;
            stroke-width: 2.5px !important;
        }
    </style>
</head>
<body>
    <div id="controls">
        <h1>FalkorDB Memory</h1>
        <div class="status-container" id="status">Connecting to database...</div>

        <div class="legend">
            <div class="legend-title">Categories</div>
            <div id="legend-items"></div>
        </div>

        <button class="btn-refresh" onclick="refreshGraph()">Refresh View</button>
    </div>

    <div id="tooltip"></div>
    <svg id="graph"></svg>

    <script>
        const colorPalette = {
            "Session": "#4e79a7",
            "Agent": "#f28e2c",
            "Decision": "#e15759",
            "Learning": "#76b7b2",
            "Code": "#59a14f",
            "Concept": "#edc949",
            "Project": "#af7aa1",
            "Task": "#ff9da7",
            "Artifact": "#9c755f",
            "Problem": "#bab0ab",
            "Solution": "#86bc25",
            "Pattern": "#b07aa1",
            "Dependency": "#17becf"
        };

        const svg = d3.select("#graph");
        const tooltip = d3.select("#tooltip");
        const container = svg.append("g");

        let width = window.innerWidth;
        let height = window.innerHeight;

        const simulation = d3.forceSimulation()
            .force("link", d3.forceLink().id(d => d.id).distance(120))
            .force("charge", d3.forceManyBody().strength(-400))
            .force("center", d3.forceCenter(width / 2, height / 2))
            .force("x", d3.forceX(width / 2).strength(0.1))
            .force("y", d3.forceY(height / 2).strength(0.1))
            .force("collision", d3.forceCollide().radius(60));

        // Zoom setup
        const zoom = d3.zoom()
            .scaleExtent([0.1, 8])
            .on("zoom", (event) => {
                container.attr("transform", event.transform);
            });

        svg.call(zoom);

        async function refreshGraph() {
            const statusEl = document.getElementById("status");
            statusEl.innerText = "Refreshing graph data...";

            try {
                const response = await fetch("/api/graph");
                if (!response.ok) throw new Error("Failed to fetch graph data");

                const data = await response.json();
                render(data);
                statusEl.innerText = `Connected: ${data.nodes.length} nodes, ${data.links.length} relationships`;
            } catch (err) {
                console.error(err);
                statusEl.innerText = "Error: " + err.message;
                statusEl.style.color = "#dc3545";
            }
        }

        function render(data) {
            // Update legend
            const labels = [...new Set(data.nodes.map(n => n.label))].sort();
            const legendItems = d3.select("#legend-items");
            legendItems.selectAll("*").remove();

            labels.forEach(l => {
                const item = legendItems.append("div").attr("class", "legend-item");
                item.append("div")
                    .attr("class", "legend-color")
                    .style("background-color", colorPalette[l] || "#adb5bd");
                item.append("span").text(l);
            });

            // Clear previous elements
            container.selectAll("*").remove();

            // Arrow marker for directed edges
            container.append("defs").selectAll("marker")
                .data(["arrow"])
                .enter().append("marker")
                .attr("id", d => d)
                .attr("viewBox", "0 -5 10 10")
                .attr("refX", 25)
                .attr("refY", 0)
                .attr("markerWidth", 6)
                .attr("markerHeight", 6)
                .attr("orient", "auto")
                .append("path")
                .attr("fill", "#adb5bd")
                .attr("d", "M0,-5L10,0L0,5");

            // Links
            const link = container.append("g")
                .attr("class", "links")
                .selectAll("line")
                .data(data.links)
                .enter().append("line")
                .attr("class", "link")
                .attr("marker-end", "url(#arrow)");

            // Nodes
            const node = container.append("g")
                .attr("class", "nodes")
                .selectAll("circle")
                .data(data.nodes)
                .enter().append("circle")
                .attr("class", "node")
                .attr("r", d => {
                    const base = 10;
                    if (d.label === 'Session') return base + 5;
                    if (d.label === 'Project') return base + 8;
                    return base;
                })
                .attr("fill", d => colorPalette[d.label] || "#adb5bd")
                .call(d3.drag()
                    .on("start", dragstarted)
                    .on("drag", dragged)
                    .on("end", dragended))
                .on("mouseover", (event, d) => {
                    highlightNode(d, data.links);
                    tooltip.style("visibility", "visible")
                        .html(`<strong>${d.label}</strong> (ID: ${d.id})<pre>${JSON.stringify(d.properties, null, 2)}</pre>`);
                })
                .on("mousemove", (event) => {
                    tooltip.style("top", (event.pageY - 10) + "px").style("left", (event.pageX + 20) + "px");
                })
                .on("mouseout", () => {
                    unhighlight();
                    tooltip.style("visibility", "hidden");
                });

            // Labels
            const label = container.append("g")
                .attr("class", "labels")
                .selectAll("text")
                .data(data.nodes)
                .enter().append("text")
                .attr("class", "label")
                .attr("dy", ".35em")
                .attr("dx", 15)
                .text(d => {
                    const p = d.properties;
                    return p.title || p.name || p.content || p.id;
                });

            simulation.nodes(data.nodes).on("tick", () => {
                link
                    .attr("x1", d => d.source.x)
                    .attr("y1", d => d.source.y)
                    .attr("x2", d => d.target.x)
                    .attr("y2", d => d.target.y);

                node
                    .attr("cx", d => d.x)
                    .attr("cy", d => d.y);

                label
                    .attr("x", d => d.x)
                    .attr("y", d => d.y);
            });

            simulation.force("link").links(data.links);
            simulation.alpha(1).restart();
        }

        function highlightNode(d, links) {
            const connectedNodeIds = new Set();
            connectedNodeIds.add(d.id);

            d3.selectAll(".link").classed("link-highlight", l => {
                if (l.source.id === d.id || l.target.id === d.id) {
                    connectedNodeIds.add(l.source.id);
                    connectedNodeIds.add(l.target.id);
                    return true;
                }
                return false;
            });

            d3.selectAll(".node").classed("node-highlight", n => connectedNodeIds.has(n.id));
        }

        function unhighlight() {
            d3.selectAll(".link").classed("link-highlight", false);
            d3.selectAll(".node").classed("node-highlight", false);
        }

        function dragstarted(event, d) {
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
        }

        function dragged(event, d) {
            d.fx = event.x;
            d.fy = event.y;
        }

        function dragended(event, d) {
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
        }

        window.addEventListener("resize", () => {
            width = window.innerWidth;
            height = window.innerHeight;
            simulation.force("center", d3.forceCenter(width / 2, height / 2));
            simulation.alpha(0.3).restart();
        });

        refreshGraph();
    </script>
</body>
</html>
    """
    return html_content


@app.get("/api/graph")
async def get_graph_data():
    """Fetch all nodes and edges from FalkorDB and return in D3-friendly format."""
    ops = get_graph_ops()

    # Query all nodes
    # We return n as properties, but ops.query will already have parsed it via _parse_result_set
    nodes_query = "MATCH (n) RETURN id(n) as id, labels(n)[0] as label, n as properties"
    try:
        nodes_result = ops.query(nodes_query)

        nodes = []
        for row in nodes_result.get("result_set", []):
            if len(row) >= 3:
                node_id, label, props = row[0], row[1], row[2]
                # If props is a dict with 'properties', extract them
                if isinstance(props, dict) and "properties" in props:
                    props = props["properties"]

                nodes.append({"id": node_id, "label": label, "properties": props})

        # Query all edges
        edges_query = "MATCH (a)-[r]->(b) RETURN id(a) as source, id(b) as target, type(r) as type, r as properties"
        edges_result = ops.query(edges_query)

        links = []
        for row in edges_result.get("result_set", []):
            if len(row) >= 4:
                source, target, rel_type, props = row[0], row[1], row[2], row[3]
                if isinstance(props, dict) and "properties" in props:
                    props = props["properties"]

                links.append(
                    {"source": source, "target": target, "type": rel_type, "properties": props}
                )

        return {"nodes": nodes, "links": links}
    except Exception as e:
        logger.error(f"Failed to fetch graph data: {e}")
        return {"nodes": [], "links": [], "error": str(e)}


def main():
    """Entry point for the web viewer."""
    port = int(os.environ.get("PORT", 37777))
    logger.info(f"Starting FalkorDB Memory Web Viewer on http://localhost:{port}")
    uvicorn.run(app, host="0.0.0.0", port=port)


if __name__ == "__main__":
    main()
