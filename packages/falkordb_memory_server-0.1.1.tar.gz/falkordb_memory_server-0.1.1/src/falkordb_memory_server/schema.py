"""Graph schema definitions for the memory system."""

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class NodeLabel(str, Enum):
    """Node labels in the memory graph."""

    SESSION = "Session"
    AGENT = "Agent"
    DECISION = "Decision"
    LEARNING = "Learning"
    CODE = "Code"
    CONCEPT = "Concept"
    PROJECT = "Project"
    TASK = "Task"
    ARTIFACT = "Artifact"
    PROBLEM = "Problem"
    SOLUTION = "Solution"
    PATTERN = "Pattern"
    DEPENDENCY = "Dependency"
    CONVENTION = "Convention"
    REFACTOR = "Refactor"
    TEST = "Test"
    API = "API"
    REVIEW = "Review"


class MemoryTier(int, Enum):
    """Memory tiers for Endless Mode (biomimetic stack)."""

    L0 = 0  # Active context (Current conversation/task)
    L1 = 1  # Short term / session (Current session)
    L2 = 2  # Project scope (Current project)
    L3 = 3  # Global (Across all projects/sessions)


class RelationType(str, Enum):
    """Relationship types in the memory graph."""

    # Temporal/Session
    STARTED_BY = "STARTED_BY"
    CONTINUES = "CONTINUES"
    OCCURRED_IN = "OCCURRED_IN"

    # Causal/Dependent
    LED_TO = "LED_TO"
    DEPENDS_ON = "DEPENDS_ON"
    DERIVED_FROM = "DERIVED_FROM"
    SOLVED_BY = "SOLVED_BY"

    # Structural
    CONTAINS = "CONTAINS"
    IMPLEMENTS = "IMPLEMENTS"
    USES = "USES"
    HAS_CONVENTION = "HAS_CONVENTION"

    # Knowledge
    KNOWS = "KNOWS"
    RELATED_TO = "RELATED_TO"
    SIMILAR_TO = "SIMILAR_TO"

    # Memory
    REMEMBERS = "REMEMBERS"
    DISCOVERED = "DISCOVERED"
    APPLIED = "APPLIED"
    CHANGED = "CHANGED"
    COVERS = "COVERS"
    CALLED_WITH = "CALLED_WITH"
    REVIEWS = "REVIEWS"

    # Sharing
    SHARED_WITH = "SHARED_WITH"


class MemoryType(str, Enum):
    """Types of memory content."""

    LEARNING = "learning"
    DECISION = "decision"
    CODE = "code"
    CONCEPT = "concept"
    TASK = "task"
    PROBLEM = "problem"
    SOLUTION = "solution"
    PATTERN = "pattern"
    DEPENDENCY = "dependency"
    CONVENTION = "convention"
    REFACTOR = "refactor"
    TEST = "test"
    API = "api"
    REVIEW = "review"


# ============================================================
# Node Property Schemas
# ============================================================


class SessionProperties(BaseModel):
    """Properties for Session nodes."""

    id: str = Field(..., description="Unique session identifier")
    agent_type: str = Field(..., description="Type of agent: claude, codex, gemini")
    agent_id: str = Field(..., description="Agent instance identifier")
    project_path: str | None = Field(None, description="Working directory")
    started_at: str = Field(..., description="Session start timestamp (ISO format)")
    ended_at: str | None = Field(None, description="Session end timestamp")
    status: str = Field("active", description="Session status: active, completed, abandoned")
    objective: str | None = Field(None, description="Session goal")
    ttl: int | None = Field(None, description="TTL in seconds")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional context")


class AgentProperties(BaseModel):
    """Properties for Agent nodes."""

    id: str = Field(..., description="Unique agent identifier")
    type: str = Field(..., description="Agent type: claude, codex, gemini")
    name: str = Field(..., description="Agent name")
    capabilities: list[str] = Field(default_factory=list, description="Agent capabilities")
    preferences: dict[str, Any] = Field(default_factory=dict, description="Agent preferences")
    first_seen: str = Field(..., description="First seen timestamp")
    last_active: str = Field(..., description="Last active timestamp")


class DecisionProperties(BaseModel):
    """Properties for Decision nodes."""

    id: str = Field(..., description="Unique decision identifier")
    type: str = Field(
        ..., description="Decision type: architecture, implementation, refactor, etc."
    )
    context: str = Field(..., description="What led to this decision")
    rationale: str = Field(..., description="Why this choice was made")
    alternatives: list[str] = Field(default_factory=list, description="Options considered")
    outcome: str | None = Field(None, description="Result of the decision")
    confidence: float = Field(0.8, ge=0.0, le=1.0, description="Confidence level")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class LearningProperties(BaseModel):
    """Properties for Learning nodes."""

    id: str = Field(..., description="Unique learning identifier")
    category: str = Field(..., description="Category: pattern, anti-pattern, tip, insight")
    title: str = Field(..., description="Learning title")
    content: str = Field(..., description="Learning content")
    tags: list[str] = Field(default_factory=list, description="Tags for categorization")
    applicability: str | None = Field(None, description="When to apply this learning")
    source: str | None = Field(None, description="Where this came from")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    last_applied: str | None = Field(None, description="Last application timestamp")
    application_count: int = Field(0, ge=0, description="Number of times applied")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class CodeProperties(BaseModel):
    """Properties for Code nodes."""

    id: str = Field(..., description="Unique code identifier")
    path: str | None = Field(None, description="File path")
    language: str | None = Field(None, description="Programming language")
    name: str = Field(..., description="Function/class/module name")
    type: str = Field(..., description="Type: function, class, module, file")
    content: str = Field(..., description="Code snippet or content")
    description: str | None = Field(None, description="Code description")
    hash: str | None = Field(None, description="Content hash for deduplication")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class ConceptProperties(BaseModel):
    """Properties for Concept nodes."""

    id: str = Field(..., description="Unique concept identifier")
    name: str = Field(..., description="Concept name")
    description: str | None = Field(None, description="Concept description")
    category: str | None = Field(None, description="Concept category")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class ProblemProperties(BaseModel):
    """Properties for Problem nodes."""

    id: str = Field(..., description="Unique problem identifier")
    error: str = Field(..., description="Error message or description")
    category: str = Field(..., description="Problem category: bug, crash, timeout, etc.")
    context: str | None = Field(None, description="Context where the problem occurred")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class SolutionProperties(BaseModel):
    """Properties for Solution nodes."""

    id: str = Field(..., description="Unique solution identifier")
    fix: str = Field(..., description="Description of the fix")
    code: str | None = Field(None, description="Code snippet for the fix")
    explanation: str | None = Field(None, description="Why this fix works")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class TaskProperties(BaseModel):
    """Properties for Task nodes."""

    id: str = Field(..., description="Unique task identifier")
    title: str = Field(..., description="Task title")
    description: str | None = Field(None, description="Task description")
    status: str = Field("todo", description="Task status: todo, in_progress, completed, abandoned")
    priority: str = Field("medium", description="Task priority: low, medium, high, critical")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    due_date: str | None = Field(None, description="Task due date")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class ProjectProperties(BaseModel):
    """Properties for Project nodes."""

    id: str = Field(..., description="Unique project identifier")
    name: str = Field(..., description="Project name")
    path: str = Field(..., description="Project root directory path")
    description: str | None = Field(None, description="Project description")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")


class ArtifactProperties(BaseModel):
    """Properties for Artifact nodes."""

    id: str = Field(..., description="Unique artifact identifier")
    name: str = Field(..., description="Artifact name")
    type: str = Field(..., description="Artifact type: document, image, data, etc.")
    path: str | None = Field(None, description="File path to the artifact")
    description: str | None = Field(None, description="Artifact description")
    hash: str | None = Field(None, description="Content hash for deduplication/incremental check")
    mtime: float | None = Field(None, description="Last modification time")
    last_mined: str | None = Field(None, description="Last mining timestamp (ISO format)")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class DependencyProperties(BaseModel):
    """Properties for Dependency nodes."""

    id: str = Field(..., description="Unique dependency identifier")
    name: str = Field(..., description="Dependency name")
    version: str | None = Field(None, description="Version")
    description: str | None = Field(None, description="What the dependency does")
    rationale: str | None = Field(None, description="Why this was chosen")
    alternatives: list[str] = Field(default_factory=list, description="Alternatives considered")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class PatternProperties(BaseModel):
    """Properties for Pattern nodes."""

    id: str = Field(..., description="Unique pattern identifier")
    type: str = Field(..., description="Pattern type (e.g., singleton, observer, jwt-validation)")
    description: str | None = Field(None, description="Pattern description")
    code: str | None = Field(None, description="Example code snippet")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class ConventionProperties(BaseModel):
    """Properties for Convention nodes."""

    id: str = Field(..., description="Unique convention identifier")
    type: str = Field(..., description="Convention type: naming, style, docstring, etc.")
    name: str = Field(..., description="Convention name")
    description: str = Field(..., description="Convention description/rule")
    pattern: str | None = Field(None, description="Regex or pattern example")
    example: str | None = Field(None, description="Correct example")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class RefactorProperties(BaseModel):
    """Properties for Refactor nodes."""

    id: str = Field(..., description="Unique refactor identifier")
    description: str = Field(..., description="Description of the refactoring")
    target: str = Field(..., description="What was refactored (file, function, etc.)")
    before: str | None = Field(None, description="Before state")
    after: str | None = Field(None, description="After state")
    rationale: str | None = Field(None, description="Why the refactor was performed")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class TestProperties(BaseModel):
    """Properties for Test nodes."""

    id: str = Field(..., description="Unique test identifier")
    name: str = Field(..., description="Test name")
    type: str = Field(..., description="Test type: unit, integration, e2e, etc.")
    target: str = Field(..., description="What is being tested")
    content: str | None = Field(None, description="Test code or description")
    status: str | None = Field(None, description="Test status: passing, failing, etc.")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class APIProperties(BaseModel):
    """Properties for API nodes."""

    id: str = Field(..., description="Unique API identifier")
    name: str = Field(..., description="API name or endpoint")
    method: str | None = Field(None, description="HTTP method if applicable")
    description: str | None = Field(None, description="API description")
    parameters: dict[str, Any] = Field(default_factory=dict, description="API parameters")
    returns: str | None = Field(None, description="Return value or response schema")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


class ReviewProperties(BaseModel):
    """Properties for Review nodes."""

    id: str = Field(..., description="Unique review identifier")
    target: str = Field(..., description="What was reviewed")
    comments: str = Field(..., description="Review comments")
    status: str | None = Field(None, description="Review status: approved, requested_changes, etc.")
    reviewer: str | None = Field(None, description="Reviewer identifier")
    created_at: str = Field(..., description="Creation timestamp")
    valid_from: str | None = Field(None, description="Start of temporal validity (ISO format)")
    valid_to: str | None = Field(None, description="End of temporal validity (ISO format)")
    embedding: list[float] | None = Field(None, description="Semantic embedding vector")


# ============================================================
# Request/Response Schemas
# ============================================================


class CreateNodeRequest(BaseModel):
    """Request for creating a node."""

    label: NodeLabel | str = Field(..., description="Node label")
    properties: dict[str, Any] = Field(default_factory=dict, description="Node properties")
    return_node: bool = Field(True, description="Return created node")


class CreateEdgeRequest(BaseModel):
    """Request for creating a relationship."""

    from_id: int | str = Field(..., description="Source node ID")
    relation: RelationType | str = Field(..., description="Relationship type")
    to_id: int | str = Field(..., description="Target node ID")
    properties: dict[str, Any] = Field(default_factory=dict, description="Edge properties")


class QueryRequest(BaseModel):
    """Request for executing a Cypher query."""

    query: str = Field(..., description="Cypher query string")
    params: dict[str, Any] = Field(default_factory=dict, description="Query parameters")
    read_only: bool = Field(False, description="Read-only mode")


class DeleteRequest(BaseModel):
    """Request for deleting nodes."""

    node_ids: list[int | str] = Field(..., description="Node IDs to delete")
    cascade: bool = Field(False, description="Delete connected edges")


class RememberRequest(BaseModel):
    """Request for storing a memory."""

    memory_type: MemoryType = Field(..., description="Type of memory")
    content: dict[str, Any] = Field(..., description="Memory content (type-specific)")
    context: dict[str, Any] = Field(default_factory=dict, description="Session/project context")
    ttl: int | None = Field(None, description="TTL in seconds")
    tier: MemoryTier | int | None = Field(None, description="Memory tier (L0-L3)")
    generate_embedding: bool = Field(True, description="Generate semantic embedding")


class RecallRequest(BaseModel):
    """Request for recalling memories."""

    query_type: str = Field("semantic", description="Query type: semantic, text, cypher, traversal")
    query: str = Field(..., description="Query string or Cypher")
    filters: dict[str, Any] = Field(default_factory=dict, description="Property filters")
    limit: int = Field(10, ge=1, le=1000, description="Max results")
    include_context: bool = Field(True, description="Include related nodes")
    include_invalid: bool = Field(False, description="Include facts marked as invalid")
