"""Memory extraction from conversations and tool usage.

Inspired by:
- MemPalace: Rule-based extraction with zero API calls
- Claude-Mem: AI-powered compression for complex context

This module provides:
1. Rule-based extraction (default, zero cost)
2. Optional AI compression (for complex scenarios)
3. Batch import for conversations and project files
"""

import hashlib
import json
import os
import re
from collections.abc import Callable
from enum import Enum
from pathlib import Path
from typing import Any

import httpx
from pydantic import BaseModel, Field

from falkordb_memory_server.config import get_settings


class MemoryCategory(str, Enum):
    """Types of extractable memories."""

    DECISION = "decision"  # Choices made, trade-offs
    PREFERENCE = "preference"  # Always/never, coding style
    MILESTONE = "milestone"  # Breakthroughs, achievements
    PROBLEM = "problem"  # Bugs, issues, failures
    EMOTIONAL = "emotional"  # Feelings, relationships
    LEARNING = "learning"  # Insights, patterns
    SOLUTION = "solution"  # Fixes, resolutions for problems
    CONTEXT = "context"  # Project context, conventions, configs
    CONVENTION = "convention"  # Coding standards, naming patterns
    DEPENDENCY = "dependency"  # Library/dependency choices
    REFACTOR = "refactor"  # Refactoring changes
    TEST = "test"  # Testing information, coverage
    API = "api"  # API definitions, calls
    REVIEW = "review"  # Code review comments
    TASK = "task"  # Todos, actionable items, schedules
    GENERAL = "general"  # Default category


class ExtractionMode(str, Enum):
    """Extraction mode for adapting to different contexts."""

    PROGRAMMING = "programming"
    OFFICE = "office"
    LIFE = "life"


# ============================================================
# Utilities
# ============================================================


def compute_file_hash(file_path: str | Path) -> str:
    """Compute SHA256 hash of a file."""
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            sha256.update(chunk)
    return sha256.hexdigest()


# ============================================================
# Marker Patterns (from MemPalace)
# ============================================================

DECISION_MARKERS = [
    # English patterns
    r"\blet'?s (use|go with|try|pick|choose|switch to)\b",
    r"\bwe (should|decided|chose|went with|picked|settled on)\b",
    r"\bi'?m going (to|with)\b",
    r"\bbetter (to|than|approach|option|choice)\b",
    r"\binstead of\b",
    r"\brather than\b",
    r"\bthe reason (is|was|being)\b",
    r"\bbecause\b",
    r"\btrade-?off\b",
    r"\bpros and cons\b",
    r"\barchitecture\b",
    r"\bapproach\b",
    r"\bstrategy\b",
    r"\bpattern\b",
    r"\bstack\b",
    r"\bframework\b",
    r"\binfrastructure\b",
    r"\bset (it |this )?to\b",
    r"\bconfigure\b",
    r"\bdefault\b",
    r"\bmigrated\b",
    r"\badopted\b",
    # Chinese patterns
    r"我们决定",
    r"决定使用",
    r"选择了",
    r"采用",
    r"切换到",
    r"迁移到",
    r"因为",
    r"原因是",
    r"权衡",
    r"架构",
    r"方案",
    r"策略",
    r"模式",
    r"而不是",
    r"比起.*更好",
    r"最佳选择",
    r"最终选择",
]

PREFERENCE_MARKERS = [
    # English patterns
    r"\bi prefer\b",
    r"\balways use\b",
    r"\bnever use\b",
    r"\bdon'?t (ever |like to )?(use|do|mock|stub|import)\b",
    r"\bi like (to|when|how)\b",
    r"\bi hate (when|how|it when)\b",
    r"\bplease (always|never|don'?t)\b",
    r"\bmy (rule|preference|style|convention) is\b",
    r"\bwe (always|never)\b",
    r"\bfunctional\b.*\bstyle\b",
    r"\bsnake_?case\b",
    r"\bcamel_?case\b",
    r"\buse\b.*\binstead of\b",
    r"\bbest practice\b",
    # Chinese patterns
    r"我倾向",
    r"我偏好",
    r"我更喜欢",
    r"总是使用",
    r"从不使用",
    r"不要使用",
    r"建议使用",
    r"建议",
    r"最佳实践",
    r"代码风格",
    r"命名规范",
    r"习惯",
    r"倾向",
    r"偏好",
]

MILESTONE_MARKERS = [
    # English patterns
    r"\bit works\b",
    r"\bit worked\b",
    r"\bgot it working\b",
    r"\bfixed\b",
    r"\bsolved\b",
    r"\bbreakthrough\b",
    r"\bfigured (it )?out\b",
    r"\bnailed it\b",
    r"\bcracked (it|the)\b",
    r"\bfinally\b",
    r"\bfirst time\b",
    r"\bfirst ever\b",
    r"\bnever (done|been|had) before\b",
    r"\bdiscovered\b",
    r"\brealized\b",
    r"\bfound (out|that)\b",
    r"\bturns out\b",
    r"\bthe key (is|was|insight)\b",
    r"\bthe trick (is|was)\b",
    r"\bnow i (understand|see|get it)\b",
    r"\bbuilt\b",
    r"\bcreated\b",
    r"\bimplemented\b",
    r"\bshipped\b",
    r"\blaunched\b",
    r"\bdeployed\b",
    r"\breleased\b",
    r"\bcompleted\b",
    r"\bdone\b",
    # Chinese patterns
    r"成功了",
    r"修复了",
    r"解决了",
    r"搞定了",
    r"完成了",
    r"实现了",
    r"部署了",
    r"发布了",
    r"突破了",
    r"第一次",
    r"终于",
    r"发现",
    r"关键",
    r"技巧",
    r"搞定",
    r"上线",
    r"上线了",
    r"很高兴",
    r"太好了",
    r"太棒了",
]

PROBLEM_MARKERS = [
    # English patterns
    r"\b(bug|error|crash|fail|broke|broken|issue|problem)\b",
    r"\bdoesn'?t work\b",
    r"\bnot working\b",
    r"\bwon'?t\b.*\bwork\b",
    r"\bkeeps? (failing|crashing|breaking|erroring)\b",
    r"\broot cause\b",
    r"\bthe (problem|issue|bug) (is|was)\b",
    r"\bturns out\b.*\b(was|because|due to)\b",
    r"\bthe fix (is|was)\b",
    r"\bworkaround\b",
    r"\bthat'?s why\b",
    r"\bthe reason it\b",
    r"\bfixed (it |the |by )\b",
    r"\bsolution (is|was)\b",
    r"\bresolved\b",
    r"\bpatched\b",
    r"\bthe answer (is|was)\b",
    r"\b(had|need) to\b.*\binstead\b",
    r"\bdebugging\b",
    r"\btroubleshoot\b",
    # Chinese patterns
    r"错误",
    r"崩溃",
    r"失败",
    r"问题",
    r"Bug",
    r"不工作",
    r"无法",
    r"报错",
    r"异常",
    r"故障",
    r"根本原因",
    r"解决方案",
    r"修复",
    r"解决",
    r"调试",
    r"排查",
    r"调试后",
    r"原因",
    r"问题",
    r"修复",
]

EMOTIONAL_MARKERS = [
    # English patterns
    r"\blove\b",
    r"\bscared\b",
    r"\bafraid\b",
    r"\bproud\b",
    r"\bhurt\b",
    r"\bhappy\b",
    r"\bsad\b",
    r"\bcry\b",
    r"\bcrying\b",
    r"\bmiss\b",
    r"\bsorry\b",
    r"\bgrateful\b",
    r"\bangry\b",
    r"\bworried\b",
    r"\blonely\b",
    r"\bbeautiful\b",
    r"\bamazing\b",
    r"\bwonderful\b",
    r"\bexcited\b",
    r"\bfrustrated\b",
    r"\boverwhelmed\b",
    r"i feel",
    r"i'm (scared|happy|sad|angry|worried|excited)",
    r"i love you",
    r"i'm sorry",
    r"i wish",
    r"i miss",
    r"i need",
    r"\*[^*]+\*",  # *emotion* markers
    # Chinese patterns
    r"喜欢",
    r"爱",
    r"开心",
    r"高兴",
    r"难过",
    r"伤心",
    r"生气",
    r"愤怒",
    r"担心",
    r"焦虑",
    r"害怕",
    r"恐惧",
    r"骄傲",
    r"自豪",
    r"沮丧",
    r"失望",
    r"兴奋",
    r"激动",
    r"感谢",
    r"感激",
    r"抱歉",
    r"遗憾",
    r"太棒了",
    r"太好了",
    r"烦人",
    r"烦死了",
]

LEARNING_MARKERS = [
    # English patterns
    r"\blearned\b",
    r"\blearnt\b",
    r"\binsight\b",
    r"\bpattern\b",
    r"\banti-?pattern\b",
    r"\blesson\b",
    r"\btip\b",
    r"\badvice\b",
    r"\brecommend(ation)?\b",
    r"\bremember\b",
    r"\bnote that\b",
    r"\bimportant\b",
    r"\bkey (point|thing|insight)\b",
    r"\bmake sure\b",
    r"\bdon'?t forget\b",
    r"\bwarning\b",
    r"\bcaution\b",
    # Chinese patterns
    r"学到",
    r"学习",
    r"经验",
    r"教训",
    r"技巧",
    r"建议",
    r"推荐",
    r"记住",
    r"注意",
    r"重要",
    r"关键",
    r"不要忘记",
    r"警告",
    r"心得",
    r"总结",
    r"发现.*规律",
    r"洞察",
    r"明白",
    r"理解",
    r"掌握",
    # Code/Technical patterns
    r"TODO",
    r"FIXME",
    r"HACK",
    r"NOTE",
    r"Note:",
    r"note:",
]

SOLUTION_MARKERS = [
    # English patterns
    r"\bthe fix (is|was)\b",
    r"\bworkaround\b",
    r"\bresolved by\b",
    r"\bsolved by\b",
    r"\bsolution (is|was)\b",
    r"\bfixed by\b",
    r"\bpatch\b",
    r"\bapplied fix\b",
    # Chinese patterns
    r"解决方案是",
    r"修复方法",
    r"通过.*修复",
    r"通过.*解决",
    r"补丁",
    r"解决方法",
]

CONTEXT_MARKERS = [
    # English patterns
    r"\bconfig(uration)?\b",
    r"\bsetting\b",
    r"\benvironment\b",
    r"\bworkflow\b",
    # Chinese patterns
    r"配置",
    r"设置",
    r"环境",
    r"流程",
]

CONVENTION_MARKERS = [
    # English patterns
    r"\bconventions?\b",
    r"\bstandards?\b",
    r"\brules?\b",
    r"\bguidelines?\b",
    r"\bpreferences?\b",
    r"\bstyles?\b",
    r"\blints?\b",
    r"\bformats?\b",
    r"\bnaming\b",
    # Chinese patterns
    r"规范",
    r"标准",
    r"规则",
    r"指南",
    r"偏好",
    r"约定",
    r"风格",
    r"命名",
]

DEPENDENCY_MARKERS = [
    # English patterns
    r"\b(add|install|use|import|depend|require|using)(s|ed|ing)?\b.*\b(library|package|dependency|module|sdk|framework|tool|plugin|database|service)\b",
    r"\b(switch|migrate|move)(s|d|ed|ing)?\b.*\b(to|from)\b.*\b(library|package|dependency|module|sdk|framework|tool|plugin|database|service)\b",
    r"\b(switch|migrate|move)(s|d|ed|ing)?\b\s+from\b.*\bto\b",
    r"\bbetter than\b.*\b(library|package|dependency|module|sdk|framework|tool|plugin|database|service)\b",
    r"\balternative (to|for)\b",
    r"\b(pros|cons|trade-?off)\b.*\b(library|package|dependency|module|sdk|framework|tool|plugin|database|service)\b",
    r"\breason for choosing\b",
    r"\bwhy we chose\b",
    r"\bdecided to use\b.*\binstead of\b",
    r"\bpackage manager\b",
    r"\bversion\b",
    r"\bcompatibility\b",
    r"\binstall(s|ed|ing)?\s+[\w-]+\b",
    r"\badd(s|ed|ing)?\s+[\w-]+\b",
    r"\bmigrate(s|d|ed|ing)?\s+from\s+[\w-]+\s+to\s+[\w-]+\b",
    # Chinese patterns
    r"安装",
    r"引入",
    r"依赖",
    r"库",
    r"模块",
    r"包",
    r"框架",
    r"工具",
    r"插件",
    r"数据库",
    r"服务",
    r"选择.*是因为",
    r"比起.*更好",
    r"替代方案",
    r"优缺点",
    r"权衡",
    r"版本",
    r"兼容性",
    r"从.*切换到.*",
]

REFACTOR_MARKERS = [
    # English patterns
    r"\brefactor(ing|ed)?\b",
    r"\brestructur(ing|ed)?\b",
    r"\brewrit(ing|ten)?\b",
    r"\bclean(ing|ed)?\s+up\b",
    r"\bextract(ed)?\s+(method|function|class)\b",
    r"\bmoved\b.*\bto\b",
    r"\brenamed\b",
    r"\bsimplif(y|ied|ying)\b",
    r"\boptimiz(e|ed|ing)\b",
    r"\bdecouple(d)?\b",
    # Chinese patterns
    r"重构",
    r"重写",
    r"清理",
    r"优化",
    r"提取",
    r"重命名",
    r"解耦",
    r"简化",
]

TEST_MARKERS = [
    # English patterns
    r"\btest(ing|ed)?\b",
    r"\bunit\s+test\b",
    r"\bintegration\s+test\b",
    r"\be2e\s+test\b",
    r"\bcoverage\b",
    r"\bcovered\b",
    r"\bassert(ion)?\b",
    r"\bmock(ing|ed)?\b",
    r"\bstub(bing|bed)?\b",
    r"\bpytest\b",
    r"\bjest\b",
    r"\bmocha\b",
    # Chinese patterns
    r"测试",
    r"单元测试",
    r"集成测试",
    r"覆盖率",
    r"覆盖",
    r"断言",
    r"模拟",
]

API_MARKERS = [
    # English patterns
    r"\bapi\b",
    r"\bendpoint\b",
    r"\bhttp\b",
    r"\bget\b",
    r"\bpost\b",
    r"\bput\b",
    r"\bdelete\b",
    r"\bpatch\b",
    r"\brest(ful)?\b",
    r"\bgraphql\b",
    r"\bpayload\b",
    r"\bresponse\b",
    r"\brequest\b",
    r"\bcalled\s+with\b",
    r"\bparameter(s)?\b",
    # Chinese patterns
    r"接口",
    r"调用",
    r"端点",
    r"请求",
    r"响应",
    r"参数",
]

REVIEW_MARKERS = [
    # English patterns
    r"\breview(ed)?\b",
    r"\bcomment(ed)?\b",
    r"\bfeedback\b",
    r"\bapprove(d)?\b",
    r"\breject(ed)?\b",
    r"\bsuggest(ion)?\b",
    r"\bpr\b",
    r"\bpull\s+request\b",
    r"\bmr\b",
    r"\bmerge\s+request\b",
    # Chinese patterns
    r"评审",
    r"审查",
    r"反馈",
    r"评论",
    r"通过",
    r"拒绝",
    r"建议",
]

TASK_MARKERS = [
    # English patterns
    r"\btodo\b",
    r"\btask\b",
    r"\baction item\b",
    r"\bschedule\b",
    r"\bmeeting\b",
    r"\bappointment\b",
    r"\breminder\b",
    r"\bremind me\b",
    r"\barrange\b",
    r"\bbook\b",
    r"\bpurchase\b",
    r"\bbuy\b",
    r"\bflight\b",
    r"\bticket\b",
    r"\breimbursement\b",
    # Chinese patterns
    r"待办",
    r"任务",
    r"日程",
    r"安排",
    r"会议",
    r"提醒我",
    r"周会",
    r"确认",
    r"邮件",
    r"报销",
    r"购买",
    r"机票",
    r"家庭",
]

ALL_MARKERS = {
    MemoryCategory.DECISION: DECISION_MARKERS,
    MemoryCategory.PREFERENCE: PREFERENCE_MARKERS,
    MemoryCategory.MILESTONE: MILESTONE_MARKERS,
    MemoryCategory.PROBLEM: PROBLEM_MARKERS,
    MemoryCategory.EMOTIONAL: EMOTIONAL_MARKERS,
    MemoryCategory.LEARNING: LEARNING_MARKERS,
    MemoryCategory.SOLUTION: SOLUTION_MARKERS,
    MemoryCategory.CONTEXT: CONTEXT_MARKERS,
    MemoryCategory.CONVENTION: CONVENTION_MARKERS,
    MemoryCategory.DEPENDENCY: DEPENDENCY_MARKERS,
    MemoryCategory.REFACTOR: REFACTOR_MARKERS,
    MemoryCategory.TEST: TEST_MARKERS,
    MemoryCategory.API: API_MARKERS,
    MemoryCategory.REVIEW: REVIEW_MARKERS,
    MemoryCategory.TASK: TASK_MARKERS,
}

# Sentiment words for disambiguation
POSITIVE_WORDS = {
    "pride",
    "proud",
    "joy",
    "happy",
    "love",
    "beautiful",
    "amazing",
    "wonderful",
    "incredible",
    "fantastic",
    "brilliant",
    "perfect",
    "excited",
    "thrilled",
    "grateful",
    "warm",
    "breakthrough",
    "success",
    "works",
    "working",
    "solved",
    "fixed",
    "nailed",
    "completed",
    "done",
}

NEGATIVE_WORDS = {
    "bug",
    "error",
    "crash",
    "fail",
    "broken",
    "broke",
    "issue",
    "problem",
    "wrong",
    "stuck",
    "blocked",
    "unable",
    "impossible",
    "missing",
    "terrible",
    "horrible",
    "awful",
    "worse",
    "worst",
    "panic",
    "disaster",
}


# ============================================================
# Extraction Models
# ============================================================


class ExtractedMemory(BaseModel):
    """A single extracted memory."""

    content: str = Field(..., description="The memory content")
    category: MemoryCategory = Field(..., description="Memory category")
    confidence: float = Field(0.0, ge=0.0, le=1.0, description="Extraction confidence")
    keywords: list[str] = Field(default_factory=list, description="Matched keywords")
    chunk_index: int = Field(0, description="Index in the source")
    source_file: str | None = Field(None, description="Source file path")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class ExtractionResult(BaseModel):
    """Result of extraction operation."""

    memories: list[ExtractedMemory] = Field(default_factory=list)
    total_chunks: int = Field(0, description="Total chunks processed")
    by_category: dict[str, int] = Field(default_factory=dict, description="Count by category")


# ============================================================
# Memory Extractor
# ============================================================


class PIIRedactor:
    """Redacts PII and secrets from text before extraction."""

    PATTERNS = {
        "AWS_KEY": re.compile(r"(?i)\bAKIA[0-9A-Z]{16}\b"),
        "JWT": re.compile(r"\beyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}\b"),
        "PRIVATE_KEY": re.compile(
            r"-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |OPENSSH )?PRIVATE KEY-----"
        ),
        "EMAIL": re.compile(r"\b[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+\b"),
        "PUBLIC_IP": re.compile(
            r"(?<!\d)(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?!\d)"
        ),
        "SECRET_FIELD": re.compile(
            r"(?i)(password|passwd|pwd|secret|api_key|token)\s*[:=]\s*['\"]([^'\"]+)['\"]"
        ),
        "PHONE": re.compile(r"\b1[3-9]\d{9}\b"),
        "ID_CARD": re.compile(r"\b\d{17}[\dXx]\b"),
        "BANK_CARD": re.compile(r"\b[456]\d{15}\b|\b62\d{14,17}\b"),
    }

    WHITELIST_IPS = {"127.0.0.1", "0.0.0.0", "255.255.255.255", "localhost"}

    @classmethod
    def _is_local_ip(cls, ip_str: str) -> bool:
        if ip_str in cls.WHITELIST_IPS:
            return True
        if ip_str.startswith("10.") or ip_str.startswith("192.168."):
            return True
        if ip_str.startswith("172."):
            try:
                second = int(ip_str.split(".")[1])
                if 16 <= second <= 31:
                    return True
            except (ValueError, IndexError):
                pass
        return False

    @classmethod
    def redact(cls, text: str, mode: ExtractionMode = ExtractionMode.PROGRAMMING) -> str:
        if not text:
            return text

        def ip_repl(match):
            ip = match.group(0)
            return ip if cls._is_local_ip(ip) else "[REDACTED_PUBLIC_IP]"

        def secret_repl(match):
            key = match.group(1)
            val = match.group(2)
            if val.lower() in (
                "placeholder",
                "test",
                "dummy",
                "example",
                "your_api_key",
                "your_password",
                "token",
            ):
                return match.group(0)
            return f"{key}='[REDACTED_SECRET]'"

        text = cls.PATTERNS["AWS_KEY"].sub("[REDACTED_AWS_KEY]", text)
        text = cls.PATTERNS["JWT"].sub("[REDACTED_JWT]", text)
        text = cls.PATTERNS["PRIVATE_KEY"].sub("[REDACTED_PRIVATE_KEY]", text)
        text = cls.PATTERNS["EMAIL"].sub("[REDACTED_EMAIL]", text)
        text = cls.PATTERNS["PUBLIC_IP"].sub(ip_repl, text)
        text = cls.PATTERNS["SECRET_FIELD"].sub(secret_repl, text)

        if mode in (ExtractionMode.OFFICE, ExtractionMode.LIFE):
            text = cls.PATTERNS["PHONE"].sub("[REDACTED_PHONE]", text)
            text = cls.PATTERNS["ID_CARD"].sub("[REDACTED_ID_CARD]", text)
            text = cls.PATTERNS["BANK_CARD"].sub("[REDACTED_BANK_CARD]", text)

        return text


class MemoryExtractor:
    """
    Extract memories from text using rule-based patterns.

    Zero API calls, based on MemPalace's general_extractor.
    Achieves ~96.6% recall on LongMemEval benchmark.
    """

    def __init__(self, min_confidence: float = 0.3, mode: ExtractionMode | None = None):
        """Initialize extractor with confidence threshold and mode."""
        self.min_confidence = min_confidence

        if mode is None:
            settings = get_settings()
            try:
                self.mode = ExtractionMode(settings.extraction_mode.lower())
            except ValueError:
                self.mode = ExtractionMode.PROGRAMMING
        else:
            self.mode = mode

        self._compile_patterns()

    def _remove_private_content(self, text: str) -> str:
        """Remove content wrapped in <private> tags (case-insensitive, handles nesting)."""
        # Use string concatenation to avoid matching the marker in the source code itself
        marker = "<" + "private"
        if not text or marker not in text.lower():
            return text

        lower_text = text.lower()
        start_tag = "<" + "private" + ">"
        end_tag = "</" + "private" + ">"

        ranges = []
        stack = []

        i = 0
        while i < len(text):
            if lower_text.startswith(start_tag, i):
                stack.append(i)
                i += len(start_tag)
            elif lower_text.startswith(end_tag, i):
                if stack:
                    start = stack.pop()
                    # We only care about the outermost range for removal
                    if not stack:
                        ranges.append((start, i + len(end_tag)))
                i += len(end_tag)
            else:
                i += 1

        # Handle unclosed tags: remove from the first unclosed tag to the end of text
        if stack:
            ranges.append((stack[0], len(text)))

        if not ranges:
            return text

        # Sort ranges from end to start to avoid index shifts during replacement
        ranges.sort(key=lambda x: x[0], reverse=True)
        result = list(text)
        for start, end in ranges:
            result[start:end] = [" "]

        return "".join(result)

    def _compile_patterns(self) -> None:
        """Pre-compile regex patterns for performance based on extraction mode."""
        self.compiled_markers = {}

        dev_only_categories = {
            MemoryCategory.DEPENDENCY,
            MemoryCategory.REFACTOR,
            MemoryCategory.TEST,
            MemoryCategory.API,
            MemoryCategory.REVIEW,
            MemoryCategory.CONVENTION,
        }

        for category, markers in ALL_MARKERS.items():
            if self.mode != ExtractionMode.PROGRAMMING and category in dev_only_categories:
                continue
            self.compiled_markers[category] = [re.compile(m, re.IGNORECASE) for m in markers]

    def extract(self, text: str, source_file: str = None) -> ExtractionResult:
        """
        Extract memories from text.

        Args:
            text: Text to extract from
            source_file: Optional source file path

        Returns:
            ExtractionResult with extracted memories
        """
        # Filter out private content
        text = self._remove_private_content(text)

        # Redact PII and secrets
        text = PIIRedactor.redact(text, mode=self.mode)
        # Split into segments
        segments = self._split_into_segments(text)

        memories = []
        by_category: dict[str, int] = {}

        for i, segment in enumerate(segments):
            if len(segment.strip()) < 10:
                continue

            # Extract prose (skip code blocks)
            prose = self._extract_prose(segment)

            # Score against all categories
            scores, matched_keywords = self._score_segment(prose)

            if not scores:
                continue

            # Get best category
            best_category = max(scores, key=scores.get)
            max_score = scores[best_category]

            # Apply disambiguation
            best_category = self._disambiguate(best_category, prose, scores)

            # Calculate confidence (1 keyword = 0.33, 2 = 0.67, 3+ = 1.0)
            confidence = min(1.0, max_score / 3.0)
            if confidence < self.min_confidence:
                continue

            # Create memory
            memory = ExtractedMemory(
                content=segment.strip(),
                category=best_category,
                confidence=confidence,
                keywords=matched_keywords.get(best_category, []),
                chunk_index=i,
                source_file=source_file,
            )
            memories.append(memory)

            # Update counts
            cat_name = best_category.value
            by_category[cat_name] = by_category.get(cat_name, 0) + 1

        return ExtractionResult(
            memories=memories,
            total_chunks=len(segments),
            by_category=by_category,
        )

    def extract_from_tool_use(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
        tool_output: Any,
        context: dict[str, Any] = None,
    ) -> ExtractedMemory | None:
        """
        Extract memory from a tool usage event.

        Args:
            tool_name: Name of the tool used
            tool_input: Tool input parameters
            tool_output: Tool output/result
            context: Additional context (session, project, etc.)

        Returns:
            ExtractedMemory or None if no significant content
        """
        # Build content string
        input_str = json.dumps(tool_input, default=str, ensure_ascii=False)[:500]
        output_str = str(tool_output)[:1000] if tool_output else ""
        content = f"Tool: {tool_name}\nInput: {input_str}\nOutput: {output_str}"

        # Redact PII and secrets
        content = PIIRedactor.redact(content, mode=self.mode)

        # Filter out private content
        content = self._remove_private_content(content)

        # Score against categories
        scores, matched_keywords = self._score_segment(content)

        if not scores:
            # Default to general for tool uses
            return ExtractedMemory(
                content=content,
                category=MemoryCategory.GENERAL,
                confidence=0.5,
                metadata={
                    "tool_name": tool_name,
                    "context": context or {},
                },
            )

        best_category = max(scores, key=scores.get)
        confidence = min(1.0, scores[best_category] / 5.0)

        return ExtractedMemory(
            content=content,
            category=best_category,
            confidence=confidence,
            keywords=matched_keywords.get(best_category, []),
            metadata={
                "tool_name": tool_name,
                "context": context or {},
            },
        )

    def _split_into_segments(self, text: str) -> list[str]:
        """Split text into processable segments."""
        lines = text.split("\n")

        # Check for speaker-turn markers
        turn_patterns = [
            re.compile(r"^>\s"),
            re.compile(r"^(Human|User|Q)\s*:", re.I),
            re.compile(r"^(Assistant|AI|A|Claude|ChatGPT|Gemini)\s*:", re.I),
        ]

        turn_count = sum(
            1 for line in lines if any(pat.match(line.strip()) for pat in turn_patterns)
        )

        # If enough turn markers, split by turns
        if turn_count >= 3:
            return self._split_by_turns(lines, turn_patterns)

        # Fallback: paragraph splitting
        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]

        # If single giant block, chunk by line groups
        if len(paragraphs) <= 1 and len(lines) > 20:
            segments = []
            for i in range(0, len(lines), 25):
                group = "\n".join(lines[i : i + 25]).strip()
                if group:
                    segments.append(group)
            return segments

        return paragraphs

    def _split_by_turns(
        self,
        lines: list[str],
        turn_patterns: list[re.Pattern],
    ) -> list[str]:
        """Split lines into segments at each speaker turn boundary."""
        segments = []
        current = []

        for line in lines:
            stripped = line.strip()
            is_turn = any(pat.match(stripped) for pat in turn_patterns)

            if is_turn and current:
                segments.append("\n".join(current))
                current = [line]
            else:
                current.append(line)

        if current:
            segments.append("\n".join(current))

        return segments

    def _extract_prose(self, text: str) -> str:
        """Extract prose lines, skipping code blocks."""
        lines = text.split("\n")
        prose = []
        in_code = False

        for line in lines:
            if line.strip().startswith("```"):
                in_code = not in_code
                continue
            if in_code:
                continue
            if not self._is_code_line(line):
                prose.append(line)

        result = "\n".join(prose).strip()
        return result if result else text

    def _is_code_line(self, line: str) -> bool:
        """Check if a line is code (not prose)."""
        stripped = line.strip()
        if not stripped:
            return False

        code_patterns = [
            re.compile(r"^\s*[\$#]\s"),
            re.compile(r"^\s*(cd|source|echo|export|pip|npm|git|python|bash)\s"),
            re.compile(r"^\s*```"),
            re.compile(r"^\s*(import|from|def|class|function|const|let|var|return)\s"),
            re.compile(r"^\s*[A-Z_]{2,}="),
            re.compile(r"^\s*\|"),
            re.compile(r"^\s*[-]{2,}"),
            re.compile(r"^\s*[{}\[\]]\s*$"),
            re.compile(r"^\s*(if|for|while|try|except|elif|else:)\b"),
            re.compile(r"^\s*\w+\.\w+\("),
        ]

        for pattern in code_patterns:
            if pattern.match(stripped):
                return True

        # Low alpha ratio suggests code
        alpha_ratio = sum(1 for c in stripped if c.isalpha()) / max(len(stripped), 1)
        if alpha_ratio < 0.4 and len(stripped) > 10:
            return True

        return False

    def _score_segment(
        self,
        text: str,
    ) -> tuple[dict[MemoryCategory, float], dict[MemoryCategory, list[str]]]:
        """Score text against all category markers."""
        scores: dict[MemoryCategory, float] = {}
        keywords: dict[MemoryCategory, list[str]] = {}

        for category, patterns in self.compiled_markers.items():
            score = 0.0
            matched = []
            for pattern in patterns:
                matches = pattern.findall(text)
                if matches:
                    score += len(matches)
                    matched.extend(m if isinstance(m, str) else str(m) for m in matches)

            if score > 0:
                scores[category] = score
                keywords[category] = list(set(matched))

        # print(f"DEBUG: scores={scores}")
        return scores, keywords

    def _get_sentiment(self, text: str) -> str:
        """Quick sentiment analysis."""
        words = set(w.lower() for w in re.findall(r"\b\w+\b", text))
        pos = len(words & POSITIVE_WORDS)
        neg = len(words & NEGATIVE_WORDS)

        if pos > neg:
            return "positive"
        elif neg > pos:
            return "negative"
        return "neutral"

    def _has_resolution(self, text: str) -> bool:
        """Check if text describes a RESOLVED problem."""
        resolution_patterns = [
            r"\bfixed\b",
            r"\bsolved\b",
            r"\bresolved\b",
            r"\bgot it working\b",
            r"\bit works\b",
            r"\bnailed it\b",
            r"\bfigured (it )?out\b",
        ]
        return any(re.search(p, text, re.I) for p in resolution_patterns)

    def _disambiguate(
        self,
        category: MemoryCategory,
        text: str,
        scores: dict[MemoryCategory, float],
    ) -> MemoryCategory:
        """Fix misclassifications using sentiment and resolution."""
        sentiment = self._get_sentiment(text)

        # Resolved problems are milestones
        if category == MemoryCategory.PROBLEM and self._has_resolution(text):
            if scores.get(MemoryCategory.EMOTIONAL, 0) > 0 and sentiment == "positive":
                return MemoryCategory.EMOTIONAL
            return MemoryCategory.MILESTONE

        # Problem + positive sentiment => milestone or emotional
        if category == MemoryCategory.PROBLEM and sentiment == "positive":
            if scores.get(MemoryCategory.MILESTONE, 0) > 0:
                return MemoryCategory.MILESTONE
            if scores.get(MemoryCategory.EMOTIONAL, 0) > 0:
                return MemoryCategory.EMOTIONAL

        # If both decision and dependency match, prefer dependency
        # because it's a more specific type of decision.
        if category == MemoryCategory.DECISION and scores.get(MemoryCategory.DEPENDENCY, 0) > 0:
            return MemoryCategory.DEPENDENCY

        return category


# ============================================================
# Batch Mining Functions
# ============================================================


def mine_file(
    file_path: str | Path,
    extractor: MemoryExtractor = None,
) -> ExtractionResult:
    """
    Mine a single file for memories.

    Args:
        file_path: Path to the file
        extractor: Optional MemoryExtractor instance

    Returns:
        ExtractionResult with found memories
    """
    extractor = extractor or MemoryExtractor()
    path = Path(file_path)

    if not path.exists():
        return ExtractionResult()

    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ExtractionResult()

    return extractor.extract(content, source_file=str(path))


PROJECT_CONTEXT_FILES = {
    "CLAUDE.md",
    "GEMINI.md",
    "AGENTS.md",
    "CONVENTIONS.md",
    ".clauderc",
    ".geminirc",
    ".omgrc",
    "CONTRIBUTING.md",
    "pyproject.toml",
    "package.json",
    "go.mod",
    "Cargo.toml",
    "README.md",
    "GEMINI_MEMORY.md",
    "MEMORY.md",
}


def mine_project_context(
    project_path: str | Path,
    extractor: MemoryExtractor = None,
) -> ExtractionResult:
    """
    Mine project context files (CLAUDE.md, etc.) for memories.

    Args:
        project_path: Path to the project root
        extractor: Optional MemoryExtractor instance

    Returns:
        ExtractionResult with found memories
    """
    extractor = extractor or MemoryExtractor()
    project_path = Path(project_path)

    all_memories = []
    total_chunks = 0
    by_category: dict[str, int] = {}

    if not project_path.exists() or not project_path.is_dir():
        return ExtractionResult()

    # Look for context files in root
    for filename in PROJECT_CONTEXT_FILES:
        filepath = project_path / filename
        if filepath.exists() and filepath.is_file():
            # For context files, we can be more aggressive and treat segments as context
            # if they don't match anything else, or just mine normally.
            # Here we mine normally with the new CONTEXT markers.
            result = mine_file(filepath, extractor)

            all_memories.extend(result.memories)
            total_chunks += result.total_chunks

            for cat, count in result.by_category.items():
                by_category[cat] = by_category.get(cat, 0) + count

    return ExtractionResult(
        memories=all_memories,
        total_chunks=total_chunks,
        by_category=by_category,
    )


def mine_directory(
    directory: str | Path,
    recursive: bool = True,
    file_extensions: set[str] = None,
    extractor: MemoryExtractor = None,
    skip_callback: Callable[[Path], bool] | None = None,
) -> ExtractionResult:
    """
    Mine all files in a directory for memories.

    Args:
        directory: Directory to mine
        recursive: Whether to recurse into subdirectories
        file_extensions: Set of file extensions to include
        extractor: Optional MemoryExtractor instance
        skip_callback: Optional callback taking a file path and returning True to skip

    Returns:
        Combined ExtractionResult from all files
    """
    extractor = extractor or MemoryExtractor()
    directory = Path(directory)

    # Default readable extensions
    if file_extensions is None:
        file_extensions = {
            ".txt",
            ".md",
            ".py",
            ".js",
            ".ts",
            ".jsx",
            ".tsx",
            ".json",
            ".yaml",
            ".yml",
            ".html",
            ".css",
            ".java",
            ".go",
            ".rs",
            ".rb",
            ".sh",
            ".sql",
            ".toml",
        }

    # Skip directories
    skip_dirs = {
        ".git",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        "env",
        "dist",
        "build",
        ".next",
        ".mempalace",
    }

    all_memories = []
    total_chunks = 0
    by_category: dict[str, int] = {}

    # Walk directory
    for root, dirs, files in os.walk(directory):
        # Filter skip dirs
        dirs[:] = [d for d in dirs if d not in skip_dirs]

        if not recursive:
            dirs.clear()

        for filename in files:
            filepath = Path(root) / filename

            # Check extension
            if filepath.suffix.lower() not in file_extensions:
                continue

            # Check skip callback
            if skip_callback and skip_callback(filepath):
                continue

            # Mine file
            result = mine_file(filepath, extractor)

            all_memories.extend(result.memories)
            total_chunks += result.total_chunks

            for cat, count in result.by_category.items():
                by_category[cat] = by_category.get(cat, 0) + count

    return ExtractionResult(
        memories=all_memories,
        total_chunks=total_chunks,
        by_category=by_category,
    )


# ============================================================
# Convenience Functions
# ============================================================


def extract_memories(text: str) -> list[ExtractedMemory]:
    """Convenience function to extract memories from text."""
    extractor = MemoryExtractor()
    result = extractor.extract(text)
    return result.memories


def extract_from_conversation(conversation: str) -> list[ExtractedMemory]:
    """Extract memories from a conversation transcript."""
    return extract_memories(conversation)


class LLMExtractor(MemoryExtractor):
    """
    Extract memories from text using LLM.
    Falls back to rule-based MemoryExtractor if LLM fails or is not configured.
    """

    def __init__(self, min_confidence: float = 0.3, mode: ExtractionMode | None = None):
        super().__init__(min_confidence, mode)
        self.settings = get_settings()

    def extract(self, text: str, source_file: str | None = None) -> ExtractionResult:
        """Extract memories using LLM, with fallback to rules."""
        if not self.settings.llm_api_key:
            return super().extract(text, source_file)

        # Try LLM extraction
        try:
            return self._extract_with_llm(text, source_file)
        except Exception as e:
            import logging

            logger = logging.getLogger(__name__)
            logger.warning(f"LLM extraction failed: {e}. Falling back to rule-based extractor.")
            return super().extract(text, source_file)

    def _extract_with_llm(self, text: str, source_file: str | None = None) -> ExtractionResult:
        """Call OpenAI-compatible API to extract memories."""
        if self.mode == ExtractionMode.PROGRAMMING:
            role_description = "You are a senior developer analyzing code, documentation, or technical conversation."
            extraction_focus = "Extract critical facts, decisions, learnings, patterns, problems, conventions, and dependencies from the following text."
        elif self.mode == ExtractionMode.OFFICE:
            role_description = "You are an intelligent assistant analyzing office communication, emails, meetings, and schedules."
            extraction_focus = "Extract critical tasks, decisions, schedules, milestones, and important contexts from the following text."
        else:
            role_description = (
                "You are a personal assistant analyzing daily life conversations and routines."
            )
            extraction_focus = "Extract personal preferences, tasks, schedules, reminders, and life events from the following text."

        prompt = f"""
{role_description}
{extraction_focus}
Categorize each into one of the following: decision, preference, milestone, problem, emotional, learning, solution, context, convention, dependency, refactor, test, api, review, task, general.
Return the result strictly as a JSON array of objects. Each object must have:
- 'content': string (the extracted fact, concise and actionable)
- 'category': string (the matched category)
- 'confidence': float (0.0 to 1.0)
- 'keywords': array of strings (key concepts)

Text:
{text}
"""
        url = self.settings.llm_base_url or "https://api.openai.com/v1"
        url = url.rstrip("/") + "/chat/completions"

        headers = {
            "Authorization": f"Bearer {self.settings.llm_api_key}",
            "Content-Type": "application/json",
        }
        data = {
            "model": self.settings.llm_model,
            "messages": [{"role": "user", "content": prompt}],
            "response_format": {"type": "json_object"},
            "temperature": 0.1,
        }

        with httpx.Client(timeout=30.0) as client:
            response = client.post(url, headers=headers, json=data)
            response.raise_for_status()

            result_json = response.json()
            content_str = result_json["choices"][0]["message"]["content"]
            parsed = json.loads(content_str)

            # Support both array and dict wrapping array
            items = parsed if isinstance(parsed, list) else parsed.get("memories", [])
            if not items and isinstance(parsed, dict):
                # Try finding any list in the dict
                for v in parsed.values():
                    if isinstance(v, list):
                        items = v
                        break

            memories = []
            by_category = {}
            for item in items:
                cat_str = item.get("category", "general").lower()
                try:
                    category = MemoryCategory(cat_str)
                except ValueError:
                    category = MemoryCategory.GENERAL

                confidence = float(item.get("confidence", 0.8))
                if confidence < self.min_confidence:
                    continue

                mem = ExtractedMemory(
                    content=item.get("content", ""),
                    category=category,
                    confidence=confidence,
                    keywords=item.get("keywords", []),
                    source_file=source_file,
                )
                memories.append(mem)
                by_category[category.value] = by_category.get(category.value, 0) + 1

            return ExtractionResult(
                memories=memories,
                total_chunks=1,
                by_category=by_category,
            )
