"""Codex CLI integration for the memory system.

This module provides the adapter layer for OpenAI Codex CLI agents to interact
with the FalkorDB memory system through the MCP protocol.

Codex CLI Configuration:
- Uses OPENAI_API_KEY for authentication
- Supports model selection via OPENAI_MODEL or OMC_CODEX_DEFAULT_MODEL env vars
- Integrates with OMC team runtime as 'codex' agent type

Usage:
    # Configure Codex CLI to use memory MCP server
    export CODEX_MCP_SERVERS='[{"name": "memory", "command": "python", "args": ["-m", "falkordb_memory_server"]}]'
"""

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from falkordb_memory_server.graph_ops import DatabaseConnectionError, GraphOperationError

logger = logging.getLogger(__name__)


@dataclass
class CodexMemoryAdapter:
    """
    Adapter for OpenAI Codex CLI to interact with the memory system.

    This provides a simplified interface for Codex agents to store,
    recall, and share memories through the FalkorDB backend.
    """

    agent_id: str
    model: str = "gpt-4o"
    namespace: str | None = None
    project_path: str | None = None

    _session_id: str | None = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        """Initialize namespace from project path if not set."""
        if self.namespace is None and self.project_path:
            self.namespace = f"codex:{Path(self.project_path).name}"

    def start_session(self, objective: str | None = None) -> dict[str, Any]:
        """Start a new Codex session in the memory system."""
        try:
            from falkordb_memory_server.session import get_session_manager

            manager = get_session_manager()
            result = manager.start_session(
                agent_type="codex",
                agent_id=self.agent_id,
                project_path=self.project_path,
                objective=objective,
            )
            self._session_id = result.get("session_id")
            return result
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to start session: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error starting session")
            return {"error": str(e)}

    def end_session(self, status: str = "completed", summary: str | None = None) -> dict[str, Any]:
        """End the current session."""
        if not self._session_id:
            return {"error": "No active session"}

        try:
            from falkordb_memory_server.session import get_session_manager

            manager = get_session_manager()
            return manager.end_session(self._session_id, status, summary)
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to end session: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error ending session")
            return {"error": str(e)}

    def remember(
        self,
        content: str,
        memory_type: str = "learning",
        title: str | None = None,
        tags: list[str] | None = None,
        ttl: int | None = None,
    ) -> dict[str, Any]:
        """Store a memory from Codex."""
        try:
            from falkordb_memory_server.memory_tools import get_memory_manager

            manager = get_memory_manager()

            memory_content = {"content": content}
            if title:
                memory_content["title"] = title
            if tags:
                memory_content["tags"] = tags

            context = {
                "agent_type": "codex",
                "agent_id": self.agent_id,
                "model": self.model,
                "session_id": self._session_id,
            }
            if self.namespace:
                context["namespace"] = self.namespace

            return manager.remember(
                memory_type=memory_type,
                content=memory_content,
                context=context,
                ttl=ttl,
            )
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to store memory: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error storing memory")
            return {"error": str(e)}

    def recall(
        self,
        query: str,
        memory_types: list[str] | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        """Recall memories matching a query."""
        try:
            from falkordb_memory_server.memory_tools import get_memory_manager

            manager = get_memory_manager()

            filters = {"agent_type": "codex"}
            if self.namespace:
                filters["namespace"] = self.namespace

            return manager.recall(
                query_type="text",
                query=query,
                filters=filters,
                limit=limit,
            )
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to recall memories: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error recalling memories")
            return {"error": str(e)}

    def semantic_search(self, query: str, k: int = 5) -> list[dict[str, Any]]:
        """Perform semantic search using embeddings."""
        try:
            from falkordb_memory_server.semantic_tools import get_semantic_engine

            engine = get_semantic_engine()
            return engine.search(query, k=k)
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Semantic search failed: {e}")
            return [{"error": str(e)}]
        except Exception as e:
            logger.exception("Unexpected error in semantic search")
            return [{"error": str(e)}]

    def share_with_claude(self, memory_id: int | str) -> dict[str, Any]:
        """Share a memory with Claude agents."""
        try:
            from falkordb_memory_server.sharing import get_sharing_manager

            manager = get_sharing_manager()
            return manager.share_memory(memory_id, ["claude"])
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to share memory with Claude: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error sharing memory")
            return {"error": str(e)}

    def share_with_gemini(self, memory_id: int | str) -> dict[str, Any]:
        """Share a memory with Gemini agents."""
        try:
            from falkordb_memory_server.sharing import get_sharing_manager

            manager = get_sharing_manager()
            return manager.share_memory(memory_id, ["gemini"])
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to share memory with Gemini: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error sharing memory")
            return {"error": str(e)}

    def get_claude_memories(self, limit: int = 20) -> dict[str, Any]:
        """Get memories shared by Claude agents."""
        try:
            from falkordb_memory_server.sharing import get_sharing_manager

            manager = get_sharing_manager()
            return manager.query_agent_memories(agent_type="claude", limit=limit)
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to get Claude memories: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error getting memories")
            return {"error": str(e)}

    def get_gemini_memories(self, limit: int = 20) -> dict[str, Any]:
        """Get memories shared by Gemini agents."""
        try:
            from falkordb_memory_server.sharing import get_sharing_manager

            manager = get_sharing_manager()
            return manager.query_agent_memories(agent_type="gemini", limit=limit)
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to get Gemini memories: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error getting memories")
            return {"error": str(e)}


def generate_codex_mcp_config(
    falkordb_url: str = "redis://localhost:6379",
    embedding_model: str = "all-MiniLM-L6-v2",
    graph_name: str = "agent_memory",
) -> dict[str, Any]:
    """Generate MCP server configuration for Codex CLI."""
    return {
        "mcpServers": {
            "memory": {
                "command": "python",
                "args": ["-m", "falkordb_memory_server"],
                "env": {
                    "FALKORDB_URL": falkordb_url,
                    "EMBEDDING_MODEL": embedding_model,
                    "GRAPH_NAME": graph_name,
                },
            }
        }
    }


def setup_codex_env(
    agent_id: str | None = None,
    model: str = "gpt-4o",
    project_path: str | None = None,
) -> dict[str, str]:
    """Generate environment variables for Codex agent in OMC team."""
    env = {
        "OPENAI_MODEL": model,
        "OMC_EXTERNAL_MODELS_DEFAULT_CODEX_MODEL": model,
    }

    if agent_id:
        env["CODEX_AGENT_ID"] = agent_id

    if project_path:
        env["CODEX_PROJECT_PATH"] = project_path

    return env


def codex_remember(content: str, **kwargs: Any) -> dict[str, Any]:
    """Convenience function for Codex to store a memory."""
    adapter = CodexMemoryAdapter(
        agent_id=os.environ.get("CODEX_AGENT_ID", "codex-default"),
        model=os.environ.get("OPENAI_MODEL", "gpt-4o"),
        project_path=os.environ.get("CODEX_PROJECT_PATH"),
    )
    return adapter.remember(content, **kwargs)


def codex_recall(query: str, limit: int = 10) -> dict[str, Any]:
    """Convenience function for Codex to recall memories."""
    adapter = CodexMemoryAdapter(
        agent_id=os.environ.get("CODEX_AGENT_ID", "codex-default"),
        model=os.environ.get("OPENAI_MODEL", "gpt-4o"),
        project_path=os.environ.get("CODEX_PROJECT_PATH"),
    )
    return adapter.recall(query, limit=limit)
