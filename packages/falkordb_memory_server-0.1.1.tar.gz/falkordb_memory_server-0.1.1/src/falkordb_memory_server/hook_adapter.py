"""Hook adapter for cross-CLI memory capture.

Supports:
- Claude Code (PreToolUse, PostToolUse)
- Gemini CLI (BeforeTool, AfterTool, SessionStart, SessionEnd, etc.)

This module provides a unified interface for memory capture across
different Agent CLIs.
"""

import json
import logging
import sys
from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class HookSource(str, Enum):
    """Source CLI for the hook."""

    CLAUDE = "claude"
    GEMINI = "gemini"
    OPENCLAW = "openclaw"


class UnifiedEvent(str, Enum):
    """Unified hook event names."""

    SESSION_START = "session_start"
    SESSION_END = "session_end"
    USER_PROMPT = "user_prompt"
    AGENT_RESPONSE = "agent_response"
    BEFORE_MODEL = "before_model"
    AFTER_MODEL = "after_model"
    TOOL_SELECTION = "tool_selection"
    BEFORE_TOOL = "before_tool"
    AFTER_TOOL = "after_tool"
    PRE_COMPRESS = "pre_compress"
    NOTIFICATION = "notification"


# Event name mappings
CLAUDE_TO_UNIFIED = {
    "SessionStart": UnifiedEvent.SESSION_START,
    "PreToolUse": UnifiedEvent.BEFORE_TOOL,
    "PostToolUse": UnifiedEvent.AFTER_TOOL,
    "UserPromptSubmit": UnifiedEvent.USER_PROMPT,
    "Notification": UnifiedEvent.NOTIFICATION,
}

GEMINI_TO_UNIFIED = {
    "SessionStart": UnifiedEvent.SESSION_START,
    "SessionEnd": UnifiedEvent.SESSION_END,
    "BeforeAgent": UnifiedEvent.USER_PROMPT,
    "AfterAgent": UnifiedEvent.AGENT_RESPONSE,
    "BeforeModel": UnifiedEvent.BEFORE_MODEL,
    "AfterModel": UnifiedEvent.AFTER_MODEL,
    "BeforeToolSelection": UnifiedEvent.TOOL_SELECTION,
    "BeforeTool": UnifiedEvent.BEFORE_TOOL,
    "AfterTool": UnifiedEvent.AFTER_TOOL,
    "PreCompress": UnifiedEvent.PRE_COMPRESS,
    "Notification": UnifiedEvent.NOTIFICATION,
}

OPENCLAW_TO_UNIFIED = {
    "session_start": UnifiedEvent.SESSION_START,
    "session_end": UnifiedEvent.SESSION_END,
    "user_message": UnifiedEvent.USER_PROMPT,
    "agent_reply": UnifiedEvent.AGENT_RESPONSE,
    "tool_call": UnifiedEvent.BEFORE_TOOL,
    "tool_result": UnifiedEvent.AFTER_TOOL,
}


class UnifiedHookInput(BaseModel):
    """Unified hook input format."""

    # Base fields
    session_id: str = ""
    cwd: str = ""
    timestamp: datetime = Field(default_factory=datetime.now)
    hook_event: UnifiedEvent = UnifiedEvent.NOTIFICATION

    # Raw data for debugging
    raw_event: str = ""
    source_cli: HookSource = HookSource.CLAUDE

    # Event-specific fields
    prompt: str | None = None
    tool_name: str | None = None
    tool_input: dict[str, Any] | None = None
    tool_output: dict[str, Any] | None = None
    model_response: str | None = None

    # Additional context
    transcript_path: str | None = None
    mcp_context: dict[str, Any] | None = None


class UnifiedHookOutput(BaseModel):
    """Unified hook output format."""

    decision: Literal["allow", "deny"] = "allow"
    reason: str | None = None
    system_message: str | None = None
    additional_context: str | None = None

    # CLI-specific outputs
    claude_specific: dict[str, Any] = Field(default_factory=dict)
    gemini_specific: dict[str, Any] = Field(default_factory=dict)
    openclaw_specific: dict[str, Any] = Field(default_factory=dict)

    def to_claude_output(self) -> dict[str, Any]:
        """Convert to Claude Code output format."""
        result = {
            "decision": "approve" if self.decision == "allow" else "deny",
        }
        if self.reason:
            result["reason"] = self.reason
        return result

    def to_gemini_output(self) -> dict[str, Any]:
        """Convert to Gemini CLI output format."""
        result: dict[str, Any] = {
            "decision": self.decision,
        }
        if self.reason:
            result["reason"] = self.reason
        if self.system_message:
            result["systemMessage"] = self.system_message

        gemini_output = {}
        if self.additional_context:
            gemini_output["additionalContext"] = self.additional_context
        if self.claude_specific:
            gemini_output.update(self.gemini_specific)

        if gemini_output:
            result["hookSpecificOutput"] = gemini_output

        return result

    def to_openclaw_output(self) -> dict[str, Any]:
        """Convert to OpenClaw output format."""
        result: dict[str, Any] = {
            "decision": self.decision,
        }
        if self.reason:
            result["reason"] = self.reason
        if self.system_message:
            result["systemMessage"] = self.system_message
        if self.additional_context:
            result["additionalContext"] = self.additional_context

        if self.openclaw_specific:
            result.update(self.openclaw_specific)

        return result


class HookAdapter:
    """
    Adapter for normalizing hook inputs and outputs across CLIs.

    Usage:
        adapter = HookAdapter(source_cli="claude")
        unified_input = adapter.normalize_input(raw_input)
        result = handler.process(unified_input)
        output = adapter.normalize_output(result)
    """

    def __init__(self, source_cli: HookSource | str = HookSource.CLAUDE):
        """Initialize adapter with source CLI."""
        if isinstance(source_cli, str):
            source_cli = HookSource(source_cli.lower())
        self.source_cli = source_cli

    def normalize_input(self, raw_input: dict[str, Any]) -> UnifiedHookInput:
        """
        Normalize raw hook input to unified format.

        Args:
            raw_input: Raw input from the CLI

        Returns:
            UnifiedHookInput with standardized fields
        """
        if self.source_cli == HookSource.CLAUDE:
            return self._parse_claude_input(raw_input)
        elif self.source_cli == HookSource.OPENCLAW:
            return self._parse_openclaw_input(raw_input)
        else:
            return self._parse_gemini_input(raw_input)

    def _parse_claude_input(self, raw_input: dict[str, Any]) -> UnifiedHookInput:
        raw_event = raw_input.get("hook_event_name", "")
        unified_event = CLAUDE_TO_UNIFIED.get(raw_event, UnifiedEvent.NOTIFICATION)
        return self._build_unified_input(raw_input, raw_event, unified_event)

    def _parse_gemini_input(self, raw_input: dict[str, Any]) -> UnifiedHookInput:
        raw_event = raw_input.get("hook_event_name", "")
        unified_event = GEMINI_TO_UNIFIED.get(raw_event, UnifiedEvent.NOTIFICATION)
        return self._build_unified_input(raw_input, raw_event, unified_event)

    def _build_unified_input(
        self, raw_input: dict[str, Any], raw_event: str, unified_event: UnifiedEvent
    ) -> UnifiedHookInput:
        # Parse timestamp
        timestamp_str = raw_input.get("timestamp", "")
        try:
            timestamp = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
        except (ValueError, TypeError):
            timestamp = datetime.now()

        # Build unified input
        return UnifiedHookInput(
            session_id=raw_input.get("session_id", ""),
            cwd=raw_input.get("cwd", raw_input.get("GEMINI_CWD", "")),
            timestamp=timestamp,
            hook_event=unified_event,
            raw_event=raw_event,
            source_cli=self.source_cli,
            prompt=raw_input.get("prompt"),
            tool_name=raw_input.get("tool_name"),
            tool_input=raw_input.get("tool_input"),
            tool_output=raw_input.get("tool_response") or raw_input.get("tool_output"),
            model_response=raw_input.get("prompt_response") or raw_input.get("model_response"),
            transcript_path=raw_input.get("transcript_path"),
            mcp_context=raw_input.get("mcp_context"),
        )

    def _parse_openclaw_input(self, raw_input: dict[str, Any]) -> UnifiedHookInput:
        raw_event = raw_input.get("event", "")
        unified_event = OPENCLAW_TO_UNIFIED.get(raw_event, UnifiedEvent.NOTIFICATION)

        timestamp_str = raw_input.get("timestamp", "")
        try:
            timestamp = datetime.fromisoformat(timestamp_str.replace("Z", "+00:00"))
        except (ValueError, TypeError):
            timestamp = datetime.now()

        return UnifiedHookInput(
            session_id=raw_input.get("session_id", ""),
            cwd=raw_input.get("working_dir", ""),
            timestamp=timestamp,
            hook_event=unified_event,
            raw_event=raw_event,
            source_cli=HookSource.OPENCLAW,
            prompt=raw_input.get("message", ""),
            tool_name=raw_input.get("tool_name"),
            tool_input=raw_input.get("tool_args"),
            tool_output=raw_input.get("tool_result"),
            model_response=raw_input.get("reply"),
        )

    def normalize_output(self, output: UnifiedHookOutput) -> dict[str, Any]:
        """
        Convert unified output to CLI-specific format.

        Args:
            output: Unified output

        Returns:
            CLI-specific output dict
        """
        if self.source_cli == HookSource.CLAUDE:
            return output.to_claude_output()
        elif self.source_cli == HookSource.OPENCLAW:
            return output.to_openclaw_output()
        else:
            return output.to_gemini_output()


class MemoryHookHandler:
    """
    Handler for memory capture and context injection.

    Integrates with FalkorDB Memory for:
    - Tool usage capture
    - Session context injection
    - Memory extraction and storage
    """

    def __init__(self, falkordb_url: str | None = None):
        """Initialize handler with lazy-loaded components.

        Args:
            falkordb_url: Optional FalkorDB URL. If None, uses environment variable.
        """
        self._extractor = None
        self._graph_ops = None
        self._falkordb_url = falkordb_url
        self._db_available = True  # Assume available until proven otherwise

    @property
    def extractor(self):
        """Lazy load memory extractor."""
        if self._extractor is None:
            from falkordb_memory_server.extractor import MemoryExtractor

            self._extractor = MemoryExtractor()
        return self._extractor

    @property
    def graph_ops(self):
        """Lazy load graph operations with connection check."""
        if self._graph_ops is None and self._db_available:
            try:
                from falkordb_memory_server.graph_ops import get_graph_ops

                self._graph_ops = get_graph_ops()
            except Exception:
                # Database not available, degrade gracefully
                self._db_available = False
                return None
        return self._graph_ops

    def _safe_graph_op(self, operation: callable, default=None):
        """Execute graph operation safely, returning default on failure."""
        if not self._db_available:
            return default
        try:
            return operation()
        except Exception as e:
            logger.error(f"Memory hook graph operation failed: {e}")
            self._db_available = False
            return default

    def handle(self, input_data: UnifiedHookInput) -> UnifiedHookOutput:
        """
        Process hook event and return result.

        Args:
            input_data: Normalized hook input

        Returns:
            UnifiedHookOutput with decision and optional context
        """
        event = input_data.hook_event

        if event == UnifiedEvent.SESSION_START:
            return self._handle_session_start(input_data)
        elif event == UnifiedEvent.SESSION_END:
            return self._handle_session_end(input_data)
        elif event == UnifiedEvent.BEFORE_TOOL:
            return self._handle_before_tool(input_data)
        elif event == UnifiedEvent.AFTER_TOOL:
            return self._handle_after_tool(input_data)
        elif event == UnifiedEvent.USER_PROMPT:
            return self._handle_user_prompt(input_data)
        else:
            # Default: allow without action
            return UnifiedHookOutput(decision="allow")

    def _handle_session_start(self, input_data: UnifiedHookInput) -> UnifiedHookOutput:
        """Handle session start - inject context."""

        def create_session():
            if self.graph_ops:
                self.graph_ops.create_node(
                    "Session",
                    {
                        "id": input_data.session_id,
                        "cwd": input_data.cwd,
                        "started_at": input_data.timestamp.isoformat(),
                        "source_cli": input_data.source_cli.value,
                    },
                )

        self._safe_graph_op(create_session)

        # Retrieve relevant memories for context
        memories = self._recall_relevant_memories(input_data.cwd)

        if memories:
            context = self._format_context(memories)
            return UnifiedHookOutput(
                decision="allow",
                additional_context=context,
                system_message=f"Loaded {len(memories)} relevant memories",
            )

        return UnifiedHookOutput(decision="allow")

    def _handle_session_end(self, input_data: UnifiedHookInput) -> UnifiedHookOutput:
        """Handle session end - cleanup and summary."""

        def update_session():
            if self.graph_ops:
                cypher = """
                MATCH (s:Session {id: $id})
                SET s.ended_at = $ended_at
                """
                self.graph_ops.query(
                    cypher,
                    params={
                        "id": input_data.session_id,
                        "ended_at": input_data.timestamp.isoformat(),
                    },
                )

        self._safe_graph_op(update_session)

        return UnifiedHookOutput(decision="allow")

    def _handle_before_tool(self, input_data: UnifiedHookInput) -> UnifiedHookOutput:
        """Handle before tool - validation and logging."""
        # Log tool use (no blocking by default)
        return UnifiedHookOutput(decision="allow")

    def _handle_after_tool(self, input_data: UnifiedHookInput) -> UnifiedHookOutput:
        """Handle after tool - capture and extract memory."""
        if not input_data.tool_name or not input_data.tool_input:
            return UnifiedHookOutput(decision="allow")

        # Extract memory from tool use
        memory = self.extractor.extract_from_tool_use(
            tool_name=input_data.tool_name,
            tool_input=input_data.tool_input,
            tool_output=input_data.tool_output or {},
            context={
                "session_id": input_data.session_id,
                "cwd": input_data.cwd,
            },
        )

        if memory and memory.confidence >= 0.3:
            # Store to graph
            self._store_memory(memory, input_data.session_id)

        return UnifiedHookOutput(decision="allow")

    def _handle_user_prompt(self, input_data: UnifiedHookInput) -> UnifiedHookOutput:
        """Handle user prompt - extract and potentially inject context."""
        if not input_data.prompt:
            return UnifiedHookOutput(decision="allow")

        # Extract memories from prompt
        result = self.extractor.extract(input_data.prompt)

        for memory in result.memories:
            if memory.confidence >= 0.3:
                self._store_memory(memory, input_data.session_id)

        # Proactive Insights retrieval
        insights = self._get_proactive_insights(
            input_data.prompt, input_data.cwd, input_data.session_id
        )
        self._update_active_architecture(insights)

        if insights and input_data.source_cli == HookSource.GEMINI:
            context_str = "Proactive Insights:\n" + "\n".join([f"- {i}" for i in insights])
            return UnifiedHookOutput(decision="allow", additional_context=context_str)

        return UnifiedHookOutput(decision="allow")

    def _get_proactive_insights(self, prompt: str, cwd: str, session_id: str) -> list[str]:
        """Retrieve proactive insights based on user prompt, deduplicated per session."""
        if not self.graph_ops or not prompt:
            return []

        import re

        words = re.findall(r"[a-zA-Z0-9_\-\./]+", prompt)
        keywords = [w for w in words if len(w) > 3][:5]

        if not keywords:
            return []

        def query_insights():
            cypher = """
            MATCH (n)
            WHERE (n:Decision OR n:Convention OR n:Learning)
              AND (n.source_file IS NULL OR n.source_file CONTAINS $cwd OR toString(n.context) CONTAINS $cwd)
              AND any(kw IN $keywords WHERE toLower(n.content) CONTAINS toLower(kw))
            RETURN id(n) as node_id, n.category as category, n.content as content, n.confidence as confidence
            ORDER BY n.confidence DESC
            LIMIT 10
            """
            result = self.graph_ops.query(
                cypher, params={"cwd": cwd, "keywords": keywords}, read_only=True
            )
            return result.get("result_set", [])

        rows = self._safe_graph_op(query_insights, default=[])
        if not rows:
            return []

        import json
        from datetime import timedelta, timezone
        from pathlib import Path

        cache_dir = Path(cwd) / ".omg" / "state"
        cache_file = cache_dir / f"insights_cache_{session_id}.json"

        pushed = {}
        if cache_file.exists():
            try:
                with open(cache_file) as f:
                    pushed = json.load(f)
            except Exception:
                pass

        now = datetime.now(timezone.utc)
        insights = []
        new_pushed = False

        for row in rows:
            node_id, category, content, confidence = row
            nid_str = str(node_id)

            if nid_str in pushed:
                try:
                    last_push = datetime.fromisoformat(pushed[nid_str])
                    if now - last_push < timedelta(hours=1):
                        continue
                except ValueError:
                    pass

            insights.append(f"[{str(category).upper()}] {content}")
            pushed[nid_str] = now.isoformat()
            new_pushed = True

            if len(insights) >= 3:
                break

        if new_pushed:
            try:
                cache_dir.mkdir(parents=True, exist_ok=True)
                with open(cache_file, "w") as f:
                    json.dump(pushed, f)
            except Exception:
                pass

        return insights

    def _update_active_architecture(self, insights: list[str]):
        """Update async state file for proactive insights."""
        if not insights:
            return

        try:
            from pathlib import Path

            cache_dir = Path(".omg/state")
            cache_dir.mkdir(parents=True, exist_ok=True)
            arch_file = cache_dir / "active-architecture.md"

            content = "# Active Architecture Insights\n\n"
            content += "Automatically pushed context based on recent activity:\n\n"
            for i in insights:
                content += f"- {i}\n"

            with open(arch_file, "w") as f:
                f.write(content)
        except Exception:
            pass

    def _recall_relevant_memories(self, cwd: str) -> list[dict]:
        """Recall memories relevant to current context."""

        def query_memories():
            if not self.graph_ops:
                return []
            cypher = """
            MATCH (n)
            WHERE n.source_file CONTAINS $cwd OR n.context CONTAINS $cwd
            RETURN n
            ORDER BY n.created_at DESC
            LIMIT 10
            """
            result = self.graph_ops.query(cypher, params={"cwd": cwd}, read_only=True)
            return result.get("result_set", [])

        return self._safe_graph_op(query_memories, default=[])

    def _format_context(self, memories: list[dict]) -> str:
        """Format memories as context string."""
        lines = ["# Relevant Memories\n"]
        for m in memories[:10]:
            if isinstance(m, dict) and "n" in m:
                node = m["n"]
                content = node.get("content", str(node))
                category = node.get("category", "general")
                lines.append(f"- [{category}] {content[:100]}")
        return "\n".join(lines)

    def _store_memory(self, memory, session_id: str) -> int:
        """Store memory to graph and return node ID."""
        from falkordb_memory_server.extractor import MemoryCategory

        category_to_label = {
            MemoryCategory.DECISION: "Decision",
            MemoryCategory.PREFERENCE: "Learning",
            MemoryCategory.MILESTONE: "Task",
            MemoryCategory.PROBLEM: "Decision",
            MemoryCategory.EMOTIONAL: "Learning",
            MemoryCategory.LEARNING: "Learning",
            MemoryCategory.GENERAL: "Learning",
        }

        label = category_to_label.get(memory.category, "Learning")

        def create_memory_node():
            if not self.graph_ops:
                return {"node_id": 0}
            return self.graph_ops.create_node(
                label,
                {
                    "content": memory.content,
                    "category": memory.category.value,
                    "confidence": memory.confidence,
                    "keywords": memory.keywords,
                    "source_file": memory.source_file,
                    "session_id": session_id,
                    "created_at": datetime.now().isoformat(),
                },
            )

        result = self._safe_graph_op(create_memory_node, default={"node_id": 0})
        return result.get("node_id", 0)


def run_hook(source_cli: str = "claude"):
    """
    Main entry point for hook execution.

    Reads JSON from stdin, processes, and outputs to stdout.
    """
    # Read input
    try:
        raw_input = json.load(sys.stdin)
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON input: {e}", file=sys.stderr)
        sys.exit(2)

    # Create adapter and handler
    adapter = HookAdapter(source_cli=source_cli)
    handler = MemoryHookHandler()

    # Normalize input
    unified_input = adapter.normalize_input(raw_input)

    # Process
    result = handler.handle(unified_input)

    # Output
    output = adapter.normalize_output(result)
    print(json.dumps(output))
    sys.exit(0)


if __name__ == "__main__":
    # Auto-detect source CLI from environment
    import os

    source = os.environ.get("HOOK_SOURCE_CLI", "claude")
    run_hook(source)
