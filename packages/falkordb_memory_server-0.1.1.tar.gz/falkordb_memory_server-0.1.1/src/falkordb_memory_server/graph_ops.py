"""Graph operations wrapper for FalkorDB."""

import logging
import re
import threading
import time
from datetime import datetime, timezone
from typing import Any

from falkordb import FalkorDB

from falkordb_memory_server.config import get_settings
from falkordb_memory_server.schema import NodeLabel, RelationType

logger = logging.getLogger(__name__)


class DatabaseConnectionError(Exception):
    """Raised when database connection fails."""

    pass


class GraphOperationError(Exception):
    """Raised when a graph operation fails."""

    pass


class GraphOperations:
    """Wrapper for FalkorDB graph operations."""

    def __init__(self) -> None:
        """Initialize graph connection."""
        self.settings = get_settings()
        self._db: FalkorDB | None = None
        self._graph = None
        self._lock = threading.RLock()
        self._connection_available = True
        self._label_pattern = re.compile(r"^[a-zA-Z0-9_]+$")

    @property
    def db(self) -> FalkorDB:
        """Get FalkorDB connection (lazy initialization with thread safety)."""
        if self._db is None:
            with self._lock:
                # Double-check locking pattern
                if self._db is None:
                    max_retries = 3
                    retry_delay = 1
                    for attempt in range(max_retries):
                        try:
                            # Optimize connection pool:
                            # max_connections: Number of connections in the pool
                            # socket_timeout: Timeout for socket operations
                            # health_check_interval: Frequency of health checks
                            self._db = FalkorDB.from_url(
                                self.settings.redis_url,
                                max_connections=20,
                                socket_timeout=5,
                                health_check_interval=30,
                            )
                            # Verify connection
                            self._db.connection.ping()
                            logger.info(
                                f"Connected to FalkorDB at {self.settings.redis_url} (pool size: 20)"
                            )
                            self._connection_available = True
                            break
                        except Exception as e:
                            self._connection_available = False
                            if attempt < max_retries - 1:
                                logger.warning(
                                    f"Connection attempt {attempt + 1} failed: {e}. Retrying in {retry_delay}s..."
                                )
                                time.sleep(retry_delay)
                                retry_delay *= 2
                            else:
                                logger.error(
                                    f"Failed to connect to FalkorDB after {max_retries} attempts: {e}"
                                )
                                raise DatabaseConnectionError(
                                    f"Failed to connect to FalkorDB: {e}"
                                ) from e
        return self._db

    @property
    def graph(self):
        """Get the memory graph (lazy initialization)."""
        if self._graph is None:
            with self._lock:
                if self._graph is None:
                    try:
                        self._graph = self.db.select_graph(self.settings.graph_name)
                        logger.debug(f"Selected graph: {self.settings.graph_name}")
                    except DatabaseConnectionError:
                        raise
                    except Exception as e:
                        logger.error(f"Failed to select graph: {e}")
                        raise GraphOperationError(f"Failed to select graph: {e}") from e
        return self._graph

    def is_connected(self) -> bool:
        """Check if database connection is available."""
        try:
            db = self.db
            db.connection.ping()
            return True
        except (DatabaseConnectionError, Exception):
            return False

    def _validate_label(self, label: str) -> str:
        """Validate node label to prevent Cypher injection."""
        if not label:
            raise GraphOperationError("Node label cannot be empty")

        # Check against enum if applicable
        try:
            if isinstance(label, NodeLabel):
                return label.value
            # Check if it's a valid enum value
            NodeLabel(label)
            return label
        except ValueError:
            # Not in enum, check regex for safety
            if not self._label_pattern.match(label):
                logger.error(f"Invalid label detected: {label}")
                raise GraphOperationError(f"Invalid label format: {label}")
            return label

    def _validate_relation(self, relation: str) -> str:
        """Validate relationship type to prevent Cypher injection."""
        if not relation:
            raise GraphOperationError("Relationship type cannot be empty")

        try:
            if isinstance(relation, RelationType):
                return relation.value
            RelationType(relation)
            return relation
        except ValueError:
            if not self._label_pattern.match(relation):
                logger.error(f"Invalid relationship type detected: {relation}")
                raise GraphOperationError(f"Invalid relationship format: {relation}")
            return relation

    def safe_query(
        self,
        cypher: str,
        params: dict[str, Any] | None = None,
        read_only: bool = False,
    ) -> dict[str, Any]:
        """
        Execute a Cypher query with error handling.

        Returns empty result on failure instead of crashing.
        """
        try:
            return self.query(cypher, params, read_only)
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.warning(f"Query failed: {e}")
            return {"result_set": [], "statistics": {}, "error": str(e)}
        except Exception as e:
            logger.exception(f"Unexpected query error: {e}")
            return {"result_set": [], "statistics": {}, "error": str(e)}

    def query(
        self,
        cypher: str,
        params: dict[str, Any] | None = None,
        read_only: bool = False,
    ) -> dict[str, Any]:
        """
        Execute a Cypher query.

        Args:
            cypher: Cypher query string
            params: Query parameters
            read_only: Use read-only query method

        Returns:
            Query result with result_set and statistics
        """
        try:
            # Use read-only query if specified
            method = self.graph.ro_query if read_only else self.graph.query
            result = method(cypher, params=params or {})

            return {
                "result_set": self._parse_result_set(result),
                "statistics": self._parse_statistics(result),
            }
        except Exception as e:
            if "Connection error" in str(e) or "Timeout" in str(e) or "Closed" in str(e):
                self._db = None  # Reset connection for retry
                logger.warning(f"Database connection error: {e}")
                raise DatabaseConnectionError(f"Database connection error: {e}") from e
            logger.error(f"Graph operation failed: {e}")
            raise GraphOperationError(f"Graph operation failed: {e}") from e

    def create_vector_index(
        self,
        label: NodeLabel | str,
        property_name: str,
        dimension: int,
        similarity_function: str = "cosine",
    ) -> bool:
        """
        Create a vector index for a node label and property.

        Args:
            label: Node label
            property_name: Property name containing the vector
            dimension: Vector dimension
            similarity_function: Similarity function (e.g., 'cosine', 'euclidean')

        Returns:
            Success status
        """
        label_str = self._validate_label(label)

        # FalkorDB new vector index syntax (Cypher):
        # CREATE VECTOR INDEX FOR (n:label) ON (n.property) OPTIONS {dimension: d, similarityFunction: 'f'}
        # For backward compatibility or procedure-based creation:
        # CALL db.idx.vector.createNodeIndex('label', 'property', dimension, 'similarity_function')

        # We'll try the Cypher syntax first as it's the standard way in FalkorDB now
        cypher = f"CREATE VECTOR INDEX FOR (n:{label_str}) ON (n.{property_name}) OPTIONS {{dimension: {int(dimension)}, similarityFunction: '{similarity_function}'}}"

        try:
            self.query(cypher)
            logger.info(f"Created vector index for {label_str}({property_name})")
            return True
        except Exception as e:
            if (
                "Index already exists" in str(e)
                or "Duplicate index" in str(e)
                or "already exists" in str(e).lower()
            ):
                logger.debug(f"Vector index for {label_str}({property_name}) already exists")
                return True

            # Fallback to procedure-based creation if Cypher syntax fails
            try:
                fallback_cypher = f"CALL db.idx.vector.createNodeIndex('{label_str}', '{property_name}', {int(dimension)}, '{similarity_function}')"
                self.query(fallback_cypher)
                return True
            except Exception as e2:
                logger.error(f"Failed to create vector index: {e} (Fallback: {e2})")
                return False

    def create_nodes_batch(
        self,
        label: NodeLabel | str,
        nodes_properties: list[dict[str, Any]],
    ) -> list[int]:
        """
        Create multiple nodes in a single batch.

        Args:
            label: Node label
            nodes_properties: List of dictionaries containing node properties

        Returns:
            List of created node IDs
        """
        if not nodes_properties:
            return []

        label_str = self._validate_label(label)
        now = datetime.now(timezone.utc).isoformat()

        # Prepare properties with timestamps
        batch_props = []
        for props in nodes_properties:
            p = props.copy()
            if "created_at" not in p:
                p["created_at"] = now
            batch_props.append(p)

        # Use UNWIND for batching
        cypher = f"""
        UNWIND $batch as props
        CREATE (n:{label_str})
        SET n = props
        RETURN id(n) as node_id
        """

        result = self.query(cypher, params={"batch": batch_props})

        return [row[0] for row in result["result_set"]]

    def create_edges_batch(
        self,
        edges_info: list[dict[str, Any]],
    ) -> int:
        """
        Create multiple relationships in a single batch.

        Args:
            edges_info: List of dicts with {from_id, relation, to_id, properties}

        Returns:
            Number of created edges
        """
        if not edges_info:
            return 0

        now = datetime.now(timezone.utc).isoformat()

        # Group by relation type because Cypher relation types can't be parameterized
        by_relation = {}
        for edge in edges_info:
            rel = self._validate_relation(edge["relation"])
            if rel not in by_relation:
                by_relation[rel] = []

            props = edge.get("properties", {}).copy()
            if "created_at" not in props:
                props["created_at"] = now

            by_relation[rel].append(
                {"from_id": int(edge["from_id"]), "to_id": int(edge["to_id"]), "props": props}
            )

        total_created = 0
        for rel_str, batch in by_relation.items():
            cypher = f"""
            UNWIND $batch as edge
            MATCH (a), (b)
            WHERE id(a) = edge.from_id AND id(b) = edge.to_id
            CREATE (a)-[r:{rel_str}]->(b)
            SET r = edge.props
            """
            result = self.query(cypher, params={"batch": batch})
            stats = result.get("statistics", {})
            total_created += stats.get("relationships_created", 0)

        return total_created

    def create_node(
        self,
        label: NodeLabel | str,
        properties: dict[str, Any],
        return_node: bool = True,
    ) -> dict[str, Any]:
        """
        Create a node with the given label and properties.

        Args:
            label: Node label
            properties: Node properties
            return_node: Whether to return the created node

        Returns:
            Created node or node ID
        """
        label_str = self._validate_label(label)

        # Add timestamps if not present
        props = properties.copy()
        if "created_at" not in props:
            props["created_at"] = datetime.now(timezone.utc).isoformat()

        # Build Cypher query with parameterization to prevent injection
        return_clause = "RETURN n" if return_node else "RETURN id(n) as node_id"
        # Use SET n = $props for complete property replacement
        cypher = f"CREATE (n:{label_str}) SET n = $props {return_clause}"

        result = self.query(cypher, params={"props": props})

        if return_node:
            if result["result_set"]:
                return result["result_set"][0][0]
            return {}
        else:
            if result["result_set"]:
                return {"node_id": result["result_set"][0][0]}
            return {}

    def create_edge(
        self,
        from_id: int,
        relation: str,
        to_id: int,
        properties: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Create a relationship between two nodes.

        Args:
            from_id: Source node ID
            relation: Relationship type
            to_id: Target node ID
            properties: Relationship properties

        Returns:
            Created relationship info
        """
        relation_str = self._validate_relation(relation)
        props = properties.copy() if properties else {}
        if "created_at" not in props:
            props["created_at"] = datetime.now(timezone.utc).isoformat()

        cypher = f"""
        MATCH (a), (b)
        WHERE id(a) = $from_id AND id(b) = $to_id
        CREATE (a)-[r:{relation_str}]->(b)
        SET r = $props
        RETURN r
        """

        params = {"from_id": int(from_id), "to_id": int(to_id), "props": props}

        result = self.query(cypher, params=params)

        if result["result_set"]:
            return result["result_set"][0][0]
        return {}

    def delete_nodes(
        self,
        node_ids: list[int],
        cascade: bool = False,
    ) -> dict[str, Any]:
        """
        Delete nodes by ID.

        Args:
            node_ids: List of node IDs to delete
            cascade: Whether to delete connected edges

        Returns:
            Delete statistics
        """
        if not node_ids:
            return {"deleted_count": 0}

        delete_clause = "DETACH DELETE n" if cascade else "DELETE n"
        cypher = f"""
        MATCH (n)
        WHERE id(n) IN $ids
        {delete_clause}
        RETURN count(n) as count
        """

        result = self.query(cypher, params={"ids": [int(nid) for nid in node_ids]})

        return {"deleted_count": result["result_set"][0][0] if result["result_set"] else 0}

    def semantic_search(
        self,
        query_vector: list[float],
        label: NodeLabel | str | None = None,
        k: int = 10,
        min_score: float = 0.0,
    ) -> list[dict[str, Any]]:
        """
        Perform semantic search using vector similarity.

        Args:
            query_vector: Embedding vector
            label: Optional node label filter
            k: Number of results
            min_score: Minimum similarity score

        Returns:
            List of matching nodes with scores
        """
        # If no label provided, we search across common memory labels
        # In FalkorDB, vector index is per (Label, Property)
        labels_to_search = []
        if label:
            labels_to_search = [self._validate_label(label)]
        else:
            # Search all indexed labels
            labels_to_search = ["Learning", "Decision", "Code", "Concept"]

        all_matches = []
        for label_str in labels_to_search:
            # Build parameterized Cypher query with correct signature:
            # CALL db.idx.vector.queryNodes(label, property, k, vector)
            # Vector must be wrapped in vecf32()
            cypher = f"""
            CALL db.idx.vector.queryNodes('{label_str}', 'embedding', $k, vecf32($vector))
            YIELD node, score
            WHERE score >= $min_score
            RETURN node, score
            ORDER BY score DESC
            LIMIT $k
            """

            params = {"k": k, "vector": query_vector, "min_score": min_score}

            try:
                # Use read_only=True for search
                result = self.query(cypher, params=params, read_only=True)

                for row in result["result_set"]:
                    node_dict, score = row
                    all_matches.append(
                        {"node": node_dict, "score": float(score), "label": label_str}
                    )
            except Exception as e:
                # If index doesn't exist for this label, just skip it
                if "Index not found" in str(e) or "not registered" in str(e).lower():
                    logger.debug(f"No vector index for label {label_str}")
                else:
                    logger.warning(f"Vector search failed for label {label_str}: {e}")

        # Sort combined results by score
        all_matches.sort(key=lambda x: x["score"], reverse=True)

        # Limit to k results
        return all_matches[:k]

    def get_stats(self) -> dict[str, Any]:
        """Get graph statistics."""
        try:
            labels_result = self.graph.query("CALL db.labels()")
            rels_result = self.graph.query("CALL db.relationshipTypes()")

            labels = (
                [row[0] for row in labels_result.result_set] if labels_result.result_set else []
            )
            rel_types = [row[0] for row in rels_result.result_set] if rels_result.result_set else []

            node_count_result = self.graph.query("MATCH (n) RETURN count(n) as count")
            node_count = node_count_result.result_set[0][0] if node_count_result.result_set else 0

            edge_count_result = self.graph.query("MATCH ()-[r]->() RETURN count(r) as count")
            edge_count = edge_count_result.result_set[0][0] if edge_count_result.result_set else 0

            return {
                "node_count": node_count,
                "edge_count": edge_count,
                "labels": labels,
                "relationship_types": rel_types,
            }
        except Exception as e:
            logger.error(f"Failed to get graph stats: {e}")
            raise GraphOperationError(f"Failed to get graph stats: {e}") from e

    def _parse_result_set(self, result) -> list[list[Any]]:
        """Parse raw result set into a list of lists."""
        if not result or not hasattr(result, "result_set"):
            return []

        parsed = []
        for row in result.result_set:
            parsed_row = []
            for item in row:
                parsed_row.append(self._serialize_value(item))
            parsed.append(parsed_row)
        return parsed

    def _parse_statistics(self, result) -> dict[str, Any]:
        """Parse raw statistics into a dictionary."""
        if not result or not hasattr(result, "statistics"):
            return {}
        return result.statistics

    def _serialize_value(self, value: Any) -> Any:
        """Serialize a value to JSON-compatible format."""
        if value is None:
            return None
        if isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, (list, tuple)):
            return [self._serialize_value(v) for v in value]
        if isinstance(value, dict):
            return {k: self._serialize_value(v) for k, v in value.items()}
        if hasattr(value, "__dict__"):
            # Node or Edge object from FalkorDB
            return self._node_to_dict(value)
        return str(value)

    def _node_to_dict(self, node) -> dict[str, Any]:
        """Convert a FalkorDB Node to a dictionary."""
        if hasattr(node, "properties"):
            return {
                "id": getattr(node, "id", None),
                "labels": list(getattr(node, "labels", [])),
                "properties": dict(getattr(node, "properties", {})),
            }
        return {"value": str(node)}


# Global instance
_graph_ops: GraphOperations | None = None
_graph_ops_lock = threading.Lock()


def get_graph_ops() -> GraphOperations:
    """Get the global GraphOperations instance."""
    global _graph_ops
    if _graph_ops is None:
        with _graph_ops_lock:
            if _graph_ops is None:
                _graph_ops = GraphOperations()
    return _graph_ops
