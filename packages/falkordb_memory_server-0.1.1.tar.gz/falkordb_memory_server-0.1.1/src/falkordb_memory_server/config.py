"""Configuration management using pydantic-settings."""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_prefix="",
        env_file=(".env", "~/.falkordb_memory/.env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # FalkorDB connection
    falkordb_url: str = "redis://localhost:6379"
    falkordb_host: str = "localhost"
    falkordb_port: int = 6379
    falkordb_password: str | None = None
    graph_name: str = "agent_memory"

    # Embedding configuration
    embedding_model: str = "all-MiniLM-L6-v2"
    embedding_dimension: int = 384  # Default for all-MiniLM-L6-v2

    # Memory defaults
    default_ttl: int = 604800  # 7 days in seconds
    max_results: int = 100

    # LLM Extraction configuration
    llm_api_key: str | None = None
    llm_model: str = "gpt-4o-mini"
    llm_base_url: str | None = None

    # Extraction mode
    extraction_mode: str = "programming"

    # Server configuration
    log_level: str = "INFO"

    @property
    def redis_url(self) -> str:
        """Get Redis URL for FalkorDB connection."""
        if self.falkordb_url != "redis://localhost:6379":
            return self.falkordb_url
        if self.falkordb_password:
            return f"redis://:{self.falkordb_password}@{self.falkordb_host}:{self.falkordb_port}"
        return f"redis://{self.falkordb_host}:{self.falkordb_port}"


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()
