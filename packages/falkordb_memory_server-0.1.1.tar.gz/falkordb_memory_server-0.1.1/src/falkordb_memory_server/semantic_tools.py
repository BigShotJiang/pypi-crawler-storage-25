"""Semantic search tools using vector embeddings."""

import json
import logging
from typing import Any

from falkordb_memory_server.config import get_settings
from falkordb_memory_server.embeddings import EmbeddingService, get_embedding_service
from falkordb_memory_server.graph_ops import GraphOperations, get_graph_ops
from falkordb_memory_server.schema import NodeLabel

logger = logging.getLogger(__name__)


class SemanticSearchEngine:
    """Semantic search engine using vector similarity."""

    def __init__(
        self,
        ops: GraphOperations | None = None,
        embedding_service: EmbeddingService | None = None,
    ) -> None:
        """Initialize semantic search engine."""
        self.ops = ops or get_graph_ops()
        self.embedding_service = embedding_service or get_embedding_service()
        self.settings = get_settings()
        self._indexes_created = False

    def ensure_vector_indexes(self) -> dict[str, Any]:
        """
        Ensure vector indexes exist for all memory node types.

        Returns:
            Index creation results
        """
        if self._indexes_created:
            return {"status": "already_initialized"}

        results = {}
        labels_with_embeddings = [
            NodeLabel.LEARNING,
            NodeLabel.DECISION,
            NodeLabel.CODE,
            NodeLabel.CONCEPT,
        ]

        for label in labels_with_embeddings:
            try:
                result = self.ops.create_vector_index(
                    label=label,
                    property_name="embedding",
                    dimension=self.settings.embedding_dimension,
                    similarity_function="cosine",
                )
                results[label.value] = result
            except Exception as e:
                logger.warning(f"Could not create vector index for {label}: {e}")
                results[label.value] = {"error": str(e)}

        self._indexes_created = True
        return {"status": "initialized", "indexes": results}

    def search(
        self,
        query: str,
        node_label: NodeLabel | str | None = None,
        k: int = 10,
        min_score: float = 0.0,
        include_invalid: bool = False,
    ) -> list[dict[str, Any]]:
        """
        Perform semantic search using vector similarity.

        Args:
            query: Search query text
            node_label: Optional filter by node type
            k: Number of results
            min_score: Minimum similarity score (0-1)
            include_invalid: Include invalid facts

        Returns:
            List of matching nodes with scores
        """
        # 1. Check if embedding service is available
        if not self.embedding_service.is_available():
            logger.warning("Embedding service unavailable, falling back to text search")
            return self._fallback_text_search(query, node_label, k, include_invalid)

        # 2. Generate query embedding
        embedding_result = self.embedding_service.generate_embedding(query)
        if not embedding_result:
            logger.warning("Embedding generation failed, falling back to text search")
            return self._fallback_text_search(query, node_label, k, include_invalid)

        query_vector = embedding_result.vector

        # 3. Call ops.semantic_search (low-level vector query)
        try:
            results = self.ops.semantic_search(
                query_vector=query_vector,
                label=node_label,
                k=k,
                min_score=min_score,
            )

            # Filter by temporal validity if needed
            if not include_invalid:
                # Filter results where valid_to property is set
                results = [
                    r
                    for r in results
                    if r.get("node", {}).get("properties", {}).get("valid_to") is None
                ]

            return results
        except Exception as e:
            logger.error(f"Vector search failed: {e}, falling back to text search")
            # 4. Fallback to basic text search if failed
            return self._fallback_text_search(query, node_label, k, include_invalid)

    def progressive_search(
        self,
        query: str,
        node_label: NodeLabel | str | None = None,
        k: int = 10,
        min_score: float = 0.0,
        layer: int = 1,
        include_invalid: bool = False,
    ) -> list[dict[str, Any]]:
        """
        Perform progressive search:
        Layer 1: Semantic search
        Layer 2: Layer 1 + 1-hop neighbors
        Layer 3: Layer 1 + 2-hop traversal
        """
        # Always start with Layer 1 semantic search
        base_results = self.search(
            query=query,
            node_label=node_label,
            k=k,
            min_score=min_score,
            include_invalid=include_invalid,
        )

        if layer <= 1 or not base_results:
            return base_results

        # Extract base node IDs
        base_node_ids = []
        for r in base_results:
            node = r.get("node", {})
            # Handle different node formats from falkordb-py
            node_id = node.get("id") if isinstance(node, dict) else getattr(node, "id", None)
            if node_id is not None:
                try:
                    base_node_ids.append(int(node_id))
                except (ValueError, TypeError):
                    continue

        if not base_node_ids:
            return base_results

        # Determine traversal depth
        # Layer 2 = 1 hop, Layer 3 = 2 hops
        depth = 1 if layer == 2 else 2

        # Cypher to find neighbors
        # We want to return the neighbor nodes.
        # We also filter by temporal validity if include_invalid is False.
        temporal_clause = " AND m.valid_to IS NULL" if not include_invalid else ""

        cypher = f"""
        MATCH (n)-[*1..{depth}]-(m)
        WHERE id(n) IN $ids AND id(n) <> id(m){temporal_clause}
        RETURN DISTINCT m
        LIMIT $limit
        """

        # We might want to limit the number of neighbors to avoid huge results
        neighbor_limit = k * 3

        try:
            neighbor_result = self.ops.query(
                cypher, params={"ids": base_node_ids, "limit": neighbor_limit}, read_only=True
            )

            # Combine results
            seen_ids = set(base_node_ids)
            combined_results = list(base_results)

            for row in neighbor_result.get("result_set", []):
                if row and row[0]:
                    node_data = row[0]
                    # Handle different node formats from falkordb-py
                    node_id = (
                        node_data.get("id")
                        if isinstance(node_data, dict)
                        else getattr(node_data, "id", None)
                    )

                    if node_id is not None and int(node_id) not in seen_ids:
                        seen_ids.add(int(node_id))
                        combined_results.append(
                            {
                                "node": node_data,
                                "score": 0.0,  # Neighbors get 0 score or we could use some decay
                                "context": f"{layer}-layer context ({depth}-hop neighbor)",
                            }
                        )

            return combined_results

        except Exception as e:
            logger.error(f"Neighbor traversal failed: {e}")
            return base_results

    def _fallback_text_search(
        self,
        query: str,
        node_label: NodeLabel | str | None,
        k: int,
        include_invalid: bool = False,
    ) -> list[dict[str, Any]]:
        """Fallback to basic text search if vector search fails."""
        label_filter = ""
        params = {"query": query, "k": k}
        if node_label:
            label_str = node_label.value if isinstance(node_label, NodeLabel) else node_label
            label_filter = f":{label_str}"

        temporal_clause = " AND n.valid_to IS NULL" if not include_invalid else ""

        cypher = f"""
        MATCH (n{label_filter})
        WHERE (n.content CONTAINS $query OR n.title CONTAINS $query){temporal_clause}
        RETURN n
        LIMIT $k
        """

        result = self.ops.query(cypher, params=params, read_only=True)
        matches = []

        for row in result.get("result_set", []):
            if row:
                node_data = row[0]
                matches.append(
                    {
                        "node": node_data,
                        "score": 0.5,  # Default score for text match
                    }
                )

        return matches

    def embed_and_store(
        self,
        node_id: int | str,
        content: dict[str, Any],
        content_type: str = "memory",
    ) -> dict[str, Any]:
        """
        Generate embedding and store it on a node.

        Args:
            node_id: Node ID to attach embedding to
            content: Content to embed
            content_type: Type of content

        Returns:
            Update result with embedding info
        """
        # Prepare text for embedding
        text = self.embedding_service.prepare_text_for_embedding(content, content_type)

        # Generate embedding
        embedding_result = self.embedding_service.generate_embedding(text)
        if not embedding_result:
            return {"error": "Failed to generate embedding", "node_id": node_id}

        # Store embedding on node
        cypher = """
        MATCH (n)
        WHERE id(n) = $node_id
        SET n.embedding = $embedding, n.embedding_model = $model
        RETURN n
        """

        self.ops.query(
            cypher,
            params={
                "node_id": int(node_id),
                "embedding": embedding_result.vector,
                "model": embedding_result.model,
            },
        )

        return {
            "node_id": node_id,
            "embedding_dimension": embedding_result.dimension,
            "embedding_model": embedding_result.model,
            "text_preview": embedding_result.text_preview,
        }

    def find_similar(
        self,
        node_id: int | str,
        k: int = 5,
        min_score: float = 0.5,
    ) -> list[dict[str, Any]]:
        """
        Find nodes similar to a given node using its embedding.

        Args:
            node_id: Reference node ID
            k: Number of similar nodes to find
            min_score: Minimum similarity score

        Returns:
            List of similar nodes with scores
        """
        # Get the node's embedding
        cypher = """
        MATCH (n)
        WHERE id(n) = $node_id
        RETURN n.embedding as embedding
        """

        result = self.ops.query(cypher, params={"node_id": int(node_id)}, read_only=True)
        if (
            not result.get("result_set")
            or not result["result_set"][0]
            or not result["result_set"][0][0]
        ):
            return [{"error": "Node not found or has no embedding"}]

        embedding = result["result_set"][0][0]
        if isinstance(embedding, str):
            embedding = json.loads(embedding)

        # Find similar nodes using low-level semantic_search
        # We fetch k+1 and filter out the self node
        all_matches = self.ops.semantic_search(query_vector=embedding, k=k + 1, min_score=min_score)

        # Filter out the reference node and limit to k
        matches = [m for m in all_matches if m["node"].get("id") != int(node_id)][:k]

        return matches

    def recall(
        self,
        query: str,
        query_type: str = "semantic",
        filters: dict[str, Any] | None = None,
        limit: int = 10,
        include_invalid: bool = False,
    ) -> dict[str, Any]:
        """
        Recall memories using various query types.

        Args:
            query: Search query or Cypher string
            query_type: semantic, text, cypher, or traversal
            filters: Property filters
            limit: Maximum results
            include_invalid: Include invalid facts

        Returns:
            Search results in unified format
        """
        if query_type == "cypher":
            return self.ops.query(query, params=filters, read_only=True)

        if query_type == "semantic":
            matches = self.search(
                query=query,
                k=limit,
                include_invalid=include_invalid,
            )
            # Standardize output for consistency with other recall types
            return {
                "result_set": [[m["node"], m["score"]] for m in matches],
                "statistics": {"matches": len(matches)},
            }

        if query_type == "text":
            # Full-text search (requires index)
            # Note: FalkorDB fulltext index doesn't support complex WHERE easily in CALL
            temporal_clause = " WHERE node.valid_to IS NULL" if not include_invalid else ""
            cypher = f"""
            CALL db.idx.fulltext.queryNodes('content', $query)
            YIELD node, score
            {temporal_clause}
            RETURN node, score
            ORDER BY score DESC
            LIMIT $limit
            """
            return self.ops.query(cypher, params={"query": query, "limit": limit}, read_only=True)

        # Default: basic MATCH query
        temporal_clause = " AND n.valid_to IS NULL" if not include_invalid else ""
        cypher = f"""
        MATCH (n)
        WHERE (n.content CONTAINS $query OR (n.title IS NOT NULL AND n.title CONTAINS $query)){temporal_clause}
        RETURN n, 1.0 as score
        LIMIT $limit
        """
        return self.ops.query(cypher, params={"query": query, "limit": limit}, read_only=True)

    def hybrid_search(
        self,
        query: str,
        filters: dict[str, Any] | None = None,
        k: int = 10,
        vector_weight: float = 0.7,
    ) -> list[dict[str, Any]]:
        """
        Hybrid search combining vector similarity and text matching.

        Args:
            query: Search query
            filters: Property filters
            k: Number of results
            vector_weight: Weight for vector results (0-1, text gets 1 - vector_weight)

        Returns:
            Combined and ranked results
        """
        # Get vector results
        vector_results = self.search(query, k=k * 2)

        # Get text results
        params = {"query": query, "limit": k * 2}
        filter_parts = []
        if filters:
            for key, value in filters.items():
                param_name = f"filter_{key}"
                filter_parts.append(f"n.{key} = ${param_name}")
                params[param_name] = value

        where_clause = " AND ".join(filter_parts) if filter_parts else "true"

        text_cypher = f"""
        MATCH (n)
        WHERE ({where_clause})
        AND (n.content CONTAINS $query OR n.title CONTAINS $query)
        RETURN n
        LIMIT $limit
        """

        text_result = self.ops.query(text_cypher, params=params, read_only=True)
        text_results = []
        for row in text_result.get("result_set", []):
            if row:
                node_data = row[0]
                if isinstance(node_data, dict):
                    node_info = node_data
                else:
                    node_info = {
                        "id": getattr(node_data, "id", None),
                        "labels": list(getattr(node_data, "labels", [])),
                        "properties": dict(getattr(node_data, "properties", {})),
                    }
                text_results.append(node_info)

        # Combine results
        combined = {}
        text_weight = 1 - vector_weight

        # Add vector results
        for result in vector_results:
            if "node" in result:
                node_id = result["node"].get("id")
                if node_id:
                    combined[node_id] = {
                        "node": result["node"],
                        "score": result["score"] * vector_weight,
                    }

        # Add/merge text results
        for node in text_results:
            node_id = node.get("id")
            if node_id:
                if node_id in combined:
                    combined[node_id]["score"] += text_weight
                else:
                    combined[node_id] = {
                        "node": node,
                        "score": text_weight,
                    }

        # Sort by combined score
        sorted_results = sorted(
            combined.values(),
            key=lambda x: x["score"],
            reverse=True,
        )

        return sorted_results[:k]


# Global instance
_semantic_engine: SemanticSearchEngine | None = None


def get_semantic_engine() -> SemanticSearchEngine:
    """Get the global SemanticSearchEngine instance."""
    global _semantic_engine
    if _semantic_engine is None:
        _semantic_engine = SemanticSearchEngine()
    return _semantic_engine
