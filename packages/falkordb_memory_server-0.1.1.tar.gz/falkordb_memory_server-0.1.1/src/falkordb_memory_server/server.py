"""MCP Server for FalkorDB Memory System."""

import asyncio
import logging
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import CallToolResult, TextContent, Tool

import falkordb_memory_server.handlers.extraction  # noqa: F401
import falkordb_memory_server.handlers.graph  # noqa: F401
import falkordb_memory_server.handlers.maintenance  # noqa: F401
import falkordb_memory_server.handlers.memory  # noqa: F401
import falkordb_memory_server.handlers.semantic  # noqa: F401
import falkordb_memory_server.handlers.session  # noqa: F401
import falkordb_memory_server.handlers.tier  # noqa: F401
from falkordb_memory_server.config import get_settings
from falkordb_memory_server.graph_ops import (
    DatabaseConnectionError,
    GraphOperationError,
    GraphOperations,
    get_graph_ops,
)

# Import handlers to trigger registration
from falkordb_memory_server.handlers import registry
from falkordb_memory_server.handlers.extraction import (  # noqa: F401
    handle_extract,
    handle_load_project_context,
    handle_mine,
    handle_mine_conversations,
)

# Re-export for tests
from falkordb_memory_server.handlers.graph import (  # noqa: F401
    handle_create_edge,
    handle_create_node,
    handle_delete,
    handle_query,
)
from falkordb_memory_server.handlers.maintenance import handle_cleanup, handle_stats  # noqa: F401
from falkordb_memory_server.handlers.memory import (  # noqa: F401
    handle_associate,
    handle_forget,
    handle_get_api_usage,
    handle_get_bug_patterns,
    handle_get_code_patterns,
    handle_get_conventions,
    handle_get_decision_chain,
    handle_get_refactors,
    handle_get_reviews,
    handle_get_test_coverage,
    handle_invalidate,
    handle_recall,
    handle_remember,
    handle_wake_up,
)
from falkordb_memory_server.handlers.semantic import handle_semantic_search  # noqa: F401
from falkordb_memory_server.handlers.session import (  # noqa: F401
    handle_end_session,
    handle_start_session,
)
from falkordb_memory_server.handlers.tier import (  # noqa: F401
    handle_demote,
    handle_promote,
    handle_set_tier,
)

TOOLS = registry.tools

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create MCP server instance
server = Server("falkordb-memory-server")


def get_ops() -> GraphOperations:
    """Get graph operations instance."""
    return get_graph_ops()


@server.list_tools()
async def list_tools() -> list[Tool]:
    """Return list of available tools."""
    return registry.tools


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> CallToolResult:
    """Handle tool calls."""
    try:
        ops = get_ops()
        if name in registry.handlers:
            content = registry.handlers[name](ops, arguments)
            return CallToolResult(content=content)
        else:
            return CallToolResult(
                content=[TextContent(type="text", text=f"Unknown tool: {name}")],
                isError=True,
            )

    except (DatabaseConnectionError, GraphOperationError) as e:
        logger.error(f"Database error executing tool {name}: {e}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"Database error: {str(e)}")],
            isError=True,
        )
    except Exception as e:
        logger.exception(f"Error executing tool {name}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"Error: {str(e)}")],
            isError=True,
        )


async def run_server() -> None:
    """Run the MCP server."""
    settings = get_settings()
    logger.info(f"Starting FalkorDB Memory Server (graph: {settings.graph_name})")
    logger.info(f"Embedding model: {settings.embedding_model}")

    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main() -> None:
    """Main entry point."""
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "init":
        from falkordb_memory_server.setup import interactive_setup

        interactive_setup()
        return

    asyncio.run(run_server())


if __name__ == "__main__":
    main()
