"""Gemini CLI integration for the memory system.

This module provides the adapter layer for Gemini CLI agents to interact
with the FalkorDB memory system through the MCP protocol.

Gemini CLI Configuration:
- Uses GEMINI_API_KEY for authentication
- Supports model selection via GEMINI_MODEL env var
- Integrates with OMC team runtime as 'gemini' agent type

Usage:
    # Configure Gemini CLI to use memory MCP server
    export GEMINI_MCP_SERVERS='[{"name": "memory", "command": "python", "args": ["-m", "falkordb_memory_server"]}]'

    # Or add to Gemini CLI config file
"""

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from falkordb_memory_server.graph_ops import DatabaseConnectionError, GraphOperationError

logger = logging.getLogger(__name__)


# ============================================================
# Gemini CLI Configuration Models
# ============================================================


class GeminiMcpServer(BaseModel):
    """MCP server configuration for Gemini CLI."""

    name: str
    command: str
    args: list[str] = []
    env: dict[str, str] = {}
    type: str = "stdio"  # stdio or http


class GeminiConfig(BaseModel):
    """Full Gemini CLI configuration."""

    api_key: str | None = None
    model: str = "gemini-2.0-flash"
    mcp_servers: list[GeminiMcpServer] = []
    memory_enabled: bool = True
    memory_namespace: str | None = None


# ============================================================
# Memory Adapter for Gemini
# ============================================================


@dataclass
class GeminiMemoryAdapter:
    """
    Adapter for Gemini CLI to interact with the memory system.

    This provides a simplified interface for Gemini agents to store,
    recall, and share memories through the FalkorDB backend.
    """

    agent_id: str
    model: str = "gemini-2.0-flash"
    namespace: str | None = None
    project_path: str | None = None

    # Session tracking
    _session_id: str | None = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        """Initialize namespace from project path if not set."""
        if self.namespace is None and self.project_path:
            self.namespace = f"gemini:{Path(self.project_path).name}"

    # ============================================================
    # Session Management
    # ============================================================

    def start_session(self, objective: str | None = None) -> dict[str, Any]:
        """
        Start a new Gemini session in the memory system.

        Args:
            objective: Session goal/objective

        Returns:
            Session information
        """
        try:
            # Import here to avoid circular dependencies
            from falkordb_memory_server.session import get_session_manager

            manager = get_session_manager()
            result = manager.start_session(
                agent_type="gemini",
                agent_id=self.agent_id,
                project_path=self.project_path,
                objective=objective,
            )

            self._session_id = result.get("session_id")
            return result
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to start session: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error starting session")
            return {"error": str(e)}

    def end_session(self, status: str = "completed", summary: str | None = None) -> dict[str, Any]:
        """
        End the current session.

        Args:
            status: Session end status (completed, abandoned)
            summary: Session summary

        Returns:
            End session result
        """
        if not self._session_id:
            return {"error": "No active session"}

        try:
            from falkordb_memory_server.session import get_session_manager

            manager = get_session_manager()
            return manager.end_session(self._session_id, status, summary)
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to end session: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error ending session")
            return {"error": str(e)}

    # ============================================================
    # Memory Operations
    # ============================================================

    def remember(
        self,
        content: str,
        memory_type: str = "learning",
        title: str | None = None,
        tags: list[str] | None = None,
        ttl: int | None = None,
    ) -> dict[str, Any]:
        """
        Store a memory from Gemini.

        Args:
            content: Memory content
            memory_type: Type (learning, decision, code, concept)
            title: Optional title
            tags: Optional tags
            ttl: Time-to-live in seconds

        Returns:
            Created memory information
        """
        try:
            from falkordb_memory_server.memory_tools import get_memory_manager

            manager = get_memory_manager()

            memory_content = {"content": content}
            if title:
                memory_content["title"] = title
            if tags:
                memory_content["tags"] = tags

            context = {
                "agent_type": "gemini",
                "agent_id": self.agent_id,
                "model": self.model,
                "session_id": self._session_id,
            }
            if self.namespace:
                context["namespace"] = self.namespace

            return manager.remember(
                memory_type=memory_type,
                content=memory_content,
                context=context,
                ttl=ttl,
            )
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to store memory: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error storing memory")
            return {"error": str(e)}

    def recall(
        self,
        query: str,
        memory_types: list[str] | None = None,
        limit: int = 10,
    ) -> dict[str, Any]:
        """
        Recall memories matching a query.

        Args:
            query: Search query
            memory_types: Filter by memory types
            limit: Maximum results

        Returns:
            Matching memories
        """
        try:
            from falkordb_memory_server.memory_tools import get_memory_manager

            manager = get_memory_manager()

            filters = {"agent_type": "gemini"}
            if self.namespace:
                filters["namespace"] = self.namespace
            if memory_types:
                # Will be handled in the query
                pass

            return manager.recall(
                query_type="text",
                query=query,
                filters=filters,
                limit=limit,
            )
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to recall memories: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error recalling memories")
            return {"error": str(e)}

    def semantic_search(
        self,
        query: str,
        k: int = 5,
    ) -> list[dict[str, Any]]:
        """
        Perform semantic search using embeddings.

        Args:
            query: Search query
            k: Number of results

        Returns:
            Matching memories with similarity scores
        """
        try:
            from falkordb_memory_server.semantic_tools import get_semantic_engine

            engine = get_semantic_engine()
            return engine.search(query, k=k)
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Semantic search failed: {e}")
            return [{"error": str(e)}]
        except Exception as e:
            logger.exception("Unexpected error in semantic search")
            return [{"error": str(e)}]

    def share_with_claude(self, memory_id: int | str) -> dict[str, Any]:
        """
        Share a memory with Claude agents.

        Args:
            memory_id: Memory node ID

        Returns:
            Sharing result
        """
        try:
            from falkordb_memory_server.sharing import get_sharing_manager

            manager = get_sharing_manager()
            return manager.share_memory(memory_id, ["claude"])
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to share memory with Claude: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error sharing memory")
            return {"error": str(e)}

    def share_with_codex(self, memory_id: int | str) -> dict[str, Any]:
        """
        Share a memory with Codex agents.

        Args:
            memory_id: Memory node ID

        Returns:
            Sharing result
        """
        try:
            from falkordb_memory_server.sharing import get_sharing_manager

            manager = get_sharing_manager()
            return manager.share_memory(memory_id, ["codex"])
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to share memory with Codex: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error sharing memory")
            return {"error": str(e)}

    def get_claude_memories(self, limit: int = 20) -> dict[str, Any]:
        """
        Get memories shared by Claude agents.

        Args:
            limit: Maximum results

        Returns:
            Shared memories
        """
        try:
            from falkordb_memory_server.sharing import get_sharing_manager

            manager = get_sharing_manager()
            return manager.query_agent_memories(agent_type="claude", limit=limit)
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to get Claude memories: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error getting memories")
            return {"error": str(e)}

    def get_codex_memories(self, limit: int = 20) -> dict[str, Any]:
        """
        Get memories shared by Codex agents.

        Args:
            limit: Maximum results

        Returns:
            Shared memories
        """
        try:
            from falkordb_memory_server.sharing import get_sharing_manager

            manager = get_sharing_manager()
            return manager.query_agent_memories(agent_type="codex", limit=limit)
        except (DatabaseConnectionError, GraphOperationError) as e:
            logger.error(f"Failed to get Codex memories: {e}")
            return {"error": str(e)}
        except Exception as e:
            logger.exception("Unexpected error getting memories")
            return {"error": str(e)}


# ============================================================
# Gemini CLI MCP Configuration Generator
# ============================================================


def generate_gemini_mcp_config(
    falkordb_url: str = "redis://localhost:6379",
    embedding_model: str = "all-MiniLM-L6-v2",
    graph_name: str = "agent_memory",
) -> dict[str, Any]:
    """
    Generate MCP server configuration for Gemini CLI.

    Args:
        falkordb_url: FalkorDB connection URL
        embedding_model: Embedding model name
        graph_name: Graph database name

    Returns:
        MCP server configuration
    """
    return {
        "mcpServers": {
            "memory": {
                "command": "python",
                "args": ["-m", "falkordb_memory_server"],
                "env": {
                    "FALKORDB_URL": falkordb_url,
                    "EMBEDDING_MODEL": embedding_model,
                    "GRAPH_NAME": graph_name,
                },
            }
        }
    }


def write_gemini_config(
    output_path: str | Path,
    falkordb_url: str = "redis://localhost:6379",
    embedding_model: str = "all-MiniLM-L6-v2",
    graph_name: str = "agent_memory",
) -> dict[str, Any]:
    """
    Write Gemini CLI configuration file.

    Args:
        output_path: Path to write config (e.g., ~/.gemini/config.json)
        falkordb_url: FalkorDB connection URL
        embedding_model: Embedding model name
        graph_name: Graph database name

    Returns:
        Written configuration
    """
    output_path = Path(output_path)
    config = generate_gemini_mcp_config(falkordb_url, embedding_model, graph_name)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(config, f, indent=2)

    return {
        "path": str(output_path),
        "config": config,
    }


# ============================================================
# Environment Variable Setup for OMC Integration
# ============================================================


def setup_gemini_env(
    agent_id: str | None = None,
    model: str = "gemini-2.0-flash",
    project_path: str | None = None,
) -> dict[str, str]:
    """
    Generate environment variables for Gemini agent in OMC team.

    Args:
        agent_id: Agent identifier
        model: Gemini model name
        project_path: Project working directory

    Returns:
        Environment variables dict
    """
    env = {
        "GEMINI_MODEL": model,
        "OMC_EXTERNAL_MODELS_DEFAULT_GEMINI_MODEL": model,
    }

    if agent_id:
        env["GEMINI_AGENT_ID"] = agent_id

    if project_path:
        env["GEMINI_PROJECT_PATH"] = project_path

    return env


# ============================================================
# Convenience Functions for Direct Usage
# ============================================================


def gemini_remember(content: str, **kwargs: Any) -> dict[str, Any]:
    """
    Convenience function for Gemini to store a memory.

    Args:
        content: Memory content
        **kwargs: Additional arguments (title, tags, ttl)

    Returns:
        Created memory info
    """
    adapter = GeminiMemoryAdapter(
        agent_id=os.environ.get("GEMINI_AGENT_ID", "gemini-default"),
        model=os.environ.get("GEMINI_MODEL", "gemini-2.0-flash"),
        project_path=os.environ.get("GEMINI_PROJECT_PATH"),
    )
    return adapter.remember(content, **kwargs)


def gemini_recall(query: str, limit: int = 10) -> dict[str, Any]:
    """
    Convenience function for Gemini to recall memories.

    Args:
        query: Search query
        limit: Maximum results

    Returns:
        Matching memories
    """
    adapter = GeminiMemoryAdapter(
        agent_id=os.environ.get("GEMINI_AGENT_ID", "gemini-default"),
        model=os.environ.get("GEMINI_MODEL", "gemini-2.0-flash"),
        project_path=os.environ.get("GEMINI_PROJECT_PATH"),
    )
    return adapter.recall(query, limit=limit)


def gemini_semantic_search(query: str, k: int = 5) -> list[dict[str, Any]]:
    """
    Convenience function for Gemini semantic search.

    Args:
        query: Search query
        k: Number of results

    Returns:
        Matching memories with scores
    """
    adapter = GeminiMemoryAdapter(
        agent_id=os.environ.get("GEMINI_AGENT_ID", "gemini-default"),
        model=os.environ.get("GEMINI_MODEL", "gemini-2.0-flash"),
        project_path=os.environ.get("GEMINI_PROJECT_PATH"),
    )
    return adapter.semantic_search(query, k=k)
