"""OMC integration - sync with notepad and project-memory."""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from falkordb_memory_server.config import get_settings
from falkordb_memory_server.graph_ops import GraphOperations, get_graph_ops
from falkordb_memory_server.memory_tools import MemoryManager, get_memory_manager
from falkordb_memory_server.schema import MemoryType

logger = logging.getLogger(__name__)


class OMCSyncService:
    """Synchronize between FalkorDB memory and OMC systems."""

    def __init__(
        self,
        ops: GraphOperations | None = None,
        memory_manager: MemoryManager | None = None,
    ) -> None:
        """Initialize OMC sync service."""
        self.ops = ops or get_graph_ops()
        self.memory_manager = memory_manager or get_memory_manager()
        self.settings = get_settings()

    # ============================================================
    # Notepad Synchronization
    # ============================================================

    def sync_notepad_to_graph(
        self,
        notepad_path: str | Path,
        session_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Sync OMC notepad content to the memory graph.

        Args:
            notepad_path: Path to .omc/notepad.md
            session_id: Optional session to associate

        Returns:
            Sync result
        """
        notepad_path = Path(notepad_path)
        if not notepad_path.exists():
            return {"error": f"Notepad not found: {notepad_path}"}

        content = notepad_path.read_text()
        sections = self._parse_notepad(content)

        results = {
            "priority": None,
            "working": [],
            "manual": [],
        }

        # Sync priority context
        if sections.get("priority"):
            result = self.memory_manager.remember(
                memory_type=MemoryType.LEARNING,
                content={
                    "title": "Priority Context",
                    "content": sections["priority"],
                    "category": "context",
                    "tags": ["priority", "notepad"],
                },
                context={"session_id": session_id, "source": "notepad"},
            )
            results["priority"] = result

        # Sync working memory entries
        for entry in sections.get("working", []):
            result = self.memory_manager.remember(
                memory_type=MemoryType.LEARNING,
                content={
                    "title": entry.get("title", "Working Memory Entry"),
                    "content": entry.get("content", ""),
                    "category": "working_memory",
                    "tags": ["working", "notepad"],
                },
                context={
                    "session_id": session_id,
                    "source": "notepad",
                    "timestamp": entry.get("timestamp"),
                },
            )
            results["working"].append(result)

        # Sync manual entries
        for entry in sections.get("manual", []):
            result = self.memory_manager.remember(
                memory_type=MemoryType.LEARNING,
                content={
                    "title": entry.get("title", "Manual Entry"),
                    "content": entry.get("content", ""),
                    "category": "manual_memory",
                    "tags": ["manual", "notepad"],
                },
                context={"session_id": session_id, "source": "notepad"},
            )
            results["manual"].append(result)

        return {
            "status": "synced",
            "notepad_path": str(notepad_path),
            "results": results,
        }

    def sync_graph_to_notepad(
        self,
        notepad_path: str | Path,
        session_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Sync memory graph content back to notepad.

        Args:
            notepad_path: Path to .omc/notepad.md
            session_id: Optional session filter

        Returns:
            Sync result
        """
        notepad_path = Path(notepad_path)

        # Query relevant memories
        if session_id:
            cypher = f"""
            MATCH (l:Learning)
            WHERE l.context CONTAINS '{session_id}' OR l.tags CONTAINS 'notepad'
            RETURN l
            ORDER BY l.created_at DESC
            LIMIT 20
            """
        else:
            cypher = """
            MATCH (l:Learning)
            WHERE l.tags CONTAINS 'notepad'
            RETURN l
            ORDER BY l.created_at DESC
            LIMIT 20
            """

        result = self.ops.query(cypher, read_only=True)
        memories = result.get("result_set", [])

        # Build notepad content
        priority_lines = []
        working_lines = []
        manual_lines = []

        for row in memories:
            if len(row) < 1:
                continue
            node = row[0]
            props = node.get("properties", {}) if isinstance(node, dict) else {}

            category = props.get("category", "")
            content = props.get("content", "")
            title = props.get("title", "")
            created = props.get("created_at", "")

            if category == "context":
                priority_lines.append(content)
            elif category == "working_memory":
                working_lines.append(f"- [{created}] {title}: {content[:100]}")
            elif category == "manual_memory":
                manual_lines.append(f"- {title}: {content[:200]}")

        # Build notepad content
        notepad_content = "# OMC Notepad\n\n"
        notepad_content += "## Priority Context\n"
        notepad_content += "\n".join(priority_lines) if priority_lines else "(empty)\n"
        notepad_content += "\n\n## Working Memory\n"
        notepad_content += "\n".join(working_lines) if working_lines else "(empty)\n"
        notepad_content += "\n\n## Manual\n"
        notepad_content += "\n".join(manual_lines) if manual_lines else "(empty)\n"

        # Write notepad
        notepad_path.parent.mkdir(parents=True, exist_ok=True)
        notepad_path.write_text(notepad_content)

        return {
            "status": "synced",
            "notepad_path": str(notepad_path),
            "priority_count": len(priority_lines),
            "working_count": len(working_lines),
            "manual_count": len(manual_lines),
        }

    # ============================================================
    # Project Memory Synchronization
    # ============================================================

    def sync_project_memory_to_graph(
        self,
        project_memory_path: str | Path,
    ) -> dict[str, Any]:
        """
        Sync OMC project-memory.json to the memory graph.

        Args:
            project_memory_path: Path to .omc/project-memory.json

        Returns:
            Sync result
        """
        project_memory_path = Path(project_memory_path)
        if not project_memory_path.exists():
            return {"error": f"Project memory not found: {project_memory_path}"}

        with open(project_memory_path) as f:
            data = json.load(f)

        results = {
            "tech_stack": [],
            "conventions": [],
            "notes": [],
        }

        # Sync tech stack
        tech_stack = data.get("techStack", {})
        for category, items in tech_stack.items():
            for item in items if isinstance(items, list) else [items]:
                result = self.memory_manager.remember(
                    memory_type=MemoryType.CONCEPT,
                    content={
                        "name": item if isinstance(item, str) else item.get("name", "Unknown"),
                        "category": category,
                        "description": f"Tech stack: {category}",
                    },
                    context={"source": "project-memory"},
                )
                results["tech_stack"].append(result)

        # Sync conventions
        conventions = data.get("conventions", {})
        for conv_type, conv_content in conventions.items():
            result = self.memory_manager.remember(
                memory_type=MemoryType.LEARNING,
                content={
                    "title": f"Convention: {conv_type}",
                    "content": json.dumps(conv_content)
                    if isinstance(conv_content, dict)
                    else str(conv_content),
                    "category": "convention",
                    "tags": ["convention", conv_type],
                },
                context={"source": "project-memory"},
            )
            results["conventions"].append(result)

        # Sync notes
        notes = data.get("notes", [])
        for note in notes:
            result = self.memory_manager.remember(
                memory_type=MemoryType.LEARNING,
                content={
                    "title": note.get("title", "Project Note"),
                    "content": note.get("content", ""),
                    "category": note.get("category", "project_note"),
                    "tags": note.get("tags", []),
                },
                context={"source": "project-memory"},
            )
            results["notes"].append(result)

        return {
            "status": "synced",
            "project_memory_path": str(project_memory_path),
            "results": results,
        }

    def export_graph_to_project_memory(
        self,
        output_path: str | Path,
        project_path: str | None = None,
    ) -> dict[str, Any]:
        """
        Export graph memories to project-memory.json format.

        Args:
            output_path: Output file path
            project_path: Optional project filter

        Returns:
            Export result
        """
        # Query concepts for tech stack
        tech_cypher = """
        MATCH (c:Concept)
        WHERE c.category IN ['language', 'framework', 'build', 'runtime', 'tool']
        RETURN c.category as category, c.name as name
        """

        tech_result = self.ops.query(tech_cypher, read_only=True)
        tech_stack = {}

        for row in tech_result.get("result_set", []):
            if len(row) >= 2:
                category, name = row[0], row[1]
                if category not in tech_stack:
                    tech_stack[category] = []
                tech_stack[category].append(name)

        # Query conventions
        conv_cypher = """
        MATCH (l:Learning)
        WHERE l.category = 'convention'
        RETURN l.title as title, l.content as content
        """

        conv_result = self.ops.query(conv_cypher, read_only=True)
        conventions = {}

        for row in conv_result.get("result_set", []):
            if len(row) >= 2:
                title, content = row[0], row[1]
                conv_type = title.replace("Convention: ", "").lower()
                try:
                    conventions[conv_type] = json.loads(content)
                except json.JSONDecodeError:
                    conventions[conv_type] = content

        # Query notes
        notes_cypher = """
        MATCH (l:Learning)
        WHERE l.category IN ['project_note', 'insight', 'tip']
        RETURN l.title as title, l.content as content, l.category as category, l.tags as tags
        LIMIT 50
        """

        notes_result = self.ops.query(notes_cypher, read_only=True)
        notes = []

        for row in notes_result.get("result_set", []):
            if len(row) >= 4:
                notes.append(
                    {
                        "title": row[0],
                        "content": row[1],
                        "category": row[2],
                        "tags": row[3] if isinstance(row[3], list) else [],
                    }
                )

        # Build output
        output = {
            "techStack": tech_stack,
            "build": {},
            "conventions": conventions,
            "structure": {},
            "notes": notes,
            "directives": [],
        }

        # Write output
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(output, f, indent=2)

        return {
            "status": "exported",
            "output_path": str(output_path),
            "tech_stack_items": sum(len(v) for v in tech_stack.values()),
            "conventions_count": len(conventions),
            "notes_count": len(notes),
        }

    # ============================================================
    # Helper Methods
    # ============================================================

    def _parse_notepad(self, content: str) -> dict[str, Any]:
        """Parse notepad markdown content into sections."""
        sections = {
            "priority": "",
            "working": [],
            "manual": [],
        }

        current_section = None
        current_content = []

        for line in content.split("\n"):
            if line.startswith("## Priority Context"):
                if current_section and current_content:
                    sections[current_section] = "\n".join(current_content).strip()
                current_section = "priority"
                current_content = []
            elif line.startswith("## Working Memory"):
                if current_section and current_content:
                    sections[current_section] = "\n".join(current_content).strip()
                current_section = "working"
                current_content = []
            elif line.startswith("## Manual"):
                if current_section and current_content:
                    sections[current_section] = "\n".join(current_content).strip()
                current_section = "manual"
                current_content = []
            elif current_section:
                current_content.append(line)

        # Handle last section
        if current_section and current_content:
            sections[current_section] = "\n".join(current_content).strip()

        # Parse working memory entries
        if sections["working"]:
            entries = []
            for line in sections["working"].split("\n"):
                if line.startswith("- "):
                    entries.append(
                        {
                            "content": line[2:],
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        }
                    )
            sections["working"] = entries

        return sections


# Global instance
_omc_sync: OMCSyncService | None = None


def get_omc_sync() -> OMCSyncService:
    """Get the global OMCSyncService instance."""
    global _omc_sync
    if _omc_sync is None:
        _omc_sync = OMCSyncService()
    return _omc_sync
