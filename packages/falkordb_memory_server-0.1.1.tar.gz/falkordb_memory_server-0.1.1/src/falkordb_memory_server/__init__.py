"""FalkorDB Memory Server - Cross-platform, cross-agent memory system."""

__version__ = "0.1.0"

# from falkordb_memory_server.server import main

# __all__ = ["main"]
