"""Handler module."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from falkordb_memory_server.graph_ops import GraphOperations
from falkordb_memory_server.handlers import registry


@registry.register(
    Tool(
        name="memory_stats",
        description="Get statistics about the memory graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "detailed": {
                    "type": "boolean",
                    "description": "Include detailed statistics",
                    "default": False,
                }
            },
        },
    )
)
def handle_stats(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_stats tool."""
    result = ops.get_stats()
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_cleanup",
        description="Remove expired memories based on TTL.",
        inputSchema={
            "type": "object",
            "properties": {
                "dry_run": {
                    "type": "boolean",
                    "description": "Report only, don't delete",
                    "default": True,
                },
                "batch_size": {
                    "type": "integer",
                    "description": "Batch size for deletion",
                    "default": 100,
                },
            },
        },
    )
)
def handle_cleanup(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_cleanup tool."""
    from falkordb_memory_server.ttl import get_ttl_manager

    dry_run = args.get("dry_run", True)
    batch_size = args.get("batch_size", 100)
    ttl_manager = get_ttl_manager()
    result = ttl_manager.cleanup_expired(dry_run=dry_run, batch_size=batch_size, cascade=True)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]
