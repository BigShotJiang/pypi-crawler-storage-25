"""Tool handlers registry for FalkorDB Memory Server."""

from collections.abc import Callable
from typing import Any

from mcp.types import TextContent, Tool

from falkordb_memory_server.graph_ops import GraphOperations

HandlerFunc = Callable[[GraphOperations, dict[str, Any]], list[TextContent]]


class ToolRegistry:
    """Registry for mapping tools to their handler functions."""

    def __init__(self) -> None:
        self.tools: list[Tool] = []
        self.handlers: dict[str, HandlerFunc] = {}

    def register(self, tool: Tool) -> Callable[[HandlerFunc], HandlerFunc]:
        """Decorator to register a tool and its handler."""

        def decorator(func: HandlerFunc) -> HandlerFunc:
            self.tools.append(tool)
            self.handlers[tool.name] = func
            return func

        return decorator


registry = ToolRegistry()
