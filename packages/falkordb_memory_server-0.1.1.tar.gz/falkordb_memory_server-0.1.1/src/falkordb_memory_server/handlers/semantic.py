"""Handler module."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from falkordb_memory_server.graph_ops import GraphOperations
from falkordb_memory_server.handlers import registry
from falkordb_memory_server.semantic_tools import get_semantic_engine


@registry.register(
    Tool(
        name="memory_semantic_search",
        description="Find semantically similar memories using vector similarity search.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Text to search for"},
                "node_label": {"type": "string", "description": "Filter by node type (optional)"},
                "k": {"type": "integer", "description": "Number of results", "default": 10},
                "min_score": {
                    "type": "number",
                    "description": "Minimum similarity score (0-1)",
                    "default": 0.0,
                },
                "layer": {
                    "type": "integer",
                    "description": "Progressive Disclosure layer: 1 (semantic), 2 (semantic + 1-hop), 3 (semantic + 2-hop)",
                    "enum": [1, 2, 3],
                    "default": 1,
                },
            },
            "required": ["query"],
        },
    )
)
def handle_semantic_search(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_semantic_search tool."""
    from falkordb_memory_server.schema import NodeLabel

    query = args.get("query", "")
    node_label = args.get("node_label")
    k = args.get("k", 10)
    min_score = args.get("min_score", 0.0)
    layer = args.get("layer", 1)
    label_enum = None
    if node_label:
        try:
            label_enum = NodeLabel(node_label)
        except ValueError:
            label_enum = node_label
    results = get_semantic_engine().progressive_search(
        query=query, node_label=label_enum, k=k, min_score=min_score, layer=layer
    )
    return [TextContent(type="text", text=json.dumps(results, indent=2, default=str))]
