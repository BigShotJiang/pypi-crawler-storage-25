"""Handler module."""

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from mcp.types import TextContent, Tool

from falkordb_memory_server.extractor import (
    PROJECT_CONTEXT_FILES,
    MemoryCategory,
    MemoryExtractor,
    compute_file_hash,
    mine_directory,
    mine_file,
)
from falkordb_memory_server.graph_ops import GraphOperations
from falkordb_memory_server.handlers import registry

logger = logging.getLogger(__name__)


@registry.register(
    Tool(
        name="memory_extract",
        description="Extract memories from text using rule-based pattern matching. Zero API calls, identifies decisions, preferences, milestones, problems, and learnings.",
        inputSchema={
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Text content to extract memories from"},
                "source_file": {
                    "type": "string",
                    "description": "Optional source file path for attribution",
                },
                "min_confidence": {
                    "type": "number",
                    "description": "Minimum confidence threshold (0-1)",
                    "default": 0.3,
                },
                "extraction_mode": {
                    "type": "string",
                    "description": "Optional extraction mode: programming, office, life",
                    "enum": ["programming", "office", "life"],
                },
                "store": {
                    "type": "boolean",
                    "description": "Automatically store extracted memories to graph",
                    "default": False,
                },
            },
            "required": ["text"],
        },
    )
)
def handle_extract(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_extract tool."""
    text = args.get("text", "")
    source_file = args.get("source_file")
    min_confidence = args.get("min_confidence", 0.3)
    extraction_mode = args.get("extraction_mode")
    store = args.get("store", False)
    extractor = MemoryExtractor(min_confidence=min_confidence, mode=extraction_mode)
    result = extractor.extract(text, source_file=source_file)
    if store and result.memories:
        from falkordb_memory_server.memory_tools import MemoryManager

        manager = MemoryManager(ops=ops)
        category_to_type = {
            MemoryCategory.DECISION: "decision",
            MemoryCategory.PREFERENCE: "learning",
            MemoryCategory.MILESTONE: "task",
            MemoryCategory.PROBLEM: "problem",
            MemoryCategory.SOLUTION: "solution",
            MemoryCategory.EMOTIONAL: "learning",
            MemoryCategory.LEARNING: "learning",
            MemoryCategory.CONTEXT: "learning",
            MemoryCategory.CONVENTION: "convention",
            MemoryCategory.DEPENDENCY: "dependency",
            MemoryCategory.GENERAL: "learning",
        }
        stored_ids = []
        for memory in result.memories:
            mem_type = category_to_type.get(memory.category, "learning")
            props = {
                "content": memory.content,
                "category": memory.category.value,
                "confidence": memory.confidence,
                "keywords": memory.keywords,
                "source_file": memory.source_file,
                "extracted_at": datetime.now(timezone.utc).isoformat(),
            }
            res = manager.remember(memory_type=mem_type, content=props, generate_embedding=False)
            if "node_id" in res:
                stored_ids.append(res["node_id"])
            elif "id" in res:
                stored_ids.append(res["id"])
        result_dict = result.model_dump()
        result_dict["stored_count"] = len(stored_ids)
        result_dict["stored_ids"] = stored_ids
        return [TextContent(type="text", text=json.dumps(result_dict, indent=2, default=str))]
    return [TextContent(type="text", text=json.dumps(result.model_dump(), indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_mine",
        description="Mine files or directories for memories. Scans code, docs, and transcripts to extract decisions, learnings, and patterns.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File or directory path to mine"},
                "recursive": {
                    "type": "boolean",
                    "description": "Recurse into subdirectories",
                    "default": True,
                },
                "file_extensions": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "File extensions to include (e.g., ['.md', '.py', '.txt'])",
                },
                "store": {
                    "type": "boolean",
                    "description": "Automatically store extracted memories to graph",
                    "default": False,
                },
                "incremental": {
                    "type": "boolean",
                    "description": "Only mine files that have changed since last mine (requires store=True to track state in graph)",
                    "default": True,
                },
            },
            "required": ["path"],
        },
    )
)
def handle_mine(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_mine tool."""
    path_str = args.get("path", "")
    recursive = args.get("recursive", True)
    file_extensions = args.get("file_extensions")
    store = args.get("store", False)
    incremental = args.get("incremental", True)
    target = Path(path_str).absolute()
    path_str = str(target)
    ext_set = set(file_extensions) if file_extensions else None
    extraction_mode = args.get("extraction_mode")
    extractor = MemoryExtractor(mode=extraction_mode)
    existing_states = {}
    if incremental and store:
        cypher = "\n        MATCH (a:Artifact)\n        WHERE a.path = $path OR a.path STARTS WITH $prefix\n        RETURN a.path as path, a.mtime as mtime, a.hash as hash\n        "
        prefix = path_str + os.sep if target.is_dir() else path_str
        try:
            state_result = ops.safe_query(
                cypher, params={"path": path_str, "prefix": prefix}, read_only=True
            )
            for row in state_result.get("result_set", []):
                p, mtime, h = row
                existing_states[p] = {"mtime": mtime, "hash": h}
        except Exception as e:
            logger.warning(f"Could not fetch existing states: {e}")
    processed_states = {}

    def state_tracker(filepath: Path) -> bool:
        """Callback to track file state and decide whether to skip mining."""
        abs_path = str(filepath.absolute())
        try:
            stat = filepath.stat()
            mtime = stat.st_mtime
            state = existing_states.get(abs_path)
            if state:
                if state.get("mtime") == mtime:
                    if store:
                        processed_states[abs_path] = {"mtime": mtime, "hash": state.get("hash")}
                    return True if incremental and store else False
                f_hash = compute_file_hash(filepath)
                if state.get("hash") == f_hash:
                    if store:
                        processed_states[abs_path] = {"mtime": mtime, "hash": f_hash}
                    return True if incremental and store else False
                if store:
                    processed_states[abs_path] = {"mtime": mtime, "hash": f_hash}
                return False
            else:
                if store:
                    f_hash = compute_file_hash(filepath)
                    processed_states[abs_path] = {"mtime": mtime, "hash": f_hash}
                return False
        except Exception as e:
            logger.warning(f"Error checking state for {abs_path}: {e}")
            return False

    if target.is_file():
        if state_tracker(target):
            from falkordb_memory_server.extractor import ExtractionResult

            result = ExtractionResult()
        else:
            result = mine_file(target, extractor)
    elif target.is_dir():
        result = mine_directory(
            target,
            recursive=recursive,
            file_extensions=ext_set,
            extractor=extractor,
            skip_callback=state_tracker if store else None,
        )
    else:
        return [TextContent(type="text", text=f"Error: Path not found: {path_str}")]
    if store:
        if processed_states:
            artifact_batch = []
            for p, s in processed_states.items():
                artifact_batch.append(
                    {
                        "path": p,
                        "name": Path(p).name,
                        "type": "code"
                        if Path(p).suffix.lower() in {".py", ".js", ".ts", ".go", ".java"}
                        else "document",
                        "mtime": s["mtime"],
                        "hash": s["hash"],
                        "last_mined": datetime.now(timezone.utc).isoformat(),
                    }
                )
            if artifact_batch:
                cypher = "\n                UNWIND $batch as props\n                MERGE (a:Artifact {path: props.path})\n                SET a += props\n                "
                ops.safe_query(cypher, params={"batch": artifact_batch})
        if result.memories:
            from falkordb_memory_server.memory_tools import MemoryManager

            manager = MemoryManager(ops=ops)
            category_to_type = {
                MemoryCategory.DECISION: "decision",
                MemoryCategory.PREFERENCE: "learning",
                MemoryCategory.MILESTONE: "task",
                MemoryCategory.PROBLEM: "problem",
                MemoryCategory.SOLUTION: "solution",
                MemoryCategory.EMOTIONAL: "learning",
                MemoryCategory.LEARNING: "learning",
                MemoryCategory.CONTEXT: "learning",
                MemoryCategory.CONVENTION: "convention",
                MemoryCategory.DEPENDENCY: "dependency",
                MemoryCategory.GENERAL: "learning",
            }
            stored_ids = []
            for memory in result.memories:
                mem_type = category_to_type.get(memory.category, "learning")
                props = {
                    "content": memory.content,
                    "category": memory.category.value,
                    "confidence": memory.confidence,
                    "keywords": memory.keywords,
                    "source_file": memory.source_file,
                    "extracted_at": datetime.now(timezone.utc).isoformat(),
                }
                res = manager.remember(
                    memory_type=mem_type, content=props, generate_embedding=False
                )
                if "node_id" in res:
                    stored_ids.append(res["node_id"])
                elif "id" in res:
                    stored_ids.append(res["id"])
            result_dict = result.model_dump()
            result_dict["stored_count"] = len(stored_ids)
            result_dict["stored_ids"] = stored_ids
            result_dict["files_checked"] = len(processed_states)
            return [TextContent(type="text", text=json.dumps(result_dict, indent=2, default=str))]
    result_dict = result.model_dump()
    result_dict["files_checked"] = len(processed_states)
    return [TextContent(type="text", text=json.dumps(result_dict, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_mine_conversations",
        description="Mine memories from conversation exports (Claude, ChatGPT, Slack).",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path to conversation export file or directory",
                },
                "source_type": {
                    "type": "string",
                    "description": "Format of the export: claude_json, claude_md, chatgpt_json, chatgpt_html, slack_json, slack_txt, auto",
                    "enum": [
                        "claude_json",
                        "claude_md",
                        "chatgpt_json",
                        "chatgpt_html",
                        "slack_json",
                        "slack_txt",
                        "auto",
                    ],
                    "default": "auto",
                },
                "extraction_mode": {
                    "type": "string",
                    "description": "Optional extraction mode: programming, office, life",
                    "enum": ["programming", "office", "life"],
                },
                "store": {
                    "type": "boolean",
                    "description": "Whether to store extracted memories in the graph",
                    "default": False,
                },
            },
            "required": ["path"],
        },
    )
)
def handle_mine_conversations(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_mine_conversations tool."""
    from falkordb_memory_server.conversation_miner import ConversationMiner

    path_str = args.get("path", "")
    source_type = args.get("source_type", "auto")
    store = args.get("store", False)
    extraction_mode = args.get("extraction_mode")
    target = Path(path_str).absolute()
    path_str = str(target)

    extractor = MemoryExtractor(mode=extraction_mode)
    miner = ConversationMiner(extractor=extractor)
    result = miner.mine_conversations(path_str, source_type=source_type, store=store)
    result_dict = {
        "total_chunks": result.total_chunks,
        "by_category": result.by_category,
        "memories": [
            {
                "content": m.content,
                "category": m.category.value,
                "confidence": m.confidence,
                "source_file": m.source_file,
                "keywords": m.keywords,
            }
            for m in result.memories
        ],
    }
    if store:
        result_dict["stored_count"] = result.metadata.get("stored_count", 0)
        result_dict["stored_ids"] = result.metadata.get("stored_ids", [])
    return [TextContent(type="text", text=json.dumps(result_dict, indent=2, ensure_ascii=False))]


@registry.register(
    Tool(
        name="memory_load_project_context",
        description="Auto-load project-specific context (conventions, configs) from common files like CLAUDE.md, GEMINI.md, .clauderc, etc. Zero API calls, uses rule-based patterns.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {
                    "type": "string",
                    "description": "Path to the project root directory",
                },
                "incremental": {
                    "type": "boolean",
                    "description": "Only reload files that have changed (recommended)",
                    "default": True,
                },
                "extraction_mode": {
                    "type": "string",
                    "description": "Optional extraction mode: programming, office, life",
                    "enum": ["programming", "office", "life"],
                },
            },
            "required": ["project_path"],
        },
    )
)
def handle_load_project_context(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_load_project_context tool."""
    import os

    project_path_str = args.get("project_path")
    incremental = args.get("incremental", True)
    if not project_path_str:
        return [TextContent(type="text", text="Error: project_path is required")]
    project_path = Path(project_path_str).absolute()
    if not project_path.exists() or not project_path.is_dir():
        return [
            TextContent(
                type="text", text=f"Error: Path not found or not a directory: {project_path_str}"
            )
        ]
    existing_states = {}
    path_str = str(project_path)
    prefix = path_str + os.sep
    cypher = "\n    MATCH (a:Artifact)\n    WHERE a.path = $path OR a.path STARTS WITH $prefix\n    RETURN a.path as path, a.mtime as mtime, a.hash as hash\n    "
    try:
        state_result = ops.safe_query(
            cypher, params={"path": path_str, "prefix": prefix}, read_only=True
        )
        for row in state_result.get("result_set", []):
            p, mtime, h = row
            existing_states[p] = {"mtime": mtime, "hash": h}
    except Exception as e:
        logger.warning(f"Could not fetch existing states: {e}")
    processed_states = {}

    def context_state_tracker(filepath: Path) -> bool:
        abs_path = str(filepath.absolute())
        try:
            stat = filepath.stat()
            mtime = stat.st_mtime
            state = existing_states.get(abs_path)
            if state:
                if state.get("mtime") == mtime:
                    processed_states[abs_path] = {"mtime": mtime, "hash": state.get("hash")}
                    return True if incremental else False
                f_hash = compute_file_hash(filepath)
                if state.get("hash") == f_hash:
                    processed_states[abs_path] = {"mtime": mtime, "hash": f_hash}
                    return True if incremental else False
                processed_states[abs_path] = {"mtime": mtime, "hash": f_hash}
                return False
            else:
                f_hash = compute_file_hash(filepath)
                processed_states[abs_path] = {"mtime": mtime, "hash": f_hash}
                return False
        except Exception as e:
            logger.warning(f"Error checking state for {abs_path}: {e}")
            return False

    all_memories = []
    total_chunks = 0
    by_category: dict[str, int] = {}
    extractor = MemoryExtractor()
    for filename in PROJECT_CONTEXT_FILES:
        filepath = project_path / filename
        if filepath.exists() and filepath.is_file():
            if context_state_tracker(filepath):
                continue
            result = mine_file(filepath, extractor)
            all_memories.extend(result.memories)
            total_chunks += result.total_chunks
            for cat, count in result.by_category.items():
                by_category[cat] = by_category.get(cat, 0) + count
    if processed_states:
        artifact_batch = []
        for p, s in processed_states.items():
            artifact_batch.append(
                {
                    "path": p,
                    "name": Path(p).name,
                    "type": "project_context",
                    "mtime": s["mtime"],
                    "hash": s["hash"],
                    "last_mined": datetime.now(timezone.utc).isoformat(),
                }
            )
        if artifact_batch:
            cypher = "\n            UNWIND $batch as props\n            MERGE (a:Artifact {path: props.path})\n            SET a += props\n            "
            ops.safe_query(cypher, params={"batch": artifact_batch})
    if all_memories:
        from falkordb_memory_server.memory_tools import MemoryManager

        manager = MemoryManager(ops=ops)
        category_to_type = {
            MemoryCategory.DECISION: "decision",
            MemoryCategory.PREFERENCE: "learning",
            MemoryCategory.MILESTONE: "task",
            MemoryCategory.PROBLEM: "problem",
            MemoryCategory.SOLUTION: "solution",
            MemoryCategory.EMOTIONAL: "learning",
            MemoryCategory.LEARNING: "learning",
            MemoryCategory.CONTEXT: "learning",
            MemoryCategory.CONVENTION: "convention",
            MemoryCategory.DEPENDENCY: "dependency",
            MemoryCategory.GENERAL: "learning",
        }
        stored_ids = []
        for memory in all_memories:
            mem_type = category_to_type.get(memory.category, "learning")
            props = {
                "content": memory.content,
                "category": memory.category.value,
                "confidence": memory.confidence,
                "keywords": memory.keywords,
                "source_file": memory.source_file,
                "context": project_path_str,
                "extracted_at": datetime.now(timezone.utc).isoformat(),
            }
            res = manager.remember(memory_type=mem_type, content=props, generate_embedding=False)
            if "node_id" in res:
                stored_ids.append(res["node_id"])
            elif "id" in res:
                stored_ids.append(res["id"])
        result_dict = {
            "status": "success",
            "message": f"Loaded project context. Stored {len(stored_ids)} memories from {len(artifact_batch)} files checked.",
            "stored_count": len(stored_ids),
            "files_checked": len(artifact_batch),
            "memories": [m.model_dump() for m in all_memories],
        }
        return [TextContent(type="text", text=json.dumps(result_dict, indent=2, default=str))]
    result_dict = {
        "status": "success",
        "message": f"No new project context found or all files are up to date. Checked {len(processed_states)} context files.",
        "stored_count": 0,
        "files_checked": len(processed_states),
        "memories": [],
    }
    return [TextContent(type="text", text=json.dumps(result_dict, indent=2, default=str))]
