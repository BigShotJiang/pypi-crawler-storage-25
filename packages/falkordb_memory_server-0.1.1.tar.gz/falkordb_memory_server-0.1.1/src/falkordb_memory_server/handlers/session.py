"""Handler module."""

import json
from datetime import datetime, timezone
from typing import Any

from mcp.types import TextContent, Tool

from falkordb_memory_server.graph_ops import GraphOperations
from falkordb_memory_server.handlers import registry


@registry.register(
    Tool(
        name="memory_start_session",
        description="Start a new agent session in memory for tracking work context.",
        inputSchema={
            "type": "object",
            "properties": {
                "agent_type": {
                    "type": "string",
                    "description": "Agent type: claude, codex, gemini",
                },
                "agent_id": {"type": "string", "description": "Agent instance identifier"},
                "project_path": {"type": "string", "description": "Working directory path"},
                "objective": {"type": "string", "description": "Session goal or objective"},
                "ttl": {"type": "integer", "description": "Session TTL in seconds"},
            },
            "required": ["agent_type", "agent_id"],
        },
    )
)
def handle_start_session(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_start_session tool."""
    import uuid

    session_id = str(uuid.uuid4())
    properties = {
        "id": session_id,
        "agent_type": args.get("agent_type"),
        "agent_id": args.get("agent_id"),
        "project_path": args.get("project_path"),
        "objective": args.get("objective"),
        "started_at": datetime.now(timezone.utc).isoformat(),
        "status": "active",
    }
    if args.get("ttl"):
        properties["ttl"] = args["ttl"]
    result = ops.create_node("Session", properties)
    result["session_id"] = session_id
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_end_session",
        description="End the current agent session.",
        inputSchema={
            "type": "object",
            "properties": {
                "session_id": {"type": "string", "description": "Session ID to end"},
                "status": {
                    "type": "string",
                    "description": "Session end status",
                    "enum": ["completed", "abandoned"],
                    "default": "completed",
                },
                "summary": {"type": "string", "description": "Session summary"},
            },
            "required": ["session_id"],
        },
    )
)
def handle_end_session(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_end_session tool."""
    session_id = args.get("session_id")
    status = args.get("status", "completed")
    summary = args.get("summary")
    params = {
        "session_id": session_id,
        "status": status,
        "ended_at": datetime.now(timezone.utc).isoformat(),
    }
    cypher = "MATCH (s:Session {id: $session_id}) SET s.status = $status, s.ended_at = $ended_at"
    if summary:
        cypher += ", s.summary = $summary"
        params["summary"] = summary
    cypher += " RETURN s"
    result = ops.query(cypher, params=params)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]
