"""Handler module."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from falkordb_memory_server.graph_ops import GraphOperations
from falkordb_memory_server.handlers import registry
from falkordb_memory_server.schema import (
    RecallRequest,
)
from falkordb_memory_server.semantic_tools import get_semantic_engine


@registry.register(
    Tool(
        name="memory_remember",
        description="Store a memory (learning, decision, code snippet, concept, problem, solution, pattern, or dependency) with automatic embedding generation and tiering (Endless Mode).",
        inputSchema={
            "type": "object",
            "properties": {
                "memory_type": {
                    "type": "string",
                    "description": "Type of memory to store",
                    "enum": [
                        "learning",
                        "decision",
                        "code",
                        "concept",
                        "task",
                        "problem",
                        "solution",
                        "pattern",
                        "dependency",
                    ],
                },
                "content": {
                    "type": "object",
                    "description": "Memory content (type-specific properties)",
                },
                "context": {
                    "type": "object",
                    "description": "Session/project context",
                    "default": {},
                },
                "ttl": {"type": "integer", "description": "Time-to-live in seconds (optional)"},
                "tier": {
                    "type": "integer",
                    "description": "Memory tier: 0=L0 (Active), 1=L1 (Session), 2=L2 (Project), 3=L3 (Global)",
                    "enum": [0, 1, 2, 3],
                    "default": 1,
                },
                "generate_embedding": {
                    "type": "boolean",
                    "description": "Generate semantic embedding for search",
                    "default": True,
                },
            },
            "required": ["memory_type", "content"],
        },
    )
)
def handle_remember(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_remember tool."""
    from falkordb_memory_server.memory_tools import MemoryManager

    manager = MemoryManager(ops=ops)
    memory_type = args.get("memory_type")
    content_dict = args.get("content", {})
    context_dict = args.get("context", {})
    ttl = args.get("ttl")
    tier = args.get("tier")
    generate_embedding = args.get("generate_embedding", True)
    result = manager.remember(
        memory_type=memory_type,
        content=content_dict,
        context=context_dict,
        ttl=ttl,
        tier=tier,
        generate_embedding=generate_embedding,
    )
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_recall",
        description="Search and retrieve memories from the graph. Supports semantic, text, and Cypher queries.",
        inputSchema={
            "type": "object",
            "properties": {
                "query_type": {
                    "type": "string",
                    "description": "Query type: semantic (vector), text (full-text), cypher, or traversal",
                    "enum": ["semantic", "text", "cypher", "traversal"],
                    "default": "semantic",
                },
                "query": {"type": "string", "description": "Search query or Cypher string"},
                "filters": {"type": "object", "description": "Property filters", "default": {}},
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of results",
                    "default": 10,
                    "minimum": 1,
                    "maximum": 1000,
                },
                "include_context": {
                    "type": "boolean",
                    "description": "Include related nodes",
                    "default": True,
                },
                "include_invalid": {
                    "type": "boolean",
                    "description": "Include facts marked as invalid (valid_to is set)",
                    "default": False,
                },
            },
            "required": ["query"],
        },
    )
)
def handle_recall(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_recall tool."""
    request = RecallRequest(**args)
    result = get_semantic_engine().recall(
        query=request.query,
        query_type=request.query_type,
        filters=request.filters,
        limit=request.limit,
        include_invalid=request.include_invalid,
    )
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_invalidate",
        description="Mark a memory as no longer valid (setting its valid_to timestamp).",
        inputSchema={
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": ["string", "integer"],
                    "description": "Unique memory ID (string) or node ID (integer)",
                },
                "invalidated_at": {
                    "type": "string",
                    "description": "Optional ISO timestamp for invalidation (default: now)",
                },
            },
            "required": ["memory_id"],
        },
    )
)
def handle_invalidate(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_invalidate tool."""
    from falkordb_memory_server.memory_tools import MemoryManager

    memory_id = args.get("memory_id")
    invalidated_at = args.get("invalidated_at")
    manager = MemoryManager(ops=ops)
    result = manager.invalidate_memory(memory_id, invalidated_at)
    return [TextContent(type="text", text=json.dumps({"success": result}, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_associate",
        description="Create a relationship between two memories to build knowledge connections.",
        inputSchema={
            "type": "object",
            "properties": {
                "from_ref": {
                    "type": "object",
                    "description": "Source node reference (id or query)",
                    "properties": {"id": {"type": "integer"}, "query": {"type": "string"}},
                },
                "relation": {"type": "string", "description": "Relationship type"},
                "to_ref": {
                    "type": "object",
                    "description": "Target node reference (id or query)",
                    "properties": {"id": {"type": "integer"}, "query": {"type": "string"}},
                },
                "properties": {"type": "object", "description": "Edge properties", "default": {}},
            },
            "required": ["from_ref", "relation", "to_ref"],
        },
    )
)
def handle_associate(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_associate tool."""
    from_ref = args.get("from_ref", {})
    to_ref = args.get("to_ref", {})
    relation = args.get("relation")
    properties = args.get("properties", {})
    from_id = from_ref.get("id")
    to_id = to_ref.get("id")
    if not from_id or not to_id:
        raise ValueError("Both from_id and to_id are required")
    result = ops.create_edge(from_id, relation, to_id, properties)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_forget",
        description="Remove memories from the graph. Supports TTL-based cleanup.",
        inputSchema={
            "type": "object",
            "properties": {
                "ref": {
                    "type": "object",
                    "description": "What to forget (id, query, or older_than)",
                    "properties": {
                        "id": {"type": "integer"},
                        "query": {"type": "string"},
                        "older_than_seconds": {"type": "integer"},
                    },
                },
                "cascade": {
                    "type": "boolean",
                    "description": "Remove connected nodes",
                    "default": False,
                },
            },
            "required": ["ref"],
        },
    )
)
def handle_forget(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_forget tool."""
    ref = args.get("ref", {})
    cascade = args.get("cascade", False)
    if "id" in ref:
        result = ops.delete_nodes([ref["id"]], cascade)
    elif "older_than_seconds" in ref:
        delete_clause = "DETACH DELETE n" if cascade else "DELETE n"
        cypher = f"\n        MATCH (n)\n        WHERE datetime(n.created_at) < datetime() - duration({{seconds: $seconds}})\n        {delete_clause}\n        "
        query_result = ops.query(cypher, params={"seconds": int(ref["older_than_seconds"])})
        stats = query_result.get("statistics", {})
        deleted_count = stats.get("nodes_deleted", 0)
        result = {"deleted_count": deleted_count}
    elif "query" in ref:
        delete_clause = "DETACH DELETE n" if cascade else "DELETE n"
        cypher = f"MATCH (n) WHERE {ref['query']} {delete_clause}"
        query_result = ops.query(cypher)
        stats = query_result.get("statistics", {})
        deleted_count = stats.get("nodes_deleted", 0)
        result = {"deleted_count": deleted_count}
    else:
        raise ValueError("Provide id, older_than_seconds, or query in ref")
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_get_decision_chain",
        description="Retrieve decision chains starting from a specific decision or showing all recent decision paths.",
        inputSchema={
            "type": "object",
            "properties": {
                "start_node_id": {
                    "type": "integer",
                    "description": "Starting decision node ID (optional)",
                },
                "max_depth": {
                    "type": "integer",
                    "description": "Maximum traversal depth",
                    "default": 5,
                    "minimum": 1,
                    "maximum": 10,
                },
                "include_invalid": {
                    "type": "boolean",
                    "description": "Include invalid decisions",
                    "default": False,
                },
            },
        },
    )
)
def handle_get_decision_chain(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_get_decision_chain tool."""
    from falkordb_memory_server.memory_tools import MemoryManager

    start_node_id = args.get("start_node_id")
    max_depth = args.get("max_depth", 5)
    manager = MemoryManager(ops=ops)
    result = manager.get_decision_chain(start_node_id, max_depth)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_get_bug_patterns",
        description="Retrieve bug patterns (problems and their solutions) from the memory graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "problem_id": {"type": "integer", "description": "Optional specific problem ID"},
                "category": {"type": "string", "description": "Optional category filter"},
                "include_invalid": {
                    "type": "boolean",
                    "description": "Include invalid problems/solutions",
                    "default": False,
                },
            },
        },
    )
)
def handle_get_bug_patterns(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_get_bug_patterns tool."""
    from falkordb_memory_server.memory_tools import MemoryManager

    problem_id = args.get("problem_id")
    category = args.get("category")
    manager = MemoryManager(ops=ops)
    result = manager.get_bug_patterns(problem_id, category)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_get_code_patterns",
        description="Retrieve code patterns (code snippets and the patterns they implement) from the memory graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "code_id": {"type": "integer", "description": "Optional specific code node ID"},
                "pattern_type": {"type": "string", "description": "Optional pattern type filter"},
                "include_invalid": {
                    "type": "boolean",
                    "description": "Include invalid code/patterns",
                    "default": False,
                },
            },
        },
    )
)
def handle_get_code_patterns(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_get_code_patterns tool."""
    from falkordb_memory_server.memory_tools import MemoryManager

    code_id = args.get("code_id")
    pattern_type = args.get("pattern_type")
    manager = MemoryManager(ops=ops)
    result = manager.get_code_patterns(code_id, pattern_type)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_get_conventions",
        description="Retrieve coding conventions (naming, style, docstring, etc.) from the memory graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "convention_type": {
                    "type": "string",
                    "description": "Optional convention type filter (naming, style, docstring, etc.)",
                },
                "project_path": {"type": "string", "description": "Optional project path filter"},
                "include_invalid": {
                    "type": "boolean",
                    "description": "Include invalid conventions",
                    "default": False,
                },
            },
        },
    )
)
def handle_get_conventions(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_get_conventions tool."""
    from falkordb_memory_server.memory_tools import MemoryManager

    convention_type = args.get("convention_type")
    project_path = args.get("project_path")
    manager = MemoryManager(ops=ops)
    result = manager.get_conventions(convention_type, project_path)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_get_refactors",
        description="Retrieve refactoring history and patterns from the memory graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "target": {
                    "type": "string",
                    "description": "Optional target filter (file or function name)",
                },
                "include_invalid": {
                    "type": "boolean",
                    "description": "Include invalid refactors",
                    "default": False,
                },
            },
        },
    )
)
def handle_get_refactors(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_get_refactors tool."""
    from falkordb_memory_server.memory_tools import MemoryManager

    target = args.get("target")
    include_invalid = args.get("include_invalid", False)
    manager = MemoryManager(ops=ops)
    result = manager.get_refactors(target, include_invalid)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_get_test_coverage",
        description="Retrieve test coverage and related code from the memory graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "target": {
                    "type": "string",
                    "description": "Optional target filter (file or function name)",
                },
                "include_invalid": {
                    "type": "boolean",
                    "description": "Include invalid tests",
                    "default": False,
                },
            },
        },
    )
)
def handle_get_test_coverage(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_get_test_coverage tool."""
    from falkordb_memory_server.memory_tools import MemoryManager

    target = args.get("target")
    include_invalid = args.get("include_invalid", False)
    manager = MemoryManager(ops=ops)
    result = manager.get_test_coverage(target, include_invalid)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_get_api_usage",
        description="Retrieve API usage history and examples from the memory graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "api_name": {"type": "string", "description": "Optional API name filter"},
                "include_invalid": {
                    "type": "boolean",
                    "description": "Include invalid usage",
                    "default": False,
                },
            },
        },
    )
)
def handle_get_api_usage(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_get_api_usage tool."""
    from falkordb_memory_server.memory_tools import MemoryManager

    api_name = args.get("api_name")
    include_invalid = args.get("include_invalid", False)
    manager = MemoryManager(ops=ops)
    result = manager.get_api_usage(api_name, include_invalid)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_get_reviews",
        description="Retrieve code review history and comments from the memory graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "target": {
                    "type": "string",
                    "description": "Optional target filter (file or function name)",
                },
                "include_invalid": {
                    "type": "boolean",
                    "description": "Include invalid reviews",
                    "default": False,
                },
            },
        },
    )
)
def handle_get_reviews(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_get_reviews tool."""
    from falkordb_memory_server.memory_tools import MemoryManager

    target = args.get("target")
    include_invalid = args.get("include_invalid", False)
    manager = MemoryManager(ops=ops)
    result = manager.get_reviews(target, include_invalid)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_wake_up",
        description="Load project-critical facts into context (Wake-up command). Retrieves active session, latest decisions, critical learnings, and active tasks.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {
                    "type": "string",
                    "description": "Optional filter by project working directory",
                },
                "limit": {
                    "type": "integer",
                    "description": "Number of items for each category (default 3)",
                    "default": 3,
                },
            },
        },
    )
)
def handle_wake_up(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_wake_up tool."""
    from falkordb_memory_server.memory_tools import get_memory_manager

    project_path = args.get("project_path")
    limit = args.get("limit", 3)
    manager = get_memory_manager()
    result = manager.wake_up(project_path, limit)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]
