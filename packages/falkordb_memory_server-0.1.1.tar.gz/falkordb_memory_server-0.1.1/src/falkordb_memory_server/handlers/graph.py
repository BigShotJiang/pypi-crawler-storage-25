"""Handler module."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from falkordb_memory_server.graph_ops import GraphOperations
from falkordb_memory_server.handlers import registry
from falkordb_memory_server.schema import (
    CreateEdgeRequest,
    CreateNodeRequest,
    DeleteRequest,
    QueryRequest,
)


@registry.register(
    Tool(
        name="memory_query",
        description="Execute a Cypher query against the agent memory graph. Use for advanced graph operations.",
        inputSchema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Cypher query string"},
                "params": {
                    "type": "object",
                    "description": "Query parameters (optional)",
                    "default": {},
                },
                "read_only": {
                    "type": "boolean",
                    "description": "Execute as read-only query",
                    "default": False,
                },
            },
            "required": ["query"],
        },
    )
)
def handle_query(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_query tool."""
    request = QueryRequest(**args)
    result = ops.query(request.query, request.params, request.read_only)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_create_node",
        description="Create a new node in the memory graph. Nodes can be Session, Agent, Decision, Learning, Code, Concept, Pattern, or Dependency.",
        inputSchema={
            "type": "object",
            "properties": {
                "label": {
                    "type": "string",
                    "description": "Node label: Session, Agent, Decision, Learning, Code, Concept, Project, Task, Artifact, Problem, Solution, Pattern, Dependency",
                    "enum": [
                        "Session",
                        "Agent",
                        "Decision",
                        "Learning",
                        "Code",
                        "Concept",
                        "Project",
                        "Task",
                        "Artifact",
                        "Problem",
                        "Solution",
                        "Pattern",
                        "Dependency",
                    ],
                },
                "properties": {
                    "type": "object",
                    "description": "Node properties as key-value pairs",
                    "default": {},
                },
                "return_node": {
                    "type": "boolean",
                    "description": "Return the created node details",
                    "default": True,
                },
            },
            "required": ["label"],
        },
    )
)
def handle_create_node(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_create_node tool."""
    request = CreateNodeRequest(**args)
    result = ops.create_node(request.label, request.properties, request.return_node)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_create_edge",
        description="Create a relationship between two nodes in the memory graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "from_id": {"type": "integer", "description": "Source node ID"},
                "relation": {
                    "type": "string",
                    "description": "Relationship type (e.g., STARTED_BY, LED_TO, KNOWS, RELATED_TO)",
                },
                "to_id": {"type": "integer", "description": "Target node ID"},
                "properties": {
                    "type": "object",
                    "description": "Edge properties (optional)",
                    "default": {},
                },
            },
            "required": ["from_id", "relation", "to_id"],
        },
    )
)
def handle_create_edge(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_create_edge tool."""
    request = CreateEdgeRequest(**args)
    result = ops.create_edge(request.from_id, request.relation, request.to_id, request.properties)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_delete",
        description="Delete nodes or relationships from the memory graph.",
        inputSchema={
            "type": "object",
            "properties": {
                "node_ids": {
                    "type": "array",
                    "items": {"type": "integer"},
                    "description": "List of node IDs to delete",
                },
                "cascade": {
                    "type": "boolean",
                    "description": "Also delete connected edges",
                    "default": False,
                },
            },
            "required": ["node_ids"],
        },
    )
)
def handle_delete(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_delete tool."""
    request = DeleteRequest(**args)
    result = ops.delete_nodes(request.node_ids, request.cascade)
    return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]
