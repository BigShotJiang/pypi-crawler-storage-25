"""Handler module."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from falkordb_memory_server.graph_ops import GraphOperations
from falkordb_memory_server.handlers import registry


@registry.register(
    Tool(
        name="memory_set_tier",
        description="Explicitly set the tier (L0-L3) of a memory node (Endless Mode).",
        inputSchema={
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": ["string", "integer"],
                    "description": "Unique memory ID (string) or node ID (integer)",
                },
                "tier": {
                    "type": "integer",
                    "description": "Memory tier: 0=L0 (Active), 1=L1 (Session), 2=L2 (Project), 3=L3 (Global)",
                    "enum": [0, 1, 2, 3],
                },
            },
            "required": ["memory_id", "tier"],
        },
    )
)
def handle_set_tier(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_set_tier tool."""
    from falkordb_memory_server.tier import get_tier_manager

    memory_id = args.get("memory_id")
    tier = args.get("tier")
    manager = get_tier_manager()
    result = manager.set_tier(memory_id, tier)
    return [TextContent(type="text", text=json.dumps({"success": result}, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_promote",
        description="Promote a memory to the next tier level (e.g., L1 -> L2).",
        inputSchema={
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": ["string", "integer"],
                    "description": "Unique memory ID (string) or node ID (integer)",
                }
            },
            "required": ["memory_id"],
        },
    )
)
def handle_promote(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_promote tool."""
    from falkordb_memory_server.tier import get_tier_manager

    memory_id = args.get("memory_id")
    manager = get_tier_manager()
    result = manager.promote(memory_id)
    return [TextContent(type="text", text=json.dumps({"success": result}, indent=2, default=str))]


@registry.register(
    Tool(
        name="memory_demote",
        description="Demote a memory to the previous tier level (e.g., L2 -> L1).",
        inputSchema={
            "type": "object",
            "properties": {
                "memory_id": {
                    "type": ["string", "integer"],
                    "description": "Unique memory ID (string) or node ID (integer)",
                }
            },
            "required": ["memory_id"],
        },
    )
)
def handle_demote(ops: GraphOperations, args: dict[str, Any]) -> list[TextContent]:
    """Handle memory_demote tool."""
    from falkordb_memory_server.tier import get_tier_manager

    memory_id = args.get("memory_id")
    manager = get_tier_manager()
    result = manager.demote(memory_id)
    return [TextContent(type="text", text=json.dumps({"success": result}, indent=2, default=str))]
