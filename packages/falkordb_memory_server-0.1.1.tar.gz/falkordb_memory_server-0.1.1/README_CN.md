<div align="center">

# FalkorDB Memory

### 面向软件开发的图原生记忆系统

<br>

*"为什么选 PostgreSQL？" "这个 Bug 见过吗？" "这个 API 怎么用？"*

每个开发者都熟悉这些问题。答案藏在过去对话中 —— 深埋在聊天记录里、丢失在会话间隙、散落在各种工具间。**FalkorDB Memory 为你的 AI Agent 提供持久大脑**，记住决策、追踪代码模式、跨项目连接知识。

**一个图数据库** —— FalkorDB 在单个 Redis 存储中融合向量搜索 + 图关系。无需分离的 ChromaDB + SQLite。无上下文碎片化。

**原生图查询** —— 用 Cypher 追溯决策链、发现问题模式、挖掘隐藏关联：`MATCH (d:Decision)-[:LED_TO]->(p:Problem) RETURN d.rationale, p.solution`

**零成本提取** —— 纯正则匹配，无 API 调用，96.6% 基准准确率。决策、Bug、学习、模式 —— 自动分类存储。

<br>

[![][python-shield]][python-link]
[![][license-shield]][license-link]
[![][falkordb-shield]][falkordb-link]

<br>

[快速开始](#快速开始) · [功能特性](#功能特性) · [为什么是图？](#为什么是图原生) · [MCP 工具](#mcp-工具) · [路线图](#路线图)

<br>

### 一个图数据库。零碎片化。原生关联。

<table>
<tr>
<td align="center"><strong>15+</strong><br><sub>MCP 工具</sub></td>
<td align="center"><strong>图+向量</strong><br><sub>一个数据库</sub></td>
<td align="center"><strong>¥0</strong><br><sub>提取成本</sub></td>
<td align="center"><strong>Cypher</strong><br><sub>原生查询</sub></td>
</tr>
</table>

**对比其他方案**

| 特性 | FalkorDB Memory | MemPalace | claude-mem |
|------|-----------------|-----------|------------|
| 存储 | **一个图数据库** | ChromaDB + SQLite | SQLite + ChromaDB |
| 图查询 | **原生 Cypher** | 模拟实现 | 无 |
| 向量搜索 | **内置** | ChromaDB | ChromaDB |
| 关系遍历 | **原生边** | 逻辑层 | 无 |

</div>

---

## 快速开始

```bash
# 安装依赖
pip install falkordb-memory-server

# 初始化配置向导（选择使用模式：Programming / Office / Life）
python -m falkordb_memory_server init

# 启动 FalkorDB（Docker）
docker run -d -p 6379:6379 falkordb/falkordb:latest

# 配置 Claude Code
claude mcp add falkordb-memory -- python -m falkordb_memory_server

# 配置 OpenClaw
curl -fsSL https://raw.githubusercontent.com/goodideal/falkordb-memory/main/scripts/install_openclaw.sh | bash

# 或配置 Gemini CLI
gemini extensions install https://github.com/goodideal/falkordb-memory
```

安装后，AI Agent 自动具备：
- **捕获记忆** —— 从对话和工具使用中自动提取
- **注入上下文** —— 会话开始时加载相关历史记忆
- **语义搜索** —— 跨所有存储知识进行语义检索

---

## 功能特性

### 🧠 记忆提取

自动将记忆分类到 7 个类别：

| 类别 | 描述 | 匹配模式示例 |
|------|------|-------------|
| `decision` | 决策、选择、权衡 | "我们决定...", "而不是" |
| `preference` | 偏好、风格、约定 | "我总是使用...", "从不" |
| `milestone` | 里程碑、突破、成就 | "成功了!", "修复了", "解决了" |
| `problem` | 问题、Bug、故障 | "错误", "崩溃", "Bug" |
| `learning` | 学习、洞察、经验 | "学到", "发现", "技巧" |
| `emotional` | 情感、感受 | "喜欢", "自豪", "沮丧" |
| `general` | 通用默认分类 | - |

**提取模式 (Extraction Modes)**
根据您的使用场景优化提取规则：
- **Programming (默认)**: 专为软件架构、代码片段与技术决策优化。
- **Office (办公)**: 专为会议纪要、日程安排与日常任务优化。自动对手机号、身份证号、银行卡号等 PII 信息进行脱敏拦截。
- **Life (生活)**: 专为个人提醒、家庭待办与财务记录优化。

**零 API 调用** —— 纯正则模式匹配，在 LongMemEval 基准测试中达到 96.6% 准确率（MemPalace 基准）。

### 🔗 图存储

记忆是节点。关系是边。发现关联：

```cypher
// 查找所有导致问题的决策
MATCH (d:Decision)-[:LED_TO]->(p:Problem)
RETURN d.rationale, p.solution

// 查找相关学习
MATCH (l:Learning)-[:DERIVED_FROM]->(c:Code)
WHERE l.category = 'security'
RETURN l, c
```

### 🔍 语义搜索

基于 sentence-transformers 的向量相似度搜索：

```python
# 查找相似记忆
results = memory_semantic_search(
    query="认证最佳实践",
    k=10,
    min_score=0.7
)
```

### 💡 主动洞察推送 (Proactive Insights)

**从被动检索到主动上下文流式推送** —— 系统会拦截工具调用或用户提示，并主动将相关的历史架构决策推送到 Agent 的上下文中。

- **回合驱动注入**: 在每次对话周期的起点检索与当前文件或主题相关的规范。
- **异步状态渲染**: 自动更新本地工作区文件 (`.omg/state/active-architecture.md`)，在不阻塞执行的情况下对齐 Agent 的系统提示词。
- **零上下文污染**: 通过严格的 1 小时会话级去重和基于置信度的截断，保护 Token 限制。

### 🛡️ 隐私与安全防线

**内建 PII 与密钥脱敏 (`PIIRedactor`)** 确保敏感数据永远不会泄露到图数据库中。

- **自动化密钥过滤**: 检测并使用 `[REDACTED_SECRET]` 替换 AWS Keys、JWT 令牌、私钥和密码。
- **PII 擦除**: 自动移除电子邮件地址和公网 IP 地址。
- **开发者友好的白名单**: 安全忽略常见的测试密码（如 `test`, `dummy`）和标准的局域网 IP (`127.0.0.1`, `192.168.x.x`)，防止阻碍合法的本地开发。

### 🪝 跨 Agent 钩子

| Agent | Hook 事件 | 配置文件 |
|-------|----------|---------|
| Claude Code | `PreToolUse`, `PostToolUse` | `~/.claude/settings.json` |
| Gemini CLI | `BeforeTool`, `AfterTool`, `SessionStart` | `gemini-extension.json` |

统一事件映射：

```
Claude Code          Gemini CLI           统一事件
───────────────────────────────────────────────────
PreToolUse      →   BeforeTool      →   before_tool
PostToolUse     →   AfterTool       →   after_tool
-               →   SessionStart    →   session_start
```

---

## 安装配置

### 前置要求

1. **FalkorDB**（基于 Redis 的图数据库）：
   ```bash
   docker run -d -p 6379:6379 --name falkordb falkordb/falkordb:latest
   ```

2. **Python 3.10+**

### 方式 1：从 PyPI 安装

```bash
pip install falkordb-memory-server
```

### 方式 2：从源码安装（开发模式）

```bash
git clone https://github.com/goodideal/falkordb-memory.git
cd falkordb-memory
pip install -e .
```

### 配置 Claude Code

```bash
# 添加 MCP 服务器
claude mcp add falkordb-memory -e FALKORDB_URL=redis://localhost:6379 -- python -m falkordb_memory_server

# 验证连接
claude mcp list
```

### 可选：启用钩子自动捕获

在 `~/.claude/settings.json` 添加钩子实现自动记忆捕获：

```json
{
  "hooks": {
    "SessionStart": [{
      "matcher": ".*",
      "hooks": [{
        "type": "command",
        "command": "python /path/to/hooks/claude-code-hook.py"
      }]
    }],
    "PostToolUse": [{
      "matcher": ".*",
      "hooks": [{
        "type": "command",
        "command": "python /path/to/hooks/claude-code-hook.py"
      }]
    }]
  }
}
```

### Gemini CLI 配置

```bash
# 安装扩展
gemini extensions install https://github.com/goodideal/falkordb-memory

# 或本地开发链接
gemini extensions link ./gemini-extension
```

---

## MCP 工具

### 记忆操作

| 工具 | 描述 |
|------|------|
| `memory_remember` | 存储新记忆 |
| `memory_recall` | 搜索和检索记忆 |
| `memory_associate` | 创建记忆间的关系 |
| `memory_forget` | 删除记忆（支持 TTL） |

### 提取工具

| 工具 | 描述 |
|------|------|
| `memory_extract` | 从文本提取记忆 |
| `memory_mine` | 批量从文件/目录挖掘记忆 |

### 搜索工具

| 工具 | 描述 |
|------|------|
| `memory_semantic_search` | 向量相似度搜索 |
| `memory_query` | 执行原生 Cypher 查询 |

### 会话管理

| 工具 | 描述 |
|------|------|
| `memory_start_session` | 开始新的 Agent 会话 |
| `memory_end_session` | 结束当前会话 |

### 维护工具

| 工具 | 描述 |
|------|------|
| `memory_stats` | 查看记忆统计 |
| `memory_cleanup` | 清理过期记忆 |

---

## 使用示例

### 存储记忆

```
"记住我们决定使用 PostgreSQL 作为数据库，因为它处理 JSON 更好"
```

**注意：** 直接使用 `memory_remember` 工具时，`content` 和 `context` 必须是 **字典**，而非字符串：

```json
{
  "memory_type": "decision",
  "content": {
    "title": "数据库选择",
    "description": "我们选择了 PostgreSQL",
    "rationale": "更好的 JSON 支持"
  },
  "context": {
    "project": "my-project"
  }
}
```

### 回忆记忆

```
"你记得关于认证的什么内容？"
"找出我们关于 API 的决策"
```

### 从文件提取

```
"从 docs 目录挖掘重要决策"
"从这次对话中提取学习"
```

### 图查询

```
"显示我们解决过的所有问题"
"哪些决策导致了这个架构？"
```

---

## 架构设计

```
┌─────────────────────────────────────────────────────────────┐
│                     Agent 层                                 │
│   Claude Code │ Gemini CLI │ Codex │ 自定义 Agent            │
└─────────────────────┬───────────────────────────────────────┘
                      │ MCP 协议 / Hooks
                      ▼
┌─────────────────────────────────────────────────────────────┐
│              FalkorDB Memory MCP 服务器                      │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────────────┐│
│  │图操作工具   │ │记忆工具     │ │ 提取工具                ││
│  │- query      │ │- remember   │ │- memory_extract         ││
│  │- create     │ │- recall     │ │- memory_mine            ││
│  │- delete     │ │- associate  │ │                         ││
│  └─────────────┘ └─────────────┘ └─────────────────────────┘│
└─────────────────────┬───────────────────────────────────────┘
                      │ falkordb-py SDK
                      ▼
┌─────────────────────────────────────────────────────────────┐
│                    FalkorDB (Redis)                          │
│  节点: Session, Agent, Decision, Learning, Code, Concept    │
│  边: STARTED_BY, LED_TO, KNOWS, RELATED_TO                 │
│  索引: 向量索引（语义）, 全文索引（搜索）                    │
└─────────────────────────────────────────────────────────────┘
```

---

## 配置说明

### 环境变量

```bash
FALKORDB_URL=redis://localhost:6379
GRAPH_NAME=agent_memory
EMBEDDING_MODEL=all-MiniLM-L6-v2
DEFAULT_TTL=604800  # 7 天
```

### 嵌入模型

本地嵌入模型基于 sentence-transformers —— **无需 API key**。

| 模型 | 维度 | 大小 | 速度 | 准确率 |
|------|------|------|------|--------|
| `all-MiniLM-L6-v2` | 384 | ~90MB | 快 | 良好 |
| `all-mpnet-base-v2` | 768 | ~420MB | 较慢 | 更好 |

**工作原理：**
- 模型在首次使用时**自动下载**到 `~/.cache/torch/sentence_transformers/`
- 下载后**完全离线可用** —— 无 API 调用，无需网络
- 记忆提取零成本 —— 纯正则模式匹配自动分类
- 语义搜索使用本地嵌入向量进行相似度计算

**安装依赖：**
```bash
pip install sentence-transformers torch
```

**切换模型：**
```bash
# 使用更高精度模型
export EMBEDDING_MODEL=all-mpnet-base-v2
export EMBEDDING_DIMENSION=768
```

---

## 路线图

### v1.0（基础版本）

- ✅ MCP 服务器与图操作
- ✅ FalkorDB 集成（Redis 图数据库）
- ✅ 基础记忆工具：remember、recall、forget
- ✅ 节点标签：Session、Agent、Decision、Learning、Code、Concept
- ✅ 关系类型：STARTED_BY、LED_TO、DERIVED_FROM、KNOWS

### v1.1（当前版本）

- ✅ 基于规则模式的记忆提取
- ✅ Claude Code 和 Gemini CLI 钩子
- ✅ 本地嵌入的语义搜索
- ✅ 批量文件/目录挖掘

### v1.2（开发者核心）

*解决日常开发痛点*

- 🔲 Decision Chain Query — 追溯架构决策链（`"为什么用 PostgreSQL？"`）
- 🔲 Bug Pattern Registry — 记住踩过的坑（`"这个错误见过吗？"`）
- 🔲 Code Pattern Memory — API 用法和模式（`"React hooks 最佳实践"`）
- 🔲 Privacy Control — `<private>` 标签排除敏感内容
- 🔲 Wake-up Command — 加载项目关键事实到上下文
- 🔲 **增量挖掘** — 追踪文件变化（hash/mtime），跳过未修改文件，避免重复存储

### v1.3（项目知识）

*项目级上下文管理*

- 🔲 Project Context Auto-Load — 约定、配置、依赖自动加载
- 🔲 Dependency Decision Memory — 记住为什么选 X 而不是 Y
- 🔲 Convention Registry — 编码规范、命名模式
- 🔲 Knowledge Graph — 时序实体关系图（Cypher 查询）

### v1.4（开发工作流）

*融入开发流程*

- 🔲 Refactor Trail — 追踪重构原因和影响范围
- 🔲 Test Memory — 测试策略、边界条件、覆盖决策
- 🔲 API Usage Memory — 第三方 API 使用经验
- 🔲 Code Review Memory — Review 反馈和改进记录

### v1.5（增强体验）

- 🔲 Web Viewer UI — 图可视化（`localhost:37777`）
- 🔲 Endless Mode — 仿生记忆架构，支持超长会话（L0-L3 栈）
- 🔲 Progressive Disclosure — 3 层搜索流程
- 🔲 Conversation Mining — 多格式支持（Claude、ChatGPT、Slack）

### v2.0（企业级）

- 🔲 AAAK Dialect — 大规模重复实体压缩
- 🔲 Advanced Graph Analytics — 影响力分析、模式检测、社区发现
- 🔲 Multi-tenant Support — 团队/项目隔离记忆
- 🔲 Team Memory Sharing — 跨团队知识同步

---

## 常见问题

### 首次运行：模型下载

首次使用时，嵌入模型会自动下载：

```
INFO:falkordb_memory_server.server:Loading embedding model: all-MiniLM-L6-v2
```

这是**一次性下载**（约 90MB）。之后完全离线可用。

### Cypher 语法注意事项

FalkorDB 使用 OpenCypher，存在一些差异：

```cypher
# ❌ 不支持 - datetime() 函数
CREATE (n:Decision {created_at: datetime()})

# ✅ 正确 - 从 Python 传入时间戳
CREATE (n:Decision {created_at: "2024-01-15T10:30:00"})
```

### MCP 服务器连接问题

1. 确认 FalkorDB 正在运行：
   ```bash
   docker ps | grep falkordb
   ```

2. 检查 MCP 服务器状态：
   ```bash
   claude mcp list
   ```

3. 重启 MCP 服务器：
   ```bash
   claude mcp remove falkordb-memory
   claude mcp add falkordb-memory -e FALKORDB_URL=redis://localhost:6379 -- python -m falkordb_memory_server
   ```

### 导入错误

如果出现 `ModuleNotFoundError`：

```bash
# 以开发模式安装
pip install -e .
```

---

## 参考资料

本项目借鉴了以下项目的优秀设计：

- **[MemPalace](https://github.com/mempathy-labs/mempalace)** —— 规则模式提取、96.6% LongMemEval 基准测试
- **[Claude-Mem](https://github.com/thedotmack/claude-mem)** —— Hook 生命周期设计、MCP 集成模式

---

## 许可证

MIT License - 详见 [LICENSE](LICENSE)

[python-shield]: https://img.shields.io/badge/Python-3.10%2B-blue
[python-link]: https://python.org
[license-shield]: https://img.shields.io/badge/License-MIT-green
[license-link]: LICENSE
[falkordb-shield]: https://img.shields.io/badge/FalkorDB-4.0%2B-red
[falkordb-link]: https://falkordb.com