from falkordb_memory_server.semantic_tools import get_semantic_engine

engine = get_semantic_engine()
try:
    print(engine.ensure_vector_indexes())
except Exception as e:
    print(f"Error: {e}")
