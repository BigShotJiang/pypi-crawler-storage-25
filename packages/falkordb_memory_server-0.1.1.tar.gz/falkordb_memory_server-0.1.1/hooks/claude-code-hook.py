#!/usr/bin/env python3
"""
Claude Code Hook for FalkorDB Memory.

This hook integrates with Claude Code to capture memories from tool usage
and inject relevant context at session start.

Installation:
  Add to ~/.claude/settings.json:

  {
    "hooks": {
      "SessionStart": [
        {
          "matcher": ".*",
          "hooks": [
            {
              "type": "command",
              "command": "python /path/to/falkordb-memory/hooks/claude-code-hook.py"
            }
          ]
        }
      ],
      "PostToolUse": [
        {
          "matcher": ".*",
          "hooks": [
            {
              "type": "command",
              "command": "python /path/to/falkordb-memory/hooks/claude-code-hook.py"
            }
          ]
        }
      ]
    }
  }
"""

import json
import sys
from pathlib import Path

# Add src to path for imports
script_dir = Path(__file__).parent
src_dir = script_dir.parent / "src"
sys.path.insert(0, str(src_dir))

from falkordb_memory_server.hook_adapter import (  # noqa: E402
    HookAdapter,
    HookSource,
    MemoryHookHandler,
)


def main():
    """Main hook entry point."""
    # Read input from stdin
    try:
        raw_input = json.load(sys.stdin)
    except json.JSONDecodeError as e:
        error_msg = f"Invalid JSON input: {e}"
        print(error_msg, file=sys.stderr)
        # Exit 2 = blocking error (stderr shown to user)
        sys.exit(2)

    # Create adapter for Claude Code
    adapter = HookAdapter(source_cli=HookSource.CLAUDE)
    handler = MemoryHookHandler()

    # Normalize and process
    try:
        unified_input = adapter.normalize_input(raw_input)
        result = handler.handle(unified_input)
        output = adapter.normalize_output(result)

        # Output JSON to stdout
        print(json.dumps(output))
        sys.exit(0)

    except Exception as e:
        # Log error to stderr, allow operation to proceed
        print(f"Hook error: {e}", file=sys.stderr)
        # Exit 0 = success, but with warning
        print(json.dumps({"decision": "approve"}))
        sys.exit(0)


if __name__ == "__main__":
    main()
