import asyncio
import statistics
import time

from falkordb_memory_server.graph_ops import get_graph_ops


async def benchmark():
    ops = get_graph_ops()

    # Ensure clean state or at least known state
    try:
        ops.query("MATCH (n:Benchmark) DETACH DELETE n")
    except Exception:
        pass

    # Create vector index if not exists
    ops.create_vector_index("Benchmark", "embedding", 384)

    latencies = []

    print("Benchmarking create_node...")
    for i in range(100):
        start = time.perf_counter()
        ops.create_node(
            "Benchmark", {"id": i, "content": f"test content {i}", "embedding": [0.1] * 384}
        )
        end = time.perf_counter()
        latencies.append((end - start) * 1000)

    print_stats("create_node", latencies)

    print("\nBenchmarking query (read-only)...")
    latencies = []
    for i in range(100):
        start = time.perf_counter()
        ops.query(f"MATCH (n:Benchmark {{id: {i}}}) RETURN n", read_only=True)
        end = time.perf_counter()
        latencies.append((end - start) * 1000)

    print_stats("query_read", latencies)

    print("\nBenchmarking semantic_search...")
    latencies = []
    query_vector = [0.1] * 384
    for i in range(100):
        start = time.perf_counter()
        ops.semantic_search(query_vector, label="Benchmark", k=5)
        end = time.perf_counter()
        latencies.append((end - start) * 1000)

    print("\nBenchmarking create_nodes_batch...")
    latencies = []
    batch_size = 50
    for i in range(10):
        batch = [
            {"id": i * batch_size + j, "content": f"batch content {j}"} for j in range(batch_size)
        ]
        start = time.perf_counter()
        ops.create_nodes_batch("Benchmark", batch)
        end = time.perf_counter()
        latencies.append((end - start) * 1000)

    print_stats("create_nodes_batch", latencies)
    print(f"Total nodes created: {10 * batch_size}")


def print_stats(name, latencies):
    avg = statistics.mean(latencies)
    p50 = statistics.median(latencies)
    p95 = sorted(latencies)[int(len(latencies) * 0.95)]
    p99 = sorted(latencies)[int(len(latencies) * 0.99)]
    print(f"{name}: Avg={avg:.2f}ms, P50={p50:.2f}ms, P95={p95:.2f}ms, P99={p99:.2f}ms")


if __name__ == "__main__":
    asyncio.run(benchmark())
