"""
synthesis_agent.py — Post-run project-wide analysis agent.

After all per-file Workers complete, the SynthesisAgent pulls every stored
analysis from ChromaDB, sends them in a single "principal architect" prompt,
and produces a comprehensive project intelligence report covering:

  • project_narrative         — what the project is, why it exists, how it works
  • architecture_overview     — layer/module breakdown, data flow, boundaries
  • algorithm_catalog         — every significant algorithm found, with complexity
  • critical_paths            — files whose failure breaks the system
  • tech_debt_hotspots        — concrete issues with severity + file reference
  • improvement_roadmap       — ordered action list with impact estimates
  • security_surface          — cross-file security risks
  • integration_guide         — how to add new features / hook into the system
  • algorithm_recommendations — new algorithms that would improve the project
  • dependency_clusters       — logical module groupings

Output is saved to {output_root}/synthesis.json.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Synthesis Agent
# ---------------------------------------------------------------------------

class SynthesisAgent:
    """Generates a project-wide intelligence report using all file analyses."""

    def __init__(
        self,
        output_root: Path,
        api_key: str,
        model_name: str = "gemma-4-31b-it",
        chroma_store=None,
    ) -> None:
        self.output_root = output_root
        self.api_key = api_key
        self.model_name = model_name
        self.chroma_store = chroma_store

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def run(self, all_results: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """
        Collect all analysis summaries, call Gemini once, and save synthesis.json.

        Returns the synthesis dict on success, None on failure.
        """
        summaries = self._collect_summaries(all_results)
        if not summaries:
            logger.warning("SynthesisAgent: no summaries to synthesise.")
            return None

        logger.info(f"SynthesisAgent: synthesising {len(summaries)} file analyses…")

        prompt = self._build_prompt(summaries)
        raw    = self._call_gemini(prompt)
        if not raw:
            return None

        synthesis = self._parse_response(raw)
        if synthesis:
            out_path = self.output_root / "synthesis.json"
            out_path.write_text(json.dumps(synthesis, indent=2, ensure_ascii=False), encoding="utf-8")
            logger.info(f"SynthesisAgent: saved → {out_path}")

        return synthesis

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _collect_summaries(self, all_results: List[Dict[str, Any]]) -> List[str]:
        """
        Build compact text summaries from raw Worker results.

        ChromaDB is used for per-file RAG during analysis but NOT queried here —
        the raw Worker results already contain everything needed and are guaranteed
        to be dicts, avoiding any schema mismatch.
        """
        summaries: List[str] = []
        for res in all_results:
            if not isinstance(res, dict):
                continue
            if res.get("error"):
                continue

            sec   = res.get("html_sections", {}) or {}
            ov    = sec.get("file_overview", {}) or {}
            algos = sec.get("algorithms", []) or []
            funcs = [
                f.get("signature", "") for f in (sec.get("function_breakdown") or [])
                if isinstance(f, dict)
            ]
            patterns = sec.get("notable_patterns", []) or []
            risks    = sec.get("risks_and_warnings", []) or []

            algo_text = ""
            if algos:
                algo_parts = []
                for a in algos:
                    if isinstance(a, dict):
                        algo_parts.append(
                            f"{a.get('name', '?')} [{a.get('time_complexity', '?')}]"
                        )
                if algo_parts:
                    algo_text = "  Algorithms: " + ", ".join(algo_parts)

            risk_sevs = [
                r.get("severity", "?") for r in risks[:3] if isinstance(r, dict)
            ]

            summary = (
                f"FILE: {res.get('relative_path', '?')}\n"
                f"  Language : {res.get('language', '?')}\n"
                f"  Purpose  : {ov.get('purpose', '?')}\n"
                f"  Lines    : {ov.get('size_lines', '?')}\n"
                f"  Functions: {', '.join(funcs[:6])}\n"
                f"{algo_text}\n"
                f"  Patterns : {', '.join(str(p) for p in patterns[:4])}\n"
                f"  Risks    : {len(risks)} ({', '.join(risk_sevs)})\n"
                f"  Role     : {str(sec.get('system_role', ''))[:200]}"
            )
            summaries.append(summary)

        return summaries

    def _build_prompt(self, summaries: List[str]) -> str:
        # Coerce every item to str — guards against any future type leakage
        safe = [s if isinstance(s, str) else json.dumps(s, ensure_ascii=False) for s in summaries[:200]]
        combined = "\n\n---\n\n".join(safe)

        return f"""You are a PRINCIPAL SOFTWARE ARCHITECT performing a full technical audit of a codebase.

Below are AI-generated analysis summaries for every file in the project.
Your task is to synthesise them into a **comprehensive, expert-level intelligence report**.

FILE ANALYSES:
{combined}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
REQUIRED OUTPUT — reply with ONLY valid JSON matching this EXACT schema:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{{
  "summary_one_liner": "One punchy sentence describing the project.",

  "project_narrative": "3–5 paragraph detailed explanation: what the project does, why it was built, the architectural philosophy, how the major components interact, and what engineering problem it solves. This should read like a well-written technical blog post intro.",

  "language_stack": ["Python", "JavaScript"],

  "architecture_overview": "2–3 paragraph description of the system architecture: layers, data flow, entry points, module boundaries, key abstractions.",

  "algorithm_catalog": [
    {{
      "name": "Algorithm name (e.g. BFS, Trie lookup, Round-robin, SHA-256 hashing)",
      "category": "one of: graph, sorting, search, hashing, scheduling, ML, string, compression, concurrency, other",
      "file": "path/to/file.py",
      "function": "function_name_where_it_lives",
      "description": "Detailed explanation of how this algorithm works in this specific context.",
      "purpose": "Why this algorithm was chosen for this task.",
      "time_complexity": "O(N log N)",
      "space_complexity": "O(N)",
      "why_chosen": "Why this is better than the alternatives for this use case.",
      "alternatives_considered": ["Alternative A — reason rejected", "Alternative B — reason rejected"]
    }}
  ],

  "critical_paths": [
    {{"path": "relative/path.py", "reason": "Why failure here breaks the system."}}
  ],

  "tech_debt_hotspots": [
    {{"file": "relative/path.py", "issue": "Specific technical debt issue.", "severity": "high|medium|low", "effort": "hours|days|weeks"}}
  ],

  "improvement_roadmap": [
    {{
      "priority": 1,
      "action": "Concrete improvement action.",
      "impact": "What this unlocks or fixes.",
      "files_affected": ["file1.py", "file2.py"],
      "effort": "1–2 days"
    }}
  ],

  "security_surface": [
    {{"risk": "Specific security concern.", "severity": "high|medium|low", "files": ["file.py"]}}
  ],

  "integration_guide": {{
    "overview": "2–3 sentences on how the system is designed for extension.",
    "steps_to_add_new_feature": [
      "Step 1: ...",
      "Step 2: ...",
      "Step 3: ..."
    ],
    "extension_points": [
      {{"name": "ClassName or interface", "file": "path.py", "how": "Subclass / implement / register to add new behaviour."}}
    ],
    "key_abstractions": [
      {{"name": "AbstractName", "file": "path.py", "purpose": "What it provides."}}
    ]
  }},

  "algorithm_recommendations": [
    {{
      "name": "Recommended algorithm (e.g. Bloom filter for deduplication)",
      "problem_it_solves": "Current limitation or bottleneck it addresses.",
      "implementation_hint": "Concrete advice on how and where to add it.",
      "files_to_modify": ["file.py"],
      "expected_improvement": "e.g. 10× faster lookup, 50% memory reduction",
      "priority": "high|medium|low"
    }}
  ],

  "dependency_clusters": [
    {{"name": "Cluster name (e.g. API Layer)", "files": ["file1.py", "file2.py"], "purpose": "What this cluster does."}}
  ]
}}

RULES:
- Output ONLY the JSON object. No markdown fences, no preamble, no commentary.
- Be highly specific — cite actual file names, function names, and algorithm names from the analyses.
- algorithm_catalog must include EVERY significant algorithm found, not just obvious ones.
- integration_guide must give genuinely actionable, file-specific guidance.
- algorithm_recommendations must be realistic and specific to THIS codebase's needs.
"""

    def _call_gemini(self, prompt: str) -> Optional[str]:
        url = (
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{self.model_name}:generateContent?key={self.api_key}"
        )
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "system_instruction": {
                "parts": [{"text": (
                    "You are a principal software architect. "
                    "You MUST respond with a single valid JSON object and nothing else. "
                    "No prose, no markdown fences, no commentary — only JSON."
                )}]
            },
            "generationConfig": {
                "temperature": 0.1,
                "maxOutputTokens": 8192,
                "response_mime_type": "application/json",
            },
        }
        try:
            resp = requests.post(url, json=payload, timeout=180)
            resp.raise_for_status()
            data = resp.json()
            return data["candidates"][0]["content"]["parts"][0]["text"]
        except Exception as exc:
            logger.error(f"SynthesisAgent Gemini call failed: {exc}")
            return None


    def _parse_response(self, raw: str) -> Optional[Dict[str, Any]]:
        """Robustly extract JSON — same raw_decode strategy as worker.py."""
        text = raw.strip()

        # Strip markdown fences
        if text.startswith("```"):
            lines = text.splitlines()
            inner = []
            for i, line in enumerate(lines):
                if i == 0:
                    continue
                if line.strip() == "```":
                    break
                inner.append(line)
            text = "\n".join(inner).strip()

        start = text.find("{")
        if start == -1:
            logger.error("SynthesisAgent: no JSON object found in response.")
            return None

        decoder = json.JSONDecoder()
        try:
            obj, _ = decoder.raw_decode(text, start)
            return obj
        except json.JSONDecodeError as exc:
            logger.error(f"SynthesisAgent JSON parse error: {exc}")
            logger.debug(f"Raw (first 500): {raw[:500]}")
            return None
