"""
cli.py — CLI entry point for CodeReportAI.

Usage:
    codereportai                        # scan current directory
    codereportai --path ./my-project    # scan specific folder
    codereportai --resume               # skip already-processed files
    codereportai --workers 4            # parallel workers
    codereportai --no-chroma            # disable ChromaDB

    # Inline query shortcut (no 'query' subcommand needed):
    codereportai "which algorithm is used for traversal?"
    codereportai "how should I add caching?" --path ./my-project

    # Explicit query subcommand:
    codereportai query "what patterns are used?" --top 8
"""

from __future__ import annotations

import os
import sys

# Fix Windows cp1252 terminal encoding — must happen before Rich initialises.
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
    except Exception:
        pass

from pathlib import Path

import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.markdown import Markdown

app = typer.Typer(
    name="codereportai",
    help="[CodeReportAI] Recursively analyse any codebase and generate AI-powered HTML reports.",
    add_completion=False,
)

console = Console()
OUTPUT_DIRNAME = "CodeReportAi"


# ---------------------------------------------------------------------------
# API key loading (shared)
# ---------------------------------------------------------------------------

def _load_api_keys() -> list[str]:
    """
    Load Gemini API keys.

    Priority:
      1. GEMINI_API_KEY_* variables from .env / environment (user overrides)
      2. Built-in hardcoded keys (used automatically if no .env is present)
    """
    _BUILTIN_KEYS: list[str] = [
        "AIzaSyDCyXcLQm_JK_QoUKeIqC4bwyvzBfEt6ss",
        "AIzaSyDHO_VLFm-tYjRqc9E3vDVA8BZoWxuNCaQ",
        "AIzaSyCJH6Ynd8X3fYAC5A3KHsGmUeY5wbbri9s",
    ]

    keys: list[str] = []
    i = 1
    while True:
        key = os.environ.get(f"GEMINI_API_KEY_{i}")
        if not key:
            break
        keys.append(key.strip())
        i += 1
    bare = os.environ.get("GEMINI_API_KEY")
    if bare and bare.strip() not in keys:
        keys.append(bare.strip())

    for k in _BUILTIN_KEYS:
        if k not in keys:
            keys.append(k)

    return [k for k in keys if k]


def _load_env_and_keys(root: Path, env_file: Path) -> list[str]:
    """Load .env and return API keys."""
    env_path = env_file if env_file.is_absolute() else (root / env_file)
    if env_path.exists():
        load_dotenv(dotenv_path=env_path)
        console.print(f"[dim]Loaded .env from {env_path}[/dim]")
    else:
        load_dotenv()
    return _load_api_keys()


# ---------------------------------------------------------------------------
# Main analyse command (default — runs when no subcommand is given)
# ---------------------------------------------------------------------------

@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    question: str = typer.Argument(
        None,
        help="Ask a question about the codebase (shortcut for `codereportai query`). "
             'Example: codereportai "which algorithm handles traversal?"',
    ),
    path: Path = typer.Option(
        None,
        "--path", "-p",
        help="Root directory to scan or query against (default: current working directory).",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
    ),
    resume: bool = typer.Option(
        False,
        "--resume/--no-resume",
        help="Skip files already present in context.json.",
    ),
    workers: int = typer.Option(
        1,
        "--workers", "-w",
        min=1, max=16,
        help="Number of parallel worker threads (1-16).",
    ),
    model: str = typer.Option(
        "gemma-4-31b-it",
        "--model", "-m",
        help="Gemini model to use.",
    ),
    env_file: Path = typer.Option(
        Path(".env"),
        "--env",
        help="Path to .env file containing GEMINI_API_KEY_* variables.",
    ),
    use_chroma: bool = typer.Option(
        True,
        "--chroma/--no-chroma",
        help="Enable ChromaDB semantic memory (default: on).",
    ),
    top: int = typer.Option(
        5,
        "--top", "-n",
        help="Number of results for inline query mode.",
        min=1, max=20,
    ),
) -> None:
    """
    Scan a codebase and generate AI-powered HTML reports.
    Or ask a question: codereportai \"which algorithm handles traversal?\"
    """
    # If a named subcommand (e.g. `codereportai query ...`) was invoked, skip.
    if ctx.invoked_subcommand is not None:
        return

    # ── Inline query shortcut ────────────────────────────────────────────────
    # `codereportai "question?"` routes to query mode automatically.
    if question:
        root_q: Path = (path or Path.cwd()).resolve()
        _run_inline_query(question, root_q, env_file, model, top)
        return

    # ── Scan mode ────────────────────────────────────────────────────────────
    console.print(
        Panel.fit(
            "[bold cyan]CodeReportAI[/bold cyan]  [dim]v2.0.0[/dim]\n"
            "[dim]AI-powered codebase analysis — Gemini + ChromaDB[/dim]\n"
            '[dim]Tip: ask questions with [bold]codereportai \'your question\'[/bold][/dim]',
            border_style="cyan",
        )
    )

    root: Path = (path or Path.cwd()).resolve()

    # ── Path safety: ensure output stays within root ─────────────────────────
    output_root = (root / OUTPUT_DIRNAME).resolve()
    try:
        output_root.relative_to(root)   # raises ValueError if output escapes root
    except ValueError:
        console.print(f"[red]Security: output path {output_root} would escape root {root}[/red]")
        raise typer.Exit(code=1)

    root_safe = str(root).encode("ascii", errors="replace").decode("ascii")
    console.print(f"[bold]Target directory:[/bold] {root_safe}")

    api_keys = _load_env_and_keys(root, env_file)
    if not api_keys:
        console.print(
            "[bold red]ERROR: No API keys found.[/bold red]\n"
            "Create a [bold].env[/bold] file with at least one:\n"
            "  GEMINI_API_KEY_1=your_key_here\n\n"
            "Copy [bold].env.example[/bold] from the CodeReportAI install directory to get started."
        )
        raise typer.Exit(code=1)

    # Lazy imports
    from .api_manager import APIManager
    from .context_manager import ContextManager
    from .scanner import scan_files
    from .supervisor import Supervisor

    console.print("[bold]Scanning files…[/bold]")
    file_list = scan_files(root)

    if not file_list:
        console.print("[yellow]No source files found in the target directory.[/yellow]")
        raise typer.Exit(code=0)

    table = Table(title="Scan Summary", show_header=True, header_style="bold magenta")
    table.add_column("Metric", style="dim")
    table.add_column("Value", justify="right")
    table.add_row("Files discovered", str(len(file_list)))
    table.add_row("API keys loaded", str(len(api_keys)))
    table.add_row("Workers", str(workers))
    table.add_row("Model", model)
    table.add_row("Resume mode", "yes" if resume else "no")
    table.add_row("ChromaDB", "enabled" if use_chroma else "disabled")
    console.print(table)

    output_root.mkdir(parents=True, exist_ok=True)

    api_manager = APIManager(api_keys)
    ctx_manager = ContextManager()

    context_path = output_root / "context.json"
    if resume and context_path.exists():
        ctx_manager.load(context_path)
        console.print(
            f"[dim]Resumed from context.json — "
            f"{len(ctx_manager.snapshot().get('processed_files', []))} files already done.[/dim]"
        )

    supervisor = Supervisor(
        root=root,
        output_root=output_root,
        api_manager=api_manager,
        ctx_manager=ctx_manager,
        model_name=model,
        concurrency=workers,
        resume=resume,
        use_chroma=use_chroma,
    )

    try:
        supervisor.run(file_list)
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user. Progress has been saved to context.json.[/yellow]")
        console.print("Run with [bold]--resume[/bold] to continue where you left off.")
        raise typer.Exit(code=130)


# ---------------------------------------------------------------------------
# Inline query helper (shared between positional arg shortcut + query subcommand)
# ---------------------------------------------------------------------------

def _run_inline_query(question: str, root: Path, env_file: Path, model: str, top: int) -> None:
    """Embed question, search ChromaDB, answer with Gemini."""
    import requests as _requests

    console.print(
        Panel.fit(
            f"[bold cyan]CodeReportAI — Query Mode[/bold cyan]\n"
            f'[dim]Question:[/dim] "{question}"',
            border_style="cyan",
        )
    )

    chroma_dir = root / OUTPUT_DIRNAME / "chroma_store"
    if not chroma_dir.exists():
        console.print(
            f"[red]No ChromaDB store found at {chroma_dir}\n"
            "Run [bold]codereportai[/bold] to analyse the codebase first.[/red]"
        )
        return

    api_keys = _load_env_and_keys(root, env_file)
    if not api_keys:
        console.print("[red]No API keys found.[/red]")
        return

    api_key = api_keys[0]
    from .embedder import ChromaStore, _gemini_embed

    chroma = ChromaStore(db_dir=chroma_dir)
    if not chroma.available:
        console.print("[red]ChromaDB unavailable. Install: pip install chromadb[/red]")
        return
    if chroma.count() == 0:
        console.print("[yellow]ChromaDB is empty. Run codereportai first.[/yellow]")
        return

    console.print(f"[dim]Searching {chroma.count()} file analyses...[/dim]")
    q_embed = _gemini_embed(question, api_key, task_type="RETRIEVAL_QUERY")
    if not q_embed:
        console.print("[red]Failed to embed question. Check your API key.[/red]")
        return

    retrieved = chroma.query(question_embedding=q_embed, n_results=top)
    if not retrieved:
        console.print("[yellow]No relevant files found.[/yellow]")
        return

    table = Table(title=f"Top {len(retrieved)} Relevant Files", header_style="bold cyan")
    table.add_column("File", style="cyan")
    table.add_column("Lang")
    table.add_column("Match", justify="right")
    table.add_column("Purpose")
    for r in retrieved:
        table.add_row(r["path"], r["language"], str(r["similarity"]), (r["purpose"] or "—")[:55])
    console.print(table)

    # Build ranked context — highest match first, capped at 800 chars each
    context_parts = []
    for r in retrieved:
        doc_snippet = r["document"][:800].strip()
        context_parts.append(
            f"[FILE: {r['path']} | lang={r['language']} | match={r['similarity']}]\n"
            f"{doc_snippet}"
        )
    context_text = "\n\n".join(context_parts)

    qa_prompt = f"""A developer is working on this codebase and asked:

"{question}"

Here are the most relevant file analyses (already ranked by relevance):

{context_text}

Answer the developer's question directly and concisely.
Rules:
- Start your reply with the actual answer — no preamble, no restating the question.
- Write like you're responding in a code-review chat, not filling in a report template.
- Do NOT output bullet points summarising the question or the context you were given.
- Use inline code like `ClassName.method()` or **`file/path.java`** when naming files or functions.
- If the answer is a file/line location, just say where it is and briefly what it does there.
- If the answer involves steps (e.g. "how do I add X"), use a short numbered list.
- Keep the total answer under 150 words unless detail is genuinely needed.
- Format in Markdown."""
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
    console.print("[dim]Asking Gemini...[/dim]")
    try:
        resp = _requests.post(
            url,
            json={
                "contents": [{"parts": [{"text": qa_prompt}]}],
                "generationConfig": {
                    "temperature": 0.3,       # slightly warmer for natural prose
                    "maxOutputTokens": 1024,  # keep answers concise
                },
            },
            timeout=60,
        )
        resp.raise_for_status()
        answer = resp.json()["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as exc:
        console.print(f"[red]Gemini error: {exc}[/red]")
        return

    console.print("\n[bold green]Answer:[/bold green]")
    console.print(Panel(Markdown(answer), border_style="green"))


# ---------------------------------------------------------------------------
# Query subcommand — semantic Q&A against the ChromaDB knowledge base
# ---------------------------------------------------------------------------

@app.command()
def query(
    question: str = typer.Argument(..., help="Natural language question about the codebase."),
    path: Path = typer.Option(
        None, "--path", "-p",
        help="Project root previously analysed (default: CWD).",
        exists=True, file_okay=False, dir_okay=True, resolve_path=True,
    ),
    top: int = typer.Option(5, "--top", "-n", help="Files to retrieve.", min=1, max=20),
    model: str = typer.Option("gemma-4-31b-it", "--model", "-m"),
    env_file: Path = typer.Option(Path(".env"), "--env"),
) -> None:
    """
    Ask a natural language question about a previously analysed codebase.

    Examples:
        codereportai query "which algorithm is used for traversal?"
        codereportai query "how do I add a new data source?" --top 8
        codereportai query "what are the biggest security risks?"
    """
    root = (path or Path.cwd()).resolve()
    _run_inline_query(question, root, env_file, model, top)


if __name__ == "__main__":
    app()
