"""
supervisor.py — Supervisor Agent (Orchestrator).

Parallel execution model:
  ┌──────────────────────────────────────────────────────────────────┐
  │  KEY_1  →  2 concurrent worker threads  (files 1,2 in parallel) │
  │  KEY_2  →  2 concurrent worker threads  (files 3,4 in parallel) │
  │  KEY_3  →  SUPERVISOR KEY (ChromaDB embedding + Synthesis Agent) │
  └──────────────────────────────────────────────────────────────────┘
  Total simultaneous files: 4 (2 per worker key × 2 worker keys)

Retry policy (handled inside Worker._call_gemini_rest):
  429 / 503  →  wait 10 s  →  retry SAME key  →  up to 3 attempts
"""

from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor, Future, as_completed
from pathlib import Path
from typing import List, Optional, Any, Dict

from rich.console import Console
from rich.progress import (
    Progress, SpinnerColumn, BarColumn,
    TaskProgressColumn, TextColumn, TimeElapsedColumn, TimeRemainingColumn,
)
from rich.panel import Panel

from .api_manager import APIManager, NoKeysAvailableError
from .context_manager import ContextManager
from .embedder import ChromaStore
from .html_renderer import render_report
from .synthesis_agent import SynthesisAgent
from .worker import Worker

console = Console()

# How many total parallel analysis slots (= worker_keys × WORKERS_PER_KEY)
# This is computed dynamically from APIManager; the value here is the fallback.
DEFAULT_CONCURRENCY = 4


class Supervisor:
    def __init__(
        self,
        root: Path,
        output_root: Path,
        api_manager: APIManager,
        ctx_manager: ContextManager,
        model_name: str = "gemma-4-31b-it",
        concurrency: int = DEFAULT_CONCURRENCY,
        resume: bool = False,
        use_chroma: bool = True,
    ) -> None:
        self.root        = root
        self.output_root = output_root
        self.api_manager = api_manager
        self.ctx_manager = ctx_manager
        self.model_name  = model_name
        self.resume      = resume
        self.context_path = output_root / "context.json"

        # Total parallel slots = len(worker_keys) × WORKERS_PER_KEY
        n_worker_keys = len(api_manager._worker_keys)
        self.concurrency = n_worker_keys * api_manager.WORKERS_PER_KEY

        self._worker = Worker(model_name=model_name)
        self._stats  = {
            "processed": 0, "skipped": 0, "errors": 0,
            "total_lines": 0, "complexity_score": 0,
        }
        self._parsed_results: List[Dict[str, Any]] = []
        self._result_lock = threading.Lock()  # protect shared lists / stats

        # ── ChromaStore ────────────────────────────────────────────────
        self._chroma: Optional[ChromaStore] = None
        if use_chroma:
            chroma_dir = output_root / "chroma_store"
            self._chroma = ChromaStore(db_dir=chroma_dir)
            self.ctx_manager.attach_chroma(self._chroma)

        # Dedicated thread pool for async embedding (non-blocking)
        self._embed_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="embed")

    # ------------------------------------------------------------------
    # Main run loop
    # ------------------------------------------------------------------

    def run(self, file_list: List[Path]) -> None:
        to_process: List[Path] = []
        for fp in file_list:
            if self.resume and self.ctx_manager.is_processed(fp):
                self._stats["skipped"] += 1
            else:
                to_process.append(fp)

        total    = len(to_process)
        skipped  = self._stats["skipped"]
        chroma_s = (
            "[green]ChromaDB ON[/green]" if (self._chroma and self._chroma.available)
            else "[yellow]ChromaDB OFF[/yellow]"
        )
        console.print(
            Panel(
                f"[bold cyan]Files to analyse:[/bold cyan] {total}  "
                f"[dim](skipped {skipped} already processed)[/dim]  "
                f"{chroma_s}\n"
                f"[dim]Parallel slots: {self.concurrency}  "
                f"({len(self.api_manager._worker_keys)} worker key(s) × "
                f"{self.api_manager.WORKERS_PER_KEY} threads each)[/dim]",
                title="[bold]CodeReportAI — Starting Analysis[/bold]",
                border_style="cyan",
            )
        )

        if total == 0:
            console.print("[green]All files already processed. Use --no-resume to reprocess.[/green]")
            return

        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=console,
            transient=False,
        ) as progress:
            task_id = progress.add_task("Analysing files...", total=total)

            # concurrency = total parallel worker slots (e.g. 4 = 2 keys × 2 slots)
            with ThreadPoolExecutor(
                max_workers=self.concurrency,
                thread_name_prefix="worker",
            ) as executor:
                future_map: dict[Future, Path] = {
                    executor.submit(self._process_one, fp): fp
                    for fp in to_process
                }
                for future in as_completed(future_map):
                    fp = future_map[future]
                    try:
                        result = future.result()
                    except Exception as exc:
                        console.print(f"[red]Unhandled error for {fp.name}: {exc}[/red]")
                        with self._result_lock:
                            self._stats["errors"] += 1
                        result = None

                    if result and not result.get("error"):
                        self._on_success(result)
                    elif result and result.get("error"):
                        console.print(
                            f"[red]FAIL {result['relative_path']}: {result['error']}[/red]"
                        )
                        with self._result_lock:
                            self._stats["errors"] += 1

                    progress.advance(task_id)

        # Wait for all pending embed jobs
        self._embed_executor.shutdown(wait=True)

        # ── Synthesis Agent ───────────────────────────────────────────
        # On --resume runs where only a few files changed, loading the
        # existing synthesis.json is far better than re-synthesising from
        # 1-2 results.  Only run (or re-run) synthesis when enough new
        # results are available to produce a meaningful report.
        synthesis = self._load_or_run_synthesis()

        # ── Generate Index Dashboard ──────────────────────────────────
        from .html_renderer import render_index
        index_html = render_index(
            self._parsed_results,
            self.root,
            self._stats,
            synthesis=synthesis,
        )
        (self.output_root / "codereportai.html").write_text(index_html, encoding="utf-8")

        self._print_summary()

    # ------------------------------------------------------------------
    # Per-file processing — uses semaphore-bound key assignment
    # ------------------------------------------------------------------

    def _process_one(self, file_path: Path) -> dict:
        """
        Acquire a worker key slot (blocks until one of the 2 slots for that
        key is free), run the Worker, then release the slot.
        Retry logic for 429/503 lives inside Worker._call_gemini_rest.
        """
        key, semaphore = self.api_manager.acquire_worker_key()
        try:
            relative_path = str(file_path.relative_to(self.root))
            snippet = None
            language = None
            try:
                snippet = file_path.read_text(encoding="utf-8", errors="replace")[:600]
                from .worker import LANG_MAP
                language = LANG_MAP.get(file_path.suffix.lower())
            except OSError:
                pass

            context_summary = self.ctx_manager.summary_for_prompt(
                file_path=relative_path,
                language=language,
                content_snippet=snippet,
                api_key=key,
            )

            return self._worker.process(
                file_path=file_path,
                root=self.root,
                api_key=key,
                context_summary=context_summary,
                chroma_context="",
            )
        except Exception as exc:
            return {
                "file_path":     file_path,
                "relative_path": str(file_path.relative_to(self.root)),
                "error":         str(exc),
                "html_sections": {},
                "context_update": {},
                "language": "Unknown",
            }
        finally:
            semaphore.release()   # always free the slot

    # ------------------------------------------------------------------
    # Success handler (thread-safe)
    # ------------------------------------------------------------------

    def _on_success(self, result: dict) -> None:
        fp: Path = result["file_path"]

        with self._result_lock:
            self.ctx_manager.update(result.get("context_update", {}), fp)
            self.ctx_manager.mark_processed(fp)
            self.ctx_manager.save(self.context_path)

        # Async embed into ChromaDB using the reserved supervisor key
        if self._chroma and self._chroma.available:
            sup_key = self.api_manager.supervisor_key
            if sup_key:
                self._embed_executor.submit(
                    self._chroma.embed_and_store, result, sup_key
                )

        # Render HTML report
        html      = render_report(result)
        out_path  = self._html_output_path(fp)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(html, encoding="utf-8")

        with self._result_lock:
            self._stats["processed"] += 1
            sections = result.get("html_sections", {})
            lines    = sections.get("file_overview", {}).get("size_lines", 0)
            algos    = len(sections.get("algorithms", []))
            funcs    = len(sections.get("function_breakdown", []))
            risks    = len(sections.get("risks_and_warnings", []))
            self._stats["total_lines"]      += lines
            self._stats["complexity_score"] += round(
                (lines / 100) + (algos * 5) + (funcs * 0.5) + (risks * 3), 1
            )
            self._parsed_results.append(result)

        rel_safe = (
            str(out_path.relative_to(self.output_root.parent))
            .encode("ascii", errors="replace")
            .decode("ascii")
        )
        console.print(f"[green]OK[/green] {result['relative_path']} → {rel_safe}")

    # ------------------------------------------------------------------
    # Synthesis Agent
    # ------------------------------------------------------------------

    MIN_FILES_FOR_FRESH_SYNTHESIS = 3   # re-run synthesis only if this many new files

    def _load_or_run_synthesis(self) -> dict:
        """
        Smart synthesis dispatcher:

        1. If this was a resume run that only processed < MIN_FILES_FOR_FRESH_SYNTHESIS
           new files AND a synthesis.json already exists → load and reuse it.
           (Avoids feeding 1-file prompts to the model which produce garbage.)

        2. Otherwise → gather ALL available results (previously processed files
           loaded from context.json + new files from this run) and run a full
           fresh synthesis.
        """
        synthesis_path = self.output_root / "synthesis.json"
        n_new = len(self._parsed_results)

        # ── Case 1: resume with very few changes — reuse existing synthesis ──
        if n_new < self.MIN_FILES_FOR_FRESH_SYNTHESIS and synthesis_path.exists():
            try:
                import json as _json
                existing = _json.loads(synthesis_path.read_text(encoding="utf-8"))
                console.print(
                    f"[dim]Resume mode: {n_new} new file(s) — reusing existing synthesis.json "
                    f"(re-runs when ≥{self.MIN_FILES_FOR_FRESH_SYNTHESIS} files change).[/dim]"
                )
                return existing
            except Exception as exc:
                console.print(f"[yellow]Could not load existing synthesis.json: {exc}[/yellow]")

        # ── Case 2: run a full synthesis ─────────────────────────────────────
        # Merge new results with historical results from context.json so the
        # synthesis sees the full codebase, not just this run's files.
        all_results = self._merge_all_results()
        if not all_results:
            console.print("[yellow]No results to synthesise.[/yellow]")
            return {}

        return self._run_synthesis(all_results)

    def _merge_all_results(self) -> list:
        """
        Return self._parsed_results merged with any previously-stored summaries
        from the context.json file (for resume runs).
        Deduplication is done by relative_path.
        """
        merged: dict = {r["relative_path"]: r for r in self._parsed_results}

        # Load historical context summaries to fill in gaps
        if self.context_path.exists():
            try:
                import json as _json
                ctx = _json.loads(self.context_path.read_text(encoding="utf-8"))
                files_ctx = ctx.get("files", {})
                for rel_path, meta in files_ctx.items():
                    if rel_path not in merged:
                        # Build a minimal synthetic result from context metadata
                        merged[rel_path] = {
                            "relative_path": rel_path,
                            "language": meta.get("language", "Unknown"),
                            "error": None,
                            "html_sections": {
                                "file_overview": {
                                    "purpose": meta.get("purpose", ""),
                                    "size_lines": meta.get("size_lines", 0),
                                },
                                "function_breakdown": [],
                                "algorithms": [],
                                "notable_patterns": meta.get("patterns_found", []),
                                "risks_and_warnings": [],
                                "system_role": meta.get("cross_file_insight", ""),
                            },
                        }
            except Exception as exc:
                console.print(f"[yellow]Could not load context.json for synthesis merge: {exc}[/yellow]")

        return list(merged.values())

    def _run_synthesis(self, all_results: list | None = None) -> dict:
        results_to_use = all_results if all_results is not None else self._parsed_results
        if not results_to_use:
            return {}

        api_key = self.api_manager.supervisor_key
        if not api_key:
            console.print("[yellow]No supervisor key available — skipping Synthesis Agent.[/yellow]")
            return {}

        console.print("[dim]Running Synthesis Agent (using reserved supervisor key)...[/dim]")
        agent = SynthesisAgent(
            output_root=self.output_root,
            api_key=api_key,
            model_name=self.model_name,
            chroma_store=self._chroma,
        )
        return agent.run(results_to_use) or {}



    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _html_output_path(self, file_path: Path) -> Path:
        rel = file_path.relative_to(self.root)
        out = self.output_root / rel.with_suffix(".html")
        # Safety: ensure output stays within output_root
        try:
            out.resolve().relative_to(self.output_root.resolve())
        except ValueError:
            raise ValueError(
                f"Security: output path {out} would escape {self.output_root}"
            )
        return out

    def _print_summary(self) -> None:
        s = self._stats
        chroma_count = self._chroma.count() if self._chroma else 0
        n_slots = len(self.api_manager._worker_keys) * self.api_manager.WORKERS_PER_KEY
        console.print(
            Panel(
                f"[bold green]Done:[/bold green] {s['processed']}   "
                f"[bold yellow]Skipped:[/bold yellow] {s['skipped']}   "
                f"[bold red]Errors:[/bold red] {s['errors']}\n"
                f"[dim]ChromaDB entries:[/dim] {chroma_count}   "
                f"[dim]Parallel slots used:[/dim] {n_slots}   "
                f"[dim]Reports:[/dim] {self.output_root}",
                title="[bold]CodeReportAI — Run Complete[/bold]",
                border_style="green",
            )
        )
