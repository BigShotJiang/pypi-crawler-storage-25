"""
api_manager.py — Thread-safe multi-key Gemini API manager.

Architecture (3 keys, 4 parallel workers):

  ┌─────────────────────────────────────────────┐
  │  GEMINI_API_KEY_1  →  2 worker threads      │
  │  GEMINI_API_KEY_2  →  2 worker threads      │
  │  GEMINI_API_KEY_3  →  SUPERVISOR (reserved) │
  └─────────────────────────────────────────────┘

Retry policy (per worker):
  - 429 ResourceExhausted  → wait 10 s → retry SAME key (no rotation)
  - 503 ServiceUnavailable → wait 10 s → retry SAME key (no rotation)
  - All other errors       → propagate immediately
"""

from __future__ import annotations

import threading
import time
from typing import List, Optional

from rich.console import Console

console = Console()

# How long to wait before retrying a 429 or 503 on the SAME key
RATE_LIMIT_WAIT: int = 10


class NoKeysAvailableError(RuntimeError):
    """Raised when no worker API keys are configured."""


class APIManager:
    """
    Manages a pool of Gemini API keys.

    With ≥ 3 keys:
      - Last key is reserved as the supervisor key (embedding + synthesis).
      - Remaining keys are worker keys; each key serves exactly
        WORKERS_PER_KEY concurrent threads (default 2).

    With < 3 keys:
      - All keys shared between workers; supervisor uses any available key.

    Retry policy (enforced by the caller — see supervisor.py):
      On 429 or 503 → wait RATE_LIMIT_WAIT seconds → retry the SAME key.
    """

    WORKERS_PER_KEY: int = 2   # concurrent threads per worker key

    def __init__(self, keys: List[str]) -> None:
        if not keys:
            raise ValueError("At least one GEMINI_API_KEY must be provided.")

        self._all_keys: List[str] = list(keys)

        # ── Key assignment ─────────────────────────────────────────────
        if len(keys) >= 3:
            self._supervisor_key: Optional[str] = keys[-1]
            self._worker_keys: List[str]         = keys[:-1]
        else:
            # Not enough keys to reserve one → share everything
            self._supervisor_key = keys[-1]
            self._worker_keys    = keys[:]

        # Build the per-key semaphore pool so each worker key handles
        # at most WORKERS_PER_KEY concurrent requests.
        self._semaphores = {
            k: threading.Semaphore(self.WORKERS_PER_KEY)
            for k in self._worker_keys
        }

        # Round-robin index for assigning keys to new tasks
        self._rr_index = 0
        self._rr_lock  = threading.Lock()

        n_workers = len(self._worker_keys) * self.WORKERS_PER_KEY
        console.print(
            f"[green]Loaded {len(keys)} API key(s)[/green]  "
            f"[dim]({len(self._worker_keys)} worker key(s) × "
            f"{self.WORKERS_PER_KEY} threads = {n_workers} parallel slots  |  "
            f"1 supervisor key reserved)[/dim]"
        )

    # ------------------------------------------------------------------
    # Worker-key interface
    # ------------------------------------------------------------------

    def acquire_worker_key(self) -> tuple[str, threading.Semaphore]:
        """
        Pick the next worker key (round-robin) and acquire its semaphore slot.
        Blocks if that key already has WORKERS_PER_KEY active requests.

        Returns (key, semaphore) — caller MUST call semaphore.release() when done.
        """
        with self._rr_lock:
            key = self._worker_keys[self._rr_index % len(self._worker_keys)]
            self._rr_index += 1

        sem = self._semaphores[key]
        sem.acquire()          # blocks if key is fully occupied
        return key, sem

    @property
    def supervisor_key(self) -> Optional[str]:
        """The API key reserved for the supervisor agent (embedding / synthesis)."""
        return self._supervisor_key

    # ------------------------------------------------------------------
    # Legacy compat — still used by cli.py summary / context
    # ------------------------------------------------------------------

    def get_key(self, timeout: float = 300.0) -> str:
        """
        Legacy single-key getter used by the query CLI path and
        context_manager (non-threaded usage).
        Returns the supervisor key first, then worker keys as fallback.
        """
        return self._supervisor_key or self._worker_keys[0]

    def mark_rate_limited(self, key: str) -> None:
        """No-op — rate-limit handling moved into the worker retry loop."""
        pass

    def advance(self) -> None:
        """No-op — round-robin is now implicit in acquire_worker_key()."""
        pass

    def all_cooling_down(self) -> bool:
        """Legacy compat — always False under the new model."""
        return False
