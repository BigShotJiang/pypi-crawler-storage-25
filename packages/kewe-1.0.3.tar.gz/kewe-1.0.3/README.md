# KeWe

<p align="center">
  <strong>Python Async Web Framework</strong><br>
  <em>Fast, modern, and production-ready — built on pure Python asyncio</em>
</p>

<p align="center">
  <a href="https://pypi.org/project/kewe/"><img src="https://img.shields.io/pypi/v/kewe.svg" alt="PyPI"></a>
  <a href="https://pypi.org/project/kewe/"><img src="https://img.shields.io/pypi/pyversions/kewe.svg" alt="Python"></a>
  <a href="https://github.com/Ouopoulos/kewe/blob/main/LICENSE"><img src="https://img.shields.io/pypi/l/kewe.svg" alt="License"></a>
  <a href="https://github.com/Ouopoulos/kewe"><img src="https://img.shields.io/github/stars/Ouopoulos/kewe.svg" alt="Stars"></a>
</p>

---

## Features

KeWe is a batteries-included async web framework that covers the full HTTP lifecycle:

- **Pure Asyncio** — Built on `asyncio` with zero sync overhead. Uses `uvloop` on Linux, `winloop` on Windows.
- **Fast JSON** — Backed by `orjson` for high-performance serialization, with `ujson` fallback.
- **Full HTTP Stack** — HTTP/1.1, HTTP/2 (`h2`), HTTP/3 (`aioquic`), keep-alive, range requests, SSE, streaming uploads.
- **Automatic API Docs** — OpenAPI 3.0 / Swagger generation with docstring-first schema extraction.
- **Routing** — Regex-based routing with type converters, path parameters, URL building (`url_for`), blueprints, class-based views, and blueprint groups.
- **Middleware** — Onion-style middleware pipeline with priority control. Built-ins: CORS, compression, security headers, trusted hosts, forwarded headers, HTTPS redirect, request ID, error tracking.
- **Security** — JWT (HS256/RS256), OAuth2, API Key, Basic Auth, CSRF protection, rate limiting, RBAC (roles & permissions), password hashing, signed cookies, token encryption, circuit breaker.
- **Dependency Injection** — `Depends()`, `Query()`, `Header()`, `Body()`, `Form()`, `File()`, `Path()`, `Security()` with scoped service lifetimes.
- **WebSockets** — Built-in WS support with connection manager, broadcasting, group messaging, and JSON messaging.
- **Background Tasks** — Fire-and-forget tasks, scheduled jobs, async task processor, cleanup manager, token auto-rotator.
- **Caching** — Memory, Redis backends. Decorators: `@cache`, `@cache_response`, `@memoize`, `@cached_property`. LRU cache included.
- **Monitoring** — Health checks (liveness/readiness), Prometheus-style metrics, anomaly detection, audit logging.
- **Testing** — `TestClient`, `AsyncTestClient`, `TestCase`, `TestWebSocket`, dependency overriding.
- **CLI** — Interactive REPL, shell commands, startup management, file watching reloader.
- **Plugins** — Database (SQLAlchemy + async), Redis, OpenAPI, Pydantic, CORS, compression, rate limiting. Extensible plugin system.
- **Multi-Process** — Worker manager with configurable workers, shared context, multiplexing.
- **ASGI Compatible** — Run behind Uvicorn, Hypercorn, or any ASGI server.

---

## Installation

```bash
pip install kewe
```

Install with optional dependencies for specific features:

```bash
pip install kewe[security]    # JWT, CSRF, rate limiting, password hashing
pip install kewe[database]    # SQLAlchemy + Alembic
pip install kewe[redis]       # Redis cache backend
pip install kewe[pydantic]    # Pydantic model validation
pip install kewe[otel]        # OpenTelemetry tracing
pip install kewe[fast]        # httptools-based HTTP parser
pip install kewe[celery]      # Celery task queue
pip install kewe[httpx]       # HTTP client
pip install kewe[yaml]        # YAML config support
pip install kewe[http2]       # HTTP/2 support
pip install kewe[http3]       # HTTP/3 support
pip install kewe[all]         # Everything
```

---

## Quickstart

```python
from kewe import Kewe, json

app = Kewe("my_app")

@app.get("/")
async def home():
    return {"message": "Hello, KeWe!"}

@app.get("/hello/{name}")
async def hello(name: str):
    return {"greeting": f"Hello, {name}!"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
```

Save as `main.py` and run:

```bash
python main.py
# or via CLI:
kewe run app:main --port 8000
```

---

## Routing

```python
from kewe import Kewe, json, text, html, redirect, Request

app = Kewe("routing_demo")

# HTTP method decorators
@app.get("/api/users")
@app.post("/api/users")
@app.put("/api/users/{user_id}")
@app.patch("/api/users/{user_id}")
@app.delete("/api/users/{user_id}")
@app.head("/api/users")
@app.options("/api/users")

# Path parameters with type conversion
@app.get("/items/{item_id:int}")
async def get_item(request: Request, item_id: int):
    return {"item_id": item_id}

@app.get("/posts/{slug:str}")
async def get_post(slug: str):
    return {"slug": slug}

@app.get("/files/{path:path}")
async def get_file(path: str):
    return {"file_path": path}

# Blueprints for modular routing
from kewe import Blueprint

users_bp = Blueprint("users", url_prefix="/api/users")

@users_bp.get("/")
async def list_users():
    return json([{"id": 1, "name": "Alice"}])

@users_bp.get("/{user_id:int}")
async def get_user(user_id: int):
    return json({"id": user_id, "name": "Alice"})

app.register_blueprint(users_bp)
```

---

## Response Types

```python
from kewe import (
    Kewe, json, text, html, redirect,
    file, Response, StreamingResponse,
    ServerSentEventResponse
)

app = Kewe("response_demo")

@app.get("/json")
async def json_demo():
    return json({"key": "value"})

@app.get("/text")
async def text_demo():
    return text("Plain text response")

@app.get("/html")
async def html_demo():
    return html("<h1>Hello World</h1>")

@app.get("/redirect")
async def redirect_demo():
    return redirect("/new-location")

@app.get("/file")
async def file_demo():
    return await file("path/to/file.pdf")

# Server-Sent Events
@app.get("/events")
async def events():
    async def generate():
        for i in range(10):
            yield f"data: Message {i}\n\n"
    return ServerSentEventResponse(generate())
```

---

## Middleware

```python
from kewe import Kewe, Middleware
from kewe.middleware import (
    CORSMiddleware, SecurityHeadersMiddleware,
    HTTPSRedirectMiddleware, TrustedHostMiddleware,
    CompressionMiddleware
)

app = Kewe("secure_app")

# Built-in middleware
app.add_middleware(CORSMiddleware(
    allow_origins=["https://example.com"],
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
    allow_credentials=True,
))

app.add_middleware(SecurityHeadersMiddleware())
app.add_middleware(CompressionMiddleware())
app.add_middleware(TrustedHostMiddleware(allowed_hosts=["example.com"]))

# Custom middleware
@app.middleware
async def timing_middleware(request, call_next):
    import time
    start = time.time()
    response = await call_next(request)
    response.headers["X-Response-Time"] = f"{time.time() - start:.3f}s"
    return response
```

---

## Request Handling

```python
from kewe import Kewe, Request, json, Depends, Query, Body

app = Kewe("request_demo")

@app.get("/search")
async def search(request: Request, q: str = Query(), page: int = Query(default=1)):
    return json({"query": q, "page": page, "url": str(request.url)})

@app.post("/items")
async def create_item(body: dict = Body()):
    return json(body, status_code=201)

@app.post("/upload")
async def upload(request: Request):
    form = await request.form()
    uploaded_file = form.get("file")
    if uploaded_file:
        content = await uploaded_file.read()
        return json({"filename": uploaded_file.filename, "size": len(content)})
    return json({"error": "No file"}, status_code=400)
```

---

## Dependency Injection

```python
from kewe import Kewe, Depends, json
from kewe.application.di import Container, Lifetime

app = Kewe("di_demo")
container = app.container

# Register services
class DatabaseService:
    async def query(self, sql: str):
        return {"result": f"executed: {sql}"}

container.register(DatabaseService, lifetime=Lifetime.SINGLETON)
container.register("config", lambda: {"db_host": "localhost"}, Lifetime.SINGLETON)

# Use in routes
async def get_db():
    return app.container.resolve(DatabaseService)

@app.get("/db")
async def db_demo(db: DatabaseService = Depends(get_db)):
    return await db.query("SELECT 1")

# Parameter dependencies
from kewe import Query, Header, Body

@app.post("/items")
async def create(
    page: int = Query(default=1),
    authorization: str = Header(),
    data: dict = Body(),
):
    return {"page": page, "auth": authorization, "data": data}
```

---

## WebSocket

```python
from kewe import Kewe, websocket, WebSocketConnection

app = Kewe("ws_demo")

@app.websocket("/ws")
async def echo(ws: WebSocketConnection):
    await ws.accept()
    async for message in ws:
        data = message.json()
        await ws.send_json({"echo": data})

# Broadcasting with WebSocket Manager
from kewe import WebSocketManager

manager = WebSocketManager(app)

@app.websocket("/chat")
async def chat(ws: WebSocketConnection):
    await ws.accept()
    manager.connect(ws)
    try:
        async for message in ws:
            await manager.broadcast(message.json(), exclude=ws)
    finally:
        manager.disconnect(ws)
```

---

## Security

```python
from kewe import Kewe
from kewe.security.auth import AuthManager, login_required, get_current_user
from kewe.security.jwt import JWTAuthManager
from kewe.security.csrf import CSRFMiddleware
from kewe.security.rate_limit import RateLimiter, rate_limit

app = Kewe("secure_app")

# JWT Auth
jwt = JWTAuthManager(secret_key="your-secret-key")

@app.post("/login")
async def login():
    tokens = jwt.generate_tokens({"user_id": 123})
    return {"access_token": tokens.access_token}

@app.get("/me")
@login_required
async def protected(user = get_current_user()):
    return {"user_id": user.user_id}

# Rate limiting
@app.get("/api/sensitive")
@rate_limit(max_requests=10, window_seconds=60)
async def rate_limited():
    return {"status": "ok"}

# CSRF protection
app.add_middleware(CSRFMiddleware())
```

---

## OpenAPI / Swagger

```python
from kewe import Kewe
from kewe.plugins.openapi import OpenAPIPlugin

app = Kewe("api_docs")
openapi = OpenAPIPlugin()
openapi.setup(app, title="My API", version="1.0.0")

# Auto-generated from docstrings and type hints
@app.get("/items/{item_id:int}")
async def get_item(
    item_id: int,
    q: str = None,
) -> dict:
    """Retrieve an item by ID.

    Args:
        item_id: The unique identifier of the item.
        q: Optional search query string.
    """
    return {"item_id": item_id, "query": q}

# Access:
# - OpenAPI JSON: http://localhost:8000/openapi.json
# - Swagger UI: http://localhost:8000/docs
# - ReDoc: http://localhost:8000/redoc
```

---

## Health Checks & Monitoring

```python
from kewe import Kewe
from kewe.monitoring.health import setup_health_checks, HealthCheck
from kewe.monitoring.metrics import setup_metrics

app = Kewe("monitored_app")

# Health checks
setup_health_checks(app, checks=[
    HealthCheck(name="database", check=check_db_connection),
    HealthCheck(name="redis", check=check_redis),
    HealthCheck(name="external_api", check=check_external_api),
])
# Endpoints: /health/live, /health/ready

# Metrics
setup_metrics(app, path="/metrics")
```

---

## Application Factory

```python
from kewe import create_app, KeweConfig, Kewe

config = KeweConfig()
config.debug = False
config.host = "0.0.0.0"
config.port = 8080

app = create_app("production_app", config=config)

@app.get("/")
async def root():
    return {"status": "running"}
```

---

## Testing

```python
from kewe import Kewe, TestClient, AsyncTestClient

app = Kewe("test_app")

@app.get("/api/items")
async def list_items():
    return {"items": []}

# Synchronous test client
with TestClient(app) as client:
    response = client.get("/api/items")
    assert response.status_code == 200
    data = response.json()
    assert "items" in data

# Async test client
async with AsyncTestClient(app) as client:
    response = await client.get("/api/items")
    assert response.status_code == 200
```

---

## Configuration

```python
from kewe import Config, KeweConfig

# Dictionary-style config
config = KeweConfig()
config.debug = True
config.host = "0.0.0.0"
config.port = 8000
config.secret_key = "production-secret-key"

# Load from environment
config.load_from_env()

# Load from file
config.load_from_file("config.json")

# Load from object
class Settings:
    DEBUG = True
    HOST = "0.0.0.0"
    PORT = 8080

config.load_from_object(Settings)

app = Kewe("configured_app", config=config)
```

---

## Project Structure

```
kewe/
├── application/     # App core, config, DI, signals, state
├── background/      # Background tasks, scheduling, cleanup
├── base/            # Constants, context, types, cancellation
├── cache/           # Cache manager, backends, decorators
├── cli/             # CLI tools, REPL
├── cookies/         # Cookie/session handling
├── database/        # SQLAlchemy integration, models, queries
├── errors/          # Exceptions, handlers, tracking, circuit breaker
├── gateway/         # API gateway adapter
├── handlers/        # Static file serving, simple handlers
├── http/            # HTTP client, headers, keepalive, URL, range
├── logging/         # Structured logging, access logs, formatters
├── middleware/       # Middleware core, CORS, request ID
├── monitoring/      # Health, metrics, anomaly detection, audit
├── plugins/         # Auth, database, OpenAPI, Pydantic support
├── request/         # Request parsing, forms, uploads, multipart
├── response/        # Response types, streaming
├── routing/         # Router, blueprints, views, converters
├── security/        # Auth, JWT, CSRF, rate limiting, RBAC, password
├── server/          # ASGI, HTTP server, lifecycle, reloader, SSL
├── telemetry/       # OpenTelemetry, tracing
├── touchup/         # Performance optimization, zero-copy
├── utils/           # Helpers, testing, i18n, pagination
├── websocket/       # WebSocket protocol, connection, manager
├── worker/          # Process workers, shared context, multiplexer
├── app.py           # Main Kewe application class
└── factory.py       # Application factory
```

---

## Requirements

- Python 3.12+
- No required external dependencies — runs on the standard library
- `orjson` — fast JSON serialization (optional, falls back to `ujson` then `json`)
- `uvloop` (Linux) / `winloop` (Windows) — accelerated event loop (optional)

---

## License

MIT — see [LICENSE](LICENSE) for details.
