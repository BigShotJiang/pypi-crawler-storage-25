#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Kewe CLI入口点

允许通过 `python -m kewe` 运行CLI

使用示例:
    $ python -m kewe hello:app
    $ python -m kewe hello:app --host=0.0.0.0 --port=8000
"""
from kewe.cli.app import main

if __name__ == "__main__":
    main()
