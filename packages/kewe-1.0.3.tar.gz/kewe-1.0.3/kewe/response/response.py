#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Response对象 - 增强版响应处理
包括：流式响应、文件下载、Cookie设置、重定向
"""

import logging
import mimetypes
import os
import asyncio
import re
import urllib.parse
from typing import Dict, Any, Optional, Union, AsyncGenerator, List, Callable
from dataclasses import dataclass

_bg_logger = logging.getLogger(__name__)

_PYDANTIC_BASEMODEL = None
_PYDANTIC_CHECKED = False

def _get_pydantic_basemodel():
    global _PYDANTIC_BASEMODEL, _PYDANTIC_CHECKED
    if not _PYDANTIC_CHECKED:
        _PYDANTIC_CHECKED = True
        try:
            from pydantic import BaseModel
            _PYDANTIC_BASEMODEL = BaseModel
        except ImportError:
            _PYDANTIC_BASEMODEL = None
    return _PYDANTIC_BASEMODEL


def _serialize_pydantic(data: Any) -> Any:
    if isinstance(data, (str, int, float, bool)) or data is None:
        return data
    bm = _get_pydantic_basemodel()
    if bm is None:
        return data
    if isinstance(data, dict):
        for v in data.values():
            if isinstance(v, bm):
                from kewe.plugins.pydantic_support import model_to_dict
                return {k: model_to_dict(v) if isinstance(v, bm) else v for k, v in data.items()}
        return data
    if isinstance(data, list):
        if data and isinstance(data[0], bm):
            from kewe.plugins.pydantic_support import model_to_dict
            return [model_to_dict(item) if isinstance(item, bm) else item for item in data]
        return data
    if isinstance(data, bm):
        from kewe.plugins.pydantic_support import model_to_dict
        return model_to_dict(data)
    return data


def _background_task_error_callback(task):
    try:
        task.result()
    except Exception:
        _bg_logger.error("Background task error", exc_info=True)
from datetime import datetime, timezone
from email.utils import formatdate

# 使用性能优化的JSON处理
from kewe.utils.compat import json as _json
from kewe.http.headers import Headers

logger = logging.getLogger(__name__)


class BackgroundTask:
    __slots__ = ('func', 'args', 'kwargs')

    def __init__(self, func: Callable, *args: Any, **kwargs: Any):
        self.func = func
        self.args = args
        self.kwargs = kwargs

    async def __call__(self) -> None:
        if asyncio.iscoroutinefunction(self.func):
            await self.func(*self.args, **self.kwargs)
        else:
            self.func(*self.args, **self.kwargs)

    async def run(self) -> None:
        await self()


class BackgroundTasks:
    __slots__ = ('tasks',)

    def __init__(self, tasks: Optional[List[BackgroundTask]] = None):
        self.tasks: List[BackgroundTask] = list(tasks) if tasks else []

    def add_task(self, func: Callable, *args: Any, **kwargs: Any) -> None:
        self.tasks.append(BackgroundTask(func, *args, **kwargs))

    async def __call__(self) -> None:
        await self.run()

    async def run(self) -> None:
        for task in self.tasks:
            try:
                await task()
            except Exception as e:
                logger.error(f"Background task error: {e}", exc_info=True)


@dataclass
class ResponseCookie:
    _TOKEN_RE = re.compile(r'^[!#$%&\'*+\-.^_`|~0-9A-Za-z]+$')
    _QUOTABLE_RE = re.compile(r'^[!#$%&\'()*+\-./:<=>?@[\]^_`{|}~0-9A-Za-z ]*$')

    name: str
    value: str
    expires: Optional[datetime] = None
    max_age: Optional[int] = None
    domain: Optional[str] = None
    path: str = "/"
    secure: bool = False
    httponly: bool = False
    samesite: str = "Lax"

    def to_header(self) -> str:
        if not self._TOKEN_RE.match(self.name):
            raise ValueError(f"Invalid cookie name: {self.name!r}")
        safe_value = self.value.replace('\r', '').replace('\n', '')
        if '\x00' in safe_value or not self._QUOTABLE_RE.match(safe_value):
            from urllib.parse import quote
            safe_value = quote(safe_value, safe='')
        parts = [f"{self.name}={safe_value}"]

        if self.expires:
            parts.append(f"Expires={formatdate(timeval=self.expires.timestamp(), localtime=False, usegmt=True)}")

        if self.max_age is not None:
            parts.append(f"Max-Age={self.max_age}")

        if self.domain:
            parts.append(f"Domain={self.domain}")

        parts.append(f"Path={self.path}")

        if self.secure:
            parts.append("Secure")

        if self.httponly:
            parts.append("HttpOnly")

        if self.samesite:
            parts.append(f"SameSite={self.samesite}")

        return "; ".join(parts)


class _ResponseCookies:
    """Response cookies 的 dict-like 代理 - 

    支持:
        response.cookies['key'] = 'value'
        del response.cookies['key']
        'key' in response.cookies
        response.cookies.get('key')
    """

    def __init__(self, response: "Response"):
        self._response = response

    def __setitem__(self, key: str, value: str):
        self._response.set_cookie(key, value)

    def __getitem__(self, key: str):
        if key in self._response._cookies:
            return self._response._cookies[key].value
        raise KeyError(key)

    def __delitem__(self, key: str):
        self._response.delete_cookie(key)

    def __contains__(self, key: str):
        return key in self._response._cookies

    def __iter__(self):
        return iter(self._response._cookies)

    def __len__(self):
        return len(self._response._cookies)

    def get(self, key: str, default: str = None):
        cookie = self._response._cookies.get(key)
        return cookie.value if cookie else default

    def keys(self):
        return self._response._cookies.keys()

    def values(self):
        return [c.value for c in self._response._cookies.values()]

    def items(self):
        return [(k, c.value) for k, c in self._response._cookies.items()]

    def __repr__(self):
        return f"ResponseCookies({dict(self.items())})"


class _CacheControl:
    """Cache-Control 便捷代理 - 属性式 API"""

    _BOOL_DIRECTIVES = frozenset({
        'no_cache', 'no_store', 'no_transform',
        'must_revalidate', 'proxy_revalidate', 'private', 'public',
    })
    _INT_DIRECTIVES = frozenset({'max_age', 's_maxage'})

    def __init__(self, headers):
        self._headers = headers

    def _parse(self):
        raw = self._headers.get('cache-control', '')
        result = {}
        for part in raw.split(','):
            part = part.strip()
            if not part:
                continue
            if '=' in part:
                key, val = part.split('=', 1)
                key = key.strip().lower().replace('-', '_')
                if key in self._INT_DIRECTIVES:
                    try:
                        result[key] = int(val.strip())
                    except ValueError:
                        result[key] = val.strip()
                else:
                    result[key] = val.strip()
            else:
                key = part.strip().lower().replace('-', '_')
                if key in self._BOOL_DIRECTIVES:
                    result[key] = True
        return result

    def _serialize(self, directives):
        parts = []
        for key, value in directives.items():
            attr_name = key.replace('_', '-')
            if key in self._BOOL_DIRECTIVES:
                if value:
                    parts.append(attr_name)
            elif value is not None:
                parts.append(f"{attr_name}={value}")
        self._headers['cache-control'] = ', '.join(parts) if parts else ''

    def __getattr__(self, name):
        if name.startswith('_'):
            return super().__getattribute__(name)
        directives = self._parse()
        return directives.get(name.replace('-', '_'))

    def __setattr__(self, name, value):
        if name.startswith('_'):
            super().__setattr__(name, value)
            return
        directives = self._parse()
        directives[name.replace('-', '_')] = value
        self._serialize(directives)

    def __repr__(self):
        return f"CacheControl({self._headers.get('cache-control', '')})"


class Response:
    """增强版响应对象 - Response实现"""
    __slots__ = (
        '_body', 'status', '_headers', '_content_type', '_cookies',
        '_streaming', '_stream_generator', 'background', '_frozen',
    )

    def __init__(
        self,
        body: Union[bytes, str] = None,
        status: int = 200,
        headers: Optional[Dict[str, str]] = None,
        content_type: str = "application/octet-stream",
        json: Any = None,
        **kwargs
    ):
        if json is not None and body is not None:
            raise TypeError("Response() cannot accept both 'body' and 'json' arguments")
        if json is not None:
            body = json
        # Allow status_code as an alias for status
        if 'status_code' in kwargs:
            status = kwargs.pop('status_code')
        if kwargs:
            raise TypeError(f"Response() got unexpected keyword arguments: {', '.join(kwargs.keys())}")
        actual_body = body if body is not None else b""
        if hasattr(actual_body, '__aiter__') or (hasattr(actual_body, '__iter__') and not isinstance(actual_body, (bytes, str, dict, list))):
            if hasattr(actual_body, '__aiter__'):
                self._streaming = True
                self._stream_generator = actual_body
                self._body = b''
                self.status: int = status
                self._headers: Headers = Headers()
                if headers:
                    if isinstance(headers, Headers):
                        self._headers = headers
                    else:
                        for k, v in headers.items():
                            self._headers[k] = v
                if 'content-type' not in self._headers:
                    self._headers['content-type'] = content_type
                self._content_type = self._headers.get('content-type', content_type)
                self._cookies: Dict[str, ResponseCookie] = {}
                self.background: Optional[BackgroundTasks] = None
                self._frozen: bool = False
                return
        auto_ct = None
        if isinstance(actual_body, (dict, list)):
            auto_ct = "application/json"
        elif isinstance(actual_body, str):
            auto_ct = "text/plain; charset=utf-8"
        else:
            bm = _get_pydantic_basemodel()
            if bm is not None and isinstance(actual_body, bm):
                auto_ct = "application/json"
        self._body: bytes = self._encode_body(actual_body)
        self.status: int = status
        self._headers: Headers = Headers()
        if headers:
            if isinstance(headers, Headers):
                self._headers = headers
            else:
                for k, v in headers.items():
                    self._headers[k] = v
        effective_ct = content_type
        if auto_ct and content_type == "application/octet-stream" and 'content-type' not in self._headers:
            effective_ct = auto_ct
        if 'content-type' not in self._headers:
            self._headers['content-type'] = effective_ct
        self._content_type = self._headers.get('content-type', content_type)
        self._cookies: Dict[str, ResponseCookie] = {}
        self._streaming: bool = False
        self._stream_generator: Optional[AsyncGenerator[bytes, None]] = None
        self.background: Optional[BackgroundTasks] = None
        self._frozen: bool = False
        self._update_content_length()

    @property
    def cookies(self):
        """Cookie dict-like 接口 - 

        使用示例:
            response.cookies['key'] = 'value'
            del response.cookies['key']
        """
        return _ResponseCookies(self)

    @cookies.setter
    def cookies(self, value):
        if isinstance(value, _ResponseCookies):
            self._cookies = value._response._cookies
        elif isinstance(value, dict):
            for k, v in value.items():
                self.set_cookie(k, str(v))

    def _update_content_length(self):
        if not self._streaming:
            self._headers['content-length'] = str(len(self._body))

    @property
    def content_type(self) -> str:
        return self._content_type

    @content_type.setter
    def content_type(self, value: str):
        self._content_type = value
        self._headers['content-type'] = value

    @property
    def headers(self) -> Headers:
        """大小写不敏感的响应头"""
        return self._headers

    @headers.setter
    def headers(self, value):
        if isinstance(value, Headers):
            self._headers = value
        elif value:
            self._headers = Headers(value)
        else:
            self._headers = Headers()

    def set_header(self, name: str, value: Any) -> "Response":
        """Set a response header using case-insensitive normalization."""
        if not name:
            raise ValueError("Header name cannot be empty")
        self._headers[name] = str(value)
        if name.lower() == "content-type":
            self._content_type = str(value)
        return self

    def get_header(self, name: str, default: Any = None) -> Any:
        """Case-insensitive response header lookup."""
        if not name:
            return default
        return self._headers.get(name, default)

    def has_header(self, name: str) -> bool:
        """Check if a response header has been set."""
        if not name:
            return False
        return name in self._headers

    def delete_header(self, name: str) -> "Response":
        """Remove a response header if present."""
        if not name:
            return self
        self._headers.pop(name, None)
        if name.lower() == "content-type":
            self._content_type = self._headers.get(
                "content-type",
                "application/octet-stream",
            )
        return self

    @property
    def status_code(self) -> int:
        """Compatibility alias for `status` attribute."""
        return self.status

    @status_code.setter
    def status_code(self, value: int):
        self.status = value

    @property
    def cache_control(self):
        """Cache-Control 便捷属性 - 

        使用示例:
            response.cache_control.no_cache = True
            response.cache_control.max_age = 3600
            response.cache_control.private = True
        """
        return _CacheControl(self._headers)

    @cache_control.setter
    def cache_control(self, value: str):
        if value:
            self._headers['cache-control'] = value
        else:
            self._headers.pop('cache-control', None)

    def set_etag(self, etag: str, weak: bool = False) -> "Response":
        """设置 ETag 头 — HTTP 缓存标准

        Args:
            etag: ETag 值（不含引号，方法会自动添加）
            weak: 是否为弱 ETag（W/"etag" 格式）

        Returns:
            self（支持链式调用）
        """
        if weak:
            self._headers['etag'] = f'W/"{etag}"'
        else:
            self._headers['etag'] = f'"{etag}"'
        return self

    def add_etag(self, overwrite: bool = False) -> "Response":
        if not overwrite and self._headers.get('etag'):
            return self
        import hashlib
        body = self._body if isinstance(self._body, bytes) else b''
        etag = hashlib.md5(body).hexdigest()
        self._headers['etag'] = f'"{etag}"'
        return self

    def make_conditional(
        self,
        request_headers,
    ) -> "Response":
        if request_headers is not None and not isinstance(request_headers, dict):
            if hasattr(request_headers, 'headers'):
                request_headers = {k.lower(): v for k, v in request_headers.headers.items()}
            else:
                request_headers = {}
        elif isinstance(request_headers, dict):
            request_headers = {k.lower(): v for k, v in request_headers.items()}

        etag = self._headers.get('etag', '')
        last_modified = self._headers.get('last-modified', '')

        if_none_match = request_headers.get('if-none-match', '') if request_headers else ''
        if_modified_since = request_headers.get('if-modified-since', '') if request_headers else ''
        if_match = request_headers.get('if-match', '') if request_headers else ''
        if_unmodified_since = request_headers.get('if-unmodified-since', '') if request_headers else ''

        not_modified = False
        precondition_failed = False

        def _strip_etag(s: str) -> str:
            s = s.strip()
            if s.startswith('W/'):
                s = s[2:]
            if s.startswith('"') and s.endswith('"'):
                s = s[1:-1]
            return s

        if if_none_match and etag:
            server_etag_raw = _strip_etag(etag)
            for client_etag in if_none_match.split(','):
                client_etag = client_etag.strip()
                if client_etag == '*':
                    not_modified = True
                    break
                if _strip_etag(client_etag) == server_etag_raw:
                    not_modified = True
                    break

        if if_modified_since and last_modified and not not_modified:
            try:
                from email.utils import parsedate_to_datetime
                since_dt = parsedate_to_datetime(if_modified_since)
                from email.utils import parsedate_to_datetime as _parse
                lm_dt = parsedate_to_datetime(last_modified)
                if lm_dt.timestamp() <= since_dt.timestamp():
                    not_modified = True
            except (ValueError, TypeError):
                if if_modified_since == last_modified:
                    not_modified = True

        if if_match and etag:
            matched = False
            server_etag_raw = _strip_etag(etag)
            for client_etag in if_match.split(','):
                client_etag = client_etag.strip()
                if client_etag == '*':
                    matched = True
                    break
                if _strip_etag(client_etag) == server_etag_raw:
                    matched = True
                    break
            if not matched:
                precondition_failed = True

        if if_unmodified_since and last_modified and not precondition_failed:
            try:
                from email.utils import parsedate_to_datetime
                since_dt = parsedate_to_datetime(if_unmodified_since)
                lm_dt = parsedate_to_datetime(last_modified)
                if lm_dt.timestamp() > since_dt.timestamp():
                    precondition_failed = True
            except (ValueError, TypeError):
                pass

        if precondition_failed:
            self.status = 412
            self._body = b''
            self._headers.pop('content-length', None)
        elif not_modified:
            self.status = 304
            self._body = b''
            self._headers.pop('content-length', None)

        return self

    def init_headers(self, headers: Optional[Dict[str, str]] = None) -> None:
        """初始化/重置响应头"""
        if headers:
            for k, v in headers.items():
                self._headers[k] = v
        if 'content-type' not in self._headers:
            self._headers['content-type'] = self._content_type

    @staticmethod
    def _encode_body(body: Union[bytes, str, dict, list, None]) -> bytes:
        if body is None:
            return b''
        if isinstance(body, bytes):
            return body
        if isinstance(body, str):
            return body.encode('utf-8')
        if isinstance(body, (dict, list, int, float, bool)):
            return _json.dumpsb(body)
        serialized = _serialize_pydantic(body)
        if serialized is not body:
            return _json.dumpsb(serialized)
        raise TypeError(f"Response body must be bytes, str, dict, list, int, float, bool or None, got {type(body).__name__}")

    @property
    def body(self) -> bytes:
        return self._body

    @body.setter
    def body(self, value: Union[bytes, str, dict, list]):
        self._body = self._encode_body(value)
        self._update_content_length()

    @property
    def content_length(self) -> Optional[int]:
        """响应体长度 """
        cl = self._headers.get('content-length')
        if cl is not None:
            try:
                return int(cl)
            except (ValueError, TypeError):
                pass
        return len(self._body) if self._body else None

    @content_length.setter
    def content_length(self, value: Optional[int]):
        if value is not None:
            self._headers['content-length'] = str(value)
        else:
            self._headers.pop('content-length', None)

    @property
    def etag(self) -> Optional[str]:
        """ETag 值 getter 

        返回不含引号和 W/ 前缀的 ETag 值，不存在时返回 None。
        """
        raw = self._headers.get('etag', '')
        if not raw:
            return None
        etag = raw.strip()
        if etag.startswith('W/'):
            etag = etag[2:]
        etag = etag.strip('"')
        return etag or None

    @property
    def vary(self) -> List[str]:
        """Vary 头解析 

        返回 Vary 头中的字段名列表。
        """
        header = self._headers.get('vary', '')
        if not header:
            return []
        return [v.strip() for v in header.split(',') if v.strip()]

    @vary.setter
    def vary(self, value: Union[str, List[str]]):
        if isinstance(value, list):
            self._headers['vary'] = ', '.join(value)
        elif value:
            self._headers['vary'] = str(value)
        else:
            self._headers.pop('vary', None)

    @property
    def expires(self) -> Optional[datetime]:
        """Expires 头解析 

        返回 datetime 对象（UTC），不存在时返回 None。
        """
        header = self._headers.get('expires', '')
        if not header:
            return None
        try:
            from email.utils import parsedate_to_datetime
            return parsedate_to_datetime(header)
        except (ValueError, TypeError):
            return None

    @expires.setter
    def expires(self, value: Optional[datetime]):
        if value is not None:
            self._headers['expires'] = formatdate(
                timeval=value.timestamp(), localtime=False, usegmt=True
            )
        else:
            self._headers.pop('expires', None)

    @property
    def last_modified(self) -> Optional[datetime]:
        """Last-Modified 头解析 

        返回 datetime 对象（UTC），不存在时返回 None。
        """
        header = self._headers.get('last-modified', '')
        if not header:
            return None
        try:
            from email.utils import parsedate_to_datetime
            return parsedate_to_datetime(header)
        except (ValueError, TypeError):
            return None

    @last_modified.setter
    def last_modified(self, value: Optional[datetime]):
        if value is not None:
            self._headers['last-modified'] = formatdate(
                timeval=value.timestamp(), localtime=False, usegmt=True
            )
        else:
            self._headers.pop('last-modified', None)

    @property
    def www_authenticate(self) -> Optional[str]:
        return self._headers.get('www-authenticate')

    @www_authenticate.setter
    def www_authenticate(self, value):
        if value is not None:
            self._headers['www-authenticate'] = str(value)
        else:
            self._headers.pop('www-authenticate', None)

    @property
    def retry_after(self) -> Optional[str]:
        return self._headers.get('retry-after')

    @retry_after.setter
    def retry_after(self, value):
        if value is not None:
            self._headers['retry-after'] = str(value)
        else:
            self._headers.pop('retry-after', None)

    async def _consume_async_generator(self, gen):
        parts = []
        async for chunk in gen:
            if isinstance(chunk, str):
                chunk = chunk.encode('utf-8')
            if chunk:
                parts.append(chunk)
        return parts

    def freeze(self) -> "Response":
        """冻结响应

        将响应标记为不可变，消费流式生成器并缓存结果，
        确保 content-length 正确设置。用于缓存场景。
        """
        if self._streaming and hasattr(self, '_stream_generator') and self._stream_generator is not None:
            parts = []
            try:
                import asyncio
                gen = self._stream_generator
                if hasattr(gen, '__aiter__'):
                    try:
                        loop = asyncio.get_event_loop()
                        if loop.is_running():
                            import concurrent.futures
                            with concurrent.futures.ThreadPoolExecutor() as executor:
                                future = executor.submit(
                                    asyncio.run,
                                    self._consume_async_generator(gen)
                                )
                                parts = future.result(timeout=30)
                        else:
                            parts = loop.run_until_complete(self._consume_async_generator(gen))
                    except RuntimeError:
                        parts = asyncio.run(self._consume_async_generator(gen))
                else:
                    for chunk in gen:
                        if isinstance(chunk, str):
                            chunk = chunk.encode('utf-8')
                        if chunk:
                            parts.append(chunk)
            except Exception as e:
                logger.warning(f"Error consuming stream generator: {e}")
                self._body = b''.join(parts)
            self._streaming = False
            self._stream_generator = None
        if self._body is not None and not self._headers.get('content-length'):
            self._headers['content-length'] = str(len(self._body))
        self._frozen = True
        return self

    @property
    def is_frozen(self) -> bool:
        return self._frozen

    def get_asgi_headers(self) -> list:
        """获取 ASGI 格式的响应头列表

        返回 [(name_bytes, value_bytes), ...] 格式的头部列表，
        包含 Set-Cookie 头。用于中间件和测试场景。
        """
        headers = []
        for key in self._headers:
            value = self._headers[key]
            safe_key = str(key).replace('\r', '').replace('\n', '').encode('utf-8')
            safe_value = str(value).replace('\r', '').replace('\n', '').encode('utf-8')
            headers.append((safe_key, safe_value))
        for cookie_header in self.get_cookie_headers():
            if isinstance(cookie_header, tuple):
                headers.append((str(cookie_header[0]).encode('utf-8'), str(cookie_header[1]).encode('utf-8')))
            else:
                parts = str(cookie_header).split('=', 1)
                if len(parts) == 2:
                    headers.append((b'set-cookie', str(cookie_header).replace('\r', '').replace('\n', '').encode('utf-8')))
        return headers
    
    def set_cookie(
        self,
        key: str,
        value: str = "",
        *,
        max_age: Optional[int] = None,
        expires: Optional[datetime] = None,
        path: str = "/",
        domain: Optional[str] = None,
        secure: bool = False,
        httponly: bool = False,
        samesite: str = "Lax"
    ) -> "Response":
        self._cookies[key] = ResponseCookie(
            name=key,
            value=value,
            expires=expires,
            max_age=max_age,
            domain=domain,
            path=path,
            secure=secure,
            httponly=httponly,
            samesite=samesite
        )
        return self

    def delete_cookie(
        self,
        key: str,
        *,
        path: str = "/",
        domain: Optional[str] = None,
        secure: bool = True,
        httponly: bool = True,
        samesite: str = "Lax"
    ) -> "Response":
        self._cookies[key] = ResponseCookie(
            name=key,
            value="",
            expires=datetime(1970, 1, 1, tzinfo=timezone.utc),
            max_age=0,
            domain=domain,
            path=path,
            secure=secure,
            httponly=httponly,
            samesite=samesite
        )
        return self
    
    def get_cookie_headers(self) -> List[tuple]:
        headers = []
        for cookie in self._cookies.values():
            headers.append(('set-cookie', cookie.to_header()))
        return headers
    
    async def __call__(self, scope, receive, send):
        """ASGI接口 - 使Response可直接作为ASGI应用使用

        Response.__call__实现，支持：
        - 发送HTTP响应
        - 流式响应
        - 响应后自动执行BackgroundTasks
        """
        headers = []
        header_keys = set()
        for key, value in self._headers.rawItems() if hasattr(self._headers, 'rawItems') else self._headers.items():
            safe_key = key.replace('\r', '').replace('\n', '').encode('utf-8')
            safe_value = str(value).replace('\r', '').replace('\n', '').encode('utf-8')
            safe_key = bytes([b for b in safe_key if b >= 0x20 or b == 0x09])
            safe_value = bytes([b for b in safe_value if b >= 0x20 or b == 0x09])
            headers.append((safe_key, safe_value))
            header_keys.add(key.lower().encode('utf-8') if isinstance(key, str) else key.lower())

        for name, value in self.get_cookie_headers():
            headers.append((name.encode('utf-8'), value.encode('utf-8')))

        if b'content-type' not in header_keys:
            headers.append((b'content-type', self.content_type.encode('utf-8')))

        if self.is_streaming and self._stream_generator:
            await send({
                'type': 'http.response.start',
                'status': self.status,
                'headers': headers
            })
            try:
                async for chunk in self._stream_generator:
                    await send({
                        'type': 'http.response.body',
                        'body': chunk,
                        'more_body': True
                    })
            except Exception as e:
                logger.error(f"Streaming response error in ASGI __call__: {e}")
            finally:
                if hasattr(self._stream_generator, 'aclose'):
                    await self._stream_generator.aclose()

            try:
                await send({
                    'type': 'http.response.body',
                    'body': b'',
                    'more_body': False
                })
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)
        else:
            body = self._body if isinstance(self._body, bytes) else self._body.encode('utf-8')
            if b'content-length' not in header_keys:
                headers.append((b'content-length', str(len(body)).encode('utf-8')))

            await send({
                'type': 'http.response.start',
                'status': self.status,
                'headers': headers
            })
            await send({
                'type': 'http.response.body',
                'body': body,
                'more_body': False
            })

        if self.background:
            try:
                loop = asyncio.get_running_loop()
                task = loop.create_task(self.background.run())
                task.add_done_callback(_background_task_error_callback)
            except RuntimeError:
                await self.background.run()
    
    @property
    def is_streaming(self) -> bool:
        """是否为流式响应"""
        return self._streaming

    @property
    def stream_generator(self) -> Optional[AsyncGenerator[bytes, None]]:
        """获取流式响应生成器"""
        return self._stream_generator


def raw(body: bytes, status: int = 200, headers: Optional[Dict[str, str]] = None,
        content_type: str = "application/octet-stream") -> Response:
    """创建原始字节响应 — 原始字节响应

    不进行任何编码，直接返回原始字节。
    """
    return Response(body=body, status=status, headers=headers, content_type=content_type)


def empty(status: int = 204, headers: Optional[Dict[str, str]] = None) -> Response:
    """创建空响应 — 空响应

    默认返回 204 No Content。
    """
    return Response(status=status, headers=headers)


def redirect(url: str, status: int = 302, headers: Optional[Dict[str, str]] = None) -> Response:
    resp = RedirectResponse(url, status=status)
    if headers:
        for k, v in headers.items():
            resp._headers[k.lower()] = v
    return resp


async def file(
    path: str,
    filename: str = None,
    mime_type: str = None,
    attachment: bool = False,
    base_dir: Optional[str] = None
) -> Response:
    return send_file(path, filename=filename, mime_type=mime_type, attachment=attachment, base_dir=base_dir)


class JSONResponse(Response):

    def __init__(self, body: Any = None, status: int = 200, headers: Optional[Dict[str, str]] = None, *, ensure_ascii: bool = False, indent: Optional[int] = None):
        if body is not None:
            if isinstance(body, (dict, list, int, float, bool, str)):
                json_body = _json.dumpsb(body, ensure_ascii=ensure_ascii, indent=indent)
            else:
                serialized = _serialize_pydantic(body)
                json_body = _json.dumpsb(serialized, ensure_ascii=ensure_ascii, indent=indent)
        else:
            json_body = b'null'
        super().__init__(body=json_body, status=status, headers=headers, content_type="application/json")


class HTMLResponse(Response):

    def __init__(self, body: str = "", status: int = 200, headers: Optional[Dict[str, str]] = None):
        super().__init__(body=body, status=status, headers=headers, content_type="text/html; charset=utf-8")


class PlainTextResponse(Response):

    def __init__(self, body: str = "", status: int = 200, headers: Optional[Dict[str, str]] = None):
        super().__init__(body=body, status=status, headers=headers, content_type="text/plain; charset=utf-8")


def json(data: Any, status: int = 200, headers: Optional[Dict[str, str]] = None) -> JSONResponse:
    resp = JSONResponse(body=data, status=status)
    if headers:
        for k, v in headers.items():
            resp._headers[k] = v
    return resp


def text(text_str: str, status: int = 200, headers: Optional[Dict[str, str]] = None) -> PlainTextResponse:
    resp = PlainTextResponse(body=text_str, status=status)
    if headers:
        for k, v in headers.items():
            resp._headers[k] = v
    return resp


def html(html_str: str, status: int = 200, headers: Optional[Dict[str, str]] = None) -> HTMLResponse:
    resp = HTMLResponse(body=html_str, status=status)
    if headers:
        for k, v in headers.items():
            resp._headers[k] = v
    return resp


class RedirectResponse(Response):

    def __init__(self, url: str, status: int = 302, headers: Optional[Dict[str, str]] = None,
                 allowed_hosts: Optional[list] = None):
        if url.startswith(('javascript:', 'data:', 'vbscript:')):
            raise ValueError(f"Redirect to unsafe protocol not allowed: {url.split(':')[0]}:")
        if url.startswith(('http://', 'https://', '//')):
            from urllib.parse import urlparse
            parsed = urlparse(url)
            if allowed_hosts is not None and parsed.hostname not in allowed_hosts:
                raise ValueError(f"Redirect to external host not allowed: {parsed.hostname}")
        super().__init__(status=status, headers=headers, content_type="text/plain; charset=utf-8")
        self.set_header("location", url)
        self._body = b''
        self._headers.pop('content-length', None)


class FileResponse(Response):

    def __init__(
        self,
        path: str,
        status: int = 200,
        headers: Optional[Dict[str, str]] = None,
        content_type: Optional[str] = None,
        filename: Optional[str] = None,
        chunk_size: int = 64 * 1024,
        request_headers: Optional[Dict[str, str]] = None,
        base_dir: Optional[str] = None,
        stat_result: Optional[os.stat_result] = None,
    ):
        super().__init__(status=status, headers=headers)
        self._file_path = os.path.realpath(path)
        self._chunk_size = chunk_size
        self._range_start = 0
        self._range_end = None
        self._file_size = 0
        self._stat_result = stat_result

        if base_dir:
            safe_dir = os.path.realpath(base_dir)
            if not self._file_path.startswith(safe_dir + os.sep) and self._file_path != safe_dir:
                self.status = 403
                self._body = b"Forbidden"
                self.content_type = "text/plain"
                return

        if content_type:
            self.content_type = content_type
        else:
            self.content_type = mimetypes.guess_type(path)[0] or "application/octet-stream"

        if stat_result is not None:
            stat = stat_result
        else:
            if not os.path.isfile(self._file_path):
                self.status = 404
                self._body = b"File not found"
                self.content_type = "text/plain"
                return
            stat = os.stat(self._file_path)

        self._file_size = stat.st_size
        self.headers['content-length'] = str(stat.st_size)
        self.headers['accept-ranges'] = 'bytes'

        import time
        from datetime import timezone
        last_modified = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)
        self.headers['last-modified'] = formatdate(timeval=stat.st_mtime, localtime=False, usegmt=True)

        etag = f'"{stat.st_mtime_ns:x}-{stat.st_size:x}"'
        self.headers['etag'] = etag

        if filename:
            try:
                encoded_name = urllib.parse.quote(filename, safe='')
                self.headers['content-disposition'] = f"attachment; filename=\"{filename}\"; filename*=UTF-8''{encoded_name}"
            except Exception:
                self.headers['content-disposition'] = f'attachment; filename="{filename}"'

        if request_headers:
            if self._check_conditional_request(request_headers, etag, last_modified):
                self.status = 304
                self._body = b''
                self._streaming = False
                return

            range_header = request_headers.get('range', '')
            if range_header:
                self._parse_range(range_header)
                if self.status == 416:
                    return

        self._streaming = True
        self._stream_generator = self._file_stream()
        self._body = b''

    def _check_conditional_request(self, request_headers: Dict[str, str], etag: str, last_modified: datetime) -> bool:
        """检查条件请求 (If-None-Match / If-Modified-Since)"""
        if_none_match = request_headers.get('if-none-match', '')
        if if_none_match:
            for match_etag in if_none_match.split(','):
                match_etag = match_etag.strip()
                if match_etag == etag or match_etag == '*':
                    return True

        if_modified_since = request_headers.get('if-modified-since', '')
        if if_modified_since and not if_none_match:
            try:
                from email.utils import parsedate_to_datetime
                since = parsedate_to_datetime(if_modified_since)
                if last_modified.timestamp() <= since.timestamp():
                    return True
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)

        return False

    def _parse_range(self, range_header: str):
        """解析 Range 头，支持断点续传"""
        if not range_header.startswith('bytes='):
            return

        range_spec = range_header[6:]
        try:
            if range_spec.startswith('-'):
                suffix_length = int(range_spec[1:])
                self._range_start = max(0, self._file_size - suffix_length)
                self._range_end = self._file_size - 1
            elif range_spec.endswith('-'):
                self._range_start = int(range_spec[:-1])
                self._range_end = self._file_size - 1
            else:
                parts = range_spec.split('-')
                self._range_start = int(parts[0])
                self._range_end = int(parts[1])

            if self._range_start >= self._file_size:
                self.status = 416
                self.headers['content-range'] = f'bytes */{self._file_size}'
                self._body = b'Range Not Satisfiable'
                self._streaming = False
                return

            if self._range_start > self._range_end:
                self.status = 416
                self.headers['content-range'] = f'bytes */{self._file_size}'
                self._body = b'Range Not Satisfiable'
                self._streaming = False
                return

            self._range_end = min(self._range_end, self._file_size - 1)
            content_length = self._range_end - self._range_start + 1

            self.status = 206
            self.headers['content-range'] = f'bytes {self._range_start}-{self._range_end}/{self._file_size}'
            self.headers['content-length'] = str(content_length)
        except (ValueError, IndexError):
            pass

    async def _file_stream(self) -> AsyncGenerator[bytes, None]:
        loop = asyncio.get_running_loop()
        try:
            f = await loop.run_in_executor(None, lambda: open(self._file_path, 'rb'))
        except FileNotFoundError:
            self.status = 404
            self._body = b'File not found'
            yield b'File not found'
            return
        except PermissionError:
            self.status = 403
            self._body = b'Access denied'
            yield b'Access denied'
            return
        try:
            if self._range_start > 0:
                await loop.run_in_executor(None, f.seek, self._range_start)
            
            remaining = (self._range_end - self._range_start + 1) if self._range_end is not None else self._file_size
            
            while remaining > 0:
                read_size = min(self._chunk_size, remaining)
                chunk = await loop.run_in_executor(None, f.read, read_size)
                if not chunk:
                    break
                remaining -= len(chunk)
                yield chunk
        finally:
            await loop.run_in_executor(None, f.close)


def send_file(path: str, filename: str = None, mime_type: str = None,
              attachment: bool = False, base_dir: Optional[str] = None,
              **kwargs) -> 'FileResponse':
    """创建文件响应 — 支持 Range/ETag/Last-Modified/条件请求

    委托给 FileResponse，开箱即用支持：
    - 自动 ETag 生成
    - Last-Modified 头
    - If-None-Match / If-Modified-Since 条件请求 (304)
    - Range 请求 (断点续传)
    - Content-Type 自动检测
    """
    fr_kwargs = {}
    if filename:
        fr_kwargs['filename'] = filename
    if mime_type:
        fr_kwargs['content_type'] = mime_type
    if base_dir:
        fr_kwargs['base_dir'] = base_dir
    fr_kwargs.update(kwargs)
    return FileResponse(path=path, **fr_kwargs)


class ServerSentEvent:
    """Server-Sent Event 格式化器 - """

    def __init__(
        self,
        data: Optional[str] = None,
        event: Optional[str] = None,
        id: Optional[str] = None,
        retry: Optional[int] = None,
        comment: Optional[str] = None,
    ):
        self.data = data
        self.event = event
        self.id = id
        self.retry = retry
        self.comment = comment

    def encode(self) -> bytes:
        parts = []
        if self.comment is not None:
            parts.append(f": {self.comment}\n")
        if self.event is not None:
            parts.append(f"event: {self.event}\n")
        if self.data is not None:
            for line in self.data.splitlines():
                parts.append(f"data: {line}\n")
        if self.id is not None:
            parts.append(f"id: {self.id}\n")
        if self.retry is not None:
            parts.append(f"retry: {self.retry}\n")
        parts.append("\n")
        return "".join(parts).encode("utf-8")


class PaginatedResponse:
    """通用分页响应构建器 — 委托给 kewe.utils.pagination.PaginatedResponse"""

    def __init__(
        self,
        items: List[Any],
        total: int,
        page: int = 1,
        per_page: int = 20,
        page_size: int = None,
        *,
        page_key: str = "page",
        per_page_key: str = "per_page",
    ):
        from kewe.utils.pagination import PaginatedResponse as _PaginatedResponse
        actual_per_page = page_size if page_size is not None else per_page
        self._inner = _PaginatedResponse(
            items=items,
            total=total,
            page=max(1, page),
            per_page=max(1, min(actual_per_page, 100)),
        )
        self.items = self._inner.items
        self.total = self._inner.total
        self.page = self._inner.page
        self.per_page = self._inner.per_page
        self.pages = self._inner.pages
        self.has_next = self._inner.has_next
        self.has_prev = self._inner.has_prev

    @classmethod
    def from_request(
        cls,
        request: Any,
        items: List[Any],
        total: int,
        *,
        default_per_page: int = 20,
        max_per_page: int = 100,
        page_key: str = "page",
        per_page_key: str = "per_page",
    ) -> "PaginatedResponse":
        page = int(request.query_params.get(page_key, "1"))
        per_page = int(request.query_params.get(per_page_key, str(default_per_page)))
        per_page = min(per_page, max_per_page)
        return cls(items, total, page, per_page, page_key=page_key, per_page_key=per_page_key)

    def to_dict(self) -> Dict[str, Any]:
        return self._inner.to_dict()

    def to_response(self, status: int = 200) -> Response:
        return json(self.to_dict(), status=status)
