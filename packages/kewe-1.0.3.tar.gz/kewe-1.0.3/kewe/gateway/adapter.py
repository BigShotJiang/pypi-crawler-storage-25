#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Gateway adapter for integrating the API gateway with a Kewe app.
"""

import logging
from typing import TYPE_CHECKING

from kewe.gateway.core import ErrorCode, get_api_gateway
from kewe.request import Request
from kewe.response import Response, json

if TYPE_CHECKING:
    from kewe.app import Kewe

logger = logging.getLogger(__name__)


class GatewayAdapter:
    def __init__(self, app, prefix: str = ""):
        self.app = app
        self.prefix = prefix.rstrip("/")
        self.gateway = get_api_gateway()
        if not self.gateway._app:
            self.gateway.bind_app(app, prefix=self.prefix)
        self._register_routes()

    def _register_routes(self):
        """Register gateway routes onto the Kewe app."""
        if not self.prefix:
            logger.info("Gateway adapter skipped route registration (no prefix configured)")
            return

        @self.app.route(
            f"{self.prefix}/<path:path>",
            methods=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"],
        )
        async def handle_api(request: Request):
            return await self._handle_request(request)

        @self.app.route(f"{self.prefix}", methods=["GET"])
        async def handle_api_root(request: Request):
            return await self._handle_request(request)

        logger.info(f"Gateway adapter registered with prefix: {self.prefix}")

    async def _handle_request(self, request: Request) -> Response:
        """Build a gateway request payload and dispatch it."""
        json_body = await request.json_async
        body_bytes = await request.body
        body_payload = json_body
        if body_payload is None and body_bytes:
            body_payload = body_bytes.decode("utf-8", errors="surrogateescape")

        raw_request = {
            "path": request.path,
            "method": request.method,
            "headers": dict(request.headers),
            "query_params": {
                key: values[0] if len(values) == 1 else values
                for key, values in request.query_params.items_raw()
            },
            "body": body_payload,
            "client_ip": request.client_ip,
            "user_agent": request.headers.get("user-agent", ""),
            "api_version": "v1",
        }

        try:
            response_data = await self.gateway.handle_request(raw_request)

            status_code = 200 if response_data.get("success", True) else 400
            if response_data.get("code", 0) != 0:
                error_code = response_data.get("code", 0)
                if error_code == ErrorCode.NOT_FOUND.code:
                    status_code = 404
                elif error_code == ErrorCode.UNAUTHORIZED.code:
                    status_code = 401
                elif error_code == ErrorCode.FORBIDDEN.code:
                    status_code = 403
                elif error_code == ErrorCode.RATE_LIMITED.code:
                    status_code = 429
                elif error_code >= 1000:
                    status_code = 400

            response = json(response_data, status=status_code)
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "DENY"
            response.headers["X-XSS-Protection"] = "1; mode=block"
            return response
        except Exception as e:
            logger.error(f"Gateway adapter error: {e}")
            return json(
                {
                    "success": False,
                    "code": ErrorCode.SERVER_ERROR.code,
                    "message": "Internal Server Error",
                    "error": str(e),
                },
                status=500,
            )

    def register_gateway_route(self, path: str, method: str = "GET", **kwargs):
        """Register a gateway route."""

        def decorator(func):
            full_path = f"{self.prefix}{path}"
            self.gateway.route(full_path, method=method, **kwargs)(func)
            logger.info(f"Registered gateway route: {method} {full_path}")
            return func

        return decorator

    def add_global_middleware(self, middleware):
        """Register a global gateway middleware."""
        self.gateway.add_global_middleware(middleware)


def setup_gateway(app, prefix: str = "") -> GatewayAdapter:
    """Create and register a gateway adapter for an app."""
    return GatewayAdapter(app, prefix)


def register_gateway_route(app, gateway, prefix: str = ""):
    """Register gateway routes to the application"""
    adapter = GatewayAdapter(app, prefix)
    adapter._register_routes()
    return adapter
