#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""

API网关模块 - 与蓝图路由深度集成
网关路由共享主Router路由表，认证/限流转为路由级中间件
"""

from kewe.utils.compat import json
import logging
import re
import asyncio
import time
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, Tuple, TYPE_CHECKING

from kewe.request import Request
from kewe.response import Response, json as json_response
from kewe.errors.exceptions import KeweException

if TYPE_CHECKING:
    from kewe.routing.router import Router

logger = logging.getLogger(__name__)


class ErrorCode(Enum):
    SUCCESS = (0, "成功")
    UNKNOWN_ERROR = (1000, "未知错误")
    INVALID_REQUEST = (1001, "无效请求")
    UNAUTHORIZED = (1002, "未授权")
    FORBIDDEN = (1003, "禁止访问")
    NOT_FOUND = (1004, "资源不存在")
    METHOD_NOT_ALLOWED = (1005, "方法不允许")
    RATE_LIMITED = (1006, "请求过于频繁")
    SERVER_ERROR = (1007, "服务器内部错误")
    SERVICE_UNAVAILABLE = (1008, "服务不可用")
    TIMEOUT = (1009, "请求超时")
    VALIDATION_ERROR = (1010, "数据验证失败")

    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message


@dataclass
class GatewayRequest:
    request_id: str
    path: str
    method: str
    headers: Dict[str, str] = field(default_factory=dict)
    query_params: Dict[str, Any] = field(default_factory=dict)
    body: Any = None
    client_ip: str = ""
    user_agent: str = ""
    timestamp: datetime = field(default_factory=datetime.now)
    api_version: str = "v1"
    user_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def json(self):
        if isinstance(self.body, dict):
            return self.body
        if isinstance(self.body, str):
            try:
                return json.loads(self.body)
            except json.JSONDecodeError:
                return None
        return None


@dataclass
class GatewayResponse:
    request_id: str
    success: bool
    code: int
    message: str
    data: Any = None
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    status: int = 200

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "success": self.success,
            "code": self.code,
            "message": self.message,
            "data": self.data,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
        }


@dataclass
class GatewayRoute:
    path: str
    method: str
    handler: Callable
    version: str = "v1"
    middlewares: List[Callable] = field(default_factory=list)
    require_auth: bool = True
    rate_limit: Optional[Tuple[int, int]] = None
    description: str = ""
    path_regex: Optional[re.Pattern] = None
    param_names: List[str] = field(default_factory=list)
    namespace: Optional[str] = None


class GatewayError(KeweException):
    error_code_attr = "GATEWAY_ERROR"

    _CODE_TO_HTTP_STATUS = {
        0: 200, 1000: 500, 1001: 400, 1002: 401, 1003: 403,
        1004: 404, 1005: 405, 1006: 429, 1007: 500, 1008: 503,
        1009: 504, 1010: 422,
    }

    def __init__(self, error_code: ErrorCode, message: str = None, details: Dict[str, Any] = None):
        self.gateway_error_code = error_code
        self.details = details or {}
        http_status = self._CODE_TO_HTTP_STATUS.get(error_code.code, 500)
        super().__init__(
            message=message or error_code.message,
            status_code=http_status,
            error_code=f"GATEWAY_{error_code.name}",
        )


class GatewayTrieNode:
    def __init__(self):
        self.children: Dict[str, "GatewayTrieNode"] = {}
        self.route: Optional[GatewayRoute] = None
        self.param_name: Optional[str] = None
        self.is_param: bool = False


class TrieRouter:
    def __init__(self):
        self.root = GatewayTrieNode()
        self._routes: Dict[str, GatewayRoute] = {}
        self._lock = asyncio.Lock()

    def add_route(self, route: GatewayRoute) -> None:
        if "{" in route.path:
            regex_pattern = re.sub(r"\{(\w+)\}", r"([^/]+)", route.path)
            route.path_regex = re.compile(f"^{regex_pattern}$")
            route.param_names = re.findall(r"\{(\w+)\}", route.path)

        parts = route.path.strip("/").split("/")
        node = self.root

        for part in parts:
            if part.startswith("{") and part.endswith("}"):
                param_name = part[1:-1]
                if "*" not in node.children:
                    param_node = GatewayTrieNode()
                    param_node.is_param = True
                    param_node.param_name = param_name
                    node.children["*"] = param_node
                else:
                    existing_param = node.children["*"].param_name
                    if existing_param != param_name:
                        logger.warning(
                            f"路由参数冲突: 路径段 '{{{param_name}}}' 与已有参数 '{{{existing_param}}}' "
                            f"在同一层级，参数名将被覆盖为 '{{{param_name}}}'"
                        )
                        node.children["*"].param_name = param_name
                node = node.children["*"]
            else:
                if part not in node.children:
                    node.children[part] = GatewayTrieNode()
                node = node.children[part]

        route_key = f"{route.method.upper()}:{route.version}:{route.path}"
        self._routes[route_key] = route
        node.route = route

    def match(self, path: str, method: str, version: str) -> Optional[Tuple[GatewayRoute, Dict[str, str]]]:
        route_key = f"{method.upper()}:{version}:{path}"

        if route_key in self._routes:
            return self._routes[route_key], {}

        parts = path.strip("/").split("/")
        node = self.root
        params = {}

        for part in parts:
            if part in node.children:
                node = node.children[part]
            elif "*" in node.children:
                param_node = node.children["*"]
                params[param_node.param_name] = part
                node = param_node
            else:
                return None

        if node.route:
            if node.route.method.upper() == method.upper() and node.route.version == version:
                return node.route, params

        for key, route in self._routes.items():
            if route.method.upper() == method.upper() and route.version == version:
                if "{" in route.path and route.path_regex:
                    match = route.path_regex.match(path)
                    if match:
                        regex_params = dict(zip(route.param_names, match.groups()))
                        return route, regex_params

        return None

    def get_routes(self) -> List[GatewayRoute]:
        return list(self._routes.values())

    def clear(self):
        self.root = GatewayTrieNode()
        self._routes.clear()


class APIGateway:

    def __init__(self):
        self._router = TrieRouter()
        self._global_middlewares: List[Callable] = []
        self._error_handlers: Dict[ErrorCode, Callable] = {}

        self._route_cache: OrderedDict[str, Tuple[GatewayRoute, Dict[str, str]]] = OrderedDict()
        self._cache_size = 1000
        self._cache_lock = asyncio.Lock()

        self._rate_limit_store: Dict[str, Tuple[int, float]] = {}
        self._rate_limit_lock = asyncio.Lock()

        self._jwt_manager = None
        self._jwt_secret: Optional[str] = None

        self._app = None
        self._main_router: Optional["Router"] = None
        self._gateway_prefix: str = ""

        self._register_default_error_handlers()

    def bind_app(self, app, prefix: str = ""):
        self._app = app
        self._main_router = app.router
        self._gateway_prefix = prefix.rstrip("/")
        self._sync_routes_to_main_router()
        self._register_health_endpoint(app)

    def _sync_routes_to_main_router(self):
        if not self._main_router or not self._app:
            return

        for gw_route in self._router.get_routes():
            self._register_gateway_route_to_main_router(gw_route)

    def _register_gateway_route_to_main_router(self, gw_route: GatewayRoute):
        if not self._main_router or not self._app:
            return

        full_path = gw_route.path
        if not full_path.startswith('/'):
            full_path = f'/{full_path}'

        if gw_route.version and gw_route.version != "v1":
            full_path = f"/{gw_route.version}{full_path}"

        if not full_path.startswith(self._gateway_prefix):
            full_path = f"{self._gateway_prefix}{full_path}"

        gateway_middlewares = self._build_gateway_middlewares(gw_route)

        original_handler = gw_route.handler

        @wraps(original_handler)
        async def gateway_wrapped_handler(request: Request, **kwargs):
            return await self._dispatch_to_handler(original_handler, request, gw_route, **kwargs)

        self._main_router.add_route(
            path=full_path,
            methods=[gw_route.method.upper()],
            handler=gateway_wrapped_handler,
            middlewares=gateway_middlewares,
            name=gw_route.namespace or f"gateway:{gw_route.method}:{gw_route.path}",
        )

        logger.debug(f"Synced gateway route to main router: {gw_route.method} {full_path}")

    def _build_gateway_middlewares(self, gw_route: GatewayRoute) -> List[Callable]:
        middlewares = []

        if gw_route.require_auth:
            middlewares.append(self._create_auth_middleware())

        if gw_route.rate_limit:
            max_requests, window_seconds = gw_route.rate_limit
            middlewares.append(self._create_rate_limit_middleware(
                gw_route.path, max_requests, window_seconds
            ))

        for mw in gw_route.middlewares:
            middlewares.append(mw)

        return middlewares

    def _create_auth_middleware(self) -> Callable:
        async def gateway_auth_middleware(request: Request):
            auth_header = request.headers.get("authorization", "")
            if not auth_header:
                from kewe.errors.exceptions import Unauthorized
                raise Unauthorized("Missing authorization header")

            if auth_header.startswith("Bearer "):
                token = auth_header[7:]
                if not token:
                    from kewe.errors.exceptions import Unauthorized
                    raise Unauthorized("Empty bearer token")
                self._validate_bearer_token(token)
            elif auth_header.startswith("ApiKey "):
                api_key = auth_header[7:]
                if not api_key:
                    from kewe.errors.exceptions import Unauthorized
                    raise Unauthorized("Empty API key")
                request.ctx.gateway_api_key = api_key
            else:
                from kewe.errors.exceptions import Unauthorized
                raise Unauthorized("Unsupported authorization scheme")

            return True

        return gateway_auth_middleware

    def _validate_bearer_token(self, token: str):
        try:
            jwt_manager = self._jwt_manager
            if jwt_manager:
                from kewe.security.jwt import TokenType
                jwt_manager._parse_and_validate_token(token, TokenType.ACCESS)
                return

            if self._app and hasattr(self._app, 'auth') and hasattr(self._app.auth, 'jwt_auth'):
                self._app.auth.jwt_auth._decode_token(token)
                return

            self._validate_jwt_manual(token)
        except Exception as e:
            from kewe.errors.exceptions import Unauthorized
            if isinstance(e, Unauthorized):
                raise
            raise Unauthorized("Invalid token")

    def _validate_jwt_manual(self, token: str) -> Dict[str, Any]:
        import base64
        import hmac
        import hashlib
        parts = token.split('.')
        if len(parts) != 3:
            from kewe.errors.exceptions import Unauthorized
            raise Unauthorized("Invalid JWT format")

        jwt_secret = self._jwt_secret
        if not jwt_secret:
            from kewe.errors.exceptions import Unauthorized
            raise Unauthorized("JWT verification failed: no jwt_secret or jwt_manager configured")

        try:
            header_b64 = parts[0] + '=' * (4 - len(parts[0]) % 4)
            header_data = json.loads(base64.urlsafe_b64decode(header_b64))
        except Exception:
            from kewe.errors.exceptions import Unauthorized
            raise Unauthorized("Invalid token header")

        alg = header_data.get('alg', '').lower()
        if alg not in ('hs256', 'hs384', 'hs512'):
            from kewe.errors.exceptions import Unauthorized
            raise Unauthorized(f"Unsupported JWT algorithm: {header_data.get('alg')}")

        signing_input = f"{parts[0]}.{parts[1]}".encode('utf-8')
        try:
            sig_b64 = parts[2] + '=' * (4 - len(parts[2]) % 4)
            signature = base64.urlsafe_b64decode(sig_b64)
        except Exception:
            from kewe.errors.exceptions import Unauthorized
            raise Unauthorized("Invalid token signature encoding")

        alg_map = {'hs256': hashlib.sha256, 'hs384': hashlib.sha384, 'hs512': hashlib.sha512}
        expected_sig = hmac.new(jwt_secret.encode('utf-8'), signing_input, alg_map[alg]).digest()
        if not hmac.compare_digest(signature, expected_sig):
            from kewe.errors.exceptions import Unauthorized
            raise Unauthorized("Invalid token signature")

        payload_b64 = parts[1] + '=' * (4 - len(parts[1]) % 4)
        user_data = json.loads(base64.urlsafe_b64decode(payload_b64))
        exp = user_data.get('exp')
        if exp and time.time() > exp:
            from kewe.errors.exceptions import Unauthorized
            raise Unauthorized("Token expired")

        return user_data

    def _create_rate_limit_middleware(self, path: str, max_requests: int, window_seconds: int) -> Callable:
        async def gateway_rate_limit_middleware(request: Request):
            client_ip = getattr(request, 'client_ip', 'unknown')
            client_key = f"rate_limit:{client_ip}:{path}"
            now = time.time()

            async with self._rate_limit_lock:
                if len(self._rate_limit_store) > 10000:
                    expired_keys = [k for k, (_, ws) in list(self._rate_limit_store.items())
                                    if now - ws > window_seconds]
                    for k in expired_keys:
                        del self._rate_limit_store[k]
                    if len(self._rate_limit_store) > 10000:
                        oldest = sorted(self._rate_limit_store.items(), key=lambda x: x[1][1])[:len(self._rate_limit_store) - 5000]
                        for k, _ in oldest:
                            del self._rate_limit_store[k]

                if client_key in self._rate_limit_store:
                    count, window_start = self._rate_limit_store[client_key]
                    if now - window_start > window_seconds:
                        self._rate_limit_store[client_key] = (1, now)
                    elif count >= max_requests:
                        from kewe.errors.exceptions import TooManyRequests
                        retry_after = int(window_seconds - (now - window_start))
                        raise TooManyRequests(
                            f"Rate limit exceeded: {max_requests} requests per {window_seconds}s",
                            retry_after=retry_after
                        )
                    else:
                        self._rate_limit_store[client_key] = (count + 1, window_start)
                else:
                    self._rate_limit_store[client_key] = (1, now)

            return True

        return gateway_rate_limit_middleware

    async def _dispatch_to_handler(self, handler: Callable, request: Request,
                                    gw_route: GatewayRoute, **kwargs) -> Any:
        import inspect

        handler_args = {}
        sig = inspect.signature(handler)
        params = list(sig.parameters.keys())

        path_params = getattr(request.ctx, 'path_params', {}) or kwargs
        for param_name, param_value in path_params.items():
            if param_name in params:
                handler_args[param_name] = param_value

        for param_name, param_value in getattr(request, 'query_params', {}).items():
            if param_name in params:
                handler_args[param_name] = param_value

        if 'request' in params:
            handler_args['request'] = request

        if inspect.iscoroutinefunction(handler):
            result = await handler(**handler_args)
        else:
            result = handler(**handler_args)

        if isinstance(result, (dict, list, str, int, float, bool)):
            if isinstance(result, dict) and ('success' in result and 'code' in result):
                return json_response(result)
            return json_response(self._wrap_gateway_response(request, result))
        elif isinstance(result, Response):
            return result
        elif isinstance(result, GatewayResponse):
            return json_response(result.to_dict(), status=result.status)
        else:
            return json_response(self._wrap_gateway_response(request, result))

    def _wrap_gateway_response(self, request: Request, data: Any) -> Dict[str, Any]:
        request_id = getattr(request.ctx, 'request_id', str(uuid.uuid4()))
        return GatewayResponse(
            request_id=request_id,
            success=True,
            code=ErrorCode.SUCCESS.code,
            message=ErrorCode.SUCCESS.message,
            data=data,
        ).to_dict()

    def _register_default_error_handlers(self):
        self._error_handlers[ErrorCode.RATE_LIMITED] = self._handle_rate_limit
        self._error_handlers[ErrorCode.UNAUTHORIZED] = self._handle_unauthorized
        self._error_handlers[ErrorCode.VALIDATION_ERROR] = self._handle_validation_error

    def _register_health_endpoint(self, app):
        prefix = getattr(self, '_gateway_prefix', '')

        async def health_check(request):
            checks = {}
            overall = "healthy"
            if self._app:
                checks["app"] = "healthy"
            else:
                checks["app"] = "unhealthy"
                overall = "unhealthy"
            route_count = len(self._router.get_routes())
            checks["routes"] = f"{route_count} registered"
            status_code = 200 if overall == "healthy" else 503
            from kewe.response import json as json_response
            return json_response(
                {"status": overall, "checks": checks, "prefix": prefix},
                status=status_code,
            )

        try:
            app.route(f"{prefix}/health", methods=["GET"])(health_check)
        except (ValueError, Exception):
            logger.debug("Non-critical operation failed", exc_info=True)

    def _handle_rate_limit(self, request: GatewayRequest, error: GatewayError) -> GatewayResponse:
        return GatewayResponse(
            request_id=request.request_id,
            success=False,
            code=error.error_code.code,
            message="请求过于频繁，请稍后再试",
            metadata={"retry_after": error.details.get("retry_after", 60)},
        )

    def _handle_unauthorized(self, request: GatewayRequest, error: GatewayError) -> GatewayResponse:
        return GatewayResponse(
            request_id=request.request_id,
            success=False,
            code=error.error_code.code,
            message="请先登录",
            metadata={"auth_url": f"{getattr(self, '_gateway_prefix', '')}/auth/login"},
        )

    def _handle_validation_error(self, request: GatewayRequest, error: GatewayError) -> GatewayResponse:
        return GatewayResponse(
            request_id=request.request_id,
            success=False,
            code=error.error_code.code,
            message="请求数据验证失败",
            data={"errors": error.details.get("errors", [])},
        )

    def register_route(self, route: GatewayRoute) -> None:
        self._router.add_route(route)
        self._register_gateway_route_to_main_router(route)
        logger.info(f"Gateway route registered: {route.method.upper()}:{route.version}:{route.path}")

    def add_route(self, route: GatewayRoute) -> None:
        return self.register_route(route)

    def route(
        self,
        path: str,
        method: str = "GET",
        version: str = "v1",
        require_auth: bool = True,
        rate_limit: Optional[Tuple[int, int]] = None,
        middlewares: List[Callable] = None,
        description: str = "",
        namespace: Optional[str] = None,
    ):
        def decorator(func: Callable):
            import inspect
            sig = inspect.signature(func)
            params = list(sig.parameters.keys())

            async def wrapped_handler(request):
                handler_args = {}

                if "path_params" in request.metadata:
                    for param_name, param_value in request.metadata["path_params"].items():
                        if param_name in params:
                            handler_args[param_name] = param_value

                for param_name, param_value in request.query_params.items():
                    if param_name in params:
                        param_type = sig.parameters[param_name].annotation
                        if param_type != inspect.Parameter.empty:
                            try:
                                if param_type == int:
                                    handler_args[param_name] = int(param_value)
                                elif param_type == float:
                                    handler_args[param_name] = float(param_value)
                                elif param_type == bool:
                                    handler_args[param_name] = param_value.lower() == "true"
                                else:
                                    handler_args[param_name] = param_value
                            except Exception:
                                handler_args[param_name] = param_value
                        else:
                            handler_args[param_name] = param_value

                if "body" in params:
                    handler_args["body"] = await request.body
                if "json" in params:
                    handler_args["json"] = await request.json_async

                if "request" in params:
                    handler_args["request"] = request

                if inspect.iscoroutinefunction(func):
                    return await func(**handler_args)
                else:
                    return func(**handler_args)

            gateway_route = GatewayRoute(
                path=path,
                method=method,
                handler=wrapped_handler,
                version=version,
                middlewares=middlewares or [],
                require_auth=require_auth,
                rate_limit=rate_limit,
                description=description,
                namespace=namespace,
            )
            self.register_route(gateway_route)
            return func

        return decorator

    def get(self, path, **kwargs):
        return self.route(path, method="GET", **kwargs)

    def post(self, path, **kwargs):
        return self.route(path, method="POST", **kwargs)

    def put(self, path, **kwargs):
        return self.route(path, method="PUT", **kwargs)

    def delete(self, path, **kwargs):
        return self.route(path, method="DELETE", **kwargs)

    def patch(self, path, **kwargs):
        return self.route(path, method="PATCH", **kwargs)

    def add_global_middleware(self, middleware: Callable) -> None:
        self._global_middlewares.append(middleware)

    def set_jwt_manager(self, jwt_manager):
        self._jwt_manager = jwt_manager

    def set_jwt_secret(self, secret: str):
        self._jwt_secret = secret

    async def _get_cached_route(self, cache_key: str) -> Optional[Tuple[GatewayRoute, Dict[str, str]]]:
        async with self._cache_lock:
            if cache_key in self._route_cache:
                route_info = self._route_cache.pop(cache_key)
                self._route_cache[cache_key] = route_info
                return route_info
            return None

    async def _cache_route(self, cache_key: str, route_info: Tuple[GatewayRoute, Dict[str, str]]) -> None:
        async with self._cache_lock:
            if len(self._route_cache) >= self._cache_size:
                oldest_key = next(iter(self._route_cache))
                del self._route_cache[oldest_key]
            self._route_cache[cache_key] = route_info

    async def _match_route(self, path: str, method: str, version: str) -> Optional[Tuple[GatewayRoute, Dict[str, str]]]:
        cache_key = f"{method.upper()}:{version}:{path}"

        cached = await self._get_cached_route(cache_key)
        if cached:
            return cached

        result = self._router.match(path, method, version)
        if result:
            await self._cache_route(cache_key, result)

        return result

    async def handle_request(self, raw_request: Dict[str, Any]) -> Dict[str, Any]:
        request_id = str(uuid.uuid4())
        request = None

        try:
            path = raw_request.get("path", "/")
            api_version = raw_request.get("api_version", "v1")

            prefix = getattr(self, '_gateway_prefix', '')
            version_match = re.match(rf"^{re.escape(prefix)}/(v\d+)(/.*)?$", path)
            if version_match:
                extracted_version = version_match.group(1)
                clean_path = prefix + (version_match.group(2) if version_match.group(2) else "")
                api_version = extracted_version
            else:
                clean_path = path

            body = raw_request.get("body")
            request = GatewayRequest(
                request_id=request_id,
                path=clean_path,
                method=raw_request.get("method", "GET"),
                headers=raw_request.get("headers", {}),
                query_params=raw_request.get("query_params", {}),
                body=body,
                client_ip=raw_request.get("client_ip", ""),
                user_agent=raw_request.get("user_agent", ""),
                api_version=api_version,
                user_id=raw_request.get("user_id"),
            )

            for middleware in self._global_middlewares:
                try:
                    if asyncio.iscoroutinefunction(middleware):
                        result = await middleware(request)
                    else:
                        result = middleware(request)
                    if result:
                        request = result
                except Exception as e:
                    logger.error(f"中间件执行失败: {e}")

            match_result = await self._match_route(request.path, request.method, request.api_version)
            if not match_result:
                raise GatewayError(
                    ErrorCode.NOT_FOUND, f"路由不存在: {request.method} {request.path}"
                )

            route, path_params = match_result
            request.metadata["path_params"] = path_params

            if route.require_auth:
                auth_header = request.headers.get("authorization", "")
                if not auth_header:
                    raise GatewayError(ErrorCode.UNAUTHORIZED, "Missing authorization header")
                if auth_header.startswith("Bearer "):
                    token = auth_header[7:]
                    if not token:
                        raise GatewayError(ErrorCode.UNAUTHORIZED, "Empty bearer token")
                    try:
                        jwt_manager = getattr(self, '_jwt_manager', None)
                        if jwt_manager:
                            try:
                                from kewe.security.jwt import TokenType
                                payload = jwt_manager._parse_and_validate_token(token, TokenType.ACCESS)
                                user_data = {"sub": payload.sub, "jti": payload.jti, "exp": payload.exp}
                            except Exception:
                                user_data = self._validate_jwt_manual(token)
                        else:
                            user_data = self._validate_jwt_manual(token)
                        request.metadata["user"] = user_data.get("sub")
                        request.metadata["token_payload"] = user_data
                    except GatewayError:
                        raise
                    except Exception as e:
                        raise GatewayError(ErrorCode.UNAUTHORIZED, f"Invalid token: {str(e)}")
                elif auth_header.startswith("ApiKey "):
                    api_key = auth_header[7:]
                    if not api_key:
                        raise GatewayError(ErrorCode.UNAUTHORIZED, "Empty API key")
                    request.metadata["api_key"] = api_key
                else:
                    raise GatewayError(ErrorCode.UNAUTHORIZED, "Unsupported authorization scheme")

            if route.rate_limit:
                max_requests, window_seconds = route.rate_limit
                client_key = f"rate_limit:{request.client_ip}:{route.path}"
                now = time.time()
                async with self._rate_limit_lock:
                    if len(self._rate_limit_store) > 10000:
                        expired_keys = [k for k, (_, ws) in list(self._rate_limit_store.items()) if now - ws > window_seconds * 2]
                        for k in expired_keys:
                            del self._rate_limit_store[k]

                    if client_key in self._rate_limit_store:
                        count, window_start = self._rate_limit_store[client_key]
                        if now - window_start > window_seconds:
                            self._rate_limit_store[client_key] = (1, now)
                        elif count >= max_requests:
                            raise GatewayError(
                                ErrorCode.RATE_LIMITED,
                                f"Rate limit exceeded: {max_requests} requests per {window_seconds}s",
                                details={"retry_after": int(window_seconds - (now - window_start))}
                            )
                        else:
                            self._rate_limit_store[client_key] = (count + 1, window_start)
                    else:
                        self._rate_limit_store[client_key] = (1, now)

            for middleware in route.middlewares:
                try:
                    if asyncio.iscoroutinefunction(middleware):
                        result = await middleware(request)
                    else:
                        result = middleware(request)
                    if result:
                        request = result
                except Exception as e:
                    logger.error(f"路由中间件执行失败: {e}")

            if asyncio.iscoroutinefunction(route.handler):
                response_data = await route.handler(request)
            else:
                response_data = route.handler(request)

            if isinstance(response_data, GatewayResponse):
                response = response_data
            elif isinstance(response_data, dict):
                response = GatewayResponse(
                    request_id=request_id,
                    success=True,
                    code=ErrorCode.SUCCESS.code,
                    message=ErrorCode.SUCCESS.message,
                    data=response_data,
                )
            else:
                response = GatewayResponse(
                    request_id=request_id,
                    success=True,
                    code=ErrorCode.SUCCESS.code,
                    message=ErrorCode.SUCCESS.message,
                    data=response_data,
                )

            return response.to_dict()

        except GatewayError as e:
            handler = self._error_handlers.get(e.gateway_error_code)
            if handler and request is not None:
                response = handler(request, e)
            else:
                response = GatewayResponse(
                    request_id=request_id,
                    success=False,
                    code=e.gateway_error_code.code,
                    message=e.message,
                    data=e.details,
                )
            return response.to_dict()

        except Exception as e:
            logger.error(f"请求处理失败: {e}")
            response = GatewayResponse(
                request_id=request_id,
                success=False,
                code=ErrorCode.SERVER_ERROR.code,
                message="服务器内部错误",
            )
            return response.to_dict()

    def get_routes(self) -> List[GatewayRoute]:
        return self._router.get_routes()

    def sync_blueprint_routes(self, blueprint_name: str, url_prefix: str, routes: List[Dict[str, Any]]):
        if not self._main_router or not self._app:
            return

        for route_info in routes:
            path = route_info.get('path', '/')
            methods = route_info.get('methods', ['GET'])
            handler = route_info.get('handler')
            version = route_info.get('version', 'v1')
            require_auth = route_info.get('require_auth', True)
            rate_limit = route_info.get('rate_limit')
            description = route_info.get('description', '')
            route_middlewares = route_info.get('middlewares', [])

            full_path = f"{self._gateway_prefix}{url_prefix}{path}"

            gw_route = GatewayRoute(
                path=full_path,
                method=methods[0] if methods else "GET",
                handler=handler,
                version=version,
                middlewares=route_middlewares,
                require_auth=require_auth,
                rate_limit=rate_limit,
                description=description,
                namespace=f"{blueprint_name}:{handler.__name__}" if handler else None,
            )

            self._router.add_route(gw_route)
            self._register_gateway_route_to_main_router(gw_route)

            logger.info(f"Synced blueprint route: {blueprint_name} {methods} {full_path}")


def get_api_gateway() -> APIGateway:
    return APIGateway()


from kewe.errors.circuit_breaker import CircuitState, CircuitBreaker, CircuitOpenError
