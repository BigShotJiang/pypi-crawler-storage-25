#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
API网关模块 - Gateway Package
提供API路由、中间件、限流、认证、版本控制、熔断器
"""
from .core import (
    ErrorCode,
    GatewayRequest,
    GatewayResponse,
    GatewayRoute,
    GatewayError,
    GatewayTrieNode,
    TrieRouter,
    APIGateway,
    CircuitState,
    CircuitBreaker,
    CircuitOpenError,
    get_api_gateway,
)
from .adapter import (
    GatewayAdapter,
    setup_gateway,
)

__all__ = [
    'ErrorCode',
    'GatewayRequest',
    'GatewayResponse',
    'GatewayRoute',
    'GatewayError',
    'GatewayTrieNode',
    'TrieRouter',
    'APIGateway',
    'CircuitState',
    'CircuitBreaker',
    'CircuitOpenError',
    'get_api_gateway',
    'GatewayAdapter',
    'setup_gateway',
]
