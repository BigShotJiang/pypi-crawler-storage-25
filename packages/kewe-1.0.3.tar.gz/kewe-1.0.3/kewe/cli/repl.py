#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
REPL 上下文 - Interactive Shell Context
REPL上下文实现

功能：
- 交互式应用调试
- 自动导入常用对象
- 支持异步代码执行
- 上下文注入 API
"""
import asyncio
import code
import inspect
import logging
import sys
import types
from typing import Dict, Any, Optional, List, Callable, Union
from pathlib import Path
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class REPLVariable:
    """REPL 变量定义"""
    name: str
    value: Any
    description: Optional[str] = None


class REPLContextManager:
    """
    REPL 上下文管理器
    
    支持动态注入变量到 REPL 环境
    
    使用示例:
        # 方式1：直接设置属性
        app.repl_ctx.foo = foo
        app.repl_ctx.os = os
        
        # 方式2：使用 add 方法
        app.repl_ctx.add(foo)
        app.repl_ctx.add(os, desc="Standard os module.")
        
        # 方式3：使用 add_local 方法
        app.repl_ctx.add_local(variable=my_obj, name="obj", desc="My object")
    """
    
    def __init__(self, app=None):
        self._app = app
        self._variables: Dict[str, REPLVariable] = {}
        self._preparations: List[str] = []
    
    def add(
        self,
        obj: Any,
        name: str = None,
        desc: Optional[str] = None
    ) -> 'REPLContextManager':
        """
        添加对象到 REPL 上下文
        
        Args:
            obj: 要添加的对象
            name: 变量名（默认使用对象的 __name__）
            desc: 描述信息
            
        Returns:
            self（支持链式调用）
            
        使用示例:
            app.repl_ctx.add(foo).add(bar, desc="Bar object")
        """
        if name is None:
            name = getattr(obj, '__name__', None) or getattr(obj, '__qualname__', str(id(obj)))
        
        self._variables[name] = REPLVariable(
            name=name,
            value=obj,
            description=desc or getattr(obj, '__doc__', None)
        )
        
        return self
    
    def add_local(
        self,
        variable: Any,
        name: str = None,
        desc: Optional[str] = None
    ) -> 'REPLContextManager':
        """
        添加本地变量（add 的别名，语义更清晰）
        
        Args:
            variable: 变量值
            name: 变量名
            desc: 描述信息
            
        Returns:
            self
        """
        return self.add(variable, name, desc)
    
    def prepare(self, code: str) -> 'REPLContextManager':
        """
        添加准备代码（在 REPL 启动时执行）
        
        Args:
            code: Python 代码字符串
            
        Returns:
            self
            
        使用示例:
            app.repl_ctx.prepare("from utils.helpers import *")
            app.repl_ctx.prepare("from models import User, Post")
        """
        self._preparations.append(code)
        return self
    
    def remove(self, name: str) -> bool:
        """
        移除变量
        
        Args:
            name: 变量名
            
        Returns:
            是否成功移除
        """
        if name in self._variables:
            del self._variables[name]
            return True
        return False
    
    def clear(self):
        """清除所有自定义变量"""
        self._variables.clear()
        self._preparations.clear()
    
    def get_variables(self) -> Dict[str, Any]:
        """获取所有变量"""
        return {name: var.value for name, var in self._variables.items()}
    
    def get_descriptions(self) -> Dict[str, str]:
        """获取所有变量的描述"""
        return {name: var.description or "" for name, var in self._variables.items()}
    
    def __setattr__(self, name: str, value: Any):
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            self._variables[name] = REPLVariable(name=name, value=value)
    
    def __getattr__(self, name: str) -> Any:
        if name.startswith('_'):
            return super().__getattribute__(name)
        if name in self._variables:
            return self._variables[name].value
        raise AttributeError(f"REPL context has no attribute '{name}'")
    
    def __delattr__(self, name: str):
        if name.startswith('_'):
            super().__delattr__(name)
        else:
            self.remove(name)


class REPLContext:
    """
    REPL 上下文
    
    提供交互式调试环境
    
    使用示例:
        $ kewe shell myapp:app
        >>> app
        <Kewe 'myapp'>
        >>> app.router.routes
        [...]
    """
    
    def __init__(
        self,
        app = None,
        locals: Dict[str, Any] = None,
        banner: str = None
    ):
        self.app = app
        self._locals = locals or {}
        self._banner = banner
        self._history_file = Path.home() / ".kewe_repl_history"
        self._context_manager = REPLContextManager(app)
    
    @property
    def ctx(self) -> REPLContextManager:
        """获取上下文管理器"""
        return self._context_manager
    
    def setup(self) -> Dict[str, Any]:
        context = {
            'app': self.app,
            '__name__': '__console__',
            '__doc__': None,
        }
        
        if self.app:
            context.update({
                'config': self.app.config,
                'router': self.app.router,
                'ctx': self.app.ctx,
                'state': self.app.state,
                'shared_ctx': getattr(self.app, 'shared_ctx', None),
            })
        
        context.update(self._get_default_imports())
        context.update(self._locals)
        context.update(self._context_manager.get_variables())
        
        return context
    
    def _get_default_imports(self) -> Dict[str, Any]:
        imports = {}
        
        try:
            import kewe
            imports['kewe'] = kewe
            imports.update({
                'Kewe': kewe.Kewe,
                'Request': kewe.Request,
                'Response': kewe.Response,
                'json': kewe.json,
                'text': kewe.text,
                'html': kewe.html,
                'redirect': kewe.redirect,
                'Blueprint': kewe.Blueprint,
                'Middleware': kewe.Middleware,
                'g': kewe.g,
            })
        except ImportError:
            pass
        
        imports.update({
            'asyncio': asyncio,
            'sys': sys,
            'Path': Path,
        })
        
        return imports
    
    def get_banner(self) -> str:
        """获取欢迎信息"""
        if self._banner:
            return self._banner
        
        try:
            import kewe
            version = kewe.__version__
        except (ImportError, AttributeError):
            version = "unknown"
        
        lines = [
            f"Kewe Framework v{version}",
            "Interactive Shell",
            "",
            "Available objects:",
            "  app      - Application instance",
            "  config   - Application config",
            "  router   - Router instance",
            "  ctx      - Application context",
            "  g        - Global storage",
            "",
            "Type 'help(object)' for help, 'exit()' to exit.",
        ]
        
        if self.app:
            lines.insert(2, f"Application: {self.app.name}")
        
        return "\n".join(lines)
    
    def interact(self):
        """启动交互式会话"""
        context = self.setup()
        banner = self.get_banner()
        
        try:
            import readline
            readline.set_completer(self._completer)
            readline.parse_and_bind("tab: complete")
            
            if self._history_file.exists():
                readline.read_history_file(str(self._history_file))
        except ImportError:
            pass
        
        console = code.InteractiveConsole(context)
        
        try:
            console.interact(banner=banner, exitmsg="Goodbye!")
        finally:
            try:
                import readline
                readline.write_history_file(str(self._history_file))
            except (ImportError, IOError):
                pass
    
    def _completer(self, text: str, state: int):
        """自动补全"""
        context = self.setup()
        options = [key for key in context.keys() if key.startswith(text)]
        if state < len(options):
            return options[state]
        return None


class AsyncREPLContext(REPLContext):
    """
    异步 REPL 上下文
    
    支持在 REPL 中执行异步代码
    
    使用示例:
        >>> await app.ctx.db.query("SELECT 1")
        [{'?column?': 1}]
    """
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._loop = None
    
    def setup(self) -> Dict[str, Any]:
        context = super().setup()
        
        context['_await'] = self._await
        context['run'] = self._run_async
        
        return context
    
    def _await(self, coro):
        """等待协程完成"""
        if self._loop is None:
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
        
        return self._loop.run_until_complete(coro)
    
    def _run_async(self, coro):
        """运行异步函数"""
        return self._await(coro)
    
    def interact(self):
        """启动异步交互式会话"""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        
        try:
            super().interact()
        finally:
            self._loop.close()


def create_repl_context(
    app = None,
    locals: Dict[str, Any] = None,
    async_mode: bool = True
) -> REPLContext:
    """
    创建 REPL 上下文
    
    Args:
        app: 应用实例
        locals: 额外的本地变量
        async_mode: 是否启用异步模式
        
    Returns:
        REPLContext 实例
    """
    if async_mode:
        return AsyncREPLContext(app=app, locals=locals)
    return REPLContext(app=app, locals=locals)


def run_shell(app_path: str, locals: Dict[str, Any] = None):
    """
    运行交互式 Shell
    
    Args:
        app_path: 应用路径 (module:app)
        locals: 额外的本地变量
    """
    from kewe.cli.app import import_app
    
    _, app = import_app(app_path)
    
    context = create_repl_context(app=app, locals=locals)
    context.interact()


__all__ = [
    'REPLContext',
    'AsyncREPLContext',
    'create_repl_context',
    'run_shell',
]
