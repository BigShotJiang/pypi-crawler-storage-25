#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
完善的CLI工具 - CLI Tool Enhancement
支持多命令、自定义命令、项目生成、运行管理
"""
import argparse
import sys
import os
import subprocess
import asyncio
import importlib.util
from pathlib import Path
from typing import List, Dict, Callable, Optional, Any
import logging

logger = logging.getLogger(__name__)


__all__ = [
    'CLI',
    'Command',
    'RunCommand',
    'CreateProjectCommand',
    'TestCommand',
    'ShellCommand',
    'RoutesCommand',
    'VersionCommand',
]


def import_app(app_path: str):
    """导入应用实例

    Args:
        app_path: 应用路径 (module:app)

    Returns:
        tuple: (module_name, app_instance)
    """
    if ":" not in app_path:
        app_path = f"{app_path}:app"

    module_name, app_name = app_path.split(":")

    if os.getcwd() not in sys.path:
        sys.path.insert(0, os.getcwd())

    try:
        module = importlib.import_module(module_name)
        app = getattr(module, app_name)
        return module_name, app
    except ImportError as e:
        raise ImportError(f"Cannot import module '{module_name}': {e}") from e
    except AttributeError as e:
        raise AttributeError(f"Module '{module_name}' has no attribute '{app_name}'") from e


class Command:
    """命令基类"""
    
    name: str = ""
    description: str = ""
    aliases: List[str] = []
    
    def add_arguments(self, parser: argparse.ArgumentParser):
        """添加命令参数 - 默认空实现"""
        return None
    
    def handle(self, args: argparse.Namespace) -> int:
        """处理命令，返回退出码"""
        raise NotImplementedError
    
    def run(self, args: argparse.Namespace) -> int:
        """运行命令"""
        try:
            return self.handle(args)
        except Exception as e:
            logger.error(f"Command '{self.name}' failed: {e}")
            return 1


class RunCommand(Command):
    """运行服务器命令"""
    
    name = "run"
    description = "Run the Kewe application server"
    aliases = ["start", "serve"]
    
    def add_arguments(self, parser: argparse.ArgumentParser):
        parser.add_argument("--host", "-H", default="0.0.0.0", help="Host to bind to")
        parser.add_argument("--port", "-p", type=int, default=8000, help="Port to bind to")
        parser.add_argument("--workers", "-w", type=int, default=1, help="Number of worker processes")
        parser.add_argument("--debug", "-d", action="store_true", help="Enable debug mode")
        parser.add_argument("--reload", "-r", action="store_true", help="Enable auto-reload")
        parser.add_argument("--app", "-a", default="app:app", help="Application module and instance (module:app)")
    
    def handle(self, args: argparse.Namespace) -> int:
        """处理运行命令"""
        logger.info(f"Starting Kewe server on {args.host}:{args.port}")
        
        if args.reload:
            return self._run_with_reload(args)
        elif args.workers > 1:
            return self._run_with_workers(args)
        else:
            return self._run_single(args)
    
    def _run_single(self, args: argparse.Namespace) -> int:
        """单进程运行"""
        try:
            app = self._load_app(args.app)
            asyncio.run(app.run(host=args.host, port=args.port, debug=args.debug))
            return 0
        except KeyboardInterrupt:
            logger.info("Server stopped")
            return 0
        except Exception as e:
            logger.error(f"Server error: {e}")
            return 1
    
    def _run_with_workers(self, args: argparse.Namespace) -> int:
        """多进程运行"""
        import multiprocessing
        
        def worker_process(worker_id: int):
            """工作进程"""
            try:
                app = self._load_app(args.app)
                asyncio.run(app.run(host=args.host, port=args.port + worker_id, debug=args.debug))
            except Exception as e:
                logger.error(f"Worker {worker_id} error: {e}")
        
        processes = []
        for i in range(args.workers):
            p = multiprocessing.Process(target=worker_process, args=(i,))
            p.start()
            processes.append(p)
        
        try:
            for p in processes:
                p.join()
        except KeyboardInterrupt:
            logger.info("Stopping workers...")
            for p in processes:
                p.terminate()
        
        return 0
    
    def _run_with_reload(self, args: argparse.Namespace) -> int:
        from kewe.server.reloader import FileWatcher, ReloadConfig
        
        config = ReloadConfig(
            enabled=True,
            watch_dirs=['.'],
            watch_files=['*.py'],
            ignore_dirs=['__pycache__', '.git', 'node_modules', '.venv', 'venv', 'env'],
            interval=1.0,
        )
        
        server_process = None
        
        def start_server():
            nonlocal server_process
            stop_server()
            server_process = subprocess.Popen(
                [sys.executable, '-c',
                 f'import importlib; import sys; sys.path.insert(0, "."); '
                 f'm = importlib.import_module("{args.app.split(":")[0]}"); '
                 f'app = getattr(m, "{args.app.split(":")[1] if ":" in args.app else "app"}"); '
                 f'import asyncio; asyncio.run(app.run(host="{args.host}", port={args.port}, debug={args.debug}))'],
                cwd=os.getcwd(),
            )
        
        def stop_server():
            nonlocal server_process
            if server_process and server_process.poll() is None:
                server_process.terminate()
                try:
                    server_process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    server_process.kill()
                server_process = None
        
        def on_files_changed(changed_files):
            logger.info(f"Files changed: {changed_files}, restarting server...")
            start_server()
        
        watcher = FileWatcher(config)
        watcher.add_callback(on_files_changed)
        
        start_server()
        watcher.start()
        
        try:
            while True:
                import time
                time.sleep(0.5)
                if server_process and server_process.poll() is not None:
                    if server_process.returncode != 0:
                        logger.warning(f"Server exited with code {server_process.returncode}, waiting for file changes...")
        except KeyboardInterrupt:
            logger.info("Stopping server...")
            stop_server()
            watcher.stop()
        
        return 0
    
    def _load_app(self, app_path: str) -> Any:
        _, app = import_app(app_path)
        return app


class CreateProjectCommand(Command):
    """创建项目命令"""
    
    name = "new"
    description = "Create a new Kewe project"
    aliases = ["create", "init"]
    
    def add_arguments(self, parser: argparse.ArgumentParser):
        parser.add_argument("name", help="Project name")
        parser.add_argument("--directory", "-d", help="Project directory (default: project name)")
        parser.add_argument("--template", "-t", default="basic", 
                          choices=["basic", "api", "full"],
                          help="Project template")
    
    def handle(self, args: argparse.Namespace) -> int:
        """处理创建项目命令"""
        project_name = args.name
        project_dir = Path(args.directory or project_name)
        
        if project_dir.exists():
            logger.error(f"Directory '{project_dir}' already exists")
            return 1
        
        logger.info(f"Creating new Kewe project: {project_name}")
        
        # 创建项目结构
        self._create_project_structure(project_dir, project_name, args.template)
        
        logger.info(f"Project '{project_name}' created successfully!")
        logger.info(f"To get started:")
        logger.info(f"  cd {project_dir}")
        logger.info(f"  kewe run")
        
        return 0
    
    def _create_project_structure(self, project_dir: Path, name: str, template: str):
        """创建项目结构"""
        # 创建目录
        (project_dir / name).mkdir(parents=True)
        (project_dir / "tests").mkdir()
        
        # 创建 __init__.py
        (project_dir / name / "__init__.py").write_text("")
        (project_dir / "tests" / "__init__.py").write_text("")
        
        # 创建主应用文件
        app_content = self._get_app_template(name, template)
        (project_dir / name / "app.py").write_text(app_content)
        
        # 创建配置文件
        config_content = self._get_config_template()
        (project_dir / name / "config.py").write_text(config_content)
        
        # 创建路由文件
        routes_content = self._get_routes_template()
        (project_dir / name / "routes.py").write_text(routes_content)
        
        # 创建 requirements.txt
        requirements = self._get_requirements_template(template)
        (project_dir / "requirements.txt").write_text(requirements)
        
        # 创建 README.md
        readme = self._get_readme_template(name)
        (project_dir / "README.md").write_text(readme)
        
        # 创建 .gitignore
        gitignore = self._get_gitignore_template()
        (project_dir / ".gitignore").write_text(gitignore)
        
        # 如果是完整模板，添加更多文件
        if template == "full":
            (project_dir / name / "models").mkdir()
            (project_dir / name / "services").mkdir()
            (project_dir / name / "middleware").mkdir()
            (project_dir / name / "models" / "__init__.py").write_text("")
            (project_dir / name / "services" / "__init__.py").write_text("")
            (project_dir / name / "middleware" / "__init__.py").write_text("")
    
    def _get_app_template(self, name: str, template: str) -> str:
        """获取应用模板"""
        return f'''"""
{name} - Kewe Application
"""
from kewe import Kewe, KeweConfig
from .config import config
from .routes import setup_routes

# 创建应用
app_config = KeweConfig(
    host=config.get("HOST", "0.0.0.0"),
    port=config.get("PORT", 8000),
    debug=config.get("DEBUG", False),
)

app = Kewe(name="{name}", config=app_config)

# 设置路由
setup_routes(app)

if __name__ == "__main__":
    import asyncio
    asyncio.run(app.run())
'''
    
    def _get_config_template(self) -> str:
        """获取配置模板"""
        return '''"""
Configuration
"""
import os

class Config:
    """配置类"""
    
    def __init__(self):
        self._config = {
            "HOST": os.getenv("HOST", "0.0.0.0"),
            "PORT": int(os.getenv("PORT", "8000")),
            "DEBUG": os.getenv("DEBUG", "false").lower() == "true",
            "SECRET_KEY": os.getenv("SECRET_KEY", "your-secret-key"),
        }
    
    def get(self, key: str, default=None):
        return self._config.get(key, default)
    
    def set(self, key: str, value):
        self._config[key] = value

# 全局配置实例
config = Config()
'''
    
    def _get_routes_template(self) -> str:
        """获取路由模板"""
        return '''"""
Routes
"""
from kewe import json

def setup_routes(app):
    """设置路由"""
    
    @app.get("/")
    async def index(request):
        return json({"message": "Welcome to Kewe!"})
    
    @app.get("/health")
    async def health(request):
        return json({"status": "healthy"})
    
    @app.get("/users/<id:int>")
    async def get_user(request, id: int):
        return json({"id": id, "name": "User " + str(id)})
'''
    
    def _get_requirements_template(self, template: str) -> str:
        """获取依赖模板"""
        base = "kewe\\n"
        if template in ["api", "full"]:
            base += "pydantic\\n"
        if template == "full":
            base += "redis\\n"
            base += "aiomysql\\n"
            base += "aiohttp\\n"
        return base
    
    def _get_readme_template(self, name: str) -> str:
        """获取README模板"""
        return f'''# {name}

A Kewe web application.

## Getting Started

### Installation

```bash
pip install -r requirements.txt
```

### Running

```bash
kewe run
```

Or:

```bash
python -m {name}.app
```

## Project Structure

```
{name}/
├── __init__.py
├── app.py          # Main application
├── config.py       # Configuration
└── routes.py       # Route definitions
tests/              # Test files
```

## License

MIT
'''
    
    def _get_gitignore_template(self) -> str:
        """获取gitignore模板"""
        return '''# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# Virtual environments
venv/
ENV/
env/
.venv

# IDE
.vscode/
.idea/
*.swp
*.swo
*~

# Environment
.env
.env.local

# Logs
*.log
logs/
'''


class TestCommand(Command):
    """测试命令"""
    
    name = "test"
    description = "Run tests"
    aliases = ["t"]
    
    def add_arguments(self, parser: argparse.ArgumentParser):
        parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
        parser.add_argument("--coverage", "-c", action="store_true", help="Run with coverage")
        parser.add_argument("--pattern", "-p", default="test_*.py", help="Test file pattern")
        parser.add_argument("path", nargs="?", default="tests", help="Test directory or file")
    
    def handle(self, args: argparse.Namespace) -> int:
        """处理测试命令"""
        cmd = ["pytest"]
        
        if args.verbose:
            cmd.append("-v")
        
        if args.coverage:
            cmd.extend(["--cov=.", "--cov-report=term-missing"])
        
        cmd.append(args.path)
        
        try:
            result = subprocess.run(cmd, check=True)
            return result.returncode
        except subprocess.CalledProcessError as e:
            return e.returncode
        except FileNotFoundError:
            logger.error("pytest not found. Install it with: pip install pytest")
            return 1


class ShellCommand(Command):
    """交互式Shell命令"""
    
    name = "shell"
    description = "Start an interactive shell with app context"
    aliases = ["sh", "console"]
    
    def add_arguments(self, parser: argparse.ArgumentParser):
        parser.add_argument("--app", "-a", default="app:app", help="Application path")
    
    def handle(self, args: argparse.Namespace) -> int:
        """处理Shell命令"""
        import code
        
        # 加载应用
        sys.path.insert(0, os.getcwd())
        
        try:
            module_name, app_name = args.app.split(":")
            module = importlib.import_module(module_name)
            app = getattr(module, app_name)
        except Exception as e:
            logger.error(f"Cannot load app: {e}")
            return 1
        
        # 设置交互环境
        context = {
            "app": app,
            "Kewe": type(app),
            "Request": None,  # 导入请求类
            "json": None,  # 导入json响应
        }
        
        banner = f"""
Kewe Interactive Shell
======================
Available objects:
  - app: Your Kewe application

Type help(app) for more information.
"""
        
        code.interact(banner=banner, local=context)
        return 0


class RoutesCommand(Command):
    """路由列表命令"""
    
    name = "routes"
    description = "List all registered routes"
    aliases = ["r", "url"]
    
    def add_arguments(self, parser: argparse.ArgumentParser):
        parser.add_argument("--app", "-a", default="app:app", help="Application path")
    
    def handle(self, args: argparse.Namespace) -> int:
        """处理路由列表命令"""
        sys.path.insert(0, os.getcwd())
        
        try:
            module_name, app_name = args.app.split(":")
            module = importlib.import_module(module_name)
            app = getattr(module, app_name)
        except Exception as e:
            logger.error(f"Cannot load app: {e}")
            return 1
        
        print("Registered Routes:")
        print("=" * 80)
        print(f"{'Method':<10} {'Path':<40} {'Handler':<30}")
        print("-" * 80)
        
        # 打印路由
        for route in app.router.routes:
            methods = ",".join(route.methods)
            handler_name = f"{route.handler.__module__}.{route.handler.__name__}"
            print(f"{methods:<10} {route.path:<40} {handler_name:<30}")
        
        return 0


class VersionCommand(Command):
    """版本命令"""
    
    name = "version"
    description = "Show version information"
    aliases = ["v", "--version"]
    
    def handle(self, args: argparse.Namespace) -> int:
        """处理版本命令"""
        try:
            from kewe import __version__
            print(f"Kewe {__version__}")
        except ImportError:
            print("Kewe (version unknown)")
        
        print(f"Python {sys.version}")
        return 0


class DBCommand(Command):
    """数据库命令公共基类"""

    def _load_app(self, app_path: str) -> Any:
        _, app = import_app(app_path)
        return app

    def _get_database_url(self, app: Any) -> Optional[str]:
        if hasattr(app, 'db') and hasattr(app.db, '_database_url'):
            return app.db._database_url
        if hasattr(app, 'config'):
            config = app.config
            if isinstance(config, dict):
                return config.get('DATABASE_URL')
            if hasattr(config, 'extra') and 'DATABASE_URL' in config.extra:
                return config.extra['DATABASE_URL']
            if hasattr(config, 'get'):
                return config.get('DATABASE_URL')
        return os.environ.get('DATABASE_URL')

    def _import_alembic(self):
        try:
            from kewe.database.alembic import AlembicManager
            return AlembicManager
        except ImportError:
            logger.error("Alembic is required. Install with: pip install alembic")
            return None


class DBMigrateCommand(DBCommand):
    """数据库迁移命令"""

    name = "migrate"
    description = "Generate a new database migration"
    aliases = ["makemigrations"]

    def add_arguments(self, parser: argparse.ArgumentParser):
        parser.add_argument("--app", "-a", default="app:app", help="Application path")
        parser.add_argument("-m", "--message", default="auto", help="Migration message")
        parser.add_argument("--migrations-dir", default="migrations", help="Migrations directory")
        parser.add_argument("--no-autogenerate", action="store_true", help="Don't autogenerate migration")

    def handle(self, args: argparse.Namespace) -> int:
        AlembicManager = self._import_alembic()
        if not AlembicManager:
            return 1

        app = self._load_app(args.app)
        database_url = self._get_database_url(app)
        if not database_url:
            logger.error("No database URL found. Configure app.db or pass --database-url")
            return 1

        try:
            manager = AlembicManager(
                database_url=database_url,
                migrations_dir=args.migrations_dir,
            )
            revision = manager.generate(
                message=args.message,
                autogenerate=not args.no_autogenerate,
            )
            logger.info(f"Generated migration: {revision}")
            return 0
        except Exception as e:
            logger.error(f"Migration generation failed: {e}")
            return 1


class DBUpgradeCommand(DBCommand):
    """数据库升级命令"""

    name = "db-upgrade"
    description = "Upgrade database to a given revision"
    aliases = ["upgrade"]

    def add_arguments(self, parser: argparse.ArgumentParser):
        parser.add_argument("--app", "-a", default="app:app", help="Application path")
        parser.add_argument("--revision", "-r", default="head", help="Target revision (default: head)")
        parser.add_argument("--migrations-dir", default="migrations", help="Migrations directory")

    def handle(self, args: argparse.Namespace) -> int:
        AlembicManager = self._import_alembic()
        if not AlembicManager:
            return 1

        app = self._load_app(args.app)
        database_url = self._get_database_url(app)
        if not database_url:
            logger.error("No database URL found")
            return 1

        try:
            manager = AlembicManager(
                database_url=database_url,
                migrations_dir=args.migrations_dir,
            )
            manager.upgrade(args.revision)
            logger.info(f"Database upgraded to: {args.revision}")
            return 0
        except Exception as e:
            logger.error(f"Database upgrade failed: {e}")
            return 1


class DBDowngradeCommand(DBCommand):
    """数据库降级命令"""

    name = "db-downgrade"
    description = "Downgrade database to a given revision"
    aliases = ["downgrade"]

    def add_arguments(self, parser: argparse.ArgumentParser):
        parser.add_argument("--app", "-a", default="app:app", help="Application path")
        parser.add_argument("--revision", "-r", default="-1", help="Target revision (default: -1)")
        parser.add_argument("--migrations-dir", default="migrations", help="Migrations directory")

    def handle(self, args: argparse.Namespace) -> int:
        AlembicManager = self._import_alembic()
        if not AlembicManager:
            return 1

        app = self._load_app(args.app)
        database_url = self._get_database_url(app)
        if not database_url:
            logger.error("No database URL found")
            return 1

        try:
            manager = AlembicManager(
                database_url=database_url,
                migrations_dir=args.migrations_dir,
            )
            manager.downgrade(args.revision)
            logger.info(f"Database downgraded to: {args.revision}")
            return 0
        except Exception as e:
            logger.error(f"Database downgrade failed: {e}")
            return 1


class DBInitCommand(DBCommand):
    """数据库迁移初始化命令"""

    name = "db-init"
    description = "Initialize database migration environment"
    aliases = ["dbinit"]

    def add_arguments(self, parser: argparse.ArgumentParser):
        parser.add_argument("--app", "-a", default="app:app", help="Application path")
        parser.add_argument("--migrations-dir", default="migrations", help="Migrations directory")

    def handle(self, args: argparse.Namespace) -> int:
        AlembicManager = self._import_alembic()
        if not AlembicManager:
            return 1

        app = self._load_app(args.app)
        database_url = self._get_database_url(app) or "sqlite:///app.db"

        try:
            manager = AlembicManager(
                database_url=database_url,
                migrations_dir=args.migrations_dir,
            )
            manager.init()
            logger.info(f"Migration environment initialized at {args.migrations_dir}")
            return 0
        except Exception as e:
            logger.error(f"Migration init failed: {e}")
            return 1


class CLI:
    """
    命令行接口
    """
    
    def __init__(self):
        self.commands: Dict[str, Command] = {}
        self.aliases: Dict[str, str] = {}
        self._register_default_commands()
    
    def _register_default_commands(self):
        """注册默认命令"""
        self.register_command(RunCommand())
        self.register_command(CreateProjectCommand())
        self.register_command(TestCommand())
        self.register_command(ShellCommand())
        self.register_command(RoutesCommand())
        self.register_command(VersionCommand())
        self.register_command(DBMigrateCommand())
        self.register_command(DBUpgradeCommand())
        self.register_command(DBDowngradeCommand())
        self.register_command(DBInitCommand())
    
    def register_command(self, command: Command):
        """注册命令"""
        self.commands[command.name] = command
        
        # 注册别名
        for alias in command.aliases:
            self.aliases[alias] = command.name
    
    def get_command(self, name: str) -> Optional[Command]:
        """获取命令"""
        # 先检查是否是主命令
        if name in self.commands:
            return self.commands[name]
        
        # 检查别名
        if name in self.aliases:
            return self.commands[self.aliases[name]]
        
        return None
    
    def create_parser(self) -> argparse.ArgumentParser:
        """创建参数解析器"""
        parser = argparse.ArgumentParser(
            prog="kewe",
            description="Kewe Framework CLI Tool",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  kewe new myproject          Create a new project
  kewe run                    Run the application
  kewe run --reload           Run with auto-reload
  kewe test                   Run tests
  kewe routes                 List all routes
            """
        )
        
        parser.add_argument(
            "--version",
            action="store_true",
            help="Show version information"
        )
        
        subparsers = parser.add_subparsers(dest="command", help="Available commands")
        
        # 为每个命令创建子解析器
        for name, command in self.commands.items():
            cmd_parser = subparsers.add_parser(
                name,
                help=command.description,
                aliases=command.aliases
            )
            command.add_arguments(cmd_parser)
        
        return parser
    
    def run(self, args: List[str] = None) -> int:
        """运行CLI"""
        parser = self.create_parser()
        parsed_args = parser.parse_args(args)
        
        # 显示版本
        if parsed_args.version:
            return VersionCommand().run(parsed_args)
        
        # 获取命令
        if not parsed_args.command:
            parser.print_help()
            return 0
        
        command = self.get_command(parsed_args.command)
        if command is None:
            logger.error(f"Unknown command: {parsed_args.command}")
            return 1
        
        # 执行命令
        return command.run(parsed_args)


def main(args: List[str] = None) -> int:
    """CLI入口点"""
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s: %(message)s"
    )
    
    cli = CLI()
    return cli.run(args)


if __name__ == "__main__":
    sys.exit(main())




