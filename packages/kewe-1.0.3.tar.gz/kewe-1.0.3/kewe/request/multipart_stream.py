#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Multipart 流式解析器 - Streaming Multipart Parser
multipart解析实现

功能：
- 流式解析 multipart/form-data
- 支持大文件上传
- 低内存占用
"""
import asyncio
import logging
import os
import re
from typing import AsyncGenerator, Dict, List, Optional, Tuple, Any, Callable
from dataclasses import dataclass, field
from pathlib import Path
import tempfile

logger = logging.getLogger(__name__)


@dataclass
class MultipartField:
    """Multipart 字段"""
    name: str
    value: Optional[bytes] = None
    filename: Optional[str] = None
    content_type: str = "text/plain"
    headers: Dict[str, str] = field(default_factory=dict)
    size: int = 0
    temp_file: Optional[str] = None
    
    @property
    def is_file(self) -> bool:
        """是否是文件字段"""
        return self.filename is not None
    
    def get_value(self, encoding: str = 'utf-8') -> str:
        """获取文本值"""
        if self.value is None:
            return ""
        return self.value.decode(encoding)
    
    def save(self, path: str) -> int:
        if self.temp_file and os.path.exists(self.temp_file):
            import shutil
            shutil.copy2(self.temp_file, path)
            return self.size
        if self.value is None:
            return 0
        with open(path, 'wb') as f:
            f.write(self.value)
        return len(self.value)


@dataclass
class MultipartParserConfig:
    """Multipart 解析器配置"""
    max_fields: int = 1000
    max_field_size: int = 1024 * 1024  # 1MB
    max_file_size: int = 100 * 1024 * 1024  # 100MB
    max_header_size: int = 8192  # 8KB
    memory_threshold: int = 2 * 1024 * 1024  # 2MB - 超过此大小使用临时文件
    temp_dir: Optional[str] = None
    keep_temp_files: bool = False


class MultipartParser:
    """
    Multipart 流式解析器
    
    支持流式解析 multipart/form-data 请求体
    
    使用示例:
        parser = MultipartParser(boundary)
        
        async for field in parser.parse(stream):
            if field.is_file:
                await field.save(f"/uploads/{field.filename}")
            else:
                print(f"{field.name}: {field.get_value()}")
    """
    
    def __init__(
        self,
        boundary: str,
        config: MultipartParserConfig = None
    ):
        self.boundary = boundary
        self.config = config or MultipartParserConfig()
        
        self._boundary_bytes = f"--{boundary}".encode()
        self._end_boundary = f"--{boundary}--".encode()
        self._fields: List[MultipartField] = []
        self._current_field: Optional[MultipartField] = None
        self._file_handle = None
        self._cleaned_up = False

    def __del__(self):
        if not self._cleaned_up:
            self.cleanup()
    
    async def parse(
        self,
        stream: AsyncGenerator[bytes, None]
    ) -> AsyncGenerator[MultipartField, None]:
        buffer = bytearray()
        state = "preamble"
        field_count = 0
        max_buffer_size = self.config.max_file_size + self.config.max_header_size + 65536

        try:
            async for chunk in stream:
                buffer.extend(chunk)

                if len(buffer) > max_buffer_size:
                    raise ValueError(f"Buffer too large: {len(buffer)} bytes (max: {max_buffer_size})")

                while True:
                    if state == "preamble":
                        idx = buffer.find(self._boundary_bytes)
                        if idx == -1:
                            if len(buffer) > self.config.max_header_size * 4:
                                buffer = buffer[-(self.config.max_header_size * 2):]
                            break
                        
                        buffer = buffer[idx + len(self._boundary_bytes):]
                        state = "headers"
                    
                    elif state == "headers":
                        header_end = buffer.find(b"\r\n\r\n")
                        if header_end == -1:
                            if len(buffer) > self.config.max_header_size:
                                raise ValueError(f"Header section too large: {len(buffer)} bytes (max: {self.config.max_header_size})")
                            break
                        
                        header_data = buffer[:header_end].decode('utf-8', errors='surrogateescape')
                        buffer = buffer[header_end + 4:]
                        
                        field_count += 1
                        if field_count > self.config.max_fields:
                            raise ValueError(f"Too many fields (max: {self.config.max_fields})")
                        
                        self._current_field = self._parse_headers(header_data)
                        self._current_field.size = 0
                        state = "body"
                    
                    elif state == "body":
                        boundary_idx = buffer.find(b"\r\n" + self._boundary_bytes)
                        
                        if boundary_idx == -1:
                            safe_size = max(0, len(buffer) - len(self._boundary_bytes) - 10)
                            if safe_size > 0:
                                await self._write_field_data(bytes(buffer[:safe_size]))
                                buffer = buffer[safe_size:]
                            break
                        
                        body_data = bytes(buffer[:boundary_idx])
                        await self._write_field_data(body_data)
                        
                        if self._current_field:
                            self._close_current_file_handle()
                            yield self._current_field
                            self._fields.append(self._current_field)
                        
                        buffer = buffer[boundary_idx + 2:]
                        
                        if buffer.startswith(self._end_boundary):
                            return
                        
                        if buffer.startswith(self._boundary_bytes):
                            buffer = buffer[len(self._boundary_bytes):]
                            state = "headers"
            
            if state == "body" and self._current_field:
                await self._write_field_data(bytes(buffer))
                yield self._current_field
        except Exception:
            self._close_current_file_handle()
            raise
    
    def _parse_headers(self, header_data: str) -> MultipartField:
        """解析字段头"""
        name = None
        filename = None
        content_type = "text/plain"
        headers = {}
        
        for line in header_data.split("\r\n"):
            if not line:
                continue
            
            if ":" in line:
                key, value = line.split(":", 1)
                key = key.strip().lower()
                value = value.strip()
                headers[key] = value
                
                if key == "content-disposition":
                    name_match = re.search(r'name="([^"]*)"', value)
                    if name_match:
                        name = name_match.group(1)
                    
                    filename_match = re.search(r'filename="([^"]*)"', value)
                    if filename_match:
                        filename = filename_match.group(1)
                
                elif key == "content-type":
                    content_type = value.split(";")[0].strip()
        
        return MultipartField(
            name=name or "",
            filename=filename,
            content_type=content_type,
            headers=headers
        )
    
    async def _write_field_data(self, data: bytes):
        if not self._current_field:
            return
        
        self._current_field.size += len(data)
        
        if self._current_field.is_file:
            if self._current_field.size > self.config.max_file_size:
                raise ValueError(
                    f"File too large: {self._current_field.size} bytes "
                    f"(max: {self.config.max_file_size})"
                )
        else:
            if self._current_field.size > self.config.max_field_size:
                raise ValueError(
                    f"Field too large: {self._current_field.size} bytes "
                    f"(max: {self.config.max_field_size})"
                )
        
        if self._current_field.size > self.config.memory_threshold:
            if self._current_field.temp_file is None:
                temp_dir = self.config.temp_dir or tempfile.gettempdir()
                fd, temp_path = tempfile.mkstemp(dir=temp_dir)
                os.close(fd)
                self._current_field.temp_file = temp_path
                self._file_handle = open(temp_path, 'wb')
            
            self._file_handle.write(data)
        else:
            if self._current_field.value is None:
                self._current_field.value = data
            else:
                self._current_field.value += data
    
    def _close_current_file_handle(self):
        if self._file_handle is not None:
            try:
                self._file_handle.close()
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)
            self._file_handle = None
    
    def get_fields(self) -> List[MultipartField]:
        """获取所有字段"""
        return self._fields.copy()
    
    def get_field(self, name: str) -> Optional[MultipartField]:
        """获取指定字段"""
        for field in self._fields:
            if field.name == name:
                return field
        return None
    
    def get_files(self) -> List[MultipartField]:
        """获取所有文件字段"""
        return [f for f in self._fields if f.is_file]
    
    def cleanup(self):
        self._close_current_file_handle()
        if not self.config.keep_temp_files:
            for field in self._fields:
                if field.temp_file:
                    try:
                        Path(field.temp_file).unlink()
                    except Exception as e:
                        logger.warning(f"Failed to delete temp file: {e}")
        self._cleaned_up = True


async def parse_multipart_stream(
    stream: AsyncGenerator[bytes, None],
    boundary: str,
    config: MultipartParserConfig = None
) -> Dict[str, Any]:
    """
    解析 multipart 流并返回字段字典
    
    Args:
        stream: 数据流
        boundary: 边界字符串
        config: 解析器配置
        
    Returns:
        包含 fields 和 files 的字典
        
    使用示例:
        result = await parse_multipart_stream(request.stream(), boundary)
        fields = result['fields']
        files = result['files']
    """
    parser = MultipartParser(boundary, config)
    
    fields = {}
    files = {}
    
    async for field in parser.parse(stream):
        if field.is_file:
            if field.name not in files:
                files[field.name] = []
            files[field.name].append(field)
        else:
            if field.name not in fields:
                fields[field.name] = []
            fields[field.name].append(field.get_value())
    
    return {
        'fields': fields,
        'files': files,
        'parser': parser
    }


_BOUNDARY_RE = re.compile(r"^[A-Za-z0-9'()+_,\-./:=? ]{1,70}$")


def extract_boundary(content_type: str) -> Optional[str]:
    if 'multipart/form-data' not in content_type:
        return None

    for part in content_type.split(';'):
        part = part.strip()
        if part.startswith('boundary='):
            boundary = part[9:]
            if boundary.startswith('"') and boundary.endswith('"'):
                boundary = boundary[1:-1]
            if not _BOUNDARY_RE.match(boundary):
                raise ValueError(f"Invalid boundary characters: {boundary!r}")
            return boundary

    return None


class StreamingFormData:
    """
    流式表单数据处理器
    
    用于处理大文件上传
    
    使用示例:
        @app.post("/upload", stream=True)
        async def upload(request):
            boundary = extract_boundary(request.content_type)
            form = StreamingFormData(boundary)
            
            async for chunk in request.stream():
                async for field in form.feed(chunk):
                    if field.is_file:
                        await save_file(field)
            
            return json({"status": "ok"})
    """
    
    def __init__(
        self,
        boundary: str,
        config: MultipartParserConfig = None,
        on_field: Callable[[MultipartField], Any] = None,
        on_file: Callable[[MultipartField, bytes], Any] = None
    ):
        self.boundary = boundary
        self.config = config or MultipartParserConfig()
        self.on_field = on_field
        self.on_file = on_file
        
        self._parser = MultipartParser(boundary, config)
        self._buffer = bytearray()
        self._state = "preamble"
        self._current_field: Optional[MultipartField] = None
    
    async def feed(self, chunk: bytes) -> AsyncGenerator[MultipartField, None]:
        """
        输入数据块
        
        Args:
            chunk: 数据块
            
        Yields:
            完成的字段
        """
        self._buffer.extend(chunk)
        
        async for field in self._process_buffer():
            if field.is_file and self.on_file:
                await self.on_file(field, field.value or b"")
            elif self.on_field:
                await self.on_field(field)
            yield field
    
    async def _process_buffer(self) -> AsyncGenerator[MultipartField, None]:
        """处理缓冲区"""
        while True:
            if self._state == "preamble":
                idx = self._buffer.find(f"--{self.boundary}".encode())
                if idx == -1:
                    break
                
                self._buffer = self._buffer[idx + len(self.boundary) + 2:]
                self._state = "headers"
            
            elif self._state == "headers":
                header_end = self._buffer.find(b"\r\n\r\n")
                if header_end == -1:
                    break
                
                header_data = self._buffer[:header_end].decode('utf-8', errors='surrogateescape')
                self._buffer = self._buffer[header_end + 4:]
                
                self._current_field = self._parser._parse_headers(header_data)
                self._current_field.size = 0
                self._state = "body"
            
            elif self._state == "body":
                boundary_marker = f"\r\n--{self.boundary}".encode()
                idx = self._buffer.find(boundary_marker)
                
                if idx == -1:
                    safe_size = max(0, len(self._buffer) - len(boundary_marker) - 10)
                    if safe_size > 0:
                        data = self._buffer[:safe_size]
                        self._current_field.size += len(data)
                        max_size = self._parser.config.max_file_size if getattr(self._current_field, 'is_file', False) else self._parser.config.max_field_size
                        if self._current_field.size > max_size:
                            raise ValueError(f"Field too large: {self._current_field.size} bytes (max: {max_size})")
                        if self._current_field.value is None:
                            self._current_field.value = data
                        else:
                            self._current_field.value += data
                        self._buffer = self._buffer[safe_size:]
                    break
                
                body_data = self._buffer[:idx]
                self._current_field.size += len(body_data)
                max_size = self._parser.config.max_file_size if getattr(self._current_field, 'is_file', False) else self._parser.config.max_field_size
                if self._current_field.size > max_size:
                    raise ValueError(f"Field too large: {self._current_field.size} bytes (max: {max_size})")
                if self._current_field.value is None:
                    self._current_field.value = body_data
                else:
                    self._current_field.value += body_data
                
                yield self._current_field
                
                self._buffer = self._buffer[idx + len(boundary_marker):]
                
                if self._buffer.startswith(b"--"):
                    self._state = "done"
                    return
                
                self._state = "headers"
    
    async def finish(self) -> AsyncGenerator[MultipartField, None]:
        """
        完成处理
        
        Yields:
            剩余的字段
        """
        if self._buffer and self._current_field:
            self._current_field.size += len(self._buffer)
            if self._current_field.value is None:
                self._current_field.value = self._buffer
            else:
                self._current_field.value += self._buffer
            yield self._current_field


__all__ = [
    'MultipartField',
    'MultipartParserConfig',
    'MultipartParser',
    'parse_multipart_stream',
    'extract_boundary',
    'StreamingFormData',
]



