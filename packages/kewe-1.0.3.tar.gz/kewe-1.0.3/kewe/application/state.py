#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
应用状态管理 - Application State Management

提供完整的状态机管理，支持状态转换监听
"""
import asyncio
import time
import logging
from typing import Optional, Callable, List, Dict, Any, Set
from enum import Enum, auto
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


class AppState(Enum):
    NONE = auto()
    INIT = auto()
    STARTING = auto()
    RUNNING = auto()
    STOPPING = auto()
    STOPPED = auto()
    RELOADING = auto()


class ServerState(Enum):
    IDLE = auto()
    STARTING = auto()
    RUNNING = auto()
    STOPPING = auto()
    STOPPED = auto()


@dataclass
class StateTransition:
    from_state: Enum
    to_state: Enum
    reason: Optional[str] = None
    timestamp: float = field(default_factory=time.time)


class StateManager:

    def __init__(self, initial_state: Enum = AppState.NONE):
        self._state = initial_state
        self._transitions: List[StateTransition] = []
        self._listeners: Dict[Enum, List[Callable]] = {}
        self._any_listeners: List[Callable] = []
        self._transition_hooks: Dict[tuple, List[Callable]] = {}
        self._active_tasks: set = set()

    def _create_tracked_task(self, coro):
        task = asyncio.create_task(coro)
        self._active_tasks.add(task)

        def _on_done(t):
            self._active_tasks.discard(t)
            if t.exception():
                logger.error(f"Async state callback error: {t.exception()}")

        task.add_done_callback(_on_done)
        return task

    @property
    def state(self) -> Enum:
        return self._state

    @property
    def is_running(self) -> bool:
        return self._state in (AppState.RUNNING, ServerState.RUNNING)

    @property
    def is_stopped(self) -> bool:
        return self._state in (AppState.STOPPED, ServerState.STOPPED)

    def transition_to(self, new_state: Enum, reason: str = None) -> bool:
        if self._state == new_state:
            return True

        old_state = self._state

        transition = StateTransition(
            from_state=old_state,
            to_state=new_state,
            reason=reason
        )
        self._transitions.append(transition)

        hook_key = (old_state, new_state)
        if hook_key in self._transition_hooks:
            for hook in self._transition_hooks[hook_key]:
                try:
                    if asyncio.iscoroutinefunction(hook):
                        self._create_tracked_task(hook(old_state, new_state, reason))
                    else:
                        hook(old_state, new_state, reason)
                except Exception as e:
                    logger.error(f"State transition hook error: {e}")

        self._state = new_state

        logger.debug(f"State transition: {old_state.name} -> {new_state.name} ({reason or 'no reason'})")

        self._notify_listeners(old_state, new_state, reason)

        return True

    def _notify_listeners(self, old_state: Enum, new_state: Enum, reason: str):
        if new_state in self._listeners:
            for listener in self._listeners[new_state]:
                try:
                    if asyncio.iscoroutinefunction(listener):
                        self._create_tracked_task(listener(old_state, new_state, reason))
                    else:
                        listener(old_state, new_state, reason)
                except Exception as e:
                    logger.error(f"State listener error: {e}")

        for listener in self._any_listeners:
            try:
                if asyncio.iscoroutinefunction(listener):
                    self._create_tracked_task(listener(old_state, new_state, reason))
                else:
                    listener(old_state, new_state, reason)
            except Exception as e:
                logger.error(f"State listener error: {e}")

    def on_state(self, state: Enum, listener: Callable):
        if state not in self._listeners:
            self._listeners[state] = []
        self._listeners[state].append(listener)

    def on_any_state(self, listener: Callable):
        self._any_listeners.append(listener)

    def on_transition(self, from_state: Enum, to_state: Enum, hook: Callable):
        key = (from_state, to_state)
        if key not in self._transition_hooks:
            self._transition_hooks[key] = []
        self._transition_hooks[key].append(hook)

    def get_transitions(self) -> List[StateTransition]:
        return self._transitions.copy()

    def get_state_duration(self) -> float:
        if not self._transitions:
            return 0.0
        last_transition = self._transitions[-1]
        return time.time() - last_transition.timestamp


class ApplicationStateManager(StateManager):

    def __init__(self):
        super().__init__(AppState.NONE)
        self.server_state = StateManager(ServerState.IDLE)
        self._setup_default_transitions()

    def _setup_default_transitions(self):
        self.on_transition(AppState.NONE, AppState.INIT, self._on_init)
        self.on_transition(AppState.INIT, AppState.STARTING, self._on_starting)
        self.on_transition(AppState.STARTING, AppState.RUNNING, self._on_running)

        self.on_transition(AppState.RUNNING, AppState.STOPPING, self._on_stopping)
        self.on_transition(AppState.STOPPING, AppState.STOPPED, self._on_stopped)

        self.on_transition(AppState.RUNNING, AppState.RELOADING, self._on_reloading)
        self.on_transition(AppState.RELOADING, AppState.RUNNING, self._on_reload_complete)

    def _on_init(self, old, new, reason):
        logger.info("Application initializing...")

    def _on_starting(self, old, new, reason):
        logger.info("Application starting...")

    def _on_running(self, old, new, reason):
        logger.info("Application is running")

    def _on_stopping(self, old, new, reason):
        logger.info("Application stopping...")

    def _on_stopped(self, old, new, reason):
        logger.info("Application stopped")

    def _on_reloading(self, old, new, reason):
        logger.info("Application reloading...")

    def _on_reload_complete(self, old, new, reason):
        logger.info("Application reload complete")

    async def start(self):
        if self.state != AppState.NONE:
            logger.warning(f"Cannot start from state {self.state}")
            return False

        self.transition_to(AppState.INIT, "Application initialization")
        self.transition_to(AppState.STARTING, "Application starting")

        await asyncio.sleep(0.1)

        self.transition_to(AppState.RUNNING, "Application started successfully")
        return True

    async def stop(self, reason: str = None):
        if self.state not in (AppState.RUNNING, AppState.RELOADING):
            logger.warning(f"Cannot stop from state {self.state}")
            return False

        self.transition_to(AppState.STOPPING, reason or "Application stopping")

        await asyncio.sleep(0.1)

        self.transition_to(AppState.STOPPED, "Application stopped")
        return True

    async def reload(self):
        if self.state != AppState.RUNNING:
            logger.warning(f"Cannot reload from state {self.state}")
            return False

        self.transition_to(AppState.RELOADING, "Application reloading")

        await asyncio.sleep(0.1)

        self.transition_to(AppState.RUNNING, "Application reload complete")
        return True

    def get_status(self) -> Dict[str, Any]:
        return {
            'app_state': self.state.name,
            'server_state': self.server_state.state.name,
            'is_running': self.is_running,
            'state_duration': self.get_state_duration(),
            'transitions': len(self._transitions)
        }


def create_state_manager(initial_state: Enum = AppState.NONE) -> StateManager:
    return StateManager(initial_state)


def create_app_state_manager() -> ApplicationStateManager:
    return ApplicationStateManager()
