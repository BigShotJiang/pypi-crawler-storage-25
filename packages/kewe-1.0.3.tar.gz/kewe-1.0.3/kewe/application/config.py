#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
统一配置系统 - Unified Configuration System
config.py实现

提供统一的配置管理，支持环境变量、配置文件、代码设置等多种方式
"""
import os
from kewe.utils.compat import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional, Union, List, Callable
from dataclasses import dataclass, field, asdict

logger = logging.getLogger(__name__)


class Config(dict):
    """
    配置类 - 支持多种配置来源
    
    使用示例:
        config = Config()
        config.DB_HOST = "localhost"
        config.DB_PORT = 5432
        
        # 从环境变量加载
        config.load_from_env()
        
        # 从文件加载
        config.load_from_file("config.json")
    """
    
    def __init__(self, defaults: Dict[str, Any] = None):
        super().__init__()
        self._defaults = defaults or {}
        self._validators: Dict[str, Callable] = {}
        self._priority: Dict[str, int] = {}  # 配置项优先级
        self.update(self._defaults, priority=0)
        
    def __getattr__(self, name: str) -> Any:
        """支持通过属性访问配置"""
        try:
            return self[name]
        except KeyError:
            raise AttributeError(f"Config has no attribute '{name}'")
    
    def __setattr__(self, name: str, value: Any):
        """支持通过属性设置配置"""
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            self[name] = value
    
    def add_validator(self, key: str, validator: Callable[[Any], bool]):
        """
        添加配置验证器
        
        Args:
            key: 配置键
            validator: 验证函数，返回True表示验证通过
        """
        self._validators[key] = validator
    
    def validate(self) -> bool:
        """
        验证配置
        
        Returns:
            是否验证通过
        """
        valid = True
        for key, validator in self._validators.items():
            if key in self:
                try:
                    if not validator(self[key]):
                        logger.error(f"Config validation failed for {key}: {self[key]}")
                        valid = False
                except Exception as e:
                    logger.error(f"Error validating config {key}: {e}")
                    valid = False
        return valid
    
    def update(self, other: Dict[str, Any], priority: int = 1):
        """
        更新配置
        
        Args:
            other: 配置字典
            priority: 优先级，高优先级会覆盖低优先级
        """
        for key, value in other.items():
            # 只有当新配置的优先级高于或等于现有配置时才更新
            if key not in self._priority or priority >= self._priority.get(key, 0):
                self[key] = value
                self._priority[key] = priority
    
    def __setitem__(self, key: str, value: Any):
        """设置配置项 - 直接赋值使用最高优先级(10)，可覆盖任何来源"""
        existing_priority = self._priority.get(key, 0)
        new_priority = 10
        if new_priority >= existing_priority:
            super().__setitem__(key, value)
            self._priority[key] = new_priority
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取配置项"""
        return super().get(key, default)
    
    def get_nested(self, key: str, default: Any = None, separator: str = ".") -> Any:
        """
        获取嵌套配置项
        
        Args:
            key: 嵌套键，使用点号分隔，如 "DB.HOST"
            default: 默认值
            separator: 分隔符
        
        Returns:
            配置值
        """
        keys = key.split(separator)
        value = self
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set_nested(self, key: str, value: Any, separator: str = ".", priority: int = 1) -> None:
        """
        设置嵌套配置项
        
        Args:
            key: 嵌套键，使用点号分隔，如 "DB.HOST"
            value: 配置值
            separator: 分隔符
            priority: 优先级
        """
        keys = key.split(separator)
        config = self
        
        # 遍历到最后一个键之前
        for k in keys[:-1]:
            if k not in config or not isinstance(config[k], dict):
                config[k] = {}
                # 设置优先级
                if k not in self._priority:
                    self._priority[k] = priority
            config = config[k]
        
        # 设置最后一个键
        config[keys[-1]] = value
        # 设置优先级
        full_key = separator.join(keys)
        if full_key not in self._priority:
            self._priority[full_key] = priority
    
    def load_from_env(self, prefix: str = "KEWE_", separator: str = "__", priority: int = 3, load_dotenv: bool = True) -> None:
        """
        从环境变量加载配置
        
        支持嵌套配置，使用双下划线分隔
        例如: KEWE_DB__HOST=localhost 会设置为 {"DB": {"HOST": "localhost"}}
        
        Args:
            prefix: 环境变量前缀
            separator: 嵌套键的分隔符
            priority: 优先级，默认3（最高）
            load_dotenv: 是否自动加载.env文件（默认True）
        """
        if load_dotenv:
            try:
                from dotenv import load_dotenv as _load_dotenv
                _load_dotenv()
                logger.debug("Loaded .env file via python-dotenv")
            except ImportError:
                pass
        
        loaded = 0
        config_dict = {}
        
        for key, value in os.environ.items():
            if key.startswith(prefix):
                config_key = key[len(prefix):]
                
                # 尝试解析类型
                parsed_value = self._parse_value(value)
                
                # 处理嵌套配置
                if separator in config_key:
                    parts = config_key.split(separator)
                    current = config_dict
                    for part in parts[:-1]:
                        if part not in current:
                            current[part] = {}
                        current = current[part]
                    current[parts[-1]] = parsed_value
                else:
                    config_dict[config_key] = parsed_value
                
                loaded += 1
        
        # 使用update方法更新配置，设置优先级
        if config_dict:
            self.update(config_dict, priority=priority)
        
        logger.debug(f"Loaded {loaded} config from environment")
    
    def load_from_file(self, path: Union[str, Path], priority: int = 2, *, silent: bool = False) -> None:
        """
        从文件加载配置
        
        支持JSON、YAML、TOML格式
        
        Args:
            path: 配置文件路径
            priority: 优先级，默认2（高于默认值，低于环境变量）
            silent: 如果为True，文件不存在时不抛异常
        """
        path = Path(path)
        
        if not path.exists():
            if silent:
                return
            raise FileNotFoundError(f"Config file not found: {path}")
        
        suffix = path.suffix.lower()
        
        if suffix == '.json':
            data = self._load_json(path)
        elif suffix in ('.yaml', '.yml'):
            data = self._load_yaml(path)
        elif suffix == '.toml':
            data = self._load_toml(path)
        elif suffix == '.py':
            data = self._load_python(path)
        else:
            raise ValueError(f"Unsupported config file format: {suffix}")
        
        # 使用update方法更新配置，设置优先级
        if data:
            self.update(data, priority=priority)
    
    def from_envvar(self, variable_name: str, silent: bool = False) -> bool:
        """从环境变量指定的文件路径加载配置"""
        file_path = os.environ.get(variable_name)
        if not file_path:
            if silent:
                return False
            raise RuntimeError(f"Environment variable '{variable_name}' is not set")
        self.load_from_file(file_path, silent=silent)
        return True
    
    def from_object(self, obj: Union[str, object]) -> None:
        """从 Python 对象加载配置（提取大写属性）"""
        if isinstance(obj, str):
            import importlib
            module_path, _, obj_name = obj.rpartition('.')
            module = importlib.import_module(module_path)
            obj = getattr(module, obj_name)
        for key in dir(obj):
            if key.isupper():
                self[key] = getattr(obj, key)
    
    def from_pyfile(self, filename: Union[str, Path], silent: bool = False) -> bool:
        """从 Python 文件加载配置"""
        path = Path(filename)
        if not path.exists():
            if silent:
                return False
            raise FileNotFoundError(f"Config file not found: {path}")
        data = self._load_python(path)
        if data:
            self.update(data, priority=2)
        return True
    
    def discover_config(self, name: str = "config", priority: int = 2) -> bool:
        """
        自动发现配置文件
        
        按以下顺序查找：
        1. 当前目录
        2. config目录
        3. ../config目录
        4. /etc/kewe
        
        支持的扩展名：.json, .yaml, .yml, .toml, .py
        
        Args:
            name: 配置文件名（不含扩展名）
            priority: 优先级
        
        Returns:
            是否找到并加载配置文件
        """
        extensions = ['.json', '.yaml', '.yml', '.toml', '.py']
        search_paths = [
            Path.cwd(),
            Path.cwd() / "config",
            Path.cwd().parent / "config",
            Path("/etc/kewe")
        ]
        
        for path in search_paths:
            if not path.exists() or not path.is_dir():
                continue
            
            for ext in extensions:
                config_path = path / f"{name}{ext}"
                if config_path.exists():
                    try:
                        self.load_from_file(config_path, priority=priority)
                        logger.info(f"Discovered config file: {config_path}")
                        return True
                    except Exception as e:
                        logger.warning(f"Error loading config file {config_path}: {e}")
                        continue
        
        logger.debug("No config file discovered")
        return False
    
    def _load_json(self, path: Path) -> Dict[str, Any]:
        """加载JSON配置"""
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        logger.debug(f"Loaded config from JSON: {path}")
        return data
    
    def _load_yaml(self, path: Path) -> Dict[str, Any]:
        """加载YAML配置（可选依赖）"""
        try:
            import yaml
            with open(path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            logger.debug(f"Loaded config from YAML: {path}")
            return data or {}
        except ImportError:
            logger.error(
                "PyYAML is required for YAML config files. "
                "Install with: pip install pyyaml"
            )
            raise
    
    def _load_toml(self, path: Path) -> Dict[str, Any]:
        try:
            import tomllib
        except ImportError:
            try:
                import tomli as tomllib
            except ImportError:
                raise ImportError(
                    "TOML support requires Python 3.11+ or 'tomli' package. "
                    "Install with: pip install tomli"
                )
        with open(path, 'rb') as f:
            data = tomllib.load(f)
        logger.debug(f"Loaded config from TOML: {path}")
        return data
    
    def _load_python(self, path: Path) -> Dict[str, Any]:
        """加载Python配置"""
        import importlib.util
        
        spec = importlib.util.spec_from_file_location("config", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        # 提取大写的配置项
        config_dict = {}
        for key in dir(module):
            if key.isupper() and not key.startswith('_'):
                config_dict[key] = getattr(module, key)
        
        logger.debug(f"Loaded config from Python: {path}")
        return config_dict
    
    def _parse_value(self, value: str) -> Any:
        """解析配置值，自动检测类型"""
        # 尝试解析为布尔值
        if value.lower() in ('true', 'yes'):
            return True
        if value.lower() in ('false', 'no'):
            return False
        
        # 尝试解析为整数
        try:
            return int(value)
        except ValueError:
            pass
        
        # 尝试解析为浮点数
        try:
            return float(value)
        except ValueError:
            pass
        
        # 尝试解析为JSON
        try:
            return json.loads(value)
        except (ValueError, Exception):
            logger.debug("Non-critical operation failed", exc_info=True)
        
        # 默认返回字符串
        return value
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return dict(self)
    
    def to_json(self, indent: int = 2) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), indent=indent, default=str)
    
    def save_to_file(self, path: Union[str, Path]):
        """保存配置到文件"""
        path = Path(path)
        
        with open(path, 'w', encoding='utf-8') as f:
            if path.suffix == '.json':
                json.dump(self.to_dict(), f, indent=2, default=str)
            else:
                # 简单的key=value格式
                for key, value in self.items():
                    f.write(f"{key}={value}\n")


@dataclass
class KeweConfig:
    """
    Kewe应用配置
    
    提供类型安全的配置项
    """
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 1
    debug: bool = False
    
    access_log: bool = True
    log_level: int = logging.INFO
    log_json: bool = False
    
    auto_optimize: bool = True
    use_uvloop: bool = True
    
    request_timeout: float = 60.0
    graceful_timeout: float = 10.0
    keep_alive: bool = True
    keep_alive_timeout: float = 5.0
    request_max_size: int = 100 * 1024 * 1024
    
    request_max_size_json: int = 10 * 1024 * 1024
    request_max_size_form: int = 50 * 1024 * 1024
    request_max_size_multipart: int = 100 * 1024 * 1024
    
    enable_gateway: bool = True
    gateway_prefix: str = ""
    
    request_id_header: str = "X-Request-ID"
    request_id_format: str = "uuid"
    auto_request_id: bool = True
    auto_health_check: bool = True
    health_check_path: str = "/health"
    
    enable_security_headers: bool = True
    enable_compression: bool = True
    compression_min_size: int = 500
    compression_level: int = 6
    
    secret_key: Optional[str] = None
    
    environment: str = "development"
    env_config_paths: Dict[str, str] = field(default_factory=lambda: {
        "development": "config/development.toml",
        "testing": "config/testing.toml",
        "staging": "config/staging.toml",
        "production": "config/production.toml",
    })
    
    show_banner: bool = True
    
    extra: Dict[str, Any] = field(default_factory=dict)
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取配置项 - 兼容 dict 接口（大写键名自动映射到小写字段）"""
        normalized = self._normalize_key(key)
        if hasattr(self, normalized) and normalized in self.__dataclass_fields__:
            return getattr(self, normalized)
        if key in self.extra:
            return self.extra[key]
        if normalized != key and normalized in self.extra:
            return self.extra[normalized]
        return default
    
    def _normalize_key(self, key: str) -> str:
        if key.isupper() and hasattr(self, key.lower()) and key.lower() in self.__dataclass_fields__:
            return key.lower()
        return key

    def __getitem__(self, key: str) -> Any:
        """支持 dict 风格访问（大写键名自动映射到小写字段）"""
        normalized = self._normalize_key(key)
        if hasattr(self, normalized) and normalized in self.__dataclass_fields__:
            return getattr(self, normalized)
        if key in self.extra:
            return self.extra[key]
        if normalized != key and normalized in self.extra:
            return self.extra[normalized]
        raise KeyError(key)

    def __setitem__(self, key: str, value: Any):
        """支持 dict 风格赋值 — （大写键名自动映射到小写字段）"""
        normalized = self._normalize_key(key)
        if hasattr(self, normalized) and normalized in self.__dataclass_fields__:
            setattr(self, normalized, value)
        else:
            self.extra[key] = value

    def __delitem__(self, key: str):
        """支持 dict 风格删除"""
        if key in self.extra:
            del self.extra[key]
        elif hasattr(self, key) and key in self.__dataclass_fields__:
            raise KeyError(f"Cannot delete dataclass field: {key}")
        else:
            raise KeyError(key)

    def __contains__(self, key: str) -> bool:
        normalized = self._normalize_key(key)
        return (hasattr(self, normalized) and normalized in self.__dataclass_fields__) or key in self.extra

    def keys(self):
        result = list(self.__dataclass_fields__.keys())
        result.extend(self.extra.keys())
        return result

    def values(self):
        result = [getattr(self, f) for f in self.__dataclass_fields__]
        result.extend(self.extra.values())
        return result

    def items(self):
        result = [(f, getattr(self, f)) for f in self.__dataclass_fields__]
        result.extend(self.extra.items())
        return result

    def update(self, data=None, **kwargs):
        if data:
            if hasattr(data, 'items'):
                for k, v in data.items():
                    self[k] = v
            else:
                for k, v in data:
                    self[k] = v
        for k, v in kwargs.items():
            self[k] = v

    def pop(self, key: str, *args):
        if key in self.extra:
            return self.extra.pop(key)
        normalized = self._normalize_key(key)
        if normalized in self.extra:
            return self.extra.pop(normalized)
        if args:
            return args[0]
        raise KeyError(key)

    def __len__(self):
        return len(self.__dataclass_fields__) + len(self.extra)

    def to_config(self) -> Config:
        """转换为Config对象"""
        config = Config()
        config.update(asdict(self))
        return config
    
    @classmethod
    def from_config(cls, config: Config) -> 'KeweConfig':
        """从Config对象创建"""
        # 提取已知配置项
        known_fields = {f.name for f in cls.__dataclass_fields__.values()}
        kwargs = {k: v for k, v in config.items() if k in known_fields}
        extra = {k: v for k, v in config.items() if k not in known_fields}
        
        return cls(**kwargs, extra=extra)
    
    def load_from_env(self, prefix: str = "KEWE_"):
        config = Config()
        config.load_from_env(prefix=prefix)
        self._apply_config(config)

    def load_for_environment(self, env: Optional[str] = None):
        """根据环境名称加载对应配置文件

        Args:
            env: 环境名称，如 development/testing/staging/production。
                 如果为None则使用self.environment
        """
        env = env or self.environment
        self.environment = env

        config_path = self.env_config_paths.get(env)
        if config_path is None:
            logger.warning(f"No config path defined for environment: {env}")
            return

        path = Path(config_path)
        if path.exists():
            config = Config()
            config.load_from_file(path, priority=2)
            self._apply_config(config)
            logger.info(f"Loaded config for environment: {env} from {path}")
        else:
            logger.debug(f"Config file not found for environment {env}: {path}")
    
    def load_from_file(self, path, **kwargs):
        config = Config()
        config.load_from_file(path, **kwargs)
        self._apply_config(config)
    
    def from_pyfile(self, filename, **kwargs):
        config = Config()
        config.from_pyfile(filename, **kwargs)
        self._apply_config(config)
    
    def from_object(self, obj):
        config = Config()
        config.from_object(obj)
        self._apply_config(config)
    
    def from_envvar(self, variable_name, **kwargs):
        config = Config()
        result = config.from_envvar(variable_name, **kwargs)
        self._apply_config(config)
        return result
    
    def _apply_config(self, config):
        for key, value in config.items():
            attr_name = key.lower()
            if hasattr(self, attr_name) and attr_name in self.__dataclass_fields__:
                field_type = self.__dataclass_fields__[attr_name].type
                try:
                    if field_type == 'int' or field_type is int:
                        value = int(value)
                    elif field_type == 'float' or field_type is float:
                        value = float(value)
                    elif field_type == 'bool' or field_type is bool:
                        if isinstance(value, str):
                            value = value.lower() in ('true', '1', 'yes')
                        else:
                            value = bool(value)
                except (ValueError, TypeError):
                    pass
                setattr(self, attr_name, value)
            else:
                self.extra[key] = value


def load_config(
    path: Union[str, Path] = None,
    env_prefix: str = "KEWE_",
    defaults: Dict[str, Any] = None
) -> Config:
    """
    加载配置的便捷函数
    
    加载顺序: 默认值 -> 配置文件 -> 环境变量
    
    示例:
        config = load_config("config.json", env_prefix="APP_")
    """
    config = Config(defaults)
    
    # 加载配置文件
    if path:
        config.load_from_file(path)
    
    # 加载环境变量
    config.load_from_env(prefix=env_prefix)
    
    return config


# 全局配置实例
_config: Optional[Config] = None


def get_config() -> Config:
    """获取全局配置实例"""
    global _config
    if _config is None:
        _config = Config()
    return _config


def set_config(config: Config):
    """设置全局配置实例"""
    global _config
    _config = config


__all__ = [
    'Config',
    'KeweConfig',
    'load_config',
    'get_config',
    'set_config',
]
