#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
便捷Mixins - 提供便捷的API注册方式
mixins.py实现
"""
import asyncio
import logging
import ssl
from typing import Callable, Dict, List, Optional, Union, Any
from functools import wraps

logger = logging.getLogger(__name__)


class RouteMixin:
    """
    路由Mixin - 提供便捷的路由注册方式
    
    RouteMixin实现
    支持 API 版本控制
    """
    
    def route(
        self,
        path: str,
        methods: Optional[List[str]] = None,
        **kwargs
    ):
        raise NotImplementedError(
            f"{type(self).__name__}.route() must be implemented by the application class. "
            "If you are using RouteMixin standalone, provide a route() method."
        )
    
    def get(self, path: str, **kwargs):
        return self.route(path, methods=["GET"], **kwargs)
    
    def post(self, path: str, **kwargs):
        return self.route(path, methods=["POST"], **kwargs)
    
    def put(self, path: str, **kwargs):
        return self.route(path, methods=["PUT"], **kwargs)
    
    def delete(self, path: str, **kwargs):
        return self.route(path, methods=["DELETE"], **kwargs)
    
    def patch(self, path: str, **kwargs):
        return self.route(path, methods=["PATCH"], **kwargs)
    
    def head(self, path: str, **kwargs):
        return self.route(path, methods=["HEAD"], **kwargs)
    
    def options(self, path: str, **kwargs):
        return self.route(path, methods=["OPTIONS"], **kwargs)
    
    def add_route(
        self,
        handler: Callable,
        path: str,
        methods: List[str] = None,
        **kwargs
    ):
        if methods is None:
            if hasattr(handler, '_view_class'):
                methods = handler._view_class._get_allowed_methods()
            else:
                methods = ["GET"]
        return self.router.add_route(path=path, methods=methods, handler=handler, **kwargs)
    
    def _apply_version(self, path: str, version: Optional[Union[int, str]] = None, 
                       version_prefix: str = "v") -> str:
        if version is None:
            return path
        
        version_str = str(version)
        return f"/{version_prefix}{version_str}{path}"


class MiddlewareMixin:
    """
    中间件Mixin - 提供便捷的中间件注册方式
    
    统一洋葱中间件模式，所有中间件最终都转换为洋葱模式执行。
    """
    
    def middleware(self, func_or_type: Union[Callable, str] = None, *, middleware_type: Optional[str] = None, priority: int = 50):
        """
        统一中间件注册入口

        支持三种模式:
            1. 洋葱中间件 (默认): @app.middleware() 或 @app.middleware(middleware_type="onion")
            2. 请求中间件: @app.middleware(middleware_type="request")
            3. 响应中间件: @app.middleware(middleware_type="response")
        """
        actual_type = middleware_type or "onion"
        if callable(func_or_type) and not isinstance(func_or_type, str):
            return self._register_middleware(func_or_type, actual_type, priority)

        if isinstance(func_or_type, str):
            actual_type = func_or_type

        if actual_type == "http":
            actual_type = "onion"

        def decorator(f: Callable) -> Callable:
            return self._register_middleware(f, actual_type, priority)
        return decorator
    
    def _register_middleware(self, func: Callable, middleware_type: str = "onion", priority: int = 50):
        """注册中间件 - 统一转换为洋葱模式"""
        import inspect
        from kewe.middleware.core import OnionMiddleware

        sig = inspect.signature(func)
        param_count = len([p for p in sig.parameters.values()
                          if p.default is inspect.Parameter.empty
                          and p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)])

        if middleware_type == "onion" and param_count < 2:
            middleware_type = "request"

        if hasattr(self, '_onion_chain'):
            if middleware_type == "onion":
                self._onion_chain.add(OnionMiddleware(func, priority=priority))
            elif middleware_type == "request":
                async def _request_as_onion(request, call_next):
                    if param_count == 0:
                        result = func()
                    else:
                        result = func(request)
                    if inspect.isawaitable(result):
                        result = await result
                    from kewe.response.response import Response
                    if isinstance(result, Response):
                        request.ctx._short_circuit_response = result
                        return await call_next(request)
                    if result is False:
                        from kewe.response import json as _json
                        request.ctx._short_circuit_response = _json({"error": "Request rejected by middleware"}, status=403)
                        return await call_next(request)
                    if result is not None and result is not True:
                        from kewe.response import json as _json
                        request.ctx._short_circuit_response = _json(result, status=200)
                        return await call_next(request)
                    return await call_next(request)
                self._onion_chain.add(OnionMiddleware(_request_as_onion, priority=priority))
            elif middleware_type == "response":
                async def _response_as_onion(request, call_next):
                    response = await call_next(request)
                    if param_count <= 1:
                        result = func(response)
                    else:
                        result = func(request, response)
                    if inspect.isawaitable(result):
                        result = await result
                    from kewe.response.response import Response
                    if isinstance(result, Response):
                        return result
                    return response
                self._onion_chain.add(OnionMiddleware(_response_as_onion, priority=priority))
            else:
                raise ValueError(f"Invalid middleware type: {middleware_type!r}. "
                               f"Must be 'onion', 'request', or 'response'")
        elif hasattr(self, 'middleware_manager'):
            self.middleware_manager.register(func, attach_to=middleware_type, priority=priority)
        return func
    
    def on_request(self, func_or_middleware: Callable = None, *, priority: int = 50):
        """
        请求中间件快捷方式

        使用示例:
            @app.on_request
            async def check_auth(request):
                if request.path.startswith("/admin"):
                    token = request.headers.get("Authorization")
                    if not token:
                        raise Unauthorized("Missing token")
        """
        if func_or_middleware is not None:
            return self._register_middleware(func_or_middleware, "request", priority)

        def decorator(f: Callable) -> Callable:
            return self._register_middleware(f, "request", priority)
        return decorator

    def on_response(self, func_or_middleware: Callable = None, *, priority: int = 50):
        """
        响应中间件快捷方式

        使用示例:
            @app.on_response
            async def add_headers(request, response):
                response.headers["X-API-Version"] = "1.0"
        """
        if func_or_middleware is not None:
            return self._register_middleware(func_or_middleware, "response", priority)

        def decorator(f: Callable) -> Callable:
            return self._register_middleware(f, "response", priority)
        return decorator

    def before_request(self, func: Callable = None, *, priority: int = 50):
        """
        请求前钩子 - before_request

        在请求处理前执行，返回非None值时中断请求处理。

        使用示例:
            @app.before_request
            async def check_auth(request):
                if request.path.startswith("/admin"):
                    token = request.headers.get("Authorization")
                    if not token:
                        return json({"error": "Unauthorized"}, status=401)
        """
        return self.on_request(func, priority=priority)

    def after_request(self, func: Callable = None, *, priority: int = 50):
        """
        请求后钩子 - after_request

        在请求处理后执行，可以修改响应对象。

        使用示例:
            @app.after_request
            async def add_headers(request, response):
                response.headers["X-API-Version"] = "1.0"
                return response
        """
        return self.on_response(func, priority=priority)


class ExceptionMixin:
    """
    异常处理Mixin - 提供便捷的异常处理器注册方式
    
    KeWe 使用 @app.exception() 装饰器和 app.register_error_handler() 函数式API
    作为统一的异常处理器注册方式。
    """
    
    def exception(self, status_code_or_type):
        def decorator(handler):
            if isinstance(status_code_or_type, int):
                if hasattr(self, 'error_handlers'):
                    self.error_handlers[status_code_or_type] = handler
                if hasattr(self, 'middleware_manager'):
                    self.middleware_manager.register_status_code_handler(status_code_or_type, handler)
            elif isinstance(status_code_or_type, type) and issubclass(status_code_or_type, BaseException):
                if hasattr(self, 'middleware_manager'):
                    self.middleware_manager.register_error_handler(status_code_or_type, handler)
            else:
                raise TypeError(f"Expected int status code or Exception subclass, got {type(status_code_or_type)}")
            return handler
        return decorator


class ListenerMixin:
    """
    监听器Mixin - 提供服务器生命周期事件监听
    
    ListenerMixin实现
    """
    
    def before_server_start(self, listener: Callable = None):
        return self._register_listener("before_server_start", listener)
    
    def after_server_start(self, listener: Callable = None):
        return self._register_listener("after_server_start", listener)
    
    def before_server_stop(self, listener: Callable = None):
        return self._register_listener("before_server_stop", listener)
    
    def after_server_stop(self, listener: Callable = None):
        return self._register_listener("after_server_stop", listener)
    
    def _register_listener(self, event: str, listener: Callable = None):
        if hasattr(self, 'middleware_manager'):
            event_map = {
                'before_server_start': self.middleware_manager.register_before_server_start,
                'after_server_start': self.middleware_manager.register_after_server_start,
                'before_server_stop': self.middleware_manager.register_before_server_stop,
                'after_server_stop': self.middleware_manager.register_after_server_stop,
            }
            register_fn = event_map.get(event)
            if register_fn is None:
                raise ValueError(f"Unknown event '{event}', must be one of: {list(event_map.keys())}")
            if listener is not None:
                register_fn(listener)
                return listener
            def decorator(fn):
                register_fn(fn)
                return fn
            return decorator

        if not hasattr(self, '_listeners'):
            self._listeners = {}
        if event not in self._listeners:
            self._listeners[event] = []

        def decorator(fn):
            self._listeners[event].append(fn)
            return fn

        if listener is None:
            return decorator
        else:
            return decorator(listener)
    
    def register_listener(self, event: str, listener: Callable = None):
        return self._register_listener(event, listener)


class StaticMixin:
    
    def static(
        self,
        uri: str,
        file_or_directory: str,
        name: str = "static",
        allow_directory_listing: bool = False,
        index: str = None,
        **kwargs
    ):
        from kewe.handlers.static_serve import register_static
        kwargs.setdefault('index_file', index)
        kwargs.setdefault('allow_directory_listing', allow_directory_listing)
        register_static(self, uri, file_or_directory, name=name, **kwargs)


class SignalMixin:
    """
    信号Mixin - 提供信号系统支持
    
    SignalMixin实现
    """
    
    def signal(self, event: str, condition: dict = None, exclusive: bool = True):
        """
        信号装饰器
        
        注册信号处理器到信号总线。支持动态信号模式匹配。
        """
        def decorator(handler):
            from kewe.application.signals import DynamicSignal
            if '.' in event and '<' in event:
                if not hasattr(self, '_dynamic_signals'):
                    self._dynamic_signals = {}
                if event not in self._dynamic_signals:
                    self._dynamic_signals[event] = DynamicSignal(event)
                self._dynamic_signals[event].register(handler)
            else:
                bus = getattr(self, 'signal_bus', None)
                if bus is None:
                    raise RuntimeError(
                        "signal_bus not found on instance. "
                        "Ensure the application is properly initialized before registering signals."
                    )
                bus.on(event, handler)
            return handler
        return decorator
    
    def event(self, event: str):
        """等待事件"""
        waiter = getattr(self, '_event_waiter', None)
        if waiter is not None:
            return waiter.wait_for(event)
        from kewe.application.signals import EventWaiter
        waiter = EventWaiter()
        return waiter.wait_for(event)


class GatewayMixin:
    """
    网关Mixin - 提供API网关路由注册
    
    将网关相关方法从Kewe类中拆分出来
    """
    
    def api_route(
        self,
        path: str,
        methods: Optional[List[str]] = None,
        *,
        version: str = "v1",
        name: Optional[str] = None,
        **kwargs
    ) -> Callable[[Callable], Callable]:
        """
        API网关路由装饰器
        """
        def decorator(handler: Callable) -> Callable:
            if self.gateway:
                full_path = f"{self.config.gateway_prefix}{path}"
                self.gateway.route(
                    full_path,
                    method=methods[0] if methods else "GET",
                    version=version,
                    name=name,
                    **kwargs
                )(handler)
            return handler
        return decorator
    
    def api_get(self, path: str, version: str = "v1", **kwargs) -> Callable[[Callable], Callable]:
        """API GET路由快捷方式"""
        return self.api_route(path, methods=["GET"], version=version, **kwargs)
    
    def api_post(self, path: str, version: str = "v1", **kwargs) -> Callable[[Callable], Callable]:
        """API POST路由快捷方式"""
        return self.api_route(path, methods=["POST"], version=version, **kwargs)
    
    def api_put(self, path: str, version: str = "v1", **kwargs) -> Callable[[Callable], Callable]:
        """API PUT路由快捷方式"""
        return self.api_route(path, methods=["PUT"], version=version, **kwargs)
    
    def api_delete(self, path: str, version: str = "v1", **kwargs) -> Callable[[Callable], Callable]:
        """API DELETE路由快捷方式"""
        return self.api_route(path, methods=["DELETE"], version=version, **kwargs)
    
    def api_patch(self, path: str, version: str = "v1", **kwargs) -> Callable[[Callable], Callable]:
        """API PATCH路由快捷方式"""
        return self.api_route(path, methods=["PATCH"], version=version, **kwargs)
    
    def _register_gateway_routes(self):
        """注册网关路由处理器"""
        from kewe.request import Request
        from kewe.response import json
        from kewe.gateway.core import ErrorCode
        
        prefix = self.config.gateway_prefix
        
        @self.route(f"{prefix}/<path:path>", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"], name="gateway_catch_all")
        async def gateway_catch_all(request: Request):
            return await self._handle_gateway_request(request)
        
        @self.route(f"{prefix}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"], name="gateway_root")
        async def gateway_root(request: Request):
            return await self._handle_gateway_request(request)
        
        logger.info(f"Gateway enabled with prefix: {prefix}")
    
    async def _handle_gateway_request(self, request) -> 'Response':
        """处理网关请求 - 优先匹配已注册的应用路由（含Blueprint），未命中再走Gateway"""
        from kewe.response import json
        from kewe.gateway.core import ErrorCode

        match = self.router.find_route(request.path, request.method)
        if match:
            handler = match.get('handler')
            params = match.get('params', {})
            if handler and handler != self._handle_gateway_request:
                try:
                    import inspect
                    sig = inspect.signature(handler)
                    if len(sig.parameters) > 1:
                        result = handler(request, **params)
                    else:
                        result = handler(request)
                    if inspect.isawaitable(result):
                        return await result
                    return result
                except Exception as e:
                    import logging
                    logging.getLogger(__name__).debug(f"Gateway route handler error: {e}")
        
        try:
            raw_request = {
                "path": request.path,
                "method": request.method,
                "headers": dict(request.headers),
                "query_params": {k: v[0] if len(v) == 1 else v for k, v in request.query_params.items_raw()},
                "body": await request.json_async,
                "client_ip": request.client_ip,
                "user_agent": request.headers.get("user-agent", ""),
                "api_version": "v1",
            }
            
            response_data = await self.gateway.handle_request(raw_request)
            
            status_code = 200 if response_data.get("success", True) else 400
            if response_data.get("code", 0) != 0:
                error_code = response_data.get("code", 0)
                if error_code == ErrorCode.NOT_FOUND.code:
                    status_code = 404
                elif error_code == ErrorCode.UNAUTHORIZED.code:
                    status_code = 401
                elif error_code == ErrorCode.FORBIDDEN.code:
                    status_code = 403
                elif error_code == ErrorCode.RATE_LIMITED.code:
                    status_code = 429
                elif error_code >= 1000:
                    status_code = 400
            
            response = json(response_data, status=status_code)
            
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["X-Frame-Options"] = "DENY"
            response.headers["X-XSS-Protection"] = "1; mode=block"
            
            return response
            
        except Exception as e:
            logger.error(f"Gateway request error: {e}", exc_info=True)
            from kewe.errors.exceptions import InternalServerError
            server_err = InternalServerError("Internal Server Error")
            server_err.__cause__ = e
            return json(server_err.to_problem_details(), status=500)


class WebSocketMixin:
    """
    WebSocket Mixin - 提供WebSocket路由注册
    """
    
    def add_websocket_route(
        self,
        path: str,
        handler: Callable,
        *,
        name: Optional[str] = None,
        subprotocols: Optional[List[str]] = None,
        **kwargs
    ) -> Callable:
        """添加WebSocket路由 — 统一存储到 router._websocket_routes"""
        if hasattr(self, 'router') and hasattr(self.router, 'add_websocket_route'):
            self.router.add_websocket_route(path, handler, name=name, subprotocols=subprotocols, **kwargs)
        else:
            if not hasattr(self, '_websocket_routes'):
                self._websocket_routes = []
            self._websocket_routes.append({
                'path': path,
                'handler': handler,
                'name': name,
                'subprotocols': subprotocols,
                'kwargs': kwargs
            })
        return handler
    
    def websocket(
        self,
        path: str,
        *,
        name: Optional[str] = None,
        subprotocols: Optional[List[str]] = None,
        **kwargs
    ) -> Callable[[Callable], Callable]:
        """
        WebSocket路由装饰器
        """
        def decorator(handler: Callable) -> Callable:
            return self.add_websocket_route(
                path,
                handler,
                name=name,
                subprotocols=subprotocols,
                **kwargs
            )
        return decorator


class DIMixin:
    """
    依赖注入Mixin - 提供DI容器操作
    """
    
    def register_service(
        self,
        interface: type,
        implementation: Optional[type] = None,
        factory: Optional[Callable] = None,
        instance: Optional[Any] = None,
        lifetime: str = "transient"
    ):
        """
        注册服务到依赖注入容器
        """
        from kewe.application.di import Lifetime
        
        lifetime_enum = Lifetime(lifetime)
        self.container.register(
            interface=interface,
            implementation=implementation,
            factory=factory,
            instance=instance,
            lifetime=lifetime_enum
        )
        return self
    
    def resolve_service(self, interface: type) -> Any:
        """解析服务"""
        return self.container.resolve(interface)
    
    def service_scope(self):
        """创建服务作用域"""
        return self.container.scope()


class UrlMixin:
    """
    URL生成Mixin - 提供反向URL生成
    """

    def url_for(self, view_name: str, **kwargs) -> str:
        """
        根据路由名称生成URL - 

        Args:
            view_name: 路由名称
            **kwargs: 路径参数

        Returns:
            生成的URL字符串

        使用示例:
            @app.get("/users/<user_id>", name="user_detail")
            async def user_detail(request, user_id):
                ...

            url = app.url_for("user_detail", user_id=42)
            # => "/users/42"
        """
        if hasattr(self, 'router') and hasattr(self.router, 'url_for'):
            return self.router.url_for(view_name, **kwargs)

        if hasattr(self, 'router') and hasattr(self.router, '_routes'):
            for route in self.router._routes.values():
                route_name = getattr(route, 'name', None)
                if route_name == view_name:
                    path = getattr(route, 'path', getattr(route, 'pattern', ''))
                    for key, value in kwargs.items():
                        path = path.replace(f'<{key}>', str(value))
                        path = path.replace(f'{{{key}}}', str(value))
                    return path

        raise ValueError(f"No route found with name: {view_name}")


class ConfigMixin:
    """
    配置Mixin - 提供多种配置加载方式
    """
    
    def config_from_object(self, obj: Any) -> 'Kewe':
        if isinstance(obj, str):
            import importlib
            module_path, _, attr = obj.rpartition('.')
            if module_path:
                module = importlib.import_module(module_path)
                obj = getattr(module, attr) if attr else module
            else:
                module = importlib.import_module(obj)
                obj = module
        
        if hasattr(self.config, 'from_object'):
            self.config.from_object(obj)
        else:
            for key in dir(obj):
                if key.isupper():
                    value = getattr(obj, key)
                    lower_key = key.lower()
                    if hasattr(self.config, lower_key):
                        setattr(self.config, lower_key, value)
        return self
    
    def config_from_envvar(self, variable_name: str, silent: bool = False) -> 'Kewe':
        import os
        value = os.environ.get(variable_name)
        if not value:
            if silent:
                return self
            raise RuntimeError(f"Environment variable {variable_name} is not set")
        return self.config_from_pyfile(value)
    
    def config_from_pyfile(self, filename: str, silent: bool = False) -> 'Kewe':
        import types
        d = types.ModuleType("config")
        d.__file__ = filename
        try:
            with open(filename, 'r') as f:
                exec(compile(f.read(), filename, 'exec'), d.__dict__)
        except IOError:
            if silent:
                return self
            raise
        for key in dir(d):
            if key.isupper():
                value = getattr(d, key)
                if hasattr(self.config, key.lower()):
                    setattr(self.config, key.lower(), value)
        return self
    
    def config_from_mapping(self, mapping: Dict[str, Any]) -> 'Kewe':
        for key, value in mapping.items():
            if key.isupper() and hasattr(self.config, key.lower()):
                setattr(self.config, key.lower(), value)
        return self


class ServerMixin:
    """
    服务器Mixin - 提供服务器运行和SSL配置
    """
    
    async def run(
        self,
        host: str = None,
        port: int = None,
        debug: bool = None,
        log_level: int = None,
        access_log: bool = None,
        json_log: bool = None,
        ssl: Union[Dict[str, Any], "SSLConfig", ssl.SSLContext] = None,
        ssl_cert: str = None,
        ssl_key: str = None,
        ssl_password: str = None,
        workers: int = 1,
        **kwargs
    ):
        """
        运行服务器
        """
        host = host or self.config.host
        port = port or self.config.port
        debug = debug if debug is not None else self.config.debug
        
        if log_level is not None or access_log is not None or json_log is not None:
            self._log_level = log_level if log_level is not None else self._log_level
            self._access_log = access_log if access_log is not None else self._access_log
            self._json_log = json_log if json_log is not None else self._json_log
            self._setup_logging()
        
        if debug and self._log_level > logging.DEBUG:
            self._log_level = logging.DEBUG
            self._setup_logging()
        
        from kewe.utils.compat import auto_select_event_loop
        auto_select_event_loop()
        
        self.set_current()
        
        ssl_context = self._resolve_ssl(ssl, ssl_cert, ssl_key, ssl_password)
        
        protocol = "https" if ssl_context else "http"
        serve_location = f"{protocol}://{host}:{port}"
        
        from kewe.application.logo import display_motd, get_runtime_info
        if getattr(self.config, 'show_banner', True):
            runtime_info = get_runtime_info()
            motd_data = {
                "mode": "debug" if debug else "production",
                "server": "kewe, HTTP/1.1",
                "python": runtime_info.get("python", "unknown"),
            }
            if workers > 1:
                motd_data["workers"] = str(workers)
            motd_extra = {}
            if self.gateway:
                motd_extra["gateway"] = self.config.gateway_prefix
            if hasattr(self, 'container') and self.container._registrations:
                motd_extra["DI services"] = str(len(self.container._registrations))
            
            display_motd(serve_location, data=motd_data, extra=motd_extra)
        
        await self.plugins.run_hooks('before_server_start', self)
        
        if hasattr(self, 'middleware_manager'):
            self.middleware_manager.compile_middleware_chains()
        
        if workers > 1:
            from kewe.worker.custom import serve_multi
            await serve_multi(
                self,
                host=host,
                port=port,
                workers=workers,
                debug=debug,
                ssl_context=ssl_context,
                **kwargs
            )
        else:
            from kewe.server import KeweServer
            server = KeweServer(
                self,
                host=host,
                port=port,
                ssl_context=ssl_context,
                **kwargs
            )
            
            try:
                await server.start()
                await self.plugins.run_hooks('after_server_start', self)
            except KeyboardInterrupt:
                logger.info("Shutting down...")
            finally:
                await self.plugins.run_hooks('before_server_stop', self)
                if hasattr(self, '_plugins'):
                    for plugin in self._plugins:
                        try:
                            if hasattr(plugin, 'teardown') and callable(plugin.teardown):
                                plugin.teardown()
                        except Exception as e:
                            logger.error(f"Plugin teardown error: {e}")
                await server.stop()
                await self.plugins.run_hooks('after_server_stop', self)
    
    def _resolve_ssl(
        self,
        ssl: Union[Dict[str, Any], "SSLConfig", ssl.SSLContext] = None,
        ssl_cert: str = None,
        ssl_key: str = None,
        ssl_password: str = None
    ) -> Optional[ssl.SSLContext]:
        """
        解析SSL配置
        """
        import ssl as ssl_module
        
        if ssl is not None:
            if isinstance(ssl, ssl_module.SSLContext):
                return ssl
            
            if isinstance(ssl, dict):
                from kewe.server.ssl import SSLConfig
                config = SSLConfig.from_dict(ssl)
                return config.context
            
            if hasattr(ssl, 'context'):
                return ssl.context
        
        if ssl_cert and ssl_key:
            from kewe.server.ssl import create_ssl_context
            return create_ssl_context(
                cert=ssl_cert,
                key=ssl_key,
                password=ssl_password
            )
        
        return None
    
    def asgi(self):
        from kewe.server.asgi import asgi_app
        return asgi_app(self)


# 组合所有Mixin
class ApplicationMixin(
    RouteMixin,
    MiddlewareMixin,
    ExceptionMixin,
    ListenerMixin,
    StaticMixin,
    SignalMixin,
    GatewayMixin,
    WebSocketMixin,
    DIMixin,
    UrlMixin,
    ConfigMixin,
    ServerMixin,
):
    """
    应用组合Mixin
    
    包含所有便捷API
    """
    pass
