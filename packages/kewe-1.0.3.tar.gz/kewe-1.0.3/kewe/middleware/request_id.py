#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
请求 ID 自动注入模块
支持从请求头读取或自动生成唯一请求 ID
"""

import secrets
import time
import uuid
from typing import Optional, Callable, Dict, Any
from dataclasses import dataclass
from enum import Enum
from contextvars import ContextVar


class RequestIDFormat(Enum):
    """请求 ID 格式"""
    UUID = "uuid"
    UUID_HEX = "uuid_hex"
    ULID = "ulid"
    NANO_ID = "nanoid"
    CUSTOM = "custom"


@dataclass
class RequestIDConfig:
    """请求 ID 配置"""
    header_name: str = "X-Request-ID"
    response_header_name: str = "X-Request-ID"
    format: RequestIDFormat = RequestIDFormat.UUID
    length: int = 21
    prefix: str = ""
    generator: Optional[Callable[[], str]] = None
    enforce: bool = False


def generate_uuid() -> str:
    """生成 UUID v4"""
    return str(uuid.uuid4())


def generate_uuid_hex() -> str:
    """生成 UUID v4 十六进制格式"""
    return uuid.uuid4().hex


def generate_ulid() -> str:
    """生成 ULID (Universally Unique Lexicographically Sortable Identifier)"""
    timestamp = int(time.time() * 1000)
    randomness = secrets.token_bytes(10)
    
    timestamp_bytes = timestamp.to_bytes(6, byteorder='big')
    combined = timestamp_bytes + randomness
    
    return _base32_encode(combined)


def generate_nanoid(length: int = 21) -> str:
    """生成 Nano ID"""
    alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_-"
    alphabet_len = len(alphabet)
    
    mask = 1
    while mask < alphabet_len:
        mask <<= 1
    mask -= 1
    
    result = []
    random_bytes = secrets.token_bytes(length * 2)
    byte_index = 0
    
    while len(result) < length:
        if byte_index >= len(random_bytes):
            random_bytes = secrets.token_bytes(length * 2)
            byte_index = 0
        
        byte = random_bytes[byte_index]
        byte_index += 1
        
        if byte <= mask:
            result.append(alphabet[byte % alphabet_len])
    
    return ''.join(result)


def _base32_encode(data: bytes) -> str:
    """Base32 编码（Crockford's Base32）"""
    alphabet = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
    result = []
    
    for i in range(0, len(data), 5):
        chunk = data[i:i+5]
        chunk_int = int.from_bytes(chunk, byteorder='big')
        
        for j in range(8):
            if i + j * 5 // 8 < len(data):
                result.append(alphabet[(chunk_int >> (35 - j * 5)) & 0x1F])
    
    return ''.join(result)


class RequestIDGenerator:
    """请求 ID 生成器"""
    
    def __init__(self, config: RequestIDConfig = None):
        self.config = config or RequestIDConfig()
        self._generators: Dict[RequestIDFormat, Callable[[], str]] = {
            RequestIDFormat.UUID: generate_uuid,
            RequestIDFormat.UUID_HEX: generate_uuid_hex,
            RequestIDFormat.ULID: generate_ulid,
            RequestIDFormat.NANO_ID: lambda: generate_nanoid(self.config.length),
        }
    
    def generate(self) -> str:
        """生成请求 ID"""
        if self.config.generator:
            request_id = self.config.generator()
        else:
            generator = self._generators.get(self.config.format, generate_uuid)
            request_id = generator()
        
        if self.config.prefix:
            return f"{self.config.prefix}{request_id}"
        
        return request_id
    
    def extract_from_headers(self, headers: Dict[str, str]) -> Optional[str]:
        """从请求头中提取请求 ID"""
        header_name = self.config.header_name.lower()
        
        for key, value in headers.items():
            if key.lower() == header_name:
                return value
        
        return None


class RequestIDManager:
    """请求 ID 管理器"""
    
    def __init__(self, config: RequestIDConfig = None):
        self.config = config or RequestIDConfig()
        self.generator = RequestIDGenerator(self.config)
    
    def get_or_create(self, headers: Dict[str, str]) -> str:
        """获取或创建请求 ID"""
        existing_id = self.generator.extract_from_headers(headers)
        
        if existing_id:
            return existing_id
        
        if self.config.enforce:
            raise ValueError(f"Request ID header '{self.config.header_name}' is required")
        
        return self.generator.generate()
    
    def create_response_headers(self, request_id: str) -> Dict[str, str]:
        """创建响应头"""
        return {
            self.config.response_header_name: request_id
        }


_request_id_manager: Optional[RequestIDManager] = None


def get_request_id_manager() -> RequestIDManager:
    """获取全局请求 ID 管理器"""
    global _request_id_manager
    if _request_id_manager is None:
        _request_id_manager = RequestIDManager()
    return _request_id_manager


def configure_request_id(
    header_name: str = "X-Request-ID",
    response_header_name: str = "X-Request-ID",
    format: RequestIDFormat = RequestIDFormat.UUID,
    length: int = 21,
    prefix: str = "",
    generator: Optional[Callable[[], str]] = None,
    enforce: bool = False
) -> RequestIDManager:
    """
    配置请求 ID 生成器
    
    Args:
        header_name: 请求头名称
        response_header_name: 响应头名称
        format: ID 格式
        length: Nano ID 长度
        prefix: ID 前缀
        generator: 自定义生成函数
        enforce: 是否强制要求请求头中有 ID
    
    Returns:
        RequestIDManager 实例
    """
    global _request_id_manager
    
    config = RequestIDConfig(
        header_name=header_name,
        response_header_name=response_header_name,
        format=format,
        length=length,
        prefix=prefix,
        generator=generator,
        enforce=enforce
    )
    
    _request_id_manager = RequestIDManager(config)
    return _request_id_manager


def generate_request_id() -> str:
    """生成请求 ID（使用全局配置）"""
    return get_request_id_manager().generator.generate()


class RequestContext:
    """
    请求上下文 - 支持跨服务传播
    使用 ContextVar 确保并发安全，使用 token/reset 模式确保嵌套安全
    """

    _ctx_request_id: ContextVar[Optional[str]] = ContextVar('req_id_ctx', default=None)
    _ctx_trace_id: ContextVar[Optional[str]] = ContextVar('trace_id_ctx', default=None)
    _ctx_span_id: ContextVar[Optional[str]] = ContextVar('span_id_ctx', default=None)
    _ctx_propagation_headers: ContextVar[Optional[Dict[str, str]]] = ContextVar('prop_headers_ctx', default=None)
    _tokens: ContextVar[Optional[list]] = ContextVar('req_ctx_tokens', default=None)

    @classmethod
    def set_current(
        cls,
        request_id: str,
        trace_id: Optional[str] = None,
        span_id: Optional[str] = None
    ) -> None:
        tokens = cls._tokens.get() or []
        tokens.append((
            cls._ctx_request_id.set(request_id),
            cls._ctx_trace_id.set(trace_id or request_id),
            cls._ctx_span_id.set(span_id or generate_nanoid(16)),
            cls._ctx_propagation_headers.set({
                "X-Request-ID": request_id,
                "X-Trace-ID": trace_id or request_id,
                "X-Span-ID": span_id or generate_nanoid(16),
            }),
        ))
        cls._tokens.set(tokens)

    @classmethod
    def get_request_id(cls) -> Optional[str]:
        return cls._ctx_request_id.get()

    @classmethod
    def get_trace_id(cls) -> Optional[str]:
        return cls._ctx_trace_id.get()

    @classmethod
    def get_span_id(cls) -> Optional[str]:
        return cls._ctx_span_id.get()

    @classmethod
    def propagate_headers(cls, extra_headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        headers = dict(cls._ctx_propagation_headers.get() or {})
        if extra_headers:
            headers.update(extra_headers)
        return headers

    @classmethod
    def extract_from_incoming(cls, headers: Dict[str, str]) -> Dict[str, Optional[str]]:
        return {
            "request_id": headers.get("X-Request-ID") or headers.get("x-request-id"),
            "trace_id": headers.get("X-Trace-ID") or headers.get("x-trace-id"),
            "span_id": headers.get("X-Span-ID") or headers.get("x-span-id"),
            "parent_span_id": headers.get("X-Parent-Span-ID") or headers.get("x-parent-span-id"),
        }

    @classmethod
    def create_child_context(cls) -> Dict[str, str]:
        parent_span_id = cls._ctx_span_id.get()
        new_span_id = generate_nanoid(16)
        return {
            "X-Request-ID": cls._ctx_request_id.get() or "",
            "X-Trace-ID": cls._ctx_trace_id.get() or "",
            "X-Span-ID": new_span_id,
            "X-Parent-Span-ID": parent_span_id or "",
        }

    @classmethod
    def clear(cls) -> None:
        """清除请求上下文，使用reset(token)恢复外层上下文"""
        tokens = cls._tokens.get([])
        if tokens:
            t_req, t_trace, t_span, t_headers = tokens.pop()
            cls._ctx_request_id.reset(t_req)
            cls._ctx_trace_id.reset(t_trace)
            cls._ctx_span_id.reset(t_span)
            cls._ctx_propagation_headers.reset(t_headers)
            cls._tokens.set(tokens)
        else:
            cls._ctx_request_id.set(None)
            cls._ctx_trace_id.set(None)
            cls._ctx_span_id.set(None)
            cls._ctx_propagation_headers.set({})


class RequestIDMiddleware:
    """
    请求 ID 传播中间件
    
    自动在请求和响应中注入请求 ID，支持跨服务传播
    
    使用示例:
        from kewe.middleware.request_id import RequestIDMiddleware
        
        app = Kewe("my-app")
        RequestIDMiddleware(app)
    """
    
    def __init__(
        self,
        app=None,
        *,
        header_name: str = "X-Request-ID",
        trace_header_name: str = "X-Trace-ID",
        span_header_name: str = "X-Span-ID",
        generate_if_missing: bool = True,
        response_header: str = None,
        format: str = None
    ):
        self.app = app
        self.header_name = header_name
        self.response_header = response_header or header_name
        self.trace_header_name = trace_header_name
        self.span_header_name = span_header_name
        self.generate_if_missing = generate_if_missing
        self.format = format
        
        if app is not None:
            self._register_middleware()
    
    def _register_middleware(self):
        """注册中间件"""
        
        @self.app.middleware("request", priority=0)
        async def extract_request_id(request):
            headers = dict(request.headers)
            
            extracted = RequestContext.extract_from_incoming(headers)
            
            request_id = extracted.get("request_id")
            trace_id = extracted.get("trace_id")
            span_id = extracted.get("span_id")
            
            if not request_id and self.generate_if_missing:
                request_id = generate_request_id()
            
            if not trace_id:
                trace_id = request_id
            
            if not span_id:
                span_id = generate_nanoid(16)
            
            RequestContext.set_current(request_id, trace_id, span_id)
            
            request.ctx.request_id = request_id
            request.ctx.trace_id = trace_id
            request.ctx.span_id = span_id
            
            return True
        
        @self.app.middleware("response", priority=100)
        async def inject_response_headers(request, response):
            request_id = getattr(request.ctx, 'request_id', None)
            if request_id:
                response.headers[self.header_name] = request_id
            
            trace_id = getattr(request.ctx, 'trace_id', None)
            if trace_id:
                response.headers[self.trace_header_name] = trace_id
            
            span_id = getattr(request.ctx, 'span_id', None)
            if span_id:
                response.headers[self.span_header_name] = span_id
            
            RequestContext.clear()
            
            return response


__all__ = [
    'RequestIDFormat',
    'RequestIDConfig',
    'RequestIDGenerator',
    'RequestIDManager',
    'RequestContext',
    'RequestIDMiddleware',
    'get_request_id_manager',
    'configure_request_id',
    'generate_request_id',
    'generate_uuid',
    'generate_uuid_hex',
    'generate_ulid',
    'generate_nanoid',
]

