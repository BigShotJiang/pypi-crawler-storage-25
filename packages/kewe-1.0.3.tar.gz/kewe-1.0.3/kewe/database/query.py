#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
查询构建器 - Query Builder

查询构建模式，
提供流畅的链式查询API。

功能：
- 链式查询构建
- 条件过滤
- 排序/分页
- 聚合查询
- 与SQLAlchemyPlugin集成
"""
import logging
from dataclasses import dataclass
from typing import Any, Dict, Generic, List, Optional, Type, TypeVar, Union, Tuple

logger = logging.getLogger(__name__)

_SQLALCHEMY_AVAILABLE = False

try:
    from sqlalchemy import select, insert, update, delete, func, and_, or_, not_
    from sqlalchemy.ext.asyncio import AsyncSession
    _ASYNC_SESSION = True
    _SQLALCHEMY_AVAILABLE = True
except ImportError:
    logger.debug("SQLAlchemy not available. Query builder will not be functional.")
    _ASYNC_SESSION = False
    _SQLALCHEMY_AVAILABLE = False

T = TypeVar("T")


@dataclass
class PaginationResult(Generic[T]):
    """分页结果 - 类型安全的分页数据容器"""
    items: List[Any]
    total: int
    page: int
    per_page: int
    pages: int
    has_prev: bool
    has_next: bool

    def to_dict(self) -> Dict[str, Any]:
        return {
            "items": self.items,
            "total": self.total,
            "page": self.page,
            "per_page": self.per_page,
            "pages": self.pages,
            "has_prev": self.has_prev,
            "has_next": self.has_next,
        }


class QueryBuilder:
    """
    查询构建器 - 流畅的链式查询API

    使用示例:
        # 基本查询
        results = await QueryBuilder(User, session).filter(User.is_active == True).all()

        # 排序和分页
        results = await QueryBuilder(User, session).order_by(User.created_at.desc()).limit(10).offset(0).all()

        # 聚合查询
        count = await QueryBuilder(User, session).count()

        # 条件组合
        results = await QueryBuilder(User, session).filter(
            or_(User.username == "admin", User.email.contains("example.com"))
        ).all()
    """

    def __init__(self, model: Type = None, session: Any = None):
        if model is not None and not _SQLALCHEMY_AVAILABLE:
            raise ImportError(
                "SQLAlchemy is required for QueryBuilder. "
                "Install with: pip install sqlalchemy[asyncio]"
            )

        self._model = model
        self._session = session
        self._filters: List[Any] = []
        self._order_by_clauses: List[Any] = []
        self._limit_value: Optional[int] = None
        self._offset_value: Optional[int] = None
        self._joins: List[Tuple[Any, Any]] = []
        self._group_by_clauses: List[Any] = []
        self._having_clauses: List[Any] = []
        self._with_entities: Optional[List[Any]] = None
        self._distinct: bool = False

    def filter(self, *criteria: Any) -> "QueryBuilder":
        """添加过滤条件"""
        self._filters.extend(criteria)
        return self

    def filter_by(self, **kwargs: Any) -> "QueryBuilder":
        """通过关键字参数添加过滤条件"""
        if _SQLALCHEMY_AVAILABLE:
            for key, value in kwargs.items():
                column = getattr(self._model, key, None)
                if column is not None:
                    self._filters.append(column == value)
        return self

    def order_by(self, *clauses: Any) -> "QueryBuilder":
        """添加排序条件"""
        self._order_by_clauses.extend(clauses)
        return self

    def limit(self, value: int) -> "QueryBuilder":
        """设置结果数量限制"""
        self._limit_value = value
        return self

    def offset(self, value: int) -> "QueryBuilder":
        """设置偏移量"""
        self._offset_value = value
        return self

    def join(self, target: Any, onclause: Any = None) -> "QueryBuilder":
        self._joins.append(('inner', target, onclause))
        return self

    def outerjoin(self, target: Any, onclause: Any = None) -> "QueryBuilder":
        self._joins.append(('outer', target, onclause))
        return self

    def subquery(self) -> Any:
        stmt = self._build_select()
        return stmt.subquery()

    def raw(self, sql: str, params: dict = None) -> Any:
        from sqlalchemy import text
        return text(sql), params or {}

    def group_by(self, *clauses: Any) -> "QueryBuilder":
        """添加GROUP BY"""
        self._group_by_clauses.extend(clauses)
        return self

    def having(self, *criteria: Any) -> "QueryBuilder":
        """添加HAVING条件"""
        self._having_clauses.extend(criteria)
        return self

    def with_entities(self, *entities: Any) -> "QueryBuilder":
        """指定查询字段"""
        self._with_entities = list(entities)
        return self

    def distinct(self) -> "QueryBuilder":
        """去重"""
        self._distinct = True
        return self

    def _build_select(self) -> Any:
        """构建SELECT语句"""
        if self._with_entities:
            stmt = select(*self._with_entities)
        else:
            stmt = select(self._model)

        if self._distinct:
            stmt = stmt.distinct()

        for join_info in self._joins:
            join_type, target, onclause = join_info
            if join_type == 'outer':
                if onclause is not None:
                    stmt = stmt.outerjoin(target, onclause)
                else:
                    stmt = stmt.outerjoin(target)
            else:
                if onclause is not None:
                    stmt = stmt.join(target, onclause)
                else:
                    stmt = stmt.join(target)

        if self._filters:
            if len(self._filters) == 1:
                stmt = stmt.where(self._filters[0])
            else:
                stmt = stmt.where(and_(*self._filters))

        if self._group_by_clauses:
            stmt = stmt.group_by(*self._group_by_clauses)

        if self._having_clauses:
            if len(self._having_clauses) == 1:
                stmt = stmt.having(self._having_clauses[0])
            else:
                stmt = stmt.having(and_(*self._having_clauses))

        if self._order_by_clauses:
            stmt = stmt.order_by(*self._order_by_clauses)

        if self._limit_value is not None:
            stmt = stmt.limit(self._limit_value)

        if self._offset_value is not None:
            stmt = stmt.offset(self._offset_value)

        return stmt

    async def _execute(self, stmt):
        if self._session is None:
            raise RuntimeError("No database session available")
        if _ASYNC_SESSION:
            return await self._session.execute(stmt)
        else:
            import asyncio
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, self._session.execute, stmt)

    async def all(self) -> List[Any]:
        if self._session is None:
            raise RuntimeError("No database session available")

        stmt = self._build_select()
        result = await self._execute(stmt)
        if self._with_entities:
            return result.all()
        return result.scalars().all()

    async def first(self) -> Optional[Any]:
        """获取第一条结果"""
        if self._session is None:
            raise RuntimeError("No database session available")

        stmt = self._build_select()
        result = await self._execute(stmt)
        if self._with_entities:
            return result.first()
        return result.scalars().first()

    async def one(self) -> Any:
        if self._session is None:
            raise RuntimeError("No database session available")

        stmt = self._build_select()
        result = await self._execute(stmt)
        if self._with_entities:
            return result.one()
        return result.scalars().one()

    async def one_or_none(self) -> Optional[Any]:
        if self._session is None:
            raise RuntimeError("No database session available")

        stmt = self._build_select()
        result = await self._execute(stmt)
        if self._with_entities:
            return result.one_or_none()
        return result.scalars().one_or_none()

    async def count(self) -> int:
        """计数 - 复用 _build_select 的 filter/join 逻辑"""
        if self._session is None:
            raise RuntimeError("No database session available")

        count_col = func.count()
        if self._distinct:
            try:
                from sqlalchemy import inspect as sa_inspect
                mapper = sa_inspect(self._model)
                pk_col = mapper.primary_key[0]
                count_col = func.count(pk_col.distinct())
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)

        base_stmt = self._build_select()
        stmt = select(count_col).select_from(base_stmt.subquery())
        result = await self._execute(stmt)
        return result.scalar() or 0

    async def exists(self) -> bool:
        """检查是否存在 - 复用 _build_select 的 filter/join 逻辑"""
        if self._session is None:
            raise RuntimeError("No database session available")

        base_stmt = self._build_select().limit(1)
        result = await self._execute(base_stmt)
        return result.first() is not None

    async def paginate(
        self,
        page: int = 1,
        per_page: int = 20,
    ) -> PaginationResult:
        """
        分页查询

        Args:
            page: 页码（从1开始）
            per_page: 每页数量

        Returns:
            PaginationResult 分页结果
        """
        total = await self.count()
        pages = (total + per_page - 1) // per_page if total > 0 else 0

        offset = (page - 1) * per_page
        old_limit, old_offset = self._limit_value, self._offset_value
        self._limit_value = per_page
        self._offset_value = offset
        try:
            items = await self.all()
        finally:
            self._limit_value = old_limit
            self._offset_value = old_offset

        return PaginationResult(
            items=items,
            total=total,
            page=page,
            per_page=per_page,
            pages=pages,
            has_prev=page > 1,
            has_next=page < pages,
        )

    async def values(self, *columns: Any) -> List[Tuple]:
        """获取指定列的值"""
        if self._session is None:
            raise RuntimeError("No database session available")

        stmt = select(*columns).select_from(self._model)

        if self._filters:
            if len(self._filters) == 1:
                stmt = stmt.where(self._filters[0])
            else:
                stmt = stmt.where(and_(*self._filters))

        if self._order_by_clauses:
            stmt = stmt.order_by(*self._order_by_clauses)

        if self._limit_value is not None:
            stmt = stmt.limit(self._limit_value)

        if self._offset_value is not None:
            stmt = stmt.offset(self._offset_value)

        result = await self._execute(stmt)
        return result.all()

    async def scalar(self) -> Any:
        """获取标量值"""
        if self._session is None:
            raise RuntimeError("No database session available")

        stmt = self._build_select()
        result = await self._execute(stmt)
        return result.scalar()


class SelectQuery:
    """SELECT查询构建器"""

    def __init__(self, model: Type, session: Any = None):
        self._builder = QueryBuilder(model, session)

    def filter(self, *criteria: Any) -> "SelectQuery":
        self._builder.filter(*criteria)
        return self

    def filter_by(self, **kwargs: Any) -> "SelectQuery":
        self._builder.filter_by(**kwargs)
        return self

    def order_by(self, *clauses: Any) -> "SelectQuery":
        self._builder.order_by(*clauses)
        return self

    def limit(self, value: int) -> "SelectQuery":
        self._builder.limit(value)
        return self

    def offset(self, value: int) -> "SelectQuery":
        self._builder.offset(value)
        return self

    def join(self, target: Any, onclause: Any = None) -> "SelectQuery":
        self._builder.join(target, onclause)
        return self

    def outerjoin(self, target: Any, onclause: Any = None) -> "SelectQuery":
        self._builder.outerjoin(target, onclause)
        return self

    def group_by(self, *clauses: Any) -> "SelectQuery":
        self._builder.group_by(*clauses)
        return self

    def having(self, criterion: Any) -> "SelectQuery":
        self._builder.having(criterion)
        return self

    def distinct(self) -> "SelectQuery":
        self._builder.distinct()
        return self

    def with_entities(self, *entities: Any) -> "SelectQuery":
        self._builder.with_entities(*entities)
        return self

    def paginate(self, page: int = 1, per_page: int = 20) -> "SelectQuery":
        self._builder.offset((page - 1) * per_page).limit(per_page)
        return self

    async def all(self) -> List[Any]:
        return await self._builder.all()

    async def first(self) -> Optional[Any]:
        return await self._builder.first()

    async def count(self) -> int:
        return await self._builder.count()

    async def one(self) -> Any:
        result = await self._builder.all()
        if len(result) == 0:
            raise ValueError("No result found")
        if len(result) > 1:
            raise ValueError("Multiple results found")
        return result[0]

    async def one_or_none(self) -> Optional[Any]:
        result = await self._builder.all()
        if len(result) == 0:
            return None
        if len(result) > 1:
            raise ValueError("Multiple results found")
        return result[0]

    async def exists(self) -> bool:
        return await self._builder.count() > 0

    async def scalar(self) -> Any:
        return await self._builder.scalar()

    async def values(self, *columns: Any) -> List[tuple]:
        return await self._builder.values(*columns)


class _BaseMutationQuery:
    def __init__(self, model: Type, session: Any = None):
        self._model = model
        self._session = session

    async def _execute(self, stmt):
        if self._session is None:
            raise RuntimeError("No database session available")
        if _ASYNC_SESSION:
            return await self._session.execute(stmt)
        else:
            import asyncio
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, self._session.execute, stmt)

    async def _flush(self):
        if _ASYNC_SESSION:
            await self._session.flush()
        else:
            import asyncio
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._session.flush)


class InsertQuery(_BaseMutationQuery):

    def __init__(self, model: Type, session: Any = None):
        super().__init__(model, session)
        self._values: List[Dict[str, Any]] = []

    def values(self, **kwargs: Any) -> "InsertQuery":
        self._values.append(kwargs)
        return self

    def bulk_values(self, values_list: List[Dict[str, Any]]) -> "InsertQuery":
        self._values.extend(values_list)
        return self

    async def execute(self) -> Any:
        if self._session is None:
            raise RuntimeError("No database session available")

        if not self._values:
            raise ValueError("No values provided for insert")

        if len(self._values) == 1:
            instance = self._model(**self._values[0])
            self._session.add(instance)
            await self._flush()
            return instance
        else:
            stmt = insert(self._model).values(self._values)
            result = await self._execute(stmt)
            await self._flush()
            return result


class UpdateQuery(_BaseMutationQuery):

    def __init__(self, model: Type, session: Any = None):
        super().__init__(model, session)
        self._values: Dict[str, Any] = {}
        self._filters: List[Any] = []

    def values(self, **kwargs: Any) -> "UpdateQuery":
        self._values.update(kwargs)
        return self

    def filter(self, *criteria: Any) -> "UpdateQuery":
        self._filters.extend(criteria)
        return self

    def filter_by(self, **kwargs: Any) -> "UpdateQuery":
        if _SQLALCHEMY_AVAILABLE:
            for key, value in kwargs.items():
                column = getattr(self._model, key, None)
                if column is not None:
                    self._filters.append(column == value)
        return self

    async def execute(self, allow_no_filter: bool = False) -> Any:
        if self._session is None:
            raise RuntimeError("No database session available")

        if not self._values:
            raise ValueError("No values provided for update")

        if not self._filters and not allow_no_filter:
            raise ValueError(
                "Update without filter conditions is dangerous. "
                "Pass allow_no_filter=True to update all rows."
            )

        stmt = update(self._model).values(**self._values)

        if self._filters:
            if len(self._filters) == 1:
                stmt = stmt.where(self._filters[0])
            else:
                stmt = stmt.where(and_(*self._filters))

        result = await self._execute(stmt)
        await self._flush()
        return result


class DeleteQuery(_BaseMutationQuery):

    def __init__(self, model: Type, session: Any = None):
        super().__init__(model, session)
        self._filters: List[Any] = []

    def filter(self, *criteria: Any) -> "DeleteQuery":
        self._filters.extend(criteria)
        return self

    def filter_by(self, **kwargs: Any) -> "DeleteQuery":
        if _SQLALCHEMY_AVAILABLE:
            for key, value in kwargs.items():
                column = getattr(self._model, key, None)
                if column is not None:
                    self._filters.append(column == value)
        return self

    async def execute(self, allow_no_filter: bool = False) -> Any:
        if self._session is None:
            raise RuntimeError("No database session available")

        if not self._filters and not allow_no_filter:
            raise ValueError(
                "Delete without filter conditions is dangerous. "
                "Pass allow_no_filter=True to delete all rows."
            )

        stmt = delete(self._model)

        if self._filters:
            if len(self._filters) == 1:
                stmt = stmt.where(self._filters[0])
            else:
                stmt = stmt.where(and_(*self._filters))

        result = await self._execute(stmt)
        await self._flush()
        return result
