#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Alembic Migration Manager"""

import logging
import os
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)

ALEMBIC_AVAILABLE = False

try:
    import alembic
    from alembic.config import Config as AlembicConfig
    from alembic.script import ScriptDirectory
    from alembic.runtime.migration import MigrationContext
    ALEMBIC_AVAILABLE = True
except ImportError:
    pass


class AlembicManager:

    def __init__(self, database_url: str = None, migrations_path: str = "migrations"):
        self.database_url = database_url
        self.migrations_path = migrations_path
        self._config = None

        if not ALEMBIC_AVAILABLE:
            logger.debug("Alembic not available. Install with: pip install alembic")

    @property
    def config(self) -> Optional["AlembicConfig"]:
        if not ALEMBIC_AVAILABLE:
            return None
        if self._config is None:
            self._config = AlembicConfig()
            if self.database_url:
                self._config.set_main_option("sqlalchemy.url", self.database_url)
            self._config.set_main_option("script_location", self.migrations_path)
        return self._config

    def init(self, directory: str = "migrations") -> bool:
        if not ALEMBIC_AVAILABLE:
            logger.error("Alembic is not installed. Run: pip install alembic")
            return False

        from alembic.command import init as alembic_init
        try:
            alembic_init(self.config, directory)
            self.migrations_path = directory
            logger.info(f"Alembic migrations initialized in {directory}")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize Alembic: {e}")
            return False

    def create_migration(self, message: str = "auto", autogenerate: bool = True, target_metadata=None) -> bool:
        if not ALEMBIC_AVAILABLE:
            logger.error("Alembic is not installed. Run: pip install alembic")
            return False

        from alembic.command import revision
        try:
            if autogenerate and target_metadata is not None:
                self.config.attributes = getattr(self.config, 'attributes', {}) or {}
                self.config.attributes['target_metadata'] = target_metadata
            revision(self.config, message=message, autogenerate=autogenerate)
            logger.info(f"Migration created: {message}")
            return True
        except Exception as e:
            logger.error(f"Failed to create migration: {e}")
            return False

    def upgrade(self, revision: str = "head") -> bool:
        if not ALEMBIC_AVAILABLE:
            logger.error("Alembic is not installed. Run: pip install alembic")
            return False

        from alembic.command import upgrade
        try:
            upgrade(self.config, revision)
            logger.info(f"Database upgraded to: {revision}")
            return True
        except Exception as e:
            logger.error(f"Failed to upgrade database: {e}")
            return False

    def downgrade(self, revision: str = "-1") -> bool:
        if not ALEMBIC_AVAILABLE:
            logger.error("Alembic is not installed. Run: pip install alembic")
            return False

        from alembic.command import downgrade
        try:
            downgrade(self.config, revision)
            logger.info(f"Database downgraded to: {revision}")
            return True
        except Exception as e:
            logger.error(f"Failed to downgrade database: {e}")
            return False

    def current_revision(self) -> Optional[str]:
        if not ALEMBIC_AVAILABLE:
            return None

        try:
            from sqlalchemy import create_engine, text
            script = ScriptDirectory.from_config(self.config)
            head = script.get_current_head()
            db_url = self.database_url
            if db_url:
                engine = create_engine(db_url)
                with engine.connect() as conn:
                    context = MigrationContext.configure(conn)
                    current = context.get_current_revision()
                engine.dispose()
                return current
            return head
        except Exception as e:
            logger.debug(f"Could not get current revision: {e}")
            return None

    def history(self) -> List[Dict[str, Any]]:
        if not ALEMBIC_AVAILABLE:
            return []

        try:
            script = ScriptDirectory.from_config(self.config)
            revisions = []
            for rev in script.walk_revisions():
                revisions.append({
                    "revision": rev.revision,
                    "message": rev.doc,
                    "down_revision": rev.down_revision,
                })
            return revisions
        except Exception as e:
            logger.debug(f"Could not get migration history: {e}")
            return []

    def stamp(self, revision: str = "head") -> bool:
        if not ALEMBIC_AVAILABLE:
            return False

        from alembic.command import stamp
        try:
            stamp(self.config, revision)
            return True
        except Exception as e:
            logger.error(f"Failed to stamp database: {e}")
            return False

    async def async_upgrade(self, revision: str = "head") -> bool:
        """异步升级数据库到指定版本"""
        import asyncio
        return await asyncio.get_running_loop().run_in_executor(
            None, self.upgrade, revision
        )

    async def async_downgrade(self, revision: str = "-1") -> bool:
        """异步降级数据库到指定版本"""
        import asyncio
        return await asyncio.get_running_loop().run_in_executor(
            None, self.downgrade, revision
        )

    async def async_create_migration(self, message: str = "auto", autogenerate: bool = True, target_metadata=None) -> bool:
        """异步创建迁移脚本"""
        import asyncio
        return await asyncio.get_running_loop().run_in_executor(
            None, lambda: self.create_migration(message, autogenerate, target_metadata)
        )

    async def async_current_revision(self) -> Optional[str]:
        """异步获取当前版本"""
        import asyncio
        return await asyncio.get_running_loop().run_in_executor(
            None, self.current_revision
        )

    async def async_history(self) -> List[Dict[str, Any]]:
        """异步获取迁移历史"""
        import asyncio
        return await asyncio.get_running_loop().run_in_executor(
            None, self.history
        )

    async def async_stamp(self, revision: str = "head") -> bool:
        """异步标记版本"""
        import asyncio
        return await asyncio.get_running_loop().run_in_executor(
            None, self.stamp, revision
        )

    async def async_upgrade_with_async_engine(self, revision: str = "head", async_engine=None) -> bool:
        """使用异步引擎升级数据库"""
        if not ALEMBIC_AVAILABLE:
            logger.error("Alembic is not installed. Run: pip install alembic")
            return False

        if async_engine is None:
            return await self.async_upgrade(revision)

        try:
            from alembic.runtime.migration import MigrationContext
            from alembic.operations import Operations
            from alembic.script import ScriptDirectory

            script = ScriptDirectory.from_config(self.config)

            async with async_engine.begin() as connection:
                context = MigrationContext.configure(
                    connection=connection.sync_connection,
                    opts={"target_metadata": None}
                )

                ops = Operations(context)
                current = context.get_current_revision()

                for rev in script.iterate_revisions(current, revision):
                    rev.module.upgrade(ops.get_context())

                logger.info(f"Database upgraded to: {revision}")
                return True
        except Exception as e:
            logger.error(f"Failed to upgrade database with async engine: {e}")
            return False


def is_alembic_available() -> bool:
    return ALEMBIC_AVAILABLE
