#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Database helpers for Kewe.
"""

from .models import (
    Model, Base, get_declarative_base, get_global_base,
    initialize_database, transaction,
    model_to_pydantic, pydantic_to_model,
    NPlusOneDetector, ConnectionPoolMonitor,
)
from .query import QueryBuilder, SelectQuery, InsertQuery, UpdateQuery, DeleteQuery, PaginationResult
from .alembic import AlembicManager, is_alembic_available

try:
    from kewe.plugins.pydantic_support import model_to_dict as pydantic_to_dict
except ImportError:
    pydantic_to_dict = None

__all__ = [
    "Model",
    "Base",
    "get_declarative_base",
    "get_global_base",
    "initialize_database",
    "transaction",
    "model_to_pydantic",
    "pydantic_to_model",
    "pydantic_to_dict",
    "NPlusOneDetector",
    "ConnectionPoolMonitor",
    "QueryBuilder",
    "SelectQuery",
    "InsertQuery",
    "UpdateQuery",
    "DeleteQuery",
    "PaginationResult",
    "AlembicManager",
    "is_alembic_available",
]
