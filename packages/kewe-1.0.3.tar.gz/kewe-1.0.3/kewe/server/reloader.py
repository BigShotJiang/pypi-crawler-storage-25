#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
优雅重启模块 - Graceful Restart Support
reloader实现，支持零停机重启

功能：
- SIGHUP 触发优雅重启
- 热重载代码变更
- 零停机重启
- 进程状态同步
"""
import os
import sys
import signal
import logging
import asyncio
import socket
import time
import threading
import importlib
from typing import Optional, Callable, Dict, Any, List, Set, Union
from pathlib import Path
from dataclasses import dataclass, field
from datetime import datetime
import hashlib
import subprocess

logger = logging.getLogger(__name__)


@dataclass
class ReloadConfig:
    """重载配置"""
    enabled: bool = True
    watch_dirs: List[str] = field(default_factory=lambda: ['.'])
    watch_files: List[str] = field(default_factory=lambda: ['*.py'])
    ignore_dirs: List[str] = field(default_factory=lambda: ['__pycache__', '.git', 'node_modules', '.venv', 'venv'])
    ignore_files: List[str] = field(default_factory=lambda: ['*.pyc', '*.pyo', '*.pyd'])
    interval: float = 1.0
    use_stat: bool = False


@dataclass
class FileInfo:
    """文件信息"""
    path: str
    mtime: float
    size: int
    hash: Optional[str] = None


class FileWatcher:
    """文件监视器"""
    
    def __init__(self, config: Union[ReloadConfig, List[str], None] = None):
        if isinstance(config, list):
            self.config = ReloadConfig(watch_dirs=config)
        elif config is None:
            self.config = ReloadConfig()
        else:
            self.config = config
        self._files: Dict[str, FileInfo] = {}
        self._initialized: bool = False
        self._callbacks: List[Callable[[List[str]], None]] = []
        self._running = False
        self._thread: Optional[threading.Thread] = None
    
    def add_callback(self, callback: Callable[[List[str]], None]):
        """添加变更回调"""
        self._callbacks.append(callback)
    
    def remove_callback(self, callback: Callable[[List[str]], None]):
        """移除变更回调"""
        if callback in self._callbacks:
            self._callbacks.remove(callback)
    
    def _should_watch(self, path: Path) -> bool:
        """检查是否应该监视该路径"""
        path_str = str(path)
        
        for ignore_dir in self.config.ignore_dirs:
            if f"{os.sep}{ignore_dir}{os.sep}" in path_str or path_str.startswith(ignore_dir + os.sep):
                return False
        
        for ignore_file in self.config.ignore_files:
            if path.match(ignore_file):
                return False
        
        for pattern in self.config.watch_files:
            if path.match(pattern):
                return True
        
        return False
    
    def _scan_files(self) -> Dict[str, FileInfo]:
        """扫描文件"""
        files = {}
        
        for watch_dir in self.config.watch_dirs:
            watch_path = Path(watch_dir)
            if not watch_path.exists():
                continue
            
            for root, dirs, filenames in os.walk(watch_path):
                root_path = Path(root)
                
                dirs[:] = [d for d in dirs if d not in self.config.ignore_dirs]
                
                for filename in filenames:
                    file_path = root_path / filename
                    
                    if self._should_watch(file_path):
                        try:
                            stat = file_path.stat()
                            file_hash = None
                            
                            if self.config.use_stat:
                                file_hash = self._compute_hash(file_path)
                            
                            files[str(file_path)] = FileInfo(
                                path=str(file_path),
                                mtime=stat.st_mtime,
                                size=stat.st_size,
                                hash=file_hash
                            )
                        except OSError:
                            pass
        
        return files
    
    def _compute_hash(self, path: Path) -> str:
        """计算文件哈希"""
        hasher = hashlib.md5()
        try:
            with open(path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except OSError:
            return ""
    
    def _check_changes(self) -> List[str]:
        """检查变更"""
        current_files = self._scan_files()
        changed = []
        
        for path, info in current_files.items():
            if path not in self._files:
                changed.append(path)
            elif info.mtime != self._files[path].mtime:
                if self.config.use_stat:
                    if info.hash != self._files[path].hash:
                        changed.append(path)
                else:
                    changed.append(path)
        
        for path in self._files:
            if path not in current_files:
                changed.append(path)
        
        self._files = current_files
        return changed
    
    def _watch_loop(self):
        """监视循环"""
        while self._running:
            time.sleep(self.config.interval)
            
            if not self._running:
                break
            
            changed = self._check_changes()
            
            if changed:
                logger.info(f"Files changed: {changed}")
                for callback in self._callbacks:
                    try:
                        callback(changed)
                    except Exception as e:
                        logger.error(f"Callback error: {e}")
    
    def start(self):
        """启动监视"""
        if self._running:
            return
        
        self._files = self._scan_files()
        self._initialized = True
        self._running = True
        self._thread = threading.Thread(target=self._watch_loop, daemon=True)
        self._thread.start()
        logger.info("File watcher started")
    
    def stop(self):
        """停止监视"""
        self._running = False
        if self._thread:
            self._thread.join(timeout=2.0)
        logger.info("File watcher stopped")
    
    def check(self) -> List[str]:
        """检查文件变更（同步方法）"""
        if not self._initialized:
            self._files = self._scan_files()
            self._initialized = True
            return []
        return self._check_changes()


class GracefulRestart:
    """优雅重启管理器"""
    
    def __init__(self, app_factory: Callable):
        self.app_factory = app_factory
        self._workers: List[int] = []
        self._master_pid = os.getpid()
        self._restarting = False
        self._shutdown_event = asyncio.Event()
        self._file_watcher: Optional[FileWatcher] = None
        self._config = ReloadConfig()
    
    def setup_signal_handlers(self):
        """设置信号处理器 - 兼容Windows"""
        import sys
        if sys.platform != 'win32':
            if hasattr(signal, 'SIGHUP'):
                signal.signal(signal.SIGHUP, self._handle_sighup)
        signal.signal(signal.SIGTERM, self._handle_sigterm)
        signal.signal(signal.SIGINT, self._handle_sigint)
        logger.info("Signal handlers registered for graceful restart")
    
    def _handle_sighup(self, signum, frame):
        """处理SIGHUP - 触发优雅重启"""
        logger.info("Received SIGHUP, initiating graceful restart...")
        self._restart()
    
    def _handle_sigterm(self, signum, frame):
        """处理SIGTERM"""
        logger.info("Received SIGTERM, shutting down...")
        self._shutdown()
    
    def _handle_sigint(self, signum, frame):
        """处理SIGINT"""
        logger.info("Received SIGINT, shutting down...")
        self._shutdown()
    
    def _restart(self):
        """执行重启"""
        if self._restarting:
            logger.warning("Restart already in progress")
            return
        
        self._restarting = True
        
        logger.info("Starting graceful restart...")
        
        try:
            self._restart_workers()
        except Exception as e:
            logger.error(f"Restart failed: {e}")
        finally:
            self._restarting = False
    
    def _restart_workers(self):
        """重启worker进程"""
        for pid in self._workers:
            try:
                os.kill(pid, signal.SIGTERM)
                logger.info(f"Sent SIGTERM to worker {pid}")
            except ProcessLookupError:
                logger.warning(f"Worker {pid} not found")
        
        time.sleep(1)
        
        self._spawn_workers()
    
    def _spawn_workers(self):
        """生成新的worker进程"""
        if not self.app_factory:
            logger.warning("No app_factory provided, cannot spawn workers")
            return
        import sys
        if sys.platform == 'win32':
            logger.info("Windows platform: using subprocess for worker spawn")
            import subprocess
            try:
                proc = subprocess.Popen(
                    [sys.executable, '-m', 'kewe', 'run'],
                    close_fds=False
                )
                self._workers.append(proc.pid)
                logger.info(f"Spawned worker process: PID={proc.pid}")
            except Exception as e:
                logger.error(f"Failed to spawn worker on Windows: {e}")
        else:
            try:
                pid = os.fork()
                if pid == 0:
                    try:
                        asyncio.run(self.app_factory())
                    except Exception as e:
                        logger.error(f"Worker process error: {e}")
                    finally:
                        os._exit(0)
                else:
                    self._workers.append(pid)
                    logger.info(f"Spawned worker process: PID={pid}")
            except OSError as e:
                logger.error(f"Failed to fork worker: {e}")
    
    def _shutdown(self):
        """关闭"""
        self._shutdown_event.set()
    
    def enable_hot_reload(self, config: ReloadConfig = None):
        """启用热重载"""
        self._config = config or ReloadConfig()
        self._file_watcher = FileWatcher(self._config)
        self._file_watcher.add_callback(self._on_files_changed)
        self._file_watcher.start()
        logger.info("Hot reload enabled")
    
    def _on_files_changed(self, changed_files: List[str]):
        """文件变更回调"""
        logger.info(f"Detected file changes: {changed_files}")
        self._restart()
    
    def disable_hot_reload(self):
        """禁用热重载"""
        if self._file_watcher:
            self._file_watcher.stop()
            self._file_watcher = None
        logger.info("Hot reload disabled")


class Reloader:
    """代码重载器"""
    
    def __init__(self):
        self._modules: Set[str] = set()
        self._pre_import_modules: Dict[str, Any] = {}
    
    def snapshot_modules(self):
        """快照当前模块"""
        self._modules = set(sys.modules.keys())
        self._pre_import_modules = {
            name: module for name, module in sys.modules.items()
            if module is not None and hasattr(module, '__file__')
        }
        logger.debug(f"Snapshot taken: {len(self._modules)} modules")
    
    def reload_changed(self, changed_files: List[str]) -> List[str]:
        """重载变更的模块"""
        reloaded = []
        
        for file_path in changed_files:
            module_name = self._file_to_module(file_path)
            
            if module_name and module_name in sys.modules:
                try:
                    importlib.reload(sys.modules[module_name])
                    reloaded.append(module_name)
                    logger.info(f"Reloaded module: {module_name}")
                except Exception as e:
                    logger.error(f"Failed to reload {module_name}: {e}")
        
        return reloaded
    
    def _file_to_module(self, file_path: str) -> Optional[str]:
        """文件路径转模块名"""
        path = Path(file_path).resolve()
        
        for name, module in self._pre_import_modules.items():
            if module is not None and hasattr(module, '__file__') and module.__file__:
                module_path = Path(module.__file__).resolve()
                if path == module_path:
                    return name
        
        return None
    
    def full_reload(self):
        """完全重载"""
        for name in list(sys.modules.keys()):
            if name in self._pre_import_modules:
                try:
                    importlib.reload(sys.modules[name])
                except Exception as e:
                    logger.error(f"Failed to reload {name}: {e}")


def restart_server():
    """重启服务器"""
    logger.info("Restarting server...")
    
    exe = sys.executable
    args = sys.argv
    
    os.execv(exe, [exe] + args)


def fork_restart():
    if sys.platform == 'win32':
        logger.warning("fork_restart is not supported on Windows, using subprocess restart instead")
        restart_server()
        return
    pid = os.fork()
    
    if pid == 0:
        restart_server()
    else:
        logger.info(f"Forked new process: {pid}")
        os._exit(0)


class RestartManager:
    """重启管理器"""
    
    def __init__(self, app):
        self.app = app
        self._graceful_restart: Optional[GracefulRestart] = None
        self._reloader: Optional[Reloader] = None
    
    def setup(self, enable_hot_reload: bool = False, config: ReloadConfig = None):
        """设置重启管理"""
        self._graceful_restart = GracefulRestart(lambda: self.app)
        self._graceful_restart.setup_signal_handlers()
        
        if enable_hot_reload:
            self._reloader = Reloader()
            self._reloader.snapshot_modules()
            self._graceful_restart.enable_hot_reload(config)
    
    def trigger_restart(self):
        """触发重启"""
        if self._graceful_restart:
            self._graceful_restart._restart()
    
    def cleanup(self):
        """清理"""
        if self._graceful_restart:
            self._graceful_restart.disable_hot_reload()



__all__ = [
    'ReloadConfig',
    'FileWatcher',
    'GracefulRestart',
    'Reloader',
    'AutoReloader',
    'RestartManager',
    'restart_server',
    'fork_restart',
]