#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
SSL/TLS配置模块 - SSL/TLS Configuration
SSL配置实现

支持：
- 证书文件配置
- 密钥文件配置
- 密码保护
- SSL上下文创建
- 双向TLS认证
"""
import ssl
import logging
from typing import Optional, Union, Dict, Any, List
from pathlib import Path
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class SSLConfig:
    """
    SSL配置类
    
    使用示例:
        # 基本配置
        ssl_config = SSLConfig(
            cert="/path/to/cert.pem",
            key="/path/to/key.pem"
        )
        
        # 带密码的密钥
        ssl_config = SSLConfig(
            cert="/path/to/cert.pem",
            key="/path/to/key.pem",
            password="secret"
        )
        
        # 双向TLS
        ssl_config = SSLConfig(
            cert="/path/to/server.crt",
            key="/path/to/server.key",
            ca_cert="/path/to/ca.crt",
            verify_mode="required"
        )
    """
    
    cert: Optional[Union[str, Path]] = None
    key: Optional[Union[str, Path]] = None
    password: Optional[Union[str, bytes, callable]] = None
    ca_cert: Optional[Union[str, Path]] = None
    verify_mode: str = "none"
    verify_depth: int = 0
    
    protocol: int = ssl.PROTOCOL_TLS_SERVER
    options: int = ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1
    
    ciphers: Optional[str] = None
    sni_callback: Optional[callable] = None
    
    session_timeout: Optional[int] = None
    session_cache_mode: Optional[int] = None
    
    _context: Optional[ssl.SSLContext] = field(default=None, repr=False)
    
    @property
    def cert_file(self) -> Optional[Union[str, Path]]:
        return self.cert

    @property
    def key_file(self) -> Optional[Union[str, Path]]:
        return self.key

    def __post_init__(self):
        if isinstance(self.cert, str):
            self.cert = Path(self.cert)
        if isinstance(self.key, str):
            self.key = Path(self.key)
        if isinstance(self.ca_cert, str):
            self.ca_cert = Path(self.ca_cert)
    
    @property
    def context(self) -> ssl.SSLContext:
        """获取SSL上下文"""
        if self._context is None:
            self._context = self.create_context()
        return self._context
    
    def create_context(self) -> ssl.SSLContext:
        """
        创建SSL上下文
        
        Returns:
            配置好的SSLContext实例
        """
        context = ssl.SSLContext(self.protocol)
        
        context.options |= self.options
        
        if self.cert and self.key:
            context.load_cert_chain(
                str(self.cert),
                str(self.key),
                password=self.password
            )
        
        if self.ca_cert:
            context.load_verify_locations(str(self.ca_cert))
        
        verify_modes = {
            "none": ssl.CERT_NONE,
            "optional": ssl.CERT_OPTIONAL,
            "required": ssl.CERT_REQUIRED,
        }
        context.verify_mode = verify_modes.get(self.verify_mode, ssl.CERT_NONE)
        context.verify_flags = ssl.VERIFY_X509_STRICT
        
        if self.verify_depth > 0:
            context.verify_flags |= ssl.VERIFY_DEPTH
        
        if self.ciphers:
            context.set_ciphers(self.ciphers)
        else:
            context.set_ciphers("ECDHE+AESGCM:DHE+AESGCM:AES256+EECDH:AES256+EDH")
        
        if self.sni_callback:
            context.sni_callback = self.sni_callback
        
        if self.session_timeout:
            context.session_timeout = self.session_timeout
        
        if self.session_cache_mode is not None:
            context.session_cache_mode = self.session_cache_mode
        
        return context
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "cert": str(self.cert) if self.cert else None,
            "key": str(self.key) if self.key else None,
            "password": "***" if self.password else None,
            "ca_cert": str(self.ca_cert) if self.ca_cert else None,
            "verify_mode": self.verify_mode,
            "verify_depth": self.verify_depth,
            "protocol": self.protocol,
            "options": self.options,
            "ciphers": self.ciphers,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SSLConfig":
        """从字典创建"""
        return cls(
            cert=data.get("cert"),
            key=data.get("key"),
            password=data.get("password"),
            ca_cert=data.get("ca_cert"),
            verify_mode=data.get("verify_mode", "none"),
            verify_depth=data.get("verify_depth", 0),
            protocol=data.get("protocol", ssl.PROTOCOL_TLS_SERVER),
            options=data.get("options", ssl.OP_NO_SSLv2 | ssl.OP_NO_SSLv3 | ssl.OP_NO_TLSv1 | ssl.OP_NO_TLSv1_1),
            ciphers=data.get("ciphers"),
        )
    
    @classmethod
    def from_files(
        cls,
        cert: Union[str, Path],
        key: Union[str, Path],
        password: Optional[Union[str, bytes, callable]] = None
    ) -> "SSLConfig":
        """从证书文件创建"""
        return cls(cert=cert, key=key, password=password)


def create_ssl_context(
    cert: Optional[Union[str, Path]] = None,
    key: Optional[Union[str, Path]] = None,
    password: Optional[Union[str, bytes, callable]] = None,
    ca_cert: Optional[Union[str, Path]] = None,
    verify_mode: str = "none",
    **kwargs
) -> ssl.SSLContext:
    """
    创建SSL上下文的便捷函数
    
    Args:
        cert: 证书文件路径
        key: 密钥文件路径
        password: 密钥密码
        ca_cert: CA证书路径
        verify_mode: 验证模式 (none, optional, required)
        **kwargs: 其他SSL配置参数
        
    Returns:
        配置好的SSLContext实例
        
    使用示例:
        # 简单配置
        ctx = create_ssl_context(
            cert="/path/to/cert.pem",
            key="/path/to/key.pem"
        )
        
        # 双向TLS
        ctx = create_ssl_context(
            cert="/path/to/server.crt",
            key="/path/to/server.key",
            ca_cert="/path/to/ca.crt",
            verify_mode="required"
        )
    """
    config = SSLConfig(
        cert=cert,
        key=key,
        password=password,
        ca_cert=ca_cert,
        verify_mode=verify_mode,
        **kwargs
    )
    return config.create_context()


def load_ssl_config(
    cert_path: str,
    key_path: str,
    password: Optional[str] = None
) -> Dict[str, Any]:
    """
    加载SSL配置
    
    Args:
        cert_path: 证书文件路径
        key_path: 密钥文件路径
        password: 密钥密码
        
    Returns:
        SSL配置字典
    """
    cert_file = Path(cert_path)
    key_file = Path(key_path)
    
    if not cert_file.exists():
        raise FileNotFoundError(f"Certificate file not found: {cert_path}")
    
    if not key_file.exists():
        raise FileNotFoundError(f"Key file not found: {key_path}")
    
    return {
        "cert": str(cert_file),
        "key": str(key_file),
        "password": password,
    }


class SSLManager:
    """
    SSL管理器 - 管理多个SSL配置
    
    使用示例:
        manager = SSLManager()
        
        # 添加默认配置
        manager.add_config("default", SSLConfig(
            cert="/path/to/cert.pem",
            key="/path/to/key.pem"
        ))
        
        # SNI支持
        manager.add_config("example.com", SSLConfig(
            cert="/path/to/example.com.crt",
            key="/path/to/example.com.key"
        ))
        
        # 获取上下文
        ctx = manager.get_context("default")
    """
    
    def __init__(self):
        self._configs: Dict[str, SSLConfig] = {}
        self._default: Optional[str] = None
    
    def add_config(
        self,
        name: str,
        config: SSLConfig,
        default: bool = False
    ) -> None:
        """添加SSL配置"""
        self._configs[name] = config
        if default or self._default is None:
            self._default = name
    
    def get_config(self, name: str = None) -> Optional[SSLConfig]:
        """获取SSL配置"""
        if name is None:
            name = self._default
        return self._configs.get(name)
    
    def get_context(self, name: str = None) -> Optional[ssl.SSLContext]:
        """获取SSL上下文"""
        config = self.get_config(name)
        if config:
            return config.context
        return None
    
    def remove_config(self, name: str) -> bool:
        """移除SSL配置"""
        if name in self._configs:
            del self._configs[name]
            if self._default == name:
                self._default = next(iter(self._configs), None)
            return True
        return False
    
    def create_sni_callback(self) -> callable:
        """
        创建SNI回调函数
        
        Returns:
            SNI回调函数
        """
        def sni_callback(ssl_socket, server_name, ssl_context):
            config = self._configs.get(server_name.decode() if isinstance(server_name, bytes) else server_name)
            if config:
                ssl_socket.context = config.context
        
        return sni_callback


__all__ = [
    'SSLConfig',
    'SSLManager',
    'SSLContextBuilder',
    'create_ssl_context',
    'load_ssl_config',
]



