#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Daemon 模式 - Background Process Management
Daemon模式实现

功能：
- 后台运行服务器
- PID 文件管理
- 进程控制
"""
import asyncio
import logging
import os
import signal
import sys
import time
from pathlib import Path
from typing import Optional, Callable, Any, Dict
from dataclasses import dataclass
from kewe.utils.compat import json

logger = logging.getLogger(__name__)


@dataclass
class DaemonConfig:
    """Daemon 配置"""
    pid_file: Optional[str] = None
    log_file: Optional[str] = None
    working_dir: Optional[str] = None
    umask: int = 0
    detach: bool = True


class DaemonManager:
    """
    Daemon 进程管理器
    
    支持后台运行、PID 文件管理、进程控制
    
    使用示例:
        # 启动 daemon
        daemon = DaemonManager(pid_file="/var/run/kewe.pid")
        daemon.start()
        
        # 停止 daemon
        daemon.stop()
        
        # 重启 daemon
        daemon.restart()
    
    CLI 使用:
        $ kewe run myapp:app --daemon
        $ kewe run myapp:app --stop
        $ kewe run myapp:app --restart
    """
    
    def __init__(
        self,
        pid_file: Optional[str] = None,
        log_file: Optional[str] = None,
        working_dir: Optional[str] = None
    ):
        self.pid_file = Path(pid_file) if pid_file else None
        self.log_file = Path(log_file) if log_file else None
        self.working_dir = working_dir or os.getcwd()
        self._daemonized = False
    
    def _write_pid_file(self, pid: int):
        """写入 PID 文件"""
        if self.pid_file:
            self.pid_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.pid_file, 'w') as f:
                json.dump({
                    'pid': pid,
                    'start_time': time.time(),
                    'working_dir': self.working_dir
                }, f)
            logger.debug(f"PID file written: {self.pid_file}")
    
    def _read_pid_file(self) -> Optional[Dict[str, Any]]:
        """读取 PID 文件"""
        if self.pid_file and self.pid_file.exists():
            try:
                with open(self.pid_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError) as e:
                logger.warning(f"Failed to read PID file: {e}")
        return None
    
    def _remove_pid_file(self):
        """删除 PID 文件"""
        if self.pid_file and self.pid_file.exists():
            self.pid_file.unlink()
            logger.debug(f"PID file removed: {self.pid_file}")
    
    def _double_fork(self):
        """
        双重 fork 实现 daemon
        
        这是标准的 Unix daemon 实现方式：
        1. 第一次 fork 创建子进程，父进程退出
        2. 子进程创建新会话
        3. 第二次 fork 确保进程不是会话首进程
        """
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
        
        os.chdir(self.working_dir)
        os.setsid()
        os.umask(0)
        
        pid = os.fork()
        if pid > 0:
            sys.exit(0)
        
        sys.stdout.flush()
        sys.stderr.flush()
        
        if self.log_file:
            self.log_file.parent.mkdir(parents=True, exist_ok=True)
            log_fd = os.open(self.log_file, os.O_RDWR | os.O_CREAT | os.O_APPEND)
            os.dup2(log_fd, sys.stdout.fileno())
            os.dup2(log_fd, sys.stderr.fileno())
        else:
            devnull = os.open(os.devnull, os.O_RDWR)
            os.dup2(devnull, sys.stdin.fileno())
            os.dup2(devnull, sys.stdout.fileno())
            os.dup2(devnull, sys.stderr.fileno())
        
        self._daemonized = True
        logger.info(f"Daemon started with PID: {os.getpid()}")
    
    def start(self, target: Callable = None, *args, **kwargs) -> bool:
        """
        启动 daemon
        
        Args:
            target: 目标函数
            args: 位置参数
            kwargs: 关键字参数
            
        Returns:
            是否成功启动
        """
        if self.is_running():
            logger.error("Daemon is already running")
            return False
        
        if sys.platform == 'win32':
            logger.warning("Daemon mode is not fully supported on Windows")
            if target:
                return target(*args, **kwargs)
            return True
        
        self._double_fork()
        self._write_pid_file(os.getpid())
        
        try:
            if target:
                return target(*args, **kwargs)
            return True
        except Exception as e:
            logger.error(f"Daemon target failed: {e}")
            self._remove_pid_file()
            return False
    
    def stop(self, timeout: float = 30.0) -> bool:
        """
        停止 daemon
        
        Args:
            timeout: 超时时间
            
        Returns:
            是否成功停止
        """
        pid_info = self._read_pid_file()
        if not pid_info:
            logger.warning("No PID file found, daemon may not be running")
            return True
        
        pid = pid_info['pid']
        
        try:
            os.kill(pid, signal.SIGTERM)
            logger.info(f"Sent SIGTERM to PID: {pid}")
        except ProcessLookupError:
            logger.warning(f"Process {pid} not found")
            self._remove_pid_file()
            return True
        except PermissionError:
            logger.error(f"No permission to kill process {pid}")
            return False
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                os.kill(pid, 0)
                time.sleep(0.5)
            except ProcessLookupError:
                self._remove_pid_file()
                logger.info(f"Daemon stopped (PID: {pid})")
                return True
        
        try:
            os.kill(pid, signal.SIGKILL)
            logger.warning(f"Sent SIGKILL to PID: {pid}")
            self._remove_pid_file()
            return True
        except ProcessLookupError:
            self._remove_pid_file()
            return True
    
    def restart(self, target: Callable = None, *args, **kwargs) -> bool:
        """
        重启 daemon
        
        Args:
            target: 目标函数
            args: 位置参数
            kwargs: 关键字参数
            
        Returns:
            是否成功重启
        """
        if self.is_running():
            if not self.stop():
                return False
            time.sleep(1)
        
        return self.start(target, *args, **kwargs)
    
    def is_running(self) -> bool:
        """
        检查 daemon 是否在运行
        
        Returns:
            是否在运行
        """
        pid_info = self._read_pid_file()
        if not pid_info:
            return False
        
        try:
            os.kill(pid_info['pid'], 0)
            return True
        except ProcessLookupError:
            self._remove_pid_file()
            return False
    
    def get_status(self) -> Dict[str, Any]:
        """
        获取 daemon 状态
        
        Returns:
            状态信息
        """
        pid_info = self._read_pid_file()
        if not pid_info:
            return {'running': False}
        
        running = self.is_running()
        uptime = time.time() - pid_info['start_time'] if running else 0
        
        return {
            'running': running,
            'pid': pid_info['pid'] if running else None,
            'uptime': uptime,
            'working_dir': pid_info.get('working_dir'),
            'pid_file': str(self.pid_file) if self.pid_file else None
        }


class DaemonContext:
    """
    Daemon 上下文管理器
    
    使用示例:
        with DaemonContext(pid_file="/var/run/kewe.pid"):
            app.run()
    """
    
    def __init__(
        self,
        pid_file: Optional[str] = None,
        log_file: Optional[str] = None,
        working_dir: Optional[str] = None,
        detach: bool = True
    ):
        self.manager = DaemonManager(
            pid_file=pid_file,
            log_file=log_file,
            working_dir=working_dir
        )
        self.detach = detach
    
    def __enter__(self):
        if self.detach and sys.platform != 'win32':
            self.manager._double_fork()
            self.manager._write_pid_file(os.getpid())
        return self.manager
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.manager._remove_pid_file()
        return False


def run_as_daemon(
    app,
    host: str = "127.0.0.1",
    port: int = 8000,
    workers: int = 1,
    pid_file: Optional[str] = None,
    log_file: Optional[str] = None
) -> bool:
    """
    以 daemon 模式运行应用
    
    Args:
        app: Kewe 应用实例
        host: 主机地址
        port: 端口
        workers: Worker 数量
        pid_file: PID 文件路径
        log_file: 日志文件路径
        
    Returns:
        是否成功启动
    """
    daemon = DaemonManager(pid_file=pid_file, log_file=log_file)
    
    def run_app():
        app.run(host=host, port=port, workers=workers)
        return True
    
    return daemon.start(run_app)


__all__ = [
    'DaemonConfig',
    'DaemonManager',
    'DaemonContext',
    'run_as_daemon',
]
