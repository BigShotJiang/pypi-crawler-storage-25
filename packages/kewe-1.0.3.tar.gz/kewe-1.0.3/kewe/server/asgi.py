#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ASGI适配器 - ASGI Adapter
ASGI实现，提供完整的ASGI 3.0合规性

提供ASGI兼容性，支持在ASGI服务器中运行Kewe应用
支持：
- HTTP 请求处理（含流式响应）
- WebSocket 连接（含子协议协商）
- Lifespan 生命周期管理
- 请求取消和断开连接处理
"""
import logging
import asyncio
import urllib.parse
from typing import Dict, Any, Optional, Callable, Awaitable, List, AsyncGenerator
from enum import Enum
from dataclasses import dataclass, field

_HEADER_SANITIZE_TABLE = bytes.maketrans(b'', b'')
_UNSAFE_HEADER_BYTES = bytes(range(0x20)) + bytes([0x7f])
_SAFE_HEADER_TABLE = bytes.maketrans(_UNSAFE_HEADER_BYTES, b' ' * len(_UNSAFE_HEADER_BYTES))

from kewe.request import Request
from kewe.response import Response
from kewe.utils.compat import json as _json

logger = logging.getLogger(__name__)


class ASGIState(Enum):
    """ASGI连接状态"""
    REQUEST = "request"
    RESPONSE_STARTED = "response_started"
    RESPONSE_COMPLETE = "response_complete"
    DISCONNECTED = "disconnected"


@dataclass
class ASGIContext:
    """ASGI上下文"""
    scope: Dict[str, Any]
    state: ASGIState = ASGIState.REQUEST
    disconnect_received: bool = False
    response_sent: bool = False
    bytes_sent: int = 0


class ASGIAdapter:
    """
    ASGI适配器 - 完整的 ASGI 3.0 实现
    将Kewe应用转换为ASGI兼容的应用
    """
    
    def __init__(self, app, enable_lifespan: bool = True):
        self.app = app
        self.lifespan_state: Dict[str, Any] = {}
        self.enable_lifespan = enable_lifespan
    
    async def __call__(
        self,
        scope: Dict[str, Any],
        receive: Callable[[], Awaitable[Dict[str, Any]]],
        send: Callable[[Dict[str, Any]], Awaitable[None]]
    ):
        """
        ASGI接口 - ASGI 3.0 规范
        
        Args:
            scope: ASGI作用域
            receive: 接收消息的函数
            send: 发送消息的函数
        """
        scope_type = scope['type']
        
        if scope_type == 'http':
            await self.handle_http(scope, receive, send)
        elif scope_type == 'websocket':
            await self.handle_websocket(scope, receive, send)
        elif scope_type == 'lifespan':
            await self.handle_lifespan(scope, receive, send)
        else:
            logger.warning(f"Unknown scope type: {scope_type}")
    
    async def handle_lifespan(
        self,
        scope: Dict[str, Any],
        receive: Callable,
        send: Callable
    ):
        """
        处理 Lifespan 生命周期事件 - ASGI 3.0 规范
        """
        while True:
            message = await receive()
            
            if message['type'] == 'lifespan.startup':
                try:
                    await self._handle_startup()
                    await send({'type': 'lifespan.startup.complete'})
                    if 'state' in scope:
                        self.lifespan_state.update(scope['state'])
                except Exception as e:
                    logger.error(f"Lifespan startup error: {e}")
                    await send({
                        'type': 'lifespan.startup.failed',
                        'message': str(e)
                    })
                    break
            
            elif message['type'] == 'lifespan.shutdown':
                try:
                    await self._handle_shutdown()
                    if 'state' in scope:
                        scope['state'] = dict(self.lifespan_state)
                    await send({'type': 'lifespan.shutdown.complete'})
                except Exception as e:
                    logger.error(f"Lifespan shutdown error: {e}")
                    await send({
                        'type': 'lifespan.shutdown.failed',
                        'message': str(e)
                    })
                break
            
            else:
                logger.warning(f"Unknown lifespan message type: {message.get('type')}")
                break
    
    async def _handle_startup(self):
        logger.info("ASGI lifespan startup")

        if hasattr(self.app, 'config') and hasattr(self.app.config, 'to_config'):
            try:
                config_obj = self.app.config.to_config()
                if hasattr(config_obj, 'validate'):
                    config_obj.validate()
            except Exception as e:
                logger.error(f"Config validation failed: {e}")

        if hasattr(self.app, '_lifespan') and self.app._lifespan is not None:
            await self.app._execute_lifespan_startup()

        if hasattr(self.app, 'middleware_manager'):
            await self.app._emit_signal("server.init.before", app=self.app)
            await self.app.middleware_manager.execute_before_server_start(
                self.app,
                asyncio.get_running_loop()
            )
            await self.app.middleware_manager.execute_after_server_start(
                self.app,
                asyncio.get_running_loop()
            )
            await self.app._emit_signal("server.init.after", app=self.app)

    async def _handle_shutdown(self):
        logger.info("ASGI lifespan shutdown")

        if hasattr(self.app, 'middleware_manager'):
            await self.app._emit_signal("server.shutdown.before", app=self.app)
            await self.app.middleware_manager.execute_before_server_stop(
                self.app,
                asyncio.get_running_loop()
            )
            await self.app.middleware_manager.execute_after_server_stop(
                self.app,
                asyncio.get_running_loop()
            )
            await self.app._emit_signal("server.shutdown.after", app=self.app)

        if hasattr(self.app, '_lifespan') and self.app._lifespan is not None:
            await self.app._execute_lifespan_shutdown()
    
    async def handle_http(
        self,
        scope: Dict[str, Any],
        receive: Callable,
        send: Callable
    ):
        ctx = ASGIContext(scope=scope)
        start_time = asyncio.get_running_loop().time()
        
        disconnect_received = False
        
        try:
            body = b''
            request_method = scope.get('method', 'GET')
            content_length = None
            content_length_values = []
            for name, value in scope.get('headers', []):
                if name == b'content-length':
                    content_length_values.append(int(value))
            if len(content_length_values) > 1:
                unique_values = set(content_length_values)
                if len(unique_values) > 1:
                    await send({
                        'type': 'http.response.start',
                        'status': 400,
                        'headers': [
                            [b'content-type', b'text/plain; charset=utf-8'],
                        ],
                    })
                    await send({
                        'type': 'http.response.body',
                        'body': b'Bad Request: conflicting Content-Length headers',
                    })
                    return
            if content_length_values:
                content_length = content_length_values[0]
            
            max_body_size = getattr(self.app.config, 'request_max_size', 100 * 1024 * 1024)
            if max_body_size and content_length is not None and content_length > max_body_size:
                await send({
                    'type': 'http.response.start',
                    'status': 413,
                    'headers': [
                        [b'content-type', b'application/json'],
                    ],
                })
                await send({
                    'type': 'http.response.body',
                    'body': b'{"error":"Request body too large"}',
                })
                return
            
            if (content_length is not None and content_length > 0) or request_method in ('POST', 'PUT', 'PATCH', 'DELETE'):
                more_body = True
                total_read = 0
                if content_length is not None and content_length > 0:
                    body_buf = bytearray(content_length)
                    body_offset = 0
                else:
                    body_parts = []
                while more_body:
                    message = await receive()
                    if message['type'] == 'http.request':
                        chunk = message.get('body', b'')
                        total_read += len(chunk)
                        if max_body_size and total_read > max_body_size:
                            await send({
                                'type': 'http.response.start',
                                'status': 413,
                                'headers': [[b'content-type', b'application/json']],
                            })
                            await send({
                                'type': 'http.response.body',
                                'body': b'{"error":"Request body too large"}',
                            })
                            return
                        if content_length is not None and content_length > 0:
                            body_buf[body_offset:body_offset + len(chunk)] = chunk
                            body_offset += len(chunk)
                        else:
                            body_parts.append(chunk)
                        more_body = message.get('more_body', False)
                    elif message['type'] == 'http.disconnect':
                        disconnect_received = True
                        break
                if content_length is not None and content_length > 0:
                    body = bytes(body_buf[:body_offset])
                else:
                    body = b''.join(body_parts)
            
            if disconnect_received:
                logger.debug("Client disconnected before request completed")
                return
            
            request = self._build_request(scope, body)
            request._is_disconnected = False

            async def _wrapped_receive():
                nonlocal disconnect_received
                if disconnect_received:
                    ctx.disconnect_received = True
                    return {'type': 'http.disconnect'}
                try:
                    msg = await receive()
                    if msg.get('type') == 'http.disconnect':
                        disconnect_received = True
                        ctx.disconnect_received = True
                        request._is_disconnected = True
                    return msg
                except Exception:
                    disconnect_received = True
                    ctx.disconnect_received = True
                    request._is_disconnected = True
                    return {'type': 'http.disconnect'}

            request._receive = _wrapped_receive
            
            try:
                request_timeout = getattr(self.app.config, 'request_timeout', None)
                if request_timeout and request_timeout > 0:
                    try:
                        response = await asyncio.wait_for(
                            self.app.handle_request(request),
                            timeout=request_timeout
                        )
                    except asyncio.TimeoutError:
                        if not disconnect_received and ctx.state == ASGIState.REQUEST:
                            if hasattr(self.app, '_on_request_cancelled'):
                                try:
                                    await self.app._on_request_cancelled(request)
                                except Exception:
                                    logger.debug("Error in request cancellation handler", exc_info=True)
                            from kewe.errors.exceptions import RequestTimeout
                            try:
                                timeout_exc = RequestTimeout()
                                timeout_response = await self.app._handle_exception(request, timeout_exc)
                            except Exception:
                                timeout_response = Response(
                                    body=b'{"type":"about:blank","title":"Request Timeout","status":408}',
                                    status=408,
                                    content_type="application/problem+json"
                                )
                            await self._send_http_response(timeout_response, send, ctx)
                        return
                else:
                    response = await self.app.handle_request(request)
                
                if response is None:
                    logger.error("Handler returned None for request %s %s", request.method, request.path)
                    from kewe.response import Response
                    response = Response(
                        body=b'{"detail":"Internal Server Error: handler returned no response"}',
                        status=500,
                        content_type="application/json"
                    )
                
                if disconnect_received:
                    logger.debug("Client disconnected, not sending response")
                    return
                
                elapsed = asyncio.get_running_loop().time() - start_time
                if 'X-Response-Time' not in response.headers:
                    response.headers['X-Response-Time'] = f"{elapsed:.3f}s"
                
                await self._send_http_response(response, send, ctx)
                
            except Exception as e:
                if isinstance(e, asyncio.CancelledError):
                    raise
                logger.error(f"ASGI HTTP request error: {e}")

                if not disconnect_received and ctx.state == ASGIState.REQUEST:
                    error_response = await self._handle_exception(request, e)
                    await self._send_http_response(error_response, send, ctx)
        
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.error(f"ASGI HTTP handling error: {e}")
            if ctx.state == ASGIState.REQUEST:
                try:
                    await send({
                        'type': 'http.response.start',
                        'status': 500,
                        'headers': [[b'content-type', b'application/json']],
                    })
                    await send({
                        'type': 'http.response.body',
                        'body': b'{"detail":"Internal Server Error"}',
                    })
                except Exception:
                    logger.warning("Failed to send error response", exc_info=True)

    async def _send_http_response(
        self,
        response: Response,
        send: Callable,
        ctx: ASGIContext
    ):
        """发送HTTP响应 - 支持流式响应"""
        headers = []
        header_keys_lower = set()

        if hasattr(response, '_headers') and hasattr(response._headers, 'rawItems'):
            raw_items = response._headers.rawItems()
        elif hasattr(response, 'headers'):
            raw_items = response.headers.items()
        else:
            raw_items = []

        for key, value in raw_items:
            val_str = str(value)
            if '\r' in key or '\n' in key:
                safe_key = key.replace('\r', '').replace('\n', '').encode('utf-8').translate(_SAFE_HEADER_TABLE)
            else:
                safe_key = key.encode('utf-8')
            if '\r' in val_str or '\n' in val_str:
                safe_value = val_str.replace('\r', '').replace('\n', '').encode('utf-8').translate(_SAFE_HEADER_TABLE)
            else:
                safe_value = val_str.encode('utf-8')
            headers.append((safe_key, safe_value))
            header_keys_lower.add(safe_key.lower())
        
        cookie_headers = getattr(response, 'get_cookie_headers', lambda: [])()

        for name, value in cookie_headers:
            headers.append((name.encode('utf-8'), value.encode('utf-8')))
        
        if b'content-type' not in header_keys_lower:
            headers.append((b'content-type', response.content_type.encode('utf-8')))
        
        if response.is_streaming and response.stream_generator:
            await send({
                'type': 'http.response.start',
                'status': response.status,
                'headers': headers
            })
            ctx.state = ASGIState.RESPONSE_STARTED
            
            try:
                async for chunk in response.stream_generator:
                    if ctx.disconnect_received:
                        break

                    if isinstance(chunk, str):
                        chunk = chunk.encode('utf-8')
                    elif not isinstance(chunk, bytes):
                        chunk = str(chunk).encode('utf-8')

                    await send({
                        'type': 'http.response.body',
                        'body': chunk,
                        'more_body': True
                    })
                    ctx.bytes_sent += len(chunk)
            except Exception as e:
                logger.error(f"Streaming response error: {e}", exc_info=True)
            finally:
                if hasattr(response.stream_generator, 'aclose'):
                    await response.stream_generator.aclose()
                
                if not ctx.disconnect_received and ctx.state != ASGIState.RESPONSE_COMPLETE:
                    try:
                        await send({
                            'type': 'http.response.body',
                            'body': b'',
                            'more_body': False
                        })
                        ctx.state = ASGIState.RESPONSE_COMPLETE
                        ctx.response_sent = True
                    except Exception:
                        logger.warning("Failed to send final body chunk", exc_info=True)

                if hasattr(response, 'background') and response.background is not None:
                    try:
                        loop = asyncio.get_running_loop()
                        if hasattr(response.background, 'run'):
                            task = loop.create_task(response.background.run())
                        elif callable(response.background):
                            task = loop.create_task(response.background())
                        else:
                            task = None
                        if task:
                            task.add_done_callback(lambda t: t.exception() if not t.cancelled() and t.exception() else None)
                    except RuntimeError:
                        if hasattr(response.background, 'run'):
                            await response.background.run()
                        elif callable(response.background):
                            await response.background()
                    except Exception as bg_exc:
                        logger.error(f"Background task error: {bg_exc}")
        else:
            body = response.body if isinstance(response.body, bytes) else response.body.encode('utf-8')
            if b'content-length' not in header_keys_lower:
                headers.append((b'content-length', str(len(body)).encode('utf-8')))
            
            await send({
                'type': 'http.response.start',
                'status': response.status,
                'headers': headers
            })
            ctx.state = ASGIState.RESPONSE_STARTED
            
            if body:
                await send({
                    'type': 'http.response.body',
                    'body': body,
                    'more_body': False
                })
            else:
                await send({
                    'type': 'http.response.body',
                    'body': b'',
                    'more_body': False
                })
            
            ctx.state = ASGIState.RESPONSE_COMPLETE
            ctx.response_sent = True
            
            if hasattr(response, 'background') and response.background is not None:
                try:
                    loop = asyncio.get_running_loop()
                    if hasattr(response.background, 'run'):
                        loop.create_task(response.background.run())
                    elif callable(response.background):
                        loop.create_task(response.background() if asyncio.iscoroutinefunction(response.background) else asyncio.to_thread(response.background))
                except Exception as bg_exc:
                    logger.error(f"Background task error: {bg_exc}")

    async def handle_websocket(
        self,
        scope: Dict[str, Any],
        receive: Callable,
        send: Callable
    ):
        """处理WebSocket连接 - 支持子协议协商"""
        path = scope['path']
        websocket_handler = self._find_websocket_handler(path, scope)
        
        if not websocket_handler:
            await send({
                'type': 'websocket.close',
                'code': 1008,
                'reason': 'No route found'
            })
            return
        
        subprotocols = scope.get('subprotocols', [])
        selected_subprotocol = None
        
        if hasattr(websocket_handler, '_subprotocols'):
            for proto in websocket_handler._subprotocols:
                if proto in subprotocols:
                    selected_subprotocol = proto
                    break
        
        from kewe.websocket.connection import WebSocketConnection
        ws = WebSocketConnection(
            _asgi_scope=scope,
            _asgi_receive=receive,
            _asgi_send=send
        )
        
        if selected_subprotocol:
            ws.protocol._subprotocol = selected_subprotocol
        
        try:
            await ws.accept(subprotocol=selected_subprotocol)
        except Exception as e:
            logger.error(f"ASGI WebSocket accept error: {e}")
            try:
                await send({
                    'type': 'websocket.close',
                    'code': 1011,
                    'reason': 'Internal error'
                })
            except Exception:
                logger.warning("Failed to send WebSocket close on accept error", exc_info=True)
            return
        
        try:
            from kewe.base.context import RequestContextManager, g as _g
            ctx_mgr = RequestContextManager()
            ctx_mgr.__enter__()
            try:
                _g.request = ws
                _g.app = self.app

                if hasattr(self.app, '_onion_chain') and self.app._onion_chain._middlewares:
                    from kewe.request.request import Request
                    pseudo_request = Request(
                        method="GET", path=path,
                        headers={k.decode(): v.decode() for k, v in scope.get('headers', [])},
                        query_params={}, body=b'',
                        client_ip=scope.get('client', ('127.0.0.1', 0))[0] if scope.get('client') else '127.0.0.1',
                    )
                    pseudo_request._scope = scope
                    for mw in self.app._onion_chain._middlewares:
                        if getattr(mw, 'websocket_safe', False):
                            try:
                                result = await mw.execute(pseudo_request, lambda r: None)
                                from kewe.response import Response
                                if isinstance(result, Response) and result.status >= 400:
                                    await send({'type': 'websocket.close', 'code': 1008, 'reason': 'Forbidden'})
                                    return
                            except Exception:
                                logger.debug("WebSocket middleware error", exc_info=True)

                if hasattr(websocket_handler, '_websocket_dependencies'):
                    deps = websocket_handler._websocket_dependencies
                    for dep in deps:
                        import inspect as _inspect
                        if _inspect.iscoroutinefunction(dep):
                            await dep(ws)
                        else:
                            dep(ws)

                resolver = getattr(self.app, '_dependency_resolver', None)
                if resolver is not None:
                    resolved = await resolver._resolve_parameters(websocket_handler, ws, self.app, [])
                    await websocket_handler(ws, **resolved)
                else:
                    await websocket_handler(ws)
            except Exception as e:
                logger.error(f"ASGI WebSocket error: {e}", exc_info=True)
                if hasattr(self.app, '_handle_exception'):
                    try:
                        from kewe.websocket.exceptions import WebSocketException
                        if isinstance(e, WebSocketException):
                            ws_exc = e
                        else:
                            ws_exc = WebSocketException(message=str(e), code=1011)
                        await self.app._handle_exception(ws, ws_exc)
                    except Exception:
                        logger.debug("WebSocket exception handler error", exc_info=True)
                try:
                    await send({
                        'type': 'websocket.close',
                        'code': 1011,
                        'reason': 'Internal error'
                    })
                except Exception:
                    logger.warning("Failed to send WebSocket close on error", exc_info=True)
            else:
                try:
                    if not getattr(ws, '_close_sent', False) and ws.state.value <= 2:
                        close_code = getattr(ws, '_close_code', 1000) or 1000
                        close_reason = getattr(ws, '_close_reason', '') or ''
                        close_msg = {'type': 'websocket.close', 'code': close_code}
                        if close_reason:
                            close_msg['reason'] = close_reason[:123]
                        await send(close_msg)
                        ws._close_sent = True
                except Exception:
                    logger.warning("Failed to send WebSocket close", exc_info=True)
                try:
                    msg = await asyncio.wait_for(receive(), timeout=5.0)
                    while msg.get('type') != 'websocket.disconnect':
                        msg = await asyncio.wait_for(receive(), timeout=5.0)
                except (asyncio.TimeoutError, Exception):
                    logger.debug("WebSocket disconnect wait interrupted", exc_info=True)
            finally:
                try:
                    ctx_mgr.__exit__(None, None, None)
                except Exception:
                    logger.debug("Context manager exit error", exc_info=True)
        finally:
            pass
    
    def _build_request(self, scope: Dict[str, Any], body: bytes) -> Request:
        path = scope['path']
        query_string = scope.get('query_string', b'')
        if query_string:
            query_params = urllib.parse.parse_qs(query_string.decode('utf-8', errors='surrogateescape'), keep_blank_values=True)
        else:
            query_params = {}

        headers = {}
        for key, value in scope.get('headers', []):
            headers[key.decode('utf-8', errors='surrogateescape').lower()] = value.decode('utf-8', errors='surrogateescape')

        client = scope.get('client')
        client_ip = client[0] if client else ''

        server = scope.get('server')
        host = server[0] if server else ''

        root_path = scope.get('root_path', '')

        http_version = scope.get('http_version', '1.1')
        request = Request(
            method=scope['method'],
            path=path,
            headers=headers,
            query_params=query_params,
            body=body,
            client_ip=client_ip,
            protocol=f"HTTP/{http_version}",
            _scope=scope,
        )

        if http_version == '2':
            request._http_version = '2'
            request._supports_push = 'http.response.push' in scope.get('asgi', {}).get('extensions', {})
            request._http2_stream_id = scope.get('http2_stream_id')

        if root_path:
            request.state.root_path = root_path

        if hasattr(self, 'app'):
            request.app = self.app

        if hasattr(self, 'lifespan_state') and self.lifespan_state:
            request.state._lifespan_state = self.lifespan_state

        if 'state' in scope:
            for k, v in scope['state'].items():
                setattr(request.state, k, v)
        elif hasattr(self, 'lifespan_state') and self.lifespan_state:
            if 'state' not in scope:
                scope['state'] = {}
            scope['state'].update(self.lifespan_state)

        return request

    @staticmethod
    def _get_header(headers, name, default=b''):
        for key, value in headers:
            if key == name:
                return value
        return default

    async def _send_http2_push(
        self,
        path: str,
        send: Callable,
        scope: Dict[str, Any],
    ):
        if 'http.response.push' not in scope.get('asgi', {}).get('extensions', {}):
            return
        try:
            push_scope = dict(scope)
            push_scope['path'] = path
            push_scope['method'] = 'GET'
            push_scope['type'] = 'http'
            await send({
                'type': 'http.response.push',
                'path': path,
                'headers': [
                    [b':method', b'GET'],
                    [b':path', path.encode()],
                    [b':scheme', b'https'],
                    [b':authority', self._get_header(scope.get('headers', []), b'host', b'localhost')],
                ],
            })
        except Exception as e:
            logger.warning(f"HTTP/2 push failed: {e}")

    async def _handle_exception(self, request: Request, exc: Exception) -> Response:
        """统一异常处理 - 委托给框架异常处理链"""
        try:
            if hasattr(self.app, '_handle_exception'):
                return await self.app._handle_exception(request, exc)

            if hasattr(self.app, '_custom_exception_handlers'):
                for exc_type in type(exc).__mro__:
                    handler = self.app._custom_exception_handlers.get(exc_type)
                    if handler:
                        result = handler(request, exc)
                        if asyncio.iscoroutine(result):
                            result = await result
                        if isinstance(result, Response):
                            return result
                        if isinstance(result, dict):
                            return Response(
                                body=_json.dumps(result).encode('utf-8'),
                                status=getattr(exc, 'status_code', 500),
                                content_type='application/json'
                            )
        except Exception as handler_exc:
            logger.error(f"Exception handler error: {handler_exc}")

        if hasattr(exc, 'to_problem_details'):
            try:
                problem = exc.to_problem_details()
                return Response(
                    body=_json.dumps(problem).encode('utf-8'),
                    status=getattr(exc, 'status_code', 500),
                    content_type='application/problem+json'
                )
            except Exception:
                logger.warning("Failed to generate problem details", exc_info=True)

        if hasattr(exc, 'status_code'):
            return Response(
                body=_json.dumps({"detail": str(exc)}).encode('utf-8'),
                status=exc.status_code,
                content_type='application/json'
            )

        return Response(
            body=_json.dumps({"detail": "Internal Server Error"}).encode('utf-8'),
            status=500,
            content_type='application/json'
        )
    
    def _find_websocket_handler(self, path: str, scope: Dict[str, Any]) -> Optional[Callable]:
        """查找WebSocket路由处理器 - 支持路径参数"""
        from kewe.websocket.manager import find_websocket_handler
        handler, path_params = find_websocket_handler(self.app, path)
        if handler and path_params:
            scope['path_params'] = path_params
        return handler


def asgi_app(app):
    """
    创建ASGI应用
    
    使用示例:
        from kewe import Kewe
        from kewe.server.asgi import asgi_app
        
        app = Kewe("MyApp")
        
        @app.route("/")
        async def index(request):
            return {"message": "Hello, ASGI!"}
        
        asgi_application = asgi_app(app)
    """
    return ASGIAdapter(app)


def create_asgi_app(
    app_factory: Callable[[], Any],
    lifespan: bool = True
) -> Callable:
    """
    创建ASGI应用工厂
    
    Args:
        app_factory: 应用工厂函数
        lifespan: 是否启用lifespan支持
        
    Returns:
        ASGI应用
        
    使用示例:
        def create_app():
            app = Kewe("MyApp")
            return app
        
        asgi_app = create_asgi_app(create_app)
    """
    adapter = None
    _init_lock: Optional[asyncio.Lock] = None

    async def asgi_handler(scope, receive, send):
        nonlocal adapter, _init_lock
        if adapter is None:
            if _init_lock is None:
                _init_lock = asyncio.Lock()
            async with _init_lock:
                if adapter is None:
                    app = app_factory()
                    adapter = ASGIAdapter(app, enable_lifespan=lifespan)
        if not lifespan and scope['type'] == 'lifespan':
            message = await receive()
            if message['type'] == 'lifespan.startup':
                await send({'type': 'lifespan.startup.complete'})
            elif message['type'] == 'lifespan.shutdown':
                await send({'type': 'lifespan.shutdown.complete'})
            return
        await adapter(scope, receive, send)
    
    return asgi_handler


class ASGIResponse:
    """ASGI响应构建器 - 便捷的ASGI响应构造"""

    def __init__(self):
        self._status: int = 200
        self._headers: list = []
        self._body_parts: list = []

    def set_status(self, status: int):
        self._status = status

    def set_header(self, name: str, value: str):
        self._headers.append((name.encode('utf-8'), value.encode('utf-8')))

    def write(self, data: bytes):
        self._body_parts.append(data)

    @property
    def status(self) -> int:
        return self._status

    @property
    def headers(self) -> list:
        return self._headers

    @property
    def body_parts(self) -> list:
        return self._body_parts

    @property
    def body(self) -> bytes:
        return b''.join(self._body_parts)


class StreamingASGIResponse:
    """流式ASGI响应"""

    def __init__(self):
        self._status: int = 200
        self._headers: list = []
        self._chunks: list = []

    def set_status(self, status: int):
        self._status = status

    def set_header(self, name: str, value: str):
        self._headers.append((name.encode('utf-8'), value.encode('utf-8')))

    async def write(self, data: bytes):
        self._chunks.append(data)

    @property
    def status(self) -> int:
        return self._status

    @property
    def headers(self) -> list:
        return self._headers


__all__ = [
    'ASGIAdapter',
    'ASGIState',
    'ASGIContext',
    'ASGIResponse',
    'StreamingASGIResponse',
    'asgi_app',
    'create_asgi_app',
]
