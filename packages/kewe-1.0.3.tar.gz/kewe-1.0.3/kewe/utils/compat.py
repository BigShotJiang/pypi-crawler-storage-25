#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
兼容性模块 - Compatibility Module
提供orjson、ujson等性能库的自动检测和使用
默认JSON库为orjson（最快），ujson为备选回退
"""
import asyncio
import logging
import sys
import os
from typing import Optional, Callable, Any, TypeVar, Coroutine
from functools import wraps, partial

logger = logging.getLogger(__name__)

T = TypeVar('T')

UVLOOP_AVAILABLE = False
WINLOOP_AVAILABLE = False
UJSON_AVAILABLE = False
ORJSON_AVAILABLE = False
UVLOOP_VERSION: Optional[str] = None
WINLOOP_VERSION: Optional[str] = None
UJSON_VERSION: Optional[str] = None
ORJSON_VERSION: Optional[str] = None

_uvloop_module = None
_winloop_module = None
_ujson_module = None
_orjson_module = None

try:
    import uvloop as _uvloop_module
    UVLOOP_AVAILABLE = True
    UVLOOP_VERSION = getattr(_uvloop_module, '__version__', 'unknown')
    logger.debug(f"uvloop {UVLOOP_VERSION} is available")
except ImportError:
    logger.debug("uvloop not available")

try:
    import winloop as _winloop_module
    WINLOOP_AVAILABLE = True
    WINLOOP_VERSION = getattr(_winloop_module, '__version__', 'unknown')
    logger.debug(f"winloop {WINLOOP_VERSION} is available")
except ImportError:
    logger.debug("winloop not available")

try:
    import ujson as _ujson_module
    UJSON_AVAILABLE = True
    UJSON_VERSION = getattr(_ujson_module, '__version__', 'unknown')
    logger.debug(f"ujson {UJSON_VERSION} is available")
except ImportError:
    logger.debug("ujson not available")

try:
    import orjson as _orjson_module
    ORJSON_AVAILABLE = True
    ORJSON_VERSION = getattr(_orjson_module, '__version__', 'unknown')
    logger.debug(f"orjson {ORJSON_VERSION} is available")
    _ORJSON_BASE_OPTION = 0
    try:
        import numpy
        _ORJSON_BASE_OPTION |= _orjson_module.OPT_SERIALIZE_NUMPY
    except ImportError:
        pass
except ImportError:
    logger.debug("orjson not available")
    _orjson_module = None
    _ORJSON_BASE_OPTION = 0


def get_uvloop_version() -> Optional[str]:
    """获取uvloop版本"""
    return UVLOOP_VERSION


def get_ujson_version() -> Optional[str]:
    """获取ujson版本"""
    return UJSON_VERSION


def get_orjson_version() -> Optional[str]:
    """获取orjson版本"""
    return ORJSON_VERSION


def use_uvloop() -> bool:
    """
    使用uvloop作为事件循环
    
    Returns:
        是否成功启用uvloop
    """
    if not UVLOOP_AVAILABLE:
        logger.debug("uvloop not available, using default asyncio")
        return False
    
    try:
        asyncio.set_event_loop_policy(_uvloop_module.EventLoopPolicy())
        logger.info(f"Using uvloop {UVLOOP_VERSION} for better performance")
        return True
    except Exception as e:
        logger.warning(f"Failed to use uvloop: {e}")
        return False


def use_winloop() -> bool:
    if not WINLOOP_AVAILABLE:
        return False

    try:
        asyncio.set_event_loop_policy(_winloop_module.EventLoopPolicy())
        logger.info(f"Using winloop {WINLOOP_VERSION} for better performance on Windows")
        return True
    except Exception as e:
        logger.warning(f"Failed to install winloop: {e}")
        return False


def auto_select_event_loop() -> bool:
    if sys.platform == 'win32' and WINLOOP_AVAILABLE:
        if use_winloop():
            return True

    if UVLOOP_AVAILABLE:
        if use_uvloop():
            return True

    if WINLOOP_AVAILABLE:
        if use_winloop():
            return True

    logger.debug("Using default asyncio event loop")
    return False


def run_with_uvloop(
    main: Coroutine[Any, Any, T],
    *,
    debug: bool = False,
    loop_factory: Optional[Callable[[], asyncio.AbstractEventLoop]] = None
) -> T:
    """
    使用uvloop运行协程 - uvloop 0.18+ 推荐方式
    
    Args:
        main: 要运行的协程
        debug: 是否启用调试模式
        loop_factory: 自定义事件循环工厂
        
    Returns:
        协程的返回值
        
    使用示例:
        async def main():
            print("Hello, uvloop!")
        
        run_with_uvloop(main())
    """
    if UVLOOP_AVAILABLE:
        if loop_factory is None:
            loop_factory = _uvloop_module.new_event_loop
        return _uvloop_module.run(main, debug=debug, loop_factory=loop_factory)
    else:
        return asyncio.run(main, debug=debug)


def create_uvloop_runner():
    """
    创建uvloop运行器 - Python 3.11+ 的新方式
    
    使用示例:
        runner = create_uvloop_runner()
        runner.run(main())
    """
    if not UVLOOP_AVAILABLE:
        return None
    
    if sys.version_info >= (3, 11):
        return asyncio.Runner(loop_factory=_uvloop_module.new_event_loop)
    
    return None


class JsonWrapper:
    """
    JSON包装器 - 默认使用orjson，ujson为回退，stdlib json为最终保障
    降级链: orjson > ujson > stdlib json
    orjson 是默认JSON库，性能最优，支持 datetime、numpy、dataclass 等
    ujson 是高性能备选
    stdlib json 是最终保障，确保框架始终可用
    """
    
    UJSON_NEW_FEATURES = UJSON_AVAILABLE and UJSON_VERSION and tuple(int(x) for x in UJSON_VERSION.split('.')[:3]) >= (5, 10, 0)
    
    _cached_default = None
    _cached_default_with_nan = None
    _orjson_base_option = _ORJSON_BASE_OPTION
    _orjson_option_default = _ORJSON_BASE_OPTION
    _orjson_option_indent = _ORJSON_BASE_OPTION
    if ORJSON_AVAILABLE:
        _orjson_option_indent = _ORJSON_BASE_OPTION | _orjson_module.OPT_INDENT_2

    @classmethod
    def _get_orjson_option(cls, **kwargs) -> int:
        option = cls._orjson_base_option
        if kwargs.get('indent'):
            option |= _orjson_module.OPT_INDENT_2
        return option

    @classmethod
    def _make_default(cls):
        if cls._cached_default is not None:
            return cls._cached_default
        
        import datetime
        import enum
        import uuid
        import decimal
        
        _PYDANTIC_AVAILABLE = False
        _BaseModel = None
        try:
            from pydantic import BaseModel as _BM
            _PYDANTIC_AVAILABLE = True
            _BaseModel = _BM
        except ImportError:
            pass
        
        def _default(obj):
            if isinstance(obj, datetime.datetime):
                return obj.isoformat()
            if isinstance(obj, datetime.date):
                return obj.isoformat()
            if isinstance(obj, datetime.time):
                return obj.isoformat()
            if isinstance(obj, datetime.timedelta):
                return obj.total_seconds()
            if isinstance(obj, enum.Enum):
                return obj.value
            if isinstance(obj, uuid.UUID):
                return str(obj)
            if isinstance(obj, bytes):
                return obj.decode('utf-8', errors='replace')
            if isinstance(obj, set):
                return list(obj)
            if isinstance(obj, Exception):
                return str(obj)
            if isinstance(obj, decimal.Decimal):
                return float(obj)
            if _PYDANTIC_AVAILABLE and isinstance(obj, _BaseModel):
                return obj.model_dump(mode='json')
            import dataclasses
            if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
                return dataclasses.asdict(obj)
            raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")
        
        cls._cached_default = _default
        return _default

    @classmethod
    def _make_default_with_nan(cls):
        if cls._cached_default_with_nan is not None:
            return cls._cached_default_with_nan
        
        import math
        _base_default = cls._make_default()
        
        def _default_with_nan(obj):
            if isinstance(obj, float):
                if math.isnan(obj):
                    return None
                if math.isinf(obj):
                    return None
            return _base_default(obj)
        
        cls._cached_default_with_nan = _default_with_nan
        return _default_with_nan
    
    @staticmethod
    def _sanitize_nan_inf(obj):
        """递归替换NaN/Infinity为None，确保JSON输出合规(RFC 8259)"""
        import math
        if isinstance(obj, dict):
            return {k: JsonWrapper._sanitize_nan_inf(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [JsonWrapper._sanitize_nan_inf(v) for v in obj]
        if isinstance(obj, float):
            if math.isnan(obj) or math.isinf(obj):
                return None
        return obj
    
    @staticmethod
    def _ujson_filter_kwargs(kwargs):
        filtered = {}
        supported = {'ensure_ascii', 'indent', 'sort_keys', 'escape_forward_slashes',
                     'encode_html_chars', 'reject_bytes', 'default'}
        for k, v in kwargs.items():
            if k in supported and v is not None:
                filtered[k] = v
        return filtered

    @staticmethod
    def dumps(obj, **kwargs) -> str:
        if ORJSON_AVAILABLE:
            obj = JsonWrapper._sanitize_nan_inf(obj)
            if type(obj) in (dict, list):
                try:
                    return _orjson_module.dumps(obj, option=JsonWrapper._orjson_option_default).decode('utf-8')
                except _orjson_module.JSONEncodeError:
                    pass
            option = JsonWrapper._orjson_option_indent if kwargs.get('indent') else JsonWrapper._orjson_option_default
            try:
                result = _orjson_module.dumps(obj, option=option, default=JsonWrapper._make_default_with_nan())
                return result.decode('utf-8')
            except _orjson_module.JSONEncodeError:
                return _orjson_module.dumps(str(obj)).decode('utf-8')
        else:
            if UJSON_AVAILABLE:
                ujson_kwargs = JsonWrapper._ujson_filter_kwargs(kwargs)
                try:
                    return _ujson_module.dumps(obj, **ujson_kwargs)
                except (TypeError, ValueError):
                    return _ujson_module.dumps(str(obj))
            else:
                import json as _stdlib_json
                return _stdlib_json.dumps(obj, **kwargs)
    
    @staticmethod
    def loads(s, **kwargs):
        if ORJSON_AVAILABLE:
            return _orjson_module.loads(s)
        else:
            if UJSON_AVAILABLE:
                return _ujson_module.loads(s, **kwargs)
            else:
                import json as _stdlib_json
                return _stdlib_json.loads(s, **kwargs)
    
    @staticmethod
    def dump(obj, fp, **kwargs):
        if ORJSON_AVAILABLE:
            option = JsonWrapper._orjson_option_indent if kwargs.get('indent') else JsonWrapper._orjson_option_default
            try:
                fp.write(_orjson_module.dumps(obj, option=option, default=JsonWrapper._make_default_with_nan()).decode('utf-8'))
            except _orjson_module.JSONEncodeError:
                fp.write(_orjson_module.dumps(str(obj)).decode('utf-8'))
        else:
            if UJSON_AVAILABLE:
                obj = JsonWrapper._sanitize_nan_inf(obj)
                ujson_kwargs = JsonWrapper._ujson_filter_kwargs(kwargs)
                fp.write(_ujson_module.dumps(obj, **ujson_kwargs))
            else:
                import json as _stdlib_json
                _stdlib_json.dump(obj, fp, **kwargs)
    
    @staticmethod
    def load(fp, **kwargs):
        if ORJSON_AVAILABLE:
            return _orjson_module.loads(fp.read())
        else:
            if UJSON_AVAILABLE:
                return _ujson_module.load(fp, **kwargs)
            else:
                import json as _stdlib_json
                return _stdlib_json.load(fp, **kwargs)
    
    @staticmethod
    def dumpsb(obj, **kwargs) -> bytes:
        return JsonWrapper.encode(obj, **kwargs)
    
    @staticmethod
    def encode(obj, **kwargs) -> bytes:
        if ORJSON_AVAILABLE:
            option = JsonWrapper._orjson_option_indent if kwargs.get('indent') else JsonWrapper._orjson_option_default
            try:
                return _orjson_module.dumps(obj, option=option, default=JsonWrapper._make_default_with_nan())
            except _orjson_module.JSONEncodeError:
                return _orjson_module.dumps(str(obj))
        else:
            if UJSON_AVAILABLE:
                obj = JsonWrapper._sanitize_nan_inf(obj)
                ujson_kwargs = JsonWrapper._ujson_filter_kwargs(kwargs)
                try:
                    return _ujson_module.encode(obj, **ujson_kwargs)
                except TypeError:
                    return _ujson_module.encode(str(obj))
            else:
                import json as _stdlib_json
                return _stdlib_json.dumps(obj, **kwargs).encode('utf-8')
    
    @staticmethod
    def decode(s, **kwargs):
        if ORJSON_AVAILABLE:
            if isinstance(s, bytes):
                return _orjson_module.loads(s)
            return _orjson_module.loads(s)
        else:
            if UJSON_AVAILABLE:
                if isinstance(s, bytes):
                    return _ujson_module.decode(s.decode('utf-8'), **kwargs)
                return _ujson_module.decode(s, **kwargs)
            else:
                import json as _stdlib_json
                if isinstance(s, bytes):
                    s = s.decode('utf-8')
                return _stdlib_json.loads(s, **kwargs)


json = JsonWrapper()


def set_process_title(title: str):
    """
    设置进程标题
    
    Args:
        title: 进程标题
    """
    try:
        import setproctitle
        setproctitle.setproctitle(title)
    except ImportError:
        try:
            import ctypes
            libc = ctypes.CDLL("libc.so.6")
            libc.prctl(15, title.encode('utf-8'), 0, 0, 0)
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)


def get_available_memory() -> Optional[int]:
    """
    获取可用内存（字节）
    
    Returns:
        可用内存字节数，如果无法获取则返回None
    """
    try:
        if sys.platform == 'win32':
            import ctypes
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]
            
            memStatus = MEMORYSTATUSEX()
            memStatus.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memStatus))
            return memStatus.ullAvailPhys
        else:
            try:
                with open('/proc/meminfo', 'r') as f:
                    for line in f:
                        if line.startswith('MemAvailable:'):
                            parts = line.split()
                            if len(parts) >= 2:
                                return int(parts[1]) * 1024
            except (IOError, OSError, ValueError):
                pass
            
            try:
                import psutil
                return psutil.virtual_memory().available
            except ImportError:
                return None
    except Exception:
        return None


def get_cpu_count() -> int:
    """
    获取CPU核心数 - 使用 sched_getaffinity 如果可用
    
    Returns:
        CPU核心数
    """
    try:
        return len(os.sched_getaffinity(0))
    except AttributeError:
        return os.cpu_count() or 1


async def run_in_threadpool(
    func: Callable[..., T],
    *args: Any,
    **kwargs: Any,
) -> T:
    """
    在线程池中运行同步函数 - run_in_threadpool实现
    
    用于在异步路由中调用同步的阻塞IO操作（如文件读写、数据库查询等），
    避免阻塞事件循环。
    
    使用示例:
        async def endpoint(request):
            result = await run_in_threadpool(blocking_function, arg1, arg2)
            return {"result": result}
    
    Args:
        func: 要在线程池中运行的同步函数
        *args: 位置参数
        **kwargs: 关键字参数
        
    Returns:
        函数的返回值
    """
    loop = asyncio.get_running_loop()
    if kwargs:
        func = partial(func, **kwargs)
    return await loop.run_in_executor(None, func, *args)


def sync_to_async(
    func: Callable[..., T],
    *,
    thread_sensitive: bool = False,
) -> Callable[..., Coroutine[Any, Any, T]]:
    """
    将同步函数转换为异步函数 - sync_to_async实现
    
    使用示例:
        @sync_to_async
        def blocking_db_query(user_id):
            return db.query(User).get(user_id)
        
        async def endpoint(request):
            user = await blocking_db_query(123)
    
    Args:
        func: 同步函数
        thread_sensitive: 是否线程敏感
        
    Returns:
        异步包装函数
    """
    @wraps(func)
    async def wrapper(*args: Any, **kwargs: Any) -> T:
        return await run_in_threadpool(func, *args, **kwargs)
    return wrapper


def is_uvloop_active() -> bool:
    """
    检查当前是否正在使用uvloop
    
    Returns:
        是否正在使用uvloop
    """
    if not UVLOOP_AVAILABLE:
        return False
    
    try:
        loop = asyncio.get_running_loop()
        return hasattr(loop, '_libuv')
    except RuntimeError:
        return False


def get_event_loop_type() -> str:
    """
    获取当前事件循环类型
    
    Returns:
        事件循环类型名称
    """
    try:
        loop = asyncio.get_running_loop()
        loop_class = loop.__class__.__name__
        
        if 'uvloop' in loop_class.lower() or hasattr(loop, '_libuv'):
            return 'uvloop'
        elif 'winloop' in loop_class.lower():
            return 'winloop'
        else:
            return 'asyncio'
    except RuntimeError:
        return 'none'


__all__ = [
    'UVLOOP_AVAILABLE',
    'UJSON_AVAILABLE',
    'ORJSON_AVAILABLE',
    'UVLOOP_VERSION',
    'UJSON_VERSION',
    'ORJSON_VERSION',
    'use_uvloop',
    'use_winloop',
    'auto_select_event_loop',
    'run_with_uvloop',
    'create_uvloop_runner',
    'is_uvloop_active',
    'get_event_loop_type',
    'JsonWrapper',
    'json',
    'set_process_title',
    'get_available_memory',
    'get_cpu_count',
    'get_uvloop_version',
    'get_ujson_version',
    'get_orjson_version',
    'run_in_threadpool',
    'sync_to_async',
]
