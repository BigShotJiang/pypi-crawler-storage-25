#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
工具函数包 - Utils Package
提供通用辅助函数和工具类
"""
from kewe.utils.helpers import (
    import_string,
    load_module_from_file_location,
    is_atty,
    has_color_support,
    walk_modules,
    get_root_path,
    get_env_bool,
    get_env_int,
    get_env_list,
    to_camel_case,
    to_snake_case,
    slugify,
    humanize_bytes,
    humanize_duration,
    truncate_string,
    ensure_dir,
    clean_filename,
    merge_dicts,
    flatten_dict,
    unflatten_dict,
    memoize,
    retry,
)
from kewe.utils.distributed_lock import DistributedLock, LockManager
try:
    from kewe.utils.token_encryptor import TokenEncryptor
except ImportError:
    TokenEncryptor = None
from kewe.touchup.performance import ConnectionPoolConfig, ConnectionPool
from kewe.utils.compat import (
    UVLOOP_AVAILABLE, UJSON_AVAILABLE, ORJSON_AVAILABLE,
    UVLOOP_VERSION, UJSON_VERSION, ORJSON_VERSION,
    use_uvloop, use_winloop, auto_select_event_loop,
    run_with_uvloop, create_uvloop_runner,
    is_uvloop_active, get_event_loop_type,
    JsonWrapper, json as compat_json,
    set_process_title, get_available_memory, get_cpu_count,
    get_uvloop_version, get_ujson_version, get_orjson_version,
)
from kewe.utils.i18n import I18nConfig, I18n, setup_i18n
from kewe.utils.testing import (
    TestResponse, WebSocketMessage, TestWebSocket,
    TestClient, AsyncTestClient, TestCase,
    create_test_client, create_async_test_client,
)
from kewe.utils.pagination import (
    PaginationParams, PaginatedResponse, CursorPaginationParams,
    CursorPaginatedResponse, paginate, paginate_cursor,
)

__all__ = [
    'import_string',
    'load_module_from_file_location',
    'is_atty',
    'has_color_support',
    'walk_modules',
    'get_root_path',
    'get_env_bool',
    'get_env_int',
    'get_env_list',
    'to_camel_case',
    'to_snake_case',
    'slugify',
    'humanize_bytes',
    'humanize_duration',
    'truncate_string',
    'ensure_dir',
    'clean_filename',
    'merge_dicts',
    'flatten_dict',
    'unflatten_dict',
    'memoize',
    'retry',
    'DistributedLock',
    'LockManager',
    'TokenEncryptor',
    'ConnectionPoolConfig',
    'ConnectionPool',
    'UVLOOP_AVAILABLE',
    'UJSON_AVAILABLE',
    'ORJSON_AVAILABLE',
    'UVLOOP_VERSION',
    'UJSON_VERSION',
    'ORJSON_VERSION',
    'use_uvloop',
    'use_winloop',
    'auto_select_event_loop',
    'run_with_uvloop',
    'create_uvloop_runner',
    'is_uvloop_active',
    'get_event_loop_type',
    'JsonWrapper',
    'compat_json',
    'set_process_title',
    'get_available_memory',
    'get_cpu_count',
    'get_uvloop_version',
    'get_ujson_version',
    'get_orjson_version',
    'I18nConfig',
    'I18n',
    'setup_i18n',
    'TestResponse',
    'WebSocketMessage',
    'TestWebSocket',
    'TestClient',
    'AsyncTestClient',
    'TestCase',
    'create_test_client',
    'create_async_test_client',
    'PaginationParams',
    'PaginatedResponse',
    'CursorPaginationParams',
    'CursorPaginatedResponse',
    'paginate',
    'paginate_cursor',
]
