#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
范围请求支持 - Range Request Support
支持HTTP Range请求，用于断点续传、视频流等
"""
import re
import os
from typing import Optional, Tuple, List, Dict, Any
from dataclasses import dataclass
from pathlib import Path


@dataclass
class ByteRange:
    """字节范围"""
    start: Optional[int]
    end: Optional[int]
    
    @property
    def is_suffix(self) -> bool:
        """是否是后缀范围（如 -500）"""
        return self.start is None and self.end is not None
    
    def get_length(self, total_size: int) -> int:
        """获取范围长度"""
        start, end = self.get_bounds(total_size)
        return end - start + 1
    
    def get_bounds(self, total_size: int) -> Tuple[int, int]:
        """获取实际边界"""
        if self.is_suffix:
            # 后缀范围：最后N个字节
            start = max(0, total_size - self.end)
            end = total_size - 1
        else:
            start = self.start or 0
            end = self.end if self.end is not None else total_size - 1
            end = min(end, total_size - 1)
        
        return start, end


class RangeHeaderParser:
    """Range请求头解析器"""
    
    # Range: bytes=0-499
    # Range: bytes=500-999
    # Range: bytes=-500 (最后500字节)
    # Range: bytes=500- (从500开始到结束)
    # Range: bytes=0-0,-1 (多范围)
    
    RANGE_REGEX = re.compile(r'bytes=(.+)')
    
    @classmethod
    def parse(cls, range_header: str) -> Optional[List[ByteRange]]:
        """
        解析Range请求头
        
        Args:
            range_header: Range请求头值
            
        Returns:
            ByteRange列表或None
        """
        if not range_header:
            return None
        
        match = cls.RANGE_REGEX.match(range_header)
        if not match:
            return None
        
        ranges_str = match.group(1)
        ranges = []
        
        for range_str in ranges_str.split(','):
            range_str = range_str.strip()
            
            if '-' not in range_str:
                continue
            
            parts = range_str.split('-', 1)
            
            if parts[0] == '':
                # 后缀范围：-500
                try:
                    end = int(parts[1])
                    ranges.append(ByteRange(start=None, end=end))
                except ValueError:
                    continue
            elif parts[1] == '':
                # 从开始到结束：500-
                try:
                    start = int(parts[0])
                    ranges.append(ByteRange(start=start, end=None))
                except ValueError:
                    continue
            else:
                # 正常范围：0-499
                try:
                    start = int(parts[0])
                    end = int(parts[1])
                    ranges.append(ByteRange(start=start, end=end))
                except ValueError:
                    continue
        
        return ranges if ranges else None


class RangeResponseBuilder:
    """范围响应构建器"""
    
    def __init__(self, file_path: str, ranges: List[ByteRange]):
        self.file_path = Path(file_path)
        self.ranges = ranges
        self.file_size = self.file_path.stat().st_size
    
    def is_satisfiable(self) -> bool:
        """检查范围是否可满足"""
        for range_obj in self.ranges:
            if range_obj.is_suffix:
                if range_obj.end <= 0:
                    return False
            else:
                start = range_obj.start or 0
                if start >= self.file_size:
                    return False
        return True
    
    def build_single_range_response(self, range_obj: ByteRange) -> Tuple[bytes, Dict[str, str]]:
        """
        构建单范围响应
        
        Returns:
            (响应体, 响应头)
        """
        start, end = range_obj.get_bounds(self.file_size)
        length = end - start + 1
        
        # 读取文件范围
        with open(self.file_path, 'rb') as f:
            f.seek(start)
            data = f.read(length)
        
        headers = {
            'Content-Type': self._get_content_type(),
            'Content-Length': str(length),
            'Content-Range': f'bytes {start}-{end}/{self.file_size}',
            'Accept-Ranges': 'bytes',
        }
        
        return data, headers
    
    def build_multi_range_response(self, boundary: str = None) -> Tuple[bytes, Dict[str, str]]:
        """
        构建多范围响应
        
        Returns:
            (响应体, 响应头)
        """
        if boundary is None:
            import uuid
            boundary = f"kewe_boundary_{uuid.uuid4().hex[:16]}"
        
        content_type = self._get_content_type()
        parts = []
        
        for range_obj in self.ranges:
            start, end = range_obj.get_bounds(self.file_size)
            length = end - start + 1
            
            # 读取范围数据
            with open(self.file_path, 'rb') as f:
                f.seek(start)
                data = f.read(length)
            
            # 构建部分响应
            part_header = (
                f"--{boundary}\r\n"
                f"Content-Type: {content_type}\r\n"
                f"Content-Range: bytes {start}-{end}/{self.file_size}\r\n"
                f"\r\n"
            ).encode('utf-8')
            
            parts.append(part_header + data + b"\r\n")
        
        # 结束边界
        parts.append(f"--{boundary}--\r\n".encode('utf-8'))
        
        body = b"".join(parts)
        
        headers = {
            'Content-Type': f'multipart/byteranges; boundary={boundary}',
            'Content-Length': str(len(body)),
            'Accept-Ranges': 'bytes',
        }
        
        return body, headers
    
    def _get_content_type(self) -> str:
        """获取文件Content-Type"""
        import mimetypes
        content_type, _ = mimetypes.guess_type(str(self.file_path))
        return content_type or 'application/octet-stream'


def handle_range_request(
    request_headers: Dict[str, str],
    file_path: str,
    default_content_type: str = None
) -> Optional[Tuple[int, bytes, Dict[str, str]]]:
    """
    处理范围请求
    
    Args:
        request_headers: 请求头
        file_path: 文件路径
        default_content_type: 默认Content-Type
        
    Returns:
        (状态码, 响应体, 响应头) 或 None（不是范围请求）
    """
    range_header = request_headers.get('range') or request_headers.get('Range')
    
    if not range_header:
        return None
    
    # 解析范围
    ranges = RangeHeaderParser.parse(range_header)
    if not ranges:
        return 400, b"Invalid Range header", {'Content-Type': 'text/plain'}
    
    # 检查文件
    file_path = Path(file_path)
    if not file_path.exists():
        return 404, b"File not found", {'Content-Type': 'text/plain'}
    
    file_size = file_path.stat().st_size
    
    # 构建响应
    builder = RangeResponseBuilder(str(file_path), ranges)
    
    if not builder.is_satisfiable():
        return (
            416,  # Range Not Satisfiable
            b"Range not satisfiable",
            {
                'Content-Type': 'text/plain',
                'Content-Range': f'bytes */{file_size}'
            }
        )
    
    if len(ranges) == 1:
        body, headers = builder.build_single_range_response(ranges[0])
        return 206, body, headers
    else:
        body, headers = builder.build_multi_range_response()
        return 206, body, headers


# 装饰器支持
def supports_range_request(handler):
    """
    支持范围请求的装饰器
    
    使用示例:
        @app.get("/files/<filename>")
        @supports_range_request
        async def serve_file(request, filename):
            file_path = f"/path/to/files/{filename}"
            return await serve_file_with_range(request, file_path)
    """
    async def wrapper(request, *args, **kwargs):
        response = await handler(request, *args, **kwargs)
        
        # 添加Accept-Ranges头
        if hasattr(response, 'headers'):
            response.headers['Accept-Ranges'] = 'bytes'
        
        return response
    
    return wrapper


async def serve_file_with_range(
    request,
    file_path: str,
    chunk_size: int = 8192
):
    """
    提供支持范围请求的文件服务
    
    Args:
        request: 请求对象
        file_path: 文件路径
        chunk_size: 块大小
        
    Returns:
        Response对象
    """
    from kewe.response import Response
    
    file_path = Path(file_path)
    
    if not file_path.exists():
        from kewe.response import json
        return json({"error": "File not found"}, status=404)
    
    # 检查是否是范围请求
    range_header = request.headers.get('range') or request.headers.get('Range')
    
    if range_header:
        result = handle_range_request(dict(request.headers), str(file_path))
        if result:
            status, body, headers = result
            response = Response(status=status, body=body)
            response.headers.update(headers)
            return response
    
    # 普通响应 - 使用流式传输避免大文件一次性加载
    import mimetypes
    content_type, _ = mimetypes.guess_type(str(file_path))
    file_size = file_path.stat().st_size

    async def _file_generator():
        with open(file_path, 'rb') as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                yield chunk

    response = Response(status=200)
    response._streaming = True
    response._stream_generator = _file_generator()
    response.content_type = content_type or 'application/octet-stream'
    response.headers['Accept-Ranges'] = 'bytes'
    response.headers['Content-Length'] = str(file_size)

    return response


class StreamingFileResponse:
    """
    流式文件响应
    支持大文件流式传输和范围请求
    """
    
    def __init__(self, file_path: str, chunk_size: int = 8192):
        self.file_path = Path(file_path)
        self.chunk_size = chunk_size
        self.range_start = 0
        self.range_end = None
    
    def set_range(self, start: int, end: Optional[int] = None):
        """设置范围"""
        self.range_start = start
        self.range_end = end
    
    async def __call__(self, request):
        """生成响应"""
        from kewe.response import Response
        
        if not self.file_path.exists():
            from kewe.response import json
            return json({"error": "File not found"}, status=404)
        
        file_size = self.file_path.stat().st_size
        
        # 处理范围请求
        range_header = request.headers.get('range') or request.headers.get('Range')
        
        if range_header:
            ranges = RangeHeaderParser.parse(range_header)
            if ranges and len(ranges) == 1:
                start, end = ranges[0].get_bounds(file_size)
                self.set_range(start, end)
        
        # 确定实际范围
        start = self.range_start
        end = self.range_end if self.range_end is not None else file_size - 1
        end = min(end, file_size - 1)
        
        # 生成流式响应
        async def file_generator():
            with open(self.file_path, 'rb') as f:
                f.seek(start)
                remaining = end - start + 1
                
                while remaining > 0:
                    chunk_size = min(self.chunk_size, remaining)
                    data = f.read(chunk_size)
                    if not data:
                        break
                    yield data
                    remaining -= len(data)
        
        import mimetypes
        content_type, _ = mimetypes.guess_type(str(self.file_path))
        
        response = Response(status=206 if range_header else 200)
        response.content_type = content_type or 'application/octet-stream'
        response.headers['Accept-Ranges'] = 'bytes'
        
        if range_header:
            response.headers['Content-Range'] = f'bytes {start}-{end}/{file_size}'
            response.headers['Content-Length'] = str(end - start + 1)
        else:
            response.headers['Content-Length'] = str(file_size)
        
        # 设置流式体
        response._streaming = True
        response._stream_generator = file_generator()
        
        return response
