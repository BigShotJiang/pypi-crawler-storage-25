#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
HTTP协议实现 - HTTP Protocol Implementation

统一HTTP协议层，委托给http_server中的实际实现。
对外保持HttpParser/HttpResponseWriter/KeweHttpProtocol接口兼容。
"""
import asyncio
import logging
from typing import Optional, Dict, Any

from kewe.server.http_server import HttpRequestParser

logger = logging.getLogger(__name__)

try:
    import httptools as _httptools
    HAS_HTTPTOOLS = True
except ImportError:
    _httptools = None
    HAS_HTTPTOOLS = False


class HttpParser(HttpRequestParser):
    """
    HTTP请求解析器 — 统一入口

    委托给HttpRequestParser（http_server.py中的实际实现），
    保持对外接口兼容。新增流式请求体处理能力。
    """

    def __init__(self, max_body_size: int = 100 * 1024 * 1024):
        super().__init__(max_body_size=max_body_size)

    @property
    def complete(self) -> bool:
        return self.is_complete

    @property
    def path(self) -> Optional[str]:
        return self.url

    @path.setter
    def path(self, value: Optional[str]):
        self.url = value

    @property
    def keep_alive(self) -> bool:
        connection = self.headers.get('connection', '').lower()
        version = self.version or '1.1'
        if version == '1.1':
            return connection != 'close'
        return connection == 'keep-alive'

    @property
    def chunked(self) -> bool:
        return self._chunked

    @property
    def content_length(self) -> int:
        return self._content_length

    def feed_data(self, data: bytes) -> bool:
        if not hasattr(self, '_http_parser_instance'):
            if _httptools is not None:
                self._http_parser_instance = _httptools.HttpRequestParser(self)
            else:
                self._http_parser_instance = None

        if self._http_parser_instance is not None:
            try:
                self._http_parser_instance.feed_data(data)
                return self.is_complete
            except Exception as e:
                logger.error(f"HTTP parse error: {e}")
                raise
        return self.is_complete


class HttpResponseWriter:
    """
    HTTP响应写入器

    支持流式响应和chunked编码
    """

    def __init__(self, transport: asyncio.Transport):
        self.transport = transport
        self.headers_sent = False
        self.chunked = False
        self.keep_alive = True

    def write_headers(
        self,
        status: int = 200,
        headers: Optional[Dict[str, str]] = None,
        version: str = "HTTP/1.1",
        keep_alive: bool = True,
    ):
        if self.headers_sent:
            return

        headers = headers or {}
        self.keep_alive = keep_alive

        status_text = self._get_status_text(status)
        header_lines = [f"{version} {status} {status_text}\r\n"]

        if "content-length" not in headers and "transfer-encoding" not in headers:
            headers["transfer-encoding"] = "chunked"
            self.chunked = True

        if "connection" not in headers:
            if self.keep_alive:
                headers["connection"] = "keep-alive"
            else:
                headers["connection"] = "close"

        for key, value in headers.items():
            header_lines.append(f"{key}: {value}\r\n")

        header_lines.append("\r\n")

        self.transport.write("".join(header_lines).encode())
        self.headers_sent = True

    def write(self, data: bytes):
        if not self.headers_sent:
            self.write_headers()

        if self.chunked:
            size_hex = hex(len(data))[2:].encode()
            self.transport.write(size_hex + b"\r\n")
            self.transport.write(data)
            self.transport.write(b"\r\n")
        else:
            self.transport.write(data)

    def write_eof(self):
        if self.chunked:
            self.transport.write(b"0\r\n\r\n")

    def _get_status_text(self, status: int) -> str:
        try:
            from http import HTTPStatus
            return HTTPStatus(status).phrase
        except ValueError:
            return "Unknown"


class KeweHttpProtocol(asyncio.Protocol):
    """
    Kewe HTTP协议处理器

    委托给http_server.RequestHandler实现，
    保持对外接口兼容。
    """

    def __init__(self, app, loop=None, **kwargs):
        from kewe.server.http_server import RequestHandler
        self._handler = RequestHandler(
            app,
            loop=loop,
            request_timeout=kwargs.get("request_timeout", 60.0),
            keep_alive_timeout=kwargs.get("keep_alive_timeout", 5.0),
            request_max_size=kwargs.get("request_max_size", 100 * 1024 * 1024),
            max_connections=kwargs.get("max_connections", 10000),
        )

    def connection_made(self, transport: asyncio.Transport):
        self._handler.connection_made(transport)

    def connection_lost(self, exc: Optional[Exception]):
        self._handler.connection_lost(exc)

    def data_received(self, data: bytes):
        self._handler.data_received(data)


def create_http_server(
    app,
    host: str = "0.0.0.0",
    port: int = 8000,
    **kwargs
) -> asyncio.AbstractServer:
    """
    创建HTTP服务器

    委托给KeweServer实现。
    """
    from kewe.server.http_server import KeweServer

    async def _create():
        server = KeweServer(
            app,
            host=host,
            port=port,
            request_timeout=kwargs.get("request_timeout", 60.0),
            keep_alive_timeout=kwargs.get("keep_alive_timeout", 5.0),
            request_max_size=kwargs.get("request_max_size", 100 * 1024 * 1024),
            backlog=kwargs.get("backlog", 100),
            ssl_context=kwargs.get("ssl_context"),
            max_connections=kwargs.get("max_connections", 10000),
            graceful_shutdown_timeout=kwargs.get("graceful_shutdown_timeout", 30.0),
        )
        await server.start()
        return server

    return _create()


__all__ = [
    'HttpParser',
    'HttpResponseWriter',
    'KeweHttpProtocol',
    'create_http_server',
    'HAS_HTTPTOOLS',
]

