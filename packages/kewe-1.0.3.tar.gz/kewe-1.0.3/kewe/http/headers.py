#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
HTTP头管理 - 大小写不敏感的多值字典
headers.py实现
"""
from typing import Dict, List, Optional, Iterator, Tuple, Union, Any, MutableMapping, Callable
from collections.abc import Mapping
import logging

logger = logging.getLogger(__name__)


class CIMultiDict(MutableMapping):
    """
    大小写不敏感的多值字典
    Case-Insensitive Multi-Value Dictionary
    
    特性:
    - 键名大小写不敏感
    - 支持一个键对应多个值
    - 保持原始键名的大小写（用于输出）
    """
    
    __slots__ = ('_data',)
    
    def __init__(self, *args, **kwargs):
        """
        初始化
        
        支持多种初始化方式:
            Headers()
            Headers({'Content-Type': 'text/html'})
            Headers([('Content-Type', 'text/html')])
            Headers(Content-Type='text/html')
        """
        self._data: Dict[str, List[Tuple[str, str]]] = {}
        # _data结构: {lower_key: [(original_key, value), ...]}
        
        if args:
            if len(args) == 1:
                arg = args[0]
                if isinstance(arg, Mapping):
                    for key, value in arg.items():
                        self.add(key, value)
                elif hasattr(arg, 'items'):
                    for key, value in arg.items():
                        self.add(key, value)
                else:
                    # 假设是可迭代对象
                    for item in arg:
                        if len(item) == 2:
                            self.add(item[0], item[1])
                        else:
                            raise ValueError(f"Invalid header item: {item}")
            else:
                raise TypeError(f"Headers expected at most 1 argument, got {len(args)}")
        
        for key, value in kwargs.items():
            # 将下划线替换为连字符
            header_name = key.replace('_', '-')
            self.add(header_name, value)
    
    def add(self, key: str, value: str):
        """
        添加值（不覆盖，支持多值）
        
        Args:
            key: 键名
            value: 值
        """
        lower_key = key.lower()
        if lower_key not in self._data:
            self._data[lower_key] = []
        self._data[lower_key].append((key, str(value)))
    
    def get(self, key: str, default: Any = None, type: Optional[Callable] = None) -> Any:
        lower_key = key.lower()
        if lower_key in self._data and self._data[lower_key]:
            value = self._data[lower_key][0][1]
            if type is not None:
                try:
                    return type(value)
                except (ValueError, TypeError):
                    return default
            return value
        return default

    def _get_lowered(self, lower_key: str, default: Any = None) -> Optional[str]:
        if lower_key in self._data and self._data[lower_key]:
            return self._data[lower_key][0][1]
        return default
    
    def getall(self, key: str, default: Any = None) -> List[str]:
        """
        获取所有值
        
        Args:
            key: 键名
            default: 默认值
            
        Returns:
            值列表
        """
        lower_key = key.lower()
        if lower_key in self._data:
            return [item[1] for item in self._data[lower_key]]
        return default if default is not None else []
    
    getlist = getall
    
    def getone(self, key: str, default: Any = None) -> Optional[str]:
        """获取单个值（同get）"""
        return self.get(key, default)
    
    def set(self, key: str, value: str):
        """
        设置值（覆盖所有现有值）
        
        Args:
            key: 键名
            value: 值
        """
        lower_key = key.lower()
        self._data[lower_key] = [(key, str(value))]
    
    def __setitem__(self, key: str, value: str):
        """设置值（覆盖）"""
        self.set(key, value)
    
    def __getitem__(self, key: str) -> str:
        """获取值"""
        lower_key = key.lower()
        if lower_key in self._data and self._data[lower_key]:
            return self._data[lower_key][0][1]
        raise KeyError(key)
    
    def __delitem__(self, key: str):
        """删除键"""
        lower_key = key.lower()
        if lower_key in self._data:
            del self._data[lower_key]
        else:
            raise KeyError(key)
    
    def __contains__(self, key: str) -> bool:
        """检查键是否存在"""
        return key.lower() in self._data
    
    def __iter__(self) -> Iterator[str]:
        """迭代键（去重，原始大小写）- 与 keys() 保持一致"""
        seen = set()
        for items in self._data.values():
            for original_key, _ in items:
                lower = original_key.lower()
                if lower not in seen:
                    seen.add(lower)
                    yield original_key
    
    def keys(self):
        """获取所有键（去重，原始大小写）"""
        seen = set()
        for items in self._data.values():
            for original_key, _ in items:
                lower = original_key.lower()
                if lower not in seen:
                    seen.add(lower)
                    yield original_key
    
    def values(self):
        """获取所有值（第一个值）"""
        for items in self._data.values():
            if items:
                yield items[0][1]
    
    def items(self):
        """获取所有键值对（第一个值）"""
        for items in self._data.values():
            if items:
                yield items[0][0], items[0][1]
    
    def __len__(self) -> int:
        """获取键的数量"""
        return len(self._data)
    
    def __repr__(self) -> str:
        """字符串表示"""
        items = []
        for key, value in self.items():
            items.append(f"{key!r}: {value!r}")
        return f"Headers({{'{', '.join(items)}}})"
    
    def __str__(self) -> str:
        """字符串表示"""
        lines = []
        for key, value in self.items():
            lines.append(f"{key}: {value}")
        return '\n'.join(lines)
    
    def copy(self) -> 'CIMultiDict':
        """复制"""
        new_headers = CIMultiDict()
        for items in self._data.values():
            for original_key, value in items:
                new_headers.add(original_key, value)
        return new_headers
    
    def extend(self, *args, **kwargs):
        """
        扩展
        
        支持:
            headers.extend({'X-Custom': 'value'})
            headers.extend([('X-Custom', 'value')])
            headers.extend(X_Custom='value')
        """
        if args:
            if len(args) == 1:
                arg = args[0]
                if isinstance(arg, Mapping):
                    for key, value in arg.items():
                        self.add(key, value)
                else:
                    for item in arg:
                        if len(item) == 2:
                            self.add(item[0], item[1])
        
        for key, value in kwargs.items():
            header_name = key.replace('_', '-')
            self.add(header_name, value)
    
    def pop(self, key: str, default: Any = None):
        """弹出键"""
        lower_key = key.lower()
        if lower_key in self._data:
            items = self._data.pop(lower_key)
            if items:
                return items[0][1]
        if default is not None:
            return default
        raise KeyError(key)
    
    def popall(self, key: str, default: Any = None) -> List[str]:
        """弹出所有值"""
        lower_key = key.lower()
        if lower_key in self._data:
            items = self._data.pop(lower_key)
            return [item[1] for item in items]
        return default if default is not None else []
    
    def popone(self, key: str, default: Any = None):
        """弹出一个值"""
        return self.pop(key, default)
    
    def clear(self):
        """清空"""
        self._data.clear()
    
    def update(self, *args, **kwargs):
        """更新（覆盖模式）"""
        if args:
            if len(args) == 1:
                arg = args[0]
                if isinstance(arg, Mapping):
                    for key, value in arg.items():
                        self.set(key, value)
                else:
                    for item in arg:
                        if len(item) == 2:
                            self.set(item[0], item[1])
        
        for key, value in kwargs.items():
            header_name = key.replace('_', '-')
            self.set(header_name, value)


class Headers(CIMultiDict):
    """
    HTTP头专用类
    继承CIMultiDict，提供HTTP头特定的功能
    """
    
    # 常用HTTP头名称（标准化大小写）
    STANDARD_HEADERS = {
        'accept': 'Accept',
        'accept-charset': 'Accept-Charset',
        'accept-encoding': 'Accept-Encoding',
        'accept-language': 'Accept-Language',
        'accept-ranges': 'Accept-Ranges',
        'age': 'Age',
        'allow': 'Allow',
        'authorization': 'Authorization',
        'cache-control': 'Cache-Control',
        'connection': 'Connection',
        'content-disposition': 'Content-Disposition',
        'content-encoding': 'Content-Encoding',
        'content-language': 'Content-Language',
        'content-length': 'Content-Length',
        'content-location': 'Content-Location',
        'content-range': 'Content-Range',
        'content-type': 'Content-Type',
        'cookie': 'Cookie',
        'date': 'Date',
        'etag': 'ETag',
        'expect': 'Expect',
        'expires': 'Expires',
        'from': 'From',
        'host': 'Host',
        'if-match': 'If-Match',
        'if-modified-since': 'If-Modified-Since',
        'if-none-match': 'If-None-Match',
        'if-range': 'If-Range',
        'if-unmodified-since': 'If-Unmodified-Since',
        'last-modified': 'Last-Modified',
        'location': 'Location',
        'max-forwards': 'Max-Forwards',
        'pragma': 'Pragma',
        'proxy-authenticate': 'Proxy-Authenticate',
        'proxy-authorization': 'Proxy-Authorization',
        'range': 'Range',
        'referer': 'Referer',
        'retry-after': 'Retry-After',
        'server': 'Server',
        'set-cookie': 'Set-Cookie',
        'te': 'TE',
        'trailer': 'Trailer',
        'transfer-encoding': 'Transfer-Encoding',
        'upgrade': 'Upgrade',
        'user-agent': 'User-Agent',
        'vary': 'Vary',
        'via': 'Via',
        'warning': 'Warning',
        'www-authenticate': 'WWW-Authenticate',
        'x-request-id': 'X-Request-ID',
        'x-forwarded-for': 'X-Forwarded-For',
        'x-forwarded-host': 'X-Forwarded-Host',
        'x-forwarded-proto': 'X-Forwarded-Proto',
        'x-real-ip': 'X-Real-IP',
    }
    
    def add(self, key: str, value: str):
        """
        添加值，使用标准化键名
        """
        # 标准化键名大小写
        lower_key = key.lower()
        standard_key = self.STANDARD_HEADERS.get(lower_key, key)
        super().add(standard_key, value)
    
    def set(self, key: str, value: str):
        """
        设置值，使用标准化键名
        """
        lower_key = key.lower()
        standard_key = self.STANDARD_HEADERS.get(lower_key, key)
        super().set(standard_key, value)
    
    def get_content_type(self) -> Optional[str]:
        """获取Content-Type"""
        return self.get('content-type')
    
    def get_content_length(self) -> Optional[int]:
        """获取Content-Length"""
        value = self.get('content-length')
        if value:
            try:
                return int(value)
            except ValueError:
                pass
        return None
    
    def is_chunked(self) -> bool:
        """检查是否为分块传输"""
        transfer_encoding = self.get('transfer-encoding', '').lower()
        return 'chunked' in transfer_encoding
    
    def is_keep_alive(self) -> bool:
        """检查是否保持连接"""
        connection = self.get('connection', '').lower()
        return connection != 'close'
    
    def is_upgrade(self) -> bool:
        """检查是否为升级请求"""
        connection = self.get('connection', '').lower()
        return 'upgrade' in connection
    
    def get_encoding(self) -> str:
        """获取编码"""
        content_type = self.get('content-type', '')
        if 'charset=' in content_type:
            parts = content_type.split('charset=')
            if len(parts) > 1:
                encoding = parts[1].split(';')[0].strip()
                return encoding.strip('"\'')
        return 'utf-8'
    
    def raw_items(self) -> List[Tuple[str, str]]:
        """
        获取所有原始键值对（包括重复键）
        
        Returns:
            键值对列表
        """
        items = []
        for header_items in self._data.values():
            for original_key, value in header_items:
                items.append((original_key, value))
        return items
    
    def encode(self) -> bytes:
        """
        编码为HTTP头字节流
        
        Returns:
            HTTP头字节
        """
        lines = []
        for key, value in self.raw_items():
            lines.append(f"{key}: {value}\r\n")
        return ''.join(lines).encode('utf-8')
    
    @classmethod
    def decode(cls, data: bytes) -> 'Headers':
        """
        从字节流解码HTTP头
        
        Args:
            data: HTTP头字节
            
        Returns:
            Headers对象
        """
        headers = cls()
        text = data.decode('utf-8', errors='surrogateescape')
        for line in text.split('\r\n'):
            if ':' in line:
                key, value = line.split(':', 1)
                headers.add(key.strip(), value.strip())
        return headers


# 便捷函数
def parse_headers(headers_data: Union[Dict, List, bytes, str]) -> Headers:
    """
    解析HTTP头数据
    
    Args:
        headers_data: 头数据
        
    Returns:
        Headers对象
    """
    if isinstance(headers_data, Headers):
        return headers_data
    
    if isinstance(headers_data, bytes):
        return Headers.decode(headers_data)
    
    if isinstance(headers_data, str):
        return Headers.decode(headers_data.encode('utf-8'))
    
    return Headers(headers_data)
