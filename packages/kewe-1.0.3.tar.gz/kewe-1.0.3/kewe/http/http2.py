#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
HTTP/2协议支持 - HTTP/2 Protocol Support
基于h2库实现生产级HTTP/2支持

功能：
- 完整的HTTP/2连接管理
- PING/PONG保活机制
- 流优先级处理
- 完善的GOAWAY优雅关闭
- SETTINGS帧协商
- 流量控制优化
- 服务器推送
- 连接预检验证
"""
import asyncio
import logging
import time
from typing import Dict, Optional, Any, Callable, Set

logger = logging.getLogger(__name__)

try:
    import h2
    import h2.connection
    import h2.events
    import h2.config
    import h2.errors
    import h2.exceptions
    import h2.settings
    H2_AVAILABLE = True
except ImportError:
    H2_AVAILABLE = False
    logger.info("h2 package not installed, HTTP/2 support disabled. Install with: pip install h2")

STREAM_CLEANUP_DELAY = 30
PING_INTERVAL = 30.0
DEFAULT_MAX_CONCURRENT_STREAMS = 128
DEFAULT_INITIAL_WINDOW_SIZE = 65535
DEFAULT_MAX_FRAME_SIZE = 16384
DEFAULT_HEADER_TABLE_SIZE = 4096


class HTTP2Settings:
    """HTTP/2设置管理"""

    def __init__(
        self,
        max_concurrent_streams: int = DEFAULT_MAX_CONCURRENT_STREAMS,
        initial_window_size: int = DEFAULT_INITIAL_WINDOW_SIZE,
        max_frame_size: int = DEFAULT_MAX_FRAME_SIZE,
        header_table_size: int = DEFAULT_HEADER_TABLE_SIZE,
        enable_push: bool = True,
        max_header_list_size: Optional[int] = None,
    ):
        self.max_concurrent_streams = max_concurrent_streams
        self.initial_window_size = initial_window_size
        self.max_frame_size = max_frame_size
        self.header_table_size = header_table_size
        self.enable_push = enable_push
        self.max_header_list_size = max_header_list_size

    def apply_to_connection(self, conn: 'h2.connection.H2Connection'):
        if not H2_AVAILABLE:
            return
        try:
            conn.local_settings = h2.settings.Settings(
                client_side=False,
                max_concurrent_streams=self.max_concurrent_streams,
                initial_window_size=self.initial_window_size,
                max_frame_size=self.max_frame_size,
                header_table_size=self.header_table_size,
                enable_push=1 if self.enable_push else 0,
            )
            if self.max_header_list_size is not None:
                conn.local_settings.max_header_list_size = self.max_header_list_size
        except Exception as e:
            logger.warning(f"Failed to apply HTTP/2 settings: {e}")


class HTTP2Connection:
    """HTTP/2连接管理 - 生产级实现"""

    def __init__(
        self,
        transport,
        protocol: 'HTTP2Protocol',
        settings: Optional[HTTP2Settings] = None,
    ):
        if not H2_AVAILABLE:
            raise ImportError(
                "HTTP/2 support requires 'h2' package. "
                "Install with: pip install h2"
            )

        self.transport = transport
        self.protocol = protocol
        self.settings = settings or HTTP2Settings()

        config = h2.config.H2Configuration(
            client_side=False,
            header_encoding='utf-8',
            validate_outbound_headers=False,
            validate_inbound_headers=True,
            logger=logger.debug if logger.isEnabledFor(logging.DEBUG) else None,
        )
        self.conn = h2.connection.H2Connection(config=config)

        self.settings.apply_to_connection(self.conn)
        self.conn.initiate_connection()

        self.streams: Dict[int, 'HTTP2Stream'] = {}
        self._flow_control_futures: Dict[int, asyncio.Future] = {}
        self._active_tasks: Set[asyncio.Task] = set()
        self._closed_streams: Dict[int, float] = {}
        self._graceful_shutdown = False
        self._last_ping_time: float = 0.0
        self._ping_data: Optional[bytes] = None
        self._connection_start_time: float = time.monotonic()
        self._total_streams_processed: int = 0
        self._last_activity_time: float = time.monotonic()

        self.transport.write(self.conn.data_to_send())

    @property
    def is_going_away(self) -> bool:
        return self._graceful_shutdown

    @property
    def active_stream_count(self) -> int:
        return sum(1 for s in self.streams.values() if not s._stream_ended and not s._reset)

    def _update_activity(self):
        self._last_activity_time = time.monotonic()

    def receive_data(self, data: bytes):
        try:
            events = self.conn.receive_data(data)
            for event in events:
                self._handle_event(event)
        except Exception as e:
            error_name = type(e).__name__
            if 'ProtocolError' in error_name:
                logger.error(f"HTTP/2 protocol error: {e}")
                self._send_goaway(1, str(e))
            elif 'FlowControlError' in error_name:
                logger.error(f"HTTP/2 flow control error: {e}")
                self._send_goaway(3, str(e))
            else:
                logger.error(f"HTTP/2 error: {e}")
                self._send_goaway(2, str(e))

    def _handle_event(self, event):
        self._update_activity()

        event_type = type(event).__name__

        if event_type == 'RequestReceived':
            self._handle_request(event)
        elif event_type == 'DataReceived':
            self._handle_data(event)
        elif event_type == 'StreamEnded':
            self._handle_stream_end(event)
        elif event_type == 'WindowUpdated':
            self._handle_window_update(event)
        elif event_type == 'StreamReset':
            self._handle_stream_reset(event)
        elif event_type == 'ConnectionTerminated':
            self._handle_connection_terminated(event)
        elif event_type == 'PingReceived':
            self._handle_ping_received(event)
        elif event_type == 'RemoteSettingsChanged':
            self._handle_settings_changed(event)
        elif event_type == 'PriorityUpdated':
            self._handle_priority_updated(event)
        elif event_type == 'PushedStreamReceived':
            self._handle_pushed_stream(event)
        elif event_type == 'SettingsAcknowledged':
            logger.debug("HTTP/2 settings acknowledged by peer")
        elif event_type == 'TrailHeadersReceived':
            self._handle_trail_headers(event)

        data_to_send = self.conn.data_to_send()
        if data_to_send:
            self.transport.write(data_to_send)

    def _handle_request(self, event):
        stream_id = event.stream_id

        if self._graceful_shutdown:
            self.conn.reset_stream(stream_id, error_code=7)
            return

        if self.active_stream_count >= self.settings.max_concurrent_streams:
            self.conn.reset_stream(stream_id, error_code=7)
            logger.warning(f"Rejected stream {stream_id}: max concurrent streams reached")
            return

        headers = dict(event.headers)

        stream = HTTP2Stream(
            stream_id=stream_id,
            connection=self,
            headers=headers,
            weight=event.priority_weight if hasattr(event, 'priority_weight') else 16,
            depends_on=event.priority_depends_on if hasattr(event, 'priority_depends_on') else 0,
            exclusive=event.priority_exclusive if hasattr(event, 'priority_exclusive') else False,
        )
        self.streams[stream_id] = stream

        task = asyncio.create_task(self._process_request(stream))
        self._active_tasks.add(task)
        task.add_done_callback(self._active_tasks.discard)

    async def _process_request(self, stream):
        try:
            from kewe.request.request import Request
            from urllib.parse import urlparse, parse_qs

            method = stream.headers.get(':method', 'GET')
            path = stream.headers.get(':path', '/')
            headers = {k: v for k, v in stream.headers.items() if not k.startswith(':')}

            parsed_url = urlparse(path)
            path = parsed_url.path
            query_params = parse_qs(parsed_url.query)

            client_ip = '127.0.0.1'
            if self.transport:
                extra_info = self.transport.get_extra_info('peername')
                if extra_info:
                    client_ip = extra_info[0]

            request = Request(
                method=method,
                path=path,
                headers=headers,
                query_params=query_params,
                query_string=parsed_url.query,
                body=b'',
                client_ip=client_ip,
                protocol='HTTP/2',
                app=self.protocol.app if hasattr(self.protocol, 'app') else None,
            )

            if stream.has_body:
                body = await stream.get_body()
                request._full_body = body

            response = await self.protocol.app.handle_request(request)
            await stream.send_response(response)

        except Exception as e:
            if 'StreamClosedError' in type(e).__name__:
                logger.debug(f"Stream {stream.stream_id} was closed by client")
            else:
                logger.error(f"Error processing HTTP/2 request: {e}")
                try:
                    await stream.send_error(500)
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)
        finally:
            self._total_streams_processed += 1
            self._closed_streams[stream.stream_id] = time.monotonic()
            asyncio.get_running_loop().call_later(
                STREAM_CLEANUP_DELAY,
                self._cleanup_stream,
                stream.stream_id
            )

    def _cleanup_stream(self, stream_id: int):
        if stream_id in self._closed_streams:
            del self._closed_streams[stream_id]
        if stream_id in self.streams:
            del self.streams[stream_id]

    def _handle_data(self, event):
        stream_id = event.stream_id
        if stream_id in self.streams:
            stream = self.streams[stream_id]
            stream.receive_data(event.data)
            self.conn.acknowledge_received_data(event.flow_controlled_length, stream_id)

    def _handle_stream_end(self, event):
        stream_id = event.stream_id
        if stream_id in self.streams:
            self.streams[stream_id].end_stream()

    def _handle_window_update(self, event):
        stream_id = event.stream_id
        if stream_id in self._flow_control_futures:
            future = self._flow_control_futures.pop(stream_id)
            if not future.done():
                future.set_result(None)
        elif stream_id == 0:
            for sid, future in list(self._flow_control_futures.items()):
                if not future.done():
                    future.set_result(None)

    def _handle_stream_reset(self, event):
        stream_id = event.stream_id
        error_code = event.error_code
        logger.debug(f"Stream {stream_id} reset with error code {error_code}")

        if stream_id in self.streams:
            self.streams[stream_id].reset()
            del self.streams[stream_id]
        if stream_id in self._flow_control_futures:
            future = self._flow_control_futures.pop(stream_id)
            if not future.done():
                future.cancel()

    def _handle_connection_terminated(self, event):
        error_code = event.error_code
        last_stream_id = event.last_stream_id
        additional_data = event.additional_data
        logger.info(
            f"HTTP/2 connection terminated: error_code={error_code}, "
            f"last_stream_id={last_stream_id}, "
            f"additional_data={additional_data}"
        )
        self.close()

    def _handle_ping_received(self, event):
        ping_data = event.ping_data
        self.conn.ping(ping_data)
        self._last_ping_time = time.monotonic()
        logger.debug(f"HTTP/2 PING received, sent PONG")

    def _handle_settings_changed(self, event):
        changed_settings = event.changed_settings
        for setting_id, setting_value in changed_settings.items():
            logger.debug(f"HTTP/2 remote setting changed: {setting_id}={setting_value.new_value}")

    def _handle_priority_updated(self, event):
        stream_id = event.stream_id
        weight = event.weight
        depends_on = event.depends_on
        exclusive = event.exclusive
        if stream_id in self.streams:
            stream = self.streams[stream_id]
            stream.weight = weight
            stream.depends_on = depends_on
            stream.exclusive = exclusive
        logger.debug(f"Stream {stream_id} priority updated: weight={weight}, depends_on={depends_on}")

    def _handle_pushed_stream(self, event):
        pushed_stream_id = event.pushed_stream_id
        parent_stream_id = event.stream_id
        logger.debug(
            f"HTTP/2 pushed stream {pushed_stream_id} received from parent stream {parent_stream_id}"
        )

    def _handle_trail_headers(self, event):
        stream_id = event.stream_id
        if stream_id in self.streams:
            stream = self.streams[stream_id]
            for name, value in event.headers:
                stream.trailers[name] = value

    def send_ping(self):
        if not H2_AVAILABLE:
            return
        try:
            import os
            ping_data = os.urandom(8)
            self.conn.ping(ping_data)
            self._ping_data = ping_data
            self._last_ping_time = time.monotonic()
            data = self.conn.data_to_send()
            if data:
                self.transport.write(data)
        except Exception as e:
            logger.warning(f"Failed to send PING: {e}")

    def _send_goaway(self, error_code: int = 0, reason: str = ""):
        if not H2_AVAILABLE:
            return
        try:
            max_stream_id = max(self.streams.keys()) if self.streams else 0
            additional_data = reason.encode('utf-8') if reason else None
            self.conn.close_connection(
                error_code=error_code,
                last_stream_id=max_stream_id,
                additional_data=additional_data,
            )
            data = self.conn.data_to_send()
            if data:
                self.transport.write(data)
        except Exception as e:
            logger.error(f"Error sending GOAWAY: {e}")

    def graceful_shutdown(self):
        self._graceful_shutdown = True
        self._send_goaway(0, "graceful_shutdown")

    def close(self):
        try:
            if not self._graceful_shutdown:
                self._send_goaway(0, "connection_close")
        except Exception as e:
            logger.error(f"Error closing HTTP/2 connection: {e}")
        finally:
            for stream in self.streams.values():
                if not stream._stream_ended and not stream._reset:
                    stream.reset()
            self.streams.clear()
            for sid, future in self._flow_control_futures.items():
                if not future.done():
                    future.cancel()
            self._flow_control_futures.clear()
            if self.transport and not self.transport.is_closing():
                self.transport.close()

    @property
    def stats(self) -> Dict[str, Any]:
        return {
            'total_streams_processed': self._total_streams_processed,
            'active_streams': self.active_stream_count,
            'closed_streams_pending_cleanup': len(self._closed_streams),
            'connection_uptime': time.monotonic() - self._connection_start_time,
            'last_activity_ago': time.monotonic() - self._last_activity_time,
            'graceful_shutdown': self._graceful_shutdown,
        }


class HTTP2Stream:
    """HTTP/2流 - 支持优先级和尾部头"""

    def __init__(
        self,
        stream_id: int,
        connection: HTTP2Connection,
        headers: Dict[str, str],
        weight: int = 16,
        depends_on: int = 0,
        exclusive: bool = False,
    ):
        self.stream_id = stream_id
        self.connection = connection
        self.headers = headers
        self.weight = weight
        self.depends_on = depends_on
        self.exclusive = exclusive
        self.has_body = headers.get(':method') in ['POST', 'PUT', 'PATCH']
        self.trailers: Dict[str, str] = {}

        self._body_buffer = bytearray()
        self._body_event = asyncio.Event()
        self._stream_ended = False
        self._reset = False

    def receive_data(self, data: bytes):
        self._body_buffer.extend(data)

    def end_stream(self):
        self._stream_ended = True
        self._body_event.set()

    def reset(self):
        self._reset = True
        self._body_event.set()

    async def get_body(self, timeout: float = 60.0) -> bytes:
        if not self.has_body:
            return b''

        try:
            await asyncio.wait_for(self._body_event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            raise asyncio.TimeoutError(f"Timeout waiting for stream {self.stream_id} body")

        if self._reset:
            raise Exception(f"Stream {self.stream_id} was reset")

        return bytes(self._body_buffer)

    async def _wait_for_flow_control(self):
        max_size = self.connection.conn.local_flow_control_window(self.stream_id)
        if max_size > 0:
            return min(max_size, self.connection.conn.max_outbound_frame_size)

        future = asyncio.get_running_loop().create_future()
        self.connection._flow_control_futures[self.stream_id] = future
        try:
            await asyncio.wait_for(future, timeout=30.0)
        except asyncio.TimeoutError:
            pass
        return min(
            self.connection.conn.local_flow_control_window(self.stream_id),
            self.connection.conn.max_outbound_frame_size,
        )

    async def send_response(self, response):
        conn = self.connection.conn

        response_headers = [
            (':status', str(response.status)),
            ('content-type', getattr(response, 'content_type', 'application/json')),
        ]

        for name, value in response.headers.items():
            if name.lower() not in ['content-type', 'content-length', 'transfer-encoding', ':status']:
                response_headers.append((name.lower(), str(value)))

        conn.send_headers(self.stream_id, response_headers)
        self.connection.transport.write(conn.data_to_send())

        if hasattr(response, '_stream_generator') and response._streaming:
            async for chunk in response._stream_generator:
                if isinstance(chunk, str):
                    chunk = chunk.encode('utf-8')
                while chunk:
                    max_size = await self._wait_for_flow_control()
                    if not max_size or max_size <= 0:
                        continue
                    data_to_send = chunk[:max_size]
                    chunk = chunk[max_size:]
                    conn.send_data(self.stream_id, data_to_send, end_stream=False)
                    self.connection.transport.write(conn.data_to_send())
                    await asyncio.sleep(0)
            conn.send_data(self.stream_id, b'', end_stream=True)
            self.connection.transport.write(conn.data_to_send())
        else:
            body = response.body if response.body else b''
            if isinstance(body, str):
                body = body.encode('utf-8')
            while body:
                max_size = await self._wait_for_flow_control()
                if not max_size or max_size <= 0:
                    continue
                data_to_send = body[:max_size]
                body = body[max_size:]
                end = len(body) == 0
                conn.send_data(self.stream_id, data_to_send, end_stream=end)
                self.connection.transport.write(conn.data_to_send())

    async def send_push(self, path: str, response):
        try:
            conn = self.connection.conn
            remote_settings = conn.remote_settings
            if hasattr(remote_settings, 'enable_push') and not remote_settings.enable_push:
                logger.debug("HTTP/2 push disabled by client")
                return

            push_stream_id = conn.get_next_available_stream_id()
            conn.push_stream(self.stream_id, push_stream_id, [
                (':method', 'GET'),
                (':path', path),
                (':scheme', 'https'),
                (':authority', self.headers.get(':authority', 'localhost')),
            ])
            self.connection.transport.write(conn.data_to_send())

            push_headers = [
                (':status', str(response.status)),
                ('content-type', getattr(response, 'content_type', 'application/octet-stream')),
            ]
            conn.send_headers(push_stream_id, push_headers)
            self.connection.transport.write(conn.data_to_send())

            body = response.body if response.body else b''
            if isinstance(body, str):
                body = body.encode('utf-8')

            max_frame = conn.max_outbound_frame_size
            while body:
                chunk = body[:max_frame]
                body = body[max_frame:]
                end = len(body) == 0
                conn.send_data(push_stream_id, chunk, end_stream=end)
                self.connection.transport.write(conn.data_to_send())
        except Exception as e:
            if 'ProtocolError' in type(e).__name__:
                logger.warning(f"HTTP/2 push failed (protocol error): {e}")
            else:
                logger.warning(f"HTTP/2 push failed: {e}")

    async def send_error(self, status: int):
        conn = self.connection.conn
        response_headers = [(':status', str(status)), ('content-type', 'text/plain')]
        try:
            conn.send_headers(self.stream_id, response_headers, end_stream=True)
            self.connection.transport.write(conn.data_to_send())
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)


class HTTP2Protocol(asyncio.Protocol):
    """HTTP/2协议处理器"""

    def __init__(self, app, settings: Optional[HTTP2Settings] = None):
        self.app = app
        self.settings = settings or HTTP2Settings()
        self.transport: Optional[asyncio.Transport] = None
        self.connection: Optional[HTTP2Connection] = None

    def connection_made(self, transport: asyncio.Transport):
        self.transport = transport
        try:
            self.connection = HTTP2Connection(transport, self, settings=self.settings)
            logger.debug("HTTP/2 connection established")
        except Exception as e:
            logger.error(f"Failed to create HTTP/2 connection: {e}")
            transport.close()

    def data_received(self, data: bytes):
        if self.connection:
            self.connection.receive_data(data)

    def connection_lost(self, exc):
        if self.connection:
            self.connection.close()
        logger.debug("HTTP/2 connection lost")


def create_http2_server(
    app,
    host: str = "0.0.0.0",
    port: int = 8000,
    ssl_context=None,
    settings: Optional[HTTP2Settings] = None,
):
    """创建HTTP/2服务器"""
    if not H2_AVAILABLE:
        raise ImportError(
            "HTTP/2 support requires 'h2' package. "
            "Install with: pip install h2"
        )

    loop = asyncio.get_running_loop()
    http2_settings = settings or HTTP2Settings()

    def protocol_factory():
        return HTTP2Protocol(app, settings=http2_settings)

    return loop.create_server(protocol_factory, host=host, port=port, ssl=ssl_context)


def is_http2_available() -> bool:
    """检查HTTP/2是否可用"""
    return H2_AVAILABLE


class HTTP2ConnectionPool:
    """HTTP/2连接池 - 复用连接提升性能，按host:port分锁减少竞争"""

    def __init__(self, max_connections: int = 100, idle_timeout: float = 30.0):
        self._max_connections = max_connections
        self._idle_timeout = idle_timeout
        self._pool: Dict[str, list] = {}
        self._locks: Dict[str, asyncio.Lock] = {}
        self._total_created = 0
        self._total_reused = 0
        self._active_count: Dict[str, int] = {}

    def _get_lock(self, key: str) -> asyncio.Lock:
        if key not in self._locks:
            self._locks[key] = asyncio.Lock()
        return self._locks[key]

    async def acquire(self, host: str, port: int, ssl_context=None, settings: Optional[HTTP2Settings] = None):
        key = f"{host}:{port}"
        lock = self._get_lock(key)
        async with lock:
            if key in self._pool:
                while self._pool[key]:
                    conn, created_at = self._pool[key].pop()
                    if time.monotonic() - created_at < self._idle_timeout:
                        if hasattr(conn, 'transport') and not conn.transport.is_closing():
                            self._total_reused += 1
                            self._active_count[key] = self._active_count.get(key, 0) + 1
                            return conn
                if not self._pool[key]:
                    del self._pool[key]
            total_active = self._active_count.get(key, 0)
            if total_active >= self._max_connections:
                return None
            self._total_created += 1
            self._active_count[key] = total_active + 1
            try:
                conn = await self._create_connection(host, port, ssl_context=ssl_context, settings=settings)
                return conn
            except Exception:
                self._active_count[key] = max(0, self._active_count.get(key, 1) - 1)
                raise

    async def release(self, host: str, port: int, connection):
        key = f"{host}:{port}"
        lock = self._get_lock(key)
        async with lock:
            self._active_count[key] = max(0, self._active_count.get(key, 1) - 1)
            if key not in self._pool:
                self._pool[key] = []
            if len(self._pool[key]) < self._max_connections:
                if hasattr(connection, 'transport') and not connection.transport.is_closing():
                    self._pool[key].append((connection, time.monotonic()))
                else:
                    try:
                        connection.close()
                    except Exception:
                        logger.debug("Non-critical operation failed", exc_info=True)
            else:
                try:
                    connection.close()
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)

    async def close_all(self):
        for key, lock in self._locks.items():
            async with lock:
                if key in self._pool:
                    for conn, _ in self._pool[key]:
                        try:
                            conn.close()
                        except Exception:
                            logger.debug("Non-critical operation failed", exc_info=True)
                    del self._pool[key]
        self._locks.clear()
        self._active_count.clear()

    @property
    def stats(self) -> Dict[str, Any]:
        total_idle = sum(len(v) for v in self._pool.values())
        total_active = sum(self._active_count.values())
        return {
            'total_created': self._total_created,
            'total_reused': self._total_reused,
            'idle_connections': total_idle,
            'active_connections': total_active,
            'hosts': len(self._pool),
        }


def negotiate_alpn(ssl_context) -> Optional[str]:
    """ALPN协议协商 - 在TLS握手时协商HTTP/2"""
    if not H2_AVAILABLE:
        return None
    try:
        ssl_context.set_alpn_protocols(['h2', 'http/1.1'])

        def _alpn_select_callback(client_protocols):
            for proto in client_protocols:
                if proto == b'h2':
                    return b'h2'
            if b'http/1.1' in client_protocols:
                return b'http/1.1'
            return b'http/1.1'

        ssl_context.set_alpn_select_callback(_alpn_select_callback)
        return 'h2'
    except Exception:
        return None


__all__ = [
    'HTTP2Connection',
    'HTTP2Stream',
    'HTTP2Protocol',
    'HTTP2Settings',
    'HTTP2ConnectionPool',
    'create_http2_server',
    'is_http2_available',
    'negotiate_alpn',
]
