#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
进程间通信多路复用器 - Multiplexer
multiplexer.py实现

提供Worker进程间的通信和管理功能
"""
import os
import multiprocessing
import logging
from datetime import datetime
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass
from enum import Enum, auto

from kewe.worker import WorkerState
from kewe.worker.custom import WorkerInfo

logger = logging.getLogger(__name__)


class Multiplexer:
    """
    多路复用器
    
    管理多个Worker进程，提供进程间通信功能
    
    使用示例:
        multiplexer = Multiplexer()
        multiplexer.start_workers(target_func, num_workers=4)
        
        # 获取Worker状态
        status = multiplexer.get_worker_status()
        
        # 重启所有Worker
        multiplexer.restart_all()
    """
    
    def __init__(self):
        self.workers: Dict[int, WorkerInfo] = {}
        self._processes: Dict[int, multiprocessing.Process] = {}
        self._shutdown = False
        self._monitor_callback: Optional[Callable] = None
        self._worker_configs: Dict[int, Dict[str, Any]] = {}
        
    def start_workers(
        self,
        target: Callable,
        num_workers: int = 1,
        args: tuple = (),
        kwargs: dict = None
    ):
        """
        启动多个Worker进程
        
        Args:
            target: Worker进程执行的函数
            num_workers: Worker数量
            args: 传递给target的位置参数
            kwargs: 传递给target的关键字参数
        """
        kwargs = kwargs or {}
        
        logger.info(f"Starting {num_workers} workers")
        
        for i in range(num_workers):
            self._start_worker(i, target, args, kwargs)
            
    def _start_worker(
        self,
        worker_id: int,
        target: Callable,
        args: tuple,
        kwargs: dict
    ):
        """启动单个Worker"""
        import time
        
        process = multiprocessing.Process(
            target=self._worker_wrapper,
            args=(worker_id, target, args, kwargs),
            name=f"kewe-worker-{worker_id}"
        )
        
        process.start()
        
        self._processes[worker_id] = process
        self._worker_configs[worker_id] = {'target': target, 'args': args, 'kwargs': kwargs}
        self.workers[worker_id] = WorkerInfo(
            index=worker_id,
            pid=process.pid,
            state=WorkerState.RUNNING,
            start_time=datetime.fromtimestamp(time.time()),
            last_heartbeat=time.time()
        )
        
        logger.info(f"Worker {worker_id} started (PID: {process.pid})")
        
    def _worker_wrapper(
        self,
        worker_id: int,
        target: Callable,
        args: tuple,
        kwargs: dict
    ):
        """Worker包装器"""
        try:
            # 设置进程标题
            try:
                import setproctitle
                setproctitle.setproctitle(f"kewe-worker-{worker_id}")
            except ImportError:
                pass
                
            # 执行目标函数
            target(*args, **kwargs)
            
        except Exception as e:
            logger.error(f"Worker {worker_id} error: {e}")
            raise
            
    def stop_workers(self, graceful: bool = True):
        """停止所有Worker"""
        logger.info("Stopping all workers...")
        self._shutdown = True
        
        for worker_id, process in list(self._processes.items()):
            self._stop_worker(worker_id, graceful)
            
        self.workers.clear()
        self._processes.clear()
        
        logger.info("All workers stopped")
        
    def _stop_worker(self, worker_id: int, graceful: bool = True):
        """停止单个Worker"""
        if worker_id not in self._processes:
            return
            
        process = self._processes[worker_id]
        
        if worker_id in self.workers:
            self.workers[worker_id].state = WorkerState.STOPPING
            
        if graceful:
            process.terminate()
            process.join(timeout=10)
            
            if process.is_alive():
                process.kill()
                process.join()
        else:
            process.kill()
            process.join()
            
        if worker_id in self.workers:
            self.workers[worker_id].state = WorkerState.STOPPED
            
        del self._processes[worker_id]
        
        logger.info(f"Worker {worker_id} stopped")
        
    def restart_worker(self, worker_id: int):
        """重启指定Worker"""
        if worker_id not in self.workers:
            logger.warning(f"Worker {worker_id} not found")
            return

        logger.info(f"Restarting worker {worker_id}")

        info = self.workers[worker_id]
        info.state = WorkerState.RESTARTING

        config = self._worker_configs.get(worker_id)
        self._stop_worker(worker_id, graceful=True)

        if config:
            self._start_worker(worker_id, config['target'], config['args'], config['kwargs'])
            logger.info(f"Worker {worker_id} restarted (PID: {self._processes.get(worker_id, multiprocessing.Process()).pid})")
        else:
            logger.warning(f"Worker {worker_id} config not found, cannot restart")
        
    def restart_all(self):
        """重启所有Worker"""
        logger.info("Restarting all workers...")
        
        for worker_id in list(self.workers.keys()):
            self.restart_worker(worker_id)
            
    def get_worker_status(self) -> List[Dict[str, Any]]:
        """获取所有Worker状态"""
        import time
        
        status = []
        for worker_id, info in self.workers.items():
            process = self._processes.get(worker_id)
            is_alive = process.is_alive() if process else False
            
            status.append({
                'worker_id': worker_id,
                'pid': info.pid,
                'state': info.state.name,
                'is_alive': is_alive,
                'request_count': info.requests_handled,
                'uptime': time.time() - info.start_time.timestamp() if info.start_time else 0
            })
            
        return status
        
    def increment_request_count(self, worker_id: int):
        """增加请求计数"""
        if worker_id in self.workers:
            self.workers[worker_id].requests_handled += 1
            
    def update_heartbeat(self, worker_id: int):
        """更新心跳"""
        import time
        
        if worker_id in self.workers:
            self.workers[worker_id].last_heartbeat = time.time()
            
    def check_health(self) -> List[int]:
        """
        检查Worker健康状态
        
        Returns:
            不健康的Worker ID列表
        """
        import time
        
        unhealthy = []
        current_time = time.time()
        
        for worker_id, info in self.workers.items():
            process = self._processes.get(worker_id)
            
            if not process or not process.is_alive():
                unhealthy.append(worker_id)
                continue
                
            # 检查心跳超时（假设心跳间隔为30秒）
            if info.last_heartbeat > 0 and current_time - info.last_heartbeat > 60:
                logger.warning(f"Worker {worker_id} heartbeat timeout")
                unhealthy.append(worker_id)
                
        return unhealthy
        
    def set_monitor_callback(self, callback: Callable):
        """
        设置监控回调
        
        Args:
            callback: 回调函数，接收Worker状态列表
        """
        self._monitor_callback = callback


class WorkerSharedState:
    """
    共享状态
    
    在多个Worker进程间共享状态
    
    使用示例:
        state = WorkerSharedState()
        state.set('counter', 0)
        
        # 在Worker中
        counter = state.get('counter')
        state.set('counter', counter + 1)
    """
    
    def __init__(self):
        self._manager = multiprocessing.Manager()
        self._state = self._manager.dict()
    
    def get(self, key, default=None):
        """获取共享状态"""
        return self._state.get(key, default)
    
    def set(self, key, value):
        """设置共享状态"""
        self._state[key] = value
    
    def delete(self, key):
        """删除共享状态"""
        if key in self._state:
            del self._state[key]
    
    def clear(self):
        """清空共享状态"""
        self._state.clear()
    
    def items(self):
        """获取所有键值对"""
        return list(self._state.items())

    def close(self):
        """释放Manager资源"""
        try:
            self._manager.shutdown()
        except Exception:
            logger.warning("Multiplexer shutdown failed", exc_info=True)

    def __del__(self):
        try:
            self.close()
        except Exception:
            logger.warning("Multiplexer cleanup failed", exc_info=True)


__all__ = [
    'Multiplexer',
    'WorkerSharedState',
    'WorkerMultiplexer',
]



