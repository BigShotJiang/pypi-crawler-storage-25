#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
多worker支持模块 - Multi-worker Support
worker实现，提供多进程服务器
支持SO_REUSEPORT和socket传递两种模式
"""
import os
import sys
import multiprocessing
import logging
import signal
import socket
import asyncio
import inspect
from typing import Optional, List, Dict, Any, Callable
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import traceback

from kewe.utils.compat import set_process_title
from kewe.worker import WorkerState

logger = logging.getLogger(__name__)


@dataclass
class WorkerInfo:
    """Worker信息"""
    index: int
    pid: Optional[int] = None
    state: WorkerState = WorkerState.INIT
    start_time: Optional[datetime] = None
    requests_handled: int = 0
    last_error: Optional[str] = None
    last_heartbeat: float = 0


class WorkerProcess(multiprocessing.Process):
    """Worker进程 - 支持socket传递"""
    
    def __init__(
        self,
        app_factory: Callable,
        index: int,
        host: str,
        port: int,
        worker_config: Dict[str, Any],
        sock: Optional[socket.socket] = None,
        use_reuseport: bool = False
    ):
        super().__init__(daemon=True)
        self.app_factory = app_factory
        self.index = index
        self.host = host
        self.port = port
        self.worker_config = worker_config
        self.sock = sock
        self.use_reuseport = use_reuseport
        self._state = multiprocessing.Value('i', WorkerState.INIT.value)
        self._requests_handled = multiprocessing.Value('i', 0)
    
    def run(self):
        """Worker进程主函数"""
        try:
            set_process_title(f"kewe-worker-{self.index}")
            self._set_state(WorkerState.STARTING)
            
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
            loop.run_until_complete(self._serve())
        except Exception as e:
            logger.error(f"Worker {self.index} failed: {e}\n{traceback.format_exc()}")
            self._set_state(WorkerState.FAILED)
    
    async def _serve(self):
        """启动服务器"""
        from kewe.server import KeweServer
        
        app = self.app_factory()
        
        server = KeweServer(
            app,
            host=self.host,
            port=self.port,
            request_timeout=self.worker_config.get('request_timeout', 60.0),
            keep_alive_timeout=self.worker_config.get('keep_alive_timeout', 5.0),
            request_max_size=self.worker_config.get('request_max_size', 100 * 1024 * 1024),
            max_connections=self.worker_config.get('max_connections', 10000)
        )
        
        self._set_state(WorkerState.RUNNING)
        
        try:
            if self.sock:
                await server.start(sock=self.sock)
            else:
                await server.start()
        except Exception as e:
            logger.error(f"Worker {self.index} server error: {e}")
            self._set_state(WorkerState.FAILED)
    
    def _set_state(self, state: WorkerState):
        """设置状态"""
        self._state.value = state.value
    
    def get_state(self) -> WorkerState:
        """获取状态"""
        return WorkerState(self._state.value)
    
    def increment_requests(self):
        """增加请求计数"""
        with self._requests_handled.get_lock():
            self._requests_handled.value += 1
    
    def get_requests_handled(self) -> int:
        """获取处理的请求数"""
        return self._requests_handled.value


class SocketManager:
    """Socket管理器 - 支持SO_REUSEPORT"""
    
    @staticmethod
    def has_reuseport() -> bool:
        """检查系统是否支持SO_REUSEPORT"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            sock.close()
            return True
        except (AttributeError, OSError):
            return False
    
    @staticmethod
    def create_socket(
        host: str,
        port: int,
        reuseport: bool = True,
        backlog: int = 128
    ) -> socket.socket:
        """创建服务器socket"""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        if reuseport and SocketManager.has_reuseport():
            try:
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
                logger.info("SO_REUSEPORT enabled")
            except OSError:
                logger.warning("SO_REUSEPORT not available, falling back to socket passing")
        
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        
        if hasattr(socket, "TCP_FASTOPEN"):
            try:
                sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_FASTOPEN, 5)
            except OSError:
                pass
        
        sock.setblocking(False)
        sock.bind((host, port))
        sock.listen(backlog)
        
        return sock


class WorkerManager:
    """Worker管理器"""
    
    def __init__(
        self,
        app_factory: Callable,
        host: str = "0.0.0.0",
        port: int = 8000,
        workers: int = 1,
        worker_config: Dict[str, Any] = None,
        use_reuseport: bool = True
    ):
        self.app_factory = app_factory
        self.host = host
        self.port = port
        self.workers_count = workers
        self.worker_config = worker_config or {}
        self.use_reuseport = use_reuseport and SocketManager.has_reuseport()
        
        self._workers: List[WorkerProcess] = []
        self._worker_infos: Dict[int, WorkerInfo] = {}
        self._master_sock: Optional[socket.socket] = None
        self._running = False
        self._shutdown_event: Optional[asyncio.Event] = None
        self._monitor_task: Optional[asyncio.Task] = None
    
    @property
    def workers(self) -> List[WorkerProcess]:
        return self._workers.copy()
    
    def get_worker_info(self, index: int) -> Optional[WorkerInfo]:
        return self._worker_infos.get(index)
    
    def get_all_worker_infos(self) -> Dict[int, WorkerInfo]:
        return self._worker_infos.copy()
    
    def _create_workers(self):
        """创建worker进程"""
        for i in range(self.workers_count):
            worker = WorkerProcess(
                app_factory=self.app_factory,
                index=i,
                host=self.host,
                port=self.port,
                worker_config=self.worker_config,
                sock=self._master_sock if not self.use_reuseport else None,
                use_reuseport=self.use_reuseport
            )
            
            self._workers.append(worker)
            self._worker_infos[i] = WorkerInfo(index=i)
    
    def _start_workers(self):
        """启动所有worker"""
        for worker in self._workers:
            worker.start()
            info = self._worker_infos[worker.index]
            info.pid = worker.pid
            info.state = WorkerState.STARTING
            info.start_time = datetime.now()
            logger.info(f"Worker {worker.index} started with pid {worker.pid}")
    
    async def _monitor_workers(self):
        """监控worker状态"""
        while self._running:
            await asyncio.sleep(5)
            
            for worker in self._workers:
                info = self._worker_infos[worker.index]
                
                if not worker.is_alive():
                    if info.state == WorkerState.RUNNING:
                        logger.warning(f"Worker {worker.index} (pid: {info.pid}) died unexpectedly")
                        info.state = WorkerState.FAILED
                        info.last_error = "Worker process died"
                        
                        if self._running:
                            await self._restart_worker(worker.index)
    
    async def _restart_worker(self, index: int):
        """重启worker"""
        old_worker = self._workers[index]
        info = self._worker_infos[index]
        
        logger.info(f"Restarting worker {index}...")
        
        new_worker = WorkerProcess(
            app_factory=self.app_factory,
            index=index,
            host=self.host,
            port=self.port,
            worker_config=self.worker_config,
            sock=self._master_sock if not self.use_reuseport else None,
            use_reuseport=self.use_reuseport
        )
        
        new_worker.start()
        
        self._workers[index] = new_worker
        info.pid = new_worker.pid
        info.state = WorkerState.STARTING
        info.start_time = datetime.now()
        
        logger.info(f"Worker {index} restarted with pid {new_worker.pid}")
    
    async def start(self):
        """启动多worker服务器"""
        self._running = True
        
        if not self.use_reuseport:
            self._master_sock = SocketManager.create_socket(
                self.host,
                self.port,
                reuseport=False
            )
            logger.info(f"Master socket created on {self.host}:{self.port}")
        
        self._create_workers()
        self._start_workers()
        
        self._monitor_task = asyncio.create_task(self._monitor_workers())
        
        logger.info(f"Started {self.workers_count} workers")
    
    async def stop(self, timeout: float = 30.0):
        """停止所有worker"""
        if not self._running:
            return
        
        self._running = False
        
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        
        for worker in self._workers:
            info = self._worker_infos[worker.index]
            info.state = WorkerState.STOPPING
            
            if worker.is_alive():
                try:
                    os.kill(worker.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
        
        await asyncio.sleep(min(timeout / 2, 5))
        
        for worker in self._workers:
            if worker.is_alive():
                logger.warning(f"Worker {worker.index} did not stop gracefully, killing...")
                try:
                    os.kill(worker.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        
        for worker in self._workers:
            worker.join(timeout=5)
            info = self._worker_infos[worker.index]
            info.state = WorkerState.STOPPED
        
        if self._master_sock:
            self._master_sock.close()
            self._master_sock = None
        
        logger.info("All workers stopped")
    
    async def scale(self, target_count: int):
        """
        动态调整 worker 数量
        
        Args:
            target_count: 目标 worker 数量
        """
        current_count = len([w for w in self._workers if w.is_alive()])
        
        if target_count == current_count:
            logger.info(f"Already at target worker count: {target_count}")
            return
        
        if target_count > current_count:
            await self._scale_up(target_count - current_count)
        else:
            await self._scale_down(current_count - target_count)
        
        logger.info(f"Scaled workers from {current_count} to {target_count}")
    
    async def _scale_up(self, count: int):
        """增加 worker"""
        for i in range(count):
            index = len(self._workers)
            worker = WorkerProcess(
                app_factory=self.app_factory,
                index=index,
                host=self.host,
                port=self.port,
                worker_config=self.worker_config,
                sock=self._master_sock if not self.use_reuseport else None,
                use_reuseport=self.use_reuseport
            )
            
            worker.start()
            self._workers.append(worker)
            self._worker_infos[index] = WorkerInfo(
                index=index,
                pid=worker.pid,
                state=WorkerState.STARTING,
                start_time=datetime.now()
            )
            
            logger.info(f"Scaled up worker {index} with pid {worker.pid}")
    
    async def _scale_down(self, count: int):
        """减少 worker"""
        workers_to_stop = self._workers[-count:]
        
        for worker in workers_to_stop:
            if worker.is_alive():
                try:
                    os.kill(worker.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
        
        await asyncio.sleep(2)
        
        for worker in workers_to_stop:
            if worker.is_alive():
                try:
                    os.kill(worker.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            
            worker.join(timeout=2)
            
            if worker.index in self._worker_infos:
                self._worker_infos[worker.index].state = WorkerState.STOPPED
        
        self._workers = self._workers[:-count]
        logger.info(f"Scaled down {count} workers")
    
    async def reload_all(self):
        """重载所有 worker"""
        logger.info("Reloading all workers...")
        
        for worker in self._workers:
            if worker.is_alive():
                try:
                    os.kill(worker.pid, signal.SIGHUP)
                except ProcessLookupError:
                    pass
        
        logger.info("Reload signal sent to all workers")


class MultiWorkerServer:
    """多worker服务器 - 兼容旧API"""
    
    def __init__(
        self,
        app,
        host: str = "0.0.0.0",
        port: int = 8000,
        workers: int = 1,
        request_timeout: float = 60.0,
        keep_alive_timeout: float = 5.0,
        request_max_size: int = 100 * 1024 * 1024
    ):
        self.app = app
        self.host = host
        self.port = port
        self.workers_count = workers
        self.worker_config = {
            'request_timeout': request_timeout,
            'keep_alive_timeout': keep_alive_timeout,
            'request_max_size': request_max_size
        }
        
        self._manager: Optional[WorkerManager] = None
        self._running = False
    
    def _create_app_factory(self) -> Callable:
        """创建应用工厂函数"""
        app = self.app
        
        def factory():
            return app
        
        return factory
    
    async def start(self):
        """启动服务器"""
        self._running = True
        
        self._manager = WorkerManager(
            app_factory=self._create_app_factory(),
            host=self.host,
            port=self.port,
            workers=self.workers_count,
            worker_config=self.worker_config
        )
        
        await self._manager.start()
        
        await self._wait_for_shutdown()
    
    async def _wait_for_shutdown(self):
        """等待关闭信号"""
        loop = asyncio.get_running_loop()
        shutdown_event = asyncio.Event()
        
        def signal_handler():
            logger.info("Received shutdown signal")
            shutdown_event.set()
        
        try:
            for sig in ('SIGINT', 'SIGTERM'):
                if hasattr(signal, sig):
                    loop.add_signal_handler(
                        getattr(signal, sig),
                        signal_handler
                    )
        except (NotImplementedError, ValueError):
            pass
        
        await shutdown_event.wait()
        await self.stop()
    
    async def stop(self):
        """停止服务器"""
        if not self._running:
            return
        
        self._running = False
        
        if self._manager:
            await self._manager.stop()
        
        logger.info("Server stopped")


async def serve_multi(
    app,
    host: str = "0.0.0.0",
    port: int = 8000,
    workers: int = 1,
    debug: bool = False,
    request_timeout: float = 60.0,
    keep_alive_timeout: float = 5.0,
    request_max_size: int = 100 * 1024 * 1024,
    **kwargs
) -> None:
    """
    运行多worker服务器
    
    Args:
        app: Kewe应用实例
        host: 主机地址
        port: 端口
        workers: worker数量
        debug: 调试模式
        request_timeout: 请求超时时间
        keep_alive_timeout: Keep-Alive超时时间
        request_max_size: 最大请求体大小
    """
    if workers <= 0:
        workers = multiprocessing.cpu_count()
        logger.info(f"Auto-detected {workers} workers")
    
    if debug and workers > 1:
        logger.warning("Debug mode enabled, using 1 worker")
        workers = 1
    
    server = MultiWorkerServer(
        app,
        host=host,
        port=port,
        workers=workers,
        request_timeout=request_timeout,
        keep_alive_timeout=keep_alive_timeout,
        request_max_size=request_max_size
    )
    
    await server.start()


__all__ = [
    'WorkerState',
    'WorkerInfo',
    'WorkerProcess',
    'SocketManager',
    'WorkerManager',
    'MultiWorkerServer',
    'serve_multi',
]