#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Rate Limiting - 限流模块
提供请求限流功能（固定窗口/滑动窗口/令牌桶）
"""
import time
import asyncio
import threading
import logging
from typing import Optional, Dict, Any, Callable, Union, Tuple
from dataclasses import dataclass
from abc import ABC, abstractmethod
from kewe.request import Request
from kewe.response import Response

logger = logging.getLogger(__name__)


@dataclass
class RateLimitInfo:
    limit: int
    remaining: int
    reset_time: int
    retry_after: Optional[int] = None


class RateLimiterBackend(ABC):
    @abstractmethod
    async def get(self, key: str) -> Optional[int]:
        pass

    @abstractmethod
    async def incr(self, key: str, ttl: int) -> int:
        pass

    @abstractmethod
    async def reset(self, key: str) -> None:
        pass

    @abstractmethod
    async def get_ttl(self, key: str) -> Optional[int]:
        pass


class MemoryBackend(RateLimiterBackend):

    def __init__(self):
        self._store: Dict[str, tuple] = {}
        self._lock: Optional[asyncio.Lock] = None
        self._sync_lock = threading.Lock()

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    def incr_sync(self, key: str, ttl: int) -> int:
        with self._sync_lock:
            now = time.time()
            if key in self._store:
                count, old_expire = self._store[key]
                if now < old_expire:
                    count += 1
                    self._store[key] = (count, old_expire)
                else:
                    self._store[key] = (1, now + ttl)
            else:
                self._store[key] = (1, now + ttl)
            return self._store[key][0]

    async def get(self, key: str) -> Optional[int]:
        async with self._get_lock():
            if key in self._store:
                count, expire_time = self._store[key]
                if time.time() < expire_time:
                    return count
                else:
                    del self._store[key]
            return None

    async def incr(self, key: str, ttl: int) -> int:
        async with self._get_lock():
            now = time.time()
            if key in self._store:
                count, old_expire = self._store[key]
                if now < old_expire:
                    count += 1
                    self._store[key] = (count, old_expire)
                else:
                    self._store[key] = (1, now + ttl)
            else:
                self._store[key] = (1, now + ttl)
            if len(self._store) > 10000:
                expired_keys = [k for k, (_, exp) in self._store.items() if now >= exp]
                for k in expired_keys:
                    del self._store[k]
            return self._store[key][0]

    async def reset(self, key: str) -> None:
        async with self._get_lock():
            if key in self._store:
                del self._store[key]

    async def get_ttl(self, key: str) -> Optional[int]:
        async with self._get_lock():
            if key in self._store:
                _, expire_time = self._store[key]
                ttl = int(expire_time - time.time())
                return max(0, ttl)
            return None


class RedisBackend(RateLimiterBackend):

    _INCR_LUA = """
    local key = KEYS[1]
    local ttl = tonumber(ARGV[1])
    local count = redis.call('INCR', key)
    if count == 1 then
        redis.call('EXPIRE', key, ttl)
    end
    return count
    """

    def __init__(self, redis_client, prefix: str = "rate_limit:"):
        self.redis = redis_client
        self.prefix = prefix
        self._incr_script = self.redis.register_script(self._INCR_LUA) if hasattr(self.redis, 'register_script') else None

    def _make_key(self, key: str) -> str:
        return f"{self.prefix}{key}"

    async def get(self, key: str) -> Optional[int]:
        value = await self.redis.get(self._make_key(key))
        return int(value) if value else None

    async def incr(self, key: str, ttl: int) -> int:
        redis_key = self._make_key(key)
        if self._incr_script:
            count = await self._incr_script(keys=[redis_key], args=[ttl])
            return int(count)
        count = await self.redis.incr(redis_key)
        if count == 1:
            await self.redis.expire(redis_key, ttl)
        return count

    async def reset(self, key: str) -> None:
        await self.redis.delete(self._make_key(key))

    async def get_ttl(self, key: str) -> Optional[int]:
        ttl = await self.redis.ttl(self._make_key(key))
        return ttl if ttl > 0 else None


class SlidingWindowMemoryBackend(RateLimiterBackend):
    def __init__(self, default_window: float = 60.0):
        self._store: Dict[str, list] = {}
        self._windows: Dict[str, float] = {}
        self._lock: Optional[asyncio.Lock] = None
        self._default_window = default_window

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def get(self, key: str) -> Optional[int]:
        async with self._get_lock():
            if key in self._store:
                now = time.time()
                window = self._windows.get(key, self._default_window)
                self._store[key] = [t for t in self._store[key] if now - t < window]
                return len(self._store[key])
            return None

    async def incr(self, key: str, ttl: int) -> int:
        async with self._get_lock():
            now = time.time()
            if key not in self._store:
                self._store[key] = []
            self._windows[key] = float(ttl)
            self._store[key] = [t for t in self._store[key] if now - t < ttl]
            self._store[key].append(now)
            if len(self._store) > 10000:
                expired_keys = [
                    k for k, v in self._store.items()
                    if not v or now - v[-1] > self._windows.get(k, self._default_window)
                ]
                for k in expired_keys:
                    self._store.pop(k, None)
                    self._windows.pop(k, None)
            return len(self._store[key])

    async def reset(self, key: str) -> None:
        async with self._get_lock():
            self._store.pop(key, None)
            self._windows.pop(key, None)

    async def get_ttl(self, key: str) -> Optional[int]:
        async with self._get_lock():
            if key in self._store and self._store[key]:
                window = self._windows.get(key, self._default_window)
                oldest = min(self._store[key])
                return max(0, int(oldest + window - time.time()))
            return None


class TokenBucketBackend(RateLimiterBackend):
    def __init__(self, refill_rate: float = 1.0):
        self._store: Dict[str, tuple] = {}
        self._refill_rate = refill_rate
        self._lock: Optional[asyncio.Lock] = None

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def get(self, key: str) -> Optional[int]:
        async with self._get_lock():
            if key in self._store:
                tokens, last_refill = self._store[key]
                now = time.time()
                elapsed = now - last_refill
                max_tokens = self._refill_rate * 60
                tokens = min(tokens + elapsed * self._refill_rate, max_tokens)
                self._store[key] = (tokens, now)
                return int(max_tokens - tokens)
            return None

    async def incr(self, key: str, ttl: int) -> int:
        async with self._get_lock():
            now = time.time()
            if key not in self._store:
                self._store[key] = (self._refill_rate * 60 - 1, now)
                return 1
            tokens, last_refill = self._store[key]
            elapsed = now - last_refill
            tokens = min(tokens + elapsed * self._refill_rate, self._refill_rate * 60)
            tokens -= 1
            self._store[key] = (tokens, now)
            return int(self._refill_rate * 60 - tokens)

    async def reset(self, key: str) -> None:
        async with self._get_lock():
            self._store.pop(key, None)

    async def get_ttl(self, key: str) -> Optional[int]:
        async with self._get_lock():
            if key in self._store:
                tokens, last_refill = self._store[key]
                needed = self._refill_rate * 60 - tokens
                if needed <= 0:
                    return 0
                return int(needed / self._refill_rate)
            return None


class RateLimiter:

    def __init__(
        self,
        backend: Optional[RateLimiterBackend] = None,
        key_func: Optional[Callable[[Request], str]] = None,
        limit: Optional[int] = None,
        period: Optional[int] = None,
        max_requests: Optional[int] = None,
        window: Optional[int] = None,
    ):
        self.backend = backend or MemoryBackend()
        self._default_limit = max_requests or limit
        self._default_period = window or period
        if key_func is not None:
            self.key_func = key_func
        else:
            self.key_func = lambda req: req.client_ip

    async def is_allowed(self, request: Request, limit: int = None, period: int = None) -> Tuple[bool, "RateLimitInfo"]:
        effective_limit = limit or self._default_limit or 100
        effective_period = period or self._default_period or 60
        key = self.key_func(request)
        count = await self.backend.incr(key, effective_period)
        remaining = max(0, effective_limit - count)
        ttl = await self.backend.get_ttl(key)
        reset_time = int(time.time()) + (ttl if ttl else effective_period)
        if count > effective_limit:
            retry_after = ttl if ttl else effective_period
            return False, RateLimitInfo(
                limit=effective_limit,
                remaining=0,
                reset_time=reset_time,
                retry_after=retry_after
            )
        return True, RateLimitInfo(
            limit=effective_limit,
            remaining=remaining,
            reset_time=reset_time
        )

    def check(self, key: str, limit: int = None, period: int = None, window: int = None):
        effective_limit = limit or self._default_limit or 100
        effective_period = period or window or self._default_period or 60
        if hasattr(self.backend, 'incr_sync'):
            count = self.backend.incr_sync(key, effective_period)
        else:
            count = 1
        allowed = count <= effective_limit
        return RateLimitInfo(
            limit=effective_limit,
            remaining=max(0, effective_limit - count),
            reset_time=time.time() + effective_period,
            retry_after=0 if allowed else effective_period,
        )

    async def acheck(self, key: str, limit: int = None, period: int = None) -> bool:
        """便捷方法：检查指定key是否在限流范围内

        Args:
            key: 限流标识（如客户端IP）
            limit: 最大请求数（默认使用构造函数传入值或100）
            period: 时间窗口秒数（默认使用构造函数传入值或60）

        Returns:
            True 表示允许，False 表示超限
        """
        effective_limit = limit or self._default_limit or 100
        effective_period = period or self._default_period or 60
        count = await self.backend.incr(key, effective_period)
        return count <= effective_limit

    async def reset(self, request: Request) -> None:
        key = self.key_func(request)
        await self.backend.reset(key)


class RateLimitMiddleware:

    def __init__(
        self,
        limit: int,
        period: int = 60,
        backend: Optional[RateLimiterBackend] = None,
        key_func: Optional[Callable[[Request], str]] = None,
        on_limit: Optional[Callable] = None,
    ):
        self.limiter = RateLimiter(backend, key_func)
        self.limit = limit
        self.period = period
        self.excluded_paths = []
        self.on_limit = on_limit

    async def check_limit(self, request: Request) -> bool:
        for path in self.excluded_paths:
            if request.path.startswith(path):
                return True
        is_allowed, info = await self.limiter.is_allowed(
            request, self.limit, self.period
        )
        request.ctx.rate_limit_info = info
        if not is_allowed:
            if self.on_limit:
                return await self.on_limit(request, info)
            from kewe.errors.exceptions import TooManyRequests
            exc = TooManyRequests(
                f"Rate limit exceeded. Retry after {info.retry_after} seconds",
                retry_after=info.retry_after
            )
            exc.headers.update({
                "X-RateLimit-Limit": str(info.limit),
                "X-RateLimit-Remaining": str(info.remaining),
                "X-RateLimit-Reset": str(info.reset_time),
                "Retry-After": str(info.retry_after)
            })
            raise exc
        return True

    async def after_request(self, request: Request, response: Response) -> Response:
        if hasattr(request.ctx, 'rate_limit_info'):
            info = request.ctx.rate_limit_info
            response.headers['X-RateLimit-Limit'] = str(info.limit)
            response.headers['X-RateLimit-Remaining'] = str(info.remaining)
            response.headers['X-RateLimit-Reset'] = str(info.reset_time)
            if info.retry_after is not None:
                response.headers['Retry-After'] = str(info.retry_after)
        return response


def rate_limit(limit: int, period: int = 60, backend: Optional[RateLimiterBackend] = None,
               key_func: Optional[Callable[[Request], str]] = None,
               excluded_paths: Optional[list] = None,
               on_limit: Optional[Callable] = None):
    def decorator(func):
        middleware = RateLimitMiddleware(
            limit, period, backend, key_func, on_limit
        )
        if excluded_paths:
            middleware.excluded_paths = excluded_paths

        import functools

        @functools.wraps(func)
        async def async_wrapper(request, *args, **kwargs):
            result = middleware.check_limit(request)
            if hasattr(result, '__await__'):
                result = await result
            if result is not None:
                return result
            return await func(request, *args, **kwargs)

        @functools.wraps(func)
        def sync_wrapper(request, *args, **kwargs):
            result = middleware.check_limit(request)
            if hasattr(result, '__await__'):
                import asyncio
                import concurrent.futures
                try:
                    loop = asyncio.get_running_loop()
                    with concurrent.futures.ThreadPoolExecutor() as pool:
                        future = pool.submit(asyncio.run, result)
                        result = future.result(timeout=30)
                except RuntimeError:
                    result = asyncio.run(result)
            if result is not None:
                return result
            return func(request, *args, **kwargs)

        import asyncio
        if asyncio.iscoroutinefunction(func):
            wrapper = async_wrapper
        else:
            wrapper = sync_wrapper

        wrapper._rate_limit_middleware = middleware
        return wrapper
    return decorator


__all__ = [
    'RateLimiterBackend',
    'MemoryBackend',
    'SlidingWindowMemoryBackend',
    'TokenBucketBackend',
    'RedisBackend',
    'RateLimiter',
    'RateLimitInfo',
    'RateLimitMiddleware',
    'rate_limit',
]

