#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Kewe Security Module"""

from .jwt import JWTAuthManager
from .rbac_manager import RBACManager
from .token_store import TokenStore
from .csrf import (
    CSRFProtection,
    CSRFMiddleware,
    csrf_protect,
    get_csrf_token,
    set_csrf_cookie
)
from .rate_limit import (
    RateLimiterBackend,
    MemoryBackend,
    RedisBackend,
    RateLimiter,
    RateLimitMiddleware,
    RateLimitInfo,
    rate_limit
)
from .password import generate_password_hash, check_password_hash, hash_password, verify_password
from .auth import (
    AuthStrategy,
    AuthError,
    AuthenticationError,
    AuthorizationError,
    User,
    AuthToken,
    APIKey,
    OAuth2Config,
    UserStore,
    TokenStoreProtocol,
    InMemoryUserStore,
    InMemoryTokenStore,
    JWTAuthenticator,
    SessionAuthenticator,
    APIKeyAuthenticator,
    OAuth2Authenticator,
    EnhancedRBACManager,
    AuthManager,
    get_current_user,
    login_required,
    roles_required,
    permissions_required,
)

__all__ = [
    'JWTAuthManager',
    'RBACManager',
    'TokenStore',
    'CSRFProtection',
    'CSRFMiddleware',
    'csrf_protect',
    'get_csrf_token',
    'set_csrf_cookie',
    'RateLimiterBackend',
    'MemoryBackend',
    'RedisBackend',
    'RateLimiter',
    'RateLimitMiddleware',
    'RateLimitInfo',
    'rate_limit',
    'generate_password_hash',
    'check_password_hash',
    'hash_password',
    'verify_password',
    'AuthStrategy',
    'AuthError',
    'AuthenticationError',
    'AuthorizationError',
    'User',
    'AuthToken',
    'APIKey',
    'OAuth2Config',
    'UserStore',
    'TokenStoreProtocol',
    'InMemoryUserStore',
    'InMemoryTokenStore',
    'JWTAuthenticator',
    'SessionAuthenticator',
    'APIKeyAuthenticator',
    'OAuth2Authenticator',
    'EnhancedRBACManager',
    'AuthManager',
    'get_current_user',
    'login_required',
    'roles_required',
    'permissions_required',
]
