#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""RBAC (Role-Based Access Control) Manager"""

from typing import Dict, List, Set, Optional
from enum import Enum

from kewe.logging.logger import get_logger


class Role(Enum):
    """角色枚举"""
    ADMIN = "admin"
    USER = "user"
    GUEST = "guest"
    MODERATOR = "moderator"


class Permission(Enum):
    """权限枚举"""
    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    ADMIN = "admin"
    MODERATE = "moderate"


class RBACManager:

    DEFAULT_ROLE_HIERARCHY = {
        "admin": {"moderator", "user"},
        "moderator": {"user"},
        "user": {"guest"},
    }

    def __init__(self):
        self.role_permissions: Dict[str, Set[str]] = {}
        self.user_roles: Dict[str, Set[str]] = {}
        self.role_hierarchy: Dict[str, Set[str]] = dict(self.DEFAULT_ROLE_HIERARCHY)
        self._resource_permissions: Dict[str, Set[str]] = {}
        self.logger = get_logger(__name__)
        self._init_default_roles()

    def _init_default_roles(self):
        self.role_permissions["admin"] = {
            "read", "write", "delete", "admin", "moderate"
        }
        self.role_permissions["moderator"] = {
            "read", "write", "moderate"
        }
        self.role_permissions["user"] = {
            "read", "write"
        }
        self.role_permissions["guest"] = {
            "read"
        }

    def _normalize_role(self, role) -> str:
        if isinstance(role, Role):
            return role.value
        if isinstance(role, str):
            return role.lower()
        raise TypeError(f"Role must be Role enum or str, got {type(role)}")
    
    def _normalize_permission(self, permission) -> str:
        if isinstance(permission, Permission):
            return permission.value
        if isinstance(permission, str):
            return permission.lower()
        raise TypeError(f"Permission must be Permission enum or str, got {type(permission)}")

    def add_role(self, role, permissions: Optional[Set[str]] = None) -> bool:
        """添加角色（如不存在则创建）

        Args:
            role: 角色名或Role枚举
            permissions: 初始权限集合

        Returns:
            是否添加成功
        """
        try:
            role_name = self._normalize_role(role)
            if role_name not in self.role_permissions:
                self.role_permissions[role_name] = set()
            if permissions:
                for p in permissions:
                    self.role_permissions[role_name].add(self._normalize_permission(p))
            return True
        except Exception:
            return False

    def add_permission(self, role_or_permission, permission=None) -> bool:
        if permission is not None:
            return self.add_permission_to_role(role_or_permission, permission)
        perm_name = role_or_permission.value if isinstance(role_or_permission, Permission) else str(role_or_permission)
        for role_perms in self.role_permissions.values():
            if perm_name in role_perms:
                return True
        if 'default' not in self.role_permissions:
            self.role_permissions['default'] = set()
        self.role_permissions['default'].add(perm_name)
        return True

    def grant_permission(self, role, permission) -> bool:
        return self.add_permission(role, permission)

    def assign_role_to_user(self, user_id: str, role) -> bool:
        try:
            role = self._normalize_role(role)
            if user_id not in self.user_roles:
                self.user_roles[user_id] = set()
            self.user_roles[user_id].add(role)
            self.logger.info(f"Role {role} assigned to user {user_id}")
            return True
        except Exception as e:
            self.logger.error(f"分配角色失败: {e}")
            return False

    def assign_role(self, user_id: str, role) -> bool:
        return self.assign_role_to_user(user_id, role)

    def remove_role_from_user(self, user_id: str, role) -> bool:
        """
        从用户移除角色

        Args:
            user_id: 用户ID
            role: 角色

        Returns:
            是否移除成功
        """
        try:
            role = self._normalize_role(role)
            if user_id in self.user_roles and role in self.user_roles[user_id]:
                self.user_roles[user_id].remove(role)
                self.logger.info(f"已从用户 {user_id} 移除角色 {role}")
                return True
            return False
        except Exception as e:
            self.logger.error(f"移除角色失败: {e}")
            return False

    def get_user_roles(self, user_id: str) -> Set[str]:
        return self.user_roles.get(user_id, set())

    def get_all_inherited_roles(self, user_id: str) -> Set[str]:
        direct_roles = self.user_roles.get(user_id, set())
        all_roles = set(direct_roles)
        queue = list(direct_roles)
        visited = set(direct_roles)
        max_depth = 100
        depth = 0
        while queue and depth < max_depth:
            depth += 1
            role = queue.pop()
            inherited = self.role_hierarchy.get(role, set())
            for r in inherited:
                if r not in visited:
                    all_roles.add(r)
                    visited.add(r)
                    queue.append(r)
        return all_roles

    def has_permission(self, user_id_or_role, permission=None) -> bool:
        if permission is not None:
            permission = self._normalize_permission(permission)
            if user_id_or_role in self.role_permissions:
                return permission in self.role_permissions[user_id_or_role]
            all_roles = self.get_all_inherited_roles(user_id_or_role)
            for role in all_roles:
                if role in self.role_permissions and permission in self.role_permissions[role]:
                    return True
            return False
        perm_to_check = self._normalize_permission(user_id_or_role)
        for role_name, perms in self.role_permissions.items():
            if perm_to_check in perms:
                return True
        return False

    def check_permission(self, user_id_or_role, permission=None) -> bool:
        return self.has_permission(user_id_or_role, permission)

    def get_user_permissions(self, user_id: str) -> Set[str]:
        permissions = set()
        all_roles = self.get_all_inherited_roles(user_id)
        for role in all_roles:
            if role in self.role_permissions:
                permissions.update(self.role_permissions[role])
        return permissions

    def check_all_permissions(self, roles: list, permissions: list) -> bool:
        all_role_perms = set()
        for role in roles:
            role = self._normalize_role(role)
            if role in self.role_permissions:
                all_role_perms.update(self.role_permissions[role])
            inherited = self.role_hierarchy.get(role, set())
            for r in inherited:
                if r in self.role_permissions:
                    all_role_perms.update(self.role_permissions[r])
        return all(self._normalize_permission(p) in all_role_perms for p in permissions)

    def check_any_permission(self, roles: list, permissions: list) -> bool:
        all_role_perms = set()
        for role in roles:
            role = self._normalize_role(role)
            if role in self.role_permissions:
                all_role_perms.update(self.role_permissions[role])
            inherited = self.role_hierarchy.get(role, set())
            for r in inherited:
                if r in self.role_permissions:
                    all_role_perms.update(self.role_permissions[r])
        return any(self._normalize_permission(p) in all_role_perms for p in permissions)

    def add_permission_to_role(self, role, permission) -> bool:
        """
        为角色添加权限

        Args:
            role: 角色
            permission: 权限

        Returns:
            是否添加成功
        """
        try:
            role = self._normalize_role(role)
            permission = self._normalize_permission(permission)
            if role not in self.role_permissions:
                self.role_permissions[role] = set()
            self.role_permissions[role].add(permission)
            self.logger.info(f"Permission {permission} added to role {role}")
            return True
        except Exception as e:
            self.logger.error(f"添加权限失败: {e}")
            return False

    def remove_permission_from_role(self, role, permission) -> bool:
        """
        从角色移除权限

        Args:
            role: 角色
            permission: 权限

        Returns:
            是否移除成功
        """
        try:
            role = self._normalize_role(role)
            permission = self._normalize_permission(permission)
            if role in self.role_permissions and permission in self.role_permissions[role]:
                self.role_permissions[role].remove(permission)
                self.logger.info(f"Permission {permission} removed from role {role}")
                return True
            return False
        except Exception as e:
            self.logger.error(f"移除权限失败: {e}")
            return False

    def get_role_permissions(self, role) -> Set[str]:
        return self.role_permissions.get(role, set())

    def has_resource_permission(self, user_id: str, permission, resource_type: str = None, resource_id: str = None) -> bool:
        permission = self._normalize_permission(permission)
        if resource_type and resource_id:
            resource_key = f"{resource_type}:{resource_id}"
            perm_string = f"{permission}:{resource_key}"
            if hasattr(self, '_resource_permissions') and user_id in self._resource_permissions:
                if perm_string in self._resource_permissions[user_id]:
                    return True
        return self.has_permission(user_id, permission)

    def grant_resource_permission(self, user_id: str, permission, resource_type: str, resource_id: str) -> bool:
        try:
            permission = self._normalize_permission(permission)
            resource_key = f"{resource_type}:{resource_id}"
            perm_string = f"{permission}:{resource_key}"
            if not hasattr(self, '_resource_permissions'):
                self._resource_permissions: Dict[str, Set[str]] = {}
            if user_id not in self._resource_permissions:
                self._resource_permissions[user_id] = set()
            self._resource_permissions[user_id].add(perm_string)
            self.logger.info(f"Granted {permission} on {resource_key} to user {user_id}")
            return True
        except Exception as e:
            self.logger.error(f"Grant resource permission failed: {e}")
            return False

    def revoke_resource_permission(self, user_id: str, permission, resource_type: str, resource_id: str) -> bool:
        try:
            permission = self._normalize_permission(permission)
            resource_key = f"{resource_type}:{resource_id}"
            perm_string = f"{permission}:{resource_key}"
            if hasattr(self, '_resource_permissions') and user_id in self._resource_permissions:
                self._resource_permissions[user_id].discard(perm_string)
            self.logger.info(f"Revoked {permission} on {resource_key} from user {user_id}")
            return True
        except Exception as e:
            self.logger.error(f"Revoke resource permission failed: {e}")
            return False

    def get_resource_permissions(self, user_id: str, resource_type: str = None) -> Set[str]:
        if not hasattr(self, '_resource_permissions') or user_id not in self._resource_permissions:
            return set()
        perms = self._resource_permissions[user_id]
        if resource_type:
            return {p for p in perms if f":{resource_type}:" in p}
        return perms


__all__ = [
    'Role',
    'Permission',
    'RBACManager',
]
