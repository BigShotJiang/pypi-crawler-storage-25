#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""JWT Authentication Module"""

from kewe.utils.compat import json
import base64
import hashlib
import os
import time
import secrets
from typing import Optional, Dict, Any, Tuple, List, Union
from dataclasses import dataclass, asdict, field
from enum import Enum

try:
    from cryptography.hazmat.primitives.asymmetric import rsa, padding
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.exceptions import InvalidSignature
    _HAS_CRYPTOGRAPHY = True
except ImportError:
    _HAS_CRYPTOGRAPHY = False

from kewe.application.config import Config
from kewe.errors.exceptions import KeweException
from kewe.logging.logger import get_logger
import logging

logger = logging.getLogger(__name__)

try:
    from kewe.security.token_store import TokenStore
except ImportError:
    TokenStore = None

try:
    from kewe.security.rbac_manager import RBACManager
except ImportError:
    RBACManager = None

try:
    from kewe.cache.lru_cache import LRUCache
except ImportError:
    LRUCache = None

try:
    from kewe.background.async_task_processor import AsyncTaskProcessor
except ImportError:
    AsyncTaskProcessor = None

try:
    from kewe.background.cleanup_task_manager import CleanupTaskManager
except ImportError:
    CleanupTaskManager = None

try:
    from kewe.background.token_auto_rotator import TokenAutoRotator, TokenRotationConfig
except ImportError:
    TokenAutoRotator = None
    TokenRotationConfig = None

try:
    from kewe.monitoring.anomaly_detector import AnomalyDetector, SecurityEvent
except ImportError:
    AnomalyDetector = None
    SecurityEvent = None

try:
    from kewe.monitoring.audit_log_persistence import AuditLogEntry, InMemoryAuditLogStorage, AuditLogManager
except ImportError:
    AuditLogEntry = None
    InMemoryAuditLogStorage = None
    AuditLogManager = None

try:
    from kewe.monitoring.monitoring import MonitoringManager
except ImportError:
    MonitoringManager = None

try:
    from kewe.utils.distributed_lock import LockManager
except ImportError:
    LockManager = None


class TokenType(Enum):
    """令牌类型"""
    ACCESS = "access"
    REFRESH = "refresh"


class TokenStatus(Enum):
    """令牌状态"""
    ACTIVE = "active"
    EXPIRED = "expired"
    REVOKED = "revoked"
    INVALID = "invalid"


class JWTAlgorithm(Enum):
    """JWT算法"""
    RS256 = "RS256"
    HS256 = "HS256"


class PathConstants:
    """路径常量"""
    PRIVATE_KEY_FILE = "conf/private_key.pem"
    PUBLIC_KEY_FILE = "conf/public_key.pem"

    @classmethod
    def ensure_keys_dir(cls):
        """确保密钥目录存在"""
        import os
        os.makedirs(os.path.dirname(cls.PRIVATE_KEY_FILE), exist_ok=True)


class SecurityException(KeweException):
    """安全异常基类"""
    def __init__(self, message: str = "Security error", status_code: int = 401, error_code: str = "SECURITY_ERROR"):
        super().__init__(message=message, status_code=status_code, error_code=error_code)


class TokenExpiredError(SecurityException):
    """令牌过期异常"""
    def __init__(self, message: str = "Token has expired"):
        super().__init__(message=message, status_code=401, error_code="TOKEN_EXPIRED")


class InvalidTokenError(SecurityException):
    """无效令牌异常"""
    def __init__(self, message: str = "Invalid token"):
        super().__init__(message=message, status_code=401, error_code="INVALID_TOKEN")


class RateLimitExceeded(SecurityException):
    """速率限制超出异常"""
    def __init__(self, message: str = "Rate limit exceeded"):
        super().__init__(message=message, status_code=429, error_code="RATE_LIMIT_EXCEEDED")


class ConcurrentSessionLimit(SecurityException):
    """并发会话限制异常"""
    def __init__(self, message: str = "Concurrent session limit reached"):
        super().__init__(message=message, status_code=429, error_code="CONCURRENT_SESSION_LIMIT")


class JWTEncoder:
    """JWT 编码器 — 支持 Base64URL 编解码和完整 JWT 签名"""

    @staticmethod
    def encode(data: Dict[str, Any], secret: str = "", algorithm: str = "HS256") -> str:
        if secret:
            return JWTEncoder._encode_jwt(data, secret, algorithm)
        json_str = json.dumps(data, separators=(",", ":"))
        return base64.urlsafe_b64encode(json_str.encode()).decode().rstrip("=")

    @staticmethod
    def _encode_jwt(payload: Dict[str, Any], secret: str, algorithm: str = "HS256") -> str:
        header = {"alg": algorithm, "typ": "JWT"}
        header_b64 = JWTEncoder._b64url_encode(json.dumps(header, separators=(",", ":")).encode())
        payload_b64 = JWTEncoder._b64url_encode(json.dumps(payload, separators=(",", ":")).encode())
        signing_input = f"{header_b64}.{payload_b64}"
        signature = JWTEncoder._sign(signing_input, secret, algorithm)
        return f"{signing_input}.{signature}"

    @staticmethod
    def decode(data: str, secret: str = "", algorithm: str = "HS256") -> Dict[str, Any]:
        if secret and "." in data:
            return JWTEncoder._decode_jwt(data, secret, algorithm)
        padding = 4 - len(data) % 4
        if padding != 4:
            data += "=" * padding
        json_str = base64.urlsafe_b64decode(data).decode()
        return json.loads(json_str)

    @staticmethod
    def _decode_jwt(token: str, secret: str, algorithm: str = "HS256") -> Dict[str, Any]:
        parts = token.split(".")
        if len(parts) != 3:
            raise ValueError("Invalid JWT format")
        header_b64, payload_b64, signature = parts
        signing_input = f"{header_b64}.{payload_b64}"
        expected_sig = JWTEncoder._sign(signing_input, secret, algorithm)
        if not secrets.compare_digest(signature, expected_sig):
            raise ValueError("Invalid JWT signature")
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding
        payload_json = base64.urlsafe_b64decode(payload_b64).decode()
        return json.loads(payload_json)

    @staticmethod
    def _b64url_encode(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).decode().rstrip("=")

    @staticmethod
    def _sign(signing_input: str, secret: str, algorithm: str = "HS256") -> str:
        import hmac as _hmac
        alg_map = {
            "HS256": hashlib.sha256,
            "HS384": hashlib.sha384,
            "HS512": hashlib.sha512,
        }
        hash_func = alg_map.get(algorithm.upper(), hashlib.sha256)
        sig = _hmac.new(
            secret.encode() if isinstance(secret, str) else secret,
            signing_input.encode(),
            hash_func,
        ).digest()
        return JWTEncoder._b64url_encode(sig)


class RSAKeyManager:
    """RSA 密钥管理器"""

    def __init__(self, key_size: int = 2048, hmac_secret: Optional[str] = None):
        if not _HAS_CRYPTOGRAPHY:
            raise ImportError(
                "cryptography is required for RSA JWT. "
                "Install it with: pip install kewe[security]"
            )
        self.key_size = key_size
        self.private_key = None
        self.public_key = None
        self.old_public_keys: List[rsa.RSAPublicKey] = []
        self.created_at = None
        self.hmac_secret = hmac_secret or secrets.token_hex(32)
        self.current_key_id: Optional[str] = None
        self.logger = get_logger(__name__)

    def generate_keypair(self) -> None:
        """生成新的 RSA 密钥对"""
        self.private_key = rsa.generate_private_key(
            public_exponent=65537, key_size=self.key_size
        )
        self.public_key = self.private_key.public_key()
        self.created_at = time.time()
        self.current_key_id = secrets.token_hex(8)
        self.logger.info(f"RSA 密钥对已生成，大小: {self.key_size} bits, kid: {self.current_key_id}")

    def save_to_files(self, private_path: str, public_path: str, password: Optional[bytes] = None) -> bool:
        """保存密钥到文件
        
        Args:
            private_path: 私钥文件路径
            public_path: 公钥文件路径
            password: 私钥加密密码，None 表示不加密（不推荐用于生产环境）
        """
        try:
            if password:
                enc_alg = serialization.BestAvailableEncryption(password)
            else:
                enc_alg = serialization.NoEncryption()
            private_pem = self.private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=enc_alg,
            )
            with open(private_path, "wb") as f:
                f.write(private_pem)

            # 保存公钥
            public_pem = self.public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo,
            )
            with open(public_path, "wb") as f:
                f.write(public_pem)

            return True
        except Exception as e:
            self.logger.error(f"Failed to save key: {e}")
            return False

    def load_from_files(self, private_path: str, public_path: str, password: Optional[bytes] = None) -> bool:
        """从文件加载密钥
        
        Args:
            private_path: 私钥文件路径
            public_path: 公钥文件路径
            password: 私钥解密密码，None 表示未加密
        """
        try:
            with open(private_path, "rb") as f:
                self.private_key = serialization.load_pem_private_key(
                    f.read(), password=password
                )

            with open(public_path, "rb") as f:
                self.public_key = serialization.load_pem_public_key(f.read())

            self.created_at = time.time()
            return True
        except Exception as e:
            self.logger.error(f"加载密钥失败: {e}")
            return False

    def load_from_pem(self, private_pem: str = None, public_pem: str = None, password: Optional[bytes] = None) -> bool:
        if private_pem:
            try:
                if isinstance(private_pem, str):
                    private_pem = private_pem.encode('utf-8')
                self.private_key = serialization.load_pem_private_key(private_pem, password=password)
            except Exception as e:
                self.logger.error(f"加载私钥PEM失败: {e}")
                return False
        if public_pem:
            try:
                if isinstance(public_pem, str):
                    public_pem = public_pem.encode('utf-8')
                self.public_key = serialization.load_pem_public_key(public_pem)
            except Exception as e:
                self.logger.error(f"Failed to load public key PEM: {e}")
                return False
        self.created_at = time.time()
        return True

    def should_rotate(self, rotation_interval: int = 86400) -> bool:
        """检查是否需要轮换密钥"""
        if self.created_at is None:
            return False
        return time.time() - self.created_at > rotation_interval


class _SyncRateLimiter:
    """同步速率限制器 - 委托给 kewe.security.rate_limit"""

    def __init__(self, redis_client: Optional[Any] = None):
        from kewe.security.rate_limit import MemoryBackend, RateLimiter
        self._backend = MemoryBackend()
        self._limiter = RateLimiter(self._backend, key_func=lambda req: req if isinstance(req, str) else req.client_ip)
        self.logger = get_logger(__name__)

    def is_allowed(self, key: str, max_requests: int = 100, window: int = 60) -> bool:
        import asyncio
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            return self._check_local(key, max_requests, window)
        try:
            return asyncio.run(self._limiter.check(key, limit=max_requests, period=window))
        except RuntimeError:
            return self._check_local(key, max_requests, window)

    def _check_local(self, key: str, max_requests: int, window: int) -> bool:
        current_time = time.time()
        if not hasattr(self, '_local_cache'):
            self._local_cache: Dict[str, Dict[str, Any]] = {}
        if key not in self._local_cache:
            self._local_cache[key] = {"requests": [], "last_cleanup": current_time}
        cache = self._local_cache[key]
        if current_time - cache["last_cleanup"] > window:
            cache["requests"] = [t for t in cache["requests"] if current_time - t < window]
            cache["last_cleanup"] = current_time
        if len(cache["requests"]) >= max_requests:
            return False
        cache["requests"].append(current_time)
        return True


class _DictObject:
    def __init__(self, data: dict):
        self._data = data

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(name)
        try:
            return self._data[name]
        except KeyError:
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

    def __getitem__(self, key):
        return self._data[key]

    def __contains__(self, key):
        return key in self._data

    def get(self, key, default=None):
        return self._data.get(key, default)

    def keys(self):
        return self._data.keys()

    def values(self):
        return self._data.values()

    def items(self):
        return self._data.items()

    def __repr__(self):
        return f"_DictObject({self._data})"


@dataclass
class TokenPayload:

    sub: str
    jti: str
    iat: int
    exp: int
    nbf: int
    type: str
    iss: str
    aud: str
    sid: str
    dfp: Optional[str] = None
    ip: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        extra = result.pop('extra', {})
        result.update(extra)
        return result

    def is_expiring_soon(self, threshold_ratio: float = 0.2) -> bool:
        remaining = self.exp - time.time()
        total = self.exp - self.iat
        return remaining < total * threshold_ratio

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TokenPayload":
        known_fields = {f.name for f in cls.__dataclass_fields__.values() if f.name != 'extra'}
        filtered = {k: v for k, v in data.items() if k in known_fields}
        extra = {k: v for k, v in data.items() if k not in known_fields}
        return cls(**filtered, extra=extra)


@dataclass
class SecurityContext:
    """安全上下文数据类"""

    user_agent: str = ""
    ip_address: str = "unknown"
    device_fingerprint: Optional[str] = None

    def to_dict(self) -> Dict[str, str]:
        return {
            "user_agent": self.user_agent,
            "ip_address": self.ip_address,
            "device_fingerprint": self.device_fingerprint or "",
        }


class JWTAuthManager:
    """JWT 认证管理器"""

    def __init__(
        self,
        secret_key: Optional[str] = None,
        redis_client: Optional[Any] = None,
        enable_audit_log: bool = True,
        persist_keys: bool = True,
        *,
        algorithm: Optional[str] = None,
    ):
        """
        初始化 JWT 认证管理器

        Args:
            secret_key: HMAC密钥（用于HS256算法），如未提供则自动生成RSA密钥对
            redis_client: Redis 客户端
            enable_audit_log: 是否启用审计日志
            persist_keys: 是否持久化密钥
            algorithm: JWT算法（HS256/RS256），默认RS256
        """
        self.config = Config()
        self.config.update({
            'jwt_expiration_delta': 3600,
            'jwt_rate_limit_max': 0,
            'jwt_rate_limit_window': 60,
            'session_id_length': 32,
            'access_token_jti_length': 32,
            'refresh_token_jti_length': 32,
            'max_refresh_per_minute': 10,
            'max_concurrent_sessions': 5,
            'access_token_ttl': 3600,
            'refresh_token_ttl': 86400 * 7,
            'jwt_issuer': 'kewe',
            'jwt_audience': 'kewe-api',
            'reject_ip_change': False,
            'jwt_clock_skew': 30,
        })
        self.algorithm = algorithm or self.config.get('algorithm', 'RS256')
        self.codec = JWTEncoder()
        self.key_manager = RSAKeyManager(hmac_secret=secret_key or self.config.get('hmac_secret'))
        self.token_store = TokenStore(redis_client) if redis_client else None
        self.rate_limiter = _SyncRateLimiter(redis_client) if redis_client else None
        self.rbac_manager = RBACManager() if RBACManager is not None else None
        self.anomaly_detector = AnomalyDetector(max_events=1000, time_window=3600) if AnomalyDetector is not None else None

        self.audit_log_storage = InMemoryAuditLogStorage() if InMemoryAuditLogStorage is not None else None
        self.audit_log_manager = AuditLogManager(self.audit_log_storage) if self.audit_log_storage and AuditLogManager is not None else None

        self.monitoring = MonitoringManager() if MonitoringManager is not None else None

        self.lock_manager = LockManager(redis_client) if redis_client and LockManager is not None else None

        self.async_processor = AsyncTaskProcessor(max_workers=4, max_queue_size=1000) if AsyncTaskProcessor is not None else None
        if self.async_processor is not None:
            self.async_processor.start()

        # 初始化 LRU token 缓存
        self.token_cache = LRUCache(
            max_size=1000, default_ttl=self.config.get('jwt_expiration_delta', 3600)
        )

        # 初始化密钥轮换
        self.key_rotation_interval = 3600

        # jti预生成池
        self._jti_pool_size = 64
        self._jti_pool: List[str] = []
        self._refill_jti_pool()

        # 初始化监控指标
        self.metrics = {
            "token_generated": 0,
            "token_validated": 0,
            "token_validation_failed": 0,
            "token_refreshed": 0,
            "token_revoked": 0,
            "redis_operation_failed": 0,
            "cache_hit": 0,
            "cache_miss": 0,
        }

        self.logger = get_logger(__name__)

        # 保存参数
        self.persist_keys = persist_keys

        # 初始化审计日志logger（必须在cleanup_manager之前）
        if enable_audit_log:
            self.audit_logger = self.audit_log_manager
        else:
            self.audit_logger = None

        # 初始化后台清理任务管理器
        self.cleanup_manager = CleanupTaskManager() if CleanupTaskManager is not None else None
        if self.cleanup_manager is not None:
            self._register_cleanup_tasks()
            self.cleanup_manager.start()

        if TokenAutoRotator is not None and TokenRotationConfig is not None:
            self.token_rotator = TokenAutoRotator(
                config=TokenRotationConfig(
                    enabled=True,
                    strategy="hybrid",
                    rotation_threshold=0.7,
                    min_rotation_interval=300,
                    max_rotation_count=10,
                    force_rotation_on_risk=True,
                ),
                refresh_callback=self._rotate_token_callback,
            )
        else:
            self.token_rotator = None

        self._init_keys()

        if self.token_store is not None:
            self.token_store.start_cleaner()

        self.logger.info("JWTAuthManager 初始化完成")

    def _register_cleanup_tasks(self) -> None:
        """
        注册后台清理任务
        """
        # 注册缓存清理任务
        self.cleanup_manager.register_task(
            name="cache_cleanup",
            func=lambda: self.token_cache.cleanup_expired(),
            interval=60.0,  # 60秒
        )

        # 注册密钥轮换检查任务
        self.cleanup_manager.register_task(
            name="key_rotation_check",
            func=self._check_and_rotate_keys,
            interval=3600.0,  # 1小时
        )

        # 注册审计日志清理任务
        self.cleanup_manager.register_task(
            name="audit_log_cleanup",
            func=lambda: self.audit_log_storage.cleanup_old_logs(retention_days=30),
            interval=86400.0,  # 24小时
        )

        # 注册黑名单清理任务
        if self.token_store is not None:
            self.cleanup_manager.register_task(
                name="blacklist_cleanup",
                func=lambda: self.token_store.cleanup_expired_blacklist(),
                interval=3600.0,
            )

        self.logger.info("Background cleanup task registered")

    def _check_and_rotate_keys(self) -> int:
        """
        检查并轮换密钥

        Returns:
            轮换的密钥数量
        """
        # 添加日志，查看 key_rotation_interval 和时间差的值
        if self.key_manager.created_at is not None:
            time_diff = time.time() - self.key_manager.created_at
            self.logger.info(
                f"检查密钥轮换: key_rotation_interval={self.key_rotation_interval}, time_diff={time_diff}, should_rotate={self.key_manager.should_rotate(self.key_rotation_interval)}"
            )
        else:
            self.logger.info(
                f"检查密钥轮换: created_at is None, should_rotate={self.key_manager.should_rotate(self.key_rotation_interval)}"
            )

        if self.key_manager.should_rotate(self.key_rotation_interval):
            self.rotate_signing_keys()
            return 1
        return 0

    def _get_cache_key(self, token: str) -> str:
        """
        获取缓存键
        """
        import hashlib

        return f"jwt:{hashlib.sha256(token.encode()).hexdigest()}"

    def _cache_token(self, token: str, payload: TokenPayload):
        """
        缓存 token
        """
        cache_key = self._get_cache_key(token)
        # 设置与令牌过期时间匹配的缓存过期时间
        ttl = max(1, int(payload.exp - time.time()))
        self.token_cache.set(cache_key, payload, ttl=ttl)

    def _cache_tokens(self, tokens: Dict[str, TokenPayload]):
        """
        批量缓存 tokens
        """
        for token, payload in tokens.items():
            self._cache_token(token, payload)

    def _get_cached_token(self, token: str) -> Optional[TokenPayload]:
        """
        获取缓存的 token
        """
        cache_key = self._get_cache_key(token)
        return self.token_cache.get(cache_key)

    def _init_keys(self) -> None:
        """初始化密钥 - 优先从文件加载，不存在则生成新密钥对"""
        private_path = PathConstants.PRIVATE_KEY_FILE
        public_path = PathConstants.PUBLIC_KEY_FILE
        
        try:
            if os.path.exists(private_path) and os.path.exists(public_path):
                if self.key_manager.load_from_files(private_path, public_path):
                    self.logger.info("已从文件加载密钥对")
                    return
        except Exception as e:
            self.logger.warning(f"加载密钥文件失败: {e}，将生成新密钥对")
        
        self.key_manager.generate_keypair()
        self.logger.info("New key pair generated")
        
        try:
            PathConstants.ensure_keys_dir()
            self.key_manager.save_to_files(private_path, public_path)
            self.logger.info("已将新密钥对保存到文件")
        except Exception as e:
            self.logger.warning(f"Failed to save key file: {e}")

    def generate_access_token(
        self, user_id: str, user_name: str, context: SecurityContext
    ) -> str:
        """
        生成访问令牌
        """
        start_time = time.time()

        # 检查速率限制
        self._check_rate_limit(user_id, "access")

        # 创建会话
        now, session_id = self._create_session(user_id, context)

        # 生成令牌
        payload = self._create_access_token_payload(user_id, now, session_id, context)
        token = self._create_jwt(payload.to_dict())

        # 异常检测
        self._detect_anomalies(user_id, context, "access")

        # 记录审计日志
        self._log_token_issued(user_id, payload.jti, TokenType.ACCESS.value, context)

        duration = time.time() - start_time
        if self.monitoring:
            self.monitoring.record_token_generated("access", duration)

        # 注册令牌到自动轮换器
        self._register_token_for_rotation(
            token, TokenType.ACCESS.value, user_id, now, payload.exp
        )

        self.metrics["token_generated"] += 1
        self.logger.debug(f"访问令牌已生成: user={user_id}, jti={payload.jti}")
        return token

    def create_token(
        self,
        user_id: Union[str, Dict[str, Any]],
        token_type: str = "access",
        expires_delta: Optional[int] = None,
        expires_in: Optional[int] = None,
        extra_claims: Optional[Dict[str, Any]] = None,
    ) -> str:
        if expires_in is not None and expires_delta is None:
            expires_delta = expires_in
        if isinstance(user_id, dict):
            extra_claims = {**user_id, **(extra_claims or {})}
            user_id = extra_claims.pop("sub", extra_claims.pop("user_id", "unknown"))
        context = SecurityContext()
        if extra_claims:
            context = SecurityContext(
                user_agent="",
                ip_address="unknown",
                device_fingerprint=None,
            )
            context._extra_claims = extra_claims
        if token_type == "refresh":
            return self.generate_refresh_token(user_id, context)
        return self.generate_access_token(user_id, str(user_id), context)

    def decode_token(self, token: str):
        payload = self._decode_token(token, verify=True)
        if isinstance(payload, dict):
            return _DictObject(payload)
        return payload

    def _check_rate_limit(self, user_id: str, token_type: str) -> None:
        max_requests = self.config.jwt_rate_limit_max
        if not max_requests or max_requests <= 0:
            return
        if not self.rate_limiter.is_allowed(
            f"{token_type}:{user_id}", max_requests=max_requests
        ):
            self.logger.warning(f"{token_type}令牌生成速率超限: {user_id}")
            raise RateLimitExceeded("请求过于频繁，请稍后再试")

    def _create_session(self, user_id: str, context: SecurityContext) -> tuple:
        now = int(time.time())
        session_id = secrets.token_hex(self.config.session_id_length // 2)

        if self.token_store is not None:
            success, error_msg = self.token_store.track_session(
                user_id, session_id, context,
                self.max_concurrent_sessions,
                self.reject_ip_change,
            )

            if not success:
                raise ConcurrentSessionLimit(error_msg or "并发会话数超过限制")

        return now, session_id

    def _refill_jti_pool(self):
        """预生成jti池"""
        pool = []
        for _ in range(self._jti_pool_size):
            pool.append(secrets.token_hex(self.config.access_token_jti_length // 2))
        self._jti_pool = pool

    def _get_jti(self) -> str:
        """从池中获取jti，池空时自动补充"""
        if not self._jti_pool:
            self._refill_jti_pool()
        return self._jti_pool.pop()

    def _create_access_token_payload(
        self, user_id: str, now: int, session_id: str, context: SecurityContext
    ) -> TokenPayload:
        extra = getattr(context, '_extra_claims', None) or {}
        return TokenPayload(
            sub=user_id,
            jti=self._get_jti(),
            iat=now,
            exp=now + self.access_token_ttl,
            nbf=now,
            type=TokenType.ACCESS.value,
            iss=self.issuer,
            aud=self.audience,
            sid=session_id,
            dfp=context.device_fingerprint,
            ip=context.ip_address,
            extra=extra,
        )

    def _detect_anomalies(
        self, user_id: str, context: SecurityContext, token_type: str
    ) -> None:
        if self.anomaly_detector is None:
            return
        security_event = SecurityEvent(
            event_type="TOKEN_ISSUED",
            user_id=user_id,
            timestamp=time.time(),
            ip_address=context.ip_address,
            device_fingerprint=context.device_fingerprint,
            details={"token_type": token_type},
        )
        anomalies = self.anomaly_detector.detect_all_anomalies(
            user_id, "TOKEN_ISSUED", context.ip_address, context.device_fingerprint
        )

        if anomalies:
            self.logger.warning(
                f"检测到安全异常: user={user_id}, anomalies={[a.description for a in anomalies]}"
            )
            if self.audit_logger:
                for anomaly in anomalies:
                    self.async_processor.submit_task(
                        self.audit_logger.log_security_event,
                        f"ANOMALY_{anomaly.anomaly_type}",
                        user_id,
                        context.ip_address,
                        {
                            "severity": anomaly.severity,
                            "confidence": anomaly.confidence,
                            "description": anomaly.description,
                        },
                    )

            # 记录异常到监控
            for anomaly in anomalies:
                self.monitoring.record_anomaly(
                    anomaly.anomaly_type, anomaly.severity, anomaly.confidence
                )

    def _log_token_issued(
        self, user_id: str, jti: str, token_type: str, context: SecurityContext
    ) -> None:
        """
        记录令牌发行日志
        """
        if self.audit_logger:
            self.async_processor.submit_task(
                self.audit_logger.log_token_issued,
                user_id,
                jti,
                token_type,
                context.ip_address,
                context.device_fingerprint,
            )

    def _register_token_for_rotation(
        self, token: str, token_type: str, user_id: str, issued_at: int, expires_at: int
    ) -> None:
        if self.token_rotator is None:
            return
        self.token_rotator.register_token(
            token=token,
            token_type=token_type,
            user_id=user_id,
            issued_at=issued_at,
            expires_at=expires_at,
        )

    def generate_refresh_token(self, user_id: str, context: SecurityContext) -> str:
        if not self.rate_limiter.is_allowed(
            f"refresh:{user_id}", max_requests=self.config.max_refresh_per_minute
        ):
            self.logger.warning(f"刷新令牌生成速率超限: {user_id}")
            raise RateLimitExceeded("请求过于频繁，请稍后再试")

        now = int(time.time())
        token_jti = self._get_jti()

        payload = {
            "sub": user_id,
            "jti": token_jti,
            "iat": now,
            "exp": now + self.refresh_token_ttl,
            "nbf": now,
            "type": TokenType.REFRESH.value,
            "iss": self.issuer,
            "aud": self.audience,
            "sid": secrets.token_hex(self.config.session_id_length // 2),
            "dfp": context.device_fingerprint,
            "ip": context.ip_address,
        }

        token = self._create_jwt(payload)

        # 存储刷新令牌
        if self.token_store:
            self.token_store.store_refresh_token(
                user_id,
                token_jti,
                now + self.refresh_token_ttl,
                context,
                max_usage=getattr(self.config, "max_refresh_token_usage", 10),
            )

        if self.audit_logger:
            self.async_processor.submit_task(
                self.audit_logger.log_token_issued,
                user_id,
                token_jti,
                TokenType.REFRESH.value,
                context.ip_address,
                context.device_fingerprint,
            )

        self.metrics["token_generated"] += 1
        self.logger.debug(f"刷新令牌已生成: user={user_id}, jti={token_jti}")
        return token

    def _create_jwt(self, payload: Dict[str, Any]) -> str:
        algorithm = getattr(self, 'algorithm', 'RS256')
        header = {"alg": algorithm, "typ": "JWT"}

        kid = getattr(self.key_manager, 'current_key_id', None)
        if kid:
            header["kid"] = kid

        header_b64 = self.codec.encode(header)
        payload_b64 = self.codec.encode(payload)

        message = f"{header_b64}.{payload_b64}"

        if algorithm == 'HS256':
            import hmac as hmac_mod
            secret = self.key_manager.hmac_secret
            if isinstance(secret, str):
                secret = secret.encode()
            signature = hmac_mod.new(
                secret,
                message.encode(),
                hashlib.sha256,
            ).digest()
        else:
            signature = self.key_manager.private_key.sign(
                message.encode(),
                padding.PKCS1v15(),
                hashes.SHA256()
            )
        signature_b64 = base64.urlsafe_b64encode(signature).decode().rstrip("=")

        return f"{message}.{signature_b64}"

    def _decode_token(self, token: str, verify: bool = True) -> Dict[str, Any]:
        try:
            parts = token.split(".")
            if len(parts) != 3:
                raise InvalidTokenError("Invalid token format")

            if verify and not self._verify_signature(token):
                raise InvalidTokenError("Invalid token signature")

            payload = self.codec.decode(parts[1])
            return payload
        except InvalidTokenError:
            raise
        except Exception as e:
            raise InvalidTokenError(f"Token decode error: {e}") from e

    def _verify_signature(self, token: str) -> bool:
        """验证 JWT 签名"""
        try:
            parts = token.split(".")
            if len(parts) != 3:
                return False

            message = f"{parts[0]}.{parts[1]}"
            signature = base64.urlsafe_b64decode(parts[2] + "==")

            header = self.codec.decode(parts[0])
            algorithm = header.get('alg', 'RS256')

            expected_alg = getattr(self, 'algorithm', 'RS256')
            if algorithm != expected_alg:
                return False

            if algorithm == 'HS256':
                import hmac as hmac_mod
                secret = self.key_manager.hmac_secret
                if isinstance(secret, str):
                    secret = secret.encode()
                expected = hmac_mod.new(
                    secret,
                    message.encode(),
                    hashlib.sha256,
                ).digest()
                return hmac_mod.compare_digest(signature, expected)

            try:
                self.key_manager.public_key.verify(
                    signature, message.encode(),
                    padding.PKCS1v15(),
                    hashes.SHA256()
                )
                return True
            except InvalidSignature:
                pass

            for old_key in self.key_manager.old_public_keys:
                try:
                    old_key.verify(
                        signature, message.encode(), padding.PKCS1v15(),
                        hashes.SHA256()
                    )
                    return True
                except InvalidSignature:
                    continue

            return False
        except Exception:
            return False

    def _parse_and_validate_token(
        self, token: str, expected_type: TokenType
    ) -> TokenPayload:
        payload = self._decode_token(token, verify=True)

        if payload.get("type") != expected_type.value:
            raise InvalidTokenError(
                f"Invalid token type, expected {expected_type.value}"
            )

        if payload.get("exp", 0) < time.time() - self.config.get('jwt_clock_skew', 30):
            raise TokenExpiredError("Token has expired")

        if payload.get("nbf", 0) > time.time() + self.config.get('jwt_clock_skew', 30):
            raise InvalidTokenError("Token not yet valid")

        expected_iss = self.issuer
        if expected_iss and payload.get("iss") != expected_iss:
            raise InvalidTokenError(f"Invalid token issuer: expected {expected_iss}")

        expected_aud = self.audience
        if expected_aud and payload.get("aud") != expected_aud:
            raise InvalidTokenError(f"Invalid token audience: expected {expected_aud}")

        if self.token_store and self.token_store.is_blacklisted(payload.get("jti")):
            raise InvalidTokenError("Token has been revoked")

        return TokenPayload.from_dict(payload)

    def refresh_access_token(
        self, refresh_token: str, context: SecurityContext
    ) -> Tuple[str, str]:
        """
        刷新访问令牌

        Returns:
            Tuple[str, str]: (新访问令牌, 新刷新令牌)
        """
        if self.lock_manager:
            lock = self.lock_manager.get_lock(f"refresh:{refresh_token}", lock_timeout=10)
            if not lock.acquire():
                raise SecurityException("无法获取刷新锁")
        else:
            lock = None

        try:
            payload = self._parse_and_validate_token(refresh_token, TokenType.REFRESH)
            user_id = payload.sub
            token_jti = payload.jti

            # 验证刷新令牌
            refresh_data = self.token_store.get_refresh_token(user_id, token_jti)
            if not refresh_data:
                self.logger.warning(
                    f"刷新令牌不存在或已撤销: {user_id}, jti={token_jti}"
                )
                raise InvalidTokenError("刷新令牌无效")

            # 检查设备指纹
            if payload.dfp and payload.dfp != context.device_fingerprint:
                self.logger.warning(f"Refresh token device fingerprint mismatch: {user_id}")
                raise SecurityException("设备验证失败")

            # 增加使用次数
            if not self.token_store.increment_refresh_usage(user_id, token_jti):
                self.logger.warning(f"刷新令牌使用次数超限: {user_id}, jti={token_jti}")
                raise InvalidTokenError("刷新令牌已用完")

            # 生成新令牌
            user_name = f"User_{user_id}"
            new_access_token = self.generate_access_token(user_id, user_name, context)
            new_refresh_token = self.generate_refresh_token(user_id, context)

            # 将旧刷新令牌加入黑名单
            self.token_store.add_to_blacklist(token_jti, payload.exp)
            self.token_store.revoke_refresh_token(user_id, token_jti)

            if self.audit_logger:
                self.async_processor.submit_task(
                    self.audit_logger.log_token_refreshed,
                    user_id,
                    token_jti,
                    f"jti={token_jti}",
                    context.ip_address,
                    context.device_fingerprint,
                )

            self.metrics["token_refreshed"] += 1
            self.logger.debug(f"Token 刷新成功: user={user_id}, old_jti={token_jti}")

            return new_access_token, new_refresh_token
        finally:
            lock.release()

    def validate_access_token(
        self,
        token: str,
        context: Optional[SecurityContext] = None,
        check_renewal: bool = True,
    ) -> Tuple[TokenPayload, Optional[str]]:
        """
        验证访问令牌

        Returns:
            Tuple[TokenPayload, Optional[str]]: (payload, 新token或None)
        """
        start_time = time.time()
        try:
            # 优先从缓存获取
            cached_payload = self._get_cached_token(token)
            if cached_payload:
                self.metrics["cache_hit"] += 1

                if self.token_store.is_blacklisted(cached_payload.jti):
                    cache_key = self._get_cache_key(token)
                    self.token_cache.delete(cache_key)
                    raise InvalidTokenError("Token has been revoked")

                if cached_payload.exp <= time.time():
                    cache_key = self._get_cache_key(token)
                    self.token_cache.delete(cache_key)
                else:
                    self.token_rotator.record_token_usage(token) if self.token_rotator else None

                    if context and cached_payload.dfp and context.device_fingerprint:
                        if cached_payload.dfp != context.device_fingerprint:
                            self.logger.warning(f"Device fingerprint mismatch: user={cached_payload.sub}")
                            self.metrics["token_validation_failed"] += 1
                            raise SecurityException("设备验证失败")

                    new_token = None
                    if check_renewal and cached_payload.is_expiring_soon():
                        self.logger.debug(f"Token即将过期，建议续约: user={cached_payload.sub}")

                    if self.token_rotator and self.token_rotator.should_rotate(token, {"has_risk": False}):
                        self.logger.info(f"触发令牌自动轮换: user={cached_payload.sub}")
                        rotated_token, _ = self.token_rotator.rotate_token(
                            token, {"has_risk": False}
                        )
                        if rotated_token:
                            new_token = rotated_token

                    duration = time.time() - start_time
                    if self.monitoring:
                        self.monitoring.record_token_validated("cache", duration)
                    return cached_payload, new_token

            # 缓存未命中，进行完整验证
            self.metrics["cache_miss"] += 1
            payload = self._parse_and_validate_token(token, TokenType.ACCESS)

            if self.token_store.is_user_token_revoked(payload.sub, payload.iat):
                raise InvalidTokenError("User tokens have been revoked")

            self._cache_token(token, payload)

            # 记录令牌使用
            self.token_rotator.record_token_usage(token) if self.token_rotator else None

            if context and payload.dfp and context.device_fingerprint and payload.dfp != context.device_fingerprint:
                self.logger.warning(f"设备指纹不匹配: user={payload.sub}")
                self.metrics["token_validation_failed"] += 1
                raise SecurityException("设备验证失败")

            new_token = None
            if check_renewal and payload.is_expiring_soon():
                self.logger.debug(f"Token即将过期，建议续约: user={payload.sub}")

            # 检查是否需要自动轮换令牌
            if self.token_rotator and self.token_rotator.should_rotate(token, {"has_risk": False}):
                self.logger.info(f"Token auto-rotation triggered: user={payload.sub}")
                rotated_token, _ = self.token_rotator.rotate_token(
                    token, {"has_risk": False}
                )
                if rotated_token:
                    new_token = rotated_token

            duration = time.time() - start_time
            if self.monitoring:
                self.monitoring.record_token_validated("full", duration)
            return payload, new_token
        except Exception as e:
            self.metrics["token_validation_failed"] += 1
            duration = time.time() - start_time
            if self.monitoring:
                self.monitoring.record_token_validated("failed", duration)
            raise

    def renew_token_if_needed(
        self, token: str, context: SecurityContext, threshold_ratio: float = 0.2
    ) -> Tuple[TokenPayload, Optional[str]]:
        """
        如果Token即将过期，自动续约

        Returns:
            Tuple[TokenPayload, Optional[str]]: (payload, 新token或None)
        """
        payload = self._parse_and_validate_token(token, TokenType.ACCESS)

        if payload.is_expiring_soon(threshold_ratio):
            user_name = f"User_{payload.sub}"
            new_token = self.generate_access_token(payload.sub, user_name, context)

            self.token_store.add_to_blacklist(payload.jti, payload.exp)

            if self.audit_logger:
                self.async_processor.submit_task(
                    self.audit_logger.log_token_refreshed,
                    payload.sub,
                    payload.jti,
                    new_token[:32],
                    context.ip_address,
                    context.device_fingerprint,
                )

            new_payload, _ = self._parse_and_validate_token(new_token, TokenType.ACCESS)
            return new_payload, new_token

        return payload, None

    def revoke_token(self, token: str, reason: str = "user_logout") -> None:
        try:
            payload = self._decode_token(token, verify=True)
            self.token_store.add_to_blacklist(payload["jti"], payload["exp"])

            if payload.get("type") == TokenType.REFRESH.value:
                self.token_store.revoke_refresh_token(payload["sub"], payload["jti"])

            if self.audit_logger:
                self.async_processor.submit_task(
                    self.audit_logger.log_token_revoked,
                    payload["sub"],
                    payload["jti"],
                    reason,
                    "unknown",
                )

            self.metrics["token_revoked"] += 1
            self.logger.debug(f"Token 已撤销: jti={payload['jti']}, reason={reason}")
        except InvalidTokenError:
            raise
        except Exception as e:
            self.logger.error(f"撤销 Token 失败: {e}")
            raise RuntimeError(f"Token revocation failed: {e}") from e

    def revoke_all_user_tokens(
        self, user_id: str, reason: str = "security_reset"
    ) -> None:
        self.token_store.revoke_all_user_refresh_tokens(user_id)
        self.token_store.set_user_revocation_timestamp(user_id)

        if self.audit_logger:
            self.async_processor.submit_task(
                self.audit_logger.log_security_event,
                "ALL_TOKENS_REVOKED",
                user_id,
                "unknown",
                {"reason": reason},
            )

        self.logger.debug(f"用户所有 Token 已撤销: {user_id}")

    def rotate_signing_keys(self) -> None:
        self.logger.info("开始轮换签名密钥...")

        if self.key_manager.public_key:
            self.key_manager.old_public_keys.append(self.key_manager.public_key)
            if len(self.key_manager.old_public_keys) > 2:
                self.key_manager.old_public_keys.pop(0)

        old_kid = getattr(self.key_manager, 'current_key_id', None)
        self.key_manager.generate_keypair()

        if self.token_store:
            try:
                self.token_store.add_to_blacklist(f"rotated_from:{old_kid}", int(time.time()) + 86400)
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)

        # 保存新密钥
        if self.persist_keys:
            private_path = PathConstants.PRIVATE_KEY_FILE
            public_path = PathConstants.PUBLIC_KEY_FILE
            PathConstants.ensure_keys_dir()
            self.key_manager.save_to_files(private_path, public_path)

        if self.audit_logger:
            self.async_processor.submit_task(
                self.audit_logger.log_security_event,
                "KEY_ROTATION",
                "system",
                "system",
                {},
            )

        self.logger.info("签名密钥已轮换")

    def shutdown(self) -> None:
        if self.async_processor is not None:
            self.async_processor.stop()
        if self.cleanup_manager is not None:
            self.cleanup_manager.stop()
        if self.token_store is not None:
            self.token_store.stop_cleaner()
        if self.audit_log_storage is not None:
            self.audit_log_storage.close()
        if self.monitoring is not None:
            self.monitoring.stop()
        self.logger.info("JWTAuthManager shutdown")

    def get_metrics(self) -> Dict[str, int]:
        """
        获取监控指标
        """
        return self.metrics

    def get_cache_stats(self) -> Dict[str, Any]:
        """
        获取缓存统计信息

        Returns:
            缓存统计信息字典
        """
        return self.token_cache.get_stats()

    def assign_user_role(self, user_id: str, role: str) -> None:
        """
        为用户分配角色

        Args:
            user_id: 用户 ID
            role: 角色名称
        """
        from kewe.security.rbac_manager import Role

        role_enum = Role(role)
        self.rbac_manager.assign_role_to_user(user_id, role_enum)

    def remove_user_role(self, user_id: str, role: str) -> None:
        """
        移除用户的角色

        Args:
            user_id: 用户 ID
            role: 角色名称
        """
        from kewe.security.rbac_manager import Role

        role_enum = Role(role)
        self.rbac_manager.remove_role_from_user(user_id, role_enum)

    def _rotate_token_callback(
        self, old_token: str, context: Dict[str, Any]
    ) -> Tuple[str, str]:
        try:
            payload = self._decode_token(old_token, verify=True)
            if not payload or not payload.get("sub"):
                return "", ""
            
            user_id = payload.get("sub", "")
            user_name = payload.get("name", "")
            
            if not user_id:
                return "", ""
            
            security_ctx = SecurityContext(
                ip_address=context.get("ip_address", "0.0.0.0"),
                user_agent=context.get("user_agent", ""),
                device_fingerprint=context.get("device_fingerprint"),
            )
            
            new_access = self.generate_access_token(user_id, user_name, security_ctx)
            new_refresh = self.generate_refresh_token(user_id, security_ctx)
            
            return new_access, new_refresh
        except Exception as e:
            self.logger.error(f"Token rotation failed: {e}")
            return "", ""

    @property
    def access_token_ttl(self) -> int:
        """访问令牌过期时间"""
        val = self.config.get('access_token_ttl')
        if val is not None:
            return val
        return self.config.get('jwt_expiration_delta', 3600)

    @property
    def refresh_token_ttl(self) -> int:
        """刷新令牌过期时间"""
        val = self.config.get('refresh_token_ttl')
        if val is not None:
            return val
        return self.config.get('refresh_expiration_delta', 604800)

    @property
    def issuer(self) -> str:
        """JWT 签发者"""
        val = self.config.get('jwt_issuer')
        if val is not None:
            return val
        return "kewe-server"

    @property
    def audience(self) -> str:
        """JWT 受众"""
        val = self.config.get('jwt_audience')
        if val is not None:
            return val
        return "kewe-client"

    @property
    def max_concurrent_sessions(self) -> int:
        """最大并发会话数"""
        return self.config.get('max_concurrent_sessions', 5)

    @property
    def reject_ip_change(self) -> bool:
        """是否拒绝 IP 变化"""
        return self.config.get('reject_ip_change', False)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.shutdown()
        return False

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.shutdown()
        return False


JWTAuthManager.verify_token = JWTAuthManager.decode_token


__all__ = [
    'TokenType',
    'TokenStatus',
    'JWTAlgorithm',
    'PathConstants',
    'SecurityException',
    'TokenExpiredError',
    'InvalidTokenError',
    'RateLimitExceeded',
    'ConcurrentSessionLimit',
    'JWTEncoder',
    'RSAKeyManager',
    'TokenPayload',
    'SecurityContext',
    'JWTAuthManager',
]
