#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Kewe 路由模块 - Routing Module
提供高性能的 URL 路由匹配

功能：
- URL 路由匹配
- 参数类型转换和验证
- 蓝图支持
- 路由缓存
- 类视图
- URL 构建
"""

from kewe.routing.router import Router, Route, Blueprint as RouterBlueprint
from kewe.routing.converter import (
    ParameterConverter,
    ParameterValidator,
    ValidationError,
    register_converter,
    convert_parameter,
    parse_path_pattern,
)
from kewe.routing.blueprints import Blueprint, RouteType, RouteDefinition, MiddlewareDefinition, ExceptionHandlerDefinition
from kewe.routing.blueprint_group import BlueprintGroup, group
from kewe.routing.views import HTTPMethodView, View, method_decorator
from kewe.routing.url import URL, URLBuilder, url_for, safe_url, url_decode

__all__ = [
    'Router',
    'Route',
    'RouterBlueprint',
    'ParameterConverter',
    'ParameterValidator',
    'ValidationError',
    'register_converter',
    'convert_parameter',
    'parse_path_pattern',
    'Blueprint',
    'RouteType',
    'RouteDefinition',
    'MiddlewareDefinition',
    'ExceptionHandlerDefinition',
    'BlueprintGroup',
    'group',
    'HTTPMethodView',
    'View',
    'method_decorator',
    'URL',
    'URLBuilder',
    'url_for',
    'safe_url',
    'url_decode',
]
