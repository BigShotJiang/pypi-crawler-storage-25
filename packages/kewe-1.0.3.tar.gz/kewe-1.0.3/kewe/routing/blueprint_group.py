#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
蓝图组 - Blueprint Groups
blueprint_group.py实现，提供蓝图分组管理

功能：
- 蓝图分组和嵌套
- 共享配置和中间件
- 名称前缀
- 版本控制
"""
from typing import List, Optional, Dict, Any, Callable, Union, Tuple
import logging

from kewe.routing.blueprints import Blueprint

logger = logging.getLogger(__name__)


class BlueprintGroup:
    """
    蓝图组
    
    用于将多个蓝图组织在一起，共享相同的配置前缀
    
    使用示例:
        # 方式1：直接创建
        api_v1 = BlueprintGroup(url_prefix='/api/v1', version='v1')
        api_v1.add_blueprint(users_bp)
        api_v1.add_blueprint(posts_bp)
        app.register_blueprint_group(api_v1)
        
        # 方式2：使用 group 函数
        api = group(users_bp, posts_bp, url_prefix='/api/v1')
        app.register_blueprint_group(api)
        
        # 方式3：嵌套分组
        v1 = BlueprintGroup(url_prefix='/v1')
        v2 = BlueprintGroup(url_prefix='/v2')
        api = BlueprintGroup(url_prefix='/api')
        api.add_blueprint_group(v1)
        api.add_blueprint_group(v2)
    """
    
    def __init__(
        self,
        url_prefix: str = "",
        version: Optional[str] = None,
        strict_slashes: bool = False,
        name_prefix: Optional[str] = None,
        host: Optional[str] = None,
        **kwargs
    ):
        """
        初始化蓝图组
        
        Args:
            url_prefix: URL前缀
            version: API版本
            strict_slashes: 是否严格匹配斜杠
            name_prefix: 名称前缀（用于路由命名）
            host: 主机名限制
            **kwargs: 其他配置
        """
        self.url_prefix = url_prefix.rstrip('/')
        self.version = version
        self.strict_slashes = strict_slashes
        self.name_prefix = name_prefix
        self.host = host
        self.extra_options = kwargs
        
        self._blueprints: List[Blueprint] = []
        self._groups: List['BlueprintGroup'] = []
        self._middlewares: List[Dict[str, Any]] = []
        self._error_handlers: Dict[int, Callable] = {}
        self._listeners: Dict[str, List[Callable]] = {}
    
    def add_blueprint(
        self,
        blueprint: Blueprint,
        url_prefix: Optional[str] = None,
        **options
    ):
        """
        添加蓝图到组
        
        Args:
            blueprint: 蓝图实例
            url_prefix: 可选的URL前缀（覆盖组的前缀）
            **options: 其他选项
        """
        blueprint._group_options = {
            'url_prefix': url_prefix,
            'options': options
        }
        self._blueprints.append(blueprint)
        logger.debug(f"Added blueprint '{blueprint.name}' to group")
        return self
    
    def add_blueprint_group(
        self,
        group: 'BlueprintGroup',
        url_prefix: Optional[str] = None
    ):
        """
        添加嵌套蓝图组
        
        Args:
            group: 蓝图组实例
            url_prefix: 可选的URL前缀
        """
        group._parent_options = {
            'url_prefix': url_prefix
        }
        self._groups.append(group)
        logger.debug(f"Added blueprint group to group")
        return self
    
    def middleware(self, func: Callable = None, attach_to: str = "request"):
        """
        注册组级中间件
        
        应用到组内所有蓝图
        
        Args:
            func: 中间件函数
            attach_to: 附加到 'request' 或 'response'
        """
        def decorator(f):
            self._middlewares.append({
                'handler': f,
                'attach_to': attach_to
            })
            return f
        
        if func is None:
            return decorator
        return decorator(func)
    
    def exception(self, status_code_or_type):
        """
        注册组级异常处理器

        支持两种模式:
            1. 按状态码: @group.exception(404)
            2. 按异常类型: @group.exception(ValueError)

        应用到组内所有蓝图
        """
        def decorator(func: Callable):
            self._error_handlers[status_code_or_type] = func
            return func
        return decorator
    
    def listener(self, event: str):
        """
        注册组级监听器
        
        Args:
            event: 事件名称 (before_server_start, after_server_start, etc.)
        """
        def decorator(func: Callable):
            if event not in self._listeners:
                self._listeners[event] = []
            self._listeners[event].append(func)
            return func
        return decorator
    
    def before_server_start(self, func: Callable):
        """服务器启动前监听器"""
        return self.listener("before_server_start")(func)
    
    def after_server_start(self, func: Callable):
        """服务器启动后监听器"""
        return self.listener("after_server_start")(func)
    
    def before_server_stop(self, func: Callable):
        """服务器停止前监听器"""
        return self.listener("before_server_stop")(func)
    
    def after_server_stop(self, func: Callable):
        """服务器停止后监听器"""
        return self.listener("after_server_stop")(func)
    
    def register(self, app, url_prefix: Optional[str] = None):
        """
        注册蓝图组到应用
        
        Args:
            app: Kewe应用实例
            url_prefix: 可选的URL前缀（覆盖组的前缀）
        """
        group_prefix = (url_prefix or self.url_prefix).rstrip('/')
        
        for mw in self._middlewares:
            app.middleware(mw['handler'], attach_to=mw['attach_to'])
        
        for status_code, handler in self._error_handlers.items():
            app.exception(status_code)(handler)
        
        for event, listeners in self._listeners.items():
            for listener in listeners:
                if hasattr(app, event):
                    getattr(app, event)(listener)
        
        for blueprint in self._blueprints:
            blueprint_prefix = group_prefix
            if hasattr(blueprint, '_group_options'):
                bp_url_prefix = blueprint._group_options.get('url_prefix')
                if bp_url_prefix:
                    blueprint_prefix = f"{group_prefix}{bp_url_prefix}"
            
            if self.strict_slashes and not hasattr(blueprint, 'strict_slashes'):
                blueprint.strict_slashes = self.strict_slashes
            
            if self.name_prefix and not hasattr(blueprint, '_name_prefix'):
                blueprint._name_prefix = self.name_prefix
            
            if self.host and not hasattr(blueprint, 'host'):
                blueprint.host = self.host
            
            app.register_blueprint(blueprint, url_prefix=blueprint_prefix)
        
        for nested_group in self._groups:
            nested_prefix = group_prefix
            if hasattr(nested_group, '_parent_options'):
                parent_prefix = nested_group._parent_options.get('url_prefix', '')
                if parent_prefix:
                    nested_prefix = f"{group_prefix}{parent_prefix}"
            
            nested_group.register(app, url_prefix=nested_prefix)
        
        logger.info(
            f"Registered blueprint group with prefix '{group_prefix}' "
            f"({len(self._blueprints)} blueprints, {len(self._groups)} nested groups)"
        )
    
    def copy(self) -> 'BlueprintGroup':
        """创建蓝图组副本"""
        new_group = BlueprintGroup(
            url_prefix=self.url_prefix,
            version=self.version,
            strict_slashes=self.strict_slashes,
            name_prefix=self.name_prefix,
            host=self.host,
            **self.extra_options
        )
        new_group._blueprints = self._blueprints.copy()
        new_group._groups = self._groups.copy()
        new_group._middlewares = self._middlewares.copy()
        new_group._error_handlers = self._error_handlers.copy()
        new_group._listeners = {k: v.copy() for k, v in self._listeners.items()}
        return new_group
    
    def __iter__(self):
        """迭代蓝图"""
        return iter(self._blueprints)
    
    def __len__(self):
        """蓝图数量"""
        return len(self._blueprints)
    
    def __contains__(self, blueprint: Blueprint):
        """检查是否包含蓝图"""
        return blueprint in self._blueprints
    
    def __add__(self, other: Union['BlueprintGroup', Blueprint]) -> 'BlueprintGroup':
        """合并蓝图组或蓝图"""
        new_group = self.copy()
        if isinstance(other, BlueprintGroup):
            for bp in other._blueprints:
                new_group.add_blueprint(bp)
            for g in other._groups:
                new_group.add_blueprint_group(g)
        elif isinstance(other, Blueprint):
            new_group.add_blueprint(other)
        return new_group
    
    def get_blueprints(self) -> List[Blueprint]:
        """获取所有蓝图"""
        return self._blueprints.copy()
    
    def get_all_blueprints(self) -> List[Tuple[str, Blueprint]]:
        """获取所有蓝图（包括嵌套的）"""
        result = []
        for bp in self._blueprints:
            result.append((self.url_prefix, bp))
        for group in self._groups:
            for prefix, bp in group.get_all_blueprints():
                full_prefix = f"{self.url_prefix}{prefix}"
                result.append((full_prefix, bp))
        return result


def group(
    *blueprints: Union[Blueprint, 'BlueprintGroup'],
    url_prefix: str = "",
    version: Optional[str] = None,
    name_prefix: Optional[str] = None,
    **kwargs
) -> BlueprintGroup:
    """
    快速创建蓝图组
    
    使用示例:
        api = group(
            users_bp,
            posts_bp,
            url_prefix='/api/v1'
        )
        app.register_blueprint_group(api)
        
        # 嵌套分组
        v1 = group(users_bp, posts_bp, url_prefix='/v1')
        v2 = group(comments_bp, url_prefix='/v2')
        api = group(v1, v2, url_prefix='/api')
    
    Args:
        *blueprints: 蓝图实例或蓝图组
        url_prefix: URL前缀
        version: API版本
        name_prefix: 名称前缀
        **kwargs: 其他配置
        
    Returns:
        BlueprintGroup实例
    """
    bp_group = BlueprintGroup(
        url_prefix=url_prefix,
        version=version,
        name_prefix=name_prefix,
        **kwargs
    )
    
    for item in blueprints:
        if isinstance(item, BlueprintGroup):
            bp_group.add_blueprint_group(item)
        elif isinstance(item, Blueprint):
            bp_group.add_blueprint(item)
    
    return bp_group


__all__ = [
    'BlueprintGroup',
    'group',
]
