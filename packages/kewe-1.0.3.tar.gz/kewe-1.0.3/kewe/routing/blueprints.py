#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
蓝图模块 - Blueprint System
Blueprint实现，支持嵌套、中间件、异常处理
"""
import logging
from typing import Callable, Dict, List, Optional, Any, Union, Tuple
from dataclasses import dataclass, field
from enum import Enum

from kewe.middleware import MiddlewarePriority

logger = logging.getLogger(__name__)


class RouteType(Enum):
    """路由类型"""
    HTTP = "http"
    WEBSOCKET = "websocket"


@dataclass
class RouteDefinition:
    """路由定义"""
    path: str
    methods: List[str]
    handler: Callable
    route_type: RouteType = RouteType.HTTP
    middlewares: List[Callable] = field(default_factory=list)
    name: Optional[str] = None
    strict_slashes: bool = False
    stream: bool = False


@dataclass
class MiddlewareDefinition:
    """中间件定义"""
    handler: Callable
    attach_to: str = "request"
    priority: MiddlewarePriority = MiddlewarePriority.NORMAL


@dataclass
class ExceptionHandlerDefinition:
    """异常处理器定义"""
    exception_type: type
    handler: Callable


class Blueprint:
    """
    蓝图 - 模块化路由组织
    Blueprint实现
    
    支持:
    - 嵌套蓝图
    - 蓝图级别中间件
    - 蓝图级别异常处理
    - 静态文件
    - URL前缀
    - 命名空间
    - 主机匹配
    - 协议匹配
    """
    
    def __init__(
        self,
        name: str,
        url_prefix: Optional[str] = None,
        version: Optional[str] = None,
        strict_slashes: bool = False,
        namespace: Optional[str] = None,
        host: Optional[str] = None,
        schemes: Optional[List[str]] = None,
    ):
        self.name = name
        self.url_prefix = url_prefix or ""
        self.version = version
        self.strict_slashes = strict_slashes
        self.namespace = namespace or name
        self.host = host
        self.schemes = schemes or []
        
        self._routes: List[RouteDefinition] = []
        self._websocket_routes: List[RouteDefinition] = []
        self._middlewares: List[MiddlewareDefinition] = []
        self._exception_handlers: List[ExceptionHandlerDefinition] = []
        self._nested_blueprints: List[Tuple['Blueprint', Optional[str]]] = []
        self._static_routes: List[Dict[str, Any]] = []
        self._gateway_routes: List[Dict[str, Any]] = []
        self._startup_handlers: List[Callable] = []
        self._shutdown_handlers: List[Callable] = []
    
    # ========== HTTP路由 ==========
    
    def route(
        self,
        path: str,
        methods: Optional[List[str]] = None,
        name: Optional[str] = None,
        middlewares: Optional[List[Callable]] = None,
        strict_slashes: Optional[bool] = None,
        stream: bool = False,
        dependencies: Optional[List[Callable]] = None,
        tags: Optional[List[str]] = None,
        responses: Optional[Dict] = None,
        **kwargs
    ) -> Callable:
        """路由装饰器"""
        def decorator(func: Callable) -> Callable:
            route = RouteDefinition(
                path=path,
                methods=methods or ["GET"],
                handler=func,
                route_type=RouteType.HTTP,
                middlewares=middlewares or [],
                name=name or func.__name__,
                strict_slashes=strict_slashes if strict_slashes is not None else self.strict_slashes,
                stream=stream
            )
            self._routes.append(route)
            if dependencies:
                func._route_dependencies = dependencies
            if tags:
                func._route_tags = tags
            if responses:
                func._route_responses = responses
            return func
        return decorator
    
    def get(self, path: str, **kwargs) -> Callable:
        """GET路由快捷方式"""
        return self.route(path, methods=["GET"], **kwargs)
    
    def post(self, path: str, **kwargs) -> Callable:
        """POST路由快捷方式"""
        return self.route(path, methods=["POST"], **kwargs)
    
    def put(self, path: str, **kwargs) -> Callable:
        """PUT路由快捷方式"""
        return self.route(path, methods=["PUT"], **kwargs)
    
    def delete(self, path: str, **kwargs) -> Callable:
        """DELETE路由快捷方式"""
        return self.route(path, methods=["DELETE"], **kwargs)
    
    def patch(self, path: str, **kwargs) -> Callable:
        """PATCH路由快捷方式"""
        return self.route(path, methods=["PATCH"], **kwargs)
    
    def head(self, path: str, **kwargs) -> Callable:
        """HEAD路由快捷方式"""
        return self.route(path, methods=["HEAD"], **kwargs)
    
    def options(self, path: str, **kwargs) -> Callable:
        """OPTIONS路由快捷方式"""
        return self.route(path, methods=["OPTIONS"], **kwargs)
    
    # ========== WebSocket路由 ==========
    
    def websocket(
        self,
        path: str,
        name: Optional[str] = None,
        middlewares: Optional[List[Callable]] = None,
        **kwargs
    ) -> Callable:
        """WebSocket路由装饰器"""
        def decorator(func: Callable) -> Callable:
            route = RouteDefinition(
                path=path,
                methods=["WEBSOCKET"],
                handler=func,
                route_type=RouteType.WEBSOCKET,
                middlewares=middlewares or [],
                name=name or func.__name__,
                strict_slashes=False
            )
            self._websocket_routes.append(route)
            return func
        return decorator
    
    # ========== 中间件 ==========
    
    def middleware(
        self,
        func_or_type: Union[Callable, str] = None,
        *,
        attach_to: Optional[str] = None,
        type: Optional[str] = None,
        middleware_type: Optional[str] = None,
        priority: MiddlewarePriority = MiddlewarePriority.NORMAL
    ) -> Callable:
        """
        中间件装饰器 - 与 App.middleware 签名统一

        支持三种调用方式:
            1. @bp.middleware("request") / @bp.middleware("response")
            2. App 风格: @bp.middleware(middleware_type="request")
            3. 旧版兼容: @bp.middleware(attach_to="request")

        注意: 推荐使用 middleware_type 参数替代 type，避免遮蔽 Python 内置 type()。
              type 参数保留用于向后兼容。
        """
        resolved_type = middleware_type or type or attach_to or "onion"

        if callable(func_or_type) and not isinstance(func_or_type, str):
            def decorator(f: Callable) -> Callable:
                mw = MiddlewareDefinition(
                    handler=f,
                    attach_to=resolved_type,
                    priority=priority
                )
                self._middlewares.append(mw)
                return f
            return decorator(func_or_type)

        if isinstance(func_or_type, str):
            resolved_type = func_or_type

        def decorator(func: Callable) -> Callable:
            mw = MiddlewareDefinition(
                handler=func,
                attach_to=resolved_type,
                priority=priority
            )
            self._middlewares.append(mw)
            return func
        return decorator
    
    def on_request(self, func: Callable = None, *, priority: MiddlewarePriority = MiddlewarePriority.NORMAL) -> Callable:
        """
        请求中间件装饰器 - 
        
        使用示例:
            @bp.on_request
            async def check_auth(request):
                if request.path.startswith("/admin"):
                    token = request.headers.get("Authorization")
                    if not token:
                        raise Unauthorized("Missing token")
        """
        def decorator(f: Callable) -> Callable:
            mw = MiddlewareDefinition(
                handler=f,
                attach_to="request",
                priority=priority
            )
            self._middlewares.append(mw)
            return f
        
        if func is not None:
            return decorator(func)
        return decorator
    
    def on_response(self, func: Callable = None, *, priority: MiddlewarePriority = MiddlewarePriority.NORMAL) -> Callable:
        """
        响应中间件装饰器 - 
        
        使用示例:
            @bp.on_response
            async def add_headers(request, response):
                response.headers["X-API-Version"] = "1.0"
        """
        def decorator(f: Callable) -> Callable:
            mw = MiddlewareDefinition(
                handler=f,
                attach_to="response",
                priority=priority
            )
            self._middlewares.append(mw)
            return f
        
        if func is not None:
            return decorator(func)
        return decorator

    # ========== 异常处理 ==========
    
    def exception(self, status_code_or_type) -> Callable:
        """
        异常处理器装饰器

        支持两种模式:
            1. 按状态码: @bp.exception(404)
            2. 按异常类型: @bp.exception(ValidationError)

        使用示例:
            @bp.exception(404)
            async def handle_not_found(request, exception):
                return json({"error": "Not found"}, status=404)

            @bp.exception(ValidationError)
            async def handle_validation_error(request, exception):
                return json({"error": str(exception)}, status=400)
        """
        def decorator(func: Callable) -> Callable:
            if isinstance(status_code_or_type, int):
                from kewe.errors.exceptions import KeweException

                class _CodeException(KeweException):
                    status_code = status_code_or_type

                _CodeException.__name__ = f"HTTP{status_code_or_type}"
                _CodeException.__qualname__ = f"HTTP{status_code_or_type}"
                handler = ExceptionHandlerDefinition(
                    exception_type=_CodeException,
                    handler=func
                )
            else:
                handler = ExceptionHandlerDefinition(
                    exception_type=status_code_or_type,
                    handler=func
                )
            self._exception_handlers.append(handler)
            return func
        return decorator

    def register_error_handler(self, code_or_exception, handler: Callable):
        """非装饰器方式注册异常处理器

        用法:
            bp.register_error_handler(404, handle_not_found)
            bp.register_error_handler(ValueError, handle_value_error)
        """
        if isinstance(code_or_exception, int):
            from kewe.errors.exceptions import KeweException

            class _CodeException(KeweException):
                status_code = code_or_exception

            _CodeException.__name__ = f"HTTP{code_or_exception}"
            _CodeException.__qualname__ = f"HTTP{code_or_exception}"
            handler_def = ExceptionHandlerDefinition(
                exception_type=_CodeException,
                handler=handler,
            )
        else:
            handler_def = ExceptionHandlerDefinition(
                exception_type=code_or_exception,
                handler=handler,
            )
        self._exception_handlers.append(handler_def)
    
    # ========== 嵌套蓝图 ==========
    
    def register_blueprint(
        self,
        blueprint: 'Blueprint',
        url_prefix: Optional[str] = None
    ) -> 'Blueprint':
        """
        注册嵌套蓝图
        
        使用示例:
            parent = Blueprint("parent", url_prefix="/parent")
            child = Blueprint("child", url_prefix="/child")
            
            parent.register_blueprint(child)
            # 最终路径: /parent/child/...
        """
        self._nested_blueprints.append((blueprint, url_prefix))
        logger.debug(f"Registered nested blueprint: {blueprint.name}")
        return self

    def url_for(self, endpoint: str, **kwargs) -> Optional[str]:
        """在蓝图命名空间内生成 URL

        自动添加蓝图命名空间前缀到 endpoint，然后委托给应用的 router.url_for()。

        使用示例:
            # 蓝图内路由名 "list_users" -> 查找 "api.list_users"
            url = bp.url_for("list_users")
            url = bp.url_for("get_user", user_id=42)

        Args:
            endpoint: 路由端点名（不含蓝图命名空间前缀）
            **kwargs: 路径参数和额外参数

        Returns:
            生成的 URL 字符串，找不到时返回 None
        """
        full_name = f"{self.namespace}.{endpoint}"
        app = self._get_app()
        if app and hasattr(app, 'router') and hasattr(app.router, 'url_for'):
            return app.router.url_for(full_name, **kwargs)
        return None

    def _get_app(self):
        """获取关联的应用实例"""
        from kewe.base.context import get_app_ctx, get_request_ctx
        try:
            app_ctx = get_app_ctx()
            if app_ctx and hasattr(app_ctx, 'app') and app_ctx.app is not None:
                return app_ctx.app
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)
        try:
            req_ctx = get_request_ctx()
            if req_ctx and hasattr(req_ctx, 'request'):
                req = req_ctx.request
                if hasattr(req, 'app') and req.app is not None:
                    return req.app
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)
        if hasattr(self, '_app') and self._app is not None:
            return self._app
        return None
    
    def copy(
        self,
        name: str,
        url_prefix: Optional[str] = None,
        version: Optional[str] = None,
        strict_slashes: Optional[bool] = None,
    ) -> 'Blueprint':
        """基于当前蓝图创建副本"""
        import copy as _copy
        new_bp = Blueprint(
            name=name,
            url_prefix=url_prefix or self.url_prefix,
            version=version or self.version,
            strict_slashes=strict_slashes if strict_slashes is not None else self.strict_slashes,
        )
        new_bp._routes = _copy.deepcopy(self._routes)
        new_bp._websocket_routes = _copy.deepcopy(self._websocket_routes)
        new_bp._middlewares = _copy.deepcopy(self._middlewares)
        new_bp._exception_handlers = _copy.deepcopy(self._exception_handlers)
        new_bp._nested_blueprints = _copy.deepcopy(self._nested_blueprints)
        new_bp._static_routes = _copy.deepcopy(self._static_routes)
        new_bp._gateway_routes = _copy.deepcopy(self._gateway_routes)
        new_bp._startup_handlers = _copy.deepcopy(self._startup_handlers)
        new_bp._shutdown_handlers = _copy.deepcopy(self._shutdown_handlers)
        if hasattr(self, '_after_startup_handlers'):
            new_bp._after_startup_handlers = _copy.deepcopy(self._after_startup_handlers)
        if hasattr(self, '_after_shutdown_handlers'):
            new_bp._after_shutdown_handlers = _copy.deepcopy(self._after_shutdown_handlers)
        return new_bp
    
    @staticmethod
    def group(
        *blueprints: Union['Blueprint', 'BlueprintGroup'],
        url_prefix: str = "",
        version: Optional[str] = None,
        name_prefix: Optional[str] = None,
        **kwargs
    ) -> 'BlueprintGroup':
        """创建蓝图组
        
        使用示例:
            api = Blueprint.group(
                users_bp,
                posts_bp,
                url_prefix='/api/v1'
            )
            app.register_blueprint_group(api)
        """
        from kewe.routing.blueprint_group import group
        return group(*blueprints, url_prefix=url_prefix, version=version,
                     name_prefix=name_prefix, **kwargs)
    
    # ========== 静态文件 ==========
    
    def static(
        self,
        url_prefix: str,
        directory: str,
        **kwargs
    ) -> 'Blueprint':
        """
        注册静态文件路由
        
        使用示例:
            bp.static("/assets", "./assets")
        """
        self._static_routes.append({
            'url_prefix': url_prefix,
            'directory': directory,
            'kwargs': kwargs
        })
        return self
    
    # ========== 网关路由 ==========

    def api_route(
        self,
        path: str,
        methods: Optional[List[str]] = None,
        version: str = "v1",
        require_auth: bool = True,
        rate_limit: Optional[Tuple[int, int]] = None,
        middlewares: Optional[List[Callable]] = None,
        description: str = "",
        name: Optional[str] = None,
        **kwargs
    ) -> Callable:
        def decorator(func: Callable) -> Callable:
            self._gateway_routes.append({
                'path': path,
                'methods': methods or ["GET"],
                'version': version,
                'handler': func,
                'require_auth': require_auth,
                'rate_limit': rate_limit,
                'middlewares': middlewares or [],
                'description': description,
                'name': name or func.__name__,
                'kwargs': kwargs
            })

            route = RouteDefinition(
                path=path,
                methods=methods or ["GET"],
                handler=func,
                route_type=RouteType.HTTP,
                middlewares=middlewares or [],
                name=name or func.__name__,
                strict_slashes=self.strict_slashes,
            )
            self._routes.append(route)
            return func
        return decorator
    
    def api_get(self, path: str, version: str = "v1", require_auth: bool = True,
                rate_limit: Optional[Tuple[int, int]] = None, **kwargs) -> Callable:
        return self.api_route(path, methods=["GET"], version=version,
                              require_auth=require_auth, rate_limit=rate_limit, **kwargs)
    
    def api_post(self, path: str, version: str = "v1", require_auth: bool = True,
                 rate_limit: Optional[Tuple[int, int]] = None, **kwargs) -> Callable:
        return self.api_route(path, methods=["POST"], version=version,
                              require_auth=require_auth, rate_limit=rate_limit, **kwargs)
    
    def api_put(self, path: str, version: str = "v1", require_auth: bool = True,
                rate_limit: Optional[Tuple[int, int]] = None, **kwargs) -> Callable:
        return self.api_route(path, methods=["PUT"], version=version,
                              require_auth=require_auth, rate_limit=rate_limit, **kwargs)
    
    def api_delete(self, path: str, version: str = "v1", require_auth: bool = True,
                   rate_limit: Optional[Tuple[int, int]] = None, **kwargs) -> Callable:
        return self.api_route(path, methods=["DELETE"], version=version,
                              require_auth=require_auth, rate_limit=rate_limit, **kwargs)

    def api_patch(self, path: str, version: str = "v1", require_auth: bool = True,
                  rate_limit: Optional[Tuple[int, int]] = None, **kwargs) -> Callable:
        return self.api_route(path, methods=["PATCH"], version=version,
                              require_auth=require_auth, rate_limit=rate_limit, **kwargs)
    
    # ========== 生命周期事件 ==========
    
    def startup(self, func: Callable) -> Callable:
        self._startup_handlers.append(func)
        return func
    
    def shutdown(self, func: Callable) -> Callable:
        self._shutdown_handlers.append(func)
        return func
    
    def listener(self, event: str):
        def decorator(func: Callable) -> Callable:
            if event == 'before_server_start':
                self._startup_handlers.append(func)
            elif event == 'after_server_start':
                if not hasattr(self, '_after_startup_handlers'):
                    self._after_startup_handlers = []
                self._after_startup_handlers.append(func)
            elif event == 'before_server_stop':
                self._shutdown_handlers.append(func)
            elif event == 'after_server_stop':
                if not hasattr(self, '_after_shutdown_handlers'):
                    self._after_shutdown_handlers = []
                self._after_shutdown_handlers.append(func)
            else:
                raise ValueError(f"Unknown event '{event}'")
            return func
        return decorator
    
    # ========== 注册到应用 ==========
    
    def register(
        self,
        app,
        url_prefix: Optional[str] = None
    ):
        """
        注册蓝图到应用
        
        Args:
            app: Kewe应用实例
            url_prefix: 额外的URL前缀（与蓝图的url_prefix合并）
        """
        self._app = app
        if url_prefix:
            prefix = self._build_path(url_prefix, self.url_prefix)
        else:
            prefix = self.url_prefix
        
        logger.info(f"Registering blueprint '{self.name}' with prefix '{prefix}'")
        
        # 注册HTTP路由
        for route in self._routes:
            full_path = self._build_path(prefix, route.path)
            route_name = f"{self.namespace}.{route.name}" if self.namespace != self.name else f"{self.name}.{route.name}"
            app.router.add_route(
                path=full_path,
                methods=route.methods,
                handler=route.handler,
                middlewares=route.middlewares,
                strict_slashes=route.strict_slashes,
                name=route_name,
                host=self.host,
                schemes=self.schemes if self.schemes else None,
            )
        
        # 注册WebSocket路由
        for route in self._websocket_routes:
            full_path = self._build_path(prefix, route.path)
            # 假设app支持websocket路由
            if hasattr(app, 'add_websocket_route'):
                app.add_websocket_route(
                    path=full_path,
                    handler=route.handler,
                    name=f"{self.namespace}.{route.name}" if self.namespace != self.name else f"{self.name}.{route.name}"
                )
        
        # 注册中间件 - 限定蓝图作用域
        for mw in self._middlewares:
            bp_prefix = prefix
            mw_handler = mw.handler
            mw_attach_to = mw.attach_to

            import inspect as _inspect
            _sig = _inspect.signature(mw_handler)
            _param_count = len([p for p in _sig.parameters.values()
                               if p.default is _inspect.Parameter.empty
                               and p.kind not in (_inspect.Parameter.VAR_POSITIONAL, _inspect.Parameter.VAR_KEYWORD)])

            if mw_attach_to == "onion" and _param_count >= 2:
                class OnionScopedMiddleware:
                    def __init__(self, handler, bp_pref):
                        self._handler = handler
                        self._prefix = bp_pref

                    async def __call__(self, request, call_next):
                        req_path = getattr(request, 'path', '')
                        if not (req_path == self._prefix or req_path.startswith(self._prefix + '/')):
                            return await call_next(request)
                        return await self._handler(request, call_next)

                scoped_handler = OnionScopedMiddleware(mw_handler, bp_prefix)
            elif mw_attach_to in ("request",) or (mw_attach_to == "onion" and _param_count < 2):
                class RequestScopedMiddleware:
                    def __init__(self, handler, bp_pref):
                        self._handler = handler
                        self._prefix = bp_pref

                    async def __call__(self, request, call_next):
                        req_path = getattr(request, 'path', '')
                        if not (req_path == self._prefix or req_path.startswith(self._prefix + '/')):
                            return await call_next(request)
                        if _param_count == 0:
                            result = self._handler()
                        else:
                            result = self._handler(request)
                        if _inspect.isawaitable(result):
                            result = await result
                        from kewe.response.response import Response
                        if isinstance(result, Response):
                            request.ctx._short_circuit_response = result
                            return await call_next(request)
                        if result is False:
                            from kewe.response import json as _json
                            request.ctx._short_circuit_response = _json({"error": "Request rejected by middleware"}, status=403)
                            return await call_next(request)
                        return await call_next(request)

                scoped_handler = RequestScopedMiddleware(mw_handler, bp_prefix)
            else:
                class ResponseScopedMiddleware:
                    def __init__(self, handler, bp_pref):
                        self._handler = handler
                        self._prefix = bp_pref

                    async def __call__(self, request, call_next):
                        response = await call_next(request)
                        req_path = getattr(request, 'path', '')
                        if not (req_path == self._prefix or req_path.startswith(self._prefix + '/')):
                            return response
                        if _param_count <= 1:
                            result = self._handler(response)
                        else:
                            result = self._handler(request, response)
                        if _inspect.isawaitable(result):
                            result = await result
                        from kewe.response.response import Response
                        if isinstance(result, Response):
                            return result
                        return response

                scoped_handler = ResponseScopedMiddleware(mw_handler, bp_prefix)

            from kewe.middleware.core import OnionMiddleware
            app._onion_chain.add(OnionMiddleware(scoped_handler, priority=mw.priority.value if hasattr(mw.priority, 'value') else mw.priority))
        
        # 注册异常处理器 - 限定蓝图作用域
        for handler_def in self._exception_handlers:
            exc_type = handler_def.exception_type
            if isinstance(exc_type, int):
                from kewe.errors.exceptions import KeweException
                status_exc_type = type(
                    f'StatusCode{exc_type}Exception',
                    (KeweException,),
                    {'status_code': exc_type, 'error_code': f'STATUS_{exc_type}'}
                )
                app.middleware_manager.register_error_handler(
                    status_exc_type,
                    handler_def.handler,
                    url_prefix=prefix
                )
                if exc_type not in app.error_handlers:
                    app.error_handlers[exc_type] = handler_def.handler
            else:
                app.middleware_manager.register_error_handler(
                    exc_type,
                    handler_def.handler,
                    url_prefix=prefix
                )

        # 注册静态文件
        for static_def in self._static_routes:
            static_prefix = self._build_path(prefix, static_def['url_prefix'])
            if hasattr(app, 'static'):
                app.static(
                    static_prefix,
                    static_def['directory'],
                    **static_def['kwargs']
                )
        
        if hasattr(app, 'gateway') and app.gateway:
            gateway = app.gateway
            if hasattr(gateway, 'sync_blueprint_routes'):
                gateway.sync_blueprint_routes(
                    blueprint_name=self.name,
                    url_prefix=prefix,
                    routes=self._gateway_routes
                )
            else:
                for route in self._gateway_routes:
                    gateway_path = self._build_path(prefix, route['path'])
                    full_path = f"{getattr(app.config, 'gateway_prefix', '')}{gateway_path}"
                    gateway.route(
                        full_path,
                        method=route['methods'][0] if route['methods'] else "GET",
                        version=route['version'],
                        **route['kwargs']
                    )(route['handler'])
        
        # 注册嵌套蓝图
        for nested_bp, nested_prefix in self._nested_blueprints:
            if nested_prefix:
                parent_prefix = self._build_path(prefix, nested_prefix)
            else:
                parent_prefix = prefix
            nested_bp.register(app, parent_prefix)
        
        # 注册生命周期事件
        for handler in self._startup_handlers:
            if hasattr(app, 'register_listener'):
                app.register_listener('before_server_start', handler)
        
        for handler in self._shutdown_handlers:
            if hasattr(app, 'register_listener'):
                app.register_listener('before_server_stop', handler)
        
        for handler in getattr(self, '_after_startup_handlers', []):
            if hasattr(app, 'register_listener'):
                app.register_listener('after_server_start', handler)
        
        for handler in getattr(self, '_after_shutdown_handlers', []):
            if hasattr(app, 'register_listener'):
                app.register_listener('after_server_stop', handler)
        
        logger.info(f"Blueprint '{self.name}' registered successfully")
    
    def _build_path(self, prefix: str, path: str) -> str:
        """构建完整路径"""
        # 确保前缀以/开头
        if not prefix.startswith('/'):
            prefix = '/' + prefix
        
        # 确保路径以/开头
        if not path.startswith('/'):
            path = '/' + path
        
        # 合并路径
        if prefix.endswith('/') and path.startswith('/'):
            full_path = prefix + path[1:]
        elif not prefix.endswith('/') and not path.startswith('/'):
            full_path = prefix + '/' + path
        else:
            full_path = prefix + path
        
        # 处理版本前缀
        if self.version and not full_path.startswith(f'/v{self.version}'):
            full_path = f'/v{self.version}{full_path}'
        
        return full_path
    
    # ========== 属性访问 ==========
    
    @property
    def routes(self) -> List[RouteDefinition]:
        """获取所有HTTP路由"""
        return self._routes.copy()
    
    @property
    def websocket_routes(self) -> List[RouteDefinition]:
        """获取所有WebSocket路由"""
        return self._websocket_routes.copy()
    
    @property
    def middlewares(self) -> List[MiddlewareDefinition]:
        """获取所有中间件"""
        return self._middlewares.copy()
    
    @property
    def exception_handlers(self) -> List[ExceptionHandlerDefinition]:
        """获取所有异常处理器"""
        return self._exception_handlers.copy()
    
    def __repr__(self) -> str:
        return f"<Blueprint '{self.name}' prefix='{self.url_prefix}'>"


from kewe.routing.blueprint_group import BlueprintGroup


__all__ = [
    'Blueprint',
    'BlueprintGroup',
    'RouteDefinition',
    'RouteType',
    'MiddlewareDefinition',
    'ExceptionHandlerDefinition',
]
