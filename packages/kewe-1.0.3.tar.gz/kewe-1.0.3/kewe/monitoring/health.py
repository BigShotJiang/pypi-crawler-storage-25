#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
@Project ：Kewe
@File    ：health.py
@IDE     ：PyCharm
@Author  ：Kewe Team
@Date    ：2026/04/12

健康检查和指标模块 - 运维监控支持
"""

import asyncio
import logging
import threading
import time
from typing import Dict, Any, List, Callable, Optional
from dataclasses import dataclass, field
from enum import Enum

from kewe.response import json
from kewe import __version__

logger = logging.getLogger(__name__)


class HealthStatus(Enum):
    """健康状态"""
    HEALTHY = "healthy"
    UNHEALTHY = "unhealthy"
    DEGRADED = "degraded"


@dataclass
class HealthCheck:
    """健康检查项"""
    name: str
    status: HealthStatus
    details: Dict[str, Any] = field(default_factory=dict)
    response_time: float = 0.0


@dataclass(slots=True)
class HealthReport:
    """健康报告"""
    status: HealthStatus
    checks: List[HealthCheck] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)
    version: str = field(default_factory=lambda: __version__)
    uptime: float = 0.0


class HealthChecker:
    
    def __init__(self):
        self._checks: Dict[str, Callable] = {}
        self._liveness_checks: Dict[str, Callable] = {}
        self._readiness_checks: Dict[str, Callable] = {}
        self._startup_checks: Dict[str, Callable] = {}
        self._start_time = time.time()
    
    def add_check(self, name: str, check_func: Callable):
        self._checks[name] = check_func
        logger.debug(f"Added health check: {name}")
    
    def add_liveness_check(self, name: str, check_func: Callable):
        self._liveness_checks[name] = check_func
        logger.debug(f"Added liveness check: {name}")
    
    def add_readiness_check(self, name: str, check_func: Callable):
        self._readiness_checks[name] = check_func
        logger.debug(f"Added readiness check: {name}")
    
    def add_startup_check(self, name: str, check_func: Callable):
        self._startup_checks[name] = check_func
        logger.debug(f"Added startup check: {name}")
    
    async def check_liveness(self) -> HealthReport:
        checks = []
        overall_status = HealthStatus.HEALTHY
        all_checks = {**self._checks, **self._liveness_checks}
        for name, check_func in all_checks.items():
            start_time = time.time()
            try:
                if asyncio.iscoroutinefunction(check_func):
                    result = await check_func()
                else:
                    result = check_func()
                response_time = time.time() - start_time
                if isinstance(result, bool):
                    status = HealthStatus.HEALTHY if result else HealthStatus.UNHEALTHY
                    details = {}
                else:
                    status = result.get('status', HealthStatus.HEALTHY)
                    details = result.get('details', {})
                check = HealthCheck(name=name, status=status, details=details, response_time=response_time)
                checks.append(check)
                if status == HealthStatus.UNHEALTHY:
                    overall_status = HealthStatus.UNHEALTHY
            except Exception as e:
                logger.error(f"Liveness check '{name}' failed: {e}")
                checks.append(HealthCheck(name=name, status=HealthStatus.UNHEALTHY, details={"error": str(e)}))
                overall_status = HealthStatus.UNHEALTHY
        return HealthReport(status=overall_status, checks=checks, uptime=time.time() - self._start_time)
    
    async def check_readiness(self) -> HealthReport:
        checks = []
        overall_status = HealthStatus.HEALTHY
        all_checks = {**self._checks, **self._readiness_checks}
        for name, check_func in all_checks.items():
            start_time = time.time()
            try:
                if asyncio.iscoroutinefunction(check_func):
                    result = await check_func()
                else:
                    result = check_func()
                response_time = time.time() - start_time
                if isinstance(result, bool):
                    status = HealthStatus.HEALTHY if result else HealthStatus.UNHEALTHY
                    details = {}
                else:
                    status = result.get('status', HealthStatus.HEALTHY)
                    details = result.get('details', {})
                check = HealthCheck(name=name, status=status, details=details, response_time=response_time)
                checks.append(check)
                if status == HealthStatus.UNHEALTHY:
                    overall_status = HealthStatus.UNHEALTHY
                elif status == HealthStatus.DEGRADED and overall_status == HealthStatus.HEALTHY:
                    overall_status = HealthStatus.DEGRADED
            except Exception as e:
                logger.error(f"Readiness check '{name}' failed: {e}")
                checks.append(HealthCheck(name=name, status=HealthStatus.UNHEALTHY, details={"error": str(e)}))
                overall_status = HealthStatus.UNHEALTHY
        return HealthReport(status=overall_status, checks=checks, uptime=time.time() - self._start_time)
    
    async def check_startup(self) -> HealthReport:
        checks = []
        overall_status = HealthStatus.HEALTHY
        all_checks = {**self._startup_checks}
        for name, check_func in all_checks.items():
            start_time = time.time()
            try:
                if asyncio.iscoroutinefunction(check_func):
                    result = await check_func()
                else:
                    result = check_func()
                response_time = time.time() - start_time
                if isinstance(result, bool):
                    status = HealthStatus.HEALTHY if result else HealthStatus.UNHEALTHY
                    details = {}
                else:
                    status = result.get('status', HealthStatus.HEALTHY)
                    details = result.get('details', {})
                check = HealthCheck(name=name, status=status, details=details, response_time=response_time)
                checks.append(check)
                if status == HealthStatus.UNHEALTHY:
                    overall_status = HealthStatus.UNHEALTHY
            except Exception as e:
                logger.error(f"Startup check '{name}' failed: {e}")
                checks.append(HealthCheck(name=name, status=HealthStatus.UNHEALTHY, details={"error": str(e)}))
                overall_status = HealthStatus.UNHEALTHY
        return HealthReport(status=overall_status, checks=checks, uptime=time.time() - self._start_time)
    
    async def run_checks(self) -> HealthReport:
        """运行所有健康检查（并行执行）"""
        checks = []
        overall_status = HealthStatus.HEALTHY
        
        async def _run_single_check(name, check_func):
            start_time = time.time()
            try:
                if asyncio.iscoroutinefunction(check_func):
                    result = await check_func()
                else:
                    result = check_func()
                
                response_time = time.time() - start_time
                
                if isinstance(result, bool):
                    status = HealthStatus.HEALTHY if result else HealthStatus.UNHEALTHY
                    details = {}
                else:
                    status = result.get('status', HealthStatus.HEALTHY)
                    details = result.get('details', {})
                
                return HealthCheck(
                    name=name,
                    status=status,
                    details=details,
                    response_time=response_time
                )
            except Exception as e:
                logger.error(f"Health check '{name}' failed: {e}")
                return HealthCheck(
                    name=name,
                    status=HealthStatus.UNHEALTHY,
                    details={"error": str(e)}
                )
        
        tasks = [
            _run_single_check(name, check_func)
            for name, check_func in self._checks.items()
        ]
        
        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for result in results:
                if isinstance(result, Exception):
                    checks.append(HealthCheck(
                        name="unknown",
                        status=HealthStatus.UNHEALTHY,
                        details={"error": str(result)}
                    ))
                    overall_status = HealthStatus.UNHEALTHY
                else:
                    checks.append(result)
                    if result.status == HealthStatus.UNHEALTHY:
                        overall_status = HealthStatus.UNHEALTHY
                    elif result.status == HealthStatus.DEGRADED and overall_status == HealthStatus.HEALTHY:
                        overall_status = HealthStatus.DEGRADED
        
        return HealthReport(
            status=overall_status,
            checks=checks,
            uptime=time.time() - self._start_time
        )


class HealthMetricsCollector:
    
    def __init__(self, max_histogram_size: int = 10000):
        from kewe.monitoring.core import MetricsCollector
        self._collector = MetricsCollector()
        self._timers: Dict[str, List[float]] = {}
        self._max_histogram_size = max_histogram_size
        self._lock = threading.Lock()
    
    def increment(self, name: str, value: int = 1, labels: Dict[str, str] = None):
        self._collector.counter(name, value, labels)
    
    def decrement(self, name: str, value: int = 1, labels: Dict[str, str] = None):
        self._collector.counter(name, -value, labels)
    
    def gauge(self, name: str, value: float, labels: Dict[str, str] = None):
        self._collector.gauge(name, value, labels)
    
    def histogram(self, name: str, value: float, labels: Dict[str, str] = None):
        self._collector.histogram(name, value, labels)
    
    def timer(self, name: str, value: float, labels: Dict[str, str] = None):
        self._collector.histogram(name, value, labels)
    
    def get_metrics(self) -> Dict[str, Any]:
        return {
            "counters": {k: sum(v.values()) for k, v in self._collector.counters.items()},
            "gauges": {k: sum(v.values()) for k, v in self._collector.gauges.items()},
            "histograms": {
                k: {
                    "count": sum(len(vv) for vv in v.values()),
                    "sum": sum(sum(vv) for vv in v.values()),
                }
                for k, v in self._collector.histograms.items()
            },
        }
    
    def to_prometheus(self) -> str:
        return self._collector.get_prometheus_metrics()


class HealthEndpoint:
    """健康检查端点"""

    def __init__(self, app, path: str = "/health"):
        self.app = app
        self.path = path
        self.checker = HealthChecker()

        self._register_default_checks()
        self._register_routes()

    def _register_default_checks(self):
        """注册默认健康检查"""
        async def app_check():
            return {
                "status": HealthStatus.HEALTHY,
                "details": {"app_name": self.app.name}
            }
        self.checker.add_check("app", app_check)

    def _register_routes(self):
        """注册路由"""
        existing_methods = set()
        for route in getattr(self.app.router, 'routes', []):
            if hasattr(route, 'path') and route.path == self.path:
                if hasattr(route, 'methods'):
                    existing_methods.update(route.methods)

        if 'GET' not in existing_methods:
            @self.app.get(self.path)
            async def health_check(request):
                report = await self.checker.run_checks()

                status_code = 200
                if report.status == HealthStatus.UNHEALTHY:
                    status_code = 503
                elif report.status == HealthStatus.DEGRADED:
                    status_code = 200

                return json({
                    "status": report.status.value,
                    "checks": [
                        {
                            "name": c.name,
                            "status": c.status.value,
                            "response_time": round(c.response_time, 3),
                            "details": c.details
                        }
                        for c in report.checks
                    ],
                    "uptime": round(report.uptime, 2),
                    "version": report.version
                }, status=status_code)

        ready_path = f"{self.path}/ready"
        ready_exists = any(
            hasattr(r, 'path') and r.path == ready_path
            for r in getattr(self.app.router, 'routes', [])
        )
        if not ready_exists:
            @self.app.get(ready_path)
            async def readiness_check(request):
                report = await self.checker.check_readiness()

                if report.status == HealthStatus.UNHEALTHY:
                    return json({
                        "ready": False,
                        "checks": [
                            {"name": c.name, "status": c.status.value, "details": c.details}
                            for c in report.checks
                        ]
                    }, status=503)

                return json({"ready": True})

        live_path = f"{self.path}/live"
        live_exists = any(
            hasattr(r, 'path') and r.path == live_path
            for r in getattr(self.app.router, 'routes', [])
        )
        if not live_exists:
            @self.app.get(live_path)
            async def liveness_check(request):
                report = await self.checker.check_liveness()

                if report.status == HealthStatus.UNHEALTHY:
                    return json({"alive": False}, status=503)

                return json({"alive": True})

    def add_metrics_endpoint(self, path: str = "/metrics"):
        """添加指标端点 — 委托给 app._metrics_manager"""
        from kewe.monitoring.metrics import add_metrics_endpoint
        add_metrics_endpoint(self.app, path)


# 便捷函数
def setup_health_checks(app, path: str = "/health") -> HealthEndpoint:
    """设置健康检查"""
    return HealthEndpoint(app, path)
