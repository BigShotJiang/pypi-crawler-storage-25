#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
监控模块 - Monitoring
提供完整的可观测性支持

功能：
- Prometheus 指标导出
- OpenTelemetry 集成
- 性能指标收集
- 自定义指标
"""
import logging
import time
import bisect
from typing import Dict, Any, Optional, Callable
from dataclasses import dataclass
from collections import defaultdict, deque
import threading

logger = logging.getLogger(__name__)


@dataclass
class MetricValue:
    """指标值"""
    name: str
    value: float
    labels: Dict[str, str]
    timestamp: float


class MetricsCollector:
    """
    指标收集器 - Prometheus 风格
    """
    
    def __init__(self, app=None):
        self.app = app
        self.counters: Dict[str, Dict[str, float]] = defaultdict(lambda: defaultdict(float))
        self.gauges: Dict[str, Dict[str, float]] = defaultdict(lambda: defaultdict(float))
        self.histograms: Dict[str, Dict[str, deque]] = defaultdict(lambda: defaultdict(lambda: deque(maxlen=self._histogram_max_size)))
        self._histogram_max_size = 10000
        self._default_buckets = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, float('inf'))
        self.lock = threading.Lock()
    
    def counter(self, name: str, value: float = 1, labels: Optional[Dict[str, str]] = None):
        """
        增加计数器
        
        Args:
            name: 指标名称
            value: 增加的值
            labels: 标签
        """
        labels = labels or {}
        label_key = self._labels_to_key(labels)
        
        with self.lock:
            self.counters[name][label_key] += value
    
    def gauge(self, name: str, value: float, labels: Optional[Dict[str, str]] = None):
        """
        设置仪表值
        
        Args:
            name: 指标名称
            value: 值
            labels: 标签
        """
        labels = labels or {}
        label_key = self._labels_to_key(labels)
        
        with self.lock:
            self.gauges[name][label_key] = value
    
    def histogram(self, name: str, value: float, labels: Optional[Dict[str, str]] = None):
        """
        记录直方图值
        
        Args:
            name: 指标名称
            value: 值
            labels: 标签
        """
        labels = labels or {}
        label_key = self._labels_to_key(labels)
        
        with self.lock:
            self.histograms[name][label_key].append(value)
    
    def get_prometheus_metrics(self) -> str:
        """
        获取 Prometheus 格式的指标
        
        Returns:
            Prometheus 格式的指标字符串
        """
        lines = []
        
        # 输出计数器
        for name, label_values in self.counters.items():
            lines.append(f"# TYPE {name} counter")
            for label_key, value in label_values.items():
                labels = self._key_to_labels(label_key)
                label_str = self._format_labels(labels)
                lines.append(f"{name}{label_str} {value}")
        
        # 输出仪表
        for name, label_values in self.gauges.items():
            lines.append(f"# TYPE {name} gauge")
            for label_key, value in label_values.items():
                labels = self._key_to_labels(label_key)
                label_str = self._format_labels(labels)
                lines.append(f"{name}{label_str} {value}")
        
        # 输出直方图
        for name, label_values in self.histograms.items():
            lines.append(f"# TYPE {name} histogram")
            for label_key, values in label_values.items():
                if values:
                    labels = self._key_to_labels(label_key)
                    label_str = self._format_labels(labels)
                    
                    count = len(values)
                    total = sum(values)
                    
                    sorted_values = sorted(values)
                    for bucket in self._default_buckets:
                        if bucket == float('inf'):
                            bucket_count = count
                            if label_str:
                                bucket_label = label_str[:-1] + ',le="+Inf"}'
                            else:
                                bucket_label = '{le="+Inf"}'
                        else:
                            bucket_count = bisect.bisect_right(sorted_values, bucket)
                            if label_str:
                                bucket_label = label_str[:-1] + f',le="{bucket}"}}'
                            else:
                                bucket_label = f'{{le="{bucket}"}}'
                        lines.append(f"{name}_bucket{bucket_label} {bucket_count}")
                    
                    lines.append(f"{name}_count{label_str} {count}")
                    lines.append(f"{name}_sum{label_str} {total}")
        
        return '\n'.join(lines)
    
    def _labels_to_key(self, labels: Dict[str, str]) -> str:
        """将标签转换为键"""
        if not labels:
            return ""
        return ','.join(f"{k}={v}" for k, v in sorted(labels.items()))
    
    def _key_to_labels(self, key: str) -> Dict[str, str]:
        """将键转换为标签"""
        if not key:
            return {}
        labels = {}
        for pair in key.split(','):
            if '=' in pair:
                k, v = pair.split('=', 1)
                labels[k] = v
        return labels
    
    def _format_labels(self, labels: Dict[str, str]) -> str:
        """格式化标签"""
        if not labels:
            return ""
        return '{' + ','.join(f'{k}="{v}"' for k, v in sorted(labels.items())) + '}'


class PerformanceMonitor:
    """
    性能监控器
    """
    
    def __init__(self, app=None):
        """
        初始化性能监控器
        
        Args:
            app: Kewe 应用实例
        """
        self.app = app
        self.metrics = MetricsCollector(app)
        self.request_times: Dict[str, list] = defaultdict(list)
        self._lock = threading.Lock()
        self._active_requests = 0
        self._total_requests = 0
        self._error_requests = 0
    
    def record_request_start(self, method: str, path: str):
        with self._lock:
            self._active_requests += 1
            self._total_requests += 1
        self.metrics.gauge('active_requests', self._active_requests, {'method': method, 'path': path})
        self.metrics.counter('requests_total', labels={'method': method, 'path': path})
    
    def record_request_end(self, method: str, path: str, status: int, duration: float):
        with self._lock:
            self._active_requests -= 1
            if status >= 400:
                self._error_requests += 1
        self.metrics.gauge('active_requests', self._active_requests)
        
        self.metrics.histogram('request_duration_seconds', duration, {
            'method': method,
            'path': path,
            'status': str(status)
        })
        
        self.metrics.counter('responses_total', labels={'method': method, 'path': path, 'status': str(status)})
        
        if status >= 400:
            self.metrics.counter('errors_total', labels={'method': method, 'path': path, 'status': str(status)})
    
    def get_stats(self) -> Dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息字典
        """
        return {
            'total_requests': self._total_requests,
            'active_requests': self._active_requests,
            'error_requests': self._error_requests,
            'error_rate': self._error_requests / self._total_requests if self._total_requests > 0 else 0,
        }


try:
    from kewe.telemetry.otel import OpenTelemetryIntegration
except ImportError:
    class OpenTelemetryIntegration:
        def __init__(self, app=None, service_name: str = "kewe-app"):
            self.app = app
            self.service_name = service_name
            self.tracer = None
            self.meter = None

        def setup(self):
            logger.warning("OpenTelemetry not installed. Install with: pip install opentelemetry-api opentelemetry-sdk")

        def start_span(self, name: str):
            return None

        def record_exception(self, exception: Exception):
            logger.debug(f"Exception recorded (no telemetry): {exception}")


def setup_monitoring(app, service_name: str = "kewe-app"):
    """
    设置监控
    
    Args:
        app: Kewe 应用实例
        service_name: 服务名称
    """
    # 创建性能监控器
    monitor = PerformanceMonitor(app)
    app.monitor = monitor
    
    # 创建 OpenTelemetry 集成
    otel = OpenTelemetryIntegration(app, service_name)
    otel.setup()
    app.otel = otel
    
    # 添加监控中间件
    @app.middleware('request')
    async def monitoring_middleware(request):
        # 记录请求开始
        request._start_time = time.time()
        monitor.record_request_start(request.method, request.path)
        
        # 开始 OpenTelemetry 跨度
        if otel.tracer:
            request._span = otel.start_span(f"{request.method} {request.path}")
    
    @app.middleware('response')
    async def monitoring_response_middleware(request, response):
        # 计算请求时间
        duration = time.time() - getattr(request, '_start_time', time.time())
        
        # 记录请求结束
        monitor.record_request_end(request.method, request.path, response.status, duration)
        
        # 结束 OpenTelemetry 跨度
        if hasattr(request, '_span') and request._span:
            request._span.end()
        
        return response
    
    # 添加指标端点
    @app.get("/metrics")
    async def metrics_handler(request):
        """Prometheus 指标端点"""
        return monitor.metrics.get_prometheus_metrics()
    
    @app.get("/stats")
    async def stats_handler(request):
        """统计信息端点"""
        from kewe.response import json
        return json(monitor.get_stats())


__all__ = [
    'MetricsCollector',
    'PerformanceMonitor',
    'OpenTelemetryIntegration',
    'setup_monitoring',
]

