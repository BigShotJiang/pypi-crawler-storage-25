#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Anomaly Detector"""

import time
from collections import deque
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass

from kewe.logging.logger import get_logger


@dataclass
class SecurityEvent:
    """安全事件"""
    event_type: str
    user_id: str
    timestamp: float
    ip_address: str
    device_fingerprint: Optional[str]
    details: Dict[str, Any]


@dataclass
class Anomaly:
    """异常"""
    anomaly_type: str
    description: str
    severity: str  # low, medium, high
    confidence: float  # 0-1


class AnomalyDetector:

    def __init__(self, max_events: int = 1000, time_window: int = 3600):
        self.max_events = max_events
        self.time_window = time_window
        self.user_events: Dict[str, deque] = {}
        self.ip_events: Dict[str, deque] = {}
        self._last_cleanup: float = 0.0
        self.logger = get_logger(__name__)

    def add_event(self, event: SecurityEvent):
        if event.user_id not in self.user_events:
            self.user_events[event.user_id] = deque(maxlen=self.max_events)
        self.user_events[event.user_id].append(event)

        if event.ip_address not in self.ip_events:
            self.ip_events[event.ip_address] = deque(maxlen=self.max_events)
        self.ip_events[event.ip_address].append(event)

    def detect_all_anomalies(self, user_id: str, event_type: str, ip_address: str, device_fingerprint: Optional[str]) -> List[Anomaly]:
        """
        检测所有异常

        Args:
            user_id: 用户ID
            event_type: 事件类型
            ip_address: IP地址
            device_fingerprint: 设备指纹

        Returns:
            异常列表
        """
        anomalies = []

        now = time.time()
        if now - self._last_cleanup > 60:
            self._cleanup_expired_events()
            self._last_cleanup = now

        # 检测登录频率异常
        frequency_anomaly = self._detect_frequency_anomaly(user_id, event_type)
        if frequency_anomaly:
            anomalies.append(frequency_anomaly)

        # 检测位置异常
        location_anomaly = self._detect_location_anomaly(user_id, ip_address)
        if location_anomaly:
            anomalies.append(location_anomaly)

        # 检测设备异常
        device_anomaly = self._detect_device_anomaly(user_id, device_fingerprint)
        if device_anomaly:
            anomalies.append(device_anomaly)

        return anomalies

    def _cleanup_expired_events(self):
        """清理过期事件"""
        current_time = time.time()
        cutoff_time = current_time - self.time_window

        # 清理用户事件
        for user_id in list(self.user_events.keys()):
            new_events = deque(
                (event for event in self.user_events[user_id]
                 if event.timestamp >= cutoff_time),
                maxlen=self.max_events
            )
            if not new_events:
                del self.user_events[user_id]
            else:
                self.user_events[user_id] = new_events

        for ip_address in list(self.ip_events.keys()):
            new_events = deque(
                (event for event in self.ip_events[ip_address]
                 if event.timestamp >= cutoff_time),
                maxlen=self.max_events
            )
            if not new_events:
                del self.ip_events[ip_address]
            else:
                self.ip_events[ip_address] = new_events

    def _detect_frequency_anomaly(self, user_id: str, event_type: str) -> Optional[Anomaly]:
        """
        检测频率异常

        Args:
            user_id: 用户ID
            event_type: 事件类型

        Returns:
            异常或None
        """
        if user_id not in self.user_events:
            return None

        events = self.user_events[user_id]
        recent_events = [
            event for event in events
            if event.event_type == event_type and event.timestamp > time.time() - 60
        ]

        if len(recent_events) > 5:
            return Anomaly(
                anomaly_type="FREQUENCY",
                description="登录频率过高",
                severity="high",
                confidence=0.9
            )
        elif len(recent_events) > 3:
            return Anomaly(
                anomaly_type="FREQUENCY",
                description="登录频率较高",
                severity="medium",
                confidence=0.7
            )

        return None

    def _detect_location_anomaly(self, user_id: str, ip_address: str) -> Optional[Anomaly]:
        """
        检测位置异常

        Args:
            user_id: 用户ID
            ip_address: IP地址

        Returns:
            异常或None
        """
        if user_id not in self.user_events:
            return None

        events = self.user_events[user_id]
        recent_events = [
            event for event in events
            if event.timestamp > time.time() - 3600
        ]

        # 简单检测：如果最近有不同的IP地址，且时间间隔较短
        if len(recent_events) > 1:
            ip_addresses = set(event.ip_address for event in recent_events)
            if len(ip_addresses) > 1:
                # 检查时间间隔
                events_sorted = sorted(recent_events, key=lambda e: e.timestamp)
                time_diff = events_sorted[-1].timestamp - events_sorted[0].timestamp
                if time_diff < 600:  # 10分钟内
                    return Anomaly(
                        anomaly_type="LOCATION",
                        description="登录位置变化异常",
                        severity="high",
                        confidence=0.8
                    )

        return None

    def _detect_device_anomaly(self, user_id: str, device_fingerprint: Optional[str]) -> Optional[Anomaly]:
        """
        检测设备异常

        Args:
            user_id: 用户ID
            device_fingerprint: 设备指纹

        Returns:
            异常或None
        """
        if not device_fingerprint or user_id not in self.user_events:
            return None

        events = self.user_events[user_id]
        recent_events = [
            event for event in events
            if event.timestamp > time.time() - 3600
        ]

        # 检查是否有不同的设备指纹
        fingerprints = set(event.device_fingerprint for event in recent_events if event.device_fingerprint)
        if len(fingerprints) > 1 and device_fingerprint not in fingerprints:
            return Anomaly(
                anomaly_type="DEVICE",
                description="登录设备变化异常",
                severity="medium",
                confidence=0.7
            )

        return None
