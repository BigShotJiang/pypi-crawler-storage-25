#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
会话管理模块 - Session Management
session实现

提供Session支持、Flash消息、安全加密等功能
"""
import asyncio
from abc import ABC, abstractmethod
from kewe.utils.compat import json
import base64
import hashlib
import hmac
import secrets
import time
from typing import Dict, Any, Optional, Callable
from dataclasses import dataclass, field
from functools import wraps

from kewe.cookies.signed import SignedCookieManager


@dataclass
class SessionConfig:
    secret_key: str = field(default_factory=lambda: secrets.token_hex(32))
    session_cookie_name: str = "session"
    session_cookie_domain: Optional[str] = None
    session_cookie_path: str = "/"
    session_cookie_httponly: bool = True
    session_cookie_secure: bool = True
    session_cookie_samesite: str = "Lax"
    permanent_session_lifetime: int = 3600 * 24 * 31
    session_type: str = "cookie"

    def __init__(self, secret_key: Optional[str] = None,
                 session_cookie_name: str = "session",
                 session_cookie: Optional[str] = None,
                 session_cookie_domain: Optional[str] = None,
                 session_cookie_path: str = "/",
                 session_cookie_httponly: bool = True,
                 session_cookie_secure: bool = True,
                 session_cookie_samesite: str = "Lax",
                 permanent_session_lifetime: int = 3600 * 24 * 31,
                 session_type: str = "cookie"):
        self.secret_key = secret_key or secrets.token_hex(32)
        self.session_cookie_name = session_cookie or session_cookie_name
        self.session_cookie_domain = session_cookie_domain
        self.session_cookie_path = session_cookie_path
        self.session_cookie_httponly = session_cookie_httponly
        self.session_cookie_secure = session_cookie_secure
        self.session_cookie_samesite = session_cookie_samesite
        self.permanent_session_lifetime = permanent_session_lifetime
        self.session_type = session_type


class SessionMixin:
    """Session 混入基类 — Session混入基类

    提供标准化的 modified / new / permanent 属性接口，
    使 isinstance(session, SessionMixin) 检查生效。
    """

    @property
    def modified(self) -> bool:
        return getattr(self, '_modified', False)

    @property
    def new(self) -> bool:
        return getattr(self, '_new', True)

    @new.setter
    def new(self, value: bool):
        self._new = value

    @property
    def permanent(self) -> bool:
        return getattr(self, '_permanent', False)

    @permanent.setter
    def permanent(self, value: bool):
        self._permanent = value


class Session(SessionMixin, dict):
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._modified = False
        self._permanent = False
        self._session_id = secrets.token_hex(16)
        self._new = True
    
    @property
    def session_id(self) -> str:
        return self._session_id
    
    def regenerate_id(self):
        self._session_id = secrets.token_hex(16)
        self._modified = True
    
    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        self._modified = True
    
    def __delitem__(self, key):
        super().__delitem__(key)
        self._modified = True
    
    def pop(self, key, *args):
        self._modified = True
        return super().pop(key, *args)
    
    def update(self, *args, **kwargs):
        super().update(*args, **kwargs)
        self._modified = True
    
    def clear(self):
        super().clear()
        self._modified = True
    
    def setdefault(self, key, default=None):
        if key not in self:
            self._modified = True
        return super().setdefault(key, default)
    
    @property
    def modified(self) -> bool:
        return self._modified
    
    @property
    def new(self) -> bool:
        return self._new
    
    @new.setter
    def new(self, value: bool):
        self._new = value
    
    @property
    def permanent(self) -> bool:
        """是否是永久会话"""
        return self._permanent
    
    @permanent.setter
    def permanent(self, value: bool):
        self._permanent = value
    
    def to_dict(self) -> dict:
        data = dict(self)
        data["_permanent"] = self._permanent
        data["_created_at"] = time.time()
        return data
    
    @classmethod
    def from_dict(cls, data: dict) -> "Session":
        session = cls()
        permanent = data.pop("_permanent", False)
        created_at = data.pop("_created_at", None)
        
        session.update(data)
        session._permanent = permanent
        session._created_at = created_at
        session._modified = False
        session._new = False
        
        return session


class NullSession(SessionMixin, dict):
    """不可写会话哨兵 — 不可写会话哨兵

    当 session 未配置时使用，任何写操作均抛出 RuntimeError。
    读操作返回空结果，不抛异常。
    """

    def _fail(self, *args, **kwargs):
        raise RuntimeError(
            "Session is not available. "
            "Call app.setup_session() or set app.secret_key to enable sessions."
        )

    def __setitem__(self, key, value):
        self._fail()

    def __delitem__(self, key):
        self._fail()

    def pop(self, key, *args):
        self._fail()

    def update(self, *args, **kwargs):
        self._fail()

    def clear(self):
        self._fail()

    def setdefault(self, key, default=None):
        self._fail()


class SessionInterface(ABC):
    """会话接口基类"""
    
    def __init__(self, config: SessionConfig):
        self.config = config
    
    @abstractmethod
    def open_session(self, request) -> Optional[Session]:
        ...
    
    @abstractmethod
    def save_session(self, session: Session, response):
        ...


class SecureCookieSessionInterface(SessionInterface):
    """
    安全Cookie会话接口 - SecureCookieSessionInterface
    
    将会话数据加密存储在Cookie中，优先使用AES-GCM加密，
    若cryptography包未安装则回退到HMAC签名
    """
    
    def __init__(self, config: SessionConfig):
        super().__init__(config)
        self._signer = SignedCookieManager(config.secret_key, salt="kewe.session")
        self._use_encryption = False
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            self._encryption_key = self._derive_encryption_key(config.secret_key)
            self._use_encryption = True
        except ImportError:
            import warnings
            warnings.warn(
                "cryptography package not installed. Session data will be signed but NOT encrypted. "
                "Install with: pip install cryptography",
                RuntimeWarning,
                stacklevel=2
            )
    
    def _derive_encryption_key(self, secret_key: str) -> bytes:
        import hashlib
        return hashlib.pbkdf2_hmac(
            'sha256',
            secret_key.encode('utf-8'),
            b'kewe.session.enc.salt',
            iterations=100000,
        )
    
    def _encrypt(self, data: bytes) -> str:
        if self._use_encryption:
            import os
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            aesgcm = AESGCM(self._encryption_key)
            nonce = os.urandom(12)
            ciphertext = aesgcm.encrypt(nonce, data, None)
            return base64.urlsafe_b64encode(nonce + ciphertext).decode()
        else:
            data_b64 = base64.urlsafe_b64encode(data).decode()
            signature = self._signer.sign(data_b64)
            return f"{data_b64}.{signature}"
    
    def _decrypt(self, token: str) -> Optional[bytes]:
        if self._use_encryption:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            try:
                raw = base64.urlsafe_b64decode(token.encode())
                nonce = raw[:12]
                ciphertext = raw[12:]
                aesgcm = AESGCM(self._encryption_key)
                return aesgcm.decrypt(nonce, ciphertext, None)
            except Exception:
                return None
        else:
            try:
                if "." not in token:
                    return None
                data_b64, signature = token.rsplit(".", 1)
                data = base64.urlsafe_b64decode(data_b64.encode())
                expected_signed = self._signer.sign(data_b64)
                _, expected_sig = expected_signed.rsplit(".", 1)
                if not hmac.compare_digest(signature, expected_sig):
                    return None
                return data
            except Exception:
                return None
    
    def open_session(self, request) -> Optional[Session]:
        cookie_value = request.cookies.get(self.config.session_cookie_name)
        
        if not cookie_value:
            return Session()
        
        try:
            data = self._decrypt(cookie_value)
            if data is None:
                return Session()
            
            session_data = json.loads(data.decode('utf-8', errors='surrogateescape'))
            created_at = session_data.get('_created_at')
            if created_at is not None:
                permanent = session_data.get('_permanent', False)
                lifetime = self.config.permanent_session_lifetime if permanent else 3600
                if time.time() - created_at > lifetime:
                    return Session()
            
            return Session.from_dict(session_data)
            
        except Exception:
            return Session()
    
    def save_session(self, session: Session, response, request=None):
        if not session.modified:
            return
        
        data = json.dumps(session.to_dict()).encode()
        cookie_value = self._encrypt(data)
        
        MAX_COOKIE_SIZE = 4093
        if len(cookie_value) > MAX_COOKIE_SIZE:
            import logging
            logger = logging.getLogger(__name__)
            logger.warning(
                f"Session cookie size ({len(cookie_value)}) exceeds browser limit ({MAX_COOKIE_SIZE}). "
                f"Session data will not be persisted. Consider using server-side session storage."
            )
            response.delete_cookie(
                self.config.session_cookie_name,
                domain=self.config.session_cookie_domain,
                path=self.config.session_cookie_path,
            )
            return
        
        max_age = self.config.permanent_session_lifetime if session.permanent else None
        
        response.set_cookie(
            key=self.config.session_cookie_name,
            value=cookie_value,
            max_age=max_age,
            domain=self.config.session_cookie_domain,
            path=self.config.session_cookie_path,
            httponly=self.config.session_cookie_httponly,
            secure=self.config.session_cookie_secure,
            samesite=self.config.session_cookie_samesite
        )


class RedisSessionInterface(SessionInterface):
    """Redis会话接口"""
    
    def __init__(self, config: SessionConfig, redis_client=None):
        super().__init__(config)
        self.redis = redis_client
        self.key_prefix = "session:"
        self._signer = SignedCookieManager(config.secret_key, salt="kewe.redis_session")
    
    def _sign_session_id(self, session_id: str) -> str:
        return self._signer.sign(session_id)
    
    def _verify_session_id(self, signed_value: str) -> Optional[str]:
        try:
            unsigned = self._signer.unsign(signed_value)
            return unsigned if isinstance(unsigned, str) else unsigned.decode()
        except Exception:
            return None
    
    async def open_session(self, request) -> Optional[Session]:
        if not self.redis:
            return Session()
        
        cookie_value = request.cookies.get(self.config.session_cookie_name)
        
        if not cookie_value:
            return Session()
        
        session_id = self._verify_session_id(cookie_value)
        if not session_id:
            return Session()
        
        try:
            data = await self.redis.get(f"{self.key_prefix}{session_id}")
            if data:
                if isinstance(data, bytes):
                    data = data.decode('utf-8', errors='surrogateescape')
                session_data = json.loads(data)
                session = Session.from_dict(session_data)
                session._session_id = session_id
                return session
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)
        
        return Session()
    
    async def save_session(self, session: Session, response, request=None):
        if not self.redis or not session.modified:
            return
        
        existing_id = getattr(session, '_session_id', None)
        session_id = existing_id or secrets.token_hex(16)
        
        ttl = self.config.permanent_session_lifetime if session.permanent else 3600
        data = json.dumps(session.to_dict())
        await self.redis.setex(f"{self.key_prefix}{session_id}", ttl, data)
        
        signed_id = self._sign_session_id(session_id)
        
        response.set_cookie(
            key=self.config.session_cookie_name,
            value=signed_id,
            max_age=ttl if session.permanent else None,
            domain=self.config.session_cookie_domain,
            path=self.config.session_cookie_path,
            httponly=self.config.session_cookie_httponly,
            secure=self.config.session_cookie_secure,
            samesite=self.config.session_cookie_samesite
        )


class SessionMiddleware:
    """会话中间件"""
    
    def __init__(self, session_interface: SessionInterface):
        self.session_interface = session_interface
    
    async def process_request(self, request):
        if asyncio.iscoroutinefunction(self.session_interface.open_session):
            request.session = await self.session_interface.open_session(request)
        else:
            request.session = self.session_interface.open_session(request)
        from kewe.base.context import g
        g._session = request.session
    
    async def process_response(self, request, response):
        if hasattr(request, "session"):
            if asyncio.iscoroutinefunction(self.session_interface.save_session):
                await self.session_interface.save_session(request.session, response, request=request)
            else:
                self.session_interface.save_session(request.session, response, request=request)


def setup_session(app, config: SessionConfig = None, session_interface: SessionInterface = None):
    """
    设置会话支持
    
    使用示例:
        from kewe import Kewe
        from kewe.cookies.session import setup_session, SessionConfig
        
        app = Kewe("MyApp")
        setup_session(app, SessionConfig(secret_key="your-secret-key"))
        
        @app.route("/")
        async def index(request):
            request.session["user_id"] = 123
            request.session.flash("Welcome!", "success")
            return text("OK")
    """
    config = config or SessionConfig()
    
    if session_interface is None:
        if config.session_type == "redis":
            session_interface = RedisSessionInterface(config)
        else:
            session_interface = SecureCookieSessionInterface(config)
    
    middleware = SessionMiddleware(session_interface)
    
    @app.middleware("onion")
    async def session_middleware(request, handler):
        await middleware.process_request(request)
        try:
            response = await handler(request)
        except Exception as exc:
            if hasattr(request, 'session'):
                try:
                    from kewe.errors.exceptions import KeweException
                    if isinstance(exc, KeweException) and hasattr(exc, '_response'):
                        save_response = exc._response
                    else:
                        from kewe.response import Response
                        save_response = Response(status=500, body=b'')
                    await middleware.process_response(request, save_response)
                    if save_response.headers.get('set-cookie'):
                        if not hasattr(exc, '_response'):
                            exc._session_cookies = save_response.get_cookie_headers()
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)
            raise
        if hasattr(request, 'session'):
            await middleware.process_response(request, response)
        return response


__all__ = [
    "SessionMixin",
    "Session",
    "NullSession",
    "SessionConfig",
    "SessionInterface",
    "SecureCookieSessionInterface",
    "RedisSessionInterface",
    "SessionMiddleware",
    "setup_session",
]
