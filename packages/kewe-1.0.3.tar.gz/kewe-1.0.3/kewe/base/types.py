#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
类型定义模块 - Type Definitions
提供完整的类型提示支持
"""
from typing import (
    Dict, List, Optional, Union, Callable, Any, 
    Awaitable, TypeVar, Generic, Protocol, TypedDict,
    AsyncGenerator, Tuple, Set
)
from dataclasses import dataclass
from enum import Enum


class HTTPMethod(str, Enum):
    """HTTP方法"""
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"
    TRACE = "TRACE"
    CONNECT = "CONNECT"


class RouteMatch(TypedDict):
    """路由匹配结果"""
    path: str
    methods: List[str]
    handler: Callable
    params: Dict[str, Any]
    middlewares: List[Callable]


class RequestHeaders(TypedDict, total=False):
    """请求头"""
    host: str
    user_agent: str
    accept: str
    accept_encoding: str
    accept_language: str
    content_type: str
    content_length: str
    authorization: str
    cookie: str
    x_request_id: str
    x_forwarded_for: str
    x_forwarded_proto: str


class ResponseHeaders(TypedDict, total=False):
    """响应头"""
    content_type: str
    content_length: str
    content_encoding: str
    cache_control: str
    set_cookie: str
    location: str
    server: str
    date: str
    x_request_id: str
    x_response_time: str


class QueryParams(TypedDict, total=False):
    """查询参数"""
    page: int
    per_page: int
    offset: int
    limit: int
    sort: str
    order: str
    q: str
    fields: str
    expand: str
    filter: str


class JSONValue(TypedDict, total=False):
    """JSON值"""
    id: Union[int, str]
    type: str
    name: str
    value: Any
    created_at: str
    updated_at: str


JSONType = Union[None, bool, int, float, str, List['JSONType'], 'JSONValue']


@dataclass
class Cookie:
    name: str
    value: str
    max_age: Optional[int] = None
    expires: Optional[str] = None
    path: str = "/"
    domain: Optional[str] = None
    secure: bool = True
    httponly: bool = False
    samesite: str = "Lax"


@dataclass
class RouteInfo:
    """路由信息"""
    path: str
    methods: List[HTTPMethod]
    handler: Callable
    name: Optional[str] = None
    params: Optional[Dict[str, str]] = None
    host: Optional[str] = None
    schemes: Optional[List[str]] = None


@dataclass
class MiddlewareInfo:
    """中间件信息"""
    handler: Callable
    priority: int
    attach_to: str
    name: Optional[str] = None


@dataclass
class WebSocketInfo:
    """WebSocket信息"""
    path: str
    handler: Callable
    subprotocols: Optional[List[str]] = None


class ASGIScope(TypedDict, total=False):
    """ASGI Scope"""
    type: str
    asgi: Dict[str, str]
    http_version: str
    method: str
    scheme: str
    path: str
    query_string: bytes
    root_path: str
    headers: List[Tuple[bytes, bytes]]
    server: Tuple[str, int]
    client: Tuple[str, int]
    subprotocols: List[str]


class ASGIMessage(TypedDict, total=False):
    """ASGI Message"""
    type: str
    status: int
    headers: List[Tuple[bytes, bytes]]
    body: bytes
    more_body: bool
    text: str
    bytes: bytes
    code: int
    reason: str
    subprotocol: str


class HTTPRequest(TypedDict, total=False):
    """HTTP请求"""
    method: str
    path: str
    headers: Dict[str, str]
    query_params: Dict[str, List[str]]
    body: bytes
    client_ip: str
    protocol: str


class HTTPResponse(TypedDict, total=False):
    """HTTP响应"""
    status: int
    headers: Dict[str, str]
    body: bytes
    content_type: str


T = TypeVar('T')


class RequestHandler(Protocol[T]):
    """请求处理器协议"""
    async def __call__(self, request: 'Request') -> T: ...


class MiddlewareHandler(Protocol):
    """中间件处理器协议"""
    async def __call__(self, request: 'Request') -> Optional['Response']: ...


class ResponseMiddlewareHandler(Protocol):
    """响应中间件处理器协议"""
    async def __call__(self, request: 'Request', response: 'Response') -> None: ...


class ErrorHandler(Protocol):
    """错误处理器协议"""
    async def __call__(self, request: 'Request', exception: Exception) -> 'Response': ...


class WebSocketHandler(Protocol):
    """WebSocket处理器协议"""
    async def __call__(self, websocket: 'WebSocketConnection') -> None: ...


class RouteDecorator(Protocol):
    """路由装饰器协议"""
    def __call__(self, handler: Callable) -> Callable: ...


class AppProtocol(Protocol):
    """应用协议"""
    def route(
        self,
        path: str,
        methods: List[str] = None,
        **kwargs
    ) -> RouteDecorator: ...
    
    def get(self, path: str, **kwargs) -> RouteDecorator: ...
    def post(self, path: str, **kwargs) -> RouteDecorator: ...
    def put(self, path: str, **kwargs) -> RouteDecorator: ...
    def delete(self, path: str, **kwargs) -> RouteDecorator: ...
    def patch(self, path: str, **kwargs) -> RouteDecorator: ...
    
    def middleware(
        self,
        middleware_or_request: Union[Callable, str] = None,
        **kwargs
    ) -> Callable: ...
    
    def websocket(self, path: str, **kwargs) -> RouteDecorator: ...
    
    async def handle_request(self, request: 'Request') -> 'Response': ...


class ServerProtocol(Protocol):
    """服务器协议"""
    async def start(self, sock: Any = None) -> None: ...
    async def stop(self) -> None: ...


class RouterProtocol(Protocol):
    """路由器协议"""
    def add_route(
        self,
        path: str,
        methods: List[str],
        handler: Callable,
        **kwargs
    ) -> None: ...
    
    def find_route(
        self,
        path: str,
        method: str,
        host: str = None
    ) -> Optional[RouteMatch]: ...
    
    def url_for(self, name: str, **kwargs) -> Optional[str]: ...


class ConfigProtocol(Protocol):
    """配置协议"""
    def get(self, key: str, default: Any = None) -> Any: ...
    def set(self, key: str, value: Any) -> None: ...
    def update(self, values: Dict[str, Any]) -> None: ...
    def load_from_env(self, prefix: str = "") -> None: ...
    def load_from_file(self, path: str) -> None: ...


class ContextProtocol(Protocol):
    """上下文协议"""
    def get(self, key: str, default: Any = None) -> Any: ...
    def set(self, key: str, value: Any) -> None: ...
    def delete(self, key: str) -> bool: ...
    def clear(self) -> None: ...


from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from kewe.request import Request
    from kewe.response import Response
    from kewe.websocket import WebSocketConnection


__all__ = [
    'HTTPMethod',
    'RouteMatch',
    'RequestHeaders',
    'ResponseHeaders',
    'QueryParams',
    'JSONValue',
    'JSONType',
    'Cookie',
    'RouteInfo',
    'MiddlewareInfo',
    'WebSocketInfo',
    'ASGIScope',
    'ASGIMessage',
    'HTTPRequest',
    'HTTPResponse',
    'T',
    'RequestHandler',
    'MiddlewareHandler',
    'ResponseMiddlewareHandler',
    'ErrorHandler',
    'WebSocketHandler',
    'RouteDecorator',
    'AppProtocol',
    'ServerProtocol',
    'RouterProtocol',
    'ConfigProtocol',
    'ContextProtocol',
]
