#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
常量定义模块 - Constants
constants.py实现，定义框架使用的所有常量
"""


class HTTP:
    """HTTP相关常量"""
    
    DEFAULT_REQUEST_MAX_SIZE = 100_000_000
    DEFAULT_REQUEST_TIMEOUT = 60
    DEFAULT_RESPONSE_TIMEOUT = 60
    DEFAULT_KEEP_ALIVE_TIMEOUT = 5
    DEFAULT_KEEP_ALIVE = True
    DEFAULT_WEBSOCKET_MAX_SIZE = 2 ** 20
    DEFAULT_WEBSOCKET_PING_INTERVAL = 20
    DEFAULT_WEBSOCKET_PING_TIMEOUT = 20
    
    REQUEST_BUFFER_SIZE = 64 * 1024
    RESPONSE_BUFFER_SIZE = 64 * 1024
    
    MAX_HEADER_SIZE = 8192
    MAX_HEADERS_COUNT = 100
    
    METHODS = [
        'GET',
        'POST',
        'PUT',
        'DELETE',
        'PATCH',
        'HEAD',
        'OPTIONS',
        'TRACE',
        'CONNECT',
    ]
    
    SAFE_METHODS = ['GET', 'HEAD', 'OPTIONS', 'TRACE']
    IDEMPOTENT_METHODS = ['GET', 'HEAD', 'OPTIONS', 'TRACE', 'PUT', 'DELETE']


class Server:
    """服务器相关常量"""
    
    DEFAULT_HOST = "127.0.0.1"
    DEFAULT_PORT = 8000
    DEFAULT_DEBUG = False
    DEFAULT_ACCESS_LOG = True
    DEFAULT_AUTO_RELOAD = False
    
    DEFAULT_WORKERS = 1
    MAX_WORKERS = 100
    
    SIGNAL_SHUTDOWN_GRACE_PERIOD = 15.0
    HEALTH_CHECK_INTERVAL = 30


class WebSocket:
    """WebSocket相关常量"""
    
    OPCODE_CONTINUATION = 0x0
    OPCODE_TEXT = 0x1
    OPCODE_BINARY = 0x2
    OPCODE_CLOSE = 0x8
    OPCODE_PING = 0x9
    OPCODE_PONG = 0xA
    
    CLOSE_NORMAL = 1000
    CLOSE_GOING_AWAY = 1001
    CLOSE_PROTOCOL_ERROR = 1002
    CLOSE_UNSUPPORTED_DATA = 1003
    CLOSE_NO_STATUS = 1005
    CLOSE_ABNORMAL = 1006
    CLOSE_INVALID_DATA = 1007
    CLOSE_POLICY_VIOLATION = 1008
    CLOSE_MESSAGE_TOO_BIG = 1009
    CLOSE_MANDATORY_EXTENSION = 1010
    CLOSE_INTERNAL_ERROR = 1011
    CLOSE_SERVICE_RESTART = 1012
    CLOSE_TRY_AGAIN_LATER = 1013
    CLOSE_BAD_GATEWAY = 1014


class MIME:
    """MIME类型常量"""
    
    TEXT_PLAIN = "text/plain"
    TEXT_HTML = "text/html"
    TEXT_CSS = "text/css"
    TEXT_JAVASCRIPT = "text/javascript"
    TEXT_XML = "text/xml"
    
    APPLICATION_JSON = "application/json"
    APPLICATION_XML = "application/xml"
    APPLICATION_FORM = "application/x-www-form-urlencoded"
    APPLICATION_OCTET_STREAM = "application/octet-stream"
    APPLICATION_PDF = "application/pdf"
    APPLICATION_ZIP = "application/zip"
    APPLICATION_GZIP = "application/gzip"
    
    IMAGE_JPEG = "image/jpeg"
    IMAGE_PNG = "image/png"
    IMAGE_GIF = "image/gif"
    IMAGE_SVG = "image/svg+xml"
    IMAGE_WEBP = "image/webp"
    IMAGE_ICO = "image/x-icon"
    
    AUDIO_MPEG = "audio/mpeg"
    AUDIO_OGG = "audio/ogg"
    VIDEO_MP4 = "video/mp4"
    VIDEO_WEBM = "video/webm"
    
    MULTIPART_FORM = "multipart/form-data"
    MULTIPART_BYTERANGES = "multipart/byteranges"


class Status:
    """HTTP状态码常量"""
    
    CONTINUE = 100
    SWITCHING_PROTOCOLS = 101
    PROCESSING = 102
    EARLY_HINTS = 103
    
    OK = 200
    CREATED = 201
    ACCEPTED = 202
    NON_AUTHORITATIVE_INFORMATION = 203
    NO_CONTENT = 204
    RESET_CONTENT = 205
    PARTIAL_CONTENT = 206
    MULTI_STATUS = 207
    ALREADY_REPORTED = 208
    IM_USED = 226
    
    MULTIPLE_CHOICES = 300
    MOVED_PERMANENTLY = 301
    FOUND = 302
    SEE_OTHER = 303
    NOT_MODIFIED = 304
    USE_PROXY = 305
    TEMPORARY_REDIRECT = 307
    PERMANENT_REDIRECT = 308
    
    BAD_REQUEST = 400
    UNAUTHORIZED = 401
    PAYMENT_REQUIRED = 402
    FORBIDDEN = 403
    NOT_FOUND = 404
    METHOD_NOT_ALLOWED = 405
    NOT_ACCEPTABLE = 406
    PROXY_AUTHENTICATION_REQUIRED = 407
    REQUEST_TIMEOUT = 408
    CONFLICT = 409
    GONE = 410
    LENGTH_REQUIRED = 411
    PRECONDITION_FAILED = 412
    PAYLOAD_TOO_LARGE = 413
    URI_TOO_LONG = 414
    UNSUPPORTED_MEDIA_TYPE = 415
    RANGE_NOT_SATISFIABLE = 416
    EXPECTATION_FAILED = 417
    IM_A_TEAPOT = 418
    MISDIRECTED_REQUEST = 421
    UNPROCESSABLE_ENTITY = 422
    LOCKED = 423
    FAILED_DEPENDENCY = 424
    TOO_EARLY = 425
    UPGRADE_REQUIRED = 426
    PRECONDITION_REQUIRED = 428
    TOO_MANY_REQUESTS = 429
    REQUEST_HEADER_FIELDS_TOO_LARGE = 431
    UNAVAILABLE_FOR_LEGAL_REASONS = 451
    
    INTERNAL_SERVER_ERROR = 500
    NOT_IMPLEMENTED = 501
    BAD_GATEWAY = 502
    SERVICE_UNAVAILABLE = 503
    GATEWAY_TIMEOUT = 504
    HTTP_VERSION_NOT_SUPPORTED = 505
    VARIANT_ALSO_NEGOTIATES = 506
    INSUFFICIENT_STORAGE = 507
    LOOP_DETECTED = 508
    NOT_EXTENDED = 510
    NETWORK_AUTHENTICATION_REQUIRED = 511


class Local:
    """本地化常量"""
    
    DEFAULT_ENCODING = "utf-8"
    DEFAULT_TIMEZONE = "UTC"


class Security:
    """安全相关常量"""
    
    DEFAULT_COOKIE_MAX_AGE = 3600
    DEFAULT_COOKIE_PATH = "/"
    DEFAULT_COOKIE_SAMESITE = "Lax"
    
    DEFAULT_CORS_MAX_AGE = 86400
    DEFAULT_CORS_ALLOW_HEADERS = ["*"]
    DEFAULT_CORS_ALLOW_METHODS = ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
    
    DEFAULT_RATE_LIMIT = 100
    DEFAULT_RATE_LIMIT_PERIOD = 60
    
    CSRF_TOKEN_LENGTH = 32
    CSRF_HEADER_NAME = "X-CSRF-Token"
    CSRF_COOKIE_NAME = "csrf_token"


class Log:
    """日志相关常量"""
    
    DEFAULT_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    ACCESS_LOG_FORMAT = '%(client_ip)s - - [%(asctime)s] "%(method)s %(path)s %(protocol)s" %(status)s %(length)s'
    
    LEVEL_DEBUG = "DEBUG"
    LEVEL_INFO = "INFO"
    LEVEL_WARNING = "WARNING"
    LEVEL_ERROR = "ERROR"
    LEVEL_CRITICAL = "CRITICAL"


class Config:
    """配置相关常量"""
    
    ENV_PREFIX = "KEWE_"
    
    CONFIG_FILES = [
        "kewe.conf",
        "kewe.cfg",
        "kewe.ini",
        "kewe.json",
        "kewe.yaml",
        "kewe.yml",
        ".kewerc",
    ]
    
    KEY_DEBUG = "DEBUG"
    KEY_HOST = "HOST"
    KEY_PORT = "PORT"
    KEY_WORKERS = "WORKERS"
    KEY_ACCESS_LOG = "ACCESS_LOG"
    KEY_AUTO_RELOAD = "AUTO_RELOAD"


__all__ = [
    'HTTP',
    'Server',
    'WebSocket',
    'MIME',
    'Status',
    'Local',
    'Security',
    'Log',
    'Config',
    'DEFAULT_HOST',
    'DEFAULT_PORT',
    'HTTP_METHODS',
]

DEFAULT_HOST = Server.DEFAULT_HOST
DEFAULT_PORT = Server.DEFAULT_PORT
HTTP_METHODS = ('GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS', 'TRACE')

