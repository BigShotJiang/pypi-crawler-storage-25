#!/usr/bin/env python
# -*- coding: utf-8 -*-
import asyncio
import time
import logging
import threading
from enum import Enum
from typing import Optional, Callable, Any, Dict, List
from dataclasses import dataclass, field

from kewe.errors.exceptions import KeweException


logger = logging.getLogger(__name__)


class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


@dataclass
class CircuitBreakerConfig:
    failure_threshold: int = 5
    recovery_timeout: float = 30.0
    half_open_max_calls: int = 3
    success_threshold: int = 3
    window_size: float = 60.0


@dataclass
class CircuitStats:
    failures: int = 0
    successes: int = 0
    total_calls: int = 0
    last_failure_time: float = 0.0
    last_success_time: float = 0.0
    consecutive_failures: int = 0
    consecutive_successes: int = 0
    half_open_calls: int = 0
    window_failures: List[float] = field(default_factory=list)


class CircuitBreaker:
    def __init__(
        self,
        name: str = "default",
        config: Optional[CircuitBreakerConfig] = None,
        on_state_change: Optional[Callable[[CircuitState, CircuitState], None]] = None,
        fallback: Optional[Callable[..., Any]] = None,
        *,
        failure_threshold: Optional[int] = None,
        recovery_timeout: Optional[float] = None,
    ):
        self.name = name
        if config is None and (failure_threshold is not None or recovery_timeout is not None):
            config = CircuitBreakerConfig(
                failure_threshold=failure_threshold or 5,
                recovery_timeout=recovery_timeout if recovery_timeout is not None else 30.0,
            )
        self.config = config or CircuitBreakerConfig()
        self._state = CircuitState.CLOSED
        self._stats = CircuitStats()
        self._on_state_change = on_state_change
        self._fallback = fallback
        self._lock: Optional[asyncio.Lock] = None
        self._sync_lock = threading.Lock()

    @property
    def state(self) -> str:
        return self._state.value

    @property
    def circuit_state(self) -> CircuitState:
        return self._state

    @state.setter
    def state(self, value):
        if isinstance(value, CircuitState):
            self._state = value
        elif isinstance(value, str):
            self._state = CircuitState(value)
        else:
            self._state = value

    def __eq__(self, other):
        if isinstance(other, CircuitState):
            return self._state == other
        if isinstance(other, str):
            return self._state.value == other
        return NotImplemented

    def _check_and_transition(self) -> CircuitState:
        if self._state == CircuitState.OPEN:
            if time.time() - self._stats.last_failure_time >= self.config.recovery_timeout:
                self._transition_to(CircuitState.HALF_OPEN)
        return self._state

    @property
    def stats(self) -> CircuitStats:
        return self._stats

    def _transition_to(self, new_state: CircuitState):
        old_state = self._state
        if old_state == new_state:
            return
        self._state = new_state
        logger.info(f"CircuitBreaker '{self.name}': {old_state.value} -> {new_state.value}")
        if self._on_state_change:
            try:
                self._on_state_change(old_state, new_state)
            except Exception as e:
                logger.error(f"CircuitBreaker state change callback error: {e}")

    def _record_failure(self):
        now = time.time()
        self._stats.failures += 1
        self._stats.total_calls += 1
        self._stats.last_failure_time = now
        self._stats.consecutive_failures += 1
        self._stats.consecutive_successes = 0
        self._stats.window_failures.append(now)
        self._stats.window_failures = [
            t for t in self._stats.window_failures
            if now - t < self.config.window_size
        ]
        if self._state == CircuitState.HALF_OPEN:
            self._stats.half_open_calls = 0
            self._transition_to(CircuitState.OPEN)
        elif self._state == CircuitState.CLOSED:
            if self._stats.consecutive_failures >= self.config.failure_threshold:
                self._transition_to(CircuitState.OPEN)

    def record_failure(self):
        """公开方法：记录一次失败"""
        self._record_failure()

    def _record_success(self):
        now = time.time()
        self._stats.successes += 1
        self._stats.total_calls += 1
        self._stats.last_success_time = now
        self._stats.consecutive_successes += 1
        self._stats.consecutive_failures = 0
        if self._state == CircuitState.HALF_OPEN:
            if self._stats.consecutive_successes >= self.config.success_threshold:
                self._transition_to(CircuitState.CLOSED)

    def record_success(self):
        """公开方法：记录一次成功"""
        self._record_success()

    def _can_execute(self) -> bool:
        current = self._check_and_transition()
        if current == CircuitState.CLOSED:
            return True
        if current == CircuitState.HALF_OPEN:
            if self._stats.half_open_calls < self.config.half_open_max_calls:
                self._stats.half_open_calls += 1
                return True
            return False
        return False

    async def call(self, func: Callable, *args, **kwargs) -> Any:
        if self._lock is None:
            self._lock = asyncio.Lock()
        async with self._lock:
            can_exec = self._can_execute()
        if not can_exec:
            if self._fallback:
                return self._fallback(*args, **kwargs)
            raise CircuitOpenError(f"CircuitBreaker '{self.name}' is open")
        try:
            result = await func(*args, **kwargs)
            async with self._lock:
                self._record_success()
            return result
        except Exception as e:
            async with self._lock:
                self._record_failure()
            raise

    def call_sync(self, func: Callable, *args, **kwargs) -> Any:
        with self._sync_lock:
            can_exec = self._can_execute()
        if not can_exec:
            if self._fallback:
                return self._fallback(*args, **kwargs)
            raise CircuitOpenError(f"CircuitBreaker '{self.name}' is open")
        try:
            result = func(*args, **kwargs)
            with self._sync_lock:
                self._record_success()
            return result
        except Exception as e:
            with self._sync_lock:
                self._record_failure()
            raise

    def reset(self):
        self._stats = CircuitStats()
        self._transition_to(CircuitState.CLOSED)

    def force_open(self):
        self._transition_to(CircuitState.OPEN)

    def get_status(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "state": self.state,
            "failures": self._stats.failures,
            "successes": self._stats.successes,
            "total_calls": self._stats.total_calls,
            "consecutive_failures": self._stats.consecutive_failures,
            "consecutive_successes": self._stats.consecutive_successes,
            "last_failure_time": self._stats.last_failure_time,
            "last_success_time": self._stats.last_success_time,
        }


class CircuitOpenError(KeweException):
    error_code = "CIRCUIT_OPEN"

    def __init__(self, name: str = "default", retry_after: Optional[int] = None):
        self.name = name
        self.retry_after = retry_after
        headers = {}
        if retry_after is not None:
            headers["Retry-After"] = str(retry_after)
        super().__init__(
            message=f"CircuitBreaker '{name}' is open",
            status_code=503,
            error_code=self.error_code,
            headers=headers if headers else None,
        )


class CircuitBreakerRegistry:
    _instance: Optional["CircuitBreakerRegistry"] = None
    _lock = threading.Lock()

    def __init__(self):
        self._breakers: Dict[str, CircuitBreaker] = {}

    @classmethod
    def get_instance(cls) -> "CircuitBreakerRegistry":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def set_instance(cls, instance: "CircuitBreakerRegistry"):
        with cls._lock:
            cls._instance = instance

    @classmethod
    def create(cls) -> "CircuitBreakerRegistry":
        return cls()

    def get_or_create(
        self,
        name: str,
        config: Optional[CircuitBreakerConfig] = None,
        fallback: Optional[Callable] = None,
    ) -> CircuitBreaker:
        with self._lock:
            if name not in self._breakers:
                self._breakers[name] = CircuitBreaker(
                    name=name, config=config, fallback=fallback
                )
            return self._breakers[name]

    def get(self, name: str) -> Optional[CircuitBreaker]:
        return self._breakers.get(name)

    def get_all_status(self) -> Dict[str, Dict[str, Any]]:
        return {name: cb.get_status() for name, cb in self._breakers.items()}

    def reset_all(self):
        for cb in self._breakers.values():
            cb.reset()


def circuit_breaker(
    name: Optional[str] = None,
    config: Optional[CircuitBreakerConfig] = None,
    fallback: Optional[Callable] = None,
    registry: Optional[CircuitBreakerRegistry] = None,
):
    def decorator(func):
        cb_name = name or f"{func.__module__}.{func.__qualname__}"
        reg = registry or CircuitBreakerRegistry.get_instance()
        cb = reg.get_or_create(cb_name, config=config, fallback=fallback)

        if asyncio.iscoroutinefunction(func):
            async def wrapper(*args, **kwargs):
                return await cb.call(func, *args, **kwargs)
        else:
            def wrapper(*args, **kwargs):
                return cb.call_sync(func, *args, **kwargs)

        wrapper._circuit_breaker = cb
        wrapper.__name__ = func.__name__
        wrapper.__qualname__ = func.__qualname__
        return wrapper

    return decorator
