#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
错误追踪器 - 记录和管理应用错误
"""
import asyncio
import hashlib
from kewe.utils.compat import json
import logging
import traceback
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict
from collections import deque

logger = logging.getLogger(__name__)


class ErrorSeverity(Enum):
    """错误严重程度"""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class ErrorRecord:
    """错误记录"""
    id: str
    timestamp: str
    severity: ErrorSeverity
    exception_type: str
    message: str
    traceback: str
    request_info: Optional[Dict] = None
    context: Optional[Dict] = None
    count: int = 1
    last_occurrence: Optional[str] = None
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'id': self.id,
            'timestamp': self.timestamp,
            'severity': self.severity.value,
            'exception_type': self.exception_type,
            'message': self.message,
            'traceback': self.traceback,
            'request_info': self.request_info,
            'context': self.context,
            'count': self.count,
            'last_occurrence': self.last_occurrence
        }
    
    @classmethod
    def from_exception(
        cls,
        exception: Exception,
        severity: ErrorSeverity = ErrorSeverity.ERROR,
        request_info: Optional[Dict] = None,
        context: Optional[Dict] = None
    ) -> 'ErrorRecord':
        """从异常创建错误记录"""
        # 生成唯一ID（基于异常类型和消息）
        error_key = f"{type(exception).__name__}:{str(exception)}"
        error_id = hashlib.md5(error_key.encode()).hexdigest()[:12]
        
        now = datetime.now().isoformat()
        
        return cls(
            id=error_id,
            timestamp=now,
            severity=severity,
            exception_type=type(exception).__name__,
            message=str(exception),
            traceback=''.join(traceback.format_exception(
                type(exception), exception, exception.__traceback__
            )),
            request_info=request_info,
            context=context
        )


class ErrorTracker:
    """
    错误追踪器
    
    记录、管理和报告应用错误
    """
    
    def __init__(
        self,
        max_records: int = 1000,
        deduplicate: bool = True,
        auto_cleanup: bool = True
    ):
        self._records: Dict[str, ErrorRecord] = {}
        self._record_order: deque = deque(maxlen=max_records)
        self._max_records = max_records
        self._deduplicate = deduplicate
        self._auto_cleanup = auto_cleanup
        self._lock: Optional[asyncio.Lock] = None
        self._handlers: List[Callable] = []
        self._stats = {
            'total_errors': 0,
            'unique_errors': 0,
            'by_severity': {s.value: 0 for s in ErrorSeverity}
        }

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def track(
        self,
        exception: Exception,
        severity: ErrorSeverity = ErrorSeverity.ERROR,
        request_info: Optional[Dict] = None,
        context: Optional[Dict] = None
    ) -> ErrorRecord:
        """
        追踪错误
        
        Args:
            exception: 异常对象
            severity: 严重程度
            request_info: 请求信息
            context: 上下文信息
            
        Returns:
            错误记录
        """
        record = ErrorRecord.from_exception(
            exception, severity, request_info, context
        )
        
        async with self._get_lock():
            # 检查是否已存在
            if self._deduplicate and record.id in self._records:
                existing = self._records[record.id]
                existing.count += 1
                existing.last_occurrence = datetime.now().isoformat()
                record = existing
            else:
                self._records[record.id] = record
                self._record_order.append(record.id)
            
            # 更新统计
            self._stats['total_errors'] += 1
            if record.count == 1:
                self._stats['unique_errors'] += 1
            self._stats['by_severity'][severity.value] += 1
            
            # 自动清理
            if self._auto_cleanup and len(self._records) > self._max_records:
                self._cleanup_old_records()
        
        # 调用处理器
        for handler in self._handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(record)
                else:
                    handler(record)
            except Exception as e:
                logger.error(f"Error handler failed: {e}")
        
        return record
    
    def _cleanup_old_records(self):
        """清理旧记录"""
        while len(self._records) > self._max_records:
            old_id = self._record_order.popleft()
            if old_id in self._records:
                del self._records[old_id]
    
    def get(self, error_id: str) -> Optional[ErrorRecord]:
        """
        获取错误记录
        
        Args:
            error_id: 错误ID
            
        Returns:
            错误记录或None
        """
        return self._records.get(error_id)
    
    def get_all(self) -> List[ErrorRecord]:
        """
        获取所有错误记录
        
        Returns:
            错误记录列表
        """
        return list(self._records.values())
    
    def get_recent(self, count: int = 10) -> List[ErrorRecord]:
        """
        获取最近的错误记录
        
        Args:
            count: 数量
            
        Returns:
            错误记录列表
        """
        recent_ids = list(self._record_order)[-count:]
        return [self._records[eid] for eid in recent_ids if eid in self._records]
    
    def get_by_severity(self, severity: ErrorSeverity) -> List[ErrorRecord]:
        """
        按严重程度获取错误
        
        Args:
            severity: 严重程度
            
        Returns:
            错误记录列表
        """
        return [
            record for record in self._records.values()
            if record.severity == severity
        ]
    
    def add_handler(self, handler: Callable):
        """添加错误处理器"""
        self._handlers.append(handler)

    def add_reporter(self, reporter):
        """添加错误报告器 — 将 ErrorReporter 适配为 handler

        使用示例:
            from kewe.errors.reporter import WebhookReporter
            tracker.add_reporter(WebhookReporter("https://hooks.example.com/errors"))
        """
        async def reporter_handler(record):
            try:
                if hasattr(reporter, 'report'):
                    await reporter.report(record)
            except Exception:
                logger.warning("Error reporter failed", exc_info=True)
        self._handlers.append(reporter_handler)
    
    def remove_handler(self, handler: Callable):
        """
        移除错误处理器
        
        Args:
            handler: 处理函数
        """
        if handler in self._handlers:
            self._handlers.remove(handler)
    
    def clear(self):
        """清除所有记录"""
        self._records.clear()
        self._record_order.clear()
        self._stats = {
            'total_errors': 0,
            'unique_errors': 0,
            'by_severity': {s.value: 0 for s in ErrorSeverity}
        }
    
    @property
    def stats(self) -> Dict:
        """获取统计信息"""
        return self._stats.copy()
    
    def export_json(self, filepath: str):
        """
        导出为JSON文件
        
        Args:
            filepath: 文件路径
        """
        data = {
            'stats': self._stats,
            'records': [record.to_dict() for record in self._records.values()]
        }
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    def generate_report(self) -> str:
        """
        生成错误报告
        
        Returns:
            报告文本
        """
        lines = [
            "=" * 60,
            "Error Tracking Report",
            "=" * 60,
            f"Total Errors: {self._stats['total_errors']}",
            f"Unique Errors: {self._stats['unique_errors']}",
            "",
            "By Severity:",
        ]
        
        for severity, count in self._stats['by_severity'].items():
            lines.append(f"  {severity}: {count}")
        
        lines.extend([
            "",
            "Recent Errors:",
            "-" * 60
        ])
        
        for record in self.get_recent(5):
            lines.extend([
                f"[{record.severity.value.upper()}] {record.exception_type}",
                f"  Message: {record.message}",
                f"  Count: {record.count}",
                f"  Time: {record.timestamp}",
                ""
            ])
        
        return "\n".join(lines)


# 全局错误追踪器实例
error_tracker = ErrorTracker()
