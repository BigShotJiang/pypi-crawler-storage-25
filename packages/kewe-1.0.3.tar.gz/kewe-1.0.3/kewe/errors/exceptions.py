#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
完善的异常类体系 - Enhanced Exception Classes
提供完整的HTTP标准异常

注意: 2xx/3xx 状态码不是"异常"，应使用响应工具函数（如 redirect()）。
这些类仅为向后兼容保留，未来版本将移除。
"""
import warnings
from typing import Optional, Dict, Any


class KeweException(Exception):

    __slots__ = ('message', 'status_code', 'context', 'headers', 'detail', 'error_code', 'response')

    def __init__(self, message: Optional[str] = None, status_code: int = 500,
                 context: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None,
                 detail: Any = None, error_code: Optional[str] = None):
        super().__init__(message)
        self.message = message or "Internal Server Error"
        self.status_code = status_code
        self.context = context or {}
        self.headers = headers or {}
        self.detail = detail
        self.error_code = error_code
        self.response = None

    @property
    def status(self) -> int:
        """HTTP 状态码 — 与 Response.status 统一"""
        return self.status_code

    def to_problem_details(self, request_path: str = "") -> Dict[str, Any]:
        import time
        result = {
            "type": f"https://kewe.dev/errors/{self.error_code or self.status_code}",
            "title": self.message or self.__class__.__name__.replace('_', ' '),
            "status": self.status_code,
            "detail": self.detail or self.message,
        }
        if request_path:
            result["instance"] = request_path
        if self.error_code:
            result["error_code"] = self.error_code
        if self.context:
            reserved = {'type', 'title', 'status', 'instance', 'detail', 'error_code'}
            for k, v in self.context.items():
                if k not in reserved:
                    result[k] = v
        if self.__cause__:
            result["cause"] = str(self.__cause__)
        result["timestamp"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        return result

    def get_headers(self) -> Dict[str, str]:
        headers = dict(self.headers)
        if hasattr(self, 'www_authenticate') and self.www_authenticate:
            headers['WWW-Authenticate'] = self.www_authenticate
        if hasattr(self, 'allowed_methods') and self.allowed_methods:
            headers['Allow'] = ', '.join(self.allowed_methods)
        if hasattr(self, 'retry_after') and self.retry_after is not None:
            headers['Retry-After'] = str(self.retry_after)
        if hasattr(self, 'location') and self.location:
            headers['Location'] = self.location
        return headers

    def __str__(self):
        return f"[{self.status_code}] {self.message}"


# 4xx Client Error
class BadRequest(KeweException):
    error_code = "BAD_REQUEST"
    def __init__(self, message: str = "Bad Request", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 400, detail=detail, headers=headers, error_code=self.error_code)


class Unauthorized(KeweException):
    error_code = "UNAUTHORIZED"
    __slots__ = ('www_authenticate',)
    def __init__(self, message: str = "Unauthorized", www_authenticate: Optional[str] = None, detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 401, detail=detail, headers=headers, error_code=self.error_code)
        self.www_authenticate = www_authenticate


class PaymentRequired(KeweException):
    error_code = "PAYMENT_REQUIRED"
    def __init__(self, message: str = "Payment Required", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 402, detail=detail, headers=headers, error_code=self.error_code)


class Forbidden(KeweException):
    error_code = "FORBIDDEN"
    def __init__(self, message: str = "Forbidden", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 403, detail=detail, headers=headers, error_code=self.error_code)


class NotFound(KeweException):
    error_code = "NOT_FOUND"
    def __init__(self, message: str = "Not Found", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 404, detail=detail, headers=headers, error_code=self.error_code)


class MethodNotAllowed(KeweException):
    error_code = "METHOD_NOT_ALLOWED"
    __slots__ = ('allowed_methods',)
    def __init__(self, message: str = "Method Not Allowed", allowed_methods: Optional[list] = None, detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 405, detail=detail, headers=headers, error_code=self.error_code)
        self.allowed_methods = allowed_methods or []


class NotAcceptable(KeweException):
    error_code = "NOT_ACCEPTABLE"
    def __init__(self, message: str = "Not Acceptable", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 406, detail=detail, headers=headers, error_code=self.error_code)


class ProxyAuthenticationRequired(KeweException):
    error_code = "PROXY_AUTH_REQUIRED"
    def __init__(self, message: str = "Proxy Authentication Required", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 407, detail=detail, headers=headers, error_code=self.error_code)


class RequestTimeout(KeweException):
    error_code = "REQUEST_TIMEOUT"
    def __init__(self, message: str = "Request Timeout", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 408, detail=detail, headers=headers, error_code=self.error_code)


class Conflict(KeweException):
    error_code = "CONFLICT"
    def __init__(self, message: str = "Conflict", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 409, detail=detail, headers=headers, error_code=self.error_code)


class Gone(KeweException):
    error_code = "GONE"
    def __init__(self, message: str = "Gone", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 410, detail=detail, headers=headers, error_code=self.error_code)


class LengthRequired(KeweException):
    error_code = "LENGTH_REQUIRED"
    def __init__(self, message: str = "Length Required", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 411, detail=detail, headers=headers, error_code=self.error_code)


class PreconditionFailed(KeweException):
    error_code = "PRECONDITION_FAILED"
    def __init__(self, message: str = "Precondition Failed", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 412, detail=detail, headers=headers, error_code=self.error_code)


class PayloadTooLarge(KeweException):
    error_code = "PAYLOAD_TOO_LARGE"
    def __init__(self, message: str = "Payload Too Large", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 413, detail=detail, headers=headers, error_code=self.error_code)


class UriTooLong(KeweException):
    error_code = "URI_TOO_LONG"
    def __init__(self, message: str = "URI Too Long", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 414, detail=detail, headers=headers, error_code=self.error_code)


class UnsupportedMediaType(KeweException):
    error_code = "UNSUPPORTED_MEDIA_TYPE"
    def __init__(self, message: str = "Unsupported Media Type", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 415, detail=detail, headers=headers, error_code=self.error_code)


class RangeNotSatisfiable(KeweException):
    error_code = "RANGE_NOT_SATISFIABLE"
    def __init__(self, message: str = "Range Not Satisfiable", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 416, detail=detail, headers=headers, error_code=self.error_code)


class ExpectationFailed(KeweException):
    error_code = "EXPECTATION_FAILED"
    def __init__(self, message: str = "Expectation Failed", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 417, detail=detail, headers=headers, error_code=self.error_code)


class MisdirectedRequest(KeweException):
    error_code = "MISDIRECTED_REQUEST"
    def __init__(self, message: str = "Misdirected Request", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 421, detail=detail, headers=headers, error_code=self.error_code)


class ImATeapot(KeweException):
    error_code = "IM_A_TEAPOT"
    def __init__(self, message: str = "I'm a teapot", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 418, detail=detail, headers=headers, error_code=self.error_code)


class UnprocessableEntity(KeweException):
    error_code = "UNPROCESSABLE_ENTITY"
    def __init__(self, message: str = "Unprocessable Entity", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 422, detail=detail, headers=headers, error_code=self.error_code)


class Locked(KeweException):
    error_code = "LOCKED"
    def __init__(self, message: str = "Locked", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 423, detail=detail, headers=headers, error_code=self.error_code)


class FailedDependency(KeweException):
    error_code = "FAILED_DEPENDENCY"
    def __init__(self, message: str = "Failed Dependency", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 424, detail=detail, headers=headers, error_code=self.error_code)


class TooEarly(KeweException):
    error_code = "TOO_EARLY"
    def __init__(self, message: str = "Too Early", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 425, detail=detail, headers=headers, error_code=self.error_code)


class UpgradeRequired(KeweException):
    error_code = "UPGRADE_REQUIRED"
    def __init__(self, message: str = "Upgrade Required", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 426, detail=detail, headers=headers, error_code=self.error_code)


class PreconditionRequired(KeweException):
    error_code = "PRECONDITION_REQUIRED"
    def __init__(self, message: str = "Precondition Required", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 428, detail=detail, headers=headers, error_code=self.error_code)


class TooManyRequests(KeweException):
    error_code = "TOO_MANY_REQUESTS"
    __slots__ = ('retry_after',)
    def __init__(self, message: str = "Too Many Requests", retry_after: Optional[int] = None, detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 429, detail=detail, headers=headers, error_code=self.error_code)
        self.retry_after = retry_after


class RequestHeaderFieldsTooLarge(KeweException):
    error_code = "REQUEST_HEADER_FIELDS_TOO_LARGE"
    def __init__(self, message: str = "Request Header Fields Too Large", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 431, detail=detail, headers=headers, error_code=self.error_code)


class UnavailableForLegalReasons(KeweException):
    error_code = "UNAVAILABLE_FOR_LEGAL_REASONS"
    def __init__(self, message: str = "Unavailable For Legal Reasons", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 451, detail=detail, headers=headers, error_code=self.error_code)


# 5xx Server Error
class InternalServerError(KeweException):
    error_code = "INTERNAL_SERVER_ERROR"
    def __init__(self, message: str = "Internal Server Error", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 500, detail=detail, headers=headers, error_code=self.error_code)


class NotImplemented(KeweException):
    error_code = "NOT_IMPLEMENTED"
    def __init__(self, message: str = "Not Implemented", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 501, detail=detail, headers=headers, error_code=self.error_code)


class BadGateway(KeweException):
    error_code = "BAD_GATEWAY"
    def __init__(self, message: str = "Bad Gateway", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 502, detail=detail, headers=headers, error_code=self.error_code)


class ServiceUnavailable(KeweException):
    error_code = "SERVICE_UNAVAILABLE"
    __slots__ = ('retry_after',)
    def __init__(self, message: str = "Service Unavailable", retry_after: Optional[int] = None, detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 503, detail=detail, headers=headers, error_code=self.error_code)
        self.retry_after = retry_after


class GatewayTimeout(KeweException):
    error_code = "GATEWAY_TIMEOUT"
    def __init__(self, message: str = "Gateway Timeout", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 504, detail=detail, headers=headers, error_code=self.error_code)


class HttpVersionNotSupported(KeweException):
    error_code = "HTTP_VERSION_NOT_SUPPORTED"
    def __init__(self, message: str = "HTTP Version Not Supported", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 505, detail=detail, headers=headers, error_code=self.error_code)


class VariantAlsoNegotiates(KeweException):
    error_code = "VARIANT_ALSO_NEGOTIATES"
    def __init__(self, message: str = "Variant Also Negotiates", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 506, detail=detail, headers=headers, error_code=self.error_code)


class InsufficientStorage(KeweException):
    error_code = "INSUFFICIENT_STORAGE"
    def __init__(self, message: str = "Insufficient Storage", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 507, detail=detail, headers=headers, error_code=self.error_code)


class LoopDetected(KeweException):
    error_code = "LOOP_DETECTED"
    def __init__(self, message: str = "Loop Detected", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 508, detail=detail, headers=headers, error_code=self.error_code)


class NotExtended(KeweException):
    error_code = "NOT_EXTENDED"
    def __init__(self, message: str = "Not Extended", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 510, detail=detail, headers=headers, error_code=self.error_code)


class NetworkAuthenticationRequired(KeweException):
    error_code = "NETWORK_AUTH_REQUIRED"
    def __init__(self, message: str = "Network Authentication Required", detail: Any = None, headers: Optional[Dict[str, str]] = None):
        super().__init__(message, 511, detail=detail, headers=headers, error_code=self.error_code)


class _HTTPExceptionMeta(type):
    def __instancecheck__(cls, instance):
        from kewe.errors.exceptions import HTTPException as _HTTPException
        if cls is _HTTPException:
            return isinstance(instance, KeweException) and hasattr(instance, 'status_code')
        return super().__instancecheck__(instance)


class HTTPException(KeweException, metaclass=_HTTPExceptionMeta):

    __slots__ = ()

    def __init__(self, status_code: int = 500, detail: Any = None, headers: Optional[Dict[str, str]] = None,
                 ):
        msg = str(detail) if detail else f"HTTP {status_code}"
        super().__init__(
            message=msg,
            status_code=status_code,
            headers=headers,
            detail=detail,
        )


class RequestValidationError(KeweException):

    __slots__ = ('errors', 'body')

    def __init__(self, errors: Any = None, message: str = "Validation Error", body: Any = None):
        super().__init__(
            message=message,
            status_code=422,
            detail=errors,
            error_code="VALIDATION_ERROR",
        )
        self.errors = errors
        self.body = body

    def errors_list(self) -> list:
        """返回错误列表"""
        if isinstance(self.errors, list):
            return self.errors
        if self.errors is not None:
            return [self.errors]
        return []


_STATUS_CODE_TO_EXCEPTION = {
    400: BadRequest,
    401: Unauthorized,
    402: PaymentRequired,
    403: Forbidden,
    404: NotFound,
    405: MethodNotAllowed,
    406: NotAcceptable,
    407: ProxyAuthenticationRequired,
    408: RequestTimeout,
    409: Conflict,
    410: Gone,
    411: LengthRequired,
    412: PreconditionFailed,
    413: PayloadTooLarge,
    414: UriTooLong,
    415: UnsupportedMediaType,
    416: RangeNotSatisfiable,
    417: ExpectationFailed,
    418: ImATeapot,
    422: UnprocessableEntity,
    423: Locked,
    424: FailedDependency,
    425: TooEarly,
    426: UpgradeRequired,
    428: PreconditionRequired,
    429: TooManyRequests,
    431: RequestHeaderFieldsTooLarge,
    451: UnavailableForLegalReasons,
    500: InternalServerError,
    501: NotImplemented,
    502: BadGateway,
    503: ServiceUnavailable,
    504: GatewayTimeout,
    505: HttpVersionNotSupported,
    506: VariantAlsoNegotiates,
    507: InsufficientStorage,
    508: LoopDetected,
    510: NotExtended,
    511: NetworkAuthenticationRequired,
}


def abort(status_code_or_response, message: Optional[str] = None, detail: Any = None,
          headers: Optional[Dict[str, str]] = None, context: Optional[Dict[str, Any]] = None,
          error_code: Optional[str] = None):
    """中断请求处理并抛出HTTP异常

    支持多种调用方式:
        abort(404)
        abort(404, "Not found")
        abort(404, detail="Not found", headers={"X-Custom": "value"})
        abort(Response(body="Custom", status=400))

    Args:
        status_code_or_response: HTTP状态码或 Response 对象
        message: 可选的错误消息
        detail: 可选的错误详情
        headers: 可选的额外响应头
        context: 可选的上下文信息
        error_code: 可选的应用级错误码

    Raises:
        HTTPException: 对应状态码的HTTP异常
    """
    if isinstance(status_code_or_response, int):
        status_code = status_code_or_response
    elif hasattr(status_code_or_response, 'status') and hasattr(status_code_or_response, 'body'):
        from kewe.errors.exceptions import _AbortResponse
        raise _AbortResponse(status_code_or_response)
    else:
        raise TypeError(f"abort() expects int or Response, got {type(status_code_or_response)}")

    msg = message
    if 200 <= status_code < 400:
        import warnings
        warnings.warn(
            f"abort() was called with a success status code {status_code}. "
            f"This is not the intended use of abort(). "
            f"Return a Response directly instead.",
            DeprecationWarning,
            stacklevel=2,
        )
    exc_class = _STATUS_CODE_TO_EXCEPTION.get(status_code, KeweException)
    exc = exc_class(msg or f"HTTP {status_code}")
    if detail:
        exc.detail = detail
    if headers:
        exc.headers.update(headers)
    if context:
        exc.context.update(context)
    if error_code:
        exc.error_code = error_code
    raise exc


class _AbortResponse(Exception):
    """内部异常：abort(Response(...)) 的包装"""
    def __init__(self, response):
        self.response = response


__all__ = [
    'KeweException',
    'HTTPException',
    'BadRequest',
    'Unauthorized',
    'PaymentRequired',
    'Forbidden',
    'NotFound',
    'MethodNotAllowed',
    'NotAcceptable',
    'ProxyAuthenticationRequired',
    'RequestTimeout',
    'Conflict',
    'Gone',
    'LengthRequired',
    'PreconditionFailed',
    'PayloadTooLarge',
    'UriTooLong',
    'UnsupportedMediaType',
    'RangeNotSatisfiable',
    'ExpectationFailed',
    'MisdirectedRequest',
    'ImATeapot',
    'UnprocessableEntity',
    'Locked',
    'FailedDependency',
    'TooEarly',
    'UpgradeRequired',
    'PreconditionRequired',
    'TooManyRequests',
    'RequestHeaderFieldsTooLarge',
    'UnavailableForLegalReasons',
    'InternalServerError',
    'NotImplemented',
    'BadGateway',
    'ServiceUnavailable',
    'GatewayTimeout',
    'HttpVersionNotSupported',
    'VariantAlsoNegotiates',
    'InsufficientStorage',
    'LoopDetected',
    'NotExtended',
    'NetworkAuthenticationRequired',
    'RequestValidationError',
    '_AbortResponse',
]
