#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
错误处理辅助函数

提供完整的错误处理机制
使用 RFC 7807 Problem Details 格式
"""

from kewe.utils.compat import json
import logging
import traceback
from typing import Dict, Any, Optional

from kewe.request import Request
from kewe.response import Response

logger = logging.getLogger(__name__)


def format_error_response(
    exception: Exception,
    debug: bool = False,
    include_traceback: bool = False,
    request: Optional[Request] = None
) -> Dict[str, Any]:
    """
    格式化错误响应 - RFC 7807 Problem Details 格式

    Args:
        exception: 异常对象
        debug: 是否调试模式
        include_traceback: 是否包含堆栈跟踪
        request: 请求对象（用于添加上下文信息）

    Returns:
        错误响应字典
    """
    request_path = request.path if request else ""

    if hasattr(exception, 'to_problem_details'):
        response = exception.to_problem_details(request_path)
    else:
        response = {
            'type': 'about:blank',
            'title': type(exception).__name__,
            'status': getattr(exception, 'status', getattr(exception, 'status_code', 500)),
            'detail': str(exception),
        }

    if request:
        response.setdefault('instance', request_path)

    if debug or include_traceback:
        response['traceback'] = traceback.format_exc()

    return response


def get_error_details(exception: Exception) -> Dict[str, Any]:
    """
    获取错误详细信息

    Args:
        exception: 异常对象

    Returns:
        错误详情字典
    """
    return {
        'type': type(exception).__name__,
        'module': type(exception).__module__,
        'message': str(exception),
        'args': exception.args,
        'traceback': traceback.format_exception(
            type(exception), exception, exception.__traceback__
        )
    }


def log_error(
    exception: Exception,
    request: Optional[Request] = None,
    level: str = 'error',
    extra: Optional[Dict] = None
):
    """
    记录错误日志

    Args:
        exception: 异常对象
        request: 请求对象
        level: 日志级别
        extra: 额外信息
    """
    log_data = {
        'exception_type': type(exception).__name__,
        'exception_message': str(exception),
    }

    if request:
        log_data['request'] = {
            'method': request.method,
            'path': request.path,
            'client_ip': getattr(request, 'client_ip', 'unknown'),
        }

    if extra:
        log_data.update(extra)

    log_message = f"{log_data['exception_type']}: {log_data['exception_message']}"

    if level == 'debug':
        logger.debug(log_message, extra=log_data)
    elif level == 'info':
        logger.info(log_message, extra=log_data)
    elif level == 'warning':
        logger.warning(log_message, extra=log_data)
    elif level == 'error':
        logger.error(log_message, extra=log_data, exc_info=True)
    elif level == 'critical':
        logger.critical(log_message, extra=log_data, exc_info=True)


def _merge_exception_headers(exception: Exception, response: Response) -> Response:
    if hasattr(exception, 'get_headers'):
        for key, value in exception.get_headers().items():
            if key.lower() not in response._headers:
                response._headers[key] = value
    return response


def _make_error_response(
    request: Request,
    exception: Exception,
    status: int,
    title: str = None,
) -> Response:
    request_path = request.path if request else ""

    if hasattr(exception, 'to_problem_details'):
        body = exception.to_problem_details(request_path)
    else:
        body = {
            'type': f'https://kewe.dev/errors/{status}',
            'title': title or type(exception).__name__,
            'status': status,
            'detail': str(exception),
            'instance': request_path,
        }

    accept = ''
    if request and hasattr(request, 'headers'):
        accept = request.headers.get('accept', '')

    use_content_negotiation = accept and 'text/html' in accept.lower() and 'application/json' not in accept.lower() and 'application/problem+json' not in accept.lower()

    if use_content_negotiation:
        try:
            from kewe.pages.errorpages import ErrorPage
            error_page = ErrorPage(debug=False)
            render_kw = {
                "status_code": status,
                "message": title or type(exception).__name__,
                "exception": exception,
                "request": request,
                "accept_header": accept,
            }
            response = error_page.render(**render_kw)
            return _merge_exception_headers(exception, response)
        except Exception:
            logger.warning("Error page rendering failed", exc_info=True)

    response = Response(
        body=json.dumps(body, ensure_ascii=False).encode(),
        status=status,
        headers={'Content-Type': 'application/problem+json'}
    )
    return _merge_exception_headers(exception, response)


def setup_error_handlers(app):
    """
    设置默认错误处理器 - RFC 7807 Problem Details 格式

    Args:
        app: Kewe应用实例
    """
    from kewe.errors.exceptions import (
        NotFound, MethodNotAllowed, BadRequest,
        Unauthorized, Forbidden, InternalServerError,
        RequestTimeout, PayloadTooLarge, UnsupportedMediaType,
        TooManyRequests, Conflict, Gone, PreconditionFailed,
        RequestValidationError
    )
    from kewe.routing.converter import ValidationError

    @app.exception(404)
    async def not_found_handler(request: Request, exception: NotFound):
        return _make_error_response(request, exception, status=404, title='Not Found')

    @app.exception(405)
    async def method_not_allowed_handler(request: Request, exception: MethodNotAllowed):
        return _make_error_response(request, exception, status=405, title='Method Not Allowed')

    @app.exception(400)
    async def bad_request_handler(request: Request, exception: BadRequest):
        return _make_error_response(request, exception, status=400, title='Bad Request')

    @app.exception(ValidationError)
    async def validation_error_handler(request: Request, exception: ValidationError):
        return _make_error_response(request, exception, status=400, title='Validation Error')

    @app.exception(RequestValidationError)
    async def request_validation_error_handler(request: Request, exception: RequestValidationError):
        return _make_error_response(request, exception, status=422, title='Request Validation Error')

    @app.exception(401)
    async def unauthorized_handler(request: Request, exception: Unauthorized):
        response = _make_error_response(request, exception, status=401, title='Unauthorized')
        if hasattr(exception, 'www_authenticate'):
            response._headers['WWW-Authenticate'] = exception.www_authenticate
        return response

    @app.exception(403)
    async def forbidden_handler(request: Request, exception: Forbidden):
        return _make_error_response(request, exception, status=403, title='Forbidden')

    @app.exception(408)
    async def request_timeout_handler(request: Request, exception: RequestTimeout):
        return _make_error_response(request, exception, status=408, title='Request Timeout')

    @app.exception(413)
    async def payload_too_large_handler(request: Request, exception: PayloadTooLarge):
        return _make_error_response(request, exception, status=413, title='Payload Too Large')

    @app.exception(415)
    async def unsupported_media_type_handler(request: Request, exception: UnsupportedMediaType):
        return _make_error_response(request, exception, status=415, title='Unsupported Media Type')

    @app.exception(429)
    async def too_many_requests_handler(request: Request, exception: TooManyRequests):
        response = _make_error_response(request, exception, status=429, title='Too Many Requests')
        if hasattr(exception, 'retry_after'):
            response._headers['Retry-After'] = str(exception.retry_after)
        return response

    @app.exception(409)
    async def conflict_handler(request: Request, exception: Conflict):
        return _make_error_response(request, exception, status=409, title='Conflict')

    @app.exception(410)
    async def gone_handler(request: Request, exception: Gone):
        return _make_error_response(request, exception, status=410, title='Gone')

    @app.exception(412)
    async def precondition_failed_handler(request: Request, exception: PreconditionFailed):
        return _make_error_response(request, exception, status=412, title='Precondition Failed')

    @app.exception(500)
    async def server_error_handler(request: Request, exception: InternalServerError):
        log_error(exception, request, level='error')
        return _make_error_response(request, exception, status=500, title='Internal Server Error')

    @app.exception(Exception)
    async def generic_error_handler(request: Request, exception: Exception):
        log_error(exception, request, level='error')
        return _make_error_response(request, exception, status=500, title='Internal Server Error')
