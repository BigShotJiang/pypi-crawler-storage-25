#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
遥测模块 - Telemetry Package
提供分布式追踪和OpenTelemetry集成
"""
from kewe.telemetry.tracing import (
    Span,
    TraceContext,
    get_current_trace,
    set_current_trace,
    generate_trace_id,
    generate_span_id,
    Tracer,
    get_tracer,
    set_tracer,
    TracingMiddleware,
    trace_function,
    trace_span,
)
from kewe.telemetry.otel import (
    OpenTelemetryConfig,
    OpenTelemetryIntegration,
    setup_opentelemetry,
    OTEL_AVAILABLE,
)

__all__ = [
    'Span',
    'TraceContext',
    'get_current_trace',
    'set_current_trace',
    'generate_trace_id',
    'generate_span_id',
    'Tracer',
    'get_tracer',
    'set_tracer',
    'TracingMiddleware',
    'trace_function',
    'trace_span',
    'OpenTelemetryConfig',
    'OpenTelemetryIntegration',
    'setup_opentelemetry',
    'OTEL_AVAILABLE',
]
