#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
请求追踪模块 - Request Tracing
tracing实现，提供OpenTelemetry集成

功能：
- 请求ID追踪
- OpenTelemetry 集成
- 分布式追踪支持
- 性能指标收集
"""
import logging
import time
import uuid
import threading
import functools
import asyncio
from typing import Dict, Any, Optional, Callable, List, ContextManager
from dataclasses import dataclass, field
from datetime import datetime
from contextvars import ContextVar
from contextlib import contextmanager

logger = logging.getLogger(__name__)

_current_trace: ContextVar[Optional['TraceContext']] = ContextVar('current_trace', default=None)
_trace_tokens: ContextVar[list] = ContextVar('trace_tokens', default=[])


@dataclass
class Span:
    """追踪跨度"""
    name: str
    start_time: float
    end_time: Optional[float] = None
    attributes: Dict[str, Any] = field(default_factory=dict)
    events: List[Dict[str, Any]] = field(default_factory=list)
    status: str = "OK"
    
    def set_attribute(self, key: str, value: Any):
        """设置属性"""
        self.attributes[key] = value
    
    def add_event(self, name: str, attributes: Dict[str, Any] = None):
        """添加事件"""
        self.events.append({
            "name": name,
            "timestamp": time.time(),
            "attributes": attributes or {}
        })
    
    def set_status(self, status: str, description: str = None):
        """设置状态"""
        self.status = status
        if description:
            self.attributes["status_description"] = description
    
    def end(self):
        """结束跨度"""
        self.end_time = time.time()
    
    @property
    def duration(self) -> float:
        """获取持续时间（毫秒）"""
        if self.end_time:
            return (self.end_time - self.start_time) * 1000
        return 0


@dataclass
class TraceContext:
    """追踪上下文"""
    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None
    spans: List[Span] = field(default_factory=list)
    _completed_spans: List[Span] = field(default_factory=list)
    attributes: Dict[str, Any] = field(default_factory=dict)
    start_time: float = field(default_factory=time.time)
    tracestate: Dict[str, str] = field(default_factory=dict)
    baggage: Dict[str, str] = field(default_factory=dict)
    
    def current_span(self) -> Optional[Span]:
        """获取当前跨度"""
        return self.spans[-1] if self.spans else None
    
    def start_span(self, name: str) -> Span:
        """开始新跨度"""
        span = Span(
            name=name,
            start_time=time.time()
        )
        self.spans.append(span)
        return span
    
    def end_span(self) -> Optional[Span]:
        """结束当前跨度"""
        if self.spans:
            span = self.spans.pop()
            span.end()
            self._completed_spans.append(span)
            return span
        return None
    
    @property
    def all_spans(self) -> List[Span]:
        """获取所有跨度（含已完成）"""
        return self._completed_spans + self.spans
    
    @property
    def duration(self) -> float:
        """获取总持续时间（毫秒）"""
        return (time.time() - self.start_time) * 1000


_W3C_TRACEPARENT_VERSION = "00"

def parse_traceparent(header_value: str) -> Optional[Dict[str, str]]:
    if not header_value:
        return None
    parts = header_value.strip().split('-')
    if len(parts) != 4:
        return None
    version, trace_id, parent_id, flags = parts
    if version != _W3C_TRACEPARENT_VERSION:
        return None
    if len(trace_id) != 32 or not all(c in '0123456789abcdef' for c in trace_id.lower()):
        return None
    if len(parent_id) != 16 or not all(c in '0123456789abcdef' for c in parent_id.lower()):
        return None
    return {
        'trace_id': trace_id.lower(),
        'parent_span_id': parent_id.lower(),
        'trace_flags': flags,
    }

def format_traceparent(trace_id: str, span_id: str, flags: str = "01") -> str:
    if len(trace_id) > 32:
        trace_id = trace_id[-32:]
    elif len(trace_id) < 32:
        trace_id = trace_id.zfill(32)
    if len(span_id) > 16:
        span_id = span_id[-16:]
    elif len(span_id) < 16:
        span_id = span_id.zfill(16)
    return f"{_W3C_TRACEPARENT_VERSION}-{trace_id}-{span_id}-{flags}"

def parse_tracestate(header_value: str) -> Dict[str, str]:
    if not header_value:
        return {}
    state = {}
    for member in header_value.split(','):
        member = member.strip()
        if '=' in member:
            key, _, value = member.partition('=')
            state[key.strip()] = value.strip()
    return state

def format_tracestate(tracestate: Dict[str, str]) -> str:
    return ','.join(f'{k}={v}' for k, v in tracestate.items())

def parse_baggage(header_value: str) -> Dict[str, str]:
    if not header_value:
        return {}
    baggage = {}
    for item in header_value.split(','):
        item = item.strip()
        if '=' in item:
            key, _, value = item.partition('=')
            baggage[key.strip()] = value.strip()
    return baggage

def format_baggage(baggage: Dict[str, str]) -> str:
    return ','.join(f'{k}={v}' for k, v in baggage.items())


def get_current_trace() -> Optional[TraceContext]:
    return _current_trace.get()


def set_current_trace(trace: TraceContext) -> None:
    """设置当前追踪上下文，使用token模式确保嵌套安全"""
    token = _current_trace.set(trace)
    tokens = _trace_tokens.get([])
    tokens.append(token)
    _trace_tokens.set(tokens)


def generate_trace_id() -> str:
    """生成追踪ID"""
    return uuid.uuid4().hex


def generate_span_id() -> str:
    """生成跨度ID"""
    return uuid.uuid4().hex[:16]


class Tracer:
    """追踪器"""
    
    def __init__(self, service_name: str = "kewe-app"):
        self.service_name = service_name
        self._otel_tracer = None
        self._enabled = True
        self._sample_rate = 1.0
    
    def enable(self):
        """启用追踪"""
        self._enabled = True
    
    def disable(self):
        """禁用追踪"""
        self._enabled = False
    
    def set_sample_rate(self, rate: float):
        """设置采样率"""
        self._sample_rate = max(0.0, min(1.0, rate))
    
    def init_opentelemetry(
        self,
        otlp_endpoint: str = None,
        jaeger_host: str = None,
        jaeger_port: int = 6831
    ):
        """初始化OpenTelemetry"""
        try:
            from opentelemetry import trace
            from opentelemetry.sdk.trace import TracerProvider
            from opentelemetry.sdk.trace.export import BatchSpanProcessor
            from opentelemetry.sdk.resources import Resource
            
            resource = Resource.create({
                "service.name": self.service_name
            })
            
            provider = TracerProvider(resource=resource)
            
            if otlp_endpoint:
                from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
                otlp_exporter = OTLPSpanExporter(endpoint=otlp_endpoint)
                provider.add_span_processor(BatchSpanProcessor(otlp_exporter))
            
            if jaeger_host:
                try:
                    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
                    jaeger_endpoint = f"http://{jaeger_host}:{jaeger_port or 4317}"
                    jaeger_exporter = OTLPSpanExporter(endpoint=jaeger_endpoint)
                    provider.add_span_processor(BatchSpanProcessor(jaeger_exporter))
                except ImportError:
                    logger.warning("OTLP exporter not available for Jaeger integration")
            
            trace.set_tracer_provider(provider)
            self._otel_tracer = trace.get_tracer(__name__)
            
            logger.info(f"OpenTelemetry initialized for {self.service_name}")
            return True
            
        except ImportError:
            logger.warning("OpenTelemetry not installed, using built-in tracing")
            return False
        except Exception as e:
            logger.error(f"Failed to initialize OpenTelemetry: {e}")
            return False
    
    def start_trace(
        self,
        name: str,
        trace_id: str = None,
        parent_span_id: str = None
    ) -> TraceContext:
        """开始追踪"""
        if not self._enabled:
            return None
        
        if trace_id:
            try:
                sampled = (int(trace_id, 16) % 10000) / 10000 < self._sample_rate
            except ValueError:
                import random
                sampled = random.random() < self._sample_rate
        else:
            import random
            sampled = random.random() < self._sample_rate
        if not sampled:
            return None
        
        ctx = TraceContext(
            trace_id=trace_id or generate_trace_id(),
            span_id=generate_span_id(),
            parent_span_id=parent_span_id
        )
        
        ctx.start_span(name)
        set_current_trace(ctx)
        
        return ctx
    
    def end_trace(self) -> Optional[TraceContext]:
        """结束追踪，使用reset(token)恢复外层上下文"""
        ctx = get_current_trace()
        if ctx:
            ctx.end_span()
            tokens = _trace_tokens.get([])
            if tokens:
                token = tokens.pop()
                _current_trace.reset(token)
                _trace_tokens.set(tokens)
            else:
                _current_trace.set(None)
        return ctx
    
    @contextmanager
    def trace(self, name: str, **attributes):
        """追踪上下文管理器"""
        ctx = self.start_trace(name)
        
        if ctx:
            span = ctx.current_span()
            if span:
                for key, value in attributes.items():
                    span.set_attribute(key, value)
        
        try:
            yield ctx
        except Exception as e:
            if ctx and ctx.current_span():
                ctx.current_span().set_status("ERROR", str(e))
                ctx.current_span().add_event("exception", {
                    "type": type(e).__name__,
                    "message": str(e)
                })
            raise
        finally:
            self.end_trace()
    
    def trace_request(self, request):
        trace_id = None
        parent_span_id = None
        tracestate = {}
        baggage = {}

        w3c = parse_traceparent(request.headers.get('traceparent', ''))
        if w3c:
            trace_id = w3c['trace_id']
            parent_span_id = w3c['parent_span_id']
            tracestate = parse_tracestate(request.headers.get('tracestate', ''))
        else:
            trace_id = request.headers.get('x-trace-id')
            parent_span_id = request.headers.get('x-parent-span-id')

        baggage = parse_baggage(request.headers.get('baggage', ''))

        ctx = self.start_trace(
            f"{request.method} {request.path}",
            trace_id=trace_id,
            parent_span_id=parent_span_id
        )

        if ctx:
            ctx.tracestate = tracestate
            ctx.baggage = baggage

        if ctx and ctx.current_span():
            span = ctx.current_span()
            span.set_attribute("http.method", request.method)
            span.set_attribute("http.url", str(request.url) if hasattr(request, 'url') else request.path)
            span.set_attribute("http.path", request.path)
            span.set_attribute("http.host", request.headers.get('host', ''))
            span.set_attribute("http.scheme", request.headers.get('x-forwarded-proto', 'http'))
            span.set_attribute("http.user_agent", request.headers.get('user-agent', ''))
            span.set_attribute("http.client_ip", request.client_ip)
            span.set_attribute("http.flavor", request.headers.get('server-protocol', '1.1').replace('HTTP/', ''))
            content_length = request.headers.get('content-length')
            if content_length:
                span.set_attribute("http.request_content_length", int(content_length))
            content_type = request.headers.get('content-type', '')
            if content_type:
                span.set_attribute("http.request_content_type", content_type)
            span.set_attribute("net.peer.ip", request.client_ip)
        
        return ctx
    
    def trace_response(self, response):
        ctx = get_current_trace()
        if ctx and ctx.current_span():
            span = ctx.current_span()
            span.set_attribute("http.status_code", response.status)
            span.set_attribute("http.response_content_length", len(response.body) if response.body else 0)
            if hasattr(response, 'content_type') and response.content_type:
                span.set_attribute("http.response_content_type", response.content_type)
            
            if response.status >= 500:
                span.set_status("ERROR", f"HTTP {response.status}")
            elif response.status >= 400:
                span.set_status("ERROR", f"HTTP {response.status}")
        
        return ctx


_tracer: Optional[Tracer] = None
_tracer_lock = threading.Lock()


def get_tracer() -> Tracer:
    """获取全局追踪器"""
    global _tracer
    if _tracer is None:
        with _tracer_lock:
            if _tracer is None:
                _tracer = Tracer()
    return _tracer


def set_tracer(tracer: Tracer):
    """设置全局追踪器"""
    global _tracer
    with _tracer_lock:
        _tracer = tracer


class TracingMiddleware:
    """追踪中间件"""
    
    def __init__(
        self,
        service_name: str = "kewe-app",
        sample_rate: float = 1.0,
        trace_request_body: bool = False,
        trace_response_body: bool = False
    ):
        self.tracer = Tracer(service_name)
        self.tracer.set_sample_rate(sample_rate)
        self.trace_request_body = trace_request_body
        self.trace_response_body = trace_response_body
    
    async def __call__(self, request):
        """请求追踪"""
        self.tracer.trace_request(request)
        return True
    
    async def response(self, request, response):
        self.tracer.trace_response(response)
        
        ctx = get_current_trace()
        if ctx:
            response.headers['X-Trace-Id'] = ctx.trace_id
            response.headers['X-Span-Id'] = ctx.span_id
            response.headers['traceparent'] = format_traceparent(ctx.trace_id, ctx.span_id)
            if ctx.tracestate:
                response.headers['tracestate'] = format_tracestate(ctx.tracestate)
            if ctx.baggage:
                response.headers['baggage'] = format_baggage(ctx.baggage)
        
        self.tracer.end_trace()


def trace_function(name: str = None, **attributes):
    """
    函数追踪装饰器
    
    使用示例:
        @trace_function("database_query", db="postgres")
        async def query_database():
            pass
    """
    def decorator(func: Callable) -> Callable:
        span_name = name or func.__name__
        
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            tracer = get_tracer()
            ctx = get_current_trace()
            
            if ctx:
                span = ctx.start_span(span_name)
                for key, value in attributes.items():
                    span.set_attribute(key, value)
            
            try:
                result = await func(*args, **kwargs)
                return result
            except Exception as e:
                if ctx and ctx.current_span():
                    ctx.current_span().set_status("ERROR", str(e))
                    ctx.current_span().add_event("exception", {
                        "type": type(e).__name__,
                        "message": str(e)
                    })
                raise
            finally:
                if ctx:
                    ctx.end_span()
        
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            ctx = get_current_trace()
            
            if ctx:
                span = ctx.start_span(span_name)
                for key, value in attributes.items():
                    span.set_attribute(key, value)
            
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                if ctx and ctx.current_span():
                    ctx.current_span().set_status("ERROR", str(e))
                raise
            finally:
                if ctx:
                    ctx.end_span()
        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper
    
    return decorator


@contextmanager
def trace_span(name: str, **attributes):
    """跨度追踪上下文管理器"""
    ctx = get_current_trace()
    
    if ctx:
        span = ctx.start_span(name)
        for key, value in attributes.items():
            span.set_attribute(key, value)
    
    try:
        yield span if ctx else None
    finally:
        if ctx:
            ctx.end_span()


__all__ = [
    'Tracer',
    'TraceContext',
    'Span',
    'TracingMiddleware',
    'get_tracer',
    'set_tracer',
    'get_current_trace',
    'set_current_trace',
    'trace_function',
    'trace_span',
    'generate_trace_id',
    'generate_span_id',
]
