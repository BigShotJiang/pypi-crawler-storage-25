#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
WebSocket测试支持 - WebSocket Testing Support
提供WebSocket测试客户端和测试工具
"""
import asyncio
from kewe.utils.compat import json
import logging
from typing import Any, Callable, Dict, List, Optional, Union, AsyncGenerator
from dataclasses import dataclass, field
import time

from .connection import WebSocketState, WebSocketMessage

logger = logging.getLogger(__name__)





class WebSocketTestClient:
    """
    WebSocket测试客户端
    用于测试WebSocket端点
    """
    
    def __init__(self, app):
        self.app = app
        self.state = WebSocketState.CLOSED
        self.messages: List[WebSocketMessage] = []
        self.sent_messages: List[WebSocketMessage] = []
        self._receive_queue: asyncio.Queue = asyncio.Queue()
        self._send_queue: asyncio.Queue = asyncio.Queue()
        self._handlers: Dict[str, List[Callable]] = {
            'message': [],
            'connect': [],
            'disconnect': [],
            'error': [],
        }
        self._close_code: Optional[int] = None
        self._close_reason: Optional[str] = None
        self._subprotocol: Optional[str] = None
        self._headers: Dict[str, str] = {}
    
    async def connect(
        self,
        path: str,
        headers: Dict[str, str] = None,
        subprotocols: List[str] = None
    ) -> bool:
        """
        连接到WebSocket端点
        
        Args:
            path: WebSocket路径
            headers: 请求头
            subprotocols: 子协议列表
            
        Returns:
            是否连接成功
        """
        self.state = WebSocketState.CONNECTING
        self._headers = headers or {}
        
        try:
            # 创建模拟请求
            from kewe.request import Request
            from kewe.websocket import WebSocketProtocol
            
            # 构建请求
            request = Request(
                method="GET",
                path=path,
                headers={
                    "Host": "localhost",
                    "Upgrade": "websocket",
                    "Connection": "Upgrade",
                    "Sec-WebSocket-Key": "dGhlIHNhbXBsZSBub25jZQ==",
                    "Sec-WebSocket-Version": "13",
                    **self._headers
                },
                query_params={},
                body=b"",
                client_ip="127.0.0.1",
            )
            
            if subprotocols:
                request.headers["Sec-WebSocket-Protocol"] = ", ".join(subprotocols)
            
            # 查找WebSocket处理器
            route = self.app.router.find_route(path, "GET")
            if not route:
                raise ValueError(f"No WebSocket handler found for path: {path}")
            
            handler = route["handler"]
            
            # 创建WebSocket协议实例
            self.ws_protocol = WebSocketProtocol(
                subprotocols=subprotocols,
            )
            self.ws_protocol._test_mode = True
            self.ws_protocol._test_client = self
            self.ws_protocol._request = request
            
            # 启动处理器
            self.state = WebSocketState.OPEN
            
            # 触发连接事件
            await self._trigger_event('connect')
            
            # 启动消息处理循环
            self._handler_task = asyncio.create_task(
                self._run_handler(handler, request)
            )
            
            return True
            
        except Exception as e:
            self.state = WebSocketState.CLOSED
            logger.error(f"WebSocket connection failed: {e}")
            await self._trigger_event('error', e)
            return False
    
    async def _run_handler(self, handler: Callable, request):
        try:
            import inspect
            sig = inspect.signature(handler)
            params = list(sig.parameters.keys())
            if len(params) >= 2:
                await handler(request, self.ws_protocol)
            else:
                await handler(self.ws_protocol)
        except Exception as e:
            logger.error(f"WebSocket handler error: {e}")
            await self._trigger_event('error', e)
        finally:
            await self.close()
    
    async def send(self, data: Union[str, bytes, dict]):
        """
        发送消息
        
        Args:
            data: 要发送的数据
        """
        if self.state != WebSocketState.OPEN:
            raise RuntimeError("WebSocket is not open")
        
        # 转换数据
        if isinstance(data, dict):
            data = json.dumps(data)
        
        message = WebSocketMessage(
            type="text" if isinstance(data, str) else "binary",
            data=data
        )
        
        self.sent_messages.append(message)
        
        # 放入接收队列，模拟服务器接收
        await self._receive_queue.put(message)
    
    async def receive(self, timeout: float = 5.0) -> Optional[WebSocketMessage]:
        """
        接收消息
        
        Args:
            timeout: 超时时间（秒）
            
        Returns:
            WebSocket消息或None
        """
        if self.state != WebSocketState.OPEN:
            return None
        
        try:
            message = await asyncio.wait_for(
                self._send_queue.get(),
                timeout=timeout
            )
            return message
        except asyncio.TimeoutError:
            return None
    
    async def receive_text(self, timeout: float = 5.0) -> Optional[str]:
        """接收文本消息"""
        message = await self.receive(timeout)
        if message and message.type == "text":
            return message.data if isinstance(message.data, str) else message.data.decode('utf-8')
        return None
    
    async def receive_json(self, timeout: float = 5.0) -> Optional[dict]:
        """接收JSON消息"""
        text = await self.receive_text(timeout)
        if text:
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                pass
        return None
    
    async def receive_binary(self, timeout: float = 5.0) -> Optional[bytes]:
        """接收二进制消息"""
        message = await self.receive(timeout)
        if message and message.type == "binary":
            return message.data if isinstance(message.data, bytes) else message.data.encode('utf-8')
        return None
    
    async def ping(self, data: bytes = b""):
        """发送ping帧"""
        message = WebSocketMessage(type="ping", data=data)
        await self._receive_queue.put(message)
    
    async def pong(self, data: bytes = b""):
        """发送pong帧"""
        message = WebSocketMessage(type="pong", data=data)
        await self._receive_queue.put(message)
    
    async def close(self, code: int = 1000, reason: str = ""):
        """
        关闭连接
        
        Args:
            code: 关闭代码
            reason: 关闭原因
        """
        if self.state in (WebSocketState.CLOSING, WebSocketState.CLOSED):
            return
        
        self.state = WebSocketState.CLOSING
        self._close_code = code
        self._close_reason = reason
        
        # 发送关闭消息
        message = WebSocketMessage(
            type="close",
            data=json.dumps({"code": code, "reason": reason})
        )
        await self._receive_queue.put(message)
        
        self.state = WebSocketState.CLOSED
        
        # 触发断开事件
        await self._trigger_event('disconnect', code, reason)
    
    def on(self, event: str, handler: Callable):
        """注册事件处理器"""
        if event not in self._handlers:
            self._handlers[event] = []
        self._handlers[event].append(handler)
        return handler
    
    async def _trigger_event(self, event: str, *args):
        """触发事件"""
        for handler in self._handlers.get(event, []):
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(*args)
                else:
                    handler(*args)
            except Exception as e:
                logger.error(f"Event handler error: {e}")
    
    # 模拟服务器发送消息到客户端
    async def _server_send(self, data: Union[str, bytes]):
        """模拟服务器发送消息"""
        message = WebSocketMessage(
            type="text" if isinstance(data, str) else "binary",
            data=data
        )
        self.messages.append(message)
        await self._send_queue.put(message)
        await self._trigger_event('message', message)
    
    @property
    def is_connected(self) -> bool:
        """是否已连接"""
        return self.state == WebSocketState.OPEN
    
    @property
    def close_code(self) -> Optional[int]:
        """关闭代码"""
        return self._close_code
    
    @property
    def close_reason(self) -> Optional[str]:
        """关闭原因"""
        return self._close_reason
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()


class WebSocketTestHelper:
    """
    WebSocket测试辅助工具
    """
    
    @staticmethod
    def create_test_message(data: Union[str, bytes, dict], message_type: str = "text") -> WebSocketMessage:
        """创建测试消息"""
        if isinstance(data, dict):
            data = json.dumps(data)
        return WebSocketMessage(type=message_type, data=data)
    
    @staticmethod
    async def test_websocket_endpoint(
        app,
        path: str,
        test_func: Callable[[WebSocketTestClient], Any],
        headers: Dict[str, str] = None
    ) -> Any:
        """
        测试WebSocket端点
        
        Args:
            app: Kewe应用实例
            path: WebSocket路径
            test_func: 测试函数
            headers: 请求头
            
        Returns:
            测试结果
        """
        client = WebSocketTestClient(app)
        
        try:
            connected = await client.connect(path, headers=headers)
            if not connected:
                raise ConnectionError(f"Failed to connect to {path}")
            
            result = await test_func(client)
            return result
        finally:
            await client.close()
    
    @staticmethod
    async def echo_test(app, path: str, message: str) -> str:
        """
        回声测试
        
        Args:
            app: Kewe应用实例
            path: WebSocket路径
            message: 测试消息
            
        Returns:
            响应消息
        """
        async def test(client: WebSocketTestClient):
            await client.send(message)
            return await client.receive_text()
        
        return await WebSocketTestHelper.test_websocket_endpoint(app, path, test)
    
    @staticmethod
    async def broadcast_test(
        app,
        path: str,
        num_clients: int = 3,
        message: str = "broadcast"
    ) -> List[str]:
        """
        广播测试
        
        Args:
            app: Kewe应用实例
            path: WebSocket路径
            num_clients: 客户端数量
            message: 广播消息
            
        Returns:
            各客户端接收的消息列表
        """
        clients: List[WebSocketTestClient] = []
        
        try:
            # 连接所有客户端
            for i in range(num_clients):
                client = WebSocketTestClient(app)
                connected = await client.connect(path)
                if not connected:
                    raise ConnectionError(f"Client {i} failed to connect")
                clients.append(client)
            
            # 发送广播消息
            await clients[0].send(message)
            
            # 收集响应
            responses = []
            for client in clients:
                response = await client.receive_text(timeout=2.0)
                responses.append(response)
            
            return responses
        finally:
            for client in clients:
                await client.close()


# 装饰器支持
def websocket_test(path: str, **kwargs):
    """
    WebSocket测试装饰器
    
    使用示例:
        @websocket_test("/ws")
        async def test_my_websocket(client: WebSocketTestClient):
            await client.send("hello")
            response = await client.receive_text()
            assert response == "hello"
    """
    def decorator(func: Callable):
        async def wrapper(app, *args, **func_kwargs):
            return await WebSocketTestHelper.test_websocket_endpoint(
                app, path,
                lambda client: func(client, *args, **func_kwargs),
                **kwargs
            )
        return wrapper
    return decorator


try:
    import pytest

    @pytest.fixture
    async def websocket_client(app):
        """WebSocket测试客户端fixture"""
        client = WebSocketTestClient(app)
        yield client
        await client.close()

    @pytest.fixture
    def ws_helper():
        """WebSocket测试辅助工具fixture"""
        return WebSocketTestHelper()
except ImportError:
    websocket_client = None  # type: ignore
    ws_helper = None  # type: ignore
