#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
WebSocket完整支持模块
WebSocket实现
"""
from .protocol import WebSocketProtocol, WebSocketOpCode
from .connection import WebSocketConnection, WebSocketState, WebSocketMessage
from .manager import WebSocketManager, websocket_manager, get_websocket_manager, set_websocket_manager
from .handler import WebSocketHandler, websocket, broadcast, broadcast_to_group, get_connection_count
from .exceptions import (
    WebSocketException,
    WebSocketClosed,
    WebSocketDisconnect,
    WebSocketProtocolError,
    WebSocketHandshakeError,
    WebSocketTimeout,
)
try:
    from .testing import (
        WebSocketState as TestWebSocketState,
        WebSocketMessage as TestWebSocketMessage,
        WebSocketTestClient,
        WebSocketTestHelper,
        websocket_test,
        ws_helper,
    )
except ImportError:
    TestWebSocketState = None  # type: ignore
    TestWebSocketMessage = None  # type: ignore
    WebSocketTestClient = None  # type: ignore
    WebSocketTestHelper = None  # type: ignore
    websocket_test = None  # type: ignore
    ws_helper = None  # type: ignore

__all__ = [
    'WebSocketProtocol',
    'WebSocketOpCode',
    'WebSocketConnection',
    'WebSocketState',
    'WebSocketMessage',
    'WebSocketManager',
    'websocket_manager',
    'get_websocket_manager',
    'set_websocket_manager',
    'WebSocketHandler',
    'websocket',
    'broadcast',
    'broadcast_to_group',
    'get_connection_count',
    'WebSocketException',
    'WebSocketClosed',
    'WebSocketDisconnect',
    'WebSocketProtocolError',
    'WebSocketHandshakeError',
    'WebSocketTimeout',
    'TestWebSocketState',
    'TestWebSocketMessage',
    'WebSocketTestClient',
    'WebSocketTestHelper',
    'websocket_test',
    'ws_helper',
]
