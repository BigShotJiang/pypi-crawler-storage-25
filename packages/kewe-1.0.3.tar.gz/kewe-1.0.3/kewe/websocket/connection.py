#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
WebSocket连接管理
"""
import asyncio
from kewe.utils.compat import json
import logging
import uuid
from typing import Dict, Any, Optional, Callable, Union, List
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from .protocol import WebSocketProtocol, WebSocketOpCode
from .exceptions import WebSocketClosed, WebSocketTimeout, WebSocketException

logger = logging.getLogger(__name__)


class WebSocketState(Enum):
    """WebSocket连接状态"""
    CONNECTING = 0
    OPEN = 1
    CLOSING = 2
    CLOSED = 3


@dataclass
class WebSocketMessage:
    """WebSocket消息"""
    type: str
    data: Union[str, bytes]
    timestamp: datetime = field(default_factory=datetime.now)


class WebSocketConnection:
    __slots__ = (
        '_asgi_mode', '_asgi_scope', '_asgi_receive', '_asgi_send',
        '_asgi_accepted', '_allowed_origins', 'protocol', 'request',
        'id', '_state', '_close_code', '_close_reason', '_close_sent',
        '_metadata', '_message_queue', '_receive_task', '_event_handlers',
    )
    
    def __init__(self, protocol=None, request=None, *, _asgi_scope=None, _asgi_receive=None, _asgi_send=None, allowed_origins: Optional[List[str]] = None):
        self._asgi_mode = _asgi_scope is not None
        self._asgi_scope = _asgi_scope
        self._asgi_receive = _asgi_receive
        self._asgi_send = _asgi_send
        self._asgi_accepted = False
        self._allowed_origins = allowed_origins

        if protocol is not None:
            self.protocol = protocol
        else:
            from kewe.websocket.protocol import WebSocketProtocol
            self.protocol = WebSocketProtocol()

        self.request = request
        self.id = str(uuid.uuid4())
        self._state = WebSocketState.CONNECTING
        self._close_code: Optional[int] = None
        self._close_reason: str = ''
        self._close_sent: bool = False
        self._metadata: Dict[str, Any] = {}
        self._message_queue: asyncio.Queue = asyncio.Queue()
        self._receive_task: Optional[asyncio.Task] = None
        self._event_handlers: Dict[str, List[Callable]] = {
            'message': [],
            'binary': [],
            'close': [],
            'error': [],
            'ping': [],
            'pong': [],
        }
    
    @property
    def path_params(self) -> Dict[str, Any]:
        """获取路径参数websocket.path_params"""
        if self._asgi_scope and 'path_params' in self._asgi_scope:
            return self._asgi_scope['path_params']
        if self.request and hasattr(self.request, 'ctx') and hasattr(self.request.ctx, 'path_params'):
            return self.request.ctx.path_params
        return {}

    @property
    def query_params(self) -> Dict[str, str]:
        """获取查询参数websocket.query_params"""
        if self._asgi_scope and 'query_string' in self._asgi_scope:
            from urllib.parse import parse_qs
            qs = self._asgi_scope.get('query_string', b'')
            if isinstance(qs, bytes):
                qs = qs.decode('utf-8')
            parsed = parse_qs(qs)
            return {k: v[0] for k, v in parsed.items()}
        if self.request and hasattr(self.request, 'query_params'):
            qp = self.request.query_params
            if isinstance(qp, dict):
                return {k: (v[0] if isinstance(v, list) and v else str(v)) for k, v in qp.items()}
            return dict(qp)
        return {}

    @property
    def scope(self) -> Optional[Dict[str, Any]]:
        """获取ASGI scopewebsocket.scope"""
        return self._asgi_scope

    @property
    def app(self):
        """获取应用实例websocket.app"""
        if self._asgi_scope and 'app' in self._asgi_scope:
            return self._asgi_scope['app']
        if self.request and hasattr(self.request, 'app'):
            return self.request.app
        return None

    @property
    def headers(self) -> Dict[str, str]:
        """获取请求头websocket.headers"""
        if self._asgi_scope and 'headers' in self._asgi_scope:
            raw = self._asgi_scope['headers']
            return {k.decode() if isinstance(k, bytes) else k: v.decode() if isinstance(v, bytes) else v for k, v in raw}
        if self.request and hasattr(self.request, 'headers'):
            h = self.request.headers
            if isinstance(h, dict):
                return h
            return dict(h)
        return {}
    
    async def __aenter__(self):
        """异步上下文管理器入口"""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口"""
        await self.close()

    async def accept(self, subprotocol: Optional[str] = None, headers: Optional[list] = None):
        """接受WebSocket连接 - 

        必须在发送任何消息之前调用此方法。
        在ASGI模式下，发送websocket.accept消息。
        在原始协议模式下，发送握手响应。
        
        支持 Origin 验证，防止跨站 WebSocket 劫持 (CSWSH)
        
        Args:
            subprotocol: 子协议
            headers:  - accept时发送的额外headers (Iterable[Tuple[str, str]])
        """
        if self._state != WebSocketState.CONNECTING:
            raise RuntimeError(f"Cannot accept: connection state is {self._state.name}, expected CONNECTING")

        if self._allowed_origins:
            origin = None
            if self._asgi_scope:
                scope_headers = dict(self._asgi_scope.get('headers', []))
                origin = scope_headers.get(b'origin', b'').decode('utf-8')
            elif self.request:
                origin = self.request.headers.get('origin', '')
            
            if origin and origin not in self._allowed_origins and '*' not in self._allowed_origins:
                if self._asgi_mode and not self._asgi_accepted:
                    reject_msg = {'type': 'websocket.close', 'code': 1008, 'reason': 'Origin not allowed'}
                    await self._asgi_send(reject_msg)
                self._state = WebSocketState.CLOSED
                raise PermissionError(f"WebSocket connection from origin '{origin}' is not allowed")

        if self._asgi_mode:
            if not self._asgi_accepted:
                try:
                    connect_msg = await self._asgi_receive()
                    if connect_msg.get('type') == 'websocket.close':
                        self._state = WebSocketState.CLOSED
                        return
                except Exception:
                    self._state = WebSocketState.CLOSED
                    return
            accept_msg = {'type': 'websocket.accept'}
            if subprotocol:
                accept_msg['subprotocol'] = subprotocol
            if headers:
                accept_msg['headers'] = [(k.encode(), v.encode()) if isinstance(k, str) else (k, v) for k, v in headers]
            await self._asgi_send(accept_msg)
            self._asgi_accepted = True
        else:
            if hasattr(self.protocol, 'accept'):
                await self.protocol.accept(subprotocol)

        self._state = WebSocketState.OPEN
    
    # ========== 接收消息 ==========
    
    async def receive(self, timeout: Optional[float] = None) -> Optional[Union[str, bytes]]:
        if self._asgi_mode:
            return await self._asgi_receive_any(timeout)
        try:
            result = await asyncio.wait_for(
                self.protocol.receive(),
                timeout=timeout
            )
            if result is None:
                self._state = WebSocketState.CLOSED
                return None
            
            opcode, data = result
            
            if opcode == WebSocketOpCode.TEXT.value:
                return data.decode('utf-8')
            elif opcode == WebSocketOpCode.BINARY.value:
                return data
            
            return None
            
        except asyncio.TimeoutError:
            raise WebSocketTimeout("Receive timeout")
    
    async def receive_binary(self, timeout: Optional[float] = None) -> Optional[bytes]:
        if self._asgi_mode:
            return await self._asgi_receive_binary(timeout)
        try:
            result = await asyncio.wait_for(
                self.protocol.receive(),
                timeout=timeout
            )
            if result is None:
                self._state = WebSocketState.CLOSED
                return None
            
            opcode, data = result
            
            if opcode == WebSocketOpCode.BINARY.value:
                return data
            
            return None
            
        except asyncio.TimeoutError:
            raise WebSocketTimeout("Receive timeout")

    async def receive_json(self, timeout: Optional[float] = None, mode: str = "text") -> Optional[Dict]:
        """接收JSON消息

        Args:
            timeout: 超时时间
            mode:  - "text" 或 "binary"
        """
        if mode == "binary":
            data = await self.receive_binary(timeout)
            if data is None:
                return None
            try:
                return json.loads(data.decode('utf-8') if isinstance(data, bytes) else data)
            except json.JSONDecodeError as e:
                raise WebSocketException(f"Invalid JSON: {e}") from e
        text = await self.receive(timeout)
        if text is None:
            return None
        if isinstance(text, bytes):
            raise WebSocketException("Expected text frame, got binary")
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise WebSocketException(f"Invalid JSON: {e}") from e
    
    # ========== 发送消息 ==========
    
    async def send(self, message: str):
        if self._state != WebSocketState.OPEN:
            raise WebSocketClosed()
        if self._asgi_mode:
            await self._asgi_send({
                'type': 'websocket.send',
                'text': message
            })
        else:
            await self.protocol.send_text(message)
    
    async def send_binary(self, data: bytes):
        if self._state != WebSocketState.OPEN:
            raise WebSocketClosed()
        if self._asgi_mode:
            await self._asgi_send({
                'type': 'websocket.send',
                'bytes': data
            })
        else:
            await self.protocol.send_binary(data)

    async def send_json(self, data: Dict, mode: str = "text"):
        """发送JSON消息

        Args:
            data: 要发送的数据
            mode:  - "text" 或 "binary"
        """
        if mode == "binary":
            await self.send_binary(json.dumps(data).encode('utf-8'))
        else:
            await self.send(json.dumps(data))
    
    async def receive_text(self, timeout: Optional[float] = None) -> Optional[str]:
        """接收文本消息"""
        result = await self.receive(timeout)
        if result is None:
            return None
        if isinstance(result, bytes):
            raise WebSocketException("Expected text frame, got binary")
        return result
    
    @property
    def client(self) -> Optional[tuple]:
        """客户端地址 (host, port)"""
        if self._asgi_scope and 'client' in self._asgi_scope:
            return tuple(self._asgi_scope['client'])
        if self.request and hasattr(self.request, 'client_ip'):
            return (self.request.client_ip, 0)
        return None
    
    async def ping(self, data: bytes = b''):
        if self._state != WebSocketState.OPEN:
            raise WebSocketClosed()
        if self._asgi_mode:
            await self._asgi_send({'type': 'websocket.ping', 'bytes': data})
        else:
            await self.protocol.send(WebSocketOpCode.PING.value, data)
    
    async def pong(self, data: bytes = b''):
        if self._state != WebSocketState.OPEN:
            raise WebSocketClosed()
        if self._asgi_mode:
            await self._asgi_send({'type': 'websocket.pong', 'bytes': data})
        else:
            await self.protocol.send(WebSocketOpCode.PONG.value, data)
    
    # ========== 事件处理 ==========
    
    def on(self, event: str, handler: Callable):
        """
        注册事件处理器
        
        Args:
            event: 事件类型（message, binary, close, error, ping, pong）
            handler: 处理函数
        """
        if event in self._event_handlers:
            self._event_handlers[event].append(handler)
    
    def off(self, event: str, handler: Callable):
        """
        移除事件处理器
        
        Args:
            event: 事件类型
            handler: 处理函数
        """
        if event in self._event_handlers and handler in self._event_handlers[event]:
            self._event_handlers[event].remove(handler)
    
    async def _emit(self, event: str, *args, **kwargs):
        """触发事件"""
        for handler in self._event_handlers.get(event, []):
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(*args, **kwargs)
                else:
                    handler(*args, **kwargs)
            except Exception as e:
                logger.error(f"Event handler error: {e}")
    
    # ========== 连接管理 ==========
    
    async def close(self, code: int = 1000, reason: str = ""):
        if self._state in (WebSocketState.CLOSING, WebSocketState.CLOSED):
            return
        
        if len(reason.encode('utf-8')) > 123:
            reason = reason.encode('utf-8')[:123].decode('utf-8', errors='ignore')
        
        self._state = WebSocketState.CLOSING
        
        try:
            if self._asgi_mode:
                await self._asgi_send({
                    'type': 'websocket.close',
                    'code': code,
                    'reason': reason
                })
                self._close_sent = True
            else:
                await self.protocol.close(code, reason)
            await self._emit('close', code, reason)
        except Exception as e:
            logger.error(f"Error closing WebSocket: {e}")
        finally:
            self._state = WebSocketState.CLOSED
    
    # ========== ASGI 模式接收方法 ==========
    
    async def _asgi_receive_any(self, timeout: Optional[float] = None) -> Optional[Union[str, bytes]]:
        if self._asgi_receive is None:
            return None
        try:
            message = await asyncio.wait_for(self._asgi_receive(), timeout=timeout)
        except asyncio.TimeoutError:
            raise WebSocketTimeout("Receive timeout")
        
        msg_type = message.get('type')
        if msg_type == 'websocket.disconnect':
            self._state = WebSocketState.CLOSED
            code = message.get('code', 1000)
            reason = message.get('reason', '')
            from kewe.websocket.exceptions import WebSocketDisconnect
            raise WebSocketDisconnect(code=code, reason=reason)
        if msg_type == 'websocket.receive':
            text = message.get('text')
            if text is not None:
                return text
            binary = message.get('bytes')
            if binary is not None:
                return binary
        return None

    async def _asgi_receive_text(self, timeout: Optional[float] = None) -> Optional[str]:
        if self._asgi_receive is None:
            return None
        try:
            message = await asyncio.wait_for(self._asgi_receive(), timeout=timeout)
        except asyncio.TimeoutError:
            raise WebSocketTimeout("Receive timeout")
        
        msg_type = message.get('type')
        if msg_type == 'websocket.disconnect':
            self._state = WebSocketState.CLOSED
            code = message.get('code', 1000)
            reason = message.get('reason', '')
            from kewe.websocket.exceptions import WebSocketDisconnect
            raise WebSocketDisconnect(code=code, reason=reason)
        if msg_type == 'websocket.receive':
            text = message.get('text')
            if text is not None:
                return text
            binary = message.get('bytes')
            if binary is not None:
                try:
                    return binary.decode('utf-8')
                except UnicodeDecodeError:
                    from kewe.websocket.exceptions import WebSocketProtocolError
                    raise WebSocketProtocolError(
                        code=1003,
                        reason="Received binary frame cannot be decoded as UTF-8 text. Use receive_bytes() instead."
                    )
        return None
    
    async def _asgi_receive_binary(self, timeout: Optional[float] = None) -> Optional[bytes]:
        if self._asgi_receive is None:
            return None
        try:
            message = await asyncio.wait_for(self._asgi_receive(), timeout=timeout)
        except asyncio.TimeoutError:
            raise WebSocketTimeout("Receive timeout")
        
        msg_type = message.get('type')
        if msg_type == 'websocket.disconnect':
            self._state = WebSocketState.CLOSED
            code = message.get('code', 1000)
            reason = message.get('reason', '')
            from kewe.websocket.exceptions import WebSocketDisconnect
            raise WebSocketDisconnect(code=code, reason=reason)
        if msg_type == 'websocket.receive':
            binary = message.get('bytes')
            if binary is not None:
                return binary
            text = message.get('text')
            if text is not None:
                return text.encode('utf-8')
        return None
    
    # ========== 属性 ==========
    
    @property
    def state(self) -> WebSocketState:
        """连接状态"""
        return self._state
    
    @property
    def open(self) -> bool:
        """连接是否打开"""
        return self._state == WebSocketState.OPEN
    
    @property
    def closed(self) -> bool:
        """连接是否已关闭"""
        return self._state == WebSocketState.CLOSED
    
    @property
    def subprotocol(self) -> Optional[str]:
        """协商的子协议"""
        return self.protocol.subprotocol
    
    @property
    def close_code(self) -> Optional[int]:
        if self._asgi_mode:
            return getattr(self, '_close_code', None)
        return self.protocol.close_code
    
    @property
    def close_reason(self) -> Optional[str]:
        if self._asgi_mode:
            return getattr(self, '_close_reason', None)
        return self.protocol.close_reason
    
    def __getitem__(self, key: str) -> Any:
        """获取元数据"""
        return self._metadata.get(key)
    
    def __setitem__(self, key: str, value: Any):
        """设置元数据"""
        self._metadata[key] = value



