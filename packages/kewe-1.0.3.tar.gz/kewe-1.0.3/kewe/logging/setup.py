#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
日志系统设置 - logging实现
"""
import logging
import sys
from typing import Optional

from .formatters import ColoredFormatter, JSONFormatter
from .filters import AccessLogFilter


def setup_logging(
    level: int = logging.INFO,
    json_format: bool = False,
    access_log: bool = True,
    error_log: bool = True,
    log_config: Optional[dict] = None
) -> None:
    """
    设置日志系统
    
    Args:
        level: 日志级别
        json_format: 是否使用JSON格式
        access_log: 是否启用访问日志
        error_log: 是否启用错误日志
        log_config: 自定义日志配置字典
    """
    if log_config:
        logging.config.dictConfig(log_config)
        return
    
    # 根日志器配置 - 使用WARNING级别，让子logger自己控制
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.WARNING)
    
    # 清除现有处理器
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # 设置格式
    if json_format:
        formatter = JSONFormatter()
    else:
        formatter = ColoredFormatter(
            fmt='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
    
    # 主日志器 kewe - 所有kewe.*子logger的父级
    kewe_logger = logging.getLogger("kewe")
    kewe_logger.setLevel(level)
    kewe_logger.propagate = False  # 不向root传播
    
    # 清除现有处理器
    for handler in kewe_logger.handlers[:]:
        kewe_logger.removeHandler(handler)
    
    # 控制台处理器
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    kewe_logger.addHandler(console_handler)
    
    # 访问日志器 - 独立于主日志器
    if access_log:
        access_logger = logging.getLogger("kewe.access")
        access_logger.setLevel(logging.INFO)
        access_logger.propagate = False
        
        # 清除现有处理器
        for handler in access_logger.handlers[:]:
            access_logger.removeHandler(handler)
        
        access_handler = logging.StreamHandler(sys.stdout)
        access_handler.setLevel(logging.INFO)
        access_handler.addFilter(AccessLogFilter())
        
        if json_format:
            access_formatter = JSONFormatter()
        else:
            access_formatter = logging.Formatter(
                '%(client_ip)s - - [%(asctime)s] "%(method)s %(path)s" %(status)s'
            )
        
        access_handler.setFormatter(access_formatter)
        access_logger.addHandler(access_handler)
    
    # 错误日志器 - 独立于主日志器
    if error_log:
        error_logger = logging.getLogger("kewe.error")
        error_logger.setLevel(logging.ERROR)
        error_logger.propagate = False
        
        # 清除现有处理器
        for handler in error_logger.handlers[:]:
            error_logger.removeHandler(handler)
        
        error_handler = logging.StreamHandler(sys.stderr)
        error_handler.setLevel(logging.ERROR)
        
        if json_format:
            error_formatter = JSONFormatter()
        else:
            error_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
        
        error_handler.setFormatter(error_formatter)
        error_logger.addHandler(error_handler)


def reset_logging() -> None:
    """重置日志系统到默认状态"""
    root_logger = logging.getLogger()
    
    # 清除所有处理器
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # 重置kewe相关日志器
    for name in ["kewe", "kewe.access", "kewe.error"]:
        logger = logging.getLogger(name)
        logger.setLevel(logging.WARNING)
        for handler in logger.handlers[:]:
            logger.removeHandler(handler)
