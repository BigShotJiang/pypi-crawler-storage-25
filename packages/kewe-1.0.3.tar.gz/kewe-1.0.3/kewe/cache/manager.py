# -*- coding: utf-8 -*-
import logging
import asyncio
from typing import Any, Dict, Optional
import threading

from .backends import CacheBackend, MemoryCache

logger = logging.getLogger(__name__)


class CacheManager:

    def __init__(self, backend: str = "memory"):
        self._backends: Dict[str, CacheBackend] = {}
        self._default_backend = backend
        self._lock = threading.Lock()
        self._async_lock: Optional[asyncio.Lock] = None
        self._init_default_backends()

    def _init_default_backends(self):
        self._backends["memory"] = MemoryCache()

    def add_backend(self, name: str, backend: CacheBackend):
        with self._lock:
            self._backends[name] = backend

    def set_default_backend(self, name: str):
        with self._lock:
            if name not in self._backends:
                raise ValueError(f"Backend '{name}' not found")
            self._default_backend = name

    def get_backend(self, name: str = None) -> CacheBackend:
        with self._lock:
            name = name or self._default_backend
            if name not in self._backends:
                raise ValueError(f"Backend '{name}' not found")
            return self._backends[name]

    def get(self, key: str, backend: str = None) -> Optional[Any]:
        return self.get_backend(backend).get(key)

    def set(self, key: str, value: Any, ttl: int = None, backend: str = None):
        self.get_backend(backend).set(key, value, ttl)

    def delete(self, key: str, backend: str = None):
        self.get_backend(backend).delete(key)

    def clear(self, backend: str = None):
        if backend:
            self.get_backend(backend).clear()
        else:
            for b in self._backends.values():
                b.clear()

    def exists(self, key: str, backend: str = None) -> bool:
        return self.get_backend(backend).exists(key)

    async def aget(self, key: str, backend: str = None) -> Optional[Any]:
        b = self._backends.get(backend or self._default_backend)
        if b is None:
            raise ValueError(f"Backend '{backend or self._default_backend}' not found")
        return await b.aget(key)

    async def aset(self, key: str, value: Any, ttl: int = None, backend: str = None):
        b = self._backends.get(backend or self._default_backend)
        if b is None:
            raise ValueError(f"Backend '{backend or self._default_backend}' not found")
        await b.aset(key, value, ttl)

    async def adelete(self, key: str, backend: str = None):
        b = self._backends.get(backend or self._default_backend)
        if b is None:
            raise ValueError(f"Backend '{backend or self._default_backend}' not found")
        await b.adelete(key)

    async def aclear(self, backend: str = None):
        if backend:
            await self.get_backend(backend).aclear()
        else:
            for b in self._backends.values():
                await b.aclear()

    async def aexists(self, key: str, backend: str = None) -> bool:
        return await self.get_backend(backend).aexists(key)

    async def aclose(self):
        for name, backend in list(self._backends.items()):
            try:
                if hasattr(backend, 'aclose'):
                    await backend.aclose()
                elif hasattr(backend, 'close'):
                    result = backend.close()
                    if asyncio.iscoroutine(result):
                        await result
                elif hasattr(backend, 'shutdown'):
                    result = backend.shutdown()
                    if asyncio.iscoroutine(result):
                        await result
            except Exception as e:
                logger.warning(f"Failed to close cache backend '{name}': {e}")
        self._backends.clear()
        self._init_default_backends()

    def close(self):
        for name, backend in list(self._backends.items()):
            try:
                if hasattr(backend, 'close'):
                    backend.close()
                elif hasattr(backend, 'shutdown'):
                    backend.shutdown()
            except Exception as e:
                logger.warning(f"Failed to close cache backend '{name}': {e}")
        self._backends.clear()
        self._init_default_backends()


cache_manager = CacheManager()


__all__ = [
    'CacheManager',
    'cache_manager',
]
