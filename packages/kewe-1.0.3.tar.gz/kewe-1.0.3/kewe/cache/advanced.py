# -*- coding: utf-8 -*-
import time
import math
import hashlib
import asyncio
import logging
from typing import Any, Callable, Dict, Optional, List
from dataclasses import dataclass

from .backends import CacheEntry
from .lru_cache import LRUCache

logger = logging.getLogger(__name__)


class LFUCache:

    def __init__(self, max_size: int = 1000, maxsize: int = None, default_ttl: int = None):
        self.max_size = maxsize if maxsize is not None else max_size
        self.default_ttl = default_ttl
        self._cache: Dict[str, CacheEntry] = {}
        self._freq: Dict[str, int] = {}
        self._min_freq: int = 0
        self._lock: Optional[asyncio.Lock] = None

    def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def get(self, key: str) -> Optional[Any]:
        async with self._get_lock():
            if key not in self._cache:
                return None
            entry = self._cache[key]
            if entry.expire_at is not None and time.time() > entry.expire_at:
                self._remove(key)
                return None
            self._freq[key] = self._freq.get(key, 0) + 1
            return entry.value

    async def set(self, key: str, value: Any, ttl: int = None):
        async with self._get_lock():
            ttl = ttl or self.default_ttl
            expire_at = time.time() + ttl if ttl else None
            if key in self._cache:
                self._cache[key].value = value
                self._cache[key].expire_at = expire_at
                self._freq[key] = self._freq.get(key, 0) + 1
            else:
                if len(self._cache) >= self.max_size:
                    self._evict()
                self._cache[key] = CacheEntry(value=value, expire_at=expire_at, created_at=time.time())
                self._freq[key] = 1
                self._min_freq = 1

    async def delete(self, key: str):
        async with self._get_lock():
            if key in self._cache:
                self._remove(key)

    def _remove(self, key: str):
        del self._cache[key]
        self._freq.pop(key, None)

    def _evict(self):
        if not self._freq:
            return
        min_freq = min(self._freq.values())
        for key, freq in list(self._freq.items()):
            if freq == min_freq:
                entry = self._cache.get(key)
                if entry and (entry.expire_at is None or time.time() <= entry.expire_at):
                    self._remove(key)
                    return
        for key in list(self._freq.keys()):
            self._remove(key)
            return


class BloomFilter:

    def __init__(self, size: int = 100000, hash_count: int = 7, capacity: int = None, error_rate: float = None):
        if capacity is not None and size == 100000:
            size = capacity
        self.size = size
        self.hash_count = hash_count
        if error_rate is not None:
            self.hash_count = max(1, int(-math.log2(error_rate)))
        self._byte_size = (size + 7) // 8
        self.bit_array = bytearray(self._byte_size)

    def _hashes(self, key: str) -> List[int]:
        key_bytes = key.encode('utf-8')
        h1 = int(hashlib.sha256(key_bytes).hexdigest(), 16)
        h2 = int(hashlib.sha256(f"seed:{key}".encode()).hexdigest(), 16)
        return [(h1 + i * h2) % self.size for i in range(self.hash_count)]

    def _set_bit(self, index: int):
        self.bit_array[index >> 3] |= (1 << (index & 7))

    def _get_bit(self, index: int) -> bool:
        return bool(self.bit_array[index >> 3] & (1 << (index & 7)))

    def add(self, key: str):
        for hash_val in self._hashes(key):
            self._set_bit(hash_val)

    def contains(self, key: str) -> bool:
        return all(self._get_bit(h) for h in self._hashes(key))


class CacheWarmer:

    def __init__(self, cache):
        self.cache = cache
        self._warm_keys: set = set()

    def register(self, key: str, loader: Callable):
        self._warm_keys.add((key, loader))

    async def warm(self):
        for key, loader in self._warm_keys:
            value = await loader()
            if hasattr(self.cache, 'set'):
                r = self.cache.set(key, value)
                if hasattr(r, '__await__'):
                    await r


class AdvancedCacheManager:

    def __init__(self, cache_type: str = "lru", max_size: int = 1000):
        if cache_type == "lru":
            self.cache = LRUCache(max_size)
        elif cache_type == "lfu":
            self.cache = LFUCache(max_size)
        else:
            raise ValueError(f"Unknown cache type: {cache_type}")

        self.bloom_filter = BloomFilter()
        self.warmer = CacheWarmer(self.cache)

    async def get(self, key: str, loader=None, use_bloom: bool = True):
        if use_bloom and not self.bloom_filter.contains(key):
            if loader:
                value = await loader()
                if value:
                    self.bloom_filter.add(key)
                    r = self.cache.set(key, value)
                    if hasattr(r, '__await__'):
                        await r
                return value
            return None

        r = self.cache.get(key)
        if hasattr(r, '__await__'):
            value = await r
        else:
            value = r
        if value is not None:
            return value

        if loader:
            value = await loader()
            if value:
                self.bloom_filter.add(key)
                r = self.cache.set(key, value)
                if hasattr(r, '__await__'):
                    await r
            return value

        return None

    async def set(self, key: str, value, ttl: int = None):
        self.bloom_filter.add(key)
        result = self.cache.set(key, value, ttl)
        if hasattr(result, '__await__'):
            await result

    async def delete(self, key: str):
        result = self.cache.delete(key)
        if hasattr(result, '__await__'):
            await result

    async def exists(self, key: str) -> bool:
        result = self.cache.has(key) if hasattr(self.cache, 'has') else self.cache.get(key)
        if hasattr(result, '__await__'):
            result = await result
        return result is not None

    async def clear(self):
        if hasattr(self.cache, 'clear'):
            result = self.cache.clear()
            if hasattr(result, '__await__'):
                await result
        elif hasattr(self.cache, '_cache'):
            self.cache._cache.clear()


__all__ = [
    'LFUCache',
    'BloomFilter',
    'CacheWarmer',
    'AdvancedCacheManager',
]

