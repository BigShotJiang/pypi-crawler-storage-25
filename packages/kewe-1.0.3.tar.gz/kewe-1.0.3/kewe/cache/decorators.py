# -*- coding: utf-8 -*-
import time
import hashlib
import logging
import asyncio
from typing import Any, Callable, Dict, Optional, List
from functools import wraps
from collections import OrderedDict
import threading

from .backends import MemoryCache

_CACHE_NONE_SENTINEL = "__KEWE_CACHE_NONE__"
from .manager import cache_manager

logger = logging.getLogger(__name__)


def generate_cache_key(
    func: Callable,
    args: tuple,
    kwargs: dict,
    key_prefix: str = "",
    include_args: bool = True
) -> str:
    func_name = f"{func.__module__}.{func.__qualname__}"

    if not include_args:
        return f"{key_prefix}:{func_name}" if key_prefix else func_name

    key_parts = [func_name]

    if args:
        args_str = ":".join(str(arg) for arg in args)
        key_parts.append(args_str)

    if kwargs:
        kwargs_str = ":".join(f"{k}={v}" for k, v in sorted(kwargs.items()))
        key_parts.append(kwargs_str)

    key = ":".join(key_parts)

    if len(key) > 200:
        key = hashlib.md5(key.encode()).hexdigest()

    if key_prefix:
        key = f"{key_prefix}:{key}"

    return key


def cache(
    ttl_or_manager=None,
    key_prefix: str = "",
    backend: str = None,
    key_func: Callable = None,
    unless: Callable = None,
    no_cache: bool = False,
    ttl: int = None,
    maxsize: int = None,
):
    from .advanced import AdvancedCacheManager

    _advanced_mgr = None
    if isinstance(ttl_or_manager, AdvancedCacheManager):
        _advanced_mgr = ttl_or_manager
        effective_ttl = ttl or 300
    elif isinstance(ttl_or_manager, (int, float)):
        effective_ttl = int(ttl_or_manager)
    else:
        effective_ttl = ttl or 300

    _local_cache = MemoryCache()

    def decorator(func: Callable) -> Callable:
        if no_cache:
            return func

        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            if unless and unless(*args, **kwargs):
                return await func(*args, **kwargs)

            if key_func:
                cache_key = key_func(*args, **kwargs)
            else:
                cache_args = args[1:] if args and hasattr(args[0], '__class__') and not isinstance(args[0], (int, float, str, bool, bytes)) else args
                cache_key = generate_cache_key(func, cache_args, kwargs, key_prefix)

            try:
                if _advanced_mgr:
                    cached_value = await _advanced_mgr.get(cache_key)
                    if cached_value is not None:
                        return cached_value
                elif backend:
                    cached_value = cache_manager.get(cache_key, backend)
                    if cached_value == _CACHE_NONE_SENTINEL:
                        logger.debug(f"Cache hit (None): {cache_key}")
                        return None
                    if cached_value is not None:
                        logger.debug(f"Cache hit: {cache_key}")
                        return cached_value
                    logger.debug(f"Cache miss: {cache_key}")
                else:
                    cached_value = _local_cache.get(cache_key)
                    if cached_value == _CACHE_NONE_SENTINEL:
                        logger.debug(f"Cache hit (None): {cache_key}")
                        return None
                    if cached_value is not None:
                        logger.debug(f"Cache hit: {cache_key}")
                        return cached_value
            except Exception as e:
                logger.error(f"Cache get error: {e}")

            result = await func(*args, **kwargs)

            try:
                if _advanced_mgr:
                    await _advanced_mgr.set(cache_key, result, ttl=effective_ttl)
                elif backend:
                    cache_manager.set(cache_key, result if result is not None else _CACHE_NONE_SENTINEL, effective_ttl, backend)
                else:
                    _local_cache.set(cache_key, result if result is not None else _CACHE_NONE_SENTINEL, ttl=effective_ttl)
                logger.debug(f"Cache set: {cache_key}")
            except Exception as e:
                logger.error(f"Cache set error: {e}")

            return result

        @wraps(func)
        def sync_wrapper(*args, **kwargs):
            if unless and unless(*args, **kwargs):
                return func(*args, **kwargs)

            if key_func:
                cache_key = key_func(*args, **kwargs)
            else:
                cache_args = args[1:] if args and hasattr(args[0], '__class__') and not isinstance(args[0], (int, float, str, bool, bytes)) else args
                cache_key = generate_cache_key(func, cache_args, kwargs, key_prefix)

            try:
                if backend:
                    cached_value = cache_manager.get(cache_key, backend)
                else:
                    cached_value = _local_cache.get(cache_key)
                if cached_value == _CACHE_NONE_SENTINEL:
                    logger.debug(f"Cache hit (None): {cache_key}")
                    return None
                if cached_value is not None:
                    logger.debug(f"Cache hit: {cache_key}")
                    return cached_value
            except Exception as e:
                logger.error(f"Cache get error: {e}")

            result = func(*args, **kwargs)

            try:
                if backend:
                    cache_manager.set(cache_key, result if result is not None else _CACHE_NONE_SENTINEL, effective_ttl, backend)
                else:
                    _local_cache.set(cache_key, result if result is not None else _CACHE_NONE_SENTINEL, ttl=effective_ttl)
                logger.debug(f"Cache set: {cache_key}")
            except Exception as e:
                logger.error(f"Cache set error: {e}")

            return result

        wrapper = async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper

        def invalidate(*args, **kwargs):
            if key_func:
                cache_key = key_func(*args, **kwargs)
            else:
                cache_args = args[1:] if args and hasattr(args[0], '__class__') and not isinstance(args[0], (int, float, str, bool, bytes)) else args
                cache_key = generate_cache_key(func, cache_args, kwargs, key_prefix)

            try:
                if backend:
                    cache_manager.delete(cache_key, backend)
                else:
                    _local_cache.delete(cache_key)
                logger.debug(f"Cache invalidated: {cache_key}")
            except Exception as e:
                logger.error(f"Cache invalidate error: {e}")

        def clear_all():
            try:
                if backend:
                    backend_obj = cache_manager.get_backend(backend)
                    keys = backend_obj.keys(f"{key_prefix}:*" if key_prefix else "*")
                    for key in keys:
                        backend_obj.delete(key)
                else:
                    _local_cache.clear()
                logger.debug(f"Cache cleared for {func.__name__}")
            except Exception as e:
                logger.error(f"Cache clear error: {e}")

        wrapper.invalidate = invalidate
        wrapper.clear_cache = clear_all
        wrapper.cache_key = lambda *a, **kw: generate_cache_key(
            func,
            a[1:] if a and hasattr(a[0], '__class__') else a,
            kw,
            key_prefix
        )

        return wrapper

    return decorator


cached = cache


def cached_property(ttl: int = 300):
    def decorator(func):
        cache_attr = f"_cached_{func.__name__}"

        @property
        @wraps(func)
        def wrapper(self):
            if hasattr(self, cache_attr):
                cached_value, expire_at = getattr(self, cache_attr)
                if time.time() < expire_at:
                    return cached_value

            value = func(self)

            setattr(self, cache_attr, (value, time.time() + ttl))

            return value

        return wrapper

    return decorator


def memoize(maxsize: int = 128, ttl: Optional[float] = None):
    def decorator(func: Callable) -> Callable:
        _cache = OrderedDict()
        _lock = threading.Lock()
        _stats = {"hits": 0, "misses": 0}

        if asyncio.iscoroutinefunction(func):
            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                key = (args, tuple(sorted(kwargs.items())))

                with _lock:
                    if key in _cache:
                        value, expire_at = _cache[key]
                        if ttl is not None and expire_at is not None and time.time() > expire_at:
                            del _cache[key]
                        else:
                            _cache.move_to_end(key)
                            _stats["hits"] += 1
                            return value
                    _stats["misses"] += 1

                result = await func(*args, **kwargs)

                with _lock:
                    if key not in _cache:
                        expire_at = time.time() + ttl if ttl else None
                        _cache[key] = (result, expire_at)
                        while len(_cache) > maxsize:
                            _cache.popitem(last=False)

                return result

            async_wrapper.cache_info = lambda: _cache_info()
            async_wrapper.cache_clear = lambda: _cache_clear()
            return async_wrapper

        @wraps(func)
        def wrapper(*args, **kwargs):
            key = (args, tuple(sorted(kwargs.items())))

            with _lock:
                if key in _cache:
                    value, expire_at = _cache[key]
                    if ttl is not None and expire_at is not None and time.time() > expire_at:
                        del _cache[key]
                    else:
                        _cache.move_to_end(key)
                        _stats["hits"] += 1
                        return value
                _stats["misses"] += 1

            result = func(*args, **kwargs)

            with _lock:
                if key not in _cache:
                    expire_at = time.time() + ttl if ttl else None
                    _cache[key] = (result, expire_at)
                    while len(_cache) > maxsize:
                        _cache.popitem(last=False)

            return result

        def _cache_info():
            with _lock:
                return {
                    "hits": _stats["hits"],
                    "misses": _stats["misses"],
                    "maxsize": maxsize,
                    "currsize": len(_cache),
                    "ttl": ttl
                }

        def _cache_clear():
            with _lock:
                _cache.clear()
                _stats["hits"] = 0
                _stats["misses"] = 0

        wrapper.cache_info = _cache_info
        wrapper.cache_clear = _cache_clear

        return wrapper

    return decorator


def cache_response(
    ttl: int = 300,
    key_prefix: str = "kewe:response",
    vary: Optional[List[str]] = None,
    unless: Optional[Callable] = None,
    backend: Optional[str] = None
):
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def async_wrapper(request, *args, **kwargs):
            if unless and unless(request):
                return await func(request, *args, **kwargs)

            vary_headers = vary or ["Accept", "Accept-Encoding"]

            cache_key_parts = [
                key_prefix,
                request.method,
                request.path,
            ]

            for header in vary_headers:
                value = request.headers.get(header.lower(), "")
                cache_key_parts.append(f"{header}={value}")

            query_string = request.query_string if hasattr(request, 'query_string') else ""
            if query_string:
                cache_key_parts.append(f"qs={query_string}")

            cache_key = ":".join(cache_key_parts)

            if len(cache_key) > 200:
                cache_key = f"{key_prefix}:{hashlib.md5(cache_key.encode()).hexdigest()}"

            try:
                cached_response = cache_manager.get(cache_key, backend)
                if cached_response is not None:
                    logger.debug(f"Response cache hit: {cache_key}")
                    if isinstance(cached_response, dict):
                        from kewe.response import Response
                        return Response(
                            body=cached_response.get('body', b''),
                            status=cached_response.get('status', 200),
                            headers=cached_response.get('headers', {}),
                            content_type=cached_response.get('content_type', 'application/json')
                        )
                    return cached_response
            except Exception as e:
                logger.error(f"Response cache get error: {e}")

            result = await func(request, *args, **kwargs)

            if result is not None:
                try:
                    cache_data = result
                    if hasattr(result, 'body') and hasattr(result, 'status'):
                        body = result.body
                        if isinstance(body, bytes):
                            body = body.decode('utf-8', errors='surrogateescape')
                        elif not isinstance(body, str):
                            body = str(body)
                        cache_data = {
                            'body': body,
                            'status': result.status,
                            'headers': dict(result.headers) if result.headers else {},
                            'content_type': getattr(result, 'content_type', 'application/json')
                        }
                    cache_manager.set(cache_key, cache_data, ttl, backend)
                    logger.debug(f"Response cache set: {cache_key}")
                except Exception as e:
                    logger.error(f"Response cache set error: {e}")

            return result

        return async_wrapper

    return decorator

