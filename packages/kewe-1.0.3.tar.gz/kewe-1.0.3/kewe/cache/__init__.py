# -*- coding: utf-8 -*-
from .backends import (
    CacheStrategy,
    CacheEntry,
    CacheBackend,
    MemoryCache,
    RedisCache,
)
from .manager import (
    CacheManager,
    cache_manager,
)
from .decorators import (
    generate_cache_key,
    cache,
    cached,
    cached_property,
    memoize,
    cache_response,
)
from .lru_cache import LRUCache
from .advanced import (
    LFUCache,
    BloomFilter,
    CacheWarmer,
    AdvancedCacheManager,
)


def get_cache(backend: str = None) -> CacheBackend:
    return cache_manager.get_backend(backend)


def clear_cache(backend: str = None):
    cache_manager.clear(backend)


def setup_redis_cache(
    name: str = "redis",
    host: str = "localhost",
    port: int = 6379,
    db: int = 0,
    password: str = None,
    set_default: bool = False
):
    backend = RedisCache(host=host, port=port, db=db, password=password)
    cache_manager.add_backend(name, backend)

    if set_default:
        cache_manager.set_default_backend(name)

    return backend


__all__ = [
    'CacheStrategy',
    'CacheEntry',
    'CacheBackend',
    'MemoryCache',
    'RedisCache',
    'CacheManager',
    'cache_manager',
    'generate_cache_key',
    'cache',
    'cached',
    'cached_property',
    'memoize',
    'cache_response',
    'get_cache',
    'clear_cache',
    'setup_redis_cache',
    'LRUCache',
    'LFUCache',
    'BloomFilter',
    'CacheWarmer',
    'AdvancedCacheManager',
]
