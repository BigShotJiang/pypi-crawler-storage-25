#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Pydantic集成模块 - Pydantic Integration Module
支持 Pydantic v2.12.5+ 的新功能

功能：
- 自动参数注入
- 请求验证装饰器
- 响应模型序列化与过滤
- 配置管理
- 类型转换
- 支持 Pydantic 2.12 新特性
- 标准HTTP 422验证错误格式
"""
import functools
import logging
from typing import (
    Dict, Any, List, Optional, Callable, TypeVar, Generic,
    Union, Type, get_type_hints, Annotated, get_origin, get_args
)
from dataclasses import dataclass

from kewe.request import Request
from kewe.response import json, Response

logger = logging.getLogger(__name__)

T = TypeVar('T')
ModelT = TypeVar('ModelT')

PYDANTIC_AVAILABLE = False
PYDANTIC_VERSION: Optional[str] = None

try:
    import pydantic
    from pydantic import BaseModel, ValidationError, Field, field_validator, model_validator
    from pydantic import ConfigDict, computed_field
    from pydantic.type_adapter import TypeAdapter
    from pydantic.functional_validators import AfterValidator, BeforeValidator
    from pydantic.alias_generators import to_camel, to_snake, to_pascal

    PYDANTIC_AVAILABLE = True
    PYDANTIC_VERSION = getattr(pydantic, '__version__', 'unknown')
    logger.debug(f"pydantic {PYDANTIC_VERSION} is available")
except ImportError:
    logger.debug("pydantic not available")
    BaseModel = object
    ValidationError = type('ValidationError', (Exception,), {})


def get_pydantic_version() -> Optional[str]:
    return PYDANTIC_VERSION


def is_pydantic_available() -> bool:
    return PYDANTIC_AVAILABLE


def _format_validation_errors(exc: 'ValidationError') -> List[Dict[str, Any]]:
    """将Pydantic ValidationError格式化为的标准422错误格式

    输出格式:
        [
            {
                "loc": ["body", "field_name"],
                "msg": "error message",
                "type": "value_error.missing"
            }
        ]
    """
    errors = []
    for error in exc.errors():
        loc = list(error.get('loc', []))
        errors.append({
            'loc': loc,
            'msg': error.get('msg', ''),
            'type': error.get('type', 'value_error'),
        })
    return errors


def _create_422_response(errors: Any) -> Response:
    """创建标准422验证错误响应 — RFC 7807 格式"""
    if isinstance(errors, list):
        detail = errors
    elif hasattr(errors, 'errors'):
        detail = _format_validation_errors(errors)
    else:
        detail = [{"loc": [], "msg": str(errors), "type": "value_error"}]

    resp = json({
        "type": "about:blank",
        "title": "Validation Error",
        "status": 422,
        "detail": "Request validation failed",
        "errors": detail,
    }, status=422)
    resp.content_type = 'application/problem+json'
    return resp


if PYDANTIC_AVAILABLE:
    class BaseSchema(BaseModel):
        model_config = ConfigDict(
            extra='forbid',
            str_strip_whitespace=True,
            validate_assignment=True,
            use_enum_values=True,
            populate_by_name=True,
            ser_json_keys='camel',
        )

    class ORMSchema(BaseModel):
        """ORM模式基类 - 自动从SQLAlchemy模型转换

        使用示例:
            class UserResponse(ORMSchema):
                model_config = ConfigDict(from_attributes=True)

                id: int
                name: str
                email: str

            # 直接从SQLAlchemy模型创建
            user = await session.get(User, 1)
            response = UserResponse.model_validate(user)
        """
        model_config = ConfigDict(
            from_attributes=True,
            populate_by_name=True,
            ser_json_keys='camel',
            str_strip_whitespace=True,
            validate_assignment=True,
        )

    def create_model(
        name: str,
        /,
        **fields: Any
    ) -> Type[BaseModel]:
        from pydantic import create_model as _create_model
        return _create_model(name, **fields)

    def validate_data(
        model: Type[BaseModel],
        data: Any,
        *,
        strict: bool = False,
        from_attributes: bool = True,
        context: Optional[Dict[str, Any]] = None
    ) -> BaseModel:
        return model.model_validate(
            data,
            strict=strict,
            from_attributes=from_attributes,
            context=context
        )

    def validate_json(
        model: Type[BaseModel],
        json_data: Union[str, bytes],
        *,
        strict: bool = False,
        context: Optional[Dict[str, Any]] = None
    ) -> BaseModel:
        return model.model_validate_json(json_data, strict=strict, context=context)

    def model_to_json(
        model: BaseModel,
        *,
        indent: Optional[int] = None,
        exclude_none: bool = False,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        by_alias: bool = True,
        context: Optional[Dict[str, Any]] = None
    ) -> str:
        return model.model_dump_json(
            indent=indent,
            exclude_none=exclude_none,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            by_alias=by_alias,
            context=context
        )

    def model_to_dict(
        model: BaseModel,
        *,
        exclude_none: bool = False,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        by_alias: bool = True,
        mode: str = 'python',
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        return model.model_dump(
            exclude_none=exclude_none,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            by_alias=by_alias,
            mode=mode,
            context=context
        )

    class TypeAdapterCache:
        _adapters: Dict[Type, 'TypeAdapter'] = {}

        @classmethod
        def get(cls, type_: Type) -> 'TypeAdapter':
            if type_ not in cls._adapters:
                cls._adapters[type_] = TypeAdapter(type_)
            return cls._adapters[type_]

        @classmethod
        def validate(cls, type_: Type, data: Any, *, context: Optional[Dict[str, Any]] = None) -> Any:
            adapter = cls.get(type_)
            return adapter.validate_python(data, context=context)

        @classmethod
        def validate_json(cls, type_: Type, json_data: Union[str, bytes]) -> Any:
            adapter = cls.get(type_)
            return adapter.validate_json(json_data)

        @classmethod
        def dump_json(cls, type_: Type, data: Any) -> str:
            adapter = cls.get(type_)
            return adapter.dump_json(data)

    def validate(
        *,
        body: Optional[Type[BaseModel]] = None,
        query: Optional[Type[BaseModel]] = None,
        path: Optional[Type[BaseModel]] = None,
        headers: Optional[Type[BaseModel]] = None,
        strict: bool = False,
        context: Optional[Dict[str, Any]] = None
    ) -> Callable:
        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            async def wrapper(request: Request, *args, **kwargs):
                validated = ValidatedData()
                errors: List[Dict[str, Any]] = []

                if body is not None:
                    try:
                        json_data = await request.json_async
                        validated.body = validate_data(body, json_data, strict=strict, context=context)
                    except ValidationError as e:
                        for err in _format_validation_errors(e):
                            err['loc'] = ['body'] + err['loc']
                            errors.append(err)
                    except Exception as e:
                        errors.append({'loc': ['body'], 'msg': str(e), 'type': 'value_error'})

                if query is not None:
                    try:
                        query_data = {}
                        for key, values in request.query_params.items_raw():
                            query_data[key] = values[0] if len(values) == 1 else values
                        validated.query = validate_data(query, query_data, strict=strict, context=context)
                    except ValidationError as e:
                        for err in _format_validation_errors(e):
                            err['loc'] = ['query'] + err['loc']
                            errors.append(err)

                if path is not None:
                    try:
                        path_params = kwargs.copy()
                        validated.path = validate_data(path, path_params, strict=strict, context=context)
                    except ValidationError as e:
                        for err in _format_validation_errors(e):
                            err['loc'] = ['path'] + err['loc']
                            errors.append(err)

                if headers is not None:
                    try:
                        validated.headers = validate_data(
                            headers, dict(request.headers), strict=strict, context=context
                        )
                    except ValidationError as e:
                        for err in _format_validation_errors(e):
                            err['loc'] = ['header'] + err['loc']
                            errors.append(err)

                if errors:
                    return _create_422_response(errors)

                return await func(request, validated, *args, **kwargs)

            return wrapper
        return decorator

    @dataclass
    class ValidatedData:
        body: Optional[BaseModel] = None
        query: Optional[BaseModel] = None
        path: Optional[BaseModel] = None
        headers: Optional[BaseModel] = None

    def pydantic_response(
        model: BaseModel,
        *,
        status: int = 200,
        headers: Optional[Dict[str, str]] = None,
        context: Optional[Dict[str, Any]] = None,
        exclude_none: bool = False,
        exclude_unset: bool = False,
        exclude_defaults: bool = False,
        by_alias: bool = True,
        exclude: Optional[set] = None,
        include: Optional[set] = None,
    ) -> Response:
        dump_kwargs = dict(
            mode='json',
            by_alias=by_alias,
            exclude_none=exclude_none,
            exclude_unset=exclude_unset,
            exclude_defaults=exclude_defaults,
            context=context,
        )
        if exclude is not None:
            dump_kwargs['exclude'] = exclude
        if include is not None:
            dump_kwargs['include'] = include
        return json(
            model.model_dump(**dump_kwargs),
            status=status,
            headers=headers
        )

    def pydantic_response_list(
        models: List[BaseModel],
        *,
        status: int = 200,
        headers: Optional[Dict[str, str]] = None,
        context: Optional[Dict[str, Any]] = None,
        exclude_none: bool = False,
        exclude_unset: bool = False,
        by_alias: bool = True,
    ) -> Response:
        return json(
            [m.model_dump(
                mode='json',
                by_alias=by_alias,
                exclude_none=exclude_none,
                exclude_unset=exclude_unset,
                context=context
            ) for m in models],
            status=status,
            headers=headers
        )

    def filter_response_with_model(
        data: Any,
        response_model: Type[BaseModel],
        *,
        exclude_unset: bool = True,
        exclude_none: bool = False,
        exclude_defaults: bool = False,
        by_alias: bool = True,
    ) -> Any:
        """使用response_model过滤响应数据 - 

        将原始数据通过response_model验证后序列化，自动剥离多余字段。
        response_model核心功能。

        Args:
            data: 原始响应数据（dict/list/BaseModel实例）
            response_model: Pydantic模型类
            exclude_unset: 排除未设置的值（默认True，默认行为）
            exclude_none: 排除None值
            exclude_defaults: 排除默认值
            by_alias: 使用别名
        """
        if data is None:
            return None

        if isinstance(data, BaseModel):
            raw = data.model_dump(by_alias=by_alias)
        elif isinstance(data, dict):
            raw = data
        elif isinstance(data, list):
            result = []
            for item in data:
                if isinstance(item, BaseModel):
                    result.append(filter_response_with_model(
                        item, response_model,
                        exclude_unset=exclude_unset,
                        exclude_none=exclude_none,
                        exclude_defaults=exclude_defaults,
                        by_alias=by_alias,
                    ))
                elif isinstance(item, dict):
                    try:
                        validated = response_model.model_validate(item)
                        result.append(validated.model_dump(
                            mode='json',
                            by_alias=by_alias,
                            exclude_unset=exclude_unset,
                            exclude_none=exclude_none,
                            exclude_defaults=exclude_defaults,
                        ))
                    except Exception:
                        result.append(item)
                else:
                    result.append(item)
            return result
        else:
            raw = data

        try:
            validated = response_model.model_validate(raw)
            return validated.model_dump(
                mode='json',
                by_alias=by_alias,
                exclude_unset=exclude_unset,
                exclude_none=exclude_none,
                exclude_defaults=exclude_defaults,
            )
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(
                f"Response model validation failed for {response_model.__name__}: {e}. "
                f"Returning unfiltered data."
            )
            return raw

    def extract_query_model(
        request: Request,
        model: Type[BaseModel],
        *,
        strict: bool = False,
    ) -> BaseModel:
        """从请求查询参数提取并验证Pydantic模型

        使用示例:
            class PaginationParams(BaseModel):
                page: int = 1
                size: int = Field(default=10, le=100)

            @app.get("/items")
            async def list_items(request, params: PaginationParams = QueryModel()):
                ...
        """
        query_data = {}
        model_fields = model.model_fields if hasattr(model, 'model_fields') else {}
        for key, values in request.query_params.items_raw():
            if key in model_fields:
                query_data[key] = values[0] if len(values) == 1 else values
        return model.model_validate(query_data, strict=strict)

    def extract_path_model(
        request: Request,
        model: Type[BaseModel],
        path_params: Dict[str, Any],
        *,
        strict: bool = False,
    ) -> BaseModel:
        """从路径参数提取并验证Pydantic模型"""
        return model.model_validate(path_params, strict=strict)

    def extract_header_model(
        request: Request,
        model: Type[BaseModel],
        *,
        strict: bool = False,
    ) -> BaseModel:
        """从请求头提取并验证Pydantic模型"""
        headers_lower = {k.lower(): v for k, v in request.headers.items()}
        model_fields = model.model_fields if hasattr(model, 'model_fields') else {}
        header_data = {}
        for key in model_fields:
            if key.lower() in headers_lower:
                header_data[key] = headers_lower[key.lower()]
        return model.model_validate(header_data, strict=strict)

    def create_validator(
        field_name: str,
        validator: Callable[[Any], Any]
    ) -> Callable:
        def decorator(model_class: Type[BaseModel]) -> Type[BaseModel]:
            setattr(model_class, f'validate_{field_name}',
                    field_validator(field_name)(validator))
            return model_class
        return decorator

    def AnnotatedField(
        default: Any = ...,
        *,
        description: str = "",
        examples: Optional[List[Any]] = None,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        ge: Optional[Union[int, float]] = None,
        le: Optional[Union[int, float]] = None,
        gt: Optional[Union[int, float]] = None,
        lt: Optional[Union[int, float]] = None,
        multiple_of: Optional[Union[int, float]] = None,
        pattern: Optional[str] = None,
        discriminator: Optional[str] = None,
        strict: Optional[bool] = None,
    ) -> Any:
        return Field(
            default=default,
            description=description,
            examples=examples,
            min_length=min_length,
            max_length=max_length,
            ge=ge,
            le=le,
            gt=gt,
            lt=lt,
            multiple_of=multiple_of,
            pattern=pattern,
            discriminator=discriminator,
            strict=strict,
        )

    class BodyModel:
        """Body模型参数标记 - 用于自动注入Pydantic body模型

        使用示例:
            class CreateUser(BaseModel):
                name: str
                email: str

            @app.post("/users")
            async def create_user(request, body: CreateUser = BodyModel()):
                ...
        """
        def __init__(self, *, strict: bool = False, context: Optional[Dict[str, Any]] = None):
            self.strict = strict
            self.context = context

    class QueryModel:
        """Query模型参数标记 - 用于自动注入Pydantic query模型

        使用示例:
            class Pagination(BaseModel):
                page: int = 1
                size: int = Field(default=10, le=100)

            @app.get("/items")
            async def list_items(request, params: Pagination = QueryModel()):
                ...
        """
        def __init__(self, *, strict: bool = False, context: Optional[Dict[str, Any]] = None):
            self.strict = strict
            self.context = context

    class HeaderModel:
        """Header模型参数标记 - 用于自动注入Pydantic header模型"""
        def __init__(self, *, strict: bool = False, context: Optional[Dict[str, Any]] = None):
            self.strict = strict
            self.context = context

    class PathModel:
        """Path模型参数标记 - 用于自动注入Pydantic path模型"""
        def __init__(self, *, strict: bool = False, context: Optional[Dict[str, Any]] = None):
            self.strict = strict
            self.context = context

else:
    BaseSchema = object
    ORMSchema = object
    ValidatedData = None

    def validate(*args, **kwargs):
        import warnings
        warnings.warn(
            "Pydantic is not installed. @validate() decorator will skip all validation. "
            "Install pydantic: pip install pydantic",
            RuntimeWarning,
            stacklevel=2
        )
        def decorator(func):
            return func
        return decorator

    def pydantic_response(model, **kwargs):
        return json({"error": "pydantic not available"}, status=500)

    def pydantic_response_list(models, **kwargs):
        return json({"error": "pydantic not available"}, status=500)

    def filter_response_with_model(data, response_model, **kwargs):
        return data

    def extract_query_model(request, model, **kwargs):
        raise RuntimeError("pydantic not available")

    def extract_path_model(request, model, path_params, **kwargs):
        raise RuntimeError("pydantic not available")

    def extract_header_model(request, model, **kwargs):
        raise RuntimeError("pydantic not available")

    def create_validator(*args, **kwargs):
        def decorator(model_class):
            return model_class
        return decorator

    AnnotatedField = None
    BodyModel = None
    QueryModel = None
    HeaderModel = None
    PathModel = None

    def model_to_dict(model, **kwargs):
        if hasattr(model, 'model_dump'):
            return model.model_dump(**kwargs)
        if hasattr(model, 'dict'):
            return model.dict(**kwargs)
        return dict(model)

    def model_to_json(model, **kwargs):
        if hasattr(model, 'model_dump_json'):
            return model.model_dump_json(**kwargs)
        if hasattr(model, 'json'):
            return model.json(**kwargs)
        from kewe.utils.compat import json as _json
        return _json.dumps(model_to_dict(model, **kwargs))


__all__ = [
    'PYDANTIC_AVAILABLE',
    'PYDANTIC_VERSION',
    'get_pydantic_version',
    'is_pydantic_available',
    'BaseSchema',
    'ORMSchema',
    'ValidatedData',
    'validate',
    'pydantic_response',
    'pydantic_response_list',
    'filter_response_with_model',
    'extract_query_model',
    'extract_path_model',
    'extract_header_model',
    'create_validator',
    'AnnotatedField',
    'BodyModel',
    'QueryModel',
    'HeaderModel',
    'PathModel',
    'model_to_dict',
    'model_to_json',
]

if PYDANTIC_AVAILABLE:
    __all__.extend([
        'BaseModel',
        'ValidationError',
        'Field',
        'field_validator',
        'model_validator',
        'ConfigDict',
        'computed_field',
        'TypeAdapter',
        'TypeAdapterCache',
        'create_model',
        'validate_data',
        'validate_json',
        'model_to_json',
        'model_to_dict',
        'to_camel',
        'to_snake',
        'to_pascal',
    ])
