#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
认证插件

支持JWT、OAuth等多种认证方式。
"""
from kewe.plugins.base import Plugin
from kewe import __version__
from kewe.response import json
import asyncio
from typing import Dict, Any, Optional, Callable, List
import time
import secrets

try:
    import jwt
    JWT_AVAILABLE = True
except ImportError:
    JWT_AVAILABLE = False
    jwt = None


class AuthPlugin(Plugin):
    """认证插件基类"""
    
    name = "auth"
    version = __version__
    
    def setup(self, app, **config):
        self.config = config
        

class JWTPlugin(AuthPlugin):
    """JWT认证插件"""
    
    name = "jwt"
    version = __version__
    
    def setup(self, app, **config):
        super().setup(app, **config)
        self.secret_key = config.get('secret_key')
        if not self.secret_key:
            raise ValueError("JWT secret_key is required")
        
        self.algorithm = config.get('algorithm', 'HS256')
        self.expire_delta = config.get('expire_delta', 3600)  # 默认1小时
        self.token_header = config.get('token_header', 'Authorization')
        self.token_prefix = config.get('token_prefix', 'Bearer')
        
        # 注册到应用
        app.jwt = self
        
        # 添加JWT中间件
        @app.middleware('request')
        async def jwt_middleware(request):
            # 检查Authorization头
            token = self._get_token(request)
            if not token:
                return
            
            try:
                payload = self.decode(token)
                request.user = payload
            except jwt.ExpiredSignatureError:
                return json({"error": "Token has expired"}, status=401)
            except jwt.InvalidTokenError:
                return json({"error": "Invalid token"}, status=401)
        
    def _get_token(self, request):
        """从请求中获取token"""
        auth_header = request.headers.get(self.token_header)
        if not auth_header:
            return None
        
        parts = auth_header.split()
        if len(parts) != 2 or parts[0] != self.token_prefix:
            return None
        
        return parts[1]
    
    def encode(self, payload: Dict[str, Any]) -> str:
        """编码JWT token"""
        # 添加过期时间
        payload['exp'] = time.time() + self.expire_delta
        payload['iat'] = time.time()
        
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    def decode(self, token: str) -> Dict[str, Any]:
        """解码JWT token"""
        return jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
    
    def verify(self, token: str) -> bool:
        """验证JWT token"""
        try:
            self.decode(token)
            return True
        except Exception:
            return False


def jwt_required():
    """JWT认证装饰器"""
    def decorator(func):
        async def wrapper(request, *args, **kwargs):
            request.requires_jwt = True
            return await func(request, *args, **kwargs)
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper
    return decorator


class OAuthPlugin(AuthPlugin):
    """OAuth认证插件"""
    
    name = "oauth"
    version = __version__
    
    def setup(self, app, **config):
        super().setup(app, **config)
        self.providers = config.get('providers', {})
        
        # 注册到应用
        app.oauth = self
        
        # 添加OAuth路由
        @app.route("/oauth/<provider>/login")
        async def oauth_login(request, provider):
            if provider not in self.providers:
                return json({"error": "Provider not supported"}, status=400)
            
            provider_config = self.providers[provider]
            client_id = provider_config['client_id']
            redirect_uri = provider_config['redirect_uri']
            scope = provider_config.get('scope', '')
            
            # 生成state参数防止CSRF攻击
            state = secrets.token_urlsafe(32)
            request.session['oauth_state'] = state
            
            # 构建授权URL
            auth_url = provider_config['auth_url']
            auth_url += f"?client_id={client_id}"
            auth_url += f"&redirect_uri={redirect_uri}"
            auth_url += f"&response_type=code"
            auth_url += f"&state={state}"
            if scope:
                auth_url += f"&scope={scope}"
            
            from kewe.response import redirect
            return redirect(auth_url)
        
        @app.route("/oauth/<provider>/callback")
        async def oauth_callback(request, provider):
            if provider not in self.providers:
                return json({"error": "Provider not supported"}, status=400)
            
            # 验证state参数
            state = request.query_params.get('state', '')
            if not state or state != request.session.get('oauth_state'):
                return json({"error": "Invalid state parameter"}, status=400)
            
            # 获取code
            code = request.query_params.get('code', '')
            if not code:
                return json({"error": "No code provided"}, status=400)
            
            # 交换token
            provider_config = self.providers[provider]
            token = await self._exchange_token(provider, code, provider_config)
            
            # 获取用户信息
            user_info = await self._get_user_info(provider, token, provider_config)
            
            # 处理用户登录
            if hasattr(self, 'on_login'):
                result = self.on_login(request, provider, user_info, token)
                if asyncio.iscoroutine(result):
                    await result
            
            return json({"user": user_info, "token": token})
    
    async def _exchange_token(self, provider: str, code: str, config: Dict[str, Any]) -> Dict[str, Any]:
        from kewe.http.client import AsyncHTTPClient
        
        async with AsyncHTTPClient() as client:
            data = {
                'client_id': config['client_id'],
                'client_secret': config['client_secret'],
                'code': code,
                'redirect_uri': config['redirect_uri'],
                'grant_type': 'authorization_code'
            }
            
            response = await client.post(config['token_url'], data=data)
            return response.json()
    
    async def _get_user_info(self, provider: str, token: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
        from kewe.http.client import AsyncHTTPClient
        
        async with AsyncHTTPClient() as client:
            headers = {
                'Authorization': f"Bearer {token['access_token']}"
            }
            
            response = await client.get(config['user_info_url'], headers=headers)
            return response.json()
    
    def on_login(self, request, provider: str, user_info: Dict[str, Any], token: Dict[str, Any]):
        """用户登录回调 - 默认空实现，子类可覆盖"""
        return None


class SessionAuthPlugin(AuthPlugin):
    """会话认证插件"""
    
    name = "session_auth"
    version = __version__
    
    def setup(self, app, **config):
        super().setup(app, **config)
        self.session_key = config.get('session_key', 'user_id')
        
        # 注册到应用
        app.session_auth = self
        
        # 添加会话认证中间件
        @app.middleware('request')
        async def session_auth_middleware(request):
            # 检查是否需要会话认证
            if hasattr(request, 'requires_auth') and request.requires_auth:
                if self.session_key not in request.session:
                    return json({"error": "Not authenticated"}, status=401)
                
                # 将用户信息添加到请求对象
                request.user = {self.session_key: request.session[self.session_key]}
    
    def login(self, request, user_id: Any):
        """用户登录"""
        request.session[self.session_key] = user_id
    
    def logout(self, request):
        """用户登出"""
        if self.session_key in request.session:
            del request.session[self.session_key]
    
    def is_authenticated(self, request) -> bool:
        """检查用户是否已认证"""
        return self.session_key in request.session


def session_required():
    """会话认证装饰器"""
    def decorator(func):
        async def wrapper(request, *args, **kwargs):
            request.requires_auth = True
            return await func(request, *args, **kwargs)
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper
    return decorator


class RBACPlugin(AuthPlugin):
    """基于角色的访问控制插件"""
    
    name = "rbac"
    version = __version__
    
    def setup(self, app, **config):
        super().setup(app, **config)
        self.role_key = config.get('role_key', 'role')
        self.roles = config.get('roles', {})
        
        # 注册到应用
        app.rbac = self
    
    def has_role(self, request, role: str) -> bool:
        """检查用户是否有指定角色"""
        if not hasattr(request, 'user') or not request.user:
            return False
        
        user_role = request.user.get(self.role_key)
        if not user_role:
            return False
        
        # 检查角色是否直接匹配
        if user_role == role:
            return True
        
        # 检查角色继承关系
        if user_role in self.roles:
            user_roles = self.roles[user_role]
            return role in user_roles
        
        return False
    
    def has_permission(self, request, permission: str) -> bool:
        """检查用户是否有指定权限"""
        if not hasattr(request, 'user') or not request.user:
            return False
        
        user_role = request.user.get(self.role_key)
        if not user_role:
            return False
        
        # 检查角色权限
        if user_role in self.roles:
            permissions = self.roles[user_role].get('permissions', [])
            return permission in permissions
        
        return False


def role_required(roles: List[str]):
    """角色认证装饰器"""
    def decorator(func):
        async def wrapper(request, *args, **kwargs):
            if not hasattr(request.app, 'rbac'):
                return json({"error": "RBAC plugin not initialized"}, status=500)
            
            rbac = request.app.rbac
            for role in roles:
                if rbac.has_role(request, role):
                    return await func(request, *args, **kwargs)
            
            return json({"error": "Insufficient permissions"}, status=403)
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper
    return decorator

def permission_required(permissions: List[str]):
    """权限认证装饰器"""
    def decorator(func):
        async def wrapper(request, *args, **kwargs):
            if not hasattr(request.app, 'rbac'):
                return json({"error": "RBAC plugin not initialized"}, status=500)
            
            rbac = request.app.rbac
            for permission in permissions:
                if rbac.has_permission(request, permission):
                    return await func(request, *args, **kwargs)
            
            return json({"error": "Insufficient permissions"}, status=403)
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper
    return decorator


# 便捷函数
def jwt_plugin(secret_key: str, **config):
    """创建JWT插件"""
    config['secret_key'] = secret_key
    return JWTPlugin, config

def oauth(providers: Dict[str, Any], **config):
    """创建OAuth插件"""
    config['providers'] = providers
    return OAuthPlugin, config

def session_auth(session_key: str = 'user_id', **config):
    """创建会话认证插件"""
    config['session_key'] = session_key
    return SessionAuthPlugin, config

def rbac(roles: Dict[str, Any], role_key: str = 'role', **config):
    """创建RBAC插件"""
    config.update({
        'roles': roles,
        'role_key': role_key
    })
    return RBACPlugin, config


__all__ = [
    'AuthPlugin',
    'JWTPlugin',
    'OAuthPlugin',
    'SessionAuthPlugin',
    'RBACPlugin',
    'jwt_required',
    'session_required',
    'role_required',
    'permission_required',
    'jwt',
    'oauth',
    'session_auth',
    'rbac',
]
