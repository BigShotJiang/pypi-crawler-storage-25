#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
URL方案和协议注册表 - URL Schemes and Protocol Registry
用于管理不同的URL方案和协议配置
"""
from typing import Dict, Any, Optional
from dataclasses import dataclass, field
from enum import Enum


class SchemeType(Enum):
    """方案类型"""
    HTTP = "http"
    HTTPS = "https"
    WS = "ws"
    WSS = "wss"
    HTTP2 = "h2"
    HTTP3 = "h3"


@dataclass
class URLScheme:
    """
    URL方案配置
    
    定义特定协议的URL生成规则
    
    使用示例:
        scheme = URLScheme(
            name='https',
            default_port=443,
            secure=True
        )
        url = scheme.build_url(host='example.com', path='/api')
        # https://example.com/api
    """
    
    name: str
    default_port: int
    secure: bool = False
    websocket: bool = False
    options: Dict[str, Any] = field(default_factory=dict)
    
    def build_url(
        self,
        host: str,
        port: Optional[int] = None,
        path: str = "/",
        query: Optional[Dict[str, str]] = None,
        fragment: Optional[str] = None
    ) -> str:
        """
        构建URL
        
        Args:
            host: 主机名
            port: 端口（默认使用方案的默认端口）
            path: 路径
            query: 查询参数
            fragment: 片段标识符
            
        Returns:
            完整URL
        """
        # 确定端口
        if port is None or port == self.default_port:
            netloc = host
        else:
            netloc = f"{host}:{port}"
        
        # 构建基础URL
        url = f"{self.name}://{netloc}{path}"
        
        # 添加查询参数
        if query:
            from urllib.parse import urlencode
            url += f"?{urlencode(query)}"
        
        # 添加片段
        if fragment:
            url += f"#{fragment}"
        
        return url
    
    def is_default_port(self, port: int) -> bool:
        """检查是否是默认端口"""
        return port == self.default_port


class SchemeRegistry:
    """
    URL方案注册表
    
    管理所有支持的URL方案
    
    使用示例:
        registry = SchemeRegistry()
        registry.register(URLScheme('https', 443, secure=True))
        
        scheme = registry.get('https')
        url = scheme.build_url('example.com', path='/api')
    """
    
    def __init__(self):
        self._schemes: Dict[str, URLScheme] = {}
        self._register_defaults()
    
    def _register_defaults(self):
        """注册默认方案"""
        defaults = [
            URLScheme("http", 80),
            URLScheme("https", 443, secure=True),
            URLScheme("ws", 80, websocket=True),
            URLScheme("wss", 443, secure=True, websocket=True),
            URLScheme("h2", 443, secure=True),
            URLScheme("h3", 443, secure=True),
        ]
        
        for scheme in defaults:
            self.register(scheme)
    
    def register(self, scheme: URLScheme):
        """
        注册URL方案
        
        Args:
            scheme: URL方案实例
        """
        self._schemes[scheme.name] = scheme
    
    def get(self, name: str) -> Optional[URLScheme]:
        """
        获取URL方案
        
        Args:
            name: 方案名称
            
        Returns:
            URLScheme实例或None
        """
        return self._schemes.get(name)
    
    def unregister(self, name: str):
        """
        注销URL方案
        
        Args:
            name: 方案名称
        """
        if name in self._schemes:
            del self._schemes[name]
    
    def list_schemes(self) -> list:
        """列出所有方案名称"""
        return list(self._schemes.keys())
    
    def get_secure_schemes(self) -> list:
        """获取所有安全方案"""
        return [name for name, scheme in self._schemes.items() if scheme.secure]
    
    def get_websocket_schemes(self) -> list:
        """获取所有WebSocket方案"""
        return [name for name, scheme in self._schemes.items() if scheme.websocket]


# 全局注册表
_global_registry: Optional[SchemeRegistry] = None


def get_scheme_registry() -> SchemeRegistry:
    """获取全局方案注册表"""
    global _global_registry
    if _global_registry is None:
        _global_registry = SchemeRegistry()
    return _global_registry


def build_url(
    scheme: str,
    host: str,
    port: Optional[int] = None,
    path: str = "/",
    **kwargs
) -> str:
    """
    构建URL的便捷函数
    
    Args:
        scheme: 方案名称
        host: 主机名
        port: 端口
        path: 路径
        **kwargs: 其他参数
        
    Returns:
        完整URL
    """
    registry = get_scheme_registry()
    scheme_obj = registry.get(scheme)
    
    if scheme_obj is None:
        raise ValueError(f"Unknown scheme: {scheme}")
    
    return scheme_obj.build_url(host, port, path, **kwargs)




