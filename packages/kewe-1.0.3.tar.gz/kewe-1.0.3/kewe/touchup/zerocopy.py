#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
零拷贝优化 - Zero-Copy Optimizations
使用sendfile、mmap等技术优化大文件传输性能
"""
import os
import mmap
import asyncio
from typing import Optional, Union, BinaryIO
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class ZeroCopySupport:
    """
    零拷贝支持检测
    """
    
    # 检测sendfile支持
    HAS_SENDFILE = hasattr(os, 'sendfile')
    
    # 检测splice支持（Linux）
    HAS_SPLICE = False
    try:
        import fcntl
        HAS_SPLICE = True
    except ImportError:
        pass
    
    @classmethod
    def is_supported(cls) -> bool:
        """检查是否支持零拷贝"""
        return cls.HAS_SENDFILE


class SendfileTransport:
    """
    Sendfile传输器
    使用操作系统sendfile进行零拷贝文件传输
    """
    
    def __init__(self, transport):
        self.transport = transport
        self._socket = None
        self._extract_socket()
    
    def _extract_socket(self):
        """从transport提取socket"""
        try:
            # 尝试获取底层socket
            if hasattr(self.transport, 'get_extra_info'):
                self._socket = self.transport.get_extra_info('socket')
            elif hasattr(self.transport, '_sock'):
                self._socket = self.transport._sock
        except Exception as e:
            logger.debug(f"Could not extract socket: {e}")
    
    async def sendfile(
        self,
        file_path: Union[str, Path],
        offset: int = 0,
        count: Optional[int] = None
    ) -> int:
        """
        使用sendfile发送文件
        
        Args:
            file_path: 文件路径
            offset: 起始偏移
            count: 发送字节数，None表示到文件末尾
            
        Returns:
            发送的字节数
        """
        if not ZeroCopySupport.HAS_SENDFILE:
            raise RuntimeError("sendfile not supported on this platform")
        
        if self._socket is None:
            raise RuntimeError("No socket available for sendfile")
        
        file_path = Path(file_path)
        file_size = file_path.stat().st_size
        
        if count is None:
            count = file_size - offset
        
        sent = 0
        
        with open(file_path, 'rb') as f:
            # 在事件循环中执行sendfile
            loop = asyncio.get_running_loop()
            
            while sent < count:
                try:
                    # 使用线程池执行阻塞的sendfile
                    n = await loop.run_in_executor(
                        None,
                        os.sendfile,
                        self._socket.fileno(),
                        f.fileno(),
                        offset + sent,
                        count - sent
                    )
                    
                    if n == 0:
                        break
                    
                    sent += n
                    
                except (BlockingIOError, InterruptedError):
                    await asyncio.sleep(0)
                    continue
                except Exception as e:
                    logger.error(f"sendfile error: {e}")
                    break
        
        return sent


class MmapFileReader:
    """
    内存映射文件读取器
    使用mmap优化大文件读取
    """
    
    def __init__(self, file_path: Union[str, Path], access=mmap.ACCESS_READ):
        self.file_path = Path(file_path)
        self.access = access
        self._file: Optional[BinaryIO] = None
        self._mmap: Optional[mmap.mmap] = None
        self._size = 0
    
    def open(self):
        """打开文件并创建内存映射"""
        self._file = open(self.file_path, 'rb')
        self._size = self.file_path.stat().st_size
        
        if self._size > 0:
            self._mmap = mmap.mmap(self._file.fileno(), 0, access=self.access)
        
        return self
    
    def close(self):
        """关闭文件和内存映射"""
        if self._mmap:
            self._mmap.close()
            self._mmap = None
        
        if self._file:
            self._file.close()
            self._file = None
    
    def read(self, size: int = -1, offset: int = 0) -> bytes:
        """读取数据"""
        if self._mmap is None:
            return b""
        
        if size < 0:
            size = self._size - offset
        
        return self._mmap[offset:offset + size]
    
    def read_chunked(self, chunk_size: int = 8192, offset: int = 0):
        """分块读取"""
        if self._mmap is None:
            return
        
        while offset < self._size:
            chunk = self._mmap[offset:offset + chunk_size]
            if not chunk:
                break
            yield chunk
            offset += len(chunk)
    
    def __enter__(self):
        return self.open()
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    @property
    def size(self) -> int:
        return self._size


class ZeroCopyFileResponse:
    """零拷贝文件响应 — 继承 StreamingResponse，使用 mmap 流式读取

    与框架 Response 体系完全兼容，可直接设置 headers/content_type。
    大文件使用 mmap 分块流式输出，避免全量加载到内存。
    """

    SENDFILE_THRESHOLD = 64 * 1024
    MMAP_THRESHOLD = 64 * 1024

    def __init__(
        self,
        file_path: Union[str, Path],
        chunk_size: int = 64 * 1024,
        content_type: Optional[str] = None,
        status: int = 200,
        headers: Optional[dict] = None,
    ):
        from kewe.response import StreamingResponse
        from kewe.http.headers import Headers
        import mimetypes as _mt

        self._file_path = Path(file_path)
        if not self._file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        self._file_size = self._file_path.stat().st_size
        self._chunk_size = chunk_size

        ct = content_type or _mt.guess_type(str(self._file_path))[0] or 'application/octet-stream'

        self._resp = StreamingResponse(
            body=self._mmap_stream(),
            status=status,
            headers=headers,
            content_type=ct,
        )
        self._resp.headers['content-length'] = str(self._file_size)
        self._resp.headers['accept-ranges'] = 'bytes'

    async def _mmap_stream(self):
        loop = asyncio.get_running_loop()
        try:
            reader = await loop.run_in_executor(None, self._open_mmap_reader)
            try:
                offset = 0
                while offset < reader.size:
                    end = min(offset + self._chunk_size, reader.size)
                    chunk = await loop.run_in_executor(None, reader.read, end - offset, offset)
                    if not chunk:
                        break
                    offset += len(chunk)
                    yield chunk
            finally:
                await loop.run_in_executor(None, reader.close)
        except Exception:
            try:
                f = await loop.run_in_executor(None, lambda: open(self._file_path, 'rb'))
                try:
                    while True:
                        chunk = await loop.run_in_executor(None, f.read, self._chunk_size)
                        if not chunk:
                            break
                        yield chunk
                finally:
                    await loop.run_in_executor(None, f.close)
            except Exception:
                logger.warning("Zero-copy file send failed", exc_info=True)

    def _open_mmap_reader(self):
        return MmapFileReader(self._file_path).__enter__()

    @property
    def status(self):
        return self._resp.status

    @status.setter
    def status(self, value):
        self._resp.status = value

    @property
    def headers(self):
        return self._resp.headers

    @headers.setter
    def headers(self, value):
        self._resp.headers = value

    @property
    def content_type(self):
        return self._resp.content_type

    @content_type.setter
    def content_type(self, value):
        self._resp.content_type = value

    @property
    def body(self):
        return self._resp.body

    @property
    def is_streaming(self):
        return True

    @property
    def stream_generator(self):
        return self._resp.stream_generator

    @property
    def background(self):
        return self._resp.background

    def get_cookie_headers(self):
        return self._resp.get_cookie_headers()

    def set_cookie(self, key, value, **kwargs):
        self._resp.set_cookie(key, value, **kwargs)

    def delete_cookie(self, key, **kwargs):
        self._resp.delete_cookie(key, **kwargs)

    @property
    def cookies(self):
        return self._resp.cookies

    @property
    def _headers(self):
        return self._resp._headers

    @property
    def _cookies(self):
        return self._resp._cookies

    @property
    def status_code(self):
        return self._resp.status_code

    @property
    def file_size(self) -> int:
        return self._file_size


class ZeroCopyBuffer:
    """
    零拷贝缓冲区
    使用内存视图避免数据复制
    """
    
    def __init__(self, initial_size: int = 8192):
        self._buffer = bytearray(initial_size)
        self._view = memoryview(self._buffer)
        self._size = 0
    
    def write(self, data: bytes) -> int:
        """写入数据"""
        data_len = len(data)
        
        # 扩展缓冲区
        if self._size + data_len > len(self._buffer):
            new_size = max(len(self._buffer) * 2, self._size + data_len)
            new_buffer = bytearray(new_size)
            new_buffer[:self._size] = self._buffer[:self._size]
            self._buffer = new_buffer
            self._view = memoryview(self._buffer)
        
        # 使用内存视图写入（零拷贝）
        if isinstance(data, (bytes, bytearray)):
            self._view[self._size:self._size + data_len] = data
        else:
            # 对于其他类型，需要复制
            self._buffer[self._size:self._size + data_len] = data
        
        self._size += data_len
        return data_len
    
    def get_buffer(self) -> memoryview:
        """获取内存视图（零拷贝）"""
        return self._view[:self._size]
    
    def get_bytes(self) -> bytes:
        """获取字节串（需要复制）"""
        return bytes(self._view[:self._size])
    
    def clear(self):
        """清空缓冲区"""
        self._size = 0
    
    def __len__(self) -> int:
        return self._size


class FileCache:
    """
    文件缓存
    使用mmap缓存频繁访问的文件
    """
    
    def __init__(self, max_size: int = 100 * 1024 * 1024):  # 100MB
        self.max_size = max_size
        self._cache: dict = {}
        self._current_size = 0
    
    def get(self, file_path: Union[str, Path]) -> Optional[mmap.mmap]:
        """获取缓存的文件"""
        file_path = str(file_path)
        
        if file_path in self._cache:
            return self._cache[file_path]['mmap']
        
        return None
    
    def put(self, file_path: Union[str, Path]) -> Optional[mmap.mmap]:
        """缓存文件"""
        file_path = Path(file_path)
        file_size = file_path.stat().st_size
        
        # 检查大小限制
        if file_size > self.max_size:
            return None
        
        # 清理空间
        while self._current_size + file_size > self.max_size:
            self._evict_oldest()
        
        # 创建内存映射
        try:
            with open(file_path, 'rb') as f:
                mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
            
            import time
            self._cache[str(file_path)] = {
                'mmap': mm,
                'size': file_size,
                'time': time.time()
            }
            self._current_size += file_size
            
            return mm
            
        except Exception as e:
            logger.error(f"Failed to cache file: {e}")
            return None
    
    def _evict_oldest(self):
        """移除最旧的缓存"""
        if not self._cache:
            return
        
        import time
        oldest = min(self._cache.items(), key=lambda x: x[1]['time'])
        file_path, entry = oldest
        
        entry['mmap'].close()
        self._current_size -= entry['size']
        del self._cache[file_path]

    def clear(self):
        """清空缓存"""
        for entry in self._cache.values():
            entry['mmap'].close()
        
        self._cache.clear()
        self._current_size = 0


# 便捷函数
async def sendfile(
    transport,
    file_path: Union[str, Path],
    offset: int = 0,
    count: Optional[int] = None
) -> int:
    """
    使用sendfile发送文件
    
    Args:
        transport: 传输对象
        file_path: 文件路径
        offset: 起始偏移
        count: 发送字节数
        
    Returns:
        发送的字节数
    """
    sender = SendfileTransport(transport)
    return await sender.sendfile(file_path, offset, count)


def create_mmap_reader(file_path: Union[str, Path]) -> MmapFileReader:
    """
    创建内存映射文件读取器
    
    Args:
        file_path: 文件路径
        
    Returns:
        MmapFileReader实例
    """
    return MmapFileReader(file_path)


def is_sendfile_available() -> bool:
    """检查sendfile是否可用"""
    return ZeroCopySupport.is_supported()


ZeroCopyTransport = SendfileTransport

__all__ = [
    'ZeroCopySupport',
    'SendfileTransport',
    'ZeroCopyTransport',
    'MmapFileReader',
    'ZeroCopyFileResponse',
    'ZeroCopyBuffer',
    'FileCache',
]


# 性能测试
def benchmark_transfer(file_path: Union[str, Path], iterations: int = 10):
    """
    基准测试不同传输方式
    
    Args:
        file_path: 测试文件路径
        iterations: 迭代次数
    """
    import time
    
    file_path = Path(file_path)
    file_size = file_path.stat().st_size
    
    print(f"Benchmarking file: {file_path} ({file_size} bytes)")
    print(f"Iterations: {iterations}")
    print()
    
    # 测试普通读取
    read_times = []
    for _ in range(iterations):
        start = time.time()
        with open(file_path, 'rb') as f:
            while f.read(8192):
                pass
        read_times.append(time.time() - start)
    
    print(f"Regular read:     {sum(read_times)/len(read_times)*1000:.2f}ms (avg)")
    
    # 测试mmap
    mmap_times = []
    for _ in range(iterations):
        start = time.time()
        with MmapFileReader(file_path) as reader:
            for _ in reader.read_chunked(8192):
                pass
        mmap_times.append(time.time() - start)
    
    print(f"Mmap read:        {sum(mmap_times)/len(mmap_times)*1000:.2f}ms (avg)")
    
    # 测试sendfile（如果可用）
    if ZeroCopySupport.HAS_SENDFILE:
        import tempfile
        
        sendfile_times = []
        for _ in range(iterations):
            # 创建目标文件描述符
            with tempfile.TemporaryFile() as dest:
                start = time.time()
                with open(file_path, 'rb') as src:
                    offset = 0
                    while offset < file_size:
                        sent = os.sendfile(dest.fileno(), src.fileno(), offset, file_size - offset)
                        if sent == 0:
                            break
                        offset += sent
                sendfile_times.append(time.time() - start)
        
        print(f"Sendfile:         {sum(sendfile_times)/len(sendfile_times)*1000:.2f}ms (avg)")




