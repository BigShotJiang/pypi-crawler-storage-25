#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
性能优化模块 - Performance Optimization Module
提供各种性能优化功能，包括缓存、连接池、零拷贝等
"""
import asyncio
import logging
import functools
from typing import Dict, List, Optional, Callable, Any, Union
from collections import OrderedDict
from dataclasses import dataclass
from time import time

from kewe.cache.lru_cache import LRUCache
from kewe.cache import cached

logger = logging.getLogger(__name__)


@dataclass
class ConnectionPoolConfig:
    """连接池配置 — 统一配置对象

    合并了 utils.advanced 和 touchup.performance 两套配置，
    同时兼容 ConnectionPoolConfig(factory, config=...) 和
    ConnectionPool(factory, max_size=10, ...) 两种初始化方式。
    """
    max_size: int = 10
    min_size: int = 0
    max_overflow: int = 10
    max_idle: int = 5
    timeout: float = 30.0
    ttl: float = 300.0
    recycle: float = 3600.0
    stale: float = 300.0


class ConnectionPool:
    """
    连接池实现 — 统一版本

    合并了 kewe.utils.advanced.ConnectionPool 和
    kewe.touchup.performance.ConnectionPool 两套实现，
    保留双方所有能力：TTL 有效性检查、max_idle/max_overflow、
    上下文管理器、ConnectionPoolConfig 配置对象。

    使用示例:
        # 方式一：直接参数
        pool = ConnectionPool(
            factory=create_db_connection,
            max_size=10,
            max_idle=5,
            ttl=300
        )

        # 方式二：配置对象
        config = ConnectionPoolConfig(max_size=20, max_overflow=5)
        pool = ConnectionPool(factory=create_db_connection, config=config)

        # 获取/释放连接
        conn = await pool.acquire()
        try:
            await conn.execute("SELECT * FROM users")
        finally:
            await pool.release(conn)

        # 上下文管理器
        async with pool:
            conn = await pool.acquire()
    """

    def __init__(
        self,
        factory: Callable,
        max_size: int = None,
        max_idle: int = None,
        ttl: float = None,
        config: ConnectionPoolConfig = None,
        **kwargs
    ):
        if config is not None:
            self.config = config
        else:
            cfg_max_size = max_size if max_size is not None else kwargs.get('max_size', 10)
            cfg_max_idle = max_idle if max_idle is not None else kwargs.get('max_idle', 5)
            cfg_ttl = ttl if ttl is not None else kwargs.get('ttl', 300.0)
            cfg_max_overflow = kwargs.get('max_overflow', 10)
            cfg_timeout = kwargs.get('timeout', 30.0)
            cfg_min_size = kwargs.get('min_size', 0)
            cfg_recycle = kwargs.get('recycle', 3600.0)
            cfg_stale = kwargs.get('stale', 300.0)
            self.config = ConnectionPoolConfig(
                max_size=cfg_max_size,
                min_size=cfg_min_size,
                max_overflow=cfg_max_overflow,
                max_idle=cfg_max_idle,
                timeout=cfg_timeout,
                ttl=cfg_ttl,
                recycle=cfg_recycle,
                stale=cfg_stale,
            )

        self.factory = factory

        self._pool: asyncio.Queue = asyncio.Queue(maxsize=self.config.max_size)
        self._size: int = 0
        self._lock = asyncio.Lock()
        self._connections: Dict[Any, float] = {}
        self._in_use: Dict[int, Any] = {}

    @property
    def max_size(self) -> int:
        return self.config.max_size

    @property
    def max_idle(self) -> int:
        return self.config.max_idle

    @property
    def ttl(self) -> float:
        return self.config.ttl

    async def acquire(self, timeout: float = None) -> Any:
        """获取连接

        Args:
            timeout: 等待超时秒数，None 使用配置中的 timeout
        """
        effective_timeout = timeout if timeout is not None else self.config.timeout

        async with self._lock:
            if not self._pool.empty():
                conn = self._pool.get_nowait()
                if await self._is_valid(conn):
                    self._in_use[id(conn)] = conn
                    return conn
                else:
                    self._size -= 1
                    self._connections.pop(conn, None)

            if self._size < self.config.max_size + self.config.max_overflow:
                conn = await self.factory()
                self._size += 1
                self._connections[conn] = time()
                self._in_use[id(conn)] = conn
                return conn

        if effective_timeout is not None and effective_timeout > 0:
            try:
                conn = await asyncio.wait_for(self._pool.get(), timeout=effective_timeout)
            except asyncio.TimeoutError:
                raise TimeoutError(
                    f"ConnectionPool.acquire() timed out after {effective_timeout}s"
                )
        else:
            conn = await self._pool.get()

        if await self._is_valid(conn):
            async with self._lock:
                self._in_use[id(conn)] = conn
            return conn

        async with self._lock:
            self._size -= 1
            self._connections.pop(conn, None)

        raise RuntimeError("Failed to acquire valid connection")

    async def release(self, conn: Any):
        """释放连接"""
        if conn is None:
            return

        conn_id = id(conn)
        async with self._lock:
            self._in_use.pop(conn_id, None)

            if self._pool.qsize() < self.config.max_idle:
                await self._pool.put(conn)
            else:
                await self._destroy(conn)

    async def _is_valid(self, conn) -> bool:
        """检查连接是否有效（TTL 检查）"""
        created_time = self._connections.get(conn, 0)
        if time() - created_time > self.config.ttl:
            return False
        return True

    async def _destroy(self, conn: Any):
        """销毁连接"""
        self._size -= 1
        self._connections.pop(conn, None)
        if hasattr(conn, 'close'):
            if asyncio.iscoroutinefunction(conn.close):
                await conn.close()
            else:
                conn.close()

    async def close(self):
        """关闭连接池中所有空闲连接"""
        while not self._pool.empty():
            try:
                conn = self._pool.get_nowait()
                await self._destroy(conn)
            except asyncio.QueueEmpty:
                break

    async def close_all(self):
        """关闭所有连接（包括正在使用的）"""
        await self.close()

        for conn_id, conn in list(self._in_use.items()):
            try:
                await self._destroy(conn)
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)
        self._in_use.clear()

    @property
    def pool_size(self) -> int:
        """当前池中空闲连接数"""
        return self._pool.qsize()

    @property
    def in_use_count(self) -> int:
        """当前正在使用的连接数"""
        return len(self._in_use)

    @property
    def total_size(self) -> int:
        """总连接数（空闲 + 使用中）"""
        return self._size

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self.close())
        except RuntimeError:
            pass

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()


class ZeroCopyTransport:
    """
    零拷贝传输实现
    
    使用sendfile系统调用实现零拷贝文件传输
    
    使用示例:
        transport = ZeroCopyTransport()
        await transport.sendfile(writer, '/path/to/file')
    """
    
    @staticmethod
    async def sendfile(
        writer,
        file_path: str,
        offset: int = 0,
        count: int = -1
    ) -> int:
        """
        使用sendfile发送文件
        
        Args:
            writer: 写入器（如asyncio.StreamWriter）
            file_path: 文件路径
            offset: 起始偏移量
            count: 发送字节数，-1表示全部
            
        Returns:
            发送的字节数
        """
        import os
        
        try:
            # 尝试使用sendfile
            loop = asyncio.get_running_loop()
            
            with open(file_path, 'rb') as f:
                if offset > 0:
                    f.seek(offset)
                
                # 获取文件大小
                if count < 0:
                    count = os.path.getsize(file_path) - offset
                
                # 使用sendfile（如果支持）
                if hasattr(loop, 'sendfile'):
                    transport = writer.transport
                    sent = await loop.sendfile(
                        transport,
                        f,
                        offset=offset,
                        count=count
                    )
                    return sent
                else:
                    # 回退到普通读取
                    chunk_size = 64 * 1024  # 64KB
                    sent = 0
                    
                    while sent < count:
                        to_read = min(chunk_size, count - sent)
                        data = f.read(to_read)
                        if not data:
                            break
                        writer.write(data)
                        await writer.drain()
                        sent += len(data)
                    
                    return sent
                    
        except Exception as e:
            logger.error(f"Sendfile error: {e}")
            raise


class ExtendedPerformanceMonitor:
    """
    性能监控器

    统一入口，委托给monitoring.core.PerformanceMonitor，
    同时保留track装饰器和内存追踪能力。
    """

    def __init__(self, app=None):
        from kewe.monitoring.core import PerformanceMonitor as CoreMonitor
        self._core = CoreMonitor(app)
        self.metrics: Dict[str, List[float]] = {
            'request_times': [],
            'memory_usage': [],
        }
        self._start_times: Dict[str, float] = {}

    def track(self, func):
        """性能追踪装饰器"""
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            start = time()
            try:
                return await func(*args, **kwargs)
            finally:
                elapsed = time() - start
                self.metrics['request_times'].append(elapsed)
                if len(self.metrics['request_times']) > 1000:
                    self.metrics['request_times'] = self.metrics['request_times'][-1000:]

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            start = time()
            try:
                return func(*args, **kwargs)
            finally:
                elapsed = time() - start
                self.metrics['request_times'].append(elapsed)
                if len(self.metrics['request_times']) > 1000:
                    self.metrics['request_times'] = self.metrics['request_times'][-1000:]

        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper

    def record_request_start(self, method: str, path: str):
        self._core.record_request_start(method, path)

    def record_request_end(self, method: str, path: str, status: int, duration: float):
        self._core.record_request_end(method, path, status, duration)

    def get_stats(self) -> Dict[str, Any]:
        core_stats = self._core.get_stats()
        times = self.metrics['request_times']
        if times:
            core_stats.update({
                'avg_response_time': sum(times) / len(times),
                'min_response_time': min(times),
                'max_response_time': max(times),
                'requests_per_second': len(times) / sum(times) if sum(times) > 0 else 0,
            })
        return core_stats

    def reset(self):
        for key in self.metrics:
            self.metrics[key] = []

    def start_memory_tracking(self, nframe: int = 25):
        try:
            import tracemalloc
            if not tracemalloc.is_tracing():
                tracemalloc.start(nframe)
        except ImportError:
            pass

    def stop_memory_tracking(self):
        try:
            import tracemalloc
            if tracemalloc.is_tracing():
                tracemalloc.stop()
        except ImportError:
            pass

    def take_memory_snapshot(self):
        try:
            import tracemalloc
            if not tracemalloc.is_tracing():
                return None
            return tracemalloc.take_snapshot()
        except ImportError:
            return None

    def get_top_memory_allocations(self, limit: int = 10, snapshot=None):
        try:
            import tracemalloc
            if snapshot is None:
                snapshot = self.take_memory_snapshot()
            if snapshot is None:
                return []
            stats = snapshot.statistics('lineno')
            result = []
            for stat in stats[:limit]:
                result.append({
                    'file': str(stat.traceback),
                    'size_kb': stat.size / 1024,
                    'count': stat.count,
                })
            return result
        except ImportError:
            return []

    def compare_memory_snapshots(self, snapshot1, snapshot2, limit: int = 10):
        try:
            import tracemalloc
            diffs = snapshot2.compare_to(snapshot1, 'lineno')
            result = []
            for diff in diffs[:limit]:
                result.append({
                    'file': str(diff.traceback),
                    'size_diff_kb': diff.size / 1024,
                    'count_diff': diff.count,
                })
            return result
        except ImportError:
            return []


def optimize_json():
    from kewe.utils.compat import json as _json
    logger.info("Using JsonWrapper (orjson > ujson fallback) for JSON processing")
    return _json


def setup_performance_optimizations():
    """
    设置所有性能优化
    
    自动应用所有可用的性能优化
    """
    optimizations = []
    
    # 1. 事件循环优化
    try:
        import uvloop
        asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
        optimizations.append("uvloop")
        logger.info("Enabled uvloop event loop")
    except ImportError:
        pass
    
    # 2. JSON优化 (orjson为默认最优，ujson为备选)
    try:
        import orjson
        optimizations.append("orjson")
        logger.info("Enabled orjson for JSON processing (4-5x stdlib)")
    except ImportError:
        pass

    try:
        import ujson
        optimizations.append("ujson")
        logger.info("Enabled ujson for JSON processing")
    except ImportError:
        pass
    
    # 3. HTTP解析优化
    try:
        import httptools
        optimizations.append("httptools")
        logger.info("Enabled httptools for HTTP parsing")
    except ImportError:
        pass
    
    logger.info(f"Applied {len(optimizations)} performance optimizations: {', '.join(optimizations)}")
    return optimizations


__all__ = [
    'ConnectionPoolConfig',
    'LRUCache',
    'cached',
    'ConnectionPool',
    'ZeroCopyTransport',
    'ExtendedPerformanceMonitor',
    'optimize_json',
    'setup_performance_optimizations',
]

