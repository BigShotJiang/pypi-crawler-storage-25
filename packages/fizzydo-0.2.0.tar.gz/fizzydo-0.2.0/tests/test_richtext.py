import pytest

from fizzydo.errors import FizzyError
from fizzydo.richtext import to_html


def test_none_passthrough():
    assert to_html(None) is None


def test_plain_text_wrapped_and_escaped():
    html = to_html("<script>alert(1)</script>")
    assert html is not None
    assert html.startswith("<p>")
    assert "<script>" not in html
    assert "&lt;script&gt;" in html


def test_markdown_file(tmp_path):
    f = tmp_path / "body.md"
    f.write_text("# Title\n\nSome **bold**.\n", encoding="utf-8")
    html = to_html(f"@{f}")
    assert html is not None
    assert "<h1>" in html
    assert "<strong>" in html


def test_html_file_passthrough(tmp_path):
    f = tmp_path / "body.html"
    raw = "<div>literally <em>this</em></div>"
    f.write_text(raw, encoding="utf-8")
    assert to_html(f"@{f}") == raw


def test_missing_file(tmp_path):
    with pytest.raises(FizzyError):
        to_html(f"@{tmp_path / 'nope.md'}")
