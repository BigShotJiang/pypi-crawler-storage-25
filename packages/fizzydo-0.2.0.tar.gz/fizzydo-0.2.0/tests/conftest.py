"""Shared fixtures for fizzydo tests."""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

BASE_URL = "https://app.fizzy.do"
ACCOUNT_SLUG = "897362094"


@pytest.fixture(autouse=True)
def _isolated_env(monkeypatch, tmp_path: Path) -> None:
    """Isolate every test from any real .env file or stray env vars."""
    monkeypatch.delenv("FIZZYDO_API_KEY", raising=False)
    monkeypatch.delenv("FIZZYDO_ACCOUNT", raising=False)
    monkeypatch.delenv("FIZZYDO_BASE_URL", raising=False)
    # Run from a temp dir so we don't pick up the project's .env (if any).
    monkeypatch.chdir(tmp_path)
    # Move HOME so $HOME/.env doesn't surprise us either.
    monkeypatch.setenv("HOME", str(tmp_path))


@pytest.fixture
def configured_env(monkeypatch) -> None:
    """Set the env vars a typical CLI invocation expects."""
    monkeypatch.setenv("FIZZYDO_API_KEY", "test-token")
    monkeypatch.setenv("FIZZYDO_ACCOUNT", ACCOUNT_SLUG)


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


# ---- sample payloads (verbatim shape from Fizzy_API.md) ---------------------


@pytest.fixture
def board_payload() -> dict:
    return {
        "id": "03f5v9zkft4hj9qq0lsn9ohcm",
        "name": "Fizzy",
        "all_access": True,
        "created_at": "2025-12-05T19:36:35.534Z",
        "auto_postpone_period_in_days": 30,
        "url": f"{BASE_URL}/{ACCOUNT_SLUG}/boards/03f5v9zkft4hj9qq0lsn9ohcm",
        "creator": {
            "id": "03f5v9zjw7pz8717a4no1h8a7",
            "name": "David Heinemeier Hansson",
            "role": "owner",
            "active": True,
            "email_address": "david@example.com",
            "created_at": "2025-12-05T19:36:35.401Z",
            "url": f"{BASE_URL}/{ACCOUNT_SLUG}/users/03f5v9zjw7pz8717a4no1h8a7",
        },
    }


@pytest.fixture
def card_payload() -> dict:
    return {
        "id": "03f5vaeq985jlvwv3arl4srq2",
        "number": 1,
        "title": "First!",
        "status": "published",
        "description": "Hello, World!",
        "description_html": "<div class=\"action-text-content\"><p>Hello, World!</p></div>",
        "image_url": None,
        "has_attachments": False,
        "tags": ["programming"],
        "golden": False,
        "last_active_at": "2025-12-05T19:38:48.553Z",
        "created_at": "2025-12-05T19:38:48.540Z",
        "url": f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1",
        "board": {
            "id": "03f5v9zkft4hj9qq0lsn9ohcm",
            "name": "Fizzy",
        },
        "creator": {"id": "u1", "name": "DHH"},
        "comments_url": f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/comments",
        "reactions_url": f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/reactions",
    }


@pytest.fixture
def identity_payload() -> dict:
    return {
        "accounts": [
            {
                "id": "03f5v9zjskhcii2r45ih3u1rq",
                "name": "37signals",
                "slug": f"/{ACCOUNT_SLUG}",
                "created_at": "2025-12-05T19:36:35.377Z",
                "user": {
                    "id": "03f5v9zjw7pz8717a4no1h8a7",
                    "name": "David Heinemeier Hansson",
                    "role": "owner",
                    "active": True,
                    "email_address": "david@example.com",
                    "created_at": "2025-12-05T19:36:35.401Z",
                    "url": f"{BASE_URL}/users/03f5v9zjw7pz8717a4no1h8a7",
                },
            }
        ]
    }


@pytest.fixture
def comment_payload() -> dict:
    return {
        "id": "c1",
        "created_at": "2025-12-05T19:36:35.534Z",
        "updated_at": "2025-12-05T19:36:35.534Z",
        "body": {
            "plain_text": "Looks good!",
            "html": "<div>Looks good!</div>",
        },
        "creator": {"id": "u1", "name": "DHH"},
    }


@pytest.fixture
def step_payload() -> dict:
    return {"id": "s1", "content": "Write tests", "completed": False}


@pytest.fixture
def column_payload() -> dict:
    return {
        "id": "col1",
        "name": "In Progress",
        "color": "var(--color-card-default)",
        "created_at": "2025-12-05T19:36:35.534Z",
    }


@pytest.fixture
def tag_payload() -> dict:
    return {
        "id": "t1",
        "title": "bug",
        "created_at": "2025-12-05T19:36:35.534Z",
        "url": f"{BASE_URL}/{ACCOUNT_SLUG}/cards?tag_ids[]=t1",
    }
