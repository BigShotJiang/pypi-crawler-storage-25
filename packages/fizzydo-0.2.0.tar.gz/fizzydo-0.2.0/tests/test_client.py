import pytest
from pytest_httpx import HTTPXMock

from fizzydo import __version__
from fizzydo.client import FizzyClient
from fizzydo.errors import FizzyError

BASE_URL = "https://app.fizzy.do"


@pytest.fixture
def client() -> FizzyClient:
    return FizzyClient(token="abc", base_url=BASE_URL, account="897362094")


def test_authorization_and_user_agent_headers(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{BASE_URL}/my/identity", json={"accounts": []})
    client.get("/my/identity")
    request = httpx_mock.get_request()
    assert request.headers["authorization"] == "Bearer abc"
    assert request.headers["user-agent"] == f"fizzydo/{__version__}"
    assert request.headers["accept"] == "application/json"


def test_account_path(client):
    assert client.account_path("/cards") == "/897362094/cards"
    assert client.account_path("boards") == "/897362094/boards"


def test_pagination_follows_link_header(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/897362094/cards",
        json=[{"id": "1"}, {"id": "2"}],
        headers={"link": f'<{BASE_URL}/897362094/cards?page=2>; rel="next"'},
    )
    httpx_mock.add_response(
        url=f"{BASE_URL}/897362094/cards?page=2",
        json=[{"id": "3"}],
    )
    items = list(client.paginate(client.account_path("/cards"), all_pages=True))
    assert [i["id"] for i in items] == ["1", "2", "3"]


def test_pagination_default_one_page(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/897362094/cards",
        json=[{"id": "1"}, {"id": "2"}],
        headers={"link": f'<{BASE_URL}/897362094/cards?page=2>; rel="next"'},
    )
    items = list(client.paginate(client.account_path("/cards")))
    assert [i["id"] for i in items] == ["1", "2"]


def test_pagination_limit_stops_early(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/897362094/cards",
        json=[{"id": "1"}, {"id": "2"}, {"id": "3"}],
    )
    items = list(client.paginate(client.account_path("/cards"), limit=2))
    assert [i["id"] for i in items] == ["1", "2"]


def test_error_response_carries_status_and_body(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/897362094/boards",
        status_code=422,
        json={"name": ["can't be blank"]},
    )
    with pytest.raises(FizzyError) as excinfo:
        client.post(client.account_path("/boards"), json={"board": {}})
    assert excinfo.value.status_code == 422
    assert excinfo.value.body == {"name": ["can't be blank"]}
    assert "can't be blank" in excinfo.value.message


def test_404_error(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{BASE_URL}/897362094/cards/9999", status_code=404)
    with pytest.raises(FizzyError) as excinfo:
        client.get(client.account_path("/cards/9999"))
    assert excinfo.value.status_code == 404


def test_created_resource_follows_location(client, httpx_mock: HTTPXMock):
    location = f"{BASE_URL}/897362094/boards/new123"
    httpx_mock.add_response(
        url=f"{BASE_URL}/897362094/boards",
        status_code=201,
        headers={"Location": location},
        # No body, just the Location header.
        text="",
    )
    httpx_mock.add_response(url=location, json={"id": "new123", "name": "Brand New"})
    response = client.post(
        client.account_path("/boards"), json={"board": {"name": "Brand New"}}
    )
    item = client.created_resource(response)
    assert item == {"id": "new123", "name": "Brand New"}


def test_created_resource_uses_inline_body_when_present(client, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/897362094/boards/x/publication",
        status_code=201,
        json={"id": "x", "name": "Pub"},
    )
    response = client.post(client.account_path("/boards/x/publication"))
    assert client.created_resource(response) == {"id": "x", "name": "Pub"}
