import json as _json

from pytest_httpx import HTTPXMock

from fizzydo.cli import app
from tests.conftest import ACCOUNT_SLUG, BASE_URL


def test_list_comments(runner, configured_env, comment_payload, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/comments", json=[comment_payload]
    )
    result = runner.invoke(app, ["comments", "list", "1"])
    assert result.exit_code == 0, result.output
    assert "Looks good!" in result.output


def test_add_comment(runner, configured_env, comment_payload, httpx_mock: HTTPXMock):
    location = f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/comments/c1"
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/comments",
        method="POST",
        status_code=201,
        headers={"Location": location},
        text="",
    )
    httpx_mock.add_response(url=location, json=comment_payload)
    result = runner.invoke(app, ["comments", "add", "1", "Looks good!"])
    assert result.exit_code == 0, result.output

    body = _json.loads(httpx_mock.get_requests()[0].content)
    assert body == {"comment": {"body": "<p>Looks good!</p>"}}


def test_add_comment_no_body_errors(runner, configured_env):
    result = runner.invoke(app, ["comments", "add", "1"])
    assert result.exit_code != 0


def test_delete_comment(runner, configured_env, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/comments/c1",
        method="DELETE",
        status_code=204,
    )
    result = runner.invoke(app, ["comments", "delete", "1", "c1"])
    assert result.exit_code == 0, result.output
    assert "deleted" in result.output.lower()
