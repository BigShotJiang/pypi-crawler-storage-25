import json as _json

from pytest_httpx import HTTPXMock

from fizzydo.cli import app
from tests.conftest import ACCOUNT_SLUG, BASE_URL


def test_list_steps_from_card(
    runner, configured_env, card_payload, step_payload, httpx_mock: HTTPXMock
):
    card_with_steps = {**card_payload, "steps": [step_payload]}
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1", json=card_with_steps
    )
    result = runner.invoke(app, ["steps", "list", "1"])
    assert result.exit_code == 0, result.output
    assert "Write tests" in result.output


def test_add_step(runner, configured_env, step_payload, httpx_mock: HTTPXMock):
    location = f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/steps/s1"
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/steps",
        method="POST",
        status_code=201,
        headers={"Location": location},
        text="",
    )
    httpx_mock.add_response(url=location, json=step_payload)
    result = runner.invoke(app, ["steps", "add", "1", "Write tests"])
    assert result.exit_code == 0, result.output

    body = _json.loads(httpx_mock.get_requests()[0].content)
    assert body == {"step": {"content": "Write tests"}}


def test_done_step(runner, configured_env, step_payload, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/steps/s1",
        method="PUT",
        json={**step_payload, "completed": True},
    )
    result = runner.invoke(app, ["steps", "done", "1", "s1"])
    assert result.exit_code == 0, result.output

    body = _json.loads(httpx_mock.get_request().content)
    assert body == {"step": {"completed": True}}


def test_done_step_by_index(
    runner, configured_env, card_payload, httpx_mock: HTTPXMock
):
    card_with_steps = {
        **card_payload,
        "steps": [
            {"id": "s_alpha", "content": "First", "completed": False},
            {"id": "s_beta", "content": "Second", "completed": False},
        ],
    }
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1", json=card_with_steps
    )
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/steps/s_beta",
        method="PUT",
        json={"id": "s_beta", "content": "Second", "completed": True},
    )
    result = runner.invoke(app, ["steps", "done", "1", "2"])
    assert result.exit_code == 0, result.output

    requests = httpx_mock.get_requests()
    assert len(requests) == 2
    assert requests[0].method == "GET"
    assert requests[0].url.path.endswith("/cards/1")
    assert requests[1].method == "PUT"
    assert requests[1].url.path.endswith("/cards/1/steps/s_beta")


def test_done_step_index_out_of_range(
    runner, configured_env, card_payload, httpx_mock: HTTPXMock
):
    card_with_steps = {
        **card_payload,
        "steps": [{"id": "s1", "content": "Only one", "completed": False}],
    }
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1", json=card_with_steps
    )
    result = runner.invoke(app, ["steps", "done", "1", "5"])
    assert result.exit_code != 0
    # Only the GET fired; no PUT was attempted.
    requests = httpx_mock.get_requests()
    assert len(requests) == 1
    assert requests[0].method == "GET"


def test_delete_step_by_index(
    runner, configured_env, card_payload, httpx_mock: HTTPXMock
):
    card_with_steps = {
        **card_payload,
        "steps": [{"id": "s_zulu", "content": "Doomed", "completed": False}],
    }
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1", json=card_with_steps
    )
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/steps/s_zulu",
        method="DELETE",
        status_code=204,
    )
    result = runner.invoke(app, ["steps", "delete", "1", "1"])
    assert result.exit_code == 0, result.output
