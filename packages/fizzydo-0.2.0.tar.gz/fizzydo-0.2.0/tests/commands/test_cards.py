from pytest_httpx import HTTPXMock

from fizzydo.cli import app
from tests.conftest import ACCOUNT_SLUG, BASE_URL


def test_list_cards(runner, configured_env, card_payload, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards", json=[card_payload]
    )
    result = runner.invoke(app, ["cards", "list"])
    assert result.exit_code == 0, result.output
    assert "First!" in result.output


def test_list_cards_with_filters(
    runner, configured_env, card_payload, httpx_mock: HTTPXMock
):
    httpx_mock.add_response(json=[card_payload])
    result = runner.invoke(
        app,
        [
            "cards",
            "list",
            "--board",
            "b1",
            "--tag",
            "t1",
            "--status",
            "closed",
            "--sort",
            "newest",
            "--search",
            "bug",
        ],
    )
    assert result.exit_code == 0, result.output
    request = httpx_mock.get_request()
    query = request.url.params
    assert query.get_list("board_ids[]") == ["b1"]
    assert query.get_list("tag_ids[]") == ["t1"]
    assert query.get("indexed_by") == "closed"
    assert query.get("sorted_by") == "newest"
    assert query.get_list("terms[]") == ["bug"]


def test_list_cards_id_mode(
    runner, configured_env, card_payload, httpx_mock: HTTPXMock
):
    second = {**card_payload, "number": 7, "title": "Second"}
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards", json=[card_payload, second]
    )
    result = runner.invoke(app, ["--id", "cards", "list"])
    assert result.exit_code == 0, result.output
    lines = [line for line in result.output.strip().splitlines() if line]
    assert lines == ["1", "7"]


def test_show_card(runner, configured_env, card_payload, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1", json=card_payload
    )
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/comments", json=[]
    )
    result = runner.invoke(app, ["cards", "show", "1"])
    assert result.exit_code == 0, result.output
    assert "First!" in result.output
    assert "Hello, World!" in result.output


def test_show_card_renders_description_steps_and_comments(
    runner, configured_env, card_payload, comment_payload, httpx_mock: HTTPXMock
):
    rich_card = {
        **card_payload,
        "description_html": (
            "<div class=\"action-text-content\">"
            "<h2>Goal</h2><p>Ship the thing.</p>"
            "<ul><li>Write code</li><li>Write tests</li></ul>"
            "</div>"
        ),
        "steps": [
            {"id": "s1", "content": "Draft the API", "completed": True},
            {"id": "s2", "content": "Wire it up", "completed": False},
        ],
    }
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1", json=rich_card
    )
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/comments", json=[comment_payload]
    )
    result = runner.invoke(app, ["cards", "show", "1"])
    assert result.exit_code == 0, result.output
    assert "Goal" in result.output
    assert "Ship the thing." in result.output
    assert "Write code" in result.output
    assert "[x] Draft the API" in result.output
    assert "[ ] Wire it up" in result.output
    assert "Looks good!" in result.output


def test_show_card_json_mode_includes_comments(
    runner, configured_env, card_payload, comment_payload, httpx_mock: HTTPXMock
):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1", json=card_payload
    )
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/comments", json=[comment_payload]
    )
    result = runner.invoke(app, ["--json", "cards", "show", "1"])
    assert result.exit_code == 0, result.output
    import json as _json

    payload = _json.loads(result.output)
    assert payload["card"]["title"] == "First!"
    assert len(payload["comments"]) == 1
    assert payload["comments"][0]["id"] == "c1"


def test_create_card(runner, configured_env, card_payload, httpx_mock: HTTPXMock):
    location = f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1"
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards/b1/cards",
        method="POST",
        status_code=201,
        headers={"Location": location},
        text="",
    )
    httpx_mock.add_response(url=location, json=card_payload)
    result = runner.invoke(
        app,
        ["cards", "create", "--board", "b1", "--title", "First!", "--description", "Hi"],
    )
    assert result.exit_code == 0, result.output
    assert "First!" in result.output

    create_req = httpx_mock.get_requests()[0]
    import json as _json

    body = _json.loads(create_req.content)
    assert body == {"card": {"title": "First!", "description": "<p>Hi</p>"}}


def test_create_card_with_column_triages_after_create(
    runner, configured_env, card_payload, httpx_mock: HTTPXMock
):
    location = f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1"
    # POST /boards/b1/cards → 201 + Location
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards/b1/cards",
        method="POST",
        status_code=201,
        headers={"Location": location},
        text="",
    )
    # GET location (created_resource)
    httpx_mock.add_response(url=location, json=card_payload)
    # POST /cards/1/triage
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/triage",
        method="POST",
        status_code=204,
    )
    # Final GET to refresh display with column populated
    triaged = {**card_payload, "column": {"id": "col1", "name": "DOING"}}
    httpx_mock.add_response(url=location, json=triaged)

    result = runner.invoke(
        app,
        [
            "cards",
            "create",
            "--board",
            "b1",
            "--title",
            "First!",
            "--column",
            "col1",
        ],
    )
    assert result.exit_code == 0, result.output
    assert "DOING" in result.output

    requests = httpx_mock.get_requests()
    assert [r.method for r in requests] == ["POST", "GET", "POST", "GET"]
    triage_body = __import__("json").loads(requests[2].content)
    assert triage_body == {"column_id": "col1"}


def test_bulk_create_from_dir(
    runner, configured_env, card_payload, tmp_path, httpx_mock: HTTPXMock
):
    src = tmp_path / "tasks"
    src.mkdir()
    (src / "alpha.md").write_text("# Alpha card\n\nFirst body.\n", encoding="utf-8")
    (src / "beta_card.md").write_text("Plain body, no h1.\n", encoding="utf-8")
    (src / "empty.md").write_text("   \n", encoding="utf-8")

    location = f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1"
    # Two creates → two POST + GET pairs.
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards/b1/cards",
        method="POST",
        status_code=201,
        headers={"Location": location},
        text="",
    )
    httpx_mock.add_response(
        url=location, json={**card_payload, "number": 1, "title": "Alpha card"}
    )
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards/b1/cards",
        method="POST",
        status_code=201,
        headers={"Location": location},
        text="",
    )
    httpx_mock.add_response(
        url=location, json={**card_payload, "number": 2, "title": "Beta Card"}
    )

    result = runner.invoke(
        app,
        ["cards", "bulk-create", "--board", "b1", "--from-dir", str(src)],
    )
    assert result.exit_code == 0, result.output
    assert "Alpha card" in result.output
    assert "Beta Card" in result.output

    posts = [r for r in httpx_mock.get_requests() if r.method == "POST"]
    assert len(posts) == 2
    import json as _json

    first = _json.loads(posts[0].content)
    second = _json.loads(posts[1].content)
    # alpha.md → H1 stripped, body is "First body."
    assert first["card"]["title"] == "Alpha card"
    assert "First body" in first["card"]["description"]
    # beta_card.md → no H1, humanized filename, full body kept
    assert second["card"]["title"] == "Beta Card"
    assert "Plain body" in second["card"]["description"]


def test_bulk_create_with_column(
    runner, configured_env, card_payload, tmp_path, httpx_mock: HTTPXMock
):
    src = tmp_path / "tasks"
    src.mkdir()
    (src / "one.md").write_text("# One\n\nBody.\n", encoding="utf-8")

    location = f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1"
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards/b1/cards",
        method="POST",
        status_code=201,
        headers={"Location": location},
        text="",
    )
    httpx_mock.add_response(url=location, json=card_payload)
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/1/triage",
        method="POST",
        status_code=204,
    )
    httpx_mock.add_response(
        url=location,
        json={**card_payload, "column": {"id": "col1", "name": "DOING"}},
    )

    result = runner.invoke(
        app,
        [
            "cards",
            "bulk-create",
            "--board",
            "b1",
            "--from-dir",
            str(src),
            "--column",
            "col1",
        ],
    )
    assert result.exit_code == 0, result.output
    methods = [r.method for r in httpx_mock.get_requests()]
    assert methods == ["POST", "GET", "POST", "GET"]


def test_bulk_create_empty_dir_errors(runner, configured_env, tmp_path):
    src = tmp_path / "empty_dir"
    src.mkdir()
    result = runner.invoke(
        app,
        ["cards", "bulk-create", "--board", "b1", "--from-dir", str(src)],
    )
    assert result.exit_code != 0


def test_close_card(runner, configured_env, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/42/closure",
        method="POST",
        status_code=204,
    )
    result = runner.invoke(app, ["cards", "close", "42"])
    assert result.exit_code == 0, result.output
    assert "42" in result.output


def test_triage_card(runner, configured_env, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/42/triage",
        method="POST",
        status_code=204,
    )
    result = runner.invoke(app, ["cards", "triage", "42", "--column", "col1"])
    assert result.exit_code == 0, result.output

    import json as _json

    body = _json.loads(httpx_mock.get_request().content)
    assert body == {"column_id": "col1"}


def test_tag_card_strips_hash(runner, configured_env, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/42/taggings",
        method="POST",
        status_code=204,
    )
    result = runner.invoke(app, ["cards", "tag", "42", "#bug"])
    assert result.exit_code == 0, result.output

    import json as _json

    body = _json.loads(httpx_mock.get_request().content)
    assert body == {"tag_title": "bug"}


def test_invalid_status_rejected(runner, configured_env):
    result = runner.invoke(app, ["cards", "list", "--status", "bogus"])
    assert result.exit_code != 0


def test_status_all_merges_open_and_closed(
    runner, configured_env, card_payload, httpx_mock: HTTPXMock
):
    open_card = {
        **card_payload,
        "id": "card_open_id",
        "number": 1,
        "title": "Open one",
        "last_active_at": "2026-04-07T00:00:00Z",
    }
    closed_card = {
        **card_payload,
        "id": "card_closed_id",
        "number": 2,
        "title": "Closed one",
        "closed": True,
        "last_active_at": "2026-04-08T00:00:00Z",
    }
    # Two callbacks: first for the open feed, second for the closed feed.
    httpx_mock.add_response(json=[open_card])
    httpx_mock.add_response(json=[closed_card])

    result = runner.invoke(app, ["cards", "list", "--status", "all"])
    assert result.exit_code == 0, result.output
    assert "Open one" in result.output
    assert "Closed one" in result.output

    requests = httpx_mock.get_requests()
    assert len(requests) == 2
    # First request: no indexed_by param
    assert "indexed_by" not in requests[0].url.params
    # Second request: indexed_by=closed
    assert requests[1].url.params.get("indexed_by") == "closed"


def test_status_closed_makes_single_call(
    runner, configured_env, card_payload, httpx_mock: HTTPXMock
):
    httpx_mock.add_response(json=[card_payload])
    result = runner.invoke(app, ["cards", "list", "--status", "closed"])
    assert result.exit_code == 0, result.output
    requests = httpx_mock.get_requests()
    assert len(requests) == 1
    assert requests[0].url.params.get("indexed_by") == "closed"


def test_card_not_found_404(runner, configured_env, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/999", status_code=404
    )
    result = runner.invoke(app, ["cards", "show", "999"])
    assert result.exit_code != 0
    assert getattr(result.exception, "status_code", None) == 404


def test_mine_resolves_via_identity(
    runner, configured_env, identity_payload, card_payload, httpx_mock: HTTPXMock
):
    httpx_mock.add_response(url=f"{BASE_URL}/my/identity", json=identity_payload)
    httpx_mock.add_response(json=[card_payload])
    result = runner.invoke(app, ["cards", "list", "--mine"])
    assert result.exit_code == 0, result.output

    list_request = httpx_mock.get_requests()[1]
    user_id = identity_payload["accounts"][0]["user"]["id"]
    assert list_request.url.params.get_list("assignee_ids[]") == [user_id]
