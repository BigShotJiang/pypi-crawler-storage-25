from pytest_httpx import HTTPXMock

from fizzydo.cli import app
from tests.conftest import ACCOUNT_SLUG, BASE_URL


def test_whoami(runner, configured_env, identity_payload, httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{BASE_URL}/my/identity", json=identity_payload)
    result = runner.invoke(app, ["auth", "whoami"])
    assert result.exit_code == 0, result.output
    assert ACCOUNT_SLUG in result.output
    # The user-name column may wrap on narrow test terminals; assert on the
    # account-name column instead, which is short enough to always fit.
    assert "37signals" in result.output


def test_whoami_json(runner, configured_env, identity_payload, httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{BASE_URL}/my/identity", json=identity_payload)
    result = runner.invoke(app, ["--json", "auth", "whoami"])
    assert result.exit_code == 0, result.output
    assert "37signals" in result.output


def test_status_unauthorized(runner, configured_env, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/my/identity", status_code=401, json={"error": "nope"}
    )
    result = runner.invoke(app, ["auth", "status"])
    assert result.exit_code != 0
    assert result.exception is not None
    assert getattr(result.exception, "status_code", None) == 401
