from pytest_httpx import HTTPXMock

from fizzydo.cli import app
from tests.conftest import ACCOUNT_SLUG, BASE_URL


def test_list_columns(runner, configured_env, column_payload, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards/b1/columns", json=[column_payload]
    )
    result = runner.invoke(app, ["columns", "list", "--board", "b1"])
    assert result.exit_code == 0, result.output
    assert "In Progress" in result.output


def test_create_column_maps_color(
    runner, configured_env, column_payload, httpx_mock: HTTPXMock
):
    location = f"{BASE_URL}/{ACCOUNT_SLUG}/boards/b1/columns/col1"
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards/b1/columns",
        method="POST",
        status_code=201,
        headers={"Location": location},
        text="",
    )
    httpx_mock.add_response(url=location, json=column_payload)
    result = runner.invoke(
        app,
        ["columns", "create", "--board", "b1", "--name", "In Progress", "--color", "lime"],
    )
    assert result.exit_code == 0, result.output

    import json as _json

    body = _json.loads(httpx_mock.get_requests()[0].content)
    assert body == {"column": {"name": "In Progress", "color": "var(--color-card-4)"}}


def test_create_column_invalid_color(runner, configured_env):
    result = runner.invoke(
        app,
        ["columns", "create", "--board", "b1", "--name", "X", "--color", "octarine"],
    )
    assert result.exit_code != 0
