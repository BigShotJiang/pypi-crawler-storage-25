from pytest_httpx import HTTPXMock

from fizzydo.cli import app
from tests.conftest import ACCOUNT_SLUG, BASE_URL


def test_list_boards(runner, configured_env, board_payload, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards", json=[board_payload]
    )
    result = runner.invoke(app, ["boards", "list"])
    assert result.exit_code == 0, result.output
    assert "Fizzy" in result.output


def test_show_board(runner, configured_env, board_payload, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards/{board_payload['id']}",
        json=board_payload,
    )
    result = runner.invoke(app, ["boards", "show", board_payload["id"]])
    assert result.exit_code == 0, result.output
    assert "Fizzy" in result.output


def test_create_board_follows_location(
    runner, configured_env, board_payload, httpx_mock: HTTPXMock
):
    location = f"{BASE_URL}/{ACCOUNT_SLUG}/boards/{board_payload['id']}"
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards",
        method="POST",
        status_code=201,
        headers={"Location": location},
        text="",
    )
    httpx_mock.add_response(url=location, json=board_payload)
    result = runner.invoke(app, ["boards", "create", "--name", "Fizzy"])
    assert result.exit_code == 0, result.output
    assert "Fizzy" in result.output


def test_create_board_with_description_alias(
    runner, configured_env, board_payload, httpx_mock: HTTPXMock
):
    location = f"{BASE_URL}/{ACCOUNT_SLUG}/boards/{board_payload['id']}"
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards",
        method="POST",
        status_code=201,
        headers={"Location": location},
        text="",
    )
    httpx_mock.add_response(url=location, json=board_payload)
    result = runner.invoke(
        app,
        ["boards", "create", "--name", "Fizzy", "--description", "Hello board"],
    )
    assert result.exit_code == 0, result.output

    import json as _json

    body = _json.loads(httpx_mock.get_requests()[0].content)
    assert body["board"]["public_description"] == "<p>Hello board</p>"


def test_delete_board_204(runner, configured_env, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards/abc",
        method="DELETE",
        status_code=204,
    )
    result = runner.invoke(app, ["boards", "delete", "abc"])
    assert result.exit_code == 0, result.output
    assert "deleted" in result.output.lower()


def test_publish_board(runner, configured_env, board_payload, httpx_mock: HTTPXMock):
    published = {**board_payload, "public_url": "https://app.fizzy.do/public/x"}
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/boards/{board_payload['id']}/publication",
        method="POST",
        status_code=201,
        json=published,
    )
    result = runner.invoke(app, ["boards", "publish", board_payload["id"]])
    assert result.exit_code == 0, result.output


def test_update_board_requires_field(runner, configured_env):
    result = runner.invoke(app, ["boards", "update", "abc"])
    assert result.exit_code != 0
