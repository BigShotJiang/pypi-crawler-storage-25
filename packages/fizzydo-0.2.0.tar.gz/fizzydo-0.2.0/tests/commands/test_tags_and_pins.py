from pytest_httpx import HTTPXMock

from fizzydo.cli import app
from tests.conftest import ACCOUNT_SLUG, BASE_URL


def test_list_tags(runner, configured_env, tag_payload, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/tags", json=[tag_payload]
    )
    result = runner.invoke(app, ["tags", "list"])
    assert result.exit_code == 0, result.output
    assert "bug" in result.output


def test_list_pins(runner, configured_env, card_payload, httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{BASE_URL}/my/pins", json=[card_payload])
    result = runner.invoke(app, ["pins", "list"])
    assert result.exit_code == 0, result.output
    assert "First!" in result.output


def test_pin_add(runner, configured_env, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/42/pin",
        method="POST",
        status_code=204,
    )
    result = runner.invoke(app, ["pins", "add", "42"])
    assert result.exit_code == 0, result.output
    assert "Pinned" in result.output


def test_pin_remove(runner, configured_env, httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/{ACCOUNT_SLUG}/cards/42/pin",
        method="DELETE",
        status_code=204,
    )
    result = runner.invoke(app, ["pins", "remove", "42"])
    assert result.exit_code == 0, result.output
    assert "Unpinned" in result.output
