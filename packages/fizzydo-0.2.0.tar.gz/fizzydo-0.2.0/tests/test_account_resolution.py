"""Coverage for FizzyClient's lazy single-account resolution."""

import pytest
from pytest_httpx import HTTPXMock

from fizzydo.client import FizzyClient
from fizzydo.errors import FizzyError

BASE_URL = "https://app.fizzy.do"


def test_single_account_is_auto_resolved(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/my/identity",
        json={"accounts": [{"slug": "/123", "name": "Solo"}]},
    )
    client = FizzyClient(token="t", base_url=BASE_URL, account=None)
    assert client.account == "123"


def test_multiple_accounts_require_explicit_choice(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        url=f"{BASE_URL}/my/identity",
        json={
            "accounts": [
                {"slug": "/1", "name": "A"},
                {"slug": "/2", "name": "B"},
            ]
        },
    )
    client = FizzyClient(token="t", base_url=BASE_URL, account=None)
    with pytest.raises(FizzyError) as excinfo:
        _ = client.account
    assert "1" in excinfo.value.message and "2" in excinfo.value.message


def test_no_accounts_errors(httpx_mock: HTTPXMock):
    httpx_mock.add_response(url=f"{BASE_URL}/my/identity", json={"accounts": []})
    client = FizzyClient(token="t", base_url=BASE_URL, account=None)
    with pytest.raises(FizzyError):
        _ = client.account
