from fizzydo.errors import FizzyError, exit_code_for


def test_exit_code_known_statuses():
    assert exit_code_for(401) == 2
    assert exit_code_for(403) == 3
    assert exit_code_for(404) == 4
    assert exit_code_for(422) == 5
    assert exit_code_for(429) == 6


def test_exit_code_5xx_bucket():
    assert exit_code_for(500) == 7
    assert exit_code_for(503) == 7


def test_exit_code_unknown_or_none():
    assert exit_code_for(None) == 1
    assert exit_code_for(418) == 1


def test_fizzy_error_carries_body():
    err = FizzyError("boom", status_code=422, body={"name": ["is required"]})
    assert err.status_code == 422
    assert err.body == {"name": ["is required"]}
    assert "boom" in str(err)
