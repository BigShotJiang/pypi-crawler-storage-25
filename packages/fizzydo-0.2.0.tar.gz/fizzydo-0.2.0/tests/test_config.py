from pathlib import Path

import pytest

from fizzydo.config import load_config
from fizzydo.errors import FizzyError


def test_explicit_token_wins(monkeypatch):
    monkeypatch.setenv("FIZZYDO_API_KEY", "from-env")
    cfg = load_config(token="from-flag")
    assert cfg.token == "from-flag"
    assert cfg.token_source == "--token"


def test_env_token(monkeypatch):
    monkeypatch.setenv("FIZZYDO_API_KEY", "from-env")
    cfg = load_config()
    assert cfg.token == "from-env"
    assert cfg.token_source == "env (FIZZYDO_API_KEY)"


def test_dotenv_in_cwd(monkeypatch, tmp_path):
    (tmp_path / ".env").write_text(
        "FIZZYDO_API_KEY=from-cwd-dotenv\n", encoding="utf-8"
    )
    monkeypatch.chdir(tmp_path)
    cfg = load_config()
    assert cfg.token == "from-cwd-dotenv"
    assert ".env" in cfg.token_source


def test_dotenv_in_home_when_no_cwd(monkeypatch, tmp_path):
    home = tmp_path / "home"
    cwd = tmp_path / "cwd"
    home.mkdir()
    cwd.mkdir()
    (home / ".env").write_text("FIZZYDO_API_KEY=from-home\n", encoding="utf-8")
    monkeypatch.chdir(cwd)
    monkeypatch.setenv("HOME", str(home))
    cfg = load_config()
    assert cfg.token == "from-home"


def test_cwd_wins_over_home(monkeypatch, tmp_path):
    home = tmp_path / "home"
    cwd = tmp_path / "cwd"
    home.mkdir()
    cwd.mkdir()
    (home / ".env").write_text("FIZZYDO_API_KEY=home\n", encoding="utf-8")
    (cwd / ".env").write_text("FIZZYDO_API_KEY=cwd\n", encoding="utf-8")
    monkeypatch.chdir(cwd)
    monkeypatch.setenv("HOME", str(home))
    cfg = load_config()
    assert cfg.token == "cwd"


def test_explicit_env_file_path(monkeypatch, tmp_path):
    custom = tmp_path / "custom.env"
    custom.write_text("FIZZYDO_API_KEY=custom\n", encoding="utf-8")
    cfg = load_config(env_file_path=str(custom))
    assert cfg.token == "custom"


def test_explicit_env_file_path_missing(tmp_path):
    with pytest.raises(FizzyError):
        load_config(env_file_path=str(tmp_path / "nope.env"))


def test_missing_token_raises():
    with pytest.raises(FizzyError) as excinfo:
        load_config()
    assert "FIZZYDO_API_KEY" in str(excinfo.value)


def test_account_and_base_url_resolution(monkeypatch):
    monkeypatch.setenv("FIZZYDO_API_KEY", "tok")
    monkeypatch.setenv("FIZZYDO_ACCOUNT", "acct-from-env")
    monkeypatch.setenv("FIZZYDO_BASE_URL", "https://staging.example/")
    cfg = load_config()
    assert cfg.account == "acct-from-env"
    assert cfg.base_url == "https://staging.example"  # trailing slash stripped
