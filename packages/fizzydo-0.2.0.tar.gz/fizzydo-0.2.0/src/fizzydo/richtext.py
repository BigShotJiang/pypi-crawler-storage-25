"""Convert user-supplied text into the HTML the fizzy.do API expects.

Accepts:
  - inline plain text  -> wrapped in <p>...</p> with HTML escaping
  - "@path/to/file.md" -> read file (UTF-8), markdown -> HTML
  - "@path/to/file.html" -> read file, passthrough
  - "-"                -> read stdin (treated as Markdown)
  - None               -> None (caller can omit the field)
"""

from __future__ import annotations

import sys
from html import escape
from pathlib import Path

from markdown_it import MarkdownIt

from fizzydo.errors import FizzyError

_md = MarkdownIt()


def _markdown_to_html(text: str) -> str:
    return _md.render(text)


def _from_file(path: Path) -> str:
    if not path.is_file():
        raise FizzyError(f"File not found: {path}")
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in {".html", ".htm"}:
        return text
    return _markdown_to_html(text)


def to_html(value: str | None, *, allow_stdin: bool = True) -> str | None:
    """Convert ``value`` into HTML suitable for a fizzy rich-text field."""
    if value is None:
        return None

    if value == "-":
        if not allow_stdin:
            raise FizzyError("Stdin input is not supported here.")
        return _markdown_to_html(sys.stdin.read())

    if value.startswith("@"):
        return _from_file(Path(value[1:]).expanduser())

    # Plain inline text: wrap and escape so the API receives valid HTML.
    return f"<p>{escape(value)}</p>"
