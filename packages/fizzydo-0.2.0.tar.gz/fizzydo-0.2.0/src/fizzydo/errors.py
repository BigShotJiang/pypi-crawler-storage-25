"""Domain errors and HTTP-status -> exit-code mapping for the fizzydo CLI."""

from __future__ import annotations

from typing import Any


class FizzyError(Exception):
    """Raised for any error talking to the fizzy.do API or local config issues."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.body = body


# Mapping is intentionally explicit so the CLI's exit codes are stable contract.
_EXIT_CODE_BY_STATUS: dict[int, int] = {
    401: 2,
    403: 3,
    404: 4,
    422: 5,
    429: 6,
}


def exit_code_for(status_code: int | None) -> int:
    if status_code is None:
        return 1
    if status_code in _EXIT_CODE_BY_STATUS:
        return _EXIT_CODE_BY_STATUS[status_code]
    if 500 <= status_code < 600:
        return 7
    return 1
