"""Rich-based rendering for CLI output (table | json | id modes)."""

from __future__ import annotations

import json
from typing import Any, Callable, Iterable

from markdownify import markdownify as _html_to_md
from rich.console import Console
from rich.markdown import Markdown
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

OutputMode = str  # "table" | "json" | "id"

console = Console()
err_console = Console(stderr=True)


def _short(value: Any, length: int = 60) -> str:
    if value is None:
        return ""
    text = str(value)
    if len(text) <= length:
        return text
    return text[: length - 1] + "…"


# ---- table builders ---------------------------------------------------------


def _board_row(b: dict[str, Any]) -> tuple[str, ...]:
    creator = (b.get("creator") or {}).get("name", "")
    return (
        b.get("id", ""),
        b.get("name", ""),
        "yes" if b.get("all_access") else "no",
        str(b.get("auto_postpone_period_in_days") or ""),
        creator,
    )


def _board_table() -> Table:
    t = Table(title="Boards")
    t.add_column("id", style="dim")
    t.add_column("name")
    t.add_column("all access")
    t.add_column("auto-postpone")
    t.add_column("creator")
    return t


def _column_row(c: dict[str, Any]) -> tuple[str, ...]:
    color = c.get("color")
    if isinstance(color, dict):
        color = color.get("name") or color.get("value") or ""
    return (c.get("id", ""), c.get("name", ""), str(color or ""))


def _column_table() -> Table:
    t = Table(title="Columns")
    t.add_column("id", style="dim")
    t.add_column("name")
    t.add_column("color")
    return t


def _card_row(c: dict[str, Any]) -> tuple[str, ...]:
    column = c.get("column")
    column_name = column.get("name") if isinstance(column, dict) else ""
    tags = ", ".join(c.get("tags") or [])
    return (
        str(c.get("number", "")),
        _short(c.get("title"), 60),
        c.get("status", ""),
        column_name or "",
        tags,
        "★" if c.get("golden") else "",
    )


def _card_table() -> Table:
    t = Table(title="Cards")
    t.add_column("#", style="bold")
    t.add_column("title")
    t.add_column("status")
    t.add_column("column")
    t.add_column("tags")
    t.add_column("gold")
    return t


def _comment_row(c: dict[str, Any]) -> tuple[str, ...]:
    body = (c.get("body") or {}).get("plain_text", "")
    creator = (c.get("creator") or {}).get("name", "")
    return (c.get("id", ""), creator, _short(body, 80), c.get("created_at", ""))


def _comment_table() -> Table:
    t = Table(title="Comments")
    t.add_column("id", style="dim")
    t.add_column("creator")
    t.add_column("body")
    t.add_column("created at")
    return t


def _step_row(s: dict[str, Any]) -> tuple[str, ...]:
    return (
        s.get("id", ""),
        "✓" if s.get("completed") else " ",
        _short(s.get("content"), 80),
    )


def _step_table() -> Table:
    t = Table(title="Steps")
    t.add_column("id", style="dim")
    t.add_column("done")
    t.add_column("content")
    return t


def _tag_row(t: dict[str, Any]) -> tuple[str, ...]:
    return (t.get("id", ""), t.get("title", ""))


def _tag_table() -> Table:
    t = Table(title="Tags")
    t.add_column("id", style="dim")
    t.add_column("title")
    return t


def _identity_row(account: dict[str, Any]) -> tuple[str, ...]:
    user = account.get("user") or {}
    return (
        account.get("slug", "").lstrip("/"),
        account.get("name", ""),
        user.get("name", ""),
        user.get("role", ""),
        user.get("email_address", ""),
    )


def _identity_table() -> Table:
    t = Table(title="Identity")
    t.add_column("account slug", style="bold")
    t.add_column("account")
    t.add_column("user")
    t.add_column("role")
    t.add_column("email")
    return t


_KINDS: dict[str, tuple[Callable[[], Table], Callable[[dict[str, Any]], tuple[str, ...]], str]] = {
    "board": (_board_table, _board_row, "id"),
    "column": (_column_table, _column_row, "id"),
    "card": (_card_table, _card_row, "number"),
    "comment": (_comment_table, _comment_row, "id"),
    "step": (_step_table, _step_row, "id"),
    "tag": (_tag_table, _tag_row, "id"),
    "identity": (_identity_table, _identity_row, "slug"),
}


# ---- public API -------------------------------------------------------------


def print_resources(
    items: Iterable[dict[str, Any]],
    *,
    kind: str,
    mode: OutputMode,
) -> None:
    items = list(items)
    if mode == "json":
        console.print_json(json.dumps(items))
        return
    if mode == "id":
        id_field = _KINDS[kind][2]
        for item in items:
            value = item.get(id_field)
            if id_field == "slug" and isinstance(value, str):
                value = value.lstrip("/")
            if value is not None:
                console.print(value)
        return

    table_factory, row_fn, _ = _KINDS[kind]
    table = table_factory()
    if not items:
        console.print(f"[dim]No {kind}s found.[/dim]")
        return
    for item in items:
        table.add_row(*row_fn(item))
    console.print(table)


def print_resource(item: dict[str, Any], *, kind: str, mode: OutputMode) -> None:
    print_resources([item], kind=kind, mode=mode)


# ---- detail view (cards show) -----------------------------------------------


def _html_to_markdown(html: str) -> str:
    """Convert API HTML back to Markdown for terminal rendering.

    Strips the wrapping ``<div class="action-text-content">`` Trix wrapper that
    fizzy.do/Action Text adds, then runs markdownify with sensible options.
    """
    if not html:
        return ""
    return _html_to_md(html, heading_style="ATX", bullets="-").strip()


def _comment_body_markdown(comment: dict[str, Any]) -> str:
    body = comment.get("body") or {}
    if isinstance(body, dict):
        html = body.get("html") or ""
        if html:
            return _html_to_markdown(html)
        return body.get("plain_text") or ""
    return str(body or "")


def print_card_detail(
    card: dict[str, Any],
    comments: list[dict[str, Any]],
    *,
    mode: OutputMode,
) -> None:
    """Render a card with its description, checklist, and comments inline."""
    if mode == "json":
        console.print_json(json.dumps({"card": card, "comments": comments}))
        return
    if mode == "id":
        number = card.get("number")
        if number is not None:
            console.print(number)
        return

    number = card.get("number", "?")
    title = card.get("title", "")
    header = Text()
    header.append(f"#{number} ", style="bold cyan")
    header.append(title, style="bold")
    console.print(header)

    column = card.get("column")
    column_name = column.get("name") if isinstance(column, dict) else None
    meta_parts: list[str] = []
    if column_name:
        meta_parts.append(f"column={column_name}")
    status = card.get("status")
    if status:
        meta_parts.append(f"status={status}")
    if card.get("closed"):
        meta_parts.append("closed")
    if card.get("golden"):
        meta_parts.append("★ golden")
    tags = card.get("tags") or []
    if tags:
        meta_parts.append("tags=" + ", ".join(tags))
    assignees = card.get("assignees") or []
    if assignees:
        names = [
            (a.get("name") if isinstance(a, dict) else str(a)) or ""
            for a in assignees
        ]
        meta_parts.append("assignees=" + ", ".join(n for n in names if n))
    if meta_parts:
        console.print(Text("  ".join(meta_parts), style="dim"))

    description_html = card.get("description_html") or ""
    if description_html:
        console.print(Rule(style="dim"))
        console.print(Markdown(_html_to_markdown(description_html)))

    steps = card.get("steps") or []
    if steps:
        console.print(Rule("Checklist", style="dim"))
        for step in steps:
            mark = "[x]" if step.get("completed") else "[ ]"
            content = step.get("content") or ""
            console.print(Text(f"{mark} {content}"))

    if comments:
        console.print(Rule("Comments", style="dim"))
        for comment in comments:
            creator = (comment.get("creator") or {}).get("name", "")
            created_at = comment.get("created_at", "")
            header = Text()
            header.append(creator or "?", style="bold")
            if created_at:
                header.append(f"  {created_at}", style="dim")
            console.print(header)
            body = _comment_body_markdown(comment)
            if body:
                console.print(Markdown(body))
            console.print()


def print_no_content(message: str, *, mode: OutputMode) -> None:
    if mode == "table":
        console.print(f"[green]✓[/green] {message}")
    # json/id modes stay quiet for 204s.


def print_identity(payload: dict[str, Any], *, mode: OutputMode) -> None:
    accounts = payload.get("accounts") or []
    print_resources(accounts, kind="identity", mode=mode)


def print_error(message: str) -> None:
    err_console.print(f"[red]error:[/red] {message}")
