"""Root Typer app: global options, shared state, error handling."""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from typing import Optional

import typer

from fizzydo import __version__
from fizzydo.client import FizzyClient
from fizzydo.commands import (
    auth as auth_cmd,
    boards as boards_cmd,
    cards as cards_cmd,
    columns as columns_cmd,
    comments as comments_cmd,
    pins as pins_cmd,
    steps as steps_cmd,
    tags as tags_cmd,
)
from fizzydo.config import Config, load_config
from fizzydo.errors import FizzyError, exit_code_for
from fizzydo.output import print_error


@dataclass
class State:
    """Shared state hung off ``ctx.obj``.

    Config and client are built lazily so ``--help`` and similar bookkeeping
    commands don't require a configured token.
    """

    token: Optional[str] = None
    account: Optional[str] = None
    base_url: Optional[str] = None
    env_file_path: Optional[str] = None
    json: bool = False
    ids_only: bool = False
    debug: bool = False
    _config: Optional[Config] = field(default=None, repr=False)
    _client: Optional[FizzyClient] = field(default=None, repr=False)

    @property
    def mode(self) -> str:
        if self.json:
            return "json"
        if self.ids_only:
            return "id"
        return "table"

    def config(self) -> Config:
        if self._config is None:
            self._config = load_config(
                token=self.token,
                account=self.account,
                base_url=self.base_url,
                env_file_path=self.env_file_path,
            )
        return self._config

    def client(self) -> FizzyClient:
        if self._client is None:
            cfg = self.config()
            self._client = FizzyClient(
                token=cfg.token,
                base_url=cfg.base_url,
                account=cfg.account,
            )
        return self._client


app = typer.Typer(
    name="fizzydo",
    help="Command-line client for the fizzy.do kanban API.",
    no_args_is_help=True,
    add_completion=False,
    pretty_exceptions_enable=False,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"fizzydo {__version__}")
        raise typer.Exit()


@app.callback()
def _root(
    ctx: typer.Context,
    token: Optional[str] = typer.Option(
        None, "--token", envvar=None, help="API token (overrides env / .env)."
    ),
    account: Optional[str] = typer.Option(
        None, "--account", help="Account slug (overrides env / .env)."
    ),
    base_url: Optional[str] = typer.Option(
        None, "--base-url", help="Override the API base URL."
    ),
    env_file_path: Optional[str] = typer.Option(
        None,
        "--env-file-path",
        help="Path to a .env file. Defaults to ./.env then $HOME/.env.",
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Emit raw JSON instead of tables."
    ),
    ids_only: bool = typer.Option(
        False, "--id", help="Emit only IDs (or numbers for cards), one per line."
    ),
    debug: bool = typer.Option(
        False, "--debug", help="Re-raise exceptions instead of pretty-printing."
    ),
    version: bool = typer.Option(
        False, "--version", callback=_version_callback, is_eager=True
    ),
) -> None:
    state = State(
        token=token,
        account=account,
        base_url=base_url,
        env_file_path=env_file_path,
        json=json_output,
        ids_only=ids_only,
        debug=debug,
    )
    if json_output and ids_only:
        raise typer.BadParameter("--json and --id cannot be combined.")
    ctx.obj = state


# Sub-apps wired here so each command module stays self-contained.
app.add_typer(auth_cmd.app, name="auth", help="Authentication and identity.")
app.add_typer(boards_cmd.app, name="boards", help="Boards.")
app.add_typer(columns_cmd.app, name="columns", help="Columns on a board.")
app.add_typer(cards_cmd.app, name="cards", help="Cards (tasks).")
app.add_typer(comments_cmd.app, name="comments", help="Comments on a card.")
app.add_typer(steps_cmd.app, name="steps", help="Checklist steps on a card.")
app.add_typer(tags_cmd.app, name="tags", help="Tags.")
app.add_typer(pins_cmd.app, name="pins", help="Pinned cards.")


def main() -> None:
    """Console script entry point. Catches FizzyError and exits cleanly."""
    try:
        app(standalone_mode=False)
    except FizzyError as exc:
        print_error(exc.message)
        sys.exit(exit_code_for(exc.status_code))
    except typer.Exit as exc:
        sys.exit(exc.exit_code)
    except typer.Abort:
        sys.exit(1)
    except click_exceptions() as exc:  # type: ignore[misc]
        # Typer/Click usage errors: print and exit non-zero with their own code.
        exc.show()
        sys.exit(exc.exit_code if hasattr(exc, "exit_code") else 2)


def click_exceptions():  # pragma: no cover - tiny helper
    import click

    return (click.ClickException,)
