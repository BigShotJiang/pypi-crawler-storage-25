"""Thin httpx wrapper around the fizzy.do REST API."""

from __future__ import annotations

from typing import Any, Iterator

import httpx

from fizzydo import __version__
from fizzydo.errors import FizzyError


class FizzyClient:
    """Synchronous HTTP client for fizzy.do.

    Owns a single ``httpx.Client``. Subcommands construct their JSON request
    envelopes (e.g. ``{"card": {...}}``) themselves; this class stays generic.
    """

    def __init__(
        self,
        *,
        token: str,
        base_url: str,
        account: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self._account = account
        self._http = httpx.Client(
            base_url=base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
                "User-Agent": f"fizzydo/{__version__}",
            },
            follow_redirects=False,
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "FizzyClient":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    @property
    def account(self) -> str:
        if not self._account:
            self._account = self._resolve_account_from_identity()
        return self._account

    def set_account(self, account: str) -> None:
        self._account = account

    def _resolve_account_from_identity(self) -> str:
        """Auto-pick the account slug when only one is available."""
        payload = self.request("GET", "/my/identity").json()
        accounts = payload.get("accounts") or []
        slugs = [a.get("slug", "").lstrip("/") for a in accounts if a.get("slug")]
        if len(slugs) == 1:
            return slugs[0]
        if not slugs:
            raise FizzyError("Token has no accounts; nothing to operate on.")
        raise FizzyError(
            "Multiple accounts available "
            f"({', '.join(slugs)}). Set FIZZYDO_ACCOUNT or pass --account."
        )

    def account_path(self, suffix: str) -> str:
        if not suffix.startswith("/"):
            suffix = "/" + suffix
        return f"/{self.account}{suffix}"

    # ---- low-level helpers ----------------------------------------------------

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | list[tuple[str, Any]] | None = None,
        json: Any = None,
    ) -> httpx.Response:
        try:
            response = self._http.request(method, path, params=params, json=json)
        except httpx.HTTPError as exc:
            raise FizzyError(f"Network error talking to {path}: {exc}") from exc

        if response.status_code >= 400:
            raise self._error_from_response(response)
        return response

    def get(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("POST", path, **kwargs)

    def put(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("PUT", path, **kwargs)

    def patch(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("PATCH", path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        return self.request("DELETE", path, **kwargs)

    # ---- pagination -----------------------------------------------------------

    def paginate(
        self,
        path: str,
        *,
        params: dict[str, Any] | list[tuple[str, Any]] | None = None,
        all_pages: bool = False,
        limit: int | None = None,
    ) -> Iterator[Any]:
        """Yield items from a paginated list endpoint.

        - ``all_pages=False`` (default): only the first page.
        - ``all_pages=True``: follow ``Link: rel="next"`` until exhausted.
        - ``limit``: stop after yielding this many items regardless.
        """
        next_url: str | None = path
        next_params = params
        yielded = 0
        while next_url is not None:
            response = self.request("GET", next_url, params=next_params)
            page = response.json()
            for item in page:
                yield item
                yielded += 1
                if limit is not None and yielded >= limit:
                    return
            if not all_pages:
                return
            link = response.links.get("next")
            next_url = link["url"] if link else None
            next_params = None  # subsequent URLs already encode their params

    # ---- 201 Created helpers --------------------------------------------------

    def created_resource(self, response: httpx.Response) -> Any:
        """Re-fetch a freshly-created resource via its ``Location`` header.

        Many fizzy POST endpoints return ``201 Created`` with a ``Location``
        header but no body. This helper follows the location so callers can
        display the new object without each command duplicating the GET.
        """
        if response.content:
            try:
                return response.json()
            except ValueError:
                pass

        location = response.headers.get("Location")
        if not location:
            return None
        return self.get(location).json()

    # ---- error mapping --------------------------------------------------------

    @staticmethod
    def _error_from_response(response: httpx.Response) -> FizzyError:
        body: Any = None
        if response.content:
            try:
                body = response.json()
            except ValueError:
                body = response.text

        message = f"{response.status_code} {response.reason_phrase} from {response.request.url}"
        if isinstance(body, dict):
            details = ", ".join(
                f"{field}: {'; '.join(msgs) if isinstance(msgs, list) else msgs}"
                for field, msgs in body.items()
            )
            if details:
                message = f"{message} — {details}"
        elif isinstance(body, str) and body.strip():
            message = f"{message} — {body.strip()}"

        return FizzyError(message, status_code=response.status_code, body=body)
