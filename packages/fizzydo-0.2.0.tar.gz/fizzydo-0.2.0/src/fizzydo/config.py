"""Resolve runtime config (token, account, base URL) from flags / env / .env."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import dotenv_values

from fizzydo.errors import FizzyError

DEFAULT_BASE_URL = "https://app.fizzy.do"

ENV_TOKEN = "FIZZYDO_API_KEY"
ENV_ACCOUNT = "FIZZYDO_ACCOUNT"
ENV_BASE_URL = "FIZZYDO_BASE_URL"


@dataclass
class Config:
    token: str
    base_url: str
    account: str | None
    # Where the token came from, for `auth status` reporting.
    token_source: str
    account_source: str | None


def _load_dotenv_values(env_file_path: str | None) -> dict[str, str]:
    """Load values from a .env file. CWD then $HOME, unless overridden.

    Returns an empty dict if no file is found. Raises FizzyError if an explicit
    --env-file-path was given but the file doesn't exist.
    """
    if env_file_path is not None:
        path = Path(env_file_path).expanduser()
        if not path.is_file():
            raise FizzyError(f"--env-file-path not found: {path}")
        return {k: v for k, v in dotenv_values(path).items() if v is not None}

    for candidate in (Path.cwd() / ".env", Path.home() / ".env"):
        if candidate.is_file():
            return {k: v for k, v in dotenv_values(candidate).items() if v is not None}

    return {}


def load_config(
    *,
    token: str | None = None,
    account: str | None = None,
    base_url: str | None = None,
    env_file_path: str | None = None,
) -> Config:
    """Build a Config from CLI flags, environment, and a .env fallback.

    Precedence (first hit wins):
      1. Explicit kwargs (CLI flags).
      2. Process environment.
      3. .env file (CWD, then $HOME, or the path given by env_file_path).
    """
    dotenv = _load_dotenv_values(env_file_path)

    resolved_token = token
    token_source = "--token"
    if resolved_token is None:
        env_value = os.environ.get(ENV_TOKEN)
        if env_value:
            resolved_token = env_value
            token_source = f"env ({ENV_TOKEN})"
        elif dotenv.get(ENV_TOKEN):
            resolved_token = dotenv[ENV_TOKEN]
            token_source = f".env ({ENV_TOKEN})"

    if not resolved_token:
        raise FizzyError(
            f"No API token configured. Set {ENV_TOKEN} in the environment, "
            "add it to a .env file in the current directory or $HOME, or pass --token."
        )

    resolved_account = account
    account_source: str | None = "--account" if account else None
    if resolved_account is None:
        env_account = os.environ.get(ENV_ACCOUNT)
        if env_account:
            resolved_account = env_account
            account_source = f"env ({ENV_ACCOUNT})"
        elif dotenv.get(ENV_ACCOUNT):
            resolved_account = dotenv[ENV_ACCOUNT]
            account_source = f".env ({ENV_ACCOUNT})"

    resolved_base_url = (
        base_url
        or os.environ.get(ENV_BASE_URL)
        or dotenv.get(ENV_BASE_URL)
        or DEFAULT_BASE_URL
    ).rstrip("/")

    return Config(
        token=resolved_token,
        base_url=resolved_base_url,
        account=resolved_account,
        token_source=token_source,
        account_source=account_source,
    )
