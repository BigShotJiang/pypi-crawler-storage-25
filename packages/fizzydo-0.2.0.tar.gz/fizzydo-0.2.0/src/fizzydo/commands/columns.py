"""`fizzydo columns` — board columns CRUD."""

from __future__ import annotations

from typing import Optional

import typer

from fizzydo.errors import FizzyError
from fizzydo.output import print_no_content, print_resource, print_resources

app = typer.Typer(help="Columns on a board.", no_args_is_help=True)


# The API takes a CSS variable for color; the user provides a name.
COLOR_BY_NAME: dict[str, str] = {
    "blue": "var(--color-card-default)",
    "gray": "var(--color-card-1)",
    "tan": "var(--color-card-2)",
    "yellow": "var(--color-card-3)",
    "lime": "var(--color-card-4)",
    "aqua": "var(--color-card-5)",
    "violet": "var(--color-card-6)",
    "purple": "var(--color-card-7)",
    "pink": "var(--color-card-8)",
}


def _resolve_color(color: Optional[str]) -> Optional[str]:
    if color is None:
        return None
    key = color.strip().lower()
    if key.startswith("var("):
        return color
    if key not in COLOR_BY_NAME:
        valid = ", ".join(sorted(COLOR_BY_NAME))
        raise FizzyError(f"Unknown column color {color!r}. Valid: {valid}.")
    return COLOR_BY_NAME[key]


@app.command("list")
def list_columns(
    ctx: typer.Context,
    board: str = typer.Option(..., "--board", help="Board ID."),
) -> None:
    """List columns on a board."""
    state = ctx.obj
    client = state.client()
    items = client.get(client.account_path(f"/boards/{board}/columns")).json()
    print_resources(items, kind="column", mode=state.mode)


@app.command()
def show(
    ctx: typer.Context,
    column_id: str,
    board: str = typer.Option(..., "--board", help="Board ID."),
) -> None:
    """Show a single column."""
    state = ctx.obj
    client = state.client()
    item = client.get(
        client.account_path(f"/boards/{board}/columns/{column_id}")
    ).json()
    print_resource(item, kind="column", mode=state.mode)


@app.command()
def create(
    ctx: typer.Context,
    board: str = typer.Option(..., "--board", help="Board ID."),
    name: str = typer.Option(..., "--name", help="Column name."),
    color: Optional[str] = typer.Option(
        None,
        "--color",
        help=f"One of: {', '.join(sorted(COLOR_BY_NAME))}.",
    ),
) -> None:
    """Create a new column on a board."""
    state = ctx.obj
    client = state.client()
    payload: dict[str, object] = {"name": name}
    css = _resolve_color(color)
    if css is not None:
        payload["color"] = css

    response = client.post(
        client.account_path(f"/boards/{board}/columns"),
        json={"column": payload},
    )
    item = client.created_resource(response)
    if item:
        print_resource(item, kind="column", mode=state.mode)
    else:
        print_no_content("Column created.", mode=state.mode)


@app.command()
def update(
    ctx: typer.Context,
    column_id: str,
    board: str = typer.Option(..., "--board", help="Board ID."),
    name: Optional[str] = typer.Option(None, "--name"),
    color: Optional[str] = typer.Option(None, "--color"),
) -> None:
    """Update a column."""
    state = ctx.obj
    client = state.client()
    payload: dict[str, object] = {}
    if name is not None:
        payload["name"] = name
    css = _resolve_color(color)
    if css is not None:
        payload["color"] = css
    if not payload:
        raise typer.BadParameter("Provide --name or --color.")
    client.put(
        client.account_path(f"/boards/{board}/columns/{column_id}"),
        json={"column": payload},
    )
    print_no_content("Column updated.", mode=state.mode)


@app.command()
def delete(
    ctx: typer.Context,
    column_id: str,
    board: str = typer.Option(..., "--board", help="Board ID."),
) -> None:
    """Delete a column."""
    state = ctx.obj
    client = state.client()
    client.delete(client.account_path(f"/boards/{board}/columns/{column_id}"))
    print_no_content("Column deleted.", mode=state.mode)
