"""`fizzydo comments` — comments on cards."""

from __future__ import annotations

from typing import Optional

import typer

from fizzydo.errors import FizzyError
from fizzydo.output import print_no_content, print_resource, print_resources
from fizzydo.richtext import to_html

app = typer.Typer(help="Comments on a card.", no_args_is_help=True)


def _resolve_body(
    body: Optional[str],
    file: Optional[str],
    use_editor: bool,
) -> str:
    """Pick the user's preferred input source and convert it to HTML."""
    sources = [s for s in (body, file, use_editor or None) if s]
    if len(sources) > 1:
        raise FizzyError("Provide only one of: body argument, --file, --editor.")

    if file is not None:
        html = to_html(f"@{file}", allow_stdin=False)
    elif use_editor:
        edited = typer.edit("", extension=".md")
        if edited is None or not edited.strip():
            raise FizzyError("Editor closed without input; comment not created.")
        html = to_html(edited, allow_stdin=False)
    elif body is not None:
        html = to_html(body)
    else:
        raise FizzyError("No comment body provided.")

    if html is None:
        raise FizzyError("Comment body resolved to empty HTML.")
    return html


@app.command("list")
def list_comments(ctx: typer.Context, number: int) -> None:
    """List comments on a card."""
    state = ctx.obj
    client = state.client()
    items = client.get(client.account_path(f"/cards/{number}/comments")).json()
    print_resources(items, kind="comment", mode=state.mode)


@app.command()
def show(ctx: typer.Context, number: int, comment_id: str) -> None:
    """Show a single comment."""
    state = ctx.obj
    client = state.client()
    item = client.get(
        client.account_path(f"/cards/{number}/comments/{comment_id}")
    ).json()
    print_resource(item, kind="comment", mode=state.mode)


@app.command()
def add(
    ctx: typer.Context,
    number: int,
    body: Optional[str] = typer.Argument(
        None, help="Inline body, @file.md/@file.html, or '-' for stdin."
    ),
    file: Optional[str] = typer.Option(None, "--file", help="Read body from a file."),
    editor: bool = typer.Option(False, "--editor", help="Compose body in $EDITOR."),
) -> None:
    """Add a comment to a card."""
    state = ctx.obj
    client = state.client()
    html = _resolve_body(body, file, editor)
    response = client.post(
        client.account_path(f"/cards/{number}/comments"),
        json={"comment": {"body": html}},
    )
    item = client.created_resource(response)
    if item:
        print_resource(item, kind="comment", mode=state.mode)
    else:
        print_no_content("Comment added.", mode=state.mode)


@app.command()
def update(
    ctx: typer.Context,
    number: int,
    comment_id: str,
    body: Optional[str] = typer.Argument(None),
    file: Optional[str] = typer.Option(None, "--file"),
    editor: bool = typer.Option(False, "--editor"),
) -> None:
    """Update a comment you authored."""
    state = ctx.obj
    client = state.client()
    html = _resolve_body(body, file, editor)
    response = client.put(
        client.account_path(f"/cards/{number}/comments/{comment_id}"),
        json={"comment": {"body": html}},
    )
    item = response.json() if response.content else None
    if item:
        print_resource(item, kind="comment", mode=state.mode)
    else:
        print_no_content("Comment updated.", mode=state.mode)


@app.command()
def delete(ctx: typer.Context, number: int, comment_id: str) -> None:
    """Delete a comment you authored."""
    state = ctx.obj
    client = state.client()
    client.delete(client.account_path(f"/cards/{number}/comments/{comment_id}"))
    print_no_content("Comment deleted.", mode=state.mode)
