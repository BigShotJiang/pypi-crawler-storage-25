"""`fizzydo auth` — identity and configuration sanity checks."""

from __future__ import annotations

import typer

from fizzydo.output import console, print_identity

app = typer.Typer(help="Authentication and identity.", no_args_is_help=True)


@app.command()
def whoami(ctx: typer.Context) -> None:
    """Show the accounts the current token can access."""
    state = ctx.obj
    payload = state.client().get("/my/identity").json()
    print_identity(payload, mode=state.mode)


@app.command()
def status(ctx: typer.Context) -> None:
    """Verify the configured token and report what fizzydo will use."""
    state = ctx.obj
    cfg = state.config()
    client = state.client()
    payload = client.get("/my/identity").json()
    accounts = payload.get("accounts") or []

    if state.mode == "json":
        import json as _json

        console.print_json(
            _json.dumps(
                {
                    "base_url": cfg.base_url,
                    "token_source": cfg.token_source,
                    "account": cfg.account,
                    "account_source": cfg.account_source,
                    "accounts_available": [
                        a.get("slug", "").lstrip("/") for a in accounts
                    ],
                }
            )
        )
        return

    console.print(f"[bold]base url[/bold]      {cfg.base_url}")
    console.print(f"[bold]token source[/bold]  {cfg.token_source}")
    console.print(
        f"[bold]account[/bold]       {cfg.account or '(unset)'}"
        + (f"  [dim]from {cfg.account_source}[/dim]" if cfg.account_source else "")
    )
    console.print()
    print_identity(payload, mode="table")
