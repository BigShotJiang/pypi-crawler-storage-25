"""`fizzydo cards` — card lifecycle (the workhorse subcommand)."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import typer

from fizzydo.errors import FizzyError
from fizzydo.output import (
    err_console,
    print_card_detail,
    print_no_content,
    print_resource,
    print_resources,
)
from fizzydo.richtext import to_html

app = typer.Typer(help="Cards (tasks).", no_args_is_help=True)


VALID_STATUS = {
    "all",
    "closed",
    "not_now",
    "stalled",
    "postponing_soon",
    "golden",
}
VALID_SORT = {"latest", "newest", "oldest"}
VALID_DATE_RANGE = {
    "today",
    "yesterday",
    "thisweek",
    "lastweek",
    "thismonth",
    "lastmonth",
    "thisyear",
    "lastyear",
}


def _normalize_status(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    key = value.replace("-", "_").lower()
    if key not in VALID_STATUS:
        raise typer.BadParameter(
            f"--status must be one of: {', '.join(sorted(VALID_STATUS))}"
        )
    return key


def _current_user_id(state) -> str:
    """Look up the user ID for the configured account from /my/identity."""
    client = state.client()
    payload = client.get("/my/identity").json()
    target_slug = client.account.lstrip("/")
    for account in payload.get("accounts") or []:
        if account.get("slug", "").lstrip("/") == target_slug:
            user = account.get("user") or {}
            user_id = user.get("id")
            if user_id:
                return user_id
    raise FizzyError(
        f"Could not resolve current user for account {target_slug!r}."
    )


@app.command("list")
def list_cards(
    ctx: typer.Context,
    board: list[str] = typer.Option([], "--board", help="Filter by board ID."),
    tag: list[str] = typer.Option([], "--tag", help="Filter by tag ID."),
    assignee: list[str] = typer.Option(
        [], "--assignee", help="Filter by assignee user ID."
    ),
    creator: list[str] = typer.Option(
        [], "--creator", help="Filter by card creator ID."
    ),
    closer: list[str] = typer.Option([], "--closer", help="Filter by closer user ID."),
    mine: bool = typer.Option(
        False, "--mine", help="Only cards assigned to me."
    ),
    status: Optional[str] = typer.Option(
        None,
        "--status",
        help=(
            "all (open + closed merged)|closed|not-now|stalled|"
            "postponing-soon|golden"
        ),
    ),
    sort: Optional[str] = typer.Option(
        None, "--sort", help="latest|newest|oldest (default: latest)"
    ),
    unassigned: bool = typer.Option(False, "--unassigned"),
    created_when: Optional[str] = typer.Option(
        None, "--created", help="today|yesterday|thisweek|lastweek|thismonth|..."
    ),
    closed_when: Optional[str] = typer.Option(
        None, "--closed-on", help="today|yesterday|thisweek|..."
    ),
    search: list[str] = typer.Option([], "--search", help="Search term."),
    all_pages: bool = typer.Option(False, "--all", help="Fetch every page."),
    limit: Optional[int] = typer.Option(None, "--limit", help="Cap total items."),
) -> None:
    """List cards with optional filters."""
    state = ctx.obj
    base_params: list[tuple[str, str]] = []
    for value in board:
        base_params.append(("board_ids[]", value))
    for value in tag:
        base_params.append(("tag_ids[]", value))
    for value in assignee:
        base_params.append(("assignee_ids[]", value))
    for value in creator:
        base_params.append(("creator_ids[]", value))
    for value in closer:
        base_params.append(("closer_ids[]", value))
    for value in search:
        base_params.append(("terms[]", value))

    if mine:
        base_params.append(("assignee_ids[]", _current_user_id(state)))
    if unassigned:
        base_params.append(("assignment_status", "unassigned"))

    if sort is not None:
        if sort not in VALID_SORT:
            raise typer.BadParameter(
                f"--sort must be one of: {', '.join(sorted(VALID_SORT))}"
            )
        base_params.append(("sorted_by", sort))

    if created_when is not None:
        if created_when not in VALID_DATE_RANGE:
            raise typer.BadParameter(
                f"--created must be one of: {', '.join(sorted(VALID_DATE_RANGE))}"
            )
        base_params.append(("creation", created_when))
    if closed_when is not None:
        if closed_when not in VALID_DATE_RANGE:
            raise typer.BadParameter(
                f"--closed-on must be one of: {', '.join(sorted(VALID_DATE_RANGE))}"
            )
        base_params.append(("closure", closed_when))

    normalized_status = _normalize_status(status)
    client = state.client()

    if normalized_status == "all":
        # The fizzy.do API has no single param for "open + closed"; merge two
        # calls. Pull the open feed and the closed feed separately, dedupe by
        # id, and re-sort by last_active_at descending.
        open_items = list(
            client.paginate(
                client.account_path("/cards"),
                params=base_params,
                all_pages=all_pages,
                limit=limit,
            )
        )
        closed_params = base_params + [("indexed_by", "closed")]
        closed_items = list(
            client.paginate(
                client.account_path("/cards"),
                params=closed_params,
                all_pages=all_pages,
                limit=limit,
            )
        )
        seen: set[str] = set()
        merged: list[dict] = []
        for item in open_items + closed_items:
            ident = item.get("id") or str(item.get("number"))
            if ident in seen:
                continue
            seen.add(ident)
            merged.append(item)
        merged.sort(key=lambda c: c.get("last_active_at") or "", reverse=True)
        if limit is not None:
            merged = merged[:limit]
        print_resources(merged, kind="card", mode=state.mode)
        return

    params = list(base_params)
    if normalized_status is not None:
        params.append(("indexed_by", normalized_status))

    items = list(
        client.paginate(
            client.account_path("/cards"),
            params=params,
            all_pages=all_pages,
            limit=limit,
        )
    )
    print_resources(items, kind="card", mode=state.mode)


@app.command()
def show(ctx: typer.Context, number: int) -> None:
    """Show a card by its number, including description, checklist, and comments."""
    state = ctx.obj
    client = state.client()
    card = client.get(client.account_path(f"/cards/{number}")).json()
    try:
        comments = client.get(
            client.account_path(f"/cards/{number}/comments")
        ).json()
        if not isinstance(comments, list):
            comments = []
    except FizzyError:
        comments = []
    print_card_detail(card, comments, mode=state.mode)


@app.command()
def create(
    ctx: typer.Context,
    board: str = typer.Option(..., "--board", help="Board ID."),
    title: str = typer.Option(..., "--title"),
    description: Optional[str] = typer.Option(
        None, "--description", help="Inline text, @file.md, @file.html, or '-' for stdin."
    ),
    tag: list[str] = typer.Option([], "--tag", help="Tag ID (repeat for multiple)."),
    draft: bool = typer.Option(False, "--draft", help="Create as a draft."),
    column: Optional[str] = typer.Option(
        None,
        "--column",
        help="If set, triage the new card into this column ID immediately.",
    ),
) -> None:
    """Create a new card."""
    state = ctx.obj
    client = state.client()
    payload: dict[str, object] = {"title": title}
    desc_html = to_html(description)
    if desc_html is not None:
        payload["description"] = desc_html
    if tag:
        payload["tag_ids"] = tag
    if draft:
        payload["status"] = "drafted"

    response = client.post(
        client.account_path(f"/boards/{board}/cards"),
        json={"card": payload},
    )
    item = client.created_resource(response)
    if column and item:
        number = item.get("number")
        if number is not None:
            client.post(
                client.account_path(f"/cards/{number}/triage"),
                json={"column_id": column},
            )
            item = client.get(client.account_path(f"/cards/{number}")).json()

    if item:
        print_resource(item, kind="card", mode=state.mode)
    else:
        print_no_content("Card created.", mode=state.mode)


def _split_h1_title(text: str, fallback: str) -> tuple[str, str]:
    """Pull an H1 off the top of a markdown file as the title.

    Returns ``(title, body)``. If no leading H1 is found, returns the fallback
    title and the original text untouched.
    """
    lines = text.splitlines()
    leading_blanks = 0
    for line in lines:
        if line.strip() == "":
            leading_blanks += 1
            continue
        if line.lstrip().startswith("# ") and not line.lstrip().startswith("## "):
            title = line.lstrip()[2:].strip()
            body = "\n".join(lines[leading_blanks + 1 :]).lstrip("\n")
            return title, body
        return fallback, text
    return fallback, text


def _humanize_filename(stem: str) -> str:
    return stem.replace("-", " ").replace("_", " ").strip().title()


@app.command("bulk-create")
def bulk_create(
    ctx: typer.Context,
    board: str = typer.Option(..., "--board", help="Board ID."),
    from_dir: Path = typer.Option(
        ...,
        "--from-dir",
        help="Directory containing markdown files to import as cards.",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    column: Optional[str] = typer.Option(
        None,
        "--column",
        help="Triage every created card into this column ID.",
    ),
    tag: list[str] = typer.Option(
        [], "--tag", help="Tag ID to apply to every card (repeatable)."
    ),
    draft: bool = typer.Option(False, "--draft", help="Create cards as drafts."),
    pattern: str = typer.Option(
        "*.md", "--pattern", help="Glob pattern for files in --from-dir."
    ),
    recursive: bool = typer.Option(
        False, "--recursive", help="Recurse into subdirectories of --from-dir."
    ),
) -> None:
    """Bulk-create cards from a directory of markdown files.

    Each file becomes one card. The title is taken from the first H1 line
    (``# Title``); if none is present, the filename stem is humanized into a
    title and the entire file becomes the description.
    """
    state = ctx.obj
    client = state.client()

    files = sorted((from_dir.rglob if recursive else from_dir.glob)(pattern))
    files = [f for f in files if f.is_file()]
    if not files:
        raise FizzyError(f"No files matched {pattern!r} under {from_dir}.")

    created: list[dict] = []
    failures: list[tuple[Path, str]] = []
    for path in files:
        try:
            text = path.read_text(encoding="utf-8")
        except OSError as exc:
            failures.append((path, f"read error: {exc}"))
            continue
        if not text.strip():
            err_console.print(f"[yellow]warning:[/yellow] skipping empty file {path}")
            continue

        title, body = _split_h1_title(text, fallback=_humanize_filename(path.stem))
        payload: dict[str, object] = {"title": title}
        desc_html = to_html(body, allow_stdin=False) if body.strip() else None
        if desc_html is not None:
            payload["description"] = desc_html
        if tag:
            payload["tag_ids"] = tag
        if draft:
            payload["status"] = "drafted"

        try:
            response = client.post(
                client.account_path(f"/boards/{board}/cards"),
                json={"card": payload},
            )
            item = client.created_resource(response)
            if column and item:
                number = item.get("number")
                if number is not None:
                    client.post(
                        client.account_path(f"/cards/{number}/triage"),
                        json={"column_id": column},
                    )
                    item = client.get(
                        client.account_path(f"/cards/{number}")
                    ).json()
            if item:
                created.append(item)
        except FizzyError as exc:
            failures.append((path, str(exc)))

    print_resources(created, kind="card", mode=state.mode)

    if failures:
        for path, msg in failures:
            err_console.print(f"[red]error:[/red] {path}: {msg}")
        raise typer.Exit(code=1)


@app.command()
def update(
    ctx: typer.Context,
    number: int,
    title: Optional[str] = typer.Option(None, "--title"),
    description: Optional[str] = typer.Option(None, "--description"),
    tag: list[str] = typer.Option([], "--tag", help="Tag IDs to set."),
    draft: Optional[bool] = typer.Option(
        None, "--draft/--published", help="Toggle draft state."
    ),
) -> None:
    """Update a card's metadata."""
    state = ctx.obj
    client = state.client()
    payload: dict[str, object] = {}
    if title is not None:
        payload["title"] = title
    desc_html = to_html(description)
    if desc_html is not None:
        payload["description"] = desc_html
    if tag:
        payload["tag_ids"] = tag
    if draft is not None:
        payload["status"] = "drafted" if draft else "published"
    if not payload:
        raise typer.BadParameter("Provide at least one field to update.")
    client.put(client.account_path(f"/cards/{number}"), json={"card": payload})
    print_no_content("Card updated.", mode=state.mode)


@app.command()
def delete(ctx: typer.Context, number: int) -> None:
    """Delete a card."""
    state = ctx.obj
    client = state.client()
    client.delete(client.account_path(f"/cards/{number}"))
    print_no_content("Card deleted.", mode=state.mode)


@app.command()
def close(ctx: typer.Context, number: int) -> None:
    """Close a card (mark as Done)."""
    state = ctx.obj
    client = state.client()
    client.post(client.account_path(f"/cards/{number}/closure"))
    print_no_content(f"Card #{number} closed.", mode=state.mode)


@app.command()
def reopen(ctx: typer.Context, number: int) -> None:
    """Reopen a closed card."""
    state = ctx.obj
    client = state.client()
    client.delete(client.account_path(f"/cards/{number}/closure"))
    print_no_content(f"Card #{number} reopened.", mode=state.mode)


@app.command("not-now")
def not_now(ctx: typer.Context, number: int) -> None:
    """Move a card to Not Now."""
    state = ctx.obj
    client = state.client()
    client.post(client.account_path(f"/cards/{number}/not_now"))
    print_no_content(f"Card #{number} moved to Not Now.", mode=state.mode)


@app.command()
def triage(
    ctx: typer.Context,
    number: int,
    column: str = typer.Option(..., "--column", help="Target column ID."),
) -> None:
    """Move a card into a column."""
    state = ctx.obj
    client = state.client()
    client.post(
        client.account_path(f"/cards/{number}/triage"),
        json={"column_id": column},
    )
    print_no_content(f"Card #{number} triaged.", mode=state.mode)


@app.command()
def untriage(ctx: typer.Context, number: int) -> None:
    """Send a card back to triage."""
    state = ctx.obj
    client = state.client()
    client.delete(client.account_path(f"/cards/{number}/triage"))
    print_no_content(f"Card #{number} sent back to triage.", mode=state.mode)


@app.command()
def tag(ctx: typer.Context, number: int, name: str) -> None:
    """Toggle a tag on a card. Creates the tag if it doesn't exist."""
    state = ctx.obj
    client = state.client()
    client.post(
        client.account_path(f"/cards/{number}/taggings"),
        json={"tag_title": name.lstrip("#")},
    )
    print_no_content(f"Toggled #{name.lstrip('#')} on card #{number}.", mode=state.mode)


@app.command()
def assign(ctx: typer.Context, number: int, user_id: str) -> None:
    """Toggle assignment of a user on a card."""
    state = ctx.obj
    client = state.client()
    client.post(
        client.account_path(f"/cards/{number}/assignments"),
        json={"assignee_id": user_id},
    )
    print_no_content(
        f"Toggled assignment of {user_id} on card #{number}.", mode=state.mode
    )


@app.command()
def golden(ctx: typer.Context, number: int) -> None:
    """Mark a card as golden."""
    state = ctx.obj
    client = state.client()
    client.post(client.account_path(f"/cards/{number}/goldness"))
    print_no_content(f"Card #{number} marked golden.", mode=state.mode)


@app.command()
def ungolden(ctx: typer.Context, number: int) -> None:
    """Remove golden status from a card."""
    state = ctx.obj
    client = state.client()
    client.delete(client.account_path(f"/cards/{number}/goldness"))
    print_no_content(f"Card #{number} unmarked golden.", mode=state.mode)


@app.command()
def watch(ctx: typer.Context, number: int) -> None:
    """Subscribe the current user to notifications for a card."""
    state = ctx.obj
    client = state.client()
    client.post(client.account_path(f"/cards/{number}/watch"))
    print_no_content(f"Watching card #{number}.", mode=state.mode)


@app.command()
def unwatch(ctx: typer.Context, number: int) -> None:
    """Unsubscribe the current user from notifications for a card."""
    state = ctx.obj
    client = state.client()
    client.delete(client.account_path(f"/cards/{number}/watch"))
    print_no_content(f"Unwatched card #{number}.", mode=state.mode)
