"""`fizzydo pins` — pinned cards."""

from __future__ import annotations

import typer

from fizzydo.output import print_no_content, print_resources

app = typer.Typer(help="Pinned cards.", no_args_is_help=True)


@app.command("list")
def list_pins(ctx: typer.Context) -> None:
    """List the current user's pinned cards."""
    state = ctx.obj
    client = state.client()
    items = client.get("/my/pins").json()
    print_resources(items, kind="card", mode=state.mode)


@app.command()
def add(ctx: typer.Context, number: int) -> None:
    """Pin a card for the current user."""
    state = ctx.obj
    client = state.client()
    client.post(client.account_path(f"/cards/{number}/pin"))
    print_no_content(f"Pinned card #{number}.", mode=state.mode)


@app.command()
def remove(ctx: typer.Context, number: int) -> None:
    """Unpin a card for the current user."""
    state = ctx.obj
    client = state.client()
    client.delete(client.account_path(f"/cards/{number}/pin"))
    print_no_content(f"Unpinned card #{number}.", mode=state.mode)
