"""`fizzydo boards` — boards CRUD and publication."""

from __future__ import annotations

from typing import Optional

import typer

from fizzydo.output import print_no_content, print_resource, print_resources
from fizzydo.richtext import to_html

app = typer.Typer(help="Boards.", no_args_is_help=True)


@app.command("list")
def list_boards(ctx: typer.Context) -> None:
    """List boards in the current account."""
    state = ctx.obj
    items = state.client().get(state.client().account_path("/boards")).json()
    print_resources(items, kind="board", mode=state.mode)


@app.command()
def show(ctx: typer.Context, board_id: str) -> None:
    """Show a single board."""
    state = ctx.obj
    item = state.client().get(state.client().account_path(f"/boards/{board_id}")).json()
    print_resource(item, kind="board", mode=state.mode)


@app.command()
def create(
    ctx: typer.Context,
    name: str = typer.Option(..., "--name", help="Board name."),
    auto_postpone_days: Optional[int] = typer.Option(
        None, "--auto-postpone-days", help="Days of inactivity before auto-postpone."
    ),
    no_all_access: bool = typer.Option(
        False, "--no-all-access", help="Restrict access to specific users."
    ),
    public_description: Optional[str] = typer.Option(
        None,
        "--description",
        "--public-description",
        help="Markdown/HTML for the board description.",
    ),
) -> None:
    """Create a new board."""
    state = ctx.obj
    client = state.client()
    payload: dict[str, object] = {"name": name}
    if auto_postpone_days is not None:
        payload["auto_postpone_period_in_days"] = auto_postpone_days
    if no_all_access:
        payload["all_access"] = False
    desc_html = to_html(public_description, allow_stdin=False)
    if desc_html is not None:
        payload["public_description"] = desc_html

    response = client.post(client.account_path("/boards"), json={"board": payload})
    item = client.created_resource(response)
    if item:
        print_resource(item, kind="board", mode=state.mode)
    else:
        print_no_content("Board created.", mode=state.mode)


@app.command()
def update(
    ctx: typer.Context,
    board_id: str,
    name: Optional[str] = typer.Option(None, "--name"),
    auto_postpone_days: Optional[int] = typer.Option(None, "--auto-postpone-days"),
    public_description: Optional[str] = typer.Option(
        None, "--description", "--public-description"
    ),
    all_access: Optional[bool] = typer.Option(
        None, "--all-access/--no-all-access", help="Toggle account-wide access."
    ),
    user: list[str] = typer.Option(
        [], "--user", help="User ID with access (repeat for multiple)."
    ),
) -> None:
    """Update a board."""
    state = ctx.obj
    client = state.client()
    payload: dict[str, object] = {}
    if name is not None:
        payload["name"] = name
    if auto_postpone_days is not None:
        payload["auto_postpone_period_in_days"] = auto_postpone_days
    desc_html = to_html(public_description, allow_stdin=False)
    if desc_html is not None:
        payload["public_description"] = desc_html
    if all_access is not None:
        payload["all_access"] = all_access
    if user:
        payload["user_ids"] = user

    if not payload:
        raise typer.BadParameter("Provide at least one field to update.")

    client.put(client.account_path(f"/boards/{board_id}"), json={"board": payload})
    print_no_content("Board updated.", mode=state.mode)


@app.command()
def delete(ctx: typer.Context, board_id: str) -> None:
    """Delete a board."""
    state = ctx.obj
    client = state.client()
    client.delete(client.account_path(f"/boards/{board_id}"))
    print_no_content("Board deleted.", mode=state.mode)


@app.command()
def publish(ctx: typer.Context, board_id: str) -> None:
    """Publish a board (creates a shareable public link)."""
    state = ctx.obj
    client = state.client()
    response = client.post(client.account_path(f"/boards/{board_id}/publication"))
    item = response.json() if response.content else None
    if item:
        print_resource(item, kind="board", mode=state.mode)
    else:
        print_no_content("Board published.", mode=state.mode)


@app.command()
def unpublish(ctx: typer.Context, board_id: str) -> None:
    """Unpublish a board (removes public access)."""
    state = ctx.obj
    client = state.client()
    client.delete(client.account_path(f"/boards/{board_id}/publication"))
    print_no_content("Board unpublished.", mode=state.mode)
