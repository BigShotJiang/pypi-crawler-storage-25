"""`fizzydo tags` — list tags in the account."""

from __future__ import annotations

import typer

from fizzydo.output import print_resources

app = typer.Typer(help="Tags.", no_args_is_help=True)


@app.command("list")
def list_tags(ctx: typer.Context) -> None:
    """List all tags in the current account, sorted alphabetically."""
    state = ctx.obj
    client = state.client()
    items = client.get(client.account_path("/tags")).json()
    print_resources(items, kind="tag", mode=state.mode)
