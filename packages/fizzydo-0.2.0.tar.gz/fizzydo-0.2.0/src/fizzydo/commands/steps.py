"""`fizzydo steps` — checklist steps on a card."""

from __future__ import annotations

from typing import Optional

import typer

from fizzydo.errors import FizzyError
from fizzydo.output import print_no_content, print_resource, print_resources

app = typer.Typer(help="Checklist steps on a card.", no_args_is_help=True)


def _resolve_step_id(client, card_number: int, step_id: str) -> str:
    """Resolve a step reference to its real ID.

    Accepts either a literal step ID (passed through unchanged) or a positive
    1-based index that refers to the Nth step on the card. The index path
    fetches the card to look up the actual ID.
    """
    if step_id.isdigit() and int(step_id) > 0:
        index = int(step_id)
        card = client.get(client.account_path(f"/cards/{card_number}")).json()
        steps = card.get("steps") or []
        if index > len(steps):
            raise FizzyError(
                f"Step #{index} does not exist on card #{card_number} "
                f"(card has {len(steps)} step{'s' if len(steps) != 1 else ''})."
            )
        return steps[index - 1]["id"]
    return step_id


@app.command("list")
def list_steps(ctx: typer.Context, number: int) -> None:
    """List steps on a card.

    The fizzy.do API has no list endpoint for steps; we read them from the
    card's payload directly.
    """
    state = ctx.obj
    client = state.client()
    card = client.get(client.account_path(f"/cards/{number}")).json()
    steps = card.get("steps") or []
    print_resources(steps, kind="step", mode=state.mode)


@app.command()
def add(ctx: typer.Context, number: int, content: str) -> None:
    """Add a new step to a card."""
    state = ctx.obj
    client = state.client()
    response = client.post(
        client.account_path(f"/cards/{number}/steps"),
        json={"step": {"content": content}},
    )
    item = client.created_resource(response)
    if item:
        print_resource(item, kind="step", mode=state.mode)
    else:
        print_no_content("Step added.", mode=state.mode)


@app.command()
def done(ctx: typer.Context, number: int, step_id: str) -> None:
    """Mark a step as completed.

    STEP_ID may be a literal step ID or a 1-based index into the card's checklist.
    """
    state = ctx.obj
    client = state.client()
    resolved = _resolve_step_id(client, number, step_id)
    response = client.put(
        client.account_path(f"/cards/{number}/steps/{resolved}"),
        json={"step": {"completed": True}},
    )
    item = response.json() if response.content else None
    if item:
        print_resource(item, kind="step", mode=state.mode)
    else:
        print_no_content("Step completed.", mode=state.mode)


@app.command()
def undo(ctx: typer.Context, number: int, step_id: str) -> None:
    """Mark a step as not completed.

    STEP_ID may be a literal step ID or a 1-based index into the card's checklist.
    """
    state = ctx.obj
    client = state.client()
    resolved = _resolve_step_id(client, number, step_id)
    response = client.put(
        client.account_path(f"/cards/{number}/steps/{resolved}"),
        json={"step": {"completed": False}},
    )
    item = response.json() if response.content else None
    if item:
        print_resource(item, kind="step", mode=state.mode)
    else:
        print_no_content("Step reopened.", mode=state.mode)


@app.command()
def update(
    ctx: typer.Context,
    number: int,
    step_id: str,
    content: Optional[str] = typer.Option(None, "--content"),
    completed: Optional[bool] = typer.Option(None, "--completed/--not-completed"),
) -> None:
    """Update a step's content and/or completion.

    STEP_ID may be a literal step ID or a 1-based index into the card's checklist.
    """
    state = ctx.obj
    client = state.client()
    payload: dict[str, object] = {}
    if content is not None:
        payload["content"] = content
    if completed is not None:
        payload["completed"] = completed
    if not payload:
        raise typer.BadParameter("Provide --content or --completed/--not-completed.")
    resolved = _resolve_step_id(client, number, step_id)
    response = client.put(
        client.account_path(f"/cards/{number}/steps/{resolved}"),
        json={"step": payload},
    )
    item = response.json() if response.content else None
    if item:
        print_resource(item, kind="step", mode=state.mode)
    else:
        print_no_content("Step updated.", mode=state.mode)


@app.command()
def delete(ctx: typer.Context, number: int, step_id: str) -> None:
    """Delete a step.

    STEP_ID may be a literal step ID or a 1-based index into the card's checklist.
    """
    state = ctx.obj
    client = state.client()
    resolved = _resolve_step_id(client, number, step_id)
    client.delete(client.account_path(f"/cards/{number}/steps/{resolved}"))
    print_no_content("Step deleted.", mode=state.mode)
