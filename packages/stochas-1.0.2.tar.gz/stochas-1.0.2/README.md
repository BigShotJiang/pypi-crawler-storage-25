# stochas: Smart Data Orchestration

<p align="center">
  <a href="https://pypi.org/project/stochas/">
    <img src="https://img.shields.io/pypi/v/stochas.svg" alt="PyPI version">
  </a>
  <a href="https://pypi.org/project/stochas/">
    <img src="https://img.shields.io/pypi/pyversions/stochas.svg" alt="Python versions">
  </a>
  <a href="https://github.com/Hydrowelder/stochas/actions/workflows/workflow.yml">
    <img src="https://github.com/Hydrowelder/stochas/actions/workflows/workflow.yml/badge.svg" alt="Tests & Release Status">
  </a>
  <a href="https://docs.pydantic.dev/latest/">
    <img src="https://img.shields.io/badge/Pydantic-v2-FF43A1?logo=pydantic&logoColor=white" alt="Pydantic v2">
  </a>
  <a href="https://opensource.org/licenses/Apache-2.0">
    <img src="https://img.shields.io/badge/License-Apache_2.0-blue.svg" alt="License">
  </a>
  <a href="https://hydrowelder.github.io/stochas/">
    <img src="https://img.shields.io/badge/docs-GitHub_Pages-blue.svg" alt="Documentation">
  </a>
  <a href="https://pypistats.org/packages/stochas">
    <img src="https://img.shields.io/pypi/dm/stochas.svg" alt="Downloads">
  </a>
</p>

`stochas` is a Python framework built to handle the complexity of **Monte Carlo simulations**, **parametric studies**, and **probabilistic modeling**.

It provides a robust bridge between abstract statistical rules and concrete simulation data, ensuring your experiments are repeatable, traceable, and easy to manage.

---

## Installation

Install the package via your preferred manager:

```bash
uv add stochas
```

or with `pip`:

```bash
pip install stochas
```

---

## Core Features

* **Salted Seeding**: Combines Global Seeds, Parameter Names, and Trial Numbers for unique but deterministic draws.
* **Numeric Mixins**: Use your data containers directly in math operations (`container * 5.0`) without manually extracting values.
* **Nominal Support**: Easily toggle between "Perfect World" (Trial 0) and "Probabilistic World" (Monte Carlo) results.
* **Pydantic Foundation**: Every component is a Pydantic model, providing out-of-the-box validation and effortless JSON serialization.

---

## Why use `stochas`?

Managing hundreds of simulation trials can quickly become a mess of manual seeds and inconsistent data. `stochas` solves this by providing:

* **Repeatable Randomness**: Our "Salted Seed" logic ensures that any specific trial can be perfectly recreated, even years later, by tying randomness to simple to set and store values.
* **Smart Containers**: `NamedValue` objects behave like numbers or arrays but protect your data from accidental overwrites using a state-machine logic.
* **Physics-Ready Distributions**: A wide range of built-in distributions (Normal, Truncated Normal, Log-Normal, etc.) that handle their own random number generators internally.
* **Serialized Registries**: Automatically track exactly which "rules" (`Distributions`) and "results" (`NamedValues`) were used in every trial for easy export to JSON or databases.
