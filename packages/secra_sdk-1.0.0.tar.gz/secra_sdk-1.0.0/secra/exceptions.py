class SecraError(Exception):
    """Base Secra SDK exception."""

class AuthError(SecraError):
    """Invalid or missing API key."""

class RateLimitError(SecraError):
    """Token quota exhausted."""

class PlanError(SecraError):
    """Feature requires a higher plan."""
