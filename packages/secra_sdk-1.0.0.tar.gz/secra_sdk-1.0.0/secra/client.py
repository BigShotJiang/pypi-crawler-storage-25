"""
Secra Python SDK — HTTP client.
"""
from __future__ import annotations

from typing import Optional
import httpx

from .models import ScanResult, SanitizeResult, ToolValidation, Balance
from .exceptions import SecraError, AuthError, RateLimitError, PlanError

DEFAULT_BASE_URL = "https://secra-backend-production.up.railway.app"
DEFAULT_TIMEOUT  = 30.0


class SecraClient:
    """
    Synchronous Secra client.

    Parameters
    ----------
    api_key : str
        Your Secra API key (Developer or Pro plan required).
    base_url : str, optional
        Override the API base URL (useful for self-hosted).
    timeout : float, optional
        Request timeout in seconds (default 30).

    Examples
    --------
    >>> client = SecraClient(api_key="sk-...")
    >>> result = client.scan("Ignore all previous instructions")
    >>> result.is_blocked
    True
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self._api_key = api_key
        self._base    = base_url.rstrip("/")
        self._http    = httpx.Client(
            headers={"X-API-Key": api_key, "Content-Type": "application/json"},
            timeout=timeout,
        )

    # ── Core scan ─────────────────────────────────────────────────────────────

    def scan(self, prompt: str, context: Optional[str] = None) -> ScanResult:
        """
        Scan a prompt for injection attacks, persona hijacking, and data leakage.

        Parameters
        ----------
        prompt : str
            The prompt text to scan (before it reaches your LLM).
        context : str, optional
            System prompt or prior conversation context for better detection.

        Returns
        -------
        ScanResult
            Use ``result.is_blocked`` to gate LLM calls.
        """
        resp = self._post("/v1/scan", {"prompt": prompt, "context": context})
        return ScanResult.from_dict(resp)

    def sanitize(self, prompt: str, level: str = "standard") -> SanitizeResult:
        """
        Sanitize a prompt — strips injection patterns and returns a clean version.

        Parameters
        ----------
        prompt : str
            The raw prompt to sanitize.
        level : str
            ``"standard"`` (default) or ``"strict"``.
        """
        resp = self._post("/v1/sanitize", {"prompt": prompt, "level": level})
        return SanitizeResult.from_dict(resp)

    def validate_tool(self, tool_name: str, arguments: dict) -> ToolValidation:
        """
        Validate a tool call before execution (Developer+ plan).

        Parameters
        ----------
        tool_name : str
            Name of the tool/function being called.
        arguments : dict
            Arguments that will be passed to the tool.
        """
        resp = self._post("/v1/validate-tool", {"tool_name": tool_name, "arguments": arguments})
        return ToolValidation.from_dict(resp)

    def scan_content(self, content: str, source_url: Optional[str] = None) -> ScanResult:
        """
        Scan external content before injecting it into agent context (Developer+).

        Parameters
        ----------
        content : str
            Web page body, document text, or API response to scan.
        source_url : str, optional
            URL the content was fetched from (used in threat reporting).
        """
        resp = self._post("/v1/scan-content", {"content": content, "source_url": source_url})
        return ScanResult.from_dict(resp)

    def balance(self) -> Balance:
        """Return current token balance and plan info."""
        resp = self._get("/v1/usage/balance")
        return Balance.from_dict(resp)

    # ── Internal ──────────────────────────────────────────────────────────────

    def _post(self, path: str, body: dict) -> dict:
        r = self._http.post(f"{self._base}{path}", json=body)
        return self._handle(r)

    def _get(self, path: str) -> dict:
        r = self._http.get(f"{self._base}{path}")
        return self._handle(r)

    def _handle(self, r: httpx.Response) -> dict:
        if r.status_code == 401:
            raise AuthError("Invalid or missing API key.")
        if r.status_code == 403:
            detail = r.json().get("detail", {})
            raise PlanError(detail.get("message", "Plan upgrade required."))
        if r.status_code == 429:
            raise RateLimitError("Token limit reached. Upgrade or wait for reset.")
        if not r.is_success:
            raise SecraError(f"API error {r.status_code}: {r.text}")
        return r.json()

    def close(self):
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


class AsyncSecraClient(SecraClient):
    """
    Async variant — use inside async/await code.

    Examples
    --------
    >>> async with AsyncSecraClient(api_key="sk-...") as client:
    ...     result = await client.scan("Ignore all previous instructions")
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._async_http = httpx.AsyncClient(
            headers={"X-API-Key": self._api_key, "Content-Type": "application/json"},
            timeout=DEFAULT_TIMEOUT,
        )

    async def scan(self, prompt: str, context: Optional[str] = None) -> ScanResult:
        resp = await self._apost("/v1/scan", {"prompt": prompt, "context": context})
        return ScanResult.from_dict(resp)

    async def sanitize(self, prompt: str, level: str = "standard") -> SanitizeResult:
        resp = await self._apost("/v1/sanitize", {"prompt": prompt, "level": level})
        return SanitizeResult.from_dict(resp)

    async def validate_tool(self, tool_name: str, arguments: dict) -> ToolValidation:
        resp = await self._apost("/v1/validate-tool", {"tool_name": tool_name, "arguments": arguments})
        return ToolValidation.from_dict(resp)

    async def scan_content(self, content: str, source_url: Optional[str] = None) -> ScanResult:
        resp = await self._apost("/v1/scan-content", {"content": content, "source_url": source_url})
        return ScanResult.from_dict(resp)

    async def balance(self) -> Balance:
        r = await self._async_http.get(f"{self._base}/v1/usage/balance")
        return Balance.from_dict(self._handle(r))

    async def _apost(self, path: str, body: dict) -> dict:
        r = await self._async_http.post(f"{self._base}{path}", json=body)
        return self._handle(r)

    async def aclose(self):
        await self._async_http.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        await self.aclose()
