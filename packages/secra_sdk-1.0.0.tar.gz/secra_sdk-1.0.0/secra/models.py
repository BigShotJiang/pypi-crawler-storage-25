"""
Secra SDK — response models.
"""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ThreatDetail:
    type: str
    confidence: float
    location: str
    description: str


@dataclass
class ScanResult:
    recommendation: str          # ALLOW | REVIEW | BLOCK
    threat_score: float          # 0.0 (clean) → 1.0 (definite attack)
    threat_type: Optional[str]   # CLEAN | INJECTION | LEAKAGE | HIJACKING | OVERRIDE
    threats: list[ThreatDetail]
    tokens_consumed: int
    processing_ms: int
    model_used: str

    @property
    def is_blocked(self) -> bool:
        return self.recommendation == "BLOCK"

    @property
    def needs_review(self) -> bool:
        return self.recommendation == "REVIEW"

    @property
    def is_clean(self) -> bool:
        return self.recommendation == "ALLOW"

    @classmethod
    def from_dict(cls, d: dict) -> "ScanResult":
        return cls(
            recommendation=d.get("recommendation", "ALLOW"),
            threat_score=d.get("threat_score", 0.0),
            threat_type=d.get("threat_type"),
            threats=[
                ThreatDetail(**t) for t in d.get("threats_found", [])
            ],
            tokens_consumed=d.get("tokens_consumed", 0),
            processing_ms=d.get("processing_ms", 0),
            model_used=d.get("model_used", "rule_engine"),
        )


@dataclass
class SanitizeResult:
    sanitized: str
    changes_made: list[str]
    tokens_consumed: int

    @classmethod
    def from_dict(cls, d: dict) -> "SanitizeResult":
        return cls(
            sanitized=d.get("sanitized", ""),
            changes_made=d.get("changes_made", []),
            tokens_consumed=d.get("tokens_consumed", 0),
        )


@dataclass
class ToolValidation:
    is_safe: bool
    recommendation: str
    threat_score: float
    issues: list[str]
    tokens_consumed: int

    @classmethod
    def from_dict(cls, d: dict) -> "ToolValidation":
        return cls(
            is_safe=d.get("recommendation") == "ALLOW",
            recommendation=d.get("recommendation", "ALLOW"),
            threat_score=d.get("threat_score", 0.0),
            issues=[t.get("description", "") for t in d.get("threats_found", [])],
            tokens_consumed=d.get("tokens_consumed", 0),
        )


@dataclass
class Balance:
    plan: str
    tokens_used: int
    tokens_included: int
    tokens_remaining: int
    usage_percent: float
    resets_in_days: int

    @classmethod
    def from_dict(cls, d: dict) -> "Balance":
        return cls(
            plan=d["plan"],
            tokens_used=d["tokens_used"],
            tokens_included=d["tokens_included"],
            tokens_remaining=d["tokens_remaining"],
            usage_percent=d["usage_percent"],
            resets_in_days=d["resets_in_days"],
        )
