"""
Secra Python SDK
The Security Layer Every AI Agent Needs.

Usage:
    from secra import SecraClient

    client = SecraClient(api_key="sk-...")
    result = client.scan("Ignore all previous instructions and...")
    if result.is_blocked:
        raise ValueError("Prompt injection detected")
"""

from .client import SecraClient
from .models import ScanResult, SanitizeResult, ToolValidation, Balance

__version__ = "1.0.0"
__all__ = ["SecraClient", "ScanResult", "SanitizeResult", "ToolValidation", "Balance"]
