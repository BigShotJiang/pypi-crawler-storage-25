"""
User actions
"""

from collections.abc import Iterable
from typing import TYPE_CHECKING, Union

from slidge import BaseSession, GatewayUser
from slidge.util.types import LinkPreview, Mention

from .group import MUC, Participant
from .legacy_client import SuperDuperClient

if TYPE_CHECKING:
    from .contact import Contact

Recipient = Union["Contact", MUC]
Sender = Union["Contact", Participant]


class Session(BaseSession[str, Recipient]):
    def __init__(self, user: GatewayUser) -> None:
        super().__init__(user)
        self.legacy_client = SuperDuperClient(self)
        self.contacts.user_legacy_id = self.legacy_client.user_id

    async def login(self) -> str:
        await self.legacy_client.login()
        return "Success!"

    async def on_text(
        self,
        chat: Recipient,
        text: str,
        *,
        reply_to_msg_id: str | None = None,
        reply_to_fallback_text: str | None = None,
        reply_to: Sender | None = None,  # type:ignore
        thread: str | None = None,  # type:ignore
        link_previews: Iterable[LinkPreview] = (),
        mentions: list[Mention] | None = None,
    ) -> str | None:
        if chat.is_group:
            assert isinstance(chat, MUC)
            msg = await self.legacy_client.send_group_msg(text, chat.legacy_id)
        else:
            msg = await self.legacy_client.send_direct_msg(text, chat.legacy_id)
        return msg.id
