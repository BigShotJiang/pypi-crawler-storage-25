from slixmpp.exceptions import XMPPError

from slidge import (
    BaseGateway,
    BaseSession,
    LegacyBookmarks,
    LegacyContact,
    LegacyParticipant,
    LegacyRoster,
)
from slidge.util.test import SlidgeTest
from slidge.util.types import MessageReference


class Gateway(BaseGateway):
    COMPONENT_NAME = "Megacorp Chat XMPP Gateway"
    GROUPS = True


class Session(BaseSession):
    async def login(self):
        pass


class Contact(LegacyContact):
    pass


class Roster(LegacyRoster):
    async def legacy_id_to_jid_username(self, legacy_id: str) -> str:
        if not legacy_id.startswith("room-"):
            raise XMPPError
        return legacy_id


class Bookmarks(LegacyBookmarks):
    async def fill(self):
        self.user_nick = "🎉coquinou"


class TestMamCorrection(SlidgeTest):
    plugin = globals()

    def setUp(self):
        super().setUp()
        self._add_slidge_user()

    def test_reply_to_user(self) -> None:
        muc = self.get_joined_muc("room-coquinou")
        part: LegacyParticipant = self.run_coro(muc.get_user_participant())
        part.send_text(
            "a body",
            "a-legacy-id",
            reply_to=MessageReference(
                "ref",
                author="user",
                body="blabla",
            ),
        )
        self.send(  # language=XML
            """
            <message type="groupchat"
                     from="room-coquinou@aim.shakespeare.lit/coquinou-1u25g"
                     id="a-legacy-id"
                     to="romeo@shakespeare.lit/gajim">
              <body>&gt; 🎉coquinou:\n&gt; blabla\na body</body>
              <active xmlns="http://jabber.org/protocol/chatstates" />
              <markable xmlns="urn:xmpp:chat-markers:0" />
              <stanza-id xmlns="urn:xmpp:sid:0"
                         id="a-legacy-id"
                         by="room-coquinou@aim.shakespeare.lit" />
              <reply xmlns="urn:xmpp:reply:0"
                     id="ref"
                     to="room-coquinou@aim.shakespeare.lit/coquinou-1u25g" />
              <fallback xmlns="urn:xmpp:fallback:0"
                        for="urn:xmpp:reply:0">
                <body start="0"
                      end="22" />
              </fallback>
              <occupant-id xmlns="urn:xmpp:occupant-id:0"
                           id="slidge-user" />
              <nick xmlns="http://jabber.org/protocol/nick">🎉coquinou</nick>
            </message>
            """
        )
