from slixmpp.exceptions import XMPPError

from slidge import (
    BaseGateway,
    BaseSession,
    LegacyBookmarks,
    LegacyContact,
    LegacyParticipant,
    LegacyRoster,
)
from slidge.group import LegacyMUC
from slidge.util.test import SlidgeTest


class Gateway(BaseGateway):
    COMPONENT_NAME = "Megacorp Chat XMPP Gateway"
    GROUPS = True


class Session(BaseSession):
    async def login(self):
        pass


class Roster(LegacyRoster[str, LegacyContact]):
    async def legacy_id_to_jid_username(self, legacy_id: str) -> str:
        if legacy_id.startswith("room-"):
            raise XMPPError("item-not-found", "This is a MUC JID")
        return legacy_id


class Bookmarks(LegacyBookmarks[str, LegacyMUC[str, str, LegacyParticipant, str]]):
    async def fill(self) -> None:
        pass


class TestOccupantId(SlidgeTest):
    plugin = globals()

    def setUp(self) -> None:
        super().setUp()
        self._add_slidge_user()

    def test_update_contact_in_previously_anonymous_participant(self) -> None:
        muc = self.get_joined_muc("room-occupant")
        self.run_coro(muc.get_participant(occupant_id="occupant-id"))
        self.run_coro(
            muc.get_participant_by_legacy_id("user-id", occupant_id="occupant-id")
        )

        by_occupant_id: LegacyParticipant = self.run_coro(
            muc.get_participant(occupant_id="occupant-id")
        )
        by_legacy_id: LegacyParticipant = self.run_coro(
            muc.get_participant_by_legacy_id("user-id")
        )

        assert by_occupant_id.occupant_id == "occupant-id"
        assert by_legacy_id.occupant_id == "occupant-id"

        assert by_occupant_id.contact.legacy_id == "user-id"
        assert by_legacy_id.contact.legacy_id == "user-id"
