from slixmpp.jid import unescape_node

JID_ESCAPE_SEQUENCES = {
    "\\20",
    "\\22",
    "\\26",
    "\\27",
    "\\2f",
    "\\3a",
    "\\3c",
    "\\3e",
    "\\40",
    "\\5c",
}


JID_UNESCAPE_TRANSFORMATIONS = {
    "\\20": " ",
    "\\22": '"',
    "\\26": "&",
    "\\27": "'",
    "\\2f": "/",
    "\\3a": ":",
    "\\3c": "<",
    "\\3e": ">",
    "\\40": "@",
    "\\5c": "\\",
}


ESCAPE_TABLE = "".maketrans({v: k for k, v in JID_UNESCAPE_TRANSFORMATIONS.items()})

__all__ = "ESCAPE_TABLE", "unescape_node"
