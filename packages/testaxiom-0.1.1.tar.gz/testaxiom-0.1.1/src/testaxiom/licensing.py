"""
TestAxiom Licensing — Tier-based feature gating.

Tiers:
    COMMUNITY (Free):
        - EP, BVA engines (unlimited)
        - CLI + Python API
        - JSON/text output
        - Single-parameter analysis
        - Full traceability & rationale
        - Open source, MIT license

    PRO ($19/mo or $149/yr — future):
        - Everything in Community
        - Decision Table engine
        - Pairwise (All-Pairs) engine
        - State Transition engine
        - Multi-parameter batch analysis
        - CSV/Excel export
        - AI requirement parser (NLP → parameters)
        - Priority support

    ENTERPRISE (custom pricing — future):
        - Everything in Pro
        - Jira/Xray integration
        - Traceability matrix export (regulatory compliance)
        - Team management & shared configurations
        - SSO / SAML
        - Audit log
        - On-premise deployment option
        - Dedicated support & SLA
"""

from __future__ import annotations

from enum import Enum
from functools import wraps
from typing import Callable


class Tier(str, Enum):
    """License tiers."""
    COMMUNITY = "community"
    PRO = "pro"
    ENTERPRISE = "enterprise"


# Global tier — defaults to COMMUNITY (free)
_current_tier: Tier = Tier.COMMUNITY


def get_tier() -> Tier:
    """Get current license tier."""
    return _current_tier


def set_tier(tier: Tier | str) -> None:
    """Set license tier (for testing or activation)."""
    global _current_tier
    if isinstance(tier, str):
        tier = Tier(tier)
    _current_tier = tier


def requires_tier(minimum_tier: Tier) -> Callable:
    """
    Decorator that gates a function behind a minimum tier.

    Usage:
        @requires_tier(Tier.PRO)
        def generate_pairwise(...):
            ...
    """
    tier_order = {Tier.COMMUNITY: 0, Tier.PRO: 1, Tier.ENTERPRISE: 2}

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            current = get_tier()
            if tier_order[current] < tier_order[minimum_tier]:
                raise TierError(
                    f"'{func.__name__}' requires {minimum_tier.value.upper()} tier. "
                    f"Current tier: {current.value.upper()}. "
                    f"Upgrade at https://testaxiom.dev/pricing"
                )
            return func(*args, **kwargs)
        wrapper._minimum_tier = minimum_tier
        return wrapper
    return decorator


class TierError(Exception):
    """Raised when a feature is accessed without the required tier."""
    pass


# Feature availability map (for introspection / UI display)
FEATURE_MAP = {
    "ep_engine": Tier.COMMUNITY,
    "bva_engine": Tier.COMMUNITY,
    "cli": Tier.COMMUNITY,
    "python_api": Tier.COMMUNITY,
    "json_export": Tier.COMMUNITY,
    "text_export": Tier.COMMUNITY,
    "traceability": Tier.COMMUNITY,
    "decision_table_engine": Tier.PRO,
    "pairwise_engine": Tier.PRO,
    "state_transition_engine": Tier.PRO,
    "multi_param_batch": Tier.PRO,
    "csv_export": Tier.PRO,
    "excel_export": Tier.PRO,
    "ai_parser": Tier.PRO,
    "jira_integration": Tier.ENTERPRISE,
    "traceability_matrix_export": Tier.ENTERPRISE,
    "team_management": Tier.ENTERPRISE,
    "sso_saml": Tier.ENTERPRISE,
    "audit_log": Tier.ENTERPRISE,
    "on_premise": Tier.ENTERPRISE,
}


def list_features(tier: Tier | None = None) -> dict[str, str]:
    """
    List features and their required tiers.

    Args:
        tier: If specified, only show features available at this tier.

    Returns:
        Dict of feature_name → required_tier
    """
    tier_order = {Tier.COMMUNITY: 0, Tier.PRO: 1, Tier.ENTERPRISE: 2}

    if tier is None:
        return {k: v.value for k, v in FEATURE_MAP.items()}

    level = tier_order[tier]
    return {
        k: v.value for k, v in FEATURE_MAP.items()
        if tier_order[v] <= level
    }
