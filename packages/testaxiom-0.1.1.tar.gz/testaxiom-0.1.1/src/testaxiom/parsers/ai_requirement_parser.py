"""
AI Requirement Parser — extract ParameterSpec objects from free-text requirements.

Uses Claude API (tool_use) with prompt caching for efficient repeated calls.
Requires the 'anthropic' optional dependency: pip install testaxiom[ai]
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from testaxiom.core import AnalysisResult, ParameterSpec

if TYPE_CHECKING:
    pass

_SYSTEM_PROMPT = """You are a test design expert specializing in ISTQB test design techniques.
Your job is to extract testable parameters from software requirements text.

For each parameter you identify, determine:
- name: snake_case identifier (e.g. "age", "username", "account_balance")
- param_type: one of "int", "float", "str", "bool", "enum"
- valid_range: [min, max] for numeric parameters (null if not applicable)
- valid_values: explicit list of valid values for enum/fixed-set parameters (null if not applicable)
- constraints: list of business rule strings not captured by range/values (e.g. "must be divisible by 5")
- boundary_inclusive: true if boundaries are inclusive (default true)

Extract ALL testable parameters you can identify. Be precise about numeric boundaries."""

_EXTRACT_TOOL = {
    "name": "extract_parameters",
    "description": "Extract testable parameters from requirements text",
    "input_schema": {
        "type": "object",
        "properties": {
            "parameters": {
                "type": "array",
                "description": "List of parameters extracted from the requirements",
                "items": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "Parameter name in snake_case",
                        },
                        "param_type": {
                            "type": "string",
                            "enum": ["int", "float", "str", "bool", "enum"],
                            "description": "Data type of the parameter",
                        },
                        "valid_range": {
                            "type": ["array", "null"],
                            "items": {"type": "number"},
                            "minItems": 2,
                            "maxItems": 2,
                            "description": "[min, max] for numeric types, null otherwise",
                        },
                        "valid_values": {
                            "type": ["array", "null"],
                            "description": "Explicit list of valid values for enum/fixed-set, null otherwise",
                        },
                        "constraints": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Additional business rules not captured by range/values",
                        },
                        "boundary_inclusive": {
                            "type": "boolean",
                            "description": "Whether boundaries are inclusive (default true)",
                        },
                    },
                    "required": ["name", "param_type", "constraints", "boundary_inclusive"],
                },
            }
        },
        "required": ["parameters"],
    },
}


def parse_requirements(
    requirements_text: str,
    client: Any | None = None,
    model: str = "claude-sonnet-4-6",
) -> list[ParameterSpec]:
    """
    Parse free-text requirements and return a list of ParameterSpec objects.

    Args:
        requirements_text: Natural language requirements, e.g.
            "User age must be between 18 and 65. Username must be 3-50 characters."
        client: Optional pre-configured Anthropic client. If None, creates one
            using ANTHROPIC_API_KEY from environment.
        model: Claude model ID to use.

    Returns:
        List of ParameterSpec objects ready to pass to analyze().

    Raises:
        ImportError: If the 'anthropic' package is not installed.
        TierError: If current tier is COMMUNITY (requires PRO).

    Example:
        >>> from testaxiom.parsers import parse_requirements
        >>> from testaxiom.licensing import set_tier, Tier
        >>> set_tier(Tier.PRO)
        >>> specs = parse_requirements("Age must be 18-65, weight must be 0.5-300.0 kg")
        >>> for spec in specs:
        ...     print(spec.name, spec.valid_range)
    """
    try:
        import anthropic
    except ImportError as exc:
        raise ImportError(
            "The 'anthropic' package is required for AI parsing. "
            "Install it with: pip install testaxiom[ai]"
        ) from exc

    if client is None:
        client = anthropic.Anthropic()

    response = client.messages.create(
        model=model,
        max_tokens=2048,
        system=[
            {
                "type": "text",
                "text": _SYSTEM_PROMPT,
                "cache_control": {"type": "ephemeral"},
            }
        ],
        tools=[_EXTRACT_TOOL],
        tool_choice={"type": "tool", "name": "extract_parameters"},
        messages=[
            {
                "role": "user",
                "content": requirements_text,
            }
        ],
    )

    tool_use_block = next(
        (block for block in response.content if block.type == "tool_use"),
        None,
    )
    if tool_use_block is None:
        return []

    raw_params: list[dict] = tool_use_block.input.get("parameters", [])
    return [_dict_to_spec(p) for p in raw_params]


def parse_and_analyze(
    requirements_text: str,
    client: Any | None = None,
    model: str = "claude-sonnet-4-6",
    **analyze_kwargs: Any,
) -> list[AnalysisResult]:
    """
    Parse free-text requirements and run full analysis on each extracted parameter.

    Convenience wrapper: parse_requirements() → analyze() for each ParameterSpec.

    Args:
        requirements_text: Natural language requirements text.
        client: Optional pre-configured Anthropic client.
        model: Claude model ID to use.
        **analyze_kwargs: Extra kwargs forwarded to analyze() (e.g. bva_mode, techniques).

    Returns:
        List of AnalysisResult, one per extracted parameter.

    Example:
        >>> results = parse_and_analyze("Age must be 18-65", bva_mode="3-value")
        >>> for r in results:
        ...     print(r.summary())
    """
    from testaxiom.core import analyze

    specs = parse_requirements(requirements_text, client=client, model=model)
    return [analyze(spec, **analyze_kwargs) for spec in specs]


def _dict_to_spec(data: dict) -> ParameterSpec:
    """Convert a raw dict from Claude tool_use output into a ParameterSpec."""
    valid_range = data.get("valid_range")
    if valid_range is not None:
        valid_range = tuple(valid_range)

    return ParameterSpec(
        name=data["name"],
        param_type=data.get("param_type", "int"),
        valid_range=valid_range,
        valid_values=data.get("valid_values"),
        constraints=data.get("constraints", []),
        boundary_inclusive=data.get("boundary_inclusive", True),
    )
