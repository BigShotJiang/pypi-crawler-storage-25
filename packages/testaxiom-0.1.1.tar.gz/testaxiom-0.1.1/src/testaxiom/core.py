"""
Core data models and orchestration for TestAxiom.

This module defines the fundamental types (ParameterSpec, TestCase, AnalysisResult)
and the main `analyze()` function that selects and runs the appropriate
test design technique engine(s).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Technique(str, Enum):
    """Supported ISTQB test design techniques."""
    EP = "ep"
    BVA = "bva"
    DECISION_TABLE = "decision_table"
    STATE_TRANSITION = "state_transition"
    PAIRWISE = "pairwise"


class Verdict(str, Enum):
    """Expected test verdict."""
    VALID = "valid"
    INVALID = "invalid"


@dataclass
class ParameterSpec:
    """
    Specification of a single input parameter to generate test cases for.

    Attributes:
        name: Human-readable parameter name (e.g., "age", "username").
        param_type: Data type — "int", "float", "str", "bool", "enum".
        valid_range: Tuple of (min, max) for numeric types.
        valid_values: Explicit list of valid values for enum/str types.
        constraints: Business rules as free text (e.g., "must be divisible by 5").
        boundary_inclusive: Whether boundaries are inclusive (default True).
    """
    name: str
    param_type: str = "int"
    valid_range: tuple[Any, Any] | None = None
    valid_values: list[Any] | None = None
    constraints: list[str] = field(default_factory=list)
    boundary_inclusive: bool = True


@dataclass
class TestCase:
    """
    A single generated test case with full traceability.

    Attributes:
        id: Unique test case identifier (e.g., "EP-age-001").
        parameter: Name of the parameter being tested.
        technique: Which technique generated this test case.
        input_value: The concrete test input value.
        expected: Expected verdict (valid/invalid).
        description: Human-readable explanation.
        rationale: WHY this test case exists — the mathematical justification.
        partition: Which equivalence partition this belongs to (if applicable).
        boundary_type: Type of boundary (min, max, below_min, above_max, etc.).
    """
    id: str
    parameter: str
    technique: Technique
    input_value: Any
    expected: Verdict
    description: str
    rationale: str
    partition: str | None = None
    boundary_type: str | None = None


@dataclass
class AnalysisResult:
    """
    Complete result of analyzing a parameter with one or more techniques.

    Attributes:
        parameter: The original parameter specification.
        techniques_applied: List of techniques that were applied.
        test_cases: All generated test cases.
        coverage_summary: Human-readable summary of coverage achieved.
        total_reduced_from: How many cases exhaustive testing would require.
        total_generated: How many cases were actually generated.
        efficiency_ratio: Reduction percentage (e.g., "87% reduction").
    """
    parameter: ParameterSpec
    techniques_applied: list[Technique]
    test_cases: list[TestCase]
    coverage_summary: str = ""
    total_reduced_from: int | None = None
    total_generated: int = 0
    efficiency_ratio: str = ""

    def __post_init__(self):
        self.total_generated = len(self.test_cases)
        if self.total_reduced_from and self.total_reduced_from > 0:
            reduction = (1 - self.total_generated / self.total_reduced_from) * 100
            self.efficiency_ratio = f"{reduction:.0f}% reduction"

    def summary(self) -> str:
        """Return a formatted summary of the analysis."""
        lines = [
            f"═══ TestAxiom Analysis: {self.parameter.name} ═══",
            f"Parameter type: {self.parameter.param_type}",
            f"Techniques applied: {', '.join(t.value.upper() for t in self.techniques_applied)}",
            f"Test cases generated: {self.total_generated}",
        ]
        if self.efficiency_ratio:
            lines.append(
                f"Efficiency: {self.efficiency_ratio} "
                f"(from {self.total_reduced_from} exhaustive → {self.total_generated} optimized)"
            )
        lines.append("")
        lines.append("─── Test Cases ───")
        for tc in self.test_cases:
            verdict_icon = "✓" if tc.expected == Verdict.VALID else "✗"
            lines.append(
                f"  [{tc.technique.value.upper()}] {tc.id}: "
                f"input={tc.input_value} → {verdict_icon} {tc.expected.value}"
            )
            lines.append(f"         ↳ {tc.rationale}")
        return "\n".join(lines)


def analyze(
    parameter: str | ParameterSpec,
    param_type: str = "int",
    valid_range: tuple[Any, Any] | None = None,
    valid_values: list[Any] | None = None,
    constraints: list[str] | None = None,
    techniques: list[str] | None = None,
    boundary_inclusive: bool = True,
    bva_mode: str = "2-value",
) -> AnalysisResult:
    """
    Analyze a parameter and generate optimal test cases using ISTQB techniques.

    This is the main entry point for TestAxiom. It accepts either a ParameterSpec
    object or individual arguments, selects the appropriate technique engine(s),
    and returns a fully traced AnalysisResult.

    Args:
        parameter: Parameter name (str) or a full ParameterSpec object.
        param_type: Data type — "int", "float", "str", "bool", "enum".
        valid_range: Tuple of (min, max) for numeric types.
        valid_values: Explicit list of valid values for enum/str types.
        constraints: Business rules as free text strings.
        techniques: List of technique codes to apply. Default: auto-select.
            Options: "ep", "bva", "decision_table", "pairwise", "state_transition".
        boundary_inclusive: Whether range boundaries are inclusive (default True).
        bva_mode: "2-value" or "3-value" boundary analysis.

    Returns:
        AnalysisResult with all generated test cases and traceability.

    Example:
        >>> result = analyze("age", param_type="int", valid_range=(18, 65))
        >>> print(result.summary())
    """
    # Normalize parameter input
    if isinstance(parameter, str):
        spec = ParameterSpec(
            name=parameter,
            param_type=param_type,
            valid_range=valid_range,
            valid_values=valid_values,
            constraints=constraints or [],
            boundary_inclusive=boundary_inclusive,
        )
    else:
        spec = parameter

    # Auto-select techniques if not specified
    if techniques is None:
        techniques = _auto_select_techniques(spec)

    technique_enums = [Technique(t) for t in techniques]

    # Import engines
    from testaxiom.engines.equivalence_partitioning import EPEngine
    from testaxiom.engines.boundary_value import BVAEngine

    engine_map = {
        Technique.EP: EPEngine,
        Technique.BVA: BVAEngine,
    }

    # Run selected engines and collect test cases
    all_test_cases: list[TestCase] = []
    for tech in technique_enums:
        engine_class = engine_map.get(tech)
        if engine_class is None:
            continue
        engine = engine_class()
        cases = engine.generate(spec, bva_mode=bva_mode)
        all_test_cases.extend(cases)

    # Calculate exhaustive count for efficiency ratio
    exhaustive = _estimate_exhaustive_count(spec)

    result = AnalysisResult(
        parameter=spec,
        techniques_applied=technique_enums,
        test_cases=all_test_cases,
        total_reduced_from=exhaustive,
    )

    # Generate coverage summary
    valid_count = sum(1 for tc in all_test_cases if tc.expected == Verdict.VALID)
    invalid_count = sum(1 for tc in all_test_cases if tc.expected == Verdict.INVALID)
    result.coverage_summary = (
        f"{result.total_generated} test cases: "
        f"{valid_count} valid, {invalid_count} invalid. "
        f"Techniques: {', '.join(t.value.upper() for t in technique_enums)}."
    )

    return result


def _auto_select_techniques(spec: ParameterSpec) -> list[str]:
    """Intelligently select the best techniques based on parameter characteristics."""
    techniques = []

    if spec.param_type in ("int", "float") and spec.valid_range:
        techniques.append("ep")
        techniques.append("bva")
    elif spec.param_type == "bool":
        techniques.append("ep")
    elif spec.param_type in ("str", "enum") and spec.valid_values:
        techniques.append("ep")
    else:
        techniques.append("ep")

    return techniques


def _estimate_exhaustive_count(spec: ParameterSpec) -> int | None:
    """Estimate how many test cases exhaustive testing would require."""
    if spec.valid_range and spec.param_type == "int":
        low, high = spec.valid_range
        return int(high - low + 1) + 2  # +2 for invalid values outside range
    if spec.valid_values:
        return len(spec.valid_values) + 2
    return None
