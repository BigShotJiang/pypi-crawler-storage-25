"""
TestAxiom CLI — Command-line interface for test case generation.

Usage:
    testaxiom --param "age" --type int --range 18 65
    testaxiom --param "age" --type int --range 18 65 --techniques ep bva --bva-mode 3-value
"""

from __future__ import annotations

import argparse

from testaxiom.core import analyze


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="testaxiom",
        description="TestAxiom — AI-Powered Test Design Engine. "
        "Generate mathematically optimal test cases using ISTQB methodology.",
    )
    parser.add_argument("--param", "-p", required=True, help="Parameter name (e.g., 'age', 'price')")
    parser.add_argument("--type", "-t", default="int", choices=["int", "float", "str", "bool", "enum"],
                        help="Parameter data type (default: int)")
    parser.add_argument("--range", "-r", nargs=2, type=float, metavar=("MIN", "MAX"),
                        help="Valid range for numeric types (e.g., --range 18 65)")
    parser.add_argument("--values", "-v", nargs="+",
                        help="Valid values for enum/str types (e.g., --values red green blue)")
    parser.add_argument("--techniques", nargs="+", default=None,
                        choices=["ep", "bva", "decision_table", "pairwise"],
                        help="Techniques to apply (default: auto-select)")
    parser.add_argument("--bva-mode", default="2-value", choices=["2-value", "3-value"],
                        help="BVA mode (default: 2-value)")
    parser.add_argument("--inclusive", default=True, action=argparse.BooleanOptionalAction,
                        help="Whether boundaries are inclusive (default: True)")
    parser.add_argument("--json", action="store_true", help="Output as JSON")

    args = parser.parse_args()

    valid_range = tuple(args.range) if args.range else None
    if valid_range and args.type == "int":
        valid_range = (int(valid_range[0]), int(valid_range[1]))

    result = analyze(
        parameter=args.param,
        param_type=args.type,
        valid_range=valid_range,
        valid_values=args.values,
        techniques=args.techniques,
        boundary_inclusive=args.inclusive,
        bva_mode=args.bva_mode,
    )

    if args.json:
        import json
        output = {
            "parameter": args.param,
            "type": args.type,
            "techniques": [t.value for t in result.techniques_applied],
            "total_test_cases": result.total_generated,
            "efficiency": result.efficiency_ratio,
            "test_cases": [
                {
                    "id": tc.id,
                    "input": tc.input_value,
                    "expected": tc.expected.value,
                    "technique": tc.technique.value,
                    "rationale": tc.rationale,
                    "partition": tc.partition,
                    "boundary_type": tc.boundary_type,
                }
                for tc in result.test_cases
            ]
        }
        print(json.dumps(output, indent=2, default=str))
    else:
        print(result.summary())


if __name__ == "__main__":
    main()
