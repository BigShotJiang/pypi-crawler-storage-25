"""
Boundary Value Analysis (BVA) Engine

ISTQB Definition: A black-box test design technique in which test cases are
designed based on boundary values. Testing at the boundaries between partitions
catches defects that occur at the edges of valid input ranges.

This engine supports:
- 2-value BVA: boundary + nearest neighbor from adjacent partition
- 3-value BVA: boundary + both neighbors (higher risk coverage)

Mathematical basis: Research by NIST shows that the majority of software
defects are triggered by boundary conditions. BVA focuses testing effort
where defects are statistically most likely to occur.
"""

from __future__ import annotations

from testaxiom.core import ParameterSpec, TestCase, Technique, Verdict


class BVAEngine:
    """Boundary Value Analysis test case generator."""

    def generate(self, spec: ParameterSpec, bva_mode: str = "2-value", **kwargs) -> list[TestCase]:
        """
        Generate test cases using Boundary Value Analysis.

        Args:
            spec: Parameter specification with valid_range.
            bva_mode: "2-value" (boundary + neighbor) or "3-value" (boundary + both neighbors).

        Returns:
            List of test cases targeting boundary values.
        """
        if not spec.valid_range:
            return []

        if spec.param_type not in ("int", "float"):
            return []

        low, high = spec.valid_range
        boundary_values = self._calculate_boundaries(low, high, spec, bva_mode)
        return self._create_test_cases(spec, boundary_values)

    def _calculate_boundaries(
        self,
        low: int | float,
        high: int | float,
        spec: ParameterSpec,
        bva_mode: str,
    ) -> list[dict]:
        """
        Calculate boundary values based on BVA mode.

        2-value BVA produces: min, min-1, max, max+1 (4 values)
        3-value BVA produces: min-1, min, min+1, max-1, max, max+1 (6 values)
        """
        step = 1 if spec.param_type == "int" else 0.01
        boundaries: list[dict] = []

        if bva_mode == "2-value":
            # Lower boundary pair
            boundaries.append({
                "value": low - step,
                "type": "just_below_min",
                "verdict": Verdict.INVALID,
                "description": f"Just below minimum boundary ({low})",
                "rationale": (
                    f"2-value BVA lower boundary: value {low - step} is the nearest "
                    f"neighbor below the minimum valid value {low}. "
                    f"Tests that the system correctly rejects values outside the lower boundary."
                ),
            })
            boundaries.append({
                "value": low,
                "type": "at_min",
                "verdict": Verdict.VALID if spec.boundary_inclusive else Verdict.INVALID,
                "description": f"At minimum boundary ({low})",
                "rationale": (
                    f"2-value BVA lower boundary: value {low} is the minimum "
                    f"{'inclusive' if spec.boundary_inclusive else 'exclusive'} boundary. "
                    f"Tests the exact edge of the valid range."
                ),
            })

            # Upper boundary pair
            boundaries.append({
                "value": high,
                "type": "at_max",
                "verdict": Verdict.VALID if spec.boundary_inclusive else Verdict.INVALID,
                "description": f"At maximum boundary ({high})",
                "rationale": (
                    f"2-value BVA upper boundary: value {high} is the maximum "
                    f"{'inclusive' if spec.boundary_inclusive else 'exclusive'} boundary. "
                    f"Tests the exact edge of the valid range."
                ),
            })
            boundaries.append({
                "value": high + step,
                "type": "just_above_max",
                "verdict": Verdict.INVALID,
                "description": f"Just above maximum boundary ({high})",
                "rationale": (
                    f"2-value BVA upper boundary: value {high + step} is the nearest "
                    f"neighbor above the maximum valid value {high}. "
                    f"Tests that the system correctly rejects values outside the upper boundary."
                ),
            })

        elif bva_mode == "3-value":
            # Lower boundary triplet
            boundaries.append({
                "value": low - step,
                "type": "just_below_min",
                "verdict": Verdict.INVALID,
                "description": f"Just below minimum boundary ({low})",
                "rationale": (
                    f"3-value BVA: {low - step} is the invalid neighbor below the minimum "
                    f"boundary {low}. Catches off-by-one errors at the lower edge."
                ),
            })
            boundaries.append({
                "value": low,
                "type": "at_min",
                "verdict": Verdict.VALID if spec.boundary_inclusive else Verdict.INVALID,
                "description": f"At minimum boundary ({low})",
                "rationale": (
                    f"3-value BVA: {low} is the exact lower boundary value. "
                    f"Tests whether the boundary itself is handled correctly."
                ),
            })
            boundaries.append({
                "value": low + step,
                "type": "just_above_min",
                "verdict": Verdict.VALID,
                "description": f"Just above minimum boundary ({low})",
                "rationale": (
                    f"3-value BVA: {low + step} is the valid neighbor just inside the lower "
                    f"boundary. Verifies the transition from invalid to valid at the lower edge."
                ),
            })

            # Upper boundary triplet
            boundaries.append({
                "value": high - step,
                "type": "just_below_max",
                "verdict": Verdict.VALID,
                "description": f"Just below maximum boundary ({high})",
                "rationale": (
                    f"3-value BVA: {high - step} is the valid neighbor just inside the upper "
                    f"boundary. Verifies the transition from valid to invalid at the upper edge."
                ),
            })
            boundaries.append({
                "value": high,
                "type": "at_max",
                "verdict": Verdict.VALID if spec.boundary_inclusive else Verdict.INVALID,
                "description": f"At maximum boundary ({high})",
                "rationale": (
                    f"3-value BVA: {high} is the exact upper boundary value. "
                    f"Tests whether the boundary itself is handled correctly."
                ),
            })
            boundaries.append({
                "value": high + step,
                "type": "just_above_max",
                "verdict": Verdict.INVALID,
                "description": f"Just above maximum boundary ({high})",
                "rationale": (
                    f"3-value BVA: {high + step} is the invalid neighbor above the maximum "
                    f"boundary {high}. Catches off-by-one errors at the upper edge."
                ),
            })

        return boundaries

    def _create_test_cases(
        self, spec: ParameterSpec, boundaries: list[dict]
    ) -> list[TestCase]:
        """Convert boundary values into fully traced TestCase objects."""
        test_cases = []

        for i, bv in enumerate(boundaries, 1):
            tc_id = f"BVA-{spec.name}-{i:03d}"
            test_cases.append(TestCase(
                id=tc_id,
                parameter=spec.name,
                technique=Technique.BVA,
                input_value=bv["value"],
                expected=bv["verdict"],
                description=bv["description"],
                rationale=bv["rationale"],
                boundary_type=bv["type"],
            ))

        return test_cases
