"""
Pairwise (All-Pairs) Testing Engine

ISTQB Definition: A black-box test design technique in which test cases are
designed to execute all possible discrete combinations of each pair of input
parameters.

Mathematical basis: NIST research shows that most software defects are
triggered by single parameters or interactions between exactly two parameters.
Pairwise testing exploits this by ensuring every possible pair is tested at
least once, dramatically reducing the test set size.

Example: 4 parameters with 3 values each = 81 exhaustive combinations.
Pairwise covers all pairs in ~9-12 test cases (88-93% reduction).

Algorithm: Greedy approach — iteratively builds test cases that cover
the maximum number of uncovered pairs.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from testaxiom.core import TestCase, Technique, Verdict


@dataclass
class Parameter:
    """A parameter with its possible values for pairwise testing."""
    name: str
    values: list


class PairwiseEngine:
    """Pairwise (All-Pairs) test case generator using greedy algorithm."""

    def generate(self, parameters: list[Parameter], seed: int = 42, **kwargs) -> list[TestCase]:
        """
        Generate a minimal test set covering all pairwise combinations.

        Args:
            parameters: List of Parameters, each with possible values.
            seed: Random seed for reproducibility (default 42).

        Returns:
            List of test cases covering all pairs.
        """
        if len(parameters) < 2:
            raise ValueError("Pairwise testing requires at least 2 parameters.")

        random.seed(seed)

        # Generate all pairs that need to be covered
        all_pairs = self._generate_all_pairs(parameters)
        uncovered = set(all_pairs)

        # Greedy: build test cases that cover the most uncovered pairs
        test_rows: list[dict[str, object]] = []

        while uncovered:
            best_row = self._find_best_row(parameters, uncovered)
            test_rows.append(best_row)

            # Remove covered pairs
            covered = self._pairs_in_row(parameters, best_row)
            uncovered -= covered

        return self._create_test_cases(parameters, test_rows, len(all_pairs))

    def _generate_all_pairs(self, parameters: list[Parameter]) -> set[tuple]:
        """Generate all (param_i, value_a, param_j, value_b) pairs."""
        pairs = set()
        for i in range(len(parameters)):
            for j in range(i + 1, len(parameters)):
                for val_i in parameters[i].values:
                    for val_j in parameters[j].values:
                        pairs.add((parameters[i].name, val_i, parameters[j].name, val_j))
        return pairs

    def _pairs_in_row(self, parameters: list[Parameter], row: dict) -> set[tuple]:
        """Extract all pairs covered by a single test row."""
        pairs = set()
        param_names = [p.name for p in parameters]
        for i in range(len(param_names)):
            for j in range(i + 1, len(param_names)):
                pi, pj = param_names[i], param_names[j]
                if pi in row and pj in row:
                    pairs.add((pi, row[pi], pj, row[pj]))
        return pairs

    def _find_best_row(
        self, parameters: list[Parameter], uncovered: set[tuple]
    ) -> dict[str, object]:
        """Find the row that covers the most uncovered pairs (greedy)."""
        best_row = None
        best_count = -1

        # Try multiple random candidates and pick the best
        candidates = min(50, max(10, len(uncovered)))
        for _ in range(candidates):
            row = {p.name: random.choice(p.values) for p in parameters}
            covered = self._pairs_in_row(parameters, row) & uncovered
            if len(covered) > best_count:
                best_count = len(covered)
                best_row = row

        return best_row

    def _create_test_cases(
        self,
        parameters: list[Parameter],
        rows: list[dict],
        total_pairs: int,
    ) -> list[TestCase]:
        """Convert pairwise rows into traced TestCase objects."""
        test_cases = []

        # Calculate exhaustive count for efficiency display
        exhaustive = 1
        for p in parameters:
            exhaustive *= len(p.values)

        for i, row in enumerate(rows, 1):
            input_str = ", ".join(f"{k}={v}" for k, v in row.items())

            rationale = (
                f"Pairwise test {i}/{len(rows)}: covers unique parameter pairs "
                f"from {len(parameters)} parameters. "
                f"Exhaustive testing would require {exhaustive} combinations; "
                f"pairwise covers all {total_pairs} pairs in only {len(rows)} tests "
                f"({((1 - len(rows)/exhaustive) * 100):.0f}% reduction)."
            )

            tc_id = f"PW-{i:03d}"
            test_cases.append(TestCase(
                id=tc_id,
                parameter="pairwise",
                technique=Technique.PAIRWISE,
                input_value=row,
                expected=Verdict.VALID,
                description=f"Pairwise combination: {input_str}",
                rationale=rationale,
            ))

        return test_cases
