"""
State Transition Engine — generate test cases for state machine transitions.

Covers all valid transitions (transition coverage) and optionally tests
invalid transitions (negative testing / guard failures).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from testaxiom.core import Technique, TestCase, Verdict


@dataclass
class State:
    """A state in a state machine."""
    name: str
    description: str = ""


@dataclass
class Transition:
    """A valid transition between two states."""
    from_state: str
    trigger: str
    to_state: str
    guard: str = ""  # optional condition that must hold for transition to fire


@dataclass
class InvalidTransition:
    """A trigger that must NOT fire from a given state."""
    from_state: str
    trigger: str
    reason: str = ""  # why this combination is invalid


class StateTransitionEngine:
    """
    State Transition test design engine (PRO tier).

    Generates one test case per valid transition and one per invalid transition.
    Test case IDs:
        ST-V{i:03d}  — valid transitions
        ST-I{i:03d}  — invalid transitions
    """

    def generate(
        self,
        states: list[State],
        transitions: list[Transition],
        initial_state: str,
        invalid_transitions: list[InvalidTransition] | None = None,
    ) -> list[TestCase]:
        """
        Generate test cases covering all transitions in a state machine.

        Args:
            states: All states in the state machine.
            transitions: Valid transitions (from_state, trigger, to_state).
            initial_state: Name of the starting state.
            invalid_transitions: Triggers that must NOT work from specific states.

        Returns:
            list[TestCase] — valid transitions first, then invalid.

        Raises:
            ValueError: If states or transitions lists are empty.
            TierError: If current tier is COMMUNITY.

        Example:
            >>> from testaxiom.engines.state_transition import (
            ...     State, Transition, InvalidTransition, StateTransitionEngine
            ... )
            >>> from testaxiom.licensing import set_tier, Tier
            >>> set_tier(Tier.PRO)
            >>> engine = StateTransitionEngine()
            >>> states = [State("locked"), State("unlocked")]
            >>> transitions = [
            ...     Transition("locked", "insert_coin", "unlocked"),
            ...     Transition("unlocked", "push", "locked"),
            ... ]
            >>> test_cases = engine.generate(states, transitions, "locked")
        """
        if not states:
            raise ValueError("State machine must have at least one state.")
        if not transitions:
            raise ValueError("State machine must have at least one transition.")

        n_states = len(states)
        n_valid = len(transitions)
        n_invalid = len(invalid_transitions) if invalid_transitions else 0
        n_total = n_valid + n_invalid

        test_cases: list[TestCase] = []

        # --- Valid transitions ---
        for i, t in enumerate(transitions, 1):
            guard_note = f" Guard condition: '{t.guard}'." if t.guard else ""
            rationale = (
                f"State Transition test {i}/{n_total}: Valid transition "
                f"'{t.from_state}' → '{t.to_state}' via trigger '{t.trigger}'."
                f"{guard_note} "
                f"State machine has {n_states} state(s) and {n_valid} valid transition(s). "
                f"Transition coverage requires all {n_valid} transitions to be exercised."
            )
            test_cases.append(TestCase(
                id=f"ST-V{i:03d}",
                parameter="state_machine",
                technique=Technique.STATE_TRANSITION,
                input_value={
                    "from": t.from_state,
                    "trigger": t.trigger,
                    "to": t.to_state,
                },
                expected=Verdict.VALID,
                description=(
                    f"From '{t.from_state}': trigger '{t.trigger}' → expect state '{t.to_state}'"
                ),
                rationale=rationale,
            ))

        # --- Invalid transitions ---
        if invalid_transitions:
            for i, it in enumerate(invalid_transitions, 1):
                reason_note = f" Reason: {it.reason}." if it.reason else ""
                rationale = (
                    f"State Transition test {n_valid + i}/{n_total}: Invalid transition — "
                    f"trigger '{it.trigger}' must NOT fire from state '{it.from_state}'."
                    f"{reason_note} "
                    f"Negative testing verifies the system rejects illegal state changes."
                )
                test_cases.append(TestCase(
                    id=f"ST-I{i:03d}",
                    parameter="state_machine",
                    technique=Technique.STATE_TRANSITION,
                    input_value={
                        "from": it.from_state,
                        "trigger": it.trigger,
                        "expected_result": "no transition / error",
                    },
                    expected=Verdict.INVALID,
                    description=(
                        f"From '{it.from_state}': trigger '{it.trigger}' must be rejected"
                    ),
                    rationale=rationale,
                ))

        return test_cases
