"""
Equivalence Partitioning (EP) Engine

ISTQB Definition: A black-box test design technique in which test cases are
designed to execute representatives from equivalence partitions. The principle
is that if one value in a partition passes, all others in that partition will
also pass — and if one fails, all will fail.

This engine:
1. Identifies valid and invalid partitions from the parameter spec.
2. Selects one representative value from each partition.
3. Generates test cases with full traceability.
"""

from __future__ import annotations

from dataclasses import dataclass

from testaxiom.core import ParameterSpec, TestCase, Technique, Verdict


@dataclass
class Partition:
    """An equivalence partition with its representative value."""
    name: str
    description: str
    representative: object
    verdict: Verdict


class EPEngine:
    """Equivalence Partitioning test case generator."""

    def generate(self, spec: ParameterSpec, **kwargs) -> list[TestCase]:
        """
        Generate test cases using Equivalence Partitioning.

        For numeric ranges: creates invalid-below, valid, invalid-above partitions.
        For enums/sets: creates one partition per valid value + invalid values.
        For booleans: creates True and False partitions.
        """
        partitions = self._identify_partitions(spec)
        return self._create_test_cases(spec, partitions)

    def _identify_partitions(self, spec: ParameterSpec) -> list[Partition]:
        """Identify all equivalence partitions for the given parameter."""
        partitions: list[Partition] = []

        if spec.param_type in ("int", "float") and spec.valid_range:
            low, high = spec.valid_range
            partitions.extend(self._numeric_partitions(low, high, spec))
        elif spec.param_type == "bool":
            partitions.extend(self._boolean_partitions(spec))
        elif spec.valid_values:
            partitions.extend(self._enum_partitions(spec))
        elif spec.param_type == "str":
            partitions.extend(self._string_partitions(spec))

        return partitions

    def _numeric_partitions(
        self, low: int | float, high: int | float, spec: ParameterSpec
    ) -> list[Partition]:
        """Create partitions for numeric range: below, valid, above."""
        partitions = []

        # Invalid partition: below minimum
        if spec.param_type == "int":
            below_val = int(low) - 1
        else:
            below_val = low - 0.1
        partitions.append(Partition(
            name="below_minimum",
            description=f"Values below minimum ({low})",
            representative=below_val,
            verdict=Verdict.INVALID,
        ))

        # Valid partition: within range
        if spec.param_type == "int":
            mid = int((low + high) / 2)
        else:
            mid = round((low + high) / 2, 2)
        partitions.append(Partition(
            name="valid_range",
            description=f"Values within valid range ({low}-{high})",
            representative=mid,
            verdict=Verdict.VALID,
        ))

        # Invalid partition: above maximum
        if spec.param_type == "int":
            above_val = int(high) + 1
        else:
            above_val = high + 0.1
        partitions.append(Partition(
            name="above_maximum",
            description=f"Values above maximum ({high})",
            representative=above_val,
            verdict=Verdict.INVALID,
        ))

        return partitions

    def _boolean_partitions(self, spec: ParameterSpec) -> list[Partition]:
        """Create partitions for boolean: True and False."""
        return [
            Partition(
                name="true_value",
                description=f"{spec.name} = True",
                representative=True,
                verdict=Verdict.VALID,
            ),
            Partition(
                name="false_value",
                description=f"{spec.name} = False",
                representative=False,
                verdict=Verdict.VALID,
            ),
        ]

    def _enum_partitions(self, spec: ParameterSpec) -> list[Partition]:
        """Create partitions for enumerated values."""
        partitions = []

        # One partition per valid value
        for val in spec.valid_values:
            partitions.append(Partition(
                name=f"valid_{val}",
                description=f"Valid value: {val}",
                representative=val,
                verdict=Verdict.VALID,
            ))

        # Invalid partition: value not in set
        partitions.append(Partition(
            name="invalid_not_in_set",
            description="Value not in the valid set",
            representative="__INVALID__",
            verdict=Verdict.INVALID,
        ))

        return partitions

    def _string_partitions(self, spec: ParameterSpec) -> list[Partition]:
        """Create partitions for string inputs (general)."""
        partitions = [
            Partition(
                name="empty_string",
                description="Empty string input",
                representative="",
                verdict=Verdict.INVALID,
            ),
            Partition(
                name="valid_string",
                description="Valid non-empty string",
                representative="validInput",
                verdict=Verdict.VALID,
            ),
        ]

        if spec.valid_range:
            # valid_range for strings = (min_length, max_length)
            min_len, max_len = spec.valid_range
            partitions.append(Partition(
                name="too_short",
                description=f"String shorter than minimum length ({min_len})",
                representative="x" * max(0, int(min_len) - 1),
                verdict=Verdict.INVALID,
            ))
            partitions.append(Partition(
                name="too_long",
                description=f"String longer than maximum length ({max_len})",
                representative="x" * (int(max_len) + 1),
                verdict=Verdict.INVALID,
            ))

        return partitions

    def _create_test_cases(
        self, spec: ParameterSpec, partitions: list[Partition]
    ) -> list[TestCase]:
        """Convert partitions into fully traced TestCase objects."""
        test_cases = []

        for i, partition in enumerate(partitions, 1):
            tc_id = f"EP-{spec.name}-{i:03d}"
            test_cases.append(TestCase(
                id=tc_id,
                parameter=spec.name,
                technique=Technique.EP,
                input_value=partition.representative,
                expected=partition.verdict,
                description=partition.description,
                rationale=(
                    f"Equivalence Partitioning: partition '{partition.name}' — "
                    f"one representative value tests the entire partition. "
                    f"If {partition.representative} {'passes' if partition.verdict == Verdict.VALID else 'fails'}, "
                    f"all values in this partition are expected to behave identically."
                ),
                partition=partition.name,
            ))

        return test_cases
