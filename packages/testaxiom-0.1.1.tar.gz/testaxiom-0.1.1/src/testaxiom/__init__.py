"""
TestAxiom — AI-Powered Test Design Engine

From requirements to mathematically optimal test cases
using ISTQB methodology (EP, BVA, Decision Tables, Pairwise).

Community (Free):
    >>> from testaxiom import analyze
    >>> result = analyze("age", param_type="int", valid_range=(18, 65))
    >>> print(result.summary())

Pro (Decision Tables, Pairwise, CSV export):
    >>> from testaxiom.licensing import set_tier, Tier
    >>> set_tier(Tier.PRO)
    >>> from testaxiom.engines.pairwise import PairwiseEngine, Parameter
"""

__version__ = "0.1.0"
__author__ = "Yaniv (Yaniv2809)"

from testaxiom.core import analyze, ParameterSpec, TestCase, AnalysisResult
from testaxiom.core import Technique, Verdict
from testaxiom.engines.equivalence_partitioning import EPEngine
from testaxiom.engines.boundary_value import BVAEngine
from testaxiom.licensing import Tier, get_tier, set_tier, TierError

__all__ = [
    "analyze", "ParameterSpec", "TestCase", "AnalysisResult",
    "Technique", "Verdict",
    "EPEngine", "BVAEngine",
    "Tier", "get_tier", "set_tier", "TierError",
]
