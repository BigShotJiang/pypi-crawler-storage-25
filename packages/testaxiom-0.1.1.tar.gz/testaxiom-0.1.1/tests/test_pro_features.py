"""
Tests for advanced features: Decision Table, Pairwise, Exporters, pytest integration.
"""

import json
import pytest
from testaxiom import analyze, Tier, set_tier, get_tier
from testaxiom.core import Technique
from testaxiom.engines.decision_table import DecisionTableEngine, Condition, Action, Rule
from testaxiom.engines.pairwise import PairwiseEngine, Parameter
from testaxiom.licensing import list_features
from testaxiom import exporters


# ═══════════════════════════════════════
# Licensing module (infrastructure tests)
# ═══════════════════════════════════════

class TestLicensing:
    """The licensing module still exists as infrastructure; test it works."""

    def setup_method(self):
        set_tier(Tier.COMMUNITY)

    def test_default_tier_is_community(self):
        assert get_tier() == Tier.COMMUNITY

    def test_set_tier_with_string(self):
        set_tier("pro")
        assert get_tier() == Tier.PRO

    def test_set_tier_with_enum(self):
        set_tier(Tier.ENTERPRISE)
        assert get_tier() == Tier.ENTERPRISE

    def test_all_engines_available_on_community(self):
        """All engines work on community tier — no gating."""
        engine = PairwiseEngine()
        params = [
            Parameter("browser", ["Chrome", "Firefox"]),
            Parameter("os", ["Windows", "Mac"]),
        ]
        cases = engine.generate(params)
        assert len(cases) > 0

    def test_list_features_returns_dict(self):
        features = list_features()
        assert "ep_engine" in features
        assert "pairwise_engine" in features


# ═══════════════════════════════════════
# Decision Table Engine Tests
# ═══════════════════════════════════════

class TestDecisionTableEngine:

    def test_two_conditions_generates_four_rules(self):
        """2 boolean conditions → 2^2 = 4 rules."""
        engine = DecisionTableEngine()
        conditions = [Condition("logged_in"), Condition("is_admin")]
        actions = [Action("show_admin_panel")]
        cases = engine.generate(conditions, actions)
        assert len(cases) == 4

    def test_three_conditions_generates_eight_rules(self):
        """3 boolean conditions → 2^3 = 8 rules."""
        engine = DecisionTableEngine()
        conditions = [
            Condition("logged_in"),
            Condition("is_admin"),
            Condition("has_2fa"),
        ]
        actions = [Action("grant_access")]
        cases = engine.generate(conditions, actions)
        assert len(cases) == 8

    def test_all_cases_have_technique_dt(self):
        engine = DecisionTableEngine()
        conditions = [Condition("a"), Condition("b")]
        actions = [Action("x")]
        cases = engine.generate(conditions, actions)
        for tc in cases:
            assert tc.technique == Technique.DECISION_TABLE

    def test_custom_rules(self):
        """Should use pre-defined rules when provided."""
        engine = DecisionTableEngine()
        conditions = [Condition("age_valid"), Condition("has_id")]
        actions = [Action("allow_entry")]
        custom_rules = [
            Rule(1, {"age_valid": True, "has_id": True}, {"allow_entry": True}),
            Rule(2, {"age_valid": False, "has_id": True}, {"allow_entry": False}),
        ]
        cases = engine.generate(conditions, actions, rules=custom_rules)
        assert len(cases) == 2

    def test_custom_action_resolver(self):
        """Action resolver function should determine outcomes."""
        engine = DecisionTableEngine()
        conditions = [Condition("premium"), Condition("verified")]
        actions = [Action("access")]

        def resolver(conds):
            return {"access": conds["premium"] or conds["verified"]}

        rules = engine.generate_full_table(conditions, actions, action_resolver=resolver)
        access_values = [r.actions["access"] for r in rules]
        assert access_values.count(True) == 3
        assert access_values.count(False) == 1


# ═══════════════════════════════════════
# Pairwise Engine Tests
# ═══════════════════════════════════════

class TestPairwiseEngine:

    def test_two_params_two_values_covers_all_pairs(self):
        """2 params × 2 values = 4 pairs, should be covered in ~4 tests."""
        engine = PairwiseEngine()
        params = [
            Parameter("browser", ["Chrome", "Firefox"]),
            Parameter("os", ["Windows", "Mac"]),
        ]
        cases = engine.generate(params)
        assert len(cases) >= 2
        assert len(cases) <= 4

    def test_three_params_three_values_reduces(self):
        """3 params × 3 values = 27 exhaustive. Pairwise should produce fewer."""
        engine = PairwiseEngine()
        params = [
            Parameter("browser", ["Chrome", "Firefox", "Safari"]),
            Parameter("os", ["Windows", "Mac", "Linux"]),
            Parameter("lang", ["en", "he", "ar"]),
        ]
        cases = engine.generate(params)
        assert len(cases) < 27
        assert len(cases) >= 9

    def test_all_pairs_covered(self):
        """Verify that every pair of values appears in at least one test case."""
        engine = PairwiseEngine()
        params = [
            Parameter("a", [1, 2, 3]),
            Parameter("b", ["x", "y", "z"]),
            Parameter("c", [True, False]),
        ]
        cases = engine.generate(params)

        covered_pairs = set()
        param_names = [p.name for p in params]
        for tc in cases:
            row = tc.input_value
            for i in range(len(param_names)):
                for j in range(i + 1, len(param_names)):
                    pi, pj = param_names[i], param_names[j]
                    covered_pairs.add((pi, row[pi], pj, row[pj]))

        expected_pairs = set()
        for i in range(len(params)):
            for j in range(i + 1, len(params)):
                for vi in params[i].values:
                    for vj in params[j].values:
                        expected_pairs.add((params[i].name, vi, params[j].name, vj))

        assert expected_pairs.issubset(covered_pairs)

    def test_reproducible_with_seed(self):
        engine = PairwiseEngine()
        params = [
            Parameter("a", [1, 2, 3]),
            Parameter("b", ["x", "y"]),
        ]
        cases1 = engine.generate(params, seed=42)
        cases2 = engine.generate(params, seed=42)
        assert len(cases1) == len(cases2)
        for c1, c2 in zip(cases1, cases2):
            assert c1.input_value == c2.input_value

    def test_requires_at_least_two_params(self):
        engine = PairwiseEngine()
        with pytest.raises(ValueError, match="at least 2"):
            engine.generate([Parameter("solo", [1, 2])])

    def test_all_cases_have_rationale(self):
        engine = PairwiseEngine()
        params = [
            Parameter("x", [1, 2]),
            Parameter("y", ["a", "b"]),
        ]
        cases = engine.generate(params)
        for tc in cases:
            assert tc.rationale
            assert "reduction" in tc.rationale


# ═══════════════════════════════════════
# Exporter Tests
# ═══════════════════════════════════════

class TestExporters:

    def test_json_export(self):
        result = analyze("age", param_type="int", valid_range=(18, 65))
        output = exporters.to_json(result)
        parsed = json.loads(output)
        assert parsed["parameter"]["name"] == "age"
        assert len(parsed["test_cases"]) == 7

    def test_markdown_export(self):
        result = analyze("age", param_type="int", valid_range=(18, 65))
        md = exporters.to_markdown(result)
        assert "# TestAxiom Analysis: age" in md
        assert "| ID |" in md
        assert "EP-age-001" in md

    def test_csv_export(self):
        result = analyze("age", param_type="int", valid_range=(18, 65))
        csv_output = exporters.to_csv(result)
        assert "Test Case ID" in csv_output
        assert "EP-age-001" in csv_output

    def test_traceability_matrix(self):
        r1 = analyze("age", param_type="int", valid_range=(18, 65))
        r2 = analyze("email", param_type="str", valid_values=["a@b.com", "x@y.org"])
        matrix = exporters.to_traceability_matrix(
            [r1, r2],
            requirements=["REQ-AUTH-001", "REQ-AUTH-002"]
        )
        assert "# Traceability Matrix" in matrix
        assert "REQ-AUTH-001" in matrix
        assert "REQ-AUTH-002" in matrix


# ═══════════════════════════════════════
# pytest Integration Tests
# ═══════════════════════════════════════

class TestPytestParams:

    def test_returns_list(self):
        result = analyze("age", param_type="int", valid_range=(18, 65))
        params = exporters.to_pytest_params(result)
        assert isinstance(params, list)

    def test_length_matches_test_cases(self):
        result = analyze("age", param_type="int", valid_range=(18, 65))
        params = exporters.to_pytest_params(result)
        assert len(params) == result.total_generated

    def test_each_param_has_pytest_id(self):
        result = analyze("age", param_type="int", valid_range=(18, 65))
        params = exporters.to_pytest_params(result)
        ids = [p.id for p in params]
        assert "EP-age-001" in ids
        assert "BVA-age-001" in ids

    def test_each_param_values_match_test_case(self):
        result = analyze("age", param_type="int", valid_range=(18, 65))
        params = exporters.to_pytest_params(result)
        first_tc = result.test_cases[0]
        first_param = params[0]
        assert first_param.values[0] == first_tc.input_value
        assert first_param.values[1] == first_tc.expected.value

    def test_expected_verdict_is_string(self):
        """Expected verdict should be 'valid' or 'invalid' string."""
        result = analyze("age", param_type="int", valid_range=(18, 65))
        params = exporters.to_pytest_params(result)
        for p in params:
            assert p.values[1] in ("valid", "invalid")

    def test_usable_in_parametrize(self):
        """Smoke test: to_pytest_params output can be used with parametrize."""
        result = analyze("age", param_type="int", valid_range=(18, 65))
        params = exporters.to_pytest_params(result)

        collected_inputs = []
        for p in params:
            input_val, expected = p.values[0], p.values[1]
            collected_inputs.append((input_val, expected))

        assert len(collected_inputs) == result.total_generated
