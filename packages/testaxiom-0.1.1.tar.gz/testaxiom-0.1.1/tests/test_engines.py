"""
Tests for TestAxiom — validating the test design engines themselves.

Meta-testing: we use pytest to test the tool that generates test cases.
"""

from testaxiom import analyze, ParameterSpec
from testaxiom.core import Technique, Verdict
from testaxiom.engines.equivalence_partitioning import EPEngine
from testaxiom.engines.boundary_value import BVAEngine


# ═══════════════════════════════════════
# Equivalence Partitioning Tests
# ═══════════════════════════════════════

class TestEPEngineNumeric:
    """Test EP engine with numeric range parameters."""

    def test_integer_range_creates_three_partitions(self):
        """EP on int range should produce: below_min, valid, above_max."""
        spec = ParameterSpec(name="age", param_type="int", valid_range=(18, 65))
        engine = EPEngine()
        cases = engine.generate(spec)

        assert len(cases) == 3
        verdicts = [tc.expected for tc in cases]
        assert verdicts == [Verdict.INVALID, Verdict.VALID, Verdict.INVALID]

    def test_integer_range_representative_values(self):
        """EP should pick midpoint for valid, min-1 and max+1 for invalid."""
        spec = ParameterSpec(name="age", param_type="int", valid_range=(18, 65))
        engine = EPEngine()
        cases = engine.generate(spec)

        assert cases[0].input_value == 17   # below min
        assert cases[1].input_value == 41   # midpoint (18+65)/2 = 41
        assert cases[2].input_value == 66   # above max

    def test_all_cases_have_technique_ep(self):
        """Every generated test case should be tagged with EP technique."""
        spec = ParameterSpec(name="score", param_type="int", valid_range=(0, 100))
        engine = EPEngine()
        cases = engine.generate(spec)

        for tc in cases:
            assert tc.technique == Technique.EP

    def test_all_cases_have_rationale(self):
        """Every test case must include a non-empty rationale."""
        spec = ParameterSpec(name="qty", param_type="int", valid_range=(1, 10))
        engine = EPEngine()
        cases = engine.generate(spec)

        for tc in cases:
            assert tc.rationale
            assert len(tc.rationale) > 20

    def test_all_cases_have_unique_ids(self):
        """Test case IDs must be unique."""
        spec = ParameterSpec(name="temp", param_type="int", valid_range=(-40, 120))
        engine = EPEngine()
        cases = engine.generate(spec)

        ids = [tc.id for tc in cases]
        assert len(ids) == len(set(ids))

    def test_partition_names_are_set(self):
        """Each test case should have a partition name."""
        spec = ParameterSpec(name="age", param_type="int", valid_range=(18, 65))
        engine = EPEngine()
        cases = engine.generate(spec)

        partitions = [tc.partition for tc in cases]
        assert "below_minimum" in partitions
        assert "valid_range" in partitions
        assert "above_maximum" in partitions


class TestEPEngineBoolean:
    """Test EP engine with boolean parameters."""

    def test_boolean_creates_two_partitions(self):
        """Boolean EP should produce True and False partitions."""
        spec = ParameterSpec(name="is_active", param_type="bool")
        engine = EPEngine()
        cases = engine.generate(spec)

        assert len(cases) == 2
        values = {tc.input_value for tc in cases}
        assert values == {True, False}

    def test_boolean_both_valid(self):
        """Both True and False are valid values for boolean."""
        spec = ParameterSpec(name="is_active", param_type="bool")
        engine = EPEngine()
        cases = engine.generate(spec)

        for tc in cases:
            assert tc.expected == Verdict.VALID


class TestEPEngineEnum:
    """Test EP engine with enumerated values."""

    def test_enum_creates_partition_per_value_plus_invalid(self):
        """Enum EP should create one partition per valid value + one invalid."""
        spec = ParameterSpec(
            name="color", param_type="enum",
            valid_values=["red", "green", "blue"]
        )
        engine = EPEngine()
        cases = engine.generate(spec)

        assert len(cases) == 4  # 3 valid + 1 invalid
        valid_cases = [tc for tc in cases if tc.expected == Verdict.VALID]
        invalid_cases = [tc for tc in cases if tc.expected == Verdict.INVALID]
        assert len(valid_cases) == 3
        assert len(invalid_cases) == 1


# ═══════════════════════════════════════
# Boundary Value Analysis Tests
# ═══════════════════════════════════════

class TestBVAEngine:
    """Test BVA engine with numeric parameters."""

    def test_2value_bva_generates_four_cases(self):
        """2-value BVA should produce 4 boundary test cases."""
        spec = ParameterSpec(name="age", param_type="int", valid_range=(18, 65))
        engine = BVAEngine()
        cases = engine.generate(spec, bva_mode="2-value")

        assert len(cases) == 4

    def test_2value_bva_correct_values(self):
        """2-value BVA for int range (18,65) → 17, 18, 65, 66."""
        spec = ParameterSpec(name="age", param_type="int", valid_range=(18, 65))
        engine = BVAEngine()
        cases = engine.generate(spec, bva_mode="2-value")

        values = [tc.input_value for tc in cases]
        assert values == [17, 18, 65, 66]

    def test_2value_bva_correct_verdicts(self):
        """2-value BVA verdicts: invalid, valid, valid, invalid (inclusive)."""
        spec = ParameterSpec(name="age", param_type="int", valid_range=(18, 65))
        engine = BVAEngine()
        cases = engine.generate(spec, bva_mode="2-value")

        verdicts = [tc.expected for tc in cases]
        assert verdicts == [Verdict.INVALID, Verdict.VALID, Verdict.VALID, Verdict.INVALID]

    def test_3value_bva_generates_six_cases(self):
        """3-value BVA should produce 6 boundary test cases."""
        spec = ParameterSpec(name="age", param_type="int", valid_range=(18, 65))
        engine = BVAEngine()
        cases = engine.generate(spec, bva_mode="3-value")

        assert len(cases) == 6

    def test_3value_bva_correct_values(self):
        """3-value BVA for int range (18,65) → 17, 18, 19, 64, 65, 66."""
        spec = ParameterSpec(name="age", param_type="int", valid_range=(18, 65))
        engine = BVAEngine()
        cases = engine.generate(spec, bva_mode="3-value")

        values = [tc.input_value for tc in cases]
        assert values == [17, 18, 19, 64, 65, 66]

    def test_3value_bva_correct_verdicts(self):
        """3-value BVA verdicts: invalid, valid, valid, valid, valid, invalid."""
        spec = ParameterSpec(name="age", param_type="int", valid_range=(18, 65))
        engine = BVAEngine()
        cases = engine.generate(spec, bva_mode="3-value")

        verdicts = [tc.expected for tc in cases]
        assert verdicts == [
            Verdict.INVALID, Verdict.VALID, Verdict.VALID,
            Verdict.VALID, Verdict.VALID, Verdict.INVALID
        ]

    def test_bva_all_cases_have_boundary_type(self):
        """Every BVA test case must have a boundary_type."""
        spec = ParameterSpec(name="price", param_type="float", valid_range=(0.01, 999.99))
        engine = BVAEngine()
        cases = engine.generate(spec, bva_mode="2-value")

        for tc in cases:
            assert tc.boundary_type is not None

    def test_bva_returns_empty_without_range(self):
        """BVA should return empty list if no valid_range is specified."""
        spec = ParameterSpec(name="name", param_type="str")
        engine = BVAEngine()
        cases = engine.generate(spec)

        assert cases == []

    def test_bva_exclusive_boundaries(self):
        """When boundaries are exclusive, boundary values should be invalid."""
        spec = ParameterSpec(
            name="age", param_type="int", valid_range=(18, 65),
            boundary_inclusive=False
        )
        engine = BVAEngine()
        cases = engine.generate(spec, bva_mode="2-value")

        at_min = next(tc for tc in cases if tc.boundary_type == "at_min")
        at_max = next(tc for tc in cases if tc.boundary_type == "at_max")
        assert at_min.expected == Verdict.INVALID
        assert at_max.expected == Verdict.INVALID


# ═══════════════════════════════════════
# Integration: analyze() function
# ═══════════════════════════════════════

class TestAnalyzeFunction:
    """Test the main analyze() orchestration function."""

    def test_auto_selects_ep_and_bva_for_numeric(self):
        """For numeric range, auto-selection should pick EP + BVA."""
        result = analyze("age", param_type="int", valid_range=(18, 65))

        assert Technique.EP in result.techniques_applied
        assert Technique.BVA in result.techniques_applied

    def test_total_cases_ep_plus_bva(self):
        """EP (3) + BVA 2-value (4) = 7 test cases for numeric range."""
        result = analyze("age", param_type="int", valid_range=(18, 65))

        assert result.total_generated == 7

    def test_accepts_parameter_spec_object(self):
        """analyze() should accept a ParameterSpec directly."""
        spec = ParameterSpec(name="score", param_type="int", valid_range=(0, 100))
        result = analyze(spec)

        assert result.total_generated > 0
        assert result.parameter.name == "score"

    def test_explicit_technique_selection(self):
        """Should only run specified techniques."""
        result = analyze("age", param_type="int", valid_range=(18, 65), techniques=["ep"])

        assert result.techniques_applied == [Technique.EP]
        assert result.total_generated == 3

    def test_efficiency_ratio_calculated(self):
        """Should calculate efficiency ratio vs exhaustive testing."""
        result = analyze("age", param_type="int", valid_range=(18, 65))

        assert result.efficiency_ratio
        assert "reduction" in result.efficiency_ratio

    def test_summary_output(self):
        """summary() should produce readable formatted output."""
        result = analyze("age", param_type="int", valid_range=(18, 65))
        summary = result.summary()

        assert "TestAxiom Analysis: age" in summary
        assert "EP" in summary
        assert "BVA" in summary

    def test_coverage_summary_present(self):
        """coverage_summary should describe valid/invalid counts."""
        result = analyze("age", param_type="int", valid_range=(18, 65))

        assert "valid" in result.coverage_summary
        assert "invalid" in result.coverage_summary

    def test_3value_bva_mode(self):
        """3-value BVA should produce more cases than 2-value."""
        result_2 = analyze("age", param_type="int", valid_range=(18, 65), bva_mode="2-value")
        result_3 = analyze("age", param_type="int", valid_range=(18, 65), bva_mode="3-value")

        assert result_3.total_generated > result_2.total_generated

    def test_boolean_auto_selects_ep_only(self):
        """Boolean parameters should auto-select EP only (no BVA)."""
        result = analyze("is_active", param_type="bool")

        assert Technique.EP in result.techniques_applied
        assert Technique.BVA not in result.techniques_applied
        assert result.total_generated == 2
