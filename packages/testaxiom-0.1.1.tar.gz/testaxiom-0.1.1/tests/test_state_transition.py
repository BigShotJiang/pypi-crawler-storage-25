"""
Tests for the State Transition Engine.
"""

from __future__ import annotations

import pytest

from testaxiom.core import Technique, Verdict
from testaxiom.engines.state_transition import (
    InvalidTransition,
    State,
    StateTransitionEngine,
    Transition,
)


# ---------------------------------------------------------------------------
# Fixtures — a simple turnstile state machine
# ---------------------------------------------------------------------------

@pytest.fixture
def turnstile_states():
    return [State("locked", "Initial state"), State("unlocked", "Coin inserted")]


@pytest.fixture
def turnstile_transitions():
    return [
        Transition("locked", "insert_coin", "unlocked"),
        Transition("unlocked", "push", "locked"),
        Transition("unlocked", "insert_coin", "unlocked"),  # coin while unlocked
        Transition("locked", "push", "locked"),             # push while locked (no-op)
    ]


@pytest.fixture
def turnstile_invalid():
    return [
        InvalidTransition("locked", "eject", "eject only valid when unlocked"),
    ]


@pytest.fixture
def engine():
    return StateTransitionEngine()


# ---------------------------------------------------------------------------
# Valid transitions
# ---------------------------------------------------------------------------

class TestValidTransitions:

    def test_one_case_per_transition(self, engine, turnstile_states, turnstile_transitions):
        test_cases = engine.generate(turnstile_states, turnstile_transitions, "locked")
        valid_cases = [tc for tc in test_cases if tc.expected == Verdict.VALID]
        assert len(valid_cases) == len(turnstile_transitions)

    def test_id_prefix_ST_V(self, engine, turnstile_states, turnstile_transitions):
        test_cases = engine.generate(turnstile_states, turnstile_transitions, "locked")
        valid_ids = [tc.id for tc in test_cases if tc.expected == Verdict.VALID]
        assert all(tc_id.startswith("ST-V") for tc_id in valid_ids)

    def test_ids_are_sequential(self, engine, turnstile_states, turnstile_transitions):
        test_cases = engine.generate(turnstile_states, turnstile_transitions, "locked")
        valid_ids = [tc.id for tc in test_cases if tc.expected == Verdict.VALID]
        assert valid_ids == ["ST-V001", "ST-V002", "ST-V003", "ST-V004"]

    def test_technique_is_state_transition(self, engine, turnstile_states, turnstile_transitions):
        test_cases = engine.generate(turnstile_states, turnstile_transitions, "locked")
        assert all(tc.technique == Technique.STATE_TRANSITION for tc in test_cases)

    def test_parameter_is_state_machine(self, engine, turnstile_states, turnstile_transitions):
        test_cases = engine.generate(turnstile_states, turnstile_transitions, "locked")
        assert all(tc.parameter == "state_machine" for tc in test_cases)

    def test_input_value_contains_from_trigger_to(self, engine, turnstile_states, turnstile_transitions):
        test_cases = engine.generate(turnstile_states, turnstile_transitions, "locked")
        first = test_cases[0]
        assert first.input_value["from"] == "locked"
        assert first.input_value["trigger"] == "insert_coin"
        assert first.input_value["to"] == "unlocked"

    def test_rationale_mentions_transition_and_state_count(
        self, engine, turnstile_states, turnstile_transitions
    ):
        test_cases = engine.generate(turnstile_states, turnstile_transitions, "locked")
        rationale = test_cases[0].rationale
        assert "locked" in rationale
        assert "insert_coin" in rationale
        assert "2 state" in rationale
        assert "4 valid transition" in rationale

    def test_guard_appears_in_rationale(self, engine):
        states = [State("idle"), State("running")]
        transitions = [Transition("idle", "start", "running", guard="fuel > 0")]
        test_cases = engine.generate(states, transitions, "idle")
        assert "fuel > 0" in test_cases[0].rationale

    def test_no_guard_no_guard_note_in_rationale(self, engine, turnstile_states, turnstile_transitions):
        test_cases = engine.generate(turnstile_states, turnstile_transitions, "locked")
        assert "Guard condition" not in test_cases[0].rationale


# ---------------------------------------------------------------------------
# Invalid transitions
# ---------------------------------------------------------------------------

class TestInvalidTransitions:

    def test_one_case_per_invalid_transition(
        self, engine, turnstile_states, turnstile_transitions, turnstile_invalid
    ):
        test_cases = engine.generate(
            turnstile_states, turnstile_transitions, "locked",
            invalid_transitions=turnstile_invalid,
        )
        invalid_cases = [tc for tc in test_cases if tc.expected == Verdict.INVALID]
        assert len(invalid_cases) == 1

    def test_id_prefix_ST_I(
        self, engine, turnstile_states, turnstile_transitions, turnstile_invalid
    ):
        test_cases = engine.generate(
            turnstile_states, turnstile_transitions, "locked",
            invalid_transitions=turnstile_invalid,
        )
        invalid_cases = [tc for tc in test_cases if tc.expected == Verdict.INVALID]
        assert invalid_cases[0].id == "ST-I001"

    def test_valid_cases_come_before_invalid(
        self, engine, turnstile_states, turnstile_transitions, turnstile_invalid
    ):
        test_cases = engine.generate(
            turnstile_states, turnstile_transitions, "locked",
            invalid_transitions=turnstile_invalid,
        )
        verdicts = [tc.expected for tc in test_cases]
        last_valid = max(i for i, v in enumerate(verdicts) if v == Verdict.VALID)
        first_invalid = min(i for i, v in enumerate(verdicts) if v == Verdict.INVALID)
        assert last_valid < first_invalid

    def test_invalid_input_value_structure(
        self, engine, turnstile_states, turnstile_transitions, turnstile_invalid
    ):
        test_cases = engine.generate(
            turnstile_states, turnstile_transitions, "locked",
            invalid_transitions=turnstile_invalid,
        )
        inv = next(tc for tc in test_cases if tc.expected == Verdict.INVALID)
        assert inv.input_value["from"] == "locked"
        assert inv.input_value["trigger"] == "eject"
        assert "no transition" in inv.input_value["expected_result"]

    def test_reason_appears_in_rationale(
        self, engine, turnstile_states, turnstile_transitions, turnstile_invalid
    ):
        test_cases = engine.generate(
            turnstile_states, turnstile_transitions, "locked",
            invalid_transitions=turnstile_invalid,
        )
        inv = next(tc for tc in test_cases if tc.expected == Verdict.INVALID)
        assert "eject only valid when unlocked" in inv.rationale

    def test_multiple_invalid_transitions(self, engine, turnstile_states, turnstile_transitions):
        invalid = [
            InvalidTransition("locked", "eject"),
            InvalidTransition("locked", "force_open"),
        ]
        test_cases = engine.generate(
            turnstile_states, turnstile_transitions, "locked",
            invalid_transitions=invalid,
        )
        invalid_ids = [tc.id for tc in test_cases if tc.expected == Verdict.INVALID]
        assert invalid_ids == ["ST-I001", "ST-I002"]

    def test_no_invalid_transitions_by_default(
        self, engine, turnstile_states, turnstile_transitions
    ):
        test_cases = engine.generate(turnstile_states, turnstile_transitions, "locked")
        assert all(tc.expected == Verdict.VALID for tc in test_cases)


# ---------------------------------------------------------------------------
# Edge cases and validation
# ---------------------------------------------------------------------------

class TestEdgeCases:

    def test_empty_states_raises_value_error(self, engine):
        with pytest.raises(ValueError, match="at least one state"):
            engine.generate([], [Transition("a", "t", "b")], "a")

    def test_empty_transitions_raises_value_error(self, engine):
        with pytest.raises(ValueError, match="at least one transition"):
            engine.generate([State("a")], [], "a")

    def test_single_self_loop_transition(self, engine):
        states = [State("idle")]
        transitions = [Transition("idle", "tick", "idle")]
        test_cases = engine.generate(states, transitions, "idle")
        assert len(test_cases) == 1
        assert test_cases[0].input_value["from"] == "idle"
        assert test_cases[0].input_value["to"] == "idle"

    def test_total_count_valid_plus_invalid(self, engine, turnstile_states, turnstile_transitions):
        invalid = [InvalidTransition("locked", "eject"), InvalidTransition("unlocked", "eject")]
        test_cases = engine.generate(
            turnstile_states, turnstile_transitions, "locked",
            invalid_transitions=invalid,
        )
        assert len(test_cases) == len(turnstile_transitions) + 2

    def test_rationale_total_count_reflects_invalid(self, engine, turnstile_states, turnstile_transitions):
        invalid = [InvalidTransition("locked", "eject")]
        test_cases = engine.generate(
            turnstile_states, turnstile_transitions, "locked",
            invalid_transitions=invalid,
        )
        # Last test case (invalid) should reference total = 4 valid + 1 invalid = 5
        last = test_cases[-1]
        assert "5/5" in last.rationale
