"""
Tests for the AI Requirement Parser.

All tests mock the Anthropic client to avoid real API calls.
"""

from __future__ import annotations

import sys
from unittest.mock import MagicMock

import pytest


# ---------------------------------------------------------------------------
# Helpers — build a fake Anthropic response
# ---------------------------------------------------------------------------

def _make_tool_response(parameters: list[dict]) -> MagicMock:
    """Return a mock Anthropic Messages response with tool_use content."""
    tool_block = MagicMock()
    tool_block.type = "tool_use"
    tool_block.input = {"parameters": parameters}

    response = MagicMock()
    response.content = [tool_block]
    return response


def _fake_client(parameters: list[dict]) -> MagicMock:
    """Return a mock Anthropic client whose messages.create returns the given params."""
    client = MagicMock()
    client.messages.create.return_value = _make_tool_response(parameters)
    return client


# ---------------------------------------------------------------------------
# parse_requirements — correct ParameterSpec construction
# ---------------------------------------------------------------------------

class TestParseRequirements:

    def test_single_int_range(self):
        from testaxiom.parsers import parse_requirements
        client = _fake_client([{
            "name": "age",
            "param_type": "int",
            "valid_range": [18, 65],
            "valid_values": None,
            "constraints": [],
            "boundary_inclusive": True,
        }])
        specs = parse_requirements("User age must be between 18 and 65", client=client)

        assert len(specs) == 1
        spec = specs[0]
        assert spec.name == "age"
        assert spec.param_type == "int"
        assert spec.valid_range == (18, 65)
        assert spec.valid_values is None
        assert spec.constraints == []
        assert spec.boundary_inclusive is True

    def test_float_range(self):
        from testaxiom.parsers import parse_requirements
        client = _fake_client([{
            "name": "weight",
            "param_type": "float",
            "valid_range": [0.5, 300.0],
            "valid_values": None,
            "constraints": [],
            "boundary_inclusive": True,
        }])
        specs = parse_requirements("Weight must be 0.5–300.0 kg", client=client)

        spec = specs[0]
        assert spec.param_type == "float"
        assert spec.valid_range == (0.5, 300.0)

    def test_enum_values(self):
        from testaxiom.parsers import parse_requirements
        client = _fake_client([{
            "name": "status",
            "param_type": "enum",
            "valid_range": None,
            "valid_values": ["active", "inactive", "pending"],
            "constraints": [],
            "boundary_inclusive": True,
        }])
        specs = parse_requirements("Status must be active, inactive, or pending", client=client)

        spec = specs[0]
        assert spec.param_type == "enum"
        assert spec.valid_values == ["active", "inactive", "pending"]
        assert spec.valid_range is None

    def test_constraints_preserved(self):
        from testaxiom.parsers import parse_requirements
        client = _fake_client([{
            "name": "amount",
            "param_type": "int",
            "valid_range": [0, 10000],
            "valid_values": None,
            "constraints": ["must be divisible by 100"],
            "boundary_inclusive": True,
        }])
        specs = parse_requirements("Amount 0-10000, divisible by 100", client=client)

        assert specs[0].constraints == ["must be divisible by 100"]

    def test_boundary_exclusive(self):
        from testaxiom.parsers import parse_requirements
        client = _fake_client([{
            "name": "score",
            "param_type": "float",
            "valid_range": [0.0, 1.0],
            "valid_values": None,
            "constraints": [],
            "boundary_inclusive": False,
        }])
        specs = parse_requirements("Score strictly between 0.0 and 1.0", client=client)
        assert specs[0].boundary_inclusive is False

    def test_multiple_parameters(self):
        from testaxiom.parsers import parse_requirements
        client = _fake_client([
            {"name": "age", "param_type": "int", "valid_range": [18, 65],
             "valid_values": None, "constraints": [], "boundary_inclusive": True},
            {"name": "username_length", "param_type": "int", "valid_range": [3, 50],
             "valid_values": None, "constraints": [], "boundary_inclusive": True},
        ])
        specs = parse_requirements(
            "Age 18-65. Username must be 3-50 characters.", client=client
        )
        assert len(specs) == 2
        assert specs[0].name == "age"
        assert specs[1].name == "username_length"

    def test_empty_response_returns_empty_list(self):
        from testaxiom.parsers import parse_requirements
        client = _fake_client([])
        specs = parse_requirements("No parameters here", client=client)
        assert specs == []

    def test_no_tool_use_block_returns_empty_list(self):
        """If Claude doesn't return a tool_use block, return empty list gracefully."""
        from testaxiom.parsers import parse_requirements

        text_block = MagicMock()
        text_block.type = "text"
        text_block.text = "I cannot extract any parameters."

        client = MagicMock()
        client.messages.create.return_value.content = [text_block]

        specs = parse_requirements("unclear input", client=client)
        assert specs == []

    def test_client_called_with_correct_model(self):
        from testaxiom.parsers import parse_requirements
        client = _fake_client([])
        parse_requirements("age 18-65", client=client, model="claude-opus-4-7")
        call_kwargs = client.messages.create.call_args.kwargs
        assert call_kwargs["model"] == "claude-opus-4-7"

    def test_system_prompt_uses_cache_control(self):
        from testaxiom.parsers import parse_requirements
        client = _fake_client([])
        parse_requirements("age 18-65", client=client)
        call_kwargs = client.messages.create.call_args.kwargs
        system = call_kwargs["system"]
        assert isinstance(system, list)
        assert system[0]["cache_control"] == {"type": "ephemeral"}

    def test_tool_choice_forces_extract_parameters(self):
        from testaxiom.parsers import parse_requirements
        client = _fake_client([])
        parse_requirements("age 18-65", client=client)
        call_kwargs = client.messages.create.call_args.kwargs
        assert call_kwargs["tool_choice"] == {"type": "tool", "name": "extract_parameters"}


# ---------------------------------------------------------------------------
# parse_and_analyze — integration with analyze()
# ---------------------------------------------------------------------------

class TestParseAndAnalyze:

    def test_returns_analysis_results(self):
        from testaxiom.parsers import parse_and_analyze
        client = _fake_client([{
            "name": "age",
            "param_type": "int",
            "valid_range": [18, 65],
            "valid_values": None,
            "constraints": [],
            "boundary_inclusive": True,
        }])
        results = parse_and_analyze("age must be 18-65", client=client)
        assert len(results) == 1
        assert results[0].parameter.name == "age"
        assert len(results[0].test_cases) > 0

    def test_analyze_kwargs_forwarded(self):
        from testaxiom.parsers import parse_and_analyze
        client = _fake_client([{
            "name": "age",
            "param_type": "int",
            "valid_range": [18, 65],
            "valid_values": None,
            "constraints": [],
            "boundary_inclusive": True,
        }])
        results = parse_and_analyze("age 18-65", client=client, bva_mode="3-value")
        # 3-value BVA produces 6 BVA cases + 3 EP cases = 9 total
        assert len(results[0].test_cases) == 9

    def test_empty_parse_returns_empty_list(self):
        from testaxiom.parsers import parse_and_analyze
        client = _fake_client([])
        results = parse_and_analyze("nothing here", client=client)
        assert results == []


# ---------------------------------------------------------------------------
# ImportError when anthropic is not installed
# ---------------------------------------------------------------------------

class TestMissingAnthropic:

    def test_import_error_when_anthropic_missing(self):
        """Simulate anthropic not being installed."""
        from testaxiom.parsers import parse_requirements

        original = sys.modules.get("anthropic")
        sys.modules["anthropic"] = None  # type: ignore[assignment]
        try:
            with pytest.raises(ImportError, match="pip install testaxiom\\[ai\\]"):
                parse_requirements("age 18-65")
        finally:
            if original is None:
                sys.modules.pop("anthropic", None)
            else:
                sys.modules["anthropic"] = original
