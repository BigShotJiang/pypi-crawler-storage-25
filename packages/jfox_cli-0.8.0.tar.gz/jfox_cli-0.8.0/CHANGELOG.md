# Changelog

All notable changes to jfox-cli will be documented in this file.

## [0.8.0] - 2026-05-10

### Features
- add Claude Code plugin packaging for jfox skills (#209) (#210)
- 新增 session 笔记类型，专存 AI Agent 会话记录 (#202)

### Changes
- sync AGENTS.md with CLAUDE.md and current codebase (#208)

[0.8.0]: https://github.com/zhuxixi/jfox/compare/v0.7.2...v0.8.0

## [0.7.2] - 2026-05-07

### Fixes
- **note**: atomic write to prevent 0-byte note files (#201)
- strip frontmatter from --content-file input to prevent duplication (#200)

### Changes
- update CLAUDE.md to reflect current codebase state (#203)

[0.7.2]: https://github.com/zhuxixi/jfox/compare/v0.7.1...v0.7.2

## [0.7.1] - 2026-05-05

### Fixes
- dynamically detect model weight file format

[0.7.1]: https://github.com/zhuxixi/jfox/compare/v0.7.0...v0.7.1

## [0.7.0] - 2026-05-05

### Features
- **skills**: add CI monitoring with auto-polling to /ci command
- **skills**: add /ci command to trigger GitHub Actions workflows
- **cli**: add jfox check command for detecting corrupt files (#189)
- **note**: list_notes 扫描结束时汇总无效文件提示 (#188)

### Fixes
- **note**: downgrade parse failure log to warning in load_note (#187)

### Changes
- add design specs and implementation plans for recent features
- list_notes() 元数据索引，减少全量加载 (#190)
- add implementation plan for list_notes metadata index (#190)
- add spec for list_notes() metadata index (#190)
- add spec for jfox check command (#189)
- add spec for list_notes skip summary (#188)
- **spec**: add design for load_note log level fix (#186)

[0.7.0]: https://github.com/zhuxixi/jfox/compare/v0.6.0...v0.7.0

## [0.5.0] - 2026-04-29

### Features
- 支持通过标签召回笔记 (#170) (#177)
- **cli**: show tags column in list table output
- **note**: add tags parameter to list_notes() and search_notes()
- **vector_store**: add tags parameter to search() for ChromaDB filtering

### Fixes
- **test**: resolve CI test-full failures (#175)

### Changes
- add superpowers plans and specs docs, update .gitignore (#178)
- add tag filtering implementation plan for #170
- add tag filtering design spec for #170

[0.5.0]: https://github.com/zhuxixi/jfox/compare/v0.4.3...v0.5.0

## [0.4.3] - 2026-04-28

### Features
- 内网模型自动下载（3步降级重试链） (#173)

### Fixes
- **daemon**: eliminate deprecation warnings in daemon log (#171)

[0.4.3]: https://github.com/zhuxixi/jfox/compare/v0.4.2...v0.4.3

## [0.4.2] - 2026-04-22

### Features
- add Kimi CLI skill collection (#166)
- **skills**: add release skill with full workflow instructions
- **skills**: add release helper script with version bump and CHANGELOG generation

### Fixes
- **lint**: remove unused pytest import
- **skills**: improve git Chinese encoding and fix pluralization in release helper
- **skills**: address code review issues in release helper
- **cli**: list 命令 table 输出显示完整 18 位笔记 ID

### Changes
- style(lint): format test_release_helper.py with black
- Merge pull request #167 from zhuxixi/feat/kimi-cli-skills
- Merge pull request #165 from zhuxixi/fix-list-id-truncation

[0.4.2]: https://github.com/zhuxixi/jfox/compare/v0.4.1...v0.4.2

## [0.2.0] - 2026-04-13

### Features
- **edit**: add `--content-file` parameter for reading note content from a file (#106)

### Fixes
- **skill**: add `--kb` parameter support to jfox-health skill
- **cli**: add `use` as alias for `kb switch` subcommand (#105)

### Changes
- **skills**: redesign from 5 skills to 4
- **test**: fix flaky `test_update_content_preserves_id_and_created` (timing race on fast machines)

### Performance
- **startup**: lazy import optimization to eliminate startup overhead for lightweight commands (#122)
- **ci**: optimize CI coverage job to avoid rerunning tests (#119)

## [0.1.5] - 2026-04-12

### Fixes
- **index**: add `--kb` parameter to `jfox index` command (#104) (#113)
- **index**: fix `index verify` false positives (filename vs index ID format mismatch) (#111)
- **index**: fix `index rebuild` clearing ChromaDB before re-indexing (#110)
- **test**: prevent test KB residue in global config (#101)
- **ci**: resolve Windows path comparison bug and add quality gate

### Changes
- **style**: auto-fix all ruff/black lint errors (1869 fixed)

[0.2.0]: https://github.com/zhuxixi/jfox/compare/v0.1.5...v0.2.0
[0.1.5]: https://github.com/zhuxixi/jfox/compare/v0.1.4...v0.1.5
