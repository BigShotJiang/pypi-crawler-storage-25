"""AuditStore — data access layer for audit_events table."""

from __future__ import annotations

import json
import logging

import asyncpg

logger = logging.getLogger(__name__)


class AuditStore:
    """Data access layer for the audit_events table."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def log(
        self,
        *,
        event_type: str,
        resource_type: str,
        resource_id: str,
        actor_id: int | None = None,
        org: str | None = None,
        detail: dict | None = None,
        ip_address: str | None = None,
    ) -> None:
        """Insert an audit event record.

        Parameters
        ----------
        event_type:
            Dot-separated action identifier, e.g. ``"user.role_changed"``.
        resource_type:
            Kind of resource acted on, e.g. ``"user"``, ``"org"``.
        resource_id:
            Identifier of the specific resource (as text).
        actor_id:
            DB id of the user who performed the action.  None for system events.
        org:
            Organisation slug the action belongs to.  None for platform-wide events.
        detail:
            Arbitrary JSON payload with before/after state or extra context.
        ip_address:
            Originating IP address of the request (as text, e.g. ``"1.2.3.4"``).
        """
        detail_json = json.dumps(detail) if detail is not None else None
        async with self._pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO audit_events
                    (actor_id, org, event_type, resource_type, resource_id, detail, ip_address)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                """,
                actor_id,
                org,
                event_type,
                resource_type,
                resource_id,
                detail_json,
                ip_address,
            )

    async def list(
        self,
        *,
        org: str | None = None,
        event_type: str | None = None,
        actor_id: int | None = None,
        resource_type: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[dict]:
        """Return audit events, newest first, with optional filters.

        Parameters
        ----------
        org:
            Filter to events belonging to this organisation slug.
        event_type:
            Filter to a specific event type.
        actor_id:
            Filter to actions performed by a specific user.
        resource_type:
            Filter to a specific resource kind.
        limit:
            Maximum number of rows to return (default 50).
        offset:
            Row offset for pagination (default 0).
        """
        conditions: list[str] = []
        params: list = []

        def _add(col: str, value) -> None:
            params.append(value)
            conditions.append(f"{col} = ${len(params)}")

        if org is not None:
            _add("org", org)
        if event_type is not None:
            _add("event_type", event_type)
        if actor_id is not None:
            _add("actor_id", actor_id)
        if resource_type is not None:
            _add("resource_type", resource_type)

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""

        params.append(limit)
        limit_placeholder = f"${len(params)}"
        params.append(offset)
        offset_placeholder = f"${len(params)}"

        sql = f"""
            SELECT *
            FROM audit_events
            {where}
            ORDER BY created_at DESC
            LIMIT {limit_placeholder}
            OFFSET {offset_placeholder}
        """

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(sql, *params)
        return [dict(r) for r in rows]

    async def delete_older_than(self, *, days: int) -> int:
        """Delete audit events older than *days* days.

        Returns
        -------
        int
            Number of rows deleted.
        """
        async with self._pool.acquire() as conn:
            result = await conn.execute(
                """
                DELETE FROM audit_events
                WHERE created_at < now() - ($1 * INTERVAL '1 day')
                """,
                days,
            )
        # asyncpg returns "DELETE N"
        try:
            return int(result.split()[-1])
        except (ValueError, IndexError):
            return 0
