"""Super-admin API routes — prefix /api/admin, gated by PLATFORM_MANAGE."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from canon.admin.config import get_admin_config
from canon.admin.middleware import require_super_admin
from canon.admin.models import (
    AuditEventResponse,
    DashboardResponse,
    HealthSubsystem,
    IntegrationSummary,
    KPIStats,
    OrgSummary,
    RoleUpdate,
    SubscriptionSummary,
    UserSummary,
)
from canon.auth.models import CurrentUser

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/admin", tags=["admin"])


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@router.get("/config")
async def get_config(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return the current AdminConfig (mode + feature flags)."""
    settings = request.app.state.settings
    cfg = get_admin_config(settings)
    return cfg.model_dump()


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


@router.get("/dashboard")
async def get_dashboard(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return KPIs, health summary, and recent audit events."""
    admin_store = getattr(request.app.state, "admin_store", None)
    audit_store = getattr(request.app.state, "audit_store", None)

    kpis = KPIStats()
    health: list[HealthSubsystem] = []
    recent_events: list[AuditEventResponse] = []

    if admin_store is not None:
        try:
            raw_kpis = await admin_store.get_kpis()
            kpis = KPIStats(**raw_kpis)
        except Exception:
            logger.warning("Failed to fetch KPIs", exc_info=True)

        try:
            raw_health = await admin_store.get_health_summary()
            health = [HealthSubsystem(**h) for h in raw_health]
        except Exception:
            logger.warning("Failed to fetch health summary", exc_info=True)

    if audit_store is not None:
        try:
            raw_events = await audit_store.list(limit=10)
            recent_events = [_audit_row_to_response(e) for e in raw_events]
        except Exception:
            logger.warning("Failed to fetch recent audit events", exc_info=True)

    return DashboardResponse(
        kpis=kpis,
        health=health,
        recent_events=recent_events,
    ).model_dump()


# ---------------------------------------------------------------------------
# Orgs
# ---------------------------------------------------------------------------


@router.get("/orgs")
async def list_orgs(
    request: Request,
    search: str | None = None,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return a paginated list of organisations."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return []
    rows = await admin_store.list_orgs(limit=limit, offset=offset, search=search)
    return [OrgSummary(**_coerce_org(r)).model_dump() for r in rows]


@router.get("/orgs/{org}")
async def get_org(
    org: str,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return details for a single org."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")
    row = await admin_store.get_org(org)
    if row is None:
        raise HTTPException(status_code=404, detail="Org not found")
    result = OrgSummary(**_coerce_org(row)).model_dump()
    # Include members list if present (not part of OrgSummary model)
    if "members" in row:
        result["members"] = row["members"]
    return result


@router.post("/orgs/{org}/reindex")
async def reindex_org(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Trigger a reindex for an org (logs an audit event)."""
    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="org.reindex_triggered",
                resource_type="org",
                resource_id=org,
                actor_id=None,
                org=org,
                detail={"triggered_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for reindex", exc_info=True)

    logger.info("Reindex triggered for org=%s by %s", org, user.sub)
    return {"status": "ok", "org": org}


@router.post("/orgs/{org}/suspend")
async def suspend_org(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Suspend an org (must be currently active)."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    updated = await admin_store.suspend_org(org)
    if updated is None:
        raise HTTPException(status_code=404, detail="Org not found or not active")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="org.suspended",
                resource_type="org",
                resource_id=org,
                actor_id=None,
                org=org,
                detail={"suspended_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for org suspension", exc_info=True)

    return OrgSummary(**_coerce_org({"login": org, **updated})).model_dump()


@router.post("/orgs/{org}/reactivate")
async def reactivate_org(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Reactivate a suspended org."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    updated = await admin_store.reactivate_org(org)
    if updated is None:
        raise HTTPException(status_code=404, detail="Org not found or not suspended")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="org.reactivated",
                resource_type="org",
                resource_id=org,
                actor_id=None,
                org=org,
                detail={"reactivated_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for org reactivation", exc_info=True)

    return OrgSummary(**_coerce_org({"login": org, **updated})).model_dump()


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------


@router.get("/users")
async def list_users(
    request: Request,
    org: str | None = None,
    role: str | None = None,
    search: str | None = None,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return a paginated list of users with optional filters."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return []
    rows = await admin_store.list_users(
        limit=limit, offset=offset, org=org, role=role, search=search
    )
    return [UserSummary(**_coerce_user(r)).model_dump() for r in rows]


@router.get("/users/{user_id}")
async def get_user(
    user_id: int,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return details for a single user."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")
    row = await admin_store.get_user(user_id)
    if row is None:
        raise HTTPException(status_code=404, detail="User not found")
    return UserSummary(**_coerce_user(row)).model_dump()


@router.patch("/users/{user_id}")
async def update_user(
    user_id: int,
    body: RoleUpdate,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Update a user's role and emit an audit event."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    # Fetch current state for audit trail
    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")

    updated = await admin_store.update_user_role(user_id, body.role)
    if updated is None:
        raise HTTPException(status_code=404, detail="User not found")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="user.role_changed",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                org=existing.get("org_login"),
                detail={
                    "old_role": existing.get("role"),
                    "new_role": body.role,
                    "changed_by": user.sub,
                },
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for role change", exc_info=True)

    return UserSummary(**_coerce_user(updated)).model_dump()


@router.post("/users/{user_id}/deactivate")
async def deactivate_user(
    user_id: int,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Deactivate a user, revoke all sessions and API keys."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")
    if existing.get("role") == "super_admin":
        raise HTTPException(status_code=400, detail="Cannot deactivate a super admin")
    if existing.get("status") == "deactivated":
        raise HTTPException(status_code=400, detail="User is already deactivated")

    updated = await admin_store.deactivate_user(user_id)
    if updated is None:
        raise HTTPException(status_code=409, detail="User status changed concurrently")

    session_store = getattr(request.app.state, "session_store", None)
    sessions_revoked = 0
    if session_store is not None:
        sessions_revoked = await session_store.revoke_all_sessions(user_id=user_id)

    user_store = getattr(request.app.state, "user_store", None)
    keys_revoked = 0
    if user_store is not None:
        keys_revoked = await user_store.revoke_all_api_keys(user_id=user_id)

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="user.deactivated",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                org=existing.get("org_login"),
                detail={
                    "deactivated_by": user.sub,
                    "sessions_revoked": sessions_revoked,
                    "keys_revoked": keys_revoked,
                },
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for user deactivation", exc_info=True)

    result = UserSummary(**_coerce_user(updated)).model_dump()
    result["sessions_revoked"] = sessions_revoked
    result["keys_revoked"] = keys_revoked
    return result


@router.post("/users/{user_id}/reactivate")
async def reactivate_user(
    user_id: int,
    request: Request,
    user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Reactivate a previously deactivated user."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")

    existing = await admin_store.get_user(user_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="User not found")
    if existing.get("status") != "deactivated":
        raise HTTPException(status_code=400, detail="User is not deactivated")

    updated = await admin_store.reactivate_user(user_id)
    if updated is None:
        raise HTTPException(status_code=409, detail="User status changed concurrently")

    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is not None:
        try:
            await audit_store.log(
                event_type="user.reactivated",
                resource_type="user",
                resource_id=str(user_id),
                actor_id=None,
                org=existing.get("org_login"),
                detail={"reactivated_by": user.sub},
                ip_address=_client_ip(request),
            )
        except Exception:
            logger.warning("Failed to log audit event for user reactivation", exc_info=True)

    return UserSummary(**_coerce_user(updated)).model_dump()


# ---------------------------------------------------------------------------
# Billing (cloud only)
# ---------------------------------------------------------------------------


@router.get("/billing")
async def list_billing(
    request: Request,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return billing overview — cloud deployment only."""
    _require_cloud(request)
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return []
    rows = await admin_store.list_subscriptions(limit=limit, offset=offset)
    return [SubscriptionSummary(**_coerce_subscription(r)).model_dump() for r in rows]


@router.get("/billing/{org}")
async def get_org_billing(
    org: str,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return billing info for a single org — cloud deployment only."""
    _require_cloud(request)
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        raise HTTPException(status_code=503, detail="Database not available")
    row = await admin_store.get_org_billing(org)
    if row is None:
        raise HTTPException(status_code=404, detail="Org not found")
    result = SubscriptionSummary(**_coerce_subscription(row)).model_dump()
    # Pass through extra fields from monthly summary
    for extra in ("ai_ops_used", "ai_ops_included"):
        if extra in row:
            result[extra] = row[extra]
    return result


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


@router.get("/health")
async def get_health(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return subsystem health checks."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return []
    try:
        raw = await admin_store.get_health_summary()
        return [HealthSubsystem(**h).model_dump() for h in raw]
    except Exception:
        logger.warning("Health check failed", exc_info=True)
        return []


# ---------------------------------------------------------------------------
# Integrations (read-only stub)
# ---------------------------------------------------------------------------


@router.get("/integrations")
async def list_integrations(
    request: Request,
    provider: str | None = None,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return platform integrations."""
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return []
    rows = await admin_store.list_integrations(limit=limit, offset=offset, provider=provider)
    return [IntegrationSummary(**_coerce_integration(r)).model_dump() for r in rows]


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------


@router.get("/audit")
async def list_audit_events(
    request: Request,
    org: str | None = None,
    event_type: str | None = None,
    actor_id: int | None = None,
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _user: CurrentUser = Depends(require_super_admin),
) -> list[dict]:
    """Return paginated audit events with optional filters."""
    audit_store = getattr(request.app.state, "audit_store", None)
    if audit_store is None:
        return []
    rows = await audit_store.list(
        org=org,
        event_type=event_type,
        actor_id=actor_id,
        limit=limit,
        offset=offset,
    )
    return [_audit_row_to_response(r).model_dump() for r in rows]


# ---------------------------------------------------------------------------
# AI ops
# ---------------------------------------------------------------------------


@router.get("/ai")
async def get_ai_overview(
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return AI ops overview."""
    _empty: dict = {"ops_today": 0, "ops_this_month": 0, "orgs": []}
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return _empty
    try:
        result = await admin_store.get_ai_ops_summary()
        if not isinstance(result, dict):
            return _empty
        return result
    except Exception:
        logger.warning("Failed to fetch AI ops summary", exc_info=True)
        return _empty


@router.get("/ai/{org}")
async def get_ai_org(
    org: str,
    request: Request,
    _user: CurrentUser = Depends(require_super_admin),
) -> dict:
    """Return per-org AI ops metrics."""
    _empty: dict = {"org": org, "ops_today": 0, "ops_this_month": 0}
    admin_store = getattr(request.app.state, "admin_store", None)
    if admin_store is None:
        return _empty
    try:
        result = await admin_store.get_org_ai_usage(org)
        if not isinstance(result, dict):
            return _empty
        return result
    except Exception:
        logger.warning("Failed to fetch AI ops for org=%s", org, exc_info=True)
        return _empty


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _require_cloud(request: Request) -> None:
    """Raise 404 if the deployment mode is not cloud."""
    settings = request.app.state.settings
    if settings.deployment_mode != "cloud":
        raise HTTPException(status_code=404, detail="Not available in self-hosted mode")


def _client_ip(request: Request) -> str | None:
    """Extract the originating IP address from the request."""
    forwarded_for = request.headers.get("x-forwarded-for")
    if forwarded_for:
        # Rightmost value is appended by the trusted reverse proxy (nginx-ingress)
        return forwarded_for.split(",")[-1].strip()
    client = request.client
    return client.host if client else None


def _coerce_org(row: dict) -> dict:
    """Coerce an asyncpg row dict into OrgSummary constructor kwargs."""
    result = {
        "login": row.get("login", ""),
        "installation_id": str(row["installation_id"]) if row.get("installation_id") else None,
        "user_count": row.get("user_count", 0),
        "created_at": row.get("created_at"),
        "status": row.get("status", "active"),
        "display_name": row.get("display_name", ""),
        "member_count": row.get("member_count"),
    }
    # Derive member_count from members list if present
    members = row.get("members")
    if members is not None and result["member_count"] is None:
        result["member_count"] = len(members)
    return result


def _coerce_user(row: dict) -> dict:
    """Coerce an asyncpg row dict into UserSummary constructor kwargs."""
    return {
        "id": row.get("id", 0),
        "login": row.get("login", ""),
        "email": row.get("email", ""),
        "role": row.get("role", ""),
        "status": row.get("status", "active"),
        "org_login": row.get("org_login", ""),
        "created_at": row.get("created_at"),
        "last_login": row.get("last_login"),
        "login_count": row.get("login_count"),
        "email_verified": row.get("email_verified"),
        "picture": row.get("picture"),
        "identities": row.get("identities"),
    }


def _coerce_subscription(row: dict) -> dict:
    """Coerce a subscriptions row into SubscriptionSummary constructor kwargs."""
    return {
        "org_login": row.get("org_login", ""),
        "plan": row.get("plan", ""),
        "status": row.get("status", ""),
        "seat_count": row.get("seat_count", 0),
        "billing_cycle": row.get("billing_cycle", ""),
        "stripe_customer_id": row.get("stripe_customer_id"),
        "current_period_start": row.get("current_period_start"),
        "current_period_end": row.get("current_period_end"),
    }


def _coerce_integration(row: dict) -> dict:
    """Coerce an org_integrations row into IntegrationSummary constructor kwargs."""
    return {
        "org_login": row.get("org_login", ""),
        "provider": row.get("provider", ""),
        "display_name": row.get("display_name", ""),
        "status": row.get("status", ""),
        "connected_by": row.get("connected_by"),
        "connected_at": row.get("connected_at"),
    }


def _audit_row_to_response(row: dict) -> AuditEventResponse:
    """Convert a raw audit row dict to AuditEventResponse."""
    import json as _json

    detail = row.get("detail")
    if isinstance(detail, str):
        try:
            detail = _json.loads(detail)
        except (ValueError, TypeError):
            detail = None

    return AuditEventResponse(
        id=str(row.get("id", "")),
        event_type=row.get("event_type", ""),
        resource_type=row.get("resource_type", ""),
        resource_id=str(row.get("resource_id", "")),
        actor_id=row.get("actor_id"),
        org=row.get("org"),
        detail=detail,
        ip_address=row.get("ip_address"),
        created_at=row.get("created_at"),
    )
