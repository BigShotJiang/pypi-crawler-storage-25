from __future__ import annotations

"""Two-track locus map renderer.

Track 1 (top):    Reference locus with marker gene arrows drawn at their known
                  positions in the reference sequence (locus-coordinate x-axis).

Track 2 (bottom): Detected locus in the input genome with marker gene arrows
                  drawn at their actual genome coordinates.

                  Single contig  → one continuous backbone, genome-coord axis,
                                   x-axis flipped when locus strand is "-".
                  Multiple contigs → one backbone segment per contig, each with
                                   its own genome-coord axis; segments are ordered
                                   left-to-right by the locus position of their
                                   earliest marker; explicit break markers and
                                   contig name labels separate the segments.

Connectors:       One centered dashed line per marker running from the
                  center-bottom of the Track 1 arrow to an accolade bracket
                  placed above the Track 2 arrow.  The accolade carries the
                  per-marker identity and coverage from the marker-detection BLASTN.

Special markers:  r1_core, r4_core, s1_core are split into sub-polygons
                  according to MARKER_DISPLAY.  Group labels replace individual
                  gene-name labels for unnamed sub-genes (r4_core, s1_core).
"""

import math
from dataclasses import dataclass
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFont
    _PIL_AVAILABLE = True
except ImportError:
    _PIL_AVAILABLE = False

from flavotyper.locus import LocusRecord, MarkerPosition
from flavotyper.locus_align import LocusAlignResult
from flavotyper.models import Hit


# Special marker split definitions

MARKER_DISPLAY: dict[str, dict] = {
    "r1_core": {"sub_labels": ["wfpC", "wfpD", "wfpE"], "group_label": None},
    "r4_core": {"sub_labels": ["", "", ""],              "group_label": "R4 (3 unnamed genes)"},
    "s1_core": {"sub_labels": ["", "", "", ""],          "group_label": "S1 (4 unnamed genes)"},
}


# Colour palette (Okabe-Ito-inspired, colour-blind safe)

_PALETTE: list[tuple[int, int, int]] = [
    (230, 159,   0),   # orange
    ( 86, 180, 233),   # sky blue
    (  0, 158, 115),   # bluish green
    (240, 228,  66),   # yellow
    (  0, 114, 178),   # blue
    (213,  94,   0),   # vermilion
    (204, 121, 167),   # reddish purple
    ( 89, 196, 139),   # mint
    (153,  79, 228),   # violet
    (255, 128,   0),   # amber
    ( 70, 130, 180),   # steel blue
    (188, 143, 143),   # rosy brown
]

_BACKBONE_COLOR = (120, 120, 120)
_LABEL_COLOR    = ( 40,  40,  40)
_MUTED_COLOR    = ( 90,  90,  90)
_AXIS_COLOR     = (175, 175, 175)
_OUTLINE_COLOR  = (  0,   0,   0)
_BG_COLOR       = (255, 255, 255)
_BREAK_COLOR    = ( 60,  60,  60)


# Layout constants  (all values are at 2× resolution for high-quality output)


IMG_WIDTH      = 3600
LEFT_MARGIN    = 480    # space for track labels on the left
RIGHT_MARGIN   = 80
TOP_MARGIN     = 70

TITLE_LINE_H   = 48     # bold header line height
HEADER_GAP     = 28

# Label zone above each track backbone.
# Track 1: contains gene name labels only.
# Track 2: contains gene name label + stats text + accolade bracket.
LABEL_ABOVE    = 140

TRACK_H        = 72     # backbone height (arrow body spans this)
TICK_H         = 44     # tick zone below backbone
CONNECTOR_H    = 72     # gap between Track 1 tick zone and Track 2 label zone
CONTIG_INFO_H  = 48     # contig info line below Track 2 ticks
BOTTOM_PAD     = 48

ARROW_HEAD_PX  = 32
BACKBONE_THICK = 3
ARROW_OUTLINE_W = 4

BREAK_W        = 48     # pixel width reserved for each contig break marker
BREAK_GAP      = 10     # half-gap around the "//" symbol

ACCOLADE_ARM_H = 14     # height of accolade bracket vertical arms
ACCOLADE_GAP   = 6      # gap between accolade arm bottom and arrow top

TITLE_FONT_SZ  = 32
LABEL_FONT_SZ  = 24
TICK_FONT_SZ   = 20

_ARROW_HALF    = TRACK_H // 2 - 4   # half-height of the arrow polygon
_CROWDED_TEXT_LIFT_PX = 18
_CROWDED_TEXT_MIN_GAP_PX = 100


# Internal data structures

@dataclass
class _DisplayMarker:
    """Rendering unit for one marker, possibly split into sub-polygons."""
    marker: str               # parent marker key (for color lookup)
    sub_labels: list[str]     # label per sub-polygon; empty str = no label
    group_label: str | None   # collective label (R4, S1) or None
    locus_start: int          # start within reference locus (1-based)
    locus_end: int            # end within reference locus (1-based)
    hit: Hit | None           # marker-detection hit (provides stats + genome coords)


@dataclass
class _Segment:
    """Pixel layout of one contig segment on Track 2."""
    contig: str
    g_min: int     # genome start (1-based)
    g_max: int     # genome end (1-based)
    flip: bool     # True when locus_strand == "-" on this contig
    x_left: int    # left pixel edge of this segment
    x_right: int   # right pixel edge of this segment

    def px(self, genome_pos: int) -> int:
        """Map a genome coordinate to a pixel x position."""
        span = self.g_max - self.g_min or 1
        w    = self.x_right - self.x_left
        if self.flip:
            return self.x_left + round((self.g_max - genome_pos) / span * w)
        return self.x_left + round((genome_pos - self.g_min) / span * w)


@dataclass
class _Track2MarkerLayout:
    """Resolved Track 2 placement for one detected marker."""
    marker: str
    sub_labels: list[str]
    group_label: str | None
    px1: int
    px2: int
    strand: str
    stats_text: str

    @property
    def cx(self) -> int:
        return (self.px1 + self.px2) // 2


# Public entry point

def render_locus_map(
    sample_name: str,
    locus_marker_positions: list[MarkerPosition],
    align_result: LocusAlignResult,
    output_path: Path,
    locus_record: LocusRecord | None = None,
) -> None:
    """Render a two-track locus map PNG and save it to *output_path*."""
    if not _PIL_AVAILABLE:
        raise ImportError("Pillow is required for locus maps: pip install Pillow")

    # ── Expand split markers and assign colors ───────────────────────────────
    display_markers = _expand_display_markers(
        locus_marker_positions, align_result.marker_hits
    )
    color_map = _assign_colors(display_markers)

    # ── Determine layout mode ────────────────────────────────────────────────
    contigs_in_hsps = {h.contig for h in align_result.hsps}
    is_multi = len(contigs_in_hsps) > 1

    # ── Fonts ────────────────────────────────────────────────────────────────
    font_title = _load_font_bold(TITLE_FONT_SZ)
    font_label = _load_font(LABEL_FONT_SZ)
    font_tick  = _load_font(TICK_FONT_SZ)

    # ── Canvas ───────────────────────────────────────────────────────────────
    canvas_h = (
        TOP_MARGIN
        + TITLE_LINE_H + HEADER_GAP
        + LABEL_ABOVE + TRACK_H + TICK_H    # Track 1
        + CONNECTOR_H
        + LABEL_ABOVE + TRACK_H             # Track 2
        + TICK_H
        + CONTIG_INFO_H
        + TITLE_LINE_H                       # legend
        + BOTTOM_PAD
    )

    img  = Image.new("RGB", (IMG_WIDTH, canvas_h), _BG_COLOR)
    draw = ImageDraw.Draw(img)

    drawable_w = IMG_WIDTH - LEFT_MARGIN - RIGHT_MARGIN
    x_left     = LEFT_MARGIN
    x_right    = IMG_WIDTH - RIGHT_MARGIN

    # ── Y positions (top to bottom) ──────────────────────────────────────────
    y = TOP_MARGIN

    title_y    = y;  y += TITLE_LINE_H + HEADER_GAP

    t1_label_y = y;  y += LABEL_ABOVE
    t1_y       = y + TRACK_H // 2
    y         += TRACK_H
    t1_tick_y  = y;  y += TICK_H

    y         += CONNECTOR_H

    t2_label_y = y;  y += LABEL_ABOVE
    t2_y       = y + TRACK_H // 2
    y         += TRACK_H
    t2_tick_y  = y;  y += TICK_H
    t2_contig_y = y; y += CONTIG_INFO_H

    legend_y   = y + 8

    # Accolade positions (within Track 2 label zone, just above arrow polygon)
    t2_arrow_top   = t2_y - _ARROW_HALF
    accolade_bar_y = t2_arrow_top - ACCOLADE_ARM_H - ACCOLADE_GAP
    stats_text_y   = accolade_bar_y - TICK_FONT_SZ - 4

    # Connector: from bottom of T1 arrow to top of accolade bar
    conn_y_top = t1_y + _ARROW_HALF
    conn_y_bot = accolade_bar_y

    # ── Coordinate converters ────────────────────────────────────────────────
    locus_len = align_result.locus_length

    def locus_px(pos: int) -> int:
        return x_left + round(pos / locus_len * drawable_w)

    # Single-contig converters
    det_px      = locus_px   # fallback (overwritten below for single contig)
    flip_single = False
    g_min_single = 0
    g_max_single = locus_len

    if not is_multi and align_result.hsps:
        g_min_single = min(h.genome_start for h in align_result.hsps)
        g_max_single = max(h.genome_end   for h in align_result.hsps)
        # Also account for marker hit positions (marker-detection hits can extend slightly beyond HSPs)
        if align_result.marker_hits:
            g_min_single = min(g_min_single, min(h.start for h in align_result.marker_hits))
            g_max_single = max(g_max_single, max(h.end   for h in align_result.marker_hits))
        g_span       = g_max_single - g_min_single or 1
        n_minus      = sum(1 for h in align_result.hsps if h.locus_strand == "-")
        flip_single  = n_minus > len(align_result.hsps) - n_minus

        if flip_single:
            def det_px(pos: int) -> int:  # type: ignore[misc]
                return x_left + round((g_max_single - pos) / g_span * drawable_w)
        else:
            def det_px(pos: int) -> int:  # type: ignore[misc]
                return x_left + round((pos - g_min_single) / g_span * drawable_w)

    # Multi-contig segment layouts
    segments: list[_Segment] = []
    seg_map:  dict[str, _Segment] = {}
    if is_multi:
        segments = _build_segments(
            align_result, display_markers, x_left, x_right, drawable_w
        )
        seg_map = {s.contig: s for s in segments}

    # ── Header ───────────────────────────────────────────────────────────────
    title_text = (
        f"Serotype {align_result.serotype}"
        f"   |   Locus identity: {align_result.pct_identity:.1f}%"
        f"   |   Locus coverage: {align_result.pct_coverage:.1f}%"
    )
    title_w = _approx_text_w(title_text, TITLE_FONT_SZ)
    draw.text(
        ((IMG_WIDTH - title_w) // 2, title_y),
        title_text, fill=_LABEL_COLOR, font=font_title,
    )

    # ── Track 1: Reference locus ─────────────────────────────────────────────
    # Track label
    if locus_record is not None:
        ref_strand_sym = "(-)" if locus_record.genome_strand in ("-", "-1") else "(+)"
        t1_lines = [
            "Reference locus:",
            _abbreviate_genus(align_result.reference_genome),
            f"Length: {locus_record.seq_len:,} bp",
            f"Strand {ref_strand_sym}",
        ]
    else:
        t1_lines = [
            "Reference locus:",
            align_result.reference_genome,
        ]
    _draw_track_label(draw, t1_lines, t1_label_y, font_label, font_tick)

    _draw_backbone(draw, x_left, x_right, t1_y)

    # Gene label top: just above the T1 arrow
    t1_gene_label_y = t1_y - _ARROW_HALF - LABEL_FONT_SZ - 8

    ref_centers: dict[str, int] = {}   # marker → connector x on T1
    for dm in display_markers:
        cx = _draw_split_arrows(
            draw, dm.sub_labels, dm.group_label,
            locus_px(dm.locus_start), locus_px(dm.locus_end),
            t1_y, color_map[dm.marker], "+", font_label, t1_gene_label_y,
        )
        ref_centers[dm.marker] = cx

    # T1 x-axis
    draw.line([(x_left, t1_tick_y), (x_right, t1_tick_y)], fill=_AXIS_COLOR, width=2)
    if locus_record is not None:
        ref_flip = locus_record.genome_strand in ("-", "-1")
        _draw_ticks(draw, font_tick, t1_tick_y, x_left, x_right,
                    locus_record.genome_start, locus_record.genome_end,
                    n_ticks=3, reverse=ref_flip, unit="bp")
    else:
        _draw_ticks(draw, font_tick, t1_tick_y, x_left, x_right, 0, locus_len,
                    n_ticks=3, unit="bp")

    # ── Track 2: Detected locus ──────────────────────────────────────────────
    # Track label
    if is_multi:
        t2_lines = [
            "Input genome:",
            sample_name,
            f"Fragmented — {len(contigs_in_hsps)} contigs",
        ]
    else:
        strand_sym   = "(-)" if flip_single else "(+)"
        det_len      = g_max_single - g_min_single
        contigs_list = sorted({h.contig for h in align_result.hsps})
        t2_lines = [
            "Input genome:",
            sample_name,
            f"Contig name: {contigs_list[0]}",
            f"Length: {det_len:,} bp  |  Strand {strand_sym}",
        ]
    _draw_track_label(draw, t2_lines, t2_label_y, font_label, font_tick)

    # Backbone(s)
    if is_multi:
        _draw_multi_backbone(draw, segments, t2_y)
    else:
        _draw_backbone(draw, x_left, x_right, t2_y)

    det_centers: dict[str, int] = {}          # marker → connector x on T2
    det_spans:   dict[str, tuple[int, int]] = {}  # marker → (px1, px2) for accolade
    det_layouts: list[_Track2MarkerLayout] = []

    # Gene label top for T2: a small gap above the accolade stats text
    t2_gene_label_y = stats_text_y - LABEL_FONT_SZ - 14

    for dm in display_markers:
        if dm.hit is None:
            continue

        if is_multi:
            seg = seg_map.get(dm.hit.contig)
            if seg is None:
                continue
            p_start = seg.px(dm.hit.start)
            p_end   = seg.px(dm.hit.end)
            strand  = dm.hit.strand if not seg.flip else _flip_strand(dm.hit.strand)
        else:
            p_start = det_px(dm.hit.start)
            p_end   = det_px(dm.hit.end)
            strand  = dm.hit.strand if not flip_single else _flip_strand(dm.hit.strand)

        px1 = min(p_start, p_end)
        px2 = max(p_start, p_end)
        det_layouts.append(_Track2MarkerLayout(
            marker=dm.marker,
            sub_labels=dm.sub_labels,
            group_label=dm.group_label,
            px1=px1,
            px2=px2,
            strand=strand,
            stats_text=f"id: {_fmt_pct(dm.hit.identity)};  cov: {_fmt_pct(dm.hit.coverage)}",
        ))

    text_offsets = _compute_track2_text_offsets(det_layouts)

    for layout in det_layouts:
        text_offset = text_offsets.get(layout.marker, 0)
        _draw_split_arrows(
            draw, layout.sub_labels, layout.group_label,
            layout.px1, layout.px2,
            t2_y, color_map[layout.marker], layout.strand, font_label,
            t2_gene_label_y + text_offset,
        )
        det_centers[layout.marker] = layout.cx
        det_spans[layout.marker]   = (layout.px1, layout.px2)

    # T2 x-axis
    if is_multi:
        # Each segment gets its own independent axis line + ticks (no linking)
        for seg in segments:
            draw.line(
                [(seg.x_left, t2_tick_y), (seg.x_right, t2_tick_y)],
                fill=_AXIS_COLOR, width=2,
            )
        _draw_multi_ticks(draw, font_tick, t2_tick_y, segments)
    else:
        draw.line([(x_left, t2_tick_y), (x_right, t2_tick_y)], fill=_AXIS_COLOR, width=2)
        _draw_ticks(draw, font_tick, t2_tick_y, x_left, x_right,
                    g_min_single, g_max_single, n_ticks=3, reverse=flip_single, unit="bp")

    # CONTIG_INFO_H zone: per-segment labels for fragmented; empty for single contig
    if is_multi:
        for seg in segments:
            seg_len  = seg.g_max - seg.g_min
            seg_str  = "(-)" if seg.flip else "(+)"
            seg_info = (
                f"Contig name: {seg.contig}  |  "
                f"Start: {seg.g_min:,};  End: {seg.g_max:,};  "
                f"Length: {seg_len:,} bp  |  Strand {seg_str}"
            )
            info_w  = _approx_text_w(seg_info, TICK_FONT_SZ)
            seg_cx  = (seg.x_left + seg.x_right) // 2
            draw.text(
                (seg_cx - info_w // 2, t2_contig_y + 10),
                seg_info, fill=_MUTED_COLOR, font=font_tick,
            )

    # ── Connectors + accolades ───────────────────────────────────────────────
    for layout in det_layouts:
        if layout.marker not in ref_centers or layout.marker not in det_centers:
            continue
        t1_cx          = ref_centers[layout.marker]
        t2_cx          = det_centers[layout.marker]
        t2_px1, t2_px2 = det_spans[layout.marker]
        color          = color_map[layout.marker]
        text_offset    = text_offsets.get(layout.marker, 0)

        _draw_connector_and_accolade(
            draw, t1_cx, conn_y_top,
            t2_cx, t2_px1, t2_px2,
            conn_y_bot, accolade_bar_y, ACCOLADE_ARM_H,
            layout.stats_text, stats_text_y + text_offset,
            color, font_tick,
        )

    # ── Legend ───────────────────────────────────────────────────────────────
    swatch = TICK_FONT_SZ + 4
    lx = x_left
    seen: set[str] = set()
    for dm in display_markers:
        if dm.marker in seen:
            continue
        seen.add(dm.marker)
        color = color_map[dm.marker]
        draw.rectangle([lx, legend_y, lx + swatch, legend_y + swatch], fill=color)
        draw.line(
            [(lx, legend_y), (lx + swatch, legend_y),
             (lx + swatch, legend_y + swatch), (lx, legend_y + swatch), (lx, legend_y)],
            fill=_OUTLINE_COLOR, width=2,
        )
        legend_text = _legend_label(dm)
        draw.text((lx + swatch + 8, legend_y), legend_text,
                  fill=_LABEL_COLOR, font=font_tick)
        lx += swatch + 8 + _approx_text_w(legend_text, TICK_FONT_SZ) + 30
        if lx > x_right - 200:
            break

    img.save(str(output_path), "PNG")


# Marker expansion

def _expand_display_markers(
    marker_positions: list[MarkerPosition],
    marker_hits: list[Hit],
) -> list[_DisplayMarker]:
    """Build _DisplayMarker list, applying MARKER_DISPLAY splits where defined."""
    hit_map = {h.gene: h for h in marker_hits}
    result: list[_DisplayMarker] = []
    for mp in marker_positions:
        display = MARKER_DISPLAY.get(mp.marker)
        if display:
            sub_labels  = display["sub_labels"]
            group_label = display["group_label"]
        else:
            sub_labels  = [mp.gene_name]
            group_label = None
        result.append(_DisplayMarker(
            marker=mp.marker,
            sub_labels=sub_labels,
            group_label=group_label,
            locus_start=mp.marker_start_in_locus,
            locus_end=mp.marker_end_in_locus,
            hit=hit_map.get(mp.marker),
        ))
    return result


def _legend_label(dm: _DisplayMarker) -> str:
    """Human-readable label for the legend entry of a display marker."""
    if dm.group_label:
        return dm.group_label
    visible = [lbl for lbl in dm.sub_labels if lbl]
    return "; ".join(visible) if visible else dm.marker


# Multi-contig segment layout

def _build_segments(
    align_result: LocusAlignResult,
    display_markers: list[_DisplayMarker],
    x_left: int,
    x_right: int,
    drawable_w: int,
) -> list[_Segment]:
    """Build one _Segment per contig, ordered by reference locus position.

    Ordering: the contig whose earliest detected marker appears first in the
    reference locus is placed leftmost.  Segment pixel widths are proportional
    to each contig's HSP genome span.
    """
    # Map contig → earliest locus position among its marker hits
    contig_earliest: dict[str, int] = {}
    for dm in display_markers:
        if dm.hit is None:
            continue
        contig = dm.hit.contig
        if contig not in contig_earliest:
            contig_earliest[contig] = dm.locus_start
        else:
            contig_earliest[contig] = min(contig_earliest[contig], dm.locus_start)

    ordered_contigs = sorted(contig_earliest, key=lambda c: contig_earliest[c])

    # Per-contig: union of all HSP genome spans + majority strand
    contig_spans: dict[str, tuple[int, int, str]] = {}
    for h in align_result.hsps:
        if h.contig not in contig_spans:
            contig_spans[h.contig] = (h.genome_start, h.genome_end, h.locus_strand)
        else:
            lo, hi, _ = contig_spans[h.contig]
            contig_spans[h.contig] = (min(lo, h.genome_start), max(hi, h.genome_end), h.locus_strand)

    # Only keep contigs that appear in both ordered_contigs and contig_spans
    ordered_contigs = [c for c in ordered_contigs if c in contig_spans]
    n = len(ordered_contigs)
    if n == 0:
        return []

    total_break_px = BREAK_W * (n - 1)
    seg_drawable   = drawable_w - total_break_px
    total_span     = sum(
        contig_spans[c][1] - contig_spans[c][0] for c in ordered_contigs
    ) or 1

    segments: list[_Segment] = []
    cur_x = x_left
    for i, contig in enumerate(ordered_contigs):
        g_min, g_max, strand = contig_spans[contig]
        seg_w  = round((g_max - g_min) / total_span * seg_drawable)
        seg_w  = max(seg_w, 80)   # minimum visible width
        x_r    = cur_x + seg_w

        # Determine flip from majority locus_strand for this contig
        contig_hsps = [h for h in align_result.hsps if h.contig == contig]
        n_minus = sum(1 for h in contig_hsps if h.locus_strand == "-")
        flip    = n_minus > len(contig_hsps) - n_minus

        segments.append(_Segment(
            contig=contig,
            g_min=g_min, g_max=g_max,
            flip=flip,
            x_left=cur_x, x_right=x_r,
        ))
        cur_x = x_r + BREAK_W

    # Stretch last segment to exactly x_right
    if segments:
        last = segments[-1]
        segments[-1] = _Segment(
            contig=last.contig, g_min=last.g_min, g_max=last.g_max,
            flip=last.flip, x_left=last.x_left, x_right=x_right,
        )

    return segments


# Arrow rendering (split markers)

def _draw_split_arrows(
    draw: "ImageDraw.ImageDraw",
    sub_labels: list[str],
    group_label: str | None,
    px1: int,
    px2: int,
    track_y: int,
    color: tuple[int, int, int],
    strand: str,
    font: "ImageFont.ImageFont",
    label_y: int,
) -> int:
    """Draw one or more sub-polygon arrows for a marker.

    Returns the center x of the full group (used as connector anchor).
    """
    n     = len(sub_labels)
    total = px2 - px1
    sub_w = total // n

    for i, label in enumerate(sub_labels):
        sx1 = px1 + i * sub_w
        sx2 = px1 + (i + 1) * sub_w if i < n - 1 else px2
        _draw_arrow(draw, sx1, sx2, track_y, color, strand)

        # Individual gene-name label (only when no group label)
        if group_label is None and label:
            cx = (sx1 + sx2) // 2
            lw = _approx_text_w(label, LABEL_FONT_SZ)
            draw.text((cx - lw // 2, label_y), label, fill=_LABEL_COLOR, font=font)

    # Group label centered over all sub-polygons
    if group_label:
        cx = (px1 + px2) // 2
        gw = _approx_text_w(group_label, LABEL_FONT_SZ)
        draw.text((cx - gw // 2, label_y), group_label, fill=_LABEL_COLOR, font=font)

    return (px1 + px2) // 2


def _compute_track2_text_offsets(
    layouts: list[_Track2MarkerLayout],
    lift_px: int = _CROWDED_TEXT_LIFT_PX,
) -> dict[str, int]:
    """Slightly lift the middle marker when adjacent Track 2 labels are crowded."""
    offsets = {layout.marker: 0 for layout in layouts}
    ordered = sorted(layouts, key=lambda layout: layout.cx)

    for idx in range(1, len(ordered) - 1):
        prev_layout = ordered[idx - 1]
        layout      = ordered[idx]
        next_layout = ordered[idx + 1]
        if not _track2_text_is_crowded(prev_layout, layout):
            continue
        if not _track2_text_is_crowded(layout, next_layout):
            continue
        offsets[layout.marker] = -lift_px

    return offsets


def _track2_text_is_crowded(left: _Track2MarkerLayout, right: _Track2MarkerLayout) -> bool:
    """Return True when adjacent Track 2 gene/stats labels overlap or sit too close."""
    return (
        _interval_gap(_merge_bounds(_gene_label_bounds(left)),
                      _merge_bounds(_gene_label_bounds(right))) <= _CROWDED_TEXT_MIN_GAP_PX
        or _interval_gap(_stats_bounds(left), _stats_bounds(right)) <= _CROWDED_TEXT_MIN_GAP_PX
    )


def _gene_label_bounds(layout: _Track2MarkerLayout) -> list[tuple[int, int]]:
    """Return horizontal bounds for every visible gene label on a marker."""
    if layout.group_label:
        width = _approx_text_w(layout.group_label, LABEL_FONT_SZ)
        return [_centered_bounds(layout.cx, width)]

    n = len(layout.sub_labels)
    if n == 0:
        return []

    total = layout.px2 - layout.px1
    sub_w = total // n
    bounds: list[tuple[int, int]] = []
    for i, label in enumerate(layout.sub_labels):
        if not label:
            continue
        sx1 = layout.px1 + i * sub_w
        sx2 = layout.px1 + (i + 1) * sub_w if i < n - 1 else layout.px2
        cx = (sx1 + sx2) // 2
        width = _approx_text_w(label, LABEL_FONT_SZ)
        bounds.append(_centered_bounds(cx, width))
    return bounds


def _stats_bounds(layout: _Track2MarkerLayout) -> tuple[int, int]:
    """Return horizontal bounds for the centered Track 2 stats label."""
    return _centered_bounds(layout.cx, _approx_text_w(layout.stats_text, TICK_FONT_SZ))


def _merge_bounds(bounds: list[tuple[int, int]]) -> tuple[int, int] | None:
    """Collapse many horizontal bounds into one bounding interval."""
    if not bounds:
        return None
    return (min(left for left, _ in bounds), max(right for _, right in bounds))


def _centered_bounds(cx: int, width: int) -> tuple[int, int]:
    """Return the horizontal interval of text centered at *cx*."""
    return (cx - width // 2, cx + math.ceil(width / 2))


def _interval_gap(
    left: tuple[int, int] | None,
    right: tuple[int, int] | None,
) -> int:
    """Return the horizontal gap between two intervals; 0 means overlap/touching."""
    if left is None or right is None:
        return math.inf
    if left[1] < right[0]:
        return right[0] - left[1]
    if right[1] < left[0]:
        return left[0] - right[1]
    return 0


# Connector + accolade

def _draw_connector_and_accolade(
    draw: "ImageDraw.ImageDraw",
    t1_cx: int,
    conn_y_top: int,
    t2_cx: int,
    t2_px1: int,
    t2_px2: int,
    conn_y_bot: int,
    accolade_bar_y: int,
    arm_h: int,
    stats_text: str,
    stats_y: int,
    color: tuple[int, int, int],
    font: "ImageFont.ImageFont",
) -> None:
    """Draw one centered dashed line from T1 to accolade, then the bracket."""
    blended = tuple(round(c + (255 - c) * 0.40) for c in color)

    # Dashed connector line
    _draw_dashed_line(draw, t1_cx, conn_y_top, t2_cx, conn_y_bot, color)

    # Accolade bracket: top bar + two vertical arms
    arm_bot = accolade_bar_y + arm_h
    draw.line([(t2_px1, accolade_bar_y), (t2_px2, accolade_bar_y)],
              fill=blended, width=2)
    draw.line([(t2_px1, accolade_bar_y), (t2_px1, arm_bot)],
              fill=blended, width=2)
    draw.line([(t2_px2, accolade_bar_y), (t2_px2, arm_bot)],
              fill=blended, width=2)

    # Stats text centered above the accolade bar
    sw = _approx_text_w(stats_text, TICK_FONT_SZ)
    draw.text(((t2_px1 + t2_px2) // 2 - sw // 2, stats_y),
              stats_text, fill=_MUTED_COLOR, font=font)


# Backbone helpers

def _draw_backbone(
    draw: "ImageDraw.ImageDraw", x1: int, x2: int, y: int
) -> None:
    draw.line([(x1, y), (x2, y)], fill=_BACKBONE_COLOR, width=BACKBONE_THICK)


def _draw_multi_backbone(
    draw: "ImageDraw.ImageDraw",
    segments: list[_Segment],
    track_y: int,
) -> None:
    """Draw solid backbone segments with a '//' break marker between them."""
    for i, seg in enumerate(segments):
        _draw_backbone(draw, seg.x_left, seg.x_right, track_y)

        if i < len(segments) - 1:
            # Break marker in the gap between this segment and the next
            gap_left  = seg.x_right
            gap_right = segments[i + 1].x_left
            gap_cx    = (gap_left + gap_right) // 2
            gap_h     = 20   # half-height of the "//" zigzag

            # Draw two diagonal slashes
            for offset in (-BREAK_GAP, BREAK_GAP):
                bx = gap_cx + offset
                draw.line(
                    [(bx - 6, track_y + gap_h), (bx + 6, track_y - gap_h)],
                    fill=_BREAK_COLOR, width=3,
                )



# Tick axes

def _draw_ticks(
    draw: "ImageDraw.ImageDraw",
    font: "ImageFont.ImageFont",
    y_top: int,
    x_left: int,
    x_right: int,
    coord_left: int,
    coord_right: int,
    n_ticks: int = 6,
    reverse: bool = False,
    unit: str = "",
) -> None:
    span    = abs(coord_right - coord_left)
    px_span = x_right - x_left
    if span <= 0 or px_span <= 0:
        return

    lo = min(coord_left, coord_right)
    hi = max(coord_left, coord_right)

    tick_len = 10
    label_y  = y_top + 14

    left_coord  = hi if reverse else lo
    right_coord = lo if reverse else hi
    left_label  = _format_tick_label(left_coord,  unit)
    right_label = _format_tick_label(right_coord, unit)
    left_w      = _approx_text_w(left_label,  TICK_FONT_SZ)
    right_w     = _approx_text_w(right_label, TICK_FONT_SZ)

    draw.line([(x_left,  y_top), (x_left,  y_top + tick_len)], fill=_MUTED_COLOR, width=2)
    draw.text((x_left + 2, label_y), left_label, fill=_MUTED_COLOR, font=font)
    draw.line([(x_right, y_top), (x_right, y_top + tick_len)], fill=_MUTED_COLOR, width=2)
    draw.text((x_right - right_w - 2, label_y), right_label, fill=_MUTED_COLOR, font=font)

    if span == 0 or n_ticks == 0:
        return
    raw_step  = span / n_ticks
    magnitude = 10 ** math.floor(math.log10(raw_step))
    step = magnitude * min([1, 2, 5, 10], key=lambda n: abs(n * magnitude - raw_step))
    # Exclusion zones: keep intermediate ticks away from each endpoint label.
    min_left_px  = left_w  + 20
    min_right_px = right_w + 20

    tick_coord = math.ceil(lo / step) * step
    while tick_coord <= hi:
        if reverse:
            px = x_left + round((hi - tick_coord) / span * px_span)
        else:
            px = x_left + round((tick_coord - lo) / span * px_span)
        if px - x_left < min_left_px or x_right - px < min_right_px:
            tick_coord += step
            continue
        draw.line([(px, y_top), (px, y_top + tick_len)], fill=_MUTED_COLOR, width=2)
        label   = _format_tick_label(tick_coord, unit)
        label_x = px - _approx_text_w(label, TICK_FONT_SZ) // 2
        draw.text((label_x, label_y), label, fill=_MUTED_COLOR, font=font)
        tick_coord += step


def _draw_multi_ticks(
    draw: "ImageDraw.ImageDraw",
    font: "ImageFont.ImageFont",
    y_top: int,
    segments: list[_Segment],
) -> None:
    """Draw x-axis ticks independently for each segment."""
    for seg in segments:
        seg_px_w = seg.x_right - seg.x_left
        n_ticks  = 3 if seg_px_w >= 1500 else 0
        _draw_ticks(
            draw, font, y_top,
            seg.x_left, seg.x_right,
            seg.g_min, seg.g_max,
            n_ticks=n_ticks, reverse=seg.flip, unit="bp",
        )


# Arrow drawing

def _draw_arrow(
    draw: "ImageDraw.ImageDraw",
    x1: int, x2: int, y: int,
    color: tuple[int, int, int],
    strand: str,
) -> None:
    half  = _ARROW_HALF
    width = x2 - x1

    if width < 6:
        rx2 = max(x1 + 4, x2)
        pts = [(x1, y - half), (rx2, y - half), (rx2, y + half), (x1, y + half)]
        _draw_polygon_outlined(draw, pts, color)
        return

    head = min(ARROW_HEAD_PX, width)
    if strand == "-":
        hbx = x1 + head
        pts = [(x1, y), (hbx, y - half), (x2, y - half), (x2, y + half), (hbx, y + half)]
    else:
        hbx = x2 - head
        pts = [(x1, y - half), (hbx, y - half), (x2, y), (hbx, y + half), (x1, y + half)]

    _draw_polygon_outlined(draw, pts, color)


def _draw_polygon_outlined(
    draw: "ImageDraw.ImageDraw",
    points: list[tuple[int, int]],
    fill_color: tuple[int, int, int],
) -> None:
    draw.polygon(points, fill=fill_color)
    closed = list(points) + [points[0]]
    draw.line(closed, fill=_OUTLINE_COLOR, width=ARROW_OUTLINE_W)


# Track label

def _draw_track_label(
    draw: "ImageDraw.ImageDraw",
    lines: list[str],
    label_y: int,
    font_label: "ImageFont.ImageFont",
    font_tick: "ImageFont.ImageFont",
) -> None:
    """Draw a multi-line track label in the left margin.

    The first line uses font_label (larger, dark); subsequent lines use
    font_tick (smaller, muted).  Long lines are truncated with an ellipsis.
    """
    y = label_y
    for i, line in enumerate(lines):
        if not line:
            continue
        font  = font_label if i == 0 else font_tick
        color = _LABEL_COLOR if i == 0 else _MUTED_COLOR
        sz    = LABEL_FONT_SZ if i == 0 else TICK_FONT_SZ
        max_chars = 42
        trunc = line[:max_chars] + "…" if len(line) > max_chars else line
        draw.text((10, y), trunc, fill=color, font=font)
        y += sz + 4


# Dashed line helper

def _draw_dashed_line(
    draw: "ImageDraw.ImageDraw",
    x1: int, y1: int, x2: int, y2: int,
    color: tuple[int, int, int],
    dash: int = 14,
    gap: int = 8,
) -> None:
    dx     = x2 - x1
    dy     = y2 - y1
    length = math.hypot(dx, dy)
    if length == 0:
        return
    blended = tuple(round(c + (255 - c) * 0.40) for c in color)
    segment = dash + gap
    steps   = int(length / segment) + 1
    for i in range(steps):
        t0 = min(i * segment / length,           1.0)
        t1 = min((i * segment + dash) / length,  1.0)
        sx = round(x1 + dx * t0);  sy = round(y1 + dy * t0)
        ex = round(x1 + dx * t1);  ey = round(y1 + dy * t1)
        draw.line([(sx, sy), (ex, ey)], fill=blended, width=2)


# Utility helpers

def _flip_strand(strand: str) -> str:
    return "-" if strand == "+" else "+"


def _abbreviate_genus(name: str) -> str:
    """Abbreviate a Linnean genus: 'Flavobacterium psychrophilum X' → 'F. psychrophilum X'."""
    parts = name.split(" ", 1)
    if len(parts) == 2 and parts[0].isalpha() and parts[0][0].isupper():
        return parts[0][0] + ". " + parts[1]
    return name


def _assign_colors(
    display_markers: list[_DisplayMarker],
) -> dict[str, tuple[int, int, int]]:
    color_map: dict[str, tuple[int, int, int]] = {}
    for dm in display_markers:
        if dm.marker not in color_map:
            idx = len(color_map) % len(_PALETTE)
            color_map[dm.marker] = _PALETTE[idx]
    return color_map


def _fmt_pct(value: float) -> str:
    """Format a percentage: integer when whole (100 → '100%'), one decimal otherwise."""
    return f"{int(value)}%" if value == int(value) else f"{value:.1f}%"


def _format_tick_label(coord: int, unit: str) -> str:
    if unit and coord != 0:
        return f"{coord:,} {unit}"
    return f"{coord:,}"


def _approx_text_w(text: str, font_size: int) -> int:
    return round(len(text) * font_size * 0.58)


def _load_font(size: int) -> "ImageFont.ImageFont":
    for name in ("DejaVuSans.ttf", "LiberationSans-Regular.ttf", "Arial.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except (OSError, AttributeError):
            continue
    return ImageFont.load_default()


def _load_font_bold(size: int) -> "ImageFont.ImageFont":
    for name in ("DejaVuSans-Bold.ttf", "LiberationSans-Bold.ttf",
                 "Arial Bold.ttf", "ArialBd.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except (OSError, AttributeError):
            continue
    return _load_font(size)
