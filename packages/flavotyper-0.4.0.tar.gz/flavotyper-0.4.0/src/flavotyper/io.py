from __future__ import annotations

"""FASTA parser for assembled genomes."""

from pathlib import Path
import gzip

from flavotyper.exceptions import ValidationError


def read_fasta(path: Path) -> dict[str, str]:
    """Parse FASTA into ``{contig_name: sequence}``.

    Notes:
    - contig names are taken from the first token after `>`.
    - sequences are uppercased for robust downstream matching.
    """

    records: dict[str, str] = {}
    header: str | None = None
    chunks: list[str] = []

    opener = gzip.open if "".join(path.suffixes).lower().endswith(".gz") else Path.open

    with opener(path, "rt", encoding="utf-8") as handle:
        for line_no, raw in enumerate(handle, start=1):
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                if header is not None:
                    if header in records:
                        raise ValidationError(f"Duplicate FASTA record name '{header}' in {path}")
                    records[header] = "".join(chunks).upper()
                header_tokens = line[1:].split()
                if not header_tokens:
                    raise ValidationError(f"Empty FASTA header at line {line_no} in {path}")
                header = header_tokens[0]
                chunks = []
            else:
                if header is None:
                    raise ValidationError(f"FASTA sequence found before header at line {line_no} in {path}")
                chunks.append(line)

    # Flush last record if any.
    if header is not None:
        if header in records:
            raise ValidationError(f"Duplicate FASTA record name '{header}' in {path}")
        records[header] = "".join(chunks).upper()

    if not records:
        raise ValidationError(f"No FASTA records parsed from {path}")
    # Accept standard IUPAC nucleotide codes found in assembled genomes.
    allowed_bases = {"A", "C", "G", "T", "N", "R", "Y", "S", "W", "K", "M", "B", "D", "H", "V"}
    for name, seq in records.items():
        if not seq:
            raise ValidationError(f"Empty sequence for FASTA record '{name}' in {path}")
        if set(seq) - allowed_bases:
            raise ValidationError(
                f"Invalid nucleotide symbols in FASTA record '{name}' from {path}. "
                "Allowed symbols are IUPAC DNA codes: A/C/G/T/N/R/Y/S/W/K/M/B/D/H/V."
            )
    return records
