from __future__ import annotations

"""Command-line interface.

The CLI only does three things:
1) parse arguments,
2) build a validated RunConfig,
3) call pipeline and print a short summary.
"""

import argparse
from pathlib import Path
import sys

from flavotyper import __version__
from flavotyper.config import (
    BUNDLED_LOCUS_FASTA,
    BUNDLED_RULES_YAML,
    BUNDLED_SPECIES_REF,
    DEFAULT_EXPECTED_GENOME_SIZE_MAX,
    DEFAULT_EXPECTED_GENOME_SIZE_MIN,
    FASTA_EXTENSIONS,
    RunConfig,
)
from flavotyper.exceptions import FlavoTyperError
from flavotyper.pipeline import run_typing


def _expand_genome_paths(raw: list[str]) -> list[Path]:
    """Expand any directory paths to the FASTA files they contain.

    Paths that are already files are returned unchanged.  For each directory,
    all files whose names end with a supported FASTA extension are collected
    (case-insensitive, sorted for determinism).  An empty directory (no
    matching files) raises FlavoTyperError so the user gets a clear message
    rather than a cryptic downstream failure.
    """
    result: list[Path] = []
    for raw_path in raw:
        p = Path(raw_path)
        if p.is_dir():
            found = sorted(
                f for f in p.iterdir()
                if f.is_file() and any(f.name.lower().endswith(ext) for ext in FASTA_EXTENSIONS)
            )
            if not found:
                raise FlavoTyperError(
                    f"No FASTA files found in directory: {p}\n"
                    f"Supported extensions: {', '.join(FASTA_EXTENSIONS)}"
                )
            result.extend(found)
        else:
            result.append(p)
    return result


def build_parser() -> argparse.ArgumentParser:
    """Create command parser and all supported options."""

    parser = argparse.ArgumentParser(
        prog="flavotyper",
        description="In silico serotyping for F. psychrophilum (BLASTN-based pipeline)",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Show program version and exit",
    )
    subparsers = parser.add_subparsers(dest="command")

    # ── data-dir subcommand ─────────────────────────────────────────────────
    subparsers.add_parser(
        "data-dir",
        help="Print the path to the bundled data directory and exit",
    )

    # ── type subcommand ─────────────────────────────────────────────────────
    type_parser = subparsers.add_parser("type", help="Run serotype prediction on genome FASTA files")

    # Required I/O
    type_parser.add_argument(
        "--genomes",
        nargs="+",
        required=True,
        help=(
            "Input genome FASTA file(s) or a directory. "
            "When a directory is given, all files with a supported FASTA extension "
            f"({', '.join(FASTA_EXTENSIONS)}) are discovered automatically."
        ),
    )
    type_parser.add_argument(
        "--db",
        default=None,
        help=(
            "Path to the rules YAML database file. "
            "Defaults to the bundled Flavotyper_rules.yaml."
        ),
    )
    type_parser.add_argument("--outdir", required=True, help="Output directory")

    # Marker-hit thresholds
    type_parser.add_argument(
        "--min-identity",
        type=float,
        default=97.0,
        help="Minimum BLASTN percent identity for a marker hit to be accepted (default: 97.0)",
    )
    type_parser.add_argument(
        "--min-coverage",
        type=float,
        default=94.0,
        help="Minimum marker coverage (aligned length / marker length * 100) for a hit to be accepted (default: 94.0)",
    )

    # Compute
    type_parser.add_argument(
        "--threads",
        type=int,
        default=1,
        help="Number of CPU threads passed to BLASTN and fastANI (default: 1)",
    )
    # Species gate
    type_parser.add_argument("--no-species-check", action="store_true", help="Disable ANI species verification")
    type_parser.add_argument(
        "--ani-threshold",
        type=float,
        default=95.0,
        help="Minimum fastANI value required to pass species verification (default: 95.0)",
    )
    type_parser.add_argument(
        "--species-refs",
        default=None,
        help=(
            "Path to the fastANI reference genome FASTA file. "
            "Defaults to the bundled F. psychrophilum NCIMB 1947T genome. "
            "Ignored when --no-species-check is used."
        ),
    )

    # Assembly-size / contig warnings (do not block typing).
    type_parser.add_argument(
        "--expected-genome-size-min",
        type=int,
        default=DEFAULT_EXPECTED_GENOME_SIZE_MIN,
        help=(
            "Expected minimum genome size (bp); default is the 2.5th percentile "
            "of the curated Microscope dataset"
        ),
    )
    type_parser.add_argument(
        "--expected-genome-size-max",
        type=int,
        default=DEFAULT_EXPECTED_GENOME_SIZE_MAX,
        help=(
            "Expected maximum genome size (bp); default is the 97.5th percentile "
            "of the curated Microscope dataset"
        ),
    )
    type_parser.add_argument(
        "--warn-contigs-over",
        type=int,
        default=300,
        help="Contig-count warning threshold",
    )
    type_parser.add_argument(
        "--high-warn-contigs-over",
        type=int,
        default=500,
        help="High contig-count warning threshold",
    )
    type_parser.add_argument(
        "--allow-duplicate-sample-names",
        action="store_true",
        help="Allow duplicate sample IDs derived from input file stems",
    )

    # Locus comparison
    type_parser.add_argument(
        "--locus-analysis",
        action="store_true",
        help=(
            "Enable locus analysis. Runs a second BLASTN for every sample "
            "with a Resolved serotype call, producing a pairwise alignment text "
            "file and a two-track PNG locus map in the output directory. Uses the "
            "bundled reference_loci.fasta unless overridden with --locus-db."
        ),
    )
    type_parser.add_argument(
        "--locus-db",
        default=None,
        help=(
            "Override path to the locus reference FASTA. Defaults to the bundled "
            "reference_loci.fasta shipped inside FlavoTyper/data/."
        ),
    )

    return parser


def main(argv: list[str] | None = None) -> None:
    """CLI entrypoint called by `python -m flavotyper` and console scripts."""

    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "data-dir":
        print(str(BUNDLED_RULES_YAML.parent))
        return

    if args.command != "type":
        parser.print_help()
        sys.exit(1)

    db_path      = Path(args.db) if args.db else BUNDLED_RULES_YAML
    species_refs = (
        Path(args.species_refs) if args.species_refs
        else (BUNDLED_SPECIES_REF if not args.no_species_check else None)
    )

    try:
        genomes = _expand_genome_paths(args.genomes)
    except FlavoTyperError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(2)

    config = RunConfig(
        genomes=genomes,
        db_path=db_path,
        outdir=Path(args.outdir),
        min_identity=args.min_identity,
        min_coverage=args.min_coverage,
        threads=args.threads,
        species_check=not args.no_species_check,
        ani_threshold=args.ani_threshold,
        species_refs=species_refs,
        expected_genome_size_min=args.expected_genome_size_min,
        expected_genome_size_max=args.expected_genome_size_max,
        warn_contigs_over=args.warn_contigs_over,
        high_warn_contigs_over=args.high_warn_contigs_over,
        fail_on_duplicate_sample_names=not args.allow_duplicate_sample_names,
        locus_analysis=args.locus_analysis,
        locus_db_path=Path(args.locus_db) if args.locus_db else BUNDLED_LOCUS_FASTA,
    )

    try:
        metadata, calls = run_typing(config)
    except FlavoTyperError as exc:
        # Controlled failure path with readable message.
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(2)

    n_typed = sum(1 for c in calls if c.typed)
    n_qc_failed = sum(1 for c in calls if not c.typed)
    n_with_warnings = sum(
        1 for c in calls
        if c.warnings or (c.qc and c.qc.quality_warnings)
    )
    print(
        f"Completed {len(calls)} sample(s): "
        f"typed={n_typed}, QC_failed={n_qc_failed}, with_warnings={n_with_warnings} | "
        f"DB={metadata.db_name}:{metadata.db_version} | outdir={config.outdir}",
        file=sys.stdout,
    )
