"""Top-level package metadata for FlavoTyper.

This file intentionally stays minimal:
- expose version for reports/reproducibility,
- avoid importing heavy modules at package import time.
"""

__all__ = ["__version__"]

__version__ = "0.4.0"
