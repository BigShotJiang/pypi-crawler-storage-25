from __future__ import annotations

"""Output writers for FlavoTyper results.

Produces:
- run-level JSON metadata,
- sample-level TSV table (23 columns, single-line cells),
- sample-level JSONL records.

The JSONL records carry everything in the TypingCall dataclass (including
`sample_key`, which is an internal run-scoped identifier intentionally omitted
from the TSV to keep the human-facing table clean).
"""

import csv
from pathlib import Path
import json

from flavotyper.marker_names import display_marker_name
from flavotyper.models import RunMetadata, TypingCall
from flavotyper.provenance import InputSampleManifest


TSV_HEADER = [
    "Sample_name",
    "Typed",
    "O_type",
    "R_type",
    "S_type",
    "Serotype",
    "Call_state",
    "Alternative_serotypes",
    "Species_check",
    "Species_passed",
    "Calculated_ANI",
    "ANI_reference",
    "N_contigs",
    "Genome_size_bp",
    "GC_percent",
    "QC_passed",
    "QC_warnings",
    "Present_alleles",
    "Present_alleles_ranges",
    "Present_alleles_contig_names",
    "Typing_warnings",
    "Serotype_reference",
    "Raw_hits",
]


def _format_allele_ranges(hits: list) -> str:
    """Render per-allele genomic coordinates as a single-line cell."""

    if not hits:
        return ""
    return " ; ".join(
        f"{display_marker_name(hit.gene)}:{hit.start}-{hit.end}" for hit in hits
    )


def _format_allele_contigs(hits: list) -> str:
    """Render per-allele contig names as a single-line cell."""

    if not hits:
        return ""
    return " ; ".join(
        f"{display_marker_name(hit.gene)}:{hit.contig}" for hit in hits
    )


def _format_hits(hits: list) -> str:
    """Render all BLAST hits as a single-line cell.

    Format per hit: gene|identity=X|coverage=X|contig=X|coords=start-end
    Hits are separated by ' ; '.
    """

    if not hits:
        return ""
    return " ; ".join(
        f"{display_marker_name(hit.gene)}|identity={hit.identity:.3f}|coverage={hit.coverage:.3f}"
        f"|contig={hit.contig}|coords={hit.start}-{hit.end}"
        for hit in hits
    )


def _tsv_row(call: TypingCall) -> list[str]:
    """Convert one typing call to one TSV row (23 columns)."""

    qc = call.qc
    species = qc.species if qc else None

    species_check = "Enabled" if (species and species.checked) else "Disabled"

    species_passed = ""
    if species and species.passed is not None:
        species_passed = str(species.passed)

    # Merge blocking failures and advisory warnings into one cell.
    qc_warning_entries: list[str] = []
    if qc:
        qc_warning_entries.extend(qc.quality_messages)
        qc_warning_entries.extend(qc.quality_warnings)

    return [
        call.sample,
        str(call.typed),
        call.o_type,
        call.r_type,
        call.s_type,
        call.serotype,
        call.ambiguity_state,
        ";".join(call.alternative_serotypes),
        species_check,
        species_passed,
        f"{species.best_ani:.2f}" if species and species.best_ani is not None else "",
        Path(species.best_reference).name if species and species.best_reference else "",
        str(qc.n_contigs) if qc else "",
        str(qc.genome_size) if qc else "",
        f"{qc.gc_percent:.2f}" if qc else "",
        str(qc.quality_passed) if qc else "",
        " ; ".join(qc_warning_entries),
        " ; ".join(display_marker_name(m) for m in call.present_markers),
        _format_allele_ranges(call.hits),
        _format_allele_contigs(call.hits),
        " ; ".join(call.warnings),
        call.serotype_reference,
        _format_hits(call.raw_hits),
    ]


def init_streaming_reports(outdir: Path) -> None:
    """Create/reset per-sample output files so rows can be appended during runtime."""

    outdir.mkdir(parents=True, exist_ok=True)
    tsv_path = outdir / "typing_results.tsv"
    with tsv_path.open("wt", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(TSV_HEADER)

    jsonl_path = outdir / "typing_results.jsonl"
    jsonl_path.write_text("", encoding="utf-8")


def append_call_reports(outdir: Path, call: TypingCall) -> None:
    """Append one sample call to TSV and JSONL outputs."""

    tsv_path = outdir / "typing_results.tsv"
    with tsv_path.open("at", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(_tsv_row(call))

    jsonl_path = outdir / "typing_results.jsonl"
    with jsonl_path.open("at", encoding="utf-8") as handle:
        handle.write(json.dumps(call.to_dict()) + "\n")


def write_run_metadata(outdir: Path, metadata: RunMetadata, manifests: list[InputSampleManifest]) -> None:
    """Write run-level metadata and manifest once run processing completes."""

    outdir.mkdir(parents=True, exist_ok=True)

    meta_path = outdir / "run_metadata.json"
    with meta_path.open("wt", encoding="utf-8") as handle:
        json.dump(metadata.to_dict(), handle, indent=2)

    manifest_path = outdir / "input_manifest.json"
    with manifest_path.open("wt", encoding="utf-8") as handle:
        json.dump([item.to_dict() for item in manifests], handle, indent=2)
