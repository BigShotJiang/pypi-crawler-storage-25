"""Custom exception hierarchy used across FlavoTyper.

- Catch tool-specific failures in one place (CLI) and print clean messages.
- Avoid leaking low-level tracebacks for expected user errors.
"""


class FlavoTyperError(Exception):
    """Base exception for all tool-level errors."""


class ValidationError(FlavoTyperError):
    """Raised when user input or database content is invalid."""


class DependencyError(FlavoTyperError):
    """Raised when an external dependency (blastn, fastANI) is unavailable."""
