from __future__ import annotations

"""Shared marker display-name mapping.

Maps internal FlavoTyper marker keys (as used in the rules database and BLAST
hit records) to the human-readable gene names shown in all tool outputs.

Any key absent from the table is returned unchanged, so wzy*, wfpF, Rieske,
wfpH, wfpI, etc. pass through as-is.
"""

MARKER_DISPLAY_NAMES: dict[str, str] = {
    "r1_core":    "wfpC; wfpD; wfpE",
    "r4_core":    "R4 (3 unnamed genes)",
    "s1_core":    "S1 (4 unnamed genes)",
    "wfpF_p": "wfpF'",
    "wfpF_pp":    'wfpF"',
}


def display_marker_name(gene: str) -> str:
    """Return the human-readable display name for a marker gene key."""
    return MARKER_DISPLAY_NAMES.get(gene, gene)
