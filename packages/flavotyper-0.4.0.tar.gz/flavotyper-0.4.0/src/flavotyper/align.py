from __future__ import annotations

"""BLASTN alignment layer.

FlavoTyper uses BLASTN as the alignment engine.
This module:
- builds a marker FASTA + BLAST database,
- runs BLASTN with genome as query against this marker DB,
- parses tabular output into `Hit` objects.
"""

from dataclasses import dataclass
from pathlib import Path
import subprocess
import shutil

from flavotyper.exceptions import DependencyError, FlavoTyperError
from flavotyper.models import Hit


def check_blast_dependencies() -> None:
    """Fail fast if required BLAST+ executables are unavailable."""

    if shutil.which("blastn") is None:
        raise DependencyError("blastn not found in PATH. Install BLAST+ (required by FlavoTyper).")
    if shutil.which("makeblastdb") is None:
        raise DependencyError("makeblastdb not found in PATH. Install BLAST+ (required by FlavoTyper).")


@dataclass(frozen=True)
class AlignmentRequest:
    """All information needed by the aligner for one sample."""

    sample: str
    genome_path: Path


def build_marker_fasta(marker_sequences: dict[str, str], fasta_path: Path) -> None:
    """Write marker sequences to a FASTA file.

    This file is then used as input for `makeblastdb`.
    """

    with fasta_path.open("wt", encoding="utf-8") as handle:
        for marker_name, sequence in marker_sequences.items():
            handle.write(f">{marker_name}\n{sequence}\n")


def make_blast_database(marker_fasta_path: Path, db_prefix: Path) -> None:
    """Create nucleotide BLAST database from marker FASTA."""

    cmd = [
        "makeblastdb",
        "-in",
        str(marker_fasta_path),
        "-dbtype",
        "nucl",
        "-out",
        str(db_prefix),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if proc.returncode != 0:
        raise FlavoTyperError(f"makeblastdb failed: {proc.stderr.strip()}")


def parse_blast_tabular(text: str) -> list[Hit]:
    """Parse BLAST tabular output into a list of `Hit` records.

    Expected BLAST columns:
        qseqid sseqid pident qstart qend sstart send slen

    - qseqid: input contig ID (from genome query)
    - sseqid: marker ID (from subject marker FASTA)
    - slen: marker length (coverage denominator)
    """

    hits: list[Hit] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue

        fields = line.split("\t")
        if len(fields) != 8:
            raise FlavoTyperError(f"Unexpected BLAST output line: {line}")

        qseqid, sseqid, pident, qstart, qend, sstart, send, slen = fields
        marker_len = int(slen)
        q1 = int(qstart)
        q2 = int(qend)
        s1 = int(sstart)
        s2 = int(send)

        # Strand of the marker on the input genome.
        # In blastn (genome=query, marker=subject):
        #   sstart <= send → marker found in forward direction → gene on + strand
        #   sstart >  send → marker found as reverse complement → gene on - strand
        strand = "+" if s1 <= s2 else "-"

        # Coverage formula: ABS((send - sstart) + 1) / slen * 100
        alignment_len = abs((s2 - s1) + 1)
        coverage = (100.0 * alignment_len / marker_len) if marker_len else 0.0

        hits.append(
            Hit(
                gene=sseqid,
                identity=float(pident),
                coverage=coverage,
                contig=qseqid,
                start=min(q1, q2),
                end=max(q1, q2),
                marker_start=min(s1, s2),
                marker_end=max(s1, s2),
                marker_length=marker_len,
                alignment_length=alignment_len,
                strand=strand,
            )
        )

    return hits


class BlastnAligner:
    """BLASTN aligner used by the pipeline."""

    def __init__(self, db_prefix: Path, threads: int = 1):
        self.db_prefix = db_prefix
        self.threads = threads

    def align(self, request: AlignmentRequest) -> list[Hit]:
        """Run BLASTN for one sample and return parsed hits."""

        #   query = input genome
        #   subject  = marker reference database
        cmd = [
            "blastn",
            "-query",
            str(request.genome_path),
            "-db",
            str(self.db_prefix),
            "-num_threads",
            str(self.threads),
            "-outfmt",
            "6 qseqid sseqid pident qstart qend sstart send slen",
        ]

        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if proc.returncode != 0:
            raise FlavoTyperError(
                f"blastn failed for sample {request.sample}: {proc.stderr.strip()}"
            )

        return parse_blast_tabular(proc.stdout)
