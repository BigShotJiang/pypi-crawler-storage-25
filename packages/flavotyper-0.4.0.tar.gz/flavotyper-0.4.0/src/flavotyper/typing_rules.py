from __future__ import annotations

"""Rule engine for O/R/S serotype assignment.

This module applies biological logic over filtered marker hits:
- O-type assignment from O-marker exclusivity,
- R-type base groups and variants,
- inter-marker distance constraints where defined by variant rules,
- S-type assignment as an independent binary axis (S0/S1).
"""

from flavotyper.database import SerotypeDB, RVariantRule
from flavotyper.marker_names import display_marker_name
from flavotyper.models import Hit, TypingCall, QCMetrics


def _best_hit_sort_key(hit: Hit) -> tuple[float, float, int]:
    """Return a ranking key for choosing one best hit per marker.

    Ranking priority (higher is better):
    1. Higher coverage
    2. Higher identity
    3. Longer alignment
    """

    return (hit.coverage, hit.identity, hit.alignment_length or 0)


def _select_best_marker_hits(
    hits: list[Hit],
    min_identity: float,
    min_coverage: float,
) -> list[Hit]:
    """Keep one best threshold-passing hit for each marker.

    The coverage value on each raw BLAST hit is preserved as parsed by the
    alignment layer.
    """

    by_marker: dict[str, list[Hit]] = {}
    for hit in hits:
        if hit.identity < min_identity or hit.coverage < min_coverage:
            continue
        by_marker.setdefault(hit.gene, []).append(hit)

    selected: list[Hit] = []
    for gene in sorted(by_marker):
        best_hit = max(by_marker[gene], key=_best_hit_sort_key)
        selected.append(best_hit)
    return selected


def _append_unique_warning(warnings: list[str], message: str) -> None:
    """Append warning once while preserving insertion order."""

    if message not in warnings:
        warnings.append(message)


def _distance_ok(
    left_hits: list[Hit], right_hits: list[Hit], min_distance: int, max_distance: int
) -> tuple[bool, bool]:
    """Return (match_found, cross_contig_pair_seen) for the distance window check.

    Distance formula:
        start_of_higher_coordinate_gene - end_of_lower_coordinate_gene
    """

    cross_contig_pair_seen = False
    for left in left_hits:
        for right in right_hits:
            if left.contig != right.contig:
                cross_contig_pair_seen = True
                continue
            if left.start <= right.start:
                distance = right.start - left.end
            else:
                distance = left.start - right.end
            if min_distance <= distance <= max_distance:
                return True, cross_contig_pair_seen
    return False, cross_contig_pair_seen


def _variant_matches(
    rule: RVariantRule,
    present_markers: set[str],
    by_marker: dict[str, list[Hit]],
    db: SerotypeDB,
    warnings: list[str],
) -> bool:
    """Check whether one R-variant rule is satisfied."""

    if not all(marker in present_markers for marker in rule.required_markers):
        return False

    if rule.distance_rule is None:
        return True

    distance_rule = db.distance_rules[rule.distance_rule]
    matched, cross_contig_pair_seen = _distance_ok(
        by_marker.get(distance_rule.left_marker, []),
        by_marker.get(distance_rule.right_marker, []),
        distance_rule.min_distance,
        distance_rule.max_distance,
    )
    if cross_contig_pair_seen:
        _append_unique_warning(
            warnings,
            f"Distance rule '{distance_rule.name}' for variant '{rule.name}' was evaluated "
            "using hits on different contigs.",
        )
    if not matched:
        _append_unique_warning(
            warnings,
            f"Variant '{rule.name}' markers are present but distance rule '{distance_rule.name}' "
            f"was not satisfied (expected range: {distance_rule.min_distance}..{distance_rule.max_distance}).",
        )
        if cross_contig_pair_seen:
            _append_unique_warning(
                warnings,
                f"Variant '{rule.name}' could not be confirmed because required marker hits were seen "
                "on different contigs.",
            )
    return matched


def _warn_if_markers_span_multiple_contigs(hits: list[Hit], warnings: list[str]) -> None:
    """Warn when retained typing markers are distributed across contigs."""

    if len(hits) <= 1:
        return

    contigs = {hit.contig for hit in hits}
    if len(contigs) <= 1:
        return

    marker_locations = "; ".join(
        f"{display_marker_name(hit.gene)}={hit.contig}"
        for hit in sorted(hits, key=lambda hit: (hit.gene, hit.contig))
    )
    _append_unique_warning(
        warnings,
        f"Detected typing markers are not all on the same contig: {marker_locations}.",
    )


def _warn_for_unassigned_r_markers(
    db: SerotypeDB,
    present_markers: set[str],
    r_type: str,
    warnings: list[str],
) -> None:
    """Explain undefined R calls when informative R-associated markers are present."""

    if r_type != "Undefined":
        return

    for marker in sorted(present_markers):
        matching_variants = sorted(
            variant.name for variant in db.r_variants if marker in variant.required_markers
        )
        base_groups = {
            group for group, required_markers in db.r_groups.items() if marker in required_markers
        }
        base_groups.update(
            variant.base_group for variant in db.r_variants if marker in variant.required_markers
        )

        details: list[str] = []
        if base_groups:
            details.append(f"base group(s) {', '.join(sorted(base_groups))}")
        if matching_variants:
            details.append(f"variant(s) {', '.join(matching_variants)}")
        if marker in db.s1_markers:
            details.append("the S1 subtype rule")

        if not details:
            continue

        _append_unique_warning(
            warnings,
            f"R typing remained undefined, but marker '{display_marker_name(marker)}' linked to {' and '.join(details)} was detected.",
        )


def _assign_o_type(db: SerotypeDB, present_markers: set[str], warnings: list[str]) -> tuple[str, list[str], list[str]]:
    """Assign O-type and emit candidate + reason code lists."""

    matched_o_labels = [o_label for o_label, marker in db.o_types.items() if marker in present_markers]
    reasons: list[str] = []

    if len(matched_o_labels) == 1:
        reasons.append("O_UNIQUE_MARKER")
        return matched_o_labels[0], matched_o_labels, reasons

    if len(matched_o_labels) > 1:
        _append_unique_warning(
            warnings,
            f"Ambiguous O-type: multiple markers detected ({','.join(sorted(matched_o_labels))})."
        )
        reasons.append("O_MULTIPLE_MARKERS")
        return "Ambiguous", sorted(matched_o_labels), reasons

    reasons.append("O_NO_MARKER")
    return "Undefined", [], reasons


def _assign_r_type(db: SerotypeDB, present_markers: set[str], by_marker: dict[str, list[Hit]],
                   warnings: list[str]) -> tuple[str, list[str], list[str]]:
    """Assign R-type from base-group and variant rules."""
    reasons: list[str] = []

    # Step 1: identify which base R-groups are present.
    passing_groups = [
        group for group, required in db.r_groups.items()
        if all(marker in present_markers for marker in required)
    ]

    if len(passing_groups) > 1:
        _append_unique_warning(
            warnings,
            f"Ambiguous R-group: multiple base groups detected ({','.join(sorted(passing_groups))})."
        )
        reasons.append("R_MULTIPLE_BASE_GROUPS")
        return "Ambiguous", sorted(passing_groups), reasons

    if not passing_groups:
        reasons.append("R_NO_BASE_GROUP")
        return "Undefined", [], reasons

    base_group = passing_groups[0]
    reasons.append("R_BASE_GROUP_DETECTED")

    # Step 2: evaluate explicit variants for that base group.
    candidate_variants = [variant for variant in db.r_variants if variant.base_group == base_group]
    matched_variants = [
        variant.name
        for variant in candidate_variants
        if _variant_matches(variant, present_markers, by_marker, db, warnings)
    ]

    if len(matched_variants) > 1:
        _append_unique_warning(
            warnings,
            f"Ambiguous R-variant for {base_group}: "
            f"multiple variants matched ({','.join(sorted(matched_variants))})."
        )
        reasons.append("R_MULTIPLE_VARIANTS")
        return "Ambiguous", sorted(matched_variants), reasons

    if len(matched_variants) == 1:
        reasons.append("R_VARIANT_RULE_MATCH")
        return matched_variants[0], matched_variants, reasons

    # Step 3: if no explicit variant matched, return the bare base group.
    reasons.append("R_BASE_ONLY")
    return base_group, [base_group], reasons


def _assign_s_type(db: SerotypeDB, present_markers: set[str]) -> str:
    """Return S1 if all S1 markers are detected, S0 otherwise."""
    if all(marker in present_markers for marker in db.s1_markers):
        return "S1"
    return "S0"


def call_serotype(sample: str, sample_key: str, db: SerotypeDB, hits: list[Hit], min_identity: float,
                  min_coverage: float, qc: QCMetrics | None = None) -> TypingCall:
    """Produce final typing call for one sample.

    Execution order:
    1. Filter hits by identity + coverage thresholds and keep one best hit
       per marker.
    2. Assign O-type, R-type, and S-type using their respective rule functions.
    3. Compose the serotype string (``O:X-Sy-Rz``) and determine ambiguity state.
    """

    # Threshold filter: keep only one best passing hit per marker.
    passing_hits = _select_best_marker_hits(
        hits,
        min_identity=min_identity,
        min_coverage=min_coverage,
    )

    by_marker: dict[str, list[Hit]] = {}
    for hit in passing_hits:
        by_marker.setdefault(hit.gene, []).append(hit)

    present_markers = set(by_marker.keys())
    warnings: list[str] = []
    _warn_if_markers_span_multiple_contigs(passing_hits, warnings)

    o_type, o_candidates, o_reasons = _assign_o_type(db, present_markers, warnings)
    r_type, r_candidates, r_reasons = _assign_r_type(db, present_markers, by_marker, warnings)

    # Some O-types (e.g. O:0) default to R0 when no R markers are detected,
    # instead of remaining Undefined.  Other O-types keep "Undefined" as a
    # data-quality signal — their R region should be characterized.
    if (
        o_type not in {"Ambiguous", "Undefined"}
        and r_type == "Undefined"
        and o_type in set(db.o_types_default_r0)
    ):
        r_type = "R0"
        r_candidates = ["R0"]
        r_reasons = [reason for reason in r_reasons if reason != "R_NO_BASE_GROUP"]
        r_reasons.append("R_DEFAULTED_TO_R0")

    _warn_for_unassigned_r_markers(db, present_markers, r_type, warnings)

    s_type = _assign_s_type(db, present_markers)
    serotype = f"{o_type}-{s_type}-{r_type}"
    alternatives = sorted(
        f"{o}-{s_type}-{r}" for o in o_candidates for r in r_candidates
        if f"{o}-{s_type}-{r}" != serotype
    )

    if o_type == "Ambiguous" or r_type == "Ambiguous":
        ambiguity_state = "Ambiguous"
    elif o_type == "Undefined" or r_type == "Undefined":
        ambiguity_state = "Partial"
    else:
        ambiguity_state = "Resolved"
    reason_codes = sorted(set(o_reasons + r_reasons))

    return TypingCall(
        sample=sample,
        sample_key=sample_key,
        typed=True,
        o_type=o_type,
        r_type=r_type,
        s_type=s_type,
        serotype=serotype,
        ambiguity_state=ambiguity_state,
        reason_codes=reason_codes,
        alternative_serotypes=alternatives,
        warnings=warnings,
        present_markers=sorted(present_markers),
        hits=passing_hits,
        raw_hits=list(hits),
        qc=qc,
    )
