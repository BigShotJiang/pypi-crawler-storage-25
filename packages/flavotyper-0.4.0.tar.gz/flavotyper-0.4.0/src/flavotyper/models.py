from __future__ import annotations

"""Shared typed data models used by all pipeline stages.

These dataclasses are shared between modules:
- aligners produce `Hit`,
- QC produces `QCMetrics`,
- rule engine produces `TypingCall`,
- reporting consumes all of them.
"""

from dataclasses import dataclass, field, asdict

from flavotyper.provenance import utc_now_iso


@dataclass(frozen=True)
class Hit:
    """One BLAST hit between a genome contig and one marker.

    Coordinates are 1-based inclusive, matching BLAST tabular conventions.

    `strand` records the orientation of the marker gene on the input genome:
    "+" if sstart <= send in the original BLAST output (marker found in the
    forward direction), "-" if sstart > send (marker on reverse complement).
    Defaults to "+" when the aligner does not report strand.
    """

    gene: str
    identity: float
    coverage: float
    contig: str
    start: int
    end: int
    marker_start: int | None = None
    marker_end: int | None = None
    marker_length: int | None = None
    alignment_length: int | None = None
    strand: str = "+"


@dataclass(frozen=True)
class SpeciesCheckResult:
    """ANI-based species verification result for one sample."""

    checked: bool
    passed: bool | None
    best_ani: float | None
    best_reference: str | None
    message: str | None = None


@dataclass(frozen=True)
class QCMetrics:
    """Assembly + species QC summary.

    `quality_passed` is the QC gate used by the pipeline to decide whether
    typing is allowed for the sample.
    """

    n_contigs: int
    genome_size: int
    gc_percent: float
    species: SpeciesCheckResult
    quality_passed: bool
    quality_messages: list[str] = field(default_factory=list)
    quality_warnings: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class TypingCall:
    """Final per-sample output object.

    If QC fails, fields are still populated with a valid "NotTyped" record,
    so downstream reporting can stay uniform.
    """

    sample: str
    sample_key: str
    typed: bool
    o_type: str
    r_type: str
    s_type: str
    serotype: str
    ambiguity_state: str = "Resolved"
    reason_codes: list[str] = field(default_factory=list)
    alternative_serotypes: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    present_markers: list[str] = field(default_factory=list)
    hits: list[Hit] = field(default_factory=list)
    raw_hits: list[Hit] = field(default_factory=list)
    qc: QCMetrics | None = None
    serotype_reference: str = ""

    def to_dict(self) -> dict:
        """Convert to JSON-serializable dictionary for JSONL output."""

        return asdict(self)


@dataclass(frozen=True)
class RunMetadata:
    """Run-level metadata saved once per execution."""

    tool_version: str
    db_name: str
    db_version: str
    db_sha256: str
    db_rules_sha256: str
    db_markers_sha256: str
    run_id: str
    generated_at_utc: str
    min_identity: float
    min_coverage: float
    aligner: str
    species_check_enabled: bool

    @staticmethod
    def now(tool_version: str, db_name: str, db_version: str, db_sha256: str,
            db_rules_sha256: str, db_markers_sha256: str, run_id: str,
            min_identity: float, min_coverage: float, aligner: str,
            species_check_enabled: bool) -> "RunMetadata":
        """Build metadata with a UTC timestamp generated at runtime."""

        return RunMetadata(
            tool_version=tool_version,
            db_name=db_name,
            db_version=db_version,
            db_sha256=db_sha256,
            db_rules_sha256=db_rules_sha256,
            db_markers_sha256=db_markers_sha256,
            run_id=run_id,
            generated_at_utc=utc_now_iso(),
            min_identity=min_identity,
            min_coverage=min_coverage,
            aligner=aligner,
            species_check_enabled=species_check_enabled,
        )

    def to_dict(self) -> dict:
        """Serialize run metadata for JSON output."""

        return asdict(self)
