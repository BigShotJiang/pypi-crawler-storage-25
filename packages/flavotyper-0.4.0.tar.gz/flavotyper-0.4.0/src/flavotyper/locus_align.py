from __future__ import annotations

"""Genome-vs-locus alignment (second BLASTN run).

Aligns the input genome against the reference locus for the resolved serotype
to determine where the locus sits on the genome and how similar it is.

Produces:
  - % identity and % coverage of the reference locus in the input genome
  - The primary HSPs (only those that directly host at least one marker gene)
  - The typing hits for the present markers (passed through for the PNG renderer)
  - A pairwise alignment text run only on the selected contigs
  - The detected locus sequence(s) extracted in FASTA format
"""

import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path

from flavotyper.exceptions import FlavoTyperError
from flavotyper.io import read_fasta
from flavotyper.locus import LocusRecord
from flavotyper.models import Hit


# Data models

@dataclass(frozen=True)
class LocusHSP:
    """One HSP from the genome-vs-locus blastn.

    All coordinates are 1-based inclusive.
    genome_start ≤ genome_end and locus_start ≤ locus_end regardless of strand.
    """

    contig: str
    genome_start: int
    genome_end: int
    locus_start: int
    locus_end: int
    locus_strand: str     # "+" or "-"
    identity: float
    alignment_length: int


@dataclass
class LocusAlignResult:
    """Result of aligning one sample's genome against the reference locus."""

    serotype: str
    reference_genome: str  # reference strain name
    locus_length: int      # length of the reference locus (nt)
    pct_identity: float    # weighted-average % identity over primary HSPs
    pct_coverage: float    # % of reference locus covered by primary HSPs
    hsps: list[LocusHSP]   # primary HSPs sorted by (contig, genome_start)
    marker_hits: list[Hit] # marker-detection hits passed through to the PNG renderer
    alignment_text: str = field(default="")       # filtered pairwise blastn output
    locus_fasta_text: str = field(default="")     # detected locus sequence(s) in FASTA


# Public entry point

def align_genome_to_locus(
    genome_path: Path,
    locus_record: LocusRecord,
    typing_hits: list[Hit],
    present_markers: list[str],
    threads: int = 1,
    sample_name: str = "sample",
) -> LocusAlignResult:
    """Run blastn of the input genome against the reference locus.

    Parameters
    ----------
    genome_path:
        Path to the input genome FASTA (query).
    locus_record:
        Reference locus for the resolved serotype (subject).
    typing_hits:
        Above-threshold marker-detection hits (TypingCall.hits).
    present_markers:
        Marker names that drove the serotype call.
    threads:
        CPU threads passed to blastn.
    sample_name:
        Sample identifier used in the output FASTA headers.
    """
    with tempfile.TemporaryDirectory(prefix="flavotyper_locus_align_") as tmpdir:
        tmp = Path(tmpdir)
        locus_fasta = tmp / "locus.fasta"
        locus_fasta.write_text(
            f">{locus_record.serotype}\n{locus_record.sequence}\n",
            encoding="utf-8",
        )
        tabular_out = _run_blastn_tabular(genome_path, locus_fasta, threads)

    all_hsps    = _parse_locus_hsps(tabular_out)
    marker_hits = [h for h in typing_hits if h.gene in set(present_markers)]
    primary     = _select_primary_hsps(all_hsps, marker_hits)

    # Extract sequences for only the selected contigs.
    selected_contigs = {h.contig for h in primary}
    contig_seqs      = _extract_contig_seqs(genome_path, selected_contigs)

    # Build the extracted locus FASTA first (one record per selected HSP span).
    locus_fasta_text = _extract_locus_fasta(sample_name, primary, contig_seqs)

    # Pairwise blastn uses the extracted locus subsequences as query — this
    # ensures the alignment text describes exactly the sequences shown in the
    # map, with no off-target hits from other regions of the same contig.
    with tempfile.TemporaryDirectory(prefix="flavotyper_locus_pair_") as tmpdir2:
        tmp2 = Path(tmpdir2)
        locus_fasta2   = tmp2 / "locus.fasta"
        extracted_query = tmp2 / "extracted_locus.fasta"
        locus_fasta2.write_text(
            f">{locus_record.serotype}\n{locus_record.sequence}\n",
            encoding="utf-8",
        )
        extracted_query.write_text(locus_fasta_text, encoding="utf-8")
        pairwise_out = _run_blastn_pairwise(extracted_query, locus_fasta2, threads)

    return LocusAlignResult(
        serotype=locus_record.serotype,
        reference_genome=locus_record.genome,
        locus_length=locus_record.seq_len,
        pct_identity=_compute_identity(primary),
        pct_coverage=_compute_coverage(primary, locus_record.seq_len),
        hsps=sorted(primary, key=lambda h: (h.contig, h.genome_start)),
        marker_hits=marker_hits,
        alignment_text=pairwise_out,
        locus_fasta_text=locus_fasta_text,
    )


# BLASTN runners

def _run_blastn_tabular(genome_path: Path, locus_fasta: Path, threads: int) -> str:
    """Run blastn and return tabular output.

    Columns: qseqid sseqid pident qstart qend sstart send length
    """
    cmd = [
        "blastn",
        "-query",       str(genome_path),
        "-subject",     str(locus_fasta),
        "-outfmt",      "6 qseqid sseqid pident qstart qend sstart send length",
        "-task",        "blastn",
        "-num_threads", str(threads),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if proc.returncode != 0:
        raise FlavoTyperError(
            f"blastn (genome-vs-locus) failed: {proc.stderr.strip()}"
        )
    return proc.stdout


def _run_blastn_pairwise(genome_path: Path, locus_fasta: Path, threads: int) -> str:
    """Run blastn on the extracted locus sequences and return pairwise alignment text.

    -evalue 1e-10  : discards spurious short-fragment hits
    -max_hsps 1    : one alignment block per contig (the best HSP only)
    """
    cmd = [
        "blastn",
        "-query",       str(genome_path),
        "-subject",     str(locus_fasta),
        "-outfmt",      "0",
        "-task",        "blastn",
        "-evalue",      "1e-10",
        "-max_hsps",    "1",
        "-num_threads", str(threads),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if proc.returncode != 0:
        raise FlavoTyperError(
            f"blastn pairwise (genome-vs-locus) failed: {proc.stderr.strip()}"
        )
    return proc.stdout


# Parsing

def _parse_locus_hsps(text: str) -> list[LocusHSP]:
    """Parse blastn tabular output into LocusHSP records."""
    hsps: list[LocusHSP] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        fields = line.split("\t")
        if len(fields) != 8:
            raise FlavoTyperError(
                f"Unexpected genome-vs-locus blastn output: {line!r}"
            )
        qseqid, _sseqid, pident, qstart, qend, sstart, send, length = fields
        q1, q2 = int(qstart), int(qend)
        s1, s2 = int(sstart),  int(send)
        hsps.append(LocusHSP(
            contig=qseqid.strip(),
            genome_start=min(q1, q2),
            genome_end=max(q1, q2),
            locus_start=min(s1, s2),
            locus_end=max(s1, s2),
            locus_strand="+" if s1 <= s2 else "-",
            identity=float(pident),
            alignment_length=int(length),
        ))
    return hsps


# HSP selection

def _select_primary_hsps(
    hsps: list[LocusHSP],
    marker_hits: list[Hit],
) -> list[LocusHSP]:
    """Keep only HSPs that directly overlap at least one marker-detection hit.

    An HSP is retained only if it physically contains a detected marker.
    Falls back to the single best HSP by alignment length when no marker
    hits are available (should not occur for resolved serotypes).
    """
    if not hsps:
        return []
    if not marker_hits:
        return [max(hsps, key=lambda h: h.alignment_length)]

    selected = [
        h for h in hsps
        if any(
            h.contig == hit.contig
            and h.genome_start <= hit.end
            and h.genome_end   >= hit.start
            for hit in marker_hits
        )
    ]
    return selected if selected else [max(hsps, key=lambda h: h.alignment_length)]


# Contig sequence helpers

def _extract_contig_seqs(
    genome_path: Path,
    contig_names: set[str],
) -> dict[str, str]:
    """Return sequences for the requested contigs from the genome FASTA."""
    contigs = read_fasta(genome_path)
    return {name: contigs[name] for name in contig_names if name in contigs}


def _reverse_complement(seq: str) -> str:
    table = str.maketrans("ACGTNacgtn", "TGCANtgcan")
    return seq.translate(table)[::-1]


def _extract_locus_fasta(
    sample_name: str,
    hsps: list[LocusHSP],
    contig_seqs: dict[str, str],
) -> str:
    """Build a FASTA string with one record per selected contig spanning the
    full union of HSP coordinates on that contig."""

    # Merge all HSPs per contig into one span.
    contig_spans: dict[str, tuple[int, int, str]] = {}
    for h in hsps:
        if h.contig not in contig_spans:
            contig_spans[h.contig] = (h.genome_start, h.genome_end, h.locus_strand)
        else:
            lo, hi, strand = contig_spans[h.contig]
            contig_spans[h.contig] = (min(lo, h.genome_start), max(hi, h.genome_end), strand)

    lines: list[str] = []
    for contig, (start, end, strand) in sorted(contig_spans.items()):
        seq    = contig_seqs.get(contig, "")
        subseq = seq[start - 1 : end]   # 1-based inclusive → 0-based slice
        if strand == "-":
            subseq = _reverse_complement(subseq)
        strand_label = "(+)" if strand == "+" else "(-)"
        lines.append(
            f">{sample_name} | {contig} | {start}-{end} | strand {strand_label}"
        )
        lines.append(subseq)

    return "\n".join(lines) + "\n" if lines else ""


# Statistics

def _compute_identity(hsps: list[LocusHSP]) -> float:
    """Weighted-average % identity (weight = alignment length)."""
    if not hsps:
        return 0.0
    total = sum(h.alignment_length for h in hsps)
    return sum(h.identity * h.alignment_length for h in hsps) / total if total else 0.0


def _compute_coverage(hsps: list[LocusHSP], locus_length: int) -> float:
    """% of the reference locus covered by at least one primary HSP."""
    if not hsps or locus_length == 0:
        return 0.0
    intervals = sorted((h.locus_start, h.locus_end) for h in hsps)
    merged: list[tuple[int, int]] = [intervals[0]]
    for start, end in intervals[1:]:
        prev_s, prev_e = merged[-1]
        if start <= prev_e + 1:
            merged[-1] = (prev_s, max(prev_e, end))
        else:
            merged.append((start, end))
    covered = sum(e - s + 1 for s, e in merged)
    return min(100.0 * covered / locus_length, 100.0)
