from __future__ import annotations

"""Reference locus database for the locus comparison feature.

All locus data is bundled in a single file: reference_loci.fasta.
Each record holds:

  - the locus nucleotide sequence (FASTA body)
  - reference strain, genome coordinates, locus length   (header)
  - GenBank accession, PMID                              (header)
  - per-marker positions within the locus                (header, marker_* tokens)

Header format (pipe-delimited, first token is the serotype):

  >O:1-S0-R1V1|genome=Flavobacterium_psychrophilum_DK001|start=...|end=...
   |strand=...|length=...|genbank=GCA_...|pmid=...
   |marker_wzy1=start:end:strand:gene_name
   |marker_r1_core=...

FlavoTyper reads the file once at startup via LocusDB.load().
"""

from dataclasses import dataclass
from pathlib import Path

from flavotyper.exceptions import FlavoTyperError


# Data models

@dataclass(frozen=True)
class LocusRecord:
    """One reference locus for a known serotype."""

    serotype: str
    genome: str              # reference strain name (spaces restored)
    seq_len: int             # locus length in nt
    sequence: str            # full locus nucleotide sequence
    genome_start: int        # locus start coordinate on the reference genome
    genome_end: int          # locus end coordinate on the reference genome
    genome_strand: str       # "+"/"-" or "1"/"-1" depending on source
    genbank_accession: str   # "NA" when absent
    pmid: str                # "NA" when absent

    @property
    def has_genbank(self) -> bool:
        return self.genbank_accession != "NA"

    @property
    def has_pmid(self) -> bool:
        return self.pmid != "NA"


@dataclass(frozen=True)
class MarkerPosition:
    """Position of one marker gene within the reference locus sequence.

    Coordinates are 1-based inclusive, on the locus sequence.
    """

    serotype: str
    marker: str                  # internal FlavoTyper name: used as lookup key
    gene_name: str               # user-facing display name (e.g. "wfpC; wfpD; wfpE")
    marker_start_in_locus: int
    marker_end_in_locus: int
    strand: str

    @property
    def length(self) -> int:
        return self.marker_end_in_locus - self.marker_start_in_locus + 1


# LocusDB

class LocusDB:
    """In-memory reference locus database, loaded from reference_loci.fasta."""

    def __init__(
        self,
        records: dict[str, LocusRecord],
        marker_positions: dict[str, list[MarkerPosition]],
    ) -> None:
        self._records = records
        self._marker_positions = marker_positions

    @classmethod
    def load(cls, fasta_path: Path) -> "LocusDB":
        """Parse reference_loci.fasta and return a LocusDB."""
        if not fasta_path.exists():
            raise FlavoTyperError(
                f"Locus reference database not found: {fasta_path}"
            )

        records, positions = _parse_enriched_fasta(fasta_path)
        if not records:
            raise FlavoTyperError(f"{fasta_path.name} contains no locus records.")
        return cls(records, positions)

    def __len__(self) -> int:
        return len(self._records)

    @property
    def known_serotypes(self) -> frozenset[str]:
        return frozenset(self._records)

    def is_known(self, serotype: str) -> bool:
        return serotype in self._records

    def lookup(self, serotype: str) -> LocusRecord | None:
        return self._records.get(serotype)

    def get_marker_positions(self, serotype: str) -> list[MarkerPosition]:
        return self._marker_positions.get(serotype, [])


# FASTA parser

def _parse_enriched_fasta(
    path: Path,
) -> tuple[dict[str, LocusRecord], dict[str, list[MarkerPosition]]]:
    """Parse reference_loci.fasta → (records, marker_positions)."""

    records: dict[str, LocusRecord] = {}
    positions: dict[str, list[MarkerPosition]] = {}

    current_header: str | None = None
    current_seq: list[str] = []

    def flush() -> None:
        nonlocal current_header
        if current_header is None:
            return
        sequence = "".join(current_seq)
        record, markers = _parse_header(current_header, sequence, path.name)
        if record.serotype in records:
            raise FlavoTyperError(
                f"{path.name}: duplicate serotype '{record.serotype}'."
            )
        records[record.serotype] = record
        if markers:
            positions[record.serotype] = sorted(
                markers, key=lambda m: m.marker_start_in_locus
            )

    with path.open("rt", encoding="utf-8") as fh:
        for raw in fh:
            line = raw.rstrip("\n")
            if not line:
                continue
            if line.startswith(">"):
                flush()
                current_header = line[1:]
                current_seq = []
            else:
                current_seq.append(line.strip())
    flush()

    return records, positions


def _parse_header(
    header: str,
    sequence: str,
    source_name: str,
) -> tuple[LocusRecord, list[MarkerPosition]]:
    """Split one header into a LocusRecord + its MarkerPosition list."""

    tokens = header.split("|")
    serotype = tokens[0].strip()
    if not serotype:
        raise FlavoTyperError(f"{source_name}: header is missing a serotype.")

    fields: dict[str, str] = {}
    marker_tokens: list[tuple[str, str]] = []
    for token in tokens[1:]:
        if "=" not in token:
            continue
        key, _, value = token.partition("=")
        key = key.strip()
        value = value.strip()
        if key.startswith("marker_"):
            marker_tokens.append((key[len("marker_"):], value))
        else:
            fields[key] = value

    try:
        record = LocusRecord(
            serotype=serotype,
            genome=fields.get("genome", "").replace("_", " "),
            seq_len=int(fields["length"]),
            sequence=sequence,
            genome_start=int(fields["start"]),
            genome_end=int(fields["end"]),
            genome_strand=fields.get("strand", ""),
            genbank_accession=fields.get("genbank", "NA"),
            pmid=fields.get("pmid", "NA"),
        )
    except (KeyError, ValueError) as exc:
        raise FlavoTyperError(
            f"{source_name}: invalid header for '{serotype}': {exc}"
        ) from exc

    markers = [
        _parse_marker(serotype, name, value, source_name)
        for name, value in marker_tokens
    ]
    return record, markers


def _parse_marker(
    serotype: str,
    marker: str,
    value: str,
    source_name: str,
) -> MarkerPosition:
    """Decode start:end:strand:gene_name."""

    parts = value.split(":")
    if len(parts) != 4:
        raise FlavoTyperError(
            f"{source_name}: marker '{marker}' for {serotype} has "
            f"{len(parts)} fields, expected 4."
        )
    start, end, strand, gene_name = parts
    try:
        return MarkerPosition(
            serotype=serotype,
            marker=marker,
            gene_name=gene_name,
            marker_start_in_locus=int(start),
            marker_end_in_locus=int(end),
            strand=strand,
        )
    except ValueError as exc:
        raise FlavoTyperError(
            f"{source_name}: could not parse marker '{marker}' "
            f"for {serotype}: {exc}"
        ) from exc
