from __future__ import annotations

"""Provenance and reproducibility helpers."""

from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
from uuid import uuid4


def file_sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    """Return SHA-256 hex digest for a file."""

    digest = sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


@dataclass(frozen=True)
class InputSampleManifest:
    """Manifest entry for one input genome."""

    sample: str
    sample_key: str
    path: str
    size_bytes: int
    sha256: str

    def to_dict(self) -> dict:
        return asdict(self)


def new_run_id() -> str:
    """Return unique run identifier."""

    return str(uuid4())


def utc_now_iso() -> str:
    """Return UTC timestamp in ISO 8601 format."""

    return datetime.now(timezone.utc).isoformat()
