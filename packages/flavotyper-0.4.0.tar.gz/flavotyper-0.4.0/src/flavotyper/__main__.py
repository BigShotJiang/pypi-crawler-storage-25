"""Executable module entrypoint.

Allows:
    python -m flavotyper type ...
"""

from flavotyper.cli import main


if __name__ == "__main__":
    main()
