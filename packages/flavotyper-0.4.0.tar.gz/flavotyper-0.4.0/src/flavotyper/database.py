from __future__ import annotations

"""Database schema and loader for FlavoTyper typing rules.

The database is split into:
- a YAML rules file (typing logic and marker references),
- a FASTA file (marker sequences + optional header metadata).
"""

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
import yaml

from flavotyper.exceptions import ValidationError
from flavotyper.provenance import file_sha256


@dataclass(frozen=True)
class Marker:
    """One marker sequence entry."""

    name: str
    sequence: str
    header: str | None = None


@dataclass(frozen=True)
class DistanceRule:
    """Inter-marker distance constraint used by R1-variants."""

    name: str
    left_marker: str
    right_marker: str
    min_distance: int
    max_distance: int


@dataclass(frozen=True)
class RVariantRule:
    """Definition of one R-variant assignment rule."""

    name: str
    base_group: str
    required_markers: tuple[str, ...]
    distance_rule: str | None = None


@dataclass(frozen=True)
class SerotypeDB:
    """Fully validated in-memory representation of the rules database."""

    name: str
    version: str
    source_path: str
    marker_fasta_path: str
    sha256: str
    rules_sha256: str
    markers_sha256: str
    markers: dict[str, Marker]
    o_types: dict[str, str]
    r_groups: dict[str, tuple[str, ...]]
    s1_markers: tuple[str, ...]
    o_types_default_r0: tuple[str, ...]
    r_variants: tuple[RVariantRule, ...]
    distance_rules: dict[str, DistanceRule]

    @property
    def gene_sequences(self) -> dict[str, str]:
        """Convenience map for the BLAST layer: ``marker -> sequence``."""

        return {key: marker.sequence for key, marker in self.markers.items()}


def _as_tuple(values: list[str], field: str) -> tuple[str, ...]:
    """Validate list-like marker field and convert it to tuple."""

    if not isinstance(values, list) or not values:
        raise ValidationError(f"'{field}' must be a non-empty list of marker names.")
    return tuple(str(v) for v in values)


def _parse_markers_fasta(path: Path) -> dict[str, Marker]:
    """Load marker sequences from FASTA using first token in header as marker name."""

    if not path.exists() or not path.is_file():
        raise ValidationError(f"Marker FASTA not found: {path}")

    markers: dict[str, Marker] = {}
    header: str | None = None
    marker_name: str | None = None
    seq_lines: list[str] = []

    def flush_current() -> None:
        nonlocal header, marker_name, seq_lines
        if marker_name is None:
            return
        sequence = "".join(seq_lines).replace(" ", "").upper()
        if not sequence:
            raise ValidationError(f"Marker '{marker_name}' has an empty sequence in FASTA.")
        allowed = set("ACGTN")
        if any(base not in allowed for base in sequence):
            raise ValidationError(
                f"Marker '{marker_name}' contains unsupported characters (allowed: A,C,G,T,N)."
            )
        markers[marker_name] = Marker(name=marker_name, sequence=sequence, header=header)
        header = None
        marker_name = None
        seq_lines = []

    with path.open("rt", encoding="utf-8") as handle:
        for line_no, raw in enumerate(handle, start=1):
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                flush_current()
                header = line[1:].strip()
                if not header:
                    raise ValidationError(f"Empty FASTA header at line {line_no}.")
                marker_name = header.split()[0]
                if marker_name in markers:
                    raise ValidationError(f"Duplicate marker '{marker_name}' in FASTA.")
                continue

            if marker_name is None:
                raise ValidationError(f"FASTA sequence found before first header at line {line_no}.")
            seq_lines.append(line)

    flush_current()

    if not markers:
        raise ValidationError("Marker FASTA is empty.")
    return markers


def load_database(path: Path) -> SerotypeDB:
    """Load and validate YAML rules + FASTA marker database from disk."""

    with path.open("rt", encoding="utf-8") as handle:
        payload = yaml.safe_load(handle)
    if not isinstance(payload, dict):
        raise ValidationError("Database file must contain a YAML object.")

    # ---- Required top-level keys ----
    for key in (
        "name",
        "version",
        "marker_fasta",
        "o_types",
        "r_groups",
        "s1_markers",
        "distance_rules",
        "r_variants",
    ):
        if key not in payload:
            raise ValidationError(f"Database missing required key: {key}")

    # ---- Marker FASTA ----
    raw_marker_fasta = payload["marker_fasta"]
    marker_fasta_path = Path(str(raw_marker_fasta))
    if not marker_fasta_path.is_absolute():
        marker_fasta_path = path.parent / marker_fasta_path
    markers = _parse_markers_fasta(marker_fasta_path)
    rules_sha = file_sha256(path)
    markers_sha = file_sha256(marker_fasta_path)
    combined_sha = sha256(f"{rules_sha}:{markers_sha}".encode("utf-8")).hexdigest()

    def require_marker(marker_name: str, context: str) -> None:
        """Raise a targeted error when rules reference unknown markers."""

        if marker_name not in markers:
            raise ValidationError(f"Unknown marker '{marker_name}' referenced in {context}.")

    # ---- O-type mapping ----
    raw_o_types = payload["o_types"]
    if not isinstance(raw_o_types, dict) or not raw_o_types:
        raise ValidationError("'o_types' must be a non-empty object mapping O labels to marker names.")

    o_types = {str(k): str(v) for k, v in raw_o_types.items()}
    for o_label, marker_name in o_types.items():
        require_marker(marker_name, f"o_types[{o_label}]")

    # ---- R-group base rules ----
    raw_r_groups = payload["r_groups"]
    if not isinstance(raw_r_groups, dict) or not raw_r_groups:
        raise ValidationError("'r_groups' must be a non-empty object mapping R groups to required markers.")

    r_groups: dict[str, tuple[str, ...]] = {}
    for group_name, group_markers in raw_r_groups.items():
        marker_tuple = _as_tuple(group_markers, f"r_groups[{group_name}]")
        for marker_name in marker_tuple:
            require_marker(marker_name, f"r_groups[{group_name}]")
        r_groups[str(group_name)] = marker_tuple

    # ---- S1 marker set ----
    s1_markers = _as_tuple(payload["s1_markers"], "s1_markers")
    for marker_name in s1_markers:
        require_marker(marker_name, "s1_markers")

    # ---- Required distance rules ----
    raw_distance_rules = payload["distance_rules"]
    if not isinstance(raw_distance_rules, dict):
        raise ValidationError("'distance_rules' must be an object.")

    distance_rules: dict[str, DistanceRule] = {}
    for rule_name, rule_body in raw_distance_rules.items():
        if not isinstance(rule_body, dict):
            raise ValidationError(f"distance_rules[{rule_name}] must be an object.")

        for key in ("left_marker", "right_marker", "min_distance", "max_distance"):
            if key not in rule_body:
                raise ValidationError(f"distance_rules[{rule_name}] missing key: {key}")

        left_marker = str(rule_body["left_marker"])
        right_marker = str(rule_body["right_marker"])
        require_marker(left_marker, f"distance_rules[{rule_name}]")
        require_marker(right_marker, f"distance_rules[{rule_name}]")

        min_distance = int(rule_body["min_distance"])
        max_distance = int(rule_body["max_distance"])
        if min_distance > max_distance:
            raise ValidationError(f"distance_rules[{rule_name}] has min_distance > max_distance.")

        distance_rules[str(rule_name)] = DistanceRule(
            name=str(rule_name),
            left_marker=left_marker,
            right_marker=right_marker,
            min_distance=min_distance,
            max_distance=max_distance,
        )

    # ---- Optional O-type-without-R declarations ----
    raw_o_types_default_r0 = payload.get("o_types_default_r0", [])
    if not isinstance(raw_o_types_default_r0, list):
        raise ValidationError("'o_types_default_r0' must be a list when provided.")
    o_types_default_r0 = tuple(str(v) for v in raw_o_types_default_r0)
    for o_label in o_types_default_r0:
        if o_label not in o_types:
            raise ValidationError(f"o_types_default_r0 references unknown O label '{o_label}'.")

    # ---- Required R-variant rules ----
    raw_r_variants = payload["r_variants"]
    if not isinstance(raw_r_variants, list):
        raise ValidationError("'r_variants' must be a list.")
    if not raw_r_variants:
        raise ValidationError("'r_variants' must not be empty.")

    r_variants: list[RVariantRule] = []
    for idx, variant in enumerate(raw_r_variants):
        if not isinstance(variant, dict):
            raise ValidationError(f"r_variants[{idx}] must be an object.")

        for key in ("name", "base_group", "required_markers"):
            if key not in variant:
                raise ValidationError(f"r_variants[{idx}] missing key: {key}")

        base_group = str(variant["base_group"])
        if base_group not in r_groups:
            raise ValidationError(f"r_variants[{idx}] references unknown base_group '{base_group}'.")

        required_markers = _as_tuple(variant["required_markers"], f"r_variants[{idx}].required_markers")
        for marker_name in required_markers:
            require_marker(marker_name, f"r_variants[{idx}]")

        distance_rule = variant.get("distance_rule")
        if distance_rule is not None:
            distance_rule = str(distance_rule)
            if distance_rule not in distance_rules:
                raise ValidationError(
                    f"r_variants[{idx}] references unknown distance_rule '{distance_rule}'."
                )

        r_variants.append(
            RVariantRule(
                name=str(variant["name"]),
                base_group=base_group,
                required_markers=required_markers,
                distance_rule=distance_rule,
            )
        )

    return SerotypeDB(
        name=str(payload["name"]),
        version=str(payload["version"]),
        source_path=str(path),
        marker_fasta_path=str(marker_fasta_path),
        sha256=combined_sha,
        rules_sha256=rules_sha,
        markers_sha256=markers_sha,
        markers=markers,
        o_types=o_types,
        r_groups=r_groups,
        s1_markers=s1_markers,
        o_types_default_r0=o_types_default_r0,
        r_variants=tuple(r_variants),
        distance_rules=distance_rules,
    )
