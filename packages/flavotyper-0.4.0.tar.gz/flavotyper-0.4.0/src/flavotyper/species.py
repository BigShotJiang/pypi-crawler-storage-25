from __future__ import annotations

"""Species verification utilities (ANI-based).

The QC gate uses fastANI to verify that the input genome is sufficiently close
(to ANI threshold) to trusted species references.
"""

from pathlib import Path
import subprocess
import shutil
import tempfile
import os

from flavotyper.exceptions import DependencyError, FlavoTyperError
from flavotyper.models import SpeciesCheckResult


def check_fastani_dependency() -> None:
    """Fail fast if fastANI executable is unavailable."""

    if shutil.which("fastANI") is None:
        raise DependencyError("fastANI not found in PATH. Install fastANI or use --no-species-check.")


def parse_fastani_output(text: str) -> tuple[float | None, str | None]:
    """Extract best ANI value and associated reference from fastANI output."""

    best_ani: float | None = None
    best_ref: str | None = None

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue

        fields = line.split("\t")
        if len(fields) < 3:
            continue

        # Standard fastANI columns: query, reference, ANI, ...
        reference = fields[1]
        try:
            ani = float(fields[2])
        except ValueError:
            # Ignore malformed rows and keep scanning for valid ANI hits.
            continue

        if best_ani is None or ani > best_ani:
            best_ani = ani
            best_ref = reference

    return best_ani, best_ref


def verify_species_fastani(genome_path: Path, reference_genome: Path, threads: int,
                           ani_threshold: float) -> SpeciesCheckResult:
    """Run fastANI and convert output into a pass/fail species decision."""

    # Write fastANI output to a temp file; clean up explicitly regardless of outcome.
    tmp_fd, tmp_path = tempfile.mkstemp(suffix=".txt")
    os.close(tmp_fd)

    try:
        cmd = [
            "fastANI",
            "--query",
            str(genome_path),
            "--ref",
            str(reference_genome),
            "--threads",
            str(threads),
            "--output",
            tmp_path,
        ]

        proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
        if proc.returncode != 0:
            raise FlavoTyperError(
                f"fastANI failed for {genome_path.name}: {proc.stderr.strip()}"
            )

        out_text = Path(tmp_path).read_text(encoding="utf-8")

    finally:
        Path(tmp_path).unlink(missing_ok=True)

    best_ani, best_ref = parse_fastani_output(out_text)

    # No ANI hits at all -> fail species gate explicitly.
    if best_ani is None:
        return SpeciesCheckResult(
            checked=True,
            passed=False,
            best_ani=None,
            best_reference=None,
            message="No fastANI hits against provided species references.",
        )

    passed = best_ani >= ani_threshold
    msg = None if passed else f"Best ANI {best_ani:.2f} below threshold {ani_threshold:.2f}."

    return SpeciesCheckResult(
        checked=True,
        passed=passed,
        best_ani=best_ani,
        best_reference=best_ref,
        message=msg,
    )


def unchecked_species_result() -> SpeciesCheckResult:
    """Return neutral species result when species-check is disabled."""

    return SpeciesCheckResult(
        checked=False,
        passed=None,
        best_ani=None,
        best_reference=None,
        message=None,
    )
