from __future__ import annotations

"""Main orchestration layer.

Per-sample steps (inside the main loop):
  1) Read genome FASTA
  2) Species check via fastANI (optional)
  3) Assembly QC gate
  4) BLASTN alignment against marker database
  5) Rule-based serotype assignment + report append
  6) Locus comparison: second BLASTN + PNG map (Resolved serotypes only, optional)

Run-level step (after the loop):
  7) Write run metadata and input manifest JSON
"""

from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
import sys
import traceback

from flavotyper import __version__
from flavotyper.align import (
    AlignmentRequest,
    BlastnAligner,
    build_marker_fasta,
    check_blast_dependencies,
    make_blast_database,
)
from flavotyper.config import RunConfig, build_sample_identities
from flavotyper.database import load_database
from flavotyper.io import read_fasta
from flavotyper.locus import LocusDB, LocusRecord
from flavotyper.locus_align import align_genome_to_locus
from flavotyper.locus_map import render_locus_map
from flavotyper.models import RunMetadata, TypingCall, QCMetrics, SpeciesCheckResult
from flavotyper.report import append_call_reports, init_streaming_reports, write_run_metadata
from flavotyper.typing_rules import call_serotype
from flavotyper.species import check_fastani_dependency, verify_species_fastani, unchecked_species_result
from flavotyper.provenance import InputSampleManifest, file_sha256, new_run_id


def _qc_metrics(contigs: dict[str, str], species_result: SpeciesCheckResult, config: RunConfig) -> QCMetrics:
    """Compute per-sample QC metrics and pass/fail messages."""

    genome_size = sum(len(seq) for seq in contigs.values())
    n_contigs = len(contigs)

    gc_count = sum(seq.count("G") + seq.count("C") for seq in contigs.values())
    gc_percent = (100.0 * gc_count / genome_size) if genome_size else 0.0

    messages: list[str] = []
    warnings: list[str] = []

    # Assembly-size expectation interval (warning only).
    if genome_size < config.expected_genome_size_min:
        warnings.append(
            f"Genome size {genome_size} bp is smaller than expected interval "
            f"[{config.expected_genome_size_min}, {config.expected_genome_size_max}] bp."
        )
    elif genome_size > config.expected_genome_size_max:
        warnings.append(
            f"Genome size {genome_size} bp is larger than expected interval "
            f"[{config.expected_genome_size_min}, {config.expected_genome_size_max}] bp."
        )

    # Contig count thresholds (warning only).
    if n_contigs > config.high_warn_contigs_over:
        warnings.append(
            f"Contig count {n_contigs} is very high (>{config.high_warn_contigs_over}); "
            "typing may be less reliable on fragmented assemblies."
        )
    elif n_contigs > config.warn_contigs_over:
        warnings.append(
            f"Contig count {n_contigs} is high (>{config.warn_contigs_over}); "
            "typing may be affected by assembly fragmentation."
        )

    # Species gate contributes to the same QC decision.
    if species_result.checked and species_result.passed is False:
        if species_result.message:
            messages.append(f"Species check failed: {species_result.message}")
        else:
            messages.append("Species check failed.")

    return QCMetrics(
        n_contigs=n_contigs,
        genome_size=genome_size,
        gc_percent=gc_percent,
        species=species_result,
        quality_passed=not messages,
        quality_messages=messages,
        quality_warnings=warnings,
    )


def _not_typed_call(sample_name: str, sample_key: str, qc: QCMetrics) -> TypingCall:
    """Build a standardized output record for QC-failed samples."""

    return TypingCall(
        sample=sample_name,
        sample_key=sample_key,
        typed=False,
        o_type="NotTyped",
        r_type="NotTyped",
        s_type="NotTyped",
        serotype="NotTyped",
        ambiguity_state="NotTyped",
        reason_codes=["QC_GATE_FAILED"],
        alternative_serotypes=[],
        warnings=[],
        present_markers=[],
        hits=[],
        raw_hits=[],
        qc=qc,
    )


def _locus_artifact_dir(outdir: Path, sample_key: str) -> Path:
    """Return the per-sample directory used for locus-comparison artifacts."""

    return outdir / f"{sample_key}_locus_analysis"


def _format_reference_sentence(record: LocusRecord) -> str:
    """Human-readable provenance sentence for a known reference serotype."""

    parts = [f"This serotype was observed in F. psychrophilum strain {record.genome}"]
    if record.has_genbank:
        parts.append(f"GenBank: {record.genbank_accession}")
    if record.has_pmid:
        parts.append(f"PMID: {record.pmid}")
    return "; ".join(parts) + "."


def _enrich_call_with_locus_provenance(
    call: TypingCall, locus_db: LocusDB
) -> TypingCall:
    """Attach reference-strain provenance or a novel-combination warning.

    Only applies to Resolved calls.  Returns a new TypingCall (dataclass is
    frozen) with `serotype_reference` populated or a warning appended.
    """

    if call.ambiguity_state != "Resolved":
        return call

    record = locus_db.lookup(call.serotype)
    if record is not None:
        return replace(call, serotype_reference=_format_reference_sentence(record))

    novel_msg = (
        f"This serotype ({call.serotype}) has not been previously observed "
        "— no reference strain available; locus map not generated."
    )
    return replace(call, warnings=[*call.warnings, novel_msg])


def _print_progress(done: int, total: int, sample_name: str) -> None:
    """Render an in-terminal progress bar to stderr."""

    if total <= 0:
        return
    width = 30
    fraction = done / total
    filled = int(width * fraction)
    bar = "#" * filled + "-" * (width - filled)
    print(
        f"\r[{bar}] {done}/{total} ({fraction * 100:5.1f}%) last={sample_name}",
        end="" if done < total else "\n",
        file=sys.stderr,
        flush=True,
    )


def run_typing(config: RunConfig) -> tuple[RunMetadata, list[TypingCall]]:
    """Run FlavoTyper on all requested genomes."""

    # Always validate first so we fail early with clear messages.
    config.validate()

    # Load and validate marker/rule database once.
    db = load_database(config.db_path)

    # Locus DB is always loaded: needed for novel-serotype detection on every
    # Resolved call, not just when locus map generation is requested.
    locus_db = LocusDB.load(config.locus_db_path)

    # Preflight external dependencies before any per-sample work.
    check_blast_dependencies()
    if config.species_check:
        check_fastani_dependency()

    calls: list[TypingCall] = []
    manifests: list[InputSampleManifest] = []
    sample_inputs = build_sample_identities(config.genomes)
    total_genomes = len(sample_inputs)

    # Initialize result files immediately so users can monitor progress while processing.
    init_streaming_reports(config.outdir)
    _print_progress(done=0, total=total_genomes, sample_name="starting")

    # Build marker BLAST DB once per run and reuse it for every sample.
    with TemporaryDirectory(prefix="flavotyper_blastdb_") as tmp_dir:
        tmp_path = Path(tmp_dir)
        marker_fasta = tmp_path / "markers.fasta"
        db_prefix = tmp_path / "markers_db"

        build_marker_fasta(db.gene_sequences, marker_fasta)
        make_blast_database(marker_fasta, db_prefix)

        aligner = BlastnAligner(
            db_prefix=db_prefix,
            threads=config.threads,
        )

        for idx, sample_input in enumerate(sample_inputs, start=1):
            genome_path = sample_input.genome_path
            sample_name = sample_input.sample_name
            sample_key = sample_input.sample_key
            manifests.append(
                InputSampleManifest(
                    sample=sample_name,
                    sample_key=sample_key,
                    path=str(genome_path),
                    size_bytes=genome_path.stat().st_size,
                    sha256=file_sha256(genome_path),
                )
            )

            # 1) Read genome
            contigs = read_fasta(genome_path)

            # 2) Species check (optional but enabled by default)
            species_result = unchecked_species_result()
            if config.species_check:
                species_result = verify_species_fastani(
                    genome_path=genome_path,
                    reference_genome=config.species_refs,
                    threads=config.threads,
                    ani_threshold=config.ani_threshold,
                )

            # 3) QC gate
            qc = _qc_metrics(contigs, species_result, config)

            if not qc.quality_passed:
                call = _not_typed_call(sample_name, sample_key, qc)
                calls.append(call)
                append_call_reports(config.outdir, call)
                _print_progress(done=idx, total=total_genomes, sample_name=sample_name)
                continue

            # 4) Alignment
            request = AlignmentRequest(sample=sample_key, genome_path=genome_path)
            hits = aligner.align(request)

            # 5) Rule-based serotype assignment
            call = call_serotype(
                sample=sample_name,
                sample_key=sample_key,
                db=db,
                hits=hits,
                min_identity=config.min_identity,
                min_coverage=config.min_coverage,
                qc=qc,
            )
            call = _enrich_call_with_locus_provenance(call, locus_db)
            calls.append(call)
            append_call_reports(config.outdir, call)

            # 6) Locus comparison (Resolved calls only)
            # The locus DB key is the serotype string in O:X-Sy-Rz format
            # (e.g. "O:1-S0-R1V1", "O:1-S1-R2"); for O:0 the key is "O:0".
            locus_key = call.serotype
            if (
                config.locus_analysis
                and call.ambiguity_state == "Resolved"
                and locus_db.is_known(locus_key)
            ):
                try:
                    locus_record = locus_db.lookup(locus_key)
                    locus_marker_positions = locus_db.get_marker_positions(locus_key)
                    align_result = align_genome_to_locus(
                        genome_path=genome_path,
                        locus_record=locus_record,
                        typing_hits=call.hits,
                        present_markers=call.present_markers,
                        threads=config.threads,
                        sample_name=sample_name,
                    )
                    locus_outdir = _locus_artifact_dir(config.outdir, sample_key)
                    locus_outdir.mkdir(parents=True, exist_ok=True)

                    aln_path = locus_outdir / f"{sample_key}_locus_alignment.txt"
                    aln_path.write_text(align_result.alignment_text, encoding="utf-8")
                    if align_result.locus_fasta_text:
                        fasta_path = locus_outdir / f"{sample_key}_locus_sequence.fasta"
                        fasta_path.write_text(align_result.locus_fasta_text, encoding="utf-8")
                    map_path = locus_outdir / f"{sample_key}_locus_map.png"
                    render_locus_map(
                        sample_name=sample_name,
                        locus_marker_positions=locus_marker_positions,
                        align_result=align_result,
                        output_path=map_path,
                        locus_record=locus_record,
                    )
                except Exception as exc:  # noqa: BLE001
                    print(
                        f"WARNING: locus comparison failed for {sample_key}: {exc}",
                        file=sys.stderr,
                    )
                    traceback.print_exc(file=sys.stderr)

            _print_progress(done=idx, total=total_genomes, sample_name=sample_name)

    # 7) Run-level metadata + output
    metadata = RunMetadata.now(
        tool_version=__version__,
        db_name=db.name,
        db_version=db.version,
        db_sha256=db.sha256,
        db_rules_sha256=db.rules_sha256,
        db_markers_sha256=db.markers_sha256,
        run_id=new_run_id(),
        min_identity=config.min_identity,
        min_coverage=config.min_coverage,
        aligner="blastn",
        species_check_enabled=config.species_check,
    )

    write_run_metadata(config.outdir, metadata, manifests)
    return metadata, calls
