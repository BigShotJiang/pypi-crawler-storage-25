from __future__ import annotations

"""Runtime configuration model and validation rules.

This module centralizes *all* user-controlled parameters.
The pipeline calls `RunConfig.validate()` before any expensive step.
"""

from collections import Counter
from dataclasses import dataclass
from importlib.resources import files as _pkg_files
from pathlib import Path

from flavotyper.exceptions import ValidationError


DEFAULT_EXPECTED_GENOME_SIZE_MIN = 2619202
DEFAULT_EXPECTED_GENOME_SIZE_MAX = 3122663

FASTA_EXTENSIONS: tuple[str, ...] = (
    ".fa", ".fna", ".fasta", ".fas", ".fa.gz", ".fna.gz", ".fasta.gz", ".fas.gz"
)


def _bundled(filename: str) -> Path:
    """Return the Path to a file bundled inside flavotyper/data/.

    Works correctly after pip install, conda install, and in a source checkout
    because it uses importlib.resources rather than __file__-relative navigation.
    """
    return Path(str(_pkg_files("flavotyper").joinpath(f"data/{filename}")))


BUNDLED_RULES_YAML  = _bundled("Flavotyper_rules.yaml")
BUNDLED_SPECIES_REF = _bundled("Flavobacterium_psychrophilum_NCIMB_1947T.fna")
BUNDLED_LOCUS_FASTA = _bundled("Flavotyper_reference_loci.fasta")


def sample_name_from_path(path: Path) -> str:
    """Derive stable sample ID from filename, stripping FASTA(.gz) suffixes."""

    name = path.name
    lower_name = name.lower()
    for suffix in (".fasta.gz", ".fna.gz", ".fas.gz", ".fa.gz", ".fasta", ".fna", ".fas", ".fa"):
        if lower_name.endswith(suffix):
            return name[: -len(suffix)]
    return path.stem


@dataclass(frozen=True)
class SampleIdentity:
    """One input genome plus its run-local stable identifiers."""

    genome_path: Path
    sample_name: str
    sample_key: str


def build_sample_identities(genomes: list[Path]) -> list[SampleIdentity]:
    """Return per-input identifiers, assigning unique keys only for duplicates.

    `sample_name` keeps the historical filename-stem behavior. `sample_key` is
    unique within the run and is used for filesystem artifacts when duplicate
    sample names are explicitly allowed.
    """

    indexed_samples = [
        (idx, Path(genome), sample_name_from_path(Path(genome)))
        for idx, genome in enumerate(genomes)
    ]

    grouped: dict[str, list[tuple[int, Path]]] = {}
    for idx, genome_path, sample_name in indexed_samples:
        grouped.setdefault(sample_name, []).append((idx, genome_path))

    sample_keys_by_index: dict[int, str] = {}
    for sample_name, entries in grouped.items():
        if len(entries) == 1:
            sample_keys_by_index[entries[0][0]] = sample_name
            continue

        ordered_entries = sorted(
            entries,
            key=lambda item: (str(item[1].resolve()), item[0]),
        )
        width = len(str(len(ordered_entries))) if len(ordered_entries) >= 10 else 1
        for rank, (idx, _genome_path) in enumerate(ordered_entries, start=1):
            sample_keys_by_index[idx] = f"{sample_name}__{rank:0{width}d}"

    return [
        SampleIdentity(
            genome_path=genome_path,
            sample_name=sample_name,
            sample_key=sample_keys_by_index[idx],
        )
        for idx, genome_path, sample_name in indexed_samples
    ]


@dataclass(frozen=True)
class RunConfig:
    """Immutable runtime parameters for one FlavoTyper execution."""

    # ---------- Required I/O ----------
    genomes: list[Path]
    db_path: Path
    outdir: Path

    # ---------- Marker-hit filter thresholds ----------
    # Hit is considered present only if BOTH filters pass.
    min_identity: float = 97.0
    min_coverage: float = 94.0

    # ---------- Compute ----------
    threads: int = 1

    # ---------- Species QC gate (ANI) ----------
    # Enabled by default; species verification is part of the standard workflow.
    species_check: bool = True
    ani_threshold: float = 95.0
    species_refs: Path | None = None

    # ---------- Assembly QC gate ----------
    # 95% empirical reference interval (2.5th-97.5th percentiles) derived
    # from the curated 220-genome Microscope set.
    expected_genome_size_min: int = DEFAULT_EXPECTED_GENOME_SIZE_MIN
    expected_genome_size_max: int = DEFAULT_EXPECTED_GENOME_SIZE_MAX
    # Contig thresholds are warnings only (do not block typing).
    warn_contigs_over: int = 300
    high_warn_contigs_over: int = 500
    allowed_genome_extensions: tuple[str, ...] = FASTA_EXTENSIONS
    fail_on_duplicate_sample_names: bool = True

    # ---------- Locus analysis (optional, Resolved calls only) ----------
    # When True, a second BLASTN run is performed for each Resolved sample
    # against its serotype reference locus, producing a pairwise alignment
    # text file and a two-track PNG locus map.
    locus_analysis: bool = False
    locus_db_path: Path = BUNDLED_LOCUS_FASTA   # bundled reference_loci.fasta by default

    def validate(self) -> None:
        """Validate configuration consistency before execution."""

        # 1) Input existence checks
        if not self.genomes:
            raise ValidationError("No genome files provided.")
        for genome in self.genomes:
            if not genome.exists() or not genome.is_file():
                raise ValidationError(f"Genome file not found: {genome}")
            suffixes = "".join(genome.suffixes).lower()
            if not any(suffixes.endswith(ext) for ext in self.allowed_genome_extensions):
                raise ValidationError(
                    f"Unsupported genome extension for {genome}. "
                    f"Allowed: {', '.join(self.allowed_genome_extensions)}"
                )

        if self.fail_on_duplicate_sample_names:
            counts = Counter(sample_name_from_path(g) for g in self.genomes)
            duplicates = sorted(name for name, count in counts.items() if count > 1)
            if duplicates:
                raise ValidationError(
                    "Duplicate sample names detected from file stems: "
                    + ", ".join(duplicates)
                )

        if not self.db_path.exists() or not self.db_path.is_file():
            raise ValidationError(f"Database file not found: {self.db_path}")

        # 2) Numeric thresholds sanity
        if not (0.0 < self.min_identity <= 100.0):
            raise ValidationError("min_identity must be in (0, 100].")
        if not (0.0 < self.min_coverage <= 100.0):
            raise ValidationError("min_coverage must be in (0, 100].")
        if self.threads < 1:
            raise ValidationError("threads must be >= 1.")
        if not (0.0 < self.ani_threshold <= 100.0):
            raise ValidationError("ani_threshold must be in (0, 100].")

        # 3) Species-check prerequisites
        if self.species_check:
            if self.species_refs is None:
                raise ValidationError(
                    "species_refs is required when species_check is enabled. "
                    "Provide --species-refs or use --no-species-check."
                )
            if not self.species_refs.exists() or not self.species_refs.is_file():
                raise ValidationError(f"Species reference genome not found: {self.species_refs}")
            species_suffixes = "".join(self.species_refs.suffixes).lower()
            if not any(species_suffixes.endswith(ext) for ext in self.allowed_genome_extensions):
                raise ValidationError(
                    "species_refs must be a reference genome FASTA file "
                    "(.fa/.fna/.fasta/.fas, optionally gzipped)."
                )

        # 4) Assembly-size expectation interval (warning policy, but must be sane).
        if self.expected_genome_size_min <= 0 or self.expected_genome_size_max <= 0:
            raise ValidationError("expected_genome_size_min/max must be > 0.")
        if self.expected_genome_size_min > self.expected_genome_size_max:
            raise ValidationError(
                "expected_genome_size_min cannot be greater than expected_genome_size_max."
            )

        # 5) Contig warning thresholds (warning policy only).
        if self.warn_contigs_over < 1:
            raise ValidationError("warn_contigs_over must be >= 1.")
        if self.high_warn_contigs_over < 1:
            raise ValidationError("high_warn_contigs_over must be >= 1.")
        if self.warn_contigs_over > self.high_warn_contigs_over:
            raise ValidationError(
                "warn_contigs_over cannot be greater than high_warn_contigs_over."
            )

        # 6) Locus DB path — always validated because the DB is always loaded.
        if not self.locus_db_path.exists() or not self.locus_db_path.is_file():
            raise ValidationError(
                f"Locus reference database not found: {self.locus_db_path}"
            )

