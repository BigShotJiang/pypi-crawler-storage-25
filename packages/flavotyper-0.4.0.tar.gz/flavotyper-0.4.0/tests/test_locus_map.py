from pathlib import Path

import pytest

from flavotyper.locus import MarkerPosition
from flavotyper.locus_align import (
    LocusAlignResult,
    LocusHSP,
    _select_primary_hsps,
)
from flavotyper.locus_map import (
    _compute_track2_text_offsets,
    _Track2MarkerLayout,
    render_locus_map,
)
from flavotyper.models import Hit


# ---------------------------------------------------------------------------
# _select_primary_hsps
# ---------------------------------------------------------------------------

def _make_hit(gene: str, contig: str, start: int, end: int) -> Hit:
    return Hit(
        gene=gene,
        identity=99.0,
        coverage=100.0,
        contig=contig,
        start=start,
        end=end,
        marker_start=1,
        marker_end=end - start + 1,
        marker_length=end - start + 1,
        alignment_length=end - start + 1,
        strand="+",
    )


def test_select_primary_hsps_prefers_marker_anchored_hsp() -> None:
    """HSP overlapping the marker window is kept; off-target repeat is dropped."""
    main_hsp = LocusHSP(
        contig="contig_a",
        genome_start=1_000,
        genome_end=2_000,
        locus_start=1,
        locus_end=1_001,
        locus_strand="+",
        identity=100.0,
        alignment_length=1_001,
    )
    off_target = LocusHSP(
        contig="contig_a",
        genome_start=50_000,
        genome_end=50_040,
        locus_start=300,
        locus_end=340,
        locus_strand="+",
        identity=82.0,
        alignment_length=41,
    )
    marker_hits = [_make_hit("wzy1", "contig_a", 1_200, 1_350)]

    selected = _select_primary_hsps(
        hsps=[off_target, main_hsp],
        marker_hits=marker_hits,
    )

    assert selected == [main_hsp]


def test_select_primary_hsps_keeps_multiple_contigs() -> None:
    """HSPs on two contigs are both kept when markers anchor each contig."""
    hsp_a = LocusHSP(
        contig="contig_a",
        genome_start=1_000,
        genome_end=1_400,
        locus_start=1,
        locus_end=400,
        locus_strand="+",
        identity=99.5,
        alignment_length=401,
    )
    hsp_b = LocusHSP(
        contig="contig_b",
        genome_start=10_000,
        genome_end=10_300,
        locus_start=401,
        locus_end=700,
        locus_strand="+",
        identity=99.0,
        alignment_length=300,
    )
    off_target = LocusHSP(
        contig="contig_b",
        genome_start=80_000,
        genome_end=80_050,
        locus_start=150,
        locus_end=200,
        locus_strand="+",
        identity=78.0,
        alignment_length=51,
    )
    marker_hits = [
        _make_hit("wzy1",    "contig_a", 1_080, 1_180),
        _make_hit("r4_core", "contig_b", 10_050, 10_250),
    ]

    selected = _select_primary_hsps(
        hsps=[off_target, hsp_b, hsp_a],
        marker_hits=marker_hits,
    )

    assert set(selected) == {hsp_a, hsp_b}


# ---------------------------------------------------------------------------
# _compute_track2_text_offsets
# ---------------------------------------------------------------------------

def test_compute_track2_text_offsets_lifts_only_crowded_middle_marker() -> None:
    layouts = [
        _Track2MarkerLayout(
            marker="r1_core",
            sub_labels=["wfpC", "wfpD", "wfpE"],
            group_label=None,
            px1=100,
            px2=340,
            strand="+",
            stats_text="id: 99.4%;  cov: 99.9%",
        ),
        _Track2MarkerLayout(
            marker="Rieske",
            sub_labels=["Rieske"],
            group_label=None,
            px1=330,
            px2=470,
            strand="+",
            stats_text="id: 100%;  cov: 99.8%",
        ),
        _Track2MarkerLayout(
            marker="wfpF_p",
            sub_labels=["wfpF'"],
            group_label=None,
            px1=460,
            px2=600,
            strand="+",
            stats_text="id: 100%;  cov: 99.7%",
        ),
    ]

    offsets = _compute_track2_text_offsets(layouts)

    assert offsets == {
        "r1_core": 0,
        "Rieske": -18,
        "wfpF_p": 0,
    }


def test_compute_track2_text_offsets_lifts_ph0209_rieske_when_neighbors_are_tight() -> None:
    layouts = [
        _Track2MarkerLayout(
            marker="wzy3",
            sub_labels=["wzy3"],
            group_label=None,
            px1=1021,
            px2=1285,
            strand="+",
            stats_text="id: 100%;  cov: 99.8%",
        ),
        _Track2MarkerLayout(
            marker="r1_core",
            sub_labels=["wfpC", "wfpD", "wfpE"],
            group_label=None,
            px1=2564,
            px2=3027,
            strand="+",
            stats_text="id: 99.4%;  cov: 99.9%",
        ),
        _Track2MarkerLayout(
            marker="Rieske",
            sub_labels=["Rieske"],
            group_label=None,
            px1=3029,
            px2=3247,
            strand="+",
            stats_text="id: 100%;  cov: 99.8%",
        ),
        _Track2MarkerLayout(
            marker="wfpF_p",
            sub_labels=["wfpF'"],
            group_label=None,
            px1=3247,
            px2=3393,
            strand="+",
            stats_text="id: 100%;  cov: 99.7%",
        ),
    ]

    offsets = _compute_track2_text_offsets(layouts)

    assert offsets["Rieske"] == -18


# ---------------------------------------------------------------------------
# render_locus_map
# ---------------------------------------------------------------------------

def test_render_locus_map_writes_png(tmp_path: Path) -> None:
    pytest.importorskip("PIL")

    marker_positions = [
        MarkerPosition(
            serotype="O:1-S0-R4",
            marker="wzy1",
            gene_name="wzy1",
            marker_start_in_locus=120,
            marker_end_in_locus=320,
            strand="+",
        ),
        MarkerPosition(
            serotype="O:1-S0-R4",
            marker="r4_core",
            gene_name="3 unnamed genes",
            marker_start_in_locus=650,
            marker_end_in_locus=950,
            strand="+",
        ),
    ]
    align_result = LocusAlignResult(
        serotype="O:1-S0-R4",
        reference_genome="DK002",
        locus_length=1_000,
        pct_identity=99.8,
        pct_coverage=100.0,
        hsps=[
            LocusHSP(
                contig="contig_a",
                genome_start=20_000,
                genome_end=21_000,
                locus_start=1,
                locus_end=1_000,
                locus_strand="-",
                identity=99.8,
                alignment_length=1_000,
            )
        ],
        marker_hits=[
            Hit(
                gene="wzy1",
                identity=100.0,
                coverage=100.0,
                contig="contig_a",
                start=20_680,
                end=20_880,
                marker_start=1,
                marker_end=200,
                marker_length=200,
                alignment_length=200,
                strand="-",
            ),
            Hit(
                gene="r4_core",
                identity=99.5,
                coverage=100.0,
                contig="contig_a",
                start=20_050,
                end=20_350,
                marker_start=1,
                marker_end=300,
                marker_length=300,
                alignment_length=300,
                strand="-",
            ),
        ],
        alignment_text="",
    )

    output_path = tmp_path / "sample_locus_map.png"
    render_locus_map(
        sample_name="sample_1",
        locus_marker_positions=marker_positions,
        align_result=align_result,
        output_path=output_path,
    )

    assert output_path.exists()
    assert output_path.read_bytes().startswith(b"\x89PNG\r\n\x1a\n")
