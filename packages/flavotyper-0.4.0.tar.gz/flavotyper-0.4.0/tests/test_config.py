from pathlib import Path

from flavotyper.config import build_sample_identities


def test_build_sample_identities_assigns_deterministic_keys_for_duplicates(tmp_path: Path) -> None:
    run_a = tmp_path / "run_a"
    run_b = tmp_path / "run_b"
    run_a.mkdir()
    run_b.mkdir()

    sample_a_2 = run_b / "sampleA.fasta"
    sample_a_1 = run_a / "sampleA.fasta"
    sample_b = run_a / "sampleB.fasta"
    for path in (sample_a_2, sample_a_1, sample_b):
        path.write_text(">contig\nACGT\n", encoding="utf-8")

    identities = build_sample_identities([sample_a_2, sample_a_1, sample_b])

    assert [item.sample_name for item in identities] == ["sampleA", "sampleA", "sampleB"]
    assert [item.sample_key for item in identities] == ["sampleA__2", "sampleA__1", "sampleB"]
