import csv
import json
from pathlib import Path

from flavotyper.config import BUNDLED_RULES_YAML
from flavotyper.database import load_database
from flavotyper.models import Hit, QCMetrics, SpeciesCheckResult, TypingCall
from flavotyper.report import append_call_reports, init_streaming_reports
from flavotyper.typing_rules import _select_best_marker_hits, call_serotype


DB_PATH = BUNDLED_RULES_YAML


def test_select_best_marker_hits_keeps_one_best_passing_hit_per_marker() -> None:
    hits = [
        Hit(gene="wzy2", identity=99.10, coverage=95.00, contig="contig_a", start=100, end=200),
        Hit(gene="wzy2", identity=99.80, coverage=98.50, contig="contig_b", start=300, end=420),
        Hit(gene="wzy2", identity=100.00, coverage=93.00, contig="contig_c", start=500, end=620),
        Hit(gene="wfpF", identity=99.50, coverage=99.00, contig="contig_z", start=50, end=150),
    ]

    selected = _select_best_marker_hits(hits, min_identity=98.0, min_coverage=94.0)

    assert [hit.gene for hit in selected] == ["wfpF", "wzy2"]
    chosen_wzy2 = next(hit for hit in selected if hit.gene == "wzy2")
    assert chosen_wzy2.contig == "contig_b"
    assert chosen_wzy2.identity == 99.80
    assert chosen_wzy2.coverage == 98.50


def test_call_serotype_does_not_merge_split_partial_hits_into_marker_presence() -> None:
    db = load_database(DB_PATH)
    hits = [
        Hit(gene="wzy2", identity=100.0, coverage=100.0, contig="contig_1", start=100, end=200),
        Hit(gene="wfpF", identity=100.0, coverage=100.0, contig="contig_1", start=300, end=380),
        Hit(gene="r1_core", identity=100.0, coverage=50.0, contig="contig_1", start=400, end=520),
        Hit(gene="r1_core", identity=100.0, coverage=46.0, contig="contig_1", start=530, end=650),
    ]

    call = call_serotype(
        sample="sample_1",
        sample_key="sample_1",
        db=db,
        hits=hits,
        min_identity=98.0,
        min_coverage=94.0,
    )

    assert call.o_type == "O:2"
    assert call.r_type == "Undefined"
    assert call.s_type == "S0"
    assert call.serotype == "O:2-S0-Undefined"
    assert call.present_markers == ["wfpF", "wzy2"]
    assert len(call.raw_hits) == 4
    assert [hit.gene for hit in call.raw_hits] == ["wzy2", "wfpF", "r1_core", "r1_core"]


def test_o0_defaults_to_s0_r0() -> None:
    db = load_database(DB_PATH)
    hits = [
        Hit(gene="wzy0", identity=100.0, coverage=100.0, contig="contig_1", start=100, end=200),
    ]

    call = call_serotype(
        sample="sample_o0",
        sample_key="sample_o0",
        db=db,
        hits=hits,
        min_identity=98.0,
        min_coverage=94.0,
    )

    assert call.o_type == "O:0"
    assert call.r_type == "R0"
    assert call.s_type == "S0"
    assert call.serotype == "O:0-S0-R0"
    assert call.ambiguity_state == "Resolved"


def test_undefined_r_call_reports_detected_r_marker_warning() -> None:
    db = load_database(DB_PATH)
    hits = [
        Hit(gene="wzy1", identity=100.0, coverage=100.0, contig="contig_1", start=100, end=200),
        Hit(gene="wfpF", identity=100.0, coverage=100.0, contig="contig_1", start=300, end=380),
    ]

    call = call_serotype(
        sample="sample_warning",
        sample_key="sample_warning",
        db=db,
        hits=hits,
        min_identity=98.0,
        min_coverage=94.0,
    )

    assert call.serotype == "O:1-S0-Undefined"
    assert any("marker 'wfpF'" in warning and "R1V1" in warning for warning in call.warnings)


def test_markers_on_multiple_contigs_emit_warning() -> None:
    db = load_database(DB_PATH)
    hits = [
        Hit(gene="wzy1", identity=100.0, coverage=100.0, contig="contig_a", start=100, end=200),
        Hit(gene="r1_core", identity=100.0, coverage=100.0, contig="contig_b", start=300, end=380),
        Hit(gene="wfpF", identity=100.0, coverage=100.0, contig="contig_b", start=400, end=470),
    ]

    call = call_serotype(
        sample="sample_multicontig",
        sample_key="sample_multicontig",
        db=db,
        hits=hits,
        min_identity=98.0,
        min_coverage=94.0,
    )

    assert call.serotype == "O:1-S0-R1V1"
    assert any("not all on the same contig" in warning for warning in call.warnings)


def test_tsv_row_is_single_line_and_has_correct_columns(tmp_path: Path) -> None:
    qc = QCMetrics(
        n_contigs=2,
        genome_size=2750000,
        gc_percent=32.5,
        species=SpeciesCheckResult(
            checked=True,
            passed=True,
            best_ani=99.1,
            best_reference="ref.fna",
        ),
        quality_passed=True,
        quality_messages=[],
        quality_warnings=["Contig count 350 is high (>300)."],
    )
    call = TypingCall(
        sample="sample_report",
        sample_key="sample_report__1",
        typed=True,
        o_type="O:1",
        r_type="R1V1",
        s_type="S0",
        serotype="O:1-S0-R1V1",
        ambiguity_state="Resolved",
        reason_codes=[],
        warnings=["Detected typing markers are not all on the same contig."],
        present_markers=["r1_core", "wfpF", "wzy1"],
        hits=[
            Hit(gene="wzy1", identity=100.0, coverage=100.0, contig="contig_1", start=10, end=20),
        ],
        raw_hits=[
            Hit(gene="wzy1", identity=100.0, coverage=100.0, contig="contig_1", start=10, end=20),
            Hit(gene="wfpF", identity=97.5, coverage=93.0, contig="contig_2", start=30, end=40),
        ],
        qc=qc,
    )

    init_streaming_reports(tmp_path)
    append_call_reports(tmp_path, call)

    raw_lines = (tmp_path / "typing_results.tsv").read_text(encoding="utf-8").splitlines()
    # Header + exactly one data row = 2 physical lines (no multi-line cells).
    assert len(raw_lines) == 2

    with (tmp_path / "typing_results.tsv").open("rt", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))

    assert len(rows) == 1
    row = rows[0]

    # Check column names are correct.
    assert list(row.keys()) == [
        "Sample_name", "Typed", "O_type", "R_type", "S_type",
        "Serotype", "Call_state",
        "Alternative_serotypes", "Species_check",
        "Species_passed", "Calculated_ANI", "ANI_reference", "N_contigs",
        "Genome_size_bp", "GC_percent", "QC_passed", "QC_warnings",
        "Present_alleles", "Present_alleles_ranges", "Present_alleles_contig_names",
        "Typing_warnings", "Serotype_reference", "Raw_hits",
    ]

    assert row["Sample_name"] == "sample_report"
    assert row["Serotype"] == "O:1-S0-R1V1"
    assert row["S_type"] == "S0"
    assert row["Call_state"] == "Resolved"
    assert row["Species_check"] == "Enabled"
    assert row["Species_passed"] == "True"
    assert row["QC_passed"] == "True"
    assert row["QC_warnings"] == "Contig count 350 is high (>300)."
    assert row["Present_alleles"] == "wfpC; wfpD; wfpE ; wfpF ; wzy1"  # r1_core display name
    assert row["Present_alleles_ranges"] == "wzy1:10-20"
    assert row["Present_alleles_contig_names"] == "wzy1:contig_1"
    assert row["Typing_warnings"] == "Detected typing markers are not all on the same contig."
    assert row["ANI_reference"] == "ref.fna"
    assert row["Raw_hits"] == (
        "wzy1|identity=100.000|coverage=100.000|contig=contig_1|coords=10-20 ; "
        "wfpF|identity=97.500|coverage=93.000|contig=contig_2|coords=30-40"
    )

    jsonl_lines = (tmp_path / "typing_results.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(jsonl_lines) == 1
    json_record = json.loads(jsonl_lines[0])
    assert json_record["sample"] == "sample_report"
    assert json_record["sample_key"] == "sample_report__1"


def test_qc_failed_sample_has_empty_typing_warnings(tmp_path: Path) -> None:
    qc = QCMetrics(
        n_contigs=1,
        genome_size=2700000,
        gc_percent=32.3,
        species=SpeciesCheckResult(
            checked=True,
            passed=False,
            best_ani=87.5,
            best_reference="ref.fna",
            message="Best ANI 87.50 below threshold 95.00.",
        ),
        quality_passed=False,
        quality_messages=["Species check failed: Best ANI 87.50 below threshold 95.00."],
        quality_warnings=[],
    )
    call = TypingCall(
        sample="sample_qc_fail",
        sample_key="sample_qc_fail",
        typed=False,
        o_type="NotTyped",
        r_type="NotTyped",
        s_type="NotTyped",
        serotype="NotTyped",
        ambiguity_state="NotTyped",
        reason_codes=["QC_GATE_FAILED"],
        alternative_serotypes=[],
        warnings=[],
        present_markers=[],
        hits=[],
        raw_hits=[],
        qc=qc,
    )

    init_streaming_reports(tmp_path)
    append_call_reports(tmp_path, call)

    raw_lines = (tmp_path / "typing_results.tsv").read_text(encoding="utf-8").splitlines()
    assert len(raw_lines) == 2

    with (tmp_path / "typing_results.tsv").open("rt", encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))

    row = rows[0]
    assert row["Typed"] == "False"
    assert row["Serotype"] == "NotTyped"
    assert row["Call_state"] == "NotTyped"
    assert row["QC_passed"] == "False"
    assert "Species check failed" in row["QC_warnings"]
    assert row["Typing_warnings"] == ""
    assert row["Raw_hits"] == ""
