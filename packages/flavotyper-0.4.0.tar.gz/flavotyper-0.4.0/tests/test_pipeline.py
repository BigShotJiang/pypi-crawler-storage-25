from pathlib import Path

from flavotyper.locus import LocusDB, LocusRecord
from flavotyper.models import TypingCall
from flavotyper.pipeline import (
    _enrich_call_with_locus_provenance,
    _locus_artifact_dir,
)


def test_locus_artifact_dir_uses_sample_key_subdirectory() -> None:
    outdir = Path("/tmp/flavotyper_results")

    assert _locus_artifact_dir(outdir, "sampleA__2") == (
        outdir / "sampleA__2_locus_analysis"
    )


def _base_call(serotype: str, state: str = "Resolved") -> TypingCall:
    return TypingCall(
        sample="s",
        sample_key="s",
        typed=True,
        o_type="O:1",
        r_type="R1V1",
        s_type="S0",
        serotype=serotype,
        ambiguity_state=state,
    )


def _db_with(serotype: str) -> LocusDB:
    rec = LocusRecord(
        serotype=serotype,
        genome="DK001",
        seq_len=100,
        sequence="A" * 100,
        genome_start=1,
        genome_end=100,
        genome_strand="+",
        genbank_accession="GCA_900186405",
        pmid="29467746",
    )
    return LocusDB({serotype: rec}, {})


def test_enrich_populates_reference_sentence_when_serotype_known() -> None:
    call = _base_call("O:1-S0-R1V1")
    enriched = _enrich_call_with_locus_provenance(call, _db_with("O:1-S0-R1V1"))

    assert "DK001" in enriched.serotype_reference
    assert "GCA_900186405" in enriched.serotype_reference
    assert "29467746" in enriched.serotype_reference
    assert enriched.warnings == []


def test_enrich_flags_novel_combination_when_not_in_db() -> None:
    call = _base_call("O:2-S1-R1V1")
    enriched = _enrich_call_with_locus_provenance(call, _db_with("O:1-S0-R1V1"))

    assert enriched.serotype_reference == ""
    assert any("has not been previously observed" in w for w in enriched.warnings)


def test_enrich_is_noop_for_ambiguous_calls() -> None:
    call = _base_call("O:1-S0-R1V1", state="Ambiguous")
    enriched = _enrich_call_with_locus_provenance(call, _db_with("O:1-S0-R1V1"))

    assert enriched is call
