"""Unit tests for ``BrowserSessionPool`` (U2).

All tests use injected ``_manager_factory`` to avoid launching real
Chromium. A real-Playwright smoke test lives in
``test_pool_playwright.py`` under ``@pytest.mark.playwright``.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import Any

import pytest
from _browser_fakes import FakePlaywrightManager
from zeno.tools_browser.exceptions import (
    BrowserLimitError,
    BrowserSessionClosedError,
)
from zeno.tools_browser.pool import BrowserSessionPool


def _pool(
    *,
    managers: list[FakePlaywrightManager] | None = None,
    now_fn: Callable[[], float] | None = None,
    **kwargs: Any,
) -> BrowserSessionPool:
    """Construct a pool with a fake Playwright manager injected.

    ``managers`` is an out-parameter — the caller passes an empty list
    and reads back the manager the pool created after ``start()``.
    """
    managers = managers if managers is not None else []

    def factory(headless: bool) -> FakePlaywrightManager:  # noqa: ARG001
        mgr = FakePlaywrightManager()
        managers.append(mgr)
        return mgr

    return BrowserSessionPool(_manager_factory=factory, now_fn=now_fn, **kwargs)


# ---------------------------------------------------------------------------
# Happy paths
# ---------------------------------------------------------------------------


async def test_acquire_on_fresh_pool_opens_session() -> None:
    pool = _pool()
    await pool.start()
    try:
        session = await pool.acquire("alice", "thread-1")
        assert session is not None
        assert session.page is not None
    finally:
        await pool.stop()


async def test_same_key_returns_same_session() -> None:
    pool = _pool()
    await pool.start()
    try:
        a = await pool.acquire("alice", "thread-1")
        b = await pool.acquire("alice", "thread-1")
        assert a is b
    finally:
        await pool.stop()


async def test_different_threads_return_different_sessions() -> None:
    pool = _pool()
    await pool.start()
    try:
        a = await pool.acquire("alice", "thread-1")
        b = await pool.acquire("alice", "thread-2")
        assert a is not b
        assert a.page is not b.page
    finally:
        await pool.stop()


async def test_different_users_return_different_sessions() -> None:
    pool = _pool()
    await pool.start()
    try:
        a = await pool.acquire("alice", None)
        b = await pool.acquire("bob", None)
        assert a is not b
    finally:
        await pool.stop()


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


async def test_session_lock_serializes_concurrent_tool_calls() -> None:
    """Two coroutines competing for the same session.lock must serialize."""
    pool = _pool()
    await pool.start()
    try:
        session = await pool.acquire("alice", "t1")
        order: list[str] = []

        async def run(tag: str) -> None:
            async with session.lock:
                order.append(f"{tag}:start")
                await asyncio.sleep(0.01)
                order.append(f"{tag}:end")

        await asyncio.gather(run("a"), run("b"))
        # Each pair must appear contiguously — no interleaving.
        assert order[0].endswith(":start")
        assert order[1].endswith(":end")
        assert order[2].endswith(":start")
        assert order[3].endswith(":end")
        assert order[0].split(":")[0] == order[1].split(":")[0]
        assert order[2].split(":")[0] == order[3].split(":")[0]
    finally:
        await pool.stop()


async def test_idle_reaper_closes_cold_sessions() -> None:
    """After ``idle_timeout_s`` with no access the reap loop closes the session."""
    clock = {"now": 1_000.0}

    def now_fn() -> float:
        return clock["now"]

    pool = _pool(
        idle_timeout_s=60,
        reap_interval_s=0.01,  # fast reap for testing
        now_fn=now_fn,
    )
    await pool.start()
    try:
        session1 = await pool.acquire("alice", "t1")
        page1 = session1.page

        # Jump past the idle window.
        clock["now"] += 120.0

        # Give the reap loop a chance to run.
        for _ in range(50):
            await asyncio.sleep(0.005)
            if page1.closed:
                break
        assert page1.closed
        # A re-acquire opens a fresh session (different identity).
        session2 = await pool.acquire("alice", "t1")
        assert session2 is not session1
    finally:
        await pool.stop()


async def test_start_is_idempotent() -> None:
    managers: list[FakePlaywrightManager] = []
    pool = _pool(managers=managers)
    await pool.start()
    await pool.start()  # second call must be a no-op
    try:
        # Exactly one manager constructed.
        assert len(managers) == 1
        assert managers[0].started is True
    finally:
        await pool.stop()


async def test_stop_without_start_is_no_op() -> None:
    pool = _pool()
    # Must not raise.
    await pool.stop()


# ---------------------------------------------------------------------------
# Error paths
# ---------------------------------------------------------------------------


async def test_per_user_cap_raises_limit_error() -> None:
    pool = _pool(max_sessions_per_user=2)
    await pool.start()
    try:
        await pool.acquire("alice", "t1")
        await pool.acquire("alice", "t2")
        with pytest.raises(BrowserLimitError) as ei:
            await pool.acquire("alice", "t3")
        assert "alice" in str(ei.value)
    finally:
        await pool.stop()


async def test_global_cap_raises_limit_error() -> None:
    pool = _pool(max_sessions_global=2, max_sessions_per_user=10)
    await pool.start()
    try:
        await pool.acquire("alice", "t1")
        await pool.acquire("bob", "t1")
        with pytest.raises(BrowserLimitError):
            await pool.acquire("carol", "t1")
    finally:
        await pool.stop()


async def test_acquire_after_stop_raises_closed_error() -> None:
    pool = _pool()
    await pool.start()
    await pool.stop()
    with pytest.raises(BrowserSessionClosedError):
        await pool.acquire("alice", "t1")


async def test_stop_closes_all_sessions() -> None:
    pool = _pool()
    await pool.start()
    s1 = await pool.acquire("alice", "t1")
    s2 = await pool.acquire("bob", "t1")
    await pool.stop()
    assert s1.page.closed
    assert s2.page.closed
