"""EvalGuard Python SDK — HTTP client for the EvalGuard API."""

from __future__ import annotations

import base64
import time
from typing import Any, Dict, List, Optional, Union
from urllib.parse import urlparse

import requests

from .types import (
    BenchmarkResult,
    ComplianceReport,
    DriftReport,
    EvalResult,
    FirewallResult,
    SecurityScanResult,
)


class EvalGuardError(Exception):
    """Base exception for EvalGuard API errors."""

    def __init__(self, message: str, status_code: int | None = None, body: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class EvalGuardClient:
    """Client for the EvalGuard REST API.

    Example::

        from evalguard import EvalGuardClient

        client = EvalGuardClient(api_key="eg_live_...")
        result = client.run_eval({
            "model": "gpt-4o",
            "prompt": "Answer: {{input}}",
            "cases": [{"input": "hello", "expectedOutput": "hello"}],
            "scorers": ["exact-match"],
        })
        print(result)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.evalguard.ai",
        timeout: float = 120.0,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._subject: Optional[Dict[str, str]] = None

        # Enforce HTTPS for non-local URLs
        parsed = urlparse(self.base_url)
        is_local = parsed.hostname in ('localhost', '127.0.0.1')
        if parsed.scheme != 'https' and not is_local:
            raise ValueError(
                "EvalGuard: base_url must use HTTPS. "
                "Only localhost/127.0.0.1 may use HTTP."
            )
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "evalguard-python/1.0.0",
            }
        )

    # ── Helpers ──────────────────────────────────────────────────────────

    def with_subject(
        self,
        email: Optional[str] = None,
        id: Optional[str] = None,
        purpose: Optional[str] = None,
    ) -> "EvalGuardClient":
        """Return a new client bound to a subject for consent enforcement.

        The gateway proxy reads ``x-evalguard-subject-email`` /
        ``x-evalguard-subject-id`` and ``x-evalguard-purpose`` to look up
        consent. If consent is revoked or denied, the gateway returns
        HTTP 451 BEFORE forwarding to the upstream LLM provider.

        Either ``email`` or ``id`` is required. ``purpose`` defaults to
        ``model_inference`` on the server side.

        Returns a new client so a single shared client can fan out
        per-request scoped clients without mutation::

            client = EvalGuardClient(api_key="eg_live_...")
            user_client = client.with_subject(email=user.email, purpose="support_chat")
            user_client.gateway_proxy(...)  # 451 if user revoked consent
        """
        if not email and not id:
            raise ValueError("with_subject: at least one of email or id is required")
        new = EvalGuardClient(
            api_key=self.api_key,
            base_url=self.base_url,
            timeout=self.timeout,
        )
        subject: Dict[str, str] = {}
        if email:
            subject["x-evalguard-subject-email"] = email
        if id:
            subject["x-evalguard-subject-id"] = id
        if purpose:
            subject["x-evalguard-purpose"] = purpose
        new._subject = subject
        return new

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        kwargs.setdefault("timeout", self.timeout)
        # Inject consent headers per-request — using session.headers would
        # leak them across all clients sharing a Session, but since
        # with_subject() returns a fresh client (and therefore a fresh
        # Session), per-request injection is correctness AND a paranoia
        # double-up that doesn't cost anything.
        if self._subject:
            headers = kwargs.pop("headers", {}) or {}
            headers = {**headers, **self._subject}
            kwargs["headers"] = headers
        max_retries = 3
        last_error = None

        for attempt in range(max_retries + 1):
            try:
                response = self.session.request(method, self._url(path), **kwargs)

                if response.status_code == 429:
                    retry_after = int(response.headers.get("Retry-After", 0))
                    delay = retry_after if retry_after > 0 else min(2 ** attempt, 60)
                    if attempt < max_retries:
                        time.sleep(delay)
                        continue

                if response.status_code >= 500 and attempt < max_retries:
                    time.sleep(2 ** attempt)
                    continue

                if not response.ok:
                    raise EvalGuardError(
                        f"API error {response.status_code}: {response.text[:500]}",
                        status_code=response.status_code,
                        body=response.text[:500],
                    )
                if response.status_code == 204:
                    return None
                return response.json()
            except EvalGuardError:
                raise
            except Exception as e:
                last_error = e
                if attempt < max_retries:
                    time.sleep(2 ** attempt)
                    continue
                raise EvalGuardError(f"Request failed: {e}")

        raise EvalGuardError(f"Request failed after {max_retries} retries: {last_error}")

    def _get(self, path: str, params: Dict[str, Any] | None = None) -> Any:
        return self._request("GET", path, params=params)

    def _post(self, path: str, json: Any = None) -> Any:
        return self._request("POST", path, json=json)

    def _patch(self, path: str, json: Any = None) -> Any:
        return self._request("PATCH", path, json=json)

    def _delete(self, path: str) -> Any:
        return self._request("DELETE", path)

    # ── Eval endpoints ───────────────────────────────────────────────────

    def run_eval(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Run an evaluation with the given config and return results."""
        return self._post("/v1/evals/run", json=config)

    def get_eval(self, run_id: str) -> Dict[str, Any]:
        """Fetch a specific eval run by ID."""
        return self._get(f"/v1/evals/{run_id}")

    def list_evals(self, project_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """List eval runs, optionally filtered by project."""
        params = {}
        if project_id:
            params["projectId"] = project_id
        return self._get("/v1/evals", params=params)

    # ── Security scan endpoints ──────────────────────────────────────────

    def run_scan(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Run a security scan (red-team) against a model."""
        return self._post("/v1/scans/run", json=config)

    def get_scan(self, scan_id: str) -> Dict[str, Any]:
        """Fetch a specific security scan by ID."""
        return self._get(f"/v1/scans/{scan_id}")

    # ── Scorers & plugins ────────────────────────────────────────────────

    def list_scorers(self) -> List[Dict[str, Any]]:
        """List all available evaluation scorers."""
        return self._get("/v1/scorers")

    def list_plugins(self) -> List[Dict[str, Any]]:
        """List all available security plugins."""
        return self._get("/v1/plugins")

    # ── Firewall ─────────────────────────────────────────────────────────

    def check_firewall(
        self,
        input_text: str,
        rules: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Check input text against firewall rules."""
        payload: Dict[str, Any] = {"input": input_text}
        if rules is not None:
            payload["rules"] = rules
        return self._post("/v1/firewall/check", json=payload)

    # ── Benchmarks ───────────────────────────────────────────────────────

    def run_benchmarks(
        self,
        suites: List[str],
        model: str,
    ) -> Dict[str, Any]:
        """Run benchmark suites against a model."""
        return self._post("/v1/benchmarks/run", json={"suites": suites, "model": model})

    # ── Export ────────────────────────────────────────────────────────────

    def export_dpo(self, run_id: str) -> str:
        """Export eval results as DPO training data (JSONL)."""
        resp = self.session.get(
            self._url(f"/v1/evals/{run_id}/export/dpo"),
            timeout=self.timeout,
        )
        if not resp.ok:
            raise EvalGuardError(
                f"Export error {resp.status_code}", status_code=resp.status_code
            )
        return resp.text

    def export_burp(self, scan_id: str) -> str:
        """Export security scan results as Burp Suite XML."""
        resp = self.session.get(
            self._url(f"/v1/scans/{scan_id}/export/burp"),
            timeout=self.timeout,
        )
        if not resp.ok:
            raise EvalGuardError(
                f"Export error {resp.status_code}", status_code=resp.status_code
            )
        return resp.text

    # ── Compliance ───────────────────────────────────────────────────────

    def get_compliance_report(
        self, scan_id: str, framework: str
    ) -> Dict[str, Any]:
        """Map scan results to a compliance framework report."""
        return self._get(
            f"/v1/scans/{scan_id}/compliance",
            params={"framework": framework},
        )

    # ── Drift detection ──────────────────────────────────────────────────

    def detect_drift(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Detect performance drift between baseline and current results."""
        return self._post("/v1/drift/detect", json=config)

    # ── Guardrails ───────────────────────────────────────────────────────

    def generate_guardrails(self, config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Auto-generate firewall rules from scan findings."""
        return self._post("/v1/guardrails/generate", json=config)

    # ── Smart Routing ───────────────────────────────────────────────────

    def smart_route(self, test_cases: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Route test cases to optimal model tiers by complexity."""
        return self._post("/v1/smart-routing/test-cases", json={"testCases": test_cases})

    # ── Autopilot ───────────────────────────────────────────────────────

    def autopilot(self, description: str, depth: str, project_id: str, compliance_frameworks: Optional[List[str]] = None) -> Dict[str, Any]:
        """Launch automated audit pipeline."""
        return self._post("/v1/autopilot", json={"description": description, "depth": depth, "projectId": project_id, "complianceFrameworks": compliance_frameworks})

    def get_autopilot_config(self) -> Dict[str, Any]:
        """Get autopilot depth configurations."""
        return self._get("/v1/autopilot")

    # ── Pipelines ───────────────────────────────────────────────────────

    def create_pipeline(self, template_id: str, project_id: str) -> Dict[str, Any]:
        """Create eval pipeline from template."""
        return self._post("/v1/pipelines", json={"templateId": template_id, "projectId": project_id})

    def list_pipelines(self) -> List[Dict[str, Any]]:
        """List pipeline templates."""
        return self._get("/v1/pipelines")

    # ── Leaderboard ─────────────────────────────────────────────────────

    def get_leaderboard(self, category: str = "overall") -> Dict[str, Any]:
        """Get model safety/performance leaderboard."""
        return self._get("/v1/leaderboard", params={"category": category})

    # ── Cost / FinOps ───────────────────────────────────────────────────

    def get_cost(self, project_id: str, period: str = "30d") -> Dict[str, Any]:
        """Get cost analytics."""
        return self._get("/v1/cost", params={"projectId": project_id, "period": period})

    def get_cost_savings(self, project_id: str, period: str = "30d") -> Dict[str, Any]:
        """Get ROI / cost savings report."""
        return self._get("/v1/cost/savings", params={"projectId": project_id, "period": period})

    def get_cost_forecast(self, project_id: str) -> Dict[str, Any]:
        """Get cost forecast."""
        return self._get("/v1/cost/forecast", params={"projectId": project_id})

    # ── Security (extended) ─────────────────────────────────────────────

    def get_security_effectiveness(self, project_id: str) -> Dict[str, Any]:
        """Get attack effectiveness analytics."""
        return self._get("/v1/security/effectiveness", params={"projectId": project_id})

    def get_security_report(self, scan_id: str) -> Dict[str, Any]:
        """Get full security assessment report."""
        return self._get("/v1/security/report", params={"scanId": scan_id})

    # ── Support ─────────────────────────────────────────────────────────

    def submit_ticket(self, ticket_type: str, subject: str, description: str, priority: str = "medium", metadata: Optional[Dict] = None) -> Dict[str, Any]:
        """Submit a support ticket."""
        return self._post("/v1/support", json={"type": ticket_type, "subject": subject, "description": description, "priority": priority, "metadata": metadata or {}})

    def list_tickets(self, status: Optional[str] = None) -> Dict[str, Any]:
        """List user support tickets."""
        params = {"status": status} if status else {}
        return self._get("/v1/support", params=params)

    # ── Traces ──────────────────────────────────────────────────────────

    def list_traces(self, project_id: str) -> List[Dict[str, Any]]:
        """List traces for a project."""
        return self._get("/v1/traces", params={"projectId": project_id})

    def search_traces(self, project_id: str, query: str) -> List[Dict[str, Any]]:
        """Search traces."""
        return self._get("/v1/traces/search", params={"projectId": project_id, "q": query})

    def ingest_otlp(self, resource_spans: List[Dict]) -> Dict[str, Any]:
        """Ingest OTLP traces."""
        return self._post("/v1/ingest/otlp/traces", json={"resourceSpans": resource_spans})

    # ── Monitoring ──────────────────────────────────────────────────────

    def get_monitoring_analytics(self, project_id: str) -> Dict[str, Any]:
        """Get monitoring analytics."""
        return self._get("/v1/monitoring/analytics", params={"projectId": project_id})

    def get_monitoring_alerts(self, project_id: str) -> Dict[str, Any]:
        """Get monitoring alerts."""
        return self._get("/v1/monitoring/alerts", params={"projectId": project_id})

    # ── Compliance (extended) ───────────────────────────────────────────

    def check_compliance(self, project_id: str, framework: Optional[str] = None) -> Dict[str, Any]:
        """Run compliance check."""
        params = {"projectId": project_id}
        if framework: params["framework"] = framework
        return self._get("/v1/compliance/check", params=params)

    def get_compliance_gaps(self, project_id: str) -> Dict[str, Any]:
        """Get compliance gaps."""
        return self._get("/v1/compliance/gaps", params={"projectId": project_id})

    # ── Prompts ─────────────────────────────────────────────────────────

    def create_prompt(self, project_id: str, name: str, content: str, model: str = "gpt-4o", tags: Optional[List[str]] = None) -> Dict[str, Any]:
        """Create a prompt template."""
        return self._post("/v1/prompts", json={"projectId": project_id, "name": name, "content": content, "model": model, "tags": tags or []})

    def list_prompts(self, project_id: str) -> List[Dict[str, Any]]:
        """List prompts."""
        return self._get("/v1/prompts", params={"projectId": project_id})

    # ── Datasets ────────────────────────────────────────────────────────

    def create_dataset(self, project_id: str, name: str, cases: Optional[List[Dict]] = None, description: str = "") -> Dict[str, Any]:
        """Create a dataset."""
        return self._post("/v1/datasets", json={"projectId": project_id, "name": name, "cases": cases or [], "description": description})

    def list_datasets(self, project_id: str) -> List[Dict[str, Any]]:
        """List datasets."""
        return self._get("/v1/datasets", params={"projectId": project_id})

    # ── NL Pipeline ─────────────────────────────────────────────────────

    def ask(self, question: str, project_id: Optional[str] = None) -> Dict[str, Any]:
        """Ask the AI copilot."""
        return self._post("/v1/ask", json={"question": question, "projectId": project_id})

    def generate_eval_suite(self, description: str, project_id: Optional[str] = None) -> Dict[str, Any]:
        """Generate eval test suite from description."""
        return self._post("/v1/generate-eval-suite", json={"description": description, "projectId": project_id})

    # ── AI SBOM ─────────────────────────────────────────────────────────

    def get_ai_sbom(self, project_id: str) -> Dict[str, Any]:
        """Get AI System Bill of Materials."""
        return self._get("/v1/ai-sbom", params={"projectId": project_id})

    # ── Threat Intelligence ─────────────────────────────────────────────

    def get_threat_intelligence(self, project_id: str) -> Dict[str, Any]:
        """Get threat intelligence data."""
        return self._get("/v1/threat-intelligence", params={"projectId": project_id})

    # ── Audit Logs ──────────────────────────────────────────────────────

    def get_audit_logs(self, org_id: str) -> List[Dict[str, Any]]:
        """Get audit logs."""
        return self._get("/v1/audit-logs", params={"orgId": org_id})

    # ── Notifications ───────────────────────────────────────────────────

    def list_notifications(self) -> List[Dict[str, Any]]:
        """List notifications."""
        return self._get("/v1/notifications")

    # ── Templates ───────────────────────────────────────────────────────

    def list_templates(self) -> List[Dict[str, Any]]:
        """List eval templates."""
        return self._get("/v1/templates")

    # ── Marketplace ─────────────────────────────────────────────────────

    def get_marketplace(self) -> Dict[str, Any]:
        """Get marketplace."""
        return self._get("/v1/marketplace")

    # ── Missing methods (parity with JS SDK) ───────────────────────────

    def get_eval_run(self, run_id: str) -> Dict[str, Any]:
        """Get a specific eval run by ID."""
        return self._get(f"/v1/evals/{run_id}")

    def get_trace(self, trace_id: str) -> Dict[str, Any]:
        """Get a specific trace by ID."""
        return self._get(f"/v1/traces/{trace_id}")

    def trace(self, project_id: str, session_id: str, steps: List[Dict] = None) -> Dict[str, Any]:
        """Create a trace."""
        return self._post("/v1/traces", json={"projectId": project_id, "sessionId": session_id, "steps": steps or []})

    def security_scan(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Start a security scan (alias for run_scan)."""
        return self._post("/v1/security", json=config)

    def create_annotation(self, project_id: str, log_id: str, label: str, score: float = None, notes: str = None) -> Dict[str, Any]:
        """Create an annotation on a log entry."""
        body: Dict[str, Any] = {"projectId": project_id, "logId": log_id, "label": label}
        if score is not None:
            body["score"] = score
        if notes:
            body["notes"] = notes
        return self._post("/v1/annotations", json=body)

    def list_annotations(self, project_id: str) -> List[Dict[str, Any]]:
        """List annotations for a project."""
        return self._get(f"/v1/annotations?projectId={project_id}")

    def list_eval_schedules(self, project_id: str) -> List[Dict[str, Any]]:
        """List eval schedules for a project."""
        return self._get(f"/v1/eval-schedules?projectId={project_id}")

    def list_incidents(self, project_id: str) -> List[Dict[str, Any]]:
        """List incidents for a project."""
        return self._get(f"/v1/incidents?projectId={project_id}")

    def list_feature_flags(self, project_id: str) -> List[Dict[str, Any]]:
        """List feature flags for a project."""
        return self._get(f"/v1/feature-flags?projectId={project_id}")

    def list_guardrails(self, project_id: str) -> Dict[str, Any]:
        """List guardrails for a project."""
        return self._get(f"/v1/guardrails?projectId={project_id}")

    def list_team(self, org_id: str) -> List[Dict[str, Any]]:
        """List team members for an organization."""
        return self._get(f"/v1/team?orgId={org_id}")

    def list_webhooks(self, org_id: str) -> List[Dict[str, Any]]:
        """List webhooks for an organization."""
        return self._get(f"/v1/webhooks?orgId={org_id}")

    def get_gateway_health(self) -> Dict[str, Any]:
        """Get gateway health status."""
        return self._get("/v1/gateway/health")

    def get_gateway_stats(self, project_id: str) -> Dict[str, Any]:
        """Get gateway usage statistics."""
        return self._get(f"/v1/gateway/stats?projectId={project_id}")

    def get_gateway_config(self, project_id: str) -> Dict[str, Any]:
        """Get gateway configuration."""
        return self._get(f"/v1/gateway?projectId={project_id}")

    def get_monitoring_drift(self, project_id: str) -> Dict[str, Any]:
        """Get drift detection status."""
        return self._get(f"/v1/monitoring/drift?projectId={project_id}")

    def get_monitoring_sla(self, project_id: str) -> Dict[str, Any]:
        """Get SLA monitoring data."""
        return self._get(f"/v1/monitoring/sla?projectId={project_id}")

    def get_cost_budget(self, project_id: str) -> Dict[str, Any]:
        """Get cost budget for a project."""
        return self._get(f"/v1/cost/budget?projectId={project_id}")

    def get_siem_connectors(self, project_id: str) -> Dict[str, Any]:
        """Get SIEM connector configuration."""
        return self._get(f"/v1/siem?projectId={project_id}")

    def get_settings(self, project_id: str) -> Dict[str, Any]:
        """Get project settings."""
        return self._get(f"/v1/settings?projectId={project_id}")

    def get_model_cards(self, project_id: str) -> Dict[str, Any]:
        """Get model cards for compliance."""
        return self._get(f"/v1/compliance/model-cards?projectId={project_id}")

    def export_compliance(self, project_id: str, format: str = "json") -> Dict[str, Any]:
        """Export compliance report."""
        return self._get(f"/v1/compliance/export?projectId={project_id}&format={format}")

    def export_results(self, run_id: str, format: str, project_id: str) -> Dict[str, Any]:
        """Export eval results in specified format."""
        return self._get(f"/v1/exports?runId={run_id}&format={format}&projectId={project_id}")

    def generate_ai_sbom(self, project_id: str) -> Dict[str, Any]:
        """Generate AI Software Bill of Materials."""
        return self._post("/v1/ai-sbom/generate", json={"projectId": project_id})

    def ingest_otlp_traces(self, resource_spans: List[Dict]) -> Dict[str, Any]:
        """Ingest OpenTelemetry traces."""
        return self._post("/v1/ingest/otlp/traces", json={"resourceSpans": resource_spans})

    def ingest_otlp_logs(self, resource_logs: List[Dict]) -> Dict[str, Any]:
        """Ingest OpenTelemetry logs."""
        return self._post("/v1/ingest/otlp/logs", json={"resourceLogs": resource_logs})

    def ingest_otlp_metrics(self, resource_metrics: List[Dict]) -> Dict[str, Any]:
        """Ingest OpenTelemetry metrics."""
        return self._post("/v1/ingest/otlp/metrics", json={"resourceMetrics": resource_metrics})

    # ─── Provider Keys (BYOK vault) ─────────────────────────────────────
    #
    # Plaintext API keys are encrypted server-side via Supabase Vault envelope
    # encryption; responses never include the plaintext.

    def list_provider_keys(
        self, org_id: str, project_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """List metadata for all BYOK provider keys in the org.

        Returns ``{"keys": [...], "total": N}``. Keys include ``id``,
        ``provider``, ``project_id``, ``label``, ``key_last4``, ``created_at``,
        ``rotated_at`` — never plaintext or ciphertext.
        """
        params = f"?orgId={org_id}"
        if project_id:
            params += f"&projectId={project_id}"
        return self._get(f"/v1/provider-keys{params}")

    def upsert_provider_key(
        self,
        org_id: str,
        provider: str,
        api_key: str,
        project_id: Optional[str] = None,
        label: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create or rotate a BYOK key. If a row already exists for
        (org, project, provider), the vault row is rewrapped in place.
        Returns ``{"key": {...metadata}, "rotated": bool}``.
        """
        body: Dict[str, Any] = {"orgId": org_id, "provider": provider, "apiKey": api_key}
        if project_id is not None:
            body["projectId"] = project_id
        if label is not None:
            body["label"] = label
        return self._post("/v1/provider-keys", json=body)

    def delete_provider_key(self, org_id: str, key_id: str) -> Dict[str, Any]:
        """Revoke a BYOK key. The underlying vault.secrets row is auto-cleaned."""
        return self._delete(f"/v1/provider-keys?id={key_id}&orgId={org_id}")

    # ─── Models Registry (custom pricing overrides) ────────────────────

    def list_models(
        self, org_id: str, project_id: Optional[str] = None, model: Optional[str] = None
    ) -> Dict[str, Any]:
        """List custom model pricing overrides."""
        params = f"?orgId={org_id}"
        if project_id:
            params += f"&projectId={project_id}"
        if model:
            params += f"&model={model}"
        return self._get(f"/v1/models/registry{params}")

    def upsert_model(
        self,
        org_id: str,
        model_name: str,
        input_price_per_1m_usd: float,
        output_price_per_1m_usd: float,
        project_id: Optional[str] = None,
        provider: Optional[str] = None,
        display_name: Optional[str] = None,
        context_window: Optional[int] = None,
        notes: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create or update a custom pricing override. Prices in USD per
        million tokens. Effect propagates within 60 s via server-side cache."""
        body: Dict[str, Any] = {
            "orgId": org_id,
            "modelName": model_name,
            "inputPricePer1mUsd": input_price_per_1m_usd,
            "outputPricePer1mUsd": output_price_per_1m_usd,
        }
        if project_id is not None:
            body["projectId"] = project_id
        if provider is not None:
            body["provider"] = provider
        if display_name is not None:
            body["displayName"] = display_name
        if context_window is not None:
            body["contextWindow"] = context_window
        if notes is not None:
            body["notes"] = notes
        return self._post("/v1/models/registry", json=body)

    def delete_model(self, org_id: str, model_id: str) -> Dict[str, Any]:
        """Remove a custom pricing override — the model falls back to built-in rates."""
        return self._delete(f"/v1/models/registry?id={model_id}&orgId={org_id}")

    # ─── API-key budget caps ───────────────────────────────────────────

    def get_api_key_budget(self, key_id: str) -> Dict[str, Any]:
        """Get the current month's spend + cap + percent-used for a virtual key.

        Returns ``{"keyId", "name", "monthlyBudgetUsd", "currentPeriodSpentUsd",
        "currentPeriodStartedAt", "remainingUsd", "percentUsed", "staleReset"}``.
        ``staleReset: true`` means the next gateway request will reset the
        counter due to month rollover.
        """
        return self._get(f"/v1/api-keys/{key_id}/budget")

    def set_api_key_budget(
        self, key_id: str, monthly_budget_usd: Optional[float]
    ) -> Dict[str, Any]:
        """Set or remove the monthly USD cap. Pass ``None`` to remove the cap.

        Once spend reaches the cap, the gateway proxy returns
        ``402 Payment Required`` until the next period begins.
        """
        return self._patch(
            f"/v1/api-keys/{key_id}/budget",
            json={"monthlyBudgetUsd": monthly_budget_usd},
        )

    def remove_api_key_budget(self, key_id: str) -> Dict[str, Any]:
        """Convenience alias for ``set_api_key_budget(key_id, None)``."""
        return self._delete(f"/v1/api-keys/{key_id}/budget")

    # ─── Trace attachments (inline blob storage) ───────────────────────

    def list_trace_attachments(self, trace_id: str, project_id: str) -> Dict[str, Any]:
        """List all attachments on a trace (metadata only — use
        ``fetch_trace_attachment`` to download binary payload).
        """
        return self._get(
            f"/v1/traces/{trace_id}/attachments?projectId={project_id}"
        )

    def upload_trace_attachment(
        self,
        trace_id: str,
        project_id: str,
        span_id: str,
        name: str,
        mime_type: str,
        data: Union[bytes, bytearray, str],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Attach a blob (image / audio / text / json / pdf) to a span.

        ``data`` may be raw bytes, a bytearray, or a base64-encoded string.
        1 MB size cap enforced client-side to avoid a wasted round trip.
        """
        if isinstance(data, (bytes, bytearray)):
            if len(data) > 1_048_576:
                raise ValueError(
                    f"Attachment exceeds 1 MB (got {len(data)} bytes); "
                    "V1 only supports inline storage."
                )
            payload_b64 = base64.b64encode(bytes(data)).decode("ascii")
        elif isinstance(data, str):
            # Strip data-URL prefix if caller passed one.
            payload_b64 = data.split(",", 1)[1] if data.startswith("data:") else data
            padding = payload_b64.count("=")
            decoded_bytes = (len(payload_b64) * 3) // 4 - padding
            if decoded_bytes > 1_048_576:
                raise ValueError(
                    f"Attachment exceeds 1 MB (decoded {decoded_bytes} bytes)."
                )
        else:
            raise TypeError("data must be bytes, bytearray, or base64 str")

        body: Dict[str, Any] = {
            "projectId": project_id,
            "spanId": span_id,
            "name": name,
            "mimeType": mime_type,
            "dataBase64": payload_b64,
        }
        if metadata is not None:
            body["metadata"] = metadata
        return self._post(f"/v1/traces/{trace_id}/attachments", json=body)

    def fetch_trace_attachment(
        self, trace_id: str, attachment_id: str, project_id: str
    ) -> bytes:
        """Download the raw bytes of an attachment. Returns the decoded
        binary payload; the caller should respect ``mime_type`` (available
        via ``list_trace_attachments``) when deciding how to render.
        """
        # Use the raw requests session so we get bytes, not JSON.
        url = f"{self.base_url}/v1/traces/{trace_id}/attachments/{attachment_id}?projectId={project_id}"
        resp = self.session.get(url, timeout=self.timeout)
        if resp.status_code >= 400:
            raise EvalGuardError(
                f"Failed to fetch attachment (status {resp.status_code})",
                status_code=resp.status_code,
                body=resp.text,
            )
        return resp.content

    def delete_trace_attachment(
        self, trace_id: str, attachment_id: str, project_id: str
    ) -> Dict[str, Any]:
        """Revoke an attachment."""
        return self._delete(
            f"/v1/traces/{trace_id}/attachments?id={attachment_id}&projectId={project_id}"
        )

    # ─── Agent-run metered billing (Gap #5) ─────────────────────────────

    def start_agent_run(
        self,
        api_key_id: Optional[str] = None,
        end_customer_id: Optional[str] = None,
        trace_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Open a new metered agent run. Returns ``{runId, status, startedAt}``.
        Pass ``x-evalguard-run-id: <runId>`` on gateway calls to meter them."""
        body: Dict[str, Any] = {}
        if api_key_id: body["apiKeyId"] = api_key_id
        if end_customer_id: body["endCustomerId"] = end_customer_id
        if trace_id: body["traceId"] = trace_id
        if metadata: body["metadata"] = metadata
        return self._post("/v1/agent-runs/start", json=body)

    def end_agent_run(
        self,
        run_id: str,
        cost_usd: float = 0.0,
        tokens_in: int = 0,
        tokens_out: int = 0,
        status: str = "completed",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Close an agent run. Idempotent. ``status`` ∈
        completed | failed | budget_exceeded."""
        body: Dict[str, Any] = {
            "costUsd": cost_usd, "tokensIn": tokens_in, "tokensOut": tokens_out, "status": status,
        }
        if metadata: body["metadata"] = metadata
        return self._post(f"/v1/agent-runs/{run_id}/end", json=body)

    def list_agent_runs(
        self,
        api_key_id: Optional[str] = None,
        agent_tag: Optional[str] = None,
        end_customer_id: Optional[str] = None,
        since: Optional[str] = None,
        limit: int = 100,
        group_by: Optional[str] = None,
    ) -> Dict[str, Any]:
        """List agent runs, optionally grouped for chargeback by
        agent_tag / end_customer_id / api_key_id."""
        params: List[str] = []
        if api_key_id: params.append(f"apiKeyId={api_key_id}")
        if agent_tag: params.append(f"agentTag={agent_tag}")
        if end_customer_id: params.append(f"endCustomerId={end_customer_id}")
        if since: params.append(f"since={since}")
        params.append(f"limit={limit}")
        if group_by: params.append(f"groupBy={group_by}")
        return self._get(f"/v1/agent-runs?{'&'.join(params)}")

    # ─── Model-scan governance (Gap #1) ─────────────────────────────────

    def promote_model_scan(
        self,
        scan_id: str,
        to_env: str,
        from_env: Optional[str] = None,
        override: bool = False,
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Promote a scanned model to an environment. Suspicious/malicious
        verdicts 403 unless override=True + reason (>=8 chars)."""
        body: Dict[str, Any] = {"toEnv": to_env, "override": override}
        if from_env: body["fromEnv"] = from_env
        if reason: body["reason"] = reason
        return self._post(f"/v1/security/model-scan/{scan_id}/promote", json=body)

    def get_model_scan_attestation(self, scan_id: str) -> Dict[str, Any]:
        """Fetch the CycloneDX-ML 1.6 attestation for a scan. Cached on first call."""
        return self._get(f"/v1/security/model-scan/{scan_id}/attestation")

    # ─── Shadow-AI discovery (Gap #2) ───────────────────────────────────

    def ingest_shadow_ai_sightings(
        self,
        source: str,
        rows: List[Dict[str, Any]],
        project_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Ingest egress / SSO / CASB log rows. ``source`` ∈ zscaler |
        netskope | cloudflare | okta | generic. Server-side merge is
        additive — re-ingesting the same rows increments counts,
        never overwrites."""
        body: Dict[str, Any] = {"source": source, "rows": rows}
        if project_id: body["projectId"] = project_id
        return self._post("/v1/shadow-ai/ingest", json=body)

    def set_shadow_ai_policy(
        self,
        domain: str,
        status: str,
        rationale: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Per-domain policy override. ``status`` ∈ approved | blocked | pending."""
        body: Dict[str, Any] = {"domain": domain, "status": status}
        if rationale: body["rationale"] = rationale
        if project_id: body["projectId"] = project_id
        return self._post("/v1/shadow-ai/policy", json=body)

    def list_shadow_ai_policies(self, project_id: str) -> Dict[str, Any]:
        return self._get(f"/v1/shadow-ai/policy?projectId={project_id}")

    def delete_shadow_ai_policy(self, domain: str, project_id: str) -> Dict[str, Any]:
        return self._delete(f"/v1/shadow-ai/policy?domain={domain}&projectId={project_id}")

    # ─── SIEM inbound tokens (Gap #6) ───────────────────────────────────

    def create_siem_inbound_token(
        self,
        source: str,
        label: str,
        allowed_actions: Optional[List[str]] = None,
        rate_limit_per_min: int = 30,
        project_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Mint a SIEM inbound-webhook HMAC token. ``source`` ∈ splunk |
        sentinel | qradar | generic_webhook. The ``hmacSecret`` in the
        response is shown ONCE — save it into the SIEM now."""
        body: Dict[str, Any] = {
            "source": source,
            "label": label,
            "allowedActions": allowed_actions or ["quarantine_key"],
            "rateLimitPerMin": rate_limit_per_min,
        }
        if project_id: body["projectId"] = project_id
        return self._post("/v1/siem/inbound/tokens", json=body)

    def list_siem_inbound_tokens(self, project_id: str) -> Dict[str, Any]:
        return self._get(f"/v1/siem/inbound/tokens?projectId={project_id}")

    def revoke_siem_inbound_token(self, token_id: str, project_id: str) -> Dict[str, Any]:
        return self._delete(f"/v1/siem/inbound/tokens?id={token_id}&projectId={project_id}")

    # ─── Debug agent (Gap #4) ───────────────────────────────────────────

    def analyze_trace(
        self,
        trace_id: str,
        scorer_result_ids: Optional[List[str]] = None,
        analyzer_model: Optional[str] = None,
        analyzer_provider: Optional[str] = None,
        expected_output: Optional[str] = None,
        inline_context: Optional[Dict[str, Any]] = None,
        project_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Ask the debug agent to analyze a failing trace. Returns
        ``{sessionId, fixKind, confidence, rationale, suggestedFix,
        analyzerCostUsd}``. Passes BYOK OpenAI key first, falls back
        to server key only when none is stored. ``inlineContext`` bypasses
        the DB lookup — useful when your trace lives outside EvalGuard."""
        body: Dict[str, Any] = {"traceId": trace_id}
        if scorer_result_ids: body["scorerResultIds"] = scorer_result_ids
        if analyzer_model: body["analyzerModel"] = analyzer_model
        if analyzer_provider: body["analyzerProvider"] = analyzer_provider
        if expected_output: body["expectedOutput"] = expected_output
        if inline_context: body["inlineContext"] = inline_context
        if project_id: body["projectId"] = project_id
        return self._post("/v1/debug-agent", json=body)
