"""EvalGuard Python SDK -- evaluate, red-team, and guard LLM applications."""

from .client import EvalGuardClient, EvalGuardError
from .guardrails import GuardrailClient, GuardrailViolation
try:
    from .pytest_plugin import evalguard_test
except ImportError:
    evalguard_test = None  # pytest not installed — plugin available when pytest is
from .tracing import (
    Span,
    configure as configure_tracing,
    flush as flush_traces,
    get_current_span,
    get_current_trace_id,
    trace,
    traceable,
)
from .types import (
    BenchmarkResult,
    CaseResult,
    ComplianceReport,
    DriftReport,
    EvalCase,
    EvalResult,
    EvalRun,
    FirewallResult,
    FirewallRule,
    SecurityFinding,
    SecurityScanResult,
    TokenUsage,
)

__version__ = "1.2.0"

# Framework integrations -- lazy-imported to avoid hard dependencies.
# Users import from the submodule directly:
#   from evalguard.dify import DifyWebhookHandler, DifyGuardrail
#   from evalguard.chainlit import chainlit_trace, ChainlitTracer, ChainlitFeedback
#   from evalguard.gradio_integration import GradioGuard, traced_chat, guarded_chat
#   from evalguard.google_adk import EvalGuardAgentCallback
#   from evalguard.agno import EvalGuardTool, EvalGuardMonitor
#   from evalguard.browseruse import EvalGuardBrowserCallback
#   from evalguard.smolagents import EvalGuardMonitor, EvalGuardTool
#   from evalguard.composio import EvalGuardMiddleware, wrap_toolset
#   from evalguard.camel_ai import EvalGuardCamelMonitor, guard_society
#   from evalguard.mlflow_integration import EvalGuardMLflowCallback, log_evalguard_run, import_mlflow_experiment, make_evalguard_metric
#   from evalguard.mirascope import evalguard_trace, EvalGuardMirascopeMiddleware
#   from evalguard.controlflow import EvalGuardTaskObserver, observe_flow, guard_task_output

__all__ = [
    # Core client
    "EvalGuardClient",
    "EvalGuardError",
    # Guardrails
    "GuardrailClient",
    "GuardrailViolation",
    # Pytest plugin
    "evalguard_test",
    # Tracing
    "traceable",
    "trace",
    "Span",
    "configure_tracing",
    "flush_traces",
    "get_current_span",
    "get_current_trace_id",
    # Types
    "BenchmarkResult",
    "CaseResult",
    "ComplianceReport",
    "DriftReport",
    "EvalCase",
    "EvalResult",
    "EvalRun",
    "FirewallResult",
    "FirewallRule",
    "SecurityFinding",
    "SecurityScanResult",
    "TokenUsage",
]
