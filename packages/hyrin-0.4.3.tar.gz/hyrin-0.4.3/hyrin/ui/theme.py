"""APP_CSS: Textual layout + colour for HyrinApp.

The Active state's compose tree is:
  Header  /  QuestionPanel  /  VerticalScroll #chat-log  /  Input #prompt
  Static  #status-bar  /  Footer

`#chat-log { height: 1fr }` is the entire fix for spec §1's scrollback bug.
`#prompt { display: block }` stays unconditionally — only the *submit* path
gates on `streaming`, so keystrokes never drop (spec §8.5)."""

APP_CSS = """
Screen { layers: base banner; }

Header { dock: top; }
Footer { dock: bottom; }

QuestionPanel {
    border: round $primary;
    padding: 0 1;
    margin-bottom: 1;
}
QuestionPanel > Label { text-style: bold; }

#chat-log {
    height: 1fr;
    border: none;
    padding: 0 1;
    scrollbar-gutter: stable;
}

MessageWidget {
    layout: vertical;
    height: auto;
    margin-bottom: 1;
}
MessageWidget.user { color: $accent; }
MessageWidget.assistant { color: $text; }
MessageWidget.assistant.interrupted { color: $text-muted; text-style: italic; }
MessageWidget.assistant.pending { color: $text-muted; text-style: italic; }
MessageWidget.system { color: $text-muted; text-style: italic; }

MessageWidget > .role-label {
    color: $text-muted;
    text-style: bold;
    height: 1;
    padding: 0;
    margin: 0;
}
MessageWidget.user > .role-label { color: $accent; }
MessageWidget.assistant > .role-label { color: $success; }

MessageWidget > Static { height: auto; padding: 0; margin: 0; }
MessageWidget > Markdown { height: auto; padding: 0; margin: 0; background: transparent; }
MessageWidget > Markdown > MarkdownBlock { padding: 0; margin: 0; }

ActivityWidget {
    height: auto;
    padding: 0 1;
    margin-bottom: 1;
}

SystemNoticeWidget {
    height: auto;
    border: tall $warning;
    padding: 0 1;
    margin: 1 0;
    color: $warning;
}
SystemNoticeWidget.error { border: tall $error; color: $error; }

PlanReviewWidget { height: auto; }

#prompt {
    dock: bottom;
    height: 5;
    border: round $primary;
    margin: 0 1;
}
#prompt:focus { border: round $accent; }
#prompt:disabled {
    border: round $surface;
    color: $text-muted;
    opacity: 0.6;
}

#status-bar {
    dock: bottom;
    height: 1;
    color: $text-muted;
    background: $surface;
    padding: 0 1;
}
#status-bar.thinking { color: $warning; text-style: bold; }

ReconnectBadge {
    color: $warning;
    text-style: bold;
}

HyrinApp.pairing #chat-log, HyrinApp.pairing #prompt { display: none; }
HyrinApp.standby #prompt { display: none; }
HyrinApp.ended #prompt { display: none; }
"""
