"""Widget vocabulary used by HyrinApp.

All widgets are passive: the App constructs and mounts them, then mutates
them via setter methods or `update()`. None of them schedule work or own
state beyond what's needed to render.
"""
from __future__ import annotations

import re
from textual.containers import Container
from textual.widget import Widget
from textual.widgets import Collapsible, Label, Markdown, Static
from rich.text import Text


_MARKER_RE = re.compile(r"\A(## (?:Plan|Implementing))[ \t]*\r?\n\n?")


def strip_phase_markers(text):
    """Defensive strip of leading '## Plan' / '## Implementing' markers.

    Server already strips these at persist time; this is belt-and-suspenders
    in case a partial chunk leaks to the render pipeline before the server
    completes the strip. See spec §2.3.
    """
    if not text:
        return ""
    return _MARKER_RE.sub("", text)


class QuestionPanel(Collapsible):
    """Title + language + markdown body, collapsed via Ctrl+B."""

    def __init__(self, title: str, language: str, body: str):
        header = f"{title}  [{language}]" if language else title
        super().__init__(title=header, collapsed=False)
        self._body_md = Markdown(body)

    def compose(self):
        yield self._body_md


_ROLE_LABELS = {"user": "you ›", "assistant": "hyrin ›"}
SPINNER_FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
_SPINNER_INTERVAL = 0.08


def _thinking_text(frame_idx: int) -> str:
    return f"{SPINNER_FRAMES[frame_idx % len(SPINNER_FRAMES)]} thinking…"


class MessageWidget(Container):
    """One chat-log entry: user, assistant, or system. Renders markdown
    for assistant turns, plain text otherwise. Use `set_assistant_text`
    repeatedly to stream a reply incrementally."""

    def __init__(self, role: str, content: str = "", *, interrupted: bool = False):
        super().__init__()
        self.role = role
        self.add_class(role)
        if interrupted:
            self.add_class("interrupted")
        self._pending = role == "assistant" and not content
        self._frame_idx = 0
        self._spinner_timer = None
        if self._pending:
            self.add_class("pending")
        if role == "assistant":
            self._inner = Markdown(content or _thinking_text(0))
        else:
            self._inner = Static(content)

    def compose(self):
        label = _ROLE_LABELS.get(self.role)
        if label:
            yield Label(label, classes="role-label")
        yield self._inner

    def on_mount(self) -> None:
        if self._pending:
            self._spinner_timer = self.set_interval(_SPINNER_INTERVAL, self._tick_spinner)

    def _tick_spinner(self) -> None:
        if not self._pending or not isinstance(self._inner, Markdown):
            return
        self._frame_idx += 1
        self._inner.update(_thinking_text(self._frame_idx))

    def _stop_spinner(self) -> None:
        if self._spinner_timer is not None:
            self._spinner_timer.stop()
            self._spinner_timer = None

    def set_assistant_text(self, content: str) -> None:
        if isinstance(self._inner, Markdown):
            if self._pending and content:
                self._pending = False
                self._stop_spinner()
                self.remove_class("pending")
            content = strip_phase_markers(content) if content else ""
            if self._pending:
                self._inner.update(content or _thinking_text(self._frame_idx))
            else:
                self._inner.update(content)

    def mark_interrupted(self) -> None:
        self._pending = False
        self._stop_spinner()
        self.remove_class("pending")
        self.add_class("interrupted")


class ActivityWidget(Widget):
    """Renders one tool-execution line as semantic prose. No machinery exposed."""

    DEFAULT_CSS = """
    ActivityWidget {
        color: $text-muted;
        padding: 0 1;
    }
    """

    def __init__(self, tool: str, args: dict, result: dict, *, id: str | None = None):
        super().__init__(id=id)
        self.tool = tool
        self.args = args or {}
        self.result = result or {}

    def render(self) -> Text:
        return Text(self._label())

    def _label(self) -> str:
        t = self.tool
        a = self.args
        r = self.result
        if t == "read_file":
            if not a.get("path"):
                return "read_file: missing path"
            lines = (r.get("content") or "").count("\n")
            return f"Read {a.get('path')} ({lines} lines)"
        if t == "write_file":
            if not a.get("path"):
                return "write_file: missing path"
            lines = (a.get("content") or "").count("\n")
            return f"Wrote {a.get('path')} ({lines} lines)"
        if t == "edit_file":
            if not a.get("path"):
                return "edit_file: missing path"
            return f"Edited {a.get('path')}"
        if t == "list_directory":
            path = a.get("path") or "."
            return f"Listed {path.rstrip('/')}/"
        if t == "run_command":
            exit_code = r.get("exit_code", 0)
            return f"Ran {a.get('command')} — exit {exit_code}"
        return f"Activity: {t}"


class SystemNoticeWidget(Static):
    """Inline banner: reconnects, gap-reset, chat interrupted, errors."""

    def __init__(self, text: str, *, error: bool = False):
        super().__init__(text)
        self._text = text
        if error:
            self.add_class("error")

    @property
    def renderable(self) -> str:
        """Return the current text content (test-friendly alias for render())."""
        return self._text


class PlanReviewWidget(Widget):
    """Bordered card that shows the implementation plan and a CTA to approve.

    Once `mark_approved()` is called the widget collapses to a single
    confirmation line — the App calls this when a `phase_changed` event
    arrives with `to_phase == "implementing"`."""

    DEFAULT_CSS = """
    PlanReviewWidget {
        border: round $primary;
        padding: 1 2;
    }
    """

    def __init__(self, *, content: str, id: str | None = None):
        super().__init__(id=id)
        self.content = content
        self.approved = False

    def mark_approved(self) -> None:
        self.approved = True
        self.refresh()

    def render(self) -> Text:
        if self.approved:
            return Text("Plan approved · implementing")
        lines = ["Plan", ""]
        lines.append(self.content)
        lines.append("")
        lines.append("Type 'yes' / 'go' to approve, or push back with changes.")
        return Text("\n".join(lines))


class ReconnectBadge(Static):
    """Single-line indicator in the status bar."""

    def __init__(self):
        super().__init__("")
        self._text = ""

    def set_connected(self, connected: bool) -> None:
        self._text = "" if connected else "● reconnecting…"
        self.update(self._text)

    @property
    def renderable(self) -> str:
        """Return the current text content (test-friendly alias for render())."""
        return self._text


class ModeBadge(Static):
    """Header-level chip mirroring the web app's ModeBadge.

    Behaviour matches `app/frontend/components/Layout/ModeBadge.tsx`:
      - app_mode == "staging"     → "STAGING"   (amber/warning)
      - app_mode == "development" → "DEV"       (muted/neutral)
      - production / test / unknown / missing → no badge (display:none)

    Production must remain a "no badge" state — the absence of the badge
    is itself the signal that you're in prod. Hide via `display=False` so
    the widget takes zero visual space, matching the ReconnectBadge
    "appears only when relevant" pattern.
    """

    DEFAULT_CSS = """
    ModeBadge { display: none; height: 1; padding: 0 1; text-style: bold; }
    ModeBadge.-staging { display: block; background: $warning; color: $text; }
    ModeBadge.-dev { display: block; color: $text-muted; }
    """

    def __init__(self, app_mode: str = "", *, id: str | None = None):
        super().__init__("", id=id)
        self._app_mode = ""
        self.set_mode(app_mode)

    def set_mode(self, app_mode: str) -> None:
        self._app_mode = app_mode or ""
        self.remove_class("-staging")
        self.remove_class("-dev")
        if self._app_mode == "staging":
            self.add_class("-staging")
            self.update("STAGING")
        elif self._app_mode == "development":
            self.add_class("-dev")
            self.update("DEV")
        else:
            self.update("")

    @property
    def renderable(self) -> str:
        """Return the current text content (test-friendly alias)."""
        if self._app_mode == "staging":
            return "STAGING"
        if self._app_mode == "development":
            return "DEV"
        return ""
