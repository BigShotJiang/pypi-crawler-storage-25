"""HyrinApp: Textual App that owns the UI state machine and the message pump.

State machine:
    Pairing → Standby → Active → Ended

Message-pump pattern:
    Workers (`@work` coroutines) handle transports and post typed messages
    via `self.post_message(...)`. The App's `on_<MessageType>` handlers
    mutate widgets. The App never blocks on a transport.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os

from enum import Enum

import httpx
from pydantic import ValidationError


# Lightweight file logger so we can diagnose tool-dispatch / streaming
# behaviour after the fact. The TUI takes over stdout/stderr, so
# `print()` is invisible. Path: ~/.cache/hyrin/hyrin.log (rotates manually).
# Mode 0o600 because the log captures candidate code, command output, and
# chat fragments — never readable by other users on the same machine.
def _setup_logger() -> logging.Logger:
    log_dir = os.path.expanduser("~/.cache/hyrin")
    os.makedirs(log_dir, mode=0o700, exist_ok=True)
    logger = logging.getLogger("hyrin")
    if not logger.handlers:
        log_path = os.path.join(log_dir, "hyrin.log")
        # Pre-create with 0o600 so FileHandler doesn't widen via the default umask.
        if not os.path.exists(log_path):
            fd = os.open(log_path, os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
            os.close(fd)
        else:
            try:
                os.chmod(log_path, 0o600)
            except OSError:
                pass
        h = logging.FileHandler(log_path)
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(h)
        logger.setLevel(logging.INFO)
        logger.propagate = False
    return logger


log = _setup_logger()


class _NoPair(RuntimeError):
    """Raised when an operation requires a paired session but
    `pair_response` is None. Callers at worker boundaries catch this and
    surface a system notice; in-process callers (UI helpers) treat it as
    a no-op."""


from textual import on
from textual.app import App
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.message import Message
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.widgets import Button, Footer, Header, Input, Label, Static, TextArea

from .client import cable as cable_client
from .client import chat as chat_client
from .client import pair as pair_client
from .client.activity import ActivityClient
from .client.chat import (
    ChatEventType, ChatInterrupted,
    ChatUnauthorizedError, ChatSessionGoneError, ChatServerError,
)
from .client.types import ChatMessage, PairResponse, PhaseChangedEvent, QuestionInfo
from .config import Config
from .constants import PHASE_LABELS, SERVER_URL


NO_BODY_PLACEHOLDER = "_(no body provided)_"


def _question_body_or_placeholder(body: str | None) -> str:
    """Return the question body, falling back to a markdown placeholder
    when the server sent an empty/None body. Centralised so both the
    compose path and the deferred-mount path render identical text."""
    if body and body.strip():
        return body
    return NO_BODY_PLACEHOLDER
from .tools import registry as tool_registry
from .ui.theme import APP_CSS
from .ui.widgets import (
    QuestionPanel, ReconnectBadge, ModeBadge, MessageWidget, SystemNoticeWidget,
    ActivityWidget, PlanReviewWidget, SPINNER_FRAMES,
)


class AppState(Enum):
    PAIRING = "pairing"
    STANDBY = "standby"
    ACTIVE = "active"
    ENDED = "ended"


class PairCompleted(Message):
    def __init__(self, response: PairResponse):
        super().__init__()
        self.response = response


class PairFailed(Message):
    def __init__(self, error: Exception):
        super().__init__()
        self.error = error


class StreamStarted(Message):
    pass


class StreamChunkReceived(Message):
    def __init__(self, content: str):
        super().__init__()
        self.content = content


class StreamFinished(Message):
    def __init__(self, reason: str):
        super().__init__()
        self.reason = reason


class StreamErrored(Message):
    def __init__(self, code: str, message: str):
        super().__init__()
        self.code = code
        self.message = message


class SystemNoticePosted(Message):
    """Server emitted an out-of-band `system_notice` SSE event. Payload
    carries a `{level, text}` pair — `level == "error"` renders as a red
    banner; anything else is a neutral inline notice. Drift-failure copy
    arrives as level="warning"."""

    def __init__(self, level: str, text: str):
        super().__init__()
        self.level = level
        self.text = text


class ChatInterruptedNotice(Message):
    def __init__(self, partial: str):
        super().__init__()
        self.partial = partial


class CableStatusChanged(Message):
    def __init__(self, connected: bool):
        super().__init__()
        self.connected = connected


class CableEventReceived(Message):
    def __init__(self, event_type: str, payload: dict, seq: int | None):
        super().__init__()
        self.event_type = event_type
        self.payload = payload
        self.seq = seq


class GapDetected(Message):
    pass


def _friendly_error(code: str) -> str:
    table = {
        "rate_limited": "The AI is temporarily rate limited. Wait a few seconds and try again.",
        "provider_error": "The AI provider returned an error. Try again in a moment.",
        "sse_error": "Couldn't reach the interviewer right now. Please try sending again.",
        "chat_failed": "Couldn't reach the interviewer right now. Please try sending again.",
        "session_gone": "This interview session is no longer active.",
        "cable_disconnected": "Connection problem — retrying.",
    }
    return table.get(code, "Something went wrong. Please try again.")


class PromptTextArea(TextArea):
    """Multi-line input. Enter posts a Submitted message; Shift+Enter
    (and Alt+Enter as a terminal-fallback) inserts a newline. Option+Arrow
    word navigation, copy/paste, and selection come from TextArea natively."""

    class Submitted(Message):
        def __init__(self, value: str) -> None:
            super().__init__()
            self.value = value

    async def _on_key(self, event):
        if event.key == "enter":
            event.stop()
            event.prevent_default()
            self.post_message(self.Submitted(self.text))
            return
        if event.key in ("shift+enter", "alt+enter"):
            event.stop()
            event.prevent_default()
            self.insert("\n")
            return
        await super()._on_key(event)


class _QuitConfirm(ModalScreen[bool]):
    BINDINGS = [
        Binding("escape", "dismiss_no", "Cancel", show=False),
        Binding("y", "dismiss_yes", "Quit", show=False),
        Binding("n", "dismiss_no", "Cancel", show=False),
    ]

    DEFAULT_CSS = """
    _QuitConfirm {
        align: center middle;
    }
    _QuitConfirm > Vertical {
        width: 50;
        padding: 1 2;
        border: round $primary;
        background: $surface;
    }
    _QuitConfirm Label { padding-bottom: 1; text-style: bold; }
    _QuitConfirm Horizontal { height: auto; align: right middle; padding-top: 1; }
    _QuitConfirm Button { margin-left: 2; }
    """

    def compose(self):
        from textual.containers import Horizontal
        yield Vertical(
            Label("Quit the active interview?"),
            Static("Press Y to quit, N or Esc to cancel.", classes="hint"),
            Horizontal(
                Button("Cancel", id="cancel"),
                Button("Quit", id="quit", variant="error"),
            ),
        )

    def on_mount(self) -> None:
        # Focus the safer option by default; Tab cycles to Quit.
        self.query_one("#cancel", Button).focus()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "quit")

    def action_dismiss_yes(self) -> None:
        self.dismiss(True)

    def action_dismiss_no(self) -> None:
        self.dismiss(False)


class HyrinApp(App[int]):
    CSS = APP_CSS
    TITLE = "hyrin"
    ENABLE_COMMAND_PALETTE = False
    BINDINGS = [
        Binding("ctrl+c", "cancel_stream", "Cancel"),
        Binding("ctrl+q", "request_quit", "Quit"),
        Binding("escape", "request_quit", "Quit", show=False),
        Binding("ctrl+b", "toggle_question", "Question", show=False),
    ]

    pair_response: PairResponse | None = None
    state: reactive[AppState] = reactive(AppState.PAIRING, init=False)
    streaming: reactive[bool] = reactive(False)
    _current_assistant: MessageWidget | None = None

    def __init__(self, cfg: Config, *, _skip_worker: bool = False):
        super().__init__()
        self.cfg = cfg
        self._skip_worker = _skip_worker
        self._chat_history: list = []  # filled with ChatMessage in 9.5
        self._http_chat = None         # httpx.AsyncClient, set in 9.5
        self._activity = None          # ActivityClient, set in 9.6
        self._activity_http = None     # httpx.AsyncClient owned by ActivityClient
        self._activity_seq = 0
        self._last_seq: int = 0
        self._cable_stop: asyncio.Event | None = None
        self._cable_connected: bool = False
        self._spinner_idx: int = 0
        self._status_spinner_timer = None
        self._last_phase_event: PhaseChangedEvent | None = None
        self._pending_plan_review: bool = False
        self._assistant_buffer: str = ""
        self._chat_history_lock: asyncio.Lock = asyncio.Lock()

    def _require_pair(self) -> PairResponse:
        """Return the active pair response or raise `_NoPair`. Use this
        anywhere `self.pair_response` is read after pairing should have
        completed; the sentinel exception is the single failure shape."""
        if self.pair_response is None:
            raise _NoPair("pair_response is None")
        return self.pair_response

    def _phase_chip_text(self, event: PhaseChangedEvent) -> str:
        phase = event.to_phase
        if phase == "deciding" and event.decisions_total:
            return f"Decisions ({event.decisions_completed or 0}/{event.decisions_total})"
        return PHASE_LABELS.get(phase, phase.title() if phase else "")

    def compose(self):
        yield Header()
        yield ModeBadge(id="mode-badge")
        yield Static("[ — ]", id="phase-chip")
        if self.pair_response is not None and self.pair_response.question:
            q = self.pair_response.question
            yield QuestionPanel(
                q.title or f"Question #{q.id}",
                q.language or "",
                _question_body_or_placeholder(q.body),
            )
        yield VerticalScroll(id="chat-log")
        yield PromptTextArea(id="prompt")
        self._reconnect_badge = ReconnectBadge()
        yield Static(id="status-bar")
        yield Footer()

    async def on_mount(self) -> None:
        # Set initial CSS class for PAIRING state without triggering watch_state
        self.add_class(AppState.PAIRING.value)
        # Seed the status bar so it isn't blank during pair (the candidate
        # otherwise sees an empty line above the footer).
        self._update_status_bar()
        if not self._skip_worker:
            self.run_worker(self._pair_worker(), group="pair", exclusive=True, exit_on_error=False)

    async def _pair_worker(self) -> None:
        async with httpx.AsyncClient(base_url=SERVER_URL) as http:
            try:
                resp = await pair_client.pair(http, self.cfg.code)
                self.post_message(PairCompleted(response=resp))
            except Exception as exc:
                log.debug("[pair_worker.unexpected]", exc_info=exc)
                self.post_message(PairFailed(error=exc))

    def on_pair_completed(self, message: PairCompleted) -> None:
        self.pair_response = message.response
        workspace = message.response.workspace.name
        if workspace:
            self.title = f"hyrin • {workspace}"
        # Reflect the server's `app_mode` in the header chip. Production /
        # test / unknown values render as nothing — the absence of a badge
        # is the prod signal.
        try:
            self.query_one("#mode-badge", ModeBadge).set_mode(message.response.app_mode)
        except Exception as exc:
            log.debug("[mode_badge.update]", exc_info=exc)
        if message.response.session.state == "in_progress":
            self.state = AppState.ACTIVE
        else:
            self.state = AppState.STANDBY
        # Mount QuestionPanel only when the interviewer has actually started
        # the session (state == ACTIVE). In STANDBY we deliberately hide it
        # so the candidate doesn't see the question before the timer starts.
        # The session_started cable event will move us to ACTIVE and trigger
        # mount_question_panel() then.
        if self.state is AppState.ACTIVE:
            self._mount_question_panel_if_needed()
        # In Standby, the candidate has paired but the interviewer hasn't
        # started the session yet. Without a banner the screen is blank;
        # mount a connection-confirmation notice so it's clear pairing
        # succeeded and we're waiting on the interviewer.
        if self.state is AppState.STANDBY:
            workspace = message.response.workspace.name
            self.query_one("#chat-log", VerticalScroll).mount(
                SystemNoticeWidget(
                    f"Connected to {workspace}. "
                    "Waiting for the interviewer to start your session.",
                )
            )
        self.refresh(layout=True)
        # Seed history from the server's prior messages, under the lock,
        # so a worker can't observe a half-built history.
        async def _seed_history():
            async with self._chat_history_lock:
                self._chat_history = [
                    ChatMessage(role=m.role, content=m.content)
                    for m in message.response.messages
                ]
        self.run_worker(_seed_history(), group="history-seed", exit_on_error=False)
        if self.state is AppState.ACTIVE:
            self._mount_history_messages()
        if not self._skip_worker:
            # Start the cable supervisor and the activity worker.
            self._cable_stop = asyncio.Event()
            self._activity_http = httpx.AsyncClient(base_url=SERVER_URL)
            self._activity = ActivityClient(
                self._activity_http,
                message.response.session_token,
                on_overflow_notice=self._on_activity_overflow_notice,
            )
            self.run_worker(self._activity.start(), group="activity-start", exit_on_error=False)
            self.run_worker(self._cable_supervisor_worker(), group="cable", exclusive=True, exit_on_error=False)

    def on_pair_failed(self, message: PairFailed) -> None:
        # Only transition to ENDED if we never successfully paired.
        if self.pair_response is not None:
            return
        # Surface the failure so the candidate isn't staring at a blank screen.
        # Common cases: 401/404 → invalid/expired code; 409 → already claimed;
        # 410 → session gone; transport errors → can't reach server.
        from .client.pair import (
            InvalidCodeError, AlreadyClaimedError, SessionGoneError, ServerError,
        )
        err = message.error
        if isinstance(err, InvalidCodeError):
            text = "Pairing code is invalid or expired. Ask your interviewer for a new code."
        elif isinstance(err, AlreadyClaimedError):
            text = "This code has already been claimed by another connection. Ask your interviewer for a new code."
        elif isinstance(err, SessionGoneError):
            text = "This interview session is no longer available."
        elif isinstance(err, ServerError):
            text = f"Server error during pairing (status {err.status}). Try again in a moment."
        else:
            text = f"Could not reach the interview server at {SERVER_URL}. Check the URL and your network."
        self.state = AppState.ENDED
        self.query_one("#chat-log", VerticalScroll).mount(
            SystemNoticeWidget(text, error=True)
        )

    def _mount_question_panel_if_needed(self) -> None:
        """Mount the QuestionPanel above #chat-log if pair_response has a
        question and one isn't already mounted. Called when entering ACTIVE."""
        try:
            pair = self._require_pair()
        except _NoPair:
            return
        if not pair.question:
            return
        if list(self.query(QuestionPanel).results()):
            return
        q = pair.question
        header = q.title or f"Question #{q.id}"
        panel = QuestionPanel(
            header,
            q.language or "",
            _question_body_or_placeholder(q.body),
        )
        chat_log = self.query_one("#chat-log")
        self.screen.mount(panel, before=chat_log)

    async def _cable_supervisor_worker(self) -> None:
        try:
            pair = self._require_pair()
        except _NoPair:
            log.debug("[cable.supervisor.no_pair] supervisor started without pair_response")
            return

        async def on_event(ev):
            self.post_message(CableEventReceived(
                event_type=ev.event_type, payload=ev.payload, seq=ev.seq,
            ))

        async def on_status(connected: bool):
            self.post_message(CableStatusChanged(connected=connected))

        await cable_client.run_supervisor(
            url=pair.cable_url,
            session_token=pair.session_token,
            last_seq_ref=lambda: self._last_seq,
            on_event=on_event,
            on_status=on_status,
            stop=self._cable_stop,
        )

    def on_cable_status_changed(self, message: CableStatusChanged) -> None:
        self._reconnect_badge.set_connected(message.connected)
        self._cable_connected = message.connected
        self._update_status_bar()

    def _update_status_bar(self) -> None:
        """Single source of truth for the bottom status line.

        Format: `<connection> · <workspace> · <phase>  [|  ⠋ AI is thinking…]`
        Phase shows the current AI state (Clarifying, Deciding, etc.).
        Streaming indicator (#4) gets the bold/warning colour via the
        `.thinking` CSS class so the candidate has obvious feedback during
        long agentic responses."""
        try:
            sb = self.query_one("#status-bar", Static)
        except Exception as exc:
            log.debug("[status_bar.query]", exc_info=exc)
            return  # not mounted yet
        workspace = (
            self.pair_response.workspace.name if self.pair_response else ""
        )
        connected = getattr(self, "_cable_connected", False)
        if connected:
            connection = f"● Connected · {workspace}" if workspace else "● Connected"
        elif self.pair_response:
            connection = f"● Connecting · {workspace}" if workspace else "● Connecting…"
        else:
            connection = "● Pairing…"

        # Build phase suffix if we have a phase event and are connected
        phase_suffix = ""
        if connected and self._last_phase_event:
            phase = self._last_phase_event.to_phase
            phase_label = PHASE_LABELS.get(phase, phase.title() if phase else "")
            if phase_label and phase != "done":
                phase_suffix = f" · {phase_label}"

        if self.streaming:
            sb.add_class("thinking")
            frame = SPINNER_FRAMES[self._spinner_idx % len(SPINNER_FRAMES)]
            # Show what the AI is doing based on phase
            verb = {
                "awaiting_approval": "planning",
                "implementing": "implementing",
            }.get(self._last_phase_event.to_phase if self._last_phase_event else None, "thinking")
            sb.update(f"{connection}{phase_suffix}    {frame} hyrin is {verb}…")
        else:
            sb.remove_class("thinking")
            sb.update(f"{connection}{phase_suffix}")

    def _on_activity_overflow_notice(self, dropped: int) -> None:
        """Surface a one-time SystemNotice when activity drops exceed
        OVERFLOW_NOTICE_THRESHOLD in a rolling minute. Mission-control
        visibility is degraded; we don't block the candidate, we just
        tell them."""
        # Called from non-Textual context (the worker enqueue path);
        # use post_message so it lands on the message pump.
        self.post_message(SystemNoticePosted(
            level="warning",
            text=(
                f"Local activity capture is dropping events "
                f"({dropped} in the last minute). The interview continues "
                f"normally — only mission-control telemetry is affected."
            ),
        ))

    def _tick_status_spinner(self) -> None:
        if not self.streaming:
            return
        self._spinner_idx += 1
        self._update_status_bar()

    def _start_status_spinner(self) -> None:
        if self._status_spinner_timer is None:
            self._status_spinner_timer = self.set_interval(0.08, self._tick_status_spinner)

    def _stop_status_spinner(self) -> None:
        if self._status_spinner_timer is not None:
            self._status_spinner_timer.stop()
            self._status_spinner_timer = None

    def _maybe_scroll_end(self, log: VerticalScroll) -> None:
        """Sticky auto-scroll: snap to bottom only if the user is already near it.

        Threshold of 3 rows — tight enough to feel responsive when following the
        stream, loose enough that nudge-scrolls (trackpad flick) don't disarm
        sticky mode. When the candidate has clearly scrolled up, the helper is a
        no-op so they can re-read without being yanked down.
        """
        if log.scroll_y >= log.max_scroll_y - 3:
            log.scroll_end(animate=False)

    def on_cable_event_received(self, message: CableEventReceived) -> None:
        """Cable event entry point. Bounded: classify and dispatch.

        Heavy work — `phase_changed` chip+status updates, `session_started`
        widget swap, `session_ended` shutdown, `question_advanced` chat-log
        clear and re-mount — runs on a background task so the message
        pump keeps flowing for chat workers during a phase transition.
        Trivial events (`gap`, `kick`) stay inline to avoid task overhead.
        """
        if message.seq is not None:
            self._last_seq = max(self._last_seq, message.seq)
        if message.event_type == "gap":
            self.post_message(GapDetected())
            return
        if message.event_type == "kick":
            self.state = AppState.ENDED
            return
        if message.event_type in ("phase_changed", "session_started",
                                  "session_ended", "question_advanced"):
            asyncio.create_task(
                self._handle_cable_event_heavy(message.event_type, message.payload or {})
            )
            return
        # Unknown event type: log and drop. Server adding a new event must
        # not crash the candidate.
        log.debug("unknown cable event_type=%r payload_keys=%r",
                  message.event_type, list((message.payload or {}).keys()))

    async def _handle_cable_event_heavy(self, event_type: str, payload: dict) -> None:
        """Run the widget-mounting / state-mutating branches off the main
        message handler. Each branch matches the original inline body of
        `on_cable_event_received` 1:1 — the only behavioural change is
        scheduling."""
        if event_type == "phase_changed":
            event = PhaseChangedEvent(
                from_phase=payload.get("from"),
                to_phase=payload.get("to", ""),
                question_id=payload.get("question_id"),
                decisions_completed=payload.get("decisions_completed"),
                decisions_total=payload.get("decisions_total"),
            )
            self._last_phase_event = event
            try:
                chip = self.query_one("#phase-chip", Static)
                chip.update(f"[ {self._phase_chip_text(event)} ]")
            except Exception as exc:
                log.debug("[phase_chip.update]", exc_info=exc)
            self._update_status_bar()
            if event.to_phase == "awaiting_approval":
                self._pending_plan_review = True
            elif event.to_phase == "implementing":
                # Collapse the most recently mounted PlanReviewWidget.
                results = list(self.query(PlanReviewWidget).results())
                if results:
                    results[-1].mark_approved()
            return
        if event_type == "session_started":
            self.state = AppState.ACTIVE
            # Now that the interviewer started the session, mount the
            # question panel and replace the standby banner.
            self._mount_question_panel_if_needed()
            self._replace_standby_banner_with_started_notice()
            return
        if event_type == "session_ended":
            self._handle_session_ended()
            return
        if event_type == "question_advanced":
            self._handle_question_advanced(payload)
            return

    def _replace_standby_banner_with_started_notice(self) -> None:
        """Remove the 'Waiting for the interviewer…' banner so the chat
        log starts clean once the interview is in progress."""
        for w in list(self.query("SystemNoticeWidget").results()):
            if "Waiting for the interviewer" in (w.content or ""):
                w.remove()

    # ── Lifecycle: session_ended ─────────────────────────────────────────────

    EXIT_DELAY_SECONDS = 3.0

    def _handle_session_ended(self) -> None:
        """Interviewer ended the session. Mount a goodbye notice, disable
        the prompt, and schedule a clean app exit so the candidate has a
        moment to read the notice before the TUI tears down."""
        self.state = AppState.ENDED
        try:
            log_chat = self.query_one("#chat-log", VerticalScroll)
            log_chat.mount(SystemNoticeWidget(
                "Interview ended. Thanks for pairing."
            ))
            self._maybe_scroll_end(log_chat)
        except Exception as exc:
            log.debug("[session_ended.notice_mount]", exc_info=exc)
        # Disable the prompt so no further input can be sent.
        try:
            self.query_one("#prompt", PromptTextArea).disabled = True
        except Exception as exc:
            log.debug("[session_ended.prompt_disable]", exc_info=exc)
        # Reset any in-flight streaming bookkeeping.
        self.streaming = False
        self._current_assistant = None
        self._stop_status_spinner()
        # Schedule clean exit (single-shot timer). Reuses the same exit
        # path as _QuitConfirm's "Quit" branch (self.exit(0)). We don't
        # push the modal here because the session is already over —
        # asking "quit?" would be weird; we just show the notice and go.
        self.set_timer(self.EXIT_DELAY_SECONDS, self._exit_after_session_ended)

    def _exit_after_session_ended(self) -> None:
        self.exit(0)

    # ── Lifecycle: question_advanced ─────────────────────────────────────────

    def _handle_question_advanced(self, payload: dict) -> None:
        """Interviewer advanced to the next question. Clear the chat log,
        reset client-side history, swap in a new QuestionPanel, and show a
        short moving-on notice.

        Tolerates two broadcast shapes:
          - New: ``payload["question"]`` carries the full QuestionInfo dict
            (id/title/body/language) — use it directly.
          - Old: ``payload["question"]`` absent — re-fetch the session via
            pair_client.pair(...) and extract resp.question, same as the
            gap-reset path.
        """
        question_payload = payload.get("question") if isinstance(payload, dict) else None
        if question_payload:
            try:
                question = QuestionInfo.model_validate(question_payload)
            except Exception as exc:
                log.debug("[question_advanced.parse]", exc_info=exc)
                question = None
            if question is not None:
                self.run_worker(
                    self._apply_question_advanced(question),
                    group="question-advance",
                    exclusive=True,
                    exit_on_error=False,
                )
                return
        # Fallback: re-fetch via pair_client (old broadcast shape).
        self.run_worker(
            self._refetch_question_after_advance(),
            group="question-advance",
            exclusive=True,
            exit_on_error=False,
        )

    async def _refetch_question_after_advance(self) -> None:
        """Fallback refetch when the cable broadcast didn't carry the new
        question payload. Three failure modes, three copies:

          - httpx.HTTPError       → "Couldn't reach the server. Try again
                                    in a moment."
          - pydantic.ValidationError → "Got an unexpected response from the
                                         server. Please contact support."
          - anything else         → bubble (worker logs it; we don't want
                                    to mask real bugs).
        """
        async with httpx.AsyncClient(base_url=SERVER_URL) as http:
            try:
                resp = await pair_client.pair(http, self.cfg.code)
            except httpx.HTTPError:
                log.warning("refetch network error", exc_info=True)
                self._post_refetch_failure_notice(
                    "Couldn't reach the server to load the next question. "
                    "Check your connection and try again.",
                )
                return
            except ValidationError:
                log.error("refetch validation error", exc_info=True)
                self._post_refetch_failure_notice(
                    "Got unexpected data from the server. Please contact "
                    "support — the next question can't be loaded.",
                )
                return
        if resp.question is not None:
            # Also refresh the cached pair_response so downstream reads
            # (e.g. QuestionPanel remount on CTRL-B toggles) stay consistent.
            self.pair_response = resp
            await self._apply_question_advanced(resp.question)

    def _post_refetch_failure_notice(self, text: str) -> None:
        """Mount a SystemNoticeWidget into the chat log. Extracted so tests
        can swap a capture stub in without driving a Textual pilot."""
        try:
            log_chat = self.query_one("#chat-log", VerticalScroll)
            log_chat.mount(SystemNoticeWidget(text))
        except Exception as exc:
            log.debug("could not post refetch notice (chat log not mounted)", exc_info=exc)

    async def _apply_question_advanced(self, question: QuestionInfo) -> None:
        """Asynchronous question-advance: locks the in-memory critical
        section (history reset + pair_response swap) so a concurrent
        chat-worker append cannot interleave with the clear. UI mutations
        run on the message-pump thread (we are already on the loop)."""
        # 1. Remove the existing QuestionPanel(s).
        for panel in list(self.query(QuestionPanel).results()):
            panel.remove()
        # 2. Clear all chat-log children (messages, activities, plan reviews, notices).
        try:
            log_chat = self.query_one("#chat-log", VerticalScroll)
        except Exception as exc:
            log.debug("[question_advanced.find_log]", exc_info=exc)
            return
        for child in list(log_chat.children):
            child.remove()
        # 3. Reset client conversation + streaming bookkeeping under the lock.
        async with self._chat_history_lock:
            self._chat_history = []
            if self.pair_response is not None:
                self.pair_response = self.pair_response.model_copy(update={"question": question})
        self._current_assistant = None
        self._assistant_buffer = ""
        self.streaming = False
        self._stop_status_spinner()
        self._pending_plan_review = False
        # 4. Mount a fresh QuestionPanel above #chat-log.
        header = question.title or f"Question #{question.id}"
        new_panel = QuestionPanel(
            header,
            question.language or "",
            _question_body_or_placeholder(question.body),
        )
        try:
            self.screen.mount(new_panel, before=log_chat)
        except Exception as exc:
            log.debug("[question_advanced.mount_panel]", exc_info=exc)
        # 5. Mount a short moving-on notice in the cleared chat log.
        log_chat.mount(SystemNoticeWidget("Moved to next question."))
        self._maybe_scroll_end(log_chat)

    async def on_gap_detected(self, _: GapDetected) -> None:
        from .ui.widgets import SystemNoticeWidget
        # Q3b option A: hard reset — re-pair, reload history, banner.
        async with httpx.AsyncClient(base_url=SERVER_URL) as http:
            try:
                resp = await pair_client.pair(http, self.cfg.code)
            except Exception as exc:
                log.debug("[gap.repair]", exc_info=exc)
                # If re-pair fails, still show the banner so the user knows.
                self.query_one("#chat-log", VerticalScroll).mount(
                    SystemNoticeWidget("Reconnected — reloaded session from server.")
                )
                return
        async with self._chat_history_lock:
            self._chat_history = [
                ChatMessage(role=m.role, content=m.content) for m in resp.messages
            ]
        log_chat = self.query_one("#chat-log", VerticalScroll)
        # Clear and re-mount messages.
        for w in list(log_chat.children):
            w.remove()
        log_chat.mount(SystemNoticeWidget("Reconnected — reloaded session from server."))
        self._mount_history_messages()

    def _mount_history_messages(self) -> None:
        """Render messages from `_chat_history` into `#chat-log`. Reader
        runs on the message pump after a seed/repair worker has
        committed; no lock needed for a synchronous snapshot read."""
        log = self.query_one("#chat-log", VerticalScroll)
        for m in self._chat_history:
            content = m.content or ""
            # Defensive: never render the literal "[tool call]" placeholder
            # to the candidate, even if the server slips up.
            if content == "[tool call]":
                continue
            if not content.strip() and m.role == "assistant":
                continue  # tool-only assistant turn — no narration to show
            log.mount(MessageWidget(role=m.role, content=content))
        self._maybe_scroll_end(log)

    def on_stream_started(self, _: StreamStarted) -> None:
        self.streaming = True
        self._assistant_buffer = ""
        self._current_assistant = MessageWidget(role="assistant", content="")
        log_chat = self.query_one("#chat-log", VerticalScroll)
        log_chat.mount(self._current_assistant)
        self._start_status_spinner()
        self._update_status_bar()
        self.call_after_refresh(self._maybe_scroll_end, log_chat)

    def on_stream_chunk_received(self, message: StreamChunkReceived) -> None:
        if self._current_assistant is None:
            return
        self._assistant_buffer += message.content
        self._current_assistant.set_assistant_text(self._assistant_buffer)
        # Auto-scroll to follow the streaming reply.
        self._maybe_scroll_end(self.query_one("#chat-log", VerticalScroll))

    def on_system_notice_posted(self, message: SystemNoticePosted) -> None:
        """Mount a SystemNoticeWidget for a server-sent `system_notice`
        SSE event. `level == "error"` maps to the red error banner;
        anything else (including the drift-failure "warning" copy) is a
        neutral inline notice."""
        log_chat = self.query_one("#chat-log", VerticalScroll)
        log_chat.mount(SystemNoticeWidget(
            message.text,
            error=(message.level == "error"),
        ))
        self._maybe_scroll_end(log_chat)

    def on_stream_finished(self, message: StreamFinished) -> None:
        log.info("stream finished reason=%s", message.reason)
        # drift_failed is NOT an error path — the paired system_notice
        # carries the user-facing copy; just reset the spinner and hand
        # the turn back to the candidate. Any other finish reason follows
        # the same reset flow.
        self.streaming = False
        # If the stream ended while the assistant widget is still pending
        # (tool-only turn, or empty-prose stop), remove it so the spinner
        # doesn't stall forever in the chat log. Stop-then-remove avoids a
        # last-tick race where the 80ms interval would call _inner.update
        # on a detached widget.
        if (
            self._current_assistant is not None
            and not self._pending_plan_review
            and getattr(self._current_assistant, "_pending", False)
        ):
            self._current_assistant._stop_spinner()
            self._current_assistant.remove()
            self._current_assistant = None

        # If this stream was the plan review message, replace the plain
        # MessageWidget with a PlanReviewWidget so the candidate sees the
        # bordered card with the approval CTA.
        if self._pending_plan_review and self._current_assistant is not None:
            self._pending_plan_review = False
            content = self._assistant_buffer or ""
            chat_log = self.query_one("#chat-log", VerticalScroll)
            self._current_assistant.remove()
            chat_log.mount(PlanReviewWidget(content=content))
            self._maybe_scroll_end(chat_log)
        self._current_assistant = None
        self._assistant_buffer = ""
        self._stop_status_spinner()
        self._update_status_bar()
        self._maybe_scroll_end(self.query_one("#chat-log", VerticalScroll))

    def on_stream_errored(self, message: StreamErrored) -> None:
        from .ui.widgets import SystemNoticeWidget
        self.query_one("#chat-log", VerticalScroll).mount(
            SystemNoticeWidget(_friendly_error(message.code), error=True)
        )
        self.streaming = False
        self._current_assistant = None
        self._assistant_buffer = ""
        self._stop_status_spinner()
        self._update_status_bar()

    @on(PromptTextArea.Submitted)
    def _on_prompt_submitted(self, event: PromptTextArea.Submitted) -> None:
        if self.streaming:
            event.stop()  # gate submit; do NOT clear the input
            return
        text = event.value.strip()
        if not text:
            return
        # Clear the prompt buffer.
        self.query_one("#prompt", PromptTextArea).clear()

        self._send_user_turn(text)

    def _send_user_turn(self, text: str) -> None:
        log = self.query_one("#chat-log", VerticalScroll)
        log.mount(MessageWidget(role="user", content=text))
        self._maybe_scroll_end(log)
        # History append happens inside `_chat_worker` so the worker owns
        # the full request/response sequence (avoids double-append).
        self.run_worker(self._chat_worker(text), group="chat", exclusive=True, exit_on_error=False)

    async def _ensure_http(self) -> httpx.AsyncClient:
        """Return the long-lived chat HTTP client, creating it on first use.

        Lifetime contract:
          - One `httpx.AsyncClient` per `HyrinApp`. Retries (Chat-side or
            cable-driven) MUST NOT recreate the client per attempt — that
            churns the connection pool and triggers per-request DNS.
          - `_close_http_chat` is the only authorised tear-down path; after
            it runs, the next `_ensure_http` allocates a fresh client.

        Token-refresh policy (CLI-6, deliberately deferred):
          The session token is captured at pair time and embedded in every
          request's Authorization header by `chat_client.stream_chat`. We
          do NOT refresh tokens client-side; the server reissues a token
          via the pair endpoint, and an in-flight expiry surfaces as a
          ChatUnauthorizedError that the chat worker translates into a
          `session_gone` notice. If product later requires silent refresh,
          add it here behind a small async lock so we never have two
          refreshes in flight at once. Tracked as a follow-up note.
        """
        if self._http_chat is None:
            self._http_chat = httpx.AsyncClient(base_url=SERVER_URL)
        return self._http_chat

    async def _close_http_chat(self) -> None:
        """Close the chat HTTP client and clear the slot so a subsequent
        `_ensure_http` allocates a fresh one. Idempotent."""
        client, self._http_chat = self._http_chat, None
        if client is not None:
            await client.aclose()

    async def _chat_worker(self, user_text: str) -> None:
        try:
            pair = self._require_pair()
        except _NoPair:
            log.debug("[chat_worker.no_pair] aborted: pair_response is None")
            self.post_message(SystemNoticePosted(
                level="error",
                text="Connection lost. Please refresh to re-pair.",
            ))
            self.post_message(StreamErrored(code="session_gone", message=""))
            return
        token = pair.session_token

        if user_text:
            async with self._chat_history_lock:
                self._chat_history.append(ChatMessage(role="user", content=user_text))

        http = await self._ensure_http()

        async with self._chat_history_lock:
            history_len = len(self._chat_history)
        log.info("chat_worker start cwd=%s history_len=%d user_text=%r",
                 self.cfg.cwd, history_len, user_text[:80])
        # Full prompt at DEBUG so a developer can reproduce long inputs
        # locally (debug-gated; default INFO logs are unaffected).
        log.debug("chat_worker start full user_text=%r", user_text)
        _clean_exit = False
        try:
            while True:  # loop runs once per assistant turn (incl. tool turns)
                self.post_message(StreamStarted())
                assistant_buf: list[str] = []
                tool_calls = []
                finish_reason = "stop"
                # Snapshot the history under the lock; the SSE stream call
                # below must NOT hold the lock (lock never spans I/O).
                async with self._chat_history_lock:
                    history_snapshot = list(self._chat_history)
                try:
                    async for ev in chat_client.stream_chat_with_retry(
                        http, token, history_snapshot,
                    ):
                        if ev.type is ChatEventType.TEXT:
                            assistant_buf.append(ev.content)
                            self.post_message(StreamChunkReceived(ev.content))
                        elif ev.type is ChatEventType.REASONING:
                            # Render reasoning as dim prefix; no separate widget.
                            self.post_message(StreamChunkReceived(""))
                        elif ev.type is ChatEventType.TOOL_CALL:
                            tool_calls.append(ev.tool_call)
                        elif ev.type is ChatEventType.FINISH:
                            finish_reason = ev.content
                        elif ev.type is ChatEventType.SYSTEM_NOTICE:
                            # Out-of-band banner from the server — e.g. the
                            # tool-drift hard-fail copy. Doesn't count as an
                            # error; the stream will follow up with its own
                            # FINISH event (reason="drift_failed").
                            self.post_message(SystemNoticePosted(
                                level=ev.code or "info",
                                text=ev.content,
                            ))
                        elif ev.type is ChatEventType.ERROR:
                            self.post_message(StreamErrored(code=ev.code, message=ev.content))
                            _clean_exit = True
                            return
                except ChatInterrupted as e:
                    log.warning("ChatInterrupted partial_len=%d", len(e.partial_text or ""))
                    self.post_message(ChatInterruptedNotice(partial=e.partial_text))
                    _clean_exit = True
                    return
                except ChatUnauthorizedError:
                    self.post_message(StreamErrored(code="session_gone", message=""))
                    _clean_exit = True
                    return
                except ChatSessionGoneError:
                    self.post_message(StreamErrored(code="session_gone", message=""))
                    self.state = AppState.ENDED
                    _clean_exit = True
                    return
                except ChatServerError:
                    self.post_message(StreamErrored(code="chat_failed", message=""))
                    _clean_exit = True
                    return

                assistant_text = "".join(assistant_buf)
                if assistant_text or tool_calls:
                    async with self._chat_history_lock:
                        self._chat_history.append(ChatMessage(
                            role="assistant",
                            content=assistant_text,
                            tool_calls=list(tool_calls) if tool_calls else None,
                        ))
                self.post_message(StreamFinished(reason=finish_reason))

                log.info("turn done assistant_len=%d tool_calls=%d finish=%s",
                         len(assistant_text), len(tool_calls), finish_reason)
                if not tool_calls:
                    _clean_exit = True
                    return

                # Dispatch each tool call; append the role:"tool" reply
                # under the lock so a concurrent question_advanced sees a
                # consistent view.
                for tc in tool_calls:
                    tool_msg = await self._dispatch_tool(tc)
                    async with self._chat_history_lock:
                        self._chat_history.append(tool_msg)
        finally:
            # Safety net: an unhandled exception (e.g. Pydantic validation error
            # on a malformed tool_call, a bug escaping _dispatch_tool) would
            # silently kill the worker while `streaming` stays True, permanently
            # gating the input. If we didn't exit cleanly, post StreamFinished
            # so the UI resets.
            if not _clean_exit:
                self._current_assistant = None
                self._assistant_buffer = ""
                self.post_message(StreamFinished(reason="error"))

    async def _dispatch_tool(self, tc) -> ChatMessage:
        log.info("dispatch tool=%s args_len=%d cwd=%s",
                 tc.function.name, len(tc.function.arguments or ""), self.cfg.cwd)
        log.debug("dispatch full tool=%s args=%s",
                  tc.function.name, tc.function.arguments or "")
        # Parse arguments exactly once. If the LLM emitted malformed JSON
        # we still need a dict-shaped payload for ActivityWidget; preserve
        # the raw string under `_raw` so the activity log keeps the
        # offending payload visible.
        import json as _json
        raw_args = tc.function.arguments or "{}"
        try:
            args_dict = _json.loads(raw_args)
            if not isinstance(args_dict, dict):
                args_dict = {"_value": args_dict}
        except Exception as exc:
            log.debug("[dispatch.args_parse] tool=%s raw=%r",
                      tc.function.name, raw_args, exc_info=exc)
            args_dict = {"_raw": raw_args}

        try:
            self._activity_seq += 1
            result = await tool_registry.dispatch(
                self.cfg.cwd, tc.function.name, tc.function.arguments,
                seq=self._activity_seq,
            )
            if result.activity is not None and self._activity is not None:
                await self._activity.enqueue(result.activity)
            try:
                result_dict = _json.loads(result.tool_message or "{}")
                if not isinstance(result_dict, dict):
                    result_dict = {"content": result.tool_message}
            except Exception as exc:
                log.debug("[dispatch.result_parse] tool=%s",
                          tc.function.name, exc_info=exc)
                result_dict = {"content": result.tool_message}
            widget = ActivityWidget(
                tool=tc.function.name,
                args=args_dict,
                result=result_dict,
            )
            log_chat = self.query_one("#chat-log", VerticalScroll)
            log_chat.mount(widget)
            self.call_after_refresh(self._maybe_scroll_end, log_chat)
            log.info("dispatch ok tool=%s is_error=%s reply_len=%d",
                     tc.function.name, result.is_error, len(result.tool_message))
            log.debug("dispatch ok full tool=%s reply=%s",
                      tc.function.name, result.tool_message)
            return ChatMessage(
                role="tool", tool_call_id=tc.id, content=result.tool_message,
            )
        except Exception as exc:
            log.exception("dispatch raised tool=%s", tc.function.name)
            widget = ActivityWidget(
                tool=tc.function.name,
                args=args_dict,
                result={},
            )
            log_chat = self.query_one("#chat-log", VerticalScroll)
            log_chat.mount(widget)
            self.call_after_refresh(self._maybe_scroll_end, log_chat)
            return ChatMessage(
                role="tool", tool_call_id=tc.id,
                content=f"error: {exc}",
            )

    def on_chat_interrupted_notice(self, message: ChatInterruptedNotice) -> None:
        from .ui.widgets import SystemNoticeWidget
        log = self.query_one("#chat-log", VerticalScroll)
        if self._current_assistant is not None:
            self._current_assistant.set_assistant_text(message.partial)
            self._current_assistant.mark_interrupted()
        log.mount(SystemNoticeWidget(
            "[connection interrupted — press Enter to retry]",
            error=False,
        ))
        self.streaming = False
        self._current_assistant = None
        self._assistant_buffer = ""

    def action_cancel_stream(self) -> None:
        if not self.streaming:
            return
        for w in self.workers:
            if w.group == "chat":
                w.cancel()
        self.streaming = False
        from .ui.widgets import SystemNoticeWidget
        self.query_one("#chat-log", VerticalScroll).mount(
            SystemNoticeWidget("[cancelled]")
        )

    def watch_streaming(self, streaming: bool) -> None:
        try:
            prompt = self.query_one("#prompt", PromptTextArea)
        except Exception as exc:
            log.debug("[watch_streaming.prompt_query]", exc_info=exc)
            return
        prompt.disabled = streaming
        if streaming:
            self._start_status_spinner()
        else:
            self._stop_status_spinner()
            # Re-enabling a disabled widget does not restore focus. Without
            # this, the candidate can't type after the first turn — their
            # keystrokes land on whatever widget the focus drifted to during
            # streaming.
            try:
                prompt.focus()
            except Exception as exc:
                log.debug("[watch_streaming.prompt_focus]", exc_info=exc)
        self._update_status_bar()

    def action_request_quit(self) -> None:
        if self.state is AppState.ACTIVE:
            def _decide(confirmed: bool) -> None:
                if confirmed:
                    self.exit(0)
            self.push_screen(_QuitConfirm(), _decide)
        else:
            self.exit(0)

    def action_toggle_question(self) -> None:
        from .ui.widgets import QuestionPanel
        for w in self.query(QuestionPanel).results():
            w.collapsed = not w.collapsed

    async def on_unmount(self) -> None:
        # Resource teardown must be exhaustive. Wrap each step in its
        # own try/finally so a failure in one (e.g. a buggy
        # _activity.stop() that raises) doesn't leak the others. Order
        # is best-effort: cable first (signal-only, can't raise),
        # then long-running workers, then HTTP clients.
        # Exceptions are logged at debug and swallowed so a single
        # buggy teardown step never leaks the rest of the resources.
        try:
            if self._cable_stop is not None:
                self._cable_stop.set()
        except Exception as exc:
            log.debug("[on_unmount.cable_stop]", exc_info=exc)
        try:
            if self._activity is not None:
                await self._activity.stop()
        except Exception as exc:
            log.debug("[on_unmount.activity_stop]", exc_info=exc)
        try:
            if self._activity_http is not None:
                await self._activity_http.aclose()
        except Exception as exc:
            log.debug("[on_unmount.activity_http_aclose]", exc_info=exc)
        try:
            if self._http_chat is not None:
                await self._http_chat.aclose()
        except Exception as exc:
            log.debug("[on_unmount.http_chat_aclose]", exc_info=exc)

    def watch_state(self, _old: AppState, new: AppState) -> None:
        for s in AppState:
            self.remove_class(s.value)
        self.add_class(new.value)
        if new is AppState.ACTIVE:
            self.query_one("#prompt", PromptTextArea).focus()
