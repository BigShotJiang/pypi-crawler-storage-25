"""Path-safety gate and command-consent classifier for tool execution.

Two checks for filesystem ops:
  1. Resolved path must be inside cwd (no escape, no absolute outside cwd).
  2. Basename must not match a sensitive-file pattern.

`requires_consent` mirrors the VS Code extension's classifier (extension/src/tools/safety.ts):
returns "safe" | "confirm" | "block". The CLI currently only acts on "block"
(deny destructive commands outright); the "confirm" path runs silently pending a
candidate-side consent UI. See: extension's commandConsent.mode for the
target design.

`.env.example` is intentionally allowed (matches `^\\.env\\.example$`, not the
generic `.env.*` pattern).
"""
from __future__ import annotations

import os
import re


SENSITIVE_PATTERNS = [
    # .env, .env.local, .env.test, .env.ci, etc. — any .env.<suffix> variant.
    # .env.example is the documented exception and matches its own pattern below first.
    re.compile(r"^\.env\.example$"),  # allow-marker — matched first by allow check
    re.compile(r"^\.env(\.[a-zA-Z0-9_-]+)*$"),
    # Cert / key material
    re.compile(r"\.(pem|key|crt|cer|p12|pfx|jks)$"),
    # SSH private keys — id_rsa, id_ed25519, id_ecdsa, id_dsa
    re.compile(r"^id_(rsa|ed25519|ecdsa|dsa)"),
    # Credential stores
    re.compile(r"^\.pgpass$"),
    re.compile(r"^\.netrc$"),
]

# .env.example is the only allow-listed name in the .env.* family.
_ENV_EXAMPLE = re.compile(r"^\.env\.example$")


class PathEscapeError(Exception):
    pass


class SensitiveFileError(Exception):
    pass


def check_path(cwd: str, target: str) -> str:
    """Return the absolute resolved path if safe; raise otherwise."""
    cwd_abs = os.path.realpath(cwd)
    candidate = target if os.path.isabs(target) else os.path.join(cwd_abs, target)
    resolved = os.path.realpath(candidate)
    if resolved != cwd_abs and not resolved.startswith(cwd_abs + os.sep):
        raise PathEscapeError(f"path escapes cwd: {target!r}")
    base = os.path.basename(resolved)
    if _ENV_EXAMPLE.match(base):
        return resolved
    for pat in SENSITIVE_PATTERNS:
        if pat is _ENV_EXAMPLE:
            continue
        if pat.search(base):
            raise SensitiveFileError(f"refusing to access sensitive file: {base}")
    return resolved


# ── run_command consent classifier ────────────────────────────────────────────
# Mirrors extension/src/tools/safety.ts `requiresConsent`. Returns:
#   "safe"    — auto-approved, no prompt
#   "confirm" — should prompt the candidate (CLI consent UI is a TODO; for now
#               this path silently executes — beta-acceptable since the server
#               is in our control)
#   "block"   — never executes, regardless of consent setting
#
# "block" wins over everything else. Otherwise every segment (split on
# &&/||/|/;) must match the allowlist for the line to be "safe"; any
# unrecognised segment falls back to "confirm".

DENY_PATTERNS = [
    re.compile(r"\brm\s+-rf?\s+/(?!\w)"),                       # rm -rf / (root)
    re.compile(r"\brm\s+-rf?\s+/\*"),                           # rm -rf /*
    re.compile(r"\brm\s+--no-preserve-root\b"),                 # rm --no-preserve-root
    re.compile(r"\bsudo\s+rm\b"),
    re.compile(r"\bdd\s+if="),
    re.compile(r"\bmkfs(\.|\b)"),
    re.compile(r":\(\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:"),    # bash fork bomb
    re.compile(r"\bgit\s+push\s+(--force|-f)\b"),
    re.compile(r"\bgit\s+push\s+--force-with-lease\b"),
]

# Each entry matches the FIRST executable token (after any KEY=VALUE env-var
# prefix). Subcommands listed for git/npm/uv/cargo; anything else under those
# tools falls to "confirm".
_ALLOW_PREFIXES: list[tuple[str, tuple[str, ...] | None]] = [
    ("ls", None), ("cat", None), ("head", None), ("tail", None), ("wc", None),
    ("grep", None), ("rg", None), ("find", None),
    ("git", ("status", "diff", "log", "show")),
    ("npm", ("test", "run")),
    ("pytest", None),
    ("uv", ("run",)),
    ("cargo", ("test",)),
    ("python", ("-V", "--version")),
    ("python3", ("-V", "--version")),
    ("node", ("-V", "--version")),
]

_ENV_PREFIX_RE = re.compile(r"^(?:[A-Z_][A-Z0-9_]*=\S*\s+)+")


def _strip_env_prefix(seg: str) -> str:
    return _ENV_PREFIX_RE.sub("", seg)


def _is_allowed(segment: str) -> bool:
    s = _strip_env_prefix(segment.strip())
    if not s:
        return False
    tokens = s.split()
    head = tokens[0]
    for cmd, sub in _ALLOW_PREFIXES:
        if cmd != head:
            continue
        if sub is None:
            return True
        return (tokens[1] if len(tokens) > 1 else "") in sub
    return False


_SEGMENT_SPLIT_RE = re.compile(r"&&|\|\||\||;")


def requires_consent(command_line: str) -> str:
    """Classify a shell command line: 'safe' | 'confirm' | 'block'."""
    line = command_line or ""
    for pat in DENY_PATTERNS:
        if pat.search(line):
            return "block"
    segments = [s.strip() for s in _SEGMENT_SPLIT_RE.split(line) if s.strip()]
    if not segments:
        return "confirm"
    return "safe" if all(_is_allowed(s) for s in segments) else "confirm"
