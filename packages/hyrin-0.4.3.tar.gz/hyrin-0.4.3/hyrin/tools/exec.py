"""run_command tool — sh -c with combined stdout/stderr and a 100 KB cap."""
from __future__ import annotations

import asyncio


MAX_OUTPUT_BYTES = 100 * 1024
DEFAULT_TIMEOUT_SECONDS = 30.0


class CommandTimeoutError(Exception):
    pass


async def run_command(
    cwd: str, command: str, timeout: float | None = None,
) -> tuple[str, int]:
    """Run `sh -c command` in cwd, return (formatted_output, exit_code).

    formatted_output: 'exit_code=<N>\\n<combined stdout/stderr>' (truncated at 100 KB).
    Timeout raises CommandTimeoutError; the partial output is discarded.
    """
    timeout_s = timeout if (timeout and timeout > 0) else DEFAULT_TIMEOUT_SECONDS
    proc = await asyncio.create_subprocess_shell(
        command,
        cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    try:
        stdout_bytes, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout_s)
    except asyncio.TimeoutError:
        proc.kill()
        try:
            await proc.wait()
        except Exception:
            pass
        raise CommandTimeoutError(f"command timed out after {timeout_s}s")
    body = (stdout_bytes or b"").decode("utf-8", errors="replace")
    if len(body) > MAX_OUTPUT_BYTES:
        body = body[:MAX_OUTPUT_BYTES] + "\n[output truncated]"
    exit_code = proc.returncode if proc.returncode is not None else -1
    return f"exit_code={exit_code}\n{body}", exit_code
