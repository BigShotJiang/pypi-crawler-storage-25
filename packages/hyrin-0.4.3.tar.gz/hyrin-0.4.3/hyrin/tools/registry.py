"""Single dispatch entry point for all model-callable tools.

Returns a ToolResult holding both the model-facing string (sent back as
the next chat message's `content`) and an optional ActivityEvent (sent
to mission control via the activity worker). The caller (`app.py`) is
responsible for queueing the activity event and forwarding the tool
message.

`present_decision` is intentionally absent here — that flow is handled
inline in `app.py` because it requires UI input.
"""
from __future__ import annotations

import datetime
import difflib
import hashlib
import json
import time
from dataclasses import dataclass
from typing import Optional

from ..client.types import ActivityEvent, ActivityType
from . import fs as fs_tools
from . import exec as exec_tool
from .safety import requires_consent


ACTIVITY_RUN_OUTPUT_CAP = 64 * 1024
# Hard ceiling on server-supplied run_command timeouts. Stops a malicious or
# buggy server from pinning the candidate's machine for hours.
MAX_ALLOWED_TIMEOUT_SECONDS = 120.0


class UnknownToolError(Exception):
    pass


class BadArgsError(Exception):
    pass


@dataclass
class ToolResult:
    tool_message: str
    activity: Optional[ActivityEvent]
    is_error: bool = False


def _now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _truncate(text: str, cap: int) -> str:
    if len(text) <= cap:
        return text
    return text[:cap] + "\n[output truncated]"


_MISSING_PATH_ACTIVITY = {
    "read_file": ActivityType.FILE_READ,
    "write_file": ActivityType.FILE_WRITE,
    "edit_file": ActivityType.FILE_EDIT,
}


def _missing_path_result(tool: str, seq: int) -> "ToolResult":
    msg = f"error: {tool} requires a non-empty 'path' argument"
    ev = ActivityEvent(
        seq=seq, timestamp=_now_iso(), type=_MISSING_PATH_ACTIVITY[tool],
        payload={"error": "missing_path"},
    )
    return ToolResult(tool_message=msg, activity=ev, is_error=True)


async def dispatch(cwd: str, name: str, raw_args: str, *, seq: int = 0) -> ToolResult:
    try:
        args = json.loads(raw_args) if raw_args else {}
    except json.JSONDecodeError as e:
        raise BadArgsError(f"invalid json args for {name}: {e}")

    if name == "read_file":
        path = args.get("path") or ""
        if not path.strip():
            return _missing_path_result(name, seq)
        text = fs_tools.read_file(cwd, path)
        ev = ActivityEvent(
            seq=seq, timestamp=_now_iso(), type=ActivityType.FILE_READ,
            payload={"path": path, "line_count": len(text.split("\n")),
                     "size_bytes": len(text.encode("utf-8"))},
        )
        return ToolResult(tool_message=text, activity=ev)

    if name == "write_file":
        path = args.get("path") or ""
        content = args.get("content", "")
        if not path.strip():
            return _missing_path_result(name, seq)
        summary = fs_tools.write_file(cwd, path, content)
        ev = ActivityEvent(
            seq=seq, timestamp=_now_iso(), type=ActivityType.FILE_WRITE,
            payload={"path": path, "content_hash": _sha256(content),
                     "content": content, "size_bytes": len(content.encode("utf-8"))},
        )
        return ToolResult(tool_message=summary, activity=ev)

    if name == "edit_file":
        path = args.get("path") or ""
        old_str = args.get("old_str", "")
        new_str = args.get("new_str", "")
        if not path.strip():
            return _missing_path_result(name, seq)
        before = fs_tools.read_file(cwd, path)
        summary = fs_tools.edit_file(cwd, path, old_str, new_str)
        after = fs_tools.read_file(cwd, path)
        diff = "".join(difflib.unified_diff(
            before.splitlines(keepends=True),
            after.splitlines(keepends=True),
            fromfile=f"a/{path}", tofile=f"b/{path}",
        ))
        ev = ActivityEvent(
            seq=seq, timestamp=_now_iso(), type=ActivityType.FILE_EDIT,
            payload={"path": path, "content_hash": _sha256(after),
                     "diff": diff, "size_bytes": len(after.encode("utf-8"))},
        )
        return ToolResult(tool_message=summary, activity=ev)

    if name == "list_directory":
        path = args.get("path", ".")
        out = fs_tools.list_directory(cwd, path)
        entries = [line for line in out.split("\n") if line]
        ev = ActivityEvent(
            seq=seq, timestamp=_now_iso(), type=ActivityType.LIST_DIRECTORY,
            payload={"path": path, "entries": entries},
        )
        return ToolResult(tool_message=out, activity=ev)

    if name == "run_command":
        command = args.get("command", "")
        consent_class = requires_consent(command)
        if consent_class == "block":
            msg = f"exit_code=-1\n[refused: command matches a destructive pattern]"
            ev = ActivityEvent(
                seq=seq, timestamp=_now_iso(), type=ActivityType.RUN_COMMAND,
                payload={"command": command, "exit_code": -1,
                         "duration_ms": 0,
                         "stdout": "", "stderr": "blocked: destructive pattern"},
            )
            return ToolResult(tool_message=msg, activity=ev, is_error=True)
        timeout_ms = args.get("timeout_ms")
        if isinstance(timeout_ms, (int, float)) and timeout_ms > 0:
            timeout = min(timeout_ms / 1000.0, MAX_ALLOWED_TIMEOUT_SECONDS)
        else:
            timeout = None
        started = time.monotonic()
        try:
            output, exit_code = await exec_tool.run_command(cwd, command, timeout=timeout)
            duration_ms = int((time.monotonic() - started) * 1000)
            ev = ActivityEvent(
                seq=seq, timestamp=_now_iso(), type=ActivityType.RUN_COMMAND,
                payload={
                    "command": command, "exit_code": exit_code,
                    "duration_ms": duration_ms,
                    "stdout": _truncate(output, ACTIVITY_RUN_OUTPUT_CAP),
                    "stderr": "",
                },
            )
            return ToolResult(tool_message=_truncate(output, ACTIVITY_RUN_OUTPUT_CAP),
                              activity=ev)
        except exec_tool.CommandTimeoutError as e:
            duration_ms = int((time.monotonic() - started) * 1000)
            msg = f"exit_code=-1\n[command timed out: {e}]"
            ev = ActivityEvent(
                seq=seq, timestamp=_now_iso(), type=ActivityType.RUN_COMMAND,
                payload={"command": command, "exit_code": -1,
                         "duration_ms": duration_ms,
                         "stdout": "", "stderr": str(e)},
            )
            return ToolResult(tool_message=msg, activity=ev, is_error=True)

    raise UnknownToolError(f"unknown tool: {name}")
