"""Filesystem tools: read/write/edit/list, all gated through safety.check_path."""
from __future__ import annotations

import os

from .safety import check_path, PathEscapeError, SensitiveFileError


# Hard cap on read_file output. Stops a malicious server from asking for
# /dev/zero or a 50 GB sparse file and OOM-ing the candidate's box.
MAX_READ_BYTES = 512 * 1024


class OldStrNotFoundError(Exception):
    pass


class OldStrAmbiguousError(Exception):
    pass


def read_file(cwd: str, path: str) -> str:
    abs_path = check_path(cwd, path)
    with open(abs_path, "r", encoding="utf-8") as fh:
        body = fh.read(MAX_READ_BYTES + 1)
    if len(body) > MAX_READ_BYTES:
        return body[:MAX_READ_BYTES] + (
            f"\n[file truncated — exceeded {MAX_READ_BYTES // 1024} KB read limit]"
        )
    return body


def write_file(cwd: str, path: str, content: str) -> str:
    abs_path = check_path(cwd, path)
    os.makedirs(os.path.dirname(abs_path) or ".", exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as fh:
        fh.write(content)
    line_count = len(content.split("\n"))  # mirrors Go's count
    return f"wrote {line_count} lines to {path}"


def edit_file(cwd: str, path: str, old_str: str, new_str: str) -> str:
    abs_path = check_path(cwd, path)
    with open(abs_path, "r", encoding="utf-8") as fh:
        contents = fh.read()
    count = contents.count(old_str)
    if count == 0:
        raise OldStrNotFoundError(f"old_str not found in {path}")
    if count > 1:
        raise OldStrAmbiguousError(
            f"old_str matches {count} occurrences in {path}; refusing to edit"
        )
    new_contents = contents.replace(old_str, new_str, 1)
    with open(abs_path, "w", encoding="utf-8") as fh:
        fh.write(new_contents)
    return f"edited {path}"


def list_directory(cwd: str, path: str) -> str:
    abs_path = check_path(cwd, path) if path != "." else os.path.realpath(cwd)
    cwd_real = os.path.realpath(cwd)
    entries = []
    for name in sorted(os.listdir(abs_path)):
        if name.startswith("."):
            continue
        full = os.path.join(abs_path, name)
        # Resolve any symlink and confirm the target is inside cwd. Skip entries
        # that escape (e.g. `link → /etc`) so listing can't be used as a probe.
        try:
            resolved = os.path.realpath(full)
        except OSError:
            continue
        if resolved != cwd_real and not resolved.startswith(cwd_real + os.sep):
            continue
        entries.append(name + ("/" if os.path.isdir(full) else ""))
    return "\n".join(entries) if entries else "(empty directory)"
