"""Argv parsing → HyrinApp(cfg).run()."""
from __future__ import annotations

import argparse
import os
import sys

from . import __version__
from .app import HyrinApp
from .config import Config


class ArgError(Exception):
    pass


_DESCRIPTION = (
    "Hyrin candidate CLI — connect to a live interview using the pairing "
    "code shown by your interviewer."
)

_EPILOG = "Example:\n  hyrin ABCD1234"


def parse_args(argv: list[str]) -> Config:
    parser = argparse.ArgumentParser(
        prog="hyrin",
        description=_DESCRIPTION,
        epilog=_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "code",
        help="8-character pairing code shown in the interviewer's dashboard.",
    )
    parser.add_argument(
        "--cwd",
        default=os.getcwd(),
        help=(
            "Working directory for tool calls (read_file, write_file, exec). "
            "Defaults to the current shell's working directory."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"hyrin/{__version__}",
    )
    ns = parser.parse_args(argv)
    return Config(
        code=ns.code.upper(),
        cwd=ns.cwd,
    )


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    try:
        cfg = parse_args(args)
    except ArgError as e:
        print(f"hyrin: {e}", file=sys.stderr)
        return 2
    app = HyrinApp(cfg)
    return app.run() or 0


if __name__ == "__main__":
    sys.exit(main())
