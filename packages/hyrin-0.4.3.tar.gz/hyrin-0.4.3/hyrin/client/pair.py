"""POST /api/v1/sessions/pair — synchronous request, async wrapper."""
from __future__ import annotations

import httpx

from .types import PairRequest, PairResponse


PAIR_TIMEOUT_SECONDS = 15.0


class PairError(Exception):
    """Base class for pairing failures."""


class InvalidCodeError(PairError):
    pass


class AlreadyClaimedError(PairError):
    pass


class SessionGoneError(PairError):
    pass


class ServerError(PairError):
    def __init__(self, status: int, body: str = ""):
        super().__init__(f"server error: status={status} body={body[:200]!r}")
        self.status = status


async def pair(http: httpx.AsyncClient, code: str) -> PairResponse:
    body = PairRequest(code=code.upper()).model_dump()
    resp = await http.post(
        "/api/v1/sessions/pair",
        json=body,
        timeout=PAIR_TIMEOUT_SECONDS,
    )
    if resp.status_code == 200:
        return PairResponse.model_validate(resp.json())
    if resp.status_code in (401, 404):
        raise InvalidCodeError(f"code invalid or expired (status={resp.status_code})")
    if resp.status_code == 409:
        raise AlreadyClaimedError("code already claimed by another session")
    if resp.status_code == 410:
        raise SessionGoneError("session no longer available")
    raise ServerError(resp.status_code, resp.text)
