"""Pydantic models for every wire payload exchanged with the server.

These shapes mirror the Go CLI byte-for-byte. The server treats fields
as additive — keep `model_config = ConfigDict(extra='ignore')` so a
forward-compatible server cannot break the client.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator


class _Base(BaseModel):
    model_config = ConfigDict(extra="ignore")

    @model_validator(mode="before")
    @classmethod
    def _coerce_null_strings(cls, data):
        """Replace null with the field's default for optional str fields.

        Rails happily serializes nil columns as JSON null. Without this
        hook, pydantic would raise ValidationError on `"language": null`
        when the model declares `language: str = ""`. Required fields
        (no default) are left alone so genuine schema mismatches still
        surface.
        """
        if not isinstance(data, dict):
            return data
        for name, field in cls.model_fields.items():
            if (
                data.get(name) is None
                and name in data
                and field.annotation is str
                and not field.is_required()
            ):
                data[name] = field.default
        return data


# ── Pairing ──────────────────────────────────────────────────────────────────

class PairRequest(_Base):
    code: str


class WorkspaceInfo(_Base):
    name: str


class SessionInfo(_Base):
    id: int
    state: str


class QuestionInfo(_Base):
    id: int
    title: str = ""
    body: str = ""
    language: str = ""
    starter_repo_url: str = ""


class MessageRecord(_Base):
    role: str
    content: str = ""


class PairResponse(_Base):
    cable_url: str
    session_token: str
    app_mode: str = ""
    workspace: WorkspaceInfo
    session: SessionInfo
    question: Optional[QuestionInfo] = None
    messages: list[MessageRecord] = Field(default_factory=list)


# ── Chat completions ─────────────────────────────────────────────────────────

class ToolFunction(_Base):
    name: str = ""
    arguments: str = ""


class ToolCall(_Base):
    id: str = ""
    type: str = "function"
    function: ToolFunction = Field(default_factory=ToolFunction)


class ChatMessage(_Base):
    role: str
    content: Optional[str] = None
    tool_call_id: Optional[str] = None
    tool_calls: Optional[list[ToolCall]] = None


class ChatRequest(_Base):
    messages: list[ChatMessage]
    stream: bool = True


class ChunkDelta(_Base):
    content: str = ""
    reasoning_content: str = ""
    tool_calls: list[ToolCall] = Field(default_factory=list)


class ChunkChoice(_Base):
    index: int = 0
    delta: ChunkDelta = Field(default_factory=ChunkDelta)
    finish_reason: Optional[str] = None


class ChatChunk(_Base):
    id: str = ""
    object: str = ""
    choices: list[ChunkChoice] = Field(default_factory=list)


class ErrorPayload(_Base):
    code: str = ""
    message: str = ""


# ── Activity capture ─────────────────────────────────────────────────────────

class ActivityType(str, Enum):
    FILE_WRITE = "file_write"
    FILE_EDIT = "file_edit"
    FILE_READ = "file_read"
    LIST_DIRECTORY = "list_directory"
    RUN_COMMAND = "run_command"


class ActivityEvent(_Base):
    seq: int
    timestamp: str
    type: ActivityType
    payload: dict


# ── Cable inner-message envelope ─────────────────────────────────────────────

class CableInnerMessage(_Base):
    type: str
    payload: dict = Field(default_factory=dict)
    seq: Optional[int] = None


# ── Cable typed events ────────────────────────────────────────────────────────

@dataclass(frozen=True)
class PhaseChangedEvent:
    to_phase: str
    from_phase: Optional[str] = None
    question_id: Optional[int] = None
    decisions_completed: Optional[int] = None
    decisions_total: Optional[int] = None
