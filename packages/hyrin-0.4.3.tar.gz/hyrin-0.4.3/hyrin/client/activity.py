"""Activity capture: fire-and-forget POST /api/v1/sessions/activity worker.

- Bounded queue (max 100). Overflow drops oldest event.
- Per-event exponential backoff up to 30s.
- Worker stops cleanly on stop().
- POST failures never surface to the candidate; mission-control visibility
  degrades silently while the server endpoint is unavailable (spec §11).
"""
from __future__ import annotations

import asyncio
import collections
import logging
from time import monotonic as _monotonic
from typing import Callable, Optional

import httpx

from .types import ActivityEvent


ACTIVITY_QUEUE_MAX = 100
RETRY_INITIAL_SECONDS = 1.0
RETRY_MAX_SECONDS = 30.0

# Rolling-window settings for overflow logging.
#
# - OVERFLOW_WINDOW_SECONDS: drops older than this age out before being
#   counted. Sized to "one minute" per the master plan.
# - OVERFLOW_NOTICE_THRESHOLD: when the rolling count crosses this value
#   we fire the one-time on_overflow_notice callback (the app surfaces a
#   SystemNotice so the candidate sees that mission-control telemetry
#   is degraded). Re-arms when the window empties.
OVERFLOW_WINDOW_SECONDS = 60.0
OVERFLOW_NOTICE_THRESHOLD = 10

log = logging.getLogger("hyrin.activity")


class ActivityClient:
    def __init__(
        self,
        http: httpx.AsyncClient,
        session_token: str,
        retry_initial: float = RETRY_INITIAL_SECONDS,
        retry_max: float = RETRY_MAX_SECONDS,
        on_overflow_notice: Optional[Callable[[int], None]] = None,
    ):
        self._http = http
        self._token = session_token
        self._queue: collections.deque[ActivityEvent] = collections.deque()
        self._cv = asyncio.Condition()
        self._stop = asyncio.Event()
        self._task: Optional[asyncio.Task] = None
        self._retry_initial = retry_initial
        self._retry_max = retry_max
        self._idle = asyncio.Event()
        self._idle.set()
        # Drop-timestamp ring (monotonic seconds). Cleaned on every drop.
        self._drop_times: collections.deque[float] = collections.deque()
        self._overflow_notice_fired: bool = False
        self._on_overflow_notice = on_overflow_notice

    async def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        self._stop.set()
        async with self._cv:
            self._cv.notify_all()
        if self._task is not None:
            await self._task
            self._task = None

    async def enqueue(self, event: ActivityEvent) -> None:
        async with self._cv:
            self._queue.append(event)
            while len(self._queue) > ACTIVITY_QUEUE_MAX:
                self._queue.popleft()
                self._record_drop()
            self._idle.clear()
            self._cv.notify()

    def _record_drop(self) -> None:
        """Record an overflow drop and emit a WARN with the rolling count.
        Fires `on_overflow_notice` exactly once per window when the
        rolling count first crosses OVERFLOW_NOTICE_THRESHOLD."""
        now = _monotonic()
        cutoff = now - OVERFLOW_WINDOW_SECONDS
        while self._drop_times and self._drop_times[0] < cutoff:
            self._drop_times.popleft()
        self._drop_times.append(now)
        rolling = len(self._drop_times)
        log.warning(
            "activity queue overflow dropped=%d window_seconds=%d cap=%d",
            rolling, int(OVERFLOW_WINDOW_SECONDS), ACTIVITY_QUEUE_MAX,
        )
        # Re-arm the notice if the window emptied since last fire (i.e.
        # below threshold means we can fire fresh on the next surge).
        if rolling < OVERFLOW_NOTICE_THRESHOLD:
            self._overflow_notice_fired = False
        if rolling >= OVERFLOW_NOTICE_THRESHOLD and not self._overflow_notice_fired:
            self._overflow_notice_fired = True
            cb = self._on_overflow_notice
            if cb is not None:
                try:
                    cb(rolling)
                except Exception as exc:  # pragma: no cover — callback bugs shouldn't kill enqueue
                    log.debug("on_overflow_notice callback raised", exc_info=exc)

    async def flush(self) -> None:
        """Block until the queue is empty (test/shutdown helper)."""
        await self._idle.wait()

    def snapshot_seqs(self) -> list[int]:
        return [e.seq for e in self._queue]

    async def _run(self) -> None:
        while not self._stop.is_set():
            async with self._cv:
                while not self._queue and not self._stop.is_set():
                    await self._cv.wait()
                if self._stop.is_set() and not self._queue:
                    self._idle.set()
                    return
                event = self._queue.popleft()
            await self._post_with_retry(event)
            async with self._cv:
                if not self._queue:
                    self._idle.set()

    async def _post_with_retry(self, event: ActivityEvent) -> None:
        backoff = self._retry_initial
        while not self._stop.is_set():
            try:
                resp = await self._http.post(
                    "/api/v1/sessions/activity",
                    json=event.model_dump(mode="json"),
                    headers={"Authorization": f"Bearer {self._token}"},
                    timeout=10.0,
                )
                if 200 <= resp.status_code < 300:
                    return
                if resp.status_code in (400, 401, 404, 410):
                    return  # permanent failure for this event; do not retry
            except httpx.HTTPError:
                pass
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=backoff)
                return
            except asyncio.TimeoutError:
                pass
            backoff = min(backoff * 2, self._retry_max)
