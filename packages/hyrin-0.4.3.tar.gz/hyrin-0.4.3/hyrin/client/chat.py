"""SSE chat-completions client.

Wire spec:
  POST /api/v1/chat/completions
  Authorization: Bearer <session_token>
  Accept: text/event-stream
  Body: {"messages":[...], "stream": true}

Stream lines:
  data: {<chat chunk JSON>}
  data: [DONE]
  event: error\ndata: {"code":..., "message":...}
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from enum import Enum
from typing import AsyncIterator, Iterable, Iterator, Optional

import httpx

from .types import ChatChunk, ChatMessage, ChatRequest, ErrorPayload, ToolCall


class ChatEventType(str, Enum):
    TEXT = "text"
    REASONING = "reasoning"
    TOOL_CALL = "tool_call"
    FINISH = "finish"
    ERROR = "error"
    SYSTEM_NOTICE = "system_notice"


@dataclass
class ChatEvent:
    type: ChatEventType
    content: str = ""
    code: str = ""
    tool_call: Optional[ToolCall] = None

    def __eq__(self, other):
        if not isinstance(other, ChatEvent):
            return NotImplemented
        return (self.type, self.content, self.code, self.tool_call) == (
            other.type, other.content, other.code, other.tool_call
        )


def parse_sse_lines(lines: Iterable[str]) -> Iterator[ChatEvent]:
    """Translate SSE lines to ChatEvent objects.

    The caller is responsible for line splitting; this function expects
    `lines` already split on '\\n' (no trailing newline).
    """
    pending_event: Optional[str] = None
    for raw in lines:
        line = raw.rstrip("\r")
        if not line:
            pending_event = None
            continue
        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            pending_event = line[len("event:"):].strip()
            continue
        if not line.startswith("data:"):
            continue
        data = line[len("data:"):].strip()
        if data == "[DONE]":
            return
        if pending_event == "error":
            try:
                err = ErrorPayload.model_validate_json(data)
            except Exception:
                err = ErrorPayload(code="sse_error", message=data)
            yield ChatEvent(
                type=ChatEventType.ERROR,
                code=err.code or "sse_error",
                content=err.message,
            )
            pending_event = None
            continue
        if pending_event == "system_notice":
            # Server wire: {"level": "warning"|"error"|"info", "text": "..."}
            # Level rides on ChatEvent.code so we don't widen the schema.
            try:
                obj = json.loads(data)
            except Exception:
                obj = {}
            if not isinstance(obj, dict):
                obj = {}
            yield ChatEvent(
                type=ChatEventType.SYSTEM_NOTICE,
                content=str(obj.get("text", "") or ""),
                code=str(obj.get("level", "info") or "info"),
            )
            pending_event = None
            continue
        try:
            chunk = ChatChunk.model_validate_json(data)
        except Exception:
            continue
        for choice in chunk.choices:
            d = choice.delta
            if d.content:
                yield ChatEvent(type=ChatEventType.TEXT, content=d.content)
            if d.reasoning_content:
                yield ChatEvent(type=ChatEventType.REASONING, content=d.reasoning_content)
            for tc in d.tool_calls:
                yield ChatEvent(type=ChatEventType.TOOL_CALL, tool_call=tc)
            if choice.finish_reason:
                yield ChatEvent(type=ChatEventType.FINISH, content=choice.finish_reason)


# ── HTTP layer ────────────────────────────────────────────────────────────────

CHAT_READ_TIMEOUT_SECONDS = 60.0  # per-read; agentic responses can stall briefly between tool_call deltas


class ChatError(Exception):
    pass


class ChatUnauthorizedError(ChatError):
    pass


class ChatSessionGoneError(ChatError):
    pass


class ChatServerError(ChatError):
    def __init__(self, status: int):
        super().__init__(f"chat server error: status={status}")
        self.status = status


async def stream_chat(
    http: httpx.AsyncClient,
    session_token: str,
    messages: list[ChatMessage],
) -> AsyncIterator[ChatEvent]:
    body = ChatRequest(messages=messages, stream=True).model_dump(exclude_none=True)
    headers = {
        "Authorization": f"Bearer {session_token}",
        "Accept": "text/event-stream",
    }
    timeout = httpx.Timeout(CHAT_READ_TIMEOUT_SECONDS, read=CHAT_READ_TIMEOUT_SECONDS)
    async with http.stream(
        "POST", "/api/v1/chat/completions",
        json=body, headers=headers, timeout=timeout,
    ) as resp:
        if resp.status_code == 401:
            raise ChatUnauthorizedError("session token rejected")
        if resp.status_code == 410:
            raise ChatSessionGoneError("session no longer in_progress")
        if resp.status_code == 422:
            raise ChatServerError(resp.status_code)
        if resp.status_code != 200:
            raise ChatServerError(resp.status_code)

        buffer = ""
        # pending_event_line holds an "event: ..." line waiting for its paired
        # "data: ..." line so we can pass both together to parse_sse_lines,
        # preserving the parser's pending_event state without modifying 5.1.
        pending_event_line: Optional[str] = None

        async for chunk in resp.aiter_text():
            buffer += chunk
            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                line = line.rstrip("\r")
                if line.startswith("event:"):
                    pending_event_line = line
                    continue
                if pending_event_line is not None:
                    feed = [pending_event_line, line]
                    pending_event_line = None
                else:
                    feed = [line]
                for ev in parse_sse_lines(feed):
                    yield ev
                    if ev.type == ChatEventType.ERROR:
                        return

        # Flush any remaining text in the buffer.
        if buffer or pending_event_line:
            feed = ([pending_event_line] if pending_event_line else []) + ([buffer] if buffer else [])
            for ev in parse_sse_lines(feed):
                yield ev


class ChatInterrupted(ChatError):
    """Stream ended without [DONE] twice in a row. Carries partial assistant text
    from the second attempt so the UI can render it dim/interrupted."""

    def __init__(self, partial_text: str):
        super().__init__("chat stream interrupted")
        self.partial_text = partial_text


async def _stream_once_collecting(
    http: httpx.AsyncClient,
    session_token: str,
    messages: list[ChatMessage],
) -> tuple[list[ChatEvent], bool, str]:
    """Drain one stream attempt. Returns (events, completed, partial_text).

    `completed=True` iff the stream produced a FINISH event before EOF.
    `partial_text` is the concatenation of TEXT-event content seen so far.
    """
    events: list[ChatEvent] = []
    partial = []
    completed = False
    async for ev in stream_chat(http, session_token, messages):
        events.append(ev)
        if ev.type == ChatEventType.TEXT:
            partial.append(ev.content)
        if ev.type == ChatEventType.FINISH:
            completed = True
    return events, completed, "".join(partial)


# Exception group used for "the connection-establishment phase failed";
# these are retryable and produce no partial output. Mid-stream cutoffs
# (ReadError / RemoteProtocolError / TimeoutException after stream start)
# are handled separately because they carry partial assistant text.
_TRANSIENT_REQUEST_ERRORS = (
    httpx.ConnectError,
    httpx.ConnectTimeout,
    httpx.WriteError,
    httpx.PoolTimeout,
)
_MID_STREAM_CUTOFF_ERRORS = (
    httpx.ReadError,
    httpx.RemoteProtocolError,
    httpx.ReadTimeout,
)


async def stream_chat_with_retry(
    http: httpx.AsyncClient,
    session_token: str,
    messages: list[ChatMessage],
) -> AsyncIterator[ChatEvent]:
    """Run a chat stream with one silent retry on mid-stream interruption.

    Spec §7.3 row 3 (Q3a option C): if the first attempt ends without a
    FINISH event and without an explicit ERROR event, retry once silently;
    if the retry also fails to complete, raise ChatInterrupted carrying
    the partial text so the UI can show '[connection interrupted — press
    Enter to retry]' over the dim partial reply.

    Failure-mode taxonomy:
      - Transient (`_TRANSIENT_REQUEST_ERRORS`): the request never started.
        First attempt: silently retry. Second attempt: re-raise the
        underlying httpx error. We do NOT raise ChatInterrupted with
        empty partial_text — that would mislead the UI into showing the
        "[interrupted]" pill over a never-started turn.
      - Mid-stream cutoff (`_MID_STREAM_CUTOFF_ERRORS`): the response
        opened, partial text may exist. First attempt: silently retry.
        Second attempt: raise ChatInterrupted with whichever partial is
        non-empty (prefers the second attempt's partial).

    On the success path, partial output from the failed first attempt is
    discarded — the caller sees only events from the successful stream.
    """
    try:
        events, completed, partial = await _stream_once_collecting(
            http, session_token, messages,
        )
    except _MID_STREAM_CUTOFF_ERRORS:
        events, completed, partial = [], False, ""
    except _TRANSIENT_REQUEST_ERRORS:
        # No partial text possible — the request never opened.
        events, completed, partial = [], False, ""

    if completed or any(e.type == ChatEventType.ERROR for e in events):
        for ev in events:
            yield ev
        return

    # Retry once.
    try:
        events2, completed2, partial2 = await _stream_once_collecting(
            http, session_token, messages,
        )
    except _MID_STREAM_CUTOFF_ERRORS:
        raise ChatInterrupted(partial_text=partial)
    except _TRANSIENT_REQUEST_ERRORS:
        # Both attempts failed before stream open — surface the underlying
        # transport error rather than fabricating a ChatInterrupted.
        raise

    if completed2 or any(e.type == ChatEventType.ERROR for e in events2):
        for ev in events2:
            yield ev
        return

    raise ChatInterrupted(partial_text=partial2 or partial)
