"""ActionCable WebSocket client for InterviewChannel.

Wire protocol:
  - Subscribe: {"command":"subscribe","identifier":"<json string>"}
  - Heartbeat: {"command":"message","identifier":"<id>","data":"{\"type\":\"ping\"}"}
  - Inner event envelope: {"identifier":..., "message":{"type":..., "payload":..., "seq":...}}

Filtered frames (server-side liveness, not events): welcome, ping, confirm_subscription.
A reject_subscription frame is fatal and surfaces as a ParsedFrame(kind='reject').
"""
from __future__ import annotations

import asyncio
import json
import random
from dataclasses import dataclass
from typing import AsyncIterator, Awaitable, Callable, Optional
from urllib.parse import urlparse

import websockets

from .types import PhaseChangedEvent

HEARTBEAT_INTERVAL_SECONDS = 3.0  # mirrors Interview::HeartbeatConfig::PING_EVERY_SECONDS


def build_subscribe_identifier(session_token: str, last_seq: int = 0) -> str:
    payload: dict = {"channel": "InterviewChannel", "session_token": session_token}
    if last_seq > 0:
        payload["last_seq"] = last_seq
    return json.dumps(payload, separators=(",", ":"))


def build_subscribe_frame(identifier: str) -> str:
    return json.dumps({"command": "subscribe", "identifier": identifier})


def build_heartbeat_frame(identifier: str) -> str:
    return json.dumps({
        "command": "message",
        "identifier": identifier,
        "data": json.dumps({"type": "ping"}),
    })


@dataclass(frozen=True)
class ParsedFrame:
    kind: str               # "event" | "reject"
    event_type: str = ""    # only set when kind == "event"
    payload: dict = None    # only set when kind == "event"
    seq: Optional[int] = None


def parse_frame(raw: str) -> Optional[ParsedFrame]:
    try:
        outer = json.loads(raw)
    except json.JSONDecodeError:
        return None

    if outer.get("type") in ("welcome", "ping", "confirm_subscription"):
        return None
    if outer.get("type") == "reject_subscription":
        return ParsedFrame(kind="reject")

    msg = outer.get("message")
    if not isinstance(msg, dict):
        return None
    return ParsedFrame(
        kind="event",
        event_type=msg.get("type", ""),
        payload=msg.get("payload") or {},
        seq=msg.get("seq"),
    )


@dataclass(frozen=True)
class CableEvent:
    event_type: str
    payload: dict
    seq: Optional[int]


READ_TIMEOUT_SECONDS = 15.0
SUBSCRIBE_TIMEOUT_SECONDS = 10.0


class CableRejected(Exception):
    """Server sent reject_subscription. Caller should not reconnect."""


def origin_from_ws_url(ws_url: str) -> str:
    # ActionCable's default forgery protection requires Origin to match the
    # request host (regex /https?:\/\/<host>/). Without Origin, the upgrade
    # is rejected with 404 "Page not found".
    parsed = urlparse(ws_url)
    scheme = "https" if parsed.scheme == "wss" else "http"
    return f"{scheme}://{parsed.netloc}"


async def connect_and_subscribe(
    url: str, session_token: str, last_seq: int,
    subscribe_timeout: float = SUBSCRIBE_TIMEOUT_SECONDS,
) -> AsyncIterator[CableEvent]:
    """Open a single cable connection, subscribe, yield events until close.

    Spawns an internal heartbeat task on the same socket so the server's
    ping_key TTL stays fresh — without this, mission control's interviewer
    view sees the candidate as disconnected within 35s of subscribe even
    though chat is still streaming.

    `subscribe_timeout` bounds the wait for the first inbound frame
    (welcome / confirm_subscription / data). If the server accepts the WS
    handshake but never confirms the subscription, the socket would hang
    forever — instead we raise asyncio.TimeoutError so run_supervisor can
    reconnect through its existing exception path.

    Caller (the supervisor) decides whether to reconnect on close.
    Filtered frames (welcome/ping/confirm_subscription) never appear in
    the iterator. A reject_subscription raises CableRejected.
    """
    identifier = build_subscribe_identifier(session_token, last_seq)
    heartbeat_stop = asyncio.Event()
    heartbeat_task: asyncio.Task | None = None
    async with websockets.connect(url, origin=origin_from_ws_url(url), ping_interval=None) as ws:
        await ws.send(build_subscribe_frame(identifier))
        heartbeat_task = asyncio.create_task(
            run_heartbeat(ws, identifier, heartbeat_stop)
        )
        try:
            # Bound the wait for the FIRST frame separately — once we've
            # seen any frame, we're confident the channel is alive and
            # fall back to the regular READ_TIMEOUT_SECONDS per-message.
            first_frame_seen = False
            while True:
                timeout = READ_TIMEOUT_SECONDS if first_frame_seen else subscribe_timeout
                raw = await asyncio.wait_for(ws.recv(), timeout=timeout)
                first_frame_seen = True
                pf = parse_frame(raw)
                if pf is None:
                    continue
                if pf.kind == "reject":
                    raise CableRejected("server rejected subscription")
                yield CableEvent(
                    event_type=pf.event_type,
                    payload=pf.payload,
                    seq=pf.seq,
                )
        finally:
            heartbeat_stop.set()
            if heartbeat_task is not None:
                try:
                    await asyncio.wait_for(heartbeat_task, timeout=1.0)
                except (asyncio.TimeoutError, asyncio.CancelledError, Exception):
                    heartbeat_task.cancel()


INITIAL_BACKOFF = 1.0
MAX_BACKOFF = 30.0


def compute_jittered_backoff(
    base: float, max_backoff: float,
    rng: Callable[[float, float], float] = random.uniform,
) -> float:
    """Clamp `base` to `max_backoff`, then multiply by a jitter factor in [0.5, 1.5]."""
    clamped = min(base, max_backoff)
    jitter = rng(0.5, 1.5)
    return clamped * jitter


async def run_supervisor(
    url: str,
    session_token: str,
    last_seq_ref: Callable[[], int],
    on_event: Callable[[CableEvent], Awaitable[None]],
    on_status: Callable[[bool], Awaitable[None]],
    stop: asyncio.Event,
    max_attempts: Optional[int] = None,
    initial_backoff: float = INITIAL_BACKOFF,
    subscribe_timeout: float = SUBSCRIBE_TIMEOUT_SECONDS,
) -> None:
    """Maintain a cable connection, reconnecting with jittered exponential backoff.

    `last_seq_ref` is a callable so the caller can update `last_seq` from
    incoming events; the supervisor reads it fresh on every reconnect.

    `max_attempts` caps the total number of attempts (each connect counts
    as one). None = unlimited (default — preserves existing behaviour).
    `initial_backoff` and `subscribe_timeout` are exposed for tests.
    """
    backoff = initial_backoff
    attempts = 0
    while not stop.is_set():
        attempts += 1
        try:
            async for ev in connect_and_subscribe(
                url, session_token, last_seq_ref(),
                subscribe_timeout=subscribe_timeout,
            ):
                await on_status(True)
                backoff = initial_backoff
                await on_event(ev)
        except CableRejected:
            await on_status(False)
            return  # do not retry
        except Exception:
            await on_status(False)
        if stop.is_set():
            return
        if max_attempts is not None and attempts >= max_attempts:
            return
        delay = compute_jittered_backoff(backoff, MAX_BACKOFF)
        try:
            await asyncio.wait_for(stop.wait(), timeout=delay)
            return
        except asyncio.TimeoutError:
            pass
        backoff = min(backoff * 2, MAX_BACKOFF)


async def run_heartbeat(
    ws,
    identifier: str,
    stop: asyncio.Event,
    interval: float = HEARTBEAT_INTERVAL_SECONDS,
) -> None:
    """Send `{type:'ping'}` frames at `interval` until `stop` is set or the
    socket is closed. Errors are swallowed (the supervisor handles disconnect)."""
    frame = build_heartbeat_frame(identifier)
    while not stop.is_set():
        try:
            await ws.send(frame)
        except Exception:
            return
        try:
            await asyncio.wait_for(stop.wait(), timeout=interval)
            return
        except asyncio.TimeoutError:
            pass


def parse_typed_event(event: CableEvent) -> Optional[object]:
    """Parse a raw CableEvent into a typed event dataclass where applicable.

    Returns a typed event (e.g. PhaseChangedEvent) when the event_type is
    recognised, or None when no typed mapping exists.
    """
    msg_type = event.event_type
    if msg_type == "phase_changed":
        payload = event.payload
        return PhaseChangedEvent(
            from_phase=payload.get("from"),
            to_phase=payload["to"],
            question_id=payload.get("question_id"),
            decisions_completed=payload.get("decisions_completed"),
            decisions_total=payload.get("decisions_total"),
        )
    return None
