"""Shared constants used by multiple modules in cli/hyrin/.

PHASE_LABELS is the SINGLE source of truth for human-facing phase names.
Both the phase chip (top of the screen) and the status bar (bottom) read
from this dict; never duplicate the mapping inline.

Adding a new phase: add the key here, add a chip pip in
`HyrinApp._phase_chip_text` if you need progress text (decisions n/m
etc.), and that's it — both renderers will pick it up.
"""
from __future__ import annotations

import os


# Canonical phase → human label. The cable server emits the snake_case
# keys in `phase_changed` payloads. Treat this as immutable: a typo in
# a caller (PHASE_LABELS["clarifyign"] = ...) is a bug, never an
# in-place edit. Do not mutate.
PHASE_LABELS: dict[str, str] = {
    "clarifying":        "Clarifying",
    "deciding":          "Decisions",
    "awaiting_approval": "Reviewing plan",
    "implementing":      "Implementing",
    "done":              "Done",
}


# Server URL resolution order:
#   1. HYRIN_SERVER_URL env var (lets a single install switch between
#      local dev and production without reinstalling).
#   2. The string literal default below — `https://hyrin.ai` in
#      source, rewritten to the production URL by
#      `script/inject-prod-url.sh` during the release build. Do NOT
#      change the literal manually for releases — change the script.
SERVER_URL: str = os.environ.get("HYRIN_SERVER_URL") or "https://hyrin.ai"
