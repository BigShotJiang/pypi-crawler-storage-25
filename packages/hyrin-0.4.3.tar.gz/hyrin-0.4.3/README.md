# hyrin (Python + Textual)

Candidate CLI for Hyrin interview sessions. Drives pairing, chat, local
tool execution, and codebase-state capture for the interviewer.

## Install (candidate)

Recommended — provisions Python 3.12 in an isolated environment:

```bash
uv tool install --python 3.12 hyrin
```

Alternative (requires Python ≥ 3.12 already installed):

```bash
pipx install hyrin
```

Plain pip works but pollutes site-packages; not recommended:

```bash
pip install hyrin
```

Tested on macOS and Linux. Windows is not supported in v1.0.

## Uninstall

```bash
uv tool uninstall hyrin     # if installed via uv
pipx uninstall hyrin        # if installed via pipx
pip uninstall hyrin         # if installed via pip
```

## Run

```bash
hyrin <PAIRING_CODE> [--cwd <PATH>]
```

Default: `--cwd` = current directory.

## Develop

```bash
cd cli
python -m pip install -e ".[dev]"
python -m pytest -v
```

`hyrin/` holds the package; `tests/` holds pytest + Textual Pilot tests.

## Architecture

- `client/` — protocol-only (httpx, websockets, pydantic). No Textual imports.
- `tools/` — local FS + `run_command` execution gated through `safety.py`.
- `ui/` — Textual widgets and CSS. No transport imports.
- `app.py` — the only place transports meet UI; owns the state machine.

See `docs/superpowers/specs/2026-04-16-textual-cli-rewrite-design.md`
for the full design.

## Releasing

CLI releases are fully automated by `.github/workflows/build-and-release.yml`. To cut a release:

1. Bump the version in `cli/pyproject.toml`.
2. Commit and tag: `git tag cli-vX.Y.Z && git push origin main --tags`.

The workflow injects the production server URL via `script/inject-prod-url.sh`, builds the sdist + wheel, verifies the URL is baked in, and publishes to PyPI via Trusted Publishing.

For local development, the source tree always points at `http://localhost:3100`. Do not commit changes to `cli/hyrin/constants.py` that hardcode the production URL — that's the inject script's job.
