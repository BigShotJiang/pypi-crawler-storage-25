import pytest
from hyrin.tools.exec import run_command, CommandTimeoutError, MAX_OUTPUT_BYTES


@pytest.mark.asyncio
async def test_run_command_returns_exit_code_and_stdout(tmp_path):
    output, exit_code = await run_command(str(tmp_path), "printf hello", timeout=5.0)
    assert exit_code == 0
    assert output.startswith("exit_code=0\n")
    assert "hello" in output


@pytest.mark.asyncio
async def test_run_command_captures_stderr_in_combined_output(tmp_path):
    output, exit_code = await run_command(
        str(tmp_path), "printf err 1>&2; exit 3", timeout=5.0,
    )
    assert exit_code == 3
    assert "err" in output


@pytest.mark.asyncio
async def test_run_command_times_out(tmp_path):
    with pytest.raises(CommandTimeoutError):
        await run_command(str(tmp_path), "sleep 5", timeout=0.1)


@pytest.mark.asyncio
async def test_run_command_truncates_large_output(tmp_path):
    # 200 KB > 100 KB cap
    output, exit_code = await run_command(
        str(tmp_path), f"yes A | head -c {200 * 1024}", timeout=5.0,
    )
    assert exit_code == 0
    assert "[output truncated]" in output
    assert len(output) <= MAX_OUTPUT_BYTES + len("exit_code=0\n") + len("\n[output truncated]") + 16
