import pytest
from textual.widgets import Static

from hyrin.app import HyrinApp, CableEventReceived, CableStatusChanged, PairCompleted
from hyrin.client.types import PhaseChangedEvent, PairResponse, WorkspaceInfo, SessionInfo
from hyrin.config import Config

_FAKE_PAIR = PairResponse(
    cable_url="ws://srv/cable",
    session_token="jwt",
    workspace=WorkspaceInfo(name="Acme"),
    session=SessionInfo(id=1, state="in_progress"),
)


def _make_app() -> HyrinApp:
    return HyrinApp(
        Config(code="ABCD1234", cwd="/tmp"),
        _skip_worker=True,
    )


@pytest.mark.asyncio
async def test_status_bar_shows_phase_suffix():
    """Test that status bar displays the current phase suffix."""
    app = _make_app()
    async with app.run_test() as pilot:
        # Simulate pairing and cable connection
        app.post_message(PairCompleted(response=_FAKE_PAIR))
        await pilot.pause()

        app.post_message(CableStatusChanged(connected=True))
        await pilot.pause()

        app.post_message(CableEventReceived(
            event_type="phase_changed",
            payload={"to": "clarifying", "from": None, "question_id": 1},
            seq=1,
        ))
        await pilot.pause()

        bar = app.query_one("#status-bar", Static)
        text = bar.render().plain
        assert "Clarifying" in text


@pytest.mark.asyncio
async def test_status_bar_shows_awaiting_approval_phase():
    """Test that status bar shows 'Your turn' for awaiting_approval phase."""
    app = _make_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_FAKE_PAIR))
        await pilot.pause()

        app.post_message(CableStatusChanged(connected=True))
        await pilot.pause()

        app.post_message(CableEventReceived(
            event_type="phase_changed",
            payload={"to": "awaiting_approval", "from": None, "question_id": 1},
            seq=1,
        ))
        await pilot.pause()

        bar = app.query_one("#status-bar", Static)
        text = bar.render().plain
        txt = text.lower()
        assert "your turn" in txt or "reviewing" in txt or "approval" in txt


@pytest.mark.asyncio
async def test_status_bar_shows_implementing_phase():
    """Test that status bar shows 'Implementing' for implementing phase."""
    app = _make_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_FAKE_PAIR))
        await pilot.pause()

        app.post_message(CableStatusChanged(connected=True))
        await pilot.pause()

        app.post_message(CableEventReceived(
            event_type="phase_changed",
            payload={"to": "implementing", "from": None, "question_id": 1},
            seq=1,
        ))
        await pilot.pause()

        bar = app.query_one("#status-bar", Static)
        text = bar.render().plain
        assert "Implementing" in text


@pytest.mark.asyncio
async def test_status_bar_shows_streaming_state():
    """Test that status bar shows streaming indicator when streaming."""
    app = _make_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_FAKE_PAIR))
        await pilot.pause()

        app.post_message(CableStatusChanged(connected=True))
        await pilot.pause()

        # Set up a phase
        app.post_message(CableEventReceived(
            event_type="phase_changed",
            payload={"to": "implementing", "from": None, "question_id": 1},
            seq=1,
        ))
        await pilot.pause()

        # Enable streaming
        app.streaming = True
        await pilot.pause()

        bar = app.query_one("#status-bar", Static)
        text = bar.render().plain
        txt = text.lower()
        # Should show spinner and phase-aware verb
        assert "⠙" in text or "hyrin is implementing" in txt
