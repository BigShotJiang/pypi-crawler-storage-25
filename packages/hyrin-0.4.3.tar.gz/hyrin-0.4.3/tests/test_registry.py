import pytest
from hyrin.tools import fs as fs_tools
from hyrin.tools import exec as exec_tool
from hyrin.tools.registry import (
    dispatch,
    UnknownToolError,
    BadArgsError,
    ToolResult,
    MAX_ALLOWED_TIMEOUT_SECONDS,
)
from hyrin.client.types import ActivityType


@pytest.mark.asyncio
async def test_dispatch_unknown_tool_raises(tmp_path):
    with pytest.raises(UnknownToolError):
        await dispatch(str(tmp_path), "not_a_tool", "{}")


@pytest.mark.asyncio
async def test_dispatch_bad_json_args_raises(tmp_path):
    with pytest.raises(BadArgsError):
        await dispatch(str(tmp_path), "read_file", "{not-json")


@pytest.mark.asyncio
async def test_dispatch_write_file_returns_activity(tmp_path):
    res: ToolResult = await dispatch(
        str(tmp_path), "write_file", '{"path":"a.txt","content":"hello"}',
    )
    assert "wrote" in res.tool_message
    assert res.activity is not None
    assert res.activity.type == ActivityType.FILE_WRITE
    payload = res.activity.payload
    assert payload["path"] == "a.txt"
    assert payload["size_bytes"] == 5
    assert "content_hash" in payload
    assert payload["content"] == "hello"


@pytest.mark.asyncio
async def test_dispatch_write_file_missing_path_returns_error(tmp_path, monkeypatch):
    calls = []

    def _fail(*args, **kwargs):
        calls.append((args, kwargs))
        raise AssertionError("fs.write_file should not be called")

    monkeypatch.setattr(fs_tools, "write_file", _fail)

    res: ToolResult = await dispatch(
        str(tmp_path), "write_file", '{"path":"","content":"hi"}',
    )
    assert res.is_error is True
    assert res.tool_message.startswith("error:")
    assert res.activity is not None
    assert res.activity.payload.get("error") == "missing_path"
    assert calls == []


@pytest.mark.asyncio
async def test_dispatch_write_file_omitted_path_returns_error(tmp_path, monkeypatch):
    monkeypatch.setattr(
        fs_tools, "write_file",
        lambda *a, **kw: (_ for _ in ()).throw(AssertionError("unreachable")),
    )
    res: ToolResult = await dispatch(
        str(tmp_path), "write_file", '{"content":"hi"}',
    )
    assert res.is_error is True
    assert res.tool_message.startswith("error:")


@pytest.mark.asyncio
async def test_dispatch_run_command_truncates_for_activity(tmp_path):
    res = await dispatch(
        str(tmp_path), "run_command",
        '{"command":"printf done","timeout_ms":2000}',
    )
    assert res.activity.type == ActivityType.RUN_COMMAND
    assert res.activity.payload["exit_code"] == 0
    assert "done" in res.activity.payload["stdout"]


@pytest.mark.asyncio
async def test_dispatch_run_command_blocks_destructive(tmp_path, monkeypatch):
    """Block-class commands must NOT reach exec_tool.run_command."""
    called = []

    async def _fail(*a, **kw):
        called.append((a, kw))
        raise AssertionError("exec_tool.run_command should not be called for blocked input")

    monkeypatch.setattr(exec_tool, "run_command", _fail)

    res = await dispatch(
        str(tmp_path), "run_command",
        '{"command":"rm -rf /"}',
    )
    assert res.is_error is True
    assert "blocked" in res.tool_message.lower() or "refus" in res.tool_message.lower()
    assert called == []
    assert res.activity is not None
    assert res.activity.type == ActivityType.RUN_COMMAND


@pytest.mark.asyncio
async def test_dispatch_run_command_clamps_excessive_timeout(tmp_path, monkeypatch):
    """Server-supplied timeout_ms must be clamped to MAX_ALLOWED_TIMEOUT_SECONDS."""
    captured = {}

    async def _capture(cwd, command, timeout=None):
        captured["timeout"] = timeout
        return ("exit_code=0\n", 0)

    monkeypatch.setattr(exec_tool, "run_command", _capture)

    # 1 hour in ms — well over the cap
    await dispatch(
        str(tmp_path), "run_command",
        '{"command":"ls","timeout_ms":3600000}',
    )
    assert captured["timeout"] is not None
    assert captured["timeout"] <= MAX_ALLOWED_TIMEOUT_SECONDS
