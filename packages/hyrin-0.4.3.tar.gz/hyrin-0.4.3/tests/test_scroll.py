import pytest
from textual.containers import VerticalScroll

from hyrin.app import (
    HyrinApp, AppState, PairCompleted, StreamStarted, StreamChunkReceived,
)
from hyrin.client.types import PairResponse, WorkspaceInfo, SessionInfo
from hyrin.config import Config
from hyrin.ui.widgets import MessageWidget


def _paired_app():
    app = HyrinApp(
        Config(code="abc", cwd="/tmp"),
        _skip_worker=True,
    )
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )
    return app, fake


async def _mount_many_messages(app, n=40):
    log = app.query_one("#chat-log", VerticalScroll)
    for i in range(n):
        log.mount(MessageWidget(role="user", content=f"msg {i}"))


@pytest.mark.asyncio
async def test_sticky_scroll_preserves_position_when_scrolled_up():
    app, fake = _paired_app()
    async with app.run_test(size=(80, 24)) as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        await _mount_many_messages(app, 40)
        await pilot.pause()
        log = app.query_one("#chat-log", VerticalScroll)
        log.scroll_to(y=5, animate=False)
        await pilot.pause()
        assert log.scroll_y == 5
        app.post_message(StreamStarted())
        await pilot.pause()
        app.post_message(StreamChunkReceived("incoming"))
        await pilot.pause()
        assert log.scroll_y == 5, f"sticky snap fired while scrolled up; y={log.scroll_y}"


@pytest.mark.asyncio
async def test_sticky_scroll_snaps_when_at_bottom():
    app, fake = _paired_app()
    async with app.run_test(size=(80, 24)) as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        await _mount_many_messages(app, 40)
        await pilot.pause()
        log = app.query_one("#chat-log", VerticalScroll)
        log.scroll_end(animate=False)
        await pilot.pause()
        app.post_message(StreamStarted())
        await pilot.pause()
        app.post_message(StreamChunkReceived("incoming"))
        await pilot.pause()
        assert log.scroll_y == log.max_scroll_y


@pytest.mark.asyncio
async def test_threshold_three_rows():
    app, fake = _paired_app()
    async with app.run_test(size=(80, 24)) as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        await _mount_many_messages(app, 40)
        await pilot.pause()
        log = app.query_one("#chat-log", VerticalScroll)
        log.scroll_to(y=max(log.max_scroll_y - 2, 0), animate=False)
        await pilot.pause()
        app.post_message(StreamStarted())
        await pilot.pause()
        app.post_message(StreamChunkReceived("incoming"))
        await pilot.pause()
        assert log.scroll_y == log.max_scroll_y, (
            f"within-3 threshold did not snap; y={log.scroll_y} max={log.max_scroll_y}"
        )
