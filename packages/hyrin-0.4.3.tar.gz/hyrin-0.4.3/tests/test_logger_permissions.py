"""Verify the CLI log file is created with mode 0600 (owner read/write only).

The log file at ~/.cache/hyrin/hyrin.log can contain candidate code, command
outputs, and chat fragments. On a shared machine the default umask (0644)
would expose those to other local users. Force 0600 explicitly.

Skips on Windows because POSIX-mode bits aren't meaningful there.
"""
from __future__ import annotations

import logging
import os
import platform

import pytest


@pytest.mark.skipif(platform.system() == "Windows", reason="POSIX modes only")
def test_log_file_created_with_owner_only_permissions(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))

    # Reset the cached singleton handlers so _setup_logger() re-runs
    # against the new HOME without forcing a re-import of hyrin.app
    # (re-importing would invalidate other tests' module-level state).
    logger = logging.getLogger("hyrin")
    for h in list(logger.handlers):
        h.close()
        logger.removeHandler(h)

    from hyrin.app import _setup_logger

    try:
        _setup_logger()
        log_path = tmp_path / ".cache/hyrin/hyrin.log"
        assert log_path.exists(), "log file should be created on logger init"
        mode = log_path.stat().st_mode & 0o777
        assert mode == 0o600, f"expected mode 0o600, got 0o{mode:o}"
    finally:
        # Restore the logger to the original-import state so subsequent tests
        # that rely on `hyrin.app.log` still write to a valid handler.
        for h in list(logger.handlers):
            h.close()
            logger.removeHandler(h)
        _setup_logger()  # repopulate with the real $HOME path
