"""ModeBadge: header chip mirroring the web app's ModeBadge.

Behaviour invariant from app/frontend/components/Layout/ModeBadge.tsx:
  - staging      → "STAGING" visible
  - development  → "DEV"     visible
  - production / test / unknown / empty / missing → no badge (display=False)

Production must remain a "no badge" state — that absence is the prod
signal, so any unknown value also collapses to nothing.
"""
import pytest

from hyrin.app import HyrinApp, PairCompleted
from hyrin.client.types import PairResponse, WorkspaceInfo, SessionInfo
from hyrin.config import Config
from hyrin.ui.widgets import ModeBadge


def _pair(app_mode: str = "") -> PairResponse:
    return PairResponse(
        cable_url="ws://srv/cable",
        session_token="jwt",
        app_mode=app_mode,
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )


def _make_app() -> HyrinApp:
    return HyrinApp(
        Config(code="ABCD1234", cwd="/tmp"),
        _skip_worker=True,
    )


def test_mode_badge_unit_staging():
    badge = ModeBadge("staging")
    assert badge.renderable == "STAGING"
    assert badge.has_class("-staging")


def test_mode_badge_unit_development():
    badge = ModeBadge("development")
    assert badge.renderable == "DEV"
    assert badge.has_class("-dev")


@pytest.mark.parametrize("mode", ["production", "test", "", "wat", "STAGING"])
def test_mode_badge_unit_hidden_for_non_staging_dev(mode):
    badge = ModeBadge(mode)
    assert badge.renderable == ""
    assert not badge.has_class("-staging")
    assert not badge.has_class("-dev")


def test_mode_badge_set_mode_clears_previous_class():
    """Toggling staging → development must drop the old class."""
    badge = ModeBadge("staging")
    badge.set_mode("development")
    assert badge.has_class("-dev")
    assert not badge.has_class("-staging")
    badge.set_mode("production")
    assert not badge.has_class("-dev")
    assert not badge.has_class("-staging")


@pytest.mark.asyncio
async def test_mode_badge_mounts_hidden_by_default():
    """Before pair completes, the badge is mounted but invisible."""
    app = _make_app()
    async with app.run_test() as pilot:
        await pilot.pause()
        badge = app.query_one("#mode-badge", ModeBadge)
        assert badge.renderable == ""
        assert badge.display is False


@pytest.mark.asyncio
async def test_mode_badge_shows_staging_after_pair():
    app = _make_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_pair("staging")))
        await pilot.pause()
        badge = app.query_one("#mode-badge", ModeBadge)
        assert badge.renderable == "STAGING"
        assert badge.display is True


@pytest.mark.asyncio
async def test_mode_badge_shows_dev_after_pair():
    app = _make_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_pair("development")))
        await pilot.pause()
        badge = app.query_one("#mode-badge", ModeBadge)
        assert badge.renderable == "DEV"
        assert badge.display is True


@pytest.mark.asyncio
async def test_mode_badge_hidden_in_production():
    app = _make_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_pair("production")))
        await pilot.pause()
        badge = app.query_one("#mode-badge", ModeBadge)
        assert badge.renderable == ""
        assert badge.display is False


@pytest.mark.asyncio
async def test_mode_badge_hidden_for_unknown_value():
    app = _make_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_pair("wat")))
        await pilot.pause()
        badge = app.query_one("#mode-badge", ModeBadge)
        assert badge.renderable == ""
        assert badge.display is False
