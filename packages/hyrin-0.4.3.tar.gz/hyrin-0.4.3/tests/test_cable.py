import asyncio
import json

import pytest
import websockets

from hyrin.client.cable import (
    build_subscribe_identifier, parse_frame, ParsedFrame,
    HEARTBEAT_INTERVAL_SECONDS,
    connect_and_subscribe, CableEvent, origin_from_ws_url,
)


def test_identifier_includes_last_seq_when_positive():
    ident = build_subscribe_identifier("jwt", last_seq=5)
    obj = json.loads(ident)
    assert obj == {"channel": "InterviewChannel", "session_token": "jwt", "last_seq": 5}


def test_identifier_omits_last_seq_when_zero():
    ident = build_subscribe_identifier("jwt", last_seq=0)
    obj = json.loads(ident)
    assert obj == {"channel": "InterviewChannel", "session_token": "jwt"}


def test_parse_frame_filters_welcome_ping_confirm():
    for kind in ("welcome", "ping", "confirm_subscription"):
        assert parse_frame(json.dumps({"type": kind})) is None


def test_parse_frame_rejects_subscription_is_fatal():
    pf = parse_frame(json.dumps({"type": "reject_subscription"}))
    assert isinstance(pf, ParsedFrame)
    assert pf.kind == "reject"


def test_parse_frame_extracts_inner_message_session_started():
    payload = {
        "identifier": "{}",
        "message": {
            "type": "session_started",
            "payload": {"question": {"id": 7, "title": "BST", "body": "go", "language": "Go"}},
            "seq": 1,
        },
    }
    pf = parse_frame(json.dumps(payload))
    assert pf.kind == "event"
    assert pf.event_type == "session_started"
    assert pf.seq == 1
    assert pf.payload["question"]["id"] == 7


def test_heartbeat_interval_constant_is_three_seconds():
    assert HEARTBEAT_INTERVAL_SECONDS == 3.0


def test_origin_from_ws_url_maps_wss_to_https():
    assert origin_from_ws_url("wss://hyrin.ai/cable") == "https://hyrin.ai"
    assert origin_from_ws_url("ws://127.0.0.1:3100/cable") == "http://127.0.0.1:3100"


@pytest.mark.asyncio
async def test_connect_and_subscribe_sends_origin_header():
    received_origin: asyncio.Future = asyncio.Future()

    async def server(ws):
        received_origin.set_result(ws.request.headers.get("Origin"))
        first = json.loads(await ws.recv())
        await ws.send(json.dumps({"type": "welcome"}))
        await ws.send(json.dumps({
            "identifier": first["identifier"],
            "message": {"type": "kick", "payload": {}, "seq": 1},
        }))

    async with websockets.serve(server, "127.0.0.1", 0) as srv:
        port = srv.sockets[0].getsockname()[1]
        url = f"ws://127.0.0.1:{port}/cable"
        async for ev in connect_and_subscribe(url, "jwt", last_seq=0):
            if ev.event_type == "kick":
                break

    assert await received_origin == f"http://127.0.0.1:{port}"


@pytest.mark.asyncio
async def test_connect_and_subscribe_yields_events_and_handles_kick():
    received_subscribe = asyncio.Future()

    async def server(ws):
        # First frame from client must be a subscribe with our identifier.
        first = json.loads(await ws.recv())
        received_subscribe.set_result(first)
        await ws.send(json.dumps({"type": "welcome"}))           # filtered
        await ws.send(json.dumps({"type": "confirm_subscription"}))  # filtered
        await ws.send(json.dumps({                                # delivered
            "identifier": first["identifier"],
            "message": {"type": "session_started",
                        "payload": {"question": {"id": 1}}, "seq": 1},
        }))
        await ws.send(json.dumps({
            "identifier": first["identifier"],
            "message": {"type": "kick",
                        "payload": {"reason": "interviewer ended"}, "seq": 2},
        }))

    async with websockets.serve(server, "127.0.0.1", 0) as srv:
        port = srv.sockets[0].getsockname()[1]
        url = f"ws://127.0.0.1:{port}"
        events: list[CableEvent] = []
        async for ev in connect_and_subscribe(url, "jwt", last_seq=0):
            events.append(ev)
            if ev.event_type == "kick":
                break

    sub = await received_subscribe
    assert sub["command"] == "subscribe"
    ident = json.loads(sub["identifier"])
    assert ident["session_token"] == "jwt"
    assert "last_seq" not in ident
    assert [e.event_type for e in events] == ["session_started", "kick"]
    assert events[0].seq == 1
    assert events[1].payload["reason"] == "interviewer ended"


from hyrin.client.cable import compute_jittered_backoff


def test_jittered_backoff_uses_clamp_and_jitter():
    midpoint = lambda a, b: 1.0  # no-jitter rng
    assert compute_jittered_backoff(4.0, 30.0, midpoint) == 4.0
    assert compute_jittered_backoff(100.0, 30.0, midpoint) == 30.0
    half = lambda a, b: 0.5
    assert compute_jittered_backoff(8.0, 30.0, half) == 4.0


def test_parse_frame_routes_gap_message():
    payload = {"identifier": "{}",
               "message": {"type": "gap", "payload": {}}}
    pf = parse_frame(json.dumps(payload))
    assert pf.kind == "event"
    assert pf.event_type == "gap"


@pytest.mark.asyncio
async def test_connect_and_subscribe_times_out_when_server_never_confirms():
    """If the server opens the socket but never sends welcome / confirm_subscription,
    connect_and_subscribe must abort within subscribe_timeout so the supervisor
    can reconnect. Without this, a half-broken cable hangs the candidate forever."""
    server_saw_subscribe = asyncio.Event()

    async def server(ws):
        # Accept the subscribe frame, then go silent — never send welcome
        # or confirm_subscription. This simulates a backend that accepted
        # the WS upgrade but never wired up the channel.
        await ws.recv()
        server_saw_subscribe.set()
        try:
            await asyncio.sleep(5.0)
        except asyncio.CancelledError:
            pass

    async with websockets.serve(server, "127.0.0.1", 0) as srv:
        port = srv.sockets[0].getsockname()[1]
        url = f"ws://127.0.0.1:{port}"

        events: list[CableEvent] = []
        with pytest.raises(asyncio.TimeoutError):
            async for ev in connect_and_subscribe(
                url, "jwt", last_seq=0, subscribe_timeout=0.2,
            ):
                events.append(ev)

    assert server_saw_subscribe.is_set()
    assert events == []  # no events delivered before the timeout fires


from hyrin.client.cable import run_supervisor


@pytest.mark.asyncio
async def test_run_supervisor_honours_max_attempts():
    """Bounded retry: when max_attempts is set, the supervisor stops
    reconnecting after the cap. A test server that always closes the
    socket forces the failure path; the supervisor must surface
    on_status(False) and return without waiting forever."""
    attempts = {"n": 0}

    async def server(ws):
        # Accept the subscribe, then close the socket cold. Each accept
        # increments the attempt counter on the test side.
        await ws.recv()
        await ws.close()

    async with websockets.serve(server, "127.0.0.1", 0) as srv:
        port = srv.sockets[0].getsockname()[1]
        url = f"ws://127.0.0.1:{port}"

        statuses: list[bool] = []
        events_seen: list[CableEvent] = []

        async def on_event(ev):
            events_seen.append(ev)

        async def on_status(connected):
            statuses.append(connected)
            if not connected:
                attempts["n"] += 1

        stop = asyncio.Event()
        # max_attempts=2 with a near-zero backoff — supervisor should bail
        # within a second on a stable build.
        await run_supervisor(
            url, "jwt", lambda: 0,
            on_event=on_event,
            on_status=on_status,
            stop=stop,
            max_attempts=2,
            initial_backoff=0.01,
        )

    assert events_seen == []
    # 2 disconnects → 2 on_status(False) calls (one per failed attempt).
    assert attempts["n"] == 2


@pytest.mark.asyncio
async def test_run_supervisor_default_is_unlimited_attempts():
    """Sanity check: the default code path keeps the existing forever-retry
    semantics. Drive it from a server that closes once, then stays open and
    sends a usable event on the second attempt — supervisor must succeed."""
    attempts = {"n": 0}

    async def server(ws):
        attempts["n"] += 1
        first = json.loads(await ws.recv())
        if attempts["n"] == 1:
            await ws.close()
            return
        await ws.send(json.dumps({"type": "welcome"}))
        await ws.send(json.dumps({
            "identifier": first["identifier"],
            "message": {"type": "session_started",
                        "payload": {}, "seq": 1},
        }))
        # Keep the socket open just long enough to deliver the event.
        await asyncio.sleep(0.05)

    async with websockets.serve(server, "127.0.0.1", 0) as srv:
        port = srv.sockets[0].getsockname()[1]
        url = f"ws://127.0.0.1:{port}"

        events_seen: list[CableEvent] = []
        stop = asyncio.Event()

        async def on_event(ev):
            events_seen.append(ev)
            stop.set()

        async def on_status(_connected):
            pass

        await asyncio.wait_for(
            run_supervisor(
                url, "jwt", lambda: 0,
                on_event=on_event,
                on_status=on_status,
                stop=stop,
                initial_backoff=0.01,
            ),
            timeout=2.0,
        )

    assert any(ev.event_type == "session_started" for ev in events_seen)
    assert attempts["n"] >= 2


@pytest.mark.asyncio
async def test_heartbeat_sends_ping_frames_until_stopped():
    received = []

    async def server(ws):
        async for frame in ws:
            received.append(json.loads(frame))

    async with websockets.serve(server, "127.0.0.1", 0) as srv:
        port = srv.sockets[0].getsockname()[1]
        async with websockets.connect(f"ws://127.0.0.1:{port}") as ws:
            from hyrin.client.cable import run_heartbeat
            stop = asyncio.Event()
            task = asyncio.create_task(run_heartbeat(ws, "ident-x", stop, interval=0.05))
            await asyncio.sleep(0.18)  # ~3 pings
            stop.set()
            await task

    pings = [f for f in received if f.get("command") == "message"]
    assert len(pings) >= 2
    assert all(json.loads(f["data"]) == {"type": "ping"} for f in pings)
    assert all(f["identifier"] == "ident-x" for f in pings)
