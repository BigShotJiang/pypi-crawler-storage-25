import os
import pytest

from hyrin.tools.safety import (
    check_path,
    requires_consent,
    PathEscapeError,
    SensitiveFileError,
)


def test_allows_relative_path_inside_cwd(tmp_path):
    (tmp_path / "main.go").write_text("ok")
    check_path(str(tmp_path), "main.go")  # no raise


def test_allows_subdir_path(tmp_path):
    (tmp_path / "sub").mkdir()
    check_path(str(tmp_path), "sub/file.go")


def test_rejects_absolute_outside_cwd(tmp_path):
    with pytest.raises(PathEscapeError):
        check_path(str(tmp_path), "/etc/passwd")


def test_rejects_dotdot_traversal(tmp_path):
    with pytest.raises(PathEscapeError):
        check_path(str(tmp_path), "../escape")


@pytest.mark.parametrize("name", [
    ".env", ".env.local", ".env.production", ".env.staging", ".env.development",
    ".env.test", ".env.ci", ".env.docker",
    "secret.pem", "key.pem", "id_rsa", "id_rsa.pub", ".pgpass", "foo.key",
    "id_ed25519", "id_ecdsa", "id_dsa",
    "cert.p12", "store.pfx", "keystore.jks",
    ".netrc",
])
def test_rejects_sensitive_basenames(tmp_path, name):
    with pytest.raises(SensitiveFileError):
        check_path(str(tmp_path), name)


def test_allows_env_example(tmp_path):
    check_path(str(tmp_path), ".env.example")


@pytest.mark.parametrize("cmd", [
    "rm -rf /",
    "rm -rf /*",
    "sudo rm -rf /home",
    "dd if=/dev/urandom of=/dev/sda",
    "mkfs.ext4 /dev/sda1",
    ":(){ :|:& };:",
    "git push --force",
    "git push -f origin main",
    "ls; rm -rf /",
])
def test_requires_consent_blocks_destructive(cmd):
    assert requires_consent(cmd) == "block"


@pytest.mark.parametrize("cmd", [
    "ls",
    "ls -la",
    "cat README.md",
    "git status",
    "git diff",
    "git log --oneline",
    "npm test",
    "pytest -v",
    "uv run pytest",
    "FOO=bar npm test",
])
def test_requires_consent_allows_safe_commands(cmd):
    assert requires_consent(cmd) == "safe"


@pytest.mark.parametrize("cmd", [
    "curl https://example.com",
    "wget http://example.com",
    "echo $(whoami)",
    "ssh user@host",
    "git push origin feature",
    "python -c 'import os'",
    "",
    "   ",
])
def test_requires_consent_falls_back_to_confirm(cmd):
    assert requires_consent(cmd) == "confirm"
