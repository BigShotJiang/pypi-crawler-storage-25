import json
from hyrin.client.types import (
    PairRequest, PairResponse, WorkspaceInfo, SessionInfo, QuestionInfo,
    MessageRecord, ChatRequest, ChatMessage, ToolCall, ToolFunction,
    ChatChunk, ChunkChoice, ChunkDelta, ErrorPayload,
    ActivityEvent, ActivityType,
)


def test_pair_request_roundtrip():
    req = PairRequest(code="ABCDEF")
    assert json.loads(req.model_dump_json()) == {"code": "ABCDEF"}


def test_pair_response_parses_minimal_payload():
    raw = {
        "cable_url": "ws://x/cable",
        "session_token": "jwt",
        "workspace": {"name": "Acme"},
        "session": {"id": 42, "state": "in_progress"},
        "messages": [],
    }
    resp = PairResponse.model_validate(raw)
    assert resp.session.id == 42
    assert resp.question is None


def test_chat_message_serializes_tool_call():
    msg = ChatMessage(
        role="assistant",
        content="",
        tool_calls=[ToolCall(
            id="call-1",
            type="function",
            function=ToolFunction(name="read_file", arguments='{"path":"x"}'),
        )],
    )
    blob = json.loads(msg.model_dump_json(exclude_none=True))
    assert blob["tool_calls"][0]["function"]["arguments"] == '{"path":"x"}'
    assert "tool_call_id" not in blob  # absent when not a tool reply


def test_chat_message_tool_reply_shape():
    msg = ChatMessage(role="tool", tool_call_id="call-1", content="result")
    blob = json.loads(msg.model_dump_json(exclude_none=True))
    assert blob == {"role": "tool", "tool_call_id": "call-1", "content": "result"}


def test_chat_chunk_parses_finish_reason():
    raw = {"choices": [{"index": 0, "delta": {}, "finish_reason": "tool_calls"}]}
    chunk = ChatChunk.model_validate(raw)
    assert chunk.choices[0].finish_reason == "tool_calls"


def test_activity_event_run_command_payload():
    ev = ActivityEvent(
        seq=1,
        timestamp="2026-04-16T00:00:00Z",
        type=ActivityType.RUN_COMMAND,
        payload={"command": "ls", "exit_code": 0, "duration_ms": 12,
                 "stdout": "a", "stderr": ""},
    )
    blob = json.loads(ev.model_dump_json())
    assert blob["type"] == "run_command"
    assert blob["payload"]["exit_code"] == 0


def test_question_info_tolerates_null_strings_from_rails():
    # Rails serializes nil columns as JSON null. The model must coerce
    # these to "" rather than raise ValidationError.
    raw = {
        "id": 7,
        "title": "Implement Pagination",
        "body": "Build an API endpoint…",
        "language": None,
        "starter_repo_url": None,
    }
    q = QuestionInfo.model_validate(raw)
    assert q.id == 7
    assert q.language == ""
    assert q.starter_repo_url == ""


def test_pair_response_parses_app_mode_staging():
    """Server sends `app_mode: "staging"` at the top level — capture it."""
    raw = {
        "cable_url": "ws://x/cable",
        "session_token": "jwt",
        "app_mode": "staging",
        "workspace": {"name": "Acme"},
        "session": {"id": 1, "state": "in_progress"},
        "messages": [],
    }
    resp = PairResponse.model_validate(raw)
    assert resp.app_mode == "staging"


def test_pair_response_app_mode_defaults_to_empty_when_missing():
    """Backward-compatible: older servers omit `app_mode` entirely."""
    raw = {
        "cable_url": "ws://x/cable",
        "session_token": "jwt",
        "workspace": {"name": "Acme"},
        "session": {"id": 1, "state": "in_progress"},
        "messages": [],
    }
    resp = PairResponse.model_validate(raw)
    assert resp.app_mode == ""


def test_pair_response_app_mode_null_coerces_to_empty():
    """A `null` from Rails must be coerced to '' rather than raise."""
    raw = {
        "cable_url": "ws://x/cable",
        "session_token": "jwt",
        "app_mode": None,
        "workspace": {"name": "Acme"},
        "session": {"id": 1, "state": "in_progress"},
        "messages": [],
    }
    resp = PairResponse.model_validate(raw)
    assert resp.app_mode == ""


def test_pair_response_with_nullable_question_fields_roundtrips():
    raw = {
        "cable_url": "ws://x/cable",
        "session_token": "jwt",
        "workspace": {"name": "Acme"},
        "session": {"id": 1, "state": "paired"},
        "question": {
            "id": 7, "title": "X", "body": "Y",
            "language": None, "starter_repo_url": None,
        },
        "messages": [],
    }
    resp = PairResponse.model_validate(raw)
    assert resp.question.language == ""
    assert resp.question.starter_repo_url == ""
