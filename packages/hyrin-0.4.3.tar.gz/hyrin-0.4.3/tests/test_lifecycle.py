"""Cable-lifecycle handlers: `session_ended` and `question_advanced`.

These cover the two transitions that used to be stubbed:

  * session_ended  → mount a goodbye notice, disable the prompt, and
    schedule a clean exit (don't just flip state).
  * question_advanced → clear the chat log, reset the client-side chat
    history, swap the QuestionPanel, and mount a moving-on notice
    (don't just refresh the layout).
"""
from __future__ import annotations

import pytest

from hyrin.app import (
    AppState, CableEventReceived, HyrinApp, PairCompleted,
)
from hyrin.client.types import (
    PairResponse, QuestionInfo, SessionInfo, WorkspaceInfo,
)
from hyrin.config import Config
from hyrin.ui.widgets import (
    ActivityWidget, MessageWidget, QuestionPanel, SystemNoticeWidget,
)


def _make_cfg() -> Config:
    return Config(code="abc", cwd="/tmp")


def _fake_pair(question: dict | None = None) -> PairResponse:
    return PairResponse(
        cable_url="ws://srv/cable",
        session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
        question=question,
    )


@pytest.mark.asyncio
async def test_session_ended_mounts_notice_and_schedules_exit(monkeypatch):
    """session_ended should: (a) mount a goodbye SystemNoticeWidget,
    (b) disable the prompt, (c) schedule app.exit via set_timer so the
    candidate sees the notice before the TUI tears down."""
    app = HyrinApp(_make_cfg(), _skip_worker=True)

    exit_called = {"n": 0}

    def fake_exit(*args, **kwargs):
        exit_called["n"] += 1

    scheduled = {"delay": None, "callback": None}

    def fake_set_timer(delay, callback, *args, **kwargs):
        scheduled["delay"] = delay
        scheduled["callback"] = callback
        # Return a truthy sentinel; app.py doesn't store the handle.
        return object()

    async with app.run_test() as pilot:
        # Replace exit + set_timer BEFORE we trigger the event so the
        # Pilot runtime isn't torn down while still inside run_test().
        monkeypatch.setattr(app, "exit", fake_exit)
        monkeypatch.setattr(app, "set_timer", fake_set_timer)

        app.post_message(PairCompleted(response=_fake_pair()))
        await pilot.pause()

        from hyrin.app import PromptTextArea
        prompt = app.query_one("#prompt", PromptTextArea)
        assert prompt.disabled is False

        app.post_message(CableEventReceived(
            event_type="session_ended", payload={}, seq=1,
        ))
        await pilot.pause()

        # State flipped to ENDED.
        assert app.state is AppState.ENDED
        # Goodbye notice mounted.
        notices = [n.content for n in app.query("SystemNoticeWidget").results()]
        assert any("Interview ended" in (n or "") for n in notices), (
            f"expected goodbye notice, got {notices!r}"
        )
        # Prompt disabled.
        assert prompt.disabled is True
        # Exit scheduled (not invoked synchronously).
        assert scheduled["callback"] is not None
        assert scheduled["delay"] == app.EXIT_DELAY_SECONDS
        assert exit_called["n"] == 0
        # Invoking the scheduled callback triggers self.exit(0).
        scheduled["callback"]()
        assert exit_called["n"] == 1


@pytest.mark.asyncio
async def test_question_advanced_clears_chat_log():
    """question_advanced with an inline question payload should clear
    all existing chat-log children, reset `_chat_history`, remove the
    old QuestionPanel, mount a fresh one for the new question, and
    drop a short moving-on notice."""
    app = HyrinApp(_make_cfg(), _skip_worker=True)

    initial_question = {
        "id": 10, "title": "First", "body": "q1 body", "language": "Python",
    }

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_fake_pair(initial_question)))
        await pilot.pause()

        from textual.containers import VerticalScroll
        chat_log = app.query_one("#chat-log", VerticalScroll)
        # Populate the chat log with a mix of widgets so we can assert
        # they're all wiped on advance.
        chat_log.mount(MessageWidget(role="user", content="hi"))
        chat_log.mount(MessageWidget(role="assistant", content="hello"))
        chat_log.mount(ActivityWidget(
            tool="read_file", args={"path": "x.py"}, result={"content": "a\n"},
        ))
        chat_log.mount(SystemNoticeWidget("old notice"))
        await pilot.pause()

        # Seed a non-empty chat history as well.
        from hyrin.client.types import ChatMessage
        app._chat_history = [
            ChatMessage(role="user", content="hi"),
            ChatMessage(role="assistant", content="hello"),
        ]

        # Sanity: one QuestionPanel mounted already.
        assert len(list(app.query(QuestionPanel).results())) == 1
        assert len(list(chat_log.children)) >= 4

        # Broadcast: new-shape payload with inline question.
        new_question = {
            "id": 11, "title": "Second", "body": "q2 body", "language": "Go",
        }
        app.post_message(CableEventReceived(
            event_type="question_advanced",
            payload={"question": new_question},
            seq=42,
        ))
        await pilot.pause()
        await pilot.pause()

        # Only one QuestionPanel, and it's the NEW one.
        panels = list(app.query(QuestionPanel).results())
        assert len(panels) == 1
        title_attr = getattr(panels[0], "title", "")
        title_str = str(title_attr)
        assert "Second" in title_str, f"expected new title, got {title_str!r}"

        # Chat log contains ONLY the moving-on notice (old widgets cleared).
        chat_log = app.query_one("#chat-log", VerticalScroll)
        remaining = list(chat_log.children)
        assert len(remaining) == 1
        assert isinstance(remaining[0], SystemNoticeWidget)
        assert "Moved to next question" in (remaining[0].content or "")

        # Client history wiped.
        assert app._chat_history == []
        # Streaming bookkeeping reset.
        assert app._current_assistant is None
        assert app.streaming is False


@pytest.mark.asyncio
async def test_question_advanced_without_payload_falls_back_to_refetch(monkeypatch):
    """When the broadcast omits ``payload.question`` (old server shape),
    the handler should re-fetch the session via pair_client.pair and use
    resp.question to rebuild the QuestionPanel."""
    from hyrin.client import pair as pair_client

    initial_question = {
        "id": 20, "title": "Old", "body": "old body", "language": "Python",
    }
    refetched_question_info = QuestionInfo(
        id=21, title="Refetched", body="new body", language="Go",
    )

    async def fake_pair(http, code):
        return PairResponse(
            cable_url="ws://srv/cable",
            session_token="jwt",
            workspace=WorkspaceInfo(name="Acme"),
            session=SessionInfo(id=1, state="in_progress"),
            question=refetched_question_info,
        )

    monkeypatch.setattr(pair_client, "pair", fake_pair)

    app = HyrinApp(_make_cfg(), _skip_worker=True)

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_fake_pair(initial_question)))
        await pilot.pause()

        app.post_message(CableEventReceived(
            event_type="question_advanced",
            payload={},  # no inline question → force refetch
            seq=99,
        ))
        # Let the async refetch worker run.
        await pilot.pause()
        await pilot.pause()
        await pilot.pause()

        panels = list(app.query(QuestionPanel).results())
        assert len(panels) == 1
        title_str = str(getattr(panels[0], "title", ""))
        assert "Refetched" in title_str, f"expected refetched title, got {title_str!r}"
