import pytest
from hyrin.ui.widgets import ActivityWidget


@pytest.mark.parametrize("tool, args, result, expected", [
    ("read_file", {"path": "auth.py"}, {"content": "a\nb\nc\n"}, "Read auth.py (3 lines)"),
    ("write_file", {"path": "models.py", "content": "x\n" * 10}, {}, "Wrote models.py (10 lines)"),
    ("edit_file", {"path": "models.py"}, {}, "Edited models.py"),
    ("list_directory", {"path": "src"}, {"content": "a\nb\n"}, "Listed src/"),
    ("run_command", {"command": "pytest tests/"}, {"exit_code": 0}, "Ran pytest tests/ — exit 0"),
])
def test_activity_widget_renders_semantic_label(tool, args, result, expected):
    w = ActivityWidget(tool=tool, args=args, result=result)
    rendered = w.render()
    text = rendered.plain if hasattr(rendered, "plain") else str(rendered)
    assert expected == text.strip()


@pytest.mark.parametrize("tool, expected", [
    ("write_file", "write_file: missing path"),
    ("read_file", "read_file: missing path"),
    ("edit_file", "edit_file: missing path"),
])
def test_activity_widget_renders_missing_path(tool, expected):
    w = ActivityWidget(tool=tool, args={"path": ""}, result={})
    rendered = w.render()
    text = rendered.plain if hasattr(rendered, "plain") else str(rendered)
    assert text.strip() == expected
    assert "None" not in text


@pytest.mark.parametrize("tool, args, result", [
    ("read_file", {"path": "x.py"}, {"content": ""}),
    ("write_file", {"path": "x.py", "content": ""}, {}),
    ("run_command", {"command": "ls"}, {"exit_code": 127}),
])
def test_activity_widget_never_leaks_machinery_strings(tool, args, result):
    w = ActivityWidget(tool=tool, args=args, result=result)
    rendered = w.render()
    text = rendered.plain if hasattr(rendered, "plain") else str(rendered)
    for banned in ("tool_call", "function_call", "present_decision", "tool_calls"):
        assert banned not in text


from hyrin.ui.widgets import PlanReviewWidget


def test_plan_review_widget_renders_with_border_and_cta():
    content = "Items: records.\n\n• Add Cursor encoder\n• Wire controller\n\nDoes this work?"
    w = PlanReviewWidget(content=content)
    rendered = w.render()
    text = rendered.plain if hasattr(rendered, "plain") else str(rendered)
    assert "Plan" in text
    assert "Add Cursor encoder" in text
    assert "approve" in text.lower()


def test_plan_review_widget_collapses_when_approved():
    w = PlanReviewWidget(content="Plan body")
    w.mark_approved()
    rendered = w.render()
    text = rendered.plain if hasattr(rendered, "plain") else str(rendered)
    assert text.strip().startswith("Plan approved")
    assert "implementing" in text.lower()


from hyrin.ui.widgets import strip_phase_markers


def test_strip_phase_markers_removes_leading_plan():
    assert strip_phase_markers("## Plan\nbody") == "body"


def test_strip_phase_markers_removes_leading_implementing():
    assert strip_phase_markers("## Implementing\ndoing") == "doing"


def test_strip_phase_markers_leaves_non_leading_marker():
    text = "Some intro\n## Plan\nbody"
    assert strip_phase_markers(text) == text


def test_strip_phase_markers_handles_trailing_whitespace_on_marker_line():
    assert strip_phase_markers("## Plan   \nbody") == "body"


def test_strip_phase_markers_handles_empty_input():
    assert strip_phase_markers("") == ""
    assert strip_phase_markers(None) == ""
