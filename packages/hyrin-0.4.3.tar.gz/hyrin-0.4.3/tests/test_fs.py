import os
import pytest
from hyrin.tools.fs import (
    read_file, write_file, edit_file, list_directory,
    OldStrNotFoundError, OldStrAmbiguousError, MAX_READ_BYTES,
)


def test_write_then_read(tmp_path):
    summary = write_file(str(tmp_path), "a/b.txt", "hello\nworld\n")
    assert summary == "wrote 3 lines to a/b.txt"   # split on \n → 3 chunks
    assert read_file(str(tmp_path), "a/b.txt") == "hello\nworld\n"


def test_edit_file_replaces_single_occurrence(tmp_path):
    write_file(str(tmp_path), "x.txt", "hello world")
    summary = edit_file(str(tmp_path), "x.txt", "world", "there")
    assert summary == "edited x.txt"
    assert read_file(str(tmp_path), "x.txt") == "hello there"


def test_edit_file_raises_when_old_str_missing(tmp_path):
    write_file(str(tmp_path), "x.txt", "hello")
    with pytest.raises(OldStrNotFoundError):
        edit_file(str(tmp_path), "x.txt", "missing", "x")


def test_edit_file_raises_when_old_str_ambiguous(tmp_path):
    write_file(str(tmp_path), "x.txt", "ab ab ab")
    with pytest.raises(OldStrAmbiguousError) as info:
        edit_file(str(tmp_path), "x.txt", "ab", "X")
    assert "3" in str(info.value)


def test_list_directory_skips_hidden_sorts_marks_dirs(tmp_path):
    (tmp_path / "b.txt").write_text("")
    (tmp_path / "a").mkdir()
    (tmp_path / ".hidden").write_text("")
    out = list_directory(str(tmp_path), ".")
    assert out == "a/\nb.txt"


def test_read_file_truncates_oversized_input(tmp_path):
    big = "x" * (MAX_READ_BYTES + 1024)
    (tmp_path / "big.txt").write_text(big)
    out = read_file(str(tmp_path), "big.txt")
    assert "[file truncated" in out
    # The truncated body must be capped at MAX_READ_BYTES + a small marker.
    assert len(out) <= MAX_READ_BYTES + 100


def test_read_file_passes_through_small_input(tmp_path):
    (tmp_path / "small.txt").write_text("hello world")
    assert read_file(str(tmp_path), "small.txt") == "hello world"


def test_list_directory_skips_symlinks_pointing_outside_cwd(tmp_path):
    # Create cwd, an outside dir with a sentinel file, and a symlink in cwd.
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "secret").write_text("")
    cwd = tmp_path / "project"
    cwd.mkdir()
    (cwd / "real.txt").write_text("")
    os.symlink(str(outside), str(cwd / "link"))
    out = list_directory(str(cwd), ".")
    # The symlink pointing outside cwd must not appear in the listing.
    assert "link" not in out
    assert "real.txt" in out
