import asyncio
import json
import httpx
import pytest

from hyrin.client.activity import ActivityClient, ACTIVITY_QUEUE_MAX
from hyrin.client.types import ActivityEvent, ActivityType


def _make_event(seq: int) -> ActivityEvent:
    return ActivityEvent(
        seq=seq, timestamp="2026-04-16T00:00:00Z",
        type=ActivityType.FILE_READ,
        payload={"path": f"f-{seq}.txt", "line_count": 1, "size_bytes": 1},
    )


@pytest.mark.asyncio
async def test_activity_client_posts_each_event_with_bearer():
    received = []

    def handler(request):
        assert request.headers.get("Authorization") == "Bearer jwt"
        received.append(json.loads(request.content))
        return httpx.Response(204)

    http = httpx.AsyncClient(transport=httpx.MockTransport(handler), base_url="http://srv")
    client = ActivityClient(http, "jwt")
    await client.start()
    await client.enqueue(_make_event(1))
    await client.enqueue(_make_event(2))
    await client.flush()
    await client.stop()
    await http.aclose()

    assert [e["seq"] for e in received] == [1, 2]


@pytest.mark.asyncio
async def test_activity_client_drops_oldest_on_overflow():
    received = []

    async def slow_handler(request):
        await asyncio.sleep(0.05)
        received.append(json.loads(request.content)["seq"])
        return httpx.Response(204)

    http = httpx.AsyncClient(
        transport=httpx.MockTransport(lambda r: httpx.Response(204)),
        base_url="http://srv",
    )
    client = ActivityClient(http, "jwt")
    # Force enqueue beyond cap without starting the worker so we can observe
    # the drop-oldest policy directly.
    for s in range(ACTIVITY_QUEUE_MAX + 5):
        await client.enqueue(_make_event(s))
    seqs = client.snapshot_seqs()
    assert len(seqs) == ACTIVITY_QUEUE_MAX
    assert seqs[0] == 5     # first 5 dropped
    assert seqs[-1] == ACTIVITY_QUEUE_MAX + 4
    await http.aclose()


@pytest.mark.asyncio
async def test_activity_client_retries_on_transient_failure():
    attempts = {"n": 0}

    def handler(request):
        attempts["n"] += 1
        if attempts["n"] < 3:
            return httpx.Response(503)
        return httpx.Response(204)

    http = httpx.AsyncClient(transport=httpx.MockTransport(handler), base_url="http://srv")
    client = ActivityClient(http, "jwt", retry_initial=0.01, retry_max=0.05)
    await client.start()
    await client.enqueue(_make_event(1))
    await client.flush()
    await client.stop()
    await http.aclose()

    assert attempts["n"] == 3


import logging


@pytest.mark.asyncio
async def test_activity_overflow_emits_warn_with_dropped_count(caplog):
    """Each overflow drop emits a single WARN line whose message includes
    the count of drops in the last 60 seconds."""
    http = httpx.AsyncClient(
        transport=httpx.MockTransport(lambda r: httpx.Response(204)),
        base_url="http://srv",
    )
    client = ActivityClient(http, "jwt")

    # The `hyrin` parent logger sets propagate=False once app.py is
    # imported (file-handler bootstrap). Force propagation back on for
    # this test so caplog (root-level handler) actually sees the record.
    hyrin_logger = logging.getLogger("hyrin")
    prev_propagate = hyrin_logger.propagate
    hyrin_logger.propagate = True
    try:
        caplog.set_level(logging.WARNING, logger="hyrin.activity")
        for s in range(ACTIVITY_QUEUE_MAX + 3):
            await client.enqueue(_make_event(s))
    finally:
        hyrin_logger.propagate = prev_propagate
    await http.aclose()

    warns = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert len(warns) == 3, f"expected 3 drop warnings, got {len(warns)}: {warns!r}"
    # Each WARN line says how many drops have happened in the rolling
    # window so far (1, 2, 3).
    rolling_counts = [r.getMessage() for r in warns]
    assert any("dropped=1" in m for m in rolling_counts)
    assert any("dropped=2" in m for m in rolling_counts)
    assert any("dropped=3" in m for m in rolling_counts)
    # Format invariant: WARN includes 'overflow' so log scrapers can grep.
    assert all("overflow" in m for m in rolling_counts)


@pytest.mark.asyncio
async def test_activity_overflow_fires_notice_callback_once_at_threshold():
    """When >= OVERFLOW_NOTICE_THRESHOLD drops occur within the rolling
    window, the optional `on_overflow_notice` callback fires exactly
    once for the first crossing — subsequent drops in the same window
    don't re-fire it."""
    from hyrin.client.activity import OVERFLOW_NOTICE_THRESHOLD

    fired: list[int] = []
    http = httpx.AsyncClient(
        transport=httpx.MockTransport(lambda r: httpx.Response(204)),
        base_url="http://srv",
    )
    client = ActivityClient(
        http, "jwt",
        on_overflow_notice=lambda count: fired.append(count),
    )

    # Fill to capacity, then push (threshold + 5) more so we cross.
    for s in range(ACTIVITY_QUEUE_MAX + OVERFLOW_NOTICE_THRESHOLD + 5):
        await client.enqueue(_make_event(s))
    await http.aclose()

    # Callback should fire exactly once, at the first crossing.
    assert len(fired) == 1, f"expected exactly one notice, got {fired!r}"
    assert fired[0] >= OVERFLOW_NOTICE_THRESHOLD


@pytest.mark.asyncio
async def test_activity_overflow_window_expires(monkeypatch):
    """Drops outside the 60s rolling window don't count toward the
    threshold — old drops age out."""
    from hyrin.client import activity as activity_mod
    from hyrin.client.activity import OVERFLOW_NOTICE_THRESHOLD

    fake_now = {"t": 1000.0}

    def now() -> float:
        return fake_now["t"]

    monkeypatch.setattr(activity_mod, "_monotonic", now)

    fired: list[int] = []
    http = httpx.AsyncClient(
        transport=httpx.MockTransport(lambda r: httpx.Response(204)),
        base_url="http://srv",
    )
    client = ActivityClient(
        http, "jwt",
        on_overflow_notice=lambda count: fired.append(count),
    )

    # First burst: just below the threshold.
    for s in range(ACTIVITY_QUEUE_MAX + OVERFLOW_NOTICE_THRESHOLD - 1):
        await client.enqueue(_make_event(s))
    assert fired == []

    # Drain the queue so burst 2 starts from a known state (otherwise
    # burst 2's drops are dominated by the residual full queue from
    # burst 1 rather than the rolling-window aging behaviour we want
    # to exercise).
    client._queue.clear()

    # Advance past the rolling window (60s) and burst again. Threshold
    # has NOT been crossed within any single window, so still no notice.
    fake_now["t"] += 120.0
    for s in range(ACTIVITY_QUEUE_MAX + OVERFLOW_NOTICE_THRESHOLD - 1):
        await client.enqueue(_make_event(1000 + s))
    assert fired == [], f"old drops should have aged out; got {fired!r}"

    await http.aclose()
