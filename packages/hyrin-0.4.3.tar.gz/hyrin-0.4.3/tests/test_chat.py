import json

import pytest

from hyrin.client.chat import (
    parse_sse_lines, ChatEvent, ChatEventType,
)


def _frames(*lines: str) -> str:
    return "\n".join(lines) + "\n"


def test_parse_text_delta_emits_text_event():
    raw = _frames(
        'data: {"choices":[{"index":0,"delta":{"content":"Hello"},"finish_reason":null}]}',
        '',
        'data: [DONE]',
    )
    events = list(parse_sse_lines(raw.splitlines()))
    assert events == [ChatEvent(type=ChatEventType.TEXT, content="Hello")]


def test_parse_reasoning_delta_emits_reasoning_event():
    raw = _frames(
        'data: {"choices":[{"index":0,"delta":{"reasoning_content":"thinking"},"finish_reason":null}]}',
        'data: [DONE]',
    )
    events = list(parse_sse_lines(raw.splitlines()))
    assert events[0].type == ChatEventType.REASONING
    assert events[0].content == "thinking"


def test_parse_tool_call_delta_emits_tool_call_event():
    raw = _frames(
        'data: {"choices":[{"index":0,"delta":{"tool_calls":['
        '{"id":"c-1","type":"function","function":{"name":"read_file","arguments":"{}"}}]},'
        '"finish_reason":null}]}',
        'data: [DONE]',
    )
    events = list(parse_sse_lines(raw.splitlines()))
    assert events[0].type == ChatEventType.TOOL_CALL
    assert events[0].tool_call.id == "c-1"
    assert events[0].tool_call.function.name == "read_file"


def test_parse_finish_reason_emits_finish_event():
    raw = _frames(
        'data: {"choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}]}',
        'data: [DONE]',
    )
    events = list(parse_sse_lines(raw.splitlines()))
    assert events[0].type == ChatEventType.FINISH
    assert events[0].content == "tool_calls"


def test_parse_sse_lines_emits_system_notice_event():
    payload = json.dumps({"level": "warning", "text": "AI had trouble applying the code."})
    lines = [
        "event: system_notice",
        f"data: {payload}",
        "",
    ]
    events = list(parse_sse_lines(lines))
    assert len(events) == 1
    assert events[0].type is ChatEventType.SYSTEM_NOTICE
    assert events[0].content == "AI had trouble applying the code."
    # level rides on the existing `code` field of ChatEvent to avoid
    # widening the dataclass schema.
    assert events[0].code == "warning"


def test_parse_sse_lines_system_notice_defaults_missing_fields():
    lines = [
        "event: system_notice",
        "data: {}",
        "",
    ]
    events = list(parse_sse_lines(lines))
    assert len(events) == 1
    assert events[0].type is ChatEventType.SYSTEM_NOTICE
    assert events[0].content == ""
    assert events[0].code == "info"


def test_parse_event_error_emits_error_event_with_code():
    raw = _frames(
        'event: error',
        'data: {"code":"rate_limited","message":"too many"}',
        'data: [DONE]',
    )
    events = list(parse_sse_lines(raw.splitlines()))
    assert events[0].type == ChatEventType.ERROR
    assert events[0].code == "rate_limited"
    assert events[0].content == "too many"


def test_parse_skips_blank_lines_and_comments():
    raw = _frames(
        ': ping',
        '',
        'data: [DONE]',
    )
    assert list(parse_sse_lines(raw.splitlines())) == []


import httpx
from hyrin.client.chat import (
    stream_chat, ChatUnauthorizedError, ChatSessionGoneError,
)
from hyrin.client.types import ChatMessage


def _client(handler):
    return httpx.AsyncClient(transport=httpx.MockTransport(handler), base_url="http://srv")


@pytest.mark.asyncio
async def test_stream_chat_sends_bearer_and_streams_events():
    captured = {}

    def handler(request):
        captured["auth"] = request.headers.get("Authorization")
        captured["accept"] = request.headers.get("Accept")
        captured["body"] = json.loads(request.content)
        body = (
            'data: {"choices":[{"index":0,"delta":{"content":"hi"},"finish_reason":null}]}\n\n'
            'data: {"choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}\n\n'
            'data: [DONE]\n'
        )
        return httpx.Response(200, content=body, headers={"content-type": "text/event-stream"})

    msgs = [ChatMessage(role="user", content="hello")]
    async with _client(handler) as http:
        events = [ev async for ev in stream_chat(http, "jwt", msgs)]

    assert captured["auth"] == "Bearer jwt"
    assert captured["accept"] == "text/event-stream"
    assert captured["body"]["stream"] is True
    assert [e.type.value for e in events] == ["text", "finish"]


@pytest.mark.asyncio
@pytest.mark.parametrize("status, exc", [
    (401, ChatUnauthorizedError),
    (410, ChatSessionGoneError),
])
async def test_stream_chat_status_code_errors(status, exc):
    def handler(_):
        return httpx.Response(status, text="")

    async with _client(handler) as http:
        with pytest.raises(exc):
            async for _ in stream_chat(http, "jwt", [ChatMessage(role="user", content="x")]):
                pass


from hyrin.client.chat import stream_chat_with_retry, ChatInterrupted


@pytest.mark.asyncio
async def test_stream_chat_with_retry_recovers_on_first_failure():
    calls = {"n": 0}

    def handler(request):
        calls["n"] += 1
        if calls["n"] == 1:
            # First attempt: drop mid-stream after one chunk.
            body = ('data: {"choices":[{"index":0,"delta":{"content":"hi"},"finish_reason":null}]}\n\n')
            return httpx.Response(200, content=body, headers={"content-type": "text/event-stream"})
        # Second attempt: clean stream.
        body = (
            'data: {"choices":[{"index":0,"delta":{"content":"hello"},"finish_reason":null}]}\n\n'
            'data: {"choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}\n\n'
            'data: [DONE]\n'
        )
        return httpx.Response(200, content=body, headers={"content-type": "text/event-stream"})

    msgs = [ChatMessage(role="user", content="hi")]
    async with _client(handler) as http:
        events = [ev async for ev in stream_chat_with_retry(http, "jwt", msgs)]

    assert calls["n"] == 2
    # First-attempt partial output is discarded; we yield only the successful retry.
    assert [e.content for e in events if e.type == ChatEventType.TEXT] == ["hello"]


@pytest.mark.asyncio
async def test_stream_chat_with_retry_surfaces_after_second_failure():
    def handler(_):
        # Always drop with no DONE — caller's read times out.
        body = 'data: {"choices":[{"index":0,"delta":{"content":"x"},"finish_reason":null}]}\n\n'
        return httpx.Response(200, content=body, headers={"content-type": "text/event-stream"})

    msgs = [ChatMessage(role="user", content="hi")]
    async with _client(handler) as http:
        with pytest.raises(ChatInterrupted) as info:
            async for _ in stream_chat_with_retry(http, "jwt", msgs):
                pass
        assert info.value.partial_text  # the partial text from the second attempt is preserved


@pytest.mark.asyncio
async def test_stream_chat_with_retry_treats_transient_connect_error_as_retryable():
    """A transient httpx.ConnectError on either attempt must NOT surface as
    ChatInterrupted — that exception is reserved for true mid-stream cutoffs
    (server opened the SSE response, then dropped). A connect error means
    the request never started, so the partial-text contract makes no sense."""
    calls = {"n": 0}

    def handler(request):
        calls["n"] += 1
        if calls["n"] == 1:
            # Transient: simulate a connect error before headers.
            raise httpx.ConnectError("dial tcp: connection refused", request=request)
        # Second attempt: clean stream.
        body = (
            'data: {"choices":[{"index":0,"delta":{"content":"ok"},"finish_reason":null}]}\n\n'
            'data: {"choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}\n\n'
            'data: [DONE]\n'
        )
        return httpx.Response(200, content=body, headers={"content-type": "text/event-stream"})

    msgs = [ChatMessage(role="user", content="hi")]
    async with _client(handler) as http:
        events = [ev async for ev in stream_chat_with_retry(http, "jwt", msgs)]

    assert calls["n"] == 2
    text_events = [e.content for e in events if e.type == ChatEventType.TEXT]
    assert text_events == ["ok"]


@pytest.mark.asyncio
async def test_stream_chat_with_retry_transient_connect_error_on_both_attempts_raises_chat_error_not_interrupted():
    """When BOTH attempts fail with a transient connect error (i.e. the
    request never started either time), we have no partial text to preserve.
    Raise the underlying httpx error rather than fabricating a ChatInterrupted
    with empty partial — empty-partial ChatInterrupted is a misleading UX."""
    def handler(request):
        raise httpx.ConnectError("dial tcp: connection refused", request=request)

    msgs = [ChatMessage(role="user", content="hi")]
    async with _client(handler) as http:
        with pytest.raises(httpx.ConnectError):
            async for _ in stream_chat_with_retry(http, "jwt", msgs):
                pass


@pytest.mark.asyncio
async def test_stream_chat_with_retry_mid_stream_cutoff_still_raises_chat_interrupted():
    """Regression guard: a true mid-stream cutoff (server opens the
    response and then drops) must still raise ChatInterrupted with the
    partial text. This is the existing contract from row 7.3 — we are
    only narrowing it, not removing it."""
    def handler(_):
        body = 'data: {"choices":[{"index":0,"delta":{"content":"par"},"finish_reason":null}]}\n\n'
        return httpx.Response(200, content=body, headers={"content-type": "text/event-stream"})

    msgs = [ChatMessage(role="user", content="hi")]
    async with _client(handler) as http:
        with pytest.raises(ChatInterrupted) as info:
            async for _ in stream_chat_with_retry(http, "jwt", msgs):
                pass
        assert info.value.partial_text == "par"
