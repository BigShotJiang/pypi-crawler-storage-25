"""Layout density regression tests.

These pin down that widgets in #chat-log render at their natural content
height — not stretched to fill available space. A subtle `Widget` default
leaves `height` unset, which causes the widget to expand to whatever
vertical room is left in the `VerticalScroll`. The symptom is a huge
vertical gap between successive chat-log entries (activity widgets
ballooning, notice banners ballooning, etc.).
"""
import pytest

from hyrin.app import (
    HyrinApp, PairCompleted,
    StreamStarted, StreamChunkReceived, StreamFinished,
)
from hyrin.client.types import PairResponse, WorkspaceInfo, SessionInfo
from hyrin.config import Config
from hyrin.ui.widgets import (
    MessageWidget, ActivityWidget, PlanReviewWidget, SystemNoticeWidget,
)
from textual.containers import VerticalScroll


def _paired_app():
    app = HyrinApp(
        Config(code="abc", cwd="/tmp"),
        _skip_worker=True,
    )
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )
    return app, fake


@pytest.mark.asyncio
async def test_activity_widget_natural_height_is_one_line():
    """One ActivityWidget in an otherwise empty chat-log must render at its
    content size (1 row) — not fill the whole scroll area."""
    app, fake = _paired_app()
    async with app.run_test(size=(80, 30)) as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        log = app.query_one("#chat-log", VerticalScroll)
        aw = ActivityWidget(
            tool="list_directory", args={"path": "."}, result={},
        )
        log.mount(aw)
        await pilot.pause()
        assert aw.size.height == 1, (
            f"ActivityWidget should size to its 1-line render, got "
            f"height={aw.size.height}. This means the widget is stretching "
            f"to fill available space — set `height: auto` in DEFAULT_CSS."
        )


@pytest.mark.asyncio
async def test_tool_only_turn_total_height_is_compact():
    """Real sequence: user msg → tool-only turn (activity) → final prose.
    The three widgets together should consume at most a handful of rows,
    not the entire chat-log viewport."""
    app, fake = _paired_app()
    async with app.run_test(size=(80, 30)) as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        log = app.query_one("#chat-log", VerticalScroll)
        log.mount(MessageWidget(role="user", content="list files"))
        await pilot.pause()
        # Tool-only assistant turn: StreamStarted → Activity mounted → StreamFinished
        app.post_message(StreamStarted())
        await pilot.pause()
        aw = ActivityWidget(
            tool="list_directory", args={"path": "."}, result={},
        )
        log.mount(aw)
        await pilot.pause()
        app.post_message(StreamFinished(reason="tool_calls"))
        await pilot.pause()
        # Follow-up assistant prose
        app.post_message(StreamStarted())
        await pilot.pause()
        app.post_message(StreamChunkReceived("4 files."))
        await pilot.pause()
        app.post_message(StreamFinished(reason="stop"))
        await pilot.pause()

        kids = list(log.children)
        # Exactly three widgets: user msg, activity, assistant msg.
        # (Ghost pending assistant MessageWidget must be cleaned up.)
        assert len(kids) == 3, (
            f"expected 3 widgets, got {len(kids)}: "
            f"{[type(c).__name__ for c in kids]}"
        )
        # Each widget should be compact — the activity widget in particular
        # must not fill the whole chat-log viewport.
        heights = [c.size.height for c in kids]
        assert all(h <= 3 for h in heights), (
            f"Each widget should be at most a few rows tall, got {heights}. "
            f"A widget ballooning means its CSS lacks `height: auto`."
        )


@pytest.mark.asyncio
async def test_system_notice_widget_natural_height():
    """A single-line system notice must not fill available space."""
    from hyrin.app import SystemNoticePosted

    app, fake = _paired_app()
    async with app.run_test(size=(80, 30)) as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        app.post_message(SystemNoticePosted(level="warning", text="short notice"))
        await pilot.pause()
        notices = [
            w for w in app.query(SystemNoticeWidget).results()
            if "short notice" in (w.renderable or "")
        ]
        assert len(notices) == 1
        # border: tall adds 2 rows, padding: 0 1 horizontal, content: 1 row
        # → at most 3 rows. The bug would give ~20+.
        assert notices[0].size.height <= 3, (
            f"SystemNoticeWidget should be ~3 rows, got {notices[0].size.height}"
        )


@pytest.mark.asyncio
async def test_plan_review_widget_natural_height():
    """PlanReviewWidget should size to its content + border, not stretch."""
    app, fake = _paired_app()
    async with app.run_test(size=(80, 40)) as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        log = app.query_one("#chat-log", VerticalScroll)
        p = PlanReviewWidget(content="Step 1.")
        log.mount(p)
        await pilot.pause()
        # Render is 5 lines: "Plan", "", content, "", approve-CTA → with
        # `padding: 1 2` and `border: round` that's at most ~9 rows. The bug
        # would stretch it to fill the whole chat-log.
        assert p.size.height <= 10, (
            f"PlanReviewWidget should size to content, got {p.size.height}"
        )
