import json
import httpx
import pytest

from hyrin.client.pair import (
    pair, InvalidCodeError, AlreadyClaimedError, SessionGoneError,
    ServerError,
)


def _client(handler):
    transport = httpx.MockTransport(handler)
    return httpx.AsyncClient(transport=transport, base_url="http://srv")


@pytest.mark.asyncio
async def test_pair_success_returns_response():
    captured = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["body"] = json.loads(request.content)
        return httpx.Response(200, json={
            "cable_url": "ws://srv/cable",
            "session_token": "jwt-x",
            "workspace": {"name": "Acme"},
            "session": {"id": 7, "state": "in_progress"},
            "messages": [],
        })

    async with _client(handler) as http:
        resp = await pair(http, "abcdef")

    assert captured["url"].endswith("/api/v1/sessions/pair")
    assert captured["body"] == {"code": "ABCDEF"}  # uppercased
    assert resp.session_token == "jwt-x"


@pytest.mark.asyncio
@pytest.mark.parametrize("status, exc", [
    (401, InvalidCodeError), (404, InvalidCodeError),
    (409, AlreadyClaimedError), (410, SessionGoneError),
])
async def test_pair_error_status_maps_to_exception(status, exc):
    def handler(_):
        return httpx.Response(status, json={})

    async with _client(handler) as http:
        with pytest.raises(exc):
            await pair(http, "abcdef")


@pytest.mark.asyncio
async def test_pair_other_status_is_server_error():
    def handler(_):
        return httpx.Response(503, text="boom")

    async with _client(handler) as http:
        with pytest.raises(ServerError) as info:
            await pair(http, "abcdef")
        assert "503" in str(info.value)
