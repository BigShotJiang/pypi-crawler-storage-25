import pytest

from hyrin.cli import parse_args


def test_parse_args_uppercases_code_and_uses_defaults():
    cfg = parse_args(["abcdef"])
    assert cfg.code == "ABCDEF"


def test_parse_args_missing_code_raises_systemexit():
    # argparse exits with code 2 when a required positional is missing.
    with pytest.raises(SystemExit):
        parse_args([])


def test_parse_args_supports_cwd():
    cfg = parse_args(["xyz", "--cwd", "/tmp"])
    assert cfg.code == "XYZ"
    assert cfg.cwd == "/tmp"


def test_parse_args_does_not_accept_server_flag():
    # --server has been removed; argparse treats it as unknown.
    with pytest.raises(SystemExit):
        parse_args(["xyz", "--server", "https://example.com"])


def test_parse_args_does_not_accept_debug_flag():
    # --debug has been removed; argparse treats it as unknown.
    with pytest.raises(SystemExit):
        parse_args(["xyz", "--debug"])
