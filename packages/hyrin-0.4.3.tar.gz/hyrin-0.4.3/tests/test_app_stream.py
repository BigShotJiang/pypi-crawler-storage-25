import pytest

from hyrin.app import (
    HyrinApp, AppState, PairCompleted,
    StreamStarted, StreamChunkReceived, StreamFinished,
)
from hyrin.client.types import PairResponse, WorkspaceInfo, SessionInfo
from hyrin.config import Config
from hyrin.ui.widgets import MessageWidget, ActivityWidget, SystemNoticeWidget


def _paired_app():
    app = HyrinApp(
        Config(code="abc", cwd="/tmp"),
        _skip_worker=True,
    )
    fake = PairResponse(
        cable_url="ws://srv/cable", session_token="jwt",
        workspace=WorkspaceInfo(name="Acme"),
        session=SessionInfo(id=1, state="in_progress"),
    )
    return app, fake


@pytest.mark.asyncio
async def test_tool_only_turn_removes_pending_widget():
    app, fake = _paired_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        app.post_message(StreamStarted())
        await pilot.pause()
        # No chunks — simulate a pure tool-call turn.
        app.post_message(StreamFinished(reason="tool_calls"))
        await pilot.pause()
        assistants = [
            w for w in app.query(MessageWidget).results()
            if getattr(w, "role", None) == "assistant"
        ]
        assert assistants == [], f"expected no assistant widgets, got {assistants!r}"


@pytest.mark.asyncio
async def test_prose_then_tool_call_keeps_message_widget():
    app, fake = _paired_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        app.post_message(StreamStarted())
        await pilot.pause()
        app.post_message(StreamChunkReceived("Let's sketch this out."))
        await pilot.pause()
        app.post_message(StreamFinished(reason="tool_calls"))
        await pilot.pause()
        assistants = [
            w for w in app.query(MessageWidget).results()
            if getattr(w, "role", None) == "assistant"
        ]
        assert len(assistants) == 1
        assert not assistants[0]._pending


@pytest.mark.asyncio
async def test_system_notice_event_mounts_widget():
    from hyrin.app import SystemNoticePosted

    app, fake = _paired_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()

        app.post_message(SystemNoticePosted(
            level="warning",
            text="AI had trouble applying the code.",
        ))
        await pilot.pause()

        notices = [
            w for w in app.query(SystemNoticeWidget).results()
            if "AI had trouble applying the code." in (w.renderable or "")
        ]
        assert len(notices) == 1, (
            f"expected exactly one system-notice widget, got {len(notices)}"
        )
        # A warning-level notice is NOT an error banner — the candidate can
        # keep pairing; no red styling.
        assert "error" not in notices[0].classes


@pytest.mark.asyncio
async def test_system_notice_error_level_renders_as_error_banner():
    from hyrin.app import SystemNoticePosted

    app, fake = _paired_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()

        app.post_message(SystemNoticePosted(level="error", text="boom"))
        await pilot.pause()

        notices = [
            w for w in app.query(SystemNoticeWidget).results()
            if "boom" in (w.renderable or "")
        ]
        assert len(notices) == 1
        assert "error" in notices[0].classes


@pytest.mark.asyncio
async def test_drift_failed_finish_is_clean_exit():
    app, fake = _paired_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()

        # Pretend we were streaming — mirror on_stream_started's side effects
        # without needing the full worker to drive us.
        app.streaming = True
        app.post_message(StreamFinished(reason="drift_failed"))
        await pilot.pause()

        # Clean reset: streaming flag clears, state stays ACTIVE, and no
        # error banner gets mounted (the paired system_notice already
        # carries the user-facing copy).
        assert app.streaming is False
        assert app.state is AppState.ACTIVE
        error_banners = [
            w for w in app.query(SystemNoticeWidget).results()
            if "error" in w.classes
        ]
        assert error_banners == [], (
            f"drift_failed must not mount an error banner, got {error_banners!r}"
        )


@pytest.mark.asyncio
async def test_mid_stream_empty_chunk_does_not_reshow_spinner():
    app, fake = _paired_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=fake))
        await pilot.pause()
        app.post_message(StreamStarted())
        await pilot.pause()
        app.post_message(StreamChunkReceived("hello"))
        await pilot.pause()
        w = app._current_assistant
        assert w is not None and not w._pending
        app.post_message(StreamChunkReceived(""))
        await pilot.pause()
        assert not w._pending
        app.post_message(StreamChunkReceived(" world"))
        await pilot.pause()
        # Buffer ownership moved to HyrinApp (CLI-2); the widget no longer
        # carries `_buffer` — read from app._assistant_buffer instead.
        assert app._assistant_buffer == "hello world"
        assert not w._pending
