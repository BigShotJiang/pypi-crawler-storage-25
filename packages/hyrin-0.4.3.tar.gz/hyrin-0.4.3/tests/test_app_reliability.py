"""Reliability-focused tests for HyrinApp wiring (Batch CLI-B).

Covers:
- `_ensure_http` lifecycle: single client per app, recreated only on close.
- `_refetch_question_after_advance`: HTTP error vs validation error split.
- Cable-event handler offload: heavy work runs on a background task.
"""
from __future__ import annotations

import asyncio

import httpx
import pytest

from hyrin.app import HyrinApp
from hyrin.config import Config


def _cfg() -> Config:
    # Minimal config; cwd doesn't matter — no FS is touched in these tests.
    return Config(code="ABCD1234", cwd="/tmp")


@pytest.mark.asyncio
async def test_ensure_http_returns_same_client_across_calls():
    """Single AsyncClient per app: calling `_ensure_http` repeatedly must
    return the same instance. Retries inside `_chat_worker` would otherwise
    leak file descriptors and reset connection pools per attempt."""
    app = HyrinApp(_cfg(), _skip_worker=True)
    try:
        first = await app._ensure_http()
        second = await app._ensure_http()
        third = await app._ensure_http()
        assert first is second is third
        assert isinstance(first, httpx.AsyncClient)
    finally:
        await app._close_http_chat()


@pytest.mark.asyncio
async def test_ensure_http_recreates_after_explicit_close():
    """Once explicitly closed (e.g. on shutdown failure mid-restart),
    `_ensure_http` must produce a fresh, usable client. This exercises the
    invariant that close + ensure is idempotent and safe to repeat."""
    app = HyrinApp(_cfg(), _skip_worker=True)
    first = await app._ensure_http()
    await app._close_http_chat()
    assert app._http_chat is None
    second = await app._ensure_http()
    try:
        assert second is not first
        assert isinstance(second, httpx.AsyncClient)
    finally:
        await app._close_http_chat()


import json
from pydantic import ValidationError


class _StubMessageBus:
    """Captures system-notice texts pushed to the chat log so we can assert
    on the exact copy a candidate would see, without spinning a Textual
    pilot just for two notices."""

    def __init__(self):
        self.notices: list[str] = []

    def append(self, text: str) -> None:
        self.notices.append(text)


def _install_notice_capture(app: HyrinApp, bus: _StubMessageBus) -> None:
    """Replace `_apply_question_advanced` and the chat-log query path with
    no-ops that record the failure-branch notice into `bus`. We can't mount
    a real chat-log without driving the Textual pilot, so we monkeypatch
    the two methods that actually push the notice."""
    def _post_notice(text: str) -> None:
        bus.append(text)

    app._post_refetch_failure_notice = _post_notice  # implementation hook


@pytest.mark.asyncio
async def test_refetch_question_network_error_shows_network_copy(monkeypatch):
    """When pair_client.pair raises an httpx.HTTPError, the candidate sees
    the network-retry copy. Server-down vs malformed-JSON must NOT collapse
    into the same generic message — the actions are different."""
    app = HyrinApp(_cfg(), _skip_worker=True)
    bus = _StubMessageBus()
    _install_notice_capture(app, bus)

    async def fake_pair(http, code):
        raise httpx.ConnectError("connection refused", request=httpx.Request("GET", "http://srv"))

    monkeypatch.setattr("hyrin.client.pair.pair", fake_pair)
    await app._refetch_question_after_advance()
    assert any("network" in n.lower() or "try again" in n.lower() for n in bus.notices)
    assert not any("contact support" in n.lower() for n in bus.notices)


@pytest.mark.asyncio
async def test_refetch_question_validation_error_shows_data_copy(monkeypatch):
    """A Pydantic ValidationError indicates a server-shape regression; the
    candidate cannot self-heal, so the copy must say "contact support".
    The same generic-network copy would mask a real bug."""
    app = HyrinApp(_cfg(), _skip_worker=True)
    bus = _StubMessageBus()
    _install_notice_capture(app, bus)

    async def fake_pair(http, code):
        # Force a real ValidationError by feeding bad data into the model.
        from hyrin.client.types import PairResponse
        return PairResponse.model_validate({"session_token": 123})  # wrong type → raises

    monkeypatch.setattr("hyrin.client.pair.pair", fake_pair)
    await app._refetch_question_after_advance()
    assert any("contact support" in n.lower() or "data" in n.lower() for n in bus.notices)


@pytest.mark.asyncio
async def test_refetch_question_unexpected_error_propagates(monkeypatch):
    """A bare RuntimeError is not a known failure mode — bubbling means
    Textual's worker logger surfaces it. Silently swallowing would hide
    real bugs (e.g. a typo introduced in `_apply_question_advanced`)."""
    app = HyrinApp(_cfg(), _skip_worker=True)
    bus = _StubMessageBus()
    _install_notice_capture(app, bus)

    async def fake_pair(http, code):
        raise RuntimeError("unexpected")

    monkeypatch.setattr("hyrin.client.pair.pair", fake_pair)
    with pytest.raises(RuntimeError):
        await app._refetch_question_after_advance()


from hyrin.app import CableEventReceived


@pytest.mark.asyncio
async def test_on_cable_event_received_offloads_heavy_phase_changed(monkeypatch):
    """The main message handler must not run heavy widget mutations
    inline — heavy work belongs on a background task so the chat worker
    keeps draining its stream during a phase transition. Assert the
    handler RETURNS within a tiny budget after we send a phase_changed
    event, even when the heavy handler is artificially slow."""
    app = HyrinApp(_cfg(), _skip_worker=True)

    handler_started = asyncio.Event()
    handler_done = asyncio.Event()

    async def slow_heavy(event_type, payload):
        handler_started.set()
        await asyncio.sleep(0.2)  # simulate heavy widget mounts
        handler_done.set()

    monkeypatch.setattr(app, "_handle_cable_event_heavy", slow_heavy)

    msg = CableEventReceived(
        event_type="phase_changed",
        payload={"from": "clarifying", "to": "deciding",
                 "decisions_completed": 0, "decisions_total": 3},
        seq=42,
    )

    loop = asyncio.get_running_loop()
    t0 = loop.time()
    app.on_cable_event_received(msg)
    elapsed = loop.time() - t0
    # Synchronous handler must return within 50ms even though the heavy
    # path takes 200ms — that's the whole point of the offload.
    assert elapsed < 0.05, f"handler blocked for {elapsed:.3f}s"

    # The background task must actually run (and finish).
    await asyncio.wait_for(handler_started.wait(), timeout=1.0)
    await asyncio.wait_for(handler_done.wait(), timeout=1.0)


@pytest.mark.asyncio
async def test_on_cable_event_received_inline_for_gap_event():
    """Lightweight events (gap → triggers GapDetected) stay on the main
    handler — they are a single post_message and offloading would be pure
    overhead. Verify the heavy hook is NOT invoked for `gap`."""
    app = HyrinApp(_cfg(), _skip_worker=True)
    heavy_calls = []

    async def fake_heavy(event_type, payload):
        heavy_calls.append(event_type)

    app._handle_cable_event_heavy = fake_heavy

    posted: list = []
    app.post_message = lambda m: posted.append(m)  # type: ignore[assignment]

    msg = CableEventReceived(event_type="gap", payload={}, seq=1)
    app.on_cable_event_received(msg)
    # Give the loop a turn in case anything slipped onto the task queue.
    await asyncio.sleep(0)
    assert heavy_calls == []
    assert any(type(p).__name__ == "GapDetected" for p in posted)
