import asyncio
import json

import pytest
from aiohttp import web, WSMsgType

from hyrin.app import HyrinApp, AppState
from hyrin.config import Config


@pytest.mark.asyncio
async def test_e2e_pair_chat_tool_completes(tmp_path, monkeypatch):
    activity_records: list[dict] = []
    server_port = 0  # set after site.start()

    (tmp_path / "main.py").write_text("print('hi')\n")

    async def pair_handler(request):
        return web.json_response({
            "cable_url": f"ws://127.0.0.1:{server_port}/cable",
            "session_token": "jwt",
            "workspace": {"name": "Acme"},
            "session": {"id": 1, "state": "in_progress"},
            "messages": [],
        })

    async def chat_handler(request):
        body = await request.json()
        last = body["messages"][-1]
        if last["role"] == "user":
            stream = (
                'data: {"choices":[{"index":0,"delta":{"tool_calls":'
                '[{"id":"c1","type":"function","function":'
                '{"name":"read_file","arguments":"{\\"path\\":\\"main.py\\"}"}}]}'
                ',"finish_reason":null}]}\n\n'
                'data: {"choices":[{"index":0,"delta":{},"finish_reason":"tool_calls"}]}\n\n'
                'data: [DONE]\n'
            )
        elif last["role"] == "tool":
            stream = (
                'data: {"choices":[{"index":0,"delta":{"content":"got it"},'
                '"finish_reason":null}]}\n\n'
                'data: {"choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}\n\n'
                'data: [DONE]\n'
            )
        else:
            stream = 'data: [DONE]\n'
        return web.Response(text=stream, content_type="text/event-stream")

    async def activity_handler(request):
        activity_records.append(await request.json())
        return web.Response(status=204)

    async def cable_handler(request):
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        await ws.send_json({"type": "welcome"})
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                data = json.loads(msg.data)
                if data.get("command") == "subscribe":
                    await ws.send_json({"type": "confirm_subscription"})
        return ws

    app = web.Application()
    app.router.add_post("/api/v1/sessions/pair", pair_handler)
    app.router.add_post("/api/v1/chat/completions", chat_handler)
    app.router.add_post("/api/v1/sessions/activity", activity_handler)
    app.router.add_get("/cable", cable_handler)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    server_port = site._server.sockets[0].getsockname()[1]

    # Override SERVER_URL for this test
    monkeypatch.setattr("hyrin.app.SERVER_URL", f"http://127.0.0.1:{server_port}")

    try:
        cli_app = HyrinApp(Config(
            code="abc", cwd=str(tmp_path),
        ))
        async with cli_app.run_test() as pilot:
            for _ in range(50):
                if cli_app.state is AppState.ACTIVE:
                    break
                await pilot.pause()
            assert cli_app.state is AppState.ACTIVE

            await pilot.press("h", "i", "enter")
            # Buffer ownership moved to HyrinApp (CLI-2). After stream
            # finishes, the assistant text lives in _chat_history (the
            # in-flight buffer is cleared on stream_finished).
            for _ in range(80):
                await pilot.pause()
                if any("got it" in (m.content or "")
                       for m in cli_app._chat_history if m.role == "assistant"):
                    break
            assert any("got it" in (m.content or "")
                       for m in cli_app._chat_history if m.role == "assistant")

        assert any(r["type"] == "file_read" and r["payload"]["path"] == "main.py"
                   for r in activity_records)
    finally:
        await runner.cleanup()
