import pytest
from textual.widgets import Static

from hyrin.app import HyrinApp, CableEventReceived, PairCompleted
from hyrin.client.types import PhaseChangedEvent, PairResponse, WorkspaceInfo, SessionInfo
from hyrin.config import Config

_FAKE_PAIR = PairResponse(
    cable_url="ws://srv/cable",
    session_token="jwt",
    workspace=WorkspaceInfo(name="Acme"),
    session=SessionInfo(id=1, state="in_progress"),
)


def _make_app() -> HyrinApp:
    return HyrinApp(
        Config(code="ABCD1234", cwd="/tmp"),
        _skip_worker=True,
    )


@pytest.mark.asyncio
async def test_phase_chip_initial_render():
    """Phase chip is present on mount with the placeholder dash."""
    app = _make_app()
    async with app.run_test() as pilot:
        await pilot.pause()
        chip = app.query_one("#phase-chip", Static)
        assert "—" in chip.content


@pytest.mark.asyncio
async def test_phase_chip_updates_on_phase_changed_event():
    """A phase_changed cable event updates the chip label to the new phase."""
    app = _make_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_FAKE_PAIR))
        await pilot.pause()

        app.post_message(CableEventReceived(
            event_type="phase_changed",
            payload={"to": "clarifying", "from": None, "question_id": 1},
            seq=1,
        ))
        await pilot.pause()

        chip = app.query_one("#phase-chip", Static)
        assert "Clarifying" in chip.content


@pytest.mark.asyncio
async def test_phase_chip_shows_progress_during_deciding():
    """When phase is 'deciding' with totals, chip shows 'Decisions (n/m)' format."""
    app = _make_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_FAKE_PAIR))
        await pilot.pause()

        app.post_message(CableEventReceived(
            event_type="phase_changed",
            payload={
                "to": "deciding",
                "from": "clarifying",
                "question_id": 1,
                "decisions_completed": 1,
                "decisions_total": 3,
            },
            seq=2,
        ))
        await pilot.pause()

        chip = app.query_one("#phase-chip", Static)
        assert "Decisions (1/3)" in chip.content


@pytest.mark.asyncio
async def test_phase_chip_shows_all_known_phases():
    """Verify each known phase label renders correctly."""
    known_phases = {
        "clarifying": "Clarifying",
        "awaiting_approval": "Reviewing plan",
        "implementing": "Implementing",
        "done": "Done",
    }
    for phase, expected_label in known_phases.items():
        app = _make_app()
        async with app.run_test() as pilot:
            app.post_message(PairCompleted(response=_FAKE_PAIR))
            await pilot.pause()

            app.post_message(CableEventReceived(
                event_type="phase_changed",
                payload={"to": phase, "from": None},
                seq=1,
            ))
            await pilot.pause()

            chip = app.query_one("#phase-chip", Static)
            assert expected_label in chip.content, (
                f"phase={phase!r}: expected {expected_label!r} in {chip.content!r}"
            )


@pytest.mark.asyncio
async def test_phase_chip_unknown_phase_falls_back_to_title_case():
    """An unrecognised phase name renders in title-case."""
    app = _make_app()
    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_FAKE_PAIR))
        await pilot.pause()

        app.post_message(CableEventReceived(
            event_type="phase_changed",
            payload={"to": "some_new_phase", "from": None},
            seq=1,
        ))
        await pilot.pause()

        chip = app.query_one("#phase-chip", Static)
        assert "Some_New_Phase" in chip.content


def test_phase_changed_event_dataclass():
    """PhaseChangedEvent is frozen and correctly constructed."""
    ev = PhaseChangedEvent(
        to_phase="deciding",
        from_phase="clarifying",
        question_id=7,
        decisions_completed=2,
        decisions_total=4,
    )
    assert ev.to_phase == "deciding"
    assert ev.from_phase == "clarifying"
    assert ev.question_id == 7
    assert ev.decisions_completed == 2
    assert ev.decisions_total == 4
    # frozen — must raise on mutation attempt
    with pytest.raises((AttributeError, TypeError)):
        ev.to_phase = "implementing"  # type: ignore[misc]
