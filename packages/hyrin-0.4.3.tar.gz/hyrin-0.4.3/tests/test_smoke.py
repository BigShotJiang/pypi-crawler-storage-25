def test_package_imports():
    import hyrin
    import hyrin.cli
    import hyrin.config
    import hyrin.app
    from hyrin.client import pair, cable, chat, activity, types  # noqa: F401
    from hyrin.tools import fs, exec, registry, safety            # noqa: F401
    from hyrin.ui import theme, widgets                           # noqa: F401
    assert hyrin.__version__
