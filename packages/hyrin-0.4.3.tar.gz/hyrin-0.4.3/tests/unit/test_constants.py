"""Phase-label parity: the chip and the status bar must render identical
text for every key in the canonical PHASE_LABELS map. Regression guard
for CLI-13 — previously two separate dicts drifted (chip said
'Reviewing plan', status bar said 'Your turn' for the same phase)."""
from __future__ import annotations

import pytest
from textual.widgets import Static

from hyrin.app import (
    CableEventReceived, CableStatusChanged, HyrinApp, PairCompleted,
)
from hyrin.client.types import PairResponse, SessionInfo, WorkspaceInfo
from hyrin.config import Config
from hyrin.constants import PHASE_LABELS


_FAKE_PAIR = PairResponse(
    cable_url="ws://srv/cable",
    session_token="jwt",
    workspace=WorkspaceInfo(name="Acme"),
    session=SessionInfo(id=1, state="in_progress"),
)


def _make_app() -> HyrinApp:
    return HyrinApp(
        Config(code="ABCD1234", cwd="/tmp"),
        _skip_worker=True,
    )


def test_phase_labels_is_a_frozen_mapping_of_str_to_str():
    """PHASE_LABELS exists, is non-empty, and only maps str → str."""
    assert isinstance(PHASE_LABELS, dict)
    assert PHASE_LABELS, "PHASE_LABELS must not be empty"
    for k, v in PHASE_LABELS.items():
        assert isinstance(k, str) and isinstance(v, str)
        assert k and v, "no empty keys or values"


def test_phase_labels_covers_every_known_phase():
    """The five phases the cable layer can emit must each have a label."""
    expected_phases = {
        "clarifying", "deciding", "awaiting_approval", "implementing", "done",
    }
    assert expected_phases.issubset(PHASE_LABELS.keys())


@pytest.mark.asyncio
@pytest.mark.parametrize("phase", sorted({
    "clarifying", "deciding", "awaiting_approval", "implementing", "done",
}))
async def test_chip_and_status_bar_use_identical_label(phase: str):
    """For every PHASE_LABELS key the chip text and status-bar text agree
    on the human-facing label. Status bar suppresses the 'done' suffix
    (existing behaviour); test only asserts the prefix match for non-done
    phases. The chip always renders the label."""
    app = _make_app()
    expected_label = PHASE_LABELS[phase]

    async with app.run_test() as pilot:
        app.post_message(PairCompleted(response=_FAKE_PAIR))
        await pilot.pause()
        app.post_message(CableStatusChanged(connected=True))
        await pilot.pause()
        # Use a payload that does NOT include decisions_total so 'deciding'
        # falls through to the plain label rather than 'Decisions (n/m)'.
        app.post_message(CableEventReceived(
            event_type="phase_changed",
            payload={"to": phase, "from": None, "question_id": 1},
            seq=1,
        ))
        await pilot.pause()

        chip = app.query_one("#phase-chip", Static)
        assert expected_label in chip.content, (
            f"chip missing {expected_label!r} for phase={phase!r}: "
            f"chip.content={chip.content!r}"
        )

        if phase != "done":
            bar = app.query_one("#status-bar", Static)
            bar_text = bar.render().plain
            assert expected_label in bar_text, (
                f"status bar missing {expected_label!r} for phase={phase!r}: "
                f"bar={bar_text!r}"
            )
