#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
C++ 代码规范检查工具 - 启动脚本

用法：
1. 在 Windows 上：双击 run.bat 或运行 python run.py
2. 在 Linux/Mac 上：运行 chmod +x run.sh && ./run.sh 或 python run.py

此脚本确保：
- 在离线环境下运行（不需要 pip 安装依赖）
- 自动处理 Python 路径
- 提供 Windows 中文编码支持
"""

import sys
import os

# 添加项目根目录到 Python 路径
script_dir = os.path.dirname(os.path.abspath(__file__))
if script_dir not in sys.path:
    sys.path.insert(0, script_dir)

# 添加 code_checker 目录到 Python 路径
code_checker_dir = os.path.join(script_dir, 'code_checker')
if code_checker_dir not in sys.path:
    sys.path.insert(0, code_checker_dir)

# Windows 编码设置
if sys.platform == 'win32':
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleOutputCP(65001)  # UTF-8
        kernel32.SetConsoleCP(65001)
    except:
        pass

    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except:
        import io
        try:
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
            sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        except:
            pass

# 显示欢迎信息
print("=" * 60)
print("C++ 代码规范检查工具 v1.0")
print("=" * 60)
print()

# 导入并运行主程序
try:
    from cpp_checker import main
    main()
except ImportError as e:
    print(f"错误：无法导入模块 - {e}")
    print("请确保在项目根目录运行此脚本")
    print("目录结构应为：")
    print("  - run.py (当前脚本)")
    print("  - code_checker/")
    print("    - config/")
    print()
    sys.exit(1)
except KeyboardInterrupt:
    print("\n\n用户中断程序")
    sys.exit(0)
except Exception as e:
    print(f"\n错误：{e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
