#!/bin/bash

# C++ 代码规范检查工具启动脚本（Linux/Mac）

echo "正在启动 C++ 代码规范检查工具..."
echo ""

# 检查 Python 是否已安装
if ! command -v python3 &> /dev/null
then
    if ! command -v python &> /dev/null
    then
        echo "错误：未检测到 Python 环境"
        echo "请先安装 Python 3.8 或更高版本"
        exit 1
    else
        python run.py "$@"
    fi
else
    python3 run.py "$@"
fi
