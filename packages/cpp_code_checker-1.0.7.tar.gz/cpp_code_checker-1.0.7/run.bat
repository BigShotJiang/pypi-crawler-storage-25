@echo off
chcp 65001 >nul 2>&1
echo 正在启动 C++ 代码规范检查工具...
echo.

REM 检查 Python 是否已安装
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo 错误：未检测到 Python 环境
    echo 请先安装 Python 3.8 或更高版本
    echo 下载地址：https://www.python.org/downloads/
    pause
    exit /b 1
)

REM 运行 Python 脚本
python run.py %*

REM 如果出错，暂停以便用户查看
if %errorlevel% neq 0 (
    echo.
    echo 程序异常退出，请查看上方错误信息
    pause
)
