#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os

# Windows 编码设置
if sys.platform == 'win32':
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleOutputCP(65001)  # UTF-8
        kernel32.SetConsoleCP(65001)
    except:
        pass

    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except:
        import io
        try:
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
            sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        except:
            pass

# 显示欢迎信息
print("=" * 60)
print("C++ 代码规范检查工具 v1.0")
print("=" * 60)
print()

# 导入并运行主程序
try:
    from .cpp_checker import main
    main()
except ImportError as e:
    print(f"错误：无法导入模块 - {e}")
    print("请确保在项目根目录运行此脚本")
    print("目录结构应为：")
    print("  - run.py (当前脚本)")
    print("  - code_checker/")
    print("  - config/")
    print()
    sys.exit(1)
except KeyboardInterrupt:
    print("\n\n用户中断程序")
    sys.exit(0)
except Exception as e:
    print(f"\n错误：{e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
