#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Indentation rule - check for excessive empty lines
"""

import os
import re
from typing import Dict, Any, List
from code_checker.base import BaseRule


class IndentationRule(BaseRule):
    """Indentation rule - max 2 consecutive empty lines"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)

    def check(self, file_path: str, content: str, lines: list) -> List[str]:
        """
        Check indentation (excessive empty lines)

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of warning messages
        """
        warnings = []

        # Track current function context
        in_function = False
        current_function = ""
        brace_count = 0

        empty_lines = 0
        for i, line in enumerate(lines, 1):
            # Try to extract function name when entering a new function
            if '{' in line and not in_function:
                func_match = re.search(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)\s*{', line)
                if func_match:
                    current_function = func_match.group(1)

            # Track brace count to know when we're inside a function
            if '{' in line:
                brace_count += line.count('{')
                if not in_function:
                    in_function = True

            if '}' in line:
                brace_count -= line.count('}')
                if brace_count == 0 and in_function:
                    in_function = False
                    current_function = ""

            # Check for excessive empty lines
            if not line.strip():
                empty_lines += 1
                if empty_lines > 2:
                    # Determine whitelist key
                    if in_function and current_function:
                        # Inside a function, use function name
                        whitelist_key = current_function
                        location_info = f"函数 '{current_function}'"
                    else:
                        # Not in function (global scope), use filename:line
                        whitelist_key = f"{os.path.basename(file_path)}:{i}"
                        location_info = whitelist_key

                    # Check if in whitelist
                    if whitelist_key not in self.whitelist["indentation"]:
                        warnings.append(
                            f"[代码格式][indentation] 第 {i} 行: 连续空行过多 [{location_info}]"
                        )
                    else:
                        self.whitelist_filtered_count += 1
                    empty_lines = 0
            else:
                empty_lines = 0

        return warnings
