#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Brackets rule - check bracket placement style
"""

import re
from typing import Dict, Any, List
from code_checker.base import BaseRule


class BracketsRule(BaseRule):
    """Brackets rule - check for proper bracket placement"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)
        self.style = config["code_style"]["brackets"]["style"]  # "new_line" or "same_line"

    def check(self, file_path: str, content: str, lines: list) -> List[str]:
        """
        Check bracket placement style

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of warning messages
        """
        warnings = []

        # Track current function context
        in_function = False
        current_function = ""
        brace_count = 0

        # Track current enum/struct/class context
        in_enum = False
        in_struct = False
        in_class = False
        current_context_name = ""

        for i, line in enumerate(lines, 1):
            # Try to extract function name when entering a new function
            if '{' in line and not in_function:
                func_match = re.search(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)\s*{', line)
                if func_match:
                    current_function = func_match.group(1)

            # Try to extract enum/struct/class name
            if '{' in line:
                # Check for enum
                enum_match = re.search(r'\benum\s+(?:class\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*{', line)
                if enum_match:
                    in_enum = True
                    current_context_name = enum_match.group(1)
                else:
                    # Check for struct
                    struct_match = re.search(r'\bstruct\s+([A-Za-z_][A-Za-z0-9_]*)\s*{', line)
                    if struct_match:
                        in_struct = True
                        current_context_name = struct_match.group(1)
                    else:
                        # Check for class
                        class_match = re.search(r'\bclass\s+([A-Za-z_][A-Za-z0-9_]*)\s*{', line)
                        if class_match:
                            in_class = True
                            current_context_name = class_match.group(1)

            # Track brace count to know when we're inside a function
            if '{' in line:
                brace_count += line.count('{')
                if not in_function:
                    in_function = True

            if '}' in line:
                brace_count -= line.count('}')
                if brace_count == 0:
                    if in_enum or in_struct or in_class:
                        in_enum = False
                        in_struct = False
                        in_class = False
                        current_context_name = ""
                    if in_function:
                        in_function = False
                        current_function = ""

            # Check for opening brace placement
            if '{' in line:
                # Remove comment to get clean line
                clean_line = line.split('//')[0].strip()

                # Find opening brace
                brace_pos = clean_line.find('{')

                if brace_pos != -1:
                    # Determine whitelist key
                    if in_function and current_function:
                        # Inside a function, use function name
                        whitelist_key = current_function
                        location_info = f"函数 '{current_function}'"
                    elif in_enum or in_struct or in_class:
                        # Inside enum/struct/class, use the name
                        whitelist_key = current_context_name
                        location_info = f"{current_context_name}"
                    else:
                        # Not in function or enum/struct/class, use filename:line
                        whitelist_key = f"{file_path.split('/')[-1]}:{i}"
                        location_info = whitelist_key

                    # Check bracket style
                    if self.style == "new_line":
                        # Opening brace should be on a new line
                        # Allow: ")\n{" or ")\n    {"
                        if brace_pos > 0 and not clean_line.endswith('{'):
                            # Brace is not at the end of line, which is fine for new_line style
                            pass
                        else:
                            # Brace is at the end of line or only brace on line
                            # For new_line style, brace should be on its own line
                            if brace_pos > 0 and clean_line.endswith('{'):
                                # Brace on same line - violation
                                if whitelist_key not in self.whitelist["brackets"]:
                                    warnings.append(
                                        f"[代码格式][brackets] 第 {i} 行: 左大括号应在新行 [{location_info}]"
                                    )
                                else:
                                    self.whitelist_filtered_count += 1
                    elif self.style == "same_line":
                        # Opening brace should be on the same line
                        if brace_pos > 0 and not clean_line.endswith('{'):
                            # Brace not at end of line - check if there's content after it
                            if brace_pos < len(clean_line) - 1:
                                # Content after brace - violation
                                if whitelist_key not in self.whitelist["brackets"]:
                                    warnings.append(
                                        f"[代码格式][brackets] 第 {i} 行: 左大括号应与声明在同一行 [{location_info}]"
                                    )
                                else:
                                    self.whitelist_filtered_count += 1

        return warnings
