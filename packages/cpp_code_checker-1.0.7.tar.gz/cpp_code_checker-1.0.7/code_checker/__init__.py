#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
C++ Code Checker Package
用于 PyPI 发布的包入口
"""

import os
import json
import importlib.resources
from typing import Dict, Any, Optional

__all__ = ['get_resource_path', 'load_resource_json']


def get_resource_path(resource_name: str) -> str:
    """
    获取配置文件资源的路径

    支持以下场景：
    1. pip 安装后的包内资源
    2. run.py 直接运行的本地文件
    3. VSCode 插件的使用

    Args:
        resource_name: 资源文件名（如 "config/coding_standards.json"）

    Returns:
        资源文件的绝对路径
    """
    # 方案1：尝试使用 importlib.resources（适用于 pip 安装的包）
    try:
        # Python 3.9+
        # 注意：files() 返回的对象不支持 with 语句，需要直接使用
        base_path = importlib.resources.files("code_checker")
        resource_path = base_path / resource_name
        if resource_path.is_file():
            # 对于打包后的资源，需要使用 as_file 来获取实际路径
            try:
                with importlib.resources.as_file(resource_path) as file_path:
                    return str(file_path)
            except (AttributeError, OSError):
                # 如果 as_file 不支持或失败，直接返回路径
                return str(resource_path)
    except (AttributeError, FileNotFoundError, ImportError):
        pass

    # 方案2：回退到传统的文件路径方式（适用于开发环境和 run.py）
    # 获取 code_checker 包的目录
    code_checker_dir = os.path.dirname(os.path.abspath(__file__))
    resource_path = os.path.join(code_checker_dir, resource_name)

    if os.path.exists(resource_path):
        return resource_path

    # 方案3：尝试从项目根目录的 config 目录加载（向后兼容）
    project_root = os.path.dirname(code_checker_dir)
    fallback_path = os.path.join(project_root, resource_name)

    if os.path.exists(fallback_path):
        return fallback_path

    # 如果都找不到，返回一个路径（调用方需要处理文件不存在的情况）
    return resource_path


def load_resource_json(resource_name: str) -> Optional[Dict[str, Any]]:
    """
    加载 JSON 配置文件资源

    Args:
        resource_name: 资源文件名（如 "config/coding_standards.json"）

    Returns:
        配置字典，如果文件不存在返回 None
    """
    resource_path = get_resource_path(resource_name)

    if os.path.exists(resource_path):
        try:
            with open(resource_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return None

    return None


def main():
    """主函数入口，用于 PyPI 安装后的命令行调用"""
    from .cpp_checker import main as _main
    _main()
