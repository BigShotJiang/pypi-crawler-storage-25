#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
No extern rule
"""

import re
from typing import Dict, Any, List
from code_checker.base import BaseRule


class NoExternRule(BaseRule):
    """No extern rule - prohibit using extern for global variables or functions"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)

    def check(self, file_path: str, content: str, lines: list) -> List[str]:
        """
        Check if extern is used

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of suggestion messages
        """
        suggestions = []

        # Match extern declarations: extern type [modifiers] identifier [;|=|...]
        # Must be on the same line as extern
        # Examples:
        #   extern int g_var1;
        #   extern char* g_ptr;
        #   extern void someFunction();
        #   extern float var1, var2;
        extern_pattern = re.compile(r'extern\s+(?:[^\n]+\s+)*\b([a-zA-Z_]\w*)\s*[;=\(]')

        for line_num, line in enumerate(lines, 1):
            # Skip empty lines
            if not line.strip():
                continue

            # Skip comment lines
            stripped_line = line.strip()
            if stripped_line.startswith('//'):
                continue

            # Remove inline comments
            clean_line = line.split('//')[0].strip()

            # Check if line contains extern
            if 'extern' not in clean_line:
                continue

            # Try to match extern declaration
            match = extern_pattern.search(clean_line)
            if match:
                identifier = match.group(1)

                # Check if in whitelist (use identifier name)
                if identifier not in self.whitelist["no_extern"]:
                    suggestions.append(
                        f"[最佳实践][no_extern] 第 {line_num} 行: 禁止使用 extern 引用全局变量或函数 '{identifier}'，应使用头文件声明"
                    )
                else:
                    self.whitelist_filtered_count += 1

        return suggestions
