#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Cyclomatic complexity rule
"""

import re
from typing import Dict, Any, List
from code_checker.base import BaseRule


class CyclomaticComplexityRule(BaseRule):
    """Cyclomatic complexity rule - max 10"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)

    def check(self, file_path: str, content: str, lines: list) -> List[str]:
        """
        Check cyclomatic complexity (simplified version - estimated by nesting level)

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of suggestion messages
        """
        suggestions = []

        in_function = False
        function_start = 0
        function_name = ""  # Simple name (last part after ::)
        full_function_name = ""  # Full name including scope (e.g., ClassName::functionName)
        complexity = 0
        brace_count = 0
        max_complexity = self.config["best_practices"]["cyclomatic_complexity"]["max_complexity"]
        full_func_name = ""  # Initialize for function name extraction

        for i, line in enumerate(lines, 1):
            # Try to extract function name (supports C++ member functions: ClassName::functionName)
            if '{' in line and not in_function:
                # Match patterns like:
                # - simpleFunction()
                # - ClassName::memberFunction()
                # - Namespace::ClassName::memberFunction()
                # - int simpleFunction()
                # - void ClassName::memberFunction()
                # - std::string Namespace::ClassName::memberFunction()
                
                # Strategy: find the function name by looking for the pattern just before parameters
                # First, find the position of the last '(' before '{'
                paren_pos = line.rfind('(')
                if paren_pos != -1 and line.find('{', paren_pos) != -1:
                    # Extract the part before '('
                    before_paren = line[:paren_pos].strip()

                    # Now extract the function name from this part
                    # Split by whitespace and look for the last token that contains the function name
                    # The function name is typically the last non-void token
                    tokens = before_paren.split()

                    # Skip return type keywords and operators
                    skip_keywords = {'int', 'float', 'double', 'char', 'void', 'bool', 'unsigned', 'signed', 'long', 'short', 'const', 'static', '*', '&'}

                    # Try to find the function name (should be the last token or contain ::)
                    for token in reversed(tokens):
                        if not token:  # Skip empty tokens
                            continue
                        if token in skip_keywords:
                            continue
                        if '::' in token or ((token[0].isalpha() or token[0] == '_') and token):
                            full_func_name = token
                            break

                    # Extract just the function name (last part after ::)
                    if full_func_name:
                        # Remove template parameters if present
                        full_func_name = re.sub(r'<[^>]+>', '', full_func_name)

                        parts = full_func_name.split('::')
                        function_name = parts[-1].strip()

                        # Store the full function name (including scope)
                        full_function_name = full_func_name.strip()

            # Calculate complexity (if, for, while, switch, case, catch, &&, ||)
            complexity_keywords = ['if', 'for', 'while', 'switch', 'case', 'catch', '&&', '||']
            if in_function:
                for keyword in complexity_keywords:
                    complexity += line.count(keyword)

            if '{' in line:
                brace_count += line.count('{')
                if not in_function:
                    # Only treat as function start if we found a function name
                    if function_name or full_function_name:
                        in_function = True
                        function_start = i
                        complexity = 1  # Base complexity

            if '}' in line:
                brace_count -= line.count('}')
                if brace_count == 0 and in_function:
                    if complexity > max_complexity:
                        # Check if in whitelist (try full name first, then simple name)
                        in_whitelist = False
                        if full_function_name in self.whitelist["cyclomatic_complexity"]:
                            in_whitelist = True
                        elif function_name in self.whitelist["cyclomatic_complexity"]:
                            in_whitelist = True
                        
                        if not in_whitelist:
                            # Use full name if available, otherwise use simple name
                            display_name = full_function_name if full_function_name else function_name
                            suggestions.append(
                                f"[最佳实践][cyclomatic_complexity] 第 {function_start} 行开始的函数 '{display_name}' 圈复杂度过高（{complexity}），建议简化"
                            )
                        else:
                            self.whitelist_filtered_count += 1
                    in_function = False

        return suggestions
