#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Function length rule
"""

import re
from typing import Dict, Any, List
from code_checker.base import BaseRule


class FunctionLengthRule(BaseRule):
    """Function length rule - max 100 lines"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)

    def check(self, file_path: str, content: str, lines: list) -> List[str]:
        """
        Check function length

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of suggestion messages
        """
        suggestions = []

        in_function = False
        function_start = 0
        function_name = ""
        brace_count = 0
        max_length = self.config["best_practices"]["function_length"]["max_length"]

        for i, line in enumerate(lines, 1):
            # Try to extract function name
            if '{' in line and not in_function:
                func_match = re.search(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)\s*{', line)
                if func_match:
                    function_name = func_match.group(1)

            if '{' in line:
                brace_count += line.count('{')
                if not in_function:
                    in_function = True
                    function_start = i

            if '}' in line:
                brace_count -= line.count('}')
                if brace_count == 0 and in_function:
                    function_length = i - function_start
                    if function_length > max_length:
                        # Check if in whitelist
                        if function_name not in self.whitelist["function_length"]:
                            suggestions.append(
                                f"[最佳实践][function_length] 第 {function_start} 行开始的函数 '{function_name}' 过长（{function_length} 行），建议拆分"
                            )
                        else:
                            self.whitelist_filtered_count += 1
                    in_function = False

        return suggestions
