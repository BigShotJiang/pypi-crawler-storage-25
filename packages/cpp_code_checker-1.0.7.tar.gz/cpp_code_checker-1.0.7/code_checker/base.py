#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Base utilities and default configurations for C++ Code Checker
"""

import sys
from typing import Dict, Any, List
from dataclasses import dataclass


class Colors:
    """Terminal color output"""
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

    @staticmethod
    def disable():
        """Disable color output"""
        Colors.HEADER = ''
        Colors.OKBLUE = ''
        Colors.OKCYAN = ''
        Colors.OKGREEN = ''
        Colors.WARNING = ''
        Colors.FAIL = ''
        Colors.ENDC = ''
        Colors.BOLD = ''
        Colors.UNDERLINE = ''


@dataclass
class Violation:
    """
    违规项数据类，统一返回格式，确保校验和白名单生成使用相同逻辑

    Attributes:
        rule_type: 规则类型，如 'class_struct_and_union_name', 'function' 等
        line_number: 违规所在的行号
        identifier: 标识符名称，用于白名单匹配
        message: 错误消息描述
        details: 额外细节信息（可选）
    """
    rule_type: str
    line_number: int
    identifier: str
    message: str
    details: str = ""


# Detect Windows and disable colors
if sys.platform == 'win32':
    try:
        import colorama
        colorama.init()
    except ImportError:
        Colors.disable()


# Default coding standards configuration
DEFAULT_CODING_STANDARDS: Dict[str, Any] = {
    "naming_conventions": {
        "class_struct_and_union_name": {
            "pattern": r"^[A-Z][a-zA-Z0-9]*$",
            "description": "类名、结构体名和联合体名使用帕斯卡命名法（PascalCase）"
        },
        "function": {
            "pattern": r"^[A-Z][A-Z0-9_]*[A-Z][a-zA-Z0-9]*$",
            "description": "普通函数名使用帕斯卡命名法（PascalCase），可以加全大写前缀"
        },
        "member_function": {
            "pattern": r"^[a-z][a-zA-Z0-9_]*$",
            "description": "类和结构体的成员函数使用驼峰命名法"
        },
        "parameter": {
            "pattern": r"^[a-z][a-zA-Z0-9_]*$",
            "description": "函数参数使用驼峰命名法"
        },
        "local_variable": {
            "pattern": r"^[a-z][a-zA-Z0-9_]*$",
            "description": "局部变量使用驼峰命名法"
        },
        "global_variable": {
            "pattern": r"^g_[a-z][a-zA-Z0-9_]*$",
            "description": "全局变量使用g_前缀+驼峰命名法"
        },
        "static_global_variable": {
            "pattern": r"^s_[a-z][a-zA-Z0-9_]*$",
            "description": "静态全局变量使用s_前缀+驼峰命名法"
        },
        "macro": {
            "pattern": r"^[A-Z][A-Z0-9_]*$",
            "description": "宏定义使用全大写下划线分隔"
        },
        "file_name": {
            "pattern": r"^[a-z][a-z0-9_]*$",
            "description": "源文件和头文件名使用全小写下划线分隔"
        },
        "constant": {
            "pattern": r"^c[A-Z][a-zA-Z0-9]*$",
            "description": "常量名使用c前缀+帕斯卡命名法（cPascalCase）"
        },
        "enum_type": {
            "pattern": r"^[A-Z][a-zA-Z0-9]*$",
            "description": "枚举类型使用帕斯卡命名法（PascalCase）"
        }
    },
    "code_style": {
        "indentation": {
            "size": 4,
            "description": "使用4个空格缩进"
        },
        "line_length": {
            "max_length": 120,
            "description": "每行不超过120个字符"
        }
    },
    "best_practices": {
        "function_length": {
            "max_lines": 100,
            "description": "单个函数不超过100行"
        },
        "cyclomatic_complexity": {
            "max_complexity": 10,
            "description": "圈复杂度不超过10"
        },
        "no_extern": {
            "description": "禁止使用extern引用全局变量或函数"
        }
    }
}


# Base rule class for all check rules
class BaseRule:
    """Base class for all check rules"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        """
        Initialize rule

        Args:
            config: Configuration dictionary
            whitelist: Whitelist dictionary
        """
        self.config = config
        self.whitelist = whitelist
        self.whitelist_filtered_count = 0

    def check(self, file_path: str, content: str, lines: list) -> List[Violation]:
        """
        Check the rule

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of Violation objects
        """
        raise NotImplementedError("Subclasses must implement check method")

    def get_filtered_count(self) -> int:
        """Get the count of whitelist filtered items"""
        return self.whitelist_filtered_count
