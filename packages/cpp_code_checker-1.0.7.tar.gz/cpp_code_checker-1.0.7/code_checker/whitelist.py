#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Whitelist manager for C++ Code Checker
"""

import os
import json
from typing import Dict, List, Optional


class WhitelistManager:
    """Load and manage whitelist"""

    @staticmethod
    def load_whitelist(whitelist_path: Optional[str] = None) -> Dict[str, List[str]]:
        """
        Load whitelist file

        Args:
            whitelist_path: Path to whitelist file (optional)

        Returns:
            Whitelist dictionary
        """
        whitelist = {
            "class_struct_and_union_name": [],
            "enum_type": [],
            "enum_value": [],
            "function": [],
            "member_function": [],
            "parameter": [],
            "local_variable": [],
            "constant": [],
            "class_member_variable": [],
            "struct_member_variable": [],
            "global_variable": [],
            "static_global_variable": [],
            "macro": [],
            "file_name": [],
            "indentation": [],
            "line_length": [],
            "function_length": [],
            "cyclomatic_complexity": [],
            "no_extern": []
        }

        if whitelist_path and os.path.exists(whitelist_path):
            try:
                with open(whitelist_path, 'r', encoding='utf-8') as f:
                    loaded_whitelist = json.load(f)
                    # Merge loaded whitelist with default whitelist
                    for key, value in loaded_whitelist.items():
                        if key in whitelist:
                            whitelist[key] = value
            except (json.JSONDecodeError, IOError) as e:
                print(f"警告：加载白名单文件失败: {e}")

        return whitelist

    @staticmethod
    def create_default_whitelist() -> Dict[str, List[str]]:
        """
        Create default whitelist with common exceptions

        Returns:
            Default whitelist dictionary
        """
        return {
            "class_struct_and_union_name": [],
            "enum_type": [],
            "enum_value": [],
            "function": ["main"],
            "member_function": [],
            "parameter": [],
            "local_variable": [],
            "constant": [],
            "class_member_variable": [],
            "struct_member_variable": [],
            "global_variable": [],
            "static_global_variable": [],
            "macro": [],
            "file_name": [],
            "indentation": [],
            "line_length": [],
            "function_length": [],
            "cyclomatic_complexity": [],
            "no_extern": []
        }
