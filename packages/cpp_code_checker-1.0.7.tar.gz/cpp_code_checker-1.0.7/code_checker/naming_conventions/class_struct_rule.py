#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Class, struct and union naming rule
"""

import re
from typing import Dict, Any, List
from code_checker.base import BaseRule, Violation


class ClassStructRule(BaseRule):
    """Class, struct and union naming rule - PascalCase"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)

    def check(self, file_path: str, content: str, lines: list) -> List[Violation]:
        """
        Check class, struct and union naming convention

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of Violation objects
        """
        errors = []

        # First, find all typedef struct/union ranges to avoid duplicate checking
        # Note: typedef enum is handled by enum_rule.py, so we skip it here
        typedef_ranges = []

        # Find all typedef keyword positions
        typedef_keyword_pattern = re.compile(r'\btypedef\b')
        for typedef_match in typedef_keyword_pattern.finditer(content):
            typedef_pos = typedef_match.start()

            # Get content after typedef (up to next 100 characters)
            after_typedef = content[typedef_pos + 7:typedef_pos + 100]
            # Remove all whitespace
            after_typedef_no_ws = re.sub(r'\s+', '', after_typedef)

            # Check if this is followed by struct/union (without whitespace)
            # Skip enum as it's handled by enum_rule.py
            if not after_typedef_no_ws.startswith('struct') and not after_typedef_no_ws.startswith('union'):
                continue

            # Find the opening brace
            open_brace_pos = content.find('{', typedef_pos)
            if open_brace_pos == -1:
                continue

            # Find matching closing brace
            brace_count = 1
            i = open_brace_pos + 1
            while i < len(content) and brace_count > 0:
                if content[i] == '{':
                    brace_count += 1
                elif content[i] == '}':
                    brace_count -= 1
                i += 1

            if brace_count == 0:
                # Found matching brace, find the semicolon
                semicolon_pos = content.find(';', i)
                if semicolon_pos != -1:
                    typedef_ranges.append({
                        'start': typedef_pos,
                        'end': semicolon_pos + 1,
                        'close_brace': i - 1
                    })

        # Check if a position is within any typedef range
        def is_in_typedef(pos):
            for r in typedef_ranges:
                if r['start'] <= pos < r['end']:
                    return True
            return False

        # Check typedef names (after closing brace)
        # For typedef definitions (typedef struct/union { ... } Name),
        # we only check the name after }, not the internal name after struct/union keyword
        # Note: typedef enum is handled by enum_rule.py, so we skip it here
        # For each typedef range, extract the name after the closing brace
        checked_typedef_positions = set()  # Track which typedef positions have been checked
        for r in typedef_ranges:
            # Skip if we've already processed a typedef with the same close_brace position
            if r['close_brace'] in checked_typedef_positions:
                continue
            checked_typedef_positions.add(r['close_brace'])

            # Find the content between closing brace and semicolon
            after_brace = content[r['close_brace'] + 1:r['end'] - 1].strip()

            # Get the naming pattern from config
            naming_pattern = self.config["naming_conventions"]["class_struct_and_union_name"]["pattern"]

            # Extract names (handle multiple names separated by commas, and pointer types with *)
            names = []
            for name in after_brace.split(','):
                name = name.strip()
                # Remove * for pointer types
                name = name.lstrip('*')
                if name:
                    names.append(name)

            # Check typedef names (only the name after })
            for type_name in names:
                if not re.match(naming_pattern, type_name):
                    # Not conforming to convention
                    if type_name not in self.whitelist["class_struct_and_union_name"]:
                        # Not in whitelist, add error
                        line_num = content[:r['close_brace']].count('\n') + 1
                        errors.append(
                            Violation(
                                rule_type="class_struct_and_union_name",
                                line_number=line_num,
                                identifier=type_name,
                                message=f"typedef类型名 '{type_name}' 不符合规范（应使用帕斯卡命名法）"
                            )
                        )
                    else:
                        # In whitelist, increase filter count
                        self.whitelist_filtered_count += 1

        # Check regular (non-typedef) class, struct, and union definitions
        # Note: enum is handled by enum_rule.py, so we skip it here
        # Match class, struct, and union definitions (skip those inside typedef)
        pattern = re.compile(r'\b(class|struct|union)\s+([A-Za-z_][A-Za-z0-9_]*)\b')
        for match in pattern.finditer(content):
            # Skip if this is inside a typedef definition
            if is_in_typedef(match.start()):
                continue

            struct_type = match.group(1)  # 'class', 'struct' or 'union'
            type_name = match.group(2)

            # Get the naming pattern from config
            naming_pattern = self.config["naming_conventions"]["class_struct_and_union_name"]["pattern"]

            if not re.match(naming_pattern, type_name):
                # Not conforming to convention
                if type_name not in self.whitelist["class_struct_and_union_name"]:
                    # Not in whitelist, add error
                    line_num = content[:match.start()].count('\n') + 1
                    errors.append(
                        Violation(
                            rule_type="class_struct_and_union_name",
                            line_number=line_num,
                            identifier=type_name,
                            message=f"{struct_type}名 '{type_name}' 不符合规范（应使用帕斯卡命名法）"
                        )
                    )
                else:
                    # In whitelist, increase filter count
                    self.whitelist_filtered_count += 1

        return errors
