#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Macro naming rule
"""

import re
from typing import Dict, Any, List
from code_checker.base import BaseRule, Violation


class MacroRule(BaseRule):
    """Macro naming rule - UPPERCASE with underscores"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)

    def check(self, file_path: str, content: str, lines: list) -> List[Violation]:
        """
        Check macro naming convention

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of Violation objects
        """
        errors = []

        # Match #define MACRO_NAME or #define MACRO_NAME(...)
        macro_pattern = re.compile(r'#\s*define\s+([A-Za-z_][A-Za-z0-9_]*)')
        for match in macro_pattern.finditer(content):
            macro_name = match.group(1)

            # Exclude special macros (like conditional compilation)
            exclude_macros = ["if", "ifdef", "ifndef", "else", "elif", "endif",
                             "defined", "include", "pragma", "line", "error", "warning"]
            if macro_name in exclude_macros:
                continue

            # Check macro naming convention
            pattern = self.config["naming_conventions"]["macro"]["pattern"]
            if not re.match(pattern, macro_name):
                # Not conforming to convention
                if macro_name not in self.whitelist["macro"]:
                    # Not in whitelist, add error
                    line_num = content[:match.start()].count('\n') + 1
                    errors.append(
                        f"[命名规范][macro] 第 {line_num} 行: 宏定义 '{macro_name}' 不符合规范（应使用全大写下划线分隔，如 MAX_SIZE）"
                    )
                else:
                    # In whitelist, increase filter count
                    self.whitelist_filtered_count += 1

        return errors
