#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
File name naming rule
"""

import re
from typing import Dict, Any, List
from code_checker.base import BaseRule, Violation


class FileNameRule(BaseRule):
    """File name naming rule - lowercase with underscores"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)

    def check(self, file_path: str, content: str, lines: list) -> List[Violation]:
        """
        Check file name convention

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of Violation objects
        """
        errors = []

        # Only check .cpp, .h, .c files
        import os
        filename = os.path.basename(file_path)
        filename_lower = filename.lower()

        if filename_lower.endswith(('.cpp', '.h', '.c')):
            # Extract filename without extension
            name_without_ext = os.path.splitext(filename)[0]

            if name_without_ext:  # Ensure filename is not empty
                pattern = self.config["naming_conventions"]["file_name"]["pattern"]
                if not re.match(pattern, name_without_ext):
                    # Not conforming to convention
                    if name_without_ext not in self.whitelist["file_name"]:
                        # Not in whitelist, add error
                        errors.append(
                            f"[命名规范][file_name] 文件名 '{filename}' 不符合规范（应使用全小写下划线分隔，如 my_file.cpp）"
                        )
                    else:
                        # In whitelist, increase filter count
                        self.whitelist_filtered_count += 1

        return errors
