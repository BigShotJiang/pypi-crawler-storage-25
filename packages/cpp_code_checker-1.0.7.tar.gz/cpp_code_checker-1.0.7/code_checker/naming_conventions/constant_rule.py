#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Constant naming rule
"""

import re
from typing import Dict, Any, List
from code_checker.base import BaseRule, Violation


class ConstantRule(BaseRule):
    """Constant naming rule - cPascalCase"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)

    def check(self, file_path: str, content: str, lines: list) -> List[Violation]:
        """
        Check constant naming convention

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of Violation objects
        """
        errors = []

        # Check const constants
        const_pattern = re.compile(r'\bconst\s+\w+\s+([A-Za-z_][A-Za-z0-9_]*)\s*[=;]')
        for match in const_pattern.finditer(content):
            const_name = match.group(1)

            # Exclude const references and pointers (like const Config& config)
            if not const_name.endswith('&') and not const_name.endswith('*'):
                # Check constant naming convention
                pattern = self.config["naming_conventions"]["constant"]["pattern"]
                if not re.match(pattern, const_name):
                    # Not conforming to convention
                    if const_name not in self.whitelist["constant"]:
                        # Not in whitelist, add error
                        line_num = content[:match.start()].count('\n') + 1
                        errors.append(
                            Violation(
                                rule_type="constant",
                                line_number=line_num,
                                identifier=const_name,
                                message=f"常量名 '{const_name}' 不符合规范（应使用c前缀+帕斯卡命名法，如 cMaxBufferSize）"
                            )
                        )
                    else:
                        # In whitelist, increase filter count
                        self.whitelist_filtered_count += 1

        # Check static const constants
        static_const_pattern = re.compile(r'\bstatic\s+const\s+\w+\s+([A-Za-z_][A-Za-z0-9_]*)\s*[=;]')
        for match in static_const_pattern.finditer(content):
            const_name = match.group(1)

            # Exclude const references and pointers
            if not const_name.endswith('&') and not const_name.endswith('*'):
                # Check constant naming convention
                pattern = self.config["naming_conventions"]["constant"]["pattern"]
                if not re.match(pattern, const_name):
                    # Not conforming to convention
                    if const_name not in self.whitelist["constant"]:
                        # Not in whitelist, add error
                        line_num = content[:match.start()].count('\n') + 1
                        errors.append(
                            Violation(
                                rule_type="constant",
                                line_number=line_num,
                                identifier=const_name,
                                message=f"常量名 '{const_name}' 不符合规范（应使用c前缀+帕斯卡命名法，如 cMaxBufferSize）"
                            )
                        )
                    else:
                        # In whitelist, increase filter count
                        self.whitelist_filtered_count += 1

        # Check static constexpr constants
        static_constexpr_pattern = re.compile(r'\bstatic\s+constexpr\s+\w+\s+([A-Za-z_][A-Za-z0-9_]*)\s*[=;]')
        for match in static_constexpr_pattern.finditer(content):
            const_name = match.group(1)

            # Check constant naming convention
            pattern = self.config["naming_conventions"]["constant"]["pattern"]
            if not re.match(pattern, const_name):
                # Not conforming to convention
                if const_name not in self.whitelist["constant"]:
                    # Not in whitelist, add error
                    line_num = content[:match.start()].count('\n') + 1
                    errors.append(
                        Violation(
                            rule_type="constant",
                            line_number=line_num,
                            identifier=const_name,
                            message=f"常量名 '{const_name}' 不符合规范（应使用c前缀+帕斯卡命名法，如 cMaxBufferSize）"
                        )
                    )
                else:
                    # In whitelist, increase filter count
                    self.whitelist_filtered_count += 1

        return errors
