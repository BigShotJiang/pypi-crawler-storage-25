#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Enum type and enum value naming rule
"""

import re
from typing import Dict, Any, List
from code_checker.base import BaseRule, Violation


class EnumRule(BaseRule):
    """Enum type and enum value naming rule"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)
        self.enum_type_filtered = 0
        self.enum_value_filtered = 0

    def check(self, file_path: str, content: str, lines: list) -> List[Violation]:
        """
        Check enum type and enum value naming convention

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of Violation objects
        """
        errors = []

        # First, find all typedef enum ranges to avoid duplicate checking
        typedef_ranges = []

        # Match typedef enum definitions (with name after enum keyword)
        typedef_enum_pattern1 = re.compile(
            r'typedef\s+enum\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{[^}]*\}\s*([^;]+)\s*;',
            re.DOTALL
        )
        for match in typedef_enum_pattern1.finditer(content):
            typedef_ranges.append((match.start(), match.end()))

        # Match typedef enum definitions (without name after enum keyword)
        typedef_enum_pattern2 = re.compile(
            r'typedef\s+enum\s*\{[^}]*\}\s*([^;]+)\s*;',
            re.DOTALL
        )
        for match in typedef_enum_pattern2.finditer(content):
            typedef_ranges.append((match.start(), match.end()))

        # Check if a position is within any typedef range
        def is_in_typedef(pos):
            for start, end in typedef_ranges:
                if start <= pos < end:
                    return True
            return False

        # Match enum definitions (skip those inside typedef)
        enum_type_pattern = re.compile(r'\benum\s+(class\s+)?([A-Za-z_][A-Za-z0-9_]*)')
        for match in enum_type_pattern.finditer(content):
            # Skip if this is inside a typedef definition
            if is_in_typedef(match.start()):
                continue

            enum_name = match.group(2)

            # Skip if the name is a keyword
            if enum_name in ['typedef', 'struct', 'union', 'class']:
                continue

            # Check enum type name
            pattern = self.config["naming_conventions"]["enum_type"]["pattern"]
            if not re.match(pattern, enum_name):
                # Not conforming to convention
                if enum_name not in self.whitelist["enum_type"]:
                    # Not in whitelist, add error
                    line_num = content[:match.start()].count('\n') + 1
                    errors.append(
                                Violation(
                                    rule_type="enum_type",
                                    line_number=line_num,
                                    identifier=enum_name,
                                    message=f"枚举类名 '{enum_name}' 不符合规范（应使用帕斯卡命名法）"
                                )
                            )
                else:
                    # In whitelist, increase filter count
                    self.enum_type_filtered += 1

        # Match typedef enum definitions (with name after enum keyword)
        # Pattern: typedef enum Name { ... } Type;
        typedef_enum_pattern1 = re.compile(
            r'typedef\s+enum\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{[^}]*\}\s*([^;]+)\s*;',
            re.DOTALL
        )
        for match in typedef_enum_pattern1.finditer(content):
            enum_name = match.group(1)  # name after enum
            typedef_names_part = match.group(2).strip()

            # Get the naming pattern from config
            pattern = self.config["naming_conventions"]["enum_type"]["pattern"]

            # For typedef enum, we only check the names after }, not the internal name after enum keyword
            # So skip checking enum_name here

            # Extract typedef names (handle multiple names separated by commas, and pointer types with *)
            typedef_names = []
            for name in typedef_names_part.split(','):
                name = name.strip()
                # Remove * for pointer types
                name = name.lstrip('*')
                if name:
                    typedef_names.append(name)

            # Check typedef names (the names after })
            for type_name in typedef_names:
                if not re.match(pattern, type_name):
                    # Not conforming to convention
                    if type_name not in self.whitelist["enum_type"]:
                        # Not in whitelist, add error
                        line_num = content[:match.start()].count('\n') + 1
                        errors.append(
                                Violation(
                                    rule_type="enum_type",
                                    line_number=line_num,
                                    identifier=type_name,
                                    message=f"枚举类名 '{type_name}' 不符合规范（应使用帕斯卡命名法）"
                                )
                            )
                    else:
                        # In whitelist, increase filter count
                        self.enum_type_filtered += 1

            # Check enum values for typedef enum
            # Find enum definition range
            start_pos = content.find('{', match.start())
            if start_pos != -1:
                # Find matching closing brace
                brace_count = 1
                i = start_pos + 1
                while i < len(content) and brace_count > 0:
                    if content[i] == '{':
                        brace_count += 1
                    elif content[i] == '}':
                        brace_count -= 1
                    i += 1

                if brace_count == 0:
                    enum_body = content[start_pos + 1:i - 1]

                    # Detect enum values (format: name, or name = xxx, or name)
                    enum_value_pattern = re.compile(r'\b([A-Za-z_][A-Za-z0-9_]*)\b')
                    for value_match in enum_value_pattern.finditer(enum_body):
                        enum_value = value_match.group(1)

                        # Exclude keywords and types
                        exclude_keywords = ["int", "uint8_t", "uint16_t", "uint32_t",
                                           "int8_t", "int16_t", "int32_t", "char",
                                           "bool", "void", "const", "static", "constexpr"]
                        if enum_value not in exclude_keywords:
                            # Check enum value naming (SCREAMING_SNAKE_CASE)
                            value_pattern = r"^[A-Z][A-Z0-9_]*$"
                            if not re.match(value_pattern, enum_value):
                                # Not conforming to convention
                                if enum_value not in self.whitelist["enum_value"]:
                                    # Not in whitelist, add error
                                    # Calculate actual line number
                                    actual_pos = start_pos + 1 + value_match.start()
                                    line_num = content[:actual_pos].count('\n') + 1
                                    errors.append(
                                Violation(
                                    rule_type="enum_value",
                                    line_number=line_num,
                                    identifier=enum_value,
                                    message=f"枚举值 '{enum_value}' 不符合规范（应使用全大写下划线分隔，如 POWER_OFF）"
                                )
                            )
                                else:
                                    # In whitelist, increase filter count
                                    self.enum_value_filtered += 1

        # Match typedef enum definitions (without name after enum keyword)
        # Pattern: typedef enum { ... } Type;
        typedef_enum_pattern2 = re.compile(
            r'typedef\s+enum\s*\{[^}]*\}\s*([^;]+)\s*;',
            re.DOTALL
        )
        for match in typedef_enum_pattern2.finditer(content):
            names_part = match.group(1).strip()

            # Get the naming pattern from config
            pattern = self.config["naming_conventions"]["enum_type"]["pattern"]

            # Extract names (handle multiple names separated by commas, and pointer types with *)
            names = []
            for name in names_part.split(','):
                name = name.strip()
                # Remove * for pointer types
                name = name.lstrip('*')
                if name:
                    names.append(name)

            # Check typedef names (the names after })
            for enum_name in names:
                if not re.match(pattern, enum_name):
                    # Not conforming to convention
                    if enum_name not in self.whitelist["enum_type"]:
                        # Not in whitelist, add error
                        line_num = content[:match.start()].count('\n') + 1
                        errors.append(
                                Violation(
                                    rule_type="enum_type",
                                    line_number=line_num,
                                    identifier=enum_name,
                                    message=f"枚举类名 '{enum_name}' 不符合规范（应使用帕斯卡命名法）"
                                )
                            )
                    else:
                        # In whitelist, increase filter count
                        self.enum_type_filtered += 1

            # Check enum values for typedef enum
            # Find enum definition range
            start_pos = content.find('{', match.start())
            if start_pos != -1:
                # Find matching closing brace
                brace_count = 1
                i = start_pos + 1
                while i < len(content) and brace_count > 0:
                    if content[i] == '{':
                        brace_count += 1
                    elif content[i] == '}':
                        brace_count -= 1
                    i += 1

                if brace_count == 0:
                    enum_body = content[start_pos + 1:i - 1]

                    # Detect enum values (format: name, or name = xxx, or name)
                    enum_value_pattern = re.compile(r'\b([A-Za-z_][A-Za-z0-9_]*)\b')
                    for value_match in enum_value_pattern.finditer(enum_body):
                        enum_value = value_match.group(1)

                        # Exclude keywords and types
                        exclude_keywords = ["int", "uint8_t", "uint16_t", "uint32_t",
                                           "int8_t", "int16_t", "int32_t", "char",
                                           "bool", "void", "const", "static", "constexpr"]
                        if enum_value not in exclude_keywords:
                            # Check enum value naming (SCREAMING_SNAKE_CASE)
                            value_pattern = r"^[A-Z][A-Z0-9_]*$"
                            if not re.match(value_pattern, enum_value):
                                # Not conforming to convention
                                if enum_value not in self.whitelist["enum_value"]:
                                    # Not in whitelist, add error
                                    # Calculate actual line number
                                    actual_pos = start_pos + 1 + value_match.start()
                                    line_num = content[:actual_pos].count('\n') + 1
                                    errors.append(
                                Violation(
                                    rule_type="enum_value",
                                    line_number=line_num,
                                    identifier=enum_value,
                                    message=f"枚举值 '{enum_value}' 不符合规范（应使用全大写下划线分隔，如 POWER_OFF）"
                                )
                            )
                                else:
                                    # In whitelist, increase filter count
                                    self.enum_value_filtered += 1

        # Update filtered counts
        self.whitelist_filtered_count = self.enum_type_filtered + self.enum_value_filtered

        return errors

    def get_enum_type_filtered(self) -> int:
        """Get enum type filtered count"""
        return self.enum_type_filtered

    def get_enum_value_filtered(self) -> int:
        """Get enum value filtered count"""
        return self.enum_value_filtered
