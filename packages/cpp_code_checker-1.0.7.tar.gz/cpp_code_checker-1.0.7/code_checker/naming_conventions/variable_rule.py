#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Variable naming rule - includes member variables, global variables, parameters, and local variables
"""

import re
from typing import Dict, Any, List
from code_checker.base import BaseRule, Violation
from code_checker.naming_conventions.helper import NamingHelper


class VariableRule(BaseRule):
    """Variable naming rule for all types of variables"""

    def __init__(self, config: Dict[str, Any], whitelist: Dict[str, list]):
        super().__init__(config, whitelist)
        self.class_member_filtered = 0
        self.struct_member_filtered = 0
        self.global_filtered = 0
        self.static_global_filtered = 0
        self.parameter_filtered = 0
        self.local_variable_filtered = 0
        self.in_function = None  # Mark function body ranges

    def _find_first_real_brace(self, content: str) -> int:
        """
        Find the position of the first real { (skipping comments, strings, and preprocessor directives)

        Returns:
            Position of the first real { character, or -1 if not found
        """
        in_single_line_comment = False
        in_multi_line_comment = False
        in_double_quote = False
        in_single_quote = False

        i = 0
        while i < len(content):
            char = content[i]

            # Skip preprocessor directives (#if, #ifdef, #include, #define, #endif, etc.)
            if not in_single_line_comment and not in_multi_line_comment and not in_double_quote and not in_single_quote:
                if char == '#' and (i == 0 or content[i-1] == '\n'):
                    # Found a preprocessor directive, skip to end of line
                    while i < len(content) and content[i] != '\n':
                        i += 1
                    continue

            if in_single_line_comment:
                if char == '\n':
                    in_single_line_comment = False
                i += 1
                continue

            if in_multi_line_comment:
                if char == '*' and i + 1 < len(content) and content[i + 1] == '/':
                    in_multi_line_comment = False
                    i += 1
                i += 1
                continue

            if not in_double_quote and not in_single_quote and not in_multi_line_comment and not in_single_line_comment:
                # Check for comment start
                if char == '/' and i + 1 < len(content):
                    if content[i + 1] == '/':
                        in_single_line_comment = True
                        i += 2
                        continue
                    elif content[i + 1] == '*':
                        in_multi_line_comment = True
                        i += 2
                        continue

                # Check for string and character literals
                if char == '"':
                    # Check if it's an escaped quote
                    if i == 0 or content[i - 1] != '\\':
                        in_double_quote = not in_double_quote
                    i += 1
                    continue
                elif char == "'":
                    # Check if it's an escaped quote
                    if i == 0 or content[i - 1] != '\\':
                        in_single_quote = not in_single_quote
                    i += 1
                    continue

                # Found the first real {
                if char == '{':
                    return i

            i += 1

        return -1  # No { found

    def _is_in_preprocessor_directive(self, content: str, pos: int) -> bool:
        """
        Check if position is in a preprocessor directive line

        Args:
            content: File content
            pos: Position to check

        Returns:
            True if position is in a preprocessor directive line, False otherwise
        """
        # Find the start of the line containing pos
        line_start = content.rfind('\n', 0, pos) + 1
        line_end = content.find('\n', pos)
        if line_end == -1:
            line_end = len(content)

        line_content = content[line_start:line_end]

        # Check if line starts with # (skip leading whitespace)
        return line_content.strip().startswith('#')

    def check(self, file_path: str, content: str, lines: list) -> List[Violation]:
        """
        Check variable naming convention

        Args:
            file_path: Path to the file
            content: File content as string
            lines: File content as list of lines

        Returns:
            List of Violation objects
        """
        errors = []

        # Get class/struct ranges and markers
        class_ranges = NamingHelper.get_class_struct_ranges(content)
        in_class, in_struct, in_class_or_struct = NamingHelper.create_position_markers(
            content, class_ranges
        )

        # Find the first real { position
        first_brace_pos = self._find_first_real_brace(content)

        # Check local variables first (to mark function bodies)
        self._check_local_variables(content, errors, in_class, in_struct)

        # Check member variables and global variables (exclude function bodies)
        self._check_member_and_global_variables(content, errors, in_class, in_struct, first_brace_pos, self.in_function)

        # Check function parameters
        self._check_parameters(content, errors)

        # Update filtered count
        self.whitelist_filtered_count = (
            self.class_member_filtered + self.struct_member_filtered +
            self.global_filtered + self.static_global_filtered +
            self.parameter_filtered + self.local_variable_filtered
        )

        return errors

    def _check_member_and_global_variables(self, content: str, errors: List[str],
                                            in_class: list, in_struct: list, first_brace_pos: int, in_function: list):
        """Check member variables and global variables"""
        # Match variable declarations (allow initialization)
        var_decl_pattern = re.compile(
            r'^\s*(?:[A-Za-z_][A-Za-z0-9_]*(?:\s*\*|\s*&)?\s+)+([A-Za-z_][A-Za-z0-9_]*)'
            r'\s*(?:\[[^\]]*\])?\s*(?:=\s*[^;]+)?\s*;',
            re.MULTILINE
        )

        for match in var_decl_pattern.finditer(content):
            var_name = match.group(1)

            # Skip if in preprocessor directive
            if self._is_in_preprocessor_directive(content, match.start()):
                continue

            # Exclude keywords and function-related identifiers
            exclude_keywords = ["class", "struct", "enum", "if", "for", "while", "switch",
                              "catch", "return", "public", "private", "protected", "operator",
                              "using", "namespace", "template", "typename", "virtual", "static",
                              "const", "constexpr", "extern", "mutable", "volatile", "inline",
                              "explicit", "friend", "override", "final", "noexcept", "decltype",
                              "sizeof", "alignof", "alignas", "typeid", "asm", "catch", "throw",
                              "try", "sizeof"]
            if var_name in exclude_keywords:
                continue

            # Exclude const constants (handled by constant rule)
            match_text = content[match.start():match.end()]
            if 'const' in match_text:
                check_line_start = content.rfind('\n', 0, match.start()) + 1
                check_line_end = content.find('\n', check_line_start + 1)
                if check_line_end == -1:
                    check_line_end = len(content)
                declaration_line = content[check_line_start:check_line_end]
                if re.search(r'\bconst\b', declaration_line):
                    continue

            # Exclude function declarations
            context = content[max(0, match.start() - 50):match.end() + 50]
            if '(' in context and ')' in context:
                func_check = re.search(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)\s*[;{]', context)
                if func_check and func_check.group(1) == var_name:
                    continue

            # Determine if class member, struct member, or global variable
            check_pos = match.start()

            if check_pos < len(in_class) and in_class[check_pos]:
                # Skip if it's in a function body (it's a local variable, not a class member)
                if in_function is not None and check_pos < len(in_function) and in_function[check_pos]:
                    continue

                # Class member variable: use _camelCase
                pattern = self.config["naming_conventions"]["class_member_variable"]["pattern"]
                if not re.match(pattern, var_name):
                    if var_name not in self.whitelist["class_member_variable"]:
                        line_num = content[:match.start()].count('\n') + 1
                        errors.append(
                            f"[命名规范][class_member_variable] 第 {line_num} 行: 类成员变量 '{var_name}' 不符合规范（应使用下划线前缀+驼峰命名法，如 _myVariable）"
                        )
                    else:
                        self.class_member_filtered += 1

            elif check_pos < len(in_struct) and in_struct[check_pos]:
                # Skip if it's in a function body (it's a local variable, not a struct member)
                if in_function is not None and check_pos < len(in_function) and in_function[check_pos]:
                    continue

                # Struct member variable: use camelCase
                pattern = self.config["naming_conventions"]["struct_member_variable"]["pattern"]
                if not re.match(pattern, var_name):
                    if var_name not in self.whitelist["struct_member_variable"]:
                        line_num = content[:match.start()].count('\n') + 1
                        errors.append(
                            f"[命名规范][struct_member_variable] 第 {line_num} 行: 结构体成员变量 '{var_name}' 不符合规范（应使用驼峰命名法，如 myVariable）"
                        )
                    else:
                        self.struct_member_filtered += 1

            else:
                # Not in class/struct, check if in function body
                # Use in_function marker to exclude local variables
                if in_function is not None and check_pos < len(in_function) and in_function[check_pos]:
                    # In function body, it's a local variable, skip
                    continue

                # Check if before first { (global/static global variable)
                if first_brace_pos != -1 and check_pos >= first_brace_pos:
                    # After first {, not considered global/static global variable
                    continue

                # Global or static global variable
                check_line_start = content.rfind('\n', 0, match.start()) + 1
                check_line_end = content.find('\n', check_line_start + 1)
                if check_line_end == -1:
                    check_line_end = len(content)

                declaration_line = content[check_line_start:check_line_end]
                is_static = re.search(r'\bstatic\b', declaration_line) is not None

                if is_static:
                    pattern = self.config["naming_conventions"]["static_global_variable"]["pattern"]
                    whitelist_key = "static_global_variable"
                    rule_name = "static_global_variable"
                    var_type = "静态全局变量"
                    desc = "s_ 前缀 + 驼峰命名法（如 s_instance）"
                    if is_static:
                        self.static_global_filtered += 1
                else:
                    pattern = self.config["naming_conventions"]["global_variable"]["pattern"]
                    whitelist_key = "global_variable"
                    rule_name = "global_variable"
                    var_type = "全局变量"
                    desc = "g_ 前缀 + 驼峰命名法（如 g_userCount）"
                    self.global_filtered += 1

                if not re.match(pattern, var_name):
                    if var_name not in self.whitelist[whitelist_key]:
                        line_num = content[:match.start()].count('\n') + 1
                        errors.append(
                            f"[命名规范][{rule_name}] 第 {line_num} 行: {var_type} '{var_name}' 不符合规范（应使用{desc}）"
                        )
                    else:
                        if is_static:
                            self.static_global_filtered += 1
                        else:
                            self.global_filtered += 1

    def _check_parameters(self, content: str, errors: List[str]):
        """Check function parameters"""
        param_pattern = re.compile(r'\b([a-zA-Z_][a-zA-Z0-9_]*)\s*\(([^)]*)\)')
        for match in param_pattern.finditer(content):
            func_name = match.group(1)
            params_str = match.group(2)

            if not params_str.strip():
                continue

            # Exclude control flow statements
            if func_name in ['for', 'while', 'if', 'switch', 'catch', 'do']:
                continue

            # Split parameters
            params = [p.strip() for p in params_str.split(',')]
            for param in params:
                if not param:
                    continue

                # Extract parameter name (last identifier)
                param_parts = param.split()
                if len(param_parts) < 2:
                    continue

                param_name_part = param_parts[-1]
                param_name = param_name_part.split('=')[0].strip()
                param_name = param_name.rstrip('*&').strip()

                # Exclude keywords and special identifiers
                exclude_keywords = ["void", "int", "float", "double", "char", "bool",
                                  "class", "struct", "enum", "const", "static", "constexpr",
                                  "const&", "const*", "unsigned", "signed", "long", "short"]
                if not param_name or param_name in exclude_keywords:
                    continue

                # Check parameter naming
                pattern = self.config["naming_conventions"]["parameter"]["pattern"]
                if not re.match(pattern, param_name):
                    if param_name not in self.whitelist["parameter"]:
                        line_num = content[:match.start()].count('\n') + 1
                        errors.append(
                            f"[命名规范][parameter] 第 {line_num} 行: 函数参数 '{param_name}' 不符合规范（应使用驼峰命名法）"
                        )
                    else:
                        self.parameter_filtered += 1

    def _check_local_variables(self, content: str, errors: List[str],
                               in_class: list, in_struct: list):
        """Check local variables in function bodies"""
        # Mark function body ranges (including member functions)
        self.in_function = [False] * len(content)

        # Find all function definitions using regex
        # Pattern: return_type function_name(params) {
        # We need to match:
        # - Regular functions: int func() {}
        # - Member functions: int Class::func() {}
        # - Methods in class: void method() {}

        # First, mark all function bodies
        func_pattern = re.compile(
            r'([A-Za-z_][A-Za-z0-9_]*(?:\s*\*|\s*&)?\s+)'  # Return type
            r'([A-Za-z_][A-Za-z0-9_]*(?:::[A-Za-z_][A-Za-z0-9_]*)?\s*)'  # Function name (may have scope)
            r'(?:\([^)]*\))'  # Parameters
            r'(?:\s*const)?'  # Optional const
            r'(?:\s*override)?'  # Optional override
            r'(?:\s*final)?'  # Optional final
            r'(?:\s*noexcept)?'  # Optional noexcept
            r'\s*\{',  # Opening brace
            re.MULTILINE
        )

        for match in func_pattern.finditer(content):
            func_start = match.end() - 1  # Position of {

            # Check if this is actually a function, not class/struct/enum definition
            # Look at immediate context to exclude class/struct/enum definitions
            context_start = max(0, match.start() - 100)
            context = content[context_start:match.start()]

            # Skip if it's a class/struct/enum definition
            # Check if the matched return_type is actually a keyword (class, struct, enum)
            if match.group(1).strip() in ['class', 'struct', 'enum']:
                continue

            # Check if it's a function or variable initialization
            # Function definition: something(params) {
            # Variable initialization: something = { ... }
            # Variable initialization with function call: something = func() { ... }

            # Look for = or ( before the { (indicates variable initialization)
            immediate_context = content[max(0, match.start() - 20):match.start()]

            # Check if there's = or ( in immediate context (excluding the function params)
            # We need to be careful: the function params already have ( and )
            # So we check if there's a = or extra ( after the closing )

            # Find the position of the closing )
            paren_end = match.group().rfind(')')
            if paren_end != -1:
                after_paren = match.group()[paren_end + 1:match.end() - 1]  # Between ) and {
                # If there's = or ( between ) and {, it's likely variable initialization
                if '=' in after_paren or '(' in after_paren:
                    continue

            # This is a function definition, mark the function body
            brace_count = 1
            pos = func_start + 1
            while pos < len(content) and brace_count > 0:
                if content[pos] == '{':
                    brace_count += 1
                elif content[pos] == '}':
                    brace_count -= 1
                self.in_function[pos] = True
                pos += 1

        # Detect variable declarations and determine if local variables
        var_decl_pattern = re.compile(
            r'^\s*(?:[A-Za-z_][A-Za-z0-9_]*(?:\s*\*|\s*&)?\s+)+([A-Za-z_][A-Za-z0-9_]*)'
            r'\s*(?:\[[^\]]*\])?\s*(?:=\s*[^;]+)?\s*;',
            re.MULTILINE
        )
        for match in var_decl_pattern.finditer(content):
            var_name = match.group(1)
            check_pos = match.start()

            # Exclude keywords
            exclude_keywords = ["class", "struct", "enum", "if", "for", "while", "switch",
                              "catch", "return", "public", "private", "protected", "operator",
                              "using", "namespace", "template", "typename", "virtual", "static",
                              "const", "constexpr", "extern", "mutable", "volatile", "inline",
                              "explicit", "friend", "override", "final", "noexcept", "decltype",
                              "sizeof", "alignof", "alignas", "typeid", "asm", "catch", "throw",
                              "try"]
            if var_name in exclude_keywords:
                continue

            # Exclude function declarations
            context = content[max(0, match.start() - 50):match.end() + 50]
            if '(' in context and ')' in context:
                func_check = re.search(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)\s*[;{]', context)
                if func_check and func_check.group(1) == var_name:
                    continue

            # Determine if local variable (in function body)
            # If it's in a function body, it's a local variable regardless of being in class/struct
            is_local = (
                check_pos < len(self.in_function) and self.in_function[check_pos]
            )

            if is_local:
                pattern = self.config["naming_conventions"]["local_variable"]["pattern"]
                if not re.match(pattern, var_name):
                    if var_name not in self.whitelist["local_variable"]:
                        line_num = content[:match.start()].count('\n') + 1
                        errors.append(
                        Violation(
                            rule_type="local_variable",
                            line_number=line_num,
                            identifier=var_name,
                                    message=f"局部变量 '{var_name}' 不符合规范（应使用驼峰命名法）"
                        )
                    )
                    else:
                        self.local_variable_filtered += 1
