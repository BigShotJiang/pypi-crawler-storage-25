#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
C++ Code Checker - Main Entry Point
Modular refactored version
"""

import os
import sys
import json
from code_checker import get_resource_path
import argparse
from typing import Dict, Any, List, Optional
from pathlib import Path
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import base modules
from code_checker.base import Colors, DEFAULT_CODING_STANDARDS
from code_checker.config_loader import ConfigLoader
from code_checker.whitelist import WhitelistManager

# Import naming convention rules
from code_checker.naming_conventions.file_name_rule import FileNameRule
from code_checker.naming_conventions.macro_rule import MacroRule
from code_checker.naming_conventions.class_struct_rule import ClassStructRule
from code_checker.naming_conventions.enum_rule import EnumRule
from code_checker.naming_conventions.constant_rule import ConstantRule
from code_checker.naming_conventions.function_rule import FunctionRule
from code_checker.naming_conventions.variable_rule import VariableRule

# Import code style rules
from code_checker.code_style.line_length_rule import LineLengthRule
from code_checker.code_style.indentation_rule import IndentationRule

# Import best practice rules
from code_checker.best_practices.function_length_rule import FunctionLengthRule
from code_checker.best_practices.cyclomatic_complexity_rule import CyclomaticComplexityRule
from code_checker.best_practices.no_extern_rule import NoExternRule


class CppCodeChecker:
    """C++ code checker with modular rules"""

    def __init__(self, config_path: Optional[str] = None, whitelist_path: Optional[str] = None):
        """Initialize checker"""
        self.script_dir = os.path.dirname(os.path.abspath(__file__))

        # Load configuration
        self.config = ConfigLoader.load_config(config_path, self.script_dir)

        # Load whitelist
        self.whitelist = WhitelistManager.load_whitelist(whitelist_path)

        # Initialize all rules
        self._init_rules()

    def _init_rules(self):
        """Initialize all check rules"""
        # Naming convention rules
        self.file_name_rule = FileNameRule(self.config, self.whitelist)
        self.macro_rule = MacroRule(self.config, self.whitelist)
        self.class_struct_rule = ClassStructRule(self.config, self.whitelist)
        self.enum_rule = EnumRule(self.config, self.whitelist)
        self.constant_rule = ConstantRule(self.config, self.whitelist)
        self.function_rule = FunctionRule(self.config, self.whitelist)
        self.variable_rule = VariableRule(self.config, self.whitelist)

        # Code style rules
        self.line_length_rule = LineLengthRule(self.config, self.whitelist)
        self.indentation_rule = IndentationRule(self.config, self.whitelist)

        # Best practice rules
        self.function_length_rule = FunctionLengthRule(self.config, self.whitelist)
        self.cyclomatic_complexity_rule = CyclomaticComplexityRule(self.config, self.whitelist)
        self.no_extern_rule = NoExternRule(self.config, self.whitelist)

    def is_subrule_enabled(self, subrule_name: str) -> bool:
        """
        Check if a subrule is enabled based on config

        Args:
            subrule_name: The name of the subrule (e.g., 'enum_type', 'enum_value', 'file_name')

        Returns:
            True if enabled, False otherwise (default: True)
        """
        # Map subrule names to config paths
        config_path_map = {
            'file_name': ['naming_conventions', 'file_name'],
            'macro': ['naming_conventions', 'macro'],
            'class_struct_and_union_name': ['naming_conventions', 'class_struct_and_union_name'],
            'enum_type': ['naming_conventions', 'enum_type'],
            'enum_value': ['naming_conventions', 'enum_value'],
            'constant': ['naming_conventions', 'constant'],
            'function': ['naming_conventions', 'function'],
            'member_function': ['naming_conventions', 'member_function'],
            'parameter': ['naming_conventions', 'parameter'],
            'local_variable': ['naming_conventions', 'local_variable'],
            'global_variable': ['naming_conventions', 'global_variable'],
            'static_global_variable': ['naming_conventions', 'static_global_variable'],
            'class_member_variable': ['naming_conventions', 'class_member_variable'],
            'struct_member_variable': ['naming_conventions', 'struct_member_variable'],
            'line_length': ['code_style', 'line_length'],
            'indentation': ['code_style', 'indentation'],
            'function_length': ['best_practices', 'function_length'],
            'cyclomatic_complexity': ['best_practices', 'cyclomatic_complexity'],
            'no_extern': ['best_practices', 'no_extern']
        }

        if subrule_name not in config_path_map:
            return True  # Default: enabled

        path = config_path_map[subrule_name]
        config_obj = self.config
        for key in path:
            if key in config_obj:
                config_obj = config_obj[key]
            else:
                return True  # Default: enabled if path not found

        # Check enabled status from config
        if isinstance(config_obj, dict) and 'enabled' in config_obj:
            return config_obj['enabled']

        return True  # Default: enabled

    def get_severity_for_subrule(self, subrule_name: str) -> str:
        """
        Get severity level for a subrule based on config

        Args:
            subrule_name: The name of the subrule (e.g., 'enum_type', 'enum_value', 'file_name')

        Returns:
            Severity level: 'error', 'warning', or 'suggestion' (default: 'error')
        """
        # Map subrule names to config paths
        config_path_map = {
            'file_name': ['naming_conventions', 'file_name'],
            'macro': ['naming_conventions', 'macro'],
            'class_struct_and_union_name': ['naming_conventions', 'class_struct_and_union_name'],
            'enum_type': ['naming_conventions', 'enum_type'],
            'enum_value': ['naming_conventions', 'enum_value'],
            'constant': ['naming_conventions', 'constant'],
            'function': ['naming_conventions', 'function'],
            'member_function': ['naming_conventions', 'member_function'],
            'parameter': ['naming_conventions', 'parameter'],
            'local_variable': ['naming_conventions', 'local_variable'],
            'global_variable': ['naming_conventions', 'global_variable'],
            'static_global_variable': ['naming_conventions', 'static_global_variable'],
            'class_member_variable': ['naming_conventions', 'class_member_variable'],
            'struct_member_variable': ['naming_conventions', 'struct_member_variable'],
            'line_length': ['code_style', 'line_length'],
            'indentation': ['code_style', 'indentation'],
            'function_length': ['best_practices', 'function_length'],
            'cyclomatic_complexity': ['best_practices', 'cyclomatic_complexity'],
            'no_extern': ['best_practices', 'no_extern']
        }

        if subrule_name not in config_path_map:
            return 'error'  # Default severity

        path = config_path_map[subrule_name]
        config_obj = self.config
        for key in path:
            if key in config_obj:
                config_obj = config_obj[key]
            else:
                return 'error'  # Default if path not found

        # Get severity from config
        if isinstance(config_obj, dict) and 'severity' in config_obj:
            return config_obj['severity']

        return 'error'  # Default severity

    @staticmethod
    def violation_to_message(violation) -> str:
        """
        Convert Violation object to error message string

        Args:
            violation: Violation object

        Returns:
            Formatted error message string
        """
        from code_checker.base import Violation

        if isinstance(violation, Violation):
            return f"[命名规范][{violation.rule_type}] 第 {violation.line_number} 行: {violation.message}"
        else:
            # Backward compatibility: if it's already a string, return it
            return str(violation)

    def add_messages_by_severity(self, messages: list, errors: list, warnings: list, suggestions: list):
        """
        Add messages to appropriate list based on their severity level and enabled status

        Args:
            messages: List of Violation objects or error messages
            errors: List to append error-level messages
            warnings: List to append warning-level messages
            suggestions: List to append suggestion-level messages
        """
        import re
        from code_checker.base import Violation

        for msg in messages:
            # Convert Violation to message string if needed
            if isinstance(msg, Violation):
                violation = msg
                message = self.violation_to_message(violation)
                subrule_name = violation.rule_type
            else:
                # Backward compatibility: treat as string
                message = msg
                # Extract subrule name from message
                match = re.search(r'\[.*?\]\[([^\]]+)\]', message)
                if match:
                    subrule_name = match.group(1)
                else:
                    subrule_name = None

            if subrule_name:
                # Check if this subrule is enabled
                if not self.is_subrule_enabled(subrule_name):
                    continue  # Skip this message if subrule is disabled

                severity = self.get_severity_for_subrule(subrule_name)
                if severity == 'error':
                    errors.append(message)
                elif severity == 'warning':
                    warnings.append(message)
                elif severity == 'suggestion':
                    suggestions.append(message)
                else:
                    errors.append(message)  # Default to error
            else:
                errors.append(message)  # Default to error if pattern not found

    def check_file(self, file_path: str, use_whitelist: bool = True) -> Dict[str, Any]:
        """
        Check a single file

        Args:
            file_path: Path to the file
            use_whitelist: Whether to use whitelist filtering (default True). Should be False when generating whitelist
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            lines = content.split('\n')
        except Exception as e:
            return {
                "file": file_path,
                "errors": [f"无法读取文件: {str(e)}"],
                "warnings": [],
                "suggestions": [],
                "whitelist_filtered": {}
            }

        # Temporarily save and clear whitelist if not using it
        original_whitelist = None
        if not use_whitelist:
            original_whitelist = self.whitelist.copy()
            for key in self.whitelist:
                self.whitelist[key] = []

        errors = []
        warnings = []
        suggestions = []

        # Collect all check results (Violation objects)
        all_violations = []

        # Check naming conventions
        all_violations.extend(self.file_name_rule.check(file_path, content, lines))
        all_violations.extend(self.macro_rule.check(file_path, content, lines))
        all_violations.extend(self.class_struct_rule.check(file_path, content, lines))
        all_violations.extend(self.enum_rule.check(file_path, content, lines))
        all_violations.extend(self.constant_rule.check(file_path, content, lines))
        all_violations.extend(self.function_rule.check(file_path, content, lines))
        all_violations.extend(self.variable_rule.check(file_path, content, lines))

        # Check code style
        all_violations.extend(self.line_length_rule.check(file_path, content, lines))
        all_violations.extend(self.indentation_rule.check(file_path, content, lines))

        # Check best practices
        all_violations.extend(self.function_length_rule.check(file_path, content, lines))
        all_violations.extend(self.cyclomatic_complexity_rule.check(file_path, content, lines))
        all_violations.extend(self.no_extern_rule.check(file_path, content, lines))

        # Distribute messages by severity
        self.add_messages_by_severity(all_violations, errors, warnings, suggestions)

        # Restore original whitelist if it was temporarily disabled
        if not use_whitelist and original_whitelist is not None:
            self.whitelist = original_whitelist

        # Collect whitelist filtered counts (only for enabled rules)
        whitelist_filtered = {
            "file_name": self.file_name_rule.get_filtered_count() if self.is_subrule_enabled('file_name') else 0,
            "macro": self.macro_rule.get_filtered_count() if self.is_subrule_enabled('macro') else 0,
            "class_struct_and_union_name": self.class_struct_rule.get_filtered_count() if self.is_subrule_enabled('class_struct_and_union_name') else 0,
            "enum_type": self.enum_rule.get_enum_type_filtered() if self.is_subrule_enabled('enum_type') else 0,
            "enum_value": self.enum_rule.get_enum_value_filtered() if self.is_subrule_enabled('enum_value') else 0,
            "constant": self.constant_rule.get_filtered_count() if self.is_subrule_enabled('constant') else 0,
            "function": self.function_rule.get_function_filtered() if self.is_subrule_enabled('function') else 0,
            "member_function": self.function_rule.get_member_function_filtered() if self.is_subrule_enabled('member_function') else 0,
            "class_member_variable": self.variable_rule.class_member_filtered if self.is_subrule_enabled('class_member_variable') else 0,
            "struct_member_variable": self.variable_rule.struct_member_filtered if self.is_subrule_enabled('struct_member_variable') else 0,
            "global_variable": self.variable_rule.global_filtered if self.is_subrule_enabled('global_variable') else 0,
            "static_global_variable": self.variable_rule.static_global_filtered if self.is_subrule_enabled('static_global_variable') else 0,
            "parameter": self.variable_rule.parameter_filtered if self.is_subrule_enabled('parameter') else 0,
            "local_variable": self.variable_rule.local_variable_filtered if self.is_subrule_enabled('local_variable') else 0,
            "line_length": self.line_length_rule.get_filtered_count() if self.is_subrule_enabled('line_length') else 0,
            "indentation": self.indentation_rule.get_filtered_count() if self.is_subrule_enabled('indentation') else 0,
            "function_length": self.function_length_rule.get_filtered_count() if self.is_subrule_enabled('function_length') else 0,
            "cyclomatic_complexity": self.cyclomatic_complexity_rule.get_filtered_count() if self.is_subrule_enabled('cyclomatic_complexity') else 0,
            "no_extern": self.no_extern_rule.get_filtered_count() if self.is_subrule_enabled('no_extern') else 0
        }

        return {
            "file": file_path,
            "errors": errors,
            "warnings": warnings,
            "suggestions": suggestions,
            "whitelist_filtered": whitelist_filtered,
            "violations": all_violations  # Save original Violation objects for whitelist generation
        }

    def check_directory(self, directory: str, ignore_dirs: List[str] = None,
                       extensions: List[str] = None, use_whitelist: bool = True) -> List[Dict[str, Any]]:
        """
        Check all files in a directory

        Args:
            directory: Directory path
            ignore_dirs: List of directories to ignore
            extensions: List of file extensions to check
            use_whitelist: Whether to use whitelist filtering
        """
        if ignore_dirs is None:
            ignore_dirs = ['build', 'dist', 'node_modules', 'venv', '__pycache__', '.git']
        if extensions is None:
            extensions = ['.cpp', '.h', '.hpp', '.cc', '.cxx']

        results = []
        for root, dirs, files in os.walk(directory):
            # Remove ignored directories
            dirs[:] = [d for d in dirs if d not in ignore_dirs]

            for file in files:
                if any(file.endswith(ext) for ext in extensions):
                    file_path = os.path.join(root, file)
                    results.append(self.check_file(file_path, use_whitelist))

        return results

    @staticmethod
    def extract_identifier_from_message(message: str) -> tuple:
        """
        Extract identifier type and name from error message

        Returns:
            Tuple of (rule_type, identifier_name)
        """
        # Enum type
        if "枚举类名" in message or "枚举类型名" in message:
            match = __import__('re').search(r"(?:枚举类名|枚举类型名) '([^']+)'", message)
            if match:
                return ("enum_type", match.group(1))

        # Enum value
        if "枚举值" in message:
            match = __import__('re').search(r"枚举值 '([^']+)'", message)
            if match:
                return ("enum_value", match.group(1))

        # Typedef struct/union/enum type names (typedef定义的类型名)
        if "typedef类型名" in message:
            match = __import__('re').search(r"typedef类型名 '([^']+)'", message)
            if match:
                return ("class_struct_and_union_name", match.group(1))

        # Class, struct and union names
        if "class名" in message or "struct名" in message or "union名" in message or ("类名" in message and "枚举类名" not in message) or ("结构体名" in message) or ("联合体名" in message):
            match = __import__('re').search(r"(?:class名|struct名|union名|类名|结构体名|联合体名) '([^']+)'", message)
            if match:
                return ("class_struct_and_union_name", match.group(1))

        # Function names
        if "函数名" in message:
            match = __import__('re').search(r"函数名 '([^']+)'", message)
            if match:
                # Check if it's a member function or normal function
                if "成员函数" in message:
                    return ("member_function", match.group(1))
                else:
                    return ("function", match.group(1))

        # Constant names
        if "常量名" in message:
            match = __import__('re').search(r"常量名 '([^']+)'", message)
            if match:
                return ("constant", match.group(1))

        # Class member variables
        if "类成员变量" in message:
            match = __import__('re').search(r"类成员变量 '([^']+)'", message)
            if match:
                return ("class_member_variable", match.group(1))

        # Struct member variables
        if "结构体成员变量" in message:
            match = __import__('re').search(r"结构体成员变量 '([^']+)'", message)
            if match:
                return ("struct_member_variable", match.group(1))

        # Global variables
        if "全局变量" in message and "静态全局变量" not in message:
            match = __import__('re').search(r"全局变量 '([^']+)'", message)
            if match:
                return ("global_variable", match.group(1))

        # Static global variables
        if "静态全局变量" in message:
            match = __import__('re').search(r"静态全局变量 '([^']+)'", message)
            if match:
                return ("static_global_variable", match.group(1))

        # Parameters
        if "函数参数" in message:
            match = __import__('re').search(r"函数参数 '([^']+)'", message)
            if match:
                return ("parameter", match.group(1))

        # Local variables
        if "局部变量" in message:
            match = __import__('re').search(r"局部变量 '([^']+)'", message)
            if match:
                return ("local_variable", match.group(1))

        # Macro names
        if "宏定义" in message:
            match = __import__('re').search(r"宏定义 '([^']+)'", message)
            if match:
                return ("macro", match.group(1))

        # File names
        if "[file_name]" in message or "文件名" in message:
            match = __import__('re').search(r"文件名 '([^']+)'", message)
            if match:
                filename = match.group(1)
                # Extract filename without extension
                import os
                name_without_ext = os.path.splitext(filename)[0]
                return ("file_name", name_without_ext)

        # Cyclomatic complexity (function names)
        if "cyclomatic_complexity" in message and "函数" in message:
            match = __import__('re').search(r"函数 '([^']+)' 圈复杂度过高", message)
            if match:
                return ("cyclomatic_complexity", match.group(1))

        # Function length (function names)
        if "function_length" in message and "函数" in message:
            match = __import__('re').search(r"函数 '([^']+)' 过长", message)
            if match:
                return ("function_length", match.group(1))

        # Line length (function names or filename:line_number)
        if "line_length" in message and "[" in message and "]" in message:
            # Try to extract function name first
            func_match = __import__('re').search(r"\[函数 '([^']+)'\]", message)
            if func_match:
                return ("line_length", func_match.group(1))
            # If not in function, extract filename:line
            match = __import__('re').search(r"\[([^]]+)\]$", message)
            if match:
                return ("line_length", match.group(1))

        # Indentation (function names or filename:line_number)
        if "indentation" in message and "[" in message and "]" in message:
            # Try to extract function name first
            func_match = __import__('re').search(r"\[函数 '([^']+)'\]", message)
            if func_match:
                return ("indentation", func_match.group(1))
            # If not in function, extract filename:line
            match = __import__('re').search(r"\[([^]]+)\]$", message)
            if match:
                return ("indentation", match.group(1))

        # No extern (identifier names)
        if "no_extern" in message and "禁止使用 extern 引用全局变量或函数" in message:
            match = __import__('re').search(r"禁止使用 extern 引用全局变量或函数 '([^']+)'", message)
            if match:
                return ("no_extern", match.group(1))

        return (None, None)


def print_results(results: List[Dict[str, Any]]):
    """Print check results"""
    total_errors = 0
    total_warnings = 0
    total_suggestions = 0
    total_filtered = 0
    rule_filtered = {}  # 统计各个规则的过滤总数

    for result in results:
        file = result['file']
        errors = result['errors']
        warnings = result['warnings']
        suggestions = result['suggestions']
        whitelist_filtered = result.get('whitelist_filtered', {})

        if errors:
            total_errors += len(errors)
            print(f"\n{Colors.FAIL}{file}{Colors.ENDC}")
            for error in errors:
                print(f"  {Colors.FAIL}✗{Colors.ENDC} {error}")

        if warnings:
            total_warnings += len(warnings)
            if not errors:
                print(f"\n{Colors.WARNING}{file}{Colors.ENDC}")
            for warning in warnings:
                print(f"  {Colors.WARNING}⚠{Colors.ENDC} {warning}")

        if suggestions:
            total_suggestions += len(suggestions)
            if not errors and not warnings:
                print(f"\n{Colors.OKCYAN}{file}{Colors.ENDC}")
            for suggestion in suggestions:
                print(f"  {Colors.OKCYAN}ℹ{Colors.ENDC} {suggestion}")

        # 统计白名单过滤数（不显示在文件级别）
        if whitelist_filtered:
            for key, count in whitelist_filtered.items():
                if count > 0:
                    total_filtered += count
                    rule_filtered[key] = rule_filtered.get(key, 0) + count

    # Summary
    print(f"\n{Colors.BOLD}检查统计:{Colors.ENDC}")
    print(f"  {Colors.FAIL}错误: {total_errors}{Colors.ENDC}")
    print(f"  {Colors.WARNING}警告: {total_warnings}{Colors.ENDC}")
    print(f"  {Colors.OKCYAN}建议: {total_suggestions}{Colors.ENDC}")

    # 显示白名单过滤统计（按规则分类）
    if total_filtered > 0:
        print(f"  {Colors.OKGREEN}白名单过滤: {total_filtered} 项{Colors.ENDC}")
        # 显示各个规则的过滤数
        for rule_name in sorted(rule_filtered.keys()):
            if rule_filtered[rule_name] > 0:
                print(f"    - {rule_name}: {rule_filtered[rule_name]}")


def generate_whitelist(results: List[Dict[str, Any]], output_path: str, config: Dict[str, Any]):
    """Generate whitelist from check results"""

    def is_whitelist_supported(subrule_name: str) -> bool:
        """
        Check if a subrule supports whitelist based on config

        Args:
            subrule_name: The name of the subrule

        Returns:
            True if whitelist is supported, False otherwise (default: True)
        """
        # Map subrule names to config paths
        config_path_map = {
            'file_name': ['naming_conventions', 'file_name'],
            'macro': ['naming_conventions', 'macro'],
            'class_struct_and_union_name': ['naming_conventions', 'class_struct_and_union_name'],
            'enum_type': ['naming_conventions', 'enum_type'],
            'enum_value': ['naming_conventions', 'enum_value'],
            'constant': ['naming_conventions', 'constant'],
            'function': ['naming_conventions', 'function'],
            'member_function': ['naming_conventions', 'member_function'],
            'parameter': ['naming_conventions', 'parameter'],
            'local_variable': ['naming_conventions', 'local_variable'],
            'global_variable': ['naming_conventions', 'global_variable'],
            'static_global_variable': ['naming_conventions', 'static_global_variable'],
            'class_member_variable': ['naming_conventions', 'class_member_variable'],
            'struct_member_variable': ['naming_conventions', 'struct_member_variable'],
            'line_length': ['code_style', 'line_length'],
            'indentation': ['code_style', 'indentation'],
            'function_length': ['best_practices', 'function_length'],
            'cyclomatic_complexity': ['best_practices', 'cyclomatic_complexity'],
            'no_extern': ['best_practices', 'no_extern']
        }

        if subrule_name not in config_path_map:
            return True  # Default: support whitelist

        path = config_path_map[subrule_name]
        config_obj = config
        for key in path:
            if key in config_obj:
                config_obj = config_obj[key]
            else:
                return True  # Default: support whitelist if path not found

        # Check support_whitelist status from config
        if isinstance(config_obj, dict) and 'support_whitelist' in config_obj:
            return config_obj['support_whitelist']

        return True  # Default: support whitelist

    whitelist_to_add = {}

    for result in results:
        file = result['file']
        violations = result.get('violations', [])

        for violation in violations:
            from code_checker.base import Violation
            if isinstance(violation, Violation):
                rule_type = violation.rule_type
                identifier = violation.identifier
            else:
                # Backward compatibility: try to extract from string
                rule_type, identifier = CppCodeChecker.extract_identifier_from_message(str(violation))

            if rule_type and identifier:
                # Check if this rule supports whitelist
                if not is_whitelist_supported(rule_type):
                    continue  # Skip if whitelist is not supported

                if rule_type not in whitelist_to_add:
                    whitelist_to_add[rule_type] = []
                if identifier not in whitelist_to_add[rule_type]:
                    whitelist_to_add[rule_type].append(identifier)

    # Load existing whitelist
    existing_whitelist = WhitelistManager.load_whitelist(None)

    # Merge with existing whitelist
    for key, value in whitelist_to_add.items():
        if key in existing_whitelist:
            existing_whitelist[key] = list(set(existing_whitelist[key] + value))
        else:
            existing_whitelist[key] = value

    # Save whitelist
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(existing_whitelist, f, indent=2, ensure_ascii=False)

    # Print whitelist statistics
    print(f"\n{Colors.OKGREEN}白名单统计:{Colors.ENDC}")
    for key, value in whitelist_to_add.items():
        if value:
            print(f"  {key}: {len(value)} 项")
    print(f"\n{Colors.OKGREEN}白名单已生成到: {output_path}{Colors.ENDC}")


def main():
    """Main entry point"""

    # Set UTF-8 encoding for console output (for Windows compatibility)
    if sys.platform == 'win32':
        # Set console code page to UTF-8
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            # Set console output code page to UTF-8 (CP 65001)
            kernel32.SetConsoleOutputCP(65001)
            kernel32.SetConsoleCP(65001)
        except:
            pass

        # Set stdout and stderr encoding to UTF-8
        try:
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
        except (AttributeError, OSError):
            # Python < 3.7 or not supported, fallback
            import io
            try:
                sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
                sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
            except:
                # If all methods fail, at least warn the user
                pass

    parser = argparse.ArgumentParser(description='C++ 代码规范检查工具')
    parser.add_argument('-f', '--file', type=str, help='检查单个文件')
    parser.add_argument('-d', '--directory', type=str, help='检查目录或配置文件路径(need_check_code_dir.json)')
    parser.add_argument('-c', '--config', type=str, help='配置文件路径')
    parser.add_argument('-w', '--whitelist', type=str, help='白名单文件路径')
    parser.add_argument('-o', '--output', type=str, help='生成白名单的输出路径')
    parser.add_argument('--generate-whitelist', action='store_true', help='生成白名单')
    parser.add_argument('--show-filtered', action='store_true', help='显示白名单过滤的数量')
    parser.add_argument('--no-color', action='store_true', help='禁用颜色输出')

    args = parser.parse_args()

    # Detect if output is redirected to file
    is_output_redirected = not sys.stdout.isatty()

    # Windows console encoding warning
    if sys.platform == 'win32' and not is_output_redirected and not args.no_color:
        try:
            # Test if Chinese characters can be displayed correctly
            test_str = "测试"
            sys.stdout.write(test_str + "\r")
            sys.stdout.flush()
            # Try to read back what was written (this may fail in some terminals)
        except UnicodeEncodeError:
            # If encoding fails, suggest using --no-color
            print("\n提示：检测到中文显示可能不正常，建议使用 --no-color 参数禁用颜色输出")
            print("例如：python code_checker/cpp_checker.py -d tests/ --no-color\n")
        except:
            pass

    if args.no_color:
        Colors.disable()

    # Set default config file if not specified
    if not args.file and not args.directory:
        # Get default config file path using resource loader
        default_config_path = get_resource_path("config/need_check_code_dir.json")
        args.directory = default_config_path
        print(f"{Colors.OKBLUE}使用默认配置文件: {args.directory}{Colors.ENDC}")
        print()

    # Set default whitelist if not specified
    if args.whitelist is None:
        # Get default whitelist path using resource loader
        default_whitelist_path = get_resource_path("config/white_list.json")
        args.whitelist = default_whitelist_path

    # Initialize checker
    checker = CppCodeChecker(args.config, args.whitelist)

    # Check files
    if args.file:
        results = [checker.check_file(args.file, not args.generate_whitelist)]
    else:
        # Determine if directory argument is a JSON config file
        directory = args.directory
        ignore_dirs = None
        extensions = None

        if directory.endswith('.json'):
            # Load configuration from JSON file
            try:
                with open(directory, 'r', encoding='utf-8') as f:
                    config_data = json.load(f)

                # Extract parameters from config
                directory = config_data.get('root', '.')
                ignore_dirs = config_data.get('ignore', [])
                extensions = config_data.get('extensions', None)

                # Convert to absolute path if relative
                if not os.path.isabs(directory):
                    # Get the directory of the config file
                    config_dir = os.path.dirname(os.path.abspath(args.directory))
                    directory = os.path.join(config_dir, directory)

                # Convert to absolute path for display
                directory = os.path.abspath(directory)

                print(f"{Colors.OKBLUE}使用配置文件: {args.directory}{Colors.ENDC}")
                print(f"{Colors.OKBLUE}检查目录: {directory}{Colors.ENDC}")
                if ignore_dirs:
                    print(f"{Colors.OKBLUE}忽略目录: {', '.join(ignore_dirs)}{Colors.ENDC}")
                if extensions:
                    print(f"{Colors.OKBLUE}文件后缀: {', '.join(extensions)}{Colors.ENDC}")
                print()

            except FileNotFoundError:
                print(f"{Colors.FAIL}错误: 配置文件不存在: {directory}{Colors.ENDC}")
                return
            except json.JSONDecodeError as e:
                print(f"{Colors.FAIL}错误: 配置文件格式错误: {e}{Colors.ENDC}")
                return
            except Exception as e:
                print(f"{Colors.FAIL}错误: 读取配置文件失败: {e}{Colors.ENDC}")
                return

        results = checker.check_directory(directory, ignore_dirs=ignore_dirs, extensions=extensions, use_whitelist=not args.generate_whitelist)

    # Generate whitelist or print results
    if args.generate_whitelist:
        # Default output path if not specified
        if not args.output:
            # Get code_checker package directory
            code_checker_dir = os.path.dirname(os.path.abspath(__file__))
            default_output_path = os.path.join(code_checker_dir, "config", "white_list.json")

            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(default_output_path), exist_ok=True)

            generate_whitelist(results, default_output_path, checker.config)
        else:
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(args.output), exist_ok=True)
            generate_whitelist(results, args.output, checker.config)
    else:
        # Check if output to file is requested
        if args.output:
            # Disable colors when writing to file
            original_stdout = sys.stdout
            with open(args.output, 'w', encoding='utf-8') as f:
                sys.stdout = f
                Colors.disable()
                print_results(results)
                sys.stdout = original_stdout
        else:
            print_results(results)


if __name__ == '__main__':
    main()
