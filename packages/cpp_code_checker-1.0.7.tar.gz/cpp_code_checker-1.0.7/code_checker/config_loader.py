#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Configuration loader for C++ Code Checker
"""

import os
import json
from typing import Dict, Any, Optional
from code_checker.base import DEFAULT_CODING_STANDARDS
from code_checker import get_resource_path


class ConfigLoader:
    """Load configuration from file or use defaults"""

    @staticmethod
    def load_config(config_path: Optional[str] = None, script_dir: str = None) -> Dict[str, Any]:
        """
        Load configuration file

        Args:
            config_path: Path to configuration file (optional)
            script_dir: Directory where the script is located (optional)

        Returns:
            Configuration dictionary
        """
        # 1. If user specified a config file, use it
        if config_path and os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)

        # 2. Try to automatically find project config file
        if script_dir is None:
            script_dir = os.path.dirname(os.path.abspath(__file__))

        # Try to find config file using resource loader
        auto_config_path = get_resource_path("config/coding_standards.json")

        if auto_config_path and os.path.exists(auto_config_path):
            with open(auto_config_path, 'r', encoding='utf-8') as f:
                return json.load(f)

        # 3. If not found, use hardcoded default configuration
        return DEFAULT_CODING_STANDARDS
