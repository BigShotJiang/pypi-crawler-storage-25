# PyPI发布指南

本文档介绍如何将 `cpp-code-checker` 发布到 PyPI。

## 前置准备

### 1. 注册 PyPI 账号

1. 访问 https://pypi.org/account/register/
2. 注册账号并完成邮箱验证
3. 启用双因素认证（2FA）**必须**
4. 生成 API Token：
   - 进入 Account settings → API tokens
   - Create new token → 选择 "Entire account"
   - 复制生成的 token（只显示一次）

### 2. 安装发布工具

```bash
# 安装构建工具
pip install build

# 安装发布工具
pip install twine

# 或使用 uv
uv pip install build twine
```

### 3. 准备项目配置

#### 3.1 更新 pyproject.toml

项目已包含 `pyproject.toml`，需要确保配置完整：

```toml
[build-system]
requires = ["setuptools>=61.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "cpp-code-checker"
version = "1.0.0"
description = "C++代码规范检查工具 - 支持命名规范、代码风格和最佳实践检查"
readme = "README.md"
requires-python = ">=3.8"
license = {text = "MIT"}
authors = [
    {name = "LiKe", email = "ke_li2@ymtc.com"}
]
keywords = ["cpp", "code-checker", "lint", "code-quality", "static-analysis"]
classifiers = [
    "Development Status :: 5 - Production/Stable",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.8",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Topic :: Software Development :: Quality Assurance",
    "Topic :: Software Development :: Testing",
    "Topic :: Software Development :: Code Generators",
]

[project.urls]
Homepage = "https://gitee.com/like310101/cpp-code-checker"
Repository = "https://gitee.com/like310101/cpp-code-checker"
"Bug Tracker" = "https://gitee.com/like310101/cpp-code-checker/issues"
Documentation = "https://gitee.com/like310101/cpp-code-checker/blob/main/README.md"

[project.scripts]
cpp-code-checker = "code_checker:main"

[tool.setuptools.packages.find]
where = ["."]
include = ["code_checker*"]

[tool.setuptools.package-data]
code_checker = ["config/*.json", "*.md"]
```

**说明：**
- `config` 目录已移动到 `code_checker/` 包内，确保打包时正确包含
- 使用 `importlib.resources` 加载配置文件，支持 pip 安装、run.py 直接运行、VSCode 插件等多种使用方式

#### 3.2 创建 MANIFEST.in

创建 `MANIFEST.in` 文件，确保所有必要文件都被包含：

```
include README.md
include LICENSE
include pyproject.toml
include run.py
include run.bat
include run.sh
include PYPI_PUBLISH_GUIDE.md
include INSTALL_TROUBLESHOOTING.md
include OFFLINE_DEPLOY.md
include QUICKSTART.md
recursive-include code_checker *.py
recursive-include code_checker/config *.json
recursive-include code_checker/naming_conventions *.py
recursive-include code_checker/best_practices *.py
recursive-include code_checker/code_style *.py
exclude tests
exclude vscode-extension
exclude *.egg-info
exclude __pycache__
exclude .git
```

#### 3.3 准备 README.md

确保 README.md：
- 包含项目的详细描述
- 有安装和使用说明
- 有清晰的示例
- 使用 Markdown 格式

#### 3.4 准备 LICENSE

确保项目有许可证文件（如 MIT、Apache 2.0 等）。

---

## 发布步骤

### 步骤1：清理旧的构建文件

```bash
# 删除旧的构建目录
rm -rf dist/ build/ *.egg-info

# Windows
rd /s /q dist build *.egg-info
```

### 步骤2：构建包

```bash
# 使用 build 工具构建
python -m build
# 或
uv run build
```

构建完成后会生成：
- `dist/cpp-code-checker-1.0.0.tar.gz` (源码包)
- `dist/cpp_code_checker-1.0.0-py3-none-any.whl` (wheel包)

### 步骤3：检查包内容

```bash
# 查看wheel包内容
unzip -l dist/cpp_code_checker-1.0.0-py3-none-any.whl

# 查看源码包内容
tar -tzf dist/cpp-code-checker-1.0.0.tar.gz
```

### 步骤4：测试上传到 TestPyPI（推荐）

**首次发布必须先测试！**

#### 4.1 注册 TestPyPI 账号

1. 访问 https://test.pypi.org/account/register/
2. 注册账号（可以和 PyPI 使用相同账号）
3. 生成 API Token

#### 4.2 上传到 TestPyPI

```bash
# 使用 API Token 上传
twine upload --repository testpypi --username __token__ --password <your-testpypi-token> dist/*

# 或使用配置文件（更安全）
# 创建 ~/.pypirc 文件：
```

```ini
[pypi]
  username = __token__
  password = <your-pypi-token>

[testpypi]
  username = __token__
  password = <your-testpypi-token>
```

```bash
# 然后直接上传
twine upload --repository testpypi dist/*
```

#### 4.3 测试安装

```bash
# 从 TestPyPI 安装测试
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ cpp-code-checker

# 或使用 uv
uv pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ cpp-code-checker

# 测试运行
cpp-code-checker --help
```

### 步骤5：正式发布到 PyPI

如果测试无误，可以发布到正式的 PyPI：

```bash
twine upload --repository pypi dist/*
```

或使用配置文件：

```bash
twine upload dist/*
```

### 步骤6：验证发布

1. 访问 https://pypi.org/project/cpp-code-checker/
2. 确认页面显示正确
3. 测试安装：

```bash
pip install cpp-code-checker
# 或
uv pip install cpp-code-checker

# 测试运行
cpp-code-checker --help
```

---

## 版本管理

### 语义化版本

遵循 [Semantic Versioning](https://semver.org/)：

- `MAJOR.MINOR.PATCH`
- 例如：`1.0.0`, `1.0.1`, `1.1.0`, `2.0.0`

### 更新版本号

修改 `pyproject.toml` 中的版本号：

```toml
[project]
version = "1.0.1"  # 修改这里
```

然后重新构建和发布。

---

## 常见问题

### Q1: 上传失败，提示 "HTTPError: 400 Client Error"

**原因**：该版本号已存在

**解决**：更新版本号后重新构建

### Q2: 如何撤回已发布的版本？

**注意**：PyPI 不支持删除已发布的版本！

- 如果发现严重问题，发布新版本修复
- 如果只是元数据错误，可以在 PyPI 网站上编辑
- 如果账号被盗，立即联系 PyPI 支持

### Q3: 如何更新包？

1. 更新版本号
2. 清理旧的构建文件
3. 重新构建
4. 上传到 PyPI

### Q4: 如何删除 TestPyPI 上的包？

```bash
pip install twine
twine delete --repository testpypi cpp-code-checker 1.0.0
```

注意：删除后不能再使用相同的版本号。

---

## 安全最佳实践

1. **永远不要将 API Token 提交到 Git**
2. **使用环境变量或配置文件存储 Token**
3. **启用双因素认证（2FA）**
4. **定期更换 API Token**
5. **使用 TestPyPI 测试后再发布**

---

## 发布检查清单

发布前请确认：

- [ ] 版本号已更新
- [ ] README.md 内容完整
- [ ] LICENSE 文件存在
- [ ] pyproject.toml 配置完整
- [ ] 所有依赖都已声明（本项目无依赖）
- [ ] 在 TestPyPI 测试通过
- [ ] 包内容完整（包含所有必要文件）
- [ ] 安装后可以正常运行
- [ ] 准备好发布说明

---

## 相关资源

- [PyPI 官方文档](https://packaging.python.org/)
- [twine 文档](https://twine.readthedocs.io/)
- [TestPyPI](https://test.pypi.org/)
- [语义化版本](https://semver.org/)

---

## 示例：完整发布流程

```bash
# 1. 清理旧文件
rm -rf dist/ build/ *.egg-info

# 2. 构建包
python -m build

# 3. 检查包内容
unzip -l dist/cpp_code_checker-1.0.0-py3-none-any.whl

# 4. 上传到 TestPyPI 测试
python -m twine upload --repository testpypi dist/*

# 5. 测试安装
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ cpp-code-checker
cpp-code-checker --help

# 6. 正式发布
python -m twine upload dist/*

# 7. 验证发布
pip install cpp-code-checker
cpp-code-checker --help
python -m code_checker --help
```

---

## 发布后维护

1. **监控错误报告**：定期检查 GitHub/Gitee Issues
2. **及时修复问题**：发现问题后尽快发布修复版本
3. **更新文档**：及时更新 README 和文档
4. **响应反馈**：积极响应用户反馈

---

## 联系方式

如有问题，请联系：
- 作者：LiKe
- 邮箱：ke_li2@ymtc.com
- Gitee：https://gitee.com/like310101/cpp-code-checker
