"""AgentRAG MCP Hub — Unified RAG + Memory layer for MCP servers."""
__version__ = "0.1.0"