# Uno CLI

> **Agent tool gateway by ClawdChat** — access 2000+ real-world tools from the command line with one credential.

[![PyPI](https://img.shields.io/pypi/v/uno-cli.svg)](https://pypi.org/project/uno-cli/)
[![Python](https://img.shields.io/pypi/pyversions/uno-cli.svg)](https://pypi.org/project/uno-cli/)
[![License](https://img.shields.io/pypi/l/uno-cli.svg)](https://github.com/xray918/uno-mcp-cli/blob/main/LICENSE)

Zero runtime dependencies (Python 3.8+ stdlib only). Designed for both humans in a terminal and LLM agents orchestrating tool calls.

## Install

```bash
pip install uno-cli
```

## Quick start

```bash
uno login                             # device-code auth via ClawdChat SSO
uno search "weather"                  # find a tool
uno call weather-cn.weatherArea --args '{"area":"Beijing"}'
```

Credentials are stored at `~/.uno/credentials.json` (mode `600`).

## Core commands

| Command | Purpose |
|---|---|
| `uno login` / `uno logout` / `uno use` | Device-code auth, multi-account switching |
| `uno whoami` | Current user, credits, plan |
| `uno search <query>` | Hybrid keyword + semantic tool search |
| `uno tool get <slug>` | Full tool metadata |
| `uno call <slug> --args '{...}'` | Invoke a tool; returns `{success, data, meta}` |
| `uno rate <slug> <0-5>` | Rate a tool to improve ranking |
| `uno servers [-q ...]` | Browse servers / categories |
| `uno keys list / create / delete` | API key management |
| `uno disconnect <server>` | Revoke 3rd-party OAuth / API key |
| `uno health` | Liveness check |

All commands output JSON. Add `--compact` for single-line output (fewer tokens for LLM agents).

## Environment variables

| Variable | Purpose |
|---|---|
| `UNO_API_KEY` | Override stored credentials (useful for CI). |
| `UNO_API_URL` | Override API base URL (default `https://clawdtools.uno`). |
| `UNO_OAUTH_SCOPE` | OAuth scope requested at `login --start` (default `mcp:*`). Single-purpose skills narrow this to `mcp:<tool>`. |
| `UNO_ALLOWED_TOOLS` | Comma-separated glob whitelist enforced by `uno call`. Tools not matching any pattern are rejected with `tool_not_allowed`. Example: `gpt-image-2.*,time.*`. |
| `UNO_CALLER_SKILL` | Identifier (e.g. `gpt-image2`) appended to the `User-Agent` for attribution. |

### Scope enforcement for embedding skills

Single-purpose Cursor / Claude skills (such as `gpt-image2`) embed `uno-cli` as a dependency but must only call the one tool they advertise. The combination of `UNO_OAUTH_SCOPE` (narrowed scope at login) and `UNO_ALLOWED_TOOLS` (runtime glob whitelist) makes the CLI's behaviour match its declared metadata — a hard requirement for Clawhub / Skillhub security review.

```bash
export UNO_OAUTH_SCOPE="mcp:gpt-image-2"
export UNO_ALLOWED_TOOLS="gpt-image-2.*"
uno call gpt-image-2.gpt_image2_submit --args '{"prompt":"..."}'
```

Attempting to call anything outside the whitelist returns:

```json
{
  "error": "tool_not_allowed",
  "tool": "github.create_issue",
  "allowed": ["gpt-image-2.*"],
  "hint": "This skill is scoped to a subset of Uno tools. Install uno-cli separately to access the full 2000+ tool catalog."
}
```

## Python entry point

Agents that bootstrap the CLI without relying on `PATH` can use the module form:

```bash
python -m uno_cli search "weather"
```

## License

MIT © ClawdChat.
