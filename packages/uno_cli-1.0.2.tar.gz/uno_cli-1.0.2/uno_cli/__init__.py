"""Uno CLI — Agent tool gateway by ClawdChat.

Command-line access to 2000+ real-world tools behind a single credential.

Entry point::

    uno search "weather"
    uno call time.get_current_time --args '{"timezone":"UTC"}'

Python entry point (for agent bootstrapping)::

    python -m uno_cli search "weather"
"""

from uno_cli._version import __version__

__all__ = ["__version__"]
