"""Argparse + output-shape + User-Agent tests for uno_cli.cli."""

from __future__ import annotations

import json

import pytest

from uno_cli import cli
from uno_cli._version import __version__


# ── Argv preprocessing ─────────────────────────────────────────────


class TestPreprocessArgv:
    def test_hoists_compact_flag_to_front(self):
        assert cli._preprocess_argv(["search", "weather", "--compact"]) == [
            "--compact",
            "search",
            "weather",
        ]

    def test_hoists_base_url_with_value(self):
        out = cli._preprocess_argv(["search", "weather", "--base-url", "http://x"])
        assert out == ["--base-url", "http://x", "search", "weather"]

    def test_rewrites_poll_with_dash_prefix_value(self):
        """Device codes can start with ``-``; argparse would misread them as flags."""
        assert cli._preprocess_argv(["login", "--poll", "-abc"]) == [
            "login",
            "--poll=-abc",
        ]

    def test_keeps_already_valid_input_untouched(self):
        assert cli._preprocess_argv(["--compact", "whoami"]) == ["--compact", "whoami"]


# ── Parser structure ───────────────────────────────────────────────


class TestParser:
    def test_version_flag_matches_package(self, capsys):
        parser = cli.build_parser()
        with pytest.raises(SystemExit):
            parser.parse_args(["--version"])
        out = capsys.readouterr().out
        assert __version__ in out

    def test_subcommands_are_registered(self):
        parser = cli.build_parser()
        # Subparsers live at position 2 (after --compact, --base-url).
        subparsers_action = next(
            a for a in parser._actions if isinstance(a, cli.argparse._SubParsersAction)
        )
        expected = {
            "login", "logout", "use", "whoami", "search", "tool",
            "call", "rate", "servers", "keys", "health", "disconnect",
        }
        assert expected <= set(subparsers_action.choices.keys())


# ── User-Agent header ──────────────────────────────────────────────


class TestUserAgent:
    def test_default_user_agent_shape(self, monkeypatch):
        monkeypatch.delenv(cli.CALLER_SKILL_ENV, raising=False)
        ua = cli._user_agent()
        assert ua.startswith(f"uno-cli/{__version__}")
        assert "skill/" not in ua

    def test_caller_skill_is_appended(self, monkeypatch):
        monkeypatch.setenv(cli.CALLER_SKILL_ENV, "gpt-image2")
        ua = cli._user_agent()
        assert "skill/gpt-image2" in ua

    def test_caller_skill_is_sanitized(self, monkeypatch):
        """Only alnum + ``-_.`` survive, truncated at 64 chars — no header smuggling."""
        monkeypatch.setenv(cli.CALLER_SKILL_ENV, "bad\r\nheader: evil/slash")
        ua = cli._user_agent()
        assert "\r" not in ua and "\n" not in ua and ":" not in ua and "/evil" not in ua
        assert "skill/badheaderevilslash" in ua

    def test_caller_skill_truncated_at_64_chars(self, monkeypatch):
        monkeypatch.setenv(cli.CALLER_SKILL_ENV, "a" * 200)
        ua = cli._user_agent()
        # The sanitiser truncates to at most 64 chars.
        assert "skill/" + ("a" * 64) in ua
        assert "skill/" + ("a" * 65) not in ua


# ── Output helpers & hints ─────────────────────────────────────────


class TestErrorHints:
    @pytest.mark.parametrize("msg,expected", [
        ("insufficient_credits", "Out of credits."),
        ("unauthorized", "Login required."),
        ("tool_not_found", "Try: uno search"),
        ("tool_not_allowed", "outside this skill's declared scope."),
        ("rate limit exceeded", "Rate limited."),
        ("totally unrelated error text", ""),
    ])
    def test_match_hint(self, msg, expected):
        hint = cli._match_hint(msg)
        if expected:
            assert expected in hint
        else:
            assert hint == ""

    def test_format_api_error_passes_through_detail_list(self):
        """FastAPI-style 422 validation errors arrive as ``{"detail": [...]}``."""
        body = {"detail": [{"loc": ["body", "tool"], "msg": "field required"}]}
        out = cli._format_api_error(422, body)
        assert out["status"] == 422
        assert "body → tool" in out["error"]
        assert "field required" in out["error"]

    def test_format_api_error_str_body(self):
        out = cli._format_api_error(500, "server exploded")
        assert out["error"] == "server exploded"


# ── JSON output shape of _out ──────────────────────────────────────


class TestOutShape:
    def test_default_output_is_pretty(self, capsys):
        # Ensure no lingering compact state from previous tests
        if hasattr(cli._out, "compact"):
            cli._out.compact = False
        cli._out({"a": 1})
        out = capsys.readouterr().out
        assert "\n" in out  # pretty-printed has newlines
        assert json.loads(out) == {"a": 1}

    def test_compact_output_is_single_line(self, capsys):
        cli._out.compact = True
        try:
            cli._out({"a": 1, "b": [1, 2]})
            out = capsys.readouterr().out
            assert out.count("\n") == 1  # one trailing newline from print
            assert json.loads(out) == {"a": 1, "b": [1, 2]}
        finally:
            cli._out.compact = False
