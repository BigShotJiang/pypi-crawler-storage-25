"""Auth flow tests — file I/O + OAuth scope propagation, all mocked."""

from __future__ import annotations

import json
import os

import pytest

from uno_cli import cli


@pytest.fixture
def isolated_cred_home(monkeypatch, tmp_path):
    """Redirect the credentials file into a per-test temp directory."""
    cred_dir = tmp_path / ".uno"
    cred_file = cred_dir / "credentials.json"
    monkeypatch.setattr(cli, "CRED_DIR", str(cred_dir))
    monkeypatch.setattr(cli, "CRED_FILE", str(cred_file))
    return cred_file


class TestCredentialRoundtrip:
    def test_save_then_load(self, isolated_cred_home):
        auth = cli.AuthManager()
        auth.save_account("uno_key_abc", "Alice", "alice@example.com", "u_1")
        assert auth.load_key() == "uno_key_abc"

        data = json.loads(isolated_cred_home.read_text())
        assert data[0]["api_key"] == "uno_key_abc"
        assert data[0]["email"] == "alice@example.com"
        assert data[0]["active"] is True

    def test_env_key_overrides_stored(self, isolated_cred_home, monkeypatch):
        auth = cli.AuthManager()
        auth.save_account("uno_stored", "Alice", "a@e.com")
        monkeypatch.setenv("UNO_API_KEY", "uno_from_env")
        assert auth.load_key() == "uno_from_env"

    def test_multi_account_switch(self, isolated_cred_home):
        auth = cli.AuthManager()
        auth.save_account("key_a", "Alice", "a@e.com")
        auth.save_account("key_b", "Bob", "b@e.com")
        assert auth.load_key() == "key_b"  # newest becomes active

        auth.switch("a@e.com")
        assert auth.load_key() == "key_a"

    def test_remove_account_all(self, isolated_cred_home):
        auth = cli.AuthManager()
        auth.save_account("key_a", "Alice", "a@e.com")
        auth.save_account("key_b", "Bob", "b@e.com")
        auth.remove_account(all_=True)
        assert auth.load_key() == ""


class TestDeviceCodeScope:
    """``login_device_start`` must request whatever ``UNO_OAUTH_SCOPE`` is set to."""

    def test_scope_from_env_is_sent(self, monkeypatch, isolated_cred_home):
        monkeypatch.setenv("UNO_OAUTH_SCOPE", "mcp:gpt-image-2")

        captured = {}

        class _FakeAPI:
            def __init__(self, *a, **kw):
                pass

            def post(self, path, data, timeout=60):
                captured["path"] = path
                captured["data"] = data
                return {
                    "device_code": "dc_xyz",
                    "user_code": "USER-CODE",
                    "verification_uri": "https://clawdtools.uno/device",
                    "expires_in": 600,
                    "interval": 5,
                }

        monkeypatch.setattr(cli, "UnoAPI", _FakeAPI)

        result = cli.AuthManager().login_device_start()
        assert captured["path"] == "/oauth/device/code"
        assert captured["data"]["scope"] == "mcp:gpt-image-2"
        assert result["scope"] == "mcp:gpt-image-2"
        assert result["verification_uri_complete"].endswith("?code=USER-CODE")

    def test_default_scope_is_wildcard(self, monkeypatch, isolated_cred_home):
        monkeypatch.delenv("UNO_OAUTH_SCOPE", raising=False)
        captured = {}

        class _FakeAPI:
            def __init__(self, *a, **kw):
                pass

            def post(self, path, data, timeout=60):
                captured["data"] = data
                return {
                    "device_code": "dc",
                    "user_code": "UC",
                    "verification_uri": "https://clawdtools.uno/device",
                    "expires_in": 600,
                    "interval": 5,
                }

        monkeypatch.setattr(cli, "UnoAPI", _FakeAPI)
        cli.AuthManager().login_device_start()
        assert captured["data"]["scope"] == "mcp:*"


class TestLoginWithKey:
    def test_verifies_key_against_auth_me(self, monkeypatch, isolated_cred_home):
        class _FakeAPI:
            def __init__(self, *a, **kw):
                pass

            def get(self, path, params=None):
                assert path == "/v1/auth/me"
                return {"name": "Alice", "email": "a@e.com", "id": "u_1"}

        monkeypatch.setattr(cli, "UnoAPI", _FakeAPI)
        result = cli.AuthManager().login_with_key("uno_key_abc")
        assert result["success"] is True
        assert result["name"] == "Alice"
        assert result["email"] == "a@e.com"
        assert result["credential_stored_at"] == cli.CRED_FILE
        assert result["credential_file_mode"] == "0600"
        # Critical: the raw API key must never appear in the login response
        # (it is persisted to the credentials file below, but never echoed).
        import json as _json
        assert "uno_key_abc" not in _json.dumps(result)
        with open(cli.CRED_FILE) as f:
            data = json.load(f)
        assert data[0]["api_key"] == "uno_key_abc"

    def test_invalid_key_returns_error(self, monkeypatch, isolated_cred_home):
        class _FakeAPI:
            def __init__(self, *a, **kw):
                pass

            def get(self, path, params=None):
                raise cli.APIError(401, {"detail": "invalid api key"})

        monkeypatch.setattr(cli, "UnoAPI", _FakeAPI)
        result = cli.AuthManager().login_with_key("uno_bad")
        assert "error" in result
        # Make sure nothing was persisted
        assert not os.path.exists(cli.CRED_FILE)
