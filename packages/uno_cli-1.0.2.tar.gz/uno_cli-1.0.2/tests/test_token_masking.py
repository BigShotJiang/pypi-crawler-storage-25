"""Security-posture tests — stdout must NEVER contain a full API token.

Any raw token would let an attacker who can read the terminal, shell history,
or an agent's stdout buffer hijack the user's account. The CLI funnels every
response through ``_strip_secrets`` in ``_out`` so the invariant holds even
if a future contributor forgets to mask manually.
"""

from __future__ import annotations

import io
import json

import pytest

from uno_cli import cli


RAW_TOKEN = "uno_abcdefghijklmnopqrstuvwxyz0123456789WXYZ"


# ── _mask_token ────────────────────────────────────────────────────


class TestMaskToken:
    def test_long_token_shows_prefix_and_suffix_only(self):
        out = cli._mask_token(RAW_TOKEN)
        assert out.startswith(RAW_TOKEN[:8])
        assert out.endswith(RAW_TOKEN[-4:])
        assert "..." in out
        assert RAW_TOKEN not in out

    def test_short_value_becomes_triple_asterisk(self):
        assert cli._mask_token("short") == "***"

    def test_none_stays_none(self):
        assert cli._mask_token(None) is None

    def test_non_string_values_unchanged(self):
        assert cli._mask_token(42) == 42
        assert cli._mask_token(["list"]) == ["list"]


# ── _strip_secrets ─────────────────────────────────────────────────


class TestStripSecrets:
    def test_top_level_api_key_field_is_masked(self):
        out = cli._strip_secrets({"api_key": RAW_TOKEN, "name": "alice"})
        assert out["api_key"] != RAW_TOKEN
        assert RAW_TOKEN not in json.dumps(out)
        assert out["name"] == "alice"

    @pytest.mark.parametrize(
        "field",
        [
            "api_key",
            "apiKey",
            "API_KEY",
            "access_token",
            "refresh_token",
            "secret",
            "client_secret",
            "password",
            "token",
        ],
    )
    def test_known_secret_field_names_are_all_masked(self, field):
        out = cli._strip_secrets({field: RAW_TOKEN})
        assert RAW_TOKEN not in json.dumps(out), f"{field} not masked"

    def test_nested_dict_secret_is_masked(self):
        out = cli._strip_secrets({"data": {"api_key": RAW_TOKEN, "email": "a@b.c"}})
        assert RAW_TOKEN not in json.dumps(out)
        assert out["data"]["email"] == "a@b.c"

    def test_list_of_dicts_is_masked(self):
        items = [
            {"name": "k1", "api_key": RAW_TOKEN},
            {"name": "k2", "api_key": RAW_TOKEN + "_2"},
        ]
        out = cli._strip_secrets({"keys": items})
        assert RAW_TOKEN not in json.dumps(out)
        assert out["keys"][0]["name"] == "k1"

    def test_non_secret_lookalike_field_untouched(self):
        out = cli._strip_secrets({"description": "the api_key field is secret"})
        assert out["description"] == "the api_key field is secret"

    def test_key_id_is_not_a_secret(self):
        out = cli._strip_secrets({"key_id": "kid_abc", "description": "x"})
        assert out["key_id"] == "kid_abc"


# ── _out chokepoint ────────────────────────────────────────────────


class TestOutChokepoint:
    def test_out_masks_api_key_before_printing(self, capsys):
        cli._out({"success": True, "api_key": RAW_TOKEN})
        captured = capsys.readouterr()
        assert RAW_TOKEN not in captured.out
        payload = json.loads(captured.out)
        assert payload["success"] is True
        assert payload["api_key"] != RAW_TOKEN

    def test_out_masks_nested_access_token(self, capsys):
        cli._out({"data": {"tokens": [{"access_token": RAW_TOKEN}]}})
        out = capsys.readouterr().out
        assert RAW_TOKEN not in out

    def test_out_preserves_non_secret_structure(self, capsys):
        cli._out({"success": True, "data": {"name": "alice", "credits": 500}})
        payload = json.loads(capsys.readouterr().out)
        assert payload["data"]["name"] == "alice"
        assert payload["data"]["credits"] == 500


# ── Callsite regression ────────────────────────────────────────────


class TestLoginReturnShape:
    """The return dicts from AuthManager login paths must not carry the raw
    token even if _out is bypassed (defense in depth). We verify by building a
    real return payload the way ``login_device_poll`` would."""

    def test_login_device_poll_success_shape_has_no_api_key(self):
        source = (cli.__file__,)
        import pathlib

        text = pathlib.Path(source[0]).read_text(encoding="utf-8")
        # Confirm the obvious leak patterns are gone:
        assert '"api_key": access_token' not in text, (
            "login_device_poll must not return the raw access_token under an "
            "api_key field; agents should read ~/.uno/credentials.json instead."
        )

    def test_credential_stored_at_is_advertised(self):
        """Positive marker: successful login responses include a
        ``credential_stored_at`` field pointing at the file on disk."""
        import pathlib

        text = pathlib.Path(cli.__file__).read_text(encoding="utf-8")
        assert text.count('"credential_stored_at": CRED_FILE') >= 3, (
            "All login success paths (login_with_key + login_device_poll main "
            "+ fallback) should advertise the credential file location so "
            "callers know where the token actually lives."
        )
