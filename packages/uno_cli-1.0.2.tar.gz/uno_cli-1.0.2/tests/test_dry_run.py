"""--dry-run preview tests.

``uno call --dry-run <tool>`` is the primary user-confirmation surface: it
formats the planned invocation (tool + arguments) as JSON without reading any
credential, opening any socket, or spending any credit. These tests are the
safety net that guarantees the dry-run remains strictly local.
"""

from __future__ import annotations

import argparse
import json

import pytest

from uno_cli import cli


# ── Shared fake API that explodes if ever called ───────────────────


class _PanicAPI:
    """Any method on this class raises — a dry-run must never hit it."""

    def __init__(self, *a, **kw):
        raise AssertionError(
            "dry-run called the network client; it must not touch the network"
        )


# ── Parser surface ─────────────────────────────────────────────────


class TestDryRunFlag:
    def test_dry_run_flag_defaults_to_false(self):
        parser = cli.build_parser()
        args = parser.parse_args(["call", "weather.get", "--args", "{}"])
        assert args.dry_run is False

    def test_dry_run_flag_parsed_when_present(self):
        parser = cli.build_parser()
        args = parser.parse_args(["call", "--dry-run", "weather.get", "--args", "{}"])
        assert args.dry_run is True

    def test_dry_run_flag_trailing_position_also_works(self):
        parser = cli.build_parser()
        args = parser.parse_args(["call", "weather.get", "--args", "{}", "--dry-run"])
        assert args.dry_run is True


# ── cmd_call dry-run path ──────────────────────────────────────────


class TestDryRunCall:
    def _run_dry_run(self, monkeypatch, capsys, *, tool, args_json):
        """Invoke cmd_call in dry-run mode; any network attempt explodes."""
        # If _get_api / UnoAPI ever gets called, the test fails loudly.
        monkeypatch.setattr(cli, "_get_api", lambda a: _PanicAPI())
        monkeypatch.setattr(cli, "UnoAPI", _PanicAPI)

        ns = argparse.Namespace(
            tool=tool,
            args=args_json,
            timeout=60,
            dry_run=True,
            base_url="https://clawdtools.uno",
        )
        cli.cmd_call(ns)
        return json.loads(capsys.readouterr().out)

    def test_dry_run_returns_preview_without_network(self, monkeypatch, capsys):
        out = self._run_dry_run(
            monkeypatch,
            capsys,
            tool="weather-free.weather_now",
            args_json='{"city": "Beijing"}',
        )
        assert out["success"] is True
        assert out["dry_run"] is True
        assert out["preview"]["tool"] == "weather-free.weather_now"
        assert out["preview"]["arguments"] == {"city": "Beijing"}
        assert out["preview"]["timeout_seconds"] == 60
        assert "No network request" in out["note"]

    def test_dry_run_with_empty_args_returns_empty_dict(self, monkeypatch, capsys):
        out = self._run_dry_run(
            monkeypatch, capsys, tool="time.get_current_time", args_json=None
        )
        assert out["preview"]["arguments"] == {}

    def test_dry_run_without_credentials_still_works(self, monkeypatch, capsys):
        """Dry-run must not call _get_api, so even unauthenticated users can
        preview an invocation."""

        def _panic(*a, **kw):
            raise AssertionError("dry-run read credentials; it must not.")

        monkeypatch.setattr(cli.AuthManager, "load_key", _panic)
        self._run_dry_run(
            monkeypatch,
            capsys,
            tool="weather-free.weather_now",
            args_json='{"city": "Tokyo"}',
        )

    def test_dry_run_respects_scope_guard(self, monkeypatch, capsys):
        """Dry-run should still be blocked by UNO_ALLOWED_TOOLS — a skill
        scoped to gpt-image-2 should not be able to preview a call to github
        even in dry-run mode."""
        monkeypatch.setenv("UNO_ALLOWED_TOOLS", "gpt-image-2.*")
        monkeypatch.setattr(cli, "_get_api", lambda a: _PanicAPI())

        ns = argparse.Namespace(
            tool="github.create_issue",
            args='{"title": "x"}',
            timeout=60,
            dry_run=True,
            base_url="https://clawdtools.uno",
        )
        with pytest.raises(SystemExit) as excinfo:
            cli.cmd_call(ns)
        assert excinfo.value.code == 1
        out = json.loads(capsys.readouterr().out)
        assert out["error"] == "tool_not_allowed"

    def test_dry_run_preview_does_not_leak_secrets(self, monkeypatch, capsys):
        """If the user passes an api_key-looking arg, the normal output
        stripper should still redact it on the way out."""
        out = self._run_dry_run(
            monkeypatch,
            capsys,
            tool="some-tool.run",
            args_json='{"api_key": "uno_should_be_masked_longlonglong"}',
        )
        # _out passes everything through _strip_secrets; the api_key field
        # inside preview.arguments is a legitimate tool arg, but the masker
        # errs on the side of caution by key-name.
        assert "uno_should_be_masked_longlonglong" not in json.dumps(out)
