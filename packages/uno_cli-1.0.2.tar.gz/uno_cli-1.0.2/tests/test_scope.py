"""Unit tests for scope enforcement (UNO_OAUTH_SCOPE + UNO_ALLOWED_TOOLS).

These tests drive ``uno_cli.cli`` without touching the network. They are the
safety net that lets single-purpose skills like ``gpt-image2`` rely on the CLI
to enforce their declared scope.
"""

from __future__ import annotations

import json

import pytest

from uno_cli import cli


# ── UNO_ALLOWED_TOOLS glob matching ────────────────────────────────


class TestAllowedToolsParsing:
    def test_empty_value_means_no_restriction(self):
        assert cli._parse_allowed_tools("") == []
        assert cli._parse_allowed_tools("   ") == []

    def test_comma_separated(self):
        assert cli._parse_allowed_tools("a,b,c") == ["a", "b", "c"]

    def test_strips_whitespace_around_each_entry(self):
        assert cli._parse_allowed_tools(" a , b  ,c ") == ["a", "b", "c"]

    def test_drops_empty_entries(self):
        assert cli._parse_allowed_tools("a,,b,") == ["a", "b"]


class TestToolAllowedMatching:
    def test_empty_patterns_allow_everything(self):
        assert cli._is_tool_allowed("anything.at_all", []) is True

    def test_exact_match(self):
        assert cli._is_tool_allowed(
            "gpt-image-2.gpt_image2_submit",
            ["gpt-image-2.gpt_image2_submit"],
        )
        assert not cli._is_tool_allowed(
            "github.create_issue",
            ["gpt-image-2.gpt_image2_submit"],
        )

    def test_server_wildcard_match(self):
        patterns = ["gpt-image-2.*"]
        assert cli._is_tool_allowed("gpt-image-2.gpt_image2_submit", patterns)
        assert cli._is_tool_allowed("gpt-image-2.gpt_image2_result", patterns)
        assert not cli._is_tool_allowed("github.create_issue", patterns)

    def test_multiple_patterns_are_union(self):
        patterns = ["gpt-image-2.*", "time.*"]
        assert cli._is_tool_allowed("time.get_current_time", patterns)
        assert cli._is_tool_allowed("gpt-image-2.gpt_image2_submit", patterns)
        assert not cli._is_tool_allowed("github.create_issue", patterns)

    def test_case_sensitive(self):
        """fnmatchcase: tool slugs are case-sensitive — protects against accidental broadening."""
        assert not cli._is_tool_allowed("GPT-IMAGE-2.foo", ["gpt-image-2.*"])


# ── UNO_OAUTH_SCOPE env var ────────────────────────────────────────


class TestOauthScope:
    def test_default_scope(self, monkeypatch):
        monkeypatch.delenv("UNO_OAUTH_SCOPE", raising=False)
        assert cli._get_oauth_scope() == "mcp:*"

    def test_env_override(self, monkeypatch):
        monkeypatch.setenv("UNO_OAUTH_SCOPE", "mcp:gpt-image-2")
        assert cli._get_oauth_scope() == "mcp:gpt-image-2"

    def test_empty_env_falls_back_to_default(self, monkeypatch):
        monkeypatch.setenv("UNO_OAUTH_SCOPE", "   ")
        assert cli._get_oauth_scope() == "mcp:*"


# ── End-to-end cmd_call whitelist enforcement ──────────────────────


class _DummyArgs:
    """Lightweight stand-in for argparse.Namespace in cmd_call tests."""

    def __init__(self, tool, args_json=None):
        self.tool = tool
        self.args = args_json
        self.timeout = 60
        self.base_url = "https://clawdtools.uno"


@pytest.fixture(autouse=True)
def output_buffer(monkeypatch):
    """Capture ``_out`` into a list so tests can inspect it."""
    buf = []

    def fake_out(obj):
        buf.append(obj)
        # Still emit to stdout for visibility when running pytest -s
        print(json.dumps(obj, ensure_ascii=False))

    monkeypatch.setattr(cli, "_out", fake_out)
    return buf


class TestCmdCallScopeEnforcement:
    def test_tool_outside_whitelist_is_rejected_before_network(
        self, monkeypatch, output_buffer
    ):
        """The network layer must never be reached when the tool is blocked."""

        def _explode(*_a, **_kw):
            raise AssertionError("Network should not be touched for blocked tool")

        monkeypatch.setattr(cli, "_get_api", _explode)
        monkeypatch.setenv("UNO_ALLOWED_TOOLS", "gpt-image-2.*")

        with pytest.raises(SystemExit) as excinfo:
            cli.cmd_call(_DummyArgs("github.create_issue"))
        assert excinfo.value.code == 1

        assert len(output_buffer) == 1
        payload = output_buffer[0]
        assert payload["error"] == "tool_not_allowed"
        assert payload["tool"] == "github.create_issue"
        assert payload["allowed"] == ["gpt-image-2.*"]
        assert "uno-cli" in payload["hint"]

    def test_tool_inside_whitelist_reaches_network_layer(self, monkeypatch):
        """When the tool matches, cmd_call must fall through to the API call."""
        monkeypatch.setenv("UNO_ALLOWED_TOOLS", "gpt-image-2.*")

        seen = {}

        class _FakeAPI:
            def post(self, path, data, timeout=60):
                seen["path"] = path
                seen["data"] = data
                return {"data": {"ok": True}, "meta": {"credits_used": 300}}

        monkeypatch.setattr(cli, "_get_api", lambda args: _FakeAPI())

        cli.cmd_call(_DummyArgs("gpt-image-2.gpt_image2_submit", args_json='{"prompt":"x"}'))
        assert seen["path"] == "/v1/call"
        assert seen["data"]["tool"] == "gpt-image-2.gpt_image2_submit"

    def test_empty_whitelist_allows_any_tool(self, monkeypatch):
        monkeypatch.delenv("UNO_ALLOWED_TOOLS", raising=False)

        class _FakeAPI:
            def post(self, path, data, timeout=60):
                return {"data": {}, "meta": {}}

        monkeypatch.setattr(cli, "_get_api", lambda args: _FakeAPI())
        cli.cmd_call(_DummyArgs("github.create_issue"))
