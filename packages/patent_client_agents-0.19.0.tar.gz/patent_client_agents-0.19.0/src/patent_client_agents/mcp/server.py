"""Standalone patent-client-agents MCP server entry point.

Run via the ``patent-client-agents-mcp`` console script (installed by the ``[mcp]``
extra of the ``patent-client-agents`` distribution), or directly::

    python -m patent_client_agents.mcp.server
    fastmcp run patent_client_agents.mcp.server:mcp

Stdio is the default transport. Pass ``--transport http`` (or use
``fastmcp run``) for HTTP mode.

Auth is env-driven via ``law_tools_core.mcp.auth.make_auth``. For stdio
and local development, leave the auth env vars unset and the server
runs without authentication. For HTTP deployments, set
``LAW_TOOLS_CORE_PUBLIC_URL`` plus the Google OAuth or static bearer
env vars described in :mod:`law_tools_core.mcp.auth`.

Hosted/multi-instance deployments that need persistent OAuth/DCR
client state (Firestore-backed storage, rate limiting, etc.) belong in
a separate deploy package (see ``patent-mcp-deploy``) that builds its
own server from the same ``build_server`` + ``ip_mcp`` building blocks.

Note on naming: the PyPI distribution is ``patent-client-agents``; the import module
stays ``patent_client_agents`` (PyYAML/yaml, scikit-learn/sklearn style decoupling).
"""

from __future__ import annotations

import argparse
import sys

from law_tools_core.mcp import make_auth
from law_tools_core.mcp.server_factory import build_server
from patent_client_agents import __version__

from . import ip_mcp

mcp = build_server(
    name="patent-client-agents",
    instructions=(
        "Patent and IP data connectors: USPTO (ODP, PPUBS, Assignments, "
        "Office Actions, PTAB, Petitions, Bulk Data, TSDR, Trademark "
        "Assignments), EPO OPS, Google Patents, CPC, MPEP, TMEP, CanLII "
        "(Canadian courts, tribunals, and IP statutes), and WIPO Lex "
        "(global IP statute / treaty / judgment database)."
    ),
    auth=make_auth(),
)
mcp.mount(ip_mcp)


def main(argv: list[str] | None = None) -> None:
    """Entry point for the ``patent-client-agents-mcp`` console script.

    No args ⇒ run the MCP server on stdio (the default behavior MCP
    clients expect). ``--version`` and ``--help`` print and exit.
    """
    parser = argparse.ArgumentParser(
        prog="patent-client-agents-mcp",
        description=(
            "Run the patent-client-agents MCP server on stdio. Exposes ~50 patent/IP "
            "tools from USPTO, EPO, Google Patents, MPEP, and CanLII to any "
            "MCP client. See docs/installation.md for client configuration."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"patent-client-agents {__version__}",
    )
    parser.parse_args(argv)
    try:
        mcp.run()
    except KeyboardInterrupt:
        sys.exit(0)


if __name__ == "__main__":
    main()
