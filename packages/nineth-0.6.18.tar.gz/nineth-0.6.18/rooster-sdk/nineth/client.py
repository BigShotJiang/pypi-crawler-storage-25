"""Python client for the 1984 model API."""

from __future__ import annotations

import asyncio
import copy
import json
import os
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional, Tuple, Union

import httpx

from nineth._constants import (
    DEFAULT_BASE_URL,
    DEFAULT_STREAM_TIMEOUT,
    DEFAULT_TIMEOUT,
    AVAILABLE_MODELS,
    _API_KEY_HEADER,
)
from nineth._helpers import (
    _build_payload,
    _coerce_requested_response_event,
    _coerce_requested_response_format,
    _parse_sse_lines,
    _raise_for_status,
    _raise_for_stream_event,
    _trim_callback_response,
    _trim_event,
    _trim_response,
)
from nineth._local_services import LocalServiceRegistry
from nineth._streaming import _coalesce_deltas, _normalize_public_stream_event
from nineth._streaming import _service_progress_event


class NinethAPIError(RuntimeError):
    """Raised when the API returns an error response."""


def _prepare_callback_include_service(
    include_service: Optional[List[Any]],
) -> Tuple[LocalServiceRegistry, Optional[List[Any]]]:
    local_registry, server_paths = LocalServiceRegistry.from_paths(include_service)
    payload_include_service: List[Any] = list(server_paths)
    if local_registry.has_services:
        payload_include_service.extend(local_registry.schemas)
    return local_registry, payload_include_service or None


def _normalize_client_service_result(result: Any) -> Tuple[bool, Any, Optional[str]]:
    if isinstance(result, dict) and result.get("success") is False:
        return False, result, str(result.get("error") or "Client-managed service reported failure.")
    return True, result, None


def _build_client_service_results(
    local_registry: LocalServiceRegistry,
    pending_client_calls: List[Dict[str, Any]],
    process_id: str,
) -> List[Dict[str, Any]]:
    local_registry.set_context_id(process_id)
    results: List[Dict[str, Any]] = []
    for pending in pending_client_calls:
        call_id = str(pending.get("call_id", "")).strip()
        service_name = str(pending.get("service_name", "")).strip()
        params = pending.get("params", {}) if isinstance(pending.get("params", {}), dict) else {}
        entry: Dict[str, Any] = {
            "call_id": call_id,
            "service_name": service_name,
            "success": False,
        }
        try:
            raw_result = local_registry.execute(service_name, params)
            success, result, error = _normalize_client_service_result(raw_result)
            entry["success"] = success
            if success:
                entry["result"] = result
            else:
                entry["result"] = result
                entry["error"] = error
        except Exception as exc:
            entry["error"] = str(exc)
        results.append(entry)
    return results


async def _abuild_client_service_results(
    local_registry: LocalServiceRegistry,
    pending_client_calls: List[Dict[str, Any]],
    process_id: str,
) -> List[Dict[str, Any]]:
    local_registry.set_context_id(process_id)
    async def _run_pending_call(pending: Dict[str, Any]) -> Dict[str, Any]:
        call_id = str(pending.get("call_id", "")).strip()
        service_name = str(pending.get("service_name", "")).strip()
        params = pending.get("params", {}) if isinstance(pending.get("params", {}), dict) else {}
        entry: Dict[str, Any] = {
            "call_id": call_id,
            "service_name": service_name,
            "success": False,
        }
        try:
            raw_result = await local_registry.aexecute(service_name, params)
            success, result, error = _normalize_client_service_result(raw_result)
            entry["success"] = success
            if success:
                entry["result"] = result
            else:
                entry["result"] = result
                entry["error"] = error
        except Exception as exc:
            entry["error"] = str(exc)
        return entry

    if not pending_client_calls:
        return []

    return list(await asyncio.gather(*(_run_pending_call(pending) for pending in pending_client_calls)))


def _callback_result_event(body: Dict[str, Any]) -> Dict[str, Any]:
    result_body = {
        "process_id": body.get("process_id"),
        "final_response": body.get("final_response", ""),
        "iterations": body.get("iterations", 0),
        "usage": body.get("usage", {}),
        "thinking": body.get("thinking", []),
        "service_calls": body.get("service_calls", []),
        "service_responses": body.get("service_responses", []),
        "artifacts": body.get("artifacts", []),
        "events": body.get("events", []),
    }
    return {
        "type": "result",
        "process_id": body.get("process_id", "pending"),
        "iteration": body.get("iterations", 0),
        "data": _trim_response(result_body, cache_enabled=False),
    }


def _missing_stream_result_delta(final_response: Any, emitted_text: str) -> str:
    text = str(final_response or "")
    if not text:
        return ""
    if not emitted_text:
        return text
    if text == emitted_text or emitted_text.endswith(text) or emitted_text.startswith(text):
        return ""
    if text.startswith(emitted_text):
        return text[len(emitted_text):]
    return ""


def _allowed_builtin_service_names(payload: Dict[str, Any]) -> set[str] | None:
    if not payload.get("services"):
        if payload.get("include_service"):
            return None
        return set()

    service_names = payload.get("service_names")
    if isinstance(service_names, list):
        return {
            name
            for raw_name in service_names
            if (name := str(raw_name).strip()) and name != "done"
        }

    return None


def _normalize_inbound_address(email_messaging: Optional[Dict[str, Any]]) -> str:
    if not isinstance(email_messaging, dict):
        return ""

    for key in ("address", "email", "from_email", "from-email"):
        value = str(email_messaging.get(key) or "").strip().lower()
        if value:
            return value
    return ""


def _extract_inbound_uuid(email_messaging: Optional[Dict[str, Any]]) -> str:
    if not isinstance(email_messaging, dict):
        return ""
    for key in ("inbound_uuid", "inbound_id", "inboundId"):
        value = str(email_messaging.get(key) or "").strip()
        if value:
            return value
    return ""


def _prepare_messaging_for_inbound_mutation(
    messaging: Optional[Dict[str, Any]],
    inbound_setup_ids: Dict[str, str],
) -> Optional[Dict[str, Any]]:
    if not isinstance(messaging, dict):
        return messaging

    prepared = copy.deepcopy(messaging)
    email_messaging = prepared.get("email")
    if not isinstance(email_messaging, dict):
        return prepared

    inbound_uuid = _extract_inbound_uuid(email_messaging)
    if inbound_uuid:
        return prepared

    address = _normalize_inbound_address(email_messaging)
    if not address:
        return prepared

    remembered = inbound_setup_ids.get(address)
    if remembered:
        email_messaging["inbound_uuid"] = remembered
    return prepared


def _capture_inbound_setup_result(
    body: Optional[Dict[str, Any]],
    inbound_setup_ids: Dict[str, str],
) -> None:
    if not isinstance(body, dict):
        return

    events = body.get("events")
    if not isinstance(events, list):
        return

    for raw_event in events:
        if not isinstance(raw_event, dict) or raw_event.get("type") != "mailbox_configured":
            continue
        data = raw_event.get("data") if isinstance(raw_event.get("data"), dict) else {}
        address = str(data.get("address") or "").strip().lower()
        inbound_uuid = str(data.get("inbound_uuid") or "").strip()
        deleted_at = str(data.get("deleted_at") or "").strip()

        if not address:
            continue
        if deleted_at:
            inbound_setup_ids.pop(address, None)
            continue
        if inbound_uuid:
            inbound_setup_ids[address] = inbound_uuid


# ---------------------------------------------------------------------------
# ModelProxy — the `client.model` namespace
# ---------------------------------------------------------------------------

class _ModelProxy:
    """Provides ``client.model.request(...)``."""

    def __init__(self, client: "NinethClient") -> None:
        self._client = client

    def request(
        self,
        task_input: str,
        *,
        model: Optional[str] = None,
        stream: bool = False,
        reasoning: Optional[str] = None,
        top_p: Optional[float] = None,
        min_p: Optional[float] = None,
        top_k: Optional[int] = None,
        repetition_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        frequency_penalty: Optional[float] = None,
        seed: Optional[int] = None,
        show_reasoning: bool = False,
        max_iterations: int = 10,
        continuous: Optional[bool] = None,
        images: Optional[List[str]] = None,
        audio: Optional[List[Any]] = None,
        policy: Optional[str] = None,
        cache: bool = False,
        session_id: Optional[str] = None,
        base_system: bool = True,
        default_service: Union[bool, List[str]] = False,
        include_service: Optional[List[Any]] = None,
        client_service_results: Optional[List[Dict[str, Any]]] = None,
        verbose: bool = False,
        response_format: str = "text",
        compute: bool = False,
        messaging: Optional[Dict[str, Any]] = None,
        system_prompt: Optional[str] = None,
        debug: Optional[bool] = None,
    ) -> Union[Dict[str, Any], Iterator[Dict[str, Any]]]:
        """
        Send a task to the model.

        Args:
            task_input:     The task or question for the model.
            model:          Model name, e.g. ``"1984-m3-0317"``.
                            Falls back to the client ``default_model``.
            stream:         ``True`` → yields live text deltas as they arrive.
                            ``False`` (default) → returns the full response at once.
            reasoning:      Reasoning depth hint: ``"low"``, ``"medium"``, or ``"high"``.
            show_reasoning: Include the model's internal reasoning in the output.
            max_iterations: How many model turns the server may run. Default: ``10``.
            continuous:     Keep the loop running even without service calls.
                            Defaults to ``True`` when ``max_iterations > 10``.
            images:         Base64-encoded images for multimodal requests.
            audio:          Base64-encoded audio inputs. Each entry may be a plain base64 string or a dict with ``data`` plus optional ``mime_type`` and ``filename``.
            policy:         Additional caller policy text layered on top of the SDK/API runtime instruction. It does not remove the runtime done/service guidance.
            cache:          Persist the task session and return a reusable ``session_id``.
            session_id:     Reuse a previously returned cached session.
            base_system:    Use the Together-backed base provider path. Set ``False`` to fall back to the runtime default provider selection.
            default_service:
                            ``False`` disables built-in services.
                            ``True`` enables all built-in services.
                            A list enables only the named built-in services.
            include_service:
                            One custom-service surface. You may pass a local ``schema.py`` path, a directory containing ``schema.py``, a shorthand name discoverable from a local ``schema.py`` file, or a service manager class/object defined by that schema. Unresolved path strings are passed through to the server composer.
            client_service_results:
                            Optional manual callback results for resuming a paused client-managed service stream or buffered request.
            verbose:        Enable verbose runtime telemetry in the API response/event stream.
            response_format:
                            ``"text"`` (default) returns normal text.
                            ``"json"`` requests JSON output and parses the final response when possible.
            compute:        Include the total token count as ``compute``.
            messaging:      Optional outbound transport config. Example:
                            ``{"email": {"email": "bot@example.com", "name": "Bot"}, "telegram": {"botId": "bot-1", "chatId": "123"}}``.

        Returns:
            When ``stream=False``: a dict with ``final_response`` and ``iterations``.
            When ``stream=True``:  an iterator of event dicts. Text arrives as
            ``{"type": "model_delta", "data": {"text": "..."}}``. The last event
            is ``{"type": "result", ...}`` with the full ``final_response``.

        Raises:
            ValueError:      When no model is configured.
            NinethAPIError:  When the server returns an error.
        """
        resolved_model = model or self._client.default_model
        if not resolved_model:
            raise ValueError(
                "A model is required. Pass model=... or set default_model / NINETH_MODEL."
            )
        resolved_policy = policy if policy is not None else system_prompt
        resolved_verbose = verbose if debug is None else (verbose or bool(debug))
        if stream:
            return self._client._stream_request(
                task_input, resolved_model,
                reasoning=reasoning,
                top_p=top_p,
                min_p=min_p,
                top_k=top_k,
                repetition_penalty=repetition_penalty,
                presence_penalty=presence_penalty,
                frequency_penalty=frequency_penalty,
                seed=seed,
                show_reasoning=show_reasoning,
                max_iterations=max_iterations, continuous=continuous,
                images=images, audio=audio, policy=resolved_policy,
                cache=cache, session_id=session_id, base_system=base_system,
                default_service=default_service,
                include_service=include_service,
                client_service_results=client_service_results,
                verbose=resolved_verbose,
                response_format=response_format,
                compute=compute,
                messaging=messaging,
            )
        return self._client._buffered_request(
            task_input, resolved_model,
            reasoning=reasoning,
            top_p=top_p,
            min_p=min_p,
            top_k=top_k,
            repetition_penalty=repetition_penalty,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            seed=seed,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations, continuous=continuous,
            images=images, audio=audio, policy=resolved_policy,
            cache=cache, session_id=session_id, base_system=base_system,
            default_service=default_service,
            include_service=include_service,
            client_service_results=client_service_results,
            verbose=resolved_verbose,
            response_format=response_format,
            compute=compute,
            messaging=messaging,
        )


class _AsyncModelProxy:
    """Async version of ``_ModelProxy``. Used on ``AsyncNinethClient``."""

    def __init__(self, client: "AsyncNinethClient") -> None:
        self._client = client

    async def request(
        self,
        task_input: str,
        *,
        model: Optional[str] = None,
        stream: bool = False,
        reasoning: Optional[str] = None,
        top_p: Optional[float] = None,
        min_p: Optional[float] = None,
        top_k: Optional[int] = None,
        repetition_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        frequency_penalty: Optional[float] = None,
        seed: Optional[int] = None,
        show_reasoning: bool = False,
        max_iterations: int = 10,
        continuous: Optional[bool] = None,
        images: Optional[List[str]] = None,
        audio: Optional[List[Any]] = None,
        policy: Optional[str] = None,
        cache: bool = False,
        session_id: Optional[str] = None,
        base_system: bool = True,
        default_service: Union[bool, List[str]] = False,
        include_service: Optional[List[Any]] = None,
        client_service_results: Optional[List[Dict[str, Any]]] = None,
        verbose: bool = False,
        response_format: str = "text",
        compute: bool = False,
        messaging: Optional[Dict[str, Any]] = None,
        system_prompt: Optional[str] = None,
        debug: Optional[bool] = None,
    ) -> Union[Dict[str, Any], AsyncIterator[Dict[str, Any]]]:
        """
        Send a task to the model (async).

        When ``stream=False`` awaits the full response and returns a dict.
        When ``stream=True`` returns an async iterator::

            async for event in await client.model.request("task", stream=True):
                if event["type"] == "model_delta":
                    print(event["data"]["text"], end="")
        """
        resolved_model = model or self._client.default_model
        if not resolved_model:
            raise ValueError(
                "A model is required. Pass model=... or set default_model / NINETH_MODEL."
            )
        resolved_policy = policy if policy is not None else system_prompt
        resolved_verbose = verbose if debug is None else (verbose or bool(debug))
        if stream:
            return self._client._stream_request(
                task_input, resolved_model,
                reasoning=reasoning,
                top_p=top_p,
                min_p=min_p,
                top_k=top_k,
                repetition_penalty=repetition_penalty,
                presence_penalty=presence_penalty,
                frequency_penalty=frequency_penalty,
                seed=seed,
                show_reasoning=show_reasoning,
                max_iterations=max_iterations, continuous=continuous,
                images=images, audio=audio, policy=resolved_policy,
                cache=cache, session_id=session_id, base_system=base_system,
                default_service=default_service,
                include_service=include_service,
                client_service_results=client_service_results,
                verbose=resolved_verbose,
                response_format=response_format,
                compute=compute,
                messaging=messaging,
            )
        return await self._client._buffered_request(
            task_input, resolved_model,
            reasoning=reasoning,
            top_p=top_p,
            min_p=min_p,
            top_k=top_k,
            repetition_penalty=repetition_penalty,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            seed=seed,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations, continuous=continuous,
            images=images, audio=audio, policy=resolved_policy,
            cache=cache, session_id=session_id, base_system=base_system,
            default_service=default_service,
            include_service=include_service,
            client_service_results=client_service_results,
            verbose=resolved_verbose,
            response_format=response_format,
            compute=compute,
            messaging=messaging,
        )


# ---------------------------------------------------------------------------
# Public clients
# ---------------------------------------------------------------------------

class NinethClient:
    """
    Synchronous client for the 1984 model API.

    Basic usage::

        from nineth import NinethClient

        with NinethClient(default_model="1984-m3-0317") as client:
            response = client.model.request("Summarise BTC today.")
            print(response["final_response"])

    Streaming::

        with NinethClient(default_model="1984-m3-0317") as client:
            for event in client.model.request("Summarise BTC today.", stream=True):
                if event["type"] == "model_delta":
                    print(event["data"]["text"], end="", flush=True)
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        *,
        default_model: Optional[str] = None,
        timeout: Union[httpx.Timeout, float, None] = DEFAULT_TIMEOUT,
        stream_timeout: Union[httpx.Timeout, float, None] = DEFAULT_STREAM_TIMEOUT,
        headers: Optional[Dict[str, str]] = None,
    ):
        resolved_base_url = (base_url or os.getenv("NINETH_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        resolved_api_key = api_key or os.getenv("NINETH_API_KEY")

        request_headers: Dict[str, str] = dict(headers or {})
        if resolved_api_key:
            request_headers.setdefault(_API_KEY_HEADER, resolved_api_key)

        self.base_url = resolved_base_url
        self.api_key = resolved_api_key
        self.default_model: Optional[str] = (
            default_model
            or os.getenv("NINETH_DEFAULT_MODEL")
            or os.getenv("NINETH_MODEL")
        )
        self._stream_timeout = stream_timeout
        self._http = httpx.Client(
            base_url=resolved_base_url,
            timeout=timeout,
            headers=request_headers or None,
        )
        self._inbound_setup_ids: Dict[str, str] = {}
        self.model = _ModelProxy(self)

    def _ensure_api_key(self) -> None:
        if not self.api_key and _API_KEY_HEADER not in self._http.headers:
            raise ValueError(
                "Authentication required. Pass api_key=... or set NINETH_API_KEY."
            )

    def health(self) -> Dict[str, Any]:
        """Check that the API is reachable.  Does not require authentication."""
        response = self._http.get("/health")
        _raise_for_status(response)
        return response.json()

    def _run_callback_request_loop(
        self,
        payload: Dict[str, Any],
        *,
        model: str,
        local_registry: LocalServiceRegistry,
    ) -> Dict[str, Any]:
        current_payload = dict(payload)

        while True:
            response = self._http.post("/model/callback", json=current_payload)
            _raise_for_status(response, model=model)
            body = response.json()
            if body.get("status") != "awaiting_client_services":
                return body

            process_id = str(body.get("process_id", "")).strip()
            if not process_id:
                raise NinethAPIError("Callback response did not include a process_id.")

            current_payload = dict(payload)
            current_payload["process_id"] = process_id
            current_payload["client_service_results"] = _build_client_service_results(
                local_registry,
                body.get("pending_client_calls", []),
                process_id,
            )

    def _stream_callback_request(
        self,
        payload: Dict[str, Any],
        *,
        model: str,
        cache: bool,
        response_format: str,
    ) -> Iterator[Dict[str, Any]]:
        emitted_text = ""
        should_backfill_result_text = payload.get("client_service_results") is None
        allowed_builtin_services = _allowed_builtin_service_names(payload)

        with self._http.stream(
            "POST",
            "/model/callback/stream",
            json=payload,
            timeout=self._stream_timeout,
        ) as response:
            _raise_for_status(response, model=model)
            for event in _coalesce_deltas(
                _parse_sse_lines(response.iter_lines()),
                allowed_builtin_services=allowed_builtin_services,
                allow_raw_client_services=True,
            ):
                _raise_for_stream_event(event, model=model)
                trimmed_event = _trim_event(
                    event,
                    cache_enabled=cache,
                    allow_raw_client_services=True,
                )
                if event.get("type") in {"model_delta", "model_raw_delta"}:
                    if trimmed_event is None:
                        continue
                    if not trimmed_event.get("data", {}).get("progress"):
                        emitted_text += trimmed_event.get("data", {}).get("text", "")
                    yield trimmed_event
                    continue

                if should_backfill_result_text and event.get("type") == "result":
                    missing_text = _missing_stream_result_delta(
                        event.get("data", {}).get("final_response", ""),
                        emitted_text,
                    )
                    if missing_text:
                        emitted_text += missing_text
                        yield {"type": "model_delta", "data": {"text": missing_text}}

                if trimmed_event is not None:
                    yield _coerce_requested_response_event(
                        trimmed_event,
                        response_format=response_format,
                    )
                if event.get("type") == "awaiting_client_services":
                    return

    def _buffered_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        top_p: Optional[float],
        min_p: Optional[float],
        top_k: Optional[int],
        repetition_penalty: Optional[float],
        presence_penalty: Optional[float],
        frequency_penalty: Optional[float],
        seed: Optional[int],
        show_reasoning: bool,
        max_iterations: int,
        images: Optional[List[str]],
        audio: Optional[List[Any]],
        policy: Optional[str],
        continuous: Optional[bool] = None,
        cache: bool = False,
        session_id: Optional[str] = None,
        base_system: bool = True,
        default_service: Union[bool, List[str]] = False,
        include_service: Optional[List[Any]] = None,
        client_service_results: Optional[List[Dict[str, Any]]] = None,
        verbose: bool = False,
        response_format: str = "text",
        compute: bool = False,
        messaging: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        self._ensure_api_key()
        local_registry, payload_include_service = _prepare_callback_include_service(include_service)
        prepared_messaging = _prepare_messaging_for_inbound_mutation(messaging, self._inbound_setup_ids)
        payload = _build_payload(
            task_input, model,
            reasoning=reasoning,
            top_p=top_p,
            min_p=min_p,
            top_k=top_k,
            repetition_penalty=repetition_penalty,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            seed=seed,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations, images=images,
            audio=audio, policy=policy, continuous=continuous,
            cache=cache, session_id=session_id, base_system=base_system,
            default_service=default_service,
            include_service=payload_include_service,
            client_service_results=client_service_results,
            verbose=verbose,
            response_format=response_format,
            compute=compute,
            messaging=prepared_messaging,
        )
        if client_service_results is not None:
            response = self._http.post("/model/callback", json=payload)
            _raise_for_status(response, model=model)
            result = _coerce_requested_response_format(
                _trim_callback_response(response.json(), cache_enabled=cache),
                response_format=response_format,
            )
            _capture_inbound_setup_result(result, self._inbound_setup_ids)
            return result
        if local_registry.has_services:
            response_body = self._run_callback_request_loop(
                payload,
                model=model,
                local_registry=local_registry,
            )
            result = _coerce_requested_response_format(
                _trim_response(response_body, cache_enabled=cache),
                response_format=response_format,
            )
            _capture_inbound_setup_result(result, self._inbound_setup_ids)
            return result

        response = self._http.post("/model", json=payload)
        _raise_for_status(response, model=model)
        result = _coerce_requested_response_format(
            _trim_response(response.json(), cache_enabled=cache),
            response_format=response_format,
        )
        _capture_inbound_setup_result(result, self._inbound_setup_ids)
        return result

    def _stream_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        top_p: Optional[float],
        min_p: Optional[float],
        top_k: Optional[int],
        repetition_penalty: Optional[float],
        presence_penalty: Optional[float],
        frequency_penalty: Optional[float],
        seed: Optional[int],
        show_reasoning: bool,
        max_iterations: int,
        images: Optional[List[str]],
        audio: Optional[List[Any]],
        policy: Optional[str],
        continuous: Optional[bool] = None,
        cache: bool = False,
        session_id: Optional[str] = None,
        base_system: bool = True,
        default_service: Union[bool, List[str]] = False,
        include_service: Optional[List[Any]] = None,
        client_service_results: Optional[List[Dict[str, Any]]] = None,
        verbose: bool = False,
        response_format: str = "text",
        compute: bool = False,
        messaging: Optional[Dict[str, Any]] = None,
    ) -> Iterator[Dict[str, Any]]:
        self._ensure_api_key()
        local_registry, payload_include_service = _prepare_callback_include_service(include_service)
        prepared_messaging = _prepare_messaging_for_inbound_mutation(messaging, self._inbound_setup_ids)
        payload = _build_payload(
            task_input, model,
            reasoning=reasoning,
            top_p=top_p,
            min_p=min_p,
            top_k=top_k,
            repetition_penalty=repetition_penalty,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            seed=seed,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations, images=images,
            audio=audio, policy=policy, continuous=continuous,
            cache=cache, session_id=session_id, base_system=base_system,
            default_service=default_service,
            include_service=payload_include_service,
            client_service_results=client_service_results,
            verbose=verbose,
            response_format=response_format,
            compute=compute,
            messaging=prepared_messaging,
        )

        def _yield_and_capture(events: Iterator[Dict[str, Any]]) -> Iterator[Dict[str, Any]]:
            for event in events:
                if event.get("type") == "result" and isinstance(event.get("data"), dict):
                    _capture_inbound_setup_result(event["data"], self._inbound_setup_ids)
                yield event

        if local_registry.has_services or client_service_results is not None:
            yield from _yield_and_capture(
                self._stream_callback_request(
                    payload,
                    model=model,
                    cache=cache,
                    response_format=response_format,
                )
            )
            return

        allowed_builtin_services = _allowed_builtin_service_names(payload)

        with self._http.stream("POST", "/model/stream", json=payload, timeout=self._stream_timeout) as response:
            _raise_for_status(response, model=model)
            for event in _coalesce_deltas(
                _parse_sse_lines(response.iter_lines()),
                allowed_builtin_services=allowed_builtin_services,
            ):
                _raise_for_stream_event(event, model=model)
                trimmed_event = _trim_event(event, cache_enabled=cache)
                if trimmed_event is not None:
                    public_event = _coerce_requested_response_event(
                        trimmed_event,
                        response_format=response_format,
                    )
                    if public_event.get("type") == "result" and isinstance(public_event.get("data"), dict):
                        _capture_inbound_setup_result(public_event["data"], self._inbound_setup_ids)
                    yield public_event

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "NinethClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


class AsyncNinethClient:
    """
    Asynchronous client for the 1984 model API.

    Basic usage::

        import asyncio
        from nineth import AsyncNinethClient

        async def main():
            async with AsyncNinethClient(default_model="1984-m3-0317") as client:
                response = await client.model.request("Summarise ETH today.")
                print(response["final_response"])

        asyncio.run(main())
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        *,
        default_model: Optional[str] = None,
        timeout: Union[httpx.Timeout, float, None] = DEFAULT_TIMEOUT,
        stream_timeout: Union[httpx.Timeout, float, None] = DEFAULT_STREAM_TIMEOUT,
        headers: Optional[Dict[str, str]] = None,
    ):
        resolved_base_url = (base_url or os.getenv("NINETH_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        resolved_api_key = api_key or os.getenv("NINETH_API_KEY")

        request_headers: Dict[str, str] = dict(headers or {})
        if resolved_api_key:
            request_headers.setdefault(_API_KEY_HEADER, resolved_api_key)

        self.base_url = resolved_base_url
        self.api_key = resolved_api_key
        self.default_model: Optional[str] = (
            default_model
            or os.getenv("NINETH_DEFAULT_MODEL")
            or os.getenv("NINETH_MODEL")
        )
        self._stream_timeout = stream_timeout
        self._http = httpx.AsyncClient(
            base_url=resolved_base_url,
            timeout=timeout,
            headers=request_headers or None,
        )
        self._inbound_setup_ids: Dict[str, str] = {}
        self.model = _AsyncModelProxy(self)

    def _ensure_api_key(self) -> None:
        if not self.api_key and _API_KEY_HEADER not in self._http.headers:
            raise ValueError(
                "Authentication required. Pass api_key=... or set NINETH_API_KEY."
            )

    async def health(self) -> Dict[str, Any]:
        """Check that the API is reachable.  Does not require authentication."""
        response = await self._http.get("/health")
        _raise_for_status(response)
        return response.json()

    async def _run_callback_request_loop(
        self,
        payload: Dict[str, Any],
        *,
        model: str,
        local_registry: LocalServiceRegistry,
    ) -> Dict[str, Any]:
        current_payload = dict(payload)

        while True:
            response = await self._http.post("/model/callback", json=current_payload)
            _raise_for_status(response, model=model)
            body = response.json()
            if body.get("status") != "awaiting_client_services":
                return body

            process_id = str(body.get("process_id", "")).strip()
            if not process_id:
                raise NinethAPIError("Callback response did not include a process_id.")

            current_payload = dict(payload)
            current_payload["process_id"] = process_id
            current_payload["client_service_results"] = await _abuild_client_service_results(
                local_registry,
                body.get("pending_client_calls", []),
                process_id,
            )

    async def _stream_callback_request(
        self,
        payload: Dict[str, Any],
        *,
        model: str,
        cache: bool,
        response_format: str,
    ) -> AsyncIterator[Dict[str, Any]]:
        allowed_builtin_services = _allowed_builtin_service_names(payload)

        async with self._http.stream(
            "POST",
            "/model/callback/stream",
            json=payload,
            timeout=self._stream_timeout,
        ) as response:
            _raise_for_status(response, model=model)
            event_type = "message"
            data_lines: list[str] = []
            emitted_text = ""
            should_backfill_result_text = payload.get("client_service_results") is None

            async for raw_line in response.aiter_lines():
                line = raw_line.rstrip("\r")
                if not line:
                    if data_lines:
                        parsed: Dict[str, Any] = json.loads("\n".join(data_lines))
                        parsed.setdefault("type", event_type)
                        _raise_for_stream_event(parsed, model=model)
                        public_event = _normalize_public_stream_event(
                            parsed,
                            allowed_builtin_services=allowed_builtin_services,
                            allow_raw_client_services=True,
                        )
                        if public_event is None:
                            event_type = "message"
                            data_lines = []
                            continue
                        trimmed_event = _trim_event(
                            public_event,
                            cache_enabled=cache,
                            allow_raw_client_services=True,
                        )
                        progress_event = _service_progress_event(parsed)
                        if progress_event is not None:
                            trimmed_progress = _trim_event(
                                progress_event,
                                cache_enabled=cache,
                                allow_raw_client_services=True,
                            )
                            if trimmed_progress is not None:
                                yield trimmed_progress
                        if public_event.get("type") in {"model_delta", "model_raw_delta"}:
                            if trimmed_event is not None:
                                text = trimmed_event.get("data", {}).get("text", "")
                                if text:
                                    emitted_text += text
                                    yield trimmed_event
                        else:
                            if should_backfill_result_text and public_event.get("type") == "result":
                                missing_text = _missing_stream_result_delta(
                                    public_event.get("data", {}).get("final_response", ""),
                                    emitted_text,
                                )
                                if missing_text:
                                    emitted_text += missing_text
                                    yield {"type": "model_delta", "data": {"text": missing_text}}
                            if trimmed_event is not None:
                                yield _coerce_requested_response_event(
                                    trimmed_event,
                                    response_format=response_format,
                                )
                            if public_event.get("type") == "awaiting_client_services":
                                return
                    event_type = "message"
                    data_lines = []
                    continue
                if line.startswith(":"):
                    continue
                if line.startswith("event:"):
                    event_type = line.split(":", 1)[1].strip()
                    continue
                if line.startswith("data:"):
                    data_lines.append(line.split(":", 1)[1].strip())

    async def _buffered_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        top_p: Optional[float],
        min_p: Optional[float],
        top_k: Optional[int],
        repetition_penalty: Optional[float],
        presence_penalty: Optional[float],
        frequency_penalty: Optional[float],
        seed: Optional[int],
        show_reasoning: bool,
        max_iterations: int,
        continuous: Optional[bool] = None,
        images: Optional[List[str]],
        audio: Optional[List[Any]],
        policy: Optional[str],
        cache: bool = False,
        session_id: Optional[str] = None,
        base_system: bool = True,
        default_service: Union[bool, List[str]] = False,
        include_service: Optional[List[Any]] = None,
        client_service_results: Optional[List[Dict[str, Any]]] = None,
        verbose: bool = False,
        response_format: str = "text",
        compute: bool = False,
        messaging: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        self._ensure_api_key()
        local_registry, payload_include_service = _prepare_callback_include_service(include_service)
        prepared_messaging = _prepare_messaging_for_inbound_mutation(messaging, self._inbound_setup_ids)
        payload = _build_payload(
            task_input, model,
            reasoning=reasoning,
            top_p=top_p,
            min_p=min_p,
            top_k=top_k,
            repetition_penalty=repetition_penalty,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            seed=seed,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations, continuous=continuous,
            images=images, audio=audio, policy=policy,
            cache=cache, session_id=session_id, base_system=base_system,
            default_service=default_service,
            include_service=payload_include_service,
            client_service_results=client_service_results,
            verbose=verbose,
            response_format=response_format,
            compute=compute,
            messaging=prepared_messaging,
        )
        if client_service_results is not None:
            response = await self._http.post("/model/callback", json=payload)
            _raise_for_status(response, model=model)
            result = _coerce_requested_response_format(
                _trim_callback_response(response.json(), cache_enabled=cache),
                response_format=response_format,
            )
            _capture_inbound_setup_result(result, self._inbound_setup_ids)
            return result
        if local_registry.has_services:
            response_body = await self._run_callback_request_loop(
                payload,
                model=model,
                local_registry=local_registry,
            )
            result = _coerce_requested_response_format(
                _trim_response(response_body, cache_enabled=cache),
                response_format=response_format,
            )
            _capture_inbound_setup_result(result, self._inbound_setup_ids)
            return result

        response = await self._http.post("/model", json=payload)
        _raise_for_status(response, model=model)
        result = _coerce_requested_response_format(
            _trim_response(response.json(), cache_enabled=cache),
            response_format=response_format,
        )
        _capture_inbound_setup_result(result, self._inbound_setup_ids)
        return result

    def _stream_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        top_p: Optional[float],
        min_p: Optional[float],
        top_k: Optional[int],
        repetition_penalty: Optional[float],
        presence_penalty: Optional[float],
        frequency_penalty: Optional[float],
        seed: Optional[int],
        show_reasoning: bool,
        max_iterations: int,
        continuous: Optional[bool] = None,
        images: Optional[List[str]],
        audio: Optional[List[Any]],
        policy: Optional[str],
        cache: bool = False,
        session_id: Optional[str] = None,
        base_system: bool = True,
        default_service: Union[bool, List[str]] = False,
        include_service: Optional[List[Any]] = None,
        client_service_results: Optional[List[Dict[str, Any]]] = None,
        verbose: bool = False,
        response_format: str = "text",
        compute: bool = False,
        messaging: Optional[Dict[str, Any]] = None,
    ) -> AsyncIterator[Dict[str, Any]]:
        self._ensure_api_key()
        local_registry, payload_include_service = _prepare_callback_include_service(include_service)
        prepared_messaging = _prepare_messaging_for_inbound_mutation(messaging, self._inbound_setup_ids)
        payload = _build_payload(
            task_input, model,
            reasoning=reasoning,
            top_p=top_p,
            min_p=min_p,
            top_k=top_k,
            repetition_penalty=repetition_penalty,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            seed=seed,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations, continuous=continuous,
            images=images, audio=audio, policy=policy,
            cache=cache, session_id=session_id, base_system=base_system,
            default_service=default_service,
            include_service=payload_include_service,
            client_service_results=client_service_results,
            verbose=verbose,
            response_format=response_format,
            compute=compute,
            messaging=prepared_messaging,
        )

        if local_registry.has_services or client_service_results is not None:
            async def _callback_gen() -> AsyncIterator[Dict[str, Any]]:
                async for event in self._stream_callback_request(
                    payload,
                    model=model,
                    cache=cache,
                    response_format=response_format,
                ):
                    if event.get("type") == "result" and isinstance(event.get("data"), dict):
                        _capture_inbound_setup_result(event["data"], self._inbound_setup_ids)
                    yield event

            return _callback_gen()

        allowed_builtin_services = _allowed_builtin_service_names(payload)

        async def _gen() -> AsyncIterator[Dict[str, Any]]:
            async with self._http.stream(
                "POST",
                "/model/stream",
                json=payload,
                timeout=self._stream_timeout,
            ) as response:
                _raise_for_status(response, model=model)
                event_type = "message"
                data_lines: list[str] = []

                async for raw_line in response.aiter_lines():
                    line = raw_line.rstrip("\r")
                    if not line:
                        if data_lines:
                            parsed: Dict[str, Any] = json.loads("\n".join(data_lines))
                            parsed.setdefault("type", event_type)
                            _raise_for_stream_event(parsed, model=model)
                            public_event = _normalize_public_stream_event(
                                parsed,
                                allowed_builtin_services=allowed_builtin_services,
                            )
                            if public_event is None:
                                event_type = "message"
                                data_lines = []
                                continue
                            trimmed_event = _trim_event(public_event, cache_enabled=cache)
                            progress_event = _service_progress_event(parsed)
                            if progress_event is not None:
                                trimmed_progress = _trim_event(progress_event, cache_enabled=cache)
                                if trimmed_progress is not None:
                                    yield trimmed_progress
                            if public_event.get("type") == "model_delta":
                                if trimmed_event is not None:
                                    text = trimmed_event.get("data", {}).get("text", "")
                                    if text:
                                        yield trimmed_event
                            else:
                                if trimmed_event is not None:
                                    shaped_event = _coerce_requested_response_event(
                                        trimmed_event,
                                        response_format=response_format,
                                    )
                                    if shaped_event.get("type") == "result" and isinstance(shaped_event.get("data"), dict):
                                        _capture_inbound_setup_result(shaped_event["data"], self._inbound_setup_ids)
                                    yield shaped_event
                        event_type = "message"
                        data_lines = []
                        continue
                    if line.startswith(":"):
                        continue
                    if line.startswith("event:"):
                        event_type = line.split(":", 1)[1].strip()
                        continue
                    if line.startswith("data:"):
                        data_lines.append(line.split(":", 1)[1].strip())

                if data_lines:
                    parsed = json.loads("\n".join(data_lines))
                    parsed.setdefault("type", event_type)
                    _raise_for_stream_event(parsed, model=model)
                    public_event = _normalize_public_stream_event(
                        parsed,
                        allowed_builtin_services=allowed_builtin_services,
                    )
                    if public_event is None:
                        return
                    trimmed_event = _trim_event(public_event, cache_enabled=cache)
                    progress_event = _service_progress_event(parsed)
                    if progress_event is not None:
                        trimmed_progress = _trim_event(progress_event, cache_enabled=cache)
                        if trimmed_progress is not None:
                            yield trimmed_progress
                    if public_event.get("type") == "model_delta":
                        if trimmed_event is not None:
                            text = trimmed_event.get("data", {}).get("text", "")
                            if text:
                                yield trimmed_event
                    else:
                        if trimmed_event is not None:
                            shaped_event = _coerce_requested_response_event(
                                trimmed_event,
                                response_format=response_format,
                            )
                            if shaped_event.get("type") == "result" and isinstance(shaped_event.get("data"), dict):
                                _capture_inbound_setup_result(shaped_event["data"], self._inbound_setup_ids)
                            yield shaped_event

        return _gen()

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncNinethClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()
