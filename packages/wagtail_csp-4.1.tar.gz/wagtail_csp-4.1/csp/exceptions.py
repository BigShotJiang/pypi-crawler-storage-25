class CSPNonceError(Exception):
    pass
