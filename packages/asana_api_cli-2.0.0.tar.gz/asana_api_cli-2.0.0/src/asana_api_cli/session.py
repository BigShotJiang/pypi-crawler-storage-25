"""Asana SDK client construction utilities.

A thin wrapper around the official `asana` SDK ApiClient that handles
initialization from environment variables, toggling pagination mode, and
applying the global configuration passed in from the CLI.
"""

from __future__ import annotations

import functools
import json
import os
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import asana
from urllib3.util.retry import Retry

ACCESS_TOKEN_ENV = "ASANA_ACCESS_TOKEN"
DEFAULT_WORKSPACE_ENV = "ASANA_DEFAULT_WORKSPACE"


def resolve_body(value: str) -> Any:
    """Parse a body argument as JSON.

    Supports three input forms:
    - ``@path`` — read JSON from a file
    - ``-``     — read JSON from stdin
    - otherwise — parse the string itself as JSON
    """
    if value == "-":
        raw = sys.stdin.read()
    elif value.startswith("@"):
        path = Path(value[1:])
        try:
            raw = path.read_text(encoding="utf-8")
        except FileNotFoundError:
            print(f"Body file not found: {path}", file=sys.stderr)
            sys.exit(1)
        except OSError as exc:
            print(f"Cannot read body file {path}: {exc}", file=sys.stderr)
            sys.exit(1)
    else:
        raw = value

    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        print(f"Invalid JSON in body: {exc}", file=sys.stderr)
        sys.exit(1)


@dataclass
class _Runtime:
    """Configuration shared globally during a CLI invocation. Updated by the main group callback."""

    debug: bool = False
    host: str | None = None
    proxy: str | None = None
    verify_ssl: bool = True
    ssl_ca_cert: str | None = None
    retries: int | None = None
    timeout: float | None = None
    access_token: str | None = None
    temp_dir: str | None = None


runtime = _Runtime()


class AsanaSession:
    """Session that holds an ApiClient from the official asana SDK."""

    def __init__(self, token: str, *, paginate: bool = False, page_size: int | None = None) -> None:
        config = asana.Configuration()
        config.access_token = token
        # When --paginate is set, the SDK returns a PageIterator that walks every page.
        config.return_page_iterator = paginate
        # When --page-size is set, override the SDK default per-page size (100).
        if page_size is not None:
            config.page_limit = page_size
        self._page_size = page_size

        # Apply runtime values to Configuration
        if runtime.host:
            config.host = runtime.host
        if runtime.proxy:
            config.proxy = runtime.proxy  # pyright: ignore[reportAttributeAccessIssue]
        if not runtime.verify_ssl:
            config.verify_ssl = False
        if runtime.ssl_ca_cert:
            config.ssl_ca_cert = runtime.ssl_ca_cert  # pyright: ignore[reportAttributeAccessIssue]
        if runtime.temp_dir:
            config.temp_folder_path = runtime.temp_dir  # pyright: ignore[reportAttributeAccessIssue]
        if runtime.retries is not None:
            # Replace only `total` while keeping the existing backoff/status_forcelist.
            config.retry_strategy = Retry(
                total=runtime.retries,
                backoff_factor=2,
                status_forcelist=[429, 500, 502, 503, 504],
            )
        if runtime.debug:
            # The SDK debug setter attaches a stderr handler to the urllib3/asana
            # loggers and enables http.client.HTTPConnection.debuglevel.
            config.debug = True

        self._config = config
        self._client = asana.ApiClient(config)

        # Configuration has no --timeout knob, so wrap call_api to inject it.
        if runtime.timeout is not None:
            self._install_timeout(runtime.timeout)

    def _install_timeout(self, timeout: float) -> None:
        """Wrap ApiClient.call_api to inject a default _request_timeout."""
        original = self._client.call_api

        @functools.wraps(original)
        def call_api_with_timeout(*args: Any, **kwargs: Any) -> Any:
            kwargs.setdefault("_request_timeout", timeout)
            return original(*args, **kwargs)

        self._client.call_api = call_api_with_timeout  # type: ignore[method-assign]

    @property
    def client(self) -> asana.ApiClient:
        return self._client

    def api(self, api_class: type) -> object:
        """Take a <Tag>Api class and return an instance bound to this session."""
        return api_class(self._client)

    @classmethod
    def from_env(cls, *, paginate: bool = False, page_size: int | None = None) -> "AsanaSession":
        """Build a session from runtime.access_token, falling back to $ASANA_ACCESS_TOKEN."""
        token = runtime.access_token or os.environ.get(ACCESS_TOKEN_ENV, "")
        if not token:
            print(
                f"Access token is not set. Pass --access-token or set {ACCESS_TOKEN_ENV}.",
                file=sys.stderr,
            )
            sys.exit(1)
        return cls(token=token, paginate=paginate, page_size=page_size)

    def fetch_capped(
        self,
        api_method: Callable[..., Any],
        *args: Any,
        opts: dict[str, Any],
        max_items: int,
    ) -> list[Any]:
        """Fetch up to *max_items* items by manually walking ``next_page.offset``.

        The last request is automatically capped to the remaining count so we
        do not overfetch. Returns a flat list of items, matching the shape
        produced by ``--paginate``.
        """
        # Disable the SDK's PageIterator path for the duration of these calls.
        config = self._client.configuration
        original = config.return_page_iterator
        config.return_page_iterator = False
        try:
            page_size_default = self._page_size or 100
            items: list[Any] = []
            opts = dict(opts)  # don't mutate the caller's dict
            while len(items) < max_items:
                remaining = max_items - len(items)
                opts["limit"] = min(remaining, page_size_default)
                response = api_method(*args, opts)
                page_data = _extract(response, "data") or []
                items.extend(page_data)
                next_page = _extract(response, "next_page")
                offset = _extract(next_page, "offset") if next_page else None
                if not offset:
                    break
                opts["offset"] = offset
            return items[:max_items]
        finally:
            config.return_page_iterator = original


def _extract(obj: Any, key: str) -> Any:
    """Read *key* from a SDK response that may be a dict or a typed model."""
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(key)
    return getattr(obj, key, None)


def resolve_workspace(
    explicit: str | None,
    *,
    required: bool = False,
) -> str | None:
    """Resolve workspace GID with fallback chain.

    Priority: explicit ``--workspace`` value > ``ASANA_DEFAULT_WORKSPACE``
    env var (only when *required* is True).

    When workspace is optional (``required=False``), the env-var fallback is
    **not** used.  This prevents the default workspace from being sent
    alongside other scope parameters (e.g. ``--project`` on ``get-tasks``)
    that are mutually exclusive with workspace in the Asana API.

    If *required* is True and no value is found, exits with an error.
    """
    if explicit is not None:
        return explicit
    if required:
        ws = os.environ.get(DEFAULT_WORKSPACE_ENV)
        if ws:
            return ws
        print(
            f"Workspace is required. Specify --workspace or set {DEFAULT_WORKSPACE_ENV}.",
            file=sys.stderr,
        )
        sys.exit(1)
    return None
