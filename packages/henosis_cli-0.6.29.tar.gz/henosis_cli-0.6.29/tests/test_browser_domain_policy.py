import pytest

from app.settings import settings
from app.tools.browser_tools import BrowserPolicyError, _normalize_allowed_domains, _validate_browser_url


def test_normalize_allowed_domains_strips_scheme_slashes_and_dedupes():
    assert _normalize_allowed_domains([
        "https://Example.com/",
        "example.com",
        "docs.openai.com/",
        "http://docs.openai.com",
    ]) == ["example.com", "docs.openai.com"]


def test_validate_browser_url_blocks_private_and_loopback_hosts(monkeypatch):
    monkeypatch.setattr(settings, "BROWSER_BLOCK_PRIVATE_NETS", True)

    with pytest.raises(BrowserPolicyError):
        _validate_browser_url("http://127.0.0.1:8000", [])

    with pytest.raises(BrowserPolicyError):
        _validate_browser_url("http://localhost:3000", [])


def test_validate_browser_url_enforces_allow_list(monkeypatch):
    monkeypatch.setattr(settings, "BROWSER_BLOCK_PRIVATE_NETS", False)

    url, host = _validate_browser_url("https://docs.openai.com/api", ["openai.com"])
    assert url == "https://docs.openai.com/api"
    assert host == "docs.openai.com"

    with pytest.raises(BrowserPolicyError):
        _validate_browser_url("https://example.com", ["openai.com"])


def test_validate_browser_url_rejects_non_http_schemes(monkeypatch):
    monkeypatch.setattr(settings, "BROWSER_BLOCK_PRIVATE_NETS", False)

    with pytest.raises(BrowserPolicyError):
        _validate_browser_url("file:///etc/passwd", [])
