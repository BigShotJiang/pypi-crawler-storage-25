import importlib
import json
from pathlib import Path


def _make_cli():
    cli_mod = importlib.import_module("cli")
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model="gpt-5.4",
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
        machine_link_mode=True,
    )
    cli.auth_user = "user@example.com"
    cli.device_id = "machine-a"
    cli.device_name = "Windows PC"
    return cli


def test_spawn_remote_agent_process_starts_child_cli(monkeypatch, tmp_path):
    cli = _make_cli()
    cli.log_dir = tmp_path / "logs"
    spawn_dir = tmp_path / "project"
    spawn_dir.mkdir()

    popen_calls = []

    class _Proc:
        pid = 12345

    def fake_popen(cmd, **kwargs):
        popen_calls.append((cmd, kwargs))
        return _Proc()

    monkeypatch.setattr("cli.subprocess.Popen", fake_popen)
    monkeypatch.setattr(cli, "_resolve_spawn_cli_base_command", lambda: ["python", "cli.py"])

    result = cli._spawn_remote_agent_process(
        cwd=str(spawn_dir),
        terminal_id="term-spawned",
        model="gpt-5.4",
    )

    assert result["ok"] is True
    assert result["pid"] == 12345
    assert result["terminal_id"] == "term-spawned"
    assert len(popen_calls) == 1
    cmd, kwargs = popen_calls[0]
    assert cmd == [
        "python",
        "cli.py",
        "--server",
        "http://127.0.0.1:8000/api",
        "--agent-mode",
        "--terminal-id",
        "term-spawned",
        "--workspace-dir",
        str(spawn_dir),
        "--agent-scope",
        str(spawn_dir),
        "--model",
        "gpt-5.4",
    ]
    assert kwargs["cwd"] == str(spawn_dir)


def test_list_machine_link_directories_returns_parent_and_child_dirs(monkeypatch, tmp_path):
    cli = _make_cli()
    root = tmp_path / "repo"
    child = root / "src"
    root.mkdir()
    child.mkdir()
    monkeypatch.chdir(root)
    cli.local_workspace_dir = str(root)
    cli.host_base = str(root)

    listing = cli._list_machine_link_directories(str(root))

    assert listing["ok"] is True
    assert listing["current_path"] == str(root.resolve())
    entries = listing["entries"]
    assert entries[0]["kind"] == "parent"
    assert any(entry["name"] == "src" and entry["path"] == str(child.resolve()) for entry in entries)


def test_machine_link_info_uses_current_device_identity(tmp_path):
    cli = _make_cli()
    cli.local_workspace_dir = str(tmp_path)
    cli.host_base = None
    info = cli._build_machine_link_info()

    assert info["machine_id"] == "machine-a"
    assert info["device_name"] == "Windows PC"
    assert info["default_start_dir"] == str(Path(tmp_path).resolve())
    assert info["auth_user"] == "user@example.com"


def test_list_machine_link_managed_sessions_updates_exited_process_state():
    cli = _make_cli()

    class _Proc:
        pid = 2468

        def poll(self):
            return 0

    cli._machine_link_managed_sessions["term-spawned"] = {
        "terminal_id": "term-spawned",
        "pid": 2468,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "running",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": None,
        "exit_code": None,
        "restart_count": 0,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": _Proc(),
    }

    result = cli._list_machine_link_managed_sessions()

    assert result["ok"] is True
    assert result["sessions"][0]["terminal_id"] == "term-spawned"
    assert result["sessions"][0]["status"] == "exited"
    assert result["sessions"][0]["exit_code"] == 0


def test_stop_machine_link_managed_session_terminates_registered_child():
    cli = _make_cli()

    class _Proc:
        def __init__(self):
            self.pid = 1357
            self.returncode = None

        def poll(self):
            return self.returncode

        def terminate(self):
            self.returncode = 0

        def wait(self, timeout=None):
            return self.returncode

        def kill(self):
            self.returncode = -9

    proc = _Proc()
    cli._machine_link_managed_sessions["term-spawned"] = {
        "terminal_id": "term-spawned",
        "pid": proc.pid,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "running",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": None,
        "exit_code": None,
        "restart_count": 0,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": proc,
    }

    result = cli._stop_machine_link_managed_session("term-spawned")

    assert result["ok"] is True
    assert result["terminal_id"] == "term-spawned"
    assert result["session"]["status"] == "stopped"
    assert result["session"]["exit_code"] == 0


def test_restart_machine_link_managed_session_stops_then_respawns(monkeypatch):
    cli = _make_cli()

    class _Proc:
        def __init__(self, pid):
            self.pid = pid
            self.returncode = None

        def poll(self):
            return self.returncode

        def terminate(self):
            self.returncode = 0

        def wait(self, timeout=None):
            return self.returncode

        def kill(self):
            self.returncode = -9

    old_proc = _Proc(1111)
    new_proc = _Proc(2222)
    cli._machine_link_managed_sessions["term-spawned"] = {
        "terminal_id": "term-spawned",
        "pid": old_proc.pid,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "running",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": None,
        "exit_code": None,
        "restart_count": 0,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": old_proc,
    }

    spawn_calls = []

    def fake_spawn_remote_agent_process(*, cwd, terminal_id, model=None):
        spawn_calls.append({"cwd": cwd, "terminal_id": terminal_id, "model": model})
        cli._machine_link_managed_sessions[terminal_id] = {
            "terminal_id": terminal_id,
            "pid": new_proc.pid,
            "cwd": cwd,
            "model": model,
            "status": "running",
            "started_at": "2026-03-30T00:05:00Z",
            "stopped_at": None,
            "exit_code": None,
            "restart_count": 1,
            "last_error": None,
            "command": ["python", "cli.py"],
            "_process": new_proc,
        }
        return {
            "ok": True,
            "terminal_id": terminal_id,
            "pid": new_proc.pid,
            "cwd": cwd,
            "session": cli._machine_link_session_view(cli._machine_link_managed_sessions[terminal_id]),
        }

    monkeypatch.setattr(cli, "_spawn_remote_agent_process", fake_spawn_remote_agent_process)

    result = cli._restart_machine_link_managed_session("term-spawned")

    assert spawn_calls == [{"cwd": "C:/repo/project", "terminal_id": "term-spawned", "model": "gpt-5.4"}]
    assert result["ok"] is True
    assert result["terminal_id"] == "term-spawned"
    assert result["pid"] == 2222
    assert result["session"]["status"] == "running"


def test_remove_machine_link_managed_session_drops_stale_entry(monkeypatch):
    cli = _make_cli()
    saved = []
    monkeypatch.setattr(cli, "_save_auth_state_to_disk", lambda: saved.append(True))
    cli._machine_link_managed_sessions["term-stale"] = {
        "terminal_id": "term-stale",
        "pid": 0,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "stale",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": "2026-03-30T00:10:00Z",
        "exit_code": None,
        "restart_count": 0,
        "last_error": "PID no longer matches",
        "command": ["python", "cli.py"],
        "_process": None,
    }

    result = cli._machine_link_remove_managed_session("term-stale")

    assert result["ok"] is True
    assert result["removed"] is True
    assert "term-stale" not in cli._machine_link_managed_sessions
    assert saved == [True]


def test_remove_all_stale_sessions_removes_only_stale_entries(monkeypatch):
    cli = _make_cli()
    saved = []
    monkeypatch.setattr(cli, "_save_auth_state_to_disk", lambda: saved.append(True))
    cli._machine_link_managed_sessions["term-stale"] = {
        "terminal_id": "term-stale",
        "pid": 0,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "stale",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": "2026-03-30T00:10:00Z",
        "exit_code": None,
        "restart_count": 0,
        "last_error": "PID no longer matches",
        "command": ["python", "cli.py"],
        "_process": None,
    }
    cli._machine_link_managed_sessions["term-running"] = {
        "terminal_id": "term-running",
        "pid": 9999,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "running",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": None,
        "exit_code": None,
        "restart_count": 0,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": None,
    }
    monkeypatch.setattr(cli, "_machine_link_pid_exists", lambda pid: pid == 9999)
    monkeypatch.setattr(cli, "_machine_link_pid_matches_session", lambda pid, session: True)

    result = cli._machine_link_remove_all_stale_sessions()

    assert result["ok"] is True
    assert result["removed_count"] == 1
    assert result["removed_terminal_ids"] == ["term-stale"]
    assert "term-stale" not in cli._machine_link_managed_sessions
    assert "term-running" in cli._machine_link_managed_sessions
    assert saved == [True]


def test_read_session_output_returns_tail_of_log_file(tmp_path):
    cli = _make_cli()
    cli.log_dir = tmp_path
    cli._machine_link_managed_sessions["term-spawned"] = {
        "terminal_id": "term-spawned",
        "pid": 0,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "stopped",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": "2026-03-30T00:10:00Z",
        "exit_code": 0,
        "restart_count": 1,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": None,
    }
    log_path = cli._machine_link_log_path("term-spawned")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text(("alpha\n" * 300) + "charlie\n", encoding="utf-8")

    result = cli._machine_link_read_session_output("term-spawned", max_chars=1000)

    assert result["ok"] is True
    assert result["terminal_id"] == "term-spawned"
    assert result["truncated"] is True
    assert result["log_path"] == str(log_path)
    assert result["output"].endswith("charlie\n")


def test_auth_state_persists_and_restores_machine_link_sessions(tmp_path):
    cli = _make_cli()
    cli.auth_state_file = tmp_path / "auth-state.json"
    cli._machine_link_managed_sessions["term-spawned"] = {
        "terminal_id": "term-spawned",
        "pid": 4242,
        "cwd": "C:/repo/project",
        "model": "gpt-5.4",
        "status": "stopped",
        "started_at": "2026-03-30T00:00:00Z",
        "stopped_at": "2026-03-30T00:10:00Z",
        "exit_code": 0,
        "restart_count": 1,
        "last_error": None,
        "command": ["python", "cli.py"],
        "_process": None,
    }

    cli._save_auth_state_to_disk()
    payload = json.loads(cli.auth_state_file.read_text(encoding="utf-8"))

    assert payload["machine_link_managed_sessions"] == [
        {
            "terminal_id": "term-spawned",
            "pid": 4242,
            "cwd": "C:/repo/project",
            "model": "gpt-5.4",
            "status": "stopped",
            "started_at": "2026-03-30T00:00:00Z",
            "stopped_at": "2026-03-30T00:10:00Z",
            "exit_code": 0,
            "restart_count": 1,
            "last_error": None,
            "command": ["python", "cli.py"],
        }
    ]

    restored_cli = _make_cli()
    restored_cli.auth_state_file = cli.auth_state_file

    assert restored_cli._load_auth_state_from_disk() is False
    assert restored_cli._machine_link_managed_sessions["term-spawned"]["terminal_id"] == "term-spawned"
    assert restored_cli._machine_link_managed_sessions["term-spawned"]["status"] == "stopped"
    assert restored_cli._machine_link_managed_sessions["term-spawned"]["pid"] == 4242
