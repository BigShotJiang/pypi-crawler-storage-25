import asyncio
import importlib

import pytest


def make_cli():
    cli_mod = importlib.import_module("cli")
    return cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )


def test_turn_elapsed_freezes_after_finalize(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = make_cli()
    values = iter([10.0, 14.25, 99.0])
    monkeypatch.setattr(cli_mod.time, "perf_counter", lambda: next(values))

    assert cli._begin_turn_timer() == pytest.approx(10.0)
    assert cli._turn_elapsed_seconds(finalize=True) == pytest.approx(4.25)
    assert cli._turn_elapsed_seconds() == pytest.approx(4.25)


def test_stream_once_starts_turn_timer_for_local_codex(monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = make_cli()
    seen = {}

    monkeypatch.setattr(cli_mod.time, "perf_counter", lambda: 123.0)
    monkeypatch.setattr(cli, "_should_use_local_codex_for_model", lambda model: True)

    async def fake_stream(user_input: str) -> str:
        seen["started_at"] = cli._turn_started_at
        seen["cached_duration"] = cli._last_turn_duration_secs
        return "ok"

    monkeypatch.setattr(cli, "_stream_codex_local_once", fake_stream)

    assert asyncio.run(cli._stream_once("hello")) == "ok"
    assert seen["started_at"] == pytest.approx(123.0)
    assert seen["cached_duration"] is None
