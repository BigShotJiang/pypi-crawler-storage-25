from app.controls import L1, L2, available_tools_for
from app.tools.browser_tools import BROWSER_TOOL_NAMES, browser_tool_requires_approval


def _names(tools):
    return {t.get("name") for t in tools if isinstance(t, dict)}


def test_browser_tools_hidden_at_level_one_even_when_enabled():
    names = _names(available_tools_for(L1, tools_enabled=False, browser_tools_enabled=True))
    assert not (names & BROWSER_TOOL_NAMES)


def test_browser_tools_available_at_level_two_without_file_tools():
    names = _names(available_tools_for(L2, tools_enabled=False, browser_tools_enabled=True))
    assert {"browser_session", "browser_tabs", "browser_navigate", "browser_snapshot", "browser_act", "browser_wait"} <= names
    assert "read_file" not in names


def test_browser_tool_requires_approval_distinguishes_safe_vs_state_changing_actions():
    assert browser_tool_requires_approval("browser_snapshot", {}) is False
    assert browser_tool_requires_approval("browser_wait", {}) is False
    assert browser_tool_requires_approval("browser_session", {"action": "status"}) is False
    assert browser_tool_requires_approval("browser_tabs", {"action": "select"}) is False
    assert browser_tool_requires_approval("browser_act", {"action": "hover"}) is False

    assert browser_tool_requires_approval("browser_session", {"action": "start"}) is True
    assert browser_tool_requires_approval("browser_tabs", {"action": "close"}) is True
    assert browser_tool_requires_approval("browser_navigate", {"url": "https://example.com"}) is True
    assert browser_tool_requires_approval("browser_act", {"action": "click"}) is True
