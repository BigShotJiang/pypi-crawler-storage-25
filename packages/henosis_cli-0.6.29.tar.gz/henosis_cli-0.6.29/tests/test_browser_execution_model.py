import shutil
import tempfile
from pathlib import Path

from app.routers import chat as chat_router
from app.settings import settings
from app.tools.file_tools import FileToolPolicy, execute_tool


def _new_workspace() -> Path:
    root = Path("workspace/.tmp_tests")
    root.mkdir(parents=True, exist_ok=True)
    return Path(tempfile.mkdtemp(prefix="browser-exec-model-", dir=str(root)))


def test_browser_tools_are_not_server_only():
    assert chat_router._is_server_only_tool("browser_session") is False
    assert chat_router._is_server_only_tool("browser_snapshot") is False


def test_browser_tools_do_not_force_server_approval_when_cli_authority(monkeypatch):
    monkeypatch.setattr(settings, "APPROVALS_SOURCE", "cli")
    needed = chat_router._server_approval_required_for_invocation(
        session_id="sess-1",
        tool_name="browser_navigate",
        level=2,
        auto_approve_tools=set(),
        auto_approve_command_bases=set(),
        args_preview={"url": "https://example.com"},
    )
    assert needed is False


def test_server_execute_tool_rejects_browser_runtime_execution():
    ws = _new_workspace()
    try:
        pol = FileToolPolicy(scope="workspace", workspace_base=ws)
        out = execute_tool("browser_session", {"action": "status"}, pol)
        assert out.get("ok") is False
        assert "client callback" in str(out.get("error", ""))
    finally:
        shutil.rmtree(ws, ignore_errors=True)
