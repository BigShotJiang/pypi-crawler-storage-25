import os
from pathlib import Path


def test_node_bin_dirs_for_cwd_collects_parent_bins(tmp_path):
    from henosis_cli_tools import tool_impl as ti

    root_bin = tmp_path / "node_modules" / ".bin"
    root_bin.mkdir(parents=True)
    nested = tmp_path / "packages" / "app"
    nested.mkdir(parents=True)
    nested_bin = nested / "node_modules" / ".bin"
    nested_bin.mkdir(parents=True)

    found = ti._node_bin_dirs_for_cwd(nested)

    assert nested_bin in found
    assert root_bin in found
    assert found.index(nested_bin) < found.index(root_bin)


def test_resolve_windows_cmd_shim_noop_for_non_windows():
    from henosis_cli_tools import tool_impl as ti

    resolved = ti._resolve_windows_cmd_shim("npm", {"PATH": os.environ.get("PATH", "")})

    if os.name != "nt":
        assert resolved is None


def test_resolve_windows_cmd_shim_prefers_cmd(tmp_path, monkeypatch):
    if os.name != "nt":
        return

    from henosis_cli_tools import tool_impl as ti

    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    npm_cmd = bin_dir / "npm.cmd"
    npm_cmd.write_text("@echo off\r\n", encoding="utf-8")

    env = {"PATH": str(bin_dir)}
    resolved = ti._resolve_windows_cmd_shim("npm", env)

    assert isinstance(resolved, str)
    assert Path(resolved).resolve() == npm_cmd.resolve()
