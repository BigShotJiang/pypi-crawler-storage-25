from app.routers import chat as chat_router


def test_gemini_effective_function_calling_mode_switches_auto_to_validated_for_server_tools():
    assert (
        chat_router._gemini_effective_function_calling_mode(
            "AUTO",
            include_server_side_tool_invocations=True,
        )
        == "VALIDATED"
    )
    assert (
        chat_router._gemini_effective_function_calling_mode(
            "ANY",
            include_server_side_tool_invocations=True,
        )
        == "ANY"
    )
    assert (
        chat_router._gemini_effective_function_calling_mode(
            None,
            include_server_side_tool_invocations=False,
        )
        == "AUTO"
    )


def test_gemini_build_rest_payload_includes_server_side_tool_invocations_flag():
    payload = chat_router._gemini_build_rest_payload(
        contents=[{"role": "user", "parts": [{"text": "hello"}]}],
        system_instruction="be helpful",
        tools=[
            {
                "functionDeclarations": [{"name": "read_file"}],
            },
            {"googleSearch": {}},
        ],
        function_call_mode="AUTO",
        allowed_function_names=["read_file"],
        include_server_side_tool_invocations=True,
    )

    assert payload["toolConfig"]["includeServerSideToolInvocations"] is True
    assert payload["toolConfig"]["functionCallingConfig"]["mode"] == "VALIDATED"
    assert "allowedFunctionNames" not in payload["toolConfig"]["functionCallingConfig"]


def test_gemini_build_rest_payload_skips_function_calling_config_for_builtin_tools_only():
    payload = chat_router._gemini_build_rest_payload(
        contents=[{"role": "user", "parts": [{"text": "hello"}]}],
        system_instruction="",
        tools=[{"googleSearch": {}}],
        function_call_mode="AUTO",
        allowed_function_names=None,
        include_server_side_tool_invocations=True,
    )

    assert payload["toolConfig"] == {"includeServerSideToolInvocations": True}


def test_gemini_sanitize_schema_preserves_additional_properties_but_removes_refs():
    schema = {
        "type": "object",
        "properties": {
            "payload": {
                "type": "object",
                "additionalProperties": {"type": "string"},
                "$defs": {"Thing": {"type": "string"}},
                "$ref": "#/defs/Thing",
            }
        },
        "required": ["payload"],
        "additionalProperties": False,
        "defs": {"Top": {"type": "string"}},
        "ref": "#/defs/Top",
        "strict": True,
    }

    sanitized = chat_router._sanitize_for_gemini_schema(schema)

    assert sanitized == {
        "type": "object",
        "properties": {
            "payload": {
                "type": "object",
                "additionalProperties": {"type": "string"},
            }
        },
        "required": ["payload"],
        "additionalProperties": False,
    }


def test_gemini_sdk_function_declaration_uses_parameters_json_schema():
    from google.genai import types

    decl = chat_router._gemini_make_sdk_function_declaration(
        types,
        name="read_file",
        description="Read a file",
        parameters_schema={
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
            "additionalProperties": False,
            "$defs": {"Thing": {"type": "string"}},
        },
    )

    payload = decl.model_dump(mode="json", by_alias=True, exclude_none=True)

    assert payload == {
        "name": "read_file",
        "description": "Read a file",
        "parametersJsonSchema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
            "additionalProperties": False,
        },
    }


def test_gemini_build_sdk_tool_config_includes_server_side_tool_invocations_flag():
    from google.genai import types

    tool_cfg = chat_router._gemini_build_sdk_tool_config(
        types,
        function_call_mode="VALIDATED",
        allowed_function_names=None,
        has_function_tools=True,
        include_server_side_tool_invocations=True,
    )

    assert tool_cfg is not None
    assert tool_cfg.model_dump(mode="json", by_alias=True, exclude_none=True) == {
        "functionCallingConfig": {"mode": "VALIDATED"},
        "includeServerSideToolInvocations": True,
    }


def test_gemini_build_rest_payload_sanitizes_sdk_tool_objects():
    from google.genai import types

    decl = chat_router._gemini_make_sdk_function_declaration(
        types,
        name="read_file",
        description="Read a file",
        parameters_schema={
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
            "additionalProperties": False,
        },
    )

    payload = chat_router._gemini_build_rest_payload(
        contents=[{"role": "user", "parts": [{"text": "hello"}]}],
        system_instruction="",
        tools=[
            types.Tool(function_declarations=[decl]),
            types.Tool(google_search=types.GoogleSearch()),
        ],
        function_call_mode="AUTO",
        allowed_function_names=None,
        include_server_side_tool_invocations=True,
    )

    assert payload["tools"] == [
        {
            "functionDeclarations": [
                {
                    "name": "read_file",
                    "description": "Read a file",
                    "parametersJsonSchema": {
                        "type": "object",
                        "properties": {"path": {"type": "string"}},
                        "required": ["path"],
                        "additionalProperties": False,
                    },
                }
            ]
        },
        {"googleSearch": {}},
    ]
    assert payload["toolConfig"] == {
        "functionCallingConfig": {"mode": "VALIDATED"},
        "includeServerSideToolInvocations": True,
    }


def test_gemini_build_function_response_part_keeps_function_call_id_for_rest_mode():
    part = chat_router._gemini_build_function_response_part(
        name="read_file",
        result={"ok": True},
        call_id="call-123",
        genai_types=None,
    )

    assert part == {
        "functionResponse": {
            "name": "read_file",
            "response": {"result": {"ok": True}},
            "id": "call-123",
        }
    }


def test_gemini_rest_extract_function_calls_and_tool_parts():
    response = {
        "candidates": [
            {
                "content": {
                    "role": "model",
                    "parts": [
                        {
                            "toolCall": {
                                "toolType": "GOOGLE_SEARCH",
                                "id": "tool-1",
                            },
                            "thoughtSignature": "abc",
                        },
                        {
                            "functionCall": {
                                "name": "read_file",
                                "args": {"path": "docs/geminidocs.txt"},
                                "id": "call-1",
                            }
                        },
                    ],
                }
            }
        ]
    }

    calls = chat_router._gemini_rest_extract_function_calls(response)
    assert calls == [
        {
            "id": "call-1",
            "name": "read_file",
            "args": {"path": "docs/geminidocs.txt"},
        }
    ]
    assert chat_router._gemini_message_has_server_tool_parts(
        chat_router._gemini_rest_extract_first_content(response)
    )
