import pytest

from app.routers.chat_adapter import _backend_billing_source


@pytest.mark.parametrize(
    "model",
    [
        None,
        "gpt-5.4",
        "claude-sonnet-4-6",
        "gemini-3.1-pro-preview",
        "grok-4.20-beta-0309-reasoning",
        "deepseek-chat-3.2",
        "kimi-k2.5",
        "glm-4.7",
    ],
)
def test_backend_billing_source_is_generic_henosis(model):
    assert _backend_billing_source(model) == "backend_henosis"
