import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_pyproject_discovers_henosis_cli_tools_subpackages():
    content = (ROOT / "pyproject.toml").read_text(encoding="utf-8")

    assert "[tool.setuptools.packages.find]" in content
    assert '"henosis_cli_tools.*"' in content


def test_cli_entry_import_survives_missing_access_adapters_package(tmp_path):
    pkg_src = ROOT / "henosis_cli_tools"
    pkg_dst = tmp_path / "henosis_cli_tools"

    copied_files = {
        "__init__.py",
        "tool_impl.py",
        "settings_ui.py",
        "access_hub.py",
        "access_profiles.py",
        "cli_entry.py",
        "input_engine.py",
    }

    pkg_dst.mkdir()
    for name in copied_files:
        (pkg_dst / name).write_text((pkg_src / name).read_text(encoding="utf-8"), encoding="utf-8")

    code = """
import importlib
import pathlib
import sys

tmp_root = pathlib.Path(sys.argv[1]).resolve()
repo_root = pathlib.Path(sys.argv[2]).resolve()
sys.path.insert(0, str(tmp_root))
sys.path.insert(1, str(repo_root))

mod = importlib.import_module('henosis_cli_tools.cli_entry')
pkg = importlib.import_module('henosis_cli_tools')

assert callable(getattr(mod, 'main', None))
assert hasattr(pkg, 'FileToolPolicy')
print('ok')
"""

    completed = subprocess.run(
        [sys.executable, "-c", code, str(tmp_path), str(ROOT)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )

    assert completed.returncode == 0, completed.stderr or completed.stdout
    assert completed.stdout.strip() == "ok"
