import asyncio

import app.services.remote_machine_link as remote_machine_link_mod
from app.services.remote_machine_link import RemoteMachineLinkService


async def _no_redis():
    return None


class _MachineSocket:
    def __init__(self, service, user_id, machine_id):
        self.service = service
        self.user_id = user_id
        self.machine_id = machine_id
        self.payloads = []

    async def send_json(self, payload):
        self.payloads.append(payload)
        message_type = payload.get("type")
        data = payload.get("data") or {}
        if message_type == "machine.spawn.request":
            asyncio.get_running_loop().create_task(
                self.service.handle_machine_message(
                    self.user_id,
                    self.machine_id,
                    "machine.spawn.response",
                    {
                        "request_id": data.get("request_id"),
                        "ok": True,
                        "terminal_id": data.get("terminal_id"),
                        "pid": 4242,
                        "cwd": data.get("cwd"),
                    },
                )
            )
        elif message_type == "machine.dir.list.request":
            asyncio.get_running_loop().create_task(
                self.service.handle_machine_message(
                    self.user_id,
                    self.machine_id,
                    "machine.dir.list.response",
                    {
                        "request_id": data.get("request_id"),
                        "ok": True,
                        "current_path": data.get("path") or "C:/repo",
                        "entries": [{"name": "src", "path": "C:/repo/src", "kind": "directory"}],
                    },
                )
            )
        elif message_type == "machine.session.list.request":
            asyncio.get_running_loop().create_task(
                self.service.handle_machine_message(
                    self.user_id,
                    self.machine_id,
                    "machine.session.list.response",
                    {
                        "request_id": data.get("request_id"),
                        "ok": True,
                        "sessions": [{"terminal_id": "term-spawned", "pid": 4242, "status": "running"}],
                    },
                )
            )
        elif message_type == "machine.session.stop.request":
            asyncio.get_running_loop().create_task(
                self.service.handle_machine_message(
                    self.user_id,
                    self.machine_id,
                    "machine.session.stop.response",
                    {
                        "request_id": data.get("request_id"),
                        "ok": True,
                        "terminal_id": data.get("terminal_id"),
                    },
                )
            )
        elif message_type == "machine.session.restart.request":
            asyncio.get_running_loop().create_task(
                self.service.handle_machine_message(
                    self.user_id,
                    self.machine_id,
                    "machine.session.restart.response",
                    {
                        "request_id": data.get("request_id"),
                        "ok": True,
                        "terminal_id": data.get("terminal_id"),
                        "pid": 5252,
                    },
                )
            )
        elif message_type == "machine.session.remove.request":
            asyncio.get_running_loop().create_task(
                self.service.handle_machine_message(
                    self.user_id,
                    self.machine_id,
                    "machine.session.remove.response",
                    {
                        "request_id": data.get("request_id"),
                        "ok": True,
                        "terminal_id": data.get("terminal_id"),
                        "removed": True,
                    },
                )
            )
        elif message_type == "machine.session.cleanup_stale.request":
            asyncio.get_running_loop().create_task(
                self.service.handle_machine_message(
                    self.user_id,
                    self.machine_id,
                    "machine.session.cleanup_stale.response",
                    {
                        "request_id": data.get("request_id"),
                        "ok": True,
                        "removed_count": 1,
                        "removed_terminal_ids": ["term-stale"],
                    },
                )
            )
        elif message_type == "machine.session.output.request":
            asyncio.get_running_loop().create_task(
                self.service.handle_machine_message(
                    self.user_id,
                    self.machine_id,
                    "machine.session.output.response",
                    {
                        "request_id": data.get("request_id"),
                        "ok": True,
                        "terminal_id": data.get("terminal_id"),
                        "output": "hello world",
                        "truncated": False,
                    },
                )
            )


def test_machine_summary_includes_link_metadata(monkeypatch):
    monkeypatch.setattr(remote_machine_link_mod, "get_redis", _no_redis)
    service = RemoteMachineLinkService()

    socket = _MachineSocket(service, "user-1", "machine-a")
    machine_id = asyncio.run(service.register_machine("user-1", "machine-a", socket))
    asyncio.run(
        service.machine_hello(
            "user-1",
            machine_id,
            {
                "machine_id": machine_id,
                "device_name": "Windows PC",
                "host_name": "dev-box",
                "platform": "win32",
                "cwd": "C:/repo",
                "default_start_dir": "C:/repo/project",
                "cli_version": "0.6.26",
                "display_name": "Windows PC",
            },
        )
    )

    machines = asyncio.run(service.list_machines("user-1"))

    assert machines == [
        {
            "machine_id": "machine-a",
            "display_name": "Windows PC",
            "device_id": None,
            "device_name": "Windows PC",
            "host_name": "dev-box",
            "platform": "win32",
            "cwd": "C:/repo",
            "host_base": None,
            "default_start_dir": "C:/repo/project",
            "cli_version": "0.6.26",
            "online": True,
            "connected_at": machines[0]["connected_at"],
            "last_seen_at": machines[0]["last_seen_at"],
        }
    ]


def test_request_spawn_round_trips_through_machine_socket(monkeypatch):
    monkeypatch.setattr(remote_machine_link_mod, "get_redis", _no_redis)
    service = RemoteMachineLinkService()

    socket = _MachineSocket(service, "user-1", "machine-a")
    machine_id = asyncio.run(service.register_machine("user-1", "machine-a", socket))

    result = asyncio.run(
        service.request_spawn(
            "user-1",
            machine_id,
            cwd="C:/repo/project",
            terminal_id="term-spawned",
            model="gpt-5.4",
        )
    )

    assert socket.payloads == [
        {
            "type": "machine.spawn.request",
            "data": {
                "cwd": "C:/repo/project",
                "terminal_id": "term-spawned",
                "model": "gpt-5.4",
                "request_id": result["request_id"],
            },
        }
    ]
    assert result["ok"] is True
    assert result["terminal_id"] == "term-spawned"
    assert result["pid"] == 4242


def test_browse_directories_round_trips_through_machine_socket(monkeypatch):
    monkeypatch.setattr(remote_machine_link_mod, "get_redis", _no_redis)
    service = RemoteMachineLinkService()

    socket = _MachineSocket(service, "user-1", "machine-a")
    machine_id = asyncio.run(service.register_machine("user-1", "machine-a", socket))

    result = asyncio.run(service.browse_directories("user-1", machine_id, path="C:/repo"))

    assert socket.payloads == [
        {
            "type": "machine.dir.list.request",
            "data": {
                "path": "C:/repo",
                "request_id": result["request_id"],
            },
        }
    ]
    assert result["ok"] is True
    assert result["current_path"] == "C:/repo"
    assert result["entries"] == [{"name": "src", "path": "C:/repo/src", "kind": "directory"}]


def test_list_sessions_round_trips_through_machine_socket(monkeypatch):
    monkeypatch.setattr(remote_machine_link_mod, "get_redis", _no_redis)
    service = RemoteMachineLinkService()

    socket = _MachineSocket(service, "user-1", "machine-a")
    machine_id = asyncio.run(service.register_machine("user-1", "machine-a", socket))

    result = asyncio.run(service.list_sessions("user-1", machine_id))

    assert socket.payloads == [
        {
            "type": "machine.session.list.request",
            "data": {
                "request_id": result["request_id"],
            },
        }
    ]
    assert result["ok"] is True
    assert result["sessions"] == [{"terminal_id": "term-spawned", "pid": 4242, "status": "running"}]


def test_stop_session_round_trips_through_machine_socket(monkeypatch):
    monkeypatch.setattr(remote_machine_link_mod, "get_redis", _no_redis)
    service = RemoteMachineLinkService()

    socket = _MachineSocket(service, "user-1", "machine-a")
    machine_id = asyncio.run(service.register_machine("user-1", "machine-a", socket))

    result = asyncio.run(service.stop_session("user-1", machine_id, terminal_id="term-spawned"))

    assert socket.payloads == [
        {
            "type": "machine.session.stop.request",
            "data": {
                "terminal_id": "term-spawned",
                "request_id": result["request_id"],
            },
        }
    ]
    assert result["ok"] is True
    assert result["terminal_id"] == "term-spawned"


def test_restart_session_round_trips_through_machine_socket(monkeypatch):
    monkeypatch.setattr(remote_machine_link_mod, "get_redis", _no_redis)
    service = RemoteMachineLinkService()

    socket = _MachineSocket(service, "user-1", "machine-a")
    machine_id = asyncio.run(service.register_machine("user-1", "machine-a", socket))

    result = asyncio.run(service.restart_session("user-1", machine_id, terminal_id="term-spawned"))

    assert socket.payloads == [
        {
            "type": "machine.session.restart.request",
            "data": {
                "terminal_id": "term-spawned",
                "request_id": result["request_id"],
            },
        }
    ]
    assert result["ok"] is True
    assert result["terminal_id"] == "term-spawned"
    assert result["pid"] == 5252


def test_remove_session_round_trips_through_machine_socket(monkeypatch):
    monkeypatch.setattr(remote_machine_link_mod, "get_redis", _no_redis)
    service = RemoteMachineLinkService()

    socket = _MachineSocket(service, "user-1", "machine-a")
    machine_id = asyncio.run(service.register_machine("user-1", "machine-a", socket))

    result = asyncio.run(service.remove_session("user-1", machine_id, terminal_id="term-spawned"))

    assert socket.payloads == [
        {
            "type": "machine.session.remove.request",
            "data": {
                "terminal_id": "term-spawned",
                "request_id": result["request_id"],
            },
        }
    ]
    assert result["ok"] is True
    assert result["terminal_id"] == "term-spawned"
    assert result["removed"] is True


def test_cleanup_stale_sessions_round_trips_through_machine_socket(monkeypatch):
    monkeypatch.setattr(remote_machine_link_mod, "get_redis", _no_redis)
    service = RemoteMachineLinkService()

    socket = _MachineSocket(service, "user-1", "machine-a")
    machine_id = asyncio.run(service.register_machine("user-1", "machine-a", socket))

    result = asyncio.run(service.cleanup_stale_sessions("user-1", machine_id))

    assert socket.payloads == [
        {
            "type": "machine.session.cleanup_stale.request",
            "data": {
                "request_id": result["request_id"],
            },
        }
    ]
    assert result["ok"] is True
    assert result["removed_count"] == 1
    assert result["removed_terminal_ids"] == ["term-stale"]


def test_read_session_output_round_trips_through_machine_socket(monkeypatch):
    monkeypatch.setattr(remote_machine_link_mod, "get_redis", _no_redis)
    service = RemoteMachineLinkService()

    socket = _MachineSocket(service, "user-1", "machine-a")
    machine_id = asyncio.run(service.register_machine("user-1", "machine-a", socket))

    result = asyncio.run(service.read_session_output("user-1", machine_id, terminal_id="term-spawned", max_chars=12000))

    assert socket.payloads == [
        {
            "type": "machine.session.output.request",
            "data": {
                "terminal_id": "term-spawned",
                "max_chars": 12000,
                "request_id": result["request_id"],
            },
        }
    ]
    assert result["ok"] is True
    assert result["terminal_id"] == "term-spawned"
    assert result["output"] == "hello world"
