from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session

from app.services.model_logs import extract_input_cache_split, insert_model_log


def test_extract_input_cache_split_openai_cached_tokens():
    usage = {
        "prompt_tokens": 1000,
        "input_tokens_details": {"cached_tokens": 600},
    }
    cached, non_cached = extract_input_cache_split(usage, 1000)
    assert cached == 600
    assert non_cached == 400


def test_extract_input_cache_split_openai_prompt_tokens_details():
    usage = {
        "prompt_tokens": 1000,
        "prompt_tokens_details": {"cached_tokens": 600},
    }
    cached, non_cached = extract_input_cache_split(usage, 1000)
    assert cached == 600
    assert non_cached == 400


def test_extract_input_cache_split_anthropic_cache_fields():
    usage = {
        "prompt_tokens": 1000,
        "cache_read_input_tokens": 200,
        "cache_creation_input_tokens": 300,
    }
    cached, non_cached = extract_input_cache_split(usage, 1000)
    assert cached == 500
    assert non_cached == 500


def test_extract_input_cache_split_prefers_provider_step_cached_sum_when_larger():
    usage = {
        "prompt_tokens": 2000,
        "input_tokens_details": {"cached_tokens": 900},
        "provider_steps": [
            {"stage": "turn", "cached_input_tokens": 700},
            {"stage": "turn", "cached_input_tokens": 900},
        ],
    }
    cached, non_cached = extract_input_cache_split(usage, 2000)
    assert cached == 1600
    assert non_cached == 400


def test_insert_model_log_falls_back_when_cache_columns_missing():
    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    with Session(engine) as db:
        db.execute(
            text(
                """
                CREATE TABLE model_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT,
                    model_id TEXT,
                    tokens_input INTEGER,
                    tokens_output INTEGER,
                    cost REAL,
                    status TEXT,
                    created_at TEXT
                )
                """
            )
        )
        insert_model_log(
            db,
            user_id="u1",
            model_id="gpt-5.3-codex",
            tokens_input=1000,
            tokens_output=200,
            cost=0.123,
            status="codex_local",
            cached_input_tokens=700,
            non_cached_input_tokens=300,
        )
        db.commit()
        row = db.execute(
            text(
                """
                SELECT user_id, model_id, tokens_input, tokens_output, cost, status
                FROM model_logs
                LIMIT 1
                """
            )
        ).mappings().first()
        assert row is not None
        assert row["user_id"] == "u1"
        assert row["status"] == "codex_local"
        assert int(row["tokens_input"] or 0) == 1000


def test_insert_model_log_writes_cache_columns_when_available():
    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    with Session(engine) as db:
        db.execute(
            text(
                """
                CREATE TABLE model_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT,
                    model_id TEXT,
                    tokens_input INTEGER,
                    tokens_output INTEGER,
                    cost REAL,
                    status TEXT,
                    cached_input_tokens INTEGER,
                    non_cached_input_tokens INTEGER,
                    created_at TEXT
                )
                """
            )
        )
        insert_model_log(
            db,
            user_id="u2",
            model_id="gpt-5.3-codex",
            tokens_input=900,
            tokens_output=100,
            cost=0.111,
            status="success",
            cached_input_tokens=400,
            non_cached_input_tokens=500,
        )
        db.commit()
        row = db.execute(
            text(
                """
                SELECT cached_input_tokens, non_cached_input_tokens
                FROM model_logs
                LIMIT 1
                """
            )
        ).mappings().first()
        assert row is not None
        assert int(row["cached_input_tokens"] or 0) == 400
        assert int(row["non_cached_input_tokens"] or 0) == 500


def test_insert_model_log_writes_billing_source_when_available():
    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    with Session(engine) as db:
        db.execute(
            text(
                """
                CREATE TABLE model_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT,
                    model_id TEXT,
                    tokens_input INTEGER,
                    tokens_output INTEGER,
                    cost REAL,
                    status TEXT,
                    billing_source TEXT,
                    cached_input_tokens INTEGER,
                    non_cached_input_tokens INTEGER,
                    created_at TEXT
                )
                """
            )
        )
        insert_model_log(
            db,
            user_id="u3",
            model_id="gpt-5.4",
            tokens_input=120,
            tokens_output=30,
            cost=0.42,
            status="success",
            billing_source="codex_local",
            cached_input_tokens=20,
            non_cached_input_tokens=100,
        )
        db.commit()
        row = db.execute(
            text(
                """
                SELECT status, billing_source
                FROM model_logs
                LIMIT 1
                """
            )
        ).mappings().first()
        assert row is not None
        assert row["status"] == "success"
        assert row["billing_source"] == "codex_local"


def test_admin_codex_local_filter_sql_matches_billing_source_and_legacy_status():
    from app.routers import admin as admin_router

    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    with Session(engine) as db:
        db.execute(
            text(
                """
                CREATE TABLE model_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT,
                    model_id TEXT,
                    tokens_input INTEGER,
                    tokens_output INTEGER,
                    cost REAL,
                    status TEXT,
                    billing_source TEXT,
                    created_at TEXT
                )
                """
            )
        )
        db.execute(
            text(
                """
                INSERT INTO model_logs (user_id, model_id, tokens_input, tokens_output, cost, status, billing_source, created_at)
                VALUES
                    ('u1', 'gpt-5.4', 10, 5, 0.1, 'success', 'codex_local', '2026-01-01 00:00:00'),
                    ('u1', 'gpt-5.4', 10, 5, 0.1, 'codex_local', NULL, '2026-01-01 00:01:00'),
                    ('u1', 'gpt-5.4', 10, 5, 0.1, 'success', 'backend_openai', '2026-01-01 00:02:00')
                """
            )
        )
        where = admin_router._codex_local_filter_sql(db, "billing_source")
        rows = db.execute(
            text(
                f"""
                SELECT status, billing_source
                FROM model_logs
                WHERE {where}
                ORDER BY created_at ASC
                """
            ),
            {"billing_source": "codex_local"},
        ).mappings().all()
        assert len(rows) == 2
        assert rows[0]["billing_source"] == "codex_local"
        assert rows[1]["status"] == "codex_local"
