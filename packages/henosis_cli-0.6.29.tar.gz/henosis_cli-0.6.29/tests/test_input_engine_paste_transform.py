import signal
import threading

from henosis_cli_tools import input_engine as ie


class _FakeUser32:
    def GetKeyState(self, _vk: int) -> int:
        return 0


class _ChunkedFakeMsvcrt:
    def __init__(self, bursts) -> None:
        self._bursts = [list(b) for b in bursts if b]
        self._idx = 0
        self._gap_pending = False

    def _active_burst(self):
        if self._idx >= len(self._bursts):
            return None
        return self._bursts[self._idx]

    def kbhit(self) -> bool:
        active = self._active_burst()
        if active and len(active) > 0:
            return True
        if self._idx + 1 < len(self._bursts):
            if not self._gap_pending:
                self._gap_pending = True
                return False
            self._idx += 1
            self._gap_pending = False
            nxt = self._active_burst()
            return bool(nxt)
        return False

    def getwch(self) -> str:
        active = self._active_burst()
        if not active:
            raise AssertionError("getwch() called with empty queue")
        return active.pop(0)


def _build_windows_engine(fake_msvcrt: _ChunkedFakeMsvcrt) -> ie.WindowsKeyEngine:
    engine = object.__new__(ie.WindowsKeyEngine)
    engine.msvcrt = fake_msvcrt
    engine.user32 = _FakeUser32()
    engine.VK_SHIFT = 0x10
    return engine


def _patch_signal(monkeypatch):
    original_handler = object()

    def _fake_getsignal(sig):
        assert sig == signal.SIGINT
        return original_handler

    def _fake_signal(sig, _handler):
        assert sig == signal.SIGINT
        return None

    monkeypatch.setattr(signal, "getsignal", _fake_getsignal)
    monkeypatch.setattr(signal, "signal", _fake_signal)


class _SelectStub:
    def __init__(self, ready_checks=None):
        self._ready_checks = list(ready_checks or [])

    def select(self, _read, _write, _err, _timeout):
        if self._ready_checks:
            ready = bool(self._ready_checks.pop(0))
            if ready:
                return ([123], [], [])
        return ([], [], [])


def _build_posix_engine(payload: bytes) -> ie.PosixKeyEngine:
    engine = object.__new__(ie.PosixKeyEngine)
    engine.info = ie.EngineInfo(
        supports_shift_enter=False,
        hint="Enter sends; Ctrl+J inserts a newline.",
        fallback_key_name="Ctrl+J",
    )
    engine.enter_sigs = {b"\r", b"\n", b"\r\n"}
    engine.shift_sig = None
    engine.select = _SelectStub([False])
    engine.fd = 123
    engine.termios = type(
        "_TermiosStub",
        (),
        {"TCSADRAIN": 0, "tcsetattr": staticmethod(lambda *_args, **_kwargs: None)},
    )
    engine._orig_attrs = None
    engine._bracketed_paste_enabled = False

    payloads = [payload, b"\r"]

    def _read_bytes(timeout: float = 5.0) -> bytes:  # noqa: ARG001
        if payloads:
            return payloads.pop(0)
        return b""

    engine._read_bytes = _read_bytes  # type: ignore[attr-defined]
    engine.get_history = lambda: []  # type: ignore[assignment]
    engine._is_backspace = ie.PosixKeyEngine._is_backspace.__get__(engine, ie.PosixKeyEngine)
    return engine


def test_windows_chunked_multiline_paste_uses_transform(monkeypatch):
    _patch_signal(monkeypatch)
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda _txt: True)
    monkeypatch.setattr(ie, "_get_terminal_width", lambda default=80: 120)
    monkeypatch.setattr(ie.time, "sleep", lambda _seconds: None)
    monotonic_values = iter([0.0, 0.0, 0.04, 0.04, 0.08, 0.08])
    monkeypatch.setattr(ie.time, "monotonic", lambda: next(monotonic_values))

    bursts = [
        list("line1\nline2\nline3\nline4"),
        list("\nline5\nline6\nline7"),
        ["\r"],
    ]
    fake_msvcrt = _ChunkedFakeMsvcrt(bursts)
    engine = _build_windows_engine(fake_msvcrt)

    transformed_inputs = []

    def _transform(text: str) -> str:
        transformed_inputs.append(text)
        return "[[paste:1]]"

    result = engine.read_message("You: ", "", paste_transform=_transform)

    assert result == "[[paste:1]]"
    assert transformed_inputs == [
        "line1\nline2\nline3\nline4\nline5\nline6\nline7"
    ]


def test_windows_single_line_burst_with_enter_submits(monkeypatch):
    _patch_signal(monkeypatch)
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda _txt: True)
    monkeypatch.setattr(ie, "_get_terminal_width", lambda default=80: 120)
    monkeypatch.setattr(ie.time, "sleep", lambda _seconds: None)

    fake_msvcrt = _ChunkedFakeMsvcrt([list("hello\r\n")])
    engine = _build_windows_engine(fake_msvcrt)

    transformed_inputs = []

    def _transform(text: str) -> str:
        transformed_inputs.append(text)
        return text

    result = engine.read_message("You: ", "", paste_transform=_transform)

    assert result == "hello"
    assert transformed_inputs == ["hello"]


def test_posix_multibyte_multiline_paste_uses_transform(monkeypatch):
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda _txt: True)
    monkeypatch.setattr(ie, "_get_terminal_width", lambda default=80: 120)
    monkeypatch.setattr(ie.time, "sleep", lambda _seconds: None)
    monotonic_values = iter([0.0, 0.0, 0.04, 0.04, 0.08, 0.08])
    monkeypatch.setattr(ie.time, "monotonic", lambda: next(monotonic_values))

    payload = b"line1\nline2\nline3\nline4\nline5\nline6\nline7"
    engine = _build_posix_engine(payload)

    transformed_inputs = []

    def _transform(text: str) -> str:
        transformed_inputs.append(text)
        return "[[paste:1]]"

    result = engine.read_message("You: ", "", stop_event=threading.Event(), paste_transform=_transform)

    assert result == "[[paste:1]]"
    assert transformed_inputs == [
        "line1\nline2\nline3\nline4\nline5\nline6\nline7"
    ]


def test_posix_single_line_chunk_with_enter_submits(monkeypatch):
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda _txt: True)
    monkeypatch.setattr(ie, "_get_terminal_width", lambda default=80: 120)
    monkeypatch.setattr(ie.time, "sleep", lambda _seconds: None)

    engine = _build_posix_engine(b"hello\r\n")

    transformed_inputs = []

    def _transform(text: str) -> str:
        transformed_inputs.append(text)
        return text

    result = engine.read_message("You: ", "", stop_event=threading.Event(), paste_transform=_transform)

    assert result == "hello"
    assert transformed_inputs == ["hello"]
