import asyncio
import importlib

from henosis_cli_tools.access_hub import AUTH_MODE_DROID_SUB, AUTH_MODE_GITHUB_SUB


def _make_cli(tmp_path):
    cli_mod = importlib.import_module("cli")
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )
    cli.access_routes_file = tmp_path / "henosis_cli_access.json"
    cli.provider_keys_file = tmp_path / "henosis_cli_provider_keys.json"
    cli.codex_auth_file = tmp_path / "henosis_cli_codex_auth.json"
    cli.codex_shared_auth_file = tmp_path / "codex_shared_auth" / "auth.json"
    cli._load_access_hub_state()
    return cli


def test_model_auth_menu_includes_subscription_routes_when_model_is_supported(tmp_path, monkeypatch):
    monkeypatch.setenv("HENOSIS_ENABLE_EXPERIMENTAL_SUB_ROUTES", "1")
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None

    gh_adapter = cli.access_hub.get_execution_adapter("sub:github_copilot")
    droid_adapter = cli.access_hub.get_execution_adapter("sub:droid")
    monkeypatch.setattr(gh_adapter, "supports_model", lambda model_id: model_id in {"gpt-5.4", "claude-sonnet-4-6"})
    monkeypatch.setattr(droid_adapter, "supports_model", lambda model_id: model_id in {"claude-sonnet-4-6", "deepseek-chat-3.2"})

    openai_choices = [value for value, _label in cli._model_auth_menu_choices("gpt-5.4")]
    claude_choices = [value for value, _label in cli._model_auth_menu_choices("claude-sonnet-4-6")]

    assert AUTH_MODE_GITHUB_SUB in openai_choices
    assert AUTH_MODE_GITHUB_SUB in claude_choices
    assert AUTH_MODE_DROID_SUB in claude_choices


def test_billing_source_display_text_covers_subscription_routes(tmp_path, monkeypatch):
    monkeypatch.setenv("HENOSIS_ENABLE_EXPERIMENTAL_SUB_ROUTES", "1")
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None

    gh_adapter = cli.access_hub.get_execution_adapter("sub:github_copilot")
    droid_adapter = cli.access_hub.get_execution_adapter("sub:droid")
    monkeypatch.setattr(gh_adapter, "supports_model", lambda model_id: model_id == "gpt-5.4")
    monkeypatch.setattr(droid_adapter, "supports_model", lambda model_id: model_id == "gemini-3.1-pro-preview")
    monkeypatch.setattr(gh_adapter, "get_readiness_status", lambda: importlib.import_module("henosis_cli_tools.access_profiles").ProfileReadinessStatus(state="ready", ready=True, detail="ready"))
    monkeypatch.setattr(droid_adapter, "get_readiness_status", lambda: importlib.import_module("henosis_cli_tools.access_profiles").ProfileReadinessStatus(state="ready", ready=True, detail="ready"))

    cli.access_hub.set_model_override("gpt-5.4", AUTH_MODE_GITHUB_SUB)
    cli.access_hub.set_model_override("gemini-3.1-pro-preview", AUTH_MODE_DROID_SUB)

    assert cli._billing_source_display_text("gpt-5.4") == "Billed via your GitHub Copilot subscription"
    assert cli._billing_source_display_text("gemini-3.1-pro-preview") == "Billed via your Droid subscription"


def test_stream_once_executes_github_subscription_route_locally(tmp_path, monkeypatch):
    monkeypatch.setenv("HENOSIS_ENABLE_EXPERIMENTAL_SUB_ROUTES", "1")
    cli = _make_cli(tmp_path)
    cli.model = "gpt-5.4"
    cli.auth_user = "henosis"
    assert cli.access_hub is not None

    gh_adapter = cli.access_hub.get_execution_adapter("sub:github_copilot")
    monkeypatch.setattr(gh_adapter, "supports_model", lambda model_id: model_id == "gpt-5.4")
    monkeypatch.setattr(
        gh_adapter,
        "get_readiness_status",
        lambda: importlib.import_module("henosis_cli_tools.access_profiles").ProfileReadinessStatus(
            state="ready", ready=True, detail="configured"
        ),
    )
    monkeypatch.setattr(
        gh_adapter,
        "execute_turn",
        lambda *, model_id, prompt, cwd=None: {
            "ok": True,
            "text": "hello from github sub",
            "usage": {"prompt_tokens": 6, "completion_tokens": 2, "total_tokens": 8},
            "model": model_id,
            "billing_source": "sub_github_copilot",
        },
    )
    monkeypatch.setattr(cli, "_commit_usage", lambda *args, **kwargs: asyncio.sleep(0))
    monkeypatch.setattr(cli, "_render_status_info", lambda ctx: None)

    cli.access_hub.set_model_override("gpt-5.4", AUTH_MODE_GITHUB_SUB)

    out = asyncio.run(cli._stream_once("ship it"))

    assert out == "hello from github sub"


def test_auth_status_includes_subscription_profiles(tmp_path, monkeypatch):
    monkeypatch.setenv("HENOSIS_ENABLE_EXPERIMENTAL_SUB_ROUTES", "1")
    cli = _make_cli(tmp_path)
    rendered = []
    assert cli.access_hub is not None

    gh_adapter = cli.access_hub.get_execution_adapter("sub:github_copilot")
    droid_adapter = cli.access_hub.get_execution_adapter("sub:droid")
    monkeypatch.setattr(gh_adapter, "get_readiness_status", lambda: importlib.import_module("henosis_cli_tools.access_profiles").ProfileReadinessStatus(state="ready", ready=True, detail="github ready"))
    monkeypatch.setattr(droid_adapter, "get_readiness_status", lambda: importlib.import_module("henosis_cli_tools.access_profiles").ProfileReadinessStatus(state="unknown", ready=False, detail="droid setup pending"))
    monkeypatch.setattr(cli.ui, "info_box", lambda title, lines: rendered.append((title, list(lines))))

    handled = asyncio.run(cli.handle_command("/auth status"))

    assert handled is True
    title, lines = rendered[-1]
    assert title == "Local provider auth"
    assert any("GitHub Copilot sub" in line for line in lines)
    assert any("Droid sub" in line for line in lines)


def test_model_auth_menu_hides_subscription_routes_by_default(tmp_path, monkeypatch):
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None

    gh_adapter = cli.access_hub.get_execution_adapter("sub:github_copilot")
    droid_adapter = cli.access_hub.get_execution_adapter("sub:droid")
    monkeypatch.setattr(gh_adapter, "supports_model", lambda model_id: model_id in {"gpt-5.4", "claude-sonnet-4-6"})
    monkeypatch.setattr(droid_adapter, "supports_model", lambda model_id: model_id in {"claude-sonnet-4-6", "deepseek-chat-3.2"})

    openai_choices = [value for value, _label in cli._model_auth_menu_choices("gpt-5.4")]
    claude_choices = [value for value, _label in cli._model_auth_menu_choices("claude-sonnet-4-6")]

    assert AUTH_MODE_GITHUB_SUB not in openai_choices
    assert AUTH_MODE_GITHUB_SUB not in claude_choices
    assert AUTH_MODE_DROID_SUB not in claude_choices


def test_auth_status_hides_subscription_profiles_by_default(tmp_path, monkeypatch):
    cli = _make_cli(tmp_path)
    rendered = []

    monkeypatch.setattr(cli.ui, "info_box", lambda title, lines: rendered.append((title, list(lines))))

    handled = asyncio.run(cli.handle_command("/auth status"))

    assert handled is True
    title, lines = rendered[-1]
    assert title == "Local provider auth"
    assert not any("GitHub Copilot sub" in line for line in lines)
    assert not any("Droid sub" in line for line in lines)
