import asyncio
import importlib
import os
from contextlib import asynccontextmanager
import json

import pytest

from henosis_cli_tools.access_hub import (
    AccessHub,
    AUTH_MODE_BACKEND,
    AUTH_MODE_BYOK,
    AUTH_MODE_CODEX,
    PROFILE_ID_BACKEND,
    PROFILE_ID_CODEX,
    byok_profile_id_for_provider,
    default_access_profile_for_mode,
)


def _make_cli(tmp_path):
    cli_mod = importlib.import_module("cli")
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )
    cli.access_routes_file = tmp_path / "henosis_cli_access.json"
    cli.provider_keys_file = tmp_path / "henosis_cli_provider_keys.json"
    cli.codex_auth_file = tmp_path / "henosis_cli_codex_auth.json"
    cli.codex_shared_auth_file = tmp_path / "codex_shared_auth" / "auth.json"
    cli._load_access_hub_state()
    return cli


def test_access_hub_persists_provider_defaults_model_overrides_and_keys(tmp_path):
    routes_path = tmp_path / "routes.json"
    keys_path = tmp_path / "keys.json"

    hub = AccessHub(routes_path=routes_path, keys_path=keys_path)
    assert hub.describe_model_access("gpt-5.4", codex_available_for_model=True)["mode"] == AUTH_MODE_CODEX

    assert hub.set_provider_key("anthropic", "sk-ant-123456789") is True
    assert hub.set_provider_default("anthropic", AUTH_MODE_BYOK) is True
    assert hub.set_model_override("gpt-5.4", AUTH_MODE_BACKEND) is True

    reloaded = AccessHub(routes_path=routes_path, keys_path=keys_path)

    claude_desc = reloaded.describe_model_access("claude-sonnet-4-6")
    assert claude_desc["provider"] == "anthropic"
    assert claude_desc["mode"] == AUTH_MODE_BYOK
    assert claude_desc["ready"] is True
    assert claude_desc["source"] == "provider_default"

    gpt_desc = reloaded.describe_model_access("gpt-5.4", codex_available_for_model=True)
    assert gpt_desc["mode"] == AUTH_MODE_BACKEND
    assert gpt_desc["source"] == "model_override"


def test_phase_zero_profile_helpers_keep_codex_and_byok_mapping_explicit():
    assert PROFILE_ID_BACKEND == "backend:henosis"
    assert PROFILE_ID_CODEX == "oauth:codex"
    assert byok_profile_id_for_provider("anthropic") == "byok:anthropic"

    codex_profile = default_access_profile_for_mode(AUTH_MODE_CODEX, "openai")
    assert codex_profile.profile_id == PROFILE_ID_CODEX
    assert codex_profile.billing_source == "oauth_codex"

    byok_profile = default_access_profile_for_mode(AUTH_MODE_BYOK, "anthropic")
    assert byok_profile.profile_id == "byok:anthropic"
    assert byok_profile.billing_source == "byok_anthropic"


def test_describe_model_access_adds_profile_metadata_without_changing_mode_resolution(tmp_path):
    hub = AccessHub(routes_path=tmp_path / "routes.json", keys_path=tmp_path / "keys.json")

    codex_desc = hub.describe_model_access("gpt-5.4", codex_available_for_model=True)
    assert codex_desc["mode"] == AUTH_MODE_CODEX
    assert codex_desc["profile_id"] == PROFILE_ID_CODEX
    assert codex_desc["profile"].billing_source == "oauth_codex"
    assert codex_desc["profile_readiness"].state == "unknown"

    assert hub.set_provider_key("anthropic", "sk-ant-123456789") is True
    assert hub.set_model_override("claude-sonnet-4-6", AUTH_MODE_BYOK) is True
    byok_desc = hub.describe_model_access("claude-sonnet-4-6")
    assert byok_desc["mode"] == AUTH_MODE_BYOK
    assert byok_desc["profile_id"] == "byok:anthropic"
    assert byok_desc["profile"].billing_source == "byok_anthropic"


def test_describe_provider_exposes_byok_profile_metadata(tmp_path):
    hub = AccessHub(routes_path=tmp_path / "routes.json", keys_path=tmp_path / "keys.json")

    desc = hub.describe_provider("anthropic")

    assert desc["byok_profile_id"] == "byok:anthropic"
    assert desc["byok_billing_source"] == "byok_anthropic"


def test_codex_routing_respects_explicit_backend_override(tmp_path):
    cli = _make_cli(tmp_path)
    cli.codex_route_all_openai_models = True
    cli.codex_access_token = "access-token-123"
    cli.codex_refresh_token = "refresh-token-123"

    assert cli._should_use_local_codex_for_model("gpt-5.4") is True

    assert cli.access_hub is not None
    assert cli.access_hub.set_model_override("gpt-5.4", AUTH_MODE_BACKEND) is True

    assert cli._should_use_local_codex_for_model("gpt-5.4") is False


def test_model_auth_menu_choices_are_provider_aware(tmp_path):
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None
    cli.access_hub.set_provider_key("anthropic", "sk-ant-123456789")

    openai_choices = [value for value, _label in cli._model_auth_menu_choices("gpt-5.4")]
    anthropic_choices = [value for value, _label in cli._model_auth_menu_choices("claude-sonnet-4-6")]

    assert AUTH_MODE_CODEX in openai_choices
    assert AUTH_MODE_BYOK in openai_choices
    assert AUTH_MODE_CODEX not in anthropic_choices
    assert AUTH_MODE_BYOK in anthropic_choices


def test_model_access_badges_reflect_byok_missing_and_backend(tmp_path):
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None

    cli.access_hub.set_model_override("claude-sonnet-4-6", AUTH_MODE_BYOK)
    assert cli._model_access_badges("claude-sonnet-4-6") == ["AUTH: BYOK MISSING"]

    cli.access_hub.set_model_override("gpt-5.4", AUTH_MODE_BACKEND)
    assert cli._model_access_badges("gpt-5.4") == ["AUTH: HENOSIS"]


def test_codex_route_does_not_change_input_prompt_label(tmp_path):
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None
    cli.model = "gpt-5.4"
    cli.codex_access_token = "access-token-123"
    cli.codex_refresh_token = "refresh-token-123"
    cli.access_hub.set_model_override("gpt-5.4", AUTH_MODE_CODEX)

    assert cli._chat_prompt_label() == "You: "
    assert cli._edit_prompt_label() == "Edit> "


def test_byok_route_does_not_change_input_prompt_label(tmp_path):
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None
    cli.model = "claude-sonnet-4-6"
    cli.access_hub.set_provider_key("anthropic", "sk-ant-123456789")
    cli.access_hub.set_model_override("claude-sonnet-4-6", AUTH_MODE_BYOK)

    assert cli._chat_prompt_label() == "You: "
    assert cli._edit_prompt_label() == "Edit> "


def test_billing_source_display_text_is_generic_for_backend_byok_and_codex(tmp_path):
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None
    cli.codex_access_token = None
    cli.codex_refresh_token = None

    assert cli._billing_source_display_text("gpt-5.4") == "Billed via Henosis credits"

    cli.access_hub.set_provider_key("anthropic", "sk-ant-123456789")
    cli.access_hub.set_model_override("claude-sonnet-4-6", AUTH_MODE_BYOK)
    assert cli._billing_source_display_text("claude-sonnet-4-6") == "Billed via your Anthropic API key"

    cli.codex_access_token = "access-token-123"
    cli.codex_refresh_token = "refresh-token-123"
    cli.access_hub.set_model_override("gpt-5.4", AUTH_MODE_CODEX)
    assert cli._billing_source_display_text("gpt-5.4") == "Billed via your OpenAI Codex subscription"


def test_stream_once_refuses_to_silently_send_byok_routes_to_backend(tmp_path):
    cli = _make_cli(tmp_path)
    cli.model = "claude-sonnet-4-6"
    assert cli.access_hub is not None
    cli.access_hub.set_model_override("claude-sonnet-4-6", AUTH_MODE_BYOK)

    with pytest.raises(RuntimeError, match="not ready"):
        asyncio.run(cli._stream_once("hello"))


def test_auth_status_command_renders_local_provider_summary(tmp_path, monkeypatch):
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None
    cli.access_hub.set_provider_key("anthropic", "sk-ant-123456789")
    rendered = []

    monkeypatch.setattr(cli.ui, "info_box", lambda title, lines: rendered.append((title, list(lines))))

    handled = asyncio.run(cli.handle_command("/auth status"))

    assert handled is True
    assert rendered
    title, lines = rendered[-1]
    assert title == "Local provider auth"
    assert any("Anthropic" in line for line in lines)


def test_open_settings_exposes_provider_auth_actions_and_routes_to_menu(tmp_path, monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli(tmp_path)

    captured_items = []
    opened = []

    class _FakeSettingsUI:
        def __init__(self, title, items, initial, defaults, footer=None, on_change=None):
            captured_items.append(items)

        def run(self):
            return True, {"__settings_action__": "provider_auth_openai"}

    async def _fake_open_provider_auth_menu(provider):
        opened.append(provider)

    monkeypatch.setattr(cli_mod, "SettingsUI", _FakeSettingsUI)
    monkeypatch.setattr(cli, "_open_provider_auth_menu", _fake_open_provider_auth_menu)

    asyncio.run(cli.open_settings())

    assert captured_items
    provider_group = next(group for group in captured_items[0] if group.get("label") == "Provider Auth")
    provider_ids = [row.get("id") for row in (provider_group.get("items") or [])]
    assert "provider_auth_openai" in provider_ids
    assert "provider_auth_anthropic" in provider_ids
    assert "provider_auth_github_copilot" not in provider_ids
    assert "provider_auth_droid" not in provider_ids
    assert opened == ["openai"]


def test_hidden_subscription_routes_cannot_be_selected_by_default(tmp_path):
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None

    assert cli.access_hub.set_model_override("gpt-5.4", "github_copilot_sub") is False
    assert cli.access_hub.set_model_override("gemini-3.1-pro-preview", "droid_sub") is False


def test_default_local_access_model_prefers_available_byok_provider(tmp_path):
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None
    cli.codex_access_token = None
    cli.codex_refresh_token = None
    cli.access_hub.set_provider_key("gemini", "gem-key-123456")

    assert cli._default_local_access_model() == "gemini-3.1-pro-preview"


def test_usage_commit_meta_for_byok_models_uses_provider_billing_source(tmp_path):
    cli = _make_cli(tmp_path)
    assert cli.access_hub is not None
    cli.access_hub.set_provider_key("anthropic", "sk-ant-123456789")
    cli.access_hub.set_model_override("claude-sonnet-4-6", AUTH_MODE_BYOK)

    meta = cli._usage_commit_meta_for_model("claude-sonnet-4-6")

    assert meta == {"billing_source": "byok_anthropic", "path": "local_byok"}


def test_stream_once_uses_local_byok_stream_context(tmp_path, monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli(tmp_path)
    cli.model = "claude-sonnet-4-6"
    assert cli.access_hub is not None
    cli.access_hub.set_provider_key("anthropic", "sk-ant-123456789")
    cli.access_hub.set_model_override("claude-sonnet-4-6", AUTH_MODE_BYOK)

    used_local_context = []

    class _FakeRemoteClient:
        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

    class _FakeLocalResp:
        status_code = 200
        headers = {"content-type": "text/event-stream"}

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        def raise_for_status(self):
            return None

        async def aread(self):
            return b""

        async def aiter_lines(self):
            payload = {
                "model": "claude-sonnet-4-6",
                "text": "hello from byok",
                "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
            }
            for line in [
                'event: session.started',
                'data: {"session_id":"local-byok-session","level":3,"fs_scope":"workspace"}',
                '',
                'event: message.completed',
                'data: ' + json.dumps(payload),
                '',
            ]:
                yield line

    class _FakeLocalClient:
        def stream(self, *args, **kwargs):
            return _FakeLocalResp()

        async def aclose(self):
            return None

    @asynccontextmanager
    async def _fake_local_context(req_payload, http_timeout):
        used_local_context.append(dict(req_payload or {}))
        yield _FakeLocalClient(), "http://henosis-local/chat/stream"

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", lambda *args, **kwargs: _FakeRemoteClient())
    monkeypatch.setattr(cli, "_local_byok_stream_context", _fake_local_context)

    out = asyncio.run(cli._stream_once("hello"))

    assert out == "hello from byok"
    assert used_local_context


def test_local_byok_stream_context_clears_non_selected_provider_keys(tmp_path, monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli(tmp_path)
    cli.model = "claude-sonnet-4-6"
    assert cli.access_hub is not None
    cli.access_hub.set_provider_key("anthropic", "local-anthropic-key")

    from app.settings import settings as app_settings

    monkeypatch.setattr(app_settings, "OPENAI_API_KEY", "env-openai-key", raising=False)
    monkeypatch.setattr(app_settings, "ANTHROPIC_API_KEY", "env-anthropic-key", raising=False)
    monkeypatch.setattr(app_settings, "GEMINI_API_KEY", "env-gemini-key", raising=False)

    async def _run():
        async with cli._local_byok_stream_context(
            {"model": "claude-sonnet-4-6"},
            cli_mod.httpx.Timeout(5.0),
        ):
            assert app_settings.ANTHROPIC_API_KEY == "local-anthropic-key"
            assert app_settings.OPENAI_API_KEY is None
            assert app_settings.GEMINI_API_KEY is None

        assert app_settings.OPENAI_API_KEY == "env-openai-key"
        assert app_settings.ANTHROPIC_API_KEY == "env-anthropic-key"
        assert app_settings.GEMINI_API_KEY == "env-gemini-key"

    asyncio.run(_run())


def test_local_byok_stream_context_temporarily_silences_env_loader(tmp_path, monkeypatch):
    cli_mod = importlib.import_module("cli")
    cli = _make_cli(tmp_path)
    cli.model = "claude-sonnet-4-6"
    assert cli.access_hub is not None
    cli.access_hub.set_provider_key("anthropic", "local-anthropic-key")

    seen_import_env_values = []
    original_import = __import__

    def _spy_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name in ("app.settings", "app.routers") or str(name).startswith("app.settings"):
            seen_import_env_values.append(os.environ.get("HENOSIS_ENV_LOADER_VERBOSE"))
        return original_import(name, globals, locals, fromlist, level)

    monkeypatch.delenv("HENOSIS_ENV_LOADER_VERBOSE", raising=False)
    monkeypatch.setattr("builtins.__import__", _spy_import)

    async def _run():
        async with cli._local_byok_stream_context(
            {"model": "claude-sonnet-4-6"},
            cli_mod.httpx.Timeout(5.0),
        ):
            assert os.environ.get("HENOSIS_ENV_LOADER_VERBOSE") is None

        assert os.environ.get("HENOSIS_ENV_LOADER_VERBOSE") is None

    asyncio.run(_run())

    assert "0" in seen_import_env_values


def test_render_status_info_force_billing_prepends_billing_for_presets(tmp_path, monkeypatch):
    cli = _make_cli(tmp_path)
    cli.usage_info_mode = "concise"
    cli.status_fields = None
    seen = {}

    monkeypatch.setattr(
        cli,
        "_render_status_info",
        lambda ctx: seen.setdefault("fields", list(cli.status_fields or [])),
    )

    cli._render_status_info_force_billing({"billing_line": "Billing: Billed via Henosis credits"})

    assert seen["fields"] == ["billing", "context-meter", "tool-calls"]
    assert cli.status_fields is None


def test_render_status_info_force_billing_preserves_custom_fields(tmp_path, monkeypatch):
    cli = _make_cli(tmp_path)
    cli.status_fields = ["context-meter", "tool-calls"]
    seen = {}

    monkeypatch.setattr(
        cli,
        "_render_status_info",
        lambda ctx: seen.setdefault("fields", list(cli.status_fields or [])),
    )

    cli._render_status_info_force_billing({"billing_line": "Billing: Billed via your Anthropic API key"})

    assert seen["fields"] == ["billing", "context-meter", "tool-calls"]
    assert cli.status_fields == ["context-meter", "tool-calls"]


def test_model_byok_selection_prompts_for_key_and_stores_it(tmp_path, monkeypatch):
    cli = _make_cli(tmp_path)
    cli.model = "claude-sonnet-4-6"
    assert cli.access_hub is not None

    responses = iter([AUTH_MODE_BYOK, "add_now"])

    async def _fake_menu_choice(title, text, choices):
        return next(responses)

    monkeypatch.setattr(cli, "_menu_choice", _fake_menu_choice)
    monkeypatch.setattr("getpass.getpass", lambda prompt: "sk-ant-123456789")

    changed = asyncio.run(cli._prompt_model_auth_method("claude-sonnet-4-6"))

    assert changed is True
    assert cli.access_hub.has_provider_key("anthropic") is True
    assert cli._describe_model_access("claude-sonnet-4-6")["mode"] == AUTH_MODE_BYOK
    assert cli._describe_model_access("claude-sonnet-4-6")["ready"] is True


def test_model_byok_selection_can_cancel_without_saving_override(tmp_path, monkeypatch):
    cli = _make_cli(tmp_path)
    cli.model = "claude-sonnet-4-6"
    assert cli.access_hub is not None

    responses = iter([AUTH_MODE_BYOK, "cancel"])

    async def _fake_menu_choice(title, text, choices):
        return next(responses)

    monkeypatch.setattr(cli, "_menu_choice", _fake_menu_choice)

    changed = asyncio.run(cli._prompt_model_auth_method("claude-sonnet-4-6"))

    assert changed is False
    assert cli._describe_model_access("claude-sonnet-4-6")["mode"] == AUTH_MODE_BACKEND
