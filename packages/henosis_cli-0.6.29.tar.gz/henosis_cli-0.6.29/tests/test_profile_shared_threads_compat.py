from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.routers import profile as profile_router


def _build_profile_app(*, include_public_id: bool):
    engine = create_engine(
        "sqlite://",
        future=True,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

    shared_public_id_col = ", public_id TEXT" if include_public_id else ""

    with engine.begin() as conn:
        conn.execute(
            text(
                """
                CREATE TABLE users (
                    id INTEGER PRIMARY KEY,
                    username TEXT,
                    email TEXT,
                    is_verified BOOLEAN,
                    is_admin BOOLEAN,
                    credits REAL,
                    subscription_tier TEXT,
                    subscription_status TEXT,
                    current_period_end TEXT,
                    created_at TEXT,
                    stripe_customer_id TEXT
                )
                """
            )
        )
        conn.execute(text("CREATE TABLE subscription_tiers (name TEXT PRIMARY KEY, monthly_credits REAL)"))
        conn.execute(
            text(
                """
                CREATE TABLE custom_instructions (
                    user_id TEXT,
                    instructions TEXT,
                    last_model TEXT,
                    experimental_features TEXT,
                    sidebar_position TEXT,
                    created_at TEXT,
                    updated_at TEXT
                )
                """
            )
        )
        conn.execute(
            text(
                f"""
                CREATE TABLE shared_threads (
                    thread_id INTEGER,
                    created_at TEXT
                    {shared_public_id_col}
                )
                """
            )
        )
        conn.execute(text("CREATE TABLE threads (id INTEGER PRIMARY KEY, user_id INTEGER, name TEXT)"))
        conn.execute(text("CREATE TABLE projects (id INTEGER PRIMARY KEY, user_id INTEGER, name TEXT, description TEXT, created_at TEXT)"))
        conn.execute(text("CREATE TABLE device_tokens (device_id TEXT, user_id INTEGER, device_name TEXT, last_used TEXT, created_at TEXT, is_trusted BOOLEAN)"))
        conn.execute(
            text(
                """
                INSERT INTO users (
                    id, username, email, is_verified, is_admin, credits, subscription_tier,
                    subscription_status, current_period_end, created_at, stripe_customer_id
                ) VALUES (
                    1, 'henosis', 'henosis@example.com', 1, 0, 7.5, 'free', 'none', NULL, '2026-01-01', NULL
                )
                """
            )
        )
        conn.execute(text("INSERT INTO subscription_tiers (name, monthly_credits) VALUES ('free', 10.0)"))
        conn.execute(text("INSERT INTO threads (id, user_id, name) VALUES (42, 1, 'Migrated thread')"))
        if include_public_id:
            conn.execute(
                text(
                    "INSERT INTO shared_threads (thread_id, created_at, public_id) VALUES (42, '2026-01-02', 'public-42')"
                )
            )
        else:
            conn.execute(text("INSERT INTO shared_threads (thread_id, created_at) VALUES (42, '2026-01-02')"))

    app = FastAPI()
    app.include_router(profile_router.router)

    def override_db():
        db = SessionLocal()
        try:
            yield db
        finally:
            db.close()

    app.dependency_overrides[profile_router.get_db] = override_db
    app.dependency_overrides[profile_router.get_current_user] = lambda: "henosis"
    return app


def test_profile_shared_threads_query_handles_missing_public_id_column():
    app = _build_profile_app(include_public_id=False)
    client = TestClient(app)

    response = client.get("/api/profile")
    assert response.status_code == 200, response.text
    body = response.json()

    assert body["shared_threads"] == [
        {
            "thread_id": 42,
            "name": "Migrated thread",
            "created_at": "2026-01-02",
            "public_id": None,
        }
    ]


def test_profile_shared_threads_query_returns_public_id_when_present():
    app = _build_profile_app(include_public_id=True)
    client = TestClient(app)

    response = client.get("/api/profile")
    assert response.status_code == 200, response.text
    body = response.json()

    assert body["shared_threads"][0]["public_id"] == "public-42"
