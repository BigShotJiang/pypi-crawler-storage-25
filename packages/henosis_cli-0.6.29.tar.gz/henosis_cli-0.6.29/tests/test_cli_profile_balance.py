import asyncio
import importlib
import uuid
from pathlib import Path


def _new_local_tmp() -> Path:
    base = Path.cwd() / ".pytest_local_tmp"
    base.mkdir(parents=True, exist_ok=True)
    path = base / f"profile-balance-{uuid.uuid4().hex[:10]}"
    path.mkdir(parents=True, exist_ok=False)
    return path


def make_cli(tmp_path: Path):
    cli_mod = importlib.import_module("cli")
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )
    cli.codex_auth_file = tmp_path / "henosis_cli_codex_auth.json"
    cli.codex_shared_auth_file = tmp_path / "codex_shared_auth" / "auth.json"
    return cli


class _FakeProfileResponse:
    status_code = 200
    headers = {"content-type": "application/json"}

    def __init__(self, payload):
        self._payload = payload

    def json(self):
        return self._payload


def test_load_profile_for_tier_prefers_authoritative_remaining_credits(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def get(self, url):
            return _FakeProfileResponse(
                {
                    "user": {
                        "subscription_tier": "personal",
                        "subscription_status": "active",
                        "credits": 0.0,
                        "tier_monthly_credits": 40.0,
                        "remaining_credits": 27.5,
                    }
                }
            )

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    asyncio.run(cli._load_profile_for_tier())

    assert cli.subscription_tier == "personal"
    assert cli.subscription_status == "active"
    assert cli._last_remaining_credits == 27.5


def test_load_profile_for_tier_does_not_treat_zero_user_credits_as_authoritative(monkeypatch):
    tmp_path = _new_local_tmp()
    cli_mod = importlib.import_module("cli")
    cli = make_cli(tmp_path)

    class _FakeAsyncClient:
        def __init__(self, *args, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def get(self, url):
            return _FakeProfileResponse(
                {
                    "user": {
                        "subscription_tier": "personal",
                        "subscription_status": "active",
                        "credits": 0.0,
                        "tier_monthly_credits": 40.0,
                    }
                }
            )

    monkeypatch.setattr(cli_mod.httpx, "AsyncClient", _FakeAsyncClient)

    asyncio.run(cli._load_profile_for_tier())

    assert cli._last_remaining_credits == 40.0
