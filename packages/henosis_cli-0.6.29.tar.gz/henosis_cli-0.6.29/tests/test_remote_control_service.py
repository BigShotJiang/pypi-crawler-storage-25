import asyncio

import app.services.remote_control as remote_control_mod
from app.services.remote_control import RemoteControlService, TerminalConnection


class _FakeRedisPipeline:
    def __init__(self, redis):
        self._redis = redis
        self._ops = []

    def get(self, key):
        self._ops.append(("get", key))
        return self

    async def execute(self):
        out = []
        for op, key in self._ops:
            if op == "get":
                out.append(self._redis._kv.get(key))
        self._ops.clear()
        return out


class _FakeRedis:
    def __init__(self):
        self._kv = {}
        self._zsets = {}
        self._counter = 0
        self.published = []

    async def get(self, key):
        return self._kv.get(key)

    async def set(self, key, value, ex=None, nx=False):
        if nx and key in self._kv:
            return False
        self._kv[key] = value
        return True

    async def delete(self, *keys):
        removed = 0
        for key in keys:
            if key in self._kv:
                removed += 1
                self._kv.pop(key, None)
        return removed

    async def exists(self, key):
        return 1 if key in self._kv else 0

    async def incr(self, _key):
        self._counter += 1
        return self._counter

    async def zscore(self, key, member):
        return self._zsets.get(key, {}).get(member)

    async def zadd(self, key, mapping):
        bucket = self._zsets.setdefault(key, {})
        bucket.update(mapping)
        return len(mapping)

    async def zrange(self, key, start, end):
        items = sorted(self._zsets.get(key, {}).items(), key=lambda item: (item[1], item[0]))
        members = [member for member, _score in items]
        if end == -1:
            return members[start:]
        return members[start : end + 1]

    async def zrem(self, key, *members):
        bucket = self._zsets.get(key, {})
        removed = 0
        for member in members:
            if member in bucket:
                removed += 1
                bucket.pop(member, None)
        return removed

    def pipeline(self):
        return _FakeRedisPipeline(self)

    async def publish(self, channel, payload):
        self.published.append((channel, payload))
        return 1


def _enable_shared_registry(monkeypatch):
    fake_redis = _FakeRedis()

    async def _fake_get_redis():
        return fake_redis

    monkeypatch.setattr(remote_control_mod, "get_redis", _fake_get_redis)
    return fake_redis


def test_message_completed_replays_final_text_into_snapshot():
    service = RemoteControlService()

    updated = service._apply_terminal_event_locked(
        "term-1",
        {
            "terminal": {"terminal_id": "term-1"},
            "current_turn": {
                "active": True,
                "assistant_so_far": "",
                "tool_events": [],
            },
        },
        "message.completed",
        {
            "model": "gpt-5.4",
            "text": "Final answer from completion payload",
        },
    )

    assert updated["current_turn"]["active"] is False
    assert updated["current_turn"]["assistant_so_far"] == "Final answer from completion payload"
    assert updated["model"] == "gpt-5.4"
    assert updated["last_completed"]["text"] == "Final answer from completion payload"


def test_terminal_summary_includes_remote_control_metadata_fields():
    service = RemoteControlService()
    terminal = TerminalConnection(
        user_id="user-1",
        terminal_id="term-1",
        websocket=object(),
        order_index=1,
        hello={
            "terminal": {
                "terminal_id": "term-1",
                "label": "Workstation",
                "terminal_alias": "Orion-17",
                "terminal_short_id": "term-1",
                "display_name": "Orion-17",
                "cli_version": "1.2.3",
                "host_base": "C:/repo",
                "model_presets": [
                    {"value": "gpt-5.4", "label": "OpenAI: gpt-5.4"},
                ],
            }
        },
        snapshot={
            "terminal": {
                "terminal_id": "term-1",
                "cwd": "C:/repo/app",
            },
            "requested_tools": True,
            "fs_scope": "host",
            "control_level": 3,
            "current_turn": {
                "active": False,
                "tool_events": [],
            },
        },
    )

    summary = service._terminal_summary_locked(terminal)

    assert summary["label"] == "Workstation"
    assert summary["terminal_alias"] == "Orion-17"
    assert summary["terminal_short_id"] == "term-1"
    assert summary["display_name"] == "Orion-17"
    assert summary["cwd"] == "C:/repo/app"
    assert summary["host_base"] == "C:/repo"
    assert summary["requested_tools"] is True
    assert summary["fs_scope"] == "host"
    assert summary["control_level"] == 3
    assert summary["model_presets"] == [{"value": "gpt-5.4", "label": "OpenAI: gpt-5.4"}]


def test_settings_update_waits_for_terminal_state_before_mutating_snapshot():
    service = RemoteControlService()
    terminal = TerminalConnection(
        user_id="user-1",
        terminal_id="term-1",
        websocket=object(),
        order_index=1,
        snapshot={
            "terminal": {"terminal_id": "term-1"},
            "settings": {"host_base": "C:/old"},
            "host_base": "C:/old",
        },
    )
    service._terminals = {"user-1": {"term-1": terminal}}
    service._browsers = {
        "user-1": {
            "browser-1": type(
                "BrowserStub",
                (),
                {"selected_terminal_id": "term-1", "websocket": object()},
            )()
        }
    }

    class TerminalSocket:
        def __init__(self):
            self.payloads = []

        async def send_json(self, payload):
            self.payloads.append(payload)

    socket = TerminalSocket()
    terminal.websocket = socket

    import asyncio

    ok, terminal_id = asyncio.run(
        service.forward_browser_message(
            "user-1",
            "browser-1",
            "settings.update",
            {"settings": {"host_base": "C:/new"}},
        )
    )

    assert ok is True
    assert terminal_id == "term-1"
    assert socket.payloads == [
        {"type": "settings.update", "data": {"settings": {"host_base": "C:/new"}}}
    ]
    assert terminal.snapshot["settings"]["host_base"] == "C:/old"
    assert terminal.snapshot["host_base"] == "C:/old"


def test_choice_request_and_clear_round_trip_in_snapshot():
    service = RemoteControlService()

    snapshot = service._apply_terminal_event_locked(
        "term-1",
        {"terminal": {"terminal_id": "term-1"}},
        "choice.request",
        {
            "request_id": "choice-1",
            "kind": "codex_usage_limit",
            "title": "Codex limit reached",
        },
    )

    assert snapshot["pending_choice"]["request_id"] == "choice-1"

    cleared = service._apply_terminal_event_locked(
        "term-1",
        snapshot,
        "choice.cleared",
        {"request_id": "choice-1"},
    )

    assert "pending_choice" not in cleared


def test_terminal_list_order_is_stable_and_not_activity_sorted():
    service = RemoteControlService()
    service._terminals = {
        "user-1": {
            "term-a": TerminalConnection(
                user_id="user-1",
                terminal_id="term-a",
                websocket=object(),
                order_index=1,
                connected_at="2025-01-01T00:00:00+00:00",
                last_seen_at="2025-01-01T00:00:01+00:00",
                hello={"terminal": {"label": "Alpha"}},
            ),
            "term-b": TerminalConnection(
                user_id="user-1",
                terminal_id="term-b",
                websocket=object(),
                order_index=2,
                connected_at="2025-01-01T00:00:02+00:00",
                last_seen_at="2025-01-01T00:09:59+00:00",
                hello={"terminal": {"label": "Bravo"}},
            ),
        }
    }

    terminals = service._list_terminals_locked("user-1")

    assert [item["terminal_id"] for item in terminals] == ["term-a", "term-b"]


def test_register_terminal_auto_selects_browsers_waiting_for_terminal():
    service = RemoteControlService()

    class BrowserSocket:
        def __init__(self):
            self.payloads = []

        async def send_json(self, payload):
            self.payloads.append(payload)

    browser_socket = BrowserSocket()

    import asyncio

    browser_id = asyncio.run(service.register_browser("user-1", browser_socket))

    assert service._browsers["user-1"][browser_id].selected_terminal_id is None

    terminal_socket = BrowserSocket()
    asyncio.run(service.register_terminal("user-1", "term-1", terminal_socket))

    assert service._browsers["user-1"][browser_id].selected_terminal_id == "term-1"
    assert any(
        payload.get("type") == "remote.selected"
        and payload.get("data", {}).get("terminal_id") == "term-1"
        for payload in browser_socket.payloads
    )
    assert any(
        payload.get("type") == "remote.snapshot"
        and payload.get("data", {}).get("terminal_id") == "term-1"
        for payload in browser_socket.payloads
    )


def test_terminal_events_forward_terminal_id_to_selected_browser():
    service = RemoteControlService()

    class BrowserSocket:
        def __init__(self):
            self.payloads = []

        async def send_json(self, payload):
            self.payloads.append(payload)

    browser_socket = BrowserSocket()
    terminal = TerminalConnection(
        user_id="user-1",
        terminal_id="term-1",
        websocket=object(),
        order_index=1,
        snapshot={"terminal": {"terminal_id": "term-1"}},
    )
    service._terminals = {"user-1": {"term-1": terminal}}
    service._browsers = {
        "user-1": {
            "browser-1": type(
                "BrowserStub",
                (),
                {"selected_terminal_id": "term-1", "websocket": browser_socket},
            )()
        }
    }

    import asyncio

    asyncio.run(
        service.ingest_terminal_event(
            "user-1",
            "term-1",
            "message.delta",
            {"text": "hello"},
        )
    )

    assert browser_socket.payloads == [
        {"type": "message.delta", "data": {"text": "hello", "terminal_id": "term-1"}}
    ]


def test_register_terminal_remaps_duplicate_terminal_ids_instead_of_replacing():
    service = RemoteControlService()

    class TerminalSocket:
        async def send_json(self, payload):
            return payload

        async def close(self, *args, **kwargs):
            raise AssertionError("duplicate terminal registration should not replace the existing socket")

    import asyncio

    first_terminal_id = asyncio.run(service.register_terminal("user-1", "term-1", TerminalSocket()))
    second_terminal_id = asyncio.run(service.register_terminal("user-1", "term-1", TerminalSocket()))

    assert first_terminal_id == "term-1"
    assert second_terminal_id != "term-1"
    assert second_terminal_id.startswith("term-1-")

    terminals = service._list_terminals_locked("user-1")
    assert [item["terminal_id"] for item in terminals] == [first_terminal_id, second_terminal_id]


def test_shared_registry_lists_terminals_across_service_instances(monkeypatch):
    _enable_shared_registry(monkeypatch)
    service_a = RemoteControlService()
    service_b = RemoteControlService()

    class TerminalSocket:
        async def send_json(self, payload):
            return payload

    first_terminal_id = asyncio.run(service_a.register_terminal("user-1", "term-a", TerminalSocket()))
    second_terminal_id = asyncio.run(service_b.register_terminal("user-1", "term-b", TerminalSocket()))

    terminals_from_a = asyncio.run(service_a.list_terminals("user-1"))
    terminals_from_b = asyncio.run(service_b.list_terminals("user-1"))

    assert [item["terminal_id"] for item in terminals_from_a] == [first_terminal_id, second_terminal_id]
    assert [item["terminal_id"] for item in terminals_from_b] == [first_terminal_id, second_terminal_id]


def test_shared_registry_browser_state_includes_terminals_from_other_workers(monkeypatch):
    _enable_shared_registry(monkeypatch)
    service_a = RemoteControlService()
    service_b = RemoteControlService()
    browser_service = RemoteControlService()

    class TerminalSocket:
        async def send_json(self, payload):
            return payload

    class BrowserSocket:
        def __init__(self):
            self.payloads = []

        async def send_json(self, payload):
            self.payloads.append(payload)

    asyncio.run(service_a.register_terminal("user-1", "term-a", TerminalSocket()))
    asyncio.run(service_b.register_terminal("user-1", "term-b", TerminalSocket()))

    browser_socket = BrowserSocket()
    browser_id = asyncio.run(browser_service.register_browser("user-1", browser_socket))

    assert browser_id
    terminals_payload = next(payload for payload in browser_socket.payloads if payload.get("type") == "remote.terminals")
    assert {item.get("terminal_id") for item in terminals_payload.get("data", {}).get("terminals", [])} == {"term-a", "term-b"}
    connected_payload = next(payload for payload in browser_socket.payloads if payload.get("type") == "remote.connected")
    assert connected_payload.get("data", {}).get("terminal_id") in {"term-a", "term-b"}
