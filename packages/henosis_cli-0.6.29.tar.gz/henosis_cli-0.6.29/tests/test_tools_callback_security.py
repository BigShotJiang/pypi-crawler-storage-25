import asyncio

from app.routers import tools as tools_router


def test_callback_invalid_when_token_mismatch_for_pending_job():
    async def _run() -> None:
        job = await tools_router.create_pending_job("sess-cb", "call-cb", "wait_process", ttl_sec=120)
        status = await tools_router.resolve_job("sess-cb", "call-cb", "wrong-token", {"ok": True})
        assert status == "invalid"
        assert await tools_router.pending_job_exists("sess-cb", "call-cb") is True
        # Clean up by resolving with the correct token so the in-memory pending map does not leak.
        status2 = await tools_router.resolve_job("sess-cb", "call-cb", job.token, {"ok": True})
        assert status2 == "ok"

    asyncio.run(_run())
