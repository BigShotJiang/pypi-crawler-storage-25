import os
import math
import pytest

from cli import ChatCLI


def make_cli(model: str | None = None) -> ChatCLI:
    # Minimal CLI with no network calls exercised in these tests
    return ChatCLI(
        server=os.getenv("HENOSIS_SERVER", "https://henosis.us/api_v2"),
        model=model,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )


def approx(a: float, b: float, rel: float = 1e-9, abs_tol: float = 1e-9) -> bool:
    return math.isclose(float(a), float(b), rel_tol=rel, abs_tol=abs_tol)


def test_openai_prompt_cache_cost_split():
    cli = make_cli()
    model = "gpt-5"
    usage = {
        "prompt_tokens": 1000,
        "completion_tokens": 500,
        "input_tokens_details": {"cached_tokens": 600},
    }
    # Pricing table in cli.py: gpt-5 input=$1.75/m, output=$14/m
    in_rate = 1.75
    out_rate = 14.0
    non_cached = 400
    cached = 600
    expected = (non_cached / 1_000_000) * in_rate
    expected += (cached / 1_000_000) * (in_rate * 0.10)
    expected += (500 / 1_000_000) * out_rate
    got = cli.compute_cost_usd(model, usage)
    assert approx(got, expected, rel=1e-12, abs_tol=1e-12)


def test_openai_prompt_cache_cost_split_from_prompt_tokens_details():
    cli = make_cli()
    model = "gpt-5"
    usage = {
        "prompt_tokens": 1000,
        "completion_tokens": 500,
        "prompt_tokens_details": {"cached_tokens": 600},
    }
    in_rate = 1.75
    out_rate = 14.0
    non_cached = 400
    cached = 600
    expected = (non_cached / 1_000_000) * in_rate
    expected += (cached / 1_000_000) * (in_rate * 0.10)
    expected += (500 / 1_000_000) * out_rate
    got = cli.compute_cost_usd(model, usage)
    assert approx(got, expected, rel=1e-12, abs_tol=1e-12)


def test_anthropic_image_tokens_count_as_input():
    cli = make_cli()
    model = "claude-sonnet-4-20250514"
    usage = {
        "prompt_tokens": 1000,
        "completion_tokens": 400,
        "image_tokens": 200,
    }
    # Pricing table in cli.py: input=$4.20/m, output=$21/m
    in_rate = 4.20
    out_rate = 21.0
    # image tokens added to prompt side
    expected = ((1000 + 200) / 1_000_000) * in_rate + (400 / 1_000_000) * out_rate
    got = cli.compute_cost_usd(model, usage)
    assert approx(got, expected, rel=1e-12, abs_tol=1e-12)


def test_reasoning_gap_billed_as_output_when_total_exceeds_sum():
    cli = make_cli()
    model = "gpt-5"
    usage = {
        "prompt_tokens": 1000,
        "completion_tokens": 400,
        "total_tokens": 1700,  # gap of 300 (think/reasoning, etc.)
    }
    in_rate = 1.75
    out_rate = 14.0
    gap = 1700 - (1000 + 400)
    expected = (1000 / 1_000_000) * in_rate + ((400 + gap) / 1_000_000) * out_rate
    got = cli.compute_cost_usd(model, usage)
    assert approx(got, expected, rel=1e-12, abs_tol=1e-12)


def test_deepseek_cache_pricing_path():
    cli = make_cli()
    model = "deepseek-chat-3.2"
    usage = {
        "prompt_cache_hit_tokens": 300,
        "prompt_cache_miss_tokens": 700,
        "completion_tokens": 200,
    }
    # deepseek-chat-3.2 pricing (cli.py): input=$0.53/m, output=$0.67/m, cache_hit=$0.278/m
    in_rate = 0.53
    out_rate = 0.67
    cache_hit_rate = 0.278
    expected = (300 / 1_000_000) * cache_hit_rate
    expected += (700 / 1_000_000) * in_rate
    expected += (200 / 1_000_000) * out_rate
    got = cli.compute_cost_usd(model, usage)
    assert approx(got, expected, rel=1e-12, abs_tol=1e-12)


def test_openai_cached_tokens_do_not_exceed_prompt_tokens():
    """Guardrail: if server reports more cached tokens than prompt tokens, clamp to prompt size.
    This prevents negative non-cached math and over/under-billing.
    """
    cli = make_cli()
    model = "gpt-5"
    usage = {
        "prompt_tokens": 150,
        "completion_tokens": 50,
        "input_tokens_details": {"cached_tokens": 1000},  # nonsensical; will be clamped to 150
    }
    in_rate = 1.75
    out_rate = 14.0
    non_cached = 0
    cached = 150
    expected = (non_cached / 1_000_000) * in_rate
    expected += (cached / 1_000_000) * (in_rate * 0.10)
    expected += (50 / 1_000_000) * out_rate
    got = cli.compute_cost_usd(model, usage)
    assert approx(got, expected, rel=1e-12, abs_tol=1e-12)


def test_gpt_54_context_scaling_applies_in_cli_and_backend():
    cli = make_cli()
    model = "gpt-5.4"
    usage = {
        "prompt_tokens": 300_000,
        "completion_tokens": 120_000,
        "input_tokens_details": {"cached_tokens": 80_000},
    }
    non_cached = 220_000
    cached = 80_000
    in_rate = 5.25
    cached_rate = 0.50
    out_rate = 22.75
    expected = (non_cached / 1_000_000) * in_rate
    expected += (cached / 1_000_000) * cached_rate
    expected += (120_000 / 1_000_000) * out_rate

    got_cli = cli.compute_cost_usd(model, usage)

    from app.routers.chat_adapter import _compute_cost_usd as backend_compute_cost_usd

    got_backend = backend_compute_cost_usd(model, usage)
    assert approx(got_cli, expected, rel=1e-12, abs_tol=1e-12)
    assert approx(got_backend, expected, rel=1e-12, abs_tol=1e-12)


def test_gpt_54_pro_context_scaling_applies_in_cli_and_backend():
    cli = make_cli()
    model = "gpt-5.4-pro"
    usage = {
        "prompt_tokens": 300_000,
        "completion_tokens": 90_000,
    }
    in_rate = 60.25
    out_rate = 270.25
    expected = (300_000 / 1_000_000) * in_rate
    expected += (90_000 / 1_000_000) * out_rate

    got_cli = cli.compute_cost_usd(model, usage)

    from app.routers.chat_adapter import _compute_cost_usd as backend_compute_cost_usd

    got_backend = backend_compute_cost_usd(model, usage)
    assert approx(got_cli, expected, rel=1e-12, abs_tol=1e-12)
    assert approx(got_backend, expected, rel=1e-12, abs_tol=1e-12)


def test_gpt_54_mini_cost_matches_backend_with_cached_input():
    cli = make_cli()
    model = "gpt-5.4-mini-2026-03-17"
    usage = {
        "prompt_tokens": 100_000,
        "completion_tokens": 20_000,
        "input_tokens_details": {"cached_tokens": 60_000},
    }
    expected = (40_000 / 1_000_000) * 1.00
    expected += (60_000 / 1_000_000) * 0.075
    expected += (20_000 / 1_000_000) * 4.75

    got_cli = cli.compute_cost_usd(model, usage)

    from app.routers.chat_adapter import _compute_cost_usd as backend_compute_cost_usd

    got_backend = backend_compute_cost_usd(model, usage)
    assert approx(got_cli, expected, rel=1e-12, abs_tol=1e-12)
    assert approx(got_backend, expected, rel=1e-12, abs_tol=1e-12)


def test_gpt_54_nano_cost_matches_backend_with_cached_input():
    cli = make_cli()
    model = "gpt-5.4-nano-2026-03-17"
    usage = {
        "prompt_tokens": 90_000,
        "completion_tokens": 15_000,
        "input_tokens_details": {"cached_tokens": 50_000},
    }
    expected = (40_000 / 1_000_000) * 0.45
    expected += (50_000 / 1_000_000) * 0.02
    expected += (15_000 / 1_000_000) * 1.50

    got_cli = cli.compute_cost_usd(model, usage)

    from app.routers.chat_adapter import _compute_cost_usd as backend_compute_cost_usd

    got_backend = backend_compute_cost_usd(model, usage)
    assert approx(got_cli, expected, rel=1e-12, abs_tol=1e-12)
    assert approx(got_backend, expected, rel=1e-12, abs_tol=1e-12)


def test_token_estimator_applies_gpt_54_context_scaling(monkeypatch):
    from app.services import token_estimator
    from app.settings import settings

    monkeypatch.setattr(token_estimator, "_heuristic_tokens", lambda _text: 300_000)
    monkeypatch.setattr(settings, "TOKEN_ESTIMATION_ENABLED", False)
    monkeypatch.setattr(settings, "TOKEN_ESTIMATION_INPUT_COST_MULTIPLIER", 1.0)

    est = token_estimator.estimate_tokens_and_cost(
        model="gpt-5.4",
        messages=[{"role": "user", "content": "hi"}],
        output_ratio=0.5,
    )

    expected = (300_000 / 1_000_000) * 5.25
    expected += (150_000 / 1_000_000) * 22.75
    assert approx(float(est["estimated_cost_usd"]), expected, rel=1e-12, abs_tol=1e-12)
