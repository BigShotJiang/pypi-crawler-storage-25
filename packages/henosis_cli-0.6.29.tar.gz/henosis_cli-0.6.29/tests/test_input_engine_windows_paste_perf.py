import os
import signal
import sys
import time
from pathlib import Path

import pytest

from henosis_cli_tools import input_engine as ie


class _FakeUser32:
    def GetKeyState(self, _vk: int) -> int:
        # High bit set means key is down. We return 0 => key up.
        return 0


class _FakeMsvcrt:
    """Feed a deterministic sequence of characters to WindowsKeyEngine.

    WindowsKeyEngine uses:
      - kbhit() to decide if a character is available
      - getwch() to read one character at a time
    """

    def __init__(self, queue) -> None:
        self._queue = list(queue)

    def kbhit(self) -> bool:
        return bool(self._queue)

    def getwch(self) -> str:
        if not self._queue:
            raise AssertionError("getwch() called with empty queue")
        return self._queue.pop(0)


class _CountingStdout:
    """A stdout sink that counts writes but doesn't keep large buffers in memory."""

    def __init__(self) -> None:
        self.write_calls = 0
        self.chars_written = 0

    def write(self, s: str) -> int:
        ss = str(s)
        self.write_calls += 1
        self.chars_written += len(ss)
        return len(ss)

    def flush(self) -> None:
        return None


class _LatencyCountingStdout(_CountingStdout):
    """Counting stdout sink with per-write latency to emulate terminal I/O cost."""

    def __init__(self, per_write_delay_sec: float) -> None:
        super().__init__()
        self._delay = max(0.0, float(per_write_delay_sec))

    def write(self, s: str) -> int:
        n = super().write(s)
        if self._delay:
            time.sleep(self._delay)
        return n


class _ChunkedFakeMsvcrt:
    """Emit characters in paste-like bursts with tiny idle gaps between bursts.

    This emulates a terminal that delivers pasted input in chunks instead of one
    monolithic queue, which is closer to real-world behavior.
    """

    def __init__(self, bursts) -> None:
        self._bursts = [list(b) for b in bursts if b]
        self._idx = 0
        self._gap_pending = False

    def _active_burst(self):
        if self._idx >= len(self._bursts):
            return None
        return self._bursts[self._idx]

    def kbhit(self) -> bool:
        active = self._active_burst()
        if active and len(active) > 0:
            return True
        if self._idx + 1 < len(self._bursts):
            # Return one "no data" poll between bursts to force a loop break.
            if not self._gap_pending:
                self._gap_pending = True
                return False
            self._idx += 1
            self._gap_pending = False
            nxt = self._active_burst()
            return bool(nxt)
        return False

    def getwch(self) -> str:
        active = self._active_burst()
        if not active:
            raise AssertionError("getwch() called with empty queue")
        return active.pop(0)


class _TimedChunkedFakeMsvcrt:
    """Emit bursts according to wall-clock release times.

    This is closer to a real terminal paste than `_ChunkedFakeMsvcrt` because
    `kbhit()` turns true only after the scheduled release time for each burst
    has elapsed, rather than after a fixed number of polling loops.
    """

    def __init__(self, bursts, *, start_time: float, inter_burst_delay_sec: float) -> None:
        cleaned = [list(b) for b in bursts if b]
        delay = max(0.0, float(inter_burst_delay_sec))
        self._bursts = cleaned
        self._release_times: list[float] = []
        t = float(start_time)
        for i, _burst in enumerate(cleaned):
            self._release_times.append(t)
            if i < len(cleaned) - 1:
                t += delay
        self._idx = 0

    def _advance_ready_burst(self) -> list[str] | None:
        now = time.perf_counter()
        while self._idx < len(self._bursts):
            active = self._bursts[self._idx]
            if active:
                if now >= self._release_times[self._idx]:
                    return active
                return None
            self._idx += 1
        return None

    def kbhit(self) -> bool:
        return self._advance_ready_burst() is not None

    def getwch(self) -> str:
        active = self._advance_ready_burst()
        if not active:
            raise AssertionError("getwch() called with no ready characters")
        ch = active.pop(0)
        if not active:
            self._idx += 1
        return ch


def _patch_signal(monkeypatch):
    """Prevent tests from modifying the real SIGINT handler."""

    original_handler = object()
    state = {"handler": None}

    def _fake_getsignal(sig):
        assert sig == signal.SIGINT
        return original_handler

    def _fake_signal(sig, handler):
        assert sig == signal.SIGINT
        state["handler"] = handler
        return None

    monkeypatch.setattr(signal, "getsignal", _fake_getsignal)
    monkeypatch.setattr(signal, "signal", _fake_signal)
    # Avoid time.sleep() delays in the read loop.
    monkeypatch.setattr(ie.time, "sleep", lambda _seconds: None)
    return original_handler, state


def _build_engine(fake_msvcrt: _FakeMsvcrt) -> ie.WindowsKeyEngine:
    # Bypass __init__ so we don't emit bracketed-paste enable sequences or touch
    # the real console.
    engine = object.__new__(ie.WindowsKeyEngine)
    engine.msvcrt = fake_msvcrt
    engine.user32 = _FakeUser32()
    engine.VK_SHIFT = 0x10
    return engine


def _read_issuelist_text() -> str:
    root = Path(__file__).resolve().parents[1]
    p = root / "issuelist.md"
    if not p.exists():
        raise AssertionError(f"Missing issuelist.md at {p}")
    return p.read_text(encoding="utf-8", errors="replace")


def _chunk_text(text: str, chunk_size: int) -> list[str]:
    if chunk_size <= 0:
        return [text]
    out = []
    i = 0
    while i < len(text):
        out.append(text[i : i + chunk_size])
        i += chunk_size
    return out


@pytest.mark.skipif(os.name != "nt", reason="Windows-only paste perf test")
def test_windows_bracketed_paste_issuelist_md_informational_perf(monkeypatch):
    """Informational benchmark for multiline bracketed paste.

    Uses exact issuelist.md contents as the paste payload.
    Prints metrics but does not assert on timing.
    """

    if os.environ.get("HENOSIS_RUN_TERMINAL_PERF", "0") != "1":
        pytest.skip("Set HENOSIS_RUN_TERMINAL_PERF=1 to run terminal perf tests")

    _patch_signal(monkeypatch)
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda _txt: True)
    # Stable width so redraw math is consistent.
    monkeypatch.setattr(ie, "_get_terminal_width", lambda default=80: 120)

    payload = _read_issuelist_text()

    # Simulate a bracketed paste (ESC[200~ ... ESC[201~) and then a final Enter.
    # NOTE: WindowsKeyEngine uses msvcrt.getwch(), so this is naturally char-by-char.
    seq = list("\x1b[200~") + list(payload) + list("\x1b[201~") + ["\r"]

    fake_msvcrt = _FakeMsvcrt(seq)
    engine = _build_engine(fake_msvcrt)

    counting = _CountingStdout()
    # IMPORTANT: patch the input_engine module's stdout, not the global sys.stdout
    # used by pytest's capture machinery.
    monkeypatch.setattr(ie.sys, "stdout", counting)

    t0 = time.perf_counter()
    result = engine.read_message("You: ", "")
    dt = time.perf_counter() - t0

    assert result == payload.strip()

    # Informational metrics: print in a single line for easy grepping.
    # Use the real stdout for reporting.
    sys.__stdout__.write(
        (
            "[paste-perf] windows bracketed paste: "
            f"payload_chars={len(payload)} "
            f"payload_lines={payload.count(chr(10)) + 1 if payload else 0} "
            f"duration_ms={dt * 1000.0:.2f} "
            f"stdout_write_calls={counting.write_calls} "
            f"stdout_chars_written={counting.chars_written}\n"
        )
    )
    sys.__stdout__.flush()


@pytest.mark.skipif(os.name != "nt", reason="Windows-only paste perf test")
def test_windows_bracketed_paste_markers_charwise(monkeypatch):
    """Bracketed paste markers arrive character-by-character under msvcrt.getwch().

    This verifies that marker parsing works under that condition.
    """

    _patch_signal(monkeypatch)
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda _txt: True)
    monkeypatch.setattr(ie, "_get_terminal_width", lambda default=80: 120)

    # Keep this as a fast functional test; large-payload performance is covered
    # by dedicated opt-in perf tests.
    payload = "line1\nline2\nline3"
    # Explicitly build markers as individual characters.
    start = ["\x1b", "[", "2", "0", "0", "~"]
    end = ["\x1b", "[", "2", "0", "1", "~"]
    seq = start + list(payload) + end + ["\r"]

    fake_msvcrt = _FakeMsvcrt(seq)
    engine = _build_engine(fake_msvcrt)

    counting = _CountingStdout()
    monkeypatch.setattr(ie.sys, "stdout", counting)

    result = engine.read_message("You: ", "")
    assert result == payload.strip()


@pytest.mark.skipif(os.name != "nt", reason="Windows-only paste perf test")
def test_windows_bracketed_paste_issuelist_md_chunked_stream_perf_regression(monkeypatch):
    """Regression test for large multiline paste under chunked terminal delivery.

    This adds realistic terminal pressure:
    - input arrives in small bursts (not one giant queue)
    - each stdout write incurs a tiny delay (render/transport proxy)
    """

    # Preserve sleep for latency modeling in this test.
    original_handler = object()
    state = {"handler": None}

    def _fake_getsignal(sig):
        assert sig == signal.SIGINT
        return original_handler

    def _fake_signal(sig, handler):
        assert sig == signal.SIGINT
        state["handler"] = handler
        return None

    monkeypatch.setattr(signal, "getsignal", _fake_getsignal)
    monkeypatch.setattr(signal, "signal", _fake_signal)
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda _txt: True)
    monkeypatch.setattr(ie, "_get_terminal_width", lambda default=80: 120)

    if os.environ.get("HENOSIS_RUN_TERMINAL_PERF", "0") != "1":
        pytest.skip("Set HENOSIS_RUN_TERMINAL_PERF=1 to run terminal perf regression test")

    payload = _read_issuelist_text()
    start_marker = "\x1b[200~"
    end_marker = "\x1b[201~"
    chunk_size = int(os.environ.get("HENOSIS_PASTE_CHUNK_SIZE", "64"))
    # Keep markers in dedicated bursts and chunk only payload bytes.
    # Some terminals can fragment control sequences, but that behavior is covered
    # by dedicated marker parsing tests; this test focuses on realistic throughput.
    bursts = [start_marker] + _chunk_text(payload, chunk_size) + [end_marker, "\r"]

    fake_msvcrt = _ChunkedFakeMsvcrt(bursts)
    engine = _build_engine(fake_msvcrt)

    per_write_delay = float(os.environ.get("HENOSIS_PASTE_WRITE_DELAY_SEC", "0.00015"))
    counting = _LatencyCountingStdout(per_write_delay_sec=per_write_delay)
    monkeypatch.setattr(ie.sys, "stdout", counting)

    t0 = time.perf_counter()
    result = engine.read_message("You: ", "")
    dt_ms = (time.perf_counter() - t0) * 1000.0

    assert result == payload.strip()

    max_write_calls = int(os.environ.get("HENOSIS_PASTE_MAX_WRITE_CALLS", "450"))
    max_duration_ms = float(os.environ.get("HENOSIS_PASTE_MAX_MS", "2500"))
    assert counting.write_calls <= max_write_calls
    assert dt_ms <= max_duration_ms

    sys.__stdout__.write(
        (
            "[paste-perf] windows chunked bracketed paste: "
            f"payload_chars={len(payload)} "
            f"chunk_size={chunk_size} "
            f"per_write_delay_sec={per_write_delay:.6f} "
            f"duration_ms={dt_ms:.2f} "
            f"stdout_write_calls={counting.write_calls} "
            f"stdout_chars_written={counting.chars_written}\n"
        )
    )
    sys.__stdout__.flush()


@pytest.mark.skipif(os.name != "nt", reason="Windows-only paste perf test")
def test_windows_bracketed_paste_issuelist_md_wall_time_stream_perf_regression(monkeypatch):
    """Regression test that simulates paste delivery on a wall-clock schedule.

    Unlike the chunked-stream test above, chunk availability is released over
    elapsed time. This makes the total runtime include both render overhead and
    the actual paste cadence a terminal would impose.
    """

    original_handler = object()
    state = {"handler": None}

    def _fake_getsignal(sig):
        assert sig == signal.SIGINT
        return original_handler

    def _fake_signal(sig, handler):
        assert sig == signal.SIGINT
        state["handler"] = handler
        return None

    monkeypatch.setattr(signal, "getsignal", _fake_getsignal)
    monkeypatch.setattr(signal, "signal", _fake_signal)
    monkeypatch.setattr(ie, "_copy_to_clipboard", lambda _txt: True)
    monkeypatch.setattr(ie, "_get_terminal_width", lambda default=80: 120)

    if os.environ.get("HENOSIS_RUN_TERMINAL_PERF", "0") != "1":
        pytest.skip("Set HENOSIS_RUN_TERMINAL_PERF=1 to run terminal perf regression test")

    payload = _read_issuelist_text()
    start_marker = "\x1b[200~"
    end_marker = "\x1b[201~"
    chunk_size = int(os.environ.get("HENOSIS_PASTE_WALL_CHUNK_SIZE", os.environ.get("HENOSIS_PASTE_CHUNK_SIZE", "64")))
    inter_burst_delay = float(os.environ.get("HENOSIS_PASTE_BURST_INTERVAL_SEC", "0.004"))
    bursts = [start_marker] + _chunk_text(payload, chunk_size) + [end_marker, "\r"]

    start_time = time.perf_counter() + 0.002
    fake_msvcrt = _TimedChunkedFakeMsvcrt(
        bursts,
        start_time=start_time,
        inter_burst_delay_sec=inter_burst_delay,
    )
    engine = _build_engine(fake_msvcrt)

    per_write_delay = float(os.environ.get("HENOSIS_PASTE_WRITE_DELAY_SEC", "0.00015"))
    counting = _LatencyCountingStdout(per_write_delay_sec=per_write_delay)
    monkeypatch.setattr(ie.sys, "stdout", counting)

    expected_paste_ms = max(0.0, (len(bursts) - 1) * inter_burst_delay * 1000.0)
    t0 = time.perf_counter()
    result = engine.read_message("You: ", "")
    dt_ms = (time.perf_counter() - t0) * 1000.0

    assert result == payload.strip()

    max_write_calls = int(os.environ.get("HENOSIS_PASTE_MAX_WRITE_CALLS", "450"))
    max_overhead_ms = float(os.environ.get("HENOSIS_PASTE_WALL_MAX_OVERHEAD_MS", "1200"))
    assert counting.write_calls <= max_write_calls
    assert dt_ms <= expected_paste_ms + max_overhead_ms

    sys.__stdout__.write(
        (
            "[paste-perf] windows wall-time bracketed paste: "
            f"payload_chars={len(payload)} "
            f"chunk_size={chunk_size} "
            f"inter_burst_delay_sec={inter_burst_delay:.6f} "
            f"expected_paste_ms={expected_paste_ms:.2f} "
            f"per_write_delay_sec={per_write_delay:.6f} "
            f"duration_ms={dt_ms:.2f} "
            f"stdout_write_calls={counting.write_calls} "
            f"stdout_chars_written={counting.chars_written}\n"
        )
    )
    sys.__stdout__.flush()
