from app.routers import chat as chat_router


def test_wait_process_timeout_uses_requested_timeout_plus_buffer():
    wait_sec = chat_router._client_tool_wait_timeout_sec(
        "wait_process",
        {"process_id": "proc_123", "timeout": 45},
    )
    assert wait_sec >= 60


def test_wait_process_timeout_defaults_to_base_for_other_tools():
    wait_sec = chat_router._client_tool_wait_timeout_sec(
        "process_status",
        {"process_id": "proc_123"},
    )
    assert wait_sec == int(getattr(chat_router.settings, "TOOLS_CALLBACK_TIMEOUT_SEC", 180) or 180)
