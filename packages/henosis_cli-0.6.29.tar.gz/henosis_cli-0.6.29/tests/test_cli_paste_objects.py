import importlib


def _make_cli():
    cli_mod = importlib.import_module("cli")
    return cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model="gpt-5.4",
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )


def _long_paste() -> str:
    return "\n".join(
        [
            "line one",
            "line two",
            "line three",
            "line four",
            "line five",
            "line six",
            "line seven",
        ]
    )


def test_short_paste_stays_inline_below_threshold_even_with_trailing_newline():
    cli = _make_cli()
    state = cli._new_input_paste_state()
    short_paste = "\n".join(["one", "two", "three", "four", "five", "six"]) + "\n"

    transformed = cli._input_paste_transform(state, short_paste)

    assert cli._input_paste_line_count(short_paste) == 6
    assert transformed == short_paste
    assert state == {"counter": 0, "items": {}}


def test_large_paste_becomes_placeholder_and_expands_on_submit():
    cli = _make_cli()
    paste = _long_paste()

    placeholder = cli._input_paste_transform(cli._chat_input_paste_state, paste)
    rendered = cli._rewrite_submitted_input_text(f"before {placeholder}", from_edit=False)
    expanded = cli._finalize_submitted_input(rendered, from_edit=False)

    assert placeholder == "[[paste:1]]"
    assert rendered == "before [[paste:1]]"
    assert expanded == f"before <paste-1>{paste}</paste-1>"
    assert cli._chat_input_paste_state == {"counter": 0, "items": {}}


def test_busy_prompt_paste_state_transfers_back_to_chat_and_expands():
    cli = _make_cli()
    paste = _long_paste()
    placeholder = cli._input_paste_transform(cli._busy_input_paste_state, paste)
    draft = f"queued {placeholder}"

    cli._transfer_busy_input_prefill_to_chat(draft)
    expanded = cli._finalize_submitted_input(cli._chat_input_prefill, from_edit=False)

    assert cli._chat_input_prefill == ""
    assert placeholder == "[[paste:1]]"
    assert expanded == f"queued <paste-1>{paste}</paste-1>"
    assert cli._busy_input_paste_state == {"counter": 0, "items": {}}
    assert cli._chat_input_paste_state == {"counter": 0, "items": {}}


def test_read_message_with_paste_objects_supports_legacy_engine_signature():
    cli = _make_cli()
    captured = {}

    class _LegacyEngine:
        def read_message(
            self,
            prompt_label: str = "\nYou: ",
            cont_label: str = "... ",
            stop_event=None,
            initial_text: str = "",
        ) -> str:
            captured["prompt_label"] = prompt_label
            captured["cont_label"] = cont_label
            captured["stop_event"] = stop_event
            captured["initial_text"] = initial_text
            return "typed"

    cli._input_engine = _LegacyEngine()

    result = cli._read_message_with_paste_objects("You: ", None, "prefill")

    assert result == "typed"
    assert captured == {
        "prompt_label": "You: ",
        "cont_label": "",
        "stop_event": None,
        "initial_text": "prefill",
    }
