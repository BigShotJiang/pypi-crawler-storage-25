import asyncio
import importlib


def make_cli():
    cli_mod = importlib.import_module("cli")
    return cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )


def test_browsertools_settings_round_trip():
    cli = make_cli()
    cli.browser_tools_enabled = True
    cli.browser_allowed_domains = ["example.com", "docs.openai.com"]

    data = cli._collect_settings_dict()
    assert data["browser_tools_enabled"] is True
    assert data["browser_allowed_domains"] == ["example.com", "docs.openai.com"]

    cli2 = make_cli()
    cli2._apply_settings_dict(data)
    assert cli2.browser_tools_enabled is True
    assert cli2.browser_allowed_domains == ["example.com", "docs.openai.com"]


def test_browsertools_command_updates_settings_without_touching_disk(monkeypatch):
    cli = make_cli()
    monkeypatch.setattr(cli, "save_settings", lambda: None)

    assert asyncio.run(cli.handle_command("/browsertools on")) is True
    assert cli.browser_tools_enabled is True

    assert asyncio.run(cli.handle_command("/browsertools domains example.com,docs.openai.com")) is True
    assert cli.browser_allowed_domains == ["example.com", "docs.openai.com"]

    assert asyncio.run(cli.handle_command("/browsertools domains clear")) is True
    assert cli.browser_allowed_domains == []


def test_cli_browser_approval_only_prompts_for_risky_actions(monkeypatch):
    cli = make_cli()
    calls = []

    def _prompt(label, args, policy=None):
        calls.append((label, args))
        return "once"

    cli._approval_prompt_ui = _prompt  # type: ignore[attr-defined]

    assert cli._cli_approval_for("browser_snapshot", {}, level=2) is True
    assert calls == []

    assert cli._cli_approval_for("browser_act", {"action": "click", "ref": "e1"}, level=2) is True
    assert calls and calls[0][0] == "browser_act"
