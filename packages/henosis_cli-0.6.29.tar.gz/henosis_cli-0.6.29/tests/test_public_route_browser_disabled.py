import sys
from pathlib import Path

from starlette.testclient import TestClient

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from app.main import app
from app.routers.chat_adapter import FREE_TIER_MODELS


def test_public_stream_forces_browser_tools_off(monkeypatch):
    import app.routers.chat as chat_router

    seen = {}

    async def _fake_chat_stream(req, body):
        seen["enable_browser_tools"] = body.enable_browser_tools
        seen["browser_allowed_domains"] = body.browser_allowed_domains
        seen["enable_tools"] = body.enable_tools
        seen["enable_web_search"] = body.enable_web_search

        async def _gen():
            yield b"event: message.completed\ndata: {\"model\":\"test\",\"usage\":{}}\n\n"

        from fastapi.responses import StreamingResponse

        return StreamingResponse(_gen(), media_type="text/event-stream")

    monkeypatch.setattr(chat_router, "chat_stream", _fake_chat_stream)

    client = TestClient(app)
    resp = client.post(
        "/api/public/chat/stream",
        json={
            "model": FREE_TIER_MODELS[0],
            "messages": [{"role": "user", "content": "hello"}],
            "enable_tools": True,
            "enable_web_search": True,
            "enable_browser_tools": True,
            "browser_allowed_domains": ["example.com"],
        },
    )

    assert resp.status_code == 200
    assert seen["enable_tools"] is False
    assert seen["enable_web_search"] is False
    assert seen["enable_browser_tools"] is False
    assert seen["browser_allowed_domains"] is None
