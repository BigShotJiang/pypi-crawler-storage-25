from __future__ import annotations

import importlib.util
from pathlib import Path


def _load_module():
    root = Path(__file__).resolve().parents[1]
    path = root / "scripts" / "compare_openai_billing.py"
    spec = importlib.util.spec_from_file_location("compare_openai_billing", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_aggregate_db_usage_rows_excludes_codex_local_and_normalizes_aliases():
    mod = _load_module()
    rows = [
        {
            "user_id": "alice",
            "model_id": "gpt-5-mini",
            "billing_source": "",
            "status": "success",
            "request_count": 2,
            "prompt_tokens": 100,
            "cached_input_tokens": 40,
            "non_cached_input_tokens": 60,
            "completion_tokens": 25,
            "cost_usd": 1.5,
        },
        {
            "user_id": "alice",
            "model_id": "gpt-5-mini",
            "billing_source": "codex_local",
            "status": "success",
            "request_count": 9,
            "prompt_tokens": 999,
            "cached_input_tokens": 0,
            "non_cached_input_tokens": 999,
            "completion_tokens": 999,
            "cost_usd": 9.9,
        },
        {
            "user_id": "bob",
            "model_id": "claude-sonnet-4-6",
            "billing_source": "",
            "status": "success",
            "request_count": 3,
            "prompt_tokens": 500,
            "cached_input_tokens": 0,
            "non_cached_input_tokens": 500,
            "completion_tokens": 50,
            "cost_usd": 2.0,
        },
    ]

    totals, by_model = mod.aggregate_db_usage_rows(rows)

    assert totals["request_count"] == 2
    assert totals["prompt_tokens"] == 100
    assert totals["cached_input_tokens"] == 40
    assert totals["completion_tokens"] == 25
    assert totals["cost_usd"] == 1.5
    assert totals["user_count"] == 1
    assert list(by_model.keys()) == ["gpt-5.4-mini-2026-03-17"]


def test_aggregate_openai_usage_buckets_sums_across_buckets_and_aliases():
    mod = _load_module()
    buckets = [
        {
            "results": [
                {
                    "model": "gpt-5.4-mini",
                    "num_model_requests": 2,
                    "input_tokens": 100,
                    "input_cached_tokens": 30,
                    "output_tokens": 20,
                }
            ]
        },
        {
            "results": [
                {
                    "model": "gpt-5.4-mini-2026-03-17",
                    "num_model_requests": 1,
                    "input_tokens": 40,
                    "input_cached_tokens": 10,
                    "output_tokens": 5,
                }
            ]
        },
    ]

    totals, by_model = mod.aggregate_openai_usage_buckets(buckets)

    assert totals["request_count"] == 3
    assert totals["input_tokens"] == 140
    assert totals["input_cached_tokens"] == 40
    assert totals["output_tokens"] == 25
    assert by_model["gpt-5.4-mini-2026-03-17"]["request_count"] == 3


def test_build_model_comparison_rows_computes_deltas():
    mod = _load_module()
    rows = mod.build_model_comparison_rows(
        {
            "gpt-5.4": {
                "request_count": 4,
                "prompt_tokens": 500,
                "cached_input_tokens": 120,
                "completion_tokens": 90,
                "cost_usd": 3.5,
                "user_count": 2,
            }
        },
        {
            "gpt-5.4": {
                "request_count": 5,
                "input_tokens": 550,
                "input_cached_tokens": 100,
                "output_tokens": 110,
            }
        },
    )

    assert len(rows) == 1
    row = rows[0]
    assert row["request_delta"] == -1
    assert row["input_delta"] == -50
    assert row["cached_delta"] == 20
    assert row["output_delta"] == -20


def test_candidate_db_urls_adds_host_side_postgres_fallbacks():
    mod = _load_module()
    urls = mod.candidate_db_urls("postgresql://user:pass@db:5432/concurrent_db")

    assert urls[0] == "postgresql://user:pass@db:5432/concurrent_db"
    assert "postgresql://user:pass@localhost:5450/concurrent_db" in urls
    assert "postgresql://user:pass@127.0.0.1:5450/concurrent_db" in urls
