import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import pytest
from starlette.testclient import TestClient

_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from app.main import app
from app.settings import settings


class DummyOpenAI:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key


class FakeWSConn:
    def __init__(self, module: "FakeWebsockets", events: List[Dict[str, Any]]):
        self._module = module
        self._events = list(events)
        self.sent: List[str] = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def send(self, msg: str) -> None:
        self.sent.append(msg)
        self._module.last_sent = msg

    async def recv(self) -> str:
        if not self._events:
            raise RuntimeError("fake ws exhausted")
        return json.dumps(self._events.pop(0))


class FakeWebsockets:
    def __init__(self, events: List[Dict[str, Any]]):
        self._events = events
        self.last_url: Optional[str] = None
        self.last_headers: Any = None
        self.last_sent: Optional[str] = None

    def connect(self, url: str, **kwargs: Any) -> FakeWSConn:
        self.last_url = url
        self.last_headers = kwargs.get("additional_headers", kwargs.get("extra_headers"))
        return FakeWSConn(self, self._events)


@pytest.fixture(autouse=True)
def _env(monkeypatch):
    monkeypatch.setattr(settings, "OPENAI_API_KEY", "sk-test")
    monkeypatch.setattr(settings, "DISABLE_V0_ROUTES", False)
    monkeypatch.setattr(settings, "OPENAI_RESPONSES_TRANSPORT", "websocket")
    monkeypatch.setattr(settings, "OPENAI_RESPONSES_WS_URL", "wss://example.test/v1/responses")
    monkeypatch.setattr(settings, "OPENAI_RESPONSES_WS_TIMEOUT_SEC", 10)
    yield


def test_openai_websocket_transport_uses_response_create(monkeypatch):
    import app.routers.chat as chat_router

    try:
        app.include_router(chat_router.router, prefix="/v0")
    except Exception:
        pass

    monkeypatch.setattr(chat_router, "OpenAI", DummyOpenAI)
    fake_ws = FakeWebsockets(
        [
            {"type": "response.output_text.delta", "delta": "hello ws"},
            {
                "type": "response.completed",
                "response": {
                    "id": "resp_ws_1",
                    "output_text": "hello ws",
                    "output": [
                        {
                            "type": "message",
                            "role": "assistant",
                            "content": [{"type": "output_text", "text": "hello ws"}],
                        }
                    ],
                    "usage": {"input_tokens": 11, "output_tokens": 7, "total_tokens": 18},
                },
            },
        ]
    )
    monkeypatch.setattr(chat_router, "websockets", fake_ws)

    client = TestClient(app)
    payload = {
        "model": "gpt-5",
        "messages": [{"role": "user", "content": "Say hello"}],
        "enable_tools": False,
        "background": True,
    }
    resp = client.post("/v0/chat/stream", json=payload)
    assert resp.status_code == 200

    sent = json.loads(str(fake_ws.last_sent or "{}"))
    assert sent.get("type") == "response.create"
    assert "background" not in sent
    assert fake_ws.last_url == "wss://example.test/v1/responses"

    assert "event: message.delta" in resp.text
    assert "event: message.completed" in resp.text
