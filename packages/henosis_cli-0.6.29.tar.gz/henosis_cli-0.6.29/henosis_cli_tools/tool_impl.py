# tool_impl.py
from __future__ import annotations
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import tempfile
import time
import logging
import sys
import threading
import uuid
import errno
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
import difflib
import math

# ----------------------------- Defaults -----------------------------#
# Reasonable default extension allowlist (lower-case)
_DEFAULT_ALLOWED_EXTS = {
    ".txt",
    ".md",
    ".json",
    ".jsonc",
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
    ".cfg",
    ".env",
    ".xml",
    ".html",
    ".css",
    ".scss",
    ".less",
    ".js",
    ".mjs",
    ".cjs",
    ".ts",
    ".tsx",
    ".jsx",
    ".py",
    ".ipynb",
    ".rb",
    ".go",
    ".rs",
    ".java",
    ".kt",
    ".scala",
    ".c",
    ".cc",
    ".cpp",
    ".h",
    ".hpp",
    ".cs",
    ".php",
    ".sh",
    ".bash",
    ".zsh",
    ".ps1",
    ".sql",
    ".graphql",
    ".proto",
    ".dockerignore",
    ".gitignore",
    ".make",
    ".mk",
    ".cmake",
    ".gradle",
    ".sbt",
    ".nuspec",
    ".conf",
}

_MAX_FILE_BYTES = int(os.getenv("HENOSIS_MAX_FILE_BYTES", str(1_073_741_824)))
_MAX_EDIT_BYTES = int(os.getenv("HENOSIS_MAX_EDIT_BYTES", str(1_073_741_824)))
_EDIT_SAFEGUARD_MAX_LINES = int(os.getenv("HENOSIS_EDIT_SAFEGUARD_MAX_LINES", "3000"))

# Command timeout behavior:
# - The tool call can request a per-invocation timeout via the `timeout` argument.
# - The client/user may configure a DEFAULT (used when the tool omits timeout)
#   and a MAX (hard cap for safety).
# - Backward compatibility: legacy env var HENOSIS_COMMAND_TIMEOUT_SEC is treated as MAX.
def _env_float(name: str, default: float) -> float:
    try:
        v = os.getenv(name, "")
        if v is None:
            return float(default)
        s = str(v).strip()
        if not s:
            return float(default)
        return float(s)
    except Exception:
        return float(default)


_COMMAND_TIMEOUT_DEFAULT_SEC = _env_float("HENOSIS_COMMAND_TIMEOUT_DEFAULT_SEC", 360.0)
_LEGACY_COMMAND_TIMEOUT_SEC_RAW = os.getenv("HENOSIS_COMMAND_TIMEOUT_SEC", "")
if str(_LEGACY_COMMAND_TIMEOUT_SEC_RAW or "").strip():
    _COMMAND_TIMEOUT_MAX_SEC = _env_float("HENOSIS_COMMAND_TIMEOUT_SEC", 900.0)
else:
    _COMMAND_TIMEOUT_MAX_SEC = _env_float("HENOSIS_COMMAND_TIMEOUT_MAX_SEC", 900.0)

# Max chars for stdout/stderr before truncation notice is applied.
# Configurable via env var HENOSIS_CMD_OUTPUT_MAX_CHARS.
def _env_int(name: str, default: int) -> int:
    try:
        v = os.getenv(name, "")
        if v is None:
            return int(default)
        s = str(v).strip()
        if not s:
            return int(default)
        return int(s)
    except Exception:
        return int(default)


_CMD_OUTPUT_MAX_CHARS = _env_int("HENOSIS_CMD_OUTPUT_MAX_CHARS", 250_000)
_APPLY_PATCH_DRY_RUN_MAX_DIFF_CHARS_PER_FILE = _env_int("HENOSIS_APPLY_PATCH_DRY_RUN_MAX_DIFF_CHARS_PER_FILE", 100_000)
_APPLY_PATCH_DRY_RUN_MAX_DIFF_CHARS_TOTAL = _env_int("HENOSIS_APPLY_PATCH_DRY_RUN_MAX_DIFF_CHARS_TOTAL", 500_000)
_MANAGED_PROCESS_OUTPUT_MAX_CHARS = _env_int("HENOSIS_MANAGED_PROCESS_OUTPUT_MAX_CHARS", 250_000)
_MANAGED_PROCESS_MAX_CHUNKS = _env_int("HENOSIS_MANAGED_PROCESS_MAX_CHUNKS", 2000)
_MANAGED_PROCESS_MAX_ITEMS = _env_int("HENOSIS_MANAGED_PROCESS_MAX_ITEMS", 128)
_MANAGED_PROCESS_LIST_LIMIT = _env_int("HENOSIS_MANAGED_PROCESS_LIST_LIMIT", 200)
_MANAGED_TERMINAL_OUTPUT_MAX_CHARS = _env_int("HENOSIS_MANAGED_TERMINAL_OUTPUT_MAX_CHARS", 250_000)
_MANAGED_TERMINAL_MAX_CHUNKS = _env_int("HENOSIS_MANAGED_TERMINAL_MAX_CHUNKS", 4000)
_MANAGED_TERMINAL_MAX_ITEMS = _env_int("HENOSIS_MANAGED_TERMINAL_MAX_ITEMS", 64)
_MANAGED_TERMINAL_LIST_LIMIT = _env_int("HENOSIS_MANAGED_TERMINAL_LIST_LIMIT", 100)
_MANAGED_TERMINAL_DEFAULT_COLS = _env_int("HENOSIS_MANAGED_TERMINAL_DEFAULT_COLS", 120)
_MANAGED_TERMINAL_DEFAULT_ROWS = _env_int("HENOSIS_MANAGED_TERMINAL_DEFAULT_ROWS", 40)


def _verbose_notice(limit: int) -> str:
    # Keep the original wording/typos; only the limit value is dynamic.
    return (
        "console output was EXTEREMELY verbose the ouput was truncated as to not overflow your context. "
        f"here are the last {int(limit)} chars:\n"
    )

_logger = logging.getLogger("henosis_cli_tools.tool_impl")


def _normalize_and_strip_wrapping_quotes(s: Any) -> Any:
    """Best-effort normalization for common quoting mistakes on tool inputs.

    Context: users (and models) often include *literal* wrapping quotes around
    path-like arguments or command strings, e.g. '"src/app.py"' or '"rg -n x"'.
    We strip a single wrapper layer while preserving meaningful inner quotes.

    Smart quotes are normalized first. Wrappers are only stripped when the
    string starts and ends with the same quote char and the inner content does
    not contain that quote char.
    """
    try:
        if s is None:
            return ""
        s2 = str(s)
    except Exception:
        return s

    # Normalize “smart quotes” to ASCII quotes.
    trans = {
        "\u201c": '"',
        "\u201d": '"',
        "\u2018": "'",
        "\u2019": "'",
    }
    try:
        if any(ch in s2 for ch in trans):
            s2 = "".join(trans.get(ch, ch) for ch in s2)
    except Exception:
        pass

    if len(s2) >= 2 and s2[0] == s2[-1] and s2[0] in ('"', "'"):
        q = s2[0]
        inner = s2[1:-1]
        # Only strip when it looks like a simple wrapper, not when quotes are meaningful.
        if q not in inner:
            return inner
    return s2


def _windows_normalize_and_strip_wrapping_quotes(s: str) -> str:
    return str(_normalize_and_strip_wrapping_quotes(s))


def _windows_sanitize_argv(parts: List[str]) -> Tuple[List[str], bool]:
    """Sanitize argv on Windows to avoid passing literal quote chars to tools.

    Returns (new_parts, changed).
    """
    if os.name != "nt":
        return parts, False
    changed = False
    out: List[str] = []
    for p in parts:
        p2 = _windows_normalize_and_strip_wrapping_quotes(p)
        if p2 != p:
            changed = True
        out.append(p2)
    return out, changed

def _windows_commandline_to_argv(cmdline: str) -> Optional[List[str]]:
    """Parse a Windows command line string using CommandLineToArgvW semantics.

    This matches the native Windows splitting rules better than shlex on Windows.
    Returns None on non-Windows or on failure.
    """
    if os.name != "nt":
        return None
    s = (cmdline or "").strip()
    if not s:
        return []
    try:
        import ctypes
        from ctypes import wintypes

        # IMPORTANT: declare argtypes/restype.
        # Without this, ctypes may treat the return value as a 32-bit int on 64-bit
        # Python, leading to pointer truncation and access violations.
        cmdline_to_argvw = ctypes.windll.shell32.CommandLineToArgvW
        cmdline_to_argvw.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_int)]
        cmdline_to_argvw.restype = ctypes.POINTER(wintypes.LPWSTR)

        local_free = ctypes.windll.kernel32.LocalFree
        local_free.argtypes = [wintypes.HLOCAL]
        local_free.restype = wintypes.HLOCAL

        argc = ctypes.c_int(0)
        argv_p = cmdline_to_argvw(wintypes.LPCWSTR(s), ctypes.byref(argc))
        if not argv_p:
            return None
        try:
            out = [argv_p[i] for i in range(int(argc.value))]
        finally:
            try:
                local_free(ctypes.cast(argv_p, wintypes.HLOCAL))
            except Exception:
                pass
        return out
    except Exception:
        return None


def _normalize_allowed_exe_names(exe: str) -> List[str]:
    """Return a small set of candidate names for allowlist checks.

    On Windows, callers may use python vs python.exe, rg vs rg.exe, etc.
    We accept both the basename and the basename-without-extension for common
    executable suffixes.
    """
    try:
        base = os.path.basename(exe or "").lower()
    except Exception:
        base = str(exe or "").lower()
    names = [base]
    if os.name == "nt":
        try:
            stem, ext = os.path.splitext(base)
            if ext.lower() in {".exe", ".cmd", ".bat", ".com"} and stem:
                names.append(stem)
        except Exception:
            pass
    # De-dup while preserving order
    seen: Set[str] = set()
    out: List[str] = []
    for n in names:
        if n and n not in seen:
            seen.add(n)
            out.append(n)
    return out


def _resolve_cwd_for_command(cwd: Optional[str], policy: FileToolPolicy) -> Tuple[Optional[Path], Optional[str]]:
    """Resolve and validate cwd for command tools.

    Returns (cwd_path, error_message). If error_message is not None, caller should
    return {ok: False, error: error_message}.

    Mirrors the logic currently used by run_command.
    """
    cwd_arg = str(_normalize_and_strip_wrapping_quotes(cwd or "."))
    try:
        cwd_path = resolve_path(cwd_arg, policy)
    except Exception as e:
        return None, f"resolve_path failed for cwd: {type(e).__name__}: {e}"

    # Host scope special-case: '.' means process cwd, not the host_base.
    if cwd_arg in ("", ".") and policy.scope == "host":
        cwd_path = Path.cwd()

    if cwd_path.exists() and cwd_path.is_file():
        cwd_path = cwd_path.parent
    if str(cwd_arg or "").strip() and not cwd_path.exists():
        return None, "cwd does not exist"
    if not cwd_path.is_dir():
        return None, "cwd is not a directory"
    return cwd_path, None


def _vendor_bin_dir() -> Optional[Path]:
    """Return the directory containing vendored helper binaries (if present).

    We ship small helper binaries (currently ripgrep) inside wheels so the CLI can
    rely on them even when they aren't installed on the host PATH.
    """
    try:
        d = Path(__file__).resolve().parent / "_vendor"
        if d.exists() and d.is_dir():
            return d
    except Exception:
        return None
    return None


def _prepend_path(env: Dict[str, str], prefix_dir: Path) -> Dict[str, str]:
    """Return a copy of env with PATH prefixed by prefix_dir."""
    try:
        out = dict(env)
        key = "PATH"
        cur = out.get(key, "") or ""
        out[key] = str(prefix_dir) + os.pathsep + cur if cur else str(prefix_dir)
        return out
    except Exception:
        return env


def _node_bin_dirs_for_cwd(cwd_path: Path) -> List[Path]:
    """Return node_modules/.bin directories from cwd up to filesystem root."""
    out: List[Path] = []
    seen: Set[Path] = set()
    cur = cwd_path
    try:
        while True:
            cand = cur / "node_modules" / ".bin"
            try:
                rcand = cand.resolve()
            except Exception:
                rcand = cand
            if rcand.exists() and rcand.is_dir() and rcand not in seen:
                seen.add(rcand)
                out.append(rcand)
            parent = cur.parent
            if parent == cur:
                break
            cur = parent
    except Exception:
        pass
    return out


def _resolve_windows_cmd_shim(exe: str, env: Dict[str, str]) -> Optional[str]:
    """Resolve common Windows command shims like npm.cmd when shell=False."""
    if os.name != "nt":
        return None
    try:
        base = os.path.basename(str(exe or "")).lower()
    except Exception:
        base = str(exe or "").lower()
    if base not in {"npm", "npx", "pnpm", "node"}:
        return None
    search_path = env.get("PATH") or os.environ.get("PATH") or ""
    try:
        resolved = shutil.which(str(exe), path=search_path)
    except Exception:
        resolved = None
    if resolved:
        return resolved
    stem, ext = os.path.splitext(str(exe))
    cand_names: List[str] = []
    if ext:
        cand_names.append(str(exe))
    else:
        cand_names.extend([f"{exe}.cmd", f"{exe}.exe", f"{exe}.bat"])
    for cand_name in cand_names:
        try:
            resolved = shutil.which(cand_name, path=search_path)
        except Exception:
            resolved = None
        if resolved:
            return resolved
    return None

def _parse_allowed_roots(raw: str | None) -> List[Path]:
    roots: List[Path] = []
    if not raw:
        return roots
    for token in raw.split(","):
        s = token.strip()
        if not s:
            continue
        p = Path(s).expanduser().resolve()
        roots.append(p)
    return roots

@dataclass
class FileToolPolicy:
    """Scope and constraints for local file and process operations.
    scope: "workspace" or "host"
    workspace_base: base directory for workspace scope (created if missing)
    host_base: optional base for host scope (must be absolute)
    allowed_roots: optional list of absolute Path roots for host scope
    allowed_exts: lower-case extension allowlist (use empty set to disable)
    max_bytes: max bytes for single read/write
    """
    scope: str = "workspace"
    workspace_base: Path = Path(os.getenv("HENOSIS_WORKSPACE_DIR", "./workspace")).expanduser().resolve()
    host_base: Optional[Path] = None
    allowed_roots: Optional[List[Path]] = None
    allowed_exts: Set[str] = frozenset(
        {e.strip().lower() for e in os.getenv("HENOSIS_ALLOW_EXTENSIONS", "").split(",") if e.strip()} or _DEFAULT_ALLOWED_EXTS
    )
    max_bytes: int = _MAX_FILE_BYTES

    def __post_init__(self) -> None:
        # Ensure workspace dir exists
        try:
            self.workspace_base.mkdir(parents=True, exist_ok=True)
            (self.workspace_base / ".locks").mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

    def all_host_roots(self) -> List[Path]:
        roots = list(self.allowed_roots or [])
        if self.host_base:
            roots.append(self.host_base)
        return roots

def resolve_path(path_input: str, policy: FileToolPolicy) -> Path:
    path_input = str(_normalize_and_strip_wrapping_quotes(path_input or "")).strip()
    is_empty = (path_input == "" or path_input == ".")
    if policy.scope == "workspace":
        if is_empty:
            full = policy.workspace_base
        else:
            p = Path(path_input)
            if p.is_absolute():
                raise ValueError("absolute paths are not allowed in workspace scope")
            full = (policy.workspace_base / p).resolve()
        try:
            full.relative_to(policy.workspace_base)
        except Exception:
            raise ValueError("path escapes workspace")
        return full
    # host scope
    roots = policy.all_host_roots()
    if not roots:
        roots = [Path.cwd().resolve()]
    if is_empty:
        base = policy.host_base or roots[0]
        full = base
    else:
        p = Path(path_input).expanduser()
        full = p.resolve() if p.is_absolute() else (policy.host_base or roots[0]).joinpath(p).resolve()
    for r in roots:
        try:
            full.relative_to(r)
            break
        except Exception:
            continue
    else:
        raise ValueError("path is not under any allowed host root")
    return full

# ------------------------- Encoding helpers -------------------------#
def read_text_auto(p: Path) -> str:
    data = p.read_bytes()
    if data.startswith(b"\xef\xbb\xbf"):
        return data[3:].decode("utf-8", errors="replace")
    if data.startswith(b"\xff\xfe\x00\x00") or data.startswith(b"\x00\x00\xfe\xff"):
        return data.decode("utf-32", errors="replace")
    if data.startswith(b"\xff\xfe"):
        return data.decode("utf-16-le", errors="replace")
    if data.startswith(b"\xfe\xff"):
        return data.decode("utf-16-be", errors="replace")
    sample = data[:4096]
    if sample:
        nul_ratio = sample.count(b"\x00") / max(1, len(sample))
        if nul_ratio > 0.20:
            even_nuls = sum(1 for i in range(0, len(sample), 2) if sample[i] == 0)
            odd_nuls = sum(1 for i in range(1, len(sample), 2) if sample[i] == 0)
            if odd_nuls >= even_nuls:
                try:
                    return data.decode("utf-16-le", errors="replace")
                except Exception:
                    pass
            else:
                try:
                    return data.decode("utf-16-be", errors="replace")
                except Exception:
                    pass
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("utf-8", errors="replace")

def _ensure_size_limit_bytes(content: str, max_bytes: int) -> None:
    b = len(content.encode("utf-8", errors="replace"))
    if b > max_bytes:
        raise ValueError(f"content exceeds {max_bytes} bytes")

def _file_size_ok(p: Path, max_bytes: int) -> None:
    try:
        size = p.stat().st_size
    except FileNotFoundError:
        return
    if size > max_bytes:
        raise ValueError(f"file too large (> {max_bytes} bytes)")


def _truncate_if_verbose(text: str, limit: int = _CMD_OUTPUT_MAX_CHARS) -> str:
    """Return text unchanged if within limit; otherwise prepend notice and keep last `limit` chars.

    The notice text is intentionally spelled exactly as requested by the user.
    """
    if text is None:
        return ""
    try:
        s = str(text)
    except Exception:
        s = ""
    if len(s) <= limit:
        return s
    tail = s[-limit:]
    return _verbose_notice(limit) + tail


def _utc_now_iso() -> str:
    try:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    except Exception:
        return ""


@dataclass
class ManagedProcessChunk:
    seq: int
    stream: str
    text: str
    timestamp: str


@dataclass
class ManagedProcessRecord:
    process_id: str
    cmd: str
    argv: List[str]
    parse_method: str
    argv_sanitized: bool
    cwd: str
    pid: int
    started_at: str
    status: str
    stdout_chars: int = 0
    stderr_chars: int = 0
    output_chars: int = 0
    chunk_seq: int = 0
    last_output_seq: int = 0
    last_output_at: Optional[str] = None
    finished_at: Optional[str] = None
    exit_code: Optional[int] = None
    error: Optional[str] = None
    chunks: deque = field(default_factory=lambda: deque())
    proc: Any = None
    output_lock: Any = field(default_factory=threading.Lock)
    wait_cond: Any = field(default_factory=threading.Condition)

    def metadata(self) -> Dict[str, Any]:
        return {
            "process_id": self.process_id,
            "cmd": self.cmd,
            "argv": list(self.argv),
            "parse_method": self.parse_method,
            "argv_sanitized": bool(self.argv_sanitized),
            "cwd": self.cwd,
            "pid": int(self.pid),
            "status": self.status,
            "started_at": self.started_at,
            "last_output_at": self.last_output_at,
            "finished_at": self.finished_at,
            "exit_code": self.exit_code,
            "error": self.error,
            "stdout_chars": int(self.stdout_chars),
            "stderr_chars": int(self.stderr_chars),
            "output_chars": int(self.output_chars),
            "last_output_seq": int(self.last_output_seq),
        }


_MANAGED_PROCESSES: Dict[str, ManagedProcessRecord] = {}
_MANAGED_PROCESSES_LOCK = threading.Lock()


@dataclass
class ManagedTerminalRecord:
    terminal_id: str
    cmd: str
    argv: List[str]
    parse_method: str
    argv_sanitized: bool
    cwd: str
    pid: int
    started_at: str
    status: str
    cols: int
    rows: int
    stdout_chars: int = 0
    stderr_chars: int = 0
    output_chars: int = 0
    chunk_seq: int = 0
    last_output_seq: int = 0
    last_output_at: Optional[str] = None
    finished_at: Optional[str] = None
    exit_code: Optional[int] = None
    error: Optional[str] = None
    chunks: deque = field(default_factory=lambda: deque())
    proc: Any = None
    master_fd: Optional[int] = None
    output_lock: Any = field(default_factory=threading.Lock)
    wait_cond: Any = field(default_factory=threading.Condition)
    close_requested: bool = False

    def metadata(self) -> Dict[str, Any]:
        return {
            "terminal_id": self.terminal_id,
            "cmd": self.cmd,
            "argv": list(self.argv),
            "parse_method": self.parse_method,
            "argv_sanitized": bool(self.argv_sanitized),
            "cwd": self.cwd,
            "pid": int(self.pid),
            "status": self.status,
            "started_at": self.started_at,
            "last_output_at": self.last_output_at,
            "finished_at": self.finished_at,
            "exit_code": self.exit_code,
            "error": self.error,
            "stdout_chars": int(self.stdout_chars),
            "stderr_chars": int(self.stderr_chars),
            "output_chars": int(self.output_chars),
            "last_output_seq": int(self.last_output_seq),
            "cols": int(self.cols),
            "rows": int(self.rows),
        }


_MANAGED_TERMINALS: Dict[str, ManagedTerminalRecord] = {}
_MANAGED_TERMINALS_LOCK = threading.Lock()


def _managed_terminal_close_requested(record: ManagedTerminalRecord) -> bool:
    try:
        return bool(getattr(record, "close_requested", False))
    except Exception:
        return False


def _managed_terminal_expected_close_error_text(err: Any) -> bool:
    try:
        msg = str(err or "").strip().lower()
    except Exception:
        msg = ""
    if not msg:
        return False
    if "10053" in msg:
        return True
    if "connectionabortederror" in msg:
        return True
    if ("connection" in msg) and ("aborted" in msg):
        return True
    if "broken pipe" in msg:
        return True
    if "eoferror" in msg:
        return True
    if ("closed" in msg) or ("ended" in msg):
        return True
    return False


def _managed_terminal_should_suppress_reader_error(record: ManagedTerminalRecord, exc: Exception) -> bool:
    if not _managed_terminal_close_requested(record):
        return False
    if isinstance(exc, (EOFError, BrokenPipeError, ConnectionAbortedError)):
        return True
    return _managed_terminal_expected_close_error_text(exc)


def _managed_terminal_maybe_clear_expected_close_error(record: ManagedTerminalRecord) -> None:
    try:
        err = getattr(record, "error", None)
    except Exception:
        err = None
    if _managed_terminal_close_requested(record) and _managed_terminal_expected_close_error_text(err):
        try:
            record.error = None
        except Exception:
            pass


def _managed_terminal_final_status(
    record: ManagedTerminalRecord,
    code: Optional[int],
    *,
    terminated: bool = False,
    killed: bool = False,
) -> str:
    if bool(killed):
        return "killed"
    if bool(terminated) or _managed_terminal_close_requested(record):
        if isinstance(code, int) and int(code) == 0:
            return "exited"
        return "killed"
    if code is None:
        return "failed" if getattr(record, "error", None) else "unknown"
    return "exited" if int(code) == 0 else "failed"


def _managed_process_status(proc: Any) -> str:
    try:
        if proc is None:
            return "failed"
        code = proc.poll()
        if code is None:
            return "running"
        return "exited" if int(code) == 0 else "failed"
    except Exception:
        return "unknown"


def _managed_process_append_chunk(record: ManagedProcessRecord, stream_name: str, text: str) -> None:
    if not isinstance(text, str) or not text:
        return
    stream_key = "stderr" if str(stream_name).strip().lower() == "stderr" else "stdout"
    timestamp = _utc_now_iso()
    with record.output_lock:
        record.chunk_seq += 1
        chunk = ManagedProcessChunk(
            seq=int(record.chunk_seq),
            stream=stream_key,
            text=text,
            timestamp=timestamp,
        )
        record.chunks.append(chunk)
        max_chunks = max(10, int(_MANAGED_PROCESS_MAX_CHUNKS))
        while len(record.chunks) > max_chunks:
            old = record.chunks.popleft()
            try:
                old_len = len(old.text)
            except Exception:
                old_len = 0
            record.output_chars = max(0, int(record.output_chars) - int(old_len))
            if old.stream == "stderr":
                record.stderr_chars = max(0, int(record.stderr_chars) - int(old_len))
            else:
                record.stdout_chars = max(0, int(record.stdout_chars) - int(old_len))
        max_chars = max(1024, int(_MANAGED_PROCESS_OUTPUT_MAX_CHARS))
        while record.output_chars > max_chars and record.chunks:
            old = record.chunks.popleft()
            try:
                old_len = len(old.text)
            except Exception:
                old_len = 0
            record.output_chars = max(0, int(record.output_chars) - int(old_len))
            if old.stream == "stderr":
                record.stderr_chars = max(0, int(record.stderr_chars) - int(old_len))
            else:
                record.stdout_chars = max(0, int(record.stdout_chars) - int(old_len))
        text_len = len(text)
        record.output_chars += int(text_len)
        if stream_key == "stderr":
            record.stderr_chars += int(text_len)
        else:
            record.stdout_chars += int(text_len)
        record.last_output_seq = int(chunk.seq)
        record.last_output_at = timestamp
    with record.wait_cond:
        record.wait_cond.notify_all()


def _managed_process_reader(record: ManagedProcessRecord, stream_name: str, pipe: Any) -> None:
    try:
        carry: List[str] = []
        while True:
            chunk = pipe.read(1)
            if chunk in (None, ""):
                break
            if not isinstance(chunk, str):
                try:
                    chunk = str(chunk)
                except Exception:
                    chunk = ""
            if chunk:
                carry.append(chunk)
                if chunk == "\n" or len(carry) >= 256:
                    _managed_process_append_chunk(record, stream_name, "".join(carry))
                    carry = []
        if carry:
            _managed_process_append_chunk(record, stream_name, "".join(carry))
    except Exception as e:
        with record.output_lock:
            if not record.error:
                record.error = f"{stream_name} reader error: {type(e).__name__}: {e}"
    finally:
        try:
            if pipe is not None:
                pipe.close()
        except Exception:
            pass
        with record.wait_cond:
            record.wait_cond.notify_all()


def _managed_process_monitor(record: ManagedProcessRecord) -> None:
    try:
        proc = record.proc
        code = proc.wait() if proc is not None else None
    except Exception as e:
        code = None
        with record.output_lock:
            if not record.error:
                record.error = f"monitor error: {type(e).__name__}: {e}"
    finally:
        with record.output_lock:
            record.exit_code = (int(code) if isinstance(code, int) else None)
            if code is None:
                record.status = "failed" if record.error else "unknown"
            else:
                record.status = "exited" if int(code) == 0 else "failed"
            record.finished_at = _utc_now_iso()
        with record.wait_cond:
            record.wait_cond.notify_all()


def _managed_process_compact_error(err: Any) -> str:
    try:
        return _clip_text_for_process(str(err or "unknown error"), 400)
    except Exception:
        return "unknown error"


def _clip_text_for_process(text: Any, limit: int) -> str:
    try:
        s = str(text or "")
    except Exception:
        s = ""
    if len(s) <= int(limit):
        return s
    if int(limit) <= 16:
        return s[: int(limit)]
    keep = int(limit) - len("... (truncated) ...")
    if keep <= 0:
        return s[: int(limit)]
    head = max(1, keep // 2)
    tail = max(1, keep - head)
    return s[:head] + "... (truncated) ..." + s[-tail:]


def _managed_process_evict_if_needed() -> None:
    max_items = max(4, int(_MANAGED_PROCESS_MAX_ITEMS))
    with _MANAGED_PROCESSES_LOCK:
        if len(_MANAGED_PROCESSES) < max_items:
            return
        candidates = list(_MANAGED_PROCESSES.values())
        candidates.sort(
            key=lambda rec: (
                0 if rec.status != "running" else 1,
                rec.finished_at or rec.last_output_at or rec.started_at or "",
            )
        )
        while len(_MANAGED_PROCESSES) >= max_items and candidates:
            victim = candidates.pop(0)
            if victim.status == "running":
                break
            _MANAGED_PROCESSES.pop(victim.process_id, None)


def _managed_process_register(record: ManagedProcessRecord) -> None:
    _managed_process_evict_if_needed()
    with _MANAGED_PROCESSES_LOCK:
        _MANAGED_PROCESSES[record.process_id] = record


def _managed_process_get(process_id: Optional[str]) -> Optional[ManagedProcessRecord]:
    pid = str(process_id or "").strip()
    if not pid:
        return None
    with _MANAGED_PROCESSES_LOCK:
        return _MANAGED_PROCESSES.get(pid)


def _managed_process_output_since(record: ManagedProcessRecord, after_seq: int, stream: str) -> List[Dict[str, Any]]:
    stream_filter = str(stream or "all").strip().lower()
    if stream_filter not in {"all", "stdout", "stderr"}:
        stream_filter = "all"
    out: List[Dict[str, Any]] = []
    with record.output_lock:
        for chunk in list(record.chunks):
            if int(chunk.seq) <= int(after_seq):
                continue
            if stream_filter != "all" and chunk.stream != stream_filter:
                continue
            out.append(
                {
                    "seq": int(chunk.seq),
                    "stream": chunk.stream,
                    "timestamp": chunk.timestamp,
                    "text": chunk.text,
                }
            )
    return out


def _managed_process_make_output_data(
    record: ManagedProcessRecord,
    *,
    after_seq: int,
    stream: str,
    max_chars: int,
) -> Dict[str, Any]:
    chunks = _managed_process_output_since(record, after_seq=after_seq, stream=stream)
    total_chars = 0
    kept: List[Dict[str, Any]] = []
    clipped = False
    cap = max(256, int(max_chars or 0))
    for chunk in chunks:
        text = str(chunk.get("text") or "")
        new_total = total_chars + len(text)
        if new_total > cap:
            remaining = max(0, cap - total_chars)
            if remaining <= 0:
                clipped = True
                break
            clipped_chunk = dict(chunk)
            clipped_chunk["text"] = text[:remaining]
            kept.append(clipped_chunk)
            total_chars += len(clipped_chunk["text"])
            clipped = True
            break
        kept.append(chunk)
        total_chars = new_total
    joined = "".join(str(chunk.get("text") or "") for chunk in kept)
    data = record.metadata()
    data.update(
        {
            "after_seq": int(after_seq),
            "stream": str(stream or "all"),
            "chunks": kept,
            "text": joined,
            "returned_chars": int(total_chars),
            "clipped": bool(clipped),
        }
    )
    return data


def _ansi_strip(text: str) -> str:
    try:
        return re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", str(text or ""))
    except Exception:
        try:
            return str(text or "")
        except Exception:
            return ""


def _normalize_terminal_visible_text(text: str) -> str:
    try:
        s = str(text or "")
    except Exception:
        s = ""
    s = s.replace("\r\n", "\n")
    s = s.replace("\r", "\n")
    s = _ansi_strip(s)
    return s


def _terminal_screen_text(record: ManagedTerminalRecord) -> str:
    with record.output_lock:
        joined = "".join(str(chunk.text or "") for chunk in list(record.chunks))
        rows = max(1, int(record.rows or _MANAGED_TERMINAL_DEFAULT_ROWS))
    visible = _normalize_terminal_visible_text(joined)
    lines = visible.splitlines()
    if not lines:
        return ""
    return "\n".join(lines[-rows:])


def _managed_terminal_append_chunk(record: ManagedTerminalRecord, text: str, stream_name: str = "stdout") -> None:
    if not isinstance(text, str) or not text:
        return
    stream_key = "stderr" if str(stream_name).strip().lower() == "stderr" else "stdout"
    timestamp = _utc_now_iso()
    with record.output_lock:
        record.chunk_seq += 1
        chunk = ManagedProcessChunk(seq=int(record.chunk_seq), stream=stream_key, text=text, timestamp=timestamp)
        record.chunks.append(chunk)
        max_chunks = max(20, int(_MANAGED_TERMINAL_MAX_CHUNKS))
        while len(record.chunks) > max_chunks:
            old = record.chunks.popleft()
            old_len = len(str(old.text or ""))
            record.output_chars = max(0, int(record.output_chars) - old_len)
            if old.stream == "stderr":
                record.stderr_chars = max(0, int(record.stderr_chars) - old_len)
            else:
                record.stdout_chars = max(0, int(record.stdout_chars) - old_len)
        max_chars = max(1024, int(_MANAGED_TERMINAL_OUTPUT_MAX_CHARS))
        while record.output_chars > max_chars and record.chunks:
            old = record.chunks.popleft()
            old_len = len(str(old.text or ""))
            record.output_chars = max(0, int(record.output_chars) - old_len)
            if old.stream == "stderr":
                record.stderr_chars = max(0, int(record.stderr_chars) - old_len)
            else:
                record.stdout_chars = max(0, int(record.stdout_chars) - old_len)
        text_len = len(text)
        record.output_chars += text_len
        if stream_key == "stderr":
            record.stderr_chars += text_len
        else:
            record.stdout_chars += text_len
        record.last_output_seq = int(chunk.seq)
        record.last_output_at = timestamp
    with record.wait_cond:
        record.wait_cond.notify_all()


def _managed_terminal_reader_posix(record: ManagedTerminalRecord, fd: int) -> None:
    try:
        while True:
            try:
                data = os.read(fd, 4096)
            except OSError as e:
                if int(getattr(e, "errno", 0) or 0) in {errno.EIO, errno.EBADF}:
                    break
                raise
            if not data:
                break
            _managed_terminal_append_chunk(record, data.decode("utf-8", errors="replace"), "stdout")
    except Exception as e:
        with record.output_lock:
            if not record.error:
                record.error = f"terminal reader error: {type(e).__name__}: {e}"
    finally:
        with record.wait_cond:
            record.wait_cond.notify_all()


def _managed_terminal_reader_windows(record: ManagedTerminalRecord, proc: Any) -> None:
    try:
        while True:
            try:
                chunk = proc.read()
            except EOFError:
                break
            except Exception as e:
                msg = str(e or "")
                if "closed" in msg.lower() or "ended" in msg.lower():
                    break
                raise
            if chunk in (None, ""):
                try:
                    isalive = getattr(proc, "isalive", None)
                    if callable(isalive) and not bool(isalive()):
                        break
                except Exception:
                    pass
                time.sleep(0.02)
                continue
            _managed_terminal_append_chunk(record, str(chunk), "stdout")
    except Exception as e:
        if not _managed_terminal_should_suppress_reader_error(record, e):
            with record.output_lock:
                if not record.error:
                    record.error = f"terminal reader error: {type(e).__name__}: {e}"
    finally:
        with record.wait_cond:
            record.wait_cond.notify_all()


def _managed_terminal_monitor(record: ManagedTerminalRecord) -> None:
    try:
        proc = record.proc
        code = _managed_terminal_wait(proc)
    except Exception as e:
        code = None
        with record.output_lock:
            if not record.error:
                record.error = f"terminal monitor error: {type(e).__name__}: {e}"
    finally:
        with record.output_lock:
            _managed_terminal_maybe_clear_expected_close_error(record)
            record.exit_code = (int(code) if isinstance(code, int) else None)
            record.status = _managed_terminal_final_status(record, code)
            record.finished_at = _utc_now_iso()
        try:
            if record.master_fd is not None:
                os.close(record.master_fd)
        except Exception:
            pass
        with record.wait_cond:
            record.wait_cond.notify_all()


def _managed_terminal_poll(proc: Any) -> Optional[int]:
    try:
        if proc is None:
            return None
        poll_fn = getattr(proc, "poll", None)
        if callable(poll_fn):
            code = poll_fn()
            return (int(code) if isinstance(code, int) else None)
        isalive_fn = getattr(proc, "isalive", None)
        if callable(isalive_fn):
            if bool(isalive_fn()):
                return None
        exitstatus_fn = getattr(proc, "get_exitstatus", None)
        if callable(exitstatus_fn):
            code = exitstatus_fn()
            return (int(code) if isinstance(code, int) else 0)
        exitstatus_attr = getattr(proc, "exitstatus", None)
        if isinstance(exitstatus_attr, int):
            return int(exitstatus_attr)
    except Exception:
        return None
    return 0


def _managed_terminal_wait(proc: Any, timeout: Optional[float] = None) -> Optional[int]:
    try:
        if proc is None:
            return None
        wait_fn = getattr(proc, "wait", None)
        if callable(wait_fn):
            try:
                code = wait_fn(timeout=timeout) if timeout is not None else wait_fn()
            except TypeError:
                code = wait_fn()
            return (int(code) if isinstance(code, int) else _managed_terminal_poll(proc))
        deadline = (time.time() + float(timeout)) if isinstance(timeout, (int, float)) else None
        while True:
            code = _managed_terminal_poll(proc)
            if code is not None:
                return code
            if deadline is not None and time.time() >= deadline:
                return None
            time.sleep(0.05)
    except Exception:
        return _managed_terminal_poll(proc)


def _managed_terminal_register(record: ManagedTerminalRecord) -> None:
    max_items = max(4, int(_MANAGED_TERMINAL_MAX_ITEMS))
    with _MANAGED_TERMINALS_LOCK:
        if len(_MANAGED_TERMINALS) >= max_items:
            candidates = list(_MANAGED_TERMINALS.values())
            candidates.sort(
                key=lambda rec: (
                    0 if rec.status != "running" else 1,
                    rec.finished_at or rec.last_output_at or rec.started_at or "",
                )
            )
            while len(_MANAGED_TERMINALS) >= max_items and candidates:
                victim = candidates.pop(0)
                if victim.status == "running":
                    break
                _MANAGED_TERMINALS.pop(victim.terminal_id, None)
        _MANAGED_TERMINALS[record.terminal_id] = record


def _managed_terminal_get(terminal_id: Optional[str]) -> Optional[ManagedTerminalRecord]:
    tid = str(terminal_id or "").strip()
    if not tid:
        return None
    with _MANAGED_TERMINALS_LOCK:
        return _MANAGED_TERMINALS.get(tid)


def _managed_terminal_output_since(record: ManagedTerminalRecord, after_seq: int, stream: str) -> List[Dict[str, Any]]:
    stream_filter = str(stream or "all").strip().lower()
    if stream_filter not in {"all", "stdout", "stderr"}:
        stream_filter = "all"
    out: List[Dict[str, Any]] = []
    with record.output_lock:
        for chunk in list(record.chunks):
            if int(chunk.seq) <= int(after_seq):
                continue
            if stream_filter != "all" and chunk.stream != stream_filter:
                continue
            out.append({
                "seq": int(chunk.seq),
                "stream": chunk.stream,
                "timestamp": chunk.timestamp,
                "text": chunk.text,
            })
    return out


def _managed_terminal_make_snapshot_data(
    record: ManagedTerminalRecord,
    *,
    after_seq: int,
    stream: str,
    max_chars: int,
) -> Dict[str, Any]:
    chunks = _managed_terminal_output_since(record, after_seq=after_seq, stream=stream)
    total_chars = 0
    kept: List[Dict[str, Any]] = []
    clipped = False
    cap = max(256, int(max_chars or 0))
    for chunk in chunks:
        text = str(chunk.get("text") or "")
        new_total = total_chars + len(text)
        if new_total > cap:
            remaining = max(0, cap - total_chars)
            if remaining <= 0:
                clipped = True
                break
            clipped_chunk = dict(chunk)
            clipped_chunk["text"] = text[:remaining]
            kept.append(clipped_chunk)
            total_chars += len(clipped_chunk["text"])
            clipped = True
            break
        kept.append(chunk)
        total_chars = new_total
    joined = "".join(str(chunk.get("text") or "") for chunk in kept)
    data = record.metadata()
    data.update(
        {
            "after_seq": int(after_seq),
            "stream": str(stream or "all"),
            "chunks": kept,
            "text": joined,
            "returned_chars": int(total_chars),
            "clipped": bool(clipped),
            "screen_text": _terminal_screen_text(record),
        }
    )
    return data


def _terminal_set_winsize(fd: int, rows: int, cols: int) -> None:
    if os.name == "nt":
        raise RuntimeError("interactive terminals require ConPTY/pywinpty support on Windows, which is not available in this runtime")
    import fcntl
    import struct
    import termios

    winsz = struct.pack("HHHH", int(rows), int(cols), 0, 0)
    fcntl.ioctl(fd, termios.TIOCSWINSZ, winsz)


def _windows_import_winpty() -> Any:
    if os.name != "nt":
        return None
    try:
        import winpty  # type: ignore
        return winpty
    except Exception:
        return None


def _terminal_newline_text() -> str:
    """Return the newline sequence to inject into interactive terminals.

    Windows managed terminals proved more reliable when sent a literal carriage
    return rather than line feed. POSIX PTYs continue to use LF.
    """
    return "\r" if os.name == "nt" else "\n"


def _terminal_keys_to_text(keys: List[str]) -> str:
    mapping = {
        "ENTER": _terminal_newline_text(),
        "RETURN": _terminal_newline_text(),
        "TAB": "\t",
        "ESC": "\x1b",
        "BACKSPACE": "\x7f",
        "CTRL_C": "\x03",
        "CTRL_D": "\x04",
        "CTRL_Z": "\x1a",
        "UP": "\x1b[A",
        "DOWN": "\x1b[B",
        "RIGHT": "\x1b[C",
        "LEFT": "\x1b[D",
    }
    out: List[str] = []
    for key in keys:
        token = str(key or "").strip()
        if not token:
            continue
        out.append(mapping.get(token.upper(), token))
    return "".join(out)


# -------------------------- Token estimation --------------------------#

_DID_TRY_LOAD_DOTENV_FOR_GEMINI = False


def _env_truthy(name: str) -> bool:
    try:
        v = os.getenv(name, "")
        return str(v).strip().lower() in {"1", "true", "yes", "y", "on"}
    except Exception:
        return False


def _maybe_load_dotenv_for_gemini() -> None:
    """Best-effort: load a local .env into os.environ so GEMINI_API_KEY is available.

    This is intentionally optional and safe:
    - If python-dotenv isn't installed, this is a no-op.
    - If no .env is found, this is a no-op.
    - We only do it once per process.

    Rationale: some tool runners (and unit tests) invoke henosis_cli_tools directly
    without importing the server's app.settings (which normally loads .env).
    """
    global _DID_TRY_LOAD_DOTENV_FOR_GEMINI
    if _DID_TRY_LOAD_DOTENV_FOR_GEMINI:
        return
    _DID_TRY_LOAD_DOTENV_FOR_GEMINI = True

    # Allow opt-out.
    if _env_truthy("HENOSIS_DISABLE_DOTENV_AUTOLOAD") or _env_truthy("HENOSIS_DISABLE_GEMINI_DOTENV_AUTOLOAD"):
        return
    try:
        from dotenv import load_dotenv  # type: ignore
    except Exception:
        return

    candidates: List[Path] = []
    try:
        candidates.append((Path.cwd() / ".env").resolve())
    except Exception:
        pass
    # Also try a repo-root relative to this file (best-effort; harmless when installed as a package).
    try:
        candidates.append((Path(__file__).resolve().parents[2] / ".env").resolve())
    except Exception:
        pass

    for p in candidates:
        try:
            if p.exists() and p.is_file():
                load_dotenv(p, override=False)
                if _env_truthy("HENOSIS_GEMINI_COUNT_TOKENS_DEBUG"):
                    _logger.info("Loaded .env for Gemini token counting: %s", str(p))
                break
        except Exception:
            continue

def _estimate_tokens_chars_per_token(text: str, *, chars_per_token: float = 4.0) -> int:
    """Heuristic token estimator.

    Gemini docs: ~4 characters per token (very rough, language-dependent).
    We use this as a safe fallback when provider-native token counting isn't available.
    """
    try:
        if not text:
            return 0
        cpt = float(chars_per_token)
        if cpt <= 0:
            cpt = 4.0
        return max(0, int(math.ceil(len(text) / cpt)))
    except Exception:
        return 0


def _gemini_count_tokens(text: str, *, model: str, api_key: Optional[str] = None) -> Optional[int]:
    """Count tokens using Google Gemini's count_tokens API.

    NOTE: This performs a provider API call.

    Env vars:
      - GEMINI_API_KEY or HENOSIS_GEMINI_API_KEY: API key
      - HENOSIS_GEMINI_TOKEN_COUNT_MODEL: override model used for counting
    """
    try:
        if not text:
            return 0
        key = (api_key or "").strip()
        if not key:
            # In some environments (e.g., tool runners), .env isn't loaded into os.environ.
            # Try to load it once before giving up.
            _maybe_load_dotenv_for_gemini()
            key = (
                os.getenv("GEMINI_API_KEY")
                or os.getenv("HENOSIS_GEMINI_API_KEY")
                or ""
            ).strip()
        if not key:
            if _env_truthy("HENOSIS_GEMINI_COUNT_TOKENS_DEBUG"):
                _logger.warning(
                    "Gemini count_tokens skipped: missing API key (GEMINI_API_KEY/HENOSIS_GEMINI_API_KEY not set)"
                )
            return None
        # Lazy import so the shared library can be used without google-genai installed.
        from google import genai  # type: ignore

        client = genai.Client(api_key=key)
        # google-genai has changed accepted shapes across versions.
        # Try a couple safe forms.
        try:
            resp = client.models.count_tokens(model=str(model), contents=text)
        except Exception:
            resp = client.models.count_tokens(model=str(model), contents=[text])
        # SDKs vary: support object attr or dict-like.
        tok = getattr(resp, "total_tokens", None)
        if tok is None and isinstance(resp, dict):
            tok = resp.get("total_tokens")
        if tok is None and hasattr(resp, "model_dump"):
            try:
                d = resp.model_dump()  # type: ignore[attr-defined]
                if isinstance(d, dict):
                    tok = d.get("total_tokens")
            except Exception:
                tok = None
        if tok is None:
            return None
        return max(0, int(tok))
    except Exception as e:
        if _env_truthy("HENOSIS_GEMINI_COUNT_TOKENS_DEBUG"):
            try:
                _logger.warning(
                    "Gemini count_tokens failed (model=%s, text_chars=%d): %s: %s",
                    str(model),
                    len(text or ""),
                    type(e).__name__,
                    str(e)[:300],
                )
            except Exception:
                pass
        return None

# ----------------------------- File ops -----------------------------#
def read_file(path: str, policy: FileToolPolicy) -> Dict[str, Any]:
    p = resolve_path(path, policy)
    if not p.exists():
        return {"ok": False, "error": "file does not exist"}
    if not p.is_file():
        return {"ok": False, "error": "path is not a file"}
    _file_size_ok(p, policy.max_bytes)
    text = read_text_auto(p)
    path_label = str(p) if policy.scope == "host" else str(p.relative_to(policy.workspace_base))

    # Token estimate:
    # We want "tokens_used" to reflect the cost of *injecting the file content* into the model context.
    # Prefer provider-native counting via Gemini's count_tokens when available; fall back to ~4 chars/token.
    tokens_used_details: Dict[str, Any] = {
        "method": "chars_per_token",
        "chars_per_token": 4,
    }
    tokens_used = _estimate_tokens_chars_per_token(text, chars_per_token=4.0)

    if text:
        # Default token-count model:
        # - Must support the Gemini `count_tokens` method for your API version.
        # - gemini-2.5-pro and gemini-2.0-flash are broadly available on v1beta.
        #
        # Env overrides (checked in this order):
        #   - HENOSIS_GEMINI_TOKEN_COUNT_MODEL (library-level)
        #   - GEMINI_TOKEN_COUNTER_MODEL (server settings convention)
        count_model = (
            os.getenv("HENOSIS_GEMINI_TOKEN_COUNT_MODEL")
            or os.getenv("GEMINI_TOKEN_COUNTER_MODEL")
            or "gemini-2.5-pro"
        ).strip()
        pol_key = None
        try:
            pol_key = getattr(policy, "_gemini_api_key", None)
        except Exception:
            pol_key = None
        tok = _gemini_count_tokens(text, model=count_model, api_key=(str(pol_key) if pol_key else None))
        if isinstance(tok, int):
            tokens_used = tok
            tokens_used_details = {
                "method": "gemini.count_tokens",
                "model": count_model,
            }

    return {
        "ok": True,
        "data": {
            "path": path_label,
            "content": text,
            "tokens_used": int(tokens_used),
            "tokens_used_details": tokens_used_details,
        },
    }

def write_file(path: str, content: str, policy: FileToolPolicy) -> Dict[str, Any]:
    p = resolve_path(path, policy)
    _ensure_size_limit_bytes(content, policy.max_bytes)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8", newline="") as f:
        f.write(content)
    tokens_used = int(len(content) / 0.3) if content else 0
    return {"ok": True, "data": {"path": str(p), "tokens_used": tokens_used}}

def append_file(path: str, content: str, policy: FileToolPolicy) -> Dict[str, Any]:
    p = resolve_path(path, policy)
    _ensure_size_limit_bytes(content, policy.max_bytes)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8", newline="") as f:
        f.write(content)
    tokens_used = int(len(content) / 0.3) if content else 0
    return {"ok": True, "data": {"path": str(p), "tokens_used": tokens_used}}

def list_dir(path: str, policy: FileToolPolicy) -> Dict[str, Any]:
    # Resolve path with explicit error if resolution fails
    try:
        p = resolve_path(path, policy)
    except Exception as e:
        return {"ok": False, "error": f"resolve_path failed: {type(e).__name__}: {e}", "data": {"path_input": path, "scope": policy.scope}}

    if not p.exists():
        return {"ok": False, "error": "directory does not exist", "data": {"path": str(p), "scope": policy.scope}}
    if not p.is_dir():
        return {"ok": False, "error": "path is not a directory", "data": {"path": str(p), "scope": policy.scope}}

    items = []
    try:
        children = list(p.iterdir())
    except (PermissionError, OSError) as e:
        return {"ok": False, "error": f"list_dir error: {type(e).__name__}: {e}", "data": {"path": str(p), "scope": policy.scope}}
    except Exception as e:
        return {"ok": False, "error": f"Failed to list directory: {type(e).__name__}: {e}", "data": {"path": str(p), "scope": policy.scope}}

    for child in sorted(children, key=lambda x: (not x.is_dir(), x.name.lower()))[:1000]:
        info = {"name": child.name, "is_dir": child.is_dir()}
        if child.is_file():
            try:
                info["size"] = child.stat().st_size
            except Exception:
                info["size"] = None
        items.append(info)

    path_label = str(p) if policy.scope == "host" else str(p.relative_to(policy.workspace_base))
    return {"ok": True, "data": {"path": path_label, "items": items}}


def _parse_run_command_request(
    cmd: Optional[str],
    policy: FileToolPolicy,
    cwd: Optional[str],
    allow_commands_csv: Optional[str],
) -> Dict[str, Any]:
    cmd_str = str(_normalize_and_strip_wrapping_quotes(cmd or "")).strip()
    if not cmd_str:
        return {"ok": False, "error": "cmd is required"}

    cwd_path, cwd_err = _resolve_cwd_for_command(cwd, policy)
    if cwd_err:
        return {"ok": False, "error": cwd_err}

    allow_raw = (allow_commands_csv if allow_commands_csv is not None else os.getenv("HENOSIS_ALLOW_COMMANDS", ""))
    allow_set = {c.strip().lower() for c in (allow_raw or "").split(",") if c.strip()}
    allow_all = bool({"*", "any", "all"} & allow_set)
    if not allow_set:
        return {"ok": False, "error": "no commands allowed (empty allowlist)"}

    if os.name == "nt":
        win_parts = _windows_commandline_to_argv(cmd_str)
        if win_parts is not None:
            parts = win_parts
            parse_method = "windows.CommandLineToArgvW"
        else:
            try:
                parts = shlex.split(cmd_str, posix=False)
            except Exception as e:
                return {"ok": False, "error": f"invalid cmd: {e}"}
            parse_method = "shlex.posix_false"
    else:
        try:
            parts = shlex.split(cmd_str, posix=True)
        except Exception as e:
            return {"ok": False, "error": f"invalid cmd: {e}"}
        parse_method = "shlex.posix_true"

    argv_sanitized = False
    if os.name == "nt":
        try:
            parts, argv_sanitized2 = _windows_sanitize_argv(parts)
            argv_sanitized = bool(argv_sanitized or argv_sanitized2)
            if argv_sanitized2 and "windows.strip_wrapping_quotes" not in str(parse_method):
                parse_method = f"{parse_method}+windows.strip_wrapping_quotes"
        except Exception:
            argv_sanitized = bool(argv_sanitized)
    if not parts:
        return {"ok": False, "error": "cmd is empty after parsing"}

    exe = parts[0]
    candidates = _normalize_allowed_exe_names(exe)
    if (not allow_all) and not any(c in allow_set for c in candidates):
        show = candidates[0] if candidates else str(exe)
        return {"ok": False, "error": f"command '{show}' not allowed"}

    return {
        "ok": True,
        "data": {
            "cmd_str": cmd_str,
            "cwd_path": cwd_path,
            "parts": list(parts),
            "parse_method": parse_method,
            "argv_sanitized": bool(argv_sanitized),
            "allow_all": bool(allow_all),
        },
    }


def _resolve_effective_timeout(timeout: Optional[float]) -> Tuple[float, float, float, bool]:
    try:
        requested = float(timeout) if timeout is not None else float(_COMMAND_TIMEOUT_DEFAULT_SEC)
    except Exception:
        requested = float(_COMMAND_TIMEOUT_DEFAULT_SEC)
    try:
        max_sec = float(_COMMAND_TIMEOUT_MAX_SEC)
    except Exception:
        max_sec = 900.0
    if max_sec <= 0:
        max_sec = 0.01
    timeout_s = min(max(0.01, requested), max_sec)
    timeout_was_clamped = bool(requested > max_sec)
    return requested, max_sec, timeout_s, timeout_was_clamped


def _prepare_command_env_and_parts(parts: List[str], cwd_path: Path) -> Tuple[List[str], Dict[str, str]]:
    exe = parts[0] if parts else ""
    env = os.environ.copy()
    try:
        if os.getenv("HENOSIS_DISABLE_VENDORED_BINS", "").strip().lower() not in ("1", "true", "yes", "on"):
            vdir = _vendor_bin_dir()
            if vdir is not None:
                try:
                    rg_name = "rg.exe" if os.name == "nt" else "rg"
                    rg_path = vdir / rg_name
                    if rg_path.exists() and os.name != "nt":
                        st = rg_path.stat()
                        if (st.st_mode & 0o111) == 0:
                            rg_path.chmod(st.st_mode | 0o100)
                except Exception:
                    pass
                env = _prepend_path(env, vdir)
    except Exception:
        env = os.environ.copy()

    try:
        for node_bin in reversed(_node_bin_dirs_for_cwd(cwd_path)):
            env = _prepend_path(env, node_bin)
    except Exception:
        pass

    try:
        vdir2 = _vendor_bin_dir()
        exe_has_path = (os.path.sep in exe) or (os.path.altsep is not None and os.path.altsep in exe)
        if (not exe_has_path) and vdir2 is not None:
            base0 = os.path.basename(exe).lower()
            if os.name == "nt" and base0 in {"rg", "rg.exe"}:
                cand = vdir2 / "rg.exe"
                if cand.exists() and cand.is_file():
                    parts[0] = str(cand)
            else:
                resolved = None
                try:
                    resolved = shutil.which(exe, path=env.get("PATH"))
                except Exception:
                    resolved = None
                if not resolved:
                    cand_names: List[str] = []
                    if os.name == "nt":
                        if not exe.lower().endswith(".exe"):
                            cand_names.append(exe + ".exe")
                        cand_names.append(exe)
                    else:
                        cand_names.append(exe)
                    for nm in cand_names:
                        cand = vdir2 / nm
                        if cand.exists() and cand.is_file():
                            parts[0] = str(cand)
                            break
    except Exception:
        pass

    try:
        exe_has_path = (os.path.sep in exe) or (os.path.altsep is not None and os.path.altsep in exe)
        if os.name == "nt" and (not exe_has_path):
            cmd_shim = _resolve_windows_cmd_shim(exe, env)
            if cmd_shim:
                parts[0] = str(cmd_shim)
    except Exception:
        pass

    return parts, env

# --------------------------- run_command ----------------------------#
def run_command(
    cmd: Optional[str],
    policy: FileToolPolicy,
    cwd: Optional[str] = None,
    timeout: Optional[float] = None,
    allow_commands_csv: Optional[str] = None,
) -> Dict[str, Any]:
    """Execute a command without a shell.

    Input is provided as a single command string (cmd) and is parsed into argv
    using native-ish rules (CommandLineToArgvW on Windows; shlex on POSIX).
    """
    parsed = _parse_run_command_request(cmd, policy, cwd, allow_commands_csv)
    if not bool(parsed.get("ok")):
        return parsed
    pdata = parsed.get("data") if isinstance(parsed.get("data"), dict) else {}
    cmd_str = str(pdata.get("cmd_str") or "")
    cwd_path = pdata.get("cwd_path")
    parts = list(pdata.get("parts") or [])
    parse_method = str(pdata.get("parse_method") or "")
    argv_sanitized = bool(pdata.get("argv_sanitized"))
    requested, max_sec, timeout_s, timeout_was_clamped = _resolve_effective_timeout(timeout)
    start = time.time()
    try:
        parts, env = _prepare_command_env_and_parts(parts, cwd_path)

        # Force UTF-8 decoding with replacement to avoid locale-dependent decode errors
        # on Windows (e.g., cp1252 UnicodeDecodeError in reader thread).
        proc = subprocess.run(
            parts,
            shell=False,
            cwd=str(cwd_path),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_s,
            env=env,
        )
        dur_ms = int((time.time() - start) * 1000)
        # Truncate very verbose outputs to protect context size
        out = _truncate_if_verbose(proc.stdout)
        err = _truncate_if_verbose(proc.stderr)
        return {
            "ok": True,
            "data": {
                "cmd": cmd_str,
                "argv": list(parts),
                "parse_method": parse_method,
                "argv_sanitized": bool(argv_sanitized),
                "cwd": str(cwd_path),
                "exit_code": proc.returncode,
                "stdout": out,
                "stderr": err,
                "timed_out": False,
                "duration_ms": dur_ms,
                "timeout_requested_sec": requested,
                "timeout_effective_sec": timeout_s,
                "timeout_max_sec": max_sec,
                "timeout_was_clamped": timeout_was_clamped,
            },
        }
    except FileNotFoundError as e:
        # Common case: caller tries `rg` but it's not installed.
        # We *also* support a vendored binary under henosis_cli_tools/_vendor, so if
        # it's missing in a source checkout, provide a helpful hint.
        dur_ms = int((time.time() - start) * 1000)
        hint_lines: List[str] = []
        try:
            hint_lines.append(f"Executable not found: {parts[0]!r}")
            try:
                _missing_base = os.path.basename(str(parts[0] or "")).lower()
            except Exception:
                _missing_base = ""
            if _missing_base in {"rg", "rg.exe"}:
                vdir = _vendor_bin_dir()
                rg_name = "rg.exe" if os.name == "nt" else "rg"
                rg_path = (vdir / rg_name) if vdir else None
                hint_lines.append(
                    "ripgrep (rg) is allowed but was not found on PATH. "
                    "If you're running from source, vendor it with: python scripts/vendor_ripgrep.py"
                )
                if rg_path is not None:
                    hint_lines.append(f"Vendored path checked: {rg_path} (exists={rg_path.exists()})")
        except Exception:
            pass
        return {
            "ok": False,
            "error": f"{type(e).__name__}: {e}",
            "data": {
                "cmd": cmd_str,
                "argv": list(parts) if isinstance(parts, list) else None,
                "parse_method": parse_method,
                "argv_sanitized": bool(argv_sanitized),
                "cwd": str(cwd_path),
                "duration_ms": dur_ms,
                "hint": "\n".join(hint_lines) if hint_lines else None,
            },
        }
    except subprocess.TimeoutExpired as e:
        dur_ms = int((time.time() - start) * 1000)
        # Even in timeout, ensure any captured output is truncated if overly verbose
        out = _truncate_if_verbose(e.stdout or "")
        err = _truncate_if_verbose(e.stderr or "")
        return {
            "ok": True,
            "data": {
                "cmd": cmd_str,
                "argv": list(parts),
                "parse_method": parse_method,
                "argv_sanitized": bool(argv_sanitized),
                "cwd": str(cwd_path),
                "exit_code": None,
                "stdout": out,
                "stderr": err,
                "timed_out": True,
                "duration_ms": dur_ms,
                "timeout_requested_sec": requested,
                "timeout_effective_sec": timeout_s,
                "timeout_max_sec": max_sec,
                "timeout_was_clamped": timeout_was_clamped,
                "message": (
                    f"Command exceeded timeout (effective_timeout={timeout_s}s). "
                    "Process was terminated."
                ),
            },
        }


def spawn_command(
    cmd: Optional[str],
    policy: FileToolPolicy,
    cwd: Optional[str] = None,
    allow_commands_csv: Optional[str] = None,
) -> Dict[str, Any]:
    parsed = _parse_run_command_request(cmd, policy, cwd, allow_commands_csv)
    if not bool(parsed.get("ok")):
        return parsed
    pdata = parsed.get("data") if isinstance(parsed.get("data"), dict) else {}
    cmd_str = str(pdata.get("cmd_str") or "")
    cwd_path = pdata.get("cwd_path")
    parts = list(pdata.get("parts") or [])
    parse_method = str(pdata.get("parse_method") or "")
    argv_sanitized = bool(pdata.get("argv_sanitized"))
    process_id = f"proc_{uuid.uuid4().hex}"
    start = time.time()
    try:
        parts, env = _prepare_command_env_and_parts(parts, cwd_path)
        proc = subprocess.Popen(
            parts,
            shell=False,
            cwd=str(cwd_path),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=env,
            bufsize=1,
            creationflags=(subprocess.CREATE_NO_WINDOW if os.name == "nt" and hasattr(subprocess, "CREATE_NO_WINDOW") else 0),
        )
        record = ManagedProcessRecord(
            process_id=process_id,
            cmd=cmd_str,
            argv=list(parts),
            parse_method=parse_method,
            argv_sanitized=bool(argv_sanitized),
            cwd=str(cwd_path),
            pid=int(getattr(proc, "pid", 0) or 0),
            started_at=_utc_now_iso(),
            status="running",
            proc=proc,
        )
        _managed_process_register(record)
        for stream_name, pipe in (("stdout", proc.stdout), ("stderr", proc.stderr)):
            t = threading.Thread(
                target=_managed_process_reader,
                args=(record, stream_name, pipe),
                daemon=True,
            )
            t.start()
        monitor = threading.Thread(target=_managed_process_monitor, args=(record,), daemon=True)
        monitor.start()
        dur_ms = int((time.time() - start) * 1000)
        data = record.metadata()
        data.update({"duration_ms": dur_ms, "process_id": process_id})
        return {"ok": True, "data": data}
    except FileNotFoundError as e:
        dur_ms = int((time.time() - start) * 1000)
        return {
            "ok": False,
            "error": f"{type(e).__name__}: {e}",
            "data": {
                "cmd": cmd_str,
                "argv": list(parts) if isinstance(parts, list) else None,
                "parse_method": parse_method,
                "argv_sanitized": bool(argv_sanitized),
                "cwd": str(cwd_path),
                "duration_ms": dur_ms,
            },
        }
    except Exception as e:
        dur_ms = int((time.time() - start) * 1000)
        return {
            "ok": False,
            "error": f"{type(e).__name__}: {e}",
            "data": {
                "cmd": cmd_str,
                "argv": list(parts) if isinstance(parts, list) else None,
                "parse_method": parse_method,
                "argv_sanitized": bool(argv_sanitized),
                "cwd": str(cwd_path),
                "duration_ms": dur_ms,
            },
        }


def process_list(limit: Optional[int] = None) -> Dict[str, Any]:
    try:
        max_items = max(1, min(int(limit or _MANAGED_PROCESS_LIST_LIMIT), int(_MANAGED_PROCESS_LIST_LIMIT)))
    except Exception:
        max_items = int(_MANAGED_PROCESS_LIST_LIMIT)
    with _MANAGED_PROCESSES_LOCK:
        items = list(_MANAGED_PROCESSES.values())
    items.sort(key=lambda rec: rec.started_at or "", reverse=True)
    data = [rec.metadata() for rec in items[:max_items]]
    return {"ok": True, "data": {"items": data, "count": len(data)}}


def process_status(process_id: Optional[str]) -> Dict[str, Any]:
    record = _managed_process_get(process_id)
    if record is None:
        return {"ok": False, "error": "process not found"}
    with record.output_lock:
        record.status = _managed_process_status(record.proc) if record.status == "running" else record.status
        data = record.metadata()
    return {"ok": True, "data": data}


def process_output(
    process_id: Optional[str],
    after_seq: Optional[int] = None,
    stream: Optional[str] = None,
    max_chars: Optional[int] = None,
) -> Dict[str, Any]:
    record = _managed_process_get(process_id)
    if record is None:
        return {"ok": False, "error": "process not found"}
    try:
        seq = max(0, int(after_seq or 0))
    except Exception:
        seq = 0
    try:
        cap = max(256, int(max_chars or 16000))
    except Exception:
        cap = 16000
    data = _managed_process_make_output_data(
        record,
        after_seq=seq,
        stream=str(stream or "all"),
        max_chars=cap,
    )
    return {"ok": True, "data": data}


def wait_process(process_id: Optional[str], timeout: Optional[float] = None) -> Dict[str, Any]:
    record = _managed_process_get(process_id)
    if record is None:
        return {"ok": False, "error": "process not found"}
    try:
        requested = float(timeout) if timeout is not None else float(_COMMAND_TIMEOUT_DEFAULT_SEC)
    except Exception:
        requested = float(_COMMAND_TIMEOUT_DEFAULT_SEC)
    try:
        max_sec = float(_COMMAND_TIMEOUT_MAX_SEC)
    except Exception:
        max_sec = 900.0
    if max_sec <= 0:
        max_sec = 0.01
    timeout_s = min(max(0.01, requested), max_sec)
    timeout_was_clamped = bool(requested > max_sec)
    start = time.time()
    with record.wait_cond:
        if record.status == "running":
            record.wait_cond.wait(timeout_s)
    with record.output_lock:
        if record.status == "running":
            record.status = _managed_process_status(record.proc)
            if record.status != "running" and record.finished_at is None:
                record.finished_at = _utc_now_iso()
                try:
                    record.exit_code = int(record.proc.poll()) if record.proc is not None else None
                except Exception:
                    record.exit_code = None
        data = record.metadata()
    data.update(
        {
            "duration_ms": int((time.time() - start) * 1000),
            "timeout_requested_sec": float(requested),
            "timeout_effective_sec": float(timeout_s),
            "timeout_max_sec": float(max_sec),
            "timeout_was_clamped": bool(timeout_was_clamped),
            "timed_out": bool(data.get("status") == "running"),
        }
    )
    return {"ok": True, "data": data}


def terminate_process(process_id: Optional[str]) -> Dict[str, Any]:
    record = _managed_process_get(process_id)
    if record is None:
        return {"ok": False, "error": "process not found"}
    proc = record.proc
    if proc is None:
        return {"ok": False, "error": "process handle unavailable"}
    start = time.time()
    terminated = False
    killed = False
    try:
        if proc.poll() is None:
            try:
                proc.terminate()
                terminated = True
                proc.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                proc.kill()
                killed = True
                proc.wait(timeout=5.0)
        code = proc.poll()
    except Exception as e:
        with record.output_lock:
            record.error = _managed_process_compact_error(e)
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    with record.output_lock:
        record.exit_code = int(code) if isinstance(code, int) else record.exit_code
        record.status = "killed" if killed or terminated else _managed_process_status(proc)
        record.finished_at = record.finished_at or _utc_now_iso()
        data = record.metadata()
    data.update(
        {
            "duration_ms": int((time.time() - start) * 1000),
            "terminated": bool(terminated),
            "killed": bool(killed),
        }
    )
    with record.wait_cond:
        record.wait_cond.notify_all()
    return {"ok": True, "data": data}


def spawn_terminal(
    cmd: Optional[str],
    policy: FileToolPolicy,
    cwd: Optional[str] = None,
    allow_commands_csv: Optional[str] = None,
    cols: Optional[int] = None,
    rows: Optional[int] = None,
) -> Dict[str, Any]:
    parsed = _parse_run_command_request(cmd, policy, cwd, allow_commands_csv)
    if not bool(parsed.get("ok")):
        return parsed
    pdata = parsed.get("data") if isinstance(parsed.get("data"), dict) else {}
    cmd_str = str(pdata.get("cmd_str") or "")
    cwd_path = pdata.get("cwd_path")
    parts = list(pdata.get("parts") or [])
    parse_method = str(pdata.get("parse_method") or "")
    argv_sanitized = bool(pdata.get("argv_sanitized"))
    try:
        cols_i = max(20, int(cols or _MANAGED_TERMINAL_DEFAULT_COLS))
    except Exception:
        cols_i = int(_MANAGED_TERMINAL_DEFAULT_COLS)
    try:
        rows_i = max(5, int(rows or _MANAGED_TERMINAL_DEFAULT_ROWS))
    except Exception:
        rows_i = int(_MANAGED_TERMINAL_DEFAULT_ROWS)
    terminal_id = f"term_{uuid.uuid4().hex}"
    start = time.time()
    try:
        parts, env = _prepare_command_env_and_parts(parts, cwd_path)
        master_fd = None
        if os.name == "nt":
            winpty_mod = _windows_import_winpty()
            if winpty_mod is None:
                return {
                    "ok": False,
                    "error": "interactive terminals on Windows require pywinpty/ConPTY support, but pywinpty is not installed",
                }
            proc = None
            spawn_errors: List[str] = []
            try:
                PtyProcess = getattr(winpty_mod, "PtyProcess", None)
                if PtyProcess is not None:
                    proc = PtyProcess.spawn(
                        " ".join(parts),
                        cwd=str(cwd_path),
                        env=env,
                        dimensions=(int(rows_i), int(cols_i)),
                    )
            except Exception as e:
                spawn_errors.append(f"PtyProcess.spawn failed: {type(e).__name__}: {e}")
            if proc is None:
                try:
                    PTY = getattr(winpty_mod, "PTY", None)
                    if PTY is not None:
                        proc = PTY(int(cols_i), int(rows_i))
                        proc.spawn(" ".join(parts), cwd=str(cwd_path), env=env)
                except Exception as e:
                    spawn_errors.append(f"PTY.spawn failed: {type(e).__name__}: {e}")
            if proc is None:
                return {"ok": False, "error": "; ".join(spawn_errors) or "failed to create Windows terminal session"}
            pid_val = 0
            try:
                pid_attr = getattr(proc, "pid", None)
                pid_val = int(pid_attr() if callable(pid_attr) else pid_attr or 0)
            except Exception:
                pid_val = 0
        else:
            import pty

            master_fd, slave_fd = pty.openpty()
            try:
                _terminal_set_winsize(slave_fd, rows_i, cols_i)
            except Exception:
                pass
            proc = subprocess.Popen(
                parts,
                stdin=slave_fd,
                stdout=slave_fd,
                stderr=slave_fd,
                cwd=str(cwd_path),
                env=env,
                close_fds=True,
            )
            try:
                os.close(slave_fd)
            except Exception:
                pass
            pid_val = int(getattr(proc, "pid", 0) or 0)
        record = ManagedTerminalRecord(
            terminal_id=terminal_id,
            cmd=cmd_str,
            argv=list(parts),
            parse_method=parse_method,
            argv_sanitized=bool(argv_sanitized),
            cwd=str(cwd_path),
            pid=int(pid_val),
            started_at=_utc_now_iso(),
            status="running",
            cols=int(cols_i),
            rows=int(rows_i),
            proc=proc,
            master_fd=(int(master_fd) if isinstance(master_fd, int) else None),
        )
        _managed_terminal_register(record)
        if os.name == "nt":
            reader = threading.Thread(target=_managed_terminal_reader_windows, args=(record, proc), daemon=True)
        else:
            reader = threading.Thread(target=_managed_terminal_reader_posix, args=(record, int(master_fd)), daemon=True)
        reader.start()
        monitor = threading.Thread(target=_managed_terminal_monitor, args=(record,), daemon=True)
        monitor.start()
        data = record.metadata()
        data.update({"terminal_id": terminal_id, "duration_ms": int((time.time() - start) * 1000)})
        return {"ok": True, "data": data}
    except FileNotFoundError as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def terminal_list(limit: Optional[int] = None) -> Dict[str, Any]:
    try:
        max_items = max(1, min(int(limit or _MANAGED_TERMINAL_LIST_LIMIT), int(_MANAGED_TERMINAL_LIST_LIMIT)))
    except Exception:
        max_items = int(_MANAGED_TERMINAL_LIST_LIMIT)
    with _MANAGED_TERMINALS_LOCK:
        items = list(_MANAGED_TERMINALS.values())
    items.sort(key=lambda rec: rec.started_at or "", reverse=True)
    data = [rec.metadata() for rec in items[:max_items]]
    return {"ok": True, "data": {"items": data, "count": len(data)}}


def terminal_snapshot(
    terminal_id: Optional[str],
    after_seq: Optional[int] = None,
    stream: Optional[str] = None,
    max_chars: Optional[int] = None,
) -> Dict[str, Any]:
    record = _managed_terminal_get(terminal_id)
    if record is None:
        return {"ok": False, "error": "terminal not found"}
    try:
        seq = max(0, int(after_seq or 0))
    except Exception:
        seq = 0
    try:
        cap = max(256, int(max_chars or 16000))
    except Exception:
        cap = 16000
    data = _managed_terminal_make_snapshot_data(
        record,
        after_seq=seq,
        stream=str(stream or "all"),
        max_chars=cap,
    )
    return {"ok": True, "data": data}


def terminal_input(
    terminal_id: Optional[str],
    *,
    text: Optional[str] = None,
    keys: Optional[List[str]] = None,
    append_newline: bool = False,
) -> Dict[str, Any]:
    record = _managed_terminal_get(terminal_id)
    if record is None:
        return {"ok": False, "error": "terminal not found"}
    payload = ""
    if isinstance(text, str) and text:
        payload += text
    if isinstance(keys, list) and keys:
        payload += _terminal_keys_to_text(keys)
    if append_newline:
        payload += _terminal_newline_text()
    if not payload:
        return {"ok": False, "error": "text or keys is required"}
    with record.output_lock:
        if record.status != "running":
            return {"ok": False, "error": f"terminal is not running (status={record.status})"}
    try:
        if os.name == "nt":
            proc = record.proc
            if proc is None:
                return {"ok": False, "error": "terminal handle unavailable"}
            write_fn = getattr(proc, "write", None)
            if not callable(write_fn):
                return {"ok": False, "error": "terminal write unsupported by Windows backend"}
            write_fn(payload)
            written = len(payload.encode("utf-8", errors="replace"))
        else:
            fd = int(record.master_fd) if record.master_fd is not None else None
            if fd is None:
                return {"ok": False, "error": "terminal handle unavailable"}
            written = os.write(fd, payload.encode("utf-8", errors="replace"))
        return {
            "ok": True,
            "data": {
                "terminal_id": record.terminal_id,
                "bytes_written": int(written),
                "chars_requested": len(payload),
                "append_newline": bool(append_newline),
            },
        }
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def terminal_resize(terminal_id: Optional[str], *, cols: Optional[int], rows: Optional[int]) -> Dict[str, Any]:
    record = _managed_terminal_get(terminal_id)
    if record is None:
        return {"ok": False, "error": "terminal not found"}
    try:
        cols_i = max(20, int(cols or record.cols or _MANAGED_TERMINAL_DEFAULT_COLS))
        rows_i = max(5, int(rows or record.rows or _MANAGED_TERMINAL_DEFAULT_ROWS))
    except Exception as e:
        return {"ok": False, "error": f"invalid terminal size: {e}"}
    try:
        if os.name == "nt":
            proc = record.proc
            if proc is None:
                return {"ok": False, "error": "terminal handle unavailable"}
            resize_fn = getattr(proc, "setwinsize", None) or getattr(proc, "set_size", None)
            if not callable(resize_fn):
                return {"ok": False, "error": "terminal resize unsupported by Windows backend"}
            try:
                resize_fn(int(rows_i), int(cols_i))
            except TypeError:
                resize_fn(int(cols_i), int(rows_i))
        else:
            fd = int(record.master_fd) if record.master_fd is not None else None
            if fd is None:
                return {"ok": False, "error": "terminal handle unavailable"}
            _terminal_set_winsize(fd, rows_i, cols_i)
        with record.output_lock:
            record.cols = int(cols_i)
            record.rows = int(rows_i)
            data = record.metadata()
        return {"ok": True, "data": data}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


def terminal_close(terminal_id: Optional[str]) -> Dict[str, Any]:
    record = _managed_terminal_get(terminal_id)
    if record is None:
        return {"ok": False, "error": "terminal not found"}
    proc = record.proc
    if proc is None:
        return {"ok": False, "error": "terminal handle unavailable"}
    start = time.time()
    terminated = False
    killed = False
    try:
        with record.output_lock:
            record.close_requested = True
        if _managed_terminal_poll(proc) is None:
            try:
                if os.name == "nt":
                    close_fn = getattr(proc, "close", None)
                    terminate_fn = getattr(proc, "terminate", None)
                    kill_fn = getattr(proc, "kill", None)
                    cancel_io_fn = getattr(proc, "cancel_io", None)
                    if callable(close_fn):
                        try:
                            close_fn(True)
                        except TypeError:
                            close_fn()
                    elif callable(terminate_fn):
                        terminate_fn()
                    elif callable(kill_fn):
                        kill_fn()
                    elif callable(cancel_io_fn):
                        cancel_io_fn()
                    else:
                        raise RuntimeError("terminal close unsupported by Windows backend")
                else:
                    proc.terminate()
                terminated = True
                code = _managed_terminal_wait(proc, timeout=5.0)
                if code is None:
                    raise subprocess.TimeoutExpired(cmd=str(getattr(record, "cmd", "terminal")), timeout=5.0)
            except subprocess.TimeoutExpired:
                kill_fn = getattr(proc, "kill", None)
                if callable(kill_fn):
                    kill_fn()
                elif os.name != "nt":
                    proc.kill()
                killed = True
                code = _managed_terminal_wait(proc, timeout=5.0)
            except AttributeError:
                if os.name == "nt":
                    kill_fn = getattr(proc, "kill", None)
                    if callable(kill_fn):
                        kill_fn()
                        killed = True
                else:
                    raise
        code = _managed_terminal_poll(proc)
    except Exception as e:
        with record.output_lock:
            record.error = _managed_process_compact_error(e)
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    with record.output_lock:
        _managed_terminal_maybe_clear_expected_close_error(record)
        record.exit_code = int(code) if isinstance(code, int) else record.exit_code
        record.status = _managed_terminal_final_status(record, code, terminated=terminated, killed=killed)
        record.finished_at = record.finished_at or _utc_now_iso()
        data = record.metadata()
    try:
        if record.master_fd is not None:
            os.close(record.master_fd)
            record.master_fd = None
    except Exception:
        pass
    data.update(
        {
            "duration_ms": int((time.time() - start) * 1000),
            "terminated": bool(terminated),
            "killed": bool(killed),
        }
    )
    with record.wait_cond:
        record.wait_cond.notify_all()
    return {"ok": True, "data": data}


def run_shell(
    command: str,
    policy: FileToolPolicy,
    cwd: Optional[str] = None,
    timeout: Optional[float] = None,
    shell: Optional[str] = None,
    allow_commands_csv: Optional[str] = None,
) -> Dict[str, Any]:
    """Execute a shell command string under an explicit shell.

    WARNING: This enables shell patterns (pipes, redirection, chaining) and cannot
    practically enforce an allowlist for subcommands executed *within* the shell.
    Only the shell executable itself is allowlist-checked.
    """
    cmd_text = str(_normalize_and_strip_wrapping_quotes(command or ""))
    if not cmd_text.strip():
        return {"ok": False, "error": "command is required"}

    cwd_path, cwd_err = _resolve_cwd_for_command(cwd, policy)
    if cwd_err:
        return {"ok": False, "error": cwd_err}

    allow_raw = (allow_commands_csv if allow_commands_csv is not None else os.getenv("HENOSIS_ALLOW_COMMANDS", ""))
    allow_set = {c.strip().lower() for c in (allow_raw or "").split(",") if c.strip()}
    allow_all = bool({"*", "any", "all"} & allow_set)
    if not allow_set:
        return {"ok": False, "error": "no commands allowed (empty allowlist)"}

    # Select shell argv
    shell_name = str(_normalize_and_strip_wrapping_quotes(shell or "")).strip().lower()
    if os.name == "nt":
        if not shell_name:
            shell_name = "cmd"
        if shell_name in {"cmd", "cmd.exe"}:
            parts = ["cmd.exe", "/d", "/s", "/c", cmd_text]
        elif shell_name in {"powershell", "powershell.exe"}:
            parts = ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd_text]
        elif shell_name in {"pwsh", "pwsh.exe"}:
            parts = ["pwsh", "-NoProfile", "-NonInteractive", "-Command", cmd_text]
        else:
            return {"ok": False, "error": f"unknown shell '{shell}'"}
    else:
        if not shell_name:
            shell_name = "bash"
        if shell_name in {"bash", "sh"}:
            parts = [shell_name, "-lc", cmd_text]
        else:
            return {"ok": False, "error": f"unknown shell '{shell}'"}

    exe = parts[0]
    candidates = _normalize_allowed_exe_names(exe)
    if (not allow_all) and not any(c in allow_set for c in candidates):
        show = candidates[0] if candidates else str(exe)
        return {"ok": False, "error": f"command '{show}' not allowed"}

    # Timeout handling mirrors run_command
    try:
        requested = float(timeout) if timeout is not None else float(_COMMAND_TIMEOUT_DEFAULT_SEC)
    except Exception:
        requested = float(_COMMAND_TIMEOUT_DEFAULT_SEC)
    try:
        max_sec = float(_COMMAND_TIMEOUT_MAX_SEC)
    except Exception:
        max_sec = 900.0
    if max_sec <= 0:
        max_sec = 0.01
    timeout_s = min(max(0.01, requested), max_sec)
    timeout_was_clamped = bool(requested > max_sec)

    start = time.time()
    try:
        env = os.environ.copy()
        try:
            if os.getenv("HENOSIS_DISABLE_VENDORED_BINS", "").strip().lower() not in ("1", "true", "yes", "on"):
                vdir = _vendor_bin_dir()
                if vdir is not None:
                    env = _prepend_path(env, vdir)
        except Exception:
            env = os.environ.copy()

        proc = subprocess.run(
            parts,
            shell=False,
            cwd=str(cwd_path),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout_s,
            env=env,
        )
        dur_ms = int((time.time() - start) * 1000)
        out = _truncate_if_verbose(proc.stdout)
        err = _truncate_if_verbose(proc.stderr)
        return {
            "ok": True,
            "data": {
                "command": cmd_text,
                "shell": shell_name,
                "argv": list(parts),
                "cwd": str(cwd_path),
                "exit_code": proc.returncode,
                "stdout": out,
                "stderr": err,
                "timed_out": False,
                "duration_ms": dur_ms,
                "timeout_requested_sec": requested,
                "timeout_effective_sec": timeout_s,
                "timeout_max_sec": max_sec,
                "timeout_was_clamped": timeout_was_clamped,
            },
        }
    except FileNotFoundError as e:
        dur_ms = int((time.time() - start) * 1000)
        return {
            "ok": False,
            "error": f"{type(e).__name__}: {e}",
            "data": {
                "command": cmd_text,
                "shell": shell_name,
                "argv": list(parts),
                "cwd": str(cwd_path),
                "duration_ms": dur_ms,
            },
        }
    except subprocess.TimeoutExpired as e:
        dur_ms = int((time.time() - start) * 1000)
        out = _truncate_if_verbose(e.stdout or "")
        err = _truncate_if_verbose(e.stderr or "")
        return {
            "ok": True,
            "data": {
                "command": cmd_text,
                "shell": shell_name,
                "argv": list(parts),
                "cwd": str(cwd_path),
                "exit_code": None,
                "stdout": out,
                "stderr": err,
                "timed_out": True,
                "duration_ms": dur_ms,
                "timeout_requested_sec": requested,
                "timeout_effective_sec": timeout_s,
                "timeout_max_sec": max_sec,
                "timeout_was_clamped": timeout_was_clamped,
                "message": (
                    f"Command exceeded timeout (effective_timeout={timeout_s}s). "
                    "Process was terminated."
                ),
            },
        }


# ---------------------------- apply_patch ----------------------------#
def _ap_normalize_unicode(s: str) -> str:
    trans = {
        "\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2013": "-", "\u2014": "-", "\u2015": "-",
        "\u2018": "'", "\u2019": "'", "\u201A": "'", "\u201B": "'",
        "\u201C": '"', "\u201D": '"', "\u201E": '"', "\u201F": '"',
        "\u00A0": " ", "\u2002": " ", "\u2003": " ", "\u2004": " ", "\u2005": " ", "\u2006": " ", "\u2007": " ", "\u2008": " ", "\u2009": " ", "\u200A": " ", "\u202F": " ", "\u205F": " ",
        "\u3000": " ",
    }
    return "".join(trans.get(ch, ch) for ch in s.strip())

def _ap_parse_patch(patch: str, *, lenient: bool = True) -> List[Dict[str, Any]]:
    raw = (patch or "").strip("\n")
    lines = raw.splitlines()
    if lenient and lines:
        first = lines[0].strip()
        last = lines[-1].strip()
        if first in ("<<EOF", "<<'EOF'", '<<"EOF"') and last == "EOF":
            lines = lines[1:-1]
    if not lines or lines[0].strip() != "*** Begin Patch":
        raise ValueError("patch must start with '*** Begin Patch'")
    if lines[-1].strip() != "*** End Patch":
        raise ValueError("patch must end with '*** End Patch'")
    body = lines[1:-1]
    i = 0
    hunks: List[Dict[str, Any]] = []
    def at(n: int) -> str:
        return body[n] if 0 <= n < len(body) else ""
    while i < len(body):
        line = at(i).strip()
        if not line:
            i += 1
            continue
        if line.startswith("*** Add File: "):
            path = line[len("*** Add File: "):]
            i += 1
            contents: List[str] = []
            while i < len(body):
                L = body[i]
                if L.startswith("*** "):
                    break
                if L.startswith("+"):
                    contents.append(L[1:])
                    i += 1
                else:
                    break
            if not contents or contents[-1] != "":
                contents.append("")
            hunks.append({"kind": "add", "path": path, "contents": "\n".join(contents)})
            continue
        if line.startswith("*** Delete File: "):
            path = line[len("*** Delete File: "):]
            hunks.append({"kind": "delete", "path": path})
            i += 1
            continue
        if line.startswith("*** Update File: "):
            path = line[len("*** Update File: "):]
            i += 1
            move_to: Optional[str] = None
            if i < len(body) and body[i].strip().startswith("*** Move to: "):
                move_to = body[i].strip()[len("*** Move to: "):]
                i += 1
            chunks: List[Dict[str, Any]] = []
            first_chunk = True
            while i < len(body):
                s = body[i]
                s_strip = s.strip()
                if not s_strip:
                    i += 1
                    continue
                if s_strip.startswith("*** "):
                    break
                context: Optional[str] = None
                consumed = 0
                had_header = False
                if s_strip == "@@":
                    consumed = 1
                    had_header = True
                elif s_strip.startswith("@@ "):
                    context = s_strip[3:]
                    consumed = 1
                    had_header = True
                else:
                    # Relaxed: allow implicit chunk (even after the first) without an @@ header
                    consumed = 0
                i += consumed
                old_lines: List[str] = []
                new_lines: List[str] = []
                eof_flag = False
                parsed = 0
                while i < len(body):
                    t = body[i]
                    t_strip = t.strip()
                    # Treat encountering a new header as the end of this chunk
                    if t_strip.startswith("*** "):
                        break
                    if t_strip == "@@" or t_strip.startswith("@@ "):
                        # If nothing parsed yet and we just saw a header, allow skipping empty hunks
                        break
                    if t_strip == "*** End of File":
                        eof_flag = True
                        i += 1
                        parsed += 1
                        break
                    if t.startswith("+"):
                        new_lines.append(t[1:])
                    elif t.startswith("-"):
                        old_lines.append(t[1:])
                    elif t.startswith(" "):
                        seg = t[1:]
                        old_lines.append(seg)
                        new_lines.append(seg)
                    else:
                        # Relaxed: treat plain, non-prefixed, non-header lines as unchanged context
                        seg = t
                        old_lines.append(seg)
                        new_lines.append(seg)
                    i += 1
                    parsed += 1
                # If we consumed a header but did not parse any lines, tolerate an empty hunk (skip it)
                if parsed == 0 and had_header:
                    first_chunk = False
                    continue
                if parsed == 0:
                    raise ValueError("empty update chunk")
                chunks.append({"context": context, "old": old_lines, "new": new_lines, "eof": eof_flag})
                first_chunk = False
            if not chunks:
                raise ValueError(f"empty update for path '{path}'")
            hunks.append({"kind": "update", "path": path, "move_to": move_to, "chunks": chunks})
            continue
        raise ValueError(f"invalid hunk header: {line}")
    return hunks

def _ap_resolve_target(base_dir: Path, rel_or_abs: str, policy: FileToolPolicy) -> Path:
    p_in = str(_normalize_and_strip_wrapping_quotes(rel_or_abs or "")).strip()
    if not p_in:
        raise ValueError("empty path in patch")
    p = Path(p_in)
    p = p.resolve() if p.is_absolute() else (base_dir / p).resolve()
    if policy.scope == "workspace":
        try:
            p.relative_to(policy.workspace_base)
        except Exception:
            raise ValueError("path escapes workspace")
    else:
        roots = policy.all_host_roots() or [Path.cwd().resolve()]
        for r in roots:
            try:
                p.relative_to(r)
                break
            except Exception:
                continue
        else:
            raise ValueError("path is not under any allowed host root")
    # Extension policy for files (ignore dirs)
    if p.suffix and policy.allowed_exts and not p.is_dir():
        if p.suffix.lower() not in policy.allowed_exts:
            raise ValueError(f"extension '{p.suffix}' not allowed")
    return p

def _ap_compute_replacements(original: List[str], chunks: List[Dict[str, Any]], path: Path) -> List[Tuple[int, int, List[str]]]:
    repls: List[Tuple[int, int, List[str]]] = []
    line_index = 0
    for ch in chunks:
        ctx = ch.get("context")
        old = ch.get("old") or []
        new = ch.get("new") or []
        eof = bool(ch.get("eof"))
        if ctx:
            idx = _ap_seek_sequence(original, [ctx], line_index, False)
            if idx is None:
                raise ValueError(f"Failed to find context '{ctx}' in {path}")
            line_index = idx + 1
        if not old:
            insertion_idx = (len(original) - 1) if (original and original[-1] == "") else len(original)
            repls.append((insertion_idx, 0, list(new)))
            continue
        pattern = list(old)
        new_slice = list(new)
        if eof and pattern and pattern[-1] == "":
            pattern = pattern[:-1]
            if new_slice and new_slice[-1] == "":
                new_slice = new_slice[:-1]
        found = _ap_seek_sequence(original, pattern, line_index, eof)
        if found is None:
            raise ValueError(f"Failed to find expected lines in {path}")
        repls.append((found, len(pattern), new_slice))
        line_index = found + len(pattern)
    return repls

def _ap_seek_sequence(lines: List[str], pattern: List[str], start: int, eof: bool) -> Optional[int]:
    if not pattern:
        return start
    if len(pattern) > len(lines):
        return None
    search_start = (len(lines) - len(pattern)) if (eof and len(lines) >= len(pattern)) else start
    for i in range(search_start, len(lines) - len(pattern) + 1):
        if lines[i:i + len(pattern)] == pattern:
            return i
    for i in range(search_start, len(lines) - len(pattern) + 1):
        ok = True
        for p_idx, pat in enumerate(pattern):
            if lines[i + p_idx].rstrip() != pat.rstrip():
                ok = False
                break
        if ok:
            return i
    for i in range(search_start, len(lines) - len(pattern) + 1):
        ok = True
        for p_idx, pat in enumerate(pattern):
            if lines[i + p_idx].strip() != pat.strip():
                ok = False
                break
        if ok:
            return i
    for i in range(search_start, len(lines) - len(pattern) + 1):
        ok = True
        for p_idx, pat in enumerate(pattern):
            if _ap_normalize_unicode(lines[i + p_idx]) != _ap_normalize_unicode(pat):
                ok = False
                break
        if ok:
            return i
    return None

def _atomic_write(target: Path, content: str, backup: bool) -> Optional[Path]:
    target.parent.mkdir(parents=True, exist_ok=True)
    # Backups are intentionally disabled; history should be tracked via git.
    backup_path: Optional[Path] = None
    fd, tmp_path = tempfile.mkstemp(prefix=target.name + ".tmp_", dir=str(target.parent))
    tmp_exists = True
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        # Atomically move temp file into place
        os.replace(tmp_path, target)
        tmp_exists = False
    finally:
        try:
            if tmp_exists and os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
    return backup_path


def _make_unified_diff(before: str, after: str, *, fromfile: str, tofile: str) -> str:
    return "\n".join(
        difflib.unified_diff(
            before.splitlines(),
            after.splitlines(),
            fromfile=fromfile,
            tofile=tofile,
            lineterm="",
        )
    )


def _count_unified_diff_lines(diff_text: str) -> Tuple[int, int]:
    added = 0
    removed = 0
    for line in (diff_text or "").splitlines():
        if line.startswith("+++ ") or line.startswith("--- "):
            continue
        if line.startswith("+"):
            added += 1
        elif line.startswith("-"):
            removed += 1
    return added, removed


def _truncate_diff_for_preview(
    diff_text: str,
    *,
    per_file_cap: int,
    total_remaining: int,
) -> Tuple[str, bool, Optional[Dict[str, Any]]]:
    text = str(diff_text or "")
    original_chars = len(text)
    per_cap = max(0, int(per_file_cap or 0))
    rem = max(0, int(total_remaining or 0))
    allowed = min(per_cap, rem)

    if original_chars <= allowed:
        return text, False, None

    reasons: List[str] = []
    if original_chars > per_cap:
        reasons.append("max_chars_per_file")
    if original_chars > rem:
        reasons.append("max_chars_total")

    if allowed <= 0:
        return "", True, {
            "original_chars": original_chars,
            "kept_chars": 0,
            "max_chars_per_file": per_cap,
            "max_chars_total": max(0, int(_APPLY_PATCH_DRY_RUN_MAX_DIFF_CHARS_TOTAL)),
            "total_remaining_before_file": rem,
            "reasons": reasons or ["max_chars_total"],
        }

    marker = "\n... (diff truncated) ...\n"
    if allowed <= (len(marker) + 16):
        out = text[:allowed]
    else:
        room = allowed - len(marker)
        head = int(room * 0.65)
        tail = max(0, room - head)
        out = text[:head] + marker + text[-tail:]

    return out, True, {
        "original_chars": original_chars,
        "kept_chars": len(out),
        "max_chars_per_file": per_cap,
        "max_chars_total": max(0, int(_APPLY_PATCH_DRY_RUN_MAX_DIFF_CHARS_TOTAL)),
        "total_remaining_before_file": rem,
        "reasons": reasons or ["max_chars_per_file"],
    }


def apply_patch(
    patch: str,
    policy: FileToolPolicy,
    *,
    cwd: str | None = ".",
    lenient: bool = True,
    dry_run: bool = False,
    backup: bool = True,
    safeguard_max_lines: int = _EDIT_SAFEGUARD_MAX_LINES,
    safeguard_confirm: bool = False,
) -> Dict[str, Any]:
    patch_text = str(patch or "")
    if not patch_text.strip():
        return {"ok": False, "error": "patch is required"}
    base_dir = resolve_path(cwd or ".", policy)
    if base_dir.exists() and base_dir.is_file():
        base_dir = base_dir.parent
    if not base_dir.exists():
        return {"ok": False, "error": "cwd does not exist"}
    if not base_dir.is_dir():
        return {"ok": False, "error": "cwd is not a directory"}
    hunks = _ap_parse_patch(patch_text, lenient=lenient)
    added: List[str] = []
    modified: List[str] = []
    deleted: List[str] = []
    details: List[Dict[str, Any]] = []
    diff_stats = {"files_changed": 0, "lines_added": 0, "lines_removed": 0}
    diff_total_remaining = max(0, int(_APPLY_PATCH_DRY_RUN_MAX_DIFF_CHARS_TOTAL))
    diff_per_file_cap = max(0, int(_APPLY_PATCH_DRY_RUN_MAX_DIFF_CHARS_PER_FILE))

    def _record_diff(
        detail: Dict[str, Any],
        *,
        before_text: str,
        after_text: str,
        fromfile: str,
        tofile: str,
    ) -> None:
        nonlocal diff_total_remaining
        diff_text = _make_unified_diff(before_text, after_text, fromfile=fromfile, tofile=tofile)
        lines_added, lines_removed = _count_unified_diff_lines(diff_text)
        detail["lines_added"] = lines_added
        detail["lines_removed"] = lines_removed
        if (lines_added > 0) or (lines_removed > 0):
            diff_stats["files_changed"] += 1
            diff_stats["lines_added"] += lines_added
            diff_stats["lines_removed"] += lines_removed
        if dry_run:
            clipped, truncated, truncation_policy = _truncate_diff_for_preview(
                diff_text,
                per_file_cap=diff_per_file_cap,
                total_remaining=diff_total_remaining,
            )
            detail["diff"] = clipped
            if truncated:
                detail["diff_truncated"] = True
                if isinstance(truncation_policy, dict):
                    detail["diff_truncation_policy"] = truncation_policy
            diff_total_remaining = max(0, diff_total_remaining - len(clipped))

    for h in hunks:
        kind = h.get("kind")
        if kind == "add":
            path_s = h.get("path")
            target = _ap_resolve_target(base_dir, path_s, policy)
            contents = h.get("contents", "")
            _ensure_size_limit_bytes(contents, _MAX_EDIT_BYTES)
            lines_after = len(contents.splitlines())
            if (lines_after > safeguard_max_lines) and not safeguard_confirm:
                details.append({
                    "path": str(target),
                    "action": "A",
                    "safeguard_triggered": True,
                    "message": f"Safeguard: resulting file would be {lines_after} lines (> {safeguard_max_lines}). Set safeguard_confirm=true to apply.",
                })
                continue
            if not dry_run:
                target.parent.mkdir(parents=True, exist_ok=True)
                _atomic_write(target, contents, backup=False)
            added.append(str(target))
            detail = {"path": str(target), "action": "A", "dry_run": dry_run}
            _record_diff(detail, before_text="", after_text=contents, fromfile="/dev/null", tofile=str(target))
            details.append(detail)
        elif kind == "delete":
            path_s = h.get("path")
            target = _ap_resolve_target(base_dir, path_s, policy)
            if not target.exists():
                deleted.append(str(target))
                details.append({"path": str(target), "action": "D", "dry_run": dry_run, "note": "did not exist"})
                continue
            if not target.is_file():
                return {"ok": False, "error": "delete target is not a file"}
            _file_size_ok(target, _MAX_EDIT_BYTES)
            before = read_text_auto(target)
            if not dry_run:
                try:
                    target.unlink()
                except Exception as e:
                    return {"ok": False, "error": str(e)}
            deleted.append(str(target))
            detail = {"path": str(target), "action": "D", "dry_run": dry_run}
            _record_diff(detail, before_text=before, after_text="", fromfile=str(target), tofile="/dev/null")
            details.append(detail)
        elif kind == "update":
            path_s = h.get("path")
            move_to = h.get("move_to")
            src = _ap_resolve_target(base_dir, path_s, policy)
            dst = _ap_resolve_target(base_dir, move_to, policy) if move_to else src
            if not src.exists():
                return {"ok": False, "error": f"source file does not exist: {src}"}
            if not src.is_file():
                return {"ok": False, "error": "source is not a file"}
            _file_size_ok(src, _MAX_EDIT_BYTES)
            before = read_text_auto(src)
            original_lines = before.split("\n")
            if original_lines and original_lines[-1] == "":
                original_lines.pop()
            repls = _ap_compute_replacements(original_lines, h.get("chunks") or [], src)
            after_lines = list(original_lines)
            for start_idx, old_len, new_seg in reversed(repls):
                for _ in range(old_len):
                    if 0 <= start_idx < len(after_lines):
                        after_lines.pop(start_idx)
                for offset, s in enumerate(new_seg):
                    after_lines.insert(start_idx + offset, s)
            if not after_lines or after_lines[-1] != "":
                after_lines.append("")
            after = "\n".join(after_lines)
            lines_after = len(after.splitlines())
            if (lines_after > safeguard_max_lines) and not safeguard_confirm:
                details.append({
                    "path": str(dst),
                    "action": "M",
                    "safeguard_triggered": True,
                    "message": f"Safeguard: resulting file would be {lines_after} lines (> {safeguard_max_lines}). Set safeguard_confirm=true to apply.",
                })
                continue
            if not dry_run:
                dst.parent.mkdir(parents=True, exist_ok=True)
                _atomic_write(dst, after, backup=False)
                if dst != src:
                    try:
                        src.unlink()
                    except Exception:
                        pass
            modified.append(str(dst))
            detail = {"path": str(dst), "action": "M", "dry_run": dry_run, "moved": (str(dst) if dst != src else None)}
            _record_diff(detail, before_text=before, after_text=after, fromfile=str(src), tofile=str(dst))
            details.append(detail)
        else:
            return {"ok": False, "error": f"unknown hunk kind '{kind}'"}
    summary = {"added": added, "modified": modified, "deleted": deleted}
    return {"ok": True, "data": {"summary": summary, "details": details, "dry_run": dry_run, "diff_stats": diff_stats}}

# ------------------------- string_replace (fallback) -------------------------#
def _glob_files(base_dir: Path, patterns: List[str], exclude: Optional[List[str]]) -> List[Path]:
    files: List[Path] = []
    seen: Set[Path] = set()
    exc: List[str] = [str(_normalize_and_strip_wrapping_quotes(e)) for e in (exclude or []) if str(e).strip()]
    for pat in patterns or []:
        pat = str(_normalize_and_strip_wrapping_quotes(pat or "")).strip()
        if not pat:
            continue
        for p in base_dir.glob(pat):
            try:
                rp = p.resolve()
            except Exception:
                continue
            if any(rp.match(x) for x in exc):
                continue
            if rp not in seen and rp.is_file():
                seen.add(rp)
                files.append(rp)
    return files


def string_replace(
    pattern: str,
    replacement: str,
    policy: FileToolPolicy,
    *,
    cwd: str | None = ".",
    file_globs: Optional[List[str]] = None,
    exclude_globs: Optional[List[str]] = None,
    is_regex: bool = False,
    expected_total_matches: Optional[int] = None,
    max_replacements_per_file: int = 5,
    max_total_replacements: int = 5,
    dry_run: bool = False,
) -> Dict[str, Any]:
    """
    Minimal, guarded string replacement across files matched by globs.

    Safeguards (intentionally limited):
      - expected_total_matches: abort if planned replacements != expected
      - caps: at most max_replacements_per_file per file, and max_total_replacements overall
      - dry_run: return unified diffs and counts without writing
    """
    pat = str(pattern or "")
    if not pat:
        return {"ok": False, "error": "pattern is required"}
    if file_globs is None or not [g for g in file_globs if str(g).strip()]:
        return {"ok": False, "error": "file_globs is required (non-empty)"}

    base_dir = resolve_path(cwd or ".", policy)
    if base_dir.exists() and base_dir.is_file():
        base_dir = base_dir.parent
    if not base_dir.exists() or not base_dir.is_dir():
        return {"ok": False, "error": "cwd does not exist or is not a directory"}

    # Compile matcher
    try:
        if is_regex:
            rx = re.compile(pat)
        else:
            rx = re.compile(re.escape(pat))
    except re.error as e:
        return {"ok": False, "error": f"invalid regex: {e}"}

    targets = _glob_files(base_dir, [str(g) for g in file_globs], [str(e) for e in (exclude_globs or [])])
    if not targets:
        return {"ok": False, "error": "no files matched globs"}

    total_planned = 0
    total_targets = 0
    details: List[Dict[str, Any]] = []
    changed_files = 0
    write_ops: List[Tuple[Path, str]] = []

    for fp in targets:
        # Enforce policy: path must lie within allowed roots, ext allowlist, size limits
        try:
            # Re-resolve via _ap_resolve_target-like checks by going through resolve_path on relative
            # Compute a path relative to base_dir for verify then back to absolute
            rel = fp.relative_to(base_dir)
            p = _ap_resolve_target(base_dir, str(rel), policy)
        except Exception as e:
            details.append({"path": str(fp), "skipped": True, "reason": str(e)})
            continue
        _file_size_ok(p, policy.max_bytes)

        before = read_text_auto(p)
        matches = list(rx.finditer(before))
        if not matches:
            details.append({"path": str(p), "replacements": 0, "targets": 0, "changed": False})
            continue
        # Count all potential targets in this file (prior to caps)
        total_targets += len(matches)
        # Determine how many we can take in this file without exceeding caps
        remaining_global = max(0, int(max_total_replacements) - total_planned)
        if remaining_global <= 0:
            break
        per_file_cap = int(max_replacements_per_file)
        per_file = min(len(matches), per_file_cap, remaining_global)
        if per_file <= 0:
            details.append({"path": str(p), "replacements": 0, "targets": len(matches), "changed": False, "note": "per-file cap is 0"})
            continue
        # Perform only up to per_file replacements, capturing before/after examples for the ones we applied
        # Build the 'after' string manually so we can compute example pairs accurately
        pieces: List[str] = []
        last_end = 0
        did = 0
        examples: List[Dict[str, str]] = []
        for i, m in enumerate(matches):
            if i >= per_file:
                break
            pieces.append(before[last_end:m.start()])
            try:
                rep = m.expand(replacement)
            except Exception:
                # Fallback: use literal replacement if expansion fails
                rep = replacement
            pieces.append(rep)
            last_end = m.end()
            did += 1
            # Record example mapping for this replacement
            try:
                examples.append({"from": m.group(0), "to": rep})
            except Exception:
                pass
        pieces.append(before[last_end:])
        after = "".join(pieces)
        total_planned += did
        if did > 0:
            changed_files += 1
            diff = "\n".join(
                difflib.unified_diff(
                    before.splitlines(), after.splitlines(),
                    fromfile=str(p), tofile=str(p), lineterm=""
                )
            )
            details.append({
                "path": str(p),
                "replacements": did,
                "targets": len(matches),
                "changed": True,
                "examples": examples,  # caller may ignore when not needed
                "diff": diff if dry_run else None,
            })
            write_ops.append((p, after))
        else:
            details.append({"path": str(p), "replacements": 0, "targets": len(matches), "changed": False})

        # Enforce overall cap
        if total_planned >= int(max_total_replacements):
            break

    if expected_total_matches is not None and int(expected_total_matches) != int(total_planned):
        return {
            "ok": False,
            "error": f"expected_total_matches {expected_total_matches} did not match planned replacements {total_planned}",
            "data": {"summary": {"files_considered": len(targets), "files_changed": changed_files, "total_replacements": total_planned}, "details": details}
        }

    if dry_run:
        return {
            "ok": True,
            "data": {
                "summary": {"files_considered": len(targets), "files_changed": changed_files, "total_replacements": total_planned, "total_targets": total_targets},
                "details": details,
                "dry_run": True,
            },
        }

    # Write changes
    for p, after in write_ops:
        _ensure_size_limit_bytes(after, policy.max_bytes)
        _atomic_write(p, after, backup=False)

    return {
        "ok": True,
        "data": {
            "summary": {"files_considered": len(targets), "files_changed": changed_files, "total_replacements": total_planned, "total_targets": total_targets},
            "details": [{k: v for k, v in d.items() if k != "diff"} for d in details],
            "dry_run": False,
        },
    }
