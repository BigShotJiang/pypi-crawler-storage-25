from __future__ import annotations

from typing import List, Optional

from ..access_profiles import ModelCapabilityInfo, ProfileReadinessStatus


class BackendHenosisAdapter:
    profile_id = "backend:henosis"

    def list_available_models(self) -> List[ModelCapabilityInfo]:
        return []

    def supports_model(self, model_id: str) -> bool:
        return True

    def get_model_capabilities(self, model_id: str) -> Optional[ModelCapabilityInfo]:
        if not isinstance(model_id, str) or not model_id.strip():
            return None
        return ModelCapabilityInfo(model_id=model_id.strip(), provider_family="openai")

    def get_readiness_status(self) -> ProfileReadinessStatus:
        return ProfileReadinessStatus(
            state="ready",
            ready=True,
            installed=True,
            authenticated=True,
            subscription_usable=True,
            model_available=True,
            detail="Henosis backend is available when backend auth is configured.",
        )

    def execute_turn(self, *, model_id: str, prompt: str, cwd: Optional[str] = None):
        return {
            "ok": False,
            "error": "backend:henosis execution is handled by the normal Henosis SSE path, not via adapter subprocess execution.",
            "model": model_id,
            "usage": {},
            "text": "",
            "billing_source": "backend_henosis",
        }
