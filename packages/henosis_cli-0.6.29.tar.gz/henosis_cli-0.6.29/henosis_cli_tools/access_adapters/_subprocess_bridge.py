from __future__ import annotations

import json
import os
import shlex
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional


def _split_models_csv(raw: str) -> List[str]:
    out: List[str] = []
    seen = set()
    for item in str(raw or "").replace("\n", ",").split(","):
        mid = str(item or "").strip()
        if not mid or mid in seen:
            continue
        seen.add(mid)
        out.append(mid)
    return out


def _run_command(
    command: List[str],
    *,
    prompt: str,
    cwd: Optional[str],
    env: Optional[Dict[str, str]] = None,
    timeout_sec: float = 120.0,
) -> Dict[str, Any]:
    try:
        completed = subprocess.run(
            command,
            input=str(prompt or ""),
            text=True,
            capture_output=True,
            cwd=(str(Path(cwd).resolve()) if cwd else None),
            env=env,
            timeout=max(1.0, float(timeout_sec or 120.0)),
            check=False,
        )
    except FileNotFoundError as exc:
        return {"ok": False, "error": f"command not found: {exc}"}
    except subprocess.TimeoutExpired as exc:
        return {"ok": False, "error": f"command timed out after {timeout_sec}s", "stdout": exc.stdout, "stderr": exc.stderr}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    return {
        "ok": completed.returncode == 0,
        "returncode": int(completed.returncode),
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }


def _prepare_command(template: str, *, model_id: str, cwd: Optional[str]) -> List[str]:
    rendered = str(template or "").format(model=model_id, cwd=(cwd or ""))
    return shlex.split(rendered, posix=(os.name != "nt"))


def _parse_execution_output(
    raw: Dict[str, Any],
    *,
    model_id: str,
    billing_source: str,
) -> Dict[str, Any]:
    if not raw.get("ok"):
        return {
            "ok": False,
            "error": str(raw.get("error") or raw.get("stderr") or raw.get("stdout") or "subscription command failed"),
            "billing_source": billing_source,
        }
    stdout = str(raw.get("stdout") or "")
    stderr = str(raw.get("stderr") or "")
    try:
        parsed = json.loads(stdout)
    except Exception:
        parsed = None
    if isinstance(parsed, dict):
        text = str(parsed.get("text") or parsed.get("content") or parsed.get("output") or "")
        usage = parsed.get("usage") if isinstance(parsed.get("usage"), dict) else {}
        model_used = str(parsed.get("model") or model_id)
        return {
            "ok": True,
            "text": text,
            "usage": usage,
            "model": model_used,
            "billing_source": billing_source,
            "raw": parsed,
            "stderr": stderr,
        }
    return {
        "ok": True,
        "text": stdout.strip(),
        "usage": {},
        "model": model_id,
        "billing_source": billing_source,
        "raw": {"stdout": stdout, "stderr": stderr},
    }
