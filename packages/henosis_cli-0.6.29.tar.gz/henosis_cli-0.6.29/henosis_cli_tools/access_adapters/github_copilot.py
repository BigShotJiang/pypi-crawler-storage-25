from __future__ import annotations

import os
import shutil
import subprocess
from typing import List, Optional

from ..access_profiles import ModelCapabilityInfo, ProfileReadinessStatus
from ._subprocess_bridge import _parse_execution_output, _prepare_command, _run_command, _split_models_csv


class GitHubCopilotAdapter:
    profile_id = "sub:github_copilot"
    billing_source = "sub_github_copilot"
    _fallback_models = [
        "gpt-5.4",
        "gpt-5",
        "claude-sonnet-4-6",
        "gemini-3.1-pro-preview",
    ]

    def _copilot_binary(self) -> Optional[str]:
        try:
            return shutil.which("copilot")
        except Exception:
            return None

    def _exec_template(self) -> Optional[str]:
        raw = os.getenv("HENOSIS_GITHUB_COPILOT_EXEC", "").strip()
        return raw or None

    def _discover_models_from_env(self) -> List[str]:
        return _split_models_csv(os.getenv("HENOSIS_GITHUB_COPILOT_MODELS", ""))

    def _discover_models_from_cli(self) -> List[str]:
        binary = self._copilot_binary()
        if not binary:
            return []
        try:
            completed = subprocess.run(
                [binary, "help"],
                text=True,
                capture_output=True,
                timeout=10.0,
                check=False,
            )
            haystack = "\n".join([completed.stdout or "", completed.stderr or ""])
        except Exception:
            return []
        discovered: List[str] = []
        seen = set()
        for model_id in self._fallback_models:
            if model_id in haystack and model_id not in seen:
                seen.add(model_id)
                discovered.append(model_id)
        return discovered

    def list_available_models(self) -> List[ModelCapabilityInfo]:
        models = self._discover_models_from_env()
        if not models:
            models = self._discover_models_from_cli()
        if not models:
            models = list(self._fallback_models)
        infos: List[ModelCapabilityInfo] = []
        for model_id in models:
            mid = str(model_id or "").strip()
            if not mid:
                continue
            provider = "openai"
            if mid.startswith("claude-"):
                provider = "anthropic"
            elif mid.startswith("gemini-"):
                provider = "gemini"
            infos.append(
                ModelCapabilityInfo(
                    model_id=mid,
                    provider_family=provider,
                    supports_tools=True,
                    supports_streaming=False,
                )
            )
        return infos

    def supports_model(self, model_id: str) -> bool:
        try:
            target = str(model_id or "").strip()
        except Exception:
            return False
        return any(m.model_id == target for m in self.list_available_models())

    def get_model_capabilities(self, model_id: str) -> Optional[ModelCapabilityInfo]:
        for item in self.list_available_models():
            if item.model_id == model_id:
                return item
        return None

    def get_readiness_status(self) -> ProfileReadinessStatus:
        binary = self._copilot_binary()
        exec_template = self._exec_template()
        if not binary and not exec_template:
            return ProfileReadinessStatus(
                state="not_installed",
                ready=False,
                installed=False,
                authenticated=None,
                subscription_usable=None,
                model_available=None,
                detail="GitHub Copilot CLI was not found on PATH, and no execution template override is configured.",
                metadata={"binary": None, "exec_template": None},
            )
        if not exec_template:
            return ProfileReadinessStatus(
                state="misconfigured",
                ready=False,
                installed=bool(binary),
                authenticated=None,
                subscription_usable=None,
                model_available=None,
                detail="GitHub Copilot bridge is installed/discoverable, but HENOSIS_GITHUB_COPILOT_EXEC is not set for local execution yet.",
                metadata={"binary": binary, "exec_template": None, "discovery": "runtime-first"},
            )
        return ProfileReadinessStatus(
            state="ready",
            ready=True,
            installed=bool(binary) or bool(exec_template),
            authenticated=None,
            subscription_usable=None,
            model_available=None,
            detail="GitHub Copilot local subprocess bridge is configured.",
            metadata={"binary": binary, "exec_template": exec_template, "discovery": "runtime-first"},
        )

    def execute_turn(self, *, model_id: str, prompt: str, cwd: Optional[str] = None):
        template = self._exec_template()
        if not template:
            return {
                "ok": False,
                "error": "GitHub Copilot execution is not configured. Set HENOSIS_GITHUB_COPILOT_EXEC.",
                "model": model_id,
                "usage": {},
                "text": "",
                "billing_source": self.billing_source,
            }
        command = _prepare_command(template, model_id=model_id, cwd=cwd)
        raw = _run_command(command, prompt=prompt, cwd=cwd, timeout_sec=120.0)
        return _parse_execution_output(raw, model_id=model_id, billing_source=self.billing_source)
