from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from .access_profiles import AccessProfile, ProfileCapabilities
from .access_profiles import ExecutionAdapter, ProfileReadinessStatus
from .access_adapters import (
    BackendHenosisAdapter,
    CodexOAuthAdapter,
    DroidAdapter,
    GitHubCopilotAdapter,
)

PROVIDER_ORDER: List[str] = [
    "openai",
    "anthropic",
    "gemini",
    "xai",
    "deepseek",
    "kimi",
    "glm",
]

PROVIDER_DISPLAY_NAMES: Dict[str, str] = {
    "openai": "OpenAI",
    "anthropic": "Anthropic",
    "gemini": "Gemini",
    "xai": "xAI",
    "deepseek": "DeepSeek",
    "kimi": "Kimi",
    "glm": "GLM",
}

AUTH_MODE_BACKEND = "backend"
AUTH_MODE_CODEX = "codex_oauth"
AUTH_MODE_BYOK = "byok"
AUTH_MODE_GITHUB_SUB = "github_copilot_sub"
AUTH_MODE_DROID_SUB = "droid_sub"

AUTH_MODE_LABELS: Dict[str, str] = {
    AUTH_MODE_BACKEND: "Henosis backend",
    AUTH_MODE_CODEX: "Codex OAuth",
    AUTH_MODE_BYOK: "BYOK",
    AUTH_MODE_GITHUB_SUB: "GitHub subscription",
    AUTH_MODE_DROID_SUB: "Droid subscription",
}

PROFILE_ID_BACKEND = "backend:henosis"
PROFILE_ID_CODEX = "oauth:codex"
PROFILE_ID_GITHUB_SUB = "sub:github_copilot"
PROFILE_ID_DROID_SUB = "sub:droid"


def experimental_subscription_routes_enabled() -> bool:
    try:
        raw = str(os.getenv("HENOSIS_ENABLE_EXPERIMENTAL_SUB_ROUTES", "") or "").strip().lower()
    except Exception:
        raw = ""
    return raw in {"1", "true", "yes", "on"}


def byok_profile_id_for_provider(provider: Any) -> str:
    return f"byok:{normalize_provider(provider)}"


def default_profile_id_for_mode(mode: Any, provider: Any) -> str:
    normalized_mode = normalize_auth_mode(mode, provider)
    provider_norm = normalize_provider(provider)
    if normalized_mode == AUTH_MODE_CODEX:
        return PROFILE_ID_CODEX
    if normalized_mode == AUTH_MODE_GITHUB_SUB:
        return PROFILE_ID_GITHUB_SUB
    if normalized_mode == AUTH_MODE_DROID_SUB:
        return PROFILE_ID_DROID_SUB
    if normalized_mode == AUTH_MODE_BYOK:
        return byok_profile_id_for_provider(provider_norm)
    return PROFILE_ID_BACKEND


def default_access_profile_for_mode(mode: Any, provider: Any) -> AccessProfile:
    normalized_mode = normalize_auth_mode(mode, provider) or AUTH_MODE_BACKEND
    provider_norm = normalize_provider(provider)
    if normalized_mode == AUTH_MODE_CODEX:
        return AccessProfile(
            profile_id=PROFILE_ID_CODEX,
            kind="oauth",
            display_name="Codex OAuth",
            provider_families_supported=["openai"],
            billing_source="oauth_codex",
            execution_backend="local_http",
            capabilities=ProfileCapabilities(
                supports_streaming=True,
                supports_tool_calling=True,
                supports_context_handoff=True,
                supports_model_discovery=False,
            ),
        )
    if normalized_mode == AUTH_MODE_GITHUB_SUB:
        return AccessProfile(
            profile_id=PROFILE_ID_GITHUB_SUB,
            kind="subscription",
            display_name="GitHub Copilot subscription",
            provider_families_supported=["openai", "anthropic", "gemini"],
            billing_source="sub_github_copilot",
            execution_backend="local_acp",
            capabilities=ProfileCapabilities(
                supports_streaming=False,
                supports_tool_calling=False,
                supports_context_handoff=False,
                supports_model_discovery=True,
                supports_acp=True,
                supports_subprocess_exec=True,
            ),
        )
    if normalized_mode == AUTH_MODE_DROID_SUB:
        return AccessProfile(
            profile_id=PROFILE_ID_DROID_SUB,
            kind="subscription",
            display_name="Droid subscription",
            provider_families_supported=["openai", "anthropic", "gemini", "xai", "deepseek", "kimi", "glm"],
            billing_source="sub_droid",
            execution_backend="local_jsonrpc",
            capabilities=ProfileCapabilities(
                supports_streaming=False,
                supports_tool_calling=False,
                supports_context_handoff=False,
                supports_model_discovery=True,
                supports_acp=True,
                supports_jsonrpc=True,
                supports_subprocess_exec=True,
            ),
        )
    if normalized_mode == AUTH_MODE_BYOK:
        return AccessProfile(
            profile_id=byok_profile_id_for_provider(provider_norm),
            kind="byok",
            display_name=f"{provider_display_name(provider_norm)} BYOK",
            provider_families_supported=[provider_norm],
            billing_source=f"byok_{provider_norm}",
            execution_backend="local_http",
            capabilities=ProfileCapabilities(
                supports_streaming=True,
                supports_tool_calling=True,
                supports_context_handoff=False,
                supports_model_discovery=False,
            ),
        )
    return AccessProfile(
        profile_id=PROFILE_ID_BACKEND,
        kind="backend",
        display_name="Henosis backend",
        provider_families_supported=PROVIDER_ORDER[:],
        billing_source="backend_henosis",
        execution_backend="backend_sse",
        capabilities=ProfileCapabilities(
            supports_streaming=True,
            supports_tool_calling=True,
            supports_context_handoff=True,
            supports_remote_control_inference=True,
            supports_model_discovery=True,
        ),
    )


def normalize_provider(provider: Any) -> str:
    try:
        s = str(provider or "").strip().lower()
    except Exception:
        s = ""
    return s if s in PROVIDER_ORDER else "openai"


def provider_display_name(provider: Any) -> str:
    p = normalize_provider(provider)
    return PROVIDER_DISPLAY_NAMES.get(p, p.title() or "Unknown")


def normalize_model_id(model: Any) -> str:
    try:
        return str(model or "").strip().lower()
    except Exception:
        return ""


def provider_from_model(model: Any) -> str:
    m = normalize_model_id(model)
    if not m:
        return "openai"
    if m.startswith("claude-"):
        return "anthropic"
    if m.startswith("gemini-"):
        return "gemini"
    if m.startswith("grok-"):
        return "xai"
    if m.startswith("deepseek-"):
        return "deepseek"
    if m.startswith("kimi-"):
        return "kimi"
    if m.startswith("glm-"):
        return "glm"
    return "openai"


def available_auth_modes_for_provider(provider: Any) -> List[str]:
    p = normalize_provider(provider)
    experimental_subs = experimental_subscription_routes_enabled()
    if p == "openai":
        modes = [AUTH_MODE_BACKEND, AUTH_MODE_CODEX, AUTH_MODE_BYOK]
        if experimental_subs:
            modes.extend([AUTH_MODE_GITHUB_SUB, AUTH_MODE_DROID_SUB])
        return modes
    if p in {"anthropic", "gemini"}:
        modes = [AUTH_MODE_BACKEND, AUTH_MODE_BYOK]
        if experimental_subs:
            modes.extend([AUTH_MODE_GITHUB_SUB, AUTH_MODE_DROID_SUB])
        return modes
    modes = [AUTH_MODE_BACKEND, AUTH_MODE_BYOK]
    if experimental_subs:
        modes.append(AUTH_MODE_DROID_SUB)
    return modes


def normalize_auth_mode(value: Any, provider: Any) -> Optional[str]:
    try:
        s = str(value or "").strip().lower()
    except Exception:
        return None
    if not s:
        return None
    aliases = {
        "backend": AUTH_MODE_BACKEND,
        "henosis": AUTH_MODE_BACKEND,
        "henosis_backend": AUTH_MODE_BACKEND,
        "backend_henosis": AUTH_MODE_BACKEND,
        "codex": AUTH_MODE_CODEX,
        "codex_oauth": AUTH_MODE_CODEX,
        "oauth_codex": AUTH_MODE_CODEX,
        "byok": AUTH_MODE_BYOK,
        "api_key": AUTH_MODE_BYOK,
        "provider_key": AUTH_MODE_BYOK,
        "github": AUTH_MODE_GITHUB_SUB,
        "github_copilot": AUTH_MODE_GITHUB_SUB,
        "github_copilot_sub": AUTH_MODE_GITHUB_SUB,
        "sub_github_copilot": AUTH_MODE_GITHUB_SUB,
        "copilot": AUTH_MODE_GITHUB_SUB,
        "droid": AUTH_MODE_DROID_SUB,
        "droid_sub": AUTH_MODE_DROID_SUB,
        "sub_droid": AUTH_MODE_DROID_SUB,
    }
    mode = aliases.get(s)
    if mode not in available_auth_modes_for_provider(provider):
        return None
    return mode


def mask_secret(value: Any) -> str:
    try:
        s = str(value or "")
    except Exception:
        s = ""
    if not s:
        return "(missing)"
    if len(s) <= 8:
        return "*" * len(s)
    return f"{s[:4]}...{s[-4:]}"


class AccessHub:
    def __init__(self, *, routes_path: Path, keys_path: Path) -> None:
        self.routes_path = Path(routes_path).expanduser()
        self.keys_path = Path(keys_path).expanduser()
        self.provider_defaults: Dict[str, str] = {}
        self.model_overrides: Dict[str, str] = {}
        self.provider_keys: Dict[str, str] = {}
        self._adapter_registry: Dict[str, ExecutionAdapter] = self._build_adapter_registry()
        self.load()

    def _build_adapter_registry(self) -> Dict[str, ExecutionAdapter]:
        registry: Dict[str, ExecutionAdapter] = {}
        for adapter in (
            BackendHenosisAdapter(),
            CodexOAuthAdapter(),
            GitHubCopilotAdapter(),
            DroidAdapter(),
        ):
            try:
                profile_id = str(getattr(adapter, "profile_id", "") or "").strip()
            except Exception:
                profile_id = ""
            if profile_id:
                registry[profile_id] = adapter
        return registry

    def _load_json(self, path: Path) -> Dict[str, Any]:
        try:
            if not path.exists():
                return {}
            raw = json.loads(path.read_text(encoding="utf-8"))
            return raw if isinstance(raw, dict) else {}
        except Exception:
            return {}

    def _write_json_private(self, path: Path, payload: Dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass

    def load(self) -> None:
        routes = self._load_json(self.routes_path)
        keys = self._load_json(self.keys_path)

        provider_defaults: Dict[str, str] = {}
        try:
            raw_defaults = routes.get("provider_defaults") if isinstance(routes, dict) else {}
            if isinstance(raw_defaults, dict):
                for provider, value in raw_defaults.items():
                    p = normalize_provider(provider)
                    mode = normalize_auth_mode(value, p)
                    if mode:
                        provider_defaults[p] = mode
        except Exception:
            provider_defaults = {}
        self.provider_defaults = provider_defaults

        model_overrides: Dict[str, str] = {}
        try:
            raw_overrides = routes.get("model_overrides") if isinstance(routes, dict) else {}
            if isinstance(raw_overrides, dict):
                for model, value in raw_overrides.items():
                    model_key = normalize_model_id(model)
                    if not model_key:
                        continue
                    provider = provider_from_model(model_key)
                    mode = normalize_auth_mode(value, provider)
                    if mode:
                        model_overrides[model_key] = mode
        except Exception:
            model_overrides = {}
        self.model_overrides = model_overrides

        provider_keys: Dict[str, str] = {}
        try:
            raw_keys = keys.get("provider_keys") if isinstance(keys, dict) else {}
            if isinstance(raw_keys, dict):
                for provider, value in raw_keys.items():
                    p = normalize_provider(provider)
                    try:
                        secret = str(value or "").strip()
                    except Exception:
                        secret = ""
                    if secret:
                        provider_keys[p] = secret
        except Exception:
            provider_keys = {}
        self.provider_keys = provider_keys

    def save_routes(self) -> None:
        payload = {
            "version": 1,
            "provider_defaults": dict(sorted(self.provider_defaults.items())),
            "model_overrides": dict(sorted(self.model_overrides.items())),
        }
        self._write_json_private(self.routes_path, payload)

    def save_keys(self) -> None:
        payload = {
            "version": 1,
            "provider_keys": dict(sorted(self.provider_keys.items())),
        }
        self._write_json_private(self.keys_path, payload)

    def has_provider_key(self, provider: Any) -> bool:
        p = normalize_provider(provider)
        return bool(self.provider_keys.get(p))

    def get_provider_key(self, provider: Any) -> Optional[str]:
        p = normalize_provider(provider)
        value = self.provider_keys.get(p)
        if isinstance(value, str) and value.strip():
            return value.strip()
        return None

    def masked_provider_key(self, provider: Any) -> str:
        return mask_secret(self.get_provider_key(provider))

    def set_provider_key(self, provider: Any, value: Any) -> bool:
        p = normalize_provider(provider)
        try:
            secret = str(value or "").strip()
        except Exception:
            secret = ""
        if not secret:
            return False
        self.provider_keys[p] = secret
        self.save_keys()
        return True

    def clear_provider_key(self, provider: Any) -> None:
        p = normalize_provider(provider)
        self.provider_keys.pop(p, None)
        self.save_keys()

    def set_provider_default(self, provider: Any, mode: Any) -> bool:
        p = normalize_provider(provider)
        normalized = normalize_auth_mode(mode, p)
        if not normalized:
            return False
        self.provider_defaults[p] = normalized
        self.save_routes()
        return True

    def clear_provider_default(self, provider: Any) -> None:
        p = normalize_provider(provider)
        self.provider_defaults.pop(p, None)
        self.save_routes()

    def set_model_override(self, model: Any, mode: Any) -> bool:
        model_key = normalize_model_id(model)
        if not model_key:
            return False
        provider = provider_from_model(model_key)
        normalized = normalize_auth_mode(mode, provider)
        if not normalized:
            return False
        self.model_overrides[model_key] = normalized
        self.save_routes()
        return True

    def clear_model_override(self, model: Any) -> None:
        model_key = normalize_model_id(model)
        if not model_key:
            return
        self.model_overrides.pop(model_key, None)
        self.save_routes()

    def count_model_overrides(self) -> int:
        return int(len(self.model_overrides))

    def subscription_routes_visible(self) -> bool:
        return bool(experimental_subscription_routes_enabled())

    def describe_provider(self, provider: Any, *, codex_ready: bool = False) -> Dict[str, Any]:
        p = normalize_provider(provider)
        default_mode = normalize_auth_mode(self.provider_defaults.get(p), p)
        available_modes = available_auth_modes_for_provider(p)
        byok_profile = self.get_default_profile_for_mode(AUTH_MODE_BYOK, p)
        info: Dict[str, Any] = {
            "provider": p,
            "provider_label": provider_display_name(p),
            "available_modes": list(available_modes),
            "default_mode": default_mode,
            "default_mode_label": AUTH_MODE_LABELS.get(default_mode or "", "Follow model / legacy default") if default_mode else "Follow model / legacy default",
            "byok_key_present": self.has_provider_key(p),
            "byok_key_masked": self.masked_provider_key(p),
            "codex_ready": bool(codex_ready) if p == "openai" else False,
            "byok_profile_id": byok_profile.profile_id,
            "byok_billing_source": byok_profile.billing_source,
        }
        return info

    def get_default_profile_for_mode(self, mode: Any, provider: Any) -> AccessProfile:
        return default_access_profile_for_mode(mode, provider)

    def get_execution_adapter(self, profile_id: Any) -> Optional[ExecutionAdapter]:
        try:
            key = str(profile_id or "").strip()
        except Exception:
            key = ""
        if not key:
            return None
        return self._adapter_registry.get(key)

    def list_known_profiles(self) -> List[AccessProfile]:
        return [
            default_access_profile_for_mode(AUTH_MODE_BACKEND, "openai"),
            default_access_profile_for_mode(AUTH_MODE_CODEX, "openai"),
            default_access_profile_for_mode(AUTH_MODE_BYOK, "openai"),
            default_access_profile_for_mode(AUTH_MODE_BYOK, "anthropic"),
            AccessProfile(
                profile_id="sub:github_copilot",
                kind="subscription",
                display_name="GitHub Copilot subscription",
                provider_families_supported=["openai", "anthropic", "gemini"],
                billing_source="sub_github_copilot",
                execution_backend="local_acp",
                capabilities=ProfileCapabilities(
                    supports_streaming=True,
                    supports_tool_calling=True,
                    supports_model_discovery=True,
                    supports_acp=True,
                    supports_subprocess_exec=True,
                ),
            ),
            AccessProfile(
                profile_id="sub:droid",
                kind="subscription",
                display_name="Droid subscription",
                provider_families_supported=["openai", "anthropic", "gemini", "xai", "deepseek", "kimi", "glm"],
                billing_source="sub_droid",
                execution_backend="local_jsonrpc",
                capabilities=ProfileCapabilities(
                    supports_streaming=True,
                    supports_tool_calling=True,
                    supports_model_discovery=True,
                    supports_acp=True,
                    supports_jsonrpc=True,
                    supports_subprocess_exec=True,
                ),
            ),
        ]

    def get_profile_readiness(self, profile_id: Any) -> ProfileReadinessStatus:
        adapter = self.get_execution_adapter(profile_id)
        if adapter is None:
            return ProfileReadinessStatus(
                state="unsupported",
                ready=False,
                detail=f"No execution adapter is registered for profile '{profile_id}'.",
            )
        try:
            return adapter.get_readiness_status()
        except Exception as exc:
            return ProfileReadinessStatus(
                state="unknown",
                ready=False,
                detail=f"Adapter readiness lookup failed: {exc}",
            )

    def mode_supported_for_model(self, mode: Any, model: Any) -> bool:
        model_key = normalize_model_id(model)
        provider = provider_from_model(model_key)
        normalized_mode = normalize_auth_mode(mode, provider)
        if normalized_mode is None:
            return False
        if normalized_mode in {AUTH_MODE_BACKEND, AUTH_MODE_BYOK}:
            return True
        if normalized_mode == AUTH_MODE_CODEX:
            return provider == "openai"
        profile_id = default_profile_id_for_mode(normalized_mode, provider)
        adapter = self.get_execution_adapter(profile_id)
        if adapter is None:
            return False
        try:
            return bool(adapter.supports_model(model_key))
        except Exception:
            return False

    def available_auth_modes_for_model(self, model: Any) -> List[str]:
        model_key = normalize_model_id(model)
        provider = provider_from_model(model_key)
        modes: List[str] = []
        for mode in available_auth_modes_for_provider(provider):
            if self.mode_supported_for_model(mode, model_key):
                modes.append(mode)
        return modes

    def describe_model_access(
        self,
        model: Any,
        *,
        codex_available_for_model: bool = False,
    ) -> Dict[str, Any]:
        model_key = normalize_model_id(model)
        provider = provider_from_model(model_key)
        model_override = normalize_auth_mode(self.model_overrides.get(model_key), provider)
        provider_default = normalize_auth_mode(self.provider_defaults.get(provider), provider)

        source = "default_backend"
        mode = AUTH_MODE_BACKEND
        if model_override:
            mode = model_override
            source = "model_override"
        elif provider_default:
            mode = provider_default
            source = "provider_default"
        elif provider == "openai" and bool(codex_available_for_model):
            mode = AUTH_MODE_CODEX
            source = "legacy_codex"

        ready = True
        detail = AUTH_MODE_LABELS.get(mode, mode)
        if mode == AUTH_MODE_CODEX:
            ready = bool(codex_available_for_model)
            detail = "Codex OAuth ready" if ready else "Codex OAuth not available"
        elif mode == AUTH_MODE_BYOK:
            ready = self.has_provider_key(provider)
            detail = (
                f"BYOK key set ({self.masked_provider_key(provider)})"
                if ready
                else "BYOK key missing"
            )
        elif mode == AUTH_MODE_BACKEND:
            ready = True
            detail = "Henosis backend billing"
        elif mode in (AUTH_MODE_GITHUB_SUB, AUTH_MODE_DROID_SUB):
            readiness = self.get_profile_readiness(default_profile_id_for_mode(mode, provider))
            try:
                model_supported = self.mode_supported_for_model(mode, model_key)
            except Exception:
                model_supported = False
            ready = bool(readiness.ready) and bool(model_supported)
            detail = readiness.detail or AUTH_MODE_LABELS.get(mode, mode)
            if readiness.ready and not model_supported:
                detail = f"{AUTH_MODE_LABELS.get(mode, mode)} does not support model {model_key}"

        if mode == AUTH_MODE_BACKEND:
            badge = "HENOSIS"
        elif mode == AUTH_MODE_CODEX:
            badge = "CODEX" if ready else "CODEX LOGIN"
        elif mode == AUTH_MODE_BYOK:
            badge = "BYOK" if ready else "BYOK MISSING"
        elif mode == AUTH_MODE_GITHUB_SUB:
            badge = "GITHUB SUB" if ready else "GITHUB SUB SETUP"
        elif mode == AUTH_MODE_DROID_SUB:
            badge = "DROID SUB" if ready else "DROID SUB SETUP"
        else:
            badge = str(mode).upper()

        readiness = self.get_profile_readiness(default_profile_id_for_mode(mode, provider))

        return {
            "model": model_key,
            "provider": provider,
            "provider_label": provider_display_name(provider),
            "mode": mode,
            "profile_id": default_profile_id_for_mode(mode, provider),
            "profile": self.get_default_profile_for_mode(mode, provider),
            "profile_readiness": readiness,
            "mode_label": AUTH_MODE_LABELS.get(mode, mode),
            "source": source,
            "ready": bool(ready),
            "detail": detail,
            "badge": badge,
            "model_override": model_override,
            "provider_default": provider_default,
            "available_modes": list(available_auth_modes_for_provider(provider)),
            "byok_key_present": self.has_provider_key(provider),
            "byok_key_masked": self.masked_provider_key(provider),
            "codex_available_for_model": bool(codex_available_for_model),
        }
