from __future__ import annotations

import ipaddress
import json
import os
import socket
import threading
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import urlparse

_BROWSER_REF_ATTR = "data-henosis-ref"
_BROWSER_SAFE_SCHEMES = {"http", "https"}
_BROWSER_PASSIVE_SCHEMES = {"about", "data", "blob"}
BROWSER_TOOL_NAMES = {
    "browser_session",
    "browser_tabs",
    "browser_navigate",
    "browser_snapshot",
    "browser_act",
    "browser_wait",
}


def _env_bool(name: str, default: bool) -> bool:
    try:
        raw = os.getenv(name)
        if raw is None:
            return bool(default)
        val = str(raw).strip().lower()
        if val in {"1", "true", "yes", "on"}:
            return True
        if val in {"0", "false", "no", "off"}:
            return False
    except Exception:
        pass
    return bool(default)


def _env_int(name: str, default: int) -> int:
    try:
        raw = os.getenv(name)
        if raw is None or not str(raw).strip():
            return int(default)
        return int(str(raw).strip())
    except Exception:
        return int(default)


def _browser_headless() -> bool:
    return _env_bool("HENOSIS_BROWSER_HEADLESS", True)


def _browser_enable_downloads() -> bool:
    return _env_bool("HENOSIS_BROWSER_ENABLE_DOWNLOADS", False)


def _browser_nav_timeout_ms() -> int:
    return _env_int("HENOSIS_BROWSER_NAV_TIMEOUT_MS", 30_000)


def _browser_action_timeout_ms() -> int:
    return _env_int("HENOSIS_BROWSER_ACTION_TIMEOUT_MS", 15_000)


def _browser_idle_ttl_sec() -> int:
    return _env_int("HENOSIS_BROWSER_IDLE_TTL_SEC", 1_800)


def _browser_max_tabs() -> int:
    return _env_int("HENOSIS_BROWSER_MAX_TABS", 5)


def _browser_snapshot_max_items() -> int:
    return _env_int("HENOSIS_BROWSER_SNAPSHOT_MAX_ITEMS", 200)


def _browser_snapshot_max_chars() -> int:
    return _env_int("HENOSIS_BROWSER_SNAPSHOT_MAX_CHARS", 12_000)


def _browser_block_private_nets() -> bool:
    return _env_bool("HENOSIS_BROWSER_BLOCK_PRIVATE_NETS", True)


def _browser_allowed_domains_env() -> str:
    try:
        return str(os.getenv("HENOSIS_BROWSER_ALLOWED_DOMAINS", "") or "")
    except Exception:
        return ""


@dataclass
class BrowserSnapshotRecord:
    snapshot_id: str
    tab_id: str
    url: str
    title: str
    items: List[Dict[str, Any]]
    text: str
    created_at: float = field(default_factory=time.time)


@dataclass
class BrowserSessionState:
    session_key: str
    context: Any
    tabs: Dict[str, Any]
    active_tab_id: Optional[str]
    snapshots: Dict[str, BrowserSnapshotRecord] = field(default_factory=dict)
    last_used_at: float = field(default_factory=time.time)
    created_at: float = field(default_factory=time.time)
    allowed_domains: Tuple[str, ...] = field(default_factory=tuple)


class BrowserPolicyError(RuntimeError):
    pass


class BrowserManager:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._playwright = None
        self._browser = None
        self._sessions: Dict[str, BrowserSessionState] = {}

    def _ensure_runtime(self) -> None:
        if self._browser is not None:
            return
        try:
            from playwright.sync_api import sync_playwright  # type: ignore
        except Exception as exc:  # pragma: no cover - depends on optional dependency/runtime install
            raise RuntimeError(
                "Playwright is not installed on this client. Install the playwright package and Chromium browser binaries first."
            ) from exc
        self._playwright = sync_playwright().start()
        self._browser = self._playwright.chromium.launch(headless=_browser_headless())

    def _new_context(self, state: BrowserSessionState) -> Any:
        self._ensure_runtime()
        context = self._browser.new_context(accept_downloads=_browser_enable_downloads())
        context.set_default_navigation_timeout(int(_browser_nav_timeout_ms()))
        context.set_default_timeout(int(_browser_action_timeout_ms()))
        context.route(
            "**/*",
            lambda route, request, session=state: self._route_handler(route, request, session),
        )
        return context

    def _route_handler(self, route: Any, request: Any, session: BrowserSessionState) -> None:
        try:
            url = str(getattr(request, "url", "") or "")
            if not url:
                route.continue_()
                return
            if not _is_request_url_allowed(url, session.allowed_domains):
                route.abort("blockedbyclient")
                return
        except Exception:
            pass
        route.continue_()

    def _cleanup_expired_locked(self) -> None:
        ttl = max(60, int(_browser_idle_ttl_sec()))
        now = time.time()
        stale = [key for key, state in self._sessions.items() if (now - state.last_used_at) > ttl]
        for key in stale:
            self._close_session_locked(key)

    def _close_session_locked(self, session_key: str) -> None:
        state = self._sessions.pop(session_key, None)
        if not state:
            return
        try:
            state.context.close()
        except Exception:
            pass

    def close_session(self, session_key: str) -> bool:
        with self._lock:
            existed = session_key in self._sessions
            self._close_session_locked(session_key)
            return existed

    def reset_session(self, session_key: str, allowed_domains: Sequence[str]) -> BrowserSessionState:
        with self._lock:
            self._close_session_locked(session_key)
            return self.ensure_session(session_key, allowed_domains, create=True)

    def ensure_session(
        self,
        session_key: str,
        allowed_domains: Sequence[str],
        *,
        create: bool = True,
    ) -> BrowserSessionState:
        normalized_domains = tuple(_normalize_allowed_domains(allowed_domains))
        with self._lock:
            self._cleanup_expired_locked()
            state = self._sessions.get(session_key)
            if state is not None:
                if tuple(state.allowed_domains) != normalized_domains:
                    state.allowed_domains = normalized_domains
                state.last_used_at = time.time()
                self._prune_tabs_locked(state)
                if not state.tabs and create:
                    self._create_tab_locked(state)
                return state
            if not create:
                raise KeyError(session_key)
            state = BrowserSessionState(
                session_key=session_key,
                context=None,
                tabs={},
                active_tab_id=None,
                allowed_domains=normalized_domains,
            )
            state.context = self._new_context(state)
            self._sessions[session_key] = state
            self._create_tab_locked(state)
            state.last_used_at = time.time()
            return state

    def get_session(self, session_key: str) -> Optional[BrowserSessionState]:
        with self._lock:
            self._cleanup_expired_locked()
            state = self._sessions.get(session_key)
            if state is None:
                return None
            state.last_used_at = time.time()
            self._prune_tabs_locked(state)
            return state

    def _prune_tabs_locked(self, state: BrowserSessionState) -> None:
        closed = [tab_id for tab_id, page in state.tabs.items() if _page_is_closed(page)]
        for tab_id in closed:
            state.tabs.pop(tab_id, None)
            self._drop_tab_snapshots_locked(state, tab_id)
        if state.active_tab_id not in state.tabs:
            state.active_tab_id = next(iter(state.tabs.keys()), None)

    def _drop_tab_snapshots_locked(self, state: BrowserSessionState, tab_id: str) -> None:
        stale = [sid for sid, snap in state.snapshots.items() if snap.tab_id == tab_id]
        for snapshot_id in stale:
            state.snapshots.pop(snapshot_id, None)

    def _invalidate_tab_snapshots_locked(self, state: BrowserSessionState, tab_id: str) -> None:
        self._drop_tab_snapshots_locked(state, tab_id)

    def _create_tab_locked(self, state: BrowserSessionState) -> str:
        max_tabs = int(_browser_max_tabs())
        if len(state.tabs) >= max_tabs:
            raise BrowserPolicyError(f"browser tab limit reached ({max_tabs})")
        page = state.context.new_page()
        tab_id = _new_short_id("tab")
        state.tabs[tab_id] = page
        state.active_tab_id = tab_id
        return tab_id

    def list_tabs(self, state: Optional[BrowserSessionState]) -> List[Dict[str, Any]]:
        if state is None:
            return []
        with self._lock:
            self._prune_tabs_locked(state)
            items: List[Dict[str, Any]] = []
            for tab_id, page in state.tabs.items():
                items.append(
                    {
                        "tab_id": tab_id,
                        "url": _safe_call(lambda: page.url, default=""),
                        "title": _safe_call(lambda: page.title(), default=""),
                        "active": bool(tab_id == state.active_tab_id),
                    }
                )
            return items

    def get_page(self, state: BrowserSessionState, tab_id: Optional[str] = None) -> Tuple[str, Any]:
        with self._lock:
            self._prune_tabs_locked(state)
            resolved = tab_id or state.active_tab_id
            if not resolved:
                resolved = self._create_tab_locked(state)
            page = state.tabs.get(resolved)
            if page is None:
                raise BrowserPolicyError(f"unknown tab_id '{resolved}'")
            state.active_tab_id = resolved
            state.last_used_at = time.time()
            return resolved, page

    def new_tab(self, state: BrowserSessionState) -> Tuple[str, Any]:
        with self._lock:
            tab_id = self._create_tab_locked(state)
            page = state.tabs[tab_id]
            state.last_used_at = time.time()
            return tab_id, page

    def close_tab(self, state: BrowserSessionState, tab_id: str) -> None:
        with self._lock:
            page = state.tabs.get(tab_id)
            if page is None:
                raise BrowserPolicyError(f"unknown tab_id '{tab_id}'")
            try:
                page.close()
            except Exception:
                pass
            state.tabs.pop(tab_id, None)
            self._drop_tab_snapshots_locked(state, tab_id)
            if not state.tabs:
                self._create_tab_locked(state)
            elif state.active_tab_id == tab_id:
                state.active_tab_id = next(iter(state.tabs.keys()), None)
            state.last_used_at = time.time()

    def invalidate_tab_snapshots(self, state: BrowserSessionState, tab_id: str) -> None:
        with self._lock:
            self._invalidate_tab_snapshots_locked(state, tab_id)
            state.last_used_at = time.time()

    def store_snapshot(self, state: BrowserSessionState, snapshot: BrowserSnapshotRecord) -> None:
        with self._lock:
            self._invalidate_tab_snapshots_locked(state, snapshot.tab_id)
            state.snapshots[snapshot.snapshot_id] = snapshot
            state.last_used_at = time.time()

    def get_snapshot(self, state: BrowserSessionState, snapshot_id: str) -> BrowserSnapshotRecord:
        with self._lock:
            snap = state.snapshots.get(snapshot_id)
            if snap is None:
                raise BrowserPolicyError(
                    f"unknown or stale snapshot_id '{snapshot_id}'. Take a fresh browser_snapshot first."
                )
            state.last_used_at = time.time()
            return snap


_BROWSER_MANAGER: Optional[BrowserManager] = None
_BROWSER_MANAGER_LOCK = threading.Lock()
_BROWSER_WORKER: Optional["_BrowserWorker"] = None
_BROWSER_WORKER_LOCK = threading.Lock()


class _BrowserWorker:
    def __init__(self) -> None:
        self._cv = threading.Condition()
        self._queue = deque()
        self._thread = threading.Thread(target=self._run, name="henosis-browser-worker", daemon=True)
        self._thread.start()

    def call(self, fn: Any, *args: Any, **kwargs: Any) -> Any:
        done = threading.Event()
        holder: Dict[str, Any] = {}
        with self._cv:
            self._queue.append((fn, args, kwargs, done, holder))
            self._cv.notify()
        done.wait()
        if "exc" in holder:
            raise holder["exc"]
        return holder.get("result")

    def _run(self) -> None:
        while True:
            with self._cv:
                while not self._queue:
                    self._cv.wait()
                fn, args, kwargs, done, holder = self._queue.popleft()
            try:
                holder["result"] = fn(*args, **kwargs)
            except Exception as exc:
                holder["exc"] = exc
            finally:
                done.set()


def _get_browser_manager() -> BrowserManager:
    global _BROWSER_MANAGER
    if _BROWSER_MANAGER is not None:
        return _BROWSER_MANAGER
    with _BROWSER_MANAGER_LOCK:
        if _BROWSER_MANAGER is None:
            _BROWSER_MANAGER = BrowserManager()
        return _BROWSER_MANAGER


def _get_browser_worker() -> _BrowserWorker:
    global _BROWSER_WORKER
    if _BROWSER_WORKER is not None:
        return _BROWSER_WORKER
    with _BROWSER_WORKER_LOCK:
        if _BROWSER_WORKER is None:
            _BROWSER_WORKER = _BrowserWorker()
        return _BROWSER_WORKER


def is_browser_tool(name: Optional[str]) -> bool:
    try:
        return (name or "").strip().lower() in BROWSER_TOOL_NAMES
    except Exception:
        return False


def browser_tool_requires_approval(tool_name: Optional[str], args_preview: Optional[Dict[str, Any]] = None) -> bool:
    name = (tool_name or "").strip().lower()
    args_preview = args_preview if isinstance(args_preview, dict) else {}
    action = str(args_preview.get("action") or "").strip().lower()
    if name in {"browser_snapshot", "browser_wait"}:
        return False
    if name == "browser_session":
        return action in {"start", "stop", "reset"}
    if name == "browser_tabs":
        return action in {"new", "close"}
    if name == "browser_navigate":
        return True
    if name == "browser_act":
        return action not in {"hover", "scroll", "scroll_into_view"}
    return False


def _tool_ok(data: Any) -> Dict[str, Any]:
    return {"ok": True, "data": data}


def _tool_err(msg: str) -> Dict[str, Any]:
    return {"ok": False, "error": msg}


def _new_short_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:10]}"


def _safe_call(fn: Any, *, default: Any) -> Any:
    try:
        return fn()
    except Exception:
        return default


def _page_is_closed(page: Any) -> bool:
    try:
        return bool(page.is_closed())
    except Exception:
        return False


def _normalize_allowed_domains(domains: Optional[Iterable[Any]]) -> List[str]:
    cleaned: List[str] = []
    seen = set()
    raw_domains = list(domains or [])
    if not raw_domains:
        raw_domains = [token.strip() for token in _browser_allowed_domains_env().split(",") if token.strip()]
    for domain in raw_domains:
        if not isinstance(domain, str):
            continue
        item = domain.strip().lower()
        if not item:
            continue
        if "://" in item:
            item = item.split("://", 1)[1]
        item = item.strip().strip("/")
        if not item or item in seen:
            continue
        seen.add(item)
        cleaned.append(item)
    return cleaned


def _normalize_session_key(raw: Optional[Any]) -> str:
    text = "" if raw is None else str(raw).strip()
    if not text:
        return ""
    safe = "".join(ch for ch in text if ch.isalnum() or ch in {"-", "_", ":", "."})
    return safe[:128]


def _resolve_browser_session_key(args: Dict[str, Any], policy: Any) -> str:
    explicit = _normalize_session_key(args.get("session_key"))
    if explicit:
        return explicit
    from_policy = _normalize_session_key(getattr(policy, "_browser_session_key", None))
    if from_policy:
        return from_policy
    fallback = _normalize_session_key(getattr(policy, "_browser_fallback_session_key", None))
    if fallback:
        return fallback
    return _new_short_id("browser")


def _resolve_browser_allowed_domains(args: Dict[str, Any], policy: Any) -> List[str]:
    override = args.get("allowed_domains")
    if isinstance(override, list):
        return _normalize_allowed_domains(override)
    from_policy = getattr(policy, "_browser_allowed_domains", None)
    if isinstance(from_policy, list):
        return _normalize_allowed_domains(from_policy)
    return _normalize_allowed_domains(None)


def _resolved_nav_timeout(args: Dict[str, Any]) -> int:
    try:
        value = int(args.get("timeout_ms") or _browser_nav_timeout_ms())
    except Exception:
        value = int(_browser_nav_timeout_ms())
    return max(1, min(value, 300_000))


def _resolved_action_timeout(args: Dict[str, Any]) -> int:
    try:
        value = int(args.get("timeout_ms") or _browser_action_timeout_ms())
    except Exception:
        value = int(_browser_action_timeout_ms())
    return max(1, min(value, 300_000))


def _page_summary(page: Any, tab_id: str) -> Dict[str, Any]:
    return {
        "tab_id": tab_id,
        "url": _safe_call(lambda: page.url, default=""),
        "title": _safe_call(lambda: page.title(), default=""),
    }


def _session_status_payload(state: Optional[BrowserSessionState], session_key: str) -> Dict[str, Any]:
    tabs = _get_browser_manager().list_tabs(state)
    return {
        "session_key": session_key,
        "running": bool(state is not None),
        "active_tab_id": (state.active_tab_id if state is not None else None),
        "tab_count": len(tabs),
        "tabs": tabs,
        "allowed_domains": list(state.allowed_domains) if state is not None else [],
        "headless": _browser_headless(),
        "idle_ttl_sec": int(_browser_idle_ttl_sec()),
        "nav_timeout_ms": int(_browser_nav_timeout_ms()),
        "action_timeout_ms": int(_browser_action_timeout_ms()),
    }


def _summary_text_from_snapshot_items(items: Sequence[Dict[str, Any]], max_chars: int) -> Tuple[str, bool]:
    lines: List[str] = []
    for item in items:
        try:
            ref = str(item.get("ref") or "")
            role = str(item.get("role") or item.get("tag") or "element")
            name = str(item.get("name") or "").strip()
            text = str(item.get("text") or "").strip()
            extras: List[str] = []
            if name:
                extras.append(f"name={name}")
            if text and text != name:
                extras.append(f"text={text}")
            if item.get("value") not in (None, ""):
                extras.append(f"value={item.get('value')}")
            if item.get("disabled"):
                extras.append("disabled=true")
            if item.get("checked"):
                extras.append("checked=true")
            line = f"{ref} | {role}"
            if extras:
                line += " | " + " | ".join(extras)
            lines.append(line)
        except Exception:
            continue
    text = "\n".join(lines)
    truncated = False
    if len(text) > max_chars:
        text = text[:max_chars].rstrip()
        truncated = True
    return text, truncated


def _infer_role_js() -> str:
    return r"""
const inferRole = (el) => {
  const explicit = (el.getAttribute('role') || '').trim();
  if (explicit) return explicit;
  const tag = (el.tagName || '').toLowerCase();
  const typ = (el.getAttribute('type') || '').toLowerCase();
  if (tag === 'a') return 'link';
  if (tag === 'button') return 'button';
  if (tag === 'select') return 'select';
  if (tag === 'textarea') return 'textbox';
  if (tag === 'input') {
    if (typ === 'checkbox') return 'checkbox';
    if (typ === 'radio') return 'radio';
    if (typ === 'submit' || typ === 'button' || typ === 'reset') return 'button';
    return 'textbox';
  }
  if (tag === 'summary') return 'button';
  return tag || 'element';
};
const labelFor = (el) => {
  const direct = [
    el.getAttribute('aria-label'),
    el.getAttribute('title'),
    el.getAttribute('placeholder'),
    el.getAttribute('alt'),
    el.value,
    el.innerText,
    el.textContent,
  ];
  for (const candidate of direct) {
    if (candidate && String(candidate).trim()) return String(candidate).trim();
  }
  const id = el.getAttribute('id');
  if (id) {
    const lbl = document.querySelector(`label[for="${CSS.escape(id)}"]`);
    if (lbl && lbl.innerText && lbl.innerText.trim()) return lbl.innerText.trim();
  }
  const parentLabel = el.closest('label');
  if (parentLabel && parentLabel.innerText && parentLabel.innerText.trim()) return parentLabel.innerText.trim();
  return '';
};
const safeText = (value, maxLen = 160) => {
  const out = String(value || '').replace(/\s+/g, ' ').trim();
  if (!out) return '';
  return out.length > maxLen ? out.slice(0, maxLen) : out;
};
const visible = (el) => {
  const rect = el.getBoundingClientRect();
  if (!rect || rect.width < 1 || rect.height < 1) return false;
  const style = window.getComputedStyle(el);
  if (!style) return true;
  if (style.visibility === 'hidden' || style.display === 'none') return false;
  return true;
};
"""


_SNAPSHOT_JS = f"""
(payload) => {{
  const snapshotId = String((payload && payload.snapshotId) || 'snap');
  const maxItems = Number((payload && payload.maxItems) || 100);
  {_infer_role_js()}
  const selectors = [
    'a[href]',
    'button',
    'input',
    'textarea',
    'select',
    'summary',
    '[role]',
    '[tabindex]:not([tabindex="-1"])'
  ];
  for (const node of document.querySelectorAll('[{_BROWSER_REF_ATTR}]')) {{
    node.removeAttribute('{_BROWSER_REF_ATTR}');
  }}
  const nodes = Array.from(document.querySelectorAll(selectors.join(',')));
  const unique = [];
  const seen = new Set();
  for (const node of nodes) {{
    if (!node || seen.has(node)) continue;
    seen.add(node);
    if (!visible(node)) continue;
    unique.push(node);
    if (unique.length >= maxItems) break;
  }}
  const items = [];
  unique.forEach((el, idx) => {{
    const ref = `e${{idx + 1}}`;
    el.setAttribute('{_BROWSER_REF_ATTR}', `${{snapshotId}}:${{ref}}`);
    const role = inferRole(el);
    const name = safeText(labelFor(el));
    const text = safeText(el.innerText || el.textContent || '');
    const value = safeText(el.value || el.getAttribute('value') || '');
    const placeholder = safeText(el.getAttribute('placeholder') || '');
    const type = safeText(el.getAttribute('type') || '');
    const tag = safeText((el.tagName || '').toLowerCase());
    items.push({{
      ref,
      role,
      name,
      text,
      value,
      placeholder,
      tag,
      type,
      disabled: !!el.disabled,
      checked: !!el.checked,
    }});
  }});
  return {{
    url: window.location.href,
    title: document.title || '',
    items,
    total_items: items.length,
  }};
}}
"""


def _build_snapshot(page: Any, tab_id: str, max_items: int, max_chars: int) -> BrowserSnapshotRecord:
    snapshot_id = _new_short_id("snap")
    raw = page.evaluate(_SNAPSHOT_JS, {"snapshotId": snapshot_id, "maxItems": int(max_items)})
    if not isinstance(raw, dict):
        raise RuntimeError("browser snapshot did not return structured data")
    items = raw.get("items") or []
    if not isinstance(items, list):
        items = []
    text, truncated = _summary_text_from_snapshot_items(items, max_chars)
    snapshot = BrowserSnapshotRecord(
        snapshot_id=snapshot_id,
        tab_id=tab_id,
        url=str(raw.get("url") or page.url or ""),
        title=str(raw.get("title") or _safe_call(lambda: page.title(), default="") or ""),
        items=items,
        text=text,
    )
    setattr(snapshot, "_summary_truncated", bool(truncated))
    return snapshot


def _find_ref_locator(page: Any, snapshot: BrowserSnapshotRecord, ref: str) -> Any:
    ref_text = str(ref or "").strip()
    if not ref_text:
        raise BrowserPolicyError("ref is required")
    selector = f'[{_BROWSER_REF_ATTR}="{snapshot.snapshot_id}:{ref_text}"]'
    locator = page.locator(selector).first
    try:
        if locator.count() < 1:
            raise BrowserPolicyError(
                f"ref '{ref_text}' was not found for snapshot_id '{snapshot.snapshot_id}'. Take a fresh browser_snapshot and try again."
            )
    except Exception as exc:
        if isinstance(exc, BrowserPolicyError):
            raise
        raise BrowserPolicyError(
            f"failed to resolve ref '{ref_text}' for snapshot_id '{snapshot.snapshot_id}'"
        ) from exc
    return locator


def _sanitize_host(hostname: str) -> str:
    return hostname.strip().strip("[]").lower()


def _hostname_matches_allowed(hostname: str, allowed_domains: Sequence[str]) -> bool:
    host = _sanitize_host(hostname)
    if not allowed_domains:
        return True
    for allowed in allowed_domains:
        cand = _sanitize_host(str(allowed or ""))
        if not cand:
            continue
        if host == cand or host.endswith("." + cand):
            return True
    return False


def _host_resolves_to_private_net(hostname: str) -> bool:
    host = _sanitize_host(hostname)
    if not host:
        return True
    if host in {"localhost", "localhost.localdomain"}:
        return True
    try:
        ip = ipaddress.ip_address(host)
        return _ip_is_privateish(ip)
    except ValueError:
        pass
    try:
        infos = socket.getaddrinfo(host, None)
    except Exception:
        return False
    for info in infos:
        try:
            addr = info[4][0]
            ip = ipaddress.ip_address(addr)
            if _ip_is_privateish(ip):
                return True
        except Exception:
            continue
    return False


def _ip_is_privateish(ip: ipaddress._BaseAddress) -> bool:  # type: ignore[attr-defined]
    return bool(
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_reserved
        or ip.is_multicast
        or ip.is_unspecified
        or str(ip) == "169.254.169.254"
    )


def _validate_browser_url(url: str, allowed_domains: Sequence[str]) -> Tuple[str, str]:
    try:
        parsed = urlparse(str(url or "").strip())
    except Exception as exc:
        raise BrowserPolicyError("url is required") from exc
    if not parsed.scheme or not parsed.netloc:
        raise BrowserPolicyError("browser URLs must be absolute http/https URLs")
    scheme = parsed.scheme.lower()
    if scheme not in _BROWSER_SAFE_SCHEMES:
        raise BrowserPolicyError("browser navigation only permits http and https URLs")
    hostname = _sanitize_host(parsed.hostname or "")
    if not hostname:
        raise BrowserPolicyError("browser URL is missing a hostname")
    if not _hostname_matches_allowed(hostname, allowed_domains):
        raise BrowserPolicyError(f"hostname '{hostname}' is not in the browser allow-list")
    if _browser_block_private_nets() and _host_resolves_to_private_net(hostname):
        raise BrowserPolicyError(f"browser access to private or loopback host '{hostname}' is blocked")
    return parsed.geturl(), hostname


def _is_request_url_allowed(url: str, allowed_domains: Sequence[str]) -> bool:
    parsed = urlparse(str(url or "").strip())
    scheme = (parsed.scheme or "").lower()
    if scheme in _BROWSER_PASSIVE_SCHEMES:
        return True
    if scheme not in _BROWSER_SAFE_SCHEMES:
        return False
    try:
        _validate_browser_url(url, allowed_domains)
        return True
    except Exception:
        return False


def _execute_browser_tool_sync(name: str, args_json: Dict[str, Any] | str, policy: Any = None) -> Dict[str, Any]:
    try:
        if isinstance(args_json, str):
            args = json.loads(args_json) if args_json.strip() else {}
        else:
            args = dict(args_json or {})
    except Exception as exc:
        return _tool_err(f"invalid browser tool args: {exc}")
    try:
        session_key = _resolve_browser_session_key(args, policy)
        allowed_domains = _resolve_browser_allowed_domains(args, policy)
        manager = _get_browser_manager()
        tool_name = (name or "").strip().lower()

        if tool_name == "browser_session":
            action = str(args.get("action") or "status").strip().lower()
            if action == "status":
                state = manager.get_session(session_key)
                return _tool_ok(_session_status_payload(state, session_key))
            if action == "start":
                state = manager.ensure_session(session_key, allowed_domains, create=True)
                return _tool_ok(_session_status_payload(state, session_key))
            if action == "stop":
                stopped = manager.close_session(session_key)
                payload = _session_status_payload(None, session_key)
                payload["stopped"] = bool(stopped)
                return _tool_ok(payload)
            if action == "reset":
                state = manager.reset_session(session_key, allowed_domains)
                out = _session_status_payload(state, session_key)
                out["reset"] = True
                return _tool_ok(out)
            return _tool_err("browser_session action must be start, status, stop, or reset")

        if tool_name == "browser_tabs":
            action = str(args.get("action") or "list").strip().lower()
            if action == "list":
                state = manager.get_session(session_key)
                return _tool_ok(_session_status_payload(state, session_key))
            state = manager.ensure_session(session_key, allowed_domains, create=True)
            if action == "new":
                tab_id, page = manager.new_tab(state)
                url = str(args.get("url") or "").strip()
                if url:
                    url, _ = _validate_browser_url(url, allowed_domains)
                    page.goto(url, wait_until="load", timeout=_resolved_nav_timeout(args))
                    manager.invalidate_tab_snapshots(state, tab_id)
                out = _session_status_payload(state, session_key)
                out["active_tab"] = _page_summary(page, tab_id)
                return _tool_ok(out)
            if action == "select":
                tab_id, page = manager.get_page(state, str(args.get("tab_id") or "").strip())
                out = _session_status_payload(state, session_key)
                out["active_tab"] = _page_summary(page, tab_id)
                return _tool_ok(out)
            if action == "close":
                tab_id = str(args.get("tab_id") or "").strip()
                if not tab_id:
                    return _tool_err("tab_id is required for browser_tabs close")
                manager.close_tab(state, tab_id)
                return _tool_ok(_session_status_payload(state, session_key))
            return _tool_err("browser_tabs action must be list, new, select, or close")

        state = manager.ensure_session(session_key, allowed_domains, create=True)

        if tool_name == "browser_navigate":
            url = str(args.get("url") or "").strip()
            if not url:
                return _tool_err("url is required")
            url, _host = _validate_browser_url(url, allowed_domains)
            tab_id, page = manager.get_page(state, str(args.get("tab_id") or "").strip() or None)
            requested_url = url
            wait_until = str(args.get("wait_until") or "load").strip().lower() or "load"
            if wait_until not in {"commit", "domcontentloaded", "load", "networkidle"}:
                wait_until = "load"
            page.goto(url, wait_until=wait_until, timeout=_resolved_nav_timeout(args))
            final_url = _safe_call(lambda: page.url, default="")
            if final_url:
                _validate_browser_url(final_url, allowed_domains)
            manager.invalidate_tab_snapshots(state, tab_id)
            return _tool_ok(
                {
                    **_page_summary(page, tab_id),
                    "requested_url": requested_url,
                    "redirected": bool(final_url and final_url != requested_url),
                    "wait_until": wait_until,
                    "snapshot_recommended": True,
                }
            )

        if tool_name == "browser_snapshot":
            tab_id, page = manager.get_page(state, str(args.get("tab_id") or "").strip() or None)
            max_items = int(args.get("max_items") or _browser_snapshot_max_items())
            max_items = max(1, min(max_items, 500))
            max_chars = int(args.get("max_chars") or _browser_snapshot_max_chars())
            max_chars = max(200, min(max_chars, 50_000))
            snapshot = _build_snapshot(page, tab_id, max_items, max_chars)
            manager.store_snapshot(state, snapshot)
            text = snapshot.text
            truncated = bool(getattr(snapshot, "_summary_truncated", False))
            return _tool_ok(
                {
                    "session_key": session_key,
                    "tab_id": tab_id,
                    "url": snapshot.url,
                    "title": snapshot.title,
                    "snapshot_id": snapshot.snapshot_id,
                    "stats": {
                        "items": len(snapshot.items),
                        "interactive": len(snapshot.items),
                        "chars": len(text),
                        "truncated": truncated,
                    },
                    "items": snapshot.items,
                    "text": text,
                }
            )

        if tool_name == "browser_wait":
            tab_id, page = manager.get_page(state, str(args.get("tab_id") or "").strip() or None)
            timeout_ms = _resolved_action_timeout(args)
            waited_for: List[str] = []
            url_pattern = str(args.get("url_pattern") or "").strip()
            wait_text = str(args.get("text") or "").strip()
            load_state = str(args.get("load_state") or "").strip().lower()
            if url_pattern:
                page.wait_for_url(url_pattern, timeout=timeout_ms)
                waited_for.append(f"url_pattern={url_pattern}")
            if load_state:
                if load_state not in {"domcontentloaded", "load", "networkidle"}:
                    return _tool_err("load_state must be domcontentloaded, load, or networkidle")
                page.wait_for_load_state(load_state, timeout=timeout_ms)
                waited_for.append(f"load_state={load_state}")
            if wait_text:
                page.get_by_text(wait_text, exact=False).first.wait_for(state="visible", timeout=timeout_ms)
                waited_for.append(f"text={wait_text}")
            if not waited_for:
                return _tool_err("browser_wait requires url_pattern, text, or load_state")
            return _tool_ok(
                {
                    **_page_summary(page, tab_id),
                    "waited_for": waited_for,
                    "timeout_ms": timeout_ms,
                }
            )

        if tool_name == "browser_act":
            action = str(args.get("action") or "").strip().lower()
            if not action:
                return _tool_err("action is required")
            tab_id_arg = str(args.get("tab_id") or "").strip() or None
            tab_id, page = manager.get_page(state, tab_id_arg)
            timeout_ms = _resolved_action_timeout(args)
            before_url = _safe_call(lambda: page.url, default="")
            before_title = _safe_call(lambda: page.title(), default="")
            locator = None
            snapshot_id = str(args.get("snapshot_id") or "").strip()
            ref = str(args.get("ref") or "").strip()
            if action != "scroll":
                if not snapshot_id:
                    return _tool_err("snapshot_id is required for this browser action")
                snapshot = manager.get_snapshot(state, snapshot_id)
                if snapshot.tab_id != tab_id:
                    return _tool_err("snapshot_id does not belong to the selected tab")
                locator = _find_ref_locator(page, snapshot, ref)
            if action == "click":
                locator.click(timeout=timeout_ms)
            elif action == "double_click":
                locator.dblclick(timeout=timeout_ms)
            elif action == "type":
                text = str(args.get("text") or "")
                locator.fill(text, timeout=timeout_ms)
                if bool(args.get("append_enter")):
                    locator.press("Enter", timeout=timeout_ms)
            elif action == "press":
                key = str(args.get("key") or "").strip()
                if not key:
                    return _tool_err("key is required for browser_act press")
                locator.press(key, timeout=timeout_ms)
            elif action == "select":
                value = args.get("value")
                if isinstance(value, list):
                    locator.select_option(value=[str(v) for v in value], timeout=timeout_ms)
                elif isinstance(value, str) and value.strip():
                    locator.select_option(value=value, timeout=timeout_ms)
                else:
                    return _tool_err("value is required for browser_act select")
            elif action == "hover":
                locator.hover(timeout=timeout_ms)
            elif action == "scroll_into_view":
                locator.scroll_into_view_if_needed(timeout=timeout_ms)
            elif action == "scroll":
                delta_x = float(args.get("delta_x") or 0)
                delta_y = float(args.get("delta_y") or 600)
                page.mouse.wheel(delta_x, delta_y)
            elif action == "check":
                locator.check(timeout=timeout_ms)
            elif action == "uncheck":
                locator.uncheck(timeout=timeout_ms)
            else:
                return _tool_err(
                    "browser_act action must be click, double_click, type, press, select, hover, scroll_into_view, scroll, check, or uncheck"
                )
            after_url = _safe_call(lambda: page.url, default="")
            after_title = _safe_call(lambda: page.title(), default="")
            navigation_detected = bool(after_url and after_url != before_url)
            if navigation_detected:
                manager.invalidate_tab_snapshots(state, tab_id)
            return _tool_ok(
                {
                    **_page_summary(page, tab_id),
                    "action": action,
                    "ref": ref or None,
                    "snapshot_id": snapshot_id or None,
                    "navigation_detected": navigation_detected,
                    "title_changed": bool(after_title != before_title),
                    "snapshot_recommended": True,
                }
            )

        return _tool_err(f"unknown browser tool '{tool_name}'")
    except BrowserPolicyError as exc:
        return _tool_err(str(exc))
    except Exception as exc:
        return _tool_err(str(exc))


def execute_browser_tool(name: str, args_json: Dict[str, Any] | str, policy: Any = None) -> Dict[str, Any]:
    try:
        return _get_browser_worker().call(_execute_browser_tool_sync, name, args_json, policy)
    except Exception as exc:
        return _tool_err(str(exc))
