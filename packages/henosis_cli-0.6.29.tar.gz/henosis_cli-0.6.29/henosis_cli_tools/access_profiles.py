from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional, Protocol, runtime_checkable

ProfileKind = Literal["backend", "oauth", "subscription", "byok"]
ExecutionBackendKind = Literal["backend_sse", "local_http", "local_subprocess", "local_acp", "local_jsonrpc", "local_proxy"]
ReadinessState = Literal[
    "ready",
    "not_installed",
    "not_logged_in",
    "subscription_unavailable",
    "model_unavailable",
    "misconfigured",
    "unsupported",
    "unknown",
]


@dataclass(frozen=True)
class ProfileCapabilities:
    supports_streaming: bool = False
    supports_tool_calling: bool = False
    supports_context_handoff: bool = False
    supports_remote_control_inference: bool = False
    supports_usage_commit: bool = True
    supports_thread_sync: bool = True
    supports_model_discovery: bool = False
    supports_acp: bool = False
    supports_jsonrpc: bool = False
    supports_subprocess_exec: bool = False


@dataclass(frozen=True)
class ProfileReadinessStatus:
    state: ReadinessState
    ready: bool
    detail: str = ""
    installed: Optional[bool] = None
    authenticated: Optional[bool] = None
    subscription_usable: Optional[bool] = None
    model_available: Optional[bool] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ModelCapabilityInfo:
    model_id: str
    available: bool = True
    provider_family: str = "openai"
    display_name: Optional[str] = None
    max_context_tokens: Optional[int] = None
    supports_tools: Optional[bool] = None
    supports_streaming: Optional[bool] = None
    supports_reasoning: Optional[bool] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class AccessProfile:
    profile_id: str
    kind: ProfileKind
    display_name: str
    provider_families_supported: List[str]
    billing_source: str
    execution_backend: ExecutionBackendKind
    capabilities: ProfileCapabilities = field(default_factory=ProfileCapabilities)
    metadata: Dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class ExecutionAdapter(Protocol):
    profile_id: str

    def list_available_models(self) -> List[ModelCapabilityInfo]: ...

    def supports_model(self, model_id: str) -> bool: ...

    def get_model_capabilities(self, model_id: str) -> Optional[ModelCapabilityInfo]: ...

    def get_readiness_status(self) -> ProfileReadinessStatus: ...

    def execute_turn(self, *, model_id: str, prompt: str, cwd: Optional[str] = None) -> Dict[str, Any]: ...
