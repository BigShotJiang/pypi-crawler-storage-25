from __future__ import annotations

from wexample_wex_addon_services_platform.services_platform_addon_manager import (
    ServicesPlatformAddonManager,
)

__all__ = ["ServicesPlatformAddonManager"]
