from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(
    type=COMMAND_TYPE_SERVICE,
    description="Configure n8n service in app config",
)
def n8n__service__install(
    context: ExecutionContext,
    service: AppService,
) -> None:
    from wexample_helpers.helpers.string import string_random_token

    config_file = service.app_workdir.get_config_file()
    config = config_file.read_config()

    config.set_by_path(f"service.{service.name}.basic_auth.user", "admin")
    config.set_by_path(
        f"service.{service.name}.basic_auth.password",
        string_random_token(),
    )

    config_file.write_config(config)
    service.app_workdir.get_runtime_config(rebuild=True)

    context.io.log("Configured n8n service defaults")
