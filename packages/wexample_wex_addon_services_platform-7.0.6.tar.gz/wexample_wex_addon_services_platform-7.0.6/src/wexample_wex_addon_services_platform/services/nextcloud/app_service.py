from __future__ import annotations

from wexample_wex_addon_app.service.app_service import AppService as BaseAppService


class AppService(BaseAppService):
    def get_workdir_contribution(self) -> dict:
        from wexample_filestate.const.disk import DiskItemType

        # Nextcloud container runs as uid 33 (www-data)
        nc_mode = {"owner": "33:33", "permissions": "750", "recursive": True}

        return {
            "children": [
                {
                    "name": "nextcloud",
                    "type": DiskItemType.DIRECTORY,
                    "should_exist": True,
                    "children": [
                        {
                            "name": "data",
                            "type": DiskItemType.DIRECTORY,
                            "should_exist": True,
                            "mode": nc_mode,
                        },
                    ],
                },
            ]
        }
