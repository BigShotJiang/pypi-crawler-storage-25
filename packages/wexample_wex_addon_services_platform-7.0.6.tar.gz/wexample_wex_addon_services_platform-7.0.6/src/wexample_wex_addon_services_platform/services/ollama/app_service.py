from __future__ import annotations

from wexample_wex_addon_app.service.app_service import AppService as BaseAppService


class AppService(BaseAppService):
    def get_workdir_contribution(self) -> dict:
        from wexample_filestate.const.disk import DiskItemType

        # Ollama runs as root, no chown needed — just ensure the models dir exists.
        return {
            "children": [
                {
                    "name": "ollama",
                    "type": DiskItemType.DIRECTORY,
                    "should_exist": True,
                }
            ]
        }
