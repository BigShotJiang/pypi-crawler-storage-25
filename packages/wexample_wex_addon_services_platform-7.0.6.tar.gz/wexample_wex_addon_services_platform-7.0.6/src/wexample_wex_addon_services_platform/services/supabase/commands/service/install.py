from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(
    type=COMMAND_TYPE_SERVICE,
    description="Install supabase: generate secrets and fetch config files",
)
def supabase__service__install(
    context: ExecutionContext,
    service: AppService,
) -> None:
    import base64
    import hashlib
    import hmac
    import json
    import secrets
    import subprocess
    import time

    from wexample_helpers.helpers.file import (
        file_chown_as_real_user,
        file_env_append_as_real_user,
        file_mkdir_as_real_user,
    )

    def _jwt(secret: str, role: str) -> str:
        header = (
            base64.urlsafe_b64encode(
                json.dumps({"alg": "HS256", "typ": "JWT"}).encode()
            )
            .rstrip(b"=")
            .decode()
        )
        now = int(time.time())
        payload = (
            base64.urlsafe_b64encode(
                json.dumps(
                    {
                        "role": role,
                        "iss": "supabase",
                        "iat": now,
                        "exp": now + 157680000,
                    }
                ).encode()
            )
            .rstrip(b"=")
            .decode()
        )
        sig = (
            base64.urlsafe_b64encode(
                hmac.new(
                    secret.encode(), f"{header}.{payload}".encode(), hashlib.sha256
                ).digest()
            )
            .rstrip(b"=")
            .decode()
        )
        return f"{header}.{payload}.{sig}"

    app_path = service.app_workdir.get_path()
    jwt_secret = secrets.token_hex(32)

    # Generate secrets and write to .env (gitignored)
    file_env_append_as_real_user(
        app_path / ".wex" / ".env",
        {
            "SUPABASE_JWT_SECRET": jwt_secret,
            "SUPABASE_ANON_KEY": _jwt(jwt_secret, "anon"),
            "SUPABASE_SERVICE_ROLE_KEY": _jwt(jwt_secret, "service_role"),
            "SUPABASE_SECRET_KEY_BASE": secrets.token_hex(64),
            "SUPABASE_VAULT_ENC_KEY": secrets.token_hex(16),
            "SUPABASE_PG_META_CRYPTO_KEY": secrets.token_hex(32),
            "SUPABASE_POSTGRES_PASSWORD": secrets.token_urlsafe(24),
            "SUPABASE_DASHBOARD_USERNAME": "admin",
            "SUPABASE_DASHBOARD_PASSWORD": secrets.token_urlsafe(24),
            "SUPABASE_LOGFLARE_PUBLIC_ACCESS_TOKEN": secrets.token_hex(16),
            "SUPABASE_LOGFLARE_PRIVATE_ACCESS_TOKEN": secrets.token_hex(32),
        },
    )

    # Fetch official Supabase config files
    supabase_config_path = app_path / "supabase" / "config"
    context.io.log("Fetching official Supabase config files from GitHub...")

    base_url = (
        "https://raw.githubusercontent.com/supabase/supabase/master/docker/volumes"
    )
    files_to_fetch = {
        "api/kong.yml": supabase_config_path / "api" / "kong.yml",
        "api/kong-entrypoint.sh": supabase_config_path / "api" / "kong-entrypoint.sh",
        "db/realtime.sql": supabase_config_path / "db" / "realtime.sql",
        "db/webhooks.sql": supabase_config_path / "db" / "webhooks.sql",
        "db/roles.sql": supabase_config_path / "db" / "roles.sql",
        "db/jwt.sql": supabase_config_path / "db" / "jwt.sql",
        "db/_supabase.sql": supabase_config_path / "db" / "_supabase.sql",
        "db/logs.sql": supabase_config_path / "db" / "logs.sql",
        "db/pooler.sql": supabase_config_path / "db" / "pooler.sql",
        "logs/vector.yml": supabase_config_path / "logs" / "vector.yml",
        "pooler/pooler.exs": supabase_config_path / "pooler" / "pooler.exs",
    }

    for remote_path, local_path in files_to_fetch.items():
        file_mkdir_as_real_user(local_path.parent)
        url = f"{base_url}/{remote_path}"
        result = subprocess.run(
            ["curl", "-sSfL", url, "-o", str(local_path)], capture_output=True
        )
        if result.returncode != 0:
            context.io.log(f"Warning: could not fetch {remote_path}")
        else:
            file_chown_as_real_user(local_path)
            context.io.log(f"  ✓ {remote_path}")

    # Make kong-entrypoint.sh executable
    entrypoint = supabase_config_path / "api" / "kong-entrypoint.sh"
    if entrypoint.exists():
        entrypoint.chmod(0o755)

    # Create empty postgres custom config files required by supabase/postgres image.
    # The image's postgresql.conf includes these via `include =` directives —
    # postgres will refuse to start if they are missing.
    db_custom_config_path = app_path / "supabase" / "db" / "config"
    file_mkdir_as_real_user(db_custom_config_path)
    for conf_file in ["wal-g.conf", "read-replica.conf", "supautils.conf"]:
        conf_path = db_custom_config_path / conf_file
        if not conf_path.exists():
            conf_path.touch()
            file_chown_as_real_user(conf_path)
            context.io.log(f"  ✓ db/config/{conf_file}")

    # pgsodium_root.key must be pre-created so the postgres container can read it.
    # The image's pgsodium_getkey.sh tries to write it if missing, but the mounted
    # directory isn't writable by the container user — causing FATAL: invalid secret key.
    pgsodium_key_path = db_custom_config_path / "pgsodium_root.key"
    if not pgsodium_key_path.exists():
        pgsodium_key_path.write_text(secrets.token_hex(32))
        file_chown_as_real_user(pgsodium_key_path)
        context.io.log("  ✓ db/config/pgsodium_root.key")

    context.io.log("Supabase install complete.")
