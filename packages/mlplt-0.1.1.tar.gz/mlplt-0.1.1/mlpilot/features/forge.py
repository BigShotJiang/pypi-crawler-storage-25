"""
mlpilot/features/forge.py
FeatureForge — leakage-safe feature engineering pipeline.
One function that handles encoding, scaling, and datetime expansion.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from joblib import Parallel, delayed

from mlpilot.features.encoders import (
    BinaryEncoder, CVTargetEncoder, DFMinMaxScaler, DFRobustScaler,
    DFStandardScaler, DatetimeFeatureExtractor, SafeLabelEncoder
)
from mlpilot.utils.display import RichTable, print_step, print_success
from mlpilot.utils.types import BaseResult


# ---------------------------------------------------------------------------
# FeatureResult
# ---------------------------------------------------------------------------

class FeatureResult(BaseResult):
    """
    Complete result from ml.features().
    
    Provides leakage-safe fit_transform() / transform() — statistics are
    always learned from training data only.
    """

    def __init__(
        self,
        df: pd.DataFrame,
        target: Optional[str],
        steps: List[tuple],
        col_actions: Dict[str, str],
    ):
        self.df = df
        self.target = target
        self._steps = steps
        self.col_actions = col_actions
        self._pipeline: Optional[Any] = None
        self._fitted = False
        self._feature_names_out: List[str] = []

    @property
    def pipeline(self) -> Any:
        if self._pipeline is None:
            # Lazy import sklearn
            from sklearn.pipeline import Pipeline
            self._pipeline = Pipeline(self._steps) if self._steps else Pipeline([("passthrough", "passthrough")])
        return self._pipeline

    @property
    def feature_names_out(self) -> List[str]:
        return self._feature_names_out

    def fit_transform(self, df: pd.DataFrame, y=None) -> pd.DataFrame:
        """
        Fit the pipeline on df and return the transformed dataframe.
        """
        X = self._drop_target(df)
        y_col = self._get_y(df, y)
        result = X.copy()
        
        for name, step in self._steps:
            if hasattr(step, "fit"):
                step.fit(result, y_col)
                result = step.transform(result)
            else:
                pass
                
        self._fitted = True
        self._feature_names_out = list(result.columns)
        
        # Lazy sync with sklearn pipeline if needed
        return result

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Transform new data using statistics learned during fit_transform().
        """
        if not self._fitted:
            raise RuntimeError("Call fit_transform(df_train) before transform(df_test)")
        X = self._drop_target(df)
        return self._apply_steps(X, y=None, fit=False)

    def _apply_steps(self, X: pd.DataFrame, y, fit: bool) -> pd.DataFrame:
        result = X.copy()
        for name, step in self._steps:
            if fit:
                if hasattr(step, "fit"):
                    step.fit(result, y)
            result = step.transform(result)
        self._feature_names_out = list(result.columns)
        return result

    def _drop_target(self, df: pd.DataFrame) -> pd.DataFrame:
        if self.target and self.target in df.columns:
            return df.drop(columns=[self.target])
        return df.copy()

    def _get_y(self, df: pd.DataFrame, y) -> Optional[pd.Series]:
        if y is not None:
            return pd.Series(y)
        if self.target and self.target in df.columns:
            return df[self.target]
        return None

    def report(self) -> None:
        """Print a summary of what was done to each column."""
        tbl = RichTable(
            title="Feature Engineering Report",
            columns=["Column", "Action"]
        )
        for col, action in self.col_actions.items():
            tbl.add_row(col, action)
        tbl.print()

    def __repr__(self) -> str:
        return (f"FeatureResult(target='{self.target}', "
                f"n_steps={len(self._steps)}, "
                f"n_features_out={len(self._feature_names_out)})")


# ---------------------------------------------------------------------------
# FeatureForge Engine
# ---------------------------------------------------------------------------

class FeatureForge:
    """Internal engine. Use ml.features() instead."""

    def __init__(
        self,
        target: Optional[str] = None,
        encoding: Union[str, Dict] = "auto",
        scaling: Union[str, Dict] = "auto",
        datetime_features: bool = True,
        max_cardinality_onehot: int = 20,
        feature_selection: bool = False,
        n_features_to_keep: Union[int, float] = 1.0,
        verbose: bool = True,
    ):
        self.target = target
        self.encoding = encoding
        self.scaling = scaling
        self.datetime_features = datetime_features
        self.max_cardinality_onehot = max_cardinality_onehot
        self.feature_selection = feature_selection
        self.n_features_to_keep = n_features_to_keep
        self.verbose = verbose

    def build(self, df: pd.DataFrame) -> FeatureResult:
        if self.verbose:
            print_step("Building FeatureForge pipeline...", "⚙️")

        steps = []
        col_actions: Dict[str, str] = {}
        feat_cols = [c for c in df.columns if c != self.target]

        # --------------- Datetime expansion ---------------
        if self.datetime_features:
            dt_cols = df[feat_cols].select_dtypes(include=["datetime64"]).columns.tolist()
            for col in dt_cols:
                extractor = DatetimeFeatureExtractor(col)
                steps.append((f"dt_{col}", extractor))
                col_actions[col] = "datetime → year/month/day/hour/dayofweek/quarter/is_weekend"
                feat_cols.remove(col)

        # --------------- Categorical encoding ---------------
        cat_cols = df[feat_cols].select_dtypes(
            include=["object", "category", "bool"]
        ).columns.tolist()

        for col in cat_cols:
            n_unique = df[col].nunique(dropna=True)
            enc = self._choose_encoding(col, n_unique)

            if enc == "binary":
                steps.append((f"bin_{col}", BinaryEncoder(col)))
                col_actions[col] = "binary encoding (0/1)"
            elif enc == "onehot":
                steps.append((f"ohe_{col}", _PandasOHE(col)))
                col_actions[col] = f"one-hot encoding ({n_unique} categories)"
            elif enc == "target":
                steps.append((f"te_{col}", CVTargetEncoder(col, smoothing=10.0)))
                col_actions[col] = "target encoding (leakage-safe CV)"
            elif enc == "label":
                steps.append((f"le_{col}", SafeLabelEncoder(col)))
                col_actions[col] = "label encoding"

        # --------------- Numeric scaling ---------------
        num_cols_remaining = [
            c for c in feat_cols
            if c not in cat_cols and pd.api.types.is_numeric_dtype(df[c])
        ]

        if num_cols_remaining:
            scaler = self._choose_scaler(df, num_cols_remaining)
            if scaler is not None:
                steps.append(("scaler", scaler))
                for col in num_cols_remaining:
                    col_actions[col] = f"{self.scaling} scaling"

        if self.verbose:
            print_success(f"Pipeline built: {len(steps)} transformation steps")

        return FeatureResult(df=df, target=self.target, steps=steps, col_actions=col_actions)

    def _choose_encoding(self, col: str, n_unique: int) -> str:
        if isinstance(self.encoding, dict) and col in self.encoding:
            return self.encoding[col]
        strategy = self.encoding if isinstance(self.encoding, str) else "auto"
        if strategy != "auto":
            return strategy
        if n_unique == 2:
            return "binary"
        if n_unique <= self.max_cardinality_onehot:
            return "onehot"
        if self.target:
            return "target"
        return "label"

    def _choose_scaler(self, df: pd.DataFrame, cols: List[str]) -> Optional[Any]:
        strategy = self.scaling if isinstance(self.scaling, str) else "auto"
        if strategy == "none":
            return None
        if strategy == "auto":
            has_outliers = False
            for col in cols:
                q = df[col].quantile([0.25, 0.75])
                iqr = q[0.75] - q[0.25]
                if iqr > 0:
                    n_out = int(((df[col] < q[0.25] - 1.5 * iqr) | (df[col] > q[0.75] + 1.5 * iqr)).sum())
                    if n_out / len(df) > 0.05:
                        has_outliers = True
                        break
            strategy = "robust" if has_outliers else "standard"

        if strategy == "standard":
            return DFStandardScaler(cols)
        if strategy == "robust":
            return DFRobustScaler(cols)
        if strategy == "minmax":
            return DFMinMaxScaler(cols)
        return None


# ---------------------------------------------------------------------------
# Helper: Pandas OHE
# ---------------------------------------------------------------------------

class _PandasOHE:
    def __init__(self, column: str, drop_first: bool = True):
        self.column = column
        self.drop_first = drop_first
        self.categories_: List[Any] = []

    def fit(self, X, y=None):
        series = X[self.column] if isinstance(X, pd.DataFrame) else pd.Series(X)
        self.categories_ = sorted(series.dropna().unique().tolist(), key=str)
        return self

    def transform(self, X, y=None):
        X = X.copy()
        dummies = pd.get_dummies(X[self.column], prefix=self.column, drop_first=self.drop_first)
        return pd.concat([X.drop(columns=[self.column]), dummies], axis=1)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def features(
    df: pd.DataFrame,
    target: Optional[str] = None,
    encoding: Union[str, Dict] = "auto",
    scaling: Union[str, Dict] = "auto",
    datetime_features: bool = True,
    max_cardinality_onehot: int = 20,
    verbose: bool = True,
) -> FeatureResult:
    """FeatureForge entry point."""
    forge = FeatureForge(
        target=target,
        encoding=encoding,
        scaling=scaling,
        datetime_features=datetime_features,
        max_cardinality_onehot=max_cardinality_onehot,
        verbose=verbose,
    )
    return forge.build(df)
