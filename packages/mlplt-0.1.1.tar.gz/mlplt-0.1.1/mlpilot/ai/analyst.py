"""
mlpilot/ai/analyst.py
AIAnalyst — Natural language data analysis using local-first LLMs.
Uses Ollama (local) via its API, with Groq as a cloud fallback.
Implements 'Review before Run' for execution safety.
"""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import pandas as pd

from mlpilot.utils.display import print_step, print_success, print_warning

# Dynamic root detection for universal compatibility
BASE_DIR = Path(__file__).resolve().parent.parent


def check_environment() -> bool:
    """Verifies that the required AI environment (Ollama) is available."""
    try:
        import ollama
        ollama.list()
        return True
    except Exception:
        print_warning("Ollama not found or not running. AI features will be disabled.")
        print("Please install Ollama from https://ollama.com to use the Analyst.")
        return False


class AIAnalyst:
    """
    AI-powered data analyst companion.
    """

    def __init__(
        self,
        df: pd.DataFrame,
        model: str = "auto",
        engine: str = "auto",
        groq_api_key: Optional[str] = None,
        verbose: bool = True,
    ):
        self.df = df
        self.verbose = verbose
        self.groq_api_key = groq_api_key or os.environ.get("GROQ_API_KEY")
        
        # Verify environment on startup
        if self.verbose:
            check_environment()
        
        # 1. Engine Detection
        if engine == "auto":
            if self._is_ollama_alive():
                self.engine = "ollama"
            elif self.groq_api_key:
                self.engine = "groq"
            else:
                self.engine = "bash" # No LLM available
                if verbose:
                    print_warning("No LLM engine found (Ollama or Groq). Analyst will be limited.")
        else:
            self.engine = engine

        # 2. Model Detection
        if model == "auto" and self.engine == "ollama":
            self.model = self._detect_best_ollama_model()
        elif model == "auto" and self.engine == "groq":
            self.model = "llama3-70b-8192"
        else:
            self.model = model if model != "auto" else "llama3.2"

    def ask(self, query: str, auto_run: bool = False) -> Any:
        """
        Ask a natural language question about the data.
        Returns the result of the generated code execution.
        """
        if self.verbose:
            print_step(f"AI Analyst ({self.engine}): Thinking about '{query}'...", "🧠")

        # 1. Build Prompt
        prompt = self._build_prompt(query)

        # 2. Get Code
        code = self._get_llm_code(prompt)
        if not code:
            print_warning("AI could not generate valid code.")
            return None

        # 3. Review before Run
        if not auto_run:
            if not self._user_approval(code):
                print_step("Execution cancelled by user.", "🚫")
                return None

        # 4. Execute
        if self.verbose:
            print_step("Executing analysis...", "⚡")
        
        return self._execute_code(code)

    def _build_prompt(self, query: str) -> str:
        try:
            head_str = self.df.head(3).to_markdown()
        except (ImportError, ModuleNotFoundError):
            head_str = str(self.df.head(3))

        summary = {
            "columns": list(self.df.columns),
            "dtypes": self.df.dtypes.astype(str).to_dict(),
            "head": head_str,
            "shape": self.df.shape
        }
        
        prompt = f"""
You are a world-class Python Data Analyst. Your goal is to write code using pandas to answer questions about a dataframe named 'df'.

DATASET SUMMARY:
- Shape: {summary['shape']}
- Columns: {summary['columns']}
- Sample Data:
{summary['head']}

USER QUESTION:
"{query}"

RULES:
1. Only return the Python code itself. 
2. Do not include markdown '```python' blocks.
3. Use the dataframe variable 'df'.
4. Ensure the last line of the code results in the final answer (or stores it in a variable 'result').
5. Do not perform destructive operations (dropping columns, unless asked).
6. If you need to plot, use matplotlib.

CODE:
"""
        return prompt

    def _get_llm_code(self, prompt: str) -> Optional[str]:
        if self.engine == "ollama":
            try:
                import ollama
                response = ollama.generate(model=self.model, prompt=prompt)
                code = response['response']
                return self._clean_code(code)
            except Exception as e:
                print_error(f"Ollama error: {e}")
                return None
        
        elif self.engine == "groq":
            try:
                import groq
                client = groq.Groq(api_key=self.groq_api_key)
                completion = client.chat.completions.create(
                    model=self.model,
                    messages=[{"role": "user", "content": prompt}]
                )
                code = completion.choices[0].message.content
                return self._clean_code(code)
            except Exception as e:
                print_error(f"Groq error: {e}")
                return None
        
        return None

    def _clean_code(self, code: str) -> str:
        # Remove markdown ticks if present
        code = re.sub(r"```python\n?", "", code)
        code = re.sub(r"```\n?", "", code)
        return code.strip()

    def _user_approval(self, code: str) -> bool:
        """Display code with Rich and ask for confirmation."""
        from rich.console import Console
        from rich.panel import Panel
        from rich.syntax import Syntax
        
        console = Console()
        syntax = Syntax(code, "python", theme="monokai", line_numbers=True)
        console.print("\n")
        console.print(Panel(syntax, title="AI Proposed Analysis", subtitle="[y] Run / [n] Cancel", border_style="cyan"))
        
        ans = input("  Run this code? (y/n): ").lower().strip()
        return ans == 'y'

    def _execute_code(self, code: str) -> Any:
        # Setup locals/globals for exec
        workspace = {"df": self.df.copy(), "result": None, "pd": pd}
        try:
            exec(code, {}, workspace)
            # If 'result' was not set, try to get the last expression?
            # For simplicity, we assume the code stores the answer in 'result' 
            # or it's the last line (handled by simple exec in some environments, but not pure Python).
            # We'll try to find 'result' or just return the modified df if that's what was intended.
            return workspace.get("result")
        except Exception as e:
            print_error(f"Analysis failed during execution: {e}")
            return None

    def _is_ollama_alive(self) -> bool:
        try:
            import ollama
            ollama.list()
            return True
        except Exception:
            return False

    def _detect_best_ollama_model(self) -> str:
        try:
            import ollama
            models = [m['name'] for m in ollama.list()['models']]
            priority = ["llama3.2:latest", "llama3.2", "llama3:latest", "llama3", "mistral"]
            for p in priority:
                if p in models:
                    return p
            return models[0] if models else "llama3.2"
        except Exception:
            return "llama3.2"


def print_error(msg: str):
    from mlpilot.utils.display import print_error as pe
    pe(msg)


def explain_data(df: pd.DataFrame, model: str = "llama3.2", verbose: bool = True):
    """
    Generates a 3-sentence non-technical executive summary of the data using AI.
    """
    from rich.console import Console
    from rich.panel import Panel
    import ollama

    # 1. Gather Stats
    stats = {
        "rows": len(df),
        "columns": list(df.columns),
        "numeric_summary": df.describe().to_dict(),
        "missing": df.isnull().sum().sum()
    }

    # 2. Ask AI
    prompt = f"""
    Write a professional 3-sentence executive summary of this dataset for a non-technical CEO.
    The data has {stats['rows']} rows and columns: {stats['columns']}.
    Total missing values: {stats['missing']}.
    Key stats: {stats['numeric_summary']}
    
    Make it sound business-intelligent and clear.
    """

    try:
        response = ollama.chat(model=model, messages=[{'role': 'user', 'content': prompt}])
        explanation = response['message']['content']
        
        # 3. Premium Display
        console = Console()
        console.print("\n")
        console.print(Panel(
            explanation,
            title="[bold blue]Executive Summary (Llama 3.2)[/bold blue]",
            border_style="blue",
            padding=(1, 2)
        ))
        return explanation
    except Exception as e:
        if verbose:
            print_error(f"Failed to generate story: {e}")
        return "Intelligence summary unavailable — check your Llama connection."
