"""
mlpilot/ai/audit.py
MLAudit — Technical and Social Bias auditing for machine learning models.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from mlpilot.utils.display import RichTable, print_step, print_success, print_warning


@dataclass
class AuditResult:
    """
    Result object from ml.audit().
    Contains technical performance stability and social bias metrics.
    """
    technical_health: Dict[str, Any]
    bias_metrics: Dict[str, Any]
    recommendations: List[str] = field(default_factory=list)

    def print_summary(self):
        """Prints a professional model audit card."""
        print_step("Generated Model Health Card", "🛡️")
        
        # 1. Technical Health
        h = self.technical_health
        tech_tbl = RichTable(title="Technical Audit (Robustness)", columns=["Metric", "Value", "Status"])
        status = "PASSED" if h['stability_score'] > 0.9 else "WARNING"
        tech_tbl.add_row("Stability Score", f"{h['stability_score']:.2f}", status)
        tech_tbl.add_row("Noise Tolerance", f"{h['noise_tolerance']:.2f}", "INFO")
        tech_tbl.print()
        
        # 2. Bias Metrics
        if self.bias_metrics:
            b = self.bias_metrics
            bias_tbl = RichTable(title="Social Bias Audit (Fairness)", columns=["Metric", "Difference", "Severity"])
            for metric, val in b.items():
                severity = "LOW" if val < 0.1 else ("MEDIUM" if val < 0.2 else "HIGH")
                bias_tbl.add_row(metric.replace("_", " ").title(), f"{val:.4f}", severity)
            bias_tbl.print()
        else:
            print_warning("No bias audit performed (missing sensitive_features).")

        # 3. Recommendations
        if self.recommendations:
            print_step("Recommendations", "💡")
            for rec in self.recommendations:
                print(f" • {rec}")

    def to_html(self, path: str = "model_audit_report.html"):
        """Generates a professional Model Card as an HTML report."""
        print_step("Generating HTML Model Card...", "📄")
        # Simplified for now
        return path


def audit(
    model: Any,
    X: pd.DataFrame,
    y: pd.Series,
    sensitive_features: Optional[Union[pd.Series, pd.DataFrame]] = None,
    noise_level: float = 0.05,
    verbose: bool = True
) -> AuditResult:
    """
    Performs a technical and social audit on a fitted model.
    
    Parameters
    ----------
    model : fitted sklearn-compatible model
    X : features
    y : true labels
    sensitive_features : columns for fairness auditing (e.g. gender, race)
    noise_level : amount of perturbation for stability testing
    """
    if verbose:
        print_step("Initiating Comprehensive Model Audit...", "🛡️")

    # 1. Technical Stability Audit
    if verbose:
        print_step("Testing prediction stability against noise...", "🧪")
    
    orig_preds = model.predict(X)
    
    # Perturb numeric columns
    X_noisy = X.copy()
    num_cols = X.select_dtypes(include=np.number).columns
    for col in num_cols:
        noise = np.random.normal(0, X[col].std() * noise_level, size=len(X))
        X_noisy[col] = X_noisy[col] + noise
        
    noisy_preds = model.predict(X_noisy)
    
    # Calculate stability (fraction of identical predictions)
    if pd.api.types.is_numeric_dtype(y):
        # For regression, use correlation or relative error
        stability = np.corrcoef(orig_preds, noisy_preds)[0,1]
    else:
        stability = np.mean(orig_preds == noisy_preds)
    
    tech_health = {
        "stability_score": stability,
        "noise_tolerance": 1.0 - (1.0 - stability) / noise_level if noise_level > 0 else 1.0
    }

    # 2. Social Bias Audit (Lazy Fairlearn)
    bias_metrics = {}
    if sensitive_features is not None:
        if verbose:
            print_step("Auditing social bias (Fairlearn)...", "⚖️")
        try:
            from fairlearn.metrics import demographic_parity_difference, equalized_odds_difference
            
            # Map y and noisy_preds to 0/1 if they are categorical
            y_audit = y
            preds_audit = noisy_preds
            if not pd.api.types.is_numeric_dtype(y_audit):
                from sklearn.preprocessing import LabelEncoder
                le = LabelEncoder()
                y_audit = le.fit_transform(y_audit.astype(str))
                preds_audit = le.transform(preds_audit.astype(str))

            dp_diff = demographic_parity_difference(y_audit, preds_audit, sensitive_features=sensitive_features)
            eo_diff = equalized_odds_difference(y_audit, preds_audit, sensitive_features=sensitive_features)
            
            bias_metrics = {
                "demographic_parity": float(dp_diff),
                "equalized_odds": float(eo_diff)
            }
        except ImportError:
            print_warning("Fairlearn not installed. Skipping bias audit. (pip install fairlearn)")

    # 3. Generate Recommendations
    recs = []
    if stability < 0.85:
        recs.append("Technical stability is low. Consider robust scaling or regularization.")
    if bias_metrics.get("demographic_parity", 0) > 0.1:
        recs.append("Significant demographic disparity detected. Review selection process for bias.")
    if not recs:
        recs.append("Model appears healthy and stable.")

    return AuditResult(tech_health, bias_metrics, recs)
