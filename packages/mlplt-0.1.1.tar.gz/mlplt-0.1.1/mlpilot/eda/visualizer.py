"""
mlpilot/eda/visualizer.py
SmartVisualizer — An intelligent plotting engine that auto-detects the best dashboard.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

import pandas as pd
from mlpilot.eda.plots import PlotEngine
from mlpilot.utils.display import print_step, print_success


class VisualResult:
    """
    Result object from ml.visualize().
    Stores all generated plotly/matplotlib figures for easy display.
    """

    def __init__(self, figures: Dict[str, Any]):
        self.figures = figures

    def show(self, key: Optional[str] = None):
        """Displays all figures or a specific one in a notebook."""
        try:
            from IPython.display import display
            if key:
                if key in self.figures:
                    display(self.figures[key])
                else:
                    print(f"Plot '{key}' not found.")
            else:
                for fig in self.figures.values():
                    display(fig)
        except ImportError:
            print("Not in a Jupyter environment. Use result.to_html() to view plots.")

    def to_html(self, path: str = "visual_dashboard.html"):
        """Saves all plots into a single HTML dashboard file."""
        # This is a placeholder for a more complex multi-plot HTML layout
        # For now, we utilize the first few plotly figures if available
        try:
            import plotly.io as pio
            from pathlib import Path
            
            html_content = "<html><head><title>mlpilot Visual Dashboard</title></head><body style='background:#1a1d2e; color:#e2e8f0; font-family:sans-serif;'>"
            html_content += "<h1 style='text-align:center;'>mlpilot Smart Dashboard</h1>"
            
            for name, fig in self.figures.items():
                if hasattr(fig, "to_html"):
                    html_content += f"<div style='margin-bottom:50px;'><h3>{name}</h3>"
                    html_content += fig.to_html(full_html=False, include_plotlyjs='cdn')
                    html_content += "</div>"
            
            html_content += "</body></html>"
            Path(path).write_text(html_content, encoding="utf-8")
            print_success(f"Dashboard saved to {path}")
            return path
        except ImportError:
            print("Plotly required for HTML dashboard.")
            return None


def visualize(
    df: pd.DataFrame,
    target: Optional[str] = None,
    backend: str = "plotly",
    sample_size: int = 1000,
) -> VisualResult:
    """
    Intelligently generates a visual suite for the dataset.
    
    Parameters
    ----------
    df : pd.DataFrame
        The data to visualize.
    target : str, optional
        Highlight relationships with the target column.
    backend : str
        'plotly' (interactive) or 'matplotlib'.
    sample_size : int
        Max rows to use for scatter/relationship plots.
    """
    print_step("Generating Smart Visualizations...", "✨")
    
    engine = PlotEngine(backend=backend)
    figs = {}
    
    # 1. Dataset Shape / Missingness
    print_step("Charting missingness...", "🧩")
    if df.isnull().any().any():
        figs["Missing Map"] = engine.missing_heatmap(df)
        
    # 2. Univariate Distribution (Top 8 columns)
    cols = df.columns.tolist()
    for col in cols[:8]:
        if col == target:
            continue
        print_step(f"Visualizing {col}...", "📊")
        if pd.api.types.is_numeric_dtype(df[col]):
            figs[f"Dist: {col}"] = engine.histogram(df[col])
        else:
            figs[f"Counts: {col}"] = engine.bar_chart(df[col])

    # 3. Target Relationships (if target provided)
    if target and target in df.columns:
        print_step(f"Analyzing relationships with {target}...", "🎯")
        figs["Target Dist"] = engine.target_distribution(df[target])
        
        # Sample for bivariate to keep speed
        sub_df = df.sample(min(len(df), sample_size))
        num_cols = df.select_dtypes(include="number").columns.tolist()
        
        for col in num_cols[:4]:
             if col != target:
                 figs[f"{col} vs {target}"] = engine.feature_vs_target(sub_df[col], sub_df[target])

    # 4. Correlation Matrix
    print_step("Building correlation map...", "🗺️")
    num_df = df.select_dtypes(include="number")
    if len(num_df.columns) >= 2:
        figs["Correlations"] = engine.correlation_heatmap(num_df.corr())

    print_success(f"Generated {len(figs)} intelligent plots.")
    return VisualResult(figs)
