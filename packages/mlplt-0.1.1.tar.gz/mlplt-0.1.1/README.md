# mlpilot 🚀
### The Complete Python ML Toolkit — Killing the Boilerplate.

[![PyPI version](https://badge.fury.io/py/mlplt.svg)](https://badge.fury.io/py/mlplt)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://github.com/yourusername/mlpilot/actions/workflows/test.yml/badge.svg)](https://github.com/yourusername/mlpilot/actions)

**mlpilot** is the definitive "all-in-one" library for machine learning practitioners. What currently takes 40 hours of repetitive coding, `mlpilot` delivers in 5 minutes. No dependency hell. No boilerplate. Just results.

---

## 📢 A Note from the Author
Hi! I'm **Anannya Vyas**, a student developer. 🎓

I didn't build **mlpilot** just to add another library to the pile. I built it because I was tired of writing the same 200 lines of null-handling, scaling, and correlation plotting for every single project. I wanted a library that "thinks" like a data scientist—making smart defaults while giving you full override control.

This project is my graduation milestone. It’s a journey from learning how to build a package to implementing local-first AI intelligence. Whether you are a student like me or a professional looking to move faster, I hope `mlpilot` saves you from the "boilerplate tax."

*Special thanks to my teacher **Lovnish Verma** for the inspiration and guidance.*

---

## 🚀 The mlpilot Advantage
**mlpilot** isn't just a library; it's a replacement for half your `requirements.txt`.

| Feature | mlpilot | Profiling | PyCaret | SHAP | Fairlearn |
|---|---|---|---|---|---|
| **Smart EDA Report** | ✅ | ✅ | ❌ | ❌ | ❌ |
| **Auto-Cleaning** | ✅ | ❌ | Partial | ❌ | ❌ |
| **Model Leaderboard** | ✅ | ❌ | ✅ | ❌ | ❌ |
| **Bias & Fairness Audit**| ✅ | ❌ | ❌ | ❌ | ✅ |
| **AI Data Analyst** | ✅ | ❌ | ❌ | ❌ | ❌ |
| **API Deployment** | ✅ | ❌ | ❌ | ❌ | ❌ |

---

## 🛠️ Prerequisites & Installation

### AI Features (Recommended)
`mlpilot` uses **local-first AI** to keep your data private.
1. Install [Ollama](https://ollama.com).
2. Run `ollama pull llama3.2` (or `llama3`).
3. Keep the Ollama app running to use `ml.analyst()` and `ml.explain_data()`.

### Installation
```bash
# Core installation
pip install mlplt

# Full suite (includes AI, NLP, and Deployment tools)
pip install mlplt[full]
```

---

## ⚡ Quick Start: The "Instant Analyst" Workflow
Solve a churn prediction problem from scratch in under 60 seconds of coding.

```python
import mlpilot as ml
import pandas as pd

# 1. Load your data
df = pd.read_csv("customer_data.csv")

# 2. Let the AI explain it in 3 sentences
ml.explain_data(df)

# 3. Auto-generate a premium dashboard
viz = ml.visualize(df, target="churn")
viz.to_html("insights.html")

# 4. Clean and Engineer (leakage-safe)
clean = ml.clean(df, target="churn")
feats = ml.features(clean.df, target="churn")

# 5. Training & Auditing
X_train, X_test, y_train, y_test = ml.split(feats, test_size=0.2)
base = ml.baseline(X_train, y_train)

# 6. Audit for Bias & Stability
audit = ml.audit(base.best_model, X_test, y_test)
audit.print_summary()

# 7. Generate your final Project Story
ml.story([df, base, audit])
```

---

## 🧠 The AI Brain: Intelligent ML

### 🔍 AI Analyst (`ml.analyst`)
Ask questions about your data in plain English. No more searching for pandas syntax.
> *"Which city has the highest average churn, and is it correlated with revenue?"*
> `mlpilot` generates the code, shows it to you for review, and runs it instantly.

### ⚖️ MLAudit (`ml.audit`)
Go beyond accuracy. Audit your models for:
*   **Technical Stability**: How does the model react to noise?
*   **Social Bias**: Check for Demographic Parity and Equalized Odds to ensure your model is fair to all groups.

### 📝 DataStory (`ml.story`)
Automatically synthesizes your EDA, Cleaning, Training, and Auditing results into a narrative report. Perfect for presentations!

---

## 📖 Complete API Reference

| Module | Function | Description |
|---|---|---|
| **EDA** | `ml.analyze(df)` | 12-section comprehensive report. |
| **Visualizer** | `ml.visualize(df)` | Intelligent auto-plotting dashboard. |
| **Cleaner** | `ml.clean(df)` | Auto-fix nulls, outliers, and dtypes. |
| **Validator** | `ml.validate(df)` | Check for leakage, drift, and schema errors. |
| **FeatureForge** | `ml.features(df)` | One-line encoding and scaling pipeline. |
| **Baseline** | `ml.baseline(X,y)` | 15+ model comparison leaderboard. |
| **Explainer** | `ml.explain(model,X)`| Global and local SHAP explanations. |
| **LaunchPad** | `ml.deploy(model)` | FastAPI + Docker in 5 minutes. |

---

## 📁 Project Structure
```text
mlpilot/
├── ai/          # Analyst, Audit, Story (The Brain)
├── clean/       # Cleaner, Strategies, Diff
├── eda/         # Analyzer, Visualizer, Plots
├── train/       # Baseline, HyperX, Evaluate
├── validate/    # Schema, Drift, Checks
└── deploy/      # LaunchPad, FastAPI
```

---

## 🤝 Contributing
Contributions are welcome! This is a student project, and I'd love to see how you improve it.
1. Fork the repo.
2. Install dev dependencies: `pip install -e ".[dev]"`
3. Run tests: `pytest tests/`

---

## 📄 License
Licensed under the **MIT License**. Use it, fork it, make it yours.

---

## ⭐ Show Your Support
If **mlpilot** helped you crush your project boilerplate:
*   ⭐ **Star the repo** on GitHub.
*   📢 **Share it** with your classmates.
*   🐛 **Report bugs** to help me learn and improve.

**Built with ❤️ for the ML community.**
