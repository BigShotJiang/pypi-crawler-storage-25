"""Session helpers for the Kanyun Sandbox v2 Python SDK."""

from __future__ import annotations

import threading

from .types import CreateSandboxRequest


class Session:
    def __init__(self, handle) -> None:
        self._handle = handle
        self._closed = False
        self._lock = threading.Lock()

    @property
    def info(self):
        return self._handle.info

    @property
    def agent(self):
        return self._handle.agent

    def detail(self):
        return self._handle.detail()

    def events(self):
        return self._handle.events()

    def refresh(self):
        return self._handle.refresh()

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
        self._handle.destroy()
        with self._lock:
            self._closed = True

    def __enter__(self) -> "Session":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()


class _SessionContextManager:
    def __init__(self, client, request: CreateSandboxRequest) -> None:
        self._client = client
        self._request = request
        self._session: Session | None = None

    def __enter__(self) -> Session:
        self._session = self._client.new_session(self._request)
        return self._session

    def __exit__(self, *_exc: object) -> None:
        if self._session is not None:
            self._session.close()
