"""Data types for the Kanyun Sandbox v2 Python SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


def _str_map(value: Any) -> dict[str, str] | None:
    return value if isinstance(value, dict) else None


def _obj(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _nullable_str(value: Any) -> str | None:
    return None if value is None else str(value)


@dataclass(slots=True)
class PublicEndpoint:
    name: str
    url: str
    host: str
    path: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "PublicEndpoint":
        return cls(
            name=str(payload.get("Name", payload.get("name", ""))),
            url=str(payload.get("URL", payload.get("url", ""))),
            host=str(payload.get("Host", payload.get("host", ""))),
            path=str(payload.get("Path", payload.get("path", ""))),
        )


@dataclass(slots=True)
class CreateSandboxRequest:
    template_name: str
    claim_name: str | None = None
    ttl_seconds: int | None = None
    metadata: dict[str, str] | None = None

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"templateName": self.template_name}
        if self.claim_name:
            payload["claimName"] = self.claim_name
        if self.ttl_seconds is not None:
            payload["ttlSeconds"] = self.ttl_seconds
        if self.metadata:
            payload["metadata"] = self.metadata
        return payload


@dataclass(slots=True)
class SandboxInfo:
    sandbox_name: str
    claim_name: str
    template_name: str
    status: str
    ip: str
    endpoint: str
    created_at: str
    expires_at: str
    released_at: str | None
    release_reason: str
    failure_reason: str
    public_endpoints: list[PublicEndpoint] = field(default_factory=list)

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "SandboxInfo":
        endpoints = payload.get("PublicEndpoints")
        return cls(
            sandbox_name=str(payload.get("SandboxName", "")),
            claim_name=str(payload.get("ClaimName", "")),
            template_name=str(payload.get("TemplateName", "")),
            status=str(payload.get("Status", "")),
            ip=str(payload.get("IP", "")),
            endpoint=str(payload.get("Endpoint", "")),
            created_at=str(payload.get("CreatedAt", "")),
            expires_at=str(payload.get("ExpiresAt", "")),
            released_at=None if payload.get("ReleasedAt") is None else str(payload.get("ReleasedAt")),
            release_reason=str(payload.get("ReleaseReason", "")),
            failure_reason=str(payload.get("FailureReason", "")),
            public_endpoints=[
                PublicEndpoint.from_payload(item) for item in endpoints if isinstance(item, dict)
            ]
            if isinstance(endpoints, list)
            else [],
        )


@dataclass(slots=True)
class SandboxDetail(SandboxInfo):
    metadata: dict[str, str] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "SandboxDetail":
        info = SandboxInfo.from_payload(payload)
        metadata = payload.get("Metadata")
        return cls(
            sandbox_name=info.sandbox_name,
            claim_name=info.claim_name,
            template_name=info.template_name,
            status=info.status,
            ip=info.ip,
            endpoint=info.endpoint,
            created_at=info.created_at,
            expires_at=info.expires_at,
            released_at=info.released_at,
            release_reason=info.release_reason,
            failure_reason=info.failure_reason,
            public_endpoints=info.public_endpoints,
            metadata=metadata if isinstance(metadata, dict) else None,
        )


@dataclass(slots=True)
class SandboxEvent:
    event_id: str
    aggregate_type: str
    aggregate_id: str
    sandbox_name: str
    claim_name: str
    event_type: str
    occurred_at: str
    actor: str
    reason: str
    payload: dict[str, Any] | None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "SandboxEvent":
        raw = payload.get("Payload")
        return cls(
            event_id=str(payload.get("EventID", "")),
            aggregate_type=str(payload.get("AggregateType", "")),
            aggregate_id=str(payload.get("AggregateID", "")),
            sandbox_name=str(payload.get("SandboxName", "")),
            claim_name=str(payload.get("ClaimName", "")),
            event_type=str(payload.get("EventType", "")),
            occurred_at=str(payload.get("OccurredAt", "")),
            actor=str(payload.get("Actor", "")),
            reason=str(payload.get("Reason", "")),
            payload=raw if isinstance(raw, dict) else None,
        )


@dataclass(slots=True)
class TemplateRecord:
    name: str
    runtime_profile_id: str
    display_name: str
    description: str
    default_ttl_seconds: int
    max_ttl_seconds: int
    enabled: bool
    metadata: dict[str, str] | None
    labels: dict[str, str] | None
    annotations: dict[str, str] | None
    created_by: str
    created_at: str
    updated_at: str
    pod_template: dict[str, Any]
    network_policy: dict[str, Any] | None
    ingresses: list["TemplateIngress"]

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "TemplateRecord":
        ingresses = payload.get("Ingresses")
        return cls(
            name=str(payload.get("Name", "")),
            runtime_profile_id=str(payload.get("RuntimeProfileID", "")),
            display_name=str(payload.get("DisplayName", "")),
            description=str(payload.get("Description", "")),
            default_ttl_seconds=int(payload.get("DefaultTTLSeconds", 0)),
            max_ttl_seconds=int(payload.get("MaxTTLSeconds", 0)),
            enabled=bool(payload.get("Enabled", False)),
            metadata=_str_map(payload.get("Metadata")),
            labels=_str_map(payload.get("Labels")),
            annotations=_str_map(payload.get("Annotations")),
            created_by=str(payload.get("CreatedBy", "")),
            created_at=str(payload.get("CreatedAt", "")),
            updated_at=str(payload.get("UpdatedAt", "")),
            pod_template=_obj(payload.get("PodTemplate")),
            network_policy=payload.get("NetworkPolicy") if isinstance(payload.get("NetworkPolicy"), dict) else None,
            ingresses=[
                TemplateIngress.from_payload(item) for item in ingresses if isinstance(item, dict)
            ]
            if isinstance(ingresses, list)
            else [],
        )


@dataclass(slots=True)
class TemplateIngressBackendResource:
    api_group: str
    kind: str
    name: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "TemplateIngressBackendResource":
        return cls(
            api_group=str(payload.get("apiGroup", "")),
            kind=str(payload.get("kind", "")),
            name=str(payload.get("name", "")),
        )


@dataclass(slots=True)
class TemplateIngressBackend:
    type: str
    port: int
    resource: TemplateIngressBackendResource | None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "TemplateIngressBackend":
        resource = payload.get("resource")
        return cls(
            type=str(payload.get("type", "")),
            port=int(payload.get("port", 0)),
            resource=TemplateIngressBackendResource.from_payload(resource)
            if isinstance(resource, dict)
            else None,
        )


@dataclass(slots=True)
class TemplateIngress:
    name: str
    host_prefix: str
    path: str
    path_type: str
    backend: TemplateIngressBackend
    annotations: dict[str, str] | None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "TemplateIngress":
        return cls(
            name=str(payload.get("name", "")),
            host_prefix=str(payload.get("hostPrefix", "")),
            path=str(payload.get("path", "")),
            path_type=str(payload.get("pathType", "")),
            backend=TemplateIngressBackend.from_payload(_obj(payload.get("backend"))),
            annotations=_str_map(payload.get("annotations")),
        )


@dataclass(slots=True)
class TemplateMaterialization:
    id: str
    template_name: str
    runtime_profile_id: str
    cluster_id: str
    namespace: str
    runtime_template_name: str
    template_updated_at: str
    pull_secret_materialization_id: str
    pull_secret_name: str
    pull_secret_version: int
    status: str
    last_error: str
    last_materialized_at: str | None
    created_at: str
    updated_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "TemplateMaterialization":
        return cls(
            id=str(payload.get("id", "")),
            template_name=str(payload.get("templateName", "")),
            runtime_profile_id=str(payload.get("runtimeProfileId", "")),
            cluster_id=str(payload.get("clusterId", "")),
            namespace=str(payload.get("namespace", "")),
            runtime_template_name=str(payload.get("runtimeTemplateName", "")),
            template_updated_at=str(payload.get("templateUpdatedAt", "")),
            pull_secret_materialization_id=str(payload.get("pullSecretMaterializationId", "")),
            pull_secret_name=str(payload.get("pullSecretName", "")),
            pull_secret_version=int(payload.get("pullSecretVersion", 0)),
            status=str(payload.get("status", "")),
            last_error=str(payload.get("lastError", "")),
            last_materialized_at=_nullable_str(payload.get("lastMaterializedAt")),
            created_at=str(payload.get("createdAt", "")),
            updated_at=str(payload.get("updatedAt", "")),
        )


@dataclass(slots=True)
class WarmPoolRecord:
    name: str
    template_name: str
    desired_replicas: int
    current_replicas: int
    ready_replicas: int
    labels: dict[str, str] | None
    annotations: dict[str, str] | None
    created_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "WarmPoolRecord":
        return cls(
            name=str(payload.get("Name", "")),
            template_name=str(payload.get("TemplateName", "")),
            desired_replicas=int(payload.get("DesiredReplicas", 0)),
            current_replicas=int(payload.get("CurrentReplicas", 0)),
            ready_replicas=int(payload.get("ReadyReplicas", 0)),
            labels=_str_map(payload.get("Labels")),
            annotations=_str_map(payload.get("Annotations")),
            created_at=str(payload.get("CreatedAt", "")),
        )


@dataclass(slots=True)
class SandboxHistoryRecord:
    claim_name: str
    sandbox_name: str
    template_name: str
    status: str
    ip: str
    endpoint: str
    created_at: str
    deleted_at: str | None
    failure_reason: str
    metadata: dict[str, str] | None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "SandboxHistoryRecord":
        return cls(
            claim_name=str(payload.get("ClaimName", "")),
            sandbox_name=str(payload.get("SandboxName", "")),
            template_name=str(payload.get("TemplateName", "")),
            status=str(payload.get("Status", "")),
            ip=str(payload.get("IP", "")),
            endpoint=str(payload.get("Endpoint", "")),
            created_at=str(payload.get("CreatedAt", "")),
            deleted_at=_nullable_str(payload.get("DeletedAt")),
            failure_reason=str(payload.get("FailureReason", "")),
            metadata=_str_map(payload.get("Metadata")),
        )


@dataclass(slots=True)
class SandboxHistoryList:
    sandboxes: list[SandboxHistoryRecord]
    total: int

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "SandboxHistoryList":
        sandboxes = payload.get("sandboxes")
        return cls(
            sandboxes=[
                SandboxHistoryRecord.from_payload(item) for item in sandboxes if isinstance(item, dict)
            ]
            if isinstance(sandboxes, list)
            else [],
            total=int(payload.get("total", 0)),
        )


@dataclass(slots=True)
class SandboxHistoryEvent:
    event_id: str
    sandbox_id: str
    event_type: str
    occurred_at: str
    actor: str
    reason: str
    payload: dict[str, Any] | None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "SandboxHistoryEvent":
        return cls(
            event_id=str(payload.get("eventId", payload.get("EventID", ""))),
            sandbox_id=str(payload.get("sandboxId", payload.get("SandboxID", ""))),
            event_type=str(payload.get("eventType", payload.get("EventType", ""))),
            occurred_at=str(payload.get("occurredAt", payload.get("OccurredAt", ""))),
            actor=str(payload.get("actor", payload.get("Actor", ""))),
            reason=str(payload.get("reason", payload.get("Reason", ""))),
            payload=payload.get("payload", payload.get("Payload"))
            if isinstance(payload.get("payload", payload.get("Payload")), dict)
            else None,
        )


@dataclass(slots=True)
class SandboxHistoryDetail:
    record: SandboxHistoryRecord
    events: list[SandboxHistoryEvent]

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "SandboxHistoryDetail":
        record = payload.get("record", payload.get("sandbox"))
        events = payload.get("events")
        return cls(
            record=SandboxHistoryRecord.from_payload(record if isinstance(record, dict) else {}),
            events=[
                SandboxHistoryEvent.from_payload(item) for item in events if isinstance(item, dict)
            ]
            if isinstance(events, list)
            else [],
        )


@dataclass(slots=True)
class Cluster:
    id: str
    display_name: str
    description: str
    kube_config_secret_id: str
    status: str
    labels: dict[str, str] | None
    created_at: str
    updated_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "Cluster":
        return cls(
            id=str(payload.get("id", "")),
            display_name=str(payload.get("displayName", "")),
            description=str(payload.get("description", "")),
            kube_config_secret_id=str(payload.get("kubeConfigSecretId", "")),
            status=str(payload.get("status", "")),
            labels=_str_map(payload.get("labels")),
            created_at=str(payload.get("createdAt", "")),
            updated_at=str(payload.get("updatedAt", "")),
        )


@dataclass(slots=True)
class RuntimeProfile:
    id: str
    cluster_id: str
    namespace: str
    default_registry_profile_id: str
    default_ttl_seconds: int
    max_ttl_seconds: int
    status: str
    labels: dict[str, str] | None
    created_at: str
    updated_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "RuntimeProfile":
        return cls(
            id=str(payload.get("id", "")),
            cluster_id=str(payload.get("clusterId", "")),
            namespace=str(payload.get("namespace", "")),
            default_registry_profile_id=str(payload.get("defaultRegistryProfileId", "")),
            default_ttl_seconds=int(payload.get("defaultTTLSeconds", 0)),
            max_ttl_seconds=int(payload.get("maxTTLSeconds", 0)),
            status=str(payload.get("status", "")),
            labels=_str_map(payload.get("labels")),
            created_at=str(payload.get("createdAt", "")),
            updated_at=str(payload.get("updatedAt", "")),
        )


@dataclass(slots=True)
class BuildProfile:
    id: str
    cluster_id: str
    namespace: str
    builder_image: str
    registry_profile_id: str
    default_timeout_seconds: int
    status: str
    created_at: str
    updated_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "BuildProfile":
        return cls(
            id=str(payload.get("id", "")),
            cluster_id=str(payload.get("clusterId", "")),
            namespace=str(payload.get("namespace", "")),
            builder_image=str(payload.get("builderImage", "")),
            registry_profile_id=str(payload.get("registryProfileId", "")),
            default_timeout_seconds=int(payload.get("defaultTimeoutSeconds", 0)),
            status=str(payload.get("status", "")),
            created_at=str(payload.get("createdAt", "")),
            updated_at=str(payload.get("updatedAt", "")),
        )


@dataclass(slots=True)
class RegistryProfile:
    id: str
    registry: str
    namespace_prefix: str
    credential_secret_id: str
    created_at: str
    updated_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "RegistryProfile":
        return cls(
            id=str(payload.get("id", "")),
            registry=str(payload.get("registry", "")),
            namespace_prefix=str(payload.get("namespacePrefix", "")),
            credential_secret_id=str(payload.get("credentialSecretId", "")),
            created_at=str(payload.get("createdAt", "")),
            updated_at=str(payload.get("updatedAt", "")),
        )


@dataclass(slots=True)
class SecretProfile:
    id: str
    type: str
    version: int
    created_by: str
    created_at: str
    updated_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "SecretProfile":
        return cls(
            id=str(payload.get("id", "")),
            type=str(payload.get("type", "")),
            version=int(payload.get("version", 0)),
            created_by=str(payload.get("createdBy", "")),
            created_at=str(payload.get("createdAt", "")),
            updated_at=str(payload.get("updatedAt", "")),
        )


@dataclass(slots=True)
class SecretMaterialization:
    id: str
    secret_profile_id: str
    secret_profile_version: int
    cluster_id: str
    namespace: str
    k8s_secret_name: str
    purpose: str
    status: str
    last_synced_at: str | None
    last_error: str
    created_at: str
    updated_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "SecretMaterialization":
        return cls(
            id=str(payload.get("id", "")),
            secret_profile_id=str(payload.get("secretProfileId", "")),
            secret_profile_version=int(payload.get("secretProfileVersion", 0)),
            cluster_id=str(payload.get("clusterId", "")),
            namespace=str(payload.get("namespace", "")),
            k8s_secret_name=str(payload.get("k8sSecretName", "")),
            purpose=str(payload.get("purpose", "")),
            status=str(payload.get("status", "")),
            last_synced_at=_nullable_str(payload.get("lastSyncedAt")),
            last_error=str(payload.get("lastError", "")),
            created_at=str(payload.get("createdAt", "")),
            updated_at=str(payload.get("updatedAt", "")),
        )


@dataclass(slots=True)
class ImageBuild:
    id: str
    status: str
    image_asset_id: str
    build_profile_id: str
    registry_profile_id: str
    source_ref: str
    image_ref: str
    created_at: str
    updated_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ImageBuild":
        return cls(
            id=str(payload.get("id", "")),
            status=str(payload.get("status", "")),
            image_asset_id=str(payload.get("imageAssetId", "")),
            build_profile_id=str(payload.get("buildProfileId", "")),
            registry_profile_id=str(payload.get("registryProfileId", "")),
            source_ref=str(payload.get("sourceRef", "")),
            image_ref=str(payload.get("imageRef", "")),
            created_at=str(payload.get("createdAt", "")),
            updated_at=str(payload.get("updatedAt", "")),
        )


@dataclass(slots=True)
class ImageBuildLogLine:
    id: int
    build_id: str
    line: str
    stream: str
    occurred_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ImageBuildLogLine":
        return cls(
            id=int(payload.get("id", 0)),
            build_id=str(payload.get("buildId", "")),
            line=str(payload.get("line", "")),
            stream=str(payload.get("stream", "")),
            occurred_at=str(payload.get("occurredAt", "")),
        )


@dataclass(slots=True)
class ImageAsset:
    id: str
    logical_name: str
    registry_profile_id: str
    build_profile_id: str
    repository: str
    latest_image_ref: str
    latest_digest: str
    description: str
    labels: dict[str, str] | None
    created_at: str
    updated_at: str

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ImageAsset":
        return cls(
            id=str(payload.get("id", "")),
            logical_name=str(payload.get("logicalName", "")),
            registry_profile_id=str(payload.get("registryProfileId", "")),
            build_profile_id=str(payload.get("buildProfileId", "")),
            repository=str(payload.get("repository", "")),
            latest_image_ref=str(payload.get("latestImageRef", "")),
            latest_digest=str(payload.get("latestDigest", "")),
            description=str(payload.get("description", "")),
            labels=_str_map(payload.get("labels")),
            created_at=str(payload.get("createdAt", "")),
            updated_at=str(payload.get("updatedAt", "")),
        )
