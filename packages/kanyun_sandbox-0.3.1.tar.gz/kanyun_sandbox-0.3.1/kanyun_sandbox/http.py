"""HTTP transport for the Kanyun Sandbox v2 Python SDK."""

from __future__ import annotations

from typing import Any

import httpx

from .errors import (
    APIError,
    AuthenticationError,
    ConflictError,
    NotFoundError,
    ValidationError,
)


class HTTPTransport:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str,
        client: httpx.Client | None = None,
        timeout: float = 60.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._client = client or httpx.Client(timeout=timeout)
        self._owns_client = client is None

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "HTTPTransport":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def request_json(
        self,
        method: str,
        path: str,
        *,
        body: dict[str, Any] | None = None,
    ) -> Any:
        response = self._client.request(
            method,
            self._build_url(path),
            json=body,
            headers=self._build_headers(body),
        )
        if response.status_code == 204:
            raise APIError("expected response body but received 204 No Content", 204)

        payload = self._parse_payload(response)
        if response.is_error:
            raise self._to_error(response.status_code, payload, response.reason_phrase)
        return payload

    def request_no_content(
        self,
        method: str,
        path: str,
        *,
        body: dict[str, Any] | None = None,
    ) -> None:
        response = self._client.request(
            method,
            self._build_url(path),
            json=body,
            headers=self._build_headers(body),
        )
        if response.status_code == 204:
            return

        payload = self._parse_payload(response)
        if response.is_error:
            raise self._to_error(response.status_code, payload, response.reason_phrase)

    def _build_url(self, path: str) -> str:
        if path.startswith("/"):
            return f"{self._base_url}{path}"
        return f"{self._base_url}/{path}"

    def _build_headers(self, body: dict[str, Any] | None) -> dict[str, str]:
        headers = {"Accept": "application/json", "X-API-Key": self._api_key}
        if body is not None:
            headers["Content-Type"] = "application/json"
        return headers

    def _parse_payload(self, response: httpx.Response) -> Any:
        content_type = response.headers.get("Content-Type", "")
        if "application/json" in content_type:
            return response.json()
        text = response.text
        if not text:
            return {}
        try:
            return response.json()
        except ValueError:
            return {"error": {"message": text}}

    def _to_error(self, status_code: int, payload: Any, fallback: str) -> APIError:
        error = payload.get("error") if isinstance(payload, dict) else None
        message = fallback or "request failed"
        code = None
        if isinstance(error, dict):
            message = str(error.get("message") or message)
            code = error.get("code")

        if status_code == 400:
            return ValidationError(message, status_code, code)
        if status_code == 401:
            return AuthenticationError(message, status_code, code)
        if status_code == 404:
            return NotFoundError(message, status_code, code)
        if status_code == 409:
            return ConflictError(message, status_code, code)
        return APIError(message, status_code, code)
