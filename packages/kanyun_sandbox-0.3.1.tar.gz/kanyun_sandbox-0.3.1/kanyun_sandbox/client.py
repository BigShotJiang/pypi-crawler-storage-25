"""Client for the Kanyun Sandbox v2 Python SDK."""

from __future__ import annotations

from contextlib import AbstractContextManager
from typing import Any, Callable
from urllib.parse import quote, urlencode

import httpx

from .handle import SandboxHandle
from .http import HTTPTransport
from .session import Session, _SessionContextManager
from .types import (
    BuildProfile,
    Cluster,
    CreateSandboxRequest,
    ImageAsset,
    ImageBuild,
    ImageBuildLogLine,
    RegistryProfile,
    SandboxDetail,
    SandboxEvent,
    SandboxHistoryDetail,
    SandboxHistoryList,
    SandboxInfo,
    SecretMaterialization,
    SecretProfile,
    RuntimeProfile,
    TemplateRecord,
    TemplateMaterialization,
    WarmPoolRecord,
)

AgentFactory = Callable[[str], Any]


class Client(AbstractContextManager["Client"]):
    def __init__(
        self,
        *,
        control_plane_url: str,
        api_key: str,
        http_client: httpx.Client | None = None,
        agent_client_factory: AgentFactory | None = None,
        agent_port: int = 8080,
        timeout: float = 60.0,
    ) -> None:
        self._transport = HTTPTransport(
            base_url=control_plane_url,
            api_key=api_key,
            client=http_client,
            timeout=timeout,
        )
        self._agent_client_factory = agent_client_factory
        self._agent_port = agent_port

    def close(self) -> None:
        self._transport.close()

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def create_sandbox(self, request: CreateSandboxRequest) -> SandboxHandle:
        payload = self._transport.request_json(
            "POST",
            "/api/v2/sandboxes",
            body=request.to_payload(),
        )
        return SandboxHandle(
            SandboxInfo.from_payload(payload),
            client=self,
            agent_client_factory=self._agent_client_factory,
            agent_port=self._agent_port,
        )

    def get_sandbox(self, sandbox_id: str) -> SandboxInfo:
        payload = self._transport.request_json(
            "GET",
            f"/api/v2/sandboxes/{quote(sandbox_id, safe='')}",
        )
        return SandboxInfo.from_payload(payload)

    def list_sandboxes(self) -> list[SandboxInfo]:
        payload = self._transport.request_json("GET", "/api/v2/sandboxes")
        return [SandboxInfo.from_payload(item) for item in payload]

    def get_sandbox_detail(self, sandbox_id: str) -> SandboxDetail:
        payload = self._transport.request_json(
            "GET",
            f"/api/v2/sandboxes/{quote(sandbox_id, safe='')}/detail",
        )
        return SandboxDetail.from_payload(payload)

    def list_sandbox_events(self, sandbox_id: str) -> list[SandboxEvent]:
        payload = self._transport.request_json(
            "GET",
            f"/api/v2/sandboxes/{quote(sandbox_id, safe='')}/events",
        )
        return [SandboxEvent.from_payload(item) for item in payload]

    def delete_sandbox(self, sandbox_id: str) -> None:
        self._transport.request_no_content(
            "DELETE",
            f"/api/v2/sandboxes/{quote(sandbox_id, safe='')}",
        )

    def extend_sandbox(self, sandbox_id: str, ttl_seconds: int) -> None:
        self._transport.request_no_content(
            "PATCH",
            f"/api/v2/sandboxes/{quote(sandbox_id, safe='')}",
            body={"ttlSeconds": ttl_seconds},
        )

    def connect_sandbox(self, sandbox_id: str) -> SandboxHandle:
        return SandboxHandle(
            self.get_sandbox(sandbox_id),
            client=self,
            agent_client_factory=self._agent_client_factory,
            agent_port=self._agent_port,
        )

    def new_session(self, request: CreateSandboxRequest) -> Session:
        return Session(self.create_sandbox(request))

    def run_session(
        self,
        template_name: str,
        *,
        claim_name: str | None = None,
        ttl_seconds: int | None = None,
        metadata: dict[str, str] | None = None,
    ) -> _SessionContextManager:
        return _SessionContextManager(
            self,
            CreateSandboxRequest(
                template_name=template_name,
                claim_name=claim_name,
                ttl_seconds=ttl_seconds,
                metadata=metadata,
            ),
        )

    def list_templates(self) -> list[TemplateRecord]:
        payload = self._transport.request_json("GET", "/api/v2/templates")
        return [TemplateRecord.from_payload(item) for item in payload]

    def get_template(self, template_name: str) -> TemplateRecord:
        payload = self._transport.request_json(
            "GET",
            f"/api/v2/templates/{quote(template_name, safe='')}",
        )
        return TemplateRecord.from_payload(payload)

    def apply_template(self, template_name: str, request: dict[str, Any]) -> TemplateRecord:
        payload = self._transport.request_json(
            "PUT",
            f"/api/v2/templates/{quote(template_name, safe='')}",
            body=request,
        )
        return TemplateRecord.from_payload(payload)

    def delete_template(self, template_name: str) -> None:
        self._transport.request_no_content(
            "DELETE",
            f"/api/v2/templates/{quote(template_name, safe='')}",
        )

    def list_template_materializations(self, template_name: str) -> list[TemplateMaterialization]:
        payload = self._transport.request_json(
            "GET",
            f"/api/v2/templates/{quote(template_name, safe='')}/materializations",
        )
        return [TemplateMaterialization.from_payload(item) for item in payload]

    def resync_template_materialization(self, template_name: str) -> TemplateMaterialization:
        payload = self._transport.request_json(
            "POST",
            f"/api/v2/templates/{quote(template_name, safe='')}/materializations/resync",
        )
        return TemplateMaterialization.from_payload(payload)

    def list_warm_pools(self) -> list[WarmPoolRecord]:
        payload = self._transport.request_json("GET", "/api/v2/warm-pools")
        return [WarmPoolRecord.from_payload(item) for item in payload]

    def get_warm_pool(self, name: str) -> WarmPoolRecord:
        payload = self._transport.request_json("GET", f"/api/v2/warm-pools/{quote(name, safe='')}")
        return WarmPoolRecord.from_payload(payload)

    def apply_warm_pool(self, name: str, request: dict[str, Any]) -> WarmPoolRecord:
        payload = self._transport.request_json(
            "PUT",
            f"/api/v2/warm-pools/{quote(name, safe='')}",
            body=request,
        )
        return WarmPoolRecord.from_payload(payload)

    def delete_warm_pool(self, name: str) -> None:
        self._transport.request_no_content("DELETE", f"/api/v2/warm-pools/{quote(name, safe='')}")

    def list_sandbox_history(
        self,
        *,
        page: int | None = None,
        page_size: int | None = None,
        status: str | None = None,
        template_name: str | None = None,
    ) -> SandboxHistoryList:
        query = urlencode(
            {
                key: value
                for key, value in {
                    "page": page,
                    "pageSize": page_size,
                    "status": status,
                    "templateName": template_name,
                }.items()
                if value is not None and value != ""
            }
        )
        path = "/api/v2/sandbox-history" if not query else f"/api/v2/sandbox-history?{query}"
        payload = self._transport.request_json("GET", path)
        return SandboxHistoryList.from_payload(payload)

    def get_sandbox_history(self, sandbox_id: str) -> SandboxHistoryDetail:
        payload = self._transport.request_json(
            "GET",
            f"/api/v2/sandbox-history/{quote(sandbox_id, safe='')}",
        )
        return SandboxHistoryDetail.from_payload(payload)

    def list_clusters(self) -> list[Cluster]:
        payload = self._transport.request_json("GET", "/api/v2/clusters")
        return [Cluster.from_payload(item) for item in payload]

    def get_cluster(self, cluster_id: str) -> Cluster:
        payload = self._transport.request_json("GET", f"/api/v2/clusters/{quote(cluster_id, safe='')}")
        return Cluster.from_payload(payload)

    def create_cluster(self, request: dict[str, Any]) -> Cluster:
        payload = self._transport.request_json("POST", "/api/v2/clusters", body=request)
        return Cluster.from_payload(payload)

    def upsert_cluster(self, cluster_id: str, request: dict[str, Any]) -> Cluster:
        payload = self._transport.request_json(
            "PUT",
            f"/api/v2/clusters/{quote(cluster_id, safe='')}",
            body=request,
        )
        return Cluster.from_payload(payload)

    def delete_cluster(self, cluster_id: str) -> None:
        self._transport.request_no_content("DELETE", f"/api/v2/clusters/{quote(cluster_id, safe='')}")

    def list_runtime_profiles(self) -> list[RuntimeProfile]:
        payload = self._transport.request_json("GET", "/api/v2/runtime-profiles")
        return [RuntimeProfile.from_payload(item) for item in payload]

    def get_runtime_profile(self, profile_id: str) -> RuntimeProfile:
        payload = self._transport.request_json(
            "GET",
            f"/api/v2/runtime-profiles/{quote(profile_id, safe='')}",
        )
        return RuntimeProfile.from_payload(payload)

    def create_runtime_profile(self, request: dict[str, Any]) -> RuntimeProfile:
        payload = self._transport.request_json("POST", "/api/v2/runtime-profiles", body=request)
        return RuntimeProfile.from_payload(payload)

    def upsert_runtime_profile(self, profile_id: str, request: dict[str, Any]) -> RuntimeProfile:
        payload = self._transport.request_json(
            "PUT",
            f"/api/v2/runtime-profiles/{quote(profile_id, safe='')}",
            body=request,
        )
        return RuntimeProfile.from_payload(payload)

    def delete_runtime_profile(self, profile_id: str) -> None:
        self._transport.request_no_content(
            "DELETE",
            f"/api/v2/runtime-profiles/{quote(profile_id, safe='')}",
        )

    def create_secret_profile(self, request: dict[str, Any]) -> SecretProfile:
        payload = self._transport.request_json("POST", "/api/v2/secret-profiles", body=request)
        return SecretProfile.from_payload(payload)

    def list_secret_profiles(self) -> list[SecretProfile]:
        payload = self._transport.request_json("GET", "/api/v2/secret-profiles")
        return [SecretProfile.from_payload(item) for item in payload]

    def get_secret_profile(self, profile_id: str) -> SecretProfile:
        payload = self._transport.request_json("GET", f"/api/v2/secret-profiles/{quote(profile_id, safe='')}")
        return SecretProfile.from_payload(payload)

    def upsert_secret_profile(self, profile_id: str, request: dict[str, Any]) -> SecretProfile:
        payload = self._transport.request_json(
            "PUT",
            f"/api/v2/secret-profiles/{quote(profile_id, safe='')}",
            body=request,
        )
        return SecretProfile.from_payload(payload)

    def list_secret_materializations(self, secret_profile_id: str) -> list[SecretMaterialization]:
        payload = self._transport.request_json(
            "GET",
            f"/api/v2/secret-profiles/{quote(secret_profile_id, safe='')}/materializations",
        )
        return [SecretMaterialization.from_payload(item) for item in payload]

    def rotate_secret_profile(self, secret_profile_id: str, request: dict[str, Any]) -> SecretProfile:
        payload = self._transport.request_json(
            "POST",
            f"/api/v2/secret-profiles/{quote(secret_profile_id, safe='')}/rotate",
            body=request,
        )
        return SecretProfile.from_payload(payload)

    def delete_secret_profile(self, profile_id: str) -> None:
        self._transport.request_no_content("DELETE", f"/api/v2/secret-profiles/{quote(profile_id, safe='')}")

    def resync_secret_materialization(
        self,
        secret_profile_id: str,
        materialization_id: str,
    ) -> SecretMaterialization:
        payload = self._transport.request_json(
            "POST",
            f"/api/v2/secret-profiles/{quote(secret_profile_id, safe='')}/materializations/{quote(materialization_id, safe='')}/resync",
        )
        return SecretMaterialization.from_payload(payload)

    def create_build_profile(self, request: dict[str, Any]) -> BuildProfile:
        payload = self._transport.request_json("POST", "/api/v2/build-profiles", body=request)
        return BuildProfile.from_payload(payload)

    def list_build_profiles(self) -> list[BuildProfile]:
        payload = self._transport.request_json("GET", "/api/v2/build-profiles")
        return [BuildProfile.from_payload(item) for item in payload]

    def get_build_profile(self, profile_id: str) -> BuildProfile:
        payload = self._transport.request_json("GET", f"/api/v2/build-profiles/{quote(profile_id, safe='')}")
        return BuildProfile.from_payload(payload)

    def upsert_build_profile(self, profile_id: str, request: dict[str, Any]) -> BuildProfile:
        payload = self._transport.request_json(
            "PUT",
            f"/api/v2/build-profiles/{quote(profile_id, safe='')}",
            body=request,
        )
        return BuildProfile.from_payload(payload)

    def delete_build_profile(self, profile_id: str) -> None:
        self._transport.request_no_content("DELETE", f"/api/v2/build-profiles/{quote(profile_id, safe='')}")

    def create_registry_profile(self, request: dict[str, Any]) -> RegistryProfile:
        payload = self._transport.request_json("POST", "/api/v2/registry-profiles", body=request)
        return RegistryProfile.from_payload(payload)

    def list_registry_profiles(self) -> list[RegistryProfile]:
        payload = self._transport.request_json("GET", "/api/v2/registry-profiles")
        return [RegistryProfile.from_payload(item) for item in payload]

    def get_registry_profile(self, profile_id: str) -> RegistryProfile:
        payload = self._transport.request_json("GET", f"/api/v2/registry-profiles/{quote(profile_id, safe='')}")
        return RegistryProfile.from_payload(payload)

    def upsert_registry_profile(self, profile_id: str, request: dict[str, Any]) -> RegistryProfile:
        payload = self._transport.request_json(
            "PUT",
            f"/api/v2/registry-profiles/{quote(profile_id, safe='')}",
            body=request,
        )
        return RegistryProfile.from_payload(payload)

    def delete_registry_profile(self, profile_id: str) -> None:
        self._transport.request_no_content("DELETE", f"/api/v2/registry-profiles/{quote(profile_id, safe='')}")

    def create_image_build(self, request: dict[str, Any]) -> ImageBuild:
        payload = self._transport.request_json("POST", "/api/v2/image-builds", body=request)
        return ImageBuild.from_payload(payload)

    def list_image_builds(self) -> list[ImageBuild]:
        payload = self._transport.request_json("GET", "/api/v2/image-builds")
        return [ImageBuild.from_payload(item) for item in payload]

    def get_image_build(self, build_id: str) -> ImageBuild:
        payload = self._transport.request_json("GET", f"/api/v2/image-builds/{quote(build_id, safe='')}")
        return ImageBuild.from_payload(payload)

    def list_image_build_logs(self, build_id: str) -> list[ImageBuildLogLine]:
        payload = self._transport.request_json(
            "GET",
            f"/api/v2/image-builds/{quote(build_id, safe='')}/logs",
        )
        return [ImageBuildLogLine.from_payload(item) for item in payload]

    def cancel_image_build(self, build_id: str) -> ImageBuild:
        payload = self._transport.request_json(
            "POST",
            f"/api/v2/image-builds/{quote(build_id, safe='')}/cancel",
        )
        return ImageBuild.from_payload(payload)

    def list_image_assets(self) -> list[ImageAsset]:
        payload = self._transport.request_json("GET", "/api/v2/image-assets")
        return [ImageAsset.from_payload(item) for item in payload]

    def create_image_asset(self, request: dict[str, Any]) -> ImageAsset:
        payload = self._transport.request_json("POST", "/api/v2/image-assets", body=request)
        return ImageAsset.from_payload(payload)

    def get_image_asset(self, asset_id: str) -> ImageAsset:
        payload = self._transport.request_json("GET", f"/api/v2/image-assets/{quote(asset_id, safe='')}")
        return ImageAsset.from_payload(payload)

    def upsert_image_asset(self, asset_id: str, request: dict[str, Any]) -> ImageAsset:
        payload = self._transport.request_json(
            "PUT",
            f"/api/v2/image-assets/{quote(asset_id, safe='')}",
            body=request,
        )
        return ImageAsset.from_payload(payload)

    def delete_image_asset(self, asset_id: str) -> None:
        self._transport.request_no_content("DELETE", f"/api/v2/image-assets/{quote(asset_id, safe='')}")
