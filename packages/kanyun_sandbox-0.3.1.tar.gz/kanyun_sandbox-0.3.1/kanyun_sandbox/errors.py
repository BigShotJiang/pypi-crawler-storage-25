"""Errors for the Kanyun Sandbox v2 Python SDK."""

from __future__ import annotations


class APIError(Exception):
    def __init__(self, message: str, status_code: int, code: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code


class AuthenticationError(APIError):
    pass


class NotFoundError(APIError):
    pass


class ConflictError(APIError):
    pass


class ValidationError(APIError):
    pass


class SandboxNotReadyError(Exception):
    def __init__(self, sandbox_id: str, status: str) -> None:
        super().__init__(f"sandbox {sandbox_id} is not ready: missing IP for status {status}")
        self.sandbox_id = sandbox_id
        self.status = status


class SandboxAgentUnavailableError(Exception):
    def __init__(self, sandbox_id: str) -> None:
        super().__init__(
            f"sandbox {sandbox_id} does not have an agent client factory configured; "
            "pass agent_client_factory to Client to enable agent access"
        )
        self.sandbox_id = sandbox_id
