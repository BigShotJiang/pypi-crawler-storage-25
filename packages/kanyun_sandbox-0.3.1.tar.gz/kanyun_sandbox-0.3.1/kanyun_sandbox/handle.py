"""Sandbox handle for the Kanyun Sandbox v2 Python SDK."""

from __future__ import annotations

from typing import Any, Protocol

from .errors import SandboxAgentUnavailableError, SandboxNotReadyError
from .types import SandboxDetail, SandboxEvent, SandboxInfo


class _HandleClient(Protocol):
    def delete_sandbox(self, sandbox_id: str) -> None: ...
    def extend_sandbox(self, sandbox_id: str, ttl_seconds: int) -> None: ...
    def get_sandbox_detail(self, sandbox_id: str) -> SandboxDetail: ...
    def list_sandbox_events(self, sandbox_id: str) -> list[SandboxEvent]: ...
    def get_sandbox(self, sandbox_id: str) -> SandboxInfo: ...


def _resolve_sandbox_id(info: SandboxInfo) -> str:
    return info.claim_name or info.sandbox_name


def _build_agent_base_url(info: SandboxInfo, agent_port: int) -> str:
    if not info.ip:
        raise SandboxNotReadyError(_resolve_sandbox_id(info), info.status)
    if agent_port <= 0:
        agent_port = 8080
    return f"http://{info.ip}:{agent_port}"


class SandboxHandle:
    def __init__(
        self,
        info: SandboxInfo,
        *,
        client: _HandleClient,
        agent_client_factory,
        agent_port: int = 8080,
    ) -> None:
        self._client = client
        self._agent_client_factory = agent_client_factory
        self._agent_port = agent_port
        self._agent = None
        self.info = info

    @property
    def agent(self):
        if self._agent is None:
            if self._agent_client_factory is None:
                raise SandboxAgentUnavailableError(_resolve_sandbox_id(self.info))
            self._agent = self._agent_client_factory(_build_agent_base_url(self.info, self._agent_port))
        return self._agent

    def destroy(self) -> None:
        self._client.delete_sandbox(_resolve_sandbox_id(self.info))

    def extend(self, ttl_seconds: int) -> None:
        self._client.extend_sandbox(_resolve_sandbox_id(self.info), ttl_seconds)

    def detail(self) -> SandboxDetail:
        return self._client.get_sandbox_detail(_resolve_sandbox_id(self.info))

    def events(self) -> list[SandboxEvent]:
        return self._client.list_sandbox_events(_resolve_sandbox_id(self.info))

    def refresh(self) -> SandboxInfo:
        refreshed = self._client.get_sandbox(_resolve_sandbox_id(self.info))
        previous_ip = self.info.ip
        self.info = refreshed
        if self._agent is not None and refreshed.ip != previous_ip:
            if not refreshed.ip:
                self._agent = None
            else:
                self._agent = self._agent_client_factory(_build_agent_base_url(refreshed, self._agent_port))
        return self.info
