from __future__ import annotations

import pytest

from kanyun_sandbox.session import Session
from kanyun_sandbox.types import SandboxInfo


class StubHandle:
    def __init__(self) -> None:
        self.info = SandboxInfo(
            sandbox_name="sb-1",
            claim_name="claim-1",
            template_name="aio-default",
            status="Running",
            ip="10.0.0.1",
            endpoint="",
            created_at="",
            expires_at="",
            released_at=None,
            release_reason="",
            failure_reason="",
        )
        self.agent = {"base_url": "http://10.0.0.1:8080"}
        self.destroy_calls = 0

    def destroy(self) -> None:
        self.destroy_calls += 1

    def detail(self):
        return {"ok": True}

    def events(self):
        return [{"event_id": "evt-1"}]

    def refresh(self):
        self.info = SandboxInfo(
            sandbox_name="sb-1",
            claim_name="claim-1",
            template_name="aio-default",
            status="Ready",
            ip="10.0.0.2",
            endpoint="",
            created_at="",
            expires_at="",
            released_at=None,
            release_reason="",
            failure_reason="",
        )
        return self.info


def test_session_proxies_and_close_is_idempotent() -> None:
    handle = StubHandle()
    session = Session(handle)

    assert session.info.claim_name == "claim-1"
    assert session.agent == {"base_url": "http://10.0.0.1:8080"}
    assert session.detail() == {"ok": True}
    assert session.events() == [{"event_id": "evt-1"}]
    assert session.refresh().status == "Ready"

    session.close()
    session.close()

    assert handle.destroy_calls == 1


def test_session_context_manager_closes() -> None:
    handle = StubHandle()

    with Session(handle) as session:
        assert session.info.claim_name == "claim-1"

    assert handle.destroy_calls == 1


def test_session_retries_close_after_failure() -> None:
    handle = StubHandle()

    def failing_destroy() -> None:
        handle.destroy_calls += 1
        if handle.destroy_calls == 1:
            raise RuntimeError("delete failed")

    handle.destroy = failing_destroy
    session = Session(handle)

    with pytest.raises(RuntimeError, match="delete failed"):
        session.close()

    session.close()
    assert handle.destroy_calls == 2
