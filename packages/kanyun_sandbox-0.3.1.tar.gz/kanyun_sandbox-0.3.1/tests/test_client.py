from __future__ import annotations

import json

import httpx
import pytest

from kanyun_sandbox import (
    Client,
    CreateSandboxRequest,
    SandboxNotReadyError,
)
from kanyun_sandbox.errors import SandboxAgentUnavailableError


def test_client_control_plane_operations(monkeypatch: pytest.MonkeyPatch) -> None:
    created_payload = {}

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["X-API-Key"] == "test-key"
        if request.method == "POST" and request.url.path == "/api/v2/sandboxes":
            created_payload.update(json.loads(request.content.decode("utf-8")))
            return httpx.Response(
                201,
                json={
                    "SandboxName": "claim-1",
                    "ClaimName": "claim-1",
                    "TemplateName": "aio-default",
                    "Status": "Running",
                    "IP": "10.0.0.1",
                    "Endpoint": "http://ignored.example",
                    "CreatedAt": "2026-05-06T00:00:00Z",
                    "ExpiresAt": "2026-05-06T01:00:00Z",
                    "ReleasedAt": None,
                    "ReleaseReason": "",
                    "FailureReason": "",
                    "PublicEndpoints": [
                        {
                            "Name": "preview",
                            "URL": "https://claim-1.example.com/",
                            "Host": "claim-1.example.com",
                            "Path": "/",
                        }
                    ],
                },
            )
        if request.method == "GET" and request.url.path == "/api/v2/sandboxes/claim-1":
            return httpx.Response(
                200,
                json={
                    "SandboxName": "claim-1",
                    "ClaimName": "claim-1",
                    "TemplateName": "aio-default",
                    "Status": "Ready",
                    "IP": "10.0.0.2",
                    "Endpoint": "http://ignored.example",
                    "CreatedAt": "2026-05-06T00:00:00Z",
                    "ExpiresAt": "2026-05-06T01:00:00Z",
                    "ReleasedAt": None,
                    "ReleaseReason": "",
                    "FailureReason": "",
                },
            )
        if request.method == "GET" and request.url.path == "/api/v2/sandboxes":
            return httpx.Response(
                200,
                json=[
                    {
                        "SandboxName": "claim-1",
                        "ClaimName": "claim-1",
                        "TemplateName": "aio-default",
                        "Status": "Ready",
                        "IP": "10.0.0.2",
                        "Endpoint": "http://ignored.example",
                        "CreatedAt": "2026-05-06T00:00:00Z",
                        "ExpiresAt": "2026-05-06T01:00:00Z",
                        "ReleasedAt": None,
                        "ReleaseReason": "",
                        "FailureReason": "",
                    }
                ],
            )
        if request.method == "GET" and request.url.path == "/api/v2/sandboxes/claim-1/detail":
            return httpx.Response(
                200,
                json={
                    "SandboxName": "claim-1",
                    "ClaimName": "claim-1",
                    "TemplateName": "aio-default",
                    "Status": "Ready",
                    "IP": "10.0.0.2",
                    "Endpoint": "http://ignored.example",
                    "CreatedAt": "2026-05-06T00:00:00Z",
                    "ExpiresAt": "2026-05-06T01:00:00Z",
                    "ReleasedAt": None,
                    "ReleaseReason": "",
                    "FailureReason": "",
                    "Metadata": {"trace_id": "trace-1"},
                },
            )
        if request.method == "GET" and request.url.path == "/api/v2/sandboxes/claim-1/events":
            return httpx.Response(
                200,
                json=[
                    {
                        "EventID": "evt-1",
                        "AggregateType": "Sandbox",
                        "AggregateID": "claim-1",
                        "SandboxName": "claim-1",
                        "ClaimName": "claim-1",
                        "EventType": "SandboxCreated",
                        "OccurredAt": "2026-05-06T00:00:00Z",
                        "Actor": "sdk-user",
                        "Reason": "",
                        "Payload": {"status": "Ready"},
                    }
                ],
            )
        if request.method == "DELETE" and request.url.path == "/api/v2/sandboxes/claim-1":
            return httpx.Response(204)
        if request.method == "GET" and request.url.path == "/api/v2/templates":
            return httpx.Response(
                200,
                json=[
                    {
                        "Name": "aio-default",
                        "DisplayName": "AIO Default",
                        "Description": "default template",
                        "DefaultTTLSeconds": 300,
                        "MaxTTLSeconds": 3600,
                        "Enabled": True,
                        "Metadata": {"region": "hz"},
                        "RuntimeProfileID": "runtime-main",
                        "CreatedBy": "user-1",
                        "UpdatedAt": "2026-05-06T00:10:00Z",
                        "Ingresses": [
                            {
                                "name": "web",
                                "hostPrefix": "app",
                                "path": "/",
                                "pathType": "Prefix",
                                "backend": {"type": "service", "port": 8000},
                            }
                        ],
                    }
                ],
            )
        if request.method == "GET" and request.url.path == "/api/v2/templates/aio-default":
            return httpx.Response(
                200,
                json={
                    "Name": "aio-default",
                    "DisplayName": "AIO Default",
                    "Description": "default template",
                    "DefaultTTLSeconds": 300,
                    "MaxTTLSeconds": 3600,
                    "Enabled": True,
                    "Metadata": {"region": "hz"},
                },
            )
        raise AssertionError(f"unexpected request: {request.method} {request.url.path}")

    client = Client(
        control_plane_url="http://127.0.0.1:8080",
        api_key="test-key",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
        agent_client_factory=lambda base_url: {"base_url": base_url},
        agent_port=9090,
    )

    handle = client.create_sandbox(
        CreateSandboxRequest(
            template_name="aio-default",
            ttl_seconds=300,
            metadata={"trace_id": "trace-1"},
        )
    )

    assert created_payload == {
        "templateName": "aio-default",
        "ttlSeconds": 300,
        "metadata": {"trace_id": "trace-1"},
    }
    assert handle.info.ip == "10.0.0.1"
    assert handle.info.public_endpoints[0].url == "https://claim-1.example.com/"
    assert handle.agent == {"base_url": "http://10.0.0.1:9090"}

    connected = client.connect_sandbox("claim-1")
    assert connected.info.ip == "10.0.0.2"

    info = client.get_sandbox("claim-1")
    assert info.status == "Ready"

    sandboxes = client.list_sandboxes()
    assert len(sandboxes) == 1
    assert sandboxes[0].claim_name == "claim-1"

    detail = client.get_sandbox_detail("claim-1")
    assert detail.metadata == {"trace_id": "trace-1"}

    events = client.list_sandbox_events("claim-1")
    assert len(events) == 1
    assert events[0].event_id == "evt-1"

    client.delete_sandbox("claim-1")

    templates = client.list_templates()
    assert len(templates) == 1
    assert templates[0].name == "aio-default"
    assert templates[0].runtime_profile_id == "runtime-main"
    assert templates[0].ingresses[0].backend.port == 8000

    template = client.get_template("aio-default")
    assert template.display_name == "AIO Default"


def test_client_returns_handles_without_ip_or_agent_factory() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path in {"/api/v2/sandboxes", "/api/v2/sandboxes/claim-2"}:
            status = 201 if request.method == "POST" else 200
            return httpx.Response(
                status,
                json={
                    "SandboxName": "claim-2",
                    "ClaimName": "claim-2",
                    "TemplateName": "aio-default",
                    "Status": "Pending",
                    "IP": "",
                    "Endpoint": "http://must-not-be-used.example",
                    "CreatedAt": "",
                    "ExpiresAt": "",
                    "ReleasedAt": None,
                    "ReleaseReason": "",
                    "FailureReason": "",
                },
            )
        raise AssertionError(f"unexpected request: {request.method} {request.url.path}")

    client = Client(
        control_plane_url="http://127.0.0.1:8080",
        api_key="test-key",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    handle = client.create_sandbox(CreateSandboxRequest(template_name="aio-default"))
    assert handle.info.status == "Pending"
    with pytest.raises(SandboxAgentUnavailableError):
        _ = handle.agent

    connected = client.connect_sandbox("claim-2")
    assert connected.info.status == "Pending"
    with pytest.raises(SandboxAgentUnavailableError):
        _ = connected.agent


def test_configured_agent_factory_still_requires_ip_on_agent_access() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/v2/sandboxes":
            return httpx.Response(
                201,
                json={
                    "SandboxName": "claim-2",
                    "ClaimName": "claim-2",
                    "TemplateName": "python-dev",
                    "Status": "Pending",
                    "IP": "",
                    "Endpoint": "http://must-not-be-used.example",
                    "CreatedAt": "",
                    "ExpiresAt": "",
                    "ReleasedAt": None,
                    "ReleaseReason": "",
                    "FailureReason": "",
                },
            )
        raise AssertionError(f"unexpected request: {request.method} {request.url.path}")

    client = Client(
        control_plane_url="http://127.0.0.1:8080",
        api_key="test-key",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
        agent_client_factory=lambda base_url: {"base_url": base_url},
    )

    handle = client.create_sandbox(CreateSandboxRequest(template_name="python-dev"))
    with pytest.raises(SandboxNotReadyError):
        _ = handle.agent


def test_client_manages_templates_warm_pools_and_history() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "PUT" and request.url.path == "/api/v2/templates/python-dev":
            assert json.loads(request.content.decode("utf-8")) == {
                "runtimeProfileId": "runtime-main",
                "displayName": "Python Dev",
                "enabled": True,
                "defaultTTLSeconds": 300,
                "maxTTLSeconds": 3600,
                "podTemplate": {"spec": {"containers": [{"name": "main"}]}},
            }
            return httpx.Response(
                200,
                json={
                    "Name": "python-dev",
                    "RuntimeProfileID": "runtime-main",
                    "DisplayName": "Python Dev",
                    "Description": "",
                    "DefaultTTLSeconds": 300,
                    "MaxTTLSeconds": 3600,
                    "Enabled": True,
                    "Metadata": None,
                    "Labels": None,
                    "Annotations": None,
                    "CreatedBy": "user-1",
                    "CreatedAt": "2026-05-06T00:00:00Z",
                    "UpdatedAt": "2026-05-06T00:10:00Z",
                    "PodTemplate": {"spec": {"containers": [{"name": "main"}]}},
                    "NetworkPolicy": None,
                    "Ingresses": [
                        {
                            "name": "web",
                            "hostPrefix": "py",
                            "path": "/",
                            "pathType": "Prefix",
                            "backend": {"type": "service", "port": 8000},
                        }
                    ],
                },
            )
        if request.method == "GET" and request.url.path == "/api/v2/templates/python-dev/materializations":
            return httpx.Response(
                200,
                json=[
                    {
                        "id": "mat-1",
                        "templateName": "python-dev",
                        "runtimeProfileId": "runtime-main",
                        "clusterId": "cluster-main",
                        "namespace": "sandboxes",
                        "runtimeTemplateName": "python-dev",
                        "templateUpdatedAt": "2026-05-06T00:10:00Z",
                        "pullSecretMaterializationId": "secret-mat-1",
                        "pullSecretName": "pull-secret",
                        "pullSecretVersion": 2,
                        "status": "synced",
                        "lastError": "",
                        "lastMaterializedAt": "2026-05-06T00:11:00Z",
                        "createdAt": "2026-05-06T00:00:00Z",
                        "updatedAt": "2026-05-06T00:11:00Z",
                    }
                ],
            )
        if request.method == "PUT" and request.url.path == "/api/v2/warm-pools/python-dev-pool":
            return httpx.Response(
                200,
                json={
                    "Name": "python-dev-pool",
                    "TemplateName": "python-dev",
                    "DesiredReplicas": 2,
                    "CurrentReplicas": 1,
                    "ReadyReplicas": 1,
                    "Labels": {"tier": "dev"},
                    "Annotations": None,
                    "CreatedAt": "2026-05-06T00:00:00Z",
                },
            )
        if request.method == "GET" and request.url.path == "/api/v2/sandbox-history":
            query = request.url.query.decode("utf-8") if isinstance(request.url.query, bytes) else str(request.url.query)
            assert query == "page=2&pageSize=10&status=Released&templateName=python-dev"
            return httpx.Response(
                200,
                json={
                    "sandboxes": [
                        {
                            "ClaimName": "claim-history",
                            "SandboxName": "sandbox-history",
                            "TemplateName": "python-dev",
                            "Status": "Released",
                            "IP": "10.0.0.9",
                            "Endpoint": "",
                            "CreatedAt": "2026-05-06T00:00:00Z",
                            "DeletedAt": "2026-05-06T01:00:00Z",
                            "FailureReason": "",
                            "Metadata": {"trace": "one"},
                        }
                    ],
                    "total": 1,
                },
            )
        if request.method == "DELETE" and request.url.path == "/api/v2/warm-pools/python-dev-pool":
            return httpx.Response(204)
        raise AssertionError(f"unexpected request: {request.method} {request.url.path}")

    client = Client(
        control_plane_url="http://127.0.0.1:8080",
        api_key="test-key",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    template = client.apply_template(
        "python-dev",
        {
            "runtimeProfileId": "runtime-main",
            "displayName": "Python Dev",
            "enabled": True,
            "defaultTTLSeconds": 300,
            "maxTTLSeconds": 3600,
            "podTemplate": {"spec": {"containers": [{"name": "main"}]}},
        },
    )
    assert template.runtime_profile_id == "runtime-main"
    assert template.ingresses[0].backend.port == 8000

    materializations = client.list_template_materializations("python-dev")
    assert materializations[0].id == "mat-1"

    pool = client.apply_warm_pool(
        "python-dev-pool",
        {"templateName": "python-dev", "desiredReplicas": 2, "labels": {"tier": "dev"}},
    )
    assert pool.ready_replicas == 1

    history = client.list_sandbox_history(
        page=2,
        page_size=10,
        status="Released",
        template_name="python-dev",
    )
    assert history.total == 1
    assert history.sandboxes[0].claim_name == "claim-history"

    client.delete_warm_pool("python-dev-pool")


def test_client_manages_platform_profiles_and_image_builds() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.method == "POST" and request.url.path == "/api/v2/clusters":
            return httpx.Response(
                201,
                json={
                    "id": "cluster-main",
                    "displayName": "Main",
                    "description": "",
                    "kubeConfigSecretId": "secret-kubeconfig",
                    "status": "active",
                    "labels": {"region": "hz"},
                    "createdAt": "2026-05-06T00:00:00Z",
                    "updatedAt": "2026-05-06T00:00:00Z",
                },
            )
        if request.method == "GET" and request.url.path == "/api/v2/runtime-profiles/runtime-main":
            return httpx.Response(
                200,
                json={
                    "id": "runtime-main",
                    "clusterId": "cluster-main",
                    "namespace": "sandboxes",
                    "defaultRegistryProfileId": "registry-main",
                    "defaultTTLSeconds": 300,
                    "maxTTLSeconds": 3600,
                    "status": "active",
                    "labels": None,
                    "createdAt": "2026-05-06T00:00:00Z",
                    "updatedAt": "2026-05-06T00:00:00Z",
                },
            )
        if request.method == "POST" and request.url.path == "/api/v2/secret-profiles":
            assert json.loads(request.content.decode("utf-8"))["payload"] == {"username": "u", "password": "p"}
            return httpx.Response(
                201,
                json={
                    "id": "secret-registry",
                    "type": "registry",
                    "version": 1,
                    "createdBy": "user-1",
                    "createdAt": "2026-05-06T00:00:00Z",
                    "updatedAt": "2026-05-06T00:00:00Z",
                },
            )
        if request.method == "GET" and request.url.path == "/api/v2/secret-profiles/secret-registry/materializations":
            return httpx.Response(
                200,
                json=[
                    {
                        "id": "secret-mat-1",
                        "secretProfileId": "secret-registry",
                        "secretProfileVersion": 1,
                        "clusterId": "cluster-main",
                        "namespace": "sandboxes",
                        "k8sSecretName": "pull-secret",
                        "purpose": "image_pull",
                        "status": "synced",
                        "lastSyncedAt": "2026-05-06T00:01:00Z",
                        "lastError": "",
                        "createdAt": "2026-05-06T00:00:00Z",
                        "updatedAt": "2026-05-06T00:01:00Z",
                    }
                ],
            )
        if request.method == "POST" and request.url.path == "/api/v2/image-builds":
            assert json.loads(request.content.decode("utf-8")) == {
                "imageAssetId": "asset-1",
                "buildProfileId": "build-main",
                "ref": "main",
            }
            return httpx.Response(
                201,
                json={
                    "id": "build-1",
                    "status": "queued",
                    "imageAssetId": "asset-1",
                    "buildProfileId": "build-main",
                    "registryProfileId": "registry-main",
                    "gitCredentialSecretId": "",
                    "sourceRepoUrl": "https://example.com/repo.git",
                    "sourceRef": "main",
                    "resolvedCommit": "",
                    "contextPath": ".",
                    "dockerfilePath": "Dockerfile",
                    "logicalName": "python-dev",
                    "imageRepository": "registry.example.com/sandbox/python-dev",
                    "imageTag": "main",
                    "imageRef": "",
                    "imageDigest": "",
                    "cacheRef": "",
                    "jobName": "",
                    "startedAt": None,
                    "finishedAt": None,
                    "failureReason": "",
                    "createdBy": "user-1",
                    "createdAt": "2026-05-06T00:00:00Z",
                    "updatedAt": "2026-05-06T00:00:00Z",
                },
            )
        if request.method == "GET" and request.url.path == "/api/v2/image-builds/build-1/logs":
            return httpx.Response(
                200,
                json=[
                    {
                        "id": 1,
                        "buildId": "build-1",
                        "line": "queued",
                        "stream": "stdout",
                        "occurredAt": "2026-05-06T00:00:01Z",
                    }
                ],
            )
        raise AssertionError(f"unexpected request: {request.method} {request.url.path}")

    client = Client(
        control_plane_url="http://127.0.0.1:8080",
        api_key="test-key",
        http_client=httpx.Client(transport=httpx.MockTransport(handler)),
    )

    cluster = client.create_cluster(
        {
            "id": "cluster-main",
            "displayName": "Main",
            "kubeConfigSecretId": "secret-kubeconfig",
            "status": "active",
        }
    )
    assert cluster.id == "cluster-main"

    runtime = client.get_runtime_profile("runtime-main")
    assert runtime.namespace == "sandboxes"

    secret = client.create_secret_profile(
        {
            "id": "secret-registry",
            "type": "registry",
            "payload": {"username": "u", "password": "p"},
        }
    )
    assert secret.version == 1

    materializations = client.list_secret_materializations("secret-registry")
    assert materializations[0].k8s_secret_name == "pull-secret"

    build = client.create_image_build(
        {"imageAssetId": "asset-1", "buildProfileId": "build-main", "ref": "main"}
    )
    assert build.status == "queued"

    logs = client.list_image_build_logs("build-1")
    assert logs[0].line == "queued"
