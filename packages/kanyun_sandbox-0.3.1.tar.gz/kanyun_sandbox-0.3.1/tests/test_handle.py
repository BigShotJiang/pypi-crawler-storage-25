from __future__ import annotations

import pytest

from kanyun_sandbox.handle import SandboxHandle, _build_agent_base_url
from kanyun_sandbox.errors import SandboxAgentUnavailableError, SandboxNotReadyError
from kanyun_sandbox.types import SandboxDetail, SandboxEvent, SandboxInfo


class StubClient:
    def __init__(self) -> None:
        self.deleted_id = None
        self.refreshed = SandboxInfo(
            sandbox_name="sb-1",
            claim_name="claim-1",
            template_name="aio-default",
            status="Ready",
            ip="10.0.0.2",
            endpoint="",
            created_at="",
            expires_at="",
            released_at=None,
            release_reason="",
            failure_reason="",
        )

    def delete_sandbox(self, sandbox_id: str) -> None:
        self.deleted_id = sandbox_id

    def get_sandbox_detail(self, sandbox_id: str) -> SandboxDetail:
        return SandboxDetail(
            sandbox_name=sandbox_id,
            claim_name=sandbox_id,
            template_name="aio-default",
            status="Ready",
            ip="10.0.0.1",
            endpoint="",
            created_at="",
            expires_at="",
            released_at=None,
            release_reason="",
            failure_reason="",
            metadata={"trace_id": "trace-1"},
        )

    def list_sandbox_events(self, sandbox_id: str) -> list[SandboxEvent]:
        return [
            SandboxEvent(
                event_id="evt-1",
                aggregate_type="Sandbox",
                aggregate_id=sandbox_id,
                sandbox_name=sandbox_id,
                claim_name=sandbox_id,
                event_type="SandboxCreated",
                occurred_at="2026-05-06T00:00:00Z",
                actor="sdk-user",
                reason="",
                payload={"status": "Ready"},
            )
        ]

    def get_sandbox(self, sandbox_id: str) -> SandboxInfo:
        return self.refreshed


def test_build_agent_base_url_only_uses_ip() -> None:
    info = SandboxInfo(
        sandbox_name="sb-1",
        claim_name="claim-1",
        template_name="aio-default",
        status="Running",
        ip="10.0.0.1",
        endpoint="http://ignored.example",
        created_at="",
        expires_at="",
        released_at=None,
        release_reason="",
        failure_reason="",
    )

    assert _build_agent_base_url(info, 9090) == "http://10.0.0.1:9090"


def test_build_agent_base_url_raises_without_ip() -> None:
    info = SandboxInfo(
        sandbox_name="sb-1",
        claim_name="claim-1",
        template_name="aio-default",
        status="Pending",
        ip="",
        endpoint="http://must-not-be-used.example",
        created_at="",
        expires_at="",
        released_at=None,
        release_reason="",
        failure_reason="",
    )

    with pytest.raises(SandboxNotReadyError):
        _build_agent_base_url(info, 8080)


def test_handle_proxies_control_plane_calls() -> None:
    client = StubClient()
    info = SandboxInfo(
        sandbox_name="sb-1",
        claim_name="claim-1",
        template_name="aio-default",
        status="Running",
        ip="10.0.0.1",
        endpoint="http://ignored.example",
        created_at="",
        expires_at="",
        released_at=None,
        release_reason="",
        failure_reason="",
    )
    handle = SandboxHandle(info, client=client, agent_client_factory=lambda base_url: {"base_url": base_url}, agent_port=8080)

    assert handle.info.claim_name == "claim-1"
    assert handle.agent == {"base_url": "http://10.0.0.1:8080"}

    detail = handle.detail()
    assert detail.metadata == {"trace_id": "trace-1"}

    events = handle.events()
    assert len(events) == 1
    assert events[0].event_id == "evt-1"

    refreshed = handle.refresh()
    assert refreshed.ip == "10.0.0.2"
    assert handle.agent == {"base_url": "http://10.0.0.2:8080"}

    handle.destroy()
    assert client.deleted_id == "claim-1"


def test_handle_control_plane_calls_do_not_require_agent_factory() -> None:
    client = StubClient()
    info = SandboxInfo(
        sandbox_name="sb-1",
        claim_name="claim-1",
        template_name="python-dev",
        status="Running",
        ip="",
        endpoint="",
        created_at="",
        expires_at="",
        released_at=None,
        release_reason="",
        failure_reason="",
    )

    handle = SandboxHandle(info, client=client, agent_client_factory=None)

    assert handle.info.template_name == "python-dev"
    assert handle.detail().metadata == {"trace_id": "trace-1"}
    with pytest.raises(SandboxAgentUnavailableError):
        _ = handle.agent
