from __future__ import annotations

import httpx
import pytest

from kanyun_sandbox.errors import (
    APIError,
    AuthenticationError,
    ConflictError,
    NotFoundError,
    ValidationError,
)
from kanyun_sandbox.http import HTTPTransport


def make_transport(handler):
    client = httpx.Client(transport=httpx.MockTransport(handler))
    return HTTPTransport(base_url="http://127.0.0.1:8080", api_key="test-key", client=client)


def test_request_json_adds_api_key_and_parses_success() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["X-API-Key"] == "test-key"
        return httpx.Response(
            200,
            json={"ClaimName": "claim-1", "IP": "10.0.0.1"},
            headers={"Content-Type": "application/json"},
        )

    transport = make_transport(handler)

    payload = transport.request_json("GET", "/api/v2/sandboxes/claim-1")

    assert payload["ClaimName"] == "claim-1"
    assert payload["IP"] == "10.0.0.1"


def test_request_json_serializes_body() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["Content-Type"] == "application/json"
        assert request.read() == b'{"templateName":"aio-default","ttlSeconds":300}'
        return httpx.Response(200, json={"ok": True}, headers={"Content-Type": "application/json"})

    transport = make_transport(handler)

    payload = transport.request_json(
        "POST",
        "/api/v2/sandboxes",
        body={"templateName": "aio-default", "ttlSeconds": 300},
    )

    assert payload["ok"] is True


@pytest.mark.parametrize(
    ("status_code", "code", "message", "expected_error"),
    [
        (400, "invalid_request", "bad request", ValidationError),
        (401, "unauthorized", "not allowed", AuthenticationError),
        (404, "not_found", "missing", NotFoundError),
        (409, "conflict", "busy", ConflictError),
    ],
)
def test_request_json_maps_api_errors(status_code, code, message, expected_error) -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status_code,
            json={"error": {"code": code, "message": message}},
            headers={"Content-Type": "application/json"},
        )

    transport = make_transport(handler)

    with pytest.raises(expected_error) as exc_info:
        transport.request_json("GET", "/api/v2/test")

    assert exc_info.value.status_code == status_code
    assert exc_info.value.code == code
    assert exc_info.value.message == message


def test_request_json_maps_plain_text_error_body() -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text="boom")

    transport = make_transport(handler)

    with pytest.raises(APIError) as exc_info:
        transport.request_json("GET", "/api/v2/test")

    assert exc_info.value.status_code == 500
    assert exc_info.value.message == "boom"


def test_request_no_content_accepts_204() -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(204)

    transport = make_transport(handler)

    assert transport.request_no_content("DELETE", "/api/v2/sandboxes/claim-1") is None
