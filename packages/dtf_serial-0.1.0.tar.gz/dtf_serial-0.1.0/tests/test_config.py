"""Tests for dtf_serial/config.py."""

from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest
import tomli_w

from dtf_serial.config import (
    DEFAULT_BAUD,
    DEFAULT_FIRMWARE_VERSION,
    DEFAULT_GATEWAY_URL,
    DEFAULT_HARDWARE_VARIANT,
    load_config_file,
    prompt_missing,
    resolve_config,
    save_config_file,
)

# ---------------------------------------------------------------------------
# load_config_file
# ---------------------------------------------------------------------------


def test_load_config_file_valid(tmp_path: Path) -> None:
    cfg_file = tmp_path / ".dtf-serial.toml"
    data: dict[str, Any] = {
        "key": "abc123",
        "device_id": "dev-1",
        "firmware_version": "2.0.0",
        "baud": 9600,
    }
    with open(cfg_file, "wb") as f:
        tomli_w.dump(data, f)

    result = load_config_file(cfg_file)
    assert result == data


def test_load_config_file_missing(tmp_path: Path) -> None:
    result = load_config_file(tmp_path / "nonexistent.toml")
    assert result == {}


def test_load_config_file_invalid_toml(tmp_path: Path) -> None:
    cfg_file = tmp_path / ".dtf-serial.toml"
    cfg_file.write_bytes(b"key = [invalid toml")

    import click

    with pytest.raises(click.ClickException, match="Invalid TOML"):
        load_config_file(cfg_file)


# ---------------------------------------------------------------------------
# save_config_file
# ---------------------------------------------------------------------------


def test_save_config_file(tmp_path: Path) -> None:
    cfg_file = tmp_path / ".dtf-serial.toml"
    data: dict[str, Any] = {"key": "mykey", "device_id": "d1"}
    save_config_file(cfg_file, data)

    loaded = load_config_file(cfg_file)
    assert loaded == data


# ---------------------------------------------------------------------------
# prompt_missing
# ---------------------------------------------------------------------------


def test_prompt_missing_all_present() -> None:
    partial: dict[str, Any] = {
        "key": "k",
        "device_id": "d",
        "firmware_version": "1.0.0",
    }
    result = prompt_missing(partial)
    assert result == partial


def test_prompt_missing_asks_for_missing_fields() -> None:
    with patch(
        "dtf_serial.config.click.prompt", side_effect=["mykey", "mydevice", "2.0.0"]
    ) as mock_prompt:
        result = prompt_missing({})

    assert result["key"] == "mykey"
    assert result["device_id"] == "mydevice"
    assert result["firmware_version"] == "2.0.0"
    assert mock_prompt.call_count == 3


def test_prompt_missing_skips_present_fields() -> None:
    with patch("dtf_serial.config.click.prompt", return_value="newkey") as mock_prompt:
        result = prompt_missing(
            {"key": "existing", "device_id": "d1", "firmware_version": "1.0"}
        )

    assert result["key"] == "existing"
    assert mock_prompt.call_count == 0


def test_prompt_missing_firmware_has_default() -> None:
    with patch(
        "dtf_serial.config.click.prompt",
        side_effect=["k", "d", DEFAULT_FIRMWARE_VERSION],
    ) as mock_prompt:
        prompt_missing({})

    # third call should have default kwarg
    _, kwargs = mock_prompt.call_args_list[2]
    assert kwargs.get("default") == DEFAULT_FIRMWARE_VERSION


# ---------------------------------------------------------------------------
# resolve_config
# ---------------------------------------------------------------------------


def test_resolve_config_from_file(tmp_path: Path) -> None:
    cfg_file = tmp_path / ".dtf-serial.toml"
    data: dict[str, Any] = {
        "key": "filekey",
        "device_id": "filedev",
        "firmware_version": "3.0.0",
        "port": "/dev/ttyUSB0",
        "baud": 9600,
    }
    with open(cfg_file, "wb") as f:
        tomli_w.dump(data, f)

    with patch("dtf_serial.config.Path", return_value=cfg_file):
        cfg = resolve_config({})

    assert cfg.api_key == "filekey"
    assert cfg.device_id == "filedev"
    assert cfg.firmware_version == "3.0.0"
    assert cfg.port == "/dev/ttyUSB0"
    assert cfg.baud == 9600


def test_resolve_config_cli_overrides_file(tmp_path: Path) -> None:
    cfg_file = tmp_path / ".dtf-serial.toml"
    data: dict[str, Any] = {
        "key": "filekey",
        "device_id": "filedev",
        "firmware_version": "1.0.0",
    }
    with open(cfg_file, "wb") as f:
        tomli_w.dump(data, f)

    with patch("dtf_serial.config.Path", return_value=cfg_file):
        cfg = resolve_config({"key": "clikey"})

    assert cfg.api_key == "clikey"
    assert cfg.device_id == "filedev"


def test_resolve_config_prompts_on_first_run(tmp_path: Path) -> None:
    cfg_file = tmp_path / ".dtf-serial.toml"

    with (
        patch("dtf_serial.config.Path", return_value=cfg_file),
        patch(
            "dtf_serial.config.click.prompt",
            side_effect=["prompted_key", "prompted_dev", "1.0.0"],
        ),
    ):
        cfg = resolve_config({})

    assert cfg.api_key == "prompted_key"
    assert cfg.device_id == "prompted_dev"
    assert cfg_file.exists()
    saved = load_config_file(cfg_file)
    assert saved["key"] == "prompted_key"


def test_resolve_config_no_prompts_on_second_run(tmp_path: Path) -> None:
    cfg_file = tmp_path / ".dtf-serial.toml"
    data: dict[str, Any] = {
        "key": "k",
        "device_id": "d",
        "firmware_version": "1.0.0",
    }
    with open(cfg_file, "wb") as f:
        tomli_w.dump(data, f)

    with (
        patch("dtf_serial.config.Path", return_value=cfg_file),
        patch("dtf_serial.config.click.prompt") as mock_prompt,
    ):
        cfg = resolve_config({})

    mock_prompt.assert_not_called()
    assert cfg.api_key == "k"


def test_resolve_config_defaults_applied(tmp_path: Path) -> None:
    cfg_file = tmp_path / ".dtf-serial.toml"
    data: dict[str, Any] = {
        "key": "k",
        "device_id": "d",
        "firmware_version": "1.0.0",
    }
    with open(cfg_file, "wb") as f:
        tomli_w.dump(data, f)

    with patch("dtf_serial.config.Path", return_value=cfg_file):
        cfg = resolve_config({})

    assert cfg.baud == DEFAULT_BAUD
    assert cfg.hardware_variant == DEFAULT_HARDWARE_VARIANT
    assert cfg.gateway_url == DEFAULT_GATEWAY_URL
    assert cfg.port == ""


def test_resolve_config_saves_after_prompt(tmp_path: Path) -> None:
    cfg_file = tmp_path / ".dtf-serial.toml"

    with (
        patch("dtf_serial.config.Path", return_value=cfg_file),
        patch("dtf_serial.config.click.prompt", side_effect=["k", "d", "1.0.0"]),
    ):
        resolve_config({})

    assert cfg_file.exists()
    saved = load_config_file(cfg_file)
    assert saved["key"] == "k"
    assert saved["device_id"] == "d"
