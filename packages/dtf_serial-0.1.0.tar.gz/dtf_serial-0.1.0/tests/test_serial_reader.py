"""Tests for serial port reader."""

import logging
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import serial

from dtf_serial.serial_reader import (
    KNOWN_USB_UART_DEVICES,
    SerialReader,
    detect_ports,
    select_port,
    wait_for_device,
)

# Stable ordered list for tests that need indexed access.
_KNOWN_DEVICES = sorted(KNOWN_USB_UART_DEVICES)


def make_port_info(vid: int, pid: int, device: str) -> MagicMock:
    info = MagicMock()
    info.vid = vid
    info.pid = pid
    info.device = device
    return info


# ── detect_ports ──────────────────────────────────────────────────────────────


def test_detect_ports_empty() -> None:
    with patch("serial.tools.list_ports.comports", return_value=[]):
        assert detect_ports() == []


def test_detect_ports_one_known() -> None:
    vid, pid = _KNOWN_DEVICES[0]
    port = make_port_info(vid, pid, "/dev/ttyUSB0")
    with patch("serial.tools.list_ports.comports", return_value=[port]):
        assert detect_ports() == ["/dev/ttyUSB0"]


def test_detect_ports_multiple_known() -> None:
    vid0, pid0 = _KNOWN_DEVICES[0]
    vid1, pid1 = _KNOWN_DEVICES[1]
    ports = [
        make_port_info(vid0, pid0, "/dev/ttyUSB0"),
        make_port_info(vid1, pid1, "/dev/ttyUSB1"),
    ]
    with patch("serial.tools.list_ports.comports", return_value=ports):
        result = detect_ports()
    assert result == ["/dev/ttyUSB0", "/dev/ttyUSB1"]


def test_detect_ports_unknown_vid_pid_filtered() -> None:
    unknown = make_port_info(0x1234, 0x5678, "/dev/ttyUSB0")
    with patch("serial.tools.list_ports.comports", return_value=[unknown]):
        assert detect_ports() == []


def test_detect_ports_mixed_known_and_unknown() -> None:
    vid, pid = _KNOWN_DEVICES[2]
    known = make_port_info(vid, pid, "/dev/ttyUSB0")
    unknown = make_port_info(0xAAAA, 0xBBBB, "/dev/ttyUSB1")
    with patch("serial.tools.list_ports.comports", return_value=[known, unknown]):
        assert detect_ports() == ["/dev/ttyUSB0"]


# ── select_port ───────────────────────────────────────────────────────────────


def test_select_port_returns_none_when_empty() -> None:
    with patch("serial.tools.list_ports.comports", return_value=[]):
        assert select_port() is None


def test_select_port_auto_selects_single() -> None:
    vid, pid = _KNOWN_DEVICES[0]
    port = make_port_info(vid, pid, "/dev/ttyUSB0")
    with patch("serial.tools.list_ports.comports", return_value=[port]):
        result = select_port()
    assert result == "/dev/ttyUSB0"


def test_select_port_prompts_when_multiple() -> None:
    vid0, pid0 = _KNOWN_DEVICES[0]
    vid1, pid1 = _KNOWN_DEVICES[1]
    ports = [
        make_port_info(vid0, pid0, "/dev/ttyUSB0"),
        make_port_info(vid1, pid1, "/dev/ttyUSB1"),
    ]
    with patch("serial.tools.list_ports.comports", return_value=ports):
        with patch(
            "dtf_serial.serial_reader.click.prompt", return_value=2
        ) as mock_prompt:
            result = select_port()
    assert result == "/dev/ttyUSB1"
    mock_prompt.assert_called_once()


def test_select_port_prompt_selects_first() -> None:
    vid0, pid0 = _KNOWN_DEVICES[0]
    vid1, pid1 = _KNOWN_DEVICES[1]
    ports = [
        make_port_info(vid0, pid0, "/dev/ttyUSB0"),
        make_port_info(vid1, pid1, "/dev/ttyUSB1"),
    ]
    with patch("serial.tools.list_ports.comports", return_value=ports):
        with patch("dtf_serial.serial_reader.click.prompt", return_value=1):
            result = select_port()
    assert result == "/dev/ttyUSB0"


# ── wait_for_device ───────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_wait_for_device_returns_immediately() -> None:
    vid, pid = _KNOWN_DEVICES[0]
    port = make_port_info(vid, pid, "/dev/ttyUSB0")
    with patch("serial.tools.list_ports.comports", return_value=[port]):
        result = await wait_for_device(interval=0.0)
    assert result == "/dev/ttyUSB0"


@pytest.mark.asyncio
async def test_wait_for_device_polls_until_found() -> None:
    vid, pid = _KNOWN_DEVICES[0]
    port = make_port_info(vid, pid, "/dev/ttyUSB0")
    call_count = 0

    def fake_comports() -> list[MagicMock]:
        nonlocal call_count
        call_count += 1
        return [] if call_count < 3 else [port]

    with patch("serial.tools.list_ports.comports", side_effect=fake_comports):
        with patch("asyncio.sleep", new_callable=AsyncMock):
            result = await wait_for_device(interval=0.01)

    assert result == "/dev/ttyUSB0"
    assert call_count == 3


# ── SerialReader ──────────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_read_lines_yields_decoded_line() -> None:
    mock_serial = MagicMock()
    mock_serial.readline.return_value = b"hello world\r\n"

    reader = SerialReader(port="/dev/ttyUSB0", baud=115200)
    collected: list[str] = []

    with patch("dtf_serial.serial_reader.serial.Serial", return_value=mock_serial):
        async for line in reader.read_lines():
            collected.append(line)
            break

    assert collected == ["hello world"]


@pytest.mark.asyncio
async def test_read_lines_strips_crlf() -> None:
    mock_serial = MagicMock()
    mock_serial.readline.return_value = b"data\r\n"

    reader = SerialReader(port="/dev/ttyUSB0", baud=115200)

    with patch("dtf_serial.serial_reader.serial.Serial", return_value=mock_serial):
        async for line in reader.read_lines():
            assert line == "data"
            break


@pytest.mark.asyncio
async def test_read_lines_serial_exception_stops(
    caplog: pytest.LogCaptureFixture,
) -> None:
    mock_serial = MagicMock()
    mock_serial.readline.side_effect = serial.SerialException("port lost")

    reader = SerialReader(port="/dev/ttyUSB0", baud=115200)
    lines: list[str] = []

    with patch("dtf_serial.serial_reader.serial.Serial", return_value=mock_serial):
        with caplog.at_level(logging.ERROR):
            async for line in reader.read_lines():
                lines.append(line)

    assert lines == []
    assert any("port lost" in r.message for r in caplog.records)


@pytest.mark.asyncio
async def test_read_lines_utf8_replacement() -> None:
    call_count = 0

    def fake_readline() -> bytes:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return b"good \xff bad\r\n"
        raise serial.SerialException("done")

    mock_serial = MagicMock()
    mock_serial.readline.side_effect = fake_readline

    reader = SerialReader(port="/dev/ttyUSB0", baud=115200)
    lines: list[str] = []

    with patch("dtf_serial.serial_reader.serial.Serial", return_value=mock_serial):
        async for line in reader.read_lines():
            lines.append(line)

    assert len(lines) == 1
    assert "\ufffd" in lines[0]


@pytest.mark.asyncio
async def test_read_lines_no_parser_dependency() -> None:
    """SerialReader must not import from parser, buffer, or transport."""
    import dtf_serial.serial_reader as module

    source = module.__file__ or ""
    with open(source) as f:
        content = f.read()

    assert "from dtf_serial.parser" not in content
    assert "from dtf_serial.buffer" not in content
    assert "from dtf_serial.transport" not in content
