"""Tests for HttpTransport."""

import gzip
import json
import logging
from unittest.mock import MagicMock, patch

import pytest

from dtf_serial.events import LogEvent, RawEvent
from dtf_serial.transport import HttpTransport

GATEWAY = "http://localhost:8765/v1/ingest"
API_KEY = "dtf_k_testkey"
DEVICE_ID = "dev-001"
FW = "1.2.3"
HW = "rev-a"


def make_transport() -> HttpTransport:
    return HttpTransport(
        gateway_url=GATEWAY,
        api_key=API_KEY,
        device_id=DEVICE_ID,
        firmware_version=FW,
        hardware_variant=HW,
    )


def fake_response(status: int) -> MagicMock:
    resp = MagicMock()
    resp.status = status
    resp.__enter__ = lambda s: s
    resp.__exit__ = MagicMock(return_value=False)
    return resp


EVENTS = [
    LogEvent(lv="i", mod="wifi", m="connected", wts=1000),
    RawEvent(m="raw line", wts=2000),
]


@pytest.mark.asyncio
async def test_send_success_200() -> None:
    transport = make_transport()
    captured: list[bytes] = []

    def fake_urlopen(req: object, timeout: int) -> MagicMock:
        import urllib.request

        assert isinstance(req, urllib.request.Request)
        captured.append(req.data)  # type: ignore[union-attr]
        return fake_response(200)

    with patch("dtf_serial.transport.urllib.request.urlopen", side_effect=fake_urlopen):
        result = await transport.send(EVENTS)

    assert result is True
    assert len(captured) == 1
    body = gzip.decompress(captured[0])
    payload = json.loads(body)
    assert payload["d"] == DEVICE_ID
    assert payload["fv"] == FW
    assert payload["hw"] == HW
    assert len(payload["e"]) == 2


@pytest.mark.asyncio
async def test_send_success_202() -> None:
    transport = make_transport()

    with patch(
        "dtf_serial.transport.urllib.request.urlopen",
        return_value=fake_response(202),
    ):
        result = await transport.send(EVENTS)

    assert result is True


@pytest.mark.asyncio
async def test_send_server_error_returns_false() -> None:
    import urllib.error

    transport = make_transport()
    exc = urllib.error.HTTPError(  # type: ignore[arg-type]
        GATEWAY, 500, "Internal Server Error", {}, None
    )

    with patch(
        "dtf_serial.transport.urllib.request.urlopen",
        side_effect=exc,
    ):
        result = await transport.send(EVENTS)

    assert result is False


@pytest.mark.asyncio
async def test_send_network_error_returns_false(
    caplog: pytest.LogCaptureFixture,
) -> None:
    transport = make_transport()

    with patch(
        "dtf_serial.transport.urllib.request.urlopen",
        side_effect=ConnectionError("refused"),
    ):
        with caplog.at_level(logging.ERROR):
            result = await transport.send(EVENTS)

    assert result is False
    assert any("refused" in r.message for r in caplog.records)


@pytest.mark.asyncio
async def test_send_timeout_returns_false(
    caplog: pytest.LogCaptureFixture,
) -> None:
    transport = make_transport()

    with patch(
        "dtf_serial.transport.urllib.request.urlopen",
        side_effect=TimeoutError("timed out"),
    ):
        with caplog.at_level(logging.ERROR):
            result = await transport.send(EVENTS)

    assert result is False
    assert any("timed out" in r.message for r in caplog.records)


@pytest.mark.asyncio
async def test_auth_header_present() -> None:
    transport = make_transport()
    captured_headers: list[dict[str, str]] = []

    def fake_urlopen(req: object, timeout: int) -> MagicMock:
        import urllib.request

        assert isinstance(req, urllib.request.Request)
        captured_headers.append(dict(req.headers))
        return fake_response(200)

    with patch("dtf_serial.transport.urllib.request.urlopen", side_effect=fake_urlopen):
        await transport.send(EVENTS)

    assert len(captured_headers) == 1
    # urllib capitalises header names
    auth = captured_headers[0].get("Authorization") or captured_headers[0].get(
        "authorization"
    )
    assert auth == f"Bearer {API_KEY}"


@pytest.mark.asyncio
async def test_content_headers_present() -> None:
    transport = make_transport()
    captured_headers: list[dict[str, str]] = []

    def fake_urlopen(req: object, timeout: int) -> MagicMock:
        import urllib.request

        assert isinstance(req, urllib.request.Request)
        captured_headers.append(dict(req.headers))
        return fake_response(200)

    with patch("dtf_serial.transport.urllib.request.urlopen", side_effect=fake_urlopen):
        await transport.send(EVENTS)

    headers = captured_headers[0]
    ct = (
        headers.get("Content-type")
        or headers.get("Content-Type")
        or headers.get("content-type")
    )
    ce = (
        headers.get("Content-encoding")
        or headers.get("Content-Encoding")
        or headers.get("content-encoding")
    )
    assert ct == "application/json"
    assert ce == "gzip"


@pytest.mark.asyncio
async def test_api_key_not_in_logs(caplog: pytest.LogCaptureFixture) -> None:
    import urllib.error

    transport = make_transport()
    exc = urllib.error.HTTPError(  # type: ignore[arg-type]
        GATEWAY, 403, "Forbidden", {}, None
    )

    with patch(
        "dtf_serial.transport.urllib.request.urlopen",
        side_effect=exc,
    ):
        with caplog.at_level(logging.ERROR):
            await transport.send(EVENTS)

    for record in caplog.records:
        assert API_KEY not in record.getMessage()


@pytest.mark.asyncio
async def test_payload_structure() -> None:
    transport = make_transport()
    captured: list[bytes] = []

    def fake_urlopen(req: object, timeout: int) -> MagicMock:
        import urllib.request

        assert isinstance(req, urllib.request.Request)
        captured.append(req.data)  # type: ignore[union-attr]
        return fake_response(200)

    events = [LogEvent(lv="w", mod="app", m="low mem", wts=9999)]
    with patch("dtf_serial.transport.urllib.request.urlopen", side_effect=fake_urlopen):
        await transport.send(events)

    payload = json.loads(gzip.decompress(captured[0]))
    assert set(payload.keys()) >= {"d", "fv", "hw", "e"}
    assert payload["e"][0] == {
        "t": "l",
        "lv": "w",
        "mod": "app",
        "m": "low mem",
        "wts": 9999,
    }
