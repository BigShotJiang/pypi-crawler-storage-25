"""Tests for EspIdfParser and strip_ansi."""

import pytest

from dtf_serial.events import LogEvent, RawEvent
from dtf_serial.parser import EspIdfParser, strip_ansi


@pytest.fixture
def parser() -> EspIdfParser:
    return EspIdfParser()


# --- strip_ansi ---


def test_strip_ansi_no_codes() -> None:
    assert strip_ansi("hello") == "hello"


def test_strip_ansi_color_wrap() -> None:
    assert (
        strip_ansi("\x1b[0;32mI (1234) wifi: connected\x1b[0m")
        == "I (1234) wifi: connected"
    )


def test_strip_ansi_multiple_codes() -> None:
    assert strip_ansi("\x1b[1m\x1b[31mERROR\x1b[0m") == "ERROR"


def test_strip_ansi_only_codes() -> None:
    assert strip_ansi("\x1b[0m\x1b[32m") == ""


def test_strip_ansi_empty() -> None:
    assert strip_ansi("") == ""


# --- EspIdfParser: successful parses ---


@pytest.mark.parametrize(
    "char,expected_lv",
    [
        ("V", "v"),
        ("D", "d"),
        ("I", "i"),
        ("W", "w"),
        ("E", "e"),
    ],
)
def test_all_log_levels(parser: EspIdfParser, char: str, expected_lv: str) -> None:
    result = parser.parse(f"{char} (100) tag: message")
    assert isinstance(result, LogEvent)
    assert result.lv == expected_lv


def test_basic_log_event(parser: EspIdfParser) -> None:
    result = parser.parse("I (1234) wifi: connected")
    assert isinstance(result, LogEvent)
    assert result.lv == "i"
    assert result.mod == "wifi"
    assert result.m == "connected"


def test_ansi_wrapped_line(parser: EspIdfParser) -> None:
    result = parser.parse("\x1b[0;32mI (1234) wifi: connected\x1b[0m")
    assert isinstance(result, LogEvent)
    assert result.lv == "i"
    assert result.mod == "wifi"
    assert result.m == "connected"


def test_message_with_colon(parser: EspIdfParser) -> None:
    result = parser.parse("E (999) my_module: error: something broke")
    assert isinstance(result, LogEvent)
    assert result.mod == "my_module"
    assert result.m == "error: something broke"


def test_multi_word_tag(parser: EspIdfParser) -> None:
    result = parser.parse("I (500) esp_wifi: station connected")
    assert isinstance(result, LogEvent)
    assert result.mod == "esp_wifi"
    assert result.m == "station connected"


def test_http_client_tag(parser: EspIdfParser) -> None:
    result = parser.parse("D (200) http_client: sending request")
    assert isinstance(result, LogEvent)
    assert result.mod == "http_client"
    assert result.m == "sending request"


def test_zero_timestamp(parser: EspIdfParser) -> None:
    result = parser.parse("I (0) boot: starting")
    assert isinstance(result, LogEvent)
    assert result.mod == "boot"
    assert result.m == "starting"


def test_large_timestamp(parser: EspIdfParser) -> None:
    result = parser.parse("W (9999999) net: reconnecting")
    assert isinstance(result, LogEvent)
    assert result.lv == "w"


def test_wts_is_millis(parser: EspIdfParser) -> None:
    import time

    before = time.time_ns() // 1_000_000
    result = parser.parse("I (1) tag: msg")
    after = time.time_ns() // 1_000_000
    assert isinstance(result, LogEvent)
    assert before <= result.wts <= after


# --- EspIdfParser: RawEvent fallthrough ---


def test_random_line_raw_event(parser: EspIdfParser) -> None:
    result = parser.parse("some random output")
    assert isinstance(result, RawEvent)
    assert result.m == "some random output"


def test_empty_line_raw_event(parser: EspIdfParser) -> None:
    result = parser.parse("")
    assert isinstance(result, RawEvent)
    assert result.m == ""


def test_whitespace_only_raw_event(parser: EspIdfParser) -> None:
    result = parser.parse("   ")
    assert isinstance(result, RawEvent)
    assert result.m == ""


def test_only_ansi_codes_raw_event(parser: EspIdfParser) -> None:
    result = parser.parse("\x1b[0m\x1b[32m")
    assert isinstance(result, RawEvent)
    assert result.m == ""


def test_partial_espidf_format_raw_event(parser: EspIdfParser) -> None:
    result = parser.parse("I (1234) wifi connected")  # missing colon+space
    assert isinstance(result, RawEvent)


def test_wrong_level_char_raw_event(parser: EspIdfParser) -> None:
    result = parser.parse("F (100) tag: msg")  # F is not a valid level
    assert isinstance(result, RawEvent)


def test_very_long_line(parser: EspIdfParser) -> None:
    long_msg = "x" * 10_000
    result = parser.parse(f"I (1) tag: {long_msg}")
    assert isinstance(result, LogEvent)
    assert result.m == long_msg


def test_raw_wts_is_millis(parser: EspIdfParser) -> None:
    import time

    before = time.time_ns() // 1_000_000
    result = parser.parse("not a log line")
    after = time.time_ns() // 1_000_000
    assert isinstance(result, RawEvent)
    assert before <= result.wts <= after
