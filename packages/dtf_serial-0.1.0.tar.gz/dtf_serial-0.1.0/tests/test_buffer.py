"""Tests for InMemoryBuffer."""

import asyncio

import pytest

from dtf_serial.buffer import InMemoryBuffer
from dtf_serial.events import LogEvent, RawEvent


def make_log(msg: str = "hello") -> LogEvent:
    return LogEvent(lv="i", mod="app", m=msg, wts=1000)


def make_raw(msg: str = "raw") -> RawEvent:
    return RawEvent(m=msg, wts=1000)


@pytest.mark.asyncio
async def test_add_single_drain() -> None:
    buf = InMemoryBuffer()
    event = make_log()
    await buf.add(event)
    result = await buf.drain()
    assert result == [event]


@pytest.mark.asyncio
async def test_add_multiple_preserves_order() -> None:
    buf = InMemoryBuffer()
    events = [make_log(f"msg{i}") for i in range(5)]
    for e in events:
        await buf.add(e)
    result = await buf.drain()
    assert result == events


@pytest.mark.asyncio
async def test_drain_empty_returns_empty_list() -> None:
    buf = InMemoryBuffer()
    result = await buf.drain()
    assert result == []


@pytest.mark.asyncio
async def test_len_after_adds() -> None:
    buf = InMemoryBuffer()
    assert len(buf) == 0
    await buf.add(make_log())
    assert len(buf) == 1
    await buf.add(make_raw())
    assert len(buf) == 2


@pytest.mark.asyncio
async def test_len_zero_after_drain() -> None:
    buf = InMemoryBuffer()
    for _ in range(5):
        await buf.add(make_log())
    await buf.drain()
    assert len(buf) == 0


@pytest.mark.asyncio
async def test_reusable_after_drain() -> None:
    buf = InMemoryBuffer()
    await buf.add(make_log("first"))
    await buf.drain()
    event = make_log("second")
    await buf.add(event)
    result = await buf.drain()
    assert result == [event]


@pytest.mark.asyncio
async def test_concurrent_add_drain() -> None:
    buf = InMemoryBuffer()
    n = 50

    async def producer() -> None:
        for i in range(n):
            await buf.add(make_log(f"msg{i}"))

    drained: list[object] = []

    async def consumer() -> None:
        for _ in range(10):
            drained.extend(await buf.drain())
            await asyncio.sleep(0)

    await asyncio.gather(producer(), consumer())
    # drain any remaining
    drained.extend(await buf.drain())

    assert len(drained) == n
    assert len(buf) == 0
