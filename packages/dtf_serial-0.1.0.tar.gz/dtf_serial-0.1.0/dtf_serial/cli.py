"""CLI entry point for dtf-serial."""

import asyncio
import logging
from typing import Any

import click
import serial

from dtf_serial.buffer import BufferProtocol, InMemoryBuffer
from dtf_serial.config import DtfConfig, resolve_config
from dtf_serial.parser import EspIdfParser, ParserProtocol
from dtf_serial.serial_reader import SerialReader, select_port, wait_for_device
from dtf_serial.transport import HttpTransport, TransportProtocol

logger = logging.getLogger("dtf-serial")

_FLUSH_INTERVAL = 10.0


async def reader_loop(
    reader: SerialReader,
    parser: ParserProtocol,
    buffer: BufferProtocol,
) -> None:
    async for line in reader.read_lines():
        event = parser.parse(line)
        await buffer.add(event)


async def flush_loop(
    buffer: BufferProtocol,
    transport: TransportProtocol,
    interval: float = _FLUSH_INTERVAL,
) -> None:
    while True:
        await asyncio.sleep(interval)
        events = await buffer.drain()
        if events:
            success = await transport.send(events)
            if not success:
                logger.warning("[dtf-serial] Flush failed, re-queuing batch")
                # Re-enqueue events so they can be retried on the next flush.
                for event in events:
                    await buffer.add(event)
            else:
                logger.info(f"[dtf-serial] Shipped {len(events)} events")


async def reconnecting_reader(
    initial_port: str | None,
    config: DtfConfig,
    parser: ParserProtocol,
    buffer: BufferProtocol,
) -> None:
    """Reconnection wrapper around reader_loop.

    On first iteration uses initial_port if provided, otherwise detects.
    On subsequent iterations always re-detects via wait_for_device().
    """
    first = True
    while True:
        if first and initial_port:
            port = initial_port
        else:
            port = await wait_for_device()
        first = False

        logger.info(f"[dtf-serial] Connected to {port} at {config.baud} baud")
        reader = SerialReader(port, config.baud)

        try:
            await reader_loop(reader, parser, buffer)
        except serial.SerialException:
            pass

        logger.info("[dtf-serial] Device disconnected. Waiting for reconnect...")
        await asyncio.sleep(1.0)


async def async_main(config: DtfConfig) -> None:
    initial_port = config.port or select_port()

    parser = EspIdfParser()
    buffer = InMemoryBuffer()
    transport = HttpTransport(
        gateway_url=config.gateway_url,
        api_key=config.api_key,
        device_id=config.device_id,
        firmware_version=config.firmware_version,
        hardware_variant=config.hardware_variant,
    )

    logger.info(f"[dtf-serial] Streaming to {config.gateway_url}")

    try:
        await asyncio.gather(
            reconnecting_reader(initial_port, config, parser, buffer),
            flush_loop(buffer, transport),
        )
    finally:
        events = await buffer.drain()
        if events:
            success = await transport.send(events)
            if success:
                logger.info(f"[dtf-serial] Flushed {len(events)} remaining events")
            else:
                logger.warning("[dtf-serial] Final flush failed")


@click.command()
@click.option("--key", default=None, help="API key")
@click.option("--port", default=None, help="Serial port path")
@click.option("--baud", default=None, type=int, help="Baud rate (default: 115200)")
@click.option("--device-id", default=None, help="Device identifier")
@click.option("--fw-version", default=None, help="Firmware version")
@click.option("--hw", default=None, help="Hardware variant")
@click.option("--gateway", default=None, help="Gateway URL")
def cli(
    key: str | None,
    port: str | None,
    baud: int | None,
    device_id: str | None,
    fw_version: str | None,
    hw: str | None,
    gateway: str | None,
) -> None:
    cli_flags: dict[str, Any] = {}
    if key is not None:
        cli_flags["key"] = key
    if port is not None:
        cli_flags["port"] = port
    if baud is not None:
        cli_flags["baud"] = baud
    if device_id is not None:
        cli_flags["device_id"] = device_id
    if fw_version is not None:
        cli_flags["firmware_version"] = fw_version
    if hw is not None:
        cli_flags["hardware_variant"] = hw
    if gateway is not None:
        cli_flags["gateway_url"] = gateway

    logging.basicConfig(
        format="%(message)s",
        level=logging.INFO,
    )

    config = resolve_config(cli_flags)

    try:
        asyncio.run(async_main(config))
    except KeyboardInterrupt:
        logger.info("[dtf-serial] Stopped.")


def main() -> None:
    """Run the DTF serial agent."""
    cli()
