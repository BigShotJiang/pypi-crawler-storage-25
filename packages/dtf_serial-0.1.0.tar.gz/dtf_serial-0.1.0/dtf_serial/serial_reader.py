"""Serial port reader for ESP32 UART output."""

import asyncio
import logging
from collections.abc import AsyncIterator

import click
import serial
import serial.tools.list_ports

logger = logging.getLogger("dtf-serial")

# Known USB-UART chip (VID, PID) pairs.
KNOWN_USB_UART_DEVICES: frozenset[tuple[int, int]] = frozenset(
    [
        (0x10C4, 0xEA60),  # CP210x
        (0x1A86, 0x7523),  # CH340/CH341
        (0x0403, 0x6001),  # FTDI FT232
        (0x0403, 0x6010),  # FTDI FT2232
    ]
)


def detect_ports() -> list[str]:
    """Return device paths for connected USB-UART ports matching known VID/PIDs."""
    return [
        p.device
        for p in serial.tools.list_ports.comports()
        if (p.vid, p.pid) in KNOWN_USB_UART_DEVICES
    ]


def select_port() -> str | None:
    """Return a selected port path, or None if no devices are present.

    Auto-selects when exactly one device is found; prompts when multiple.
    """
    ports = detect_ports()
    if not ports:
        return None
    if len(ports) == 1:
        logger.info("[dtf-serial] Found device: %s", ports[0])
        return ports[0]
    logger.info("[dtf-serial] Multiple devices found:")
    for i, port in enumerate(ports, start=1):
        logger.info("  %d. %s", i, port)
    choice: int = click.prompt("Select port", type=click.IntRange(1, len(ports)))
    return ports[choice - 1]


async def wait_for_device(interval: float = 1.0) -> str:
    """Poll for a USB-UART device and return its port path once found."""
    logger.info("[dtf-serial] Waiting for ESP32... Plug in a device.")
    while True:
        ports = detect_ports()
        if ports:
            return ports[0]
        await asyncio.sleep(interval)


class SerialReader:
    """Reads lines from a serial port, yielding decoded strings."""

    def __init__(self, port: str, baud: int) -> None:
        self._port = port
        self._baud = baud

    async def read_lines(self) -> AsyncIterator[str]:
        """Async generator yielding UTF-8 decoded lines from the serial port."""
        ser: serial.Serial = await asyncio.to_thread(
            lambda: serial.Serial(self._port, self._baud, timeout=1)
        )
        try:
            while True:
                try:
                    raw: bytes = await asyncio.to_thread(ser.readline)
                    if not raw:
                        continue
                    line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
                    yield line
                except serial.SerialException as exc:
                    logger.error("[dtf-serial] Serial error: %s", exc)
                    return
        finally:
            await asyncio.to_thread(ser.close)
