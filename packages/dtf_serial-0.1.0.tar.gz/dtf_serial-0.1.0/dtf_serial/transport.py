"""Transport Protocol for shipping log events to the DTF ingest gateway."""

import asyncio
import gzip
import json
import logging
import urllib.error
import urllib.request
from typing import Protocol

from dtf_serial.events import Event

logger = logging.getLogger("dtf-serial")


class TransportProtocol(Protocol):
    async def send(self, events: list[Event]) -> bool: ...


class HttpTransport:
    """HTTP transport that POSTs gzip-compressed JSON batches to the ingest gateway."""

    def __init__(
        self,
        gateway_url: str = "https://ingest.deploythefleet.com/v1/ingest",
        api_key: str = "",
        device_id: str = "",
        firmware_version: str = "",
        hardware_variant: str = "",
    ) -> None:
        self._gateway_url = gateway_url
        self._api_key = api_key
        self.device_id = device_id
        self.firmware_version = firmware_version
        self.hardware_variant = hardware_variant

    def _do_request(self, body: bytes) -> bool:
        req = urllib.request.Request(
            self._gateway_url,
            data=body,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
                "Content-Encoding": "gzip",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return bool(200 <= resp.status < 300)
        except urllib.error.HTTPError as exc:
            logger.error("[dtf-serial] HTTP error sending events: %s", exc.code)
            return False
        except Exception as exc:
            logger.error("[dtf-serial] Error sending events: %s", exc)
            return False

    async def send(self, events: list[Event]) -> bool:
        payload = {
            "sv": 1,
            "d": self.device_id,
            "fv": self.firmware_version,
            "hw": self.hardware_variant,
            "src": "serial",
            "e": [event.to_dict() for event in events],
        }
        body = gzip.compress(json.dumps(payload).encode())
        return await asyncio.to_thread(self._do_request, body)
