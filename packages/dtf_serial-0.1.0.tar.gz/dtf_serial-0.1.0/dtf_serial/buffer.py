"""Buffer Protocol for batching log events before transport."""

import asyncio
from collections import deque
from typing import Protocol

from dtf_serial.events import Event

_DEFAULT_MAX_SIZE = 10_000


class BufferProtocol(Protocol):
    async def add(self, event: Event) -> None: ...
    async def drain(self) -> list[Event]: ...
    def __len__(self) -> int: ...


class InMemoryBuffer:
    """Asyncio-safe in-memory buffer implementing BufferProtocol.

    Bounded by max_size; when full, the oldest event is evicted on add().
    """

    def __init__(self, max_size: int = _DEFAULT_MAX_SIZE) -> None:
        self._events: deque[Event] = deque(maxlen=max_size)
        self._lock: asyncio.Lock = asyncio.Lock()
        self._size: int = 0

    async def add(self, event: Event) -> None:
        async with self._lock:
            self._events.append(event)
            self._size = len(self._events)

    async def drain(self) -> list[Event]:
        async with self._lock:
            events = list(self._events)
            self._events.clear()
            self._size = 0
            return events

    def __len__(self) -> int:
        return self._size
