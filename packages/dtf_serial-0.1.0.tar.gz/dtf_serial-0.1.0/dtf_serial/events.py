"""Event dataclasses for log and raw serial events."""

from dataclasses import dataclass
from typing import Any, Union


@dataclass
class LogEvent:
    """Successfully parsed ESP-IDF log line."""

    lv: str  # log level: v, d, i, w, e
    mod: str  # module tag
    m: str  # message
    wts: int  # wall timestamp (UTC millis from host clock)

    def to_dict(self) -> dict[str, Any]:
        return {"t": "l", "lv": self.lv, "mod": self.mod, "m": self.m, "wts": self.wts}


@dataclass
class RawEvent:
    """Unparseable line passed through as-is."""

    m: str  # full raw line
    wts: int  # wall timestamp (UTC millis from host clock)

    def to_dict(self) -> dict[str, Any]:
        return {"t": "l", "m": self.m, "wts": self.wts}


Event = Union[LogEvent, RawEvent]
