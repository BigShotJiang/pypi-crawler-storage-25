"""Configuration loading from .dtf-serial.toml and CLI flags."""

import sys

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import click
import tomli_w

CONFIG_FILENAME = ".dtf-serial.toml"
DEFAULT_BAUD = 115200
DEFAULT_FIRMWARE_VERSION = "1.0.0"
DEFAULT_HARDWARE_VARIANT = "1.0.0"
DEFAULT_GATEWAY_URL = "https://ingest.deploythefleet.com/v1/ingest"


@dataclass(frozen=True)
class DtfConfig:
    api_key: str
    port: str
    baud: int
    device_id: str
    firmware_version: str
    hardware_variant: str
    gateway_url: str


def load_config_file(path: Path) -> dict[str, Any]:
    """Read .dtf-serial.toml; return empty dict if not found."""
    try:
        with open(path, "rb") as f:
            return tomllib.load(f)
    except FileNotFoundError:
        return {}
    except tomllib.TOMLDecodeError as exc:
        raise click.ClickException(f"Invalid TOML in {path}: {exc}") from exc


def save_config_file(path: Path, config: dict[str, Any]) -> None:
    """Write config dict to path using tomli_w."""
    with open(path, "wb") as f:
        tomli_w.dump(config, f)


def prompt_missing(partial: dict[str, Any]) -> dict[str, Any]:
    """Prompt for any missing required values; return updated dict."""
    result = dict(partial)

    if not result.get("key"):
        result["key"] = click.prompt("API key")

    if not result.get("device_id"):
        result["device_id"] = click.prompt("Device ID")

    if not result.get("firmware_version"):
        result["firmware_version"] = click.prompt(
            "Firmware version", default=DEFAULT_FIRMWARE_VERSION
        )

    return result


def resolve_config(cli_flags: dict[str, Any]) -> DtfConfig:
    """Merge CLI flags → file → prompts → defaults into a DtfConfig.

    Saves config to file if interactive prompts were needed.
    """
    config_path = Path(CONFIG_FILENAME)
    file_values = load_config_file(config_path)

    # CLI flags win over file values (only non-None CLI flags are passed in)
    merged: dict[str, Any] = {**file_values, **cli_flags}

    required_keys = {"key", "device_id", "firmware_version"}
    needs_prompt = any(not merged.get(k) for k in required_keys)

    if needs_prompt:
        merged = prompt_missing(merged)
        save_config_file(config_path, merged)

    return DtfConfig(
        api_key=merged["key"],
        port=merged.get("port", ""),
        baud=int(merged.get("baud", DEFAULT_BAUD)),
        device_id=merged["device_id"],
        firmware_version=merged.get("firmware_version", DEFAULT_FIRMWARE_VERSION),
        hardware_variant=str(merged.get("hardware_variant", DEFAULT_HARDWARE_VARIANT)),
        gateway_url=str(merged.get("gateway_url", DEFAULT_GATEWAY_URL)),
    )
