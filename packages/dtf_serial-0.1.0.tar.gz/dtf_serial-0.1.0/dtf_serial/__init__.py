"""DTF Serial Agent — captures ESP32 UART output and ships logs to DTF ingest."""
