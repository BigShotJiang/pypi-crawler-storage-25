"""Parser Protocol and ESP-IDF implementation."""

import re
import time
from typing import Protocol

from dtf_serial.events import Event, LogEvent, RawEvent

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[a-zA-Z]")
_ESPIDF_RE = re.compile(r"^([VDIWE])\s+\((\d*)\)\s+(.+?):\s+(.*)$")
_LEVEL_MAP = {"V": "v", "D": "d", "I": "i", "W": "w", "E": "e"}


def strip_ansi(line: str) -> str:
    return _ANSI_RE.sub("", line)


class ParserProtocol(Protocol):
    def parse(self, line: str) -> Event: ...


class EspIdfParser:
    def parse(self, line: str) -> Event:
        wts = time.time_ns() // 1_000_000
        stripped = strip_ansi(line).strip()
        m = _ESPIDF_RE.match(stripped)
        if m:
            lv = _LEVEL_MAP[m.group(1)]
            tag = m.group(3)
            msg = m.group(4)
            return LogEvent(lv=lv, mod=tag, m=msg, wts=wts)
        return RawEvent(m=stripped, wts=wts)
