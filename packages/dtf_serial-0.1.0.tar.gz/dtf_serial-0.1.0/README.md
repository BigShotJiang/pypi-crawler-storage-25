# dtf-serial

CLI tool that captures ESP32 UART output and ships structured logs to the [Deploy The Fleet](https://deploythefleet.com) ingest gateway.

```
USB/UART → SerialReader → Parser → Buffer → Transport → POST /v1/ingest
```

## Install

```bash
pipx install dtf-serial
```

### Install from TestPyPI (pre-release)

```bash
pipx install dtf-serial --pip-args="--index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/"
```

To update when a new version is published:

```bash
pipx install dtf-serial --force --pip-args="--index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/"
```

### Install from source

```bash
pip install -e .

# With dev tools (pytest, black, flake8, mypy)
pip install -e ".[dev]"
```

## Usage

```bash
# Interactive first run — prompts for API key, device ID, firmware version
dtf-serial

# Or pass everything via flags
dtf-serial --key dtf_k_YOUR_KEY --device-id esp32-001 --fw-version 2.0.0
```

Settings are saved to `.dtf-serial.toml` in the current directory. CLI flags override file values.

### All flags

| Flag | Description | Default |
|------|-------------|---------|
| `--key` | DTF ingest API key | *(prompted)* |
| `--device-id` | Device identifier | *(prompted)* |
| `--port` | Serial port (e.g. `/dev/ttyUSB0`) | auto-detect |
| `--baud` | Baud rate | `115200` |
| `--fw-version` | Firmware version | `1.0.0` |
| `--hw` | Hardware variant | `1.0.0` |
| `--gateway` | Ingest gateway URL | `https://ingest.deploythefleet.com/v1/ingest` |

### Serial port auto-detection

When `--port` is omitted, dtf-serial scans for known USB-UART chips (CP210x, CH340, FTDI). If no device is found it waits for one to be plugged in.

## Test server

A local mock ingest server is included for development:

```bash
# Terminal 1
python tools/test_server.py --port 8000

# Terminal 2
dtf-serial --gateway http://localhost:8000/v1/ingest
```

The test server validates auth headers, decompresses payloads, and pretty-prints received events.

## Development

```bash
# Run all checks
black --check dtf_serial/ tests/
flake8 dtf_serial/ tests/
mypy dtf_serial/
pytest tests/ --tb=short
```

## Publishing

Publishing is handled by CI:

- **TestPyPI** — automatically published on every push to `next` (when the version is bumped)
- **PyPI** — published when a GitHub release is created
