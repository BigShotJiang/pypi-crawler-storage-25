"""Polily TUI — interactive terminal interface (Textual)."""

import logging
from pathlib import Path

from textual.app import App
from textual.widgets import Input

from polily.core.events import TOPIC_LANGUAGE_CHANGED, get_event_bus
from polily.core.user_prefs import get_pref, set_pref
from polily.tui import i18n
from polily.tui.bindings import GLOBAL_BINDINGS
from polily.tui.screens.main import MainScreen
from polily.tui.service import PolilyService
from polily.tui.theme import register_polily_theme

logger = logging.getLogger(__name__)


class PolilyApp(App):
    """Polily — A Polymarket Monitoring Agent That Actually Works (interactive TUI)."""

    TITLE = "Polily"
    SUB_TITLE = "A Polymarket Monitoring Agent That Actually Works"
    CSS_PATH = ["css/tokens.tcss", "css/app.tcss"]

    BINDINGS = GLOBAL_BINDINGS

    def __init__(self, service: PolilyService | None = None):
        super().__init__()
        self.service = service or PolilyService()
        self._init_i18n_from_prefs()

    def _init_i18n_from_prefs(self) -> None:
        """Resolve startup language: DB user_prefs.language > config.tui.language > "zh".

        Loaded once during __init__ (before any view composes) so the very first
        render already sees translated strings — no flash of zh during startup
        when the user previously chose en.
        """
        catalogs_dir = Path(i18n.__file__).parent / "catalogs"
        catalogs = i18n.load_catalogs(catalogs_dir)
        configured = self.service.config.tui.language
        stored = get_pref(self.service.db, "language", default=configured)
        if stored not in catalogs:
            logger.warning("i18n: stored language %r not in catalogs (%s); falling back to %r",
                           stored, sorted(catalogs), configured)
            stored = configured
        i18n.init_i18n(catalogs, default=stored)

    def on_mount(self) -> None:
        register_polily_theme(self)  # NEW: register brand theme
        self._restart_daemon()
        self.push_screen(MainScreen(self.service))

    def _restart_daemon(self) -> None:
        """Restart scheduler daemon on every TUI launch.

        Previously only started the daemon if it wasn't already running. Now
        we always restart (when there are auto-monitored events) so the
        daemon picks up the latest code the user has committed. New daemon
        writes a fresh `data/logs/poll-v<ver>-<ts>.log`; old logs are kept.
        """
        from polily.core.monitor_store import get_active_monitors
        monitors = get_active_monitors(self.service.db)
        if not monitors:
            return
        try:
            from polily.daemon.scheduler import restart_daemon
            if restart_daemon():
                self.notify(i18n.t("app.notify.daemon_restarted"))
        except Exception:
            pass  # non-fatal — daemon can be started manually

    async def action_quit(self) -> None:
        """Kill everything and exit immediately."""
        self.exit()

    async def action_back(self) -> None:
        """ESC handler — release focused Input first, then pop screen.

        Two semantics in priority order:

        1. If an Input widget has focus (e.g. the Polymarket URL field on
           the main screen), defocus it. While Input has focus every keypress
           goes to the text buffer, so the user can't reach the digit-nav /
           q / r shortcuts — ESC is the canonical "let me out" key.

        2. Otherwise, pop the current screen if there's one underneath.
           Textual seeds the screen stack with an empty `Screen(id="_default")`
           at index 0 before any `push_screen` runs, so on the main screen
           the stack is `[_default, MainScreen]` (length 2) — a plain
           `len > 1` check would pop MainScreen and reveal the empty
           default. Skip the pop when MainScreen is on top.
        """
        if isinstance(self.focused, Input):
            self.screen.set_focus(None)
            return
        if isinstance(self.screen, MainScreen):
            return
        if len(self.screen_stack) > 1:
            self.pop_screen()

    async def action_help(self) -> None:
        """Placeholder for help overlay — Phase 3 actual overlay widget.
        For now, notify."""
        self.notify(i18n.t("app.notify.help_placeholder"), severity="information")

    async def action_toggle_language(self) -> None:
        """Cycle through available languages, persist to DB, broadcast change.

        I18nFooter (every screen on stack) re-composes via TOPIC_LANGUAGE_CHANGED
        subscription. Views that mix i18n strings into their own widgets must
        also subscribe to the same topic and call recompose=True (see wallet.py
        for the canonical pattern).
        """
        langs = i18n.available_languages()
        if not langs:
            return
        try:
            idx = langs.index(i18n.current_language())
        except ValueError:
            idx = -1
        next_lang = langs[(idx + 1) % len(langs)]
        i18n.set_language(next_lang)
        set_pref(self.service.db, "language", next_lang)
        get_event_bus().publish(TOPIC_LANGUAGE_CHANGED, {"language": next_lang})


def run_tui(service: PolilyService | None = None) -> None:
    """Entry point for TUI mode.

    If `service` is provided, the TUI uses it directly (avoids double-loading
    config from db when the CLI already built one for the yaml regen hook).
    Otherwise the TUI builds its own PolilyService.

    If service construction fails with ConfigValidationError (db.config has
    invalid values that Pydantic refuses), show FatalConfigScreen instead of
    the normal app — user must run a CLI escape hatch
    (`polily config reset --all` / `polily config reset <key>`) and relaunch.
    Per design §7.3 / Q4.
    """
    if service is None:
        from polily.core.config import ConfigValidationError
        try:
            service = PolilyService()
        except ConfigValidationError as e:
            from polily.tui.views._config_fatal_screen import FatalConfigScreen

            error_message = str(e)

            class _FatalApp(App):
                def on_mount(self) -> None:
                    self.push_screen(FatalConfigScreen(error_message=error_message))

            _FatalApp().run()
            import os

            from polily.tui.terminal_cleanup import cleanup_terminal
            # _FatalApp's driver is already torn down by app.run() returning,
            # so the canonical path is unreachable; cleanup_terminal falls
            # back to writing DECRST sequences directly. See R5-B.
            cleanup_terminal(app=None)
            os._exit(1)

    app = PolilyApp(service=service)
    try:
        app.run()
    finally:
        # Force-kill all child processes and exit immediately.
        # claude CLI (used by AI agents) spawns Node.js subprocesses that
        # survive normal Python shutdown (sys.exit, atexit). os._exit bypasses
        # all cleanup but is the only reliable way to terminate. SQLite writes
        # are committed before reaching this point. See README Limitations.
        # R5-B: cleanup_terminal restores mouse-tracking + alt-screen modes
        # before os._exit so the user's terminal isn't left spewing raw SGR
        # escape sequences. By the time `app.run()` returns, Textual has
        # already torn the driver down, so the fallback path applies.
        import os

        from polily.tui.terminal_cleanup import cleanup_terminal
        cleanup_terminal(app)
        os._exit(0)
