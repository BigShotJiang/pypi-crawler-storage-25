"""Refresh market + event scores using live prices.

Called by global_poll after price update (Step 2).
Only recalculates price-sensitive dimensions; verifiability and time are stable.
"""

import json
import logging
from dataclasses import dataclass
from datetime import UTC, datetime

from polily.core.db import PolilyDB
from polily.core.event_store import (
    MarketRow,
    get_event,
    market_row_to_model,
)
from polily.price_feeds import extract_crypto_asset, extract_threshold_price
from polily.scan.mispricing import MispricingResult, detect_mispricing
from polily.scan.scoring import _DEFAULT_WEIGHTS, _TYPE_WEIGHTS, compute_structure_score

logger = logging.getLogger(__name__)


@dataclass
class RefreshResult:
    markets_refreshed: int = 0
    events_refreshed: int = 0


def refresh_scores(
    db: PolilyDB,
    underlying_prices: dict[str, float],
    config=None,
) -> RefreshResult:
    """Recalculate scores for all markets that have a score_breakdown.

    1. Group scored markets by event
    2. For each market: rebuild Market model, recalc mispricing + score
    3. Merge fresh scores into existing breakdown (preserve verifiability/time)
    4. Recalculate event-level scores
    5. Batch commit
    """
    from polily.scan.event_scoring import compute_event_quality_score

    if config is None:
        from polily.core.config import PolilyConfig
        config = PolilyConfig()

    # v0.11.5: commentary text no longer persisted into score_breakdown
    # (view layer renders live via polily.tui.commentary_render). Daemon
    # only refreshes numeric breakdown — F2 toggle takes effect on next
    # view paint without daemon coordination.

    result = RefreshResult()
    now = datetime.now(UTC).isoformat()

    # Collect scored markets from monitored events only
    with db.transaction() as conn:
        rows = conn.execute(
            """SELECT m.*, e.market_type
            FROM markets m
            JOIN events e ON m.event_id = e.event_id
            JOIN event_monitors em ON e.event_id = em.event_id
            WHERE m.active = 1 AND m.closed = 0
            AND m.score_breakdown IS NOT NULL
            AND e.closed = 0
            AND em.auto_monitor = 1""",
        ).fetchall()

    if not rows:
        return result

    # Group by event_id
    by_event: dict[str, list] = {}
    for row in rows:
        eid = row["event_id"]
        by_event.setdefault(eid, []).append(row)

    # Map ccxt pair → Binance symbol for underlying lookup
    # e.g. "BTC/USDT" → underlying_prices["BTCUSDT"]
    def _get_underlying(event_title: str) -> float | None:
        pair = extract_crypto_asset(event_title)
        if not pair:
            return None
        sym = pair.replace("/", "")
        return underlying_prices.get(sym)

    # AF-3 (v0.11.7): import once outside the loop.
    # score_refresh.py runs periodically; without recomputing implied_fair_value
    # here, the value from pipeline's last run goes stale (dict() copy of
    # old_bd preserves but never refreshes the key). Build all markets first,
    # then compute implied_fv per-event before per-market write so the write
    # loop can stamp the fresh value.
    from polily.scan.event_scoring import compute_implied_fair_values

    for event_id, market_rows in by_event.items():
        try:
            event = get_event(event_id, db)
            if not event:
                continue

            market_type = event.market_type or "other"
            tw = _TYPE_WEIGHTS.get(market_type, _DEFAULT_WEIGHTS)
            underlying = _get_underlying(event.title)

            # Build Market models for event-level scoring
            market_models = []
            # Pair (MarketRow, Market) so the per-market write loop can
            # access both without rebuilding from mrow twice.
            paired: list[tuple] = []

            for mrow in market_rows:
                mr = MarketRow.model_validate(dict(mrow))
                market = market_row_to_model(mr, market_type=market_type)
                market_models.append(market)
                paired.append((mr, market))

            # AF-3: compute implied_fair_value per-event from current
            # in-memory Market models (which carry fresh yes_price from DB).
            implied_fv_by_market = compute_implied_fair_values(event, market_models)

            for mr, market in paired:

                old_bd = json.loads(mr.score_breakdown)

                # Recalculate mispricing (crypto only)
                mispricing = MispricingResult(signal="none")
                if market_type in ("crypto", "crypto_threshold") and underlying is not None:
                    old_pp = old_bd.get("price_params", {})
                    threshold = old_pp.get("threshold_price") or extract_threshold_price(mr.question)
                    vol = old_pp.get("annual_volatility")
                    if threshold and vol:
                        mispricing = detect_mispricing(
                            market, config.mispricing,
                            current_underlying_price=underlying,
                            threshold_price=threshold,
                            annual_volatility=vol,
                        )

                # Recalculate structure score
                score = compute_structure_score(market, mispricing=mispricing)

                # Merge into existing breakdown (preserve verifiability, time, commentary structure)
                new_bd = dict(old_bd)
                new_bd["liquidity"] = round(score.liquidity_structure, 1)
                new_bd["probability"] = round(score.probability_space, 1)
                new_bd["friction"] = round(score.trading_friction, 1)
                if tw.get("net_edge", 0) > 0:
                    new_bd["net_edge"] = round(score.net_edge, 1)

                # Update mispricing data
                if mispricing.theoretical_fair_value is not None or mispricing.signal != "none":
                    new_bd["mispricing"] = {
                        "fair_value": mispricing.theoretical_fair_value,
                        "fair_value_low": mispricing.fair_value_low,
                        "fair_value_high": mispricing.fair_value_high,
                        "deviation_pct": mispricing.deviation_pct,
                        "direction": mispricing.direction,
                        "signal": mispricing.signal,
                        "model_confidence": mispricing.model_confidence,
                    }
                if underlying is not None and "price_params" in new_bd:
                    new_bd["price_params"]["underlying_price"] = underlying

                # Round-trip friction
                if market.round_trip_friction_pct is not None:
                    new_bd["round_trip_friction_pct"] = round(market.round_trip_friction_pct, 4)

                # v0.11.5: commentary not persisted (view renders live).
                # Drop any stale `commentary` key from old data so the
                # JSON stays clean on next read.
                new_bd.pop("commentary", None)

                # AF-3 (v0.11.7): refresh implied_fair_value with current
                # yes_prices. If the event no longer qualifies (e.g., became
                # non-negRisk — defensive, unlikely in practice), drop the
                # stale key from old_bd so it doesn't outlive its truth.
                mid = mr.market_id
                if mid in implied_fv_by_market:
                    new_bd["implied_fair_value"] = implied_fv_by_market[mid]
                else:
                    new_bd.pop("implied_fair_value", None)

                with db.transaction() as conn:
                    conn.execute(
                        "UPDATE markets SET structure_score = ?, score_breakdown = ?, updated_at = ? WHERE market_id = ?",
                        (score.total, json.dumps(new_bd, ensure_ascii=False, default=str), now, mr.market_id),
                    )
                result.markets_refreshed += 1

            # Recalculate event-level score
            if market_models:
                event_score = compute_event_quality_score(event, market_models)
                with db.transaction() as conn:
                    conn.execute(
                        "UPDATE events SET structure_score = ?, updated_at = ? WHERE event_id = ?",
                        (event_score.total, now, event_id),
                    )
                result.events_refreshed += 1

        except Exception:
            logger.exception("Score refresh failed for event %s", event_id)
            continue

    # v0.11.6: each UPDATE auto-commits on its own `with db.transaction()`
    # exit. Was: trailing db.conn.commit() flushed the whole loop's writes.
    # Per-row commit under WAL has equivalent perf and avoids losing
    # earlier work on a mid-loop failure.

    if result.markets_refreshed > 0:
        logger.debug(
            "Refreshed %d markets, %d events",
            result.markets_refreshed, result.events_refreshed,
        )

    return result
