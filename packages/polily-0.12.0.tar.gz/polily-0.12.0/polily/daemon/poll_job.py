"""Global poll job -- fetches prices for ALL active markets every 30s.

Architecture:
  - ONE global poll function, registered as IntervalTrigger in daemon
  - Step 1   (price layer): fetch CLOB + Binance concurrently -> update markets table
  - Step 1.5 (resolution): for markets closed this tick that the user holds,
    fetch Gamma outcomePrices and settle via ResolutionHandler
  - Step 2   (score refresh): recalculate mispricing + scores for scored markets
  - Step 3   (intelligence layer): for monitored events -> compute signals

Module-level _ctx pattern (PollerContext) for db/config/scheduler/wallet access.
"""

import asyncio
import json
import logging
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from polily.core import clob as _clob
from polily.core.db import PolilyDB
from polily.core.event_store import (
    get_event,
    get_event_markets,
    mark_market_closed,
    update_market_prices,
)
from polily.daemon.close_event import close_event
from polily.daemon.resolution import derive_winner
from polily.price_feeds import extract_crypto_asset

if TYPE_CHECKING:
    from polily.core.positions import PositionManager
    from polily.core.wallet import WalletService
    from polily.daemon.resolution import ResolutionHandler

logger = logging.getLogger(__name__)

# Max concurrent market fetches. Each slot holds 4 requests
# (/book + /midpoint + /price BUY + /price SELL).
_SEMAPHORE_LIMIT = 100
_poll_count = 0  # Safe: poll executor is single-threaded (APScheduler config)
_poll_log: logging.Logger | None = None

# v0.11.4 OBS-1: split httpx timeouts. Pre-v0.11.4 used `timeout=15` which
# set ALL fields (connect/read/write/pool) to 15s. The dominant tail under
# Polymarket CLOB load was read=15s. Connect/write/pool drop to defaults
# that fail fast.
_HTTPX_TIMEOUT = httpx.Timeout(connect=5.0, read=10.0, write=10.0, pool=10.0)

# v0.11.4 OBS-1: per-tick circuit breaker. After 5 consecutive ConnectErrors
# in a single poll tick, abort retries for remaining markets to prevent the
# 19-min worst-case retry storm under sustained outage. Reset at the start
# of every tick via _reset_tick_circuit_breaker().
_TICK_FAIL_COUNT = 0
_BREAKER_THRESHOLD = 5

# v0.11.4 OBS-1: shared semaphore for _fetch_one. Module-level so
# _fetch_one (now module-level) can use it without nesting.
_FETCH_SEMAPHORE: asyncio.Semaphore | None = None


def _get_fetch_semaphore() -> asyncio.Semaphore:
    """Lazy-init asyncio.Semaphore tied to the current event loop.

    Created on first use because asyncio.Semaphore must bind to a running
    loop; module-import time has no loop.
    """
    global _FETCH_SEMAPHORE
    if _FETCH_SEMAPHORE is None:
        _FETCH_SEMAPHORE = asyncio.Semaphore(_SEMAPHORE_LIMIT)
    return _FETCH_SEMAPHORE


def _reset_tick_circuit_breaker() -> None:
    """Called at the start of every poll tick to reset the breaker."""
    global _TICK_FAIL_COUNT
    _TICK_FAIL_COUNT = 0


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1.5, min=1, max=10),
    retry=retry_if_exception_type((httpx.ConnectError, httpx.TimeoutException)),
    reraise=True,  # re-raise the original exception (not RetryError) so
                   # circuit-breaker counter logic can match exception type
)
async def _fetch_one_inner(client: httpx.AsyncClient, market) -> dict:
    """Inner: tenacity-retried fetch. 3 attempts, exponential backoff.

    Calls via module-level `_clob.fetch_clob_market_data` so existing
    tests that `patch("polily.core.clob.fetch_clob_market_data")` continue
    to take effect, AND new tests that `monkeypatch.setattr(poll_job,
    "fetch_clob_market_data", ...)` also take effect via the alias below.
    """
    return await fetch_clob_market_data(client, market.clob_token_id_yes)


async def _fetch_one(client: httpx.AsyncClient, market) -> dict:
    """v0.11.4: retry transient errors via tenacity (3 attempts, exponential
    backoff). Circuit breaker: after 5 consecutive ConnectErrors in a single
    tick, skip retries for remaining markets to prevent retry-storm-induced
    poll skip cascade.
    """
    global _TICK_FAIL_COUNT
    sem = _get_fetch_semaphore()
    if _TICK_FAIL_COUNT >= _BREAKER_THRESHOLD:
        # Breaker tripped — single attempt, no retry
        async with sem:
            return await fetch_clob_market_data(client, market.clob_token_id_yes)
    try:
        async with sem:
            return await _fetch_one_inner(client, market)
    except (httpx.ConnectError, httpx.TimeoutException):
        _TICK_FAIL_COUNT += 1
        raise


async def fetch_clob_market_data(*args, **kwargs):
    """Module-level async alias for polily.core.clob.fetch_clob_market_data.

    Why this exists (v0.11.4): two test-patch styles must both work:
    1. `patch("polily.core.clob.fetch_clob_market_data")` — used by 20+
       existing tests. Resolves through `_clob.fetch_clob_market_data`
       attribute lookup.
    2. `monkeypatch.setattr(poll_job, "fetch_clob_market_data", ...)` —
       used by v0.11.4 retry/circuit-breaker tests.

    Implementation: this thin async proxy looks up the attribute on
    `_clob` at call time, so style 1 works. Style 2 replaces THIS module
    attribute entirely, short-circuiting the proxy.
    """
    return await _clob.fetch_clob_market_data(*args, **kwargs)

# Gamma API for post-close resolution checks.
GAMMA_BASE_URL = "https://gamma-api.polymarket.com"
# Tight timeout — same as TradeEngine live-price fetch. Resolution is
# best-effort per tick; a miss now retries 30s later.
_GAMMA_TIMEOUT = 2.0
# Cap concurrent Gamma requests when many markets close in one tick (e.g.
# end-of-week expiry batch) so we don't DoS the free public endpoint.
_GAMMA_CONCURRENCY = 5


async def _fetch_gamma_market(market_id: str) -> dict | None:
    """GET Gamma /markets/{market_id}; None on any failure.

    Per-tick best-effort. Errors are split by kind:
    - transient network/HTTP errors → WARN (expected at the free-tier edge)
    - malformed/missing JSON → ERROR (schema drift → needs a human)
    """
    try:
        async with httpx.AsyncClient(timeout=_GAMMA_TIMEOUT) as client:
            r = await client.get(f"{GAMMA_BASE_URL}/markets/{market_id}")
            r.raise_for_status()
            return r.json()
    except (httpx.TimeoutException, httpx.TransportError, httpx.HTTPStatusError) as e:
        logger.warning("gamma fetch failed for %s (transient): %s", market_id, e)
        return None
    except (json.JSONDecodeError, ValueError, KeyError) as e:
        logger.error(
            "gamma response malformed for %s — possible schema drift: %s",
            market_id, e, exc_info=True,
        )
        return None


async def _run_resolution_pass(
    market_ids: list[str],
    db: PolilyDB,
    wallet: "WalletService",
    positions: "PositionManager",
    resolver: "ResolutionHandler",
) -> None:
    """Fan out resolution checks across all markets closed this tick.

    Wrapped in a coroutine so `asyncio.run()` owns the event loop lifetime.
    Pre-3.12 Python tolerated `asyncio.gather(*[coro_call(...)])` outside a
    loop; 3.14 raises at `asyncio.events.get_event_loop()` because the
    coroutines are constructed before `asyncio.run()` installs the loop.

    Concurrency is capped via a semaphore to avoid hammering Gamma's free
    public endpoint during end-of-week close storms.
    """
    sem = asyncio.Semaphore(_GAMMA_CONCURRENCY)

    async def _one(mid: str) -> None:
        async with sem:
            await _resolve_closed_market_if_position(
                mid, db, wallet, positions, resolver,
            )

    await asyncio.gather(*[_one(mid) for mid in market_ids])


async def _resolve_closed_market_if_position(
    market_id: str,
    db: PolilyDB,
    wallet: "WalletService",
    positions: "PositionManager",
    resolver: "ResolutionHandler",
) -> None:
    """Resolve a closed market — writes `markets.resolved_outcome` and
    (if user holds positions) credits wallet via RESOLVE tx.

    v0.8.5: `_has_positions` early-return removed so `resolved_outcome`
    is authoritative on `closed=1` markets regardless of user position.
    This is required by the lifecycle state model: `resolved_outcome IS
    NULL` unambiguously means "SETTLING" (UMA 2h window). Wallet credit
    is still position-gated inside `ResolutionHandler.resolve_market`
    (empty `positions` rows → no credit loop iterations).

    Function name kept for backwards compat with existing callers /
    tests; `_if_position` is now a historical suffix.
    """
    data = await _fetch_gamma_market(market_id)
    if data is None:
        return  # transient HTTP error or timeout — retry next tick
    prices_raw = data.get("outcomePrices", "[]")
    prices = (
        json.loads(prices_raw) if isinstance(prices_raw, str) else (prices_raw or [])
    )
    uma_raw = data.get("umaResolutionStatuses", "[]")
    try:
        uma_statuses = (
            json.loads(uma_raw) if isinstance(uma_raw, str) else (uma_raw or [])
        )
    except (ValueError, TypeError):
        uma_statuses = []
    winner = derive_winner(prices, uma_statuses=uma_statuses)
    if winner is None:
        return  # UMA pre-finalization, dispute in progress, or malformed response
    n_settled, credited = resolver.resolve_market(market_id, winner)
    if n_settled > 0:
        _get_poll_log().info(
            f"           resolved| {market_id} -> {winner} "
            f"| {n_settled} position{'s' if n_settled != 1 else ''} "
            f"credited ${credited:.2f}"
        )


async def backfill_stuck_resolutions(
    db: PolilyDB,
    wallet: "WalletService",
    positions: "PositionManager",
    resolver: "ResolutionHandler",
) -> int:
    """One-time startup pass: heal `closed=1 AND resolved_outcome IS NULL` rows.

    Pre-v0.8.5 the resolver early-returned on no-position markets, leaving
    their `resolved_outcome` at NULL forever. Post-v0.8.5 the live flow
    handles new closures correctly, but legacy rows stay stuck. This pass
    walks stuck markets at daemon startup and feeds each through the
    standard resolver path.

    **Concurrency safety**: this function writes `markets.resolved_outcome`
    via `ResolutionHandler.resolve_market`, whose atomic tx is idempotent
    under retry (SQLite serializes on write lock; already-resolved rows
    are excluded by the `WHERE resolved_outcome IS NULL` filter). Safe to
    run alongside other writers (TUI scan, poll ticks), though in practice
    `scheduler.run_daemon` invokes this **before** `scheduler.start()` to
    avoid thrashing.

    **Blast-radius cap**: limited to 100 rows per invocation so daemon
    startup stays under ~40s worst case (100 / _GAMMA_CONCURRENCY × Gamma
    timeout). Remaining stuck rows heal on subsequent restarts — this is
    a legacy-data migration path, not a live-operation dependency.

    Returns the number of markets processed (for logging).
    """
    with db.transaction() as conn:
        rows = conn.execute(
            "SELECT market_id FROM markets "
            "WHERE closed = 1 AND resolved_outcome IS NULL "
            "LIMIT 100"
        ).fetchall()
    if not rows:
        return 0

    sem = asyncio.Semaphore(_GAMMA_CONCURRENCY)

    async def _one(mid: str) -> None:
        async with sem:
            await _resolve_closed_market_if_position(
                mid, db, wallet, positions, resolver,
            )

    await asyncio.gather(*[_one(r["market_id"]) for r in rows])
    return len(rows)


def _build_poll_log_path(project_root: "Path | None" = None) -> "Path":  # noqa: F821
    """Build the poll log path for this daemon instance.

    Pattern: ``<paths.log_dir()>/poll-v<version>-<YYYYMMDD-HHMMSS>.log``.
    Each daemon restart gets a fresh file — callers keep the history.
    Directory is created lazily inside ``paths.log_dir()``.

    v0.11.0 (Whis-review S3): the log dir resolves via the paths module.
    Pre-fix: ``Path(__file__).resolve().parent.parent.parent / "data" / "logs"``.
    Under pipx install, ``Path(__file__)`` lives in ``site-packages`` which
    is read-only on most systems — daemon would crash on first poll cycle.

    The ``project_root`` parameter is preserved for legacy callers/tests
    that want to inject a sandbox; if non-None it overrides the paths
    module just like before.
    """
    from datetime import datetime

    from polily import __version__
    from polily.core import paths

    if project_root is not None:
        log_dir = project_root / "data" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
    else:
        log_dir = paths.log_dir()  # paths.log_dir() lazy-mkdirs internally
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    return log_dir / f"poll-v{__version__}-{ts}.log"


def _get_poll_log() -> logging.Logger:
    """Lazy-init a dedicated file logger for this daemon's poll log."""
    global _poll_log
    if _poll_log is not None:
        return _poll_log
    path = _build_poll_log_path()
    _poll_log = logging.getLogger("polily.poll")
    _poll_log.propagate = False
    handler = logging.FileHandler(str(path))
    handler.setFormatter(logging.Formatter("%(message)s"))
    _poll_log.addHandler(handler)
    _poll_log.setLevel(logging.INFO)
    return _poll_log


@dataclass(frozen=True)
class PollerContext:
    """Immutable context -- swapped atomically to avoid thread-safety races.

    wallet/positions/resolver are required so that auto-resolution cannot be
    silently disabled by a forgotten init_poller arg (user's money at stake).
    """

    db: PolilyDB
    wallet: "WalletService"
    positions: "PositionManager"
    resolver: "ResolutionHandler"
    config: Any = None
    scheduler: Any = None


# Single reference (set once on daemon startup via init_poller)
_ctx: PollerContext | None = None

def init_poller(
    db: PolilyDB,
    wallet: "WalletService",
    positions: "PositionManager",
    resolver: "ResolutionHandler",
    config: Any = None,
    scheduler: Any = None,
) -> None:
    """Initialize module-level context."""
    global _ctx
    _ctx = PollerContext(
        db=db,
        wallet=wallet,
        positions=positions,
        resolver=resolver,
        config=config,
        scheduler=scheduler,
    )


def global_poll(db: PolilyDB | None = None) -> None:
    """One poll cycle: fetch all active markets, update prices, refresh scores.

    If *db* is passed directly (for testing), uses it.
    Otherwise reads from module-level _ctx.
    """
    import time as _time

    global _poll_count

    if db is None:
        if _ctx is None:
            logger.error("global_poll called before init_poller")
            return
        db = _ctx.db

    t_start = _time.monotonic()
    _poll_count += 1
    warn = False

    # v0.11.4 OBS-1: reset per-tick circuit breaker. After 5 consecutive
    # ConnectErrors in a single tick, _fetch_one switches to single-attempt
    # mode for the remaining markets to prevent retry-storm.
    _reset_tick_circuit_breaker()

    markets = _get_monitored_markets(db)
    fetchable = [m for m in markets if m.clob_token_id_yes]

    if not fetchable:
        return

    # Emit banner up front so mid-tick log lines (e.g. `resolved|` from
    # Step 1.5) appear chronologically below the tick header they belong
    # to, not above it. Pre-v0.6.0 had no mid-tick logging so the banner
    # was written at the end as a summary header; that inverts reader
    # expectations once auto-resolution joined the flow.
    _get_poll_log().info(f"── poll #{_poll_count} {'─' * 50}")

    # --- Step 1: Fetch CLOB + Binance concurrently ---
    crypto_symbols = _collect_crypto_symbols(db)

    t_fetch = _time.monotonic()
    results, underlying_prices, trades_by_id = asyncio.run(
        _fetch_all(fetchable, crypto_symbols),
    )
    clob_elapsed = _time.monotonic() - t_fetch

    # Process results
    closed_count = 0
    err_count = 0
    err_by_type: dict[str, int] = {}
    closed_by_event: dict[str, list[str]] = {}
    price_ok = 0  # markets with midpoint price
    book_ok = 0   # markets with orderbook depth

    for market, result in zip(fetchable, results, strict=True):
        if isinstance(result, httpx.HTTPStatusError):
            if result.response.status_code == 404:
                mark_market_closed(market.market_id, db)
                closed_by_event.setdefault(market.event_id, []).append(
                    market.market_id,
                )
                closed_count += 1
            else:
                err_count += 1
                key = str(result.response.status_code)
                err_by_type[key] = err_by_type.get(key, 0) + 1
            continue
        if isinstance(result, Exception):
            err_count += 1
            key = type(result).__name__
            if "timeout" in str(result).lower() or "Timeout" in type(result).__name__:
                key = "timeout"
            err_by_type[key] = err_by_type.get(key, 0) + 1
            continue
        if result.get("yes_price") is not None:
            price_ok += 1
        if result.get("bid_depth") and result.get("bid_depth") > 0:
            book_ok += 1
        update_market_prices(market.market_id, db=db, **result)

    # Write trades to markets.recent_trades
    trades_ok = 0
    with db.transaction() as conn:
        for market in fetchable:
            trades = trades_by_id.get(market.market_id)
            if trades:
                conn.execute(
                    "UPDATE markets SET recent_trades = ? WHERE market_id = ?",
                    (json.dumps(trades), market.market_id),
                )
                trades_ok += 1

    # Close events where all sub-markets are gone. Delegates to the shared
    # close_event routine: flip `events.closed=1` + log. `auto_monitor` is
    # preserved (user-intent flag) and the Archive view surfaces closed
    # monitored events directly from `events + event_monitors`.
    for event_id in closed_by_event:
        all_markets = get_event_markets(event_id, db)
        if not all(m.closed for m in all_markets):
            continue
        event = get_event(event_id, db)
        if event is None or event.closed == 1:
            continue  # already closed — don't re-log on every tick
        title = event.title or event_id
        close_event(event_id, title, db, trigger_source="poll")

    # --- Step 1.5: Auto-resolve newly closed markets the user holds -----
    # Only fires if init_poller supplied wallet/positions/resolver (test
    # paths that invoke global_poll(db=...) directly skip resolution).
    if closed_count > 0 and _ctx is not None:
        closed_market_ids = [
            mid for mids in closed_by_event.values() for mid in mids
        ]
        try:
            asyncio.run(
                _run_resolution_pass(
                    closed_market_ids, db,
                    _ctx.wallet, _ctx.positions, _ctx.resolver,
                )
            )
        except Exception:
            logger.exception("auto-resolution pass failed (will retry next tick)")

    # --- Step 2: Refresh scores ---
    refresh_ms = 0
    refresh_n = 0
    try:
        from polily.daemon.score_refresh import refresh_scores

        config = _ctx.config if _ctx else None
        t_refresh = _time.monotonic()
        result = refresh_scores(db, underlying_prices, config)
        refresh_ms = (_time.monotonic() - t_refresh) * 1000
        refresh_n = result.markets_refreshed
    except Exception:
        logger.exception("Score refresh failed")
        warn = True

    # --- Step 2.7: Honor context_requires_regen on monitored events ---
    # Polymarket sets event_metadata.context_requires_regen=true when their
    # auto-curated description has gone stale. Pre-v0.12.0 we never re-checked
    # the flag, so descriptions accumulated drift silently (caught on event
    # 206793 — Iran uranium — where the description missed 5/6-5/7 MOU news).
    # Module-level cooldown (5 min default) prevents API hammering when
    # Polymarket leaves the flag set during their async regen.
    regen_n = 0
    try:
        from polily.daemon.event_metadata_regen import (
            regen_stale_event_descriptions,
        )

        regen_config = _ctx.config if _ctx else None
        regen_n = asyncio.run(regen_stale_event_descriptions(db, regen_config))
        if regen_n > 0:
            logger.info("Regenerated event_metadata for %d events", regen_n)
    except Exception:
        logger.exception("event_metadata regen step failed")
        warn = True

    # Step 3.5 (dispatcher): drain overdue pending scan_logs rows to the ai executor.
    # Runs AFTER resolution (Step 1.5) and score refresh (Step 2) so analyses see
    # committed state, and BEFORE Step 3 intelligence layer so this-tick movement
    # signals aren't consumed by this-tick analyses (they land next tick).
    if _ctx and _ctx.scheduler:
        try:
            n = dispatch_pending_analyses(_ctx.db, _ctx.scheduler)
            if n > 0:
                logger.info("Dispatched %d pending analysis rows to ai executor", n)
        except Exception:
            logger.exception("Dispatcher step failed")

    # --- Step 3: Intelligence layer ---
    _run_intelligence_layer(db)

    # --- Log ---
    total = _time.monotonic() - t_start
    if total > 30:
        warn = True

    plog = _get_poll_log()
    ts = datetime.now().strftime("%H:%M:%S")

    # fetch line
    fetch_parts = [f"clob {len(fetchable)} markets {clob_elapsed:.1f}s"]
    if crypto_symbols:
        bin_status = f"binance/ticker {len(underlying_prices)}/{len(crypto_symbols)}"
        if len(underlying_prices) < len(crypto_symbols):
            bin_status += " failed"
        fetch_parts.append(bin_status)
    plog.info(f"  {ts} fetch   | {' | '.join(fetch_parts)}")

    # score line
    if refresh_n:
        plog.info(f"           score   | {refresh_n} markets rescored {refresh_ms:.0f}ms")

    # check line — data completeness
    n_total = len(fetchable)
    check_parts = [f"price: {price_ok}/{n_total}", f"book: {book_ok}/{n_total}", f"trades: {trades_ok}/{n_total}", f"score: {refresh_n}/{n_total}"]
    if underlying_prices:
        bin_parts = [f"{sym.replace('USDT','')} ${p:,.0f}" for sym, p in underlying_prices.items()]
        check_parts.append(f"binance: {' '.join(bin_parts)}")
    plog.info(f"           check   | {' | '.join(check_parts)}")

    # result line
    result_parts = []
    if closed_count:
        result_parts.append(f"{closed_count} closed")
    if err_count:
        result_parts.append(f"{err_count} errors")
    result_parts.append(f"total {total:.1f}s")
    if warn:
        result_parts.append("[!]")
    plog.info(f"           result  | {' | '.join(result_parts)}")

    # errors detail line (only when errors exist)
    if err_by_type:
        err_details = " | ".join(f"{k}: {v} markets" for k, v in sorted(err_by_type.items()))
        plog.info(f"           errors  | {err_details}")


def _run_intelligence_layer(db: PolilyDB) -> None:
    """Step 3: compute M/Q signals for every monitored event.

    Only runs for events with auto_monitor=1. Reads fresh prices from
    the markets table (just updated by Step 1), computes per-sub-market
    movement signals, and for negRisk events also writes event-level metrics.
    """
    from polily.core.config import MovementConfig
    from polily.core.event_store import get_event, get_event_markets
    from polily.core.monitor_store import get_active_monitors
    from polily.monitor.event_metrics import compute_event_metrics
    from polily.monitor.models import MovementSignals
    from polily.monitor.scorer import compute_movement_score
    from polily.monitor.signals import (
        compute_book_imbalance,
        compute_price_z_score,
        compute_trade_concentration,
        compute_volume_price_confirmation,
        compute_volume_ratio,
    )
    from polily.monitor.store import append_movement, get_event_movements

    monitored_event_ids = get_active_monitors(db)

    # Resolve MovementConfig: prefer _ctx.config, fall back to defaults
    mc: MovementConfig
    if _ctx is not None and _ctx.config is not None:
        mc = _ctx.config.movement
    else:
        mc = MovementConfig()

    for event_id in monitored_event_ids:
        try:
            event = get_event(event_id, db)
            if not event or event.closed:
                continue

            markets = get_event_markets(event_id, db)
            active_markets = [
                m for m in markets if not m.closed and m.clob_token_id_yes
            ]

            if not active_markets:
                continue

            # --- Per-sub-market signal computation ---
            min_history = mc.min_history_entries
            stale_seconds = mc.stale_threshold_seconds

            # Fetch once per event (not per market)
            recent = get_event_movements(event_id, db, hours=6)

            for m in active_markets:
                market_entries = [
                    e for e in recent if e.get("market_id") == m.market_id
                ]

                # Guard: check data sufficiency and freshness
                is_cold = len(market_entries) < min_history
                is_stale = False
                if market_entries:
                    latest_ts = market_entries[0].get("created_at", "")
                    try:
                        latest_dt = datetime.fromisoformat(latest_ts)
                        if latest_dt.tzinfo is None:
                            latest_dt = latest_dt.replace(tzinfo=UTC)
                        age = (datetime.now(UTC) - latest_dt).total_seconds()
                        is_stale = age > stale_seconds
                    except (ValueError, TypeError):
                        is_stale = True

                if is_cold or is_stale:
                    # Write noise entry — just record price, no signal computation
                    append_movement(
                        event_id=event_id, market_id=m.market_id,
                        yes_price=m.yes_price, no_price=m.no_price,
                        bid_depth=m.bid_depth or 0, ask_depth=m.ask_depth or 0,
                        spread=m.spread, magnitude=0, quality=0, label="noise",
                        db=db,
                    )
                    continue

                price_history = [
                    e["yes_price"]
                    for e in reversed(market_entries)
                    if e.get("yes_price") is not None
                ]

                # Signals from markets table data
                bid_depth = m.bid_depth or 0
                ask_depth = m.ask_depth or 0
                book_imbalance = compute_book_imbalance(bid_depth, ask_depth)
                price_z = compute_price_z_score(m.yes_price or 0, price_history)

                # Trade data from recent_trades JSON
                trade_sizes: list[float] = []
                if m.recent_trades:
                    try:
                        trades = json.loads(m.recent_trades)
                        trade_sizes = [
                            float(t.get("size", 0)) for t in trades
                        ]
                    except (json.JSONDecodeError, TypeError):
                        pass

                recent_volume = sum(trade_sizes)
                baseline_volume = (
                    sum(e.get("trade_volume", 0) for e in market_entries)
                    / max(len(market_entries), 1)
                )
                vol_ratio = compute_volume_ratio(recent_volume, baseline_volume)
                trade_conc = compute_trade_concentration(trade_sizes)

                prev_price = (
                    market_entries[0]["yes_price"] if market_entries else None
                )
                price_change_pct = 0.0
                if prev_price and prev_price > 0 and m.yes_price:
                    price_change_pct = (m.yes_price - prev_price) / prev_price
                vol_price_conf = compute_volume_price_confirmation(
                    price_change_pct, vol_ratio
                )

                signals = MovementSignals(
                    price_z_score=price_z,
                    volume_ratio=vol_ratio,
                    book_imbalance=book_imbalance,
                    trade_concentration=trade_conc,
                    volume_price_confirmation=vol_price_conf,
                )

                result = compute_movement_score(
                    signals, event.market_type or "other", mc
                )

                append_movement(
                    event_id=event_id,
                    market_id=m.market_id,
                    yes_price=m.yes_price,
                    no_price=m.no_price,
                    prev_yes_price=prev_price,
                    trade_volume=recent_volume,
                    bid_depth=bid_depth,
                    ask_depth=ask_depth,
                    spread=m.spread,
                    magnitude=result.magnitude,
                    quality=result.quality,
                    label=result.label,
                    db=db,
                )

            # --- Event-level trigger: check if AI analysis should fire ---
            _check_event_trigger(event_id, active_markets, mc, db)

            # --- Event-level metrics for negRisk events with 2+ sub-markets ---
            if event.neg_risk and len(active_markets) > 1:
                prices = {
                    m.market_id: (m.yes_price or 0) for m in active_markets
                }
                asks = {
                    m.market_id: m.best_ask
                    for m in active_markets
                    if m.best_ask
                }

                # Get previous event-level prices for TV distance / leader change
                prev_entries = get_event_movements(event_id, db, hours=1)
                prev_event_level = [
                    e for e in prev_entries if e["market_id"] is None
                ]
                prev_prices: dict[str, float] | None = None
                if prev_event_level:
                    try:
                        prev_snap = json.loads(prev_event_level[0]["snapshot"])
                        if "prices" in prev_snap:
                            prev_prices = prev_snap["prices"]
                    except (json.JSONDecodeError, TypeError):
                        pass

                metrics = compute_event_metrics(
                    prices, prev_prices=prev_prices, asks=asks
                )

                snapshot = {
                    "overround": metrics.overround,
                    "entropy": metrics.entropy,
                    "leader_id": metrics.leader_id,
                    "leader_margin": metrics.leader_margin,
                    "leader_changed": metrics.leader_changed,
                    "tv_distance": metrics.tv_distance,
                    "hhi": metrics.hhi,
                    "dutch_book_gap": metrics.dutch_book_gap,
                    "prices": prices,  # store for next comparison
                }

                append_movement(
                    event_id=event_id,
                    market_id=None,  # event-level
                    magnitude=0,
                    quality=0,
                    label="noise",
                    snapshot=json.dumps(snapshot),
                    db=db,
                )
        except Exception:
            logger.exception("Intelligence layer failed for event %s", event_id)
            continue

    # v0.11.6: append_movement (in monitor/store.py) self-commits via
    # db.transaction(). Per-row commits replace the prior "batch commit
    # at end" — under WAL, perf is equivalent, and a mid-loop failure
    # no longer rolls back earlier rows (the surrounding try/except
    # already isolates iteration failures).


def dispatch_pending_analyses(db: PolilyDB, scheduler) -> int:
    """Scan for overdue pending scan_logs rows and submit each to the ai executor.

    Atomically claims each row (pending→running) before dispatching so
    concurrent ticks can't double-fire. Returns count submitted.

    fetch_overdue_pending already filters to at-most-one earliest pending
    per event and excludes events with a running row (B4 + Q1 invariants).
    """
    from polily.scan_log import claim_pending_scan, fetch_overdue_pending

    overdue = fetch_overdue_pending(db)
    if not overdue:
        return 0

    submitted = 0
    for row in overdue:
        scan_id = row["scan_id"]
        if not claim_pending_scan(scan_id, db):
            continue  # another tick already claimed
        try:
            scheduler.add_job(
                _run_pending_analysis,
                id=f"pending_{scan_id}",
                executor="ai",
                replace_existing=True,
                kwargs={
                    "event_id": row["event_id"],
                    "scan_id": scan_id,
                    "db": db,
                    "trigger_source": row["trigger_source"],
                },
            )
            submitted += 1
        except Exception:
            # add_job raised after we already flipped status to 'running'.
            # Don't abort the loop — other overdue rows still get a shot.
            # Row stays in 'running' and will be swept by fail_orphan_running
            # on the next daemon restart.
            logger.exception(
                "scheduler.add_job failed for scan_id=%s; row left in running state",
                scan_id,
            )
    return submitted


def _run_pending_analysis(
    *, event_id: str, scan_id: str, db: PolilyDB, trigger_source: str,
) -> None:
    """Executor job function for a dispatched pending analysis.

    Pulls `config` from the shared `_ctx` (set by init_poller) so PolilyService
    can build its NarrativeWriter with the right `config.ai.narrative_writer`
    settings. Without config, PolilyService.__init__ would AttributeError on
    the first agent call.

    v0.11.4 (BUG-2.2): outer try block now wraps the FULL function body
    (including PolilyService construction), and the except handler explicitly
    finalizes the scan_logs row to status='failed'. Without this, any
    exception raised before reaching analyze_event's internal exception
    handler would leave the row stuck in 'running' indefinitely (only
    cleaned up by fail_orphan_running on next daemon restart). Real
    prod incident 2026-05-04 21:38: 2 rows stuck 12+ minutes because
    of sqlite3.InterfaceError raised in get_event() — caught here,
    logged, but not finalized.

    Belt-and-suspenders: nested try around finish_scan so its own failure
    doesn't crash the ai executor thread (would prevent OTHER analyses
    from running).

    v0.11.4 (BUG-4): full body runs inside `with db._lock:` to serialize
    DB access from concurrent ai executor threads. Two ai threads racing
    db.conn.execute() were observed producing sqlite3.InterfaceError
    (prod 2026-05-04 21:38, captured in daemon-stderr.log thanks to
    v0.11.2's stderr redirect). The lock is held for the analysis call;
    finish_scan in the except handler runs WITHOUT the lock (single SQL
    write that the engine-level WAL serializes), avoiding holding the
    lock across the failure-path I/O.
    """
    import asyncio

    from polily.scan_log import finish_scan
    from polily.tui import i18n
    from polily.tui.service import PolilyService

    try:
        # v0.11.6: prior `with db._lock:` wrap removed — Tasks 3-6 migrated
        # all DB access (including service.analyze_event's downstream calls)
        # to `db.transaction()` which acquires `db._lock` internally. The
        # outer wrap was redundant after the broad migration completed.
        cfg = _ctx.config if _ctx is not None else None
        # v0.11.7: align this daemon-process's i18n state with the user's
        # TUI language (`user_prefs.language`). The daemon never goes
        # through PolilyApp._init_i18n_from_prefs, so without this every
        # NarrativeWriter prompt would default to the en
        # `language.directive_for_llm`, making scheduled / monitor-triggered
        # analyses come back in English regardless of F2. Per-call sync
        # rather than init-once so a mid-flight F2 toggle takes effect on
        # the very next scheduled run.
        i18n.sync_from_user_pref(
            db, fallback=cfg.tui.language if cfg is not None else "en",
        )
        service = PolilyService(config=cfg, db=db)
        asyncio.run(
            service.analyze_event(
                event_id, trigger_source=trigger_source, scan_id=scan_id,
            ),
        )
    except Exception as e:
        logger.exception("Dispatched analysis failed for scan_id=%s", scan_id)
        try:
            finish_scan(
                scan_id,
                status="failed",
                error=f"dispatcher_exception: {type(e).__name__}: {e}"[:200],
                db=db,
            )
        except Exception:
            # Belt-and-suspenders: if finish_scan ALSO fails, log and move on.
            # The row will be cleaned up by fail_orphan_running on next
            # daemon restart. Never let this function raise — that would
            # crash the ai executor thread and prevent OTHER analyses
            # from running.
            logger.exception(
                "finish_scan ALSO failed for scan_id=%s — row left running, "
                "will be swept by fail_orphan_running on next daemon restart",
                scan_id,
            )


def _trigger_movement_analysis(
    *, event_id: str, event_title: str | None, reason: str, db: PolilyDB,
) -> None:
    """Write a pending scan_logs row so the next poll tick dispatches analysis.

    Q5 decision: movement-triggered analyses flow through the same DB queue as
    scheduled ones so everything appears in the 待办 zone of menu 0.
    """
    from polily.scan_log import insert_pending_scan

    now_iso = datetime.now(UTC).isoformat()
    insert_pending_scan(
        event_id=event_id,
        event_title=event_title,
        scheduled_at=now_iso,  # "now" = immediately eligible for next tick
        trigger_source="movement",
        scheduled_reason=reason,
        db=db,
    )


def _check_event_trigger(
    event_id: str,
    active_markets: list,
    mc,
    db: PolilyDB,
) -> None:
    """Check if event-level movement should trigger AI analysis.

    Aggregates max(M) and max(Q) across all sub-markets in the latest tick,
    then checks: should_trigger AND cooldown AND daily limit.
    If all pass, submits AI analysis to the ai executor.
    """
    from polily.monitor.models import MovementResult
    from polily.monitor.store import get_event_latest, get_today_analysis_count

    # Get latest movement entries for this event's markets
    latest = get_event_latest(event_id, db)
    if not latest:
        return

    # Aggregate: max M and Q across sub-markets in latest tick (within 60s)
    cutoff = (datetime.now(UTC) - timedelta(seconds=60)).isoformat()
    with db.transaction() as conn:
        recent = conn.execute(
            """SELECT magnitude, quality FROM movement_log
            WHERE event_id = ? AND market_id IS NOT NULL
            AND created_at >= ?
            ORDER BY created_at DESC""",
            (event_id, cutoff),
        ).fetchall()

    if not recent:
        return

    max_m = max(r["magnitude"] for r in recent)
    max_q = max(r["quality"] for r in recent)

    # Check trigger threshold
    agg = MovementResult(magnitude=max_m, quality=max_q)
    if not agg.should_trigger(
        m_threshold=mc.magnitude_threshold,
        q_threshold=mc.quality_threshold,
    ):
        return

    # Check cooldown: last triggered analysis for this event
    with db.transaction() as conn:
        last_triggered = conn.execute(
            """SELECT created_at FROM movement_log
            WHERE event_id = ? AND triggered_analysis = 1
            ORDER BY created_at DESC LIMIT 1""",
            (event_id,),
        ).fetchone()

    if last_triggered:
        try:
            last_dt = datetime.fromisoformat(last_triggered["created_at"])
            if last_dt.tzinfo is None:
                last_dt = last_dt.replace(tzinfo=UTC)
            age = (datetime.now(UTC) - last_dt).total_seconds()
            if age < agg.cooldown_seconds:
                logger.debug(
                    "Event %s trigger skipped: cooldown (%ds < %ds)",
                    event_id, int(age), agg.cooldown_seconds,
                )
                return
        except (ValueError, TypeError):
            pass

    # Check daily limit
    today_count = get_today_analysis_count(event_id, db)
    if today_count >= mc.daily_analysis_limit:
        logger.debug(
            "Event %s trigger skipped: daily limit (%d/%d)",
            event_id, today_count, mc.daily_analysis_limit,
        )
        return

    # --- Trigger AI analysis ---
    logger.info(
        "Movement trigger for event %s: M=%.0f Q=%.0f (%s)",
        event_id, max_m, max_q, agg.label,
    )

    # Mark triggered in movement_log (the actual spike row by magnitude,
    # not the temporally-latest row). When a tick writes multiple
    # sub-market rows microseconds apart, ordering by created_at would
    # land on whichever row was last inserted — often a noise row from
    # a sibling sub-market, NOT the spike row that drove the trigger.
    # Agent queries "which row triggered this?" would then find a
    # noise-labeled row marked triggered=1 — confusing provenance.
    # Ordering by magnitude DESC picks the row that actually drove the
    # max_m aggregation (most aligned with the trigger condition).
    # See test_movement_trigger.test_marks_spike_row_not_temporally_latest_row.
    with db.transaction() as conn:
        conn.execute(
            """UPDATE movement_log SET triggered_analysis = 1
            WHERE event_id = ? AND market_id IS NOT NULL
            AND id = (SELECT id FROM movement_log
                      WHERE event_id = ? AND market_id IS NOT NULL
                      AND created_at >= ?
                      ORDER BY magnitude DESC, created_at DESC LIMIT 1)""",
            (event_id, event_id, cutoff),
        )

    # Write pending scan_logs row; the next poll tick's dispatcher picks it up
    # (Q5: unified queue so movement analyses also show in menu 0's 待办 zone).
    event = get_event(event_id, db)
    _trigger_movement_analysis(
        event_id=event_id,
        event_title=event.title if event else None,
        reason=f"M={max_m:.0f} Q={max_q:.0f} ({agg.label})",
        db=db,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_monitored_markets(db: PolilyDB) -> list:
    """Get active markets only from monitored events."""
    with db.transaction() as conn:
        rows = conn.execute(
            """SELECT m.* FROM markets m
            JOIN event_monitors em ON m.event_id = em.event_id
            WHERE m.active = 1 AND m.closed = 0
            AND em.auto_monitor = 1
            ORDER BY m.market_id""",
        ).fetchall()
    from polily.core.event_store import MarketRow
    return [MarketRow.model_validate(dict(r)) for r in rows]


def _collect_crypto_symbols(db: PolilyDB) -> set[str]:
    """Collect unique Binance symbols needed for monitored crypto events.

    Returns e.g. {"BTCUSDT", "ETHUSDT"}.
    """
    with db.transaction() as conn:
        rows = conn.execute(
            """SELECT DISTINCT e.title FROM events e
            JOIN event_monitors em ON e.event_id = em.event_id
            WHERE e.market_type = 'crypto' AND e.closed = 0
            AND em.auto_monitor = 1""",
        ).fetchall()
    symbols = set()
    for row in rows:
        pair = extract_crypto_asset(row["title"])
        if pair:
            symbols.add(pair.replace("/", ""))  # BTC/USDT → BTCUSDT
    return symbols


# ---------------------------------------------------------------------------
# Async fetch
# ---------------------------------------------------------------------------


async def _fetch_all(
    markets: list, crypto_symbols: set[str] | None = None,
) -> tuple[list, dict[str, float], dict[str, list]]:
    """Fetch CLOB data + Binance tickers + trades concurrently.

    Returns (results, underlying_prices, trades_by_market_id).
    results: list parallel to markets (dict | Exception).
    underlying_prices: {"BTCUSDT": 71035.0, ...} — empty if no crypto.
    trades_by_market_id: {"m1": [{"price":..., "size":..., "side":...}, ...], ...}

    v0.11.4 OBS-1: split httpx timeouts (read=10s, was 15s) + tenacity
    retry inside _fetch_one (module-level) + per-tick circuit breaker.
    """
    async with httpx.AsyncClient(timeout=_HTTPX_TIMEOUT) as client:
        clob_tasks = [_fetch_one(client, m) for m in markets]

        binance_task = None
        if crypto_symbols:
            binance_task = asyncio.ensure_future(
                _fetch_binance_tickers(client, crypto_symbols),
            )

        trades_task = asyncio.ensure_future(
            _fetch_trades_batch(client, markets),
        )

        results = await asyncio.gather(*clob_tasks, return_exceptions=True)

        underlying: dict[str, float] = {}
        if binance_task is not None:
            try:
                underlying = await binance_task
            except Exception as e:
                logger.debug("Binance ticker fetch failed: %s", e)

        trades_by_id: dict[str, list] = {}
        try:
            trades_by_id = await trades_task
        except Exception as e:
            logger.debug("Trades batch fetch failed: %s", e)

        return results, underlying, trades_by_id


async def _fetch_binance_tickers(
    client: httpx.AsyncClient,
    symbols: set[str],
) -> dict[str, float]:
    """Fetch current prices from Binance for a set of symbols.

    Returns {"BTCUSDT": 71035.0, "ETHUSDT": 2198.0, ...}.
    """
    if not symbols:
        return {}
    # Binance requires compact JSON (no spaces): ["BTCUSDT","ETHUSDT"]
    symbols_json = json.dumps(sorted(symbols), separators=(",", ":"))
    resp = await client.get(
        "https://api.binance.com/api/v3/ticker/price",
        params={"symbols": symbols_json},
    )
    resp.raise_for_status()
    return {item["symbol"]: float(item["price"]) for item in resp.json()}


_TRADES_SEM_LIMIT = 5  # Data API is slower; limit concurrency
_DATA_API_BASE = "https://data-api.polymarket.com"


async def _fetch_trades_batch(
    client: httpx.AsyncClient,
    markets: list,
) -> dict[str, list]:
    """Fetch recent trades for all markets from Data API.

    Uses condition_id (not token_id). Concurrency limited to 5.
    Returns {market_id: [{"price":..., "size":..., "side":...}, ...]}.
    """
    sem = asyncio.Semaphore(_TRADES_SEM_LIMIT)
    result: dict[str, list] = {}

    async def _fetch_one(market):
        cid = market.condition_id
        if not cid:
            return
        async with sem:
            try:
                resp = await client.get(
                    f"{_DATA_API_BASE}/trades",
                    params={"market": cid, "limit": 20},
                )
                if resp.status_code != 200:
                    return
                data = resp.json()
                if isinstance(data, list):
                    raw = data
                elif isinstance(data, dict):
                    raw = data.get("data", [])
                else:
                    return
                result[market.market_id] = [
                    {
                        "price": float(t.get("price", 0)),
                        "size": float(t.get("size", 0)),
                        "side": t.get("side", ""),
                    }
                    for t in raw
                    if t.get("price") is not None
                ]
            except Exception as e:
                logger.debug("Trades fetch failed for %s: %s", market.market_id, e)

    await asyncio.gather(*[_fetch_one(m) for m in markets])
    return result
