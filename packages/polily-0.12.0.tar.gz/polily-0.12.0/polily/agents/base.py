"""BaseAgent: invoke claude CLI in headless mode with structured output."""

import asyncio
import contextlib
import json
import logging
import os
import re
import tempfile
from collections.abc import Callable

logger = logging.getLogger(__name__)

# Global registry of active subprocess PIDs for cleanup on exit
_active_pids: set[int] = set()


def _dump_debug(tag: str, content: str):
    """Write debug info to <log_dir>/agent_debug.log (append). Always writes, no log level.

    v0.11.0: log path resolves via polily.core.paths.agent_debug_log()
    instead of import-time os.getcwd() + 'data/logs'. The old behavior
    pinned the path to whatever cwd the polily process was launched
    from, which broke when the user installed via pipx and ran from
    arbitrary cwd.
    """
    try:
        from datetime import UTC, datetime

        from polily.core import paths

        ts = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S")
        path = paths.agent_debug_log()
        with open(path, "a") as f:
            f.write(f"\n=== {tag} [{ts}] ===\n{content}\n")
    except Exception:
        pass


def _extract_cli_error(stdout_text: str, stderr_text: str) -> str:
    """Build a human-readable error for a non-zero claude CLI exit.

    claude CLI emits API failures as JSON on stdout (`is_error=true` +
    `api_error_status` + `result`) while stderr stays empty, so we must peek
    into stdout before falling back to stderr.
    """
    envelope = None
    try:
        parsed = json.loads(stdout_text)
        if isinstance(parsed, list):
            for item in reversed(parsed):
                if isinstance(item, dict) and item.get("type") == "result":
                    envelope = item
                    break
        elif isinstance(parsed, dict):
            envelope = parsed
    except (json.JSONDecodeError, ValueError):
        envelope = None

    if envelope and envelope.get("is_error"):
        status = envelope.get("api_error_status")
        result = envelope.get("result") or ""
        if isinstance(result, dict):
            result = json.dumps(result)
        prefix = f"[API {status}] " if status else ""
        detail = str(result).strip()[:500]
        if detail:
            return f"{prefix}{detail}"
        if status:
            return prefix.strip()

    return stderr_text[:500]


def kill_all_agents():
    """Kill all active claude CLI subprocesses."""
    for pid in list(_active_pids):
        try:
            os.kill(pid, 9)  # SIGKILL
            logger.info("Killed agent subprocess %d", pid)
        except (ProcessLookupError, PermissionError):
            pass
    _active_pids.clear()


class BaseAgent:
    """Base class for AI agents that call claude CLI.

    Uses `claude -p` and parses JSON from the response text.

    Heartbeat monitoring: emits status callbacks during long-running calls.
    No system kill — user decides when to cancel via cancel().
    """

    def __init__(
        self,
        system_prompt: str,
        json_schema: dict | None,            # was: dict — now Optional for v0.12.0 markdown mode
        model: str = "opus",  # v0.12.0: bumped sonnet → opus to match AgentConfig.model default
        cli_command: str | None = None,
        *,
        max_prompt_chars: int,  # required keyword-only; sourced from AgentConfig.max_prompt_chars
        allowed_tools: list[str] | None = None,
        # Legacy compat — these are ignored now (no system kill)
        idle_timeout_seconds: float = 0,
        timeout_seconds: float | None = None,
    ):
        self.system_prompt = system_prompt
        self.json_schema = json_schema
        self.model = model
        # Resolution order:
        #   1. Explicit constructor arg (tests / future pinning use case).
        #   2. POLILY_CLAUDE_CLI env var — written into the launchd plist
        #      by `generate_launchd_plist` so the daemon can find the binary
        #      regardless of where nvm / homebrew / asdf installed it.
        #   3. Bare "claude" — relies on PATH; works when running under
        #      the user's shell but fails under launchd's stripped PATH.
        resolved = cli_command or os.environ.get("POLILY_CLAUDE_CLI") or "claude"
        # Dangling-path self-check: if env var points at a file that no
        # longer exists (user upgraded nvm and removed the old node
        # version), fall back to bare "claude" and tell the user how
        # to fix it. Without this, the first symptom would be a raw
        # FileNotFoundError that the user has to correlate back to the
        # plist on their own.
        #
        # os.path.exists follows symlinks — nvm's claude is a symlink
        # chain (bin/claude -> ../lib/node_modules/.../claude.exe), so
        # False here means the chain is genuinely broken, not just that
        # one hop in the chain looks unusual.
        if resolved != "claude" and not os.path.exists(resolved):
            logger.warning(
                "POLILY_CLAUDE_CLI=%s does not exist or is a broken symlink. "
                "Likely cause: nvm / homebrew removed the node version this "
                "path was resolved against. Diagnose with `ls -lL %s` or "
                "`polily doctor`. Falling back to bare 'claude' — run "
                "`polily scheduler restart` to regenerate the plist against "
                "the current install.",
                resolved, resolved,
            )
            resolved = "claude"
        self.cli_command = resolved
        self.max_prompt_chars = max_prompt_chars
        self.allowed_tools = allowed_tools
        self._current_proc: asyncio.subprocess.Process | None = None
        self._cancelled = False

    def cancel(self):
        """Cancel the currently running CLI call. Safe to call from any thread."""
        self._cancelled = True
        proc = self._current_proc
        if proc and proc.returncode is None:
            try:
                proc.kill()
                logger.info("Cancelled agent subprocess %d", proc.pid)
            except (ProcessLookupError, PermissionError):
                pass

    async def invoke(
        self, prompt: str, max_retries: int = 2,
        on_heartbeat: Callable[[float, str], None] | None = None,
    ) -> dict | str:
        """Call claude CLI and return parsed result.

        - If self.json_schema is set: return parsed JSON dict (existing behavior).
        - If self.json_schema is None: return the raw markdown / text string from
          the CLI's `result` field (v0.12.0 free-form output mode).

        on_heartbeat(elapsed_seconds, status): called every ~5s during execution.
          status: "running" (<60s), "slow" (60-120s), "unresponsive" (>120s)
        """
        self._cancelled = False
        tmp_path = None
        try:
            if len(prompt) > self.max_prompt_chars:
                tmp_path = self._write_temp(prompt)
                actual_prompt = f"Analyze the data in file: {tmp_path}"
            else:
                actual_prompt = prompt

            last_error = None
            for attempt in range(1, max_retries + 1):
                try:
                    result = await self._call_cli(actual_prompt, on_heartbeat)
                    return result
                except Exception as e:
                    if self._cancelled:
                        raise RuntimeError("Agent cancelled by user") from e
                    last_error = e
                    if attempt < max_retries:
                        wait = attempt * 3
                        logger.warning("Agent attempt %d/%d failed: %s. Retrying in %ds...", attempt, max_retries, e, wait)
                        await asyncio.sleep(wait)
                    else:
                        logger.warning("Agent failed after %d attempts: %s", max_retries, e)

            raise last_error
        finally:
            if tmp_path:
                with contextlib.suppress(OSError):
                    os.unlink(tmp_path)

    async def invoke_batch(
        self, prompts: list[str], max_concurrent: int = 3
    ) -> list[dict | str]:
        """Run multiple prompts in parallel with concurrency limit."""
        sem = asyncio.Semaphore(max_concurrent)

        async def bounded(p: str) -> dict | str:
            async with sem:
                return await self.invoke(p)

        return await asyncio.gather(*[bounded(p) for p in prompts])

    def _build_cli_args(self, actual_prompt: str) -> list[str]:
        """Build the argv list passed to claude CLI.

        Extracted so unit tests can verify --json-schema is conditionally
        included AND so the initial + retry call paths in _call_cli stay in
        sync (was previously duplicated inline in two branches).

        Two execution modes are still distinguished:
          - tool mode (allowed_tools set): system prompt prepended to user
            prompt so the agent can read files / shell out / web search.
          - legacy mode (no tools): uses --bare + --system-prompt flags.

        --json-schema is appended only when self.json_schema is not None;
        when None, we run in v0.12.0 markdown / free-form mode and let the
        agent emit raw text into the `result` field.
        """
        if self.allowed_tools:
            # Tool mode: agent has Read/Bash/WebSearch etc.
            # No --bare (agent needs file access), no --system-prompt (in user prompt).
            full_prompt = f"{self.system_prompt}\n\n{actual_prompt}"
            args = [
                self.cli_command, "-p", full_prompt,
                "--output-format", "json",
                "--allowedTools", ",".join(self.allowed_tools),
            ]
            if self.json_schema is not None:
                args.extend(["--json-schema", json.dumps(self.json_schema)])
            args.extend(["--model", self.model])
        else:
            # Legacy mode: no tools, uses --bare
            args = [
                self.cli_command, "-p", actual_prompt,
                "--output-format", "json",
                "--bare",
            ]
            if self.json_schema is not None:
                args.extend(["--json-schema", json.dumps(self.json_schema)])
            args.extend([
                "--system-prompt", self.system_prompt,
                "--model", self.model,
            ])
        return args

    async def _call_cli(
        self, prompt: str,
        on_heartbeat: Callable[[float, str], None] | None = None,
    ) -> dict | str:
        """Execute claude CLI with heartbeat monitoring.

        No system kill — runs until process completes or cancel() is called.
        Emits heartbeat status via on_heartbeat callback every ~5 seconds.
        """
        import time

        args = self._build_cli_args(actual_prompt=prompt)

        # v0.11.0: inject POLILY_DB into the subprocess env so the agent
        # prompt's `sqlite3 "$POLILY_DB" ...` resolves to the path layer's
        # absolute db_path() — independent of cwd, daemon WorkingDirectory,
        # or install method (pipx / venv / dev checkout).
        #
        # MUST be os.environ.copy() (not a fresh dict) so the subprocess
        # inherits HOME (claude config lookup), PATH (binary resolution),
        # and POLILY_CLAUDE_CLI (when set by the launchd plist for daemon
        # mode). Without inheritance, claude fails with "not logged in"
        # or fails to locate sub-binaries.
        from polily.core import paths as _paths
        subproc_env = os.environ.copy()
        subproc_env["POLILY_DB"] = str(_paths.db_path())

        proc = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=subproc_env,
        )
        self._current_proc = proc
        _active_pids.add(proc.pid)

        try:
            comm_task = asyncio.ensure_future(proc.communicate())
            start = time.monotonic()
            while not comm_task.done():
                await asyncio.sleep(5.0)
                elapsed = time.monotonic() - start
                # Emit heartbeat status
                if on_heartbeat:
                    if elapsed > 600:
                        on_heartbeat(elapsed, "unresponsive")
                    elif elapsed > 300:
                        on_heartbeat(elapsed, "long")
                    elif elapsed > 120:
                        on_heartbeat(elapsed, "searching")
                    else:
                        on_heartbeat(elapsed, "running")
                logger.debug("Agent still running (%.0fs)...", elapsed)

            stdout, stderr = comm_task.result()
        finally:
            self._current_proc = None
            _active_pids.discard(proc.pid)
            if proc.returncode is None:
                proc.kill()
                await proc.wait()

        if proc.returncode != 0:
            stdout_text = stdout.decode()
            stderr_text = stderr.decode()
            err_text = _extract_cli_error(stdout_text, stderr_text)
            _dump_debug(
                "cli_error",
                f"exit={proc.returncode}\n{stderr_text[:500]}\n---stdout---\n{stdout_text[:2000]}",
            )
            raise RuntimeError(f"claude CLI exited with code {proc.returncode}: {err_text}")

        raw_output = stdout.decode()
        _dump_debug("cli_stdout", raw_output)
        try:
            return self._parse_response(raw_output)
        except Exception as e:
            _dump_debug("parse_error", f"{e}\n---\n{raw_output}")
            raise

    def _parse_response(self, raw_output: str) -> dict | str:
        """Parse claude CLI output. Handles multiple response formats.

        Claude Code CLI v2.1+ with --output-format json returns a JSON array:
          [{"type":"system","subtype":"init",...}, {"type":"assistant",...}, {"type":"result",...}]
        Older versions returned a single JSON object:
          {"type":"result","result":"..."}

        Return type depends on self.json_schema:
          - schema set: return parsed JSON dict (existing behavior).
          - schema is None (v0.12.0 markdown mode): return the raw `result`
            string from the envelope, no JSON extraction.
        """
        # Try 1: Parse as JSON (array or object)
        try:
            parsed = json.loads(raw_output)

            # New format (CLI v2.1+): JSON array with multiple objects
            if isinstance(parsed, list):
                envelope = None
                for item in reversed(parsed):  # result is typically the last element
                    if isinstance(item, dict) and item.get("type") == "result":
                        envelope = item
                        break
                if envelope is None:
                    raise RuntimeError(
                        f"No result object found in claude CLI array response ({len(parsed)} items)"
                    )
            elif isinstance(parsed, dict):
                # Legacy single-object format
                envelope = parsed
            else:
                raise RuntimeError(f"Unexpected JSON type from claude CLI: {type(parsed).__name__}")

            # Markdown mode (v0.12.0): no schema → caller wants raw text.
            # The CLI's `result` field is a string; pass it through verbatim.
            # Skip structured_output here even if the CLI tucked one in —
            # the agent was asked for free-form text, return free-form text.
            if self.json_schema is None:
                result_text = envelope.get("result", "")
                if isinstance(result_text, str):
                    return result_text
                # Defensive: CLI sometimes returns dict on result; stringify so
                # caller still gets a str as advertised by the type contract.
                return json.dumps(result_text)

            # Extract structured output or result text from envelope
            if "structured_output" in envelope and envelope["structured_output"]:
                return envelope["structured_output"]
            result_text = envelope.get("result", "")
            if isinstance(result_text, dict):
                return result_text
            if isinstance(result_text, str):
                return self._extract_json_from_text(result_text)
        except json.JSONDecodeError:
            pass

        # Markdown mode fallback: if the CLI emitted plain text (no JSON envelope
        # at all — shouldn't happen with --output-format json but be defensive),
        # return raw output verbatim instead of trying to extract JSON.
        if self.json_schema is None:
            return raw_output

        # Try 2: Extract JSON from raw text (might have markdown fences)
        return self._extract_json_from_text(raw_output)

    def _extract_json_from_text(self, text: str) -> dict:
        """Extract JSON object from text that may contain markdown fences or other text."""
        # Try to find JSON in code blocks
        json_match = re.search(r'```(?:json)?\s*\n?([\s\S]*?)\n?```', text)
        if json_match:
            try:
                return json.loads(json_match.group(1))
            except json.JSONDecodeError:
                pass

        # Try to find raw JSON object
        brace_match = re.search(r'\{[\s\S]*\}', text)
        if brace_match:
            try:
                return json.loads(brace_match.group(0))
            except json.JSONDecodeError:
                pass

        raise RuntimeError(f"No JSON found in claude CLI response: {text[:200]}")

    def _write_temp(self, content: str) -> str:
        """Write content to a temp file and return its path."""
        fd, path = tempfile.mkstemp(suffix=".txt", prefix="polily_agent_")
        with os.fdopen(fd, "w") as f:
            f.write(content)
        return path
