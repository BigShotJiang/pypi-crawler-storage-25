"""Abstract base handler and shared utilities for format I/O."""

from __future__ import annotations

import os
import sys
import uuid
from abc import ABC, abstractmethod
from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from ...exceptions import IncorporatorFormatError
from ..formats import FormatType

# Mapping from optional-import module name to the install-extra users need.
# Every entry is a single source of truth — when a new optional dep ships,
# add one row here and every handler that needs it is covered automatically.
_OPTIONAL_INSTALL_EXTRAS: dict[str, str] = {
    "orjson": "speedups",
    "lxml": "speedups",
    "lxml.etree": "speedups",
    "lxml.html": "speedups",
    "pyarrow": "parquet",
    "pyarrow.parquet": "parquet",
    "pyarrow.feather": "parquet",
    "pyarrow.orc": "parquet",
    "pyarrow.ipc": "parquet",
    "fastavro": "avro",
    "openpyxl": "xlsx",
    "bs4": "speedups",
}


def _require_optional(module_name: str, install_extra: str | None = None) -> Any:
    """Lazy-import an optional dep, raising a uniform install-message on miss.

    Centralises the ~20 ``try: import X; except ImportError: raise
    IncorporatorFormatError("X not installed. Run: pip install ...")``
    blocks so the install-extra → message mapping lives in one dict
    (``_OPTIONAL_INSTALL_EXTRAS``).  Handlers shrink to one-liner
    imports — ``pa = _require_optional("pyarrow")``.
    """
    # Call ``__import__`` directly (not ``importlib.import_module``) so test
    # fixtures that monkeypatch ``builtins.__import__`` reach this code path
    # whether or not the module is already cached in ``sys.modules``.
    # ``importlib.import_module`` short-circuits on cache hits and would
    # therefore silently bypass the patch.
    try:
        __import__(module_name)
    except ImportError as exc:
        extra = install_extra or _OPTIONAL_INSTALL_EXTRAS.get(module_name, module_name)
        raise IncorporatorFormatError(f"{module_name} not installed. Run: pip install incorporator[{extra}]") from exc
    # ``__import__("foo.bar")`` returns ``foo``, not ``foo.bar``.  Reach into
    # ``sys.modules`` for the actual submodule the caller asked for.
    return sys.modules[module_name]


@contextmanager
def atomic_write_path(target: str | Path) -> Iterator[Path]:
    """Yield a sibling tempfile path; rename atomically on success.

    Use for monolithic formats that write a single bulk file (Parquet,
    Excel, JSON, XML).  If the write completes successfully, the
    tempfile is renamed to ``target`` via ``os.replace()`` — an atomic
    operation on POSIX and Windows.  If the write raises, the tempfile
    is removed so we don't leave a half-written corrupt file behind.

    Pre-existing ``target`` files are left untouched until the rename
    succeeds, so an interrupted write never destroys the prior version.

    Streaming formats (NDJSON, CSV, SQLite, Avro) don't need this —
    their writes append line-by-line and partial output is recoverable.
    """
    target_path = Path(target).resolve()
    # Sibling tempfile in the same directory so os.replace stays atomic
    # (cross-device renames are not atomic on POSIX).
    tmp_path = target_path.with_name(f"{target_path.name}.tmp-{uuid.uuid4().hex[:8]}")
    try:
        yield tmp_path
    except BaseException:
        # Clean up the tempfile on any failure (including KeyboardInterrupt).
        try:
            if tmp_path.exists():
                tmp_path.unlink()
        except OSError:
            pass
        raise
    else:
        # Successful write — rename atomically.  os.replace overwrites the
        # destination on both POSIX and Windows (≥Vista), so we don't need
        # to special-case "destination exists".
        os.replace(tmp_path, target_path)


# Backward-compat module-level set + helper — preferred surface is
# :attr:`FormatType.is_append_safe`, the property co-located with the
# enum.  Both views share the same membership set so existing callers
# don't break.
APPEND_FRIENDLY_FORMATS: set[FormatType] = {
    FormatType.NDJSON,
    FormatType.CSV,
    FormatType.TSV,
    FormatType.PSV,
    FormatType.SQLITE,
    FormatType.AVRO,
}


def supports_append(format_type: FormatType) -> bool:
    """Return True when the format's write handler supports ``if_exists="append"``.

    Backward-compat wrapper over :attr:`FormatType.is_append_safe`.  Prefer
    the property on new code.
    """
    return format_type.is_append_safe


# Spreadsheet-aware CSV/XLSX formula-injection prefixes.  When a string cell
# value starts with any of these, Excel / LibreOffice Calc / Google Sheets
# interpret the cell as a formula and execute it on open.  Industry-standard
# mitigation (per OWASP "Formula Injection") is to prefix the cell with a
# single-quote so the spreadsheet renders the raw text instead of evaluating.
_FORMULA_INJECTION_PREFIXES: tuple[str, ...] = ("=", "@", "+", "-", "\t", "\r")


def _neutralise_formula_injection(value: Any) -> Any:
    """Single-quote-prefix any string starting with a formula-evaluating char.

    Non-string values pass through unchanged.  Empty strings pass through.
    The prefix `'` is the canonical mitigation — Excel renders the literal
    text and never evaluates.  Reversed automatically on re-import by every
    spreadsheet tool.
    """
    if not isinstance(value, str) or not value:
        return value
    if value.startswith(_FORMULA_INJECTION_PREFIXES):
        return "'" + value
    return value


def _raise_if_append_unsupported(kwargs: dict[str, Any], format_name: str) -> None:
    if kwargs.get("if_exists") == "append":
        raise IncorporatorFormatError(
            f"Monolithic formats ({format_name}) do not support O(1) streaming appends. "
            "Please stream to NDJSON, CSV, SQLite, or Avro instead."
        )


class BaseFormatHandler(ABC):
    """Abstract Strategy for parsing and writing different data formats."""

    @abstractmethod
    def parse(self, source: str | bytes | Path, **kwargs: Any) -> dict[str, Any] | list[dict[str, Any]]:
        """Parse a byte buffer, string, or Path into a dict or list of dicts.

        Each subclass implements its own format-specific parsing (JSON, XML,
        CSV, Parquet, etc.). Failures must raise :class:`IncorporatorFormatError`
        so the central dispatch can surface a uniform error shape.
        """
        pass

    @abstractmethod
    def write(self, data: Iterable[dict[str, Any]], file_path: str | Path, **kwargs: Any) -> None:
        """Stream rows from an iterable to a file in the subclass's format.

        Subclasses honour standard kwargs where applicable: ``if_exists``
        (``"replace"`` / ``"append"`` / ``"fail"``), ``all_field_names``
        (column order hint), and format-specific tuning kwargs. Failures
        must raise :class:`IncorporatorFormatError`.
        """
        pass
