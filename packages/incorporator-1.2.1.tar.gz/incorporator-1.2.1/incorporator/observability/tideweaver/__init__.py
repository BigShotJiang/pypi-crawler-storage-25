"""Tideweaver: lightweight orchestration over ``stream()`` / fjord-flush / ``export()``.

A :class:`Watershed` declares the plan — a time window plus a graph of named
:class:`Current` nodes connected by edges.  :class:`Tideweaver` runs the plan:
each current ticks on its own interval; each inbound edge's
:class:`FlowControl` decides whether the dependent fires this pass.  One
:class:`Tide` log record is emitted per scheduler pass.

The vocabulary is deliberately small:

* :class:`Tideweaver` — the orchestrator.
* :class:`Watershed` — the plan (window + currents + edges).
* :class:`Current` (and the verb-typed subclasses :class:`Stream`,
  :class:`Fjord`, :class:`Export`) — one node in the graph.
* :class:`Tide` — one scheduler pass; emitted as a log record.
* :class:`~incorporator.Wave` — already exists; one emit from a stream call
  or a fjord flush.  Unmodified by this module.
* :class:`FlowControl` — the per-edge composition of gate + surge_barrier
  + penstock + reservoir + spillway.  Mirrors real canal/dam engineering:
  :class:`HardLock` / :class:`SoftPass` / :class:`Weir` decide pass/hold;
  :class:`SurgeBarrier` overrides under extreme upstream-in-flight load;
  :class:`Penstock` rate-limits flow across the edge; :class:`Reservoir`
  buffers N recent waves; :class:`Spillway` handles overflow.

A "fjord flush" is the scheduling primitive of a :class:`Fjord` current:
snapshot the upstream currents' registries, run the user-supplied
``outflow(state)`` function, build the dynamic output class, export.  It is
NOT a call to ``cls.fjord()`` (which is a long-running daemon ill-suited to
per-interval ticking).  Stream source ingestion is owned by the upstream
:class:`Stream` currents in the graph.
"""

from __future__ import annotations

from .architect import TuningHint, TuningReport, tune
from .current import Current, CustomCurrent, Export, Fjord, Stream
from .flow import (
    BackpressurePenstock,
    BurstPenstock,
    DropOldest,
    ExportToArchive,
    FlowControl,
    FlowObserver,
    Gate,
    GateMode,
    HardLock,
    LoggingObserver,
    NullObserver,
    Penstock,
    RaiseOverflow,
    Reservoir,
    SignalObserver,
    SignalPenstock,
    SoftPass,
    Spillway,
    SurgeAction,
    SurgeBarrier,
    SustainedPenstock,
    Weir,
    WindowPenstock,
    flow_from_mode,
)
from .logged import LoggedTideweaver
from .scheduler import TickFactory, Tideweaver
from .tide import Tide
from .watershed import Edge, Watershed

__all__ = [
    "BackpressurePenstock",
    "BurstPenstock",
    "Current",
    "CustomCurrent",
    "DropOldest",
    "Edge",
    "Export",
    "ExportToArchive",
    "Fjord",
    "FlowControl",
    "FlowObserver",
    "Gate",
    "GateMode",
    "HardLock",
    "LoggedTideweaver",
    "LoggingObserver",
    "NullObserver",
    "Penstock",
    "RaiseOverflow",
    "Reservoir",
    "SignalObserver",
    "SignalPenstock",
    "SoftPass",
    "Spillway",
    "Stream",
    "SurgeAction",
    "SurgeBarrier",
    "SustainedPenstock",
    "TickFactory",
    "Tide",
    "Tideweaver",
    "TuningHint",
    "TuningReport",
    "Watershed",
    "Weir",
    "WindowPenstock",
    "flow_from_mode",
    "tune",
]
