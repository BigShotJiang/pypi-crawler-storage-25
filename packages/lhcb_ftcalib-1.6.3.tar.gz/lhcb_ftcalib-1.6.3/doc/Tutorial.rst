Getting Started
===============
lhcb-ftcalib is a package that faciliates the calibration of mistag probabilities
given some raw tagging probabilities and tagging decisions and a calibration dataset.
A mistag probability (or mistag for short)
is the probability that a tagging decision is wrong. In calibration datasets containing neutral
B or Bs mesons, oscillation is taken into account.

Installation
------------

``lhcb-ftcalib`` is available in the python package index (PyPI) and also provides a command
line tool called ``ftcalib``. The command line tool is by design not feature complete,
the API should be used for non-`standard` calibrations.
``lhcb-ftcalib`` can be installed via

.. code-block::

    pip install lhcb-ftcalib

**If**, for some reason, the package could not installed from the PyPI, a manual installation is possible:

.. code-block::

   git clone https://gitlab.cern.ch/lhcb-ft/lhcb_ftcalib.git
   cd lhcb-ftcalib
   pip install -e .

The package requirements are listed in ``requirements.txt``. If, for some reason, a manual installation
of the requirements should fail, a full environment can be installed through ``pipenv``:

.. code-block::

   git clone https://gitlab.cern.ch/lhcb-ft/lhcb_ftcalib.git
   cd lhcb-ftcalib
   pipenv install -e .

Which should install fixed versions from the ``Pipefile.lock`` file.

Quickstart
----------
There are two main ways to use ``lhcb-ftcalib``: through the command line interface (CLI) or through the python API.

* As a python package (``import lhcb_ftcalib as ft``):
    * This approach offers the greatest flexibility.
    * In addition, lhcb_ftcalib is designed to be extendable and configurable.
    * For a physics analysis workflow, this is the recommended way to use the package.
* CLI (``ftcalib`` in the terminal): 
    * The CLI is the easiest way to get reliable tagging performance numbers without writing any code. 
    * It is designed to be user-friendly and is NOT meant to be a feature-complete replacement of the full package as such.

The following sections will give a quickstart guide for both approaches. It is recommended to be familiar with both.

CLI Quickstart: Calibrating a Tagger
------------------------------------

Calibrating a tagger is as easy as typing

.. code-block::

   ftcalib data.root:DecayTree -t OSElec OSMuon -op calibrate -mode Bu -id Bu_ID

This will read the file ``data.root``, search for the TTree ``"DecayTree"``,
search for a branch called ``<something>OSElec<something>ETA`` or ``DEC``, (and the same 
with "OSMuon") and
a branch called ``Bu_ID`` (usually) for the decay flavour of the B mesons,
compute tagging performance numbers, run the calibration and output the
calibration result and calibrated performance numbers to the screen. If the
arguments are somehow illogical, ftcalib should tell you what the problem is as
it checks for common user-errors. A full list of command line arguments with examples can be
found in section :ref:`CLI` of the documentation.

Interpretation of CLI-output
............................
The ``ftcalib`` run outputs a lot of information to the terminal. This output
should be mostly self-explanatory. The following info is printed:

    * A list of identified tagger branches
    * Various kinds of tagger correlations (see :obj:`TaggerCollection.correlation <lhcb_ftcalib.TaggerCollection.correlation>` for the mathematical definitions)
    * A **"RAW TAGGER STATISTICS"** table containing

      * Contains the number of events in the branches (:obj:`TaggingData.N <lhcb_ftcalib.TaggingData.N>`)
      * The sum of event weights (:obj:`TaggingData.Nws <lhcb_ftcalib.TaggingData.Nws>`)
      * The effective number of events (:obj:`TaggingData.Neffs <lhcb_ftcalib.TaggingData.Neffs>`)
      * The number of tagged events (:obj:`TaggingData.Nts <lhcb_ftcalib.TaggingData.Nts>`)
      * The sum of event weights of tagged events (:obj:`TaggingData.Nwts <lhcb_ftcalib.TaggingData.Nwts>`)
     
    * A **"RAW TAGGING PERFORMANCES"** table containing flavour tagging performance numbers before the calibration

      * Tagging Efficiency (:obj:`TaggingData.tagging_efficiency <lhcb_ftcalib.TaggingData.tagging_efficiency>`)
      * Average Mistag Rate (:obj:`TaggingData.mistag_rate <lhcb_ftcalib.TaggingData.mistag_rate>`)
      * Effective Mistag (:obj:`TaggingData.effective_mistag <lhcb_ftcalib.TaggingData.effective_mistag>`)
      * Tagging Power (:obj:`TaggingData.tagging_power <lhcb_ftcalib.TaggingData.tagging_power>`)

    * A basis representation of the calibration function (In this case it is the default: First degree polynomial, identity (mistag) link
    * iminuit minimization output
    * A **"FINAL CALIBRATION PARAMETERS"** containing the calibration parameters of the chosen model
    * A **"CALIBRATED TAGGER STATISTICS"** table containing the updated event statistics. The numbers in this table can differ from the raw numbers if :math:`\omega>0.5`
    * A **"CALIBRATED PERFORMANCES TABLE"** contains the performance numbers od the calibrated tagging data
    * Finally, warnings are printed in case of mistag over -or underflow or any other kind of problem. 
    * In the end, this is followed by a warning summary.

Python API Quickstart: Calibrating a Tagger
-------------------------------------------
An equivalent way of calibrating taggers is shown here in script form.

.. code-block:: python

    import uproot
    import lhcb_ftcalib as ft

    # Load the data with whatever library you seem fit
    df = uproot.open("data.root")["DecayTree"].arrays(library="pd")

    OSmu = ft.Tagger("OSmu", df.OSMuon_ETA, df.OSMuon_DEC, df.Bu_ID, mode = "Bu")

    OSmu.calibrate()

    print("Raw tagging power:", OSmu.stats.tagging_power(calibrated=False))
    print("Calibrated tagging power:", OSmu.stats.tagging_power(calibrated=True))

``Tagger.stats`` is a :obj:`TaggingData` object containing all the relevant statistics and performance calculators.
By design, the API is more flexible than the CLI, and the script example 
will produce much less output when used like this. It is however possible to recreate the full CLI output by simply using 
a TaggerCollection object:

.. code-block:: python

    import uproot
    import lhcb_ftcalib as ft

    df = uproot.open("data.root")["DecayTree"].arrays(library="pd")

    tc = ft.TaggerCollection()
    tc.create_tagger("OSmu", df.OSMuon_ETA, df.OSMuon_DEC, df.Bu_ID, mode = "Bu")
    tc.create_tagger("OSe", df.OSElectron_ETA, df.OSElectron_DEC, df.Bu_ID, mode = "Bu")

    tc.calibrate(corr   = True, # Correlation tables
                 stats  = True, # Tagging statistics
                 perf   = True, # Performance tables (tagging power)
                 params = True, # Final calibration parameters
                 basis  = True) # Print the calibration function symbolically in the optimized basis

The output will be the exact same as with the CLI. Since multiple taggers are calibrated 
at once, the output will be organized in tables and tagger correlations will be printed by default.
Each of these outputs can be set to ``False`` which reduces the computational overhead needed.

Plotting calibration results and saving the calibration in a json file is achieved by simply appending 

.. code-block:: python

   # Make standard plots using matplotlib
   tc.plot_calibration_curves()
   # Save the calibration in a json file containing all relevant information about tagger,
   # its performance pre and post calibration, the parameters and covariance matrix etc.
   ft.save_calibration(tc, "my_calibration.json")

The created json file can be loaded again to apply its calibrations so some other Taggers.
