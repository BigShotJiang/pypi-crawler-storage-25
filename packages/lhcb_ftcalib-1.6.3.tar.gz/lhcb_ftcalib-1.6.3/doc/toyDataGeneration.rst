Use of Flavour Tagging in Time-Dependent CP Violation Analyses
==============================================================
This chapter will explore the use of flavour tagging in time-dependent CP
violation analyses, by introducing two exemplary, and well understood decay
modes. At the same time it will give insight into how the toy data generator of
ftcalib works, as it is used to generate the synthetic data for the examples
shown in this chapter.

Primarily, the toy data generator of ftcalib is used to generate synthetic data
for testing and for validation of ftcalib itself. However, more generally, it
can be used to test an analysis workflow for a measurement of CP violation. It
offers the possibility to explore analysis ideas and physics hypotheses. The
generated data described here does however not depend on the actual decay
kinematics and is in this respect not a perfect replacement for full MC. Still,
in respect to the implementation of a flavour tagging calibration workflow and
a CP-violation fitter model, it offers a nice sandbox for experimentation.

The toy generator is first configured with several physics parameters. Then,
zero or more ficticious tagging algorithms can be configured to generate mistag
distributions according to provided arbitrary sampling distributions and a
calibration function is chosen to generate matching tagging decisions. The
tagging decisions are generated such that by calibrating the tagger, one can
recover the input calibration parameters.

It should be noted, that since lhcb_ftcalib is a tool meant primarily for use
at a hadron collider like LHCb, the following equations will be formulated in
forward time, only.

Sampling the decay time distributions
-------------------------------------

The decay time distributions of neutral mesons are given by the following expressions:

.. math::
   \frac{P(t|B,f=+1)}{(1-\alpha)(1+\beta)}            &\propto \epsilon(t)e^{-\Gamma t} \left[\cosh\left(\frac{1}{2}\Delta\Gamma t\right) - S \sin(\Delta m t) + C \cos(\Delta m t) + A \sinh\left(\frac{1}{2}\Delta\Gamma t\right) \right]|A_f|^2(1+|\lambda_f|^2)\\
   \frac{P(t|\overline{B},f=+1)}{(1+\alpha)(1+\beta)} &\propto \epsilon(t)e^{-\Gamma t} \left[\cosh\left(\frac{1}{2}\Delta\Gamma t\right) + S \sin(\Delta m t) - C \cos(\Delta m t) + A \sinh\left(\frac{1}{2}\Delta\Gamma t\right) \right]|A_f|^2(1+|\lambda_f|^2)|p/q|^2\\
   \frac{P(t|B,f=-1)}{(1-\alpha)(1-\beta)}            &\propto \epsilon(t)e^{-\Gamma t} \left[\cosh\left(\frac{1}{2}\Delta\Gamma t\right) - \overline{S} \sin(\Delta m t) + \overline{C} \cos(\Delta m t) + \overline{A} \sinh\left(\frac{1}{2}\Delta\Gamma t\right) \right]|A_{\bar{f}}|^2(1+|\lambda_{\bar{f}}|^2)|q/p|^2\\
   \frac{P(t|\overline{B},f=-1)}{(1+\alpha)(1-\beta)} &\propto \epsilon(t)e^{-\Gamma t} \left[\cosh\left(\frac{1}{2}\Delta\Gamma t\right) + \overline{S} \sin(\Delta m t) - \overline{C} \cos(\Delta m t) + \overline{A} \sinh\left(\frac{1}{2}\Delta\Gamma t\right) \right]|A_{\bar{f}}|^2(1+|\lambda_{\bar{f}}|^2)

where :math:`P(t|\overline{B},f=-1)` denotes a decay of an initial
anti-:math:`B` meson into a final state with CP eigenvalue :math:`f=-1` and
:math:`\epsilon(t)` is a common time dependent acceptance function,
representing the reconstruction probability of a detector. Furthermore,
:math:`\alpha` is the production asymmetry and :math:`\beta` is a possible
detection asymmetry. We thus have to sample our synthetic decay time data from
these functions numerically.

The difficult question is now how to normalize these functions, i.e. how many
events to sample from each distribution. If we naively assume, that roughly the
same number of :math:`B` and :math:`\overline{B}` mesons are initially produced
(which is true) and if we sample these event counts directly, it would be like
assuming that the number of *observed* :math:`B` and :math:`\overline{B}`
meson decays are the same in each of these four cases (and happen to be in the
correct final state, too), which is, of course, false. The reason is that if a
CP asymmetry is present, depending on the decay time, the probability of
observing a decay of an initial :math:`B` or a :math:`\overline{B}` meson will
vary with time. This fact is also reflected in the time-integrated CP
asymmetry, which is also non-zero if CPV is present and implies an imbalance of
observed decays of initial :math:`B` and :math:`\overline{B}` meson decays. 

The generation of the decay time data is now motivated using two well-known decay modes.

Part 1: The CP violating decay :math:`B^0 \to J\!/\!\psi K^0_\mathrm{S}`
........................................................................

First, we can look at a decay mode with relatively simple physics,
:math:`B^0\to J\!/\!\psi K^0_S`, where :math:`f=\overline{f}=1` (interference
CP violation) and thus :math:`S=\overline{S}` and :math:`C=\overline{C}=0` and
:math:`\Delta\Gamma\approx 0`. In this channel, CP violation is a very large
effect, which is why CP violation in the :math:`B` system was discovered in
this mode. Here we set :math:`f=1` and only focus on the first two decay rates.
The total numbers of observed decays of :math:`B` and :math:`\overline{B}`
mesons will largely depend on the integrals

.. math::
   N_{B^0} &\propto \int_0^\infty e^{-\Gamma t}[1-S\sin(\Delta mt)]\, dt = \frac{1}{\Gamma} - \frac{S\Delta m}{\Delta m^2+\Gamma^2} \approx 0.52\\
   N_{\overline{B}^0} &\propto \int_0^\infty e^{-\Gamma t}[1+S\sin(\Delta mt)]\, dt = \frac{1}{\Gamma} + \frac{S\Delta m}{\Delta m^2+\Gamma^2} \approx 0.80

when we set :math:`S=0.7`. Therefore, because of CP violation, more decays of initial
:math:`\overline{B}^0` mesons will be observed, which is consistent with the shape and
sign of the CP asymmetry, as published by several experiments. And indeed, if
one observes the TRUEID distribution in actual Monte Carlo samples, for such a
decay mode with small :math:`\Delta m` the imbalance of initial B-ID will be 
large, as seen below:

.. plot::
   :include-source: false

   import numpy as np
   import matplotlib.pyplot as plt

   fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(6, 3))
   N = 100000
   S=0.7

   def plot(ax, G, m):
       Aplus = 1/G - S*m/(m**2 + G**2)
       Aminus = 1/G + S*m/(m**2 + G**2)

       ratio = Aplus/(Aplus + Aminus)

       Nplus = N * ratio
       Nminus = N - Nplus

       ax.hist([-511, 511], bins=30, weights=[Nminus, Nplus], color="C0")
       ax.set_xlabel("Monte Carlo Particle ID", fontsize=15)


   ax1.set_title(r"$\Delta m_d=0.5065\,\mathrm{ps}^{-1}$")
   plot(ax1, 1.52, 0.5065)
   ax2.set_title(r"$\Delta m_s=17.765\,\mathrm{ps}^{-1}$")
   plot(ax2, 1.52, 17.765)
   fig.tight_layout()

In the right plot, a higher oscillation frequency is inserted to demonstrate
the effect. The number of initially produced :math:`B^\pm` (or :math:`B` and
:math:`\overline{B}`) mesons is given by :math:`N^\pm` 

.. math::
   N^+ &= N_\mathrm{tot}A_{\mathcal{I}} \qquad\text{with}\qquad A_{\mathcal{I}}=\frac{\int_0^\infty P(t|B^0,1)\,dt}{\int_0^\infty P(t|\overline{B}^0,1)\,dt+\int_0^\infty P(t|B^0,1)\,dt}\\
   N^- &= N_\mathrm{tot} - N^+,

where :math:`A_{\mathcal{I}}` is the correction needed to account for the 
event yields in the presence of CP violation. The distributions for vanishing
and non-zero CP asymmetry are shown below side by side:

.. plot::
   :include-source: false

   import matplotlib.pyplot as plt
   import lhcb_ftcalib as ft
   import numpy as np
   import pandas as pd

   from scripts.jpsiks_asym import timehist_JpsiKS, timehist_JpsiKstar, asymmetry
   tmin = 0
   tmax = 15

   tg = ft.ToyGenerator(tmin, tmax, seed=34987534)
   tg_cpv = ft.ToyGenerator(tmin, tmax, seed=34987534)
   tg.setPhysics(    neutral_mode=True, flavour_specific=True, DM=0.5065, DG=0, S=0,   Sbar=0,   C=1.0, Cbar=-1.0, ADG=0, ADGbar=0.0)
   tg_cpv.setPhysics(neutral_mode=True, flavour_specific=False, DM=0.5065, DG=0, S=0.7, Sbar=0.7, C=0.0, Cbar=0.0, ADG=0, ADGbar=0.0)

   df_zero = tg.generate(100000, acceptance="arctan")
   df_cpv = tg_cpv.generate(100000, acceptance="arctan")

   fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(10, 8))

   timehist_JpsiKstar(tmin, tmax, ax1, df_zero, tg)
   timehist_JpsiKS(tmin, tmax, ax2, df_cpv, tg_cpv)
   asymmetry(tmin, tmax, ax3, df_zero, "No CPV", tg, nbins=20)
   asymmetry(tmin, tmax, ax4, df_cpv, "S=0.7", tg_cpv, nbins=20, show_S=True)

   ax1.set_ylabel("Entries", fontsize=15)
   ax3.set_ylabel("$A_{CP}$", fontsize=15)
   fig.tight_layout()

The two lower plots show the time-integrated asymmetry per decay time bin. On
the right, we clearly see that we can recover the parameter :math:`S=0.7` from
this asymmetry as it is its amplitude. Inspect the plot source to see how these
were made using lhcb_ftcalib and its toy generator.

Part 2: The decay :math:`B_s \to D_s^- \pi^+`
.............................................
In this decay mode, CP violation is negligible and has, as of 2026, not been
established. Therefore :math:`S=\overline{S}=0`. Since this decay is
flavour-specific, we need to set :math:`C=1` and :math:`\overline{C}=-1`, such
that at time :math:`t=0` since we had no time for oscillations, we observe the
pure, flavour specific decays :math:`B_s^0 \to D_s^-\pi^+` and
:math:`\overline{B}_s^0 \to D_s^+\pi^-`. Furthermore,
:math:`\Delta\Gamma_s=0.083\,\mathrm{ps}^{-1}` and :math:`\Delta
m_s=17.765\,\mathrm{ps}^{-1}`. This is the decay mode in which the LHCb
collaboration measured the oscillation frequency with unprecedented precision.

Here, since we have two possible final states, we need to sample from all four
decay time distributions. We know quite a lot about the physics of this decay
mode, and if we would insert our theoretical knowledge into the equations and
simplify, we would be left with two effective equations as a measurement
strategy, one describing the mixed, and one describing the unmixed decays. But
if we for a moment pretend that we do not know the values of the physical
parameters, we need to be quite careful about choosing the right event numbers for
sampling.

As a start we can say that the fraction of all :math:`B_s` mesons
decaying into the final state with CP eigenvalue :math:`f=\pm 1` is given by

.. math::
   N_{f=1}=Nf_+ &= N\frac{
    \int_0^\infty P(t|B,1) + P(t|\overline{B},1)\, dt
   }{
    \int_0^\infty P(t|B,1) + P(t|\overline{B},-1)+ P(t|\overline{B},1)+ P(t|B,-1)\, dt
   }\\
   N_{f=-1}&= N(1 - f_+).

since this gives us a clear instruction on how to split the sample into
sub-problems. Then we are practically left with two subsamples, whose
normalization condition can be solved individually as shown in the previous
section:

.. math::
    N(B,f=+1) &= N \cdot f_+\cdot A_{\mathcal{I}}(f=1)\\
    N(\overline{B},f=+1) &= N \cdot f_+ (1 - A_{\mathcal{I}}(f=1))\\
    N(B,f=-1) &= N \cdot (1 - f_+)\cdot A_{\mathcal{I}}(f=-1)\\
    N(\overline{B},f=-1) &= N \cdot (1 - f_+)\cdot (1 - A_{\mathcal{I}}(f=-1))

In a sample of 100000 generated events, this would lead to the following event
numbers for the decay :math:`B_s^0 \to D_s^-\pi^+`:

.. math::
    N(D_s^+\pi^-) &= 50000 \\
    N(D_s^-\pi^+) &= 50000 \\
    N(B_s^0\to D_s^-\pi^+) &= 24892 \\
    N(\overline{B}_s^0\to D_s^-\pi^+) &= 25108 \\
    N(B_s^0\to D_s^+\pi^-) &= 25107 \\
    N(\overline{B}_s^0\to D_s^+\pi^-) &= 24893

The reason for the slight excess of mixed decays is due to the fact that an
acceptance function was used, which suppresses the first oscillations heavily.
Without an acceptance, a slight excess of unmixed decays would be observed.

When we sample the decay time distributions for mixed and unmixed decays with
correct event yields, we get the following distribution:

.. plot::
   :include-source: false

    import lhcb_ftcalib as ft
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd

    def curve_area(curve_y, dx):
        return np.sum(curve_y) * dx

    tmin = 0
    tmax = 3
    precision = 1000

    gen = ft.ToyGenerator(tmin, tmax, seed=230948)
    gen.setPhysics(neutral_mode=True, flavour_specific=True, DM=17.765, DG=0.083, S=0, Sbar=0, C=1.0, Cbar=-1.0, ADG=0, ADGbar=0.0)

    df = gen.generate(100000, acceptance="arctan")

    t = np.linspace(tmin, tmax, precision)
    acc = gen.arctan_acceptance

    nbins = 200
    curve_mixed   = gen.bdecay(t, fprod=-1, fdecay=1, acceptance=acc) + gen.bdecay(t, fprod=1, fdecay=-1, acceptance=acc)
    curve_unmixed = gen.bdecay(t, fprod=1, fdecay=1, acceptance=acc) + gen.bdecay(t, fprod=-1, fdecay=-1, acceptance=acc)

    bin_width = (tmax - tmin) / nbins
    Nmixed = len(df[df.PROCESS.isin([2, 3])])
    Nunmixed = len(df[df.PROCESS.isin([1, 4])])
    curve_mixed /= curve_area(curve_mixed, (tmax - tmin) / precision)
    curve_mixed *= Nmixed * bin_width
    curve_unmixed /= curve_area(curve_unmixed, (tmax - tmin) / precision)
    curve_unmixed *= Nunmixed * bin_width

    fig, ax = plt.subplots(1, 1, figsize=(7, 4))

    ax.hist(df.TRUETAU[(df.PROCESS==1)|(df.PROCESS==4)], bins=nbins, histtype="stepfilled", linewidth=1, label="Unmixed", alpha=0.4, color="b")
    ax.hist(df.TRUETAU[(df.PROCESS==2)|(df.PROCESS==3)], bins=nbins, histtype="stepfilled", linewidth=1, label="Mixed", alpha=0.4, color="r")
    ax.hist(df.TRUETAU, bins=nbins, histtype="step", linewidth=1, label="Total", alpha=0.7)

    ax.plot(t, curve_mixed, label="Mixed", color="r", linewidth=1)
    ax.plot(t, curve_unmixed, label="Unmixed", color="b", linewidth=1)

    ax.legend(loc="upper right")
    ax.set_xlim(tmin, tmax)
    ax.set_xlabel("Decay Time [ps]", fontsize=15)
    ax.set_ylabel("Entries", fontsize=15)
    fig.tight_layout()

.. Part 3: The decay :math:`B_s \to D_s^- K^+`
.. ...........................................
.. The event generation for the decay time has already been fully established in
.. the previous section. This third decay mode is interesting for the reason, that
.. its not only a flavour-specific decay, but that it also violates CP.
..
.. TODO

Generating the mistag distribution
----------------------------------
The way the toy generator is supposed to work, is that it generates tagging
data with a relation between the raw mistag :math:`\eta`, the calibrated mistag
:math:`\omega` and the tagging decisions :math:`d`, which is given by a chosen
calibration function, such that by calibrating the tagger (using :math:`\eta`
and :math:`d`), one can recover the chosen calibration parameters and the
:math:`\omega`-distribution.

Since there are an infinite number of possible mistag distributions
corresponding to the same calibration parameters :math:`p_i`, the user is free
to choose any mistag distribution. This choice will affect the tagging
performance. Finally, the tagging decision is initialized to the true
production flavour and inverted probabilistically according to the
**calibrated** mistag :math:`\omega`. This way, the tagging decision 
effectively encodes the relationship between :math:`\eta` and :math:`\omega`.

The generated mistag distributions and the fitted calibration curve recovered
from the same toy sample are shown side by side below:

.. plot::
   :include-source: false

    import lhcb_ftcalib as ft
    import matplotlib.pyplot as plt
    import numpy as np

    F1 = ft.PolynomialCalibration(2, ft.link.mistag)

    gen = ft.ToyGenerator(0, 15, seed=2398754)
    gen.setPhysics(neutral_mode=True, flavour_specific=True, C=1, Cbar=-1)

    p0_plus = 0.04
    p1_plus = 0.3
    p0_minus = -0.03
    p1_minus = 0.2

    params = ft.CalParameters(2)
    params.set_calibration_flavour([p0_plus, p1_plus, p0_minus, p1_minus], np.eye(4))

    delta_params = params.params_delta

    etaDistribution = lambda x: np.exp(-0.5 * ((x - 0.3)/0.09) ** 2)

    gen.add_tagger(name           = "T1",
                   params_plus    = [p0_plus, p1_plus],
                   params_minus   = [p0_minus, p1_minus],
                   eta_shape_func = etaDistribution,
                   calib_func     = F1)
    df = gen.generate(100000, acceptance="arctan")

    tc = ft.TaggerCollection()
    tc.create_tagger("T1", df.T1_ETA, df.T1_DEC, 511 * df.FLAV_PROD, mode="TRUEID")
    tc.set_calibration(F1)
    tc.calibrate(quiet=True)

    eta_lin = np.linspace(0, 0.5, 1000)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

    nbins = 100
    bin_width = 0.5 / nbins
    sampling_curve = etaDistribution(eta_lin)
    sampling_curve /= np.trapezoid(sampling_curve, eta_lin)
    sampling_curve *= len(df) * bin_width

    ax1.hist(df.T1_ETA, bins=nbins, range=(0, 0.5), histtype="step", linewidth=1, label=r"$\eta$", alpha=0.7)
    ax1.hist(df.T1_OMEGA, bins=nbins, range=(0, 0.5), histtype="step", linewidth=1, label="$\omega$", alpha=0.7)
    ax1.plot(eta_lin, sampling_curve, linewidth=1, linestyle="--", color="C0", label=r"$\exp\left(-\frac{1}{2}\left(\frac{x-0.3}{0.09}\right)^2\right)$")

    flavour_text = "\n".join([rf"${pname}$={p:.4f}" for pname, p in zip(params.names_latex_flavour, params.params_flavour)])
    delta_text = "\n".join([rf"${pname}$={p:.4f}" for pname, p in zip(params.names_latex_delta, params.params_delta)])

    ax1.text(0.02, 0.9, flavour_text, transform=ax1.transAxes, fontsize=10, verticalalignment="top", bbox=dict(boxstyle="round", facecolor="white", alpha=0.8))
    ax1.text(0.02, 0.5, delta_text, transform=ax1.transAxes, fontsize=10, verticalalignment="top", bbox=dict(boxstyle="round", facecolor="orange", alpha=0.8))

    ax1.set_xlim(0, 0.5)
    ax1.set_xlabel("Mistag", fontsize=15)
    ax1.set_ylabel("Entries", fontsize=15)
    ax1.set_title(r"Generated $\eta$ and $\omega$", fontsize=15)
    ax1.legend(loc="lower right", fontsize=15)

    ft.draw_calibration_curve(tc["T1"], ax=ax2, save=False, title="Calibration", title_fontsize=14, legend_fontsize=15, params_fontsize=10, axis_fontsize=15)
    fig.tight_layout()

As shown above, the calibration does a good job at recovering the input
calibration parameters. Notice how the generated mistag distribution is not
quite faithful to the input function towards zero. The reason is that eta
values are corrected upwards, such that the calibrated omega value ends up at a
safe distance from zero. This is done, since when omega approaches zero,
singularities are encountered in the likelihood computation, which we want to
avoid in automated tests. In production, lhcb_ftcalib will warn you about
:math:`\omega\le 0` cases. Lastly, we will choose a slightly more complex
calibration and decorrelate the production flavour from the decay flavour by
setting :math:`\Delta m_s=17.765\,\mathrm{ps}^{-1}` in the generation of the
decay time data.

.. plot::
   :include-source: false

    import lhcb_ftcalib as ft
    import matplotlib.pyplot as plt
    import numpy as np

    F1 = ft.PolynomialCalibration(3, ft.link.mistag)

    gen = ft.ToyGenerator(0, 15, 329848)
    gen.setPhysics(neutral_mode=True, flavour_specific=True, DM=17.765, DG=0, S=0, Sbar=0, C=1.0, Cbar=-1.0, ADG=0, ADGbar=0.0)

    p0_plus = 0.04
    p1_plus = 0.3
    p2_plus = -2.3
    p0_minus = -0.03
    p1_minus = 0.2
    p2_minus = -1.3

    params = ft.CalParameters(3)
    params.set_calibration_flavour([p0_plus, p1_plus, p2_plus, p0_minus, p1_minus, p2_minus], np.eye(6))

    delta_params = params.params_delta

    etaDistribution = lambda x: np.exp(-0.5 * ((x - 0.3)/0.09) ** 2)

    gen.add_tagger(name           = "T1",
                   params_plus    = [p0_plus, p1_plus, p2_plus],
                   params_minus   = [p0_minus, p1_minus, p2_minus],
                   eta_shape_func = etaDistribution,
                   calib_func     = F1)
    df = gen.generate(100000, acceptance="arctan")

    tc = ft.TaggerCollection()
    tc.create_tagger("T1", df.T1_ETA, df.T1_DEC, df.FLAV_DECAY, tau_ps=df.TAU, mode="Bs")
    tc.set_calibration(F1)
    tc.calibrate(quiet=True)

    eta_lin = np.linspace(0, 0.5, 1000)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

    nbins = 100
    bin_width = 0.5 / nbins
    sampling_curve = etaDistribution(eta_lin)
    sampling_curve /= np.trapezoid(sampling_curve, eta_lin)
    sampling_curve *= len(df) * bin_width

    ax1.hist(df.T1_ETA, bins=nbins, range=(0, 0.5), histtype="step", linewidth=1, label=r"$\eta$", alpha=0.7)
    ax1.hist(df.T1_OMEGA, bins=nbins, range=(0, 0.5), histtype="step", linewidth=1, label="$\omega$", alpha=0.7)
    ax1.plot(eta_lin, sampling_curve, linewidth=1, linestyle="--", color="C0", label=r"$\exp\left(-\frac{1}{2}\left(\frac{x-0.3}{0.09}\right)^2\right)$")

    flavour_text = "\n".join([rf"${pname}$={p:.4f}" for pname, p in zip(params.names_latex_flavour, params.params_flavour)])
    delta_text = "\n".join([rf"${pname}$={p:.4f}" for pname, p in zip(params.names_latex_delta, params.params_delta)])

    ax1.text(0.02, 0.9, flavour_text, transform=ax1.transAxes, fontsize=10, verticalalignment="top", bbox=dict(boxstyle="round", facecolor="white", alpha=0.8))
    ax1.text(0.02, 0.5, delta_text, transform=ax1.transAxes, fontsize=10, verticalalignment="top", bbox=dict(boxstyle="round", facecolor="orange", alpha=0.8))

    ax1.set_xlim(0, 0.5)
    ax1.set_xlabel("Mistag", fontsize=15)
    ax1.set_ylabel("Entries", fontsize=15)
    ax1.set_title(r"Generated $\eta$ and $\omega$", fontsize=15)
    ax1.legend(loc="lower right", fontsize=15)

    ft.draw_calibration_curve(tc["T1"], ax=ax2, save=False, title="Calibration", title_fontsize=14, legend_fontsize=15, params_fontsize=10, axis_fontsize=15)
    fig.tight_layout()

And again, the retrieved parameters are reasonably close to the input parameters.

Effect of Flavour Tagging on CPV observables
--------------------------------------------
When measuring CP violation amplitudes in time-dependent analyses, flavour
tagging directly affects the sensitivity of the measurement. In one class of
such measurements, if both the :math:`B` and the :math:`\overline{B}` meson can
decay into the same final state, the time-dependent CP asymmetry is given by

.. math::
    \mathcal{A}(t) = \frac{\Gamma(\overline{B}(t)\to f)-\Gamma(B(t)\to f)}{\Gamma(\overline{B}(t)\to f)+\Gamma(B(t)\to f)} = \frac{S\sin(\Delta m t) - C\cos(\Delta m t)}{\cosh\!\left(\frac{1}{2}\Delta\Gamma t\right) + A_{\Delta\Gamma} \sinh\!\left(\frac{1}{2}\Delta\Gamma t\right)}

In general, the statistical uncertainty of the time-dependent CP asymmetry
exhibits the following proportionality:

.. math::
    \sigma(\mathcal{A}) \propto \frac{1}{\sqrt{\epsilon_\mathrm{tag, eff}N}} = \frac{1}{\sqrt{\epsilon_\text{tag}(1-2\omega)^2N}},

where :math:`\epsilon_\mathrm{tag,eff}` is the effective tagging efficiency or
tagging power, :math:`\epsilon_\mathrm{tag}` is the tagging efficiency and
:math:`\omega` is the mean mistag probability of the sample. Intuitively, with
increasing flavour tagging performance, the observed amplitude increases,
reaching its actual size in the limit of perfect tagging, while without flavour
tagging, we cannot distinguish between the two initial flavours and thus the
observed CP asymmetry is zero. To properly measure one or more amplitudes, it
is important to precisely quantify the effect flavour tagging has on their
measurement. We thus need to derive amplitude correction factors to assign to
each event and to each amplitude to compensate the amplitude dampening due to
imperfect tagging. For this reason, these amplitudes will now be derived from
first principles. One available implementation of these is part of LHCb's B2DX
fitter, called DecRateCoeff_Bd.h or DecRateCoeff_Bs.h and it is made for
fitting with RooFit. We start with the initial, simplified, decay rates

.. math::
   \frac{P(t|B,f=+1)}{(1-\alpha)(1+\beta)}            &\propto e^{-\Gamma t} \left[H\cosh(\Delta\Gamma t/2) + C\cos(\Delta mt) - S\sin(\Delta m t) + A\sinh(\Delta\Gamma t/2)\right]\\
   \frac{P(t|\overline{B},f=+1)}{(1+\alpha)(1+\beta)} &\propto e^{-\Gamma t} \left[H\cosh(\Delta\Gamma t/2) - C\cos(\Delta mt) + S\sin(\Delta m t) + A\sinh(\Delta\Gamma t/2)\right]\\
   \frac{P(t|B,f=-1)}{(1-\alpha)(1-\beta)}            &\propto e^{-\Gamma t} \left[\overline{H}\cosh(\Delta\Gamma t/2) + \overline{C}\cos(\Delta mt) - \overline{S}\sin(\Delta m t) + \overline{A}\sinh(\Delta\Gamma t/2)\right]\\
   \frac{P(t|\overline{B},f=-1)}{(1+\alpha)(1-\beta)} &\propto e^{-\Gamma t} \left[\overline{H}\cosh(\Delta\Gamma t/2) - \overline{C}\cos(\Delta mt) + \overline{S}\sin(\Delta m t) + \overline{A}\sinh(\Delta\Gamma t/2)\right]

where we have labelled the :math:`\cosh`-parameter with :math:`H` instead of :math:`D` to
avoid confusion with the tagging dilution. The observed decay time distribution
for events measured in the final state with CP eigenvalue :math:`f` is then given by the
sum of the two possible paths to reach this final state:

.. math::
   P_{CP}(t|f) = (1-\alpha)(1+f\beta)P(t,B,f) + (1+\alpha)(1+f\beta)P(t,\overline{B},f).

In this form, this expression is not very useful though, as it cancels to
almost nothing. Now we introduce flavour tagging as a way to interpolate
between these two distributions based on the tagging decision and the
calibrated mistag probability.

.. math::
   P_{CP}(t|f,{\color{blue}d}) &= {\color{blue}[\epsilon^+(\delta_{d,1}(1-\omega^+)+\delta_{d,-1}\omega^+) +\delta_{d,0} (1-\epsilon^+))]}(1-\alpha)(1+f\beta)P(t,B,f) \\
                 &+ {\color{blue}[\epsilon^-(\delta_{d,-1}(1-\omega^-)+\delta_{d,1}\omega^-) +\delta_{d,0} (1-\epsilon^-))]}(1+\alpha)(1+f\beta)P(t,\overline{B},f)

Here, :math:`\epsilon^\pm` are the tagging efficiencies of the tagger in
the two calibration subsamples belonging to the two initial flavours and
:math:`\omega^\pm=\omega(\eta,\vec{p}^\pm)` are the corresponding calibrated
mistag probabilities. Observe how in the case of perfect tagging
(:math:`\epsilon^\pm=1` and :math:`\omega^\pm=0`), the tagging decision acts as
a binary selector between the two decay rates, while it otherwise interpolates
smoothly using the mistag probability. Even if a single event is not tagged at
all, the fact that the algorithm may have an efficiency asymmetry
:math:`\epsilon^+ \neq \epsilon^-` can still give us some sensitivity to the CP
asymmetry, albeit extremely small in practice. Likewise, it is interesting to
note, that a sizable production asymmetry alone would reveal the oscillating
nature of the decay rates in the decay time distribution, but again, in
practise, it is far too small to be noticed.

From here, the path to the result is obvious. The expression
:math:`P_{CP}(t|f,d)` needs to be expanded and regrouped, such that the CP
asymmetry amplitudes :math:`S`, :math:`C`, :math:`A_{\Delta\Gamma}` and
:math:`H` are factored out and their corresponding correction factors are
identified. This way, we aim at measuring the effect of flavour tagging and
other asymmetries as separate factors to these parameters, like this 

.. math::
   S_f \mapsto \mathcal{F}_{\!S}(\omega(\eta,\vec{p}), d, f, \alpha,\beta,\epsilon,\Delta\epsilon,\Delta\omega) \cdot S_f,

and likewise for all other amplitude parameters. This is indeed possible and
beneficial for practical implementations, as will be shown. This is a somewhat
tedious process and is performed here using computer algebra to avoid sign
errors. Some useful definitions can be made:

.. math::
   \omega&\equiv\frac{\omega^++\omega^-}{2} \qquad \Delta\omega\equiv\omega^+-\omega^-\\
   \epsilon_\mathrm{tag}&\equiv\frac{\epsilon^++\epsilon^-}{2} \qquad \Delta\epsilon\equiv\epsilon^--\epsilon^+

and therefore

.. math::
    \epsilon^\pm = \epsilon_\mathrm{tag} \mp \frac{\Delta\epsilon}{2}.

Furthermore, the Kronecker deltas can be substituded with algebraic expressions
using the tagging decision: :math:`\delta_{d,\pm 1} = \frac{1}{2}(1 \pm  d)`.
It is recommended to treat the untagged case separately. We find that for the
sample of tagged events, the correction factors :math:`\mathcal{F}` are given
by

.. math::
    \mathcal{F}_{\!S}                &= (1+f\beta)\left\{-d D \left(\frac{\alpha\Delta\epsilon}{2}+\epsilon_\text{tag}\right)-\frac{1}{2}d\Delta\epsilon\Delta\omega-d\alpha\epsilon_\text{tag}\Delta\omega+\alpha\epsilon_\text{tag}+\frac{\Delta\epsilon}{2}\right\}\\
    \mathcal{F}_{\!C}                &= -\mathcal{F}_{\!S}\\
    \mathcal{F}_{\!H}                &= (1+f\beta)\left\{ \epsilon_\text{tag} + \frac{\alpha\Delta\epsilon}{2} - \frac{1}{2}d\alpha\Delta\omega\Delta\epsilon-\epsilon_\text{tag} d\Delta\omega -Dd\left(\frac{\Delta\epsilon}{2} +\alpha\epsilon_\text{tag}\right) \right\}\\
    \mathcal{F}_{\!A_{\Delta\Gamma}} &= \mathcal{F}_{\!H}

where :math:`D=1-\omega^+-\omega^-=1-2\omega` is the flavour tagging dilution
with :math:`\omega=\omega(p_0,\cdots p_m,\Delta p_0,\cdots,\Delta p_m)`. For
untagged events, the following corrections need to be assigned

.. math::
    \mathcal{F}_{\!S}                &= (1+f\beta)(-\Delta\epsilon-2\alpha(\epsilon_\text{tag}-1))\approx 0\\
    \mathcal{F}_{\!C}                &= -\mathcal{F}_{\!S}\\
    \mathcal{F}_{\!H}                &= (1+f\beta)(2(1-\epsilon_\text{tag})-\alpha\Delta\epsilon)\\
    \mathcal{F}_{\!A_{\Delta\Gamma}} &= \mathcal{F}_{\!H}

The amplitude corrections for the parameters :math:`\overline{S}`,
:math:`\overline{C}`, :math:`\overline{H}` and
:math:`\overline{A}_{\Delta\Gamma}` are obtained by setting :math:`f=-1`. This
calculation was verified using a Mathematica script, which can be found in the
doc/ folder of lhcb_ftcalib or can be downloaded here: :download:`Download Mathematica Notebook <Decrates.nb>`
:download:`or as a PDF <Decrates.pdf>`

.. note::
    On second thought, it might seem unusual, that the tagging efficiency is
    part of these corrections. After all, the amount of tagged events in the
    sample does not obviously affect an individual event. However, it is needed
    to account for the effect that the selection of a tagged subsample can bias
    the CP asymmetry if this subsample has an underlying flavour tagging bias.
    This parameter is therefore needed to account for the relative sizes of
    these samples. Overall, the effect of this parameter is usually very subtle
    and in absence of tagging asymmetries, it is absorbed by the integration
    constant.

These amplitude corrections neatly encode all the flavour tagging performance
and bias effects on our physics result. To measure CP violation, we can
therefore perform a time-dependent fit using a single decay rate:

.. math::
    P(t|f,d) \propto e^{-\Gamma t} \left\{ \mathcal{F}_{\!H} \cosh\!\left(\frac{1}{2}\Delta\Gamma t\right) + C_f\cdot\mathcal{F}_{\!C} \cos(\Delta m t) + S_f\cdot\mathcal{F}_{\!S} \sin(\Delta m t) + A_{\Delta\Gamma,f}\mathcal{F}_{H} \sinh\!\left(\frac{1}{2}\Delta\Gamma t\right) \right\}

in which the amplitude corrections take care of the relative signs and all
asymmetries and depend on the tagging decision and the final state of the given
event.

To better see what they actually do, we can remove all the small asymmetries we
would normally expect to be small and are then left with trivially simple
expressions:

.. math::
    \mathcal{F}_{\!S} &\approx -d (1-2\omega) \\
    \mathcal{F}_{\!C} &\approx d (1-2\omega) \\
    \mathcal{F}_{\!H} &= \mathcal{F}_{\!A_{\Delta\Gamma}} = 1

We thus learn, that the amplitudes are dampened by the factor
:math:`1-2\omega`, which is the flavour tagging dilution
:math:`\mathcal{D}_{FT}`. One can thus write in approximation, that
:math:`\mathcal{A}_{CP}^\text{observed}=\mathcal{D}_{FT}\cdot\mathcal{A}_{CP}^\text{true}`.
Armed with these coefficients, we can now create toy data sets using lhcb_ftcalib's
toy generator and recreate exemplary LHCb analyses.

The measurement of :math:`\sin(2\beta)` in :math:`B^0 \to J\!/\!\psi K^0_S` decays as a toy analysis
----------------------------------------------------------------------------------------------------
This decay offers an excellent environment to measure the CP violation
parameter :math:`\sin(2\beta)`, with only very small contributions from penguin
diagrams. The final state of the decay is CP invariant, and a huge CP violating
effect can be observed in the interference of the decays with and without
mixing. In this mode, we expect :math:`S\approx\sin(2\beta)\approx 0.7` and :math:`C=0`.

First, we generate the toy data and throw away the branches we would normally
not have access to in real data. We are unable to calibrate the decay
:math:`B^0 \to J\!/\!\psi K^0_S` on its own, unfortunately, since its final
state is not flavour-specific. A control mode is therefore needed which we will
use to transfer the calibration to the signal mode, assuming that the decays
are sufficiently similar in terms of kinematics. Here, we chose :math:`B^0 \to
J\!/\!\psi K^{*}(892)^0(\to K^+\pi^-)` as the calibration mode, for four
reasons: It is a flavour-specific decay, so it can be used to calibrate a
tagging algorithm, secondly, it exhibits no CP violation, at least to great
precision. Reasons three and four are that the decay is abundant and can be
selected with high purity. These considerations are not relevant here, as we do
not generate any background contributions (but the reader is invited to assemble 
cocktail toy MC samples with this tool, which is implemented in :class:`~lhcb_ftcalib.MultiComponentToyGenerator`).

**DATA GENERATION**

.. code-block:: python

    import lhcb_ftcalib as ft
    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd

    def generate_data(SEED, acceptance):
        S_true = 0.7
        # Set true calibration parameters in flavour form
        p0_plus = 0.04
        p1_plus = 0.3
        p0_minus = -0.03
        p1_minus = 0.28
        N = 100000

        # /////////////////////////////////////
        # Generate the signal mode B -> Jpsi KS
        # /////////////////////////////////////
        genJpsiKS = ft.ToyGenerator(0, 15, seed=SEED) # ps
        genJpsiKS.setPhysics(DM=0.5065, DG=0, S=S_true, C=0)
        calibration = ft.PolynomialCalibration(2, ft.link.mistag)
        genJpsiKS.add_tagger(name     = "ToyTagger",
                       params_plus    = [p0_plus, p1_plus],
                       params_minus   = [p0_minus, p1_minus],
                       eta_shape_func = lambda x: np.exp(-0.5 * ((x - 0.3)/0.03) ** 2),
                       calib_func     = calibration)
        dfJpsiKS = genJpsiKS.generate(N, acceptance=acceptance)

        # /////////////////////////////////////////////////////////////////////////////
        # Generate the calibration mode B -> Jpsi K*(892)0 with identical tagging setup
        # /////////////////////////////////////////////////////////////////////////////
        genJpsiKst = ft.ToyGenerator(0, 15, seed=SEED + 1) # ps
        genJpsiKst.setPhysics(DM=0.5065, DG=0, S=0, Sbar=0, C=1.0, Cbar=-1.0)
        genJpsiKst.add_tagger(name    = "ToyTagger",
                       params_plus    = [p0_plus, p1_plus],
                       params_minus   = [p0_minus, p1_minus],
                       eta_shape_func = lambda x: np.exp(-0.5 * ((x - 0.3)/0.03) ** 2),
                       calib_func     = calibration)
        dfJpsiKst = genJpsiKst.generate(N, acceptance=acceptance)

        # Remove branches we would not have access to in real data
        dfJpsiKS.drop(columns=["PROCESS", "FLAV_PROD", "FLAV_DECAY", "TRUETAU", "FLAV_HYPOT", "ToyTagger_OMEGA"], inplace=True)
        dfJpsiKst.drop(columns=["PROCESS", "FLAV_PROD", "TRUETAU", "FLAV_HYPOT", "ToyTagger_OMEGA"], inplace=True)
        return dfJpsiKS, dfJpsiKst

**FLAVOUR TAGGING CALIBRATION**

For the sake of this demonstration, we assume that we can safely apply the
calibration obtained in the calibration mode to the signal mode. Now the
analysis can begin. First, we calibrate our only tagger in the calibration mode
and check the results:

.. code-block:: python

    # Calibrate the tagger in the JpsiKstar control mode
    tc = ft.TaggerCollection()
    tc.create_tagger("ToyTagger", 
                     dfJpsiKst.ToyTagger_ETA,
                     dfJpsiKst.ToyTagger_DEC, 
                     511 * dfJpsiKst.FLAV_DECAY,
                     tau_ps = dfJpsiKst.TAU,
                     mode = "Bd")
    tc.set_calibration(ft.PolynomialCalibration(2, ft.link.mistag))
    tc.calibrate(quiet=True)
    # Save calibration result for later use in the signal mode
    calib_result = ft.save_calibration(tc, "ToyTagger", write=False)

    ft.draw_calibration_curve(tc["ToyTagger"], title="Calibration", title_fontsize=14, legend_fontsize=15, params_fontsize=10, axis_fontsize=15)

.. plot::
   :include-source: false

    import lhcb_ftcalib as ft
    from scripts.jpsiks_analysis import generate_data

    def acceptance(t):
        return 2.0 * np.arctan(2.0 * t) / np.pi

    dfJpsiKS, dfJpsiKst = generate_data(493874, acceptance=acceptance)

    tc = ft.TaggerCollection()
    tc.create_tagger("ToyTagger", 
                     dfJpsiKst.ToyTagger_ETA, 
                     dfJpsiKst.ToyTagger_DEC, 
                     511 * dfJpsiKst.FLAV_DECAY,
                     tau_ps = dfJpsiKst.TAU,
                     mode="Bd")
    tc.set_calibration(ft.PolynomialCalibration(2, ft.link.mistag))
    tc.calibrate(quiet=True)

    fig, ax = plt.subplots(1, 1, figsize=(7, 5))
    ft.draw_calibration_curve(tc["ToyTagger"], ax=ax, save=False, title="Calibration", title_fontsize=14, legend_fontsize=15, params_fontsize=10, axis_fontsize=15, print_params=False)
    fig.tight_layout()


**TAGGING CALIBRATION TRANSFER**
Finally, we can perform the time-dependent fit in the signal mode. First we
apply the calibration to the tagger in the signal mode and then we define a
maximum likelihood fit to measure the decay rates. We will use a simplified
version of the decay rate coefficients, matching our simple physics
configuration.

.. code-block:: python

    # Apply the calibration to JpsiKS and retrieve the calibrated mistag and tagging decision for the main fit
    target = ft.TargetTagger("ToyTagger", dfJpsiKS["ToyTagger_ETA"].to_numpy(), dfJpsiKS["ToyTagger_DEC"].to_numpy())
    target.load(calib_result, "ToyTagger")
    target.apply()

    toyTaggerCalibrated = target.get_dataframe()

    omega = toyTaggerCalibrated["ToyTagger_OMEGA"].to_numpy()
    dec = toyTaggerCalibrated["ToyTagger_CDEC"].to_numpy()

**TIME-DEPENDENT FIT**

The likelihood we now need to implement for this mode has the simple form 

.. math::
    P(t|S,C) \propto \epsilon(t)e^{-\Gamma t} \left\{ 1 + S \cdot \mathcal{F}_{\!S}(\omega, d) \sin(\Delta m t) + C \cdot \mathcal{F}_{\!C}(\omega, d) \cos(\Delta m t) \right\}

with the amplitude corrections :math:`\mathcal{F}_{\!S} = -d (1-2\omega) = -\mathcal{F}_{\!C}` as derived above.
To implement this fit as a maximum likelihood fit using iminuit, we need to compute a normalization 
of this model. Since the normalization factorizes and is linear with respect to the amplitude corrections, we can 
easily derive the necessary terms by numerical integration:

.. math::
    N_{\exp} &= \int_{t_\text{min}}^{t_\text{max}} \epsilon(t)e^{-\Gamma t} \,dt\\
    N_{\sin} &= \int_{t_\text{min}}^{t_\text{max}} \epsilon(t)e^{-\Gamma t} \sin(\Delta m t) \,dt\\
    N_{\cos} &= \int_{t_\text{min}}^{t_\text{max}} \epsilon(t)e^{-\Gamma t} \cos(\Delta m t) \,dt

and then we can assign the following normalization to each event:

.. math::
    N_i = N_{\exp} + S \cdot \mathcal{F}_{\!S}(d_i,\omega_i) \cdot N_{\sin} + C \cdot \mathcal{F}_{\!C}(d_i,\omega_i) \cdot N_{\cos},

This is one possible implementation:

.. code-block:: python

    DeltaM = 0.5065      # ps^{-1}, B0 oscillation frequency (PDG)
    Gamma  = 1.0 / 1.52  # ps^{-1}, B0 decay width (PDG lifetime 1.52 ps)
    tmin   = 0.0
    tmax   = float(dfJpsiKS["TAU"].max())

    # Normalization integrals (identical for every event; computed once on a
    # fine grid using the same acceptance that shapes the data)
    t_norm = np.linspace(tmin, tmax, 5000)
    base_decay = np.exp(-Gamma * t_norm) * acceptance(t_norm)
    I_exp = np.trapezoid(base_decay,                           t_norm)
    I_sin = np.trapezoid(base_decay * np.sin(DeltaM * t_norm), t_norm)
    I_cos = np.trapezoid(base_decay * np.cos(DeltaM * t_norm), t_norm)
    # The per-event normalization factorises as
    # N_i = I_exp + S * F_S_i * I_sin + C * F_C_i * I_cos

    # Pre-compute event-level time projections (vectorised, called once)
    t = dfJpsiKS["TAU"].to_numpy(dtype=np.float64)
    F_S = -dec * (1.0 - 2.0 * omega)
    F_C = -F_S
    sin_t = np.sin(DeltaM * t)
    cos_t = np.cos(DeltaM * t)
    # Acceptance is fixed, so we can precompute it as well
    decay_component = acceptance(t) * np.exp(-Gamma * t)

    def nll(S, C):
        # Raw pdf value
        f_i = decay_component * (1.0 + S * F_S * sin_t + C * F_C * cos_t)
        if np.any(f_i <= 0.0):
            return np.inf

        # Compute per-event normalization
        N_i = I_exp + S * F_S * I_sin + C * F_C * I_cos
        if np.any(N_i <= 0.0):
            return np.inf

        return float(-np.sum(np.log(f_i) - np.log(N_i)))

    m = Minuit(nll, S=0.5, C=0.0)
    m.errordef = Minuit.LIKELIHOOD
    m.limits["S"] = (-1.0, 1.0)
    m.limits["C"] = (-1.0, 1.0)
    m.migrad()
    m.hesse()

In this toy example, we get the following result:

.. math::
    S = 0.694 \pm 0.024 \qquad\text{and}\qquad C = 0.010 \pm 0.015

The total script runtime is about 4 seconds.
Like in the real analysis, the measurement of :math:`C` is more precise, due to
the narrower likelihood curvature in this direction, caused by the associated
cosine term and because of the fact that most of the data is concentrated at
low decay times, where the cosine function is still large, and thus provides
more sensitivity.

The full script can be accessed here: :download:`Download JpsiKS fit script <scripts/jpsiks_analysis.py>`.

The measurement of :math:`\Delta m_s` in :math:`B_s^0 \to D_s^-\pi^+` decays as a toy analysis
----------------------------------------------------------------------------------------------
This decay mode offers an excellent environment to measure the :math:`B_s^0`
oscillation frequency :math:`\Delta m_s` as the mode is quite abundant, has a
flavour-specific final state and as of today, no CP violation in the mixing has
been observed, that might complicate the measurement. The fact that the final
state is flavour-specific means that we do not need a separate calibration mode
and can directly calibrate our flavour tagging algorithm on the signal mode. In
fact, in the actual LHCb measurement, the flavour tagging calibration and the
measurement of :math:`\Delta m_s` were performed simultaneously in a single
fit. In this toy example, we will do the same and this time, we will not use
lhcb_ftcalib to calibrate flavour tagging at all, but instead, the decay time
pdf will give us the necessary sensitivity to the calibration parameters, which
will be floated in the fit.

**DATA GENERATION**

We set :math:`\Delta m_s^{\text{true}} = 17.765 \text{ps}^{-1}` for the event generation 
and choose a tagging efficiency of 80% for the tagging algorithm:

.. code-block:: python

   def generate_data(SEED, acceptance):
       # Set true calibration parameters in flavour form
       p0_plus = 0.04
       p1_plus = 0.3
       p0_minus = -0.03
       p1_minus = 0.28
       N = 100000

       # ////////////////////////////////////
       # Generate the signal mode Bs -> Ds Pi
       # ////////////////////////////////////
       calibration = ft.PolynomialCalibration(2, ft.link.mistag)
       genBs2Dspi = ft.ToyGenerator(0, 15, seed=SEED) # ps
       genBs2Dspi.setPhysics(neutral_mode=True, flavour_specific=True, DM=17.765, DG=0.083, S=0, Sbar=0, C=1.0, Cbar=-1.0)
       genBs2Dspi.add_tagger(name    = "ToyTagger",
                      params_plus    = [p0_plus, p1_plus],
                      params_minus   = [p0_minus, p1_minus],
                      eta_shape_func = lambda x: np.exp(-0.5 * ((x - 0.4)/0.03) ** 2),
                      calib_func     = calibration, 
                      efficiency=0.8)
       df = genBs2Dspi.generate(N, acceptance=acceptance)

       # Remove branches we would not have access to in real data
       df.drop(columns=["PROCESS", "FLAV_PROD", "TRUETAU", "FLAV_HYPOT", "ToyTagger_OMEGA"], inplace=True)
       return df

**LIKELIHOOD DEFINITION**

Here, if we insert the values relevant for this decay mode, we find, that the we can write the full rate compactly as

.. math::
    P(t, \Delta m_s, p_0, p_1, \Delta p_0, \Delta p_1 | f, d) \propto \epsilon(t)e^{-\Gamma t} \left\{ \cosh\!\left(\frac{1}{2}\Delta\Gamma t\right) + \mathcal{C} \cdot \mathcal{F}_{\!C}(d, \omega) \cdot\cos(\Delta m_s t)\right\}

Since :math:`C=1` and :math:`\overline{C}=-1` in this mode, the term
:math:`\mathcal{C} \cdot \mathcal{F}_{\!C}(d, \omega)=f\cdot d\cdot(1-2\omega)`
takes on the value :math:`(1-2\omega)` in unmixed decays :math:`B_s^0 \to
D_s^-\pi^+` and :math:`\overline{B}_s^0 \to D_s^+\pi^-` and
:math:`-(1-2\omega)` in mixed decays :math:`B_s^0 \to \overline{B}_s^0 \to
D_s^+\pi^-` and :math:`\overline{B}_s^0 \to B_s^0 \to D_s^-\pi^+`. We define
an event as being mixed, if the tagging decision (production flavour estimate)
is opposite to the decay flavour and unmixed otherwise. The calibration
function is implemented manually as 

.. math::
   \omega(\eta, d, p_0, p_1, \Delta p_0, \Delta p_1) = \eta + \left(p_0+d\frac{\Delta p_0}{2}\right) +  \left(p_1+d\frac{\Delta p_1}{2}\right) \cdot (\eta-\langle\eta\rangle)

Like in the actual analysis, we slightly depart from the traditional definition
of Delta-parameters, and assume that the tag decision represents the production
flavour subsamples. Therefore, delta parameters measure the calibration
difference between events *tagged* 1 or -1, which is a valid alternative choice, 
which is more consistent in this setup. 

**FIT IMPLEMENTATION**

In this implementation, we are using a single tagger and generate no tagging
asymmetries. This fully justifies fitting without untagged events.

.. code-block:: python

    import lhcb_ftcalib as ft
    import matplotlib.pyplot as plt

    DeltaM = 17.765 # ps^-1
    DeltaGamma = 0.083 # ps^-1
    Gamma = 1 / 1.5 # ps^-1
    tmin = 0
    tmax = 15

    def acceptance(t):
        return 2.0 * np.arctan(2.0 * t) / np.pi

    df = generate_data(493874, acceptance)

    average_eta = np.mean(df.ToyTagger_ETA)

    # Linear mistag calibration function
    def omega(eta, d, p0, p1, DP0, DP1):
        omega = eta + p0 + p1 * (eta - average_eta)
        domega = DP0 + DP1 * (eta - average_eta)
        return omega + d * 0.5 * domega

    # Set data masks and shorthands
    dec_global = df.ToyTagger_DEC.to_numpy()

    dilution = lambda omega: 1.0 - 2.0 * omega

    untagged = (dec_global == 0)
    tagged = (dec_global != 0)

    fdecay = df[tagged].FLAV_DECAY.to_numpy()
    dec = df[tagged].ToyTagger_DEC.to_numpy()

    unmixed = (fdecay == dec)
    mixed   = (fdecay != dec)

    t = df[tagged].TAU.to_numpy()
    eta = df[tagged].ToyTagger_ETA.to_numpy()

    # Precompute what we can (everything that does not depend on floating parameters)
    cosh_t = np.cosh(0.5 * DeltaGamma * t)
    decay_component = acceptance(t) * np.exp(-Gamma * t)

    def nll(DeltaMs, p0, p1, DP0, DP1):
        # Compute normalization integrals
        time_int = np.linspace(tmin, tmax, 5000)
        I_base_decay = np.exp(-Gamma * time_int) * acceptance(time_int)
        I_ExpCosh = np.trapezoid(I_base_decay * np.cosh(0.5 * DeltaGamma * time_int), time_int)
        I_ExpCos  = np.trapezoid(I_base_decay * np.cos(DeltaMs * time_int),           time_int)

        # Compute per-event likelihoods
        NLL = np.zeros_like(t)

        cos_t = np.cos(DeltaMs * t)  # cos(DeltaM * t)

        # Compute F_C coefficient
        F_C_coeff = dilution(omega(eta, dec, p0, p1, DP0, DP1))

        # Compute raw likelihoods. cos_t sign encodes mixing state
        NLL[unmixed] = decay_component[unmixed] * (cosh_t[unmixed] + cos_t[unmixed] * F_C_coeff[unmixed])
        NLL[mixed]   = decay_component[mixed]   * (cosh_t[mixed]   - cos_t[mixed]   * F_C_coeff[mixed])
        
        # Normalize the likelihoods
        NLL[unmixed] /= I_ExpCosh + I_ExpCos * F_C_coeff[unmixed]
        NLL[mixed]   /= I_ExpCosh - I_ExpCos * F_C_coeff[mixed]

        if np.any(NLL <= 0.0):
            return np.inf
        
        return float(-np.sum(np.log(NLL)))

    m = Minuit(nll, DeltaMs=17.5, p0=0.0, p1=0.0, DP0=0.0, DP1=0.0)
    m.errordef = Minuit.LIKELIHOOD
    m.limits["DeltaMs"] = (10.0, 25.0)
    m.limits["p0"]  = (-1.0, 1.0)
    m.limits["p1"]  = (-1.0, 1.0)
    m.limits["DP0"] = (-1.0, 1.0)
    m.limits["DP1"] = (-1.0, 1.0)
    m.migrad()
    m.hesse()

    print(m)
    print(f"\nFitted  DeltaMs: {m.values['DeltaMs']:.3f} ps^-1 (Generator value: {DeltaM} ps^-1)")

Our fit gives us the following result:

.. math::
    \Delta m_s &= 17.776 \pm 0.010\,\mathrm{ps}^{-1}\\
    p_0        &= \hphantom{+}0.0038 \pm 0.0025\\
    p_1        &= \hphantom{+}0.30 \pm 0.09\\
    \Delta p_0 &= -0.010 \pm 0.005\\
    \Delta p_1 &= \hphantom{+}0.11 \pm 0.17

after a runtime of about 10s. The values are in good agreement with the
generated values, whereby we should not expect to reconstruct the true
calibration input parameters perfectly with infinite statistics, as the
definition of the Delta parameters is slightly different as mentioned above,
but here they end up being very close to the input.

Finally, we can reproduce the plot showing the exponential decay of the mixed and unmixed components 
in the data. Also, we can plot the untagged data in gray:

.. plot::
   :include-source: false

   import matplotlib.pyplot as plt
   import lhcb_ftcalib as ft
   from iminuit import Minuit

   def generate_data(SEED, acceptance):
       # Set true calibration parameters in flavour form
       p0_plus = 0.04
       p1_plus = 0.3
       p0_minus = -0.03
       p1_minus = 0.28
       N = 100000

       # ////////////////////////////////////
       # Generate the signal mode Bs -> Ds Pi
       # ////////////////////////////////////
       calibration = ft.PolynomialCalibration(2, ft.link.mistag)
       genBs2Dspi = ft.ToyGenerator(0, 15, seed=SEED) # ps
       genBs2Dspi.setPhysics(neutral_mode=True, flavour_specific=True, DM=17.765, DG=0.083, S=0, Sbar=0, C=1.0, Cbar=-1.0)
       genBs2Dspi.add_tagger(name    = "ToyTagger",
                      params_plus    = [p0_plus, p1_plus],
                      params_minus   = [p0_minus, p1_minus],
                      eta_shape_func = lambda x: np.exp(-0.5 * ((x - 0.4)/0.03) ** 2),
                      calib_func     = calibration, 
                      efficiency=0.8)
       df = genBs2Dspi.generate(N, acceptance=acceptance)

       # Remove branches we would not have access to in real data
       df.drop(columns=["PROCESS", "FLAV_PROD", "TRUETAU", "FLAV_HYPOT", "ToyTagger_OMEGA"], inplace=True)
       return df

   DeltaM = 17.765 # ps^-1
   DeltaGamma = 0.083 # ps^-1
   Gamma = 1 / 1.5 # ps^-1
   tmin = 0
   tmax = 15

   def acceptance(t):
       return 2.0 * np.arctan(2.0 * t) / np.pi

   df = generate_data(493874, acceptance)

   average_eta = np.mean(df.ToyTagger_ETA)

   # Simple calibration function
   def omega(eta, d, p0, p1, DP0, DP1):
       omega = eta + p0 + p1 * (eta - average_eta)
       domega = DP0 + DP1 * (eta - average_eta)
       return omega + d * 0.5 * domega

   dec = df.ToyTagger_DEC.to_numpy()

   F_C = lambda d, omega: d * (1.0 - 2.0 * omega)
   dilution = lambda omega: 1.0 - 2.0 * omega

   untagged = (dec == 0)
   tagged = (dec != 0)
   fdecay = df[tagged].FLAV_DECAY.to_numpy()
   dec = df[tagged].ToyTagger_DEC.to_numpy()

   unmixed = (fdecay == dec)
   mixed   = (fdecay != dec)

   t = df[tagged].TAU.to_numpy()
   eta = df[tagged].ToyTagger_ETA.to_numpy()
   # Precompute what we can (does not depend on DeltaMs)
   cosh_t = np.cosh(0.5 * DeltaGamma * t)
   decay_component = acceptance(t) * np.exp(-Gamma * t)

   def nll(DeltaMs, p0, p1, DP0, DP1):
       # Compute normalization integrals
       t_norm = np.linspace(tmin, tmax, 5000)
       I_base_decay = np.exp(-Gamma * t_norm) * acceptance(t_norm)
       I_ExpCosh = np.trapezoid(I_base_decay * np.cosh(0.5 * DeltaGamma * t_norm), t_norm)
       I_ExpCos  = np.trapezoid(I_base_decay * np.cos(DeltaMs * t_norm),           t_norm)

       # Compute per-event likelihoods
       NLL = np.zeros_like(t)
       C = 1.0
       Cbar = -1.0

       cos_t = np.cos(DeltaMs * t)

       # Compute F_C coefficient
       F_C_coeff = dilution(omega(eta, dec, p0, p1, DP0, DP1))

       # Compute raw likelihoods
       NLL[unmixed] = decay_component[unmixed] * (cosh_t[unmixed] + cos_t[unmixed] * F_C_coeff[unmixed])
       NLL[mixed]   = decay_component[mixed]   * (cosh_t[mixed]   - cos_t[mixed]   * F_C_coeff[mixed])
       
       # Normalize the likelihoods
       NLL[unmixed] /= I_ExpCosh + I_ExpCos * F_C_coeff[unmixed]
       NLL[mixed]   /= I_ExpCosh - I_ExpCos * F_C_coeff[mixed]

       if np.any(NLL <= 0.0):
           return np.inf
       
       return float(-np.sum(np.log(NLL)))

   m = Minuit(nll, DeltaMs=17.5, p0=0.0, p1=0.0, DP0=0.0, DP1=0.0)
   m.errordef = Minuit.LIKELIHOOD
   m.limits["DeltaMs"] = (10.0, 25.0)
   m.limits["p0"]  = (-1.0, 1.0)
   m.limits["p1"]  = (-1.0, 1.0)
   m.limits["DP0"] = (-1.0, 1.0)
   m.limits["DP1"] = (-1.0, 1.0)
   m.migrad()
   m.hesse()

   print(m)
   print(f"\nFitted  DeltaMs: {m.values['DeltaMs']:.3f} ps^-1 (true value: {DeltaM} ps^-1)")

   tau_tagged   = t  # save tagged-only tau before overwriting with plot range
   t = np.linspace(0, 8, 1000)
   nbins = 200
   curve_mixed = acceptance(t) * np.exp(-Gamma * t) * (np.cosh(0.5 * DeltaGamma * t) - np.cos(m.values['DeltaMs'] * t) * dilution(omega(average_eta, 0, m.values['p0'], m.values['p1'], m.values['DP0'], m.values['DP1'])))
   curve_unmixed = acceptance(t) * np.exp(-Gamma * t) * (np.cosh(0.5 * DeltaGamma * t) + np.cos(m.values['DeltaMs'] * t) * dilution(omega(average_eta, 0, m.values['p0'], m.values['p1'], m.values['DP0'], m.values['DP1'])))
   curve_untagged = acceptance(t) * np.exp(-Gamma * t) * np.cosh(0.5 * DeltaGamma * t)

   bins_mixed,    edges_mixed    = np.histogram(tau_tagged[mixed],            bins=nbins, range=(0, 8))
   bins_unmixed,  edges_unmixed  = np.histogram(tau_tagged[unmixed],          bins=nbins, range=(0, 8))
   bins_untagged, edges_untagged = np.histogram(df.TAU.to_numpy()[untagged],  bins=nbins, range=(0, 8))

   fig, ax = plt.subplots(1, 1, figsize=(10, 6))
   bin_width = edges_mixed[1] - edges_mixed[0]
   ax.errorbar(0.5 * (edges_mixed[1:] + edges_mixed[:-1]), bins_mixed, yerr=np.sqrt(bins_mixed), xerr=bin_width/2, fmt='.', label='mixed', color='red', markersize=1, elinewidth=0.5)
   ax.errorbar(0.5 * (edges_unmixed[1:] + edges_unmixed[:-1]), bins_unmixed, yerr=np.sqrt(bins_unmixed), xerr=bin_width/2, fmt='.', label='unmixed', color='blue', markersize=1, elinewidth=0.5)
   ax.errorbar(0.5 * (edges_untagged[1:] + edges_untagged[:-1]), bins_untagged, yerr=np.sqrt(bins_untagged), xerr=bin_width/2, fmt='.', label='untagged', color='gray', markersize=1, elinewidth=0.5)

   n_mixed   = np.sum(mixed)
   n_unmixed = np.sum(unmixed)
   n_untagged = np.sum(untagged)
   integral_mixed   = np.trapezoid(curve_mixed,   t)
   integral_unmixed = np.trapezoid(curve_unmixed, t)
   integral_untagged = np.trapezoid(curve_untagged, t)
   ax.plot(t, curve_mixed   * n_mixed   * bin_width / integral_mixed,   label='Fit (mixed)',   color='red',  linewidth=1, alpha=0.5)
   ax.plot(t, curve_unmixed * n_unmixed * bin_width / integral_unmixed, label='Fit (unmixed)', color='blue', linewidth=1, alpha=0.5)
   ax.plot(t, curve_untagged * n_untagged * bin_width / integral_untagged, label='Untagged', color='gray', linewidth=1, alpha=0.5)

   # Add a plot in the plot showing a zoomed in view
   axins = ax.inset_axes([0.45, 0.38, 0.50, 0.55])
   axins.errorbar(0.5 * (edges_mixed[1:] + edges_mixed[:-1]), bins_mixed,
                  yerr=np.sqrt(bins_mixed), xerr=bin_width/2,
                  fmt='.', color='red', markersize=2, elinewidth=1)
   axins.errorbar(0.5 * (edges_unmixed[1:] + edges_unmixed[:-1]), bins_unmixed,
                  yerr=np.sqrt(bins_unmixed), xerr=bin_width/2,
                  fmt='.', color='blue', markersize=2, elinewidth=1)
   axins.plot(t, curve_mixed   * n_mixed   * bin_width / integral_mixed,   color='red',  linewidth=1, alpha=0.5)
   axins.plot(t, curve_unmixed * n_unmixed * bin_width / integral_unmixed, color='blue', linewidth=1, alpha=0.5)
   axins.set_xlim(1, 3)
   axins.set_ylim(100, 800)
   axins.set_xlabel("$t$ [ps]", loc="right")
   ax.set_xlabel("$t$ [ps]", loc="right")
   ax.set_ylabel("Decays / 0.04 ps", loc="top")

   ax.legend(loc='lower center', bbox_to_anchor=(0.5, 1.02), ncols=3, borderaxespad=0)
   ax.set_xlim(0, 8)
   ax.set_ylim(bottom=0)
   plt.savefig("TEST.pdf", bbox_inches='tight')


Note, that the oscillations are nicely visible, but they do not reach the
x-Axis, as we might naively expect when we compare with the decay
distribution shown in the previous chapters, where decay time generation was
motivated. The reason is, that we are using tagging information with mistag
estimates, which predict the tag correctness. Whenever we mis-tag an event,
we lose some resolution and the curve resembles the untagged decay more
closely.

The full script can be accessed here: :download:`Download Bs2Dspi fit script <scripts/dms_analysis.py>`.
