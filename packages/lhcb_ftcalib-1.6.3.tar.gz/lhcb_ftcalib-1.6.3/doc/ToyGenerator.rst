Toy Data Generator
==================

The ``toy_generator`` module provides a physics-accurate toy Monte Carlo
generator for flavour-tagged B-meson decays.  It samples decay times from the
full time-dependent differential decay rates — including CP violation,
production and detection asymmetries, decay-time acceptance, and
:math:`\Delta\Gamma` effects.

The module exposes three public classes:

* :class:`~lhcb_ftcalib.toy_generator.DistributionSampler` — a lightweight sampler for arbitrary
  numerical probability distributions, used internally to sample decay times
  and mistag distributions.
* :class:`~lhcb_ftcalib.ToyGenerator` — the main generator with a builder-style API.
* :class:`~lhcb_ftcalib.MultiComponentToyGenerator` — a wrapper around multiple :class:`~lhcb_ftcalib.ToyGenerator` instances to
  generate mixtures of different decay modes or background contributions in a single dataset.

Output columns produced by :meth:`~lhcb_ftcalib.ToyGenerator.generate`
----------------------------------------------------------------------

* **PROCESS** – Integer code of the physical decay process (see :class:`ToyGenerator.Process`).
    * 1 = :math:`B \to f`,
    * 2 = :math:`\bar{B} \to f`,
    * 3 = :math:`B \to \bar{f}`,
    * 4 = :math:`\bar{B} \to \bar{f}`.
* **FLAV_PROD** – True production flavour (``+1`` = :math:`B^0_q/B^+`, ``-1`` = :math:`\overline{B}^0_q/B^-`).
* **FLAV_DECAY** – True decay flavour.  For oscillating modes (``neutral_mode=True``) 
  this is ``+1`` for decays to :math:`f` and ``-1`` for
  decays to :math:`\bar{f}`.  For non-oscillating modes (``neutral_mode=False``) it
  equals ``FLAV_PROD`` because there is no mixing.
* **FLAV_HYPOT** – Production-flavour hypothesis derived from the decay
  flavour and decay time via the mixing asymmetry.  Equals ``FLAV_PROD``
  for non-oscillating modes. :math:`f_\text{hypot} = f_\text{decay} \times \mathrm{sign}(\cos(\Delta m_q \cdot t))` for oscillating modes.
* **TRUETAU** – Reconstructed true decay time in ps.
* **TAU** – Reconstructed decay time in ps
* **TAUERR** – Generated if ``tau_error_falloff`` is set. TAU distribution
    is smeared by gaussian kernels using TAUERR values as sigma. Be aware, that
    if TAUERR was generated, it should be used in the tagger calibration.
    Otherwise, the fit will underestimate the mistag uncertainty and
    input calibration parameters will not be reproduced in the fit results.
* **eventNumber** – Sequential event index assigned before shuffling; useful as a reproducible selection mask.
* **<name>_ETA** – Raw mistag estimate for each registered tagger.
* **<name>_OMEGA** – Calibrated mistag for each registered tagger.
* **<name>_DEC** – Tagging decision (``+1``, ``0`` or ``-1``) for each registered tagger.

Example: CP-eigenstate decay (e.g. B → J/psi KS)
-------------------------------------------------

.. code-block:: python

    import lhcb_ftcalib as ft

    # Generate B0 → J/psi KS-like decay
    gen = ft.ToyGenerator(tmin=0.3, tmax=15.0, seed=42)
    gen.setPhysics(neutral_mode=True, flavour_specific=False, S=0.7, C=0.0, DM=0.5065)

    gen.add_tagger(
        name           = "OSKaon",
        params_plus    = [0.03, 0.2], # p_0^+ and p_1^+
        params_minus   = [0.05, 0.25], # p_0^- and p_1^-
        eta_shape_func = lambda eta: np.exp(-0.5 * ((x - 0.3) / 0.05) ** 2) + np.exp(0.6*x)-1
        calib_func     = ft.PolynomialCalibration(2, ft.link.logit),
    )

    df = gen.generate(N=50_000, tau_error_falloff=1/0.045, acceptance="arctan")

Example: Flavour-specific decay (e.g. B → J/psi K*)
----------------------------------------------------

.. code-block:: python

    import lhcb_ftcalib as ft
    import numpy as np

    gen = ft.ToyGenerator(tmin=0.3, tmax=15.0, seed=42)
    gen.setPhysics(neutral_mode=True, flavour_specific=True, DM=0.5065, C=1, Cbar=-1, S=0, Sbar=0)

    gen.add_tagger(
        name           = "OSKaon",
        params_plus    = [0.03, 0.2], # p_0^+ and p_1^+
        params_minus   = [0.05, 0.25], # p_0^- and p_1^-
        eta_shape_func = lambda eta: np.exp(-0.5 * ((x - 0.3) / 0.05) ** 2) + np.exp(0.6*x)-1
        calib_func     = ft.PolynomialCalibration(2, ft.link.logit),
    )

    df = gen.generate(N=50_000, tau_error_falloff=1/0.045, acceptance=lambda t: 2*np.arctan(2*t)/np.pi)

API reference
-------------

.. autoclass:: lhcb_ftcalib.toy_generator.DistributionSampler
   :members:
   :special-members: __call__

.. autoclass:: lhcb_ftcalib.ToyGenerator
   :members:
   :undoc-members:
   :exclude-members: ToyTagger, Process, fProd

.. autoclass:: lhcb_ftcalib.MultiComponentToyGenerator
   :members:
   :undoc-members:
