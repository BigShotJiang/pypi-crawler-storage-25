# Configuration file for the Sphinx documentation builder.
#
# This file only contains a selection of the most common options. For a full
# list see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Path setup --------------------------------------------------------------

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.
#
import os
import sys
import datetime
sys.path.insert(0, os.path.abspath('../src/lhcb_ftcalib'))
sys.path.insert(0, os.path.abspath('../src'))
sys.path.insert(0, os.path.abspath('..'))
sys.path.insert(0, os.path.abspath('.'))

from _version import __version__

# -- Project information -----------------------------------------------------
thisyear = f"{datetime.datetime.now().year}"
project = 'lhcb_ftcalib'
copyright = f'{thisyear}, LHCb Collaboration'
author = 'Vukan Jevtic'

# The full version, including alpha/beta/rc tags
release = __version__
version = __version__

# -- General configuration ---------------------------------------------------

# Add any Sphinx extension module names here, as strings. They can be
# extensions coming with Sphinx (named 'sphinx.ext.*') or your custom
# ones.
extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.mathjax",
    "matplotlib.sphinxext.plot_directive"
]
mathjax3_config = {
    "tex": {
        "tags" : "ams",
        "tagSide" : "right",
        "tagIndent" : "0em"
    }
}   
imgmath_latex_preamble = r"\usepackage{amsmath}"

# Use makeindex instead of xindy (xindy requires libcrypt.so.1 which may be unavailable)
latex_use_xindy = False
latex_elements = {
    "figure_align": "H",
}

# Disable alphabetical ordering
autodoc_member_order = "bysource"

# Break long signatures into one parameter per line
maximum_signature_line_length = 80

# Render type aliases by name instead of expanding them
autodoc_type_aliases = {
    "NPArrayFloat":    "NPArrayFloat",
    "NPArrayBool":     "NPArrayBool",
    "NPArrayInt":      "NPArrayInt",
    "NPArrayOrPandas": "NPArrayOrPandasSeries",
    "NPArrayOrScalar": "NPArrayOrScalar",
    "NPMatrix":        "NPMatrix",
}

# Add any paths that contain templates here, relative to this directory.
templates_path = ['_templates']

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store']


# -- Options for HTML output -------------------------------------------------

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.
#
html_theme = 'furo'
html_theme_options = {
    'navigation_with_keys': True,
}


# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
# html_static_path = ['_static']
html_static_path = ['_static']
# html_css_files = ['custom.css']
