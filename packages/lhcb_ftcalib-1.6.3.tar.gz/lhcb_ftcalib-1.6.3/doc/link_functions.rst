Link functions
==============
Non-linear link functions can improve fitting quality and ensures that mistags
stay in their physical range after the calibration.

.. plot::
   :include-source: false

   import numpy as np
   import matplotlib.pyplot as plt
   from lhcb_ftcalib import link

   eta_full = np.linspace(0.01, 0.99, 500)
   eta_restr = np.linspace(0.01, 0.499, 500)

   full_links   = [(link.logit,   r"logit",   "C0"),
                   (link.probit,  r"probit",  "C1"),
                   (link.cauchit, r"cauchit", "C2")]
   fig, ax1 = plt.subplots(1, 1, figsize=(5, 5))

   for lf, label, color in full_links:
       ax1.plot(eta_full, lf.L(eta_full), label=label, color=color)
   ax1.axhline(0, color="k", linewidth=0.6, linestyle="--")
   ax1.axvline(0.5, color="k", linewidth=0.6, linestyle=":")
   ax1.set_xlim(0, 0.5)
   ax1.set_ylim(0, 10)
   ax1.set_xlabel(r"$\eta$")
   ax1.set_ylabel(r"$g(\eta)$")
   ax1.set_title("Link functions")
   ax1.legend()

   fig.tight_layout()

.. automodule:: lhcb_ftcalib.link_functions
   :members:
   :undoc-members:
   :show-inheritance:
