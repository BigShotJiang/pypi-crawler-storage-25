Comparing calibration results to the EPM
========================================
``lhcb-ftcalib`` uses mostly the same conventions for the flavour tagging
likelihood and performance numbers as the former EspressoPerformanceMonitor. 
Results obtained with ftcalib should be exactly equal to those obtained with the EPM with some 
caveats outlined in this section.

The EPM uses now outdated physics constants which can be easily set in ftcalib to the old values:

.. code-block:: python

   import lhcb_ftcalib as ft

   # Enforcing exact EPM compatibility 
   ft.constants.DeltaM_d = 0.51
   ft.constants.DeltaM_s = 17.761
   ft.constants.DeltaGamma_d = 0
   ft.constants.DeltaGamma_s = 0.0913
   ft.constants.ignore_mistag_asymmetry_for_apply = True  # Should be the default anyway
   ft.constants.CovarianceCorrectionMethod = "SquaredHesse" # Should be the default anyway

   # Continue with calibrations...

.. warning::
   The name of a combined tagger branch in ``lhcb-ftcalib`` is always ``XYZ_ETA`` which
   differs w.r.t. the EspressoPerformanceMonitor where a combined branch is named ``XYZ_OMEGA``.
   The reasoning behind this change is that a combined tagging decision normally still needs
   to be calibrated and is therefore usually treated as a raw tagging decision.
  

Remaining differences can be attributed to rounding imprecision as the
EspressoPerformanceMonitor and ftcalib use very different routines to sum and
multiply the provided data and the order in which the data are processed
differs significanly.

It is ensured that ``lhcb-ftcalib`` and the EspressoPerformanceMonitor give
compatible results through unit tests where the output of both programs for the
same data is compared.

