GLM Calibration Functions
=========================
This chapter is intended to answer some common questions about Flavour Tagging
calibration functions, and give some insight into why they are defined as they
are. It aims at answering the following exemplary questions among others:

* Why is the average mistag always being subtracted from the mistag, :math:`\eta-\langle\eta\rangle`?
* Why are :math:`p_0` and :math:`p_1` close to zero in ftcalib for the linear calibration, even though the function is almost the identity function?
* Why is :math:`\omega(\eta)=p_0+p_1(\eta-\langle\eta\rangle)+p_2(\eta-\langle\eta\rangle)^2` not the optimal second degree calibration model?
* How do I write the formula of my higher-order calibration function in my thesis?
* What are link functions for?

Introduction
------------

The aim of FT calibrations is simple: Given a dataset of mistags
:math:`\eta_i\in[0,\frac{1}{2}]` 
we need to fit some model 
:math:`\omega(\eta, p_0, p_1, \cdots)=\omega(\eta, \vec{p})` 
which maximizes the Flavour Tagging
likelihood for some optimal parameter set :math:`\vec{p}`:

.. math::
    \displaystyle \mathcal{L}(\vec{p})=\prod_{i=0}^N \delta_{f,-d}\omega(\eta_i,\vec{p}) + \delta_{f,d} (1-\omega(\eta_i,\vec{p})),

where :math:`f` is the production flavour hypothesis and :math:`d` is the
tagging decision. Here, really, any capable function :math:`\omega` would do,
but we will look in the following at the polynomial calibrations, expressed in
powers of the mistag, as this is the most straightforward and common
calibration type. 

The simplest choice for a polynomial calibration function is the one given by
the *monomial basis coefficients* :math:`\{1,\eta,\eta^2,\ldots,\eta^m\}` up to some chosen order :math:`m`:

.. math::
   :label: monomialmodel

   \omega(\eta,\vec{p})=\sum_{j=0}^m p_j\eta^j,

and while this model could describe our data accurately, the fit parameters :math:`p_j`
will be highly correlated in general. For a generalized linear model (GLM), of
which Eq. :eq:`monomialmodel` is an example, the covariance matrix of the
calibration parameters is proportional to

.. math::
    \mathrm{Cov}(\vec{p}\vert X)\propto(X^\top X)^{-1}

with :math:`X` being the chosen design matrix of the form

.. math::
    X = \begin{bmatrix}
        1& \eta_1& \eta_1^2& \cdots\\
        1& \eta_2& \eta_2^2& \cdots\\
        1& \eta_3& \eta_3^2& \cdots\\
        \vdots & \vdots & \vdots & \ddots
    \end{bmatrix}\in \mathbb{R}^{N\times m}

(in the monomial basis) for :math:`N` data points and :math:`m` calibration
parameters. This gives us 

.. math::
    :label: monomial_moments

    X^\top X=
    \begin{bmatrix}
    N & \sum_i \eta_i & \sum_i \eta_i^2 & \cdots\\
    \sum_i \eta_i & \sum_i \eta_i^2 & \sum_i\eta_i^3 & \cdots\\
    \sum_i \eta_i^2 & \sum_i \eta_i^3 & \sum_i \eta_i^4 & \cdots\\
    \vdots &  \vdots &  \vdots & \ddots
    \end{bmatrix}\in \mathbb{R}^{m\times m}

for the monomial basis. Observe that the off-diagonal elements are large in
general, and this will in general be true after matrix inversion. Thus,
correlations will in general be arbitrarily large between any two calibration
parameters, depending on the data. In the following subsections, we will derive
a more suitable basis for polynomial calibrations in which the calibration
parameters are uncorrelated.

It should be noted that in this chapter the use of Generalized Linear Models
(GLM) is motivated as they seem like a solid foundation for stable and
interpretable calibrations, but we will not develop the full theory as plenty
literature is available on this topic. Choosing to work in a space of
orthogonal functions, like specific polynomials, to decorrelate the parameters
of the GLM is an arbitrary choice which is not strictly required by the
standard GLM literature, but which should give great benefit in practice: It
practically allows us to safely ignore parameter correlation terms when this
model is applied to data and it allows us to interpret the calibration
parameters in a natural way: If parameter :math:`p_i` is compatible with zero, the
corresponding basis function term is not needed to describe the data and we can
very likely choose :math:`m<i` for a simpler model of our data.

.. warning::
   In the GLM literature, symbols like :math:`\eta` are practically reserved
   and have a different meaning, while here, it is the mistag probability,
   which could be confusing for readers familiar with this topic. Furthermore,
   as will be mentioned in the corresponding chapter, the application of link
   functions works a bit differently in the GLM literature, but the coice that
   was historically made for Flavour Tagging is fully valid and is still
   covered by GLM.

Linear calibrations
-------------------

In the case  of linear calibrations where the calibration function is given by
:math:`\omega(\eta)=p_0+p_1\eta`, we can estimate the covariance matrix as outlined before 

.. math::
    \mathrm{Cov}(\vec{p})  \propto (X^\top X)^{-1}
    =\begin{bmatrix}
        N & \sum_i\eta_i \\ \sum_i\eta_i & \sum_i\eta_i^2
    \end{bmatrix}^{-1} 
    =\frac{1}{N\sum_i\eta_i^2-(\sum_i\eta_i)^2}\begin{bmatrix}
        \sum_i\eta_i^2 & -\sum_i\eta_i \\ -\sum_i\eta_i & N
    \end{bmatrix}

and we see that the correlation (and the covariance) between :math:`p_0` and :math:`p_1` is proportional to

.. math::
    \mathrm{corr}(p_0, p_1)\propto -\frac{\sum_i^N\eta_i}{N\sum_i\eta_i^2-(\sum_i\eta_i)^2}

Ideally, we would want this term to be zero and can achieve this by transforming the
coordinate :math:`\eta\mapsto\eta - \langle\eta\rangle` such that the sum of
mistags is zero on average in the numerator. Here, :math:`\langle\eta\rangle` is the average
(weighted) mistag :math:`\langle\eta\rangle=\sum_i\eta_iw_i/\sum_iw_i`. We therefore obtain our classic, average-eta-subtracted form
of the calibration function

.. math::
    \omega(\eta)=p_0+p_1(\eta-\langle\eta\rangle)

which is often shown in publications and where :math:`p_0` and :math:`p_1` are
indeed uncorrelated.

Quadratic calibrations
----------------------
In the case of quadratic calibrations, if we again naively assume the monomial
basis :math:`\{1,\eta,\eta^2\}=\{P_0,P_1,P_2\}`, we
have 

.. math::
    \mathrm{Cov}(p_0,p_1,p_2)\propto (X^\top X)^{-1}=\begin{pmatrix}
        N & \color{red}\sum_i\eta_i & \color{red}\sum_i\eta_i^2 \\
        \color{red}\sum_i\eta_i & \sum_i\eta_i^2 & \color{red}\sum_i\eta_i^3 \\
        \color{red}\sum_i\eta_i^2 & \color{red}\sum_i\eta_i^3 & \sum_i\eta_i^4 \\
    \end{pmatrix}^{-1}.

We can already see that to find a suitable transformation, i.e., a new basis of
some kind, in which
:math:`\mathrm{corr}(p_0,p_1)=\mathrm{corr}(p_1,p_2)=\mathrm{corr}(p_0,p_2)=0`,
we will need to find an elaborate transformation in which the highlighted
terms, vanish. This is a futile task in guessing, and therefore, we develop a
more systematic way to find such a transformation, using a proper
orthogonalization algorithm. For linear calibration models, we could say that
we found that a simple basis transformation :math:`B` of the form

.. math::
    \underbrace{
    \begin{bmatrix}
        1 & 0 \\ -\langle\eta\rangle & 1
    \end{bmatrix}}_{B}
    \begin{bmatrix}
        1 \\ \eta
    \end{bmatrix}=
    \begin{bmatrix}
        1 \\ \eta-\langle\eta\rangle
    \end{bmatrix}=
    \begin{bmatrix}
        \hat{P}_0(\eta) \\ \hat{P}_1(\eta)
    \end{bmatrix}

has given us a calibration function with uncorrelated parameters. We can
therefore reexpress our linear calibration function as 

.. math::
    \omega(\eta)=\sum_{j=0}^1p_j\hat{P}_j(\eta) = p_0 + p_1(\eta - \langle\eta\rangle).

This expression almost has the form of a GLM as it is sometimes used in the literature, where it
is often given as

.. math::
    \omega(\eta)=\eta + \sum_jp_j\hat{P}_j(\eta)

instead. The reason for adding :math:`\eta` to the function turns out to be quite useful, 
as something interesting happens if we do that:

.. math::
    :nowrap:

    \begin{align*}
    \omega(\eta) &= \eta + p_0 + p_1(\eta - \langle\eta\rangle) \\
                 &= \eta + p_0 + p_1(\eta - \langle\eta\rangle) + \langle\eta\rangle - \langle\eta\rangle \\
                 &= \underbrace{p_0 + \langle\eta\rangle}_{\tilde{p_0}} + \underbrace{(1 + p_1)}_{\tilde{p_1}}(\eta - \langle\eta\rangle).
    \end{align*}

By adding an offset of :math:`\eta`, we therefore obtain effectively the same
linear function, defined by two effective parameters :math:`\tilde{p_0}` and
:math:`\tilde{p_1}` that are still uncorrelated for the reason given above,
which is no big surprise. But now, the meaning of :math:`p_0` and :math:`p_1`
has changed, since now the identity is obtained if :math:`p_0=p_1=p_i=0`. This is
the convention used by ftcalib, and it is arguably the best. It is easy to
convince oneself that this holds for calibrations of arbitrary polynomial order
and thus :math:`p_i=0` *always* corresponds to the identity calibration
:math:`\omega(\eta)=\eta`, no matter what link function or polynomial order was
used.

To continue now with the quadratic calibration function case, we again need to find a matrix
:math:`\mathbf{B}` to transform the monomial basis into a basis of new polynomials
:math:`\hat{P}_i(\eta)=\sum_{j=0}^m B_{ij}\eta^j` such that an orthogonal basis
representation is obtained:

.. math::
    \begin{bmatrix}
        a & 0 & 0 \\ b & c & 0 \\ d & e & f
    \end{bmatrix}
    \begin{bmatrix}
        1 \\ \eta \\ \eta^2
    \end{bmatrix}=
    \begin{bmatrix}
        \hat{P}_0(\eta) \\ \hat{P}_1(\eta) \\ \hat{P}_2(\eta)
    \end{bmatrix}

such that the covariance matrix, in analogy to :eq:`monomial_moments`

.. math::
    \mathrm{Cov}(p_0,p_1,p_2)\propto (X^\top X)^{-1}=\begin{pmatrix}
        \langle \hat{P}_0,\hat{P}_0\rangle & \langle \hat{P}_0,\hat{P}_1\rangle & \langle \hat{P}_0,\hat{P}_2\rangle \\
        \langle \hat{P}_1,\hat{P}_0\rangle & \langle \hat{P}_1,\hat{P}_1\rangle & \langle \hat{P}_1,\hat{P}_2\rangle \\
        \langle \hat{P}_2,\hat{P}_0\rangle & \langle \hat{P}_2,\hat{P}_1\rangle & \langle \hat{P}_2,\hat{P}_2\rangle \\
    \end{pmatrix}^{-1}

that is proportional to products of polynomials :math:`\langle P_i,P_j\rangle` is diagonal.
This is equivalent to finding a basis in which all calibration parameters are
uncorrelated. If we consider the fact that :math:`X^\top X` always has a
non-vanishing diagonal, its inverse can only be diagonal if :math:`X^\top X` is
diagonal in the first place. A suitable polynomial basis is therefore found if
:math:`\langle P_i,P_j\rangle=0` for :math:`i\neq j`. The inner product is
hereby defined as

.. math::
    \langle P_i,P_j\rangle = \sum_{k=0}^N P_i(\eta_k)P_j(\eta_k)

as before. Unsurprisingly, orthogonalization with Gram-Schmidt is exactly what
needs to be used in the following, as what we need to find is an orthogonal set
of :math:`\hat{P}_j(\eta)` basis vectors.

As is customary, we start with our non-orthogonal vectors
:math:`\{P_0,P_1,P_2\}=\{1,\eta,\eta^2\}` and we set :math:`\hat{P}_0=1`, and
successively subtract projections from our basis vectors according to the
familiar algorithm

.. math::
    :nowrap:

    \begin{align*}
    \hat{P}_1 &= P_1 - \frac{\langle \hat{P}_0,P_1\rangle}{\langle \hat{P}_0,\hat{P}_0\rangle} \hat{P}_0 \\
              &= \eta-\frac{\sum_i^N 1\cdot \eta_i}{N}\cdot 1=\eta - \langle\eta\rangle
    \end{align*}

our linear result! We continue

.. math::
    :nowrap:

    \begin{align*}
    \hat{P}_2 &= P_2 - \frac{\langle\hat{P}_0,P_2\rangle}{\langle\hat{P}_0,\hat{P}_0\rangle}\hat{P}_0
                     - \frac{\langle\hat{P}_1,P_2\rangle}{\langle\hat{P_1},\hat{P_1}\rangle}\hat{P}_1 \\
              &= \eta^2-\frac{\sum_i^N 1\cdot\eta_i^2}{N}\cdot 1-\frac{\sum_i^N(\eta_i-\langle\eta\rangle)\eta_i^2}{\sum_i^N(\eta_i-\langle\eta\rangle)^2}(\eta-\langle\eta\rangle) \\
              &= \eta^2-\langle\eta^2\rangle-\frac{\langle\eta^3\rangle-\langle\eta\rangle\langle\eta^2\rangle}{\langle\eta^2\rangle-\langle\eta\rangle^2}(\eta-\langle\eta\rangle)
    \end{align*}

Thus, we can write the quadratic calibration function that gives us
uncorrelated calibration parameters as

.. math::
    :nowrap:

    \begin{align*}
        \omega(\eta,p_0,p_1,p_2) &= \eta + \sum_{j=0}^2p_j\hat{P}_j(\eta) \\
                            &= p_0 + \langle\eta\rangle \\
                            &+ (1 + p_1)(\eta-\langle\eta\rangle) \\
                            &+ p_2 \left(\eta^2-\frac{\langle\eta^3\rangle-\langle\eta\rangle\langle\eta^2\rangle}{\langle\eta^2\rangle-\langle\eta\rangle^2}(\eta-\langle\eta\rangle)
                                           -\langle\eta^2\rangle\right)
    \end{align*}

In ftcalib, this calculation is not performed analytically, but numerically
using the modified Gram-Schmidt algorithm, which is a very quick procedure when working with numerical data.

Optimized algorithm
-------------------
Since we always orthogonalize the monomial basis, we end up estimating the
moment averages of the mistags :math:`\langle\eta^n\rangle` quite often, which
is why we can define a simpler algorithm where these moments are precomputed.
By defining a symmetric moment-lookup matrix
:math:`M_{ij}=\langle\eta^{i+j}\rangle`, the following compact procedure is
equivalent to the one outlined above, but faster to compute and numerically
more stable ("Modified" Gram-Schmidt, or MGS). As a result, the scalar product
becomes very cheap to compute:

1. Initialize :math:`\mathbf{B}=\mathbb{1}` and precompute :math:`M_{ij}=\langle\eta^{i+j}\rangle`.
2. For each row :math:`B_i` in :math:`B`
    1. :math:`B_i = \frac{B_i}{\sqrt{\langle\hat{P}_i,\hat{P}_i\rangle}}\quad` with :math:`\quad\langle\hat{P}_i,\hat{P}_j\rangle \equiv \displaystyle\sum_{k,l} B_{ik}B_{jl}M_{kl}`
    2. For each row :math:`j` with :math:`j>i`
        1. :math:`B_j = B_j - B_i\langle\hat{P}_i,\hat{P}_j\rangle\quad`

Finally, the basis is orthonormalized by reapplying step 2.1 to each row again
and an identical result is obtained as before.

Link functions
--------------
A "link function" can be added to the definition of a GLM to ensure that the
output of the calibration function is always in the desired range, e.g.,
:math:`[0,\frac{1}{2}]` for mistag probabilities (or slightly above
:math:`\frac{1}{2}` but certainly not :math:`<0`) by effectively optimizing the
model in a transformed parameter space. In addition, it can improve the fit
quality by introducing additional model precision. With some given link
function :math:`g`, the calibration function is defined as

.. math::
    \omega(\eta) = g^{-1\!}\left(g(\eta)+\sum_{j=0}^m p_j\hat{P}_j(g(\eta))\right),

where :math:`g^{-1}` is the inverse of the link function. Nothing about this
calibration function is different from the previous case, except that the
mistags are transformed first by the link function. Notably, even by adding a
link function, the calibration remains linear in the calibration parameters
:math:`p_j`, but to ensure zero correlation, a change is needed in the
orthogonalization procedure. To be precise, the parameter covariance of a GLM
is not proportional to :math:`(X^\top X)^{-1}` as stated before, *not even in
the case of an identity link*, but to the inverse Fisher information matrix
:math:`(X^\top W X)^{-1}=\mathcal{I}(\vec{p})^{-1}` with some weight matrix :math:`W` 
specific to the link function and the likelihood.

.. warning::
   Here, the link function is evidently applied to the mistag before the polynomial
   basis is evaluated, which means that the initial basis functions are 
   defined here in the space transformed by :math:`g`: :math:`\{1, g(\eta),
   g(\eta)^2, \cdots\}`, and not in the original mistag space. This choice of 
   initial basis does not affect GLM properties at all. We do this so 
   that the GLM remains interpretable. In the literature, this form of a
   GLM is more likely to be found:

   .. math::
       \omega(\eta) = g^{-1\!}\left(\eta+\sum_{j=0}^m p_j\hat{P}_j(\eta)\right).

   or even more compactly as :math:`g(\omega_i)=\vec{P}(\eta_i)^\top\vec{p}` (in standard notation this would be :math:`g(\mu_i)=x_i^\top\vec{\beta}`).

The most common link function for FT calibrations is the negated logistic
function :math:`\mathrm{logit}(\eta)=\log(1-\eta)-\log(\eta)`, which maps the interval :math:`[0,\frac{1}{2}]` to :math:`[+\infty, 0]`.
Its inverse is the (negated) sigmoid function.

.. math::
   g(x) =\log\left(\frac{1-x}{x}\right),  \quad 
   g^{-1}(x) = \frac{1}{1 + e^{x}}.

The orthogonalization procedure is modified by introducing Fisher information
weights in the scalar products between polynomials. For the optimized MGS
algorithm, this amounts to simply changing the moment average computation to
this form:

.. math::
    \langle\eta^n\rangle \equiv \frac{1}{\sum_iw_i}\displaystyle\sum_i^N \frac{w_ig(\eta_i)^n}{\eta_i(1-\eta_i)\left[\frac{\partial}{\partial \eta} g(\eta_i)\right]^2}.

This way, the Fisher information matrix is diagonalized by the Gram-Schmidt
algorithm and the calibration parameters are uncorrelated. With this change,
the rest of the procedure remains untouched.

.. raw:: html

   <details>
   <summary><strong>Derivation of the Fisher information weight</strong></summary>
   <br>

Fisher information weights are needed to ensure calibration parameters remain
uncorrelated in the presence of a non-identity link function. This condition requires the
Fisher information matrix to be diagonal through a correct choice of weight
terms.

With a link function :math:`g`, the calibration function is

.. math::
    \omega(\eta) = g^{-1}\!\left(g(\eta) + \sum_j p_j\hat{P}_j(g(\eta))\right).

A single tagged event is a binary Bernoulli outcome — the tagger is either
correct (:math:`x=1`) or wrong (:math:`x=0`). The single-event log-likelihood is

.. math::
    \log L = (1-x)\log\omega + x\log(1-\omega).

The Fisher information matrix is the negative expected Hessian of the
log-likelihood:

.. math::
    I_{jk} = -\mathbb{E}\!\left[\frac{\partial^2\log L}{\partial p_j\,\partial p_k}\right].

Since :math:`\log L` depends on :math:`p_j` only through :math:`\omega(\eta;\mathbf{p})`,
the chain rule gives

.. math::
    \frac{\partial^2\log L}{\partial p_j\,\partial p_k}
        = \frac{\partial^2\log L}{\partial\omega^2}\,\frac{\partial\omega}{\partial p_j}\frac{\partial\omega}{\partial p_k}
        + \underbrace{\frac{\partial\log L}{\partial\omega}\,\frac{\partial^2\omega}{\partial p_j\,\partial p_k}}_{=0}.

The second term vanishes because at the parameter optimum :math:`\mathbb{E}[\partial\log L/\partial\omega]=0`. 
The derivative w.r.t. :math:`\omega` yields a likelihood-specific weight contribution:

.. math::
    -\mathbb{E}\!\left[\frac{\partial^2\log L}{\partial\omega^2}\right]
      = -\frac{1-\mathbb{E}[x]}{\omega^2}-\frac{\mathbb{E}[x]}{(1-\omega)^2}
      = \frac{1}{\omega(1-\omega)}.

where we have used the fact that :math:`\mathbb{E}[x]=1-\omega` by the property of the mistag.
Therefore, the Fisher-matrix elements are

.. math::
    I_{jk} = \frac{1}{\omega(1-\omega)}\frac{\partial\omega}{\partial p_j}\frac{\partial\omega}{\partial p_k}.

The derivative of :math:`\omega(\eta)` with respect to :math:`p_j` gives us a contribution specific to the used link
(or 1 for the identity link). Using the chain rule we get,

.. math::
    \frac{\partial\omega}{\partial p_j}
        = \left[g^{-1}\right]'\!\left(g(\eta)\right)\hat{P}_j(g(\eta))
        = \frac{\hat{P}_j(g(\eta))}{g'(\eta)},

where in the last step, the (inverse) inverse function rule :math:`[g^{-1}]'(g(\eta)) = 1/g'(\eta)` is applied.
Furthermore, this expression is valid at the nominal point before the calibration where :math:`\omega\approx\eta` and :math:`p_i=0`.
Substituting everything back in, and evaluating at the nominal point gives the final expression for the Fisher elements:

.. math::
    I_{jk} = \frac{1}{\sum_{i=0}^Nw_i}\sum_{i=0}^N \frac{w_i\hat{P}_j(g(\eta_i))\hat{P}_k(g(\eta_i))}
                         {\eta_i(1-\eta_i)\left[\frac{\partial}{\partial\eta}g(\eta_i)\right]^2}.

where we have some arbitrary, but optional event weights :math:`w_i`.
This expression is simultaneously a cleaner definition of the *inner product* we have been using before! It is
interesting to note, that by inspecting this term, we find that the weight
matrix :math:`W` mentioned previously, is therefore always diagonal. For the
parameters to be uncorrelated, :math:`I_{jk}=0` for :math:`j\neq k`, which
means the basis polynomials must be orthogonal with respect to the inner
product

.. math::
    \langle\hat{P}_j,\hat{P}_k\rangle_{\mathrm{Fisher}}
        = \frac{1}{\sum_{i=0}^Nw_i}\sum_{i=0}^N \frac{w_i\hat{P}_j(g(\eta_i))\hat{P}_k(g(\eta_i))} {\eta_i(1-\eta_i)\left[\frac{\partial}{\partial\eta}g(\eta_i)\right]^2}
        = 0

This is precisely the Fisher information metric, and the weight
:math:`[\eta(1-\eta)(g'(\eta))^2]^{-1}` is the corresponding *Fisher
information weight*. Applying the same Gram-Schmidt procedure as before, but
now with the moment averages computed using this weight, yields an orthogonal
basis and thus uncorrelated parameters for our Bernoulli likelihood with
arbitrary link function.

.. raw:: html

   </details>
   <br>

Reference formulas for higher-order calibrations
------------------------------------------------
The following script is a rewrite of ftcalib's own basis transformation code in
sympy and it prints the non-trivial basis coefficients for a given calibration
order. The actual algorithm is numerical in nature. With increasing order, the
previous basis coefficients stay unchanged and only new coefficients are added
in the next row. As mentioned before, the analytical results obtained here
continue to hold if there is a link function.

.. code-block:: python

   import sys
   from sympy import Symbol, symbols, Matrix, pprint, sqrt, latex

   e = Symbol('eta')

   def avg_eta(deg: int):
       if deg == 0:
           return 1
       if deg == 1:
           return Symbol(f'<{e}>')
       return Symbol(f'<eta**{deg}>')

   def make_calibration(deg: int):
       moments: Matrix = Matrix([[avg_eta(i + j) for j in range(deg)] for i in range(deg)])
       basis: Matrix = Matrix([[ 1 if i == j else 0 for j in range(deg)] for i in range(deg)])

       def product(v1, v2):
           prod = 0
           for i in range(deg):
               for j in range(deg):
                   prod += v1[i] * v2[j] * moments[i, j]
           return prod

       # Gram-Schmidt orthogonalization (MGS)
       for i in range(deg):
           norm = sqrt(product(basis[i,:], basis[i,:]))
           basis[i,:] = basis[i,:].applyfunc(lambda x : x / norm)
           for j in range(i + 1, deg):
               prod = product(basis[i,:], basis[j,:])
               basis[j,:] -= basis[i,:] * prod
       for i in range(deg):
           basis[i,:] /= basis[i,i]

       basis.simplify()
       return basis


   if __name__ == "__main__":
       if len(sys.argv) != 2:
           print("Usage: python formula.py [DEG]")
           sys.exit(1)
       DEG = int(sys.argv[1])
       basis = make_calibration(DEG + 1)
       for i in range(DEG + 1):
           coeff = basis[DEG, i]
           print(f"B_{DEG}{i} =")
           pprint(coeff)
           print("In LaTeX:")
           print(f"B_{{{DEG}{i}}} =", latex(coeff).replace('<', '\\langle ').replace('>', ' \\rangle').replace("**", '^').replace("eta", '\\eta'))

.. math::
    :nowrap:

    \begin{align*}
    B_{10} &= - \langle \eta \rangle\\
    B_{20} &= \frac{- \langle \eta^2 \rangle^{2} + \langle \eta^3 \rangle \langle \eta \rangle}{\langle \eta^2 \rangle - \langle \eta \rangle^{2}}\\
    B_{21} &= \frac{\langle \eta^2 \rangle \langle \eta \rangle - \langle \eta^3 \rangle}{\langle \eta^2 \rangle - \langle \eta \rangle^{2}}\\
    B_{30} &= \frac{- \langle \eta^2 \rangle^{2} \langle \eta^5 \rangle + 2 \langle \eta^2 \rangle \langle \eta^3 \rangle \langle \eta^4 \rangle - \langle \eta^3 \rangle^{3} + \langle \eta^3 \rangle \langle \eta^5 \rangle \langle \eta \rangle - \langle \eta^4 \rangle^{2} \langle \eta \rangle}{\langle \eta^2 \rangle^{3} - 2 \langle \eta^2 \rangle \langle \eta^3 \rangle \langle \eta \rangle - \langle \eta^2 \rangle \langle \eta^4 \rangle + \langle \eta^3 \rangle^{2} + \langle \eta^4 \rangle \langle \eta \rangle^{2}}\\
    B_{31} &= \frac{- \langle \eta^2 \rangle^{2} \langle \eta^4 \rangle + \langle \eta^2 \rangle \langle \eta^3 \rangle^{2} + \langle \eta^2 \rangle \langle \eta^5 \rangle \langle \eta \rangle - \langle \eta^3 \rangle \langle \eta^4 \rangle \langle \eta \rangle - \langle \eta^3 \rangle \langle \eta^5 \rangle + \langle \eta^4 \rangle^{2}}{\langle \eta^2 \rangle^{3} - 2 \langle \eta^2 \rangle \langle \eta^3 \rangle \langle \eta \rangle - \langle \eta^2 \rangle \langle \eta^4 \rangle + \langle \eta^3 \rangle^{2} + \langle \eta^4 \rangle \langle \eta \rangle^{2}}\\
    B_{32} &= \frac{- \langle \eta^2 \rangle^{2} \langle \eta^3 \rangle + \langle \eta^2 \rangle \langle \eta^4 \rangle \langle \eta \rangle + \langle \eta^2 \rangle \langle \eta^5 \rangle + \langle \eta^3 \rangle^{2} \langle \eta \rangle - \langle \eta^3 \rangle \langle \eta^4 \rangle - \langle \eta^5 \rangle \langle \eta \rangle^{2}}{\langle \eta^2 \rangle^{3} - 2 \langle \eta^2 \rangle \langle \eta^3 \rangle \langle \eta \rangle - \langle \eta^2 \rangle \langle \eta^4 \rangle + \langle \eta^3 \rangle^{2} + \langle \eta^4 \rangle \langle \eta \rangle^{2}}
    \end{align*}

The symbolic computation for fourth degree calibrations takes more than an hour on my machine in sympy, so they are omitted here.
