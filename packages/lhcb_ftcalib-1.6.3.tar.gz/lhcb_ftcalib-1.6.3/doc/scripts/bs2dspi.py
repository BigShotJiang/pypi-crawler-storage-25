import sys
sys.path.append("../")
import lhcb_ftcalib as ft
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


if __name__ == "__main__":
    pd.set_option("display.max_rows", None)

    def curve_area(curve_y, dx):
        return np.sum(curve_y) * dx

    F = ft.PolynomialCalibration(2, ft.link.mistag)
    tmin = 0
    tmax = 3
    precision = 1000

    gen = ft.ToyGenerator(tmin, tmax)
    gen.setPhysics(DM=17.765, DG=0.083, S=0, Sbar=0, C=1.0, Cbar=-1.0, ADG=0, ADGbar=0.0)

    gen.add_tagger(name           = "T1",
                   params_plus    = [0, 0],
                   params_minus   = [0, 0],
                   eta_shape_func = lambda _ : 1,
                   calib_func     = F)
    df = gen.generate(100000, flavour_specific_decay=True, acceptance="None")

    t = np.linspace(tmin, tmax, precision)
    acceptance = lambda _ : 1.0

    nbins = 200
    curve_mixed   = gen.bdecay(t, fprod=-1, fdecay=1, acceptance=acceptance) + gen.bdecay(t, fprod=1, fdecay=-1, acceptance=acceptance)
    curve_unmixed = gen.bdecay(t, fprod=1, fdecay=1, acceptance=acceptance) + gen.bdecay(t, fprod=-1, fdecay=-1, acceptance=acceptance)

    bin_width = (tmax - tmin) / nbins
    Nmixed = len(df[df.PROCESS.isin([2, 3])])
    Nunmixed = len(df[df.PROCESS.isin([1, 4])])
    curve_mixed /= curve_area(curve_mixed, (tmax - tmin) / precision)
    curve_mixed *= Nmixed * bin_width
    curve_unmixed /= curve_area(curve_unmixed, (tmax - tmin) / precision)
    curve_unmixed *= Nunmixed * bin_width

    fig, ax = plt.subplots(1, 1, figsize=(8, 5))

    ax.hist(df.TRUETAU[(df.PROCESS==1)|(df.PROCESS==4)], bins=nbins, histtype="stepfilled", linewidth=1, label="Unmixed", alpha=0.4, color="b")
    ax.hist(df.TRUETAU[(df.PROCESS==2)|(df.PROCESS==3)], bins=nbins, histtype="stepfilled", linewidth=1, label="Mixed", alpha=0.4, color="r")
    ax.hist(df.TRUETAU, bins=nbins, histtype="step", linewidth=1, label="Total", alpha=0.7)

    ax.plot(t, curve_mixed, label="Mixed", color="r", linewidth=1)
    ax.plot(t, curve_unmixed, label="Unmixed", color="b", linewidth=1)

    ax.legend(loc="upper right")
    # plt.yscale("log")
    ax.set_xlim(tmin, tmax)
    fig.tight_layout()

