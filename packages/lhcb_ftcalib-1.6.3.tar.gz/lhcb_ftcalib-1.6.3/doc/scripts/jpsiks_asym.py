import lhcb_ftcalib as ft
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

def timehist_JpsiKstar(tmin, tmax, ax, df, gen):
    def curve_area(curve_y, dx):
        return np.sum(curve_y) * dx

    nbins_hist = 120
    bin_width = (tmax - tmin) / nbins_hist
    def normalize_curve_to_area(curve, area):
        return curve / curve_area(curve, (tmax - tmin) / 1000) * area

    t = np.linspace(tmin, tmax, 1000)
    curve_Btof       = gen.bdecay(t, fprod=1, fdecay=1, acceptance=gen.arctan_acceptance)
    curve_Bbartof    = gen.bdecay(t, fprod=-1, fdecay=1, acceptance=gen.arctan_acceptance)
    curve_Btofbar    = gen.bdecay(t, fprod=1, fdecay=-1, acceptance=gen.arctan_acceptance)
    curve_Bbartofbar = gen.bdecay(t, fprod=-1, fdecay=-1, acceptance=gen.arctan_acceptance)

    N_f    = df[df.PROCESS.isin([ft.ToyGenerator.Process.B_to_f,    ft.ToyGenerator.Process.Bbar_to_f])].shape[0]
    N_fbar = df[df.PROCESS.isin([ft.ToyGenerator.Process.B_to_fbar, ft.ToyGenerator.Process.Bbar_to_fbar])].shape[0]

    curve_f    = normalize_curve_to_area(curve_Btof + curve_Bbartof,         N_f    * bin_width)
    curve_fbar = normalize_curve_to_area(curve_Btofbar + curve_Bbartofbar,   N_fbar * bin_width)

    Nplus = len(df.TRUETAU[df.FLAV_PROD==1])
    Nminus = len(df.TRUETAU[df.FLAV_PROD==-1])

    ax.hist(df.TRUETAU[df.PROCESS.isin([ft.ToyGenerator.Process.B_to_f, ft.ToyGenerator.Process.Bbar_to_f])],       bins=nbins_hist, range=(tmin, tmax), histtype="stepfilled", alpha=0.5, color="r")
    ax.hist(df.TRUETAU[df.PROCESS.isin([ft.ToyGenerator.Process.B_to_fbar, ft.ToyGenerator.Process.Bbar_to_fbar])], bins=nbins_hist, range=(tmin, tmax), histtype="stepfilled", alpha=0.5, color="b")

    ax.plot(t, curve_f, color="r", label=r"$f = J\!/\!\psi K^*$")
    ax.plot(t, curve_fbar, color="b", label=r"$ f= J\!/\!\psi \overline{K}^*$")
    ax.set_title(r"$B^0\to J\!/\!\psi K^*$ (No CPV)")
    ax.set_yscale("log")
    ax.legend()

def timehist_JpsiKS(tmin, tmax, ax, df, gen):
    def curve_area(curve_y, dx):
        return np.sum(curve_y) * dx
    def normalize_curve_to_area(curve, area):
        return curve / curve_area(curve, (tmax - tmin) / 1000) * area

    nbins_hist = 120
    bin_width = (tmax - tmin) / nbins_hist

    N_B    = df[df.PROCESS == ft.ToyGenerator.Process.B_to_f].shape[0]
    N_Bbar = df[df.PROCESS == ft.ToyGenerator.Process.Bbar_to_f].shape[0]
    t = np.linspace(tmin, tmax, 1000)
    curve_B    = normalize_curve_to_area(gen.bdecay(t, fprod=1, fdecay=1, acceptance=gen.arctan_acceptance), N_B * bin_width)
    curve_Bbar = normalize_curve_to_area(gen.bdecay(t, fprod=-1, fdecay=1, acceptance=gen.arctan_acceptance), N_Bbar * bin_width)

    ax.hist(df.TRUETAU[df.FLAV_PROD==1], bins=nbins_hist, color="r", range=(tmin, tmax), histtype="stepfilled", alpha=0.5)
    ax.hist(df.TRUETAU[df.FLAV_PROD==-1], bins=nbins_hist, color="b", range=(tmin, tmax), histtype="stepfilled", alpha=0.5)
    ax.plot(t, curve_B, 'r-', label=r"$B^0\to J\!/\!\psi K^0_\mathrm{S}$")
    ax.plot(t, curve_Bbar, 'b-', label=r"$\overline{B}^0\to J\!/\!\psi K^0_\mathrm{S}$")
    ax.set_title(r"$B^0\to J\!/\!\psi K^0_\mathrm{S}$ (S=0.7,C=0)")
    ax.set_yscale("log")
    ax.legend()

def asymmetry(tmin, tmax, ax, df, title, gen, nbins=20, show_S=False):
    def jackknife_error(N, y):
        dA = N
        dA -= 2 * y * N
        dA += y ** 2 * N
        dA /= N ** 2
        return np.sqrt(dA)

    bin_edges = np.linspace(tmin, tmax, nbins + 1)
    df = df.copy()
    df["bin"] = pd.cut(df.TRUETAU, bins=bin_edges, labels=False)
    chunks = [df[df.bin == i] for i in range(nbins)]
    xs   = [(bin_edges[i] + bin_edges[i+1]) / 2 for i in range(nbins)]
    xerr = [(0.5 * (bin_edges[i+1] - bin_edges[i])) for i in range(nbins)]
    ys   = [((c.FLAV_PROD == -1).sum() - (c.FLAV_PROD == 1).sum()) / len(c) for c in chunks]
    yerr = [jackknife_error(len(c), y) for c, y in zip(chunks, ys)]

    t = np.linspace(tmin, tmax, 1000)
    asym = gen.bdecay(t, fprod=-1, fdecay=1, acceptance=lambda _ : 1.0) - gen.bdecay(t, fprod=1, fdecay=1, acceptance=lambda _ : 1.0)
    asym /= gen.bdecay(t, fprod=-1, fdecay=1, acceptance=lambda _ : 1.0) + gen.bdecay(t, fprod=1, fdecay=1, acceptance=lambda _ : 1.0)

    if show_S:
        ax.plot(t, asym, 'k-', label="Asymmetry")
        plt.axhline(gen.S, color="gray", linestyle="--", label=f"S={gen.S}")
        plt.axhline(-gen.S, color="gray", linestyle="--")

    ax.errorbar(xs, ys, yerr=yerr, xerr=xerr, fmt="o", color="k")
    ax.axhline(0, color="gray", linestyle="-", linewidth=0.5)
    ax.set_xlabel("t [ps]")
    ax.set_ylim(-0.8, 0.8)
    plt.legend()

if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import sys
    sys.path.append("../")
    import lhcb_ftcalib as ft
    import numpy as np
    import pandas as pd

    F = ft.PolynomialCalibration(2, ft.link.mistag)
    tmin = 0
    tmax = 15

    tg = ft.ToyGenerator(tmin, tmax)
    tg_cpv = ft.ToyGenerator(tmin, tmax)
    tg.setPhysics(    DM=0.5065, DG=0, S=0,   Sbar=0,   C=0.0, Cbar=0.0, ADG=0, ADGbar=0.0)
    tg_cpv.setPhysics(DM=0.5065, DG=0, S=0.7, Sbar=0.7, C=0.0, Cbar=0.0, ADG=0, ADGbar=0.0)

    def make_sample(gen):
       gen.add_tagger(name           = "T1",
                      params_plus    = [0, 0],
                      params_minus   = [0, 0],
                      eta_shape_func = lambda _ : 1,
                      calib_func     = F)
       return gen.generate(100000)

    df_zero = make_sample(tg)
    df_cpv = make_sample(tg_cpv)

    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(10, 8))

    timehist(tmin, tmax, ax1, df_zero, "No CPV", tg, (r"$B^0\to J\!/\!\psi K^*$", r"$\overline{B}^0\to J\!/\!\psi \overline{K}^*$"))
    timehist(tmin, tmax, ax2, df_cpv, "S=0.7", tg_cpv, (r"$B^0\to J\!/\!\psi K^0_\mathrm{S}$", r"$\overline{B}^0\to J\!/\!\psi K^0_\mathrm{S}$"))
    asymmetry(tmin, tmax, ax3, df_zero, "No CPV", tg, nbins=20)
    asymmetry(tmin, tmax, ax4, df_cpv, "S=0.7", tg_cpv, nbins=20, show_S=True)

    ax1.set_ylabel("Entries")
    ax3.set_ylabel("$A_{CP}$")
    fig.tight_layout()
