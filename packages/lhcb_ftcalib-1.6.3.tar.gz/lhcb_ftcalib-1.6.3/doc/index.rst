lhcb_ftcalib Documentation
==========================

.. only:: html

   :download:`Download PDF Manual <lhcb_ftcalib.pdf>`

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Tutorial

.. toctree::
   :maxdepth: 2
   :caption: Documentation

   modules
   CommandLineInterface

.. toctree::
   :maxdepth: 2
   :caption: Compatibility and FAQ

   EPMComparison
   Troubleshooting

.. toctree::
   :maxdepth: 2
   :caption: Theory

   likelihood
   calibrationFuncTheory
   combination
   toyDataGeneration

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
