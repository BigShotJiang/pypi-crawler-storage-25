import sys
sys.path.append('../')
import lhcb_ftcalib as ft
import numpy as np
from iminuit import Minuit

def generate_data(SEED, acceptance):
    S_true = 0.7
    # Set true calibration parameters in flavour form
    p0_plus = 0.04
    p1_plus = 0.3
    p0_minus = -0.03
    p1_minus = 0.28
    N = 100000

    # /////////////////////////////////////
    # Generate the signal mode B -> Jpsi KS
    # /////////////////////////////////////
    genJpsiKS = ft.ToyGenerator(0, 15, seed=SEED) # ps
    genJpsiKS.setPhysics(neutral_mode=True, flavour_specific=False, DM=0.5065, DG=0, S=S_true, C=0)
    calibration = ft.PolynomialCalibration(2, ft.link.mistag)
    genJpsiKS.add_tagger(name     = "ToyTagger",
                   params_plus    = [p0_plus, p1_plus],
                   params_minus   = [p0_minus, p1_minus],
                   eta_shape_func = lambda x: np.exp(-0.5 * ((x - 0.3)/0.03) ** 2),
                   calib_func     = calibration)
    dfJpsiKS = genJpsiKS.generate(N, acceptance=acceptance)

    # /////////////////////////////////////////////////////////////////////////////
    # Generate the calibration mode B -> Jpsi K*(892)0 with identical tagging setup
    # /////////////////////////////////////////////////////////////////////////////
    genJpsiKst = ft.ToyGenerator(0, 15, seed=SEED + 1) # ps
    genJpsiKst.setPhysics(neutral_mode=True, flavour_specific=True, DM=0.5065, DG=0, S=0, Sbar=0, C=1.0, Cbar=-1.0)
    genJpsiKst.add_tagger(name    = "ToyTagger",
                   params_plus    = [p0_plus, p1_plus],
                   params_minus   = [p0_minus, p1_minus],
                   eta_shape_func = lambda x: np.exp(-0.5 * ((x - 0.3)/0.03) ** 2),
                   calib_func     = calibration)
    dfJpsiKst = genJpsiKst.generate(N, acceptance=acceptance)

    # Remove branches we would not have access to in real data
    dfJpsiKS.drop(columns=["PROCESS", "FLAV_PROD", "FLAV_DECAY", "TRUETAU", "FLAV_HYPOT", "ToyTagger_OMEGA"], inplace=True)
    dfJpsiKst.drop(columns=["PROCESS", "FLAV_PROD", "TRUETAU", "FLAV_HYPOT", "ToyTagger_OMEGA"], inplace=True)
    return dfJpsiKS, dfJpsiKst


if __name__ == "__main__":
    import lhcb_ftcalib as ft
    import matplotlib.pyplot as plt

    def acceptance(t):
        return 2.0 * np.arctan(2.0 * t) / np.pi

    dfJpsiKS, dfJpsiKst = generate_data(493874, acceptance)

    # Calibrate the tagger in the JpsiKstar control mode
    tc = ft.TaggerCollection()
    tc.create_tagger("ToyTagger", 
                     dfJpsiKst.ToyTagger_ETA,
                     dfJpsiKst.ToyTagger_DEC, 
                     511 * dfJpsiKst.FLAV_DECAY,
                     tau_ps = dfJpsiKst.TAU,
                     mode = "Bd")
    tc.set_calibration(ft.PolynomialCalibration(2, ft.link.mistag))
    tc.calibrate(quiet=True)
    # Save calibration result for later use in the signal mode
    calib_result = ft.save_calibration(tc, "ToyTagger", write=False)

    fig, ax = plt.subplots(1, 1, figsize=(7, 5))
    ft.draw_calibration_curve(tc["ToyTagger"], ax=ax, save=False, title="Calibration", title_fontsize=14, legend_fontsize=15, params_fontsize=10, axis_fontsize=15, print_params=False)
    fig.tight_layout()

    # Apply the calibration to JpsiKS
    target = ft.TargetTagger("ToyTagger", dfJpsiKS["ToyTagger_ETA"].to_numpy(), dfJpsiKS["ToyTagger_DEC"].to_numpy())
    target.load(calib_result, "ToyTagger")
    target.apply()

    toyTaggerCalibrated = target.get_dataframe()
    print(toyTaggerCalibrated)

    omega = toyTaggerCalibrated["ToyTagger_OMEGA"].to_numpy()
    dec = toyTaggerCalibrated["ToyTagger_CDEC"].to_numpy()

    # Iminuit fit to
    # acceptance(t) * exp(-Gamma t) * (1 + S * F_S * sin(DeltaM t) + C * F_C * cos(DeltaM t))
    # F_S = -dec * (1 - 2 * omega)
    # F_C = dec * (1 - 2 * omega)

    DeltaM = 0.5065       # ps^{-1}, B0 oscillation frequency (PDG)
    Gamma  = 1.0 / 1.52   # ps^{-1}, B0 decay width (PDG lifetime 1.52 ps)
    tmin   = 0.0
    tmax   = float(dfJpsiKS["TAU"].max())

    # Decay times from signal dataset; omega and dec already computed above (lines 81-82)
    t = dfJpsiKS["TAU"].to_numpy(dtype=np.float64)
    # Per-event coefficients matching the formula in the comment above
    F_S = -dec * (1.0 - 2.0 * omega)
    F_C = -F_S

    # Pre-compute event-level time projections (vectorised, called once)
    sin_t = np.sin(DeltaM * t)
    cos_t = np.cos(DeltaM * t)
    decay_component = acceptance(t) * np.exp(-Gamma * t)

    # -------------------------------------------------------------------------
    # Normalization integrals (identical for every event; computed once on a
    # fine grid using the same acceptance that shapes the data)
    #
    #   I_exp = integral  e^{-Gamma t} a(t)              dt
    #   I_sin = integral  e^{-Gamma t} a(t) sin(DM t)    dt
    #   I_cos = integral  e^{-Gamma t} a(t) cos(DM t)    dt
    #
    # The per-event normalization factorises as
    #   N_i = I_exp + S * F_S_i * I_sin + C * F_C_i * I_cos
    # -------------------------------------------------------------------------
    t_norm = np.linspace(tmin, tmax, 5000)
    base_decay = np.exp(-Gamma * t_norm) * acceptance(t_norm)
    I_exp      = np.trapezoid(base_decay,                           t_norm)
    I_sin      = np.trapezoid(base_decay * np.sin(DeltaM * t_norm), t_norm)
    I_cos      = np.trapezoid(base_decay * np.cos(DeltaM * t_norm), t_norm)

    def nll(S, C):
        f_i = decay_component * (1.0 + S * F_S * sin_t + C * F_C * cos_t)
        if np.any(f_i <= 0.0):
            return np.inf

        N_i = I_exp + S * F_S * I_sin + C * F_C * I_cos
        if np.any(N_i <= 0.0):
            return np.inf

        return float(-np.sum(np.log(f_i) - np.log(N_i)))

    m = Minuit(nll, S=0.5, C=0.0)
    m.errordef = Minuit.LIKELIHOOD
    m.limits["S"] = (-1.0, 1.0)
    m.limits["C"] = (-1.0, 1.0)
    m.migrad()
    m.hesse()

    print(m)
    print(f"\nFitted  S = {m.values['S']:.4f} ± {m.errors['S']:.4f}  (generated: 0.7)")
    print(f"Fitted  C = {m.values['C']:.4f} ± {m.errors['C']:.4f}  (generated: 0.0)")
