import numpy as np
import matplotlib.pyplot as plt

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(6, 3))
N = 100000
S=0.7

def plot(ax, G, m):
    Aplus = 1/G - S*m/(m**2 + G**2)
    Aminus = 1/G + S*m/(m**2 + G**2)

    ratio = Aplus/(Aplus + Aminus)

    Nplus = N * ratio
    Nminus = N - Nplus

    ax.hist([-511, 511], bins=30, weights=[Nminus, Nplus], color="C0")
    ax.set_xlabel("Monte Carlo Particle ID", fontsize=15)


ax1.set_title(r"$\Delta m_d=0.5065\,\mathrm{ps}^{-1}$")
plot(ax1, 1.52, 0.5065)
ax2.set_title(r"$\Delta m_s=17.765\,\mathrm{ps}^{-1}$")
plot(ax2, 1.52, 17.765)
fig.tight_layout()