import matplotlib.pyplot as plt
import lhcb_ftcalib as ft
import numpy as np
import pandas as pd

from scripts.jpsiks_asym import timehist_JpsiKS, timehist_JpsiKstar, asymmetry
tmin = 0
tmax = 15

tg = ft.ToyGenerator(tmin, tmax, seed=34987534)
tg_cpv = ft.ToyGenerator(tmin, tmax, seed=34987534)
tg.setPhysics(    neutral_mode=True, flavour_specific=True, DM=0.5065, DG=0, S=0,   Sbar=0,   C=1.0, Cbar=-1.0, ADG=0, ADGbar=0.0)
tg_cpv.setPhysics(neutral_mode=True, flavour_specific=False, DM=0.5065, DG=0, S=0.7, Sbar=0.7, C=0.0, Cbar=0.0, ADG=0, ADGbar=0.0)

df_zero = tg.generate(100000, acceptance="arctan")
df_cpv = tg_cpv.generate(100000, acceptance="arctan")

fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(10, 8))

timehist_JpsiKstar(tmin, tmax, ax1, df_zero, tg)
timehist_JpsiKS(tmin, tmax, ax2, df_cpv, tg_cpv)
asymmetry(tmin, tmax, ax3, df_zero, "No CPV", tg, nbins=20)
asymmetry(tmin, tmax, ax4, df_cpv, "S=0.7", tg_cpv, nbins=20, show_S=True)

ax1.set_ylabel("Entries", fontsize=15)
ax3.set_ylabel("$A_{CP}$", fontsize=15)
fig.tight_layout()