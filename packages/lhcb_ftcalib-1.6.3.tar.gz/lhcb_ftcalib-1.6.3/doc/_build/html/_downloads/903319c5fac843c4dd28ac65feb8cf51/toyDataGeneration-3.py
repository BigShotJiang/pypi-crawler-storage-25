import lhcb_ftcalib as ft
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

def curve_area(curve_y, dx):
    return np.sum(curve_y) * dx

tmin = 0
tmax = 3
precision = 1000

gen = ft.ToyGenerator(tmin, tmax, seed=230948)
gen.setPhysics(neutral_mode=True, flavour_specific=True, DM=17.765, DG=0.083, S=0, Sbar=0, C=1.0, Cbar=-1.0, ADG=0, ADGbar=0.0)

df = gen.generate(100000, acceptance="arctan")

t = np.linspace(tmin, tmax, precision)
acc = gen.arctan_acceptance

nbins = 200
curve_mixed   = gen.bdecay(t, fprod=-1, fdecay=1, acceptance=acc) + gen.bdecay(t, fprod=1, fdecay=-1, acceptance=acc)
curve_unmixed = gen.bdecay(t, fprod=1, fdecay=1, acceptance=acc) + gen.bdecay(t, fprod=-1, fdecay=-1, acceptance=acc)

bin_width = (tmax - tmin) / nbins
Nmixed = len(df[df.PROCESS.isin([2, 3])])
Nunmixed = len(df[df.PROCESS.isin([1, 4])])
curve_mixed /= curve_area(curve_mixed, (tmax - tmin) / precision)
curve_mixed *= Nmixed * bin_width
curve_unmixed /= curve_area(curve_unmixed, (tmax - tmin) / precision)
curve_unmixed *= Nunmixed * bin_width

fig, ax = plt.subplots(1, 1, figsize=(7, 4))

ax.hist(df.TRUETAU[(df.PROCESS==1)|(df.PROCESS==4)], bins=nbins, histtype="stepfilled", linewidth=1, label="Unmixed", alpha=0.4, color="b")
ax.hist(df.TRUETAU[(df.PROCESS==2)|(df.PROCESS==3)], bins=nbins, histtype="stepfilled", linewidth=1, label="Mixed", alpha=0.4, color="r")
ax.hist(df.TRUETAU, bins=nbins, histtype="step", linewidth=1, label="Total", alpha=0.7)

ax.plot(t, curve_mixed, label="Mixed", color="r", linewidth=1)
ax.plot(t, curve_unmixed, label="Unmixed", color="b", linewidth=1)

ax.legend(loc="upper right")
ax.set_xlim(tmin, tmax)
ax.set_xlabel("Decay Time [ps]", fontsize=15)
ax.set_ylabel("Entries", fontsize=15)
fig.tight_layout()