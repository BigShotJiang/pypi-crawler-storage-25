import matplotlib.pyplot as plt
import lhcb_ftcalib as ft
from iminuit import Minuit

def generate_data(SEED, acceptance):
    # Set true calibration parameters in flavour form
    p0_plus = 0.04
    p1_plus = 0.3
    p0_minus = -0.03
    p1_minus = 0.28
    N = 100000

    # ////////////////////////////////////
    # Generate the signal mode Bs -> Ds Pi
    # ////////////////////////////////////
    calibration = ft.PolynomialCalibration(2, ft.link.mistag)
    genBs2Dspi = ft.ToyGenerator(0, 15, seed=SEED) # ps
    genBs2Dspi.setPhysics(neutral_mode=True, flavour_specific=True, DM=17.765, DG=0.083, S=0, Sbar=0, C=1.0, Cbar=-1.0)
    genBs2Dspi.add_tagger(name    = "ToyTagger",
                   params_plus    = [p0_plus, p1_plus],
                   params_minus   = [p0_minus, p1_minus],
                   eta_shape_func = lambda x: np.exp(-0.5 * ((x - 0.4)/0.03) ** 2),
                   calib_func     = calibration,
                   efficiency=0.8)
    df = genBs2Dspi.generate(N, acceptance=acceptance)

    # Remove branches we would not have access to in real data
    df.drop(columns=["PROCESS", "FLAV_PROD", "TRUETAU", "FLAV_HYPOT", "ToyTagger_OMEGA"], inplace=True)
    return df

DeltaM = 17.765 # ps^-1
DeltaGamma = 0.083 # ps^-1
Gamma = 1 / 1.5 # ps^-1
tmin = 0
tmax = 15

def acceptance(t):
    return 2.0 * np.arctan(2.0 * t) / np.pi

df = generate_data(493874, acceptance)

average_eta = np.mean(df.ToyTagger_ETA)

# Simple calibration function
def omega(eta, d, p0, p1, DP0, DP1):
    omega = eta + p0 + p1 * (eta - average_eta)
    domega = DP0 + DP1 * (eta - average_eta)
    return omega + d * 0.5 * domega

dec = df.ToyTagger_DEC.to_numpy()

F_C = lambda d, omega: d * (1.0 - 2.0 * omega)
dilution = lambda omega: 1.0 - 2.0 * omega

untagged = (dec == 0)
tagged = (dec != 0)
fdecay = df[tagged].FLAV_DECAY.to_numpy()
dec = df[tagged].ToyTagger_DEC.to_numpy()

unmixed = (fdecay == dec)
mixed   = (fdecay != dec)

t = df[tagged].TAU.to_numpy()
eta = df[tagged].ToyTagger_ETA.to_numpy()
# Precompute what we can (does not depend on DeltaMs)
cosh_t = np.cosh(0.5 * DeltaGamma * t)
decay_component = acceptance(t) * np.exp(-Gamma * t)

def nll(DeltaMs, p0, p1, DP0, DP1):
    # Compute normalization integrals
    t_norm = np.linspace(tmin, tmax, 5000)
    I_base_decay = np.exp(-Gamma * t_norm) * acceptance(t_norm)
    I_ExpCosh = np.trapezoid(I_base_decay * np.cosh(0.5 * DeltaGamma * t_norm), t_norm)
    I_ExpCos  = np.trapezoid(I_base_decay * np.cos(DeltaMs * t_norm),           t_norm)

    # Compute per-event likelihoods
    NLL = np.zeros_like(t)
    C = 1.0
    Cbar = -1.0

    cos_t = np.cos(DeltaMs * t)

    # Compute F_C coefficient
    F_C_coeff = dilution(omega(eta, dec, p0, p1, DP0, DP1))

    # Compute raw likelihoods
    NLL[unmixed] = decay_component[unmixed] * (cosh_t[unmixed] + cos_t[unmixed] * F_C_coeff[unmixed])
    NLL[mixed]   = decay_component[mixed]   * (cosh_t[mixed]   - cos_t[mixed]   * F_C_coeff[mixed])

    # Normalize the likelihoods
    NLL[unmixed] /= I_ExpCosh + I_ExpCos * F_C_coeff[unmixed]
    NLL[mixed]   /= I_ExpCosh - I_ExpCos * F_C_coeff[mixed]

    if np.any(NLL <= 0.0):
        return np.inf

    return float(-np.sum(np.log(NLL)))

m = Minuit(nll, DeltaMs=17.5, p0=0.0, p1=0.0, DP0=0.0, DP1=0.0)
m.errordef = Minuit.LIKELIHOOD
m.limits["DeltaMs"] = (10.0, 25.0)
m.limits["p0"]  = (-1.0, 1.0)
m.limits["p1"]  = (-1.0, 1.0)
m.limits["DP0"] = (-1.0, 1.0)
m.limits["DP1"] = (-1.0, 1.0)
m.migrad()
m.hesse()

print(m)
print(f"\nFitted  DeltaMs: {m.values['DeltaMs']:.3f} ps^-1 (true value: {DeltaM} ps^-1)")

tau_tagged   = t  # save tagged-only tau before overwriting with plot range
t = np.linspace(0, 8, 1000)
nbins = 200
curve_mixed = acceptance(t) * np.exp(-Gamma * t) * (np.cosh(0.5 * DeltaGamma * t) - np.cos(m.values['DeltaMs'] * t) * dilution(omega(average_eta, 0, m.values['p0'], m.values['p1'], m.values['DP0'], m.values['DP1'])))
curve_unmixed = acceptance(t) * np.exp(-Gamma * t) * (np.cosh(0.5 * DeltaGamma * t) + np.cos(m.values['DeltaMs'] * t) * dilution(omega(average_eta, 0, m.values['p0'], m.values['p1'], m.values['DP0'], m.values['DP1'])))
curve_untagged = acceptance(t) * np.exp(-Gamma * t) * np.cosh(0.5 * DeltaGamma * t)

bins_mixed,    edges_mixed    = np.histogram(tau_tagged[mixed],            bins=nbins, range=(0, 8))
bins_unmixed,  edges_unmixed  = np.histogram(tau_tagged[unmixed],          bins=nbins, range=(0, 8))
bins_untagged, edges_untagged = np.histogram(df.TAU.to_numpy()[untagged],  bins=nbins, range=(0, 8))

fig, ax = plt.subplots(1, 1, figsize=(10, 6))
bin_width = edges_mixed[1] - edges_mixed[0]
ax.errorbar(0.5 * (edges_mixed[1:] + edges_mixed[:-1]), bins_mixed, yerr=np.sqrt(bins_mixed), xerr=bin_width/2, fmt='.', label='mixed', color='red', markersize=1, elinewidth=0.5)
ax.errorbar(0.5 * (edges_unmixed[1:] + edges_unmixed[:-1]), bins_unmixed, yerr=np.sqrt(bins_unmixed), xerr=bin_width/2, fmt='.', label='unmixed', color='blue', markersize=1, elinewidth=0.5)
ax.errorbar(0.5 * (edges_untagged[1:] + edges_untagged[:-1]), bins_untagged, yerr=np.sqrt(bins_untagged), xerr=bin_width/2, fmt='.', label='untagged', color='gray', markersize=1, elinewidth=0.5)

n_mixed   = np.sum(mixed)
n_unmixed = np.sum(unmixed)
n_untagged = np.sum(untagged)
integral_mixed   = np.trapezoid(curve_mixed,   t)
integral_unmixed = np.trapezoid(curve_unmixed, t)
integral_untagged = np.trapezoid(curve_untagged, t)
ax.plot(t, curve_mixed   * n_mixed   * bin_width / integral_mixed,   label='Fit (mixed)',   color='red',  linewidth=1, alpha=0.5)
ax.plot(t, curve_unmixed * n_unmixed * bin_width / integral_unmixed, label='Fit (unmixed)', color='blue', linewidth=1, alpha=0.5)
ax.plot(t, curve_untagged * n_untagged * bin_width / integral_untagged, label='Untagged', color='gray', linewidth=1, alpha=0.5)

# Add a plot in the plot showing a zoomed in view
axins = ax.inset_axes([0.45, 0.38, 0.50, 0.55])
axins.errorbar(0.5 * (edges_mixed[1:] + edges_mixed[:-1]), bins_mixed,
               yerr=np.sqrt(bins_mixed), xerr=bin_width/2,
               fmt='.', color='red', markersize=2, elinewidth=1)
axins.errorbar(0.5 * (edges_unmixed[1:] + edges_unmixed[:-1]), bins_unmixed,
               yerr=np.sqrt(bins_unmixed), xerr=bin_width/2,
               fmt='.', color='blue', markersize=2, elinewidth=1)
axins.plot(t, curve_mixed   * n_mixed   * bin_width / integral_mixed,   color='red',  linewidth=1, alpha=0.5)
axins.plot(t, curve_unmixed * n_unmixed * bin_width / integral_unmixed, color='blue', linewidth=1, alpha=0.5)
axins.set_xlim(1, 3)
axins.set_ylim(100, 800)
axins.set_xlabel("$t$ [ps]", loc="right")
ax.set_xlabel("$t$ [ps]", loc="right")
ax.set_ylabel("Decays / 0.04 ps", loc="top")

ax.legend(loc='lower center', bbox_to_anchor=(0.5, 1.02), ncols=3, borderaxespad=0)
ax.set_xlim(0, 8)
ax.set_ylim(bottom=0)
plt.savefig("TEST.pdf", bbox_inches='tight')