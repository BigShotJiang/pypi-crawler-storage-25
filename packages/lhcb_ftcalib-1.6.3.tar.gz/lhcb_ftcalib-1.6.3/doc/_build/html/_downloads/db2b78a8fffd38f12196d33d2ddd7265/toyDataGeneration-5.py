import lhcb_ftcalib as ft
import matplotlib.pyplot as plt
import numpy as np

F1 = ft.PolynomialCalibration(3, ft.link.mistag)

gen = ft.ToyGenerator(0, 15, 329848)
gen.setPhysics(neutral_mode=True, flavour_specific=True, DM=17.765, DG=0, S=0, Sbar=0, C=1.0, Cbar=-1.0, ADG=0, ADGbar=0.0)

p0_plus = 0.04
p1_plus = 0.3
p2_plus = -2.3
p0_minus = -0.03
p1_minus = 0.2
p2_minus = -1.3

params = ft.CalParameters(3)
params.set_calibration_flavour([p0_plus, p1_plus, p2_plus, p0_minus, p1_minus, p2_minus], np.eye(6))

delta_params = params.params_delta

etaDistribution = lambda x: np.exp(-0.5 * ((x - 0.3)/0.09) ** 2)

gen.add_tagger(name           = "T1",
               params_plus    = [p0_plus, p1_plus, p2_plus],
               params_minus   = [p0_minus, p1_minus, p2_minus],
               eta_shape_func = etaDistribution,
               calib_func     = F1)
df = gen.generate(100000, acceptance="arctan")

tc = ft.TaggerCollection()
tc.create_tagger("T1", df.T1_ETA, df.T1_DEC, df.FLAV_DECAY, tau_ps=df.TAU, mode="Bs")
tc.set_calibration(F1)
tc.calibrate(quiet=True)

eta_lin = np.linspace(0, 0.5, 1000)
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

nbins = 100
bin_width = 0.5 / nbins
sampling_curve = etaDistribution(eta_lin)
sampling_curve /= np.trapezoid(sampling_curve, eta_lin)
sampling_curve *= len(df) * bin_width

ax1.hist(df.T1_ETA, bins=nbins, range=(0, 0.5), histtype="step", linewidth=1, label=r"$\eta$", alpha=0.7)
ax1.hist(df.T1_OMEGA, bins=nbins, range=(0, 0.5), histtype="step", linewidth=1, label="$\omega$", alpha=0.7)
ax1.plot(eta_lin, sampling_curve, linewidth=1, linestyle="--", color="C0", label=r"$\exp\left(-\frac{1}{2}\left(\frac{x-0.3}{0.09}\right)^2\right)$")

flavour_text = "\n".join([rf"${pname}$={p:.4f}" for pname, p in zip(params.names_latex_flavour, params.params_flavour)])
delta_text = "\n".join([rf"${pname}$={p:.4f}" for pname, p in zip(params.names_latex_delta, params.params_delta)])

ax1.text(0.02, 0.9, flavour_text, transform=ax1.transAxes, fontsize=10, verticalalignment="top", bbox=dict(boxstyle="round", facecolor="white", alpha=0.8))
ax1.text(0.02, 0.5, delta_text, transform=ax1.transAxes, fontsize=10, verticalalignment="top", bbox=dict(boxstyle="round", facecolor="orange", alpha=0.8))

ax1.set_xlim(0, 0.5)
ax1.set_xlabel("Mistag", fontsize=15)
ax1.set_ylabel("Entries", fontsize=15)
ax1.set_title(r"Generated $\eta$ and $\omega$", fontsize=15)
ax1.legend(loc="lower right", fontsize=15)

ft.draw_calibration_curve(tc["T1"], ax=ax2, save=False, title="Calibration", title_fontsize=14, legend_fontsize=15, params_fontsize=10, axis_fontsize=15)
fig.tight_layout()