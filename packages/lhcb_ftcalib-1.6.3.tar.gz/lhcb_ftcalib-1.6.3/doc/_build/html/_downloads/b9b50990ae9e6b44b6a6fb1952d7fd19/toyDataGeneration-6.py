import lhcb_ftcalib as ft
from scripts.jpsiks_analysis import generate_data

def acceptance(t):
    return 2.0 * np.arctan(2.0 * t) / np.pi

dfJpsiKS, dfJpsiKst = generate_data(493874, acceptance=acceptance)

tc = ft.TaggerCollection()
tc.create_tagger("ToyTagger",
                 dfJpsiKst.ToyTagger_ETA,
                 dfJpsiKst.ToyTagger_DEC,
                 511 * dfJpsiKst.FLAV_DECAY,
                 tau_ps = dfJpsiKst.TAU,
                 mode="Bd")
tc.set_calibration(ft.PolynomialCalibration(2, ft.link.mistag))
tc.calibrate(quiet=True)

fig, ax = plt.subplots(1, 1, figsize=(7, 5))
ft.draw_calibration_curve(tc["ToyTagger"], ax=ax, save=False, title="Calibration", title_fontsize=14, legend_fontsize=15, params_fontsize=10, axis_fontsize=15, print_params=False)
fig.tight_layout()