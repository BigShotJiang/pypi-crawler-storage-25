import os
import re
from git import Repo
from packaging.version import Version

repo = Repo(".")

valid_version_re = r"[0-9]+\.[0-9]+\.[0-9]"

def valid_version(v: str):
    # MAJOR.MINOR.PATCH format, e.g. 1.5.6
    return re.search(valid_version_re, v)

def strip_version(v: str):
    return re.search(valid_version_re, v).group(0)

def valid_version_file(v: str):
    # Is __version__ variable set to a pure version string?
    return v.strip() == f'__version__ = "{strip_version(v)}"'


def test_version_file():
    assert valid_version_file(open("src/lhcb_ftcalib/_version.py", "r").read()), "_version.py does not have the expected format. __version__ must be set to a pure version string, e.g. __version__ = \"1.5.6\""

MASTER_VERSION_PY = strip_version((repo.commit("origin/master").tree / "src/lhcb_ftcalib/_version.py").data_stream.read().decode())
CURRENT_VERSION_PY = strip_version(open("src/lhcb_ftcalib/_version.py", "r").read())
on_master: bool = os.environ["CURRENT_BRANCH"] == "master"
print("Master branch version:", MASTER_VERSION_PY)
print("This version:",          CURRENT_VERSION_PY)

def test_release_name():
    assert on_master or valid_version(CURRENT_VERSION_PY), "Version specified in _version.py is not of the form X.Y.Z"

def test_release_is_newer():
    assert on_master or Version(CURRENT_VERSION_PY) > Version(MASTER_VERSION_PY), f"New release must have strictly newer version than master (>{MASTER_VERSION_PY}). Found: {CURRENT_VERSION_PY} in _version.py"
