import os
import pytest
import numpy as np
import uproot
import pandas as pd
import argparse
import lhcb_ftcalib as ft
from lhcb_ftcalib.printing import FTCalibException, MissingFile, MissingTree, MissingBranch
from lhcb_ftcalib.TaggerCollection import TaggerCollection
from utils import example_eta_distributions, check_dataframe_ivalid_values, check_performance_numbers

from lhcb_ftcalib.__main__ import read_file, validate_ops, run, load_data

ft.warnings.print_warning_summary = False

def delete_file(F):
    if os.path.exists(F):
        os.remove(F)
        print("Removed", F)


def parse_args(argv):
    argv = argv.split(" ")

    parser = argparse.ArgumentParser(description="TEST")
    parser.add_argument("rootfile",  type=str)
    parser.add_argument("-t",         dest="taggers",   type=str, nargs="+", default=[])
    parser.add_argument("-SS",        dest="SStaggers", type=str, nargs="+", default=[])
    parser.add_argument("-OS",        dest="OStaggers", type=str, nargs="+", default=[])
    parser.add_argument("-id",        dest="id_branch", type=str)
    parser.add_argument("-mode",      dest="mode",      type=str, choices=["Bu", "Bd", "Bs"],)
    parser.add_argument("-tau",       dest="tau",       type=str)
    parser.add_argument("-tauerr",    dest="tauerr",    type=str)
    parser.add_argument("-timeunit",  dest="timeunit",  type=str, default="ns", choices=["ns", "ps", "fs"])
    parser.add_argument("-weights",   dest="weights",   type=str)
    parser.add_argument("-op",        dest="op",        type=str, required=True,  nargs='+', choices=["calibrate", "combine", "apply"])
    parser.add_argument("-write",     dest="write",     type=str)
    parser.add_argument("-selection", dest="selection", type=str)
    parser.add_argument("-input_cal", dest="input_cal", type=str)
    parser.add_argument("-plot",      dest="plot",       action="store_true")
    parser.add_argument("-n",         default=-1, dest="nmax")
    parser.add_argument("-skip",      default=0, dest="skipfirst")
    parser.add_argument("-keep_branches", dest="keep_branches", type=str)

    parser.add_argument("-fun",  type=str, dest="fun", nargs=2, default=["poly", 2])
    parser.add_argument("-link", type=str, dest="link", choices=["mistag", "logit", "probit", "cauchit"], default="mistag")

    parser.add_argument("-i", action="store_true", dest="interactive")
    parser.add_argument("-filetype", type=str, default="root", choices=["root", "csv"], dest="filetype")
    return parser.parse_args(argv)


def test_prepare_cli_tests():
    GENERATOR_SEED = 123456

    if not os.path.exists("tests/cli"):
        os.mkdir("tests/cli")

    def check_calibration_valid(df):
        assert df.FLAV_DECAY.nunique() == 2
        assert df.FLAV_DECAY.isin([-1, 1]).all()
        assert np.abs(np.mean(df.FLAV_DECAY)) < 0.01

        assert df.FLAV_PROD.nunique() == 2
        assert df.FLAV_PROD.isin([-1, 1]).all()
        assert np.abs(np.mean(df.FLAV_PROD)) < 0.01

    if not os.path.exists("tests/cli/toy_data.root"):
        poly1 = ft.PolynomialCalibration(2, ft.link.mistag)

        tag_effs = [0.9, 0.8, 0.6]

        def make_tree(treename, N, calib_func, param_set, weight=None, **physics_params):
            gen = ft.toy_generator.ToyGenerator(0, 20, seed=GENERATOR_SEED)
            gen.setPhysics(**physics_params)
            i = 0
            for params_plus, params_minus in param_set:
                gen.add_tagger(f"TOY{i}", params_plus = params_plus, params_minus = params_minus, eta_shape_func=example_eta_distributions[0], calib_func=calib_func, efficiency=tag_effs[i % len(tag_effs)])
                i += 1

            if weight is not None:
                DATA = pd.concat([gen.generate(N, acceptance="arctan", precision=1000), weight], axis=1)
                check_dataframe_ivalid_values(DATA)
                check_calibration_valid(DATA)
                File[treename] = DATA
            else:
                DATA = gen.generate(N, acceptance="arctan", precision=1000)
                check_dataframe_ivalid_values(DATA)
                check_calibration_valid(DATA)
                File[treename] = DATA

        param_set = [
            ([0, 0], [0, 0]),
            ([0.01, 0.3], [0.01, 0]),
            ([0.01, -0.05], [0.01, 0.1])
        ]
        param_set_SSOS = [
            ([0, 0], [0, 0]),
            ([0.01, 0.3], [0.01, 0]),
            ([0.01, -0.05], [0.01, 0.1]),
            ([0.01, -0.05], [0.01, 0.1])
        ]

        with uproot.recreate("tests/cli/toy_data.root") as File:
            make_tree("BU_TOY", N=30000, calib_func=poly1, param_set=param_set, weight=None, flavour_specific=True, neutral_mode=False, Lifetime=1.52)
            make_tree("BD_TOY", N=30000, calib_func=poly1, param_set=param_set, weight=None, flavour_specific=True, neutral_mode=True,  Lifetime=1.52, DM=0.5065, DG=0, C=1, Cbar=-1)
            make_tree("BU_TOY_SSOS", N=20000, calib_func=poly1, param_set=param_set_SSOS, weight=None, flavour_specific=True, neutral_mode=False,  Lifetime=1.52, DM=0.5065, DG=0)


def test_read_file():
    F = "tests/cli/toy_data.root"
    args = parse_args(f"{F} -t TOY0 -id FLAV_DECAY -mode Bu -op calibrate")

    # Missing file exception
    with pytest.raises(MissingFile):
        read_file(args.rootfile + "MISSING",
                  TAGGERS = args.taggers,
                  ID      = args.id_branch,
                  WEIGHT  = args.weights)

    # Missing tree
    with pytest.raises(MissingTree):
        read_file(args.rootfile + ":MISSING",
                  TAGGERS = args.taggers,
                  ID      = args.id_branch,
                  WEIGHT  = args.weights)

    # Missing branch
    with pytest.raises(MissingBranch):
        read_file(args.rootfile,
                  TAGGERS = args.taggers,
                  ID      = args.id_branch + "MISSING",
                  WEIGHT  = args.weights)


def test_validate_ops():
    args = parse_args("FILE -t TOY0 -id FLAV_DECAY -mode Bu -op calibrate")
    validate_ops(args)
    args = parse_args("FILE -t TOY0 -id FLAV_DECAY -mode Bu -op calibrate combine")
    validate_ops(args)
    args = parse_args("FILE -t TOY0 -id FLAV_DECAY -mode Bu -op calibrate combine calibrate")
    validate_ops(args)
    args = parse_args("FILE -t TOY0 -id FLAV_DECAY -mode Bu -op apply")
    validate_ops(args)
    args = parse_args("FILE -t TOY0 -id FLAV_DECAY -mode Bu -op apply combine")
    validate_ops(args)

    with pytest.raises(FTCalibException):
        args = parse_args("FILE -t TOY0 -id FLAV_DECAY -mode Bu -op apply apply")
        validate_ops(args)
    with pytest.raises(FTCalibException):
        args = parse_args("FILE -t TOY0 -id FLAV_DECAY -mode Bu -op calibrate calibrate")
        validate_ops(args)
    with pytest.raises(FTCalibException):
        args = parse_args("FILE -t TOY0 -id FLAV_DECAY -mode Bu -op apply calibrate")
        validate_ops(args)
    with pytest.raises(FTCalibException):
        args = parse_args("FILE -t TOY0 -id FLAV_DECAY -mode Bu -op calibrate apply")
        validate_ops(args)
    with pytest.raises(FTCalibException):
        validate_ops(args)
        args = parse_args("FILE -t TOY0 -id FLAV_DECAY -mode Bu -op calibrate combine calibrate calibrate")


def compare_dataframe_to_file(filename, key, df):
    assert os.path.exists(filename)
    fdata = uproot.open(filename)[key].arrays(library="pd")
    for branch in fdata.columns.values:
        if branch in df:
            print(f"Comparing branch {branch} ...")
            b1 = np.array(fdata[branch])
            b2 = np.array(df[branch])
            if not all(np.isclose(b1, b2)):
                print("FAIL")
                print("CLI ", b1[b1 != b2])
                print("API ", b2[b1 != b2])
                raise AssertionError
            print("PASSED")


def test_run_calibrate_Bu():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/cli/test_calibrate_Bu"
    delete_file(testfile + ".json")
    delete_file(testfile + ".root")
    F = "tests/cli/toy_data.root"
    args = parse_args(f"{F}:BU_TOY -t TOY0 TOY1 TOY2 -id FLAV_DECAY -mode Bu -op calibrate -write {testfile} -plot")

    loadplan = read_file(args.rootfile,
                         TAGGERS = args.taggers,
                         ID      = args.id_branch)

    run(args, load_data(args, loadplan, "branches"), loadplan)

    # API
    df = uproot.open(F)["BU_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY"], library="pd")
    check_dataframe_ivalid_values(df)
    tc = TaggerCollection()
    tc.create_tagger("TOY0_#0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY1_#0", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY2_#0", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    check_performance_numbers(tc)
    tc.calibrate()
    apidata = tc.get_dataframe(calibrated=True)
    compare_dataframe_to_file(testfile + ".root", "TaggingTree", apidata)

    check_performance_numbers(tc)
    check_dataframe_ivalid_values(apidata)

    delete_file(testfile + ".json")
    delete_file(testfile + ".root")


def test_run_calibrate_combine_Bu():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/cli/test_calibrate_combine_Bu"
    delete_file(testfile + ".json")
    delete_file(testfile + ".root")
    F = "tests/cli/toy_data.root"
    args = parse_args(f"{F}:BU_TOY -t TOY0 TOY1 TOY2 -id FLAV_DECAY -mode Bu -op calibrate combine -write {testfile}")

    loadplan = read_file(args.rootfile,
                         TAGGERS = args.taggers,
                         ID      = args.id_branch)

    run(args, load_data(args, loadplan, "branches"), loadplan)
    # API
    df = uproot.open(F)["BU_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY"], library="pd")
    check_dataframe_ivalid_values(df)
    tc = TaggerCollection()
    tc.create_tagger("TOY0_#1", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY1_#1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY2_#1", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    check_performance_numbers(tc)
    tc.calibrate()
    apidata = tc.get_dataframe(calibrated=True)
    combination = tc.combine_taggers("Combination", calibrated=True)
    combdata = combination.get_dataframe(calibrated=False)
    for v in combdata.columns.values:
        apidata[v] = combdata[v]
    compare_dataframe_to_file(testfile + ".root", "TaggingTree", apidata)

    check_performance_numbers(tc)
    check_dataframe_ivalid_values(apidata)
    check_performance_numbers(combination)
    check_dataframe_ivalid_values(combdata)

    delete_file(testfile + ".json")
    delete_file(testfile + ".root")


def test_run_calibrate_combine_calibrate_Bu():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/cli/test_calibrate_combine_calibrate_Bu"
    delete_file(testfile + ".json")
    delete_file(testfile + ".root")
    F = "tests/cli/toy_data.root"
    args = parse_args(f"{F}:BU_TOY -t TOY0 TOY1 TOY2 -id FLAV_DECAY -mode Bu -op calibrate combine calibrate -write {testfile}")

    loadplan = read_file(args.rootfile,
                         TAGGERS = args.taggers,
                         ID      = args.id_branch)

    run(args, load_data(args, loadplan, "branches"), loadplan)
    # API
    df = uproot.open(F)["BU_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY"], library="pd")
    check_dataframe_ivalid_values(df)
    tc = TaggerCollection()
    tc.create_tagger("TOY0_#2", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY1_#2", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY2_#2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    check_performance_numbers(tc)
    tc.calibrate()
    apidata = tc.get_dataframe(calibrated=True)
    combination = tc.combine_taggers("Combination", calibrated=True)
    check_performance_numbers(combination)
    combination.calibrate()
    combdata = combination.get_dataframe(calibrated=False)
    combdata_calib = combination.get_dataframe(calibrated=True)
    for v in combdata.columns.values:
        apidata[v] = combdata[v]
    for v in combdata_calib.columns.values:
        apidata[v] = combdata_calib[v]
    compare_dataframe_to_file(testfile + ".root", "TaggingTree", apidata)

    check_performance_numbers(tc)
    check_dataframe_ivalid_values(apidata)
    check_performance_numbers(combination)
    check_dataframe_ivalid_values(combdata)
    check_dataframe_ivalid_values(combdata_calib)

    delete_file(testfile + ".json")
    delete_file(testfile + ".root")


def test_run_calibrate_Bd():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/cli/test_calibrate_Bd"
    delete_file(testfile + ".json")
    delete_file(testfile + ".root")
    F = "tests/cli/toy_data.root"
    args = parse_args(f"{F}:BD_TOY -t TOY0 TOY1 TOY2 -id FLAV_DECAY -mode Bd -op calibrate -tau TAU -timeunit ps -write {testfile}")

    loadplan = read_file(args.rootfile,
                         TAGGERS = args.taggers,
                         ID      = args.id_branch,
                         TAU     = args.tau)

    run(args, load_data(args, loadplan, "branches"), loadplan)

    # API
    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU"], library="pd")
    check_dataframe_ivalid_values(df)
    tc = TaggerCollection()
    tc.create_tagger("TOY0_#3", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY1_#3", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY2_#3", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    check_performance_numbers(tc)
    tc.calibrate()
    apidata = tc.get_dataframe()
    compare_dataframe_to_file(testfile + ".root", "TaggingTree", apidata)

    check_performance_numbers(tc)
    check_dataframe_ivalid_values(apidata)

    delete_file(testfile + ".json")
    delete_file(testfile + ".root")


def test_run_calibrate_Bd_selection_vartype1():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/cli/test_calibrate_Bd_sel_v1"
    delete_file(testfile + ".json")
    delete_file(testfile + ".root")
    F = "tests/cli/toy_data.root"
    args = parse_args(f"{F}:BD_TOY -t TOY0 TOY1 TOY2 -id FLAV_DECAY -mode Bd -op calibrate -tau TAU -timeunit ps -write {testfile} -selection \"TAU>0.5\"")

    loadplan = read_file(args.rootfile,
                         TAGGERS = args.taggers,
                         ID      = args.id_branch,
                         TAU     = args.tau,
                         SEL     = args.selection)

    run(args, load_data(args, loadplan, "branches"), loadplan)

    # API
    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU"], library="pd")
    check_dataframe_ivalid_values(df)
    selection = df.TAU > 0.5
    tc = TaggerCollection()
    tc.create_tagger("TOY0_#4", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY1_#4", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY2_#4", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    check_performance_numbers(tc)
    tc.calibrate()
    apidata = tc.get_dataframe()
    compare_dataframe_to_file(testfile + ".root", "TaggingTree", apidata)

    check_performance_numbers(tc)
    check_dataframe_ivalid_values(apidata)

    delete_file(testfile + ".json")
    delete_file(testfile + ".root")


def test_run_calibrate_Bd_selection_vartype2():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/cli/test_calibrate_Bd_sel_v2"
    delete_file(testfile + ".json")
    delete_file(testfile + ".root")
    F = "tests/cli/toy_data.root"
    args = parse_args(f"{F}:BD_TOY -t TOY0 TOY1 TOY2 -id FLAV_DECAY -mode Bd -op calibrate -tau TAU -timeunit ps -write {testfile} -selection \"eventNumber%2==0\"")

    loadplan = read_file(args.rootfile,
                         TAGGERS = args.taggers,
                         ID      = args.id_branch,
                         TAU     = args.tau,
                         SEL     = args.selection)

    run(args, load_data(args, loadplan, "branches"), loadplan)

    # API
    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU", "eventNumber"], library="pd")
    check_dataframe_ivalid_values(df)
    selection = df.eventNumber % 2 == 0
    tc = TaggerCollection()
    tc.create_tagger("TOY0_#5", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY1_#5", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY2_#5", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    check_performance_numbers(tc)
    tc.calibrate()
    apidata = tc.get_dataframe()
    compare_dataframe_to_file(testfile + ".root", "TaggingTree", apidata)

    check_performance_numbers(tc)
    check_dataframe_ivalid_values(apidata)

    delete_file(testfile + ".json")
    delete_file(testfile + ".root")


def test_run_calibrate_combine_Bd():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/cli/test_calibrate_combine_Bd"
    delete_file(testfile + ".json")
    delete_file(testfile + ".root")
    F = "tests/cli/toy_data.root"
    args = parse_args(f"{F}:BD_TOY -t TOY0 TOY1 TOY2 -id FLAV_DECAY -mode Bd -op calibrate combine -tau TAU -timeunit ps -write {testfile}")

    loadplan = read_file(args.rootfile,
                         TAGGERS = args.taggers,
                         ID      = args.id_branch,
                         TAU     = args.tau)

    run(args, load_data(args, loadplan, "branches"), loadplan)
    # API
    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU"], library="pd")
    check_dataframe_ivalid_values(df)
    tc = TaggerCollection()
    tc.create_tagger("TOY0_#6", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY1_#6", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY2_#6", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    check_performance_numbers(tc)
    tc.calibrate()
    combination = tc.combine_taggers("Combination", calibrated=True)
    apidata = tc.get_dataframe(calibrated=True)
    combdata = combination.get_dataframe(calibrated=False)
    for v in combdata.columns.values:
        apidata[v] = combdata[v]
    compare_dataframe_to_file(testfile + ".root", "TaggingTree", apidata)

    check_performance_numbers(tc)
    check_dataframe_ivalid_values(apidata)
    check_performance_numbers(combination)
    check_dataframe_ivalid_values(combdata)

    delete_file(testfile + ".json")
    delete_file(testfile + ".root")


def test_run_calibrate_combine_calibrate_Bd():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/cli/test_calibrate_combine_calibrate_Bd"
    delete_file(testfile + ".json")
    delete_file(testfile + ".root")
    F = "tests/cli/toy_data.root"
    args = parse_args(f"{F}:BD_TOY -t TOY0 TOY1 TOY2 -id FLAV_DECAY -mode Bd -op calibrate combine calibrate -tau TAU -timeunit ps -write {testfile}")

    loadplan = read_file(args.rootfile,
                         TAGGERS = args.taggers,
                         ID      = args.id_branch,
                         TAU     = args.tau)

    run(args, load_data(args, loadplan, "branches"), loadplan)
    # API
    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU"], library="pd")
    check_dataframe_ivalid_values(df)
    tc = TaggerCollection()
    tc.create_tagger("TOY0_#7", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY1_#7", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY2_#7", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    check_performance_numbers(tc)
    tc.calibrate()
    combination = tc.combine_taggers("Combination", calibrated=True)
    combination.calibrate()
    apidata = tc.get_dataframe(calibrated=True)
    combdata = combination.get_dataframe(calibrated=False)
    combdata_calib = combination.get_dataframe(calibrated=True)
    for v in combdata.columns.values:
        apidata[v] = combdata[v]
    for v in combdata_calib.columns.values:
        apidata[v] = combdata_calib[v]
    compare_dataframe_to_file(testfile + ".root", "TaggingTree", apidata)

    check_performance_numbers(tc)
    check_dataframe_ivalid_values(apidata)
    check_performance_numbers(combination)
    check_dataframe_ivalid_values(combdata)
    check_dataframe_ivalid_values(combdata_calib)

    delete_file(testfile + ".json")
    delete_file(testfile + ".root")


def test_run_calibrate_combine_calibrate_Bd_selection():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/cli/test_calibrate_combine_calibrate_Bd_sel"
    delete_file(testfile + ".json")
    delete_file(testfile + ".root")
    F = "tests/cli/toy_data.root"
    args = parse_args(f"{F}:BD_TOY -t TOY0 TOY1 TOY2 -id FLAV_DECAY -mode Bd -op calibrate combine calibrate -tau TAU -timeunit ps -selection eventNumber%2==0 -write {testfile}")

    loadplan = read_file(args.rootfile,
                         TAGGERS = args.taggers,
                         ID      = args.id_branch,
                         TAU     = args.tau,
                         SEL     = args.selection)

    run(args, load_data(args, loadplan, "branches"), loadplan)
    # API
    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU", "eventNumber"], library="pd")
    check_dataframe_ivalid_values(df)

    selection = df.eventNumber % 2 == 0
    tc = TaggerCollection()
    tc.create_tagger("TOY0_#8", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY1_#8", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY2_#8", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    check_performance_numbers(tc)
    tc.calibrate()
    combination = tc.combine_taggers("Combination", calibrated=True, next_selection=None)
    combination.calibrate()
    apidata = tc.get_dataframe(calibrated=True)
    combdata = combination.get_dataframe(calibrated=False)
    combdata_calib = combination.get_dataframe(calibrated=True)
    for v in combdata.columns.values:
        apidata[v] = combdata[v]
    for v in combdata_calib.columns.values:
        apidata[v] = combdata_calib[v]
    compare_dataframe_to_file(testfile + ".root", "TaggingTree", apidata)

    check_performance_numbers(tc)
    check_dataframe_ivalid_values(apidata)
    check_performance_numbers(combination)
    check_dataframe_ivalid_values(combdata)
    check_dataframe_ivalid_values(combdata_calib)

    delete_file(testfile + ".json")
    delete_file(testfile + ".root")


def test_run_calibrate_combine_calibrate_Bd_double_selection():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/cli/test_calibrate_combine_calibrate_Bd_sel"
    delete_file(testfile + ".json")
    delete_file(testfile + ".root")
    F = "tests/cli/toy_data.root"
    args = parse_args(f"{F}:BD_TOY -t TOY0 TOY1 TOY2 -id FLAV_DECAY -mode Bd -op calibrate combine calibrate -tau TAU -timeunit ps -selection eventNumber%2==0;eventNumber%3==2 -write {testfile}")

    loadplan = read_file(args.rootfile,
                         TAGGERS = args.taggers,
                         ID      = args.id_branch,
                         TAU     = args.tau,
                         SEL     = args.selection)

    run(args, load_data(args, loadplan, "branches"), loadplan)
    # API
    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU", "eventNumber"], library="pd")
    check_dataframe_ivalid_values(df)
    selection = df.eventNumber % 2 == 0
    comb_selection = df.eventNumber % 3 == 2
    tc = TaggerCollection()
    tc.create_tagger("TOY0_#9", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY1_#9", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY2_#9", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    check_performance_numbers(tc)
    tc.calibrate()
    combination = tc.combine_taggers("Combination", calibrated=True, next_selection=comb_selection)
    combination.calibrate()
    apidata = tc.get_dataframe(calibrated=True)
    combdata = combination.get_dataframe(calibrated=False)
    combdata_calib = combination.get_dataframe(calibrated=True)
    for v in combdata.columns.values:
        apidata[v] = combdata[v]
    for v in combdata_calib.columns.values:
        apidata[v] = combdata_calib[v]
    compare_dataframe_to_file(testfile + ".root", "TaggingTree", apidata)

    check_performance_numbers(tc)
    check_dataframe_ivalid_values(apidata)
    check_performance_numbers(combination)
    check_dataframe_ivalid_values(combdata)
    check_dataframe_ivalid_values(combdata_calib)

    delete_file(testfile + ".json")
    delete_file(testfile + ".root")
