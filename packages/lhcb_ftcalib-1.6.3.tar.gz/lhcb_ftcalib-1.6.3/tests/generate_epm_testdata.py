# Copyright (C) 2026 Q. Führing & V. Jevtic
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from functools import partial
import os
import sys
import pandas as pd
import uproot
import numpy as np

import lhcb_ftcalib as ft
from utils import example_eta_distributions
import matplotlib.pyplot as plt


def generate_reference_data(N):
    if not os.path.exists("tests/epm_reference_data"):
        os.mkdir("tests/epm_reference_data")

    with uproot.recreate("tests/epm_reference_data/reference.root") as File:
        GENERATOR_SEED = 4242424242
        poly1_MISTAG = ft.PolynomialCalibration(2, ft.link.mistag)
        poly2_MISTAG = ft.PolynomialCalibration(3, ft.link.mistag)
        poly1_LOGIT  = ft.PolynomialCalibration(2, ft.link.logit)

        mass_range = [5000.0, 6000.0]
        DGs_EPM = 0.0913
        DGd_EPM = 0
        DMd_EPM = 0.51
        DMs_EPM = 17.761
        LIFE_EPM = 1.52

        param_set_poly1 = [
            ([0, 0], [0, 0]),
            ([0.01, 0.3], [0.01, 0]),
            ([0.01, -0.05], [0.01, 0.1])
        ]

        param_set_poly2 = [
            ([0, 0, 0], [0, 0, 0]),
            ([0.01, 0.3, -0.03], [0.01, 0, 0.04]),
            ([0.01, -0.05, -0.3], [0.01, 0.1, 0.8])
        ]

        fake_weight = pd.DataFrame({"WEIGHT" : np.random.gumbel(loc=1, scale=0.08, size=N)}, dtype=np.float32)
        fake_weight.WEIGHT -= (np.mean(fake_weight.WEIGHT)-1)

        def fill_tree(treename, calib_func, param_set, weight, tauerr:bool, **physics_params):
            gen = ft.toy_generator.ToyGenerator(0, 20, seed=GENERATOR_SEED)
            gen.setPhysics(**physics_params)
            gen.add_tagger("TOY0", params_plus = param_set[0][0], params_minus = param_set[0][1], eta_shape_func=example_eta_distributions[0], calib_func=calib_func, efficiency=0.9)
            gen.add_tagger("TOY1", params_plus = param_set[1][0], params_minus = param_set[1][1], eta_shape_func=example_eta_distributions[1], calib_func=calib_func, efficiency=0.8)
            gen.add_tagger("TOY2", params_plus = param_set[2][0], params_minus = param_set[2][1], eta_shape_func=example_eta_distributions[2], calib_func=calib_func, efficiency=0.6)

            if weight is not None:
                df = pd.concat([gen.generate(N, tau_error_falloff=1/0.045 if tauerr else None, acceptance="arctan", precision=1000), weight], axis=1)
            else:
                df = gen.generate(N, tau_error_falloff=1/0.045 if tauerr else None, acceptance="arctan", precision=1000)
            dtypes = {col: df[col].dtype for col in df.columns}
            File.mktree(treename, dtypes)
            File[treename].extend({col: df[col].to_numpy(dtype=dtypes[col]) for col in df.columns})

        fill_tree("BU_POLY1_MISTAG", poly1_MISTAG, param_set_poly1, weight=fake_weight, tauerr=False, neutral_mode=False, Lifetime=LIFE_EPM, flavour_specific=True, C=1, Cbar=-1)
        fill_tree("BD_POLY1_MISTAG", poly1_MISTAG, param_set_poly1, weight=fake_weight, tauerr=False, neutral_mode=True, flavour_specific=True, DM=DMd_EPM, DG=DGd_EPM, Lifetime=LIFE_EPM, C=1, Cbar=-1)
        fill_tree("BS_POLY1_MISTAG", poly1_MISTAG, param_set_poly1, weight=None,        tauerr=True,  neutral_mode=True, flavour_specific=True, DM=DMs_EPM, DG=DGs_EPM, Lifetime=LIFE_EPM, C=1, Cbar=-1)
        fill_tree("BD_POLY1_LOGIT", poly1_LOGIT,  param_set_poly1,  weight=None,        tauerr=False, neutral_mode=True, flavour_specific=True, DM=DMd_EPM, DG=DGd_EPM, Lifetime=LIFE_EPM, C=1, Cbar=-1)
        fill_tree("BD_POLY2_MISTAG", poly2_MISTAG, param_set_poly2, weight=None,        tauerr=False, neutral_mode=True, flavour_specific=True, DM=DMd_EPM, DG=DGd_EPM, Lifetime=LIFE_EPM, C=1, Cbar=-1)

        def signal_pdf(X, mu, sigma):
            # Normalized gaussian distribution
            return 1/(sigma * np.sqrt(2 * np.pi)) * np.exp(-0.5 * ((X - mu) / sigma) ** 2)
            # return ft.toy_generator.mass_peak(X, mu, sigma)

        def background_pdf(X, E):
            # Background component normalized to mass range
            return np.exp(-E * X) / (np.exp(-E * mass_range[0]) - np.exp(-E * mass_range[1]))

        signal_gen     = ft.ToyGenerator(0, 20, seed=GENERATOR_SEED)
        background_gen = ft.ToyGenerator(0, 20, seed=GENERATOR_SEED)
        signal_gen.setPhysics(neutral_mode=True, flavour_specific=True, DM=DMd_EPM, DG=DGd_EPM, Lifetime=LIFE_EPM, C=1, Cbar=-1)
        background_gen.setPhysics(neutral_mode=True, flavour_specific=True, DM=DMd_EPM, DG=DGd_EPM, Lifetime=LIFE_EPM, C=0, Cbar=0) # Useless for tagging
        signal_gen.add_tagger("TOY0", params_plus = param_set_poly1[0][0], params_minus = param_set_poly1[0][1], eta_shape_func=example_eta_distributions[0], calib_func=poly1_MISTAG, efficiency=0.9)
        signal_gen.add_tagger("TOY1", params_plus = param_set_poly1[1][0], params_minus = param_set_poly1[1][1], eta_shape_func=example_eta_distributions[1], calib_func=poly1_MISTAG, efficiency=0.8)
        signal_gen.add_tagger("TOY2", params_plus = param_set_poly1[2][0], params_minus = param_set_poly1[2][1], eta_shape_func=example_eta_distributions[2], calib_func=poly1_MISTAG, efficiency=0.6)
        background_gen.add_tagger("TOY0", params_plus = param_set_poly1[0][0], params_minus = param_set_poly1[0][1], eta_shape_func=example_eta_distributions[0], calib_func=poly1_MISTAG, efficiency=0.9)
        background_gen.add_tagger("TOY1", params_plus = param_set_poly1[1][0], params_minus = param_set_poly1[1][1], eta_shape_func=example_eta_distributions[1], calib_func=poly1_MISTAG, efficiency=0.8)
        background_gen.add_tagger("TOY2", params_plus = param_set_poly1[2][0], params_minus = param_set_poly1[2][1], eta_shape_func=example_eta_distributions[2], calib_func=poly1_MISTAG, efficiency=0.6)

        multi_gen = ft.toy_generator.MultiComponentToyGenerator(mass_range)
        Nsig = N // 3
        multi_gen.add_component(True, Nsig, signal_gen, partial(signal_pdf, mu=5279, sigma=25))
        multi_gen.add_component(False, N - Nsig, background_gen, partial(background_pdf, E=0.003))

        df = multi_gen.generate()
        dtypes = {col: df[col].dtype for col in df.columns}
        File.mktree("BD_POLY1_MISTAG_SWEIGHTS", dtypes)
        File["BD_POLY1_MISTAG_SWEIGHTS"].extend({col: df[col].to_numpy(dtype=dtypes[col]) for col in df.columns})


if __name__ == "__main__":
    if len(sys.argv) != 2:
        generate_reference_data(30000)
    else:
        generate_reference_data(int(sys.argv[1]))
