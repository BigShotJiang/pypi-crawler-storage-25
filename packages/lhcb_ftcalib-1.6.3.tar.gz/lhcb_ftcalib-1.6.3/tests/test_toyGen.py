"""Unit tests for ToyGenerator and DistributionSampler """
from __future__ import annotations

import os
import sys

import numpy as np
import pandas as pd
import pytest

import lhcb_ftcalib as ft
from lhcb_ftcalib.toy_generator import DistributionSampler

# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def flat(t: np.ndarray) -> np.ndarray:
    return np.ones_like(t, dtype=float)


def gaussian_eta(x: np.ndarray) -> np.ndarray:
    return np.exp(-0.5 * ((x - 0.3) / 0.03) ** 2)


def make_generator(seed: int = 0, neutral_mode: bool = False, flavour_specific: bool = True, **physics_kwargs) -> ft.ToyGenerator:
    """Factory: creates a ToyGenerator with one PolynomialCalibration(2) tagger named 'T'."""
    gen = ft.ToyGenerator(0, 15, seed=seed)
    gen.setPhysics(neutral_mode=neutral_mode, flavour_specific=flavour_specific, **physics_kwargs)
    gen.add_tagger(
        "T",
        params_plus=[0.05, 0.30],
        params_minus=[0.03, 0.28],
        eta_shape_func=gaussian_eta,
        calib_func=ft.PolynomialCalibration(2, ft.link.mistag),
    )
    return gen


# ===========================================================================
# DistributionSampler
# ===========================================================================

class TestDistributionSampler:

    def test_samples_within_extended_range(self):
        """All samples must lie within the smearing-extended bounds [xmin-dx, xmax+dx]."""
        np.random.seed(0)
        xmin, xmax, precision = 0.0, 1.0, 500
        sampler = DistributionSampler(xmin, xmax, precision, lambda x: np.ones_like(x))
        dx = (xmax - xmin) / precision
        samples = sampler(10_000)
        assert np.all(samples >= xmin - dx)
        assert np.all(samples <= xmax + dx)

    def test_uniform_distribution_mean(self):
        """Mean of samples from a flat distribution on [0, 1] should be ~0.5."""
        np.random.seed(1)
        sampler = DistributionSampler(0.0, 1.0, 1000, lambda x: np.ones_like(x))
        samples = sampler(50_000)
        assert abs(np.mean(samples) - 0.5) < 0.02

    def test_gaussian_distribution_mean(self):
        """Mean of samples from a Gaussian centred at 0.3 should be ~0.3."""
        np.random.seed(2)
        sampler = DistributionSampler(0.001, 0.5, 2000, gaussian_eta)
        samples = sampler(30_000)
        assert abs(np.mean(samples) - 0.3) < 0.005

    def test_function_area_constant(self):
        """Integral of the constant function 1 over [0, 2] should equal 2."""
        sampler = DistributionSampler(0.0, 2.0, 2000, lambda x: np.ones_like(x))
        assert abs(sampler.functionArea(5000) - 2.0) < 0.01

    def test_function_area_gaussian(self):
        """Integral of a Gaussian should match sigma * sqrt(2*pi) to within 1 %."""
        sigma = 0.03
        sampler = DistributionSampler(0.0, 0.5, 2000, gaussian_eta)
        expected = sigma * np.sqrt(2 * np.pi)
        assert abs(sampler.functionArea(5000) - expected) / expected < 0.01


# ===========================================================================
# ToyGenerator: configuration
# ===========================================================================

class TestToyGeneratorConfiguration:

    def test_default_cpv_parameters(self):
        """All CPV parameters must be zero at construction."""
        gen = ft.ToyGenerator(0, 15, seed=0)
        assert gen.S == 0
        assert gen.C == 0
        assert gen.Sbar == 0
        assert gen.Cbar == 0
        assert gen.DM == pytest.approx(0.5065)
        assert gen.DG == 0
        assert gen.Aprod == 0
        assert gen.Adet == 0

    def test_set_cpv_parameters(self):
        """setCPVParameters must update all relevant attributes."""
        gen = ft.ToyGenerator(0, 15)
        gen.setPhysics(neutral_mode=True, flavour_specific=True, DM=17.8, DG=0.09, S=0.5, Sbar=-0.4, C=0.1, Cbar=-0.1)
        assert gen.DM == pytest.approx(17.8)
        assert gen.DG == pytest.approx(0.09)
        assert gen.S == pytest.approx(0.5)
        assert gen.Sbar == pytest.approx(-0.4)
        assert gen.C == pytest.approx(0.1)
        assert gen.Cbar == pytest.approx(-0.1)

    def test_add_tagger_registers_name(self):
        """After add_tagger, one tagger with the given name must be registered."""
        gen = ft.ToyGenerator(0, 15)
        gen.add_tagger("MyTagger", [0.05, 0.3], [0.03, 0.28], gaussian_eta,
                       ft.PolynomialCalibration(2, ft.link.mistag))
        assert len(gen._toy_taggers) == 1
        assert gen._toy_taggers[0].name == "MyTagger"

    def test_add_multiple_taggers(self):
        """Multiple taggers must all be stored."""
        gen = ft.ToyGenerator(0, 15)
        gen.add_tagger("T1", [0.05, 0.30], [0.03, 0.28], gaussian_eta,
                       ft.PolynomialCalibration(2, ft.link.mistag))
        gen.add_tagger("T2", [0.04, 0.32], [0.02, 0.27], gaussian_eta,
                       ft.PolynomialCalibration(2, ft.link.mistag))
        assert len(gen._toy_taggers) == 2

    def test_add_tagger_param_length_mismatch_raises(self):
        """Mismatched params_plus length vs calib_func.npar must raise AssertionError."""
        gen = ft.ToyGenerator(0, 15)
        with pytest.raises(AssertionError):
            gen.add_tagger("T", [0.05, 0.3, 0.0], [0.03, 0.28], gaussian_eta,
                           ft.PolynomialCalibration(2, ft.link.mistag))


# ===========================================================================
# ToyGenerator.bdecay: physics properties
# ===========================================================================

class TestBDecay:

    T = np.linspace(0.01, 15.0, 500)

    def test_positivity_all_modes(self):
        """bdecay must return non-negative values for all four production/decay combinations."""
        gen = make_generator(neutral_mode=True, S=0.7, C=0.2, DM=0.5065, DG=0.05)
        for fprod in (+1, -1):
            for fdecay in (+1, -1):
                vals = gen.bdecay(self.T, fprod, fdecay, flat)
                assert np.all(vals >= 0), (
                    f"Negative bdecay value for fprod={fprod}, fdecay={fdecay}"
                )

    def test_no_cpv_b_bbar_symmetry(self):
        """With no CPV and no asymmetries, B and Bbar must have identical PDFs."""
        gen = ft.ToyGenerator(0, 15)
        gen.setPhysics(neutral_mode=True, flavour_specific=True, S=0, C=0, Sbar=0, Cbar=0, Aprod=0, Adet=0)
        b_to_f    = gen.bdecay(self.T, fprod=+1, fdecay=+1, acceptance=flat)
        bbar_to_f = gen.bdecay(self.T, fprod=-1, fdecay=+1, acceptance=flat)
        np.testing.assert_allclose(b_to_f, bbar_to_f, rtol=1e-10)

    def test_cpv_breaks_b_bbar_symmetry(self):
        """With S != 0, B and Bbar must have different time-dependent PDFs."""
        gen = make_generator(neutral_mode=True, S=0.7, DM=0.5065)
        b_to_f    = gen.bdecay(self.T, fprod=+1, fdecay=+1, acceptance=flat)
        bbar_to_f = gen.bdecay(self.T, fprod=-1, fdecay=+1, acceptance=flat)
        assert not np.allclose(b_to_f, bbar_to_f)

    def test_aprod_breaks_b_bbar_symmetry(self):
        """A positive production asymmetry makes the B yield larger than Bbar."""
        gen = ft.ToyGenerator(0, 15)
        gen.setPhysics(neutral_mode=False, flavour_specific=True, Aprod=0.3)  # no CPV
        b_integral    = np.trapezoid(gen.bdecay(self.T, fprod=+1, fdecay=+1, acceptance=flat), self.T)
        bbar_integral = np.trapezoid(gen.bdecay(self.T, fprod=-1, fdecay=+1, acceptance=flat), self.T)
        assert b_integral > bbar_integral

    def test_dg_changes_pdf_shape(self):
        """A non-zero DG changes the PDF shape relative to DG=0."""
        gen_dg0 = ft.ToyGenerator(0, 15)
        gen_dg0.setPhysics(neutral_mode=True, flavour_specific=True, DG=0.0)
        gen_dg1 = ft.ToyGenerator(0, 15)
        gen_dg1.setPhysics(neutral_mode=True, flavour_specific=True, DG=0.09)
        pdf0 = gen_dg0.bdecay(self.T, +1, +1, flat)
        pdf1 = gen_dg1.bdecay(self.T, +1, +1, flat)
        assert not np.allclose(pdf0, pdf1)

    def test_acceptance_scales_pdf_multiplicatively(self):
        """The acceptance function must scale the PDF point-by-point."""
        gen = ft.ToyGenerator(0, 15)
        gen.setPhysics(neutral_mode=False, flavour_specific=True)
        pdf_flat = gen.bdecay(self.T, +1, +1, flat)
        pdf_half = gen.bdecay(self.T, +1, +1, lambda t: 0.5 * np.ones_like(t))
        np.testing.assert_allclose(pdf_half, 0.5 * pdf_flat, rtol=1e-10)


# ===========================================================================
# ToyGenerator: asymmetry and final-state fraction helpers
# ===========================================================================

class TestCPVAsymmetry:

    def test_no_cpv_gives_half(self):
        """Without CPV and with zero production asymmetry, J+/(J++J-) must be 0.5."""
        gen = ft.ToyGenerator(0, 15)
        gen.setPhysics(neutral_mode=True, flavour_specific=True, Aprod=0, S=0, C=0, Sbar=0, Cbar=0, ADG=0, ADGbar=0)
        asym = gen._cpv_asymmetry(fdecay=+1, acceptance=flat, precision=2000)
        assert abs(asym - 0.5) < 1e-6

    def test_positive_aprod_raises_asymmetry(self):
        """Aprod > 0 should yield more B than Bbar, pushing the asymmetry above 0.5."""
        gen = ft.ToyGenerator(0, 15)
        gen.setPhysics(neutral_mode=True, flavour_specific=True, Aprod=0.2)
        asym = gen._cpv_asymmetry(fdecay=+1, acceptance=flat, precision=2000)
        assert asym > 0.5

    def test_negative_aprod_lowers_asymmetry(self):
        gen = ft.ToyGenerator(0, 15)
        gen.setPhysics(neutral_mode=True, flavour_specific=True, Aprod=-0.2)
        asym = gen._cpv_asymmetry(fdecay=+1, acceptance=flat, precision=2000)
        assert asym < 0.5

    def test_asymmetry_in_unit_interval(self):
        """The asymmetry must always lie in (0, 1)."""
        gen = make_generator(neutral_mode=True, S=0.7, C=0.2, DM=0.5065)
        asym = gen._cpv_asymmetry(fdecay=+1, acceptance=flat, precision=2000)
        assert 0 < asym < 1


class TestFinalStateFraction:

    def test_symmetric_params_give_half(self):
        """With all-default (symmetric) parameters, exactly half of decays go to f=+1."""
        gen = ft.ToyGenerator(0, 15)
        gen.setPhysics(neutral_mode=True, flavour_specific=True)
        frac = gen._final_state_fraction(acceptance=flat, precision=2000)
        assert abs(frac - 0.5) < 1e-6

    def test_larger_absAf_increases_fraction(self):
        """Setting |A_f| > 1 (default) should push the f=+1 fraction above 0.5."""
        gen = ft.ToyGenerator(0, 15)
        gen.setPhysics(neutral_mode=True, flavour_specific=True)
        gen.absAf = 2.0
        frac = gen._final_state_fraction(acceptance=flat, precision=2000)
        assert frac > 0.5

    def test_fraction_in_unit_interval(self):
        gen = make_generator(neutral_mode=True, S=0.5, C=0.1)
        frac = gen._final_state_fraction(acceptance=flat, precision=2000)
        assert 0 < frac < 1


# ===========================================================================
# generate(): structural correctness
# ===========================================================================

class TestGenerateStructure:
    """Tests for shape, column names, dtypes, and value ranges of generate()."""

    @classmethod
    def setup_class(cls):
        gen = make_generator(seed=111)
        cls.df = gen.generate(3000, acceptance=flat)

    def test_output_is_dataframe(self):
        assert isinstance(self.df, pd.DataFrame)

    def test_non_empty(self):
        assert len(self.df) > 0

    def test_required_columns_present(self):
        expected = {
            "PROCESS", "FLAV_PROD", "FLAV_DECAY", "FLAV_HYPOT",
            "TRUETAU", "TAU",
            "T_ETA", "T_DEC", "T_OMEGA",
        }
        assert expected.issubset(set(self.df.columns))

    def test_flav_prod_values(self):
        assert set(self.df["FLAV_PROD"].unique()).issubset({1, -1})

    def test_flav_decay_values(self):
        assert set(self.df["FLAV_DECAY"].unique()).issubset({1, -1})

    def test_flav_hypot_values(self):
        assert set(self.df["FLAV_HYPOT"].unique()).issubset({1, -1})

    def test_dec_values(self):
        assert set(self.df["T_DEC"].unique()).issubset({1, -1})

    # def test_tau_in_range(self):
    #     # DistributionSampler smears sampled values by ±½·dx, where
    #     # dx = (tmax - tmin) / precision = 15 / 1000 = 0.015, so TAU
    #     # can legitimately fall slightly below tmin.
    #     dx_half = 15.0 / 1000 / 2
    #     assert (self.df["TAU"] >= -dx_half).all()
    #     assert (self.df["TAU"] <= 15.0 + dx_half).all()
    #
    def test_truetau_in_range(self):
        dx_half = 15.0 / 1000 / 2
        assert (self.df["TRUETAU"] >= -dx_half).all()
        assert (self.df["TRUETAU"] <= 15.0 + dx_half).all()

    def test_eta_in_range(self):
        assert (self.df["T_ETA"] >= 0.0).all()
        assert (self.df["T_ETA"] <= 0.5).all()

    def test_omega_in_range(self):
        assert (self.df["T_OMEGA"] > 0.0).all()
        assert (self.df["T_OMEGA"] < 1.0).all()

    def test_output_length_close_to_requested(self):
        """After omega filtering, the dataset must retain at least 85 % of requested events."""
        assert len(self.df) >= 0.85 * 3000

    def test_two_taggers_produce_correct_columns(self):
        """A generator with two taggers must produce separate column sets for each."""
        gen = ft.ToyGenerator(0, 15, seed=0)
        gen.setPhysics(neutral_mode=False, flavour_specific=True)
        gen.add_tagger("OS", [0.05, 0.30], [0.03, 0.28], gaussian_eta,
                       ft.PolynomialCalibration(2, ft.link.mistag))
        gen.add_tagger("SS", [0.10, 0.25], [0.08, 0.22], gaussian_eta,
                       ft.PolynomialCalibration(2, ft.link.mistag))
        df = gen.generate(500, acceptance=flat)
        for prefix in ("OS", "SS"):
            for suffix in ("_ETA", "_DEC", "_OMEGA"):
                assert prefix + suffix in df.columns


# ===========================================================================
# generate(): physics content
# ===========================================================================

class TestGeneratePhysics:

    def test_cp_eigenstate_all_flav_decay_plus_one(self):
        """flavour_specific_decay=False → all events must have FLAV_DECAY == +1."""
        gen = make_generator(seed=42, S=0.7, neutral_mode=True, flavour_specific=False, DM=0.5065, DG=0)
        df = gen.generate(2000, acceptance=flat)
        assert (df["FLAV_DECAY"] == 1).all()

    def test_flavour_specific_has_both_decay_flavours(self):
        """flavour_specific_decay=True → both FLAV_DECAY = ±1 must be present."""
        gen = make_generator(seed=42, neutral_mode=True, flavour_specific=True, C=1.0, Cbar=-1.0)
        df = gen.generate(2000, acceptance=flat)
        assert (df["FLAV_DECAY"] == +1).any()
        assert (df["FLAV_DECAY"] == -1).any()

    def test_no_cpv_balanced_production(self):
        """With Aprod=0 and S=C=0, B and Bbar fractions should be within 4 % of 0.5."""
        gen = make_generator(seed=99, neutral_mode=False, flavour_specific=True, S=0, C=0, Sbar=0, Cbar=0, Aprod=0)
        df = gen.generate(20_000, acceptance=flat)
        frac_b = (df["FLAV_PROD"] == 1).mean()
        assert abs(frac_b - 0.5) < 0.04

    def test_positive_aprod_gives_more_b(self):
        """Aprod > 0 must result in more B than Bbar events."""
        gen = make_generator(seed=77, Aprod=0.3)
        df = gen.generate(20_000, acceptance=flat)
        assert (df["FLAV_PROD"] == +1).sum() > (df["FLAV_PROD"] == -1).sum()

    def test_cp_asymmetry_sign(self):
        """With S > 0, the statistic mean(FLAV_PROD * sin(DM*t)) must be negative.

        For B (fprod=+1), the decay PDF is suppressed at sin(DM*t) > 0 when S > 0,
        while for Bbar (fprod=-1) it is enhanced there.  The signed sum is therefore
        dominated by the Bbar contribution and is negative.
        """
        gen = make_generator(seed=1337, S=1.0, neutral_mode=True, flavour_specific=True, DM=0.5065)
        df = gen.generate(30_000, acceptance=flat)
        stat = np.mean(df["FLAV_PROD"].to_numpy() * np.sin(gen.DM * df["TAU"].to_numpy()))
        assert stat < 0

    def test_decay_time_mean_matches_lifetime(self):
        """With flat acceptance and no CPV, mean(TAU) should be close to the B lifetime."""
        gen = make_generator(seed=314)
        df = gen.generate(30_000, acceptance=flat)
        assert abs(df["TAU"].mean() - gen.Lifetime) < 0.1

    def test_repeated_seed_gives_identical_output(self):
        """Two generate() calls starting from the same seed must produce identical data."""
        gen1 = make_generator(seed=500)
        df1 = gen1.generate(500, acceptance=flat)
        # Re-seeding by constructing a fresh generator resets the global numpy RNG state
        gen2 = make_generator(seed=500)
        df2 = gen2.generate(500, acceptance=flat)
        pd.testing.assert_frame_equal(df1.reset_index(drop=True),
                                      df2.reset_index(drop=True))

    def test_different_seeds_give_different_output(self):
        gen1 = make_generator(seed=1)
        df1 = gen1.generate(500, acceptance=flat)
        gen2 = make_generator(seed=2)
        df2 = gen2.generate(500, acceptance=flat)
        assert not df1["TAU"].reset_index(drop=True).equals(df2["TAU"].reset_index(drop=True))
