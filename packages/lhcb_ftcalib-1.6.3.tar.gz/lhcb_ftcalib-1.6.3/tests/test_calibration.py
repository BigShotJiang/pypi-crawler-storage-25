import os
import pytest
import numpy as np
import pandas as pd
import uproot
import matplotlib.pyplot as plt
import lhcb_ftcalib as ft
from lhcb_ftcalib.plotting import calibration_lineshape
from utils import DataIntegrity, DataValidityContext, delete_file, allclose, example_eta_distributions, check_dataframe_ivalid_values, check_performance_numbers

ft.warnings.print_warning_summary = False

def test_prepare_tests():
    GENERATOR_SEED = 4242424248
    print("Uproot version:", uproot.__version__)
    if not os.path.exists("tests/calib"):
        os.mkdir("tests/calib")

    # Generate toy data for calibration testing
    if not os.path.exists("tests/calib/toy_data.root"):
        poly1 = ft.PolynomialCalibration(2, ft.link.mistag)

        with uproot.recreate("tests/calib/toy_data.root") as File:
            generatorBU = ft.toy_generator.ToyGenerator(0, 20, seed=GENERATOR_SEED)
            generatorBU.setPhysics(neutral_mode=False, flavour_specific=True, Lifetime=1.52)
            generatorBU.add_tagger("TOY0", 
                                   params_plus  = [0, 0], 
                                   params_minus = [0, 0],
                                   eta_shape_func = example_eta_distributions[0],
                                   calib_func   = poly1, 
                                   efficiency=0.9)
            generatorBU.add_tagger("TOY1", 
                                   params_plus  = [0.01, 0.3], 
                                   params_minus = [0.01, 0],
                                   eta_shape_func = example_eta_distributions[1],
                                   calib_func   = poly1, 
                                   efficiency=0.8)
            generatorBU.add_tagger("TOY2", 
                                   params_plus  = [0.01, 0], 
                                   params_minus = [0.01, 0.3],
                                   eta_shape_func = example_eta_distributions[2],
                                   calib_func   = poly1, 
                                   efficiency=0.6)
            dfBU = generatorBU.generate(30000)

            generatorBD = ft.toy_generator.ToyGenerator(0, 20, seed=GENERATOR_SEED)
            generatorBD.setPhysics(neutral_mode=True, flavour_specific=True, Lifetime=1.52, DM=0.51, DG=0, C=1, Cbar=-1)
            generatorBD.add_tagger("TOY0", 
                                   params_plus  = [0, 0], 
                                   params_minus = [0, 0],
                                   eta_shape_func = example_eta_distributions[0],
                                   calib_func   = poly1, 
                                   efficiency=0.9)
            generatorBD.add_tagger("TOY1", 
                                   params_plus  = [0.01, 0.3], 
                                   params_minus = [0.01, 0],
                                   eta_shape_func = example_eta_distributions[1],
                                   calib_func   = poly1, 
                                   efficiency=0.8)
            generatorBD.add_tagger("TOY2", 
                                   params_plus  = [0.01, 0], 
                                   params_minus = [0.01, 0.3],
                                   eta_shape_func = example_eta_distributions[2],
                                   calib_func   = poly1, 
                                   efficiency=0.6)
            dfBD = generatorBD.generate(30000)

            File["BU_TOY"] = dfBU
            File["BD_TOY"] = dfBD


def TagDataEquals(d1, d2):
    if d1 is None and d2 is None:
        return True
    equal = True
    equal &= d1._full_data.equals(d2._full_data)
    equal &= d1._tagdata.equals(d2._tagdata)

    equal &= d1.N     == d2.N
    equal &= d1.Nt    == d2.Nt
    equal &= d1.Nw    == d2.Nw
    equal &= d1.Neff  == d2.Neff
    equal &= d1.Nwt   == d2.Nwt
    equal &= d1.Ns    == d2.Ns
    equal &= d1.Nts   == d2.Nts
    equal &= d1.Nws   == d2.Nws
    equal &= d1.Neffs == d2.Neffs
    equal &= d1.Nwts  == d2.Nwts
    return equal


def compare_dataframe_to_file(filename, key, df):
    # Tests the content of a root file to a dataframe for equality within
    # rounding errors to make sure API and CLI give same results
    assert os.path.exists(filename)
    fdata = uproot.open(filename)[key].arrays(library="pd")
    for branch in fdata.columns.values:
        if branch in df:
            print(f"Comparing branch {branch} ...")
            b1 = np.array(fdata[branch])
            b2 = np.array(df[branch])
            if not all(np.isclose(b1, b2)):
                print("FAIL")
                print("CLI ", b1[b1 != b2])
                print("API ", b2[b1 != b2])
                raise AssertionError
            print("PASSED")


def test_oscillation_plot_curve_uses_production_flavour_mix():
    eta = np.array([0.12, 0.18, 0.24, 0.30, 0.36, 0.42])
    dec = np.array([1, 1, 1, 1, 1, 1], dtype=np.int32)
    decay_id = np.full(len(eta), 531, dtype=np.int32)
    tau = np.array([0.01, np.pi / ft.constants.DeltaM_s + 0.01] * (len(eta) // 2))

    tagger = ft.Tagger("BS_TEST", eta, dec, decay_id, mode="Bs", tau_ps=tau)
    func = ft.PolynomialCalibration(2, ft.link.mistag)
    tagger.set_calibration(func)

    params = [0.08, 0.25, -0.04, 0.18]
    tagger.stats.params = ft.CalParameters(2)
    tagger.stats.params.set_calibration_flavour(params, np.eye(4))

    eta_plot = np.array([0.2, 0.3, 0.4])
    curve = calibration_lineshape(tagger, eta_plot)

    frac_plus = np.mean(tagger.stats._tagdata.prod_flav == 1)
    curve_plus = tagger.func.eval(params, eta_plot.copy(), np.ones_like(eta_plot))
    curve_minus = tagger.func.eval(params, eta_plot.copy(), -np.ones_like(eta_plot))
    expected = frac_plus * curve_plus + (1 - frac_plus) * curve_minus

    assert np.any(tagger.stats._tagdata.prod_flav != tagger.stats._tagdata.decay_flav)
    np.testing.assert_allclose(curve, expected)


def test_calibrate_Bu():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/calib/test_calibrate_Bu"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BU_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY"], library="pd")
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()
        out = tc.get_dataframe(calibrated=True)
        check_dataframe_ivalid_values(out)

    # Test plotting while we are here
    os.makedirs("tests/testplots", exist_ok=True)
    tc.plot_calibration_curves(savepath="tests/testplots", format="pdf")
    tc.plot_calibration_curves(savepath="tests/testplots", format="png")
    tc.plot_calibration_curves(savepath="tests/testplots", format="json")
    fig, ax = plt.subplots()
    ft.draw_calibration_curve(tc["TOY0"], ax=ax, save=False)
    plt.close(fig)
    tc_trueid = ft.TaggerCollection()
    tc_trueid.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, 521 * np.sign(df.FLAV_DECAY), mode="TRUEID")
    with DataValidityContext(tc_trueid):
        tc_trueid.calibrate(quiet=True)
    check_dataframe_ivalid_values(tc_trueid.get_dataframe(calibrated=True))
    fig, ax = plt.subplots()
    ft.draw_calibration_curve(tc_trueid["TOY0"], ax=ax, save=False, title_fontsize=14, legend_fontsize=11, params_fontsize=10)
    plt.close(fig)

    delete_file(testfile + ".json")


def test_calibrate_combine_Bu():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/calib/test_calibrate_combine_Bu"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BU_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY"], library="pd")
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()
        apidata = tc.get_dataframe(calibrated=True)
        combination = tc.combine_taggers("Combination", calibrated=True)
        combdata = combination.get_dataframe(calibrated=False)

    for v in combdata.columns.values:
        apidata[v] = combdata[v]

    delete_file(testfile + ".json")


def test_calibrate_combine_calibrate_Bu():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/calib/test_calibrate_combine_calibrate_Bu"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BU_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY"], library="pd")
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    tc.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bu")
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()
        apidata = tc.get_dataframe(calibrated=True)
        combination = tc.combine_taggers("Combination", calibrated=True)
        combination.calibrate()
        combdata = combination.get_dataframe(calibrated=False)
        combdata_calib = combination.get_dataframe(calibrated=True)
    for v in combdata.columns.values:
        apidata[v] = combdata[v]
    for v in combdata_calib.columns.values:
        apidata[v] = combdata_calib[v]

    delete_file(testfile + ".json")


def test_calibrate_Bd():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/calib/test_calibrate_Bd"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU"], library="pd")
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()
        tc.get_dataframe()

    delete_file(testfile + ".json")


def test_calibrate_Bd_selection_vartype1():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/calib/test_calibrate_Bd_sel_v1"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU"], library="pd")
    selection = df.TAU > 0.5
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()
        tc.get_dataframe()

    delete_file(testfile + ".json")


def test_calibrate_Bd_selection_vartype2():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/calib/test_calibrate_Bd_sel_v2"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU", "eventNumber"], library="pd")
    selection = df.eventNumber % 2 == 0
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()
        tc.get_dataframe()

    delete_file(testfile + ".json")


def test_calibrate_combine_Bd():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/calib/test_calibrate_combine_Bd"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU"], library="pd")
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()
        combination = tc.combine_taggers("Combination", calibrated=True)
        apidata = tc.get_dataframe(calibrated=True)
        combdata = combination.get_dataframe(calibrated=False)
    for v in combdata.columns.values:
        apidata[v] = combdata[v]

    delete_file(testfile + ".json")


def test_calibrate_combine_calibrate_Bd():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/calib/test_calibrate_combine_calibrate_Bd"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU"], library="pd")
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()
        combination = tc.combine_taggers("Combination", calibrated=True)
        combination.calibrate()
        apidata = tc.get_dataframe(calibrated=True)
        combdata = combination.get_dataframe(calibrated=False)
        combdata_calib = combination.get_dataframe(calibrated=True)
    for v in combdata.columns.values:
        apidata[v] = combdata[v]
    for v in combdata_calib.columns.values:
        apidata[v] = combdata_calib[v]

    delete_file(testfile + ".json")


def test_calibrate_combine_calibrate_Bd_selection():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/calib/test_calibrate_combine_calibrate_Bd_sel"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU", "eventNumber"], library="pd")

    selection = df.eventNumber % 2 == 0
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()
        combination = tc.combine_taggers("Combination", calibrated=True)
        combination.calibrate()
        apidata = tc.get_dataframe(calibrated=True)
        combdata = combination.get_dataframe(calibrated=False)
        combdata_calib = combination.get_dataframe(calibrated=True)
    for v in combdata.columns.values:
        apidata[v] = combdata[v]
    for v in combdata_calib.columns.values:
        apidata[v] = combdata_calib[v]

    delete_file(testfile + ".json")


def test_parallel_calibration_consistency():
    testfile = "tests/calib/test_parallel_calibration_consistency"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU", "eventNumber"], library="pd")

    selection = df.eventNumber % 2 == 0
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)

    tc2 = ft.TaggerCollection()
    tc2.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)
    tc2.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU, selection=selection)

    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()

    with DataIntegrity(tc2), DataValidityContext(tc2):
        tc2.calibrate(parallel=True)

    res1 = tc.get_dataframe(calibrated=True)
    res2 = tc2.get_dataframe(calibrated=True)

    for col in res1.columns.values:
        assert allclose(res1[col], res2[col]), "Mismatch for " + col

    delete_file(testfile + ".json")


@pytest.mark.parametrize(
    ("func", "expected"),
    [
        (ft.PolynomialCalibration(2, ft.link.mistag), True),
        (ft.PolynomialCalibration(3, ft.link.logit), True),
        (ft.NSplineCalibration(3, ft.link.mistag), True),
        (ft.NSplineCalibration(4, ft.link.logit), True),
        (ft.BSplineCalibration(4, ft.link.mistag), True),
        (ft.BSplineCalibration(5, ft.link.logit), True),
    ]
)
def test_calibrate_save_load(func, expected):
    # Write calibrations to file and load them. Compare whether calibration
    # functions and the ones loaded from file generate the same omega value
    testfile = "tests/calib/test_calibrate_save_load"
    delete_file(testfile + ".json")
    calibfile = "tests/calib/test_calibration"
    delete_file(calibfile + ".json")
    F = "tests/calib/toy_data.root"

    df: pd.DataFrame = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU"], library="pd", entry_stop=10000)
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()
    origdata = tc.get_dataframe(calibrated=True)

    ft.save_calibration(tc, title=calibfile + ".json")

    tc_flavour = ft.TargetTaggerCollection()
    tc_flavour.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc_flavour.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc_flavour.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc_flavour.load_calibrations(calibfile + ".json", style="flavour")
    with DataValidityContext(tc_flavour):
        tc_flavour.apply(ignore_delta=True)
    flavourdata = tc_flavour.get_dataframe(calibrated=True)
    check_dataframe_ivalid_values(flavourdata)

    tc_delta = ft.TargetTaggerCollection()
    tc_delta.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc_delta.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc_delta.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc_delta.load_calibrations(calibfile + ".json", style="delta")
    with DataValidityContext(tc_delta):
        tc_delta.apply(ignore_delta=True)
    deltadata = tc_delta.get_dataframe(calibrated=True)
    check_dataframe_ivalid_values(deltadata)

    for t in range(3):
        assert tc[t].func.npar == tc_delta[t].func.npar
        assert tc[t].func.npar == tc_flavour[t].func.npar
        assert tc[t].func.link == tc_delta[t].func.link
        assert tc[t].func.link == tc_flavour[t].func.link

        TagDataEquals(tc[t].stats, tc_flavour[t].stats)
        TagDataEquals(tc[t].stats, tc_delta[t].stats)

    print("Difference between delta and flavour:")
    print((deltadata - flavourdata).describe())
    print("Difference between orig and flavour:")
    print((origdata - flavourdata).describe())
    print("Difference between delta and orig:")
    print((deltadata - origdata).describe())

    assert all([allclose(deltadata[c], flavourdata[c]) for c in origdata.columns])
    assert all([allclose(origdata[c], flavourdata[c]) for c in origdata.columns])
    assert all([allclose(origdata[c], deltadata[c]) for c in origdata.columns])

    delete_file(calibfile + ".json")
    delete_file(testfile + ".json")


def test_error_propagation_combination():
    # Run CLI command without crashing, then do the same with the API and compare results
    # CLI
    testfile = "tests/calib/test_error_propagation_combination"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY1_ETA", "TOY2_ETA",
                                          "TOY0_DEC", "TOY1_DEC", "TOY2_DEC", "FLAV_DECAY", "TAU"], library="pd")
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY1", df.TOY1_ETA, df.TOY1_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc.create_tagger("TOY2", df.TOY2_ETA, df.TOY2_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    tc[0].set_calibration(ft.PolynomialCalibration(npar=2, link=ft.link.mistag))
    tc[1].set_calibration(ft.PolynomialCalibration(npar=3, link=ft.link.mistag))
    tc[2].set_calibration(ft.PolynomialCalibration(npar=2, link=ft.link.logit))
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()

    combination = tc.combine_taggers("Combination", calibrated=True)
    check_performance_numbers(combination)
    check_dataframe_ivalid_values(combination.get_dataframe(calibrated=False))
    tagpower0 = tc[0].stats.tagging_power(calibrated=True, inselection=False)
    tagpower1 = tc[1].stats.tagging_power(calibrated=True, inselection=False)
    tagpower2 = tc[2].stats.tagging_power(calibrated=True, inselection=False)
    tagpower_combined = combination.stats.tagging_power(calibrated=False, inselection=False)
    tagpower_combined_selected = combination.stats.tagging_power(calibrated=False, inselection=True)

    ft.constants.propagate_errors = True
    combination_propagated = tc.combine_taggers("Combination new", calibrated=True)
    tagpower_combined_propagated = combination_propagated.stats.tagging_power(calibrated=False, inselection=False)
    tagpower_combined_selected_propagated = combination_propagated.stats.tagging_power(calibrated=False, inselection=True)
    ft.constants.propagate_errors = False

    assert tagpower0[0] + tagpower1[0] + tagpower2[0] >= tagpower_combined[0]
    assert tagpower0[0] + tagpower1[0] + tagpower2[0] >= tagpower_combined_propagated[0]
    assert tagpower_combined[0] == tagpower_combined_propagated[0]
    assert tagpower_combined_selected[0] == tagpower_combined_selected_propagated[0]
    assert np.array_equal(tagpower_combined_propagated, tagpower_combined_selected_propagated)

    delete_file(testfile + ".json")


def test_error_propagation_combination_consistency():
    testfile = "tests/calib/test_error_propagation_combination_consistency"
    delete_file(testfile + ".json")
    F = "tests/calib/toy_data.root"

    df = uproot.open(F)["BD_TOY"].arrays(["TOY0_ETA", "TOY0_DEC", "FLAV_DECAY", "TAU"], library="pd")
    tc = ft.TaggerCollection()
    tc.create_tagger("TOY0", df.TOY0_ETA, df.TOY0_DEC, B_ID=df.FLAV_DECAY, mode="Bd", tau_ps=df.TAU)
    with DataIntegrity(tc), DataValidityContext(tc):
        tc.calibrate()

    # Truncate omega just in case omega>0.5. Thise values cannot be compared since the epm ignores them explicitly in combinations
    # Also ignore underflow values, which the EPM does not handle at all.
    # In general, out of range omega values will not be present in the combination
    dataref = tc[0].stats._full_data
    overflow = dataref.omega > 0.5
    underflow = dataref.omega < 0
    dataref.loc[overflow, "omega_err"] = 0
    dataref.loc[overflow, "omega"] = 0.5

    dataref.loc[underflow, "omega_err"] = 0
    dataref.loc[underflow, "omega"] = 0.5
    dataref.loc[underflow, "dec"] = 0

    combination = tc.combine_taggers("Combination", calibrated=True)
    check_performance_numbers(combination)
    check_dataframe_ivalid_values(combination.get_dataframe(calibrated=False))
    tagpower = tc[0].stats.tagging_power(calibrated=True, inselection=False)
    tagpower_combined = combination.stats.tagging_power(calibrated=False, inselection=False)

    ft.constants.propagate_errors = True
    combination_propagated = tc.combine_taggers("Combination new", calibrated=True)
    tagpower_combined_propagated = combination_propagated.stats.tagging_power(calibrated=False, inselection=False)

    assert allclose(combination_propagated.stats._full_data.eta, combination.stats._full_data.eta), "Mistag values differ between error propagation and without"
    assert allclose(combination_propagated.stats._full_data.dec, combination.stats._full_data.dec), "Decision values differ between error propagation and without"

    assert allclose(tc[0].stats._full_data.omega, combination.stats._full_data.eta), "Mistag values differ between original and combination tagger"
    assert allclose(tc[0].stats._full_data.omega, combination_propagated.stats._full_data.eta), "Mistag values differ with and without error prop"
    assert allclose(tc[0].stats._full_data.omega_err, combination_propagated.stats._full_data.eta_err), "Mistag error values differ with and without error prop"
    ft.constants.propagate_errors = False

    assert np.isclose(tagpower_combined[0], tagpower[0])
    assert np.isclose(tagpower_combined[0], tagpower_combined_propagated[0])
    assert allclose(tagpower_combined_propagated, tagpower, atol=1e-4)

    delete_file(testfile + ".json")


# ─── Orthogonal polynomial basis tests ────────────────────────────────────────

def _inner_product(cal, link: ft.link.link_function, eta, weight=None):
    """Compute the full Gram matrix of cal.basis under the weighted inner product
    used in init_basis."""
    x = link.L(eta)
    denom = eta * (1 - eta) * link.DL(eta) ** 2

    npar = len(cal.basis)
    G = np.zeros((npar, npar))
    for i in range(npar):
        pi = np.polyval(cal.basis[i], x)
        for j in range(npar):
            pj = np.polyval(cal.basis[j], x)
            G[i, j] = np.average(pi * pj / denom, weights=weight)
    return G


@pytest.mark.parametrize("link", [ft.link.mistag, ft.link.logit])
@pytest.mark.parametrize("npar", [2, 3, 4, 5])
def test_poly_basis_orthogonality(link, npar):
    """Off-diagonal Gram matrix elements must vanish after init_basis."""
    rng = np.random.default_rng(0)
    eta = rng.uniform(0.05, 0.45, 20000)

    cal = ft.PolynomialCalibration(npar, link)
    eta_copy = eta.copy()
    cal.init_basis(eta)

    # Input must not be mutated
    assert np.array_equal(eta, eta_copy), "init_basis must not mutate the eta array"

    G = _inner_product(cal, link, eta)
    off_diag = G - np.diag(np.diag(G))
    assert np.allclose(off_diag, 0, atol=1e-10), (
        f"Basis not orthogonal for link={link.__name__}, npar={npar}; "
        f"max off-diagonal = {np.max(np.abs(off_diag)):.2e}"
    )


@pytest.mark.parametrize("link", [ft.link.mistag, ft.link.logit])
@pytest.mark.parametrize("npar", [2, 3, 4, 5])
def test_poly_basis_positive_norms(link, npar):
    """Diagonal Gram matrix elements (self-inner-products) must be strictly positive."""
    rng = np.random.default_rng(1)
    eta = rng.uniform(0.05, 0.45, 20000)

    cal = ft.PolynomialCalibration(npar, link)
    cal.init_basis(eta)

    G = _inner_product(cal, link, eta)
    diag = np.diag(G)
    assert np.all(diag > 0), (
        f"Non-positive self-inner-product for link={link.__name__}, npar={npar}; diag={diag}"
    )


@pytest.mark.parametrize("link", [ft.link.mistag, ft.link.logit])
@pytest.mark.parametrize("npar", [2, 3, 4, 5])
def test_poly_basis_structure(link, npar):
    """Each basis vector must have the correct length and monic leading coefficient."""
    rng = np.random.default_rng(2)
    eta = rng.uniform(0.05, 0.45, 20000)

    cal = ft.PolynomialCalibration(npar, link)
    cal.init_basis(eta)

    assert len(cal.basis) == npar, "Wrong number of basis vectors"
    for i, bvec in enumerate(cal.basis):
        assert len(bvec) == i + 1, (
            f"Basis vector P_{i} has length {len(bvec)}, expected {i + 1}"
        )
        # np.polyval stores highest-degree coefficient first; leading coeff = bvec[0]
        assert np.isclose(bvec[0], 1.0), (
            f"Leading coefficient of P_{i} is {bvec[0]}, expected 1.0 (monic)"
        )


def test_poly_basis_p0_is_constant():
    """P_0 must be the constant polynomial 1."""
    rng = np.random.default_rng(3)
    eta = rng.uniform(0.05, 0.45, 10000)

    for link in [ft.link.mistag, ft.link.logit]:
        cal = ft.PolynomialCalibration(3, link)
        cal.init_basis(eta)
        assert cal.basis[0] == pytest.approx([1.0]), (
            f"P_0 is not the constant polynomial 1 for link={link.__name__}"
        )


@pytest.mark.parametrize("link", [ft.link.mistag, ft.link.logit])
def test_poly_basis_orthogonality_with_weights(link):
    """Orthogonality must hold when event weights are supplied to init_basis."""
    rng = np.random.default_rng(4)
    eta = rng.uniform(0.05, 0.45, 20000)
    weight = rng.uniform(0.5, 2.0, len(eta))

    cal = ft.PolynomialCalibration(4, link)
    eta_copy = eta.copy()
    weight_copy = weight.copy()
    cal.init_basis(eta, weight=weight)

    # Inputs must not be mutated
    assert np.array_equal(eta, eta_copy),    "init_basis must not mutate the eta array"
    assert np.array_equal(weight, weight_copy), "init_basis must not mutate the weight array"

    G = _inner_product(cal, link, eta, weight=weight)
    off_diag = G - np.diag(np.diag(G))
    assert np.allclose(off_diag, 0, atol=1e-10), (
        f"Weighted basis not orthogonal for link={link.__name__}; "
        f"max off-diagonal = {np.max(np.abs(off_diag)):.2e}"
    )


def test_poly_default_basis_is_monomial():
    """Before init_basis is called, the default basis must be the monomial basis {1, x, x^2, ...}."""
    npar = 4
    cal = ft.PolynomialCalibration(npar, ft.link.mistag)

    assert len(cal.basis) == npar
    for i, bvec in enumerate(cal.basis):
        # Default initialisation: np.zeros(i+1) with bvec[0]=1, so polyval gives constant 1
        # (leading coefficient 1, all other coefficients 0)
        expected = np.zeros(i + 1)
        expected[0] = 1
        assert np.array_equal(bvec, expected), (
            f"Default basis vector P_{i} is {bvec}, expected {expected}"
        )


@pytest.mark.parametrize("link", [ft.link.mistag, ft.link.logit])
def test_poly_basis_set_basis_roundtrip(link):
    """set_basis followed by reading back the basis must return exactly what was set."""
    rng = np.random.default_rng(5)
    eta = rng.uniform(0.05, 0.45, 10000)

    cal = ft.PolynomialCalibration(3, link)
    cal.init_basis(eta)
    original_basis = [b.copy() for b in cal.basis]

    cal2 = ft.PolynomialCalibration(3, link)
    cal2.set_basis(original_basis)

    for i, (b1, b2) in enumerate(zip(original_basis, cal2.basis)):
        assert np.array_equal(b1, b2), f"Basis vector P_{i} changed after set_basis roundtrip"
