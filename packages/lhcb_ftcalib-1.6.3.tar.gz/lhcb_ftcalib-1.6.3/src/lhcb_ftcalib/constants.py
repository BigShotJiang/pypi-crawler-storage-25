# Copyright (C) 2026 Q. Führing & V. Jevtic
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations
# Oscillation parameters
DeltaM_d     = 0.5069
DeltaGamma_d = 0
DeltaM_s     = 17.765
DeltaGamma_s = 0.083

Lifetime_Bd  = 1.517  # in ps. Used for user warnings
Lifetime_Bs  = 1.516  # in ps. Used for user warnings
LifetimeToleranceFactor = 10  # Warning threshold

# Covariance scaling for weighted fits
CovarianceCorrectionMethod = "SquaredHesse"  # "SumW2", "None"

# Propgate uncertainties of the calibrated mistags through tagger combination
propagate_errors = False

# Calculate uncertainties of the calibrated mistags. May cost some time, so this is optional
calculate_omegaerr = True

# Use averaged representation of the calibration to write calibrated mistag to
# tuples. It is probably not optimal to never account for mistag asymmetries on
# calibration datasets, but this default mimics the EPM behaviour
ignore_mistag_asymmetry_for_apply = True

epm_compatibility_mode = False
