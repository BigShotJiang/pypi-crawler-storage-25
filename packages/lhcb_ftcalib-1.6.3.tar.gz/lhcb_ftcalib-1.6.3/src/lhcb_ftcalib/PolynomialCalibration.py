# Copyright (C) 2026 Q. Führing & V. Jevtic
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations
import numpy as np

from .CalibrationFunction import GLMCalibrationFunction
from .link_functions import link_function
from . import link_functions
from .ft_types import NPArrayFloat
from . import constants


class PolynomialCalibration(GLMCalibrationFunction):
    r""" PolynomialCalibration
        GLM for polynomial calibrations

        :math:`\displaystyle\omega(\eta)=g^{-1}\left(g(\eta) + \sum_{i=0}^mp_iP_i(g(\eta))\right)`

        with orthogonal polynominal basis vectors :math:`P_i(\eta)=\sum_{k=0}^m B_{ik}\eta^k` with link function :math:`g`, linear parameters :math:`p_i` basis coefficients :math:`B_{ik}` and total
        number of parameters :math:`m`.

        :param npar: number of calibration parameters per flavour
        :param link: Link function type
    """

    def __init__(self, npar: int, link: type[link_function]=link_functions.mistag) -> None:
        GLMCalibrationFunction.__init__(self, npar, link)

        assert npar > 1

        # Initialize monomial basis {1, x, x^2, ...}
        self.basis = []  #: List of polynomial coefficient lists for calibration parameters
        for b in range(npar):
            self.basis.append(np.zeros(b + 1))
            self.basis[-1][0] = 1

    def set_basis(self, basis: list[NPArrayFloat]) -> None:
        r"""
        Setter for GLM basis coefficients

        The n-th provided coefficient vector will form a basis vector (a polynomial in powers of eta) :math:`P_n` for parameter :math:`p_n` in the form of
        :math:`P_n(\eta)=\sum_{k=0}^mB_{nk}g(\eta)^{m - k - 1}`

        :param basis: list of polynomial basis coefficient for each linear calibration parameter.
        :return: Calibrated mistags
        """
        self.basis = basis

    def init_basis(self, eta: NPArrayFloat, weight: NPArrayFloat | None = None) -> None:
        r"""
        Computes a mistag-density dependent basis of ortogonal polynomials (called by Tagger classes)
        :math:`\{P_n\}` for the scalar product :math:`\langle P_k,P_j
        \rangle=\sum_{n=1}^NP_k(\eta_n)P_j(\eta_n)w_n \gamma_n=\delta_{kj}`
        whereby :math:`w` is an event weight and :math:`\gamma` is an
        additional weight depending on the specified link. By default the
        monomial (not orthogonal) basis :math:`\{1, \eta, \cdots, \eta^n\}` is used.

        :param eta: Raw mistag
        :param weight: Event weight
        """
        moments = np.zeros((self.npar, self.npar))
        if weight is None:
            weight = np.ones_like(eta)

        denom = eta * (1 - eta) * self.link.DL(eta) ** 2
        if self.link == link_functions.mistag and constants.epm_compatibility_mode:
            denom = 1 # This is not optimal

        for i in range(self.npar):
            for j in range(self.npar):
                moments[i][j] = np.average(self.link.L(eta) ** (i + j) / denom, weights=weight)

        def prod(v1, v2):
            s = 0
            for i in range(self.npar):
                for j in range(self.npar):
                    s += v1[i] * v2[j] * moments[i][j]
            return s

        # Gram Schmidt
        basis = np.eye(self.npar)
        for i in range(self.npar):
            basis[i] /= np.sqrt(prod(basis[i], basis[i]))

            for j in range(i + 1, self.npar):
                basis[j] -= basis[i] * prod(basis[i], basis[j])

        for i in range(self.npar):
            basis[i] /= basis[i][i]

        basis = list(basis)
        for i in range(self.npar):
            basis[i] = basis[i][:i + 1][::-1]

        self.basis = basis

    def eval(self, params: list[float], eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        omega = self.link.L(eta)
        for p in range(self.npar):
            omega[dec == +1] += params[p]             * np.polyval(self.basis[p], self.link.L(eta[dec == +1]))
            omega[dec == -1] += params[p + self.npar] * np.polyval(self.basis[p], self.link.L(eta[dec == -1]))
        return self.link.InvL(omega)

    def eval_averaged(self, params: list[float], eta: NPArrayFloat) -> NPArrayFloat:
        omega = self.link.L(eta)
        for p in range(self.npar):
            omega += params[p] * np.polyval(self.basis[p], self.link.L(eta))
        return self.link.InvL(omega)

    def eval_plotting(self, params: list[float], eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        n_pos = np.sum(dec ==  1)
        n_neg = np.sum(dec == -1)
        f = n_pos / (n_pos + n_neg)

        omega = self.link.L(eta)

        for p in range(self.npar):
            omega += (f * params[p] + (1 - f) * params[p + self.npar]) * np.polyval(self.basis[p], self.link.L(eta))

        return self.link.InvL(omega)

    def derivative(self, partial: int, params: list[float], eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        D = self.link.InvDL(self.link.L(self.eval(params, eta, dec)))

        if partial < self.npar:
            D[dec ==  1] *= np.polyval(self.basis[partial], self.link.L(eta[dec == +1]))
            D[dec == -1] = 0
        else:
            D[dec == -1] *= np.polyval(self.basis[partial - self.npar], self.link.L(eta[dec == -1]))
            D[dec ==  1] = 0

        return D

    def derivative_averaged(self, partial: int, params: list[float], eta: NPArrayFloat) -> NPArrayFloat:
        D = self.link.InvDL(self.link.L(self.eval_averaged(params, eta)))
        D *= np.polyval(self.basis[partial], self.link.L(eta))

        return D

    def gradient(self, params: list[float], eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        return np.array([self.derivative(i, params, eta, dec) for i in range(self.npar * 2)])

    def gradient_averaged(self, params: list[float], eta: NPArrayFloat) -> NPArrayFloat:
        return np.array([self.derivative_averaged(i, params, eta) for i in range(self.npar)])

    def print_basis(self):
        def fmt_exp(param, ex, varname):
            ret = ""
            if param == 0.0:
                ret = ""
            elif ex == 0:
                ret = "1" if param == 1.0 else f"{param:+.4f}"
            elif ex == 1:
                ret = varname if param == 1.0 else f"{param:+.4f}·{varname}"
            else:
                num =  varname if param == 1.0 else f"{param:+.4f}·{varname}"
                ret = num + ''.join(['⁰¹²³⁴⁵⁶⁷⁸⁹'[int(e)] for e in str(ex)])
            return ret.replace("+", "+ ").replace("-", "- ")

        identity = self.link == link_functions.mistag
        print(f"\033[1m{self.link.__name__}\033[0m link function: g(η) = {self.link.symbolic('η')}")
        if identity:
            var = "η"
            print(f"ω(η) = {var} + ", end="")
        else:
            var = "g(η)"
            print(f"ω(η) = g⁻¹({var} + ", end="")

        for i in range(self.npar):
            print(f"\033[1mp{i}\033[0m·P{i}({var})", end="") # ]]
            if i < self.npar - 1:
                print(" + ", end="")
        print("" if identity else ")")

        for i, coeff in enumerate(self.basis):
            print(f"P{i}({var}) = {fmt_exp(coeff[0], i, var)} ", end="")
            for j, c in enumerate(coeff[1:]):
                print(f"{fmt_exp(c, len(coeff) - j - 2, var)} ", end="")
            print()
