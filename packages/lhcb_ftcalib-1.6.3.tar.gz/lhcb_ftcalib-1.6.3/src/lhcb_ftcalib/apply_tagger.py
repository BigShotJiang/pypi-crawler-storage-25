# Copyright (C) 2026 Q. Führing & V. Jevtic
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations
import json
import pandas as pd
import numpy as np

from typing import final

from lhcb_ftcalib.warnings import FTCWarnMsg, WarnType, ftcalib_warning
from .ft_types import NPArrayBool, NPArrayOrPandas, CalibrationMode, NPArrayFloat
from .Tagger import TaggerBase
from .TaggerCollection import TaggerCollection
from .CalibrationFunction import GLMCalibrationFunction
from .PolynomialCalibration import PolynomialCalibration
from .NSplineCalibration import NSplineCalibration
from .BSplineCalibration import BSplineCalibration
from .printing import (info, print_tagger_correlation,
                       print_tagger_performances, print_tagger_statistics,
                       raise_error, printbold)
from .plotting import draw_inputcalibration_curve
from . import link_functions as link
from .CalParameters import CalParameters
from . import constants
from .resolution_model import ResolutionModel

@final
class _LoadedMinimizer:
    def __init__(self):
        self.values: NPArrayFloat | None = None
        self.errors: NPArrayFloat | None = None
        self.covariance: NPArrayFloat | None = None
        self.accurate: bool = True  # At this point we trust the calibration file


@final
class TargetTagger(TaggerBase):
    """ A variation of the tagger object which loads a calibration
        from file and applies it to some data. Like the "Tagger",
        it contains two sets of TaggingData (BasicTaggingData) for
        before and after the calibration.

        Note: Specifying the B id, calibration mode,
        decay time and its uncertainty as well as the resolution model is
        optional and only needed in order to estimate the raw mistag if this performance
        number is needed and if it makes sense to compute it from the B ids in the tuple.

        :param name: Name of this target tagger. Ideally, try to use the same as for the calibrated tagger
        :param eta: Targeted mistag data
        :param dec: Targeted tagging decisions
        :param ID: B meson IDs (Not needed)
        :param mode: Calibration mode (Not needed)
        :param tau: Decay times in ps (Not needed)
        :param tauerr: Decay time uncertainties in ps (Not needed)
        :param weight: Weight variable (needed for tagging statistics information)
    """

    def __init__(self,
                 name: str,
                 eta_data: NPArrayOrPandas,
                 dec_data: NPArrayOrPandas,
                 B_ID: NPArrayOrPandas | None             = None,
                 mode: CalibrationMode | str | None       = None,
                 tau_ps: NPArrayOrPandas | None           = None,
                 tauerr_ps: NPArrayOrPandas | None        = None,
                 weight: NPArrayOrPandas | None           = None,
                 resolution_model: ResolutionModel | None = None):
        if tau_ps is not None and B_ID is None:
            ftcalib_warning(WarnType.User, FTCWarnMsg.TARGET_TAGGERS_MISSING_B_ID)
        raise_error(not (mode is None and any([a is not None for a in [tau_ps, tauerr_ps, resolution_model]])),
                    "If decay time related info is provided for a target tagger, the mode must be set to Bd or Bs.")

        super().__init__(name              = name,
                         eta_data          = eta_data,
                         dec_data          = dec_data,
                         B_ID              = B_ID if B_ID is not None else np.ones_like(eta_data),
                         mode              = CalibrationMode.TRUEID if mode is None else mode,
                         tau_ps            = tau_ps if B_ID is not None else None,
                         tauerr_ps         = tauerr_ps if B_ID is not None else None,
                         weight            = weight,
                         selection         = np.ones_like(eta_data, dtype=bool),  # All events are selected when taggers are applied
                         resolution_model  = resolution_model,
                         analytic_gradient = False)
        raise_error(not (self.mode.oscillation and tau_ps is None), f"If a calibration mode \"{mode}\" is specified for a TargetTagger, the decay time needs to be provided")

        self.info                         = None
        self.func: GLMCalibrationFunction = PolynomialCalibration(2, link.mistag)  # TaggerBase sets func by default
        self._calibrated: bool            = False
        self._loaded: bool                = False
        self._has_b_id: bool              = B_ID is not None
        self.minimizer: _LoadedMinimizer  = _LoadedMinimizer()

    def apply(self, ignore_delta: bool = True):
        """ Apply the previously loaded calibration to this tagger

            :param ignore_delta: If false, delta calibration parameters will be used when calibration is applied
        """
        assert self._loaded, "Calibration must be loaded before calling apply()"

        if not constants.ignore_mistag_asymmetry_for_apply:
            if self._has_b_id:
                ftcalib_warning(WarnType.User, FTCWarnMsg.B_ID_NOT_PROVIDED)

        self.stats._compute_calibrated_statistics(self.func, self.minimizer.values, self.minimizer.covariance, self.minimizer.accurate, self.name)
        self._calibrated = True

    def load(self, filename_or_dict: str | dict, tagger_name: str, style: str = "flavour") -> None:
        """ Load a calibration entry from a calibration file

            :param filename_or_dict: Filename of the calibration file or ftcalib calibration dictionary
            :param tagger_name: Entry name of the calibration data you would like to load
            :param style: Which parameter style to use
        """
        assert isinstance(filename_or_dict, (dict, str)), "Invalid type for calibration info"
        if isinstance(filename_or_dict, dict):
            calib = filename_or_dict
        elif isinstance(filename_or_dict, str):
            with open(filename_or_dict, "r") as F:
                calib = json.loads(F.read())

        # Reconstruct calibration function
        assert tagger_name in calib, "Tagger " + tagger_name + " not contained in calibration info"
        self.info = calib[tagger_name]

        assert style in ["flavour", "delta"], "Calibrations in " + style + "style not supported. Please use 'flavour' or 'delta' style."

        if "PolynomialCalibration" in self.info:
            fun_info = self.info["PolynomialCalibration"]
            self.func = PolynomialCalibration(int(fun_info["degree"]), _get_link_by_name(fun_info["link"]))
            basis = self.info["PolynomialCalibration"]["basis"]
            basis = [np.array(vec) for vec in basis]
            self.func.set_basis(basis)
        elif "NSplineCalibration" in self.info:
            fun_info = self.info["NSplineCalibration"]
            self.func = NSplineCalibration(int(fun_info["degree"]) - 2, _get_link_by_name(fun_info["link"]))
            basis = self.info["NSplineCalibration"]["basis"]
            basis = [np.array(vec) for vec in basis]
            self.func.set_basis(basis=fun_info["basis"], nodes=fun_info["nodes"])
        elif "BSplineCalibration" in self.info:
            fun_info = self.info["BSplineCalibration"]
            self.func = BSplineCalibration(int(fun_info["degree"]), _get_link_by_name(fun_info["link"]))
            self.func.set_basis(fun_info["nodes"])
        else:
            raise RuntimeError("Unknown calibration function")

        self.stats.params = CalParameters(npar=self.func.npar)
        params = np.array(self.info["calibration"][style + "_style"]["params"])

        noms_loaded   = [float(v) for v in params[:, 1]]
        cov_loaded = self.info["calibration"][style + "_style"]["cov"]
        cov_loaded = np.array([float(e) for row in cov_loaded for e in row]).reshape((2 * self.func.npar, 2 * self.func.npar))

        if style == "delta":
            self.stats.params.set_calibration_delta(noms_loaded, cov_loaded)
        elif style == "flavour":
            self.stats.params.set_calibration_flavour(noms_loaded, cov_loaded)

        self.minimizer.values = self.stats.params.params_flavour
        self.minimizer.errors = self.stats.params.errors_flavour
        self.minimizer.covariance = self.stats.params.covariance_flavour

        self.DeltaM     = self.info["osc"]["DeltaM"]
        self.DeltaGamma = self.info["osc"]["DeltaGamma"]
        self.Aprod      = self.info["osc"]["Aprod"]

        self._loaded = True

    def get_dataframe(self, calibrated: bool = True) -> pd.DataFrame:
        """ Returns a dataframe of the calibrated mistags and tagging decisions

            :param calibrated: Return dataframe of calibrated mistags and tag decisions
            :raises: AssertionError if tagger has not been calibrated and calibrated=True
            :return: dataframe with mistag and tagging decision
        """
        if calibrated:
            assert self._calibrated
            return pd.DataFrame({
                self.name + "_CDEC"  : np.array(self.stats._full_data.cdec.copy(), dtype=np.int32),
                self.name + "_OMEGA" : np.array(self.stats._full_data.omega.copy()),
                self.name + "_OMEGA_ERR" : np.array(self.stats._full_data.omega_err.copy())
            })
        else:
            return pd.DataFrame({
                self.name + "_DEC" : np.array(self.stats._full_data.dec.copy(), dtype=np.int32),
                self.name + "_ETA" : np.array(self.stats._full_data.eta.copy())
            })


def _get_link_by_name(linkname: str) -> type[link.link_function]:
    return {
        "mistag"   : link.mistag,
        "logit"    : link.logit,
        "probit"   : link.probit,
        "cauchit"  : link.cauchit,
    }[linkname.lower()]


class TargetTaggerCollection(TaggerCollection):
    r""" class TaggerCollection List type for grouping target taggers. Supports iteration.

        :param \*taggers: Tagger instance
    """

    def __init__(self, *taggers: list[TargetTagger]):
        super().__init__(*taggers)
        self._taggers: list[TargetTagger] = [*taggers]

    def __str__(self) -> str:
        return "TargetTaggerCollection [" + ','.join([t.name for t in self._taggers]) + "]"

    def _validate(self) -> None:
        assert all([isinstance(tagger, TargetTagger) for tagger in self._taggers]), "TargetTaggerCollection can only store TargetTagger instances"
        assert len(set([tagger.name for tagger in self._taggers])) == len(self._taggers), "Tagger names are not unique"

    def add_taggers(self, *tagger: list[TargetTagger]) -> None:
        """ Adds tagger(s) to the TagCollection instance by reference """
        self._taggers += [*tagger]
        self._validate()

    def create_tagger(self, *args, **kwargs):
        """ Adds a Target instance to the TargetTaggerCollection instance
            by passing the arguments to the TargetTagger() constructor.
        """
        self._taggers.append(TargetTagger(*args, **kwargs))
        self._validate()

    def load_calibrations(self, filename_or_dict: str | dict, tagger_mapping: dict | None = None, style: str = "flavour") -> None:
        """ Load calibrations from a file

            :param filename_or_dict: Filename of the calibration file or ftcalib calibratiopn dictionary
            :param tagger_mapping: Optional dictionary of a mapping of tagger names in this list vs corresponding entry names in the calibration file. By default, the same naming is assumed (!)
            :param style: Which parameter style to use
        """
        if tagger_mapping is None:
            tagger_mapping = { t.name : t.name for t in self._taggers }
        else:
            assert len(tagger_mapping) == len(self)

        for tagger in self._taggers:
            info(f"Loading {tagger_mapping[tagger.name]} calibrations for {tagger.name}")
            tagger.load(filename_or_dict, tagger_mapping[tagger.name], style)

    def apply(self, quiet: bool = False, ignore_delta: bool = True) -> None:
        """ Applies the previously loaded calibrations to a taggers

            :param quiet: Whether to print performance summary tables
        """

        if not quiet:
            print_tagger_correlation(self, "fire")
            print_tagger_correlation(self, "dec")
            print_tagger_correlation(self, "dec_weight")
            print_tagger_statistics(self, calibrated=False, selected=False)
            print_tagger_performances(self, calibrated=False, selected=False)

        for tagger in self._taggers:
            info(f"Applying calibration for {tagger.name}")
            tagger.apply(ignore_delta)

        if not quiet:
            print_tagger_statistics(self, calibrated=True, selected=False)
            print_tagger_performances(self, calibrated=True, selected=False)

    def plot_inputcalibration_curves(self, **kwargs) -> None:
        r""" Plots input calibration curves of a set of taggers, like the EPM
            does when a calibration is applied.  Plots the loaded calbration curve
            (uncertainties are loaded but ignored while applying the calibration)
            and the targeted mistag data.

            :param \**kwargs: Arguments to pass to draw_inputcalibration_curve
        """
        for tagger in self._taggers:
            print("Info: pdf file", draw_inputcalibration_curve(tagger, **kwargs), "has been created")

    def combine_taggers(self, name: str, 
                        calibrated: bool, 
                        next_selection: NPArrayBool | None = None, 
                        tagger_subset: list[str] | None = None, 
                        append: bool = False) -> TargetTagger:
        """ Computes the combination of multiple target taggers
            and returns it in the form of a new TargetTagger object

            :param name: Name of the tagger combination
            :param calibrated: Whether to use calibrated tagger data for combination (recommended)
            :param next_selection: Event selection to use for calibrating combination (default: No selection)
            :param tagger_subset: List of tagger names to combine (optional)
            :return: Tagger combination
        """

        (incombination,
         omega_combined,
         d_combined,
         gradients_combined,
         covariances) = self._prepare_combination(name,
                                                   calibrated     = calibrated,
                                                   next_selection = next_selection,
                                                   tagger_subset  = tagger_subset,
                                                   append         = append)

        combination = TargetTagger(name     = name,
                                   eta_data = omega_combined,
                                   dec_data = d_combined,
                                   weight = incombination[0].stats._full_data.weight)
        if calibrated and constants.propagate_errors:
            combination.stats._compute_combination_statistics(omega_combined, gradients_combined, covariances, name)
        printbold(f"New tagger combination {combination.name} has been created")
        return combination
