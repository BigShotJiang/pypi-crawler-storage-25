# Copyright (C) 2026 Q. Führing & V. Jevtic
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations
from abc import ABC, abstractmethod
import numpy as np
from scipy.special import erf, erfinv
from .ft_types import NPArrayFloat


class link_function(ABC):
    """ Link function base type (purely virtual) """

    @staticmethod
    @abstractmethod
    def L(x: NPArrayFloat) -> NPArrayFloat:
        """ Link function """
        return np.empty(0)

    @staticmethod
    @abstractmethod
    def InvL(x: NPArrayFloat) -> NPArrayFloat:
        """ Link function inverse """
        return np.empty(0)

    @staticmethod
    @abstractmethod
    def DL(x: NPArrayFloat) -> NPArrayFloat:
        """ Derivative of link function """
        return np.empty(0)

    @staticmethod
    @abstractmethod
    def InvDL(x: NPArrayFloat) -> NPArrayFloat:
        """ Derivative of link function inverse """
        return np.empty(0)

    @staticmethod
    @abstractmethod
    def symbolic(var: str) -> str:
        """ Symbolic representation of link function """
        pass

    # https://docs.python.org/3/library/abc.html
    @classmethod
    def __subclasshook__(cls, C):
        if cls is link_function:
            if any("__iter__" in B.__dict__ for B in C.__mro__):
                return True
        return NotImplemented


class mistag(link_function):
    """ Identity link """
    @staticmethod
    def L(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`g(\eta)=\eta` """
        return np.array(x)

    @staticmethod
    def InvL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`g^{-1}(\eta)=\eta` """
        return np.array(x)  # Creating copy is deliberate

    @staticmethod
    def DL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`\frac{\mathrm{d}g(\eta)}{\mathrm{d}\eta}=1` """
        return np.ones_like(x)

    @staticmethod
    def InvDL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`\frac{\mathrm{d}g^{-1}(\eta)}{\mathrm{d}\eta}=1` """
        return np.ones_like(x)

    @staticmethod
    def symbolic(var: str) -> str:
        """ Symbolic representation of link function """
        return var


class logit(link_function):
    r""" Negated logit link, :math:`g(\eta)=\log\!\left(\frac{1-\eta}{\eta}\right)=-\log\!\left(\frac{\eta}{1-\eta}\right)`.

    This is the negation of the standard logit link.
    The sign is chosen so that a smaller mistag :math:`\eta` maps to a larger
    positive linear predictor. Maps :math:`\eta\in(0,\frac{1}{2}]` to :math:`(+\infty,0]`
    with neutral point :math:`g(0.5)=0`.
    """
    @staticmethod
    def L(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`g(\eta)=\log\left(\frac{1-\eta}{\eta}\right)` """
        return np.log((1 - x) / x)

    @staticmethod
    def InvL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`g^{-1}(\eta)=(1 + e^\eta)^{-1}` """
        return 1.0 / (1.0 + np.exp(x))

    @staticmethod
    def DL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`\frac{\mathrm{d}g(\eta)}{\mathrm{d}\eta}=\frac{1}{\eta(\eta-1)}` """
        return (x * (x - 1))**-1

    @staticmethod
    def InvDL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`\frac{\mathrm{d}g^{-1}(\eta)}{\mathrm{d}\eta}=-\frac{1}{2}(1 + \cosh(\eta))^{-1}` """
        return -0.5  / (1.0 + np.cosh(x))

    @staticmethod
    def symbolic(var: str) -> str:
        return f"log(1 - {var}) - log({var})"


class probit(link_function):
    r""" Negated probit link, :math:`g(\eta)=\sqrt{2}\,\mathrm{inverf}(1-2\eta)=-\Phi^{-1}(\eta)`.

    This is the negation of the standard probit :math:`\Phi^{-1}(\eta)` (inverse
    normal CDF). Maps :math:`\eta\in(0,\frac{1}{2}]` to :math:`(+\infty,0]`.
    """
    @staticmethod
    def L(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`g(\eta)=\sqrt{2}\,\mathrm{inverf}(1-2\eta)` """
        return np.sqrt(2) * erfinv(1 - 2 * x)

    @staticmethod
    def InvL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`g^{-1}(\eta) =\frac{1}{2}\left(1-\mathrm{erf}\left(\frac{\eta}{\sqrt{2}}\right)\right)` """
        return 0.5 * (1.0 - erf(x / np.sqrt(2)))

    @staticmethod
    def DL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`\frac{\mathrm{d}g(\eta)}{\mathrm{d}\eta}=-\sqrt{2\pi}\exp(\mathrm{inverf}(1-2\eta)^2)` """
        return -np.sqrt(2 * np.pi) * np.exp(erfinv(1 - 2 * x)**2)

    @staticmethod
    def InvDL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`\frac{\mathrm{d}g^{-1}(\eta)}{\mathrm{d}\eta}=-\frac{e^{-\frac{1}{2}\eta^2}}{\sqrt{2\pi}}` """
        return -np.exp(-0.5 * x**2) / np.sqrt(2 * np.pi)

    @staticmethod
    def symbolic(var: str) -> str:
        return f"√2·inverf(1 - 2·{var})"


class cauchit(link_function):
    r""" Negated cauchit link, :math:`g(\eta)=-\tan\!\left(\frac{\pi}{2}(2\eta-1)\right)`.

    This is the negation of the standard cauchit :math:`\tan(\pi(\eta-\tfrac{1}{2}))`.
    Maps :math:`\eta\in(0,\frac{1}{2}]` to :math:`(+\infty,0]`.
    """
    @staticmethod
    def L(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`g(\eta)=\begin{cases}\infty&\eta<0\\-\infty&\eta>1\\-\tan\left(\frac{1}{2}\pi(2\eta-1)\right)&\text{else}\end{cases}` """
        il = -np.tan(0.5 * np.pi * (2 * x - 1))
        il[x < 0] = np.inf
        il[x > 1] = -np.inf
        return il

    @staticmethod
    def InvL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`g^{-1}(\eta) = \frac{1}{2} - \frac{1}{\pi}\arctan(\eta)` """
        return 0.5 - np.arctan(x) / np.pi

    @staticmethod
    def DL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`\frac{\mathrm{d}g(\eta)}{\mathrm{d}\eta}=-\pi\csc^2(\pi \eta)` """
        return -np.pi * np.sin(np.pi * x)**(-2)

    @staticmethod
    def InvDL(x: NPArrayFloat) -> NPArrayFloat:
        r""" :math:`\frac{\mathrm{d}g^{-1}(\eta)}{\mathrm{d}\eta}=-\frac{1}{\pi(1+\eta^2)}` """
        return -1.0 / (np.pi * (1 + x**2))

    @staticmethod
    def symbolic(var: str) -> str:
        return f"-tan((2·{var} - 1)·π/2)"
