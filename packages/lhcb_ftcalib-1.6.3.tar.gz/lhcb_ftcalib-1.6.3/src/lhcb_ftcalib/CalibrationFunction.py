# Copyright (C) 2026 Q. Führing & V. Jevtic
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations
import numpy as np
from abc import ABC, abstractmethod

from .ft_types import NPArrayFloat
from .link_functions import link_function
from . import link_functions


class GLMCalibrationFunction(ABC):
    r"""
    Calibration function abstract base type. All calibration classes should inherit from this type.
    Calibration functions receive calibration parameters in the following order

    params :math:`= (p^+_0,\cdots, p^+_n, p^-_0,\cdots,p^-_n)`
    """

    def __init__(self, npar: int, link: type[link_function]=link_functions.mistag):
        self.npar: int = npar
        self.link: type[link_function] = link
        self.basis = None  # Function specific basis representation

    def __eq__(self, other) -> bool:
        if self.basis is None or other.basis is None:
            raise RuntimeError("Cannot compare uninitialized calibration functions")

        equal = True
        equal &= self.npar == other.npar
        equal &= self.link == other.link
        equal &= len(self.basis) == len(other.basis)

        if equal:
            for b in range(len(self.basis)):
                equal &= np.array_equal(self.basis[b], other.basis[b])
        return equal

    def get_basis_matrix(self) -> NPArrayFloat:
        """ Get full NxN basis matrix in numpy format """
        M = np.zeros((self.npar, self.npar))
        if self.basis is None:
            return np.eye(self.npar)

        for j, row in enumerate(self.basis):
            M[j][:len(row)] = row[::-1]

        return M

    @abstractmethod
    def print_basis(self) -> None:
        """ Pretty printer for the calibration basis """
        print("no basis")

    @abstractmethod
    def init_basis(self, eta: NPArrayFloat, weight: NPArrayFloat | None = None) -> None:
        """ Initializer for the calibration function basis.
            Must be called before a calibration function is evaluated

            :param eta: Mistags
            :param weight: Event weights
        """
        pass

    @abstractmethod
    def eval(self, params: list[float], eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        """ Evaluate the calibration function

            :param params: Calibration function parameters
            :param eta: Mistags
            :param dec: Tagging decisions
            :return: Calibrated mistags
        """
        print("no basis")

    @abstractmethod
    def eval_averaged(self, params: list[float], eta: NPArrayFloat) -> NPArrayFloat:
        r""" Evaluate the calibration function and ignore differences of
            flavour specific calibrations

            :param params: Mean calibration function parameters :math:`[p_0,\cdots,p_n]`
            :param eta: Mistags
            :return: Calibrated mistags
        """
        pass

    def eval_uncertainty(self, params: list[float], cov: NPArrayFloat, eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        """ Evaluate uncertainty of calibrated mistag

            :param params: Calibration function parameters
            :param cov: Covariance matrix of the calibration function parameters
            :param eta: Mistags
            :param dec: Tagging decisions
            :return: Calibrated mistags
        """
        gradient = self.gradient(params, eta, dec).T
        return np.sqrt([g @ cov @ g.T for g in gradient])

    def eval_averaged_uncertainty(self, params: list[float], cov: NPArrayFloat, eta: NPArrayFloat) -> NPArrayFloat:
        r""" Evaluate uncertainty of calibrated mistag and ignore Delta paramaters

            :param params: Mean calibration function parameters :math:`[p_0,\cdots,p_n]`
            :param cov: Covariance matrix of the calibration function parameters
            :param eta: Mistags
            :return: Uncertainties ofalibrated mistags
        """
        gradient = self.gradient_averaged(params, eta).T
        return np.sqrt([g @ cov @ g.T for g in gradient])

    @abstractmethod
    def eval_plotting(self, params: list[float], eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        """ Compute the combined lineshape of the flavour specific calibration components (for plotting).

            :param params: Calibration function parameters
            :param eta: Mistags
            :param dec: Tagging decisions
            :return: Calibrated mistags
        """
        pass

    @abstractmethod
    def derivative(self, partial: int, params: list[float], eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        """ Evaluate the partial derivative w.r.t. one of the calibration parameters.

            :param partial: :math:`n`-th calibration parameter
            :param params: Calibration function parameters
            :param eta: Mistags
            :param dec: Tagging decisions
            :return: Calibration function partial derivative
        """
        pass

    @abstractmethod
    def derivative_averaged(self, partial: int, params: list[float], eta: NPArrayFloat) -> NPArrayFloat:
        """ Evaluate the partial derivative w.r.t. one of the average calibration parameters.

            :param partial: :math:`n`-th calibration parameter
            :param params: Calibration function parameters
            :param eta: Mistags
            :param dec: Tagging decisions
            :return: Calibration function partial derivative
        """
        pass

    def gradient(self, params: list[float], eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        """ Evaluate the calibration function gradient w.r.t. to the set of calibration parameters

            :param params: Calibration function parameters
            :param eta: Mistags
            :param dec: Tagging decisions
            :return: List of all calibration function partial derivatives
        """
        return np.array([self.derivative(i, params, eta, dec) for i in range(self.npar * 2)])

    def gradient_averaged(self, params: list[float], eta: NPArrayFloat) -> NPArrayFloat:
        """ Evaluate the calibration function gradient w.r.t. to the set of averaged calibration parameters

            :param params: Calibration function parameters
            :param eta: Mistags
            :param dec: Tagging decisions
            :return: List of all calibration function partial derivatives
        """
        return np.array([self.derivative_averaged(i, params, eta) for i in range(self.npar)])

    def __str__(self) -> str:
        return f"<CalibrationFunction, type={self.__class__.__name__}, link={self.link.__name__}, npar={self.npar}>"

    def __repr__(self) -> str:
        return self.__str__()
