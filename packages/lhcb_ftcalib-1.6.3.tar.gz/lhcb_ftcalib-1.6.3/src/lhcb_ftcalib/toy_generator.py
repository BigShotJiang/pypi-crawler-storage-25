from enum import IntEnum
from typing import Callable
import pandas as pd
import numpy as np

from lhcb_ftcalib.warnings import FTCWarnMsg, WarnType, ftcalib_warning

from .CalibrationFunction import GLMCalibrationFunction
from .PolynomialCalibration import PolynomialCalibration
from . import resolution_model
from .printing import raise_error
from .ft_types import NPArrayFloat


class DistributionSampler:
    r"""Samples an arbitrary numerical probability distribution using rejection-free
    inverse-CDF sampling on a discrete grid.

    The constructor evaluates *func* on a uniform grid of *precision* points
    spanning ``[xmin, xmax]``, normalises the result to a probability vector,
    and stores it for repeated sampling via ``__call__``.  Each sample is
    additionally smeared by a uniform jitter of :math:`\pm\tfrac{1}{2}\Delta x` (where :math:`\Delta x` is the grid
    spacing) so that the output approaches a smooth distribution as *precision*
    increases.
    """

    def __init__(self, xmin: float, xmax: float, precision: int, func, *args, **kwargs):
        """
        :param xmin: Lower bound of the sampling domain.
        :param xmax: Upper bound of the sampling domain.
        :param precision: Number of equally-spaced grid points.
        :param func: Callable returning the (unnormalised) probability density.
            Must accept an ``np.ndarray`` as its first positional argument.
        :param args: Extra positional arguments forwarded to *func*.
        :param kwargs: Extra keyword arguments forwarded to *func*.
        """
        self.range = (xmin, xmax)
        self._X: np.ndarray = np.linspace(xmin, xmax, precision)
        pdf = np.asarray(func(self._X, *args, **kwargs), dtype=float)
        if pdf.ndim == 0:
            pdf = np.full_like(self._X, pdf, dtype=float)
        elif pdf.shape != self._X.shape:
            raise ValueError("Distribution function must return a scalar or an array matching the sampling grid")
        self._PDF: np.ndarray = pdf
        self._PDF /= np.sum(self._PDF)
        self.func = func
        self._dx = (xmax - xmin) / precision

    def functionArea(self, precision, *args, **kwargs) -> float:
        """Compute the area under the distribution function using the trapezoidal rule.

        :param precision: Number of integration points.
        :param args: Extra positional arguments forwarded to the stored function.
        :param kwargs: Extra keyword arguments forwarded to the stored function.
        :returns: Numerical integral of the function over ``[xmin, xmax]``.
        """
        X = np.linspace(*self.range, precision)
        return np.trapezoid(self.func(X, *args, **kwargs), X, dx=self._dx)

    def __smear(self, x: np.ndarray) -> np.ndarray:
        # Smear sampled value randomly inside sampling bin
        # In the limit precision -> infinity, this generates a smooth distribution
        x += np.random.uniform(0, 1, size=len(x)) * self._dx - 0.5 * self._dx
        return x

    def __call__(self, N: int) -> np.ndarray:
        """Draw *N* samples from the distribution.

        :param N: Number of samples to draw.
        :returns: Array of length *N* with samples drawn from the stored distribution.
        """
        return self.__smear(np.random.choice(self._X, size=N, p=self._PDF))


class ToyGenerator:
    """Physics-accurate toy Monte Carlo generator for flavour-tagged B-meson decays.

    The generator uses the full time-dependent decay rate — including CP violation,
    production/detection asymmetries, decay-time acceptance, and :math:`\Delta\Gamma` effects — to
    sample statistically correct event samples.  Its builder-style API separates
    physics configuration from event generation:

    1. Instantiate: ``gen = ToyGenerator(tmin, tmax)``
    2. Set physics: ``gen.setPhysics(neutral_mode=True, S=0.7, ...)``
    3. Register taggers: ``gen.add_tagger(...)`` (repeatable).
    4. Generate: ``df = gen.generate(N)``

    The returned :class:`pandas.DataFrame` contains the columns listed under
    :meth:`generate`.
    """

    class ToyTagger:
        def __init__(self, name: str, 
                     func_params_plus: list[float], 
                     func_params_minus: list[float], 
                     eta_shape: Callable = lambda _ : 1.0,
                     func: GLMCalibrationFunction = PolynomialCalibration(2),
                     efficiency: float = 1.0):
            self.name: str = name
            self.eta_shape: Callable = eta_shape
            self.func_params: list[float] = [*func_params_plus, *func_params_minus]
            self.func_params_plus: list[float] = func_params_plus
            self.func_params_minus: list[float] = func_params_minus
            self.func: GLMCalibrationFunction = func
            self.tageff: float = efficiency

        def __repr__(self) -> str:
            return f"ToyTagger(name={self.name})"

        def __str__(self) -> str:
            return self.__repr__()

    class Process(IntEnum):
        B_to_f = 1
        Bbar_to_f = 2
        B_to_fbar = 3
        Bbar_to_fbar = 4

    class fProd(IntEnum):
        B = 1
        Bbar = -1

    def __init__(self, tmin: float, tmax: float, seed:int|None=None):
        """
        :param tmin: Lower bound of the decay-time range in ps.
        :param tmax: Upper bound of the decay-time range in ps.
        :param seed: Optional integer seed for ``numpy``'s global legacy RNG.
            Pass a fixed value to obtain reproducible datasets.
        """
        self.tmin = tmin
        self.tmax = tmax
        if seed is not None:
            np.random.seed(seed)

        self._toy_taggers = []
        self.neutral_mode   = False         # Whether B mesons are neutral or charged
        self.flavour_specific_decay = False # Whether B mesons decay to non-CP eigenstates
        self.S: float      = 0              # CPV parameter :math:`S`
        self.Sbar: float   = 0              # CPV parameter :math:`\overline{S}`
        self.C: float      = 0              # CPV parameter :math:`C`
        self.Cbar: float   = 0              # CPV parameter :math:`\overline{C}`
        self.ADG: float    = 0              # CPV parameter :math:`A_{\Delta\Gamma}`
        self.ADGbar: float = 0              # CPV parameter :math:`\overline{A}_{\Delta\Gamma}`
        self.DM: float     = 0.5065         # Mixing frequency Δm in ps^-1 (default: Bd value)
        self.DG: float     = 0              # Width difference ΔΓ in ps^-1 (default: 0)
        self.Lifetime      = 1.52           # B-meson lifetime τ in ps (default: 1.52). Also sets Γ = 1/τ.
        self.Gamma         = 1 / 1.52       # B-meson decay width Γ in ps^-1 (default: 1/1.52). Also sets Lifetime = 1/Γ.
        self.Aprod         = 0              # Production asymmetry
        self.Adet          = 0              # Detection asymmetry

        self.absAf          = 1             # Absolute decay amplitude |A_fbar| for B → f
        self.absAfbar       = 1             # Absolute decay amplitude |A_fbar| for Bbar → fbar
        self.absLambda_f    = 1             # |λ_f| for B → f
        self.absLambda_fbar = 1             # |λ_fbar| for Bbar → fbar
        self.abs_poverq     = 1             # |p/q| (mixing parameter)
    
    def print_physics_parameters(self):
        """Print a summary of all physics parameters to stdout."""
        print(f"Oscillation:      {self.neutral_mode}")
        print(f"Flavour-specific: {self.flavour_specific_decay}")
        print(f"Δm:         {self.DM} ps^-1")
        print(f"ΔΓ:         {self.DG} ps^-1")
        print(f"S:          {self.S}")
        print(f"Sbar:       {self.Sbar}")
        print(f"C:          {self.C}")
        print(f"Cbar:       {self.Cbar}")
        print(f"AΔΓ:        {self.ADG}")
        print(f"AΔΓbar:     {self.ADGbar}")
        print(f"τ:          {self.Lifetime} ps")
        print(f"Γ:          {self.Gamma} ps^-1")
        print(f"Aprod:      {self.Aprod}")
        print(f"Adet:       {self.Adet}")
        print(f"|A_f|:      {self.absAf}")
        print(f"|A_fbar|:   {self.absAfbar}")
        print(f"|λ_f|:      {self.absLambda_f}")
        print(f"|λ_fbar|:   {self.absLambda_fbar}")
        print(f"|p/q|:      {self.abs_poverq}")

    def arctan_acceptance(self, t: np.ndarray) -> np.ndarray:
        """Built-in arctan decay-time acceptance: :math:`a(t) = \\frac{2}{\\pi}\\arctan(2t)`.

        :param t: Decay times in ps.
        :returns: Acceptance weights in ``[0, 1]``.
        """
        return 2 * np.arctan(2 * t) / np.pi

    def __sigmoid_acceptance(self, t: np.ndarray) -> np.ndarray:
        return 2 * (1 / (1 + np.exp(-1.5 * t)) - 0.5)

    def bdecay(self, t: np.ndarray, fprod: int, fdecay:int, acceptance: Callable) -> np.ndarray:
        r"""Evaluate the time-dependent B-meson decay rate PDF.

        Computes the unnormalised differential decay rate

        .. math::

            \frac{\Gamma(f_\mathrm{prod} \to f_{\mathrm{decay}})}
            {(1-f_{\text{prod}}\alpha)(1+f_{\text{decay}}\beta)}) \propto
            e^{-\Gamma t}\,\epsilon(t)\bigl[\cosh(\tfrac{1}{2}\Delta\Gamma t)
            + A_{\Delta\Gamma,f}\sinh(\tfrac{1}{2}\Delta\Gamma t)
            - f_\mathrm{prod}\,S_f\sin(\Delta m\,t)
            + f_\mathrm{prod}\,C_f\cos(\Delta m\,t)\bigr]

        multiplied by production/detection asymmetry factors and amplitude
        ratios.

        :param t: Array of decay times in ps.
        :param fprod: Production flavour: ``+1`` for B, ``-1`` for :math:`\bar{B}`.
        :param fdecay: Decay final state: ``+1`` for :math:`f`, ``-1`` for :math:`\bar{f}`.
        :param acceptance: Acceptance function :math:`a(t)`.  Must accept an
            ``np.ndarray`` and return an array of the same shape.
        :returns: Unnormalised PDF values (same shape as *t*).
        """
        if fdecay == 1:
            pdf  = np.cosh(0.5 * self.DG * t) 
            pdf += self.ADG * np.sinh(0.5 * self.DG * t)
            pdf += -fprod * self.S * np.sin(self.DM * t)
            pdf +=  fprod * self.C * np.cos(self.DM * t)
        elif fdecay == -1:
            pdf  = np.cosh(0.5 * self.DG * t) 
            pdf += self.ADGbar * np.sinh(0.5 * self.DG * t)
            pdf += -fprod * self.Sbar * np.sin(self.DM * t)
            pdf +=  fprod * self.Cbar * np.cos(self.DM * t)
        else:
            raise ValueError("fdecay must be either +1 or -1")

        # Production & detection asymmetries
        pdf *= (1 + fprod * self.Aprod) * (1 + fdecay * self.Adet)

        # Amplitude factors and |λ_f| factors
        if fdecay == 1:
            pdf *= (1 + self.absLambda_f**2) * self.absAf**2
        elif fdecay == -1:
            pdf *= (1 + self.absLambda_fbar**2) * self.absAfbar**2

        if fprod == 1 and fdecay == -1:
            pdf *= 1 / self.abs_poverq**2
        elif fprod == -1 and fdecay == 1:
            pdf *= self.abs_poverq**2

        # Exponential decay and acceptance
        pdf *= np.exp(-t / self.Lifetime) * acceptance(t)
        return pdf

    def __generate_decay(self, N:int, fprod: int, fdecay: int, acceptance: Callable) -> np.ndarray:
        # Sample decay time from exponential distribution with acceptance and CP violation
        gen = DistributionSampler(self.tmin, self.tmax, 1000, self.bdecay, fprod=fprod, fdecay=fdecay, acceptance=acceptance)
        return gen(N)

    def setPhysics(self, 
                   neutral_mode: bool    = False,
                   flavour_specific: bool = True,
                   DM: float              = 0.1,
                   DG: float              = 0,
                   S: float               = 0,
                   Sbar: float            = 0,
                   C: float               = 0,
                   Cbar: float            = 0,
                   ADG: float             = 0,
                   ADGbar: float          = 0,
                   Lifetime: float        = 1.52,
                   Aprod: float           = 0,
                   Adet: float            = 0,
                   absAf: float           = 1,
                   absAfbar: float        = 1,
                   absLambda_f: float     = 1,
                   absLambda_fbar: float  = 1,
                   abs_poverq: float      = 1):
        r"""Set the physics parameters.

        All parameters default to SM-neutral values (no CPV, Bd mixing
        frequency, zero width difference).

        :param flavour_specific: Enable flavour-specific decay (default: True).
        :param neutral_mode: If ``True``, simulate neutral B mesons with time-dependent decay rates and CPV parameters.  If ``False``, simulate charged B mesons with simple exponential decay and no CPV.  Default: ``False``.
        :param DM: Mixing frequency :math:`\Delta m` in ps\ :math:`^{-1}` (default: 0.5065).
        :param DG: Width difference :math:`\Delta\Gamma` in ps\ :math:`^{-1}` (default: 0).
        :param S: CP-odd sine coefficient for B → f (default: 0).
        :param Sbar: CP-odd sine coefficient for :math:`\bar{B} \to \bar{f}` (default: 0).
        :param C: CP-even cosine coefficient for B → f (default: 0).
        :param Cbar: CP-even cosine coefficient for :math:`\bar{B} \to \bar{f}` (default: 0).
        :param ADG: :math:`A_{\Delta\Gamma}` coefficient for B → f (default: 0).
        :param ADGbar: :math:`A_{\Delta\Gamma}` coefficient for :math:`\bar{B} \to \bar{f}` (default: 0).
        :param Lifetime: B-meson lifetime :math:`\tau` in ps (default: 1.52). Also sets :math:`\Gamma = 1/\tau`.
        :param Aprod: Production asymmetry (default: 0).
        :param Adet: Detection asymmetry (default: 0).
        :param absAf: Absolute decay amplitude :math:`|A_f|` for B → f (default: 1).
        :param absAfbar: Absolute decay amplitude :math:`|A_{\bar{f}}|` for :math:`\bar{B} \to \bar{f}` (default: 1).
        :param absLambda_f: :math:`|\lambda_f|` for B → f (default: 1).
        :param absLambda_fbar: :math:`|\lambda_{\bar{f}}|` for :math:`\bar{B} \to \bar{f}` (default: 1).
        :param abs_poverq: :math:`|p/q|` (default: 1).
        """
        assert DM > 0
        assert Lifetime > 0
        assert Aprod > -1 and Aprod < 1
        assert Adet > -1 and Adet < 1
        assert absAf >= 0
        assert absAfbar >= 0
        assert absLambda_f >= 0
        assert absLambda_fbar >= 0
        assert abs_poverq > 0

        if not neutral_mode and not flavour_specific:
            raise_error(False, "Impossible physics config: Charged B decay cannot be charge violating. Set neutral_mode=True or flavour_specific_decay=True.")

        self.neutral_mode   = neutral_mode
        self.flavour_specific_decay = flavour_specific
        self.DM             = DM
        self.DG             = DG
        self.S              = S
        self.Sbar           = Sbar
        self.C              = C
        self.Cbar           = Cbar
        self.ADG            = ADG
        self.ADGbar         = ADGbar
        self.Lifetime       = Lifetime
        self.Gamma          = 1 / Lifetime
        self.Aprod          = Aprod
        self.Adet           = Adet
        self.absAf          = absAf
        self.absAfbar       = absAfbar
        self.absLambda_f    = absLambda_f
        self.absLambda_fbar = absLambda_fbar
        self.abs_poverq     = abs_poverq

        if neutral_mode:
            if DM == 0:
                raise_error(False, "Oscillation enabled but Δm is zero")
            if S == 0 and Sbar == 0 and C == 0 and Cbar == 0 and ADG == 0 and ADGbar == 0:
                ftcalib_warning(WarnType.ToyGenerator, FTCWarnMsg.OSCILLATION_WITH_ZERO_AMPLITUDE)
            if flavour_specific and C == 0 and Cbar == 0:
                ftcalib_warning(WarnType.ToyGenerator, FTCWarnMsg.FLAVOUR_SPECIFIC_WITH_ZERO_C)

    def add_tagger(self, name: str, params_plus: list[float], params_minus: list[float], eta_shape_func: Callable, calib_func: GLMCalibrationFunction, efficiency:float=1):
        r"""Register a flavour tagger to be included in the generated dataset.

        Each call appends one tagger; call multiple times to register multiple
        taggers.  Each registered tagger contributes three columns to the output
        DataFrame: ``<name>_ETA``, ``<name>_OMEGA``, and ``<name>_DEC``.

        :param name: Column-name prefix for this tagger (e.g. ``"OSKaon"``).
        :param params_plus: Calibration parameters for B events (``FLAV_HYPOT = +1``).
            Length must match ``calib_func.npar``.
        :param params_minus: Calibration parameters for :math:`\bar{B}` events (``FLAV_HYPOT = -1``).
            Length must match ``calib_func.npar``.
        :param eta_shape_func: Callable returning the (unnormalised) mistag PDF
            over ``[0, 0.5]``.  Receives an ``np.ndarray`` and must return an
            array of the same shape or a scalar.
        :param calib_func: Calibration function instance, e.g.
            ``ft.PolynomialCalibration(2, ft.link.logit)``.
        :param efficiency: Tagging efficiency (default: 1).  Must be in ``[0, 1]``.
        """
        assert len(params_plus) == len(params_minus) == calib_func.npar, "Number of parameters for plus and minus calibration functions must match the number of parameters expected by the calibration function"
        assert efficiency >= 0 and efficiency <= 1, "Efficiency must be in [0, 1]"
        self._toy_taggers.append(self.ToyTagger(
            name              = name,
            eta_shape         = eta_shape_func,
            func_params_plus  = params_plus,
            func_params_minus = params_minus,
            func              = calib_func,
            efficiency        = efficiency
        ))

    def _cpv_asymmetry(self, fdecay: int, acceptance: Callable, precision: int=1000) -> float:
        # Nplus/Nminus must use the same acceptance as the sampler.
        # a(t) cancels pointwise in A(t), but the normalisation constants J±
        # depend on a(t) and J+ ≠ J- because pdf+ ≠ pdf-.
        # Using the flat-acceptance ratio I+/I- instead would shift every
        # data point down or up relative to the theory curve ACP(t)
        t_int = np.linspace(self.tmin, self.tmax, precision)
        J_plus  = np.trapezoid(self.bdecay(t_int, fprod=+1, fdecay=fdecay, acceptance=acceptance), t_int)
        J_minus = np.trapezoid(self.bdecay(t_int, fprod=-1, fdecay=fdecay, acceptance=acceptance), t_int)
        return J_plus / (J_plus + J_minus)

    def _final_state_fraction(self, acceptance: Callable, precision: int=1000) -> float:
        # Computes the fraction of decays to final state f=1
        t = np.linspace(self.tmin, self.tmax, precision)
        
        B_to_f       = self.bdecay(t, fprod = +1, fdecay = +1, acceptance = acceptance)
        B_to_fbar    = self.bdecay(t, fprod = +1, fdecay = -1, acceptance = acceptance)
        Bbar_to_f    = self.bdecay(t, fprod = -1, fdecay = +1, acceptance = acceptance)
        Bbar_to_fbar = self.bdecay(t, fprod = -1, fdecay = -1, acceptance = acceptance)

        numerator = np.trapezoid(B_to_f + Bbar_to_f, t)
        denom = np.trapezoid(B_to_f + Bbar_to_f + B_to_fbar + Bbar_to_fbar, t)
        return numerator / denom

    def _sample_eta(self, tagger: ToyTagger, N: int, precision: int=1000) -> np.ndarray:
        # Sample mistag from given distribution
        gen = DistributionSampler(0.001, 0.5, precision, tagger.eta_shape)
        eta = gen(N)
        eta[eta < 0] = 0
        eta[eta >= 0.5] = 0.4999

        return eta

    def __prevent_omega_underflow(self, df, eta, omega, mask_plus, mask_minus, tagger):
        # Manipulates eta until omega stays away from zero. Gives up after 10 tries
        ntries = 10
        minOmega = 0.05
        while ntries > 0:
            underflow_plus = mask_plus & (df[omega] <= minOmega)
            underflow_minus = mask_minus & (df[omega] <= minOmega) # Some tolerance because of calibration variance
            nover = underflow_plus.sum() + underflow_minus.sum()
            if nover == 0:
                print("ALL CLEAR")
                break
            print(f"Pushing {nover} eta values up...")
            # Make underflow after calibration unlikely by shifting eta up
            df.loc[underflow_plus, eta]  += minOmega - df.loc[underflow_plus, omega]  + 0.01
            df.loc[underflow_minus, eta] += minOmega - df.loc[underflow_minus, omega]  + 0.01

            # Reevaluate these omegas
            df.loc[underflow_plus, omega] = tagger.func.eval(tagger.func_params, df.loc[underflow_plus, eta], df.loc[underflow_plus, "FLAV_PROD"])
            df.loc[underflow_minus, omega] = tagger.func.eval(tagger.func_params, df.loc[underflow_minus, eta], df.loc[underflow_minus, "FLAV_PROD"])
            ntries -= 1
        if ntries == 0:
            ftcalib_warning(WarnType.ToyGenerator, FTCWarnMsg.OMEGA_MAY_UNDERFLOW)

    def generate(self, 
                 N: int,
                 tau_error_falloff: float | None   = None,
                 acceptance: str | Callable = "arctan",
                 precision: int             = 1000) -> pd.DataFrame:
        r""" 
        Generate a toy dataset with N events according to the specified physics parameters and tagger configurations.

        The returned :class:`pandas.DataFrame` contains the following columns:

        :param N: Number of events to generate.
        :param tau_error_falloff: If not ``None``, generates a TAUERR column
            with values drawn from an exponential distribution with decay constant
            *-1/tau_error_falloff*.  The TAU column is then smeared according to
            TAUERR values. Be aware, that if TAUERR is generated, it should be used in the tagger calibration. 
            Otherwise, the fit will underestimate the mistag uncertainty and input calibration parameters 
            will not be reproduced in the fit results.
        :param acceptance: Decay-time acceptance function.  Pass ``"arctan"``
            (default), ``"sigmoid"``, ``"None"`` for a flat acceptance, or a
            custom callable ``a(t) -> np.ndarray``.
        :param precision: Number of subdivisions for numerical integration and
            :class:`DistributionSampler` grids.
        :returns: :class:`pandas.DataFrame` with the columns described above.
        """

        print("Generating toy data set with these parameters")
        self.print_physics_parameters()

        if isinstance(acceptance, str):
            acc: Callable = {
                "None"    : lambda _ : 1.0,
                "arctan"  : self.arctan_acceptance,
                "sigmoid" : self.__sigmoid_acceptance,
            }[acceptance]
        else:
            acc: Callable = acceptance

        if self.neutral_mode:
            if self.flavour_specific_decay:
                N_f = int(N * self._final_state_fraction(acceptance=acc, precision=precision))
                N_fbar = N - N_f
            else:
                N_f = N
                N_fbar = 0

            Acpv    = self._cpv_asymmetry(fdecay=1, acceptance=acc)
            Acpvbar = self._cpv_asymmetry(fdecay=-1, acceptance=acc)

            N_B_to_f       = int(N_f * Acpv)
            N_Bbar_to_f    = int(N_f - N_B_to_f)
            N_B_to_fbar    = int(N_fbar * Acpvbar)
            N_Bbar_to_fbar = int(N_fbar - N_B_to_fbar)

            print("Numerical integration gives the following event counts:")
            print("N:             ", N)
            print("N_f:           ", N_f)
            print("N_fbar:        ", N_fbar)
            print("N_B_to_f:      ", N_B_to_f)
            print("N_Bbar_to_f:   ", N_Bbar_to_f)
            print("N_B_to_fbar:   ", N_B_to_fbar)
            print("N_Bbar_to_fbar:", N_Bbar_to_fbar)
            assert N_B_to_f + N_Bbar_to_f + N_B_to_fbar + N_Bbar_to_fbar == N, "Event counts do not sum up to total N. Check CPV parameters and acceptance function."
        else:
            # Non-oscillating (charged B, e.g. Bu): only B→f and B̄→f̄
            N_B_to_f       = int(N * 0.5 * (1 + self.Aprod))
            N_Bbar_to_f    = 0
            N_B_to_fbar    = 0
            N_Bbar_to_fbar = N - N_B_to_f

            print("The following event counts will be generated:")
            print("N:             ", N)
            print("N_B_to_f:      ", N_B_to_f)
            print("N_Bbar_to_fbar:", N_Bbar_to_fbar)
            assert N_B_to_f + N_Bbar_to_fbar == N, "Event counts do not sum up to total N. Check CPV parameters and acceptance function."

        print("Start of event generation...")

        # [I] Store the mode of the physical process
        df: pd.DataFrame = pd.DataFrame({"PROCESS": np.zeros(N, dtype=np.int32)})
        df.loc[:N_B_to_f, "PROCESS"]                                                   = ToyGenerator.Process.B_to_f
        df.loc[N_B_to_f:N_B_to_f + N_Bbar_to_f, "PROCESS"]                             = ToyGenerator.Process.Bbar_to_f
        df.loc[N_B_to_f + N_Bbar_to_f:N_B_to_f + N_Bbar_to_f + N_B_to_fbar, "PROCESS"] = ToyGenerator.Process.B_to_fbar
        df.loc[N_B_to_f + N_Bbar_to_f + N_B_to_fbar:, "PROCESS"]                       = ToyGenerator.Process.Bbar_to_fbar
        assert((df.PROCESS == ToyGenerator.Process.B_to_f).sum() == N_B_to_f)
        assert((df.PROCESS == ToyGenerator.Process.Bbar_to_f).sum() == N_Bbar_to_f)
        assert((df.PROCESS == ToyGenerator.Process.B_to_fbar).sum() == N_B_to_fbar)
        assert((df.PROCESS == ToyGenerator.Process.Bbar_to_fbar).sum() == N_Bbar_to_fbar)
        df["PROCESS"] = df["PROCESS"].astype(np.int32)

        # [II] Initialize production flavour
        df.eval("FLAV_PROD=0", inplace=True)
        df.loc[df.PROCESS == ToyGenerator.Process.B_to_f,       "FLAV_PROD"] = ToyGenerator.fProd.B
        df.loc[df.PROCESS == ToyGenerator.Process.B_to_fbar,    "FLAV_PROD"] = ToyGenerator.fProd.B
        df.loc[df.PROCESS == ToyGenerator.Process.Bbar_to_f,    "FLAV_PROD"] = ToyGenerator.fProd.Bbar
        df.loc[df.PROCESS == ToyGenerator.Process.Bbar_to_fbar, "FLAV_PROD"] = ToyGenerator.fProd.Bbar
        df["FLAV_PROD"] = df["FLAV_PROD"].astype(np.int32)

        # [III] Initialize decay flavour
        # In mixed samples, set it to the opposite of FLAV_PROD
        df.eval("FLAV_DECAY=FLAV_PROD", inplace=True)
        df.loc[df.PROCESS == ToyGenerator.Process.B_to_fbar, "FLAV_DECAY"] = -1 * df.FLAV_PROD[df.PROCESS == ToyGenerator.Process.B_to_fbar]
        df.loc[df.PROCESS == ToyGenerator.Process.Bbar_to_f, "FLAV_DECAY"] = -1 * df.FLAV_PROD[df.PROCESS == ToyGenerator.Process.Bbar_to_f]
        df["FLAV_DECAY"] = df["FLAV_DECAY"].astype(np.int32)

        # [IV] Initialize true decay time (MC truth)
        df.eval("TRUETAU=0.0", inplace=True)
        if self.neutral_mode:
            df.loc[df.PROCESS == ToyGenerator.Process.B_to_f,       "TRUETAU"] = self.__generate_decay(N_B_to_f,       fprod=+1, fdecay=+1, acceptance=acc)
            df.loc[df.PROCESS == ToyGenerator.Process.Bbar_to_f,    "TRUETAU"] = self.__generate_decay(N_Bbar_to_f,    fprod=-1, fdecay=+1, acceptance=acc)
            df.loc[df.PROCESS == ToyGenerator.Process.B_to_fbar,    "TRUETAU"] = self.__generate_decay(N_B_to_fbar,    fprod=+1, fdecay=-1, acceptance=acc)
            df.loc[df.PROCESS == ToyGenerator.Process.Bbar_to_fbar, "TRUETAU"] = self.__generate_decay(N_Bbar_to_fbar, fprod=-1, fdecay=-1, acceptance=acc)
        else:
            # Non-oscillating: simple exponential for all events
            simple_pdf = lambda t: np.exp(-t / self.Lifetime) * acc(t)
            gen = DistributionSampler(self.tmin, self.tmax, precision, simple_pdf)
            df["TRUETAU"] = gen(N)
        df["TRUETAU"] = df["TRUETAU"].astype(np.float32)

        # [V] Initialize measured decay time (reconstructed)
        df.eval("TAU=TRUETAU", inplace=True)
        df["TAU"] = df["TAU"].astype(np.float32)

        if tau_error_falloff is not None:
            # TAUERR is simple exponential with same acceptance function
            tauerr_pdf = lambda t: np.exp(-tau_error_falloff * t ) * acc(t)
            df["TAUERR"] = DistributionSampler(self.tmin, self.tmax, precision, tauerr_pdf)(N).astype(np.float32)
            # Smear reconstructed TAU
            df["TAU"] += np.random.normal(0, df["TAUERR"])

        # [VI] Initialize production flavour hypothesis
        # Best guess of the production flavour given the decay flavour and the decay time.
        # For non-oscillating modes FLAV_HYPOT == FLAV_PROD since there is no mixing.
        df.eval("FLAV_HYPOT=FLAV_DECAY", inplace=True)
        if self.neutral_mode:
            Amix = resolution_model.mixing_asymmetry(df.TAU, DM=self.DM, DG=self.DG, a=0)
            df.loc[Amix < 0, "FLAV_HYPOT"] *= -1
        df["FLAV_HYPOT"] = df["FLAV_HYPOT"].astype(np.int32)

        # [VII] Initialize mistags and compute tagging decisions accordingly
        for tagger in self._toy_taggers:
            # Sample mistag from given distribution
            etabranch = tagger.name + "_ETA"
            df[etabranch] = self._sample_eta(tagger, N, precision)
            df[etabranch] = df[etabranch].astype(np.float32)

            tagger.func.init_basis(df[etabranch], weight=None) # Important: Basis must be fixed to the RAW data

            # Compute calibrated mistag from sampled mistag and calibration function
            omegabranch = tagger.name + "_OMEGA"
            df.eval(f"{omegabranch}=0.5", inplace=True)
            mask_plus = df.FLAV_HYPOT == 1
            mask_minus = df.FLAV_HYPOT == -1
            df.loc[mask_plus,  omegabranch] = tagger.func.eval(tagger.func_params, df.loc[mask_plus,  etabranch], df.loc[mask_plus,  "FLAV_PROD"])
            df.loc[mask_minus, omegabranch] = tagger.func.eval(tagger.func_params, df.loc[mask_minus, etabranch], df.loc[mask_minus, "FLAV_PROD"])
            df[omegabranch] = df[omegabranch].astype(np.float32)

            # Make omega out of range unlikely
            self.__prevent_omega_underflow(df, etabranch, omegabranch, mask_plus, mask_minus, tagger)

            # Initialize perfect tagging decisions and flip according to calibrated mistag
            decbranch = tagger.name + "_DEC"
            df.eval(f"{decbranch}=FLAV_PROD", inplace=True)
            P = np.random.uniform(0, 1, size=N)
            df.loc[P < df[omegabranch], decbranch] *= -1
            df[decbranch] = df[decbranch].astype(np.int32)

        # [VIII] Shuffle the dataset to avoid ordered data
        df = df.sample(frac=1).reset_index(drop=True)

        # [IX] Set a fraction of events to untagged according to efficiency
        for tagger in self._toy_taggers:
            untagged_frac = 1 - tagger.tageff
            mask_untagged = np.random.uniform(0, 1, size=N)
            df.loc[mask_untagged < untagged_frac, tagger.name + "_DEC"] = 0
        
        df["eventNumber"] = np.arange(len(df))
        df["eventNumber"] = df["eventNumber"].astype(np.int32)
        return df


class MultiComponentToyGenerator:
    """
    Toy generator for toy data of multiple dataset components like signal, background, CPViolating backgrounds etc.

    :param mass_range: List of lower and upper mass range to generate
    :param sampling_precision: Number of interpolation bins for sampling probability distributions
    """

    class Component:
        def __init__(self, signal: bool, N: int, physics_generator: ToyGenerator, distribution: Callable[..., NPArrayFloat]):
            self.signal = signal
            self.N = N
            self.physics_generator = physics_generator
            self.mass_distribution = distribution

    def __init__(self, mass_range: list[float], sampling_precision: int=10000):
        assert isinstance(mass_range, list) and len(mass_range) == 2
        assert mass_range[1] > mass_range[0]

        self.mass_range:          list[float]               = mass_range
        self._components:         list[MultiComponentToyGenerator.Component] = []
        self._sampling_precision: int                       = sampling_precision
        self._toy_tag_configs:    list[float]               = []
        self._pdf:                list[float] | None        = []
        self._startparams:        list[float] | None        = None

    def add_component(self, signal: bool, N: int, physics_generator: ToyGenerator, distribution: Callable[..., NPArrayFloat]) -> None:
        """ Add another data component

            :param signal: Whether this component is signal or background.
            :param N: Number of events to generate for this component
            :param physics_generator: ToyGenerator instance with the physics configuration for this component
            :param distribution: Scalar probability distribution (not normalized) of a component of the data.
        """
        self._components.append(self.Component(signal, N, physics_generator, distribution))

    def __calculate_sweights(self, df):
        import sweights
        print("Calculating sweights...")
        # Compute sweights — we know the exact yields and sampling distributions,
        # so no fit is needed. PDFs must be normalised over the mass range.
        from scipy.integrate import quad

        lo, hi = self.mass_range

        signal_component     = next(c for c in self._components if c.signal)
        background_components = [c for c in self._components if not c.signal]

        N_sig = signal_component.N
        N_bkg = sum(c.N for c in background_components)

        sig_norm, _ = quad(signal_component.mass_distribution, lo, hi)
        sig_pdf = lambda x: signal_component.mass_distribution(x) / sig_norm

        # Yield-weighted sum of individually-normalised background PDFs
        bkg_norms = [quad(c.mass_distribution, lo, hi)[0] for c in background_components]
        bkg_pdf = lambda x: sum(
            c.N * c.mass_distribution(x) / norm
            for c, norm in zip(background_components, bkg_norms)
        ) / N_bkg

        sweighter = sweights.SWeight(data          = np.array(df.MASS),
                                     pdfs          = [sig_pdf, bkg_pdf],
                                     yields        = [N_sig, N_bkg],
                                     discvarranges = ((lo, hi),),
                                     method        = "summation",
                                     verbose       = True,
                                     compnames     = ["Nsig", "Nbkg"])

        df["WEIGHT"] = sweighter.get_weight(0, np.array(df.MASS))
        df["WEIGHT"] = df["WEIGHT"].astype(np.float32)


    def generate(self) -> pd.DataFrame:
        """ Generates toy data for all components and returns merged pandas DataFrame of all data

            :return: Toy data
        """

        assert [c.signal for c in self._components].count(True) == 1, "Exactly one signal component must be signal"
        assert [c.signal for c in self._components].count(False) >= 1, "One ore more pdf components must be background"

        Ncounts = np.array([component.N for component in self._components])
        Ntotal = sum(component.N for component in self._components)
        print("Total number of events to generate:", Ntotal)

        df = pd.DataFrame({"COMPONENT" : np.repeat(np.arange(0, len(self._components)), Ncounts)})

        df.eval("MASS=0.0", inplace=True)
        for n, component in enumerate(self._components):
            print("Generating component with", component.N, "events...")
            massGen = DistributionSampler(self.mass_range[0], 
                                          self.mass_range[1], 
                                          self._sampling_precision, 
                                          component.mass_distribution)
            df.loc[df.COMPONENT == n, "MASS"] = massGen(component.N)

        for n, component in enumerate(self._components):
            print("Generating physics for component", n, "...")
            physdf = component.physics_generator.generate(component.N)
            physdf.reset_index(drop=True, inplace=True)
            df.loc[df.COMPONENT == n, physdf.columns] = physdf.to_numpy()  # Without to_numpy() pandas inserts NaN columns

        self.__calculate_sweights(df)

        # Shuffle the dataset to avoid ordered data
        df = df.sample(frac=1).reset_index(drop=True)

        # Make sure there are no NaNs or infs in the data
        assert df.isna().sum().sum(axis=0) == 0, "Data contains NaN values"

        # Correct data types, since they get lost, apparently
        for col in df.columns:
            if col.endswith("OMEGA") or col.endswith("ETA") or col in ["MASS", "TRUETAU", "TAU"]:
                df[col] = df[col].astype(np.float32)
            else:
                df[col] = df[col].astype(np.int32)

        return df


if __name__ == "__main__":
    pass
