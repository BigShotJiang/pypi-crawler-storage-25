# Copyright (C) 2026 Q. Führing & V. Jevtic
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations
import os
import json
import uuid
import pathlib
import numpy as np
from typing import TypeAlias, cast, Union

from .Tagger import Tagger
from .TaggerCollection import TaggerCollection
from .printing import info
from .PolynomialCalibration import PolynomialCalibration
from .NSplineCalibration import NSplineCalibration
from .BSplineCalibration import BSplineCalibration
from .ft_types import FilePath
from .warnings import FTCWarnMsg, WarnType, ftcalib_warning

JSONPrimitive: TypeAlias = str | int | float | bool | None
JSONValue: TypeAlias = Union[JSONPrimitive, "list[JSONValue]", "dict[str, JSONValue]"]


def _serialize(obj: object) -> JSONValue:
    # Recursively converts Python/NumPy objects into JSON-serializable form.
    if isinstance(obj, dict):
        return {str(k): _serialize(v) for k, v in obj.items()}
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        return float(obj)
    if isinstance(obj, tuple):
        return _serialize(list(obj))
    if isinstance(obj, (np.ndarray, list)):
        return [_serialize(v) for v in cast(list[object], obj if isinstance(obj, list) else obj.tolist())]
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    raise TypeError(f"Cannot serialize object of type {type(obj).__name__}: {obj}")


def _save_function(tagger: Tagger) -> dict[str, JSONValue]:
    # Save info relevant for each calibration function type
    if isinstance(tagger.func, PolynomialCalibration):
        return {
            "degree" : tagger.func.npar,
            "link"   : tagger.func.link.__name__,
            "basis"  : [_serialize(vec) for vec in tagger.func.basis]
        }
    elif isinstance(tagger.func, NSplineCalibration):
        return {
            "degree" : tagger.func.npar,
            "link"   : tagger.func.link.__name__,
            "nodes"  : _serialize(tagger.func.nodes),
            "basis"  : [_serialize(vec) for vec in tagger.func.basis]
        }
    elif isinstance(tagger.func, BSplineCalibration):
        return {
            "degree" : tagger.func.npar,
            "link"   : tagger.func.link.__name__,
            "nodes"  : _serialize(tagger.func.nodes)
        }

    return {}


def save_calibration(taggers: Tagger | TaggerCollection | list[Tagger], title: str | None = None, indent: int = 2, save_path: FilePath = ".", write: bool = True):
    """ Writes calibrations of calibrated taggers to a file.

        :param taggers: Calibrated taggers
        :param title: Title of calibration file. By default, filename will be assigned a uuid. If file exists, calibrations are appended.
        :param indent: Number of indentation spaces to use in the calibration file
        :param save_path: Path to the save directory
        :param write: If True, json file is written

        :return: A dictionary of the calibration summary
    """
    def write_calibration_dict(tagger: Tagger) -> dict[str, JSONValue]:
        P = tagger.stats.params
        if not tagger.is_calibrated():
            ftcalib_warning(WarnType.Logic, FTCWarnMsg.CALIB_UNAVAILABLE_FOR_SAVING, tagger_name=tagger.name)

        calib = {
            tagger.name : {
                tagger.func.__class__.__name__ : _save_function(tagger),
                "osc" : {
                    "DeltaM"     : tagger.DeltaM,
                    "DeltaGamma" : tagger.DeltaGamma,
                    "Aprod"      : tagger.Aprod,
                },
                "calibration" : {
                    "likelihood" : "prod_flav_based",
                    "flavour_style" : {
                        "params" : [ (pn, n, s) for pn, n, s in zip(P.names_flavour, P.params_flavour, P.errors_flavour) ],
                        "cov_param_order" : [ pn for pn in P.names_flavour ],
                        "cov"    : P.covariance_flavour,
                    },
                    "delta_style" : {
                        "params" : [ (pn.replace('Δ', 'D'), n, s) for pn, n, s in zip(P.names_delta, P.params_delta, P.errors_delta) ],
                        "cov_param_order" : [ pn.replace('Δ', 'D') for pn in P.names_delta ],
                        "cov"    : P.covariance_delta,
                    }
                } if tagger.is_calibrated() else "unavailable",
                "stats" : {
                    "N"    : tagger.stats.N,
                    "Nt"   : tagger.stats.Nt,
                    "Neff" : tagger.stats.Neff,
                    "Nw"   : tagger.stats.Nw,
                    "Nwt"  : tagger.stats.Nwt,
                },
                "selected_stats" : {
                    "Ns"    : tagger.stats.Ns,
                    "Nts"   : tagger.stats.Nts,
                    "Neffs" : tagger.stats.Neffs,
                    "Nws"   : tagger.stats.Nws,
                    "Nwts"  : tagger.stats.Nwts,
                },
                "uncalibrated" : {
                    "selected" : {
                        "tag_efficiency"   : tagger.stats.tagging_efficiency(calibrated=False, inselection=True),
                        "mistag_rate"      : tagger.stats.mistag_rate(calibrated=False, inselection=True),
                        "effective_mistag" : tagger.stats.effective_mistag(calibrated=False, inselection=True),
                        "tagging_power"    : tagger.stats.tagging_power(calibrated=False, inselection=True)
                    },
                    "overall" : {
                        "tag_efficiency"   : tagger.stats.tagging_efficiency(calibrated=False, inselection=False),
                        "mistag_rate"      : tagger.stats.mistag_rate(calibrated=False, inselection=False),
                        "effective_mistag" : tagger.stats.effective_mistag(calibrated=False, inselection=False),
                        "tagging_power"    : tagger.stats.tagging_power(calibrated=False, inselection=False)
                    },
                },
                "calibrated" : {
                    "selected" : {
                        "Nts"              : tagger.stats.cal_Nts,
                        "Nwts"             : tagger.stats.cal_Nwts,
                        "tag_efficiency"   : tagger.stats.tagging_efficiency(calibrated=True, inselection=True),
                        "mistag_rate"      : tagger.stats.mistag_rate(calibrated=True, inselection=True),
                        "effective_mistag" : tagger.stats.effective_mistag(calibrated=True, inselection=True),
                        "tagging_power"    : tagger.stats.tagging_power(calibrated=True, inselection=True)
                    },
                    "overall" : {
                        "Nt"               : tagger.stats.cal_Nt,
                        "Nwt"              : tagger.stats.cal_Nwt,
                        "tag_efficiency"   : tagger.stats.tagging_efficiency(calibrated=True, inselection=False),
                        "mistag_rate"      : tagger.stats.mistag_rate(calibrated=True, inselection=False),
                        "effective_mistag" : tagger.stats.effective_mistag(calibrated=True, inselection=False),
                        "tagging_power"    : tagger.stats.tagging_power(calibrated=True, inselection=False)
                    },
                } if tagger.is_calibrated() else "unavailable"
            }
        }
        return cast(dict[str, JSONValue], _serialize(calib))

    title = str(title) if title is not None else None  # Support pathlib et al

    if isinstance(taggers, (TaggerCollection, list)):
        calib: dict[str, JSONValue] = {}
        if title is None:
            ftcalib_warning(WarnType.User, FTCWarnMsg.FILENAME_NOT_SPECIFIED)
            title = "Calibration-" + str(uuid.uuid1())
        for tagger in taggers:
            calib.update(write_calibration_dict(tagger))
    else:
        title = title or taggers.name
        calib = write_calibration_dict(taggers)

    assert title is not None

    filename = title + ".json" if not title.endswith(".json") else title

    if write:
        filepath = pathlib.PosixPath(save_path) / filename
        if os.path.exists(filepath):
            info(f"Calibration file \"{filepath}\" exists: Appending calibrations")
            existing = json.load(open(filepath, "r"))
            existing.update(calib)
            json.dump(existing, open(filepath, "w"), indent=indent)
        else:
            info(f"Calibration written to new file \"{filepath}\"")
            json.dump(calib, open(filepath, "w"), indent=indent)

    return calib
