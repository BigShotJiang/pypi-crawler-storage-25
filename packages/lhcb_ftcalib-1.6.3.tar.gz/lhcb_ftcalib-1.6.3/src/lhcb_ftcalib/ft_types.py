# Copyright (C) 2026 Q. Führing & V. Jevtic
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations
import pathlib
from typing import Any, Callable, Literal
import numpy
import numpy.typing as npt
import pandas
from enum import Enum

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .Tagger import Tagger
    from .apply_tagger import TargetTagger, TargetTaggerCollection
    from .TaggerCollection import TaggerCollection

    TaggerList = list[Tagger] | list[TargetTagger] | TaggerCollection | TargetTaggerCollection
    AnyTaggerCollection = TaggerCollection | TargetTaggerCollection
else:
    TaggerList = Any
    AnyTaggerCollection = Any

NPArrayFloat            = npt.NDArray[numpy.float64]
NPArrayBool             = npt.NDArray[numpy.bool_]
NPArrayInt              = npt.NDArray[numpy.int_]
NPArrayOrPandas         = numpy.ndarray | pandas.Series
NPMatrix                = list[NPArrayFloat]  # Numpy does not implement this as a type
NPArrayOrScalar         = npt.ArrayLike | pandas.Series | float
FilePath                = pathlib.PosixPath | str
StrOptionOrSettingsList = str | list[Any]
ScalarFunction          = Callable[[NPArrayFloat], NPArrayFloat]
TransformFunc           = Callable[[float], float]
ScaleType               = Literal["asinh", "linear", "log", "logit", "symlog"] | tuple[TransformFunc, TransformFunc]

def _to_numpy(x: pandas.Series | numpy.ndarray | list[float]) -> numpy.ndarray:
    if isinstance(x, pandas.Series):
        return x.to_numpy()
    if isinstance(x, list):
        return numpy.array(x, dtype=type(x[0]))
    return x

class CalibrationMode(Enum):
    Bd = "Bd"
    Bu = "Bu"
    Bs = "Bs"
    TRUEID = "TRUEID"

    @property
    def oscillation(self) -> bool:
        return self in (CalibrationMode.Bd, CalibrationMode.Bs)

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, CalibrationMode):
            return self.value == other.value
        elif isinstance(other, str):
            return self.value == other
        return False
    
    def __str__(self) -> str:
        return self.value
