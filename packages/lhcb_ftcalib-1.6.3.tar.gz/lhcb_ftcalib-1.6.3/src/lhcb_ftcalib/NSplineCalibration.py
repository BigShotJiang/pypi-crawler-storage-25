# Copyright (C) 2026 Q. Führing & V. Jevtic
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations
import numpy as np

from .ft_types import NPArrayFloat
from .CalibrationFunction import GLMCalibrationFunction
from . import link_functions
from .link_functions import link_function


class NSplineCalibration(GLMCalibrationFunction):
    r""" NSplineCalibration
        Cubic spline GLM

        :math:`\displaystyle\omega(\eta)=g^{-1}\left(g(\eta) + \sum_{i=0}^mp_ic_ib_i\right)`

        with calibration parameters :math:`p_i`, orthogonal spline basis coefficients :math:`c_i` and spline basis vectors :math:`b_i`.
        By default, the nodes are positioned at the :math:`q\in[1/n, 2/n, \cdots, (n+1)/n]` quantiles of the mistag distribution
        for :math:`n+2` given nodes.

        :param npar: number of calibration parameters per flavour
    """

    def __init__(self, npar: int, link: type[link_function]=link_functions.mistag):
        GLMCalibrationFunction.__init__(self, npar + 2, link)

        assert npar >= 0

        # Initialize non-orthogonal basis
        self.basis: NPArrayFloat = np.eye(self.npar)
        self.nodes: NPArrayFloat = np.sort(link.L(np.linspace(0, 0.5, self.npar)))

    def init_basis(self, eta: NPArrayFloat, weight: NPArrayFloat | None=None):
        r"""
        Computes a mistag-density dependent basis of ortogonal cubic splines (called by Tagger classes)
        :math:`\{S_n\}` for the scalar product :math:`\langle S_k,S_j
        \rangle=\sum_{n=1}^NS_k(\eta_n)S_j(\eta_n)w_n \gamma_n=\delta_{kj}`
        whereby :math:`w` is an event weight and :math:`\gamma` is an
        additional weight depending on the specified link. By default no basis
        is initialized and calibration function is not callable.

        :param eta: Raw mistag
        :param weight: Event weight
        """
        self.nodes = np.sort(self.link.L(np.quantile(eta, np.linspace(0, 1, self.npar))))

        deg = self.npar
        moments = np.zeros((deg, deg))
        if weight is None:
            weight = np.ones_like(eta)

        if self.link != link_functions.mistag:
            denom = eta * (1 - eta) * self.link.DL(eta) ** 2
        else:
            denom = 1

        basis_values = self.__get_basis_values_for_identity(self.link.L(eta))

        for i in range(deg):
            for j in range(deg):
                moments[i][j] = np.sum(basis_values[i] * basis_values[j] * weight / denom)
        moments /= np.sum(weight)

        def prod(v1, v2):
            s = 0
            for i in range(deg):
                for j in range(deg):
                    s += v1[i] * v2[j] * moments[i][j]
            return s

        # Gram Schmidt
        basis: NPArrayFloat = np.eye(deg)
        for i in range(deg):
            basis[i] /= np.sqrt(prod(basis[i], basis[i]))

            for j in range(i + 1, deg):
                basis[j] -= basis[i] * prod(basis[i], basis[j])

        for i in range(deg):
            basis[i] /= basis[i][i]

        basis = list(basis)
        for i in range(deg):
            basis[i] = basis[i][:i + 1][::-1]

        self.basis = basis

    def set_basis(self, basis: list, nodes: NPArrayFloat) -> None:
        self.basis = basis
        self.nodes = np.sort(nodes)

    def __get_basis_values_for_identity(self, eta: NPArrayFloat) -> NPArrayFloat:
        # Computes spline basis coefficients {1, x, n2(x), n3(x), ...} for identity basis
        # cub = np.zeros(self.npar)
        cub = np.empty(self.npar, dtype=object)
        # Basic cubic spline
        for s in range(self.npar):
            cub[s] = (eta - self.nodes[s]) ** 3
            cub[s][eta < self.nodes[s]] = 0.0

        # Boundary conditions
        last = self.npar - 1
        for s in range(self.npar - 1):
            cub[s] = cub[s] - cub[last]
            cub[s] /= self.nodes[last] - self.nodes[s]

        # Basis coefficients
        basis_values = np.zeros((self.npar, len(eta)))
        basis_values[0] = np.ones_like(eta)
        basis_values[1] = eta
        for s in range(self.npar - 2):
            basis_values[s + 2] = cub[s] - cub[last - 1]

        return basis_values

    def eval(self, params: list[float], eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        basis_values = self.__get_basis_values_for_identity(self.link.L(eta))
        omega = self.link.L(eta)

        for p, bvec in enumerate(self.basis):
            for k, basis_coeff in enumerate(reversed(bvec)):
                omega[dec == +1] += params[p]             * basis_coeff * basis_values[k][dec == +1]
                omega[dec == -1] += params[p + self.npar] * basis_coeff * basis_values[k][dec == -1]

        return self.link.InvL(omega)

    def eval_averaged(self, params: list[float], eta: NPArrayFloat) -> NPArrayFloat:
        basis_values = self.__get_basis_values_for_identity(self.link.L(eta))
        omega = self.link.L(eta)

        for p, bvec in enumerate(self.basis):
            for k, basis_coeff in enumerate(reversed(bvec)):
                omega += params[p] * basis_coeff * basis_values[k]

        return self.link.InvL(omega)

    def eval_plotting(self, params: list[float], eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        n_pos = np.sum(dec ==  1)
        n_neg = np.sum(dec == -1)
        f = n_pos / (n_pos + n_neg)

        omega = self.link.L(eta)

        basis_values = self.__get_basis_values_for_identity(self.link.L(eta))
        for p, bvec in enumerate(self.basis):
            for k, basis_coeff in enumerate(reversed(bvec)):
                omega += (f * params[p] + (1 - f) * params[p + self.npar]) * basis_coeff * basis_values[k]

        return self.link.InvL(omega)

    def derivative(self, partial: int, params: list[float], eta: NPArrayFloat, dec: NPArrayFloat) -> NPArrayFloat:
        D_outer = self.link.InvDL(self.link.L(self.eval(params, eta, dec)))
        basis_values = self.__get_basis_values_for_identity(self.link.L(eta))

        D_inner = np.zeros_like(eta)
        if partial < self.npar:
            for k, basis_coeff in enumerate(reversed(self.basis[partial])):
                D_inner[dec == +1] += basis_coeff * basis_values[k][dec == +1]
        else:
            for k, basis_coeff in enumerate(reversed(self.basis[partial - self.npar])):
                D_inner[dec == -1] += basis_coeff * basis_values[k][dec == -1]

        return D_outer * D_inner

    def derivative_averaged(self, partial: int, params: list[float], eta: NPArrayFloat) -> NPArrayFloat:
        D_outer = self.link.InvDL(self.link.L(self.eval_averaged(params, eta)))
        basis_values = self.__get_basis_values_for_identity(self.link.L(eta))

        D_inner = np.zeros_like(eta)
        for k, basis_coeff in enumerate(reversed(self.basis[partial])):
            D_inner += basis_coeff * basis_values[k]

        return D_outer * D_inner

    def print_basis(self) -> None:
        print("Spline node positions (mistag quantiles)")
        print(", ".join([str(np.round(n, 4)) for n in self.nodes]))

        def fmt_exp(coeff, i, N):
            ex = ""
            if N - i - 1 == 0:
                ex = "1" if coeff == 1.0 else "{0:+.4f}".format(coeff)
            elif N - i - 1 == 1:
                ex = "x" if coeff == 1.0 else "{0:+.4f}·x".format(coeff)
            elif N - i - 1 > 1:
                ex = f"n{N - i - 1}(x)"
                if i > 0:
                    ex = "{0:+.4f}·".format(coeff) + ex
            return ex

        print(f"Link function: {self.link.__name__}")
        print("Spline basis")
        for i, bvec in enumerate(self.basis):
            print(f"S_{i}(x) = {fmt_exp(bvec[0], 0, len(bvec))}", end=" ")
            for c, coeff in enumerate(bvec[1:]):
                print(fmt_exp(coeff, c + 1, len(bvec)), end=" ")
            print()
