# Copyright (C) 2026 Q. Führing & V. Jevtic
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations
import numpy as np
from .ft_types import NPArrayFloat

class CalParameters:
    r""" Calibration parameter class

        Stores calibration paramaters and transforms between different parameter conventions

        :param npar: Number of parameters per flavour
    """

    def __init__(self, npar: int):
        size = 2 * npar
        self.npar: int = npar
        self.params_flavour: NPArrayFloat = np.zeros(size)  #: Nominal values (flavour representation)
        self.params_delta: NPArrayFloat   = np.zeros(size)  #: Nominal values (delta representation)
        self.params_average: NPArrayFloat = np.zeros(npar)  #: Nominal values (averaged representation)

        self.errors_flavour: NPArrayFloat = np.zeros(size)  #: Parameter error (flavour representation)
        self.errors_delta: NPArrayFloat   = np.zeros(size)  #: Parameter error (delta representation)
        self.errors_average: NPArrayFloat = np.zeros(npar)  #: Parameter error (averaged representation)

        self.covariance_flavour: NPArrayFloat = np.zeros((size, size))  #: Parameter covariance (flavour representation)
        self.covariance_delta: NPArrayFloat   = np.zeros((size, size))  #: Parameter covariance (delta representation)
        self.covariance_average: NPArrayFloat = np.zeros((npar, npar))  #: Parameter covariance (averaged representation)

        self._flavour2delta: NPArrayFloat = np.block([[0.5*np.eye(npar), 0.5*np.eye(npar)], [np.eye(npar), -np.eye(npar)]])
        self._delta2flavour: NPArrayFloat = np.block([[np.eye(npar), 0.5*np.eye(npar)], [np.eye(npar), -0.5*np.eye(npar)]])

        self.names_flavour: list[str] = [f"p{i}+" for i in range(npar)] + [f"p{i}-" for i in range(npar)]  #: Parameter names (flavour representation)
        self.names_delta: list[str]   = [f"p{i}" for i in range(npar)] + [f"Δp{i}" for i in range(npar)]   #: Parameter names (delta representation)
        self.names_average: list[str] = [f"p{i}" for i in range(npar)]                                     #: Parameter names (averaged representation)

        self.names_latex_flavour: list[str] = [fr"p_{i}^+" for i in range(npar)] + [fr"p_{i}^-" for i in range(npar)]    #: Parameter names latex (flavour representation)
        self.names_latex_delta: list[str]   = [fr"p_{i}" for i in range(npar)] + [fr"\Delta p_{i}" for i in range(npar)]  #: Parameter names latex (delta representation)
        self.names_latex_average: list[str] = [fr"p_{i}" for i in range(npar)]                                           #: Parameter names latex (averaged representation)

    def set_calibration_flavour(self, params_flavour: list[float], covariance_flavour: NPArrayFloat):
        """
        Initializes parameters for a given calibration in the flavour representation

        :param params_flavour: Nominal values
        :param covariance_flavour: Covariance matrix
        """
        self.params_flavour     = np.array(params_flavour)
        self.covariance_flavour = np.array(covariance_flavour)
        self.errors_flavour     = np.sqrt(np.diag(self.covariance_flavour))

        self.params_delta     = self._flavour2delta @ self.params_flavour
        self.covariance_delta = self._flavour2delta @ self.covariance_flavour @ self._flavour2delta.T
        self.errors_delta     = np.sqrt(np.diag(self.covariance_delta))

        self.params_average     = self.params_delta[:self.npar]
        self.covariance_average = self.covariance_delta[:self.npar, :self.npar]
        self.errors_average     = np.sqrt(np.diag(self.covariance_average))

    def set_calibration_delta(self, params_delta: list[float], covariance_delta: NPArrayFloat):
        """ Initializes parameters for a given calibration in the delta representation

        :param params_flavour: Nominal values
        :param covariance_flavour: Covariance matrix
        """
        self.params_delta     = np.array(params_delta)
        self.covariance_delta = np.array(covariance_delta)
        self.errors_delta     = np.sqrt(np.diag(self.covariance_delta))

        self.params_flavour     = self._delta2flavour @ self.params_delta
        self.covariance_flavour = self._delta2flavour @ self.covariance_delta @ self._delta2flavour.T
        self.errors_flavour     = np.sqrt(np.diag(self.covariance_flavour))

        self.params_average     = self.params_delta[:self.npar]
        self.covariance_average = self.covariance_delta[:self.npar, :self.npar]
        self.errors_average     = np.sqrt(np.diag(self.covariance_average))

    def __len__(self) -> int:
        return self.npar

    def __str__(self) -> str:
        s = "CalParameters <"
        s += ", ".join([f"{n}={np.round(v, 5)}±{np.round(e, 5)}" for n, v, e in zip(self.names_delta, self.params_delta, self.errors_delta)])
        return s + ">"

    def __repr__(self) -> str:
        return self.__str__()
