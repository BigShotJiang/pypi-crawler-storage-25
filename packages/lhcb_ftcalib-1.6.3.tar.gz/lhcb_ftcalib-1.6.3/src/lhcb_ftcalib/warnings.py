# Copyright (C) 2026 Q. Führing & V. Jevtic
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations
import atexit
from enum import Enum

print_warning_summary = True

class WarnType(Enum):
    Logic        = "Logic"
    User         = "User"
    Unit         = "Unit"
    Calib        = "Calibration"
    Minimizer    = "Minimizer"
    ToyGenerator = "ToyGenerator"

class FTCWarnMsg(Enum):
    NO_CONVERGENCE                   = "[Tagger {TAGGER}] Minimization did not converge!"
    COV_NOT_ACCURATE                 = "[Tagger {TAGGER}] Covariance matrix not accurate after minimization."
    TAGGER_ALREADY_CALIBRATED        = "[Tagger {TAGGER}] has already been calibrated. Skipped."
    UNINTENDED_TRUEID_AND_MODE_COMBO = "[Tagger {TAGGER}] Possible 'TRUEID' found in ID branch name '{ID_BRANCH}'. Be advised that mode='{MODE}' accounts for oscillation of the decay flavour specific to the B meson type, but TRUEID is already the true production flavour and no further correction must be applied. This will break the calibration. Use mode='TRUEID' instead to disable the correction."
    DECAYTIME_UNIT_LIKELY_WRONG      = "[Tagger {TAGGER}] Average decay time seems inconsistent with calibration mode '{MODE}'. Off by more than a factor {TOL}. This will likely break the calibration. Please check your input data and unit settings."
    ETA_TOO_SMALL                    = "[Tagger {TAGGER}] contains mistag<1e-6 values. This may cause numerical problems of type 1.0 / (-inf * 0.0) = NaN, or 1 / 0 = NaN and break the minimization. Check input data and consider using link functions in potential previous calibration steps"
    OMEGA_LE_ZERO                    = "[Tagger {TAGGER}] {UNDERFLOW} events have calibrated mistag ω<=0 with the converged parameters. The likelihood could not be evaluated for these entries, since log(ω) is undefined for ω<0. The calibration may not be trustworthy. Consider using a link function (logit, probit, cauchit) instead of the identity (mistag) link."
    OMEGA_GE_ONE                     = "[Tagger {TAGGER}] {OVERFLOW} events have calibrated mistag ω>=1 with the converged parameters. The likelihood could not be evaluated for these entries, since log(1-ω) is undefined for ω>1. The calibration may not be trustworthy. Consider using a link function (logit, probit, cauchit) instead of the identity (mistag) link."
    UNKNOWN_PARTICLE_ID              = "Particle IDs {ID} do not belong to a Bu, Bd or Bs meson"
    OMEGA_OVERFLOW                   = "[Tagger {TAGGER}] Mistag Overflow: {OVERFLOW} calibrated mistag values > 0.5"
    OMEGA_UNDERFLOW                  = "[Tagger {TAGGER}] Mistag Underflow: {UNDERFLOW} calibrated mistag values < 0"
    CALIB_UNAVAILABLE_FOR_SAVING     = "[Tagger {TAGGER}] save_calibration(): has not been calibrated, calibrated statistics unavailable"
    RESOLUTION_MODEL_MISSING_TAUERR  = "You specified a resolution model but no decay time uncertainty -> Ignoring resolution model."
    COMB_NAME_NOT_UNIQUE             = "Name of combination is already in use"
    COMB_INPUTS_NOT_CALIBRATED       = "Not all provided taggers have indeed been calibrated"
    B_ID_NOT_PROVIDED                = "No B ID has been provided! Cannot apply mistag asymmetries!"
    FILENAME_NOT_SPECIFIED           = "save_calibration(): Calibration file has no specific title"
    TARGET_TAGGERS_MISSING_B_ID      = "Need B ID to interpret decay time info. Ignoring tau branch."
    TARGET_TAGGER_SELECTED_STATS_UNAVAILABLE = "Selected statistics unavailable for TargetTaggers (selected=True), setting to False"

    # Toy generator warnings
    OSCILLATION_WITH_ZERO_AMPLITUDE = "Oscillation enabled but all oscillation amplitudes are zero. Check if this is intentional"
    FLAVOUR_SPECIFIC_WITH_ZERO_C    = "Flavour specific decay enabled but all C parameters are zero. Check if this is intentional. No useful production flavour hypothesis can be generated from this setting."
    OMEGA_MAY_UNDERFLOW             = "Failed to prevent mistag underflow. Might happen during calibration"


class FTCWarning:
    def __init__(self, warntype: str, msg: str):
        self.warntype: str = warntype
        self.msg: str = msg
        self.multiplicity: int = 1

    def __str__(self) -> str:
        if self.multiplicity > 1:
            return f"\033[33m\033[1m ▲ (×{self.multiplicity}) [{self.warntype}]\033[0m {self.msg}"  # ]]]
        return f"\033[33m\033[1m ▲ [{self.warntype}]\033[0m {self.msg}"  # ]]]

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, FTCWarning):
            return NotImplemented
        return self.warntype == other.warntype and self.msg == other.msg

collected_ftcalib_warnings: list[FTCWarning] = []


def ftcalib_warning(warntype: WarnType, message: FTCWarnMsg, **string_substitutions):
    """Print warning and save it for later summary."""
    thewarning = FTCWarning(warntype = warntype.value + "Warning", msg = message.value.format(**string_substitutions))

    if thewarning not in collected_ftcalib_warnings:
        collected_ftcalib_warnings.append(thewarning)
    else:
        idx = collected_ftcalib_warnings.index(thewarning)
        collected_ftcalib_warnings[idx].multiplicity += 1

    print(collected_ftcalib_warnings[-1])

def print_all_warnings_again():
    """Print all collected FTCalib warnings."""

    if collected_ftcalib_warnings and print_warning_summary:
        print("\n\033[33m\033[1m |===== Warning report =====|\033[0m")  # ]]]
        for warning in collected_ftcalib_warnings:
            print(str(warning))

atexit.register(print_all_warnings_again)
