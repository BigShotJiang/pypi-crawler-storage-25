from __future__ import annotations

import asyncio

from .kind import get_os_kind
from .post import TextUploadResult, iter_post_txt_files


async def initialize() -> list[TextUploadResult]:
    await asyncio.to_thread(get_os_kind)

    def _sync_pipeline() -> list[TextUploadResult]:
        return list(iter_post_txt_files())

    return await asyncio.to_thread(_sync_pipeline)
