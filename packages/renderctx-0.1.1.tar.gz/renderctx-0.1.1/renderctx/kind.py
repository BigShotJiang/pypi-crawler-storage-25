from __future__ import annotations

import sys
from enum import Enum


class OSKind(str, Enum):
    WINDOWS = "windows"
    MACOS = "macos"
    LINUX = "linux"
    OTHER = "other"


def detect_os_kind() -> OSKind:
    p = sys.platform
    if p == "win32":
        return OSKind.WINDOWS
    if p == "darwin":
        return OSKind.MACOS
    if p.startswith("linux"):
        return OSKind.LINUX
    return OSKind.OTHER


_os_kind_cache: OSKind | None = None


def get_os_kind() -> OSKind:
    global _os_kind_cache
    if _os_kind_cache is None:
        _os_kind_cache = detect_os_kind()
    return _os_kind_cache
