"""Base client for interacting with MultiversX smart contracts."""

import time
from pathlib import Path
from typing import Any

from multiversx_sdk import (
    Account,
    Address,
    ProxyNetworkProvider,
    SmartContractTransactionsFactory,
    Transaction,
    TransactionsFactoryConfig,
    SmartContractQuery,
)

from .config import NetworkConfig

# Default gas limit for contract calls
DEFAULT_GAS_LIMIT = 60_000_000


class BaseClient:
    """Low-level client wrapping MultiversX SDK operations."""

    def __init__(self, pem_path: str, network: NetworkConfig):
        self.network = network
        self.account = Account.new_from_pem(Path(pem_path))
        self.proxy = ProxyNetworkProvider(network.proxy_url)
        self.factory_config = TransactionsFactoryConfig(chain_id=network.chain_id)
        self.sc_factory = SmartContractTransactionsFactory(self.factory_config)

    @property
    def address(self) -> Address:
        """Return the wallet address."""
        return self.account.address

    @property
    def bech32(self) -> str:
        """Return the wallet address as bech32 string."""
        return self.account.address.to_bech32()

    def _refresh_nonce(self):
        """Fetch and set the current account nonce from the network."""
        account_on_network = self.proxy.get_account(self.account.address)
        self.account.nonce = account_on_network.nonce

    def call(
        self,
        contract: str,
        function: str,
        arguments: list[Any] | None = None,
        value: int = 0,
        gas_limit: int = DEFAULT_GAS_LIMIT,
    ) -> str:
        """
        Execute a smart contract call (transaction).
        Returns the transaction hash.
        """
        self._refresh_nonce()

        tx = self.sc_factory.create_transaction_for_execute(
            sender=self.account.address,
            contract=Address.new_from_bech32(contract),
            function=function,
            gas_limit=gas_limit,
            arguments=arguments or [],
            native_transfer_amount=value,
        )
        tx.nonce = self.account.get_nonce_then_increment()
        tx.signature = self.account.sign_transaction(tx)

        tx_hash = self.proxy.send_transaction(tx)
        return tx_hash

    def query(
        self,
        contract: str,
        function: str,
        arguments: list[Any] | None = None,
    ) -> list[bytes]:
        """
        Execute a smart contract query (read-only, no transaction).
        Returns raw response data parts.
        """
        # Convert arguments to bytes — the VM query expects bytes, not Address objects
        raw_args = []
        for arg in (arguments or []):
            if isinstance(arg, Address):
                raw_args.append(arg.get_public_key())
            elif isinstance(arg, bytes):
                raw_args.append(arg)
            elif isinstance(arg, str):
                raw_args.append(arg.encode())
            elif isinstance(arg, int):
                byte_len = max(1, (arg.bit_length() + 7) // 8)
                raw_args.append(arg.to_bytes(byte_len, "big"))
            else:
                raw_args.append(bytes(arg))

        query = SmartContractQuery(
            contract=Address.new_from_bech32(contract),
            function=function,
            arguments=raw_args,
        )
        response = self.proxy.query_contract(query)
        return response.return_data_parts

    def wait_for_tx(self, tx_hash: str, timeout: int = 30, poll_interval: float = 1.0) -> dict:
        """
        Wait for a transaction to be processed.
        Returns the transaction data from the API.
        """
        import requests

        api_url = self.network.proxy_url.replace("gateway", "api")
        deadline = time.time() + timeout

        while time.time() < deadline:
            try:
                resp = requests.get(f"{api_url}/transactions/{tx_hash}", timeout=5)
                if resp.status_code == 200:
                    data = resp.json()
                    status = data.get("status", "")
                    if status in ("success", "fail", "invalid"):
                        return data
            except requests.RequestException:
                pass
            time.sleep(poll_interval)

        raise TimeoutError(f"Transaction {tx_hash} not finalized within {timeout}s")
