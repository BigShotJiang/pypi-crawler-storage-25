"""EscrowManager client — create, confirm, dispute, and track escrows."""

from dataclasses import dataclass
from typing import Optional

from multiversx_sdk import Address

from .base import BaseClient


# 1 EGLD = 10^18 wei
EGLD_DECIMALS = 10**18


@dataclass
class EscrowData:
    """Parsed escrow data."""
    escrow_id: int
    consumer: str
    provider: str
    amount_wei: int
    status: str  # Funded, Completed, Disputed, TimedOut
    created_at: int
    timeout_blocks: int
    description: str

    @property
    def amount_egld(self) -> float:
        """Amount in EGLD (human-readable)."""
        return self.amount_wei / EGLD_DECIMALS


def egld_to_wei(amount: float) -> int:
    """Convert EGLD to wei (smallest unit)."""
    return int(amount * EGLD_DECIMALS)


class EscrowClient:
    """High-level client for the EscrowManager smart contract."""

    def __init__(self, base: BaseClient, contract_address: str):
        self.base = base
        self.contract = contract_address

    def create(
        self,
        provider: str,
        description: str,
        amount_egld: float,
        wait: bool = True,
    ) -> tuple[str, Optional[int]]:
        """
        Create a new escrow, locking EGLD for a provider.

        Args:
            provider: The provider agent's address (bech32)
            description: Description of the service requested
            amount_egld: Amount of EGLD to lock
            wait: If True, wait for confirmation

        Returns:
            Tuple of (tx_hash, escrow_id or None)
        """
        amount_wei = egld_to_wei(amount_egld)

        tx_hash = self.base.call(
            contract=self.contract,
            function="createEscrow",
            arguments=[
                Address.new_from_bech32(provider),
                description.encode(),
            ],
            value=amount_wei,
        )

        escrow_id = None
        if wait:
            result = self.base.wait_for_tx(tx_hash)
            if result.get("status") != "success":
                raise RuntimeError(f"Create escrow failed: {result.get('status')}")
            # Try to extract escrow ID from results
            escrow_id = self._extract_escrow_id(result)

        return tx_hash, escrow_id

    def confirm(self, escrow_id: int, wait: bool = True) -> str:
        """
        Confirm delivery — releases funds to the provider.
        Only the consumer can call this.
        """
        tx_hash = self.base.call(
            contract=self.contract,
            function="confirmDelivery",
            arguments=[escrow_id],
        )

        if wait:
            result = self.base.wait_for_tx(tx_hash)
            if result.get("status") != "success":
                raise RuntimeError(f"Confirm delivery failed: {result.get('status')}")

        return tx_hash

    def dispute(self, escrow_id: int, wait: bool = True) -> str:
        """
        Dispute an escrow — refunds the consumer.
        Must be called before timeout.
        """
        tx_hash = self.base.call(
            contract=self.contract,
            function="disputeEscrow",
            arguments=[escrow_id],
        )

        if wait:
            result = self.base.wait_for_tx(tx_hash)
            if result.get("status") != "success":
                raise RuntimeError(f"Dispute failed: {result.get('status')}")

        return tx_hash

    def claim_timeout(self, escrow_id: int, wait: bool = True) -> str:
        """
        Claim timeout release — anyone can call after timeout.
        Releases funds to provider.
        """
        tx_hash = self.base.call(
            contract=self.contract,
            function="claimTimeout",
            arguments=[escrow_id],
        )

        if wait:
            result = self.base.wait_for_tx(tx_hash)
            if result.get("status") != "success":
                raise RuntimeError(f"Claim timeout failed: {result.get('status')}")

        return tx_hash

    def get_escrow(self, escrow_id: int) -> Optional[dict]:
        """Get escrow details (raw bytes for now)."""
        result = self.base.query(
            contract=self.contract,
            function="getEscrow",
            arguments=[escrow_id],
        )
        if not result or not result[0]:
            return None
        return {"raw_hex": result[0].hex(), "escrow_id": escrow_id}

    def get_count(self) -> int:
        """Get total number of escrows created."""
        result = self.base.query(
            contract=self.contract,
            function="getEscrowCount",
        )
        if not result or not result[0]:
            return 0
        return int.from_bytes(result[0], "big")

    def get_active_count(self) -> int:
        """Get number of currently active (funded) escrows."""
        result = self.base.query(
            contract=self.contract,
            function="getActiveEscrowCount",
        )
        if not result or not result[0]:
            return 0
        return int.from_bytes(result[0], "big")

    def get_total_volume(self) -> int:
        """Get total EGLD volume (in wei) processed through escrows."""
        result = self.base.query(
            contract=self.contract,
            function="getTotalVolume",
        )
        if not result or not result[0]:
            return 0
        return int.from_bytes(result[0], "big")

    def _extract_escrow_id(self, tx_data: dict) -> Optional[int]:
        """Try to extract the escrow ID from transaction results."""
        results = tx_data.get("results", [])
        for r in results:
            data = r.get("data", "")
            if data.startswith("@6f6b@"):
                # @ok@<hex_id>
                hex_id = data.split("@")[-1]
                if hex_id:
                    try:
                        return int(hex_id, 16)
                    except ValueError:
                        pass
        return None
