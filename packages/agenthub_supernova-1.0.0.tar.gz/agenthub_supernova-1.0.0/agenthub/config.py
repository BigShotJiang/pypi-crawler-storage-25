"""Network configuration for AgentHub."""

from dataclasses import dataclass


@dataclass
class NetworkConfig:
    proxy_url: str
    chain_id: str
    explorer_url: str

    @staticmethod
    def testnet() -> "NetworkConfig":
        return NetworkConfig(
            proxy_url="https://testnet-gateway.multiversx.com",
            chain_id="T",
            explorer_url="https://testnet-explorer.multiversx.com",
        )

    @staticmethod
    def devnet() -> "NetworkConfig":
        return NetworkConfig(
            proxy_url="https://devnet-gateway.multiversx.com",
            chain_id="D",
            explorer_url="https://devnet-explorer.multiversx.com",
        )

    @staticmethod
    def mainnet() -> "NetworkConfig":
        return NetworkConfig(
            proxy_url="https://gateway.multiversx.com",
            chain_id="1",
            explorer_url="https://explorer.multiversx.com",
        )


@dataclass
class ContractAddresses:
    """Deployed contract addresses."""
    agent_registry: str
    escrow_manager: str
    reputation_tracker: str

    @staticmethod
    def testnet() -> "ContractAddresses":
        return ContractAddresses(
            agent_registry="erd1qqqqqqqqqqqqqpgquen89xhkc83qf50m6my7erkk3nylt0dy4d9qdpz4c6",
            escrow_manager="erd1qqqqqqqqqqqqqpgqnsej406wuu5jv0578uu6pqda7v0xqkzd4d9q8msdkh",
            reputation_tracker="erd1qqqqqqqqqqqqqpgqlu6yayq09wvq844ga3tef6w73ad950w54d9qrcdj9y",
        )

    @staticmethod
    def mainnet() -> "ContractAddresses":
        """Mainnet addresses — update after running deploy-mainnet.sh."""
        return ContractAddresses(
            agent_registry="erd1TODO_REPLACE_AFTER_MAINNET_DEPLOY",
            escrow_manager="erd1TODO_REPLACE_AFTER_MAINNET_DEPLOY",
            reputation_tracker="erd1TODO_REPLACE_AFTER_MAINNET_DEPLOY",
        )
