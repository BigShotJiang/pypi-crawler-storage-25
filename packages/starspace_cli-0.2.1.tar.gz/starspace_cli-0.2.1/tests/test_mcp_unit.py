"""Unit tests for the MCP client wiring - no network."""
from __future__ import annotations

import json
from unittest.mock import patch, MagicMock

import pytest

from starspace_cli.client import StarSpaceClient
from starspace_cli.errors import StarSpaceError


@pytest.fixture
def client() -> StarSpaceClient:
    return StarSpaceClient(api_key="ak_unit_test", base_url="https://example.test")


def _make_response(*, body: str, status: int = 200, content_type: str = "application/json"):
    """Mock a requests.Response that's good enough for _check + _parse."""
    resp = MagicMock()
    resp.ok = 200 <= status < 400
    resp.status_code = status
    resp.headers = {"Content-Type": content_type}
    resp.text = body
    if content_type.startswith("application/json"):
        resp.json = lambda: json.loads(body)
    else:
        resp.json = lambda: (_ for _ in ()).throw(ValueError("not json"))
    return resp


def test_mcp_url_routes_default_and_readonly(client: StarSpaceClient) -> None:
    assert client._mcp_url() == "https://example.test/functions/v1/mcp-run-v1"
    assert client._mcp_url(readonly=True) == "https://example.test/functions/v1/mcp-run-v1/readonly"


def test_mcp_headers_carry_protocol_version_and_dual_accept(client: StarSpaceClient) -> None:
    headers = client._mcp_headers()
    assert headers["Authorization"] == "Bearer ak_unit_test"
    assert headers["MCP-Protocol-Version"] == "2025-11-25"
    accept = headers["Accept"]
    # Must accept BOTH so mcp-run-v1's content-negotiation 406 doesn't fire.
    assert "application/json" in accept
    assert "text/event-stream" in accept


def test_parse_mcp_response_handles_application_json(client: StarSpaceClient) -> None:
    resp = _make_response(body=json.dumps({"jsonrpc": "2.0", "id": 1, "result": {"ok": True}}))
    parsed = client._parse_mcp_response(resp)
    assert parsed["result"] == {"ok": True}


def test_parse_mcp_response_decodes_sse_streams(client: StarSpaceClient) -> None:
    sse = (
        "event: message\n"
        "data: {\"jsonrpc\":\"2.0\",\"id\":2,\"result\":{\"content\":[{\"type\":\"text\",\"text\":\"hi\"}]}}\n"
        "\n"
    )
    resp = _make_response(body=sse, content_type="text/event-stream; charset=utf-8")
    parsed = client._parse_mcp_response(resp)
    assert parsed["result"]["content"][0]["text"] == "hi"


def test_parse_mcp_response_picks_last_envelope_when_progress_emitted(client: StarSpaceClient) -> None:
    # mcp-run-v1 may emit a progress notification before the final result;
    # the parser must skip those and surface only the envelope with result/error.
    sse = (
        "data: {\"jsonrpc\":\"2.0\",\"method\":\"notifications/progress\",\"params\":{\"progress\":0.5}}\n"
        "\n"
        "data: {\"jsonrpc\":\"2.0\",\"id\":7,\"result\":{\"content\":[{\"type\":\"text\",\"text\":\"final\"}]}}\n"
        "\n"
    )
    resp = _make_response(body=sse, content_type="text/event-stream")
    parsed = client._parse_mcp_response(resp)
    assert parsed["result"]["content"][0]["text"] == "final"


def test_mcp_rpc_raises_on_jsonrpc_error(client: StarSpaceClient) -> None:
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "error": {"code": -32601, "message": "Method not found"}})
    fake = _make_response(body=body)
    with patch("starspace_cli.client.requests.post", return_value=fake):
        with pytest.raises(StarSpaceError) as ei:
            client.mcp_rpc("nope")
    assert "Method not found" in str(ei.value)


def test_mcp_call_unwraps_result_or_raises_on_iserror(client: StarSpaceClient) -> None:
    ok_body = json.dumps({"jsonrpc": "2.0", "id": 2, "result": {"content": [{"type": "text", "text": "ok"}]}})
    err_body = json.dumps({
        "jsonrpc": "2.0", "id": 2,
        "result": {"isError": True, "content": [{"type": "text", "text": "boom"}]},
    })

    with patch("starspace_cli.client.requests.post", return_value=_make_response(body=ok_body)):
        result = client.mcp_call("anything")
        assert result["content"][0]["text"] == "ok"

    with patch("starspace_cli.client.requests.post", return_value=_make_response(body=err_body)):
        with pytest.raises(StarSpaceError) as ei:
            client.mcp_call("anything")
    assert "boom" in str(ei.value)
    assert ei.value.code == "mcp_tool_error"
