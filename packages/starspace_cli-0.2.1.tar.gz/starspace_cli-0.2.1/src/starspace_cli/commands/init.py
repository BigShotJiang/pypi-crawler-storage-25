"""`starspace init` - set up a workspace config interactively.

Prompts for workspace_id + API key + optional STARSPACE_BASE_URL override,
validates the API key against the /whoami endpoint, then writes the config to
~/.config/starspace/config.json (or ./.starspace/config.json with --project).
"""

from __future__ import annotations

from typing import Optional

import typer

from starspace_cli import output
from starspace_cli.client import DEFAULT_BASE_URL, StarSpaceClient
from starspace_cli.config import (
    global_config_path,
    project_config_path,
    write_global_config,
    write_project_config,
)


def init(
    project: bool = typer.Option(
        False,
        "--project",
        help="Write config to ./.starspace/config.json instead of the global ~/.config/starspace/config.json.",
    ),
    workspace_id: Optional[str] = typer.Option(None, help="Workspace UUID. Skips the prompt if provided."),
    api_key: Optional[str] = typer.Option(None, help="Workspace API key (ak_…). Skips the prompt if provided."),
    base_url: Optional[str] = typer.Option(
        None,
        "--base-url",
        help=f"Override the StarSpace API base URL. Default: {DEFAULT_BASE_URL}",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite an existing config file without prompting."),
):
    """Initialize StarSpace CLI configuration."""

    target_path = project_config_path() if project else global_config_path()
    output.info(f"Writing config to: {target_path}")

    if target_path.exists() and not force:
        # Always require interactive confirmation for overwrite. In --json mode
        # the user should pass --force; without it we still abort safely.
        typer.confirm(
            f"Config already exists at {target_path}. Overwrite?",
            abort=True,
        )

    if not workspace_id:
        workspace_id = typer.prompt("Workspace ID")
    workspace_id = workspace_id.strip()
    if not workspace_id:
        raise output.fail("workspace ID cannot be empty", exit_code=1)

    if not api_key:
        api_key = typer.prompt("API key (ak_…)", hide_input=True)
    api_key = api_key.strip()
    if not api_key.startswith("ak_"):
        output.info("Warning: API key does not start with 'ak_'. Proceeding anyway.")

    if base_url is None:
        prompted = typer.prompt(
            "API base URL (press Enter for default)",
            default=DEFAULT_BASE_URL,
            show_default=True,
        )
        base_url = prompted.strip() if prompted else None

    if base_url == DEFAULT_BASE_URL:
        base_url_to_persist: Optional[str] = None
    else:
        base_url_to_persist = base_url or None

    output.info("Validating API key against /whoami...")
    client = StarSpaceClient(api_key=api_key, base_url=base_url)
    info = client.whoami()  # StarSpaceError bubbles to main()

    returned_workspace = info.get("workspace_id")
    if returned_workspace and returned_workspace != workspace_id:
        raise output.fail(
            f"this API key belongs to workspace {returned_workspace}, "
            f"not {workspace_id}. Use the matching key or update the workspace ID.",
            exit_code=1,
        )

    tier = info.get("tier", "free")
    key_prefix = info.get("key_prefix", "")
    output.info(f"  ✓ key validated - tier: {tier}, prefix: {key_prefix}")

    if project:
        path = write_project_config(workspace_id, api_key, base_url_to_persist)
    else:
        path = write_global_config(workspace_id, api_key, base_url_to_persist)

    output.result(
        {
            "config_path": str(path),
            "workspace_id": workspace_id,
            "tier": tier,
            "key_prefix": key_prefix,
            "scope": "project" if project else "global",
        },
        human=(
            f"Config written to {path}\n\n"
            "Next steps:\n"
            "  starspace push                 # upload your codebase\n"
            "  starspace connect claude       # generate Claude Desktop config snippet\n"
            "  starspace doctor               # diagnostics if anything looks wrong"
        ),
    )
