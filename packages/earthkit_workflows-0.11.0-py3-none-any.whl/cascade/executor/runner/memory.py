# (C) Copyright 2025- ECMWF.
#
# This software is licensed under the terms of the Apache Licence Version 2.0
# which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
# In applying this licence, ECMWF does not waive the privileges and immunities
# granted to it by virtue of its status as an intergovernmental organisation
# nor does it submit to any jurisdiction.

"""Managing datasets in memory -- inputs and outputs of the executed job
Interaction with shm
"""

import logging
import sys
from contextlib import AbstractContextManager
from typing import Any, Iterable, Literal

import cascade.executor.serde as serde
import cascade.shm.client as shm_client
from cascade.executor.comms import callback
from cascade.executor.msg import BackboneAddress, DatasetPublished
from cascade.low.core import NO_OUTPUT_PLACEHOLDER, DatasetId, WorkerId
from cascade.low.exceptions import CascadeInternalError
from cascade.low.func import md5hash24
from cascade.low.tracing import Microtrace, timer

logger = logging.getLogger(__name__)


def ds2shmid(ds: DatasetId) -> str:
    # we cant use too long file names for shm, https://trac.macports.org/ticket/64806
    return md5hash24(ds.task + ds.output)


class Memory(AbstractContextManager):
    def __init__(self, callback: BackboneAddress, worker: WorkerId) -> None:
        self.local: dict[DatasetId, Any] = {}
        self.bufs: dict[DatasetId, shm_client.AllocatedBuffer] = {}
        self.callback = callback
        self.worker = worker

    def _build_publish_message(self, outputId: DatasetId, isTaskCompletion: bool) -> DatasetPublished:
        # TODO we should fine-grain host-wide
        # and worker-only publishes at the `controller.notify` level, to not cause
        # incorrect shm.purge calls at worklow end, which log an annoying key error
        # In the case of local publishes due to runner restart during a task sequence,
        # we even need to hotfix transmit_idx=-1 to not *crash* the controller with a double completion!
        return DatasetPublished(ds=outputId, origin=self.worker, transmit_idx=None if isTaskCompletion else -1)

    def _publish(self, outputId: DatasetId, outputSchema: str, outputValue: Any, isTaskCompletion: bool):
        logger.debug(f"publishing {outputId}")
        shmid = ds2shmid(outputId)
        result_ser, deser_fun = timer(serde.ser_output, Microtrace.wrk_ser)(outputValue, outputSchema)
        l = len(result_ser)
        rbuf = shm_client.allocate(shmid, l, deser_fun)
        rbuf.view()[:l] = result_ser
        rbuf.close()
        callback(self.callback, self._build_publish_message(outputId, isTaskCompletion))

    def additional_publish_local(self, outputIds: Iterable[tuple[DatasetId, str]]):
        # if eg due to a runner crash we need to interrupt a task sequence, it may
        # trigger a publish of datasets which originally were not published
        for outputId, outputSchema in outputIds:
            outputValue = self.local[outputId]  # KeyError here is *not* expected
            self._publish(outputId, outputSchema, outputValue, False)

    def handle(self, outputId: DatasetId, outputSchema: str, outputValue: Any, isPublish: bool) -> None:
        if outputId == NO_OUTPUT_PLACEHOLDER:
            if outputValue is not None:
                logger.warning(f"gotten output of type {type(outputValue)} where none was expected, updating annotation")
                outputSchema = "Any"
            else:
                outputValue = "ok"

        self.local[outputId] = outputValue

        if isPublish:
            self._publish(outputId, outputSchema, outputValue, True)
        else:
            # NOTE even if its not actually published, we send the message to allow for
            # marking the task itself as completed -- its odd, but arguably better than
            # introducing a TaskCompleted message.
            logger.debug(f"fake publish of {outputId} for the sake of task completion")
            shmid = ds2shmid(outputId)
            callback(self.callback, self._build_publish_message(outputId, True))

    def provide(self, inputId: DatasetId, annotation: str) -> Any:
        if inputId not in self.local:
            if inputId in self.bufs:
                raise CascadeInternalError(f"internal data corruption for {inputId}")
            shmid = ds2shmid(inputId)
            logger.debug(f"asking for {inputId} via {shmid}")
            buf = shm_client.get(shmid)
            self.bufs[inputId] = buf
            self.local[inputId] = timer(serde.des_output, Microtrace.wrk_deser)(buf.view(), annotation, buf.deser_fun)

        return self.local[inputId]

    def pop(self, ds: DatasetId) -> None:
        if ds in self.local:
            logger.debug(f"popping local {ds}")
            val = self.local.pop(ds)  # noqa: F841
            del val
        if ds in self.bufs:
            logger.debug(f"popping buf {ds}")
            buf = self.bufs.pop(ds)
            buf.close()

    def flush(self, datasets: set[DatasetId] = set()) -> None:
        # NOTE poor man's memory management -- just drop those locals that didn't come from cashme. Called
        # after every taskSequence. In principle, we could purge some locals earlier, and ideally scheduler
        # would invoke some targeted purges to also remove some published ones earlier (eg, they are still
        # needed somewhere but not here)
        purgeable = [inputId for inputId in self.local if inputId not in self.bufs and (not datasets or inputId in datasets)]
        logger.debug(f"will flush {len(purgeable)} datasets")
        for inputId in purgeable:
            self.local.pop(inputId)

        # NOTE poor man's gpu mem management -- currently torch only. Given the task sequence limitation,
        # this may not be the best place to invoke.
        if "torch" in sys.modules:  # if no task on this worker imported torch, no need to flush
            try:
                import torch  # ty: ignore[unresolved-import] # *exceptional in-body import*

                logger.debug(f"imported torch version {torch.__version__} to clean cuda memory")

                if torch.cuda.is_available():
                    free, total = torch.cuda.mem_get_info()
                    logger.debug(f"cuda mem avail: {free / total:.2%}")
                    if free / total < 0.8:
                        torch.cuda.empty_cache()
                        free, total = torch.cuda.mem_get_info()
                        logger.debug(f"cuda mem avail post cache empty: {free / total:.2%}")
                        if free / total < 0.8:
                            # NOTE this ofc makes low sense if there is any other application (like browser or ollama)
                            # that the user may be running
                            logger.warning("cuda mem avail low despite cache empty!")
                            logger.debug(torch.cuda.memory_summary())
                elif torch.mps.is_available():
                    allocated = torch.mps.driver_allocated_memory()
                    recommended_max = torch.mps.recommended_max_memory()
                    logger.debug(f"mps driver {allocated=}, recommended max {recommended_max}")
                    if allocated / recommended_max < 0.8:
                        torch.mps.empty_cache()
                        allocated = torch.mps.driver_allocated_memory()
                        logger.debug(f"mps driver {allocated=} post clean")
                else:
                    logger.debug("no torch backend with free_cache capacity understood => noop")
            except Exception:
                logger.exception("failed to free torch backend mem cache")

    def __exit__(self, exc_type, exc_val, exc_tb) -> Literal[False]:
        # this is required so that the Shm can be properly freed, otherwise you get 'pointers cannot be closed'
        del self.local
        for buf in self.bufs.values():
            buf.close()
        return False
