"""Auto-generated. Do not edit. Run scripts/build.sh."""
import json

TOOLS_VERSION = "0.3.0"

OPENAI_TOOLS = json.loads(r"""
[
  {
    "type": "function",
    "function": {
      "name": "search_papers",
      "description": "按结构化条件检索学术文献元数据（标题、作者、期刊、年份、摘要等）。\n适用：「查找 Hinton 在 2020-2023 年发表的论文」「找 Nature 上关于 CRISPR 的近期文献」。\n不适用：自然语言问答检索 → 用 semantic_search；查全文片段 → 用 read_content。\n返回：论文元数据列表，每条含 doc_id、title、author、abstract、publication_venue_name、publication_published_year 等。",
      "parameters": {
        "type": "object",
        "properties": {
          "query": {
            "type": "string",
            "description": "BM25 全文关键词，匹配标题/摘要/期刊名/关键词字段。留空则纯靠结构化过滤。"
          },
          "title_contains": {
            "type": "string",
            "description": "标题中必须包含的词（仅匹配 title 字段）。"
          },
          "abstract_contains": {
            "type": "string",
            "description": "摘要中必须包含的词（仅匹配 abstract 字段）。"
          },
          "authors": {
            "type": "array",
            "items": {
              "type": "string"
            },
            "description": "作者名（任一命中即可）。SDK 内部映射到后端 `author` 字段（FILTER_OP_IN）。"
          },
          "year_from": {
            "type": "integer",
            "description": "起始发表年（含）。"
          },
          "year_to": {
            "type": "integer",
            "description": "结束发表年（含）。"
          },
          "journals": {
            "type": "array",
            "items": {
              "type": "string"
            },
            "description": "期刊名（任一命中即可）。SDK 内部映射到后端 `publication_venue_name` 字段（FILTER_OP_IN）。"
          },
          "subjects": {
            "type": "array",
            "items": {
              "type": "string"
            },
            "description": "学科分类，如 \"computer science\"、\"biology\"。"
          },
          "filters_advanced": {
            "type": "array",
            "description": "高级过滤逃生舱（仅当上述字段不够用时使用）。",
            "items": {
              "type": "object",
              "required": [
                "field",
                "value"
              ],
              "properties": {
                "field": {
                  "type": "string"
                },
                "operator": {
                  "type": "string",
                  "enum": [
                    "FILTER_OP_EQ",
                    "FILTER_OP_NE",
                    "FILTER_OP_GT",
                    "FILTER_OP_GTE",
                    "FILTER_OP_LT",
                    "FILTER_OP_LTE",
                    "FILTER_OP_IN",
                    "FILTER_OP_NIN",
                    "FILTER_OP_CONTAINS"
                  ],
                  "default": "FILTER_OP_EQ"
                },
                "value": {}
              }
            }
          },
          "sort_by_year": {
            "type": "string",
            "enum": [
              "desc",
              "asc",
              "none"
            ],
            "default": "desc"
          },
          "page": {
            "type": "integer",
            "default": 1,
            "minimum": 1
          },
          "page_size": {
            "type": "integer",
            "default": 10,
            "minimum": 1,
            "maximum": 50
          }
        }
      }
    }
  },
  {
    "type": "function",
    "function": {
      "name": "semantic_search",
      "description": "自然语言语义检索，返回相关文献片段（chunk）用于 RAG 回答。\n适用：「Transformer 注意力机制如何工作？」「最新的蛋白质折叠预测方法有哪些？」\n不适用：精确字段过滤 → search_papers；取完整原文 → read_content。\n返回：相关 chunk 列表，每条含 chunk_id/doc_id/abstract/chunk/score/title/offset。\n典型链路：semantic_search → 选取 chunk → read_content(doc_id, offset)。",
      "parameters": {
        "type": "object",
        "required": [
          "query"
        ],
        "properties": {
          "query": {
            "type": "string",
            "minLength": 1,
            "maxLength": 4096,
            "description": "自然语言查询，1-200 字最佳。"
          },
          "top_k": {
            "type": "integer",
            "default": 10,
            "minimum": 1,
            "maximum": 30
          },
          "source_types": {
            "type": "array",
            "items": {
              "type": "string",
              "enum": [
                "web",
                "pdf"
              ]
            }
          },
          "mode": {
            "type": "string",
            "enum": [
              "fast",
              "balanced",
              "quality"
            ],
            "default": "balanced",
            "description": "fast = 仅关键词召回 (~200ms)；balanced = 混合检索 (~600ms)；quality = LLM 改写 + 混合 (~2-4s)。\n"
          }
        }
      }
    }
  },
  {
    "type": "function",
    "function": {
      "name": "list_catalog",
      "description": "返回 search_papers 所有可用字段的 catalog：字段名、类型、能否过滤/排序、\n是否默认返回、字段说明、FilterOperator 清单等。\n适用：「我该用哪个字段过滤 DOI?」「access_oa_status 有哪些可能值？」\n「`metadata_type` 的合法取值是？」\n不适用：实际查询文献，那是 search_papers / semantic_search 的事。\n典型用法：Agent 第一次接触 SciVerse 或碰到模糊字段需求时先调一次本接口，\n把 schema 装进 working memory，后续精确构造 search_papers 的 filters。\ninclude_sample_values=true 时返回枚举值样本（OpenSearch terms agg，缓存 24h）。",
      "parameters": {
        "type": "object",
        "properties": {
          "include_sample_values": {
            "type": "boolean",
            "default": false,
            "description": "是否拉取 enum-like 字段的取值样本。false 仅返回静态 schema（毫秒级）；true 触发 OpenSearch terms agg（首次几百毫秒，之后 24h 走缓存）。"
          }
        },
        "required": []
      }
    }
  },
  {
    "type": "function",
    "function": {
      "name": "read_content",
      "description": "按字节区间读取文献原文片段。通常配合 semantic_search 返回的 doc_id/offset 使用，\n用于扩展上下文（往前/往后读更多字节）。\n返回：UTF-8 文本片段、bytes_returned、next_offset、是否还有后续。",
      "parameters": {
        "type": "object",
        "properties": {
          "doc_id": {
            "type": "string",
            "description": "文献 ID（来自 search_papers / semantic_search）。"
          },
          "offset": {
            "type": "integer",
            "format": "int64",
            "default": 0
          },
          "limit": {
            "type": "integer",
            "format": "int64",
            "default": 4096,
            "maximum": 16384
          }
        },
        "required": [
          "doc_id"
        ]
      }
    }
  },
  {
    "type": "function",
    "function": {
      "name": "get_resource",
      "description": "按文件名取文献中嵌入的图片字节流（PNG / JPG 等）。\n触发场景：read_content 返回的 Markdown 中含 `![alt](file_name)` 形式的图片占位，\nagent 需要把图给用户看时调本接口。\n入参 file_name 来自 markdown 内的 url 段（相对路径，禁止 `\\\\` 或 `..`）。\n返回：HTTP 二进制流 + image/* Content-Type。\nSDK / MCP server 包装层会做 base64 + mime 转换以便 agent 多模态使用。",
      "parameters": {
        "type": "object",
        "properties": {
          "file_name": {
            "type": "string",
            "description": "图片相对路径，来自 read_content Markdown 中的 `![alt](file_name)` 占位。禁止 `\\\\` 与 `..`，不能以 `/` 开头。"
          }
        },
        "required": [
          "file_name"
        ]
      }
    }
  }
]
""")

ANTHROPIC_TOOLS = json.loads(r"""
[
  {
    "name": "search_papers",
    "description": "按结构化条件检索学术文献元数据（标题、作者、期刊、年份、摘要等）。\n适用：「查找 Hinton 在 2020-2023 年发表的论文」「找 Nature 上关于 CRISPR 的近期文献」。\n不适用：自然语言问答检索 → 用 semantic_search；查全文片段 → 用 read_content。\n返回：论文元数据列表，每条含 doc_id、title、author、abstract、publication_venue_name、publication_published_year 等。",
    "input_schema": {
      "type": "object",
      "properties": {
        "query": {
          "type": "string",
          "description": "BM25 全文关键词，匹配标题/摘要/期刊名/关键词字段。留空则纯靠结构化过滤。"
        },
        "title_contains": {
          "type": "string",
          "description": "标题中必须包含的词（仅匹配 title 字段）。"
        },
        "abstract_contains": {
          "type": "string",
          "description": "摘要中必须包含的词（仅匹配 abstract 字段）。"
        },
        "authors": {
          "type": "array",
          "items": {
            "type": "string"
          },
          "description": "作者名（任一命中即可）。SDK 内部映射到后端 `author` 字段（FILTER_OP_IN）。"
        },
        "year_from": {
          "type": "integer",
          "description": "起始发表年（含）。"
        },
        "year_to": {
          "type": "integer",
          "description": "结束发表年（含）。"
        },
        "journals": {
          "type": "array",
          "items": {
            "type": "string"
          },
          "description": "期刊名（任一命中即可）。SDK 内部映射到后端 `publication_venue_name` 字段（FILTER_OP_IN）。"
        },
        "subjects": {
          "type": "array",
          "items": {
            "type": "string"
          },
          "description": "学科分类，如 \"computer science\"、\"biology\"。"
        },
        "filters_advanced": {
          "type": "array",
          "description": "高级过滤逃生舱（仅当上述字段不够用时使用）。",
          "items": {
            "type": "object",
            "required": [
              "field",
              "value"
            ],
            "properties": {
              "field": {
                "type": "string"
              },
              "operator": {
                "type": "string",
                "enum": [
                  "FILTER_OP_EQ",
                  "FILTER_OP_NE",
                  "FILTER_OP_GT",
                  "FILTER_OP_GTE",
                  "FILTER_OP_LT",
                  "FILTER_OP_LTE",
                  "FILTER_OP_IN",
                  "FILTER_OP_NIN",
                  "FILTER_OP_CONTAINS"
                ],
                "default": "FILTER_OP_EQ"
              },
              "value": {}
            }
          }
        },
        "sort_by_year": {
          "type": "string",
          "enum": [
            "desc",
            "asc",
            "none"
          ],
          "default": "desc"
        },
        "page": {
          "type": "integer",
          "default": 1,
          "minimum": 1
        },
        "page_size": {
          "type": "integer",
          "default": 10,
          "minimum": 1,
          "maximum": 50
        }
      }
    }
  },
  {
    "name": "semantic_search",
    "description": "自然语言语义检索，返回相关文献片段（chunk）用于 RAG 回答。\n适用：「Transformer 注意力机制如何工作？」「最新的蛋白质折叠预测方法有哪些？」\n不适用：精确字段过滤 → search_papers；取完整原文 → read_content。\n返回：相关 chunk 列表，每条含 chunk_id/doc_id/abstract/chunk/score/title/offset。\n典型链路：semantic_search → 选取 chunk → read_content(doc_id, offset)。",
    "input_schema": {
      "type": "object",
      "required": [
        "query"
      ],
      "properties": {
        "query": {
          "type": "string",
          "minLength": 1,
          "maxLength": 4096,
          "description": "自然语言查询，1-200 字最佳。"
        },
        "top_k": {
          "type": "integer",
          "default": 10,
          "minimum": 1,
          "maximum": 30
        },
        "source_types": {
          "type": "array",
          "items": {
            "type": "string",
            "enum": [
              "web",
              "pdf"
            ]
          }
        },
        "mode": {
          "type": "string",
          "enum": [
            "fast",
            "balanced",
            "quality"
          ],
          "default": "balanced",
          "description": "fast = 仅关键词召回 (~200ms)；balanced = 混合检索 (~600ms)；quality = LLM 改写 + 混合 (~2-4s)。\n"
        }
      }
    }
  },
  {
    "name": "list_catalog",
    "description": "返回 search_papers 所有可用字段的 catalog：字段名、类型、能否过滤/排序、\n是否默认返回、字段说明、FilterOperator 清单等。\n适用：「我该用哪个字段过滤 DOI?」「access_oa_status 有哪些可能值？」\n「`metadata_type` 的合法取值是？」\n不适用：实际查询文献，那是 search_papers / semantic_search 的事。\n典型用法：Agent 第一次接触 SciVerse 或碰到模糊字段需求时先调一次本接口，\n把 schema 装进 working memory，后续精确构造 search_papers 的 filters。\ninclude_sample_values=true 时返回枚举值样本（OpenSearch terms agg，缓存 24h）。",
    "input_schema": {
      "type": "object",
      "properties": {
        "include_sample_values": {
          "type": "boolean",
          "default": false,
          "description": "是否拉取 enum-like 字段的取值样本。false 仅返回静态 schema（毫秒级）；true 触发 OpenSearch terms agg（首次几百毫秒，之后 24h 走缓存）。"
        }
      },
      "required": []
    }
  },
  {
    "name": "read_content",
    "description": "按字节区间读取文献原文片段。通常配合 semantic_search 返回的 doc_id/offset 使用，\n用于扩展上下文（往前/往后读更多字节）。\n返回：UTF-8 文本片段、bytes_returned、next_offset、是否还有后续。",
    "input_schema": {
      "type": "object",
      "properties": {
        "doc_id": {
          "type": "string",
          "description": "文献 ID（来自 search_papers / semantic_search）。"
        },
        "offset": {
          "type": "integer",
          "format": "int64",
          "default": 0
        },
        "limit": {
          "type": "integer",
          "format": "int64",
          "default": 4096,
          "maximum": 16384
        }
      },
      "required": [
        "doc_id"
      ]
    }
  },
  {
    "name": "get_resource",
    "description": "按文件名取文献中嵌入的图片字节流（PNG / JPG 等）。\n触发场景：read_content 返回的 Markdown 中含 `![alt](file_name)` 形式的图片占位，\nagent 需要把图给用户看时调本接口。\n入参 file_name 来自 markdown 内的 url 段（相对路径，禁止 `\\\\` 或 `..`）。\n返回：HTTP 二进制流 + image/* Content-Type。\nSDK / MCP server 包装层会做 base64 + mime 转换以便 agent 多模态使用。",
    "input_schema": {
      "type": "object",
      "properties": {
        "file_name": {
          "type": "string",
          "description": "图片相对路径，来自 read_content Markdown 中的 `![alt](file_name)` 占位。禁止 `\\\\` 与 `..`，不能以 `/` 开头。"
        }
      },
      "required": [
        "file_name"
      ]
    }
  }
]
""")
