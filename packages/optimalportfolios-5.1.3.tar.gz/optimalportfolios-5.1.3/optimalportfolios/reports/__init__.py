
from optimalportfolios.reports.portfolio_result_plots import plot_efficient_frontier
