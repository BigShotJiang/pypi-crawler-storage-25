# Copyright (C) 2022 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Library to import Mechanical enums.

A useful subset of what is imported by
Ansys Inc/v{NNN}/ACT/apis/Mechanical.py
"""

from ansys.mechanical.core.embedding.app import is_initialized

if not is_initialized():
    raise RuntimeError("Enums cannot be imported until the embedded app is initialized.")

import clr

clr.AddReference("Ansys.Mechanical.DataModel")
clr.AddReference("Ansys.ACT.Interfaces")

from Ansys.ACT.Interfaces.Common import *  # noqa isort: skip
from Ansys.Mechanical.DataModel.Enums import *  # noqa isort: skip
from Ansys.ACT.Interfaces.Analysis import *  # noqa isort: skip
from Ansys.ACT.Interfaces.Geometry import *  # noqa isort: skip
from Ansys.ACT.Mechanical.Fields import *  # noqa isort: skip
from Ansys.ACT.Interfaces.Mesh import *  # noqa isort: skip
import Ansys  # noqa  isort: skip
