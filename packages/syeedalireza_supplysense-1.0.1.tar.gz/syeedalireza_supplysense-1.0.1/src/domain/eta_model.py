# In a real production system, this would load a pre-trained model (e.g., XGBoost or Random Forest)
# from a model registry like MLflow or a local .pkl file.
# For demonstration, we use a heuristic that mimics a trained linear regression model.

def predict_delivery_days(distance: float, weather: int, load: float) -> int:
    """
    Mimics an ML inference function.
    Base speed: 500km per day.
    Weather penalty: +0.5 days for rain, +1.5 days for snow.
    Load penalty: +1 day if warehouse load > 80%.
    """
    base_days = distance / 500.0
    
    weather_penalty = 0
    if weather == 1:
        weather_penalty = 0.5
    elif weather == 2:
        weather_penalty = 1.5
        
    load_penalty = 0
    if load > 0.8:
        load_penalty = 1.0
        
    total_days = base_days + weather_penalty + load_penalty
    
    # Minimum delivery time is 1 day
    return max(1, int(round(total_days)))