from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from src.domain.eta_model import predict_delivery_days

app = FastAPI(
    title="SupplySense API",
    description="Supply Chain ETA & Demand Forecasting",
    version="1.0.0"
)

class ETARequest(BaseModel):
    distance_km: float
    weather_condition: int # 0: Clear, 1: Rain, 2: Snow
    warehouse_load: float # 0.0 to 1.0 (1.0 = fully loaded)

@app.get("/health", tags=["System"])
async def health_check():
    return {"status": "healthy"}

@app.post("/api/v1/predict/eta", tags=["Forecasting"])
async def get_eta(request: ETARequest):
    """
    Predicts the Estimated Time of Arrival (ETA) in days based on distance, weather, and warehouse load.
    """
    try:
        predicted_days = predict_delivery_days(
            distance=request.distance_km,
            weather=request.weather_condition,
            load=request.warehouse_load
        )
        
        return {
            "estimated_delivery_days": predicted_days,
            "confidence": "high" # In a real ML model, return probability/confidence score
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))