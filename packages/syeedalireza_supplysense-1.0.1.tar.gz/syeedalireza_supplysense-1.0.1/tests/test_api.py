import pytest
from httpx import AsyncClient, ASGITransport
from src.main import app
import pytest_asyncio

@pytest_asyncio.fixture
async def async_client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client

@pytest.mark.asyncio
async def test_predict_eta_clear_weather(async_client):
    payload = {
        "distance_km": 1000.0, # 2 days base
        "weather_condition": 0, # Clear
        "warehouse_load": 0.5   # Normal load
    }
    response = await async_client.post("/api/v1/predict/eta", json=payload)
    assert response.status_code == 200
    assert response.json()["estimated_delivery_days"] == 2

@pytest.mark.asyncio
async def test_predict_eta_bad_weather_high_load(async_client):
    payload = {
        "distance_km": 1000.0, # 2 days base
        "weather_condition": 2, # Snow (+1.5 days)
        "warehouse_load": 0.9   # High load (+1 day)
    }
    # Total expected: 2 + 1.5 + 1 = 4.5 -> rounded to 5
    response = await async_client.post("/api/v1/predict/eta", json=payload)
    assert response.status_code == 200
    assert response.json()["estimated_delivery_days"] == 4 or response.json()["estimated_delivery_days"] == 5