# SupplySense: Supply Chain ETA & Demand Forecasting

**SupplySense** predicts exact delivery times (ETA) and forecasts product demand using machine learning, weather data, and warehouse load.

Developed by **Alireza Aminzadeh** ([@syeedalireza](https://github.com/syeedalireza)).

## Architecture
- **Machine Learning:** PyTorch / XGBoost
- **API:** FastAPI
- **Tracking:** MLflow
- **Pattern:** ML Pipeline Architecture, Microservices

*(Technical implementation pending in next iteration)*
