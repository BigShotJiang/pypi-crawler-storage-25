"""AgentDebugX public API.

The package is intentionally imported as ``agentdebug`` so existing and future
agent systems can add debugging with a small surface area. The PyPI
distribution is named ``agentdebugx``.

See ``docs/14_api_reference.md`` for the full public surface and
``docs/18_comparison_codex_vs_design.md`` for the merged v0.1 scope.
"""

from agentdebug.analyzers import HeuristicAnalyzer
from agentdebug.attribution import (
    AllAtOnceAttributor,
    AttributionResult,
    Attributor,
    BinarySearchAttributor,
    Blame,
    CounterfactualAttributor,
    HeuristicAttributor,
    SBFLAttributor,
    StepByStepAttributor,
)
from agentdebug.detectors import (
    Detector,
    DetectorConfig,
    RepeatedStateDetector,
    RepeatedToolCallDetector,
    StepCountLimitDetector,
    default_detectors,
    run_detectors,
)
from agentdebug.events import DEFAULT_BUS, BusEvent, EventBus, EventSubscription
from agentdebug.models import (
    AgentEvent,
    AgentTrajectory,
    Artifact,
    DiagnosticReport,
    EventType,
    FailureFinding,
    FailureMode,
    Modality,
)
from agentdebug.recorder import AgentDebug, TraceSession
from agentdebug.recovery import (
    DEFAULT_VERIFIERS,
    AutoManualRules,
    CriticRecoverer,
    FixProposal,
    Recoverer,
    ReflexionSuggestion,
    SelfRefineLoop,
    VerifierSpec,
)
from agentdebug.traceback import CascadeFrame, build_cascade, format_traceback
from agentdebug.storage import JsonlTraceStore, SQLiteTraceStore
from agentdebug.taxonomy import SEED_FAILURE_MODES, get_failure_mode

__all__ = [
    'AgentDebug',
    'AgentEvent',
    'AgentTrajectory',
    'AllAtOnceAttributor',
    'Artifact',
    'AttributionResult',
    'Attributor',
    'Blame',
    'BusEvent',
    'AutoManualRules',
    'BinarySearchAttributor',
    'CascadeFrame',
    'CounterfactualAttributor',
    'CriticRecoverer',
    'DEFAULT_VERIFIERS',
    'Detector',
    'DetectorConfig',
    'RepeatedStateDetector',
    'RepeatedToolCallDetector',
    'SBFLAttributor',
    'SelfRefineLoop',
    'StepByStepAttributor',
    'StepCountLimitDetector',
    'VerifierSpec',
    'build_cascade',
    'default_detectors',
    'format_traceback',
    'run_detectors',
    'DEFAULT_BUS',
    'DiagnosticReport',
    'EventBus',
    'EventSubscription',
    'EventType',
    'FailureFinding',
    'FailureMode',
    'FixProposal',
    'HeuristicAnalyzer',
    'HeuristicAttributor',
    'JsonlTraceStore',
    'Modality',
    'Recoverer',
    'ReflexionSuggestion',
    'SEED_FAILURE_MODES',
    'SQLiteTraceStore',
    'TraceSession',
    'get_failure_mode',
]

__version__ = '0.2.9'
