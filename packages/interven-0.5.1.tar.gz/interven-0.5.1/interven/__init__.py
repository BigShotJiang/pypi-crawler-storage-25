"""
Interven Python SDK — customer-facing alias.

This module re-exports everything from `aif_sdk` so customers can use the
branded import path:

    from interven import Client
    client = Client(api_key="iv_live_...")
    result = client.scan(method="POST", url="...", body={...})
"""
from aif_sdk import (
    AifClient,
    AifError,
    AifMcpMiddleware,
    ApprovalDeniedError,
    ApprovalExpiredError,
    ApprovalStatus,
    ApprovalTimeoutError,
    AuthenticationError,
    Client,
    GatewayError,
    InvokeParams,
    InvokeResponse,
    PayloadTooLargeError,
    PolicyDeniedError,
    ReplayRejectedError,
    ScanResponse,
    ToolResult,
    ToolsClient,
    __version__,
)

__all__ = [
    "Client",
    "ScanResponse",
    "ToolResult",
    "ToolsClient",
    "AifClient",
    "AifMcpMiddleware",
    "InvokeParams",
    "InvokeResponse",
    "ApprovalStatus",
    "AifError",
    "ApprovalDeniedError",
    "ApprovalExpiredError",
    "ApprovalTimeoutError",
    "AuthenticationError",
    "GatewayError",
    "PayloadTooLargeError",
    "PolicyDeniedError",
    "ReplayRejectedError",
    "__version__",
]
