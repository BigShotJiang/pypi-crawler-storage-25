"""Tests for AifMcpMiddleware — mock HTTP, verify MCP protocol handling."""

import json
from unittest.mock import MagicMock, patch

from aif_sdk.mcp import AifMcpMiddleware


def _mock_response(data: dict, status_code: int = 200):
    m = MagicMock()
    m.status_code = status_code
    m.json.return_value = data
    return m


def _make_middleware(**kwargs):
    defaults = dict(
        gateway_url="http://gw:4000",
        agent_id="agent-1",
        agent_secret="secret-123",
    )
    defaults.update(kwargs)
    return AifMcpMiddleware(**defaults)


@patch("aif_sdk.mcp.requests.post")
def test_intercept_sends_correct_headers(mock_post):
    deny_resp = {
        "jsonrpc": "2.0", "id": 1,
        "result": {
            "content": [{"type": "text", "text": "[AIF] Blocked"}],
            "isError": True,
        },
    }
    mock_post.return_value = _mock_response(deny_resp)

    mw = _make_middleware()
    mcp_req = {
        "jsonrpc": "2.0", "id": 1, "method": "tools/call",
        "params": {"name": "github_add_collaborator", "arguments": {"owner": "org"}},
    }

    result = mw.intercept(mcp_req)

    call_args = mock_post.call_args
    assert call_args[0][0] == "http://gw:4000/mcp"

    headers = call_args[1]["headers"]
    assert headers["X-AIF-Agent-ID"] == "agent-1"
    assert "X-AIF-Signature" in headers
    assert "X-AIF-Timestamp" in headers
    assert headers["Content-Type"] == "application/json"

    assert result == deny_resp


@patch("aif_sdk.mcp.requests.post")
def test_intercept_includes_credential_headers(mock_post):
    mock_post.return_value = _mock_response({"jsonrpc": "2.0", "id": 1, "result": {"content": [], "isError": False}})

    mw = _make_middleware(credential_type="pat", credential_token="ghp_test", scopes=["repo", "read:org"])
    mw.intercept({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "github_list_pull_requests", "arguments": {}}})

    headers = mock_post.call_args[1]["headers"]
    assert headers["X-AIF-Credential-Type"] == "pat"
    assert headers["X-AIF-Credential-Token"] == "ghp_test"
    assert headers["X-AIF-Scopes"] == "repo,read:org"


@patch("aif_sdk.mcp.requests.post")
def test_is_allowed_true_for_success(mock_post):
    mock_post.return_value = _mock_response({
        "jsonrpc": "2.0", "id": 1,
        "result": {"content": [{"type": "text", "text": "OK"}], "isError": False},
    })
    mw = _make_middleware()
    resp = mw.intercept({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "github_list_pull_requests", "arguments": {}}})
    assert mw.is_allowed(resp)


@patch("aif_sdk.mcp.requests.post")
def test_is_allowed_false_for_deny(mock_post):
    mock_post.return_value = _mock_response({
        "jsonrpc": "2.0", "id": 1,
        "result": {"content": [{"type": "text", "text": "Blocked"}], "isError": True},
    })
    mw = _make_middleware()
    resp = mw.intercept({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "github_add_collaborator", "arguments": {}}})
    assert not mw.is_allowed(resp)


@patch("aif_sdk.mcp.requests.post")
def test_get_approval_id_extracts_id(mock_post):
    mock_post.return_value = _mock_response({
        "jsonrpc": "2.0", "id": 1,
        "result": {
            "content": [{"type": "text", "text": "[AIF] Needs approval.\nApproval ID: abc-123\nPoll: ..."}],
            "isError": True,
        },
    })
    mw = _make_middleware()
    resp = mw.intercept({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "github_create_pull_request", "arguments": {}}})
    assert mw.get_approval_id(resp) == "abc-123"


@patch("aif_sdk.mcp.requests.post")
def test_get_approval_id_returns_none_for_deny(mock_post):
    mock_post.return_value = _mock_response({
        "jsonrpc": "2.0", "id": 1,
        "result": {"content": [{"type": "text", "text": "Blocked"}], "isError": True},
    })
    mw = _make_middleware()
    resp = mw.intercept({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "github_add_collaborator", "arguments": {}}})
    assert mw.get_approval_id(resp) is None


@patch("aif_sdk.mcp.requests.post")
def test_list_tools(mock_post):
    mock_post.return_value = _mock_response({
        "jsonrpc": "2.0", "id": 0,
        "result": {"tools": [
            {"name": "github_create_pull_request", "description": "Create a PR"},
            {"name": "slack_post_message", "description": "Post a message"},
        ]},
    })
    mw = _make_middleware()
    tools = mw.list_tools()
    assert len(tools) == 2
    assert tools[0]["name"] == "github_create_pull_request"


def test_hmac_is_computed_over_body():
    """Verify the HMAC is computed over the exact JSON body."""
    from aif_sdk.auth import hmac_sign

    mw = _make_middleware()
    mcp_req = {"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "slack_post_message", "arguments": {}}}
    body_str = json.dumps(mcp_req, separators=(",", ":"))
    expected_sig = hmac_sign(body_str, "secret-123")

    # The middleware should produce this exact signature
    assert isinstance(expected_sig, str)
    assert len(expected_sig) > 0
