"""Tests for typed exceptions in approval flow and error handling."""

import time
from unittest.mock import MagicMock, patch

import pytest

from aif_sdk import (
    AifClient,
    ApprovalDeniedError,
    ApprovalExpiredError,
    ApprovalTimeoutError,
    AuthenticationError,
    InvokeParams,
    PayloadTooLargeError,
    PolicyDeniedError,
    ReplayRejectedError,
)


def _mock_response(data: dict, status_code: int = 200):
    m = MagicMock()
    m.status_code = status_code
    m.json.return_value = data
    m.text = str(data)
    return m


def _make_client(**kwargs):
    defaults = dict(
        gateway_url="http://gw:4000",
        agent_id="a1",
        agent_name="bot",
        agent_secret="sec",
    )
    defaults.update(kwargs)
    return AifClient(**defaults)


DUMMY_PARAMS = InvokeParams(
    tool_name="github", method="PUT", url_path="/test",
    credential_type="pat", credential_token="ghp_x", scopes=["repo"],
)


@patch("aif_sdk.client.requests.post")
def test_invoke_raises_authentication_error(mock_post):
    mock_post.return_value = _mock_response({"error": "HMAC failed"}, 401)
    client = _make_client()
    with pytest.raises(AuthenticationError):
        client.invoke(DUMMY_PARAMS)


@patch("aif_sdk.client.requests.post")
def test_invoke_raises_payload_too_large(mock_post):
    mock_post.return_value = _mock_response({"error": "too large"}, 413)
    client = _make_client()
    with pytest.raises(PayloadTooLargeError):
        client.invoke(DUMMY_PARAMS)


@patch("aif_sdk.client.requests.post")
def test_invoke_raises_replay_rejected(mock_post):
    mock_post.return_value = _mock_response({"error": "Replay protection: timestamp too old"}, 400)
    client = _make_client()
    with pytest.raises(ReplayRejectedError):
        client.invoke(DUMMY_PARAMS)


@patch("aif_sdk.client.requests.post")
def test_invoke_raises_policy_denied_when_configured(mock_post):
    mock_post.return_value = _mock_response({
        "decision": "DENY",
        "error": "Denied by policy",
        "reason_codes": ["EXTERNAL_PRINCIPAL"],
        "matched_policies": [{"policy_id": "p1", "rule_ids": ["r1"]}],
        "risk": {"score": 0.9, "band": "CRITICAL"},
    })
    client = _make_client(raise_on_deny=True)
    with pytest.raises(PolicyDeniedError) as exc_info:
        client.invoke(DUMMY_PARAMS)
    assert exc_info.value.reason_codes == ["EXTERNAL_PRINCIPAL"]
    assert exc_info.value.matched_policies == ["p1"]


@patch("aif_sdk.client.requests.post")
def test_invoke_returns_deny_without_raise_by_default(mock_post):
    mock_post.return_value = _mock_response({
        "decision": "DENY",
        "reason_codes": ["EXTERNAL_PRINCIPAL"],
        "matched_policies": [],
        "risk": {"score": 0.8, "band": "HIGH"},
    })
    client = _make_client()
    result = client.invoke(DUMMY_PARAMS)
    assert result.decision == "DENY"


@patch("aif_sdk.client.requests.get")
def test_wait_for_approval_raises_expired(mock_get):
    mock_get.return_value = _mock_response({
        "approval_id": "app-1", "status": "expired",
    })
    client = _make_client()
    with pytest.raises(ApprovalExpiredError) as exc_info:
        client.wait_for_approval("app-1", max_wait=5.0)
    assert exc_info.value.approval_id == "app-1"
    assert exc_info.value.code == "APPROVAL_EXPIRED"


@patch("aif_sdk.client.requests.get")
def test_wait_for_approval_raises_denied(mock_get):
    mock_get.return_value = _mock_response({
        "approval_id": "app-2", "status": "denied",
    })
    client = _make_client()
    with pytest.raises(ApprovalDeniedError) as exc_info:
        client.wait_for_approval("app-2", max_wait=5.0)
    assert exc_info.value.approval_id == "app-2"
    assert exc_info.value.code == "APPROVAL_DENIED"


@patch("aif_sdk.client.requests.get")
def test_wait_for_approval_returns_approved(mock_get):
    mock_get.return_value = _mock_response({
        "approval_id": "app-3", "status": "approved",
    })
    client = _make_client()
    status = client.wait_for_approval("app-3", max_wait=5.0)
    assert status.is_approved


@patch("aif_sdk.client.requests.get")
def test_wait_for_approval_no_raise_on_expired(mock_get):
    mock_get.return_value = _mock_response({
        "approval_id": "app-4", "status": "expired",
    })
    client = _make_client()
    status = client.wait_for_approval("app-4", max_wait=5.0, raise_on_terminal=False)
    assert status.status == "expired"


@patch("aif_sdk.client.requests.get")
@patch("aif_sdk.client.time.sleep")
def test_wait_for_approval_raises_timeout(mock_sleep, mock_get):
    mock_get.return_value = _mock_response({
        "approval_id": "app-5", "status": "pending",
        "remaining_seconds": 3500,
    })
    # Simulate time passing by advancing monotonic clock
    start = time.monotonic()
    call_count = [0]
    original_monotonic = time.monotonic

    def fake_monotonic():
        call_count[0] += 1
        if call_count[0] > 3:
            return start + 100  # exceed max_wait
        return start + call_count[0]

    with patch("aif_sdk.client.time.monotonic", side_effect=fake_monotonic):
        client = _make_client()
        with pytest.raises(ApprovalTimeoutError) as exc_info:
            client.wait_for_approval("app-5", max_wait=5.0, poll_interval=2.5)
        assert exc_info.value.approval_id == "app-5"


def test_exception_hierarchy():
    assert issubclass(ApprovalExpiredError, Exception)
    assert issubclass(ApprovalDeniedError, Exception)
    assert issubclass(ApprovalTimeoutError, Exception)
    assert issubclass(AuthenticationError, Exception)
    assert issubclass(PolicyDeniedError, Exception)
    assert issubclass(ReplayRejectedError, Exception)
    assert issubclass(PayloadTooLargeError, Exception)

    from aif_sdk import AifError
    assert issubclass(ApprovalExpiredError, AifError)
    assert issubclass(PolicyDeniedError, AifError)
