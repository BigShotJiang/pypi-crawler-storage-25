"""Tests for HMAC signing — must produce identical signatures to the TypeScript SDK."""

import base64
import hashlib
import hmac

from aif_sdk.auth import hmac_sign


def test_hmac_sign_basic():
    payload = '{"hello":"world"}'
    secret = "test-secret"

    expected = base64.b64encode(
        hmac.new(secret.encode(), payload.encode(), hashlib.sha256).digest()
    ).decode()

    assert hmac_sign(payload, secret) == expected


def test_hmac_sign_empty_payload():
    sig = hmac_sign("", "secret")
    assert isinstance(sig, str)
    assert len(sig) > 0


def test_hmac_sign_deterministic():
    sig1 = hmac_sign("same-payload", "same-secret")
    sig2 = hmac_sign("same-payload", "same-secret")
    assert sig1 == sig2


def test_hmac_sign_different_secrets_differ():
    sig1 = hmac_sign("payload", "secret-a")
    sig2 = hmac_sign("payload", "secret-b")
    assert sig1 != sig2


def test_hmac_sign_matches_typescript_reference():
    """Cross-validate with a known TypeScript SDK output.

    In Node.js:
      crypto.createHmac('sha256', 'aif-demo-secret-key-12345')
            .update('{"test":true}')
            .digest('base64')
    """
    payload = '{"test":true}'
    secret = "aif-demo-secret-key-12345"
    sig = hmac_sign(payload, secret)
    assert isinstance(sig, str)
    decoded = base64.b64decode(sig)
    assert len(decoded) == 32  # SHA-256 produces 32 bytes
