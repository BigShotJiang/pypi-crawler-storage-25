"""Tests for type deserialization and helpers."""

from aif_sdk.types import ApprovalStatus, InvokeResponse


def test_invoke_response_from_dict_deny():
    data = {
        "decision": "DENY",
        "risk": {"score": 0.85, "band": "HIGH", "signals": [{"name": "secret_detected"}]},
        "matched_policies": [
            {"policy_id": "p1", "rule_ids": ["r1", "r2"], "policy_version": 3}
        ],
        "reason_codes": ["EXTERNAL_PRINCIPAL", "SECRET_DETECTED"],
    }
    resp = InvokeResponse.from_dict(data, http_status=200)

    assert resp.decision == "DENY"
    assert resp.risk.score == 0.85
    assert resp.risk.band == "HIGH"
    assert len(resp.risk.signals) == 1
    assert resp.matched_policies[0].policy_id == "p1"
    assert resp.matched_policies[0].policy_version == 3
    assert "EXTERNAL_PRINCIPAL" in resp.reason_codes
    assert resp.approval_id is None
    assert resp.http_status == 200


def test_invoke_response_from_dict_require_approval():
    data = {
        "decision": "REQUIRE_APPROVAL",
        "approval_id": "abc-123",
        "risk": {"score": 0.5, "band": "MEDIUM"},
        "matched_policies": [],
        "reason_codes": ["WRITE_OPERATION"],
    }
    resp = InvokeResponse.from_dict(data)
    assert resp.decision == "REQUIRE_APPROVAL"
    assert resp.approval_id == "abc-123"


def test_invoke_response_from_dict_error():
    data = {"error": "HMAC verification failed"}
    resp = InvokeResponse.from_dict(data, http_status=401)
    assert resp.error == "HMAC verification failed"
    assert resp.http_status == 401
    assert resp.decision is None


def test_invoke_response_from_dict_minimal():
    resp = InvokeResponse.from_dict({})
    assert resp.decision is None
    assert resp.risk is None
    assert resp.matched_policies == []


def test_approval_status_from_dict():
    data = {
        "approval_id": "app-1",
        "status": "pending",
        "remaining_seconds": 3500,
        "expires_at": "2026-03-08T15:00:00Z",
        "poll_guidance": "poll every 5-10s",
    }
    status = ApprovalStatus.from_dict(data)
    assert status.approval_id == "app-1"
    assert status.status == "pending"
    assert status.remaining_seconds == 3500
    assert not status.is_terminal
    assert not status.is_approved


def test_approval_status_terminal_states():
    for state in ("approved", "denied", "expired", "executed"):
        status = ApprovalStatus.from_dict({"approval_id": "x", "status": state})
        assert status.is_terminal

    status = ApprovalStatus.from_dict({"approval_id": "x", "status": "pending"})
    assert not status.is_terminal


def test_approval_status_is_approved():
    approved = ApprovalStatus.from_dict({"approval_id": "x", "status": "approved"})
    assert approved.is_approved

    denied = ApprovalStatus.from_dict({"approval_id": "x", "status": "denied"})
    assert not denied.is_approved
