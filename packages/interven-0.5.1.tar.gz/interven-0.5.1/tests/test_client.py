"""Tests for the AifClient — mock HTTP, verify HMAC signing and request shape."""

import json
from unittest.mock import MagicMock, patch

from aif_sdk import AifClient, InvokeParams


def _make_mock_response(data: dict, status_code: int = 200):
    mock = MagicMock()
    mock.status_code = status_code
    mock.json.return_value = data
    return mock


@patch("aif_sdk.client.requests.post")
def test_invoke_sends_correct_request(mock_post):
    mock_post.return_value = _make_mock_response({
        "decision": "DENY",
        "risk": {"score": 0.8, "band": "HIGH"},
        "matched_policies": [],
        "reason_codes": ["EXTERNAL_PRINCIPAL"],
    })

    client = AifClient(
        gateway_url="http://gateway:4000",
        agent_id="agent-1",
        agent_name="test-agent",
        agent_secret="secret-123",
    )

    result = client.invoke(InvokeParams(
        tool_name="github",
        operation="add_collaborator",
        method="PUT",
        url_path="/repos/org/repo/collaborators/user",
        body={"permission": "push"},
        credential_type="pat",
        credential_token="ghp_test",
        scopes=["repo"],
    ))

    assert result.decision == "DENY"
    assert result.http_status == 200

    call_args = mock_post.call_args
    assert call_args[0][0] == "http://gateway:4000/invoke"

    sent_body = json.loads(call_args[1]["data"] if "data" in call_args[1] else call_args.kwargs["data"])
    assert sent_body["tool_name"] == "github"
    assert sent_body["operation"] == "add_collaborator"
    assert sent_body["agent_context"]["agent_id"] == "agent-1"
    assert sent_body["agent_context"]["runtime_type"] == "python"
    assert sent_body["identity_context"]["credential_type"] == "pat"
    assert "ts" in sent_body
    assert "trace_id" in sent_body

    headers = call_args[1].get("headers", call_args.kwargs.get("headers", {}))
    assert "X-AIF-Signature" in headers
    assert headers["Content-Type"] == "application/json"


@patch("aif_sdk.client.requests.post")
def test_invoke_require_approval(mock_post):
    mock_post.return_value = _make_mock_response({
        "decision": "REQUIRE_APPROVAL",
        "approval_id": "appr-xyz",
        "risk": {"score": 0.5, "band": "MEDIUM"},
        "matched_policies": [{"policy_id": "p2", "rule_ids": ["r1"]}],
        "reason_codes": ["WRITE_OPERATION"],
    })

    client = AifClient(
        gateway_url="http://localhost:4000",
        agent_id="a1",
        agent_name="bot",
        agent_secret="sec",
    )

    result = client.invoke(InvokeParams(
        tool_name="github",
        operation="create_pull_request",
        method="POST",
        url_path="/repos/org/repo/pulls",
        credential_type="pat",
        credential_token="ghp_xxx",
        scopes=["repo"],
    ))

    assert result.decision == "REQUIRE_APPROVAL"
    assert result.approval_id == "appr-xyz"


@patch("aif_sdk.client.requests.get")
def test_poll_approval(mock_get):
    mock_get.return_value = _make_mock_response({
        "approval_id": "appr-1",
        "status": "pending",
        "remaining_seconds": 3400,
        "poll_guidance": "poll every 5-10s",
    })

    client = AifClient(
        gateway_url="http://localhost:4000",
        agent_id="a1",
        agent_name="bot",
        agent_secret="sec",
    )

    status = client.poll_approval("appr-1")
    assert status.status == "pending"
    assert status.remaining_seconds == 3400
    assert not status.is_terminal

    mock_get.assert_called_once()
    assert "/approvals/appr-1/status" in mock_get.call_args[0][0]


@patch("aif_sdk.client.requests.post")
def test_execute_approval(mock_post):
    mock_post.return_value = _make_mock_response({
        "decision": "ALLOW",
        "upstream_response": {"status": 201},
    })

    client = AifClient(
        gateway_url="http://localhost:4000",
        agent_id="a1",
        agent_name="bot",
        agent_secret="sec",
    )

    result = client.execute_approval("appr-1", "ghp_token", "pat", ["repo"])
    assert result.decision == "ALLOW"

    sent = mock_post.call_args
    body = sent[1].get("json") or sent.kwargs.get("json")
    assert body["credential_token"] == "ghp_token"


def test_telemetry_url_default_derivation():
    client = AifClient(
        gateway_url="http://localhost:4000",
        agent_id="a1",
        agent_name="bot",
        agent_secret="sec",
    )
    assert client._telemetry_url() == "http://localhost:4100"


def test_telemetry_url_explicit():
    client = AifClient(
        gateway_url="http://localhost:4000",
        agent_id="a1",
        agent_name="bot",
        agent_secret="sec",
        telemetry_url="http://tel:9000",
    )
    assert client._telemetry_url() == "http://tel:9000"
