from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class InvokeParams:
    tool_name: str
    method: str
    url_path: str
    credential_type: str
    credential_token: str
    scopes: list[str]
    operation: Optional[str] = None
    body: Optional[Any] = None
    headers: Optional[dict[str, str]] = None
    trace_id: Optional[str] = None


@dataclass
class RiskInfo:
    score: float
    band: str
    signals: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class MatchedPolicy:
    policy_id: str
    rule_ids: list[str] = field(default_factory=list)
    policy_version: Optional[int] = None


@dataclass
class InvokeResponse:
    decision: Optional[str] = None
    risk: Optional[RiskInfo] = None
    matched_policies: list[MatchedPolicy] = field(default_factory=list)
    reason_codes: list[str] = field(default_factory=list)
    approval_id: Optional[str] = None
    error: Optional[str] = None
    upstream_response: Optional[Any] = None
    response_actions: Optional[list[dict[str, Any]]] = None
    http_status: int = 200

    @classmethod
    def from_dict(cls, data: dict[str, Any], http_status: int = 200) -> InvokeResponse:
        risk = None
        if data.get("risk"):
            r = data["risk"]
            risk = RiskInfo(
                score=r.get("score", 0),
                band=r.get("band", "LOW"),
                signals=r.get("signals", []),
            )

        matched = []
        for mp in data.get("matched_policies", []):
            matched.append(MatchedPolicy(
                policy_id=mp.get("policy_id", ""),
                rule_ids=mp.get("rule_ids", []),
                policy_version=mp.get("policy_version"),
            ))

        return cls(
            decision=data.get("decision"),
            risk=risk,
            matched_policies=matched,
            reason_codes=data.get("reason_codes", []),
            approval_id=data.get("approval_id"),
            error=data.get("error"),
            upstream_response=data.get("upstream_response"),
            response_actions=data.get("response_actions"),
            http_status=http_status,
        )


@dataclass
class ApprovalStatus:
    approval_id: str
    status: str
    decision: Optional[str] = None
    decided_at: Optional[str] = None
    expires_at: Optional[str] = None
    remaining_seconds: int = 0
    poll_guidance: Optional[str] = None
    retry_guidance: Optional[str] = None
    error: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ApprovalStatus:
        return cls(
            approval_id=data.get("approval_id", ""),
            status=data.get("status", "unknown"),
            decision=data.get("decision"),
            decided_at=data.get("decided_at"),
            expires_at=data.get("expires_at"),
            remaining_seconds=data.get("remaining_seconds", 0),
            poll_guidance=data.get("poll_guidance"),
            retry_guidance=data.get("retry_guidance"),
            error=data.get("error"),
        )

    @property
    def is_terminal(self) -> bool:
        return self.status in ("approved", "denied", "expired", "executed")

    @property
    def is_approved(self) -> bool:
        return self.status == "approved"
