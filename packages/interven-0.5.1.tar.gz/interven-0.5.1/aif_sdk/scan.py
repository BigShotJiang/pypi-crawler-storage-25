"""
Bearer API key client for the Interven `/v1/scan` endpoint.

This is the customer-facing SaaS client — five-line integration with no HMAC,
no agent registration, just a Bearer token.

    from interven import Client

    client = Client(api_key="iv_live_...")
    result = client.scan(
        method="POST",
        url="https://slack.com/api/chat.postMessage",
        body={"text": "Customer SSN 478-23-9156"},
    )

    if result.decision == "ALLOW":
        send_to_slack(result.body_to_forward)
    elif result.decision == "SANITIZE":
        send_to_slack(result.sanitized_body)
    else:
        log_and_drop(result)

For HMAC-authenticated agents (the original `/invoke` flow), use `AifClient`
from `aif_sdk.client` instead.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Optional

import requests

from .exceptions import AifError, AuthenticationError, GatewayError, PayloadTooLargeError
from .tools import ToolsClient


DEFAULT_GATEWAY_URL = "https://api.intervensecurity.com"
DEFAULT_TIMEOUT = 30.0


@dataclass
class ScanResponse:
    """Response from POST /v1/scan."""

    decision: str
    """One of: ALLOW, DENY, SANITIZE, REQUIRE_APPROVAL."""

    risk_score: float
    """0.0–1.0 deterministic risk score."""

    risk_band: str
    """One of: LOW, MEDIUM, HIGH, CRITICAL."""

    reason_codes: list[str] = field(default_factory=list)
    """Human-readable reason codes (e.g. PII_DETECTED, THREAT_INTEL_HIT)."""

    sanitized_body: Optional[Any] = None
    """For SANITIZE decisions: the redacted body to forward instead of the original."""

    approval_id: Optional[str] = None
    """For REQUIRE_APPROVAL: opaque ID to poll via /approvals/{id}/status."""

    trace_id: str = ""
    """Unique trace ID for cross-referencing in the Interven dashboard."""

    raw: dict[str, Any] = field(default_factory=dict)
    """Full JSON response, in case you need fields not surfaced as attributes."""

    @property
    def allowed(self) -> bool:
        """True if the agent should proceed with the original request."""
        return self.decision == "ALLOW"

    @property
    def blocked(self) -> bool:
        """True if the agent should not proceed (DENY)."""
        return self.decision == "DENY"

    @property
    def needs_sanitization(self) -> bool:
        """True if the agent should forward `sanitized_body` instead of the original."""
        return self.decision == "SANITIZE"

    @property
    def needs_approval(self) -> bool:
        """True if the agent should pause and poll the approval endpoint."""
        return self.decision == "REQUIRE_APPROVAL"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ScanResponse":
        return cls(
            decision=str(data.get("decision", "")).upper(),
            risk_score=float(data.get("risk_score", 0.0)),
            risk_band=str(data.get("risk_band", "LOW")).upper(),
            reason_codes=list(data.get("reason_codes", []) or []),
            sanitized_body=data.get("sanitized_body"),
            approval_id=data.get("approval_id"),
            trace_id=str(data.get("trace_id", "")),
            raw=data,
        )


class Client:
    """Interven SaaS client. Uses Bearer API key auth — no HMAC, no agent secrets.

    Args:
        api_key: Your iv_live_* token. Read from INTERVEN_API_KEY env if omitted.
        gateway_url: Override the hosted endpoint. Read from INTERVEN_GATEWAY_URL
            env if omitted. Defaults to https://api.intervensecurity.com.
        timeout: Per-request timeout in seconds. Default 30.
        agent_id: Optional default agent UUID for all scans. Can be overridden
            per-call. If omitted and the API key isn't bound to an agent,
            Interven uses DEFAULT_SCAN_AGENT_ID server-side.
        runtime_type: Tag for telemetry, e.g. "langchain", "crewai", "openclaw".
            Default "python".
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        gateway_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT,
        agent_id: Optional[str] = None,
        runtime_type: str = "python",
    ):
        resolved_key = api_key or os.environ.get("INTERVEN_API_KEY", "").strip()
        if not resolved_key:
            raise AuthenticationError(
                "No API key provided. Pass api_key=... or set INTERVEN_API_KEY."
            )
        self.api_key = resolved_key
        self.gateway_url = (
            gateway_url
            or os.environ.get("INTERVEN_GATEWAY_URL", "").strip()
            or DEFAULT_GATEWAY_URL
        ).rstrip("/")
        self.timeout = timeout
        self.agent_id = agent_id
        self.runtime_type = runtime_type
        self.tools = ToolsClient(gateway_url=self.gateway_url, api_key=self.api_key, timeout=self.timeout)

    def scan(
        self,
        *,
        method: str,
        url: str,
        body: Optional[Any] = None,
        headers: Optional[dict[str, str]] = None,
        agent_id: Optional[str] = None,
        runtime_type: Optional[str] = None,
    ) -> ScanResponse:
        """Send one outbound request through Interven's policy + risk pipeline.

        Args:
            method: HTTP verb the agent intends to call (GET, POST, PUT, DELETE, ...).
            url: Absolute URL the agent intends to hit.
            body: Optional request body the agent would send.
            headers: Optional request headers.
            agent_id: Override the client's default agent_id for this scan.
            runtime_type: Override the client's default runtime_type for this scan.

        Returns:
            ScanResponse with the decision and (for SANITIZE) a redacted body.

        Raises:
            AuthenticationError: API key invalid or revoked.
            PayloadTooLargeError: Request body exceeded server limit (256KB default).
            GatewayError: Any other non-2xx response.
        """
        payload: dict[str, Any] = {
            "method": method.upper(),
            "url": url,
            "body": body if body is not None else {},
            "runtime_type": runtime_type or self.runtime_type,
        }
        if headers:
            payload["headers"] = headers
        effective_agent = agent_id or self.agent_id
        if effective_agent:
            payload["agent_id"] = effective_agent

        try:
            resp = requests.post(
                f"{self.gateway_url}/v1/scan",
                json=payload,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                timeout=self.timeout,
            )
        except requests.RequestException as e:
            raise GatewayError(f"Network error contacting Interven: {e}") from e

        if resp.status_code == 401:
            raise AuthenticationError("API key invalid, revoked, or missing")
        if resp.status_code == 413:
            raise PayloadTooLargeError()

        try:
            data = resp.json()
        except ValueError as e:
            raise GatewayError(
                f"Non-JSON response from Interven (status={resp.status_code}): {resp.text[:200]}"
            ) from e

        if resp.status_code >= 400:
            raise GatewayError(
                f"Interven returned {resp.status_code}: {data.get('error') or data}"
            )

        return ScanResponse.from_dict(data)

    def scan_response(
        self,
        *,
        trace_id: str,
        response_body: Any,
        response_status: Optional[int] = None,
    ) -> dict[str, Any]:
        """Classify the response body of an upstream call (read-side scanning).

        Companion to `scan()`. Call this after a `scan()` returned ALLOW and
        the agent has actually performed the upstream request — pass back
        the response body so Interven can record what content the agent saw.
        Used for forensics today (RESPONSE_CLASSIFIED events in the activity
        feed) and feeds correlation rules in v0.5+ that detect read→write
        exfiltration chains.

        Args:
            trace_id: The trace_id returned by the originating `scan()` call.
            response_body: The response body (string, dict, or list).
            response_status: Optional HTTP status code from the upstream call.

        Returns:
            dict with `data_classes`, `fields_redacted_count`, `content_fingerprint`.
        """
        payload: dict[str, Any] = {
            "trace_id": trace_id,
            "response_body": response_body,
        }
        if response_status is not None:
            payload["response_status"] = response_status
        try:
            resp = requests.post(
                f"{self.gateway_url}/v1/scan/response",
                json=payload,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                timeout=self.timeout,
            )
        except requests.RequestException as e:
            raise GatewayError(f"Network error contacting Interven: {e}") from e
        if resp.status_code == 401:
            raise AuthenticationError("API key invalid, revoked, or missing")
        if resp.status_code >= 400:
            try:
                err = resp.json()
            except ValueError:
                err = {"error": resp.text[:200]}
            raise GatewayError(f"Interven returned {resp.status_code}: {err.get('error') or err}")
        return resp.json()

    def health(self) -> bool:
        """Quick connectivity check. Returns True if the gateway responds 200 to /health."""
        try:
            r = requests.get(f"{self.gateway_url}/health", timeout=5)
            return r.status_code == 200
        except requests.RequestException:
            return False
