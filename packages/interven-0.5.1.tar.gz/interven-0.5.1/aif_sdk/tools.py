"""
Interven tool gateway — call real external tools (Slack, GitHub, Google Drive, etc.)
through Interven. Your agent never sees the real tool credential; Interven holds it,
scans every call, and executes upstream on your behalf.

    from interven import Client
    c = Client(api_key="iv_live_...")

    result = c.tools.slack.post_message(text="Customer report attached")
    if result.allowed:
        print("Delivered to Slack")
    elif result.sanitized:
        print(f"Delivered with redactions: {result.sanitized_body}")
    elif result.blocked:
        print(f"Blocked by Interven: {result.reason_codes}")
    elif result.awaiting_approval:
        print(f"Pending analyst approval: {result.approval_url}")

Credentials for each tool are stored once by the tenant admin via the Interven console
(or the `/v1/credentials/:tool` admin endpoint). Agents only ever have the Interven key.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

import requests

from .exceptions import AifError, AuthenticationError, GatewayError


@dataclass
class ToolResult:
    """Result from a tool-gateway call."""

    decision: str
    """ALLOW, SANITIZE, DENY, or REQUIRE_APPROVAL."""

    trace_id: str = ""
    risk_score: float = 0.0
    risk_band: str = "LOW"
    reason_codes: list[str] = field(default_factory=list)

    sanitized_body: Optional[Any] = None
    """For SANITIZE: the actual body that was forwarded to the upstream tool."""

    upstream_status: Optional[int] = None
    """HTTP status the real tool returned (None for DENY / REQUIRE_APPROVAL)."""

    upstream_body: Optional[Any] = None
    """Response body from the real tool (None for DENY / REQUIRE_APPROVAL)."""

    approval_id: Optional[str] = None
    approval_url: Optional[str] = None

    error: Optional[str] = None
    raw: dict[str, Any] = field(default_factory=dict)

    @property
    def allowed(self) -> bool:
        return self.decision == "ALLOW"

    @property
    def sanitized(self) -> bool:
        return self.decision == "SANITIZE"

    @property
    def blocked(self) -> bool:
        return self.decision == "DENY"

    @property
    def awaiting_approval(self) -> bool:
        return self.decision == "REQUIRE_APPROVAL"

    @classmethod
    def from_response(cls, status_code: int, data: dict[str, Any]) -> "ToolResult":
        upstream = data.get("upstream") or {}
        return cls(
            decision=str(data.get("decision", "")).upper(),
            trace_id=str(data.get("trace_id", "")),
            risk_score=float(data.get("risk_score", 0.0)),
            risk_band=str(data.get("risk_band", "LOW")).upper(),
            reason_codes=list(data.get("reason_codes", []) or []),
            sanitized_body=data.get("sanitized_body"),
            upstream_status=upstream.get("status"),
            upstream_body=upstream.get("body"),
            approval_id=data.get("approval_id"),
            approval_url=data.get("approval_url"),
            error=data.get("error"),
            raw=data,
        )


class _ToolTransport:
    """Internal HTTP transport shared by all tool namespaces."""

    def __init__(self, *, gateway_url: str, api_key: str, timeout: float):
        self._gateway_url = gateway_url
        self._api_key = api_key
        self._timeout = timeout

    def call(self, tool: str, operation: str, params: dict[str, Any]) -> ToolResult:
        url = f"{self._gateway_url}/v1/tools/{tool}/{operation}"
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "User-Agent": "interven-python-sdk/0.5",
        }
        try:
            r = requests.post(url, headers=headers, json=params, timeout=self._timeout)
        except requests.RequestException as e:
            raise GatewayError(f"Failed to reach Interven: {e}") from e

        if r.status_code == 401:
            raise AuthenticationError("Invalid or revoked Interven API key")

        # 202 (REQUIRE_APPROVAL) and 403 (DENY) are valid domain responses — return them.
        # Only truly unexpected statuses become GatewayError.
        try:
            data = r.json()
        except ValueError:
            raise GatewayError(f"Interven returned non-JSON (status={r.status_code}): {r.text[:200]}")

        if r.status_code >= 500:
            raise GatewayError(f"Interven gateway error {r.status_code}: {data}")

        return ToolResult.from_response(r.status_code, data)


# ---------- tool namespaces ----------

class SlackTools:
    def __init__(self, transport: _ToolTransport):
        self._t = transport

    def post_message(
        self,
        *,
        text: str,
        channel: Optional[str] = None,
        blocks: Optional[list[Any]] = None,
    ) -> ToolResult:
        """Post a message to Slack.

        - If tenant's Slack credential is a webhook URL, `channel` is ignored (the
          webhook is bound to one channel by Slack).
        - If it's a bot token, `channel` is required.
        """
        params: dict[str, Any] = {"text": text}
        if channel is not None:
            params["channel"] = channel
        if blocks is not None:
            params["blocks"] = blocks
        return self._t.call("slack", "post_message", params)


class GitHubTools:
    def __init__(self, transport: _ToolTransport):
        self._t = transport

    def create_pull_request(
        self,
        *,
        owner: str,
        repo: str,
        title: str,
        head: str,
        base: str = "main",
        body: Optional[str] = None,
    ) -> ToolResult:
        """Open a PR on owner/repo. Requires a GitHub fine-grained PAT credential."""
        params: dict[str, Any] = {"owner": owner, "repo": repo, "title": title, "head": head, "base": base}
        if body is not None:
            params["body"] = body
        return self._t.call("github", "create_pull_request", params)

    def update_file(
        self,
        *,
        owner: str,
        repo: str,
        path: str,
        message: str,
        content: str,  # base64-encoded
        sha: Optional[str] = None,
        branch: Optional[str] = None,
    ) -> ToolResult:
        """Create or update a file. `content` must be base64-encoded per GitHub API."""
        params: dict[str, Any] = {"owner": owner, "repo": repo, "path": path, "message": message, "content": content}
        if sha is not None:
            params["sha"] = sha
        if branch is not None:
            params["branch"] = branch
        return self._t.call("github", "update_file", params)


class GDriveTools:
    def __init__(self, transport: _ToolTransport):
        self._t = transport

    def share_file(
        self,
        *,
        file_id: str,
        role: str,  # "reader", "commenter", "writer", "owner"
        type: str,  # "user", "group", "domain", "anyone"
        email_address: Optional[str] = None,
    ) -> ToolResult:
        """Grant a permission on a Drive file. `type=anyone` triggers external-share policies."""
        params: dict[str, Any] = {"file_id": file_id, "role": role, "type": type}
        if email_address is not None:
            params["email_address"] = email_address
        return self._t.call("gdrive", "share_file", params)


class HttpTools:
    def __init__(self, transport: _ToolTransport):
        self._t = transport

    def request(
        self,
        *,
        url: str,
        method: str = "GET",
        body: Optional[Any] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> ToolResult:
        """Generic HTTP call through Interven — use for any tool not covered by a native namespace."""
        params: dict[str, Any] = {"url": url, "method": method}
        if body is not None:
            params["body"] = body
        if headers is not None:
            params["headers"] = headers
        return self._t.call("http", "request", params)


class ToolsClient:
    """Root namespace: `client.tools.slack`, `client.tools.github`, etc."""

    def __init__(self, *, gateway_url: str, api_key: str, timeout: float):
        self._transport = _ToolTransport(gateway_url=gateway_url, api_key=api_key, timeout=timeout)
        self.slack = SlackTools(self._transport)
        self.github = GitHubTools(self._transport)
        self.gdrive = GDriveTools(self._transport)
        self.http = HttpTools(self._transport)

    def call(self, tool: str, operation: str, **params: Any) -> ToolResult:
        """Escape hatch: call any tool operation not covered by a typed namespace."""
        return self._transport.call(tool, operation, params)
