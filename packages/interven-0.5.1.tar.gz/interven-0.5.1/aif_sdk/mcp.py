"""MCP (Model Context Protocol) middleware for AIF.

Provides a transparent wrapper that intercepts MCP tools/call requests,
routes them through the AIF gateway for policy/risk evaluation, and
returns MCP-formatted responses.

Usage with any MCP client::

    from aif_sdk.mcp import AifMcpMiddleware

    middleware = AifMcpMiddleware(
        gateway_url="http://localhost:4000",
        agent_id="00000000-0000-0000-0000-000000000010",
        agent_secret="aif-demo-secret-key-12345",
    )

    # Intercept an MCP tools/call request
    mcp_request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": "github_create_pull_request",
            "arguments": {"owner": "org", "repo": "repo", "title": "PR", ...}
        }
    }

    mcp_response = middleware.intercept(mcp_request)

    if mcp_response["result"]["isError"]:
        print("Blocked by AIF:", mcp_response["result"]["content"][0]["text"])
    else:
        # Forward to real MCP server
        real_response = mcp_client.send(mcp_request)
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Optional

import requests

from .auth import hmac_sign


class AifMcpMiddleware:
    """Transparent MCP middleware that enforces AIF policy on MCP tool calls.

    Acts as an interceptor between an MCP client and MCP server. For each
    tools/call request, it checks AIF's gateway and either allows the call
    to proceed, blocks it (DENY), or flags it for approval.

    The middleware communicates with the gateway's /mcp endpoint using
    standard MCP JSON-RPC format with AIF auth headers.
    """

    def __init__(
        self,
        gateway_url: str,
        agent_id: str,
        agent_secret: str,
        *,
        agent_name: Optional[str] = None,
        credential_type: str = "none",
        credential_token: str = "",
        scopes: Optional[list[str]] = None,
        timeout: float = 30.0,
    ):
        self.gateway_url = gateway_url.rstrip("/")
        self.agent_id = agent_id
        self.agent_secret = agent_secret
        self.agent_name = agent_name or agent_id
        self.credential_type = credential_type
        self.credential_token = credential_token
        self.scopes = scopes or []
        self.timeout = timeout

    def intercept(self, mcp_request: dict[str, Any]) -> dict[str, Any]:
        """Send an MCP tools/call request through AIF for policy evaluation.

        Args:
            mcp_request: Standard MCP JSON-RPC request (must be tools/call or tools/list).

        Returns:
            MCP JSON-RPC response from AIF. If the result.isError is True,
            the tool call was blocked or requires approval.
        """
        body_str = json.dumps(mcp_request, separators=(",", ":"))
        signature = hmac_sign(body_str, self.agent_secret)
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "X-AIF-Agent-ID": self.agent_id,
            "X-AIF-Signature": signature,
            "X-AIF-Timestamp": ts,
        }
        if self.credential_type != "none":
            headers["X-AIF-Credential-Type"] = self.credential_type
            headers["X-AIF-Credential-Token"] = self.credential_token
            headers["X-AIF-Scopes"] = ",".join(self.scopes)

        resp = requests.post(
            f"{self.gateway_url}/mcp",
            data=body_str,
            headers=headers,
            timeout=self.timeout,
        )

        try:
            return resp.json()
        except ValueError:
            return {
                "jsonrpc": "2.0",
                "id": mcp_request.get("id", 0),
                "error": {"code": -32603, "message": f"Gateway error: {resp.text}"},
            }

    def is_allowed(self, mcp_response: dict[str, Any]) -> bool:
        """Check if an MCP response from AIF indicates the call is allowed."""
        result = mcp_response.get("result")
        if not result:
            return False
        return not result.get("isError", False)

    def get_approval_id(self, mcp_response: dict[str, Any]) -> Optional[str]:
        """Extract approval ID from an MCP response if present."""
        result = mcp_response.get("result")
        if not result:
            return None
        text = ""
        for content in result.get("content", []):
            if content.get("type") == "text":
                text += content["text"]
        for line in text.split("\n"):
            if line.startswith("Approval ID:"):
                return line.split(":", 1)[1].strip()
        return None

    def list_tools(self) -> list[dict[str, str]]:
        """Discover supported MCP tools from the gateway.

        Uses the unauthenticated /mcp/tools/list endpoint for discovery.
        """
        resp = requests.post(
            f"{self.gateway_url}/mcp/tools/list",
            json={"jsonrpc": "2.0", "id": 0, "method": "tools/list", "params": {}},
            timeout=self.timeout,
        )
        try:
            data = resp.json()
        except ValueError:
            return []
        return data.get("result", {}).get("tools", [])
