import base64
import hashlib
import hmac


def hmac_sign(payload: str, secret: str) -> str:
    """HMAC-SHA256 sign a payload string, return base64-encoded signature."""
    sig = hmac.new(
        secret.encode("utf-8"),
        payload.encode("utf-8"),
        hashlib.sha256,
    ).digest()
    return base64.b64encode(sig).decode("utf-8")
