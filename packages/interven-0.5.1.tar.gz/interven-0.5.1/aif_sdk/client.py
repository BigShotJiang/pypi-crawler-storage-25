from __future__ import annotations

import json
import time
import uuid
from datetime import datetime, timezone
from typing import Optional

import requests

from .auth import hmac_sign
from .exceptions import (
    ApprovalDeniedError,
    ApprovalExpiredError,
    ApprovalTimeoutError,
    AuthenticationError,
    GatewayError,
    PayloadTooLargeError,
    PolicyDeniedError,
    ReplayRejectedError,
)
from .types import ApprovalStatus, InvokeParams, InvokeResponse


class AifClient:
    """Client for the Agent Identity Firewall (AIF) gateway.

    Usage::

        client = AifClient(
            gateway_url="http://localhost:4000",
            agent_id="00000000-0000-0000-0000-000000000010",
            agent_name="my-agent",
            agent_secret="aif-demo-secret-key-12345",
        )

        result = client.invoke(InvokeParams(
            tool_name="github",
            operation="add_collaborator",
            method="PUT",
            url_path="/repos/org/repo/collaborators/user",
            body={"permission": "push"},
            credential_type="pat",
            credential_token="ghp_...",
            scopes=["repo"],
        ))

        print(result.decision)  # ALLOW, DENY, REQUIRE_APPROVAL, or SANITIZE
    """

    def __init__(
        self,
        gateway_url: str,
        agent_id: str,
        agent_name: str,
        agent_secret: str,
        *,
        runtime_type: str = "python",
        deployment_env: str = "dev",
        telemetry_url: Optional[str] = None,
        timeout: float = 30.0,
        raise_on_deny: bool = False,
    ):
        self.gateway_url = gateway_url.rstrip("/")
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.agent_secret = agent_secret
        self.runtime_type = runtime_type
        self.deployment_env = deployment_env
        self.telemetry_url = (telemetry_url or "").rstrip("/") or None
        self.timeout = timeout
        self.raise_on_deny = raise_on_deny

    def invoke(self, params: InvokeParams) -> InvokeResponse:
        """Send a tool invocation through the AIF gateway.

        Returns an InvokeResponse with the decision, risk info, and
        optionally an approval_id if the decision is REQUIRE_APPROVAL.
        """
        trace_id = params.trace_id or str(uuid.uuid4())
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

        request_body = {
            "tool_name": params.tool_name,
            "upstream_request": {
                "method": params.method,
                "url_path": params.url_path,
            },
            "agent_context": {
                "agent_id": self.agent_id,
                "agent_name": self.agent_name,
                "runtime_type": self.runtime_type,
                "deployment_env": self.deployment_env,
            },
            "identity_context": {
                "credential_type": params.credential_type,
                "credential_token": params.credential_token,
                "scopes": params.scopes,
            },
            "trace_id": trace_id,
            "ts": ts,
        }

        if params.operation:
            request_body["operation"] = params.operation
        if params.body is not None:
            request_body["upstream_request"]["body"] = params.body
        if params.headers:
            request_body["upstream_request"]["headers"] = params.headers

        body_str = json.dumps(request_body, separators=(",", ":"))
        signature = hmac_sign(body_str, self.agent_secret)

        resp = requests.post(
            f"{self.gateway_url}/invoke",
            data=body_str,
            headers={
                "Content-Type": "application/json",
                "X-AIF-Signature": signature,
            },
            timeout=self.timeout,
        )

        if resp.status_code == 401:
            raise AuthenticationError("HMAC signature verification failed or agent not recognized")
        if resp.status_code == 413:
            raise PayloadTooLargeError()

        try:
            data = resp.json()
        except ValueError:
            data = {"error": resp.text}

        if resp.status_code == 400 and "replay" in data.get("error", "").lower():
            raise ReplayRejectedError()

        result = InvokeResponse.from_dict(data, http_status=resp.status_code)

        if self.raise_on_deny and result.decision == "DENY":
            raise PolicyDeniedError(
                result.error or "Denied by policy",
                reason_codes=result.reason_codes,
                matched_policies=[mp.policy_id for mp in result.matched_policies],
            )

        return result

    def poll_approval(self, approval_id: str) -> ApprovalStatus:
        """Poll the status of a pending approval.

        Use this after receiving a REQUIRE_APPROVAL decision. Returns an
        ApprovalStatus with the current state and guidance for next steps.

        Rate limited to 1 request per 2 seconds per approval ID on the server.
        """
        url = self._telemetry_url()
        resp = requests.get(
            f"{url}/approvals/{approval_id}/status",
            timeout=self.timeout,
        )

        try:
            data = resp.json()
        except ValueError:
            data = {"error": resp.text, "approval_id": approval_id, "status": "unknown"}

        return ApprovalStatus.from_dict(data)

    def wait_for_approval(
        self,
        approval_id: str,
        *,
        poll_interval: float = 5.0,
        max_wait: float = 3600.0,
        raise_on_terminal: bool = True,
    ) -> ApprovalStatus:
        """Block until an approval reaches a terminal state.

        Args:
            approval_id: The approval ID from an InvokeResponse.
            poll_interval: Seconds between polls (minimum 2.5 to respect rate limit).
            max_wait: Maximum seconds to wait before raising ApprovalTimeoutError.
            raise_on_terminal: If True (default), raises ApprovalExpiredError or
                ApprovalDeniedError on those terminal states. Set False to always
                return the ApprovalStatus without raising.

        Returns:
            The final ApprovalStatus (always returned for "approved" or "executed";
            also returned for "expired"/"denied" when raise_on_terminal=False).

        Raises:
            ApprovalExpiredError: Approval expired (60-min window) and raise_on_terminal=True.
            ApprovalDeniedError: Analyst denied the approval and raise_on_terminal=True.
            ApprovalTimeoutError: max_wait exceeded before any terminal state was reached.
        """
        poll_interval = max(poll_interval, 2.5)
        start = time.monotonic()
        deadline = start + max_wait

        while time.monotonic() < deadline:
            status = self.poll_approval(approval_id)
            if status.is_terminal:
                if raise_on_terminal and status.status == "expired":
                    raise ApprovalExpiredError(approval_id)
                if raise_on_terminal and status.status == "denied":
                    raise ApprovalDeniedError(approval_id)
                return status
            time.sleep(poll_interval)

        raise ApprovalTimeoutError(approval_id, waited_seconds=time.monotonic() - start)

    def execute_approval(
        self,
        approval_id: str,
        credential_token: str,
        credential_type: str,
        scopes: list[str],
    ) -> InvokeResponse:
        """Execute a previously approved invocation.

        After an approval is approved by an analyst, call this to trigger
        the actual upstream API call through the gateway.
        """
        resp = requests.post(
            f"{self.gateway_url}/approvals/{approval_id}/execute",
            json={
                "credential_token": credential_token,
                "credential_type": credential_type,
                "scopes": scopes,
            },
            timeout=self.timeout,
        )

        try:
            data = resp.json()
        except ValueError:
            data = {"error": resp.text}

        return InvokeResponse.from_dict(data, http_status=resp.status_code)

    def _telemetry_url(self) -> str:
        if self.telemetry_url:
            return self.telemetry_url
        # Default: derive from gateway URL by changing port 4000 -> 4100
        return self.gateway_url.replace(":4000", ":4100")
