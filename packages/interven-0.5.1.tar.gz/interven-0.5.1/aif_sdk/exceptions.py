from __future__ import annotations

from typing import Any, Optional


class AifError(Exception):
    """Base exception for all AIF SDK errors."""

    def __init__(self, message: str, *, code: Optional[str] = None, details: Optional[dict[str, Any]] = None):
        super().__init__(message)
        self.code = code
        self.details = details or {}


class AuthenticationError(AifError):
    """HMAC signature verification failed or agent not recognized."""
    pass


class PolicyDeniedError(AifError):
    """The invocation was denied by policy."""

    def __init__(self, message: str, *, reason_codes: list[str], matched_policies: list[str], **kwargs):
        super().__init__(message, code="POLICY_DENIED", **kwargs)
        self.reason_codes = reason_codes
        self.matched_policies = matched_policies


class ApprovalExpiredError(AifError):
    """The approval expired before a decision was made (60-minute window)."""

    def __init__(self, approval_id: str, message: Optional[str] = None):
        super().__init__(
            message or f"Approval {approval_id} expired before a decision was made",
            code="APPROVAL_EXPIRED",
        )
        self.approval_id = approval_id


class ApprovalDeniedError(AifError):
    """The approval was explicitly denied by an analyst."""

    def __init__(self, approval_id: str, message: Optional[str] = None):
        super().__init__(
            message or f"Approval {approval_id} was denied by an analyst",
            code="APPROVAL_DENIED",
        )
        self.approval_id = approval_id


class ApprovalTimeoutError(AifError):
    """Client-side timeout waiting for approval resolution (max_wait exceeded)."""

    def __init__(self, approval_id: str, waited_seconds: float):
        super().__init__(
            f"Timed out after {waited_seconds:.0f}s waiting for approval {approval_id}",
            code="APPROVAL_TIMEOUT",
        )
        self.approval_id = approval_id
        self.waited_seconds = waited_seconds


class GatewayError(AifError):
    """Gateway returned a non-200 response that isn't a policy decision."""
    pass


class ReplayRejectedError(AifError):
    """Request rejected due to stale timestamp (replay protection)."""

    def __init__(self):
        super().__init__("Request rejected: timestamp too old (>60s)", code="REPLAY_REJECTED")


class PayloadTooLargeError(AifError):
    """Request body exceeded the gateway's size limit (256KB)."""

    def __init__(self):
        super().__init__("Request body exceeds 256KB limit", code="PAYLOAD_TOO_LARGE")
