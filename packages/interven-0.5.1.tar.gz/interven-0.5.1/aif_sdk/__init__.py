"""
Interven Python SDK.

Two clients, one package:

    from interven import Client            # SaaS Bearer-key client → POST /v1/scan
    from interven import AifClient         # legacy HMAC client     → POST /invoke

The Bearer-key Client is the recommended path for new integrations.
"""
from .client import AifClient
from .exceptions import (
    AifError,
    ApprovalDeniedError,
    ApprovalExpiredError,
    ApprovalTimeoutError,
    AuthenticationError,
    GatewayError,
    PayloadTooLargeError,
    PolicyDeniedError,
    ReplayRejectedError,
)
from .mcp import AifMcpMiddleware
from .scan import Client, ScanResponse
from .tools import ToolResult, ToolsClient
from .types import ApprovalStatus, InvokeParams, InvokeResponse

__all__ = [
    # New (Bearer API key, /v1/scan + /v1/tools)
    "Client",
    "ScanResponse",
    "ToolResult",
    "ToolsClient",
    # Legacy (HMAC, /invoke)
    "AifClient",
    "AifMcpMiddleware",
    "InvokeParams",
    "InvokeResponse",
    "ApprovalStatus",
    # Exceptions
    "AifError",
    "ApprovalDeniedError",
    "ApprovalExpiredError",
    "ApprovalTimeoutError",
    "AuthenticationError",
    "GatewayError",
    "PayloadTooLargeError",
    "PolicyDeniedError",
    "ReplayRejectedError",
]
__version__ = "0.5.1"
