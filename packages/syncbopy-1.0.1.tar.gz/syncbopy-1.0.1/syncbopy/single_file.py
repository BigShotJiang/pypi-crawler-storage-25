"""
transcode.py — Convert a single audio file (FLAC, MP3, M4A) to Opus,
transferring tags via mutagen rather than ffmpeg's built-in metadata copy.

Dependencies:
    pip install mutagen
    ffmpeg must be on PATH
"""

import shutil
import subprocess
import tempfile
import logging
from pathlib import Path
from mutagen.flac import FLAC
from mutagen.id3 import ID3FileType
from mutagen.mp4 import MP4
from mutagen.oggopus import OggOpus


# ---------------------------------------------------------------------------
# Tag type aliases
# ---------------------------------------------------------------------------

# target format to put tags in
VorbisDict = dict[str, list[str]]


# Maps ID3v2 frame IDs to lowercase Vorbis comment field names.
ID3_TO_VORBIS: dict[str, str] = {
    # Core
    "TIT2": "title",
    "TIT3": "subtitle",
    "TALB": "album",
    "TPE1": "artist",
    "TPE2": "albumartist",
    "TPE3": "conductor",
    "TPE4": "remixer",
    "TCOM": "composer",
    "TEXT": "lyricist",
    "TCON": "genre",
    "TDRC": "date",
    "TDOR": "originaldate",
    "TRCK": "tracknumber",
    "TPOS": "discnumber",
    "TBPM": "bpm",
    "TKEY": "initialkey",
    "TLAN": "language",
    "TCOP": "copyright",
    "TENC": "encodedby",
    "TSSE": "encodersettings",
    "TSRC": "isrc",
    "TPUB": "organization",
    "TMOO": "mood",
    "TDTG": "taggingtime",
    # Sort fields
    "TSOT": "titlesort",
    "TSOP": "artistsort",
    "TSOA": "albumsort",
    "TSOC": "composersort",
    "TSO2": "albumartistsort",
    # Comments (desc-less only; keyed by description otherwise)
    "COMM": "comment",
    # Lyrics
    "USLT": "lyrics",
}

# Maps ID3.2 TXXX (user-defined text) description -> Vorbis field name.
TXXX_TO_VORBIS: dict[str, str] = {
    "MusicBrainz Artist Id": "musicbrainz_artistid",
    "MusicBrainz Album Id": "musicbrainz_albumid",
    "MusicBrainz Album Artist Id": "musicbrainz_albumartistid",
    "MusicBrainz Track Id": "musicbrainz_trackid",
    "MusicBrainz Release Track Id": "musicbrainz_releasetrackid",
    "MusicBrainz Release Group Id": "musicbrainz_releasegroupid",
    "MusicBrainz Work Id": "musicbrainz_workid",
    "MusicBrainz Disc Id": "musicbrainz_discid",
    "ACOUSTID_ID": "acoustid_id",
    "ACOUSTID_FINGERPRINT": "acoustid_fingerprint",
    "SCRIPT": "script",
    "BARCODE": "barcode",
    "CATALOGNUMBER": "catalognumber",
    "ASIN": "asin",
    "replaygain_track_gain": "replaygain_track_gain",
    "replaygain_track_peak": "replaygain_track_peak",
    "replaygain_album_gain": "replaygain_album_gain",
    "replaygain_album_peak": "replaygain_album_peak",
}

# Maps M4A atom names -> Vorbis comment field names.
M4A_TO_VORBIS: dict[str, str] = {
    "\xa9nam": "title",
    "\xa9alb": "album",
    "\xa9ART": "artist",
    "aART": "albumartist",
    "\xa9wrt": "composer",
    "\xa9gen": "genre",
    "\xa9day": "date",
    "\xa9cmt": "comment",
    "\xa9lyr": "lyrics",
    "\xa9grp": "grouping",
    "\xa9too": "encodedby",
    "cprt": "copyright",
    "soal": "albumsort",
    "soaa": "albumartistsort",
    "soar": "artistsort",
    "sonm": "titlesort",
    "soco": "composersort",
    "tmpo": "bpm",
    "cpil": "compilation",
    "----:com.apple.iTunes:MusicBrainz Artist Id": "musicbrainz_artistid",
    "----:com.apple.iTunes:MusicBrainz Album Id": "musicbrainz_albumid",
    "----:com.apple.iTunes:MusicBrainz Album Artist Id": "musicbrainz_albumartistid",
    "----:com.apple.iTunes:MusicBrainz Track Id": "musicbrainz_trackid",
    "----:com.apple.iTunes:MusicBrainz Release Track Id": "musicbrainz_releasetrackid",
    "----:com.apple.iTunes:ACOUSTID_ID": "acoustid_id",
    "----:com.apple.iTunes:replaygain_track_gain": "replaygain_track_gain",
    "----:com.apple.iTunes:replaygain_track_peak": "replaygain_track_peak",
    "----:com.apple.iTunes:replaygain_album_gain": "replaygain_album_gain",
    "----:com.apple.iTunes:replaygain_album_peak": "replaygain_album_peak",
}

# Separator used to split multi-value strings in formats that do not
# natively support repeated keys (e.g. ID3, M4A).
MULTI_VALUE_SEPARATOR = "|"

logger = logging.getLogger("syncbopy:file")


def convert_file(
    source: Path,
    target: Path,
    bitrate: str = "96k",
) -> None:
    """Main function of this file. Handles transcoding + tag conversion of a single file"""
    target.parent.mkdir(parents=True, exist_ok=True)
    tags: VorbisDict = extract_tags(source)
    # Transcode to temporary file without tags
    tmp_path: Path = transcode_without_tags(source, bitrate=bitrate)

    try:
        # Apply converted tags
        write_tags(tags, tmp_path)
        shutil.move(str(tmp_path), target)

    except Exception:
        # Clean up the temp file if anything goes wrong after transcoding
        tmp_path.unlink(missing_ok=True)
        raise


def _split_values(raw: str) -> list[str]:
    """Helper: Split e.g. multiple artists. *raw* on MULTI_VALUE_SEPARATOR; strip whitespace from each part."""
    return [part.strip() for part in raw.split(MULTI_VALUE_SEPARATOR) if part.strip()]


def extract_tags(source: Path) -> VorbisDict:
    """
    Open *source* with mutagen and return its tags as a :data:`VorbisDict`.

    - FLAC / Ogg files already use Vorbis comments; values are passed through
      (repeated keys are already lists in mutagen).
    - MP3 / ID3 files are mapped via :data:`ID3_TO_VORBIS` / :data:`TXXX_TO_VORBIS`.
    - M4A / AAC files are mapped via :data:`M4A_TO_VORBIS`.

    Multi-value strings (separated by :data:`MULTI_VALUE_SEPARATOR`) are split
    in all formats.  Formats that natively support repeated keys (FLAC) already
    return lists; those lists are also scanned for the separator.

    Cover-art frames / atoms are silently ignored.
    """

    suffix = source.suffix.lower()
    if suffix == ".flac":
        audio = FLAC(source)
        return _extract_flac_tags(audio)
    elif suffix in {".mp3"}:
        audio = ID3FileType(source)
        return _extract_id3_tags(audio)
    elif suffix in {".m4a", ".mp4", ".aac"}:
        audio = MP4(source)
        return _extract_m4a_tags(audio)
    else:
        logger.error(f"files of type {suffix} are not supported.")
        return {}


def _extract_flac_tags(tags: FLAC) -> VorbisDict:
    """Convert a mutagen Vorbis comment mapping to `VorbisDict`."""
    result: VorbisDict = {}
    for key, values in tags.items():
        norm_key = key.lower()
        flat: list[str] = []
        for v in values:
            flat.extend(_split_values(str(v)))
        if flat:
            result[norm_key] = flat
    return result


def _extract_id3_tags(audio: ID3FileType) -> VorbisDict:
    """Map ID3 frames from *audio* to a `VorbisDict`."""
    result: VorbisDict = {}
    if audio.tags is None:
        return result

    for frame in audio.tags.values():
        # e.g. "TIT2", "TXXX", "COMM"
        frame_id: str = frame.FrameID

        if frame_id == "TXXX":
            # User-defined text: look up description in TXXX_TO_VORBIS
            vorbis_key = TXXX_TO_VORBIS.get(frame.desc)
            if vorbis_key is None:
                logger.debug(
                    f"custom TXXX frame '{frame.desc}' is not mapped. Ignoring."
                )
                continue
            values = _split_values(str(frame.text[0]) if frame.text else "")
            if values:
                logger.debug(f"Setting tag {vorbis_key}={values} from {frame_id}")
                result.setdefault(vorbis_key, []).extend(values)

        elif frame_id in {"COMM", "USLT"}:
            # Only grab description-less (standard) comment / lyrics frames
            if frame.desc == "":
                vorbis_key = ID3_TO_VORBIS.get(frame_id, frame_id.lower())
                text = getattr(frame, "text", None) or getattr(frame, "lyrics", None)
                if text:
                    raw = str(text[0]) if isinstance(text, list) else str(text)
                    values = _split_values(raw)
                    if values:
                        logger.debug(
                            f"Setting tag {vorbis_key}={values} from {frame_id}"
                        )
                        result.setdefault(vorbis_key, []).extend(values)

        elif frame_id.startswith("T"):
            # Standard text frame
            vorbis_key = ID3_TO_VORBIS.get(frame_id)
            if vorbis_key is None:
                # Not mapped, so skip!
                logger.debug(
                    f"ID3v2 frame '{frame_id}' appears to be a standard type that is not mapped!"
                )
                continue
            text_list = getattr(frame, "text", [])
            for raw in text_list:
                values = _split_values(str(raw))
                logger.debug(f"Setting tag {vorbis_key}={values} from {frame_id}")
                result.setdefault(vorbis_key, []).extend(values)

        else:
            logger.debug(f"Intentionally ignoring ID3v2 field '{frame_id}' ")

    return result


def _extract_m4a_tags(audio: MP4) -> VorbisDict:
    """Map M4A atoms from *audio* to a :data:`VorbisDict`."""
    result: VorbisDict = {}
    if audio.tags is None:
        return result

    for atom_key, atom_val in audio.tags.items():
        vorbis_key = M4A_TO_VORBIS.get(atom_key)
        if vorbis_key is None:
            logger.debug(
                f"m4a atom {atom_key} does not have a mapping, discarding (value {atom_val})  "
            )
            continue

        # atom_val is typically a list; each element may be str, int, bytes,
        # or a mutagen.mp4.MP4FreeForm object.
        for item in atom_val if isinstance(atom_val, list) else [atom_val]:
            if isinstance(item, bytes):
                raw = item.decode("utf-8", errors="replace")
            elif hasattr(item, "decode"):
                # MP4FreeForm
                raw = bytes(item).decode("utf-8", errors="replace")
            elif isinstance(item, tuple):
                # trkn / disk atoms are (current, total) tuples
                raw = "/".join(str(x) for x in item if x)
            else:
                raw = str(item)
            result.setdefault(vorbis_key, []).extend(_split_values(raw))

    return result


def transcode_without_tags(
    source: Path,
    bitrate: str = "96k",
) -> Path:
    """
    Transcode *source* to Opus audio using ffmpeg, stripping **all** metadata.

    The output is written to a temporary file (platform-appropriate location).
    The temporary file is *not* deleted automatically; the caller is responsible
    for moving or removing it.

    Parameters
    ----------
    source:
        Input audio file.
    bitrate:
        Target Opus bitrate, e.g. ``"128k"`` or ``"96k"``.

    Returns
    -------
    Path
        Path to the temporary ``.opus`` file.

    Raises
    ------
    subprocess.CalledProcessError
        If ffmpeg exits with a non-zero return code.
    FileNotFoundError
        If ``ffmpeg`` is not found on PATH.
    """
    # NamedTemporaryFile with delete=False so we can pass the path to ffmpeg,
    # then hand the path back to the caller.
    tmp = tempfile.NamedTemporaryFile(
        suffix=".opus",
        delete=False,
    )
    tmp_path = Path(tmp.name)
    tmp.close()  # Close the handle; ffmpeg will write to the path.

    cmd: list[str] = [
        "ffmpeg",
        "-y",  # overwrite without asking
        "-i",
        str(source),  # input
        "-vn",  # no video / cover art stream
        "-map_metadata",
        "-1",  # strip ALL metadata, we re-add later
        "-c:a",
        "libopus",
        "-b:a",
        bitrate,
        str(tmp_path),
    ]

    subprocess.run(
        cmd,
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )

    return tmp_path


def write_tags(tags: VorbisDict, opus_path: Path) -> None:
    """
    Write *tags* to the Opus file at *opus_path* using mutagen's OggOpus.

    Each key in *tags* maps to a list of string values; mutagen stores them
    as repeated Vorbis comment fields, which is the canonical Opus way to
    represent multi-value tags.

    Parameters
    ----------
    tags:
        Mapping of lowercase Vorbis comment field names → list of values.
    opus_path:
        Path to an existing `.opus` file.
    """
    audio = OggOpus(opus_path)

    # OggOpus.tags is a VComment which behaves like a list of (key, value)
    # pairs.  Assigning a list directly sets all values for that key.
    for field, values in tags.items():
        audio[field] = values  # type: ignore[index]

    audio.save()


# Allow calling this module to process just a single file for testing purposes
if __name__ == "__main__":
    import sys

    if len(sys.argv) != 3:
        print("Usage: single_file.py <source> <target.opus>")
        sys.exit(1)

    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])
    convert_file(src, dst)
    print(f"Done: {dst}")
