#!/usr/bin/env python3
"""
syncbopy: Synchronise a music library to a target directory.

Usage:
    syncbopy <source> <target> [--bitrate 128k] [--workers 4]
"""

import argparse
import hashlib
import json
import logging
import shutil
import sys
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from syncbopy.single_file import convert_file


AUDIO_SUFFIXES = {".mp3", ".flac", ".m4a"}
COVER_NAMES = {"cover.jpg", "cover.png"}
HASH_DB_NAME = "syncbopy.json"


logger = logging.getLogger("syncbopy")


def _configure_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        format="%(asctime)s  %(levelname)-8s  %(message)s",
        datefmt="%H:%M:%S",
        level=level,
        stream=sys.stderr,
    )


# ---------------------------------------------------------------------------
# Hashing
# ---------------------------------------------------------------------------


def _file_hash(path: Path, chunk: int = 1 << 20) -> str:
    """Return the SHA-256 hex digest of *path*."""
    h = hashlib.sha256()
    with path.open("rb") as fh:
        while data := fh.read(chunk):
            h.update(data)
    return h.hexdigest()


# We store the previous hashes in a read-only map.
_db_lock = threading.Lock()


def _load_db(target_root: Path) -> dict:
    db_path = target_root / HASH_DB_NAME
    if db_path.exists():
        try:
            return json.loads(db_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("Could not read hash database (%s); starting fresh.", exc)
    return {}


def _save_db(target_root: Path, db: dict) -> None:
    db_path = target_root / HASH_DB_NAME
    tmp = db_path.with_suffix(".tmp")
    tmp.write_text(json.dumps(db, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(db_path)


def _db_key(source_root: Path, source_file: Path) -> str:
    """Stable, OS-independent key: relative POSIX path from the source root."""
    return source_file.relative_to(source_root).as_posix()


# ---------------------------------------------------------------------------
# Per-file sync logic
# ---------------------------------------------------------------------------


def _sync_audio(
    source_file: Path,
    source_root: Path,
    target_root: Path,
    bitrate: str,
    db: dict,
) -> str:
    """
    Sync one audio file.  Returns a short status string for the progress log.
    Raises on conversion failure (caller catches and logs).
    """
    rel = source_file.relative_to(source_root)
    key = rel.as_posix()
    target_f = target_root / rel.with_suffix(".opus")  # always store as opus

    target_f.parent.mkdir(parents=True, exist_ok=True)

    # Compute hash of the source file
    src_hash = _file_hash(source_file)

    with _db_lock:
        stored_hash = db.get(key)

    if stored_hash == src_hash and target_f.exists():
        return "skip"

    # Need to (re-)encode
    convert_file(source_file, target_f, bitrate=bitrate)

    with _db_lock:
        db[key] = src_hash
        _save_db(target_root, db)

    return "converted" if stored_hash else "new"


def _sync_cover(
    source_file: Path,
    source_root: Path,
    target_root: Path,
) -> str:
    """Copy a cover image if it is missing or differs from the source."""
    rel = source_file.relative_to(source_root)
    target_f = target_root / rel

    target_f.parent.mkdir(parents=True, exist_ok=True)

    if target_f.exists() and _file_hash(target_f) == _file_hash(source_file):
        return "skip"

    shutil.copy2(source_file, target_f)
    return "copied"


def _collect_files(source_root: Path):
    """Yield (path, kind) for every file we care about under *source_root*."""
    for path in sorted(source_root.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix.lower() in AUDIO_SUFFIXES:
            yield path, "audio"
        elif path.name.lower() in COVER_NAMES:
            yield path, "cover"


def syncbopy(
    source_root: Path,
    target_root: Path,
    bitrate: str = "128k",
    workers: int = 4,
) -> None:
    """Meat of the high-level program"""
    target_root.mkdir(parents=True, exist_ok=True)

    # Load hash DB once; all threads share it (guarded by _db_lock)
    db = _load_db(target_root)

    files = list(_collect_files(source_root))
    total = len(files)

    if total == 0:
        logger.info("No audio or cover files found in %s", source_root)
        return

    logger.info("Found %d file(s) to consider.  Workers: %d", total, workers)

    counts = {"skip": 0, "converted": 0, "new": 0, "copied": 0, "error": 0}
    done = 0
    cnt_lock = threading.Lock()

    def _progress(rel_path: str, status: str) -> None:
        nonlocal done
        with cnt_lock:
            counts[status] += 1
            done += 1
            pct = done * 100 // total
            logger.info(
                "[%3d%%  %4d/%4d]  %-10s %s", pct, done, total, status, rel_path
            )

    def _task(path: Path, kind: str):
        rel = path.relative_to(source_root).as_posix()
        try:
            if kind == "audio":
                status = _sync_audio(path, source_root, target_root, bitrate, db)
            else:
                status = _sync_cover(path, source_root, target_root)
            _progress(rel, status)
        except Exception as exc:
            # Log on a fresh line so the progress display is not garbled
            logger.error("Could not convert %s - %s: %s", rel, type(exc).__name__, exc)
            _progress(rel, "error")

    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(_task, p, k): (p, k) for p, k in files}
        for _ in as_completed(futures):
            pass  # progress is printed inside _task

    logger.info(
        "Done. new=%d  converted=%d  copied=%d  skipped=%d  errors=%d",
        counts["new"],
        counts["converted"],
        counts["copied"],
        counts["skip"],
        counts["error"],
    )


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="syncbopy",
        description="Synchronise a music library to a target directory in compressed OPUS format.",
    )
    p.add_argument("source", type=Path, help="Source library root directory")
    p.add_argument("target", type=Path, help="Target (device) library root directory")
    p.add_argument(
        "--bitrate",
        default="96k",
        help="Audio bitrate passed to convert_file (default: 96k)",
    )
    p.add_argument(
        "--workers",
        type=int,
        default=6,
        help="Number of parallel conversion threads (default: 6)",
    )
    p.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable DEBUG logging",
    )
    return p


def main():
    args = _build_parser().parse_args()
    _configure_logging(args.verbose)

    if not args.source.is_dir():
        logger.error(
            "Source path does not exist or is not a directory: %s", args.source
        )
        sys.exit(1)

    # Safeguard for if you mixed up the source and target destinations.
    # The source will not have a hash database.
    source_has_db = (args.source / HASH_DB_NAME).exists()
    target_has_db = args.target.is_dir() and (args.target / HASH_DB_NAME).exists()
    if source_has_db and not target_has_db:
        logger.error(
            "Found '%s' in the source directory (%s) but not in the target (%s). "
            "You may have swapped the arguments. "
            "Re-run with source and target in the correct order.",
            HASH_DB_NAME,
            args.source,
            args.target,
        )
        sys.exit(1)

    syncbopy(
        source_root=args.source.resolve(),
        target_root=args.target.resolve(),
        bitrate=args.bitrate,
        workers=args.workers,
    )


if __name__ == "__main__":
    main()
