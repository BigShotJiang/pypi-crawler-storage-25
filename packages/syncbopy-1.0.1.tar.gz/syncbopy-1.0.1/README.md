A simple python tool to (incrementally) synchronise a music library to a target directory in compressed OPUS format.

<div align="center">
  <img src="https://codeberg.org/aidavdw/syncbopy/raw/branch/main/syncbopy_mascot.webp" width=60% />
</div>

Do you have a mixed (FLAC, mp3, m4a, ogg) library of music?
Do you want to put it on your mobile device?
**syncbopy** helps you transcode it to OPUS, carry over tags, and synchronise your library it to your device.
On any consecutive runs, only files that have been changed will be updated. Unchanged files are not touched.

# How to use
As simple as can be.
```
syncbopy /path/to/your/music/library/ /path/to/sync/to/
```
`syncbopy` takes two main arguments:
First is a source library, which is the folder where you keep all your music (e.g. `~/Music/` on linux, or `C:/Users/<username>/Music` on windows). This folder will not be touched, it will just be read.
Then the target library, which is where you want to synchronise to (another folder on your computer, a folder on your phone).
You can optionally provide the amount of threads to use using `--workers`, or specify a target (average) bitrate using `--bitrate`.

For example: I have my music in `~/Music/`, and I have mounted my phone's storage at `/mnt/`. I use MTP, so I want to have my compressed music library at `/mnt/Internal\ shared\ storage\Music\portable`.
I want to run on 8 threads.
I would run the following command.
```
syncbopy --workers 8 ~/Music "/mnt/Internal shared storage/Music/portable"
```

# Features
- Converts from many file formats to OPUS.
- Hand-crafted tag conversion. Maps tags from one format to the other, supporting multiple artists etc.
- Supports incremental updates. No need to remove everything and sync from scratch, just sync what you changed!
- Resume after interrupt.
- Discards all embedded images to save space.
- Copies over external cover art (`cover.png`, `folder.jpg`, etc.)
- Respects folder structure of your library.


After every write operation, a cache with hashes is updated in the target directory.
Because of this, if the synchronisation is interrupted (cancel the script, device disconnected), the script can pick back up where it left off when you restart it.

# Installation
Very simple!
Make sure you have [FFmpeg](https://ffmpeg.org) installed.
You can install the program from PyPi using this:
```
# If you use pip
pip install syncbopy
# If you use uv
uv tool install syncbopy
```

Alternatively, you can run the code from source.
Get the code in this repository:
```
git clone https://codeberg.org/aidavdw/syncbopy
cd syncbopy
```

You can then install it, after which you can run it as stated above.
```
# If you use uv
uv tool install -e .
# If you use pip
pip install .
```

Alternatively, you can then run the program directly:
```
uv run syncbopy /path/to/music/library/ /path/to/sync/to/
```

## Dependencies
This program uses [ffmpeg](https://ffmpeg.org/) under the hood. It has been tested with version 4.4.2, but it should run with newer too.

# Why OPUS?
mp3 is great, but OPUS is greater. It's pretty well supported by most music player apps, and saves a lot more space for the same quality of audio.

# Roadmap
- Convert png/webp images to jpg on-the-fly
- Handle deleting songs in the source library
- Sync playlists (.m3u etc)
