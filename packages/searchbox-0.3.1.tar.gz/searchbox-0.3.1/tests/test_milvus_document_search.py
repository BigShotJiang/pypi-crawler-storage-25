from searchbox import MilvusDocumentSearch


class _FakeMilvusClient:
    def __init__(self):
        self.closed = False
        self.calls = []

    def search_chunks(self, **kwargs):
        self.calls.append(kwargs)
        return {
            "query": kwargs["query"],
            "file_path": kwargs["file_path"],
            "results": [
                {
                    "file_path": kwargs["file_path"],
                    "title": "manual.pdf",
                    "chunk_id": 3,
                    "start_offset": 120,
                    "end_offset": 240,
                    "score": 0.91,
                    "content": "This section explains how chunk overlap improves recall.",
                },
                {
                    "file_path": kwargs["file_path"],
                    "title": "manual.pdf",
                    "chunk_id": 8,
                    "start_offset": 360,
                    "end_offset": 480,
                    "score": 0.74,
                    "content": "This later section discusses reranking details.",
                },
            ],
        }

    def close(self):
        self.closed = True


def test_milvus_document_search_returns_chunk_level_hits():
    client = _FakeMilvusClient()
    search = MilvusDocumentSearch(
        user_id="alice",
        file_path="/docs/manual.pdf",
        collection="longdoc_index",
        client=client,
        default_top_k=2,
    )

    results = search.search("chunk overlap", top_k=1)

    assert len(results) == 1
    assert results[0]["id"] == "/docs/manual.pdf#3"
    assert results[0]["metadata"]["chunk_id"] == 3
    assert results[0]["metadata"]["start_offset"] == 120
    assert client.calls[0]["collection"] == "longdoc_index"
    assert client.calls[0]["file_path"] == "/docs/manual.pdf"

    pretty = search.search_pretty("chunk overlap", top_k=1, snippet_length=24)

    assert pretty[0]["path"] == "/docs/manual.pdf"
    assert pretty[0]["chunk_id"] == 3
    assert pretty[0]["snippet"].endswith("...")
def test_milvus_document_search_owns_its_client_when_created_directly():
    client = _FakeMilvusClient()
    document = MilvusDocumentSearch(
        user_id="alice",
        file_path="/docs/manual.pdf",
        collection="longdoc_index",
        client=client,
    )

    assert document.file_path == "/docs/manual.pdf"

    # Injected clients stay owned by the caller.
    document.close()
    assert client.closed is False
