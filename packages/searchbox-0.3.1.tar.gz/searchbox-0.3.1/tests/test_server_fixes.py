from searchbox.server.service import KnowledgeService
from searchbox.server.providers.mock import MockEmbedder, MockReranker


class _FakeStore:
    def __init__(self):
        self.deleted = []
        self.inserted = []

    def delete_by_file(self, *, user_id: str, file_path: str):
        self.deleted.append((user_id, file_path))
        return 0

    def insert_chunks(self, *, user_id: str, file_path: str, title: str, chunks):
        self.inserted.append((user_id, file_path, title, chunks))
        return len(chunks)


def test_ingest_replaces_previous_file_contents():
    store = _FakeStore()
    service = KnowledgeService(
        store=store,
        embedder=MockEmbedder(dim=8),
        reranker=MockReranker(dim=8),
        default_chunk_max_chars=2000,
        default_chunk_overlap=200,
    )

    result = service.ingest(
        user_id="alice",
        files=[{"file_path": "doc.txt", "text": "hello world", "metadata": {"title": "Doc"}}],
    )

    assert result[0]["inserted"] == 1
    assert store.deleted == [("alice", "doc.txt")]
    assert store.inserted[0][1] == "doc.txt"
