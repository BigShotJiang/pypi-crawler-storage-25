from __future__ import annotations

import json
import re
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from fastapi import Body, FastAPI, HTTPException
from pydantic import BaseModel, Field

from .chunking import split_text as _split_text  # noqa: F401 (ensures chunking is importable)
from .store import (
    MilvusStore, PaperStore, CustomStore,
    CustomFieldDef, FIELD_TYPE_MAP, INDEX_TYPE_DENSE, INDEX_TYPE_BM25, MAX_INDEXES,
)
from .providers.base import Embedder, Reranker
from .providers.dashscope_qwen import DashScopeQwenEmbedder, DashScopeQwenReranker
from .providers.local_qwen import LocalQwenEmbedder, LocalQwenReranker
from .providers.vllm_qwen import VLLMQwenEmbedder, VLLMQwenReranker
from .providers.mock import MockEmbedder, MockReranker
from .service import KnowledgeService, PaperService


@dataclass
class ServerSettings:
    milvus_uri: str = "./milvus_local.db"
    milvus_token: str = ""
    milvus_db_name: str = "default"
    milvus_collection: str = "knowledge"
    embed_provider: str = "mock"
    rerank_provider: str = "mock"
    embed_dim: int = 1024
    metric_type: str = "IP"
    default_chunk_max_chars: int = 2000
    default_chunk_overlap: int = 200
    # vLLM settings
    vllm_embed_base_url: str = "http://127.0.0.1:8806"
    vllm_embed_model: str = "Qwen/Qwen3-Embedding-0.6B"
    vllm_embed_api_key: str = ""
    vllm_rerank_base_url: str = "http://127.0.0.1:8807"
    vllm_rerank_model: str = "Qwen/Qwen3-Reranker-4B"
    vllm_rerank_api_key: str = ""
    vllm_timeout: float = 60.0
    # Local model settings
    local_embed_model: str = "Qwen/Qwen3-Embedding-0.6B"
    local_embed_batch_size: int = 32
    local_embed_max_length: int = 8192
    local_rerank_model: str = "Qwen/Qwen3-Reranker-4B"
    # DashScope settings
    dashscope_api_key: str = ""
    qwen_embed_model: str = "text-embedding-v3"
    qwen_rerank_model: str = "gte-rerank"


def _build_embedder(s: ServerSettings) -> Embedder:
    provider = s.embed_provider.lower()
    if provider == "vllm":
        return VLLMQwenEmbedder(base_url=s.vllm_embed_base_url, model_name=s.vllm_embed_model,
                                dim=s.embed_dim, api_key=s.vllm_embed_api_key, timeout=s.vllm_timeout)
    if provider == "local":
        return LocalQwenEmbedder(model_name=s.local_embed_model, dim=s.embed_dim,
                                 batch_size=s.local_embed_batch_size, max_length=s.local_embed_max_length)
    if provider == "dashscope":
        return DashScopeQwenEmbedder(api_key=s.dashscope_api_key, model=s.qwen_embed_model, dim=s.embed_dim)
    if provider == "mock":
        return MockEmbedder(dim=s.embed_dim)
    raise ValueError(f"Invalid embed_provider={provider!r}. Must be 'vllm', 'local', 'dashscope', or 'mock'.")


def _build_reranker(s: ServerSettings) -> Reranker:
    provider = s.rerank_provider.lower()
    if provider == "vllm":
        return VLLMQwenReranker(base_url=s.vllm_rerank_base_url, model_name=s.vllm_rerank_model,
                                api_key=s.vllm_rerank_api_key, timeout=s.vllm_timeout)
    if provider == "local":
        return LocalQwenReranker(model_name=s.local_rerank_model, max_length=s.local_embed_max_length)
    if provider == "dashscope":
        return DashScopeQwenReranker(api_key=s.dashscope_api_key, model=s.qwen_rerank_model)
    if provider == "mock":
        return MockReranker(dim=s.embed_dim)
    raise ValueError(f"Invalid rerank_provider={provider!r}. Must be 'vllm', 'local', 'dashscope', or 'mock'.")


def create_app(settings: ServerSettings | None = None) -> FastAPI:
    s = settings or ServerSettings()

    app = FastAPI(title="Searchbox Knowledge Server", version="1.0.0")

    _services: dict[str, KnowledgeService] = {}
    _expiry: dict[str, float | None] = {}
    _paper_services: dict[str, PaperService] = {}
    _paper_collections: set[str] = set()
    _embedder = _build_embedder(s)
    _reranker = _build_reranker(s)
    _metadata_path = Path(".searchbox_server_state.json")

    def _load_metadata() -> None:
        nonlocal _paper_collections
        try:
            raw = json.loads(_metadata_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        except Exception:
            return
        expiry = raw.get("expiry", {})
        if isinstance(expiry, dict):
            cleaned: dict[str, float | None] = {}
            for name, value in expiry.items():
                if not isinstance(name, str) or not name:
                    continue
                if value is None:
                    cleaned[name] = None
                else:
                    try:
                        cleaned[name] = float(value)
                    except (TypeError, ValueError):
                        continue
            _expiry.update(cleaned)
        papers = raw.get("paper_collections", [])
        if isinstance(papers, list):
            _paper_collections = {str(name) for name in papers if str(name)}

    def _save_metadata() -> None:
        payload = {
            "expiry": _expiry,
            "paper_collections": sorted(_paper_collections),
        }
        try:
            _metadata_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _build_service(collection_name: str) -> KnowledgeService:
        store = MilvusStore(uri=s.milvus_uri, token=s.milvus_token, db_name=s.milvus_db_name,
                            collection_name=collection_name, dim=s.embed_dim, metric_type=s.metric_type)
        return KnowledgeService(store=store, embedder=_embedder, reranker=_reranker,
                                default_chunk_max_chars=s.default_chunk_max_chars,
                                default_chunk_overlap=s.default_chunk_overlap)

    def _build_paper_service(volume_collection: str) -> PaperService:
        store = PaperStore(uri=s.milvus_uri, token=s.milvus_token, db_name=s.milvus_db_name,
                           collection_name=volume_collection, dim=s.embed_dim)
        return PaperService(store=store, embedder=_embedder)

    def _make_custom_store(name: str) -> CustomStore:
        return CustomStore(uri=s.milvus_uri, token=s.milvus_token,
                           db_name=s.milvus_db_name, collection_name=name)

    def _evict_expired() -> None:
        now = time.time()
        expired = [name for name, exp in _expiry.items() if exp is not None and now >= exp]
        for name in expired:
            try:
                svc = _services.get(name) or _build_service(name)
                svc.drop_collection()
            except Exception:
                continue
            _services.pop(name, None)
            _expiry.pop(name, None)
        if expired:
            _save_metadata()

    def get_service(collection: str | None = None) -> KnowledgeService:
        _evict_expired()
        name = collection or s.milvus_collection
        if name not in _services:
            try:
                _services[name] = _build_service(name)
            except Exception as e:
                raise RuntimeError(f"Failed to initialize KnowledgeService for {name!r}: {e}") from e
        return _services[name]

    def _require_collection(name: str) -> KnowledgeService:
        _evict_expired()
        if name not in _services:
            try:
                svc = _build_service(name)
                if not svc._store.collection_exists():
                    raise HTTPException(status_code=404, detail=f"Collection {name!r} not found.")
                _services[name] = svc
            except HTTPException:
                raise
            except Exception as e:
                raise HTTPException(status_code=404, detail=f"Collection {name!r} not found. {e}")
        return _services[name]

    def get_paper_service(volume: str) -> PaperService:
        if volume not in _paper_services:
            try:
                _paper_services[volume] = _build_paper_service(volume)
            except Exception as e:
                raise RuntimeError(f"Failed to initialize PaperService for {volume!r}: {e}") from e
        _paper_collections.add(volume)
        return _paper_services[volume]

    def _require_paper_service(col: str) -> PaperService:
        if col not in _paper_services:
            try:
                svc = _build_paper_service(col)
                if not svc._store.collection_exists():
                    raise HTTPException(status_code=404, detail=f"Volume collection {col!r} not found.")
                _paper_services[col] = svc
            except HTTPException:
                raise
            except Exception as e:
                raise HTTPException(status_code=404, detail=f"Volume collection {col!r} not found. {e}")
        _paper_collections.add(col)
        return _paper_services[col]

    def _volume_collection(volume: str) -> str:
        return "paper_" + re.sub(r"[^a-zA-Z0-9]", "_", volume).strip("_").lower()

    # ── Startup recovery ───────────────────────────────────────────────────────

    @app.on_event("startup")
    def _recover_state() -> None:
        _load_metadata()
        try:
            probe = MilvusStore(uri=s.milvus_uri, token=s.milvus_token, db_name=s.milvus_db_name,
                                collection_name="_probe", dim=s.embed_dim, metric_type=s.metric_type)
            probe.connect()
            from pymilvus import utility
            all_cols = utility.list_collections()
        except Exception:
            return
        for col in all_cols:
            if col.startswith("paper_"):
                _paper_collections.add(col)
            else:
                if col != s.milvus_collection and col not in _expiry:
                    _expiry[col] = None
        _paper_collections.intersection_update(all_cols)
        _expiry_keys = list(_expiry.keys())
        for name in _expiry_keys:
            if name != s.milvus_collection and name not in all_cols:
                _expiry.pop(name, None)
        _save_metadata()

    # ── Collections ────────────────────────────────────────────────────────────

    class CreateCollectionRequest(BaseModel):
        name: str | None = Field(default=None, min_length=1, max_length=128, pattern=r"^[a-zA-Z0-9_]+$")
        temporary: bool = Field(default=True)
        ttl_hours: float = Field(default=24.0, ge=1.0, le=720.0)

    class CollectionInfo(BaseModel):
        name: str
        temporary: bool
        expires_at: float | None = None
        ttl_remaining_seconds: float | None = None

    class RenewCollectionRequest(BaseModel):
        ttl_hours: float = Field(default=24.0, ge=1.0, le=720.0)

    @app.post("/collections", response_model=CollectionInfo, status_code=201)
    def create_collection(req: dict[str, Any] = Body(...)) -> CollectionInfo:
        req = CreateCollectionRequest.model_validate(req)
        _evict_expired()
        name = req.name or f"tmp_{uuid.uuid4().hex[:12]}"
        if name == s.milvus_collection:
            raise HTTPException(status_code=400, detail=f"Cannot create collection with default name {name!r}.")
        if name in _services and name in _expiry and _expiry[name] is not None:
            exp = _expiry[name]
            assert exp is not None
            return CollectionInfo(name=name, temporary=True, expires_at=exp,
                                  ttl_remaining_seconds=max(0.0, exp - time.time()))
        expires_at: float | None = None
        if req.temporary:
            expires_at = time.time() + req.ttl_hours * 3600
            _expiry[name] = expires_at
        else:
            _expiry[name] = None
        get_service(name)
        _save_metadata()
        return CollectionInfo(name=name, temporary=req.temporary, expires_at=expires_at,
                              ttl_remaining_seconds=max(0.0, expires_at - time.time()) if expires_at else None)

    @app.get("/collections", response_model=list[CollectionInfo])
    def list_collections() -> list[CollectionInfo]:
        _evict_expired()
        now = time.time()
        result = [CollectionInfo(name=s.milvus_collection, temporary=False)]
        for name, exp in sorted(_expiry.items()):
            if name == s.milvus_collection:
                continue
            result.append(CollectionInfo(name=name, temporary=exp is not None, expires_at=exp,
                                         ttl_remaining_seconds=max(0.0, exp - now) if exp is not None else None))
        return result

    @app.get("/collections/{name}", response_model=CollectionInfo)
    def get_collection(name: str) -> CollectionInfo:
        _evict_expired()
        now = time.time()
        if name == s.milvus_collection:
            return CollectionInfo(name=name, temporary=False)
        if name not in _expiry:
            _require_collection(name)
            _expiry[name] = None
            _save_metadata()
            return CollectionInfo(name=name, temporary=False)
        exp = _expiry[name]
        return CollectionInfo(name=name, temporary=exp is not None, expires_at=exp,
                              ttl_remaining_seconds=max(0.0, exp - now) if exp is not None else None)

    @app.patch("/collections/{name}", response_model=CollectionInfo)
    def renew_collection(name: str, req: dict[str, Any] = Body(...)) -> CollectionInfo:
        req = RenewCollectionRequest.model_validate(req)
        _evict_expired()
        if name == s.milvus_collection:
            raise HTTPException(status_code=400, detail="Cannot set TTL on the default collection.")
        if name not in _expiry:
            raise HTTPException(status_code=404, detail=f"Collection {name!r} not found.")
        expires_at = time.time() + req.ttl_hours * 3600
        _expiry[name] = expires_at
        _save_metadata()
        return CollectionInfo(name=name, temporary=True, expires_at=expires_at,
                              ttl_remaining_seconds=req.ttl_hours * 3600)

    @app.delete("/collections/{name}")
    def delete_collection(name: str) -> dict[str, Any]:
        svc = _require_collection(name)
        try:
            svc.drop_collection()
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Drop failed: {e}") from e
        _services.pop(name, None)
        _expiry.pop(name, None)
        _save_metadata()
        return {"dropped": True, "collection": name}

    @app.delete("/collection")
    def drop_collection_legacy(collection: str | None = None) -> dict[str, Any]:
        name = collection or s.milvus_collection
        try:
            svc = get_service(name)
            svc.drop_collection()
            _services.pop(name, None)
            _expiry.pop(name, None)
            _save_metadata()
            return {"dropped": True, "collection": name}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Drop failed: {e}") from e

    @app.get("/collections/{name}/users")
    def list_collection_users(name: str) -> dict[str, Any]:
        svc = _require_collection(name)
        try:
            users = svc._store.list_users()
            return {"collection": name, "user_count": len(users), "users": users}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed: {e}") from e

    @app.delete("/collections/{name}/users/{user_id}")
    def delete_collection_user(name: str, user_id: str) -> dict[str, Any]:
        svc = _require_collection(name)
        try:
            deleted = svc._store.delete_user(user_id=user_id)
            return {"collection": name, "user_id": user_id, "deleted": deleted}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed: {e}") from e

    # ── Ingest ─────────────────────────────────────────────────────────────────

    class ChunkConfig(BaseModel):
        max_chars: int = Field(default=2000, ge=200, le=60000)
        overlap: int = Field(default=200, ge=0, le=20000)

    class FileItem(BaseModel):
        file_path: str = Field(min_length=1, max_length=1024)
        text: str = Field(min_length=1, max_length=10_000_000)
        metadata: dict[str, Any] | None = None

    class IngestRequest(BaseModel):
        user_id: str = Field(min_length=1, max_length=256)
        files: list[FileItem] = Field(min_length=1)
        chunk: ChunkConfig | None = None
        collection: str | None = Field(default=None, min_length=1, max_length=128)

    class FileIngestResult(BaseModel):
        file_path: str
        inserted: int
        chunk_count: int

    class IngestResponse(BaseModel):
        collection: str
        results: list[FileIngestResult]

    @app.post("/ingest", response_model=IngestResponse)
    def ingest(req: dict[str, Any] = Body(...)) -> IngestResponse:
        req = IngestRequest.model_validate(req)
        try:
            svc = get_service(req.collection)
            results = svc.ingest(user_id=req.user_id, files=[f.model_dump() for f in req.files],
                                 chunk_max_chars=req.chunk.max_chars if req.chunk else None,
                                 chunk_overlap=req.chunk.overlap if req.chunk else None)
            name = req.collection or s.milvus_collection
            return IngestResponse(collection=name, results=[FileIngestResult(**r) for r in results])
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Ingest failed: {e}") from e

    # ── Search ─────────────────────────────────────────────────────────────────

    class SearchRequest(BaseModel):
        user_id: str = Field(min_length=1, max_length=256)
        query: str = Field(min_length=1, max_length=10000)
        recall_top_p: int = Field(default=20, ge=1, le=200)
        top_k: int = Field(default=5, ge=1, le=50)
        include_content: bool = Field(default=False)
        score_threshold: float | None = Field(default=None, ge=0.0, le=1.0)
        file_paths: list[str] | None = Field(default=None, max_length=200)
        collection: str | None = Field(default=None, min_length=1, max_length=128)

    class FileSearchHit(BaseModel):
        file_path: str
        score: float
        content: str | None = None

    class SearchResponse(BaseModel):
        query: str
        collection: str
        results: list[FileSearchHit]

    @app.post("/search", response_model=SearchResponse)
    def search(req: dict[str, Any] = Body(...)) -> SearchResponse:
        req = SearchRequest.model_validate(req)
        try:
            svc = get_service(req.collection)
            res = svc.search(user_id=req.user_id, query=req.query, recall_top_p=req.recall_top_p,
                             top_k=req.top_k, include_content=req.include_content,
                             score_threshold=req.score_threshold, file_paths=req.file_paths)
            name = req.collection or s.milvus_collection
            return SearchResponse(collection=name, **res)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Search failed: {e}") from e

    class DocumentSearchRequest(BaseModel):
        user_id: str = Field(min_length=1, max_length=256)
        file_path: str = Field(min_length=1, max_length=1024)
        query: str = Field(min_length=1, max_length=10000)
        recall_top_p: int = Field(default=20, ge=1, le=200)
        top_k: int = Field(default=5, ge=1, le=100)
        score_threshold: float | None = Field(default=None, ge=0.0, le=1.0)
        collection: str | None = Field(default=None, min_length=1, max_length=128)

    class DocumentSearchHit(BaseModel):
        file_path: str
        title: str
        chunk_id: int
        start_offset: int
        end_offset: int
        score: float
        content: str

    class DocumentSearchResponse(BaseModel):
        query: str
        collection: str
        file_path: str
        results: list[DocumentSearchHit]

    @app.post("/search/chunks", response_model=DocumentSearchResponse)
    def search_chunks(req: dict[str, Any] = Body(...)) -> DocumentSearchResponse:
        req = DocumentSearchRequest.model_validate(req)
        try:
            svc = get_service(req.collection)
            res = svc.search_chunks(user_id=req.user_id, file_path=req.file_path, query=req.query,
                                    recall_top_p=req.recall_top_p, top_k=req.top_k,
                                    score_threshold=req.score_threshold)
            name = req.collection or s.milvus_collection
            return DocumentSearchResponse(collection=name, **res)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Document search failed: {e}") from e

    # ── File management ────────────────────────────────────────────────────────

    class DeleteFileRequest(BaseModel):
        user_id: str = Field(min_length=1, max_length=256)
        file_path: str = Field(min_length=1, max_length=1024)
        collection: str | None = Field(default=None, min_length=1, max_length=128)

    @app.get("/files")
    def list_files(user_id: str, collection: str | None = None) -> dict[str, Any]:
        if not user_id:
            raise HTTPException(status_code=422, detail="user_id is required")
        try:
            svc = get_service(collection)
            files = svc.list_files(user_id=user_id)
            name = collection or s.milvus_collection
            return {"collection": name, "user_id": user_id, "files": files, "count": len(files)}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"List files failed: {e}") from e

    @app.delete("/files")
    def delete_file(req: dict[str, Any] = Body(...)) -> dict[str, Any]:
        req = DeleteFileRequest.model_validate(req)
        try:
            svc = get_service(req.collection)
            deleted = svc.delete_file(user_id=req.user_id, file_path=req.file_path)
            return {"file_path": req.file_path, "deleted": deleted}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Delete failed: {e}") from e

    @app.get("/chunks")
    def list_chunks(user_id: str, file_path: str, collection: str | None = None) -> dict[str, Any]:
        if not user_id or not file_path:
            raise HTTPException(status_code=422, detail="user_id and file_path are required")
        try:
            svc = get_service(collection)
            chunks = svc._store.list_chunks(user_id=user_id, file_path=file_path)
            name = collection or s.milvus_collection
            return {"collection": name, "user_id": user_id, "file_path": file_path,
                    "chunk_count": len(chunks), "chunks": chunks}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"List chunks failed: {e}") from e

    # ── Papers ─────────────────────────────────────────────────────────────────

    class CreateVolumeRequest(BaseModel):
        volume: str = Field(min_length=1, max_length=128)

    class VolumeInfo(BaseModel):
        volume: str
        collection: str
        num_papers: int | None = None

    class PaperItem(BaseModel):
        file_path: str = Field(min_length=1, max_length=1024)
        title: str = Field(min_length=1, max_length=1024)
        abstract: str = Field(min_length=1, max_length=65535)
        metadata: dict[str, Any] | None = None

    class PaperIngestRequest(BaseModel):
        volume: str = Field(min_length=1, max_length=128)
        papers: list[PaperItem] = Field(min_length=1)

    class PaperIngestResponse(BaseModel):
        volume: str
        collection: str
        inserted: int

    class PaperSearchRequest(BaseModel):
        volume: str = Field(min_length=1, max_length=128)
        query: str = Field(min_length=1, max_length=10000)
        top_k: int = Field(default=10, ge=1, le=100)
        score_threshold: float | None = Field(default=None, ge=0.0, le=1.0)

    class PaperSearchHitModel(BaseModel):
        file_path: str
        title: str
        score: float
        metadata: dict[str, Any]

    class PaperSearchResponse(BaseModel):
        query: str
        volume: str
        results: list[PaperSearchHitModel]

    class DeletePaperRequest(BaseModel):
        volume: str = Field(min_length=1, max_length=128)
        file_path: str = Field(min_length=1, max_length=1024)

    @app.post("/papers/collections", response_model=VolumeInfo, status_code=201)
    def create_volume(req: dict[str, Any] = Body(...)) -> VolumeInfo:
        req = CreateVolumeRequest.model_validate(req)
        col = _volume_collection(req.volume)
        try:
            svc = get_paper_service(col)
            svc.ensure_volume()
            _paper_collections.add(col)
            _save_metadata()
            return VolumeInfo(volume=req.volume, collection=col)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Create volume failed: {e}") from e

    @app.get("/papers/collections", response_model=list[VolumeInfo])
    def list_volumes() -> list[VolumeInfo]:
        return [VolumeInfo(volume=col.removeprefix("paper_").replace("_", " ").title(), collection=col)
                for col in sorted(_paper_collections)]

    @app.get("/papers/collections/{volume}", response_model=VolumeInfo)
    def get_volume(volume: str) -> VolumeInfo:
        col = _volume_collection(volume)
        svc = _require_paper_service(col)
        try:
            stats = svc._store.collection_stats()
            return VolumeInfo(volume=volume, collection=col, num_papers=stats["num_entities"])
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed: {e}") from e

    @app.delete("/papers/collections/{volume}")
    def delete_volume(volume: str) -> dict[str, Any]:
        col = _volume_collection(volume)
        svc = _require_paper_service(col)
        try:
            svc._store.drop_collection()
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Drop failed: {e}") from e
        _paper_services.pop(col, None)
        _paper_collections.discard(col)
        _save_metadata()
        return {"dropped": True, "volume": volume, "collection": col}

    @app.post("/papers/ingest", response_model=PaperIngestResponse)
    def ingest_papers(req: dict[str, Any] = Body(...)) -> PaperIngestResponse:
        req = PaperIngestRequest.model_validate(req)
        col = _volume_collection(req.volume)
        try:
            svc = get_paper_service(col)
            svc.ensure_volume()
            inserted = svc.ingest_papers(papers=[p.model_dump() for p in req.papers])
            return PaperIngestResponse(volume=req.volume, collection=col, inserted=inserted)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Paper ingest failed: {e}") from e

    @app.delete("/papers/files")
    def delete_paper(req: dict[str, Any] = Body(...)) -> dict[str, Any]:
        req = DeletePaperRequest.model_validate(req)
        col = _volume_collection(req.volume)
        svc = _require_paper_service(col)
        try:
            deleted = svc._store.delete_paper(file_path=req.file_path)
            return {"volume": req.volume, "file_path": req.file_path, "deleted": deleted}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Delete paper failed: {e}") from e

    @app.post("/papers/search", response_model=PaperSearchResponse)
    def search_papers(req: dict[str, Any] = Body(...)) -> PaperSearchResponse:
        req = PaperSearchRequest.model_validate(req)
        col = _volume_collection(req.volume)
        try:
            svc = get_paper_service(col)
            results = svc.search_papers(query=req.query, top_k=req.top_k, score_threshold=req.score_threshold)
            return PaperSearchResponse(query=req.query, volume=req.volume,
                                       results=[PaperSearchHitModel(**r) for r in results])
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Paper search failed: {e}") from e

    # ── Health ─────────────────────────────────────────────────────────────────

    @app.get("/health")
    def health() -> dict[str, Any]:
        _evict_expired()
        return {"ok": True, "version": "1.0.0", "default_collection": s.milvus_collection,
                "embed_provider": s.embed_provider, "rerank_provider": s.rerank_provider,
                "active_collections": len(_services), "active_volumes": len(_paper_services)}

    # ── Admin ──────────────────────────────────────────────────────────────────

    @app.get("/admin/collections")
    def admin_list_collections() -> dict[str, Any]:
        from pymilvus import utility
        try:
            svc = get_service()
            svc._store.connect()
            all_cols = utility.list_collections()
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to list collections: {e}") from e
        user_cols = [c for c in sorted(all_cols) if not c.startswith("paper_")]
        paper_cols = [c for c in sorted(all_cols) if c.startswith("paper_")]
        return {"total": len(all_cols), "user_collections": user_cols, "paper_collections": paper_cols}

    @app.get("/admin/collection/stats")
    def admin_collection_stats(collection: str | None = None) -> dict[str, Any]:
        try:
            svc = get_service(collection)
            stats = svc._store.admin_collection_stats()
            name = collection or s.milvus_collection
            return {"collection": name, **stats}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Stats failed: {e}") from e

    @app.get("/admin/files")
    def admin_list_files(collection: str | None = None) -> dict[str, Any]:
        try:
            svc = get_service(collection)
            files = svc._store.admin_list_all_files()
            name = collection or s.milvus_collection
            return {"collection": name, "count": len(files), "files": files}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Admin list files failed: {e}") from e

    @app.get("/admin/papers")
    def admin_list_papers(volume: str, limit: int = 1000) -> dict[str, Any]:
        col = _volume_collection(volume)
        try:
            svc = get_paper_service(col)
            papers = svc._store.admin_list_papers(limit=limit)
            return {"volume": volume, "collection": col, "count": len(papers), "papers": papers}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Admin list papers failed: {e}") from e

    # ── Custom collections ─────────────────────────────────────────────────────

    class CustomFieldRequest(BaseModel):
        name: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z_][a-zA-Z0-9_]*$")
        field_type: str = Field(description=f"One of: {', '.join(FIELD_TYPE_MAP.keys())}")
        is_primary: bool = False
        auto_id: bool = False
        max_length: int = Field(default=65535, ge=1, le=65535)
        dim: int = Field(default=1024, ge=1, le=32768)
        index_type: str | None = Field(default=None)
        default_value: Any = None

    class CreateCustomCollectionRequest(BaseModel):
        name: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z0-9_]+$")
        fields: list[CustomFieldRequest] = Field(min_length=2)

    @app.post("/custom-collections", status_code=201)
    def create_custom_collection(req: dict[str, Any] = Body(...)) -> dict[str, Any]:
        req = CreateCustomCollectionRequest.model_validate(req)
        store = _make_custom_store(req.name)
        try:
            field_defs = [CustomFieldDef(name=f.name, field_type=f.field_type, is_primary=f.is_primary,
                                         auto_id=f.auto_id, max_length=f.max_length, dim=f.dim,
                                         index_type=f.index_type.upper() if f.index_type else None,
                                         default_value=f.default_value) for f in req.fields]
            store.create(fields=field_defs)
        except ValueError as e:
            raise HTTPException(status_code=422, detail=str(e))
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Create failed: {e}") from e
        return store.describe()

    @app.get("/custom-collections/{name}")
    def describe_custom_collection(name: str) -> dict[str, Any]:
        store = _make_custom_store(name)
        if not store.collection_exists():
            raise HTTPException(status_code=404, detail=f"Collection {name!r} not found.")
        try:
            return store.describe()
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Describe failed: {e}") from e

    @app.delete("/custom-collections/{name}")
    def drop_custom_collection(name: str) -> dict[str, Any]:
        store = _make_custom_store(name)
        if not store.collection_exists():
            raise HTTPException(status_code=404, detail=f"Collection {name!r} not found.")
        try:
            store.drop()
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Drop failed: {e}") from e
        _services.pop(name, None)
        _expiry.pop(name, None)
        return {"dropped": True, "collection": name}

    return app
