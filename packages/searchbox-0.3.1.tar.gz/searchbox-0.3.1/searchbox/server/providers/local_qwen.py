from __future__ import annotations

import math

from .base import Embedder, RerankItem, Reranker


def _l2_normalize(vec: list[float]) -> list[float]:
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


def _log_softmax_pair(a: float, b: float) -> tuple[float, float]:
    m = max(a, b)
    ea, eb = math.exp(a - m), math.exp(b - m)
    t = ea + eb
    return ea / t, eb / t


class LocalQwenEmbedder(Embedder):
    def __init__(self, *, model_name: str, dim: int, batch_size: int = 32, max_length: int = 8192) -> None:
        self._dim = int(dim)
        self._batch_size = int(batch_size)
        self._max_length = int(max_length)
        try:
            import torch
            from transformers import AutoModel, AutoTokenizer
        except ImportError as e:
            raise ImportError(
                "Local provider requires: pip install transformers torch accelerate"
            ) from e
        self._torch = torch
        self._device = "cuda" if torch.cuda.is_available() else "cpu"
        self._tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        self._model = AutoModel.from_pretrained(model_name, trust_remote_code=True).to(self._device)
        self._model.eval()

    def embed(self, texts: list[str]) -> list[list[float]]:
        torch = self._torch
        all_vecs: list[list[float]] = []
        for i in range(0, len(texts), self._batch_size):
            batch = texts[i: i + self._batch_size]
            encoded = self._tokenizer(batch, padding=True, truncation=True,
                                      max_length=self._max_length, return_tensors="pt").to(self._device)
            with torch.no_grad():
                outputs = self._model(**encoded)
            hidden = outputs.last_hidden_state
            mask = encoded["attention_mask"].unsqueeze(-1).float()
            pooled = ((hidden * mask).sum(dim=1) / mask.sum(dim=1).clamp(min=1.0)).cpu().tolist()
            for vec in pooled:
                if len(vec) != self._dim:
                    raise RuntimeError(f"Model output dim {len(vec)} != expected {self._dim}")
                all_vecs.append(_l2_normalize(vec))
        return all_vecs


class LocalQwenReranker(Reranker):
    _PROMPT = (
        "<|im_start|>system\nJudge whether the Document meets the requirements based on the Query and the Instruct provided. "
        'Note that the answer can only be "yes" or "no".<|im_end|>\n'
        "<|im_start|>user\nInstruct: Given a web search query, retrieve relevant passages that answer the query.\n"
        "Query: {query}\nDocument: {document}<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"
    )

    def __init__(self, *, model_name: str, max_length: int = 8192) -> None:
        self._max_length = int(max_length)
        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except ImportError as e:
            raise ImportError("Local provider requires: pip install transformers torch accelerate") from e
        self._torch = torch
        self._device = "cuda" if torch.cuda.is_available() else "cpu"
        dtype = torch.float16 if torch.cuda.is_available() else torch.float32
        self._tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
        self._model = AutoModelForCausalLM.from_pretrained(
            model_name, trust_remote_code=True, torch_dtype=dtype).to(self._device)
        self._model.eval()
        self._yes_id = self._tokenizer.convert_tokens_to_ids("yes")
        self._no_id = self._tokenizer.convert_tokens_to_ids("no")

    def _score_pair(self, query: str, document: str) -> float:
        prompt = self._PROMPT.format(query=query, document=document)
        inputs = self._tokenizer(prompt, return_tensors="pt", truncation=True,
                                 max_length=self._max_length).to(self._device)
        with self._torch.no_grad():
            logits = self._model(**inputs).logits
        last = logits[0, -1, :]
        yes_prob, _ = _log_softmax_pair(float(last[self._yes_id]), float(last[self._no_id]))
        return yes_prob

    def rerank(self, *, query: str, documents: list[str]) -> list[RerankItem]:
        scored = [RerankItem(index=i, score=self._score_pair(query, doc)) for i, doc in enumerate(documents)]
        scored.sort(key=lambda x: x.score, reverse=True)
        return scored
