from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


class Embedder(ABC):
    @abstractmethod
    def embed(self, texts: list[str]) -> list[list[float]]:
        ...


@dataclass(frozen=True)
class RerankItem:
    index: int
    score: float


class Reranker(ABC):
    @abstractmethod
    def rerank(self, *, query: str, documents: list[str]) -> list[RerankItem]:
        ...
