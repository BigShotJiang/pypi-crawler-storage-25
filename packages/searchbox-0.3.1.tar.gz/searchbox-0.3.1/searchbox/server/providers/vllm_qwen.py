from __future__ import annotations

import math

import httpx

from .base import Embedder, RerankItem, Reranker


def _l2_normalize(vec: list[float]) -> list[float]:
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


class VLLMQwenEmbedder(Embedder):
    def __init__(self, *, base_url: str, model_name: str, dim: int,
                 api_key: str = "EMPTY", timeout: float = 60.0) -> None:
        self._dim = int(dim)
        self._model = model_name
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def embed(self, texts: list[str]) -> list[list[float]]:
        resp = self._client.post("/pooling", json={"model": self._model, "input": texts, "task": "embed"})
        if resp.status_code != 200:
            raise RuntimeError(f"vLLM embedding failed: {resp.status_code} {resp.text}")
        data = resp.json().get("data")
        if not data:
            raise RuntimeError(f"vLLM embedding missing 'data': {resp.text}")
        data.sort(key=lambda x: x["index"])
        vectors = []
        for item in data:
            vec = item.get("data")
            if vec is None or len(vec) != self._dim:
                raise RuntimeError(f"Embedding dim mismatch: expected {self._dim}, got {len(vec) if vec else None}")
            vectors.append(_l2_normalize(vec))
        return vectors


_RERANK_PREFIX = (
    "<|im_start|>system\n"
    'Judge whether the Document meets the requirements based on the Query and the Instruct provided. '
    'Note that the answer can only be "yes" or "no".<|im_end|>\n'
    "<|im_start|>user\n"
)
_RERANK_SUFFIX = "<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"
_RERANK_INSTRUCTION = "Given a web search query, retrieve relevant passages that answer the query"


class VLLMQwenReranker(Reranker):
    def __init__(self, *, base_url: str, model_name: str,
                 api_key: str = "EMPTY", timeout: float = 60.0) -> None:
        self._model = model_name
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )

    def rerank(self, *, query: str, documents: list[str]) -> list[RerankItem]:
        fmt_query = f"{_RERANK_PREFIX}<Instruct>: {_RERANK_INSTRUCTION}\n<Query>: {query}\n"
        fmt_docs = [f"<Document>: {doc}{_RERANK_SUFFIX}" for doc in documents]
        resp = self._client.post("/v1/rerank", json={"model": self._model, "query": fmt_query, "documents": fmt_docs})
        if resp.status_code != 200:
            raise RuntimeError(f"vLLM rerank failed: {resp.status_code} {resp.text}")
        results = resp.json().get("results")
        if results is None:
            raise RuntimeError(f"vLLM rerank missing 'results': {resp.text}")
        items = [RerankItem(index=int(r["index"]), score=float(r["relevance_score"])) for r in results]
        items.sort(key=lambda x: x.score, reverse=True)
        return items
