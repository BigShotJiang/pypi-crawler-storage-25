from __future__ import annotations

import hashlib
import math

from .base import Embedder, RerankItem, Reranker


class MockEmbedder(Embedder):
    def __init__(self, dim: int = 1024) -> None:
        self._dim = int(dim)

    def embed(self, texts: list[str]) -> list[list[float]]:
        results = []
        for text in texts:
            h = hashlib.md5(text.encode()).digest()
            seed = int.from_bytes(h, "big")
            vec = [(((seed >> i) & 0xFF) / 255.0 - 0.5) for i in range(self._dim)]
            norm = math.sqrt(sum(v * v for v in vec)) or 1.0
            results.append([v / norm for v in vec])
        return results


class MockReranker(Reranker):
    def __init__(self, dim: int = 1024) -> None:
        self._embedder = MockEmbedder(dim=dim)

    def rerank(self, *, query: str, documents: list[str]) -> list[RerankItem]:
        qv = self._embedder.embed([query])[0]
        dvs = self._embedder.embed(documents)
        scores = [sum(a * b for a, b in zip(qv, dv)) for dv in dvs]
        items = [RerankItem(index=i, score=s) for i, s in enumerate(scores)]
        items.sort(key=lambda x: x.score, reverse=True)
        return items
