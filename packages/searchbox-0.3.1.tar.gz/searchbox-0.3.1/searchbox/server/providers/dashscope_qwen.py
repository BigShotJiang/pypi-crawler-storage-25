from __future__ import annotations

from .base import Embedder, RerankItem, Reranker


class DashScopeQwenEmbedder(Embedder):
    def __init__(self, *, api_key: str, model: str = "text-embedding-v3", dim: int = 1024) -> None:
        try:
            import dashscope
        except ImportError as e:
            raise ImportError("DashScope provider requires: pip install dashscope") from e
        self._dashscope = dashscope
        self._dashscope.api_key = api_key
        self._model = model
        self._dim = int(dim)

    def embed(self, texts: list[str]) -> list[list[float]]:
        from dashscope import TextEmbedding
        resp = TextEmbedding.call(model=self._model, input=texts, dimension=self._dim)
        if resp.status_code != 200:
            raise RuntimeError(f"DashScope embedding failed: {resp.message}")
        return [item["embedding"] for item in sorted(resp.output["embeddings"], key=lambda x: x["text_index"])]


class DashScopeQwenReranker(Reranker):
    def __init__(self, *, api_key: str, model: str = "gte-rerank") -> None:
        try:
            import dashscope
        except ImportError as e:
            raise ImportError("DashScope provider requires: pip install dashscope") from e
        self._dashscope = dashscope
        self._dashscope.api_key = api_key
        self._model = model

    def rerank(self, *, query: str, documents: list[str]) -> list[RerankItem]:
        from dashscope import TextReRank
        resp = TextReRank.call(model=self._model, query=query, documents=documents, top_n=len(documents))
        if resp.status_code != 200:
            raise RuntimeError(f"DashScope rerank failed: {resp.message}")
        items = [RerankItem(index=r["index"], score=r["relevance_score"]) for r in resp.output["results"]]
        items.sort(key=lambda x: x.score, reverse=True)
        return items
