from __future__ import annotations

from typing import Any

from .chunking import split_text
from .store import MilvusStore, PaperStore
from .providers.base import Embedder, Reranker


class KnowledgeService:
    def __init__(self, *, store: MilvusStore, embedder: Embedder, reranker: Reranker,
                 default_chunk_max_chars: int, default_chunk_overlap: int) -> None:
        self._store = store
        self._embedder = embedder
        self._reranker = reranker
        self._default_chunk_max_chars = int(default_chunk_max_chars)
        self._default_chunk_overlap = int(default_chunk_overlap)

    def _ingest_one(self, *, user_id: str, file_path: str, text: str,
                    chunk_max_chars: int, chunk_overlap: int, metadata: dict[str, Any] | None) -> dict[str, Any]:
        title = str((metadata or {}).get("title") or "")
        chunks = split_text(text, max_chars=chunk_max_chars, overlap=chunk_overlap)
        if not chunks:
            return {"file_path": file_path, "inserted": 0, "chunk_count": 0}
        embeddings = self._embedder.embed([c.text for c in chunks])
        payload = [{"chunk_id": c.chunk_id, "start_offset": c.start_offset,
                    "end_offset": c.end_offset, "content": c.text, "embedding": v}
                   for c, v in zip(chunks, embeddings)]
        # Re-indexing the same path should replace the previous version instead of duplicating it.
        self._store.delete_by_file(user_id=user_id, file_path=file_path)
        inserted = self._store.insert_chunks(user_id=user_id, file_path=file_path, title=title, chunks=payload)
        return {"file_path": file_path, "inserted": inserted, "chunk_count": len(chunks)}

    def ingest(self, *, user_id: str, files: list[dict[str, Any]],
               chunk_max_chars: int | None = None, chunk_overlap: int | None = None) -> list[dict[str, Any]]:
        max_chars = chunk_max_chars or self._default_chunk_max_chars
        overlap = chunk_overlap or self._default_chunk_overlap
        return [self._ingest_one(user_id=user_id, file_path=f["file_path"], text=f["text"],
                                 chunk_max_chars=max_chars, chunk_overlap=overlap,
                                 metadata=f.get("metadata")) for f in files]

    def search(self, *, user_id: str, query: str, recall_top_p: int, top_k: int,
               include_content: bool = False, score_threshold: float | None = None,
               file_paths: list[str] | None = None) -> dict[str, Any]:
        qv = self._embedder.embed([query])[0]
        file_expr: str | None = None
        if file_paths:
            quoted = ['"' + fp.replace('"', "'") + '"' for fp in file_paths]
            file_expr = f'file_path in [{", ".join(quoted)}]'
        hits = self._store.search(user_id=user_id, embedding=qv, top_k=int(recall_top_p), expr=file_expr)
        if not hits:
            return {"query": query, "results": []}
        docs = [h.content for h in hits]
        order = self._reranker.rerank(query=query, documents=docs)
        file_scores: dict[str, float] = {}
        file_content: dict[str, str] = {}
        for item in order:
            hit = hits[item.index]
            fp = hit.file_path
            if fp not in file_scores or item.score > file_scores[fp]:
                file_scores[fp] = item.score
                file_content[fp] = hit.content
        ranked = sorted(file_scores.items(), key=lambda x: x[1], reverse=True)
        if score_threshold is not None:
            ranked = [(fp, s) for fp, s in ranked if s >= score_threshold]
        results = [{"file_path": fp, "score": score,
                    **({} if not include_content else {"content": file_content[fp]})}
                   for fp, score in ranked[:int(top_k)]]
        return {"query": query, "results": results}

    def search_chunks(self, *, user_id: str, query: str, recall_top_p: int, top_k: int,
                      file_path: str, score_threshold: float | None = None) -> dict[str, Any]:
        qv = self._embedder.embed([query])[0]
        expr = f'file_path == "{file_path.replace(chr(34), chr(39))}"'
        hits = self._store.search(user_id=user_id, embedding=qv, top_k=int(recall_top_p), expr=expr)
        if not hits:
            return {"query": query, "file_path": file_path, "results": []}
        docs = [h.content for h in hits]
        order = self._reranker.rerank(query=query, documents=docs)
        ranked = []
        for item in order:
            hit = hits[item.index]
            if score_threshold is not None and item.score < score_threshold:
                continue
            ranked.append({
                "file_path": hit.file_path,
                "title": hit.title,
                "chunk_id": hit.chunk_id,
                "start_offset": hit.start_offset,
                "end_offset": hit.end_offset,
                "score": item.score,
                "content": hit.content,
            })
            if len(ranked) >= int(top_k):
                break
        return {"query": query, "file_path": file_path, "results": ranked}

    def delete_file(self, *, user_id: str, file_path: str) -> int:
        return self._store.delete_by_file(user_id=user_id, file_path=file_path)

    def list_files(self, *, user_id: str) -> list[str]:
        return self._store.list_files(user_id=user_id)

    def drop_collection(self) -> None:
        self._store.drop_collection()


class PaperService:
    def __init__(self, *, store: PaperStore, embedder: Embedder) -> None:
        self._store = store
        self._embedder = embedder

    def ensure_volume(self) -> bool:
        existed = self._store.collection_exists()
        self._store.ensure_collection()
        return not existed

    def ingest_papers(self, *, papers: list[dict[str, Any]]) -> int:
        embeddings = self._embedder.embed([p["abstract"] for p in papers])
        payload = [{"file_path": p["file_path"], "title": p["title"], "abstract": p["abstract"],
                    "metadata": p.get("metadata") or {}, "abstract_embedding": emb}
                   for p, emb in zip(papers, embeddings)]
        return self._store.insert_papers(papers=payload)

    def search_papers(self, *, query: str, top_k: int,
                      score_threshold: float | None = None) -> list[dict[str, Any]]:
        qv = self._embedder.embed([query])[0]
        hits = self._store.search(embedding=qv, top_k=int(top_k))
        return [{"file_path": h.file_path, "title": h.title, "score": h.score, "metadata": h.metadata}
                for h in hits if score_threshold is None or h.score >= score_threshold]
