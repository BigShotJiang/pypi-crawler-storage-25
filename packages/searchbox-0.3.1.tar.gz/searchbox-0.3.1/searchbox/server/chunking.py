from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Chunk:
    chunk_id: int
    start_offset: int
    end_offset: int
    text: str


def split_text(text: str, *, max_chars: int, overlap: int) -> list[Chunk]:
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    if not text:
        return []
    max_chars = max(200, int(max_chars))
    overlap = max(0, min(int(overlap), max_chars // 2))

    chunks: list[Chunk] = []
    pos = 0
    chunk_id = 0
    while pos < len(text):
        end = min(pos + max_chars, len(text))
        if end < len(text):
            window_start = max(pos + int(max_chars * 0.6), pos + 1)
            boundary = text.rfind("\n\n", window_start, end)
            if boundary != -1:
                end = boundary + 2
            else:
                boundary = text.rfind("\n", window_start, end)
                if boundary != -1:
                    end = boundary + 1
        chunk_text = text[pos:end].strip()
        if chunk_text:
            chunks.append(Chunk(chunk_id=chunk_id, start_offset=pos, end_offset=end, text=chunk_text))
            chunk_id += 1
        if end >= len(text):
            break
        pos = max(pos + 1, end - overlap)
    return chunks
