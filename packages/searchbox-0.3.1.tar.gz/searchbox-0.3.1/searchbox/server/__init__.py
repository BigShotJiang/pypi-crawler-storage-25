from __future__ import annotations

import threading
from dataclasses import fields as _dc_fields
from typing import Any


def start_server(
    *,
    config: dict[str, Any] | None = None,
    host: str = "127.0.0.1",
    port: int = 18765,
    background: bool = False,
    log_level: str = "info",
) -> Any:
    """Start the searchbox knowledge server.

    Args:
        config: Server configuration dict. Keys must match ServerSettings field names.
                Unknown keys raise ValueError with a list of valid field names.
                If None, uses defaults (mock provider + local Milvus Lite DB).
        host: Bind host.
        port: Bind port.
        background: If True, run uvicorn in a daemon thread and return immediately.
        log_level: uvicorn log level.

    Returns:
        If background=True, returns the Thread object.
        If background=False, blocks until the server stops (returns None).
    """
    try:
        import uvicorn
    except ImportError as e:
        raise ImportError(
            "Running the server requires uvicorn: pip install 'searchbox[server]'"
        ) from e

    from .app import ServerSettings, create_app

    cfg = config or {}
    valid_keys = {f.name for f in _dc_fields(ServerSettings)}
    unknown = set(cfg) - valid_keys
    if unknown:
        raise ValueError(
            f"Unknown config keys: {sorted(unknown)}. "
            f"Valid keys: {sorted(valid_keys)}"
        )

    settings = ServerSettings(**cfg)
    app = create_app(settings)

    uv_config = uvicorn.Config(app, host=host, port=port, log_level=log_level)
    server = uvicorn.Server(uv_config)

    if background:
        t = threading.Thread(target=server.run, daemon=True)
        t.start()
        return t
    else:
        server.run()
        return None


def start_server_from_yaml(
    config_path: str | None = None,
    *,
    host: str | None = None,
    port: int | None = None,
    background: bool = False,
    log_level: str = "info",
) -> Any:
    """Start the server loading settings from a YAML config file.

    Args:
        config_path: Path to YAML config. If None, looks for milvus_config.yaml
                     in the current directory, then falls back to the bundled default.
        host: Override host from config.
        port: Override port from config.
        background: If True, run in a daemon thread.
        log_level: uvicorn log level.
    """
    import os

    try:
        import yaml
    except ImportError as e:
        raise ImportError(
            "Loading YAML config requires pyyaml: pip install 'searchbox[server]'"
        ) from e

    if config_path is None:
        if os.path.exists("milvus_config.yaml"):
            config_path = "milvus_config.yaml"
        else:
            import importlib.resources as pkg
            config_path = str(pkg.files("searchbox").joinpath("milvus_config.yaml"))

    with open(config_path, encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    server_cfg = raw.get("server", {})
    milvus_cfg = raw.get("milvus_db", {})
    embed_cfg = raw.get("embedding", {})
    rerank_cfg = raw.get("reranking", {})
    vllm_cfg = raw.get("vllm", {})
    ds_cfg = raw.get("dashscope", {})
    ingest_cfg = raw.get("ingest", {})

    embed_provider = embed_cfg.get("provider", "mock")
    rerank_provider = rerank_cfg.get("provider", "mock")

    # DashScope uses different default model names than local/vllm.
    _embed_model = embed_cfg.get("model", "")
    _rerank_model = rerank_cfg.get("model", "")
    dashscope_embed_model = _embed_model or "text-embedding-v3"
    dashscope_rerank_model = _rerank_model or "gte-rerank"
    local_embed_model = _embed_model or "Qwen/Qwen3-Embedding-0.6B"
    local_rerank_model = _rerank_model or "Qwen/Qwen3-Reranker-4B"

    config = {
        "milvus_uri": milvus_cfg.get("uri", "./milvus_local.db"),
        "milvus_token": milvus_cfg.get("token", ""),
        "milvus_db_name": milvus_cfg.get("db_name", "default"),
        "milvus_collection": milvus_cfg.get("collection", "knowledge"),
        "embed_provider": embed_provider,
        "rerank_provider": rerank_provider,
        "embed_dim": int(embed_cfg.get("dim", 1024)),
        "metric_type": embed_cfg.get("metric_type", "IP"),
        "default_chunk_max_chars": int(ingest_cfg.get("chunk_max_chars", 2000)),
        "default_chunk_overlap": int(ingest_cfg.get("chunk_overlap", 200)),
        # vLLM
        "vllm_embed_base_url": vllm_cfg.get("embed_base_url", "http://127.0.0.1:8806"),
        "vllm_embed_model": local_embed_model,
        "vllm_embed_api_key": vllm_cfg.get("embed_api_key", ""),
        "vllm_rerank_base_url": vllm_cfg.get("rerank_base_url", "http://127.0.0.1:8807"),
        "vllm_rerank_model": local_rerank_model,
        "vllm_rerank_api_key": vllm_cfg.get("rerank_api_key", ""),
        "vllm_timeout": float(vllm_cfg.get("timeout", 60.0)),
        # Local
        "local_embed_model": local_embed_model,
        "local_embed_batch_size": int(embed_cfg.get("batch_size", 32)),
        "local_embed_max_length": int(embed_cfg.get("max_length", 8192)),
        "local_rerank_model": local_rerank_model,
        # DashScope
        "dashscope_api_key": ds_cfg.get("api_key", ""),
        "qwen_embed_model": dashscope_embed_model,
        "qwen_rerank_model": dashscope_rerank_model,
    }

    _host = host or server_cfg.get("host", "127.0.0.1")
    _port = port or int(server_cfg.get("port", 18765))

    return start_server(config=config, host=_host, port=_port, background=background, log_level=log_level)
