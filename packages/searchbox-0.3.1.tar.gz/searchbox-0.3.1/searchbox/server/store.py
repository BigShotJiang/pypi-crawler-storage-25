from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from pymilvus import (
    Collection, CollectionSchema, DataType, FieldSchema,
    Function, FunctionType, connections, db, utility,
)


def _esc(s: str) -> str:
    return s.replace('"', "'")


_DEFAULT_DENSE_INDEX = {"index_type": "FLAT", "params": {}}


# ── User knowledge store ──────────────────────────────────────────────────────

@dataclass(frozen=True)
class MilvusSearchHit:
    score: float
    file_path: str
    title: str
    chunk_id: int
    start_offset: int
    end_offset: int
    content: str


class MilvusStore:
    def __init__(self, *, uri: str, token: str, db_name: str,
                 collection_name: str, dim: int, metric_type: str) -> None:
        self._uri = uri
        self._token = token
        self._db_name = db_name
        self._collection_name = collection_name
        self._dim = dim
        self._metric_type = metric_type
        self._connected = False
        self._collection: Collection | None = None

    @property
    def collection(self) -> Collection:
        if self._collection is None:
            raise RuntimeError("Collection not initialized.")
        return self._collection

    def connect(self) -> None:
        if self._connected:
            return
        token_val = self._token if self._token else None
        try:
            connections.connect(uri=self._uri, token=token_val)
        except Exception as e:
            raise RuntimeError(f"Failed to connect to Milvus at {self._uri}: {e}") from e
        try:
            if self._db_name not in db.list_database():
                db.create_database(self._db_name)
            db.using_database(self._db_name)
        except (AttributeError, Exception):
            pass
        self._connected = True

    def ensure_collection(self) -> None:
        self.connect()
        if utility.has_collection(self._collection_name):
            self._collection = Collection(self._collection_name)
            if not any(idx.field_name == "embedding" for idx in self._collection.indexes):
                self._collection.create_index(
                    field_name="embedding",
                    index_params={**_DEFAULT_DENSE_INDEX, "metric_type": self._metric_type},
                )
            return
        fields = [
            FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="user_id", dtype=DataType.VARCHAR, max_length=256),
            FieldSchema(name="file_path", dtype=DataType.VARCHAR, max_length=1024),
            FieldSchema(name="title", dtype=DataType.VARCHAR, max_length=512),
            FieldSchema(name="chunk_id", dtype=DataType.INT32),
            FieldSchema(name="start_offset", dtype=DataType.INT32),
            FieldSchema(name="end_offset", dtype=DataType.INT32),
            FieldSchema(name="content", dtype=DataType.VARCHAR, max_length=65535),
            FieldSchema(name="embedding", dtype=DataType.FLOAT_VECTOR, dim=int(self._dim)),
        ]
        schema = CollectionSchema(fields, description="Personal knowledge chunks")
        self._collection = Collection(name=self._collection_name, schema=schema)
        self._collection.create_index(
            field_name="embedding",
            index_params={**_DEFAULT_DENSE_INDEX, "metric_type": self._metric_type},
        )

    def load(self) -> None:
        self.ensure_collection()
        self.collection.load()

    def collection_exists(self) -> bool:
        self.connect()
        return utility.has_collection(self._collection_name)

    def collection_stats(self) -> dict[str, Any]:
        self.load()
        return {"collection": self._collection_name, "num_entities": self.collection.num_entities}

    def insert_chunks(self, *, user_id: str, file_path: str, title: str,
                      chunks: list[dict[str, Any]]) -> int:
        self.ensure_collection()
        n = len(chunks)
        entities = [
            [user_id] * n,
            [file_path] * n,
            [title] * n,
            [int(c["chunk_id"]) for c in chunks],
            [int(c["start_offset"]) for c in chunks],
            [int(c["end_offset"]) for c in chunks],
            [str(c["content"]) for c in chunks],
            [c["embedding"] for c in chunks],
        ]
        res = self.collection.insert(entities)
        self.collection.flush()
        return len(res.primary_keys)

    def search(self, *, user_id: str, embedding: list[float], top_k: int,
               ef: int = 64, expr: str | None = None) -> list[MilvusSearchHit]:
        self.load()
        base_expr = f'user_id == "{_esc(user_id)}"'
        full_expr = f"{base_expr} && ({expr})" if expr else base_expr
        results = self.collection.search(
            data=[embedding], anns_field="embedding",
            param={"metric_type": self._metric_type, "params": {"ef": int(ef)}},
            limit=int(top_k), expr=full_expr,
            output_fields=["file_path", "title", "chunk_id", "start_offset", "end_offset", "content"],
        )
        if not results:
            return []
        return [
            MilvusSearchHit(
                score=float(h.score),
                file_path=str(h.entity.get("file_path") or ""),
                title=str(h.entity.get("title") or ""),
                chunk_id=int(h.entity.get("chunk_id") or 0),
                start_offset=int(h.entity.get("start_offset") or 0),
                end_offset=int(h.entity.get("end_offset") or 0),
                content=str(h.entity.get("content") or ""),
            )
            for h in results[0]
        ]

    def list_users(self) -> list[str]:
        self.load()
        rows = self.collection.query(expr="chunk_id == 0", output_fields=["user_id"])
        return sorted({r["user_id"] for r in rows})

    def delete_user(self, *, user_id: str) -> int:
        self.ensure_collection()
        res = self.collection.delete(f'user_id == "{_esc(user_id)}"')
        self.collection.flush()
        return res.delete_count

    def list_files(self, *, user_id: str) -> list[str]:
        self.load()
        rows = self.collection.query(
            expr=f'user_id == "{_esc(user_id)}" && chunk_id == 0',
            output_fields=["file_path"],
        )
        return sorted({r["file_path"] for r in rows})

    def list_chunks(self, *, user_id: str, file_path: str) -> list[dict[str, Any]]:
        self.load()
        rows = self.collection.query(
            expr=f'user_id == "{_esc(user_id)}" && file_path == "{_esc(file_path)}"',
            output_fields=["chunk_id", "start_offset", "end_offset", "content", "title"],
        )
        return sorted(rows, key=lambda r: r.get("chunk_id", 0))

    def delete_by_file(self, *, user_id: str, file_path: str) -> int:
        self.ensure_collection()
        res = self.collection.delete(f'user_id == "{_esc(user_id)}" && file_path == "{_esc(file_path)}"')
        self.collection.flush()
        return res.delete_count

    def drop_collection(self) -> None:
        self.connect()
        if utility.has_collection(self._collection_name):
            utility.drop_collection(self._collection_name)
        self._collection = None

    def admin_list_all_files(self) -> list[dict[str, Any]]:
        self.load()
        rows = self.collection.query(expr="chunk_id >= 0", output_fields=["user_id", "file_path", "chunk_id"])
        counts: dict[tuple[str, str], int] = {}
        for r in rows:
            key = (r["user_id"], r["file_path"])
            counts[key] = counts.get(key, 0) + 1
        return [{"user_id": uid, "file_path": fp, "chunk_count": cnt}
                for (uid, fp), cnt in sorted(counts.items())]

    def admin_collection_stats(self) -> dict[str, Any]:
        self.load()
        rows = self.collection.query(expr="chunk_id >= 0", output_fields=["user_id", "file_path"])
        user_files: dict[str, set[str]] = {}
        user_chunks: dict[str, int] = {}
        for r in rows:
            uid, fp = r["user_id"], r["file_path"]
            user_files.setdefault(uid, set()).add(fp)
            user_chunks[uid] = user_chunks.get(uid, 0) + 1
        users = [{"user_id": uid, "file_count": len(user_files[uid]), "chunk_count": user_chunks[uid]}
                 for uid in sorted(user_files)]
        return {"user_count": len(users), "total_chunks": sum(user_chunks.values()), "users": users}


# ── Paper store ───────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class PaperSearchHit:
    score: float
    file_path: str
    title: str
    metadata: dict[str, Any]


class PaperStore:
    def __init__(self, *, uri: str, token: str, db_name: str, collection_name: str, dim: int) -> None:
        self._uri = uri
        self._token = token
        self._db_name = db_name
        self._collection_name = collection_name
        self._dim = dim
        self._connected = False
        self._collection: Collection | None = None

    @property
    def collection(self) -> Collection:
        if self._collection is None:
            raise RuntimeError("Paper collection not initialized.")
        return self._collection

    def connect(self) -> None:
        if self._connected:
            return
        token_val = self._token if self._token else None
        connections.connect(uri=self._uri, token=token_val)
        try:
            if self._db_name not in db.list_database():
                db.create_database(self._db_name)
            db.using_database(self._db_name)
        except (AttributeError, Exception):
            pass
        self._connected = True

    def ensure_collection(self) -> None:
        self.connect()
        if utility.has_collection(self._collection_name):
            self._collection = Collection(self._collection_name)
            if not any(idx.field_name == "abstract_embedding" for idx in self._collection.indexes):
                self._collection.create_index(
                    field_name="abstract_embedding",
                    index_params={**_DEFAULT_DENSE_INDEX, "metric_type": "IP"},
                )
            return
        fields = [
            FieldSchema(name="id", dtype=DataType.INT64, is_primary=True, auto_id=True),
            FieldSchema(name="file_path", dtype=DataType.VARCHAR, max_length=1024),
            FieldSchema(name="title", dtype=DataType.VARCHAR, max_length=1024),
            FieldSchema(name="abstract", dtype=DataType.VARCHAR, max_length=65535),
            FieldSchema(name="metadata", dtype=DataType.VARCHAR, max_length=65535),
            FieldSchema(name="abstract_embedding", dtype=DataType.FLOAT_VECTOR, dim=int(self._dim)),
        ]
        self._collection = Collection(name=self._collection_name,
                                      schema=CollectionSchema(fields, description="Shared paper volume"))
        self._collection.create_index(
            field_name="abstract_embedding",
            index_params={**_DEFAULT_DENSE_INDEX, "metric_type": "IP"},
        )

    def load(self) -> None:
        self.ensure_collection()
        self.collection.load()

    def collection_exists(self) -> bool:
        self.connect()
        return utility.has_collection(self._collection_name)

    def collection_stats(self) -> dict[str, Any]:
        self.load()
        return {"collection": self._collection_name, "num_entities": self.collection.num_entities}

    def insert_papers(self, *, papers: list[dict[str, Any]]) -> int:
        self.ensure_collection()
        entities = [
            [p["file_path"] for p in papers],
            [p["title"] for p in papers],
            [p["abstract"] for p in papers],
            [json.dumps(p.get("metadata") or {}, ensure_ascii=False) for p in papers],
            [p["abstract_embedding"] for p in papers],
        ]
        res = self.collection.insert(entities)
        self.collection.flush()
        return len(res.primary_keys)

    def search(self, *, embedding: list[float], top_k: int, ef: int = 64) -> list[PaperSearchHit]:
        self.load()
        results = self.collection.search(
            data=[embedding], anns_field="abstract_embedding",
            param={"metric_type": "IP", "params": {"ef": int(ef)}},
            limit=int(top_k), output_fields=["file_path", "title", "metadata"],
        )
        if not results:
            return []
        out = []
        for h in results[0]:
            try:
                meta = json.loads(h.entity.get("metadata") or "{}")
            except (ValueError, TypeError):
                meta = {}
            out.append(PaperSearchHit(score=float(h.score),
                                      file_path=str(h.entity.get("file_path") or ""),
                                      title=str(h.entity.get("title") or ""),
                                      metadata=meta))
        return out

    def delete_paper(self, *, file_path: str) -> int:
        self.ensure_collection()
        res = self.collection.delete(f'file_path == "{_esc(file_path)}"')
        self.collection.flush()
        return res.delete_count

    def drop_collection(self) -> None:
        self.connect()
        if utility.has_collection(self._collection_name):
            utility.drop_collection(self._collection_name)
        self._collection = None

    def admin_list_papers(self, *, limit: int = 1_000) -> list[dict[str, Any]]:
        self.load()
        rows = self.collection.query(expr='file_path != ""',
                                     output_fields=["file_path", "title", "metadata"], limit=limit)
        out = []
        for r in rows:
            try:
                meta = json.loads(r.get("metadata") or "{}")
            except (ValueError, TypeError):
                meta = {}
            out.append({"file_path": r.get("file_path", ""), "title": r.get("title", ""), "metadata": meta})
        return sorted(out, key=lambda x: x["file_path"])


# ── Custom collection store ───────────────────────────────────────────────────

FIELD_TYPE_MAP: dict[str, DataType] = {
    "int8":    DataType.INT8,
    "int16":   DataType.INT16,
    "int32":   DataType.INT32,
    "int64":   DataType.INT64,
    "float":   DataType.FLOAT,
    "double":  DataType.DOUBLE,
    "bool":    DataType.BOOL,
    "varchar": DataType.VARCHAR,
    "json":    DataType.JSON,
}

INDEX_TYPE_DENSE = "DENSE"
INDEX_TYPE_BM25 = "BM25"
MAX_INDEXES = 4


@dataclass
class CustomFieldDef:
    name: str
    field_type: str
    is_primary: bool = False
    auto_id: bool = False
    max_length: int = 65535
    dim: int = 1024
    index_type: str | None = None
    default_value: Any = None


class CustomStore:
    def __init__(self, *, uri: str, token: str, db_name: str, collection_name: str) -> None:
        self._uri = uri
        self._token = token
        self._db_name = db_name
        self._collection_name = collection_name
        self._connected = False
        self._collection: Collection | None = None

    @property
    def collection(self) -> Collection:
        if self._collection is None:
            raise RuntimeError("Collection not initialized.")
        return self._collection

    def connect(self) -> None:
        if self._connected:
            return
        token_val = self._token if self._token else None
        try:
            connections.connect(uri=self._uri, token=token_val)
        except Exception as e:
            raise RuntimeError(f"Cannot connect to Milvus: {e}") from e
        try:
            if self._db_name not in db.list_database():
                db.create_database(self._db_name)
            db.using_database(self._db_name)
        except (AttributeError, Exception):
            pass
        self._connected = True

    def collection_exists(self) -> bool:
        self.connect()
        return utility.has_collection(self._collection_name)

    def describe(self) -> dict[str, Any]:
        self.connect()
        if not utility.has_collection(self._collection_name):
            raise RuntimeError(f"Collection {self._collection_name!r} does not exist.")
        col = Collection(self._collection_name)
        fields = []
        for f in col.schema.fields:
            entry: dict[str, Any] = {"name": f.name, "type": f.dtype.name, "is_primary": f.is_primary}
            if f.max_length:
                entry["max_length"] = f.max_length
            if hasattr(f, "dim") and f.dim:
                entry["dim"] = f.dim
            fields.append(entry)
        index_info = [{"field": idx.field_name, "index_type": idx.params.get("index_type"),
                       "metric_type": idx.params.get("metric_type")} for idx in col.indexes]
        return {"collection": self._collection_name, "num_entities": col.num_entities,
                "fields": fields, "indexes": index_info}

    def create(self, *, fields: list[CustomFieldDef]) -> None:
        self.connect()
        if utility.has_collection(self._collection_name):
            raise ValueError(f"Collection {self._collection_name!r} already exists.")
        n_indexes = sum(1 for f in fields if f.index_type is not None)
        if n_indexes > MAX_INDEXES:
            raise ValueError(f"Too many indexed fields ({n_indexes}). Maximum is {MAX_INDEXES}.")
        primaries = [f for f in fields if f.is_primary]
        if len(primaries) != 1:
            raise ValueError("Exactly one primary key field is required.")
        for f in fields:
            if f.index_type != INDEX_TYPE_DENSE and f.field_type not in FIELD_TYPE_MAP:
                raise ValueError(f"Unknown field_type {f.field_type!r} for field {f.name!r}.")
            if f.index_type == INDEX_TYPE_BM25 and f.field_type != "varchar":
                raise ValueError(f"BM25 index requires field_type='varchar', got {f.field_type!r}.")
        field_schemas: list[FieldSchema] = []
        functions: list[Function] = []
        index_params_list: list[dict[str, Any]] = []
        for f in fields:
            dtype = FIELD_TYPE_MAP.get(f.field_type)
            if f.index_type == INDEX_TYPE_DENSE:
                if dtype is not None:
                    kw: dict[str, Any] = {"name": f.name, "dtype": dtype, "is_primary": f.is_primary}
                    if dtype == DataType.VARCHAR:
                        kw["max_length"] = f.max_length
                        kw["default_value"] = f.default_value or "placeholder"
                    elif f.default_value is not None:
                        kw["default_value"] = f.default_value
                    field_schemas.append(FieldSchema(**kw))
                vec_name = f"{f.name}_dense"
                field_schemas.append(FieldSchema(name=vec_name, dtype=DataType.FLOAT_VECTOR, dim=f.dim))
                index_params_list.append({"field_name": vec_name, "index_type": "FLAT", "metric_type": "IP",
                                          "params": {}})
            elif f.index_type == INDEX_TYPE_BM25:
                field_schemas.append(FieldSchema(name=f.name, dtype=DataType.VARCHAR, max_length=f.max_length,
                                                 enable_analyzer=True, default_value=f.default_value or "placeholder"))
                sparse_name = f"{f.name}_bm25"
                field_schemas.append(FieldSchema(name=sparse_name, dtype=DataType.SPARSE_FLOAT_VECTOR))
                functions.append(Function(name=f"{f.name}_bm25_fn", input_field_names=[f.name],
                                          output_field_names=[sparse_name], function_type=FunctionType.BM25))
                index_params_list.append({"field_name": sparse_name, "index_type": "SPARSE_INVERTED_INDEX",
                                          "metric_type": "BM25", "params": {}})
            else:
                assert dtype is not None
                kw = {"name": f.name, "dtype": dtype, "is_primary": f.is_primary}
                if f.auto_id:
                    kw["auto_id"] = True
                if dtype == DataType.VARCHAR:
                    kw["max_length"] = f.max_length
                    if f.default_value is not None:
                        kw["default_value"] = f.default_value
                elif f.default_value is not None:
                    kw["default_value"] = f.default_value
                field_schemas.append(FieldSchema(**kw))
        schema = CollectionSchema(fields=field_schemas, functions=functions if functions else None,
                                  enable_dynamic_field=True)
        col = Collection(name=self._collection_name, schema=schema)
        for ip in index_params_list:
            params = ip.pop("params", {})
            col.create_index(field_name=ip["field_name"],
                             index_params={"index_type": ip["index_type"], "metric_type": ip["metric_type"],
                                           "params": params})
        self._collection = col

    def load(self) -> None:
        self.connect()
        if not utility.has_collection(self._collection_name):
            raise RuntimeError(f"Collection {self._collection_name!r} does not exist.")
        self._collection = Collection(self._collection_name)
        self._collection.load()

    def drop(self) -> None:
        self.connect()
        if utility.has_collection(self._collection_name):
            utility.drop_collection(self._collection_name)
        self._collection = None
