from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import httpx

from .config import MilvusConfig, load_milvus_config
from .extractors import FileTextExtractor
from .search_types import SearchCandidate
from .sources import CandidateSource
from .strategies import SearchStrategy


# ── HTTP 客户端 ────────────────────────────────────────────────────────────────

class MilvusClient:
    """轻量 HTTP 客户端，对接 milvus 服务 REST API。"""

    def __init__(self, base_url: str = "http://localhost:18765", timeout: float = 60.0) -> None:
        self._client = httpx.Client(base_url=base_url.rstrip("/"), timeout=timeout)

    def ingest(
        self,
        user_id: str,
        files: List[Dict[str, Any]],
        collection: Optional[str] = None,
        chunk_max_chars: int = 2000,
        chunk_overlap: int = 200,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "user_id": user_id,
            "files": files,
            "chunk": {"max_chars": chunk_max_chars, "overlap": chunk_overlap},
        }
        if collection:
            payload["collection"] = collection
        resp = self._client.post("/ingest", json=payload)
        resp.raise_for_status()
        return resp.json()

    def search(
        self,
        user_id: str,
        query: str,
        recall_top_p: int = 20,
        top_k: int = 5,
        include_content: bool = True,
        score_threshold: Optional[float] = None,
        file_paths: Optional[List[str]] = None,
        collection: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "user_id": user_id,
            "query": query,
            "recall_top_p": recall_top_p,
            "top_k": top_k,
            "include_content": include_content,
        }
        if score_threshold is not None:
            payload["score_threshold"] = score_threshold
        if file_paths:
            payload["file_paths"] = file_paths
        if collection:
            payload["collection"] = collection
        resp = self._client.post("/search", json=payload)
        resp.raise_for_status()
        return resp.json()

    def search_chunks(
        self,
        user_id: str,
        file_path: str,
        query: str,
        recall_top_p: int = 20,
        top_k: int = 5,
        score_threshold: Optional[float] = None,
        collection: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "user_id": user_id,
            "file_path": file_path,
            "query": query,
            "recall_top_p": recall_top_p,
            "top_k": top_k,
        }
        if score_threshold is not None:
            payload["score_threshold"] = score_threshold
        if collection:
            payload["collection"] = collection
        resp = self._client.post("/search/chunks", json=payload)
        resp.raise_for_status()
        return resp.json()

    def list_files(self, user_id: str, collection: Optional[str] = None) -> List[str]:
        params: Dict[str, str] = {"user_id": user_id}
        if collection:
            params["collection"] = collection
        resp = self._client.get("/files", params=params)
        resp.raise_for_status()
        return resp.json().get("files", [])

    def delete_file(self, user_id: str, file_path: str, collection: Optional[str] = None) -> int:
        payload: Dict[str, Any] = {"user_id": user_id, "file_path": file_path}
        if collection:
            payload["collection"] = collection
        resp = self._client.request("DELETE", "/files", json=payload)
        resp.raise_for_status()
        return resp.json().get("deleted", 0)

    def health(self) -> Dict[str, Any]:
        resp = self._client.get("/health")
        resp.raise_for_status()
        return resp.json()

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> MilvusClient:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


# ── 公共扩展接口（供自定义管道使用）──────────────────────────────────────────────

class MilvusCandidateSource(CandidateSource):
    """
    将 /search 召回结果适配为 SearchCandidate 列表，供自定义 pipeline 使用。

    MilvusCorpusSearch 不使用此类；它是供有自定义检索流程需求时的扩展点。
    """

    def __init__(
        self,
        client: MilvusClient,
        user_id: str,
        collection: Optional[str] = None,
        recall_top_p: int = 40,
    ) -> None:
        self._client = client
        self._user_id = user_id
        self._collection = collection
        self._recall_top_p = recall_top_p

    def fetch_candidates(self, query: str, top_k: int = 20) -> List[SearchCandidate]:
        result = self._client.search(
            user_id=self._user_id,
            query=query,
            recall_top_p=max(self._recall_top_p, top_k),
            top_k=top_k,
            include_content=True,
            collection=self._collection,
        )
        return [
            SearchCandidate(
                id=hit["file_path"],
                title=hit.get("file_path", "").split("/")[-1],
                content=hit.get("content") or "",
                metadata={"milvus_score": hit.get("score", 0.0), "file_path": hit["file_path"]},
            )
            for hit in result.get("results", [])
        ]


class MilvusSearchStrategy(SearchStrategy):
    """
    将向量召回 + 重排封装为 SearchStrategy，供自定义 pipeline 使用。

    MilvusCorpusSearch 不使用此类；它是供有自定义检索流程需求时的扩展点。
    """

    def __init__(
        self,
        client: MilvusClient,
        user_id: str,
        collection: Optional[str] = None,
        recall_top_p: int = 20,
        score_threshold: Optional[float] = None,
    ) -> None:
        self._client = client
        self._user_id = user_id
        self._collection = collection
        self._recall_top_p = recall_top_p
        self._score_threshold = score_threshold

    def search(
        self,
        query: str,
        candidates: Sequence[SearchCandidate],
        top_k: int = 5,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        result = self._client.search(
            user_id=self._user_id,
            query=query,
            recall_top_p=max(self._recall_top_p, top_k * 4),
            top_k=top_k,
            include_content=True,
            score_threshold=self._score_threshold,
            collection=self._collection,
        )
        return [
            {
                "id": hit["file_path"],
                "title": hit["file_path"].split("/")[-1],
                "content": hit.get("content") or "",
                "score": hit.get("score", 0.0),
                "metadata": {"file_path": hit["file_path"], "milvus_score": hit.get("score", 0.0)},
            }
            for hit in result.get("results", [])
        ]


# ── 多文件语料库检索 ────────────────────────────────────────────────────────────

class MilvusCorpusSearch:
    """
    多文件语料库检索入口。

    检索流程（在服务端完成）：
        向量召回 top-p chunks → 语义重排 → 文件级 max-pooling → 返回 top-k 文件

    用法：
        search = MilvusCorpusSearch.from_config("milvus_config.yaml", user_id="alice")
        search.add_path("/data/papers/")
        results = search.search("量子计算的最新进展")
        pretty  = search.search_pretty("量子计算的最新进展")
    """

    def __init__(
        self,
        user_id: str,
        base_url: str = "http://localhost:18765",
        collection: Optional[str] = None,
        recall_top_p: int = 20,
        default_top_k: int = 5,
        score_threshold: Optional[float] = None,
        chunk_max_chars: int = 2000,
        chunk_overlap: int = 200,
        timeout: float = 60.0,
    ) -> None:
        self._user_id = user_id
        self._collection = collection
        self._recall_top_p = recall_top_p
        self._score_threshold = score_threshold
        self._chunk_max_chars = chunk_max_chars
        self._chunk_overlap = chunk_overlap
        self.default_top_k = default_top_k
        self._client = MilvusClient(base_url=base_url, timeout=timeout)
        self._extractor = FileTextExtractor()

    @classmethod
    def from_config(
        cls,
        config: MilvusConfig | str | None,
        user_id: str,
    ) -> MilvusCorpusSearch:
        """
        从 MilvusConfig 对象或 yaml 路径创建实例。

        用法：
            search = MilvusCorpusSearch.from_config("milvus_config.yaml", user_id="alice")
            search = MilvusCorpusSearch.from_config(None, user_id="alice")  # 使用默认值
        """
        if isinstance(config, str):
            cfg = load_milvus_config(config)
        elif config is None:
            cfg = MilvusConfig.default()
        else:
            cfg = config
        return cls(
            user_id=user_id,
            base_url=cfg.milvus_service.base_url,
            timeout=cfg.milvus_service.timeout,
            collection=cfg.search.collection,
            recall_top_p=cfg.search.recall_top_p,
            default_top_k=cfg.search.default_top_k,
            score_threshold=cfg.search.score_threshold,
            chunk_max_chars=cfg.ingest.chunk_max_chars,
            chunk_overlap=cfg.ingest.chunk_overlap,
        )

    # ── 入库 ──────────────────────────────────────────────────────────────────

    def add_path(
        self,
        path: str,
        recursive: bool = True,
        include_hidden: bool = False,
        chunk_max_chars: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
    ) -> List[str]:
        return self.add_paths(
            paths=[path],
            recursive=recursive,
            include_hidden=include_hidden,
            chunk_max_chars=chunk_max_chars,
            chunk_overlap=chunk_overlap,
        )

    def add_paths(
        self,
        paths: Sequence[str],
        recursive: bool = True,
        include_hidden: bool = False,
        chunk_max_chars: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
    ) -> List[str]:
        max_chars = chunk_max_chars or self._chunk_max_chars
        overlap = chunk_overlap or self._chunk_overlap

        inserted_paths: List[str] = []
        for raw_path in paths:
            p = Path(raw_path).expanduser()
            if not p.exists():
                raise FileNotFoundError(f"Path does not exist: {p}")

            files = []
            if p.is_dir():
                pattern = "**/*" if recursive else "*"
                for fp in sorted(p.glob(pattern)):
                    if not fp.is_file():
                        continue
                    if not include_hidden and any(part.startswith(".") for part in fp.relative_to(p).parts):
                        continue
                    text = self._extractor.read_text(fp)
                    if text:
                        files.append({"file_path": str(fp), "text": text})
            else:
                text = self._extractor.read_text(p)
                if text:
                    files.append({"file_path": str(p), "text": text})

            if files:
                self._client.ingest(
                    user_id=self._user_id,
                    files=files,
                    collection=self._collection,
                    chunk_max_chars=max_chars,
                    chunk_overlap=overlap,
                )
                inserted_paths.extend(f["file_path"] for f in files)

        return inserted_paths

    def add_text(
        self,
        text: str,
        file_path: str,
        title: Optional[str] = None,
        chunk_max_chars: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
    ) -> Dict[str, Any]:
        """直接传入文本内容入库，无需本地文件。"""
        max_chars = chunk_max_chars or self._chunk_max_chars
        overlap = chunk_overlap or self._chunk_overlap
        metadata = {"title": title} if title else None
        return self._client.ingest(
            user_id=self._user_id,
            files=[{"file_path": file_path, "text": text, **( {"metadata": metadata} if metadata else {})}],
            collection=self._collection,
            chunk_max_chars=max_chars,
            chunk_overlap=overlap,
        )

    # ── 检索 ──────────────────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        top_k: Optional[int] = None,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        """
        语料库检索，返回按相关度排序的文件列表。

        返回格式：
            [{"id": path, "title": filename, "score": float, "content": str, "metadata": {...}}, ...]
        """
        limit = top_k or self.default_top_k
        result = self._client.search(
            user_id=self._user_id,
            query=query,
            recall_top_p=max(self._recall_top_p, limit * 4),
            top_k=limit,
            include_content=True,
            score_threshold=self._score_threshold,
            collection=self._collection,
        )
        return [
            {
                "id": hit["file_path"],
                "title": hit["file_path"].split("/")[-1],
                "content": hit.get("content") or "",
                "score": hit.get("score", 0.0),
                "metadata": {"file_path": hit["file_path"], "milvus_score": hit.get("score", 0.0)},
            }
            for hit in result.get("results", [])
        ]

    def search_pretty(
        self,
        query: str,
        top_k: Optional[int] = None,
        snippet_length: int = 280,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        """
        格式化检索，snippet 自动截断，适合直接展示。

        返回格式：
            [{"path": str, "file_name": str, "score": float, "snippet": str, "metadata": {...}}, ...]
        """
        results = self.search(query=query, top_k=top_k, **kwargs)
        pretty: List[Dict[str, Any]] = []
        for item in results:
            snippet = item.get("content", "")
            if len(snippet) > snippet_length:
                snippet = f"{snippet[:snippet_length - 3].rstrip()}..."
            pretty.append({
                "path": item["id"],
                "file_name": item["title"],
                "score": item["score"],
                "snippet": snippet,
                "metadata": item.get("metadata", {}),
            })
        return pretty

    def fetch_candidates(self, query: str, top_k: int = 20) -> List[SearchCandidate]:
        """召回候选文件，供自定义重排管道使用。"""
        result = self._client.search(
            user_id=self._user_id,
            query=query,
            recall_top_p=max(self._recall_top_p, top_k),
            top_k=top_k,
            include_content=True,
            collection=self._collection,
        )
        return [
            SearchCandidate(
                id=hit["file_path"],
                title=hit.get("file_path", "").split("/")[-1],
                content=hit.get("content") or "",
                metadata={"milvus_score": hit.get("score", 0.0), "file_path": hit["file_path"]},
            )
            for hit in result.get("results", [])
        ]

    # ── 文件管理 ──────────────────────────────────────────────────────────────

    def list_files(self) -> List[str]:
        return self._client.list_files(user_id=self._user_id, collection=self._collection)

    def delete_file(self, file_path: str) -> int:
        return self._client.delete_file(
            user_id=self._user_id, file_path=file_path, collection=self._collection
        )

    def health(self) -> Dict[str, Any]:
        return self._client.health()

    def supported_extensions(self) -> List[str]:
        return self._extractor.supported_extensions()

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> MilvusCorpusSearch:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()


# ── 单文档 chunk 级检索 ────────────────────────────────────────────────────────

class MilvusDocumentSearch:
    """
    单文档 chunk 级检索入口，适合对长文档内部进行段落定位。

    检索流程（在服务端完成）：
        向量召回 top-p chunks（限定 file_path）→ 语义重排 → 返回 top-k chunks

    用法：
        doc = MilvusDocumentSearch.from_config(None, user_id="alice", file_path="/data/book.pdf")
        results = doc.search("实验设置章节在哪里")
        pretty  = doc.search_pretty("实验设置章节在哪里")

    也可通过 MilvusCorpusSearch.open_document() 获取，共享同一 HTTP 连接：
        corpus = MilvusCorpusSearch.from_config(None, user_id="alice")
        doc    = corpus.open_document("/data/book.pdf")
    """

    def __init__(
        self,
        user_id: str,
        file_path: str,
        base_url: str = "http://localhost:18765",
        collection: Optional[str] = None,
        recall_top_p: int = 20,
        default_top_k: int = 5,
        score_threshold: Optional[float] = None,
        timeout: float = 60.0,
    ) -> None:
        self._user_id = user_id
        self._file_path = file_path
        self._collection = collection
        self._recall_top_p = recall_top_p
        self._score_threshold = score_threshold
        self.default_top_k = default_top_k
        self._client = MilvusClient(base_url=base_url, timeout=timeout)

    @classmethod
    def from_config(
        cls,
        config: MilvusConfig | str | None,
        user_id: str,
        file_path: str,
        collection: Optional[str] = None,
    ) -> MilvusDocumentSearch:
        """
        从 MilvusConfig 对象或 yaml 路径创建实例。

        用法：
            doc = MilvusDocumentSearch.from_config(None, user_id="alice", file_path="/data/book.pdf")
        """
        if isinstance(config, str):
            cfg = load_milvus_config(config)
        elif config is None:
            cfg = MilvusConfig.default()
        else:
            cfg = config
        return cls(
            user_id=user_id,
            file_path=file_path,
            base_url=cfg.milvus_service.base_url,
            timeout=cfg.milvus_service.timeout,
            collection=collection if collection is not None else cfg.search.collection,
            recall_top_p=cfg.search.recall_top_p,
            default_top_k=cfg.search.default_top_k,
            score_threshold=cfg.search.score_threshold,
        )

    @property
    def file_path(self) -> str:
        return self._file_path

    # ── 检索 ──────────────────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        top_k: Optional[int] = None,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        """
        单文档 chunk 级检索，返回按相关度排序的段落列表。

        返回格式：
            [{"id": "path#chunk_id", "title": str, "score": float, "content": str,
              "metadata": {"file_path", "chunk_id", "start_offset", "end_offset", "milvus_score"}}, ...]
        """
        limit = top_k or self.default_top_k
        result = self._client.search_chunks(
            user_id=self._user_id,
            file_path=self._file_path,
            query=query,
            recall_top_p=max(self._recall_top_p, limit),
            top_k=limit,
            score_threshold=self._score_threshold,
            collection=self._collection,
        )
        return [
            {
                "id": f"{hit['file_path']}#{hit['chunk_id']}",
                "title": hit.get("title") or hit["file_path"].split("/")[-1],
                "content": hit.get("content") or "",
                "score": hit.get("score", 0.0),
                "metadata": {
                    "file_path": hit["file_path"],
                    "chunk_id": hit.get("chunk_id", 0),
                    "start_offset": hit.get("start_offset", 0),
                    "end_offset": hit.get("end_offset", 0),
                    "milvus_score": hit.get("score", 0.0),
                },
            }
            for hit in result.get("results", [])[:limit]
        ]

    def search_pretty(
        self,
        query: str,
        top_k: Optional[int] = None,
        snippet_length: int = 280,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        """
        格式化 chunk 检索，snippet 自动截断，适合直接展示。

        返回格式：
            [{"path": str, "file_name": str, "chunk_id": int,
              "start_offset": int, "end_offset": int, "score": float, "snippet": str}, ...]
        """
        results = self.search(query=query, top_k=top_k, **kwargs)
        pretty: List[Dict[str, Any]] = []
        for item in results:
            snippet = item.get("content", "")
            if len(snippet) > snippet_length:
                snippet = f"{snippet[:snippet_length - 3].rstrip()}..."
            meta = item.get("metadata", {})
            pretty.append({
                "path": meta.get("file_path", self._file_path),
                "file_name": item["title"],
                "chunk_id": meta.get("chunk_id", 0),
                "start_offset": meta.get("start_offset", 0),
                "end_offset": meta.get("end_offset", 0),
                "score": item["score"],
                "snippet": snippet,
                "metadata": meta,
            })
        return pretty

    def fetch_candidates(self, query: str, top_k: int = 20) -> List[SearchCandidate]:
        """召回候选 chunk，供自定义重排管道使用。"""
        result = self._client.search_chunks(
            user_id=self._user_id,
            file_path=self._file_path,
            query=query,
            recall_top_p=max(self._recall_top_p, top_k),
            top_k=top_k,
            score_threshold=self._score_threshold,
            collection=self._collection,
        )
        return [
            SearchCandidate(
                id=f"{hit['file_path']}#{hit['chunk_id']}",
                title=hit.get("title") or hit["file_path"].split("/")[-1],
                content=hit.get("content") or "",
                metadata={
                    "file_path": hit["file_path"],
                    "chunk_id": hit.get("chunk_id", 0),
                    "start_offset": hit.get("start_offset", 0),
                    "end_offset": hit.get("end_offset", 0),
                    "milvus_score": hit.get("score", 0.0),
                },
            )
            for hit in result.get("results", [])
        ]

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> MilvusDocumentSearch:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()
