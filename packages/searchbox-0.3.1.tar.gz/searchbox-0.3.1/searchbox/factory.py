from __future__ import annotations

from typing import Optional

from .milvus import MilvusCorpusSearch


class SearchFactory:
    @staticmethod
    def create_milvus_search(
        user_id: str,
        base_url: str = "http://localhost:18765",
        collection: Optional[str] = None,
        recall_top_p: int = 20,
        default_top_k: int = 5,
        score_threshold: Optional[float] = None,
        chunk_max_chars: int = 2000,
        chunk_overlap: int = 200,
        timeout: float = 60.0,
    ) -> MilvusCorpusSearch:
        return MilvusCorpusSearch(
            user_id=user_id,
            base_url=base_url,
            collection=collection,
            recall_top_p=recall_top_p,
            default_top_k=default_top_k,
            score_threshold=score_threshold,
            chunk_max_chars=chunk_max_chars,
            chunk_overlap=chunk_overlap,
            timeout=timeout,
        )
