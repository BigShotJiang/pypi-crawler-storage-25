from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Sequence

from .search_types import SearchCandidate


class SearchStrategy(ABC):
    @abstractmethod
    def search(
        self,
        query: str,
        candidates: Sequence[SearchCandidate],
        top_k: int = 5,
        **kwargs: Any,
    ) -> List[Dict[str, Any]]:
        raise NotImplementedError
