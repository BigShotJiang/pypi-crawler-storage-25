"""python -m searchbox — CLI entry point for the searchbox knowledge server."""
from __future__ import annotations

import argparse
import sys


def _cmd_start(args: argparse.Namespace) -> None:
    from .server import start_server_from_yaml
    print(f"Starting searchbox server on {args.host}:{args.port} ...")
    print(f"Config: {args.config or 'milvus_config.yaml (auto-detected)'}")
    print("Press Ctrl+C to stop.\n")
    start_server_from_yaml(
        config_path=args.config,
        host=args.host,
        port=args.port,
        background=False,
        log_level=args.log_level,
    )


def _cmd_init(args: argparse.Namespace) -> None:
    from .config import generate_config_template
    dest = args.output or "milvus_config.yaml"
    generate_config_template(dest)
    print(f"Config template written to: {dest}")
    print("Edit it to set your provider (mock/local/dashscope/vllm) and model paths.")


def _cmd_check(args: argparse.Namespace) -> None:
    import os
    try:
        import yaml
    except ImportError:
        print("pyyaml is required for the check command. Install it with: pip install \"searchbox[server]\"")
        sys.exit(1)
    from .config import check_service

    config_path = args.config
    if config_path is None:
        if os.path.exists("milvus_config.yaml"):
            config_path = "milvus_config.yaml"
        else:
            print("No config file found. Run: python -m searchbox init")
            sys.exit(1)

    with open(config_path, encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    base_url = raw.get("milvus_service", {}).get("base_url", "http://localhost:18765")
    timeout = float(raw.get("milvus_service", {}).get("timeout", 10.0))
    ok = check_service(base_url, timeout)
    if ok:
        print(f"[OK] Service is healthy at {base_url}")
    else:
        print(f"[FAIL] Service not reachable at {base_url}")
        sys.exit(1)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="python -m searchbox",
        description="Searchbox knowledge server CLI",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # start
    p_start = sub.add_parser("start", help="Start the knowledge server")
    p_start.add_argument("--config", default=None, metavar="PATH",
                         help="Path to milvus_config.yaml (default: auto-detect)")
    p_start.add_argument("--host", default=None, help="Bind host (overrides config)")
    p_start.add_argument("--port", type=int, default=None, help="Bind port (overrides config)")
    p_start.add_argument("--log-level", default="info", dest="log_level",
                         choices=["debug", "info", "warning", "error"])
    p_start.set_defaults(func=_cmd_start)

    # init — generate config template
    p_init = sub.add_parser("init", help="Generate a milvus_config.yaml template")
    p_init.add_argument("--output", default=None, metavar="PATH",
                        help="Output path (default: milvus_config.yaml)")
    p_init.set_defaults(func=_cmd_init)

    # check — verify service health
    p_check = sub.add_parser("check", help="Check if the knowledge server is running")
    p_check.add_argument("--config", default=None, metavar="PATH",
                         help="Path to milvus_config.yaml")
    p_check.set_defaults(func=_cmd_check)

    args = parser.parse_args()

    # Fill defaults that depend on config (host/port for start)
    if args.command == "start":
        if args.host is None:
            args.host = None  # will be resolved in start_server_from_yaml
        if args.port is None:
            args.port = None

    args.func(args)


if __name__ == "__main__":
    main()
