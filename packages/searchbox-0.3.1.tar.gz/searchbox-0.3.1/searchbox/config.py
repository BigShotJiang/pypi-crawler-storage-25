from __future__ import annotations

import copy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional


@dataclass
class MilvusServiceConfig:
    base_url: str = "http://localhost:18765"
    timeout: float = 60.0


@dataclass
class SearchConfig:
    recall_top_p: int = 20
    default_top_k: int = 5
    score_threshold: Optional[float] = None
    collection: Optional[str] = None


@dataclass
class IngestConfig:
    chunk_max_chars: int = 2000
    chunk_overlap: int = 200


@dataclass
class MilvusConfig:
    milvus_service: MilvusServiceConfig = field(default_factory=MilvusServiceConfig)
    search: SearchConfig = field(default_factory=SearchConfig)
    ingest: IngestConfig = field(default_factory=IngestConfig)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MilvusConfig:
        svc_data = data.get("milvus_service", {})
        search_data = data.get("search", {})
        ingest_data = data.get("ingest", {})

        svc = MilvusServiceConfig(
            base_url=str(svc_data.get("base_url", "http://localhost:18765")),
            timeout=float(svc_data.get("timeout", 60.0)),
        )
        srch = SearchConfig(
            recall_top_p=int(search_data.get("recall_top_p", 20)),
            default_top_k=int(search_data.get("default_top_k", 5)),
            score_threshold=search_data.get("score_threshold") or None,
            collection=search_data.get("collection") or None,
        )
        ing = IngestConfig(
            chunk_max_chars=int(ingest_data.get("chunk_max_chars", 2000)),
            chunk_overlap=int(ingest_data.get("chunk_overlap", 200)),
        )
        return cls(milvus_service=svc, search=srch, ingest=ing)

    @classmethod
    def from_yaml(cls, path: str) -> MilvusConfig:
        try:
            import yaml
        except ImportError as e:
            raise ImportError(
                "PyYAML is required to load config files. Install it with: pip install pyyaml"
            ) from e
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return cls.from_dict(data)

    @classmethod
    def default(cls) -> MilvusConfig:
        """返回内置默认配置（无需任何文件）。"""
        return cls()

    @classmethod
    def default_from_package(cls) -> MilvusConfig:
        """加载 searchbox 包内自带的 milvus_config.yaml 作为起点。"""
        builtin = Path(__file__).parent / "milvus_config.yaml"
        if builtin.exists():
            return cls.from_yaml(str(builtin))
        return cls.default()


def load_milvus_config(path: Optional[str] = None) -> MilvusConfig:
    """
    加载 Milvus 配置。

    用法：
        cfg = load_milvus_config()                      # 使用内置默认值
        cfg = load_milvus_config("my_config.yaml")      # 加载用户自定义文件
    """
    if path is None:
        return MilvusConfig.default()
    return MilvusConfig.from_yaml(path)


def generate_config_template(dest: str = "milvus_config.yaml") -> str:
    """
    把内置的配置模板复制到用户指定位置，方便用户按需修改。

    用法：
        from searchbox.config import generate_config_template
        generate_config_template("my_milvus_config.yaml")
    """
    builtin = Path(__file__).parent / "milvus_config.yaml"
    dest_path = Path(dest)
    if dest_path.exists():
        raise FileExistsError(f"{dest} already exists. Delete it first or choose another path.")
    dest_path.write_text(builtin.read_text(encoding="utf-8"), encoding="utf-8")
    return str(dest_path.resolve())


def print_setup_guide() -> None:
    """
    打印本地部署向导，帮助用户快速上手。

    用法：
        from searchbox import print_setup_guide
        print_setup_guide()
    """
    guide = """
+------------------------------------------------------------------+
|          searchbox  本地知识库服务  部署向导                       |
+------------------------------------------------------------------+

searchbox 内置了完整的向量知识库服务，无需 git clone 任何外部代码。

------------------------------------------------------------------
 第一步：安装依赖
------------------------------------------------------------------

  # 核心服务（FastAPI + Milvus Lite，无需 Docker）
  pip install "searchbox[server]"

  # 如果使用本地 HuggingFace 模型（推荐，无需联网推理）
  pip install "searchbox[local]"

  # 如果使用阿里云 DashScope API（无 GPU 时的最佳选择）
  pip install "searchbox[dashscope]"

------------------------------------------------------------------
 第二步：生成配置文件
------------------------------------------------------------------

  python -m searchbox init
  # 在当前目录生成 milvus_config.yaml，按需编辑

  关键配置项：
    embedding.provider  — mock / local / dashscope / vllm
    reranking.provider  — mock / local / dashscope / vllm
    embedding.model     — 模型名称或本地路径
    milvus_db.uri       — 数据库文件路径（默认 ./data/milvus_local.db）

------------------------------------------------------------------
 第三步：启动服务
------------------------------------------------------------------

  mkdir -p data
  python -m searchbox start
  # 或指定配置文件和端口：
  python -m searchbox start --config milvus_config.yaml --port 18765

  服务启动后，数据自动存入 ./data/milvus_local.db（自动创建，无需 Docker）

------------------------------------------------------------------
 第四步：验证服务
------------------------------------------------------------------

  python -m searchbox check
  # 或用 curl：
  curl http://localhost:18765/health

------------------------------------------------------------------
 第五步：在代码中使用
------------------------------------------------------------------

  from searchbox import MilvusCorpusSearch

  search = MilvusCorpusSearch.from_config("milvus_config.yaml", user_id="alice")
  search.add_path("/path/to/your/docs")
  results = search.search_pretty("你的查询")
  for r in results:
      print(r["score"], r["path"])

------------------------------------------------------------------
 Provider 选择指南
------------------------------------------------------------------

  mock       无需任何模型，哈希向量，仅用于测试（精度很低）
  local      本地 HuggingFace 模型，需要 GPU 或较大内存
             嵌入模型：Qwen/Qwen3-Embedding-0.6B  (~1.2 GB)
             重排模型：Qwen/Qwen3-Reranker-4B     (~8 GB)
             下载：huggingface-cli download Qwen/Qwen3-Embedding-0.6B
  dashscope  阿里云 API，无需本地 GPU，填写 api_key 即用
             申请：https://dashscope.aliyun.com
  vllm       外部 vLLM 推理服务，适合团队共享 GPU 服务器

"""
    print(guide)


def check_service(base_url: str = "http://localhost:18765", timeout: float = 5.0) -> bool:
    """
    检查 milvus服务 是否正在运行。

    用法：
        from searchbox.config import check_service
        if not check_service():
            print("请先启动 milvus服务！")

    Returns:
        True 表示服务正常，False 表示无法连接。
    """
    try:
        import httpx
        resp = httpx.get(f"{base_url.rstrip('/')}/health", timeout=timeout)
        return resp.status_code == 200 and resp.json().get("ok") is True
    except Exception:
        return False
