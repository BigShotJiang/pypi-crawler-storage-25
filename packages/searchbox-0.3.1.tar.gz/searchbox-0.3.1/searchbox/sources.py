from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

from .search_types import SearchCandidate


class CandidateSource(ABC):
    @abstractmethod
    def fetch_candidates(self, query: str, top_k: int = 20) -> List[SearchCandidate]:
        raise NotImplementedError
