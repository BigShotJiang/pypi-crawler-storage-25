import os
from typing import Optional

class Config:
    @property
    def enabled(self) -> bool:
        """Whether to enable tracing and event tracking."""
        val = os.getenv("REVGATE_ENABLED", "true").lower()
        return val in ("true", "1", "yes", "on")

    @property
    def revgate_base_url(self) -> str:
        return os.getenv("REVGATE_BASE_URL", "https://cloud.revgate.app")

    @property
    def otel_collector_endpoint(self) -> str:
        return f"{self.revgate_base_url}/v1/ingest/otel"

    @property
    def api_key(self) -> Optional[str]:
        return os.getenv("REVGATE_API_KEY")

    @property
    def otel_exporter_type(self) -> str:
        return os.getenv("REVGATE_OTEL_EXPORTER_TYPE", "proto").lower()

    @property
    def enable_console_logging(self) -> bool:
        """Whether to enable the OTel ConsoleSpanExporter."""
        val = os.getenv("REVGATE_ENABLE_CONSOLE_LOGGING", "false").lower()
        return val in ("true", "1", "yes", "on")

    @property
    def otel_export_mode(self) -> str:
        """Whether to use 'batch' or 'simple' span processing."""
        return os.getenv("REVGATE_OTEL_EXPORT_MODE", "batch").lower()

config = Config()
