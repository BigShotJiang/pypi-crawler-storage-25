"""
This file exports `logger` object for unified logging across the Revgate SDK.
"""

import logging
import os
import dotenv

# Load env vars
_ = dotenv.load_dotenv()

logger = logging.getLogger("revgate")

# Set default log level to INFO, allow override via REVGATE_LOG_LEVEL
log_level_name = os.environ.get("REVGATE_LOG_LEVEL")
if log_level_name is not None:
    log_level = getattr(logging, log_level_name.upper(), logging.INFO)
else:
    log_level = logging.INFO

logger.setLevel(log_level)

# Determine handler (console)
if not logger.handlers:
    ch = logging.StreamHandler()
    ch.setLevel(log_level)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
