"""
Auto-instrumentation for AI libraries using OpenTelemetry instrumentors.
"""

from typing import List, Optional
from ..config import config
from ..logger import logger
from .core import _get_otel_tracer

# Safe imports for instrumentation libraries
try:
    from opentelemetry.instrumentation.anthropic import AnthropicInstrumentor
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

try:
    from opentelemetry.instrumentation.openai import OpenAIInstrumentor
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

# try:
#     from openinference.instrumentation.openai_agents import OpenAIAgentsInstrumentor
#     OPENAI_AGENTS_AVAILABLE = True
# except ImportError:
#     OPENAI_AGENTS_AVAILABLE = False

try:
    from openinference.instrumentation.langchain import LangChainInstrumentor
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False

try:
    from openinference.instrumentation.google_genai import GoogleGenAIInstrumentor
    GOOGLE_GENAI_AVAILABLE = True
except ImportError:
    GOOGLE_GENAI_AVAILABLE = False

try:
    from opentelemetry.instrumentation.cohere import CohereInstrumentor
    COHERE_AVAILABLE = True
except ImportError:
    COHERE_AVAILABLE = False

try:
    from opentelemetry.instrumentation.mistralai import MistralAIInstrumentor
    MISTRALAI_AVAILABLE = True
except ImportError:
    MISTRALAI_AVAILABLE = False

try:
    from opentelemetry.instrumentation.vertexai import VertexAIInstrumentor
    VERTEX_AI_AVAILABLE = True
except ImportError:
    VERTEX_AI_AVAILABLE = False

try:
    from opentelemetry.instrumentation.sagemaker import SageMakerInstrumentor
    SAGEMAKER_AVAILABLE = True
except ImportError:
    SAGEMAKER_AVAILABLE = False

try:
    from openinference.instrumentation.huggingface import HuggingFaceInstrumentor
    HUGGINGFACE_AVAILABLE = True
except ImportError:
    HUGGINGFACE_AVAILABLE = False

_initialized_instrumentors: List[str] = []

def auto_instrument(libraries: Optional[List[str]] = None) -> None:
    """
    Enable automatic instrumentation for AI libraries.
    """
    if not config.enabled:
        logger.info("Tracing is disabled, skipping auto-instrumentation.")
        return

    # Ensure OTEL is initialized
    _get_otel_tracer()

    if libraries is None:
        libraries = ["openai", "anthropic", "langchain", "google-genai", "cohere", "mistral", "vertex-ai", "huggingface"]

    for library in libraries:
        if library in _initialized_instrumentors:
            logger.warning(f"Instrumentation for {library} is already enabled, skipping.")
            continue

        if library == "openai":
            _instrument_openai()
        elif library == "anthropic":
            _instrument_anthropic()
        elif library == "langchain":
            _instrument_langchain()
        elif library == "google-genai":
            _instrument_google_genai()
        elif library == "cohere":
            _instrument_cohere()
        elif library == "mistral":
            _instrument_mistral()
        elif library == "vertex-ai":
            _instrument_vertex_ai()
        elif library == "huggingface":
            _instrument_huggingface()
        else:
            logger.warning(f"Unknown library '{library}'")

    logger.info(f"Auto-instrumentation enabled for: {', '.join(_initialized_instrumentors)}")

def _instrument_openai():
    if not OPENAI_AVAILABLE:
        logger.warning("OpenAI instrumentation not available.")
        return
    from .core import get_tracer_provider
    OpenAIInstrumentor().instrument(tracer_provider=get_tracer_provider())
    _initialized_instrumentors.append("openai")
    logger.info("OpenAI auto-instrumentation enabled")

def _instrument_anthropic():
    if not ANTHROPIC_AVAILABLE:
        logger.warning("Anthropic instrumentation not available.")
        return
    from .core import get_tracer_provider
    AnthropicInstrumentor().instrument(tracer_provider=get_tracer_provider())
    _initialized_instrumentors.append("anthropic")
    logger.info("Anthropic auto-instrumentation enabled")

def _instrument_langchain():
    if not LANGCHAIN_AVAILABLE:
        logger.warning("LangChain instrumentation not available.")
        return
    from .core import get_tracer_provider
    LangChainInstrumentor().instrument(tracer_provider=get_tracer_provider())
    _initialized_instrumentors.append("langchain")
    logger.info("LangChain auto-instrumentation enabled")

def _instrument_google_genai():
    if not GOOGLE_GENAI_AVAILABLE:
        logger.warning("Google GenAI instrumentation not available.")
        return
    from .core import get_tracer_provider
    GoogleGenAIInstrumentor().instrument(tracer_provider=get_tracer_provider())
    _initialized_instrumentors.append("google-genai")
    logger.info("Google GenAI auto-instrumentation enabled")

def _instrument_cohere():
    if not COHERE_AVAILABLE:
        logger.warning("Cohere instrumentation not available.")
        return
    from .core import get_tracer_provider
    CohereInstrumentor().instrument(tracer_provider=get_tracer_provider())
    _initialized_instrumentors.append("cohere")
    logger.info("Cohere auto-instrumentation enabled")

def _instrument_mistral():
    if not MISTRALAI_AVAILABLE:
        logger.warning("Mistral AI instrumentation not available.")
        return
    from .core import get_tracer_provider
    MistralAIInstrumentor().instrument(tracer_provider=get_tracer_provider())
    _initialized_instrumentors.append("mistral")
    logger.info("Mistral AI auto-instrumentation enabled")

def _instrument_vertex_ai():
    if not VERTEX_AI_AVAILABLE:
        logger.warning("Vertex AI instrumentation not available.")
        return
    from .core import get_tracer_provider
    VertexAIInstrumentor().instrument(tracer_provider=get_tracer_provider())
    _initialized_instrumentors.append("vertex-ai")
    logger.info("Vertex AI auto-instrumentation enabled")

def _instrument_huggingface():
    if not HUGGINGFACE_AVAILABLE:
        logger.warning("HuggingFace instrumentation not available.")
        return
    from .core import get_tracer_provider
    HuggingFaceInstrumentor().instrument(tracer_provider=get_tracer_provider())
    _initialized_instrumentors.append("huggingface")
    logger.info("HuggingFace auto-instrumentation enabled")

def _instrument_sagemaker():
    if not SAGEMAKER_AVAILABLE:
        logger.warning("SageMaker instrumentation not available.")
        return
    from .core import get_tracer_provider
    SageMakerInstrumentor().instrument(tracer_provider=get_tracer_provider())
    _initialized_instrumentors.append("sagemaker")
    logger.info("SageMaker auto-instrumentation enabled")
