import logging
import json
from typing import Any, Dict, Optional
from .context import ContextData
from ..config import config

logger = logging.getLogger("revgate")

def track_event(
    name: str,
    metadata: Optional[Dict[str, Any]] = None,
    quantity: float = 1.0,
):
    """
    Track a billable resource usage event.

    Args:
        name: Event name matching a CostAttribute event_name (e.g., "vector_read").
        metadata: Optional key-value metadata to attach to the event.
        quantity: Number of units consumed (default 1.0). Used for cost calculation.
    """
    trace_id = ContextData.get("trace_id")
    span_id = ContextData.get("span_id")
    customer_id = ContextData.get("revgate.customer.id")
    
    # Merge product metadata with provided event metadata
    # The event inherits product-level metadata as a base
    event_metadata = ContextData.get("revgate.product.metadata") or {}
    if metadata:
        event_metadata.update(metadata)
 
    event_data = {
        "revgate.event.name": name,
        "revgate.customer.id": customer_id,
        "revgate.trace.id": trace_id,
        "revgate.span.id": span_id,
        "revgate.event.metadata": event_metadata,
        "revgate.event.usage.quantity": quantity,
    }

    if not config.enabled:
        return event_data

    # OTEL Integration
    try:
        from opentelemetry import trace
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording():
            attributes = {
                "revgate.event.name": name,
                "revgate.event.usage.quantity": quantity,
            }
            # Flatten metadata
            for k, v in event_metadata.items():
                attributes[f"revgate.event.metadata.{k}"] = str(v)
            
            current_span.add_event(name, attributes=attributes)
    except ImportError:
        pass

    # Logging
    logger.info(f"[EVENT] {name} | Quantity: {quantity} | Trace: {trace_id} | Span: {span_id}")
    
    return event_data
