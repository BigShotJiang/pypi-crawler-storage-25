import contextvars
from typing import Any, Optional, Dict
import uuid

# Safe import for OTel
try:
    from opentelemetry import trace as otel_trace
    from opentelemetry import baggage as otel_baggage
    OTEL_AVAILABLE = True
except ImportError:
    OTEL_AVAILABLE = False

class ContextData:
    _CUSTOMER_ID = contextvars.ContextVar[Optional[str]]("revgate.customer.id", default=None)
    _PRODUCT_EVENT_NAME = contextvars.ContextVar[Optional[str]]("revgate.product.event.name", default=None)
    _PRODUCT_METADATA = contextvars.ContextVar[Optional[Dict[str, Any]]]("revgate.product.metadata", default=None)
    _TRACE_ID = contextvars.ContextVar[Optional[str]]("trace_id", default=None)
    _SPAN_ID = contextvars.ContextVar[Optional[str]]("span_id", default=None)

    _context_vars = {
        "revgate.customer.id": _CUSTOMER_ID,
        "revgate.product.event.name": _PRODUCT_EVENT_NAME,
        "revgate.product.metadata": _PRODUCT_METADATA,
        "trace_id": _TRACE_ID,
        "span_id": _SPAN_ID,
    }

    _reset_tokens: Dict[str, Any] = {}

    @classmethod
    def set(cls, key: str, value: Any):
        if key in cls._context_vars:
            return cls._context_vars[key].set(value)

    @classmethod
    def get(cls, key: str, context=None) -> Any:
        # Prioritize OTel context for trace_id and span_id if available
        if OTEL_AVAILABLE:
            if key == "trace_id" or key == "span_id":
                current_span = otel_trace.get_current_span()
                if current_span and current_span.get_span_context().is_valid:
                    if key == "trace_id":
                        return f"{current_span.get_span_context().trace_id:032x}"
                    if key == "span_id":
                        return f"{current_span.get_span_context().span_id:016x}"

            # Check baggage for all context keys (supports nested context inheritance)
            baggage_val = otel_baggage.get_baggage(key, context=context)
            if baggage_val is not None:
                return baggage_val

            # Fallback to contextvar for keys not in baggage
            if key in cls._context_vars:
                return cls._context_vars[key].get()

        return None

    @classmethod
    def reset(cls, tokens: Dict[str, Any]):
        for key, token in tokens.items():
            if key in cls._context_vars and token:
                cls._context_vars[key].reset(token)

    @classmethod
    def get_current_context(cls) -> Dict[str, Any]:
        return {k: cls.get(k) for k in cls._context_vars.keys()}
