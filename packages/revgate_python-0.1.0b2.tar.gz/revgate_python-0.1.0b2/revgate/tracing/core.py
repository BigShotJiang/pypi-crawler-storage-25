import functools
import os
import uuid
import time
import asyncio
import logging
import inspect
from typing import Any, Callable, Dict, Optional, Union

try:
    from opentelemetry import trace, baggage
    from opentelemetry.context import attach, detach
    from opentelemetry.sdk.trace import TracerProvider, SpanProcessor
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor, BatchSpanProcessor
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.trace import Status, StatusCode
    OTEL_AVAILABLE = True
except ImportError:
    OTEL_AVAILABLE = False

from .context import ContextData
from .. import __version__
from ..config import config
from ..logger import logger

# Global OTEL components
_otel_tracer = None
_otel_tracer_provider = None

if OTEL_AVAILABLE:
    class RevgateContextSpanProcessor(SpanProcessor):
        """
        Span processor that injects Revgate context attributes onto every span.
        Reads from OTel baggage in the parent_context - this supports nested
        contexts where inner values override outer values (baggage is scoped
        by the attach/detach mechanism in revgate_tracing).
        """

        def on_start(self, span, parent_context=None):
            if not span.is_recording():
                return

            # Read all context values from parent_context baggage
            # For nested revgate_tracing contexts, the inner-most values override outer ones
            # because we attach new baggage (with merged values) when entering inner context

            # 1. Customer ID
            cust_id = baggage.get_baggage("revgate.customer.id", context=parent_context)
            if cust_id:
                span.set_attribute("revgate.customer.id", cust_id)

            # 2. Product Event Name
            prod_event = baggage.get_baggage("revgate.product.event.name", context=parent_context)
            if prod_event:
                span.set_attribute("revgate.product.event.name", prod_event)

            # 3. Product Metadata (flatten into dot-notation attributes)
            prod_meta = baggage.get_baggage("revgate.product.metadata", context=parent_context)
            if prod_meta and isinstance(prod_meta, dict):
                for k, v in prod_meta.items():
                    span.set_attribute(f"revgate.product.metadata.{k}", str(v))

        def on_end(self, span):
            pass

def _get_otel_tracer():
    if not config.enabled:
        return None

    global _otel_tracer, _otel_tracer_provider
    if _otel_tracer is not None:
        return _otel_tracer

    try:
        resource = Resource(attributes={
            "service.name": "revgate-python-sdk",
            "sdk.language": "python",
            "sdk.version": __version__
        })
        provider = TracerProvider(resource=resource)
        
        # Use localhost:4318 as default but respect config
        endpoint = config.otel_collector_endpoint
        
        # Import OTLPSpanExporter based on config
        if config.otel_exporter_type == "json":
            try:
                from opentelemetry.exporter.otlp.json.http.trace_exporter import OTLPSpanExporter
            except ImportError:
                logger.warning("OTLP JSON exporter not found. Falling back to Protobuf exporter.")
                from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        else:
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

        # Add the main OTLP exporter
        otlp_exporter = OTLPSpanExporter(endpoint=endpoint, headers={"x-revgate-api-key": config.api_key})
        
        if config.otel_export_mode == "simple":
            # SimpleSpanProcessor exports inline. Keep it as an opt-in for short-lived
            # environments where losing spans on process exit is worse than blocking.
            processor = SimpleSpanProcessor(otlp_exporter)
            logger.debug("Using SimpleSpanProcessor for immediate span export")
        else:
            # BatchSpanProcessor exports from a worker thread so collector outages do not
            # block user logic on span end.
            processor = BatchSpanProcessor(
                otlp_exporter,
                schedule_delay_millis=500,
                max_export_batch_size=64,
                max_queue_size=2048,
                export_timeout_millis=10000,
            )
            logger.debug("Using BatchSpanProcessor for non-blocking span export")
            
        provider.add_span_processor(processor)

        # Add Console Exporter for debugging if enabled
        if config.enable_console_logging:
            from opentelemetry.sdk.trace.export import ConsoleSpanExporter
            provider.add_span_processor(SimpleSpanProcessor(ConsoleSpanExporter()))
        
        # Add custom Context processor to inject attributes on all spans
        provider.add_span_processor(RevgateContextSpanProcessor())
        
        trace.set_tracer_provider(provider)
        _otel_tracer_provider = provider
        _otel_tracer = trace.get_tracer("revgate")
        return _otel_tracer
    except Exception as e:
         # Log error but don't crash - we might want to return None or NoOp
        logger.error(f"Failed to initialize OTEL tracer: {e}")
        return None

def get_tracer_provider():
    _get_otel_tracer() # Ensure init
    return _otel_tracer_provider

class RevgateTracing:
    def __init__(
        self,
        customer_id: Optional[str] = None,
        product_event_name: Optional[str] = None,
        product_metadata: Optional[Dict[str, Any]] = None,
        **kwargs,
    ):
        self.customer_id = customer_id
        self.product_event_name = product_event_name
        self.name = product_event_name or "span"
        self.product_metadata = product_metadata or {}
        
        self.span = None
        self.otel_context_manager = None
        self.otel_span = None
        self.baggage_token = None
        self.context_tokens = {}

    def _prepare_otel_baggage(self):
        """
        Set OTel baggage for this context. Supports nested contexts:
        - Values explicitly set in this context override parent values
        - Values not set are inherited from parent baggage
        - Metadata is merged with parent metadata
        """
        if not OTEL_AVAILABLE:
            return

        current_baggage = baggage.get_all()
        new_baggage = current_baggage.copy()

        # customer_id: inherit from parent if not explicitly set
        if self.customer_id is not None:
            new_baggage["revgate.customer.id"] = self.customer_id

        # product_event_name: inherit from parent if not explicitly set
        if self.product_event_name is not None:
            new_baggage["revgate.product.event.name"] = self.product_event_name

        # product_metadata: merge with parent (child overrides parent for same keys)
        if self.product_metadata:
            existing_metadata = new_baggage.get("revgate.product.metadata", {})
            if isinstance(existing_metadata, dict):
                new_baggage["revgate.product.metadata"] = {**existing_metadata, **self.product_metadata}
            else:
                new_baggage["revgate.product.metadata"] = self.product_metadata

        if new_baggage != current_baggage:
            # Build new context with all baggage entries
            ctx = baggage.set_baggage("revgate.customer.id", new_baggage.get("revgate.customer.id"))
            ctx = baggage.set_baggage("revgate.product.event.name", new_baggage.get("revgate.product.event.name"), context=ctx)
            ctx = baggage.set_baggage("revgate.product.metadata", new_baggage.get("revgate.product.metadata"), context=ctx)
            self.baggage_token = attach(ctx)

    def _cleanup_otel_baggage(self):
        if self.baggage_token:
            detach(self.baggage_token)
            self.baggage_token = None

    def __enter__(self):
        if not config.enabled:
            return self

        self._setup_context()
        self._prepare_otel_baggage()
        self._start_span()
        
        if self.otel_context_manager:
            self.otel_span = self.otel_context_manager.__enter__()
            
        # Log Start Span using ContextData (which correctly pulls from OTel if available)
        trace_id = ContextData.get("trace_id")
        span_id = ContextData.get("span_id")
        logger.info(f"[TRACING] START SPAN: {self.name} | TraceID: {trace_id} | SpanID: {span_id}")
        
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if not config.enabled:
            return

        # Capture IDs before exiting OTel context
        trace_id = ContextData.get("trace_id")
        span_id = ContextData.get("span_id")
        
        if self.otel_context_manager:
            self.otel_context_manager.__exit__(exc_type, exc_val, exc_tb)
            
        self._end_span(trace_id, span_id, exc_type, exc_val)
        self._cleanup_otel_baggage()
        self._reset_context()

    async def __aenter__(self):
        if not config.enabled:
            return self

        self._setup_context()
        self._prepare_otel_baggage()
        self._start_span()
        
        if self.otel_context_manager:
            self.otel_span = self.otel_context_manager.__enter__()

        # Log Start Span using ContextData
        trace_id = ContextData.get("trace_id")
        span_id = ContextData.get("span_id")
        logger.info(f"[TRACING] START SPAN: {self.name} | TraceID: {trace_id} | SpanID: {span_id}")

        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if not config.enabled:
            return

        # Capture IDs before exiting OTel context
        trace_id = ContextData.get("trace_id")
        span_id = ContextData.get("span_id")
        
        if self.otel_context_manager:
            self.otel_context_manager.__exit__(exc_type, exc_val, exc_tb)
            
        self._end_span(trace_id, span_id, exc_type, exc_val)
        self._cleanup_otel_baggage()
        self._reset_context()

    def __call__(self, func: Callable):
        # Create a factory for fresh instances to ensure task-safety when used as a decorator
        def _get_cm():
            return RevgateTracing(
                customer_id=self.customer_id,
                product_event_name=self.product_event_name,
                product_metadata=self.product_metadata
            )

        if inspect.isasyncgenfunction(func):
            @functools.wraps(func)
            async def async_gen_wrapper(*args, **kwargs):
                async with _get_cm():
                    async for item in func(*args, **kwargs):
                        yield item
            return async_gen_wrapper

        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                async with _get_cm():
                    return await func(*args, **kwargs)
            return async_wrapper

        if inspect.isgeneratorfunction(func):
            @functools.wraps(func)
            def sync_gen_wrapper(*args, **kwargs):
                with _get_cm():
                    for item in func(*args, **kwargs):
                        yield item
            return sync_gen_wrapper

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            with _get_cm():
                return func(*args, **kwargs)
        return sync_wrapper

    def _setup_context(self):
        """
        Set up ContextData for this context. ContextData syncs with OTel baggage
        so that track_event() can read values correctly.
        """
        # Sync with OTel baggage if available
        if OTEL_AVAILABLE and self.baggage_token:
            # Baggage already set by _prepare_otel_baggage(), sync ContextData to match
            if self.customer_id is not None:
                self.context_tokens["revgate.customer.id"] = ContextData.set("revgate.customer.id", self.customer_id)
            if self.product_event_name is not None:
                self.context_tokens["revgate.product.event.name"] = ContextData.set("revgate.product.event.name", self.product_event_name)
            if self.product_metadata:
                existing_meta = ContextData.get("revgate.product.metadata") or {}
                new_meta = {**existing_meta, **self.product_metadata}
                self.context_tokens["revgate.product.metadata"] = ContextData.set("revgate.product.metadata", new_meta)

    def _reset_context(self):
        ContextData.reset(self.context_tokens)

    def _start_span(self):
        """
        Start an OTel span. Attributes are read from:
        1. Explicitly set values in this context (highest priority)
        2. Parent context baggage values (for nested contexts)
        """
        tracer = _get_otel_tracer()
        if tracer:
            # Get values from this context, falling back to baggage (which carries parent values)
            cust_id = self.customer_id
            prod_event = self.product_event_name
            prod_meta = self.product_metadata

            # If not explicitly set, try to inherit from parent baggage
            if cust_id is None and OTEL_AVAILABLE:
                cust_id = baggage.get_baggage("revgate.customer.id")
            if prod_event is None and OTEL_AVAILABLE:
                prod_event = baggage.get_baggage("revgate.product.event.name")
            if not prod_meta and OTEL_AVAILABLE:
                prod_meta = baggage.get_baggage("revgate.product.metadata")

            attrs = {}
            if cust_id:
                attrs["revgate.customer.id"] = cust_id
            if prod_event:
                attrs["revgate.product.event.name"] = prod_event
            if prod_meta:
                for k, v in prod_meta.items():
                    attrs[f"revgate.product.metadata.{k}"] = str(v)

            self.otel_context_manager = tracer.start_as_current_span(self.name, attributes=attrs)
        else:
            logger.warning(f"OTEL tracer unavailable. Running without reporting span: {self.name}")

    def _end_span(self, trace_id, span_id, exc_type=None, exc_val=None):
        status = "ERROR" if exc_type else "OK"
        logger.info(f"[TRACING] END SPAN: {self.name} | TraceID: {trace_id} | SpanID: {span_id} | Status: {status}")

def revgate_tracing(**kwargs):
    return RevgateTracing(**kwargs)
