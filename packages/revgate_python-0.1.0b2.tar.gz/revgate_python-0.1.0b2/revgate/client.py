import typing
from .config import config
from .tracing import revgate_tracing, track_event
class Revgate:
    def __init__(self, api_key: typing.Optional[str] = None):
        self.api_key = api_key or config.api_key
    
    # Expose static/helper methods for convenience if needed
    # although decorators are usually used directly from the module.
    
    @property
    def billing(self):
        from .tracing import events
        return events

# For ease of use like `from revgate import Revgate`
