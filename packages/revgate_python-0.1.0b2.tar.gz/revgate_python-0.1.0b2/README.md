# Revgate SDK

The Revgate SDK provides a simple interface for tracing, billing, and observing your AI applications. It supports both manual event tracking and automatic instrumentation for popular AI libraries.

## 1. SDK Structure

The SDK is organized into the following modules:

*   **`revgate`**: Top-level package exposing the main `Revgate` client and key functions.
*   **`revgate.client`**: Contains the `Revgate` class for managing the connection and accessing sub-clients (e.g., `billing`).
*   **`revgate.tracing`**: The core tracing module.
    *   **`revgate.tracing.core`**: Handles OpenTelemetry (OTEL) integration and span management.
    *   **`revgate.tracing.events`**: Defines custom event tracking (e.g., billing events).
    *   **`revgate.tracing.autoinstrumentation`**: Provides automatic instrumentation for AI libraries.
*   **`revgate.logger`**: Centralized logging configuration.

## 2. Usage

### Installation

**Basic Installation (Core)**
Lightweight install with just the core dependencies.
```bash
pip install revgate-python
```

**With Specific Integrations**
Install support for specific AI libraries to enable auto-instrumentation.
```bash
# For specific providers
pip install "revgate-python[openai]"
pip install "revgate-python[anthropic,langchain]"
pip install "revgate-python[google-genai]"

# For all supported integrations
pip install "revgate-python[all]"
```

**Development Setup**
For contributors or local development, install in editable mode with all features.
```bash
# From the root of the repository
pip install -e ".[all]"
```

### Auto-Instrumentation

Revgate can automatically trace calls to supported AI libraries like Google GenAI, OpenAI, Anthropic, and LangChain. This captures spans, prompts, completions, and token usage without manual instrumentation.

**Example with Google GenAI:**

```python
import os
from revgate import auto_instrument, Revgate

# 1. Initialize Auto-Instrumentation
# This must be called before using the AI library.
# Supported libraries: "google-genai", "openai", "anthropic", "langchain"
auto_instrument(["google-genai"])

# 2. Use the AI library as usual
from google import genai

client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
response = client.chats.create(model='gemini-1.5-flash').send_message("Hello!")

print(response.text)
# A trace is automatically generated and sent to the configured OTEL collector.
```

### Manual Event Tracking (Billing)

For custom business logic or billing events that are not captured by auto-instrumentation, you can use `track_event`.

**Example:**

```python
from revgate import Revgate

client = Revgate()

# Track a billable event
client.billing.track_event(
    name="llm_call",
    metadata={
        "model": "gemini-1.5-flash",
        "tokens": 150,
        "cost": 0.00015,
        "currency": "USD",
        "user_id": "user_123"
    }
)

# Track a signal (non-billable)
client.billing.track_event(
    name="tool_execution",
    metadata={
        "tool": "search_db",
        "status": "success"
    }
)
```

### Configuration

The SDK uses environment variables for configuration:

*   `REVGATE_ENABLED`: Enable/disable tracing and event tracking (default: `true`).
*   `REVGATE_BASE_URL`: Revgate base URL (default: `http://dev.revgate.com`).
*   `REVGATE_API_KEY`: Your Revgate API key.
*   `REVGATE_OTEL_EXPORTER_TYPE`: OTLP exporter type - `proto` or `json` (default: `proto`).
*   `REVGATE_OTEL_EXPORT_MODE`: Span export mode - `batch` or `simple` (default: `batch`).
*   `REVGATE_ENABLE_CONSOLE_LOGGING`: Enable console span exporter for debugging (default: `false`).
*   `REVGATE_LOG_LEVEL`: Logging level (default: `INFO`).

## 3. Development & Release

### Local Development
To set up the environment for development:
```bash
# Install in editable mode with all dependencies
pip install -e ".[all]"
```

### Building the Package
To build the distribution files (wheel and source archive) locally:

1. **Install build tools:**
   ```bash
   pip install build
   ```

2. **Run the build:**
   ```bash
   python -m build
   ```
   This creates a `dist/` directory containing the `.whl` and `.tar.gz` files.

3. **Install the built wheel:**
   ```bash
   pip install dist/*.whl
   # Note: Validates that the package installs correctly.
   ```

### Publishing (Manual)
To verify the upload or publish manually:

1. **Install Twine:**
   ```bash
   pip install twine
   ```

2. **Upload:**
   ```bash
   twine upload dist/*
   ```
