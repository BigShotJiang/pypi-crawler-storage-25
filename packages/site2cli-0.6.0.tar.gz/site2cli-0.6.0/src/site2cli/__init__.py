"""site2cli: Turn any website into a CLI/API for AI agents."""

__version__ = "0.6.0"
