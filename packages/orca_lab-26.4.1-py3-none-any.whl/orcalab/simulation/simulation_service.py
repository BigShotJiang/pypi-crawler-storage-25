import asyncio
from io import TextIOWrapper
import os
import subprocess
import sys
import logging
from typing import List, override
from PySide6 import QtCore, QtWidgets, QtGui

from orcalab.cli_options import create_argparser
from orcalab.project_util import get_user_log_folder

if sys.platform != "win32":
    import pty
else:
    try:
        import winpty as _winpty

        _WINPTY_AVAILABLE = True
    except ImportError:
        _WINPTY_AVAILABLE = False


from orcalab.application_bus import ApplicationRequestBus
from orcalab.application_util import get_local_scene, get_remote_scene
from orcalab.simulation.simulation_bus import (
    SimulationNotificationBus,
    SimulationRequest,
    SimulationRequestBus,
    SimulationState,
)
from orcalab.ui.launch_dialog import LaunchDialog
from orcalab.ui.terminal_widget import TerminalWidget
from orcalab.config_service import ConfigService
from qasync import asyncWrap

logger = logging.getLogger(__name__)


class SimulationService(SimulationRequest):
    def __init__(self):
        self._sim_process_check_lock = asyncio.Lock()
        self.sim_process_running = False
        self.sim_process: subprocess.Popen | None = None
        self._win_pty: "_winpty.PtyProcess | None" = None
        self._sim_state = SimulationState.Stopped
        self._pty_master_fd: int | None = None
        self._log_file: TextIOWrapper | None = None
        self._redirect_to_widget = True

    def connect_bus(self):
        SimulationRequestBus.connect(self)

    def disconnect_bus(self):
        SimulationRequestBus.disconnect(self)

    @property
    def terminal(self) -> TerminalWidget | None:
        terminal = getattr(self, "_terminal", None)
        if isinstance(terminal, TerminalWidget):
            return terminal

        output = []
        ApplicationRequestBus().get_widget("terminal", output)
        if output and isinstance(output[0], TerminalWidget):
            self._terminal = output[0]
            # 连接进程中断信号
            self._terminal.process_interrupted.connect(self._on_process_interrupted)
            return self._terminal

        return None

    def _on_process_interrupted(self):
        """处理进程被 Ctrl+C 中断"""
        asyncio.create_task(self.stop_sim())

    @property
    def local_scene(self):
        return get_local_scene()

    @property
    def remote_scene(self):
        return get_remote_scene()

    def show_launch_dialog(self):
        """显示启动对话框（同步版本）"""
        if self.sim_process_running:
            return

        dialog = LaunchDialog()

        # 连接信号直接到异步处理方法
        dialog.program_selected.connect(self._handle_program_selected_signal)
        dialog.no_external_program.connect(self._handle_no_external_program_signal)

        # 直接在主线程中执行对话框
        return dialog.exec()

    def _handle_program_selected_signal(self, program_name: str):
        """处理程序选择信号的包装函数"""
        asyncio.create_task(self._on_external_program_selected_async(program_name))

    def _handle_no_external_program_signal(self):
        """处理无外部程序信号的包装函数"""
        asyncio.create_task(self._on_no_external_program_async())

    async def _on_external_program_selected_async(self, program_name: str):
        """外部程序选择处理（异步版本）"""

        await self._set_simulation_state(SimulationState.Launching)

        self.config_service = ConfigService()
        program_config = self.config_service.get_external_program_config(program_name)

        if not program_config:
            logger.error("未找到程序配置: %s", program_name)
            await self._set_simulation_state(SimulationState.Failed)
            await self._set_simulation_state(SimulationState.Stopped)
            return

        await self.remote_scene.publish_scene()
        await asyncio.sleep(0.5)
        await self.remote_scene.save_state()
        await self.remote_scene.change_sim_state(True)
        await asyncio.sleep(0.5)

        # 启动外部程序 - 改为在主线程直接启动
        command = program_config.get("command", "python")
        args = []
        for arg in program_config.get("args", []):
            args.append(arg)

        success = await self._start_external_process(command, args)

        if success:
            self.sim_process_running = True

            asyncio.create_task(self._sim_process_check_loop())
            await self.remote_scene.set_sync_from_mujoco_to_scene(True)
            await self._set_simulation_state(SimulationState.Running)

            logger.info("外部程序 %s 启动成功", program_name)
        else:
            logger.error("外部程序 %s 启动失败", program_name)
            self._append_terminal(
                f"外部程序 {program_name} 启动失败，请检查命令配置或日志输出。\n"
            )
            try:
                await self.remote_scene.change_sim_state(False)
            except Exception as e:
                logger.exception("回滚模拟状态时发生错误: %s", e)
            finally:
                self.sim_process_running = False

            await self._set_simulation_state(SimulationState.Failed)
            await self._set_simulation_state(SimulationState.Stopped)

    async def _on_no_external_program_async(self):
        """无外部程序处理（异步版本）"""

        await self._set_simulation_state(SimulationState.Launching)

        await self.remote_scene.publish_scene()
        await asyncio.sleep(0.5)
        await self.remote_scene.save_state()
        await self.remote_scene.change_sim_state(True)
        await asyncio.sleep(0.5)

        # 启动一个虚拟的等待进程，保持终端活跃状态
        # 使用 sleep 命令创建一个长期运行的进程，这样 _sim_process_check_loop 就不会立即退出
        success = await self._start_external_process(
            sys.executable, ["-c", "import time; time.sleep(99999999)"]
        )

        if success:
            # 设置运行状态
            self.sim_process_running = True
            await self._set_simulation_state(SimulationState.Running)
            asyncio.create_task(self._sim_process_check_loop())
            await self.remote_scene.set_sync_from_mujoco_to_scene(True)

            # 在终端显示提示信息

            self._append_terminal("已切换到运行模式，等待外部程序连接...\n")
            self._append_terminal("模拟地址: localhost:50051\n")
            self._append_terminal("请手动启动外部程序并连接到上述地址\n")
            self._append_terminal("注意：当前运行的是虚拟等待进程，可以手动停止\n")
            logger.info("无外部程序模式已启动")
        else:
            logger.error("无外部程序模式启动失败")

    async def _start_external_process(self, command: str, args: list):
        """在主线程中启动外部进程"""
        try:
            # 构建完整的命令
            resolved_command = command
            if command in ("python", "python3"):
                resolved_command = sys.executable or command
            cmd = [resolved_command] + args

            if self._redirect_to_widget:
                if sys.platform != "win32":
                    # Linux/macOS: 使用 PTY 提供真实终端环境
                    master_fd, slave_fd = pty.openpty()
                    self._pty_master_fd = master_fd

                    self.sim_process = subprocess.Popen(
                        cmd,
                        stdin=slave_fd,
                        stdout=slave_fd,
                        stderr=slave_fd,
                        env=os.environ.copy(),
                        start_new_session=True,
                    )
                    os.close(slave_fd)
                    terminal = self.terminal
                    if terminal:
                        terminal.set_pty_process(self.sim_process, master_fd)
                else:
                    # Windows: 使用 ConPTY (pywinpty) 提供真实终端，使 sshkeyboard/msvcrt 正常工作
                    if not _WINPTY_AVAILABLE:
                        raise RuntimeError(
                            "pywinpty 未安装，请运行: pip install pywinpty"
                        )
                    self._pty_master_fd = None
                    self._win_pty = _winpty.PtyProcess.spawn(cmd)
                    self.sim_process = self._win_pty
                    terminal = self.terminal
                    if terminal:
                        terminal.set_win_pty_process(self._win_pty)
            else:
                # 重定向输出到文件
                log_file_path = get_user_log_folder() / "sim_output.log"

                if self._log_file:
                    self._log_file.close()
                    self._log_file = None

                self._log_file = open(log_file_path, "w", encoding="utf-8")
                self.sim_process = subprocess.Popen(
                    cmd,
                    env=os.environ.copy(),
                    start_new_session=True,
                    stdout=self._log_file,
                    stderr=self._log_file,
                )

            # 在terminal_widget中显示启动信息
            self._append_terminal(f"启动进程: {' '.join(cmd)}\n")
            self._append_terminal(f"工作目录: {os.getcwd()}\n")
            self._append_terminal("-" * 50 + "\n")
            logger.info("启动外部程序: %s", " ".join(cmd))

            if self._redirect_to_widget:
                # 启动输出读取线程
                if sys.platform != "win32":
                    self._start_pty_output_thread()
                else:
                    self._start_winpty_output_thread()

            return True

        except Exception as e:
            logger.exception("启动外部程序失败: %s", e)
            self._append_terminal(f"启动进程失败: {str(e)}\n")
            return False

    def _append_terminal(self, line: str):
        terminal = self.terminal
        if terminal:
            terminal._append_output(line)
        logger.info(line)

    def _start_pty_output_thread(self):
        """启动PTY输出读取线程"""
        import threading
        import select

        def read_pty_output():
            """从PTY主端读取输出"""
            try:
                while self.sim_process and self.sim_process.poll() is None:
                    if self._pty_master_fd is None:
                        break
                    # 使用select等待数据可读
                    rlist, _, _ = select.select([self._pty_master_fd], [], [], 0.1)
                    if rlist:
                        try:
                            data = os.read(self._pty_master_fd, 4096)
                            if data:
                                text = data.decode("utf-8", errors="replace")
                                self._append_terminal(text)
                            else:
                                break
                        except OSError:
                            break

                # 检查进程退出码
                if self.sim_process:
                    return_code = self.sim_process.poll()
                    if return_code is not None:
                        self._append_terminal(f"\n进程退出，返回码: {return_code}\n")

            except Exception as e:
                self._append_terminal(f"读取输出时出错: {str(e)}\n")

        self.output_thread = threading.Thread(target=read_pty_output, daemon=True)
        self.output_thread.start()

    def _start_winpty_output_thread(self):
        """启动 ConPTY 输出读取线程（Windows）"""
        import threading

        win_pty = self._win_pty

        def read_winpty_output():
            try:
                while win_pty.isalive():
                    try:
                        data = win_pty.read(4096)
                        if data:
                            self._append_terminal(data)
                    except EOFError:
                        break
                    except Exception:
                        break

                exit_code = win_pty.exitstatus
                self._append_terminal(f"\n进程退出，返回码: {exit_code}\n")
            except Exception as e:
                self._append_terminal(f"读取输出时出错: {str(e)}\n")

        self.output_thread = threading.Thread(target=read_winpty_output, daemon=True)
        self.output_thread.start()

    # SimulationRequest 接口实现

    @override
    async def start_simulation(self) -> None:

        # 只有全屏模式才允许通过命令行参数直接启动场景，否则一律弹出选择界面
        parser = create_argparser()
        args, unknown = parser.parse_known_args()

        full_screen = args.full_screen
        if full_screen:
            self._redirect_to_widget = False

        sim_config_cli = getattr(args, "sim_config", None)
        if full_screen and type(sim_config_cli) is str and sim_config_cli.strip():
            if sim_config_cli == "external":
                await self._on_no_external_program_async()
            else:
                await self._on_external_program_selected_async(sim_config_cli)

            if self._sim_state != SimulationState.Running:
                exit(0)
        else:
            await asyncWrap(self.show_launch_dialog)

    @override
    async def stop_simulation(self) -> None:
        await self.stop_sim()

    @override
    def get_simulation_state(self, out: List[SimulationState]) -> None:
        out.append(self._sim_state)

    async def stop_sim(self):
        if not self.sim_process_running:
            return

        async with self._sim_process_check_lock:

            await self.remote_scene.set_sync_from_mujoco_to_scene(False)
            self.sim_process_running = False

            if self.sim_process is not None:
                self._append_terminal("\n" + "-" * 50 + "\n")
                self._append_terminal("正在停止进程...\n")

                if self._win_pty is not None:
                    try:
                        self._win_pty.terminate(force=True)
                        self._append_terminal("进程已终止\n")
                    except Exception:
                        pass
                    self._win_pty = None
                else:
                    self.sim_process.terminate()
                    try:
                        self.sim_process.wait(timeout=5)
                        self._append_terminal("进程已正常终止\n")
                    except subprocess.TimeoutExpired:
                        self.sim_process.kill()
                        self.sim_process.wait()
                        self._append_terminal("进程已强制终止\n")

                # 关闭PTY主端（Linux/macOS）
                if self._pty_master_fd is not None:
                    try:
                        os.close(self._pty_master_fd)
                    except OSError:
                        pass
                    self._pty_master_fd = None

                self.sim_process = None
                terminal = self.terminal
                if terminal:
                    terminal.clear_pty_process()

                if self._log_file:
                    self._log_file.close()
                    self._log_file = None

            await asyncio.sleep(0.5)
            await self.remote_scene.restore_state()
            await self.remote_scene.publish_scene()
            await self.remote_scene.change_sim_state(self.sim_process_running)

            await self._set_simulation_state(SimulationState.Stopped)

    async def _sim_process_check_loop(self):
        async with self._sim_process_check_lock:
            if not self.sim_process_running:
                return

            if self.sim_process is not None:
                # Windows ConPTY 用 isalive()，其他用 poll()
                if self._win_pty is not None:
                    alive = self._win_pty.isalive()
                    code = self._win_pty.exitstatus if not alive else None
                else:
                    code = self.sim_process.poll()
                    alive = code is None

                if not alive:
                    logger.info("外部进程已退出，返回码 %s", code)
                    self.sim_process_running = False
                    if self._win_pty is not None:
                        self._win_pty = None
                    if self._pty_master_fd is not None:
                        try:
                            os.close(self._pty_master_fd)
                        except OSError:
                            pass
                        self._pty_master_fd = None
                    self.sim_process = None
                    terminal = self.terminal
                    if terminal:
                        terminal.clear_pty_process()
                    await self.remote_scene.set_sync_from_mujoco_to_scene(False)
                    await self.remote_scene.change_sim_state(self.sim_process_running)
                    await self._set_simulation_state(SimulationState.Failed)
                    await self._set_simulation_state(SimulationState.Stopped)
                    return

        frequency = 0.5  # Hz
        await asyncio.sleep(1 / frequency)
        asyncio.create_task(self._sim_process_check_loop())

    async def _set_simulation_state(self, new_state: SimulationState):
        old_state = self._sim_state

        valid_transitions = {
            SimulationState.Stopped: [
                SimulationState.Launching,
            ],
            SimulationState.Launching: [
                SimulationState.Running,
                SimulationState.Failed,
            ],
            SimulationState.Running: [
                SimulationState.Stopped,
                SimulationState.Failed,
            ],
            SimulationState.Failed: [
                SimulationState.Stopped,
            ],
        }

        valid_states = valid_transitions.get(old_state, [])
        if new_state not in valid_states:
            raise ValueError(
                f"Invalid state transition from {old_state} to {new_state}"
            )

        self._sim_state = new_state
        bus = SimulationNotificationBus()
        await bus.on_simulation_state_changed(old_state, new_state)
