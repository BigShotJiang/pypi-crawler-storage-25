from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Optional

import typer

from .config import load_config
from .dispatcher import run_scan
from .models import Severity

app = typer.Typer(
    name="shieldctl",
    help="Infrastructure security scanner for Terraform, shell, YAML, Dockerfiles, and Python.",
    add_completion=False,
    no_args_is_help=True,
)


class OutputFormat(str, Enum):
    terminal = "terminal"
    json = "json"
    html = "html"


class FailOn(str, Enum):
    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


@app.command()
def scan(
    path: Path = typer.Argument(Path("."), help="Path to scan"),
    fail_on: FailOn = typer.Option(
        None,
        "--fail-on",
        help="Minimum severity that causes a non-zero exit. Overrides .shieldctl.yaml.",
    ),
    format: OutputFormat = typer.Option(OutputFormat.terminal, "--format", "-f"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Write report to file"),
    changed_only: bool = typer.Option(
        False, "--changed-only", help="Only scan files changed vs git HEAD / main"
    ),
    scanner: Optional[str] = typer.Option(
        None, "--scanner", help="Run a single scanner by name (e.g. terraform, bash)"
    ),
    strict: bool = typer.Option(
        False,
        "--strict",
        help="Fail immediately if a required scanner tool is not installed.",
    ),
) -> None:
    root = path.resolve()
    if not root.exists():
        typer.echo(f"Error: path '{root}' does not exist", err=True)
        raise typer.Exit(1)

    config = load_config(root)
    if fail_on is not None:
        config.fail_on = Severity.from_str(fail_on.value)

    from .scanners.base import ScannerError
    try:
        findings = run_scan(
            root, config,
            changed_only=changed_only,
            scanner_filter=scanner,
            strict=strict,
        )
    except ScannerError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(4)

    # Select reporter
    if format == OutputFormat.terminal:
        from .reporters.terminal import TerminalReporter
        reporter = TerminalReporter()
    elif format == OutputFormat.json:
        from .reporters.json_reporter import JsonReporter
        reporter = JsonReporter()
    else:
        from .reporters.html_reporter import HtmlReporter
        reporter = HtmlReporter()

    content = reporter.render(findings)

    if output:
        output.write_text(content)
        typer.echo(f"Report written to {output}")
    elif format != OutputFormat.terminal:
        typer.echo(content)
    # terminal reporter prints directly to stdout via rich

    # Exit code based on highest severity found
    if not findings:
        raise typer.Exit(0)

    max_sev = max(f.severity for f in findings)
    if max_sev >= config.fail_on:
        raise typer.Exit(3)
    raise typer.Exit(0)


@app.command("install-tools")
def install_tools(
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Show what would be installed without doing it."
    ),
) -> None:
    """Install all scanner dependencies (checkov, tfsec, shellcheck, etc.)."""
    from rich.console import Console
    from rich.table import Table
    from rich import box
    from .install import install_all

    con = Console()
    con.print("\n[bold]Installing shieldctl scanner dependencies…[/bold]\n")

    results = install_all(dry_run=dry_run)

    table = Table(box=box.SIMPLE_HEAD)
    table.add_column("Tool", width=14)
    table.add_column("Status", width=10)
    table.add_column("Note")

    status_style = {"ok": "green", "skipped": "dim", "failed": "red"}
    failed = []
    for r in results:
        style = status_style.get(r.status, "")
        table.add_row(r.tool, f"[{style}]{r.status}[/{style}]", r.note)
        if r.status == "failed":
            failed.append(r.tool)

    con.print(table)

    if failed:
        con.print(f"\n[red]Failed to install: {', '.join(failed)}[/red]")
        con.print("Install them manually — see each tool's documentation.")
        raise typer.Exit(1)
    else:
        con.print("[green]All tools ready.[/green]\n")


@app.command(hidden=True)
def version() -> None:
    """Print version."""
    typer.echo("shieldctl 0.1.0")
