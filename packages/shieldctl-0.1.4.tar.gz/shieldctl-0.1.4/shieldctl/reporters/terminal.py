from __future__ import annotations

from collections import Counter

from rich import box
from rich.console import Console
from rich.padding import Padding
from rich.table import Table
from rich.text import Text

from ..models import Finding, Severity

_BADGE: dict[Severity, tuple[str, str]] = {
    Severity.CRITICAL: ("bold white on red",         "CRITICAL"),
    Severity.HIGH:     ("bold white on dark_orange",  "HIGH"),
    Severity.MEDIUM:   ("bold black on yellow",       "MEDIUM"),
    Severity.LOW:      ("bold white on blue",         "LOW"),
    Severity.INFO:     ("bold white on grey50",       "INFO"),
}

_SEV_STYLE: dict[Severity, str] = {
    Severity.CRITICAL: "bold red",
    Severity.HIGH:     "bold dark_orange",
    Severity.MEDIUM:   "bold yellow",
    Severity.LOW:      "bold cyan",
    Severity.INFO:     "dim",
}

console = Console(highlight=False, width=160)


def _location(f: Finding) -> str:
    return f"{f.file}:{f.line}" if f.line else f.file


class TerminalReporter:
    def render(self, findings: list[Finding]) -> str:
        if not findings:
            console.print(Padding("[bold green]✓  No findings.[/bold green]", (1, 2)))
            return ""

        console.print()

        sorted_findings = sorted(
            findings, key=lambda x: (-x.severity, x.file, x.line or 0)
        )

        table = Table(
            box=box.HORIZONTALS,
            show_header=True,
            show_edge=True,
            show_lines=True,
            header_style="bold",
            padding=(0, 1),
        )
        table.add_column("Severity",  no_wrap=True, min_width=10, max_width=10)
        table.add_column("Rule",      no_wrap=True, min_width=20, max_width=28)
        table.add_column("Scanner",   no_wrap=True, min_width=10, max_width=14)
        table.add_column("Location",  no_wrap=True, min_width=24, max_width=44)
        table.add_column("Message",   no_wrap=True, min_width=20, max_width=60)

        for f in sorted_findings:
            badge_style, badge_label = _BADGE[f.severity]
            sev_cell = Text(f"  {badge_label}  ", style=badge_style)
            msg = f.message if len(f.message) <= 80 else f.message[:77] + "..."
            table.add_row(
                sev_cell,
                Text(f.rule, style="bold"),
                Text(f.scanner, style="dim"),
                Text(_location(f), style=_SEV_STYLE[f.severity]),
                Text(msg),
            )

        console.print(Padding(table, (0, 2)))
        console.print()

        # Summary bar
        counts = Counter(f.severity for f in findings)
        total = len(findings)

        bar = Text(f"  {total} finding{'s' if total != 1 else ''}    ")
        for sev in reversed(Severity):
            if not counts[sev]:
                continue
            badge_style, badge_label = _BADGE[sev]
            bar.append(f"  {badge_label}  ", style=badge_style)
            bar.append(f"  {counts[sev]}   ", style="bold")

        console.print(bar)
        console.print()

        return ""
