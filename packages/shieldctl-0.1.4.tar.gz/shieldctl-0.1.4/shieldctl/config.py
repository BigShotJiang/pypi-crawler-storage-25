from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .models import Severity

_DEFAULTS = {
    "fail_on": "HIGH",
    "exclude_paths": [
        "**/.terraform/**",
        "**/.terragrunt-cache/**",
        "**/node_modules/**",
        "**/.git/**",
        "**/.venv/**",
        "**/venv/**",
        "**/env/**",
        "**/__pycache__/**",
        "**/*.egg-info/**",
        "**/dist/**",
        "**/build/**",
    ],
    "suppress": [],
}


@dataclass
class Suppression:
    rule: str
    reason: str = ""


@dataclass
class ShieldConfig:
    fail_on: Severity
    exclude_paths: list[str]
    suppress: list[Suppression]

    def is_suppressed(self, rule: str) -> bool:
        return any(s.rule == rule for s in self.suppress)


def load_config(path: Path) -> ShieldConfig:
    raw = dict(_DEFAULTS)
    config_file = path / ".shieldctl.yaml"
    if config_file.exists():
        try:
            with config_file.open() as f:
                override = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid .shieldctl.yaml: {e}")
        raw.update(override)

    suppressions = [
        Suppression(rule=s["rule"], reason=s.get("reason", ""))
        for s in raw.get("suppress", [])
        if s.get("rule")
    ]

    return ShieldConfig(
        fail_on=Severity.from_str(raw["fail_on"]),
        exclude_paths=raw["exclude_paths"],
        suppress=suppressions,
    )
