"""Tests for CLI exit code behaviour with --fail-on threshold."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from shieldctl.cli import app
from shieldctl.models import Finding, Severity

runner = CliRunner()


def _finding(severity: Severity) -> Finding:
    return Finding(
        file="test.py",
        line=1,
        rule="TEST-001",
        severity=severity,
        message="test finding",
        remediation="",
        scanner="test",
    )


def _run(findings: list[Finding], fail_on: str = "HIGH") -> int:
    with patch("shieldctl.cli.run_scan", return_value=findings):
        result = runner.invoke(app, ["scan", ".", "--fail-on", fail_on])
    return result.exit_code


# ── No findings always exits 0 ────────────────────────────────────────────────

def test_no_findings_exits_0():
    assert _run([]) == 0


# ── Findings below threshold exit 0 ──────────────────────────────────────────

def test_low_findings_with_fail_on_high_exits_0():
    assert _run([_finding(Severity.LOW)], fail_on="HIGH") == 0


def test_medium_findings_with_fail_on_high_exits_0():
    assert _run([_finding(Severity.MEDIUM)], fail_on="HIGH") == 0


def test_low_findings_with_fail_on_critical_exits_0():
    assert _run([_finding(Severity.LOW)], fail_on="CRITICAL") == 0


def test_high_findings_with_fail_on_critical_exits_0():
    assert _run([_finding(Severity.HIGH)], fail_on="CRITICAL") == 0


# ── Findings at or above threshold exit 3 ────────────────────────────────────

def test_high_findings_with_fail_on_high_exits_3():
    assert _run([_finding(Severity.HIGH)], fail_on="HIGH") == 3


def test_critical_findings_with_fail_on_high_exits_3():
    assert _run([_finding(Severity.CRITICAL)], fail_on="HIGH") == 3


def test_critical_findings_with_fail_on_critical_exits_3():
    assert _run([_finding(Severity.CRITICAL)], fail_on="CRITICAL") == 3


def test_medium_findings_with_fail_on_medium_exits_3():
    assert _run([_finding(Severity.MEDIUM)], fail_on="MEDIUM") == 3


# ── Mixed severities use the highest ─────────────────────────────────────────

def test_mixed_findings_highest_triggers_threshold():
    findings = [_finding(Severity.LOW), _finding(Severity.HIGH)]
    assert _run(findings, fail_on="HIGH") == 3


def test_mixed_findings_below_threshold_exits_0():
    findings = [_finding(Severity.LOW), _finding(Severity.MEDIUM)]
    assert _run(findings, fail_on="HIGH") == 0
