from . import server
import asyncio

from contextlib import suppress


def main():
    with suppress(asyncio.CancelledError, KeyboardInterrupt):
        asyncio.run(server.run())


__all__ = ["main", "server"]
