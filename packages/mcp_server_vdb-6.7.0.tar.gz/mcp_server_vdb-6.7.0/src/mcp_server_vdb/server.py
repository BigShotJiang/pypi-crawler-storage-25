import json
import logging
import os
import sys
from contextlib import asynccontextmanager
from importlib.metadata import PackageNotFoundError, version as pkg_version
from typing import Any, AsyncIterator
from urllib.parse import unquote

import apsw
import mcp.server.stdio
import mcp.types as mtypes
from mcp.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from pydantic import AnyUrl

from vdb.lib import config, db6 as db_lib, search
from vdb.lib.utils import COMPACT_SOURCE_DATA_DUMP_OPTIONS

if sys.platform == "win32" and os.environ.get("PYTHONIOENCODING") is None:
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

logger = logging.getLogger("mcp_server_vdb")

VDB_AGE_DAYS = os.getenv("VDB_AGE_DAYS", "2")
if VDB_AGE_DAYS.isdigit():
    VDB_AGE_DAYS = int(VDB_AGE_DAYS)

try:
    SERVER_VERSION = pkg_version("mcp-server-vdb")
except PackageNotFoundError:
    SERVER_VERSION = "6.7.0"

db_conn: apsw.Connection | None = None
index_conn: apsw.Connection | None = None

ORAS_AVAILABLE = False
try:
    from vdb.lib.orasclient import download_image

    ORAS_AVAILABLE = True
except ImportError:
    pass


SERVER_INSTRUCTIONS = """
This MCP server exposes AppThreat vulnerability-db as a structured search and triage service.

Use it to:
- search by purl, cpe, url, advisory id, alias, package name, reference, symbol, or free text
- summarize or deeply inspect SBOMs
- filter results by severity, source, dates, malware, package scope, and ecosystem
- retrieve health, metadata, source, malware, CVE, and purl resources
"""

COMMON_FILTER_PROPERTIES: dict[str, Any] = {
    "severity_threshold": {
        "type": "string",
        "enum": ["LOW", "MEDIUM", "HIGH", "CRITICAL"],
    },
    "source": {
        "oneOf": [
            {"type": "string", "enum": ["osv", "nvd", "github", "aqua"]},
            {
                "type": "array",
                "items": {"type": "string", "enum": ["osv", "nvd", "github", "aqua"]},
            },
        ]
    },
    "package_ecosystem": {"type": "string"},
    "published_after": {"type": "string"},
    "published_before": {"type": "string"},
    "updated_after": {"type": "string"},
    "updated_before": {"type": "string"},
    "malware_only": {"type": "boolean"},
    "exclude_malware": {"type": "boolean"},
    "app_only": {"type": "boolean"},
    "os_only": {"type": "boolean"},
    "with_data": {"type": "boolean"},
    "max_results": {"type": "integer", "minimum": 1},
    "page": {"type": "integer", "minimum": 1},
    "page_size": {"type": "integer", "minimum": 1},
    "summary_only": {"type": "boolean"},
    "include_references": {"type": "boolean"},
    "include_affected_symbols": {"type": "boolean"},
    "include_remediation": {"type": "boolean"},
    "include_evidence": {"type": "boolean"},
}

SEVERITY_ORDER = {"LOW": 1, "MEDIUM": 2, "HIGH": 3, "CRITICAL": 4}


def _severity_rank(severity: str | None) -> int:
    return SEVERITY_ORDER.get(str(severity or "").upper(), 0)


def _get_lifespan_state(server: Server) -> dict[str, Any]:
    return server.request_context.lifespan_context


async def _publish_startup_events(server: Server):
    try:
        state = _get_lifespan_state(server)
    except LookupError:
        return
    if state.get("startup_events_published"):
        return
    session = server.request_context.session
    for event in state.get("startup_events", []):
        await session.send_log_message(
            level=event["level"], data=event["message"], logger="vdb.startup"
        )
    state["startup_events_published"] = True


async def _progress(server: Server, progress: float, total: float, message: str):
    try:
        ctx = server.request_context
    except LookupError:
        return
    await ctx.session.send_progress_notification(
        progress_token=str(ctx.request_id),
        progress=progress,
        total=total,
        message=message,
        related_request_id=str(ctx.request_id),
    )


def _extract_filters(arguments: dict[str, Any]) -> dict[str, Any]:
    filters = {}
    for key in COMMON_FILTER_PROPERTIES:
        if key in arguments and arguments[key] is not None:
            if key == "source":
                filters["sources"] = arguments[key]
            else:
                filters[key] = arguments[key]
    return filters


def _serialize_result(
    result: dict[str, Any], options: dict[str, Any]
) -> dict[str, Any]:
    data = {
        "cve_id": result.get("cve_id"),
        "matched_by": result.get("matched_by"),
        "matching_vers": result.get("matching_vers"),
        "vers": result.get("vers"),
        "purl_prefix": result.get("purl_prefix"),
        "source": result.get("source"),
        "severity": result.get("severity"),
        "score": result.get("score"),
        "published": result.get("published"),
        "updated": result.get("updated"),
        "package_ecosystem": result.get("package_ecosystem"),
        "package_scope": result.get("package_scope"),
        "aliases": result.get("aliases") or [],
    }
    if options.get("include_remediation", True):
        data["fix_version"] = result.get("fix_version")
    if options.get("include_references"):
        data["references"] = result.get("references") or []
    if options.get("include_affected_symbols"):
        data["affected_symbols"] = result.get("affected_symbols") or []
    if options.get("include_evidence"):
        data["evidence"] = {
            "description": result.get("description"),
            "namespace": result.get("namespace"),
            "name": result.get("name"),
            "type": result.get("type"),
        }
    if options.get("with_data") and result.get("source_data"):
        data["source_data"] = result["source_data"].model_dump(
            **COMPACT_SOURCE_DATA_DUMP_OPTIONS
        )
    return data


def _result_summary(results: list[dict[str, Any]]) -> dict[str, Any]:
    severities = [
        result.get("severity") for result in results if result.get("severity")
    ]
    return {
        "result_count": len(results),
        "unique_cves": sorted(
            {result.get("cve_id") for result in results if result.get("cve_id")}
        ),
        "sources": sorted(
            {result.get("source") for result in results if result.get("source")}
        ),
        "max_severity": sorted(severities, key=_severity_rank)[-1]
        if severities
        else None,
    }


def _shape_list_payload(
    query: dict[str, Any], raw_results: list[dict[str, Any]], options: dict[str, Any]
) -> dict[str, Any]:
    shaped_results = [_serialize_result(result, options) for result in raw_results]
    payload = {
        "query": query,
        "summary": _result_summary(shaped_results),
        "results": shaped_results,
    }
    if options.get("summary_only"):
        payload.pop("results", None)
    return payload


def _shape_package_payload(
    query: dict[str, Any],
    package_results: list[dict[str, Any]],
    options: dict[str, Any],
) -> dict[str, Any]:
    packages = []
    for package in package_results:
        shaped = {
            "locator": package.get("locator"),
            "result_count": package.get("result_count"),
            "max_severity": package.get("max_severity"),
            "cve_ids": package.get("cve_ids"),
            "fix_versions": package.get("fix_versions"),
            "sources": package.get("sources"),
        }
        if not options.get("summary_only"):
            shaped["results"] = [
                _serialize_result(result, options)
                for result in package.get("results", [])
            ]
        packages.append(shaped)
    return {
        "query": query,
        "summary": {
            "package_count": len(packages),
            "matched_packages": len(
                [pkg for pkg in packages if pkg.get("result_count")]
            ),
            "vulnerability_count": sum(pkg.get("result_count", 0) for pkg in packages),
        },
        "packages": packages,
    }


def _shape_bom_payload(
    query: dict[str, Any], bom_result: dict[str, Any], options: dict[str, Any]
) -> dict[str, Any]:
    components = []
    for component in bom_result.get("components", []):
        shaped = {
            "locator": component.get("locator"),
            "result_count": component.get("result_count"),
            "max_severity": component.get("max_severity"),
            "cve_ids": component.get("cve_ids"),
            "fix_versions": component.get("fix_versions"),
            "sources": component.get("sources"),
        }
        if not options.get("summary_only") and component.get("results") is not None:
            shaped["results"] = [
                _serialize_result(result, options)
                for result in component.get("results", [])
            ]
        components.append(shaped)
    return {
        "query": query,
        "summary": bom_result.get("summary", {}),
        "components": components,
    }


def _tool_schema(primary_props: dict[str, Any], required: list[str]) -> dict[str, Any]:
    properties = dict(primary_props)
    properties.update(COMMON_FILTER_PROPERTIES)
    return {"type": "object", "properties": properties, "required": required}


def _health_payload(
    startup_events: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    db_meta = db_lib.get_db_file_metadata() or {}
    return {
        "status": "ok",
        "data_dir": config.DATA_DIR,
        "database_needs_update": db_lib.needs_update(
            days=VDB_AGE_DAYS, default_status=True
        ),
        "metadata": db_meta,
        "startup_events": startup_events or [],
    }


def _resource_json(payload: dict[str, Any] | list[dict[str, Any]]) -> str:
    return json.dumps(payload, indent=2, sort_keys=True)


async def run():
    @asynccontextmanager
    async def server_lifespan(server: Server) -> AsyncIterator[dict[str, Any]]:
        global db_conn, index_conn
        startup_events: list[dict[str, Any]] = []

        def event(level: str, message: str):
            startup_events.append({"level": level, "message": message})
            logger.log(logging.INFO if level == "info" else logging.WARNING, message)

        try:
            if db_lib.needs_update(days=VDB_AGE_DAYS, default_status=True):
                event("info", "Vulnerability database is stale or missing.")
                if ORAS_AVAILABLE:
                    db_url = config.VDB_APP_ONLY_DATABASE_URL
                    event(
                        "info",
                        f"Downloading database from {db_url} into {config.DATA_DIR}.",
                    )
                    download_image(db_url, config.DATA_DIR)
                    event("info", "Database download completed.")
                else:
                    event(
                        "warning",
                        "ORAS support is unavailable; automatic download was skipped.",
                    )
            else:
                event("info", f"Using cached database from {config.DATA_DIR}.")
            db_conn, index_conn = db_lib.get()
            yield {
                "db_conn": db_conn,
                "index_conn": index_conn,
                "startup_events": startup_events,
                "startup_events_published": False,
            }
        finally:
            if db_conn:
                db_conn.close()
            if index_conn:
                index_conn.close()

    server = Server(
        "appthreat-vulnerability-db",
        version=SERVER_VERSION,
        instructions=SERVER_INSTRUCTIONS,
        lifespan=server_lifespan,
    )

    @server.list_resources()
    async def handle_list_resources() -> list[mtypes.Resource]:
        return [
            mtypes.Resource(
                uri=AnyUrl("vdb://metadata"),
                name="VDB metadata",
                description="Metadata about the active vulnerability database.",
                mimeType="application/json",
            ),
            mtypes.Resource(
                uri=AnyUrl("vdb://health"),
                name="VDB health",
                description="Operational health, freshness, and startup event information.",
                mimeType="application/json",
            ),
            mtypes.Resource(
                uri=AnyUrl("vdb://sources"),
                name="VDB sources",
                description="Configured vulnerability data sources for the active database.",
                mimeType="application/json",
            ),
            mtypes.Resource(
                uri=AnyUrl("vdb://malware/latest"),
                name="Latest malware",
                description="Recent malware records from the vulnerability database.",
                mimeType="application/json",
            ),
        ]

    @server.list_resource_templates()
    async def handle_list_resource_templates() -> list[mtypes.ResourceTemplate]:
        return [
            mtypes.ResourceTemplate(
                uriTemplate="cve://{id}",
                name="CVE record",
                description="Structured results for a CVE or advisory identifier.",
                mimeType="application/json",
            ),
            mtypes.ResourceTemplate(
                uriTemplate="purl://{purl}",
                name="PURL search",
                description="Structured results for a package URL search.",
                mimeType="application/json",
            ),
        ]

    @server.read_resource()
    async def handle_read_resource(uri: AnyUrl) -> str:
        await _publish_startup_events(server)
        uri_str = str(uri)
        state = _get_lifespan_state(server)
        if uri_str == "vdb://metadata":
            return _resource_json(db_lib.get_db_file_metadata() or {})
        if uri_str == "vdb://health":
            return _resource_json(_health_payload(state.get("startup_events")))
        if uri_str == "vdb://sources":
            metadata = db_lib.get_db_file_metadata() or {}
            return _resource_json({"sources": metadata.get("sources", [])})
        if uri_str == "vdb://malware/latest":
            malware = next(search.latest_malware(with_limit=10, with_data=True), [])
            return _resource_json(
                _shape_list_payload(
                    {"resource": uri_str},
                    malware,
                    {"with_data": True, "summary_only": False},
                )
            )
        if uri_str.startswith("cve://"):
            cve_id = uri_str.replace("cve://", "", 1).split("/", maxsplit=1)[0]
            return _resource_json(
                _shape_list_payload(
                    {"cve_id": cve_id},
                    search.search_by_cve(cve_id, with_data=True),
                    {
                        "with_data": True,
                        "summary_only": False,
                        "include_references": True,
                        "include_affected_symbols": True,
                        "include_remediation": True,
                        "include_evidence": True,
                    },
                )
            )
        if uri_str.startswith("purl://"):
            purl = unquote(uri_str.replace("purl://", "", 1))
            return _resource_json(
                _shape_list_payload(
                    {"purl": purl},
                    search.search_by_purl_like(purl, with_data=True),
                    {
                        "with_data": True,
                        "summary_only": False,
                        "include_references": True,
                        "include_affected_symbols": True,
                        "include_remediation": True,
                        "include_evidence": True,
                    },
                )
            )
        raise ValueError(f"Unsupported resource URI: {uri_str}")

    prompts = {
        "search-vulnerabilities": {
            "description": "Search for vulnerabilities for the given package or locator.",
            "arguments": [
                mtypes.PromptArgument(
                    name="search",
                    description="PURL, CPE, URL, or advisory id",
                    required=True,
                )
            ],
        },
        "cve-info": {
            "description": "Get detailed information about a CVE or advisory.",
            "arguments": [
                mtypes.PromptArgument(
                    name="cve_id", description="CVE or advisory id", required=True
                )
            ],
        },
        "list-malware": {
            "description": "List recent malware records.",
            "arguments": [
                mtypes.PromptArgument(
                    name="count", description="Number of malware results", required=True
                )
            ],
        },
        "assess-package-risk": {
            "description": "Assess risk, severity, remediation, and source evidence for a package.",
            "arguments": [
                mtypes.PromptArgument(
                    name="package",
                    description="Package locator such as a purl",
                    required=True,
                )
            ],
        },
        "triage-cve": {
            "description": "Triage a CVE with severity, scope, references, and remediation guidance.",
            "arguments": [
                mtypes.PromptArgument(
                    name="cve_id", description="CVE or advisory id", required=True
                )
            ],
        },
        "summarize-sbom-risk": {
            "description": "Summarize vulnerability risk across an SBOM.",
            "arguments": [
                mtypes.PromptArgument(
                    name="bom_hint",
                    description="Short description or path hint for the SBOM",
                    required=True,
                )
            ],
        },
        "identify-fix-priority": {
            "description": "Identify the highest priority remediation targets from vulnerability results.",
            "arguments": [
                mtypes.PromptArgument(
                    name="package", description="Package locator", required=True
                )
            ],
        },
        "explain-version-match": {
            "description": "Explain why a version matched a vulnerability range.",
            "arguments": [
                mtypes.PromptArgument(
                    name="search",
                    description="Package locator or advisory id",
                    required=True,
                )
            ],
        },
        "review-custom-overlay-impact": {
            "description": "Review how custom overlay data may change effective vulnerability results.",
            "arguments": [
                mtypes.PromptArgument(
                    name="package", description="Package locator", required=True
                )
            ],
        },
    }

    @server.list_prompts()
    async def handle_list_prompts() -> list[mtypes.Prompt]:
        return [
            mtypes.Prompt(
                name=name,
                description=value["description"],
                arguments=value["arguments"],
            )
            for name, value in prompts.items()
        ]

    @server.get_prompt()
    async def handle_get_prompt(
        name: str, arguments: dict[str, str] | None
    ) -> mtypes.GetPromptResult:
        arguments = arguments or {}
        if name == "search-vulnerabilities":
            text = f"Search {arguments['search']} for vulnerabilities, summarize the highest severities, and include remediation and evidence."
        elif name == "cve-info":
            text = f"Summarize {arguments['cve_id']} with severity, affected packages, fix versions, and evidence."
        elif name == "list-malware":
            text = f"List the latest {arguments['count']} malware entries and explain why they are risky."
        elif name == "assess-package-risk":
            text = f"Assess the risk for {arguments['package']} and prioritize fixes by severity, exploitability indicators, and source evidence."
        elif name == "triage-cve":
            text = f"Triage {arguments['cve_id']} and summarize package scope, fix versions, references, and confidence."
        elif name == "summarize-sbom-risk":
            text = f"Summarize the risk posture of the SBOM described as {arguments['bom_hint']} and group findings by package and severity."
        elif name == "identify-fix-priority":
            text = f"For {arguments['package']}, identify the fix priority order and explain the remediation path."
        elif name == "explain-version-match":
            text = f"Explain why {arguments['search']} matched or did not match known vulnerability version ranges."
        elif name == "review-custom-overlay-impact":
            text = f"Review how custom overlay data could change vulnerability results for {arguments['package']}."
        else:
            raise ValueError(f"Unknown prompt: {name}")
        return mtypes.GetPromptResult(
            description=prompts[name]["description"],
            messages=[
                mtypes.PromptMessage(
                    role="user", content=mtypes.TextContent(type="text", text=text)
                )
            ],
        )

    @server.list_tools()
    async def handle_list_tools() -> list[mtypes.Tool]:
        return [
            mtypes.Tool(
                name="search_by_purl_like",
                description="Search vulnerabilities for a Package URL.",
                inputSchema=_tool_schema(
                    {"purl": {"type": "string", "description": "PURL to search"}},
                    ["purl"],
                ),
            ),
            mtypes.Tool(
                name="search_by_any",
                description="Search vulnerabilities for a locator or advisory identifier.",
                inputSchema=_tool_schema(
                    {"search": {"type": "string", "description": "Search string"}},
                    ["search"],
                ),
            ),
            mtypes.Tool(
                name="search_by_cpe_like",
                description="Search vulnerabilities for a CPE string.",
                inputSchema=_tool_schema(
                    {"cpe": {"type": "string", "description": "CPE to search"}},
                    ["cpe"],
                ),
            ),
            mtypes.Tool(
                name="search_by_cve",
                description="Search vulnerabilities for a CVE or advisory identifier.",
                inputSchema=_tool_schema(
                    {"cve_id": {"type": "string", "description": "CVE or advisory id"}},
                    ["cve_id"],
                ),
            ),
            mtypes.Tool(
                name="search_by_url",
                description="Search vulnerabilities for a source repository URL.",
                inputSchema=_tool_schema(
                    {
                        "url": {
                            "type": "string",
                            "description": "Repository or package URL",
                        }
                    },
                    ["url"],
                ),
            ),
            mtypes.Tool(
                name="search_full_text",
                description="Search aliases, descriptions, references, and affected symbols using full text.",
                inputSchema=_tool_schema(
                    {"text": {"type": "string", "description": "Full-text query"}},
                    ["text"],
                ),
            ),
            mtypes.Tool(
                name="search_by_alias",
                description="Search by alternate advisory identifier such as GHSA or OSV alias.",
                inputSchema=_tool_schema(
                    {"alias": {"type": "string", "description": "Alias identifier"}},
                    ["alias"],
                ),
            ),
            mtypes.Tool(
                name="search_by_reference",
                description="Search by reference URL or domain.",
                inputSchema=_tool_schema(
                    {
                        "reference": {
                            "type": "string",
                            "description": "Reference URL or domain",
                        }
                    },
                    ["reference"],
                ),
            ),
            mtypes.Tool(
                name="search_by_package_name",
                description="Search by package name with ranking for exact and partial matches.",
                inputSchema=_tool_schema(
                    {
                        "package_name": {
                            "type": "string",
                            "description": "Package name or namespace/name",
                        }
                    },
                    ["package_name"],
                ),
            ),
            mtypes.Tool(
                name="search_by_symbol",
                description="Search by affected function or module name.",
                inputSchema=_tool_schema(
                    {
                        "symbol": {
                            "type": "string",
                            "description": "Function or module name",
                        }
                    },
                    ["symbol"],
                ),
            ),
            mtypes.Tool(
                name="search_packages",
                description="Search many locators in one request.",
                inputSchema=_tool_schema(
                    {
                        "packages": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "purl": {"type": "string"},
                                    "cpe": {"type": "string"},
                                    "url": {"type": "string"},
                                    "alias": {"type": "string"},
                                    "package_name": {"type": "string"},
                                    "search": {"type": "string"},
                                },
                            },
                        }
                    },
                    ["packages"],
                ),
            ),
            mtypes.Tool(
                name="search_bom_summary",
                description="Summarize vulnerabilities across an SBOM object or path.",
                inputSchema=_tool_schema(
                    {
                        "bom": {
                            "oneOf": [{"type": "string"}, {"type": "object"}],
                            "description": "CycloneDX BOM path or object",
                        }
                    },
                    ["bom"],
                ),
            ),
            mtypes.Tool(
                name="search_bom_detailed",
                description="Return detailed vulnerabilities across an SBOM object or path.",
                inputSchema=_tool_schema(
                    {
                        "bom": {
                            "oneOf": [{"type": "string"}, {"type": "object"}],
                            "description": "CycloneDX BOM path or object",
                        }
                    },
                    ["bom"],
                ),
            ),
            mtypes.Tool(
                name="latest_malware",
                description="List recent malware with filters and structured output.",
                inputSchema=_tool_schema(
                    {
                        "count": {
                            "type": "integer",
                            "minimum": 1,
                            "description": "Number of malware results",
                        }
                    },
                    [],
                ),
            ),
        ]

    @server.call_tool()
    async def handle_call_tool(name: str, arguments: dict[str, Any] | None):
        arguments = arguments or {}
        await _publish_startup_events(server)
        await _progress(server, 0, 100, f"Starting {name}")
        filters = _extract_filters(arguments)
        options = {
            "with_data": arguments.get("with_data", True),
            "summary_only": arguments.get("summary_only", False),
            "include_references": arguments.get("include_references", False),
            "include_affected_symbols": arguments.get(
                "include_affected_symbols", False
            ),
            "include_remediation": arguments.get("include_remediation", True),
            "include_evidence": arguments.get("include_evidence", False),
        }
        max_results = arguments.get("max_results")

        if name == "search_by_purl_like":
            raw = search.search_by_purl_like(
                arguments["purl"],
                with_data=options["with_data"],
                filters=filters,
                max_results=max_results,
            )
            payload = _shape_list_payload({"purl": arguments["purl"]}, raw, options)
        elif name == "search_by_any":
            raw = search.search_by_any(
                arguments["search"],
                with_data=options["with_data"],
                filters=filters,
                max_results=max_results,
            )
            payload = _shape_list_payload({"search": arguments["search"]}, raw, options)
        elif name == "search_by_cpe_like":
            raw = search.search_by_cpe_like(
                arguments["cpe"],
                with_data=options["with_data"],
                filters=filters,
                max_results=max_results,
            )
            payload = _shape_list_payload({"cpe": arguments["cpe"]}, raw, options)
        elif name == "search_by_cve":
            raw = search.search_by_cve(
                arguments["cve_id"],
                with_data=options["with_data"],
                filters=filters,
                max_results=max_results,
            )
            payload = _shape_list_payload({"cve_id": arguments["cve_id"]}, raw, options)
        elif name == "search_by_url":
            raw = search.search_by_url(
                arguments["url"],
                with_data=options["with_data"],
                filters=filters,
                max_results=max_results,
            )
            payload = _shape_list_payload({"url": arguments["url"]}, raw, options)
        elif name == "search_full_text":
            raw = search.search_full_text(
                arguments["text"],
                with_data=options["with_data"],
                filters=filters,
                max_results=max_results,
            )
            payload = _shape_list_payload({"text": arguments["text"]}, raw, options)
        elif name == "search_by_alias":
            raw = search.search_by_alias(
                arguments["alias"],
                with_data=options["with_data"],
                filters=filters,
                max_results=max_results,
            )
            payload = _shape_list_payload({"alias": arguments["alias"]}, raw, options)
        elif name == "search_by_reference":
            raw = search.search_by_reference(
                arguments["reference"],
                with_data=options["with_data"],
                filters=filters,
                max_results=max_results,
            )
            payload = _shape_list_payload(
                {"reference": arguments["reference"]}, raw, options
            )
        elif name == "search_by_package_name":
            raw = search.search_by_package_name(
                arguments["package_name"],
                with_data=options["with_data"],
                filters=filters,
                max_results=max_results,
            )
            payload = _shape_list_payload(
                {"package_name": arguments["package_name"]}, raw, options
            )
        elif name == "search_by_symbol":
            raw = search.search_by_symbol(
                arguments["symbol"],
                with_data=options["with_data"],
                filters=filters,
                max_results=max_results,
            )
            payload = _shape_list_payload({"symbol": arguments["symbol"]}, raw, options)
        elif name == "search_packages":
            raw = search.search_packages(
                arguments["packages"],
                with_data=options["with_data"],
                filters=filters,
                max_results=max_results,
            )
            payload = _shape_package_payload(
                {"packages": arguments["packages"]}, raw, options
            )
        elif name == "search_bom_summary":
            raw = search.search_bom_summary(
                arguments["bom"], filters=filters, max_results=max_results
            )
            payload = _shape_bom_payload(
                {"bom": arguments["bom"]}, raw, {**options, "summary_only": True}
            )
        elif name == "search_bom_detailed":
            raw = search.search_bom_detailed(
                arguments["bom"],
                filters=filters,
                with_data=options["with_data"],
                max_results=max_results,
            )
            payload = _shape_bom_payload({"bom": arguments["bom"]}, raw, options)
        elif name == "latest_malware":
            raw = next(
                search.latest_malware(
                    with_limit=arguments.get("count", 10),
                    with_data=options["with_data"],
                    filters=filters,
                ),
                [],
            )
            payload = _shape_list_payload(
                {"count": arguments.get("count", 10), "malware_only": True},
                raw,
                options,
            )
        else:
            raise ValueError(f"Unknown tool: {name}")

        await _progress(server, 100, 100, f"Completed {name}")
        return payload

    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="appthreat-vulnerability-db",
                server_version=SERVER_VERSION,
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )
