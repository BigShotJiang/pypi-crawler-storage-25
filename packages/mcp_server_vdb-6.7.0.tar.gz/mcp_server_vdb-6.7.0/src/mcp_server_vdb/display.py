import base64

from rich.markdown import Markdown
from rich.table import Table

from vdb.lib.cve_model import CVE


def add_table_row(table: Table, res: dict, added_row_keys: dict):
    # matched_by is the purl or cpe string
    row_key = f"""{res["matched_by"]}|{res.get("source_data_hash")}"""
    # Filter duplicate rows from getting printed
    if added_row_keys.get(row_key):
        return
    source_data: CVE = res.get("source_data")
    descriptions = []
    cna_container = source_data.root.containers.cna
    if cna_container and cna_container.descriptions and cna_container.descriptions.root:
        for adesc in cna_container.descriptions.root:
            description = (
                "\n".join(
                    [
                        base64.b64decode(sm.value).decode("utf-8")
                        for sm in adesc.supportingMedia
                    ]
                )
                if adesc.supportingMedia
                else adesc.value
            )
            description = description.replace("\\n", "\n").replace("\\t", "  ")
            descriptions.append(description)
    table.add_row(
        Markdown(
            f"[{res.get('cve_id')}](cve://{res.get('cve_id')})",
            justify="left",
            hyperlinks=True,
        ),
        res.get("matched_by"),
        Markdown("\n".join(descriptions), justify="left", hyperlinks=True),
    )
    added_row_keys[row_key] = True
