from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import quote

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

REPO_ROOT = Path(__file__).resolve().parents[3]
PACKAGE_SRC = REPO_ROOT / "packages" / "mcp-server-vdb" / "src"
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
if str(PACKAGE_SRC) not in sys.path:
    sys.path.insert(0, str(PACKAGE_SRC))

os.environ.setdefault("PYTHONPATH", f"{PACKAGE_SRC}:{REPO_ROOT}")

from vdb.lib import CvssV3, Vulnerability, VulnerabilityDetail, config, db6
from vdb.lib.gha import GitHubSource
from vdb.lib.osv import OSVSource


def _detail(cpe_uri: str, package_type: str, severity: str, updated: str):
    return VulnerabilityDetail.from_dict(
        {
            "cpe_uri": cpe_uri,
            "package": cpe_uri.split(":")[4],
            "mii": "1.0.0",
            "mae": "2.0.0",
            "severity": severity,
            "description": severity,
            "fixed_location": "",
            "package_type": package_type,
            "is_obsolete": "False",
            "source_update_time": updated,
        }
    )


def _cvss(base_score: float, severity: str):
    return CvssV3(
        base_score=base_score,
        exploitability_score=base_score,
        impact_score=base_score,
        attack_vector="NETWORK",
        attack_complexity="LOW",
        privileges_required="NONE",
        user_interaction="NONE",
        scope="UNCHANGED",
        confidentiality_impact=severity,
        integrity_impact=severity,
        availability_impact=severity,
        vector_string="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H",
    )


def _vuln(
    vid: str,
    severity: str,
    description: str,
    references: list[str],
    detail: VulnerabilityDetail,
    published: str,
    updated: str,
    purl: str,
    aliases: list[str] | None = None,
):
    vuln = Vulnerability(
        vid=vid,
        assigner="test",
        problem_type="CWE-79",
        score={"HIGH": 7.5, "CRITICAL": 9.8}[severity],
        severity=severity,
        description=description,
        related_urls=references,
        details=[detail],
        cvss_v3=_cvss({"HIGH": 7.5, "CRITICAL": 9.8}[severity], severity),
        source_update_time=updated,
        source_orig_time=published,
    )
    vuln.purl_prefix = purl
    vuln.aliases = aliases or []
    return vuln


def _seed_database(vdb_home: Path):
    os.environ["VDB_HOME"] = str(vdb_home)
    previous_include_metadata = config.VDB_INCLUDE_METADATA
    config.VDB_INCLUDE_METADATA = True
    if hasattr(db6, "reset_connections"):
        db6.reset_connections()
    else:
        if getattr(db6, "db_conn", None):
            db6.db_conn.close()
        if getattr(db6, "index_conn", None):
            db6.index_conn.close()
        db6.db_conn = None
        db6.index_conn = None
        db6.tables_created = False
    db6.get(str(vdb_home / "data.vdb6"), str(vdb_home / "data.index.vdb6"))
    osv_vuln = _vuln(
        vid="CVE-2025-1000",
        severity="HIGH",
        description="Deserialization bug in demo-lib parser with parse_payload exposure",
        references=["https://osv.dev/vulnerability/OSV-2025-1"],
        detail=_detail("cpe:2.3:a:pypi:demo-lib:*:*:*:*:*:*:*:*", "pypi", "HIGH", "2025-01-10T00:00:00Z"),
        published="2025-01-01T00:00:00Z",
        updated="2025-01-10T00:00:00Z",
        purl="pkg:pypi/demo-lib",
        aliases=["GHSA-osv-1111", "OSV-2025-1"],
    )
    github_vuln = _vuln(
        vid="CVE-2025-2000",
        severity="CRITICAL",
        description="Prototype pollution in widget-ui repository handlers",
        references=["https://github.com/example/widget-ui/security/advisories/GHSA-gh-9999"],
        detail=_detail("cpe:2.3:a:github:widget-ui:*:*:*:*:*:*:*:*", "github", "CRITICAL", "2025-02-12T00:00:00Z"),
        published="2025-02-01T00:00:00Z",
        updated="2025-02-12T00:00:00Z",
        purl="pkg:github/example/widget-ui",
        aliases=["GHSA-gh-9999"],
    )
    try:
        OSVSource().store([osv_vuln])
        GitHubSource().store([github_vuln])
        db6.optimize_and_close_all()
        if hasattr(db6, "reset_connections"):
            db6.reset_connections()
    finally:
        config.VDB_INCLUDE_METADATA = previous_include_metadata
    (vdb_home / "vdb.meta").write_text(
        json.dumps(
            {
                "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "sources": ["OSVSource", "GitHubSource"],
                "cve_data_count": 2,
                "cve_index_count": 2,
            }
        ),
        encoding="utf-8",
    )


async def run(tmp_path: Path):
    vdb_home = tmp_path / "vdb-home"
    vdb_home.mkdir(parents=True, exist_ok=True)
    _seed_database(vdb_home)

    env = os.environ.copy()
    env["VDB_HOME"] = str(vdb_home)
    env["PYTHONPATH"] = f"{PACKAGE_SRC}:{REPO_ROOT}"
    env["VDB_AGE_DAYS"] = "9999"
    env["VDB_INCLUDE_METADATA"] = "true"

    server_params = StdioServerParameters(
        command="uv",
        args=["--directory", str(REPO_ROOT / "packages" / "mcp-server-vdb"), "run", "mcp-server-vdb"],
        env=env,
    )

    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            def read_text_payload(resource_result):
                payload = resource_result
                if hasattr(payload, "contents"):
                    payload = payload.contents
                if isinstance(payload, tuple):
                    payload = payload[0]
                if isinstance(payload, (list, tuple)) and payload:
                    payload = payload[0]
                return payload.text if hasattr(payload, "text") else payload

            resources = await session.list_resources()
            assert any(str(resource.uri) == "vdb://metadata" for resource in resources.resources)

            templates = await session.list_resource_templates()
            assert any(template.uriTemplate == "cve://{id}" for template in templates.resourceTemplates)

            metadata_content = read_text_payload(await session.read_resource("vdb://metadata"))
            assert json.loads(metadata_content)

            cve_content = read_text_payload(await session.read_resource("cve://CVE-2025-1000"))
            cve_payload = json.loads(cve_content)
            assert cve_payload["summary"]["result_count"] == 1

            purl_content = read_text_payload(await session.read_resource(f"purl://{quote('pkg:pypi/demo-lib@1.5.0', safe='')}"))
            purl_payload = json.loads(purl_content)
            assert purl_payload["summary"]["result_count"] == 1

            prompts = await session.list_prompts()
            prompt_names = {prompt.name for prompt in prompts.prompts}
            assert {"assess-package-risk", "triage-cve", "summarize-sbom-risk"}.issubset(prompt_names)

            prompt = await session.get_prompt("assess-package-risk", arguments={"package": "pkg:pypi/demo-lib@1.5.0"})
            assert prompt.messages

            tools = await session.list_tools()
            tool_names = {tool.name for tool in tools.tools}
            assert {"search_full_text", "search_packages", "search_bom_summary"}.issubset(tool_names)

            result = await session.call_tool(
                "search_by_purl_like",
                arguments={"purl": "pkg:pypi/demo-lib@1.5.0", "include_references": True},
            )
            assert result.structuredContent["summary"]["result_count"] == 1
            assert result.structuredContent["results"][0]["references"]

            result = await session.call_tool(
                "search_full_text",
                arguments={"text": "Deserialization", "summary_only": True},
            )
            assert result.structuredContent["summary"]["result_count"] == 1
            assert "results" not in result.structuredContent

            result = await session.call_tool(
                "search_packages",
                arguments={
                    "packages": [
                        {"purl": "pkg:pypi/demo-lib@1.5.0"},
                        {"url": "https://github.com/example/widget-ui"},
                    ],
                    "with_data": True,
                },
            )
            assert result.structuredContent["summary"]["matched_packages"] == 2
            assert result.structuredContent["packages"][0]["results"][0]["source_data"]

            result = await session.call_tool(
                "search_bom_summary",
                arguments={
                    "bom": {
                        "components": [
                            {"name": "demo-lib", "version": "1.5.0", "purl": "pkg:pypi/demo-lib@1.5.0"},
                            {"name": "widget-ui", "version": "1.0.0", "purl": "pkg:github/example/widget-ui@1.0.0"},
                        ]
                    }
                },
            )
            assert result.structuredContent["summary"]["matched_components"] == 2


def test_run(tmp_path):
    asyncio.run(run(tmp_path))
