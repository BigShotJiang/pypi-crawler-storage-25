import json

from mcp_server_vdb import server
from vdb.lib import CvssV3, Vulnerability, VulnerabilityDetail
from vdb.lib.cve import to_cve_containers, to_cve_metadata
from vdb.lib.cve_model import CVE, CVE1, Containers, DataType, DataVersion


def _source_data_model():
    detail = VulnerabilityDetail.from_dict(
        {
            "cpe_uri": "cpe:2.3:a:pypi:demo-lib:*:*:*:*:*:*:*:*",
            "package": "demo-lib",
            "mii": "1.0.0",
            "mae": "2.0.0",
            "severity": "HIGH",
            "description": "HIGH",
            "fixed_location": "",
            "package_type": "pypi",
            "is_obsolete": "False",
            "source_update_time": "2026-01-02T00:00:00Z",
        }
    )
    vuln = Vulnerability(
        vid="CVE-2026-1000",
        assigner="test",
        problem_type="CWE-79",
        score=7.5,
        severity="HIGH",
        description="Synthetic vulnerability used for compact source_data tests.",
        related_urls=["https://example.invalid/CVE-2026-1000"],
        details=[detail],
        cvss_v3=CvssV3(
            base_score=7.5,
            exploitability_score=3.9,
            impact_score=3.6,
            attack_vector="NETWORK",
            attack_complexity="LOW",
            privileges_required="NONE",
            user_interaction="NONE",
            scope="UNCHANGED",
            confidentiality_impact="HIGH",
            integrity_impact="HIGH",
            availability_impact="HIGH",
            vector_string="",
        ),
        source_update_time="2026-01-02T00:00:00Z",
        source_orig_time="2026-01-01T00:00:00Z",
    )
    return CVE(
        root=CVE1(
            dataType=DataType.CVE_RECORD,
            dataVersion=DataVersion.field_5_2,
            cveMetadata=to_cve_metadata(vuln),
            containers=Containers(cna=to_cve_containers(vuln)),
        )
    )


def test_extract_filters_and_shape_list_payload():
    filters = server._extract_filters(
        {
            "severity_threshold": "HIGH",
            "source": ["github", "osv"],
            "with_data": True,
            "summary_only": True,
        }
    )
    assert filters["severity_threshold"] == "HIGH"
    assert filters["sources"] == ["github", "osv"]

    payload = server._shape_list_payload(
        {"search": "pkg:pypi/demo-lib@1.5.0"},
        [
            {
                "cve_id": "CVE-2025-1000",
                "matched_by": "pkg:pypi/demo-lib@1.5.0",
                "matching_vers": "1.5.0",
                "vers": "vers:pypi/>=1.0.0|<2.0.0",
                "purl_prefix": "pkg:pypi/demo-lib",
                "source": "osv",
                "severity": "HIGH",
                "score": 7.5,
                "published": "2025-01-01T00:00:00Z",
                "updated": "2025-01-02T00:00:00Z",
                "package_ecosystem": "pypi",
                "package_scope": "app",
                "aliases": ["GHSA-osv-1111"],
                "references": ["https://example.invalid/advisory"],
                "affected_symbols": ["parse_payload"],
                "fix_version": "2.0.0",
                "description": "Test issue",
                "namespace": None,
                "name": "demo-lib",
                "type": "pypi",
            }
        ],
        {
            "with_data": False,
            "summary_only": True,
            "include_references": True,
            "include_affected_symbols": True,
            "include_remediation": True,
            "include_evidence": True,
        },
    )
    assert payload["summary"]["result_count"] == 1
    assert "results" not in payload


def test_shape_package_and_bom_payloads():
    package_payload = server._shape_package_payload(
        {"packages": [{"purl": "pkg:pypi/demo-lib@1.5.0"}]},
        [
            {
                "locator": {"purl": "pkg:pypi/demo-lib@1.5.0"},
                "result_count": 1,
                "max_severity": "HIGH",
                "cve_ids": ["CVE-2025-1000"],
                "fix_versions": ["2.0.0"],
                "sources": ["osv"],
                "results": [],
            }
        ],
        {"summary_only": True},
    )
    assert package_payload["summary"]["matched_packages"] == 1

    bom_payload = server._shape_bom_payload(
        {"bom": "bom.json"},
        {
            "summary": {"component_count": 1, "matched_components": 1, "vulnerability_count": 1},
            "components": [
                {
                    "locator": {"purl": "pkg:pypi/demo-lib@1.5.0"},
                    "result_count": 1,
                    "max_severity": "HIGH",
                    "cve_ids": ["CVE-2025-1000"],
                    "fix_versions": ["2.0.0"],
                    "sources": ["osv"],
                    "results": [],
                }
            ],
        },
        {"summary_only": True},
    )
    assert bom_payload["summary"]["matched_components"] == 1


def test_health_payload():
    payload = server._health_payload([{"level": "info", "message": "Using cached database."}])
    assert payload["status"] == "ok"
    assert payload["startup_events"]


def test_serialize_result_compacts_source_data_without_breaking_model_validation():
    source_data = _source_data_model()

    payload = server._serialize_result(
        {"cve_id": "CVE-2026-1000", "source_data": source_data},
        {"with_data": True},
    )

    compact_dump = payload["source_data"]
    default_json = json.dumps(source_data.model_dump(mode="json"), separators=(",", ":"))
    compact_json = json.dumps(compact_dump, separators=(",", ":"))

    assert len(compact_json) < len(default_json)
    assert "adp" not in compact_dump["containers"]
    assert "dateReserved" not in compact_dump["cveMetadata"]
    assert "supportingMedia" not in compact_dump["containers"]["cna"]["descriptions"][0]

    revalidated = CVE(root=CVE1.model_validate(compact_dump, strict=False))
    assert revalidated.root.cveMetadata.cveId.root == "CVE-2026-1000"
