import re
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[3]
MCP_ROOT = REPO_ROOT / "packages" / "mcp-server-vdb"


def _project_version(pyproject_text: str) -> str:
    match = re.search(r'^version = "([^"]+)"', pyproject_text, re.MULTILINE)
    assert match, "project version not found"
    return match.group(1)


def test_mcp_package_tracks_root_vdb_version():
    root_version = _project_version((REPO_ROOT / "pyproject.toml").read_text())
    mcp_pyproject = (MCP_ROOT / "pyproject.toml").read_text()
    server_py = (MCP_ROOT / "src" / "mcp_server_vdb" / "server.py").read_text()

    assert _project_version(mcp_pyproject) == root_version
    assert f'"appthreat-vulnerability-db[oras]=={root_version}"' in mcp_pyproject
    assert f'SERVER_VERSION = "{root_version}"' in server_py
