"""CLI 入口"""
import click
import json
import shutil
from .api import DevOpsAPI
from .auth import login
from .config import config


def _normalize_cell(value):
    if value is None:
        return "-"
    return str(value)


def _truncate_text(text, width):
    if width <= 0:
        return ""
    if len(text) <= width:
        return text
    if width <= 1:
        return text[:width]
    return text[: width - 1] + "…"


def render_table(headers, rows, max_width=120, no_truncate_headers=None):
    if not rows:
        click.echo("暂无数据")
        return

    terminal_width = shutil.get_terminal_size((max_width, 20)).columns
    table_max_width = min(max_width, terminal_width)

    no_truncate_headers = set(no_truncate_headers or [])

    normalized_rows = []
    for row in rows:
        normalized = [_normalize_cell(cell) for cell in row[: len(headers)]]
        if len(normalized) < len(headers):
            normalized.extend(["-"] * (len(headers) - len(normalized)))
        normalized_rows.append(normalized)

    widths = [len(h) for h in headers]
    for row in normalized_rows:
        for idx, cell in enumerate(row):
            widths[idx] = max(widths[idx], len(cell))

    # 边框和分隔占用: 左右边框 + 每列两侧空格 + 列分隔符
    overhead = 3 * len(headers) + 1
    available = max(20, table_max_width - overhead)
    min_col_width = 10
    widths = [max(min_col_width, w) for w in widths]

    total = sum(widths)
    if total > available:
        fixed_idx = {i for i, h in enumerate(headers) if h in no_truncate_headers}
        shrinkable_idx = [i for i in range(len(headers)) if i not in fixed_idx]

        if shrinkable_idx:
            while sum(widths) > available:
                idx = max(shrinkable_idx, key=lambda i: widths[i])
                if widths[idx] > min_col_width:
                    widths[idx] -= 1
                else:
                    if all(widths[i] <= min_col_width for i in shrinkable_idx):
                        break
        # 若仍超出可用宽度，保留不截断列完整内容，允许终端自动换行/横向滚动查看

    def format_row(cells):
        parts = []
        for i, cell in enumerate(cells):
            text = cell if headers[i] in no_truncate_headers else _truncate_text(cell, widths[i])
            parts.append(f" {text.ljust(widths[i])} ")
        return "|" + "|".join(parts) + "|"

    border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    click.echo(border)
    click.echo(format_row(headers))
    click.echo(border)
    for row in normalized_rows:
        click.echo(format_row(row))
    click.echo(border)


@click.group()
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option(
    "--output",
    "-o",
    "output_format",
    type=click.Choice(["human", "json"], case_sensitive=False),
    default="json",
    show_default=True,
    help="输出格式: human(表格) / json",
)
@click.pass_context
def cli(ctx, project, output_format):
    """DevOps 平台迭代管理工具"""
    ctx.ensure_object(dict)
    ctx.obj["project"] = project or config.default_project
    ctx.obj["output_format"] = output_format.lower()


@cli.command("login")
def cmd_login():
    """登录 - 打开浏览器重新获取 cookie"""
    login()


@cli.group()
def sprint():
    """迭代管理命令组"""
    pass

@cli.group()
def project():
    """项目管理命令组"""
    pass

@sprint.command("create")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--title", "-t", required=True, help="迭代名称")
@click.option("--start-date", "-s", required=True, help="开始日期 (YYYY-MM-DD)")
@click.option("--end-date", "-e", required=True, help="结束日期 (YYYY-MM-DD)")
@click.option("--purpose", help="迭代目标")
@click.option("--test-start", help="测试开始日期")
@click.option("--test-end", help="测试结束日期")
@click.pass_context
def create_sprint(ctx, project, title, start_date, end_date, purpose, test_start, test_end):
    """创建迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)
    
    try:
        result = api.create_sprint(
            title=title,
            start_date=start_date,
            end_date=end_date,
            purpose=purpose or "",
            test_start_date=test_start,
            test_end_date=test_end,
        )
        click.echo(f"创建成功! 迭代 ID: {result.get('id')}")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("start")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--sprint-id", "-i", required=True, help="迭代 ID")
@click.pass_context
def start_sprint(ctx, project, sprint_id):
    """启用迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)
    
    try:
        sprints = api.list_sprints()
        sprint_data = None
        for s in sprints.get("data").get("content"):
            if s.get("id") == sprint_id:
                sprint_data = s
                break
        
        if not sprint_data:
            click.echo(f"未找到迭代: {sprint_id}", err=True)
            return
        
        result = api.start_sprint(sprint_data)
        click.echo(f"启用成功!")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("delete")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--sprint-id", "-i", required=True, help="迭代 ID")
@click.pass_context
def delete_sprint(ctx, project, sprint_id):
    """删除迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)
    
    if not click.confirm(f"确认删除迭代 {sprint_id}?"):
        return
    
    try:
        api.delete_sprint(sprint_id)
        click.echo(f"删除成功!")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)


@sprint.command("done")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.option("--sprint-id", "-i", required=True, help="迭代 ID")
@click.pass_context
def done_sprint(ctx, project, sprint_id):
    """ 完成迭代"""
    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)

    if not click.confirm(f"确认完成迭代 {sprint_id}?"):
        return

    try:
        api.done_sprint(sprint_id)
        click.echo(f"完成成功!")
    except Exception as e:
        click.echo(f"错误: {e}", err=True)



@sprint.command("list")
@click.option("--project", "-p", default=None, help="项目 ID")
@click.pass_context
def list_sprint(ctx, project):

    project_id = project or ctx.obj["project"]
    if not project_id:
        click.echo("错误: 请通过 -p 指定项目 ID 或在配置中设置 default_project")
        raise click.Abort()
    api = DevOpsAPI(project_id)


    try:
        sprints = api.list_sprints()
        sprint_list = sprints.get("data", {}).get("content", [])
        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    sprint_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return
        render_table(
            headers=["迭代名称", "迭代ID", "开始时间", "结束时间", "迭代状态", "提测时间", "测试开始时间", "测试完成时间","验收完成", "负责人"],
            rows=[
                [
                    s.get("title"),
                    s.get("id"),
                    s.get("startDate"),
                    s.get("endDate"),
                    s.get("state"),
                    s.get("testStartDate"),
                    s.get("smokeEndDate"),
                    s.get("testEndDate"),
                    s.get("acceptanceEndDate"),
                    s.get("developmentPic"),
                    s.get("testPic"),
                    s.get("acceptancePic")
                ]
                for s in sprint_list
            ],
            no_truncate_headers=["迭代ID","迭代名称"],
        )

    except Exception as e:
        click.echo(f"错误: {e}", err=True)



@project.command("list")
@click.pass_context
def list_project(ctx):

    api = DevOpsAPI("")

    try:
        projects = api.list_projects()
        project_list = projects.get("data", [])
        if ctx.obj.get("output_format") == "json":
            click.echo(
                json.dumps(
                    project_list,
                    ensure_ascii=False,
                    indent=2,
                    default=str,
                )
            )
            return
        render_table(
            headers=["项目代码", "项目名称", "部门名称"],
            rows=[
                [
                    s.get("projectCode"),
                    s.get("projectName"),
                    s.get("deptName"),
                ]
                for s in project_list
            ],
        )

    except Exception as e:
        click.echo(f"错误: {e}", err=True)

def main():
    cli()


if __name__ == "__main__":
    main()