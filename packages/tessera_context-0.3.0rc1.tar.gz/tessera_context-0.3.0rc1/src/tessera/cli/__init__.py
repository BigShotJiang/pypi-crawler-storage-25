"""Tessera command-line interface."""
