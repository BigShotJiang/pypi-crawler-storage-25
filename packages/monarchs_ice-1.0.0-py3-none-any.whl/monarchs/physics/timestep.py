"""
Model timestepping module.
core.timestep_loop handles all the 1D calculations, by first checking the
current state of the column, then running firn_column and lake/lid functions
accordingly.
"""

import numpy as np
from monarchs.physics import (
    firn_column,
    lake,
    solver,
    lid,
    percolation,
    virtual_lid,
    snow_accumulation,
    reset_column,
)
from monarchs.physics.constants import rho_ice, rho_water
from monarchs.core.error_handling import generic_error, check_correct

MODULE_NAME = "monarchs.physics.timestep"


def timestep_loop(cell, dt, met_data, t_steps_per_day, toggle_dict):
    """
    Main timestepping loop applied to an instance of the model grid.
    Called by loop_over_grid to work in parallel over multiple instances.

    Parameters
    ----------
    cell : numpy structured array
        Element of our model grid.
    dt : int32
        Time for each timestep <t_steps_per_day>. [s]

    met_data : numpy structured array
        Element of the met data grid. Contains thermodynamic variables, which
        are listed as follows:

        lw_in : int32 or float64
            Incoming broadband longwave radiation [W m^-2].
        sw_in : int32 or float64
             Incoming broadband shortwave radiation [W m^-2].
        air_temp : int32 or float64
            Air temperature [K].
        p_air : int32 or float64
            Surface pressure [hPa].
        dew_point_temperature : int32 or float64
            Dew-point temperature [K]
        wind : int32 or float64
            Surface wind speed. [m s^-1]

    t_steps_per_day : int
        Number of timesteps in a model day. Typically 24 (i.e. 1h timesteps).

    toggle_dict : dict
        A dictionary containing toggles that determine whether certain features
        are enabled. Most of these are debug settings, and are intended to
        be True for normal model operation.
        Values are the following:
            parallel: determines whether the model is run with more than one
                core.
            use_numba: determines whether numba is used for optimisation.
            snowfall_toggle: determines whether snowfall is enabled.
            firn_column_toggle: determines whether firn column evolution is
                enabled.
            firn_heat_toggle: determines whether the firn heat equation is
                solved.
            lake_development_toggle: determines whether lake formation and
                development is enabled.
            lid_development_toggle: determines whether lid formation and
                development is enabled.
            ignore_errors: determines whether to ignore errors in the model
                (e.g. Sfrac + Lfrac > 1, negative firn depths etc.)


    Returns
    -------
    None. The function amends the instance of <cell> passed to it.

    """
    cell["visit_count"] += 1
    routine_name = f"{MODULE_NAME}.timestep_loop"
    snowfall_toggle = toggle_dict["snowfall_toggle"]
    firn_column_toggle = toggle_dict["firn_column_toggle"]
    firn_heat_toggle = toggle_dict["firn_heat_toggle"]
    lake_development_toggle = toggle_dict["lake_development_toggle"]
    lid_development_toggle = toggle_dict["lid_development_toggle"]
    ignore_errors = toggle_dict["ignore_errors"]

    if not cell["valid_cell"]:
        return cell
    # track evolution of firn, lake and lid over time. We do this for each day,
    # so it resets at the start of the model day.
    cell["firn_boundary_change"] = 0
    cell["lake_boundary_change"] = 0
    cell["lid_boundary_change"] = 0

    if np.isnan(cell["firn_temperature"]).any():
        message = "NaN in firn temperature"
    cell["t_step"] = 1
    for t_step in range(t_steps_per_day):
        # Validation of model state at the start of the timestep
        if cell["lake_depth"] <= 1e-5 and cell["lake"]:
            cell["lake"] = False
            cell["lake_depth"] = 0
        if cell["lid_depth"] <= 0 and cell["lid"]:
            cell["lid"] = False
            cell["lid_depth"] = 0
        if cell["v_lid_depth"] <= 0 and cell["v_lid"]:
            cell["v_lid"] = False
            cell["v_lid_depth"] = 0

        dz = cell["firn_depth"] / cell["vert_grid"]
        if snowfall_toggle:
            cell["rho"] = cell["Sfrac"] * rho_ice + cell["Lfrac"] * rho_water
            if met_data[t_step]["temperature"] > 273.15:
                snow_T = 273.1  # sergienko thesis pg. 26
            else:
                snow_T = met_data[t_step]["temperature"]
            snow_accumulation.snowfall(
                cell,
                met_data[t_step]["snowfall"],
                met_data[t_step]["snow_dens"],
                snow_T,
            )

        """
        Two main paths - either no exposed water, in which case the dry firn
        evolves, or we have exposed water,
        in which case there are further branches depending on whether lakes
        or lids have formed yet.
        """

        if not cell["exposed_water"]:
            if firn_column_toggle:
                firn_column.firn_column(
                    cell,
                    dt,
                    dz,
                    met_data[t_step],
                    toggle_dict,
                )

        elif cell["exposed_water"]:
            # print("Exposed water present")

            if firn_heat_toggle:
                sol, fvec, success, info = solver.solve_firn_heateqn(
                    cell, met_data[t_step], dt, dz, fixed_sfc=True, solver_method="hybr"
                )
                if success:
                    cell["firn_temperature"] = sol

            cell["rho"] = cell["Sfrac"] * rho_ice + cell["Lfrac"] * rho_water
            if (
                cell["lake"]
                and not cell["lid"]
                and not cell["v_lid"]
                and cell["lake_depth"] < 0.1
                and cell["v_lid_depth"] <= 0
            ):
                cell["lake"] = False
                cell["lake_depth"] = 0

            if cell["lake_depth"] == 0:
                cell["exposed_water"] = False

            if not cell["lake"]:
                if lake_development_toggle:
                    print("Lake formation")
                    lake.lake_formation(cell, dt, met_data[t_step])

            elif cell["lake"] and not cell["lid"]:

                if lake_development_toggle:
                    Fu = lake.lake_development(cell, dt, met_data[t_step])
                # TODO - add refreezing calculation here - relevant if we have
                # lakes underneath a frozen lid that gets combined
                if firn_heat_toggle:
                    for lev in range(cell["vert_grid"]):
                        percolation.calc_refreezing(cell, lev)

                if cell["v_lid"]:
                    if lid_development_toggle:
                        virtual_lid.virtual_lid_development(
                            cell,
                            dt,
                            met_data[t_step],
                            Fu,
                        )

                    # if virtual lid freezes the entire lake (possible if
                    # lateral movement), then combine (virtual) lid and
                    # lake profiles.
                    if cell["lake_depth"] <= 1e-5:
                        reset_column.combine_lid_firn(cell, freeze_lake=False)

            elif cell["lake"] and cell["lid"]:

                if lid_development_toggle:
                    # turn virtual lid off if full lid present
                    cell["v_lid"] = False
                    Fu = lake.lake_development(
                        cell,
                        dt,
                        met_data[t_step],
                    )
                    for lev in range(cell["vert_grid"]):
                        percolation.calc_refreezing(cell, lev)
                    lid.lid_development(
                        cell,
                        dt,
                        met_data[t_step],
                        Fu,
                    )
                # Check for if we need to reset the column - two possible
                # conditions - if lake depth v small,
                #            - or if lid melt count > 6 (i.e. lid has been
                #              melting for half a day, and therefore has
                #              significant slush/water on the surface)
                if cell["lake_depth"] <= 1e-5:
                    print("Combining lid and firn column")
                    print("Lid melt count:", cell["lid_melt_count"])
                    reset_column.combine_lid_firn(cell, surface_slush=False)
                elif cell["lid_melt_count"] > 12:
                    reset_column.combine_lid_firn(cell, surface_slush=True)

        # TODO:
        # If we have had a reset/combine event, we may end up with a
        # region of liquid water inside the firn. We need to ensure that this
        # continues to freeze based on the conditions what we take to be our
        # new "firn column" - much as it did when it was a lake under a lid.
        # Effectively, we need to mimick the behaviour of the lid refreezing,
        # so that the water doesn't just sit there forever.

        # If we have Sfrac + Lfrac > 1, we need to ensure that Lfrac is
        # adjusted accordingly.
        # We can do this via calc_saturation, which is used to similar effect
        # in the percolation step.
        if np.any(cell["Lfrac"] + cell["Sfrac"] > 1):
            # Get the lowest point at which the column is saturated, and use
            # this as the starting point for the saturation algorithm.
            # Then find the other points that are saturated and perform the
            # same calculation here also.
            saturation_points = np.where(cell["Lfrac"] + cell["Sfrac"] > 1)
            for saturation_point in saturation_points[::-1][0]:
                percolation.calc_saturation(cell, saturation_point, end=True)
            # Check again. We however will tolerate any instances where the
            # solid + liquid fraction goes above 1 (unless Sfrac is above 1).
            # This is because for small grid spacings, a layer may become
            # saturated as a result of the regridding.
            # Instead of hacking it into an adjacent cell, we just let it
            # percolate in the next timestep.
            if (
                np.any(cell["Lfrac"][1:] + cell["Sfrac"][1:] > 1.00000000001)
                and cell["Sfrac"][0] <= 1
            ):
                message = (
                    "Lfrac + Sfrac > 1 after regridding, after saturation"
                    " calculation."
                )
                generic_error(cell, routine_name, message)
        if not ignore_errors:
            check_correct(cell)

        cell["rho"] = cell["Sfrac"] * rho_ice + cell["Lfrac"] * rho_water

        cell["t_step"] += 1
        # Update vertical profile to ensure we account for any firn depth
        # changes
        cell["vertical_profile"] = np.linspace(0, cell["firn_depth"], cell["vert_grid"])
    # If firn depth goes below 5, then we now consider this cell to be
    # invalid. This prevents situations where points where water concentrates
    # and melts through the firn column causing the whole model to crash.
    # Update - this now *will* cause the model to crash, in driver.py where we
    # traverse valid cells, but this is probably desirable since this indicates
    # the potential for unphysical conditions.
    if cell["firn_depth"] < 5:
        print("Firn depth below 5 m - setting cell to invalid")
        print("Location of firn depth below 5 m - ", cell["row"], cell["column"])
        cell["valid_cell"] = False

    cell["day"] += 1

    return cell
