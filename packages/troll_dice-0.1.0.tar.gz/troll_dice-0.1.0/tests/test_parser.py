"""Tests for the Troll parser.

Tests parse correctness by comparing against expected AST structures and
round-tripping through show().
"""

from __future__ import annotations

import pytest

from troll.parser import ParseError, parse
from troll.syntax import (
    Accum,
    And,
    Call,
    Choose,
    Conc,
    Count,
    D,
    Default,
    Different,
    Divide,
    Drop,
    Empty,
    Eq,
    First,
    Foreach,
    FromTo,
    FuncDecl,
    Ge,
    Gt,
    Hash,
    Id,
    If,
    Keep,
    Largest,
    Le,
    Least,
    Let,
    Lt,
    Maximal,
    Median,
    Minimal,
    Mod,
    Neq,
    Num,
    Pair,
    Pick,
    Plus,
    Question,
    Repeat,
    Sample,
    Samples,
    Second,
    SetMinus,
    Sign,
    String,
    Sum,
    Times,
    UMinus,
    Z,
    show,
)


def _expr(source: str):
    """Parse a source string and return just the expression (no declarations)."""
    program = parse(source)
    assert program.declarations == []
    return program.expression


class TestDicePrimitives:
    def test_d6(self):
        assert _expr("d6") == D(Num(6))

    def test_z10(self):
        assert _expr("z10") == Z(Num(10))

    def test_3d6_infix(self):
        """Infix d desugars to Hash(count, D(sides))."""
        assert _expr("3d6") == Hash(Num(3), D(Num(6)))

    def test_4d6_explicit_hash(self):
        assert _expr("4 # d6") == Hash(Num(4), D(Num(6)))

    def test_d_d6_nested_prefix(self):
        """d applied to d6: roll a d6, then roll a die of that many sides."""
        assert _expr("d d6") == D(D(Num(6)))


class TestArithmetic:
    def test_plus(self):
        assert _expr("1 + 2") == Plus(Num(1), Num(2))

    def test_times(self):
        assert _expr("2 * 3") == Times(Num(2), Num(3))

    def test_precedence_mul_over_add(self):
        """2 + 3 * 4 should parse as 2 + (3 * 4)."""
        assert _expr("2 + 3 * 4") == Plus(Num(2), Times(Num(3), Num(4)))

    def test_precedence_add_left_assoc(self):
        """1 + 2 + 3 should left-associate."""
        assert _expr("1 + 2 + 3") == Plus(Plus(Num(1), Num(2)), Num(3))

    def test_unary_minus(self):
        assert _expr("-1") == UMinus(Num(1))

    def test_parens_override_precedence(self):
        assert _expr("(2 + 3) * 4") == Times(Plus(Num(2), Num(3)), Num(4))

    def test_divide_and_mod(self):
        assert _expr("10 / 3") == Divide(Num(10), Num(3))
        assert _expr("10 mod 3") == Mod(Num(10), Num(3))


class TestCollections:
    def test_empty_collection(self):
        assert _expr("{}") == Empty()

    def test_singleton_collection(self):
        assert _expr("{5}") == Num(5)

    def test_multi_element_collection(self):
        assert _expr("{1, 2, 3}") == Conc(Conc(Num(1), Num(2)), Num(3))

    def test_range(self):
        assert _expr("1..6") == FromTo(Num(1), Num(6))

    def test_choose(self):
        assert _expr("choose {1, 2, 3}") == Choose(Conc(Conc(Num(1), Num(2)), Num(3)))

    def test_different(self):
        assert _expr("different d6") == Different(D(Num(6)))


class TestAggregation:
    def test_sum(self):
        assert _expr("sum 2d6") == Sum(Hash(Num(2), D(Num(6))))

    def test_count(self):
        assert _expr("count d6") == Count(D(Num(6)))

    def test_sum_largest_3_4d6(self):
        """The classic D&D stat-roll expression."""
        assert _expr("sum largest 3 4d6") == Sum(Largest(Num(3), Hash(Num(4), D(Num(6)))))


class TestMinMaxLeastLargest:
    def test_min_desugars_to_least_1(self):
        assert _expr("min d6") == Least(Num(1), D(Num(6)))

    def test_max_desugars_to_largest_1(self):
        assert _expr("max d6") == Largest(Num(1), D(Num(6)))

    def test_least_2(self):
        assert _expr("least 2 3d6") == Least(Num(2), Hash(Num(3), D(Num(6))))

    def test_largest_2(self):
        assert _expr("largest 2 3d6") == Largest(Num(2), Hash(Num(3), D(Num(6))))

    def test_minimal(self):
        assert _expr("minimal d6") == Minimal(D(Num(6)))

    def test_maximal(self):
        assert _expr("maximal d6") == Maximal(D(Num(6)))

    def test_median(self):
        assert _expr("median 3d6") == Median(Hash(Num(3), D(Num(6))))


class TestComparisons:
    def test_eq_filter(self):
        assert _expr("3 = d6") == Eq(Num(3), D(Num(6)))

    def test_neq(self):
        assert _expr("3 =/= d6") == Neq(Num(3), D(Num(6)))

    def test_lt(self):
        assert _expr("3 < d6") == Lt(Num(3), D(Num(6)))

    def test_gt(self):
        assert _expr("3 > d6") == Gt(Num(3), D(Num(6)))

    def test_le_ge(self):
        assert _expr("3 <= d6") == Le(Num(3), D(Num(6)))
        assert _expr("3 >= d6") == Ge(Num(3), D(Num(6)))

    def test_comparison_binds_tighter_than_prefix(self):
        """sum 3 = d6 should parse as sum (3 = d6), not (sum 3) = d6."""
        assert _expr("sum 3 = d6") == Sum(Eq(Num(3), D(Num(6))))


class TestCollectionOps:
    def test_drop(self):
        assert _expr("d6 drop {1}") == Drop(D(Num(6)), Num(1))

    def test_keep(self):
        assert _expr("d6 keep {1, 2}") == Keep(D(Num(6)), Conc(Num(1), Num(2)))

    def test_pick(self):
        assert _expr("{1,2,3} pick 2") == Pick(Conc(Conc(Num(1), Num(2)), Num(3)), Num(2))

    def test_setminus(self):
        assert _expr("d6 -- {1}") == SetMinus(D(Num(6)), Num(1))


class TestControlFlow:
    def test_let_binding(self):
        assert _expr("x := 1 ; x") == Let("x", Num(1), Id("x"))

    def test_nested_let(self):
        result = _expr("x := 1 ; y := 2 ; x + y")
        assert result == Let("x", Num(1), Let("y", Num(2), Plus(Id("x"), Id("y"))))

    def test_if_then_else(self):
        assert _expr("if d6 then 1 else 0") == If(D(Num(6)), Num(1), Num(0))

    def test_foreach(self):
        assert _expr("foreach i in 1..6 do d6") == Foreach("i", FromTo(Num(1), Num(6)), D(Num(6)))

    def test_repeat_until(self):
        assert _expr("repeat x := d6 until x = 6") == Repeat(
            "x", D(Num(6)), Eq(Id("x"), Num(6)), is_while=False
        )

    def test_accumulate_while(self):
        assert _expr("accumulate x := d10 while x = 10") == Accum(
            "x", D(Num(10)), Eq(Id("x"), Num(10)), is_while=True
        )


class TestFunctions:
    def test_function_decl_and_call(self):
        program = parse("function f(x, y) = x + y\ncall f(1, 2)")
        assert len(program.declarations) == 1
        decl = program.declarations[0]
        assert isinstance(decl, FuncDecl)
        assert decl.name == "f"
        assert decl.params == ["x", "y"]
        assert decl.body == Plus(Id("x"), Id("y"))
        assert program.expression == Call("f", [Num(1), Num(2)])


class TestMiscFeatures:
    def test_bang_desugars_to_if(self):
        assert _expr("!d6") == If(D(Num(6)), Empty(), Num(1))

    def test_question_probability(self):
        assert _expr("?0.5") == Question(0.5)

    def test_pair(self):
        assert _expr("[d6, d20]") == Pair(D(Num(6)), D(Num(20)))

    def test_first_second(self):
        assert _expr("%1 [1, 2]") == First(Pair(Num(1), Num(2)))
        assert _expr("%2 [1, 2]") == Second(Pair(Num(1), Num(2)))

    def test_default(self):
        assert _expr("x ~ 5") == Default("x", Num(5))

    def test_string_literal(self):
        assert _expr('"hello"') == String("hello")

    def test_sample(self):
        assert _expr("'d6") == Sample(D(Num(6)))

    def test_samples_infix(self):
        assert _expr("3 ' d6") == Samples(Num(3), D(Num(6)))

    def test_sgn(self):
        assert _expr("sgn d6") == Sign(D(Num(6)))

    def test_and(self):
        assert _expr("d6 & d6") == And(D(Num(6)), D(Num(6)))


class TestExampleFiles:
    """Verify that all bundled Troll example files parse and round-trip."""

    @pytest.fixture
    def examples_dir(self):
        import os

        d = os.path.join(os.path.dirname(__file__), "..", "Troll", "Examples")
        if not os.path.isdir(d):
            pytest.skip("Troll/Examples not available")
        return d

    def test_all_examples_parse(self, examples_dir):
        import os

        failures = []
        for fname in sorted(os.listdir(examples_dir)):
            if not fname.endswith(".t"):
                continue
            path = os.path.join(examples_dir, fname)
            with open(path) as f:
                source = f.read()
            try:
                program = parse(source)
                # Round-trip: show must not crash
                show(program)
            except Exception as e:
                failures.append(f"{fname}: {e}")
        assert failures == [], "Failed to parse:\n" + "\n".join(failures)


class TestErrors:
    def test_unexpected_token(self):
        with pytest.raises(ParseError, match="Unexpected token"):
            parse(")")

    def test_missing_rpar(self):
        with pytest.raises(ParseError, match="Expected RPAR"):
            parse("(1 + 2")

    def test_tilde_requires_id_on_left(self):
        with pytest.raises(ParseError, match="must be an identifier"):
            parse("3 ~ 5")
