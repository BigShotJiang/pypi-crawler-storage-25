"""Tests for the Troll sampling evaluator."""

from __future__ import annotations

import random as _random

from troll.parser import parse
from troll.sampling import sample, sample_n
from troll.values import Multiset, as_int


def _sample(source: str, seed: int = 42) -> Multiset | str:
    """Parse and sample a Troll expression with a fixed seed."""
    result = sample(parse(source), _random.Random(seed))
    assert isinstance(result, (Multiset, str))
    return result


def _sample_int(source: str, seed: int = 42) -> int:
    return as_int(_sample(source, seed))


class TestDicePrimitives:
    def test_d6_in_range(self):
        for seed in range(100):
            v = _sample_int("d6", seed)
            assert 1 <= v <= 6

    def test_3d6_produces_3_values(self):
        result = _sample("3d6")
        assert isinstance(result, Multiset)
        assert len(result) == 3
        assert all(1 <= x <= 6 for x in result)

    def test_z6_in_range(self):
        for seed in range(100):
            v = _sample_int("z6", seed)
            assert 0 <= v <= 6


class TestArithmetic:
    def test_sum_2d6(self):
        v = _sample_int("sum 2d6")
        assert 2 <= v <= 12

    def test_addition(self):
        assert _sample_int("3 + 4") == 7

    def test_multiplication(self):
        assert _sample_int("3 * 4") == 12

    def test_division(self):
        assert _sample_int("10 / 3") == 3

    def test_modulo(self):
        assert _sample_int("10 mod 3") == 1

    def test_unary_minus(self):
        assert _sample_int("-5") == -5


class TestCollections:
    def test_largest_3_of_4d6(self):
        result = _sample("largest 3 4d6")
        assert isinstance(result, Multiset)
        assert len(result) == 3

    def test_count(self):
        assert _sample_int("count 3d6") == 3

    def test_choose(self):
        v = _sample_int("choose {1, 2, 3}")
        assert v in (1, 2, 3)

    def test_different(self):
        result = _sample("different {1, 1, 2, 2, 3}")
        assert isinstance(result, Multiset)
        assert list(result) == [1, 2, 3]


class TestControlFlow:
    def test_let_binding(self):
        assert _sample_int("x := 3 ; x + 1") == 4

    def test_if_true(self):
        assert _sample_int("if 1 then 10 else 20") == 10

    def test_if_false(self):
        assert _sample_int("if {} then 10 else 20") == 20

    def test_foreach(self):
        result = _sample("sum foreach i in 1..3 do i")
        assert as_int(result) == 6  # 1 + 2 + 3

    def test_repeat_until(self):
        """repeat x := d6 until x = 6 should give a value 1-6."""
        v = _sample_int("repeat x := d6 until x = 6")
        assert 1 <= v <= 6


class TestFunctions:
    def test_function_call(self):
        v = _sample_int("function f(x) = x + 1\ncall f(5)")
        assert v == 6


class TestSampleN:
    def test_multiple_samples(self):
        results = sample_n(parse("d6"), 100, _random.Random(42))
        values = [as_int(v) for v in results]
        assert all(1 <= v <= 6 for v in values)
        assert len(set(values)) > 1  # not all the same

    def test_deterministic_with_seed(self):
        a = sample_n(parse("sum 2d6"), 10, _random.Random(123))
        b = sample_n(parse("sum 2d6"), 10, _random.Random(123))
        assert a == b
