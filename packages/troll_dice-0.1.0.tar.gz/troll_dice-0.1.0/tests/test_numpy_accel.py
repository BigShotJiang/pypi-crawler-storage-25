"""Tests for numpy-accelerated distribution operations.

Verifies that numpy fast paths produce identical results to the dict-based
fallback paths. Also benchmarks key operations to confirm speedups.
"""

from __future__ import annotations

from fractions import Fraction

import pytest

from troll.distribution import (
    Distribution,
    _array_to_dist,
    _convolve,
    _convolve_n,
    _dist_to_array,
    _subtract_dists,
    distribute,
)
from troll.parser import parse
from troll.values import Multiset

np = pytest.importorskip("numpy")


def _d6_dist() -> Distribution:
    """Uniform d6 distribution."""
    return Distribution.uniform([Multiset.single(i) for i in range(1, 7)])


def _int_pmf(d: Distribution) -> dict[int, Fraction]:
    """Extract {int_value: probability} from a scalar-int distribution."""
    result: dict[int, Fraction] = {}
    for v, p in d.items():
        assert isinstance(v, Multiset) and len(v) == 1
        result[v[0]] = p
    return result


@pytest.mark.skipif(
    not __import__("troll.distribution", fromlist=["_HAS_NUMPY"])._HAS_NUMPY,
    reason="numpy disabled",
)
class TestDistToArray:
    def test_d6(self):
        d = _d6_dist()
        result = _dist_to_array(d)
        assert result is not None
        arr, offset, denom = result
        assert offset == 1
        assert denom == 6
        assert list(arr) == [1, 1, 1, 1, 1, 1]

    def test_multiset_returns_none(self):
        d = distribute(parse("2d6"))
        result = _dist_to_array(d)
        assert result is None

    def test_empty_returns_none(self):
        d = Distribution.impossible()
        result = _dist_to_array(d)
        assert result is None

    def test_noncontiguous_still_works(self):
        """d6 with gap (e.g., {1: 1/3, 3: 1/3, 5: 1/3}) should pad with zeros."""
        pmf = {
            Multiset.single(1): Fraction(1, 3),
            Multiset.single(3): Fraction(1, 3),
            Multiset.single(5): Fraction(1, 3),
        }
        d = Distribution(pmf)
        result = _dist_to_array(d)
        assert result is not None
        arr, offset, _denom = result
        assert offset == 1
        assert arr[0] > 0  # value 1
        assert arr[1] == 0  # value 2 (gap)
        assert arr[2] > 0  # value 3


@pytest.mark.skipif(
    not __import__("troll.distribution", fromlist=["_HAS_NUMPY"])._HAS_NUMPY,
    reason="numpy disabled",
)
class TestArrayToDist:
    def test_round_trip(self):
        d = _d6_dist()
        result = _dist_to_array(d)
        assert result is not None
        arr, offset, denom = result
        d2 = _array_to_dist(arr, offset, denom)
        assert _int_pmf(d) == _int_pmf(d2)

    def test_exact_fractions(self):
        """Array→Distribution should produce exact Fractions, not floats."""
        arr = np.array([1, 2, 3], dtype=np.int64)
        d = _array_to_dist(arr, 1, 6)
        pmf = _int_pmf(d)
        assert pmf[1] == Fraction(1, 6)
        assert pmf[2] == Fraction(2, 6)  # = 1/3
        assert pmf[3] == Fraction(3, 6)  # = 1/2


class TestConvolve:
    def test_d6_plus_d6(self):
        d6 = _d6_dist()
        result = _convolve(d6, d6)
        pmf = _int_pmf(result)
        assert pmf[2] == Fraction(1, 36)
        assert pmf[7] == Fraction(6, 36)
        assert pmf[12] == Fraction(1, 36)
        assert sum(pmf.values()) == 1

    def test_d6_plus_d8(self):
        d6 = _d6_dist()
        d8 = Distribution.uniform([Multiset.single(i) for i in range(1, 9)])
        result = _convolve(d6, d8)
        pmf = _int_pmf(result)
        assert min(pmf) == 2
        assert max(pmf) == 14
        assert sum(pmf.values()) == 1

    def test_matches_dict_fallback(self):
        """Numpy path must produce identical results to dict path."""
        d6 = _d6_dist()
        np_result = _convolve(d6, d6)

        # Force dict fallback
        dict_result = d6.combine(d6, lambda a, b: Multiset.single(a[0] + b[0]))

        assert _int_pmf(np_result) == _int_pmf(dict_result)


class TestSubtract:
    def test_d6_minus_d4(self):
        d6 = _d6_dist()
        d4 = Distribution.uniform([Multiset.single(i) for i in range(1, 5)])
        result = _subtract_dists(d6, d4)
        pmf = _int_pmf(result)
        assert min(pmf) == -3  # 1 - 4
        assert max(pmf) == 5  # 6 - 1
        assert sum(pmf.values()) == 1


class TestConvolveN:
    def test_sum_10d6(self):
        d6 = _d6_dist()
        result = _convolve_n(10, d6)
        pmf = _int_pmf(result)
        assert min(pmf) == 10
        assert max(pmf) == 60
        assert sum(pmf.values()) == 1

    def test_n_equals_0(self):
        d6 = _d6_dist()
        result = _convolve_n(0, d6)
        pmf = _int_pmf(result)
        assert pmf == {0: Fraction(1)}

    def test_n_equals_1(self):
        d6 = _d6_dist()
        result = _convolve_n(1, d6)
        assert _int_pmf(result) == _int_pmf(d6)

    def test_matches_troll(self):
        """sum 10d6 via convolve_n must match Troll distribution."""
        dist = distribute(parse("sum 10d6"))
        pmf = _int_pmf(dist)
        assert pmf[10] == Fraction(1, 6**10)
        assert abs(float(sum(v * p for v, p in pmf.items())) - 35.0) < 1e-10


class TestCountHash:
    def test_count_5_lt_10d6(self):
        """count 5< 10d6 — count dice showing 6. Should be Binomial(10, 1/6)."""
        dist = distribute(parse("count 5< 10d6"))
        pmf = _int_pmf(dist)
        assert sum(pmf.values()) == 1
        # P(0 sixes in 10d6) = (5/6)^10
        assert abs(float(pmf[0]) - (5 / 6) ** 10) < 1e-10
        # Mean should be 10/6
        mean = sum(k * float(p) for k, p in pmf.items())
        assert abs(mean - 10 / 6) < 1e-10

    def test_count_3_eq_5d6(self):
        """count 3= 5d6 — count 3s in 5d6. Binomial(5, 1/6)."""
        dist = distribute(parse("count 3= 5d6"))
        pmf = _int_pmf(dist)
        assert sum(pmf.values()) == 1
        assert abs(float(pmf[0]) - (5 / 6) ** 5) < 1e-10

    def test_count_4_le_8d6(self):
        """count 4<= 8d6 — count dice >= 4. Binomial(8, 3/6)."""
        dist = distribute(parse("count 4<= 8d6"))
        pmf = _int_pmf(dist)
        assert sum(pmf.values()) == 1
        mean = sum(k * float(p) for k, p in pmf.items())
        assert abs(mean - 8 * 0.5) < 1e-10


class TestEndToEnd:
    """Full expressions through the distribution engine with numpy active."""

    def test_sum_20d6(self):
        dist = distribute(parse("sum 20d6"))
        assert abs(dist.mean - 70.0) < 1e-10

    def test_sum_8_hash_3d6(self):
        dist = distribute(parse("sum 8#(3d6)"))
        # 8 * 3 dice, mean = 24 * 3.5 = 84
        assert abs(dist.mean - 84.0) < 1e-10

    def test_d20_minus_d6(self):
        dist = distribute(parse("d20 - d6"))
        pmf = _int_pmf(dist)
        assert min(pmf) == -5
        assert max(pmf) == 19

    def test_exact_mode_preserved(self):
        """With numpy, exact=True should still produce exact rational probabilities."""
        dist = distribute(parse("sum 2d6"), exact=True)
        for _, p in dist.items():
            assert not isinstance(p, float), "Expected exact rational, got float"


@pytest.mark.skipif(
    not __import__("troll.distribution", fromlist=["_HAS_NUMPY"])._HAS_NUMPY,
    reason="numpy disabled",
)
class TestPerformance:
    """Verify that numpy acceleration actually speeds things up."""

    def test_sum_20d6_under_50ms(self):
        import time

        prog = parse("sum 20d6")
        t0 = time.perf_counter()
        distribute(prog)
        ms = (time.perf_counter() - t0) * 1000
        assert ms < 50, f"sum 20d6 took {ms:.1f}ms, expected < 50ms"

    def test_count_5_lt_10d6_under_50ms(self):
        import time

        prog = parse("count 5< 10d6")
        t0 = time.perf_counter()
        distribute(prog)
        ms = (time.perf_counter() - t0) * 1000
        assert ms < 50, f"count 5< 10d6 took {ms:.1f}ms, expected < 50ms"
