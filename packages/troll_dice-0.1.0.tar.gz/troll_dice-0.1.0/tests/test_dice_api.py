"""Tests for the Pythonic dice API.

Verifies that every expression built via the dice API produces the same
distribution as the equivalent Troll DSL expression. Also tests ergonomics:
.roll() return types, method chaining, repr.
"""

from __future__ import annotations

from troll.dice import (
    Expr,
    call,
    coin,
    collection,
    const,
    d,
    empty,
    foreach,
    func,
    if_,
    let,
    pair,
    pool,
    range_,
    z,
)
from troll.distribution import distribute
from troll.parser import parse


def _same_dist(expr: Expr, troll_source: str) -> None:
    """Assert that a dice API Expr and a Troll source produce identical distributions."""
    api_dist = expr.dist()
    troll_dist = distribute(parse(troll_source))
    api_items = {str(v): float(p) for v, p in api_dist.items()}
    troll_items = {str(v): float(p) for v, p in troll_dist.items()}
    assert api_items.keys() == troll_items.keys(), (
        f"Different outcomes:\n  API: {sorted(api_items.keys())}\n"
        f"  Troll: {sorted(troll_items.keys())}"
    )
    for k in api_items:
        assert abs(api_items[k] - troll_items[k]) < 1e-10, f"Probability mismatch for {k}"


class TestDiceConstructors:
    def test_d6(self):
        _same_dist(d(6), "d6")

    def test_d20(self):
        _same_dist(d(20), "d20")

    def test_z6(self):
        _same_dist(z(6), "z6")

    def test_const(self):
        _same_dist(const(5), "5")

    def test_empty(self):
        _same_dist(empty(), "{}")

    def test_collection(self):
        _same_dist(collection(1, 2, 3), "{1, 2, 3}")

    def test_range(self):
        _same_dist(range_(1, 6), "1..6")

    def test_coin(self):
        _same_dist(coin(0.5), "?0.5")


class TestPool:
    def test_pool_4d6(self):
        _same_dist(pool(4, d(6)), "4d6")

    def test_pool_2d8(self):
        _same_dist(pool(2, d(8)), "2d8")

    def test_mul_syntax(self):
        _same_dist(4 * d(6), "4d6")

    def test_pool_0(self):
        _same_dist(pool(0, d(6)), "0d6")


class TestAggregation:
    def test_sum(self):
        _same_dist(pool(3, d(6)).sum(), "sum 3d6")

    def test_count(self):
        _same_dist(pool(3, d(6)).count(), "count 3d6")

    def test_highest(self):
        _same_dist(pool(4, d(6)).highest(3), "largest 3 4d6")

    def test_lowest(self):
        _same_dist(pool(4, d(6)).lowest(2), "least 2 4d6")

    def test_max(self):
        _same_dist(pool(3, d(6)).max(), "max 3d6")

    def test_min(self):
        _same_dist(pool(3, d(6)).min(), "min 3d6")

    def test_minimal(self):
        _same_dist(pool(3, d(6)).minimal(), "minimal 3d6")

    def test_maximal(self):
        _same_dist(pool(3, d(6)).maximal(), "maximal 3d6")

    def test_median(self):
        _same_dist(pool(3, d(6)).median(), "median 3d6")

    def test_sign(self):
        _same_dist((d(3) - 2).sign(), "sgn (d3 - 2)")

    def test_sum_highest_chain(self):
        """D&D stat roll: sum of best 3 of 4d6."""
        _same_dist(pool(4, d(6)).highest(3).sum(), "sum largest 3 4d6")


class TestArithmetic:
    def test_plus_int(self):
        _same_dist(d(20) + 5, "d20 + 5")

    def test_radd(self):
        _same_dist(5 + d(20), "5 + d20")

    def test_minus(self):
        _same_dist(d(20) - 3, "d20 - 3")

    def test_rsub(self):
        _same_dist(10 - d(6), "10 - d6")

    def test_times(self):
        _same_dist(d(6) * d(6), "d6 * d6")

    def test_floordiv(self):
        _same_dist(d(100) // 10, "d100 / 10")

    def test_mod(self):
        _same_dist(d(6) % 3, "d6 mod 3")

    def test_neg(self):
        _same_dist(-d(6), "-d6")

    def test_compound(self):
        _same_dist(d(6) * 2 + 3, "d6 * 2 + 3")

    def test_sum_2d6_plus_modifier(self):
        _same_dist(pool(2, d(6)).sum() + 5, "sum 2d6 + 5")


class TestCollectionOps:
    def test_union(self):
        _same_dist(d(6).union(d(8)), "d6 @ d8")

    def test_pipe_union(self):
        _same_dist(d(6) | d(8), "d6 @ d8")

    def test_drop(self):
        _same_dist(collection(1, 2, 3, 4, 5).drop(2, 4), "{1, 2, 3, 4, 5} drop {2, 4}")

    def test_keep(self):
        _same_dist(collection(1, 2, 3, 4, 5).keep(2, 4), "{1, 2, 3, 4, 5} keep {2, 4}")

    def test_pick(self):
        _same_dist(collection(1, 2, 3).pick(2), "{1, 2, 3} pick 2")

    def test_diff(self):
        _same_dist(
            collection(1, 1, 2, 3).diff(collection(1, 3)),
            "{1, 1, 2, 3} -- {1, 3}",
        )

    def test_unique(self):
        _same_dist(pool(3, d(4)).unique(), "different 3d4")

    def test_choose(self):
        _same_dist(collection(1, 2, 3).choose(), "choose {1, 2, 3}")

    def test_choose_range(self):
        _same_dist(range_(1, 6).choose(), "choose (1..6)")


class TestFiltering:
    def test_where_eq(self):
        _same_dist(pool(3, d(6)).where_eq(6), "6 = 3d6")

    def test_where_ne(self):
        _same_dist(pool(3, d(6)).where_ne(1), "1 =/= 3d6")

    def test_where_gt(self):
        _same_dist(pool(3, d(6)).where_gt(3), "3 < 3d6")

    def test_where_lt(self):
        _same_dist(pool(3, d(6)).where_lt(4), "4 > 3d6")

    def test_where_ge(self):
        _same_dist(pool(3, d(6)).where_ge(5), "5 <= 3d6")

    def test_where_le(self):
        _same_dist(pool(3, d(6)).where_le(2), "2 >= 3d6")

    def test_count_successes(self):
        """Shadowrun: count 5+ on 8d6."""
        _same_dist(pool(8, d(6)).where_ge(5).count(), "count 5<= 8d6")

    def test_count_filter_chain(self):
        """WoD-lite: count > 7 on 5d10."""
        _same_dist(pool(5, d(10)).where_gt(7).count(), "count 7< 5d10")


class TestControlFlow:
    def test_let_binding(self):
        _same_dist(let("x", d(6), lambda x: x + x), "x := d6 ; x + x")

    def test_nested_let(self):
        _same_dist(
            let("x", d(4), lambda x: let("y", d(4), lambda y: x + y)),
            "x := d4 ; y := d4 ; x + y",
        )

    def test_if_then_else(self):
        _same_dist(if_(d(2), const(10), const(20)), "if d2 then 10 else 20")

    def test_foreach(self):
        _same_dist(
            foreach("i", range_(1, 3), lambda i: i).sum(),
            "sum foreach i in 1..3 do i",
        )

    def test_foreach_count_eq(self):
        """Count how many dice match each face — the Equal.t pattern."""
        _same_dist(
            let(
                "x",
                pool(3, d(6)),
                lambda x: foreach("i", range_(1, 6), lambda i: x.where_eq(i).count()).max(),
            ),
            "x := 3d6 ; max foreach i in 1..6 do count i = x",
        )


class TestDieModifiers:
    def test_explode_on(self):
        """Exploding d10: accumulate x:=d10 while x=10."""
        _same_dist(
            d(10).explode(on=10).sum(),
            "sum accumulate x:=d10 while x=10",
        )

    def test_explode_while(self):
        """Explode on 5+: accumulate x:=d6 while x>=5."""
        _same_dist(
            d(6).explode(while_=lambda x: x.where_ge(5)).sum(),
            "sum accumulate x:=d6 while 5<= x",
        )

    def test_reroll_on(self):
        """d5 by rerolling 6s."""
        _same_dist(d(6).reroll(on=6), "repeat x := d6 while x = 6")

    def test_reroll_while(self):
        """Reroll 1s."""
        _same_dist(
            d(6).reroll(while_=lambda x: x.where_eq(1)),
            "repeat x := d6 while 1 = x",
        )

    def test_wod_full(self):
        """WoD: 5 exploding d10, count 8+."""
        _same_dist(
            pool(5, d(10).explode(on=10)).where_gt(7).count(),
            "count 7< 5#(accumulate x:=d10 while x=10)",
        )


class TestFunctions:
    def test_func_and_call(self):
        f = func("f", ["x"], lambda x: x + 1)
        expr = call("f", d(6))
        # Build program with declaration
        from troll.syntax import Program

        prog = Program([f], expr._node)
        api_dist = distribute(prog)
        troll_dist = distribute(parse("function f(x) = x + 1\ncall f(d6)"))
        api_items = {str(v): float(p) for v, p in api_dist.items()}
        troll_items = {str(v): float(p) for v, p in troll_dist.items()}
        assert api_items == troll_items


class TestPairs:
    def test_pair(self):
        _same_dist(pair(d(4), d(6)), "[d4, d6]")

    def test_first(self):
        _same_dist(pair(d(4), d(6)).first(), "%1 [d4, d6]")

    def test_second(self):
        _same_dist(pair(d(4), d(6)).second(), "%2 [d4, d6]")


class TestLogic:
    def test_and(self):
        _same_dist(d(6).and_(d(8)), "d6 & d8")

    def test_negate(self):
        _same_dist(d(6).negate(), "!d6")


class TestRoll:
    """Test that .roll() returns sensible Python types."""

    def test_scalar_returns_int(self):
        result = d(6).roll(seed=42)
        assert isinstance(result, int)
        assert 1 <= result <= 6

    def test_sum_returns_int(self):
        result = pool(2, d(6)).sum().roll(seed=42)
        assert isinstance(result, int)
        assert 2 <= result <= 12

    def test_collection_returns_list(self):
        result = pool(3, d(6)).roll(seed=42)
        assert isinstance(result, list)
        assert len(result) == 3
        assert all(1 <= x <= 6 for x in result)

    def test_empty_returns_empty_list(self):
        result = empty().roll()
        assert result == []

    def test_multiple_rolls(self):
        results = d(6).roll(n=10, seed=42)
        assert len(results) == 10
        assert all(isinstance(r, int) for r in results)

    def test_arithmetic_roll(self):
        result = (d(20) + 5).roll(seed=42)
        assert isinstance(result, int)
        assert 6 <= result <= 25


class TestRepr:
    """Repr should show readable Troll-like syntax."""

    def test_d6(self):
        assert repr(d(6)) == "d6"

    def test_sum_2d6(self):
        assert repr(pool(2, d(6)).sum()) == "sum (2 # d6)"

    def test_chain(self):
        expr = pool(4, d(6)).highest(3).sum()
        assert "sum" in repr(expr)
        assert "largest" in repr(expr)


class TestRPGExamples:
    """End-to-end RPG expression equivalence tests."""

    def test_dnd_stat_roll(self):
        _same_dist(pool(4, d(6)).highest(3).sum(), "sum largest 3 4d6")

    def test_dnd_advantage(self):
        _same_dist(pool(2, d(20)).max() + 5, "max 2d20 + 5")

    def test_fate_dice(self):
        _same_dist(pool(4, d(3) - 2).sum(), "sum 4#(d3 - 2)")

    def test_risk_battle(self):
        api = let(
            "a",
            pool(3, d(6)),
            lambda a: let(
                "b",
                pool(2, d(6)),
                lambda b: (
                    a.max().where_gt(b.max()).count() + a.highest(2).min().where_gt(b.min()).count()
                ),
            ),
        )
        troll = (
            "attack := 3d6 ; defense := 2d6 ;\n"
            "(count (max attack)>(max defense))"
            " + (count (min largest 2 attack)>(min defense))"
        )
        _same_dist(api, troll)

    def test_shadowrun_pool(self):
        _same_dist(pool(8, d(6)).where_ge(5).count(), "count 5<= 8d6")

    def test_wod_pool(self):
        _same_dist(
            pool(5, d(10).explode(on=10)).where_gt(7).count(),
            "count 7< 5#(accumulate x:=d10 while x=10)",
        )

    def test_d5_by_reroll(self):
        _same_dist(d(6).reroll(on=6), "repeat x := d6 while x = 6")

    def test_efron_dice(self):
        a = collection(4, 4, 4, 4, 0, 0).choose()
        b = collection(3, 3, 3, 3, 3, 3).choose()
        _same_dist(
            a.where_gt(b).count(),
            "A := choose {4,4,4,4,0,0} ; B := choose {3,3,3,3,3,3} ; count A > B",
        )
