"""Comparison tests: troll distribution output vs original Troll.

Runs both troll and the original Moscow ML Troll binary on the same
expressions and verifies that the probability distributions match.

Requires the `troll` binary to be built from source. Skips if not available.
"""

from __future__ import annotations

import os as _os
import re as _re
import subprocess as _subprocess

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from troll.distribution import distribute
from troll.parser import parse
from troll.values import Multiset

TROLL_BIN = "/Users/manderso/git/external/Troll/troll"
EXAMPLES_DIR = "/Users/manderso/git/external/Troll/Examples"


@pytest.fixture(autouse=True)
def _require_troll():
    if not _os.path.isfile(TROLL_BIN):
        pytest.skip("Troll binary not available — run compile.sh first")


# ---------------------------------------------------------------------------
# Harness
# ---------------------------------------------------------------------------


def _run_troll(source: str, max_iter: int = 12) -> dict[str, float]:
    """Run the original Troll in distribution mode (-p for raw probabilities).

    Returns {value_string: probability}.
    """
    args = [TROLL_BIN, f"-{max_iter}" if max_iter != 12 else "0", "-p"]
    result = _subprocess.run(
        args,
        input=source,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        pytest.fail(f"Troll failed on {source!r}: {result.stderr}")

    pmf: dict[str, float] = {}
    for line in result.stdout.splitlines():
        m = _re.match(r"\s*(.+?):\s+(\S+)\s+\S+\s*$", line)
        if m:
            val_str = m.group(1).strip()
            # Moscow ML uses ~ for negative exponent: 2.5E~5 → 2.5E-5
            prob_str = m.group(2).replace("~", "-")
            prob = float(prob_str)
            # Normalize empty multiset representation
            if val_str == "":
                val_str = "{}"
            if prob > 0:
                pmf[val_str] = prob
    return pmf


def _run_troll(source: str, max_iter: int = 12) -> dict[str, float]:
    """Run troll distribution engine. Same return format as _run_troll."""
    dist = distribute(parse(source), max_iterations=max_iter)
    pmf: dict[str, float] = {}
    for v, p in dist.items():
        fp = float(p)
        if fp > 1e-15:
            pmf[_format_val(v)] = fp
    return pmf


def _format_val(v: object) -> str:
    """Format a value to match Troll's output format."""
    from troll.values import PairVal as _PairVal

    if isinstance(v, Multiset):
        return " ".join(str(x) for x in v) if v else "{}"
    if isinstance(v, _PairVal):
        return f"[{_format_val(v.first)}, {_format_val(v.second)}]"
    return str(v)


def _compare(source: str, *, rtol: float = 1e-8, max_iter: int = 12) -> None:
    """Compare troll and Troll distributions for a given expression."""
    troll_pmf = _run_troll(source, max_iter)
    py_pmf = _run_troll(source, max_iter)

    troll_keys = {k for k in troll_pmf if troll_pmf[k] > 1e-12}
    py_keys = {k for k in py_pmf if py_pmf[k] > 1e-12}

    errors: list[str] = []
    missing = troll_keys - py_keys
    extra = py_keys - troll_keys
    if missing:
        errors.append(f"In Troll but not troll: {missing}")
    if extra:
        errors.append(f"In troll but not Troll: {extra}")

    for key in troll_keys & py_keys:
        t_p = troll_pmf[key]
        p_p = py_pmf[key]
        if abs(t_p - p_p) > rtol * max(abs(t_p), abs(p_p), 1e-15):
            errors.append(f"  {key}: troll={t_p:.12f} troll={p_p:.12f} diff={abs(t_p - p_p):.2e}")

    if errors:
        pytest.fail(f"Mismatch for: {source!r}\n" + "\n".join(errors))


# ---------------------------------------------------------------------------
# Systematic coverage: every language feature
# ---------------------------------------------------------------------------


class TestDicePrimitives:
    """d and z with various sizes."""

    def test_d4(self):
        _compare("d4")

    def test_d6(self):
        _compare("d6")

    def test_d8(self):
        _compare("d8")

    def test_d10(self):
        _compare("d10")

    def test_d12(self):
        _compare("d12")

    def test_d20(self):
        _compare("d20")

    def test_d1(self):
        _compare("d1")

    def test_z0(self):
        _compare("z0")

    def test_z1(self):
        _compare("z1")

    def test_z6(self):
        _compare("z6")


class TestHash:
    """N # die — repeated rolls."""

    def test_1d6(self):
        _compare("1d6")

    def test_2d6(self):
        _compare("2d6")

    def test_3d6(self):
        _compare("3d6")

    def test_4d6(self):
        _compare("4d6")

    def test_0d6(self):
        _compare("0d6")

    def test_2d4(self):
        _compare("2d4")

    def test_3d8(self):
        _compare("3d8")

    def test_hash_syntax(self):
        _compare("3 # d6")

    def test_nested_hash(self):
        """2 # 2d6 — roll 2d6 twice, union all."""
        _compare("2 # 2d6")


class TestArithmetic:
    """All arithmetic operators on singletons."""

    def test_plus(self):
        _compare("d6 + d6")

    def test_plus_constant(self):
        _compare("d6 + 3")

    def test_minus(self):
        _compare("d6 - d6")

    def test_minus_constant(self):
        _compare("d6 - 3")

    def test_times(self):
        _compare("d6 * d6")

    def test_times_constant(self):
        _compare("d6 * 2")

    def test_divide(self):
        _compare("d6 / 2")

    def test_mod(self):
        _compare("d6 mod 3")

    def test_uminus(self):
        _compare("-d6")

    def test_sgn_positive(self):
        _compare("sgn d6")

    def test_sgn_mixed(self):
        _compare("sgn (d3 - 2)")

    def test_compound(self):
        _compare("d6 * 2 + 3")

    def test_precedence(self):
        _compare("d6 + d6 * 2")


class TestSum:
    """sum — total a collection into a singleton."""

    def test_sum_d6(self):
        _compare("sum d6")

    def test_sum_2d6(self):
        _compare("sum 2d6")

    def test_sum_3d6(self):
        _compare("sum 3d6")

    def test_sum_4d6(self):
        _compare("sum 4d6")

    def test_sum_2d6_plus_modifier(self):
        _compare("sum 2d6 + 5")

    def test_sum_empty(self):
        _compare("sum {}")


class TestCount:
    """count — number of elements."""

    def test_count_d6(self):
        _compare("count d6")

    def test_count_3d6(self):
        _compare("count 3d6")

    def test_count_empty(self):
        _compare("count {}")

    def test_count_filtered(self):
        _compare("count 3 < d6")


class TestLeastLargest:
    """least, largest, min, max."""

    def test_largest_1_3d6(self):
        _compare("max 3d6")

    def test_least_1_3d6(self):
        _compare("min 3d6")

    def test_largest_2_3d6(self):
        _compare("largest 2 3d6")

    def test_least_2_3d6(self):
        _compare("least 2 3d6")

    def test_largest_3_4d6(self):
        _compare("largest 3 4d6")

    def test_sum_largest_3_4d6(self):
        _compare("sum largest 3 4d6")

    def test_largest_exceeds_count(self):
        _compare("largest 5 3d6")

    def test_least_0(self):
        _compare("least 0 3d6")


class TestMinimalMaximalMedian:
    def test_minimal(self):
        _compare("minimal 3d6")

    def test_maximal(self):
        _compare("maximal 3d6")

    def test_median(self):
        _compare("median 3d6")


class TestComparisons:
    """Comparison-as-filter operators."""

    def test_eq(self):
        _compare("3 = 2d6")

    def test_neq(self):
        _compare("3 =/= 2d6")

    def test_lt(self):
        _compare("3 < d6")

    def test_gt(self):
        _compare("3 > d6")

    def test_le(self):
        _compare("3 <= d6")

    def test_ge(self):
        _compare("3 >= d6")

    def test_count_eq(self):
        _compare("count 3 = 2d6")

    def test_count_lt(self):
        _compare("count 3 < 3d6")


class TestCollectionOps:
    """Collection manipulation."""

    def test_conc(self):
        _compare("d6 @ d8")

    def test_conc_literal(self):
        _compare("{1, 2, 3}")

    def test_empty(self):
        _compare("{}")

    def test_choose(self):
        _compare("choose {1, 2, 3}")

    def test_choose_d6(self):
        _compare("choose d6")

    def test_different(self):
        _compare("different 2d6")

    def test_different_3d4(self):
        _compare("different 3d4")

    def test_drop(self):
        _compare("{1, 2, 3, 4, 5} drop {2, 4}")

    def test_keep(self):
        _compare("{1, 2, 3, 4, 5} keep {2, 4}")

    def test_setminus(self):
        _compare("{1, 1, 2, 3} -- {1, 3}")

    def test_range(self):
        _compare("1..6")

    def test_choose_range(self):
        _compare("choose 1..6")


class TestPick:
    """pick — random selection without replacement."""

    def test_pick_1_from_3(self):
        _compare("{1, 2, 3} pick 1")

    def test_pick_2_from_3(self):
        _compare("{1, 2, 3} pick 2")

    def test_pick_3_from_3(self):
        _compare("{1, 2, 3} pick 3")


class TestAnd:
    """& — conditional evaluation."""

    def test_and_true(self):
        _compare("{1} & d6")

    def test_and_false(self):
        _compare("{} & d6")

    def test_and_probabilistic(self):
        _compare("d2 & d6")


class TestLetBinding:
    """Variable binding with := ;"""

    def test_simple(self):
        _compare("x := d6 ; x + x")

    def test_nested(self):
        _compare("x := d4 ; y := d4 ; x + y")

    def test_shadowing(self):
        _compare("x := 3 ; x := x + 1 ; x")

    def test_complex_binding(self):
        _compare("x := 2d6 ; sum x")

    def test_binding_in_condition(self):
        _compare("x := d6 ; if 3 < x then x else 0")


class TestIfThenElse:
    """Conditional expressions."""

    def test_deterministic_true(self):
        _compare("if 1 then 10 else 20")

    def test_deterministic_false(self):
        _compare("if {} then 10 else 20")

    def test_probabilistic(self):
        _compare("x := d2 ; if 1 = x then 10 else 20")

    def test_nested_if(self):
        _compare("x := d6 ; if 4 < x then 2 else if 2 < x then 1 else 0")


class TestForeach:
    """foreach iteration."""

    def test_identity(self):
        _compare("foreach i in 1..3 do i")

    def test_sum_foreach(self):
        _compare("sum foreach i in 1..3 do i")

    def test_foreach_with_dice(self):
        _compare("sum foreach i in 1..3 do d6")

    def test_count_eq_foreach(self):
        """Count how many of 3d6 equal each face — the Equal.t pattern."""
        _compare("x := 3d6 ; max foreach i in 1..6 do count i = x")


class TestRepeat:
    """repeat — loop keeping last value."""

    def test_d5_by_reroll(self):
        _compare("repeat x := d6 while x = 6")

    def test_repeat_until(self):
        _compare("repeat x := d6 until 3 < x")

    def test_repeat_bounded(self):
        _compare("repeat x := d2 while x = 1", max_iter=5)


class TestAccumulate:
    """accumulate — loop collecting all values."""

    def test_sum_accum_d2(self):
        _compare("sum accumulate x:=d2 until x=2")

    def test_accum_bounded(self):
        _compare("sum accumulate x:=d2 until x=2", max_iter=5)

    def test_count_accum(self):
        _compare("count accumulate x:=d2 until x=2")

    def test_exploding_d10(self):
        """WoD-style: accumulate d10 while rolling 10."""
        _compare("sum accumulate x:=d10 while x=10")


class TestFunctions:
    """User-defined functions."""

    def test_simple_function(self):
        _compare("function f(x) = x + 1\ncall f(d6)")

    def test_two_arg_function(self):
        _compare("function f(x, y) = x + y\ncall f(d4, d6)")

    def test_recursive_usage(self):
        """Function called multiple times."""
        _compare("function f(x) = x * 2\nsum foreach i in 1..3 do call f(i)")


class TestQuestion:
    """? probability operator."""

    def test_half(self):
        _compare("?0.5")

    def test_quarter(self):
        _compare("?0.25")

    def test_conditional_on_question(self):
        _compare("if ?0.5 then d6 else d8")


class TestPairs:
    """Pair construction and projection."""

    def test_pair(self):
        _compare("[d4, d6]")

    def test_first(self):
        _compare("%1 [d4, d6]")

    def test_second(self):
        _compare("%2 [d4, d6]")


class TestDefault:
    """~ default operator."""

    def test_default_unbound(self):
        _compare("x ~ 5")

    def test_default_bound(self):
        _compare("x := 3 ; x ~ 5")


class TestBang:
    """! negation operator."""

    def test_bang_nonempty(self):
        _compare("!d6")

    def test_bang_empty(self):
        _compare("!{}")

    def test_bang_probabilistic(self):
        _compare("x := d2 ; !(1 = x)")


class TestExampleFiles:
    """All bundled .t example files."""

    @pytest.fixture
    def examples(self):
        if not _os.path.isdir(EXAMPLES_DIR):
            pytest.skip("Troll examples not available")
        files = {}
        for fname in sorted(_os.listdir(EXAMPLES_DIR)):
            if fname.endswith(".t"):
                path = _os.path.join(EXAMPLES_DIR, fname)
                with open(path) as f:
                    files[fname] = f.read()
        return files

    def test_d20stat(self, examples):
        _compare(examples["d20stat.t"])

    def test_risk(self, examples):
        _compare(examples["Risk.t"])

    def test_backgammon(self, examples):
        _compare(examples["Backgammon.t"])

    def test_d5_by_reroll(self, examples):
        _compare(examples["d5byReroll.t"])

    def test_efron(self, examples):
        _compare(examples["Efron.t"])

    def test_equal_n3(self, examples):
        _compare(f"N := 3 ;\n{examples['Equal.t']}")

    def test_equal_n4(self, examples):
        _compare(f"N := 4 ;\n{examples['Equal.t']}")

    def test_median3_d6(self, examples):
        _compare(f"N := 6 ;\n{examples['Median3.t']}")

    def test_median3_d8(self, examples):
        _compare(f"N := 8 ;\n{examples['Median3.t']}")

    def test_open_d6(self, examples):
        _compare(examples["OpenD6.t"])

    def test_yathzee(self, examples):
        _compare(examples["Yathzee.t"])

    def test_diff_n3(self, examples):
        _compare(f"N := 3 ;\n{examples['Diff.t']}")


# ---------------------------------------------------------------------------
# Hypothesis: random valid Troll expressions
# ---------------------------------------------------------------------------


def _die(sides: int) -> str:
    return f"d{sides}"


def _hash(n: int, sides: int) -> str:
    return f"{n}d{sides}"


# Strategy: generate valid Troll expression strings
_sides = st.sampled_from([2, 3, 4, 6, 8, 10, 12, 20])
_small_sides = st.sampled_from([2, 3, 4, 6])
_small_n = st.integers(min_value=1, max_value=4)
_modifier = st.integers(min_value=-5, max_value=10)

# Simple scalar expressions (always produce singletons)
_scalar_expr = st.one_of(
    # d6, d20, etc
    _sides.map(lambda s: f"d{s}"),
    # sum NdS
    st.tuples(_small_n, _small_sides).map(lambda t: f"sum {t[0]}d{t[1]}"),
    # count NdS
    st.tuples(_small_n, _small_sides).map(lambda t: f"count {t[0]}d{t[1]}"),
    # max NdS
    st.tuples(_small_n, _small_sides).map(lambda t: f"max {t[0]}d{t[1]}"),
    # min NdS
    st.tuples(_small_n, _small_sides).map(lambda t: f"min {t[0]}d{t[1]}"),
    # sum largest K NdS
    st.tuples(_small_n, _small_n, _small_sides)
    .filter(lambda t: t[0] <= t[1])
    .map(lambda t: f"sum largest {t[0]} {t[1]}d{t[2]}"),
)

# Scalar with arithmetic modifier
_modified_scalar = st.tuples(_scalar_expr, _modifier).map(
    lambda t: f"{t[0]} + {t[1]}" if t[1] >= 0 else f"{t[0]} - {-t[1]}"
)

# Collection expressions
_collection_expr = st.one_of(
    # NdS
    st.tuples(_small_n, _small_sides).map(lambda t: f"{t[0]}d{t[1]}"),
    # different NdS
    st.tuples(_small_n, _small_sides).map(lambda t: f"different {t[0]}d{t[1]}"),
    # largest K NdS
    st.tuples(_small_n, _small_n, _small_sides)
    .filter(lambda t: t[0] <= t[1])
    .map(lambda t: f"largest {t[0]} {t[1]}d{t[2]}"),
)

# Full expression strategy
_expr = st.one_of(
    _scalar_expr,
    _modified_scalar,
    # choose from collection
    _collection_expr.map(lambda e: f"choose {e}"),
    # count comparison
    st.tuples(st.integers(1, 6), _small_sides).map(lambda t: f"count {t[0]} < d{t[1]}"),
    # median
    st.tuples(_small_n, _small_sides).map(lambda t: f"median {t[0]}d{t[1]}"),
    # let binding with sum
    st.tuples(_small_n, _small_sides).map(lambda t: f"x := {t[0]}d{t[1]} ; sum x"),
)


class TestHypothesis:
    """Property-based testing: random expressions must match Troll exactly."""

    @given(expr=_scalar_expr)
    @settings(max_examples=50, deadline=10000)
    def test_scalar_expressions(self, expr: str):
        _compare(expr)

    @given(expr=_modified_scalar)
    @settings(max_examples=50, deadline=10000)
    def test_modified_scalars(self, expr: str):
        _compare(expr)

    @given(expr=_collection_expr)
    @settings(max_examples=50, deadline=10000)
    def test_collection_expressions(self, expr: str):
        _compare(expr)

    @given(expr=_expr)
    @settings(max_examples=100, deadline=10000)
    def test_mixed_expressions(self, expr: str):
        _compare(expr)

    @given(
        n=st.integers(1, 3),
        sides=_small_sides,
        k=st.integers(1, 3),
    )
    @settings(max_examples=30, deadline=10000)
    def test_sum_largest_k_of_n(self, n: int, sides: int, k: int):
        k = min(k, n)
        _compare(f"sum largest {k} {n}d{sides}")

    @given(
        sides=_small_sides,
        mod=_modifier,
    )
    @settings(max_examples=30, deadline=10000)
    def test_d_plus_modifier(self, sides: int, mod: int):
        if mod >= 0:
            _compare(f"d{sides} + {mod}")
        else:
            _compare(f"d{sides} - {-mod}")

    @given(
        n=st.integers(1, 3),
        sides=_small_sides,
    )
    @settings(max_examples=30, deadline=10000)
    def test_foreach_count_eq(self, n: int, sides: int):
        """Count matching dice — the Equal.t pattern with random params."""
        _compare(f"x := {n}d{sides} ; max foreach i in 1..{sides} do count i = x")
