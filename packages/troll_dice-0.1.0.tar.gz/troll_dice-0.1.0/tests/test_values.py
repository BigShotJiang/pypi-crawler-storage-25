"""Tests for Troll runtime value types."""

import pytest

from troll.values import EMPTY, EvalError, Multiset, PairVal, as_int


class TestMultiset:
    def test_construction_sorts(self):
        assert list(Multiset([3, 1, 2])) == [1, 2, 3]

    def test_empty(self):
        assert len(EMPTY) == 0
        assert not EMPTY

    def test_singleton(self):
        ms = Multiset.single(5)
        assert list(ms) == [5]
        assert as_int(ms) == 5

    def test_hash_and_eq(self):
        a = Multiset([1, 2, 3])
        b = Multiset([3, 1, 2])
        assert a == b
        assert hash(a) == hash(b)
        assert a != Multiset([1, 2, 4])

    def test_ordering(self):
        assert Multiset([1, 2]) < Multiset([1, 3])
        assert Multiset([1]) < Multiset([1, 2])

    def test_union_preserves_sort(self):
        a = Multiset([1, 3, 5])
        b = Multiset([2, 4])
        assert list(a.union(b)) == [1, 2, 3, 4, 5]

    def test_union_with_duplicates(self):
        a = Multiset([1, 3])
        b = Multiset([1, 2])
        assert list(a.union(b)) == [1, 1, 2, 3]

    def test_sum(self):
        assert Multiset([1, 2, 3]).sum_() == 6

    def test_least_and_largest(self):
        ms = Multiset([1, 2, 3, 4, 5])
        assert list(ms.least(3)) == [1, 2, 3]
        assert list(ms.largest(3)) == [3, 4, 5]

    def test_minimal_and_maximal(self):
        ms = Multiset([1, 1, 2, 3, 3])
        assert list(ms.minimal()) == [1, 1]
        assert list(ms.maximal()) == [3, 3]

    def test_different(self):
        assert list(Multiset([1, 1, 2, 3, 3]).different()) == [1, 2, 3]

    def test_drop_and_keep(self):
        ms = Multiset([1, 2, 3, 4, 5])
        assert list(ms.drop(Multiset([2, 4]))) == [1, 3, 5]
        assert list(ms.keep(Multiset([2, 4]))) == [2, 4]

    def test_set_minus(self):
        a = Multiset([1, 1, 2, 3])
        b = Multiset([1, 3])
        assert list(a.set_minus(b)) == [1, 2]

    def test_filter_eq(self):
        ms = Multiset([1, 2, 3, 4, 5])
        assert list(ms.filter_eq(3)) == [3]
        assert list(ms.filter_neq(3)) == [1, 2, 4, 5]

    def test_filter_lt_gt(self):
        ms = Multiset([1, 2, 3, 4, 5])
        assert list(ms.filter_lt(3)) == [4, 5]  # elements > 3 (where 3 < x)
        assert list(ms.filter_gt(3)) == [1, 2]  # elements < 3 (where 3 > x)

    def test_from_to(self):
        assert list(Multiset.from_to(1, 6)) == [1, 2, 3, 4, 5, 6]

    def test_as_int_not_singleton(self):
        with pytest.raises(EvalError):
            as_int(Multiset([1, 2]))
        with pytest.raises(EvalError):
            as_int(EMPTY)


class TestPairVal:
    def test_construction_and_access(self):
        p = PairVal(Multiset.single(1), Multiset.single(2))
        assert as_int(p.first) == 1
        assert as_int(p.second) == 2

    def test_hashable(self):
        p = PairVal(Multiset.single(1), Multiset.single(2))
        d = {p: "test"}
        assert d[PairVal(Multiset.single(1), Multiset.single(2))] == "test"
