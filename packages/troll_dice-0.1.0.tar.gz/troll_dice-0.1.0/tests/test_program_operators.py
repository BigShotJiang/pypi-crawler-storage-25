"""Exploratory tests: what happens when a D&D player uses Python operators on Programs?

These tests document the CURRENT behavior and flag cases where it's
surprising or wrong. Each test is annotated with the probable human intent.
"""

from __future__ import annotations

import pytest

from troll import Multiset, parse
from troll.syntax import Program, show
from troll.values import as_int

# -- Helpers --


def _is_collection_expr(prog: Program) -> bool:
    """Does this program's expression produce a multi-element collection?"""
    from troll.syntax import (
        Conc,
        Different,
        Drop,
        Foreach,
        FromTo,
        Hash,
        Keep,
        Pick,
        SetMinus,
    )

    return isinstance(
        prog.expression, (Hash, Conc, FromTo, Different, Drop, Keep, Pick, SetMinus, Foreach)
    )


# ============================================================
# SCALAR EXPRESSIONS: these should all just work
# ============================================================


class TestScalarArithmetic:
    """d20 + 5, d12 - 2, etc. — single die + modifier. Bread and butter."""

    def test_d20_plus_modifier(self):
        """D&D ability check: d20 + 5."""
        prog = parse("d20") + 5
        assert isinstance(prog, Program)
        assert show(prog) == "(d20 + 5)"
        val = as_int(prog.sample())
        assert 6 <= val <= 25

    def test_d20_minus_penalty(self):
        """D&D check with penalty: d20 - 2."""
        prog = parse("d20") - 2
        assert show(prog) == "(d20 - 2)"
        val = as_int(prog.sample())
        assert -1 <= val <= 18

    def test_sum_2d6_plus_modifier(self):
        """Damage roll: sum 2d6 + 3. Already scalar because of sum."""
        prog = parse("sum 2d6") + 3
        assert show(prog) == "(sum (2 # d6) + 3)"
        val = as_int(prog.sample())
        assert 5 <= val <= 15

    def test_negate_scalar(self):
        """-d6 should work fine."""
        prog = -parse("d6")
        assert show(prog) == "(-d6)"
        val = as_int(prog.sample())
        assert -6 <= val <= -1

    def test_scalar_times_scalar(self):
        """Critical hit: double the damage die. d8 * 2."""
        prog = parse("d8") * parse("d8")
        assert isinstance(prog, Program)

    def test_int_plus_program(self):
        """5 + d20 should also work (radd)."""
        prog = 5 + parse("d20")
        assert show(prog) == "(5 + d20)"

    def test_program_plus_program_scalars(self):
        """sum 2d6 + d4 — both scalar, should just add."""
        prog = parse("sum 2d6") + parse("d4")
        assert isinstance(prog, Program)
        val = as_int(prog.sample())
        assert 3 <= val <= 16


# ============================================================
# REPEAT: int * program — universally expected to mean "N dice"
# ============================================================


class TestRepeat:
    """5 * d6 = roll 5d6. This is the standard notation."""

    def test_int_times_program(self):
        """5 * parse("d6") → 5d6."""
        prog = 5 * parse("d6")
        assert show(prog) == "(5 # d6)"
        result = prog.sample()
        assert isinstance(result, Multiset)
        assert len(result) == 5

    def test_four_d6(self):
        """4 * parse("d6") for D&D stat rolling."""
        prog = 4 * parse("d6")
        assert show(prog) == "(4 # d6)"
        result = prog.sample()
        assert len(result) == 4
        assert all(1 <= x <= 6 for x in result)


# ============================================================
# COLLECTION + SCALAR: the ambiguous cases
# ============================================================


class TestCollectionPlusScalar:
    """parse("3d6") + 5 — the user probably means sum(3d6)+5 but it's ambiguous."""

    def test_3d6_plus_5_errors(self):
        """3d6 + 5 is ambiguous: sum first? add to each? append?"""
        with pytest.raises(TypeError, match="Cannot use"):
            parse("3d6") + 5

    def test_error_suggests_sum(self):
        """The error should mention .sum() as an option."""
        with pytest.raises(TypeError, match=r"\.sum\(\)"):
            parse("3d6") + 5

    def test_error_suggests_max(self):
        """The error should mention .max() as an option."""
        with pytest.raises(TypeError, match=r"\.max\(\)"):
            parse("3d6") + 5

    def test_sum_fix_works(self):
        """parse("3d6").sum() + 5 should work."""
        prog = parse("3d6").sum() + 5
        assert show(prog) == "(sum (3 # d6) + 5)"
        val = as_int(prog.sample())
        assert 8 <= val <= 23

    def test_max_fix_works(self):
        """parse("3d6").max() + 5 should work."""
        prog = parse("3d6").max() + 5
        assert show(prog) == "(largest 1 (3 # d6) + 5)"
        val = as_int(prog.sample())
        assert 6 <= val <= 11

    def test_3d6_minus_2_errors(self):
        with pytest.raises(TypeError, match="Cannot use"):
            parse("3d6") - 2

    def test_minus_fix_works(self):
        prog = parse("3d6").sum() - 2
        val = as_int(prog.sample())
        assert 1 <= val <= 16


# ============================================================
# COLLECTION + COLLECTION: also ambiguous
# ============================================================


class TestCollectionPlusCollection:
    """parse("2d6") + parse("d8") — union? add sums?"""

    def test_collection_plus_collection_errors(self):
        """2d6 + d8 is ambiguous: union? add sums?"""
        with pytest.raises(TypeError, match="Cannot use"):
            parse("2d6") + parse("d8")

    def test_union_via_troll_syntax(self):
        """To combine pools, use Troll's @ operator via parse()."""
        combined = parse("2d6 @ d8")
        result = combined.sample()
        assert isinstance(result, Multiset)
        assert len(result) == 3


# ============================================================
# COLLECTION * INT: ambiguous
# ============================================================


class TestCollectionTimesInt:
    """parse("3d6") * 5 — repeat? multiply each? multiply sum?"""

    def test_collection_times_int_errors(self):
        """3d6 * 5 is ambiguous: repeat? multiply sum? multiply each?"""
        with pytest.raises(TypeError, match="Cannot use"):
            parse("3d6") * 5

    def test_error_suggests_repeat(self):
        """The error should suggest N * expr for repeat."""
        with pytest.raises(TypeError, match=r"5 \* expr"):
            parse("3d6") * 5

    def test_int_times_collection_is_repeat(self):
        """5 * parse("3d6") is unambiguous: repeat 3d6 five times."""
        prog = 5 * parse("3d6")
        assert show(prog) == "(5 # (3 # d6))"
        result = prog.sample()
        assert isinstance(result, Multiset)
        assert len(result) == 15


# ============================================================
# CONVENIENCE METHODS
# ============================================================


class TestConvenienceMethods:
    """.sum(), .count(), .max(), .min() on Program."""

    def test_sum(self):
        prog = parse("3d6").sum()
        assert show(prog) == "sum (3 # d6)"
        val = as_int(prog.sample())
        assert 3 <= val <= 18

    def test_count(self):
        prog = parse("3d6").count()
        assert show(prog) == "count (3 # d6)"
        assert as_int(prog.sample()) == 3

    def test_max(self):
        prog = parse("3d6").max()
        assert show(prog) == "largest 1 (3 # d6)"
        val = as_int(prog.sample())
        assert 1 <= val <= 6

    def test_min(self):
        prog = parse("3d6").min()
        assert show(prog) == "least 1 (3 # d6)"
        val = as_int(prog.sample())
        assert 1 <= val <= 6

    def test_chaining(self):
        """parse("4d6").sum() + 5 — full chain."""
        prog = parse("4d6").sum() + 5
        assert show(prog) == "(sum (4 # d6) + 5)"

    def test_distribution_after_chain(self):
        """Chained programs should support .distribution()."""
        dist = (parse("3d6").sum() + 5).distribution()
        assert abs(dist.mean - 15.5) < 0.01


# ============================================================
# EDGE CASES
# ============================================================


class TestEdgeCases:
    def test_d6_is_scalar_not_collection(self):
        """d6 produces a singleton — arithmetic should work directly."""
        prog = parse("d6") + 5
        assert isinstance(prog, Program)
        val = as_int(prog.sample())
        assert 6 <= val <= 11

    def test_program_repr_shows_troll_syntax(self):
        """repr should show Troll syntax, not AST internals."""
        prog = parse("sum largest 3 4d6")
        assert "Num" not in repr(prog)
        assert "sum" in repr(prog)

    def test_non_int_operand_type_error(self):
        """parse("d6") + "hello" should TypeError."""
        with pytest.raises(TypeError):
            parse("d6") + "hello"  # type: ignore[operator]
