"""Tests for error reporting with source positions.

These tests verify that runtime errors include accurate line/column
information from the original source text, not just generic error messages.
"""

from __future__ import annotations

import random as _random

import pytest

from troll.parser import parse
from troll.sampling import sample
from troll.values import EvalError


def _sample_err(source: str) -> EvalError:
    """Parse and sample, expecting an EvalError. Return it."""
    prog = parse(source)
    with pytest.raises(EvalError) as exc_info:
        sample(prog, _random.Random(42))
    return exc_info.value


class TestPositionInErrors:
    """Every error should report line and column from the source."""

    def test_unknown_variable_position(self):
        err = _sample_err("x")
        assert err.pos == (1, 1)
        assert "line 1, col 1" in str(err)
        assert "Unknown variable: x" in str(err)

    def test_unknown_variable_later_column(self):
        err = _sample_err("1 + x")
        assert err.pos == (1, 5)
        assert "line 1, col 5" in str(err)

    def test_unknown_variable_line_2(self):
        err = _sample_err("x := 1 ;\ny")
        # y is on line 2, col 1
        assert err.pos == (2, 1)
        assert "line 2, col 1" in str(err)

    def test_arithmetic_on_collection_position(self):
        """3d6 + 5 should report the position of the + operator."""
        err = _sample_err("3d6 + 5")
        assert err.pos == (1, 5)
        assert "line 1, col 5" in str(err)
        assert "Arithmetic requires a single number" in str(err)

    def test_arithmetic_on_collection_line_2(self):
        err = _sample_err("x := 3d6 ;\nx + 5")
        # The + is on line 2, col 3
        assert err.pos == (2, 3)
        assert "line 2, col 3" in str(err)

    def test_division_by_zero_position(self):
        err = _sample_err("5 / 0")
        assert err.pos == (1, 3)
        assert "line 1, col 3" in str(err)
        assert "Division by zero" in str(err)

    def test_modulo_by_zero_position(self):
        err = _sample_err("5 mod 0")
        assert err.pos == (1, 3)
        assert "line 1, col 3" in str(err)
        assert "Modulo by zero" in str(err)

    def test_negative_d_position(self):
        err = _sample_err("d0")
        assert err.pos == (1, 1)
        assert "line 1, col 1" in str(err)
        assert "Argument to d must be > 0" in str(err)

    def test_pair_projection_on_non_pair(self):
        err = _sample_err("%1 d6")
        assert err.pos == (1, 1)
        assert "line 1, col 1" in str(err)
        assert "%1 must be a pair" in str(err)

    def test_unknown_function_position(self):
        err = _sample_err("call foo(1)")
        assert err.pos == (1, 1)
        assert "line 1, col 1" in str(err)
        assert "Unknown function: foo" in str(err)


class TestMultiLineErrors:
    """Multi-line programs should report the correct line for errors."""

    def test_error_on_line_3(self):
        source = "x := d6 ;\ny := d6 ;\nx + y + 3d6"
        err = _sample_err(source)
        # The second + is the one that fails (3d6 is a collection)
        # "x + y" succeeds (both singletons), but "+ 3d6" fails
        # The first + is at col 3, but it succeeds. The 3d6 gets summed
        # into the second +... actually let's trace: x+y produces singleton,
        # then (x+y) + 3d6 fails at the second + on col 7
        assert err.pos[0] == 3  # line 3
        assert "Arithmetic requires a single number" in str(err)

    def test_error_in_function_body(self):
        source = "function f(x) = x + 3d6\ncall f(1)"
        err = _sample_err(source)
        # The + in the function body is at line 1, col 19
        assert err.pos == (1, 19)
        assert "Arithmetic requires a single number" in str(err)

    def test_error_in_if_branch(self):
        source = "if d6\nthen 3d6 + 1\nelse 0"
        err = _sample_err(source)
        # The + on line 2, col 10
        assert err.pos == (2, 10)

    def test_error_in_foreach_body(self):
        source = "foreach i in 1..3\ndo i + 2d6"
        err = _sample_err(source)
        # The + on line 2, col 6
        assert err.pos == (2, 6)
        assert "Arithmetic requires a single number" in str(err)

    def test_error_deep_nesting(self):
        source = "a := d6 ;\nb := d6 ;\nc := d6 ;\na + b + c + 2d6"
        err = _sample_err(source)
        assert err.pos[0] == 4  # error on line 4
        assert "Arithmetic requires a single number" in str(err)

    def test_error_in_let_binding_value(self):
        source = "x := 3d6 + 1 ;\nx"
        err = _sample_err(source)
        # The + is at line 1, col 10
        assert err.pos == (1, 10)

    def test_error_in_repeat_condition(self):
        """Error in the condition expression of a repeat loop."""
        source = "repeat x := d6\nwhile x + 2d6"
        err = _sample_err(source)
        assert err.pos[0] == 2  # error on line 2
        assert "Arithmetic requires a single number" in str(err)


class TestErrorMessages:
    """Error messages should be descriptive and include suggestions."""

    def test_collection_arithmetic_suggests_sum(self):
        err = _sample_err("3d6 + 5")
        msg = str(err)
        assert "sum" in msg.lower()
        assert "count" in msg.lower()
        assert "max" in msg.lower() or "min" in msg.lower()

    def test_unknown_var_includes_name(self):
        err = _sample_err("damage")
        assert "damage" in str(err)

    def test_division_by_zero_clear(self):
        err = _sample_err("d6 / 0")
        assert "Division by zero" in str(err)

    def test_negative_die_includes_value(self):
        err = _sample_err("d0")
        assert "0" in str(err)
        assert "> 0" in str(err)

    def test_pair_projection_clear(self):
        err = _sample_err("%1 5")
        assert "%1" in str(err)
        assert "pair" in str(err)


class TestNoPositionForProgrammaticNodes:
    """Nodes built via Python operators should have pos=(0,0) and no location in error."""

    def test_programmatic_plus_no_position(self):
        # Manually construct a Plus where the left is a collection (will error)
        # but has no source position since it was built in Python
        from troll.syntax import D, Hash, Num, Plus, Program

        # 3d6 + 5, but built manually — no pos on the Plus node
        bad_prog = Program([], Plus(Hash(Num(3), D(Num(6))), Num(5)))
        with pytest.raises(EvalError) as exc_info:
            sample(bad_prog, _random.Random(42))
        # Error should NOT have "line X, col Y" since the offending node is synthetic
        assert exc_info.value.pos == (0, 0)
        assert "line" not in str(exc_info.value)


class TestParseErrors:
    """Parse errors should also have positions (already worked, verify they still do)."""

    def test_parse_error_position(self):
        from troll.parser import ParseError

        with pytest.raises(ParseError, match="line 1, col 5"):
            parse("1 + ")  # EOF at col 5

    def test_parse_error_line_2(self):
        from troll.parser import ParseError

        with pytest.raises(ParseError, match="line 2"):
            parse("x := 1 ;\n)")

    def test_unterminated_string(self):
        from troll.lexer import LexError

        with pytest.raises(LexError, match="line 1"):
            parse('"hello')
