"""Tests for the Troll lexer."""

import pytest

from troll.lexer import TT, LexError, tokenize


def _types(source: str) -> list[TT]:
    """Return just the token types (excluding EOF) for a source string."""
    return [t.type for t in tokenize(source) if t.type != TT.EOF]


def _values(source: str) -> list[object]:
    """Return just the token values (excluding EOF) for a source string."""
    return [t.value for t in tokenize(source) if t.type != TT.EOF]


class TestBasicTokens:
    def test_integer(self):
        assert _types("42") == [TT.NUM]
        assert _values("42") == [42]

    def test_real(self):
        assert _types("0.5") == [TT.REAL]
        assert _values("0.5") == [0.5]

    def test_identifier(self):
        assert _types("attack") == [TT.ID]
        assert _values("attack") == ["attack"]

    def test_string(self):
        assert _types('"hello"') == [TT.STRING]
        assert _values('"hello"') == ["hello"]


class TestKeywords:
    def test_d_both_cases(self):
        assert _types("d") == [TT.D]
        assert _types("D") == [TT.D]

    def test_z_both_cases(self):
        assert _types("z") == [TT.Z]
        assert _types("Z") == [TT.Z]

    def test_keywords_not_identifiers(self):
        keywords = [
            "sum",
            "count",
            "if",
            "then",
            "else",
            "foreach",
            "do",
            "repeat",
            "accumulate",
            "while",
            "until",
            "largest",
            "least",
            "choose",
            "different",
            "function",
            "call",
            "drop",
            "keep",
            "pick",
        ]
        for kw in keywords:
            types = _types(kw)
            assert types[0] != TT.ID, f"{kw!r} should be a keyword, not ID"

    def test_longer_word_is_identifier(self):
        assert _types("summary") == [TT.ID]
        assert _types("damage") == [TT.ID]


class TestMultiCharSymbols:
    def test_assign(self):
        assert _types(":=") == [TT.ASSGN]

    def test_neq(self):
        assert _types("=/=") == [TT.NEQ]

    def test_dotdot(self):
        assert _types("..") == [TT.DOTDOT]

    def test_setminus(self):
        assert _types("--") == [TT.SETMINUS]

    def test_le_ge(self):
        assert _types("<=") == [TT.LE]
        assert _types(">=") == [TT.GE]

    def test_hconc_vconcl_vconcr_vconcc(self):
        assert _types("||") == [TT.HCONC]
        assert _types("|>") == [TT.VCONCL]
        assert _types("<|") == [TT.VCONCR]
        assert _types("<>") == [TT.VCONCC]

    def test_percent_projections(self):
        assert _types("%1") == [TT.FIRST]
        assert _types("%2") == [TT.SECOND]


class TestCompoundExpressions:
    def test_dice_notation(self):
        """3d6 should lex as NUM D NUM, not a single token."""
        assert _types("3d6") == [TT.NUM, TT.D, TT.NUM]
        assert _values("3d6") == [3, "d", 6]

    def test_let_binding(self):
        types = _types("x := 1 ; x")
        assert types == [TT.ID, TT.ASSGN, TT.NUM, TT.SEMI, TT.ID]

    def test_collection_literal(self):
        types = _types("{1, 2, 3}")
        assert types == [TT.LBRACE, TT.NUM, TT.COMMA, TT.NUM, TT.COMMA, TT.NUM, TT.RBRACE]


class TestWhitespaceAndComments:
    def test_whitespace_ignored(self):
        assert _types("3  +  4") == [TT.NUM, TT.PLUS, TT.NUM]

    def test_newlines_ignored(self):
        assert _types("3\n+\n4") == [TT.NUM, TT.PLUS, TT.NUM]

    def test_comment_to_eol(self):
        assert _types("3 \\ this is a comment\n+ 4") == [TT.NUM, TT.PLUS, TT.NUM]

    def test_line_tracking(self):
        tokens = tokenize("3\n+\n4")
        assert tokens[0].line == 1  # 3
        assert tokens[1].line == 2  # +
        assert tokens[2].line == 3  # 4


class TestErrors:
    def test_unterminated_string(self):
        with pytest.raises(LexError, match="Unterminated string"):
            tokenize('"hello')

    def test_unexpected_char(self):
        with pytest.raises(LexError, match="Unexpected character"):
            tokenize("$")
