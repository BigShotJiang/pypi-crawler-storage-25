"""Tests for the Troll exact distribution engine."""

from __future__ import annotations

from fractions import Fraction

from troll.distribution import Distribution, distribute
from troll.parser import parse
from troll.values import Multiset


def _dist(source: str) -> Distribution:
    """Parse and compute distribution for a Troll expression."""
    return distribute(parse(source))


def _int_pmf(source: str) -> dict[int, Fraction]:
    """Get PMF as {int_value: probability} for scalar distributions."""
    dist = _dist(source)
    result: dict[int, Fraction] = {}
    for v, p in dist.items():
        assert isinstance(v, Multiset) and len(v) == 1, f"Expected singleton, got {v}"
        result[v[0]] = p
    return result


class TestDicePrimitives:
    def test_d6_uniform(self):
        pmf = _int_pmf("d6")
        assert len(pmf) == 6
        for i in range(1, 7):
            assert pmf[i] == Fraction(1, 6)

    def test_z6_uniform(self):
        pmf = _int_pmf("z6")
        assert len(pmf) == 7
        for i in range(0, 7):
            assert pmf[i] == Fraction(1, 7)

    def test_sum_2d6(self):
        pmf = _int_pmf("sum 2d6")
        assert pmf[2] == Fraction(1, 36)
        assert pmf[7] == Fraction(6, 36)
        assert pmf[12] == Fraction(1, 36)
        assert sum(pmf.values()) == Fraction(1)

    def test_sum_2d6_mean(self):
        dist = _dist("sum 2d6")
        assert abs(dist.mean - 7.0) < 1e-10


class TestArithmetic:
    def test_addition(self):
        pmf = _int_pmf("d6 + d6")
        assert pmf[2] == Fraction(1, 36)
        assert sum(pmf.values()) == 1

    def test_sum_constant(self):
        pmf = _int_pmf("3 + 4")
        assert pmf == {7: Fraction(1)}


class TestLargestLeast:
    def test_sum_largest_3_4d6_probabilities_sum_to_1(self):
        dist = _dist("sum largest 3 4d6")
        total = sum(p for _, p in dist.items())
        assert total == Fraction(1)

    def test_sum_largest_3_4d6_range(self):
        pmf = _int_pmf("sum largest 3 4d6")
        assert min(pmf.keys()) == 3
        assert max(pmf.keys()) == 18

    def test_sum_largest_3_4d6_mean(self):
        dist = _dist("sum largest 3 4d6")
        assert abs(dist.mean - 12.2446) < 0.001


class TestComparisons:
    def test_eq_filter(self):
        """3 = {1,2,3,4,5} should give {3} or {} depending on the collection."""
        dist = _dist("3 = {1, 2, 3, 4, 5}")
        items = dist.items()
        assert len(items) == 1
        v, p = items[0]
        assert v == Multiset([3])
        assert p == Fraction(1)


class TestControlFlow:
    def test_let_binding(self):
        pmf = _int_pmf("x := d6 ; x + x")
        # x + x where x is one die roll: always even, 2 to 12, step 2
        assert all(k % 2 == 0 for k in pmf)
        assert sum(pmf.values()) == Fraction(1)
        # Each outcome has probability 1/6
        assert pmf[2] == Fraction(1, 6)
        assert pmf[12] == Fraction(1, 6)

    def test_if_deterministic(self):
        pmf = _int_pmf("if 1 then 10 else 20")
        assert pmf == {10: Fraction(1)}

    def test_if_probabilistic(self):
        """if d2 = 1 then 10 else 20: d2 is 1 or 2 with equal prob."""
        # d2=1 → filter: {1}, nonempty → then(10)
        # d2=2 → filter: {}, empty → else(20)
        pmf = _int_pmf("x := d2 ; if 1 = x then 10 else 20")
        assert pmf[10] == Fraction(1, 2)
        assert pmf[20] == Fraction(1, 2)


class TestRepeatAccumulate:
    def test_d5_by_reroll(self):
        """repeat x := d6 while x = 6 produces uniform 1-5 (reroll 6s)."""
        pmf = _int_pmf("repeat x := d6 while x = 6")
        for i in range(1, 6):
            # Each of 1-5 should be approximately 20%
            assert abs(float(pmf.get(i, 0)) - 0.2) < 0.01

    def test_accumulate_d2_until_2(self):
        """accumulate produces union of all intermediate values."""
        dist = _dist("sum accumulate x := d2 until x = 2")
        total = sum(p for _, p in dist.items())
        assert abs(float(total) - 1.0) < 0.01


class TestRisk:
    def test_risk_battle(self):
        """Risk example should produce distribution over {0, 1, 2}."""
        pmf = _int_pmf(
            "attack := 3d6;\n"
            "defense := 2d6;\n"
            "(count (max attack)>(max defense))"
            " + (count (min largest 2 attack)>(min defense))"
        )
        assert set(pmf.keys()) == {0, 1, 2}
        assert sum(pmf.values()) == Fraction(1)


class TestStatistics:
    def test_mean_d6(self):
        assert abs(_dist("d6").mean - 3.5) < 1e-10

    def test_std_d6(self):
        # std of uniform 1-6 is sqrt(35/12) ≈ 1.7078
        assert abs(_dist("d6").std - 1.7078) < 0.001

    def test_probabilities_sum_to_1(self):
        """All distributions should have probabilities summing to 1."""
        for expr in ["d6", "sum 2d6", "sum largest 3 4d6", "choose {1,2,3}"]:
            total = sum(p for _, p in _dist(expr).items())
            assert total == Fraction(1), f"Probabilities don't sum to 1 for: {expr}"
