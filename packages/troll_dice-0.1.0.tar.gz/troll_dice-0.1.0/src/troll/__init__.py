"""troll-dice: Exact probability distributions for dice expressions.

Quick start::

    import troll

    # Parse a Troll expression — returns a Program you can sample or analyze
    prog = troll.parse("sum 2d6")

    prog.sample()                # one random roll → Multiset([7])
    prog.sample(n=5)             # five rolls → [Multiset([9]), ...]
    prog.distribution()          # exact PMF → Distribution(...)

    # Or skip the Program and go straight to a result
    troll.roll("sum 2d6")              # → Multiset([8])
    troll.roll("sum 2d6", n=5)         # → [Multiset([3]), Multiset([11]), ...]
    troll.dist("sum 2d6")              # → Distribution(...)
    troll.dist("sum 2d6").mean         # → 7.0
"""

from __future__ import annotations

from troll.distribution import Distribution as Distribution
from troll.distribution import distribute as distribute
from troll.lexer import LexError as LexError
from troll.lexer import tokenize as tokenize
from troll.parser import ParseError as ParseError
from troll.parser import parse as parse
from troll.sampling import sample as sample
from troll.sampling import sample_n as sample_n
from troll.syntax import Program as Program
from troll.values import EvalError as EvalError
from troll.values import Multiset as Multiset
from troll.values import PairVal as PairVal
from troll.values import Value as Value


def roll(expr: str, *, n: int = 1, seed: int | None = None) -> Value | list[Value]:
    """Parse and sample a Troll expression in one call.

    Args:
        expr: A Troll dice expression (e.g., "sum 2d6", "largest 3 4d6").
        n: Number of samples. Returns a single Value if n=1, a list if n>1.
        seed: Optional RNG seed for reproducibility.

    Returns:
        A Multiset (the roll result) or list of Multisets.

    Examples::

        >>> troll.roll("3d6")
        Multiset([2, 4, 5])
        >>> troll.roll("sum 2d6")
        Multiset([8])
        >>> int(troll.roll("sum 2d6"))
        8
        >>> troll.roll("sum 2d6", n=3)
        [Multiset([7]), Multiset([5]), Multiset([11])]
    """
    return parse(expr).sample(n=n, seed=seed)


def dist(expr: str, *, max_iterations: int = 12) -> Distribution:
    """Parse and compute the exact distribution of a Troll expression.

    Args:
        expr: A Troll dice expression (e.g., "sum 2d6").
        max_iterations: Max loop unrolling depth for repeat/accumulate.

    Returns:
        A Distribution with .mean, .std, .prob(), dict-like access, etc.

    Examples::

        >>> d = troll.dist("sum 2d6")
        >>> d.mean
        7.0
        >>> float(d.prob(lambda v: int(v) >= 10))
        0.16666666666666666
        >>> d[troll.Multiset.single(7)]
        Fraction(1, 6)
    """
    return parse(expr).distribution(max_iterations=max_iterations)
