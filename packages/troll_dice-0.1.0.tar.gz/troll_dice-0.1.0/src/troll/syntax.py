"""AST node definitions for the Troll dice language."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from troll.distribution import Distribution
    from troll.values import Value


@dataclass
class Exp:
    """Base class for Troll expression AST nodes."""

    pos: tuple[int, int] = field(default=(0, 0), kw_only=True, repr=False, compare=False)


@dataclass
class Decl:
    """Base class for Troll declaration AST nodes."""

    pos: tuple[int, int] = field(default=(0, 0), kw_only=True, repr=False, compare=False)


# -- Literals and identifiers --


@dataclass
class Num(Exp):
    val: int


@dataclass
class Id(Exp):
    name: str


@dataclass
class Empty(Exp):
    pass


@dataclass
class String(Exp):
    val: str


@dataclass
class Question(Exp):
    prob: float


# -- Arithmetic --


@dataclass
class Plus(Exp):
    left: Exp
    right: Exp


@dataclass
class Minus(Exp):
    left: Exp
    right: Exp


@dataclass
class Times(Exp):
    left: Exp
    right: Exp


@dataclass
class Divide(Exp):
    left: Exp
    right: Exp


@dataclass
class Mod(Exp):
    left: Exp
    right: Exp


@dataclass
class UMinus(Exp):
    arg: Exp


@dataclass
class Sign(Exp):
    arg: Exp


# -- Dice --


@dataclass
class D(Exp):
    arg: Exp


@dataclass
class Z(Exp):
    arg: Exp


@dataclass
class Hash(Exp):
    count: Exp
    die: Exp


# -- Collection operations --


@dataclass
class Conc(Exp):
    left: Exp
    right: Exp


@dataclass
class FromTo(Exp):
    low: Exp
    high: Exp


@dataclass
class Choose(Exp):
    arg: Exp


@dataclass
class Different(Exp):
    arg: Exp


@dataclass
class Sum(Exp):
    arg: Exp


@dataclass
class Count(Exp):
    arg: Exp


@dataclass
class Least(Exp):
    n: Exp
    collection: Exp


@dataclass
class Largest(Exp):
    n: Exp
    collection: Exp


@dataclass
class Minimal(Exp):
    arg: Exp


@dataclass
class Maximal(Exp):
    arg: Exp


@dataclass
class Median(Exp):
    arg: Exp


@dataclass
class Drop(Exp):
    left: Exp
    right: Exp


@dataclass
class Keep(Exp):
    left: Exp
    right: Exp


@dataclass
class Pick(Exp):
    left: Exp
    right: Exp


@dataclass
class SetMinus(Exp):
    left: Exp
    right: Exp


# -- Comparisons (act as filters) --


@dataclass
class Eq(Exp):
    left: Exp
    right: Exp


@dataclass
class Neq(Exp):
    left: Exp
    right: Exp


@dataclass
class Lt(Exp):
    left: Exp
    right: Exp


@dataclass
class Gt(Exp):
    left: Exp
    right: Exp


@dataclass
class Le(Exp):
    left: Exp
    right: Exp


@dataclass
class Ge(Exp):
    left: Exp
    right: Exp


# -- Logic --


@dataclass
class And(Exp):
    left: Exp
    right: Exp


# -- Control flow --


@dataclass
class Let(Exp):
    name: str
    binding: Exp
    body: Exp


@dataclass
class If(Exp):
    cond: Exp
    then_: Exp
    else_: Exp


@dataclass
class Foreach(Exp):
    name: str
    collection: Exp
    body: Exp


@dataclass
class Repeat(Exp):
    name: str
    init: Exp
    cond: Exp
    is_while: bool


@dataclass
class Accum(Exp):
    name: str
    init: Exp
    cond: Exp
    is_while: bool


@dataclass
class Call(Exp):
    name: str
    args: list[Exp] = field(default_factory=list)


# -- Text --


@dataclass
class Sample(Exp):
    arg: Exp


@dataclass
class Samples(Exp):
    count: Exp
    arg: Exp


@dataclass
class HConc(Exp):
    left: Exp
    right: Exp


@dataclass
class VConcL(Exp):
    left: Exp
    right: Exp


@dataclass
class VConcR(Exp):
    left: Exp
    right: Exp


@dataclass
class VConcC(Exp):
    left: Exp
    right: Exp


# -- Pairs --


@dataclass
class Pair(Exp):
    first: Exp
    second: Exp


@dataclass
class First(Exp):
    arg: Exp


@dataclass
class Second(Exp):
    arg: Exp


@dataclass
class Default(Exp):
    name: str
    fallback: Exp


# -- Declarations --


@dataclass
class FuncDecl(Decl):
    name: str
    params: list[str]
    body: Exp


@dataclass
class CompDecl(Decl):
    name: str
    empty: Exp
    single: str
    union: str


# -- Program --


@dataclass
class Program:
    """A parsed Troll program (declarations + main expression).

    Use .sample() for a random roll, .distribution() for exact probabilities.

        >>> import troll
        >>> prog = troll.parse("sum 2d6")
        >>> prog.sample()           # one random roll
        Multiset([7])
        >>> prog.sample(n=5)        # five random rolls
        [Multiset([9]), Multiset([4]), ...]
        >>> prog.distribution()     # exact PMF
        Distribution(
          2: 2.7778%
          3: 5.5556%
          ...
        )
    """

    declarations: list[Decl]
    expression: Exp

    def __repr__(self) -> str:
        return show(self)

    def sample(self, n: int = 1, seed: int | None = None) -> Value | list[Value]:
        """Roll the dice. Returns one Value if n=1, a list if n>1."""
        import random as _random

        from troll.sampling import sample as _sample
        from troll.sampling import sample_n as _sample_n

        rng = _random.Random(seed)
        if n == 1:
            return _sample(self, rng)
        return _sample_n(self, n, rng)

    def distribution(self, *, max_iterations: int = 12) -> Distribution:
        """Compute the exact probability distribution."""
        from troll.distribution import distribute as _distribute

        return _distribute(self, max_iterations=max_iterations)

    # -- Collection-to-scalar helpers --

    def sum(self) -> Program:
        """Sum the collection into a single number. `parse("3d6").sum()` → sum(3d6)."""
        return Program(self.declarations, Sum(self.expression))

    def count(self) -> Program:
        """Count elements in the collection. `parse("3d6").count()` → count(3d6)."""
        return Program(self.declarations, Count(self.expression))

    def max(self) -> Program:
        """Largest single element. `parse("3d6").max()` → max(3d6)."""
        return Program(self.declarations, Largest(Num(1), self.expression))

    def min(self) -> Program:
        """Smallest single element. `parse("3d6").min()` → min(3d6)."""
        return Program(self.declarations, Least(Num(1), self.expression))

    # -- Arithmetic builds new Programs --
    # These operators require scalar (singleton) expressions on both sides,
    # matching Troll's semantics. If the expression produces a collection,
    # raise a helpful error explaining the alternatives.

    def _check_scalar(self, op: str) -> None:
        """Raise a helpful error if this expression produces a collection."""
        e = self.expression
        if isinstance(e, (Hash, Conc, FromTo, Different, Drop, Keep, Pick, SetMinus, Foreach)):
            expr_str = show(self)
            raise TypeError(
                f"Cannot use '{op}' on collection expression: {expr_str}\n"
                f"\n"
                f"  '{op}' requires a single number, but this produces multiple values.\n"
                f"  Did you mean one of:\n"
                f"\n"
                f"    .sum() {op} ...    → total the collection first\n"
                f'                        e.g. parse("{expr_str}").sum() {op} ...\n'
                f"    .max() {op} ...    → use the highest value\n"
                f"    .min() {op} ...    → use the lowest value\n"
                f"    .count() {op} ...  → use the number of elements\n"
            )

    @staticmethod
    def _to_exp(other: object) -> Exp:
        """Convert a Python value or Program to an AST node."""
        if isinstance(other, Program):
            other._check_scalar("+")  # will be overridden at call site
            return other.expression
        if isinstance(other, int):
            return Num(other)
        raise TypeError(f"Cannot use {type(other).__name__} in dice expression")

    def _binop(self, other: object, node_type: type, op_str: str) -> Program:
        self._check_scalar(op_str)
        if isinstance(other, Program):
            other._check_scalar(op_str)
            return Program(self.declarations, node_type(self.expression, other.expression))
        if isinstance(other, int):
            return Program(self.declarations, node_type(self.expression, Num(other)))
        raise TypeError(f"Cannot use {type(other).__name__} in dice expression")

    def _rbinop(self, other: object, node_type: type, op_str: str) -> Program:
        self._check_scalar(op_str)
        if isinstance(other, int):
            return Program(self.declarations, node_type(Num(other), self.expression))
        raise TypeError(f"Cannot use {type(other).__name__} in dice expression")

    def __add__(self, other: object) -> Program:
        return self._binop(other, Plus, "+")

    def __radd__(self, other: object) -> Program:
        return self._rbinop(other, Plus, "+")

    def __sub__(self, other: object) -> Program:
        return self._binop(other, Minus, "-")

    def __rsub__(self, other: object) -> Program:
        return self._rbinop(other, Minus, "-")

    def __mul__(self, other: object) -> Program:
        if isinstance(other, int):
            self._check_scalar_mul(other)
            return Program(self.declarations, Hash(Num(other), self.expression))
        return self._binop(other, Times, "*")

    def __rmul__(self, other: object) -> Program:
        if isinstance(other, int):
            # int * program is always repeat: 5 * parse("d6") → 5 # d6
            return Program(self.declarations, Hash(Num(other), self.expression))
        return self._rbinop(other, Times, "*")

    def _check_scalar_mul(self, n: int) -> None:
        """Error when collection * int — ambiguous between repeat and multiply."""
        e = self.expression
        if isinstance(e, (Hash, Conc, FromTo, Different, Drop, Keep, Pick, SetMinus, Foreach)):
            expr_str = show(self)
            raise TypeError(
                f"Cannot use 'expr * {n}' on collection expression: {expr_str}\n"
                f"\n"
                f"  Did you mean one of:\n"
                f"\n"
                f"    {n} * expr      → repeat the roll {n} times\n"
                f'                      i.e. {n} * parse("{expr_str}")\n'
                f"    .sum() * {n}    → total the collection, then multiply\n"
                f"    .count() * {n}  → multiply the number of elements\n"
            )

    def __neg__(self) -> Program:
        self._check_scalar("-")
        return Program(self.declarations, UMinus(self.expression))


# -- Pretty printer --


def show(e: Exp | Decl | Program) -> str:
    """Convert an AST node back to Troll-like syntax."""
    match e:
        case Program(decls, expr):
            parts = [show(d) for d in decls] + [show(expr)]
            return "\n".join(parts)
        case FuncDecl(name, params, body):
            return f"function {name}({', '.join(params)}) = {show(body)}"
        case CompDecl(name, empty, single, union):
            return f"compositional {name}({show(empty)}, {single}, {union})"
        case Num(val=v):
            return str(v)
        case Id(name=n):
            return n
        case Empty():
            return "{}"
        case String(val=s):
            return f'"{s}"'
        case Question(prob=p):
            return f"?{p}"
        case Plus(left=a, right=b):
            return f"({show(a)} + {show(b)})"
        case Minus(left=a, right=b):
            return f"({show(a)} - {show(b)})"
        case Times(left=a, right=b):
            return f"({show(a)} * {show(b)})"
        case Divide(left=a, right=b):
            return f"({show(a)} / {show(b)})"
        case Mod(left=a, right=b):
            return f"({show(a)} mod {show(b)})"
        case UMinus(arg=a):
            return f"(-{show(a)})"
        case Sign(arg=a):
            return f"sgn {show(a)}"
        case D(arg=a):
            return f"d{show(a)}"
        case Z(arg=a):
            return f"z{show(a)}"
        case Hash(count=c, die=d_):
            return f"({show(c)} # {show(d_)})"
        case Conc(left=a, right=b):
            return f"({show(a)} @ {show(b)})"
        case FromTo(low=a, high=b):
            return f"({show(a)}..{show(b)})"
        case Choose(arg=a):
            return f"choose {show(a)}"
        case Different(arg=a):
            return f"different {show(a)}"
        case Sum(arg=a):
            return f"sum {show(a)}"
        case Count(arg=a):
            return f"count {show(a)}"
        case Least(n=n, collection=c):
            return f"least {show(n)} {show(c)}"
        case Largest(n=n, collection=c):
            return f"largest {show(n)} {show(c)}"
        case Minimal(arg=a):
            return f"minimal {show(a)}"
        case Maximal(arg=a):
            return f"maximal {show(a)}"
        case Median(arg=a):
            return f"median {show(a)}"
        case Drop(left=a, right=b):
            return f"({show(a)} drop {show(b)})"
        case Keep(left=a, right=b):
            return f"({show(a)} keep {show(b)})"
        case Pick(left=a, right=b):
            return f"({show(a)} pick {show(b)})"
        case SetMinus(left=a, right=b):
            return f"({show(a)} -- {show(b)})"
        case Eq(left=a, right=b):
            return f"({show(a)} = {show(b)})"
        case Neq(left=a, right=b):
            return f"({show(a)} =/= {show(b)})"
        case Lt(left=a, right=b):
            return f"({show(a)} < {show(b)})"
        case Gt(left=a, right=b):
            return f"({show(a)} > {show(b)})"
        case Le(left=a, right=b):
            return f"({show(a)} <= {show(b)})"
        case Ge(left=a, right=b):
            return f"({show(a)} >= {show(b)})"
        case And(left=a, right=b):
            return f"({show(a)} & {show(b)})"
        case Let(name=n, binding=v, body=b):
            return f"{n} := {show(v)};\n{show(b)}"
        case If(cond=c, then_=t, else_=el):
            return f"if {show(c)} then {show(t)} else {show(el)}"
        case Foreach(name=n, collection=c, body=b):
            return f"foreach {n} in {show(c)} do {show(b)}"
        case Repeat(name=n, init=i, cond=c, is_while=w):
            kw = "while" if w else "until"
            return f"repeat {n} := {show(i)} {kw} {show(c)}"
        case Accum(name=n, init=i, cond=c, is_while=w):
            kw = "while" if w else "until"
            return f"accumulate {n} := {show(i)} {kw} {show(c)}"
        case Call(name=n, args=args):
            return f"call {n}({', '.join(show(a) for a in args)})"
        case Sample(arg=a):
            return f"'{show(a)}"
        case Samples(count=c, arg=a):
            return f"({show(c)} ' {show(a)})"
        case HConc(left=a, right=b):
            return f"({show(a)} || {show(b)})"
        case VConcL(left=a, right=b):
            return f"({show(a)} |> {show(b)})"
        case VConcR(left=a, right=b):
            return f"({show(a)} <| {show(b)})"
        case VConcC(left=a, right=b):
            return f"({show(a)} <> {show(b)})"
        case Pair(first=a, second=b):
            return f"[{show(a)}, {show(b)}]"
        case First(arg=a):
            return f"%1 {show(a)}"
        case Second(arg=a):
            return f"%2 {show(a)}"
        case Default(name=n, fallback=f):
            return f"({n} ~ {show(f)})"
        case _:
            return repr(e)
