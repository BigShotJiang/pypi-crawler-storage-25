"""Recursive descent parser for the Troll dice language.

Uses precedence climbing for expression parsing. Precedence levels match
the original yacc grammar (higher number = tighter binding):

    2: ;  (let-binding separator — handled specially, not in infix table)
    4: || |> <| <>         right
    5: ..                  nonassoc
    6: drop keep pick --   left
    7: @ &                 right
    8: + -                 left
    9: * / mod             left
   10: unary -             (prefix)
   11: sum count etc.      (prefix)
   12: = =/= < > <= >=    right
   13: # ~ ' (infix d/z)  right
   14: d z                 (prefix)
"""

from __future__ import annotations

from typing import cast

from troll import syntax as S
from troll.lexer import TT, Token, tokenize


class ParseError(Exception):
    def __init__(self, msg: str, token: Token):
        loc = f"line {token.line}, col {token.col}"
        super().__init__(f"Parse error at {loc}: {msg}")
        self.token = token


# Infix operator table: token type -> (precedence, associativity)
INFIX = {
    TT.HCONC: (4, "right"),
    TT.VCONCL: (4, "right"),
    TT.VCONCR: (4, "right"),
    TT.VCONCC: (4, "right"),
    TT.DOTDOT: (5, "left"),
    TT.DROP: (6, "left"),
    TT.KEEP: (6, "left"),
    TT.PICK: (6, "left"),
    TT.SETMINUS: (6, "left"),
    TT.CONC: (7, "right"),
    TT.AND: (7, "right"),
    TT.PLUS: (8, "left"),
    TT.MINUS: (8, "left"),
    TT.TIMES: (9, "left"),
    TT.DIVIDE: (9, "left"),
    TT.MOD: (9, "left"),
    TT.EQ: (12, "right"),
    TT.NEQ: (12, "right"),
    TT.LT: (12, "right"),
    TT.GT: (12, "right"),
    TT.LE: (12, "right"),
    TT.GE: (12, "right"),
    TT.HASH: (13, "right"),
    TT.D: (13, "right"),
    TT.Z: (13, "right"),
    TT.SAMPLE: (13, "right"),
    TT.TILDE: (13, "right"),
}


# IDs that can name operators in compositional declarations
_UNOP_NAMES = {
    TT.MINUS: "-",
    TT.D: "d",
    TT.Z: "z",
    TT.SUM: "sum",
    TT.SGN: "sgn",
    TT.COUNT: "count",
    TT.MIN: "min",
    TT.MAX: "max",
    TT.MINIMAL: "minimal",
    TT.MAXIMAL: "maximal",
    TT.CHOOSE: "choose",
    TT.DIFFERENT: "different",
}
_BINOP_NAMES = {TT.PLUS: "+", TT.TIMES: "*", TT.CONC: "U"}


class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.pos = 0

    # -- Helpers --

    def peek(self) -> Token:
        return self.tokens[self.pos]

    def advance(self) -> Token:
        t = self.tokens[self.pos]
        self.pos += 1
        return t

    def check(self, *types: TT) -> bool:
        return self.peek().type in types

    def match(self, *types: TT) -> Token | None:
        if self.peek().type in types:
            return self.advance()
        return None

    def expect(self, tt: TT) -> Token:
        t = self.advance()
        if t.type != tt:
            raise ParseError(f"Expected {tt.name}, got {t.type.name}", t)
        return t

    @staticmethod
    def _pos(t: Token) -> tuple[int, int]:
        return (t.line, t.col)

    def error(self, msg: str) -> ParseError:
        return ParseError(msg, self.peek())

    # -- Top level --

    def parse_program(self) -> S.Program:
        decls = self.parse_decls()
        expr = self.parse_expr(0)
        decls += self.parse_decls()
        self.expect(TT.EOF)
        return S.Program(decls, expr)

    def parse_decls(self) -> list[S.Decl]:
        decls: list[S.Decl] = []
        while self.check(TT.FUNCTION, TT.COMPOSITIONAL):
            decls.append(self.parse_decl())
        return decls

    def parse_decl(self) -> S.Decl:
        if tok := self.match(TT.FUNCTION):
            name = cast(str, self.expect(TT.ID).value)
            self.expect(TT.LPAR)
            params = self.parse_id_list()
            self.expect(TT.RPAR)
            self.expect(TT.EQ)
            body = self.parse_expr(0)
            return S.FuncDecl(name, params, body, pos=self._pos(tok))

        tok = self.expect(TT.COMPOSITIONAL)
        name = cast(str, self.expect(TT.ID).value)
        self.expect(TT.LPAR)
        empty = self.parse_expr(0)
        self.expect(TT.COMMA)
        single = self.parse_id_or_op(_UNOP_NAMES)
        self.expect(TT.COMMA)
        union = self.parse_id_or_op(_BINOP_NAMES)
        self.expect(TT.RPAR)
        return S.CompDecl(name, empty, single, union, pos=self._pos(tok))

    def parse_id_list(self) -> list[str]:
        names = [cast(str, self.expect(TT.ID).value)]
        while self.match(TT.COMMA):
            names.append(cast(str, self.expect(TT.ID).value))
        return names

    def parse_id_or_op(self, ops: dict[TT, str]) -> str:
        if self.check(TT.ID):
            return cast(str, self.advance().value)
        for tt, name in ops.items():
            if self.match(tt):
                return name
        raise self.error("Expected identifier or operator name")

    # -- Expressions: precedence climbing --

    def parse_expr(self, min_prec: int) -> S.Exp:
        left = self.parse_prefix()
        while True:
            info = INFIX.get(self.peek().type)
            if info is None:
                break
            prec, assoc = info
            if prec < min_prec:
                break
            op = self.advance()
            next_prec = prec if assoc == "right" else prec + 1
            right = self.parse_expr(next_prec)
            left = self.make_infix(left, op, right)
        return left

    def make_infix(self, left: S.Exp, op: Token, right: S.Exp) -> S.Exp:
        p = self._pos(op)
        match op.type:
            case TT.PLUS:
                return S.Plus(left, right, pos=p)
            case TT.MINUS:
                return S.Minus(left, right, pos=p)
            case TT.TIMES:
                return S.Times(left, right, pos=p)
            case TT.DIVIDE:
                return S.Divide(left, right, pos=p)
            case TT.MOD:
                return S.Mod(left, right, pos=p)
            case TT.CONC:
                return S.Conc(left, right, pos=p)
            case TT.AND:
                return S.And(left, right, pos=p)
            case TT.DOTDOT:
                return S.FromTo(left, right, pos=p)
            case TT.DROP:
                return S.Drop(left, right, pos=p)
            case TT.KEEP:
                return S.Keep(left, right, pos=p)
            case TT.PICK:
                return S.Pick(left, right, pos=p)
            case TT.SETMINUS:
                return S.SetMinus(left, right, pos=p)
            case TT.EQ:
                return S.Eq(left, right, pos=p)
            case TT.NEQ:
                return S.Neq(left, right, pos=p)
            case TT.LT:
                return S.Lt(left, right, pos=p)
            case TT.GT:
                return S.Gt(left, right, pos=p)
            case TT.LE:
                return S.Le(left, right, pos=p)
            case TT.GE:
                return S.Ge(left, right, pos=p)
            case TT.HASH:
                return S.Hash(left, right, pos=p)
            case TT.HCONC:
                return S.HConc(left, right, pos=p)
            case TT.VCONCL:
                return S.VConcL(left, right, pos=p)
            case TT.VCONCR:
                return S.VConcR(left, right, pos=p)
            case TT.VCONCC:
                return S.VConcC(left, right, pos=p)
            case TT.SAMPLE:
                return S.Samples(left, right, pos=p)
            case TT.D:
                return S.Hash(left, S.D(right, pos=p), pos=p)
            case TT.Z:
                return S.Hash(left, S.Z(right, pos=p), pos=p)
            case TT.TILDE:
                if not isinstance(left, S.Id):
                    raise ParseError("Left of ~ must be an identifier", op)
                return S.Default(left.name, right, pos=p)
            case _:
                raise ParseError(f"Unknown infix operator: {op.type.name}", op)

    # -- Prefix / atoms --

    def parse_prefix(self) -> S.Exp:
        t = self.peek()

        # Special forms
        if tok := self.match(TT.IF):
            return self.parse_if(tok)
        if tok := self.match(TT.FOREACH):
            return self.parse_foreach(tok)
        if tok := self.match(TT.REPEAT):
            return self.parse_repeat_or_accum(is_accum=False, tok=tok)
        if tok := self.match(TT.ACCUM):
            return self.parse_repeat_or_accum(is_accum=True, tok=tok)
        if tok := self.match(TT.CALL):
            return self.parse_call(tok)
        if self.match(TT.LET):
            # 'let' keyword isn't used in standard Troll grammar but we
            # accept it as a no-op for forward compatibility
            pass

        # Prefix operators
        if tok := self.match(TT.MINUS):
            return S.UMinus(self.parse_expr(10), pos=self._pos(tok))
        if tok := self.match(TT.D):
            return S.D(self.parse_expr(14), pos=self._pos(tok))
        if tok := self.match(TT.Z):
            return S.Z(self.parse_expr(14), pos=self._pos(tok))
        if tok := self.match(TT.SUM):
            return S.Sum(self.parse_expr(11), pos=self._pos(tok))
        if tok := self.match(TT.SGN):
            return S.Sign(self.parse_expr(11), pos=self._pos(tok))
        if tok := self.match(TT.COUNT):
            return S.Count(self.parse_expr(11), pos=self._pos(tok))
        if tok := self.match(TT.CHOOSE):
            return S.Choose(self.parse_expr(11), pos=self._pos(tok))
        if tok := self.match(TT.DIFFERENT):
            return S.Different(self.parse_expr(11), pos=self._pos(tok))
        if tok := self.match(TT.MINIMAL):
            return S.Minimal(self.parse_expr(11), pos=self._pos(tok))
        if tok := self.match(TT.MAXIMAL):
            return S.Maximal(self.parse_expr(11), pos=self._pos(tok))
        if tok := self.match(TT.MEDIAN):
            return S.Median(self.parse_expr(11), pos=self._pos(tok))
        if tok := self.match(TT.SAMPLE):
            return S.Sample(self.parse_expr(11), pos=self._pos(tok))
        if tok := self.match(TT.BANG):
            p = self._pos(tok)
            arg = self.parse_expr(11)
            return S.If(arg, S.Empty(pos=p), S.Num(1, pos=p), pos=p)

        # min/max desugar to least 1 / largest 1
        if tok := self.match(TT.MIN):
            p = self._pos(tok)
            return S.Least(S.Num(1, pos=p), self.parse_expr(11), pos=p)
        if tok := self.match(TT.MAX):
            p = self._pos(tok)
            return S.Largest(S.Num(1, pos=p), self.parse_expr(11), pos=p)

        # least/largest take two expression arguments
        if tok := self.match(TT.LEAST):
            n = self.parse_expr(12)
            collection = self.parse_expr(12)
            return S.Least(n, collection, pos=self._pos(tok))
        if tok := self.match(TT.LARGEST):
            n = self.parse_expr(12)
            collection = self.parse_expr(12)
            return S.Largest(n, collection, pos=self._pos(tok))

        # %1, %2 (pair projection)
        if tok := self.match(TT.FIRST):
            return S.First(self.parse_expr(11), pos=self._pos(tok))
        if tok := self.match(TT.SECOND):
            return S.Second(self.parse_expr(11), pos=self._pos(tok))

        # ? (probability)
        if tok := self.match(TT.QUESTION):
            r = self.expect(TT.REAL)
            return S.Question(cast(float, r.value), pos=self._pos(tok))

        # Atoms
        if self.check(TT.NUM):
            tok = self.advance()
            return S.Num(cast(int, tok.value), pos=self._pos(tok))
        if self.check(TT.STRING):
            tok = self.advance()
            return S.String(cast(str, tok.value), pos=self._pos(tok))

        # Identifier — possibly followed by := (let-binding)
        if self.check(TT.ID):
            name_tok = self.advance()
            if self.match(TT.ASSGN):
                value = self.parse_expr(0)
                self.expect(TT.SEMI)
                body = self.parse_expr(0)
                return S.Let(cast(str, name_tok.value), value, body, pos=self._pos(name_tok))
            return S.Id(cast(str, name_tok.value), pos=self._pos(name_tok))

        # Parenthesized expression
        if self.match(TT.LPAR):
            expr = self.parse_expr(0)
            self.expect(TT.RPAR)
            return expr

        # Brace-enclosed collection: { } or { e1, e2, ... }
        if tok := self.match(TT.LBRACE):
            if self.match(TT.RBRACE):
                return S.Empty(pos=self._pos(tok))
            result = self.parse_expr(0)
            while comma := self.match(TT.COMMA):
                right = self.parse_expr(0)
                result = S.Conc(result, right, pos=self._pos(comma))
            self.expect(TT.RBRACE)
            return result

        # Bracket-enclosed pair: [e1, e2]
        if tok := self.match(TT.LBRACK):
            first = self.parse_expr(0)
            self.expect(TT.COMMA)
            second = self.parse_expr(0)
            self.expect(TT.RBRACK)
            return S.Pair(first, second, pos=self._pos(tok))

        raise self.error(f"Unexpected token: {t.type.name}")

    # -- Special form parsers --

    def parse_if(self, tok: Token) -> S.If:
        cond = self.parse_expr(0)
        self.expect(TT.THEN)
        then_e = self.parse_expr(0)
        self.expect(TT.ELSE)
        else_e = self.parse_expr(0)
        return S.If(cond, then_e, else_e, pos=self._pos(tok))

    def parse_foreach(self, tok: Token) -> S.Foreach:
        name = cast(str, self.expect(TT.ID).value)
        self.expect(TT.IN)
        collection = self.parse_expr(0)
        self.expect(TT.DO)
        body = self.parse_expr(0)
        return S.Foreach(name, collection, body, pos=self._pos(tok))

    def parse_repeat_or_accum(self, is_accum: bool, tok: Token) -> S.Exp:
        name = cast(str, self.expect(TT.ID).value)
        self.expect(TT.ASSGN)
        init = self.parse_expr(0)
        if self.match(TT.WHILE):
            cond = self.parse_expr(0)
            is_while = True
        elif self.match(TT.UNTIL):
            cond = self.parse_expr(0)
            is_while = False
        else:
            raise self.error("Expected 'while' or 'until'")
        p = self._pos(tok)
        if is_accum:
            return S.Accum(name, init, cond, is_while, pos=p)
        return S.Repeat(name, init, cond, is_while, pos=p)

    def parse_call(self, tok: Token) -> S.Call:
        name = cast(str, self.expect(TT.ID).value)
        self.expect(TT.LPAR)
        args: list[S.Exp] = []
        if not self.check(TT.RPAR):
            args.append(self.parse_expr(0))
            while self.match(TT.COMMA):
                args.append(self.parse_expr(0))
        self.expect(TT.RPAR)
        return S.Call(name, args, pos=self._pos(tok))


def parse(source: str) -> S.Program:
    """Parse a Troll program source string into an AST."""
    tokens = tokenize(source)
    return Parser(tokens).parse_program()
