"""Pythonic dice expression API.

Build dice expressions using Python objects and method chains,
then evaluate via .roll() or .dist(). This is an alternative to
the Troll string DSL — both produce the same AST and use the
same evaluation engine.

    from troll.dice import d, pool, let, foreach, if_, range_, coin

    # D&D stat roll
    pool(4, d(6)).highest(3).sum().dist().mean  # 12.24

    # WoD exploding pool
    pool(5, d(10).explode(on=10)).where_gt(7).count().dist()

    # Roll a d20 + 5
    (d(20) + 5).roll()  # → 18
"""

from __future__ import annotations

import random as _random
from typing import TYPE_CHECKING

from troll import syntax as S
from troll.sampling import sample as _sample
from troll.values import Multiset as _Multiset
from troll.values import Value as _Value

if TYPE_CHECKING:
    from collections.abc import Callable

    from troll.distribution import Distribution


class Expr:
    """A lazy dice expression. Build it up with methods, then .roll() or .dist().

    Every method returns a new Expr (immutable, composable). The underlying
    AST node is the same type the parser produces — the evaluation engine
    can't tell whether an expression came from parse() or from this API.
    """

    __slots__ = ("_node",)

    def __init__(self, node: S.Exp) -> None:
        self._node = node

    def __repr__(self) -> str:
        return S.show(self._node)

    # -- Evaluation --

    def roll(self, n: int = 1, *, seed: int | None = None) -> _Value | list[_Value]:
        """Roll the dice.

        Returns int for scalar results, list[int] for collections,
        list of results when n > 1.
        """
        prog = S.Program([], self._node)
        rng = _random.Random(seed)
        if n == 1:
            return _simplify(_sample(prog, rng))
        return [_simplify(_sample(prog, _random.Random())) for _ in range(n)]

    # Alias: people will try .sample()
    sample = roll

    def dist(self, *, exact: bool = True, optimize: bool = True) -> Distribution:
        """Compute exact probability distribution."""
        from troll.distribution import distribute as _distribute

        return _distribute(S.Program([], self._node), exact=exact, optimize=optimize)

    # Alias: people will try .distribution()
    distribution = dist

    # -- Aggregation --

    def sum(self) -> Expr:
        """Sum all elements."""
        return Expr(S.Sum(self._node))

    def count(self) -> Expr:
        """Count elements."""
        return Expr(S.Count(self._node))

    def highest(self, n: int = 1) -> Expr:
        """Keep n highest elements."""
        return Expr(S.Largest(S.Num(n), self._node))

    def lowest(self, n: int = 1) -> Expr:
        """Keep n lowest elements."""
        return Expr(S.Least(S.Num(n), self._node))

    def max(self) -> Expr:
        """Single highest element."""
        return self.highest(1)

    def min(self) -> Expr:
        """Single lowest element."""
        return self.lowest(1)

    def minimal(self) -> Expr:
        """All copies of the smallest element."""
        return Expr(S.Minimal(self._node))

    def maximal(self) -> Expr:
        """All copies of the largest element."""
        return Expr(S.Maximal(self._node))

    def median(self) -> Expr:
        """Median element."""
        return Expr(S.Median(self._node))

    def sign(self) -> Expr:
        """Sign: -1, 0, or 1."""
        return Expr(S.Sign(self._node))

    # -- Arithmetic --

    def __add__(self, other: object) -> Expr:
        return Expr(S.Plus(self._node, _to_node(other)))

    def __radd__(self, other: object) -> Expr:
        return Expr(S.Plus(_to_node(other), self._node))

    def __sub__(self, other: object) -> Expr:
        return Expr(S.Minus(self._node, _to_node(other)))

    def __rsub__(self, other: object) -> Expr:
        return Expr(S.Minus(_to_node(other), self._node))

    def __mul__(self, other: object) -> Expr:
        # Expr * int → arithmetic multiplication (Times)
        # Use pool(n, expr) or n * expr for repetition
        return Expr(S.Times(self._node, _to_node(other)))

    def __rmul__(self, other: object) -> Expr:
        if isinstance(other, int):
            return Expr(S.Hash(S.Num(other), self._node))
        return Expr(S.Times(_to_node(other), self._node))

    def __floordiv__(self, other: object) -> Expr:
        return Expr(S.Divide(self._node, _to_node(other)))

    def __mod__(self, other: object) -> Expr:
        return Expr(S.Mod(self._node, _to_node(other)))

    def __neg__(self) -> Expr:
        return Expr(S.UMinus(self._node))

    # -- Collection operations --

    def union(self, other: Expr) -> Expr:
        """Multiset union."""
        return Expr(S.Conc(self._node, other._node))

    def __or__(self, other: object) -> Expr:
        """Multiset union: a | b."""
        if isinstance(other, Expr):
            return self.union(other)
        return NotImplemented

    def drop(self, *values: int) -> Expr:
        """Remove elements by value."""
        return Expr(S.Drop(self._node, _collection_node(values)))

    def keep(self, *values: int) -> Expr:
        """Keep only elements with these values."""
        return Expr(S.Keep(self._node, _collection_node(values)))

    def pick(self, n: int | Expr) -> Expr:
        """Randomly pick n elements without replacement."""
        return Expr(S.Pick(self._node, _to_node(n)))

    def diff(self, other: Expr) -> Expr:
        """Multiset subtraction."""
        return Expr(S.SetMinus(self._node, other._node))

    def unique(self) -> Expr:
        """Remove duplicates."""
        return Expr(S.Different(self._node))

    def choose(self) -> Expr:
        """Pick one element uniformly at random."""
        return Expr(S.Choose(self._node))

    # -- Filtering (comparison-as-filter) --

    def where_eq(self, n: int | Expr) -> Expr:
        """Keep elements equal to n."""
        return Expr(S.Eq(_to_node(n), self._node))

    def where_ne(self, n: int | Expr) -> Expr:
        """Keep elements not equal to n."""
        return Expr(S.Neq(_to_node(n), self._node))

    def where_gt(self, n: int | Expr) -> Expr:
        """Keep elements greater than n."""
        return Expr(S.Lt(_to_node(n), self._node))

    def where_lt(self, n: int | Expr) -> Expr:
        """Keep elements less than n."""
        return Expr(S.Gt(_to_node(n), self._node))

    def where_ge(self, n: int | Expr) -> Expr:
        """Keep elements >= n."""
        return Expr(S.Le(_to_node(n), self._node))

    def where_le(self, n: int | Expr) -> Expr:
        """Keep elements <= n."""
        return Expr(S.Ge(_to_node(n), self._node))

    # -- Conditional / logic --

    def and_(self, other: Expr) -> Expr:
        """Short-circuit: if self is nonempty, evaluate other."""
        return Expr(S.And(self._node, other._node))

    def negate(self) -> Expr:
        """Logical negation: nonempty → empty, empty → 1."""
        return Expr(S.If(self._node, S.Empty(), S.Num(1)))

    def or_default(self, fallback: Expr, *, name: str = "_v") -> Expr:
        """Use self if bound, else fallback."""
        return Expr(S.Default(name, fallback._node))

    # -- Die modifiers --

    def explode(
        self, *, on: int | None = None, while_: Callable[[Expr], Expr] | None = None
    ) -> Expr:
        """Exploding die: reroll and accumulate while condition holds.

        d(10).explode(on=10)  →  accumulate x:=d10 while x=10
        d(6).explode(while_=lambda x: x.where_ge(5))  →  accumulate x:=d6 while 5<=x
        """
        name = "xe"
        if on is not None:
            cond = S.Eq(S.Num(on), S.Id(name))
        elif while_ is not None:
            placeholder = Expr(S.Id(name))
            cond = while_(placeholder)._node
        else:
            raise ValueError("explode() requires on= or while_=")
        return Expr(S.Accum(name, self._node, cond, is_while=True))

    def reroll(
        self, *, on: int | None = None, while_: Callable[[Expr], Expr] | None = None
    ) -> Expr:
        """Reroll die, keeping only the last result.

        d(6).reroll(on=6)  →  repeat x:=d6 while x=6  (d5 by rerolling 6s)
        d(6).reroll(while_=lambda x: x.where_eq(1))  →  reroll 1s
        """
        name = "xr"
        if on is not None:
            cond = S.Eq(S.Num(on), S.Id(name))
        elif while_ is not None:
            placeholder = Expr(S.Id(name))
            cond = while_(placeholder)._node
        else:
            raise ValueError("reroll() requires on= or while_=")
        return Expr(S.Repeat(name, self._node, cond, is_while=True))

    # -- Pairs --

    def first(self) -> Expr:
        """First element of a pair."""
        return Expr(S.First(self._node))

    def second(self) -> Expr:
        """Second element of a pair."""
        return Expr(S.Second(self._node))

    # -- Text --

    def to_text(self) -> Expr:
        """Convert to text representation."""
        return Expr(S.Sample(self._node))

    def sample_text(self, n: int = 1) -> Expr:
        """Produce n text samples."""
        return Expr(S.Samples(S.Num(n), self._node))

    def hconc(self, other: Expr) -> Expr:
        """Horizontal text concatenation."""
        return Expr(S.HConc(self._node, other._node))

    def vconc(self, other: Expr, *, align: str = "left") -> Expr:
        """Vertical text concatenation. align: 'left', 'right', 'center'."""
        match align:
            case "left":
                return Expr(S.VConcL(self._node, other._node))
            case "right":
                return Expr(S.VConcR(self._node, other._node))
            case "center":
                return Expr(S.VConcC(self._node, other._node))
            case _:
                raise ValueError(f"align must be 'left', 'right', or 'center', got {align!r}")


# ---------------------------------------------------------------------------
# Constructor functions
# ---------------------------------------------------------------------------


def d(sides: int) -> Expr:
    """A die with faces 1..sides: d(6), d(20)."""
    return Expr(S.D(S.Num(sides)))


def z(sides: int) -> Expr:
    """A zero-based die with faces 0..sides: z(6) → 0-6."""
    return Expr(S.Z(S.Num(sides)))


def pool(n: int | Expr, die: Expr) -> Expr:
    """Roll a die n times: pool(4, d(6)) → 4d6."""
    return Expr(S.Hash(_to_node(n), die._node))


def const(n: int) -> Expr:
    """A constant value."""
    return Expr(S.Num(n))


def empty() -> Expr:
    """Empty collection."""
    return Expr(S.Empty())


def collection(*values: int) -> Expr:
    """Literal collection: collection(1, 2, 3) → {1, 2, 3}."""
    if not values:
        return empty()
    node: S.Exp = S.Num(values[0])
    for v in values[1:]:
        node = S.Conc(node, S.Num(v))
    return Expr(node)


def from_str(troll_source: str) -> Expr:
    """Parse a Troll expression string into an Expr.

    Bridges the DSL and Pythonic APIs — useful for loading dice
    expressions from config files, YAML, JSON, etc.

        expr = from_str("sum largest 3 4d6")
        expr.roll()   # → 13
        expr.dist()   # → Distribution(...)
    """
    from troll.parser import parse as _parse

    return Expr(_parse(troll_source).expression)


def range_(low: int, high: int) -> Expr:
    """Range: range_(1, 6) → {1, 2, 3, 4, 5, 6}."""
    return Expr(S.FromTo(S.Num(low), S.Num(high)))


def coin(p: float = 0.5) -> Expr:
    """Bernoulli trial: 1 with probability p, empty otherwise."""
    return Expr(S.Question(p))


def text(s: str) -> Expr:
    """String literal."""
    return Expr(S.String(s))


def pair(a: Expr, b: Expr) -> Expr:
    """Pair of values."""
    return Expr(S.Pair(a._node, b._node))


# ---------------------------------------------------------------------------
# Control flow
# ---------------------------------------------------------------------------


def if_(cond: Expr, then: Expr, else_: Expr) -> Expr:
    """Conditional: if_(cond, then_expr, else_expr)."""
    return Expr(S.If(cond._node, then._node, else_._node))


def let(name: str, value: Expr, body_fn: Callable[..., Expr]) -> Expr:
    """Bind a value and use it in the body.

    let('x', d(6), lambda x: x + x)  →  x := d6 ; x + x
    """
    placeholder = Expr(S.Id(name))
    body = body_fn(placeholder)
    return Expr(S.Let(name, value._node, body._node))


def foreach(name: str, collection: Expr, body_fn: Callable[..., Expr]) -> Expr:
    """Iterate over collection elements, union results.

    foreach('i', range_(1, 6), lambda i: pool(1, d(6)).where_eq(i).count())
    """
    placeholder = Expr(S.Id(name))
    body = body_fn(placeholder)
    return Expr(S.Foreach(name, collection._node, body._node))


# ---------------------------------------------------------------------------
# Functions
# ---------------------------------------------------------------------------


def func(name: str, params: list[str], body_fn: Callable[..., Expr]) -> S.FuncDecl:
    """Define a function.

    add = func('add', ['x', 'y'], lambda x, y: x + y)
    """
    placeholders = [Expr(S.Id(p)) for p in params]
    body = body_fn(*placeholders)
    return S.FuncDecl(name, params, body._node)


def call(name: str, *args: Expr) -> Expr:
    """Call a user-defined function."""
    return Expr(S.Call(name, [a._node for a in args]))


def compositional(name: str, empty_val: Expr, single: str, union: str) -> S.CompDecl:
    """Define a compositional function (fold over collection)."""
    return S.CompDecl(name, empty_val._node, single, union)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _to_node(x: object) -> S.Exp:
    """Convert Python value or Expr to AST node."""
    if isinstance(x, Expr):
        return x._node
    if isinstance(x, int):
        return S.Num(x)
    raise TypeError(f"Cannot convert {type(x).__name__} to dice expression")


def _collection_node(values: tuple[int, ...]) -> S.Exp:
    """Build a collection AST node from a tuple of ints."""
    if not values:
        return S.Empty()
    node: S.Exp = S.Num(values[0])
    for v in values[1:]:
        node = S.Conc(node, S.Num(v))
    return node


def _simplify(result: _Value) -> _Value:
    """Simplify a sample result: singleton Multiset → int, multi-element → list."""
    if isinstance(result, _Multiset):
        if len(result) == 1:
            return result[0]  # type: ignore[return-value]
        if len(result) == 0:
            return []  # type: ignore[return-value]
        return list(result)  # type: ignore[return-value]
    return result
