"""Sampling evaluator for the Troll dice language.

Evaluates a Troll AST by rolling dice with a PRNG, producing a single
random Value outcome per evaluation.
"""

from __future__ import annotations

import random as _random
from typing import TypeAlias

from troll import syntax as S
from troll.values import EMPTY, EvalError, Multiset, PairVal, Value, as_int

Env: TypeAlias = dict[str, Value]
Decls: TypeAlias = dict[str, S.Decl]


def sample(program: S.Program, rng: _random.Random | None = None) -> Value:
    """Evaluate a parsed Troll program, returning one random sample."""
    if rng is None:
        rng = _random.Random()
    decls = _build_decls(program.declarations)
    return _eval(program.expression, {}, decls, rng)


def sample_n(program: S.Program, n: int, rng: _random.Random | None = None) -> list[Value]:
    """Evaluate a parsed Troll program n times, returning a list of samples."""
    if rng is None:
        rng = _random.Random()
    decls = _build_decls(program.declarations)
    return [_eval(program.expression, {}, decls, rng) for _ in range(n)]


def _build_decls(decl_list: list[S.Decl]) -> Decls:
    result: Decls = {}
    for d in decl_list:
        match d:
            case S.FuncDecl(name=name):
                result[name] = d
            case S.CompDecl(name=name):
                result[name] = d
    return result


def _eval(exp: S.Exp, env: Env, decls: Decls, rng: _random.Random) -> Value:
    p = exp.pos  # source position for error reporting

    match exp:
        case S.Num(val=n):
            return Multiset.single(n)

        case S.Id(name=name):
            if name in env:
                return env[name]
            raise EvalError(f"Unknown variable: {name}", p)

        case S.Empty():
            return EMPTY

        case S.String(val=s):
            return s

        case S.D(arg=arg):
            n = as_int(_eval(arg, env, decls, rng), p)
            if n <= 0:
                raise EvalError(f"Argument to d must be > 0, got {n}", p)
            return Multiset.single(rng.randint(1, n))

        case S.Z(arg=arg):
            n = as_int(_eval(arg, env, decls, rng), p)
            if n < 0:
                raise EvalError(f"Argument to z must be >= 0, got {n}", p)
            return Multiset.single(rng.randint(0, n))

        case S.Hash(count=count_exp, die=die_exp):
            m = as_int(_eval(count_exp, env, decls, rng), p)
            if m < 0:
                raise EvalError(f"Negative count in #: {m}", p)
            result = EMPTY
            for _ in range(m):
                v = _eval(die_exp, env, decls, rng)
                if not isinstance(v, Multiset):
                    raise EvalError("Argument to # must produce a collection", p)
                result = result.union(v)
            return result

        case S.Plus(left=l, right=r):
            return Multiset.single(
                as_int(_eval(l, env, decls, rng), p) + as_int(_eval(r, env, decls, rng), p)
            )

        case S.Minus(left=l, right=r):
            return Multiset.single(
                as_int(_eval(l, env, decls, rng), p) - as_int(_eval(r, env, decls, rng), p)
            )

        case S.Times(left=l, right=r):
            return Multiset.single(
                as_int(_eval(l, env, decls, rng), p) * as_int(_eval(r, env, decls, rng), p)
            )

        case S.Divide(left=l, right=r):
            lv = _eval(l, env, decls, rng)
            rv = as_int(_eval(r, env, decls, rng), p)
            if isinstance(lv, Multiset) and len(lv) == 0:
                return Multiset.single(0)
            n = as_int(lv, p)
            if rv == 0:
                raise EvalError("Division by zero", p)
            return Multiset.single(n // rv)

        case S.Mod(left=l, right=r):
            lv = _eval(l, env, decls, rng)
            rv = as_int(_eval(r, env, decls, rng), p)
            if isinstance(lv, Multiset) and len(lv) == 0:
                return Multiset.single(0)
            n = as_int(lv, p)
            if rv == 0:
                raise EvalError("Modulo by zero", p)
            return Multiset.single(n % rv)

        case S.UMinus(arg=arg):
            return Multiset.single(-as_int(_eval(arg, env, decls, rng), p))

        case S.Sign(arg=arg):
            n = as_int(_eval(arg, env, decls, rng), p)
            return Multiset.single((n > 0) - (n < 0))

        case S.Sum(arg=arg):
            v = _eval(arg, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Argument to sum must be a collection", p)
            return Multiset.single(v.sum_())

        case S.Count(arg=arg):
            v = _eval(arg, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Argument to count must be a collection", p)
            return Multiset.single(v.count())

        case S.Conc(left=l, right=r):
            lv, rv = _eval(l, env, decls, rng), _eval(r, env, decls, rng)
            if not isinstance(lv, Multiset) or not isinstance(rv, Multiset):
                raise EvalError("Arguments to @ must be collections", p)
            return lv.union(rv)

        case S.FromTo(low=l, high=h):
            return Multiset.from_to(
                as_int(_eval(l, env, decls, rng), p), as_int(_eval(h, env, decls, rng), p)
            )

        case S.Choose(arg=arg):
            v = _eval(arg, env, decls, rng)
            if not isinstance(v, Multiset) or len(v) == 0:
                raise EvalError("Argument to choose must be non-empty collection", p)
            return Multiset.single(rng.choice(list(v)))

        case S.Different(arg=arg):
            v = _eval(arg, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Argument to different must be a collection", p)
            return v.different()

        case S.Least(n=n_exp, collection=coll_exp):
            n = as_int(_eval(n_exp, env, decls, rng), p)
            v = _eval(coll_exp, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Argument to least must be a collection", p)
            return v.least(n)

        case S.Largest(n=n_exp, collection=coll_exp):
            n = as_int(_eval(n_exp, env, decls, rng), p)
            v = _eval(coll_exp, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Argument to largest must be a collection", p)
            return v.largest(n)

        case S.Minimal(arg=arg):
            v = _eval(arg, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Argument to minimal must be a collection", p)
            return v.minimal()

        case S.Maximal(arg=arg):
            v = _eval(arg, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Argument to maximal must be a collection", p)
            return v.maximal()

        case S.Median(arg=arg):
            v = _eval(arg, env, decls, rng)
            if not isinstance(v, Multiset) or len(v) == 0:
                raise EvalError("Argument to median must be non-empty collection", p)
            return Multiset.single(v.median())

        case S.Drop(left=l, right=r):
            lv, rv = _eval(l, env, decls, rng), _eval(r, env, decls, rng)
            if not isinstance(lv, Multiset) or not isinstance(rv, Multiset):
                raise EvalError("Arguments to drop must be collections", p)
            return lv.drop(rv)

        case S.Keep(left=l, right=r):
            lv, rv = _eval(l, env, decls, rng), _eval(r, env, decls, rng)
            if not isinstance(lv, Multiset) or not isinstance(rv, Multiset):
                raise EvalError("Arguments to keep must be collections", p)
            return lv.keep(rv)

        case S.Pick(left=l, right=r):
            lv = _eval(l, env, decls, rng)
            m = as_int(_eval(r, env, decls, rng), p)
            if not isinstance(lv, Multiset):
                raise EvalError("First argument to pick must be a collection", p)
            items = list(lv)
            picked = sorted(rng.sample(items, min(m, len(items))))
            return Multiset(picked)

        case S.SetMinus(left=l, right=r):
            lv, rv = _eval(l, env, decls, rng), _eval(r, env, decls, rng)
            if not isinstance(lv, Multiset) or not isinstance(rv, Multiset):
                raise EvalError("Arguments to -- must be collections", p)
            return lv.set_minus(rv)

        case S.Eq(left=l, right=r):
            n = as_int(_eval(l, env, decls, rng), p)
            v = _eval(r, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Right argument of = must be a collection", p)
            return v.filter_eq(n)

        case S.Neq(left=l, right=r):
            n = as_int(_eval(l, env, decls, rng), p)
            v = _eval(r, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Right argument of =/= must be a collection", p)
            return v.filter_neq(n)

        case S.Lt(left=l, right=r):
            n = as_int(_eval(l, env, decls, rng), p)
            v = _eval(r, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Right argument of < must be a collection", p)
            return v.filter_lt(n)

        case S.Gt(left=l, right=r):
            n = as_int(_eval(l, env, decls, rng), p)
            v = _eval(r, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Right argument of > must be a collection", p)
            return v.filter_gt(n)

        case S.Le(left=l, right=r):
            n = as_int(_eval(l, env, decls, rng), p)
            v = _eval(r, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Right argument of <= must be a collection", p)
            return v.filter_le(n)

        case S.Ge(left=l, right=r):
            n = as_int(_eval(l, env, decls, rng), p)
            v = _eval(r, env, decls, rng)
            if not isinstance(v, Multiset):
                raise EvalError("Right argument of >= must be a collection", p)
            return v.filter_ge(n)

        case S.And(left=l, right=r):
            lv = _eval(l, env, decls, rng)
            if isinstance(lv, Multiset) and len(lv) == 0:
                return EMPTY
            return _eval(r, env, decls, rng)

        case S.Let(name=name, binding=bind, body=body):
            v = _eval(bind, env, decls, rng)
            return _eval(body, {**env, name: v}, decls, rng)

        case S.If(cond=cond, then_=then_e, else_=else_e):
            cv = _eval(cond, env, decls, rng)
            if isinstance(cv, Multiset) and len(cv) == 0:
                return _eval(else_e, env, decls, rng)
            return _eval(then_e, env, decls, rng)

        case S.Foreach(name=name, collection=coll, body=body):
            cv = _eval(coll, env, decls, rng)
            if not isinstance(cv, Multiset):
                raise EvalError("Argument to foreach must be a collection", p)
            result = EMPTY
            for elem in cv:
                v = _eval(body, {**env, name: Multiset.single(elem)}, decls, rng)
                if not isinstance(v, Multiset):
                    raise EvalError("Body of foreach must produce a collection", p)
                result = result.union(v)
            return result

        case S.Repeat(name=name, init=init_e, cond=cond_e, is_while=is_while):
            return _iterate_last(name, init_e, cond_e, is_while, env, decls, rng)

        case S.Accum(name=name, init=init_e, cond=cond_e, is_while=is_while):
            return _iterate_all(name, init_e, cond_e, is_while, env, decls, rng)

        case S.Call(name=fname, args=arg_exps):
            arg_vals = [_eval(a, env, decls, rng) for a in arg_exps]
            return _call_func(fname, arg_vals, decls, rng, p)

        case S.Question(prob=prob):
            if rng.random() < prob:
                return Multiset.single(1)
            return EMPTY

        case S.Pair(first=a, second=b):
            return PairVal(_eval(a, env, decls, rng), _eval(b, env, decls, rng))

        case S.First(arg=arg):
            v = _eval(arg, env, decls, rng)
            if not isinstance(v, PairVal):
                raise EvalError("Argument to %1 must be a pair", p)
            return v.first

        case S.Second(arg=arg):
            v = _eval(arg, env, decls, rng)
            if not isinstance(v, PairVal):
                raise EvalError("Argument to %2 must be a pair", p)
            return v.second

        case S.Default(name=name, fallback=fb):
            if name in env:
                return env[name]
            return _eval(fb, env, decls, rng)

        case S.Sample(arg=arg):
            return _make_text(_eval(arg, env, decls, rng))

        case S.Samples(count=count_exp, arg=arg):
            m = as_int(_eval(count_exp, env, decls, rng), p)
            return "\n".join(str(_make_text(_eval(arg, env, decls, rng))) for _ in range(m))

        case S.HConc() | S.VConcL() | S.VConcR() | S.VConcC():
            # Text concatenation — minimal support
            lv = _make_text(_eval(exp.left, env, decls, rng))  # type: ignore[attr-defined]
            rv = _make_text(_eval(exp.right, env, decls, rng))  # type: ignore[attr-defined]
            return f"{lv} {rv}"

        case _:
            raise EvalError(f"Unsupported expression type: {type(exp).__name__}", p)


def _make_text(v: Value) -> str:
    """Convert a value to its text representation."""
    if isinstance(v, str):
        return v
    if isinstance(v, PairVal):
        return f"[{_make_text(v.first)}, {_make_text(v.second)}]"
    if isinstance(v, Multiset):
        return " ".join(str(x) for x in v)
    return repr(v)


def _iterate_last(
    name: str,
    init_e: S.Exp,
    cond_e: S.Exp,
    is_while: bool,
    env: Env,
    decls: Decls,
    rng: _random.Random,
    max_iter: int = 1000,
) -> Value:
    """Evaluate repeat: keep last value of iteration."""
    v = _eval(init_e, env, decls, rng)
    for _ in range(max_iter):
        if not isinstance(v, Multiset):
            raise EvalError("Repeat value must be a collection", init_e.pos)
        test = _eval(cond_e, {**env, name: v}, decls, rng)
        test_true = isinstance(test, Multiset) and len(test) > 0
        should_continue = test_true if is_while else not test_true
        if not should_continue:
            return v
        v = _eval(init_e, env, decls, rng)
    return v


def _iterate_all(
    name: str,
    init_e: S.Exp,
    cond_e: S.Exp,
    is_while: bool,
    env: Env,
    decls: Decls,
    rng: _random.Random,
    max_iter: int = 1000,
) -> Value:
    """Evaluate accumulate: union all intermediate values."""
    v = _eval(init_e, env, decls, rng)
    if not isinstance(v, Multiset):
        raise EvalError("Accumulate value must be a collection", init_e.pos)
    result = v
    for _ in range(max_iter):
        test = _eval(cond_e, {**env, name: v}, decls, rng)
        test_true = isinstance(test, Multiset) and len(test) > 0
        should_continue = test_true if is_while else not test_true
        if not should_continue:
            return result
        v = _eval(init_e, env, decls, rng)
        if not isinstance(v, Multiset):
            raise EvalError("Accumulate value must be a collection", init_e.pos)
        result = result.union(v)
    return result


def _call_func(
    fname: str,
    args: list[Value],
    decls: Decls,
    rng: _random.Random,
    call_pos: tuple[int, int] = (0, 0),
) -> Value:
    """Call a user-defined function."""
    decl = decls.get(fname)
    if decl is None:
        raise EvalError(f"Unknown function: {fname}", call_pos)

    if isinstance(decl, S.FuncDecl):
        if len(args) != len(decl.params):
            raise EvalError(f"Wrong number of arguments to {fname}", call_pos)
        fn_env: Env = dict(zip(decl.params, args, strict=True))
        return _eval(decl.body, fn_env, decls, rng)

    if isinstance(decl, S.CompDecl):
        if len(args) != 1:
            raise EvalError(f"Compositional {fname} takes exactly 1 argument", call_pos)
        v = args[0]
        if not isinstance(v, Multiset):
            raise EvalError(f"Argument to compositional {fname} must be a collection", call_pos)
        return _compositional(list(v), decl, decls, rng)

    raise EvalError(f"Unknown declaration type for {fname}", call_pos)


def _compositional(
    items: list[int],
    decl: S.CompDecl,
    decls: Decls,
    rng: _random.Random,
) -> Value:
    """Evaluate a compositional function: fold over list elements."""
    if not items:
        return _eval(decl.empty, {}, decls, rng)
    result = _call_func(decl.single, [Multiset.single(items[0])], decls, rng)
    for x in items[1:]:
        elem_val = _call_func(decl.single, [Multiset.single(x)], decls, rng)
        result = _call_func(decl.union, [result, elem_val], decls, rng)
    return result
