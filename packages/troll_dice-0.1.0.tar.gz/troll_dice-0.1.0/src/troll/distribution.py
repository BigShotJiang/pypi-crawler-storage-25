"""Exact probability distribution engine for the Troll dice language.

Computes complete probability mass functions over all possible outcomes
of a Troll expression. Uses fractions.Fraction for exact arithmetic.
"""

from __future__ import annotations

try:
    from cfractions import Fraction
except ImportError:
    from fractions import Fraction
from typing import TYPE_CHECKING, TypeAlias

from troll import syntax as S
from troll.values import EMPTY, EvalError, Multiset, PairVal, Value, as_int

if TYPE_CHECKING:
    from collections.abc import Callable

Prob: TypeAlias = Fraction | float
Env: TypeAlias = dict[str, Value]
Decls: TypeAlias = dict[str, S.Decl]


class Distribution:
    """A probability mass function over Troll values.

    Maps each possible outcome (Value) to its exact probability (Fraction).
    """

    __slots__ = ("_pmf",)

    # Probability type: Fraction for exact mode, float for fast mode
    _prob_type: type = Fraction

    def __init__(self, pmf: dict[Value, Prob]) -> None:
        self._pmf = {k: v for k, v in pmf.items() if v > 0}

    # -- Constructors --

    @classmethod
    def certain(cls, value: Value) -> Distribution:
        return cls({value: cls._prob_type(1)})

    @classmethod
    def uniform(cls, values: list[Value]) -> Distribution:
        n = len(values)
        if n == 0:
            return cls({})
        p = cls._prob_type(1) / n
        pmf: dict[Value, Prob] = {}
        for v in values:
            pmf[v] = pmf.get(v, cls._prob_type(0)) + p
        return cls(pmf)

    @classmethod
    def impossible(cls) -> Distribution:
        return cls({})

    @classmethod
    def choice(cls, p: Prob, d1: Distribution, d2: Distribution) -> Distribution:
        """Weighted mixture: outcome is d1 with probability p, d2 with 1-p."""
        if p == 1:
            return d1
        if p == 0:
            return d2
        zero = cls._prob_type(0)
        pmf: dict[Value, Prob] = {}
        q = cls._prob_type(1) - p
        for v, prob in d1._pmf.items():
            pmf[v] = pmf.get(v, zero) + p * prob  # type: ignore[operator]
        for v, prob in d2._pmf.items():
            pmf[v] = pmf.get(v, zero) + q * prob
        return cls(pmf)

    # -- Combinators --

    def map(self, f: Callable[[Value], Value]) -> Distribution:
        """Apply f to each outcome, merging probabilities for collisions."""
        zero = self._prob_type(0)
        pmf: dict[Value, Prob] = {}
        for val, prob in self._pmf.items():
            new_val = f(val)
            pmf[new_val] = pmf.get(new_val, zero) + prob  # type: ignore[operator]
        return Distribution(pmf)

    def flat_map(self, f: Callable[[Value], Distribution]) -> Distribution:
        """Monadic bind: f returns a Distribution for each outcome."""
        zero = self._prob_type(0)
        pmf: dict[Value, Prob] = {}
        for val, p_val in self._pmf.items():
            sub = f(val)
            for sub_val, p_sub in sub._pmf.items():
                pmf[sub_val] = pmf.get(sub_val, zero) + p_val * p_sub  # type: ignore[operator]
        return Distribution(pmf)

    def combine(self, other: Distribution, f: Callable[[Value, Value], Value]) -> Distribution:
        """Cartesian product of two independent distributions, combining with f."""
        zero = self._prob_type(0)
        pmf: dict[Value, Prob] = {}
        for v1, p1 in self._pmf.items():
            for v2, p2 in other._pmf.items():
                val = f(v1, v2)
                pmf[val] = pmf.get(val, zero) + p1 * p2  # type: ignore[operator]
        return Distribution(pmf)

    # -- Queries --

    def items(self) -> list[tuple[Value, Fraction]]:
        """Sorted list of (value, probability) pairs."""
        return sorted(self._pmf.items(), key=lambda x: x[0])  # type: ignore[return-value]

    def prob(self, predicate: Callable[[Value], bool]) -> Prob:
        """Sum of probabilities where predicate holds."""
        return sum((p for v, p in self._pmf.items() if predicate(v)), self._prob_type(0))

    def p_empty(self) -> Prob:
        """Probability that the outcome is an empty Multiset."""
        return self.prob(lambda v: isinstance(v, Multiset) and len(v) == 0)

    def p_nonempty(self) -> Prob:
        return self._prob_type(1) - self.p_empty()

    def is_empty(self) -> bool:
        return len(self._pmf) == 0

    def __len__(self) -> int:
        return len(self._pmf)

    def __repr__(self) -> str:
        if not self._pmf:
            return "Distribution(impossible)"
        items = self.items()
        lines = [f"  {_show_value(v)}: {float(p) * 100:.4f}%" for v, p in items]
        return "Distribution(\n" + "\n".join(lines) + "\n)"

    # -- Statistics (only meaningful for singleton-int-valued distributions) --

    @property
    def mean(self) -> float:
        return sum(float(as_int(v)) * float(p) for v, p in self._pmf.items())

    @property
    def variance(self) -> float:
        m = self.mean
        return sum(float(p) * (float(as_int(v)) - m) ** 2 for v, p in self._pmf.items())

    @property
    def std(self) -> float:
        return self.variance**0.5

    # -- Python numeric / dict-like interface --

    def __getitem__(self, value: Value) -> Prob:
        """Look up probability of a specific value."""
        return self._pmf.get(value, self._prob_type(0))  # type: ignore[return-value]

    def __contains__(self, value: Value) -> bool:
        return value in self._pmf

    def __iter__(self):
        """Iterate over (value, probability) pairs, sorted."""
        return iter(self.items())

    def __float__(self) -> float:
        """Convert to float (returns mean for scalar distributions)."""
        return self.mean

    def values(self) -> list[Value]:
        """Sorted list of possible outcomes."""
        return [v for v, _ in self.items()]

    def probabilities(self) -> list[Prob]:
        """Probabilities in the same order as values()."""
        return [p for _, p in self.items()]

    def to_dict(self) -> dict[Value, Prob]:
        """Return a copy of the PMF dict."""
        return dict(self._pmf)

    def to_float_dict(self) -> dict[Value, float]:
        """Return PMF as {value: float_probability}."""
        return {v: float(p) for v, p in self._pmf.items()}


def _show_value(v: Value) -> str:
    if isinstance(v, Multiset):
        return " ".join(str(x) for x in v) if v else "{}"
    if isinstance(v, PairVal):
        return f"[{_show_value(v.first)}, {_show_value(v.second)}]"
    return repr(v)


# ---------------------------------------------------------------------------
# Distribution evaluator
# ---------------------------------------------------------------------------

_MAX_ITERATIONS = 12


def _zero() -> Prob:
    return Distribution._prob_type(0)


def _one() -> Prob:
    return Distribution._prob_type(1)


# ---------------------------------------------------------------------------
# Optional numpy acceleration
# ---------------------------------------------------------------------------

try:
    import numpy as _np

    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False


def _dist_to_array(d: Distribution) -> tuple | None:
    """Convert a scalar-int Distribution to (int64_array, offset, denominator).

    Returns None if values aren't all singleton-int Multisets, or if the
    distribution is empty. The array stores integer numerators; the
    denominator is the LCD of all probabilities.
    """
    if not _HAS_NUMPY or not d._pmf:
        return None
    # Check all keys are singleton ints
    int_vals: list[tuple[int, Prob]] = []
    for v, p in d._pmf.items():
        if not isinstance(v, Multiset) or len(v) != 1:
            return None
        int_vals.append((v[0], p))
    # Find range
    lo = min(v for v, _ in int_vals)
    hi = max(v for v, _ in int_vals)
    size = hi - lo + 1
    # Build int numerator array by finding common denominator
    # For Fraction: extract numerator/denominator. For float: use float array.
    if hasattr(int_vals[0][1], "denominator"):  # Fraction or cfractions.Fraction
        from math import gcd, lcm

        denom = 1
        for _, p in int_vals:
            denom = lcm(denom, p.denominator)  # type: ignore[union-attr]
        nums = [int((p * denom).numerator) for _, p in int_vals]  # type: ignore[union-attr]
        # Reduce by GCD to keep numbers small
        g = nums[0]
        for n in nums[1:]:
            g = gcd(g, n)
        if g > 1:
            nums = [n // g for n in nums]
            denom = denom // g
        # Check if values fit in int64 (safe for convolution)
        max_num = max(abs(n) for n in nums)
        # After convolution of two arrays of length L with max value M,
        # result values can be up to L * M^2. Check headroom.
        max_after_conv = size * max_num * max_num
        if max_after_conv <= _np.iinfo(_np.int64).max // (size + 1):
            arr = _np.zeros(size, dtype=_np.int64)
            for idx, (v, _) in enumerate(int_vals):
                arr[v - lo] = nums[idx]
            return (arr, lo, denom)
        # Fall through to float mode if int64 would overflow

    # Float mode: store floats, denominator=0 signals float mode
    arr = _np.zeros(size, dtype=_np.float64)
    for v, p in int_vals:
        arr[v - lo] = float(p)
    return (arr, lo, 0)


def _array_to_dist(arr: object, offset: int, denominator: int) -> Distribution:
    """Convert a numpy array + offset + denominator back to a Distribution."""
    pmf: dict[Value, Prob] = {}
    a = arr  # type: ignore[assignment]
    for i in range(len(a)):  # type: ignore[arg-type]
        val = int(a[i])  # type: ignore[index]
        if val != 0 if denominator > 0 else a[i] > 0:  # type: ignore[index]
            if denominator > 0:
                pmf[Multiset.single(i + offset)] = Fraction(val, denominator)  # type: ignore[assignment]
            else:
                pmf[Multiset.single(i + offset)] = float(a[i])  # type: ignore[index]
    return Distribution(pmf)


def _convolve(d1: Distribution, d2: Distribution) -> Distribution:
    """Convolve two scalar-int distributions (sum of independent variables).

    Uses numpy when available, falls back to dict-based combine.
    """
    if _HAS_NUMPY:
        t1 = _dist_to_array(d1)
        t2 = _dist_to_array(d2)
        if t1 is not None and t2 is not None:
            a1, off1, den1 = t1
            a2, off2, den2 = t2
            result = _np.convolve(a1, a2)
            if den1 > 0 and den2 > 0:
                return _array_to_dist(result, off1 + off2, den1 * den2)
            return _array_to_dist(result, off1 + off2, 0)
    # Fallback
    return d1.combine(d2, lambda a, b: Multiset.single(as_int(a) + as_int(b)))


def _subtract_dists(d1: Distribution, d2: Distribution) -> Distribution:
    """Distribution of d1 - d2 for independent scalar-int distributions.

    Uses numpy correlate when available, falls back to dict-based combine.
    """
    if _HAS_NUMPY:
        t1 = _dist_to_array(d1)
        t2 = _dist_to_array(d2)
        if t1 is not None and t2 is not None:
            a1, off1, den1 = t1
            a2, off2, den2 = t2
            result = _np.correlate(a1, a2, mode="full")
            result_offset = off1 - (off2 + len(a2) - 1)
            if den1 > 0 and den2 > 0:
                return _array_to_dist(result, result_offset, den1 * den2)
            return _array_to_dist(result, result_offset, 0)
    # Fallback
    return d1.combine(d2, lambda a, b: Multiset.single(as_int(a) - as_int(b)))


def _convolve_n(n: int, d: Distribution) -> Distribution:
    """N-fold self-convolution using doubling. O(log n) convolutions.

    Uses numpy when available, falls back to dict-based _hash_n_with.
    """
    if n <= 0:
        return Distribution.certain(Multiset.single(0))
    if n == 1:
        return d
    if _HAS_NUMPY:
        t = _dist_to_array(d)
        if t is not None:
            arr, offset, denom = t
            # Doubling: compute arr^n via repeated squaring
            result = arr
            result_off = offset
            result_den = denom
            power = arr
            power_off = offset
            power_den = denom
            remaining = n - 1
            while remaining > 0:
                if remaining % 2 == 1:
                    result = _np.convolve(result, power)
                    result_off += power_off
                    result_den = result_den * power_den if result_den > 0 and power_den > 0 else 0
                    remaining -= 1
                if remaining > 0:
                    power = _np.convolve(power, power)
                    power_off *= 2
                    power_den = power_den * power_den if power_den > 0 else 0
                    remaining //= 2
            return _array_to_dist(result, result_off, result_den)

    # Fallback
    def _add(a: Value, b: Value) -> Value:
        return Multiset.single(as_int(a) + as_int(b))

    return _hash_n_with(n, d, _add, Multiset.single(0))


def distribute(
    program: S.Program,
    *,
    max_iterations: int = _MAX_ITERATIONS,
    exact: bool = True,
    optimize: bool = True,
) -> Distribution:
    """Compute the probability distribution of a Troll program.

    Args:
        exact: If True (default), use fractions.Fraction for exact arithmetic.
               If False, use float for ~50-100x faster computation.
        optimize: If True (default), use AST pattern-matching optimizations
               (sum convolution, count-hash). Set False for benchmarking
               or to force the naive evaluation path.
    """
    # Set probability type for this evaluation
    prev = Distribution._prob_type
    Distribution._prob_type = Fraction if exact else float
    try:
        decls = _build_decls(program.declarations)
        ctx = _Ctx(
            decls=decls, max_iter=max_iterations, max_calls=max_iterations, optimize=optimize
        )
        return _dist(program.expression, {}, ctx)
    finally:
        Distribution._prob_type = prev


def _build_decls(decl_list: list[S.Decl]) -> Decls:
    result: Decls = {}
    for d in decl_list:
        match d:
            case S.FuncDecl(name=name):
                result[name] = d
            case S.CompDecl(name=name):
                result[name] = d
    return result


class _Ctx:
    """Evaluation context: declarations, limits, memoization."""

    def __init__(
        self, decls: Decls, max_iter: int, max_calls: int, *, optimize: bool = True
    ) -> None:
        self.decls = decls
        self.max_iter = max_iter
        self.max_calls = max_calls
        self.optimize = optimize
        self.memo: dict[tuple[str, tuple[tuple[str, Value], ...]], Distribution] = {}


def _dist(exp: S.Exp, env: Env, ctx: _Ctx) -> Distribution:
    p = exp.pos  # source position for error reporting

    match exp:
        case S.Num(val=n):
            return Distribution.certain(Multiset.single(n))

        case S.Id(name=name):
            if name in env:
                return Distribution.certain(env[name])
            raise EvalError(f"Unknown variable: {name}", p)

        case S.Empty():
            return Distribution.certain(EMPTY)

        case S.String(val=s):
            return Distribution.certain(s)

        case S.D(arg=arg):
            return _dist(arg, env, ctx).flat_map(
                lambda v: Distribution.uniform(
                    [Multiset.single(i) for i in range(1, as_int(v, p) + 1)]
                )
            )

        case S.Z(arg=arg):
            return _dist(arg, env, ctx).flat_map(
                lambda v: Distribution.uniform(
                    [Multiset.single(i) for i in range(0, as_int(v, p) + 1)]
                )
            )

        case S.Hash(count=count_exp, die=die_exp):
            die_dist = _dist(die_exp, env, ctx)
            return _dist(count_exp, env, ctx).flat_map(lambda v: _hash_n(as_int(v, p), die_dist))

        case S.Plus(left=l, right=r):
            return _convolve(_dist(l, env, ctx), _dist(r, env, ctx))

        case S.Minus(left=l, right=r):
            return _subtract_dists(_dist(l, env, ctx), _dist(r, env, ctx))

        case S.Times(left=l, right=r):
            return _arith(_dist(l, env, ctx), _dist(r, env, ctx), lambda a, b: a * b, p)

        case S.Divide(left=l, right=r):
            return _arith(_dist(l, env, ctx), _dist(r, env, ctx), lambda a, b: a // b, p)

        case S.Mod(left=l, right=r):
            return _arith(_dist(l, env, ctx), _dist(r, env, ctx), lambda a, b: a % b, p)

        case S.UMinus(arg=arg):
            return _dist(arg, env, ctx).map(lambda v: Multiset.single(-as_int(v, p)))

        case S.Sign(arg=arg):
            return _dist(arg, env, ctx).map(
                lambda v: Multiset.single((as_int(v, p) > 0) - (as_int(v, p) < 0))
            )

        case S.Sum(arg=arg):
            # Optimization: Sum(Hash(n, expr)) → convolve sum(expr) n times
            if ctx.optimize and isinstance(arg, S.Hash):
                return _sum_hash(arg, env, ctx)
            return _dist(arg, env, ctx).map(
                lambda v: Multiset.single(v.sum_()) if isinstance(v, Multiset) else v
            )

        case S.Count(arg=arg):
            # Optimization: Count(filter(K, Hash(N, expr))) → convolve Bernoulli
            if ctx.optimize:
                ch = _try_count_hash(arg, env, ctx)
                if ch is not None:
                    return ch
            return _dist(arg, env, ctx).map(
                lambda v: Multiset.single(v.count()) if isinstance(v, Multiset) else v
            )

        case S.Conc(left=l, right=r):
            return _dist(l, env, ctx).combine(
                _dist(r, env, ctx),
                lambda a, b: (
                    a.union(b) if isinstance(a, Multiset) and isinstance(b, Multiset) else a
                ),  # type: ignore[union-attr]
            )

        case S.FromTo(low=l, high=h):
            return _dist(l, env, ctx).combine(
                _dist(h, env, ctx),
                lambda a, b: Multiset.from_to(as_int(a, p), as_int(b, p)),
            )

        case S.Choose(arg=arg):
            d = _dist(arg, env, ctx)
            return d.flat_map(_choose_from)

        case S.Different(arg=arg):
            return _dist(arg, env, ctx).map(
                lambda v: v.different() if isinstance(v, Multiset) else v  # type: ignore[union-attr]
            )

        case S.Least(n=n_exp, collection=coll_exp):
            return _dist(n_exp, env, ctx).flat_map(
                lambda n_v: _dist(coll_exp, env, ctx).map(
                    lambda c: c.least(as_int(n_v, p)) if isinstance(c, Multiset) else c  # type: ignore[union-attr]
                )
            )

        case S.Largest(n=n_exp, collection=coll_exp):
            return _dist(n_exp, env, ctx).flat_map(
                lambda n_v: _dist(coll_exp, env, ctx).map(
                    lambda c: c.largest(as_int(n_v, p)) if isinstance(c, Multiset) else c  # type: ignore[union-attr]
                )
            )

        case S.Minimal(arg=arg):
            return _dist(arg, env, ctx).map(
                lambda v: v.minimal() if isinstance(v, Multiset) else v  # type: ignore[union-attr]
            )

        case S.Maximal(arg=arg):
            return _dist(arg, env, ctx).map(
                lambda v: v.maximal() if isinstance(v, Multiset) else v  # type: ignore[union-attr]
            )

        case S.Median(arg=arg):
            return _dist(arg, env, ctx).map(
                lambda v: Multiset.single(v.median()) if isinstance(v, Multiset) else v  # type: ignore[union-attr]
            )

        case S.Drop(left=l, right=r):
            return _dist(l, env, ctx).combine(
                _dist(r, env, ctx),
                lambda a, b: (
                    a.drop(b) if isinstance(a, Multiset) and isinstance(b, Multiset) else a
                ),  # type: ignore[union-attr]
            )

        case S.Keep(left=l, right=r):
            return _dist(l, env, ctx).combine(
                _dist(r, env, ctx),
                lambda a, b: (
                    a.keep(b) if isinstance(a, Multiset) and isinstance(b, Multiset) else a
                ),  # type: ignore[union-attr]
            )

        case S.Pick(left=coll_exp, right=count_exp):
            coll_d = _dist(coll_exp, env, ctx)
            return _dist(count_exp, env, ctx).flat_map(
                lambda n_v: coll_d.flat_map(
                    lambda c: (
                        _pick_dist(c, as_int(n_v, p))
                        if isinstance(c, Multiset)
                        else Distribution.certain(c)
                    )
                )
            )

        case S.SetMinus(left=l, right=r):
            return _dist(l, env, ctx).combine(
                _dist(r, env, ctx),
                lambda a, b: (
                    a.set_minus(b) if isinstance(a, Multiset) and isinstance(b, Multiset) else a
                ),  # type: ignore[union-attr]
            )

        case S.Eq(left=l, right=r):
            return _comparison(_dist(l, env, ctx), _dist(r, env, ctx), Multiset.filter_eq, p)

        case S.Neq(left=l, right=r):
            return _comparison(_dist(l, env, ctx), _dist(r, env, ctx), Multiset.filter_neq, p)

        case S.Lt(left=l, right=r):
            return _comparison(_dist(l, env, ctx), _dist(r, env, ctx), Multiset.filter_lt, p)

        case S.Gt(left=l, right=r):
            return _comparison(_dist(l, env, ctx), _dist(r, env, ctx), Multiset.filter_gt, p)

        case S.Le(left=l, right=r):
            return _comparison(_dist(l, env, ctx), _dist(r, env, ctx), Multiset.filter_le, p)

        case S.Ge(left=l, right=r):
            return _comparison(_dist(l, env, ctx), _dist(r, env, ctx), Multiset.filter_ge, p)

        case S.And(left=l, right=r):
            ld = _dist(l, env, ctx)
            p_e = ld.p_empty()
            if p_e == 1:
                return Distribution.certain(EMPTY)
            rd = _dist(r, env, ctx)
            if p_e == 0:
                return rd
            return Distribution.choice(_one() - p_e, rd, Distribution.certain(EMPTY))

        case S.Let(name=name, binding=bind, body=body):
            return _dist(bind, env, ctx).flat_map(lambda v: _dist(body, {**env, name: v}, ctx))

        case S.If(cond=cond, then_=then_e, else_=else_e):
            cond_d = _dist(cond, env, ctx)
            p_e = cond_d.p_empty()
            if p_e == 1:
                return _dist(else_e, env, ctx)
            if p_e == 0:
                return _dist(then_e, env, ctx)
            return Distribution.choice(
                _one() - p_e,
                _dist(then_e, env, ctx),
                _dist(else_e, env, ctx),
            )

        case S.Foreach(name=name, collection=coll, body=body):
            return _dist(coll, env, ctx).flat_map(
                lambda cv: _foreach_concrete(cv, name, body, env, ctx)
            )

        case S.Repeat(name=name, init=init_e, cond=cond_e, is_while=is_while):
            return _dist_iterate(name, init_e, cond_e, is_while, env, ctx, accum=False)

        case S.Accum(name=name, init=init_e, cond=cond_e, is_while=is_while):
            return _dist_iterate(name, init_e, cond_e, is_while, env, ctx, accum=True)

        case S.Call(name=fname, args=arg_exps):
            return _dist_call(fname, arg_exps, env, ctx)

        case S.Question(prob=prob):
            fp: Prob = (  # type: ignore[assignment]
                Fraction(prob).limit_denominator(10**15)
                if Distribution._prob_type is Fraction
                else prob
            )
            return Distribution(
                {
                    Multiset.single(1): fp,
                    EMPTY: _one() - fp,
                }
            )

        case S.Pair(first=a, second=b):
            return _dist(a, env, ctx).combine(
                _dist(b, env, ctx),
                lambda av, bv: PairVal(av, bv),
            )

        case S.First(arg=arg):
            return _dist(arg, env, ctx).map(
                lambda v: v.first if isinstance(v, PairVal) else v  # type: ignore[union-attr]
            )

        case S.Second(arg=arg):
            return _dist(arg, env, ctx).map(
                lambda v: v.second if isinstance(v, PairVal) else v  # type: ignore[union-attr]
            )

        case S.Default(name=name, fallback=fb):
            if name in env:
                return Distribution.certain(env[name])
            return _dist(fb, env, ctx)

        case S.Sample(arg=arg):
            return _dist(arg, env, ctx).map(
                lambda v: " ".join(str(x) for x in v) if isinstance(v, Multiset) else str(v)
            )

        case _:
            raise EvalError(f"Distribution not supported for: {type(exp).__name__}", p)


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _arith(
    d1: Distribution,
    d2: Distribution,
    op: Callable[[int, int], int],
    pos: tuple[int, int] = (0, 0),
) -> Distribution:
    """Arithmetic on two singleton-int distributions."""
    return d1.combine(d2, lambda a, b: Multiset.single(op(as_int(a, pos), as_int(b, pos))))


def _comparison(
    left_d: Distribution,
    right_d: Distribution,
    filt: Callable[[Multiset, int], Multiset],
    pos: tuple[int, int] = (0, 0),
) -> Distribution:
    """Comparison-as-filter: left must be singleton, right is filtered."""
    return left_d.flat_map(
        lambda lv: right_d.map(
            lambda rv: filt(rv, as_int(lv, pos)) if isinstance(rv, Multiset) else rv  # type: ignore[arg-type]
        )
    )


def _hash_n(n: int, die_dist: Distribution) -> Distribution:
    """Compute n # die_dist using doubling (O(log n) combines)."""
    return _hash_n_with(n, die_dist, _union_vals, EMPTY)


def _hash_n_with(
    n: int,
    die_dist: Distribution,
    combine: Callable[[Value, Value], Value],
    zero: Value,
) -> Distribution:
    """Compute n repetitions of die_dist combined with an arbitrary function.

    Uses doubling for O(log n) combines. `zero` is the identity element
    for `combine` (empty multiset for union, Multiset([0]) for addition).
    """
    if n <= 0:
        return Distribution.certain(zero)
    if n == 1:
        return die_dist
    if n % 2 == 0:
        half = _hash_n_with(n // 2, die_dist, combine, zero)
        return half.combine(half, combine)
    rest = _hash_n_with(n - 1, die_dist, combine, zero)
    return rest.combine(die_dist, combine)


def _sum_hash(hash_node: S.Hash, env: Env, ctx: _Ctx) -> Distribution:
    """Optimized evaluation of Sum(Hash(n, expr)).

    Instead of computing the full multiset distribution and then summing,
    compute the sum distribution of a single repetition and convolve n times.
    This is the homomorphic optimization: sum(A union B) = sum(A) + sum(B).
    """

    # Compute distribution of sum(single_die)
    single_sum_dist = _dist(hash_node.die, env, ctx).map(
        lambda v: Multiset.single(v.sum_()) if isinstance(v, Multiset) else v
    )

    # Convolve n times using addition (numpy-accelerated when available)
    return _dist(hash_node.count, env, ctx).flat_map(
        lambda v: _convolve_n(as_int(v), single_sum_dist)
    )


def _try_count_hash(arg: S.Exp, env: Env, ctx: _Ctx) -> Distribution | None:
    """Detect Count(filter(K, Hash(N, expr))) and optimize via convolution.

    The insight: count(filter(K, A union B)) = count(filter(K, A)) + count(filter(K, B)).
    So count-of-filtered is a homomorphism over union, and we can convolve the
    per-die count distribution N times instead of building the full multiset.
    """
    # Pattern: the arg to Count must be a comparison with a Hash on one side
    # and a Num (the threshold) on the other.
    hash_node: S.Hash | None = None
    filter_fn: object = None

    match arg:
        case S.Lt(left=S.Num(val=k), right=S.Hash() as h):
            hash_node, filter_fn = (
                h,
                (lambda v, k=k: Multiset.single(v.count()) if isinstance(v, Multiset) else v),
            )  # type: ignore[assignment]
            # count(k < hash) → for each die outcome, count elements > k
            hash_node = h

            def _make_filter(kk: int):  # type: ignore[return]
                def filt(v: Value) -> Value:
                    if isinstance(v, Multiset):
                        return Multiset.single(len([x for x in v if x > kk]))
                    return v

                return filt

            filter_fn = _make_filter(k)
        case S.Gt(left=S.Num(val=k), right=S.Hash() as h):
            hash_node = h

            def _make_filter_gt(kk: int):  # type: ignore[return]
                def filt(v: Value) -> Value:
                    if isinstance(v, Multiset):
                        return Multiset.single(len([x for x in v if x < kk]))
                    return v

                return filt

            filter_fn = _make_filter_gt(k)
        case S.Le(left=S.Num(val=k), right=S.Hash() as h):
            hash_node = h

            def _make_filter_le(kk: int):  # type: ignore[return]
                def filt(v: Value) -> Value:
                    if isinstance(v, Multiset):
                        return Multiset.single(len([x for x in v if x >= kk]))
                    return v

                return filt

            filter_fn = _make_filter_le(k)
        case S.Ge(left=S.Num(val=k), right=S.Hash() as h):
            hash_node = h

            def _make_filter_ge(kk: int):  # type: ignore[return]
                def filt(v: Value) -> Value:
                    if isinstance(v, Multiset):
                        return Multiset.single(len([x for x in v if x <= kk]))
                    return v

                return filt

            filter_fn = _make_filter_ge(k)
        case S.Eq(left=S.Num(val=k), right=S.Hash() as h):
            hash_node = h

            def _make_filter_eq(kk: int):  # type: ignore[return]
                def filt(v: Value) -> Value:
                    if isinstance(v, Multiset):
                        return Multiset.single(len([x for x in v if x == kk]))
                    return v

                return filt

            filter_fn = _make_filter_eq(k)
        case _:
            return None

    if hash_node is None or filter_fn is None:
        return None

    # Compute per-die count distribution: for each possible die outcome,
    # how many elements pass the filter?
    single_count_dist = _dist(hash_node.die, env, ctx).map(filter_fn)

    # Convolve N times (sum of independent Bernoulli/small-int RVs)
    return _dist(hash_node.count, env, ctx).flat_map(
        lambda v: _convolve_n(as_int(v), single_count_dist)
    )


def _union_vals(a: Value, b: Value) -> Value:
    if isinstance(a, Multiset) and isinstance(b, Multiset):
        return a.union(b)
    raise EvalError("Cannot union non-collection values")


def _choose_from(v: Value) -> Distribution:
    """Uniform choice of one element from a multiset."""
    if not isinstance(v, Multiset) or len(v) == 0:
        raise EvalError("Cannot choose from empty or non-collection")
    items = list(v)
    return Distribution.uniform([Multiset.single(x) for x in items])


def _pick_dist(coll: Multiset, m: int) -> Distribution:
    """Distribution over all ways to pick m elements from a sorted multiset."""
    items = list(coll)
    n = len(items)
    if m <= 0:
        return Distribution.certain(EMPTY)
    if m >= n:
        return Distribution.certain(coll)
    return _pick_recursive(items, m, n)


def _pick_recursive(items: list[int], m: int, n: int) -> Distribution:
    """Recursively compute pick distribution following Troll's algorithm."""
    if m <= 0:
        return Distribution.certain(EMPTY)
    if m >= n:
        return Distribution.certain(Multiset(items[:n]))
    if n <= 0:
        return Distribution.certain(EMPTY)
    p_take: Prob = Distribution._prob_type(m) / n  # type: ignore[assignment]
    taken = Distribution.certain(Multiset.single(items[0])).combine(
        _pick_recursive(items[1:], m - 1, n - 1),
        _union_vals,
    )
    not_taken = _pick_recursive(items[1:], m, n - 1)
    return Distribution.choice(p_take, taken, not_taken)


def _foreach_concrete(cv: Value, name: str, body: S.Exp, env: Env, ctx: _Ctx) -> Distribution:
    """Evaluate foreach for a concrete collection value."""
    if not isinstance(cv, Multiset):
        raise EvalError("foreach requires a collection")
    if len(cv) == 0:
        return Distribution.certain(EMPTY)
    result = Distribution.certain(EMPTY)
    for elem in cv:
        elem_d = _dist(body, {**env, name: Multiset.single(elem)}, ctx)
        result = result.combine(elem_d, _union_vals)
    return result


def _dist_iterate(
    name: str,
    init_e: S.Exp,
    cond_e: S.Exp,
    is_while: bool,
    env: Env,
    ctx: _Ctx,
    *,
    accum: bool,
) -> Distribution:
    """Distribution for repeat/accumulate loops.

    Unrolls the loop up to max_iterations steps. At each step, for each
    possible value, splits into "stops here" and "continues" portions.
    """
    init_d = _dist(init_e, env, ctx)

    # For accum, we need to track (accumulated_value, current_value) pairs.
    # For repeat, we only care about the current value.
    # Simplification: unroll by iterating over concrete values via flat_map.

    if accum:
        return _dist_accum_unroll(name, init_e, cond_e, is_while, env, ctx, init_d)
    return _dist_repeat_unroll(name, init_e, cond_e, is_while, env, ctx, init_d)


def _dist_repeat_unroll(
    name: str,
    init_e: S.Exp,
    cond_e: S.Exp,
    is_while: bool,
    env: Env,
    ctx: _Ctx,
    current_d: Distribution,
) -> Distribution:
    """Unroll a repeat loop, returning distribution over the last value."""
    # For each possible current value, determine the probability of stopping.
    # If stopping, that value contributes to the result.
    # If continuing, re-evaluate init_e for the next iteration.
    result_pmf: dict[Value, Prob] = {}
    remaining = current_d

    for _ in range(ctx.max_iter):
        if remaining.is_empty():
            break

        # For each value in remaining, check condition
        stopped: dict[Value, Prob] = {}
        continued: dict[Value, Prob] = {}

        for v, p in remaining._pmf.items():
            cond_d = _dist(cond_e, {**env, name: v}, ctx)
            p_nonempty = cond_d.p_nonempty()
            p_continue = p_nonempty if is_while else (_one() - p_nonempty)
            p_stop = _one() - p_continue

            if p_stop > 0:
                stopped[v] = stopped.get(v, _zero()) + p * p_stop
            if p_continue > 0:
                continued[v] = continued.get(v, _zero()) + p * p_continue

        # Add stopped values to result
        for v, p in stopped.items():
            result_pmf[v] = result_pmf.get(v, _zero()) + p

        # For continued values, re-evaluate init to get next iteration's distribution
        if not continued:
            break
        p_cont_total = sum(continued.values())
        # Re-evaluate init_e (fresh roll each iteration)
        next_d = _dist(init_e, env, ctx)
        # Scale by total continuation probability
        remaining = Distribution({v: p * p_cont_total for v, p in next_d._pmf.items()})

    # Remaining probability after max_iter is truncation error — drop it.
    # This matches Troll's behavior: iterations beyond max_iterations are BOTTOM.
    # Renormalize so probabilities sum to 1.
    total = sum(result_pmf.values())
    if total > 0 and total != _one():
        result_pmf = {v: p / total for v, p in result_pmf.items()}

    return Distribution(result_pmf)


def _dist_accum_unroll(
    name: str,
    init_e: S.Exp,
    cond_e: S.Exp,
    is_while: bool,
    env: Env,
    ctx: _Ctx,
    init_d: Distribution,
) -> Distribution:
    """Unroll an accumulate loop, returning distribution over union of all values."""
    # Each iteration contributes its value to the accumulated result via union.
    # We flat_map over all possible sequences of values.

    # Simplified approach: track distribution over accumulated multisets.
    # Start with init_d as both current value and accumulated result.

    # For accumulate, the SML code returns
    #   foldr union [] (iterate values)
    # where iterate produces a list of all intermediate values.

    # Unroll: at each step, split into stop/continue.
    # Stopped: accumulated value is the result.
    # Continued: union current value with next iteration's result.

    result_pmf: dict[Value, Prob] = {}
    # State: list of (accumulated_value, current_value, probability)
    states: dict[tuple[Value, Value], Prob] = {}
    for v, p in init_d._pmf.items():
        states[(v, v)] = states.get((v, v), _zero()) + p

    for _ in range(ctx.max_iter):
        if not states:
            break

        new_states: dict[tuple[Value, Value], Prob] = {}

        for (acc, cur), p in states.items():
            cond_d = _dist(cond_e, {**env, name: cur}, ctx)
            p_nonempty = cond_d.p_nonempty()
            p_continue = p_nonempty if is_while else (_one() - p_nonempty)
            p_stop = _one() - p_continue

            if p_stop > 0:
                result_pmf[acc] = result_pmf.get(acc, _zero()) + p * p_stop

            if p_continue > 0:
                # Re-evaluate init for next value, union with accumulated
                next_d = _dist(init_e, env, ctx)
                for nv, np in next_d._pmf.items():
                    if isinstance(acc, Multiset) and isinstance(nv, Multiset):
                        new_acc = acc.union(nv)
                    else:
                        new_acc = nv
                    key = (new_acc, nv)
                    new_states[key] = new_states.get(key, _zero()) + p * p_continue * np

        states = new_states

    # Remaining states after max_iter are truncation error — drop them.
    # This matches Troll's behavior: iterations beyond max_iterations are BOTTOM.

    return Distribution(result_pmf)


def _dist_call(fname: str, arg_exps: list[S.Exp], env: Env, ctx: _Ctx) -> Distribution:
    """Evaluate a function call in distribution mode."""
    decl = ctx.decls.get(fname)
    if decl is None:
        raise EvalError(f"Unknown function: {fname}")

    if isinstance(decl, S.FuncDecl):
        # Compute distribution over each argument, then flat_map over all combinations
        arg_dists = [_dist(a, env, ctx) for a in arg_exps]
        if len(arg_dists) != len(decl.params):
            raise EvalError(f"Wrong number of arguments to {fname}")
        return _flat_map_args(arg_dists, decl.params, decl.body, ctx)

    if isinstance(decl, S.CompDecl):
        if len(arg_exps) != 1:
            raise EvalError(f"Compositional {fname} takes exactly 1 argument")
        return _dist(arg_exps[0], env, ctx).flat_map(lambda v: _dist_compositional(v, decl, ctx))

    raise EvalError(f"Unknown declaration type for {fname}")


def _dist_compositional(v: Value, decl: S.CompDecl, ctx: _Ctx) -> Distribution:
    """Evaluate a compositional declaration in distribution mode."""
    if not isinstance(v, Multiset):
        raise EvalError("Compositional argument must be a collection")
    items = list(v)
    if not items:
        return _dist(decl.empty, {}, ctx)
    result = _dist_call(decl.single, [S.Num(items[0])], {}, ctx)
    for x in items[1:]:
        elem = _dist_call(decl.single, [S.Num(x)], {}, ctx)
        result = result.combine(elem, lambda a, b: _call_binop(decl.union, a, b, ctx))
    return result


def _call_binop(fname: str, a: Value, b: Value, ctx: _Ctx) -> Value:
    """Call a binary function on two concrete values (for compositional).

    Only correct for deterministic combiners. Raises EvalError if the
    combiner function contains random-producing nodes (D, Z, Choose, etc.),
    which would require distribution-level evaluation instead of sampling.
    """
    import random as _rng

    from troll.sampling import _call_func

    # Check if the combiner function is stochastic
    decl = ctx.decls.get(fname)
    if isinstance(decl, S.FuncDecl) and _is_stochastic(decl.body):
        raise EvalError(
            f"Compositional combiner '{fname}' contains random operations "
            f"(dice rolls, choose, etc.) which is not supported in distribution mode. "
            f"Use a deterministic combiner function, or evaluate via sampling instead."
        )

    return _call_func(fname, [a, b], dict(ctx.decls), _rng.Random(0))


def _is_stochastic(exp: S.Exp) -> bool:
    """Check if an expression contains random-producing nodes."""
    match exp:
        case S.D() | S.Z() | S.Choose() | S.Pick() | S.Question():
            return True
        case S.Call():
            return True  # conservative: function calls might be random
        case _:
            # Recurse into children
            for attr in (
                "arg",
                "left",
                "right",
                "cond",
                "then_",
                "else_",
                "binding",
                "body",
                "init",
                "collection",
                "first",
                "second",
                "n",
                "count",
                "die",
            ):
                child = getattr(exp, attr, None)
                if isinstance(child, S.Exp) and _is_stochastic(child):
                    return True
            # Check args list (for Call nodes, though we already caught Call above)
            args = getattr(exp, "args", None)
            if isinstance(args, list):
                for a in args:
                    if isinstance(a, S.Exp) and _is_stochastic(a):
                        return True
            return False


def _flat_map_args(
    arg_dists: list[Distribution],
    params: list[str],
    body: S.Exp,
    ctx: _Ctx,
) -> Distribution:
    """Flat-map over all combinations of argument values."""
    if len(arg_dists) == 0:
        return _dist(body, {}, ctx)

    if len(arg_dists) == 1:
        return arg_dists[0].flat_map(lambda v: _dist(body, {params[0]: v}, ctx))

    # Multiple args: nest flat_maps
    def go(idx: int, bound: dict[str, Value]) -> Distribution:
        if idx >= len(arg_dists):
            return _dist(body, bound, ctx)
        return arg_dists[idx].flat_map(
            lambda v, i=idx, b=bound: go(i + 1, {**b, params[i]: v})  # type: ignore[misc]
        )

    return go(0, {})
