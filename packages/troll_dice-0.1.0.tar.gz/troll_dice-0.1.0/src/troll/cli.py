"""CLI for the Troll dice language parser and evaluator."""

from __future__ import annotations

import os as _os
import random as _random
import sys as _sys

import click as _click

from troll.distribution import distribute
from troll.lexer import LexError, tokenize
from troll.parser import ParseError, parse
from troll.sampling import sample, sample_n
from troll.syntax import show
from troll.values import EvalError, Multiset, PairVal, Value


def _format_value(v: Value) -> str:
    if isinstance(v, Multiset):
        return " ".join(str(x) for x in v) if v else "{}"
    if isinstance(v, PairVal):
        return f"[{_format_value(v.first)}, {_format_value(v.second)}]"
    return str(v)


@_click.command()
@_click.argument("input", required=False)
@_click.option("--ast", "show_ast", is_flag=True, help="Print raw AST (Python repr)")
@_click.option("--tokens", "show_tokens", is_flag=True, help="Print token stream")
@_click.option("--parse-only", is_flag=True, help="Parse and pretty-print (no evaluation)")
@_click.option("-s", "--sample", "do_sample", is_flag=True, help="Sample mode (random roll)")
@_click.option(
    "-n", "num_samples", type=int, default=0, help="Number of samples (0 = distribution)"
)
@_click.option("--seed", type=int, default=None, help="RNG seed for reproducibility")
@_click.option("--max-iter", type=int, default=12, help="Max loop iterations for distribution")
def main(
    input: str | None,
    show_ast: bool,
    show_tokens: bool,
    parse_only: bool,
    do_sample: bool,
    num_samples: int,
    seed: int | None,
    max_iter: int,
) -> None:
    """Troll dice language parser and evaluator.

    INPUT can be a filename (if it exists) or an inline expression.
    With no arguments, reads from stdin (or shows help if stdin is a TTY).

    \b
    Default mode computes the exact probability distribution.
    Use -s for a single random sample, or -n N for N samples.

    \b
    Examples:
      troll 'sum 2d6'                   # show probability distribution
      troll -s 'sum 2d6'                # roll once
      troll -n 10 'sum 2d6'             # roll 10 times
      troll --parse-only 'sum 2d6'      # just parse, show Troll syntax
      troll Troll/Examples/Risk.t        # evaluate a .t file
    """
    source = _read_source(input)
    if source is None:
        return

    try:
        if show_tokens:
            for tok in tokenize(source):
                _click.echo(tok)
            return

        program = parse(source)

        if show_ast:
            for d in program.declarations:
                _click.echo(repr(d))
            _click.echo(repr(program.expression))
            return

        if parse_only:
            _click.echo(show(program))
            return

        # Evaluation modes
        if do_sample or num_samples == 1:
            rng = _random.Random(seed)
            _click.echo(_format_value(sample(program, rng)))
            return

        if num_samples > 1:
            rng = _random.Random(seed)
            results = sample_n(program, num_samples, rng)
            for v in results:
                _click.echo(_format_value(v))
            return

        # Default: exact distribution
        dist = distribute(program, max_iterations=max_iter)
        _print_dist(dist)

    except (LexError, ParseError, EvalError) as e:
        _click.echo(f"Error: {e}", err=True)
        _sys.exit(1)


def _read_source(input: str | None) -> str | None:
    if input is not None:
        if _os.path.isfile(input):
            with open(input) as f:
                return f.read()
        return input
    if _sys.stdin.isatty():
        _click.echo(_click.get_current_context().get_help())
        return None
    source = _sys.stdin.read()
    if not source.strip():
        _click.echo(_click.get_current_context().get_help())
        return None
    return source


def _print_dist(dist: object) -> None:
    from troll.distribution import Distribution

    assert isinstance(dist, Distribution)
    # Filter out negligible probabilities (< 1e-10)
    items = [(v, p) for v, p in dist.items() if float(p) > 1e-10]
    if not items:
        _click.echo("(impossible)")
        return

    # Format value column
    val_strs = [_format_value(v) for v, _ in items]
    max_val_width = max(len(s) for s in val_strs)

    # Header
    _click.echo(f"{'Value':>{max_val_width}}   {'% =':>12}   {'% >=':>12}")

    # Cumulative >= probability
    cumulative = sum(p for _, p in items)

    for (_, p), vs in zip(items, val_strs, strict=True):
        pct = float(p) * 100
        cum_pct = float(cumulative) * 100
        _click.echo(f"{vs:>{max_val_width}} : {pct:>11.6f}%  {cum_pct:>11.6f}%")
        cumulative -= p

    # Statistics (only for singleton-int distributions)
    try:
        mean = dist.mean
        std = dist.std
        _click.echo(f"\nAverage = {mean:.6f}  Spread = {std:.6f}")
    except (EvalError, TypeError):
        pass


if __name__ == "__main__":
    main()
