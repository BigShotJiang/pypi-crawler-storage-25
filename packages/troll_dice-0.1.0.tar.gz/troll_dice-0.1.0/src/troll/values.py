"""Core value types for the Troll dice language runtime."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable


class Multiset:
    """A sorted multiset of integers — Troll's primary value type.

    Wraps a sorted tuple of ints. Hashable and comparable for use as
    distribution keys.
    """

    __slots__ = ("_items",)

    def __init__(self, items: Iterable[int] = ()) -> None:
        self._items = tuple(sorted(items))

    # -- Collection protocol --

    def __iter__(self):
        return iter(self._items)

    def __len__(self) -> int:
        return len(self._items)

    def __bool__(self) -> bool:
        return len(self._items) > 0

    def __getitem__(self, index: int) -> int:
        return self._items[index]

    # -- Equality, hashing, ordering --

    def __hash__(self) -> int:
        return hash(self._items)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Multiset):
            return self._items == other._items
        return NotImplemented

    def __lt__(self, other: object) -> bool:
        if isinstance(other, Multiset):
            return self._items < other._items
        return NotImplemented

    def __le__(self, other: object) -> bool:
        if isinstance(other, Multiset):
            return self._items <= other._items
        return NotImplemented

    def __repr__(self) -> str:
        return f"Multiset({list(self._items)})"

    # -- Numeric / Python operator overloads --
    # These make Multiset usable in Python arithmetic expressions.
    # Operations on singletons return singletons; sum/count return int.

    def __int__(self) -> int:
        """Convert singleton to int. Raises if not a singleton."""
        if len(self._items) == 1:
            return self._items[0]
        raise ValueError(f"Cannot convert non-singleton Multiset to int: {self!r}")

    def __float__(self) -> float:
        return float(int(self))

    def __add__(self, other: object) -> Multiset:
        if isinstance(other, Multiset):
            return Multiset.single(int(self) + int(other))
        if isinstance(other, int):
            return Multiset.single(int(self) + other)
        return NotImplemented

    def __radd__(self, other: object) -> Multiset:
        if isinstance(other, int):
            return Multiset.single(other + int(self))
        return NotImplemented

    def __sub__(self, other: object) -> Multiset:
        if isinstance(other, Multiset):
            return Multiset.single(int(self) - int(other))
        if isinstance(other, int):
            return Multiset.single(int(self) - other)
        return NotImplemented

    def __rsub__(self, other: object) -> Multiset:
        if isinstance(other, int):
            return Multiset.single(other - int(self))
        return NotImplemented

    def __mul__(self, other: object) -> Multiset:
        if isinstance(other, Multiset):
            return Multiset.single(int(self) * int(other))
        if isinstance(other, int):
            return Multiset.single(int(self) * other)
        return NotImplemented

    def __rmul__(self, other: object) -> Multiset:
        if isinstance(other, int):
            return Multiset.single(other * int(self))
        return NotImplemented

    def __floordiv__(self, other: object) -> Multiset:
        if isinstance(other, Multiset):
            return Multiset.single(int(self) // int(other))
        if isinstance(other, int):
            return Multiset.single(int(self) // other)
        return NotImplemented

    def __mod__(self, other: object) -> Multiset:
        if isinstance(other, Multiset):
            return Multiset.single(int(self) % int(other))
        if isinstance(other, int):
            return Multiset.single(int(self) % other)
        return NotImplemented

    def __neg__(self) -> Multiset:
        return Multiset.single(-int(self))

    def __abs__(self) -> Multiset:
        return Multiset.single(abs(int(self)))

    def __or__(self, other: Multiset) -> Multiset:
        """Union operator: {1,2} | {3,4} → {1,2,3,4}."""
        if isinstance(other, Multiset):
            return self.union(other)
        return NotImplemented

    # -- Multiset operations (all return new Multiset) --

    def union(self, other: Multiset) -> Multiset:
        """Merge two sorted multisets, maintaining sort order."""
        result: list[int] = []
        a, b = self._items, other._items
        i, j = 0, 0
        while i < len(a) and j < len(b):
            if a[i] <= b[j]:
                result.append(a[i])
                i += 1
            else:
                result.append(b[j])
                j += 1
        result.extend(a[i:])
        result.extend(b[j:])
        ms = Multiset.__new__(Multiset)
        ms._items = tuple(result)
        return ms

    def sum_(self) -> int:
        return sum(self._items)

    def count(self) -> int:
        return len(self._items)

    def least(self, n: int) -> Multiset:
        """Take the n smallest elements (already sorted)."""
        if n >= len(self._items):
            return self
        ms = Multiset.__new__(Multiset)
        ms._items = self._items[:n]
        return ms

    def largest(self, n: int) -> Multiset:
        """Take the n largest elements."""
        if n >= len(self._items):
            return self
        ms = Multiset.__new__(Multiset)
        ms._items = self._items[len(self._items) - n :]
        return ms

    def minimal(self) -> Multiset:
        """All copies of the smallest element."""
        if not self._items:
            return self
        lo = self._items[0]
        return Multiset(x for x in self._items if x == lo)

    def maximal(self) -> Multiset:
        """All copies of the largest element."""
        if not self._items:
            return self
        hi = self._items[-1]
        return Multiset(x for x in self._items if x == hi)

    def median(self) -> int:
        """Median element (middle of sorted items)."""
        return self._items[len(self._items) // 2]

    def different(self) -> Multiset:
        """Remove duplicates, preserving sort order."""
        ms = Multiset.__new__(Multiset)
        ms._items = tuple(dict.fromkeys(self._items))
        return ms

    def drop(self, other: Multiset) -> Multiset:
        """Keep elements NOT in other (membership filter)."""
        other_set = set(other._items)
        return Multiset(x for x in self._items if x not in other_set)

    def keep(self, other: Multiset) -> Multiset:
        """Keep elements that ARE in other (membership filter)."""
        other_set = set(other._items)
        return Multiset(x for x in self._items if x in other_set)

    def set_minus(self, other: Multiset) -> Multiset:
        """Multiset subtraction (remove one copy per match)."""
        remaining = list(other._items)
        result: list[int] = []
        for x in self._items:
            if x in remaining:
                remaining.remove(x)
            else:
                result.append(x)
        ms = Multiset.__new__(Multiset)
        ms._items = tuple(result)
        return ms

    def filter_eq(self, n: int) -> Multiset:
        return Multiset(x for x in self._items if x == n)

    def filter_neq(self, n: int) -> Multiset:
        return Multiset(x for x in self._items if x != n)

    def filter_lt(self, n: int) -> Multiset:
        """Elements x where n < x (i.e., x > n)."""
        return Multiset(x for x in self._items if x > n)

    def filter_gt(self, n: int) -> Multiset:
        """Elements x where n > x (i.e., x < n)."""
        return Multiset(x for x in self._items if x < n)

    def filter_le(self, n: int) -> Multiset:
        """Elements x where n <= x."""
        return Multiset(x for x in self._items if x >= n)

    def filter_ge(self, n: int) -> Multiset:
        """Elements x where n >= x."""
        return Multiset(x for x in self._items if x <= n)

    @classmethod
    def from_to(cls, low: int, high: int) -> Multiset:
        return cls(range(low, high + 1))

    @classmethod
    def single(cls, n: int) -> Multiset:
        ms = cls.__new__(cls)
        ms._items = (n,)
        return ms


EMPTY = Multiset()


@dataclass(frozen=True, order=True)
class PairVal:
    """A pair of values."""

    first: Value
    second: Value


Value = Multiset | PairVal | str


class EvalError(Exception):
    """Runtime evaluation error, optionally with source position."""

    def __init__(self, msg: str, pos: tuple[int, int] = (0, 0)) -> None:
        self.pos = pos
        full = f"line {pos[0]}, col {pos[1]}: {msg}" if pos != (0, 0) else msg
        super().__init__(full)


def _pos_str(pos: tuple[int, int]) -> str:
    if pos != (0, 0):
        return f" (line {pos[0]}, col {pos[1]})"
    return ""


def as_int(v: Value, pos: tuple[int, int] = (0, 0)) -> int:
    """Extract the single integer from a singleton Multiset."""
    if isinstance(v, Multiset) and len(v) == 1:
        return v[0]
    if isinstance(v, Multiset) and len(v) > 1:
        raise EvalError(
            f"Arithmetic requires a single number, got {len(v)}-element collection {v!r}. "
            f"Use 'sum' to total, 'count' to count, or 'max'/'min' to pick one.",
            pos,
        )
    raise EvalError(f"Expected singleton integer, got {v!r}", pos)
