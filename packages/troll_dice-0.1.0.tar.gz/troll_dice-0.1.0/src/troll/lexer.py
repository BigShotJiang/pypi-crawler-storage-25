"""Tokenizer for the Troll dice language."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class TT(Enum):
    """Token types."""

    # Literals
    NUM = auto()
    REAL = auto()
    ID = auto()
    STRING = auto()
    # Keywords
    D = auto()
    Z = auto()
    SUM = auto()
    SGN = auto()
    MOD = auto()
    LEAST = auto()
    LARGEST = auto()
    COUNT = auto()
    DROP = auto()
    KEEP = auto()
    PICK = auto()
    MEDIAN = auto()
    LET = auto()
    IN = auto()
    REPEAT = auto()
    ACCUM = auto()
    WHILE = auto()
    UNTIL = auto()
    FOREACH = auto()
    DO = auto()
    IF = auto()
    THEN = auto()
    ELSE = auto()
    MIN = auto()
    MAX = auto()
    MINIMAL = auto()
    MAXIMAL = auto()
    CHOOSE = auto()
    DIFFERENT = auto()
    FUNCTION = auto()
    CALL = auto()
    COMPOSITIONAL = auto()
    # Symbols
    PLUS = auto()
    MINUS = auto()
    TIMES = auto()
    DIVIDE = auto()
    LPAR = auto()
    RPAR = auto()
    LBRACE = auto()
    RBRACE = auto()
    LBRACK = auto()
    RBRACK = auto()
    COMMA = auto()
    SEMI = auto()
    ASSGN = auto()
    EQ = auto()
    NEQ = auto()
    LT = auto()
    GT = auto()
    LE = auto()
    GE = auto()
    DOTDOT = auto()
    CONC = auto()
    AND = auto()
    HASH = auto()
    QUESTION = auto()
    HCONC = auto()
    VCONCL = auto()
    VCONCR = auto()
    VCONCC = auto()
    SAMPLE = auto()
    FIRST = auto()
    SECOND = auto()
    TILDE = auto()
    BANG = auto()
    SETMINUS = auto()
    EOF = auto()


KEYWORDS: dict[str, TT] = {
    "D": TT.D,
    "d": TT.D,
    "Z": TT.Z,
    "z": TT.Z,
    "U": TT.CONC,
    "sum": TT.SUM,
    "sgn": TT.SGN,
    "mod": TT.MOD,
    "least": TT.LEAST,
    "largest": TT.LARGEST,
    "count": TT.COUNT,
    "drop": TT.DROP,
    "keep": TT.KEEP,
    "pick": TT.PICK,
    "median": TT.MEDIAN,
    "let": TT.LET,
    "in": TT.IN,
    "repeat": TT.REPEAT,
    "accumulate": TT.ACCUM,
    "while": TT.WHILE,
    "until": TT.UNTIL,
    "foreach": TT.FOREACH,
    "do": TT.DO,
    "if": TT.IF,
    "then": TT.THEN,
    "else": TT.ELSE,
    "min": TT.MIN,
    "max": TT.MAX,
    "minimal": TT.MINIMAL,
    "maximal": TT.MAXIMAL,
    "choose": TT.CHOOSE,
    "different": TT.DIFFERENT,
    "function": TT.FUNCTION,
    "call": TT.CALL,
    "compositional": TT.COMPOSITIONAL,
}


@dataclass
class Token:
    type: TT
    value: int | float | str | None
    line: int
    col: int

    def __repr__(self):
        if self.value is not None:
            return f"{self.type.name}({self.value!r})"
        return self.type.name


class LexError(Exception):
    def __init__(self, msg: str, line: int, col: int):
        super().__init__(f"Lexical error at line {line}, column {col}: {msg}")
        self.line = line
        self.col = col


def tokenize(source: str) -> list[Token]:
    """Tokenize a Troll program source string."""
    tokens: list[Token] = []
    i = 0
    line = 1
    line_start = 0

    def col():
        return i - line_start + 1

    def peek(offset=0):
        j = i + offset
        return source[j] if j < len(source) else ""

    def err(msg):
        raise LexError(msg, line, col())

    def tok(tt, val=None, width=1):
        nonlocal i
        tokens.append(Token(tt, val, line, col()))
        i += width

    n = len(source)
    while i < n:
        ch = source[i]

        # Whitespace
        if ch in " \t\r":
            i += 1
            continue
        if ch == "\n" or ch == "\f":
            i += 1
            line += 1
            line_start = i
            continue

        # Comment: \ to end of line
        if ch == "\\":
            while i < n and source[i] != "\n":
                i += 1
            continue

        # Number or real: [0-9]+ or 0.[0-9]+
        if ch.isdigit():
            start = i
            start_col = col()
            while i < n and source[i].isdigit():
                i += 1
            if (
                source[start:i] == "0"
                and i < n
                and source[i] == "."
                and i + 1 < n
                and source[i + 1].isdigit()
            ):
                i += 1  # skip .
                while i < n and source[i].isdigit():
                    i += 1
                tokens.append(Token(TT.REAL, float(source[start:i]), line, start_col))
            else:
                tokens.append(Token(TT.NUM, int(source[start:i]), line, start_col))
            continue

        # Identifier / keyword: [a-zA-Z]+
        if ch.isalpha():
            start = i
            start_col = col()
            while i < n and source[i].isalpha():
                i += 1
            word = source[start:i]
            tt = KEYWORDS.get(word, TT.ID)
            tokens.append(Token(tt, word, line, start_col))
            continue

        # String: "..."
        if ch == '"':
            start_col = col()
            i += 1  # skip opening "
            parts: list[str] = []
            while i < n and source[i] != '"':
                parts.append(source[i])
                i += 1
            if i >= n:
                err("Unterminated string")
            i += 1  # skip closing "
            tokens.append(Token(TT.STRING, "".join(parts), line, start_col))
            continue

        # Multi-character symbols (order matters: longest match first)
        two = source[i : i + 2] if i + 1 < n else ""
        three = source[i : i + 3] if i + 2 < n else ""

        if three == "=/=":
            tok(TT.NEQ, width=3)
            continue
        if two == ":=":
            tok(TT.ASSGN, width=2)
            continue
        if two == "--":
            tok(TT.SETMINUS, width=2)
            continue
        if two == "<=":
            tok(TT.LE, width=2)
            continue
        if two == ">=":
            tok(TT.GE, width=2)
            continue
        if two == "..":
            tok(TT.DOTDOT, width=2)
            continue
        if two == "||":
            tok(TT.HCONC, width=2)
            continue
        if two == "|>":
            tok(TT.VCONCL, width=2)
            continue
        if two == "<|":
            tok(TT.VCONCR, width=2)
            continue
        if two == "<>":
            tok(TT.VCONCC, width=2)
            continue
        if two == "%1":
            tok(TT.FIRST, width=2)
            continue
        if two == "%2":
            tok(TT.SECOND, width=2)
            continue

        # Single-character symbols
        match ch:
            case "+":
                tok(TT.PLUS)
            case "-":
                tok(TT.MINUS)
            case "*":
                tok(TT.TIMES)
            case "/":
                tok(TT.DIVIDE)
            case "(":
                tok(TT.LPAR)
            case ")":
                tok(TT.RPAR)
            case "{":
                tok(TT.LBRACE)
            case "}":
                tok(TT.RBRACE)
            case "[":
                tok(TT.LBRACK)
            case "]":
                tok(TT.RBRACK)
            case ",":
                tok(TT.COMMA)
            case ";":
                tok(TT.SEMI)
            case "=":
                tok(TT.EQ)
            case "<":
                tok(TT.LT)
            case ">":
                tok(TT.GT)
            case "@":
                tok(TT.CONC)
            case "&":
                tok(TT.AND)
            case "#":
                tok(TT.HASH)
            case "?":
                tok(TT.QUESTION)
            case "'":
                tok(TT.SAMPLE)
            case "~":
                tok(TT.TILDE)
            case "!":
                tok(TT.BANG)
            case _:
                err(f"Unexpected character: {ch!r}")

    tokens.append(Token(TT.EOF, None, line, col()))
    return tokens
