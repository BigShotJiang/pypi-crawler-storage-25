# -*- coding: utf-8 -*-

"""
load_player_information
=======================

mekk.fics example code - how to connect to FICS and grab some information.

This client grabs (and displays on the screen) some information
(rating, finger) of player specified as script argument.

Running this script
--------------------

Running this script (note that mekk.fics must be installed):

    python load_player_information.py PlayerNick PlayerNick2 ...

To get (plenty of) debugging info, add --debug

    python load_player_information.py --debug PlayerNick

To check what happens when sth is wrong, try mixing good and bad params like:

    python load_player_information.py Mekk NoSuchPlayer Chessty 1234

Comments about the code
------------------------

mekk.fics uses Twisted (http://twistedmatrix.com) to handle
network communication. As this is asynchronous library, it requires
slightly specific way of writing the code. In particular this means
that:

1. Many methods of mekk.fics return deferreds (twisted.internet.defer.Deferred objects)
   instead of actual replies. Those mean that intended action was not
   yet executed, but will be sooner or later, and deferreds allow one
   to set callbacks which will be fired once the result is ready.

   Lowlevel deferred processing is not too hard (one just dfr.addCallback(result_handling_method)
   and dfr.addErrback(error_processing_method) whenever deferreds are in place), but the code
   lacks some readability. Fortunately, inlineCallbacks trick resolves this problem. In
   functions/methods decorated with @defer.inlineCallbacks, every line like (note keyword yield)

       something = yield deferred

   means “wait for deferred to be fired, then assign it's result to variable something
   and continue” (internally it uses smart generator tricks). Moreover, we can handle
   errors with try/catch instead of adding errbacks.

   Whole routine wrapped in this way also returns deferred (and if there is a result, it must
   be returned via defer.returnValue, not via return), but apart from that the code “looks normal”.
   See http://blog.mekk.waw.pl/archives/14-Twisted-inlineCallbacks-and-deferredGenerator.html
   for some more detail.

2. Whole program must be managed by Twisted reactor, what in practice means a couple
   of standard final lines (setting up necessary objects and calling reactor.start())
   and finishing the program via reactor.stop.

3. mekk.fics itself uses „client” object to wrap the actual code. There one provide
   methods to handle all kind of FICS notifications bot or client needs to handle.
   In case of one-shot client, as this one, actual processing happens inside on_login
   method (called once we are logged in).

"""
from __future__ import print_function
import logging
import sys
import getopt
from twisted.internet import defer, reactor
from mekk.fics import FicsClient, FicsFactory, errors

#################################################################################
# Configuration
#################################################################################

from mekk.fics import FICS_HOST, FICS_PORT
import six

# Test via proxy
# FICS_HOST = 'localhost'

FICS_USER = 'guest'
FICS_PASSWORD = ''

FINGER_TEXT = """mekk.fics example code: load_player_information.py.
See http://bitbucket.org/Mekk/mekk.fics/ for more information."""

# Print also finger notes of checked players (set to false to make
# screen output shorter)
SHOW_FINGER_NOTES = True


#################################################################################
# Actual client/bot code
#################################################################################

class MyFicsClient(FicsClient):
    """
    Example client object
    """

    def __init__(self, checked_players):
        super(MyFicsClient, self).__init__(label="My connection")
        self.checked_players = checked_players

    @defer.inlineCallbacks
    def on_login(self, user):
        """
        This is routine called by mekk.fics once we are succesfully logged-in to the
        FICS. It should be used to configure the account (if necessary). As our bot
        does not respond to FICS events, but just has a few things to do, we also
        use this place to perform our processing.
        """
        print("\n!!! We are logged to FICS as %s" % user)

        # It is good habit to provide some finger for running bot. So we set one.
        # We also yield the deferred obtained so we wait for the configuration to
        # be ready before continuing (in case of finger it is not important,
        # but sometimes may be useful)
        yield self.set_finger(FINGER_TEXT)

        # Running actual code (there are three equivalent versions to illustrate
        # different ways of writing with mekk.fics and Twisted). Here also
        # we sync on finished code (not caring for the results) - otherwise
        # reactor.stop below would execute before replies are ready.
        yield self.check_fingers_1()

        yield self.check_fingers_2()

        yield self.check_fingers_3()

        # Not strictly necessary, but politely disconnecting will save us some warning in logs.
        print("!!! Waiting for disconnect")
        yield self.disconnect()

        print("!!! Stopping the program")
        # Twisted way of exiting the program. Don't do it in such a place if many
        # independend factories work simultaneously.
        reactor.stop()       # pylint:disable=no-member

    # Many more events (for example, reacting to someone tell, to games, seeks, etc etc)
    # can be handled here too. See other samples.

    @defer.inlineCallbacks
    def check_fingers_1(self):
        """
        Simplest to read implementation. We sequentially finger for all
        players we need.

        run_command is a general gateway to FICS commands (there are also
        some wrappers, but we do not use them here). It returns deferred
        fired with the command result. mekk.fics parses the result of (more important)
        commands, giving them as Python structures.
        """
        for player in self.checked_players:
            print("\n>>> check_fingers_1: querying for %s" % player)
            try:
                info = yield self.run_command("finger %s" % player)
                self.print_player(info, "check_fingers_1")
            except errors.UnknownPlayer:
                print("\n<<< check_fingers_1: Unknown player: %s" % player)
            except Exception as err:
                print("\n<<< check_fingers_1: Query for %s unexpectedly failed: %s" % (player, str(err)))

    @defer.inlineCallbacks
    def check_fingers_2(self):
        """
        Slightly faster alternative (we don't process players sequentially but
        issue all commands and only then wait for results). So FICS may be processing
        next questions while first reply is still travelling back over the net to us.
        """
        print("\n>>> check_fingers_2: querying for %s" % ", ".join(self.checked_players))
        deferreds = [ self.run_command("finger %s" % player)
                      for player in self.checked_players ]
        # We spawned all commands, now let's wait for replies and process them in order
        for dfr in deferreds:
            try:
                info = yield dfr
                self.print_player(info, "check_fingers_2")
            except errors.UnknownPlayer as err:
                print("\n<<< check_fingers_2: Unknown player: %s" % err.player_name)
            except Exception as err:
                # To know which player failed we would need to save deferred-player mapping
                print("\n<<< check_fingers_2: Query unexpectedly failed: %s" % (str(err)))

    def check_fingers_3(self):
        """
        Implementation without inlineCallbacks - in traditional
        Twisted style. Performance-wise similar to check_fingers_2,
        but replies need not be processed in order the commands were
        issued.

        Note that all_deferreds (and saving deferreds as such) is
        needed only because we intend to return “something” fired only
        once all our processing is done (our on_login closes the
        program them). We don't need this list to process the results.
        """

        # Twistedish style of embedded subroutine. This is equivalent of the catch block above
        def handle_error(failure, player):
            # failure is twisted.python.failure.Failure object. failure.value is oryginal exception,
            # apart from that failure has own useful methods, see pydoc twisted.python.failure.Failure
            if failure.check(errors.UnknownPlayer):
                print("\n<<< check_fingers_3: Unknown player: %s" % player)
            else:
                print("\n<<< check_fingers_3: Query for %s unexpectedly failed: %s" % (player, failure.getErrorMessage()))

        all_deferreds = []
        for player in self.checked_players:
            print("\n>>> check_fingers_3 - querying for %s" % player)
            dfr = self.run_command("finger %s" % player)
            # Bind callback which will be executed as soon as reply is ready. "check_finger_3" illustrates
            # how to add extra callback param(s).
            dfr.addCallback(self.print_player, "check_fingers_3")
            # Bind error processing
            dfr.addErrback(handle_error, player)
            # Save deferred to sync.
            all_deferreds.append(dfr)
        # Actual return values are not important here, but this will fire once all commands are processed
        return defer.DeferredList(all_deferreds)

    def print_player(self, finger_info, label):
        """
        Printing the player detail. mekk.fics parses finger output and extracts most important fields.
        See docstring of `mekk.fics.parsing.info_parser.parse_fics_reply` for details of what is returned.
        """
        # This also works and let's one quickly check what is inside:
        # print(info)
        print("\n<<< %s: Info about %s" % (label, finger_info.name))
        print("Ratings:")
        for game_variant, game_results in six.iteritems(finger_info.results):
            print("    %s: rating %d (rd %s), %d wins, %d draws, %d losses" % (
                game_variant, game_results.rating.value, str(game_results.rating.rd),
                game_results.wins_count, game_results.draws_count, game_results.losses_count))
        if SHOW_FINGER_NOTES:
            print("Finger notes:")
            for finger_line in finger_info.plan:
                print("    %s" % finger_line)

#################################################################################
# Script argument processing
#################################################################################

options, players = getopt.getopt(args = sys.argv[1:], shortopts=[], longopts=["debug"])
if not players:
    print("Usage: ")
    print("     python load_player_information.py player [player] [player] ...")
    sys.exit(1)

if "--debug" in [name for name,_ in options]:
    logging_level = logging.DEBUG
else:
    logging_level = logging.WARN

# mekk.fics uses logging module to record a lot of information about processing,
# including transcript of network I/O and command management logic. Especially
# during development it can be useful.
logging.basicConfig(level=logging_level)

#################################################################################
# Startup glue code
#################################################################################

my_client = MyFicsClient(players)
reactor.connectTCP(
    FICS_HOST, FICS_PORT,
    FicsFactory(client=my_client,
        auth_username=FICS_USER, auth_password=FICS_PASSWORD)
)
reactor.run()


