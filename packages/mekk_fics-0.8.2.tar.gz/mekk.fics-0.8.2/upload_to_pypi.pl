#!/usr/bin/perl -w

use Modern::Perl;
use Path::Tiny;

unless (@ARGV == 1) {
  die "Podaj jeden rgument (nazwe pliku dist/costam).\n";
}

my $name = path(shift);
unless ($name =~ m{dist/.*\.tar\.gz}) {
  die "Parametr nie wyglada poprawnie. Oczekiwane dist/costam...tar.gz\n";
}



# python3 setup.py sdist

