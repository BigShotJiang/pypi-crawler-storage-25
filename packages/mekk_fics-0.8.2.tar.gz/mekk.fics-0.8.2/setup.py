# -*- coding: utf-8 -*-

"""
mekk.fics setup
"""

import os
import sys
from setuptools import setup, find_packages

VERSION = ''   # Nadpisane poniższym
exec(open(os.path.join(os.path.dirname(__file__), "src", "mekk", "fics", "version.py")).read())

LONG_DESCRIPTION = open("README.txt").read()

CLASSIFIERS = [
    "Programming Language :: Python :: 2",
    "Programming Language :: Python :: 3",
    "Intended Audience :: Developers",
    "Topic :: Software Development :: Libraries :: Python Modules",
    "License :: OSI Approved :: Mozilla Public License 1.1 (MPL 1.1)",
    "License :: OSI Approved :: Artistic License",
    "Development Status :: 4 - Beta",
    "Intended Audience :: Developers",
    "Operating System :: OS Independent",
]

REQUIRES = [
    'six>=1.4.1',
]
if sys.version_info < (2, 7, 0):
    REQUIRES.append('ordereddict')
if sys.version_info > (3, 0, 0):
    REQUIRES.append('Twisted>=13.2.0')
else:
    REQUIRES.append('Twisted')

setup(name='mekk.fics',
      version=VERSION,
      description="FICS client library.",
      long_description=LONG_DESCRIPTION,
      classifiers=CLASSIFIERS,
      keywords='FICS, chess',
      author='Marcin Kasperski',
      author_email='Marcin.Kasperski@mekk.waw.pl',
      # url='http://bitbucket.org/Mekk/mekk.fics/',
      license='Artistic',
      package_dir={'': 'src'},
      packages=find_packages('src', exclude=['ez_setup', 'examples', 'tests']),
      namespace_packages=['mekk'],
      test_suite='nose.collector',
      include_package_data=True,
      zip_safe=False,
      install_requires=REQUIRES,
      tests_require=[
          'nose',
          'dict_compare',
      ])
