((python-mode
  (flycheck-python-flake8-executable . "/home/marcink/.virtualenvs/watchbot/bin/python")
  (flycheck-python-pylint-executable . "/home/marcink/.virtualenvs/watchbot/bin/python")
  ))
