# -*- coding: utf-8 -*-

"""
Channel info
"""

from collections import namedtuple


class ChannelRef(namedtuple("ChannelRef", "channel")):
    """
    Representation of channel number:

    - channel (int) - the number
    """
    pass
