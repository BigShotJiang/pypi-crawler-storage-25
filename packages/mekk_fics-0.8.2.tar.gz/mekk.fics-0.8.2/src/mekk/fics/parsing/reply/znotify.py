# -*- coding: utf-8 -*-

"""
Parsing znotify
"""

import re
from mekk.fics import errors
from mekk.fics.datatypes import ZnotifyInfo, IdleInfo, PlayerName


_RE_TRACKED_EMPTY = re.compile(
    r"^No one from your notify list is logged on")

_RE_TRACKED_NON_EMPTY = re.compile(
    r"Present company on your notify list:")

_RE_TRACKING_EMPTY = re.compile(
    r"^No one logged in has you on their notify list")

_RE_TRACKING_NON_EMPTY = re.compile(
    r"The following players have you on their notify list")

_RE_PLAYER_LINE = re.compile(r"^ \s \s \s+ .* $", re.VERBOSE)
_RE_PLAYER = re.compile(
    r"""^
    (?P<name>[a-zA-Z0-9_]+)
    (?: [(] idle: (?P<idle>\d+) m [)] )?
    $""", re.VERBOSE)


def _parse_player_names(line, full_text):
    items = line.strip(" \n").split(" ")
    result = []
    for item in items:
        mtch = _RE_PLAYER.search(item)
        if mtch:
            result.append(IdleInfo(
                name=PlayerName(mtch.group('name')),
                idle=60 * int(mtch.group('idle') or 0)))
    return result


def parse_znotify_reply(reply_text):
    """
    Parses complete znotify reply

    :param reply_text: reply text (multiline)
    :return: ZnotifyInfo object
    """
    tracked = []
    tracking = []

    lines = [line for line in reply_text.split("\n") if line]

    curr_ln = lines.pop(0)
    if _RE_TRACKED_NON_EMPTY.search(curr_ln):
        while lines and _RE_PLAYER_LINE.search(lines[0]):
            tracked.extend(_parse_player_names(lines.pop(0), reply_text))
    elif _RE_TRACKED_EMPTY.search(curr_ln):
        pass
    else:
        raise errors.ReplyParsingException(reply_text, "znotify")

    curr_ln = lines.pop(0)
    if _RE_TRACKING_NON_EMPTY.search(curr_ln):
        while lines and _RE_PLAYER_LINE.search(lines[0]):
            tracking.extend(_parse_player_names(lines.pop(0), reply_text))
    elif _RE_TRACKING_EMPTY.search(curr_ln):
        pass
    else:
        raise errors.ReplyParsingException(reply_text, "znotify")

    return ZnotifyInfo(tracked=tracked, tracking=tracking)
