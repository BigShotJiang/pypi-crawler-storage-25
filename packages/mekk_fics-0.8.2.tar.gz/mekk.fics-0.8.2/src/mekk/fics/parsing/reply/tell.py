# -*- coding: utf-8 -*-

"""
Prasing tell results.
"""

import re
from mekk.fics.datatypes.generic import GenericText
from mekk.fics import errors


_RE_REGISTERED_REQUIRED = re.compile(r'''
    ^Only\sregistered\susers\smay\ssend\stells
    ''', re.VERBOSE)


def parse_tell_reply(reply_text):
    """
    Parse result of telling sh.
    :param reply_text: FICS results
    """
    if _RE_REGISTERED_REQUIRED.search(reply_text):
        raise errors.TrueAccountRequired(reply_text)
    # TODO: check for all positive cases (told XXX etc), throw or warn
    # on the rest.
    return GenericText(reply_text.strip("\r\n "))
