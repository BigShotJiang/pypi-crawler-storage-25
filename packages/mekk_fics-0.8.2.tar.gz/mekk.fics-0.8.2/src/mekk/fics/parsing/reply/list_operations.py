# -*- coding: utf-8 -*-

"""
Parsing channel, player etc lists.
"""

import re
from mekk.fics import errors
from mekk.fics.datatypes.list_items import ListContents
from mekk.fics.datatypes.player import PlayerName

# -- channel list: 2 channels --
# 4   53
#  (items can be multiline if there are m# -- channel list: 2 channels --
# 4   53
#  (items can be multiline if there are many)

_RE_SHOWLIST = re.compile(r'''
\A
\s*--\s*
(?P<name>\w+)
\s+
list:
\s+(?P<count>\d+)\s+[^\-]*
\s*--\s*
(?P<items>.*)
\Z
''', re.VERBOSE + re.DOTALL)

_RE_LIST_SPLIT = re.compile(r'[\s\r\n]+')

_RE_LIST_ERROR = re.compile(r'"(?P<list>\w+)" does not match any list name\.')


def parse_showlist_reply(reply_text):
    """Rozparsowanie wyniku showlist"""
    mtch = _RE_SHOWLIST.match(reply_text)
    if mtch:
        name = mtch.group('name')
        items = _RE_LIST_SPLIT.split(mtch.group('items').strip(" \r\n"))
        if items and items[-1] == '':  # split('') -> ['']
            items.pop(-1)
        return ListContents(name=name, items=items)
    mtch = _RE_LIST_ERROR.match(reply_text)
    if mtch:
        raise errors.UnknownList(mtch.group('list'))
    else:
        raise errors.ReplyParsingException(reply_text, "showlist")


_RE_HANDLES = re.compile(r'''
\A
\s*--\s*
Matches:\s*
(?P<count>\d+)\s+[^\-]*
\s*--\s*
(?P<items>.*)
\Z
''', re.VERBOSE + re.DOTALL)

_RE_HANDLES_ERROR_SYNTAX = re.compile(r"'(?P<name>[^']+)' is not a valid handle\.")
_RE_HANDLES_ERROR_MISSING = re.compile(r'^There is no player matching the name (?P<name>\w+)')


def parse_handles_reply(reply_text):
    """Rozparsowanie wyniku handles"""
    mtch = _RE_HANDLES.match(reply_text)
    if mtch:
        items = _RE_LIST_SPLIT.split(mtch.group('items').strip(" \r\n"))
        if items and items[-1] == '':  # split('') -> ['']
            items.pop(-1)
        return ListContents(name="handles", items=[PlayerName(item) for item in items])
    mtch = _RE_HANDLES_ERROR_MISSING.match(reply_text)
    if mtch:
        raise errors.UnknownPlayer(mtch.group('name'))
    mtch = _RE_HANDLES_ERROR_SYNTAX.match(reply_text)
    if mtch:
        raise errors.UnknownPlayer(mtch.group('name'))
    raise errors.ReplyParsingException(reply_text, "handles")

