# -*- coding: utf-8 -*-

"""
List-related parsing.
"""

import re
from mekk.fics import errors
from mekk.fics.datatypes.channel import ChannelRef
from mekk.fics.datatypes.player import PlayerName

_RE_PLUS_CHANNEL = re.compile(
    r'^\[(?P<no>\d+)\] added to your channel list')
_RE_PLUS_NOTIFY = re.compile(
    r'^\[(?P<who>\S+)\] added to your (notify|gnotify) list')

_RE_MINUS_CHANNEL = re.compile(
    r'^\[(?P<no>\d+)\] removed from your channel list')
_RE_MINUS_NOTIFY = re.compile(
    r'^\[(?P<who>\S+)\] removed from your (notify|gnotify) list')

_RE_ERR_ALREADY = re.compile(
    r'\[(?P<item>[\dA-Za-z_]+)\] is already on your (?P<list>channel|notify|gnotify) list')
_RE_ERR_MISSING = re.compile(
    r'\[(?P<item>[\dA-Za-z_]+)\] is not in your (?P<list>channel|notify|gnotify) list')


def parse_addlist_reply(reply_text):
    """
    Parse reply to +chan, +notify etc.

    :param reply_text: FICS reply
    :type reply_text: str
    """
    # TODO: mayhaps return also list name (channel, notify, gnotify…)?
    mtch = _RE_PLUS_CHANNEL.search(reply_text)
    if mtch:
        return ChannelRef(int(mtch.group('no')))
    mtch = _RE_PLUS_NOTIFY.search(reply_text)
    if mtch:
        return PlayerName(mtch.group('who'))
    mtch = _RE_ERR_ALREADY.search(reply_text)
    if mtch:
        raise errors.AlreadyOnList(mtch.group('item'), mtch.group('list'))
    return None


def parse_sublist_reply(reply_text):
    """
    Parse reply to -chan, -notify etc.

    :param reply_text: FICS reply
    :type reply_text: str
    """
    mtch = _RE_MINUS_CHANNEL.search(reply_text)
    if mtch:
        return ChannelRef(int(mtch.group('no')))
    mtch = _RE_MINUS_NOTIFY.search(reply_text)
    if mtch:
        return PlayerName(mtch.group('who'))
    mtch = _RE_ERR_MISSING.search(reply_text)
    if mtch:
        raise errors.NotOnList(mtch.group('item'), mtch.group('list'))

    return None
