# -*- coding: utf-8 -*-

"""
Parsing seek info.
"""

import re
import logging
from mekk.fics.datatypes.notifications import SeekRef, Seek
# from mekk.fics.datatypes.generic import UnknownReply
from mekk.fics.datatypes.game_clock import GameClock
from mekk.fics.datatypes.player import PlayerName
from mekk.fics.datatypes.game_info import GameSpec
from mekk.fics.datatypes.game_type import GameType
from mekk.fics.datatypes.color import Color
from mekk.fics.parsing.common import rated_as_bool, numeric_rank
from mekk.fics import errors

# pylint:disable=line-too-long


log = logging.getLogger("fics")   # pylint:disable=invalid-name

_RE_PROPER_SEEKS = [
    re.compile(regexp)
    for regexp in [
        r'^Your seek has been posted with index (?P<seek_no>\d+)\.',
        r'^Updating seek ad (?P<seek_no>\d+);',
    ]]

# TODO: więcej
_RE_BAD_SEEKS = re.compile(
    '''^No such board'''
)


def parse_seek_reply(reply_text):
    """
    Parse output of "seek" command
    :param reply_text: actual FICS output
    :type reply_text: str
    :return: seek details (or None)
    :rtype: SeekRef
    :raise: errors.BadFicsCommandParameters
    """
    for good_re in _RE_PROPER_SEEKS:
        mtch = good_re.search(reply_text)
        if mtch:
            return SeekRef(seek_no=int(mtch.group('seek_no')))
    if _RE_BAD_SEEKS.search(reply_text):
        raise errors.BadFicsCommandParameters(reply_text)
    # Sygnał że nie rozumiemy
    return None


_RE_SOUGHT_LINE = re.compile(r'^ *(?P<seek_no>\d+) +(?P<rank>\d+|\+\+\+\+|----) +(?P<who>[^\s()]+)(?:\(\S+\))* +(?P<base>\d+) +(?P<inc>\d+) +(?P<rated>rated|unrated) +(?P<variant>\S+) *?(?:\[(?P<color>white|black)\])? *(?P<min_rating>\d+)-(?P<max_rating>\d+) *(?P<flags>[mf]*)')

_RE_SOUGHT_FINISH = re.compile(r'^\d+ ads? displayed')


def parse_sought_reply(reply_text):
    """Parsing reply to sought"""
    lines = reply_text.strip(" \r\n").split("\n")
    if lines and _RE_SOUGHT_FINISH.search(lines[-1]):
        seeks = []
        for line in lines[:-1]:
            mtch = _RE_SOUGHT_LINE.search(line)
            if not mtch:
                log.warn("Can't parse sought line: %s", line)
                continue
            seeks.append(
                Seek(
                    seek_no=int(mtch.group('seek_no')),
                    player=PlayerName(mtch.group('who')),
                    player_rating_value=numeric_rank(mtch.group('rank')),
                    is_manual=('m' in mtch.group('flags')),
                    using_formula=('f' in mtch.group('flags')),
                    color=(mtch.group('color') and Color(mtch.group('color')) or None),
                    game_spec=GameSpec(
                        game_type=GameType(mtch.group('variant')),
                        clock=GameClock(int(mtch.group('base')), int(mtch.group('inc'))),
                        is_rated=rated_as_bool(mtch.group('rated')),
                        is_private='p' in mtch.group('flags')),   # TODO: czy to dobrze
                ),
            )
        return seeks
    return None
