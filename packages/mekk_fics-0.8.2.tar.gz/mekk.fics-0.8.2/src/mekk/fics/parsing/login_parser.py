# -*- coding: utf-8 -*-

"""
Detecting login/password prompts, and lines telling about succesfull login
"""

import re
from mekk.fics.datatypes.player import PlayerName


_RE_LOGIN = re.compile('([Uu]ser|[Ll]ogin):')
_RE_PASSWORD = re.compile('[Pp]assword:')
_RE_GUEST_LOGIN = re.compile(r"Press return to enter the (?:server|FICS) as \"([^\"]*)\"")
_RE_NORMAL_LOGIN = re.compile(r"Starting FICS session as ([a-zA-Z0-9]+)")


def is_login_prompt(line):
    """
    Checks whether given line looks like login prompt
    :param line: text obtained from FICS
    """
    if _RE_LOGIN.search(line):
        return True
    else:
        return False


def is_password_prompt(line):
    """
    Checks whether given line looks like password prompt
    :param line: whatever FICS provided as after getting login
    """
    if _RE_PASSWORD.search(line):
        return True
    else:
        return False


def is_authorized_login_confirmation(line):
    """
    Checks whether given text looks like succesfull login
    confirmation. If so, returns full user name
    (as PayerName object), if not, returns None
    :rtype : PlayerName
    """
    mtch = _RE_NORMAL_LOGIN.search(line)
    if mtch:
        return PlayerName(mtch.group(1))
    else:
        return None


def is_guest_login_confirmation(line):
    """
    Checks whether given text looks like successful guest login
    confirmation. If so, returns full (guest) user name, if not, returns None.
    Note Enter must be sent to confirm such login.
    :rtype : bool
    """
    mtch = _RE_GUEST_LOGIN.search(line)
    if mtch:
        return PlayerName(mtch.group(1))
    else:
        return None
