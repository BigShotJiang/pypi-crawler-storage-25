# -*- coding: utf-8 -*-

"""
mekk.fics is a framwork for writing FICS (freechess.org) bots and clients.
"""

from __future__ import absolute_import

# import mekk.fics.errors as errors
from mekk.fics.fics_connector import FicsFactory, ReconnectingFicsFactory
from mekk.fics.fics_client import FicsClient
from mekk.fics.fics_client_mixin_event_methods import FicsEventMethodsMixin
from mekk.fics.tell_commands import TellCommand, TellCommandsMixin
from mekk.fics.constants.network import FICS_HOST, FICS_PORT
from mekk.fics.version import VERSION
import mekk.fics.tell_commands.tell_errors     # pylint:disable=unused-import
# import mekk.fics.tell_commands.tell_errors as tell_errors

# TODO: integrate with setup.py, write once and import where appropriate

__author__ = "Marcin Kasperski"
__copyright__ = "Copyright 2005-2012, Marcin Kasperski"
__credits__ = ["DAV", "MAd", "FICS authors, admins, and documenters"]
__license__ = "Artistic"
__version__ = VERSION
__maintainer__ = "Marcin Kasperski"
__email__ = "Marcin.Kasperski at mekk.waw.pl"
__status__ = "Development"


__all__ = [
    "FicsFactory", "ReconnectingFicsFactory",
    "FicsClient",
    "FicsEventMethodsMixin",
    "TellCommand", "TellCommandsMixin",
    "FICS_HOST", "FICS_PORT",
    # "tell_errors",
]
