"""
DAV_prac — Jyotirmoy Dutta | Roll No: 2301051 | Batch: T13
DAV Laboratory, Sem 6
Use: from DAV_prac import exp1, exp2, ... or DAV_prac.show(1)
"""

# ── Quick helper ─────────────────────────────────────────────────────────────

def show(n):
    """Print the code for experiment n (1–10)."""
    exps = {
        1: exp1, 2: exp2, 3: exp3, 4: exp4, 5: exp5,
        6: exp6, 7: exp7, 8: exp8, 9: exp9, 10: exp10,
    }
    if n not in exps:
        print("Valid experiments: 1–10")
        return
    import inspect
    print(inspect.getsource(exps[n]))


def list_experiments():
    print("""
    Experiments in DAV_prac:
    ─────────────────────────────────────────────────────────
    exp1  – R Libraries: dplyr, tidyr, data.table, rpart, stringr
    exp2  – Viz Libraries (Python): Seaborn, Plotly, Altair, Bokeh
          – Viz Libraries (R):     ggplot2, Lattice, corrplot, Base R
    exp3  – Multiple Linear Regression (California Housing)
    exp4  – Logistic Regression (Framingham Heart Study)
    exp5  – Time Series Analysis (Airline Passengers)
    exp6  – ARIMA Forecasting (Household Power Consumption)
    exp7  – Text Analytics: Spam Filter, Sentiment, Word Cloud
    exp8  – Intro to Viz Libraries Python (Seaborn, Plotly, Altair, Bokeh)
    exp9  – Viz Techniques in R (ggplot2, MASS, ggvis, Lattice)
    exp10 – DAV on Iris Dataset (Seaborn & Matplotlib)
    ─────────────────────────────────────────────────────────
    Usage:
        from DAV_prac import exp3          # import the module/string
        print(exp3)                        # see the code
        DAV_prac.show(3)                   # pretty-print source
        DAV_prac.list_experiments()        # this list
    """)


# ── Experiment 1 ─────────────────────────────────────────────────────────────

exp1 = r"""
# ============================================================
# Experiment 1 - R Libraries: dplyr, tidyr, data.table,
#                rpart, stringr
# Name: Jyotirmoy Dutta | Roll No: 2301051 | Batch: T13
# ============================================================

# ------------------------------------------------------------
# a. dplyr
# ------------------------------------------------------------
library(dplyr)

data <- data.frame(
  id    = 1:5,
  name  = c("A", "B", "C", "D", "E"),
  score = c(78, 85, 90, 66, 88)
)

# 1. select() - Selects specific columns from the dataset
print("Select name and score columns:")
print(select(data, name, score))

# 2. filter() - Filters rows based on a condition
print("Filter students with score > 80:")
print(filter(data, score > 80))

# 3. arrange() - Sorts the data in descending order
print("Arrange data by descending score:")
print(arrange(data, desc(score)))

# 4. mutate() - Adds a new variable (pass/fail status)
print("Add pass/fail status:")
print(mutate(data, status = ifelse(score >= 80, "Pass", "Fail")))

# 5. summarize() - Aggregates data to get the average score
print("Average score:")
print(summarize(data, avg_score = mean(score)))


# ------------------------------------------------------------
# b. tidyr
# ------------------------------------------------------------
library(tidyr)

data <- data.frame(
  name    = c("A", "B"),
  math    = c(80, 90),
  science = c(85, 88)
)

# 1. pivot_longer() - Converts wide data to long format
print("Pivot longer (wide to long):")
long_data <- pivot_longer(data,
                           math:science,
                           names_to  = "subject",
                           values_to = "marks")
print(long_data)

# 2. pivot_wider() - Converts long data to wide format
print("Pivot wider (long to wide):")
print(pivot_wider(long_data,
                  names_from  = subject,
                  values_from = marks))

# 3. separate() - Splits one column into multiple columns
print("Separate column:")
sep_data <- separate(data.frame(info = c("A-80", "B-90")),
                     info,
                     into = c("name", "marks"),
                     sep  = "-")
print(sep_data)

# 4. unite() - Merges multiple columns into one
print("Unite columns:")
print(unite(data, student_info, name, math))

# 5. drop_na() - Removes rows containing missing (NA) values
print("Drop NA values:")
print(drop_na(data))


# ------------------------------------------------------------
# c. data.table
# ------------------------------------------------------------
library(data.table)

dt <- data.table(
  id         = 1:5,
  department = c("IT", "HR", "IT", "HR", "IT"),
  salary     = c(50000, 45000, 60000, 48000, 55000)
)

# 1. data.table() - Original data table
print("Original data table:")
print(dt)

# 2. dt[...] (Filter) - Subsets rows where salary > 50000
print("Filter salary > 50000:")
print(dt[salary > 50000])

# 3. dt[, .()] (Select) - Selects specific columns
print("Select department and salary:")
print(dt[, .(department, salary)])

# 4. by = ... (Group By) - Average salary grouped by department
print("Average salary by department:")
print(dt[, .(avg_salary = mean(salary)), by = department])

# 5. := (Update) - Adds a bonus column in place
print("Add bonus column:")
dt[, bonus := salary * 0.10]
print(dt)


# ------------------------------------------------------------
# d. rpart
# ------------------------------------------------------------
library(rpart)

data(iris)

# 1. rpart() - Trains the decision tree model
print("1. Train Decision Tree Model:")
model <- rpart(Species ~ ., data = iris, method = "class")
print(model)

# 2. predict() - Generates predictions on the dataset
print("2. Predict on the dataset:")
pred <- predict(model, iris, type = "class")
print(head(pred))

# 3. table() - Confusion matrix to compare predicted vs actual
print("3. Confusion Matrix:")
cm <- table(Predicted = pred, Actual = iris$Species)
print(cm)

# 4. mean() - Accuracy of the model
print("4. Accuracy of the model:")
accuracy <- mean(pred == iris$Species)
print(accuracy)

# 5. plot() - Visualises the decision tree structure
print("5. Plot Decision Tree:")
plot(model)
text(model, pretty = 0)


# ------------------------------------------------------------
# e. stringr
# ------------------------------------------------------------
library(stringr)

text <- c("Data Analytics", "R Programming", "Machine Learning")

# 1. str_length() - Returns the length of each string
print("Length of strings:")
print(str_length(text))

# 2. str_to_upper() - Converts strings to uppercase
print("Convert to uppercase:")
print(str_to_upper(text))

# 3. str_detect() - Checks if a pattern exists in the string
print("Detect word 'Data':")
print(str_detect(text, "Data"))

# 4. str_replace() - Replaces first occurrence of a pattern
print("Replace R with Python:")
print(str_replace(text, "R", "Python"))

# 5. str_split() - Splits a string into pieces by delimiter
print("Split strings:")
print(str_split(text, " "))
"""


# ── Experiment 2 ─────────────────────────────────────────────────────────────

exp2 = r"""
# ============================================================
# Experiment 2 - Data Visualization Libraries
# ============================================================

# ------------------------------------------------------------
# a. Seaborn (Python)
# ------------------------------------------------------------
import seaborn as sns
import matplotlib.pyplot as plt

data = sns.load_dataset("tips")

# 1. sns.scatterplot()
print("1. Scatter Plot:")
sns.scatterplot(data=data, x="total_bill", y="tip", hue="time")
plt.show()

# 2. sns.lineplot()
print("2. Line Plot:")
sns.lineplot(data=data, x="size", y="total_bill")
plt.show()

# 3. sns.histplot()
print("3. Histogram:")
sns.histplot(data=data, x="total_bill", kde=True)
plt.show()

# 4. sns.boxplot()
print("4. Box Plot:")
sns.boxplot(data=data, x="day", y="total_bill")
plt.show()

# 5. sns.heatmap()
print("5. Heatmap:")
corr = data.corr(numeric_only=True)
sns.heatmap(corr, annot=True, cmap="coolwarm")
plt.show()


# ------------------------------------------------------------
# b. Plotly Express (Python)
# ------------------------------------------------------------
import plotly.express as px

df = px.data.iris()

# 1. px.scatter()
fig1 = px.scatter(df, x="sepal_width", y="sepal_length", color="species")
fig1.show()

# 2. px.bar()
fig2 = px.bar(df, x="species", y="sepal_width")
fig2.show()

# 3. px.line()
gm = px.data.gapminder().query("country=='Canada'")
fig3 = px.line(gm, x="year", y="lifeExp")
fig3.show()

# 4. px.pie()
fig4 = px.pie(df, names='species')
fig4.show()

# 5. px.histogram()
fig5 = px.histogram(df, x="sepal_length", nbins=20)
fig5.show()


# ------------------------------------------------------------
# c. Altair (Python)
# ------------------------------------------------------------
import altair as alt
from vega_datasets import data

source = data.cars()

scatter = alt.Chart(source).mark_point().encode(
    x='Horsepower', y='Miles_per_Gallon',
    color='Origin',
    tooltip=['Name', 'Origin', 'Horsepower', 'Miles_per_Gallon']
).interactive().properties(title="1. Interactive Scatter Plot")

bar = alt.Chart(source).mark_bar().encode(
    x='Origin', y='count()', color='Origin'
).properties(title="2. Bar Chart")

line = alt.Chart(source).mark_line().encode(
    x='Year', y='mean(Miles_per_Gallon)', color='Origin'
).properties(title="3. Line Chart")

hist = alt.Chart(source).mark_bar().encode(
    x=alt.X('Horsepower', bin=True), y='count()', color='Origin'
).properties(title="4. Histogram")

box = alt.Chart(source).mark_boxplot().encode(
    x='Origin', y='Horsepower', color='Origin'
).properties(title="5. Box Plot")

(scatter | bar) & (line | hist) & box


# ------------------------------------------------------------
# d. Bokeh (Python)
# ------------------------------------------------------------
from bokeh.plotting import figure, show, output_notebook
import pandas as pd

output_notebook()
df = pd.DataFrame({'x': [1, 2, 3, 4, 5], 'y': [6, 7, 2, 4, 5]})

p = figure(title="Bokeh Example", x_axis_label='x', y_axis_label='y')
p.circle(df['x'], df['y'], size=15, color="navy", alpha=0.5)
p.line(df['x'], df['y'], line_width=2)

p2 = figure(title="Bar Chart")
p2.vbar(x=df['x'], top=df['y'], width=0.5)

show(p)
show(p2)


# ------------------------------------------------------------
# Experiment 2 - R Visualization Libraries
# ------------------------------------------------------------

# a. ggplot2
library(ggplot2)
data(mpg)
print(ggplot(mpg, aes(x=displ, y=hwy, color=class)) + geom_point())
print(ggplot(mpg, aes(x=class)) + geom_bar(fill="steelblue"))
df <- data.frame(time=1:10, value=runif(10))
print(ggplot(df, aes(x=time, y=value)) + geom_line())
print(ggplot(mpg, aes(x=hwy)) + geom_histogram(binwidth=2))
print(ggplot(mpg, aes(x=class, y=hwy)) + geom_boxplot())

# b. Lattice
library(lattice)
data(iris)
print(xyplot(Sepal.Length ~ Petal.Length, data=iris, groups=Species, auto.key=TRUE))
avg <- aggregate(Sepal.Length ~ Species, iris, mean)
print(barchart(Sepal.Length ~ Species, data=avg))
print(bwplot(Species ~ Sepal.Width, data=iris))
print(histogram(~ Sepal.Length | Species, data=iris))
print(densityplot(~ Petal.Width, groups=Species, data=iris, auto.key=TRUE))

# c. corrplot
install.packages("corrplot")
library(corrplot)
data(mtcars)
M <- cor(mtcars)
corrplot(M, method="circle")
corrplot.mixed(M)
corrplot(M, type="lower")
corrplot(M, order="hclust", addrect=2)

# d. Base R Graphics
data(iris)
plot(iris$Sepal.Length, iris$Petal.Length, col=iris$Species, main="Scatter Plot", pch=19)
legend("topright", legend=levels(iris$Species), col=1:3, pch=19)
barplot(table(iris$Species), main="Bar Chart", col="lightblue", border="darkblue")
hist(iris$Sepal.Length, main="Histogram", col="lightgreen", breaks=10)
boxplot(Sepal.Length ~ Species, data=iris, main="Box Plot", col=c("orange","cyan","yellow"))
pairs(iris[1:4], main="Pairs Plot", pch=21, bg=c("red","green3","blue")[iris$Species])
"""


# ── Experiment 3 ─────────────────────────────────────────────────────────────

exp3 = r"""
# ============================================================
# Experiment 3 - Multiple Linear Regression in Python
# Name: Jyotirmoy Dutta | Roll No: 2301051 | Batch: T13
# Date: 09 February, 2026
# ============================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler

print('Libraries imported successfully.')

housing = fetch_california_housing(as_frame=True)
df = housing.frame
df.rename(columns={'MedHouseVal': 'Target_MedHouseVal'}, inplace=True)

print('\n--- First 5 Rows ---')
print(df.head())
print('\n--- Shape ---')
print('Rows:', df.shape[0], '| Columns:', df.shape[1])
print('\n--- Summary Statistics ---')
print(df.describe().round(2))
print('\n--- Missing Values ---')
print(df.isnull().sum())

# Correlation Heatmap
plt.figure(figsize=(10, 7))
sns.heatmap(df.corr(), annot=True, fmt='.2f', cmap='Blues',
            linewidths=0.5, annot_kws={'size': 8})
plt.title('Correlation Heatmap - California Housing Dataset',
          fontsize=13, fontweight='bold')
plt.tight_layout()
plt.show()

# Distribution of Target Variable
plt.figure(figsize=(8, 4))
sns.histplot(df['Target_MedHouseVal'], bins=50, kde=True, color='steelblue')
plt.title('Distribution of Median House Value', fontsize=12, fontweight='bold')
plt.xlabel('Median House Value (x $100,000)')
plt.tight_layout()
plt.show()

X = df.drop(columns=['Target_MedHouseVal'])
y = df['Target_MedHouseVal']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled  = scaler.transform(X_test)

print('Training samples:', X_train.shape[0])
print('Testing samples:', X_test.shape[0])

model = LinearRegression()
model.fit(X_train_scaled, y_train)

print('\n--- Model Coefficients ---')
coef_df = pd.DataFrame({'Feature': X.columns, 'Coefficient': model.coef_})
print(coef_df.to_string(index=False))
print('Intercept:', round(model.intercept_, 4))

y_pred = model.predict(X_test_scaled)
mse  = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)
mae  = mean_absolute_error(y_test, y_pred)
r2   = r2_score(y_test, y_pred)

print('\n========== MODEL EVALUATION METRICS ==========')
print(f' MSE  : {mse:.4f}')
print(f' RMSE : {rmse:.4f}')
print(f' MAE  : {mae:.4f}')
print(f' R2   : {r2:.4f}')
print('==============================================')

# Actual vs Predicted
plt.figure(figsize=(8, 6))
plt.scatter(y_test, y_pred, alpha=0.3, color='steelblue', edgecolors='none')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()],
         'r--', lw=2, label='Ideal Fit')
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Actual vs Predicted - Multiple Linear Regression', fontweight='bold')
plt.legend()
plt.tight_layout()
plt.show()

# Residuals Distribution
residuals = y_test - y_pred
plt.figure(figsize=(8, 4))
sns.histplot(residuals, bins=50, kde=True, color='coral')
plt.axvline(x=0, color='black', linestyle='--', lw=1.5)
plt.title('Residuals Distribution', fontweight='bold')
plt.tight_layout()
plt.show()

# Feature Importance
plt.figure(figsize=(9, 5))
colors = ['steelblue' if c > 0 else 'tomato' for c in model.coef_]
plt.barh(X.columns, model.coef_, color=colors)
plt.axvline(x=0, color='black', linewidth=0.8)
plt.title('Feature Coefficients - Multiple Linear Regression', fontweight='bold')
plt.tight_layout()
plt.show()

print('\nAll outputs generated successfully.')
"""


# ── Experiment 4 ─────────────────────────────────────────────────────────────

exp4 = r"""
# ============================================================
# Experiment 4 - Logistic Regression in Python
# Name: Jyotirmoy Dutta | Roll No: 2301051 | Batch: T13
# Date: 24 February, 2026
# Dataset: Framingham Heart Study (framingham.csv)
# NOTE: Download framingham.csv from Kaggle and place it in
#       the same folder as this script before running.
#       Link: https://www.kaggle.com/datasets/amanajmera1/framingham-heart-study-dataset
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, confusion_matrix, classification_report,
    roc_auc_score, roc_curve
)

sns.set_style("whitegrid")

df = pd.read_csv("framingham.csv")
df.head()
df.info()
df.describe()

df.fillna(df.mean(), inplace=True)

plt.figure(figsize=(6, 4))
sns.countplot(x='TenYearCHD', data=df)
plt.title('Distribution of TenYearCHD')
plt.show()
print(df['TenYearCHD'].value_counts(normalize=True))

# Correlation Heatmap
plt.figure(figsize=(12, 8))
sns.heatmap(df.corr(), cmap='coolwarm', annot=False)
plt.title('Correlation Heatmap')
plt.show()

# Age Distribution by CHD
plt.figure(figsize=(8, 5))
sns.histplot(data=df, x='age', hue='TenYearCHD', kde=True, bins=30)
plt.title('Age Distribution by CHD')
plt.show()

# Cholesterol vs CHD
plt.figure(figsize=(6, 5))
sns.boxplot(x='TenYearCHD', y='totChol', data=df)
plt.title('Cholesterol vs CHD')
plt.show()

# Systolic BP vs CHD
plt.figure(figsize=(6, 5))
sns.boxplot(x='TenYearCHD', y='sysBP', data=df)
plt.title('Systolic BP vs CHD')
plt.show()

X = df.drop('TenYearCHD', axis=1)
y = df['TenYearCHD']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)

scaler  = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test  = scaler.transform(X_test)

model = LogisticRegression(max_iter=1000, class_weight='balanced')
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]

print('Accuracy:', accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))

cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()

roc_auc = roc_auc_score(y_test, y_prob)
print('ROC-AUC Score:', roc_auc)
fpr, tpr, thresholds = roc_curve(y_test, y_prob)

plt.figure(figsize=(6, 5))
plt.plot(fpr, tpr, label=f'Logistic Regression (AUC = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], 'r--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.legend()
plt.show()

X_original = df.drop('TenYearCHD', axis=1)
coefficients = pd.DataFrame({
    'Feature':     X_original.columns,
    'Coefficient': model.coef_[0]
}).sort_values('Coefficient', ascending=False)

plt.figure(figsize=(10, 6))
sns.barplot(x='Coefficient', y='Feature', data=coefficients)
plt.title('Feature Importance (Logistic Regression Coefficients)')
plt.show()
"""


# ── Experiment 5 ─────────────────────────────────────────────────────────────

exp5 = r"""
# ============================================================
# Experiment 5 - Time Series Analysis in Python
# Name: Jyotirmoy Dutta | Roll No: 2301051 | Batch: T13
# Date: 26 February, 2026
# Dataset: Airline Passengers (loaded directly from URL)
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.graphics.tsaplots import plot_acf

plt.style.use('seaborn-v0_8')

url = ('https://raw.githubusercontent.com/jbrownlee/'
       'Datasets/master/airline-passengers.csv')
df = pd.read_csv(url)

df['Month'] = pd.to_datetime(df['Month'])
df.set_index('Month', inplace=True)
print(df.head())
print(df.info())
print(df.describe())

# Line Plot - Raw Time Series
plt.figure(figsize=(12, 6))
plt.plot(df.index, df['Passengers'])
plt.title('Monthly Airline Passengers (1949-1960)')
plt.xlabel('Year')
plt.ylabel('Number of Passengers')
plt.show()

# 12-Month Rolling Mean
rolling_mean = df['Passengers'].rolling(window=12).mean()
plt.figure(figsize=(12, 6))
plt.plot(df['Passengers'], label='Original')
plt.plot(rolling_mean, color='red', label='12-Month Rolling Mean')
plt.legend()
plt.title('Trend using Rolling Mean')
plt.show()

# Seasonal Decomposition
decomposition = seasonal_decompose(df['Passengers'], model='multiplicative')
decomposition.plot()
plt.show()

# ACF Plot
plot_acf(df['Passengers'])
plt.show()
"""


# ── Experiment 6 ─────────────────────────────────────────────────────────────

exp6 = r"""
# ============================================================
# Experiment 6: ARIMA Model for Time Series Forecasting
# Name: Jyotirmoy Dutta | Roll No: 2301051 | Batch: T13
# Subject: DAV Laboratory | Sem: 6 | Date: 14/03/2026
# NOTE: Download household_power_consumption.csv from Kaggle
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

df = pd.read_csv("household_power_consumption.csv", low_memory=False)
df.columns = df.columns.str.strip()
if 'index' in df.columns:
    df = df.drop('index', axis=1)
df.replace('?', np.nan, inplace=True)

numeric_cols = [
    'Global_active_power', 'Global_reactive_power', 'Voltage',
    'Global_intensity', 'Sub_metering_1', 'Sub_metering_2', 'Sub_metering_3'
]
df[numeric_cols] = df[numeric_cols].astype(float)

df['Datetime'] = pd.to_datetime(
    df['Date'] + ' ' + df['Time'],
    format='%d/%m/%Y %H:%M:%S',
    errors='coerce'
)
df.drop(['Date', 'Time'], axis=1, inplace=True)
df.set_index('Datetime', inplace=True)
df = df.ffill()

print(df.head())
print(df.columns)

from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error

series = df['Global_active_power'].resample('D').mean().dropna()

test_size = 7
train = series[:-test_size]
test  = series[-test_size:]

model     = ARIMA(train, order=(1, 1, 1))
model_fit = model.fit()
print(model_fit.summary())

forecast = model_fit.forecast(steps=len(test))
mse  = mean_squared_error(test, forecast)
rmse = np.sqrt(mse)
print(f"MSE:  {mse:.4f}")
print(f"RMSE: {rmse:.4f}")

import pmdarima as pm

auto_model = pm.auto_arima(
    train,
    start_p=0, max_p=10,
    start_q=0, max_q=10,
    d=None,
    seasonal=False,
    stepwise=True,
    suppress_warnings=True,
    trace=True
)
print(auto_model.summary())

forecast_auto = auto_model.predict(n_periods=test_size)
mse_auto  = mean_squared_error(test, forecast_auto)
rmse_auto = np.sqrt(mse_auto)
print(f"Auto ARIMA MSE:  {mse_auto:.4f}")
print(f"Auto ARIMA RMSE: {rmse_auto:.4f}")

plt.figure(figsize=(12, 6))
plt.plot(train.index, train,         label='Train')
plt.plot(test.index,  test,          label='Test')
plt.plot(test.index,  forecast_auto, label='Auto ARIMA Forecast', color='red')
plt.title("Auto ARIMA Forecast - Daily Global Active Power")
plt.xlabel("Date")
plt.ylabel("Global Active Power (kW)")
plt.legend()
plt.tight_layout()
plt.show()

print("\nConclusion: ARIMA Model in Python has been successfully implemented.")
"""


# ── Experiment 7 ─────────────────────────────────────────────────────────────

exp7 = r"""
# ============================================================
# Experiment 7: Text Analytics - Spam Filter / Sentiment
#               Analysis / Word Cloud
# Name: Jyotirmoy Dutta | Roll No: 2301051 | Batch: T13
# Subject: DAV Laboratory | Sem: 6 | Date: 14/03/2026
# ============================================================

# ── PART A: Spam Filter using Naive Bayes ───────────────────
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report, accuracy_score

url = (
    "https://raw.githubusercontent.com/justmarkham/pycon-2016-tutorial"
    "/master/data/sms.tsv"
)
df = pd.read_csv(url, sep='\t', header=None, names=['label', 'message'])
df['label'] = df['label'].map({'ham': 0, 'spam': 1})

X_train, X_test, y_train, y_test = train_test_split(
    df['message'], df['label'], test_size=0.2, random_state=42)

vectorizer  = CountVectorizer(stop_words='english')
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec  = vectorizer.transform(X_test)

model = MultinomialNB()
model.fit(X_train_vec, y_train)

y_pred = model.predict(X_test_vec)
print("=== Spam Filter Results ===")
print("Accuracy:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))

sample     = ["Congratulations! You've won a free ticket"]
sample_vec = vectorizer.transform(sample)
print("Spam Prediction for custom message:", model.predict(sample_vec))


# ── PART B: Sentiment Analysis using VADER ──────────────────
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer

nltk.download('vader_lexicon')
sia = SentimentIntensityAnalyzer()

texts = [
    "I love this product! It's amazing.",
    "This is the worst experience ever.",
    "It's okay, not great but not bad."
]

print("\n=== Sentiment Analysis Results ===")
for text in texts:
    score = sia.polarity_scores(text)
    print(f"\nText   : {text}")
    print(f"Scores : {score}")
    if score['compound'] >= 0.05:
        print("Sentiment: Positive")
    elif score['compound'] <= -0.05:
        print("Sentiment: Negative")
    else:
        print("Sentiment: Neutral")


# ── PART C: Word Cloud ───────────────────────────────────────
from wordcloud import WordCloud
import matplotlib.pyplot as plt

text = (
    "Artificial intelligence and machine learning are transforming the world. "
    "AI is used in healthcare, finance, education, and more. "
    "Machine learning models learn patterns from data."
)

wordcloud = WordCloud(
    width=800, height=400, background_color='white', max_words=200
).generate(text)

plt.figure(figsize=(10, 5))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.title("Word Cloud - AI & Machine Learning Text")
plt.tight_layout()
plt.show()

print("\nConclusion: Text Analytics successfully implemented.")
"""


# ── Experiment 8 ─────────────────────────────────────────────────────────────

exp8 = r"""
# ============================================================
# Experiment 8: Introduction to Data Visualization Libraries
#               in Python and R
# Name: Jyotirmoy Dutta | Roll No: 2301051 | Batch: T13
# Subject: DAV Laboratory | Sem: 6 | Date: 23/01/2026
# ============================================================

# ════════════════════════════════════════════════════════════
# SECTION A — SEABORN  (tips dataset)
# ════════════════════════════════════════════════════════════
import seaborn as sns
import matplotlib.pyplot as plt

data = sns.load_dataset("tips")

print("1. Scatter Plot:")
sns.scatterplot(data=data, x="total_bill", y="tip", hue="time")
plt.title("Scatter Plot: Total Bill vs Tip by Time")
plt.tight_layout(); plt.show()

print("2. Line Plot:")
sns.lineplot(data=data, x="size", y="total_bill")
plt.title("Line Plot: Party Size vs Total Bill")
plt.tight_layout(); plt.show()

print("3. Histogram:")
sns.histplot(data=data, x="total_bill", kde=True)
plt.title("Histogram: Distribution of Total Bill")
plt.tight_layout(); plt.show()

print("4. Box Plot:")
sns.boxplot(data=data, x="day", y="total_bill")
plt.title("Box Plot: Total Bill by Day")
plt.tight_layout(); plt.show()

print("5. Heatmap:")
corr = data.corr(numeric_only=True)
sns.heatmap(corr, annot=True, cmap="coolwarm")
plt.title("Heatmap: Correlation Matrix (Tips Dataset)")
plt.tight_layout(); plt.show()


# ════════════════════════════════════════════════════════════
# SECTION B — PLOTLY EXPRESS  (iris dataset)
# ════════════════════════════════════════════════════════════
import plotly.express as px

df = px.data.iris()

fig1 = px.scatter(df, x="sepal_width", y="sepal_length", color="species",
                  title="1. Interactive Scatter Plot")
fig1.show()

fig2 = px.bar(df, x="species", y="sepal_width",
              title="2. Bar Chart: Sepal Width by Species")
fig2.show()

gm   = px.data.gapminder().query("country=='Canada'")
fig3 = px.line(gm, x="year", y="lifeExp",
               title="3. Line Chart: Canada Life Expectancy")
fig3.show()

fig4 = px.pie(df, names="species", title="4. Pie Chart: Species Distribution")
fig4.show()

fig5 = px.histogram(df, x="sepal_length", nbins=20,
                    title="5. Histogram: Sepal Length")
fig5.show()


# ════════════════════════════════════════════════════════════
# SECTION C — ALTAIR  (cars dataset)
# ════════════════════════════════════════════════════════════
import altair as alt
from vega_datasets import data as vega_data

source = vega_data.cars()

scatter = (
    alt.Chart(source).mark_point()
       .encode(x="Horsepower", y="Miles_per_Gallon",
               color="Origin",
               tooltip=["Name", "Origin", "Horsepower", "Miles_per_Gallon"])
       .interactive().properties(title="1. Interactive Scatter Plot")
)

bar = (
    alt.Chart(source).mark_bar()
       .encode(x="Origin", y="count()", color="Origin")
       .properties(title="2. Bar Chart")
)

line = (
    alt.Chart(source).mark_line()
       .encode(x="Year", y="mean(Miles_per_Gallon)", color="Origin")
       .properties(title="3. Line Chart")
)

hist = (
    alt.Chart(source).mark_bar()
       .encode(x=alt.X("Horsepower", bin=True), y="count()", color="Origin")
       .properties(title="4. Histogram")
)

box = (
    alt.Chart(source).mark_boxplot()
       .encode(x="Origin", y="Horsepower", color="Origin")
       .properties(title="5. Box Plot")
)

(scatter | bar) & (line | hist) & box


# ════════════════════════════════════════════════════════════
# SECTION D — BOKEH
# ════════════════════════════════════════════════════════════
from bokeh.plotting import figure, show, output_notebook
import pandas as pd

output_notebook()
df_bk = pd.DataFrame({'x': [1, 2, 3, 4, 5], 'y': [6, 7, 2, 4, 5]})

p = figure(title="Bokeh Example", x_axis_label='x', y_axis_label='y')
p.scatter(df_bk['x'], df_bk['y'], size=15, color="navy", alpha=0.5)
p.line(df_bk['x'],    df_bk['y'], line_width=2)
show(p)

p2 = figure(title="Bar Chart")
p2.vbar(x=df_bk['x'], top=df_bk['y'], width=0.5)
show(p2)

print("\nConclusion: Intro to data visualization libraries demonstrated.")
"""


# ── Experiment 9 ─────────────────────────────────────────────────────────────

exp9 = r"""
# ============================================================
# Experiment 9: Selecting Appropriate Database and Applying
#               Various Visualization Techniques using R
# Name: Jyotirmoy Dutta | Roll No: 2301051 | Batch: T13
# Subject: DAV Laboratory | Sem: 6 | Date: 23/01/2026
# ============================================================

# 1. Using ggplot2
library(ggplot2)

ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width, color = Species)) +
  geom_point() +
  labs(title = "Scatter Plot of Sepal Length vs Sepal Width",
       x = "Sepal Length", y = "Sepal Width")

ggplot(iris, aes(x = Species, y = Petal.Length)) +
  geom_boxplot() +
  labs(title = "Box Plot of Petal Length by Species",
       x = "Species", y = "Petal Length")

ggplot(iris, aes(x = Species, y = Petal.Width, fill = Petal.Length)) +
  geom_tile() +
  scale_fill_gradient(low = "white", high = "steelblue") +
  labs(title = "Heatmap of Petal Width vs Petal Length by Species",
       x = "Species", y = "Petal Width")


# 2. Using MASS — Parallel Coordinates Plot
library(MASS)

parcoord(
  iris[, 1:4],
  col   = iris$Species,
  lty.h = 1,
  lty.v = 2
)
title("Parallel Coordinates Plot — Iris Dataset")


# 3. Using ggvis — Interactive Scatter Plot
# install.packages("ggvis")
library(ggvis)

iris %>%
  ggvis(~Sepal.Width, ~Petal.Length, fill = ~Species) %>%
  layer_points()


# 4. Using Lattice — Conditioned Scatter Plot
library(lattice)

xyplot(
  Petal.Length ~ Sepal.Width | Species,
  data = iris,
  type = c("p", "g"),
  main = "Lattice: Petal Length ~ Sepal Width | Species"
)

cat("\nConclusion: Diverse visualization techniques on the iris dataset",
    "using ggplot2, MASS, ggvis, and lattice were explored successfully.\n")
"""


# ── Experiment 10 ────────────────────────────────────────────────────────────

exp10 = r"""
# ============================================================
# Experiment 10: DAV using Python Libraries for a Specific
#                Dataset (Iris — Seaborn & Matplotlib)
# Name: Jyotirmoy Dutta | Roll No: 2301051 | Batch: T13
# Subject: DAV Laboratory | Sem: 6 | Date: 23/01/2026
# ============================================================

import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris

iris_sklearn = load_iris()
iris_df = sns.load_dataset("iris")
sns.set(style="ticks")

# Plot 1: Pairplot
sns.pairplot(iris_df, hue="species")
plt.suptitle("Pairplot of Iris Dataset", y=1.02)
plt.tight_layout(); plt.show()

# Plot 2: Swarm Plot — Sepal Length vs Sepal Width
plt.figure()
sns.swarmplot(x="sepal_length", y="sepal_width", hue="species", data=iris_df)
plt.title("Swarm plot of Sepal Length vs. Sepal Width")
plt.tight_layout(); plt.show()

# Plot 3: Swarm Plot — Petal Length vs Petal Width
plt.figure()
sns.swarmplot(x="petal_length", y="petal_width", hue="species", data=iris_df)
plt.title("Swarm plot of Petal Length vs. Petal Width")
plt.tight_layout(); plt.show()

# Plot 4: Boxplot — Sepal Length by Species
plt.figure()
sns.boxplot(x="species", y="sepal_length", data=iris_df)
plt.title("Boxplot of Sepal Length by Species")
plt.tight_layout(); plt.show()

# Plot 5: Boxplot — Sepal Width by Species
plt.figure()
sns.boxplot(x="species", y="sepal_width", data=iris_df)
plt.title("Boxplot of Sepal Width by Species")
plt.tight_layout(); plt.show()

# Plot 6: Violin Plot — Petal Length by Species
plt.figure()
sns.violinplot(x="species", y="petal_length", data=iris_df)
plt.title("Violin plot of Petal Length by Species")
plt.tight_layout(); plt.show()

# Plot 7: Violin Plot — Petal Width by Species
plt.figure()
sns.violinplot(x="species", y="petal_width", data=iris_df)
plt.title("Violin plot of Petal Width by Species")
plt.tight_layout(); plt.show()

# Plot 8: Distribution — Sepal Length
plt.figure()
sns.histplot(iris_df["sepal_length"], kde=True)
plt.title("Distribution of Sepal Length")
plt.tight_layout(); plt.show()

# Plot 9: Distribution — Sepal Width
plt.figure()
sns.histplot(iris_df["sepal_width"], kde=True)
plt.title("Distribution of Sepal Width")
plt.tight_layout(); plt.show()

# Plot 10: Distribution — Petal Length
plt.figure()
sns.histplot(iris_df["petal_length"], kde=True)
plt.title("Distribution of Petal Length")
plt.tight_layout(); plt.show()

print("\nConclusion: DAV using Python libraries (Seaborn & Matplotlib) "
      "on the Iris dataset has been successfully implemented.")
"""
