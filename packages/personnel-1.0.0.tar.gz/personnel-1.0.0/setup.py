from setuptools import setup, find_packages

setup(
    name="personnel",
    version="1.0.0",
    author="Jyotirmoy Dutta",
    description="practice",
    packages=find_packages(),
    python_requires=">=3.7",
)
