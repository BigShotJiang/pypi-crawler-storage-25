# DAV_prac

DAV Laboratory practical codes — Jyotirmoy Dutta, Roll No: 2301051, Batch: T13

## Install (from this folder)
```
pip install .
```

## Usage
```python
import DAV_prac

# List all experiments
DAV_prac.list_experiments()

# Print code for a specific experiment
DAV_prac.show(3)

# Access code as a string (copy-paste into your file)
print(DAV_prac.exp3)
```

## Experiments
- exp1  – R Libraries (dplyr, tidyr, data.table, rpart, stringr)
- exp2  – Visualization Libraries (Python + R)
- exp3  – Multiple Linear Regression
- exp4  – Logistic Regression
- exp5  – Time Series Analysis
- exp6  – ARIMA Forecasting
- exp7  – Text Analytics (Spam, Sentiment, Word Cloud)
- exp8  – Intro to Viz Libraries Python
- exp9  – Viz Techniques in R
- exp10 – DAV on Iris Dataset
