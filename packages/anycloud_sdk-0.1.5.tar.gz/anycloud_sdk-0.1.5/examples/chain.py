#!/usr/bin/env python3
"""Example: submit a 3-step pipeline with bucket-based data chaining."""

import anycloud


def main(ac: anycloud.Client):
    # -- Bucket handles (output buckets are auto-created by the server) --------
    prep_out  = ac.bucket("example-prep-output")
    train_out = ac.bucket("example-train-output")

    # -- Optional: upload local data into the first bucket ---------------------
    # prep_out.upload("~/datasets/imagenet")

    # -- Build a chain: prep → train → eval ------------------------------------
    prep = ac.submit("my-prep:latest", gpu="a100:1", output=prep_out)
    print(f"Submitted prep: {prep.id}")
    prep.wait()

    train = ac.submit(
        "my-train:latest",
        gpu="a100:8",
        input=prep_out,
        output=train_out,
    )
    print(f"Submitted train: {train.id}")
    train.wait()

    eval_ = ac.submit(
        "my-eval:latest",
        gpu="a100:1",
        input=train_out,
    )
    print(f"Submitted eval: {eval_.id}")
    eval_.wait()

    # -- Download results ------------------------------------------------------
    # train_out.download("~/results/")

    # -- Print logs from the final step ----------------------------------------
    logs = eval_.logs()
    if logs:
        print(f"\n--- eval logs ---\n{logs}")


if __name__ == "__main__":
    # Auto-loads credentials from the API.
    # Use credentials="name" if you have multiple credential sets.
    with anycloud.Client() as ac:
        main(ac)
