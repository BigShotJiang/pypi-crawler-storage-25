import pytest


@pytest.fixture(autouse=True)
def _set_github_token(monkeypatch):
    """Provide a default GITHUB_TOKEN so Client() never fails auth in tests."""
    monkeypatch.setenv("GITHUB_TOKEN", "tok")
