"""Tests for Image — Dockerfile generation, ref hashing, and build() integration."""

import json
import tempfile
from pathlib import Path

import httpx
import pytest

from anycloud import Client, Image, Job
from anycloud.types import AWSCredentials, CloudConfig


def _aws_config(**overrides) -> CloudConfig:
    defaults = dict(
        cloudProvider="AWS",
        credentials=AWSCredentials(accessKeyId="fake", secretAccessKey="fake"),
    )
    defaults.update(overrides)
    return CloudConfig(**defaults)


class TestDockerfileGeneration:
    def test_basic_from(self):
        img = Image("ubuntu:22.04")
        assert img.to_dockerfile() == "FROM ubuntu:22.04\n"

    def test_empty_base_raises(self):
        with pytest.raises(ValueError, match="base image is required"):
            Image("")

    def test_blank_base_raises(self):
        with pytest.raises(ValueError, match="base image is required"):
            Image("   ")

    def test_default_base(self):
        img = Image()
        assert img.to_dockerfile().startswith("FROM python:3.11\n")

    def test_pip_install(self):
        img = Image("python:3.11").pip_install("torch", "numpy")
        df = img.to_dockerfile()
        assert "RUN pip install --no-cache-dir torch numpy" in df

    def test_pip_install_empty_raises(self):
        with pytest.raises(ValueError):
            Image().pip_install()

    def test_apt_install(self):
        img = Image("python:3.11").apt_install("curl", "git")
        df = img.to_dockerfile()
        assert "apt-get update" in df
        assert "apt-get install -y curl git" in df
        assert "rm -rf /var/lib/apt/lists/*" in df

    def test_apt_install_empty_raises(self):
        with pytest.raises(ValueError):
            Image().apt_install()

    def test_run_commands_single(self):
        img = Image().run_commands("echo hello")
        assert "RUN echo hello" in img.to_dockerfile()

    def test_run_commands_multiple(self):
        img = Image().run_commands("echo a", "echo b")
        assert "RUN echo a && echo b" in img.to_dockerfile()

    def test_run_commands_empty_raises(self):
        with pytest.raises(ValueError):
            Image().run_commands()

    def test_env(self):
        img = Image().env({"HF_HOME": "/root/models", "DEBUG": "1"})
        df = img.to_dockerfile()
        assert 'ENV HF_HOME="/root/models" DEBUG="1"' in df

    def test_env_empty_raises(self):
        with pytest.raises(ValueError):
            Image().env({})

    def test_workdir(self):
        img = Image().workdir("/app")
        assert "WORKDIR /app" in img.to_dockerfile()

    def test_chaining_preserves_order(self):
        img = (
            Image("python:3.11")
            .apt_install("curl")
            .pip_install("torch")
            .env({"KEY": "val"})
            .workdir("/app")
            .run_commands("echo done")
        )
        df = img.to_dockerfile()
        lines = df.strip().splitlines()
        assert lines[0] == "FROM python:3.11"
        assert "apt-get" in lines[1]
        assert "pip install" in lines[2]
        assert "ENV" in lines[3]
        assert "WORKDIR" in lines[4]
        assert "RUN echo done" in lines[5]


class TestImmutability:
    def test_chaining_returns_new_image(self):
        a = Image("python:3.11")
        b = a.pip_install("torch")
        assert a is not b
        assert len(a._steps) == 0
        assert len(b._steps) == 1

    def test_original_unchanged_after_chain(self):
        base = Image("alpine")
        _ = base.apt_install("curl")
        _ = base.pip_install("flask")
        assert base.to_dockerfile() == "FROM alpine\n"


class TestRepository:
    def test_repository_preserved_through_chaining(self):
        img = (
            Image("python:3.11", repository="ghcr.io/user/train")
            .pip_install("torch")
            .apt_install("curl")
        )
        assert img._repository == "ghcr.io/user/train"

    def test_ref_format(self):
        img = Image("python:3.11", repository="ghcr.io/user/train").pip_install("torch")
        ref = img.ref
        assert ref.startswith("ghcr.io/user/train:")
        # Tag should be 12-char hex
        tag = ref.split(":")[-1]
        assert len(tag) == 12
        assert all(c in "0123456789abcdef" for c in tag)

    def test_ref_deterministic(self):
        img1 = Image("python:3.11", repository="ghcr.io/user/train").pip_install("torch")
        img2 = Image("python:3.11", repository="ghcr.io/user/train").pip_install("torch")
        assert img1.ref == img2.ref

    def test_ref_changes_with_content(self):
        img1 = Image("python:3.11", repository="ghcr.io/user/train").pip_install("torch")
        img2 = Image("python:3.11", repository="ghcr.io/user/train").pip_install("torch", "numpy")
        assert img1.ref != img2.ref

    def test_ref_without_repository_raises(self):
        img = Image("python:3.11").pip_install("torch")
        with pytest.raises(ValueError, match="repository is required"):
            img.ref


class TestBuildWithImage:
    def test_build_with_image(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "build-123"})

        image = Image("python:3.11", repository="ghcr.io/user/train").pip_install("torch")
        cc = _aws_config(vmType="c5.xlarge")

        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job = ac.build(image, cloud_config=cc)

        assert isinstance(job, Job)
        assert job.id == "build-123"
        body = captured["body"]
        assert body["image"] == "ghcr.io/anycloud-sh/builder"
        assert body["env"]["DOCKERFILE"] == image.to_dockerfile()
        assert body["env"]["TARGET_IMAGE"] == image.ref

    def test_build_with_image_explicit_target(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "build-456"})

        image = Image("python:3.11").pip_install("torch")
        cc = _aws_config(vmType="c5.xlarge")

        with Client() as ac:
            ac._http = httpx.Client(transport=httpx.MockTransport(handler), base_url="http://test")
            job = ac.build(image, target_image="ghcr.io/user/custom:v1", cloud_config=cc)

        assert captured["body"]["env"]["TARGET_IMAGE"] == "ghcr.io/user/custom:v1"

    def test_build_with_image_no_repository_no_target_raises(self):
        image = Image("python:3.11").pip_install("torch")
        cc = _aws_config(vmType="c5.xlarge")
        with Client() as ac:
            with pytest.raises(ValueError, match="repository is required"):
                ac.build(image, cloud_config=cc)


class TestDebianSlim:
    def test_default_version(self):
        img = Image.debian_slim()
        assert img.to_dockerfile() == "FROM python:3.11-slim\n"

    def test_custom_version(self):
        img = Image.debian_slim("3.12")
        assert img.to_dockerfile() == "FROM python:3.12-slim\n"

    def test_with_repository(self):
        img = Image.debian_slim(repository="ghcr.io/user/app")
        assert img._repository == "ghcr.io/user/app"

    def test_chaining(self):
        img = Image.debian_slim("3.12").pip_install("torch").apt_install("curl")
        df = img.to_dockerfile()
        assert df.startswith("FROM python:3.12-slim\n")
        assert "pip install" in df
        assert "apt-get" in df


class TestFromDockerfile:
    def test_basic(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".Dockerfile", delete=False) as f:
            f.write("FROM python:3.11\nRUN pip install torch\nWORKDIR /app\n")
            f.flush()
            img = Image.from_dockerfile(f.name)
        assert img._base == "python:3.11"
        df = img.to_dockerfile()
        assert "RUN pip install torch" in df
        assert "WORKDIR /app" in df

    def test_chaining_on_top(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".Dockerfile", delete=False) as f:
            f.write("FROM ubuntu:22.04\nRUN apt-get update\n")
            f.flush()
            img = Image.from_dockerfile(f.name).pip_install("flask")
        df = img.to_dockerfile()
        assert df.startswith("FROM ubuntu:22.04\n")
        assert "RUN apt-get update" in df
        assert "pip install --no-cache-dir flask" in df

    def test_with_repository(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".Dockerfile", delete=False) as f:
            f.write("FROM python:3.11\n")
            f.flush()
            img = Image.from_dockerfile(f.name, repository="ghcr.io/user/app")
        assert img._repository == "ghcr.io/user/app"
        assert img.ref.startswith("ghcr.io/user/app:")

    def test_missing_file_raises(self):
        with pytest.raises(FileNotFoundError):
            Image.from_dockerfile("/nonexistent/Dockerfile")

    def test_no_from_raises(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".Dockerfile", delete=False) as f:
            f.write("RUN echo hello\n")
            f.flush()
            with pytest.raises(ValueError, match="must start with a FROM"):
                Image.from_dockerfile(f.name)

    def test_empty_file_raises(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".Dockerfile", delete=False) as f:
            f.write("")
            f.flush()
            with pytest.raises(ValueError, match="must start with a FROM"):
                Image.from_dockerfile(f.name)

    def test_accepts_path_object(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".Dockerfile", delete=False) as f:
            f.write("FROM alpine:3.18\n")
            f.flush()
            img = Image.from_dockerfile(Path(f.name))
        assert img._base == "alpine:3.18"
