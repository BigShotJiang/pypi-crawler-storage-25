"""Tests for @anycloud.function() decorator and Function."""

import json
import os
import subprocess
import sys
import textwrap
from unittest.mock import patch

import httpx
import pytest

import anycloud
from anycloud import Function
from anycloud.client import Client
from anycloud.function import (
    _parse_github_repo,
    _detect_git_info,
    _get_default_client,
)
from anycloud.types import AWSCredentials, CloudConfig

# anycloud.__init__ shadows the module name with the function export,
# so use sys.modules to get the actual module for patching.
fn_mod = sys.modules["anycloud.function"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _aws_config(**overrides) -> CloudConfig:
    defaults = dict(
        cloudProvider="AWS",
        credentials=AWSCredentials(accessKeyId="fake", secretAccessKey="fake"),
    )
    defaults.update(overrides)
    return CloudConfig(**defaults)


FAKE_GIT_INFO = ("owner/repo", "abc123def456")


def _make_client(handler) -> Client:
    """Create a Client with a mock HTTP transport."""
    client = Client()
    client._http = httpx.Client(
        transport=httpx.MockTransport(handler), base_url="http://test"
    )
    client._default_cloud_config = _aws_config()
    return client


# ---------------------------------------------------------------------------
# _parse_github_repo
# ---------------------------------------------------------------------------


class TestParseGithubRepo:
    def test_https_with_git_suffix(self):
        assert _parse_github_repo("https://github.com/owner/repo.git") == "owner/repo"

    def test_https_without_suffix(self):
        assert _parse_github_repo("https://github.com/owner/repo") == "owner/repo"

    def test_ssh(self):
        assert _parse_github_repo("git@github.com:owner/repo.git") == "owner/repo"

    def test_ssh_without_suffix(self):
        assert _parse_github_repo("git@github.com:owner/repo") == "owner/repo"

    def test_non_github(self):
        assert _parse_github_repo("https://gitlab.com/owner/repo.git") is None

    def test_malformed(self):
        assert _parse_github_repo("not-a-url") is None

    def test_with_trailing_whitespace(self):
        assert _parse_github_repo("  https://github.com/owner/repo.git  ") == "owner/repo"


# ---------------------------------------------------------------------------
# Module-level decorator
# ---------------------------------------------------------------------------


class TestDecorator:
    def test_returns_function_object(self):
        @anycloud.function(image="python:3.11")
        def my_fn(x: int) -> int:
            return x * 2

        assert isinstance(my_fn, Function)

    def test_preserves_name(self):
        @anycloud.function(image="python:3.11")
        def my_fn(x: int) -> int:
            """My docstring."""
            return x * 2

        assert my_fn.__name__ == "my_fn"
        assert my_fn.__doc__ == "My docstring."

    def test_local_call(self):
        @anycloud.function(image="python:3.11")
        def add(a: int, b: int) -> int:
            return a + b

        assert add(2, 3) == 5

    def test_repr(self):
        @anycloud.function(image="pytorch:2.1", gpu="h100:8")
        def train(lr: float) -> dict:
            return {}

        r = repr(train)
        assert "train" in r
        assert "pytorch:2.1" in r

    def test_noop_when_running_remotely(self):
        """When _ANYCLOUD_FN is set, decorator returns the raw function."""
        with patch.dict(os.environ, {"_ANYCLOUD_FN": "{}"}):
            @anycloud.function(image="python:3.11")
            def my_fn(x: int) -> int:
                return x * 2

            assert not isinstance(my_fn, Function)
            assert callable(my_fn)
            assert my_fn(5) == 10


# ---------------------------------------------------------------------------
# Function.submit()
# ---------------------------------------------------------------------------


class TestSubmit:
    def test_submit_sends_correct_env_vars(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "fn-123"})

        def my_fn(x: int) -> int:
            return x * 2

        fn = Function(
            fn=my_fn, image="python:3.11", gpu="h100:1",
            cloud_config=_aws_config(),
            _client=_make_client(handler), _git_info=FAKE_GIT_INFO,
        )
        job = fn.submit(42)

        body = captured["body"]
        assert body["image"] == "python:3.11"
        assert body["gpuType"] == "h100:1"
        fn_config = json.loads(body["env"]["_ANYCLOUD_FN"])
        assert fn_config["repo"] == "owner/repo"
        assert fn_config["commit"] == "abc123def456"
        assert "test_function" in fn_config["module"]
        assert fn_config["name"] == "my_fn"
        assert fn_config["args"] == [42]
        assert fn_config["kwargs"] == {}
        assert body["command"][0] == "python"
        assert body["command"][1] == "-c"

    def test_submit_merges_user_env(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "fn-456"})

        def my_fn() -> None:
            pass

        fn = Function(
            fn=my_fn, image="python:3.11",
            env={"MY_VAR": "hello"}, cloud_config=_aws_config(),
            _client=_make_client(handler), _git_info=FAKE_GIT_INFO,
        )
        fn.submit()

        env = captured["body"]["env"]
        assert env["MY_VAR"] == "hello"
        assert "_ANYCLOUD_FN" in env

    def test_submit_with_kwargs(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "fn-789"})

        def my_fn(a: int, b: str = "default") -> None:
            pass

        fn = Function(
            fn=my_fn, image="python:3.11", cloud_config=_aws_config(),
            _client=_make_client(handler), _git_info=FAKE_GIT_INFO,
        )
        fn.submit(1, b="custom")

        fn_config = json.loads(captured["body"]["env"]["_ANYCLOUD_FN"])
        assert fn_config["args"] == [1]
        assert fn_config["kwargs"] == {"b": "custom"}

    def test_submit_passes_input_output_buckets(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "fn-bucket"})

        def my_fn() -> None:
            pass

        cc = _aws_config(inputBucket="my-input", outputBucket="my-output")
        fn = Function(
            fn=my_fn, image="python:3.11", cloud_config=cc,
            _client=_make_client(handler), _git_info=FAKE_GIT_INFO,
        )
        fn.submit()

        body = captured["body"]
        assert body["cloudConfig"]["inputBucket"] == "my-input"
        assert body["cloudConfig"]["outputBucket"] == "my-output"

    def test_submit_with_id(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "custom-id-123"})

        def my_fn(x: int) -> int:
            return x

        fn = Function(
            fn=my_fn, image="python:3.11", cloud_config=_aws_config(),
            _client=_make_client(handler), _git_info=FAKE_GIT_INFO,
        )
        fn.submit(42, id="custom-id-123")

        body = captured["body"]
        assert body["id"] == "custom-id-123"
        fn_config = json.loads(body["env"]["_ANYCLOUD_FN"])
        assert fn_config["args"] == [42]

    def test_submit_without_id(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "auto-id"})

        def my_fn() -> None:
            pass

        fn = Function(
            fn=my_fn, image="python:3.11", cloud_config=_aws_config(),
            _client=_make_client(handler), _git_info=FAKE_GIT_INFO,
        )
        fn.submit()

        assert "id" not in captured["body"]

    def test_submit_with_per_submit_env(self):
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "fn-env"})

        def my_fn() -> None:
            pass

        fn = Function(
            fn=my_fn, image="python:3.11",
            env={"BASE_VAR": "base", "OVERRIDE_ME": "old"},
            cloud_config=_aws_config(),
            _client=_make_client(handler), _git_info=FAKE_GIT_INFO,
        )
        fn.submit(env={"OVERRIDE_ME": "new", "EXTRA": "extra"})

        env = captured["body"]["env"]
        assert env["BASE_VAR"] == "base"
        assert env["OVERRIDE_ME"] == "new"
        assert env["EXTRA"] == "extra"
        assert "_ANYCLOUD_FN" in env


# ---------------------------------------------------------------------------
# Parameter collision detection
# ---------------------------------------------------------------------------


class TestCollisionDetection:
    def test_rejects_id_parameter(self):
        with pytest.raises(ValueError, match="'id' conflicts"):
            @anycloud.function(image="python:3.11")
            def my_fn(id: str) -> None:
                pass

    def test_rejects_env_parameter(self):
        with pytest.raises(ValueError, match="'env' conflicts"):
            @anycloud.function(image="python:3.11")
            def my_fn(env: dict) -> None:
                pass

    def test_allows_other_parameter_names(self):
        @anycloud.function(image="python:3.11")
        def my_fn(name: str, value: int) -> None:
            pass

        assert isinstance(my_fn, Function)


# ---------------------------------------------------------------------------
# CloudConfig with string credentials
# ---------------------------------------------------------------------------


class TestStringCredentials:
    def test_submit_resolves_string_credentials(self):
        """CloudConfig(credentials='my-cred') resolves via client API."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            if "/v1/credentials/" in str(request.url):
                return httpx.Response(200, json={
                    "cloudProvider": "AWS",
                    "accessKeyId": "resolved-key",
                    "secretAccessKey": "resolved-secret",
                })
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "fn-cred"})

        def my_fn() -> None:
            pass

        cc = CloudConfig(credentials="my-cred", vm_type="t3.large", spot=True)
        fn = Function(
            fn=my_fn, image="python:3.11", cloud_config=cc,
            _client=_make_client(handler), _git_info=FAKE_GIT_INFO,
        )
        fn.submit()

        body = captured["body"]
        assert body["credentialName"] == "my-cred"
        assert body["cloudConfig"]["vmType"] == "t3.large"
        assert body["cloudConfig"]["spot"] is True
        # Resolved credentials should be present
        assert body["cloudConfig"]["cloudProvider"] == "AWS"

    def test_string_credentials_cached(self):
        """String credential resolution is cached across submit calls."""
        call_count = {"cred": 0, "submit": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            if "/v1/credentials/" in str(request.url):
                call_count["cred"] += 1
                return httpx.Response(200, json={
                    "cloudProvider": "AWS",
                    "accessKeyId": "key",
                    "secretAccessKey": "secret",
                })
            call_count["submit"] += 1
            return httpx.Response(200, json={"id": f"fn-{call_count['submit']}"})

        def my_fn() -> None:
            pass

        cc = CloudConfig(credentials="cached-cred")
        fn = Function(
            fn=my_fn, image="python:3.11", cloud_config=cc,
            _client=_make_client(handler), _git_info=FAKE_GIT_INFO,
        )
        fn.submit()
        fn.submit()

        assert call_count["cred"] == 1  # resolved only once
        assert call_count["submit"] == 2

    def test_object_credentials_no_resolution(self):
        """CloudConfig with credential objects skips resolution."""
        captured = {}

        def handler(request: httpx.Request) -> httpx.Response:
            if "/v1/credentials/" in str(request.url):
                pytest.fail("Should not resolve credentials by name")
            captured["body"] = json.loads(request.content)
            return httpx.Response(200, json={"id": "fn-obj"})

        def my_fn() -> None:
            pass

        cc = _aws_config(vmType="m5.large")
        fn = Function(
            fn=my_fn, image="python:3.11", cloud_config=cc,
            _client=_make_client(handler), _git_info=FAKE_GIT_INFO,
        )
        fn.submit()

        assert captured["body"]["cloudConfig"]["vmType"] == "m5.large"


# ---------------------------------------------------------------------------
# CloudConfig.with_overrides
# ---------------------------------------------------------------------------


class TestCloudConfigWithOverrides:
    def test_basic_override(self):
        cc = _aws_config(vmType="t3.large")
        cc2 = cc.with_overrides(vm_type="m5.xlarge", spot=True)

        assert cc2.vm_type == "m5.xlarge"
        assert cc2.spot is True
        # Original unchanged
        assert cc.vm_type == "t3.large"
        assert cc.spot is None

    def test_override_credentials_to_string(self):
        cc = _aws_config()
        cc2 = cc.with_overrides(credentials="other-cred")

        assert cc2.credentials == "other-cred"
        # Original unchanged
        assert isinstance(cc.credentials, AWSCredentials)

    def test_override_buckets(self):
        cc = _aws_config()
        cc2 = cc.with_overrides(input_bucket="in", output_bucket="out")

        assert cc2.input_bucket == "in"
        assert cc2.output_bucket == "out"


# ---------------------------------------------------------------------------
# Auto-client
# ---------------------------------------------------------------------------


class TestAutoClient:
    def test_missing_token_raises(self, tmp_path):
        """_get_default_client() without GITHUB_TOKEN should raise ValueError."""
        fn_mod._default_client = None  # reset singleton

        with patch.dict(os.environ, {"ANYCLOUD_DIR": str(tmp_path)}, clear=True):
            with pytest.raises(ValueError, match="No authentication token found"):
                _get_default_client()

        fn_mod._default_client = None  # cleanup


# ---------------------------------------------------------------------------
# Git detection
# ---------------------------------------------------------------------------


class TestGitDetection:
    def test_detect_git_info_not_a_repo(self, tmp_path):
        with pytest.raises(RuntimeError, match="Could not detect git remote"):
            _detect_git_info(str(tmp_path))

    def test_detect_git_info_success(self, tmp_path):
        """Create a real git repo and verify detection."""
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True, check=True)
        subprocess.run(
            ["git", "remote", "add", "origin", "https://github.com/test/repo.git"],
            cwd=tmp_path, capture_output=True, check=True,
        )
        # Create an initial commit
        (tmp_path / "test.py").write_text("x = 1")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True, check=True)
        subprocess.run(
            ["git", "commit", "-m", "init", "--no-gpg-sign"],
            cwd=tmp_path, capture_output=True, check=True,
            env={**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "test@test.com",
                 "GIT_COMMITTER_NAME": "Test", "GIT_COMMITTER_EMAIL": "test@test.com"},
        )

        repo, commit = _detect_git_info(str(tmp_path))
        assert repo == "test/repo"
        assert len(commit) == 40  # full SHA

    def test_warns_on_uncommitted_changes(self, tmp_path):
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True, check=True)
        subprocess.run(
            ["git", "remote", "add", "origin", "https://github.com/test/repo.git"],
            cwd=tmp_path, capture_output=True, check=True,
        )
        (tmp_path / "test.py").write_text("x = 1")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True, check=True)
        subprocess.run(
            ["git", "commit", "-m", "init", "--no-gpg-sign"],
            cwd=tmp_path, capture_output=True, check=True,
            env={**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "test@test.com",
                 "GIT_COMMITTER_NAME": "Test", "GIT_COMMITTER_EMAIL": "test@test.com"},
        )
        # Make an uncommitted change
        (tmp_path / "test.py").write_text("x = 2")

        with pytest.warns(UserWarning, match="uncommitted changes"):
            _detect_git_info(str(tmp_path))

    def test_non_github_remote_raises(self, tmp_path):
        subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True, check=True)
        subprocess.run(
            ["git", "remote", "add", "origin", "https://gitlab.com/test/repo.git"],
            cwd=tmp_path, capture_output=True, check=True,
        )
        (tmp_path / "test.py").write_text("x = 1")
        subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True, check=True)
        subprocess.run(
            ["git", "commit", "-m", "init", "--no-gpg-sign"],
            cwd=tmp_path, capture_output=True, check=True,
            env={**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "test@test.com",
                 "GIT_COMMITTER_NAME": "Test", "GIT_COMMITTER_EMAIL": "test@test.com"},
        )

        with pytest.raises(RuntimeError, match="Could not parse GitHub repo"):
            _detect_git_info(str(tmp_path))


# ---------------------------------------------------------------------------
# Bootstrap script (subprocess execution)
# ---------------------------------------------------------------------------


class TestBootstrap:
    def _run_bootstrap(self, tmp_path, module_code, fn_name, args, kwargs=None):
        """Helper: run a mini bootstrap in a subprocess, skipping git clone."""
        app_dir = tmp_path / "app"
        app_dir.mkdir()
        (app_dir / "my_module.py").write_text(module_code)

        config = {
            "module": "my_module",
            "name": fn_name,
            "args": args,
            "kwargs": kwargs or {},
        }

        bootstrap = textwrap.dedent(f"""\
            import importlib, json, os, sys, types

            config = json.loads(os.environ["_ANYCLOUD_FN"])

            # Stub anycloud (simulates real container where anycloud is not installed)
            stub = types.ModuleType("anycloud")
            stub.__path__ = []
            stub.function = lambda **kw: lambda fn: fn
            sys.modules["anycloud"] = stub

            sys.path.insert(0, {str(app_dir)!r})

            mod = importlib.import_module(config["module"])
            fn = getattr(mod, config["name"])

            fn(*config["args"], **config["kwargs"])
        """)

        return subprocess.run(
            [sys.executable, "-c", bootstrap],
            capture_output=True,
            text=True,
            env={**os.environ, "_ANYCLOUD_FN": json.dumps(config)},
        )

    def test_bootstrap_success(self, tmp_path):
        result = self._run_bootstrap(
            tmp_path,
            "def my_fn(x):\n    print(f'result: {x * 2}')\n",
            "my_fn",
            [21],
        )

        assert result.returncode == 0
        assert "result: 42" in result.stdout

    def test_bootstrap_with_decorator(self, tmp_path):
        """The @anycloud.function() decorator becomes a no-op in the bootstrap."""
        module_code = textwrap.dedent("""\
            import anycloud

            @anycloud.function(image="python:3.11")
            def my_fn(x):
                print(f"doubled: {x * 2}")
        """)
        result = self._run_bootstrap(tmp_path, module_code, "my_fn", [21])

        assert result.returncode == 0, f"stderr: {result.stderr}"
        assert "doubled: 42" in result.stdout

    def test_bootstrap_exception(self, tmp_path):
        result = self._run_bootstrap(
            tmp_path,
            "def my_fn(x):\n    raise ValueError('test error')\n",
            "my_fn",
            [1],
        )

        assert result.returncode == 1
