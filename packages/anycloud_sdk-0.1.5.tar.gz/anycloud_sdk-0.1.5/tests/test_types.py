"""Tests for anycloud.types Pydantic models."""

import pytest
from pydantic import ValidationError

from anycloud.types import CloudConfig


def test_cloud_config_rejects_unknown_fields():
    with pytest.raises(ValidationError, match="extra_forbidden"):
        CloudConfig(vm_typ="bogus")


def test_cloud_config_accepts_known_aliases():
    cc = CloudConfig(vmType="t3.micro", inputStorageRegion="us-east-1")
    assert cc.vm_type == "t3.micro"
    assert cc.input_storage_region == "us-east-1"
