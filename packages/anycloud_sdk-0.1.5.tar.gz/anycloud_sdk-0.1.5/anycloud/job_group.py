"""JobGroup — manage a batch of Jobs."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Iterator

from anycloud.errors import JobGroupError
from anycloud.job import Job


class JobGroup:
    """A thin wrapper around a list of :class:`Job` instances.

    Provides parallel ``wait_all()`` and ``terminate_all()`` so you don't
    have to manage threads yourself.

    Usage::

        jobs = JobGroup([client.submit("img:latest", ...) for _ in range(4)])
        jobs.wait_all()           # blocks until every job finishes
        jobs.terminate_all()      # kill everything
    """

    def __init__(self, jobs: list[Job]):
        self._jobs = list(jobs)

    # ------------------------------------------------------------------
    # Sequence protocol
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._jobs)

    def __iter__(self) -> Iterator[Job]:
        return iter(self._jobs)

    def __getitem__(self, index: int) -> Job:
        return self._jobs[index]

    # ------------------------------------------------------------------
    # Parallel wait
    # ------------------------------------------------------------------

    def wait_all(
        self,
        *,
        timeout: float | None = None,
        poll_interval: float = 2.0,
        max_workers: int | None = None,
    ) -> JobGroup:
        """Block until every job reaches a terminal state.

        Polls all jobs in parallel using a thread pool.

        Returns ``self`` if all jobs completed successfully.
        Raises :class:`~anycloud.errors.JobGroupError` if any job failed
        (all jobs are still awaited before the error is raised).

        Args:
            timeout: Per-job timeout in seconds (``None`` = no limit).
            poll_interval: Seconds between status polls per job.
            max_workers: Thread pool size (defaults to number of jobs).
        """
        workers = max_workers or len(self._jobs)
        errors: list[tuple[str, Exception]] = []

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(
                    job.wait, timeout=timeout, poll_interval=poll_interval
                ): job
                for job in self._jobs
            }
            for future in as_completed(futures):
                job = futures[future]
                try:
                    future.result()
                except Exception as exc:
                    errors.append((job.id, exc))

        if errors:
            raise JobGroupError(errors)
        return self

    # ------------------------------------------------------------------
    # Parallel terminate
    # ------------------------------------------------------------------

    def terminate_all(self, *, max_workers: int | None = None) -> None:
        """Terminate every job in parallel."""
        workers = max_workers or len(self._jobs)
        with ThreadPoolExecutor(max_workers=workers) as pool:
            list(pool.map(lambda j: j.terminate(), self._jobs))

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @property
    def ids(self) -> list[str]:
        """Deployment IDs of all jobs in the group."""
        return [j.id for j in self._jobs]

    def __repr__(self) -> str:
        return f"JobGroup({self.ids})"
