"""anycloud Image — programmatic Dockerfile builder."""

from __future__ import annotations

import hashlib
from pathlib import Path


class Image:
    """Chainable Dockerfile builder.

    Each method returns a **new** ``Image`` (immutable), appending one or more
    Dockerfile instructions.  Call :meth:`to_dockerfile` to render the full
    Dockerfile string, or pass the ``Image`` directly to
    :meth:`Client.build`.

    Example::

        image = (
            anycloud.Image("python:3.11", repository="ghcr.io/user/train")
            .pip_install("torch", "transformers")
            .apt_install("curl", "git")
            .env({"HF_HOME": "/root/models"})
            .workdir("/app")
            .run_commands("git clone https://github.com/org/repo.git")
        )
    """

    def __init__(self, base: str = "python:3.11", *, repository: str | None = None) -> None:
        if not base or not base.strip():
            raise ValueError("base image is required (e.g. 'python:3.11')")
        self._base = base
        self._steps: list[str] = []
        self._repository = repository

    # -- factory methods ----------------------------------------------------

    @classmethod
    def debian_slim(
        cls, python_version: str = "3.11", *, repository: str | None = None
    ) -> Image:
        """Create an Image from the official Python slim Debian base.

        Example::

            image = Image.debian_slim("3.12").pip_install("torch")
        """
        return cls(f"python:{python_version}-slim", repository=repository)

    @classmethod
    def from_dockerfile(
        cls, path: str | Path, *, repository: str | None = None
    ) -> Image:
        """Load a Dockerfile from disk and return a chainable ``Image``.

        The ``FROM`` line becomes the base image; all subsequent lines become
        steps that can be extended with builder methods.

        Example::

            image = Image.from_dockerfile("./Dockerfile").pip_install("extra")
        """
        text = Path(path).read_text()
        lines = [l for l in text.strip().splitlines() if l.strip()]
        if not lines or not lines[0].upper().startswith("FROM "):
            raise ValueError(
                f"Dockerfile at {path} must start with a FROM instruction"
            )
        base = lines[0].split(None, 1)[1]
        img = cls(base, repository=repository)
        img._steps = [l for l in lines[1:]]
        return img

    # -- internal helpers ---------------------------------------------------

    def _copy(self, step: str) -> Image:
        """Return a new Image with *step* appended."""
        img = Image.__new__(Image)
        img._base = self._base
        img._steps = [*self._steps, step]
        img._repository = self._repository
        return img

    # -- builder methods ----------------------------------------------------

    def pip_install(self, *packages: str) -> Image:
        """``RUN pip install --no-cache-dir pkg1 pkg2 ...``"""
        if not packages:
            raise ValueError("pip_install requires at least one package")
        return self._copy(f"RUN pip install --no-cache-dir {' '.join(packages)}")

    def apt_install(self, *packages: str) -> Image:
        """``RUN apt-get update && apt-get install -y ... && cleanup``"""
        if not packages:
            raise ValueError("apt_install requires at least one package")
        pkgs = " ".join(packages)
        return self._copy(
            f"RUN apt-get update && apt-get install -y {pkgs} "
            f"&& rm -rf /var/lib/apt/lists/*"
        )

    def run_commands(self, *commands: str) -> Image:
        """``RUN cmd1 && cmd2 && ...``"""
        if not commands:
            raise ValueError("run_commands requires at least one command")
        return self._copy(f"RUN {' && '.join(commands)}")

    def env(self, variables: dict[str, str]) -> Image:
        """``ENV KEY=VALUE`` for each entry."""
        if not variables:
            raise ValueError("env requires at least one variable")
        lines = " ".join(f'{k}="{v}"' for k, v in variables.items())
        return self._copy(f"ENV {lines}")

    def workdir(self, path: str) -> Image:
        """``WORKDIR /path``"""
        return self._copy(f"WORKDIR {path}")

    # -- rendering ----------------------------------------------------------

    def to_dockerfile(self) -> str:
        """Render the full Dockerfile string."""
        parts = [f"FROM {self._base}"]
        parts.extend(self._steps)
        return "\n".join(parts) + "\n"

    @property
    def ref(self) -> str:
        """Full image reference (``repository:content_hash``).

        The tag is a SHA-256 hash of the Dockerfile content, enabling
        deterministic caching — same Image definition produces the same ref.

        Raises:
            ValueError: If no ``repository`` was set on this Image.
        """
        if not self._repository:
            raise ValueError(
                "repository is required to generate an image ref. "
                "Pass repository='ghcr.io/owner/repo' to Image()."
            )
        digest = hashlib.sha256(self.to_dockerfile().encode()).hexdigest()[:12]
        return f"{self._repository}:{digest}"
