"""anycloud SDK types."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class CloudType(str, Enum):
    AWS = "AWS"
    GCP = "GCP"
    Azure = "Azure"
    Lambda = "Lambda"
    Local = "Local"


class DeploymentState(str, Enum):
    Queued = "queued"
    Provisioning = "provisioning"
    Initializing = "initializing"
    Downloading = "downloading"
    Syncing = "syncing"
    Starting = "starting"
    Running = "running"
    Retrying = "retrying"
    Recovering = "recovering"
    Completed = "completed"
    Errored = "errored"
    Failed = "failed"
    Invalid = "invalid"
    Terminated = "terminated"

    @property
    def is_terminal(self) -> bool:
        return self in _TERMINAL_STATES


_TERMINAL_STATES = {
    DeploymentState.Completed,
    DeploymentState.Errored,
    DeploymentState.Failed,
    DeploymentState.Invalid,
    DeploymentState.Terminated,
}

_SUCCESS_STATES = {DeploymentState.Completed}


class DockerOptions(BaseModel):
    shm_size: str | None = Field(None, alias="shmSize")
    gpus: str | None = None
    ipc: str | None = None
    ulimits: list[str] | None = None
    memory: str | None = None
    cpus: str | None = None
    runtime: str | None = None
    binds: list[str] | None = None

    model_config = {"populate_by_name": True}


class AWSCredentials(BaseModel):
    cloud_provider: str = Field("AWS", alias="cloudProvider")
    access_key_id: str = Field(alias="accessKeyId")
    secret_access_key: str = Field(alias="secretAccessKey")

    model_config = {"populate_by_name": True}


class GCPCredentials(BaseModel):
    cloud_provider: str = Field("GCP", alias="cloudProvider")
    project_id: str = Field(alias="projectId")
    private_key: str = Field(alias="privateKey")
    client_email: str = Field(alias="clientEmail")

    model_config = {"populate_by_name": True}


class AzureCredentials(BaseModel):
    cloud_provider: str = Field("Azure", alias="cloudProvider")
    application_id: str = Field(alias="applicationId")
    secret: str
    directory_id: str = Field(alias="directoryId")
    subscription_id: str = Field(alias="subscriptionId")

    model_config = {"populate_by_name": True}


class LambdaCredentials(BaseModel):
    cloud_provider: str = Field("Lambda", alias="cloudProvider")
    api_key: str = Field(alias="apiKey")

    model_config = {"populate_by_name": True}


CloudCredentials = AWSCredentials | GCPCredentials | AzureCredentials | LambdaCredentials


class CloudConfig(BaseModel):
    cloud_provider: CloudType | None = Field(None, alias="cloudProvider")
    region: str | None = None
    vm_type: str | None = Field(None, alias="vmType")
    credentials: str | CloudCredentials | None = None
    input_storage_credentials: CloudCredentials | None = Field(None, alias="inputStorageCredentials")
    input_storage_region: str | None = Field(None, alias="inputStorageRegion")
    output_storage_credentials: CloudCredentials | None = Field(None, alias="outputStorageCredentials")
    output_storage_region: str | None = Field(None, alias="outputStorageRegion")
    min_vm_count: int | None = Field(None, alias="minVmCount")
    max_vm_count: int | None = Field(None, alias="maxVmCount")
    spot: bool | None = None
    input_bucket: str | None = Field(None, alias="inputBucket")
    output_bucket: str | None = Field(None, alias="outputBucket")
    disk_size_gb: int | None = Field(None, alias="diskSizeGb")
    availability_zone: str | None = Field(None, alias="availabilityZone")

    model_config = {"populate_by_name": True, "extra": "forbid"}

    def with_overrides(self, **kwargs: Any) -> CloudConfig:
        """Return a copy with the given fields overridden."""
        return self.model_copy(update=kwargs)


class ContainerStatus(BaseModel):
    state: str
    exit_code: int | None = Field(None, alias="exitCode")
    oom_killed: bool | None = Field(None, alias="oomKilled")
    logs: str | None = None
    uptime: str | None = None

    model_config = {"populate_by_name": True}


class DeploymentEvent(BaseModel):
    id: int
    deployment_id: str = Field(alias="deploymentId")
    state: DeploymentState
    metadata: dict[str, Any] | None = None
    created_at: int = Field(alias="createdAt")

    model_config = {"populate_by_name": True}


class StatusResponse(BaseModel):
    events: list[DeploymentEvent]
    status: str
    vm_statuses: list[dict[str, Any]] | None = Field(None, alias="vmStatuses")
    ssh_private_key: str | None = Field(None, alias="sshPrivateKey")

    model_config = {"populate_by_name": True}


class Deployment(BaseModel):
    """A stored deployment as returned by /v1/list."""

    id: str
    user_id: str = Field(alias="userId")
    deployment_type: str = Field(alias="deploymentType")
    image: str
    cloud_provider: CloudType = Field(alias="cloudProvider")
    region: str | None = None
    vm_type: str | None = Field(None, alias="vmType")
    gpu_type: str | None = Field(None, alias="gpuType")
    spot: bool
    persist: bool
    state: DeploymentState
    started_at: int = Field(alias="startedAt")
    completed_at: int | None = Field(None, alias="completedAt")
    input_bucket: str | None = Field(None, alias="inputBucket")
    output_bucket: str | None = Field(None, alias="outputBucket")
    version: str | None = None
    docker_command: str = Field(alias="dockerCommand")
    disk_size_gb: int | None = Field(None, alias="diskSizeGb")
    docker_options: DockerOptions | None = Field(None, alias="dockerOptions")
    availability_zone: str | None = Field(None, alias="availabilityZone")
    env: dict[str, str] | None = None
    github_token: str | None = Field(None, alias="githubToken")
    vm_count: int = Field(alias="vmCount")
    ssh_private_key: str = Field(alias="sshPrivateKey")
    credential_id: str = Field(alias="credentialId")
    input_storage_credential_id: str | None = Field(None, alias="inputStorageCredentialId")
    input_storage_region: str | None = Field(None, alias="inputStorageRegion")
    output_storage_credential_id: str | None = Field(None, alias="outputStorageCredentialId")
    output_storage_region: str | None = Field(None, alias="outputStorageRegion")
    command: list[str] | None = None
    image_digest: str | None = Field(None, alias="imageDigest")
    price_per_hour: float | None = Field(None, alias="pricePerHour")
    vm_duration_ms: int | None = Field(None, alias="vmDurationMs")

    model_config = {"populate_by_name": True}
