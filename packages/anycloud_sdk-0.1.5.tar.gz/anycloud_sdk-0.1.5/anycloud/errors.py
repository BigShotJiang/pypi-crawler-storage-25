"""anycloud SDK exceptions."""


class AnyCloudError(Exception):
    """Base exception for anycloud SDK."""


class APIError(AnyCloudError):
    """HTTP error from the API server."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        super().__init__(f"[{status_code}] {message}")


class ConflictError(APIError):
    """Deployment ID already exists (409)."""

    def __init__(self, message: str = "Deployment ID already exists"):
        super().__init__(409, message)


class NotFoundError(APIError):
    """Deployment not found (404)."""

    def __init__(self, message: str = "Deployment not found"):
        super().__init__(404, message)


class JobFailedError(AnyCloudError):
    """Job reached a terminal failure state.

    Attributes:
        job_id: The deployment ID.
        state: Terminal state the job reached (e.g. ``"errored"``).
        logs: Last container output captured before the error, or ``None``.
    """

    def __init__(
        self,
        job_id: str,
        state: str,
        message: str | None = None,
        logs: str | None = None,
    ):
        self.job_id = job_id
        self.state = state
        self.logs = logs
        detail = f": {message}" if message else ""
        if logs:
            detail += f"\n--- container logs ---\n{logs}"
        super().__init__(f"Job {job_id} {state}{detail}")


class JobGroupError(AnyCloudError):
    """One or more jobs in a group failed.

    Attributes:
        errors: List of ``(job_id, exception)`` tuples for every failed job.
    """

    def __init__(self, errors: list[tuple[str, Exception]]):
        self.errors = errors
        ids = ", ".join(jid for jid, _ in errors)
        super().__init__(f"{len(errors)} job(s) failed: {ids}")


class TimeoutError(AnyCloudError):
    """Operation timed out."""
