"""anycloud MCP server — exposes SDK functionality as MCP tools.

Run via: python -m anycloud.mcp
"""

from __future__ import annotations

import json
import subprocess
import time
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from anycloud.client import Client, _SDK_VERSION
from anycloud.job import Job

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _client() -> Client:
    """Return a ready-to-use SDK Client (token resolved automatically)."""
    return Client()


def _now_ms() -> int:
    return int(time.time() * 1000)


def _find_docs_dir() -> Path:
    """Resolve the docs/ directory."""
    repo_docs = Path(__file__).resolve().parent.parent.parent / "docs"
    if repo_docs.is_dir():
        return repo_docs
    raise FileNotFoundError("Cannot locate docs/ directory")


def _dump(obj: Any) -> str:
    """Serialize to JSON, handling pydantic models."""
    if hasattr(obj, "model_dump"):
        return json.dumps(obj.model_dump(by_alias=True), indent=2, default=str)
    if isinstance(obj, list) and obj and hasattr(obj[0], "model_dump"):
        return json.dumps([d.model_dump(by_alias=True) for d in obj], indent=2, default=str)
    return json.dumps(obj, indent=2, default=str)


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

mcp = FastMCP("anycloud")


# --- Docs resource ---


@mcp.resource("anycloud://docs/{path}")
def read_doc(path: str) -> str:
    """Read an anycloud documentation page."""
    return (_find_docs_dir() / f"{path}.md").read_text()


# --- Catalog tools ---


@mcp.tool()
def list_regions(cloud_provider: str) -> str:
    """List available cloud regions for a provider (AWS, GCP, Azure, Lambda)."""
    return _dump(_client().get_regions(cloud_provider))


@mcp.tool()
def list_vm_types(
    cloud_provider: str,
    region: str,
    accelerator: str | None = None,
) -> str:
    """List available VM types for a provider and region. Use accelerator to filter by GPU (e.g. "H100", "A100", or "*" for all GPUs)."""
    return _dump(_client().get_vm_types(cloud_provider, region, accelerator=accelerator))


@mcp.tool()
def list_zones(region: str) -> str:
    """List available GCP zone suffixes for a region."""
    return _dump(_client().get_zones(region))


@mcp.tool()
def list_regions_for_vm_type(
    vm_type: str,
    cloud_provider: str,
    spot: bool = False,
) -> str:
    """List regions where a VM type is available, sorted by price (US regions first)."""
    return _dump(_client().get_regions_for_vm_type(vm_type, cloud_provider, spot=spot))


@mcp.tool()
def get_pricing(
    vm_type: str,
    cloud_provider: str,
    region: str | None = None,
    spot: bool = False,
) -> str:
    """Get pricing for a VM type across regions (or for a specific region)."""
    return _dump(_client().get_pricing(vm_type, cloud_provider, region=region, spot=spot))


# --- Credentials tools ---


@mcp.tool()
def credentials_list() -> str:
    """List saved cloud credentials (secrets redacted)."""
    entries = _client().list_credentials()
    if not entries:
        return "No credentials found. Use credentials_new to add cloud provider credentials."
    return _dump(entries)


@mcp.tool()
def credentials_new(
    name: str,
    cloud_provider: str,
    # AWS
    access_key_id: str | None = None,
    secret_access_key: str | None = None,
    # GCP
    project_id: str | None = None,
    client_email: str | None = None,
    private_key: str | None = None,
    # Azure
    application_id: str | None = None,
    secret: str | None = None,
    subscription_id: str | None = None,
    directory_id: str | None = None,
    # Lambda
    api_key: str | None = None,
) -> str:
    """Add new cloud provider credentials."""
    # Collect all non-None provider fields and let the API validate
    credential: dict[str, Any] = {"cloudProvider": cloud_provider}
    for key, val in [
        ("accessKeyId", access_key_id),
        ("secretAccessKey", secret_access_key),
        ("projectId", project_id),
        ("clientEmail", client_email),
        ("privateKey", private_key),
        ("applicationId", application_id),
        ("secret", secret),
        ("subscriptionId", subscription_id),
        ("directoryId", directory_id),
        ("apiKey", api_key),
    ]:
        if val is not None:
            credential[key] = val

    _client().save_credential(name, credential)
    return f'Credential "{name}" saved successfully for {cloud_provider}.'


@mcp.tool()
def credentials_delete(name: str) -> str:
    """Delete a saved credential set."""
    _client().delete_credential(name)
    return f'Credential "{name}" deleted successfully.'


# --- Deployment tools ---


@mcp.tool()
def submit(
    image: str,
    credentials: str,
    id: str | None = None,
    region: str | None = None,
    vm_type: str | None = None,
    spot: bool | None = None,
    disk_size_gb: int | None = None,
    input_bucket: str | None = None,
    output_bucket: str | None = None,
    input_storage_credentials: str | None = None,
    input_storage_region: str | None = None,
    output_storage_credentials: str | None = None,
    output_storage_region: str | None = None,
    availability_zone: str | None = None,
    env: dict[str, str] | None = None,
    persist: bool = False,
    command: list[str] | None = None,
    gpus: str | None = None,
    memory: str | None = None,
    cpus: str | None = None,
    shm_size: str | None = None,
    ipc: str | None = None,
    runtime: str | None = None,
) -> str:
    """Submit a containerized job to run on cloud infrastructure."""
    client = _client()
    cred = client.get_credential(credentials)

    cloud_config: dict[str, Any] = {"cloudProvider": cred["cloudProvider"]}
    for key, val in [
        ("region", region), ("vmType", vm_type), ("spot", spot),
        ("diskSizeGb", disk_size_gb), ("inputBucket", input_bucket),
        ("outputBucket", output_bucket),
        ("inputStorageRegion", input_storage_region),
        ("outputStorageRegion", output_storage_region),
        ("availabilityZone", availability_zone),
    ]:
        if val is not None:
            cloud_config[key] = val

    docker_fields = [
        ("gpus", gpus), ("memory", memory), ("cpus", cpus),
        ("shmSize", shm_size), ("ipc", ipc), ("runtime", runtime),
    ]
    docker_options = {k: v for k, v in docker_fields if v} or None

    body: dict[str, Any] = {
        "image": image,
        "deploymentType": "job",
        "version": _SDK_VERSION,
        "accessToken": client._access_token,
        "cloudConfig": cloud_config,
        "credentialName": credentials,
    }
    for key, val in [
        ("inputStorageCredentialName", input_storage_credentials),
        ("outputStorageCredentialName", output_storage_credentials),
        ("id", id),
        ("env", env), ("dockerOptions", docker_options), ("command", command),
    ]:
        if val:
            body[key] = val
    if persist:
        body["persist"] = True

    data = client._post("/v1/new", body)
    return f"Job submitted successfully.\nDeployment ID: {data['id']}"


@mcp.tool()
def serve(
    image: str,
    credentials: str,
    id: str | None = None,
    region: str | None = None,
    vm_type: str | None = None,
    disk_size_gb: int | None = None,
    availability_zone: str | None = None,
    env: dict[str, str] | None = None,
    command: list[str] | None = None,
    gpus: str | None = None,
    memory: str | None = None,
    cpus: str | None = None,
    shm_size: str | None = None,
    ipc: str | None = None,
    runtime: str | None = None,
) -> str:
    """Deploy a long-running server accessible at https://<id>.anycloud.sh. The container must listen on port 8088."""
    client = _client()
    cred = client.get_credential(credentials)

    cloud_config: dict[str, Any] = {"cloudProvider": cred["cloudProvider"]}
    for key, val in [
        ("region", region), ("vmType", vm_type),
        ("diskSizeGb", disk_size_gb), ("availabilityZone", availability_zone),
    ]:
        if val is not None:
            cloud_config[key] = val

    docker_fields = [
        ("gpus", gpus), ("memory", memory), ("cpus", cpus),
        ("shmSize", shm_size), ("ipc", ipc), ("runtime", runtime),
    ]
    docker_options = {k: v for k, v in docker_fields if v} or None

    body: dict[str, Any] = {
        "image": image,
        "deploymentType": "server",
        "version": _SDK_VERSION,
        "accessToken": client._access_token,
        "cloudConfig": cloud_config,
        "credentialName": credentials,
    }
    for key, val in [
        ("id", id), ("env", env), ("dockerOptions", docker_options), ("command", command),
    ]:
        if val:
            body[key] = val

    data = client._post("/v1/new", body)
    return f"Server deployed.\nID: {data['id']}\nURL: https://{data['id']}.anycloud.sh"


@mcp.tool(name="list")
def list_deployments(filter: str | None = None) -> str:
    """List all deployments, optionally filtered by id, image, cloud, region, or state (substring match)."""
    deployments = _client().list(limit=0)

    if filter:
        f = filter.lower()
        deployments = [
            d for d in deployments
            if f in d.id.lower()
            or f in d.image.lower()
            or f in (d.cloud_provider or "").lower()
            or f in (d.region or "").lower()
            or f in d.state.lower()
        ]

    if not deployments:
        return f'No deployments matching "{filter}".' if filter else "No deployments found."

    return _dump(deployments)


@mcp.tool()
def cost(id: str | None = None, period: str = "30d") -> str:
    """Get estimated compute costs. Returns deployment data with pricePerHour and vmDurationMs fields for cost calculation. Use period like "7d", "30d", "90d", or "all"."""
    client = _client()
    deployments = client.list(limit=0)
    now = _now_ms()

    if id:
        deployment = next((d for d in deployments if d.id == id), None)
        if not deployment:
            raise ValueError(f'Deployment "{id}" not found.')
        return _dump(deployment)

    # Filter to period window
    if period == "all":
        period_ms = None
    else:
        import re
        m = re.match(r"^(\d+)d$", period)
        if not m:
            raise ValueError(f'Invalid period "{period}". Use "7d", "30d", "90d", or "all".')
        period_ms = int(m.group(1)) * 86_400_000

    window_start = (now - period_ms) if period_ms else 0
    overlapping = [
        d for d in deployments
        if (d.completed_at or now) > window_start and d.started_at < now
    ]

    return _dump(overlapping)


@mcp.tool()
def status(id: str) -> str:
    """Get deployment status, events, and VM details."""
    return _dump(_client()._status(id))


@mcp.tool()
def logs(id: str) -> str:
    """Get container logs for a deployment."""
    output = Job(_client(), id).logs()
    return output or "No logs available yet."


@mcp.tool()
def terminate(id: str) -> str:
    """Terminate a deployment and clean up cloud resources."""
    _client()._terminate(id)
    return f"Deployment {id} termination initiated."


@mcp.tool()
def resubmit(id: str) -> str:
    """Resubmit a failed or completed deployment."""
    _client()._resubmit(id)
    return f"Deployment {id} resubmitted."


@mcp.tool(name="exec")
def exec_command(id: str, command: str) -> str:
    """Execute a command on a running deployment via SSH."""
    return Job(_client(), id).exec(command)


# --- Upgrade tool ---


@mcp.tool()
def upgrade(version: str | None = None) -> str:
    """Upgrade anycloud CLI and restart the API server."""
    lines: list[str] = []

    try:
        cmd = ["anycloud", "update"] + ([version] if version else [])
        subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=120)
        lines.append(f"CLI upgraded{f' to {version}' if version else ' to latest stable'}.")
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"CLI upgrade failed: {e.stderr or e.stdout or str(e)}") from e

    try:
        subprocess.run(["anycloud", "api", "stop"], capture_output=True, text=True, timeout=30)
    except Exception:
        pass

    try:
        subprocess.run(
            ["anycloud", "api", "start"], check=True, capture_output=True, text=True, timeout=60
        )
        lines.append("API server restarted with new version.")
    except Exception as e:
        lines.append(f'Warning: API restart failed: {e}. Run "anycloud api start" manually.')

    lines += ["", "IMPORTANT: Restart the MCP server to pick up the new CLI version."]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
