"""Function decorator for remote execution via git-based code sync."""

from __future__ import annotations

import functools
import inspect
import json
import os
import subprocess
import warnings
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from anycloud.client import Client
    from anycloud.job import Job
    from anycloud.types import CloudConfig

_default_client: Client | None = None

BOOTSTRAP_SCRIPT = r'''
import importlib, json, os, subprocess, sys

def _clone_repo(repo, commit, token):
    if token:
        url = f"https://x-access-token:{token}@github.com/{repo}.git"
    else:
        url = f"https://github.com/{repo}.git"

    try:
        subprocess.run(
            ["git", "clone", "--depth", "1", url, "/app"],
            check=True, capture_output=True, text=True,
        )
    except FileNotFoundError:
        print("ERROR: git is not installed in this container image.", file=sys.stderr)
        print("Use an image that includes git, or add 'apt-get install -y git' to your Dockerfile.", file=sys.stderr)
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        print(f"ERROR: git clone failed: {e.stderr}", file=sys.stderr)
        sys.exit(1)

    # Fetch the specific commit if shallow clone didn't include it
    try:
        subprocess.run(
            ["git", "cat-file", "-t", commit],
            cwd="/app", check=True, capture_output=True,
        )
    except subprocess.CalledProcessError:
        subprocess.run(
            ["git", "fetch", "--depth", "1", "origin", commit],
            cwd="/app", check=True, capture_output=True, text=True,
        )

    subprocess.run(
        ["git", "checkout", commit],
        cwd="/app", check=True, capture_output=True, text=True,
    )

def main():
    config = json.loads(os.environ["_ANYCLOUD_FN"])

    _clone_repo(config["repo"], config["commit"], os.environ.get("GITHUB_TOKEN", ""))

    # Stub the anycloud package so user modules that do `import anycloud`
    # don't fail — the real package isn't installed in the container.
    try:
        import anycloud
    except ImportError:
        import types
        stub = types.ModuleType("anycloud")
        stub.__path__ = []
        stub.function = lambda **kw: lambda fn: fn
        sys.modules["anycloud"] = stub

    module_dir = config.get("module_dir", "")
    sys.path.insert(0, os.path.join("/app", module_dir))
    mod = importlib.import_module(config["module"])
    fn = getattr(mod, config["name"])

    fn(*config["args"], **config["kwargs"])

main()
'''


def _run_git(*args: str, cwd: str | None = None) -> str:
    """Run a git command and return stripped stdout."""
    result = subprocess.run(
        ["git", *args],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {args[0]} failed: {result.stderr.strip()}")
    return result.stdout.strip()


def _detect_git_info(workdir: str) -> tuple[str, str]:
    """Detect GitHub repo and commit from the local git state.

    Returns (repo, commit) where repo is "owner/repo" and commit is a full SHA.
    """
    try:
        remote_url = _run_git("remote", "get-url", "origin", cwd=workdir)
    except RuntimeError:
        raise RuntimeError(
            "Could not detect git remote. Ensure your code is in a git repo "
            "with a GitHub remote named 'origin'."
        )

    repo = _parse_github_repo(remote_url)
    if repo is None:
        raise RuntimeError(
            f"Could not parse GitHub repo from remote URL: {remote_url!r}. "
            "Expected a github.com URL (HTTPS or SSH)."
        )

    commit = _run_git("rev-parse", "HEAD", cwd=workdir)

    # Warn on uncommitted changes
    status = _run_git("status", "--porcelain", cwd=workdir)
    if status:
        warnings.warn(
            "You have uncommitted changes that won't be available remotely. "
            "Commit and push before calling .submit().",
            stacklevel=4,
        )

    # Warn if HEAD is not pushed
    try:
        containing = _run_git(
            "branch", "-r", "--contains", "HEAD", cwd=workdir
        )
        if not containing:
            warnings.warn(
                "Current commit has not been pushed to the remote. "
                "Push before calling .submit().",
                stacklevel=4,
            )
    except RuntimeError:
        # git branch -r --contains can fail in detached HEAD or shallow clones
        pass

    return repo, commit


def _parse_github_repo(url: str) -> str | None:
    """Extract 'owner/repo' from a GitHub URL (HTTPS or SSH)."""
    url = url.strip()
    if url.endswith(".git"):
        url = url[:-4]

    # Normalize SSH format (github.com:owner/repo) to match HTTPS
    url = url.replace("github.com:", "github.com/")

    if "github.com/" in url:
        segments = url.split("github.com/", 1)[1].split("/")
        if len(segments) >= 2:
            return f"{segments[0]}/{segments[1]}"

    return None


def _get_default_client() -> Client:
    """Return a cached default Client, created from environment variables."""
    global _default_client
    if _default_client is None:
        from anycloud.client import Client

        _default_client = Client()
    return _default_client


def function(
    *,
    image: str,
    gpu: str | None = None,
    env: dict[str, str] | None = None,
    cloud_config: CloudConfig | None = None,
    docker_options: dict[str, Any] | None = None,
):
    """Decorator that wraps a Python function for remote execution.

    Usage::

        import anycloud

        @anycloud.function(image="pytorch:2.1", gpu="h100:8")
        def train(lr: float):
            ...

        job = train.submit(0.001)
        job.wait()

    Args:
        image: Docker image reference for the remote container.
        gpu: GPU type shorthand (e.g. ``"h100:8"``).
        env: Extra environment variables passed to the container.
        cloud_config: ``CloudConfig`` for this function's submissions.
            Use ``input_bucket`` and ``output_bucket`` fields to mount
            cloud storage at ``/mnt/input`` and ``/mnt/output``.
        docker_options: Docker runtime options (shmSize, gpus, etc.).
    """
    def decorator(fn):
        if os.environ.get("_ANYCLOUD_FN"):
            return fn
        return Function(
            fn=fn,
            image=image,
            gpu=gpu,
            env=env,
            cloud_config=cloud_config,
            docker_options=docker_options,
        )
    return decorator


class Function:
    """A Python function wrapped for remote execution.

    Returned by :func:`anycloud.function`. Use ``fn.submit(args)``
    for remote execution.
    """

    def __init__(
        self,
        *,
        fn: Any,
        image: str,
        gpu: str | None = None,
        env: dict[str, str] | None = None,
        cloud_config: CloudConfig | None = None,
        docker_options: dict[str, Any] | None = None,
        _client: Client | None = None,
        _git_info: tuple[str, str] | None = None,
    ):
        self._fn = fn
        self._image = image
        self._gpu = gpu
        self._env = env
        self._cloud_config = cloud_config
        self._docker_options = docker_options
        self._client = _client
        self._git_info = _git_info

        # Resolve module and function name from the function object
        module = inspect.getmodule(fn)
        if module is None or module.__name__ == "__main__":
            source_file = inspect.getfile(fn)
            self._module_name = Path(source_file).stem
        else:
            self._module_name = module.__name__

        self._fn_name = fn.__name__
        source_path = Path(inspect.getfile(fn)).resolve()
        self._workdir = str(source_path.parent)

        # Compute module directory relative to git root so the bootstrap
        # can add the correct path to sys.path after cloning.
        self._module_dir = ""
        try:
            git_root = Path(_run_git(
                "rev-parse", "--show-toplevel", cwd=self._workdir
            ))
            rel = source_path.parent.relative_to(git_root)
            self._module_dir = str(rel) if str(rel) != "." else ""
        except (RuntimeError, ValueError):
            pass

        # Check for parameter name collisions with submit() overrides
        sig = inspect.signature(fn)
        for reserved in ("id", "env"):
            if reserved in sig.parameters:
                raise ValueError(
                    f"Function parameter {reserved!r} conflicts with "
                    f"submit({reserved}=...). Rename the parameter."
                )

        self._resolved_cloud_config: CloudConfig | None = None

        functools.update_wrapper(self, fn)

    def _resolve_cloud_config(self, client: Client) -> tuple[CloudConfig | None, str | None]:
        """Resolve cloud config, handling string credential names.

        Returns ``(cloud_config, credential_name)`` where ``credential_name``
        is set when credentials were resolved by name (for server-side lookup).
        """
        cc = self._cloud_config
        if cc is None:
            return None, None

        cred = cc.credentials
        if not isinstance(cred, str):
            return cc, None

        # Resolve string credential name lazily, cache result
        if self._resolved_cloud_config is None:
            resolved = client._resolve_credential(cred)
            # Merge user's other CloudConfig fields onto the resolved config
            overrides: dict[str, Any] = {}
            for field in type(cc).model_fields:
                if field == "credentials":
                    continue
                val = getattr(cc, field)
                if val is not None:
                    overrides[field] = val
            self._resolved_cloud_config = resolved.model_copy(update=overrides)

        return self._resolved_cloud_config, cred

    def submit(
        self,
        *args: Any,
        id: str | None = None,
        env: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> Job:
        """Submit the function for remote execution.

        Args:
            *args: Positional arguments for the wrapped function.
            id: Custom deployment ID (auto-generated if omitted).
            env: Extra environment variables merged on top of decorator-level env.
            **kwargs: Keyword arguments for the wrapped function.

        Returns a :class:`Job` handle immediately.
        """
        client = self._client or _get_default_client()
        repo, commit = self._git_info or _detect_git_info(self._workdir)

        cloud_config, credential_name = self._resolve_cloud_config(client)

        submit_env: dict[str, str] = {}
        if self._env:
            submit_env.update(self._env)
        if env:
            submit_env.update(env)

        try:
            submit_env["_ANYCLOUD_FN"] = json.dumps({
                "repo": repo,
                "commit": commit,
                "module": self._module_name,
                "module_dir": self._module_dir,
                "name": self._fn_name,

                "args": list(args),
                "kwargs": kwargs,
            })
        except TypeError as e:
            raise TypeError(
                "Function arguments must be JSON-serializable "
                "(str, int, float, bool, None, list, dict). "
                f"For complex or large data, use input_bucket instead. Original error: {e}"
            ) from e

        return client.submit(
            self._image,
            gpu=self._gpu,
            env=submit_env,
            command=["python", "-c", BOOTSTRAP_SCRIPT],
            cloud_config=cloud_config,
            docker_options=self._docker_options,
            deployment_id=id,
            credential_name=credential_name,
        )

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Call the function locally (not remotely)."""
        return self._fn(*args, **kwargs)

    def __repr__(self) -> str:
        return f"Function({self._fn.__qualname__!r}, image={self._image!r})"
