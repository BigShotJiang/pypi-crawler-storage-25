from __future__ import annotations

from dataclasses import dataclass
from typing import TypeAlias

import torch
import torch.nn.functional as F

ModelOutput: TypeAlias = dict[str, torch.Tensor]


def _empty_scalar_dict() -> dict[str, float]:
    return {}


@dataclass
class LossBreakdown:
    total: torch.Tensor
    final: torch.Tensor
    universal: torch.Tensor
    family: torch.Tensor
    language: torch.Tensor

    def as_scalars(self) -> dict[str, float]:
        scalars = _empty_scalar_dict()
        scalars["loss"] = float(self.total.detach().cpu())
        scalars["loss_final"] = float(self.final.detach().cpu())
        scalars["loss_universal"] = float(self.universal.detach().cpu())
        scalars["loss_family"] = float(self.family.detach().cpu())
        scalars["loss_language"] = float(self.language.detach().cpu())
        return scalars


class MultiLevelSequenceLoss:
    def __init__(
        self,
        pad_id: int,
        final_weight: float = 1.0,
        universal_weight: float = 0.25,
        family_weight: float = 0.35,
        language_weight: float = 0.5,
    ) -> None:
        self.pad_id = pad_id
        self.final_weight = final_weight
        self.universal_weight = universal_weight
        self.family_weight = family_weight
        self.language_weight = language_weight

    def _ce(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        vocab_size = logits.size(-1)
        return F.cross_entropy(
            logits.reshape(-1, vocab_size),
            target.reshape(-1),
            ignore_index=self.pad_id,
        )

    def __call__(self, output: ModelOutput, target: torch.Tensor) -> LossBreakdown:
        final_loss = self._ce(output["logits"], target)
        universal_loss = self._ce(output["universal_logits"], target)
        family_loss = self._ce(output["family_logits"], target)
        language_loss = self._ce(output["language_logits"], target)
        total = (
            self.final_weight * final_loss
            + self.universal_weight * universal_loss
            + self.family_weight * family_loss
            + self.language_weight * language_loss
        )
        return LossBreakdown(total, final_loss, universal_loss, family_loss, language_loss)
