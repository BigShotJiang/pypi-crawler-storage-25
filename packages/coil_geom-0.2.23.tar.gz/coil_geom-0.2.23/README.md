![PyPI - Version](https://img.shields.io/pypi/v/coil-geom)
![PyPI - License](https://img.shields.io/pypi/l/coil-geom)

# coil-geom

**coil-geom** is a Python package for generating and visualizing **coil and inductor geometries** using clean, parametric definitions. It is designed for engineering, scientific visualization, and symbolic / schematic-style plotting.

- Pure geometry first (NumPy-friendly)
- Save coil geometry data as PPTX, SVG, and PDF
- Suitable for electronics, physics, and CAD-style workflows

**Coil Types**
There are four types of coil geometry: 
1. Circle Coil 
2. Ellipse Coil
3. Ellipse Coil with Curvature Similarity
4. Ellipse Coil with Shape Similarity

Each coil geometry consists of three parts: primary coil(circle or ellipse) and transition coil(circle or ellipse). Primary coil can be a circle or an ellipse. Transition coil also can be a circle or an ellipse. CircleCoil has two primary circles and a transition circle in-betweens. EllipseCoil has two primary ellipses and a transition circle in-betweens. EllipseCoilShape has two primary ellipses and an transition ellipse with shape similarity. EllipseCoilCurvature has two primary ellipses and a transition ellipse with curvature similarity. 

### Circle Coil
![Alt Text](https://github.com/uhwang/Coil-Geom/blob/main/images/circlecoil_02.jpg?raw=true)
### Ellipse Coil 
![Alt Text](https://github.com/uhwang/Coil-Geom/blob/main/images/ellipsecoil_02.jpg?raw=true)
### Ellipse Coil Shape Similarity
![Alt Text](https://github.com/uhwang/Coil-Geom/blob/main/images/ellipsecoilshape_02.jpg?raw=true)
### Ellipse Coil Curvature Similarity
![Alt Text](https://github.com/uhwang/Coil-Geom/blob/main/images/ellipsecoilcurvature_02.jpg?raw=true)
---

## 🔗 Project Links
* **GitHub Repository**: [https://github.com/uhwang/Coil-Geom](https://github.com/uhwang/Coil-Geom)
* **PyPI Page**: [https://pypi.org/project/coil-geom/](https://pypi.org/project/coil-geom/)
* **Issue Tracker**: [Report a bug](https://github.com/uhwang/Coil-Geom/issues)
## Installation

```bash
pip install coil-geom
```

### Export Coil Geometries (PPTX, SVG, and PDF)
```Python
import coil_geom as cg

c_c_up = cg.CircleCoil(p_dist=0.7, ncoil=5)
c_c_dn = cg.CircleCoil(ncoil=5)

c_e_up = cg.EllipseCoil(p_dist=0.4, ncoil=5)
c_e_dn = cg.EllipseCoil(ncoil=5)

c_es_up = cg.EllipseCoilShape(p_dist=0.4, target=0.8, ncoil=5)
c_es_dn = cg.EllipseCoilShape(ncoil=5)

c_ec_up = cg.EllipseCoilCurvature(p_dist=0.4, ncoil=5)
c_ec_dn = cg.EllipseCoilCurvature(ncoil=5)

cg.save_ppt(c_c_up ,  "c_c_up.pptx" )
cg.save_ppt(c_c_dn ,  "c_c_dn.pptx" )
cg.save_ppt(c_e_up ,  "c_e_up.pptx" )
cg.save_ppt(c_e_dn ,  "c_e_dn.pptx" )
cg.save_ppt(c_es_up, "c_es_up.pptx", debug=True)
cg.save_ppt(c_es_dn, "c_es_dn.pptx", debug=True)
cg.save_ppt(c_ec_up, "c_ec_up.pptx", lead_l=2, lead_r=2)
cg.save_ppt(c_ec_dn, "c_ec_dn.pptx")

cg.save_svg(c_c_up ,  "c_c_up.svg" )
cg.save_svg(c_c_dn ,  "c_c_dn.svg" )
cg.save_svg(c_e_up ,  "c_e_up.svg" )
cg.save_svg(c_e_dn ,  "c_e_dn.svg" )
cg.save_svg(c_es_up, "c_es_up.svg", debug=True)
cg.save_svg(c_es_dn, "c_es_dn.svg", debug=True)
cg.save_svg(c_ec_up, "c_ec_up.svg", lead_l=2, lead_r=2)
cg.save_svg(c_ec_dn, "c_ec_dn.svg")

cg.save_pdf(c_c_up ,  "c_c_up.pdf" )
cg.save_pdf(c_c_dn ,  "c_c_dn.pdf" )
cg.save_pdf(c_e_up ,  "c_e_up.pdf" )
cg.save_pdf(c_e_dn ,  "c_e_dn.pdf" )
cg.save_pdf(c_es_up, "c_es_up.pdf", debug=True)
cg.save_pdf(c_es_dn, "c_es_dn.pdf", debug=True)
cg.save_pdf(c_ec_up, "c_ec_up.pdf")
cg.save_pdf(c_ec_dn, "c_ec_dn.pdf")

```
### Plot Coil Geometries
```Python
import matplotlib.pyplot as plt
import coil_geom as cg

cc = cg.CircleCoil(ncoil=5)
ce = cg.EllipseCoil(ncoil=5)
ces = cg.EllipseCoilShape(ncoil=5)
cec = cg.EllipseCoilCurvature(ncoil=5)

x1, y1 = cc.create_geom()
x2, y2 = ce.create_geom()
x3, y3 = ces.create_geom()
x4, y4 = cec.create_geom()

fig, axs = plt.subplots(nrows=4, ncols=1,  figsize=(8, 6))
fig.suptitle('Circle & Ellipse Coil Geometry')
axs[0].plot(x1, y1)
axs[0].set_aspect('equal')
axs[1].plot(x2, y2)
axs[1].set_aspect('equal')
axs[2].plot(x3, y3)
axs[2].set_aspect('equal')
axs[3].plot(x4, y4)
axs[3].set_aspect('equal')
plt.show()
```
![Alt Text](https://github.com/uhwang/Coil-Geom/blob/main/images/coil-matplotlib.jpg?raw=true)

### Plot 3 Phase Delta Connection
```Python
def three_delta(coil, lead_l, lead_r):

    xs, ys = [], []
    c1 = coil.create_geom(False, lead_l, lead_r)
    x1, y1 = c1.get()
    xs.append(x1)
    ys.append(y1)
    
    c2 = c1.flipud().rotate(60, axis=0)
    xs.append(c2.x)
    ys.append(c2.y)
    
    c3 = c1.flipud().rotate(-60, axis=2)
    xs.append(c3.x)
    ys.append(c3.y)
        
    return xs, ys
```
![Alt Text](https://github.com/uhwang/Coil-Geom/blob/main/images/3p_delta.jpg?raw=true)
### Plot 3 Phase Y Connection
```Python
def three_y(coil, lead_l, lead_r):

    xs, ys = [], []
    c = coil.create_geom(False, lead_l, lead_r)
    c1 = c.rotate(90, axis=0)
    xs.append(c1.x)
    ys.append(c1.y)
    
    c2 = c1.rotate(120, axis=0)
    xs.append(c2.x)
    ys.append(c2.y)
    
    c3 = c2.rotate(120, axis=0)
    xs.append(c3.x)
    ys.append(c3.y)        
    return xs, ys
```    
![Alt Text](https://github.com/uhwang/Coil-Geom/blob/main/images/3p_y.jpg?raw=true)