"""Lightweight .env file loader — replaces python-dotenv dependency."""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _log(msg: str) -> None:
    """Write a diagnostic line to stderr so it appears in worker logs."""
    print(f"[goliath_utils.env] {msg}", file=sys.stderr, flush=True)


def _walk_up_for_dotenv(start: Path) -> Path | None:
    """Walk from *start* up to root looking for a ``.env`` file."""
    path = start.resolve()
    while True:
        candidate = path / ".env"
        if candidate.is_file():
            return candidate
        parent = path.parent
        if parent == path:
            return None
        path = parent


def _find_dotenv() -> Path | None:
    """Locate the nearest ``.env`` file.

    Search order:
    1. Directory of the entry-point script (``__main__.__file__``).
    2. Walk upward from the current working directory (fallback).
    """
    # 1. Next to (or above) the script that was actually launched.
    try:
        import __main__

        entry = getattr(__main__, "__file__", None)
        if entry:
            found = _walk_up_for_dotenv(Path(entry).parent)
            if found:
                return found
    except Exception:
        pass

    # 2. Fallback: walk up from cwd.
    return _walk_up_for_dotenv(Path.cwd())


def _parse_line(line: str) -> tuple[str, str] | None:
    """Parse a single KEY=VALUE line. Returns (key, value) or None."""
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return None

    # Strip optional 'export ' prefix
    if stripped.startswith("export ") or stripped.startswith("export\t"):
        stripped = stripped[7:].lstrip()

    eq = stripped.find("=")
    if eq < 0:
        return None

    key = stripped[:eq].strip()
    if not key:
        return None

    raw = stripped[eq + 1 :].strip()

    # Quoted value
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in ('"', "'"):
        value = raw[1:-1]
        # Process escape sequences in double-quoted values
        if raw[0] == '"':
            value = value.replace("\\n", "\n").replace("\\t", "\t").replace('\\"', '"')
        return (key, value)

    # Unquoted: strip inline comment ( # ...)
    comment_pos = raw.find(" #")
    if comment_pos >= 0:
        raw = raw[:comment_pos].rstrip()

    return (key, raw)


def load_dotenv() -> bool:
    """Load variables from the nearest .env file into ``os.environ``.

    Searches from the current working directory upward. Existing
    environment variables are **not** overridden.

    Returns ``True`` if a ``.env`` file was found, ``False`` otherwise.
    """
    dotenv_path = _find_dotenv()
    if dotenv_path is None:
        try:
            import __main__
            entry = getattr(__main__, "__file__", None)
        except Exception:
            entry = None
        _log(f"no .env file found (entry={entry}, cwd={Path.cwd()})")
        return False

    _log(f"loading {dotenv_path}")
    text = dotenv_path.read_text(encoding="utf-8")
    for line in text.splitlines():
        result = _parse_line(line)
        if result is None:
            continue
        key, value = result
        if key not in os.environ:
            os.environ[key] = value
            _log(f"set {key} (from .env)")
        else:
            #_log(f"skipped {key} — already in env (env={os.environ[key]!r}, .env={value!r})")
            pass

    return True
