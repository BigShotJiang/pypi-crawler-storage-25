"""Lightweight synchronous database wrapper with pluggable drivers.

Supported drivers:

- ``"builtin"`` — Pure-Python driver from :mod:`goliath_utils.pg` (default, zero dependencies)
- ``"psycopg2"`` — psycopg2 / psycopg2-binary (C extension, must be installed separately)
- ``"psycopg"`` — psycopg v3 (pure-Python or C, must be installed separately)
"""

from __future__ import annotations

import re
import sys
from typing import Any

from ._errors import DatabaseConnectionError, DatabaseQueryError

_VALID_DRIVERS = ("builtin", "psycopg2", "psycopg")


def _rewrite_query(query: str) -> str:
    """Convert ``:param`` placeholders to psycopg2's ``%(param)s`` style."""
    return re.sub(r":(\w+)", r"%(\1)s", query)


class Database:
    """Synchronous database wrapper with a clean query interface.

    Queries use ``:param`` named placeholders::

        db.fetch_all("SELECT * FROM t WHERE id = :id", {"id": 1})

    Array parameters work naturally::

        db.fetch_all(
            "SELECT * FROM t WHERE store_id = ANY(:ids)",
            {"ids": [1, 2, 3]},
        )

    Connections are lazy — the database is not contacted until the first
    query or an explicit call to :meth:`connect`.

    The *driver* parameter controls which PostgreSQL driver is used:

    - ``"builtin"`` (default) — zero-dependency pure-Python driver
    - ``"psycopg2"`` — requires ``pip install psycopg2-binary``
    - ``"psycopg"`` — requires ``pip install psycopg``
    """

    def __init__(
        self,
        dsn: str | None = None,
        *,
        host: str | None = None,
        port: int | str = 5432,
        dbname: str | None = None,
        user: str | None = None,
        password: str | None = None,
        driver: str = "builtin",
        timeout: float = 120,
    ):
        if driver not in _VALID_DRIVERS:
            raise ValueError(
                f"Unknown driver {driver!r}. Choose from: {', '.join(_VALID_DRIVERS)}"
            )
        self._dsn = dsn
        self._host = host
        self._port = int(port)
        self._dbname = dbname
        self._user = user
        self._password = password
        self._driver = driver
        self._timeout = timeout
        self._conn: Any = None

    # -- connection lifecycle -----------------------------------------------

    def connect(self) -> None:
        """Open the database connection (called automatically on first query)."""
        if self._conn is not None:
            return

        if self._driver == "builtin":
            self._connect_builtin()
        elif self._driver == "psycopg2":
            self._connect_psycopg2()
        elif self._driver == "psycopg":
            self._connect_psycopg()

    def _connect_builtin(self) -> None:
        from goliath_utils.pg import Connection

        try:
            if self._dsn:
                conn = Connection(dsn=self._dsn, timeout=self._timeout)
            else:
                conn = Connection(
                    host=self._host or "localhost",
                    port=self._port,
                    database=self._dbname or "",
                    user=self._user or "",
                    password=self._password or "",
                    timeout=self._timeout,
                )
            conn.connect()
            conn.autocommit = True
            self._conn = conn
        except Exception as exc:
            raise DatabaseConnectionError(str(exc)) from exc

    def _connect_psycopg2(self) -> None:
        try:
            import psycopg2
        except ImportError:
            raise DatabaseConnectionError(
                "psycopg2 is required for driver='psycopg2'. "
                "Install it with: pip install psycopg2-binary"
            )

        try:
            connect_kwargs: dict[str, Any] = {
                "connect_timeout": int(self._timeout),
                "options": f"-c statement_timeout={int(self._timeout * 1000)}",
            }

            if self._dsn:
                self._conn = psycopg2.connect(self._dsn, **connect_kwargs)
            else:
                self._conn = psycopg2.connect(
                    host=self._host,
                    port=self._port,
                    dbname=self._dbname,
                    user=self._user,
                    password=self._password,
                    **connect_kwargs,
                )
            self._conn.autocommit = True
        except psycopg2.Error as exc:
            raise DatabaseConnectionError(str(exc)) from exc

    def _connect_psycopg(self) -> None:
        try:
            import psycopg
        except ImportError:
            raise DatabaseConnectionError(
                "psycopg is required for driver='psycopg'. "
                "Install it with: pip install psycopg"
            )

        try:
            connect_kwargs: dict[str, Any] = {
                "autocommit": True,
                "connect_timeout": int(self._timeout),
                "options": f"-c statement_timeout={int(self._timeout * 1000)}",
            }

            if self._dsn:
                self._conn = psycopg.connect(self._dsn, **connect_kwargs)
            else:
                self._conn = psycopg.connect(
                    host=self._host,
                    port=self._port,
                    dbname=self._dbname,
                    user=self._user,
                    password=self._password,
                    **connect_kwargs,
                )
        except psycopg.Error as exc:
            raise DatabaseConnectionError(str(exc)) from exc

    def close(self) -> None:
        """Close the database connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.close()

    # -- internal helpers ---------------------------------------------------

    def _ensure_connected(self) -> None:
        if self._conn is None:
            self.connect()

    def _execute(self, query: str, params: dict | None = None):
        """Execute a query and return results.

        Routes to the appropriate driver-specific execution path.
        """
        self._ensure_connected()

        if self._driver == "builtin":
            return self._execute_builtin(query, params)
        else:
            return self._execute_dbapi(query, params)

    def _execute_builtin(self, query: str, params: dict | None = None):
        """Execute via the builtin pure-Python driver."""
        try:
            rows, rowcount = self._conn._exec(query, params)
            return rows, rowcount
        except Exception as exc:
            from goliath_utils.pg import QueryError
            if isinstance(exc, QueryError):
                raise DatabaseQueryError(query, str(exc)) from exc
            raise DatabaseQueryError(query, str(exc)) from exc

    def _execute_dbapi(self, query: str, params: dict | None = None):
        """Execute via a DB-API 2.0 driver (psycopg2 or psycopg v3)."""
        sql = _rewrite_query(query)

        if self._driver == "psycopg2":
            from psycopg2.extras import RealDictCursor
            cur = self._conn.cursor(cursor_factory=RealDictCursor)
        else:
            # psycopg v3 uses row_factory
            from psycopg.rows import dict_row
            cur = self._conn.cursor(row_factory=dict_row)

        try:
            cur.execute(sql, params)
        except Exception as exc:
            cur.close()
            raise DatabaseQueryError(query, str(exc)) from exc
        return cur

    # -- public query interface ---------------------------------------------

    def fetch_all(self, query: str, params: dict | None = None) -> list[dict]:
        """Execute a query and return all rows as a list of dicts."""
        result = self._execute(query, params)
        if self._driver == "builtin":
            rows, _ = result
            return rows
        else:
            cur = result
            try:
                return [dict(row) for row in cur.fetchall()]
            finally:
                cur.close()

    def fetch_one(self, query: str, params: dict | None = None) -> dict | None:
        """Execute a query and return the first row, or None."""
        result = self._execute(query, params)
        if self._driver == "builtin":
            rows, _ = result
            return rows[0] if rows else None
        else:
            cur = result
            try:
                row = cur.fetchone()
                return dict(row) if row is not None else None
            finally:
                cur.close()

    def fetch_val(self, query: str, params: dict | None = None) -> Any | None:
        """Execute a query and return the first column of the first row, or None."""
        row = self.fetch_one(query, params)
        if row is None:
            return None
        return next(iter(row.values()))

    def execute(self, query: str, params: dict | None = None) -> int:
        """Execute a query and return the number of affected rows."""
        result = self._execute(query, params)
        if self._driver == "builtin":
            _, rowcount = result
            return rowcount
        else:
            cur = result
            try:
                return cur.rowcount
            finally:
                cur.close()


def get_db(
    dsn: str | None = None,
    *,
    section: str = "goliath_db",
    secrets_client: Any = None,
    driver: str = "builtin",
    timeout: float = 120,
) -> Database:
    """Create a :class:`Database` from Goliath secrets or a DSN string.

    With no arguments, fetches credentials from the ``goliath_db`` section
    of the Goliath secrets API (requires ``GOLIATH_API_URL`` and
    ``GOLIATH_API_KEY`` environment variables).

    Pass *dsn* to skip the secrets lookup entirely::

        db = get_db("postgresql://user:pass@host/dbname")

    Use *driver* to choose the PostgreSQL driver:

    - ``"builtin"`` (default) — pure-Python, zero dependencies
    - ``"psycopg2"`` — requires psycopg2-binary
    - ``"psycopg"`` — requires psycopg v3
    """
    _dblog = lambda msg: print(f"[goliath_utils.db] {msg}", file=sys.stderr, flush=True)

    if dsn is not None:
        _dblog(f"using DSN directly (driver={driver})")
        return Database(dsn=dsn, driver=driver, timeout=timeout)

    from goliath_utils.secrets import SecretsClient

    _dblog(f"fetching credentials from secrets section={section!r}")
    client = secrets_client or SecretsClient()
    creds = client.get_section(section)
    _dblog(f"connecting to {creds['host']}:{creds['port']}/{creds['db_name']} (driver={driver})")

    return Database(
        host=creds["host"],
        port=creds["port"],
        dbname=creds["db_name"],
        user=creds["db_username"],
        password=creds["db_password"],
        driver=driver,
        timeout=timeout,
    )
