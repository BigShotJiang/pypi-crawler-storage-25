__version__ = "0.0.1.dev0"

def hello():
    return 'Hello from amd-torchvision-device-gfx900!'
