"""Bundled catalog data package."""
