import os



# Custom library imports:
from .config import *



def file_is_32mb(filename: str) -> bool:
    file_size = os.path.getsize(filename)
    return file_size <= (MAX_FILE_MB * 1024 * 1024)



def get_file(filename: str):
    if os.path.getsize(filename) == 0:
        return None
    return open(filename, "rb")



def write_file(filename: str, data: str) -> None:
	with open(filename, 'w') as f:
		f.write(data)
