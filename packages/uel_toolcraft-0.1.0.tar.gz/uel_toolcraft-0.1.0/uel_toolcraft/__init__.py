"""
uel-toolcraft — A Unified Essential Library toolcraft for personal usage.

Models: AES encryption, Bark push, logging, PyQt async, Redis, SQLite, WeCom.
Tools: config, ffmpeg, filesystem, git, json, pickle, rclone, supabase, text, UI, utils.
"""

try:
    from importlib.metadata import version as _get_version
    __version__ = _get_version("uel-toolcraft")
except Exception:
    __version__ = "0.1.0"
