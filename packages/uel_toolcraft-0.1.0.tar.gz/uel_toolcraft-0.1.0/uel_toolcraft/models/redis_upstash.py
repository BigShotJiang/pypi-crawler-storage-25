from upstash_redis import Redis
import logging
from .logging_config import LogConfig

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


class RedisHelper:
    def __init__(self, api_url: str, token: str):
        """
        初始化 RedisHelper 实例并连接 Redis。
        :param api_url: Redis API URL
        :param token: Redis Token
        """
        self.redis = Redis(url=api_url, token=token)

    def get_value(self, key: str) -> str:
        """
        获取 Redis 中指定 key 对应的值。
        :param key: 键
        :return: 键对应的值
        """
        if not key:
            logger.error(f"Key '{key}' cannot be None or empty")
            raise ValueError(f"Key '{key}' cannot be None or empty")
        value = self.redis.get(key)
        if value is None:
            logger.error(f"Key '{key}' not found in Redis")
            raise KeyError(f"Key '{key}' not found in Redis")
        return value

    def get_key_value_dict(self, key_list: list) -> dict:
        """
        获取 Redis 中多个 key 对应的值，并以字典形式返回。
        :param key_list: 键的列表
        :return: 包含 key: value 的字典
        """
        result_dict = {}
        for key in key_list:
            value = self.get_value(key)
            result_dict[key] = value
        return result_dict


if __name__ == '__main__':
    LogConfig(level=logging.DEBUG)  # 配置日志记录器
    # Example usage
    upstash_redis_api = "https://your-upstash-redis-api.upstash.io"
    upstash_redis_token = "your_upstash-redis-token"

    # 创建 RedisHelper 实例
    redis_helper = RedisHelper(upstash_redis_api, upstash_redis_token)
    # 获取 Redis 中的 key 列表
    key_list_ = ["foo", "foo"]
    # 获取对应的值
    try:
        result_dict_ = redis_helper.get_key_value_dict(key_list_)
        logger.info(result_dict_)
    except (ValueError, KeyError) as e:
        logger.info(f"Error: {e}")
