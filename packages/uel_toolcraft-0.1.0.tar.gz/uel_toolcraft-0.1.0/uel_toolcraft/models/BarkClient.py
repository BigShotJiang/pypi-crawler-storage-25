import requests
import json
from .AESCipher import AESCipher
import logging
from .logging_config import LogConfig

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


class BarkClient:
    def __init__(self, server_url: str, device_key: str | list, debug: bool = False):
        """
        初始化 BarkClient
        :param server_url: Bark服务器地址，例如 http://127.0.0.1:8080
        :param device_key: 设备的推送key，例如 "your_bark_device_token" 或 ["device_key1", "device_key2"]
        :param debug: 是否开启调试模式，默认为 False
        """
        self.debug = debug  # 是否开启调试模式
        self.server_url = server_url.rstrip('/')
        self.device_key = device_key
        self.push_url = f"{self.server_url}/push"
        self.headers = {
            "Content-Type": "application/json; charset=utf-8",
        }
        self.supported_parameters = [
            "title", "subtitle", "body", "device_key", "device_keys", "level", "volume", "badge", "call", "autoCopy", "copy", "sound", "icon", "group", "ciphertext", "isArchive", "url", "action"
        ]

        # 根据 device_key 的类型设置 payload 中的 device_key 键名称
        if isinstance(self.device_key, list):
            # 如果 device_key 是列表，parameters 中的 device_key 应该是 device_keys
            self.device_key_payload_name = "device_keys"
            if self.debug:
                logger.debug(f"✅ [BarkClient] device_key is a list, using 'device_keys' in payload.")
        elif isinstance(self.device_key, str):
            # 如果 device_key 是字符串，parameters 中的 device_key 应该是 device_key
            self.device_key_payload_name = "device_key"
            if self.debug:
                logger.debug(f"✅ [BarkClient] device_key is a string, using 'device_key' in payload.")
        else:
            logger.error("❌ [BarkClient] device_key must be a string or a list of strings.")
            raise ValueError("device_key must be a string or a list of strings.")

    def send(self, body: str, title: str = "", **extra_fields):
        """
        发送推送，支持额外动态字段
        :param body: 消息正文
        :param title: 消息标题
        :param extra_fields: 其他自定义参数（sound, badge, icon, group, url等, 帮助文档: "https://bark.day.app/#/tutorial"）
        """
        payload = {
            "body": body,
            self.device_key_payload_name: self.device_key,
            "title": title
        }

        # 是否加密
        encrypt = False

        # 动态添加额外参数
        for field_name, value in extra_fields.items():
            if (field_name in self.supported_parameters) and (value is not None):
                payload[field_name] = value
            elif (field_name in ["encrypt", "aes"]) and (value is not None):
                # 如果参数是 encrypt，则设置 encrypt 变量
                encrypt = value

        try:
            if encrypt:
                # 如果需要加密，则使用 AES 加密
                key = extra_fields.get("key", None)  # 默认密钥
                if key is None:
                    logger.error("❌ [BarkClient] Key is required for encryption.")
                    raise ValueError("Key is required for encryption.")
                # 从 extra_fields 中获取 IV, 如果没有提供则生成一个默认的 IV
                iv = extra_fields.get("iv") or AESCipher.generate_key(128)  # 默认 IV
                mode = extra_fields.get("mode", "CBC")  # 默认模式为 CBC
                aes_cipher = AESCipher(key=key, iv=iv, mode=mode)
                payload_str = json.dumps(payload)
                encrypted_payload = aes_cipher.encrypt(payload_str)
                # 构建含有加密文本的 payload
                payload = {
                    self.device_key_payload_name: self.device_key,
                    "ciphertext": encrypted_payload,
                    "iv": iv,
                }

            # 发送请求
            send_response = requests.post(
                url=self.push_url,
                headers=self.headers,
                data=json.dumps(payload),
                timeout=10
            )

            if self.debug:
                # 检查响应状态码
                logger.debug(f"✅ [BarkClient] Response Status Code: {send_response.status_code}")
                logger.debug(f"✅ [BarkClient] Response Body: {send_response.content.decode('utf-8')}")

            return send_response
        except requests.exceptions.RequestException as e:
            logger.error(f"❌ [BarkClient] Request failed: {e}")
            return None


if __name__ == "__main__":
    LogConfig(level=logging.DEBUG)  # 初始化日志配置
    bark = BarkClient(server_url="https://api.day.app/", device_key="your_bark_device_token", debug=True)
    response = bark.send(
        body="This is a test message.",
        title="Test",
        group="Test Group",
        debug=False,
        encrypt=False,
        mode="CBC",
        key="aes_16_byte_key",
        iv="aes_16_byte_iv"  # CBC 模式需要 16 字节 IV, 如果不指定则自动生成 16 字节 IV
    )
