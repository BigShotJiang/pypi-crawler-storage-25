import logging
import sys
from pathlib import Path

_configured = False  # 用于防止重复配置


class LogConfig:
    """
    日志配置类，用于设置日志记录器的格式和处理器
    支持控制台输出和文件输出，支持彩色日志格式
    支持屏蔽第三方库的日志输出
    通过单例模式确保只配置一次
    通过全局变量 _configured 防止重复配置
    通过 get_logger 函数获取日志记录器实例
    :param level: 日志级别，默认为 logging.INFO
    :param log_file: 日志文件路径，如果为 None 则不输出到文件
    """
    def __init__(self, level=logging.INFO, log_file=None):
        global _configured
        if _configured:
            return  # 已配置过，直接跳过

        self.level = level
        self.log_file = Path(log_file) if log_file else None
        self.is_block_other = True  # 是否屏蔽第三方库日志
        self._configure_logging()
        _configured = True

    def _configure_logging(self):
        if self.is_block_other:
            # 屏蔽第三方库日志
            noisy_logger_list = ["httpx", "urllib3"]
            for noisy_logger in noisy_logger_list:
                logging.getLogger(noisy_logger).setLevel(logging.WARNING)

        # 彩色日志格式
        class ColorFormatter(logging.Formatter):
            COLORS = {
                "DEBUG": "\033[37m",  # 白色
                "INFO": "\033[36m",  # 青色
                "WARNING": "\033[33m",  # 黄色
                "ERROR": "\033[31m",  # 红色
                "CRITICAL": "\033[41m",  # 红色背景
            }
            RESET = "\033[0m"

            def format(self, record):
                color = self.COLORS.get(record.levelname, self.RESET)
                message = super().format(record)
                return f"{color}{message}{self.RESET}"

        # 控制台 Handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(ColorFormatter("%(asctime)s [%(levelname)s]: %(message)s"))

        root_logger = logging.getLogger()
        root_logger.setLevel(self.level)
        root_logger.handlers.clear()
        root_logger.addHandler(console_handler)

        # 文件 Handler
        if self.log_file:
            self.log_file.parent.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(self.log_file, encoding="utf-8")
            file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
            root_logger.addHandler(file_handler)


def get_logger(name=None, level=logging.INFO, log_file=None) -> logging.Logger:
    """
    获取日志记录器
    :param name: 日志记录器名称
    :param level: 日志级别
    :param log_file: 日志文件路径（可选）
    :return: logging.Logger 对象
    """
    LogConfig(level=level, log_file=log_file)  # 只会第一次生效
    logging_logger: logging.Logger = logging.getLogger(name)
    return logging_logger


if __name__ == "__main__":
    # 如果单独运行这个文件，做个测试
    logger = get_logger(name=None, level=logging.DEBUG, log_file="logging_config_get_logger.log")
    logger.debug(f"调试信息")
    logger.info(f"普通信息")
    logger.warning(f"警告信息")
    logger.error(f"错误信息")
    logger.critical(f"致命错误")
    logger.info(f"配置日志记录器成功，日志输出到控制台和文件\n\n==========================\n")
