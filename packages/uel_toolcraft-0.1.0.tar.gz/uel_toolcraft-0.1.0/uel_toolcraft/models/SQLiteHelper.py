import sqlite3
import json
from pathlib import Path
from typing import List, Dict, Any
import logging
from .logging_config import LogConfig

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


class SQLiteHelper:
    """
    A simple SQLite helper class for creating tables, inserting data, and reading data.
    """
    def __init__(self, db_path: str | Path, auto_schema_update: bool = False, debug: bool = False, show_conn: bool = True):
        """
        初始化 SQLiteHelper 实例。
        :param db_path: 数据库文件路径，可以是字符串或 Path 对象。
        :param auto_schema_update: 是否自动更新表格模式（自动增加新列）。
        :param debug: 是否启用调试模式，打印详细信息。
        :param show_conn: 是否在初始化时显示连接信息, 默认为 True。
        """
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.auto_schema_update = auto_schema_update
        self.debug = debug
        self.show_conn = show_conn
        if self.debug or self.show_conn:
            logger.info(f"✅ Connected to database: {db_path}")

    def table_exists(self, table_name: str) -> bool:
        """
        检查指定的表格是否存在。
        :param table_name: 表名
        :return: 如果表格存在则返回 True，否则返回 False。
        """
        query = "SELECT name FROM sqlite_master WHERE type='table' AND name=?"
        self.cursor.execute(query, (table_name,))

        # 使用 fetchone() 检查是否有结果
        if self.cursor.fetchone() is not None:
            # 如果 fetchone() 返回一个元组，则表格存在
            is_table_exists = True
            if self.debug:
                logger.debug(f"✅ Table '{table_name}' exists.")
        else:
            # 如果 fetchone() 返回 None，则表格不存在
            is_table_exists = False
            if self.debug:
                logger.debug(f"❌ Table '{table_name}' does not exist.")

        return is_table_exists

    def create_table(self, table_name: str, sample_row: Dict[str, Any]):
        """
        创建表格，如果表格已存在则跳过。
        :param table_name: 表名
        :param sample_row: 样本行数据，用于推断列类型
        :return: None
        """
        columns_sql = []
        for key, value in sample_row.items():
            if isinstance(value, int):
                column_type = "INTEGER"
            elif isinstance(value, float):
                column_type = "REAL"
            else:
                column_type = "TEXT"  # for str, dict, list (stored as JSON)
            columns_sql.append(f"{key} {column_type}")
        create_sql = f"CREATE TABLE IF NOT EXISTS {table_name} ({', '.join(columns_sql)})"
        self.cursor.execute(create_sql)
        self.conn.commit()
        if self.debug:
            logger.debug(f"🧱 Table '{table_name}' is ready.")

    def add_column(self, table_name: str, sample_row: Dict[str, Any]):
        """
        添加列到表格中，如果列已存在则跳过。
        :param table_name: 表名
        :param sample_row: 样本行数据，用于推断列类型
        :return: None
        """
        # 获取现有列
        self.cursor.execute(f"PRAGMA table_info({table_name})")
        existing_columns = {row[1] for row in self.cursor.fetchall()}

        for key, value in sample_row.items():
            if key not in existing_columns:
                if isinstance(value, int):
                    column_type = "INTEGER"
                elif isinstance(value, float):
                    column_type = "REAL"
                else:
                    column_type = "TEXT"
                alter_sql = f"ALTER TABLE {table_name} ADD COLUMN {key} {column_type}"
                self.cursor.execute(alter_sql)
                if self.debug:
                    logger.debug(f"➕ Added column '{key}' to table '{table_name}'.")

        self.conn.commit()

    def insert_data(self, table_name: str, data: List[Dict[str, Any]]):
        """
        插入数据到指定表中，如果表不存在则创建表。
        :param table_name: 表名
        :param data: 要插入的数据列表，每一项是一个字典
        :return: None
        """
        if not data:
            logger.warning("⚠️ No data to insert.")
            return

        # 检查表格是否存在, 如果不存在则创建
        if not self.table_exists(table_name):
            # 创建表格, 如果表格存在, 则跳过
            self.create_table(table_name, data[0])

        # 自动更新表格模式 (若列不存在, 添加列)
        if self.auto_schema_update:
            # 添加列到表格中, 如果列存在, 则跳过
            self.add_column(table_name, data[0])

        # 准备数据: 将列表或字典类型转换为 JSON 字符串
        for row in data:
            for key, value in row.items():
                if isinstance(value, (dict, list)):
                    row[key] = json.dumps(value)

        keys = data[0].keys()
        placeholders = ', '.join('?' for _ in keys)
        insert_sql = f"INSERT INTO {table_name} ({', '.join(keys)}) VALUES ({placeholders})"
        self.cursor.executemany(insert_sql, [tuple(d[k] for k in keys) for d in data])
        self.conn.commit()
        if self.debug:
            logger.debug(f"📥 Inserted {len(data)} rows into '{table_name}'.")

    def query_data(self, table_name: str, column_name: str, value: Any, exact_match: bool = False, result_column: str = "*") -> List[Dict[str, Any]]:
        """
        查询表中指定列等于某个值的所有行。
        :param table_name: 表名
        :param column_name: 要查询的列名
        :param value: 查询值。None 为 null, "" 为除了 null 的任意值
        :param exact_match: 是否进行精确匹配 (默认是模糊匹配)
        :param result_column: 查询结果的列名，默认为所有列（*）
        :return: 查询结果列表，每一项是一个字典
        """
        if value is None:
            query_sql = f"SELECT {result_column} FROM {table_name} WHERE {column_name} IS NULL"
            self.cursor.execute(query_sql)
        else:
            if exact_match:
                # 精确匹配
                query_sql = f"SELECT {result_column} FROM {table_name} WHERE {column_name} = ?"
                self.cursor.execute(query_sql, (value,))
            else:
                # 模糊匹配
                query_sql = f"SELECT {result_column} FROM {table_name} WHERE {column_name} LIKE ?"
                self.cursor.execute(query_sql, (f"%{value}%",))
        columns = [description[0] for description in self.cursor.description]
        results = []
        for row in self.cursor.fetchall():
            row_dict = dict(zip(columns, row))
            for k, v in row_dict.items():
                try:
                    row_dict[k] = json.loads(v)
                except (TypeError, json.JSONDecodeError):
                    pass
            results.append(row_dict)
        return results

    def query_by_conditions(self, table_name: str, conditions: Dict[str, Any], exact_match: bool = False, result_column: str = "*") -> List[Dict[str, Any]]:
        """
        根据多个条件查询表中的数据，支持精确/模糊匹配，并能处理值为 None 的情况。

        :param table_name: 表名
        :param conditions: 查询条件字典（列名 -> 值）
        :param exact_match: 是否精确匹配（True=精确，False=模糊）
        :param result_column: 查询结果的列名，默认为所有列（*）
        :return: 查询结果列表
        """
        if not conditions:
            raise ValueError("Must provide at least one condition.")

        where_clauses = []
        values = []

        for key, value in conditions.items():
            if value is None:
                # 处理 None 值
                where_clauses.append(f"{key} IS NULL")
            else:
                if exact_match:
                    # 精确匹配
                    where_clauses.append(f"{key} = ?")
                    values.append(value)
                else:
                    # 模糊匹配
                    where_clauses.append(f"{key} LIKE ?")
                    values.append(f"%{value}%")

        where_sql = " AND ".join(where_clauses)
        query_sql = f"SELECT {result_column} FROM {table_name} WHERE {where_sql}"

        self.cursor.execute(query_sql, values)
        columns = [desc[0] for desc in self.cursor.description]
        results = []

        for row in self.cursor.fetchall():
            row_dict = dict(zip(columns, row))
            for k, v in row_dict.items():
                try:
                    row_dict[k] = json.loads(v)
                except (TypeError, json.JSONDecodeError):
                    pass
            results.append(row_dict)
        return results

    def update_data(self, table_name: str, condition_col: str, condition_val: Any, new_values: Dict[str, Any]):
        """
        更新表格中满足条件 (condition_col == condition_val) 的行, 使用 new_values 更新。

        :param table_name: 表名
        :param condition_col: 要查询的列名，用于 WHERE 子句。
        :param condition_val: 查询值
        :param new_values: 需要更新的列和值，以字典形式提供。
        """
        if not new_values:
            logger.warning("⚠️ No values provided for update.")
            return

        # Prepare values: encode lists/dicts as JSON
        for k, v in new_values.items():
            if isinstance(v, (dict, list)):
                new_values[k] = json.dumps(v)

        set_clause = ', '.join(f"{k}=?" for k in new_values.keys())
        sql = f"UPDATE {table_name} SET {set_clause} WHERE {condition_col}=?"
        values = list(new_values.values()) + [condition_val]

        self.cursor.execute(sql, values)
        self.conn.commit()
        if self.debug:
            logger.debug(f"🔧 Updated rows in '{table_name}' where '{condition_col} = {condition_val}'")

    def update_rows(self, table_name: str, key_column: str, updates: List[Dict[str, Any]]):
        """
        批量更新表中多行数据。
        :param table_name: 表名
        :param updates: 包含每行更新数据的字典列表，每部字典必须包含 key_column 字段。如果没有要更新的字段，则跳过该行。
        :param key_column: 用于标识要更新行的唯一字段
        """
        if not updates:
            logger.warning("⚠️ No updates to apply.")
            return

        for row in updates:
            if key_column not in row:
                raise ValueError(f"Each update row must include '{key_column}'")
            row_key_value = row[key_column]
            new_values = {k: v for k, v in row.items() if k != key_column}
            if not new_values:
                continue  # 跳过无更新字段的项

            # JSON 序列化复杂数据类型
            for k, v in new_values.items():
                if isinstance(v, (dict, list)):
                    new_values[k] = json.dumps(v)  # 将 dict 或 list 转换为 JSON 字符串

            set_clause = ', '.join(f"{k} = ?" for k in new_values)
            params = list(new_values.values()) + [row_key_value]
            sql = f"UPDATE {table_name} SET {set_clause} WHERE {key_column} = ?"
            self.cursor.execute(sql, params)

        self.conn.commit()
        if self.debug:
            logger.debug(f"✅ Batch update completed: {len(updates)} rows.")

    def delete_data(self, table_name: str, condition_col: str, condition_val: Any):
        """
        删除指定条件的行。
        :param table_name: 表名
        :param condition_col: 要查询的列名，用于 WHERE 子句。
        :param condition_val: 查询值
        """
        delete_sql = f"DELETE FROM {table_name} WHERE {condition_col} = ?"
        self.cursor.execute(delete_sql, (condition_val,))
        self.conn.commit()
        if self.debug:
            logger.debug(f"🗑️ Deleted rows from '{table_name}' where '{condition_col}' = '{condition_val}'")

    def read_all(self, table_name: str) -> List[Dict[str, Any]]:
        """
        读取表中所有数据。
        :param table_name: 表名
        :return: 所有数据列表，每一项是一个字典
        """
        self.cursor.execute(f"SELECT * FROM {table_name}")
        columns = [description[0] for description in self.cursor.description]
        results = []
        for row in self.cursor.fetchall():
            row_dict = dict(zip(columns, row))
            for k, v in row_dict.items():
                # Try to decode JSON string
                try:
                    row_dict[k] = json.loads(v)
                except (TypeError, json.JSONDecodeError):
                    pass
            results.append(row_dict)
        return results

    def close(self):
        self.conn.close()
        if self.debug or self.show_conn:
            logger.info(f"🔌 Database '{self.db_path}' closed.")


if __name__ == "__main__":
    LogConfig(level=logging.DEBUG)  # 初始化日志配置
    example_data = [
        {"name": "Alice", "age": 30, "Math": 100, "Physics": 88},
        {"name": "Bob", "age": 25, "Math": 85, "Physics": 90},
    ]

    example_db_path = Path("./.idea/students.db")

    example_db = SQLiteHelper(example_db_path)
    example_db.insert_data("students", example_data)

    example_results = example_db.read_all("students")
    for r in example_results:
        print(r)

    example_db.close()
