import json
import logging
import ffmpeg
import subprocess
from pathlib import Path

# 获取日志记录器
logger: logging.Logger = logging.getLogger(__name__)


def check_ffmpeg_encoder_available(encoder: str = 'h264_nvenc'):
    """
    检查 ffmpeg 编码器是否可用
    :param encoder: str, 编码器名称，默认为 'h264_nvenc'
    :return: bool, 编码器是否可用
    """
    try:
        result = subprocess.run(
            ['ffmpeg', '-f', 'lavfi', '-i', 'nullsrc', '-t', '1',
             '-c:v', encoder, '-f', 'null', '-'],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True
        )
        return result.returncode == 0
    except FileNotFoundError:
        logger.error("ffmpeg 未安装或未添加到系统 PATH 中")
        return False


def get_codecs(filepath: str | Path):
    """
    使用 ffmpeg 检查视频的编码格式
    :param filepath:  str, 文件路径
    :return:  视频编码格式, 音频编码格式
    """
    cmd = [
        'ffprobe', '-v', 'error',
        '-select_streams', 'v:0',
        '-show_entries', 'stream=codec_name',
        '-of', 'json',
        filepath
    ]
    video_streams = json.loads(subprocess.run(cmd, stdout=subprocess.PIPE).stdout).get('streams', [])
    video_codec = video_streams[0]['codec_name'] if video_streams else None

    cmd[4] = 'a:0'  # 替换为音频流
    audio_streams = json.loads(subprocess.run(cmd, stdout=subprocess.PIPE).stdout).get('streams', [])
    audio_codec = audio_streams[0]['codec_name'] if audio_streams else None

    return video_codec, audio_codec


def check_faststart(filename: str | Path) -> bool:
    """
    检查视频文件是否支持 Fast Start（moov atom 在文件头部）
    :param filename: str or Path, 视频文件路径
    :return: bool, 是否支持 Fast Start
    """
    with open(filename, 'rb') as f:
        data = f.read(100000)  # 读取前 100KB
        if b'moov' in data:
            logger.info("✅ moov 在文件头部，支持 Fast Start（可串流播放）")
            return True
        else:
            logger.info("❌ moov 不在文件头部，可能不支持 Fast Start")
            return False


def check_faststart_ffmpeg(filename: str | Path):
    """
    使用 ffmpeg 检查视频文件是否支持 Fast Start（moov atom 在文件头部）
    :param filename: str or Path, 视频文件路径
    :return: bool, 是否支持 Fast Start
    """
    try:
        probe = ffmpeg.probe(filename)
        if 'moov' in probe['format']['tags']:
            logger.info("✅ moov 在文件头部，支持 Fast Start（可串流播放）")
            return True
        else:
            logger.info("❌ moov 不在文件头部，可能不支持 Fast Start")
            return False
    except ffmpeg.Error as e:
        logger.error(f"Error checking Fast Start: {e}")
        return None


def fix_faststart_ffmpeg(input_file: str | Path, output_file: str, vcodec: str = 'libx264', acodec: str = 'aac'):
    """
    使用 ffmpeg 修复视频文件的 Fast Start（将 moov atom 移动到文件头部）
    :param input_file: str or Path, 输入视频文件路径
    :param output_file: str, 输出视频文件路径
    :param vcodec: str, 视频编码器，默认为 'libx264'
    :param acodec: str, 音频编码器，默认为 'aac'
    :return: bool, 是否修复成功
    """
    try:
        (
            ffmpeg
            .input(input_file)
            .output(output_file, vcodec=vcodec,  acodec=acodec, movflags='faststart')
            .run(overwrite_output=True, quiet=True)
        )
        logger.info(f"✅ 已修复 {input_file} 的 Fast Start，输出文件为 {output_file}")
        return True
    except ffmpeg.Error as e:
        logger.error(f"❌ 修复 Fast Start 失败: {e}")
        return False


def get_video_width_height_duration(video_path: str | Path):
    """
    获取视频的宽度和高度
    :param video_path:
    :return: tuple, (width, height)
    """
    video_path = Path(video_path)
    default_width = 720
    default_height = 1280
    default_duration = 0
    if not video_path.is_file():
        logger.warning(f"视频文件不存在: {video_path}")
        return default_width, default_height, default_duration  # 默认宽高, 持续时间

    try:
        # 使用 ffmpeg 获取视频流信息
        probe = ffmpeg.probe(str(video_path))
        # 筛选出视频流
        video_streams = [stream for stream in probe['streams'] if stream['codec_type'] == 'video']
        if not video_streams:
            logger.warning(f"视频流信息未找到: {video_path}")
            return default_width, default_height, default_duration  # 默认宽高, 持续时间

        # 获取第一个视频流的宽度和高度
        width = video_streams[0]['width']
        height = video_streams[0]['height']
        duration = int(float(video_streams[0].get('duration', 0)))
        return width, height, duration
    except ffmpeg.Error as e:
        logger.error(f"获取视频宽高失败: {e.stderr.decode() if e.stderr else str(e)}")
        return default_width, default_height, default_duration  # 默认宽高, 持续时间


def convert_video_to_mp4(input_path: str | Path, output_path: str | Path, vcodec: str = 'libx264', acodec: str = 'aac', crf: int | None = None, fps: float | None = 30, video_bitrate: str | None = '5000k'):
    """
    将视频重新编码为 MP4 格式（H.264 + AAC）
    :param input_path: str or Path, 输入视频文件路径
    :param output_path: str, 输出视频文件路径
    :param vcodec: str, 视频编码器，默认值为 'libx264'
    :param acodec: str, 音频编码器，默认值为 'aac'
    :param crf: int, CRF 值，控制视频质量，较低的值会产生更高质量的视频. 默认值为 None（不设置）, 通常 18-28 是常用范围
    :param fps: float, 帧率，默认值为 30
    :param video_bitrate: str, 视频比特率，默认值为 '5000k'
    :return: tuple, (output_video_path, is_converted)
    """
    input_video_path = Path(input_path)
    is_converted = False

    # 检查输入路径是否为文件
    if not input_video_path.is_file():
        logger.error(f"输入文件不存在: {input_video_path}")
        return input_video_path, is_converted

    # 确保输出目录存在
    output_video_path = Path(output_path)
    output_folder = output_video_path.parent
    output_folder.mkdir(parents=True, exist_ok=True)

    # 设置视频编码器预设
    if vcodec == "libx264":
        preset = "medium"  # 'ultrafast', 'superfast', 'veryfast', 'faster', 'fast', 'medium', 'slow', 'slower', 'veryslow'
    elif vcodec == "h264_nvenc":
        preset = "p5"  # 'p1' (fastest) to 'p7' (slowest)
    else:
        preset = "default"  # 其他编码器使用默认预设

    # 检查 视频音频 编码格式
    original_vcodec, original_acodec = get_codecs(input_video_path)
    # 如果音频编码格式已经是 aac, 则直接复制; 否则使用指定的音频编码格式
    if original_acodec == 'aac':
        audio_codec = 'copy'
    else:
        audio_codec = acodec

    # ffmpeg output parameters
    params = {
        'vcodec': vcodec,
        'acodec': audio_codec,
        'pix_fmt': 'yuv420p',
        'preset': preset,  # 编码预设, 越慢压缩率越高
        'crf': crf if crf else None,  # CRF 值, 控制视频质量
        'r': fps if fps else None,  # 帧率
        # 'g': int(fps * 2) if fps else None,  # 关键帧间隔, 通常为帧率的两倍
        'video_bitrate': video_bitrate if video_bitrate else None,  # 视频比特率
        'strict': 'experimental',
        'movflags': 'faststart'
    }
    # 只保留有值的参数
    clean_params = {k: v for k, v in params.items() if v is not None}
    logger.debug(f"ffmpeg 转码参数: {clean_params}")

    # 尝试使用 ffmpeg 进行视频格式转换
    try:
        (
            ffmpeg
            .input(input_path)
            .output(f"{output_video_path}", **clean_params)
            .run(overwrite_output=True, quiet=True)
        )
        logger.info(f"✅ 视频格式转换成功: {output_video_path}")
        is_converted = True
        return output_video_path, is_converted
    except ffmpeg.Error as e:
        logger.error(f"❌ 视频格式转换失败: {e.stderr.decode() if e.stderr else str(e)}")
        return input_video_path, is_converted


def thumbnail_time_from_duration(duration: int | float) -> float:
    """
    根据视频持续时间计算提取缩略图的时间点
    :param duration: int, 视频持续时间，单位为秒
    :return: float, 提取缩略图的时间点，单位为秒
    """
    if duration <= 5:
        time_sec = duration / 2
    elif duration <= 60:
        time_sec = 5.0  # 短视频, 取第 5 秒
    else:
        time_sec = float(min(60.0, duration / 10))  # 其他长度视频, 取第 60 秒或 1/10 处
    return time_sec


def extract_thumbnail_ffmpeg(video_path: str | Path, output_image_path: str, time_sec: float = 1.0, max_size: int | None = None):
    """
    使用 ffmpeg 从视频中提取缩略图。
    需要安装 ffmpeg，并确保其在系统 PATH 中可用。
    :param video_path: str or Path, 视频文件路径
    :param output_image_path: str, 输出的缩略图文件路径
    :param time_sec: float, 提取缩略图的时间点，单位为秒，默认值为 1.0 秒
    :param max_size: int, 最大尺寸（宽或高），单位为像素，默认值为 None（不调整大小）
    :return:  None
    """
    # 获取输入stream
    stream = ffmpeg.input(video_path, ss=time_sec)

    # 如果指定了最大尺寸，则调整大小
    if max_size:
        stream = stream.filter(
            'scale',
            max_size,
            max_size,
            force_original_aspect_ratio='decrease'
        )

    # 输出缩略图
    (
        stream
        .output(output_image_path, vframes=1)
        .run(overwrite_output=True, quiet=True)
    )
