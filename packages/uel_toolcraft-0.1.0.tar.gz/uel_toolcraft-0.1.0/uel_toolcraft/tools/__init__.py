from .config_tools import read_config_file
from .filesystem_tools import (
    ensure_path,
    get_subfolders,
    shutil_move,
    shutil_move_from_list,
    supported_media_extensions,
    check_file_type,
    scan_media_files,
    scan_json_files,
    convert_bytes_to_human_readable,
    convert_to_bytes,
    md5sum,
    expand_file,
    restore_file,
)
from .json_tools import format_json, read_json_file, write_json_file
from .pickle_tools import read_pickle_file, write_pickle_file
from .txt_tools import (
    read_txt_lines,
    write_txt,
    extract_links,
    join_lines,
    extract_join_links_from_base64,
    remove_ad_chars,
    escape_markdown_chars,
)
from .utils import build_base_parser, get_args

# Optional: ffmpeg
try:
    from .ffmpeg_tools import (
        check_ffmpeg_encoder_available,
        get_codecs,
        check_faststart,
        check_faststart_ffmpeg,
        fix_faststart_ffmpeg,
        get_video_width_height_duration,
        convert_video_to_mp4,
        thumbnail_time_from_duration,
        extract_thumbnail_ffmpeg,
    )
except ImportError:
    check_ffmpeg_encoder_available = (
        get_codecs
    ) = check_faststart = check_faststart_ffmpeg = fix_faststart_ffmpeg = (
        get_video_width_height_duration
    ) = convert_video_to_mp4 = thumbnail_time_from_duration = (
        extract_thumbnail_ffmpeg
    ) = None

# Optional: git
try:
    from .git_tools import (
        create_worktree_temp_dir,
        create_worktree,
        delete_worktree,
        clean_repo_folder,
        reinit_commit,
        get_file_at_branch,
        copy_files_to_branch,
    )
except ImportError:
    create_worktree_temp_dir = create_worktree = delete_worktree = clean_repo_folder = (
        reinit_commit
    ) = get_file_at_branch = copy_files_to_branch = None

# Optional: rclone
try:
    from .rclone_tools import (
        is_rclone_installed,
        get_rclone_version,
        get_rclone_remotes,
        rclone_run,
        rclone_backup_db_file,
    )
except ImportError:
    is_rclone_installed = get_rclone_version = get_rclone_remotes = rclone_run = (
        rclone_backup_db_file
    ) = None

# Optional: supabase
try:
    from .supabase_tools import create_supabase_client
except ImportError:
    create_supabase_client = None

# Optional: PyQt6
try:
    from .ui_tools import select_path
except ImportError:
    select_path = None

__all__ = [
    "read_config_file",
    "ensure_path",
    "get_subfolders",
    "shutil_move",
    "shutil_move_from_list",
    "supported_media_extensions",
    "check_file_type",
    "scan_media_files",
    "scan_json_files",
    "convert_bytes_to_human_readable",
    "convert_to_bytes",
    "md5sum",
    "expand_file",
    "restore_file",
    "format_json",
    "read_json_file",
    "write_json_file",
    "read_pickle_file",
    "write_pickle_file",
    "read_txt_lines",
    "write_txt",
    "extract_links",
    "join_lines",
    "extract_join_links_from_base64",
    "remove_ad_chars",
    "escape_markdown_chars",
    "build_base_parser",
    "get_args",
    "check_ffmpeg_encoder_available",
    "get_codecs",
    "check_faststart",
    "check_faststart_ffmpeg",
    "fix_faststart_ffmpeg",
    "get_video_width_height_duration",
    "convert_video_to_mp4",
    "thumbnail_time_from_duration",
    "extract_thumbnail_ffmpeg",
    "create_worktree_temp_dir",
    "create_worktree",
    "delete_worktree",
    "clean_repo_folder",
    "reinit_commit",
    "get_file_at_branch",
    "copy_files_to_branch",
    "is_rclone_installed",
    "get_rclone_version",
    "get_rclone_remotes",
    "rclone_run",
    "rclone_backup_db_file",
    "create_supabase_client",
    "select_path",
]
