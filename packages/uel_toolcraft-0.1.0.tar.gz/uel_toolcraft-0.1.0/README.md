# uel-toolcraft

A Unified Essential Library toolcraft for personal usage.

## Installation

```bash
pip install uel-toolcraft
```

Install with optional dependencies:

```bash
# All optional dependencies
pip install uel-toolcraft[all]

# Specific extras
pip install uel-toolcraft[pyqt,ffmpeg,git]
```

Local development install:

```bash
git clone https://github.com/iShengren/uel-toolcraft.git
cd uel-toolcraft
uv pip install -e ".[all]"
```

## Usage

### Models

```python
from uel_toolcraft.models import AESCipher, SQLiteHelper, BarkClient

cipher = AESCipher("my-secret-key")
db = SQLiteHelper("mydb.sqlite")
bark = BarkClient("https://bark.example.com", "device_key")
```

### Tools

```python
from uel_toolcraft.tools import read_json_file, write_json_file, md5sum

data = read_json_file("config.json")
checksum = md5sum("large_file.bin")
write_json_file({"key": "value"}, "output.json")
```

### CLI

```bash
uel-toolcraft --version
python -m uel_toolcraft --version
```

## Optional Dependencies

| Extra | Packages | Used by |
|---|---|---|
| `pyqt` | PyQt6 | `PyQtAsyncHelper`, `ui_tools` |
| `ffmpeg` | ffmpeg-python | `ffmpeg_tools` |
| `rclone` | rclone-python | `rclone_tools` |
| `supabase` | supabase | `supabase_tools` |
| `git` | GitPython | `git_tools` |
| `redis` | upstash-redis | `redis_upstash` |

## License

MIT
