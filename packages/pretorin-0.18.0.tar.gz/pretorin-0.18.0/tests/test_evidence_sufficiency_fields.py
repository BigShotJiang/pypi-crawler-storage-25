"""Test that auditor-sufficiency fields round-trip end-to-end (issue #108).

Mirrors the platform-side fields added in monorepo #701 PR A:
- data_coverage_start_at
- data_coverage_end_at
- capture_query

The CLI accepts these as flags on `pretorin evidence upsert` and forwards them
into the EvidenceCreate payload sent to the public API. The MCP create_evidence
tool accepts them as arguments and does the same.
"""

from __future__ import annotations

import pytest

from pretorin.client.models import EvidenceCreate


class TestEvidenceCreateSufficiencyFields:
    def test_fields_default_to_none(self) -> None:
        ec = EvidenceCreate(
            name="x",
            description="markdown body",
            evidence_type="other",
        )
        assert ec.data_coverage_start_at is None
        assert ec.data_coverage_end_at is None
        assert ec.capture_query is None

    def test_fields_round_trip(self) -> None:
        ec = EvidenceCreate(
            name="aws-config-snapshot",
            description="markdown body",
            evidence_type="configuration",
            data_coverage_start_at="2026-01-01T00:00:00Z",
            data_coverage_end_at="2026-03-31T23:59:59Z",
            capture_query="aws configservice get-resource-config-history",
        )
        as_dict = ec.model_dump(exclude_none=True)
        assert as_dict["data_coverage_start_at"] == "2026-01-01T00:00:00Z"
        assert as_dict["data_coverage_end_at"] == "2026-03-31T23:59:59Z"
        assert (
            as_dict["capture_query"]
            == "aws configservice get-resource-config-history"
        )

    def test_point_in_time_omits_end(self) -> None:
        ec = EvidenceCreate(
            name="snapshot",
            description="markdown body",
            evidence_type="screenshot",
            data_coverage_start_at="2026-05-08T12:00:00Z",
        )
        assert ec.data_coverage_start_at == "2026-05-08T12:00:00Z"
        assert ec.data_coverage_end_at is None


class TestEvidenceUpsertWiring:
    """Smoke test that the workflow function accepts the new kwargs.

    Full integration is covered by the four-surface verification (Phase 3);
    this just protects against signature drift.
    """

    def test_upsert_evidence_signature_accepts_new_kwargs(self) -> None:
        from inspect import signature

        from pretorin.workflows.compliance_updates import upsert_evidence

        params = signature(upsert_evidence).parameters
        assert "data_coverage_start_at" in params
        assert "data_coverage_end_at" in params
        assert "capture_query" in params
