# Release Setup Verification

## Verdict

Release setup is broadly sound for the intended flow:

- PyPI project name is `vdl` in [`pyproject.toml`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/pyproject.toml).
- The package layout under `src/vdl` is valid.
- Console entry points `vdl` and `vdl-mcp` are declared and present in the built wheel.
- `src/vdl/data/websites.yaml` is included in both the wheel and sdist.
- Root GitLab CI includes the release files and allows `vdl-vX.Y.Z` tags, merge requests, and `main` branch pushes.
- PyPI publish is wired for Trusted Publishing with environment `pypi` and `aud: pypi`, with `PYPI_API_TOKEN` fallback.

The repo still needs manual platform setup in GitLab and PyPI before the first real release.

## Issues Found

1. Optional Linux and Windows CI jobs did not emit `out/SHA256SUMS` as required by the release checklist.
2. The standalone `vdl-mcp` PyInstaller builds relied on a lazy runtime import of `mcp`, which is easy for PyInstaller to miss unless we bundle it explicitly.
3. [`docs/RELEASE_PLAYBOOK.md`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/docs/RELEASE_PLAYBOOK.md) needed to be aligned with the actual final flow:
   - Trusted Publishing first
   - local macOS upload with `glab`
   - optional Linux/Windows CI builds behind variables
   - manual Pages manifest refresh after release assets exist
4. Windows installer behavior is still future work. [`scripts/install.sh`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/scripts/install.sh) is sensible for Unix installs, but it is not a Windows installer.

## Fixes Applied

- Updated [`ci/release-linux.yml`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/ci/release-linux.yml) to:
  - keep the `VDL_BUILD_LINUX_CI=1` gate
  - emit `out/SHA256SUMS`
  - preserve the per-asset `.sha256` file expected by the Pages job
  - bundle `mcp` explicitly in the `vdl-mcp` PyInstaller build
- Updated [`ci/release-windows.yml`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/ci/release-windows.yml) to:
  - keep the `VDL_BUILD_WINDOWS_CI=1` gate
  - emit `out/SHA256SUMS`
  - preserve the per-asset `.sha256` file expected by the Pages job
  - bundle `mcp` explicitly in the `vdl-mcp` PyInstaller build
- Updated [`scripts/build-macos.sh`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/scripts/build-macos.sh) to:
  - sync with `--all-extras --dev`
  - bundle `mcp` explicitly in the `vdl-mcp` PyInstaller build
  - verify the `vdl-mcp` executable is produced
- Updated [`docs/RELEASE_PLAYBOOK.md`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/docs/RELEASE_PLAYBOOK.md) to match the intended release process and exact setup values.

## Verification Results

### Package

- Confirmed `[project].name = "vdl"`.
- Confirmed `[project].version = "1.0.0"`.
- Confirmed source package exists under `src/vdl`.
- Confirmed console scripts in built wheel:
  - `vdl = vdl.cli:main`
  - `vdl-mcp = vdl.mcp_server:main`
- Confirmed non-MCP tool facade is importable from the package:
  - `import vdl.tools`
- Confirmed packaged data file in built artifacts:
  - `vdl/data/websites.yaml`

### GitLab CI

- [`.gitlab-ci.yml`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/.gitlab-ci.yml) includes:
  - [`ci/release-vdl.yml`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/ci/release-vdl.yml)
  - [`ci/release-linux.yml`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/ci/release-linux.yml)
  - [`ci/release-windows.yml`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/ci/release-windows.yml)
- Release tags allowed by workflow:
  - `vdl-vX.Y.Z`
- Normal validation behavior allowed by workflow:
  - merge request pipelines
  - `main` branch push pipelines
- [`ci/release-vdl.yml`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/ci/release-vdl.yml) uses:
  - `uv sync --frozen --all-extras --dev` in `.pre`
  - cache paths `.venv/` and `.uv-cache/`
  - `uv build --no-sources`
  - environment `pypi`
  - OIDC `id_tokens` with `aud: pypi`
  - manual Pages job after release assets exist

### Installer / Binary Flow

- [`scripts/build-macos.sh`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/scripts/build-macos.sh) is set to produce:
  - `out/vdl-<version>-aarch64-apple-darwin.tar.gz`
  - `out/SHA256SUMS`
- [`scripts/install.sh`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/scripts/install.sh):
  - reads `release.json` from GitLab Pages
  - verifies SHA256
  - installs `vdl` and `vdl-mcp` into `~/.local/bin` on Unix
  - supports current release targets `aarch64-apple-darwin` and `x86_64-unknown-linux-gnu`
  - does not currently implement a native Windows install path

## Local Validation Run

Successful:

- `uv sync --frozen --all-extras --dev`
- `PYTHONPATH=src uv run pytest -q`
- `uv build --no-sources`
- `PYTHONPATH=src uv run python -c "import vdl.tools"`
- `task --list`
- `sh -n scripts/install.sh`
- `bash -n scripts/build-macos.sh`
- YAML parse check for `.gitlab-ci.yml` and `ci/*.yml` using Ruby `YAML.load_file`

Not available in this environment:

- `shellcheck`
- Python `yaml` module for a `yamllint`-style parse shortcut

Not executed here:

- `scripts/build-macos.sh` full binary build, because this session is not running on macOS arm64
- GitLab Windows runner execution
- GitLab Linux/Windows release job execution inside CI

## Remaining Manual Setup

1. In PyPI, add a pending Trusted Publisher:
   - Platform: `GitLab CI/CD`
   - PyPI project name: `vdl`
   - GitLab namespace: `bildcraft/products`
   - GitLab project name: `video-downloader`
   - Workflow file: `.gitlab-ci.yml`
   - Environment name: `pypi`
2. In GitLab, create environment:
   - `pypi`
3. In GitLab CI/CD variables, set:
   - `VDL_BUILD_LINUX_CI=0`
   - `VDL_BUILD_WINDOWS_CI=0`
4. Optionally add fallback only if Trusted Publishing fails:
   - `PYPI_API_TOKEN=pypi-...`
5. Protect release tags:
   - `vdl-v*`
6. Ensure the local release machine has:
   - `uv`
   - Python `3.13`
   - GitLab API credentials available through `.env` (`GITLAB_TOKEN`) or `glab auth login`
   - `ffmpeg`
   - `ffprobe`

## Exact PyPI Trusted Publisher Settings

- Platform: `GitLab CI/CD`
- Project name: `vdl`
- Namespace: `bildcraft/products`
- Project: `video-downloader`
- Workflow file: `.gitlab-ci.yml`
- Environment: `pypi`

## Exact GitLab CI/CD Variables

- `VDL_BUILD_LINUX_CI=0`
- `VDL_BUILD_WINDOWS_CI=0`

Optional fallback only:

- `PYPI_API_TOKEN=pypi-...`

Recommended variable settings:

- `Protected: yes`
- `Masked: no` for `VDL_BUILD_LINUX_CI` and `VDL_BUILD_WINDOWS_CI`
- `Masked: yes` for `PYPI_API_TOKEN`

## Exact Local Token/Auth Requirements

- Provide a GitLab token through `.env` as `GITLAB_TOKEN` or through `glab auth login`
- Use a GitLab token with scopes:
  - `api`
  - `write_repository`
- No local PyPI token is required for the intended flow

## Dry-Run Release Checklist

1. Confirm [`pyproject.toml`](/Users/temmie/codes-and-scripts/projects/bildcraft/products/video-downloader/pyproject.toml) still says:
   - `name = "vdl"`
   - correct release `version`
2. Run:
   - `uv sync --frozen --all-extras --dev`
   - `PYTHONPATH=src uv run pytest -q`
   - `uv build --no-sources`
   - `PYTHONPATH=src uv run python -c "import vdl.tools"`
3. Build macOS artifact locally on Apple Silicon:
   - `./scripts/build-macos.sh`
4. Confirm local outputs:
   - `out/vdl-<version>-aarch64-apple-darwin.tar.gz`
   - `out/SHA256SUMS`
5. Tag and push:
   - `git tag vdl-vX.Y.Z`
   - `git push origin vdl-vX.Y.Z`
6. Upload local macOS assets to the GitLab Release:
   - `glab release create ...` or `glab release upload ...`
7. Let GitLab CI:
   - run tests
   - build sdist/wheel
   - publish to PyPI through Trusted Publishing
8. If Linux/Windows binaries are wanted, enable:
   - `VDL_BUILD_LINUX_CI=1`
   - `VDL_BUILD_WINDOWS_CI=1`
9. After release assets exist, run the manual Pages job:
   - `vdl-publish-pages`
10. Smoke test installer from GitLab Pages on a clean machine.

## Notes

- Optional Linux/Windows jobs currently build artifacts only. If you want those binaries to appear in `release.json`, their assets and checksums still need to be attached to the GitLab Release before the manual Pages job runs.
- The report intentionally does not remove or alter `frozen/vdl-v0`.
