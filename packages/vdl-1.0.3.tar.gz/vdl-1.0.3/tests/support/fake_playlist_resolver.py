from __future__ import annotations

from vdl.models import PlaylistInfo, PlaylistItem
from vdl.playlist import PlaylistInspection


class FakePlaylistResolver:
    """Test double for PlaylistResolver."""

    def __init__(
        self,
        items: list[PlaylistItem] | None = None,
        title: str = "Fake Playlist",
        error: Exception | None = None,
        inspections: dict[str, PlaylistInspection] | None = None,
    ) -> None:
        self._items = (
            items
            if items is not None
            else [
                PlaylistItem(
                    url="https://youtube.com/watch?v=fake1", title="Video 1", index=0
                ),
                PlaylistItem(
                    url="https://youtube.com/watch?v=fake2", title="Video 2", index=1
                ),
            ]
        )
        self._title = title
        self._error = error
        self._inspections = inspections or {}
        self.calls: list[str] = []

    async def resolve(self, url: str) -> PlaylistInfo:
        self.calls.append(url)
        if self._error:
            raise self._error
        return PlaylistInfo(url=url, title=self._title, items=self._items)

    async def inspect_url(self, url: str) -> PlaylistInspection:
        self.calls.append(f"inspect:{url}")
        return self._inspections.get(
            url, PlaylistInspection(kind="single", entry_url=url)
        )
