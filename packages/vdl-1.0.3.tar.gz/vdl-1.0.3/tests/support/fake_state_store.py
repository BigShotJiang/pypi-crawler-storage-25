from __future__ import annotations

from vdl.models import (
    DownloadResult,
    DownloadStatus,
    Quality,
    StatusRecord,
    build_request_key,
)
from vdl.progress import DownloadProgress


class InMemoryStateStore:
    """Test fake for StateStore. In-process storage with no persistence."""

    def __init__(self) -> None:
        self._store: dict[str, StatusRecord] = {}
        self._url_index: dict[str, str] = {}  # source_url → id
        self._request_index: dict[str, str] = {}  # request_key → id

    def record_started(
        self,
        id: str,
        source_url: str,
        command: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None:
        effective_request_key = request_key or (
            build_request_key(source_url, quality) if quality else None
        )
        record = StatusRecord(
            id=id,
            source_url=source_url,
            status=DownloadStatus.STARTING,
            quality=quality,
            request_key=effective_request_key,
        )
        self._store[id] = record
        self._url_index[source_url] = id
        if effective_request_key:
            self._request_index[effective_request_key] = id

    def record_progress(
        self,
        progress: DownloadProgress,
        source_url: str,
        command: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None:
        existing = self._store.get(progress.id)
        effective_request_key = (
            request_key
            or (existing.request_key if existing else None)
            or (build_request_key(source_url, quality) if quality else None)
        )
        record = StatusRecord(
            id=progress.id,
            source_url=source_url,
            status=progress.status,
            quality=quality or (existing.quality if existing else None),
            request_key=effective_request_key,
            percent=progress.percent,
        )
        self._store[progress.id] = record
        self._url_index[source_url] = progress.id
        if effective_request_key:
            self._request_index[effective_request_key] = progress.id

    def record_completed(self, result: DownloadResult) -> None:
        existing = self._store.get(result.id)
        record = StatusRecord(
            id=result.id,
            source_url=result.source_url,
            status=DownloadStatus.COMPLETED,
            quality=result.quality or (existing.quality if existing else None),
            request_key=result.request_key
            or (existing.request_key if existing else None),
            output_path=result.output_path,
        )
        self._store[result.id] = record
        self._url_index[result.source_url] = result.id
        if record.request_key:
            self._request_index[record.request_key] = result.id

    def record_failed(
        self,
        id: str,
        source_url: str,
        error: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None:
        existing = self._store.get(id)
        effective_request_key = (
            request_key
            or (existing.request_key if existing else None)
            or (build_request_key(source_url, quality) if quality else None)
        )
        record = StatusRecord(
            id=id,
            source_url=source_url,
            status=DownloadStatus.FAILED,
            quality=quality or (existing.quality if existing else None),
            request_key=effective_request_key,
            error=error,
        )
        self._store[id] = record
        self._url_index[source_url] = id
        if effective_request_key:
            self._request_index[effective_request_key] = id

    def record_cancelled(
        self,
        id: str,
        source_url: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None:
        existing = self._store.get(id)
        effective_request_key = (
            request_key
            or (existing.request_key if existing else None)
            or (build_request_key(source_url, quality) if quality else None)
        )
        record = StatusRecord(
            id=id,
            source_url=source_url,
            status=DownloadStatus.CANCELLED,
            quality=quality or (existing.quality if existing else None),
            request_key=effective_request_key,
        )
        self._store[id] = record
        self._url_index[source_url] = id
        if effective_request_key:
            self._request_index[effective_request_key] = id

    def find_by_url(self, source_url: str) -> StatusRecord | None:
        record_id = self._url_index.get(source_url)
        return self._store.get(record_id) if record_id else None

    def find_by_request(self, source_url: str, quality: Quality) -> StatusRecord | None:
        request_key = build_request_key(source_url, quality)
        record_id = self._request_index.get(request_key)
        return self._store.get(record_id) if record_id else None

    def get_status(self, id: str) -> StatusRecord | None:
        return self._store.get(id)

    def list_recent(self, limit: int = 20) -> list[StatusRecord]:
        records = sorted(self._store.values(), key=lambda r: r.updated_at, reverse=True)
        return records[:limit]
