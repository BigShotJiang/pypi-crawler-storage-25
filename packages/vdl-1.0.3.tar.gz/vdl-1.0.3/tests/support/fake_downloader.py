from __future__ import annotations

import uuid
from pathlib import Path

from vdl.cancellation import CancellationToken
from vdl.models import DownloadRequest, DownloadResult, DownloadStatus
from vdl.progress import DownloadProgress, ProgressCallback


class FakeDownloader:
    """Test double for Downloader. Returns preset results or a default completed result."""

    def __init__(
        self,
        results: dict[str, tuple[DownloadStatus, Path | None]] | None = None,
    ) -> None:
        self._results = results or {}
        self.calls: list[DownloadRequest] = []

    async def download(
        self,
        request: DownloadRequest,
        *,
        on_progress: ProgressCallback | None = None,
        cancel_token: CancellationToken | None = None,
    ) -> DownloadResult:
        self.calls.append(request)
        url = request.source.raw
        status, output_path = self._results.get(
            url, (DownloadStatus.COMPLETED, Path("/fake/video.mp4"))
        )
        download_id = str(uuid.uuid4())
        if on_progress:
            on_progress(DownloadProgress(id=download_id, status=status, percent=100.0))
        return DownloadResult(
            id=download_id,
            source_url=url,
            status=status,
            output_path=output_path,
        )
