"""Phase 1: Skeleton integration import tests."""


def test_vdl_top_level_import():
    """Test that the vdl package imports cleanly."""
    import vdl  # noqa: F401


def test_vdl_public_names():
    """Test that all public API names are importable."""
    from vdl import (
        DoctorReport,
        DownloadProgress,
        DownloadRequest,
        DownloadResult,
        DownloadStatus,
        NullLogger,
        PlaylistInfo,
        PlaylistItem,
        ReconciliationReport,
        VDLClient,
        VDLConfig,
        VDLError,
    )  # noqa: F401


def test_vdl_module_imports():
    """Test that all skeleton modules import without error."""
    import vdl.acquisition  # noqa: F401
    import vdl.cli  # noqa: F401
    import vdl.client  # noqa: F401
    import vdl.config  # noqa: F401
    import vdl.crawler  # noqa: F401
    import vdl.doctor  # noqa: F401
    import vdl.downloader  # noqa: F401
    import vdl.errors  # noqa: F401
    import vdl.input_parser  # noqa: F401
    import vdl.interactive  # noqa: F401
    import vdl.logging  # noqa: F401
    import vdl.models  # noqa: F401
    import vdl.naming  # noqa: F401
    import vdl.paths  # noqa: F401
    import vdl.playlist  # noqa: F401
    import vdl.progress  # noqa: F401
    import vdl.selection  # noqa: F401
    import vdl.site_rules  # noqa: F401
    import vdl.state  # noqa: F401
    import vdl.tools  # noqa: F401
    import vdl.urls  # noqa: F401


def test_vdl_tools_public_names():
    from vdl.tools import (
        doctor,
        doctor_sync,
        download_video,
        download_video_sync,
        get_status,
        get_status_sync,
        plan_download,
        plan_download_sync,
        resolve_playlist,
        resolve_playlist_sync,
    )  # noqa: F401
