from __future__ import annotations

from vdl.interactive import _find_index_for_url
from vdl.models import PlaylistInfo, PlaylistItem
from vdl.urls import youtube_video_id


def _playlist(items):
    return PlaylistInfo(
        url="https://youtube.com/playlist?list=PLx", title="Mix", items=items
    )


class TestYoutubeVideoId:
    def test_watch_url(self):
        assert youtube_video_id("https://www.youtube.com/watch?v=abc123") == "abc123"

    def test_watch_with_list(self):
        assert (
            youtube_video_id("https://www.youtube.com/watch?v=abc123&list=PL999")
            == "abc123"
        )

    def test_youtu_be_short_url(self):
        assert youtube_video_id("https://youtu.be/abc123") == "abc123"

    def test_no_id(self):
        assert youtube_video_id("https://example.com/page") is None


class TestFindIndexForUrl:
    def test_match_by_item_id(self):
        playlist = _playlist(
            [
                PlaylistItem(url="https://youtube.com/watch?v=aaa", id="aaa", index=0),
                PlaylistItem(url="https://youtube.com/watch?v=bbb", id="bbb", index=1),
            ]
        )
        idx = _find_index_for_url(
            playlist, "https://www.youtube.com/watch?v=bbb&list=PLx"
        )
        assert idx == 1

    def test_match_by_url_video_id(self):
        playlist = _playlist(
            [
                PlaylistItem(url="https://youtube.com/watch?v=aaa", index=0),
                PlaylistItem(url="https://youtube.com/watch?v=bbb", index=1),
            ]
        )
        idx = _find_index_for_url(
            playlist, "https://www.youtube.com/watch?v=bbb&list=PLx"
        )
        assert idx == 1

    def test_no_match(self):
        playlist = _playlist(
            [
                PlaylistItem(url="https://youtube.com/watch?v=aaa", index=0),
            ]
        )
        idx = _find_index_for_url(
            playlist, "https://www.youtube.com/watch?v=zzz&list=PLx"
        )
        assert idx is None

    def test_non_youtube_url_returns_none(self):
        playlist = _playlist([PlaylistItem(url="https://x", id="x", index=0)])
        assert _find_index_for_url(playlist, "https://example.com") is None
