"""Tests for first-run bootstrap initialization."""

from pathlib import Path
from unittest.mock import patch

import pytest

from vdl.bootstrap import ensure_app_ready
from vdl.paths import VDLPaths, get_default_paths


def _test_paths(tmp_path: Path) -> VDLPaths:
    config_dir = tmp_path / "config" / "vdl"
    state_dir = tmp_path / "state" / "vdl"
    return VDLPaths(
        config_dir=config_dir,
        config_file=config_dir / "config.toml",
        site_rules_file=config_dir / "websites.yaml",
        state_dir=state_dir,
        state_db=state_dir / "vdl.db",
        cache_dir=tmp_path / "cache" / "vdl",
        logs_dir=state_dir / "logs",
        downloads_dir=tmp_path / "Downloads" / "VDL",
    )


def test_creates_directories_on_first_run(tmp_path):
    paths = _test_paths(tmp_path)
    ensure_app_ready(paths)
    assert paths.config_dir.is_dir()
    assert paths.state_dir.is_dir()
    assert paths.logs_dir.is_dir()
    assert paths.cache_dir.is_dir()
    assert paths.downloads_dir.is_dir()


def test_creates_config_toml_on_first_run(tmp_path):
    paths = _test_paths(tmp_path)
    assert not paths.config_file.exists()
    ensure_app_ready(paths)
    assert paths.config_file.exists()
    content = paths.config_file.read_text()
    assert "output_dir" in content


def test_does_not_overwrite_existing_config(tmp_path):
    paths = _test_paths(tmp_path)
    paths.config_dir.mkdir(parents=True)
    paths.config_file.write_text('output_dir = "/custom/path"\n')
    ensure_app_ready(paths)
    assert "/custom/path" in paths.config_file.read_text()


def test_creates_state_db_on_first_run(tmp_path):
    paths = _test_paths(tmp_path)
    assert not paths.state_db.exists()
    ensure_app_ready(paths)
    assert paths.state_db.exists()


def test_idempotent_repeated_calls(tmp_path):
    paths = _test_paths(tmp_path)
    ensure_app_ready(paths)
    mtime_config = paths.config_file.stat().st_mtime
    mtime_db = paths.state_db.stat().st_mtime
    ensure_app_ready(paths)
    assert paths.config_file.stat().st_mtime == mtime_config
    assert paths.state_db.stat().st_mtime == mtime_db


def test_skips_site_rules_when_no_bundle(tmp_path):
    paths = _test_paths(tmp_path)
    with patch("vdl.bootstrap.bundled_site_rules_path", return_value=None):
        ensure_app_ready(paths)
    assert not paths.site_rules_file.exists()


def test_copies_bundled_site_rules_when_missing(tmp_path):
    paths = _test_paths(tmp_path)
    bundled = tmp_path / "bundled_websites.yaml"
    bundled.write_text("- domain: example.com\n")
    with patch("vdl.bootstrap.bundled_site_rules_path", return_value=bundled):
        ensure_app_ready(paths)
    assert paths.site_rules_file.exists()
    assert "example.com" in paths.site_rules_file.read_text()


def test_does_not_overwrite_existing_site_rules(tmp_path):
    paths = _test_paths(tmp_path)
    bundled = tmp_path / "bundled_websites.yaml"
    bundled.write_text("- domain: bundled.com\n")
    paths.config_dir.mkdir(parents=True)
    paths.site_rules_file.write_text("- domain: user.com\n")
    with patch("vdl.bootstrap.bundled_site_rules_path", return_value=bundled):
        ensure_app_ready(paths)
    assert "user.com" in paths.site_rules_file.read_text()


def test_bootstrap_copies_real_packaged_data_file(tmp_path):
    from vdl.paths import bundled_site_rules_path

    bundled = bundled_site_rules_path()
    if bundled is None:
        pytest.skip("bundled websites.yaml not present in this environment")
    paths = _test_paths(tmp_path)
    ensure_app_ready(paths)
    assert paths.site_rules_file.exists()
    assert paths.site_rules_file.read_bytes() == bundled.read_bytes()
