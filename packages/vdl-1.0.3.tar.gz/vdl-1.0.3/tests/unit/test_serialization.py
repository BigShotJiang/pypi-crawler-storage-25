from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from vdl.models import (
    BatchSummary,
    DoctorReport,
    DownloadResult,
    DownloadStatus,
    PlaylistInfo,
    PlaylistItem,
    Quality,
    StatusRecord,
)
from vdl.progress import DownloadProgress
from vdl.serialization import (
    batch_summary_to_dict,
    doctor_report_to_dict,
    download_progress_to_dict,
    download_result_to_dict,
    download_results_to_list,
    format_speed_bps,
    playlist_info_to_dict,
    status_record_to_dict,
)


class TestFormatSpeed:
    def test_none(self):
        assert format_speed_bps(None) == ""

    def test_bytes(self):
        assert format_speed_bps(0) == "0 B/s"
        assert format_speed_bps(900) == "900 B/s"

    def test_kilobytes(self):
        assert format_speed_bps(1024) == "1 KB/s"
        assert format_speed_bps(842_000) == "822 KB/s"

    def test_megabytes(self):
        assert format_speed_bps(5_300_000) == "5.1 MB/s"
        assert format_speed_bps(10 * 1024 * 1024) == "10.0 MB/s"

    def test_gigabytes(self):
        assert format_speed_bps(2 * 1024 * 1024 * 1024) == "2.0 GB/s"


class TestDownloadResultSerializer:
    def test_minimal(self):
        result = DownloadResult(
            id="abc",
            source_url="https://example/x",
            status=DownloadStatus.COMPLETED,
        )
        d = download_result_to_dict(result)
        assert d["id"] == "abc"
        assert d["status"] == "completed"
        assert d["output"] is None
        assert d["metadata"] == {}

    def test_full(self):
        result = DownloadResult(
            id="abc",
            source_url="https://example/x",
            status=DownloadStatus.COMPLETED,
            quality=Quality.P1080,
            request_key="https://example/x::1080p",
            output_path=Path("/out/video.mp4"),
            metadata={"title": "Hi"},
        )
        d = download_result_to_dict(result)
        assert d["quality"] == "1080p"
        assert d["request_key"] == "https://example/x::1080p"
        assert d["output"] == "/out/video.mp4"
        assert d["metadata"] == {"title": "Hi"}

    def test_list(self):
        result = DownloadResult(id="a", source_url="u", status=DownloadStatus.COMPLETED)
        assert download_results_to_list([result, result])[0]["id"] == "a"
        assert len(download_results_to_list([result, result])) == 2


class TestPlaylistSerializer:
    def test_basic(self):
        info = PlaylistInfo(
            url="https://p",
            title="My Playlist",
            items=[
                PlaylistItem(url="u1", index=0, title="t1"),
                PlaylistItem(url="u2", index=1),
            ],
        )
        d = playlist_info_to_dict(info)
        assert d["title"] == "My Playlist"
        assert d["count"] == 2
        assert d["items"][0] == {"index": 0, "title": "t1", "url": "u1"}


class TestStatusSerializer:
    def test_basic(self):
        record = StatusRecord(
            id="x",
            source_url="u",
            status=DownloadStatus.COMPLETED,
            quality=Quality.BEST,
            output_path=Path("/o.mp4"),
            updated_at=datetime(2026, 1, 1, tzinfo=UTC),
        )
        d = status_record_to_dict(record)
        assert d["status"] == "completed"
        assert d["output"] == "/o.mp4"
        assert d["updated_at"].startswith("2026-01-01")


class TestDoctorSerializer:
    def test_basic(self):
        report = DoctorReport(
            version="1",
            ffmpeg_available=True,
            ytdlp_available=True,
            config_ok=True,
            state_ok=True,
            output_dir_ok=True,
            details={"ffmpeg": "/bin/ffmpeg"},
        )
        d = doctor_report_to_dict(report)
        assert d["ffmpeg"] is True
        assert d["details"] == {"ffmpeg": "/bin/ffmpeg"}


class TestBatchSerializer:
    def test_counts(self):
        results = [
            DownloadResult(id="a", source_url="u", status=DownloadStatus.COMPLETED),
            DownloadResult(id="b", source_url="u", status=DownloadStatus.FAILED),
        ]
        summary = BatchSummary.from_results(results)
        d = batch_summary_to_dict(summary)
        assert d["total"] == 2
        assert d["completed"] == 1
        assert d["failed"] == 1


class TestProgressSerializer:
    def test_speed_is_formatted(self):
        p = DownloadProgress(
            id="x",
            status=DownloadStatus.DOWNLOADING,
            speed_bps=2_500_000,
            title="Hi",
            percent=42.5,
        )
        d = download_progress_to_dict(p)
        assert d["speed_bps"] == 2_500_000
        assert "MB/s" in d["speed"]
        assert d["title"] == "Hi"
        assert d["percent"] == 42.5
