from __future__ import annotations

import asyncio

import pytest

from support.fake_downloader import FakeDownloader
from support.fake_state_store import InMemoryStateStore
from vdl.cancellation import CancellationToken
from vdl.client import VDLClient
from vdl.config import VDLConfig
from vdl.models import DownloadStatus


def _config(tmp_path):
    return VDLConfig(output_dir=tmp_path / "downloads")


class _CancellingDownloader(FakeDownloader):
    """Sleeps until the cancel token is set, then returns CANCELLED."""

    async def download(self, request, *, on_progress=None, cancel_token=None):
        self.calls.append(request)
        # Simulate a long-running download that polls the token.
        for _ in range(50):
            if cancel_token is not None and cancel_token.is_cancelled:
                from vdl.models import DownloadResult

                return DownloadResult(
                    id="x",
                    source_url=request.source.raw,
                    status=DownloadStatus.CANCELLED,
                )
            await asyncio.sleep(0.01)
        from vdl.models import DownloadResult

        return DownloadResult(
            id="x",
            source_url=request.source.raw,
            status=DownloadStatus.COMPLETED,
        )


@pytest.mark.asyncio
async def test_cancel_token_aborts_in_flight_download(tmp_path):
    token = CancellationToken()
    state_store = InMemoryStateStore()
    client = VDLClient(
        config=_config(tmp_path),
        downloader=_CancellingDownloader(),
        state_store=state_store,
    )

    async def cancel_soon() -> None:
        await asyncio.sleep(0.05)
        token.cancel()

    download_task = asyncio.create_task(
        client.download("https://example.com/v", cancel_token=token)
    )
    await asyncio.gather(download_task, cancel_soon())
    result = download_task.result()
    assert result.status == DownloadStatus.CANCELLED
    record = state_store.get_status(result.id)
    assert record is not None
    assert record.status == DownloadStatus.CANCELLED


def test_cancellation_token_is_thread_safe_flag():
    token = CancellationToken()
    assert token.is_cancelled is False
    token.cancel()
    assert token.is_cancelled is True
    token.reset()
    assert token.is_cancelled is False


def test_composite_cancellation_token_or_semantics():
    from vdl.cancellation import CompositeCancellationToken

    a = CancellationToken()
    b = CancellationToken()
    composite = CompositeCancellationToken(a, b)
    assert composite.is_cancelled is False
    a.cancel()
    assert composite.is_cancelled is True


def test_composite_cancel_propagates_to_all_parents():
    from vdl.cancellation import CompositeCancellationToken

    a = CancellationToken()
    b = CancellationToken()
    composite = CompositeCancellationToken(a, b)
    composite.cancel()
    assert a.is_cancelled and b.is_cancelled


class TestCancellationController:
    def test_register_returns_distinct_token(self):
        from vdl.cancellation import CancellationController

        ctrl = CancellationController()
        t1 = ctrl.register("k1", "first")
        t2 = ctrl.register("k2", "second")
        assert t1 is not t2
        assert not t1.is_cancelled
        assert not t2.is_cancelled

    def test_active_lists_uncancelled_keys(self):
        from vdl.cancellation import CancellationController

        ctrl = CancellationController()
        ctrl.register("k1", "first")
        ctrl.register("k2", "second")
        assert {k for k, _ in ctrl.active()} == {"k1", "k2"}

    def test_cancel_targets_one_token(self):
        from vdl.cancellation import CancellationController

        ctrl = CancellationController()
        t1 = ctrl.register("k1", "first")
        t2 = ctrl.register("k2", "second")
        assert ctrl.cancel("k1") is True
        assert t1.is_cancelled
        assert not t2.is_cancelled
        # Unknown key returns False rather than raising.
        assert ctrl.cancel("missing") is False

    def test_cancel_all_targets_every_token(self):
        from vdl.cancellation import CancellationController

        ctrl = CancellationController()
        t1 = ctrl.register("k1", "first")
        t2 = ctrl.register("k2", "second")
        ctrl.cancel_all()
        assert t1.is_cancelled and t2.is_cancelled

    def test_unregister_removes_from_active(self):
        from vdl.cancellation import CancellationController

        ctrl = CancellationController()
        ctrl.register("k1", "first")
        ctrl.unregister("k1")
        assert ctrl.active() == []

    def test_active_filters_out_cancelled(self):
        from vdl.cancellation import CancellationController

        ctrl = CancellationController()
        ctrl.register("k1", "first")
        ctrl.register("k2", "second")
        ctrl.cancel("k1")
        assert {k for k, _ in ctrl.active()} == {"k2"}

    def test_update_label_changes_what_active_returns(self):
        from vdl.cancellation import CancellationController

        ctrl = CancellationController()
        ctrl.register("k1", "url")
        ctrl.update_label("k1", "Friendly Title")
        assert ctrl.active() == [("k1", "Friendly Title")]


@pytest.mark.asyncio
async def test_controller_targeted_cancel_only_aborts_one_task(tmp_path):
    """Cancelling one URL via the controller leaves siblings to complete."""
    from vdl.acquisition import AcquisitionItem, AcquisitionPlan
    from vdl.cancellation import CancellationController
    from vdl.models import InputKind

    ctrl = CancellationController()
    client = VDLClient(
        config=_config(tmp_path),
        downloader=_CancellingDownloader(),
        state_store=InMemoryStateStore(),
    )
    plan = AcquisitionPlan(
        items=[
            AcquisitionItem(source_url="https://example.com/a"),
            AcquisitionItem(source_url="https://example.com/b"),
        ],
        source_kind=InputKind.URL,
        total=2,
    )

    async def cancel_one_soon() -> None:
        # Wait until the controller has registered both tasks.
        for _ in range(50):
            if {k for k, _ in ctrl.active()} >= {"https://example.com/a"}:
                break
            await asyncio.sleep(0.01)
        ctrl.cancel("https://example.com/a")

    download_task = asyncio.create_task(client.download_plan(plan, controller=ctrl))
    await asyncio.gather(download_task, cancel_one_soon())
    results = download_task.result()
    statuses = {r.source_url: r.status for r in results}
    assert statuses["https://example.com/a"] == DownloadStatus.CANCELLED
    assert statuses["https://example.com/b"] == DownloadStatus.COMPLETED
