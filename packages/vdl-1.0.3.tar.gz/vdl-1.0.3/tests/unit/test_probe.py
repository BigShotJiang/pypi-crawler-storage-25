from __future__ import annotations

from vdl.probe import is_known_media_url


def test_youtube_watch_url_matches_a_specific_extractor():
    """yt-dlp ships a YouTube extractor; a watch URL must probe positive."""
    assert is_known_media_url("https://www.youtube.com/watch?v=abc123") is True


def test_random_listing_page_does_not_probe_positive():
    """A made-up domain has no specific extractor; only the Generic one
    would match, and Generic is excluded so the probe must return False."""
    assert (
        is_known_media_url("https://this-is-not-a-real-domain-xyzzy.invalid/list")
        is False
    )
