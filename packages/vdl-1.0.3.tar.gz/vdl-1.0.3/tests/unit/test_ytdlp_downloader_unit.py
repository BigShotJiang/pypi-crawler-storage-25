from __future__ import annotations

import builtins
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from vdl.downloader import DownloadOptions, YtDlpDownloader
from vdl.models import (
    DownloadKind,
    DownloadRequest,
    DownloadStatus,
    InputKind,
    Quality,
    SourceInput,
)

URL = "https://youtube.com/watch?v=abc123"


def _req(
    url: str = URL,
    quality: Quality = Quality.BEST,
    kind: DownloadKind = DownloadKind.VIDEO,
) -> DownloadRequest:
    return DownloadRequest(
        source=SourceInput(raw=url, kind=InputKind.VIDEO_URL, normalized=url),
        quality=quality,
        kind=kind,
    )


def _options(tmp_path: Path) -> DownloadOptions:
    return DownloadOptions(output_dir=tmp_path)


class TestYtDlpDownloaderImportError:
    async def test_raises_dependency_error_when_missing(self, tmp_path):
        from vdl.errors import VDLDependencyError

        dl = YtDlpDownloader(options=_options(tmp_path))

        real_import = builtins.__import__

        def fake_import(name, *args, **kwargs):
            if name == "yt_dlp":
                raise ImportError("No module named 'yt_dlp'")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=fake_import):
            with pytest.raises(VDLDependencyError):
                await dl.download(_req())


class TestYtDlpDownloaderSuccess:
    def _mock_yt_dlp(self, tmp_path: Path, filepath: str):
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.return_value = {
            "id": "abc123",
            "title": "Test Video",
            "filepath": filepath,
        }
        mock_ydl.prepare_filename.return_value = filepath
        return mock_ydl

    async def test_returns_completed_on_success(self, tmp_path):
        filepath = str(tmp_path / "video.mp4")
        mock_ydl = self._mock_yt_dlp(tmp_path, filepath)
        mock_yt_dlp_module = MagicMock()
        mock_yt_dlp_module.YoutubeDL.return_value = mock_ydl

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_yt_dlp_module}):
            result = await dl.download(_req())

        assert result.status == DownloadStatus.COMPLETED
        assert result.source_url == URL

    async def test_returns_failed_on_exception(self, tmp_path):
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.side_effect = RuntimeError("network error")

        mock_yt_dlp_module = MagicMock()
        mock_yt_dlp_module.YoutubeDL.return_value = mock_ydl

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_yt_dlp_module}):
            result = await dl.download(_req())

        assert result.status == DownloadStatus.FAILED
        assert "network error" in (result.error or "")

    async def test_on_progress_called_on_failure(self, tmp_path):
        received = []
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.side_effect = RuntimeError("fail")

        mock_yt_dlp_module = MagicMock()
        mock_yt_dlp_module.YoutubeDL.return_value = mock_ydl

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_yt_dlp_module}):
            result = await dl.download(_req(), on_progress=received.append)

        assert any(p.status == DownloadStatus.FAILED for p in received)

    async def test_prefers_post_processed_filepath(self, tmp_path):
        """Final result must report the merged .mp4, not the transient .webm
        that surfaces in the progress hook before yt-dlp post-processes."""
        webm = str(tmp_path / "video.webm")
        mp4 = str(tmp_path / "video.mp4")
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.return_value = {
            "id": "abc123",
            "title": "Test Video",
            "filepath": webm,
            "requested_downloads": [{"filepath": mp4}],
        }
        mock_ydl.prepare_filename.return_value = webm

        mock_yt_dlp_module = MagicMock()
        mock_yt_dlp_module.YoutubeDL.return_value = mock_ydl

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_yt_dlp_module}):
            result = await dl.download(_req())

        assert result.status == DownloadStatus.COMPLETED
        assert result.output_path is not None
        assert str(result.output_path) == str(tmp_path / "test-video.mp4")
        assert result.metadata.get("title") == "Test Video"

    async def test_no_info_returns_failed(self, tmp_path):
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.return_value = None

        mock_yt_dlp_module = MagicMock()
        mock_yt_dlp_module.YoutubeDL.return_value = mock_ydl

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_yt_dlp_module}):
            result = await dl.download(_req())

        assert result.status == DownloadStatus.FAILED

    async def test_progress_does_not_reset_between_internal_phases(self, tmp_path):
        received = []
        captured_opts = {}

        def extract_info(_url, download=True):
            hook = captured_opts["progress_hooks"][0]
            hook(
                {
                    "status": "downloading",
                    "downloaded_bytes": 50,
                    "total_bytes": 100,
                    "info_dict": {"title": "Test Video"},
                }
            )
            hook(
                {
                    "status": "finished",
                    "filename": str(tmp_path / "video.f137"),
                    "info_dict": {"title": "Test Video"},
                }
            )
            hook(
                {
                    "status": "downloading",
                    "downloaded_bytes": 10,
                    "total_bytes": 100,
                    "info_dict": {"title": "Test Video"},
                }
            )
            return {
                "id": "abc123",
                "title": "Test Video",
                "filepath": str(tmp_path / "video.mp4"),
            }

        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.side_effect = extract_info
        mock_ydl.prepare_filename.return_value = str(tmp_path / "video.mp4")

        mock_yt_dlp_module = MagicMock()

        def youtube_dl_factory(opts):
            captured_opts.clear()
            captured_opts.update(opts)
            return mock_ydl

        mock_yt_dlp_module.YoutubeDL.side_effect = youtube_dl_factory

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_yt_dlp_module}):
            result = await dl.download(_req(), on_progress=received.append)

        assert result.status == DownloadStatus.COMPLETED
        phases = [
            p
            for p in received
            if p.status in {DownloadStatus.DOWNLOADING, DownloadStatus.PROCESSING}
        ]
        assert len(phases) >= 3
        assert phases[0].percent == 50.0
        assert phases[1].percent == 99.0
        assert phases[2].percent == 99.0

    async def test_progress_falls_back_to_request_source_title(self, tmp_path):
        received = []
        captured_opts = {}
        req = _req()
        req = DownloadRequest(
            source=req.source,
            quality=req.quality,
            kind=req.kind,
            source_title="Playlist Item Title",
        )

        def extract_info(_url, download=True):
            hook = captured_opts["progress_hooks"][0]
            hook(
                {
                    "status": "finished",
                    "filename": str(tmp_path / "video.f137"),
                    "info_dict": {},
                }
            )
            return {
                "id": "abc123",
                "title": "Resolved Title",
                "filepath": str(tmp_path / "video.mp4"),
            }

        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.side_effect = extract_info
        mock_ydl.prepare_filename.return_value = str(tmp_path / "video.mp4")

        mock_yt_dlp_module = MagicMock()

        def youtube_dl_factory(opts):
            captured_opts.clear()
            captured_opts.update(opts)
            return mock_ydl

        mock_yt_dlp_module.YoutubeDL.side_effect = youtube_dl_factory

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_yt_dlp_module}):
            result = await dl.download(req, on_progress=received.append)

        assert result.status == DownloadStatus.COMPLETED
        assert any(
            p.status == DownloadStatus.PROCESSING and p.title == "Playlist Item Title"
            for p in received
        )

    async def test_emits_starting_before_download_progress(self, tmp_path):
        received = []

        filepath = str(tmp_path / "video.mp4")
        mock_ydl = self._mock_yt_dlp(tmp_path, filepath)
        mock_yt_dlp_module = MagicMock()
        mock_yt_dlp_module.YoutubeDL.return_value = mock_ydl

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_yt_dlp_module}):
            result = await dl.download(_req(), on_progress=received.append)

        assert result.status == DownloadStatus.COMPLETED
        assert received[0].status == DownloadStatus.STARTING
        assert received[0].percent == 0.0

    async def test_processing_does_not_jump_to_99_without_download_progress(
        self, tmp_path
    ):
        received = []
        captured_opts = {}

        def extract_info(_url, download=True):
            hook = captured_opts["progress_hooks"][0]
            hook(
                {
                    "status": "finished",
                    "filename": str(tmp_path / "video.f137"),
                    "info_dict": {"title": "Test Video"},
                }
            )
            return {
                "id": "abc123",
                "title": "Test Video",
                "filepath": str(tmp_path / "video.mp4"),
            }

        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.side_effect = extract_info
        mock_ydl.prepare_filename.return_value = str(tmp_path / "video.mp4")

        mock_yt_dlp_module = MagicMock()

        def youtube_dl_factory(opts):
            captured_opts.clear()
            captured_opts.update(opts)
            return mock_ydl

        mock_yt_dlp_module.YoutubeDL.side_effect = youtube_dl_factory

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_yt_dlp_module}):
            result = await dl.download(_req(), on_progress=received.append)

        assert result.status == DownloadStatus.COMPLETED
        processing = next(p for p in received if p.status == DownloadStatus.PROCESSING)
        assert processing.percent == 0.0


class TestBuildOpts:
    def test_audio_only_format(self, tmp_path):
        dl = YtDlpDownloader(options=_options(tmp_path))
        req = _req(kind=DownloadKind.AUDIO)
        opts = dl._build_opts(req, tmp_path, lambda d: None)
        assert opts["format"] == "bestaudio/best"
        assert any(
            p.get("key") == "FFmpegExtractAudio" for p in opts.get("postprocessors", [])
        )

    def test_best_quality_format(self, tmp_path):
        dl = YtDlpDownloader(options=_options(tmp_path))
        req = _req(quality=Quality.BEST)
        opts = dl._build_opts(req, tmp_path, lambda d: None)
        assert "bestvideo" in opts["format"]

    def test_p720_format(self, tmp_path):
        dl = YtDlpDownloader(options=_options(tmp_path))
        req = _req(quality=Quality.P720)
        opts = dl._build_opts(req, tmp_path, lambda d: None)
        assert "720" in opts["format"]

    def test_no_playlist_by_default(self, tmp_path):
        dl = YtDlpDownloader(options=_options(tmp_path))
        req = _req()
        opts = dl._build_opts(req, tmp_path, lambda d: None)
        assert opts["no_playlist"] is True

    def test_build_opts_level0_no_extractor_args(self, tmp_path):
        dl = YtDlpDownloader(options=_options(tmp_path))
        opts = dl._build_opts(_req(), tmp_path, lambda d: None, level=0)
        assert "extractor_args" not in opts

    def test_build_opts_level1_tv_mweb(self, tmp_path):
        dl = YtDlpDownloader(options=_options(tmp_path))
        opts = dl._build_opts(_req(), tmp_path, lambda d: None, level=1)
        assert opts["extractor_args"]["youtube"]["player_client"] == ["tv", "mweb"]

    def test_build_opts_level2_activates_cookies(self, tmp_path):
        cookies_path = tmp_path / "cookies.txt"
        cookies_path.touch()
        dl = YtDlpDownloader(
            options=DownloadOptions(output_dir=tmp_path, cookies=cookies_path)
        )
        opts = dl._build_opts(_req(), tmp_path, lambda d: None, level=2)
        assert opts.get("cookiefile") == str(cookies_path)


class TestBotDetectionEscalation:
    def _mock_ydl(self, side_effect, filepath: str):
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.prepare_filename.return_value = filepath
        mock_ydl.extract_info.side_effect = side_effect
        return mock_ydl

    async def test_download_escalates_on_bot_pattern(self, tmp_path):
        filepath = str(tmp_path / "video.mp4")
        mock_ydl = self._mock_ydl(
            side_effect=[
                RuntimeError("Sign in to confirm you're not a bot"),
                {"id": "abc123", "title": "Test Video", "filepath": filepath},
            ],
            filepath=filepath,
        )
        mock_module = MagicMock()
        mock_module.YoutubeDL.return_value = mock_ydl

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            result = await dl.download(_req())

        assert result.status == DownloadStatus.COMPLETED
        assert mock_ydl.extract_info.call_count == 2

    async def test_download_raises_after_max_escalation(self, tmp_path):
        mock_ydl = self._mock_ydl(
            side_effect=RuntimeError("Sign in to confirm you're not a bot"),
            filepath=str(tmp_path / "video.mp4"),
        )
        mock_module = MagicMock()
        mock_module.YoutubeDL.return_value = mock_ydl

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            result = await dl.download(_req())

        assert result.status == DownloadStatus.FAILED
        assert mock_ydl.extract_info.call_count == 3

    async def test_non_bot_error_does_not_escalate(self, tmp_path):
        mock_ydl = self._mock_ydl(
            side_effect=RuntimeError("network timeout"),
            filepath=str(tmp_path / "video.mp4"),
        )
        mock_module = MagicMock()
        mock_module.YoutubeDL.return_value = mock_ydl

        dl = YtDlpDownloader(options=_options(tmp_path))
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            result = await dl.download(_req())

        assert result.status == DownloadStatus.FAILED
        assert mock_ydl.extract_info.call_count == 1

    async def test_cookies_start_at_level2(self, tmp_path):
        cookies_path = tmp_path / "cookies.txt"
        cookies_path.touch()
        filepath = str(tmp_path / "video.mp4")
        mock_ydl = self._mock_ydl(
            side_effect=[{"id": "abc", "title": "T", "filepath": filepath}],
            filepath=filepath,
        )
        mock_module = MagicMock()
        mock_module.YoutubeDL.return_value = mock_ydl

        dl = YtDlpDownloader(
            options=DownloadOptions(output_dir=tmp_path, cookies=cookies_path)
        )
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            result = await dl.download(_req())

        assert result.status == DownloadStatus.COMPLETED
        assert mock_ydl.extract_info.call_count == 1
        called_opts = mock_module.YoutubeDL.call_args[0][0]
        assert called_opts.get("cookiefile") == str(cookies_path)
