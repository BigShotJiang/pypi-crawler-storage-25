"""Tests for vdl.acquisition."""

import dataclasses
from pathlib import Path

import pytest

from vdl.acquisition import AcquisitionItem, AcquisitionPlan, ExpansionPolicy
from vdl.models import DownloadKind, InputKind, Quality


class TestAcquisitionItem:
    def test_defaults(self):
        item = AcquisitionItem(source_url="https://youtube.com/watch?v=1")
        assert item.source_url == "https://youtube.com/watch?v=1"
        assert item.output_dir is None
        assert item.quality == Quality.BEST
        assert item.kind == DownloadKind.VIDEO
        assert item.force is False
        assert item.subdirectory is None
        assert item.is_playlist is False

    def test_custom(self):
        item = AcquisitionItem(
            source_url="https://youtube.com/playlist?list=PL1",
            output_dir=Path("/tmp/out"),
            quality=Quality.P1080,
            kind=DownloadKind.PLAYLIST,
            force=True,
            subdirectory="my-playlist",
            is_playlist=True,
        )
        assert item.quality == Quality.P1080
        assert item.kind == DownloadKind.PLAYLIST
        assert item.force is True
        assert item.is_playlist is True

    def test_frozen(self):
        item = AcquisitionItem(source_url="https://example.com")
        with pytest.raises(dataclasses.FrozenInstanceError):
            item.source_url = "changed"  # type: ignore[misc]


class TestAcquisitionPlan:
    def test_single_item_plan(self):
        item = AcquisitionItem(source_url="https://youtube.com/watch?v=1")
        plan = AcquisitionPlan(
            items=[item],
            source_kind=InputKind.VIDEO_URL,
            total=1,
        )
        assert plan.total == 1
        assert plan.source_kind == InputKind.VIDEO_URL
        assert len(plan.items) == 1
        assert plan.metadata == {}

    def test_multi_item_plan(self):
        items = [
            AcquisitionItem(source_url=f"https://youtube.com/watch?v={i}")
            for i in range(3)
        ]
        plan = AcquisitionPlan(
            items=items,
            source_kind=InputKind.LOCAL_LINK_FILE,
            total=3,
        )
        assert plan.total == 3
        assert len(plan.items) == 3

    def test_with_metadata(self):
        plan = AcquisitionPlan(
            items=[],
            source_kind=InputKind.UNKNOWN,
            total=0,
            metadata={"source": "test"},
        )
        assert plan.metadata["source"] == "test"

    def test_frozen(self):
        plan = AcquisitionPlan(items=[], source_kind=InputKind.URL, total=0)
        with pytest.raises(dataclasses.FrozenInstanceError):
            plan.total = 5  # type: ignore[misc]


class TestExpansionPolicy:
    def test_defaults(self):
        policy = ExpansionPolicy()
        assert policy.max_playlist_items is None
        assert policy.expand_nested_playlists is False
        assert policy.default_selection.mode == "all"

    def test_custom(self):
        from vdl.selection import PlaylistSelection

        policy = ExpansionPolicy(
            max_playlist_items=10,
            expand_nested_playlists=True,
            default_selection=PlaylistSelection(mode="first_n", first_n=5),
        )
        assert policy.max_playlist_items == 10
        assert policy.expand_nested_playlists is True
        assert policy.default_selection.first_n == 5

    def test_frozen(self):
        policy = ExpansionPolicy()
        with pytest.raises(dataclasses.FrozenInstanceError):
            policy.max_playlist_items = 5  # type: ignore[misc]
