"""Tests for vdl.prompt_utils — paste sanitization and path expansion."""

from __future__ import annotations

import os
from pathlib import Path

from vdl.prompt_utils import expand_user_path, sanitize_pasted_input


class TestSanitizePastedInput:
    def test_strips_leading_prompt_label(self):
        # Reproduces bug #2 from the field report.
        assert (
            sanitize_pasted_input(
                "URL or file path https://www.youtube.com/watch?v=NJ8AQQAo_RQ"
            )
            == "https://www.youtube.com/watch?v=NJ8AQQAo_RQ"
        )

    def test_strips_label_with_colon(self):
        assert (
            sanitize_pasted_input("URL: https://example.com/v")
            == "https://example.com/v"
        )

    def test_strips_double_quotes(self):
        assert (
            sanitize_pasted_input('"https://example.com/v"') == "https://example.com/v"
        )

    def test_strips_single_quotes(self):
        assert (
            sanitize_pasted_input("'https://example.com/v'") == "https://example.com/v"
        )

    def test_strips_smart_quotes(self):
        assert (
            sanitize_pasted_input("“https://example.com/v”") == "https://example.com/v"
        )

    def test_collapses_whitespace_runs(self):
        assert (
            sanitize_pasted_input("  https://example.com/v\r\n")
            == "https://example.com/v"
        )

    def test_empty_input_returns_empty(self):
        assert sanitize_pasted_input("") == ""
        assert sanitize_pasted_input("   ") == ""

    def test_label_alone_returns_empty(self):
        # Pasting only the prompt echo with no URL behind it should not crash.
        assert sanitize_pasted_input("URL or file path") == ""

    def test_passes_through_normal_url(self):
        assert sanitize_pasted_input("https://example.com/v") == "https://example.com/v"


class TestReadLine:
    def test_falls_back_to_input_when_not_a_tty(self):
        from unittest.mock import patch

        from vdl.prompt_utils import read_line

        # Tests are not run in a TTY, so we should hit the input() path.
        with patch("builtins.input", return_value="https://example.com/v"):
            assert read_line("URL: ", history_name="url") == "https://example.com/v"


class TestExpandUserPath:
    def test_expands_tilde(self):
        result = expand_user_path("~/Downloads")
        assert "~" not in str(result)
        assert str(result).endswith("Downloads")

    def test_expands_env_var(self, monkeypatch):
        monkeypatch.setenv("MY_TEST_VAR", "/tmp/x")
        assert expand_user_path("$MY_TEST_VAR/sub") == Path("/tmp/x/sub")

    def test_passes_through_absolute(self):
        assert expand_user_path("/already/absolute") == Path("/already/absolute")

    def test_strips_whitespace(self):
        assert expand_user_path("  /tmp/foo  ") == Path("/tmp/foo")
