from __future__ import annotations

import subprocess
from unittest.mock import MagicMock, patch

import pytest

from vdl.doctor import Doctor, DependencyCheck, check_ffmpeg, check_ytdlp


class TestCheckFfmpeg:
    def test_found(self):
        mock_result = MagicMock()
        mock_result.stdout = "ffmpeg version 6.0\nsome other line"
        with (
            patch("vdl.doctor.shutil.which", return_value="/x/ffmpeg"),
            patch("subprocess.run", return_value=mock_result),
        ):
            check = check_ffmpeg()
        assert check.available is True
        assert check.name == "ffmpeg"
        assert check.path == "/x/ffmpeg"

    def test_not_found(self):
        with patch("vdl.doctor.shutil.which", return_value=None):
            check = check_ffmpeg()
        assert check.available is False
        assert "not found" in (check.message or "")

    def test_subprocess_error(self):
        with (
            patch("vdl.doctor.shutil.which", return_value="/x/ffmpeg"),
            patch("subprocess.run", side_effect=subprocess.TimeoutExpired("ffmpeg", 5)),
        ):
            check = check_ffmpeg()
        assert check.available is False
        assert check.message is not None


class TestCheckYtdlp:
    def test_found(self):
        mock_module = MagicMock()
        mock_module.version.__version__ = "2024.1.1"
        with patch.dict(
            "sys.modules",
            {"yt_dlp": mock_module, "yt_dlp.version": mock_module.version},
        ):
            check = check_ytdlp()
        assert check.available is True
        assert check.name == "yt-dlp"

    def test_not_installed(self):
        with patch(
            "builtins.__import__", side_effect=ImportError("No module named 'yt_dlp'")
        ):
            check = check_ytdlp()
        assert check.available is False


class TestDoctor:
    def test_run_returns_report(self):
        doc = Doctor()
        report = doc.run()
        assert hasattr(report, "ffmpeg_available")
        assert hasattr(report, "ytdlp_available")
        assert isinstance(report.version, str)

    def test_check_ffmpeg_delegates(self):
        doc = Doctor()
        mock_result = MagicMock()
        mock_result.stdout = "ffmpeg version 6.0"
        with (
            patch("vdl.doctor.shutil.which", return_value="/x/ffmpeg"),
            patch("subprocess.run", return_value=mock_result),
        ):
            check = doc.check_ffmpeg()
        assert isinstance(check, DependencyCheck)

    def test_check_ytdlp_delegates(self):
        doc = Doctor()
        check = doc.check_ytdlp()
        assert isinstance(check, DependencyCheck)

    def test_report_has_details(self):
        doc = Doctor()
        report = doc.run()
        assert "ffmpeg" in report.details
        assert "ytdlp" in report.details


class TestRunDoctorExpanded:
    def _stub_checks(self, *, ffmpeg=True, ffprobe=True, ytdlp=True, mcp=True):
        from vdl import doctor as doctor_mod

        return (
            patch.object(
                doctor_mod,
                "check_ffmpeg",
                return_value=DependencyCheck(
                    "ffmpeg", ffmpeg, path="/x/ffmpeg" if ffmpeg else None
                ),
            ),
            patch.object(
                doctor_mod,
                "check_ffprobe",
                return_value=DependencyCheck(
                    "ffprobe", ffprobe, path="/x/ffprobe" if ffprobe else None
                ),
            ),
            patch.object(
                doctor_mod,
                "check_ytdlp",
                return_value=DependencyCheck(
                    "yt-dlp", ytdlp, version="x" if ytdlp else None
                ),
            ),
            patch.object(
                doctor_mod,
                "check_mcp_command",
                return_value=DependencyCheck(
                    "vdl-mcp", mcp, path="/x/vdl-mcp" if mcp else None
                ),
            ),
        )

    def _redirect_paths(self, monkeypatch, tmp_path):
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "cfg"))
        monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "cache"))
        monkeypatch.setenv("HOME", str(tmp_path))

    def test_ffprobe_reported_separately(self, tmp_path, monkeypatch):
        from vdl.doctor import run_doctor

        self._redirect_paths(monkeypatch, tmp_path)
        a, b, c, d = self._stub_checks(ffprobe=False)
        with a, b, c, d:
            report = run_doctor()
        assert report.ffmpeg_available is True
        assert report.ffprobe_available is False
        assert any("ffprobe" in r for r in report.repairs)

    def test_mcp_visibility(self, tmp_path, monkeypatch):
        from vdl.doctor import run_doctor

        self._redirect_paths(monkeypatch, tmp_path)
        a, b, c, d = self._stub_checks(mcp=False)
        with a, b, c, d:
            report = run_doctor()
        assert report.mcp_available is False
        assert any("mcp" in r.lower() for r in report.repairs)

    def test_paths_in_details(self, tmp_path, monkeypatch):
        from vdl.doctor import run_doctor

        self._redirect_paths(monkeypatch, tmp_path)
        a, b, c, d = self._stub_checks()
        with a, b, c, d:
            report = run_doctor()
        paths = report.details["paths"]
        for key in ("config_dir", "state_dir", "cache_dir", "downloads_dir"):
            assert key in paths

    def test_no_repairs_when_healthy(self, tmp_path, monkeypatch):
        from vdl.doctor import run_doctor

        self._redirect_paths(monkeypatch, tmp_path)
        a, b, c, d = self._stub_checks()
        with a, b, c, d:
            report = run_doctor()
        assert report.repairs == []
