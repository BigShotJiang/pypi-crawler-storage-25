"""Phase 3: Paths tests."""

from pathlib import Path

import pytest

from vdl.paths import (
    VDLPaths,
    bundled_site_rules_path,
    ensure_paths,
    find_cookie_file_for,
    find_default_cookie_file,
    get_default_paths,
    resolve_output_dir,
    resolve_site_rules_path,
)


@pytest.fixture
def _no_xdg(monkeypatch):
    monkeypatch.delenv("XDG_CONFIG_HOME", raising=False)
    monkeypatch.delenv("XDG_STATE_HOME", raising=False)
    monkeypatch.delenv("XDG_CACHE_HOME", raising=False)


def test_default_config_path(_no_xdg):
    paths = get_default_paths()
    assert paths.config_file == Path.home() / ".config" / "vdl" / "config.toml"
    assert paths.config_dir == Path.home() / ".config" / "vdl"


def test_default_state_path(_no_xdg):
    paths = get_default_paths()
    assert paths.state_dir == Path.home() / ".local" / "state" / "vdl"


def test_default_state_db(_no_xdg):
    paths = get_default_paths()
    assert paths.state_db == paths.state_dir / "vdl.db"


def test_default_cache_path(_no_xdg):
    paths = get_default_paths()
    assert paths.cache_dir == Path.home() / ".cache" / "vdl"


def test_default_downloads_path():
    paths = get_default_paths()
    assert paths.downloads_dir == Path.home() / "Downloads" / "VDL"


def test_default_logs_path(_no_xdg):
    paths = get_default_paths()
    assert paths.logs_dir == paths.state_dir / "logs"


def test_default_site_rules_paths(_no_xdg):
    paths = get_default_paths()
    assert paths.site_rules_file == Path.home() / ".config" / "vdl" / "websites.yaml"


def test_xdg_config_home_override(monkeypatch, tmp_path):
    custom = tmp_path / "custom_config"
    monkeypatch.setenv("XDG_CONFIG_HOME", str(custom))
    paths = get_default_paths()
    assert paths.config_dir == custom / "vdl"
    assert paths.config_file == custom / "vdl" / "config.toml"


def test_xdg_state_home_override(monkeypatch, tmp_path):
    custom = tmp_path / "custom_state"
    monkeypatch.setenv("XDG_STATE_HOME", str(custom))
    paths = get_default_paths()
    assert paths.state_dir == custom / "vdl"
    assert paths.state_db == custom / "vdl" / "vdl.db"


def test_xdg_cache_home_override(monkeypatch, tmp_path):
    custom = tmp_path / "custom_cache"
    monkeypatch.setenv("XDG_CACHE_HOME", str(custom))
    paths = get_default_paths()
    assert paths.cache_dir == custom / "vdl"


def test_ensure_paths_creates_dirs(tmp_path):
    paths = VDLPaths(
        config_dir=tmp_path / "config" / "vdl",
        config_file=tmp_path / "config" / "vdl" / "config.toml",
        site_rules_file=tmp_path / "config" / "vdl" / "websites.yaml",
        state_dir=tmp_path / "state" / "vdl",
        state_db=tmp_path / "state" / "vdl" / "vdl.db",
        cache_dir=tmp_path / "cache" / "vdl",
        logs_dir=tmp_path / "state" / "vdl" / "logs",
        downloads_dir=tmp_path / "downloads" / "VDL",
    )
    result = ensure_paths(paths)
    assert result is paths
    assert paths.config_dir.is_dir()
    assert paths.state_dir.is_dir()
    assert paths.logs_dir.is_dir()
    assert paths.cache_dir.is_dir()
    assert paths.downloads_dir.is_dir()


def test_resolve_none_returns_default(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "vdl.paths._prepare_fallback_dir",
        lambda: tmp_path / "VDL",
    )
    result = resolve_output_dir(None)
    assert result.requested_path is None
    assert result.used_fallback is False


def test_resolve_valid_path(tmp_path):
    result = resolve_output_dir(tmp_path)
    assert result.active_path == tmp_path.resolve()
    assert result.used_fallback is False
    assert result.warning is None


def test_resolve_valid_path_string(tmp_path):
    result = resolve_output_dir(str(tmp_path))
    assert result.active_path == tmp_path.resolve()
    assert result.used_fallback is False


def test_resolve_invalid_path_fallback(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "vdl.paths._prepare_fallback_dir",
        lambda: tmp_path / "fallback",
    )
    monkeypatch.setattr("vdl.paths._is_writable_dir", lambda _path: False)
    (tmp_path / "fallback").mkdir()
    result = resolve_output_dir("/this-path-cannot-exist-with-write-access-xyzzy")
    assert result.used_fallback is True
    assert result.warning is not None
    assert "unavailable" in result.warning


def _site_rules_paths(tmp_path):
    config_dir = tmp_path / "config" / "vdl"
    return VDLPaths(
        config_dir=config_dir,
        config_file=config_dir / "config.toml",
        site_rules_file=config_dir / "websites.yaml",
        state_dir=tmp_path / "state",
        state_db=tmp_path / "state" / "vdl.db",
        cache_dir=tmp_path / "cache",
        logs_dir=tmp_path / "state" / "logs",
        downloads_dir=tmp_path / "downloads",
    )


def test_resolve_site_rules_explicit_returned_as_is(tmp_path):
    explicit = tmp_path / "elsewhere.yaml"
    explicit.write_text("- domain: x.com\n")
    paths = _site_rules_paths(tmp_path)
    assert resolve_site_rules_path(explicit, paths=paths) == explicit


def test_resolve_site_rules_picks_default_when_present(tmp_path):
    paths = _site_rules_paths(tmp_path)
    paths.site_rules_file.parent.mkdir(parents=True, exist_ok=True)
    paths.site_rules_file.write_text("- domain: x.com\n")
    assert resolve_site_rules_path(None, paths=paths) == paths.site_rules_file


def test_resolve_site_rules_returns_none_when_no_file(tmp_path):
    paths = _site_rules_paths(tmp_path)
    assert resolve_site_rules_path(None, paths=paths) is None


def test_resolve_strips_quotes(tmp_path):
    quoted = f'"{tmp_path}"'
    result = resolve_output_dir(quoted)
    assert result.active_path == tmp_path.resolve()
    assert result.used_fallback is False


def test_bundled_site_rules_present():
    bundled = bundled_site_rules_path()
    assert bundled is not None and bundled.exists()


def test_find_cookie_file_for_matches_host(tmp_path):
    paths = _site_rules_paths(tmp_path)
    paths.config_dir.mkdir(parents=True, exist_ok=True)
    yt = paths.config_dir / "www.youtube.com_cookies.txt"
    other = paths.config_dir / "vimeo.com_cookies.txt"
    yt.write_text("yt")
    other.write_text("vm")
    assert find_cookie_file_for("https://www.youtube.com/watch?v=x", paths) == yt
    assert find_cookie_file_for("https://vimeo.com/123", paths) == other


def test_find_cookie_file_for_falls_back_to_generic(tmp_path):
    paths = _site_rules_paths(tmp_path)
    paths.config_dir.mkdir(parents=True, exist_ok=True)
    cookies = paths.config_dir / "cookies.txt"
    cookies.write_text("generic")
    assert find_cookie_file_for("https://anywhere.example/page", paths) == cookies


def test_find_default_cookie_file_prefers_plain_name(tmp_path):
    paths = _site_rules_paths(tmp_path)
    paths.config_dir.mkdir(parents=True, exist_ok=True)
    plain = paths.config_dir / "cookies.txt"
    other = paths.config_dir / "abc_cookies.txt"
    plain.write_text("p")
    other.write_text("o")
    assert find_default_cookie_file(paths) == plain
