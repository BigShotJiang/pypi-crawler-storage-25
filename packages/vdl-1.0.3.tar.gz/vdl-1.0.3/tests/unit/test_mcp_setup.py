"""Tests for vdl.mcp_setup — per-host MCP setup snippets."""

from __future__ import annotations

import json
from unittest.mock import patch

from vdl.mcp_setup import (
    McpInvocation,
    detect_invocation,
    render_setup_dict,
    render_setup_text,
)


class TestDetectInvocation:
    def test_uses_vdl_mcp_when_on_path(self):
        with patch("vdl.mcp_setup.shutil.which", return_value="/usr/local/bin/vdl-mcp"):
            inv = detect_invocation()
        assert inv.command == "/usr/local/bin/vdl-mcp"
        assert inv.args == []
        assert inv.is_resolved is True
        assert inv.notes is None

    def test_falls_back_to_python_module(self):
        with (
            patch("vdl.mcp_setup.shutil.which", return_value=None),
            patch("vdl.mcp_setup.sys.executable", "/opt/python"),
        ):
            inv = detect_invocation()
        assert inv.command == "/opt/python"
        assert inv.args == ["-m", "vdl.mcp_server"]
        assert inv.is_resolved is False
        assert inv.notes is not None and "PATH" in inv.notes


class TestRenderSetupText:
    def _inv(self) -> McpInvocation:
        return McpInvocation(
            command="/opt/bin/vdl-mcp",
            args=[],
            notes=None,
            is_resolved=True,
        )

    def test_includes_detected_path(self):
        text = render_setup_text(self._inv())
        assert "/opt/bin/vdl-mcp" in text

    def test_includes_claude_desktop_section(self):
        text = render_setup_text(self._inv())
        assert "Claude Desktop" in text
        assert "mcpServers" in text

    def test_includes_codex_section(self):
        text = render_setup_text(self._inv())
        assert "Codex" in text
        assert "[mcp_servers.vdl]" in text

    def test_includes_generic_section(self):
        text = render_setup_text(self._inv())
        assert "Generic MCP client" in text
        assert "stdio" in text


class TestRenderSetupDict:
    def test_structure_for_resolved_invocation(self):
        inv = McpInvocation(
            command="/opt/bin/vdl-mcp",
            args=[],
            notes=None,
            is_resolved=True,
        )
        out = render_setup_dict(inv)
        assert out["command"] == "/opt/bin/vdl-mcp"
        assert out["args"] == []
        assert out["is_resolved"] is True
        snippets = out["snippets"]
        # Structured Claude Desktop snippet should include vdl entry.
        assert "vdl" in snippets["claude_desktop"]["mcpServers"]
        assert (
            snippets["claude_desktop"]["mcpServers"]["vdl"]["command"]
            == "/opt/bin/vdl-mcp"
        )
        # generic snippet exposes stdio transport hint.
        assert snippets["generic"]["transport"] == "stdio"

    def test_json_dict_is_serializable(self):
        out = render_setup_dict(
            McpInvocation(command="/x", args=[], notes=None, is_resolved=True)
        )
        # Should round-trip through json without TypeError.
        json.dumps(out)
