"""Tests for vdl.impersonation — runtime probe of yt-dlp impersonation."""

from __future__ import annotations

import builtins
import sys
from unittest.mock import patch

from vdl.impersonation import ImpersonationCheck, probe_impersonation


def _without(modules: list[str]):
    """Block the named imports inside the with-block."""
    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if any(name == m or name.startswith(m + ".") for m in modules):
            raise ImportError(f"blocked for test: {name}")
        return real_import(name, *args, **kwargs)

    return patch.object(builtins, "__import__", side_effect=fake_import)


def _flush_module(name: str) -> None:
    sys.modules.pop(name, None)


class TestProbeImpersonation:
    def test_returns_available_on_a_healthy_install(self):
        # Sanity — the test environment was just synced with a curl-cffi
        # version inside yt-dlp's accepted range.
        result = probe_impersonation()
        assert isinstance(result, ImpersonationCheck)
        assert result.status == "available"
        assert result.detail is None

    def test_classifies_curl_cffi_missing(self):
        _flush_module("curl_cffi")
        with _without(["curl_cffi"]):
            result = probe_impersonation()
        assert result.status == "missing"
        assert result.detail and "curl_cffi" in result.detail

    def test_classifies_yt_dlp_version_mismatch(self):
        # Reproduces the exact failure mode that broke the Dailymotion
        # download: yt_dlp.networking._curlcffi raises ImportError because
        # the installed curl_cffi is outside its accepted version range.
        _flush_module("yt_dlp.networking._curlcffi")
        real_import = builtins.__import__

        def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
            # Catch both `import yt_dlp.networking._curlcffi` and the
            # `from yt_dlp.networking import _curlcffi` form yt-dlp's
            # rejection path uses.
            if name == "yt_dlp.networking._curlcffi" or (
                name == "yt_dlp.networking" and "_curlcffi" in (fromlist or ())
            ):
                raise ImportError(
                    "Only curl_cffi versions 0.5.10 and 0.10.x through 0.14.x "
                    "are supported"
                )
            return real_import(name, globals, locals, fromlist, level)

        with patch.object(builtins, "__import__", side_effect=fake_import):
            result = probe_impersonation()
        assert result.status == "version_mismatch"
        assert "0.10.x through 0.14.x" in (result.detail or "")
