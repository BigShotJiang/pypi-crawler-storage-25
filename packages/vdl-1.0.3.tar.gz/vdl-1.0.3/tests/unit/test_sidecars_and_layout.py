from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from vdl.downloader import DownloadOptions, YtDlpDownloader, _collect_sidecars
from vdl.models import (
    DownloadKind,
    DownloadRequest,
    DownloadStatus,
    InputKind,
    Quality,
    SourceInput,
)
from vdl.naming import build_output_template


URL = "https://youtube.com/watch?v=abc123"


def _req(url: str = URL) -> DownloadRequest:
    return DownloadRequest(
        source=SourceInput(raw=url, kind=InputKind.VIDEO_URL, normalized=url),
        quality=Quality.BEST,
        kind=DownloadKind.VIDEO,
    )


class TestSidecarOptions:
    def test_write_thumbnail_and_subtitles_emit_yt_dlp_flags(self, tmp_path):
        options = DownloadOptions(
            output_dir=tmp_path,
            write_thumbnail=True,
            write_subtitles=True,
            subtitle_langs="en, fr",
        )
        dl = YtDlpDownloader(options=options)
        opts = dl._build_opts(_req(), tmp_path, lambda d: None, level=0)
        assert opts["writethumbnail"] is True
        assert opts["writesubtitles"] is True
        assert opts["writeautomaticsub"] is True
        assert opts["subtitleslangs"] == ["en", "fr"]
        assert opts["subtitlesformat"] == "vtt/best"

    def test_sidecars_omitted_when_disabled(self, tmp_path):
        options = DownloadOptions(output_dir=tmp_path)
        dl = YtDlpDownloader(options=options)
        opts = dl._build_opts(_req(), tmp_path, lambda d: None, level=0)
        assert "writethumbnail" not in opts
        assert "writesubtitles" not in opts


class TestCollectSidecars:
    def test_thumbnail_path_picked_from_post_processed_entry(self):
        info = {
            "thumbnails": [
                {"url": "http://x", "filepath": "/out/dir/thumbnail.jpg"},
            ],
        }
        out = _collect_sidecars(info)
        assert out["thumbnail"] == "/out/dir/thumbnail.jpg"

    def test_subtitle_paths_keyed_by_language(self):
        info = {
            "requested_subtitles": {
                "en": {"filepath": "/out/dir/subtitles/en.vtt"},
                "fr": {"filepath": "/out/dir/subtitles/fr.vtt"},
            },
        }
        out = _collect_sidecars(info)
        assert out["subtitles"] == {
            "en": "/out/dir/subtitles/en.vtt",
            "fr": "/out/dir/subtitles/fr.vtt",
        }

    def test_no_sidecars_returns_empty(self):
        assert _collect_sidecars({}) == {}


class TestFolderLayoutTemplate:
    def test_single_video_layout(self, tmp_path):
        tmpl = build_output_template(tmp_path)
        assert tmpl["default"].endswith("%(title)s.%(ext)s")
        assert tmpl["thumbnail"].endswith("%(title)s.thumbnail.%(ext)s")
        assert tmpl["subtitle"].endswith("%(title)s.%(language)s.%(ext)s")

    def test_playlist_layout_uses_padded_index(self, tmp_path):
        tmpl = build_output_template(tmp_path, playlist=True)
        assert "%(playlist_index)03d-%(title)s.%(ext)s" in tmpl["default"]
        assert "%(playlist_index)03d-%(title)s.thumbnail.%(ext)s" in tmpl["thumbnail"]


class TestSidecarsPropagateToResult:
    async def test_completed_result_carries_sidecar_metadata(self, tmp_path):
        filepath = str(tmp_path / "out" / "video.mp4")
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        Path(filepath).write_text("video")
        thumbnail = tmp_path / "out" / "thumbnail.jpg"
        subtitle = tmp_path / "out" / "subtitles" / "en.vtt"
        thumbnail.write_text("thumb")
        subtitle.parent.mkdir(parents=True, exist_ok=True)
        subtitle.write_text("sub")
        info = {
            "id": "abc",
            "title": "Hello",
            "filepath": filepath,
            "requested_downloads": [{"filepath": filepath}],
            "thumbnails": [{"filepath": str(thumbnail)}],
            "requested_subtitles": {
                "en": {"filepath": str(subtitle)},
            },
        }
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.return_value = info
        mock_ydl.prepare_filename.return_value = filepath

        mock_yt_dlp_module = MagicMock()
        mock_yt_dlp_module.YoutubeDL.return_value = mock_ydl

        dl = YtDlpDownloader(
            options=DownloadOptions(
                output_dir=tmp_path,
                write_thumbnail=True,
                write_subtitles=True,
            )
        )
        with patch.dict("sys.modules", {"yt_dlp": mock_yt_dlp_module}):
            result = await dl.download(_req())

        assert result.status == DownloadStatus.COMPLETED
        assert result.output_path is not None
        assert result.output_path.name == "hello.mp4"
        sidecars = result.metadata.get("sidecars") or {}
        assert sidecars.get("thumbnail", "").endswith("hello.thumbnail.jpg")
        assert sidecars.get("subtitles", {}).get("en", "").endswith("hello.en.vtt")
