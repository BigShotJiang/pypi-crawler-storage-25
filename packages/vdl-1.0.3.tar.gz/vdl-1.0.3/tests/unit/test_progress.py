from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest
from rich.console import Console

from vdl.models import DownloadStatus
from vdl.progress import (
    CallbackProgressEmitter,
    DownloadProgress,
    NullProgressEmitter,
    RichProgressEmitter,
)


def _make_progress(
    status: DownloadStatus = DownloadStatus.DOWNLOADING,
) -> DownloadProgress:
    return DownloadProgress(id="test-id", status=status, percent=50.0)


class TestDownloadProgress:
    def test_construct_minimal(self):
        p = DownloadProgress(id="abc", status=DownloadStatus.DOWNLOADING)
        assert p.id == "abc"
        assert p.status == DownloadStatus.DOWNLOADING
        assert p.percent is None
        assert p.speed_bps is None
        assert p.title is None
        assert p.error is None

    def test_construct_full(self):
        p = DownloadProgress(
            id="abc",
            status=DownloadStatus.COMPLETED,
            percent=100.0,
            speed_bps=1_048_576,
            title="My Video",
            output_path=Path("/out/file.mp4"),
        )
        assert p.percent == 100.0
        assert p.speed_bps == 1_048_576
        assert p.title == "My Video"
        assert p.output_path == Path("/out/file.mp4")

    def test_is_frozen(self):
        p = _make_progress()
        with pytest.raises(Exception):
            p.percent = 99.0  # type: ignore[misc]

    def test_updated_at_auto_set(self):
        p = _make_progress()
        assert p.updated_at is not None


class TestNullProgressEmitter:
    def test_start_does_nothing(self):
        NullProgressEmitter().start(total=5)

    def test_emit_does_nothing(self):
        NullProgressEmitter().emit(_make_progress())

    def test_finish_does_nothing(self):
        NullProgressEmitter().finish()

    def test_satisfies_protocol(self):
        emitter = NullProgressEmitter()
        assert callable(emitter.start)
        assert callable(emitter.emit)
        assert callable(emitter.finish)


class TestCallbackProgressEmitter:
    def test_emit_calls_callback(self):
        received = []
        emitter = CallbackProgressEmitter(callback=received.append)
        p = _make_progress()
        emitter.emit(p)
        assert received == [p]

    def test_emit_multiple(self):
        received = []
        emitter = CallbackProgressEmitter(callback=received.append)
        p1 = _make_progress(DownloadStatus.DOWNLOADING)
        p2 = _make_progress(DownloadStatus.COMPLETED)
        emitter.emit(p1)
        emitter.emit(p2)
        assert received == [p1, p2]

    def test_start_does_nothing(self):
        emitter = CallbackProgressEmitter(callback=lambda _: None)
        emitter.start(total=3)

    def test_finish_does_nothing(self):
        emitter = CallbackProgressEmitter(callback=lambda _: None)
        emitter.finish()


class TestRichProgressEmitter:
    def test_all_methods_callable(self):
        emitter = RichProgressEmitter(console=Console())
        emitter.start()
        emitter.emit(_make_progress())
        emitter.finish()

    def test_summary_counts_track_latest_status(self):
        emitter = RichProgressEmitter(console=Console())
        emitter.start(total=2)
        emitter.emit(_make_progress(DownloadStatus.DOWNLOADING))
        emitter.emit(_make_progress(DownloadStatus.COMPLETED))
        emitter.finish()
        assert emitter.summary_counts == {"completed": 1}

    def test_summary_remaining_drops_to_zero_when_done(self):
        from rich.table import Table

        emitter = RichProgressEmitter(console=Console())
        emitter.start(total=1)
        emitter.emit(_make_progress(DownloadStatus.DOWNLOADING))
        emitter.emit(_make_progress(DownloadStatus.COMPLETED))
        panel = emitter._summary_panel()
        rows: dict[str, str] = {}
        table = panel.renderable
        assert isinstance(table, Table)
        for col_name, col_value in zip(
            table.columns[0]._cells, table.columns[1]._cells
        ):
            rows[str(col_name)] = str(col_value)
        emitter.finish()
        assert rows["Total"] == "1"
        assert rows["Active"] == "0"
        assert rows["Remaining"] == "0"
        assert rows["Completed"] == "1"

    def test_label_prefers_title_over_id(self):
        emitter = RichProgressEmitter(console=Console())
        progress = DownloadProgress(
            id="abcdef0123456789",
            status=DownloadStatus.DOWNLOADING,
            title="A Friendly Title",
        )
        assert emitter._label(progress) == "A Friendly Title"

    def test_label_falls_back_to_id_when_no_title_or_path(self):
        emitter = RichProgressEmitter(console=Console())
        progress = DownloadProgress(
            id="abcdef0123456789", status=DownloadStatus.DOWNLOADING
        )
        assert emitter._label(progress) == "download abcdef01"

    def test_total_grows_when_more_tasks_seen_than_planned(self):
        # Reproduces bug #3 from the field report: a playlist plan reports
        # total=1 (one playlist URL) but expands into N actual downloads.
        # The summary should reflect reality, not the upstream plan.
        from rich.table import Table

        emitter = RichProgressEmitter(console=Console())
        emitter.start(total=1)
        emitter.emit(DownloadProgress(id="task-a", status=DownloadStatus.DOWNLOADING))
        emitter.emit(DownloadProgress(id="task-b", status=DownloadStatus.DOWNLOADING))
        panel = emitter._summary_panel()
        rows: dict[str, str] = {}
        table = panel.renderable
        assert isinstance(table, Table)
        for col_name, col_value in zip(
            table.columns[0]._cells, table.columns[1]._cells
        ):
            rows[str(col_name)] = str(col_value)
        emitter.finish()
        assert rows["Total"] == "2"
        assert rows["Active"] == "2"

    def test_set_total_grows_total(self):
        emitter = RichProgressEmitter(console=Console())
        emitter.start(total=1)
        emitter.set_total(5)
        assert emitter._total == 5

    def test_set_total_does_not_shrink(self):
        emitter = RichProgressEmitter(console=Console())
        emitter.start(total=10)
        emitter.set_total(2)
        assert emitter._total == 10

    def test_cancelled_count_is_displayed(self):
        from rich.table import Table

        emitter = RichProgressEmitter(console=Console())
        emitter.start(total=1)
        emitter.emit(_make_progress(DownloadStatus.CANCELLED))
        panel = emitter._summary_panel()
        rows: dict[str, str] = {}
        table = panel.renderable
        assert isinstance(table, Table)
        for col_name, col_value in zip(
            table.columns[0]._cells, table.columns[1]._cells
        ):
            rows[str(col_name)] = str(col_value)
        emitter.finish()
        assert rows["Cancelled"] == "1"

    def test_title_is_remembered_across_emits(self):
        emitter = RichProgressEmitter(console=Console())
        emitter.start(total=1)
        emitter.emit(
            DownloadProgress(
                id="x", status=DownloadStatus.DOWNLOADING, title="Big Buck Bunny"
            )
        )
        # Subsequent emit without title should keep the captured title in the label.
        later = DownloadProgress(id="x", status=DownloadStatus.COMPLETED)
        assert emitter._label(later) == "Big Buck Bunny" or "x" in emitter._label(later)
        # explicitly verify storage:
        assert emitter._titles["x"] == "Big Buck Bunny"
        emitter.finish()

    def test_processing_does_not_force_task_to_100_percent(self):
        emitter = RichProgressEmitter(console=Console())
        emitter.start(total=1)
        emitter.emit(
            DownloadProgress(
                id="x",
                status=DownloadStatus.PROCESSING,
                percent=99.0,
                title="Big Buck Bunny",
            )
        )
        task_id = emitter._task_ids["x"]
        task = emitter._progress.tasks[task_id]
        assert task.completed == 99.0
        emitter.finish()
