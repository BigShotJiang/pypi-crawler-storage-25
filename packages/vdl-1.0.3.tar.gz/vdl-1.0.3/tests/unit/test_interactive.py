from __future__ import annotations

import io
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from rich.console import Console

from support.fake_downloader import FakeDownloader
from support.fake_playlist_resolver import FakePlaylistResolver
from support.fake_state_store import InMemoryStateStore
from vdl.acquisition import AcquisitionItem, AcquisitionPlan
from vdl.client import InteractiveUrlInspection, VDLClient
from vdl.config import VDLConfig
from vdl.interactive import (
    DownloadOptions,
    InteractiveApp,
    prompt_for_direct_or_crawl,
    prompt_for_direct_or_crawl_async,
    prompt_for_discovered_selection,
    prompt_for_discovered_selection_async,
    prompt_for_download_options,
    prompt_for_download_options_async,
    prompt_for_playlist_member_choice,
    prompt_for_playlist_member_choice_async,
    prompt_for_playlist_selection,
    prompt_for_playlist_selection_async,
    prompt_for_url,
    prompt_for_url_async,
    run_interactive,
)
from vdl.models import InputKind, PlaylistInfo, PlaylistItem, Quality
from vdl.selection import selection_to_indexes

URL = "https://youtube.com/watch?v=abc"


def _client(tmp_path: Path) -> VDLClient:
    return VDLClient(
        config=VDLConfig(output_dir=tmp_path),
        downloader=FakeDownloader(),
        playlist_resolver=FakePlaylistResolver(),
        state_store=InMemoryStateStore(),
    )


def _console() -> Console:
    return Console(
        file=io.StringIO(), force_terminal=False, color_system=None, width=120
    )


class TestPromptHelpers:
    def test_prompt_for_url_returns_stripped_input(self):
        with patch("builtins.input", return_value="  https://example.com  "):
            result = prompt_for_url()
        assert result == "https://example.com"

    def test_prompt_for_discovered_selection_enter_returns_all(self):
        with patch("builtins.input", return_value=""):
            result = prompt_for_discovered_selection(3)
        assert result.mode == "all"

    def test_prompt_for_download_options_empty_returns_best(self):
        # Inputs in order: quality, output_dir, write_thumbnail, write_subtitles
        with patch("builtins.input", side_effect=["", "", "", ""]):
            opts = prompt_for_download_options("https://example.com/v")
        assert isinstance(opts, DownloadOptions)
        assert opts.quality == Quality.BEST
        assert opts.output_dir is None
        # Sidecars default to True (yes/no prompt with default=True)
        assert opts.write_thumbnail is True
        assert opts.write_subtitles is True

    def test_prompt_for_playlist_member_choice_default_single(self):
        with patch("builtins.input", return_value=""):
            assert prompt_for_playlist_member_choice() == "single"

    def test_prompt_for_playlist_member_choice_p_picks_playlist(self):
        with patch("builtins.input", return_value="p"):
            assert prompt_for_playlist_member_choice() == "playlist"

    async def test_async_prompt_for_playlist_member_choice_retries_invalid_input(self):
        with patch("builtins.input", side_effect=["b", "p"]):
            assert await prompt_for_playlist_member_choice_async() == "playlist"

    def test_prompt_for_url_strips_pasted_prompt_label(self):
        # Reproduces bug 2 from the field report.
        with patch(
            "builtins.input",
            return_value="URL or file path https://www.youtube.com/watch?v=abc",
        ):
            assert prompt_for_url() == "https://www.youtube.com/watch?v=abc"

    def test_prompt_for_url_strips_surrounding_quotes(self):
        with patch("builtins.input", return_value='"https://example.com/v"'):
            assert prompt_for_url() == "https://example.com/v"

    async def test_async_prompt_for_url_strips_surrounding_quotes(self):
        with patch("builtins.input", return_value='"https://example.com/v"'):
            assert await prompt_for_url_async() == "https://example.com/v"

    def test_prompt_for_direct_or_crawl_defaults_to_direct(self):
        with patch("builtins.input", return_value=""):
            assert prompt_for_direct_or_crawl() == "direct"

    def test_prompt_for_direct_or_crawl_recognizes_crawl(self):
        with patch("builtins.input", return_value="c"):
            assert prompt_for_direct_or_crawl() == "crawl"

    async def test_async_prompt_for_direct_or_crawl_retries_invalid_input(self):
        with patch("builtins.input", side_effect=["x", "c"]):
            assert await prompt_for_direct_or_crawl_async() == "crawl"

    def test_prompt_for_playlist_selection_parses_indexes(self):
        playlist = PlaylistInfo(
            url="https://youtube.com/playlist",
            title="My Playlist",
            items=[
                PlaylistItem(url="https://youtube.com/watch?v=a", title="A", index=0),
                PlaylistItem(url="https://youtube.com/watch?v=b", title="B", index=1),
            ],
        )
        with patch("builtins.input", return_value="1"):
            sel = prompt_for_playlist_selection(playlist)
        assert selection_to_indexes(sel, 2) == [1]

    async def test_async_prompt_for_playlist_selection_retries_invalid_input(self):
        playlist = PlaylistInfo(
            url="https://youtube.com/playlist",
            title="My Playlist",
            items=[
                PlaylistItem(url="https://youtube.com/watch?v=a", title="A", index=0),
                PlaylistItem(url="https://youtube.com/watch?v=b", title="B", index=1),
            ],
        )
        with patch("builtins.input", side_effect=["oops", "1"]):
            sel = await prompt_for_playlist_selection_async(playlist)
        assert selection_to_indexes(sel, 2) == [1]

    async def test_async_prompt_for_discovered_selection_retries_invalid_input(self):
        with patch("builtins.input", side_effect=["oops", "0-1"]):
            sel = await prompt_for_discovered_selection_async(3)
        assert selection_to_indexes(sel, 3) == [0, 1]

    async def test_async_prompt_for_download_options_accepts_shorthand_quality(self):
        with patch("builtins.input", side_effect=["480", "", "", ""]):
            opts = await prompt_for_download_options_async("https://example.com/v")
        assert isinstance(opts, DownloadOptions)
        assert opts.quality == Quality.P480


class TestInteractiveApp:
    async def test_quit_word_exits_zero(self, tmp_path):
        client = _client(tmp_path)
        app = InteractiveApp(client=client, console=_console())
        with patch("builtins.input", return_value="quit"):
            rc = await app.run()
        assert rc == 0

    async def test_invalid_url_continues(self, tmp_path):
        client = _client(tmp_path)
        app = InteractiveApp(client=client, console=_console())
        inputs = iter(["not-a-url", "quit"])
        with patch("builtins.input", side_effect=inputs):
            rc = await app.run()
        assert rc == 0

    async def test_playlist_url_uses_playlist_selection(self, tmp_path):
        client = _client(tmp_path)
        app = InteractiveApp(client=client, console=_console())
        # URL, quality, output_dir, thumb, subs, selection, quit
        inputs = iter([URL, "", "", "", "", "", "quit"])
        with patch.object(
            client,
            "inspect_url_for_interactive",
            AsyncMock(
                return_value=InteractiveUrlInspection(
                    kind="playlist",
                    playlist_url="https://example.com/playlist/123",
                )
            ),
        ):
            with patch.object(client, "plan", AsyncMock()) as mock_plan:
                mock_plan.return_value = AcquisitionPlan(
                    items=[
                        AcquisitionItem(
                            source_url="https://example.com/playlist/123",
                            is_playlist=True,
                        )
                    ],
                    source_kind=InputKind.PLAYLIST_URL,
                    total=1,
                )
                with patch.object(
                    client, "execute_plan", AsyncMock(return_value=[])
                ) as mock_execute:
                    with patch("builtins.input", side_effect=inputs):
                        rc = await app.run()
        assert rc == 0
        assert mock_execute.await_args.kwargs["selection"].mode == "all"

    async def test_playlist_member_can_choose_playlist(self, tmp_path):
        client = _client(tmp_path)
        app = InteractiveApp(client=client, console=_console())
        # URL, member_choice='p', quality, output_dir, thumb, subs, selection, quit
        inputs = iter([URL, "p", "", "", "", "", "", "quit"])
        with patch.object(
            client,
            "inspect_url_for_interactive",
            AsyncMock(
                return_value=InteractiveUrlInspection(
                    kind="playlist_member",
                    playlist_url="https://example.com/playlist/123",
                    entry_url=URL,
                )
            ),
        ):
            with patch.object(client, "plan", AsyncMock()) as mock_plan:
                mock_plan.return_value = AcquisitionPlan(
                    items=[
                        AcquisitionItem(
                            source_url="https://example.com/playlist/123",
                            is_playlist=True,
                        )
                    ],
                    source_kind=InputKind.PLAYLIST_URL,
                    total=1,
                )
                with patch.object(
                    client, "execute_plan", AsyncMock(return_value=[])
                ) as mock_execute:
                    with patch("builtins.input", side_effect=inputs):
                        rc = await app.run()
        assert rc == 0
        assert mock_execute.await_args.kwargs["prefer_playlist"] is True

    async def test_single_url_can_choose_direct_download(self, tmp_path):
        client = _client(tmp_path)
        app = InteractiveApp(client=client, console=_console())
        # URL, quality, output_dir, thumb, subs, direct_or_crawl, quit
        inputs = iter([URL, "", "", "", "", "", "quit"])
        with patch.object(
            client,
            "inspect_url_for_interactive",
            AsyncMock(return_value=InteractiveUrlInspection(kind="single")),
        ):
            with patch.object(client, "plan", AsyncMock()) as mock_plan:
                mock_plan.return_value = AcquisitionPlan(
                    items=[AcquisitionItem(source_url=URL)],
                    source_kind=InputKind.VIDEO_URL,
                    total=1,
                )
                with patch.object(
                    client, "execute_plan", AsyncMock(return_value=[])
                ) as mock_execute:
                    with patch("builtins.input", side_effect=inputs):
                        rc = await app.run()
        assert rc == 0
        assert mock_plan.await_args.kwargs["quality"] == Quality.BEST
        assert mock_execute.await_count == 1

    async def test_single_url_can_choose_crawl(self, tmp_path):
        client = _client(tmp_path)
        app = InteractiveApp(client=client, console=_console())
        crawl_plan = AcquisitionPlan(
            items=[
                AcquisitionItem(source_url="https://example.com/vid0"),
                AcquisitionItem(source_url="https://example.com/vid1"),
            ],
            source_kind=InputKind.URL,
            total=2,
            metadata={
                "discovered": True,
                "selection_kind": "candidate_list",
                "discovery": {"crawler_method": "http"},
            },
        )
        # URL, quality, output_dir, thumb, subs, crawl, selection, quit
        inputs = iter([URL, "", "", "", "", "c", "0", "quit"])
        with patch.object(
            client,
            "inspect_url_for_interactive",
            AsyncMock(return_value=InteractiveUrlInspection(kind="single")),
        ):
            with patch.object(client, "discover", AsyncMock(return_value=crawl_plan)):
                with patch.object(
                    client, "execute_plan", AsyncMock(return_value=[])
                ) as mock_execute:
                    with patch("builtins.input", side_effect=inputs):
                        rc = await app.run()
        assert rc == 0
        assert selection_to_indexes(mock_execute.await_args.kwargs["selection"], 2) == [
            0
        ]


class TestRunInteractive:
    async def test_creates_client_if_none(self, tmp_path):
        mock_app = MagicMock()
        mock_app.run = AsyncMock(return_value=0)
        with patch("vdl.interactive.InteractiveApp", return_value=mock_app):
            with patch(
                "vdl.config.load_config", return_value=VDLConfig(output_dir=tmp_path)
            ):
                await run_interactive()
        mock_app.run.assert_called_once()
