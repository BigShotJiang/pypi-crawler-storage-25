"""Tests for vdl.input_parser."""

import pytest

from vdl.input_parser import parse_link_file, tokenize_raw_input


def test_parse_link_file_basic(tmp_path):
    f = tmp_path / "links.txt"
    f.write_text("https://youtube.com/watch?v=1\nhttps://youtube.com/watch?v=2\n")
    assert parse_link_file(f) == [
        "https://youtube.com/watch?v=1",
        "https://youtube.com/watch?v=2",
    ]


def test_parse_link_file_strips_blanks_and_comments(tmp_path):
    f = tmp_path / "links.txt"
    f.write_text(
        "# comment\n"
        "\n"
        "https://youtube.com/watch?v=1\n"
        "   \n"
        "# another comment\n"
        "https://youtube.com/watch?v=2\n"
    )
    assert parse_link_file(f) == [
        "https://youtube.com/watch?v=1",
        "https://youtube.com/watch?v=2",
    ]


def test_parse_link_file_strips_whitespace(tmp_path):
    f = tmp_path / "links.txt"
    f.write_text("  https://youtube.com/watch?v=1  \n")
    assert parse_link_file(f) == ["https://youtube.com/watch?v=1"]


def test_parse_link_file_empty(tmp_path):
    f = tmp_path / "links.txt"
    f.write_text("")
    assert parse_link_file(f) == []


def test_parse_link_file_all_comments(tmp_path):
    f = tmp_path / "links.txt"
    f.write_text("# nothing here\n# more comments\n")
    assert parse_link_file(f) == []


def test_tokenize_raw_input_comma_separated():
    result = tokenize_raw_input("a,b,c")
    assert result == ["a", "b", "c"]


def test_tokenize_raw_input_comma_separated_with_spaces():
    result = tokenize_raw_input("url1, url2, url3")
    assert result == ["url1", "url2", "url3"]


def test_tokenize_raw_input_space_separated():
    result = tokenize_raw_input("url1 url2 url3")
    assert result == ["url1", "url2", "url3"]


def test_tokenize_raw_input_single():
    assert tokenize_raw_input("url1") == ["url1"]


def test_tokenize_raw_input_empty():
    assert tokenize_raw_input("") == []


def test_tokenize_raw_input_comma_takes_priority_over_spaces():
    # when commas present, splits by comma not by space
    result = tokenize_raw_input("url1 url2,url3 url4")
    assert result == ["url1 url2", "url3 url4"]
