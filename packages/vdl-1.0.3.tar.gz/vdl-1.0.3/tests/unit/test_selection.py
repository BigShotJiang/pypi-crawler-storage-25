"""Tests for vdl.selection."""

import pytest

from vdl.errors import VDLSelectionError
from vdl.selection import (
    PlaylistSelection,
    parse_playlist_selection,
    selection_to_indexes,
)


class TestParsePlaylistSelection:
    def test_empty_string_means_all(self):
        sel = parse_playlist_selection("", 10)
        assert sel.mode == "all"

    def test_all_keyword(self):
        sel = parse_playlist_selection("all", 10)
        assert sel.mode == "all"

    def test_all_keyword_with_whitespace(self):
        sel = parse_playlist_selection("  all  ", 10)
        assert sel.mode == "all"

    def test_first_n(self):
        sel = parse_playlist_selection("first:5", 10)
        assert sel.mode == "first_n"
        assert sel.first_n == 5

    def test_first_n_zero(self):
        sel = parse_playlist_selection("first:0", 10)
        assert sel.mode == "first_n"
        assert sel.first_n == 0

    def test_first_n_negative_clamped_to_zero(self):
        sel = parse_playlist_selection("first:-3", 10)
        assert sel.mode == "first_n"
        assert sel.first_n == 0

    def test_first_n_invalid_falls_back_to_all(self):
        sel = parse_playlist_selection("first:abc", 10)
        assert sel.mode == "all"

    def test_discrete_indexes(self):
        sel = parse_playlist_selection("0,2,4", 10)
        assert sel.mode == "indexes"
        assert sel.indexes == frozenset({0, 2, 4})

    def test_single_index(self):
        sel = parse_playlist_selection("3", 10)
        assert sel.mode == "indexes"
        assert sel.indexes == frozenset({3})

    def test_range(self):
        sel = parse_playlist_selection("0-3", 10)
        assert sel.mode == "indexes"
        assert sel.indexes == frozenset({0, 1, 2, 3})

    def test_mixed_ranges_and_discrete(self):
        sel = parse_playlist_selection("0-2,5,8-9", 20)
        assert sel.mode == "indexes"
        assert sel.indexes == frozenset({0, 1, 2, 5, 8, 9})

    def test_invalid_falls_back_to_all(self):
        sel = parse_playlist_selection("not-valid-at-all", 10)
        assert sel.mode == "all"

    def test_frozen(self):
        import dataclasses

        sel = parse_playlist_selection("0,1", 10)
        with pytest.raises(dataclasses.FrozenInstanceError):
            sel.mode = "all"  # type: ignore[misc]


class TestSelectionToIndexes:
    def test_all_mode(self):
        sel = PlaylistSelection(mode="all")
        assert selection_to_indexes(sel, 5) == [0, 1, 2, 3, 4]

    def test_all_mode_empty_total(self):
        sel = PlaylistSelection(mode="all")
        assert selection_to_indexes(sel, 0) == []

    def test_first_n_within_total(self):
        sel = PlaylistSelection(mode="first_n", first_n=3)
        assert selection_to_indexes(sel, 10) == [0, 1, 2]

    def test_first_n_exceeds_total(self):
        sel = PlaylistSelection(mode="first_n", first_n=20)
        assert selection_to_indexes(sel, 5) == [0, 1, 2, 3, 4]

    def test_first_n_zero(self):
        sel = PlaylistSelection(mode="first_n", first_n=0)
        assert selection_to_indexes(sel, 10) == []

    def test_indexes_in_bounds(self):
        sel = PlaylistSelection(mode="indexes", indexes=frozenset({0, 2, 4}))
        assert selection_to_indexes(sel, 5) == [0, 2, 4]

    def test_indexes_out_of_bounds_filtered(self):
        sel = PlaylistSelection(mode="indexes", indexes=frozenset({0, 5, 10}))
        assert selection_to_indexes(sel, 5) == [0]

    def test_indexes_sorted(self):
        sel = PlaylistSelection(mode="indexes", indexes=frozenset({4, 1, 3}))
        assert selection_to_indexes(sel, 10) == [1, 3, 4]


class TestMostRecentSelection:
    def test_parse_most_recent(self):
        sel = parse_playlist_selection("most_recent:3", 10)
        assert sel.mode == "most_recent_n"
        assert sel.most_recent_n == 3

    def test_parse_most_recent_invalid_falls_back_to_all(self):
        sel = parse_playlist_selection("most_recent:abc", 10)
        assert sel.mode == "all"

    def test_chronological_desc_takes_first_n(self):
        sel = PlaylistSelection(mode="most_recent_n", most_recent_n=3)
        assert selection_to_indexes(sel, 10, ordering="chronological_desc") == [0, 1, 2]

    def test_chronological_asc_takes_last_n(self):
        sel = PlaylistSelection(mode="most_recent_n", most_recent_n=3)
        assert selection_to_indexes(sel, 10, ordering="chronological_asc") == [7, 8, 9]

    def test_unknown_ordering_raises(self):
        sel = PlaylistSelection(mode="most_recent_n", most_recent_n=3)
        with pytest.raises(VDLSelectionError):
            selection_to_indexes(sel, 10)

    def test_zero_n_returns_empty(self):
        sel = PlaylistSelection(mode="most_recent_n", most_recent_n=0)
        assert selection_to_indexes(sel, 10) == []

    def test_n_exceeds_total_clamped(self):
        sel = PlaylistSelection(mode="most_recent_n", most_recent_n=20)
        assert selection_to_indexes(sel, 5, ordering="chronological_desc") == [
            0,
            1,
            2,
            3,
            4,
        ]
        assert selection_to_indexes(sel, 5, ordering="chronological_asc") == [
            0,
            1,
            2,
            3,
            4,
        ]
