from __future__ import annotations

from pathlib import Path

import pytest

from vdl.models import DownloadResult, DownloadStatus, Quality
from vdl.progress import DownloadProgress
from support.fake_state_store import InMemoryStateStore
from vdl.state import reconcile_status_records


URL = "https://youtube.com/watch?v=abc123"
URL2 = "https://youtube.com/watch?v=xyz999"


def _store() -> InMemoryStateStore:
    return InMemoryStateStore()


class TestRecordStarted:
    def test_creates_starting_record(self):
        store = _store()
        store.record_started("id-1", URL, "download")
        rec = store.get_status("id-1")
        assert rec is not None
        assert rec.status == DownloadStatus.STARTING
        assert rec.source_url == URL

    def test_url_index_populated(self):
        store = _store()
        store.record_started("id-1", URL, "download")
        rec = store.find_by_url(URL)
        assert rec is not None
        assert rec.id == "id-1"


class TestRecordProgress:
    def test_updates_status_and_percent(self):
        store = _store()
        store.record_started("id-1", URL, "download")
        progress = DownloadProgress(
            id="id-1", status=DownloadStatus.DOWNLOADING, percent=42.0
        )
        store.record_progress(progress, URL, "download")
        rec = store.get_status("id-1")
        assert rec.status == DownloadStatus.DOWNLOADING
        assert rec.percent == 42.0


class TestRecordCompleted:
    def test_marks_completed(self):
        store = _store()
        store.record_started("id-1", URL, "download")
        result = DownloadResult(
            id="id-1",
            source_url=URL,
            status=DownloadStatus.COMPLETED,
            output_path=Path("/downloads/file.mp4"),
        )
        store.record_completed(result)
        rec = store.get_status("id-1")
        assert rec.status == DownloadStatus.COMPLETED
        assert rec.output_path == Path("/downloads/file.mp4")

    def test_url_index_still_valid(self):
        store = _store()
        store.record_started("id-1", URL, "download")
        result = DownloadResult(
            id="id-1", source_url=URL, status=DownloadStatus.COMPLETED
        )
        store.record_completed(result)
        assert store.find_by_url(URL) is not None


class TestRecordFailed:
    def test_marks_failed_with_error(self):
        store = _store()
        store.record_started("id-1", URL, "download")
        store.record_failed("id-1", URL, "connection refused")
        rec = store.get_status("id-1")
        assert rec.status == DownloadStatus.FAILED
        assert rec.error == "connection refused"


class TestFindByUrl:
    def test_returns_none_when_missing(self):
        store = _store()
        assert store.find_by_url("https://nothere.com") is None

    def test_finds_existing(self):
        store = _store()
        store.record_started("id-1", URL, "download")
        rec = store.find_by_url(URL)
        assert rec is not None
        assert rec.id == "id-1"


class TestFindByRequest:
    def test_returns_none_when_missing(self):
        store = _store()
        assert store.find_by_request(URL, Quality.BEST) is None

    def test_distinguishes_by_quality(self):
        store = _store()
        store.record_started("id-1", URL, "download", quality=Quality.BEST)
        store.record_started("id-2", URL, "download", quality=Quality.P720)
        best = store.find_by_request(URL, Quality.BEST)
        p720 = store.find_by_request(URL, Quality.P720)
        assert best is not None
        assert p720 is not None
        assert best.id == "id-1"
        assert p720.id == "id-2"


class TestGetStatus:
    def test_returns_none_for_unknown_id(self):
        store = _store()
        assert store.get_status("nonexistent") is None

    def test_returns_record_by_id(self):
        store = _store()
        store.record_started("id-abc", URL, "download")
        rec = store.get_status("id-abc")
        assert rec is not None
        assert rec.id == "id-abc"


class TestListRecent:
    def test_empty_returns_empty(self):
        assert _store().list_recent() == []

    def test_returns_all_records(self):
        store = _store()
        store.record_started("id-1", URL, "download")
        store.record_started("id-2", URL2, "download")
        records = store.list_recent()
        assert len(records) == 2

    def test_sorted_most_recent_first(self):
        import time

        store = _store()
        store.record_started("id-1", URL, "download")
        time.sleep(0.01)
        store.record_started("id-2", URL2, "download")
        records = store.list_recent()
        assert records[0].id == "id-2"

    def test_limit_respected(self):
        store = _store()
        for i in range(5):
            store.record_started(f"id-{i}", f"https://example.com/v/{i}", "download")
        records = store.list_recent(limit=3)
        assert len(records) == 3

    def test_idempotency_skip_pattern(self):
        store = _store()
        store.record_started("id-1", URL, "download")
        result = DownloadResult(
            id="id-1", source_url=URL, status=DownloadStatus.COMPLETED
        )
        store.record_completed(result)
        found = store.find_by_url(URL)
        assert found.status == DownloadStatus.COMPLETED


class TestReconcileStatusRecords:
    def test_existing_file(self, tmp_path):
        file_path = tmp_path / "video.mp4"
        file_path.write_text("ok", encoding="utf-8")
        store = _store()
        store.record_started("id-1", URL, "download")
        store.record_completed(
            DownloadResult(
                id="id-1",
                source_url=URL,
                status=DownloadStatus.COMPLETED,
                output_path=file_path,
            )
        )
        report = reconcile_status_records(store.list_recent())
        assert report.entries[0].status == "exists"

    def test_missing_file(self):
        missing = Path("/tmp/vdl-missing-file.mp4")
        store = _store()
        store.record_started("id-1", URL, "download")
        store.record_completed(
            DownloadResult(
                id="id-1",
                source_url=URL,
                status=DownloadStatus.COMPLETED,
                output_path=missing,
            )
        )
        report = reconcile_status_records(store.list_recent())
        assert report.entries[0].status == "missing"

    def test_no_output_path(self):
        store = _store()
        store.record_started("id-1", URL, "download")
        report = reconcile_status_records(store.list_recent())
        assert report.entries[0].status == "no_output_path"
