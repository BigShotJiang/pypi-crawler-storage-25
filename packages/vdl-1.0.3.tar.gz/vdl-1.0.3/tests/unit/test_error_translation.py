"""Tests for vdl.error_translation."""

from __future__ import annotations

from vdl.error_translation import strip_ansi, translate_error


class TestStripAnsi:
    def test_strips_color_codes(self):
        assert strip_ansi("\x1b[0;31mERROR:\x1b[0m boom") == "ERROR: boom"

    def test_passes_plain_text(self):
        assert strip_ansi("just text") == "just text"


class TestTranslateError:
    def test_connection_reset_is_network_lost(self):
        # Reproduces bug #6 from the field report.
        raw = (
            'ERROR:  Got error: ("Connection broken: ConnectionResetError(54, '
            "'Connection reset by peer')\", ConnectionResetError(54))"
        )
        translated = translate_error(raw)
        assert translated.category == "network_lost"
        assert "connection" in translated.message.lower()
        assert translated.hint is not None
        assert (
            "re-run" in translated.hint.lower() or "skipped" in translated.hint.lower()
        )

    def test_dns_failure_is_network_lost(self):
        translated = translate_error("Temporary failure in name resolution")
        assert translated.category == "network_lost"

    def test_impersonation_version_mismatch_hint_points_at_repo_sync(self):
        from unittest.mock import patch

        from vdl.error_translation import translate_error
        from vdl.impersonation import ImpersonationCheck

        raw = (
            "ERROR:  x55plm9: The extractor is attempting impersonation, but "
            "none of these impersonate targets are available: firefox."
        )
        with patch(
            "vdl.impersonation.probe_impersonation",
            return_value=ImpersonationCheck(
                status="version_mismatch",
                detail="Only curl_cffi versions 0.5.10 and 0.10.x through 0.14.x are supported",
            ),
        ):
            translated = translate_error(raw)
        assert translated.category == "impersonation_missing"
        # Surface the precise version-range message so the user understands the drift.
        assert "0.10.x through 0.14.x" in (translated.hint or "")
        # Point at the repo's actual install path, not a generic pip hint.
        assert "task sync" in (translated.hint or "") or "uv sync" in (
            translated.hint or ""
        )

    def test_impersonation_missing_curl_cffi_hint_points_at_repo_sync(self):
        from unittest.mock import patch

        from vdl.error_translation import translate_error
        from vdl.impersonation import ImpersonationCheck

        with patch(
            "vdl.impersonation.probe_impersonation",
            return_value=ImpersonationCheck(
                status="missing", detail="No module named 'curl_cffi'"
            ),
        ):
            translated = translate_error(
                "attempting impersonation; firefox unavailable"
            )
        assert translated.category == "impersonation_missing"
        assert "task sync" in (translated.hint or "") or "uv sync" in (
            translated.hint or ""
        )

    def test_impersonation_missing_is_categorized(self):
        # Reproduces bug #7 from the field report.
        raw = (
            "ERROR:  x3r86fi: The extractor is attempting impersonation, but "
            "none of these impersonate targets are available: firefox."
        )
        translated = translate_error(raw)
        assert translated.category == "impersonation_missing"
        assert translated.hint is not None
        # Hint always points at the repo's sync workflow, regardless of the
        # specific probe outcome on the host running the test.
        assert "task sync" in translated.hint or "uv sync" in translated.hint

    def test_unknown_error_passes_through(self):
        translated = translate_error("Some random failure")
        assert translated.category == "unknown"
        assert translated.message == "Some random failure"

    def test_strips_ansi_in_raw(self):
        translated = translate_error("\x1b[0;31mERROR:\x1b[0m connection reset")
        assert "\x1b" not in translated.raw
        assert translated.category == "network_lost"

    def test_empty_error_returns_unknown(self):
        translated = translate_error("")
        assert translated.category == "unknown"
        assert translated.message == "Download failed."
