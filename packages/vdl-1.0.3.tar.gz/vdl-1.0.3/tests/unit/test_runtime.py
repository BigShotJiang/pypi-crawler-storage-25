"""Tests for library-owned runtime wiring (PR1: CLI/library boundary fix)."""

from __future__ import annotations

import ast
from pathlib import Path

from vdl.client import VDLClient
from vdl.runtime import build_default_client, build_default_components


def test_build_default_components_returns_wired_bundle():
    c = build_default_components()
    assert c.downloader is not None
    assert c.playlist_resolver is not None
    assert c.state_store is not None
    assert c.doctor_service is not None
    assert c.config_store is not None


def test_build_default_client_is_fully_wired():
    client = build_default_client()
    assert client.downloader is not None
    assert client.playlist_resolver is not None
    assert client.state_store is not None
    assert client.doctor_service is not None


def test_bare_vdlclient_autowires_defaults():
    """`VDLClient()` with no args should be usable for downloads."""
    client = VDLClient()
    assert client.downloader is not None
    assert client.playlist_resolver is not None
    assert client.state_store is not None
    assert client.doctor_service is not None


def test_vdlclient_with_explicit_config_does_not_autowire(tmp_path):
    """Passing config signals explicit injection; deps must remain unset."""
    from vdl.config import VDLConfig

    cfg = VDLConfig(output_dir=tmp_path / "downloads")
    client = VDLClient(config=cfg)
    assert client.downloader is None
    assert client.state_store is None
    assert client.doctor_service is None


def _imports_in_module(module_path: Path) -> set[str]:
    tree = ast.parse(module_path.read_text(encoding="utf-8"))
    found: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            found.add(node.module)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                found.add(alias.name)
    return found


def test_tools_does_not_import_from_cli():
    src = Path(__file__).resolve().parents[2] / "src" / "vdl" / "tools.py"
    assert "vdl.cli" not in _imports_in_module(src)


def test_mcp_server_does_not_import_from_cli():
    src = Path(__file__).resolve().parents[2] / "src" / "vdl" / "mcp_server.py"
    assert "vdl.cli" not in _imports_in_module(src)
