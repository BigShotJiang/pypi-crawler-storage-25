"""Phase 4: URL and input analysis tests."""

from pathlib import Path

import pytest

from vdl.models import InputKind
from vdl.urls import (
    UrlAnalysis,
    analyze_input,
    is_local_link_file,
    is_playlist_url,
    is_supported_url,
    is_video_url,
    normalize_url,
)


# --- is_playlist_url ---


def test_youtube_playlist_url():
    assert is_playlist_url("https://www.youtube.com/playlist?list=PLabc123") is True


def test_youtube_view_playlist_url():
    assert is_playlist_url("https://www.youtube.com/view_playlist?p=PLabc") is True


def test_youtube_watch_videos_anonymous_playlist():
    url = (
        "https://www.youtube.com/watch_videos?video_ids=R0ibd_SSXH0%2CVHUrdELKjDw"
        "&type=0&title=Mastering+Love"
    )
    assert is_playlist_url(url) is True


def test_youtube_show_url_is_playlist():
    url = "https://www.youtube.com/show/VLPL22egh3ok4cN2XmlvCGt-YCIVBCuESFIw?sbp=foo"
    assert is_playlist_url(url) is True


def test_list_param_without_watch():
    assert is_playlist_url("https://www.youtube.com/?list=PLabc123") is True


def test_watch_url_with_list_is_not_plain_playlist():
    # watch?v=...&list=... is ambiguous (mix), not a plain playlist
    assert is_playlist_url("https://www.youtube.com/watch?v=abc&list=PLmix") is False


def test_plain_video_url_is_not_playlist():
    assert is_playlist_url("https://www.youtube.com/watch?v=abc123") is False


def test_vimeo_showcase_is_playlist():
    assert is_playlist_url("https://vimeo.com/showcase/12345678") is True


def test_vimeo_album_is_playlist():
    assert is_playlist_url("https://vimeo.com/album/987654") is True


def test_vimeo_single_video_is_not_playlist():
    assert is_playlist_url("https://vimeo.com/123456789") is False


def test_dailymotion_playlist_is_playlist():
    assert is_playlist_url("https://www.dailymotion.com/playlist/x5s8m3") is True


def test_dailymotion_video_is_not_playlist():
    assert is_playlist_url("https://www.dailymotion.com/video/x7xxx") is False


def test_soundcloud_set_is_playlist():
    assert is_playlist_url("https://soundcloud.com/artist/sets/my-collection") is True


def test_soundcloud_track_is_not_playlist():
    assert is_playlist_url("https://soundcloud.com/artist/track-name") is False


def test_generic_playlists_path_is_playlist():
    assert is_playlist_url("https://example.com/playlists/123") is True


def test_generic_collections_path_is_playlist():
    assert is_playlist_url("https://example.com/collections/my-list") is True


def test_youtube_list_no_video_is_playlist():
    # list= with no v= param is a pure playlist
    assert is_playlist_url("https://www.youtube.com/?list=PLabc123") is True


# --- _is_mix_url (tested indirectly via analyze_input, but also directly) ---


def test_mix_url_youtube_watch():
    from vdl.urls import _is_mix_url

    assert _is_mix_url("https://www.youtube.com/watch?v=abc&list=PLmix") is True


def test_mix_url_youtu_be_with_list():
    from vdl.urls import _is_mix_url

    assert _is_mix_url("https://youtu.be/abc123?list=PLmix") is True


def test_mix_url_youtube_no_list():
    from vdl.urls import _is_mix_url

    assert _is_mix_url("https://www.youtube.com/watch?v=abc") is False


def test_mix_url_playlist_only_is_not_mix():
    from vdl.urls import _is_mix_url

    assert _is_mix_url("https://www.youtube.com/playlist?list=PLabc") is False


def test_mix_url_non_youtube_collection_hint_is_ambiguous():
    from vdl.urls import _is_mix_url

    assert _is_mix_url("https://vimeo.com/123456?list=abc") is True


def test_mix_url_generic_playlist_query_is_ambiguous():
    from vdl.urls import _is_mix_url

    assert _is_mix_url("https://example.com/watch/abc?playlist=my-mix") is True


def test_mix_url_collection_page_is_not_ambiguous():
    from vdl.urls import _is_mix_url

    assert _is_mix_url("https://example.com/playlist/abc?playlist=my-mix") is False


# --- is_video_url ---


def test_plain_video_url():
    assert is_video_url("https://www.youtube.com/watch?v=abc123") is True


def test_youtu_be_short_url():
    assert is_video_url("https://youtu.be/abc123") is True


def test_playlist_url_is_not_video():
    assert is_video_url("https://www.youtube.com/playlist?list=PLabc") is False


def test_empty_string_is_not_video():
    assert is_video_url("") is False


def test_local_path_is_not_video_url():
    assert is_video_url("/home/user/video.mp4") is False


# --- is_supported_url ---


def test_http_url_is_supported():
    assert is_supported_url("https://www.youtube.com/watch?v=abc") is True


def test_local_path_is_not_supported_url():
    assert is_supported_url("/home/user/file.txt") is False


def test_bare_word_is_not_supported_url():
    assert is_supported_url("notaurl") is False


# --- is_local_link_file ---


def test_txt_extension_is_link_file():
    assert is_local_link_file("links.txt") is True


def test_list_extension_is_link_file():
    assert is_local_link_file("links.list") is True


def test_urls_extension_is_link_file():
    assert is_local_link_file("links.urls") is True


def test_mp4_extension_is_not_link_file():
    assert is_local_link_file("video.mp4") is False


def test_existing_txt_file(tmp_path):
    f = tmp_path / "links.txt"
    f.write_text("https://youtube.com/watch?v=abc\n")
    assert is_local_link_file(str(f)) is True


def test_youtube_url_is_not_link_file():
    assert is_local_link_file("https://www.youtube.com/watch?v=abc") is False


# --- normalize_url ---


def test_normalize_strips_whitespace():
    assert (
        normalize_url("  https://youtube.com/watch?v=abc  ")
        == "https://youtube.com/watch?v=abc"
    )


def test_normalize_strips_quotes():
    assert (
        normalize_url('"https://youtube.com/watch?v=abc"')
        == "https://youtube.com/watch?v=abc"
    )


def test_normalize_single_quotes():
    assert (
        normalize_url("'https://youtube.com/watch?v=abc'")
        == "https://youtube.com/watch?v=abc"
    )


def test_normalize_stable():
    url = "https://youtube.com/watch?v=abc"
    assert normalize_url(url) == url


# --- analyze_input ---


def test_analyze_youtube_video():
    result = analyze_input("https://www.youtube.com/watch?v=abc123")
    assert result.kind == InputKind.VIDEO_URL
    assert result.is_supported is True
    assert result.is_ambiguous is False


def test_analyze_youtube_playlist():
    result = analyze_input("https://www.youtube.com/playlist?list=PLabc123")
    assert result.kind == InputKind.PLAYLIST_URL
    assert result.is_supported is True


def test_analyze_youtu_be():
    result = analyze_input("https://youtu.be/abc123")
    assert result.kind == InputKind.VIDEO_URL
    assert result.is_supported is True


def test_analyze_watch_with_list_is_ambiguous():
    result = analyze_input("https://www.youtube.com/watch?v=abc&list=PLmix")
    assert result.kind == InputKind.VIDEO_URL
    assert result.is_ambiguous is True


def test_analyze_txt_file_by_extension():
    result = analyze_input("my-links.txt")
    assert result.kind == InputKind.LOCAL_LINK_FILE
    assert result.is_supported is True


def test_analyze_existing_txt_file(tmp_path):
    f = tmp_path / "links.txt"
    f.write_text("https://youtube.com/watch?v=abc\n")
    result = analyze_input(str(f))
    assert result.kind == InputKind.LOCAL_LINK_FILE
    assert result.is_supported is True


def test_analyze_empty_input():
    result = analyze_input("")
    assert result.kind == InputKind.UNKNOWN
    assert result.is_supported is False


def test_analyze_unsupported_string():
    result = analyze_input("notaurl")
    assert result.kind == InputKind.UNKNOWN
    assert result.is_supported is False


def test_analyze_strips_quotes():
    result = analyze_input('"https://www.youtube.com/watch?v=abc123"')
    assert result.kind == InputKind.VIDEO_URL
    assert result.is_supported is True


def test_analyze_whitespace_stripped():
    result = analyze_input("  https://www.youtube.com/watch?v=abc123  ")
    assert result.kind == InputKind.VIDEO_URL


def test_analyze_vimeo_video():
    result = analyze_input("https://vimeo.com/123456789")
    assert result.kind == InputKind.VIDEO_URL
    assert result.is_supported is True


def test_analyze_vimeo_showcase():
    result = analyze_input("https://vimeo.com/showcase/12345678")
    assert result.kind == InputKind.PLAYLIST_URL
    assert result.is_supported is True


def test_analyze_soundcloud_set():
    result = analyze_input("https://soundcloud.com/artist/sets/my-mix")
    assert result.kind == InputKind.PLAYLIST_URL
    assert result.is_supported is True


def test_analyze_youtu_be_with_list_is_ambiguous():
    result = analyze_input("https://youtu.be/abc123?list=PLmix")
    assert result.kind == InputKind.VIDEO_URL
    assert result.is_ambiguous is True


def test_analyze_generic_playlist_hint_is_ambiguous():
    result = analyze_input("https://example.com/watch/abc?playlist=my-mix")
    assert result.kind == InputKind.VIDEO_URL
    assert result.is_ambiguous is True


def test_analyze_youtube_list_only_is_playlist():
    result = analyze_input("https://www.youtube.com/?list=PLabc123")
    assert result.kind == InputKind.PLAYLIST_URL
