"""Phase 2: Core models tests."""

import dataclasses
from pathlib import Path

import pytest

from vdl.models import (
    DoctorReport,
    DownloadKind,
    DownloadRequest,
    DownloadResult,
    DownloadStatus,
    InputKind,
    OutputMode,
    PlaylistInfo,
    PlaylistItem,
    Quality,
    SourceInput,
    StatusRecord,
)


def test_input_kind_values():
    assert InputKind.URL == "url"
    assert InputKind.VIDEO_URL == "video_url"
    assert InputKind.PLAYLIST_URL == "playlist_url"
    assert InputKind.LOCAL_LINK_FILE == "local_link_file"
    assert InputKind.LOCAL_MEDIA_FILE == "local_media_file"
    assert InputKind.UNKNOWN == "unknown"


def test_download_kind_values():
    assert DownloadKind.VIDEO == "video"
    assert DownloadKind.AUDIO == "audio"
    assert DownloadKind.PLAYLIST == "playlist"


def test_download_status_values():
    assert DownloadStatus.QUEUED == "queued"
    assert DownloadStatus.STARTING == "starting"
    assert DownloadStatus.DOWNLOADING == "downloading"
    assert DownloadStatus.PROCESSING == "processing"
    assert DownloadStatus.COMPLETED == "completed"
    assert DownloadStatus.SKIPPED == "skipped"
    assert DownloadStatus.FAILED == "failed"
    assert DownloadStatus.CANCELLED == "cancelled"


def test_quality_values():
    assert Quality.BEST == "best"
    assert Quality.MEDIUM == "medium"
    assert Quality.LOW == "low"
    assert Quality.P2160 == "2160p"
    assert Quality.P1440 == "1440p"
    assert Quality.P1080 == "1080p"
    assert Quality.P720 == "720p"
    assert Quality.P480 == "480p"
    assert Quality.AUDIO == "audio"


def test_output_mode_values():
    assert OutputMode.TEXT == "text"
    assert OutputMode.JSON == "json"
    assert OutputMode.RICH == "rich"


def test_source_input_construct():
    s = SourceInput(raw="https://youtube.com/watch?v=abc", kind=InputKind.VIDEO_URL)
    assert s.raw == "https://youtube.com/watch?v=abc"
    assert s.kind == InputKind.VIDEO_URL
    assert s.normalized is None


def test_source_input_with_normalized():
    s = SourceInput(
        raw="  https://youtu.be/abc  ",
        kind=InputKind.VIDEO_URL,
        normalized="https://youtube.com/watch?v=abc",
    )
    assert s.normalized == "https://youtube.com/watch?v=abc"


def test_download_request_defaults():
    src = SourceInput(raw="https://youtube.com/watch?v=abc", kind=InputKind.VIDEO_URL)
    req = DownloadRequest(source=src)
    assert req.quality == Quality.BEST
    assert req.kind == DownloadKind.VIDEO
    assert req.force is False
    assert req.playlist is False
    assert req.output_dir is None
    assert req.cookies is None
    assert req.cookies_from_browser is None
    assert req.subdirectory is None


def test_download_request_custom():
    src = SourceInput(
        raw="https://youtube.com/playlist?list=PL123", kind=InputKind.PLAYLIST_URL
    )
    req = DownloadRequest(
        source=src,
        output_dir=Path("/tmp/downloads"),
        quality=Quality.P720,
        kind=DownloadKind.AUDIO,
        force=True,
        playlist=True,
    )
    assert req.output_dir == Path("/tmp/downloads")
    assert req.quality == Quality.P720
    assert req.kind == DownloadKind.AUDIO
    assert req.force is True
    assert req.playlist is True


def test_download_result_construct():
    result = DownloadResult(
        id="abc123",
        source_url="https://youtube.com/watch?v=abc",
        status=DownloadStatus.COMPLETED,
    )
    assert result.id == "abc123"
    assert result.status == DownloadStatus.COMPLETED
    assert result.output_path is None
    assert result.error is None
    assert result.skipped_reason is None
    assert result.metadata == {}


def test_download_result_with_output():
    result = DownloadResult(
        id="abc123",
        source_url="https://youtube.com/watch?v=abc",
        status=DownloadStatus.COMPLETED,
        output_path=Path("/downloads/video.mp4"),
        metadata={"title": "My Video"},
    )
    assert result.output_path == Path("/downloads/video.mp4")
    assert result.metadata["title"] == "My Video"


def test_playlist_item_defaults():
    item = PlaylistItem(url="https://youtube.com/watch?v=abc")
    assert item.url == "https://youtube.com/watch?v=abc"
    assert item.id is None
    assert item.title is None
    assert item.index is None
    assert item.duration_seconds is None
    assert item.selected is True
    assert item.metadata == {}


def test_playlist_info_construct():
    items = [
        PlaylistItem(url="https://youtube.com/watch?v=1", index=0),
        PlaylistItem(url="https://youtube.com/watch?v=2", index=1),
    ]
    info = PlaylistInfo(
        url="https://youtube.com/playlist?list=PL123",
        title="My Playlist",
        items=items,
    )
    assert info.url == "https://youtube.com/playlist?list=PL123"
    assert info.title == "My Playlist"
    assert len(info.items) == 2
    assert info.metadata == {}


def test_status_record_construct():
    from datetime import UTC, datetime

    rec = StatusRecord(
        id="abc123",
        source_url="https://youtube.com/watch?v=abc",
        status=DownloadStatus.COMPLETED,
    )
    assert rec.id == "abc123"
    assert rec.status == DownloadStatus.COMPLETED
    assert rec.output_path is None
    assert rec.error is None
    assert rec.percent is None
    assert isinstance(rec.updated_at, datetime)
    assert rec.updated_at.tzinfo == UTC


def test_doctor_report_construct():
    report = DoctorReport(
        version="0.1.0",
        ffmpeg_available=True,
        ytdlp_available=True,
        config_ok=True,
        state_ok=True,
        output_dir_ok=True,
    )
    assert report.version == "0.1.0"
    assert report.ffmpeg_available is True
    assert report.details == {}


def test_dataclasses_are_frozen():
    src = SourceInput(raw="https://youtube.com/watch?v=abc", kind=InputKind.VIDEO_URL)
    with pytest.raises(dataclasses.FrozenInstanceError):
        src.raw = "changed"  # type: ignore[misc]

    result = DownloadResult(
        id="x", source_url="https://example.com", status=DownloadStatus.FAILED
    )
    with pytest.raises(dataclasses.FrozenInstanceError):
        result.status = DownloadStatus.COMPLETED  # type: ignore[misc]


def test_download_result_json_safe():
    result = DownloadResult(
        id="abc123",
        source_url="https://youtube.com/watch?v=abc",
        status=DownloadStatus.COMPLETED,
        output_path=Path("/downloads/video.mp4"),
        error=None,
        metadata={"title": "Test", "duration": 120},
    )
    assert str(result.id) == "abc123"
    assert str(result.source_url) == "https://youtube.com/watch?v=abc"
    assert result.status.value == "completed"
    assert str(result.output_path) == "/downloads/video.mp4"
