from __future__ import annotations

import pytest

from vdl.crawler import CrawlResult, LinkCrawler, SiteRuleDiscoveryResolver
from vdl.site_rules import SiteRule

_PAGINATION_HTML = """
<html><body>
  <ul class="pagination">
    <li><a href="/page/1">1</a></li>
    <li><a href="/page/2">2</a></li>
  </ul>
  <a href="/video/abc">Watch Video</a>
</body></html>
"""

_BLACKLIST_HTML = """
<html><body>
  <a href="/login">Login</a>
  <a href="/video/good">Good Video</a>
</body></html>
"""


def test_crawl_result_fields():
    r = CrawlResult(
        all_links=[], pagination_links=[], non_pagination_links=[], method="http"
    )
    assert r.all_links == []
    assert r.pagination_links == []
    assert r.non_pagination_links == []
    assert r.method == "http"


def test_parse_classify_splits_pagination_from_links():
    result = LinkCrawler._parse_and_classify_links(
        _PAGINATION_HTML, "https://example.com"
    )
    result.method = "test"
    assert len(result.pagination_links) >= 1
    assert len(result.non_pagination_links) >= 1


def test_parse_classify_filters_blacklisted_urls():
    result = LinkCrawler._parse_and_classify_links(
        _BLACKLIST_HTML, "https://example.com"
    )
    urls = [link["url"] for link in result.all_links]
    assert not any("/login" in u for u in urls)
    assert any("/video/good" in u for u in urls)


class _FakeCrawler:
    def __init__(self, result: CrawlResult) -> None:
        self.result = result

    def crawl(self, url: str, cookie_file=None) -> CrawlResult:
        return self.result


@pytest.mark.asyncio
async def test_site_rule_discovery_uses_video_and_pagination_patterns():
    result = CrawlResult(
        all_links=[
            {"url": "https://example.com/watch/1", "text": "Watch", "index": 0},
            {"url": "https://example.com/list?page=2", "text": "2", "index": 1},
            {"url": "https://example.com/about", "text": "About", "index": 2},
        ],
        pagination_links=[],
        non_pagination_links=[],
        method="http",
    )
    resolver = SiteRuleDiscoveryResolver(
        site_rules=[
            SiteRule(
                domain="example.com",
                video_patterns=[r"/watch/\d+"],
                pagination_patterns=[r"\?page=\d+"],
                pagination_text_patterns=[r"^\d+$"],
            )
        ],
        crawler=_FakeCrawler(result),
    )
    links = await resolver.resolve("https://example.com/videos")
    assert links == ["https://example.com/watch/1"]


@pytest.mark.asyncio
async def test_site_rule_discovery_report_records_match():
    result = CrawlResult(
        all_links=[
            {"url": "https://example.com/watch/1", "text": "Watch", "index": 0},
            {"url": "https://example.com/list?page=2", "text": "Load More", "index": 1},
        ],
        pagination_links=[],
        non_pagination_links=[],
        method="http",
    )
    resolver = SiteRuleDiscoveryResolver(
        site_rules=[
            SiteRule(
                domain="example.com",
                video_patterns=[r"/watch/\d+"],
                pagination_patterns=[r"\?page=\d+"],
                pagination_text_patterns=[r"^Load More$"],
            )
        ],
        crawler=_FakeCrawler(result),
    )
    report = await resolver.resolve_with_report("https://example.com/videos")
    assert report.urls == ["https://example.com/watch/1"]
    assert report.matched_rule == "example.com"
    assert report.rule_filter_applied is True
    assert report.fallback_used is False
    assert report.crawler_method == "http"
    assert report.total_links_seen == 2


@pytest.mark.asyncio
async def test_site_rule_discovery_falls_back_to_generic_when_no_rule_matches():
    result = CrawlResult(
        all_links=[],
        pagination_links=[],
        non_pagination_links=[
            {
                "url": "https://example.com/watch/1",
                "text": "featured video",
                "index": 0,
            },
            {"url": "https://example.com/watch/2", "text": "clip", "index": 1},
        ],
        method="http",
    )
    resolver = SiteRuleDiscoveryResolver(
        site_rules=[SiteRule(domain="other.com", video_patterns=[r"/watch/\d+"])],
        crawler=_FakeCrawler(result),
    )
    links = await resolver.resolve("https://example.com/page")
    assert links == ["https://example.com/watch/1", "https://example.com/watch/2"]
