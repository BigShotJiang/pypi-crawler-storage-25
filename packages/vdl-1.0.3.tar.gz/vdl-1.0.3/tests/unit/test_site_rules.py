"""Tests for vdl.site_rules."""

from vdl.site_rules import SiteRule, load_site_rules


def test_site_rule_defaults():
    rule = SiteRule(domain="example.com")
    assert rule.domain == "example.com"
    assert rule.video_patterns == []
    assert rule.pagination_patterns == []
    assert rule.pagination_text_patterns == []
    assert rule.notes is None


def test_site_rule_with_values():
    rule = SiteRule(
        domain="example.com",
        video_patterns=["/watch/\\d+"],
        pagination_patterns=["\\?page=\\d+"],
        pagination_text_patterns=["^Load More$"],
        notes="Main video site",
    )
    assert rule.video_patterns == ["/watch/\\d+"]
    assert rule.pagination_patterns == ["\\?page=\\d+"]
    assert rule.pagination_text_patterns == ["^Load More$"]
    assert rule.notes == "Main video site"


def test_load_site_rules_missing_file(tmp_path):
    result = load_site_rules(tmp_path / "nonexistent.yaml")
    assert result == []


def test_load_site_rules_empty_file(tmp_path):
    f = tmp_path / "rules.yaml"
    f.write_text("")
    result = load_site_rules(f)
    assert result == []


def test_load_site_rules_dict_format(tmp_path):
    f = tmp_path / "rules.yaml"
    f.write_text(
        "example.com:\n"
        "  video_patterns:\n"
        "    - /watch/\\\\d+\n"
        "  pagination_patterns:\n"
        "    - \\?page=\\\\d+\n"
        "  pagination_text_patterns:\n"
        "    - ^Load More$\n"
    )
    rules = load_site_rules(f)
    assert len(rules) == 1
    assert rules[0].domain == "example.com"
    assert rules[0].video_patterns == ["/watch/\\\\d+"]
    assert rules[0].pagination_patterns == ["\\?page=\\\\d+"]
    assert rules[0].pagination_text_patterns == ["^Load More$"]


def test_load_site_rules_list_format(tmp_path):
    f = tmp_path / "rules.yaml"
    f.write_text(
        "- domain: example.com\n"
        "  video_patterns:\n"
        "    - /watch/\\\\d+\n"
        "  pagination_patterns:\n"
        "    - \\?page=\\\\d+\n"
    )
    rules = load_site_rules(f)
    assert len(rules) == 1
    assert rules[0].video_patterns == ["/watch/\\\\d+"]
    assert rules[0].pagination_patterns == ["\\?page=\\\\d+"]


def test_load_site_rules_supports_legacy_selector_fields(tmp_path):
    f = tmp_path / "rules.yaml"
    f.write_text(
        "- domain: example.com\n  selectors: .video-link\n  pagination:\n    - .next\n"
    )
    rules = load_site_rules(f)
    assert rules[0].video_patterns == [".video-link"]
    assert rules[0].pagination_patterns == [".next"]


def test_load_site_rules_skips_empty_domain(tmp_path):
    f = tmp_path / "rules.yaml"
    f.write_text("- domain: good.com\n- video_patterns:\n    - /watch\n")
    rules = load_site_rules(f)
    assert len(rules) == 1
    assert rules[0].domain == "good.com"
