"""Phase 2: Error hierarchy tests."""

import pytest

from vdl.errors import (
    VDLConfigError,
    VDLDependencyError,
    VDLDownloadError,
    VDLError,
    VDLInputError,
    VDLPlaylistError,
    VDLStateError,
)

ALL_ERROR_CLASSES = [
    VDLConfigError,
    VDLInputError,
    VDLDownloadError,
    VDLPlaylistError,
    VDLStateError,
    VDLDependencyError,
]


def test_vdl_error_is_exception():
    assert issubclass(VDLError, Exception)
    assert isinstance(VDLError(), Exception)


def test_all_errors_inherit_vdl_error():
    for cls in ALL_ERROR_CLASSES:
        assert issubclass(cls, VDLError), (
            f"{cls.__name__} does not inherit from VDLError"
        )
        assert isinstance(cls(), VDLError), f"{cls.__name__} instance is not a VDLError"


def test_vdl_config_error():
    with pytest.raises(VDLConfigError):
        raise VDLConfigError("bad config")


def test_vdl_input_error():
    with pytest.raises(VDLInputError):
        raise VDLInputError("bad input")


def test_vdl_download_error():
    with pytest.raises(VDLDownloadError):
        raise VDLDownloadError("download failed")


def test_vdl_playlist_error():
    with pytest.raises(VDLPlaylistError):
        raise VDLPlaylistError("playlist failed")


def test_vdl_state_error():
    with pytest.raises(VDLStateError):
        raise VDLStateError("state error")


def test_vdl_dependency_error():
    with pytest.raises(VDLDependencyError):
        raise VDLDependencyError("missing dependency")


def test_errors_caught_as_vdl_error():
    for cls in ALL_ERROR_CLASSES:
        with pytest.raises(VDLError):
            raise cls("test message")


def test_error_message_preserved():
    err = VDLConfigError("cannot load config at /path/to/config.toml")
    assert str(err) == "cannot load config at /path/to/config.toml"

    err2 = VDLDownloadError("HTTP 403 Forbidden")
    assert str(err2) == "HTTP 403 Forbidden"
