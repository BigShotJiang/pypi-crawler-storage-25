from __future__ import annotations

from pathlib import Path

import pytest

from support.fake_downloader import FakeDownloader
from support.fake_state_store import InMemoryStateStore
from vdl.client import VDLClient
from vdl.config import VDLConfig
from vdl.errors import VDLError
from vdl.models import PlaylistInfo, PlaylistItem
from vdl.tools import (
    download_video,
    download_video_sync,
    get_status,
    get_status_sync,
    plan_download,
    plan_download_sync,
    resolve_playlist,
    resolve_playlist_sync,
)


def _config(tmp_path: Path) -> VDLConfig:
    return VDLConfig(output_dir=tmp_path / "downloads")


class _FakePlaylistResolver:
    async def resolve(self, url: str) -> PlaylistInfo:
        return PlaylistInfo(
            url=url,
            title="My List",
            items=[PlaylistItem(url="https://x/1", id="1", index=0)],
        )


@pytest.mark.asyncio
async def test_download_video_returns_serialized_result(tmp_path):
    downloader = FakeDownloader()
    client = VDLClient(
        config=_config(tmp_path),
        downloader=downloader,
        state_store=InMemoryStateStore(),
    )
    out = await download_video(
        "https://example.com/v",
        write_thumbnail=True,
        write_subtitles=True,
        subtitle_langs="en fr",
        client=client,
    )
    assert out["status"] == "completed"
    assert out["url"] == "https://example.com/v"
    assert "metadata" in out
    request = downloader.calls[-1]
    assert request.write_thumbnail is True
    assert request.write_subtitles is True
    assert request.subtitle_langs == "en fr"


@pytest.mark.asyncio
async def test_plan_download_returns_structured_summary(tmp_path):
    client = VDLClient(
        config=_config(tmp_path),
        downloader=FakeDownloader(),
        state_store=InMemoryStateStore(),
    )
    out = await plan_download("https://youtube.com/watch?v=abc", client=client)
    assert out["total"] == 1
    assert out["source_kind"] == "video_url"
    assert out["items"][0]["url"] == "https://youtube.com/watch?v=abc"


@pytest.mark.asyncio
async def test_plan_download_echoes_request_sidecar_options(tmp_path):
    client = VDLClient(
        config=_config(tmp_path),
        downloader=FakeDownloader(),
        state_store=InMemoryStateStore(),
    )
    out = await plan_download(
        "https://youtube.com/watch?v=abc",
        write_thumbnail=True,
        write_subtitles=True,
        subtitle_langs="en,fr",
        client=client,
    )
    assert out["request_options"] == {
        "write_thumbnail": True,
        "write_subtitles": True,
        "subtitle_langs": "en,fr",
    }


@pytest.mark.asyncio
async def test_resolve_playlist_uses_serializer(tmp_path):
    client = VDLClient(
        config=_config(tmp_path),
        downloader=FakeDownloader(),
        playlist_resolver=_FakePlaylistResolver(),
        state_store=InMemoryStateStore(),
    )
    out = await resolve_playlist(
        "https://youtube.com/playlist?list=PL",
        client=client,
    )
    assert out["title"] == "My List"
    assert out["count"] == 1
    assert out["items"][0]["url"] == "https://x/1"


@pytest.mark.asyncio
async def test_get_status_returns_list_when_no_id(tmp_path):
    client = VDLClient(
        config=_config(tmp_path),
        downloader=FakeDownloader(),
        state_store=InMemoryStateStore(),
    )
    out = await get_status(client=client)
    assert out == []


def test_sync_wrappers_match_async_shape(tmp_path):
    downloader = FakeDownloader()
    client = VDLClient(
        config=_config(tmp_path),
        downloader=downloader,
        playlist_resolver=_FakePlaylistResolver(),
        state_store=InMemoryStateStore(),
    )

    download_out = download_video_sync("https://example.com/v", client=client)
    plan_out = plan_download_sync("https://example.com/v", client=client)
    playlist_out = resolve_playlist_sync(
        "https://youtube.com/playlist?list=PL",
        client=client,
    )
    status_out = get_status_sync(client=client)

    assert download_out["status"] == "completed"
    assert plan_out["source_kind"] == "video_url"
    assert playlist_out["count"] == 1
    assert isinstance(status_out, list)
    assert status_out[-1]["url"] == "https://example.com/v"


@pytest.mark.asyncio
async def test_sync_wrapper_raises_inside_running_loop(tmp_path):
    client = VDLClient(
        config=_config(tmp_path),
        downloader=FakeDownloader(),
        state_store=InMemoryStateStore(),
    )

    with pytest.raises(VDLError, match="active event loop"):
        download_video_sync("https://example.com/v", client=client)
