from __future__ import annotations

import pytest

from vdl import mcp_server


@pytest.mark.asyncio
async def test_mcp_download_video_delegates_to_tools(monkeypatch):
    captured = {}

    async def fake_download_video(url, **kwargs):
        captured["url"] = url
        captured.update(kwargs)
        return {"status": "completed", "url": url}

    monkeypatch.setattr(mcp_server, "download_video", fake_download_video)

    result = await mcp_server.download_video(
        "https://example.com/v",
        quality="best",
        client="sentinel-client",
    )

    assert result == {"status": "completed", "url": "https://example.com/v"}
    assert captured["url"] == "https://example.com/v"
    assert captured["quality"] == "best"
    assert captured["client"] == "sentinel-client"
