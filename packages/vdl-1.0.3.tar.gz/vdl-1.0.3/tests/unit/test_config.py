"""Phase 3: Config tests."""

from pathlib import Path

import pytest

from vdl.config import (
    TomlConfigStore,
    VDLConfig,
    load_config,
    save_config,
)
from vdl.errors import VDLConfigError
from vdl.paths import get_default_paths


def test_first_run_uses_default_site_rules_when_present(tmp_path, monkeypatch):
    cfg_home = tmp_path / "xdg-config"
    rules = cfg_home / "vdl" / "websites.yaml"
    rules.parent.mkdir(parents=True)
    rules.write_text("- domain: x.com\n")
    monkeypatch.setenv("XDG_CONFIG_HOME", str(cfg_home))
    config = load_config(tmp_path / "missing.toml")
    assert config.site_rules_path == rules


def test_first_run_no_site_rules_when_neither_present(tmp_path, monkeypatch):
    cfg_home = tmp_path / "xdg-config"
    cfg_home.mkdir()
    monkeypatch.setenv("XDG_CONFIG_HOME", str(cfg_home))
    config = load_config(tmp_path / "missing.toml")
    assert config.site_rules_path is None


def test_load_config_defaults_when_missing(tmp_path):
    config_path = tmp_path / "config.toml"
    assert not config_path.exists()
    config = load_config(config_path)
    assert isinstance(config, VDLConfig)
    assert config.default_quality == "best"
    assert config.audio_only is False
    assert config.max_concurrent_downloads == 3
    assert config.embed_metadata is True
    assert config.embed_thumbnail is True
    assert config.release_metadata_url is None
    assert isinstance(config.output_dir, Path)


def test_load_config_output_dir_is_path(tmp_path):
    config_path = tmp_path / "config.toml"
    config = load_config(config_path)
    assert isinstance(config.output_dir, Path)


def test_load_config_reads_existing_toml(tmp_path):
    config_path = tmp_path / "config.toml"
    config_path.write_text(
        'default_quality = "720p"\naudio_only = true\noutput_dir = "/tmp/vdl"\n',
        encoding="utf-8",
    )
    config = load_config(config_path)
    assert config.default_quality == "720p"
    assert config.audio_only is True
    assert config.output_dir == Path("/tmp/vdl")


def test_load_config_merges_missing_keys(tmp_path):
    config_path = tmp_path / "config.toml"
    config_path.write_text('default_quality = "480p"\n', encoding="utf-8")
    config = load_config(config_path)
    assert config.default_quality == "480p"
    assert config.embed_metadata is True
    assert config.max_concurrent_downloads == 3


def test_load_config_ignores_unknown_keys(tmp_path):
    config_path = tmp_path / "config.toml"
    config_path.write_text(
        'default_quality = "best"\nunknown_future_key = "ignored"\n',
        encoding="utf-8",
    )
    config = load_config(config_path)
    assert config.default_quality == "best"


def test_load_config_raises_on_bad_toml(tmp_path):
    config_path = tmp_path / "config.toml"
    config_path.write_text("this is not valid toml ][[\n", encoding="utf-8")
    with pytest.raises(VDLConfigError, match="Cannot load config"):
        load_config(config_path)


def test_save_config_creates_file(tmp_path):
    config_path = tmp_path / "subdir" / "config.toml"
    config = VDLConfig(output_dir=tmp_path / "downloads")
    save_config(config, config_path)
    assert config_path.exists()
    content = config_path.read_text()
    assert "output_dir" in content


def test_save_and_reload_roundtrip(tmp_path):
    config_path = tmp_path / "config.toml"
    original = VDLConfig(
        output_dir=tmp_path / "downloads",
        default_quality="720p",
        audio_only=False,
        max_concurrent_downloads=5,
        embed_metadata=True,
        embed_thumbnail=False,
    )
    save_config(original, config_path)
    reloaded = load_config(config_path)
    assert reloaded.output_dir == original.output_dir
    assert reloaded.default_quality == original.default_quality
    assert reloaded.audio_only == original.audio_only
    assert reloaded.max_concurrent_downloads == original.max_concurrent_downloads
    assert reloaded.embed_metadata == original.embed_metadata
    assert reloaded.embed_thumbnail == original.embed_thumbnail


# TomlConfigStore tests


def test_store_load_returns_config(tmp_path):
    config_path = tmp_path / "config.toml"
    config = VDLConfig(output_dir=tmp_path / "dl", default_quality="720p")
    save_config(config, config_path)
    store = TomlConfigStore(config_path)
    loaded = store.load()
    assert loaded.default_quality == "720p"


def test_store_load_caches_after_first_read(tmp_path):
    config_path = tmp_path / "config.toml"
    config = VDLConfig(output_dir=tmp_path / "dl", default_quality="720p")
    save_config(config, config_path)
    store = TomlConfigStore(config_path)
    first = store.load()
    # modify file on disk — cache should not reflect this
    config_path.write_text(
        config_path.read_text().replace("720p", "480p"), encoding="utf-8"
    )
    second = store.load()
    assert first is second
    assert second.default_quality == "720p"


def test_store_save_updates_cache(tmp_path):
    config_path = tmp_path / "config.toml"
    config = VDLConfig(output_dir=tmp_path / "dl", default_quality="best")
    store = TomlConfigStore(config_path)
    store.save(config)
    assert store.load().default_quality == "best"
    assert store._cache is config


def test_store_get_known_key(tmp_path):
    config_path = tmp_path / "config.toml"
    config = VDLConfig(output_dir=tmp_path / "dl", default_quality="1080p")
    save_config(config, config_path)
    store = TomlConfigStore(config_path)
    assert store.get("default_quality") == "1080p"


def test_store_get_unknown_key(tmp_path):
    store = TomlConfigStore(tmp_path / "config.toml")
    with pytest.raises(VDLConfigError, match="Unknown config key"):
        store.get("nonexistent_key")


def test_store_set_persists_and_updates_cache(tmp_path):
    config_path = tmp_path / "config.toml"
    config = VDLConfig(output_dir=tmp_path / "dl", default_quality="best")
    save_config(config, config_path)
    store = TomlConfigStore(config_path)
    store.set("default_quality", "480p")
    assert store._cache.default_quality == "480p"
    assert load_config(config_path).default_quality == "480p"


def test_store_set_does_not_affect_other_fields(tmp_path):
    config_path = tmp_path / "config.toml"
    config = VDLConfig(
        output_dir=tmp_path / "dl", default_quality="best", max_concurrent_downloads=5
    )
    save_config(config, config_path)
    store = TomlConfigStore(config_path)
    store.set("default_quality", "720p")
    assert store.get("default_quality") == "720p"
    assert store.get("max_concurrent_downloads") == 5


def test_store_set_unknown_key(tmp_path):
    store = TomlConfigStore(tmp_path / "config.toml")
    with pytest.raises(VDLConfigError, match="Unknown config key"):
        store.set("nonexistent_key", "value")
