from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from vdl.errors import VDLPlaylistError
from vdl.playlist import YtDlpPlaylistResolver

PLAYLIST_URL = "https://youtube.com/playlist?list=PL123"


def _mock_yt_dlp(entries: list[dict] | None = None, title: str = "Test Playlist"):
    mock_ydl = MagicMock()
    mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
    mock_ydl.__exit__ = MagicMock(return_value=False)
    default_entries = [
        {"url": "https://youtube.com/watch?v=a", "title": "Video A", "id": "a"},
        {"url": "https://youtube.com/watch?v=b", "title": "Video B", "id": "b"},
    ]
    mock_ydl.extract_info.return_value = {
        "title": title,
        "entries": entries if entries is not None else default_entries,
    }
    mock_module = MagicMock()
    mock_module.YoutubeDL.return_value = mock_ydl
    return mock_module


class TestYtDlpPlaylistResolver:
    async def test_resolve_returns_playlist_info(self):
        mock_module = _mock_yt_dlp()
        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            info = await resolver.resolve(PLAYLIST_URL)
        assert info.url == PLAYLIST_URL
        assert info.title == "Test Playlist"
        assert len(info.items) == 2

    async def test_items_have_correct_urls(self):
        mock_module = _mock_yt_dlp()
        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            info = await resolver.resolve(PLAYLIST_URL)
        assert info.items[0].url == "https://youtube.com/watch?v=a"
        assert info.items[1].url == "https://youtube.com/watch?v=b"

    async def test_items_have_indexes(self):
        mock_module = _mock_yt_dlp()
        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            info = await resolver.resolve(PLAYLIST_URL)
        assert info.items[0].index == 0
        assert info.items[1].index == 1

    async def test_no_info_raises_playlist_error(self):
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.return_value = None
        mock_module = MagicMock()
        mock_module.YoutubeDL.return_value = mock_ydl

        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            with pytest.raises(VDLPlaylistError):
                await resolver.resolve(PLAYLIST_URL)

    async def test_exception_raises_playlist_error(self):
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.side_effect = RuntimeError("connection failed")
        mock_module = MagicMock()
        mock_module.YoutubeDL.return_value = mock_ydl

        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            with pytest.raises(VDLPlaylistError, match="Playlist resolution failed"):
                await resolver.resolve(PLAYLIST_URL)

    async def test_import_error_raises_playlist_error(self):
        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": None}):
            with pytest.raises((VDLPlaylistError, ImportError, TypeError)):
                await resolver.resolve(PLAYLIST_URL)

    async def test_entries_without_url_skipped(self):
        entries = [
            {"url": "https://youtube.com/watch?v=a", "title": "A", "id": "a"},
            {"title": "No URL", "id": "b"},
        ]
        mock_module = _mock_yt_dlp(entries=entries)
        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            info = await resolver.resolve(PLAYLIST_URL)
        assert len(info.items) == 1

    async def test_empty_entries_returns_empty_items(self):
        mock_module = _mock_yt_dlp(entries=[])
        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            info = await resolver.resolve(PLAYLIST_URL)
        assert info.items == []

    async def test_inspect_url_detects_playlist(self):
        mock_module = _mock_yt_dlp()
        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            inspection = await resolver.inspect_url(PLAYLIST_URL)
        assert inspection.kind == "playlist"

    async def test_inspect_url_detects_playlist_member(self):
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.return_value = {
            "webpage_url": "https://example.com/watch/1",
            "playlist_title": "Series",
            "playlist_url": "https://example.com/series/1",
        }
        mock_module = MagicMock()
        mock_module.YoutubeDL.return_value = mock_ydl
        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            inspection = await resolver.inspect_url("https://example.com/watch/1")
        assert inspection.kind == "playlist_member"
        assert inspection.playlist_url == "https://example.com/series/1"

    async def test_inspect_url_detects_single(self):
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.return_value = {
            "webpage_url": "https://example.com/watch/1",
            "title": "Single",
        }
        mock_module = MagicMock()
        mock_module.YoutubeDL.return_value = mock_ydl
        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            inspection = await resolver.inspect_url("https://example.com/watch/1")
        assert inspection.kind == "single"

    async def test_inspect_url_returns_unknown_on_failure(self):
        mock_ydl = MagicMock()
        mock_ydl.__enter__ = MagicMock(return_value=mock_ydl)
        mock_ydl.__exit__ = MagicMock(return_value=False)
        mock_ydl.extract_info.side_effect = RuntimeError("boom")
        mock_module = MagicMock()
        mock_module.YoutubeDL.return_value = mock_ydl
        resolver = YtDlpPlaylistResolver()
        with patch.dict("sys.modules", {"yt_dlp": mock_module}):
            inspection = await resolver.inspect_url("https://example.com/watch/1")
        assert inspection.kind == "unsupported_or_unknown"
