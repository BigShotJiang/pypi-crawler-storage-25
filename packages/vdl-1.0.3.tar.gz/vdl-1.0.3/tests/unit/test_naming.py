"""Phase 5: Naming and output planning tests."""

from pathlib import Path

import pytest

from vdl.naming import (
    FilenamePlan,
    build_output_template,
    ensure_unique_path,
    plan_output_path,
    plan_playlist_directory,
    sanitize_filename,
    slugify_title,
)


# --- sanitize_filename ---


def test_sanitize_basic():
    assert sanitize_filename("The Boy Video.mp4") == "the-boy-video.mp4"


def test_sanitize_special_chars_removed():
    assert sanitize_filename("My Video (2024)!.mp4") == "my-video-2024.mp4"


def test_sanitize_underscores_removed_spaces_collapsed():
    assert (
        sanitize_filename("Test___Multiple   Spaces.mp4") == "test-multiple-spaces.mp4"
    )


def test_sanitize_hashtags_and_symbols_become_clean_slug():
    assert (
        sanitize_filename("No more next semester #michealokpara!!!.mp4")
        == "no-more-next-semester-michealokpara.mp4"
    )


def test_sanitize_uppercase_lowercased():
    assert sanitize_filename("UPPERCASE.MP4") == "uppercase.mp4"


def test_sanitize_extension_lowercased():
    assert sanitize_filename("video.MKV") == "video.mkv"


def test_sanitize_hyphens_deduplicated():
    assert sanitize_filename("a---b.mp4") == "a-b.mp4"


def test_sanitize_leading_trailing_hyphens_stripped():
    assert sanitize_filename("!video!.mp4") == "video.mp4"


def test_sanitize_empty_title_falls_back():
    assert sanitize_filename(".mp4") == "video.mp4"


def test_sanitize_no_extension():
    result = sanitize_filename("My Playlist")
    assert result == "my-playlist"


def test_sanitize_preserves_extension():
    result = sanitize_filename("video.webm")
    assert result.endswith(".webm")


def test_sanitize_output_stays_in_output_dir(tmp_path):
    # sanitize_filename should not add path separators
    result = sanitize_filename("../../etc/passwd.mp4")
    assert "/" not in result
    assert "\\" not in result


# --- build_output_template ---


def test_build_template_single_video(tmp_path):
    tmpl = build_output_template(tmp_path)
    assert tmpl["default"].endswith("%(title)s.%(ext)s")
    assert tmpl["thumbnail"].endswith("%(title)s.thumbnail.%(ext)s")
    assert tmpl["subtitle"].endswith("%(title)s.%(language)s.%(ext)s")
    assert str(tmp_path) in tmpl["default"]


def test_build_template_playlist_no_subdir(tmp_path):
    tmpl = build_output_template(tmp_path, playlist=True)
    assert "%(playlist_index)03d-%(title)s.%(ext)s" in tmpl["default"]
    assert "%(playlist_index)03d-%(title)s.thumbnail.%(ext)s" in tmpl["thumbnail"]
    assert "%(playlist_index)03d-%(title)s.%(language)s.%(ext)s" in tmpl["subtitle"]


def test_build_template_with_subdirectory(tmp_path):
    tmpl = build_output_template(tmp_path, subdirectory="My Series")
    assert "my-series" in tmpl["default"] or "My Series" in tmpl["default"]
    assert tmpl["default"].endswith("%(title)s.%(ext)s")


def test_build_template_subdirectory_creates_dir(tmp_path):
    build_output_template(tmp_path, subdirectory="New Show")
    # some sanitized form of the subdir should be created
    created = list(tmp_path.iterdir())
    assert len(created) == 1


def test_build_template_playlist_subdirectory_uses_prefix(tmp_path):
    tmpl = build_output_template(
        tmp_path,
        subdirectory="My Playlist",
        filename_prefix="007-",
    )
    assert "my-playlist" in tmpl["default"]
    assert tmpl["default"].endswith("007-%(title)s.%(ext)s")


# --- plan_output_path ---


def test_plan_output_path_basic(tmp_path):
    plan = plan_output_path("My Video", "mp4", tmp_path)
    assert isinstance(plan, FilenamePlan)
    assert plan.directory == tmp_path
    assert plan.final_path.parent == tmp_path
    assert plan.final_path.name == "my-video.mp4"
    assert plan.extension == ".mp4"
    assert plan.stem == "my-video"


def test_plan_output_path_extension_with_dot(tmp_path):
    plan = plan_output_path("Video", ".mkv", tmp_path)
    assert plan.final_path.suffix == ".mkv"


def test_plan_output_path_stays_in_output_dir(tmp_path):
    plan = plan_output_path("../../escape", "mp4", tmp_path)
    # final path must remain under output_dir
    assert plan.final_path.parent == tmp_path


def test_plan_output_path_empty_title(tmp_path):
    plan = plan_output_path("", "mp4", tmp_path)
    assert plan.final_path.name == "video.mp4"


# --- plan_playlist_directory ---


def test_plan_playlist_directory_basic(tmp_path):
    result = plan_playlist_directory("My Playlist", tmp_path)
    assert result.parent == tmp_path
    assert result.name == "my-playlist"


def test_plan_playlist_directory_sanitized(tmp_path):
    result = plan_playlist_directory("Best Of 2024!!!", tmp_path)
    assert result.parent == tmp_path
    assert "2024" in result.name


def test_plan_playlist_directory_empty_title(tmp_path):
    result = plan_playlist_directory("", tmp_path)
    assert result.name == "playlist"


def test_plan_playlist_directory_unsafe_title(tmp_path):
    result = plan_playlist_directory("!@#$%", tmp_path)
    assert result.parent == tmp_path
    assert result.name  # not empty


def test_slugify_title_applies_prefix():
    assert slugify_title("Hello World", prefix="001-") == "001-hello-world"


def test_ensure_unique_path_adds_numeric_suffix(tmp_path):
    original = tmp_path / "hello.mp4"
    original.write_text("x")
    result = ensure_unique_path(original)
    assert result.name == "hello-2.mp4"
