from __future__ import annotations

from pathlib import Path
import sqlite3

import pytest

from vdl.models import DownloadResult, DownloadStatus
from vdl.progress import DownloadProgress
from vdl.state import SQLiteStateStore

URL = "https://youtube.com/watch?v=abc123"
URL2 = "https://youtube.com/watch?v=xyz999"


@pytest.fixture
def store(tmp_path: Path) -> SQLiteStateStore:
    return SQLiteStateStore(db_path=tmp_path / "test.db")


class TestInit:
    def test_creates_db_file(self, tmp_path):
        db_path = tmp_path / "state.db"
        SQLiteStateStore(db_path=db_path)
        assert db_path.exists()

    def test_creates_parent_dirs(self, tmp_path):
        db_path = tmp_path / "nested" / "deep" / "state.db"
        SQLiteStateStore(db_path=db_path)
        assert db_path.exists()

    def test_migrates_pre_request_key_database(self, tmp_path):
        db_path = tmp_path / "legacy.db"
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                """
                CREATE TABLE downloads (
                    id TEXT PRIMARY KEY,
                    source_url TEXT NOT NULL,
                    command TEXT NOT NULL,
                    status TEXT NOT NULL,
                    output_path TEXT,
                    error TEXT,
                    percent REAL,
                    speed TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX idx_downloads_source_url
                ON downloads(source_url)
                """
            )
            conn.commit()
        finally:
            conn.close()

        store = SQLiteStateStore(db_path=db_path)

        conn = sqlite3.connect(db_path)
        try:
            columns = {
                row[1]
                for row in conn.execute("PRAGMA table_info(downloads)").fetchall()
            }
            indexes = {
                row[1]
                for row in conn.execute("PRAGMA index_list(downloads)").fetchall()
            }
        finally:
            conn.close()

        assert "request_key" in columns
        assert "quality" in columns
        assert "idx_downloads_request_key" in indexes
        store.record_started("id-1", URL, "download")


class TestRecordStarted:
    def test_creates_record(self, store):
        store.record_started("id-1", URL, "download")
        rec = store.get_status("id-1")
        assert rec is not None
        assert rec.id == "id-1"
        assert rec.source_url == URL
        assert rec.status == DownloadStatus.STARTING

    def test_url_findable(self, store):
        store.record_started("id-1", URL, "download")
        rec = store.find_by_url(URL)
        assert rec is not None


class TestRecordProgress:
    def test_updates_percent(self, store):
        store.record_started("id-1", URL, "download")
        progress = DownloadProgress(
            id="id-1", status=DownloadStatus.DOWNLOADING, percent=55.0
        )
        store.record_progress(progress, URL, "download")
        rec = store.get_status("id-1")
        assert rec.status == DownloadStatus.DOWNLOADING
        assert rec.percent == 55.0


class TestRecordCompleted:
    def test_marks_completed(self, store):
        store.record_started("id-1", URL, "download")
        result = DownloadResult(
            id="id-1",
            source_url=URL,
            status=DownloadStatus.COMPLETED,
            output_path=Path("/downloads/video.mp4"),
        )
        store.record_completed(result)
        rec = store.get_status("id-1")
        assert rec.status == DownloadStatus.COMPLETED
        assert rec.output_path == Path("/downloads/video.mp4")

    def test_without_prior_started(self, store):
        result = DownloadResult(
            id="id-new",
            source_url=URL,
            status=DownloadStatus.COMPLETED,
        )
        store.record_completed(result)
        rec = store.get_status("id-new")
        assert rec is not None
        assert rec.status == DownloadStatus.COMPLETED


class TestRecordFailed:
    def test_marks_failed(self, store):
        store.record_started("id-1", URL, "download")
        store.record_failed("id-1", URL, "timeout")
        rec = store.get_status("id-1")
        assert rec.status == DownloadStatus.FAILED
        assert rec.error == "timeout"


class TestFindByUrl:
    def test_returns_none_for_unknown(self, store):
        assert store.find_by_url("https://nothere.com") is None

    def test_finds_started(self, store):
        store.record_started("id-1", URL, "download")
        rec = store.find_by_url(URL)
        assert rec is not None and rec.id == "id-1"

    def test_finds_most_recent_for_url(self, store):
        store.record_started("id-1", URL, "download")
        store.record_failed("id-1", URL, "first attempt failed")
        store.record_started("id-2", URL, "download")
        store.record_completed(
            DownloadResult(id="id-2", source_url=URL, status=DownloadStatus.COMPLETED)
        )
        rec = store.find_by_url(URL)
        assert rec.id == "id-2"


class TestGetStatus:
    def test_returns_none_for_missing(self, store):
        assert store.get_status("nonexistent") is None

    def test_returns_record(self, store):
        store.record_started("id-1", URL, "download")
        rec = store.get_status("id-1")
        assert rec is not None


class TestListRecent:
    def test_empty_returns_empty(self, store):
        assert store.list_recent() == []

    def test_returns_all(self, store):
        store.record_started("id-1", URL, "download")
        store.record_started("id-2", URL2, "download")
        records = store.list_recent()
        assert len(records) == 2

    def test_limit_respected(self, store):
        for i in range(5):
            store.record_started(f"id-{i}", f"https://example.com/{i}", "download")
        records = store.list_recent(limit=3)
        assert len(records) == 3

    def test_default_limit_20(self, store):
        for i in range(25):
            store.record_started(f"id-{i}", f"https://example.com/{i}", "download")
        records = store.list_recent()
        assert len(records) == 20


class TestRowToRecord:
    def test_output_path_is_path_object(self, store):
        result = DownloadResult(
            id="id-1",
            source_url=URL,
            status=DownloadStatus.COMPLETED,
            output_path=Path("/some/path/video.mp4"),
        )
        store.record_completed(result)
        rec = store.get_status("id-1")
        assert isinstance(rec.output_path, Path)

    def test_null_output_path_is_none(self, store):
        store.record_started("id-1", URL, "download")
        rec = store.get_status("id-1")
        assert rec.output_path is None

    def test_updated_at_is_datetime(self, store):
        from datetime import datetime

        store.record_started("id-1", URL, "download")
        rec = store.get_status("id-1")
        assert isinstance(rec.updated_at, datetime)
