"""Test isolation: redirect XDG dirs to a temp location so we never read or
write the real user's `~/.config/vdl` or legacy `~/.config/video-downloader`."""

from __future__ import annotations

import os
import tempfile

import pytest


@pytest.fixture(autouse=True)
def _isolate_xdg_paths(monkeypatch, tmp_path_factory):
    isolated = tmp_path_factory.mktemp("xdg")
    monkeypatch.setenv("XDG_CONFIG_HOME", str(isolated / "config"))
    monkeypatch.setenv("XDG_STATE_HOME", str(isolated / "state"))
    monkeypatch.setenv("XDG_CACHE_HOME", str(isolated / "cache"))
    yield
