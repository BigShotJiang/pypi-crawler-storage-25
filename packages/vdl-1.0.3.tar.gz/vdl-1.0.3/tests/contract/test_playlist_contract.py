from __future__ import annotations

import pytest

from support.fake_downloader import FakeDownloader
from support.fake_playlist_resolver import FakePlaylistResolver
from vdl.models import DownloadStatus, InputKind, PlaylistItem
from vdl.playlist import (
    download_playlist,
    playlist_items_to_requests,
    resolve_playlist,
)
from vdl.selection import PlaylistSelection

PLAYLIST_URL = "https://youtube.com/playlist?list=PL123"


class TestFakePlaylistResolver:
    async def test_resolve_returns_playlist_info(self):
        resolver = FakePlaylistResolver()
        info = await resolver.resolve(PLAYLIST_URL)
        assert info.url == PLAYLIST_URL
        assert info.title == "Fake Playlist"
        assert len(info.items) > 0

    async def test_default_two_items(self):
        resolver = FakePlaylistResolver()
        info = await resolver.resolve(PLAYLIST_URL)
        assert len(info.items) == 2

    async def test_custom_items(self):
        items = [PlaylistItem(url="https://youtube.com/watch?v=x", index=0)]
        resolver = FakePlaylistResolver(items=items, title="Custom")
        info = await resolver.resolve(PLAYLIST_URL)
        assert len(info.items) == 1
        assert info.title == "Custom"

    async def test_records_calls(self):
        resolver = FakePlaylistResolver()
        await resolver.resolve(PLAYLIST_URL)
        assert resolver.calls == [PLAYLIST_URL]

    async def test_raises_preset_error(self):
        resolver = FakePlaylistResolver(error=ValueError("playlist error"))
        with pytest.raises(ValueError, match="playlist error"):
            await resolver.resolve(PLAYLIST_URL)


class TestResolvePLaylist:
    async def test_delegates_to_resolver(self):
        resolver = FakePlaylistResolver()
        info = await resolve_playlist(PLAYLIST_URL, resolver)
        assert info.url == PLAYLIST_URL


class TestPlaylistItemsToRequests:
    async def test_all_selected_by_default(self):
        resolver = FakePlaylistResolver()
        info = await resolver.resolve(PLAYLIST_URL)
        requests = playlist_items_to_requests(info)
        assert len(requests) == len(info.items)
        assert requests[0].playlist is True
        assert requests[0].subdirectory == "Fake Playlist"
        assert requests[0].filename_prefix == "000-"

    async def test_selected_indexes_filters(self):
        items = [
            PlaylistItem(url=f"https://youtube.com/watch?v={i}", index=i)
            for i in range(5)
        ]
        resolver = FakePlaylistResolver(items=items)
        info = await resolver.resolve(PLAYLIST_URL)
        requests = playlist_items_to_requests(info, selected_indexes=[0, 2])
        assert len(requests) == 2

    async def test_unselected_items_excluded(self):
        items = [
            PlaylistItem(url="https://youtube.com/watch?v=a", index=0, selected=True),
            PlaylistItem(url="https://youtube.com/watch?v=b", index=1, selected=False),
        ]
        resolver = FakePlaylistResolver(items=items)
        info = await resolver.resolve(PLAYLIST_URL)
        requests = playlist_items_to_requests(info)
        assert len(requests) == 1
        assert requests[0].source.raw == "https://youtube.com/watch?v=a"
        assert requests[0].filename_prefix == "000-"


class TestPlaylistItemsToRequestsWithSelection:
    def _make_items(self, count: int) -> list[PlaylistItem]:
        return [
            PlaylistItem(url=f"https://youtube.com/watch?v={i}", index=i)
            for i in range(count)
        ]

    def test_playlist_selection_all(self):
        from vdl.models import PlaylistInfo

        items = self._make_items(3)
        info = PlaylistInfo(url="https://youtube.com/playlist", title="P", items=items)
        sel = PlaylistSelection(mode="all")
        reqs = playlist_items_to_requests(info, sel)
        assert len(reqs) == 3

    def test_playlist_selection_first_n(self):
        from vdl.models import PlaylistInfo

        items = self._make_items(5)
        info = PlaylistInfo(url="https://youtube.com/playlist", title="P", items=items)
        sel = PlaylistSelection(mode="first_n", first_n=2)
        reqs = playlist_items_to_requests(info, sel)
        assert len(reqs) == 2

    def test_playlist_selection_indexes(self):
        from vdl.models import PlaylistInfo

        items = self._make_items(5)
        info = PlaylistInfo(url="https://youtube.com/playlist", title="P", items=items)
        sel = PlaylistSelection(mode="indexes", indexes=frozenset({0, 2, 4}))
        reqs = playlist_items_to_requests(info, sel)
        assert len(reqs) == 3

    def test_list_int_still_works(self):
        from vdl.models import PlaylistInfo

        items = self._make_items(5)
        info = PlaylistInfo(url="https://youtube.com/playlist", title="P", items=items)
        reqs = playlist_items_to_requests(info, [0, 2])
        assert len(reqs) == 2


class TestDownloadPlaylist:
    async def test_downloads_all_items(self):
        resolver = FakePlaylistResolver()
        downloader = FakeDownloader()
        results = await download_playlist(PLAYLIST_URL, resolver, downloader)
        assert len(results) == 2
        assert all(r.status == DownloadStatus.COMPLETED for r in results)

    async def test_empty_playlist(self):
        resolver = FakePlaylistResolver(items=[])
        downloader = FakeDownloader()
        results = await download_playlist(PLAYLIST_URL, resolver, downloader)
        assert results == []

    async def test_on_progress_forwarded(self):
        received = []
        resolver = FakePlaylistResolver()
        downloader = FakeDownloader()
        await download_playlist(
            PLAYLIST_URL, resolver, downloader, on_progress=received.append
        )
        assert len(received) == 2
