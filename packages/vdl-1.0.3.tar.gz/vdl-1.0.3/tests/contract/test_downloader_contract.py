from __future__ import annotations

from pathlib import Path

import pytest

from support.fake_downloader import FakeDownloader
from vdl.downloader import download_many, download_one
from vdl.models import DownloadRequest, DownloadStatus, InputKind, SourceInput

URL_A = "https://youtube.com/watch?v=aaa"
URL_B = "https://youtube.com/watch?v=bbb"


def _req(url: str) -> DownloadRequest:
    return DownloadRequest(source=SourceInput(raw=url, kind=InputKind.VIDEO_URL))


class TestFakeDownloader:
    async def test_default_returns_completed(self):
        dl = FakeDownloader()
        result = await dl.download(_req(URL_A))
        assert result.status == DownloadStatus.COMPLETED

    async def test_default_returns_fake_path(self):
        dl = FakeDownloader()
        result = await dl.download(_req(URL_A))
        assert result.output_path is not None

    async def test_preset_result(self):
        dl = FakeDownloader(results={URL_A: (DownloadStatus.FAILED, None)})
        result = await dl.download(_req(URL_A))
        assert result.status == DownloadStatus.FAILED
        assert result.output_path is None

    async def test_records_calls(self):
        dl = FakeDownloader()
        req = _req(URL_A)
        await dl.download(req)
        assert dl.calls == [req]

    async def test_on_progress_called(self):
        received = []
        dl = FakeDownloader()
        await dl.download(_req(URL_A), on_progress=received.append)
        assert len(received) == 1
        assert received[0].status == DownloadStatus.COMPLETED

    async def test_result_url_matches_request(self):
        dl = FakeDownloader()
        result = await dl.download(_req(URL_A))
        assert result.source_url == URL_A

    async def test_result_has_id(self):
        dl = FakeDownloader()
        result = await dl.download(_req(URL_A))
        assert result.id and len(result.id) > 0


class TestDownloadOne:
    async def test_delegates_to_downloader(self):
        dl = FakeDownloader()
        req = _req(URL_A)
        result = await download_one(req, dl)
        assert result.status == DownloadStatus.COMPLETED
        assert dl.calls == [req]


class TestDownloadMany:
    async def test_empty_returns_empty(self):
        dl = FakeDownloader()
        assert await download_many([], dl) == []

    async def test_downloads_all_requests(self):
        dl = FakeDownloader()
        reqs = [_req(URL_A), _req(URL_B)]
        results = await download_many(reqs, dl)
        assert len(results) == 2
        assert len(dl.calls) == 2

    async def test_results_preserve_order(self):
        dl = FakeDownloader(
            results={
                URL_A: (DownloadStatus.COMPLETED, Path("/a.mp4")),
                URL_B: (DownloadStatus.FAILED, None),
            }
        )
        results = await download_many([_req(URL_A), _req(URL_B)], dl)
        assert results[0].status == DownloadStatus.COMPLETED
        assert results[1].status == DownloadStatus.FAILED
