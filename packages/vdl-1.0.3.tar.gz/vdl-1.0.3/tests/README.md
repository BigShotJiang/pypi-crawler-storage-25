# Tests

Tests will be added brick by brick. Start with import tests, then config/paths, URL analysis, naming, fake downloader, and fake playlist resolver.

Keep the first checks lightweight and focused on package imports and interface boundaries.
