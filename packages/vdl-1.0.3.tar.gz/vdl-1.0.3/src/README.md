# Source

The rebuilt lightweight VDL library will live here.

Planned scope:
- Python API
- headless CLI mode
- Rich-based interactive CLI mode
- yt-dlp wrapper with clean defaults
- playlist resolution and download helpers

No implementation has been added yet.
