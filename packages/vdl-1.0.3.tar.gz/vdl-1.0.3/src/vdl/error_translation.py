"""Translate raw yt-dlp / network errors into actionable user messages.

The downloader passes raw exception strings here. We keep the original
text available via :class:`TranslatedError.raw` for logs, while the
``message`` field is what gets shown to the user. ``category`` lets
callers branch on classes of failure (e.g. show a "resume" hint when the
internet dropped).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

ErrorCategory = Literal[
    "network_lost",
    "impersonation_missing",
    "auth",
    "extractor",
    "unknown",
]

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def strip_ansi(text: str) -> str:
    """Remove ANSI color escape sequences from a string."""
    return _ANSI_RE.sub("", text)


@dataclass(frozen=True)
class TranslatedError:
    """User-facing translation of a downloader error.

    Attributes:
        category: Coarse classification used for follow-up actions.
        message: Short, terminal-friendly error message.
        hint: Optional one-line remediation hint.
        raw: Original error string (ANSI-stripped) for logging.
    """

    category: ErrorCategory
    message: str
    hint: str | None
    raw: str

    @property
    def display(self) -> str:
        """The full message to show the user (one or two lines)."""
        if self.hint:
            return f"{self.message}\n  Hint: {self.hint}"
        return self.message


_NETWORK_PATTERNS = (
    r"connection broken",
    r"connection reset",
    r"ConnectionResetError",
    r"name (or service )?not known",
    r"temporary failure in name resolution",
    r"network is unreachable",
    r"no route to host",
    r"timed? out",
    r"connection aborted",
    r"unreachable network",
)
_IMPERSONATION_PATTERNS = (
    r"attempting impersonation",
    r"impersonate targets are available",
    r"impersonation",
)


def translate_error(error: str) -> TranslatedError:
    """Classify a raw error string and produce a user-facing message.

    Args:
        error: Raw error string (may include ANSI codes).

    Returns:
        TranslatedError with category, message, optional hint, and raw text.
    """
    raw = strip_ansi(error or "").strip()
    lower = raw.lower()

    if any(re.search(p, lower, re.IGNORECASE) for p in _NETWORK_PATTERNS):
        return TranslatedError(
            category="network_lost",
            message="Network error: connection lost while downloading.",
            hint=(
                "Re-run the same URL once you're back online — already "
                "completed items will be skipped."
            ),
            raw=raw,
        )

    if any(re.search(p, lower, re.IGNORECASE) for p in _IMPERSONATION_PATTERNS):
        from vdl.impersonation import probe_impersonation

        check = probe_impersonation()
        if check.status == "version_mismatch":
            message = (
                "This site requires browser impersonation, but yt-dlp and "
                "curl-cffi are version-incompatible on this install."
            )
            hint = (
                f"yt-dlp says: {check.detail}. Re-sync the project to pull a "
                "compatible curl-cffi: `task sync` (or `uv sync --frozen --dev`)."
            )
        elif check.status == "missing":
            message = (
                "This site requires browser impersonation, but curl-cffi "
                "isn't installed."
            )
            hint = "Install with `task sync` (or `uv sync --frozen --dev`)."
        else:
            message = (
                "This site requires browser impersonation, but the required "
                "backend isn't available."
            )
            hint = (
                "Re-sync the project: `task sync` (or "
                "`uv sync --frozen --dev`). If the problem persists, run "
                "`vdl doctor` for details."
            )
        return TranslatedError(
            category="impersonation_missing",
            message=message,
            hint=hint,
            raw=raw,
        )

    return TranslatedError(
        category="unknown",
        message=raw or "Download failed.",
        hint=None,
        raw=raw,
    )
