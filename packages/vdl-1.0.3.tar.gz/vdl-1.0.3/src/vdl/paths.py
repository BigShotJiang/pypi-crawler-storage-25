"""XDG-compliant default paths and path resolution utilities.

VDL respects XDG base directory specification on Linux/macOS and falls back
to sensible defaults when environment variables are not set. This module
provides helpers for discovering and resolving all required paths.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse


@dataclass(frozen=True)
class VDLPaths:
    """All standard paths used by VDL.

    Attributes:
        config_dir: Configuration directory (~/.config/vdl).
        config_file: Main config file (config_dir/config.toml).
        site_rules_file: Site rules YAML (config_dir/websites.yaml).
        state_dir: State directory (~/.local/state/vdl).
        state_db: SQLite database path (state_dir/vdl.db).
        cache_dir: Cache directory (~/.cache/vdl).
        logs_dir: Logs directory (state_dir/logs).
        downloads_dir: Default downloads destination (~/Downloads/VDL).
    """

    config_dir: Path
    config_file: Path
    site_rules_file: Path
    state_dir: Path
    state_db: Path
    cache_dir: Path
    logs_dir: Path
    downloads_dir: Path


@dataclass(frozen=True)
class OutputPathResolution:
    """Result of resolving a requested output path.

    Attributes:
        requested_path: Path user requested.
        active_path: Path that will actually be used.
        used_fallback: Whether fallback was triggered.
        warning: Warning message if fallback was used.
    """

    requested_path: Path | None
    active_path: Path
    used_fallback: bool
    warning: str | None = None


def get_default_paths() -> VDLPaths:
    """Get all default VDL paths respecting XDG environment variables.

    Uses XDG_CONFIG_HOME, XDG_STATE_HOME, XDG_CACHE_HOME if set, otherwise
    falls back to ~/.config, ~/.local/state, ~/.cache respectively.

    Returns:
        VDLPaths with all standard directories.
    """
    home = Path.home()
    xdg_config_home = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config"))
    config_dir = xdg_config_home / "vdl"
    state_dir = (
        Path(os.environ.get("XDG_STATE_HOME", home / ".local" / "state")) / "vdl"
    )
    cache_dir = Path(os.environ.get("XDG_CACHE_HOME", home / ".cache")) / "vdl"

    return VDLPaths(
        config_dir=config_dir,
        config_file=config_dir / "config.toml",
        site_rules_file=config_dir / "websites.yaml",
        state_dir=state_dir,
        state_db=state_dir / "vdl.db",
        cache_dir=cache_dir,
        logs_dir=state_dir / "logs",
        downloads_dir=home / "Downloads" / "VDL",
    )


def resolve_site_rules_path(
    explicit: Path | None = None,
    paths: VDLPaths | None = None,
) -> Path | None:
    """Resolve site-rules YAML path.

    Checks in order:
      1. Explicit override (config.toml site_rules_path).
      2. Default ~/.config/vdl/websites.yaml.

    Returns the first existing path, or None if none exist. Callers that
    want a packaged-default fallback should consult
    :func:`bundled_site_rules_path` separately.
    """
    if explicit is not None:
        return explicit if explicit.exists() else explicit
    paths = paths or get_default_paths()
    if paths.site_rules_file.exists():
        return paths.site_rules_file
    return None


def bundled_site_rules_path() -> Path | None:
    """Path to the websites.yaml bundled with the VDL package, if any."""
    candidate = Path(__file__).parent / "data" / "websites.yaml"
    return candidate if candidate.exists() else None


def find_cookie_file_for(url: str, paths: VDLPaths | None = None) -> Path | None:
    """Return the best matching cookies file in the config dir for ``url``.

    Looks for files named like ``<host>_cookies.txt`` (legacy convention)
    first, then any single ``cookies.txt`` as a fallback. Returns None if
    nothing applicable is on disk — callers should fall through silently.
    """
    config_dir = getattr(paths, "config_dir", None) if paths is not None else None
    if config_dir is None:
        config_dir = get_default_paths().config_dir
    if not config_dir.exists():
        return None
    host = urlparse(url).netloc.lower().lstrip(".")
    if host.startswith("www."):
        host = host[4:]
    candidates = sorted(config_dir.glob("*cookies*.txt"))
    for candidate in candidates:
        name = candidate.name.lower()
        if host and host in name:
            return candidate
    for candidate in candidates:
        if candidate.name.lower() == "cookies.txt":
            return candidate
    return None


def find_default_cookie_file(paths: VDLPaths | None = None) -> Path | None:
    """Return the most likely default cookies file in the config dir.

    Used by callers that need a single cookies file at startup (e.g. the
    crawler) without a specific target URL.
    """
    config_dir = getattr(paths, "config_dir", None) if paths is not None else None
    if config_dir is None:
        config_dir = get_default_paths().config_dir
    if not config_dir.exists():
        return None
    direct = config_dir / "cookies.txt"
    if direct.exists():
        return direct
    candidates = sorted(config_dir.glob("*cookies*.txt"))
    return candidates[0] if candidates else None


def ensure_paths(paths: VDLPaths | None = None) -> VDLPaths:
    """Create all necessary VDL directories.

    Args:
        paths: VDLPaths to ensure; defaults to get_default_paths().

    Returns:
        The passed or default VDLPaths after directories are created.

    Raises:
        OSError: If directory creation fails.
    """
    paths = paths or get_default_paths()
    for directory in (
        paths.config_dir,
        paths.state_dir,
        paths.logs_dir,
        paths.cache_dir,
        paths.downloads_dir,
    ):
        directory.mkdir(parents=True, exist_ok=True)
    return paths


def resolve_output_dir(requested_path: str | Path | None) -> OutputPathResolution:
    """Resolve a requested output directory with fallback.

    If requested path is invalid or unwritable, falls back to default
    downloads directory. Returns information about the resolution.

    Args:
        requested_path: Path requested by user, or None for default.

    Returns:
        OutputPathResolution with active_path and fallback status.
    """
    if requested_path:
        candidate = _normalize_path(requested_path)
        if _is_writable_dir(candidate):
            return OutputPathResolution(
                requested_path=candidate,
                active_path=candidate,
                used_fallback=False,
            )
        fallback = _prepare_fallback_dir()
        return OutputPathResolution(
            requested_path=candidate,
            active_path=fallback,
            used_fallback=True,
            warning=(
                f"Output directory '{candidate}' is unavailable or not writable. "
                f"Using '{fallback}' for this run."
            ),
        )

    fallback = _prepare_fallback_dir()
    return OutputPathResolution(
        requested_path=None,
        active_path=fallback,
        used_fallback=False,
    )


def _normalize_path(path: str | Path) -> Path:
    """Normalize a path string by expanding ~ and resolving to absolute.

    Args:
        path: Path with possible ~ or relative components.

    Returns:
        Absolute resolved path.
    """
    raw = str(path).strip("\"'").strip()
    expanded = os.path.expanduser(raw)
    return Path(expanded).resolve()


def _prepare_fallback_dir() -> Path:
    """Prepare and return the default fallback output directory.

    Returns:
        Default downloads directory, ensured to exist and be writable.
    """
    fallback = get_default_paths().downloads_dir
    _ensure_writable_dir(fallback)
    return fallback


def _is_writable_dir(path: Path) -> bool:
    """Check if a directory exists and is writable.

    Args:
        path: Directory path to check.

    Returns:
        True if directory is writable, False otherwise.
    """
    try:
        _ensure_writable_dir(path)
        return True
    except OSError:
        return False


def _ensure_writable_dir(path: Path) -> None:
    """Create directory if needed and verify it is writable.

    Args:
        path: Directory to create/verify.

    Raises:
        OSError: If directory cannot be created or is not writable.
    """
    path.mkdir(parents=True, exist_ok=True)
    probe = path / ".vdl-write-test"
    probe.write_text("ok", encoding="utf-8")
    probe.unlink()
