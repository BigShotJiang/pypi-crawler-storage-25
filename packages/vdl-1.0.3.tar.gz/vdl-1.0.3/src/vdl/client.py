from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal

DiscoveryStatusCallback = Callable[[str, dict[str, Any]], None]

from vdl.acquisition import AcquisitionItem, AcquisitionPlan, DiscoveryResolver
from vdl.cancellation import (
    CancellationController,
    CancellationToken,
    CompositeCancellationToken,
)
from vdl.config import ConfigStore, TomlConfigStore, VDLConfig
from vdl.doctor import Doctor
from vdl.downloader import Downloader
from vdl.errors import VDLError
from vdl.input_parser import parse_link_file, tokenize_raw_input
from vdl.logging import Logger, NullLogger
from vdl.models import (
    BatchSummary,
    build_request_key,
    DoctorReport,
    DownloadResult,
    DownloadStatus,
    InputKind,
    PlaylistInfo,
    Quality,
    SourceInput,
    StatusRecord,
)
from vdl.playlist import (
    PlaylistInspection,
    PlaylistResolver,
    playlist_items_to_requests,
)
from vdl.progress import ProgressCallback
from vdl.selection import PlaylistSelection, selection_to_indexes
from vdl.state import ReconciliationReport, StateStore, reconcile_status_records


@dataclass(frozen=True)
class InteractiveUrlInspection:
    """Outcome of classifying a URL during interactive mode."""

    kind: Literal["playlist", "playlist_member", "single", "unsupported_or_unknown"]
    playlist_url: str | None = None
    entry_url: str | None = None
    reason: str | None = None


class VDLClient:
    """High-level orchestration API for downloads, playlists, and status."""

    def __init__(
        self,
        config: VDLConfig | None = None,
        config_store: ConfigStore | None = None,
        downloader: Downloader | None = None,
        playlist_resolver: PlaylistResolver | None = None,
        state_store: StateStore | None = None,
        doctor_service: Doctor | None = None,
        discovery_resolver: DiscoveryResolver | None = None,
        logger: Logger | None = None,
    ) -> None:
        bare = (
            config is None
            and config_store is None
            and downloader is None
            and playlist_resolver is None
            and state_store is None
            and doctor_service is None
        )
        if bare:
            from vdl.runtime import build_default_components

            c = build_default_components()
            config = c.config
            config_store = c.config_store
            downloader = c.downloader
            playlist_resolver = c.playlist_resolver
            state_store = c.state_store
            doctor_service = c.doctor_service
            if discovery_resolver is None:
                discovery_resolver = c.discovery_resolver
        self.config_store = config_store or TomlConfigStore()
        self.config = config if config is not None else self.config_store.load()
        self.downloader = downloader
        self.playlist_resolver = playlist_resolver
        self.state_store = state_store
        self.doctor_service = doctor_service
        self.logger = logger or NullLogger()
        if discovery_resolver is None:
            from vdl.crawler import SiteRuleDiscoveryResolver
            from vdl.paths import bundled_site_rules_path, resolve_site_rules_path
            from vdl.site_rules import load_site_rules

            rules_path = (
                resolve_site_rules_path(self.config.site_rules_path)
                or bundled_site_rules_path()
            )
            if rules_path is not None and rules_path.exists():
                rules = load_site_rules(rules_path)
                self.discovery_resolver: DiscoveryResolver | None = (
                    SiteRuleDiscoveryResolver(
                        site_rules=rules,
                        logger=self.logger,
                    )
                )
            else:
                self.discovery_resolver = None
        else:
            self.discovery_resolver = discovery_resolver

    async def inspect_url(self, url: str) -> InteractiveUrlInspection:
        from vdl.urls import analyze_input

        analysis = analyze_input(url)
        if not analysis.is_supported:
            return InteractiveUrlInspection(
                kind="unsupported_or_unknown",
                reason=analysis.reason,
            )
        if analysis.kind == InputKind.PLAYLIST_URL:
            return InteractiveUrlInspection(kind="playlist", playlist_url=url)
        if analysis.kind == InputKind.VIDEO_URL and analysis.is_ambiguous:
            return InteractiveUrlInspection(
                kind="playlist_member",
                playlist_url=url,
                entry_url=url,
                reason=analysis.reason,
            )
        if self.playlist_resolver is None:
            return InteractiveUrlInspection(kind="single", entry_url=url)

        inspect_url = getattr(self.playlist_resolver, "inspect_url", None)
        if inspect_url is None:
            return InteractiveUrlInspection(kind="single", entry_url=url)

        try:
            inspection: PlaylistInspection = await inspect_url(url)
        except Exception:
            return InteractiveUrlInspection(kind="single", entry_url=url)

        if inspection.kind == "playlist":
            return InteractiveUrlInspection(
                kind="playlist",
                playlist_url=inspection.playlist_url or url,
                entry_url=inspection.entry_url or url,
            )
        if inspection.kind == "playlist_member":
            return InteractiveUrlInspection(
                kind="playlist_member",
                playlist_url=inspection.playlist_url or url,
                entry_url=inspection.entry_url or url,
            )
        if inspection.kind == "unsupported_or_unknown":
            return InteractiveUrlInspection(kind="single", entry_url=url)
        return InteractiveUrlInspection(
            kind="single",
            entry_url=inspection.entry_url or url,
        )

    async def inspect_url_for_interactive(self, url: str) -> InteractiveUrlInspection:
        """Backward-compatible alias for interactive callers."""
        return await self.inspect_url(url)

    async def download(
        self,
        url: str,
        output_dir: Path | None = None,
        quality: Quality = Quality.BEST,
        on_progress: ProgressCallback | None = None,
        force: bool = False,
        cancel_token: CancellationToken | None = None,
        write_thumbnail: bool | None = None,
        write_subtitles: bool | None = None,
        subtitle_langs: str | None = None,
    ) -> DownloadResult:
        request = self._build_download_request(
            url,
            output_dir=output_dir,
            quality=quality,
            force=force,
            write_thumbnail=write_thumbnail,
            write_subtitles=write_subtitles,
            subtitle_langs=subtitle_langs,
        )
        return await self._execute_download_request(
            request,
            on_progress=on_progress,
            cancel_token=cancel_token,
        )

    def _build_download_request(
        self,
        url: str,
        *,
        output_dir: Path | None,
        quality: Quality,
        force: bool,
        write_thumbnail: bool | None,
        write_subtitles: bool | None,
        subtitle_langs: str | None,
    ):
        from vdl.models import DownloadRequest
        from vdl.urls import analyze_input

        analysis = analyze_input(url)
        source = SourceInput(
            raw=url, kind=analysis.kind, normalized=analysis.normalized
        )
        effective_dir = output_dir or self.config.output_dir
        return DownloadRequest(
            source=source,
            output_dir=effective_dir,
            quality=quality,
            force=force,
            write_thumbnail=write_thumbnail,
            write_subtitles=write_subtitles,
            subtitle_langs=subtitle_langs,
        )

    async def _execute_download_request(
        self,
        request,
        *,
        on_progress: ProgressCallback | None = None,
        cancel_token: CancellationToken | None = None,
    ) -> DownloadResult:
        if self.downloader is None:
            raise VDLError("No downloader configured")

        url = request.source.raw
        quality = request.quality
        request_key = build_request_key(url, quality)

        if self.state_store and not request.force:
            existing = await asyncio.to_thread(
                self.state_store.find_by_request, url, quality
            )
            if (
                existing
                and existing.status == DownloadStatus.COMPLETED
                and existing.output_path is not None
                and existing.output_path.exists()
            ):
                self.logger.info(
                    "download.skipped", url=url, reason="already completed"
                )
                return DownloadResult(
                    id=existing.id,
                    source_url=url,
                    status=DownloadStatus.SKIPPED,
                    quality=quality,
                    request_key=request_key,
                    output_path=existing.output_path,
                    skipped_reason="already completed",
                )

        download_id = str(uuid.uuid4())
        effective_dir = request.output_dir or self.config.output_dir
        self.logger.info("download.started", url=url, output_dir=str(effective_dir))

        if self.state_store:
            await asyncio.to_thread(
                self.state_store.record_started,
                download_id,
                url,
                "download",
                quality=quality,
                request_key=request_key,
            )

        result = await self.downloader.download(
            request,
            on_progress=on_progress,
            cancel_token=cancel_token,
        )

        result = DownloadResult(
            id=download_id,
            source_url=result.source_url,
            status=result.status,
            quality=quality,
            request_key=request_key,
            output_path=result.output_path,
            error=result.error,
            skipped_reason=result.skipped_reason,
            metadata=result.metadata,
        )

        if self.state_store:
            if result.status == DownloadStatus.COMPLETED:
                await asyncio.to_thread(self.state_store.record_completed, result)
            elif result.status == DownloadStatus.CANCELLED:
                await asyncio.to_thread(
                    self.state_store.record_cancelled,
                    download_id,
                    url,
                    quality=quality,
                    request_key=request_key,
                )
                self.logger.info("download.cancelled", url=url)
            elif result.status == DownloadStatus.FAILED:
                await asyncio.to_thread(
                    self.state_store.record_failed,
                    download_id,
                    url,
                    result.error or "unknown error",
                    quality=quality,
                    request_key=request_key,
                )

        if result.status == DownloadStatus.COMPLETED:
            self.logger.info(
                "download.completed",
                url=url,
                output_path=str(result.output_path) if result.output_path else None,
            )
        elif result.status == DownloadStatus.FAILED:
            self.logger.warning(
                "download.failed", url=url, error=result.error or "unknown error"
            )

        return result

    async def resolve_playlist(self, url: str) -> PlaylistInfo:
        if self.playlist_resolver is None:
            raise VDLError("No playlist resolver configured")
        info = await self.playlist_resolver.resolve(url)
        self.logger.info("playlist.resolved", url=url, total=len(info.items))
        return info

    async def download_playlist(
        self,
        url: str,
        output_dir: Path | None = None,
        on_progress: ProgressCallback | None = None,
        force: bool = False,
        cancel_token: CancellationToken | None = None,
    ) -> list[DownloadResult]:
        if self.playlist_resolver is None:
            raise VDLError("No playlist resolver configured")
        if self.downloader is None:
            raise VDLError("No downloader configured")
        return await self.download_playlist_with_selection(
            url,
            None,
            output_dir=output_dir,
            on_progress=on_progress,
            force=force,
            cancel_token=cancel_token,
        )

    async def download_playlist_with_selection(
        self,
        url: str,
        selection: PlaylistSelection | list[int] | None = None,
        output_dir: Path | None = None,
        on_progress: ProgressCallback | None = None,
        force: bool = False,
        cancel_token: CancellationToken | None = None,
        quality: Quality = Quality.BEST,
        write_thumbnail: bool | None = None,
        write_subtitles: bool | None = None,
        subtitle_langs: str | None = None,
        controller: CancellationController | None = None,
    ) -> list[DownloadResult]:
        if self.playlist_resolver is None:
            raise VDLError("No playlist resolver configured")
        if self.downloader is None:
            raise VDLError("No downloader configured")
        info = await self.playlist_resolver.resolve(url)
        effective_dir = output_dir or self.config.output_dir
        requests = playlist_items_to_requests(
            info,
            selection,
            output_dir=effective_dir,
            quality=quality,
            force=force,
            write_thumbnail=write_thumbnail,
            write_subtitles=write_subtitles,
            subtitle_langs=subtitle_langs,
        )
        if self.config.max_playlist_items is not None:
            requests = requests[: self.config.max_playlist_items]
        sem = asyncio.Semaphore(self.config.max_concurrent_downloads)

        async def _run(req):
            async with sem:
                if cancel_token is not None and cancel_token.is_cancelled:
                    return DownloadResult(
                        id="",
                        source_url=req.source.raw,
                        status=DownloadStatus.CANCELLED,
                    )
                effective_token = self._compose_task_token(
                    req, cancel_token, controller
                )
                try:
                    return await self._execute_download_request(
                        req,
                        on_progress=on_progress,
                        cancel_token=effective_token,
                    )
                finally:
                    if controller is not None:
                        controller.unregister(req.source.raw)

        return list(await asyncio.gather(*[_run(req) for req in requests]))

    def _compose_task_token(
        self,
        request,
        cancel_token: CancellationToken | None,
        controller: CancellationController | None,
    ):
        """Build the per-task cancellation token observed by the downloader.

        When a controller is provided, register a per-task token keyed by
        the request URL and compose it with the plan-level token so the
        downloader can be cancelled targeted-by-task or globally.
        """
        if controller is None:
            return cancel_token
        label = request.source_title or request.source.raw
        per_task = controller.register(request.source.raw, label)
        if cancel_token is None:
            return per_task
        return CompositeCancellationToken(cancel_token, per_task)

    async def _items_from_url_list(
        self,
        urls: list[str],
        output_dir: Path,
        quality: Quality,
        force: bool,
    ) -> tuple[list[AcquisitionItem], dict]:
        """
        Build acquisition items for a list of URLs, preserving source order.

        When expand_nested_playlists is enabled and a playlist resolver is
        configured, playlist URLs are flattened into VIDEO items and origin
        metadata is recorded. Otherwise playlist URLs become a single
        is_playlist=True item to be resolved at execution time.
        """
        from vdl.urls import analyze_input

        max_items = self.config.max_playlist_items
        expand = (
            self.config.expand_nested_playlists and self.playlist_resolver is not None
        )

        items: list[AcquisitionItem] = []
        expansions: list[dict] = []
        for origin_url in urls:
            kind = analyze_input(origin_url).kind
            if kind == InputKind.PLAYLIST_URL and expand:
                start_idx = len(items)
                try:
                    info = await self.playlist_resolver.resolve(origin_url)
                except Exception as e:
                    self.logger.warning(
                        "plan.expand.failed", url=origin_url, error=str(e)
                    )
                    items.append(
                        AcquisitionItem(
                            source_url=origin_url,
                            output_dir=output_dir,
                            quality=quality,
                            force=force,
                            is_playlist=True,
                        )
                    )
                    continue
                child_urls = [it.url for it in info.items if it.url]
                if max_items is not None:
                    child_urls = child_urls[:max_items]
                for child in child_urls:
                    items.append(
                        AcquisitionItem(
                            source_url=child,
                            output_dir=output_dir,
                            quality=quality,
                            force=force,
                        )
                    )
                expansions.append(
                    {
                        "origin_url": origin_url,
                        "kind": "playlist",
                        "expanded_count": len(child_urls),
                        "start_index": start_idx,
                        "end_index": start_idx + len(child_urls),
                        "truncated": (
                            max_items is not None and len(info.items) > max_items
                        ),
                    }
                )
            else:
                items.append(
                    AcquisitionItem(
                        source_url=origin_url,
                        output_dir=output_dir,
                        quality=quality,
                        force=force,
                        is_playlist=(kind == InputKind.PLAYLIST_URL),
                    )
                )

        metadata: dict = {}
        if expansions:
            metadata["expansions"] = expansions
        return items, metadata

    async def plan(
        self,
        raw_input: str,
        output_dir: Path | None = None,
        quality: Quality = Quality.BEST,
        force: bool = False,
    ) -> AcquisitionPlan:
        from vdl.urls import analyze_input

        effective_dir = output_dir or self.config.output_dir

        # Detect multi-URL strings (comma- or space-separated) before classify
        if raw_input.count("http://") + raw_input.count("https://") > 1:
            tokens = tokenize_raw_input(raw_input)
            if len(tokens) > 1:
                items, metadata = await self._items_from_url_list(
                    tokens, effective_dir, quality, force
                )
                plan = AcquisitionPlan(
                    items=items,
                    source_kind=InputKind.UNKNOWN,
                    total=len(items),
                    metadata=metadata,
                )
                self.logger.info(
                    "plan.created",
                    raw_input=raw_input,
                    source_kind=plan.source_kind.value,
                    total=plan.total,
                )
                return plan

        analysis = analyze_input(raw_input)

        if analysis.kind == InputKind.LOCAL_LINK_FILE:
            path = Path(analysis.normalized or raw_input)
            urls = parse_link_file(path)
            items, metadata = await self._items_from_url_list(
                urls, effective_dir, quality, force
            )
            plan = AcquisitionPlan(
                items=items,
                source_kind=analysis.kind,
                total=len(items),
                metadata=metadata,
            )
            self.logger.info(
                "plan.created",
                raw_input=raw_input,
                source_kind=plan.source_kind.value,
                total=plan.total,
            )
            return plan

        if analysis.kind == InputKind.PLAYLIST_URL:
            items = [
                AcquisitionItem(
                    source_url=raw_input,
                    output_dir=effective_dir,
                    quality=quality,
                    force=force,
                    is_playlist=True,
                )
            ]
            plan = AcquisitionPlan(items=items, source_kind=analysis.kind, total=1)
            self.logger.info(
                "plan.created",
                raw_input=raw_input,
                source_kind=plan.source_kind.value,
                total=plan.total,
            )
            return plan

        if analysis.kind == InputKind.VIDEO_URL and analysis.is_ambiguous:
            self.logger.info("input.ambiguous", url=raw_input, reason=analysis.reason)
            items = [
                AcquisitionItem(
                    source_url=raw_input,
                    output_dir=effective_dir,
                    quality=quality,
                    force=force,
                )
            ]
            plan = AcquisitionPlan(
                items=items,
                source_kind=analysis.kind,
                total=1,
                metadata={"is_ambiguous": True, "reason": analysis.reason},
            )
            self.logger.info(
                "plan.created",
                raw_input=raw_input,
                source_kind=plan.source_kind.value,
                total=plan.total,
            )
            return plan

        # Unknown / non-known-platform URLs are treated as direct video URLs
        # by default. The user can fall back to crawling explicitly via
        # ``discover()`` if the download fails — this keeps ``plan()`` cheap
        # (no network) and avoids surprise crawls on URLs yt-dlp can handle.
        if analysis.kind == InputKind.UNKNOWN:
            plan = AcquisitionPlan(
                items=[],
                source_kind=InputKind.UNKNOWN,
                total=0,
                metadata={"is_supported": False},
            )
            self.logger.info(
                "plan.created",
                raw_input=raw_input,
                source_kind=plan.source_kind.value,
                total=plan.total,
            )
            return plan

        items = [
            AcquisitionItem(
                source_url=raw_input,
                output_dir=effective_dir,
                quality=quality,
                force=force,
            )
        ]
        plan = AcquisitionPlan(items=items, source_kind=analysis.kind, total=1)
        self.logger.info(
            "plan.created",
            raw_input=raw_input,
            source_kind=plan.source_kind.value,
            total=plan.total,
        )
        return plan

    async def plan_with_probe(
        self,
        raw_input: str,
        output_dir: Path | None = None,
        quality: Quality = Quality.BEST,
        force: bool = False,
    ) -> AcquisitionPlan:
        """Create a plan using optional remote playlist/member inspection.

        This is an explicit, opt-in alternative to ``plan()`` for callers that
        want cross-site ``yt-dlp`` intent resolution. Multi-URL strings and
        link files still defer to the cheap planner.
        """
        if raw_input.count("http://") + raw_input.count("https://") > 1:
            return await self.plan(
                raw_input,
                output_dir=output_dir,
                quality=quality,
                force=force,
            )

        from vdl.urls import analyze_input

        analysis = analyze_input(raw_input)
        if analysis.kind in {
            InputKind.LOCAL_LINK_FILE,
            InputKind.LOCAL_MEDIA_FILE,
            InputKind.UNKNOWN,
        }:
            return await self.plan(
                raw_input,
                output_dir=output_dir,
                quality=quality,
                force=force,
            )

        inspection = await self.inspect_url(raw_input)
        effective_dir = output_dir or self.config.output_dir

        if inspection.kind == "playlist":
            return AcquisitionPlan(
                items=[
                    AcquisitionItem(
                        source_url=inspection.playlist_url or raw_input,
                        output_dir=effective_dir,
                        quality=quality,
                        force=force,
                        is_playlist=True,
                    )
                ],
                source_kind=InputKind.PLAYLIST_URL,
                total=1,
                metadata={"resolved_remotely": True},
            )

        if inspection.kind == "playlist_member":
            return AcquisitionPlan(
                items=[
                    AcquisitionItem(
                        source_url=raw_input,
                        output_dir=effective_dir,
                        quality=quality,
                        force=force,
                    )
                ],
                source_kind=InputKind.VIDEO_URL,
                total=1,
                metadata={
                    "is_ambiguous": True,
                    "playlist_url": inspection.playlist_url or raw_input,
                    "resolved_remotely": True,
                    "reason": (
                        "video may be part of a playlist or collection — pass --playlist to download all"
                    ),
                },
            )

        return await self.plan(
            raw_input,
            output_dir=output_dir,
            quality=quality,
            force=force,
        )

    async def discover(
        self,
        url: str,
        output_dir: Path | None = None,
        quality: Quality = Quality.BEST,
        force: bool = False,
        on_status: DiscoveryStatusCallback | None = None,
    ) -> AcquisitionPlan:
        """Run the discovery crawler on a URL and return a candidate plan.

        Used by interactive callers as a "the download failed, try crawling
        for video links instead" fallback. Raises VDLError when no discovery
        resolver is configured.

        Args:
            url: Source URL to crawl.
            output_dir: Optional output directory for the resulting plan items.
            quality: Quality preset for items in the produced plan.
            force: Whether to mark items as force-redownload.
            on_status: Optional callback invoked at discovery lifecycle stages
                (``"started"``, ``"crawling"``, ``"completed"``, ``"failed"``)
                with a metadata dict (``url``, ``total``, ``error``, etc.).
        """
        if self.discovery_resolver is None:
            raise VDLError("No discovery resolver configured")
        effective_dir = output_dir or self.config.output_dir

        def _emit(stage: str, **meta: Any) -> None:
            if on_status is not None:
                try:
                    on_status(stage, {"url": url, **meta})
                except Exception:
                    self.logger.warning("discovery.on_status.error", stage=stage)

        self.logger.info("discovery.started", url=url)
        _emit("started")

        from vdl.crawler import SiteRuleDiscoveryResolver

        discovery_metadata: dict = {
            "discovered": True,
            "selection_kind": "candidate_list",
        }
        try:
            _emit("crawling")
            if isinstance(self.discovery_resolver, SiteRuleDiscoveryResolver):
                report = await self.discovery_resolver.resolve_with_report(url)
                discovered = report.urls
                discovery_metadata["discovery"] = {
                    "matched_rule": report.matched_rule,
                    "rule_filter_applied": report.rule_filter_applied,
                    "crawler_method": report.crawler_method,
                    "total_links_seen": report.total_links_seen,
                    "fallback_used": report.fallback_used,
                }
            else:
                discovered = await self.discovery_resolver.resolve(url)
        except Exception as exc:
            _emit("failed", error=str(exc))
            raise
        items = [
            AcquisitionItem(
                source_url=u, output_dir=effective_dir, quality=quality, force=force
            )
            for u in discovered
        ]
        plan = AcquisitionPlan(
            items=items,
            source_kind=InputKind.URL,
            total=len(items),
            metadata=discovery_metadata,
        )
        self.logger.info("discovery.finished", url=url, total=len(items))
        _emit("completed", total=len(items))
        return plan

    def select_plan_items(
        self,
        plan: AcquisitionPlan,
        selection: PlaylistSelection | list[int],
    ) -> AcquisitionPlan:
        if isinstance(selection, PlaylistSelection):
            indexes = selection_to_indexes(selection, len(plan.items))
        else:
            indexes = [i for i in selection if 0 <= i < len(plan.items)]
        items = [plan.items[i] for i in indexes]
        return AcquisitionPlan(
            items=items,
            source_kind=plan.source_kind,
            total=len(items),
            metadata=plan.metadata,
        )

    def plan_requires_choice(
        self,
        plan: AcquisitionPlan,
    ) -> Literal[
        "none", "ambiguous_playlist", "playlist_selection", "discovered_selection"
    ]:
        if plan.metadata.get("is_ambiguous"):
            return "ambiguous_playlist"
        if plan.metadata.get("discovered") and plan.total > 0:
            return "discovered_selection"
        if plan.source_kind == InputKind.PLAYLIST_URL:
            return "playlist_selection"
        return "none"

    async def execute_plan(
        self,
        plan: AcquisitionPlan,
        *,
        selection: PlaylistSelection | list[int] | None = None,
        prefer_playlist: bool = False,
        on_progress: ProgressCallback | None = None,
        cancel_token: CancellationToken | None = None,
        write_thumbnail: bool | None = None,
        write_subtitles: bool | None = None,
        subtitle_langs: str | None = None,
        controller: CancellationController | None = None,
    ) -> list[DownloadResult]:
        choice = self.plan_requires_choice(plan)

        if choice == "ambiguous_playlist":
            if prefer_playlist:
                if not plan.items:
                    return []
                playlist_url = (
                    plan.metadata.get("playlist_url") or plan.items[0].source_url
                )
                results = await self.download_playlist_with_selection(
                    playlist_url,
                    selection,
                    output_dir=plan.items[0].output_dir,
                    on_progress=on_progress,
                    force=plan.items[0].force,
                    cancel_token=cancel_token,
                    quality=plan.items[0].quality,
                    write_thumbnail=write_thumbnail,
                    write_subtitles=write_subtitles,
                    subtitle_langs=subtitle_langs,
                    controller=controller,
                )
                self.logger.info(
                    "plan.executed",
                    source_kind=plan.source_kind.value,
                    total=len(results),
                )
                return results
            results = await self.download_plan(
                plan,
                on_progress=on_progress,
                cancel_token=cancel_token,
                write_thumbnail=write_thumbnail,
                write_subtitles=write_subtitles,
                subtitle_langs=subtitle_langs,
                controller=controller,
            )
            self.logger.info(
                "plan.executed", source_kind=plan.source_kind.value, total=len(results)
            )
            return results

        if choice == "playlist_selection":
            if not plan.items:
                return []
            results = await self.download_playlist_with_selection(
                plan.items[0].source_url,
                selection,
                output_dir=plan.items[0].output_dir,
                on_progress=on_progress,
                force=plan.items[0].force,
                cancel_token=cancel_token,
                quality=plan.items[0].quality,
                write_thumbnail=write_thumbnail,
                write_subtitles=write_subtitles,
                subtitle_langs=subtitle_langs,
                controller=controller,
            )
            self.logger.info(
                "plan.executed", source_kind=plan.source_kind.value, total=len(results)
            )
            return results

        if choice == "discovered_selection" and selection is not None:
            plan = self.select_plan_items(plan, selection)

        results = await self.download_plan(
            plan,
            on_progress=on_progress,
            cancel_token=cancel_token,
            write_thumbnail=write_thumbnail,
            write_subtitles=write_subtitles,
            subtitle_langs=subtitle_langs,
            controller=controller,
        )
        self.logger.info(
            "plan.executed", source_kind=plan.source_kind.value, total=len(results)
        )
        return results

    async def download_plan(
        self,
        plan: AcquisitionPlan,
        on_progress: ProgressCallback | None = None,
        cancel_token: CancellationToken | None = None,
        write_thumbnail: bool | None = None,
        write_subtitles: bool | None = None,
        subtitle_langs: str | None = None,
        controller: CancellationController | None = None,
    ) -> list[DownloadResult]:
        sem = asyncio.Semaphore(self.config.max_concurrent_downloads)

        async def _run(item: AcquisitionItem):
            async with sem:
                if cancel_token is not None and cancel_token.is_cancelled:
                    return DownloadResult(
                        id="",
                        source_url=item.source_url,
                        status=DownloadStatus.CANCELLED,
                    )
                if item.is_playlist:
                    return await self.download_playlist_with_selection(
                        item.source_url,
                        None,
                        output_dir=item.output_dir,
                        on_progress=on_progress,
                        force=item.force,
                        cancel_token=cancel_token,
                        quality=item.quality,
                        write_thumbnail=write_thumbnail,
                        write_subtitles=write_subtitles,
                        subtitle_langs=subtitle_langs,
                        controller=controller,
                    )
                effective_token: CancellationToken | None = cancel_token
                if controller is not None:
                    per_task = controller.register(item.source_url, item.source_url)
                    effective_token = (
                        per_task
                        if cancel_token is None
                        else CompositeCancellationToken(cancel_token, per_task)
                    )
                try:
                    return await self.download(
                        item.source_url,
                        output_dir=item.output_dir,
                        quality=item.quality,
                        on_progress=on_progress,
                        force=item.force,
                        cancel_token=effective_token,
                        write_thumbnail=write_thumbnail,
                        write_subtitles=write_subtitles,
                        subtitle_langs=subtitle_langs,
                    )
                finally:
                    if controller is not None:
                        controller.unregister(item.source_url)

        gathered = await asyncio.gather(*[_run(item) for item in plan.items])
        flat: list[DownloadResult] = []
        for r in gathered:
            if isinstance(r, list):
                flat.extend(r)
            else:
                flat.append(r)
        return flat

    async def execute_batch(
        self,
        plan: AcquisitionPlan,
        *,
        selection: PlaylistSelection | list[int] | None = None,
        prefer_playlist: bool = False,
        on_progress: ProgressCallback | None = None,
        cancel_token: CancellationToken | None = None,
        write_thumbnail: bool | None = None,
        write_subtitles: bool | None = None,
        subtitle_langs: str | None = None,
    ) -> BatchSummary:
        results = await self.execute_plan(
            plan,
            selection=selection,
            prefer_playlist=prefer_playlist,
            on_progress=on_progress,
            cancel_token=cancel_token,
            write_thumbnail=write_thumbnail,
            write_subtitles=write_subtitles,
            subtitle_langs=subtitle_langs,
        )
        summary = BatchSummary.from_results(results)
        self.logger.info(
            "batch.summary",
            total=summary.total,
            completed=len(summary.completed),
            skipped=len(summary.skipped),
            failed=len(summary.failed),
        )
        return summary

    async def status(
        self, id: str | None = None
    ) -> StatusRecord | list[StatusRecord] | None:
        if self.state_store is None:
            return [] if id is None else None
        if id:
            return await asyncio.to_thread(self.state_store.get_status, id)
        return await asyncio.to_thread(self.state_store.list_recent)

    async def reconcile_status(
        self,
        id: str | None = None,
        limit: int = 20,
    ) -> ReconciliationReport:
        if self.state_store is None:
            return ReconciliationReport(entries=[])
        if id:
            record = await asyncio.to_thread(self.state_store.get_status, id)
            records = [record] if record is not None else []
        else:
            records = await asyncio.to_thread(self.state_store.list_recent, limit)
        return reconcile_status_records(records, logger=self.logger)

    async def doctor(self) -> DoctorReport:
        svc = self.doctor_service or Doctor()
        return await asyncio.to_thread(svc.run)
