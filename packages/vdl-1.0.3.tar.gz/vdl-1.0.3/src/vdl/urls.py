"""Input analysis and classification.

Identifies input types (URLs, playlists, files) and normalizes them.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from vdl.models import InputKind

#: File extensions recognized as link files.
_LOCAL_LINK_EXTENSIONS = (".txt", ".list", ".urls")
#: File extensions recognized as media files.
_LOCAL_MEDIA_EXTENSIONS = (".mp4", ".mkv", ".mov", ".avi", ".webm")
_COLLECTION_QUERY_KEYS = {
    "album",
    "collection",
    "list",
    "mix",
    "playlist",
    "season",
    "series",
    "set",
    "showcase",
}
_ITEM_PATH_PATTERNS = (
    r"/clip(?:s)?(?:/|$)",
    r"/episode(?:s)?(?:/|$)",
    r"/p/[a-z0-9_-]+/?$",
    r"/post(?:s)?(?:/|$)",
    r"/reel(?:s)?(?:/|$)",
    r"/shorts(?:/|$)",
    r"/status/\d+",
    r"/track(?:s)?(?:/|$)",
    r"/video(?:s)?(?:/|$)",
    r"/watch(?:/|$)",
)
_COLLECTION_PATH_PATTERNS = (
    r"/album(?:s)?(?:/|$)",
    r"/collection(?:s)?(?:/|$)",
    r"/playlist(?:s)?(?:/|$)",
    r"/season(?:s)?(?:/|$)",
    r"/series(?:/|$)",
    r"/sets?(?:/|$)",
    r"/showcase(?:/|$)",
)


@dataclass(frozen=True)
class UrlAnalysis:
    """Result of analyzing user input.

    Attributes:
        raw: Original input string.
        kind: Classified input type.
        normalized: Canonical form (normalized URL or resolved path).
        is_supported: Whether VDL can handle this input.
        is_ambiguous: Whether input could be interpreted multiple ways.
        reason: If unsupported or ambiguous, explanation.
    """

    raw: str
    kind: InputKind
    normalized: str | None = None
    is_supported: bool = False
    is_ambiguous: bool = False
    reason: str | None = None


def analyze_input(value: str) -> UrlAnalysis:
    """Classify and analyze user input.

    Detects input type (URL, playlist, file, etc.) and returns detailed analysis.

    Args:
        value: User input string.

    Returns:
        UrlAnalysis with classification and normalization.
    """
    cleaned = value.strip("\"'").strip()

    if not cleaned:
        return UrlAnalysis(raw=value, kind=InputKind.UNKNOWN, reason="empty input")

    if is_local_link_file(cleaned):
        return UrlAnalysis(
            raw=value,
            kind=InputKind.LOCAL_LINK_FILE,
            normalized=cleaned,
            is_supported=True,
        )

    if _is_local_media_file(cleaned):
        return UrlAnalysis(
            raw=value,
            kind=InputKind.LOCAL_MEDIA_FILE,
            normalized=cleaned,
            is_supported=True,
        )

    parsed = urlparse(cleaned)
    if not (parsed.scheme and parsed.netloc):
        return UrlAnalysis(
            raw=value,
            kind=InputKind.UNKNOWN,
            reason="not a valid URL or recognized local path",
        )

    if is_playlist_url(cleaned):
        return UrlAnalysis(
            raw=value,
            kind=InputKind.PLAYLIST_URL,
            normalized=normalize_url(cleaned),
            is_supported=True,
        )

    is_mix = _is_mix_url(cleaned)
    if is_video_url(cleaned):
        return UrlAnalysis(
            raw=value,
            kind=InputKind.VIDEO_URL,
            normalized=normalize_url(cleaned),
            is_supported=True,
            is_ambiguous=is_mix,
            reason="video may be part of a playlist or collection — pass --playlist to download all"
            if is_mix
            else None,
        )

    return UrlAnalysis(
        raw=value,
        kind=InputKind.URL,
        normalized=normalize_url(cleaned),
        is_supported=True,
    )


def is_supported_url(value: str) -> bool:
    """Check if value is a valid URL with scheme and netloc.

    Args:
        value: String to check.

    Returns:
        True if it is a valid URL.
    """
    cleaned = value.strip("\"'").strip()
    parsed = urlparse(cleaned)
    return bool(parsed.scheme and parsed.netloc)


def is_playlist_url(value: str) -> bool:
    """Detect if URL points to a playlist.

    Recognizes standard playlist patterns across platforms
    (YouTube, Vimeo, SoundCloud, etc).

    Args:
        value: URL string.

    Returns:
        True if URL is a playlist.
    """
    cleaned = value.strip()
    parsed = urlparse(cleaned)
    netloc = parsed.netloc.lower()
    path = parsed.path.lower()
    query = parsed.query.lower()

    # YouTube: explicit playlist pages and multi-video aggregates.
    # /watch_videos?video_ids=... is an anonymous on-the-fly playlist
    # made of several video IDs; /show/VL... wraps a regular PL playlist.
    if "youtube.com" in netloc:
        if "/playlist" in path or "/view_playlist" in path:
            return True
        if "/watch_videos" in path and "video_ids=" in query:
            return True
        if path.startswith("/show/") or "/show/vl" in path:
            return True
        # list= with no specific video selected = pure playlist
        if "list=" in query and "v=" not in query:
            return True

    # youtu.be with only a list param and no video path segment
    if "youtu.be" in netloc:
        if not path.strip("/") and "list=" in query:
            return True

    # Vimeo: showcase or album collection
    if "vimeo.com" in netloc:
        if re.search(r"/showcase/\d+", path) or re.search(r"/album/\d+", path):
            return True

    # Dailymotion: playlist page
    if "dailymotion.com" in netloc:
        if "/playlist/" in path:
            return True

    # SoundCloud: sets are playlists
    if "soundcloud.com" in netloc:
        if "/sets/" in path:
            return True

    # Generic: /playlist(s)/ or /collection(s)/ path segment on any platform
    if re.search(r"/playlists?(?:/|$)", path) or re.search(
        r"/collections?(?:/|$)", path
    ):
        return True

    return False


def is_video_url(value: str) -> bool:
    """Detect if URL is a video (not a playlist).

    Args:
        value: URL string.

    Returns:
        True if URL is recognized as a video URL.
    """
    cleaned = value.strip()
    parsed = urlparse(cleaned)
    if not (parsed.scheme and parsed.netloc):
        return False
    return not is_playlist_url(cleaned)


def is_local_link_file(value: str | Path) -> bool:
    """Check if value is a readable text file containing URLs.

    Recognizes .txt, .list, .urls extensions or readable text files.

    Args:
        value: Path or filename.

    Returns:
        True if it's a local link file.
    """
    cleaned = str(value).strip("\"'").strip()
    if cleaned.lower().endswith(_LOCAL_LINK_EXTENSIONS):
        return True
    expanded = os.path.realpath(os.path.expanduser(cleaned))
    return (
        os.path.exists(expanded)
        and not os.path.isdir(expanded)
        and _is_readable_text(expanded)
    )


def normalize_url(value: str) -> str:
    """Normalize URL by stripping quotes and whitespace.

    Args:
        value: URL string.

    Returns:
        Stripped URL.
    """
    return value.strip("\"'").strip()


def youtube_video_id(value: str) -> str | None:
    """Extract a YouTube video id (the ``v=`` parameter or youtu.be path).

    Returns None when the URL is not a YouTube watch/short link or no id
    is present. The value is returned verbatim with no validation.
    """
    cleaned = value.strip()
    parsed = urlparse(cleaned)
    netloc = parsed.netloc.lower()
    query = parse_qs(parsed.query)
    if "v" in query and query["v"]:
        return query["v"][0]
    if "youtu.be" in netloc:
        path = parsed.path.strip("/")
        if path:
            return path.split("/", 1)[0]
    return None


def _is_mix_url(value: str) -> bool:
    """Return ``True`` when an item URL still carries collection context."""
    parsed = urlparse(value.strip())
    path = parsed.path.lower()
    query = parse_qs(parsed.query)

    if not path.strip("/"):
        return False
    if is_playlist_url(value):
        return False

    query_keys = {key.lower() for key in query}
    has_collection_query = bool(query_keys & _COLLECTION_QUERY_KEYS)
    if not has_collection_query:
        return False

    if any(
        re.search(pattern, path, re.IGNORECASE) for pattern in _COLLECTION_PATH_PATTERNS
    ):
        return False
    if any(re.search(pattern, path, re.IGNORECASE) for pattern in _ITEM_PATH_PATTERNS):
        return True

    return True


def _is_local_media_file(value: str) -> bool:
    """Return ``True`` for readable local media files with known extensions."""
    cleaned = value.strip("\"'").strip()
    lower = cleaned.lower()
    if not lower.endswith(_LOCAL_MEDIA_EXTENSIONS):
        return False
    expanded = os.path.realpath(os.path.expanduser(cleaned))
    return os.path.exists(expanded) and not os.path.isdir(expanded)


def _is_readable_text(path: str) -> bool:
    """Return ``True`` when a file can be opened and decoded as UTF-8 text."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            f.read(1024)
        return True
    except (UnicodeDecodeError, OSError):
        return False
