"""Download execution using yt-dlp.

Provides async downloader implementation and protocol for media file downloads.
"""

from __future__ import annotations

import asyncio
import os
import re
import shutil
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from vdl.cancellation import CancellationToken
from vdl.error_translation import translate_error
from vdl.errors import VDLCancelled, VDLDependencyError
from vdl.logging import Logger, NullLogger
from vdl.models import (
    DownloadKind,
    DownloadRequest,
    DownloadResult,
    DownloadStatus,
    Quality,
)
from vdl.progress import DownloadProgress, ProgressCallback

#: Patterns in error messages that suggest account/auth issues.
_BOT_ERROR_PATTERNS = [
    r"Sign in to confirm you.?re not a bot",
    r"This content is age-restricted",
    r"Please sign in to view this video",
    r"Ineligible for downloading",
    r"HTTP Error 403",
    r"Forbidden",
    r"access denied",
    r"web client only works when logged-in",
    r"only available to registered users",
    r"Sign in to confirm your age",
]


class _LogCapture:
    """Capture yt-dlp log messages (internal).

    Used to capture warnings and errors from yt-dlp for error analysis.
    """

    def __init__(self) -> None:
        """Initialize log capture."""
        self.lines: list[str] = []

    def debug(self, msg: str) -> None:
        """Ignore debug messages.

        Args:
            msg: Debug message.
        """
        pass

    def warning(self, msg: str) -> None:
        """Capture warning message.

        Args:
            msg: Warning message.
        """
        self.lines.append(msg)

    def error(self, msg: str) -> None:
        """Capture error message.

        Args:
            msg: Error message.
        """
        self.lines.append(msg)


#: Mapping of quality preferences to yt-dlp format selectors.
_QUALITY_FORMAT: dict[Quality, str] = {
    Quality.BEST: "bestvideo+bestaudio/best",
    Quality.MEDIUM: "bestvideo[height<=720]+bestaudio/best",
    Quality.LOW: "bestvideo[height<=480]+bestaudio/best",
    Quality.P2160: "bestvideo[height<=2160]+bestaudio/best[height<=2160]/best",
    Quality.P1440: "bestvideo[height<=1440]+bestaudio/best[height<=1440]/best",
    Quality.P1080: "bestvideo[height<=1080]+bestaudio/best[height<=1080]/best",
    Quality.P720: "bestvideo[height<=720]+bestaudio/best[height<=720]/best",
    Quality.P480: "bestvideo[height<=480]+bestaudio/best[height<=480]/best",
    Quality.AUDIO: "bestaudio/best",
}


@dataclass(frozen=True)
class DownloadOptions:
    """Configuration options for download operations.

    Sidecar fields (``write_thumbnail`` / ``write_subtitles``) are
    independent of yt-dlp's metadata embedding: enabling them produces
    standalone files alongside the video. ``subtitle_langs`` is a comma
    or space separated list of yt-dlp language hints (``"en,fr"``,
    ``"en.*"``); manual subtitles are preferred and yt-dlp falls back to
    auto-generated subtitles when manual is unavailable.
    """

    output_dir: Path
    quality: Quality = Quality.BEST
    audio_only: bool = False
    playlist: bool = False
    force: bool = False
    cookies: Path | None = None
    cookies_from_browser: str | None = None
    subdirectory: str | None = None
    write_thumbnail: bool = False
    write_subtitles: bool = False
    subtitle_langs: str = "en"


class Downloader(Protocol):
    """Protocol for download implementations.

    Defines the interface for media download operations.
    """

    async def download(
        self,
        request: DownloadRequest,
        *,
        on_progress: ProgressCallback | None = None,
        cancel_token: CancellationToken | None = None,
    ) -> DownloadResult:
        """Execute a download operation.

        Args:
            request: Download request with source URL and options.
            on_progress: Optional callback for progress updates.
            cancel_token: Optional token; cancelling it aborts the in-flight
                download cooperatively (next yt-dlp progress hook tick).

        Returns:
            DownloadResult with completion status and output path.
        """
        ...


class YtDlpDownloader:
    """Media downloader using yt-dlp backend.

    Handles asynchronous video/audio downloads with quality selection, format conversion,
    and error recovery. Implements multi-level retry strategy for authentication issues.

    Attributes:
        options: Default download options.
        logger: Logger for download events.
    """

    def __init__(self, options: DownloadOptions, logger: Logger | None = None) -> None:
        """Initialize downloader with options.

        Args:
            options: Download configuration (output directory, quality, cookies, etc.).
            logger: Optional logger instance (uses NullLogger if not provided).
        """
        self.options = options
        self.logger = logger or NullLogger()

    async def download(
        self,
        request: DownloadRequest,
        *,
        on_progress: ProgressCallback | None = None,
        cancel_token: CancellationToken | None = None,
    ) -> DownloadResult:
        """Execute download asynchronously.

        Offloads blocking yt-dlp operations to thread pool to avoid blocking async code.
        """
        self.logger.info("downloader.started", url=request.source.raw)
        return await asyncio.to_thread(
            self._download_sync,
            request,
            on_progress=on_progress,
            cancel_token=cancel_token,
        )

    def _download_sync(
        self,
        request: DownloadRequest,
        on_progress: ProgressCallback | None = None,
        cancel_token: CancellationToken | None = None,
    ) -> DownloadResult:
        """Synchronous download implementation using yt-dlp.

        Implements multi-level retry strategy:
        - Level 0: Standard download
        - Level 1: Alternative player clients (tv, mweb)
        - Level 2: With cookies (file or browser extraction)

        Detects bot-detection errors and automatically escalates to next retry level.

        Args:
            request: Download request with source URL and options.
            on_progress: Optional callback for progress updates.

        Returns:
            DownloadResult with completion status and error details.

        Raises:
            VDLDependencyError: If yt-dlp is not installed.
        """
        try:
            import yt_dlp
        except ImportError as e:
            raise VDLDependencyError("yt-dlp is not installed") from e

        download_id = str(uuid.uuid4())
        output_dir = request.output_dir or self.options.output_dir
        captured: dict = {"filepath": None, "title": None}
        progress_state: dict[str, float] = {"percent": 0.0}
        saw_download_progress = False

        def _info_title(d: dict) -> str | None:
            info = d.get("info_dict") or {}
            title = info.get("title")
            if title and not captured["title"]:
                captured["title"] = title
            return captured["title"] or request.source_title

        def _progress_hook(d: dict) -> None:
            nonlocal saw_download_progress
            if cancel_token is not None and cancel_token.is_cancelled:
                raise VDLCancelled("Download cancelled by user")
            title = _info_title(d)
            if on_progress is None:
                return
            status_str = d.get("status")
            if status_str == "downloading":
                downloaded = d.get("downloaded_bytes") or 0
                total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                percent = min(99.9, (downloaded / total * 100)) if total > 0 else None
                if percent is not None:
                    saw_download_progress = True
                    percent = max(progress_state["percent"], percent)
                    progress_state["percent"] = percent
                speed = d.get("speed")
                speed_bps = float(speed) if isinstance(speed, (int, float)) else None
                on_progress(
                    DownloadProgress(
                        id=download_id,
                        status=DownloadStatus.DOWNLOADING,
                        percent=percent,
                        speed_bps=speed_bps,
                        title=title,
                    )
                )
            elif status_str == "finished":
                captured["filepath"] = d.get("filename")
                # yt-dlp can emit multiple finished/downloading cycles for a single
                # logical download (separate streams, post-processing phases). Keep
                # the bar monotonic and reserve 100% for the final COMPLETED update.
                if saw_download_progress:
                    progress_state["percent"] = max(progress_state["percent"], 99.0)
                on_progress(
                    DownloadProgress(
                        id=download_id,
                        status=DownloadStatus.PROCESSING,
                        percent=progress_state["percent"],
                        title=title,
                    )
                )

        url = request.source.normalized or request.source.raw
        has_cookies = bool(
            request.cookies
            or request.cookies_from_browser
            or self.options.cookies
            or self.options.cookies_from_browser
        )
        start_level = 2 if has_cookies else 0
        last_error = "Download failed"

        for level in range(start_level, 3):
            captured["filepath"] = None
            log = _LogCapture()
            opts = self._build_opts(request, output_dir, _progress_hook, level=level)
            opts["logger"] = log

            try:
                if on_progress:
                    on_progress(
                        DownloadProgress(
                            id=download_id,
                            status=DownloadStatus.STARTING,
                            percent=0.0,
                            title=captured.get("title") or request.source_title,
                        )
                    )
                with yt_dlp.YoutubeDL(opts) as ydl:
                    info = ydl.extract_info(url, download=True)
                    if not info:
                        return DownloadResult(
                            id=download_id,
                            source_url=request.source.raw,
                            status=DownloadStatus.FAILED,
                            error="No info returned",
                        )
                    filepath = _final_filepath(info, ydl) or captured.get("filepath")
                    if on_progress:
                        on_progress(
                            DownloadProgress(
                                id=download_id,
                                status=DownloadStatus.COMPLETED,
                                percent=100.0,
                                title=captured.get("title") or info.get("title"),
                                output_path=Path(filepath) if filepath else None,
                            )
                        )
                    self.logger.info(
                        "downloader.completed",
                        url=request.source.raw,
                        filepath=filepath,
                    )
                    metadata: dict = {}
                    title = captured.get("title") or info.get("title")
                    if title:
                        metadata["title"] = title
                    sidecars = _collect_sidecars(info)
                    final_path, sidecars = _rename_download_outputs(
                        Path(filepath) if filepath else None,
                        sidecars,
                        title=title or request.source_title,
                        filename_prefix=request.filename_prefix,
                    )
                    if sidecars:
                        metadata["sidecars"] = sidecars
                    return DownloadResult(
                        id=download_id,
                        source_url=request.source.raw,
                        status=DownloadStatus.COMPLETED,
                        output_path=final_path,
                        metadata=metadata,
                    )
            except VDLCancelled:
                self.logger.info("downloader.cancelled", url=request.source.raw)
                if on_progress:
                    on_progress(
                        DownloadProgress(
                            id=download_id,
                            status=DownloadStatus.CANCELLED,
                            title=captured.get("title") or request.source_title,
                        )
                    )
                return DownloadResult(
                    id=download_id,
                    source_url=request.source.raw,
                    status=DownloadStatus.CANCELLED,
                )
            except Exception as e:
                last_error = str(e)
                # yt-dlp wraps progress-hook exceptions in DownloadError; pull
                # ours back out so a cancel does not look like a generic error.
                if isinstance(
                    getattr(e, "exc_info", (None,))[1]
                    if hasattr(e, "exc_info")
                    else None,
                    VDLCancelled,
                ):
                    self.logger.info("downloader.cancelled", url=request.source.raw)
                    if on_progress:
                        on_progress(
                            DownloadProgress(
                                id=download_id,
                                status=DownloadStatus.CANCELLED,
                                title=captured.get("title") or request.source_title,
                            )
                        )
                    return DownloadResult(
                        id=download_id,
                        source_url=request.source.raw,
                        status=DownloadStatus.CANCELLED,
                    )
                if "cancelled by user" in last_error.lower():
                    self.logger.info("downloader.cancelled", url=request.source.raw)
                    if on_progress:
                        on_progress(
                            DownloadProgress(
                                id=download_id,
                                status=DownloadStatus.CANCELLED,
                                title=captured.get("title") or request.source_title,
                            )
                        )
                    return DownloadResult(
                        id=download_id,
                        source_url=request.source.raw,
                        status=DownloadStatus.CANCELLED,
                    )
                all_output = "\n".join(log.lines) + "\n" + last_error
                bot_detected = any(
                    re.search(p, all_output, re.IGNORECASE) for p in _BOT_ERROR_PATTERNS
                )
                if bot_detected and level < 2:
                    self.logger.warning(
                        "downloader.retrying",
                        url=request.source.raw,
                        level=level,
                        reason="bot-detection",
                    )
                    continue
                translated = translate_error(last_error)
                if on_progress:
                    on_progress(
                        DownloadProgress(
                            id=download_id,
                            status=DownloadStatus.FAILED,
                            error=translated.message,
                            title=captured.get("title") or request.source_title,
                        )
                    )
                self.logger.warning(
                    "downloader.failed",
                    url=request.source.raw,
                    error=translated.raw,
                    category=translated.category,
                )
                return DownloadResult(
                    id=download_id,
                    source_url=request.source.raw,
                    status=DownloadStatus.FAILED,
                    error=translated.display,
                    metadata={
                        "error_category": translated.category,
                        "error_raw": translated.raw,
                    },
                )

        translated = translate_error(last_error)
        if on_progress:
            on_progress(
                DownloadProgress(
                    id=download_id,
                    status=DownloadStatus.FAILED,
                    error=translated.message,
                    title=captured.get("title") or request.source_title,
                )
            )
        self.logger.warning(
            "downloader.failed",
            url=request.source.raw,
            error=translated.raw,
            category=translated.category,
        )
        return DownloadResult(
            id=download_id,
            source_url=request.source.raw,
            status=DownloadStatus.FAILED,
            error=translated.display,
            metadata={
                "error_category": translated.category,
                "error_raw": translated.raw,
            },
        )

    def _build_opts(
        self, request: DownloadRequest, output_dir: Path, progress_hook, level: int = 0
    ) -> dict:
        """Build yt-dlp options dictionary for download.

        Constructs format selectors, output templates, and authentication options
        based on request parameters and retry level.

        Args:
            request: Download request with quality and format preferences.
            output_dir: Output directory for downloaded files.
            progress_hook: Callback for yt-dlp progress events.
            level: Retry level (0: standard, 1: alt clients, 2: with cookies).

        Returns:
            Dictionary of yt-dlp options ready for YoutubeDL initialization.
        """
        from vdl.naming import build_output_template

        audio_only = request.kind == DownloadKind.AUDIO or self.options.audio_only
        format_str = (
            "bestaudio/best"
            if audio_only
            else _QUALITY_FORMAT.get(request.quality, "bestvideo+bestaudio/best")
        )
        outtmpl = build_output_template(
            output_dir,
            playlist=request.playlist,
            subdirectory=request.subdirectory,
            filename_prefix=request.filename_prefix,
        )

        opts: dict = {
            "format": format_str,
            "outtmpl": outtmpl,
            "quiet": True,
            "no_warnings": True,
            "no_playlist": not request.playlist,
            "progress_hooks": [progress_hook],
            "merge_output_format": "mp4",
            "embedthumbnail": True,
            "addmetadata": True,
        }

        effective_write_thumbnail = (
            request.write_thumbnail
            if request.write_thumbnail is not None
            else self.options.write_thumbnail
        )
        effective_write_subtitles = (
            request.write_subtitles
            if request.write_subtitles is not None
            else self.options.write_subtitles
        )
        effective_subtitle_langs = request.subtitle_langs or self.options.subtitle_langs

        if effective_write_thumbnail:
            opts["writethumbnail"] = True
        if effective_write_subtitles:
            langs = [
                tok.strip()
                for tok in effective_subtitle_langs.replace(",", " ").split()
                if tok.strip()
            ]
            opts["writesubtitles"] = True
            opts["writeautomaticsub"] = True
            opts["subtitleslangs"] = langs or ["en"]
            opts["subtitlesformat"] = "vtt/best"

        if audio_only:
            opts["postprocessors"] = [
                {
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": "mp3",
                    "preferredquality": "0",
                }
            ]

        if level == 1:
            opts["extractor_args"] = {"youtube": {"player_client": ["tv", "mweb"]}}
        elif level >= 2:
            cookies = request.cookies or self.options.cookies
            cookies_from_browser = (
                request.cookies_from_browser or self.options.cookies_from_browser
            )
            if cookies:
                opts["cookiefile"] = str(cookies)
            elif cookies_from_browser:
                opts["cookiesfrombrowser"] = (cookies_from_browser,)

        return opts


def _collect_sidecars(info: dict) -> dict:
    """Extract thumbnail and subtitle file paths from a yt-dlp info dict.

    yt-dlp records the post-processed filenames on the info object. We
    surface them so wrappers don't have to guess them from the disk
    layout.
    """
    sidecars: dict = {}
    thumbs = info.get("thumbnails") or []
    for thumb in reversed(thumbs):
        path = thumb.get("filepath") or thumb.get("filename")
        if path:
            sidecars["thumbnail"] = path
            break
    requested_subs = info.get("requested_subtitles") or {}
    subs: dict = {}
    for lang, payload in requested_subs.items():
        if not isinstance(payload, dict):
            continue
        path = payload.get("filepath") or payload.get("filename")
        if path:
            subs[lang] = path
    if subs:
        sidecars["subtitles"] = subs
    return sidecars


def _final_filepath(info: dict, ydl) -> str | None:
    """Reconcile yt-dlp's final output path after post-processing.

    The ``progress_hooks`` "finished" callback fires for the last raw segment
    before muxing, so a video+audio merge to mp4 leaves the captured filename
    pointing at a transient .webm. yt-dlp records the post-processed result
    on ``info["requested_downloads"][i]["filepath"]`` (and falls back to
    ``info["filepath"]``); prefer those so the result matches the file on disk.
    """
    requested = info.get("requested_downloads") or []
    if requested:
        rd = requested[0]
        fp = rd.get("filepath") or rd.get("_filename")
        if fp:
            return fp
    return info.get("filepath") or info.get("_filename") or ydl.prepare_filename(info)


def _rename_download_outputs(
    media_path: Path | None,
    sidecars: dict,
    *,
    title: str | None,
    filename_prefix: str | None,
) -> tuple[Path | None, dict]:
    """Rename the media file and any sidecars into the final output layout."""
    if media_path is None:
        return None, sidecars

    from vdl.naming import ensure_unique_path, slugify_title

    slug = slugify_title(title or media_path.stem, prefix=filename_prefix)
    desired_media = media_path.with_name(f"{slug}{media_path.suffix.lower()}")
    desired_media = ensure_unique_path(
        desired_media,
        reserved=_sidecar_paths(sidecars),
    )
    if not media_path.exists():
        return desired_media, {}
    final_media = _move_file(media_path, desired_media)
    if final_media is None:
        return None, {}

    renamed_sidecars: dict = {}

    thumb = sidecars.get("thumbnail")
    if isinstance(thumb, str):
        thumb_path = Path(thumb)
        renamed = _move_file(
            thumb_path,
            final_media.with_name(f"{slug}.thumbnail{thumb_path.suffix.lower()}"),
        )
        if renamed is not None:
            renamed_sidecars["thumbnail"] = str(renamed)

    subtitles = sidecars.get("subtitles") or {}
    renamed_subs: dict[str, str] = {}
    if isinstance(subtitles, dict):
        for lang, raw_path in subtitles.items():
            if not isinstance(raw_path, str):
                continue
            sub_path = Path(raw_path)
            renamed = _move_file(
                sub_path,
                final_media.with_name(f"{slug}.{lang}{sub_path.suffix.lower()}"),
            )
            if renamed is not None:
                renamed_subs[lang] = str(renamed)
    if renamed_subs:
        renamed_sidecars["subtitles"] = renamed_subs

    return final_media, renamed_sidecars


def _sidecar_paths(sidecars: dict) -> list[Path]:
    """Collect all sidecar file paths from the downloader metadata."""
    paths: list[Path] = []
    thumbnail = sidecars.get("thumbnail")
    if isinstance(thumbnail, str):
        paths.append(Path(thumbnail))
    subtitles = sidecars.get("subtitles") or {}
    if isinstance(subtitles, dict):
        for path in subtitles.values():
            if isinstance(path, str):
                paths.append(Path(path))
    return paths


def _move_file(src: Path, dst: Path) -> Path | None:
    """Move a file into place and return the destination path when successful."""
    if not src.exists():
        return None
    if src == dst:
        return src
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        dst.unlink()
    shutil.move(os.fspath(src), os.fspath(dst))
    return dst


async def download_one(
    request: DownloadRequest,
    downloader: Downloader,
    on_progress: ProgressCallback | None = None,
) -> DownloadResult:
    """Download a single media item.

    Args:
        request: Download request for the item.
        downloader: Downloader implementation to use.
        on_progress: Optional callback for progress updates.

    Returns:
        DownloadResult with completion status and output path.
    """
    return await downloader.download(request, on_progress=on_progress)


async def download_many(
    requests: list[DownloadRequest],
    downloader: Downloader,
    on_progress: ProgressCallback | None = None,
) -> list[DownloadResult]:
    """Download multiple media items sequentially.

    Args:
        requests: List of download requests.
        downloader: Downloader implementation to use.
        on_progress: Optional callback for progress updates (shared across all downloads).

    Returns:
        List of DownloadResult for each request in order.
    """
    return [await downloader.download(req, on_progress=on_progress) for req in requests]
