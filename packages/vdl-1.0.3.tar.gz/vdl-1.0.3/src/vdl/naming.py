"""Output filename planning and sanitization.

Provides utilities for generating safe filenames and directory structures for downloads.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class FilenamePlan:
    """Planned output path for a downloaded file.

    Attributes:
        directory: Directory containing the file.
        stem: Filename without extension.
        extension: File extension including the dot (e.g., '.mp4').
        final_path: Complete final path (directory + stem + extension).
        temporary_path: Optional temporary path during download.
    """

    directory: Path
    stem: str
    extension: str
    final_path: Path
    temporary_path: Path | None = None


def sanitize_filename(filename: str) -> str:
    """Sanitize filename to be filesystem-safe.

    Converts to lowercase, removes special characters, collapses whitespace and dashes,
    and ensures result is non-empty (defaults to "video").

    Args:
        filename: Original filename (may include extension).

    Returns:
        Safe filename with lowercase alphanumerics, dashes, and original extension preserved.
    """
    if "." in filename:
        name, ext = filename.rsplit(".", 1)
        ext = "." + ext.lower()
    else:
        name = filename
        ext = ""

    name = name.lower()
    name = re.sub(r"[^a-z0-9]+", "-", name)
    name = re.sub(r"-+", "-", name)
    name = name.strip("-")

    if not name:
        name = "video"

    return name + ext


def build_output_template(
    output_dir: Path,
    playlist: bool = False,
    subdirectory: str | None = None,
    filename_prefix: str | None = None,
) -> dict[str, str]:
    """Build yt-dlp ``outtmpl`` mapping for the flattened media layout.

    Single video::

        <output_dir>/<title>.<ext>
        <output_dir>/<title>.thumbnail.<ext>
        <output_dir>/<title>.<language>.<ext>

    Playlist::

        <output_dir>/<playlist>/<NNN>-<title>.<ext>
        <output_dir>/<playlist>/<NNN>-<title>.thumbnail.<ext>
        <output_dir>/<playlist>/<NNN>-<title>.<language>.<ext>

    yt-dlp interprets each entry of the returned dict as a per-output-type
    template; ``default`` covers the media file, ``thumbnail`` and
    ``subtitle`` route sidecars beside it.
    """
    base_dir = output_dir
    if subdirectory:
        sanitized_sub = sanitize_filename(subdirectory) if subdirectory else None
        base_dir = output_dir / (sanitized_sub or subdirectory)
        base_dir.mkdir(parents=True, exist_ok=True)

    prefix = filename_prefix or ("%(playlist_index)03d-" if playlist else "")
    item_name = f"{prefix}%(title)s"

    return {
        "default": str(base_dir / f"{item_name}.%(ext)s"),
        "thumbnail": str(base_dir / f"{item_name}.thumbnail.%(ext)s"),
        "subtitle": str(base_dir / f"{item_name}.%(language)s.%(ext)s"),
    }


def slugify_title(title: str, *, prefix: str | None = None) -> str:
    """Return a filesystem-safe slug for display or naming."""
    base = sanitize_filename(title)
    if prefix:
        base = f"{prefix}{base}"
    return base


def ensure_unique_path(path: Path, reserved: Iterable[Path] = ()) -> Path:
    """Find a non-conflicting sibling path by appending numeric suffixes."""
    reserved_resolved = {p.resolve() for p in reserved}
    candidate = path
    counter = 2
    while candidate.exists() or candidate.resolve() in reserved_resolved:
        candidate = path.with_name(f"{path.stem}-{counter}{path.suffix}")
        counter += 1
    return candidate


def plan_output_path(title: str, extension: str, output_dir: Path) -> FilenamePlan:
    """Plan output path for a file with given title and extension.

    Sanitizes title and extension, splits into stem and extension components,
    and returns complete FilenamePlan.

    Args:
        title: File title (usually video title).
        extension: File extension (with or without leading dot).
        output_dir: Directory to place the file in.

    Returns:
        FilenamePlan with sanitized paths and components.
    """
    ext = extension.lstrip(".")
    sanitized = sanitize_filename(f"{title}.{ext}" if ext else title)
    if "." in sanitized:
        stem, final_ext = sanitized.rsplit(".", 1)
        final_ext = "." + final_ext
    else:
        stem = sanitized
        final_ext = f".{ext}" if ext else ""

    final_path = output_dir / sanitized
    return FilenamePlan(
        directory=output_dir,
        stem=stem,
        extension=final_ext,
        final_path=final_path,
    )


def plan_playlist_directory(title: str, output_dir: Path) -> Path:
    """Plan directory for a playlist's downloads.

    Sanitizes playlist title and returns as subdirectory. Uses "playlist" as fallback
    if title is empty or sanitizes to invalid name.

    Args:
        title: Playlist title.
        output_dir: Base output directory.

    Returns:
        Path to playlist directory (output_dir / sanitized_title).
    """
    safe = sanitize_filename(title) if title else "playlist"
    if not safe or safe == "video":
        safe = "playlist"
    return output_dir / safe
