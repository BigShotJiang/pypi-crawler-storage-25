"""Progress tracking and reporting for downloads.

Provides dataclasses and emitters for tracking download progress with multiple output formats.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from threading import Lock
from typing import Callable, Protocol

from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskID,
    TaskProgressColumn,
    TextColumn,
)
from rich.table import Table

from vdl.models import DownloadStatus
from vdl.serialization import format_speed_bps


@dataclass(frozen=True)
class DownloadProgress:
    """Progress update for a single download operation.

    Core progress is typed: speed is raw bytes/second and title is captured
    from upstream metadata. Wrappers format these for display.

    Attributes:
        id: Unique identifier for the download task.
        status: Current download status.
        percent: Progress percentage (0-100) for DOWNLOADING status.
        speed_bps: Download speed in bytes/second (raw).
        title: Human-readable title from source metadata, when known.
        eta: Estimated time remaining (not currently used).
        current_file: Path to file currently being processed.
        output_path: Final output path when completed.
        error: Error message if status is FAILED.
        updated_at: Timestamp when this progress was created.
    """

    id: str
    status: DownloadStatus
    percent: float | None = None
    speed_bps: float | None = None
    title: str | None = None
    eta: str | None = None
    current_file: Path | None = None
    output_path: Path | None = None
    error: str | None = None
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))


class ProgressCallback(Protocol):
    """Callback protocol for progress updates.

    Callable that receives DownloadProgress updates during download operations.
    """

    def __call__(self, progress: DownloadProgress) -> None:
        """Handle progress update.

        Args:
            progress: DownloadProgress update with current status and metrics.
        """
        ...


class ProgressEmitter(Protocol):
    """Protocol for progress reporting implementations.

    Manages lifecycle of progress reporting with start/emit/finish interface.
    """

    def start(self, total: int | None = None) -> None:
        """Initialize progress reporting.

        Args:
            total: Total number of items to process (optional).
        """
        ...

    def emit(self, progress: DownloadProgress) -> None:
        """Report a progress update.

        Args:
            progress: DownloadProgress update.
        """
        ...

    def finish(self) -> None:
        """Finalize progress reporting and clean up resources."""
        ...


class NullProgressEmitter:
    """No-op progress emitter that discards all updates.

    Used as default to avoid null checks in code that handles progress reporting.
    """

    def start(self, total: int | None = None) -> None:
        """Discard start signal.

        Args:
            total: Total count (ignored).
        """
        pass

    def emit(self, progress: DownloadProgress) -> None:
        """Discard progress update.

        Args:
            progress: DownloadProgress (ignored).
        """
        pass

    def finish(self) -> None:
        """Discard finish signal."""
        pass


class CallbackProgressEmitter:
    """Progress emitter that forwards updates to a callback function.

    Attributes:
        _callback: Callback function to invoke on each progress update.
    """

    def __init__(self, callback: Callable[[DownloadProgress], None]):
        """Initialize with callback function.

        Args:
            callback: Function to call for each progress update.
        """
        self._callback = callback

    def start(self, total: int | None = None) -> None:
        """Start reporting (ignored).

        Args:
            total: Total count (ignored).
        """
        pass

    def emit(self, progress: DownloadProgress) -> None:
        """Emit progress update via callback.

        Args:
            progress: DownloadProgress to forward to callback.
        """
        self._callback(progress)

    def finish(self) -> None:
        """Finish reporting (ignored)."""
        pass


class RichProgressEmitter:
    """Rich-based progress display with live updates.

    Uses Rich library to display real-time progress with a summary panel showing
    active/completed/skipped/failed counts and individual task progress bars.

    Thread-safe with internal locking for concurrent emit calls.

    Attributes:
        console: Rich Console for output.
    """

    def __init__(self, console: Console | None = None) -> None:
        """Initialize Rich progress emitter.

        Args:
            console: Optional Rich Console (creates new one if not provided).
        """
        self.console = console or Console()
        self._lock = Lock()
        self._started = False
        self._total = 0
        self._progress = Progress(
            SpinnerColumn(),
            TextColumn("[bold cyan]{task.fields[label]}"),
            BarColumn(),
            TaskProgressColumn(),
            TextColumn("{task.fields[state]}"),
            TextColumn("{task.fields[speed]}"),
            console=self.console,
            transient=False,
        )
        self._live = Live(console=self.console, refresh_per_second=10, transient=False)
        self._task_ids: dict[str, TaskID] = {}
        self._counts: dict[DownloadStatus, int] = {
            status: 0 for status in DownloadStatus
        }
        self._last_status: dict[str, DownloadStatus] = {}
        self._titles: dict[str, str] = {}

    def start(self, total: int | None = None) -> None:
        """Start progress display.

        Args:
            total: Total number of items to process (displayed in summary panel).
        """
        with self._lock:
            self._total = total or 0
            if self._started:
                return
            self._started = True
            self._live.start()
            self._live.update(self._render())

    def emit(self, progress: DownloadProgress) -> None:
        """Report a progress update and update display.

        Creates new progress bar on first emit for a task ID, updates existing bar on subsequent emits.
        Automatically starts progress display if not already started.

        Args:
            progress: DownloadProgress update to display.
        """
        with self._lock:
            if not self._started:
                self.start()

            task_id = self._task_ids.get(progress.id)
            if task_id is None:
                task_id = self._progress.add_task(
                    "",
                    total=100,
                    completed=0,
                    label=self._label(progress),
                    state=self._status_label(progress.status),
                    speed=format_speed_bps(progress.speed_bps),
                )
                self._task_ids[progress.id] = task_id

            previous = self._last_status.get(progress.id)
            if previous is not None:
                self._counts[previous] = max(0, self._counts[previous] - 1)
            self._counts[progress.status] += 1
            self._last_status[progress.id] = progress.status
            if progress.title and progress.id not in self._titles:
                self._titles[progress.id] = progress.title

            completed = progress.percent if progress.percent is not None else 0.0
            if progress.status in {
                DownloadStatus.COMPLETED,
                DownloadStatus.SKIPPED,
                DownloadStatus.FAILED,
                DownloadStatus.CANCELLED,
            }:
                completed = max(
                    completed,
                    100.0 if progress.status != DownloadStatus.FAILED else completed,
                )

            self._progress.update(
                task_id,
                completed=min(completed, 100.0),
                label=self._label(progress),
                state=self._status_label(progress.status, progress.error),
                speed=format_speed_bps(progress.speed_bps),
            )
            self._live.update(self._render())

    def set_total(self, total: int) -> None:
        """Update the planned total after the display has started.

        Useful when a playlist resolves into more items than the
        original plan reported. Never decreases below the current value
        so a late-arriving smaller estimate can't shrink the bar.
        """
        with self._lock:
            self._total = max(self._total, total)
            if self._started:
                self._live.update(self._render())

    def finish(self) -> None:
        """Finalize and stop progress display.

        Renders final state and stops Rich Live display and progress tracking.
        """
        with self._lock:
            if not self._started:
                return
            self._live.update(self._render())
            self._live.stop()
            self._progress.stop()
            self._started = False

    @property
    def summary_counts(self) -> dict[str, int]:
        """Get current status counts.

        Returns:
            Dictionary mapping status names to counts (empty statuses omitted).
        """
        return {
            status.value: self._counts[status]
            for status in DownloadStatus
            if self._counts[status] > 0
        }

    def _render(self) -> Group:
        """Render complete display with summary and progress bars.

        Returns:
            Rich Group combining summary panel and progress bars.
        """
        return Group(self._summary_panel(), self._progress)

    def _summary_panel(self) -> Panel:
        """Render summary panel with status counts.

        Total is the larger of (planned total provided by caller) and
        (number of distinct tasks we've actually observed) — playlists
        expand into more downloads than the plan reports, and we want
        the counter to track reality rather than the upstream plan.
        """
        table = Table.grid(expand=True)
        table.add_column(justify="left")
        table.add_column(justify="right")
        active = sum(
            self._counts[status]
            for status in (
                DownloadStatus.STARTING,
                DownloadStatus.DOWNLOADING,
                DownloadStatus.PROCESSING,
            )
        )
        terminal = sum(
            self._counts[status]
            for status in (
                DownloadStatus.COMPLETED,
                DownloadStatus.SKIPPED,
                DownloadStatus.FAILED,
                DownloadStatus.CANCELLED,
            )
        )
        observed = max(self._total, len(self._task_ids))
        remaining = max(0, observed - terminal - active)
        table.add_row("Total", str(observed))
        table.add_row("Active", str(active))
        table.add_row("Remaining", str(remaining))
        table.add_row("Completed", str(self._counts[DownloadStatus.COMPLETED]))
        table.add_row("Skipped", str(self._counts[DownloadStatus.SKIPPED]))
        table.add_row("Failed", str(self._counts[DownloadStatus.FAILED]))
        table.add_row("Cancelled", str(self._counts[DownloadStatus.CANCELLED]))
        return Panel(table, title="Download Progress", border_style="cyan")

    def _label(self, progress: DownloadProgress) -> str:
        """Generate display label for progress bar.

        Prefers the captured human title, then current/output filename, and
        only falls back to a short id slice when nothing else is known.
        """
        title = progress.title or self._titles.get(progress.id)
        if title:
            return title
        path = progress.current_file or progress.output_path
        if path is not None:
            return path.name
        return f"download {progress.id[:8]}"

    def _status_label(self, status: DownloadStatus, error: str | None = None) -> str:
        """Generate display label for status.

        Converts status enum to human-readable string. For FAILED status, appends error message.

        Args:
            status: Download status to label.
            error: Optional error message to include for FAILED status.

        Returns:
            Human-readable status label.
        """
        label = status.value.replace("_", " ")
        if status == DownloadStatus.FAILED and error:
            return f"{label}: {error}"
        return label
