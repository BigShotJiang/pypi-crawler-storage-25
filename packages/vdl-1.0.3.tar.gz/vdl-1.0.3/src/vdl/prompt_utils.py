"""Helpers for interactive prompt input.

Three related concerns:

1. Sanitize user-pasted text. Terminal users often paste a previous prompt
   echo back into the next prompt (e.g. ``URL or file path https://...``).
   They also wrap URLs in quotes. ``sanitize_pasted_input`` strips these
   without altering the meaningful payload.

2. Provide prompts via ``prompt_toolkit`` so users get shell-style ↑/↓
   history and completion while the interactive CLI is already running on
   the main asyncio loop. This avoids reading stdin from worker threads.

3. Persist a small per-prompt history file under the VDL state dir so
   recent URLs and paths come back across sessions.
"""

from __future__ import annotations

import os
import re
import sys
from pathlib import Path
from typing import Sequence

# Common prefixes the user may accidentally include from a previous prompt
# echo (case-insensitive, with or without trailing colon).
_PROMPT_PREFIXES = (
    "url or file path",
    "url or filepath",
    "output directory",
    "url",
    "file path",
    "select items",
    "quality",
)


def sanitize_pasted_input(value: str) -> str:
    """Strip prompt echoes, surrounding quotes, and stray whitespace.

    Args:
        value: Raw input from a terminal prompt.

    Returns:
        Cleaned input string. Empty string if the input was only echoed
        prompt text.
    """
    cleaned = value.strip()
    if not cleaned:
        return ""

    # Strip a leading prompt-echo prefix like "URL or file path: ".
    # Ordered longest-first so "url or file path" wins over "url".
    lower = cleaned.lower()
    for prefix in _PROMPT_PREFIXES:
        if lower.startswith(prefix):
            rest = cleaned[len(prefix) :].lstrip(" :\t")
            cleaned = rest
            break

    # Strip surrounding quotes (single or double, including smart quotes).
    cleaned = cleaned.strip().strip("\"'“”‘’").strip()

    # Collapse internal whitespace runs (a paste sometimes injects \r).
    cleaned = re.sub(r"\s+", " ", cleaned)
    return cleaned


def expand_user_path(value: str) -> Path:
    """Expand ``~`` and environment variables in a path string."""
    return Path(os.path.expandvars(os.path.expanduser(value.strip())))


_HISTORY_FILES: dict[str, Path | None] = {}


def _history_file(name: str) -> Path | None:
    """Return a writable history file path for the given prompt namespace.

    Cached because a single session asks for the same name many times.
    Returns ``None`` if the directory isn't writable, in which case
    history falls back to in-memory (still scoped to the running
    process).
    """
    if name in _HISTORY_FILES:
        return _HISTORY_FILES[name]
    try:
        from vdl.paths import get_default_paths

        state_dir = get_default_paths().state_dir
        state_dir.mkdir(parents=True, exist_ok=True)
        path = state_dir / f"prompt_history_{name}"
        path.touch(exist_ok=True)
        _HISTORY_FILES[name] = path
    except Exception:
        _HISTORY_FILES[name] = None
    return _HISTORY_FILES[name]


def _interactive_terminal() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


def _build_prompt_session(
    *,
    history_name: str,
    only_directories: bool,
    choices: Sequence[str] | None,
):
    from prompt_toolkit import PromptSession
    from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
    from prompt_toolkit.completion import PathCompleter, WordCompleter
    from prompt_toolkit.history import FileHistory, InMemoryHistory

    history_path = _history_file(history_name)
    history = FileHistory(str(history_path)) if history_path else InMemoryHistory()
    completer = None
    if only_directories:
        completer = PathCompleter(expanduser=True, only_directories=True)
    elif choices:
        completer = WordCompleter(list(choices), ignore_case=True, sentence=True)
    return PromptSession(
        history=history,
        completer=completer,
        complete_while_typing=False,
        enable_history_search=True,
        auto_suggest=AutoSuggestFromHistory(),
    )


def read_line(
    prompt_text: str,
    *,
    history_name: str,
    only_directories: bool = False,
    choices: Sequence[str] | None = None,
) -> str:
    """Read a single line with history (↑/↓) and optional completion.

    Falls back to plain ``input()`` when prompt_toolkit is missing or
    stdin/stdout aren't a TTY, so non-interactive tests still work.
    """
    if not _interactive_terminal():
        return input(prompt_text)
    try:
        session = _build_prompt_session(
            history_name=history_name,
            only_directories=only_directories,
            choices=choices,
        )
        return session.prompt(prompt_text)
    except ImportError:
        return input(prompt_text)


async def read_line_async(
    prompt_text: str,
    *,
    history_name: str,
    only_directories: bool = False,
    choices: Sequence[str] | None = None,
) -> str:
    """Async variant of ``read_line`` for the interactive CLI.

    This keeps prompt_toolkit attached to the main thread / main event loop
    instead of sending terminal reads into a worker thread.
    """
    if not _interactive_terminal():
        return input(prompt_text)
    try:
        session = _build_prompt_session(
            history_name=history_name,
            only_directories=only_directories,
            choices=choices,
        )
        return await session.prompt_async(prompt_text)
    except ImportError:
        return input(prompt_text)


def prompt_for_directory(
    label: str,
    default: Path | None,
) -> Path | None:
    """Prompt for an output directory with history + directory completion.

    Returns ``None`` when the user just hits Enter (caller falls back to
    its default). Otherwise returns an expanded ``Path`` (not validated
    on disk; caller decides whether to create it).
    """
    default_str = str(default) if default else ""
    prompt_text = f"{label} (default: {default_str or 'use VDL default'}): "
    raw = read_line(prompt_text, history_name="output_dir", only_directories=True)
    cleaned = sanitize_pasted_input(raw)
    if not cleaned:
        return None
    return expand_user_path(cleaned)


async def prompt_for_directory_async(
    label: str,
    default: Path | None,
) -> Path | None:
    """Async variant of ``prompt_for_directory``."""
    default_str = str(default) if default else ""
    prompt_text = f"{label} (default: {default_str or 'use VDL default'}): "
    raw = await read_line_async(
        prompt_text,
        history_name="output_dir",
        only_directories=True,
    )
    cleaned = sanitize_pasted_input(raw)
    if not cleaned:
        return None
    return expand_user_path(cleaned)
