"""Plain-structure serializers and display helpers for VDL core types.

The core library returns typed Python objects. Wrappers (CLI --json, MCP) call
these helpers to convert them to plain dicts/lists, and to render values like
download speed in human units. Nothing here imports Rich, prints, or does I/O.
"""

from __future__ import annotations

import dataclasses
from typing import Any, TYPE_CHECKING

from vdl.models import (
    BatchSummary,
    DoctorReport,
    DownloadResult,
    PlaylistInfo,
    StatusRecord,
)

if TYPE_CHECKING:
    from vdl.progress import DownloadProgress


def format_speed_bps(bps: float | int | None) -> str:
    """Render bytes-per-second as a human-readable string.

    Examples: 0 → "0 B/s", 842_000 → "842 KB/s", 5_300_000 → "5.3 MB/s".
    Returns empty string for None so callers can paste it into a label cell.
    """
    if bps is None:
        return ""
    if bps < 1024:
        return f"{int(bps)} B/s"
    if bps < 1024 * 1024:
        return f"{bps / 1024:.0f} KB/s"
    if bps < 1024 * 1024 * 1024:
        return f"{bps / (1024 * 1024):.1f} MB/s"
    return f"{bps / (1024 * 1024 * 1024):.1f} GB/s"


def download_result_to_dict(result: DownloadResult) -> dict[str, Any]:
    """Convert a download result into a plain JSON-friendly dictionary."""
    return {
        "id": result.id,
        "url": result.source_url,
        "status": result.status.value,
        "quality": result.quality.value if result.quality else None,
        "request_key": result.request_key,
        "output": str(result.output_path) if result.output_path else None,
        "error": result.error,
        "skipped_reason": result.skipped_reason,
        "metadata": dict(result.metadata),
    }


def download_results_to_list(results: list[DownloadResult]) -> list[dict[str, Any]]:
    """Convert a list of download results into plain dictionaries."""
    return [download_result_to_dict(r) for r in results]


def playlist_info_to_dict(info: PlaylistInfo) -> dict[str, Any]:
    """Convert playlist metadata into a plain JSON-friendly dictionary."""
    return {
        "url": info.url,
        "title": info.title,
        "count": len(info.items),
        "items": [
            {"index": item.index, "title": item.title, "url": item.url}
            for item in info.items
        ],
    }


def status_record_to_dict(record: StatusRecord) -> dict[str, Any]:
    """Convert a persisted status record into a plain dictionary."""
    return {
        "id": record.id,
        "url": record.source_url,
        "status": record.status.value,
        "quality": record.quality.value if record.quality else None,
        "output": str(record.output_path) if record.output_path else None,
        "error": record.error,
        "percent": record.percent,
        "updated_at": record.updated_at.isoformat() if record.updated_at else None,
    }


def status_records_to_list(records: list[StatusRecord]) -> list[dict[str, Any]]:
    """Convert status records into a list of plain dictionaries."""
    return [status_record_to_dict(r) for r in records]


def doctor_report_to_dict(report: DoctorReport) -> dict[str, Any]:
    """Convert a doctor report into a plain dictionary."""
    return {
        "version": report.version,
        "ffmpeg": report.ffmpeg_available,
        "ffprobe": report.ffprobe_available,
        "ytdlp": report.ytdlp_available,
        "mcp": report.mcp_available,
        "config_ok": report.config_ok,
        "state_ok": report.state_ok,
        "config_dir_ok": report.config_dir_ok,
        "state_dir_ok": report.state_dir_ok,
        "cache_dir_ok": report.cache_dir_ok,
        "output_dir_ok": report.output_dir_ok,
        "repairs": list(report.repairs),
        "details": dict(report.details),
    }


def batch_summary_to_dict(summary: BatchSummary) -> dict[str, Any]:
    """Convert a batch summary into a plain dictionary."""
    return {
        "total": summary.total,
        "completed": len(summary.completed),
        "skipped": len(summary.skipped),
        "failed": len(summary.failed),
        "results": download_results_to_list(summary.results),
    }


def download_progress_to_dict(progress: "DownloadProgress") -> dict[str, Any]:
    """Convert a live progress update into a plain dictionary."""
    return {
        "id": progress.id,
        "status": progress.status.value,
        "percent": progress.percent,
        "speed_bps": progress.speed_bps,
        "speed": format_speed_bps(progress.speed_bps),
        "title": progress.title,
        "current_file": str(progress.current_file) if progress.current_file else None,
        "output_path": str(progress.output_path) if progress.output_path else None,
        "error": progress.error,
        "updated_at": progress.updated_at.isoformat() if progress.updated_at else None,
    }


def config_to_dict(config: Any) -> dict[str, Any]:
    """Convert a dataclass-like config object into a dictionary."""
    return dataclasses.asdict(config)
