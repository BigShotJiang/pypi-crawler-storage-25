"""Playlist resolution, inspection, and request generation."""

from __future__ import annotations

from dataclasses import dataclass
import asyncio
from pathlib import Path
from typing import Literal, Protocol

from vdl.downloader import Downloader
from vdl.errors import VDLPlaylistError
from vdl.logging import Logger, NullLogger
from vdl.models import (
    DownloadRequest,
    DownloadResult,
    InputKind,
    PlaylistInfo,
    PlaylistItem,
    Quality,
    SourceInput,
)
from vdl.progress import ProgressCallback
from vdl.selection import PlaylistSelection, selection_to_indexes


class PlaylistResolver(Protocol):
    """Protocol for resolving playlist URLs to item lists.

    Implementations extract playlist metadata and item information from URLs.
    """

    async def resolve(self, url: str) -> PlaylistInfo:
        """Resolve a playlist URL to structured PlaylistInfo.

        Args:
            url: Playlist URL.

        Returns:
            PlaylistInfo with title and items.

        Raises:
            VDLPlaylistError: If resolution fails.
        """
        ...


@dataclass(frozen=True)
class PlaylistInspection:
    """Non-downloading yt-dlp classification result for a URL."""

    kind: Literal["playlist", "playlist_member", "single", "unsupported_or_unknown"]
    playlist_url: str | None = None
    entry_url: str | None = None


class _QuietYtDlpLogger:
    """Discard yt-dlp log output for inspect/resolve helper calls."""

    def debug(self, msg: str) -> None:
        pass

    def warning(self, msg: str) -> None:
        pass

    def error(self, msg: str) -> None:
        pass


class YtDlpPlaylistResolver:
    """Playlist resolver using yt-dlp.

    Resolves playlists from any platform supported by yt-dlp (YouTube, Vimeo, etc).
    Runs blocking yt-dlp calls in a thread pool to avoid blocking async code.

    Attributes:
        cookies: Optional path to cookies file.
        cookies_from_browser: Optional browser name for cookie extraction.
        logger: Logger for resolution events.
    """

    def __init__(
        self,
        cookies: str | None = None,
        cookies_from_browser: str | None = None,
        logger: Logger | None = None,
    ) -> None:
        """Initialize resolver.

        Args:
            cookies: Path to cookies file.
            cookies_from_browser: Browser name for cookie extraction.
            logger: Logger instance.
        """
        self.cookies = cookies
        self.cookies_from_browser = cookies_from_browser
        self.logger = logger or NullLogger()

    async def resolve(self, url: str) -> PlaylistInfo:
        """Resolve playlist asynchronously.

        Args:
            url: Playlist URL.

        Returns:
            PlaylistInfo with resolved items.

        Raises:
            VDLPlaylistError: If resolution fails.
        """
        self.logger.info("playlist.resolve.started", url=url)
        return await asyncio.to_thread(self._resolve_sync, url)

    async def inspect_url(self, url: str) -> PlaylistInspection:
        """Inspect whether a URL is a playlist, playlist member, or single item."""
        self.logger.info("playlist.inspect.started", url=url)
        return await asyncio.to_thread(self._inspect_sync, url)

    def _resolve_sync(self, url: str) -> PlaylistInfo:
        """Synchronous playlist resolution using yt-dlp.

        Runs in thread pool and should not be called directly.

        Args:
            url: Playlist URL.

        Returns:
            PlaylistInfo.

        Raises:
            VDLPlaylistError: If yt-dlp not installed or extraction fails.
        """
        try:
            import yt_dlp
        except ImportError as e:
            raise VDLPlaylistError("yt-dlp is not installed") from e

        opts = self._ydl_opts(extract_flat="in_playlist")
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
                if not info:
                    raise VDLPlaylistError(f"No information returned for {url}")

                title = (
                    info.get("title")
                    or info.get("playlist_title")
                    or _derive_title_from_url(url)
                )
                entries = info.get("entries") or []

                items = [
                    PlaylistItem(
                        url=e.get("url") or e.get("original_url") or "",
                        id=e.get("id"),
                        title=_entry_title(e),
                        index=i,
                        duration_seconds=int(e["duration"])
                        if e.get("duration")
                        else None,
                    )
                    for i, e in enumerate(entries)
                    if e and (e.get("url") or e.get("original_url"))
                ]
                playlist = PlaylistInfo(url=url, title=title, items=items)
                self.logger.info(
                    "playlist.resolve.completed", url=url, count=len(items)
                )
                return playlist

        except VDLPlaylistError:
            raise
        except Exception as e:
            self.logger.warning("playlist.resolve.failed", url=url, error=str(e))
            raise VDLPlaylistError(f"Playlist resolution failed: {e}") from e

    def _inspect_sync(self, url: str) -> PlaylistInspection:
        try:
            import yt_dlp
        except ImportError:
            return PlaylistInspection(kind="unsupported_or_unknown")

        opts = self._ydl_opts(extract_flat=True)
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
                if not info:
                    return PlaylistInspection(kind="unsupported_or_unknown")

                entries = info.get("entries") or []
                if entries:
                    return PlaylistInspection(kind="playlist", playlist_url=url)

                playlist_url = (
                    info.get("playlist_url")
                    or info.get("webpage_url")
                    or info.get("original_url")
                )
                if _looks_like_playlist_member(info, url):
                    return PlaylistInspection(
                        kind="playlist_member",
                        playlist_url=playlist_url,
                        entry_url=info.get("webpage_url") or url,
                    )
                return PlaylistInspection(
                    kind="single",
                    entry_url=info.get("webpage_url") or url,
                )
        except Exception:
            return PlaylistInspection(kind="unsupported_or_unknown")

    def _ydl_opts(self, *, extract_flat: bool | str) -> dict:
        opts: dict = {
            "quiet": True,
            "no_warnings": True,
            "extract_flat": extract_flat,
            "logger": _QuietYtDlpLogger(),
        }
        if self.cookies:
            opts["cookiefile"] = self.cookies
        elif self.cookies_from_browser:
            opts["cookiesfrombrowser"] = (self.cookies_from_browser,)
        return opts


def _entry_title(entry: dict) -> str | None:
    """Best-effort title for a flat-extracted playlist entry.

    Prefers the upstream ``title``; falls back to the entry id (which on
    Dailymotion-like sites is more readable than the bare URL) and only
    finally returns None.
    """
    title = entry.get("title")
    if isinstance(title, str) and title.strip():
        return title.strip()
    eid = entry.get("id")
    if isinstance(eid, str) and eid.strip():
        return eid.strip()
    return None


def _derive_title_from_url(url: str) -> str | None:
    """Derive a human-ish playlist title from the URL path as last resort."""
    from urllib.parse import urlparse

    try:
        parsed = urlparse(url)
    except Exception:
        return None
    parts = [p for p in parsed.path.split("/") if p]
    if not parts:
        return None
    last = parts[-1]
    if (
        last.lower() in {"playlist", "playlists", "album", "set", "sets"}
        and len(parts) >= 2
    ):
        last = parts[-2]
    return last.replace("-", " ").replace("_", " ").strip() or None


def _looks_like_playlist_member(info: dict, url: str) -> bool:
    if info.get("playlist") or info.get("playlist_title") or info.get("playlist_id"):
        return True
    webpage_url = info.get("webpage_url") or ""
    original_url = info.get("original_url") or ""
    return any("list=" in candidate for candidate in (url, webpage_url, original_url))


async def resolve_playlist(url: str, resolver: PlaylistResolver) -> PlaylistInfo:
    """Resolve a playlist using the provided resolver.

    Args:
        url: Playlist URL.
        resolver: PlaylistResolver implementation.

    Returns:
        PlaylistInfo.

    Raises:
        VDLPlaylistError: If resolution fails.
    """
    return await resolver.resolve(url)


def playlist_items_to_requests(
    playlist: PlaylistInfo,
    selected_indexes: PlaylistSelection | list[int] | None = None,
    *,
    output_dir: Path | None = None,
    quality: Quality = Quality.BEST,
    force: bool = False,
    write_thumbnail: bool | None = None,
    write_subtitles: bool | None = None,
    subtitle_langs: str | None = None,
) -> list[DownloadRequest]:
    """Convert playlist items to download requests.

    Applies selection and creates DownloadRequest objects for each item.

    Args:
        playlist: PlaylistInfo to convert.
        selected_indexes: Selection spec (PlaylistSelection or int list). Defaults to all.
        output_dir: Output directory for all requests.
        quality: Quality preference.
        force: Force re-download.

    Returns:
        List of DownloadRequest for selected items.
    """
    if isinstance(selected_indexes, PlaylistSelection):
        ordering = playlist.metadata.get("ordering") if playlist.metadata else None
        idx_list = selection_to_indexes(
            selected_indexes, len(playlist.items), ordering=ordering
        )
        items = [playlist.items[i] for i in idx_list if i < len(playlist.items)]
    elif selected_indexes is not None:
        items = [playlist.items[i] for i in selected_indexes if i < len(playlist.items)]
    else:
        items = playlist.items
    return [
        DownloadRequest(
            source=SourceInput(raw=item.url, kind=InputKind.VIDEO_URL),
            output_dir=output_dir,
            quality=quality,
            force=force,
            playlist=True,
            subdirectory=playlist.title,
            source_title=item.title,
            filename_prefix=(f"{item.index:03d}-" if item.index is not None else None),
            write_thumbnail=write_thumbnail,
            write_subtitles=write_subtitles,
            subtitle_langs=subtitle_langs,
        )
        for item in items
        if item.selected
    ]


async def download_playlist(
    url: str,
    resolver: PlaylistResolver,
    downloader: Downloader,
    selected_indexes: list[int] | None = None,
    on_progress: ProgressCallback | None = None,
) -> list[DownloadResult]:
    """Download all items from a playlist.

    Args:
        url: Playlist URL.
        resolver: PlaylistResolver to use.
        downloader: Downloader to use.
        selected_indexes: Optional list of item indexes to download.
        on_progress: Progress callback.

    Returns:
        List of DownloadResult for each item.

    Raises:
        VDLPlaylistError: If resolution fails.
        VDLDownloadError: If download fails.
    """
    playlist = await resolver.resolve(url)
    requests = playlist_items_to_requests(playlist, selected_indexes)
    return [await downloader.download(req, on_progress=on_progress) for req in requests]
