"""Discovery rule definitions and loading."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class SiteRule:
    """Pattern-based config for link discovery on a site.

    Attributes:
        domain: Domain name (used for rule matching).
        video_patterns: Regexes for valid media-candidate URLs.
        pagination_patterns: Regexes for pagination/navigation URLs.
        pagination_text_patterns: Regexes for pagination control text.
        notes: Free-text notes about the rule.
    """

    domain: str
    video_patterns: list[str] = field(default_factory=list)
    pagination_patterns: list[str] = field(default_factory=list)
    pagination_text_patterns: list[str] = field(default_factory=list)
    notes: str | None = None


def load_site_rules(path: Path) -> list[SiteRule]:
    """Load site rules from YAML file.

    Supports both list and dict formats. Returns empty list if file is
    missing or YAML parsing fails.

    Args:
        path: Path to YAML file.

    Returns:
        List of parsed SiteRule objects.
    """
    if not path.exists():
        return []
    try:
        import yaml
    except ImportError:
        return []
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if isinstance(data, list):
        rules = [_rule_from_dict(item) for item in data if isinstance(item, dict)]
        return [r for r in rules if r is not None]
    if isinstance(data, dict):
        rules = [
            _rule_from_dict({"domain": k, **v})
            for k, v in data.items()
            if isinstance(v, dict)
        ]
        return [r for r in rules if r is not None]
    return []


def _rule_from_dict(d: dict) -> Optional[SiteRule]:
    """Parse a single rule from dict (internal).

    Args:
        d: Dictionary with domain and crawl pattern fields.

    Returns:
        SiteRule or None if domain is missing.
    """
    domain = d.get("domain", "").strip()
    if not domain:
        return None
    video_patterns = _coerce_str_list(d.get("video_patterns", d.get("selectors", [])))
    pagination_patterns = _coerce_str_list(
        d.get("pagination_patterns", d.get("pagination", []))
    )
    pagination_text_patterns = _coerce_str_list(d.get("pagination_text_patterns", []))
    return SiteRule(
        domain=domain,
        video_patterns=video_patterns,
        pagination_patterns=pagination_patterns,
        pagination_text_patterns=pagination_text_patterns,
        notes=d.get("notes"),
    )


def _coerce_str_list(value: object) -> list[str]:
    """Coerce value to list of non-empty strings (internal).

    Args:
        value: Single string, list, or other.

    Returns:
        List of stripped non-empty strings.
    """
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list):
        return []
    return [item.strip() for item in value if isinstance(item, str) and item.strip()]
