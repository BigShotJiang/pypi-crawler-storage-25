"""First-run app initialization.

Ensures required files and directories exist before any command runs.
Safe to call on every startup — all operations are idempotent.
"""

from __future__ import annotations

import shutil
from pathlib import Path

from vdl.paths import VDLPaths, bundled_site_rules_path, ensure_paths, get_default_paths


def ensure_app_ready(paths: VDLPaths | None = None) -> None:
    """Create missing app files and directories on first run.

    Creates:
    - XDG directories (config, state, logs, cache, downloads)
    - config.toml with defaults, if missing
    - websites.yaml from bundled copy, if missing and a bundle exists
    - SQLite state DB, if missing

    Safe to call repeatedly; nothing is overwritten if already present.

    Args:
        paths: Override paths (used in tests). Defaults to get_default_paths().
    """
    paths = paths or get_default_paths()

    ensure_paths(paths)
    _ensure_config(paths)
    _ensure_site_rules(paths)
    _ensure_state_db(paths)


def _ensure_config(paths: VDLPaths) -> None:
    """Create the default config file if it does not already exist."""
    if paths.config_file.exists():
        return
    from vdl.config import _default_config, save_config

    save_config(_default_config(), paths.config_file)


def _ensure_site_rules(paths: VDLPaths) -> None:
    """Copy bundled site rules into the user config area if needed."""
    if paths.site_rules_file.exists():
        return
    bundled = bundled_site_rules_path()
    if bundled is None:
        return
    shutil.copy2(bundled, paths.site_rules_file)


def _ensure_state_db(paths: VDLPaths) -> None:
    """Initialize the SQLite state database on first run."""
    from vdl.state import SQLiteStateStore

    SQLiteStateStore(db_path=paths.state_db)
