"""Library-owned default runtime wiring for VDLClient.

This module assembles the default downloader, state store, playlist resolver,
doctor service, and discovery resolver used by ``VDLClient``. It is the single
source of truth for "default" wiring; CLI, library, tools, and MCP all consume
it instead of duplicating the assembly logic.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

from vdl.acquisition import DiscoveryResolver
from vdl.config import ConfigStore, TomlConfigStore, VDLConfig
from vdl.doctor import Doctor
from vdl.downloader import Downloader, DownloadOptions, YtDlpDownloader
from vdl.paths import (
    bundled_site_rules_path,
    find_default_cookie_file,
    get_default_paths,
    resolve_output_dir,
    resolve_site_rules_path,
)
from vdl.playlist import PlaylistResolver, YtDlpPlaylistResolver
from vdl.state import SQLiteStateStore, StateStore

if TYPE_CHECKING:
    from vdl.client import VDLClient


@dataclass
class DefaultComponents:
    """Bundle of default dependencies used to construct a ``VDLClient``."""

    config: VDLConfig
    config_store: ConfigStore
    downloader: Downloader
    playlist_resolver: PlaylistResolver
    state_store: StateStore
    doctor_service: Doctor
    discovery_resolver: DiscoveryResolver | None


def build_default_components(
    output_override: str | None = None,
    config_store: ConfigStore | None = None,
) -> DefaultComponents:
    """Assemble the default dependency set for a ``VDLClient``.

    Args:
        output_override: Optional output directory override (e.g. from CLI ``--output``).
        config_store: Optional injected config store; defaults to ``TomlConfigStore``.

    Returns:
        A ``DefaultComponents`` bundle suitable for constructing a ``VDLClient``.
    """
    from vdl.crawler import SiteRuleDiscoveryResolver
    from vdl.site_rules import load_site_rules

    paths = get_default_paths()
    store = config_store or TomlConfigStore()
    config = store.load()
    output_res = resolve_output_dir(output_override or str(config.output_dir))
    config = replace(config, output_dir=output_res.active_path)

    state_store = SQLiteStateStore(db_path=paths.state_db)
    cookie_file = find_default_cookie_file(paths)
    options = DownloadOptions(
        output_dir=config.output_dir,
        cookies=cookie_file,
        write_thumbnail=config.write_thumbnail,
        write_subtitles=config.write_subtitles,
        subtitle_langs=config.subtitle_langs,
    )
    downloader = YtDlpDownloader(options=options)
    playlist_resolver = YtDlpPlaylistResolver()
    doctor = Doctor()

    discovery_resolver: DiscoveryResolver | None = None
    rules_path = (
        resolve_site_rules_path(config.site_rules_path, paths)
        or bundled_site_rules_path()
    )
    if rules_path is not None and rules_path.exists():
        rules = load_site_rules(rules_path)
        discovery_resolver = SiteRuleDiscoveryResolver(
            site_rules=rules,
            cookie_file=cookie_file,
        )

    return DefaultComponents(
        config=config,
        config_store=store,
        downloader=downloader,
        playlist_resolver=playlist_resolver,
        state_store=state_store,
        doctor_service=doctor,
        discovery_resolver=discovery_resolver,
    )


def build_default_client(output_override: str | None = None) -> VDLClient:
    """Construct a fully wired ``VDLClient`` using default components.

    Args:
        output_override: Optional output directory override.

    Returns:
        A ``VDLClient`` ready for downloads, playlist resolution, and discovery.
    """
    from vdl.client import VDLClient

    c = build_default_components(output_override=output_override)
    return VDLClient(
        config=c.config,
        config_store=c.config_store,
        downloader=c.downloader,
        playlist_resolver=c.playlist_resolver,
        state_store=c.state_store,
        doctor_service=c.doctor_service,
        discovery_resolver=c.discovery_resolver,
    )
