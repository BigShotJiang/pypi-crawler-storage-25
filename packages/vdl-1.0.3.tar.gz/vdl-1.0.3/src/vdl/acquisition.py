"""Acquisition planning and expansion policies.

This module defines the structures for planning downloads from diverse inputs
(single URLs, playlists, link files) and policies for expanding and selecting
items from those sources.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol

from vdl.models import DownloadKind, InputKind, Quality
from vdl.selection import PlaylistSelection


@dataclass(frozen=True)
class AcquisitionItem:
    """Single downloadable item in an acquisition plan.

    Attributes:
        source_url: URL to download.
        output_dir: Target directory.
        quality: Preferred quality.
        kind: Content kind.
        force: Skip idempotency.
        subdirectory: Optional subdirectory within output_dir.
        is_playlist: Whether this URL points to a playlist.
    """

    source_url: str
    output_dir: Path | None = None
    quality: Quality = Quality.BEST
    kind: DownloadKind = DownloadKind.VIDEO
    force: bool = False
    subdirectory: str | None = None
    is_playlist: bool = False


@dataclass(frozen=True)
class AcquisitionPlan:
    """Planned downloads from user input.

    Combines structured items with source classification and optional metadata
    about expansions or discovery.

    Attributes:
        items: List of items to download.
        source_kind: How input was classified.
        total: Number of items.
        metadata: Expansion/discovery/ambiguity metadata.
    """

    items: list[AcquisitionItem]
    source_kind: InputKind
    total: int
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ExpansionPolicy:
    """Configuration for nested expansion behavior.

    Attributes:
        max_playlist_items: Cap on items expanded from any single playlist.
        expand_nested_playlists: Whether to expand playlists inline.
        default_selection: Default selection mode for playlists.
    """

    max_playlist_items: int | None = None
    expand_nested_playlists: bool = False
    default_selection: PlaylistSelection = field(
        default_factory=lambda: PlaylistSelection(mode="all")
    )


class DiscoveryResolver(Protocol):
    """Protocol for resolving generic URLs to downloadable links.

    Implementations crawl or fetch a page and extract direct URLs.
    """

    async def resolve(self, url: str) -> list[str]:
        """Resolve a URL to a list of downloadable links.

        Args:
            url: Page URL to discover links from.

        Returns:
            List of discovered URLs.

        Raises:
            Exceptions from underlying discovery mechanism.
        """
        ...
