"""Playlist selection modes and parsing.

Supports multiple selection strategies for picking items from playlists,
including all, first N, specific indexes, and most-recent policies.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from vdl.errors import VDLSelectionError


SelectionMode = Literal["all", "first_n", "indexes", "most_recent_n"]
"""Valid playlist selection modes."""


@dataclass(frozen=True)
class PlaylistSelection:
    """Specifies how to select items from a playlist.

    Attributes:
        mode: Selection strategy.
        indexes: Set of explicit indexes for 'indexes' mode.
        first_n: Count for 'first_n' mode.
        most_recent_n: Count for 'most_recent_n' mode.
    """

    mode: SelectionMode
    indexes: frozenset[int] | None = None
    first_n: int | None = None
    most_recent_n: int | None = None


def parse_playlist_selection(raw: str, total: int) -> PlaylistSelection:
    """
    Parse a raw selection string into a PlaylistSelection.

    Supported forms:
      - "" or "all"           → select all items
      - "first:N"             → select first N items
      - "most_recent:N"       → select N most-recent items (requires reliable ordering)
      - "0,2,4"               → discrete indexes
      - "0-3"                 → range (inclusive)
      - "0-2,5,8-9"           → mixed ranges and discrete indexes

    Falls back to "all" on invalid input.
    """
    raw = raw.strip()
    if not raw or raw == "all":
        return PlaylistSelection(mode="all")

    if raw.startswith("first:"):
        try:
            n = int(raw[6:])
            return PlaylistSelection(mode="first_n", first_n=max(0, n))
        except ValueError:
            return PlaylistSelection(mode="all")

    if raw.startswith("most_recent:"):
        try:
            n = int(raw[len("most_recent:") :])
            return PlaylistSelection(mode="most_recent_n", most_recent_n=max(0, n))
        except ValueError:
            return PlaylistSelection(mode="all")

    try:
        indexes: set[int] = set()
        for part in raw.split(","):
            part = part.strip()
            if "-" in part:
                start_s, end_s = part.split("-", 1)
                start, end = int(start_s.strip()), int(end_s.strip())
                indexes.update(range(start, end + 1))
            else:
                indexes.add(int(part))
        return PlaylistSelection(mode="indexes", indexes=frozenset(indexes))
    except (ValueError, TypeError):
        return PlaylistSelection(mode="all")


def selection_to_indexes(
    sel: PlaylistSelection,
    total: int,
    *,
    ordering: str | None = None,
) -> list[int]:
    """Resolve a PlaylistSelection to a sorted list of in-bounds indexes.

    Args:
        sel: Selection specification.
        total: Total items in playlist.
        ordering: How items are ordered (for most_recent validation):
            - "chronological_desc": newest first (e.g. channel uploads).
            - "chronological_asc": oldest first.
            - None/unknown: most_recent_n is rejected as untrustworthy.

    Returns:
        Sorted list of in-bounds indexes to select.

    Raises:
        VDLSelectionError: If most_recent_n is used without reliable ordering.
    """
    if sel.mode == "all":
        return list(range(total))
    if sel.mode == "first_n":
        n = min(sel.first_n or 0, total)
        return list(range(n))
    if sel.mode == "indexes" and sel.indexes is not None:
        return sorted(i for i in sel.indexes if 0 <= i < total)
    if sel.mode == "most_recent_n":
        n = sel.most_recent_n or 0
        if total == 0 or n == 0:
            return []
        if ordering == "chronological_desc":
            return list(range(min(n, total)))
        if ordering == "chronological_asc":
            return list(range(max(0, total - n), total))
        raise VDLSelectionError(
            "most_recent:N requires reliable ordering metadata; "
            "playlist ordering is unknown for this source."
        )
    return list(range(total))
