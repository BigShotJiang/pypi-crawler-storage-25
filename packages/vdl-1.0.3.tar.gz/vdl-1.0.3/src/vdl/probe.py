"""Quick yt-dlp probe to decide if a URL is a direct media URL.

When VDL gets a URL outside its hard-coded "known platforms" list, the user
wants us to first ask yt-dlp whether it recognizes the URL — yt-dlp ships
~1500 extractors, so this catches plenty of media URLs that the crawler
would otherwise treat as listing pages.

Strategy:
  1. Match the URL against yt-dlp's non-Generic extractors locally.
     This is offline and fast: if any specific extractor accepts the URL,
     it's almost certainly a direct media URL on a supported site.
  2. The Generic extractor is excluded because it accepts everything
     (its job is to scrape arbitrary HTML), so it can't disambiguate
     "media page" from "listing page".

A negative probe means "not obviously media" — we then fall through to
the crawler/discovery flow.
"""

from __future__ import annotations


def is_known_media_url(url: str) -> bool:
    """Return True when a non-Generic yt-dlp extractor matches ``url``.

    Returns False on any import or matching error so callers can safely
    fall through to crawling.
    """
    try:
        from yt_dlp.extractor import gen_extractor_classes
    except Exception:
        return False

    try:
        for cls in gen_extractor_classes():
            ie_key = getattr(cls, "ie_key", lambda: "")()
            if ie_key == "Generic":
                continue
            try:
                if cls.suitable(url):
                    return True
            except Exception:
                continue
    except Exception:
        return False
    return False
