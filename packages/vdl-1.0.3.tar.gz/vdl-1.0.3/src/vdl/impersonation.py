"""Detect why yt-dlp's browser-impersonation backend is unavailable.

yt-dlp registers its CurlCFFI request handler only when both ``curl_cffi``
is importable *and* its version is in the range yt-dlp accepts. When the
range drifts (e.g. ``curl-cffi`` 0.15+ with yt-dlp 2026.03.x), the
handler silently fails to register and Dailymotion-style extractors
report "no impersonate targets available". This module gives the rest
of the codebase a one-line answer to "why" so we can surface a hint
that tells the user exactly how to recover in this repo.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

ImpersonationStatus = Literal["available", "version_mismatch", "missing", "unknown"]


@dataclass(frozen=True)
class ImpersonationCheck:
    """Result of probing yt-dlp's impersonation backend.

    Attributes:
        status: Coarse classification used to pick a remediation hint.
        detail: Human-readable detail (the underlying ImportError text
            from yt-dlp when the version range is wrong, or a short
            note when curl_cffi isn't installed at all).
    """

    status: ImpersonationStatus
    detail: str | None


def probe_impersonation() -> ImpersonationCheck:
    """Return whether yt-dlp can impersonate browsers on this install.

    No I/O. Cheap enough to call from an error path. Does not raise.
    """
    try:
        import curl_cffi  # noqa: F401
    except ImportError as e:
        return ImpersonationCheck(status="missing", detail=str(e))
    except Exception as e:
        return ImpersonationCheck(status="unknown", detail=str(e))

    try:
        from yt_dlp.networking import _curlcffi as _ytdlp_curlcffi  # noqa: F401
    except ImportError as e:
        # yt-dlp's loader rejects out-of-range curl_cffi with a precise
        # message — surface it verbatim so users see the version range.
        return ImpersonationCheck(status="version_mismatch", detail=str(e))
    except Exception as e:
        return ImpersonationCheck(status="unknown", detail=str(e))

    return ImpersonationCheck(status="available", detail=None)
