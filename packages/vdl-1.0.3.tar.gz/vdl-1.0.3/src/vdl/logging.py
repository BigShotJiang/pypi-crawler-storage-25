"""Logging protocol and implementations.

Defines the Logger interface for structured logging throughout VDL.
"""

from __future__ import annotations

from typing import Any, Protocol


class Logger(Protocol):
    """Protocol for structured logging.

    Defines interface for event logging with contextual fields.
    Implementations should support debug, info, warning, and error levels.
    """

    def debug(self, event: str, **fields: Any) -> None:
        """Log debug-level message.

        Args:
            event: Event name/description.
            **fields: Additional contextual fields.
        """
        ...

    def info(self, event: str, **fields: Any) -> None:
        """Log info-level message.

        Args:
            event: Event name/description.
            **fields: Additional contextual fields.
        """
        ...

    def warning(self, event: str, **fields: Any) -> None:
        """Log warning-level message.

        Args:
            event: Event name/description.
            **fields: Additional contextual fields.
        """
        ...

    def error(self, event: str, **fields: Any) -> None:
        """Log error-level message.

        Args:
            event: Event name/description.
            **fields: Additional contextual fields.
        """
        ...


class NullLogger:
    """No-op logger that discards all messages.

    Used as default logger to avoid null-check conditionals throughout the codebase.
    """

    def debug(self, event: str, **fields: Any) -> None:
        """Discard debug message.

        Args:
            event: Event name (ignored).
            **fields: Contextual fields (ignored).
        """
        pass

    def info(self, event: str, **fields: Any) -> None:
        """Discard info message.

        Args:
            event: Event name (ignored).
            **fields: Contextual fields (ignored).
        """
        pass

    def warning(self, event: str, **fields: Any) -> None:
        """Discard warning message.

        Args:
            event: Event name (ignored).
            **fields: Contextual fields (ignored).
        """
        pass

    def error(self, event: str, **fields: Any) -> None:
        """Discard error message.

        Args:
            event: Event name (ignored).
            **fields: Contextual fields (ignored).
        """
        pass
