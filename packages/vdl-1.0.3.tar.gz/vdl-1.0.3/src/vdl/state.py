from __future__ import annotations

from dataclasses import dataclass
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Iterator, Protocol

from vdl.logging import Logger, NullLogger
from vdl.models import (
    DownloadResult,
    DownloadStatus,
    Quality,
    StatusRecord,
    build_request_key,
)
from vdl.progress import DownloadProgress
from vdl.serialization import format_speed_bps


class StateStore(Protocol):
    def record_started(
        self,
        id: str,
        source_url: str,
        command: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None: ...
    def record_progress(
        self,
        progress: DownloadProgress,
        source_url: str,
        command: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None: ...
    def record_completed(self, result: DownloadResult) -> None: ...
    def record_failed(
        self,
        id: str,
        source_url: str,
        error: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None: ...
    def record_cancelled(
        self,
        id: str,
        source_url: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None: ...
    def find_by_url(self, source_url: str) -> StatusRecord | None: ...
    def find_by_request(
        self, source_url: str, quality: Quality
    ) -> StatusRecord | None: ...
    def get_status(self, id: str) -> StatusRecord | None: ...
    def list_recent(self, limit: int = 20) -> list[StatusRecord]: ...


@dataclass(frozen=True)
class ReconciliationEntry:
    id: str
    source_url: str
    status: str
    output_path: Path | None


@dataclass(frozen=True)
class ReconciliationReport:
    entries: list[ReconciliationEntry]


def reconcile_status_records(
    records: list[StatusRecord],
    *,
    logger: Logger | None = None,
) -> ReconciliationReport:
    active_logger = logger or NullLogger()
    entries: list[ReconciliationEntry] = []
    for record in records:
        if record.output_path is None:
            status = "no_output_path"
        elif record.output_path.exists():
            status = "exists"
        else:
            status = "missing"
        entries.append(
            ReconciliationEntry(
                id=record.id,
                source_url=record.source_url,
                status=status,
                output_path=record.output_path,
            )
        )
    active_logger.info("reconciliation.completed", checked=len(entries))
    return ReconciliationReport(entries=entries)


class SQLiteStateStore:
    # Adapted from vdl_core/state.py::StateStore
    def __init__(self, db_path: Path | None = None) -> None:
        if db_path is None:
            from vdl.paths import get_default_paths

            db_path = get_default_paths().state_db
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS downloads (
                    id TEXT PRIMARY KEY,
                    source_url TEXT NOT NULL,
                    request_key TEXT,
                    quality TEXT,
                    command TEXT NOT NULL,
                    status TEXT NOT NULL,
                    output_path TEXT,
                    error TEXT,
                    percent REAL,
                    speed TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_downloads_source_url
                ON downloads(source_url)
                """
            )
            columns = {
                row["name"]
                for row in conn.execute("PRAGMA table_info(downloads)").fetchall()
            }
            if "request_key" not in columns:
                conn.execute("ALTER TABLE downloads ADD COLUMN request_key TEXT")
            if "quality" not in columns:
                conn.execute("ALTER TABLE downloads ADD COLUMN quality TEXT")
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_downloads_request_key
                ON downloads(request_key)
                """
            )

    def record_started(
        self,
        id: str,
        source_url: str,
        command: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None:
        now = datetime.now(UTC).isoformat()
        effective_request_key = request_key or (
            build_request_key(source_url, quality) if quality else None
        )
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO downloads
                (id, source_url, request_key, quality, command, status, output_path, error, percent, speed, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    id,
                    source_url,
                    effective_request_key,
                    quality.value if quality else None,
                    command,
                    DownloadStatus.STARTING.value,
                    None,
                    None,
                    0.0,
                    None,
                    now,
                    now,
                ),
            )

    def record_progress(
        self,
        progress: DownloadProgress,
        source_url: str,
        command: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None:
        now = datetime.now(UTC).isoformat()
        effective_request_key = request_key or (
            build_request_key(source_url, quality) if quality else None
        )
        with self._connect() as conn:
            existing = conn.execute(
                "SELECT created_at, quality, request_key FROM downloads WHERE id = ?",
                (progress.id,),
            ).fetchone()
            created_at = existing["created_at"] if existing else now
            existing_quality = existing["quality"] if existing else None
            existing_request_key = existing["request_key"] if existing else None
            conn.execute(
                """
                INSERT OR REPLACE INTO downloads
                (id, source_url, request_key, quality, command, status, output_path, error, percent, speed, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    progress.id,
                    source_url,
                    effective_request_key or existing_request_key,
                    quality.value if quality else existing_quality,
                    command,
                    progress.status.value,
                    str(progress.output_path) if progress.output_path else None,
                    progress.error,
                    progress.percent,
                    format_speed_bps(progress.speed_bps),
                    created_at,
                    now,
                ),
            )

    def record_completed(self, result: DownloadResult) -> None:
        now = datetime.now(UTC).isoformat()
        with self._connect() as conn:
            existing = conn.execute(
                "SELECT created_at, command, quality, request_key FROM downloads WHERE id = ?",
                (result.id,),
            ).fetchone()
            created_at = existing["created_at"] if existing else now
            command = existing["command"] if existing else "download"
            conn.execute(
                """
                INSERT OR REPLACE INTO downloads
                (id, source_url, request_key, quality, command, status, output_path, error, percent, speed, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    result.id,
                    result.source_url,
                    result.request_key
                    or (existing["request_key"] if existing else None),
                    result.quality.value
                    if result.quality
                    else (existing["quality"] if existing else None),
                    command,
                    DownloadStatus.COMPLETED.value,
                    str(result.output_path) if result.output_path else None,
                    None,
                    100.0,
                    None,
                    created_at,
                    now,
                ),
            )

    def record_failed(
        self,
        id: str,
        source_url: str,
        error: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None:
        now = datetime.now(UTC).isoformat()
        effective_request_key = request_key or (
            build_request_key(source_url, quality) if quality else None
        )
        with self._connect() as conn:
            existing = conn.execute(
                "SELECT created_at, command, quality, request_key FROM downloads WHERE id = ?",
                (id,),
            ).fetchone()
            created_at = existing["created_at"] if existing else now
            command = existing["command"] if existing else "download"
            conn.execute(
                """
                INSERT OR REPLACE INTO downloads
                (id, source_url, request_key, quality, command, status, output_path, error, percent, speed, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    id,
                    source_url,
                    effective_request_key
                    or (existing["request_key"] if existing else None),
                    quality.value
                    if quality
                    else (existing["quality"] if existing else None),
                    command,
                    DownloadStatus.FAILED.value,
                    None,
                    error,
                    None,
                    None,
                    created_at,
                    now,
                ),
            )

    def record_cancelled(
        self,
        id: str,
        source_url: str,
        *,
        quality: Quality | None = None,
        request_key: str | None = None,
    ) -> None:
        now = datetime.now(UTC).isoformat()
        effective_request_key = request_key or (
            build_request_key(source_url, quality) if quality else None
        )
        with self._connect() as conn:
            existing = conn.execute(
                "SELECT created_at, command, quality, request_key FROM downloads WHERE id = ?",
                (id,),
            ).fetchone()
            created_at = existing["created_at"] if existing else now
            command = existing["command"] if existing else "download"
            conn.execute(
                """
                INSERT OR REPLACE INTO downloads
                (id, source_url, request_key, quality, command, status, output_path, error, percent, speed, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    id,
                    source_url,
                    effective_request_key
                    or (existing["request_key"] if existing else None),
                    quality.value
                    if quality
                    else (existing["quality"] if existing else None),
                    command,
                    DownloadStatus.CANCELLED.value,
                    None,
                    None,
                    None,
                    None,
                    created_at,
                    now,
                ),
            )

    def find_by_url(self, source_url: str) -> StatusRecord | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM downloads WHERE source_url = ? ORDER BY updated_at DESC LIMIT 1",
                (source_url,),
            ).fetchone()
            return _row_to_record(row) if row else None

    def find_by_request(self, source_url: str, quality: Quality) -> StatusRecord | None:
        request_key = build_request_key(source_url, quality)
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM downloads WHERE request_key = ? ORDER BY updated_at DESC LIMIT 1",
                (request_key,),
            ).fetchone()
            return _row_to_record(row) if row else None

    def get_status(self, id: str) -> StatusRecord | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM downloads WHERE id = ?", (id,)).fetchone()
            return _row_to_record(row) if row else None

    def list_recent(self, limit: int = 20) -> list[StatusRecord]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM downloads ORDER BY updated_at DESC LIMIT ?", (limit,)
            ).fetchall()
            return [_row_to_record(row) for row in rows]


def _row_to_record(row: sqlite3.Row) -> StatusRecord:
    return StatusRecord(
        id=row["id"],
        source_url=row["source_url"],
        status=DownloadStatus(row["status"]),
        quality=Quality(row["quality"]) if row["quality"] else None,
        request_key=row["request_key"],
        output_path=Path(row["output_path"]) if row["output_path"] else None,
        error=row["error"],
        percent=row["percent"],
        updated_at=datetime.fromisoformat(row["updated_at"]),
    )
