from __future__ import annotations

import platform
import shutil
import subprocess
from dataclasses import dataclass

from vdl.models import DoctorReport


def _vdl_version() -> str:
    """Return the installed VDL package version, or a local fallback."""
    try:
        from importlib.metadata import PackageNotFoundError, version

        try:
            return version("vdl")
        except PackageNotFoundError:
            return "0.0.0+local"
    except Exception:
        return "0.0.0+local"


@dataclass(frozen=True)
class DependencyCheck:
    """Status for a single dependency probe."""

    name: str
    available: bool
    version: str | None = None
    path: str | None = None
    message: str | None = None


def _probe_version(executable: str) -> DependencyCheck:
    """Probe an executable by asking it for its version string."""
    path = shutil.which(executable)
    if path is None:
        return DependencyCheck(
            name=executable, available=False, message=f"{executable} not found in PATH"
        )
    try:
        result = subprocess.run(
            [executable, "-version"],
            capture_output=True,
            text=True,
            check=True,
            timeout=5,
        )
        first_line = result.stdout.splitlines()[0] if result.stdout else ""
        ver: str | None = None
        if "version" in first_line:
            parts = first_line.split("version", 1)
            if len(parts) > 1:
                ver = parts[1].strip().split(" ")[0]
        return DependencyCheck(name=executable, available=True, version=ver, path=path)
    except Exception as e:
        return DependencyCheck(
            name=executable, available=False, path=path, message=str(e)
        )


def check_ffmpeg() -> DependencyCheck:
    """Check whether `ffmpeg` is available on PATH."""
    return _probe_version("ffmpeg")


def check_ffprobe() -> DependencyCheck:
    """Check whether `ffprobe` is available on PATH."""
    return _probe_version("ffprobe")


def check_ytdlp() -> DependencyCheck:
    """Check whether `yt-dlp` is importable and report its version."""
    try:
        import yt_dlp as _yt_dlp

        return DependencyCheck(
            name="yt-dlp", available=True, version=_yt_dlp.version.__version__
        )
    except ImportError as e:
        return DependencyCheck(name="yt-dlp", available=False, message=str(e))
    except Exception as e:
        return DependencyCheck(name="yt-dlp", available=False, message=str(e))


def check_mcp_command() -> DependencyCheck:
    """Check whether the `vdl-mcp` executable is available on PATH."""
    path = shutil.which("vdl-mcp")
    if path is None:
        return DependencyCheck(
            name="vdl-mcp", available=False, message="vdl-mcp not found in PATH"
        )
    return DependencyCheck(name="vdl-mcp", available=True, path=path)


def _ffmpeg_install_hint() -> str:
    """Return a platform-specific suggestion for installing ffmpeg."""
    system = platform.system()
    if system == "Darwin":
        return "brew install ffmpeg"
    if system == "Linux":
        return "sudo apt install ffmpeg  # or: sudo dnf install ffmpeg / sudo pacman -S ffmpeg"
    return "Install ffmpeg from https://ffmpeg.org/download.html"


def run_doctor() -> DoctorReport:
    """Run the full environment check and summarize repair actions."""
    from vdl.config import load_config
    from vdl.paths import _is_writable_dir, get_default_paths

    ffmpeg = check_ffmpeg()
    ffprobe = check_ffprobe()
    ytdlp = check_ytdlp()
    mcp = check_mcp_command()

    paths = get_default_paths()

    config_ok = True
    try:
        load_config()
    except Exception:
        config_ok = False

    config_dir_ok = _is_writable_dir(paths.config_dir)
    state_dir_ok = _is_writable_dir(paths.state_dir)
    cache_dir_ok = _is_writable_dir(paths.cache_dir)
    output_dir_ok = _is_writable_dir(paths.downloads_dir)
    state_ok = state_dir_ok

    repairs: list[str] = []
    if not ffmpeg.available:
        repairs.append(f"Install ffmpeg: {_ffmpeg_install_hint()}")
    if not ffprobe.available:
        repairs.append(f"Install ffprobe (ships with ffmpeg): {_ffmpeg_install_hint()}")
    if not ytdlp.available:
        repairs.append(
            "Reinstall vdl to repair yt-dlp: pipx reinstall vdl  # or: uv tool install --force vdl"
        )
    if not mcp.available:
        repairs.append(
            "Install MCP support: pipx install 'vdl[mcp]'  # then restart your AI host"
        )
    if not config_dir_ok:
        repairs.append(f"Create writable config dir: mkdir -p {paths.config_dir}")
    if not state_dir_ok:
        repairs.append(f"Create writable state dir: mkdir -p {paths.state_dir}")
    if not cache_dir_ok:
        repairs.append(f"Create writable cache dir: mkdir -p {paths.cache_dir}")
    if not output_dir_ok:
        repairs.append(f"Create writable downloads dir: mkdir -p {paths.downloads_dir}")

    return DoctorReport(
        version=_vdl_version(),
        ffmpeg_available=ffmpeg.available,
        ffprobe_available=ffprobe.available,
        ytdlp_available=ytdlp.available,
        mcp_available=mcp.available,
        config_ok=config_ok,
        state_ok=state_ok,
        config_dir_ok=config_dir_ok,
        state_dir_ok=state_dir_ok,
        cache_dir_ok=cache_dir_ok,
        output_dir_ok=output_dir_ok,
        repairs=repairs,
        details={
            "ffmpeg": {
                "version": ffmpeg.version,
                "path": ffmpeg.path,
                "message": ffmpeg.message,
            },
            "ffprobe": {
                "version": ffprobe.version,
                "path": ffprobe.path,
                "message": ffprobe.message,
            },
            "ytdlp": {"version": ytdlp.version, "message": ytdlp.message},
            "mcp": {"path": mcp.path, "message": mcp.message},
            "paths": {
                "config_dir": str(paths.config_dir),
                "config_file": str(paths.config_file),
                "state_dir": str(paths.state_dir),
                "state_db": str(paths.state_db),
                "cache_dir": str(paths.cache_dir),
                "downloads_dir": str(paths.downloads_dir),
            },
        },
    )


class Doctor:
    """Convenience wrapper that exposes the doctor checks as methods."""

    def check_ffmpeg(self) -> DependencyCheck:
        return check_ffmpeg()

    def check_ffprobe(self) -> DependencyCheck:
        return check_ffprobe()

    def check_ytdlp(self) -> DependencyCheck:
        return check_ytdlp()

    def check_mcp_command(self) -> DependencyCheck:
        return check_mcp_command()

    def run(self) -> DoctorReport:
        return run_doctor()
