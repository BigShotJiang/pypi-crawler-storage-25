"""Interactive CLI mode for VDL using Rich.

Provides user-friendly prompts and real-time progress display for downloads.
"""

from __future__ import annotations

import asyncio
import re
import signal
from dataclasses import dataclass, field
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

from vdl.acquisition import AcquisitionPlan
from vdl.cancellation import CancellationController, CancellationToken
from vdl.client import VDLClient
from vdl.error_translation import translate_error
from vdl.models import DownloadResult, DownloadStatus, InputKind, PlaylistInfo, Quality
from vdl.progress import RichProgressEmitter
from vdl.prompt_utils import (
    expand_user_path,
    prompt_for_directory,
    prompt_for_directory_async,
    read_line,
    read_line_async,
    sanitize_pasted_input,
)
from vdl.selection import (
    PlaylistSelection,
    parse_playlist_selection,
    selection_to_indexes,
)
from vdl.urls import analyze_input, normalize_url, youtube_video_id

_BANNER = (
    " _    ______  _\n"
    "| |  / /  _ \\| |\n"
    "| | / /| | | | |\n"
    "| |/ / | |_| | |\n"
    "|___/  |____/|_|\n"
    "\n"
    "Video Downloader\n"
    "Paste a URL (YouTube, Vimeo, Dailymotion, ...), a path to a .txt link "
    "list, or 'quit' to exit."
)
_QUIT_WORDS = {"quit", "q", "exit", "bye"}
_PROMPT_STYLE = "[bold cyan]{label}[/bold cyan]"

_QUALITY_CHOICES = ["best", "2160p", "1440p", "1080p", "720p", "480p", "audio"]
_QUALITY_MAP: dict[str, Quality] = {
    "best": Quality.BEST,
    "medium": Quality.MEDIUM,
    "low": Quality.LOW,
    "2160p": Quality.P2160,
    "1440p": Quality.P1440,
    "1080p": Quality.P1080,
    "720p": Quality.P720,
    "480p": Quality.P480,
    "2160": Quality.P2160,
    "1440": Quality.P1440,
    "1080": Quality.P1080,
    "720": Quality.P720,
    "480": Quality.P480,
    "audio": Quality.AUDIO,
    "": Quality.BEST,
}


@dataclass(frozen=True)
class DownloadOptions:
    """Quality + output + sidecar choices captured from a single prompt round."""

    quality: Quality
    output_dir: Path | None
    write_thumbnail: bool
    write_subtitles: bool
    subtitle_langs: str = "en"


def prompt_for_url(console: Console | None = None) -> str:
    """Prompt user for URL or local link/media file path.

    On a real terminal, supports ↑/↓ history (persisted under the VDL
    state dir) and Tab path completion via prompt_toolkit. Pasted input
    is sanitized so users who accidentally include the prompt label
    (e.g. ``URL or file path https://...``) or wrap the URL in quotes
    still get a usable result.
    """
    console = console or Console()
    raw = read_line("URL or local file path: ", history_name="url")
    return sanitize_pasted_input(raw)


async def prompt_for_url_async(console: Console | None = None) -> str:
    console = console or Console()
    raw = await read_line_async("URL or local file path: ", history_name="url")
    return sanitize_pasted_input(raw)


def _normalize_quality(raw: str) -> Quality | None:
    return _QUALITY_MAP.get(raw.strip().lower())


def _prompt_quality_sync(console: Console) -> Quality:
    console.print("  [dim]Quality options: " + " · ".join(_QUALITY_CHOICES) + "[/dim]")
    while True:
        raw = (
            Prompt.ask(
                "Quality",
                default="best",
                choices=_QUALITY_CHOICES,
                console=console,
                show_choices=False,
            )
            .strip()
            .lower()
        )
        quality = _normalize_quality(raw)
        if quality is not None:
            return quality
        console.print("[red]Please select one of the available options.[/red]")


async def _prompt_quality(console: Console) -> Quality:
    console.print("  [dim]Quality options: " + " · ".join(_QUALITY_CHOICES) + "[/dim]")
    while True:
        raw = (
            await read_line_async(
                "Quality (best): ",
                history_name="quality",
                choices=_QUALITY_CHOICES,
            )
        ).strip()
        quality = _normalize_quality(raw or "best")
        if quality is not None:
            return quality
        console.print("[red]Please select one of the available options.[/red]")


def _prompt_yes_no(console: Console, label: str, default: bool = True) -> bool:
    suffix = " [Y/n]" if default else " [y/N]"
    raw = console.input(f"{_PROMPT_STYLE.format(label=label)}{suffix} ").strip().lower()
    if not raw:
        return default
    return raw in {"y", "yes"}


async def _prompt_yes_no_async(
    console: Console, label: str, default: bool = True
) -> bool:
    suffix = " [Y/n]" if default else " [y/N]"
    while True:
        raw = (
            (
                await read_line_async(
                    f"{label}{suffix} ",
                    history_name="yes_no",
                    choices=["y", "yes", "n", "no"],
                )
            )
            .strip()
            .lower()
        )
        if not raw:
            return default
        if raw in {"y", "yes"}:
            return True
        if raw in {"n", "no"}:
            return False
        console.print("[red]Please answer yes or no.[/red]")


def prompt_for_download_options(
    url: str,
    console: Console | None = None,
    default_output_dir: Path | None = None,
) -> DownloadOptions:
    """Prompt user for quality, output directory, and sidecar preferences.

    Args:
        url: Source URL (for context only).
        console: Optional Rich Console.
        default_output_dir: Resolved default directory shown in the prompt
            so the user knows what "default" actually is.

    Returns:
        DownloadOptions with the captured choices.
    """
    console = console or Console()
    quality = _prompt_quality_sync(console)
    try:
        output_dir = prompt_for_directory("Output directory", default_output_dir)
    except (EOFError, KeyboardInterrupt):
        raise
    write_thumbnail = _prompt_yes_no(console, "Save thumbnail?", default=True)
    write_subtitles = _prompt_yes_no(console, "Save subtitles (.vtt)?", default=True)
    return DownloadOptions(
        quality=quality,
        output_dir=output_dir,
        write_thumbnail=write_thumbnail,
        write_subtitles=write_subtitles,
    )


async def prompt_for_download_options_async(
    url: str,
    console: Console | None = None,
    default_output_dir: Path | None = None,
) -> DownloadOptions:
    console = console or Console()
    quality = await _prompt_quality(console)
    output_dir = await prompt_for_directory_async(
        "Output directory", default_output_dir
    )
    write_thumbnail = await _prompt_yes_no_async(
        console, "Save thumbnail?", default=True
    )
    write_subtitles = await _prompt_yes_no_async(
        console, "Save subtitles (.vtt)?", default=True
    )
    return DownloadOptions(
        quality=quality,
        output_dir=output_dir,
        write_thumbnail=write_thumbnail,
        write_subtitles=write_subtitles,
    )


def prompt_for_discovered_selection(
    total: int, console: Console | None = None
) -> PlaylistSelection:
    """Prompt user to select items from discovered links."""
    console = console or Console()
    raw = console.input(
        f"{_PROMPT_STYLE.format(label='Select items (e.g. 0,1,2 or first:5 or Enter=all)')} "
    ).strip()
    return parse_playlist_selection(raw, total)


async def prompt_for_discovered_selection_async(
    total: int, console: Console | None = None
) -> PlaylistSelection:
    console = console or Console()
    while True:
        raw = (
            await read_line_async(
                "Select items (e.g. 0,1,2 or first:5 or Enter=all): ",
                history_name="selection",
            )
        ).strip()
        if _looks_like_valid_selection(raw):
            return parse_playlist_selection(raw, total)
        console.print(
            "[red]Enter indexes like 0,2,4, a range like 0-3, first:5, or press Enter for all.[/red]"
        )


def prompt_for_playlist_selection(
    playlist: PlaylistInfo, console: Console | None = None
) -> PlaylistSelection:
    """Display playlist and prompt user to select items."""
    console = console or Console()
    console.print(
        f"\nPlaylist: {playlist.title or '(untitled)'} — {len(playlist.items)} items"
    )
    for item in playlist.items:
        console.print(f"  [{item.index}] {item.title or item.url}")
    raw = console.input(
        f"{_PROMPT_STYLE.format(label='Select items (e.g. 0,1,2 or first:5 or Enter=all)')} "
    ).strip()
    return parse_playlist_selection(raw, len(playlist.items))


async def prompt_for_playlist_selection_async(
    playlist: PlaylistInfo, console: Console | None = None
) -> PlaylistSelection:
    console = console or Console()
    console.print(
        f"\nPlaylist: {playlist.title or '(untitled)'} — {len(playlist.items)} items"
    )
    for item in playlist.items:
        console.print(f"  [{item.index}] {item.title or item.url}")
    while True:
        raw = (
            await read_line_async(
                "Select items (e.g. 0,1,2 or first:5 or Enter=all): ",
                history_name="selection",
            )
        ).strip()
        if _looks_like_valid_selection(raw):
            return parse_playlist_selection(raw, len(playlist.items))
        console.print(
            "[red]Enter indexes like 0,2,4, a range like 0-3, first:5, or press Enter for all.[/red]"
        )


def prompt_for_playlist_member_choice(console: Console | None = None) -> str:
    """Ask whether to download a single video or the whole playlist.

    Returns ``"playlist"`` if the user chose the playlist, otherwise
    ``"single"`` (default).
    """
    console = console or Console()
    raw = (
        console.input(
            f"{_PROMPT_STYLE.format(label='This URL is part of a playlist. Download:')}\n"
            "  [s] just this single video  (default)\n"
            "  [p] all videos in the playlist\n"
            "  Choice [s/p, Enter=s]: "
        )
        .strip()
        .lower()
    )
    if raw in {"p", "playlist"}:
        return "playlist"
    return "single"


async def prompt_for_playlist_member_choice_async(
    console: Console | None = None,
) -> str:
    console = console or Console()
    while True:
        console.print(
            "[bold cyan]This URL is part of a playlist. Download:[/bold cyan]"
        )
        console.print("  [s] just this single video  (default)")
        console.print("  [p] all videos in the playlist")
        raw = (
            (
                await read_line_async(
                    "Choice [s/p, Enter=s]: ",
                    history_name="playlist_choice",
                    choices=["s", "single", "p", "playlist", "all"],
                )
            )
            .strip()
            .lower()
        )
        if not raw or raw in {"s", "single"}:
            return "single"
        if raw in {"p", "playlist", "a", "all"}:
            return "playlist"
        console.print(
            "[red]Choose s for the single video or p for the full playlist.[/red]"
        )


def _print_results(
    results: list[DownloadResult], console: Console | None = None
) -> None:
    """Display download results in a formatted table.

    Errors are translated and printed below; if any failure was caused by
    a transient network issue, a one-line resume hint is shown so the
    user doesn't have to copy-paste the URL again.
    """
    console = console or Console()
    table = Table(title="Results", expand=True)
    table.add_column("Status", style="cyan", width=12)
    table.add_column("Source", style="white")
    table.add_column("Output", style="green")
    for result in results:
        table.add_row(
            result.status.value,
            result.source_url,
            str(result.output_path) if result.output_path else "",
        )
    console.print(table)
    saw_network_loss = False
    for result in results:
        if not result.error:
            continue
        category = (result.metadata or {}).get("error_category")
        if category == "network_lost":
            saw_network_loss = True
        translated = translate_error(result.error)
        console.print(f"[red]Error:[/red] {translated.message}")
        if translated.hint:
            console.print(f"  [yellow]Hint:[/yellow] {translated.hint}")
    if saw_network_loss:
        console.print(
            "\n[yellow]Looks like the connection dropped mid-download. "
            "Re-paste the same URL when you're back online — already "
            "completed items will be skipped automatically.[/yellow]"
        )


def _find_index_for_url(playlist: PlaylistInfo, url: str) -> int | None:
    for idx, item in enumerate(playlist.items):
        if item.url and normalize_url(item.url) == normalize_url(url):
            return idx
    target = youtube_video_id(url)
    if not target:
        return None
    for idx, item in enumerate(playlist.items):
        if item.id and item.id == target:
            return idx
        candidate = youtube_video_id(item.url) if item.url else None
        if candidate == target:
            return idx
    return None


def prompt_for_direct_or_crawl(console: Console | None = None) -> str:
    console = console or Console()
    choice = (
        console.input(
            f"{_PROMPT_STYLE.format(label='Download (d)irectly or (c)rawl page for links? (Enter=direct)')} "
        )
        .strip()
        .lower()
    )
    return "crawl" if choice == "c" else "direct"


async def prompt_for_direct_or_crawl_async(console: Console | None = None) -> str:
    console = console or Console()
    while True:
        raw = (
            (
                await read_line_async(
                    "Download directly or crawl page for links? [d/c, Enter=d]: ",
                    history_name="direct_or_crawl",
                    choices=["d", "direct", "c", "crawl"],
                )
            )
            .strip()
            .lower()
        )
        if not raw or raw in {"d", "direct"}:
            return "direct"
        if raw in {"c", "crawl"}:
            return "crawl"
        console.print("[red]Choose d for direct download or c to crawl the page.[/red]")


def _looks_like_valid_selection(raw: str) -> bool:
    raw = raw.strip().lower()
    if not raw or raw == "all":
        return True
    if raw.startswith("first:") or raw.startswith("most_recent:"):
        _, _, tail = raw.partition(":")
        return tail.isdigit()
    return bool(re.fullmatch(r"\d+(?:-\d+)?(?:\s*,\s*\d+(?:-\d+)?)*", raw))


def _render_plan_table(
    plan: AcquisitionPlan, title: str, console: Console | None = None
) -> None:
    console = console or Console()
    table = Table(title=title, expand=True)
    table.add_column("#", style="cyan", width=4)
    table.add_column("Source", style="white")
    for i, item in enumerate(plan.items):
        table.add_row(str(i), item.source_url)
    console.print(table)


@dataclass
class InteractiveApp:
    client: VDLClient
    console: Console = field(default_factory=Console)

    @property
    def _default_output_dir(self) -> Path:
        return self.client.config.output_dir

    def _options(self, url: str) -> DownloadOptions:
        return prompt_for_download_options(
            url, self.console, default_output_dir=self._default_output_dir
        )

    async def _options_async(self, url: str) -> DownloadOptions:
        return await prompt_for_download_options_async(
            url, self.console, default_output_dir=self._default_output_dir
        )

    async def run(self) -> int:
        self.console.print(Panel(_BANNER, border_style="cyan"))
        self.console.print()

        while True:
            try:
                url = await prompt_for_url_async(self.console)
            except (EOFError, KeyboardInterrupt):
                self.console.print("\nBye.", style="yellow")
                return 0

            if url.lower() in _QUIT_WORDS or not url:
                if not url:
                    continue
                self.console.print("Bye.", style="yellow")
                return 0

            analysis = analyze_input(url)

            if not analysis.is_supported:
                self.console.print(
                    f"Unsupported input: {url!r}\n"
                    "  Expected: a URL (https://…), a local media file, or a "
                    "text file of URLs.",
                    style="red",
                )
                continue

            if analysis.kind == InputKind.LOCAL_MEDIA_FILE:
                self.console.print(
                    "Already a local file — nothing to download.", style="yellow"
                )
                continue

            if analysis.kind == InputKind.LOCAL_LINK_FILE:
                opts = await self._options_async(url)
                plan = await self._plan_with_status(
                    url, output_dir=opts.output_dir, quality=opts.quality
                )
                _render_plan_table(plan, "Acquisition Plan", self.console)
                results = await self._execute_with_progress(plan, opts=opts)
                _print_results(results, self.console)
                continue

            inspection = await self.client.inspect_url_for_interactive(url)

            try:
                if inspection.kind == "playlist":
                    playlist_url = inspection.playlist_url or url
                    opts = await self._options_async(url)
                    playlist = await self.client.resolve_playlist(playlist_url)
                    sel = await prompt_for_playlist_selection_async(
                        playlist, self.console
                    )
                    plan = await self.client.plan(
                        playlist_url,
                        output_dir=opts.output_dir,
                        quality=opts.quality,
                    )
                    results = await self._execute_with_progress(
                        plan, selection=sel, opts=opts
                    )
                    _print_results(results, self.console)
                    continue

                if inspection.kind == "playlist_member":
                    choice = await prompt_for_playlist_member_choice_async(self.console)
                    if choice == "playlist":
                        playlist_url = inspection.playlist_url or url
                        opts = await self._options_async(url)
                        playlist = await self.client.resolve_playlist(playlist_url)
                        sel = await prompt_for_playlist_selection_async(
                            playlist, self.console
                        )
                        indexes = selection_to_indexes(sel, len(playlist.items))
                        original_index = _find_index_for_url(playlist, url)
                        if original_index is not None and original_index not in indexes:
                            indexes.append(original_index)
                            indexes.sort()
                            self.console.print(
                                f"  [dim]Also including the originally pasted video (item #{original_index}).[/dim]"
                            )
                        plan = await self.client.plan(
                            playlist_url,
                            output_dir=opts.output_dir,
                            quality=opts.quality,
                        )
                        results = await self._execute_with_progress(
                            plan,
                            selection=indexes,
                            prefer_playlist=True,
                            opts=opts,
                        )
                    else:
                        opts = await self._options_async(url)
                        plan = await self.client.plan(
                            url, output_dir=opts.output_dir, quality=opts.quality
                        )
                        results = await self._execute_with_progress(plan, opts=opts)
                    _print_results(results, self.console)
                    continue

                opts = await self._options_async(url)
                if await prompt_for_direct_or_crawl_async(self.console) == "crawl":
                    with self.console.status(
                        f"[cyan]Crawling[/cyan] {url}", spinner="dots"
                    ):
                        crawl_plan = await self.client.discover(
                            url, output_dir=opts.output_dir, quality=opts.quality
                        )
                    if crawl_plan.total == 0:
                        self.console.print(
                            "[yellow]Crawler found no candidate links.[/yellow]"
                        )
                        continue
                    discovery = crawl_plan.metadata.get("discovery") or {}
                    method = discovery.get("crawler_method") or "?"
                    self.console.print(
                        f"  [green]✓ crawled[/green] ({method}) — found {crawl_plan.total} link(s)"
                    )
                    _render_plan_table(crawl_plan, "Discovered Links", self.console)
                    selection = await prompt_for_discovered_selection_async(
                        crawl_plan.total, self.console
                    )
                    results = await self._execute_with_progress(
                        crawl_plan, selection=selection, opts=opts
                    )
                else:
                    plan = await self.client.plan(
                        url, output_dir=opts.output_dir, quality=opts.quality
                    )
                    results = await self._execute_with_progress(plan, opts=opts)
                _print_results(results, self.console)
            except Exception as e:
                translated = translate_error(str(e))
                self.console.print(f"[red]Error:[/red] {translated.message}")
                if translated.hint:
                    self.console.print(f"  [yellow]Hint:[/yellow] {translated.hint}")

    async def _plan_with_status(
        self,
        url: str,
        *,
        output_dir: Path | None = None,
        quality: Quality = Quality.BEST,
    ) -> AcquisitionPlan:
        return await self.client.plan(url, output_dir=output_dir, quality=quality)

    async def _execute_with_progress(
        self,
        plan: AcquisitionPlan,
        *,
        selection: PlaylistSelection | list[int] | None = None,
        prefer_playlist: bool = False,
        opts: DownloadOptions | None = None,
    ) -> list[DownloadResult]:
        emitter = RichProgressEmitter(console=self.console)
        emitter.start(total=plan.total)
        loop = asyncio.get_running_loop()
        cancel_token = CancellationToken()
        controller = CancellationController()

        def _on_progress(progress) -> None:
            loop.call_soon_threadsafe(emitter.emit, progress)

        def _on_sigint() -> None:
            # On the first SIGINT, suspend the live display, show a
            # numbered menu of in-flight tasks, and let the user cancel
            # one or all. A second SIGINT during the menu hard-aborts.
            if cancel_token.is_cancelled:
                raise KeyboardInterrupt
            asyncio.ensure_future(
                self._handle_cancel_menu(emitter, controller, cancel_token)
            )

        previous_handler = None
        sigint_installed = False
        try:
            loop.add_signal_handler(signal.SIGINT, _on_sigint)
            sigint_installed = True
        except (NotImplementedError, RuntimeError):
            previous_handler = signal.getsignal(signal.SIGINT)

        try:
            return await self.client.execute_plan(
                plan,
                selection=selection,
                prefer_playlist=prefer_playlist,
                on_progress=_on_progress,
                cancel_token=cancel_token,
                write_thumbnail=opts.write_thumbnail if opts else None,
                write_subtitles=opts.write_subtitles if opts else None,
                subtitle_langs=opts.subtitle_langs if opts else None,
                controller=controller,
            )
        except KeyboardInterrupt:
            cancel_token.cancel()
            controller.cancel_all()
            self.console.print("[yellow]Cancelled.[/yellow]")
            return []
        finally:
            if sigint_installed:
                try:
                    loop.remove_signal_handler(signal.SIGINT)
                except (NotImplementedError, RuntimeError):
                    pass
            elif previous_handler is not None:
                signal.signal(signal.SIGINT, previous_handler)
            emitter.finish()

    async def _handle_cancel_menu(
        self,
        emitter: RichProgressEmitter,
        controller: CancellationController,
        cancel_token: CancellationToken,
    ) -> None:
        """Show a Ctrl+C menu listing active downloads and route the choice.

        Runs on the main asyncio loop so terminal input stays on the main
        thread while the Live display is paused.
        """
        active = controller.active()
        if not active:
            cancel_token.cancel()
            return

        try:
            emitter._live.stop()
        except Exception:
            pass
        try:
            self.console.print()
            self.console.print("[yellow]Cancel which download?[/yellow]")
            for idx, (_key, label) in enumerate(active, start=1):
                self.console.print(f"  [{idx}] {label}")
            self.console.print(
                "  [a] cancel all   [Enter] resume   (Ctrl+C again = hard exit)"
            )
            try:
                choice = (
                    (
                        await read_line_async(
                            "Choice: ",
                            history_name="cancel_choice",
                            choices=["a", "all"],
                        )
                    )
                    .strip()
                    .lower()
                )
            except (EOFError, KeyboardInterrupt):
                choice = "a"
        finally:
            try:
                emitter._live.start()
            except Exception:
                pass

        if not choice:
            self.console.print("[dim]Resumed.[/dim]")
            return
        if choice in {"a", "all"}:
            cancel_token.cancel()
            controller.cancel_all()
            self.console.print("[yellow]Cancelling all downloads…[/yellow]")
            return
        try:
            num = int(choice)
        except ValueError:
            self.console.print(f"[red]Unknown choice: {choice!r}[/red]")
            return
        if 1 <= num <= len(active):
            key, label = active[num - 1]
            controller.cancel(key)
            self.console.print(f"[yellow]Cancelling: {label}[/yellow]")
        else:
            self.console.print(f"[red]Out of range: {num}[/red]")


async def run_interactive(client: VDLClient | None = None) -> int:
    if client is None:
        from vdl.config import load_config

        client = VDLClient(config=load_config())
    return await InteractiveApp(client=client).run()


__all__ = [
    "DownloadOptions",
    "DownloadStatus",
    "InteractiveApp",
    "prompt_for_direct_or_crawl",
    "prompt_for_direct_or_crawl_async",
    "prompt_for_discovered_selection",
    "prompt_for_discovered_selection_async",
    "prompt_for_download_options",
    "prompt_for_download_options_async",
    "prompt_for_playlist_member_choice",
    "prompt_for_playlist_member_choice_async",
    "prompt_for_playlist_selection",
    "prompt_for_playlist_selection_async",
    "prompt_for_url",
    "prompt_for_url_async",
    "run_interactive",
    "expand_user_path",
]
