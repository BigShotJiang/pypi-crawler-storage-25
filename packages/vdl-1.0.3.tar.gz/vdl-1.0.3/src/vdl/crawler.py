"""Link discovery through web crawling and site-specific extraction rules.

Provides HTML parsing and optional JavaScript-based crawling via Selenium to
extract links from pages for discovery.
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlparse, urljoin

from vdl.errors import VDLCrawlerError
from vdl.logging import Logger, NullLogger
from vdl.site_rules import SiteRule

#: URL patterns that should never be extracted (login, ads, etc).
BLACKLIST_PATTERNS = [
    r"/login",
    r"/logout",
    r"/register",
    r"/profile",
    r"/account",
    r"trafficstars",
    r"ad\.",
    r"ads\.",
    r"\.pop\.",
    r"/signup",
    r"/signin",
    r"doubleclick",
    r"googleads",
]

PAGINATION_CLASS_PATTERNS = [
    r"pagination",
    r"pager",
    r"pages?[-_]?(link|item|number|num|btn|nav|selector|controller|list)",
    r"next[-_]?(page|btn|button|link)",
    r"prev(ious)?[-_]?(page|btn|button|link)",
    r"nav(igation)?[-_]?pages?",
    r"paged?",
    r"item[-_]?pagination",
    r"load[-_]?more",
    r"\b(prev|next|page|pagination|pager)\b",
]


@dataclass(frozen=True)
class DiscoveryReport:
    """Result of discovery with metadata about how links were extracted.

    Attributes:
        urls: Extracted URLs ready for download.
        matched_rule: Domain matched by site rule, if any.
        rule_filter_applied: Whether site-rule filtering was applied.
        crawler_method: How links were extracted (http/javascript/failed).
        total_links_seen: Count before filtering.
        fallback_used: Whether generic fallback filtering was used.
    """

    urls: list[str]
    matched_rule: str | None
    rule_filter_applied: bool
    crawler_method: str
    total_links_seen: int
    fallback_used: bool


@dataclass
class CrawlResult:
    """Raw crawl output with link categorization.

    Attributes:
        all_links: All extracted links.
        pagination_links: Links classified as pagination controls.
        non_pagination_links: Content links.
        method: Crawl method used (http/javascript/failed).
    """

    all_links: list[dict[str, Any]]
    pagination_links: list[dict[str, Any]]
    non_pagination_links: list[dict[str, Any]]
    method: str  # "javascript" | "http" | "failed"


class CrawlerProtocol(Protocol):
    """Protocol for crawlers that extract links from pages."""

    def crawl(self, url: str, cookie_file: Path | None = None) -> CrawlResult:
        """Crawl a page and extract links.

        Args:
            url: Page URL to crawl.
            cookie_file: Optional cookies file.

        Returns:
            CrawlResult with extracted links.
        """
        ...


class CrawlerSession:
    """Context manager for Selenium Chrome browser session.

    Used for JavaScript-based crawling when HTTP crawling doesn't work.

    Attributes:
        _cookie_file: Optional cookies file path.
        _headless: Whether to run in headless mode.
        _driver: Selenium WebDriver instance.
    """

    def __init__(self, cookie_file: Path | None = None, headless: bool = True) -> None:
        """Initialize session.

        Args:
            cookie_file: Path to cookies JSON file.
            headless: Run in headless mode (no GUI).
        """
        self._cookie_file = cookie_file
        self._headless = headless
        self._driver = None

    def __enter__(self) -> CrawlerSession:
        """Initialize and return the browser session.

        Returns:
            Self.

        Raises:
            VDLCrawlerError: If selenium not installed or driver init fails.
        """
        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
        except ImportError as e:
            raise VDLCrawlerError("selenium is not installed") from e

        chrome_opts = Options()
        if self._headless:
            chrome_opts.add_argument("--headless")
        chrome_opts.add_argument("--no-sandbox")
        chrome_opts.add_argument("--disable-dev-shm-usage")
        chrome_opts.add_argument("--disable-blink-features=AutomationControlled")
        chrome_opts.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_opts.add_experimental_option("useAutomationExtension", False)
        chrome_opts.add_argument("--log-level=3")

        try:
            self._driver = webdriver.Chrome(options=chrome_opts)
            self._driver.set_page_load_timeout(30)
        except Exception as e:
            raise VDLCrawlerError(f"Failed to initialize Chrome driver: {e}") from e
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Clean up browser driver.

        Args:
            exc_type: Exception type if one occurred.
            exc_val: Exception value if one occurred.
            exc_tb: Exception traceback if one occurred.
        """
        if self._driver:
            self._driver.quit()
            self._driver = None

    def navigate(self, url: str, wait_time: float = 2.0) -> None:
        """Navigate to URL and wait for page load.

        Args:
            url: URL to navigate to.
            wait_time: Time to wait after navigation (seconds).

        Raises:
            VDLCrawlerError: If driver not initialized or navigation fails.
        """
        if not self._driver:
            raise VDLCrawlerError("Driver not initialized")
        parsed = urlparse(url)
        base_url = f"{parsed.scheme}://{parsed.netloc}"
        if self._cookie_file and self._cookie_file.exists():
            self._driver.get(base_url)
            try:
                cookies = json.loads(self._cookie_file.read_text())
                for cookie in cookies:
                    try:
                        self._driver.add_cookie(cookie)
                    except Exception:
                        pass
            except Exception:
                pass
            finally:
                self._cookie_file = None  # apply once only
        self._driver.get(url)
        if wait_time > 0:
            time.sleep(wait_time)

    def get_page_source(self) -> str:
        """Get rendered page HTML.

        Returns:
            Page source HTML.
        """
        return self._driver.page_source if self._driver else ""

    def get_current_url(self) -> str:
        """Get currently loaded URL.

        Returns:
            Current URL after navigation/redirects.
        """
        return self._driver.current_url if self._driver else ""

    def click_element_js(self, selector: str, by_xpath: bool = False) -> bool:
        """Click element via JavaScript.

        Args:
            selector: CSS selector or XPath expression.
            by_xpath: Whether selector is XPath (default is CSS).

        Returns:
            True if element was found and clicked, False otherwise.
        """
        if not self._driver:
            return False
        try:
            from selenium.webdriver.common.by import By

            by = By.XPATH if by_xpath else By.CSS_SELECTOR
            elements = self._driver.find_elements(by, selector)
            if elements:
                self._driver.execute_script("arguments[0].click();", elements[0])
                return True
            return False
        except Exception:
            return False


class LinkCrawler:
    """Static methods for HTML/JavaScript-based link extraction."""

    @staticmethod
    def get_links_to_crawl(url: str, cookie_file: Path | None = None) -> CrawlResult:
        """Extract links from a page using JavaScript then HTTP fallback.

        Args:
            url: Page URL.
            cookie_file: Optional cookies file.

        Returns:
            CrawlResult with extracted and categorized links.
        """
        result = LinkCrawler._crawl_with_javascript(url, cookie_file)
        if result and result.all_links:
            return result
        result = LinkCrawler._crawl_without_javascript(url, cookie_file)
        if result:
            return result
        return CrawlResult(
            all_links=[], pagination_links=[], non_pagination_links=[], method="failed"
        )

    @staticmethod
    def _crawl_with_javascript(
        url: str, cookie_file: Path | None
    ) -> CrawlResult | None:
        """Crawl page using Selenium/JavaScript (internal).

        Args:
            url: Page URL.
            cookie_file: Optional cookies file.

        Returns:
            CrawlResult if successful, None on error.
        """
        try:
            with CrawlerSession(cookie_file=cookie_file) as session:
                session.navigate(url)
                if LinkCrawler._is_homepage_redirect(url, session.get_current_url()):
                    return None
                result = LinkCrawler._parse_and_classify_links(
                    session.get_page_source(), session.get_current_url()
                )
                result.method = "javascript"
                return result
        except Exception:
            return None

    @staticmethod
    def _crawl_without_javascript(
        url: str, cookie_file: Path | None
    ) -> CrawlResult | None:
        """Crawl page using HTTP requests (internal).

        Args:
            url: Page URL.
            cookie_file: Optional cookies file (unused in HTTP mode).

        Returns:
            CrawlResult if successful, None on error.
        """
        try:
            import requests

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            result = LinkCrawler._parse_and_classify_links(response.text, url)
            result.method = "http"
            return result
        except Exception:
            return None

    @staticmethod
    def _parse_and_classify_links(html: str, base_url: str) -> CrawlResult:
        from bs4 import BeautifulSoup

        soup = BeautifulSoup(html, "html.parser")
        all_links: list[dict[str, Any]] = []
        pagination_links: list[dict[str, Any]] = []
        non_pagination_links: list[dict[str, Any]] = []
        seen_urls: set[str] = set()

        def get_text(el: Any) -> str:
            t = el.get_text(strip=True)
            if not t:
                t = el.get("title", "") or el.get("aria-label", "")
            return t or ""

        for idx, el in enumerate(soup.find_all(["a", "button", "div", "span"])):
            href = el.get("href")
            has_pag = LinkCrawler._has_pagination_context(el)
            is_generic = el.name in ["div", "span"]

            if is_generic and not has_pag:
                continue
            if not href and not has_pag:
                txt = get_text(el)
                if not re.match(r"^[\(\[]?\d+[\)\]]?$", txt.strip()):
                    continue
            if not href:
                continue

            absolute_url = urljoin(base_url, href)
            parsed = urlparse(absolute_url)
            if not parsed.scheme or not parsed.netloc:
                continue

            clean_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            if parsed.query:
                clean_url += f"?{parsed.query}"

            if any(re.search(p, clean_url, re.IGNORECASE) for p in BLACKLIST_PATTERNS):
                continue

            link_text = get_text(el)
            if not link_text:
                continue

            is_numeric = bool(re.match(r"^[\(\[]?\d+[\)\]]?$", link_text.strip()))
            dedup_key = f"{clean_url}::{link_text.strip()}" if is_numeric else clean_url
            if dedup_key in seen_urls:
                continue
            seen_urls.add(dedup_key)

            link_data: dict[str, Any] = {
                "url": clean_url,
                "text": link_text,
                "index": idx,
            }
            if is_numeric:
                clean_text = link_text.strip()
                link_data["xpath"] = f"//{el.name}[normalize-space(.)='{clean_text}']"

            all_links.append(link_data)
            if LinkCrawler._is_pagination_link(el, clean_url, link_text):
                pagination_links.append(link_data)
            else:
                non_pagination_links.append(link_data)

        return CrawlResult(
            all_links=all_links,
            pagination_links=pagination_links,
            non_pagination_links=non_pagination_links,
            method="",
        )

    @staticmethod
    def _is_pagination_link(element: Any, url: str, text: str) -> bool:
        if not re.match(r"^[\(\[]?\d+[\)\]]?$", text.strip()):
            return False
        pagination_url_patterns = [
            r"[/\?&](?:page|p)[=/-]?\d+",
            r"[/\?&]offset[=/-]?\d+",
            r"[/\?&]start[=/-]?\d+",
            r"/\d+/?$",
            r"/\d+\.html?$",
            r"javascript:",
            r"#",
        ]
        if any(re.search(p, url, re.IGNORECASE) for p in pagination_url_patterns):
            return True
        return LinkCrawler._has_pagination_context(element)

    @staticmethod
    def _has_pagination_context(element: Any) -> bool:
        def matches(text: str) -> bool:
            return any(
                re.search(p, text, re.IGNORECASE) for p in PAGINATION_CLASS_PATTERNS
            )

        classes = element.get("class", [])
        if isinstance(classes, list):
            classes = " ".join(classes)
        if matches(str(classes)):
            return True
        if matches(str(element.get("id", ""))):
            return True
        if matches(str(element.get("aria-label", ""))):
            return True
        for key, value in element.attrs.items():
            if "page" in key.lower() or "pagination" in key.lower():
                return True
            if isinstance(value, str) and matches(value):
                return True

        parent = element.parent
        for _ in range(3):
            if parent is None:
                break
            parent_classes = parent.get("class", [])
            if isinstance(parent_classes, list):
                parent_classes = " ".join(parent_classes)
            if matches(str(parent_classes)):
                return True
            if matches(str(parent.get("id", ""))):
                return True
            if parent.name == "nav":
                return True
            parent = parent.parent
        return False

    @staticmethod
    def _is_homepage_redirect(original: str, final: str) -> bool:
        """Check if navigation redirected to homepage (internal).

        Args:
            original: Original request URL.
            final: Final URL after redirects.

        Returns:
            True if final is homepage but original was not.
        """
        orig = urlparse(original)
        fin = urlparse(final)
        if orig.netloc == fin.netloc:
            if fin.path in ("", "/") and orig.path not in ("", "/"):
                return True
        return False


class SiteRuleDiscoveryResolver:
    """Discovery resolver using link crawling and optional site-specific rules.

    Crawls HTML pages to extract links, optionally filtering them using
    CSS selectors defined in SiteRule objects.

    Attributes:
        _rules: List of SiteRule for domain-specific extraction.
        _cookie_file: Optional cookies file.
        _crawler: CrawlerProtocol implementation.
        _logger: Logger for events.
    """

    def __init__(
        self,
        site_rules: list[SiteRule] | None = None,
        cookie_file: Path | None = None,
        crawler: CrawlerProtocol | None = None,
        logger: Logger | None = None,
    ) -> None:
        """Initialize discovery resolver.

        Args:
            site_rules: List of SiteRule for domain-specific filtering.
            cookie_file: Optional cookies file for crawler.
            crawler: CrawlerProtocol implementation; defaults to LinkCrawler.
            logger: Logger instance.
        """
        self._rules = site_rules or []
        self._cookie_file = cookie_file
        self._crawler = crawler or _DefaultCrawler()
        self._logger = logger or NullLogger()

    def _find_rule(self, url: str) -> SiteRule | None:
        """Find matching SiteRule for URL (internal).

        Args:
            url: URL to match.

        Returns:
            First matching SiteRule, or None.
        """
        domain = urlparse(url).netloc
        for rule in self._rules:
            if rule.domain and rule.domain in domain:
                return rule
        return None

    async def resolve(self, url: str) -> list[str]:
        """Resolve URL to list of links (simple interface).

        Args:
            url: Page URL.

        Returns:
            List of extracted URLs.

        Raises:
            Propagates exceptions from crawler.
        """
        report = await self.resolve_with_report(url)
        return report.urls

    async def resolve_with_report(self, url: str) -> DiscoveryReport:
        """Resolve URL with detailed report of extraction method and filtering.

        Args:
            url: Page URL.

        Returns:
            DiscoveryReport with URLs and metadata.

        Raises:
            Propagates exceptions from crawler.
        """
        rule = self._find_rule(url)
        self._logger.info("discovery.started", url=url, has_rule=bool(rule))
        result = await asyncio.to_thread(self._crawler.crawl, url, self._cookie_file)
        if rule:
            links = _filter_links_with_rule(result.all_links, rule)
            total_seen = len(result.all_links)
            rule_filter_applied = True
            fallback_used = False
        else:
            links = result.non_pagination_links
            total_seen = len(links)
            rule_filter_applied = False
            fallback_used = False

        resolved = [link["url"] for link in links]
        self._logger.info(
            "discovery.completed",
            url=url,
            count=len(resolved),
            has_rule=bool(rule),
            rule_filter_applied=rule_filter_applied,
            fallback_used=fallback_used,
        )
        return DiscoveryReport(
            urls=resolved,
            matched_rule=rule.domain if rule else None,
            rule_filter_applied=rule_filter_applied,
            crawler_method=result.method,
            total_links_seen=total_seen,
            fallback_used=fallback_used,
        )


class _DefaultCrawler:
    """Default crawler implementation using LinkCrawler (internal)."""

    def crawl(self, url: str, cookie_file: Path | None = None) -> CrawlResult:
        """Crawl URL using LinkCrawler.

        Args:
            url: Page URL.
            cookie_file: Optional cookies file.

        Returns:
            CrawlResult.
        """
        return LinkCrawler.get_links_to_crawl(url, cookie_file)


def _filter_links_with_rule(
    links: list[dict[str, Any]],
    rule: SiteRule,
) -> list[dict[str, Any]]:
    """Filter discovered links down to those that match a site rule."""
    filtered: list[dict[str, Any]] = []
    seen_urls: set[str] = set()
    for link in links:
        if _matches_pagination_rule(link, rule):
            continue
        if rule.video_patterns and not _matches_any_pattern(
            link.get("url", ""), rule.video_patterns
        ):
            continue
        url = link.get("url", "")
        if not url or url in seen_urls:
            continue
        seen_urls.add(url)
        filtered.append(link)
    return filtered


def _matches_pagination_rule(link: dict[str, Any], rule: SiteRule) -> bool:
    """Return ``True`` when a link looks like pagination or navigation."""
    url = link.get("url", "")
    text = (link.get("text", "") or "").strip()
    return _matches_any_pattern(url, rule.pagination_patterns) or _matches_any_pattern(
        text, rule.pagination_text_patterns
    )


def _matches_any_pattern(value: str, patterns: list[str]) -> bool:
    """Return ``True`` when ``value`` matches at least one regex pattern."""
    return any(re.search(pattern, value, re.IGNORECASE) for pattern in patterns)
