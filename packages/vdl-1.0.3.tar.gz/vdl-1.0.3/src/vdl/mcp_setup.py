"""Generate per-host MCP client configuration for ``vdl-mcp``.

The interactive ``vdl mcp setup`` command and ``vdl doctor`` use this
module to print copy-pasteable JSON snippets tailored to the user's
local environment. Detected paths are preferred over generic
"``vdl-mcp``" so the output works on machines where the script lives
inside a venv that isn't on the global ``PATH``.
"""

from __future__ import annotations

import json
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class McpInvocation:
    """How to launch ``vdl-mcp`` on this machine.

    Attributes:
        command: The executable to run (absolute when discoverable).
        args: Argument list to pass after ``command``.
        notes: Optional one-line context the UI should surface to the user.
        is_resolved: ``True`` when the command was found on disk.
    """

    command: str
    args: list[str]
    notes: str | None
    is_resolved: bool


def detect_invocation() -> McpInvocation:
    """Best-effort discovery of how to launch ``vdl-mcp`` from this install.

    Looks first for a ``vdl-mcp`` script on ``PATH``. If absent, falls
    back to ``<sys.executable> -m vdl.mcp_server`` so users running from
    a checkout still get a working snippet.
    """
    found = shutil.which("vdl-mcp")
    if found:
        return McpInvocation(
            command=found,
            args=[],
            notes=None,
            is_resolved=True,
        )
    py = sys.executable or "python"
    return McpInvocation(
        command=py,
        args=["-m", "vdl.mcp_server"],
        notes=(
            "vdl-mcp not on PATH — falling back to running the module "
            'directly. Install with: pipx install "vdl[mcp]"'
        ),
        is_resolved=False,
    )


def _claude_desktop_snippet(inv: McpInvocation) -> str:
    """Render the Claude Desktop MCP config snippet for ``inv``."""
    payload = {
        "mcpServers": {
            "vdl": {
                "command": inv.command,
                "args": inv.args,
            }
        }
    }
    return json.dumps(payload, indent=2)


def _codex_snippet(inv: McpInvocation) -> str:
    """Render the Codex MCP config snippet for ``inv``."""
    args_repr = " ".join(inv.args)
    cmd = inv.command if not args_repr else f"{inv.command} {args_repr}"
    return (
        "[mcp_servers.vdl]\n"
        f'command = "{inv.command}"\n'
        f"args = {json.dumps(inv.args)}\n"
        f"# Or the equivalent shell form: {cmd}"
    )


def _generic_snippet(inv: McpInvocation) -> str:
    """Render a generic stdio MCP config snippet for ``inv``."""
    return json.dumps(
        {"command": inv.command, "args": inv.args, "transport": "stdio"},
        indent=2,
    )


def render_setup_text(inv: McpInvocation | None = None) -> str:
    """Render a copy-pasteable, multi-host setup guide as plain text."""
    inv = inv or detect_invocation()

    lines: list[str] = []
    lines.append("VDL MCP server setup")
    lines.append("=" * 60)
    if inv.is_resolved:
        lines.append(f"Detected vdl-mcp: {inv.command}")
    else:
        lines.append(
            f"vdl-mcp not found on PATH; using: {inv.command} {' '.join(inv.args)}"
        )
    if inv.notes:
        lines.append(f"Note: {inv.notes}")
    lines.append("")

    lines.append(
        "Claude Desktop (~/Library/Application Support/Claude/claude_desktop_config.json on macOS)"
    )
    lines.append("-" * 60)
    lines.append(_claude_desktop_snippet(inv))
    lines.append("")

    lines.append("Codex / ChatGPT desktop (TOML form, e.g. ~/.codex/config.toml)")
    lines.append("-" * 60)
    lines.append(_codex_snippet(inv))
    lines.append("")

    lines.append("Generic MCP client (stdio transport)")
    lines.append("-" * 60)
    lines.append(_generic_snippet(inv))
    lines.append("")

    lines.append(
        "After updating the host's config, restart the host so it picks up the new server."
    )
    return "\n".join(lines)


def render_setup_dict(inv: McpInvocation | None = None) -> dict:
    """Structured form for ``--json`` callers and tests."""
    inv = inv or detect_invocation()
    return {
        "command": inv.command,
        "args": list(inv.args),
        "is_resolved": inv.is_resolved,
        "notes": inv.notes,
        "snippets": {
            "claude_desktop": json.loads(_claude_desktop_snippet(inv)),
            "codex_toml": _codex_snippet(inv),
            "generic": json.loads(_generic_snippet(inv)),
        },
    }
