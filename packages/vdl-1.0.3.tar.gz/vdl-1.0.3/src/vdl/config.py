"""Configuration loading, parsing, and storage.

VDL configuration is stored as TOML in ~/.config/vdl/config.toml. This module
handles reading, writing, and merging configuration with defaults.
"""

from __future__ import annotations

import tomllib
from dataclasses import asdict, dataclass, fields, replace
from pathlib import Path
from typing import Any, Protocol

from vdl.errors import VDLConfigError
from vdl.paths import get_default_paths


@dataclass(frozen=True)
class VDLConfig:
    """VDL configuration.

    Attributes:
        output_dir: Default output directory for downloads.
        config_file: Path to config file (for reference).
        default_quality: Quality preference (best/medium/low/1080p/etc).
        audio_only: Extract audio only by default.
        max_concurrent_downloads: Download concurrency limit.
        embed_metadata: Embed video metadata in file.
        embed_thumbnail: Embed thumbnail in file.
        release_metadata_url: URL for release/version metadata.
        site_rules_path: Path to site discovery rules.
        max_playlist_items: Limit on playlist item expansion.
        expand_nested_playlists: Expand playlists in mixed input.
    """

    output_dir: Path
    config_file: Path | None = None
    default_quality: str = "best"
    audio_only: bool = False
    max_concurrent_downloads: int = 3
    embed_metadata: bool = True
    embed_thumbnail: bool = True
    write_thumbnail: bool = False
    write_subtitles: bool = False
    subtitle_langs: str = "en"
    release_metadata_url: str | None = None
    site_rules_path: Path | None = None
    max_playlist_items: int | None = None
    expand_nested_playlists: bool = False


class ConfigStore(Protocol):
    """Protocol for configuration storage backends.

    Implementations can provide persistence for VDLConfig (e.g. TOML, JSON).
    """

    def load(self) -> VDLConfig:
        """Load configuration.

        Returns:
            Loaded VDLConfig.

        Raises:
            VDLConfigError: If loading fails.
        """
        ...

    def save(self, config: VDLConfig) -> None:
        """Save configuration.

        Args:
            config: VDLConfig to persist.

        Raises:
            VDLConfigError: If saving fails.
        """
        ...

    def get(self, key: str) -> Any:
        """Get a single config value.

        Args:
            key: Configuration key.

        Returns:
            Value for that key.

        Raises:
            VDLConfigError: If key is unknown or read fails.
        """
        ...

    def set(self, key: str, value: Any) -> None:
        """Set a single config value.

        Args:
            key: Configuration key.
            value: New value.

        Raises:
            VDLConfigError: If key is unknown or write fails.
        """
        ...


class TomlConfigStore:
    """ConfigStore implementation using TOML files.

    Loads and saves VDLConfig to/from ~/.config/vdl/config.toml.
    Caches loaded config to avoid repeated disk reads.
    """

    def __init__(self, path: Path | None = None) -> None:
        """Initialize store.

        Args:
            path: Custom path to config file; defaults to standard location.
        """
        self._path = path
        self._cache: VDLConfig | None = None

    def load(self) -> VDLConfig:
        """Load configuration with caching.

        Returns:
            Loaded or cached VDLConfig.

        Raises:
            VDLConfigError: If TOML is invalid.
        """
        if self._cache is None:
            self._cache = load_config(self._path)
        return self._cache

    def save(self, config: VDLConfig) -> None:
        """Save configuration to disk and update cache.

        Args:
            config: VDLConfig to persist.

        Raises:
            VDLConfigError: If writing fails.
        """
        save_config(config, self._path)
        self._cache = config

    def get(self, key: str) -> Any:
        """Get a configuration value by key.

        Args:
            key: Configuration field name.

        Returns:
            Value of that field.

        Raises:
            VDLConfigError: If key is unknown.
        """
        if key not in _CONFIG_FIELDS:
            raise VDLConfigError(f"Unknown config key: {key!r}")
        return getattr(self.load(), key)

    def set(self, key: str, value: Any) -> None:
        """Set a configuration value by key.

        Args:
            key: Configuration field name.
            value: New value.

        Raises:
            VDLConfigError: If key is unknown or write fails.
        """
        if key not in _CONFIG_FIELDS:
            raise VDLConfigError(f"Unknown config key: {key!r}")
        updated = replace(self.load(), **{key: value})
        self.save(updated)


_CONFIG_FIELDS = {f.name for f in fields(VDLConfig)}


def _default_config() -> VDLConfig:
    """Build the default configuration from the current filesystem layout."""
    paths = get_default_paths()
    site_rules_path = paths.site_rules_file if paths.site_rules_file.exists() else None
    return VDLConfig(
        output_dir=paths.downloads_dir,
        site_rules_path=site_rules_path,
    )


def _serialize_toml(config: VDLConfig) -> str:
    """Serialize a config object to the small TOML dialect used on disk."""
    lines = []
    for key, value in asdict(config).items():
        if value is None:
            continue
        if isinstance(value, bool):
            rendered = "true" if value else "false"
        elif isinstance(value, int):
            rendered = str(value)
        elif isinstance(value, float):
            rendered = str(value)
        else:
            escaped = str(value).replace("\\", "\\\\").replace('"', '\\"')
            rendered = f'"{escaped}"'
        lines.append(f"{key} = {rendered}")
    return "\n".join(lines) + "\n"


def load_config(path: Path | None = None) -> VDLConfig:
    """Load configuration from disk, falling back to defaults when missing."""
    config_path = path or get_default_paths().config_file
    if not config_path.exists():
        return _default_config()
    try:
        with open(config_path, "rb") as f:
            raw = tomllib.load(f)
    except Exception as e:
        raise VDLConfigError(f"Cannot load config: {e}") from e

    defaults = asdict(_default_config())
    merged = {**defaults, **{k: v for k, v in raw.items() if k in _CONFIG_FIELDS}}
    if "output_dir" in merged:
        merged["output_dir"] = Path(merged["output_dir"])
    if "config_file" in merged and merged["config_file"] is not None:
        merged["config_file"] = Path(merged["config_file"])
    if "site_rules_path" in merged and merged["site_rules_path"] is not None:
        merged["site_rules_path"] = Path(merged["site_rules_path"])
    return VDLConfig(**merged)


def save_config(config: VDLConfig, path: Path | None = None) -> None:
    """Write configuration to disk, creating parent directories as needed."""
    config_path = path or get_default_paths().config_file
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(_serialize_toml(config), encoding="utf-8")


def get_config_value(key: str, path: Path | None = None) -> Any:
    """Read a single config value from the persisted configuration."""
    if key not in _CONFIG_FIELDS:
        raise VDLConfigError(f"Unknown config key: {key!r}")
    config = load_config(path)
    return getattr(config, key)


def set_config_value(key: str, value: Any, path: Path | None = None) -> None:
    """Update one config value in the persisted configuration."""
    if key not in _CONFIG_FIELDS:
        raise VDLConfigError(f"Unknown config key: {key!r}")
    config = load_config(path)
    updated = replace(config, **{key: value})
    save_config(updated, path)
