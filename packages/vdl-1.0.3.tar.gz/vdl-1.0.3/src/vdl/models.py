"""Core data models and enumerations for VDL.

This module defines the fundamental data structures used throughout VDL,
including input classification, download status tracking, quality levels,
and request/result models for downloads and playlists.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import Any


class InputKind(str, Enum):
    """Classification of user input source.

    Attributes:
        URL: Generic URL (unknown platform).
        VIDEO_URL: Direct video URL on known platform.
        PLAYLIST_URL: Playlist URL on known platform.
        LOCAL_LINK_FILE: Local text file containing URLs.
        LOCAL_MEDIA_FILE: Local media file.
        UNKNOWN: Unrecognized input.
    """

    URL = "url"
    VIDEO_URL = "video_url"
    PLAYLIST_URL = "playlist_url"
    LOCAL_LINK_FILE = "local_link_file"
    LOCAL_MEDIA_FILE = "local_media_file"
    UNKNOWN = "unknown"


class DownloadKind(str, Enum):
    """Type of content being downloaded.

    Attributes:
        VIDEO: Video content (default).
        AUDIO: Audio-only extraction.
        PLAYLIST: Playlist bundle.
    """

    VIDEO = "video"
    AUDIO = "audio"
    PLAYLIST = "playlist"


class DownloadStatus(str, Enum):
    """Status lifecycle of a download.

    Attributes:
        QUEUED: Waiting to start.
        STARTING: Initialization phase.
        DOWNLOADING: Actively retrieving.
        PROCESSING: Post-download (muxing, metadata embed).
        COMPLETED: Success.
        SKIPPED: Idempotency match or user skip.
        FAILED: Error.
        CANCELLED: User or system cancellation.
    """

    QUEUED = "queued"
    STARTING = "starting"
    DOWNLOADING = "downloading"
    PROCESSING = "processing"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Quality(str, Enum):
    """Video quality preference levels.

    Attributes:
        BEST: Highest available.
        MEDIUM: Mid-range quality.
        LOW: Minimum acceptable.
        P2160: 4K resolution.
        P1440: 2K resolution.
        P1080: Full HD.
        P720: HD.
        P480: Standard definition.
        AUDIO: Audio-only.
    """

    BEST = "best"
    MEDIUM = "medium"
    LOW = "low"
    P2160 = "2160p"
    P1440 = "1440p"
    P1080 = "1080p"
    P720 = "720p"
    P480 = "480p"
    AUDIO = "audio"


class OutputMode(str, Enum):
    """Output format for CLI results.

    Attributes:
        TEXT: Plain text output.
        JSON: Structured JSON.
        RICH: Rich-formatted terminal output.
    """

    TEXT = "text"
    JSON = "json"
    RICH = "rich"


@dataclass(frozen=True)
class SourceInput:
    """Parsed user input source.

    Attributes:
        raw: Original user-provided string.
        kind: Classified input type.
        normalized: Canonicalized form (URL normalization, path resolution).
    """

    raw: str
    kind: InputKind
    normalized: str | None = None


@dataclass(frozen=True)
class DownloadRequest:
    """Request to download a single item.

    Immutable specification passed to downloader implementations.

    Attributes:
        source: Parsed input.
        output_dir: Target directory for file.
        quality: Preferred quality level.
        kind: Type of content.
        force: Skip idempotency checks.
        cookies: Path to cookies file.
        cookies_from_browser: Browser name for cookie extraction.
        playlist: Whether source is playlist context.
        subdirectory: Optional target subdirectory.
    """

    source: SourceInput
    output_dir: Path | None = None
    quality: Quality = Quality.BEST
    kind: DownloadKind = DownloadKind.VIDEO
    force: bool = False
    cookies: Path | None = None
    cookies_from_browser: str | None = None
    playlist: bool = False
    subdirectory: str | None = None
    source_title: str | None = None
    filename_prefix: str | None = None
    write_thumbnail: bool | None = None
    write_subtitles: bool | None = None
    subtitle_langs: str | None = None


@dataclass(frozen=True)
class DownloadResult:
    """Outcome of a download operation.

    Attributes:
        id: Unique identifier for this download attempt.
        source_url: URL that was downloaded.
        status: Final status.
        quality: Quality that was requested.
        request_key: Idempotency key (url::quality).
        output_path: Path to saved file.
        error: Error message if failed.
        skipped_reason: Reason for skip if applicable.
        metadata: Downloader-specific metadata.
    """

    id: str
    source_url: str
    status: DownloadStatus
    quality: Quality | None = None
    request_key: str | None = None
    output_path: Path | None = None
    error: str | None = None
    skipped_reason: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PlaylistItem:
    """Single item within a playlist.

    Attributes:
        url: Direct video/item URL.
        id: Platform-specific ID.
        title: Item title.
        index: Position in playlist.
        duration_seconds: Duration if available.
        selected: Whether included in selections.
        metadata: Platform-specific metadata.
    """

    url: str
    id: str | None = None
    title: str | None = None
    index: int | None = None
    duration_seconds: int | None = None
    selected: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PlaylistInfo:
    """Resolved playlist information.

    Attributes:
        url: Original playlist URL.
        title: Playlist title.
        items: List of items in playlist.
        metadata: Resolution metadata (ordering info, etc).
    """

    url: str
    title: str | None
    items: list[PlaylistItem]
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class StatusRecord:
    """State store record of a download.

    Tracks persistent state for idempotency and reconciliation.

    Attributes:
        id: Unique download identifier.
        source_url: URL that was requested.
        status: Last recorded status.
        quality: Quality level.
        request_key: Idempotency key.
        output_path: Path where file was saved.
        error: Last error message.
        percent: Progress indicator.
        updated_at: Last update timestamp.
    """

    id: str
    source_url: str
    status: DownloadStatus
    quality: Quality | None = None
    request_key: str | None = None
    output_path: Path | None = None
    error: str | None = None
    percent: float | None = None
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))


def quality_to_kind(quality: Quality) -> DownloadKind:
    """Map quality preference to content kind.

    Args:
        quality: Quality level.

    Returns:
        DownloadKind.AUDIO if quality is AUDIO, else DownloadKind.VIDEO.
    """
    return DownloadKind.AUDIO if quality == Quality.AUDIO else DownloadKind.VIDEO


def build_request_key(source_url: str, quality: Quality) -> str:
    """Build idempotency key for a request.

    Combines URL and quality to create a unique identifier for tracking
    idempotency on the same URL at different quality levels.

    Args:
        source_url: URL being requested.
        quality: Quality level.

    Returns:
        String in format "url::quality_value".
    """
    return f"{source_url}::{quality.value}"


@dataclass(frozen=True)
class BatchSummary:
    """Partitioned summary of batch download results.

    Groups results by status for easier analysis and reporting.

    Attributes:
        results: All download results in order.
        completed: Successfully downloaded items.
        skipped: Idempotently skipped items.
        failed: Items that failed.
        total: Total count.
    """

    results: list[DownloadResult]
    completed: list[DownloadResult] = field(default_factory=list)
    skipped: list[DownloadResult] = field(default_factory=list)
    failed: list[DownloadResult] = field(default_factory=list)
    total: int = 0

    @classmethod
    def from_results(cls, results: list[DownloadResult]) -> "BatchSummary":
        """Create summary from flat result list.

        Args:
            results: List of DownloadResult objects.

        Returns:
            BatchSummary with partitioned results.
        """
        completed = [r for r in results if r.status == DownloadStatus.COMPLETED]
        skipped = [r for r in results if r.status == DownloadStatus.SKIPPED]
        failed = [r for r in results if r.status == DownloadStatus.FAILED]
        return cls(
            results=list(results),
            completed=completed,
            skipped=skipped,
            failed=failed,
            total=len(results),
        )


@dataclass(frozen=True)
class DoctorReport:
    """System health check report.

    Attributes:
        version: VDL version.
        ffmpeg_available: Whether ffmpeg is installed.
        ytdlp_available: Whether yt-dlp is installed.
        config_ok: Config can be read/written.
        state_ok: State database accessible.
        output_dir_ok: Default output directory writable.
        ffprobe_available: Whether ffprobe is installed.
        mcp_available: Whether the vdl-mcp command is on PATH.
        config_dir_ok: Config directory writable.
        state_dir_ok: State directory writable.
        cache_dir_ok: Cache directory writable.
        repairs: Actionable repair instructions for failed checks.
        details: Additional diagnostic information.
    """

    version: str
    ffmpeg_available: bool
    ytdlp_available: bool
    config_ok: bool
    state_ok: bool
    output_dir_ok: bool
    ffprobe_available: bool = False
    mcp_available: bool = False
    config_dir_ok: bool = True
    state_dir_ok: bool = True
    cache_dir_ok: bool = True
    repairs: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)
