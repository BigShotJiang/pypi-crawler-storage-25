"""Cooperative cancellation for in-flight downloads.

yt-dlp runs in a worker thread (``asyncio.to_thread``) so cancelling the
asyncio task does not stop the work. Instead, the interactive wrapper
sets a token from a signal handler; the yt-dlp progress hook polls the
token on each tick and raises :class:`vdl.errors.VDLCancelled`, which
yt-dlp surfaces as a download failure that we convert to CANCELLED.
"""

from __future__ import annotations

import threading


class CancellationToken:
    """Thread-safe cancellation flag shared between event loop and worker."""

    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def is_cancelled(self) -> bool:
        return self._event.is_set()

    def reset(self) -> None:
        self._event.clear()


class CompositeCancellationToken:
    """Cancellation token that's "set" if any of its parents is set.

    Used to compose a per-task token with a global plan-level token so
    targeted cancellation and global cancellation can coexist without
    the downloader needing to know about either.
    """

    def __init__(self, *tokens: CancellationToken) -> None:
        self._tokens: tuple[CancellationToken, ...] = tokens

    def cancel(self) -> None:
        for tok in self._tokens:
            tok.cancel()

    @property
    def is_cancelled(self) -> bool:
        return any(tok.is_cancelled for tok in self._tokens)


class CancellationController:
    """Registry of per-task cancellation tokens for targeted cancel UX.

    Interactive callers register a token per download with a short label
    (URL or title), and the SIGINT menu enumerates active entries so the
    user can target one. ``cancel_all`` cancels every registered token,
    matching the previous global Ctrl+C behavior.
    """

    def __init__(self) -> None:
        self._tokens: dict[str, CancellationToken] = {}
        self._labels: dict[str, str] = {}
        self._lock = threading.Lock()

    def register(self, key: str, label: str) -> CancellationToken:
        """Create and store a token for a download keyed by ``key``."""
        token = CancellationToken()
        with self._lock:
            self._tokens[key] = token
            self._labels[key] = label
        return token

    def update_label(self, key: str, label: str) -> None:
        """Update the user-facing label for a registered download."""
        with self._lock:
            if key in self._tokens:
                self._labels[key] = label

    def unregister(self, key: str) -> None:
        """Remove a download from the registry."""
        with self._lock:
            self._tokens.pop(key, None)
            self._labels.pop(key, None)

    def active(self) -> list[tuple[str, str]]:
        """Return ``(key, label)`` pairs for tokens that haven't been cancelled."""
        with self._lock:
            return [
                (k, self._labels.get(k, k))
                for k, tok in self._tokens.items()
                if not tok.is_cancelled
            ]

    def cancel(self, key: str) -> bool:
        """Cancel one registered download by key."""
        with self._lock:
            token = self._tokens.get(key)
        if token is None:
            return False
        token.cancel()
        return True

    def cancel_all(self) -> None:
        """Cancel every registered download."""
        with self._lock:
            tokens = list(self._tokens.values())
        for tok in tokens:
            tok.cancel()
