"""VDL error hierarchy.

This module defines all custom exceptions raised by VDL, organized in a
hierarchy from the base VDLError to specific error types.
"""


class VDLError(Exception):
    """Base exception for all VDL errors.

    All VDL-specific exceptions inherit from this, allowing callers to
    catch all VDL errors with a single handler if needed.
    """


class VDLConfigError(VDLError):
    """Raised when configuration cannot be loaded, saved, or validated.

    Examples: missing config file, invalid TOML syntax, unknown config keys.
    """


class VDLInputError(VDLError):
    """Raised when user input cannot be understood or validated.

    Examples: unrecognized URL format, invalid file path.
    """


class VDLDownloadError(VDLError):
    """Raised when a download operation fails.

    Examples: network error, file write error, codec not available.
    """


class VDLPlaylistError(VDLError):
    """Raised when playlist resolution or playlist download fails.

    Examples: playlist URL invalid, yt-dlp extraction failed, item not found.
    """


class VDLStateError(VDLError):
    """Raised when state/idempotency data cannot be read or written.

    Examples: database locked, permissions denied, corruption detected.
    """


class VDLDependencyError(VDLError):
    """Raised when a required external dependency is unavailable.

    Examples: ffmpeg not found, yt-dlp not installed, selenium unavailable.
    """


class VDLSelectionError(VDLError):
    """Raised when a playlist selection cannot be resolved safely.

    Examples: most_recent:N on unknown ordering, invalid index range.
    """


class VDLCrawlerError(VDLError):
    """Raised when a crawler operation fails or dependency is unavailable.

    Examples: Selenium init failed, BeautifulSoup not installed, page timeout.
    """


class VDLCancelled(VDLError):
    """Raised inside a yt-dlp progress hook when the user cancels.

    Caught by the downloader, which converts it into a CANCELLED
    DownloadResult so the interactive loop can keep running.
    """
