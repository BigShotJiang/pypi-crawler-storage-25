"""Parsing user inputs (link files, raw URL lists).

This module handles reading and parsing link files (text files containing URLs)
and tokenizing raw URL strings.
"""

from __future__ import annotations

from pathlib import Path


def parse_link_file(path: Path) -> list[str]:
    """Read URLs from a link file.

    Reads all non-blank, non-comment lines from a text file,
    returning one URL per line. Lines starting with '#' are ignored.

    Args:
        path: Path to link file.

    Returns:
        List of stripped non-empty lines (URLs).

    Raises:
        FileNotFoundError: If path does not exist.
        OSError: If file cannot be read.
    """
    lines = path.read_text(encoding="utf-8").splitlines()
    return [
        line.strip()
        for line in lines
        if line.strip() and not line.strip().startswith("#")
    ]


def tokenize_raw_input(value: str) -> list[str]:
    """Split a raw input string into URL tokens.

    Supports both comma-separated and whitespace-separated lists.
    Prefers comma-separation if present, otherwise splits on whitespace.

    Args:
        value: Raw input string (e.g. "url1 url2" or "url1,url2").

    Returns:
        List of stripped tokens.
    """
    if "," in value:
        return [t.strip() for t in value.split(",") if t.strip()]
    return [t.strip() for t in value.split() if t.strip()]
