# Changelog

All notable changes to VDL are documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

---

## [Unreleased]

### Added
- First-run bootstrap (`vdl/bootstrap.py`): creates required directories, `config.toml`, `websites.yaml` (from bundled copy), and state DB on first startup; idempotent on subsequent runs.

### Changed
- `VDLPaths` now describes only the modern XDG layout; `legacy_site_rules_file` field removed.
- `_default_config()` no longer falls back to legacy `~/.config/video-downloader/` paths.
- `resolve_site_rules_path()` resolves only the modern config location; legacy fallback removed.
- CLI startup no longer calls `migrate_legacy_config()`; migration path removed from active runtime code.

### Removed
- `migrate_legacy_config()` removed from `paths.py`.
- `migrate_from_yaml()` alias removed from `site_rules.py`.

---

## [1.0.0]

### Added
- Rebuilt VDL as a proper Python package under `src/vdl/` with `pyproject.toml` and `hatchling` build backend.
- Headless CLI (`vdl download`, `vdl playlist`, `vdl resolve`, `vdl status`, `vdl doctor`, `vdl config`) with `--json` output flag.
- Interactive CLI mode via Rich (launched by `vdl` with no arguments).
- Python library API (`VDLClient`, `DownloadRequest`, `DownloadResult`, `PlaylistInfo`).
- MCP server (`vdl-mcp`) for LLM-assisted media automation; distributed as optional `vdl[mcp]` extra.
- XDG-compliant path layout with `ensure_paths()` and `get_default_paths()`.
- SQLite-backed state store for idempotent downloads, status tracking, and reconciliation.
- Site-specific crawler support via `websites.yaml` rule files and Selenium-based discovery.
- Legacy config migration from `~/.config/video-downloader/` to `~/.config/vdl/`.
- GitLab CI release pipeline (`ci/release-vdl.yml`) with PyPI Trusted Publishing.
- macOS arm64 binary build (`scripts/build-macos.sh`) with smoke-test and SHA256 checksums.
- Installer (`scripts/install.sh`) with platform detection, checksum verification, and `PATH` warning.
- Release manifest (`release.json`) published to GitLab Pages for the installer to resolve.
- `vdl doctor` command for verifying `ffmpeg`, `ffprobe`, and `yt-dlp` availability.

### Changed
- Previous implementation archived under `frozen/vdl-v0/` and kept buildable.

---

[Unreleased]: https://gitlab.com/bildcraft/products/video-downloader/-/compare/vdl-v1.0.0...HEAD
[1.0.0]: https://gitlab.com/bildcraft/products/video-downloader/-/releases/vdl-v1.0.0
