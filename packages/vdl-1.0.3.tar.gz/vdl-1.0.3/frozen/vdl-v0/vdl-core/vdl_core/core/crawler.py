"""
Selenium-based web crawler with JavaScript-first strategy.
Handles link discovery and pagination detection.
"""

import os
import re
import time
import json
from typing import Optional, Dict, List, Any, Tuple, Set
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from vdl_core.utils.logging import get_logger
import requests

logger = get_logger(__name__)

# Blacklist patterns to filter out
BLACKLIST_PATTERNS = [
    r"/login",
    r"/logout",
    r"/register",
    r"/profile",
    r"/account",
    r"trafficstars",
    r"ad\.",
    r"ads\.",
    r"\.pop\.",
    r"/signup",
    r"/signin",
    r"doubleclick",
    r"googleads",
]

# Pagination-related class/ID patterns
PAGINATION_CLASS_PATTERNS = [
    r"pagination",
    r"pager",
    r"pages?[-_]?(link|item|number|num|btn|nav|selector|controller|list)",
    r"next[-_]?(page|btn|button|link)",
    r"prev(ious)?[-_]?(page|btn|button|link)",
    r"nav(igation)?[-_]?pages?",
    r"paged?",
    r"item[-_]?pagination",
    r"load[-_]?more",
    r"\b(prev|next|page|pagination|pager)\b",
]


class CrawlerSession:
    """
    Context manager for maintaining a Selenium WebDriver session.
    Allows multiple operations on a single browser instance.
    """

    def __init__(self, cookie_file: Optional[str] = None, headless: bool = True):
        self.cookie_file = cookie_file
        self.headless = headless
        self.driver = None

    def __enter__(self):
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options

        chrome_options = Options()
        if self.headless:
            chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option("useAutomationExtension", False)
        chrome_options.add_argument("--log-level=3")

        try:
            self.driver = webdriver.Chrome(options=chrome_options)
            self.driver.set_page_load_timeout(30)
            return self
        except Exception as e:
            logger.error(f"Failed to initialize Selenium driver: {e}")
            raise

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.driver:
            self.driver.quit()
            self.driver = None

    def navigate(self, url: str, wait_time: float = 2.0):
        """Navigate to URL and apply cookies if configured."""
        if not self.driver:
            raise RuntimeError("Driver not initialized")

        # Parse domain for cookie application
        parsed = urlparse(url)
        base_url = f"{parsed.scheme}://{parsed.netloc}"

        # Load cookies if first navigation
        if self.cookie_file and os.path.exists(self.cookie_file):
            logger.debug("Applying cookies before navigation")
            self.driver.get(base_url)
            try:
                with open(self.cookie_file, "r") as f:
                    cookies = json.load(f)
                    for cookie in cookies:
                        try:
                            self.driver.add_cookie(cookie)
                        except Exception:
                            pass
            except Exception as e:
                logger.warning(f"Could not load cookies: {e}")
            finally:
                self.cookie_file = None  # Only apply once

        # Navigate to target URL
        self.driver.get(url)
        time.sleep(wait_time)
        logger.debug(f"Navigated to {url}")

    def get_page_source(self) -> str:
        """Get current page HTML source."""
        return self.driver.page_source if self.driver else ""

    def get_current_url(self) -> str:
        """Get current page URL."""
        return self.driver.current_url if self.driver else ""

    def click_element_js(self, selector: str, by_xpath: bool = False) -> bool:
        """
        Click element using JavaScript for reliability.
        """
        if not self.driver:
            return False

        try:
            from selenium.webdriver.common.by import By

            if by_xpath:
                elements = self.driver.find_elements(By.XPATH, selector)
            else:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)

            if elements:
                self.driver.execute_script("arguments[0].click();", elements[0])
                logger.debug(f"Clicked element: {selector}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error clicking element {selector}: {e}")
            return False

    def click_pagination_by_text(self, text: str) -> bool:
        """
        Click a pagination link by its text content and wait for DOM change.
        Follows strict pattern: find -> wait clickable -> click -> wait staleness.

        Args:
            text: Text to match (e.g. "2", "Next")

        Returns:
            True if click succeeded and DOM changed
        """
        if not self.driver:
            return False

        try:
            from selenium.webdriver.common.by import By
            from selenium.webdriver.support.ui import WebDriverWait
            from selenium.webdriver.support import expected_conditions as EC
            from selenium.common.exceptions import (
                TimeoutException,
                StaleElementReferenceException,
            )

            wait = WebDriverWait(self.driver, 10)

            # 1. Find the element with robust XPath (handling whitespace and tag types)
            # Match <a>, <button>, <span>, <div> with exact normalized text
            xpath = (
                f"//*[self::a or self::button or self::span or self::div]"
                f"[normalize-space(text())='{text}']"
            )

            try:
                # Wait for it to be present and clickable
                element = wait.until(EC.element_to_be_clickable((By.XPATH, xpath)))
            except TimeoutException:
                # Fallback: Try partial text if exact match fails and it's not a digit
                if not text.isdigit():
                    xpath = (
                        f"//*[self::a or self::button or self::span or self::div]"
                        f"[contains(text(), '{text}')]"
                    )
                    try:
                        element = wait.until(
                            EC.element_to_be_clickable((By.XPATH, xpath))
                        )
                    except TimeoutException:
                        logger.warning(
                            f"Could not find clickable pagination element with text '{text}'"
                        )
                        return False
                else:
                    logger.warning(
                        f"Could not find clickable pagination element with number '{text}'"
                    )
                    return False

            # 2. Pick a reference element for staleness check BEFORE clicking
            # We want something that will likely likely be replaced.
            # Ideally the list of videos/items.
            # We can try to find a common container or just use one of the other links as a proxy.
            reference = None
            try:
                # Try to find the first "content" link or image that isn't the pagination itself
                candidates = self.driver.find_elements(
                    By.CSS_SELECTOR, "a[href], img[src]"
                )
                for c in candidates:
                    if c != element:
                        reference = c
                        break

                if not reference:
                    # Fallback to body (less reliable for partial updates but better than nothing)
                    reference = self.driver.find_element(By.TAG_NAME, "body")
            except Exception:
                pass

            # 3. Click (Try standard first, then JS)
            try:
                element.click()
                logger.debug(f"Clicked pagination text: {text}")
            except Exception as e:
                logger.debug(f"Standard click failed ({e}), trying JS click")
                self.driver.execute_script("arguments[0].click();", element)

            # 4. Wait for DOM change (Staleness of reference)
            if reference:
                try:
                    wait.until(EC.staleness_of(reference))
                    logger.debug("DOM change detected (staleness)")
                except TimeoutException:
                    logger.warning(
                        "DOM did not report staleness after click (content might not have updated)"
                    )
                    return True  # Return True anyway to attempt extraction? Or False?
                    # If it didn't change, we might simply be on the same page or it's just slow.
                    # Best to assume we might have moved.

            # Short grace period for new JS to render
            time.sleep(1.0)

            return True

        except Exception as e:
            logger.error(f"Error clicking pagination text {text}: {e}")
            return False

    def wait_for_dom_change(self, timeout: float = 10.0) -> bool:
        """
        Explicitly wait for DOM staleness.
        Useful when the action was triggered externally.
        """
        # This is mostly redundant if click_pagination_by_text handles it,
        # but kept for URL navigation fallback.
        if not self.driver:
            return False

        try:
            # Just wait a bit since we don't have a specific reference from before the action
            # This is hard to do correctly without the "before" snapshot.
            # We'll rely on time.sleep and implicit waits in finding elements later.
            time.sleep(2.0)
            return True
        except Exception:
            return False


class LinkCrawler:
    """
    JavaScript-first web crawler for link discovery.
    Falls back to non-JS crawling if JS fails.
    """

    @staticmethod
    def get_links_to_crawl(
        url: str, cookie_file: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Crawl a page and extract all links with classification.

        JavaScript crawling is attempted first. If it fails or yields no results,
        falls back to non-JavaScript crawling.

        Args:
            url: URL to crawl
            cookie_file: Path to cookies file (optional)

        Returns:
            Dict with:
                - 'all_links': List[Dict] - All links with metadata
                - 'pagination_links': List[Dict] - Numeric pagination links only
                - 'non_pagination_links': List[Dict] - All other links
                - 'method': str - 'javascript' or 'non_javascript'
        """
        logger.info(f"Starting link discovery for {url}")

        # Try JavaScript crawling first
        result = LinkCrawler._crawl_with_javascript(url, cookie_file)

        if result and result["all_links"]:
            logger.info(
                f"JavaScript crawling succeeded: {len(result['all_links'])} links found"
            )
            result["method"] = "javascript"
            return result

        # Fallback to non-JavaScript
        logger.warning(
            "JavaScript crawling failed or yielded no results, falling back to non-JS"
        )
        result = LinkCrawler._crawl_without_javascript(url, cookie_file)

        if result:
            result["method"] = "non_javascript"
            return result

        # Complete failure
        logger.error("Both JavaScript and non-JavaScript crawling failed")
        return {
            "all_links": [],
            "pagination_links": [],
            "non_pagination_links": [],
            "method": "failed",
        }

    @staticmethod
    def _crawl_with_javascript(
        url: str, cookie_file: Optional[str] = None
    ) -> Optional[Dict]:
        """Crawl using Selenium with JavaScript enabled."""
        try:
            with CrawlerSession(cookie_file=cookie_file) as session:
                session.navigate(url)

                # Check for homepage redirect (auth/bot detection)
                if LinkCrawler._is_homepage_redirect(url, session.get_current_url()):
                    logger.warning(
                        "Redirected to homepage - authentication or bot detection likely"
                    )
                    return None

                html = session.get_page_source()
                current_url = session.get_current_url()

                return LinkCrawler._parse_and_classify_links(html, current_url)

        except Exception as e:
            logger.error(f"JavaScript crawling error: {e}")
            return None

    @staticmethod
    def _crawl_without_javascript(
        url: str, cookie_file: Optional[str] = None
    ) -> Optional[Dict]:
        """Crawl using basic HTTP request without JavaScript (fallback)."""
        try:
            import requests

            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }

            # Simple request, handling cookies would require parsing netscape format manually for requests
            # For fallback, we assume public access or IP auth if cookies fail

            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()

            return LinkCrawler._parse_and_classify_links(response.text, url)

        except Exception as e:
            logger.error(f"Non-JavaScript crawling error: {e}")
            return None

    @staticmethod
    def _parse_and_classify_links(html: str, base_url: str) -> Dict[str, Any]:
        """
        Parse HTML and classify links into pagination and non-pagination.
        """
        soup = BeautifulSoup(html, "html.parser")

        all_links = []
        pagination_links = []
        non_pagination_links = []
        seen_urls = set()

        # Helper to extract text from element
        def get_element_text(el):
            # Prefer direct text, then title, then aria-label
            # Use dot operator equivalent for bs4 to get all text including nested
            t = el.get_text(strip=True)
            if not t:
                t = el.get("title", "")
            if not t:
                t = el.get("aria-label", "")
            return t or ""

        # Find <a>, <button>, <span>, <div> that might be links
        # We focus on <a> for standard links, but also look for buttons/divs with pagination classes
        anchors = soup.find_all(["a", "button", "div", "span"])

        seen_urls = set()

        for idx, anchor in enumerate(anchors):
            # 1. Extract URL (if any)
            href = anchor.get("href")
            onclick = anchor.get("onclick")

            # Skip elements with no interactive properties (unless they have pagination class)
            # Optimization: If it's a span/div/button, it MUST have a pagination-like class
            # or look like a number, otherwise scanning every div is expensive.
            is_generic = anchor.name in ["div", "span"]
            has_pag_context = LinkCrawler._has_pagination_context(anchor)

            if is_generic and not has_pag_context:
                # If it's just a number "2", we want it ONLY if context is good
                # But here we are just filtering generic elements to NOT process them as links.
                # If it has no context and is generic, skip it.
                continue

            if not href and not onclick and not has_pag_context:
                # If no href/onclick and not a pag class, only allow if strict numeric text
                # (handled above for generic, but check button too)
                txt = get_element_text(anchor)
                if not (txt.isdigit() or re.match(r"^[\(\[]?\d+[\)\]]?$", txt)):
                    continue

            # Determine "URL" for deduplication/navigation
            # If standard link
            if href:
                absolute_url = urljoin(base_url, href)
            else:
                # For button/span/div, we treat it as a JS "link"
                absolute_url = "javascript:void(0)"

            link_text = get_element_text(anchor)

            # Filter empty
            if not link_text:
                continue

            # Resolve absolute URL
            absolute_url = urljoin(base_url, href)

            # Basic validation
            parsed = urlparse(absolute_url)
            if not parsed.scheme or not parsed.netloc:
                continue

            # Normalize URL
            clean_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            if parsed.query:
                clean_url += f"?{parsed.query}"

            # Blacklist filter
            if any(
                re.search(pattern, clean_url, re.IGNORECASE)
                for pattern in BLACKLIST_PATTERNS
            ):
                continue

            # Deduplicate
            # For strictly numeric pagination, the TEXT is the key differentiator, not the URL.
            # (Many JS-sites use href="#" for all pages)
            is_numeric = link_text.strip().isdigit() or re.match(
                r"^[\(\[]?\d+[\)\]]?$", link_text.strip()
            )

            dedup_key = clean_url
            if is_numeric:
                dedup_key = f"{clean_url}::{link_text.strip()}"

            if dedup_key in seen_urls:
                continue
            seen_urls.add(dedup_key)

            # Build link metadata
            link_data = {
                "url": clean_url,
                "text": link_text,
                "index": idx,
            }

            # Pre-calculate XPath for robust clicking (Eager Extraction)
            if is_numeric:
                # Use the exact text we found to generate a robust locator
                # We use specific tag name (usually 'a') and '.' to handle nested tags like <span>3</span>
                clean_text = link_text.strip()
                tag_name = anchor.name

                # Try to use a class for checking if one exists and isn't 'active' (heuristic)
                # But simple tag+text is usually robust enough for strict numbers

                link_data["xpath"] = f"//{tag_name}[normalize-space(.)='{clean_text}']"

            all_links.append(link_data)

            # Classify as pagination or non-pagination
            if LinkCrawler._is_pagination_link(anchor, clean_url, link_text):
                pagination_links.append(link_data)
            else:
                non_pagination_links.append(link_data)

        logger.info(
            f"Classified {len(pagination_links)} pagination links, {len(non_pagination_links)} other links"
        )

        return {
            "all_links": all_links,
            "pagination_links": pagination_links,
            "non_pagination_links": non_pagination_links,
        }

    @staticmethod
    def _is_pagination_link(element, url: str, text: str) -> bool:
        """
        Determine if a link is a pagination link.
        STRICT MODE: Only accepts links where text is a number.
        """
        import re

        # 1. Strict Text Requirement: Must be "1", "2", "[1]", "(1)"
        # We reject "Page 1", "Next", ">>", etc. per user request.
        text_clean = text.strip()
        is_numeric = re.match(r"^[\(\[]?\d+[\)\]]?$", text_clean)

        if not is_numeric:
            return False

        # 2. Safety Check: Verify it validates as pagination via Context or URL
        # detecting just "1" could trigger on "1 comment" or "1 item"

        # Check URL patterns
        pagination_url_patterns = [
            r"[/\?&](?:page|p)[=/-]?\d+",
            r"[/\?&]offset[=/-]?\d+",
            r"[/\?&]start[=/-]?\d+",
            r"/\d+/?$",
            r"/\d+\.html?$",
            r"javascript:",  # Common for numeric SPA pagination
            r"#",  # Common for numeric SPA pagination
        ]

        # If URL looks like pagination, or logic defaults to JS/SPA, we accept
        if any(re.search(p, url, re.IGNORECASE) for p in pagination_url_patterns):
            return True

        # 3. Context Requirement (Strict)
        # Even if it's a number, we require some indication that it's pagination.
        # This filters out random numbers in the content (e.g. "5 comments", "Chapter 1")
        if LinkCrawler._has_pagination_context(element):
            return True

        return False

    @staticmethod
    def _has_pagination_context(element) -> bool:
        """
        Deep check if element or its parents have pagination-related indicators.
        Checks: class, id, aria-label, role, data-* attributes.
        """
        keywords = PAGINATION_CLASS_PATTERNS

        # Helper to check a string against keywords
        def matches_keywords(text):
            if not text:
                return False
            return any(re.search(p, text, re.IGNORECASE) for p in keywords)

        # 1. Check Element Attributes
        attrs_to_check = [
            element.get("class", []),
            element.get("id", ""),
            element.get("aria-label", ""),
            element.get("role", ""),
            element.get("data-role", ""),
            element.get("data-type", ""),
            element.get("data-pagination", ""),
        ]

        # Handle class list
        classes = element.get("class", [])
        if isinstance(classes, list):
            classes = " ".join(classes)

        if matches_keywords(str(classes)):
            return True
        if matches_keywords(str(element.get("id", ""))):
            return True
        if matches_keywords(str(element.get("aria-label", ""))):
            return True

        # Check all data- attributes
        for key, value in element.attrs.items():
            if "page" in key.lower() or "pagination" in key.lower():
                return True
            if isinstance(value, str) and matches_keywords(value):
                return True

        # 2. Check Parent Container (Recursive up to 3 levels)
        # Common containers: <ul class="pagination">, <div class="nav-links">
        parent = element.parent
        levels = 0
        while parent and levels < 3:
            # Check parent class/id
            parent_classes = parent.get("class", [])
            if isinstance(parent_classes, list):
                parent_classes = " ".join(parent_classes)

            if matches_keywords(str(parent_classes)):
                return True
            if matches_keywords(str(parent.get("id", ""))):
                return True

            # Check tag name (nav is a strong indicator)
            if parent.name == "nav":
                return True

            parent = parent.parent
            levels += 1

        return False

    @staticmethod
    def _is_homepage_redirect(original_url: str, final_url: str) -> bool:
        """Check if we were redirected to homepage."""
        original_parsed = urlparse(original_url)
        final_parsed = urlparse(final_url)

        if original_parsed.netloc == final_parsed.netloc:
            if final_parsed.path in ["", "/"] and original_parsed.path not in ["", "/"]:
                return True
        return False

    @staticmethod
    def navigate_pagination(
        session: CrawlerSession,
        pagination_url: str,
        pagination_text: Optional[str] = None,
        pagination_xpath: Optional[str] = None,
        wait_for_change: bool = True,
    ) -> bool:
        """
        Navigate to a pagination link.
        Prioritizes XPath -> Text -> URL.
        """
        # 1. XPath Click (Most Robust - Pre-calculated)
        if pagination_xpath:
            logger.debug(f"Navigating via extracted XPath: {pagination_xpath}")
            if session.click_element_js(pagination_xpath, by_xpath=True):
                if wait_for_change:
                    session.wait_for_dom_change()
                return True

        # 2. Text Click (Robust Fallback)
        if pagination_text:
            if session.click_pagination_by_text(pagination_text):
                return True
            logger.warning(
                f"Clicking '{pagination_text}' failed, falling back to URL navigation"
            )

        # 3. URL Navigation (Last Resort, usually for static sites)
        try:
            # If URL is # or javascript:, we can't really navigate via URL
            if pagination_url.strip() in ["#", "", "javascript:void(0)"]:
                logger.warning(
                    "Pagination URL is empty/placeholder and click failed. Navigation impossible."
                )
                return False

            current_url = session.get_current_url()
            session.navigate(pagination_url, wait_time=1.0)

            if wait_for_change:
                new_url = session.get_current_url()
                if new_url != current_url:
                    logger.info(f"URL-based pagination: {current_url} → {new_url}")
                    return True
                else:
                    return session.wait_for_dom_change()

            return True
        except Exception as e:
            logger.error(f"Pagination navigation error: {e}")
            return False
