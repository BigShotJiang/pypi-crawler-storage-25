"""
Library Manager
Logic for maintaining the local media database and filesystem state.
Responsible for:
- Indexing downloaded files
- Matching files with metadata entries
- Tracking disk usage and enforcing cleanup rules
- Managing watched/unwatched status
"""
