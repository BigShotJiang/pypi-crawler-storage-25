import os
import re
import subprocess
import asyncio
import logging
import sys
import io
from pathlib import Path
from typing import Optional, Any, Tuple, Callable
import yt_dlp
from vdl_core.utils.sanitizers import sanitize_filename
from vdl_core.core.models import DownloadProgress, DownloadStatus
from vdl_core.utils.logging import get_logger
from vdl_core.utils.console import console

logger = get_logger(__name__)
# Console is used for stderr errors

# Error patterns that indicate site-level bot detection or authentication issues
BOT_ERROR_PATTERNS = [
    r"Sign in to confirm you.?re not a bot",
    r"This content is age-restricted",
    r"The following content may contain",
    r"Please sign in to view this video",
    r"Ineligible for downloading",
    r"HTTP Error 403",
    r"Forbidden",
    r"access denied",
    r"web client only works when logged-in",
    r"only available to registered users",
    r"Incomplete YouTube ID",
    r"Sign in to confirm your age",
]

# Error patterns that indicate post-processing failure but download might be fine
POST_PROCESSSING_ERROR_PATTERNS = [
    r"Unable to embed using ffprobe & ffmpeg",
    r"Conversion failed",
    r"Metadata conversion failed",
    r"Thumbnail conversion failed",
]

INCOMPLETE_SUFFIXES = (".part", ".temp", ".ytdl")


class VideoDownloader:
    def __init__(self, config_manager):
        self.config = config_manager
        self.output_dir = self.config.get("output_dir")
        logger.debug(f"VideoDownloader initialized. Output dir: {self.output_dir}")
        self.ensure_output_dir()

        # Cache dependency and feature support
        self.impersonation_supported = self.check_impersonation()
        self.hardware_encoder_available = self.check_hardware_encoder()

        logger.debug(f"Impersonation supported: {self.impersonation_supported}")
        logger.debug(f"Hardware encoder available: {self.hardware_encoder_available}")

    def ensure_output_dir(self):
        """Create output directory if it doesn't exist"""
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)

    def check_ytdlp(self):
        """Check if yt-dlp is installed"""
        try:
            # If frozen (PyInstaller), we should try to import it or use -m
            if getattr(sys, "frozen", False):
                import yt_dlp

                version = yt_dlp.version.__version__
                logger.debug(f"yt-dlp found (library): version {version}")
                return True, version

            result = subprocess.run(
                ["yt-dlp", "--version"], capture_output=True, text=True, check=True
            )
            version = result.stdout.strip()
            logger.debug(f"yt-dlp found (executable): version {version}")
            return True, version
        except (subprocess.CalledProcessError, FileNotFoundError, ImportError) as e:
            logger.debug(f"yt-dlp not found or failed: {e}")
            return False, None

    def check_ffmpeg(self):
        """Check if ffmpeg is installed"""
        try:
            result = subprocess.run(
                ["ffmpeg", "-version"], capture_output=True, text=True, check=True
            )
            logger.debug(f"ffmpeg found: {result.stdout.splitlines()[0]}")
            return True
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            logger.debug(f"ffmpeg not found or failed: {e}")
            return False

    def check_hardware_encoder(self) -> bool:
        """Check if Apple VideoToolbox hardware encoder is available"""
        try:
            result = subprocess.run(
                ["ffmpeg", "-hide_banner", "-encoders"],
                capture_output=True,
                text=True,
                check=True,
            )
            # Check if h264_videotoolbox is available
            return "h264_videotoolbox" in result.stdout
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def check_impersonation(self) -> bool:
        """Check if any impersonation handler is registered in yt-dlp"""
        try:
            from yt_dlp.networking.impersonate import ImpersonateRequestHandler

            with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True}) as ydl:
                return any(
                    isinstance(h, ImpersonateRequestHandler)
                    for h in ydl._request_director.handlers.values()
                )
        except Exception:
            return False

    def check_video_codec(self, filepath: str) -> Tuple[bool, str]:
        """Check if video needs re-encoding for QuickTime"""
        try:
            cmd = [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=codec_name,codec_tag_string",
                "-of",
                "default=noprint_wrappers=1",
                filepath,
            ]

            result = subprocess.run(cmd, capture_output=True, text=True, check=True)

            output = result.stdout.lower()
            codec_name = ""
            codec_tag = ""

            for line in output.split("\n"):
                if "codec_name=" in line:
                    codec_name = line.split("=")[1].strip()
                elif "codec_tag_string=" in line:
                    codec_tag = line.split("=")[1].strip()

            # Check if it's already H.264 with avc1 tag
            is_compatible = codec_name == "h264" and codec_tag == "avc1"
            logger.debug(
                f"Codec check: {filepath} -> {codec_name}/{codec_tag} (Compatible: {is_compatible})"
            )

            return is_compatible, f"{codec_name} ({codec_tag})"

        except Exception as e:
            logger.warning(f"Could not check codec: {e}")
            return False, "unknown"

    def reencode_for_quicktime(self, filepath: str) -> bool:
        """Re-encode video to be QuickTime compatible with H.264 (AVC) codec using hardware acceleration"""
        try:
            # Check if already compatible
            is_compatible, current_codec = self.check_video_codec(filepath)

            if is_compatible:
                logger.info(f"Video already QuickTime compatible ({current_codec})")
                return True

            logger.info(f"Current codec: {current_codec}")

            # Check if hardware encoder is available (cached)
            use_hardware = self.hardware_encoder_available

            if use_hardware:
                logger.info(
                    "Re-encoding with Apple hardware acceleration (VideoToolbox)..."
                )
            else:
                logger.warning(
                    "Hardware acceleration not available, using software encoding"
                )

            temp_output = f"{filepath}.converting.mp4"

            # Build FFmpeg command with hardware or software encoding
            if use_hardware:
                # Hardware-accelerated encoding with Apple VideoToolbox
                logger.info(
                    "Re-encoding with Apple hardware acceleration (VideoToolbox)"
                )
                cmd = [
                    "ffmpeg",
                    "-i",
                    filepath,
                    "-c:v",
                    "h264_videotoolbox",  # Apple hardware encoder
                    "-b:v",
                    "5000k",  # Target bitrate (5 Mbps)
                    "-pix_fmt",
                    "yuv420p",  # Pixel format for compatibility
                    "-tag:v",
                    "avc1",  # Explicitly set FourCC to avc1
                    "-c:a",
                    "aac",  # AAC audio codec
                    "-b:a",
                    "192k",  # Audio bitrate
                    "-ac",
                    "2",  # Stereo audio
                    "-movflags",
                    "+faststart",  # Enable streaming
                    "-y",  # Overwrite output
                    temp_output,
                ]
                logger.debug(f"FFmpeg Hardware Command: {' '.join(cmd)}")
            else:
                # Software encoding fallback (original method)
                cmd = [
                    "ffmpeg",
                    "-i",
                    filepath,
                    "-c:v",
                    "libx264",  # H.264 video codec (software)
                    "-profile:v",
                    "high",  # High profile for better quality
                    "-level",
                    "4.1",  # Level 4.1 for compatibility
                    "-pix_fmt",
                    "yuv420p",  # Pixel format for compatibility
                    "-tag:v",
                    "avc1",  # Explicitly set FourCC to avc1
                    "-preset",
                    "medium",  # Encoding speed/quality balance
                    "-crf",
                    "23",  # Quality (lower = better, 23 is good)
                    "-c:a",
                    "aac",  # AAC audio codec
                    "-b:a",
                    "192k",  # Audio bitrate
                    "-ac",
                    "2",  # Stereo audio
                    "-movflags",
                    "+faststart",  # Enable streaming
                    "-y",  # Overwrite output
                    temp_output,
                ]
                logger.debug(f"FFmpeg Software Command: {' '.join(cmd)}")

            # Show progress
            logger.info(
                f"Running: ffmpeg -i '{os.path.basename(filepath)}' ... (re-encoding for compatibility)"
            )

            # Run ffmpeg with progress output
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                universal_newlines=True,
            )

            # Monitor progress
            for line in process.stdout:
                if "frame=" in line or "time=" in line or "speed=" in line:
                    # Extract and show progress info
                    # logger.debug(f"FFmpeg: {line.strip()}")
                    pass

            process.wait()

            if process.returncode == 0:
                # Verify the conversion
                is_compatible_new, new_codec = self.check_video_codec(temp_output)

                if is_compatible_new:
                    # Replace original with re-encoded version
                    os.replace(temp_output, filepath)
                    logger.info(f"Re-encoded successfully to {new_codec}")
                    return True
                else:
                    logger.warning(
                        f"Re-encoded but codec may not be optimal: {new_codec}"
                    )
                    os.replace(temp_output, filepath)
                    return True
            else:
                logger.error("Re-encoding failed")
                if os.path.exists(temp_output):
                    os.remove(temp_output)
                return False

        except Exception as e:
            logger.error(f"Re-encoding error: {e}")
            return False

    def list_formats(self, url):
        """List available formats for a URL"""
        try:
            logger.debug(f"Listing formats for: {url}")
            subprocess.run(["yt-dlp", "-F", url], check=True)
        except subprocess.CalledProcessError as e:
            logger.error(f"Error listing formats: {e}")

    def _build_output_template(
        self, playlist: bool = False, subdirectory: Optional[str] = None
    ) -> str:
        """Build output template with sanitization exec hook"""

        base_dir = self.output_dir
        if subdirectory:
            base_dir = os.path.join(base_dir, subdirectory)
            # Create subdirectory if it doesn't exist
            Path(base_dir).mkdir(parents=True, exist_ok=True)

        if playlist and not subdirectory:
            # yt-dlp internal playlist handling (fallback)
            return os.path.join(
                base_dir, "%(playlist)s/%(playlist_index)s - %(title)s.%(ext)s"
            )
        else:
            # Standard output or specifically managed subdirectory
            template = os.path.join(base_dir, "%(title)s.%(ext)s")
            logger.debug(f"Built output template: {template}")
            return template

    def _sanitize_output_file(self, filepath: str) -> str:
        """Sanitize the output file path"""

        if not filepath or not os.path.exists(filepath):
            return filepath

        directory = os.path.dirname(filepath)
        filename = os.path.basename(filepath)

        # Sanitize the filename
        sanitized_filename = sanitize_filename(filename)
        sanitized_path = os.path.join(directory, sanitized_filename)

        # Rename the file if different
        if filepath != sanitized_path:
            try:
                logger.debug(f"Sanitizing: {filename} -> {sanitized_filename}")
                os.rename(filepath, sanitized_path)
                logger.info(f"Renamed to: {sanitized_filename}")
                return sanitized_path
            except Exception as e:
                logger.warning(f"Could not rename file: {e}")
                return filepath

        logger.debug(f"Path already sanitized: {filepath}")
        return filepath

    def _rescue_temp_file(
        self, original_path: Optional[str], audio_only: bool = False
    ) -> Optional[str]:
        """Rescue and rename .temp files left by failed post-processing"""
        if not original_path:
            return None

        # Common yt-dlp temp suffixes
        temp_suffixes = [".temp", ".part"]
        directory = os.path.dirname(original_path)
        base_name, current_ext = os.path.splitext(original_path)

        # If we expect a video but have an audio-only extension, try to find the video version
        merge_ext = f".{self.config.get('merge_format', 'mp4')}"
        potential_paths = [original_path]
        if not audio_only and current_ext != merge_ext:
            logger.debug(
                f"Expected video ({merge_ext}) but got {current_ext}. Adding merge_ext to search."
            )
            potential_paths.insert(0, f"{base_name}{merge_ext}")

        for path in potential_paths:
            path_base = os.path.splitext(path)[0]
            path_ext = os.path.splitext(path)[1]

            # 1. Check for [path_base].temp[path_ext] or [path_base].part[path_ext]
            for suffix in temp_suffixes:
                temp_path = f"{path_base}{suffix}{path_ext}"
                if os.path.exists(temp_path) and os.path.getsize(temp_path) > 0:
                    try:
                        os.rename(temp_path, path)
                        logger.info(
                            f"Rescued temporary file: {os.path.basename(temp_path)} -> {os.path.basename(path)}"
                        )
                        return path
                    except Exception as e:
                        logger.warning(f"Failed to rescue {temp_path}: {e}")

            # 2. Check if the path itself exists and is non-empty
            if os.path.exists(path) and os.path.getsize(path) > 0:
                return path

        # 3. Fallback: Scan directory for any file with same base name but video extensions
        if not audio_only:
            video_exts = [".mp4", ".mkv", ".webm"]
            logger.debug(f"Video rescue scan started in: {directory}")

            try:
                if not os.path.exists(directory):
                    logger.debug(f"Directory does not exist for scan: {directory}")
                    return None

                logger.debug(f"Performing deep directory scan for: {base_name}*")
                for file in os.listdir(directory):
                    # Check if file starts with base_name AND has a video extension
                    # Use case-insensitive check and ignore common yt-dlp intermediate tags like .f137
                    lower_file = file.lower()
                    lower_base = base_name.lower()

                    if lower_file.startswith(lower_base) and any(
                        lower_file.endswith(ext) for ext in video_exts
                    ):
                        found_path = os.path.join(directory, file)
                        size = os.path.getsize(found_path)
                        logger.debug(f"Scan found match: {file} ({size} bytes)")
                        # Ensure it's not the .temp file we just failed to rename, and it has content
                        if size > 1024 * 1024:  # > 1MB
                            logger.info(f"Directory scan rescued: {file}")
                            return found_path
            except Exception as e:
                logger.warning(f"Directory scan failed: {e}")

        return None

    def _get_ydl_opts(
        self,
        quality: str,
        audio_only: bool,
        playlist: bool,
        level: int = 0,
        cookies: Optional[str] = None,
        cookies_from_browser: Optional[str] = None,
        no_download: bool = False,
        subdirectory: Optional[str] = None,
        logger_obj: Any = None,
        min_resolution: Optional[int] = None,
    ) -> dict:
        """Build yt-dlp options dictionary for YoutubeDL"""

        opts = {
            "outtmpl": self._build_output_template(playlist, subdirectory),
            "logger": logger_obj,
            "newline": True,
            "no_playlist": not playlist,
            "quiet": True,
            "no_warnings": True,
            # Enable node and bun runtimes in addition to the deno default.
            # yt-dlp only enables deno by default; node/bun are available on this system.
            "js_runtimes": {"deno": {}, "node": {}, "bun": {}},
        }

        # Format selection
        if audio_only:
            opts.update(
                {
                    "format": "bestaudio/best",
                    "postprocessors": [
                        {
                            "key": "FFmpegExtractAudio",
                            "preferredcodec": self.config.get("audio_format"),
                            "preferredquality": self.config.get("audio_quality"),
                        }
                    ],
                }
            )
        else:
            if quality == "best":
                if min_resolution:
                    # Apply minimum resolution filter
                    opts["format"] = (
                        f"bestvideo[height>={min_resolution}]+bestaudio/best[height>={min_resolution}]"
                    )
                else:
                    opts["format"] = "bestvideo+bestaudio/best"
            elif quality == "1080p":
                opts["format"] = (
                    "bestvideo[height<=1080]+bestaudio/best[height<=1080]/best"
                )
            elif quality == "720p":
                opts["format"] = (
                    "bestvideo[height<=720]+bestaudio/best[height<=720]/best"
                )
            elif quality == "480p":
                opts["format"] = (
                    "bestvideo[height<=480]+bestaudio/best[height<=480]/best"
                )

            opts["merge_output_format"] = self.config.get("merge_format")

        # Standard options
        opts["embedthumbnail"] = self.config.get("embed_thumbnail")
        opts["addmetadata"] = self.config.get("embed_metadata")
        opts["addchapters"] = self.config.get("embed_chapters")

        if self.config.get("write_subtitles"):
            opts.update(
                {
                    "writesubtitles": True,
                    "subtitleslangs": self.config.get("subtitle_langs").split(","),
                }
            )

        # Obfuscated mode: always impersonate a browser if any target is available.
        # Empty string tells yt-dlp to pick any available impersonation target.
        if self.impersonation_supported:
            opts["impersonate"] = ""

        # YouTube player client escalation
        # Level 0: default clients (android_vr + web_safari)
        # Level 1: tv + mweb — different client stack, less likely to be flagged
        # Level 2: cookies take over client selection automatically
        if level == 1:
            opts["extractor_args"] = {"youtube": {"player_client": ["tv,mweb"]}}

        if level >= 2:
            if cookies:
                opts["cookiefile"] = cookies
            elif cookies_from_browser:
                opts["cookiesfrombrowser"] = (cookies_from_browser,)

        if no_download:
            opts["skip_download"] = True

        return opts

    def _parse_progress(self, line: str) -> Optional[dict]:
        """Parse yt-dlp progress line and return dict with percent, speed, eta"""
        line = line.strip()
        if "[download]" not in line:
            return None

        percent_match = re.search(r"\[download\]\s+([0-9.]+)%", line)
        if not percent_match:
            return None

        speed_match = re.search(r"\bat\s+([^\s]+)", line)
        eta_match = re.search(r"\bETA\s+([0-9:]+)", line)

        if percent_match:
            return {
                "percent": float(percent_match.group(1)),
                "speed": speed_match.group(1) if speed_match else None,
                "eta": eta_match.group(1) if eta_match else None,
            }
        return None

    def _progress_from_hook(self, data: dict) -> Optional[dict]:
        """Normalize yt-dlp progress hook payloads into the app's progress shape."""
        status = data.get("status")
        if status not in {"downloading", "finished"}:
            return None

        downloaded = data.get("downloaded_bytes") or 0
        total = (
            data.get("total_bytes")
            or data.get("total_bytes_estimate")
            or data.get("info_dict", {}).get("filesize")
            or data.get("info_dict", {}).get("filesize_approx")
        )

        percent = None
        if status == "finished":
            percent = 100.0
        elif total and total > 0:
            percent = min(100.0, max(0.0, (downloaded / total) * 100))

        speed = data.get("speed")
        eta = data.get("eta")

        if isinstance(speed, (int, float)) and speed >= 0:
            speed = yt_dlp.utils.format_bytes(speed) + "/s"

        if eta is not None:
            eta = yt_dlp.utils.formatSeconds(eta)

        return {
            "percent": percent,
            "speed": speed,
            "eta": eta,
            "status": status,
            "filename": data.get("filename"),
        }

    def _process_output_line(
        self,
        line: str,
        current_output_file: Optional[str],
        level: int,
        audio_only: bool,
    ) -> Tuple[Optional[str], bool, bool]:
        """
        Shared logic for parsing yt-dlp output lines.
        Returns (new_output_file, should_retry, post_processing_error)
        """
        line_str = line.strip()
        if not line_str:
            return current_output_file, False, False

        should_retry = False
        post_processing_error = False
        output_file = current_output_file

        # 1. Check for Bot Detection Errors (Escalation Trigger)
        if any(
            re.search(pattern, line_str, re.IGNORECASE)
            for pattern in BOT_ERROR_PATTERNS
        ):
            logger.debug(f"Matched BOT_ERROR_PATTERN in line: {line_str}")
            if level < 2:
                logger.warning(
                    f"Bot detection triggered at Level {level}. Escalating..."
                )
                should_retry = True
            else:
                logger.error(f"Bot detection failed at max escalation Level {level}.")

        # 2. Check for Post-processing Errors (Resiliency)
        if any(
            re.search(pattern, line_str, re.IGNORECASE)
            for pattern in POST_PROCESSSING_ERROR_PATTERNS
        ):
            logger.warning(f"Post-processing error detected: {line_str}")
            post_processing_error = True

        # 3. Destination tracking
        if "[download] Destination:" in line_str:
            dest = line_str.split("[download] Destination:")[1].strip()
            # Prefer final extension (like .mp4) over parts (like .m4a or .f137.mp4)
            expected_ext = f".{self.config.get('merge_format', 'mp4')}"
            if (
                not output_file
                or dest.endswith(expected_ext)
                or (audio_only and dest.endswith(".mp3"))
            ):
                output_file = dest
            logger.debug(f"Destination detected: {os.path.basename(dest)}")

        elif "[Merger] Merging formats into" in line_str:
            match = re.search(r'"([^"]+)"', line_str)
            if match:
                output_file = match.group(1)
                logger.debug(f"Merging into: {os.path.basename(output_file)}")

        return output_file, should_retry, post_processing_error

    def _finalize_download(
        self,
        url: str,
        output_file: Optional[str],
        return_code: int,
        post_processing_error: bool,
        audio_only: bool,
    ) -> Tuple[bool, Optional[str]]:
        """
        Shared logic for finalization (rescue, sanitize, re-encode).
        """
        # Check for rescued file if post-processing failed
        final_file = output_file
        if post_processing_error or return_code != 0:
            final_file = self._rescue_temp_file(output_file, audio_only=audio_only)

        # Success OR Rescued file
        if return_code == 0 or (final_file and os.path.exists(final_file)):
            if return_code != 0:
                logger.debug(f"Exit code {return_code} but file exists/rescued.")
                logger.warning(
                    f"Download rescued despite error code {return_code}: {url}"
                )

            # Sanitize filename
            if final_file:
                final_file = self._sanitize_output_file(final_file)

            # Re-encode if configured
            if (
                not audio_only
                and self.config.get("reencode_for_quicktime")
                and final_file
            ):
                if final_file.endswith(".mp4") and os.path.exists(final_file):
                    logger.debug(f"Checking QuickTime compatibility for: {final_file}")
                    self.reencode_for_quicktime(final_file)

            return True, final_file

        return False, None

    def verify_video_link(self, url: str, cookies: Optional[str] = None) -> bool:
        """
        Quickly verify if a video link is valid and accessible using simulation.
        Returns True if valid, False otherwise.
        """
        logger.debug(f"Verifying video link: {url}")
        opts = {
            "simulate": True,
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
        }

        if cookies:
            opts["cookiefile"] = cookies

        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                # just trying to extract info is enough to verify availability
                info = ydl.extract_info(url, download=False)
                if info and info.get("duration") is not None:
                    return True
                # Sometimes duration is None but it's still valid (e.g. livestreams)
                if info and info.get("title"):
                    return True
        except Exception as e:
            logger.warning(f"Video verification failed for {url}: {e}")
            return False

        return False

    def find_existing_download(
        self,
        url: str,
        audio_only: bool = False,
        cookies: Optional[str] = None,
        cookies_from_browser: Optional[str] = None,
        subdirectory: Optional[str] = None,
    ) -> Optional[str]:
        """
        Resolve the likely final output path for a URL and return it if it already exists.
        Used to make text-file batch downloads idempotent.
        """
        opts = self._get_ydl_opts(
            quality="best",
            audio_only=audio_only,
            playlist=False,
            level=2 if (cookies or cookies_from_browser) else 0,
            cookies=cookies,
            cookies_from_browser=cookies_from_browser,
            no_download=True,
            subdirectory=subdirectory,
            logger_obj=None,
            min_resolution=None,
        )
        opts["simulate"] = True

        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
                if not info:
                    return None

                prepared = ydl.prepare_filename(info)
                candidate_paths = {prepared, self._sanitize_output_path_only(prepared)}

                target_ext = (
                    self.config.get("audio_format", "mp3")
                    if audio_only
                    else self.config.get("merge_format", "mp4")
                )

                expanded_candidates = set()
                for candidate in candidate_paths:
                    expanded_candidates.add(candidate)
                    root, _ext = os.path.splitext(candidate)
                    retargeted = f"{root}.{target_ext}"
                    expanded_candidates.add(retargeted)
                    expanded_candidates.add(self._sanitize_output_path_only(retargeted))

                for candidate in expanded_candidates:
                    if self._is_completed_download(candidate):
                        return candidate
        except Exception as e:
            logger.debug(f"Existing-download lookup failed for {url}: {e}")

        return None

    def _sanitize_output_path_only(self, filepath: str) -> str:
        """Return the sanitized version of a path without mutating the filesystem."""
        if not filepath:
            return filepath

        directory = os.path.dirname(filepath)
        filename = os.path.basename(filepath)
        return os.path.join(directory, sanitize_filename(filename))

    def _has_incomplete_artifacts(self, filepath: str) -> bool:
        """Return True when temp/partial artifacts exist for a target output path."""
        if not filepath:
            return False

        directory = os.path.dirname(filepath)
        filename = os.path.basename(filepath)
        stem, ext = os.path.splitext(filename)

        artifact_names = {
            f"{stem}.part{ext}",
            f"{stem}.temp{ext}",
            f"{stem}{ext}.part",
            f"{stem}{ext}.temp",
            f"{stem}.ytdl",
        }

        for artifact_name in artifact_names:
            artifact_path = os.path.join(directory, artifact_name)
            if os.path.exists(artifact_path) and os.path.getsize(artifact_path) > 0:
                return True

        return False

    def _is_completed_download(self, filepath: str) -> bool:
        """
        Only completed, reusable files should satisfy idempotency.
        Temp artifacts or final files accompanied by partial remnants must be retried.
        """
        if not filepath or not os.path.exists(filepath) or os.path.isdir(filepath):
            return False

        filename = os.path.basename(filepath).lower()
        if filename.endswith(INCOMPLETE_SUFFIXES):
            return False

        if os.path.getsize(filepath) <= 0:
            return False

        if self._has_incomplete_artifacts(filepath):
            logger.info(
                f"Incomplete artifacts detected for {filepath}; allowing re-download."
            )
            return False

        return True

    def download_video(
        self,
        url: str,
        quality: Optional[str] = None,
        audio_only: Optional[bool] = None,
        playlist: bool = False,
        show_progress: bool = True,
        cookies: Optional[str] = None,
        cookies_from_browser: Optional[str] = None,
        no_download: bool = False,
        subdirectory: Optional[str] = None,
        min_resolution: Optional[int] = None,
    ) -> Tuple[str, Optional[str]]:
        """Download video synchronously with real-time progress and adaptive retry. Returns (status, output_file). Status: 'success', 'skipped', 'failed'"""

        existing_file = self.find_existing_download(
            url,
            audio_only=bool(audio_only),
            cookies=cookies,
            cookies_from_browser=cookies_from_browser,
            subdirectory=subdirectory,
        )
        if existing_file and not no_download:
            logger.info(f"Skipping existing download: {existing_file}")
            return "skipped", existing_file

        # Pre-verification to avoid false starts
        if not playlist and not no_download:
            # Skip verification if it's a playlist (handled by playlist processor) or if we are not downloading
            if not self.verify_video_link(url, cookies=cookies):
                logger.error(
                    f"Link verification failed: {url}. Skipping download attempt."
                )
                return "failed", None

        # Use config defaults if not specified
        if quality is None:
            quality = self.config.get("default_quality", "best")
        if audio_only is None:
            audio_only = self.config.get("audio_only", False)

        # Determine starting level
        force_auth = cookies is not None or cookies_from_browser is not None
        start_level = 2 if force_auth else 0

        output_file = None

        for level in range(start_level, 3):
            # Local state for this attempt
            attempt_data = {
                "output_file": output_file,
                "should_retry": False,
                "pp_error": False,
            }

            parent_self = self  # To use in nested classes

            def progress_hook(data):
                hook_progress = parent_self._progress_from_hook(data)
                if not hook_progress:
                    return

                filename = hook_progress.get("filename")
                if filename:
                    attempt_data["output_file"] = filename

                if not show_progress:
                    return

                percent = hook_progress.get("percent")
                speed = hook_progress.get("speed")
                eta = hook_progress.get("eta")

                if percent is not None:
                    speed_text = f" at {speed}" if speed else ""
                    eta_text = f" ETA {eta}" if eta else ""
                    print(
                        f"[download] {percent:5.1f}%{speed_text}{eta_text}",
                        end="\r",
                        flush=True,
                    )

            class YDLBridgeLogger:
                def debug(self, msg):
                    if "[download]" in msg and "%" in msg:
                        if show_progress:
                            print(msg.strip(), end="\r", flush=True)
                    new_file, retry, pp = parent_self._process_output_line(
                        msg, attempt_data["output_file"], level, audio_only
                    )
                    if new_file:
                        attempt_data["output_file"] = new_file
                    if retry:
                        attempt_data["should_retry"] = True
                    if pp:
                        attempt_data["pp_error"] = True

                def info(self, msg):
                    self.debug(msg)

                def warning(self, msg):
                    self.debug(msg)

                def error(self, msg):
                    self.debug(msg)

            # Build options
            ydl_opts = self._get_ydl_opts(
                quality=quality,
                audio_only=audio_only,
                playlist=playlist,
                level=level,
                cookies=cookies,
                cookies_from_browser=cookies_from_browser,
                no_download=no_download,
                subdirectory=subdirectory,
                logger_obj=YDLBridgeLogger(),
                min_resolution=min_resolution,
            )
            ydl_opts["progress_hooks"] = [progress_hook]

            logger.debug(f"Attempting level {level} (Sync Library call)")
            return_code = 0
            try:
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    return_code = ydl.download([url])
            except Exception as e:
                logger.debug(f"Download error during level {level}: {e}")
                return_code = 1
                # If we get a known error line in the exception message, it might trigger retry
                _, retry, _ = self._process_output_line(
                    str(e), attempt_data["output_file"], level, audio_only
                )
                if retry:
                    attempt_data["should_retry"] = True

                # Check for skip conditions
                if "Requested format is not available" in str(e):
                    logger.info(f"Skipping {url}: Requested resolution not available.")
                    return "skipped", None

            # Decide outcome
            if attempt_data["should_retry"] and level < 2:
                logger.info(f"Retrying at next level due to bot detection...")
                continue

            success, final_file = self._finalize_download(
                url=url,
                output_file=attempt_data["output_file"],
                return_code=return_code,
                post_processing_error=attempt_data["pp_error"],
                audio_only=audio_only,
            )

            if success:
                return "success", final_file
            elif not attempt_data["should_retry"]:
                return "failed", None

        return "failed", None

    async def download_video_async(
        self,
        url: str,
        quality: Optional[str] = None,
        audio_only: Optional[bool] = None,
        playlist: bool = False,
        task_id: Optional[str] = None,
        on_progress: Optional[Callable[[DownloadProgress], None]] = None,
        cookies: Optional[str] = None,
        cookies_from_browser: Optional[str] = None,
        subdirectory: Optional[str] = None,
        min_resolution: Optional[int] = None,
    ) -> Tuple[str, Optional[str]]:
        """Download video asynchronously with callback-based progress and adaptive retry. Returns (status, output_file). Status: 'success', 'skipped', 'failed'"""

        existing_file = await asyncio.to_thread(
            self.find_existing_download,
            url,
            bool(audio_only),
            cookies,
            cookies_from_browser,
            subdirectory,
        )
        if existing_file:
            logger.info(f"Skipping existing download: {existing_file}")
            if on_progress:
                on_progress(
                    DownloadProgress(
                        id=task_id or url,
                        status=DownloadStatus.COMPLETED,
                        percent=100.0,
                        current_file=existing_file,
                        output_path=existing_file,
                    )
                )
            return "skipped", existing_file

        # Use config defaults if not specified
        if quality is None:
            quality = self.config.get("default_quality", "best")
        if audio_only is None:
            audio_only = self.config.get("audio_only", False)

        force_auth = cookies is not None or cookies_from_browser is not None
        start_level = 2 if force_auth else 0

        output_file = None

        for level in range(start_level, 3):
            attempt_data = {
                "output_file": output_file,
                "should_retry": False,
                "pp_error": False,
            }

            parent_self = self

            def progress_hook(data):
                hook_progress = parent_self._progress_from_hook(data)
                if not hook_progress or not on_progress:
                    return

                filename = hook_progress.get("filename")
                if filename:
                    attempt_data["output_file"] = filename

                if hook_progress.get("status") == "finished":
                    on_progress(
                        DownloadProgress(
                            id=task_id or url,
                            status=DownloadStatus.PROCESSING,
                            percent=100.0,
                            speed=hook_progress.get("speed"),
                            eta=hook_progress.get("eta"),
                            current_file=attempt_data["output_file"],
                        )
                    )
                    return

                on_progress(
                    DownloadProgress(
                        id=task_id or url,
                        status=DownloadStatus.DOWNLOADING,
                        percent=hook_progress.get("percent"),
                        speed=hook_progress.get("speed"),
                        eta=hook_progress.get("eta"),
                        current_file=attempt_data["output_file"],
                    )
                )

            class YDLBridgeLogger:
                def debug(self, msg):
                    new_file, retry, pp = parent_self._process_output_line(
                        msg, attempt_data["output_file"], level, audio_only
                    )
                    if new_file:
                        attempt_data["output_file"] = new_file
                    if retry:
                        attempt_data["should_retry"] = True
                    if pp:
                        attempt_data["pp_error"] = True

                    if on_progress:
                        # Parse progress if enabled
                        progress_data = parent_self._parse_progress(msg)
                        if progress_data:
                            on_progress(
                                DownloadProgress(
                                    id=task_id or url,
                                    status=DownloadStatus.DOWNLOADING,
                                    percent=progress_data["percent"],
                                    speed=progress_data["speed"],
                                    eta=progress_data["eta"],
                                    current_file=attempt_data["output_file"],
                                )
                            )
                        elif any(
                            tag in msg
                            for tag in [
                                "[ExtractAudio]",
                                "[EmbedThumbnail]",
                                "[Metadata]",
                            ]
                        ):
                            on_progress(
                                DownloadProgress(
                                    id=task_id or url,
                                    status=DownloadStatus.PROCESSING,
                                    current_file=attempt_data["output_file"],
                                )
                            )

                def info(self, msg):
                    self.debug(msg)

                def warning(self, msg):
                    self.debug(msg)

                def error(self, msg):
                    self.debug(msg)

            ydl_opts = self._get_ydl_opts(
                quality=quality,
                audio_only=audio_only,
                playlist=playlist,
                level=level,
                cookies=cookies,
                cookies_from_browser=cookies_from_browser,
                subdirectory=subdirectory,
                logger_obj=YDLBridgeLogger(),
                min_resolution=min_resolution,
            )
            ydl_opts["progress_hooks"] = [progress_hook]

            logger.debug(f"Attempting Level {level} (Async Library call)")

            try:
                # Run the blocking library call in a separate thread
                def run_ydl():
                    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                        return ydl.download([url])

                return_code = await asyncio.to_thread(run_ydl)

                if attempt_data["should_retry"] and level < 2:
                    continue

                success, final_file = await asyncio.to_thread(
                    self._finalize_download,
                    url,
                    attempt_data["output_file"],
                    return_code,
                    attempt_data["pp_error"],
                    audio_only,
                )

                if success:
                    if on_progress:
                        on_progress(
                            DownloadProgress(
                                id=task_id or url,
                                status=DownloadStatus.COMPLETED,
                                current_file=final_file,
                                output_path=final_file,
                            )
                        )
                    return "success", final_file
                elif not attempt_data["should_retry"]:
                    if on_progress:
                        on_progress(
                            DownloadProgress(
                                id=task_id or url,
                                status=DownloadStatus.FAILED,
                                error="Download failed",
                            )
                        )
                    return "failed", None
            except Exception as e:
                err_str = str(e)

                if "Requested format is not available" in err_str:
                    logger.info(f"Skipping {url}: Requested resolution not available.")
                    return "skipped", None

                # Check exception message for bot/retry patterns (same as logger path)
                _, retry, _ = self._process_output_line(
                    err_str, attempt_data["output_file"], level, audio_only
                )
                if retry:
                    attempt_data["should_retry"] = True

                logger.error(f"Async error Level {level}: {e}")
                if on_progress:
                    on_progress(
                        DownloadProgress(
                            id=task_id or url,
                            status=DownloadStatus.FAILED,
                            error=err_str,
                        )
                    )
                if level == 2 or not attempt_data["should_retry"]:
                    return "failed", None

        return "failed", None
