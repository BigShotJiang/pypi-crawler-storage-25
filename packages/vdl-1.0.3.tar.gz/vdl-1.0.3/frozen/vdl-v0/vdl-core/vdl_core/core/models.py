from enum import Enum
from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime, UTC


class DownloadStatus(str, Enum):
    """Lifecycle states for a download task."""

    QUEUED = "queued"
    STARTING = "starting"
    DOWNLOADING = "downloading"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class DownloadProgress:
    """
    Data transfer object for download progress updates.
    Using dataclass to avoid Pydantic dependency in core.
    """

    id: str
    status: DownloadStatus
    percent: Optional[float] = 0.0
    speed: Optional[str] = None
    eta: Optional[int] = None
    current_file: Optional[str] = None
    error: Optional[str] = None
    output_path: Optional[str] = None
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
