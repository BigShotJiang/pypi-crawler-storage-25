"""
Playlist processor for expanding URLs and managing crawl sequences.
Handles playlist detection, pagination logic, and crawl orchestration.
"""

from typing import List, Optional, Dict, Any
import subprocess
import json
from vdl_core.core.crawler import LinkCrawler, CrawlerSession
from vdl_core.utils.logging import get_logger

logger = get_logger(__name__)


class PlaylistProcessor:
    """
    Processor for expanding URLs into lists of links.
    Handles native playlists (YouTube) and paginated sites.
    """

    @staticmethod
    def expand_url_native(
        url: str, cookies: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Try to expand URL using native yt-dlp playlist extraction.

        Args:
            url: URL to expand
            cookies: Cookie file path

        Returns:
            Dict with 'links' and 'title', or None if not a native playlist
        """
        try:
            logger.info(f"Attempting native playlist extraction for {url}")
            cmd = ["yt-dlp", "--flat-playlist", "-J", url]

            if cookies:
                cmd.extend(["--cookies", cookies])

            result = subprocess.run(
                cmd, capture_output=True, text=True, check=True, timeout=30
            )
            data = json.loads(result.stdout)

            title = data.get("title") or data.get("playlist_title")

            if "entries" in data:
                # It's a playlist
                links = [
                    entry.get("url") or entry.get("original_url")
                    for entry in data["entries"]
                    if entry
                ]
                links = [l for l in links if l]
                logger.info(
                    f"Native extraction found {len(links)} items in playlist: {title}"
                )
                return {"links": links, "title": title, "is_playlist": True}
            else:
                # Single video
                logger.info(f"Native extraction identified single video: {title}")
                return {"links": [url], "title": title, "is_playlist": False}

        except subprocess.TimeoutExpired:
            logger.warning("Native extraction timed out")
        except subprocess.CalledProcessError:
            logger.warning("Native extraction failed (not supported or error)")
        except Exception as e:
            logger.error(f"Error during native extraction: {e}")

        return None

    @staticmethod
    def discover_links(url: str, cookies: Optional[str] = None) -> Dict[str, Any]:
        """
        Discover all links on a page with pagination classification.

        This is the primary entry point for link discovery.
        Uses JavaScript-first crawling strategy via LinkCrawler.

        Args:
            url: URL to crawl
            cookies: Cookie file path

        Returns:
            Dict with classified links
        """
        logger.info(f"Discovering links on {url}")

        result = LinkCrawler.get_links_to_crawl(url, cookie_file=cookies)
        result["current_url"] = url

        # NOTE: Heuristic expansion (100 pages) has been removed.
        # We now rely STRICTLY on what the crawler finds.

        return result

    @staticmethod
    def crawl_pages(
        base_url: str,
        selected_pagination: List[Dict],
        cookies: Optional[str] = None,
        include_base: bool = True,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Crawl multiple pages based on selected pagination links.

        Args:
            base_url: Starting URL (Page 1)
            selected_pagination: List of pagination link dicts to crawl
            cookies: Cookie file path
            include_base: Whether to include base_url in results

        Returns:
            Dict mapping "Page N" -> {'links': List[str], 'url': str}
        """
        results = {}

        with CrawlerSession(cookie_file=cookies) as session:
            # Crawl base page first if requested
            if include_base:
                logger.info(f"Crawling base page: {base_url}")
                session.navigate(base_url)
                html = session.get_page_source()
                current_url = session.get_current_url()

                page_result = LinkCrawler._parse_and_classify_links(html, current_url)
                all_page_links = [link["url"] for link in page_result["all_links"]]

                # Base page is always Page 1
                results["Page 1"] = {"links": all_page_links, "url": current_url}
                logger.info(f"Page 1: {len(all_page_links)} links")

            # Crawl each selected pagination page
            # We treat pagination links as strictly ordered steps if they are simple numbers
            for idx, pag_link in enumerate(
                selected_pagination, start=2 if include_base else 1
            ):
                pagination_url = pag_link["url"]

                # Determine display number
                actual_page_num = PlaylistProcessor.extract_page_number(pag_link)
                display_num = (
                    actual_page_num
                    if actual_page_num
                    else (idx if include_base else idx + 1)
                )

                # Prepare text for clicking
                pagination_text = pag_link.get("text")
                if not pagination_text or not pagination_text.strip():
                    if actual_page_num:
                        pagination_text = str(actual_page_num)

                logger.info(f"Crawling Page {display_num}: {pagination_url}")

                # Navigate to pagination link
                # Priority: XPath (if extracted) -> Text -> URL
                success = LinkCrawler.navigate_pagination(
                    session,
                    pagination_url,
                    pagination_text=pagination_text,
                    pagination_xpath=pag_link.get("xpath"),
                )

                if not success:
                    logger.warning(f"Failed to navigate to Page {display_num}")
                    results[f"Page {display_num}"] = {
                        "links": [],
                        "url": pagination_url,
                    }
                    continue

                # Extract links from this page
                html = session.get_page_source()
                current_url = session.get_current_url()

                page_result = LinkCrawler._parse_and_classify_links(html, current_url)
                all_page_links = [link["url"] for link in page_result["all_links"]]

                results[f"Page {display_num}"] = {
                    "links": all_page_links,
                    "url": current_url,
                }
                logger.info(f"Page {display_num}: {len(all_page_links)} links")

        return results

    @staticmethod
    def filter_numeric_pagination(pagination_links: List[Dict]) -> List[Dict]:
        """
        Filter pagination links to only those containing numbers.

        Args:
            pagination_links: List of pagination link dicts

        Returns:
            Filtered list containing only numeric pagination
        """
        import re

        numeric_pagination = []
        for link in pagination_links:
            url = link["url"]
            text = link["text"]

            # Must contain at least one digit in URL or text
            if re.search(r"\d", url) or re.search(r"\d", text):
                numeric_pagination.append(link)

        return numeric_pagination

    @staticmethod
    def extract_page_number(pagination_link: Dict) -> Optional[int]:
        """
        Extract page number from pagination link.

        Args:
            pagination_link: Pagination link dict

        Returns:
            Page number as int, or None if cannot determine
        """
        import re

        text = pagination_link.get("text", "")
        url = pagination_link.get("url", "")

        # Try text first (most reliable for numbered links)
        if text.strip().isdigit():
            return int(text.strip())

        # Try URL patterns
        patterns = [
            r"page[=_-]?(\d+)",
            r"\?p=(\d+)",
            r"/(\d+)/?$",
            r"offset=(\d+)",
            r"start=(\d+)",
        ]

        for pattern in patterns:
            match = re.search(pattern, url, re.IGNORECASE)
            if match:
                return int(match.group(1))

        # Try to extract any number from text as last resort
        numbers = re.findall(r"\d+", text)
        if numbers:
            return int(numbers[0])

        return None
