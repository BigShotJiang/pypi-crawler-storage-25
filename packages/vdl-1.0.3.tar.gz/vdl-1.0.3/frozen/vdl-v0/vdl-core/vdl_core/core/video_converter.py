import asyncio
import os
import json
from typing import Optional, Callable, Dict, List, Any
from vdl_core.utils.logging import get_logger

logger = get_logger(__name__)


class VideoConverter:
    """
    Handles local video conversion using ffmpeg.
    Dynamically adjusts output settings based on input file analysis.
    """

    @staticmethod
    async def convert_video_async(
        input_path: str,
        output_path: str,
        quality: str = "best",
        on_progress: Optional[Callable[[float], None]] = None,
    ) -> bool:
        """
        Convert a local video file using ffmpeg with dynamic quality calculation.
        """
        if not os.path.exists(input_path):
            logger.error(f"Input file not found: {input_path}")
            return False

        # 1. Analyze Input File
        info = await VideoConverter._get_video_info(input_path)
        if not info:
            logger.error("Failed to analyze input video metadata.")
            return False

        logger.info(
            f"Input Info: {info['width']}x{info['height']} @ {info['fps']}fps, {info['duration']}s"
        )

        # 2. Calculate Dynamic Arguments
        ffmpeg_args = VideoConverter._calculate_dynamic_settings(info, quality)

        # 3. Build Command
        # -progress pipe:2 sends progress stats to stderr for parsing
        cmd = (
            ["ffmpeg", "-y", "-progress", "pipe:2", "-i", input_path]
            + ffmpeg_args
            + [output_path]
        )

        logger.info(f"Running conversion: {' '.join(cmd)}")

        try:
            process = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )

            # 4. Progress Tracking
            duration_us = int(info["duration"] * 1000000)

            while True:
                line = await process.stderr.readline()
                if not line:
                    break

                line_str = line.decode("utf-8", errors="ignore").strip()

                # Parse FFmpeg progress (key=value format)
                if "out_time_us=" in line_str:
                    try:
                        current_time_us = int(line_str.split("=")[1])
                        if current_time_us > 0 and duration_us > 0:
                            progress = min(100.0, (current_time_us / duration_us) * 100)
                            if on_progress:
                                on_progress(progress)
                    except (ValueError, IndexError):
                        pass

            await process.wait()

            if process.returncode == 0:
                if on_progress:
                    on_progress(100.0)
                logger.info(f"Conversion successful: {output_path}")
                return True
            else:
                # Read any remaining error log
                error_log = (await process.stderr.read()).decode()
                logger.error(f"FFmpeg error: {error_log}")
                return False

        except Exception as e:
            logger.error(f"Conversion failed: {e}")
            return False

    @staticmethod
    def _calculate_dynamic_settings(info: Dict[str, Any], quality: str) -> List[str]:
        """
        Generates FFmpeg arguments relative to the input file's properties.
        Preserves original resolution as requested.
        """
        # Base settings (codec, faststart for web, pixel format)
        base_args = [
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
            "-c:a",
            "aac",
        ]

        if quality == "low":
            # High compression, mono audio, lower FPS target
            crf = "32"
            preset = "veryfast"
            audio_bitrate = "64k"
            audio_channels = "1"
            target_fps = 24
        elif quality == "medium":
            # Balanced compression, stereo audio, standard FPS target
            crf = "26"
            preset = "faster"
            audio_bitrate = "96k"
            audio_channels = "2"
            target_fps = 30
        else:  # 'best'
            # High quality, slow preset, original FPS
            crf = "21"
            preset = "slow"
            audio_bitrate = "128k"
            audio_channels = "2"
            target_fps = info.get("fps", 30)

        # Build combining args
        final_args = base_args + [
            "-crf",
            crf,
            "-preset",
            preset,
            "-b:a",
            audio_bitrate,
            "-ac",
            audio_channels,
        ]

        # Dynamic FPS: min(current, target)
        input_fps = info.get("fps", 30)
        if input_fps > target_fps:
            final_args += ["-r", str(target_fps)]

        return final_args

    @staticmethod
    async def _get_video_info(file_path: str) -> Optional[Dict[str, Any]]:
        """
        Extracts width, height, fps, and duration using ffprobe JSON output.
        """
        try:
            cmd = [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=width,height,r_frame_rate,duration",
                "-of",
                "json",
                file_path,
            ]

            process = await asyncio.create_subprocess_exec(
                *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await process.communicate()

            if process.returncode != 0:
                return None

            data = json.loads(stdout)
            stream = data["streams"][0]

            # Calculate FPS from fraction (e.g., "60/1" or "30000/1001")
            fps_str = stream.get("r_frame_rate", "30/1")
            if "/" in fps_str:
                num, den = map(int, fps_str.split("/"))
                fps = num / den if den != 0 else 30.0
            else:
                fps = float(fps_str)

            # Get duration (check stream first, fallbacks might be needed for containers)
            duration = float(stream.get("duration", 0))

            return {
                "width": int(stream.get("width", 0)),
                "height": int(stream.get("height", 0)),
                "fps": fps,
                "duration": duration,
            }
        except Exception as e:
            logger.error(f"Error getting video info: {e}")
            return None
