"""
Metadata Extractor
Utility for retrieving rich information about media files.
Responsible for:
- Extracting thumbnails as JPG/PNG
- Using ffprobe to get codec, bitrate, and resolution info
- Parsing yt-dlp JSON metadata for library enrichment
"""
