"""
Batch Downloader Module
Handles batch downloads from text files with concurrent processing
"""

import os
import asyncio
from datetime import datetime
from typing import List, Optional
from rich.console import Console
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
)

from vdl_core.utils.console import console


class ReversedProgress(Progress):
    """Progress bar that shows newest tasks at the top"""

    def make_tasks_table(self, tasks):
        """Override to reverse the order of tasks in the table"""
        return super().make_tasks_table(reversed(list(tasks)))


class BatchDownloader:
    """Handles batch downloads from a file"""

    def __init__(self, downloader):
        self.downloader = downloader

    def load_urls_from_file(self, filepath: str) -> List[str]:
        """Load URLs from a file (one per line)"""
        try:
            with open(filepath, "r") as f:
                urls = [
                    line.strip()
                    for line in f
                    if line.strip() and not line.startswith("#")
                ]
            return urls
        except Exception as e:
            console.print(f"[red]Error reading file {filepath}: {e}[/red]")
            return []

    async def download_batch(
        self,
        urls: List[str],
        quality: Optional[str] = None,
        audio_only: Optional[bool] = None,
        cookies: Optional[str] = None,
        cookies_from_browser: Optional[str] = None,
        subdirectory: Optional[str] = None,
        min_resolution: Optional[int] = None,
    ):
        """Download multiple URLs concurrently using a worker queue"""

        # Get concurrency limit from config
        try:
            max_concurrent = int(
                self.downloader.config.get("max_concurrent_downloads", 3)
            )
        except (ValueError, TypeError):
            max_concurrent = 3

        console.print(
            f"\n[bold cyan]Starting batch download of {len(urls)} videos[/bold cyan]"
        )
        console.print(
            f"[cyan]Concurrency limit: {max_concurrent} (newest tasks at top)[/cyan]\n"
        )

        # Shared progress object
        progress = ReversedProgress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
            transient=False,
        )

        # Queue to manage tasks
        queue = asyncio.Queue()
        for i, url in enumerate(urls):
            queue.put_nowait((url, i))

        results = []
        failed_urls = []

        async def worker():
            while not queue.empty():
                try:
                    url, index = await queue.get()
                except asyncio.QueueEmpty:
                    break

                short_url = url[:40] + "..." if len(url) > 40 else url
                task_id = progress.add_task(
                    f"[cyan][{index + 1}/{len(urls)}] {short_url}", total=100
                )

                def on_progress(p):
                    if p.percent is not None:
                        progress.update(task_id, completed=p.percent)

                try:
                    status, output_info = await self.downloader.download_video_async(
                        url,
                        quality=quality,
                        audio_only=audio_only,
                        task_id=str(task_id),
                        on_progress=on_progress,
                        cookies=cookies,
                        cookies_from_browser=cookies_from_browser,
                        subdirectory=subdirectory,
                        min_resolution=min_resolution,
                    )

                    if status == "success":
                        filename = os.path.basename(output_info) if output_info else url
                        progress.update(
                            task_id,
                            description=f"[green]✓ Completed: [white]{filename}[/white]",
                            completed=100,
                        )
                        results.append("success")
                    elif status == "skipped":
                        filename = (
                            os.path.basename(output_info) if output_info else short_url
                        )
                        progress.update(
                            task_id,
                            description=f"[yellow]− Skipped existing: [white]{filename}[/white]",
                            completed=100,
                        )
                        results.append("skipped")
                    else:
                        # Failed
                        progress.update(
                            task_id,
                            description=f"[red]! Error [{index + 1}/{len(urls)}]",
                            completed=100,
                        )
                        results.append("failed")
                        failed_urls.append(url)
                except Exception as e:
                    progress.update(
                        task_id,
                        description=f"[red]! Error [{index + 1}/{len(urls)}]",
                        completed=100,
                    )
                    results.append("failed")
                    failed_urls.append(url)
                finally:
                    queue.task_done()

        with progress:
            # Create worker tasks
            worker_tasks = [
                asyncio.create_task(worker())
                for _ in range(min(max_concurrent, len(urls)))
            ]
            # Wait for all tasks to complete
            await asyncio.gather(*worker_tasks)

        # Final Summary
        successful = sum(1 for r in results if r == "success")
        failed = sum(1 for r in results if r == "failed")
        skipped = sum(1 for r in results if r == "skipped")

        console.print(f"\n[bold cyan]Batch Download Summary:[/bold cyan]")
        console.print(f"[green]✓ Successful: {successful}[/green]")
        if failed > 0:
            console.print(f"[red]✗ Failed: {failed}[/red]")
        if skipped > 0:
            console.print(f"[yellow]− Skipped: {skipped}[/yellow]")

        retry_file = None
        if failed_urls:
            retry_file = self._write_retry_file(failed_urls, subdirectory)
            if retry_file:
                console.print(
                    f"[yellow]Retry list saved to: [white]{retry_file}[/white][/yellow]"
                )

        return {
            "successful": successful,
            "failed": failed,
            "skipped": skipped,
            "failed_urls": failed_urls,
            "retry_file": retry_file,
        }

    def _write_retry_file(
        self, failed_urls: List[str], subdirectory: Optional[str] = None
    ) -> Optional[str]:
        """Write one failed URL per line to a retry file in the batch output folder."""
        if not failed_urls:
            return None

        output_dir = self.downloader.output_dir
        if subdirectory:
            output_dir = os.path.join(output_dir, subdirectory)

        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        retry_path = os.path.join(output_dir, f"failed-or-incomplete-{timestamp}.txt")

        unique_failed_urls = list(dict.fromkeys(failed_urls))
        with open(retry_path, "w", encoding="utf-8") as f:
            for url in unique_failed_urls:
                f.write(url + "\n")

        return retry_path
