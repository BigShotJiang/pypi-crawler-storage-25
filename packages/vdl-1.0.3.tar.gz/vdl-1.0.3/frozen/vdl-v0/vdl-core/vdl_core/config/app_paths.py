from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class AppPaths:
    config_dir: Path
    config_file: Path
    state_dir: Path
    state_db: Path
    install_metadata: Path
    logs_dir: Path
    cache_dir: Path
    default_downloads_dir: Path


def get_app_paths() -> AppPaths:
    home = Path.home()
    config_dir = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config")) / "vdl"
    state_dir = (
        Path(os.environ.get("XDG_STATE_HOME", home / ".local" / "state")) / "vdl"
    )
    cache_dir = Path(os.environ.get("XDG_CACHE_HOME", home / ".cache")) / "vdl"

    return AppPaths(
        config_dir=config_dir,
        config_file=config_dir / "config.toml",
        state_dir=state_dir,
        state_db=state_dir / "vdl.db",
        install_metadata=state_dir / "install.json",
        logs_dir=state_dir / "logs",
        cache_dir=cache_dir,
        default_downloads_dir=home / "Downloads" / "VDL",
    )


def ensure_app_dirs(paths: AppPaths | None = None) -> AppPaths:
    paths = paths or get_app_paths()
    for directory in (
        paths.config_dir,
        paths.state_dir,
        paths.logs_dir,
        paths.cache_dir,
        paths.default_downloads_dir,
    ):
        directory.mkdir(parents=True, exist_ok=True)
    return paths
