from vdl_core.config.app_paths import get_app_paths

DEFAULT_OUTPUT_DIR = str(get_app_paths().default_downloads_dir)

DEFAULT_CONFIG = {
    "output_dir": DEFAULT_OUTPUT_DIR,
    "default_quality": "best",
    "audio_only": False,
    "embed_metadata": True,
    "embed_thumbnail": True,
    "embed_chapters": True,
    "reencode_for_quicktime": False,
    "max_concurrent_downloads": 3,
    "audio_format": "mp3",
    "audio_quality": "0",
    "merge_format": "mp4",
    "write_subtitles": False,
    "subtitle_langs": "en",
    "release_channel": "stable",
    "release_metadata_url": "https://bildcraft.gitlab.io/products/video-downloader/vdl/stable/release.json",
}
