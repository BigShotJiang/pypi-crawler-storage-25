"""
Configuration Manager for Video Downloader
Handles TOML configuration loading, saving, and management
"""

from pathlib import Path
from typing import Dict, Any, Optional
import tomllib
from rich.console import Console
from vdl_core.config.app_paths import ensure_app_dirs, get_app_paths
from vdl_core.config.defaults import DEFAULT_CONFIG

console = Console()
LEGACY_RELEASE_METADATA_URL = "https://example.com/vdl/stable/release.json"


class ConfigManager:
    """Manages configuration file"""

    def __init__(self, config_path: Optional[str] = None):
        if config_path:
            self.config_path = Path(config_path)
        else:
            self.config_path = get_app_paths().config_file

        self.runtime_overrides: Dict[str, Any] = {}
        self.config = self.load_config()

    def load_config(self) -> Dict[str, Any]:
        """Load configuration from file or create default"""
        if self.config_path.exists():
            try:
                with open(self.config_path, "rb") as f:
                    config = tomllib.load(f)
                    config = self._normalize_loaded_config(config or {})
                    # Merge with defaults for any missing keys
                    return {**DEFAULT_CONFIG, **config}
            except Exception as e:
                console.print(f"[yellow]Warning: Could not load config: {e}[/yellow]")
                console.print("[yellow]Using default configuration[/yellow]")
                return DEFAULT_CONFIG.copy()
        else:
            # Create default config
            self.save_config(DEFAULT_CONFIG)
            console.print(
                f"[green]Created default config at: {self.config_path}[/green]"
            )
            return DEFAULT_CONFIG.copy()

    def save_config(self, config: Dict[str, Any] | None = None):
        """Save configuration to file"""
        if config is None:
            config = self.config

        ensure_app_dirs()
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, "w", encoding="utf-8") as f:
            f.write(_serialize_toml(config))

    def get(self, key: str, default=None):
        """Get configuration value"""
        if key in self.runtime_overrides:
            return self.runtime_overrides[key]
        return self.config.get(key, default)

    def set(self, key: str, value: Any, persist: bool = True):
        """Set configuration value"""
        self.config[key] = value
        if persist:
            self.save_config(self.config)
        else:
            self.runtime_overrides[key] = value

    def set_runtime(self, key: str, value: Any):
        """Set a value for the current process without persisting it."""
        self.runtime_overrides[key] = value

    def clear_runtime(self, key: str):
        """Remove a runtime-only override."""
        self.runtime_overrides.pop(key, None)

    def _normalize_loaded_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        normalized = dict(config)
        release_metadata_url = normalized.get("release_metadata_url")
        if release_metadata_url in (None, "", LEGACY_RELEASE_METADATA_URL):
            normalized["release_metadata_url"] = DEFAULT_CONFIG["release_metadata_url"]
        return normalized


def _serialize_toml(config: Dict[str, Any]) -> str:
    lines = []
    for key, value in config.items():
        if isinstance(value, bool):
            rendered = "true" if value else "false"
        elif isinstance(value, int):
            rendered = str(value)
        elif isinstance(value, float):
            rendered = str(value)
        else:
            escaped = str(value).replace("\\", "\\\\").replace('"', '\\"')
            rendered = f'"{escaped}"'
        lines.append(f"{key} = {rendered}")
    return "\n".join(lines) + "\n"
