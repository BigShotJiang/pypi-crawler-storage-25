from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from vdl_core.config.defaults import DEFAULT_OUTPUT_DIR


@dataclass
class OutputPathResolution:
    requested_path: str | None
    active_path: str
    used_fallback: bool
    warning: str | None = None


def default_output_dir() -> str:
    """Return the default local output directory."""
    return _normalize_path(DEFAULT_OUTPUT_DIR)


def resolve_output_dir(requested_path: str | None) -> OutputPathResolution:
    """
    Resolve an output directory into a writable location.

    If the requested path is invalid or unwritable, fall back to the default
    local output directory so the CLI can still start.
    """
    if requested_path:
        candidate = _normalize_path(requested_path)
        if _is_writable_dir(candidate):
            return OutputPathResolution(
                requested_path=requested_path,
                active_path=candidate,
                used_fallback=False,
            )

        fallback = _prepare_fallback_dir()
        return OutputPathResolution(
            requested_path=requested_path,
            active_path=fallback,
            used_fallback=True,
            warning=(
                f"Output directory '{candidate}' is unavailable or not writable. "
                f"Using '{fallback}' for this run."
            ),
        )

    fallback = _prepare_fallback_dir()
    return OutputPathResolution(
        requested_path=None,
        active_path=fallback,
        used_fallback=False,
    )


def _normalize_path(path: str) -> str:
    expanded = os.path.expanduser(path.strip("\"'").strip())
    return str(Path(expanded).resolve(strict=False))


def _prepare_fallback_dir() -> str:
    fallback = default_output_dir()
    _ensure_writable_dir(fallback)
    return fallback


def _is_writable_dir(path: str) -> bool:
    try:
        _ensure_writable_dir(path)
        return True
    except OSError:
        return False


def _ensure_writable_dir(path: str):
    target = Path(path)
    target.mkdir(parents=True, exist_ok=True)

    probe = target / ".vdl-write-test"
    with open(probe, "w", encoding="utf-8") as handle:
        handle.write("ok")
    probe.unlink()
