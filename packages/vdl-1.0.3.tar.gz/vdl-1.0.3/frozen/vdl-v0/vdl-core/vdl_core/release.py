from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import tarfile
import tempfile
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from vdl_core.config.app_paths import ensure_app_dirs, get_app_paths


class ReleaseInstallError(RuntimeError):
    pass


@dataclass
class InstallMetadata:
    product: str
    version: str
    channel: str
    platform: str
    install_root: str
    active_binary: str
    installed_at: str
    artifact_url: str
    artifact_sha256: str
    install_type: str = "release"
    release_metadata_url: str | None = None


def detect_platform_key() -> str:
    machine = platform.machine().lower()
    system = platform.system().lower()
    aliases = {
        ("darwin", "arm64"): "aarch64-apple-darwin",
        ("darwin", "x86_64"): "x86_64-apple-darwin",
        ("linux", "x86_64"): "x86_64-unknown-linux-gnu",
    }
    key = aliases.get((system, machine))
    if not key:
        raise ReleaseInstallError(f"Unsupported platform: {system}/{machine}")
    return key


def load_install_metadata(path: Path | None = None) -> InstallMetadata | None:
    path = path or get_app_paths().install_metadata
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    return InstallMetadata(**payload)


def save_install_metadata(metadata: InstallMetadata, path: Path | None = None):
    path = path or get_app_paths().install_metadata
    ensure_app_dirs()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(metadata.__dict__, handle, indent=2)


def format_install_type(metadata: InstallMetadata | None) -> str:
    if metadata is None:
        return "development"
    return metadata.install_type


def fetch_release_metadata(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=5) as response:
        return json.loads(response.read().decode("utf-8"))


def perform_self_update(config_manager) -> dict[str, str]:
    paths = ensure_app_dirs(get_app_paths())
    metadata = load_install_metadata(paths.install_metadata)
    if metadata is None or metadata.install_type != "release":
        raise ReleaseInstallError(
            "This VDL installation was not installed from a release artifact, so self-update is disabled.\n"
            "Use the contributor workflow instead:\n  git pull\n  uv sync"
        )

    metadata_url = metadata.release_metadata_url or config_manager.get(
        "release_metadata_url"
    )
    release = fetch_release_metadata(metadata_url)
    platform_key = detect_platform_key()
    latest_version = release["version"]

    if latest_version == metadata.version:
        return {
            "status": "up_to_date",
            "message": f"VDL is already up to date ({latest_version}).",
        }

    artifact = release["artifacts"].get(platform_key)
    if artifact is None:
        raise ReleaseInstallError(
            f"No release artifact available for platform {platform_key}."
        )

    install_root = Path(metadata.install_root)
    target_dir = install_root / "bin" / f"vdl-{latest_version}"
    target_dir.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmpdir:
        archive_path = Path(tmpdir) / "vdl.tar.gz"
        urllib.request.urlretrieve(artifact["url"], archive_path)
        checksum = _sha256_file(archive_path)
        expected = artifact["sha256"]
        if checksum != expected:
            raise ReleaseInstallError(
                "Downloaded artifact checksum did not match release metadata."
            )

        with tarfile.open(archive_path, "r:gz") as tar:
            tar.extractall(target_dir)

    current_link = install_root / "bin" / "current"
    tmp_link = install_root / "bin" / ".current.tmp"
    if tmp_link.exists() or tmp_link.is_symlink():
        tmp_link.unlink()
    tmp_link.symlink_to(target_dir, target_is_directory=True)
    tmp_link.replace(current_link)

    new_metadata = InstallMetadata(
        product="vdl",
        version=latest_version,
        channel=release.get("channel", "stable"),
        platform=platform_key,
        install_root=str(install_root),
        active_binary=str(current_link / "vdl"),
        installed_at=release.get("published_at", metadata.installed_at),
        artifact_url=artifact["url"],
        artifact_sha256=artifact["sha256"],
        install_type="release",
        release_metadata_url=metadata_url,
    )
    save_install_metadata(new_metadata, paths.install_metadata)

    warning = None
    if shutil.which("ffmpeg") is None:
        warning = (
            "Warning: ffmpeg was not found. Downloads may fail or post-processing may be unavailable.\n"
            "Run: vdl doctor"
        )

    return {
        "status": "updated",
        "message": f"VDL updated successfully to {latest_version}.",
        "warning": warning,
    }


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(8192), b""):
            digest.update(chunk)
    return digest.hexdigest()
