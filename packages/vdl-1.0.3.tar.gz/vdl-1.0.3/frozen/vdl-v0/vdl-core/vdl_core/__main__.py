import os
from vdl_core.cli.commands import execute
from vdl_core.utils.logging import setup_logging

if __name__ == "__main__":
    # Environment-driven logging setup
    vdl_env = os.getenv("VDL_ENV", "production").lower()

    if vdl_env == "development":
        setup_logging(phase="dev", level="DEBUG")
    else:
        # Default to production with INFO level
        setup_logging(phase="prod", level="INFO")

    execute()
