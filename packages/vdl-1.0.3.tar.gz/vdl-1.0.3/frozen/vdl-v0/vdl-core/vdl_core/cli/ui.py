"""
UI Module for Video Downloader
Handles all user interface and display functions
"""

import os
import asyncio
import re
from typing import List, Optional, Dict, Any
from rich.console import Console
from rich.prompt import Prompt, Confirm
from rich.table import Table
from rich.panel import Panel
from rich import box
from vdl_core.utils.console import console

from vdl_core.config.paths import resolve_output_dir
from vdl_core.core.downloader import VideoDownloader
from vdl_core.core.playlist import PlaylistProcessor
from vdl_core.core.batch import BatchDownloader
from vdl_core.core.video_converter import VideoConverter
from vdl_core.utils.url_helpers import UrlAnalyzer


def prompt_output_folder(downloader: VideoDownloader) -> str:
    """Prompt user for output folder, defaulting to the last used directory."""
    current_output = downloader.config.get(
        "output_dir", str(os.path.join(os.path.expanduser("~"), "Downloads"))
    )

    folder = Prompt.ask(
        "[bold cyan]Output folder[/bold cyan]",
        default=current_output,
    )
    resolution = resolve_output_dir(folder)
    active_folder = resolution.active_path

    if resolution.warning:
        console.print(f"[yellow]Warning:[/yellow] {resolution.warning}")
        downloader.config.set_runtime("output_dir", active_folder)
    elif active_folder != current_output:
        downloader.config.set("output_dir", active_folder)
    else:
        downloader.config.set_runtime("output_dir", active_folder)

    downloader.output_dir = active_folder
    console.print(f"[green]✓ Output: {active_folder}[/green]")
    return active_folder


def show_banner():
    """Display welcome banner"""
    banner = """
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║        🎬 Interactive Video Downloader 🎬                ║
║                                                           ║
║        Powered by yt-dlp                                 ║
║        Rich CLI downloader and converter                 ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
    """
    console.print(banner, style="bold cyan")


def get_quality_choice():
    """Get quality selection from user"""
    console.print("\n[bold cyan]Select video quality:[/bold cyan]")
    console.print("  [1] Best Quality (Recommended)")
    console.print("  [2] 1080p")
    console.print("  [3] 720p")
    console.print("  [4] 480p")
    console.print("  [5] Audio Only (MP3)")

    choice = Prompt.ask(
        "[cyan]Choice[/cyan]", choices=["1", "2", "3", "4", "5"], default="1"
    )
    return choice


def get_download_options():
    """Get quality and audio selection from user"""
    quality_idx = get_quality_choice()
    audio_only = quality_idx == "5"

    quality_map = {"1": "best", "2": "1080p", "3": "720p", "4": "480p"}
    quality = quality_map.get(quality_idx, "best") if not audio_only else None

    # Ask for minimum resolution if quality is "best"
    min_resolution = None
    if quality == "best":
        console.print("\n[bold yellow]Minimum resolution filter:[/bold yellow]")
        console.print("  [1] No minimum (download best available)")
        console.print("  [2] 720p minimum")
        console.print("  [3] 1080p minimum")
        console.print("  [4] 1440p minimum")
        console.print("  [5] 2160p (4K) minimum")

        min_choice = Prompt.ask(
            "[cyan]Choice[/cyan]", choices=["1", "2", "3", "4", "5"], default="1"
        )

        min_map = {"1": None, "2": 720, "3": 1080, "4": 1440, "5": 2160}
        min_resolution = min_map.get(min_choice)

        if min_resolution:
            console.print(f"[green]✓ Will skip videos below {min_resolution}p[/green]")

    return quality, audio_only, min_resolution


def get_cookie_options(downloader: VideoDownloader):
    """Get cookie options from user"""
    cookie_file = None
    browser = None

    default_cookies = downloader.config.get("cookies")
    default_browser = downloader.config.get("cookies_from_browser")

    choice = Prompt.ask(
        "\n[cyan]Authentication via cookies?[/cyan]",
        choices=["none", "file", "browser"],
        default="none",
    )

    if choice == "file":
        cookie_file = Prompt.ask(
            "[cyan]Path to cookies.txt (Netscape format)[/cyan]",
            default=default_cookies if default_cookies else "",
        )
        if cookie_file:
            cookie_file = os.path.expanduser(cookie_file.strip("\"'").strip())
    elif choice == "browser":
        browser = Prompt.ask(
            "[cyan]Choose browser[/cyan]",
            choices=[
                "chrome",
                "firefox",
                "safari",
                "edge",
                "brave",
                "opera",
                "vivaldi",
            ],
            default=default_browser if default_browser else "chrome",
        )

    return cookie_file, browser


def display_pagination_table(pagination_links: List[Dict]) -> None:
    """
    Display pagination links in a formatted table.

    Args:
        pagination_links: List of pagination link dicts
    """
    table = Table(title="\n🔢 Available Pagination Links", box=box.ROUNDED)
    table.add_column("#", style="cyan", width=6)
    table.add_column("Page", style="green", width=10)
    table.add_column("URL", style="white")

    for idx, link in enumerate(pagination_links, start=1):
        # Try to extract page number using playlist logic for consistency
        page_num = PlaylistProcessor.extract_page_number(link)
        page_display = str(page_num) if page_num else link["text"] or "?"

        url_display = link["url"]
        if len(url_display) > 60:
            url_display = url_display[:57] + "..."

        table.add_row(str(idx), page_display, url_display)

    console.print(table)


def parse_page_selection(selection: str, max_index: int) -> List[int]:
    """
    Parse user's page selection input.

    Supports:
    - Single index: "3"
    - Range: "1-5"
    - Comma-separated: "1,3,5"
    - Mix: "1,3-5,7"

    Args:
        selection: User input string
        max_index: Maximum valid index

    Returns:
        List of selected indices (1-based)
    """
    selected = set()

    parts = selection.split(",")
    for part in parts:
        part = part.strip()

        if "-" in part:
            # Range
            try:
                start, end = part.split("-")
                start = int(start.strip())
                end = int(end.strip())

                if start < 1 or end > max_index:
                    console.print(
                        f"[yellow]Warning: Range {part} contains invalid indices, skipping[/yellow]"
                    )
                    continue

                selected.update(range(start, end + 1))
            except ValueError:
                console.print(
                    f"[yellow]Warning: Invalid range '{part}', skipping[/yellow]"
                )
        else:
            # Single index
            try:
                idx = int(part.strip())
                if 1 <= idx <= max_index:
                    selected.add(idx)
                else:
                    console.print(
                        f"[yellow]Warning: Index {idx} out of range, skipping[/yellow]"
                    )
            except ValueError:
                console.print(
                    f"[yellow]Warning: Invalid input '{part}', skipping[/yellow]"
                )

    return sorted(list(selected))


def prompt_page_selection(pagination_links: List[Dict]) -> List[Dict]:
    """
    Prompt user to select which pagination pages to crawl.

    Args:
        pagination_links: List of pagination link dicts

    Returns:
        List of selected pagination link dicts
    """
    if not pagination_links:
        console.print("[yellow]No numeric pagination links found[/yellow]")
        return []

    display_pagination_table(pagination_links)

    console.print("\n[bold yellow]Select pages to crawl:[/bold yellow]")
    console.print("  Examples: '1,3,5' or '1-3' or '2' or 'all'")

    max_index = len(pagination_links)

    selection = Prompt.ask("[cyan]Selection[/cyan]", default="all")

    if selection.lower() == "all":
        return pagination_links

    indices = parse_page_selection(selection, max_index)

    if not indices:
        console.print("[red]No valid pages selected[/red]")
        return []

    selected_links = [pagination_links[i - 1] for i in indices]
    console.print(f"[green]✓ Selected {len(selected_links)} page(s)[/green]")

    return selected_links


def prompt_continuation(available_pages: List[str]) -> Optional[str]:
    """
    Prompt user to select which page to continue from.

    Args:
        available_pages: List of page identifiers (e.g., ["Page 1", "Page 2"])

    Returns:
        Selected page identifier, or None to quit
    """
    if not available_pages:
        return None

    console.print("\n[bold cyan]Crawl complete! Continue from which page?[/bold cyan]")

    # Simple sort for consistent display
    # If keys are "Page 1", "Page 2", standard string sort works ok-ish but "Page 10" comes before "Page 2"
    # Let's try to naturally sort if they follow the "Page N" format
    def natural_sort_key(s):
        return [
            int(text) if text.isdigit() else text.lower()
            for text in re.split("([0-9]+)", s)
        ]

    try:
        sorted_pages = sorted(available_pages, key=natural_sort_key)
    except:
        sorted_pages = sorted(available_pages)

    table = Table(box=box.ROUNDED)
    table.add_column("#", style="cyan", width=6)
    table.add_column("Page", style="white")

    for idx, page in enumerate(sorted_pages, start=1):
        table.add_row(str(idx), page)

    console.print(table)
    console.print("  [0] Done (quit)")

    choices = [str(i) for i in range(len(sorted_pages) + 1)]
    choice = Prompt.ask("[cyan]Choice[/cyan]", choices=choices, default="0")

    if choice == "0":
        return None

    return sorted_pages[int(choice) - 1]


def interactive_mode(
    downloader: VideoDownloader,
    initial_choice: Optional[str] = None,
    force_playlist: bool = False,
):
    """Run in interactive mode with paginated crawling support"""

    current_choice = initial_choice

    while True:
        if not current_choice:
            console.print("\n" + "─" * 60 + "\n", style="dim")
            current_choice = Prompt.ask(
                "[bold cyan]Enter video URL, file path, or 'quit'[/bold cyan]",
                default="",
            )

        if not current_choice or current_choice.lower() in ["quit", "exit", "q"]:
            if current_choice and current_choice.lower() in ["quit", "exit", "q"]:
                console.print("\n[yellow]👋 Goodbye![/yellow]")
            break

        # Normalize input
        clean_choice = current_choice.strip("\"'").strip()
        expanded_path = os.path.realpath(os.path.expanduser(clean_choice))

        is_local_file = UrlAnalyzer.is_local_file(clean_choice)
        looks_like_text_playlist_file = UrlAnalyzer.looks_like_text_playlist_file(
            clean_choice
        )
        looks_like_local_path = UrlAnalyzer.looks_like_local_path(clean_choice)

        # Handle local files (conversion or batch)
        if is_local_file or looks_like_text_playlist_file or looks_like_local_path:
            # Text-based link list should always default to direct playlist batch mode.
            if looks_like_text_playlist_file or UrlAnalyzer.is_text_file(clean_choice):
                if not os.path.exists(expanded_path):
                    console.print(
                        f"[red]Playlist file not found: {expanded_path}[/red]"
                    )
                    current_choice = None
                    continue
                handle_batch_file(expanded_path, downloader)
                current_choice = None
                continue

            # Other local-path-like inputs are treated as video conversion paths.
            if not os.path.exists(expanded_path):
                console.print(f"[red]Local file not found: {expanded_path}[/red]")
                current_choice = None
                continue

            handle_video_conversion(expanded_path)
            current_choice = None
            continue

        # Download Mode - URL handling
        url = current_choice

        # Ask for output folder before any crawling/downloading starts
        prompt_output_folder(downloader)

        is_explicit_playlist, is_mix, is_ambiguous = UrlAnalyzer.analyze_url(url)

        if force_playlist:
            download_mode = "playlist"
        else:
            console.print(
                "\n[bold yellow]How do you want to handle this URL?[/bold yellow]"
            )
            console.print("  [1] Download as single video")
            console.print("  [2] Continue in playlist mode")
            mode_choice = Prompt.ask(
                "[cyan]Choice[/cyan]",
                choices=["1", "2"],
                default="2" if is_explicit_playlist else "1",
            )
            download_mode = "playlist" if mode_choice == "2" else "single"

        is_youtube = "youtube.com" in url.lower() or "youtu.be" in url.lower()

        if is_youtube:
            cookie_file, browser = get_cookie_options(downloader)
            if download_mode == "playlist":
                native_result = PlaylistProcessor.expand_url_native(
                    url, cookies=cookie_file
                )

                if native_result and native_result.get("is_playlist"):
                    # YouTube playlists should use yt-dlp native extraction, not crawler mode.
                    handle_native_playlist(
                        native_result, downloader, cookie_file, browser
                    )
                    current_choice = None
                    continue

                console.print(
                    "[yellow]Could not detect a native YouTube playlist. Falling back to single video download.[/yellow]"
                )

            handle_single_video_download(url, downloader, cookie_file, browser)
            current_choice = None
            continue

        if download_mode == "playlist":
            # Non-YouTube playlist mode continues to use crawler-based discovery.
            handle_paginated_crawl(url, downloader)
        else:
            handle_single_video_download(url, downloader)
        current_choice = None


def handle_batch_file(file_path: str, downloader: VideoDownloader):
    """Handle direct playlist-style batch file processing with no crawling."""
    console.print(
        f"[green]✓ Link list file detected: {os.path.basename(file_path)}[/green]"
    )

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            links = [
                line.strip()
                for line in f
                if line.strip() and not line.strip().startswith("#")
            ]

        if not links:
            console.print("[red]File is empty or contains no valid links.[/red]")
            return

        console.print(f"[cyan]Found {len(links)} links in file.[/cyan]")
        console.print(
            "[cyan]Direct playlist concurrent mode: links will be downloaded as-is with no crawling.[/cyan]"
        )

        # Ask for output folder before anything else
        prompt_output_folder(downloader)

        # Prompt for playlist subfolder name
        default_name = os.path.splitext(os.path.basename(file_path))[0][:20]
        playlist_name = Prompt.ask(
            "[bold cyan]Playlist folder name[/bold cyan]", default=default_name
        )
        playlist_name = playlist_name[:20].strip()

        # Configure download options
        quality, audio_only, min_resolution = get_download_options()
        cookie_file, browser_cookies = get_cookie_options(downloader)

        console.print(
            f"\n[cyan]Starting batch download into '{playlist_name}'...[/cyan]"
        )

        # Execute batch download
        import logging

        root_logger = logging.getLogger()
        original_level = root_logger.getEffectiveLevel()
        if original_level > logging.DEBUG:
            root_logger.setLevel(logging.WARNING)

        try:
            batch = BatchDownloader(downloader)
            asyncio.run(
                batch.download_batch(
                    links,
                    quality=quality,
                    audio_only=audio_only,
                    cookies=cookie_file,
                    cookies_from_browser=browser_cookies,
                    subdirectory=playlist_name,
                    min_resolution=min_resolution,
                )
            )
            console.print(f"\n[bold green]✓ Batch download complete![/bold green]")
        except Exception as e:
            console.print(f"\n[red]Error during batch download: {e}[/red]")
        finally:
            root_logger.setLevel(original_level)

    except Exception as e:
        console.print(f"[red]Error reading file: {e}[/red]")


def handle_video_conversion(file_path: str):
    """Handle video file conversion"""
    from vdl_core.core.video_converter import VideoConverter

    console.print(
        f"[green]✓ Local video detected: {os.path.basename(file_path)}[/green]"
    )

    base, ext = os.path.splitext(file_path)
    output_file = f"{base}-mobile.mp4"

    # Get conversion quality
    console.print(
        "\n[bold cyan]Select conversion quality (WhatsApp Optimized):[/bold cyan]"
    )
    console.print("  [1] Best (Original Resolution & FPS, High Fidelity)")
    console.print("  [2] Medium (Original Resolution, Capped 30 FPS, Balanced)")
    console.print("  [3] Low (Original Resolution, Capped 24 FPS, High Compression)")

    choice = Prompt.ask("[cyan]Choice[/cyan]", choices=["1", "2", "3"], default="1")
    quality_map = {"1": "best", "2": "medium", "3": "low"}
    quality = quality_map.get(choice, "best")

    if not Confirm.ask(
        "\n[bold green]Start conversion to mobile format?[/bold green]", default=True
    ):
        return

    console.print(f"\n[cyan]Converting {os.path.basename(file_path)}...[/cyan]")

    from rich.progress import (
        Progress,
        SpinnerColumn,
        TextColumn,
        BarColumn,
        TaskProgressColumn,
    )

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("[cyan]Converting...", total=100)

        def update_progress(p):
            progress.update(task, completed=p)

        success = asyncio.run(
            VideoConverter.convert_video_async(
                file_path,
                output_file,
                quality=quality,
                on_progress=update_progress,
            )
        )

    if success:
        console.print(f"\n[bold green]✓ Conversion complete![/bold green]")
        console.print(f"[white]Output saved to: {output_file}[/white]")
    else:
        console.print(f"\n[bold red]✗ Conversion failed![/bold red]")


def handle_native_playlist(
    playlist_data: Dict, downloader: VideoDownloader, cookie_file: str, browser: str
):
    """Handle native YouTube playlist"""
    links = playlist_data["links"]
    title = playlist_data.get("title", "Playlist")

    console.print(f"\n[bold green]Found YouTube playlist: {title}[/bold green]")
    console.print(f"[cyan]{len(links)} videos[/cyan]")

    if not Confirm.ask(f"Download all {len(links)} videos?", default=True):
        return

    # Ask for playlist subfolder name (default = playlist title)
    default_folder = re.sub(r"[^\w\s-]", "", title).strip().replace(" ", "_")[:40]
    playlist_folder = Prompt.ask(
        "[bold cyan]Playlist folder name[/bold cyan]",
        default=default_folder,
    )
    playlist_folder = playlist_folder.strip()

    quality, audio_only, min_resolution = get_download_options()

    import logging

    root_logger = logging.getLogger()
    original_level = root_logger.getEffectiveLevel()
    if original_level > logging.DEBUG:
        root_logger.setLevel(logging.WARNING)

    try:
        batch = BatchDownloader(downloader)
        asyncio.run(
            batch.download_batch(
                links,
                quality=quality,
                audio_only=audio_only,
                cookies=cookie_file,
                cookies_from_browser=browser,
                subdirectory=playlist_folder,
                min_resolution=min_resolution,
            )
        )
        console.print("[bold green]✓ Download complete![/bold green]")
    finally:
        root_logger.setLevel(original_level)


def handle_single_video_download(
    url: str,
    downloader: VideoDownloader,
    cookie_file: Optional[str] = None,
    browser: Optional[str] = None,
):
    """Handle downloading a single video URL directly."""
    console.print(f"\n[green]✓ Single video mode[/green]")

    quality, audio_only, min_resolution = get_download_options()

    if not Confirm.ask(
        "[bold green]Start single video download?[/bold green]", default=True
    ):
        return

    download_links(
        [url],
        downloader,
        quality,
        audio_only,
        min_resolution,
        cookie_file,
        browser,
    )


def handle_paginated_crawl(url: str, downloader: VideoDownloader):
    """
    Handle paginated site crawling with user-guided page selection.
    This logic prioritizes JS crawling and strictly numbered pagination.
    """
    current_url = url

    # Get download preferences
    quality, audio_only, min_resolution = get_download_options()
    cookie_file, browser = get_cookie_options(downloader)

    while True:
        console.print(f"\n[cyan]Analyzing {current_url}...[/cyan]")

        # Discover links on initial page using NEW crawler logic
        discovery_result = PlaylistProcessor.discover_links(
            current_url, cookies=cookie_file
        )

        all_links = discovery_result.get("all_links", [])
        pagination_links = discovery_result.get("pagination_links", [])

        console.print(f"[green]✓ Found {len(all_links)} total links on page[/green]")

        # Filter strictly to numeric pagination
        numeric_pagination = PlaylistProcessor.filter_numeric_pagination(
            pagination_links
        )
        console.print(
            f"[green]✓ Found {len(numeric_pagination)} numeric pagination links[/green]"
        )

        if not numeric_pagination:
            console.print(
                "[yellow]No strictly numeric pagination detected, treating as single page[/yellow]"
            )

            # Download current page only
            if Confirm.ask(
                f"Download {len(all_links)} links from this page?", default=True
            ):
                subfolder = Prompt.ask(
                    "[bold cyan]Folder name for this set (leave blank for none)[/bold cyan]",
                    default="",
                )
                subfolder = subfolder.strip() or None
                download_links(
                    [link["url"] for link in all_links],
                    downloader,
                    quality,
                    audio_only,
                    min_resolution,
                    cookie_file,
                    browser,
                    subdirectory=subfolder,
                )
            break

        # User selects pages
        selected_pagination = prompt_page_selection(numeric_pagination)

        if not selected_pagination:
            console.print("[yellow]No pages selected, exiting[/yellow]")
            break

        # Ask if base page should be included
        include_base_page = Confirm.ask(
            "Include current page (Page 1) in crawl?", default=True
        )

        # Crawl selected pages
        console.print(
            f"\n[cyan]Crawling {len(selected_pagination) + (1 if include_base_page else 0)} page(s)...[/cyan]"
        )

        # crawl_results maps "Page N" -> {'links': [...], 'url': '...'}
        crawl_results = PlaylistProcessor.crawl_pages(
            base_url=current_url,
            selected_pagination=selected_pagination,
            cookies=cookie_file,
            include_base=include_base_page,
        )

        # Display results
        total_links = sum(
            len(page_data.get("links", [])) for page_data in crawl_results.values()
        )
        console.print(
            f"\n[bold green]✓ Crawl complete: {total_links} total links found[/bold green]"
        )

        for page_name, page_data in crawl_results.items():
            links = page_data.get("links", [])
            console.print(f"  • {page_name}: {len(links)} links")

        # Flatten all links
        all_crawled_links = []
        for page_data in crawl_results.values():
            all_crawled_links.extend(page_data.get("links", []))

        # Remove duplicates
        seen = set()
        unique_links = [x for x in all_crawled_links if not (x in seen or seen.add(x))]

        console.print(
            f"[cyan]{len(unique_links)} unique links after deduplication[/cyan]"
        )

        # Ask for folder name for this crawled set
        crawl_subfolder = Prompt.ask(
            "[bold cyan]Folder name for this crawled set (leave blank for none)[/bold cyan]",
            default="",
        )
        crawl_subfolder = crawl_subfolder.strip() or None

        # Download
        if Confirm.ask(f"Download {len(unique_links)} videos?", default=True):
            download_links(
                unique_links,
                downloader,
                quality,
                audio_only,
                min_resolution,
                cookie_file,
                browser,
                subdirectory=crawl_subfolder,
            )

        # Prompt for continuation
        available_pages = list(crawl_results.keys())
        next_page = prompt_continuation(available_pages)

        if next_page:
            # Look up the URL for the selected page
            page_data = crawl_results.get(next_page)
            if page_data and page_data.get("url"):
                next_url = page_data["url"]
                console.print(
                    f"[cyan]Continuing from {next_page} ({next_url})...[/cyan]"
                )
                current_url = next_url
                continue
            else:
                console.print(
                    "[red]Error: Could not determine URL for selected page. Exiting.[/red]"
                )
                break
        else:
            break


def download_links(
    links: List[str],
    downloader: VideoDownloader,
    quality: str,
    audio_only: bool,
    min_resolution: Optional[int],
    cookie_file: str,
    browser: str,
    subdirectory: Optional[str] = None,
):
    """Execute batch download with proper logging suppression"""
    import logging

    root_logger = logging.getLogger()
    original_level = root_logger.getEffectiveLevel()
    if original_level > logging.DEBUG:
        root_logger.setLevel(logging.WARNING)

    try:
        batch = BatchDownloader(downloader)
        asyncio.run(
            batch.download_batch(
                links,
                quality=quality,
                audio_only=audio_only,
                cookies=cookie_file,
                cookies_from_browser=browser,
                min_resolution=min_resolution,
                subdirectory=subdirectory,
            )
        )
        console.print("\n[bold green]✓ Download complete![/bold green]")
    except Exception as e:
        console.print(f"\n[red]Error during download: {e}[/red]")
    finally:
        root_logger.setLevel(original_level)
