#!/usr/bin/env python3
"""
Video Downloader - Command Line Interface
Main entry point for the standalone downloader/converter CLI
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from vdl_core.cli.ui import interactive_mode, show_banner
from vdl_core.config.app_paths import ensure_app_dirs, get_app_paths
from vdl_core.config.manager import ConfigManager
from vdl_core.config.paths import resolve_output_dir
from vdl_core.core.downloader import VideoDownloader
from vdl_core.core.models import DownloadProgress
from vdl_core.core.playlist import PlaylistProcessor
from vdl_core.core.video_converter import VideoConverter
from vdl_core.release import (
    InstallMetadata,
    ReleaseInstallError,
    fetch_release_metadata,
    format_install_type,
    load_install_metadata,
    perform_self_update,
)
from vdl_core.state import StateStore
from vdl_core.utils.console import console
from vdl_core.utils.logging import get_logger
from vdl_core.utils.url_helpers import UrlAnalyzer

logger = get_logger(__name__)
SUBCOMMANDS = {"download", "crawl", "status", "doctor", "config", "update"}


def _emit_output_dir_warning(message: str, json_mode: bool):
    if json_mode:
        sys.stderr.write(message + "\n")
        sys.stderr.flush()
        return
    console.print(f"[yellow]Warning:[/yellow] {message}")


def _enable_debug_logging():
    from vdl_core.utils.logging import setup_logging

    setup_logging(phase="dev", level="DEBUG")
    logger.debug("Debug logging enabled via CLI flag.")


def _create_runtime(
    config_path: str | None,
    output_dir: str | None,
    json_mode: bool = False,
    debug: bool = False,
):
    if debug:
        _enable_debug_logging()

    ensure_app_dirs()
    config_manager = ConfigManager(config_path)
    requested_output = output_dir if output_dir else config_manager.get("output_dir")
    output_resolution = resolve_output_dir(requested_output)
    if output_resolution.warning:
        _emit_output_dir_warning(output_resolution.warning, json_mode)
    config_manager.set_runtime("output_dir", output_resolution.active_path)

    downloader = VideoDownloader(config_manager)
    state_store = StateStore()
    return config_manager, downloader, state_store, output_resolution


def _record_progress(
    state_store: StateStore,
    command_name: str,
    source_url: str,
    progress: DownloadProgress,
):
    state_store.update_progress(progress, source_url=source_url, command=command_name)


async def _run_download_urls_async(
    downloader: VideoDownloader,
    state_store: StateStore,
    urls: list[str],
    options: dict[str, Any],
    command_name: str,
    json_mode: bool = False,
):
    def progress_callback(source_url: str):
        def _callback(progress: DownloadProgress):
            _record_progress(state_store, command_name, source_url, progress)
            if json_mode:
                print(
                    json.dumps(
                        {
                            "timestamp": datetime.utcnow().isoformat(),
                            "id": progress.id,
                            "status": progress.status.value,
                            "percent": progress.percent,
                            "speed": progress.speed,
                            "output": progress.output_path,
                            "error": progress.error,
                            "url": source_url,
                        }
                    ),
                    flush=True,
                )

        return _callback

    if not urls:
        return []

    max_concurrent = int(downloader.config.get("max_concurrent_downloads", 3))
    queue = asyncio.Queue()
    for i, url in enumerate(urls):
        queue.put_nowait((url, i))

    results = []
    failed_urls: list[str] = []

    async def worker():
        while not queue.empty():
            try:
                url, i = await queue.get()
            except asyncio.QueueEmpty:
                break

            task_id = f"{command_name}_{i}_{int(datetime.utcnow().timestamp())}"
            state_store.record_initial(task_id, url, command_name)
            status, output_info = await downloader.download_video_async(
                url=url,
                quality=options.get("quality"),
                audio_only=options.get("audio_only"),
                playlist=options.get("playlist", False),
                task_id=task_id,
                on_progress=progress_callback(url),
                cookies=options.get("cookies"),
                cookies_from_browser=options.get("cookies_from_browser"),
                subdirectory=options.get("subdirectory"),
                min_resolution=options.get("min_resolution"),
            )
            results.append(
                {
                    "id": task_id,
                    "url": url,
                    "status": status,
                    "output": output_info,
                }
            )
            if status == "failed":
                failed_urls.append(url)
            queue.task_done()

    workers = [
        asyncio.create_task(worker()) for _ in range(min(max_concurrent, len(urls)))
    ]
    await asyncio.gather(*workers)

    if failed_urls and json_mode:
        print(
            json.dumps(
                {
                    "timestamp": datetime.utcnow().isoformat(),
                    "type": "retry_urls",
                    "failed_count": len(failed_urls),
                    "urls": list(dict.fromkeys(failed_urls)),
                }
            ),
            flush=True,
        )

    return results


async def _run_conversion_async(path: str, quality: str, json_mode: bool):
    base, _ext = os.path.splitext(path)
    output_path = f"{base}-mobile.mp4"

    def on_progress(percent: float):
        if json_mode:
            sys.stderr.write(
                json.dumps(
                    {
                        "type": "conversion_progress",
                        "progress": percent,
                        "file": os.path.basename(path),
                    }
                )
                + "\n"
            )
            sys.stderr.flush()

    if json_mode:
        sys.stderr.write(
            json.dumps(
                {
                    "type": "conversion_start",
                    "input": path,
                    "output": output_path,
                    "quality": quality,
                }
            )
            + "\n"
        )
        sys.stderr.flush()

    success = await VideoConverter.convert_video_async(
        path, output_path, quality=quality, on_progress=on_progress
    )

    if json_mode:
        payload = (
            {"type": "conversion_complete", "output": output_path}
            if success
            else {"type": "conversion_error", "message": "FFmpeg conversion failed"}
        )
        sys.stderr.write(json.dumps(payload) + "\n")
        sys.stderr.flush()
    return success, output_path


async def _run_download_command_async(
    args, downloader: VideoDownloader, state_store: StateStore
):
    clean_target = args.target.strip("\"'").strip()
    expanded_path = os.path.realpath(os.path.expanduser(clean_target))

    is_local_file = UrlAnalyzer.is_local_file(clean_target)
    looks_like_text_playlist_file = UrlAnalyzer.looks_like_text_playlist_file(
        clean_target
    )
    looks_like_local_path = UrlAnalyzer.looks_like_local_path(clean_target)

    if is_local_file or looks_like_text_playlist_file or looks_like_local_path:
        if looks_like_text_playlist_file or UrlAnalyzer.is_text_file(clean_target):
            if not os.path.exists(expanded_path):
                raise FileNotFoundError(f"Playlist file not found: {expanded_path}")
            with open(expanded_path, "r", encoding="utf-8") as handle:
                links = [
                    line.strip()
                    for line in handle
                    if line.strip() and not line.strip().startswith("#")
                ]
            if not links:
                raise ValueError("File is empty or contains no valid links.")
            return await _run_download_urls_async(
                downloader,
                state_store,
                links,
                {
                    "quality": args.quality if args.quality != "audio" else None,
                    "audio_only": args.audio_only or args.quality == "audio",
                    "cookies": args.cookies,
                    "cookies_from_browser": args.cookies_from_browser,
                    "subdirectory": Path(expanded_path).stem[:20] or "local_playlist",
                    "playlist": True,
                },
                command_name="download",
                json_mode=args.json,
            )

        if not os.path.exists(expanded_path):
            raise FileNotFoundError(f"Local file not found: {expanded_path}")
        success, output_path = await _run_conversion_async(
            expanded_path, args.quality or "best", args.json
        )
        return [
            {
                "type": "conversion",
                "status": "success" if success else "failed",
                "output": output_path,
            }
        ]

    is_explicit_playlist, _is_mix, is_ambiguous = UrlAnalyzer.analyze_url(clean_target)
    is_playlist = args.playlist or is_explicit_playlist

    if not args.no_interactive and is_ambiguous and not is_playlist:
        sys.stderr.write(
            "[?] This video is part of a playlist/mix. Download entire playlist? (y/N): "
        )
        sys.stderr.flush()
        choice = sys.stdin.readline().strip().lower()
        is_playlist = choice in ("y", "yes")

    options = {
        "quality": args.quality if args.quality != "audio" else None,
        "audio_only": args.audio_only or args.quality == "audio",
        "cookies": args.cookies,
        "cookies_from_browser": args.cookies_from_browser,
        "subdirectory": None,
        "playlist": is_playlist,
        "min_resolution": None,
    }

    if not is_playlist:
        existing = state_store.find_by_url(clean_target)
        if existing and existing.get("status") == "completed" and not args.force:
            result = {
                "id": existing["id"],
                "url": clean_target,
                "status": "skipped",
                "output": existing.get("output_path"),
                "reason": "existing_record",
            }
            if args.json:
                print(json.dumps(result), flush=True)
            else:
                console.print(
                    f"[yellow]Existing completed download found:[/yellow] {existing.get('output_path') or clean_target}"
                )
            return [result]

        return await _run_download_urls_async(
            downloader,
            state_store,
            [clean_target],
            options,
            command_name="download",
            json_mode=args.json,
        )

    playlist_data = PlaylistProcessor.expand_url(
        clean_target,
        use_crawler=not (
            "youtube.com" in clean_target.lower() or "youtu.be" in clean_target.lower()
        ),
        cookies=args.cookies,
    )
    urls = playlist_data.get("links", [])
    if not urls:
        raise ValueError("No downloadable URLs found for playlist input.")
    options["subdirectory"] = playlist_data.get("title")
    return await _run_download_urls_async(
        downloader,
        state_store,
        urls,
        options,
        command_name="download",
        json_mode=args.json,
    )


def _print_status(rows: list[dict[str, Any]], json_mode: bool):
    if json_mode:
        print(json.dumps(rows, indent=2), flush=True)
        return

    if not rows:
        console.print("[yellow]No download state recorded yet.[/yellow]")
        return

    for row in rows:
        console.print(
            f"[cyan]{row['id']}[/cyan]  {row['status']}  {row.get('source_url', '')}"
        )
        if row.get("output_path"):
            console.print(f"  [green]{row['output_path']}[/green]")
        if row.get("error"):
            console.print(f"  [red]{row['error']}[/red]")


def _check_writable(path: Path) -> bool:
    path.mkdir(parents=True, exist_ok=True)
    probe = path / ".probe"
    try:
        with open(probe, "w", encoding="utf-8") as handle:
            handle.write("ok")
        return True
    finally:
        if probe.exists():
            probe.unlink()


def _doctor_payload(downloader: VideoDownloader) -> dict[str, Any]:
    paths = ensure_app_dirs(get_app_paths())
    install_metadata = load_install_metadata(paths.install_metadata)
    config_valid = downloader.config.config_path.exists()
    update_status = "unknown"
    metadata_url = downloader.config.get("release_metadata_url")
    try:
        fetch_release_metadata(metadata_url)
        update_status = "reachable"
    except Exception:
        update_status = "unreachable"

    payload = {
        "version": os.environ.get("VDL_VERSION", "0.1.0"),
        "install_type": format_install_type(install_metadata),
        "platform": sys.platform,
        "checks": {
            "config_exists": config_valid,
            "config_writable": _check_writable(paths.config_dir),
            "state_writable": _check_writable(paths.state_dir),
            "cache_writable": _check_writable(paths.cache_dir),
            "downloads_writable": _check_writable(Path(downloader.output_dir)),
            "ffmpeg_available": downloader.check_ffmpeg(),
            "yt_dlp_available": downloader.check_ytdlp()[0],
            "update_metadata": update_status,
        },
        "paths": {
            "config": str(paths.config_file),
            "state_db": str(paths.state_db),
            "install_metadata": str(paths.install_metadata),
            "cache": str(paths.cache_dir),
            "downloads": downloader.output_dir,
        },
    }
    return payload


def _print_doctor(payload: dict[str, Any], json_mode: bool):
    if json_mode:
        print(json.dumps(payload, indent=2), flush=True)
        return

    console.print("[bold cyan]VDL Doctor[/bold cyan]")
    console.print(f"Version: {payload['version']}")
    console.print(f"Install type: {payload['install_type']}")
    console.print(f"Platform: {payload['platform']}")
    console.print("Checks:")
    for key, value in payload["checks"].items():
        marker = "[green]✓[/green]" if value in (True, "reachable") else "[red]✗[/red]"
        console.print(f"  {marker} {key}: {value}")


def _build_subcommand_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vdl",
        description="VDL is a lightweight CLI downloader with crawl, status, doctor, and update support.",
    )
    parser.add_argument("-c", "--config", metavar="FILE", help="Path to config file")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    parser.add_argument("--version", action="store_true", help="Show version and exit")
    parser.add_argument(
        "--update",
        action="store_true",
        help="Update the current release install to the latest available version",
    )

    subparsers = parser.add_subparsers(dest="command")

    download = subparsers.add_parser("download", help="Download a URL or link list")
    download.add_argument(
        "target", help="Media URL, playlist URL, or local link-list file"
    )
    download.add_argument(
        "-o", "--output", metavar="DIR", help="Output directory for this run only"
    )
    download.add_argument(
        "-q",
        "--quality",
        choices=["best", "medium", "low", "1080p", "720p", "480p", "audio"],
        default="best",
    )
    download.add_argument("-a", "--audio-only", action="store_true")
    download.add_argument("-p", "--playlist", action="store_true")
    download.add_argument("--cookies", metavar="FILE")
    download.add_argument("--cookies-from-browser", metavar="BROWSER")
    download.add_argument("--json", action="store_true")
    download.add_argument("--no-interactive", action="store_true")
    download.add_argument("--force", action="store_true")

    crawl = subparsers.add_parser(
        "crawl", help="Discover candidate media URLs from a page"
    )
    crawl.add_argument("target", help="Page URL to crawl")
    crawl.add_argument(
        "-o", "--output", metavar="DIR", help="Output directory for this run only"
    )
    crawl.add_argument("--cookies", metavar="FILE")
    crawl.add_argument("--json", action="store_true")
    crawl.add_argument("--download", action="store_true")
    crawl.add_argument("--dry-run", action="store_true")
    crawl.add_argument("--max-depth", type=int, default=1)
    crawl.add_argument("--max-pages", type=int, default=20)
    crawl.add_argument("--same-domain", action="store_true")

    status = subparsers.add_parser("status", help="Show recent download state")
    status.add_argument("id", nargs="?")
    status.add_argument("--json", action="store_true")

    doctor = subparsers.add_parser(
        "doctor", help="Check runtime health and dependencies"
    )
    doctor.add_argument("--json", action="store_true")

    config = subparsers.add_parser("config", help="Inspect or update persisted config")
    config_subparsers = config.add_subparsers(dest="config_command")
    config_show = config_subparsers.add_parser("show", help="Show current config")
    config_show.add_argument("--json", action="store_true")
    config_get = config_subparsers.add_parser("get", help="Get a config value")
    config_get.add_argument("key")
    config_set = config_subparsers.add_parser("set", help="Set a config value")
    config_set.add_argument("key")
    config_set.add_argument("value")

    subparsers.add_parser("update", help="Update this VDL release install")

    return parser


def _build_legacy_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vdl",
        description="Legacy VDL CLI compatibility mode",
    )
    parser.add_argument("url", nargs="?")
    parser.add_argument("-c", "--config", metavar="FILE")
    parser.add_argument("-o", "--output", metavar="DIR")
    parser.add_argument(
        "-q",
        "--quality",
        choices=["best", "medium", "low", "1080p", "720p", "480p", "audio"],
        default="best",
    )
    parser.add_argument("-a", "--audio-only", action="store_true")
    parser.add_argument("-p", "--playlist", action="store_true")
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--cookies", metavar="FILE")
    parser.add_argument("--cookies-from-browser", metavar="BROWSER")
    parser.add_argument("--debug", action="store_true")
    return parser


def _handle_config_command(args):
    config_manager = ConfigManager(args.config)
    if not args.config_command or args.config_command == "show":
        payload = config_manager.config
        if getattr(args, "json", False):
            print(json.dumps(payload, indent=2), flush=True)
        else:
            for key, value in payload.items():
                console.print(f"{key} = {value}")
        return
    if args.config_command == "get":
        value = config_manager.get(args.key)
        print(value)
        return
    if args.config_command == "set":
        config_manager.set(args.key, args.value)
        console.print(f"[green]Updated {args.key}[/green]")


def _handle_status_command(args):
    state_store = StateStore()
    if args.id:
        row = state_store.get(args.id)
        _print_status([row] if row else [], args.json)
        return
    _print_status(state_store.list_recent(), args.json)


def _handle_doctor_command(args):
    _config, downloader, _state, _resolution = _create_runtime(
        args.config, None, json_mode=args.json, debug=args.debug
    )
    payload = _doctor_payload(downloader)
    _print_doctor(payload, args.json)


def _handle_update_command(args):
    _config, downloader, _state, _resolution = _create_runtime(
        args.config, None, json_mode=False, debug=args.debug
    )
    try:
        result = perform_self_update(downloader.config)
    except ReleaseInstallError as exc:
        console.print(f"[red]{exc}[/red]")
        return 1

    if result["status"] == "up_to_date":
        console.print(f"[green]{result['message']}[/green]")
        return 0

    console.print(f"[green]{result['message']}[/green]")
    if result.get("warning"):
        console.print(f"[yellow]{result['warning']}[/yellow]")
    return 0


def _handle_crawl_command(args):
    _config, downloader, state_store, _resolution = _create_runtime(
        args.config, args.output, json_mode=args.json, debug=args.debug
    )
    discovery_result = PlaylistProcessor.discover_links(
        args.target, cookies=args.cookies
    )
    all_links = discovery_result.get("all_links", [])
    pagination_links = discovery_result.get("pagination_links", [])

    unique_links = []
    seen = set()
    source_host = urlparse(args.target).netloc
    for link in all_links[: args.max_pages]:
        url = link["url"]
        if (
            args.same_domain
            and source_host
            and urlparse(url).netloc not in {"", source_host}
        ):
            continue
        if url not in seen:
            seen.add(url)
            unique_links.append(url)

    payload = {
        "source": args.target,
        "count": len(unique_links),
        "links": unique_links,
        "pagination_links": pagination_links[: args.max_pages],
        "max_depth": args.max_depth,
    }

    if args.json:
        print(json.dumps(payload, indent=2), flush=True)
    else:
        console.print(f"[cyan]Discovered {len(unique_links)} candidate links[/cyan]")
        for url in unique_links[:20]:
            console.print(f" - {url}")

    if args.download and not args.dry_run and unique_links:
        return asyncio.run(
            _run_download_urls_async(
                downloader,
                state_store,
                unique_links,
                {
                    "quality": "best",
                    "audio_only": False,
                    "cookies": args.cookies,
                    "cookies_from_browser": None,
                    "subdirectory": "crawl-results",
                    "playlist": True,
                },
                command_name="crawl",
                json_mode=args.json,
            )
        )
    return payload


def _handle_download_command(args):
    _config, downloader, state_store, output_resolution = _create_runtime(
        args.config, args.output, json_mode=args.json, debug=args.debug
    )
    if output_resolution.used_fallback and not args.json:
        console.print(
            f"[cyan]Active output directory:[/cyan] {output_resolution.active_path}"
        )

    results = asyncio.run(_run_download_command_async(args, downloader, state_store))
    if not args.json:
        for item in results:
            if item.get("type") == "conversion":
                marker = (
                    "[green]✓[/green]"
                    if item["status"] == "success"
                    else "[red]✗[/red]"
                )
                console.print(f"{marker} Conversion output: {item['output']}")
                continue
            marker = (
                "[green]✓[/green]"
                if item["status"] in {"success", "skipped"}
                else "[red]✗[/red]"
            )
            console.print(f"{marker} {item['status']} {item['url']}")
            if item.get("output"):
                console.print(f"  [white]{item['output']}[/white]")
    return results


def _handle_interactive_mode(config_path: str | None, debug: bool):
    _config, downloader, _state, output_resolution = _create_runtime(
        config_path, None, json_mode=False, debug=debug
    )
    if output_resolution.used_fallback:
        console.print(
            f"[cyan]Active output directory:[/cyan] {output_resolution.active_path}"
        )
    show_banner()
    interactive_mode(downloader)


def _handle_legacy_mode(argv: list[str]) -> int:
    parser = _build_legacy_parser()
    args = parser.parse_args(argv)
    console.print(
        "[yellow]Legacy positional CLI detected. Please migrate to `vdl download <url>` or `vdl crawl <url>`.[/yellow]"
    )
    if args.headless and args.url:
        namespace = argparse.Namespace(
            target=args.url,
            config=args.config,
            output=args.output,
            quality=args.quality,
            audio_only=args.audio_only,
            playlist=args.playlist,
            cookies=args.cookies,
            cookies_from_browser=args.cookies_from_browser,
            json=True,
            no_interactive=True,
            force=False,
            debug=args.debug,
        )
        _handle_download_command(namespace)
        return 0

    if args.url:
        namespace = argparse.Namespace(
            target=args.url,
            config=args.config,
            output=args.output,
            quality=args.quality,
            audio_only=args.audio_only,
            playlist=args.playlist,
            cookies=args.cookies,
            cookies_from_browser=args.cookies_from_browser,
            json=False,
            no_interactive=False,
            force=False,
            debug=args.debug,
        )
        _handle_download_command(namespace)
        return 0

    _handle_interactive_mode(args.config, args.debug)
    return 0


def execute(argv: list[str] | None = None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] not in SUBCOMMANDS and not argv[0].startswith("-"):
        return _handle_legacy_mode(argv)

    parser = _build_subcommand_parser()
    args = parser.parse_args(argv)

    if args.version:
        print(os.environ.get("VDL_VERSION", "0.1.0"))
        return 0

    if args.update or args.command == "update":
        return _handle_update_command(args)

    if args.command == "download":
        _handle_download_command(args)
        return 0

    if args.command == "crawl":
        _handle_crawl_command(args)
        return 0

    if args.command == "status":
        _handle_status_command(args)
        return 0

    if args.command == "doctor":
        _handle_doctor_command(args)
        return 0

    if args.command == "config":
        _handle_config_command(args)
        return 0

    _handle_interactive_mode(args.config, args.debug)
    return 0


if __name__ == "__main__":
    raise SystemExit(execute())
