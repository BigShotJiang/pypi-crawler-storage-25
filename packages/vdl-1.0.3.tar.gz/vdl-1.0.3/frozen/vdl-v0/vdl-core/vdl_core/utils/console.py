"""
Global console instance for VDL Core.
Ensures a single Console object controls stdout/stderr to prevent UI tearing
when mixing Rich progress bars and logging.
"""

from rich.console import Console

# Create a single global console instance
# force_terminal=True ensures colors work even if piped, but safe to leave auto
console = Console()
