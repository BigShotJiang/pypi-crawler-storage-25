"""
Utility functions for Video Downloader
"""

import re


def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename to be filesystem-friendly with lowercase and hyphens.

    Args:
        filename: Original filename with extension

    Returns:
        Sanitized filename in the format: the-boy-video.mp4

    Examples:
        "The Boy Video.mp4" -> "the-boy-video.mp4"
        "My Video (2024)!.mp4" -> "my-video-2024.mp4"
        "Test___Multiple   Spaces.mp4" -> "test-multiple-spaces.mp4"
    """
    # Split filename and extension
    if "." in filename:
        name, ext = filename.rsplit(".", 1)
        ext = "." + ext.lower()
    else:
        name = filename
        ext = ""

    # Convert to lowercase
    name = name.lower()

    # Remove all characters that are not alphanumeric, spaces, or hyphens
    name = re.sub(r"[^a-z0-9\s-]", "", name)

    # Replace spaces and underscores with hyphens
    name = re.sub(r"[\s_]+", "-", name)

    # Replace multiple consecutive hyphens with a single hyphen
    name = re.sub(r"-+", "-", name)

    # Strip leading and trailing hyphens
    name = name.strip("-")

    # If name becomes empty, use a default
    if not name:
        name = "video"

    return name + ext
