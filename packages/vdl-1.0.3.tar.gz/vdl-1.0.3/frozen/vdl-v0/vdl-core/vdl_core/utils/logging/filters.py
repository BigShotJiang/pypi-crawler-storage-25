import logging
from .context import request_id_var, download_id_var


class ContextFilter(logging.Filter):
    """
    Log filter that injects context variables (request_id, download_id)
    into the log record.
    """

    def filter(self, record):
        record.request_id = request_id_var.get()
        record.download_id = download_id_var.get()
        return True
