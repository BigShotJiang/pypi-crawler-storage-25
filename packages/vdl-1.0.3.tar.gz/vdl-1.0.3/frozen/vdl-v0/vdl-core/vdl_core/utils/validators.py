"""
Data Validation Helpers
Shared validation logic for URLs and inputs.
Responsible for:
- Validating URL formats for supported sites
- Checking filesystem path validity and permissions
- Sanitizing user input before processing
"""
