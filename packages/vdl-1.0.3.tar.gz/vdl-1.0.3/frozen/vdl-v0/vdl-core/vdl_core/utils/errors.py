"""
Custom Exception Definitions
Standardized error types for the VDL ecosystem.
Responsible for:
- Defining domain-specific errors (DownloadError, TranscodeError, SyncError)
- Providing meaningful error messages for the UI
- Centralizing shared error semantics for CLI flows
"""
