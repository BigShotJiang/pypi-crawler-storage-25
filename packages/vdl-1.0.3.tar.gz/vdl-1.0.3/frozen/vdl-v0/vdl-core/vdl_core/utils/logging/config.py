import logging
import sys
from pathlib import Path
from logging.handlers import RotatingFileHandler
from typing import Optional

from .filters import ContextFilter
from .formatters import get_console_formatter, get_file_formatter

from rich.logging import RichHandler
from vdl_core.utils.console import console


def setup_logging(
    phase: str = "dev", level: str = "INFO", log_dir: Optional[Path] = None
):
    """
    Initialize global logging configuration.

    Args:
        phase: 'dev', 'prod', 'test', etc.
        level: Logging level (INFO, DEBUG, etc.)
        log_dir: Directory for log files (required for prod/persistent logging)
    """
    root = logging.getLogger()

    # Convert string level to constant
    log_level = getattr(logging, level.upper(), logging.INFO)
    root.setLevel(log_level)

    # Clear existing handlers
    if root.handlers:
        root.handlers.clear()

    # Create context filter
    context_filter = ContextFilter()

    console_handler = RichHandler(
        rich_tracebacks=True,
        omit_repeated_times=False,
        show_path=False,
        console=console,  # Use shared global console
    )
    console_handler.addFilter(context_filter)
    root.addHandler(console_handler)

    # 2. File Handler (Phase dependent)
    if phase != "dev" and log_dir:
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file = log_dir / "vdl.log"

        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=5,
            encoding="utf-8",
        )
        file_handler.setFormatter(get_file_formatter())
        file_handler.addFilter(context_filter)
        root.addHandler(file_handler)

    # Silence third-party libs
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("selenium").setLevel(logging.WARNING)
