import contextvars

# Context variables for structured logging
request_id_var = contextvars.ContextVar("request_id", default=None)
download_id_var = contextvars.ContextVar("download_id", default=None)


def set_request_id(request_id: str):
    """Set the current request ID context."""
    request_id_var.set(request_id)


def set_download_id(download_id: str):
    """Set the current download ID context."""
    download_id_var.set(download_id)


def get_request_id():
    """Get the current request ID."""
    return request_id_var.get()


def get_download_id():
    """Get the current download ID."""
    return download_id_var.get()
