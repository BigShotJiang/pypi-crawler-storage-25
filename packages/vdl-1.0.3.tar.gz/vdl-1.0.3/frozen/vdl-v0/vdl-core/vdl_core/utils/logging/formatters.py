import logging


class StandardFormatter(logging.Formatter):
    """
    Standard text formatter that includes context IDs if present.
    Format: [TIMESTAMP] [LEVEL] [LOGGER] [REQ_ID] [DL_ID] MESSAGE
    """

    def format(self, record):
        # Ensure attributes exist
        if not hasattr(record, "request_id"):
            record.request_id = None
        if not hasattr(record, "download_id"):
            record.download_id = None

        return super().format(record)


def get_console_formatter() -> logging.Formatter:
    """Get the formatter for console output."""
    fmt = "[%(asctime)s] [%(levelname)s] [%(name)s]"

    # Add context placeholders
    fmt += " [%(request_id)s]"
    fmt += " [%(download_id)s]"

    fmt += " %(message)s"

    return StandardFormatter(fmt, datefmt="%Y-%m-%d %H:%M:%S")


def get_file_formatter() -> logging.Formatter:
    """Get the formatter for file output."""
    return get_console_formatter()
