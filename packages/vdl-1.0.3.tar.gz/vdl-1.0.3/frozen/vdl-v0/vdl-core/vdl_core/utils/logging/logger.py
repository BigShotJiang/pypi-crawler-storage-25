import logging


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance with valid configuration.
    Applications should strictly use this factory.
    """
    return logging.getLogger(name)
