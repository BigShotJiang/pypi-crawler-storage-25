import os
from typing import Tuple, Optional
from urllib.parse import urlparse, parse_qs


class UrlAnalyzer:
    """
    Centralized logic for analyzing input strings (URLs or file paths).
    Determines if input is a playlist, a mix, a single video, or a local file.
    """

    @staticmethod
    def is_local_file(input_str: Optional[str]) -> bool:
        """Check if input is a valid local file path (video or text)."""
        if not input_str:
            return False

        # Strip quotes just in case
        clean_path = input_str.strip("\"'").strip()
        expanded_path = os.path.realpath(os.path.expanduser(clean_path))

        return os.path.exists(expanded_path) and not os.path.isdir(expanded_path)

    @staticmethod
    def looks_like_local_path(input_str: Optional[str]) -> bool:
        """Heuristic check for local-path-shaped input, even if the file is missing."""
        if not input_str:
            return False

        clean_path = input_str.strip("\"'").strip()
        if not clean_path:
            return False

        # Real URLs should never be treated as local paths.
        parsed = urlparse(clean_path)
        if parsed.scheme and parsed.netloc:
            return False

        return (
            clean_path.startswith(("~/", "./", "../", "/"))
            or os.sep in clean_path
            or clean_path.lower().endswith(
                (".txt", ".list", ".urls", ".mp4", ".mkv", ".mov", ".avi", ".webm")
            )
        )

    @staticmethod
    def is_text_file(input_str: str) -> bool:
        """Check if input is a text file (likely a link list)."""
        if not input_str:
            return False

        clean_path = input_str.strip("\"'").strip()
        expanded_path = os.path.realpath(os.path.expanduser(clean_path))

        if not (os.path.exists(expanded_path) and not os.path.isdir(expanded_path)):
            return False

        # Extension check
        if clean_path.lower().endswith((".txt", ".list", ".urls")):
            return True

        # Content check: Try to read first few bytes
        try:
            with open(expanded_path, "r", encoding="utf-8") as f:
                f.read(1024)
            return True
        except UnicodeDecodeError:
            return False
        except Exception:
            return False

    @staticmethod
    def looks_like_text_playlist_file(input_str: Optional[str]) -> bool:
        """Heuristic check for playlist-link file input based on extension/path shape."""
        if not input_str:
            return False

        clean_path = input_str.strip("\"'").strip().lower()
        return clean_path.endswith((".txt", ".list", ".urls"))

    @staticmethod
    def analyze_url(url: str) -> Tuple[bool, bool, bool]:
        """
        Analyze a URL to determine its type.
        Returns: (is_playlist, is_mix, is_ambiguous)

        - is_playlist: Explicitly a playlist (view_playlist?) or purely list=
        - is_mix: A 'watch' URL that happens to be in a list (Youtube Mix)
        - is_ambiguous: Contains list= but also watch=, requiring user clarification
        """
        if not url:
            return False, False, False

        clean_url = url.strip()

        # Explicit playlist pages
        if "/playlist?" in clean_url or "/view_playlist?" in clean_url:
            return True, False, False

        # Check for list param
        has_list = "list=" in clean_url
        has_watch = "watch?" in clean_url

        if has_list and not has_watch:
            # list= without watch? is typically a playlist page
            return True, False, False

        if has_list and has_watch:
            # list= AND watch? is a Mix or a video inside a playlist.
            # This is "ambiguous" because the user might want just the video OR the whole list.
            # Usually treated as Single Video by default in VDL unless --playlist is passed,
            # but we flag it as ambiguous/mix so the UI can ask the user.
            return False, True, True

        return False, False, False
