from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, UTC
from pathlib import Path
from typing import Iterator

from vdl_core.config.app_paths import ensure_app_dirs, get_app_paths
from vdl_core.core.models import DownloadProgress


class StateStore:
    def __init__(self, db_path: Path | None = None):
        paths = ensure_app_dirs()
        self.db_path = db_path or paths.state_db
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    @contextmanager
    def _connect(self) -> Iterator[sqlite3.Connection]:
        connection = sqlite3.connect(self.db_path)
        connection.row_factory = sqlite3.Row
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    def _init_db(self):
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS downloads (
                    id TEXT PRIMARY KEY,
                    source_url TEXT NOT NULL,
                    command TEXT NOT NULL,
                    status TEXT NOT NULL,
                    output_path TEXT,
                    error TEXT,
                    percent REAL,
                    speed TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_downloads_source_url
                ON downloads(source_url)
                """
            )

    def record_initial(self, download_id: str, source_url: str, command: str):
        now = datetime.now(UTC).isoformat()
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO downloads (
                    id, source_url, command, status, output_path, error,
                    percent, speed, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    download_id,
                    source_url,
                    command,
                    "queued",
                    None,
                    None,
                    0.0,
                    None,
                    now,
                    now,
                ),
            )

    def update_progress(
        self, progress: DownloadProgress, source_url: str, command: str
    ):
        with self._connect() as conn:
            existing = conn.execute(
                "SELECT created_at FROM downloads WHERE id = ?", (progress.id,)
            ).fetchone()
            created_at = (
                existing["created_at"] if existing else datetime.now(UTC).isoformat()
            )
            conn.execute(
                """
                INSERT OR REPLACE INTO downloads (
                    id, source_url, command, status, output_path, error,
                    percent, speed, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    progress.id,
                    source_url,
                    command,
                    progress.status.value,
                    progress.output_path,
                    progress.error,
                    progress.percent,
                    progress.speed,
                    created_at,
                    progress.updated_at.isoformat(),
                ),
            )

    def find_by_url(self, source_url: str):
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT * FROM downloads
                WHERE source_url = ?
                ORDER BY updated_at DESC
                LIMIT 1
                """,
                (source_url,),
            ).fetchone()
            return dict(row) if row else None

    def get(self, download_id: str):
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM downloads WHERE id = ?",
                (download_id,),
            ).fetchone()
            return dict(row) if row else None

    def list_recent(self, limit: int = 20):
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM downloads
                ORDER BY updated_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
            return [dict(row) for row in rows]
