import tempfile
import unittest
from pathlib import Path

from vdl_core.config.defaults import DEFAULT_OUTPUT_DIR
from vdl_core.config.manager import ConfigManager
from vdl_core.config.paths import resolve_output_dir
from vdl_core.state import StateStore
from vdl_core.core.models import DownloadProgress, DownloadStatus


class OutputPathResolutionTests(unittest.TestCase):
    def test_valid_requested_path_is_used(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            result = resolve_output_dir(tmpdir)
            self.assertEqual(result.active_path, str(Path(tmpdir).resolve()))
            self.assertFalse(result.used_fallback)
            self.assertIsNone(result.warning)

    def test_unusable_path_falls_back(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "not-a-directory"
            file_path.write_text("content", encoding="utf-8")

            result = resolve_output_dir(str(file_path))

            self.assertEqual(
                result.active_path, str(Path(DEFAULT_OUTPUT_DIR).resolve())
            )
            self.assertTrue(result.used_fallback)
            self.assertIsNotNone(result.warning)


class ConfigManagerTests(unittest.TestCase):
    def test_runtime_override_does_not_persist(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "config.toml"
            manager = ConfigManager(str(config_path))
            original_output = manager.get("output_dir")

            manager.set_runtime("output_dir", "/tmp/override")

            self.assertEqual(manager.get("output_dir"), "/tmp/override")

            reloaded = ConfigManager(str(config_path))
            self.assertEqual(reloaded.get("output_dir"), original_output)


class StateStoreTests(unittest.TestCase):
    def test_record_and_lookup_download(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "vdl.db"
            store = StateStore(db_path)
            store.record_initial("job-1", "https://example.com/video", "download")
            store.update_progress(
                DownloadProgress(
                    id="job-1",
                    status=DownloadStatus.COMPLETED,
                    percent=100.0,
                    output_path="/tmp/video.mp4",
                ),
                source_url="https://example.com/video",
                command="download",
            )

            row = store.get("job-1")
            self.assertEqual(row["status"], "completed")
            self.assertEqual(row["output_path"], "/tmp/video.mp4")

            by_url = store.find_by_url("https://example.com/video")
            self.assertEqual(by_url["id"], "job-1")


if __name__ == "__main__":
    unittest.main()
