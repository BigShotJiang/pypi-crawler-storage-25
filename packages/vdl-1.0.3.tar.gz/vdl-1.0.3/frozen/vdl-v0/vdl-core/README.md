# VDL Core

Core Python package for the VDL Rich CLI video downloader and converter.

This package provides the `vdl` command entrypoint, interactive download flows,
playlist handling, and supporting downloader utilities.
