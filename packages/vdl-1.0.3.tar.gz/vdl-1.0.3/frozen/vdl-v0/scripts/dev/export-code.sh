#!/usr/bin/env bash

# VDL Source Code Exporter
# Consolidation script to export the entire codebase into a single text file for LLM context.

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$( cd "$SCRIPT_DIR/../../" && pwd )"
OUTPUT_DIR="$PROJECT_ROOT/data/code_exports"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
OUTPUT_FILE="$OUTPUT_DIR/vdl_codebase_$TIMESTAMP.txt"

# Default search path
SEARCH_PATH="."

# Parse arguments
while getopts "f:" opt; do
  case $opt in
    f) SEARCH_PATH="$OPTARG" ;;
    *) echo "Usage: $0 [-f path]"; exit 1 ;;
  esac
done

echo "📄 Exporting VDL codebase (Target: $SEARCH_PATH) to $OUTPUT_FILE..."

# Ensure the export directory exists before writing the final file.
mkdir -p "$OUTPUT_DIR"

# Define file extensions to include
INCLUDE_EXTENSIONS=("py" "sh" "md" "yaml" "yml" "toml" "js" "html" "css" "rs" "sql")

# Define directories to exclude
EXCLUDE_DIRS=(".git" ".venv" "__pycache__" "node_modules" "data" "dist" "build" ".ruff_cache" ".pytest_cache" "target")

# Build the temporary export
TEMP_FILE=$(mktemp)

{
    echo "================================================================================"
    echo "VDL CODEBASE EXPORT"
    echo "Generated: $(date)"
    echo "Project Root: $PROJECT_ROOT"
    echo "Search Path: $SEARCH_PATH"
    echo "================================================================================"
    echo ""
} >> "$TEMP_FILE"

# Find and process files
cd "$PROJECT_ROOT" || exit 1

# If SEARCH_PATH is a specific file, just use it
if [ -f "$SEARCH_PATH" ]; then
    FILES=("$SEARCH_PATH")
else
    # Build the find command as an array to avoid quoting/eval issues
    # But since we have complex logic (-o), we'll stick to string and fix escaping
    FIND_CMD="find $SEARCH_PATH -type f \( "
    first=true
    for ext in "${INCLUDE_EXTENSIONS[@]}"; do
        if [ "$first" = true ]; then
            FIND_CMD+="-name '*.$ext'"
            first=false
        else
            FIND_CMD+=" -o -name '*.$ext'"
        fi
    done
    FIND_CMD+=" \) "

    # Add exclusions
    for dir in "${EXCLUDE_DIRS[@]}"; do
        FIND_CMD+=" -not -path '*/$dir/*'"
    done
    
    # Execute find and get file list
    # Use -n to handle empty results gracefully if applicable, but eval is fine here
    FILES_LIST=$(eval "$FIND_CMD" | sort)
    
    # Check if we got any files
    if [ -z "$FILES_LIST" ]; then
        echo "⚠ No files found in $SEARCH_PATH matching extensions."
        rm "$TEMP_FILE"
        exit 0
    fi
    
    IFS=$'\n' read -rd '' -a FILES <<< "$FILES_LIST"
fi

# Process each file
for file in "${FILES[@]}"; do
    # Normalize path for the header
    DISPLAY_PATH=$(echo "$file" | sed 's|^./||')
    
    # Skip the output file itself if it's in the search path
    if [[ "$DISPLAY_PATH" == *".txt" && "$DISPLAY_PATH" == *"vdl_codebase"* ]]; then
        continue
    fi

    if [ ! -f "$file" ]; then
        continue
    fi

    echo "--------------------------------------------------------------------------------" >> "$TEMP_FILE"
    echo "FILE: $DISPLAY_PATH" >> "$TEMP_FILE"
    echo "--------------------------------------------------------------------------------" >> "$TEMP_FILE"
    cat "$file" >> "$TEMP_FILE"
    echo -e "\n" >> "$TEMP_FILE"
done

mv "$TEMP_FILE" "$OUTPUT_FILE"

echo "✅ Export complete! Shared at: $OUTPUT_FILE"
