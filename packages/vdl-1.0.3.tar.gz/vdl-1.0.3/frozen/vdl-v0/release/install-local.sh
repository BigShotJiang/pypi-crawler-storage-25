#!/usr/bin/env sh
set -e

BINARY="$(cd "$(dirname "$0")/.." && pwd)/dist/vdl"
INSTALL_DIR="$HOME/.local/bin"
TARGET="$INSTALL_DIR/vdl"
VDL_VERSION="${VDL_VERSION:-v0}"

echo "Installing VDL ${VDL_VERSION}..."

if [ ! -f "$BINARY" ]; then
  echo "Error: dist/vdl not found. Run 'task build' first."
  exit 1
fi

mkdir -p "$INSTALL_DIR"
cp "$BINARY" "$TARGET"
chmod +x "$TARGET"

case ":$PATH:" in
  *":$INSTALL_DIR:"*) ;;
  *) echo "Note: Add $INSTALL_DIR to your PATH:  export PATH=\"$INSTALL_DIR:\$PATH\"" ;;
esac

echo "Installed: $TARGET"
"$TARGET" --version
