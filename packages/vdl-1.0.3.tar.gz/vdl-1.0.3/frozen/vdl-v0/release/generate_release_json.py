#!/usr/bin/env python3

from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, UTC
from pathlib import Path


DIST_DIR = Path("dist")


def sha256_for(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(8192), b""):
            digest.update(chunk)
    return digest.hexdigest()


def artifact_payload(base_url: str, artifact_name: str) -> dict[str, object]:
    artifact_path = DIST_DIR / artifact_name
    return {
        "url": f"{base_url}/{artifact_name}",
        "sha256": sha256_for(artifact_path),
        "size": artifact_path.stat().st_size,
    }


def maybe_artifact(base_url: str, artifact_name: str) -> dict[str, object] | None:
    artifact_path = DIST_DIR / artifact_name
    if not artifact_path.exists():
        return None
    return artifact_payload(base_url, artifact_name)


def load_existing_artifacts(path: str) -> dict[str, dict[str, object]]:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data.get("artifacts", {})
    except (OSError, json.JSONDecodeError):
        return {}


def main():
    version = os.environ["VDL_RELEASE_VERSION"]
    base_url = os.environ["VDL_RELEASE_BASE_URL"].rstrip("/")
    notes_url = os.environ.get("VDL_NOTES_URL", "")

    # Start with any existing artifacts from a prior release.json (e.g. Linux built by CI,
    # macOS built locally). New artifacts for the same platform key override stale ones.
    merge_path = os.environ.get("VDL_MERGE_RELEASE_JSON", "")
    artifacts: dict[str, dict[str, object]] = (
        load_existing_artifacts(merge_path) if merge_path else {}
    )

    vdl_version = os.environ.get("VDL_VERSION", "v0")

    macos_arm = maybe_artifact(
        base_url, f"vdl-{vdl_version}-aarch64-apple-darwin.tar.gz"
    )
    if macos_arm:
        artifacts["aarch64-apple-darwin"] = macos_arm

    linux_x64 = maybe_artifact(
        base_url, f"vdl-{vdl_version}-x86_64-unknown-linux-gnu.tar.gz"
    )
    if linux_x64:
        artifacts["x86_64-unknown-linux-gnu"] = linux_x64

    payload = {
        "version": version,
        "channel": "stable",
        "published_at": datetime.now(UTC).isoformat(),
        "artifacts": artifacts,
        "notes_url": notes_url,
    }

    DIST_DIR.mkdir(parents=True, exist_ok=True)
    with open(DIST_DIR / "release.json", "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()
