#!/usr/bin/env sh
set -eu

PAGES_BASE_URL="${PAGES_BASE_URL:-https://bildcraft.gitlab.io/products/video-downloader/vdl}"
RELEASE_METADATA_URL="${RELEASE_METADATA_URL:-$PAGES_BASE_URL/stable/release.json}"
INSTALL_ROOT="${HOME}/.local/share/vdl"
BIN_LINK_DIR="${HOME}/.local/bin"
STATE_DIR="${HOME}/.local/state/vdl"

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "Missing required command: $1" >&2
    exit 1
  }
}

detect_platform() {
  os="$(uname -s)"
  arch="$(uname -m)"
  case "${os}/${arch}" in
    Darwin/arm64) echo "aarch64-apple-darwin" ;;
    Darwin/x86_64) echo "x86_64-apple-darwin" ;;
    Linux/x86_64) echo "x86_64-unknown-linux-gnu" ;;
    *)
      echo "Unsupported platform: ${os}/${arch}" >&2
      exit 1
      ;;
  esac
}

install_ffmpeg() {
  if command -v ffmpeg >/dev/null 2>&1; then
    return 0
  fi

  os="$(uname -s)"
  if [ "$os" = "Darwin" ]; then
    if command -v brew >/dev/null 2>&1; then
      brew install ffmpeg
      return 0
    fi
    echo "ffmpeg is required. Install it with: brew install ffmpeg" >&2
    exit 1
  fi

  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo apt-get install -y ffmpeg
    return 0
  fi

  if command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y ffmpeg
    return 0
  fi

  echo "ffmpeg is required but could not be installed automatically." >&2
  exit 1
}

require_cmd curl
require_cmd tar

if command -v shasum >/dev/null 2>&1; then
  checksum_cmd="shasum -a 256"
elif command -v sha256sum >/dev/null 2>&1; then
  checksum_cmd="sha256sum"
else
  echo "Missing checksum tool: shasum or sha256sum" >&2
  exit 1
fi

platform="$(detect_platform)"
install_ffmpeg

tmpdir="$(mktemp -d)"
metadata_file="${tmpdir}/release.json"
curl -fsSL "$RELEASE_METADATA_URL" -o "$metadata_file"

artifact_version="$(awk -F'"' '/"version"/ {print $4; exit}' "$metadata_file")"
artifact_url="$(awk -F'"' -v platform="$platform" '
  $2 == platform { in_block=1; next }
  in_block && $2 == "url" { print $4; exit }
  in_block && $0 ~ /^    }/ { in_block=0 }
' "$metadata_file")"
artifact_sha="$(awk -F'"' -v platform="$platform" '
  $2 == platform { in_block=1; next }
  in_block && $2 == "sha256" { print $4; exit }
  in_block && $0 ~ /^    }/ { in_block=0 }
' "$metadata_file")"

[ -n "$artifact_version" ] || {
  echo "Could not read release version from metadata" >&2
  exit 1
}
[ -n "$artifact_url" ] || {
  echo "Could not resolve artifact URL for platform ${platform}" >&2
  exit 1
}
[ -n "$artifact_sha" ] || {
  echo "Could not resolve artifact checksum for platform ${platform}" >&2
  exit 1
}

archive_path="${tmpdir}/vdl.tar.gz"
curl -fsSL "$artifact_url" -o "$archive_path"

actual_sha="$($checksum_cmd "$archive_path" | awk '{print $1}')"
[ "$actual_sha" = "$artifact_sha" ] || {
  echo "Checksum mismatch for downloaded artifact" >&2
  exit 1
}

version_dir="${INSTALL_ROOT}/bin/vdl-${artifact_version}"
mkdir -p "$version_dir" "$BIN_LINK_DIR" "$STATE_DIR"
tar -xzf "$archive_path" -C "$version_dir"

ln -sfn "$version_dir" "${INSTALL_ROOT}/bin/current"
ln -sfn "${INSTALL_ROOT}/bin/current/vdl" "${BIN_LINK_DIR}/vdl"

cat > "${STATE_DIR}/install.json" <<EOF
{
  "product": "vdl",
  "version": "${artifact_version}",
  "channel": "stable",
  "platform": "${platform}",
  "install_root": "${INSTALL_ROOT}",
  "active_binary": "${INSTALL_ROOT}/bin/current/vdl",
  "installed_at": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "artifact_url": "${artifact_url}",
  "artifact_sha256": "${artifact_sha}",
  "install_type": "release",
  "release_metadata_url": "${RELEASE_METADATA_URL}"
}
EOF

echo "VDL installed to ${BIN_LINK_DIR}/vdl"
echo "If 'vdl' is not found, add this to your shell profile:"
echo 'export PATH="$HOME/.local/bin:$PATH"'
