# VDL

VDL is a lightweight CLI downloader built on top of `yt-dlp`.
It adds a cleaner command interface, idempotent downloads, crawl support,
structured state, and script-friendly behavior for repeatable media downloads.

## Install

```bash
curl https://bildcraft.gitlab.io/products/video-downloader/vdl/install.sh | sh
```

## Verify

```bash
vdl --version
vdl doctor
```

## Common Commands

```bash
vdl download "https://www.youtube.com/watch?v=VIDEO_ID"
vdl download "https://www.youtube.com/playlist?list=PLAYLIST_ID"
vdl crawl "https://example.com/videos" --dry-run
vdl status
vdl --update
```

## Docs

- [Quickstart](docs/quickstart.md)
- [Install](docs/install.md)
- [CLI Usage](docs/cli-usage.md)
- [Configuration](docs/configuration.md)
- [Downloads and Idempotency](docs/downloads-and-idempotency.md)
- [Crawling](docs/crawling.md)
- [Troubleshooting](docs/troubleshooting.md)
- [Development](docs/development.md)
- [Release Builds](docs/release-builds.md)

## Product Scope

VDL is a CLI/headless downloader. It is not a desktop app, TUI, or media intelligence platform.

## License

MIT
