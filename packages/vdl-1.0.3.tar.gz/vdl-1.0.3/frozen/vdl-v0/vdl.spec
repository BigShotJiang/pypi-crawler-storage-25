# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules, collect_data_files, collect_all

block_cipher = None

# Hidden imports for dynamic dependencies
hidden_imports = [
    'yt_dlp.extractor',  # Crucial for yt-dlp to find its extractors
    'yt_dlp.extractor.youtube', 
    'curl_cffi',
    'rich',
    'rich.logging',
    'rich.progress',
    'rich.console',
    'rich.prompt',
    'rich.table',
    'rich.panel',
    'rich.box',
    'pkg_resources.extern',
]

# Collect all submodules for yt-dlp extractors to be safe
hidden_imports.extend(collect_submodules('yt_dlp.extractor'))

# Data files (if any needed for curl_cffi or other libs)
datas = []
binaries = []

# Collect curl-cffi binaries if needed (usually handled by PyInstaller but being explicit helps)
tmp_ret = collect_all('curl_cffi')
datas += tmp_ret[0]
binaries += tmp_ret[1]
hidden_imports += tmp_ret[2]


a = Analysis(
    ['vdl-core/vdl_core/__main__.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hidden_imports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='vdl',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
