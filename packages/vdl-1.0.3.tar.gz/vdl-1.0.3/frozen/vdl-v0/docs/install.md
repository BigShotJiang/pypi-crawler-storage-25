# Install

VDL is installed as a release artifact, not as a global Python package.

## Standard install

```bash
curl https://bildcraft.gitlab.io/products/video-downloader/vdl/install.sh | sh
```

The installer:

- detects your platform
- downloads the correct release artifact
- verifies its checksum
- installs it into a user-local versioned directory
- creates a stable `vdl` symlink
- records install metadata
- checks for `ffmpeg`

## Install layout

- Binary root: `~/.local/share/vdl/bin/`
- Active symlink: `~/.local/share/vdl/bin/current`
- User command: `~/.local/bin/vdl`
- Install metadata: `~/.local/state/vdl/install.json`

## PATH

If `vdl` is not found after install, add this to your shell profile:

```bash
export PATH="$HOME/.local/bin:$PATH"
```

## Dependencies

Bundled in the release artifact:

- VDL application code
- Python runtime
- Python dependencies
- vendored `yt-dlp`

External dependency:

- `ffmpeg`

On supported systems, the installer may install `ffmpeg` automatically. Otherwise it prints the exact command you need.

## GitLab-hosted release flow

In the intended GitLab setup:

- GitLab Pages serves `https://bildcraft.gitlab.io/products/video-downloader/vdl/install.sh`
- GitLab Pages also serves `https://bildcraft.gitlab.io/products/video-downloader/vdl/stable/release.json`
- `release.json` points to immutable versioned binaries in the GitLab Generic Package Registry
