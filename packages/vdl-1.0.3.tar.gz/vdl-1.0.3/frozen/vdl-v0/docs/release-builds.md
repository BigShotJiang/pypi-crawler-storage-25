# Release Builds

VDL release builds are GitLab-centered, driven by a `Taskfile.yml` that works identically locally and in CI.

## Release inputs

- `Taskfile.yml`
- `.gitlab-ci.yml`
- `release/install.sh`
- `release/generate_release_json.py`

## Supported targets

- `x86_64-unknown-linux-gnu` — built in GitLab CI
- `aarch64-apple-darwin` — built locally on Apple Silicon and uploaded via `task release`

## Release outputs

```text
dist/
  vdl-aarch64-apple-darwin.tar.gz
  vdl-aarch64-apple-darwin.sha256
  vdl-x86_64-unknown-linux-gnu.tar.gz
  vdl-x86_64-unknown-linux-gnu.sha256
  release.json
```

## Publish model

- GitLab CI builds the Linux artifact and runs `task build`, `task package`, `task generate-metadata`, `task publish`
- GitLab Generic Package Registry stores immutable versioned binaries
- GitLab Pages serves stable `install.sh` and `stable/release.json`
- Git tags trigger releases

## macOS local release flow

The macOS Apple Silicon artifact is built locally on an Apple Silicon Mac:

```bash
GITLAB_PROJECT_ID=... \
GITLAB_TOKEN=... \
VDL_RELEASE_VERSION=0.1.0 \
task release
```

`task release` does the following in order:

1. Build binary with PyInstaller (`task build`)
2. Package into `dist/vdl-aarch64-apple-darwin.tar.gz` with checksum (`task package`)
3. Download any existing `release.json` from the registry, merge Linux + macOS artifacts, write new `release.json` (`task generate-metadata`)
4. Upload artifacts and merged `release.json` to GitLab Package Registry (`task publish`)
5. Trigger a `pages_refresh` CI pipeline to re-deploy Pages with the merged metadata

## Task reference

| Task | Description |
|------|-------------|
| `task test` | Run unit tests and CLI smoke checks |
| `task build` | Build VDL binary with PyInstaller |
| `task package` | Create platform-specific tar.gz artifact and checksum |
| `task generate-metadata` | Generate/merge `release.json` |
| `task publish` | Upload artifacts to GitLab Package Registry |
| `task release` | Full local release flow (build → package → generate-metadata → publish → Pages refresh) |

## Pages and registry URLs

- Pages install URL: `https://bildcraft.gitlab.io/products/video-downloader/vdl/install.sh`
- Stable metadata URL: `https://bildcraft.gitlab.io/products/video-downloader/vdl/stable/release.json`
- Registry artifact URL pattern:
  - `${CI_API_V4_URL}/projects/${CI_PROJECT_ID}/packages/generic/vdl/<version>/<artifact>`

The installer and `vdl --update` only consume the Pages-served stable metadata and the immutable registry URLs referenced from it.

## Smoke checks

After building, verify the artifact directly:

```bash
./dist/vdl --version
./dist/vdl --help
./dist/vdl doctor --json
```
