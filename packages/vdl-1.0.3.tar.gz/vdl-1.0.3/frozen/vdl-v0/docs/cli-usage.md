# CLI Usage

## Commands

```bash
vdl download <url>
vdl crawl <url>
vdl status
vdl status <id>
vdl doctor
vdl config show
vdl config get <key>
vdl config set <key> <value>
vdl --update
vdl --version
```

## Download examples

```bash
vdl download "https://www.youtube.com/watch?v=VIDEO_ID"
vdl download "https://www.youtube.com/playlist?list=PLAYLIST_ID"
vdl download ./links.txt --json
vdl download "https://example.com/video" --audio-only
```

## Crawl examples

```bash
vdl crawl "https://example.com/videos" --dry-run
vdl crawl "https://example.com/videos" --download
vdl crawl "https://example.com/videos" --json
```

## Headless examples

```bash
vdl download "https://example.com/video" --json --no-interactive
vdl crawl "https://example.com/videos" --json --dry-run
vdl doctor --json
```

## Legacy compatibility

The older positional form is temporarily recognized:

```bash
vdl "https://www.youtube.com/watch?v=VIDEO_ID"
```

Use the subcommand form for new scripts and automation.
