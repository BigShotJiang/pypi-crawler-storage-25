# Downloads and Idempotency

VDL is designed to avoid duplicate work by default.

## Default behavior

When the same URL is submitted again, VDL prefers a safe, non-destructive result:

1. If a completed record exists, VDL reports the existing result and skips a duplicate download.
2. If a partial or missing result is detected, VDL attempts a normal recovery path where possible.
3. If the input is already active, VDL exposes status through the recorded task ID.

## Useful flags

```bash
vdl download <url> --force
vdl download <url> --output ~/Downloads/VDL
```

## Output organization

Default media location:

```text
~/Downloads/VDL
```

Batch and playlist flows may create subdirectories under the active output directory.
