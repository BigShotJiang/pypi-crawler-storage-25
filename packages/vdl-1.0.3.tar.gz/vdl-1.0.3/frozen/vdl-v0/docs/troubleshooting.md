# Troubleshooting

## `ffmpeg` not found

Run:

```bash
vdl doctor
```

Common fixes:

macOS:

```bash
brew install ffmpeg
```

Ubuntu/Debian:

```bash
sudo apt update
sudo apt install ffmpeg
```

Fedora:

```bash
sudo dnf install ffmpeg
```

## `vdl` command not found

Add this to your shell profile:

```bash
export PATH="$HOME/.local/bin:$PATH"
```

## Config or state path problems

VDL uses:

- `~/.config/vdl/config.toml`
- `~/.local/state/vdl/`
- `~/.cache/vdl/`

Use `vdl doctor` to verify path health.

## Self-update disabled

If VDL was not installed from a release artifact, `vdl --update` is intentionally disabled. Use the contributor workflow instead.
