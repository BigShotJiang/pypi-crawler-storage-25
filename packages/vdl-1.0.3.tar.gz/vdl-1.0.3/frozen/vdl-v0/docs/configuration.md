# Configuration

VDL stores configuration in:

```text
~/.config/vdl/config.toml
```

Current keys include:

- `output_dir`
- `default_quality`
- `audio_only`
- `embed_metadata`
- `embed_thumbnail`
- `embed_chapters`
- `reencode_for_quicktime`
- `max_concurrent_downloads`
- `audio_format`
- `audio_quality`
- `merge_format`
- `write_subtitles`
- `subtitle_langs`
- `release_channel`
- `release_metadata_url`

## Inspect config

```bash
vdl config show
vdl config get output_dir
```

## Update config

```bash
vdl config set output_dir ~/Videos/VDL
```

## Runtime override

Use `--output` to override the destination for a single run without rewriting config.
