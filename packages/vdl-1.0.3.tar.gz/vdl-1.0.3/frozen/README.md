# Frozen Implementations

This directory contains frozen/reference implementations.

`vdl-v0/` contains the current VDL implementation moved as-is for reference, build preservation, and future extraction.

The frozen v0 should remain installable on macOS using the preserved installer/release path:

```bash
curl <local-or-release-install-url> | sh
```

After installation, the command should run as:

```bash
vdl
```
