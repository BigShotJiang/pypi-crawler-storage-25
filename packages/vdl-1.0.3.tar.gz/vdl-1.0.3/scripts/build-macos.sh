#!/usr/bin/env bash
# Local macOS arm64 build for VDL.
#
# Produces, under ./out/:
#   vdl-<version>-aarch64-apple-darwin.tar.gz   (contains vdl, vdl-mcp)
#   SHA256SUMS
#
# Requirements: macOS arm64, Python 3.13, uv, ffmpeg/ffprobe for the doctor
# smoke check.
#
# Usage:
#   ./scripts/build-macos.sh
#   VDL_VERSION=1.2.3 ./scripts/build-macos.sh   # override pyproject version

set -euo pipefail

cd "$(dirname "$0")/.."

if [ "$(uname -s)" != "Darwin" ] || [ "$(uname -m)" != "arm64" ]; then
  echo "build-macos.sh must run on macOS arm64 (got $(uname -s)/$(uname -m))" >&2
  exit 1
fi

command -v uv >/dev/null 2>&1 || { echo "uv not found; install from https://docs.astral.sh/uv/" >&2; exit 1; }

VERSION="${VDL_VERSION:-$(awk -F'"' '/^version[[:space:]]*=/ {print $2; exit}' pyproject.toml)}"
[ -n "$VERSION" ] || { echo "could not determine VDL version" >&2; exit 1; }

echo "[build-macos] vdl ${VERSION} (arm64)"

uv sync --frozen --all-extras --dev
uv pip install pyinstaller

rm -rf build dist out
mkdir -p out

uv run pyinstaller --onefile --clean --noconfirm --name vdl scripts/vdl_entry.py
uv run pyinstaller \
  --onefile \
  --clean \
  --noconfirm \
  --name vdl-mcp \
  --hidden-import mcp \
  --hidden-import mcp.server \
  --hidden-import mcp.server.fastmcp \
  --collect-submodules mcp.server \
  --collect-submodules mcp.server.fastmcp \
  --exclude-module mcp.cli \
  scripts/vdl_mcp_entry.py

# Smoke-check the built binaries.
./dist/vdl --help >/dev/null
./dist/vdl doctor >/dev/null || echo "[build-macos] WARN: vdl doctor reported issues — review before release"
test -x ./dist/vdl-mcp

archive="out/vdl-${VERSION}-aarch64-apple-darwin.tar.gz"
tar -czf "$archive" -C dist vdl vdl-mcp

(cd out && shasum -a 256 "$(basename "$archive")" > SHA256SUMS)

cat <<EOF

[build-macos] done
  archive: ${archive}
  sums:    out/SHA256SUMS

Next steps:
  1. Tag: git tag vdl-v${VERSION} && git push origin vdl-v${VERSION}
  2. Upload to GitLab Release:
       glab release create vdl-v${VERSION} \\
         "${archive}" out/SHA256SUMS \\
         --notes "VDL ${VERSION} (macOS arm64)"
  3. CI vdl-publish-pages will then refresh the install manifest.
EOF
