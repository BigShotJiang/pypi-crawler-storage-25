"""PyInstaller entrypoint for the VDL MCP binary."""

from __future__ import annotations

from vdl.mcp_server import main


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
