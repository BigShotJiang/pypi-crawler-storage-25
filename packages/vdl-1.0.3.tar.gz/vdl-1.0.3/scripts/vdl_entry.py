"""PyInstaller entrypoint for the VDL CLI binary."""

from __future__ import annotations

from vdl.cli import main


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
