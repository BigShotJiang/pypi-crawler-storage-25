#!/usr/bin/env sh
# VDL installer.
#
# Usage:
#   curl -fsSL <install-url> | sh
#   curl -fsSL <install-url> | sh -s -- --install-deps
#
# Environment overrides:
#   VDL_RELEASE_BASE_URL  Base URL with release.json + artifacts (default: GitLab Pages).
#   VDL_INSTALL_DIR       Where to place the binary (default: $HOME/.local/bin).
#   VDL_VERSION           Pin a specific version; otherwise the manifest decides.
#
# Exit codes: 0 success, 1 hard error, 2 missing required dep that user must fix.

set -eu

VDL_RELEASE_BASE_URL="${VDL_RELEASE_BASE_URL:-https://bildcraft.gitlab.io/products/video-downloader/vdl/stable}"
VDL_INSTALL_DIR="${VDL_INSTALL_DIR:-${HOME}/.local/bin}"
INSTALL_DEPS=0
for arg in "$@"; do
  case "$arg" in
    --install-deps) INSTALL_DEPS=1 ;;
    --help|-h)
      sed -n '2,12p' "$0"
      exit 0
      ;;
  esac
done

log()  { printf '[vdl-install] %s\n' "$*"; }
warn() { printf '[vdl-install] WARN: %s\n' "$*" >&2; }
die()  { printf '[vdl-install] ERROR: %s\n' "$*" >&2; exit 1; }

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"
}

# ---- Platform detection -----------------------------------------------------

detect_platform() {
  os="$(uname -s)"
  arch="$(uname -m)"
  case "${os}/${arch}" in
    Darwin/arm64)        echo "aarch64-apple-darwin" ;;
    Darwin/x86_64)       echo "x86_64-apple-darwin" ;;
    Linux/x86_64)        echo "x86_64-unknown-linux-gnu" ;;
    Linux/aarch64|Linux/arm64) echo "aarch64-unknown-linux-gnu" ;;
    *) die "unsupported platform: ${os}/${arch}" ;;
  esac
}

ffmpeg_install_hint() {
  os="$(uname -s)"
  if [ "$os" = "Darwin" ]; then
    echo "brew install ffmpeg"
  elif command -v apt-get >/dev/null 2>&1; then
    echo "sudo apt-get install -y ffmpeg"
  elif command -v dnf >/dev/null 2>&1; then
    echo "sudo dnf install -y ffmpeg"
  elif command -v pacman >/dev/null 2>&1; then
    echo "sudo pacman -S --needed ffmpeg"
  else
    echo "see https://ffmpeg.org/download.html"
  fi
}

maybe_install_ffmpeg() {
  if command -v ffmpeg >/dev/null 2>&1 && command -v ffprobe >/dev/null 2>&1; then
    return 0
  fi
  hint="$(ffmpeg_install_hint)"
  if [ "$INSTALL_DEPS" -ne 1 ]; then
    warn "ffmpeg/ffprobe not found. Install with:  ${hint}"
    return 0
  fi
  os="$(uname -s)"
  if [ "$os" = "Darwin" ]; then
    command -v brew >/dev/null 2>&1 || die "Homebrew required for --install-deps on macOS. Install from https://brew.sh"
    brew install ffmpeg
  elif command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo apt-get install -y ffmpeg
  elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y ffmpeg
  elif command -v pacman >/dev/null 2>&1; then
    sudo pacman -S --needed --noconfirm ffmpeg
  else
    die "no supported package manager for --install-deps; run manually: ${hint}"
  fi
}

# ---- Release manifest -------------------------------------------------------

read_field() {
  # read_field <file> <platform> <field>  -> stdout
  awk -F'"' -v platform="$2" -v field="$3" '
    $2 == platform { in_block = 1; next }
    in_block && $2 == field { print $4; exit }
    in_block && $0 ~ /^[[:space:]]*}[[:space:]]*,?[[:space:]]*$/ { in_block = 0 }
  ' "$1"
}

# ---- Main -------------------------------------------------------------------

require_cmd curl
require_cmd tar
require_cmd uname

if command -v shasum >/dev/null 2>&1; then
  checksum_cmd="shasum -a 256"
elif command -v sha256sum >/dev/null 2>&1; then
  checksum_cmd="sha256sum"
else
  die "missing checksum tool (need shasum or sha256sum)"
fi

platform="$(detect_platform)"
log "platform: ${platform}"

if existing="$(command -v vdl 2>/dev/null)"; then
  log "existing vdl found at ${existing} — will be replaced if installed in the same location"
fi

tmpdir="$(mktemp -d)"
trap 'rm -rf "$tmpdir"' EXIT

manifest="${tmpdir}/release.json"
manifest_url="${VDL_RELEASE_BASE_URL%/}/release.json"
log "fetching ${manifest_url}"
curl -fsSL "$manifest_url" -o "$manifest" || die "failed to fetch release manifest"

version="${VDL_VERSION:-$(awk -F'"' '/"version"/ {print $4; exit}' "$manifest")}"
artifact_url="$(read_field "$manifest" "$platform" url)"
artifact_sha="$(read_field "$manifest" "$platform" sha256)"

[ -n "$version" ]      || die "could not read version from manifest"
[ -n "$artifact_url" ] || die "no artifact URL for platform ${platform}"
[ -n "$artifact_sha" ] || die "no checksum for platform ${platform}"

log "installing vdl ${version}"

archive="${tmpdir}/vdl.tar.gz"
curl -fsSL "$artifact_url" -o "$archive" || die "failed to download artifact"

actual="$($checksum_cmd "$archive" | awk '{print $1}')"
[ "$actual" = "$artifact_sha" ] || die "checksum mismatch (expected ${artifact_sha}, got ${actual})"

mkdir -p "$VDL_INSTALL_DIR"
case "$VDL_INSTALL_DIR" in
  /*) ;;
  *) die "VDL_INSTALL_DIR must be absolute: ${VDL_INSTALL_DIR}" ;;
esac

extract_dir="${tmpdir}/extract"
mkdir -p "$extract_dir"
tar -xzf "$archive" -C "$extract_dir"

# Archive is expected to contain a top-level vdl (and optionally vdl-mcp).
for name in vdl vdl-mcp; do
  src="$(find "$extract_dir" -maxdepth 3 -type f -name "$name" -perm -u+x | head -n1 || true)"
  [ -n "$src" ] || continue
  install -m 0755 "$src" "${VDL_INSTALL_DIR}/${name}"
  log "installed ${VDL_INSTALL_DIR}/${name}"
done

[ -x "${VDL_INSTALL_DIR}/vdl" ] || die "vdl binary missing after extraction"

# ---- Post-install checks ----------------------------------------------------

case ":$PATH:" in
  *":${VDL_INSTALL_DIR}:"*) ;;
  *) warn "${VDL_INSTALL_DIR} is not on PATH. Add this to your shell profile:"
     printf '       export PATH="%s:$PATH"\n' "$VDL_INSTALL_DIR" ;;
esac

maybe_install_ffmpeg

if "${VDL_INSTALL_DIR}/vdl" doctor >/dev/null 2>&1; then
  log "vdl doctor: ok"
else
  warn "vdl doctor reported issues. Run:  ${VDL_INSTALL_DIR}/vdl doctor"
fi

log "done. Run: vdl --help"
