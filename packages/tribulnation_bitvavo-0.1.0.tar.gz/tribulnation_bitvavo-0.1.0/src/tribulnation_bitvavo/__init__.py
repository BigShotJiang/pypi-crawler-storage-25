"""
### Tribulnation Bitvavo
> An SDK to connect Bitvavo with the Tribulnation ecosystem.

- Details
"""