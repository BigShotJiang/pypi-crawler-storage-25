import sys
import os
import json
from datetime import datetime
import pyperclip
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt
from rich import box

console = Console()

HISTORY_FILE = os.path.expanduser("~/.quickclip_history.json")
MAX_HISTORY = 100

# =========================
# Utility Functions
# =========================

def load_history():
    if not os.path.exists(HISTORY_FILE):
        return []
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return []


def save_history(history):
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2)


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# =========================
# Core Features
# =========================

def save_clip(text):
    history = load_history()

    entry = {
        "text": text,
        "time": now(),
        "length": len(text)
    }

    history.insert(0, entry)
    history = history[:MAX_HISTORY]
    save_history(history)

    console.print(Panel("[green]✔ Text saved to clipboard history![/green]"))


def list_clips():
    history = load_history()

    if not history:
        console.print("[yellow]History is empty[/yellow]")
        return

    table = Table(title="Clipboard History", box=box.ROUNDED)
    table.add_column("Index", style="cyan", justify="right")
    table.add_column("Preview", style="white")
    table.add_column("Length", style="magenta")
    table.add_column("Time", style="green")

    for i, item in enumerate(history[:15]):
        preview = item["text"][:40].replace("\n", " ")
        table.add_row(str(i), preview, str(item["length"]), item["time"])

    console.print(table)


def copy_clip(index):
    history = load_history()
    try:
        item = history[index]
        pyperclip.copy(item["text"])
        console.print(f"[green]✔ Copied:[/green] {item['text'][:50]}")
    except:
        console.print("[red]Invalid index[/red]")


def delete_clip(index):
    history = load_history()
    try:
        removed = history.pop(index)
        save_history(history)
        console.print(f"[red]✖ Deleted:[/red] {removed['text'][:50]}")
    except:
        console.print("[red]Invalid index[/red]")


def clear_history():
    save_history([])
    console.print("[red]All history cleared![/red]")


# =========================
# Advanced Features
# =========================

def search_clip(keyword):
    history = load_history()
    results = [item for item in history if keyword.lower() in item['text'].lower()]

    if not results:
        console.print("[yellow]No results found[/yellow]")
        return

    table = Table(title=f"Search results: {keyword}", box=box.SIMPLE)
    table.add_column("Index")
    table.add_column("Text")

    for i, item in enumerate(results[:10]):
        table.add_row(str(i), item['text'][:60])

    console.print(table)


def stats():
    history = load_history()

    total = len(history)
    total_chars = sum(len(item['text']) for item in history)

    console.print(Panel(f"""
[cyan]Total items:[/cyan] {total}
[magenta]Total characters:[/magenta] {total_chars}
"""))


def export_txt(filename="quickclip_export.txt"):
    history = load_history()

    with open(filename, "w", encoding="utf-8") as f:
        for item in history:
            f.write(f"[{item['time']}]\n{item['text']}\n\n")

    console.print(f"[green]Exported to {filename}[/green]")


def import_txt(filename):
    if not os.path.exists(filename):
        console.print("[red]File not found[/red]")
        return

    with open(filename, "r", encoding="utf-8") as f:
        content = f.read()

    save_clip(content)
    console.print("[green]Import successful[/green]")


# =========================
# Interactive Mode
# =========================

def interactive():
    console.print(Panel("[bold cyan]QuickClip Interactive Mode[/bold cyan]"))

    while True:
        cmd = Prompt.ask("[yellow]Command[/yellow]")

        if cmd == "exit":
            break
        elif cmd == "list":
            list_clips()
        elif cmd.startswith("save "):
            save_clip(cmd[5:])
        elif cmd.startswith("copy "):
            copy_clip(int(cmd.split()[1]))
        elif cmd.startswith("delete "):
            delete_clip(int(cmd.split()[1]))
        elif cmd.startswith("search "):
            search_clip(cmd[7:])
        elif cmd == "stats":
            stats()
        elif cmd == "clear":
            clear_history()
        else:
            console.print("[red]Unknown command[/red]")


# =========================
# CLI Entry
# =========================

def main():
    args = sys.argv

    if len(args) < 2:
        console.print(Panel("""
[bold]QuickClip CLI[/bold]

Commands:
 save <text>
 list
 copy <index>
 delete <index>
 search <keyword>
 stats
 clear
 export
 import <file>
 interactive
"""))
        return

    cmd = args[1]

    if cmd == "save":
        save_clip(" ".join(args[2:]))
    elif cmd == "list":
        list_clips()
    elif cmd == "copy":
        copy_clip(int(args[2]))
    elif cmd == "delete":
        delete_clip(int(args[2]))
    elif cmd == "search":
        search_clip(" ".join(args[2:]))
    elif cmd == "stats":
        stats()
    elif cmd == "clear":
        clear_history()
    elif cmd == "export":
        export_txt()
    elif cmd == "import":
        import_txt(args[2])
    elif cmd == "interactive":
        interactive()
    else:
        console.print("[red]Unknown command[/red]")


if __name__ == "__main__":
    main()
