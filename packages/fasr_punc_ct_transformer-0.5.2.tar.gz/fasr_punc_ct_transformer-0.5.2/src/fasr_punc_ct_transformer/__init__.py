from fasr_punc_ct_transformer.ct_transformer import CTTransformerForPunc

__all__ = [
    "CTTransformerForPunc",
]
