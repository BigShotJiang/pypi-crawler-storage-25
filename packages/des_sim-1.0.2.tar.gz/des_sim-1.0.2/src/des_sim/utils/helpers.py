'''
This file will have a few helper functions, used accros this repo.
'''
import csv
import os
import numpy as np
import pandas as pd
from tqdm import tqdm


def safe_get(lst, index, default=None):
        """Return lst[index] if it exists, else return default."""
        try:
            return lst[index]
        except IndexError:
            return default
        
def get_nested_attr(entity, attr): #Inspired from mosaik HWT model
    """
    Recursively access a nested attribute or dictionary key.

    Args:
        entity (object | dict): The root object or dictionary to access.
        attr (str): A dot-separated string representing the path 
                    (e.g. "tank_connections.tank1.heat_out2_F").

    Returns:
        Any: The value of the nested attribute or key.

    Raises:
        RuntimeError: If any part of the path is missing in the object/dict.
    """
    attr_parts = attr.split('.')
    val = entity
    
    #The following have been added only to allow for the debug ethod in hotwater tank:(
    if hasattr(entity, 'tankno'): #checking if it's a tank
        if attr_parts[0] in entity.sensors:
            return getattr(entity.sensors[attr_parts[0]],
                    attr_parts[1])
        elif attr_parts[0] in entity.connections:
            return float(getattr(entity.connections[attr_parts[0]],
                    attr_parts[1]))
        elif attr_parts[0] in entity.heating_rods:
            return getattr(entity.heating_rods[attr_parts[0]],
                    attr_parts[1])
    #-------------------------------------------------
    #The actual stuff:
    for level in attr_parts:
        try:
            val = val[level] if isinstance(val, dict) else getattr(val, level)
        except (KeyError, AttributeError) as e:
            raise RuntimeError(f'Missing {level} in {val}') from e
    
    
    return val

def set_nested_attr(entity, attr, val): 
    """
    Recursively set a nested attribute or dictionary key.

    Args:
        entity (object | dict): The root object or dictionary to modify.
        attr (str): A dot-separated string representing the path 
                    (e.g. "tank_connections.tank1.heat_out2_F").
        val (Any): The value to set.

    Raises:
        RuntimeError: If any part of the path (except the last) 
                    is missing in the object/dict.
    """
    
    attr_parts = attr.split('.')
    for level in attr_parts[:-1]:
        try:
            entity = entity[level] if isinstance(entity, dict) else getattr(entity, level)
        except (KeyError, AttributeError) as e:
            raise RuntimeError(f'Missing {level} in {entity}') from e
    if isinstance(entity, dict):
        entity[attr_parts[-1]] = val
    else:
        setattr(entity, attr_parts[-1], val)

def flatten_attrs(entity, attrs):
    flat_keys = []
    for attr in attrs:
            value = getattr(entity, attr)   # get the actual object
            if isinstance(value, dict):
                for key, val in value.items():
                    if isinstance(val, dict):  # nested dict case
                        for subkey in val.keys():
                            flat_keys.append(f"{attr}.{key}.{subkey}")
                    else:
                        flat_keys.append(f"{attr}.{key}")
            else:
                flat_keys.append(attr)

    return flat_keys


def debug_trace(time, attrs, entity, filename = 'debug_Log.csv', debug_log = {}, print_csv  = True, keyword = '', cycle = 0):
    # Instead of passing debug_log each time, we can make it persistent using function attribute
    
    step_size = 900
    print_freq = 50 # After how many steps, debug csv printed

    model = filename.strip('_trace.csv')
     # initialize persistent variable
    if not hasattr(debug_trace, "last_time"):
        debug_trace.last_time = time  # first call initializes it  
    

    if not debug_log:
        debug_log = {}
        debug_log[model+'time'] = []
        debug_log[model+'cycle'] = [] # to keep track of subcycles in event-based sim
    # inputs received in form of a dict, with attr name and val
    if isinstance(attrs, dict):
        for attr, v in attrs.items():
            for _, val in v.items():
                if attr+keyword not in debug_log.keys():
                    debug_log[attr+keyword] = []
                debug_log[model+'time'].append(time)
                debug_log[model+'cycle'].append(cycle)
                debug_log[attr+keyword].append(val)
    
    elif isinstance(attrs, list):
        for attr in attrs:
            # attr = attr+keyword #to distinguish input and output
            if attr+keyword not in debug_log.keys():
                debug_log[attr+keyword] = []

            debug_log[model+'time'].append(time)
            debug_log[model+'cycle'].append(cycle)
            debug_log[attr+keyword].append(get_nested_attr(entity, attr))
            if not print_csv:
                if time != debug_trace.last_time:
                    tqdm.write(f'Clearing screen -----\n---------------------------------\n')
                    # os.system('cls' if os.name == 'nt' else 'clear')
                tqdm.write(f'time:{time}, last_time:{debug_trace.last_time}')
                tqdm.write(f'attr: {attr}, val : {get_nested_attr(entity, attr)}')
            debug_trace.last_time = time
    # print(debug_log)
            

    path = os.getcwd()     
    filepath = os.path.join(os.getcwd(), filename)
    if print_csv:
        if time % (step_size*print_freq) == 0 or time > 7560000:
            # tqdm.write('printing debug csv')
            with open(filepath, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=debug_log.keys())
                writer.writeheader()
                for row in zip(*debug_log.values()):
                    writer.writerow(dict(zip(debug_log.keys(), row)))


    return debug_log

def calc_energy(vars, step_size): 

    '''
    
    Calculate energy in Wh from power in W and time step in seconds.
    vars: nested List, pandas series or dataframe only!!!
    step_size: in seconds
    returns absolute value of energy in Wh
    '''
    if isinstance(vars, (pd.Series, pd.DataFrame)):
        return vars.sum() * step_size/3600
    for i in range(len(vars)):
        if isinstance(vars[i], (int, float)):
            vars[i] = 0
        elif isinstance(vars[i], list):
            vars[i] = sum(vars[i]) * step_size/3600
        else :
            # so, pandas series
            vars[i] = vars[i].sum() * step_size/3600 
    
    return np.abs(vars)

def flatten_keys(obj, attr_list):
    # Flatten dict attributes
    flat_keys = []
    for attr in attr_list:
        value = getattr(obj, attr)   # get the actual object
        if isinstance(value, dict):
                for key, val in value.items():
                    if isinstance(val, dict):  # nested dict case
                        for subkey in val.keys():
                            flat_keys.append(f"{attr}.{key}.{subkey}")
                    else:
                        flat_keys.append(f"{attr}.{key}")


#wouldn't work
# def flat_keys(obj, attr_list): 
#     for n,attr in enumerate(attr_list):
#         get = get_nested_attr(obj, attr)
#         if isinstance(get, dict):
#             for k, _ in get.items():
#                 attr_list[n] = f"{get}.{k}"
#             flat_keys(obj, attr_list)
#     return attr_list

def rename_cols(df):
    columns = {}
    for col in df.columns:
        attr = col.rsplit('-', 1)[1] if '-' in col else col
        # attr = attr.split('.')[1] if '.' in attr else attr
        entity = col.split('.', 1)[0].replace('Sim', '') if '.' in col else ''
        entity = entity.replace('sim_v2', '')
        # entity = 
        new_col = f"{entity}_{attr}" 
        columns[col] = new_col
    return columns

def tqd_write(msg, debug = False):
    '''
    write a message to the tqdm output if debug is True; better than checking if it's true each time.
    debug can be overwritten, as per need
    '''
    if debug:
        tqdm.write(msg)


def collect_data(entity = '', data={}, finalize=False):
    '''
    Collect data from entity attributes over time.
    attrs: dict with attr names as keys and lists as values to store data
    finalize: if True, convert the dictionary to a dataframe and saves as csv
    '''
    if not hasattr(collect_data, 'storage'):
        collect_data.storage = {} # Function attribute, persistent across calls

    if len(data) > 0:
        for attr in data.keys():
            col_name = f'{entity}.{attr}'
            if col_name not in collect_data.storage:
                collect_data.storage[col_name] = []
            collect_data.storage[col_name].append(data[attr])
    


    if finalize:
        for k,v in collect_data.storage.items():
            tqdm.write(f'{k}, {len(v)}')
        data = pd.DataFrame(collect_data.storage)
        filename = f'additional_sim_data.csv'
        data.to_csv(filename)
        tqdm.write(f'Data saved to {filename}')
        collect_data.storage = {}  # Reset storage after saving
