"""Seeknal Ask tool registry — collects all tools into a pydantic-ai FunctionToolset."""

from pydantic_ai.toolsets import FunctionToolset

from seeknal.ask.agents.tools.apply_draft import apply_draft
from seeknal.ask.agents.tools.ask_user_tool import ask_user
from seeknal.ask.agents.tools.bootstrap_semantic_model import bootstrap_semantic_model
from seeknal.ask.agents.tools.check_ingestion_drift import check_ingestion_drift
from seeknal.ask.agents.tools.describe_table import describe_table
from seeknal.ask.agents.tools.draft_node import draft_node
from seeknal.ask.agents.tools.dry_run_draft import dry_run_draft
from seeknal.ask.agents.tools.edit_node import edit_node
from seeknal.ask.agents.tools.edit_proof_document import edit_proof_document
from seeknal.ask.agents.tools.execute_python import execute_python
from seeknal.ask.agents.tools.execute_sql import execute_sql
from seeknal.ask.agents.tools.extract_from_image import extract_from_image
from seeknal.ask.agents.tools.generate_report import generate_report
from seeknal.ask.agents.tools.get_entities import get_entities
from seeknal.ask.agents.tools.get_entity_schema import get_entity_schema
from seeknal.ask.agents.tools.inspect_output import inspect_output
from seeknal.ask.agents.tools.list_tables import list_tables
from seeknal.ask.agents.tools.open_in_browser import open_in_browser
from seeknal.ask.agents.tools.parse_record import parse_record
from seeknal.ask.agents.tools.plan_pipeline import plan_pipeline
from seeknal.ask.agents.tools.profile_data import profile_data
from seeknal.ask.agents.tools.propose_record_table import propose_record_table
from seeknal.ask.agents.tools.publish_to_proof import publish_to_proof
from seeknal.ask.agents.tools.publish_to_seeknal_report import publish_to_seeknal_report
from seeknal.ask.agents.tools.query_metric import query_metric
from seeknal.ask.agents.tools.read_pipeline import read_pipeline
from seeknal.ask.agents.tools.read_tabular import read_tabular
from seeknal.ask.agents.tools.read_proof_document import read_proof_document
from seeknal.ask.agents.tools.read_project_file import read_project_file
from seeknal.ask.agents.tools.run_pipeline import run_pipeline
from seeknal.ask.agents.tools.save_ingestion_skill import save_ingestion_skill
from seeknal.ask.agents.tools.save_metric import save_metric
from seeknal.ask.agents.tools.save_report_exposure import save_report_exposure
from seeknal.ask.agents.tools.search_pipelines import search_pipelines
from seeknal.ask.agents.tools.search_project_files import search_project_files
from seeknal.ask.agents.tools.show_lineage import show_lineage
from seeknal.ask.agents.tools.submit_plan import submit_plan
from seeknal.ask.agents.tools.write_ingested_table import write_ingested_table


def create_ask_toolset() -> FunctionToolset:
    """Create the seeknal-ask toolset with all tools registered."""
    return FunctionToolset(
        tools=[
            # Data discovery & querying
            execute_sql,
            list_tables,
            describe_table,
            get_entities,
            get_entity_schema,
            # Pipeline reading
            read_pipeline,
            search_pipelines,
            search_project_files,
            read_project_file,
            # Analysis & reporting
            execute_python,
            generate_report,
            open_in_browser,
            save_report_exposure,
            publish_to_proof,
            publish_to_seeknal_report,
            read_proof_document,
            edit_proof_document,
            # Pipeline building
            draft_node,
            dry_run_draft,
            apply_draft,
            edit_node,
            run_pipeline,
            plan_pipeline,
            show_lineage,
            inspect_output,
            profile_data,
            # Semantic layer
            bootstrap_semantic_model,
            query_metric,
            save_metric,
            # Agent workflow
            submit_plan,
            ask_user,
            # Data ingestion
            read_tabular,
            write_ingested_table,
            save_ingestion_skill,
            check_ingestion_drift,
            # Record entry (text + image)
            parse_record,
            extract_from_image,
            propose_record_table,
        ],
        id="seeknal-ask",
    )
