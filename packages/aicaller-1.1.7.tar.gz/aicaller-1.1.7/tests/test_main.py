# -*- coding: UTF-8 -*-
"""
Regression tests for the CLI entrypoint.
"""
import json
import tempfile
from pathlib import Path
from unittest import TestCase
from unittest.mock import call, patch

from aicaller.__main__ import batch_stats


class FakeEncoding:

    def encode(self, text, allowed_special="all"):
        return list(text)


class FakeTqdm:

    instances = []

    def __init__(self, iterable, **kwargs):
        self.iterable = iterable
        self.kwargs = kwargs
        self.postfixes = []
        FakeTqdm.instances.append(self)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def __iter__(self):
        return iter(self.iterable)

    def set_postfix(self, **kwargs):
        self.postfixes.append(kwargs)


class TestBatchStatsFallbackWarning(TestCase):

    def test_warns_once_per_unknown_model(self):
        records = [
            {"body": {"model": "unknown-model-a", "messages": [{"content": "hello"}]}},
            {"body": {"model": "unknown-model-a", "messages": [{"content": "world"}]}},
            {"body": {"model": "unknown-model-b", "messages": [{"content": "!"}]}},
        ]

        with tempfile.NamedTemporaryFile("w", delete=False, encoding="utf-8") as f:
            for record in records:
                f.write(json.dumps(record) + "\n")
            path = Path(f.name)

        try:
            with patch("aicaller.__main__.tiktoken.encoding_for_model", side_effect=KeyError), \
                 patch("aicaller.__main__.tiktoken.get_encoding", return_value=FakeEncoding()), \
                 self.assertLogs(level="WARNING") as cm:
                batch_stats(type("Args", (), {"file": str(path)})())

            warnings = [msg for msg in cm.output if "falling back to o200k_base for token counting" in msg]
            self.assertEqual(2, len(warnings))
            self.assertTrue(any("unknown-model-a" in msg for msg in warnings))
            self.assertTrue(any("unknown-model-b" in msg for msg in warnings))
        finally:
            path.unlink(missing_ok=True)


class TestBatchStatsProgressBar(TestCase):

    def test_reports_token_count_on_sample_progress_bar(self):
        FakeTqdm.instances = []
        records = [
            {"body": {"model": "gpt-4o", "messages": [{"content": "hi"}]}},
            {"body": {"model": "gpt-4o", "messages": [{"content": "abc"}, {"content": "de"}]}} ,
        ]

        with tempfile.NamedTemporaryFile("w", delete=False, encoding="utf-8") as f:
            for record in records:
                f.write(json.dumps(record) + "\n")
            path = Path(f.name)

        try:
            with patch("aicaller.__main__.tiktoken.encoding_for_model", return_value=FakeEncoding()), \
                 patch("aicaller.__main__.print_batch_stats") as mock_print_batch_stats, \
                 patch("aicaller.__main__.tqdm", side_effect=FakeTqdm):
                batch_stats(type("Args", (), {"file": str(path)})())

            self.assertEqual(1, len(FakeTqdm.instances))
            bar = FakeTqdm.instances[0]
            self.assertEqual("Processing samples", bar.kwargs["desc"])
            self.assertEqual("sample", bar.kwargs["unit"])
            self.assertEqual([{"tokens": 2}, {"tokens": 5}], bar.postfixes)
            mock_print_batch_stats.assert_has_calls([call([2, 5]), call([2, 3, 2])])
        finally:
            path.unlink(missing_ok=True)


