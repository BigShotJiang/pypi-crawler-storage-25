from enum import Enum
from numpy import ndarray
from typing import Literal, Optional, Union


def calc_descriptive_stats(
    arr: ndarray,
    stats_definition: Union[Enum, str] = None,
    axis: Optional[Literal[0, 1]] = None,
    with_distribution: bool = False,
) -> dict:
    """
    Calculate the descriptive stats for an array row-wise, and return them formatted for a HESTIA node.

    If input array is collapsed into a single value (i.e., axis = `None`), descriptive stats will be returned as scalar
    ints and floats. If values are calculated column-wise (i.e., axis = `0`) or row-wise (i.e., axis = `1`),
    descriptive stats will be returned as lists of ints and floats.

    If `with_distribution` = `True`, results will include the array used to calculate descriptive stats.

    Parameters
    ----------
    arr : ndarray
    stats_definition : Enum | str
    axis : 0 | 1 | None, default: `None`
    with_distribution : bool, default: `False

    Returns
    -------
    dict
        A dictionary of descriptive stats: `value` (mean), `sd`, `min`, `max`, `observations`, `statsDefinition`
        (optional), `distribution` (i.e., raw samples used to calculate stats, optional).
    """
    value: ndarray = arr.mean(axis=axis)
    sd: ndarray = arr.std(axis=axis)
    min_: ndarray = arr.min(axis=axis)
    max_: ndarray = arr.max(axis=axis)

    observations = (
        arr.size
        if axis is None
        else (
            [arr.shape[0]] * arr.shape[1]
            if axis == 0
            else [arr.shape[1]] * arr.shape[0]
        )
    )

    statsDefinition_value = (
        stats_definition.value
        if isinstance(stats_definition, Enum)
        else stats_definition
    )

    statsDefinition_dict = (
        {"statsDefinition": statsDefinition_value}
        if isinstance(statsDefinition_value, str)
        else {}
    )

    distribution_dict = (
        {
            "distribution": (
                arr.flatten() if axis is None else arr.T if axis == 0 else arr
            )
        }
        if with_distribution
        else {}
    )

    return {
        "value": value.tolist(),
        "sd": sd.tolist(),
        "min": min_.tolist(),
        "max": max_.tolist(),
        "observations": observations,
        **statsDefinition_dict,
        **distribution_dict,
    }
