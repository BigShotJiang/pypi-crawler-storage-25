from hestia_earth.utils.tools import to_precision
import numpy as np

_PERCENTILES = [10, 90]


def _percentile_key(percentile: int):
    return f"percentile{percentile}th"


def percentiles_keys():
    return list(map(_percentile_key, _PERCENTILES))


def _percentiles(distribution: list):
    values = np.percentile(distribution, _PERCENTILES)
    return {
        _percentile_key(percentile): to_precision(float(value))
        for percentile, value in zip(_PERCENTILES, values)
    }


def generate_percentiles(distribution: list):
    return (
        _percentiles(distribution)
        if len(distribution)
        > len(_PERCENTILES)  # only generate with more than 2 values
        and not all(
            [v == 0 for v in distribution]
        )  # do not generate if all distribution values are `0`
        else {}
    )
