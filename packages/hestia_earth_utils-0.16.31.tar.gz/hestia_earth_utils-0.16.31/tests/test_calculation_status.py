import os
import json

from tests.utils import fixtures_path
from hestia_earth.utils.calculation_status import _emissions_with_status

fixtures_folder = os.path.join(fixtures_path, "calculation_status")


def test_emissions_with_status():
    with open(os.path.join(fixtures_folder, "nodes.json")) as f:
        nodes = json.load(f)

    result = _emissions_with_status(nodes[0])
    assert result == {
        "emissions-total": 185,
        "emissions-complete": 55,
        "emissions-incomplete": 1,
        "emissions-missing": 129,
        "emissions": result["emissions"],  # ignore
    }

    result = _emissions_with_status(nodes[1])
    assert result == {
        "emissions-total": 185,
        "emissions-complete": 0,
        "emissions-incomplete": 13,
        "emissions-missing": 172,
        "emissions": result["emissions"],  # ignore
    }
