import pytest

from hestia_earth.utils.percentiles import generate_percentiles


@pytest.mark.parametrize(
    "distribution,expected",
    [
        (list(range(1, 1001)), {"percentile10th": 101, "percentile90th": 900}),
        ([], {}),
        ([0, 0, 0, 0], {}),
    ],
)
def test_generate_percentiles(distribution: list, expected: dict):
    result = generate_percentiles(distribution)
    assert result == expected
