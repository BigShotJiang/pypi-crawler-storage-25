from numpy import array, array_equal
from pytest import mark
from hestia_earth.schema import MeasurementStatsDefinition

from hestia_earth.utils.descriptive_stats import calc_descriptive_stats

EXPECTED_FLATTENED = {
    "value": 5,
    "sd": 2.581988897471611,
    "min": 1,
    "max": 9,
    "statsDefinition": "simulated",
    "observations": 9,
}

EXPECTED_COLUMNWISE = {
    "value": [4, 5, 6],
    "sd": [2.449489742783178, 2.449489742783178, 2.449489742783178],
    "min": [1, 2, 3],
    "max": [7, 8, 9],
    "statsDefinition": "simulated",
    "observations": [3, 3, 3],
}

EXPECTED_ROWWISE = {
    "value": [2, 5, 8],
    "sd": [0.816496580927726, 0.816496580927726, 0.816496580927726],
    "min": [1, 4, 7],
    "max": [3, 6, 9],
    "statsDefinition": "simulated",
    "observations": [3, 3, 3],
}


@mark.parametrize(
    "axis, expected",
    [(None, EXPECTED_FLATTENED), (0, EXPECTED_COLUMNWISE), (1, EXPECTED_ROWWISE)],
    ids=["flattened", "columnwise", "rowwise"],
)
@mark.parametrize(
    "stats_definition",
    [MeasurementStatsDefinition.SIMULATED, "simulated"],
    ids=["Enum", "str"],
)
def test_calc_descriptive_stats(stats_definition, axis, expected):
    SAMPLES = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    ARR = array(SAMPLES)

    result = calc_descriptive_stats(ARR, stats_definition, axis=axis)
    assert result == expected


EXPECTED_FLATTENED_WITH_DISTRIBUTION = {
    "value": 5,
    "sd": 2.581988897471611,
    "min": 1,
    "max": 9,
    "observations": 9,
    "distribution": array([1, 2, 3, 4, 5, 6, 7, 8, 9]),
}

EXPECTED_COLUMNWISE_WITH_DISTRIBUTION = {
    "value": [4, 5, 6],
    "sd": [2.449489742783178, 2.449489742783178, 2.449489742783178],
    "min": [1, 2, 3],
    "max": [7, 8, 9],
    "observations": [3, 3, 3],
    "distribution": array([[1, 4, 7], [2, 5, 8], [3, 6, 9]]),
}

EXPECTED_ROWWISE_WITH_DISTRIBUTION = {
    "value": [2, 5, 8],
    "sd": [0.816496580927726, 0.816496580927726, 0.816496580927726],
    "min": [1, 4, 7],
    "max": [3, 6, 9],
    "observations": [3, 3, 3],
    "distribution": array([[1, 2, 3], [4, 5, 6], [7, 8, 9]]),
}


@mark.parametrize(
    "axis, expected",
    [
        (None, EXPECTED_FLATTENED_WITH_DISTRIBUTION),
        (0, EXPECTED_COLUMNWISE_WITH_DISTRIBUTION),
        (1, EXPECTED_ROWWISE_WITH_DISTRIBUTION),
    ],
    ids=["flattened", "columnwise", "rowwise"],
)
def test_calc_descriptive_stats_with_distribution(axis, expected):
    SAMPLES = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    ARR = array(SAMPLES)

    result = calc_descriptive_stats(ARR, axis=axis, with_distribution=True)
    assert array_equal(result.pop("distribution"), expected.pop("distribution"))
    assert result == expected
