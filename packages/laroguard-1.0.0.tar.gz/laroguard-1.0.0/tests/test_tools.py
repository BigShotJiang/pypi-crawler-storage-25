"""
Tests for the Tools resource (sync + async).

Run with:  pytest tests/test_tools.py -v
"""
from __future__ import annotations

import json

import pytest
import respx
from httpx import Response

from laroguard import (
    AsyncLaroGuard,
    LaroGuard,
    SecurityBlockError,
)


BASE_URL = "http://localhost:8000"
API_KEY = "test-api-key"

_ALLOW_ANALYSIS = {
    "decision": "ALLOW",
    "risk_score": 5,
    "threat_category": "",
    "reason": "No threats detected",
    "detected_patterns": [],
    "confidence": 0.0,
}

_BLOCK_ANALYSIS = {
    "decision": "BLOCK",
    "risk_score": 90,
    "threat_category": "command_injection",
    "reason": "Dangerous shell command detected",
    "detected_patterns": ["rm -rf"],
    "confidence": 0.97,
}

_PROXY_ALLOW = {
    "decision": "ALLOW",
    "risk_score": 5,
    "reason": "Tool executed successfully",
    "result": {"stdout": "file1.txt\nfile2.txt", "exit_code": 0},
}

_PROXY_BLOCK = {
    "detail": {
        "error": "Security policy violation",
        "reason": "Dangerous tool invocation blocked",
        "risk_score": 90,
    }
}


class TestToolsAnalyze:
    @respx.mock(base_url=BASE_URL)
    def test_safe_tool_returns_allow(self, respx_mock):
        respx_mock.post("/v1/security/analyze-tool").mock(
            return_value=Response(200, json=_ALLOW_ANALYSIS)
        )
        lg = LaroGuard(api_key=API_KEY, base_url=BASE_URL)
        result = lg.tools.analyze(
            tool="list_files",
            arguments={"path": "/home/user"},
            origin_prompt="Show me my files",
        )

        assert result.decision == "ALLOW"
        assert result.risk_score == 5
        assert result.threat_category == ""

    @respx.mock(base_url=BASE_URL)
    def test_dangerous_tool_returns_block(self, respx_mock):
        respx_mock.post("/v1/security/analyze-tool").mock(
            return_value=Response(200, json=_BLOCK_ANALYSIS)
        )
        lg = LaroGuard(api_key=API_KEY, base_url=BASE_URL)
        result = lg.tools.analyze(
            tool="execute_shell_command",
            arguments={"command": "rm -rf /"},
        )

        assert result.decision == "BLOCK"
        assert result.risk_score == 90
        assert result.threat_category == "command_injection"
        assert "rm -rf" in result.detected_patterns
        assert result.confidence == 0.97

    @respx.mock(base_url=BASE_URL)
    def test_origin_prompt_included_in_payload(self, respx_mock):
        route = respx_mock.post("/v1/security/analyze-tool").mock(
            return_value=Response(200, json=_ALLOW_ANALYSIS)
        )
        lg = LaroGuard(api_key=API_KEY, base_url=BASE_URL)
        lg.tools.analyze(
            tool="read_file",
            arguments={"path": "/etc/passwd"},
            origin_prompt="Read the password file",
        )

        sent = json.loads(route.calls[0].request.content)
        assert sent["origin_prompt"] == "Read the password file"
        assert sent["tool"] == "read_file"

    @respx.mock(base_url=BASE_URL)
    def test_no_origin_prompt_omitted_from_payload(self, respx_mock):
        route = respx_mock.post("/v1/security/analyze-tool").mock(
            return_value=Response(200, json=_ALLOW_ANALYSIS)
        )
        lg = LaroGuard(api_key=API_KEY, base_url=BASE_URL)
        lg.tools.analyze(tool="list_files", arguments={"path": "/tmp"})

        sent = json.loads(route.calls[0].request.content)
        assert "origin_prompt" not in sent


class TestToolsRun:
    @respx.mock(base_url=BASE_URL)
    def test_proxy_allow_returns_result(self, respx_mock):
        respx_mock.post("/v1/tool-proxy/run").mock(
            return_value=Response(200, json=_PROXY_ALLOW)
        )
        lg = LaroGuard(api_key=API_KEY, base_url=BASE_URL)
        result = lg.tools.run(
            tool="list_files",
            arguments={"path": "/home/user"},
        )

        assert result.decision == "ALLOW"
        assert result.result is not None
        assert result.result["exit_code"] == 0

    @respx.mock(base_url=BASE_URL)
    def test_proxy_block_raises_security_block_error(self, respx_mock):
        respx_mock.post("/v1/tool-proxy/run").mock(
            return_value=Response(429, json=_PROXY_BLOCK)
        )
        lg = LaroGuard(api_key=API_KEY, base_url=BASE_URL)

        with pytest.raises(SecurityBlockError) as exc_info:
            lg.tools.run(
                tool="execute_shell_command",
                arguments={"command": "rm -rf /"},
            )

        err = exc_info.value
        assert err.risk_score == 90

    @respx.mock(base_url=BASE_URL)
    def test_proxy_optional_params_sent(self, respx_mock):
        route = respx_mock.post("/v1/tool-proxy/run").mock(
            return_value=Response(200, json=_PROXY_ALLOW)
        )
        lg = LaroGuard(api_key=API_KEY, base_url=BASE_URL)
        lg.tools.run(
            tool="fetch_url",
            arguments={"url": "https://example.com"},
            origin_prompt="Get the page content",
            tool_endpoint="https://tools.internal/fetch",
            mode="strict",
        )

        sent = json.loads(route.calls[0].request.content)
        assert sent["tool_endpoint"] == "https://tools.internal/fetch"
        assert sent["mode"] == "strict"
        assert sent["origin_prompt"] == "Get the page content"


class TestAsyncTools:
    @respx.mock(base_url=BASE_URL)
    @pytest.mark.asyncio
    async def test_async_analyze(self, respx_mock):
        respx_mock.post("/v1/security/analyze-tool").mock(
            return_value=Response(200, json=_ALLOW_ANALYSIS)
        )
        async with AsyncLaroGuard(api_key=API_KEY, base_url=BASE_URL) as lg:
            result = await lg.tools.analyze(
                tool="list_files",
                arguments={"path": "/home"},
            )
        assert result.decision == "ALLOW"

    @respx.mock(base_url=BASE_URL)
    @pytest.mark.asyncio
    async def test_async_run(self, respx_mock):
        respx_mock.post("/v1/tool-proxy/run").mock(
            return_value=Response(200, json=_PROXY_ALLOW)
        )
        async with AsyncLaroGuard(api_key=API_KEY, base_url=BASE_URL) as lg:
            result = await lg.tools.run(
                tool="list_files",
                arguments={"path": "/home"},
            )
        assert result.decision == "ALLOW"
        assert result.result["exit_code"] == 0
