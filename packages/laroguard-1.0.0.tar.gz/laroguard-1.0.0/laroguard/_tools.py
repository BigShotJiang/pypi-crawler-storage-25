"""
LaroGuard SDK — Tools resource.

Provides sync and async wrappers around:
  - POST /v1/security/analyze-tool   (analyse a tool call without executing it)
  - POST /v1/tool-proxy/run          (analyse AND execute a tool call)

Usage::

    from laroguard import LaroGuard

    lg = LaroGuard(api_key="your-key")

    # 1. Analyse a tool call before executing it yourself
    result = lg.tools.analyze(
        tool="execute_shell_command",
        arguments={"command": "ls /home"},
        origin_prompt="User asked to list their home directory",
    )
    if result.decision == "ALLOW":
        # run the tool yourself
        ...

    # 2. Let LaroGuard proxy the call (analyse + execute)
    proxy_result = lg.tools.run(
        tool="execute_shell_command",
        arguments={"command": "ls /home"},
        origin_prompt="User asked to list their home directory",
    )
    print(proxy_result.decision)  # ALLOW / WARN / BLOCK
    print(proxy_result.result)    # Actual tool output (if allowed)
"""
from __future__ import annotations

from typing import Any

from ._client import _Client
from ._async_client import _AsyncClient
from ._models import ToolAnalysisResult, ToolProxyResult

_ANALYZE_PATH = "/v1/security/analyze-tool"
_PROXY_PATH = "/v1/tool-proxy/run"


# ---------------------------------------------------------------------------
# Sync resource
# ---------------------------------------------------------------------------

class Tools:
    """Synchronous tools resource.  Obtained via ``LaroGuard.tools``."""

    def __init__(self, client: _Client) -> None:
        self._client = client

    def analyze(
        self,
        tool: str,
        arguments: dict[str, Any],
        origin_prompt: str | None = None,
    ) -> ToolAnalysisResult:
        """
        Analyse a tool call for security risks *without* executing it.

        Use this when you want to decide yourself whether to run the tool
        after receiving LaroGuard's verdict.

        Args:
            tool: Tool / function name (e.g. ``"execute_shell_command"``).
            arguments: The arguments dict that would be passed to the tool.
            origin_prompt: The user message that triggered this tool call.
                Providing it enables richer context analysis.

        Returns:
            :class:`~laroguard.ToolAnalysisResult` with ``decision``
            (``ALLOW`` / ``WARN`` / ``BLOCK``), ``risk_score``, and
            ``threat_category``.

        Raises:
            :class:`~laroguard.AuthenticationError`
            :class:`~laroguard.APIError`
            :class:`~laroguard.ConnectionError`
        """
        payload: dict[str, Any] = {"tool": tool, "arguments": arguments}
        if origin_prompt is not None:
            payload["origin_prompt"] = origin_prompt
        raw = self._client.post(_ANALYZE_PATH, payload)
        return ToolAnalysisResult._from_dict(raw)

    def run(
        self,
        tool: str,
        arguments: dict[str, Any],
        origin_prompt: str | None = None,
        *,
        tool_endpoint: str | None = None,
        mode: str | None = None,
    ) -> ToolProxyResult:
        """
        Analyse a tool call and, if approved, execute it through the
        LaroGuard proxy.

        Use this when you want the gateway to both check and run the tool.
        The ``result`` field of the returned object contains the tool's
        actual output (``None`` when the call is blocked).

        Args:
            tool: Tool / function name.
            arguments: Arguments to pass to the tool.
            origin_prompt: The user message that triggered this tool call.
            tool_endpoint: Custom endpoint URL for the tool (optional).
            mode: Execution mode override (optional, admin-configured).

        Returns:
            :class:`~laroguard.ToolProxyResult`

        Raises:
            :class:`~laroguard.SecurityBlockError`: Tool call was blocked.
            :class:`~laroguard.AuthenticationError`
            :class:`~laroguard.APIError`
            :class:`~laroguard.ConnectionError`
        """
        payload: dict[str, Any] = {"tool": tool, "arguments": arguments}
        if origin_prompt is not None:
            payload["origin_prompt"] = origin_prompt
        if tool_endpoint is not None:
            payload["tool_endpoint"] = tool_endpoint
        if mode is not None:
            payload["mode"] = mode
        raw = self._client.post(_PROXY_PATH, payload)
        return ToolProxyResult._from_dict(raw)


# ---------------------------------------------------------------------------
# Async resource
# ---------------------------------------------------------------------------

class AsyncTools:
    """Async tools resource.  Obtained via ``AsyncLaroGuard.tools``."""

    def __init__(self, client: _AsyncClient) -> None:
        self._client = client

    async def analyze(
        self,
        tool: str,
        arguments: dict[str, Any],
        origin_prompt: str | None = None,
    ) -> ToolAnalysisResult:
        """Async version of :meth:`Tools.analyze`."""
        payload: dict[str, Any] = {"tool": tool, "arguments": arguments}
        if origin_prompt is not None:
            payload["origin_prompt"] = origin_prompt
        raw = await self._client.post(_ANALYZE_PATH, payload)
        return ToolAnalysisResult._from_dict(raw)

    async def run(
        self,
        tool: str,
        arguments: dict[str, Any],
        origin_prompt: str | None = None,
        *,
        tool_endpoint: str | None = None,
        mode: str | None = None,
    ) -> ToolProxyResult:
        """Async version of :meth:`Tools.run`."""
        payload: dict[str, Any] = {"tool": tool, "arguments": arguments}
        if origin_prompt is not None:
            payload["origin_prompt"] = origin_prompt
        if tool_endpoint is not None:
            payload["tool_endpoint"] = tool_endpoint
        if mode is not None:
            payload["mode"] = mode
        raw = await self._client.post(_PROXY_PATH, payload)
        return ToolProxyResult._from_dict(raw)
