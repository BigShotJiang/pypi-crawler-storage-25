"""
LaroGuard Python SDK
====================

A lightweight, type-safe client for the LaroGuard AI security gateway.

Quick start::

    from laroguard import LaroGuard

    lg = LaroGuard(api_key="your-project-api-key")

    # Non-streaming chat
    response = lg.chat.create(
        messages=[{"role": "user", "content": "Hello!"}]
    )
    print(response.content)           # assistant reply
    print(response.security.decision) # ALLOW | WARN

    # Streaming chat
    for event in lg.chat.stream(messages=[{"role": "user", "content": "Tell me a story"}]):
        if event.type == "chunk":
            print(event.chunk.content, end="", flush=True)
        elif event.type == "done":
            print()
            print("Security decision:", event.security.decision)

    # RAG with document poisoning detection
    response = lg.rag.create(
        messages=[{"role": "user", "content": "What is this document about?"}],
        documents=[{"id": "d1", "content": "...retrieved text..."}],
    )

    # Tool security analysis
    result = lg.tools.analyze(tool="shell_exec", arguments={"cmd": "ls"})
    if result.decision == "ALLOW":
        ...  # run the tool yourself

Async usage::

    from laroguard import AsyncLaroGuard
    import asyncio

    async def main():
        async with AsyncLaroGuard(api_key="your-key") as lg:
            response = await lg.chat.create(
                messages=[{"role": "user", "content": "Hello!"}]
            )
            print(response.content)

    asyncio.run(main())
"""
from __future__ import annotations

from ._client import _Client, _DEFAULT_BASE_URL, _DEFAULT_TIMEOUT
from ._async_client import _AsyncClient
from ._chat import AsyncChat, Chat
from ._rag import AsyncRAG, RAG
from ._tools import AsyncTools, Tools

# Public models
from ._models import (
    ChatResponse,
    Choice,
    DocumentResult,
    Message,
    RAGAnalysisResult,
    SecurityMetadata,
    StreamChunk,
    StreamEvent,
    StreamRedaction,
    StreamSecuritySummary,
    ToolAnalysisResult,
    ToolProxyResult,
    Usage,
)

# Public exceptions
from ._exceptions import (
    APIError,
    AuthenticationError,
    LaroGuardError,
    RAGPoisoningBlockError,
    RateLimitError,
    SecurityBlockError,
    StreamSecurityBlockError,
    ConnectionError as ConnectionError,  # noqa: A001
)

__version__ = "1.0.0"
__all__ = [
    # Main clients
    "LaroGuard",
    "AsyncLaroGuard",
    # Models
    "ChatResponse",
    "Choice",
    "DocumentResult",
    "Message",
    "RAGAnalysisResult",
    "SecurityMetadata",
    "StreamChunk",
    "StreamEvent",
    "StreamRedaction",
    "StreamSecuritySummary",
    "ToolAnalysisResult",
    "ToolProxyResult",
    "Usage",
    # Exceptions
    "LaroGuardError",
    "SecurityBlockError",
    "StreamSecurityBlockError",
    "RAGPoisoningBlockError",
    "RateLimitError",
    "AuthenticationError",
    "APIError",
    "ConnectionError",
]


class LaroGuard:
    """
    Synchronous LaroGuard client.

    Args:
        api_key: Your project API key from the LaroGuard dashboard.
        base_url: Gateway base URL.  Defaults to ``http://localhost:8000``.
            Change this in production to your deployed gateway URL.
        timeout: HTTP timeout in seconds (default 120 — LLM calls can be slow).

    Example::

        lg = LaroGuard(api_key="llm-fw-xxxx", base_url="https://gateway.example.com")

    Resources:
        - ``lg.chat``  → :class:`~laroguard._chat.Chat`
        - ``lg.rag``   → :class:`~laroguard._rag.RAG`
        - ``lg.tools`` → :class:`~laroguard._tools.Tools`
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        self._http = _Client(api_key=api_key, base_url=base_url, timeout=timeout)
        self.chat = Chat(self._http)
        self.rag = RAG(self._http)
        self.tools = Tools(self._http)

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> "LaroGuard":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class AsyncLaroGuard:
    """
    Async LaroGuard client for use with ``asyncio``, FastAPI, Tornado, etc.

    Args:
        api_key: Your project API key.
        base_url: Gateway base URL.
        timeout: HTTP timeout in seconds.

    Example::

        async with AsyncLaroGuard(api_key="llm-fw-xxxx") as lg:
            resp = await lg.chat.create(messages=[...])

    Resources:
        - ``lg.chat``  → :class:`~laroguard._chat.AsyncChat`
        - ``lg.rag``   → :class:`~laroguard._rag.AsyncRAG`
        - ``lg.tools`` → :class:`~laroguard._tools.AsyncTools`
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        self._http = _AsyncClient(api_key=api_key, base_url=base_url, timeout=timeout)
        self.chat = AsyncChat(self._http)
        self.rag = AsyncRAG(self._http)
        self.tools = AsyncTools(self._http)

    async def close(self) -> None:
        """Close the underlying async HTTP connection pool."""
        await self._http.close()

    async def __aenter__(self) -> "AsyncLaroGuard":
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()
