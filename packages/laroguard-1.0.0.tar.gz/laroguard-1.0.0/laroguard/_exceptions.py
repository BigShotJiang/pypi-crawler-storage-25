"""
LaroGuard SDK — Exception hierarchy.

All exceptions originate from LaroGuardError so callers can catch broadly
or selectively depending on their error-handling strategy.
"""
from __future__ import annotations

from typing import Any


class LaroGuardError(Exception):
    """Base class for all LaroGuard SDK exceptions."""

    def __init__(self, message: str, *, status_code: int | None = None, response_body: Any = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.args[0]!r})"


# ---------------------------------------------------------------------------
# Server-side security decisions
# ---------------------------------------------------------------------------

class SecurityBlockError(LaroGuardError):
    """
    Raised when the LaroGuard gateway blocks a request due to a security
    policy violation (HTTP 429 with a security body).

    Attributes:
        reason: Human-readable explanation of the block.
        risk_score: Numeric risk score that triggered the block (0-100).
    """

    def __init__(self, reason: str, risk_score: int, *, status_code: int = 429, response_body: Any = None) -> None:
        super().__init__(
            f"Request blocked by security policy: {reason} (risk_score={risk_score})",
            status_code=status_code,
            response_body=response_body,
        )
        self.reason = reason
        self.risk_score = risk_score


class RAGPoisoningBlockError(SecurityBlockError):
    """
    Raised when the RAG document analysis blocks a request due to
    malicious documents detected in the vector-store context.

    Attributes:
        malicious_documents: Number of malicious documents found.
    """

    def __init__(
        self,
        reason: str,
        risk_score: int,
        malicious_documents: int = 0,
        *,
        status_code: int = 429,
        response_body: Any = None,
    ) -> None:
        super().__init__(reason, risk_score, status_code=status_code, response_body=response_body)
        self.malicious_documents = malicious_documents


class StreamSecurityBlockError(SecurityBlockError):
    """
    Raised mid-stream when the output scanner blocks the response.
    Contains the partial content already received before the block.

    Attributes:
        partial_content: Text chunks received before the block was issued.
    """

    def __init__(
        self,
        reason: str,
        risk_score: int,
        partial_content: str = "",
        *,
        response_body: Any = None,
    ) -> None:
        super().__init__(reason, risk_score, status_code=429, response_body=response_body)
        self.partial_content = partial_content


# ---------------------------------------------------------------------------
# Transport / auth errors
# ---------------------------------------------------------------------------

class AuthenticationError(LaroGuardError):
    """Raised when the API key is missing, invalid, or revoked (HTTP 401)."""

    def __init__(self, message: str = "Invalid or missing API key.", *, response_body: Any = None) -> None:
        super().__init__(message, status_code=401, response_body=response_body)


class RateLimitError(LaroGuardError):
    """
    Raised when the gateway rate-limits the caller (HTTP 429 without a
    security-block body, i.e. the project has exceeded its request quota).
    """

    def __init__(self, message: str = "Rate limit exceeded.", *, response_body: Any = None) -> None:
        super().__init__(message, status_code=429, response_body=response_body)


class APIError(LaroGuardError):
    """
    Raised for unexpected server errors (HTTP 500) or unrecognised non-2xx
    responses.
    """

    def __init__(self, message: str, *, status_code: int | None = None, response_body: Any = None) -> None:
        super().__init__(message, status_code=status_code, response_body=response_body)


class ConnectionError(LaroGuardError):  # noqa: A001 — intentional shadow
    """Raised when the SDK cannot reach the LaroGuard gateway (network error)."""

    def __init__(self, message: str = "Could not connect to the LaroGuard gateway.") -> None:
        super().__init__(message)
