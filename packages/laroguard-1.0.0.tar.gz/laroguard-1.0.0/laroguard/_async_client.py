"""
LaroGuard SDK — Async HTTP client core.

Mirrors :mod:`laroguard._client` but uses ``httpx.AsyncClient`` and
``async for`` so it integrates naturally with asyncio / FastAPI / Tornado
applications.
"""
from __future__ import annotations

import json
from typing import Any, AsyncGenerator

import httpx

from ._exceptions import (
    APIError,
    AuthenticationError,
    LaroGuardError,
    RAGPoisoningBlockError,
    RateLimitError,
    SecurityBlockError,
    ConnectionError as LGConnectionError,
)

_DEFAULT_TIMEOUT = 120.0
_DEFAULT_BASE_URL = "http://localhost:8000"


class _AsyncClient:
    """Low-level async HTTP client.  Use :class:`laroguard.AsyncLaroGuard` instead."""

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._http = http_client or httpx.AsyncClient(
            base_url=self._base_url,
            timeout=timeout,
            headers={"X-API-Key": api_key, "Content-Type": "application/json"},
        )

    # ------------------------------------------------------------------
    # Error parsing (shared logic, identical to sync client)
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_error(response: httpx.Response) -> LaroGuardError:
        status = response.status_code
        try:
            body: Any = response.json()
        except Exception:
            body = response.text

        detail: Any = body.get("detail", body) if isinstance(body, dict) else body

        if status == 429 and isinstance(detail, dict):
            error_type = detail.get("error", "")
            reason = detail.get("reason", str(detail))
            risk_score = int(detail.get("risk_score", 0))

            if "RAG security" in error_type:
                return RAGPoisoningBlockError(
                    reason=reason,
                    risk_score=risk_score,
                    malicious_documents=int(detail.get("malicious_documents", 0)),
                    status_code=status,
                    response_body=body,
                )
            if "Security policy" in error_type or "security" in error_type.lower():
                return SecurityBlockError(
                    reason=reason,
                    risk_score=risk_score,
                    status_code=status,
                    response_body=body,
                )

        if status == 429:
            msg = detail if isinstance(detail, str) else str(detail)
            return RateLimitError(message=msg or "Rate limit exceeded.", response_body=body)

        if status == 401:
            msg = detail if isinstance(detail, str) else "Invalid or missing API key."
            return AuthenticationError(message=msg, response_body=body)

        msg = detail if isinstance(detail, str) else json.dumps(detail)
        return APIError(message=msg or f"Unexpected HTTP {status}", status_code=status, response_body=body)

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------

    async def post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            response = await self._http.post(path, json=payload)
        except httpx.ConnectError as exc:
            raise LGConnectionError() from exc
        except httpx.TimeoutException as exc:
            raise LGConnectionError(f"Request to {path} timed out.") from exc

        if response.is_success:
            return response.json()  # type: ignore[return-value]

        raise self._parse_error(response)

    async def stream_post(self, path: str, payload: dict[str, Any]) -> AsyncGenerator[str, None]:
        try:
            async with self._http.stream("POST", path, json=payload) as response:
                if not response.is_success:
                    await response.aread()
                    raise self._parse_error(response)
                async for line in response.aiter_lines():
                    yield line
        except httpx.ConnectError as exc:
            raise LGConnectionError() from exc
        except httpx.TimeoutException as exc:
            raise LGConnectionError(f"Streaming request to {path} timed out.") from exc
        except LaroGuardError:
            raise
        except Exception as exc:
            raise APIError(f"Async streaming error: {exc}") from exc

    async def close(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "_AsyncClient":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()
