"""
LaroGuard SDK — Chat resource.

Provides sync and async wrappers around:
  - POST /v1/chat/completions          (non-streaming)
  - POST /v1/chat/completions/stream   (SSE streaming)

Usage (sync)::

    from laroguard import LaroGuard

    lg = LaroGuard(api_key="your-key")
    response = lg.chat.create(messages=[{"role": "user", "content": "Hello"}])
    print(response.content)          # assistant text
    print(response.security.decision) # ALLOW / WARN

Usage (streaming)::

    for event in lg.chat.stream(messages=[{"role": "user", "content": "Tell me a story"}]):
        if event.type == "chunk":
            print(event.chunk.content, end="", flush=True)
        elif event.type == "done":
            print()
            print("Decision:", event.security.decision)

Usage (multimodal with image)::

    import base64, pathlib
    img_b64 = base64.b64encode(pathlib.Path("photo.png").read_bytes()).decode()
    response = lg.chat.create(messages=[
        {
            "role": "user",
            "content_parts": [
                {"type": "text", "text": "What is in this image?"},
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{img_b64}"}},
            ],
        }
    ])
"""
from __future__ import annotations

import json
from typing import Any, Generator, AsyncGenerator

from ._client import _Client
from ._async_client import _AsyncClient
from ._exceptions import StreamSecurityBlockError
from ._models import (
    ChatResponse,
    StreamChunk,
    StreamEvent,
    StreamRedaction,
    StreamSecuritySummary,
)

_CHAT_PATH = "/v1/chat/completions"
_STREAM_PATH = "/v1/chat/completions/stream"


# ---------------------------------------------------------------------------
# SSE parsing helpers (shared between sync and async)
# ---------------------------------------------------------------------------

def _parse_sse_line(line: str) -> dict[str, Any] | None:
    """
    Parse a single SSE ``data: ...`` line.

    Returns:
        Parsed dict, ``None`` if the line is ``[DONE]`` or should be ignored.
    """
    if not line.startswith("data: "):
        return None
    payload = line[len("data: "):]
    if payload.strip() == "[DONE]":
        return None
    try:
        return json.loads(payload)
    except json.JSONDecodeError:
        return None


def _sse_dict_to_event(data: dict[str, Any]) -> StreamEvent | None:
    """Convert a parsed SSE dict into a typed :class:`StreamEvent`."""
    event_type = data.get("type", "")

    if event_type == "chunk":
        return StreamEvent(
            type="chunk",
            chunk=StreamChunk(content=data.get("content", "")),
        )

    if event_type == "redacted":
        return StreamEvent(
            type="redacted",
            redaction=StreamRedaction(
                content=data.get("content", "[REDACTED]"),
                data_type=data.get("data_type", "unknown"),
            ),
        )

    if event_type == "done":
        return StreamEvent(
            type="done",
            security=StreamSecuritySummary._from_dict(data.get("security", {})),
        )

    if event_type == "security_block":
        # We raise here so the generator terminates cleanly and the caller
        # gets all partial content accumulated up to this point.
        # The caller is expected to pass accumulated content when catching.
        raise StreamSecurityBlockError(
            reason=data.get("reason", "Output security policy violated"),
            risk_score=int(data.get("risk_score", 0)),
            response_body=data,
        )

    if event_type == "error":
        from ._exceptions import APIError
        raise APIError(
            message=data.get("detail", "Unknown streaming error"),
            response_body=data,
        )

    return None  # unknown / future event type — silently ignore


# ---------------------------------------------------------------------------
# Sync resource
# ---------------------------------------------------------------------------

class Chat:
    """Synchronous chat resource.  Obtained via ``LaroGuard.chat``."""

    def __init__(self, client: _Client) -> None:
        self._client = client

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def create(
        self,
        messages: list[dict[str, Any]],
        *,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
    ) -> ChatResponse:
        """
        Send a chat request and return a complete :class:`~laroguard.ChatResponse`.

        Args:
            messages: List of message dicts.  Each dict must have a ``role``
                key (``"system"``, ``"user"``, or ``"assistant"``) and either a
                ``content`` string or a ``content_parts`` list for multimodal
                input (text + images).
            model: Override the default model.  Usually left unset — the
                project's admin-configured model is used automatically.
            temperature: Sampling temperature (0.0–2.0).
            max_tokens: Upper bound on generated tokens.
            user_id: Opaque end-user identifier for audit logs.
            session_id: Conversation session identifier for context tracking.

        Returns:
            :class:`~laroguard.ChatResponse` — check ``.security.decision``
            to distinguish ``ALLOW`` from ``WARN``.

        Raises:
            :class:`~laroguard.SecurityBlockError`: Gateway blocked the request.
            :class:`~laroguard.AuthenticationError`: Invalid API key.
            :class:`~laroguard.RateLimitError`: Project quota exceeded.
            :class:`~laroguard.APIError`: Unexpected server error.
            :class:`~laroguard.ConnectionError`: Gateway unreachable.
        """
        payload = _build_payload(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            user_id=user_id,
            session_id=session_id,
            stream=False,
        )
        raw = self._client.post(_CHAT_PATH, payload)
        return ChatResponse._from_dict(raw)

    def stream(
        self,
        messages: list[dict[str, Any]],
        *,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
    ) -> Generator[StreamEvent, None, None]:
        """
        Send a chat request and yield :class:`~laroguard.StreamEvent` objects
        as they arrive over the SSE stream.

        Example::

            partial = ""
            for event in lg.chat.stream(messages=[{"role": "user", "content": "..."}]):
                if event.type == "chunk":
                    partial += event.chunk.content
                    print(event.chunk.content, end="", flush=True)
                elif event.type == "redacted":
                    partial += event.redaction.content
                elif event.type == "done":
                    print()
                    security = event.security

        Args:
            messages: Same format as :meth:`create`.

        Yields:
            :class:`~laroguard.StreamEvent` — ``type`` is one of
            ``"chunk"``, ``"redacted"``, ``"done"``.

        Raises:
            :class:`~laroguard.StreamSecurityBlockError`: Output blocked
                mid-stream.
            :class:`~laroguard.SecurityBlockError`: Prompt blocked before
                streaming started.
        """
        payload = _build_payload(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            user_id=user_id,
            session_id=session_id,
            stream=True,
        )
        for raw_line in self._client.stream_post(_STREAM_PATH, payload):
            parsed = _parse_sse_line(raw_line)
            if parsed is None:
                continue
            event = _sse_dict_to_event(parsed)
            if event is not None:
                yield event


# ---------------------------------------------------------------------------
# Async resource
# ---------------------------------------------------------------------------

class AsyncChat:
    """Async chat resource.  Obtained via ``AsyncLaroGuard.chat``."""

    def __init__(self, client: _AsyncClient) -> None:
        self._client = client

    async def create(
        self,
        messages: list[dict[str, Any]],
        *,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
    ) -> ChatResponse:
        """Async version of :meth:`Chat.create`."""
        payload = _build_payload(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            user_id=user_id,
            session_id=session_id,
            stream=False,
        )
        raw = await self._client.post(_CHAT_PATH, payload)
        return ChatResponse._from_dict(raw)

    async def stream(
        self,
        messages: list[dict[str, Any]],
        *,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        user_id: str | None = None,
        session_id: str | None = None,
    ) -> AsyncGenerator[StreamEvent, None]:
        """Async version of :meth:`Chat.stream`."""
        payload = _build_payload(
            messages=messages,
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            user_id=user_id,
            session_id=session_id,
            stream=True,
        )
        async for raw_line in self._client.stream_post(_STREAM_PATH, payload):
            parsed = _parse_sse_line(raw_line)
            if parsed is None:
                continue
            event = _sse_dict_to_event(parsed)
            if event is not None:
                yield event


# ---------------------------------------------------------------------------
# Shared payload builder
# ---------------------------------------------------------------------------

def _build_payload(
    messages: list[dict[str, Any]],
    model: str | None,
    temperature: float | None,
    max_tokens: int | None,
    user_id: str | None,
    session_id: str | None,
    stream: bool,
) -> dict[str, Any]:
    payload: dict[str, Any] = {"messages": messages, "stream": stream}
    if model is not None:
        payload["model"] = model
    if temperature is not None:
        payload["temperature"] = temperature
    if max_tokens is not None:
        payload["max_tokens"] = max_tokens
    if user_id is not None:
        payload["user_id"] = user_id
    if session_id is not None:
        payload["session_id"] = session_id
    return payload
