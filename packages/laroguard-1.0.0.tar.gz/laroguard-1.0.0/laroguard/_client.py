"""
LaroGuard SDK — Synchronous HTTP client core.

Handles authentication, request dispatch, response parsing, and error
normalisation so that the resource classes (chat, rag, tools) only need
to supply the endpoint path and payload.
"""
from __future__ import annotations

import json
from typing import Any, Generator

import httpx

from ._exceptions import (
    APIError,
    AuthenticationError,
    LaroGuardError,
    RAGPoisoningBlockError,
    RateLimitError,
    SecurityBlockError,
    StreamSecurityBlockError,
    ConnectionError as LGConnectionError,
)

_DEFAULT_TIMEOUT = 120.0  # seconds — LLM calls can be slow
_DEFAULT_BASE_URL = "http://localhost:8000"


class _Client:
    """
    Low-level synchronous HTTP client.  Not meant to be used directly —
    use :class:`laroguard.LaroGuard` instead.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        http_client: httpx.Client | None = None,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._http = http_client or httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            headers={"X-API-Key": api_key, "Content-Type": "application/json"},
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        return {
            "X-API-Key": self._api_key,
            "Content-Type": "application/json",
        }

    @staticmethod
    def _parse_error(response: httpx.Response) -> LaroGuardError:
        """
        Convert a non-2xx httpx.Response into the appropriate SDK exception.

        The gateway serialises block events as HTTP 429 with a JSON body that
        contains ``error`` == ``"Security policy violation"`` *or*
        ``"RAG security policy violation"``.  Plain rate-limit 429s have a
        different body shape.
        """
        status = response.status_code
        try:
            body: Any = response.json()
        except Exception:
            body = response.text

        # Unwrap FastAPI's standard {"detail": ...} wrapper
        detail: Any = body.get("detail", body) if isinstance(body, dict) else body

        # ---- security blocks ------------------------------------------------
        if status == 429 and isinstance(detail, dict):
            error_type = detail.get("error", "")
            reason = detail.get("reason", str(detail))
            risk_score = int(detail.get("risk_score", 0))

            if "RAG security" in error_type:
                return RAGPoisoningBlockError(
                    reason=reason,
                    risk_score=risk_score,
                    malicious_documents=int(detail.get("malicious_documents", 0)),
                    status_code=status,
                    response_body=body,
                )
            if "Security policy" in error_type or "security" in error_type.lower():
                return SecurityBlockError(
                    reason=reason,
                    risk_score=risk_score,
                    status_code=status,
                    response_body=body,
                )

        # ---- rate limit (no security body) ----------------------------------
        if status == 429:
            msg = detail if isinstance(detail, str) else str(detail)
            return RateLimitError(message=msg or "Rate limit exceeded.", response_body=body)

        # ---- auth -----------------------------------------------------------
        if status == 401:
            msg = detail if isinstance(detail, str) else "Invalid or missing API key."
            return AuthenticationError(message=msg, response_body=body)

        # ---- everything else ------------------------------------------------
        msg = detail if isinstance(detail, str) else json.dumps(detail)
        return APIError(message=msg or f"Unexpected HTTP {status}", status_code=status, response_body=body)

    # ------------------------------------------------------------------
    # Public dispatch methods
    # ------------------------------------------------------------------

    def post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Perform a synchronous POST and return the parsed JSON body."""
        try:
            response = self._http.post(path, json=payload)
        except httpx.ConnectError as exc:
            raise LGConnectionError() from exc
        except httpx.TimeoutException as exc:
            raise LGConnectionError(f"Request to {path} timed out.") from exc

        if response.is_success:
            return response.json()  # type: ignore[return-value]

        raise self._parse_error(response)

    def stream_post(self, path: str, payload: dict[str, Any]) -> Generator[str, None, None]:
        """
        Perform a streaming POST and yield raw SSE lines (``data: ...``).
        The caller is responsible for parsing each line.
        """
        try:
            with self._http.stream("POST", path, json=payload) as response:
                if not response.is_success:
                    # Consume body so we can inspect it
                    response.read()
                    raise self._parse_error(response)
                for line in response.iter_lines():
                    yield line
        except httpx.ConnectError as exc:
            raise LGConnectionError() from exc
        except httpx.TimeoutException as exc:
            raise LGConnectionError(f"Streaming request to {path} timed out.") from exc
        except LaroGuardError:
            raise
        except Exception as exc:
            raise APIError(f"Streaming error: {exc}") from exc

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "_Client":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()
