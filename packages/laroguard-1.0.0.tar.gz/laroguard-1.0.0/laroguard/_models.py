"""
LaroGuard SDK — Typed data models.

These dataclasses mirror the exact JSON shapes returned by the LaroGuard
gateway so callers get IDE autocompletion and static-analysis support.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Shared / security
# ---------------------------------------------------------------------------

@dataclass
class SecurityMetadata:
    """Security analysis metadata attached to every chat response."""

    decision: str
    """ALLOW | WARN | BLOCK"""

    total_risk_score: int
    prompt_risk_score: int
    output_risk_score: int
    prompt_hits: list[dict[str, Any]] = field(default_factory=list)
    output_hits: list[dict[str, Any]] = field(default_factory=list)
    threat_categories: list[str] = field(default_factory=list)
    warning_reason: str | None = None

    @classmethod
    def _from_dict(cls, d: dict[str, Any]) -> "SecurityMetadata":
        return cls(
            decision=d.get("decision", "ALLOW"),
            total_risk_score=d.get("total_risk_score", 0),
            prompt_risk_score=d.get("prompt_risk_score", 0),
            output_risk_score=d.get("output_risk_score", 0),
            prompt_hits=d.get("prompt_hits", []),
            output_hits=d.get("output_hits", []),
            threat_categories=d.get("threat_categories", []),
            warning_reason=d.get("warning_reason"),
        )


@dataclass
class StreamSecuritySummary:
    """Final security summary delivered in the ``done`` SSE event."""

    decision: str
    total_risk_score: int
    prompt_risk_score: int
    output_risk_score: int
    threat_categories: list[str] = field(default_factory=list)
    inline_redactions: int = 0
    warning_reason: str | None = None
    processing_time_ms: float = 0.0
    chunks_processed: int = 0

    @classmethod
    def _from_dict(cls, d: dict[str, Any]) -> "StreamSecuritySummary":
        return cls(
            decision=d.get("decision", "ALLOW"),
            total_risk_score=d.get("total_risk_score", 0),
            prompt_risk_score=d.get("prompt_risk_score", 0),
            output_risk_score=d.get("output_risk_score", 0),
            threat_categories=d.get("threat_categories", []),
            inline_redactions=d.get("inline_redactions", 0),
            warning_reason=d.get("warning_reason"),
            processing_time_ms=d.get("processing_time_ms", 0.0),
            chunks_processed=d.get("chunks_processed", 0),
        )


# ---------------------------------------------------------------------------
# Chat
# ---------------------------------------------------------------------------

@dataclass
class Usage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int

    @classmethod
    def _from_dict(cls, d: dict[str, Any]) -> "Usage":
        return cls(
            prompt_tokens=d.get("prompt_tokens", 0),
            completion_tokens=d.get("completion_tokens", 0),
            total_tokens=d.get("total_tokens", 0),
        )


@dataclass
class Message:
    role: str
    content: str


@dataclass
class Choice:
    index: int
    message: Message
    finish_reason: str

    @classmethod
    def _from_dict(cls, d: dict[str, Any]) -> "Choice":
        msg = d.get("message", {})
        return cls(
            index=d.get("index", 0),
            message=Message(role=msg.get("role", "assistant"), content=msg.get("content", "")),
            finish_reason=d.get("finish_reason", "stop"),
        )


@dataclass
class ChatResponse:
    """
    A complete (non-streaming) chat response from the LaroGuard gateway.

    ``security`` contains the security analysis for both the prompt and the
    generated output.  Check ``security.decision`` to distinguish ALLOW / WARN.
    """

    id: str
    object: str
    created: int
    model: str
    choices: list[Choice]
    usage: Usage
    security: SecurityMetadata

    @property
    def content(self) -> str:
        """Shortcut: text of the first choice's assistant message."""
        return self.choices[0].message.content if self.choices else ""

    @classmethod
    def _from_dict(cls, d: dict[str, Any]) -> "ChatResponse":
        return cls(
            id=d.get("id", ""),
            object=d.get("object", "chat.completion"),
            created=d.get("created", 0),
            model=d.get("model", ""),
            choices=[Choice._from_dict(c) for c in d.get("choices", [])],
            usage=Usage._from_dict(d.get("usage", {})),
            security=SecurityMetadata._from_dict(d.get("security_metadata", {})),
        )


# ---------------------------------------------------------------------------
# Streaming
# ---------------------------------------------------------------------------

@dataclass
class StreamChunk:
    """A single text chunk delivered during streaming."""

    content: str
    """The text fragment for this chunk."""


@dataclass
class StreamRedaction:
    """Emitted when the output scanner redacts sensitive content inline."""

    content: str
    """Replacement placeholder text (e.g. ``[REDACTED]``)."""
    data_type: str
    """Category of the redacted data (e.g. ``email``, ``phone``)."""


@dataclass
class StreamEvent:
    """
    A discriminated union representing one SSE event from the stream.

    Inspect ``type`` to determine which fields are populated:

    - ``"chunk"`` → ``chunk`` is set
    - ``"redacted"`` → ``redaction`` is set
    - ``"done"`` → ``security`` is set; this is the *last* meaningful event
    """

    type: str
    chunk: StreamChunk | None = None
    redaction: StreamRedaction | None = None
    security: StreamSecuritySummary | None = None


# ---------------------------------------------------------------------------
# Tool analysis
# ---------------------------------------------------------------------------

@dataclass
class ToolAnalysisResult:
    """Security analysis result for a tool call."""

    decision: str
    """ALLOW | WARN | BLOCK"""
    risk_score: int
    threat_category: str
    reason: str
    detected_patterns: list[str] = field(default_factory=list)
    confidence: float = 0.0

    @classmethod
    def _from_dict(cls, d: dict[str, Any]) -> "ToolAnalysisResult":
        return cls(
            decision=d.get("decision", "ALLOW"),
            risk_score=d.get("risk_score", 0),
            threat_category=d.get("threat_category", ""),
            reason=d.get("reason", ""),
            detected_patterns=d.get("detected_patterns", []),
            confidence=d.get("confidence", 0.0),
        )


@dataclass
class ToolProxyResult:
    """Result from executing a tool through the LaroGuard proxy."""

    decision: str
    risk_score: int
    reason: str
    result: Any | None = None
    """The actual tool output, if the call was allowed to execute."""

    @classmethod
    def _from_dict(cls, d: dict[str, Any]) -> "ToolProxyResult":
        return cls(
            decision=d.get("decision", "ALLOW"),
            risk_score=d.get("risk_score", 0),
            reason=d.get("reason", ""),
            result=d.get("result"),
        )


# ---------------------------------------------------------------------------
# RAG document analysis
# ---------------------------------------------------------------------------

@dataclass
class DocumentResult:
    document_id: str
    risk_score: int
    decision: str
    threat_category: str
    reason: str
    detected_patterns: list[str] = field(default_factory=list)
    confidence: float = 0.0
    malicious_fragments: list[str] = field(default_factory=list)

    @classmethod
    def _from_dict(cls, d: dict[str, Any]) -> "DocumentResult":
        return cls(
            document_id=d.get("document_id", ""),
            risk_score=d.get("risk_score", 0),
            decision=d.get("decision", "ALLOW"),
            threat_category=d.get("threat_category", ""),
            reason=d.get("reason", ""),
            detected_patterns=d.get("detected_patterns", []),
            confidence=d.get("confidence", 0.0),
            malicious_fragments=d.get("malicious_fragments", []),
        )


@dataclass
class RAGAnalysisResult:
    """Aggregate result of analyzing a batch of RAG documents."""

    total_documents: int
    malicious_documents: int
    clean_documents: int
    total_risk_score: int
    max_risk_score: int
    decision: str
    """ALLOW | WARN | BLOCK"""
    overall_threat_category: str
    processing_time_ms: float
    document_results: list[DocumentResult] = field(default_factory=list)

    @classmethod
    def _from_dict(cls, d: dict[str, Any]) -> "RAGAnalysisResult":
        return cls(
            total_documents=d.get("total_documents", 0),
            malicious_documents=d.get("malicious_documents", 0),
            clean_documents=d.get("clean_documents", 0),
            total_risk_score=d.get("total_risk_score", 0),
            max_risk_score=d.get("max_risk_score", 0),
            decision=d.get("decision", "ALLOW"),
            overall_threat_category=d.get("overall_threat_category", ""),
            processing_time_ms=d.get("processing_time_ms", 0.0),
            document_results=[DocumentResult._from_dict(r) for r in d.get("document_results", [])],
        )
