# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import logging
from typing import Any

from data_designer.config import custom_column_generator
from data_designer.config.column_configs import CustomColumnConfig, LLMStructuredColumnConfig
from data_designer.config.column_types import ColumnConfigT

from anonymizer.config.models import RewriteModelSelection
from anonymizer.config.rewrite import PrivacyGoal
from anonymizer.engine.constants import (
    COL_FULL_REWRITE,
    COL_REPLACEMENT_MAP,
    COL_REPLACEMENT_MAP_FOR_PROMPT,
    COL_REWRITE_DISPOSITION_BLOCK,
    COL_REWRITTEN_TEXT,
    COL_SENSITIVITY_DISPOSITION,
    COL_TAG_NOTATION,
    COL_TAGGED_TEXT,
    _jinja,
)
from anonymizer.engine.ndd.model_loader import resolve_model_alias
from anonymizer.engine.prompt_utils import substitute_placeholders
from anonymizer.engine.rewrite.parsers import normalize_payload, parse_sensitivity_disposition
from anonymizer.engine.schemas import (
    EntityReplacementMapSchema,
    RewriteOutputSchema,
)

logger = logging.getLogger("anonymizer.rewrite.generation")


# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------


def _get_rewrite_prompt(privacy_goal: PrivacyGoal, data_summary: str | None = None) -> str:
    """Build the full rewrite prompt with XML section headers."""
    data_context_section = ""
    if data_summary and data_summary.strip():
        data_context_section = "\n<data_context>\nDataset description: " + data_summary.strip() + "\n</data_context>\n"

    prompt = """You are an expert writer. You excel at rewriting, paraphrasing, rewording, and following instructions.

<instructions>
Your task is to rewrite the text below so that it protects the privacy of the entities described,
following the entity protection rules and replacement map provided. The rewrite must read naturally as
plain, fluent text — no tags, brackets, or annotation artifacts.

Apply each protection decision consistently across ALL occurrences of the same entity value.
Do not add justification text or commentary in the output. Only output the rewritten text.
</instructions>

<privacy_goal>
<<PRIVACY_GOAL>>
</privacy_goal>
<<DATA_CONTEXT>>
<input>
The text below contains inline entity tags marking identified entities.
{% if <<TAG_NOTATION>> == 'bracket' %}Tags use the format [[entity_value|entity_label]]. Remove all [[...]] tags.
{% elif <<TAG_NOTATION>> == 'xml' %}Tags use the format <entity_label>entity_value</entity_label>. Remove all XML entity tags.
{% elif <<TAG_NOTATION>> == 'paren' %}Tags use the format ((SENSITIVE:entity_label|entity_value)). Remove all ((SENSITIVE:...)) tags.
{% elif <<TAG_NOTATION>> == 'sentinel' %}Tags use the format <<SENSITIVE:entity_label>>entity_value<</SENSITIVE:entity_label>>. Remove all <<SENSITIVE:...>> tags.
{% endif %}
The rewritten text must read like normal prose with no tags remaining.

Tagged text:
<<TAGGED_TEXT>>
</input>

<sensitivity_disposition>
Protection decisions for each entity that needs protection:
{% for entity in <<REWRITE_DISPOSITION_BLOCK>> %}
- {{ entity.entity_label }}: "{{ entity.entity_value }}"
  Sensitivity: {{ entity.sensitivity }}
  Protection method: {{ entity.protection_method_suggestion }}
  Reason: {{ entity.protection_reason }}
{% endfor %}

Entities NOT listed above may be kept as-is.
</sensitivity_disposition>

{% if <<REPLACEMENT_MAP_COL>>.replacements %}
<replacement_map>
Synthetic replacement values for entities with protection_method "replace":
<<REPLACEMENT_MAP>>
</replacement_map>
{% endif %}
<output_requirements>
Apply each protection method as follows:
- "replace": Substitute the entity value with the corresponding synthetic value from the replacement map.
  Use the synthetic value consistently for every occurrence.
- "generalize": Replace with a broader category or range
  (e.g., a specific city → "a city in the Pacific Northwest", exact age → "in their late 30s").
- "remove": Omit the detail entirely. Rewrite the surrounding sentence so it reads naturally without it.
- "suppress_inference": Modify the text so the attribute cannot be reliably inferred by a motivated reader.

Rules:
1. ALL entity tags (as described above) must be removed. Output must be plain text.
2. Apply changes consistently — the same entity value must be treated the same way everywhere it appears.
3. Entities with protection_method_suggestion="leave_as_is" should be retained verbatim (tags removed only).
4. The rewritten text must flow naturally and preserve the meaning and narrative structure of the original.
5. Do not introduce new identifying details not present in the original.
</output_requirements>"""
    return substitute_placeholders(
        prompt,
        {
            "<<PRIVACY_GOAL>>": privacy_goal.to_prompt_string(),
            "<<DATA_CONTEXT>>": data_context_section,
            "<<TAG_NOTATION>>": COL_TAG_NOTATION,
            "<<TAGGED_TEXT>>": _jinja(COL_TAGGED_TEXT),
            "<<REWRITE_DISPOSITION_BLOCK>>": COL_REWRITE_DISPOSITION_BLOCK,
            "<<REPLACEMENT_MAP_COL>>": COL_REPLACEMENT_MAP_FOR_PROMPT,
            "<<REPLACEMENT_MAP>>": _jinja(COL_REPLACEMENT_MAP_FOR_PROMPT),
        },
    )


# ---------------------------------------------------------------------------
# Custom column generators (pure Python, no LLM)
# ---------------------------------------------------------------------------


@custom_column_generator(required_columns=[COL_SENSITIVITY_DISPOSITION])
def _format_rewrite_disposition_block(row: dict[str, Any]) -> dict[str, Any]:
    """Pre-filter and serialize protected entities (protection_method_suggestion != "leave_as_is") for the rewrite prompt."""
    disposition = parse_sensitivity_disposition(row[COL_SENSITIVITY_DISPOSITION])
    block = []
    for e in disposition.sensitivity_disposition:
        if not e.needs_protection:
            continue
        d = e.model_dump(mode="json")
        block.append(
            {
                "entity_label": d["entity_label"],
                "entity_value": d["entity_value"],
                "sensitivity": d["sensitivity"],
                "protection_method_suggestion": d["protection_method_suggestion"],
                "protection_reason": d["protection_reason"],
            }
        )
    row[COL_REWRITE_DISPOSITION_BLOCK] = block
    return row


@custom_column_generator(required_columns=[COL_REPLACEMENT_MAP, COL_REWRITE_DISPOSITION_BLOCK])
def _filter_replacement_map_for_prompt(row: dict[str, Any]) -> dict[str, Any]:
    """Keep only replacement entries for entities with protection_method_suggestion='replace'."""
    disposition_block: list[dict] = row.get(COL_REWRITE_DISPOSITION_BLOCK, [])
    replace_values = {
        e["entity_value"] for e in disposition_block if e.get("protection_method_suggestion") == "replace"
    }
    raw_map = row.get(COL_REPLACEMENT_MAP)
    if raw_map is None:
        if replace_values:
            logger.warning(
                "COL_REPLACEMENT_MAP is None but entities require replacement; prompt will have no replacements."
            )
        row[COL_REPLACEMENT_MAP_FOR_PROMPT] = {"replacements": []}
        return row
    raw_map = normalize_payload(raw_map)
    if hasattr(raw_map, "model_dump"):
        raw_map = raw_map.model_dump(mode="python")
    parsed_map = EntityReplacementMapSchema.model_validate(raw_map)
    filtered = [
        replacement.model_dump() for replacement in parsed_map.replacements if replacement.original in replace_values
    ]
    row[COL_REPLACEMENT_MAP_FOR_PROMPT] = {"replacements": filtered}
    return row


@custom_column_generator(required_columns=[COL_FULL_REWRITE])
def _extract_rewritten_text(row: dict[str, Any]) -> dict[str, Any]:
    """Extract rewritten_text from the LLM structured output.

    Sets ``COL_REWRITTEN_TEXT`` to ``None`` on failure or blank output so
    downstream steps (repair, judge, human-review flagging) can distinguish
    a failed rewrite from a valid one.
    """
    try:
        full_rewrite = row[COL_FULL_REWRITE]
        if hasattr(full_rewrite, "model_dump"):
            full_rewrite = full_rewrite.model_dump(mode="python")
        text = str(full_rewrite["rewritten_text"])
        if not text.strip():
            logger.warning("LLM returned blank rewritten_text; marking as unavailable.")
            row[COL_REWRITTEN_TEXT] = None
        else:
            row[COL_REWRITTEN_TEXT] = text
    except Exception:
        logger.warning("Failed to extract rewritten_text from COL_FULL_REWRITE; marking as unavailable.")
        row[COL_REWRITTEN_TEXT] = None
    return row


# ---------------------------------------------------------------------------
# Workflow
# ---------------------------------------------------------------------------


class RewriteGenerationWorkflow:
    """Column factory for the rewrite generation step.

    Returns column configs for disposition-block formatting,
    replacement-map filtering, LLM rewrite, and text extraction.
    The orchestrator (``RewriteWorkflow``) collects these alongside
    domain/disposition/QA columns for a single adapter call.
    """

    def columns(
        self,
        *,
        selected_models: RewriteModelSelection,
        privacy_goal: PrivacyGoal,
        data_summary: str | None = None,
    ) -> list[ColumnConfigT]:
        rewriter_alias = resolve_model_alias("rewriter", selected_models)
        return [
            CustomColumnConfig(
                name=COL_REWRITE_DISPOSITION_BLOCK,
                generator_function=_format_rewrite_disposition_block,
            ),
            CustomColumnConfig(
                name=COL_REPLACEMENT_MAP_FOR_PROMPT,
                generator_function=_filter_replacement_map_for_prompt,
            ),
            LLMStructuredColumnConfig(
                name=COL_FULL_REWRITE,
                prompt=_get_rewrite_prompt(privacy_goal, data_summary),
                model_alias=rewriter_alias,
                output_format=RewriteOutputSchema,
            ),
            CustomColumnConfig(
                name=COL_REWRITTEN_TEXT,
                generator_function=_extract_rewritten_text,
            ),
        ]
