# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import hashlib
import re
from string import Formatter
from typing import Annotated, Any, Literal

from pydantic import BaseModel, Discriminator, Field, Tag, field_validator


def _resolve_replace_tag(v: Any) -> str:
    """Callable discriminator: class name for instances, 'kind' key for dicts."""
    if isinstance(v, BaseModel):
        return type(v).__name__.lower()
    if isinstance(v, dict):
        kind = v.get("kind")
        if isinstance(kind, str) and kind:
            return kind.lower()
        raise TypeError(f"dict is missing a valid 'kind' key: {v!r}")
    raise TypeError(f"Cannot resolve replace tag for type {type(v).__name__!r}")


class ReplaceMethodBase(BaseModel):
    """Shared configuration for all replacement methods."""

    def _render_template(self, template: str, *, text: str, label: str, **extra: str) -> str:
        return template.format(text=text, label=label, **extra)

    @staticmethod
    def _validate_template(
        value: str,
        required_fields: set[str],
        allowed_fields: set[str] | None = None,
    ) -> None:
        fields = {field_name for _, field_name, _, _ in Formatter().parse(value) if field_name}
        allowed = allowed_fields or {"text", "label"}
        unexpected = fields - allowed
        if unexpected:
            invalid = ", ".join(sorted(unexpected))
            raise ValueError(f"template contains unsupported placeholders: {invalid}")
        if not required_fields.issubset(fields):
            missing = ", ".join(sorted(required_fields - fields))
            raise ValueError(f"template is missing required placeholders: {missing}")


class Substitute(ReplaceMethodBase):
    """Replace entities with LLM-generated synthetic values."""

    instructions: str | None = Field(
        default=None, description="Additional instructions for the LLM replacement generator."
    )


class Redact(ReplaceMethodBase):
    """Replace each entity with a configurable redaction template."""

    format_template: str = Field(
        default="[REDACTED_{label}]", description="Template with optional {label} placeholder."
    )
    normalize_label: bool = Field(default=True, description="Uppercase and clean label before substitution.")

    @field_validator("format_template")
    @classmethod
    def validate_format_template(cls, value: str) -> str:
        cls._validate_template(
            value=value,
            required_fields=set(),
            allowed_fields={"label"},
        )
        return value

    def replace(self, text: str, label: str) -> str:
        """Apply the redaction template to a single entity occurrence.

        Args:
            text: Original entity text (e.g. ``"Alice"``).
            label: Entity label (e.g. ``"first_name"``).
        """
        normalized_label = _format_label_for_redaction(label) if self.normalize_label else label
        return self._render_template(
            template=self.format_template,
            text=text,
            label=normalized_label,
        )


class Annotate(ReplaceMethodBase):
    """Tag each entity with a readable label token."""

    format_template: str = Field(
        default="<{text}, {label}>", description="Template with {text} and {label} placeholders."
    )

    @field_validator("format_template")
    @classmethod
    def validate_format_template(cls, value: str) -> str:
        cls._validate_template(
            value=value,
            required_fields={"text", "label"},
            allowed_fields={"text", "label"},
        )
        return value

    def replace(self, text: str, label: str) -> str:
        """Apply the annotation template to a single entity occurrence.

        Args:
            text: Original entity text (e.g. ``"Alice"``).
            label: Entity label (e.g. ``"first_name"``).
        """
        return self._render_template(
            template=self.format_template,
            text=text,
            label=label,
        )


class Hash(ReplaceMethodBase):
    """Replace each entity with a deterministic hash token."""

    algorithm: Literal["sha256", "sha1", "md5"] = Field(default="sha256", description="Hash algorithm.")
    digest_length: int = Field(
        default=12, ge=6, le=64, description="Number of hex characters to keep from the hash digest."
    )
    format_template: str = Field(
        default="<HASH_{label}_{digest}>", description="Template with {digest} required and optional {label}."
    )

    @field_validator("format_template")
    @classmethod
    def validate_format_template(cls, value: str) -> str:
        cls._validate_template(
            value=value,
            required_fields={"digest"},
            allowed_fields={"label", "digest"},
        )
        return value

    def replace(self, text: str, label: str) -> str:
        """Apply the hash template to a single entity occurrence.

        Args:
            text: Original entity text (e.g. ``"Alice"``).
            label: Entity label (e.g. ``"first_name"``).
        """
        digest = hashlib.new(self.algorithm, text.encode("utf-8")).hexdigest()[: self.digest_length]
        return self._render_template(
            template=self.format_template,
            text=text,
            label=label.upper(),
            digest=digest,
        )


ReplaceMethod = Annotated[
    Annotated[Annotate, Tag("annotate")]
    | Annotated[Redact, Tag("redact")]
    | Annotated[Hash, Tag("hash")]
    | Annotated[Substitute, Tag("substitute")],
    Discriminator(_resolve_replace_tag),
]

LocalReplaceMethod = Annotated[
    Annotated[Annotate, Tag("annotate")] | Annotated[Redact, Tag("redact")] | Annotated[Hash, Tag("hash")],
    Discriminator(_resolve_replace_tag),
]


def _format_label_for_redaction(label: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9]+", "_", label.strip()).strip("_")
    if cleaned == "":
        return "UNKNOWN"
    return cleaned.upper()
