"""LLM interaction sub-package."""
