"""Vector store sub-package."""
