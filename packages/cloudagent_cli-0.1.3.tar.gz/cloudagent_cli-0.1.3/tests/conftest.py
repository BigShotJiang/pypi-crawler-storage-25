"""Shared test fixtures."""

from __future__ import annotations

import pytest


@pytest.fixture
def respx_mock():
    """Provide a respx mock context for httpx."""
    import respx

    with respx.mock(assert_all_called=False) as mock:
        yield mock
