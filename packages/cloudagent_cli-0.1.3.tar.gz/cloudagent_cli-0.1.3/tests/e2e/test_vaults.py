"""E2E tests for ``cloudagent vaults`` commands (vaults + credentials)."""

from __future__ import annotations

import json

from tests.e2e.conftest import make_credential, make_vault, runner


class TestVaultsCreate:
    def test_create_success(self, mock_api, invoke):
        vault = make_vault()
        mock_api.post("/v1/vaults").respond(status_code=201, json=vault)

        result = invoke("vaults", "create", "--name", "cli-test-vault")
        assert result.exit_code == 0
        assert "vault_cli-test-001" in result.output

    def test_create_missing_name(self, invoke):
        result = invoke("vaults", "create")
        assert result.exit_code != 0

    def test_create_json_output(self, mock_api, invoke):
        vault = make_vault()
        mock_api.post("/v1/vaults").respond(status_code=201, json=vault)

        result = invoke("vaults", "create", "--name", "cli-test-vault", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["id"] == "vault_cli-test-001"


class TestVaultsList:
    def test_list_success(self, mock_api, invoke):
        mock_api.get("/v1/vaults").respond(
            json={"data": [make_vault()], "next_page": None}
        )
        result = invoke("vaults", "list")
        assert result.exit_code == 0
        assert "cli-test-vault" in result.output

    def test_list_empty(self, mock_api, invoke):
        mock_api.get("/v1/vaults").respond(
            json={"data": [], "next_page": None}
        )
        result = invoke("vaults", "list")
        assert result.exit_code == 0

    def test_list_json_output(self, mock_api, invoke):
        mock_api.get("/v1/vaults").respond(
            json={"data": [make_vault()], "next_page": None}
        )
        result = invoke("vaults", "list", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed["data"], list)


class TestVaultsGet:
    def test_get_success(self, mock_api, invoke):
        vault = make_vault()
        mock_api.get("/v1/vaults/vault_cli-test-001").respond(json=vault)

        result = invoke("vaults", "get", "vault_cli-test-001")
        assert result.exit_code == 0
        assert "cli-test-vault" in result.output

    def test_get_not_found(self, mock_api, invoke):
        mock_api.get("/v1/vaults/vault_nonexistent").respond(
            status_code=404, json={"detail": "Vault not found"}
        )
        result = invoke("vaults", "get", "vault_nonexistent")
        assert result.exit_code != 0

    def test_get_json_output(self, mock_api, invoke):
        vault = make_vault()
        mock_api.get("/v1/vaults/vault_cli-test-001").respond(json=vault)

        result = invoke("vaults", "get", "vault_cli-test-001", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["display_name"] == "cli-test-vault"


class TestCredentialsCreate:
    def test_create_static_bearer_success(self, mock_api, invoke):
        cred = make_credential()
        mock_api.post("/v1/vaults/vault_cli-test-001/credentials").respond(
            status_code=201, json=cred
        )

        result = invoke(
            "vaults", "credentials-create", "vault_cli-test-001",
            "--name", "cli-test-cred",
            "--auth-type", "static_bearer",
            "--token", "tok-abc",
            "--mcp-server-url", "https://mcp.test",
        )
        assert result.exit_code == 0, result.output
        assert "cred_cli-test-001" in result.output

    def test_create_missing_name(self, invoke):
        result = invoke("vaults", "credentials-create", "vault_cli-test-001")
        assert result.exit_code != 0

    def test_create_json_output(self, mock_api, invoke):
        cred = make_credential()
        mock_api.post("/v1/vaults/vault_cli-test-001/credentials").respond(
            status_code=201, json=cred
        )

        result = invoke(
            "vaults", "credentials-create", "vault_cli-test-001",
            "--name", "cli-test-cred",
            "--auth-type", "static_bearer",
            "--token", "tok-abc",
            "--mcp-server-url", "https://mcp.test",
            "--json",
        )
        assert result.exit_code == 0, result.output
        parsed = json.loads(result.output)
        assert parsed["id"] == "cred_cli-test-001"

    # -- static_env_vars (S31) --

    def test_create_static_env_vars_via_flags(self, mock_api, invoke):
        cred = make_credential()
        route = mock_api.post(
            "/v1/vaults/vault_cli-test-001/credentials"
        ).respond(status_code=201, json=cred)

        result = invoke(
            "vaults", "credentials-create", "vault_cli-test-001",
            "--name", "cli-test-cred",
            "--auth-type", "static_env_vars",
            "--env-var", "ALIBABA_CLOUD_ACCESS_KEY_ID=AK_X",
            "--env-var", "ALIBABA_CLOUD_ACCESS_KEY_SECRET=SK_Y",
        )
        assert result.exit_code == 0, result.output
        assert route.called
        # Inspect request body
        body = json.loads(route.calls[0].request.content)
        assert body["auth"]["type"] == "static_env_vars"
        assert body["auth"]["env_vars"] == {
            "ALIBABA_CLOUD_ACCESS_KEY_ID": "AK_X",
            "ALIBABA_CLOUD_ACCESS_KEY_SECRET": "SK_Y",
        }

    def test_create_static_env_vars_via_file(self, mock_api, invoke, tmp_path):
        f = tmp_path / "ak.env"
        f.write_text(
            "# AK pair\nALIBABA_CLOUD_ACCESS_KEY_ID=AK_FILE\n"
            "ALIBABA_CLOUD_ACCESS_KEY_SECRET=SK_FILE\n"
        )
        cred = make_credential()
        route = mock_api.post(
            "/v1/vaults/vault_cli-test-001/credentials"
        ).respond(status_code=201, json=cred)

        result = invoke(
            "vaults", "credentials-create", "vault_cli-test-001",
            "--name", "cli-test-cred",
            "--auth-type", "static_env_vars",
            "--env-vars-file", str(f),
        )
        assert result.exit_code == 0, result.output
        assert route.called
        body = json.loads(route.calls[0].request.content)
        assert body["auth"]["env_vars"]["ALIBABA_CLOUD_ACCESS_KEY_ID"] == "AK_FILE"

    def test_create_static_env_vars_rejects_lowercase_key(self, invoke):
        result = invoke(
            "vaults", "credentials-create", "vault_cli-test-001",
            "--name", "cli-test-cred",
            "--auth-type", "static_env_vars",
            "--env-var", "lowercase_key=bad",
        )
        assert result.exit_code != 0
        assert "match" in result.output.lower() or "invalid" in result.output.lower()

    def test_create_static_env_vars_rejects_reserved_key(self, invoke):
        result = invoke(
            "vaults", "credentials-create", "vault_cli-test-001",
            "--name", "cli-test-cred",
            "--auth-type", "static_env_vars",
            "--env-var", "ANTHROPIC_API_KEY=sk-xxx",
        )
        assert result.exit_code != 0
        assert "reserved" in result.output.lower()

    def test_create_static_env_vars_rejects_too_many_keys(self, invoke):
        flags: list[str] = []
        for i in range(33):
            flags.extend(["--env-var", f"KEY_{i}=v"])
        result = invoke(
            "vaults", "credentials-create", "vault_cli-test-001",
            "--name", "cli-test-cred",
            "--auth-type", "static_env_vars",
            *flags,
        )
        assert result.exit_code != 0
        assert "32" in result.output

    def test_create_static_env_vars_requires_at_least_one_entry(self, invoke):
        result = invoke(
            "vaults", "credentials-create", "vault_cli-test-001",
            "--name", "cli-test-cred",
            "--auth-type", "static_env_vars",
        )
        assert result.exit_code != 0
        assert "at least one" in result.output.lower() or "env_vars" in result.output.lower()


class TestVaultsUpdate:
    def test_update_success(self, mock_api, invoke):
        vault = make_vault(display_name="renamed")
        mock_api.post("/v1/vaults/vault_cli-test-001").respond(json=vault)
        result = invoke(
            "vaults", "update", "vault_cli-test-001", "--name", "renamed"
        )
        assert result.exit_code == 0, result.output
        assert "renamed" in result.output

    def test_update_nothing_supplied(self, invoke):
        result = invoke("vaults", "update", "vault_cli-test-001")
        assert result.exit_code != 0


class TestVaultsArchive:
    def test_archive_success(self, mock_api, invoke):
        vault = make_vault()
        vault["archived_at"] = "2026-04-22T00:00:00Z"
        mock_api.post("/v1/vaults/vault_cli-test-001/archive").respond(json=vault)
        result = invoke("vaults", "archive", "vault_cli-test-001")
        assert result.exit_code == 0, result.output


class TestVaultsDelete:
    def test_delete_success(self, mock_api, invoke):
        mock_api.delete("/v1/vaults/vault_cli-test-001").respond(
            json={"id": "vault_cli-test-001", "type": "vault_deleted"},
        )
        result = invoke("vaults", "delete", "vault_cli-test-001")
        assert result.exit_code == 0, result.output
        assert "vault_deleted" in result.output


class TestCredentialsGetUpdateArchiveDelete:
    def test_get_success(self, mock_api, invoke):
        cred = make_credential()
        mock_api.get(
            "/v1/vaults/vault_cli-test-001/credentials/cred_cli-test-001"
        ).respond(json=cred)
        result = invoke(
            "vaults", "credentials-get",
            "vault_cli-test-001", "cred_cli-test-001",
        )
        assert result.exit_code == 0, result.output

    def test_update_name_only(self, mock_api, invoke):
        cred = make_credential(display_name="newname")
        route = mock_api.post(
            "/v1/vaults/vault_cli-test-001/credentials/cred_cli-test-001"
        ).respond(json=cred)
        result = invoke(
            "vaults", "credentials-update",
            "vault_cli-test-001", "cred_cli-test-001",
            "--name", "newname",
        )
        assert result.exit_code == 0, result.output
        body = json.loads(route.calls[0].request.content)
        assert body == {"display_name": "newname"}

    def test_update_replace_auth_static_env_vars(self, mock_api, invoke):
        cred = make_credential()
        route = mock_api.post(
            "/v1/vaults/vault_cli-test-001/credentials/cred_cli-test-001"
        ).respond(json=cred)
        result = invoke(
            "vaults", "credentials-update",
            "vault_cli-test-001", "cred_cli-test-001",
            "--auth-type", "static_env_vars",
            "--env-var", "FOO=bar",
        )
        assert result.exit_code == 0, result.output
        body = json.loads(route.calls[0].request.content)
        assert body["auth"]["type"] == "static_env_vars"
        assert body["auth"]["env_vars"] == {"FOO": "bar"}

    def test_archive_success(self, mock_api, invoke):
        cred = make_credential()
        mock_api.post(
            "/v1/vaults/vault_cli-test-001/credentials/cred_cli-test-001/archive"
        ).respond(json=cred)
        result = invoke(
            "vaults", "credentials-archive",
            "vault_cli-test-001", "cred_cli-test-001",
        )
        assert result.exit_code == 0, result.output

    def test_delete_success(self, mock_api, invoke):
        mock_api.delete(
            "/v1/vaults/vault_cli-test-001/credentials/cred_cli-test-001"
        ).respond(
            json={
                "id": "cred_cli-test-001",
                "type": "vault_credential_deleted",
            }
        )
        result = invoke(
            "vaults", "credentials-delete",
            "vault_cli-test-001", "cred_cli-test-001",
        )
        assert result.exit_code == 0, result.output
        assert "vault_credential_deleted" in result.output


class TestCredentialsList:
    def test_list_success(self, mock_api, invoke):
        mock_api.get("/v1/vaults/vault_cli-test-001/credentials").respond(
            json={"data": [make_credential()], "next_page": None}
        )
        result = invoke("vaults", "credentials-list", "vault_cli-test-001")
        assert result.exit_code == 0
        assert "cli-test-cred" in result.output

    def test_list_empty(self, mock_api, invoke):
        mock_api.get("/v1/vaults/vault_cli-test-001/credentials").respond(
            json={"data": [], "next_page": None}
        )
        result = invoke("vaults", "credentials-list", "vault_cli-test-001")
        assert result.exit_code == 0

    def test_list_json_output(self, mock_api, invoke):
        mock_api.get("/v1/vaults/vault_cli-test-001/credentials").respond(
            json={"data": [make_credential()], "next_page": None}
        )
        result = invoke(
            "vaults", "credentials-list", "vault_cli-test-001", "--json"
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed["data"], list)
