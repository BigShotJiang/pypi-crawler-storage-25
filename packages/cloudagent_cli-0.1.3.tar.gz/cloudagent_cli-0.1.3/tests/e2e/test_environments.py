"""E2E tests for ``cloudagent environments`` commands."""

from __future__ import annotations

import json

from tests.e2e.conftest import make_environment, runner


class TestEnvironmentsCreate:
    def test_create_success(self, mock_api, invoke):
        env = make_environment()
        mock_api.post("/v1/environments").respond(status_code=201, json=env)

        result = invoke(
            "environments", "create",
            "--name", "cli-test-env",
        )
        assert result.exit_code == 0
        assert "env_cli-test-001" in result.output

    def test_create_with_description(self, mock_api, invoke):
        env = make_environment(description="cli-test sandbox")
        mock_api.post("/v1/environments").respond(status_code=201, json=env)

        result = invoke(
            "environments", "create",
            "--name", "cli-test-env",
            "--description", "cli-test sandbox",
        )
        assert result.exit_code == 0

    def test_create_missing_name(self, invoke):
        result = invoke("environments", "create")
        assert result.exit_code != 0

    def test_create_json_output(self, mock_api, invoke):
        env = make_environment()
        mock_api.post("/v1/environments").respond(status_code=201, json=env)

        result = invoke(
            "environments", "create",
            "--name", "cli-test-env",
            "--json",
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["id"] == "env_cli-test-001"


class TestEnvironmentsList:
    def test_list_success(self, mock_api, invoke):
        mock_api.get("/v1/environments").respond(
            json={"data": [make_environment()], "next_page": None}
        )
        result = invoke("environments", "list")
        assert result.exit_code == 0
        assert "cli-test-env" in result.output

    def test_list_empty(self, mock_api, invoke):
        mock_api.get("/v1/environments").respond(
            json={"data": [], "next_page": None}
        )
        result = invoke("environments", "list")
        assert result.exit_code == 0

    def test_list_json_output(self, mock_api, invoke):
        mock_api.get("/v1/environments").respond(
            json={"data": [make_environment()], "next_page": None}
        )
        result = invoke("environments", "list", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed["data"], list)

    def test_list_with_limit(self, mock_api, invoke):
        mock_api.get("/v1/environments").respond(
            json={"data": [], "next_page": None}
        )
        result = invoke("environments", "list", "--limit", "5")
        assert result.exit_code == 0


class TestEnvironmentsGet:
    def test_get_success(self, mock_api, invoke):
        env = make_environment()
        mock_api.get("/v1/environments/env_cli-test-001").respond(json=env)

        result = invoke("environments", "get", "env_cli-test-001")
        assert result.exit_code == 0
        assert "cli-test-env" in result.output

    def test_get_not_found(self, mock_api, invoke):
        mock_api.get("/v1/environments/env_nonexistent").respond(
            status_code=404, json={"detail": "Environment not found"}
        )
        result = invoke("environments", "get", "env_nonexistent")
        assert result.exit_code != 0

    def test_get_json_output(self, mock_api, invoke):
        env = make_environment()
        mock_api.get("/v1/environments/env_cli-test-001").respond(json=env)

        result = invoke("environments", "get", "env_cli-test-001", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["name"] == "cli-test-env"
