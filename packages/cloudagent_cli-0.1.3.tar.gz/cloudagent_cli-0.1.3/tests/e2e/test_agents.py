"""E2E tests for ``cloudagent agents`` commands."""

from __future__ import annotations

import json

import httpx
import respx

from cloudagent_cli.main import app as cli_app
from tests.e2e.conftest import (
    CLI_TEST_BASE_URL,
    make_agent,
    runner,
)


class TestAgentsCreate:
    def test_create_success(self, mock_api, invoke):
        agent = make_agent()
        mock_api.post("/v1/agents").respond(status_code=201, json=agent)

        result = invoke(
            "agents", "create",
            "--name", "cli-test-agent",
            "--model", "qwen3.6-plus",
        )
        assert result.exit_code == 0
        assert "agent_cli-test-001" in result.output

    def test_create_with_system_and_description(self, mock_api, invoke):
        agent = make_agent(description="A helper", system="You are helpful.")
        mock_api.post("/v1/agents").respond(status_code=201, json=agent)

        result = invoke(
            "agents", "create",
            "--name", "cli-test-agent",
            "--model", "qwen3.6-plus",
            "--system", "You are helpful.",
            "--description", "A helper",
        )
        assert result.exit_code == 0
        assert "agent_cli-test-001" in result.output

    def test_create_missing_name(self, invoke):
        """--name is required; omitting it causes exit_code != 0."""
        result = invoke("agents", "create", "--model", "qwen3.6-plus")
        assert result.exit_code != 0

    def test_create_json_output(self, mock_api, invoke):
        agent = make_agent()
        mock_api.post("/v1/agents").respond(status_code=201, json=agent)

        result = invoke(
            "agents", "create",
            "--name", "cli-test-agent",
            "--json",
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["id"] == "agent_cli-test-001"


class TestAgentsList:
    def test_list_success(self, mock_api, invoke):
        mock_api.get("/v1/agents").respond(
            json={"data": [make_agent()], "next_page": None}
        )
        result = invoke("agents", "list")
        assert result.exit_code == 0
        assert "cli-test-agent" in result.output

    def test_list_empty(self, mock_api, invoke):
        mock_api.get("/v1/agents").respond(
            json={"data": [], "next_page": None}
        )
        result = invoke("agents", "list")
        assert result.exit_code == 0

    def test_list_json_output(self, mock_api, invoke):
        mock_api.get("/v1/agents").respond(
            json={"data": [make_agent()], "next_page": None}
        )
        result = invoke("agents", "list", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed["data"], list)

    def test_list_with_limit(self, mock_api, invoke):
        mock_api.get("/v1/agents").respond(
            json={"data": [make_agent()], "next_page": None}
        )
        result = invoke("agents", "list", "--limit", "5")
        assert result.exit_code == 0


class TestAgentsGet:
    def test_get_success(self, mock_api, invoke):
        agent = make_agent()
        mock_api.get("/v1/agents/agent_cli-test-001").respond(json=agent)

        result = invoke("agents", "get", "agent_cli-test-001")
        assert result.exit_code == 0
        assert "cli-test-agent" in result.output

    def test_get_not_found(self, mock_api, invoke):
        mock_api.get("/v1/agents/agent_nonexistent").respond(
            status_code=404, json={"detail": "Agent not found"}
        )
        result = invoke("agents", "get", "agent_nonexistent")
        assert result.exit_code != 0

    def test_get_json_output(self, mock_api, invoke):
        agent = make_agent()
        mock_api.get("/v1/agents/agent_cli-test-001").respond(json=agent)

        result = invoke("agents", "get", "agent_cli-test-001", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["name"] == "cli-test-agent"


class TestAgentsUpdate:
    def test_update_success(self, mock_api, invoke):
        updated = make_agent(version=2, system="Updated prompt")
        mock_api.post("/v1/agents/agent_cli-test-001").respond(json=updated)

        result = invoke(
            "agents", "update", "agent_cli-test-001",
            "--version", "1",
            "--system", "Updated prompt",
        )
        assert result.exit_code == 0

    def test_update_missing_version(self, invoke):
        """--version is required for CAS."""
        result = invoke(
            "agents", "update", "agent_cli-test-001",
            "--system", "no version",
        )
        assert result.exit_code != 0

    def test_update_conflict(self, mock_api, invoke):
        mock_api.post("/v1/agents/agent_cli-test-001").respond(
            status_code=409, json={"detail": "Version conflict"}
        )
        result = invoke(
            "agents", "update", "agent_cli-test-001",
            "--version", "99",
            "--system", "stale",
        )
        assert result.exit_code != 0

    def test_update_json_output(self, mock_api, invoke):
        updated = make_agent(version=2)
        mock_api.post("/v1/agents/agent_cli-test-001").respond(json=updated)

        result = invoke(
            "agents", "update", "agent_cli-test-001",
            "--version", "1",
            "--name", "cli-test-renamed",
            "--json",
        )
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["version"] == 2


class TestAgentsArchive:
    def test_archive_success(self, mock_api, invoke):
        archived = make_agent(archived_at="2026-04-16T12:00:00Z")
        mock_api.post("/v1/agents/agent_cli-test-001/archive").respond(json=archived)

        result = invoke("agents", "archive", "agent_cli-test-001")
        assert result.exit_code == 0

    def test_archive_not_found(self, mock_api, invoke):
        mock_api.post("/v1/agents/agent_nonexistent/archive").respond(
            status_code=404, json={"detail": "Agent not found"}
        )
        result = invoke("agents", "archive", "agent_nonexistent")
        assert result.exit_code != 0

    def test_archive_json_output(self, mock_api, invoke):
        archived = make_agent(archived_at="2026-04-16T12:00:00Z")
        mock_api.post("/v1/agents/agent_cli-test-001/archive").respond(json=archived)

        result = invoke("agents", "archive", "agent_cli-test-001", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["archived_at"] is not None


class TestAgentsVersions:
    def test_versions_success(self, mock_api, invoke):
        versions = {
            "data": [
                {
                    "id": "aver_cli-test-001",
                    "agent_id": "agent_cli-test-001",
                    "version": 1,
                    "snapshot": {},
                    "changed_fields": ["name"],
                    "created_at": "2026-04-16T00:00:00Z",
                    "created_by": None,
                },
            ],
            "next_page": None,
        }
        mock_api.get("/v1/agents/agent_cli-test-001/versions").respond(json=versions)

        result = invoke("agents", "versions", "agent_cli-test-001")
        assert result.exit_code == 0

    def test_versions_json_output(self, mock_api, invoke):
        versions = {"data": [], "next_page": None}
        mock_api.get("/v1/agents/agent_cli-test-001/versions").respond(json=versions)

        result = invoke("agents", "versions", "agent_cli-test-001", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert "data" in parsed
