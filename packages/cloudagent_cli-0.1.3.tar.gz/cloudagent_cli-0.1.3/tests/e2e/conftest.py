"""Shared fixtures for CLI E2E tests.

Strategy: CliRunner (in-process) + respx (HTTP mock).

We mock the HTTP layer (respx) rather than spinning up a real backend,
because the backend has heavy deps (PostgreSQL, Redis, OSS).  The tests
exercise the *full CLI command chain*: Typer arg parsing -> CloudAgentClient
construction -> httpx request -> response handling -> Rich/JSON output.

All test data uses the ``cli-test-`` prefix for easy identification.
"""

from __future__ import annotations

import json
from typing import Any

import pytest
import respx
from typer.testing import CliRunner

from cloudagent_cli.main import app as cli_app

runner = CliRunner()

# ---------------------------------------------------------------------------
# Reusable mock-data factories
# ---------------------------------------------------------------------------

CLI_TEST_API_KEY = "cli-test-sk-0000000000000001"
CLI_TEST_BASE_URL = "https://mock.cloudagent.test"


def _api_url(path: str) -> str:
    return f"{CLI_TEST_BASE_URL}{path}"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _patch_config(monkeypatch):
    """Every E2E test sees a valid config so CloudAgentClient can instantiate.

    We must patch the *imported references* in ``cloudagent_cli.client``
    because ``client.py`` does ``from cloudagent_cli.config import get_api_key``.
    """
    monkeypatch.setattr("cloudagent_cli.client.get_api_key", lambda: CLI_TEST_API_KEY)
    monkeypatch.setattr("cloudagent_cli.client.get_base_url", lambda: CLI_TEST_BASE_URL)


@pytest.fixture
def mock_api():
    """Provide a respx mock context scoped to one test."""
    with respx.mock(base_url=CLI_TEST_BASE_URL, assert_all_called=False) as m:
        yield m


@pytest.fixture
def invoke():
    """Shorthand: invoke CLI args and return the CompletedProcess-like result."""
    def _invoke(*args: str):
        return runner.invoke(cli_app, list(args))
    return _invoke


# ---------------------------------------------------------------------------
# Reusable response payloads
# ---------------------------------------------------------------------------

def make_agent(
    agent_id: str = "agent_cli-test-001",
    name: str = "cli-test-agent",
    model: str = "qwen3.6-plus",
    version: int = 1,
    **overrides: Any,
) -> dict:
    base = {
        "id": agent_id,
        "name": name,
        "description": "",
        "model": model,
        "system": None,
        "tools": [],
        "mcp_servers": [],
        "skills": [],
        "metadata": {},
        "version": version,
        "created_at": "2026-04-16T00:00:00Z",
        "updated_at": "2026-04-16T00:00:00Z",
        "archived_at": None,
    }
    base.update(overrides)
    return base


def make_session(
    session_id: str = "sess_cli-test-001",
    agent_id: str = "agent_cli-test-001",
    status: str = "active",
    **overrides: Any,
) -> dict:
    base = {
        "id": session_id,
        "agent": {
            "id": agent_id,
            "name": "cli-test-agent",
            "description": None,
            "version": 1,
            "model": "qwen3.6-plus",
            "system": None,
            "tools": [],
            "mcp_servers": [],
            "skills": [],
        },
        "environment_id": None,
        "vault_ids": [],
        "status": status,
        "title": None,
        "metadata": {},
        "resources": [],
        "stats": {},
        "usage": {},
        "created_at": "2026-04-16T00:00:00Z",
        "updated_at": "2026-04-16T00:00:00Z",
        "archived_at": None,
    }
    base.update(overrides)
    return base


def make_environment(
    env_id: str = "env_cli-test-001",
    name: str = "cli-test-env",
    **overrides: Any,
) -> dict:
    base = {
        "id": env_id,
        "name": name,
        "description": "",
        "config": {},
        "metadata": {},
        "created_at": "2026-04-16T00:00:00Z",
        "updated_at": "2026-04-16T00:00:00Z",
        "archived_at": None,
    }
    base.update(overrides)
    return base


def make_vault(
    vault_id: str = "vault_cli-test-001",
    display_name: str = "cli-test-vault",
    **overrides: Any,
) -> dict:
    base = {
        "id": vault_id,
        "display_name": display_name,
        "metadata": {},
        "created_at": "2026-04-16T00:00:00Z",
        "updated_at": "2026-04-16T00:00:00Z",
        "archived_at": None,
    }
    base.update(overrides)
    return base


def make_credential(
    cred_id: str = "cred_cli-test-001",
    vault_id: str = "vault_cli-test-001",
    display_name: str = "cli-test-cred",
    **overrides: Any,
) -> dict:
    base = {
        "id": cred_id,
        "vault_id": vault_id,
        "display_name": display_name,
        "metadata": {},
        "auth": None,
        "created_at": "2026-04-16T00:00:00Z",
        "updated_at": "2026-04-16T00:00:00Z",
        "archived_at": None,
    }
    base.update(overrides)
    return base


def make_model_registration(
    reg_id: str = "modreg_cli-test-001",
    provider: str = "dashscope",
    model_id: str = "qwen-turbo",
    **overrides: Any,
) -> dict:
    base = {
        "id": reg_id,
        "org_id": "org_test",
        "provider": provider,
        "model_id": model_id,
        "display_name": None,
        "api_key": "sk-****test",
        "base_url": None,
        "is_active": True,
        "created_at": "2026-04-16T00:00:00Z",
        "updated_at": "2026-04-16T00:00:00Z",
    }
    base.update(overrides)
    return base


def make_file(
    file_id: str = "file_cli-test-001",
    filename: str = "cli-test-file.txt",
    **overrides: Any,
) -> dict:
    base = {
        "id": file_id,
        "org_id": "org_test",
        "filename": filename,
        "content_type": "text/plain",
        "size_bytes": 42,
        "created_at": "2026-04-16T00:00:00Z",
    }
    base.update(overrides)
    return base


def make_event(
    event_id: str = "ev_cli-test-001",
    event_type: str = "user.message",
    **overrides: Any,
) -> dict:
    base = {
        "id": event_id,
        "type": event_type,
        "processed_at": "2026-04-16T00:00:01Z",
    }
    base.update(overrides)
    return base
