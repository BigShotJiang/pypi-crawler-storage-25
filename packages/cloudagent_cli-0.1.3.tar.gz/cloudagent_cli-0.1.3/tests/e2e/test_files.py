"""E2E tests for ``cloudagent files`` commands."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

from tests.e2e.conftest import make_file, runner


class TestFilesUpload:
    def test_upload_success(self, mock_api, invoke, tmp_path):
        """Upload a temp file and verify the CLI reports the file_id."""
        test_file = tmp_path / "cli-test-upload.txt"
        test_file.write_text("cli-test file content")

        f = make_file(filename="cli-test-upload.txt", size_bytes=21)
        mock_api.post("/v1/files").respond(status_code=201, json=f)

        result = invoke("files", "upload", str(test_file))
        assert result.exit_code == 0
        assert "file_cli-test-001" in result.output

    def test_upload_nonexistent_file(self, invoke):
        result = invoke("files", "upload", "/tmp/cli-test-does-not-exist-99999.txt")
        assert result.exit_code != 0

    def test_upload_json_output(self, mock_api, invoke, tmp_path):
        test_file = tmp_path / "cli-test-upload.txt"
        test_file.write_text("cli-test json upload")

        f = make_file(filename="cli-test-upload.txt")
        mock_api.post("/v1/files").respond(status_code=201, json=f)

        result = invoke("files", "upload", str(test_file), "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["id"] == "file_cli-test-001"


class TestFilesList:
    def test_list_success(self, mock_api, invoke):
        mock_api.get("/v1/files").respond(
            json={"data": [make_file()], "next_page": None}
        )
        result = invoke("files", "list")
        assert result.exit_code == 0
        # Rich may truncate long filenames in table view
        assert "cli-test-file" in result.output

    def test_list_empty(self, mock_api, invoke):
        mock_api.get("/v1/files").respond(
            json={"data": [], "next_page": None}
        )
        result = invoke("files", "list")
        assert result.exit_code == 0

    def test_list_json_output(self, mock_api, invoke):
        mock_api.get("/v1/files").respond(
            json={"data": [make_file()], "next_page": None}
        )
        result = invoke("files", "list", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert isinstance(parsed["data"], list)

    def test_list_with_limit(self, mock_api, invoke):
        mock_api.get("/v1/files").respond(
            json={"data": [], "next_page": None}
        )
        result = invoke("files", "list", "--limit", "5")
        assert result.exit_code == 0


class TestFilesGet:
    def test_get_success(self, mock_api, invoke):
        f = make_file()
        mock_api.get("/v1/files/file_cli-test-001").respond(json=f)

        result = invoke("files", "get", "file_cli-test-001")
        assert result.exit_code == 0
        assert "cli-test-file.txt" in result.output

    def test_get_not_found(self, mock_api, invoke):
        mock_api.get("/v1/files/file_nonexistent").respond(
            status_code=404, json={"detail": "File not found"}
        )
        result = invoke("files", "get", "file_nonexistent")
        assert result.exit_code != 0

    def test_get_json_output(self, mock_api, invoke):
        f = make_file()
        mock_api.get("/v1/files/file_cli-test-001").respond(json=f)

        result = invoke("files", "get", "file_cli-test-001", "--json")
        assert result.exit_code == 0
        parsed = json.loads(result.output)
        assert parsed["filename"] == "cli-test-file.txt"
