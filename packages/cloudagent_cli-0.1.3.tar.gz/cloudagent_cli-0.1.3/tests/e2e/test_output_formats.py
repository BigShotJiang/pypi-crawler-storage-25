"""E2E tests for output format consistency across commands.

Verifies:
- ``--json`` flag produces valid JSON on all list/get commands.
- Without ``--json`` the output is human-readable (Rich table or detail).
"""

from __future__ import annotations

import json

from tests.e2e.conftest import (
    make_agent,
    make_credential,
    make_environment,
    make_file,
    make_model_registration,
    make_session,
    make_vault,
    runner,
)


class TestJsonOutputAcrossCommands:
    """Every list/get command with --json must emit parseable JSON."""

    def test_agents_list_json(self, mock_api, invoke):
        mock_api.get("/v1/agents").respond(
            json={"data": [make_agent()], "next_page": None}
        )
        result = invoke("agents", "list", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "data" in data

    def test_agents_get_json(self, mock_api, invoke):
        mock_api.get("/v1/agents/agent_cli-test-001").respond(json=make_agent())
        result = invoke("agents", "get", "agent_cli-test-001", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "id" in data

    def test_sessions_list_json(self, mock_api, invoke):
        mock_api.get("/v1/sessions").respond(
            json={"data": [make_session()], "next_page": None}
        )
        result = invoke("sessions", "list", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "data" in data

    def test_sessions_get_json(self, mock_api, invoke):
        mock_api.get("/v1/sessions/sess_cli-test-001").respond(json=make_session())
        result = invoke("sessions", "get", "sess_cli-test-001", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "id" in data

    def test_environments_list_json(self, mock_api, invoke):
        mock_api.get("/v1/environments").respond(
            json={"data": [make_environment()], "next_page": None}
        )
        result = invoke("environments", "list", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "data" in data

    def test_environments_get_json(self, mock_api, invoke):
        mock_api.get("/v1/environments/env_cli-test-001").respond(
            json=make_environment()
        )
        result = invoke("environments", "get", "env_cli-test-001", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "id" in data

    def test_vaults_list_json(self, mock_api, invoke):
        mock_api.get("/v1/vaults").respond(
            json={"data": [make_vault()], "next_page": None}
        )
        result = invoke("vaults", "list", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "data" in data

    def test_vaults_get_json(self, mock_api, invoke):
        mock_api.get("/v1/vaults/vault_cli-test-001").respond(json=make_vault())
        result = invoke("vaults", "get", "vault_cli-test-001", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "id" in data

    def test_models_list_json(self, mock_api, invoke):
        mock_api.get("/v1/models").respond(
            json={"data": [make_model_registration()]}
        )
        result = invoke("models", "list", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "data" in data

    def test_models_available_json(self, mock_api, invoke):
        mock_api.get("/v1/models/available").respond(json={"data": []})
        result = invoke("models", "available", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "data" in data

    def test_files_list_json(self, mock_api, invoke):
        mock_api.get("/v1/files").respond(
            json={"data": [make_file()], "next_page": None}
        )
        result = invoke("files", "list", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "data" in data

    def test_files_get_json(self, mock_api, invoke):
        mock_api.get("/v1/files/file_cli-test-001").respond(json=make_file())
        result = invoke("files", "get", "file_cli-test-001", "--json")
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "id" in data


class TestTableOutputAcrossCommands:
    """Without --json, list commands should produce non-JSON text output."""

    def test_agents_list_table(self, mock_api, invoke):
        mock_api.get("/v1/agents").respond(
            json={"data": [make_agent()], "next_page": None}
        )
        result = invoke("agents", "list")
        assert result.exit_code == 0
        # Must NOT be parseable as JSON
        with __import__("pytest").raises(json.JSONDecodeError):
            json.loads(result.output)

    def test_sessions_list_table(self, mock_api, invoke):
        mock_api.get("/v1/sessions").respond(
            json={"data": [make_session()], "next_page": None}
        )
        result = invoke("sessions", "list")
        assert result.exit_code == 0
        with __import__("pytest").raises(json.JSONDecodeError):
            json.loads(result.output)

    def test_environments_list_table(self, mock_api, invoke):
        mock_api.get("/v1/environments").respond(
            json={"data": [make_environment()], "next_page": None}
        )
        result = invoke("environments", "list")
        assert result.exit_code == 0
        with __import__("pytest").raises(json.JSONDecodeError):
            json.loads(result.output)

    def test_vaults_list_table(self, mock_api, invoke):
        mock_api.get("/v1/vaults").respond(
            json={"data": [make_vault()], "next_page": None}
        )
        result = invoke("vaults", "list")
        assert result.exit_code == 0
        with __import__("pytest").raises(json.JSONDecodeError):
            json.loads(result.output)

    def test_models_list_table(self, mock_api, invoke):
        mock_api.get("/v1/models").respond(
            json={"data": [make_model_registration()]}
        )
        result = invoke("models", "list")
        assert result.exit_code == 0
        with __import__("pytest").raises(json.JSONDecodeError):
            json.loads(result.output)
