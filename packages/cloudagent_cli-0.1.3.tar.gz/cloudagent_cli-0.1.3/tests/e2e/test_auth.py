"""E2E tests for ``cloudagent auth`` commands."""

from __future__ import annotations

import json

from typer.testing import CliRunner

from cloudagent_cli.main import app as cli_app

runner = CliRunner()


class TestAuthLogin:
    def test_login_with_api_key(self, tmp_path, monkeypatch):
        """auth login --api-key writes config and prints success."""
        cfg_file = tmp_path / "config.json"
        monkeypatch.setattr("cloudagent_cli.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("cloudagent_cli.config.CONFIG_FILE", cfg_file)
        # Also patch the auth command's own imports of config funcs
        monkeypatch.setattr(
            "cloudagent_cli.commands.auth.load_config", lambda: {}
        )
        saved = {}
        monkeypatch.setattr(
            "cloudagent_cli.commands.auth.save_config",
            lambda c: saved.update(c),
        )

        result = runner.invoke(
            cli_app,
            ["auth", "login", "--api-key", "cli-test-sk-login"],
        )
        assert result.exit_code == 0
        assert "Config saved" in result.output
        assert saved["api_key"] == "cli-test-sk-login"

    def test_login_with_custom_base_url(self, tmp_path, monkeypatch):
        """auth login --base-url overrides the default."""
        saved = {}
        monkeypatch.setattr("cloudagent_cli.commands.auth.load_config", lambda: {})
        monkeypatch.setattr(
            "cloudagent_cli.commands.auth.save_config",
            lambda c: saved.update(c),
        )

        result = runner.invoke(
            cli_app,
            [
                "auth", "login",
                "--api-key", "cli-test-sk-url",
                "--base-url", "http://custom:9000",
            ],
        )
        assert result.exit_code == 0
        assert saved["base_url"] == "http://custom:9000"

    def test_login_with_default_model(self, tmp_path, monkeypatch):
        """auth login --default-model saves the model preference."""
        saved = {}
        monkeypatch.setattr("cloudagent_cli.commands.auth.load_config", lambda: {})
        monkeypatch.setattr(
            "cloudagent_cli.commands.auth.save_config",
            lambda c: saved.update(c),
        )

        result = runner.invoke(
            cli_app,
            [
                "auth", "login",
                "--api-key", "cli-test-sk-model",
                "--default-model", "qwen-turbo",
            ],
        )
        assert result.exit_code == 0
        assert saved["default_model"] == "qwen-turbo"


class TestAuthStatus:
    def test_status_configured(self, monkeypatch, mock_api):
        """auth status with valid config shows key + base URL."""
        monkeypatch.setattr(
            "cloudagent_cli.commands.auth.load_config",
            lambda: {
                "api_key": "cli-test-sk-0000000000000001",
                "base_url": "https://mock.cloudagent.test",
                "default_model": "qwen3.6-plus",
            },
        )
        # The status command does a connectivity check via list_agents
        mock_api.get("/v1/agents").respond(
            json={"data": [], "next_page": None}
        )
        result = runner.invoke(cli_app, ["auth", "status"])
        assert result.exit_code == 0
        assert "cli-test-sk-" in result.output  # truncated key prefix
        assert "Connection OK" in result.output

    def test_status_not_configured(self, monkeypatch):
        """auth status with no api_key prints error and exits non-zero."""
        monkeypatch.setattr(
            "cloudagent_cli.commands.auth.load_config", lambda: {}
        )
        result = runner.invoke(cli_app, ["auth", "status"])
        assert result.exit_code != 0

    def test_status_connection_failed(self, monkeypatch, mock_api):
        """auth status reports connection failure gracefully."""
        monkeypatch.setattr(
            "cloudagent_cli.commands.auth.load_config",
            lambda: {
                "api_key": "cli-test-sk-status-fail",
                "base_url": "https://mock.cloudagent.test",
            },
        )
        mock_api.get("/v1/agents").respond(status_code=500, json={"detail": "boom"})
        result = runner.invoke(cli_app, ["auth", "status"])
        assert result.exit_code == 0  # status itself succeeds
        assert "Connection failed" in result.output


class TestAuthLogout:
    def test_logout_removes_config(self, monkeypatch):
        """auth logout calls delete_config."""
        deleted = []
        monkeypatch.setattr(
            "cloudagent_cli.commands.auth.delete_config",
            lambda: deleted.append(True),
        )
        result = runner.invoke(cli_app, ["auth", "logout"])
        assert result.exit_code == 0
        assert "Logged out" in result.output
        assert len(deleted) == 1
