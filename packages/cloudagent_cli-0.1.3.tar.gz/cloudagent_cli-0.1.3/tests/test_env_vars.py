"""Tests for ``cloudagent_cli.env_vars`` — static_env_vars validation."""

from __future__ import annotations

import pytest

from cloudagent_cli.env_vars import (
    ENV_VAR_MAX_KEYS,
    EnvVarValidationError,
    merge_env_var_sources,
    parse_env_file,
    parse_kv_pair,
    validate_env_vars_dict,
)


class TestParseKvPair:
    def test_simple(self):
        assert parse_kv_pair("FOO=bar") == ("FOO", "bar")

    def test_value_contains_equals(self):
        assert parse_kv_pair("FOO=a=b=c") == ("FOO", "a=b=c")

    def test_empty_value_allowed(self):
        assert parse_kv_pair("FOO=") == ("FOO", "")

    def test_no_equals_sign(self):
        with pytest.raises(EnvVarValidationError):
            parse_kv_pair("FOO")


class TestValidateEnvVarsDict:
    def test_valid(self):
        d = {"FOO": "v1", "BAR_1": "v2", "_X": "v3"}
        assert validate_env_vars_dict(d) is d

    def test_key_lowercase_rejected(self):
        with pytest.raises(EnvVarValidationError, match="must match"):
            validate_env_vars_dict({"foo": "v"})

    def test_key_starts_with_digit_rejected(self):
        with pytest.raises(EnvVarValidationError, match="must match"):
            validate_env_vars_dict({"1FOO": "v"})

    def test_reserved_exact_key_rejected(self):
        with pytest.raises(EnvVarValidationError, match="reserved"):
            validate_env_vars_dict({"PATH": "/usr/bin"})

    def test_reserved_byok_key_rejected(self):
        with pytest.raises(EnvVarValidationError, match="reserved"):
            validate_env_vars_dict({"ANTHROPIC_API_KEY": "sk-x"})

    def test_lc_prefix_rejected(self):
        with pytest.raises(EnvVarValidationError, match="locale"):
            validate_env_vars_dict({"LC_ALL": "en_US.UTF-8"})

    def test_ca_prefix_rejected(self):
        with pytest.raises(EnvVarValidationError, match="cloudagent"):
            validate_env_vars_dict({"CA_FOO": "x"})

    def test_mcp_bearer_slot_rejected(self):
        with pytest.raises(EnvVarValidationError, match="MCP bearer"):
            validate_env_vars_dict({"MCP_BEARER_1": "x"})

    def test_too_many_keys_rejected(self):
        d = {f"K{i}": "v" for i in range(ENV_VAR_MAX_KEYS + 1)}
        with pytest.raises(EnvVarValidationError, match="at most 32"):
            validate_env_vars_dict(d)

    def test_max_keys_exactly_allowed(self):
        d = {f"K{i}": "v" for i in range(ENV_VAR_MAX_KEYS)}
        # All-caps key names — compliant.
        validate_env_vars_dict(d)

    def test_key_too_long_rejected(self):
        with pytest.raises(EnvVarValidationError, match="128"):
            validate_env_vars_dict({"A" * 129: "v"})

    def test_value_too_long_rejected(self):
        with pytest.raises(EnvVarValidationError, match="32768"):
            validate_env_vars_dict({"FOO": "x" * 32769})

    def test_value_none_allowed(self):
        # Backend PATCH-delete semantics: null value = delete.
        validate_env_vars_dict({"FOO": None})


class TestParseEnvFile:
    def test_basic(self, tmp_path):
        p = tmp_path / "e.env"
        p.write_text("FOO=bar\n# comment\n\nBAZ=qux\n")
        assert parse_env_file(p) == {"FOO": "bar", "BAZ": "qux"}

    def test_quoted_value_strips_quotes(self, tmp_path):
        p = tmp_path / "e.env"
        p.write_text('FOO="hello world"\nBAR=\'x\'\n')
        assert parse_env_file(p) == {"FOO": "hello world", "BAR": "x"}

    def test_missing_file(self, tmp_path):
        with pytest.raises(EnvVarValidationError):
            parse_env_file(tmp_path / "nope.env")

    def test_duplicate_key_rejected(self, tmp_path):
        p = tmp_path / "e.env"
        p.write_text("FOO=1\nFOO=2\n")
        with pytest.raises(EnvVarValidationError, match="duplicate"):
            parse_env_file(p)

    def test_malformed_line_rejected(self, tmp_path):
        p = tmp_path / "e.env"
        p.write_text("NO_EQUALS_SIGN\n")
        with pytest.raises(EnvVarValidationError):
            parse_env_file(p)


class TestMergeEnvVarSources:
    def test_kv_only(self):
        assert merge_env_var_sources(["FOO=bar"], None) == {"FOO": "bar"}

    def test_file_only(self, tmp_path):
        p = tmp_path / "e.env"
        p.write_text("FOO=bar\n")
        assert merge_env_var_sources(None, p) == {"FOO": "bar"}

    def test_kv_overrides_file(self, tmp_path):
        p = tmp_path / "e.env"
        p.write_text("FOO=file\n")
        assert merge_env_var_sources(["FOO=cli"], p) == {"FOO": "cli"}

    def test_empty_rejected(self):
        with pytest.raises(EnvVarValidationError, match="at least one"):
            merge_env_var_sources(None, None)

    def test_merged_validation_runs(self):
        # Invalid key should surface via merge_env_var_sources.
        with pytest.raises(EnvVarValidationError, match="reserved"):
            merge_env_var_sources(["PATH=/x"], None)
