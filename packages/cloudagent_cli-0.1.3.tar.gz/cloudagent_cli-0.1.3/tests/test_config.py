"""Tests for config read/write."""

from __future__ import annotations

import json

from cloudagent_cli.config import delete_config, load_config, save_config


def test_save_and_load(tmp_path, monkeypatch):
    cfg_file = tmp_path / "config.json"
    monkeypatch.setattr("cloudagent_cli.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("cloudagent_cli.config.CONFIG_FILE", cfg_file)

    save_config({"api_key": "sk-test-123", "base_url": "http://localhost:8000"})
    assert cfg_file.exists()
    loaded = load_config()
    assert loaded["api_key"] == "sk-test-123"
    assert loaded["base_url"] == "http://localhost:8000"


def test_load_missing(tmp_path, monkeypatch):
    monkeypatch.setattr("cloudagent_cli.config.CONFIG_FILE", tmp_path / "nope.json")
    assert load_config() == {}


def test_delete(tmp_path, monkeypatch):
    cfg_file = tmp_path / "config.json"
    cfg_file.write_text(json.dumps({"api_key": "x"}))
    monkeypatch.setattr("cloudagent_cli.config.CONFIG_FILE", cfg_file)
    delete_config()
    assert not cfg_file.exists()
