"""CloudAgent CLI entry point."""

from __future__ import annotations

import typer

from cloudagent_cli.commands.agents import app as agents_app
from cloudagent_cli.commands.auth import app as auth_app
from cloudagent_cli.commands.environments import app as environments_app
from cloudagent_cli.commands.files import app as files_app
from cloudagent_cli.commands.sessions import app as sessions_app
from cloudagent_cli.commands.vaults import app as vaults_app

app = typer.Typer(
    name="cloudagent",
    help="CLI for CloudAgent — Anthropic Managed Agents compatible platform.",
    no_args_is_help=True,
)

app.add_typer(auth_app, name="auth", help="Authenticate and manage API configuration.")
app.add_typer(agents_app, name="agents", help="Create, list, and manage agents.")
app.add_typer(sessions_app, name="sessions", help="Create sessions and send messages.")
app.add_typer(environments_app, name="environments", help="Manage execution environments.")
app.add_typer(vaults_app, name="vaults", help="Manage vaults and credentials.")
app.add_typer(files_app, name="files", help="Upload and manage files.")


@app.callback()
def _main_callback() -> None:
    """CloudAgent CLI — manage agents, sessions, environments, vaults, and files."""


if __name__ == "__main__":
    app()
