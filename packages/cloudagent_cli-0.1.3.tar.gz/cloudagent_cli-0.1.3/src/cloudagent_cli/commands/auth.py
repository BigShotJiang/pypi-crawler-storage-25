"""Auth commands — login / status / logout."""

from __future__ import annotations

import typer

from cloudagent_cli.config import (
    DEFAULT_BASE_URL,
    DEFAULT_MODEL,
    delete_config,
    load_config,
    save_config,
)
from cloudagent_cli.output import bail, console

app = typer.Typer(no_args_is_help=True)


@app.command()
def login(
    api_key: str = typer.Option(None, "--api-key", "-k", help="API key (prompted if omitted)."),
    base_url: str = typer.Option(DEFAULT_BASE_URL, "--base-url", "-u", help="API base URL."),
    default_model: str = typer.Option(DEFAULT_MODEL, "--default-model", "-m", help="Default model for agents."),
) -> None:
    """Authenticate and save configuration to ~/.cloudagent/config.json."""
    if not api_key:
        api_key = typer.prompt("API Key")
    if not api_key:
        bail("API key is required.")
    cfg = load_config()
    cfg["api_key"] = api_key
    cfg["base_url"] = base_url
    cfg["default_model"] = default_model
    save_config(cfg)
    console.print("[green]Config saved to ~/.cloudagent/config.json[/green]")


@app.command()
def status() -> None:
    """Display current configuration and verify connectivity."""
    cfg = load_config()
    if not cfg.get("api_key"):
        bail("Not logged in. Run `cloudagent auth login` first.")
    console.print(f"  API Key   : {cfg['api_key'][:12]}...{cfg['api_key'][-4:]}")
    console.print(f"  Base URL  : {cfg.get('base_url', DEFAULT_BASE_URL)}")
    console.print(f"  Model     : {cfg.get('default_model', DEFAULT_MODEL)}")

    # Quick connectivity check
    try:
        from cloudagent_cli.client import CloudAgentClient

        client = CloudAgentClient(api_key=cfg["api_key"], base_url=cfg.get("base_url"))
        client.list_agents(limit=1)
        console.print("[green]Connection OK[/green]")
    except Exception as exc:
        console.print(f"[yellow]Connection failed:[/yellow] {exc}")


@app.command()
def logout() -> None:
    """Remove local configuration."""
    delete_config()
    console.print("Logged out. Config removed.")
