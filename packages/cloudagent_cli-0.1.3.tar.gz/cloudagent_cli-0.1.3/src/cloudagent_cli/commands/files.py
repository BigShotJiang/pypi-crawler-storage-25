"""File commands — upload, list, get."""

from __future__ import annotations

from typing import Optional

import typer

from cloudagent_cli.client import CloudAgentClient, CloudAgentError
from cloudagent_cli.output import bail, print_detail, print_json, print_table

app = typer.Typer(no_args_is_help=True)

JSON_FLAG = typer.Option(False, "--json", "-j", help="Output raw JSON.")

FILE_COLUMNS = ["id", "filename", "content_type", "size_bytes", "created_at"]


def _client() -> CloudAgentClient:
    try:
        return CloudAgentClient()
    except CloudAgentError as e:
        bail(str(e))
        raise


@app.command("upload")
def upload_file(
    path: str = typer.Argument(..., help="Local file path to upload."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Upload a file."""
    client = _client()
    try:
        data = client.upload_file(path)
    except CloudAgentError as e:
        bail(str(e))
        return
    except FileNotFoundError:
        bail(f"File not found: {path}")
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, FILE_COLUMNS)


@app.command("list")
def list_files(
    limit: int = typer.Option(20, "--limit", "-l"),
    page: Optional[str] = typer.Option(None, "--page"),
    output_json: bool = JSON_FLAG,
) -> None:
    """List files."""
    client = _client()
    try:
        data = client.list_files(limit=limit, page=page)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_table(data.get("data", []), FILE_COLUMNS)


@app.command("get")
def get_file(
    file_id: str = typer.Argument(..., help="File ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Get file metadata."""
    client = _client()
    try:
        data = client.get_file(file_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, FILE_COLUMNS)
