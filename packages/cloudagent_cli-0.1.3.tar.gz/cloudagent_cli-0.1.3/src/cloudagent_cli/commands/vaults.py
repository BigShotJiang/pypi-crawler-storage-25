"""Vault and credential commands."""

from __future__ import annotations

from typing import Optional

import typer

from cloudagent_cli.client import CloudAgentClient, CloudAgentError
from cloudagent_cli.env_vars import (
    EnvVarValidationError,
    merge_env_var_sources,
    validate_env_vars_dict,
)
from cloudagent_cli.output import bail, print_detail, print_json, print_table

app = typer.Typer(no_args_is_help=True)

JSON_FLAG = typer.Option(False, "--json", "-j", help="Output raw JSON.")

VAULT_COLUMNS = ["id", "display_name", "created_at"]
CRED_COLUMNS = ["id", "vault_id", "display_name", "created_at"]

_VALID_AUTH_TYPES = {"static_bearer", "mcp_oauth", "static_env_vars"}


def _client() -> CloudAgentClient:
    try:
        return CloudAgentClient()
    except CloudAgentError as e:
        bail(str(e))
        raise


def _build_auth(
    auth_type: str,
    token: Optional[str],
    access_token: Optional[str],
    mcp_server_url: Optional[str],
    env_vars_spec: Optional[list[str]],
    env_vars_file: Optional[str],
) -> dict:
    """Assemble the ``auth`` payload for a credential create/update call.

    Performs the same local validation the backend does so users see
    errors without a round-trip. On invalid input, calls ``bail()`` and
    raises ``typer.Exit(1)``.
    """
    if auth_type not in _VALID_AUTH_TYPES:
        bail(
            f"Unknown auth type: {auth_type}. "
            f"Use one of {sorted(_VALID_AUTH_TYPES)}."
        )
        raise typer.Exit(1)

    if auth_type == "static_bearer":
        if not token:
            bail("--token is required for static_bearer auth type.")
            raise typer.Exit(1)
        if not mcp_server_url:
            bail("--mcp-server-url is required for static_bearer auth type.")
            raise typer.Exit(1)
        return {
            "type": "static_bearer",
            "token": token,
            "mcp_server_url": mcp_server_url,
        }

    if auth_type == "mcp_oauth":
        if not access_token:
            bail("--access-token is required for mcp_oauth auth type.")
            raise typer.Exit(1)
        if not mcp_server_url:
            bail("--mcp-server-url is required for mcp_oauth auth type.")
            raise typer.Exit(1)
        return {
            "type": "mcp_oauth",
            "access_token": access_token,
            "mcp_server_url": mcp_server_url,
        }

    # static_env_vars
    try:
        env_vars = merge_env_var_sources(env_vars_spec, env_vars_file)
    except EnvVarValidationError as e:
        bail(str(e))
        raise typer.Exit(1)
    return {"type": "static_env_vars", "env_vars": env_vars}


# ---------- Vault CRUD ----------


@app.command("create")
def create_vault(
    name: str = typer.Option(..., "--name", "-n", help="Vault display name."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Create a new vault."""
    client = _client()
    try:
        data = client.create_vault(display_name=name)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, VAULT_COLUMNS)


@app.command("list")
def list_vaults(
    limit: int = typer.Option(20, "--limit", "-l"),
    page: Optional[str] = typer.Option(None, "--page"),
    output_json: bool = JSON_FLAG,
) -> None:
    """List vaults."""
    client = _client()
    try:
        data = client.list_vaults(limit=limit, page=page)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_table(data.get("data", []), VAULT_COLUMNS)


@app.command("get")
def get_vault(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Get vault details."""
    client = _client()
    try:
        data = client.get_vault(vault_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data)


@app.command("update")
def update_vault(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    name: Optional[str] = typer.Option(
        None, "--name", "-n", help="New display name."
    ),
    output_json: bool = JSON_FLAG,
) -> None:
    """Update a vault's mutable fields (currently: display_name)."""
    payload: dict = {}
    if name is not None:
        payload["display_name"] = name
    if not payload:
        bail("Nothing to update. Supply --name.")
        return
    client = _client()
    try:
        data = client.update_vault(vault_id, **payload)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, VAULT_COLUMNS)


@app.command("archive")
def archive_vault(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Archive a vault (soft delete — can still be read, cannot be used)."""
    client = _client()
    try:
        data = client.archive_vault(vault_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, VAULT_COLUMNS)


@app.command("delete")
def delete_vault(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Delete a vault permanently."""
    client = _client()
    try:
        data = client.delete_vault(vault_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, ["id", "type"])


# ---------- Credentials ----------


@app.command("credentials-create")
def create_credential(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    display_name: str = typer.Option(
        ..., "--name", "-n", help="Credential display name."
    ),
    auth_type: str = typer.Option(
        ...,
        "--auth-type",
        "-t",
        help="Auth type: static_bearer, mcp_oauth, or static_env_vars.",
    ),
    token: Optional[str] = typer.Option(
        None, "--token", help="Bearer token (for static_bearer)."
    ),
    access_token: Optional[str] = typer.Option(
        None, "--access-token", help="OAuth access token (for mcp_oauth)."
    ),
    mcp_server_url: Optional[str] = typer.Option(
        None,
        "--mcp-server-url",
        "-s",
        help="MCP server URL (required for static_bearer / mcp_oauth).",
    ),
    env_vars: Optional[list[str]] = typer.Option(
        None,
        "--env-var",
        help=(
            "KEY=VALUE env var entry (for static_env_vars). "
            "Repeat the flag for multiple entries."
        ),
    ),
    env_vars_file: Optional[str] = typer.Option(
        None,
        "--env-vars-file",
        help=(
            "Path to a dotenv-subset file (KEY=VALUE per line, "
            "# comments, blank lines skipped) for static_env_vars."
        ),
    ),
    output_json: bool = JSON_FLAG,
) -> None:
    """Create a credential in a vault."""
    auth = _build_auth(
        auth_type, token, access_token, mcp_server_url, env_vars, env_vars_file
    )
    client = _client()
    try:
        data = client.create_credential(
            vault_id, display_name=display_name, auth=auth
        )
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, CRED_COLUMNS)


@app.command("credentials-list")
def list_credentials(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    limit: int = typer.Option(20, "--limit", "-l"),
    page: Optional[str] = typer.Option(None, "--page"),
    output_json: bool = JSON_FLAG,
) -> None:
    """List credentials in a vault."""
    client = _client()
    try:
        data = client.list_credentials(vault_id, limit=limit, page=page)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_table(data.get("data", []), CRED_COLUMNS)


@app.command("credentials-get")
def get_credential(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    cred_id: str = typer.Argument(..., help="Credential ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Get credential details (sensitive fields are masked)."""
    client = _client()
    try:
        data = client.get_credential(vault_id, cred_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data)


@app.command("credentials-update")
def update_credential(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    cred_id: str = typer.Argument(..., help="Credential ID."),
    display_name: Optional[str] = typer.Option(
        None, "--name", "-n", help="New credential display name."
    ),
    auth_type: Optional[str] = typer.Option(
        None,
        "--auth-type",
        "-t",
        help=(
            "If set, replaces the auth payload. "
            "One of static_bearer, mcp_oauth, static_env_vars."
        ),
    ),
    token: Optional[str] = typer.Option(
        None, "--token", help="Bearer token (for static_bearer)."
    ),
    access_token: Optional[str] = typer.Option(
        None, "--access-token", help="OAuth access token (for mcp_oauth)."
    ),
    mcp_server_url: Optional[str] = typer.Option(
        None, "--mcp-server-url", "-s", help="MCP server URL."
    ),
    env_vars: Optional[list[str]] = typer.Option(
        None,
        "--env-var",
        help="KEY=VALUE env var entry (for static_env_vars).",
    ),
    env_vars_file: Optional[str] = typer.Option(
        None,
        "--env-vars-file",
        help="Path to dotenv-subset file for static_env_vars.",
    ),
    output_json: bool = JSON_FLAG,
) -> None:
    """Update a credential. ``--auth-type`` triggers a full auth replacement."""
    payload: dict = {}
    if display_name is not None:
        payload["display_name"] = display_name
    if auth_type is not None:
        payload["auth"] = _build_auth(
            auth_type,
            token,
            access_token,
            mcp_server_url,
            env_vars,
            env_vars_file,
        )
    if not payload:
        bail("Nothing to update. Supply --name and/or --auth-type.")
        return
    client = _client()
    try:
        data = client.update_credential(vault_id, cred_id, **payload)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, CRED_COLUMNS)


@app.command("credentials-archive")
def archive_credential(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    cred_id: str = typer.Argument(..., help="Credential ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Archive a credential (soft delete)."""
    client = _client()
    try:
        data = client.archive_credential(vault_id, cred_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, CRED_COLUMNS)


@app.command("credentials-delete")
def delete_credential(
    vault_id: str = typer.Argument(..., help="Vault ID."),
    cred_id: str = typer.Argument(..., help="Credential ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Delete a credential permanently."""
    client = _client()
    try:
        data = client.delete_credential(vault_id, cred_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, ["id", "type"])


# Re-export for local client-side validation tests.
__all__ = [
    "app",
    "validate_env_vars_dict",
]
