"""Environment commands."""

from __future__ import annotations

from typing import Optional

import typer

from cloudagent_cli.client import CloudAgentClient, CloudAgentError
from cloudagent_cli.output import bail, print_detail, print_json, print_table

app = typer.Typer(no_args_is_help=True)

JSON_FLAG = typer.Option(False, "--json", "-j", help="Output raw JSON.")

ENV_COLUMNS = ["id", "name", "description", "created_at"]


def _client() -> CloudAgentClient:
    try:
        return CloudAgentClient()
    except CloudAgentError as e:
        bail(str(e))
        raise


@app.command("create")
def create_environment(
    name: str = typer.Option(..., "--name", "-n", help="Environment name."),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    output_json: bool = JSON_FLAG,
) -> None:
    """Create a new environment."""
    client = _client()
    kwargs: dict = {"name": name}
    if description:
        kwargs["description"] = description
    try:
        data = client.create_environment(**kwargs)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, ENV_COLUMNS)


@app.command("list")
def list_environments(
    limit: int = typer.Option(20, "--limit", "-l"),
    page: Optional[str] = typer.Option(None, "--page"),
    output_json: bool = JSON_FLAG,
) -> None:
    """List environments."""
    client = _client()
    try:
        data = client.list_environments(limit=limit, page=page)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_table(data.get("data", []), ENV_COLUMNS)


@app.command("get")
def get_environment(
    env_id: str = typer.Argument(..., help="Environment ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Get environment details."""
    client = _client()
    try:
        data = client.get_environment(env_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data)
