"""Agent commands."""

from __future__ import annotations

from typing import Optional

import typer

from cloudagent_cli.client import CloudAgentClient, CloudAgentError
from cloudagent_cli.output import bail, print_detail, print_json, print_table

app = typer.Typer(no_args_is_help=True)

JSON_FLAG = typer.Option(False, "--json", "-j", help="Output raw JSON.")


def _client() -> CloudAgentClient:
    try:
        return CloudAgentClient()
    except CloudAgentError as e:
        bail(str(e))
        raise  # unreachable


AGENT_COLUMNS = ["id", "name", "model", "version", "created_at"]


@app.command("create")
def create_agent(
    name: str = typer.Option(..., "--name", "-n", help="Agent name."),
    model: str = typer.Option("qwen3.6-plus", "--model", "-m", help="Model identifier."),
    system: Optional[str] = typer.Option(None, "--system", "-s", help="System prompt."),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Agent description."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Create a new agent."""
    client = _client()
    kwargs: dict = {"name": name, "model": model}
    if system:
        kwargs["system"] = system
    if description:
        kwargs["description"] = description
    try:
        data = client.create_agent(**kwargs)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, AGENT_COLUMNS)


@app.command("list")
def list_agents(
    limit: int = typer.Option(20, "--limit", "-l"),
    page: Optional[str] = typer.Option(None, "--page"),
    output_json: bool = JSON_FLAG,
) -> None:
    """List agents."""
    client = _client()
    try:
        data = client.list_agents(limit=limit, page=page)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_table(data.get("data", []), AGENT_COLUMNS)


@app.command("get")
def get_agent(
    agent_id: str = typer.Argument(..., help="Agent ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Get agent details."""
    client = _client()
    try:
        data = client.get_agent(agent_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data)


@app.command("update")
def update_agent(
    agent_id: str = typer.Argument(..., help="Agent ID."),
    version: int = typer.Option(..., "--version", "-v", help="Current version (CAS)."),
    name: Optional[str] = typer.Option(None, "--name", "-n"),
    system: Optional[str] = typer.Option(None, "--system", "-s"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    model: Optional[str] = typer.Option(None, "--model", "-m"),
    output_json: bool = JSON_FLAG,
) -> None:
    """Update an agent (requires current version for optimistic concurrency)."""
    client = _client()
    kwargs: dict = {"version": version}
    if name:
        kwargs["name"] = name
    if system:
        kwargs["system"] = system
    if description:
        kwargs["description"] = description
    if model:
        kwargs["model"] = model
    try:
        data = client.update_agent(agent_id, **kwargs)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, AGENT_COLUMNS)


@app.command("archive")
def archive_agent(
    agent_id: str = typer.Argument(..., help="Agent ID."),
    output_json: bool = JSON_FLAG,
) -> None:
    """Archive an agent."""
    client = _client()
    try:
        data = client.archive_agent(agent_id)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        print_detail(data, AGENT_COLUMNS)


@app.command("versions")
def list_versions(
    agent_id: str = typer.Argument(..., help="Agent ID."),
    limit: int = typer.Option(20, "--limit", "-l"),
    output_json: bool = JSON_FLAG,
) -> None:
    """List agent versions."""
    client = _client()
    try:
        data = client.list_agent_versions(agent_id, limit=limit)
    except CloudAgentError as e:
        bail(str(e))
        return
    if output_json:
        print_json(data)
    else:
        cols = ["id", "version", "changed_fields", "created_at"]
        print_table(data.get("data", []), cols)
