"""HTTP client wrapper for CloudAgent API."""

from __future__ import annotations

from typing import Any

import httpx

from cloudagent_cli.config import get_api_key, get_base_url


class CloudAgentError(Exception):
    """Raised when the API returns a non-2xx status."""

    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class CloudAgentClient:
    """Thin wrapper around httpx for CloudAgent API calls."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self.api_key = api_key or get_api_key()
        self.base_url = base_url or get_base_url()
        if not self.api_key:
            raise CloudAgentError(0, "No API key configured. Run `cloudagent auth login` first.")
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
                "anthropic-beta": "managed-agents-2026-04-01",
            },
            timeout=30.0,
        )

    def _handle(self, resp: httpx.Response) -> Any:
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise CloudAgentError(resp.status_code, str(detail))
        if resp.status_code == 204:
            return None
        return resp.json()

    # --- Agents ---

    def create_agent(self, **kwargs: Any) -> dict[str, Any]:
        return self._handle(self._client.post("/v1/agents", json=kwargs, params={"beta": "true"}))

    def list_agents(self, limit: int = 20, page: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "beta": "true"}
        if page:
            params["page"] = page
        return self._handle(self._client.get("/v1/agents", params=params))

    def get_agent(self, agent_id: str) -> dict[str, Any]:
        return self._handle(self._client.get(f"/v1/agents/{agent_id}", params={"beta": "true"}))

    def update_agent(self, agent_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._handle(self._client.post(f"/v1/agents/{agent_id}", json=kwargs, params={"beta": "true"}))

    def archive_agent(self, agent_id: str) -> dict[str, Any]:
        return self._handle(self._client.post(f"/v1/agents/{agent_id}/archive", params={"beta": "true"}))

    def list_agent_versions(self, agent_id: str, limit: int = 20) -> dict[str, Any]:
        return self._handle(self._client.get(f"/v1/agents/{agent_id}/versions", params={"limit": limit, "beta": "true"}))

    # --- Sessions ---

    def create_session(self, **kwargs: Any) -> dict[str, Any]:
        return self._handle(self._client.post("/v1/sessions", json=kwargs, params={"beta": "true"}))

    def list_sessions(self, limit: int = 20, page: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "beta": "true"}
        if page:
            params["page"] = page
        return self._handle(self._client.get("/v1/sessions", params=params))

    def get_session(self, session_id: str) -> dict[str, Any]:
        return self._handle(self._client.get(f"/v1/sessions/{session_id}", params={"beta": "true"}))

    def update_session(self, session_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._handle(self._client.post(
            f"/v1/sessions/{session_id}",
            json=kwargs,
            params={"beta": "true"},
        ))

    def send_events(self, session_id: str, events: list[dict[str, Any]]) -> dict[str, Any]:
        return self._handle(self._client.post(
            f"/v1/sessions/{session_id}/events",
            json={"events": events},
            params={"beta": "true"},
        ))

    def list_events(self, session_id: str, limit: int = 50, page: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "beta": "true"}
        if page:
            params["page"] = page
        return self._handle(self._client.get(f"/v1/sessions/{session_id}/events", params=params))

    # --- Environments ---

    def create_environment(self, **kwargs: Any) -> dict[str, Any]:
        return self._handle(self._client.post("/v1/environments", json=kwargs, params={"beta": "true"}))

    def list_environments(self, limit: int = 20, page: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "beta": "true"}
        if page:
            params["page"] = page
        return self._handle(self._client.get("/v1/environments", params=params))

    def get_environment(self, env_id: str) -> dict[str, Any]:
        return self._handle(self._client.get(f"/v1/environments/{env_id}", params={"beta": "true"}))

    # --- Vaults ---

    def create_vault(self, **kwargs: Any) -> dict[str, Any]:
        return self._handle(self._client.post("/v1/vaults", json=kwargs, params={"beta": "true"}))

    def list_vaults(self, limit: int = 20, page: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "beta": "true"}
        if page:
            params["page"] = page
        return self._handle(self._client.get("/v1/vaults", params=params))

    def get_vault(self, vault_id: str) -> dict[str, Any]:
        return self._handle(self._client.get(f"/v1/vaults/{vault_id}", params={"beta": "true"}))

    def update_vault(self, vault_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._handle(self._client.post(
            f"/v1/vaults/{vault_id}",
            json=kwargs,
            params={"beta": "true"},
        ))

    def archive_vault(self, vault_id: str) -> dict[str, Any]:
        return self._handle(self._client.post(
            f"/v1/vaults/{vault_id}/archive",
            params={"beta": "true"},
        ))

    def delete_vault(self, vault_id: str) -> dict[str, Any]:
        return self._handle(self._client.delete(
            f"/v1/vaults/{vault_id}",
            params={"beta": "true"},
        ))

    # --- Vault Credentials ---

    def create_credential(self, vault_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._handle(self._client.post(f"/v1/vaults/{vault_id}/credentials", json=kwargs, params={"beta": "true"}))

    def list_credentials(self, vault_id: str, limit: int = 20, page: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "beta": "true"}
        if page:
            params["page"] = page
        return self._handle(self._client.get(f"/v1/vaults/{vault_id}/credentials", params=params))

    def get_credential(self, vault_id: str, cred_id: str) -> dict[str, Any]:
        return self._handle(self._client.get(
            f"/v1/vaults/{vault_id}/credentials/{cred_id}",
            params={"beta": "true"},
        ))

    def update_credential(
        self, vault_id: str, cred_id: str, **kwargs: Any
    ) -> dict[str, Any]:
        return self._handle(self._client.post(
            f"/v1/vaults/{vault_id}/credentials/{cred_id}",
            json=kwargs,
            params={"beta": "true"},
        ))

    def archive_credential(
        self, vault_id: str, cred_id: str
    ) -> dict[str, Any]:
        return self._handle(self._client.post(
            f"/v1/vaults/{vault_id}/credentials/{cred_id}/archive",
            params={"beta": "true"},
        ))

    def delete_credential(
        self, vault_id: str, cred_id: str
    ) -> dict[str, Any]:
        return self._handle(self._client.delete(
            f"/v1/vaults/{vault_id}/credentials/{cred_id}",
            params={"beta": "true"},
        ))

    # --- Models ---

    def register_model(self, **kwargs: Any) -> dict[str, Any]:
        return self._handle(self._client.post("/v1/models", json=kwargs))

    def list_models(self) -> dict[str, Any]:
        return self._handle(self._client.get("/v1/models"))

    def get_available_models(self) -> dict[str, Any]:
        return self._handle(self._client.get("/v1/models/available"))

    # --- Files ---

    def upload_file(self, filepath: str) -> dict[str, Any]:
        import mimetypes
        from pathlib import Path

        p = Path(filepath)
        ct = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        with open(p, "rb") as f:
            resp = self._client.post(
                "/v1/files",
                files={"file": (p.name, f, ct)},
                params={"beta": "true"},
            )
        return self._handle(resp)

    def list_files(self, limit: int = 20, page: str | None = None) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "beta": "true"}
        if page:
            params["page"] = page
        return self._handle(self._client.get("/v1/files", params=params))

    def get_file(self, file_id: str) -> dict[str, Any]:
        return self._handle(self._client.get(f"/v1/files/{file_id}", params={"beta": "true"}))
