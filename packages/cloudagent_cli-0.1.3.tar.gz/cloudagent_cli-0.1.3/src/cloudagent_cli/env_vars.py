"""Client-side validation for ``static_env_vars`` credential auth type.

Rules are a 1:1 mirror of backend
``backend/src/cloudagent/schemas/vault.py`` — specifically:

- ``_ENV_VAR_NAME_RE``         = ``^[A-Z_][A-Z0-9_]*$``
- ``_MCP_BEARER_RE``           = ``^MCP_BEARER_\\d+$``
- ``_RESERVED_EXACT_ENV_KEYS`` — platform-reserved exact names
- ``ENV_VAR_MAX_KEYS``         = 32
- ``ENV_VAR_MAX_KEY_LEN``      = 128
- ``ENV_VAR_MAX_VALUE_LEN``    = 32768 (32KB)
- Prefix reservations: ``LC_*`` (locale), ``CA_*`` (cloudagent platform)

CLI validates before shipping the request so the user sees errors locally
instead of a 422 from the API. If backend rules change, **update this file
to stay in sync** — we deliberately duplicate the list rather than import
from the backend (CLI is an independent PyPI package; backend source is
not guaranteed to be present at runtime).

Synced from backend/src/cloudagent/schemas/vault.py as of 2026-04-22
(M3 S31).
"""

from __future__ import annotations

import re
from pathlib import Path

# -- regexes --------------------------------------------------------------

_ENV_VAR_NAME_RE = re.compile(r"^[A-Z_][A-Z0-9_]*$")
_MCP_BEARER_RE = re.compile(r"^MCP_BEARER_\d+$")

# -- reserved keys (exact match) ------------------------------------------
# Synced from backend `_RESERVED_EXACT_ENV_KEYS`.

_RESERVED_EXACT_ENV_KEYS: frozenset[str] = frozenset({
    "PATH", "HOME", "USER", "SHELL", "PWD", "TERM", "LANG",
    "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL",
    "OPENAI_API_KEY", "OPENAI_BASE_URL",
    "DASHSCOPE_API_KEY", "DASHSCOPE_BASE_URL",
    "DEEPSEEK_API_KEY", "DEEPSEEK_BASE_URL",
    "GOOGLE_API_KEY", "GOOGLE_BASE_URL",
    "MISTRAL_API_KEY", "MISTRAL_BASE_URL",
})

# -- limits ---------------------------------------------------------------

ENV_VAR_MAX_KEYS = 32
ENV_VAR_MAX_KEY_LEN = 128
ENV_VAR_MAX_VALUE_LEN = 32768


class EnvVarValidationError(ValueError):
    """Raised when a ``--env-var`` / env-file entry is invalid."""


def _validate_env_var_key(key: str) -> None:
    """Raise :class:`EnvVarValidationError` if *key* is not a legal env-var
    name for a ``static_env_vars`` credential.

    Mirrors backend ``_validate_env_var_key``.
    """
    if not isinstance(key, str) or not key:
        raise EnvVarValidationError("env_vars key must be a non-empty string")
    if len(key) > ENV_VAR_MAX_KEY_LEN:
        raise EnvVarValidationError(
            f"env_vars key exceeds {ENV_VAR_MAX_KEY_LEN} chars"
        )
    if not _ENV_VAR_NAME_RE.match(key):
        raise EnvVarValidationError(
            f"env_vars key '{key}' must match ^[A-Z_][A-Z0-9_]*$"
        )
    if key in _RESERVED_EXACT_ENV_KEYS:
        raise EnvVarValidationError(
            f"env_vars key '{key}' is reserved by the platform"
        )
    if key.startswith("LC_"):
        raise EnvVarValidationError(
            f"env_vars key '{key}' (LC_* is locale-reserved)"
        )
    if key.startswith("CA_"):
        raise EnvVarValidationError(
            f"env_vars key '{key}' (CA_* is cloudagent-platform-reserved)"
        )
    if _MCP_BEARER_RE.match(key):
        raise EnvVarValidationError(
            f"env_vars key '{key}' conflicts with MCP bearer slots"
        )


def validate_env_vars_dict(
    v: dict[str, str | None],
) -> dict[str, str | None]:
    """Validate a full env_vars dict. Mirrors backend ``validate_env_vars_dict``.

    Returns the same dict unchanged on success; raises
    :class:`EnvVarValidationError` otherwise.
    """
    if len(v) > ENV_VAR_MAX_KEYS:
        raise EnvVarValidationError(
            f"env_vars may contain at most {ENV_VAR_MAX_KEYS} keys"
        )
    for k, val in v.items():
        _validate_env_var_key(k)
        if val is None:
            continue
        if not isinstance(val, str):
            raise EnvVarValidationError(
                f"env_vars value for '{k}' must be a string or null"
            )
        if len(val) > ENV_VAR_MAX_VALUE_LEN:
            raise EnvVarValidationError(
                f"env_vars value for '{k}' exceeds "
                f"{ENV_VAR_MAX_VALUE_LEN} chars"
            )
    return v


# -- parsers --------------------------------------------------------------


def parse_kv_pair(spec: str) -> tuple[str, str]:
    """Parse a single ``KEY=VALUE`` CLI spec. Raises if malformed.

    The value part may contain ``=`` (split only on the first ``=``).
    Empty value is permitted (``KEY=``). ``KEY`` alone (no ``=``) is not.
    """
    if "=" not in spec:
        raise EnvVarValidationError(
            f"--env-var must be KEY=VALUE, got {spec!r}"
        )
    key, value = spec.split("=", 1)
    key = key.strip()
    # Value kept verbatim — user's choice whether to trim surrounding spaces.
    return key, value


def parse_env_file(path: str | Path) -> dict[str, str]:
    """Parse a dotenv-subset file: each line ``KEY=VALUE``, ``#`` comments,
    blank lines skipped. Surrounding single/double quotes on the value are
    stripped (matching common dotenv behaviour).

    Returns a dict. Does **not** call :func:`validate_env_vars_dict`; the
    caller is expected to.
    """
    p = Path(path)
    if not p.is_file():
        raise EnvVarValidationError(
            f"--env-vars-file: {p} is not a regular file"
        )
    out: dict[str, str] = {}
    for lineno, raw in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise EnvVarValidationError(
                f"{p}:{lineno}: expected KEY=VALUE, got {raw!r}"
            )
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        # Strip matching surrounding quotes (common dotenv).
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        if key in out:
            raise EnvVarValidationError(
                f"{p}:{lineno}: duplicate key {key!r}"
            )
        out[key] = value
    return out


def merge_env_var_sources(
    kv_specs: list[str] | None,
    env_file: str | Path | None,
) -> dict[str, str]:
    """Combine ``--env-var`` flags and optional ``--env-vars-file`` into a
    single dict. ``--env-var`` entries override file entries on collision.

    Raises :class:`EnvVarValidationError` on parse/validation failure.
    Runs :func:`validate_env_vars_dict` before returning.
    """
    merged: dict[str, str] = {}
    if env_file is not None:
        merged.update(parse_env_file(env_file))
    if kv_specs:
        for spec in kv_specs:
            key, value = parse_kv_pair(spec)
            merged[key] = value
    if not merged:
        raise EnvVarValidationError(
            "static_env_vars requires at least one KEY=VALUE "
            "(via --env-var or --env-vars-file)"
        )
    validate_env_vars_dict(merged)  # type: ignore[arg-type]
    return merged
