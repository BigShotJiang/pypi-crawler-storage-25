"""Shared output helpers — table vs JSON rendering."""

from __future__ import annotations

import json
import sys
from typing import Any, Sequence

from rich.console import Console
from rich.table import Table

console = Console()
err_console = Console(stderr=True)


def print_json(data: Any) -> None:
    """Dump raw JSON to stdout."""
    print(json.dumps(data, indent=2, ensure_ascii=False, default=str))


def print_table(
    rows: Sequence[dict[str, Any]],
    columns: Sequence[str],
    *,
    title: str | None = None,
) -> None:
    """Render a rich table to the terminal."""
    table = Table(title=title, show_lines=False)
    for col in columns:
        table.add_column(col)
    for row in rows:
        table.add_row(*[str(row.get(col, "")) for col in columns])
    console.print(table)


def print_detail(data: dict[str, Any], fields: Sequence[str] | None = None) -> None:
    """Print key-value pairs for a single record."""
    keys = fields or list(data.keys())
    max_key = max(len(k) for k in keys) if keys else 0
    for k in keys:
        v = data.get(k, "")
        console.print(f"  [bold]{k:<{max_key}}[/bold]  {v}")


def print_error(msg: str) -> None:
    err_console.print(f"[red]Error:[/red] {msg}")


def bail(msg: str, code: int = 1) -> None:
    """Print error and exit."""
    print_error(msg)
    sys.exit(code)
