"""Configuration management — read/write ~/.cloudagent/config.json."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

CONFIG_DIR = Path.home() / ".cloudagent"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_BASE_URL = "https://api.cloudagent.chat"
DEFAULT_MODEL = "qwen3.6-plus"


def _ensure_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict[str, Any]:
    """Load config from disk. Returns empty dict if missing."""
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def save_config(cfg: dict[str, Any]) -> None:
    """Persist config to disk."""
    _ensure_dir()
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def delete_config() -> None:
    """Remove the config file."""
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()


def get_api_key() -> str | None:
    return load_config().get("api_key")


def get_base_url() -> str:
    return load_config().get("base_url", DEFAULT_BASE_URL)


def get_default_model() -> str:
    return load_config().get("default_model", DEFAULT_MODEL)
