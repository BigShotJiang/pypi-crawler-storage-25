"""CloudAgent CLI — command-line interface for the CloudAgent platform."""

__version__ = "0.1.0"
