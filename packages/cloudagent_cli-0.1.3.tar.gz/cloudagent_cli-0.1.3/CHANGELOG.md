# Changelog

## 0.1.2 — 2026-04-22

Aligned with backend M3 S31 (static_env_vars vault credentials).

### Added

- **`static_env_vars` credential auth type.** `vaults credentials-create`
  / `credentials-update` now accept `--auth-type static_env_vars` with
  `--env-var KEY=VALUE` (repeatable) and/or `--env-vars-file path.env`
  (dotenv-subset: `KEY=VALUE` per line, `#` comments, blank lines
  skipped, surrounding quotes stripped).
- **Client-side validation** for `static_env_vars`, mirroring backend
  rules in `backend/src/cloudagent/schemas/vault.py`:
  - key regex `^[A-Z_][A-Z0-9_]*$`, length ≤ 128
  - value length ≤ 32 KB
  - at most 32 keys per credential
  - reserved exact keys (`PATH`, `HOME`, `ANTHROPIC_API_KEY`, …) and
    prefix reservations (`LC_*`, `CA_*`) and `MCP_BEARER_\d+` slots
- **Vault write commands.** `vaults update`, `vaults archive`,
  `vaults delete`.
- **Credential write commands.** `vaults credentials-get`,
  `credentials-update`, `credentials-archive`, `credentials-delete`.
- **Session vault binding.** `sessions create --vault-id VAULT_ID`
  (repeatable, max 32). `sessions update` introduced with `--title`
  and `--vault-id`.

### Client

- `CloudAgentClient` gains `update_session`, `update_vault`,
  `archive_vault`, `delete_vault`, `get_credential`,
  `update_credential`, `archive_credential`, `delete_credential`.

## 0.1.1 — 2026-04-16

- Three field-mapping fixes + version bump.

## 0.1.0

- Initial release.
