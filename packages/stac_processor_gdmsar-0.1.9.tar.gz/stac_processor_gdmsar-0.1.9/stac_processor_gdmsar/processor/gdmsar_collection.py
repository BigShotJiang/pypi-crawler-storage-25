import logging
import os
import pystac

import stac_processor_gdmsar.metadata.common_metadata as metadata
import stac_processor_gdmsar.metadata.templates as templates
from stac_processor_gdmsar.processor.gdmsar_catalog import GDMCatalog
from stac_processor_gdmsar.processor.gdmsar_item import GDMItem

logger = logging.getLogger(__name__)


class GDMCollection(GDMCatalog):
    def __init__(self, main_id: str, folder_name: str, files: list[str], title: str, uuid: str = None,
                 codes: list[str] = [], geometry: str = "", date: str = "", resolution: str = "", 
                 child_collections: list["GDMCollection"] = [], child_items: list[GDMItem] = [], 
                 template_list: list[str] = [], default_keywords: list[str] = [], is_parent_collection: bool = False) -> None:
        self.folder_name = folder_name
        self.file_name = "collection.json"
        self.date = date
        self.main_id = main_id
        extra_fields = {"uuid": uuid} # add the uuid as an extra field, to make it easier to find the corresponding collection for a given product source
        if is_parent_collection: 
            self.stac_id = main_id
        else:
            self.stac_id = f"{self.main_id}_{geometry}_{folder_name}" if geometry != "" else f"{self.main_id}_{folder_name}"
            extra_fields["parent_id"] = main_id
        self.title = title
        # remove the children who have no stac object
        self.child_collections = [collection for collection in child_collections if collection.stac_object is not None]
        self.child_items = []
        for item in child_items:
            item.generate_stac_object(self.stac_id)
            if item.stac_object is not None:
                self.child_items.append(item)
        # the following requires the child items to be created
        self.processing_id = self.get_processing_id()
        assets = templates.get_assets(files, codes, geometry, date, resolution, _id=self.stac_id, _processing_id=self.processing_id)
        self.keywords = self.get_keywords(default_keywords, files, template_list, codes, geometry)

        # do not create the stac object if there are no child items, no child collections and no assets
        if len(self.child_items) == 0 and len(self.child_collections) == 0 and len(assets) == 0:
            logger.debug(f"Not creating stac collection for {self.stac_id} because it has no child items, no child collections and no assets")
            return

        # use the children to create the stac collection
        self.stac_object = pystac.Collection(
            id=self.stac_id, 
            description=templates.read_template(template_list[0], _id=self.stac_id, _geometry=geometry, _processing_id=self.processing_id, date=date) if len(template_list) > 0 else "",
            extent=self.get_extent(),
            title=self.title, 
            license=metadata.license_name,
            keywords=self.keywords,
            providers=metadata.providers,
            summaries=None, # will be set later, after all the items are created
            extra_fields=extra_fields, # if we want to add more fields at the top level of the collection
            assets=assets if len(assets) > 0 else None, 
            catalog_type=pystac.CatalogType.SELF_CONTAINED,
        )
        # add links to the stac collection
        self.add_common_links()
        logger.debug(f"Stac collection {self.stac_id} created with {len(assets)} assets, {len(child_collections)} child collections and {len(child_items)} child items")

    def get_processing_id(self):
        # search in the child items for a processing_id, quit as soon as we find one
        for item in self.child_items:
            if item.processing_id is not None and item.processing_id != "":
                return item.processing_id
        # if no processing_id is found, search in the child collections, and so on recursively
        for collection in self.child_collections:
            processing_id = collection.get_processing_id()
            if processing_id is not None and processing_id != "":
                return processing_id
        return "" # this can only happen if there are no children

    def get_keywords(self, default_keywords: list[str] = [], files: list[str] = [], template_list: list[str] = [], codes: list[str] = [], geometry: str = "") -> list[str]:
        # keywords can come from different sources: the type of collection, the templates, the geometry, an information in a filename, etc.
        keywords = set()
        # add the default keywords
        keywords.update(default_keywords)
        # add the keywords from the templates
        for template in template_list:
            template_keywords = templates.get_keywords_from_template(template, _id=self.stac_id, _geometry=geometry, _processing_id=self.processing_id, date=self.date)
            if template_keywords is not None: keywords.update(template_keywords)
        # add the keywords from the code and geometry
        if len(codes) > 0 and geometry != "":
            code_geometry_keywords = templates.get_keywords(files, codes, geometry, _id=self.stac_id, _processing_id=self.processing_id, date=self.date)
            if code_geometry_keywords is not None: keywords.update(code_geometry_keywords)
        # return a list of keywords without duplicates
        return list(keywords)

    def get_child_items(self) -> list[GDMItem]:
        child_items = []
        # only return the children who have a stac object
        for item in self.child_items:
            if item.stac_object is not None:
                child_items.append(item.stac_object)
        for collection in self.child_collections:
            if collection.stac_object is not None:
                child_items.extend(collection.get_child_items())
        return child_items
    
    def get_extent(self):
        # if there are no child items, the extent will be like "extent": {"spatial": {"bbox": [[null,null,null,null]]},"temporal": {"interval": [[null,null]]}}
        # it feels wrong, but it's better to have a correct extent with null values than to have an extent with empty lists
        children = self.get_child_items()
        # if len(children) == 0:
        #     return pystac.Extent(spatial=pystac.SpatialExtent(bboxes=[]), temporal=pystac.TemporalExtent(intervals=[]))
        # else:
        #     return pystac.Extent.from_items(children)
        return pystac.Extent.from_items(children)

    def _clean_summary_lists(self, lists: dict[str, list]) -> dict[str, list]:
        # Children summaries contain arrays with potentially shared values for multiple items. Specifications require to merge these arrays into a single array with unique elements.
        # cf. https://github.com/radiantearth/stac-spec/blob/master/collection-spec/collection-spec.md#summaries
        def make_hashable(e):
            if isinstance(e, dict): return tuple(sorted((k, make_hashable(v)) for k, v in e.items()))
            elif isinstance(e, (list, tuple)): return tuple(make_hashable(x) for x in e)
            return e

        def remove_duplicates(my_list):
            seen = set()
            result = []
            for item in my_list:
                hashable = make_hashable(item)
                if hashable not in seen:
                    seen.add(hashable)
                    result.append(item)
            return result

        cleaned_summary_lists = {}
        for key in lists:
            cleaned_summary_lists[key] = remove_duplicates(lists[key])
        return cleaned_summary_lists

    def get_summary(self):
        summarizer = pystac.summaries.Summarizer()
        items = self.get_child_items()
        summary = summarizer.summarize(items)
        # remove duplicates in the lists of the summary
        summary.lists = self._clean_summary_lists(summary.lists)
        return summary

    def update_keywords(self, keywords: list[str]):
        # add the keywords from the parent collection to the existing keywords, without duplicates
        current_keywords = set(self.keywords)
        parent_keywords = set(keywords)
        self.keywords = list(current_keywords.union(parent_keywords))

    def get_child_relative_path(self, child_href: str) -> str:
        if self.stac_object is None or child_href is None: return None
        # get the href from the current stac object
        href = self.stac_object.get_self_href()
        # remove the file name to get the directory
        directory = os.path.dirname(href)
        # replace that directory with a "." to get the relative path from this collection to the child item or collection
        return child_href.replace(directory, ".")

    def check_extent(self):
        # an extent can be empty when a collection has just a list of assets, but no child items and no child collections
        # an empty extent contains bboxes and intervals with null values
        # this is valid according to the stac specification, but it creates validation errors with some stac validators, so we need to clean the extent in this case
        # extents cannot be removed before because they are needed to create the extent of their parents

        def is_null_or_inf(array):
            for element in array:
                if element is not None and element != float("inf") and element != float("-inf"):
                    return False
            return True

        # return if the objects are not present, it avoids having lots of nested if statements
        if self.stac_object is None or self.stac_object.extent is None: return
        if self.stac_object.extent.spatial is None or self.stac_object.extent.spatial.bboxes is None: return
        if self.stac_object.extent.temporal is None or self.stac_object.extent.temporal.intervals is None: return
        if len(self.stac_object.extent.spatial.bboxes) == 0 or len(self.stac_object.extent.temporal.intervals) == 0: return

        # test if the bboxes are empty, and if they contain real values (not null, not inf)
        if is_null_or_inf(self.stac_object.extent.spatial.bboxes[0]) or is_null_or_inf(self.stac_object.extent.temporal.intervals[0]):
            logger.warning(f"The extent of collection '{self.stac_object.id}' contains null or inf values.")
            # print(f"Warning: the extent of collection {self.stac_object.id} contains null or inf values.")
            # the next lines would work here, but the stac file would later be impossible to open
            # self.stac_object.extent.spatial.bboxes = []
            # self.stac_object.extent.temporal.intervals = []


    def update_stac(self, base_path: str = "", keywords: list[str] = []):
        # this function will diffuse some information to its children, such as  keywords and paths
        # add the keywords from the parent to the current collection
        self.update_keywords(keywords)
        # set self href for the current collection
        self.set_href(base_path)
        # clear the extent if it contains null values, to avoid validation errors
        self.check_extent()
        # create child links for all child collections
        for collection in self.child_collections:
            if collection.stac_object is not None:
                # update the child collections recursively
                directory = f"{base_path}/{self.folder_name}" if base_path != "" else self.folder_name
                collection.update_stac(directory, self.keywords)
                # create the link from this collection to the child collection
                self.link_to("child", collection, self.get_child_relative_path(collection.stac_object.get_self_href()))
                # create the link from the child collection to this collection
                collection.link_to("parent", self, "../collection.json")
        # create child links for all child items
        for item in self.child_items:
            if item.stac_object is not None:
                # add the keywords from this collection to the item
                item.update_keywords(self.keywords)
                # create the link from the item to this collection
                item.link_to("parent", self, "../collection.json")
                item.link_to("collection", self, "../collection.json")
                # set the href of the item to point to the new location of the stac file
                directory = f"{base_path}/{self.folder_name}" if base_path != "" else self.folder_name
                item.set_href(directory) # set the href of the item before creating the link
                # add the parent collection
                item.stac_object.collection_id = self.stac_object.id
                # create the link from this collection to the item, with a relative path
                self.link_to("item", item, self.get_child_relative_path(item.stac_object.get_self_href()))

    def summarize(self):
        # summarize the collection after all the items have been created, and after all the keywords have been updated
        if self.stac_object is not None:
            self.stac_object.keywords = None # only keep the summary keywords, to avoid confusion and redundancy, and to be sure that the keywords are consistent with the content of the items
            self.stac_object.summaries = self.get_summary()
        for collection in self.child_collections:
            collection.summarize()

    def add_extra_assets(self, assets: dict[str, pystac.Asset]):
        # add the assets to the child items, and recursively to the child collections
        for item in self.child_items:
            for key, asset in assets.items():
                item.stac_object.add_asset(key, asset)
        for collection in self.child_collections:
            collection.add_extra_assets(assets)
        # also add the assets to this collection
        for key, asset in assets.items():
            self.stac_object.add_asset(key, asset)

    def generate_stac_files(self, import_assets: bool = False):
        # this function will generate all the files for this collection, and all its children. At this point, all the stac objects should be finalized
        # first write the stac files for the child items
        for item in self.child_items:
            item.write_stac_file(import_assets=import_assets)
        # then call the function of the child collections recursively
        for collection in self.child_collections:
            collection.generate_stac_files(import_assets=import_assets)
        # finally, write the stac file for this collection
        self.write_stac_file(import_assets=import_assets)
