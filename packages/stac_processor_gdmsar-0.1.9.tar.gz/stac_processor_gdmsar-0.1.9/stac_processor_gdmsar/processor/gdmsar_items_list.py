from stac_processor_gdmsar.processor.gdmsar_item import GDMItem

class GDMGeoDEM(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "digital_elevation_model_item", files, ["dem"], "WGS84", date=date, resolution=resolution, default_keywords=["digital elevation model"], uuid=uuid)
class GDMRadarDEM(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "digital_elevation_model_item", files, ["dem"], "RADAR", date=date, resolution=resolution, default_keywords=["digital elevation model"], uuid=uuid)

class GDMGeoTCoh(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "temporal_coherence_item", files, ["tcoh"], "WGS84", date=date, resolution=resolution, default_keywords=["temporal coherence"], uuid=uuid)
class GDMRadarTCoh(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "temporal_coherence_item", files, ["tcoh"], "RADAR", date=date, resolution=resolution, default_keywords=["temporal coherence"], uuid=uuid)

class GDMGeoCosEnu(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "map_of_los_vector_flatsim_item", files, ["cosenu"], "WGS84", date=date, resolution=resolution, default_keywords=["Map of LOS vector", "ENU", "EPOS convention"], uuid=uuid)
class GDMRadarCosEnu(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "map_of_los_vector_flatsim_item", files, ["cosenu"], "RADAR", date=date, resolution=resolution, default_keywords=["Map of LOS vector", "ENU", "EPOS convention"], uuid=uuid)

class GDMGeoCosNeu(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "map_of_los_vector_epos_item", files, ["cosneu"], "WGS84", date=date, resolution=resolution, default_keywords=["Map of LOS vector", "NEU", "FlatSIM convention"], uuid=uuid)
class GDMRadarCosNeu(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "map_of_los_vector_epos_item", files, ["cosneu"], "RADAR", date=date, resolution=resolution, default_keywords=["Map of LOS vector", "NEU", "FlatSIM convention"], uuid=uuid)

class GDMGeoCoh(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "spatial_coherence_item", files, ["coh"], "WGS84", date=date, resolution=resolution, default_keywords=["spatial coherence"], uuid=uuid)
class GDMRadarCoh(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "spatial_coherence_item", files, ["coh"], "RADAR", date=date, resolution=resolution, default_keywords=["spatial coherence"], uuid=uuid)

class GDMGeoInW(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "wrapped_interferogram_item", files, ["inw"], "WGS84", date=date, resolution=resolution, default_keywords=["wrapped interferogram"], uuid=uuid)
class GDMRadarInW(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "wrapped_interferogram_item", files, ["inw"], "RADAR", date=date, resolution=resolution, default_keywords=["wrapped interferogram"], uuid=uuid)

class GDMGeoInWF(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "filtered_interferogram_item", files, ["inwf"], "WGS84", date=date, resolution=resolution, default_keywords=["filtered interferogram"], uuid=uuid)
class GDMRadarInWF(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "filtered_interferogram_item", files, ["inwf"], "RADAR", date=date, resolution=resolution, default_keywords=["filtered interferogram"], uuid=uuid)

class GDMGeoInU(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "unwrapped_interferogram_item", files, ["inu"], "WGS84", date=date, resolution=resolution, default_keywords=["unwrapped interferogram"], uuid=uuid)
class GDMRadarInU(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "unwrapped_interferogram_item", files, ["inu"], "RADAR", date=date, resolution=resolution, default_keywords=["unwrapped interferogram"], uuid=uuid)

class GDMGeoDts(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "los_displacement_time_series_item", files, ["dts_los", "geo_tot"], "WGS84", date=date, resolution=resolution, default_keywords=["LOS displacement"], uuid=uuid)
class GDMRadarDts(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "los_displacement_time_series_item", files, ["dts_los"], "RADAR", date=date, resolution=resolution, default_keywords=["LOS displacement"], uuid=uuid)

class GDMGeoNet(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "network_misclosure_item", files, ["net"], "WGS84", date=date, resolution=resolution, default_keywords=["network misclosure"], uuid=uuid)
class GDMRadarNet(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "network_misclosure_item", files, ["net"], "RADAR", date=date, resolution=resolution, default_keywords=["network misclosure"], uuid=uuid)

class GDMGeoMvlos(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "mean_velocity_map_item", files, ["mv-los"], "WGS84", date=date, resolution=resolution, default_keywords=["mean velocity map"], uuid=uuid)
class GDMRadarMvlos(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "mean_velocity_map_item", files, ["mv-los"], "RADAR", date=date, resolution=resolution, default_keywords=["mean velocity map"], uuid=uuid)

class GDMGeoLut(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "lookup_table_item", files, ["lut"], "WGS84", date=date, resolution=resolution, default_keywords=["lookup table"], uuid=uuid)
class GDMRadarLut(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(main_id, "lookup_table_item", files, ["lut"], "RADAR", date=date, resolution=resolution, default_keywords=["lookup table"], uuid=uuid)