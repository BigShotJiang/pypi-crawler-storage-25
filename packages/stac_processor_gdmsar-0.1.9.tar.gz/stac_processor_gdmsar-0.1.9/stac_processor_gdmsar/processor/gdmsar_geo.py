import logging
import stac_processor_gdmsar.processor.gdmsar_items_list as items
from stac_processor_gdmsar.processor.utils import extract_date_intervals, get_sublist_by_tags
from stac_processor_gdmsar.processor.gdmsar_collection import GDMCollection
    
logger = logging.getLogger(__name__)
    
class GDMGeoAux(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        super().__init__(
            main_id=main_id,
            folder_name="auxiliary_data_collection",
            files=files,
            title = f"The auxiliary data collection from run {main_id} in ground geometry",
            uuid=uuid,
            codes=[], geometry="WGS84", 
            template_list=["auxiliary_data_collection.md"], 
            child_items=[
                items.GDMGeoDEM(main_id, uuid, files),
                items.GDMGeoTCoh(main_id, uuid, files),
                items.GDMGeoCosEnu(main_id, uuid, files),
                items.GDMGeoCosNeu(main_id, uuid, files),
            ], 
        )

class GDMGeoDateInterval(GDMCollection):
    def __init__(self, main_id: str, uuid: str, date: str, files: list[str]) -> None:
        super().__init__(
            main_id=main_id,
            folder_name=f"interferogram_date_interval_{date}_collection",
            files=files,
            title=f"Interferograms Collection for the date interval {date} for {main_id} in ground geometry",
            uuid=uuid,
            geometry="WGS84", # no assets for this collection
            date=date,
            template_list=["interferogram.md"], 
            child_items=[
                items.GDMGeoCoh(main_id, uuid, files, date=date),
                items.GDMGeoInW(main_id, uuid, files, date=date),
                items.GDMGeoInWF(main_id, uuid, files, date=date),
                items.GDMGeoInU(main_id, uuid, files, date=date)
            ], 
        )

class GDMGeoInterferograms(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        # extract the date intervals from the file names
        interferogram_files = get_sublist_by_tags(files, ["_Coh_geo_", "_InW_geo_", "_InWF_geo_", "_INU_geo_"])
        date_intervals = extract_date_intervals(interferogram_files)
        date_interval_collections = []
        for date_interval in date_intervals:
            date_interval_collections.append(GDMGeoDateInterval(main_id, uuid, date_interval, files))
        # call the super constructor
        super().__init__(
            main_id=main_id,
            folder_name="interferogram_collection",
            files=files,
            title=f"Interferograms collection from run {main_id} in ground geometry",
            uuid=uuid,
            geometry="WGS84", # no assets for this collection
            template_list=["interferogram_collection.md"], 
            child_collections=date_interval_collections, 
        )

class GDMGeoTimeSerie(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        super().__init__(
            main_id=main_id,
            folder_name="time_serie_collection",
            files=files,
            title=f"Time Series collection from run {main_id} in ground geometry",
            uuid=uuid,
            codes=[], geometry="WGS84", 
            template_list=["time_series.md"], 
            child_items=[
                items.GDMGeoDts(main_id, uuid, files),
                items.GDMGeoNet(main_id, uuid, files),
                items.GDMGeoMvlos(main_id, uuid, files)
            ], 
        )


class GDMGeo(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        super().__init__(
            main_id=main_id,
            folder_name="wgs84_collection",
            files=files,
            title=f"Run {main_id} from the GDM-SAR-In processing pipeline in ground geometry",
            uuid=uuid,
            geometry="WGS84", # no assets for this collection
            template_list=["run_geocoded_wgs84_collection.md"], 
            child_collections=[
                GDMGeoAux(main_id, uuid, files),
                GDMGeoInterferograms(main_id, uuid, files),
                GDMGeoTimeSerie(main_id, uuid, files)
            ], 
        )
