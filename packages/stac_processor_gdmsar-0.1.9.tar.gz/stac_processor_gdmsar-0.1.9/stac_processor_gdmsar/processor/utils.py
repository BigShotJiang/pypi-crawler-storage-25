import logging
import re

from stac_processor_gdmsar.explorer import make_explorer
from stac_processor_gdmsar.metadata.products import get_product

logger = logging.getLogger(__name__)
    
def is_matching(file_name: str, tags: list[str] = [], match_case: bool = True) -> bool:
    for tag in tags:
        if match_case:
            if tag in file_name:
                return True
        else:
            if tag.lower() in file_name.lower():
                return True
    return False

def get_sublist_by_tags(files: list[str], tags: list[str], match_case: bool = True) -> list[str]:
    return [f for f in files if is_matching(f, tags, match_case)]

def extract_date_interval(file_name: str) -> str:
    # the file_name should look like "GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff"
    # we want to return "20161026_20161101" using a regex
    match = re.search(r'_(\d{8}_\d{8})_', file_name)
    if match:
        return match.group(1)
    else:
        return None

def extract_date_intervals(files: list[str]) -> list[str]: 
    date_intervals = set()
    for file in files:
        date_interval = extract_date_interval(file)
        if date_interval:
            date_intervals.add(date_interval)
    # return a sorted list of date intervals, sorted by the first date in the interval
    return sorted(date_intervals, key=lambda x: x.split("_")[0])

def is_valid_json(filename: str, json: dict) -> bool:
    # there should be a product associated to the json file name
    # this is checked first, otherwise the json file may not contain the expected fields (also it does not require to open the file)
    if get_product(filename) is None:
        return False
    # a valid json file should have the following text fields
    for field in ["bbox", "geometry", "properties"]:
        if field not in json or json[field] is None or json[field] == "":
            return False
    # it should also have an these list/dict fields that should not be empty
    for field in ["bbox", "geometry", "properties"]:
        if field not in json or json[field] is None or len(json[field]) == 0:
            return False
    return True

def load_json(file_path: str) -> dict:
    if file_path is None or file_path == "":
        return {}
    try:
        # if the file does not exists, make_explorer will raise an error, that we catch and return an empty dict
        explorer = make_explorer(file_path)
        return explorer.load_json(file_path)
    except Exception as e:
        logger.error(f"Error loading JSON from {file_path}: {e}")
        return {}
