"""
This file is a CLI to test the processor independently from a STAC Repository.
To use it, just call "uv run stac_processor_gdmsar/app.py" from the main directory.

The CLI has the following commands:
- discover: to test the discover function, it will print the product sources discovered in the given source
- process: to test the process function, it will convert the given product source into a STAC catalog, and save it in the given destination directory
- version: to test the version function, it will print the version of the given product source
- id: to test the id function, it will print the id of the given product source

This CLI is only for testing purposes, it is not intended to be used by users of the processor, and it is not intended to be used in production. 
It is only a way to test the processor independently from a STAC Repository, and to check that the output of the processor is correct.
"""

import logging
import os
import shutil
import typer

from stac_processor_gdmsar.__about__ import __version__
from stac_processor_gdmsar.discover import discover as api_discover
from stac_processor_gdmsar.id import id as api_id
from stac_processor_gdmsar.version import version as api_version
from stac_processor_gdmsar.process import process as api_process

# define the logger (the logger is already configured in ./__init__.py)
logger = logging.getLogger(__name__)

# define the CLI app
app = typer.Typer()

@app.callback(invoke_without_command=True)
def main(version: bool = False):
    logger.debug("Calling 'main' function of the CLI")
    if version:
        # print(__version__)
        logger.info(f"Version: {__version__}")


@app.command()
def id(product_source: str):
    # usage: uv run stac_processor_gdmsar/app.py id <product_source>
    logger.debug(f"Calling 'id' command with product_source: {product_source}")
    id = api_id(product_source)
    # print(id)
    logger.info(f"ID: {id}")


@app.command()
def version(product_source: str):
    # usage: uv run stac_processor_gdmsar/app.py version <product_source>
    logger.debug(f"Calling 'version' command with product_source: {product_source}")
    version = api_version(product_source)
    # print(version)
    logger.info(f"Version: {version}")


@app.command()
def discover(source: str):
    # usage: uv run stac_processor_gdmsar/app.py discover <source>
    logger.debug(f"Calling 'discover' command with source: {source}")
    product_sources = api_discover(source)
    for product_source in product_sources:
        logger.info(product_source)


@app.command()
def process(product_source: str, destination: str, import_assets: bool = False):
    # usage: uv run stac_processor_gdmsar/app.py process <product_source> <destination> [--import-assets]
    logger.debug(f"Calling 'process' command with product_source: {product_source}, destination: {destination}, import_assets: {import_assets}")

    if destination is not None:
        try:
            # call the process function that returns the path of the corresponding collection in a temporary directory
            href = api_process(product_source, import_assets=import_assets)
            result = os.path.dirname(href)
            parent_result_dir = os.path.dirname(result)
            # clean the previous content of destination, if any
            os.makedirs(destination, exist_ok=True)

            logger.debug(f"Moving the processed files to destination {destination}")
            # move the content of the temporary directory to destination
            for file_name in os.listdir(parent_result_dir):
                new_file = os.path.join(destination, file_name)
                # erase previous content if any
                if os.path.exists(new_file):
                    if os.path.isdir(new_file):
                        shutil.rmtree(new_file, ignore_errors=True)
                    else:
                        os.remove(new_file)
                # move the file/directory
                shutil.move(os.path.join(parent_result_dir, file_name), new_file)

            result = os.path.join(destination, os.path.basename(parent_result_dir))
            logger.info(f"Processing completed successfully. The STAC collection has been saved in {result}")

        except BaseException as error:
            logger.error(f"Error occurred while processing: {error}")
            raise error

if __name__ == "__main__":
    app()
