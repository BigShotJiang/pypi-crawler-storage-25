import logging

logger = logging.getLogger(__name__)

class Product:
    def __init__(self, code: str, geometry: str, regex: str, title: str, template: str = ""):
        self.code = code
        self.geometry = geometry
        self.regex = regex
        self.title = title
        self.template = template

# most of these information come from https://formater.pages.in2p3.fr/flatsim/product.html
products = [
    # Products from the interferogram package
    Product("InW", "WGS84", "_InW_geo_", "Wrapped Differential Interferograms in WGS84 geometry", "wrapped_interferogram.md"),
    Product("InW", "RADAR", "_InW_radar_", "Wrapped Differential Interferograms in radar geometry", "wrapped_interferogram.md"),
    Product("InWF", "WGS84", "_InWF_geo_", "Filtered Wrapped Differential Interferograms in WGS84 geometry", "filtered_wrapped_interferogram.md"),
    Product("InWF", "RADAR", "_InWF_radar_", "Filtered Wrapped Differential Interferograms in radar geometry", "filtered_wrapped_interferogram.md"),
    Product("APS", "WGS84", "_APS_geo_", "Interferogram Atmospheric Phase Screen from Global Atmospheric Model in WGS84 geometry", "atmospheric_phase_screen.md"),
    Product("APS", "RADAR", "_APS_radar_", "Interferogram Atmospheric Phase Screen from Global Atmospheric Model in radar geometry", "atmospheric_phase_screen.md"),
    Product("COH", "WGS84", "_Coh_geo_", "Spatial coherence in WGS84 geometry", "spatial_coherence.md"),
    Product("COH", "RADAR", "_Coh_radar_", "Spatial coherence in radar geometry", "spatial_coherence.md"),
    Product("INU", "WGS84", "_INU_geo_", "Unwrapped Differential Interferograms in WGS84 geometry", "unwrapped_interferogram.md"),
    Product("INU", "RADAR", "_INU_radar_", "Unwrapped Differential Interferograms in radar geometry", "unwrapped_interferogram.md"),
    # Products from the time-serie package
    Product("DTs_LOS", "WGS84", "_DTs_geo_", "Time series", "los_displacement_time_series.md"),
    Product("DTs_LOS", "RADAR", "_DTs_radar_", "Time series", "los_displacement_time_series.md"),
    Product("geo_TOT", "WGS84", "_geo_TOT_", "Preview for time series per date"),
    Product("MV-LOS", "WGS84", "_MV-LOS_geo_", "Mean LOS velocity", "mean_velocity_map.md"),
    Product("MV-LOS", "RADAR", "_MV-LOS_radar_", "Mean LOS velocity", "mean_velocity_map.md"),
    Product("Net", "WGS84", "_Net_geo_", "Network misclosure (Quality of times series inversion)", "network_misclosures.md"),
    Product("Net", "RADAR", "_Net_radar_", "Network misclosure (Quality of times series inversion)", "network_misclosures.md"),
    Product("Stk-In", "WGS84", "Stk-In_list_InU", "Stack of coregistered Interferograms"),
    Product("Stk-In", "RADAR", "Stk-In_list_InW", "Stack of coregistered Interferograms"),
    # Products from the auxiliary data package
    Product("LuT", "WGS84", "_LuT_geo_", "Lookup tables to pass from radar to ground geometry and vice versa", "lookup_table_sat_to_ground_coordinates.md"),
    Product("LuT", "RADAR", "_LuT_radar_", "Lookup tables to pass from radar to ground geometry and vice versa", "lookup_table_sat_to_ground_coordinates.md"),
    Product("CosNEU", "WGS84", "_CosNEU_geo_", "Map of LOS vector (NEU coefficient): convention: LOS vector is positive away from satellite to ground", "map_of_los_vector_neu.md"),
    Product("CosNEU", "RADAR", "_CosNEU_radar_", "Map of LOS vector (NEU coefficient): convention: LOS vector is positive away from satellite to ground", "map_of_los_vector_neu.md"),
    Product("CosENU", "WGS84", "_CosENU_geo_", "Map of LOS vector (ENU coefficient): convention: LOS vector is positive away from ground to satellite", "map_of_los_vector_enu.md"),
    Product("CosENU", "RADAR", "_CosENU_radar_", "Map of LOS vector (ENU coefficient): convention: LOS vector is positive away from ground to satellite", "map_of_los_vector_enu.md"),
    Product("DEM", "WGS84", "_DEM_geo_", "Digital Elevation Model", "digital_elevation_model.md"),
    Product("DEM", "RADAR", "_DEM_radar_", "Digital Elevation Model", "digital_elevation_model.md"),
    Product("TCoh", "WGS84", "_TCoh_geo_", "Temporal Coherence (Quality of measure)", "temporal_coherence.md"),
    Product("TCoh", "RADAR", "_TCoh_radar_", "Temporal Coherence (Quality of measure)", "temporal_coherence.md"),
    # Root collection assets
    Product("run", "", "nsbas.proc", "NSBAS run parameters", "run_collection.md"),
    Product("run", "", "interf_pair", "Interferogram Pair", "run_collection.md"),
    Product("run", "", "baseline.rsc", "Baseline Parameters", "run_collection.md"),
    Product("run", "", "baseline_top_bot.rsc", "Baseline Top-Bottom Parameters", "run_collection.md"),
    Product("run", "", "plot_time_lat_", "Time-Latitude Plot", "run_collection.md"),
    Product("run", "", "plot_interferograms", "Interferogram Plot", "run_collection.md"),
    Product("run", "", "orb_types", "Orbit Types", "run_collection.md"),
    Product("run", "", "success_coreg.txt", "Coregistration Success", "run_collection.md"),
    # Extra txt files
    Product("extra", "RADAR", "_interfero_spectraldiversity_", "Interferogram Spectral Diversity", "extra_text_files.md"),
    Product("extra", "RADAR", "_merge_", "Merged subswaths", "extra_text_files.md"),
    Product("extra", "RADAR", "success_coreg_", "Coregistration Success", "extra_text_files.md"),
    Product("extra", "RADAR", "liste_refer.txt", "Reference List", "extra_text_files.md"),
    Product("extra", "RADAR", "Stack_list_InW_", "Stack List InW", "extra_text_files.md"),
    Product("extra", "RADAR", "list_unw_frac", "Unwrapped Fraction List", "extra_text_files.md"),
    # Inversion parameters
    Product("inversion", "RADAR", "RMSdate.txt", "Inversion Parameter: RMS date", "inversion_parameters.md"),
    Product("inversion", "RADAR", "RMSinterfero.txt", "Inversion Parameter: RMS interferogram", "inversion_parameters.md"),
    Product("inversion", "RADAR", "Input_parameter_for_TS.txt", "Inversion Parameter: Input parameters for time series inversion", "inversion_parameters.md")
]

def get_product(file: str) -> Product | None:
    for product in products:
        if product.regex.lower() in file.lower():
            return product
    return None
