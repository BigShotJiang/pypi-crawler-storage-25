import logging
import re
from typing import Iterator
from stac_processor_gdmsar.explorer import make_explorer
from stac_processor_gdmsar.processor.utils import is_valid_json

logger = logging.getLogger(__name__)


regex_uuid = re.compile(r'^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\/?$', re.IGNORECASE)
regex_subswath = re.compile(r"^iw\d(?:_iw\d){0,2}/?$", re.IGNORECASE)

def get_uuid(path: str) -> str:
    # extract the uuid from the path, which should be the last part of the path that matches the uuid pattern
    for part in reversed(path.split("/")):
        if regex_uuid.match(part):
            return part
    raise ValueError(f"No UUID found in path : {path}")

def is_uuid(name: str) -> bool:
    # a uuid should look like 123e4567-e89b-12d3-a456-426614174000
    return bool(regex_uuid.match(name))

def is_subswath(name: str) -> bool:
    # a subswath should look like iw1, iw1_iw2, iw1_iw2_iw3, ...
    return bool(regex_subswath.match(name))

def is_valid(explorer, path: str) -> bool:
    # a valid product source should contain at least one json file with an id field, and it must match a product
    for item in explorer.list_dir(path):
        if item.lower().endswith(".json"):
            json_file = explorer.join(path, item)
            json_content = explorer.load_json(json_file)
            if is_valid_json(json_file, json_content):
                return True
    return False

def discover_recursively(explorer, path: str) -> Iterator[str]:
    # the path must correspond to a directory
    if not explorer.is_directory(path):
        return
    # if the path is a subswath and contains at least one json file, then return it as a product source
    if is_subswath(explorer.basename(path)):
        if is_valid(explorer, path):
            yield path
        return
    # otherwise, list the content of the directory and apply the same logic to each item
    for item in explorer.list_dir(path):
        item_path = explorer.join(path, item)
        if is_uuid(item):
            yield from discover_recursively(explorer, item_path)
        elif is_subswath(item):
            if is_valid(explorer, item_path):
                yield item_path

def discover(source: str) -> Iterator[str]:
    # make sure that the source URL ends with a slash
    if not source.endswith("/"):
        source += "/"
    # the source can either be a local directory, or a URL.
    logger.debug(f"Discovering product sources in {source}")
    explorer = make_explorer(source)
    return discover_recursively(explorer, source)