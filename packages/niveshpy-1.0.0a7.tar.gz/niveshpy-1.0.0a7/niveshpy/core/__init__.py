"""Core module for NiveshPy."""
