"""Transaction repository for NiveshPy."""

import datetime
from collections.abc import Iterable, Sequence
from enum import Enum, auto
from typing import Literal, Protocol

from niveshpy.core.query.ast import FilterNode
from niveshpy.models.report import Allocation, HoldingUnitRow
from niveshpy.models.transaction import TransactionCreate, TransactionPublic


class TransactionFetchProfile(Enum):
    """Enum for defining different fetch profiles for transactions."""

    MINIMAL = auto()
    """Fetch only the basic transaction fields without any related entities."""
    WITH_RELATIONS = auto()
    """Fetch transaction fields along with related entities (e.g., account, security)."""


class TransactionSortOrder(Enum):
    """Enum for defining sorting options for transactions."""

    DATE_ASC_ID_ASC = auto()
    """Sort transactions by date in ascending order and by ID in ascending order."""
    DATE_DESC_ID_ASC = auto()
    """Sort transactions by date in descending order and by ID in ascending order."""
    ID_ASC = auto()
    """Sort transactions by ID in ascending order."""
    ID_DESC = auto()
    """Sort transactions by ID in descending order."""


class TransactionRepository(Protocol):
    """Repository interface for retrieving and managing transactions."""

    def get_transaction_by_id(
        self,
        transaction_id: int,
        fetch_profile: TransactionFetchProfile = TransactionFetchProfile.WITH_RELATIONS,
    ) -> TransactionPublic | None:
        """Fetch a transaction by its unique ID.

        Args:
            transaction_id: The unique ID of the transaction to fetch.
            fetch_profile: The fetch profile to determine the level of detail to retrieve.

        Returns:
            The TransactionPublic object if found, otherwise None.
        """

    def find_transactions(
        self,
        filters: Iterable[FilterNode],
        limit: int | None = None,
        offset: int = 0,
        fetch_profile: TransactionFetchProfile = TransactionFetchProfile.WITH_RELATIONS,
        sort_order: TransactionSortOrder = TransactionSortOrder.DATE_DESC_ID_ASC,
    ) -> Sequence[TransactionPublic]:
        """Find transactions matching the given filters with optional pagination.

        Args:
            filters: An iterable of FilterNode objects to filter transactions.
            limit: Optional maximum number of transactions to return.
            offset: Optional number of transactions to skip before returning results.
            fetch_profile: The fetch profile to determine the level of detail to retrieve.
            sort_order: The sort order to determine the order of the returned transactions.

        Returns:
            A sequence of TransactionPublic objects matching the filters and pagination criteria.
        """

    def find_transactions_by_ids(
        self,
        ids: Sequence[int],
        fetch_profile: TransactionFetchProfile = TransactionFetchProfile.WITH_RELATIONS,
        sort_order: TransactionSortOrder = TransactionSortOrder.DATE_DESC_ID_ASC,
    ) -> Sequence[TransactionPublic]:
        """Find transactions matching the given list of IDs.

        Args:
            ids: A sequence of unique IDs to search for.
            fetch_profile: The fetch profile to determine how much related data to load.
            sort_order: The sort order to determine the order of the returned transactions.

        Returns:
            A sequence of TransactionPublic objects matching the given IDs.
        """

    def insert_transaction(self, transaction: TransactionCreate) -> int:
        """Insert a new transaction.

        Args:
            transaction: A TransactionCreate object containing the details of the transaction to insert.

        Returns:
            The unique ID of the newly inserted transaction.
        """

    def insert_multiple_transactions(
        self, transactions: Sequence[TransactionCreate]
    ) -> int:
        """Insert multiple transactions.

        Args:
            transactions: A sequence of TransactionCreate objects to insert.

        Returns:
            The number of transactions successfully inserted.
        """

    def delete_transaction_by_id(self, transaction_id: int) -> bool:
        """Delete a transaction by its ID.

        Args:
            transaction_id: The unique ID of the transaction to delete.

        Returns:
            True if the transaction was deleted successfully, False if no transaction with the given ID was found.
        """

    def overwrite_transactions_in_date_range_for_accounts(
        self,
        transactions: Sequence[TransactionCreate],
        date_range: tuple[datetime.date, datetime.date],
        account_ids: Sequence[int],
    ) -> int:
        """Bulk insert transactions into the database.

        Delete existing transactions in the date range for specified accounts before inserting.

        Args:
            transactions: A sequence of TransactionCreate objects to insert.
            date_range: A tuple containing the start and end dates (inclusive) as datetime.date objects.
            account_ids: A sequence of account IDs for which to delete existing transactions in the date range before inserting.

        Returns:
            The number of transactions successfully inserted.
        """

    def find_holding_units(
        self, filters: Iterable[FilterNode]
    ) -> Sequence[HoldingUnitRow]:
        """Find holding units matching the given filters.

        Args:
            filters: An iterable of FilterNode objects to filter holding units.

        Returns:
            A sequence of HoldingUnitRow objects matching the filters.
        """

    def find_allocation(
        self,
        filters: Iterable[FilterNode],
        group_by: Literal["category", "type", "both"],
    ) -> Sequence[Allocation]:
        """Find allocations matching the given filters.

        Args:
            filters: An iterable of FilterNode objects to filter allocations.
            group_by: A string indicating how to group the allocations ("category", "type", or "both").

        Returns:
            A sequence of Allocation objects matching the filters and grouped according to the specified criteria.
        """
