"""Domain layer for NiveshPy."""
