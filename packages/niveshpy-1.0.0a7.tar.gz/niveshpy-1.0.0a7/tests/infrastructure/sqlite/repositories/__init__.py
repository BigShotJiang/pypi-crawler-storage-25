"""SQLite repositories unit tests."""
