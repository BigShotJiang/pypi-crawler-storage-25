"""Tests for CLI commands."""
