//! Vector search: HNSW graph construction, search, and kNN queries.
//!
//! See [[hierarchical-navigable-small-world]] and [[architecture-overview|milestone-4]].

pub mod hnsw;
pub mod quantize;
pub mod query;

/// Distance metric for vector similarity.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DistanceMetric {
    /// Cosine distance: 1 - cosine_similarity. Lower = more similar.
    Cosine,
    /// Negative dot product. Lower = more similar (for pre-normalized vectors).
    DotProduct,
    /// Euclidean (L2) distance. Lower = more similar.
    L2,
}

/// Compute distance between two vectors.
pub fn distance(a: &[f32], b: &[f32], metric: DistanceMetric) -> f32 {
    debug_assert_eq!(a.len(), b.len());
    match metric {
        DistanceMetric::Cosine => cosine_distance(a, b),
        DistanceMetric::DotProduct => -dot_product(a, b),
        DistanceMetric::L2 => l2_distance(a, b),
    }
}

fn dot_product(a: &[f32], b: &[f32]) -> f32 {
    a.iter().zip(b.iter()).map(|(x, y)| x * y).sum()
}

fn cosine_distance(a: &[f32], b: &[f32]) -> f32 {
    let dot = dot_product(a, b);
    let norm_a = a.iter().map(|x| x * x).sum::<f32>().sqrt();
    let norm_b = b.iter().map(|x| x * x).sum::<f32>().sqrt();
    let denom = norm_a * norm_b;
    if denom == 0.0 { 1.0 } else { 1.0 - dot / denom }
}

fn l2_distance(a: &[f32], b: &[f32]) -> f32 {
    a.iter()
        .zip(b.iter())
        .map(|(x, y)| (x - y) * (x - y))
        .sum::<f32>()
        .sqrt()
}

/// Convert a raw distance value to a score.
///
/// Uses metric-specific formulas matching Lucene's `VectorSimilarityFunction`:
/// - Cosine: `max((1 + cos_sim) / 2, 0)` where cos_sim = 1 - distance
/// - L2: `1 / (1 + distance²)` — inherently in (0, 1]
/// - DotProduct: `max((1 + dot) / 2, 0)` where dot = -distance
///
/// Lucene floors at 0 but does NOT ceil at 1 — scores above 1 are possible
/// for DotProduct when the normalization contract is violated (unnormalized
/// vectors). This matches Lucene's `VectorUtil.normalizeToUnitInterval()`.
///
/// See [[feature-knn-query-type#2b]].
pub fn distance_to_score(raw_distance: f32, metric: DistanceMetric) -> f32 {
    match metric {
        DistanceMetric::Cosine => {
            // cosine_distance = 1 - cos_sim, so cos_sim = 1 - distance
            // Lucene: max((1 + cos_sim) / 2, 0) = max((2 - distance) / 2, 0)
            ((2.0 - raw_distance) / 2.0).max(0.0)
        }
        DistanceMetric::L2 => {
            // Lucene: 1 / (1 + squaredDistance)
            // Inherently in (0, 1] — no clamping needed.
            1.0 / (1.0 + raw_distance * raw_distance)
        }
        DistanceMetric::DotProduct => {
            // distance = -dot_product, so dot = -distance
            // Lucene: max((1 + dot) / 2, 0) = max((1 - distance) / 2, 0)
            // Floor at 0, no ceiling — scores > 1 possible for unnormalized vectors.
            ((1.0 - raw_distance) / 2.0).max(0.0)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cosine_identical() {
        let v = vec![1.0, 2.0, 3.0];
        let d = distance(&v, &v, DistanceMetric::Cosine);
        assert!(
            d.abs() < 1e-5,
            "identical vectors should have cosine distance ~0, got {d}"
        );
    }

    #[test]
    fn cosine_orthogonal() {
        let a = vec![1.0, 0.0];
        let b = vec![0.0, 1.0];
        let d = distance(&a, &b, DistanceMetric::Cosine);
        assert!(
            (d - 1.0).abs() < 1e-5,
            "orthogonal vectors should have cosine distance ~1, got {d}"
        );
    }

    #[test]
    fn cosine_opposite() {
        let a = vec![1.0, 0.0];
        let b = vec![-1.0, 0.0];
        let d = distance(&a, &b, DistanceMetric::Cosine);
        assert!(
            (d - 2.0).abs() < 1e-5,
            "opposite vectors should have cosine distance ~2, got {d}"
        );
    }

    #[test]
    fn dot_product_metric() {
        let a = vec![1.0, 2.0];
        let b = vec![3.0, 4.0];
        let d = distance(&a, &b, DistanceMetric::DotProduct);
        // dot = 1*3 + 2*4 = 11, negated = -11
        assert_eq!(d, -11.0);
    }

    #[test]
    fn l2_distance_metric() {
        let a = vec![0.0, 0.0];
        let b = vec![3.0, 4.0];
        let d = distance(&a, &b, DistanceMetric::L2);
        assert!((d - 5.0).abs() < 1e-5, "L2 distance should be 5.0, got {d}");
    }

    #[test]
    fn l2_identical() {
        let v = vec![1.0, 2.0, 3.0];
        let d = distance(&v, &v, DistanceMetric::L2);
        assert!(d.abs() < 1e-5);
    }

    #[test]
    fn zero_vector_cosine() {
        let a = vec![0.0, 0.0];
        let b = vec![1.0, 1.0];
        let d = distance(&a, &b, DistanceMetric::Cosine);
        assert_eq!(d, 1.0); // zero vector returns distance 1.0
    }

    #[test]
    fn unit_vectors() {
        let a = vec![1.0, 0.0, 0.0];
        let b = vec![0.0, 1.0, 0.0];
        let d_cos = distance(&a, &b, DistanceMetric::Cosine);
        let d_l2 = distance(&a, &b, DistanceMetric::L2);
        assert!((d_cos - 1.0).abs() < 1e-5);
        assert!((d_l2 - std::f32::consts::SQRT_2).abs() < 1e-5);
    }

    // --- distance_to_score tests ---

    #[test]
    fn cosine_score_identical() {
        // cos_sim = 1 → distance = 0 → score = (2-0)/2 = 1.0
        let s = distance_to_score(0.0, DistanceMetric::Cosine);
        assert!(
            (s - 1.0).abs() < 1e-5,
            "identical vectors: score={s}, expected 1.0"
        );
    }

    #[test]
    fn cosine_score_orthogonal() {
        // cos_sim = 0 → distance = 1 → score = (2-1)/2 = 0.5
        let s = distance_to_score(1.0, DistanceMetric::Cosine);
        assert!(
            (s - 0.5).abs() < 1e-5,
            "orthogonal vectors: score={s}, expected 0.5"
        );
    }

    #[test]
    fn cosine_score_opposite() {
        // cos_sim = -1 → distance = 2 → score = (2-2)/2 = 0.0
        let s = distance_to_score(2.0, DistanceMetric::Cosine);
        assert!(s.abs() < 1e-5, "opposite vectors: score={s}, expected 0.0");
    }

    #[test]
    fn l2_score_identical() {
        // distance = 0 → score = 1/(1+0) = 1.0
        let s = distance_to_score(0.0, DistanceMetric::L2);
        assert!((s - 1.0).abs() < 1e-5, "identical: score={s}, expected 1.0");
    }

    #[test]
    fn l2_score_unit_distance() {
        // distance = 1 → score = 1/(1+1) = 0.5
        let s = distance_to_score(1.0, DistanceMetric::L2);
        assert!(
            (s - 0.5).abs() < 1e-5,
            "unit distance: score={s}, expected 0.5"
        );
    }

    #[test]
    fn l2_score_far() {
        // distance = 2 → score = 1/(1+4) = 0.2
        let s = distance_to_score(2.0, DistanceMetric::L2);
        assert!((s - 0.2).abs() < 1e-5, "far: score={s}, expected 0.2");
    }

    #[test]
    fn dot_product_score_high_similarity() {
        // dot = 1.0 → distance = -1.0 → score = (1-(-1))/2 = 1.0
        let s = distance_to_score(-1.0, DistanceMetric::DotProduct);
        assert!((s - 1.0).abs() < 1e-5, "high sim: score={s}, expected 1.0");
    }

    #[test]
    fn dot_product_score_zero() {
        // dot = 0 → distance = 0 → score = (1-0)/2 = 0.5
        let s = distance_to_score(0.0, DistanceMetric::DotProduct);
        assert!((s - 0.5).abs() < 1e-5, "zero dot: score={s}, expected 0.5");
    }

    #[test]
    fn dot_product_score_negative() {
        // dot = -1 → distance = 1 → score = (1-1)/2 = 0.0
        let s = distance_to_score(1.0, DistanceMetric::DotProduct);
        assert!(s.abs() < 1e-5, "negative dot: score={s}, expected 0.0");
    }

    #[test]
    fn all_scores_non_negative() {
        // Verify all metrics produce non-negative scores (Lucene floors at 0).
        // Scores > 1 are allowed for DotProduct with unnormalized vectors.
        for dist in [0.0, 0.5, 1.0, 2.0, 5.0, 10.0] {
            for metric in [
                DistanceMetric::Cosine,
                DistanceMetric::L2,
                DistanceMetric::DotProduct,
            ] {
                let s = distance_to_score(dist, metric);
                assert!(
                    s >= 0.0,
                    "score should be non-negative: metric={metric:?}, dist={dist}, score={s}"
                );
            }
        }
    }

    #[test]
    fn l2_scores_bounded_unit() {
        // L2 scores are always in (0, 1] by formula
        for dist in [0.0, 0.1, 1.0, 10.0, 100.0] {
            let s = distance_to_score(dist, DistanceMetric::L2);
            assert!(
                s > 0.0 && s <= 1.0,
                "L2 score out of (0,1]: dist={dist}, score={s}"
            );
        }
    }

    #[test]
    fn dot_product_unnormalized_can_exceed_one() {
        // distance = -dot, so distance = -2 means dot = 2
        // score = (1 + 2) / 2 = 1.5 — valid for unnormalized vectors
        let s = distance_to_score(-2.0, DistanceMetric::DotProduct);
        assert!(
            s > 1.0,
            "unnormalized dot product should produce score > 1: {s}"
        );
    }
}
