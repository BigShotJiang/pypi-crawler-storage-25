//! KNN query: approximate nearest neighbor search via HNSW.
//!
//! Results are pre-materialized at bind time, then presented as a
//! doc_id-ordered scorer. Score conversion is metric-specific, matching
//! Lucene's `VectorSimilarityFunction` formulas.
//!
//! See [[feature-knn-query-type]] and [[architecture-overview#Step 4]].

use luci_core::{DocId, NO_MORE_DOCS, Result, ScoreMode, Scorer, TwoPhaseIterator};

use crate::query::{BoundQuery, Query, ScorerSupplier};
use crate::search::searcher::Searcher;
use crate::segment::reader::SegmentReader;
use crate::vector::DistanceMetric;

/// Approximate k-nearest-neighbor query on a dense_vector field.
///
/// See [[feature-knn-query-type]].
pub struct KnnQuery {
    pub field: String,
    pub query_vector: Vec<f32>,
    pub k: usize,
    pub num_candidates: usize,
    /// Minimum score threshold. Results with score < threshold are excluded.
    /// Score is metric-specific (see [`crate::vector::distance_to_score`]).
    pub threshold: Option<f32>,
}

impl Query for KnnQuery {
    fn bind(&self, searcher: &Searcher, _score_mode: ScoreMode) -> Result<Box<dyn BoundQuery>> {
        // Validate dimensions against mapping
        if let Some(mapping) = searcher.mapping() {
            if let Some(field_id) = mapping.field_id(&self.field) {
                let field_mapping = mapping.field(field_id);
                if let Some(expected_dims) = field_mapping.field_type.vector_dims() {
                    if self.query_vector.len() != expected_dims {
                        return Err(luci_core::LuciError::InvalidQuery(format!(
                            "knn query_vector has {} dimensions, field '{}' expects {}",
                            self.query_vector.len(),
                            self.field,
                            expected_dims
                        )));
                    }
                }
            }
        }

        let total_docs = searcher.total_docs();
        Ok(Box::new(BoundKnnQuery {
            field: self.field.clone(),
            query_vector: self.query_vector.clone(),
            k: self.k,
            ef: self.num_candidates,
            threshold: self.threshold,
            total_docs,
        }))
    }
}

struct BoundKnnQuery {
    field: String,
    query_vector: Vec<f32>,
    k: usize,
    ef: usize,
    threshold: Option<f32>,
    total_docs: u32,
}

impl BoundQuery for BoundKnnQuery {
    fn scorer_supplier(&self, reader: &SegmentReader) -> Result<Option<Box<dyn ScorerSupplier>>> {
        let field_id = match reader
            .header()
            .fields
            .iter()
            .find(|f| f.field_name == self.field)
            .map(|f| f.field_id)
        {
            Some(id) => id,
            None => return Ok(None),
        };

        // Proportional per-segment k (Lucene's statistical model).
        // Ensures 95% probability of capturing this segment's global top-k
        // contribution while avoiding unnecessary HNSW work in small segments.
        let per_segment_k = if self.total_docs > 0 {
            let p = reader.doc_count() as f64 / self.total_docs as f64;
            let k = self.k as f64;
            let lambda = 16.0; // 95% confidence
            let proportional = (k * p + lambda * (k * p * (1.0 - p)).sqrt()).ceil() as usize;
            proportional.max(1).min(self.k)
        } else {
            self.k
        };

        // Run kNN search — results are pre-materialized
        let mut results = reader.knn_search(field_id, &self.query_vector, per_segment_k, self.ef);
        if results.is_empty() {
            return Ok(None);
        }

        // Read distance metric for score conversion
        let metric = reader
            .vector_metric(field_id)
            .unwrap_or(DistanceMetric::Cosine);

        // Apply threshold: keep only results with score >= threshold
        if let Some(min_score) = self.threshold {
            results
                .retain(|&(_, dist)| crate::vector::distance_to_score(dist, metric) >= min_score);
            if results.is_empty() {
                return Ok(None);
            }
        }

        // Re-sort by doc_id ascending for advance() correctness.
        // HNSW returns results sorted by distance, but the Scorer contract
        // requires doc_id-ordered iteration for Bool conjunction/filter.
        results.sort_by_key(|&(doc_id, _)| doc_id);

        Ok(Some(Box::new(KnnScorerSupplier { results, metric })))
    }
}

struct KnnScorerSupplier {
    results: Vec<(u32, f32)>,
    metric: DistanceMetric,
}

impl ScorerSupplier for KnnScorerSupplier {
    fn cost(&self) -> u64 {
        self.results.len() as u64
    }

    fn scorer(self: Box<Self>) -> Result<Box<dyn Scorer>> {
        Ok(Box::new(KnnScorer {
            results: self.results,
            metric: self.metric,
            pos: 0,
        }))
    }
}

/// Scorer that iterates over pre-materialized kNN results.
///
/// Results are sorted by doc_id ascending (re-sorted from HNSW's distance
/// order). Scores are computed from distances using metric-specific formulas.
struct KnnScorer {
    results: Vec<(u32, f32)>, // (doc_id, distance) sorted by doc_id
    metric: DistanceMetric,
    pos: usize,
}

impl Scorer for KnnScorer {
    fn doc_id(&self) -> DocId {
        if self.pos < self.results.len() {
            DocId::new(self.results[self.pos].0)
        } else {
            NO_MORE_DOCS
        }
    }

    fn next(&mut self) -> DocId {
        if self.pos < self.results.len() {
            self.pos += 1;
        }
        self.doc_id()
    }

    fn advance(&mut self, target: DocId) -> DocId {
        while self.pos < self.results.len() && self.results[self.pos].0 < target.as_u32() {
            self.pos += 1;
        }
        self.doc_id()
    }

    fn score(&mut self) -> f32 {
        if self.pos < self.results.len() {
            crate::vector::distance_to_score(self.results[self.pos].1, self.metric)
        } else {
            0.0
        }
    }

    fn two_phase(&mut self) -> Option<&mut dyn TwoPhaseIterator> {
        None
    }
}
