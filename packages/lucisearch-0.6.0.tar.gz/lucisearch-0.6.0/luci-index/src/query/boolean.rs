//! BoolQuery: boolean combination of sub-queries.
//!
//! - `must`: conjunction (AND) — all clauses must match, scores summed
//! - `should`: disjunction (OR) — any clause may match, scores summed
//! - `must_not`: exclusion — matching docs are removed
//! - `filter`: conjunction in filter context (AND, no scoring)
//!
//! See [[query-dsl#Compound Queries]] and [[architecture-query-execution#Step 7]].

use luci_core::{DocId, NO_MORE_DOCS, Result, ScoreMode, Scorer, TwoPhaseIterator};

use crate::query::{BoundQuery, Query, ScorerSupplier};
use crate::search::conjunction::ConjunctionScorer;
use crate::search::searcher::Searcher;
use crate::segment::reader::SegmentReader;

/// Boolean combination of sub-queries.
pub struct BoolQuery {
    pub(crate) must: Vec<Box<dyn Query>>,
    pub(crate) should: Vec<Box<dyn Query>>,
    pub(crate) must_not: Vec<Box<dyn Query>>,
    pub(crate) filter: Vec<Box<dyn Query>>,
    pub(crate) minimum_should_match: Option<u32>,
}

impl Query for BoolQuery {
    fn bind(&self, searcher: &Searcher, score_mode: ScoreMode) -> Result<Box<dyn BoundQuery>> {
        let must_weights: Vec<Box<dyn BoundQuery>> = self
            .must
            .iter()
            .map(|q| q.bind(searcher, score_mode))
            .collect::<Result<_>>()?;

        let should_weights: Vec<Box<dyn BoundQuery>> = self
            .should
            .iter()
            .map(|q| q.bind(searcher, score_mode))
            .collect::<Result<_>>()?;

        let must_not_weights: Vec<Box<dyn BoundQuery>> = self
            .must_not
            .iter()
            .map(|q| q.bind(searcher, ScoreMode::CompleteNoScores))
            .collect::<Result<_>>()?;

        let filter_weights: Vec<Box<dyn BoundQuery>> = self
            .filter
            .iter()
            .map(|q| q.bind(searcher, ScoreMode::CompleteNoScores))
            .collect::<Result<_>>()?;

        Ok(Box::new(BoundBoolQuery {
            must: must_weights,
            should: should_weights,
            must_not: must_not_weights,
            filter: filter_weights,
            minimum_should_match: self.minimum_should_match,
        }))
    }
}

struct BoundBoolQuery {
    must: Vec<Box<dyn BoundQuery>>,
    should: Vec<Box<dyn BoundQuery>>,
    must_not: Vec<Box<dyn BoundQuery>>,
    filter: Vec<Box<dyn BoundQuery>>,
    minimum_should_match: Option<u32>,
}

impl BoundQuery for BoundBoolQuery {
    fn bulk_score(
        &self,
        reader: &SegmentReader,
        collector: &mut crate::search::collector::TopDocsCollector,
        segment_id: luci_core::SegmentId,
    ) -> Result<Option<u64>> {
        // Only for pure-should with 2+ clauses and min_should_match <= 1
        if !self.must.is_empty() || !self.filter.is_empty() || !self.must_not.is_empty() {
            return Ok(None);
        }
        if self.minimum_should_match.map_or(false, |m| m > 1) {
            return Ok(None);
        }
        if self.should.len() < 2 {
            return Ok(None);
        }

        let mut scorers: Vec<Box<dyn luci_core::Scorer>> = Vec::new();
        for w in &self.should {
            if let Some(supplier) = w.scorer_supplier(reader)? {
                scorers.push(supplier.scorer()?);
            }
        }
        if scorers.len() < 2 {
            return Ok(None);
        }

        let max_doc = reader.doc_count();
        let mut bulk = crate::search::bulk::MaxScoreBulkScorer::new(scorers);
        let hits = bulk.score(collector, segment_id, max_doc);
        Ok(Some(hits))
    }

    fn scorer_supplier(&self, reader: &SegmentReader) -> Result<Option<Box<dyn ScorerSupplier>>> {
        // Collect must suppliers
        let mut must_suppliers: Vec<Box<dyn ScorerSupplier>> = Vec::new();
        for w in &self.must {
            match w.scorer_supplier(reader)? {
                Some(s) => must_suppliers.push(s),
                None => return Ok(None), // must clause with no matches = no results
            }
        }

        // Collect filter suppliers
        let mut filter_suppliers: Vec<Box<dyn ScorerSupplier>> = Vec::new();
        for w in &self.filter {
            match w.scorer_supplier(reader)? {
                Some(s) => filter_suppliers.push(s),
                None => return Ok(None), // filter with no matches = no results
            }
        }

        // Collect should suppliers
        let mut should_suppliers: Vec<Box<dyn ScorerSupplier>> = Vec::new();
        for w in &self.should {
            if let Some(s) = w.scorer_supplier(reader)? {
                should_suppliers.push(s);
            }
        }

        // Collect must_not suppliers
        let mut must_not_suppliers: Vec<Box<dyn ScorerSupplier>> = Vec::new();
        for w in &self.must_not {
            if let Some(s) = w.scorer_supplier(reader)? {
                must_not_suppliers.push(s);
            }
        }

        // If no must and no filter and no should, nothing matches
        if must_suppliers.is_empty() && filter_suppliers.is_empty() && should_suppliers.is_empty() {
            return Ok(None);
        }

        // Estimate total cost as min of must/filter costs
        let cost = must_suppliers
            .iter()
            .chain(filter_suppliers.iter())
            .map(|s| s.cost())
            .min()
            .unwrap_or_else(|| should_suppliers.iter().map(|s| s.cost()).sum::<u64>());

        Ok(Some(Box::new(BoolScorerSupplier {
            must: must_suppliers,
            should: should_suppliers,
            must_not: must_not_suppliers,
            filter: filter_suppliers,
            minimum_should_match: self.minimum_should_match,
            cost,
        })))
    }
}

struct BoolScorerSupplier {
    must: Vec<Box<dyn ScorerSupplier>>,
    should: Vec<Box<dyn ScorerSupplier>>,
    must_not: Vec<Box<dyn ScorerSupplier>>,
    filter: Vec<Box<dyn ScorerSupplier>>,
    minimum_should_match: Option<u32>,
    cost: u64,
}

// SAFETY: All contained ScorerSuppliers are Send
unsafe impl Send for BoolScorerSupplier {}

impl ScorerSupplier for BoolScorerSupplier {
    fn cost(&self) -> u64 {
        self.cost
    }

    fn scorer(self: Box<Self>) -> Result<Box<dyn Scorer>> {
        // Build all sub-scorers
        let mut required_scorers: Vec<Box<dyn Scorer>> = Vec::new();

        // Must clauses (scored)
        // Sort by cost for conjunction efficiency
        let mut must_with_cost: Vec<_> = self
            .must
            .into_iter()
            .map(|s| {
                let c = s.cost();
                (s, c)
            })
            .collect();
        must_with_cost.sort_by_key(|(_, c)| *c);
        for (supplier, _) in must_with_cost {
            required_scorers.push(supplier.scorer()?);
        }

        // Filter clauses (not scored)
        let mut filter_with_cost: Vec<_> = self
            .filter
            .into_iter()
            .map(|s| {
                let c = s.cost();
                (s, c)
            })
            .collect();
        filter_with_cost.sort_by_key(|(_, c)| *c);
        for (supplier, _) in filter_with_cost {
            required_scorers.push(supplier.scorer()?);
        }

        // Must_not clauses → exclusion scorers
        let mut exclusion_scorers: Vec<Box<dyn Scorer>> = Vec::new();
        for supplier in self.must_not {
            exclusion_scorers.push(supplier.scorer()?);
        }

        // Should clauses
        let should_scorers: Vec<Box<dyn Scorer>> = self
            .should
            .into_iter()
            .map(|s| s.scorer())
            .collect::<Result<_>>()?;

        let min_should = self.minimum_should_match.unwrap_or(0) as usize;

        // Build the composite scorer
        let mut base_scorer: Box<dyn Scorer> = if !required_scorers.is_empty() {
            // Case A: must/filter exist — they form the required base
            if required_scorers.len() == 1 {
                required_scorers.pop().unwrap()
            } else {
                Box::new(ConjunctionScorer::new(required_scorers))
            }
        } else if !should_scorers.is_empty() {
            // Case B: no must/filter — should becomes the primary.
            let effective_min = if min_should > 0 { min_should } else { 1 };

            let mut scorer = build_should_scorer(should_scorers, effective_min)?;

            // Apply must_not exclusions (previously skipped — bug fix)
            if !exclusion_scorers.is_empty() {
                scorer = Box::new(ExclusionScorer::new(scorer, exclusion_scorers));
            }

            return Ok(scorer);
        } else {
            return Ok(Box::new(EmptyScorer));
        };

        // Apply must_not exclusions
        if !exclusion_scorers.is_empty() {
            base_scorer = Box::new(ExclusionScorer::new(base_scorer, exclusion_scorers));
        }

        // Add should clauses
        if !should_scorers.is_empty() {
            if min_should > 0 {
                // minimum_should_match set — should becomes required.
                let should_scorer = build_should_scorer(should_scorers, min_should)?;
                base_scorer = Box::new(ConjunctionScorer::new(vec![base_scorer, should_scorer]));
            } else {
                // No minimum — should is optional boost
                base_scorer = Box::new(OptionalScorer::new(base_scorer, should_scorers));
            }
        }

        Ok(base_scorer)
    }
}

/// Scorer that always returns NO_MORE_DOCS.
struct EmptyScorer;

impl Scorer for EmptyScorer {
    fn doc_id(&self) -> DocId {
        NO_MORE_DOCS
    }
    fn next(&mut self) -> DocId {
        NO_MORE_DOCS
    }
    fn advance(&mut self, _: DocId) -> DocId {
        NO_MORE_DOCS
    }
    fn score(&mut self) -> f32 {
        0.0
    }
    fn two_phase(&mut self) -> Option<&mut dyn TwoPhaseIterator> {
        None
    }
}

/// Wraps a base scorer and skips docs that appear in exclusion scorers (must_not).
struct ExclusionScorer {
    base: Box<dyn Scorer>,
    exclusions: Vec<Box<dyn Scorer>>,
}

impl ExclusionScorer {
    fn new(base: Box<dyn Scorer>, exclusions: Vec<Box<dyn Scorer>>) -> Self {
        let mut s = Self { base, exclusions };
        s.skip_excluded();
        s
    }

    fn is_excluded(&mut self) -> bool {
        let target = self.base.doc_id();
        for exc in &mut self.exclusions {
            let doc = exc.advance(target);
            if doc == target {
                return true;
            }
        }
        false
    }

    fn skip_excluded(&mut self) {
        while self.base.doc_id() != NO_MORE_DOCS && self.is_excluded() {
            self.base.next();
        }
    }
}

impl Scorer for ExclusionScorer {
    fn doc_id(&self) -> DocId {
        self.base.doc_id()
    }
    fn next(&mut self) -> DocId {
        self.base.next();
        self.skip_excluded();
        self.base.doc_id()
    }
    fn advance(&mut self, target: DocId) -> DocId {
        self.base.advance(target);
        self.skip_excluded();
        self.base.doc_id()
    }
    fn score(&mut self) -> f32 {
        self.base.score()
    }
    fn two_phase(&mut self) -> Option<&mut dyn TwoPhaseIterator> {
        None
    }
}

/// Wraps a required base scorer with optional should scorers that add to the score.
struct OptionalScorer {
    base: Box<dyn Scorer>,
    optionals: Vec<Box<dyn Scorer>>,
}

impl OptionalScorer {
    fn new(base: Box<dyn Scorer>, optionals: Vec<Box<dyn Scorer>>) -> Self {
        Self { base, optionals }
    }
}

impl Scorer for OptionalScorer {
    fn doc_id(&self) -> DocId {
        self.base.doc_id()
    }
    fn next(&mut self) -> DocId {
        self.base.next()
    }
    fn advance(&mut self, target: DocId) -> DocId {
        self.base.advance(target)
    }
    fn score(&mut self) -> f32 {
        let mut score = self.base.score();
        let target = self.base.doc_id();
        for opt in &mut self.optionals {
            if opt.advance(target) == target {
                score += opt.score();
            }
        }
        score
    }
    fn two_phase(&mut self) -> Option<&mut dyn TwoPhaseIterator> {
        None
    }
}

/// Build the right scorer for should clauses given the effective minimum.
fn build_should_scorer(
    mut scorers: Vec<Box<dyn Scorer>>,
    min_match: usize,
) -> Result<Box<dyn Scorer>> {
    if min_match > scorers.len() {
        return Ok(Box::new(EmptyScorer));
    }
    if scorers.len() == 1 {
        return Ok(scorers.pop().unwrap());
    }
    if min_match == scorers.len() {
        // All required → conjunction (much faster than disjunction)
        return Ok(Box::new(ConjunctionScorer::new(scorers)));
    }
    if min_match <= 1 {
        return Ok(Box::new(crate::search::wand::WANDScorer::new(scorers)));
    }
    Ok(Box::new(MinShouldMatchScorer::new(scorers, min_match)))
}

/// Three-zone scorer requiring at least `min_match` should clauses to match.
///
/// Follows Lucene's WANDScorer design with head/lead/tail zones:
/// - **head**: min-heap by doc_id — scorers ahead of the current candidate
/// - **lead**: scorers positioned on the current candidate
/// - **tail**: scorers behind the candidate, sorted by cost ascending
///
/// Key invariant: `tail.len() < min_match` — the tail alone cannot
/// produce a match. Most non-matching candidates are rejected in O(1)
/// by checking `lead.len() + tail.len() < min_match`.
///
/// See [[feature-minimum-should-match]].
struct MinShouldMatchScorer {
    head: Vec<ScorerEntry>,
    head_size: usize,
    lead: Vec<ScorerEntry>,
    tail: Vec<ScorerEntry>,
    min_match: usize,
    current_doc: DocId,
    current_score: f32,
}

struct ScorerEntry {
    scorer: Box<dyn Scorer>,
    cost: u64,
}

impl MinShouldMatchScorer {
    fn new(scorers: Vec<Box<dyn Scorer>>, min_match: usize) -> Self {
        let entries: Vec<ScorerEntry> = scorers
            .into_iter()
            .map(|s| {
                let cost = 1; // Simple cost estimate
                ScorerEntry { scorer: s, cost }
            })
            .collect();

        let mut s = Self {
            head: Vec::new(),
            head_size: 0,
            lead: Vec::new(),
            tail: Vec::new(),
            min_match,
            current_doc: NO_MORE_DOCS,
            current_score: 0.0,
        };

        // Initial placement: fill tail up to min_match-1 (cheapest),
        // rest go to head.
        let mut sorted_entries = entries;
        sorted_entries.sort_by_key(|e| e.cost);

        for entry in sorted_entries {
            if s.tail.len() < min_match.saturating_sub(1) {
                s.tail.push(entry);
            } else {
                s.push_head(entry);
            }
        }

        s.advance_to_next_match();
        s
    }

    // --- Head (min-heap by doc_id) ---

    fn push_head(&mut self, entry: ScorerEntry) {
        if self.head_size < self.head.len() {
            self.head[self.head_size] = entry;
        } else {
            self.head.push(entry);
        }
        self.head_size += 1;
        self.sift_up_head(self.head_size - 1);
    }

    fn pop_head(&mut self) -> ScorerEntry {
        self.head_size -= 1;
        self.head.swap(0, self.head_size);
        if self.head_size > 0 {
            self.sift_down_head(0);
        }
        if self.head_size < self.head.len() {
            // Take from the swapped-out position
            let idx = self.head_size;
            let placeholder = ScorerEntry {
                scorer: Box::new(EmptyScorer),
                cost: 0,
            };
            std::mem::replace(&mut self.head[idx], placeholder)
        } else {
            unreachable!()
        }
    }

    fn head_top_doc(&self) -> DocId {
        if self.head_size == 0 {
            NO_MORE_DOCS
        } else {
            self.head[0].scorer.doc_id()
        }
    }

    fn sift_down_head(&mut self, mut idx: usize) {
        loop {
            let left = 2 * idx + 1;
            if left >= self.head_size {
                break;
            }
            let right = left + 1;
            let mut smallest = idx;
            if self.head[left].scorer.doc_id() < self.head[smallest].scorer.doc_id() {
                smallest = left;
            }
            if right < self.head_size
                && self.head[right].scorer.doc_id() < self.head[smallest].scorer.doc_id()
            {
                smallest = right;
            }
            if smallest == idx {
                break;
            }
            self.head.swap(idx, smallest);
            idx = smallest;
        }
    }

    fn sift_up_head(&mut self, mut idx: usize) {
        while idx > 0 {
            let parent = (idx - 1) / 2;
            if self.head[idx].scorer.doc_id() < self.head[parent].scorer.doc_id() {
                self.head.swap(idx, parent);
                idx = parent;
            } else {
                break;
            }
        }
    }

    // --- Core algorithm ---

    fn advance_to_next_match(&mut self) {
        // Move lead scorers back to head or tail
        while let Some(mut entry) = self.lead.pop() {
            entry.scorer.next();
            if entry.scorer.doc_id() == NO_MORE_DOCS {
                continue; // exhausted
            }
            self.insert_head_or_tail(entry);
        }

        loop {
            // Check if enough scorers remain
            if self.head_size + self.tail.len() < self.min_match {
                self.current_doc = NO_MORE_DOCS;
                return;
            }

            let candidate = self.head_top_doc();
            if candidate == NO_MORE_DOCS {
                self.current_doc = NO_MORE_DOCS;
                return;
            }

            // Pop all head entries on this candidate into lead
            while self.head_size > 0 && self.head[0].scorer.doc_id() == candidate {
                let entry = self.pop_head();
                self.lead.push(entry);
            }

            // Can we possibly reach min_match?
            if self.lead.len() + self.tail.len() < self.min_match {
                // Impossible — move lead back and try next candidate
                while let Some(mut entry) = self.lead.pop() {
                    entry.scorer.next();
                    if entry.scorer.doc_id() != NO_MORE_DOCS {
                        self.insert_head_or_tail(entry);
                    }
                }
                continue;
            }

            // Try pulling from tail to reach min_match
            while self.lead.len() < self.min_match && !self.tail.is_empty() {
                let mut entry = self.tail.pop().unwrap();
                entry.scorer.advance(candidate);
                if entry.scorer.doc_id() == candidate {
                    self.lead.push(entry);
                } else if entry.scorer.doc_id() != NO_MORE_DOCS {
                    self.push_head(entry);
                }
                // else: exhausted, drop

                // Recheck feasibility
                if self.lead.len() + self.tail.len() < self.min_match {
                    break;
                }
            }

            if self.lead.len() >= self.min_match {
                self.current_doc = candidate;
                self.current_score = self.lead.iter_mut().map(|e| e.scorer.score()).sum();
                return;
            }

            // Not enough matches — move lead back and continue
            while let Some(mut entry) = self.lead.pop() {
                entry.scorer.next();
                if entry.scorer.doc_id() != NO_MORE_DOCS {
                    self.insert_head_or_tail(entry);
                }
            }
        }
    }

    fn insert_head_or_tail(&mut self, entry: ScorerEntry) {
        // Maintain tail invariant: tail.len() < min_match
        if self.tail.len() < self.min_match.saturating_sub(1) {
            self.tail.push(entry);
        } else {
            self.push_head(entry);
        }
    }
}

impl Scorer for MinShouldMatchScorer {
    fn doc_id(&self) -> DocId {
        self.current_doc
    }

    fn next(&mut self) -> DocId {
        if self.current_doc == NO_MORE_DOCS {
            return NO_MORE_DOCS;
        }
        self.advance_to_next_match();
        self.current_doc
    }

    fn advance(&mut self, target: DocId) -> DocId {
        if self.current_doc == NO_MORE_DOCS {
            return NO_MORE_DOCS;
        }
        // Advance head entries below target
        let mut i = 0;
        while i < self.head_size {
            if self.head[i].scorer.doc_id() < target {
                self.head[i].scorer.advance(target);
                if self.head[i].scorer.doc_id() == NO_MORE_DOCS {
                    self.head_size -= 1;
                    self.head.swap(i, self.head_size);
                    continue; // don't increment i
                }
            }
            i += 1;
        }
        // Rebuild heap after mass advance
        for j in (0..self.head_size / 2).rev() {
            self.sift_down_head(j);
        }
        // Advance lead entries
        for entry in &mut self.lead {
            if entry.scorer.doc_id() < target {
                entry.scorer.advance(target);
            }
        }
        // Move lead back to head/tail
        let lead_entries: Vec<ScorerEntry> = self.lead.drain(..).collect();
        for entry in lead_entries {
            if entry.scorer.doc_id() != NO_MORE_DOCS {
                self.insert_head_or_tail(entry);
            }
        }
        // Advance tail entries
        let tail_entries: Vec<ScorerEntry> = self.tail.drain(..).collect();
        for mut entry in tail_entries {
            if entry.scorer.doc_id() < target {
                entry.scorer.advance(target);
            }
            if entry.scorer.doc_id() != NO_MORE_DOCS {
                self.insert_head_or_tail(entry);
            }
        }

        self.advance_to_next_match();
        self.current_doc
    }

    fn score(&mut self) -> f32 {
        self.current_score
    }

    fn two_phase(&mut self) -> Option<&mut dyn TwoPhaseIterator> {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::query::term::TermQuery;

    use crate::segment::builder::SegmentBuilder;
    use luci_analysis::Token;
    use luci_core::{FieldId, SegmentId};
    use luci_mapping::{FieldType, Mapping};

    fn make_tokens(terms: &[&str]) -> Vec<Token> {
        terms
            .iter()
            .enumerate()
            .map(|(i, t)| Token::new(*t, 0, t.len(), i as u32))
            .collect()
    }

    fn build_test_store() -> crate::search::segment_store::SegmentStore {
        let schema = Mapping::builder()
            .field("body", FieldType::Text)
            .field("tag", FieldType::Keyword)
            .build();
        let mut builder = SegmentBuilder::new(SegmentId::new(1), &schema);

        // Doc 0: body="hello world", tag="a"
        builder.add_document(
            &[
                (FieldId::new(0), make_tokens(&["hello", "world"])),
                (FieldId::new(1), make_tokens(&["a"])),
            ],
            b"{}",
        );
        // Doc 1: body="hello luci", tag="b"
        builder.add_document(
            &[
                (FieldId::new(0), make_tokens(&["hello", "luci"])),
                (FieldId::new(1), make_tokens(&["b"])),
            ],
            b"{}",
        );
        // Doc 2: body="goodbye world", tag="a"
        builder.add_document(
            &[
                (FieldId::new(0), make_tokens(&["goodbye", "world"])),
                (FieldId::new(1), make_tokens(&["a"])),
            ],
            b"{}",
        );
        // Doc 3: body="luci search", tag="c"
        builder.add_document(
            &[
                (FieldId::new(0), make_tokens(&["luci", "search"])),
                (FieldId::new(1), make_tokens(&["c"])),
            ],
            b"{}",
        );

        let reader = SegmentReader::open(builder.build()).unwrap();
        crate::search::segment_store::SegmentStore::new(
            vec![reader],
            luci_analysis::AnalyzerRegistry::new(),
            None,
        )
    }

    fn collect_doc_ids(scorer: &mut dyn Scorer) -> Vec<u32> {
        let mut ids = Vec::new();
        while scorer.doc_id() != NO_MORE_DOCS {
            ids.push(scorer.doc_id().as_u32());
            scorer.next();
        }
        ids
    }

    #[test]
    fn bool_must_two_clauses() {
        let store = build_test_store();
        let searcher = Searcher::new(&store);
        let query = BoolQuery {
            must: vec![
                Box::new(TermQuery {
                    field: "body".into(),
                    value: "hello".into(),
                }),
                Box::new(TermQuery {
                    field: "body".into(),
                    value: "world".into(),
                }),
            ],
            should: vec![],
            must_not: vec![],
            filter: vec![],
            minimum_should_match: None,
        };

        let weight = query.bind(&searcher, ScoreMode::Complete).unwrap();
        let supplier = weight
            .scorer_supplier(&searcher.segments()[0])
            .unwrap()
            .unwrap();
        let mut scorer = supplier.scorer().unwrap();

        // Only doc 0 has both "hello" AND "world"
        let ids = collect_doc_ids(scorer.as_mut());
        assert_eq!(ids, vec![0]);
    }

    #[test]
    fn bool_should_two_clauses() {
        let store = build_test_store();
        let searcher = Searcher::new(&store);
        let query = BoolQuery {
            must: vec![],
            should: vec![
                Box::new(TermQuery {
                    field: "body".into(),
                    value: "hello".into(),
                }),
                Box::new(TermQuery {
                    field: "body".into(),
                    value: "goodbye".into(),
                }),
            ],
            must_not: vec![],
            filter: vec![],
            minimum_should_match: None,
        };

        let weight = query.bind(&searcher, ScoreMode::Complete).unwrap();
        let supplier = weight
            .scorer_supplier(&searcher.segments()[0])
            .unwrap()
            .unwrap();
        let mut scorer = supplier.scorer().unwrap();

        // Docs 0, 1, 2: "hello" in 0,1 and "goodbye" in 2
        let ids = collect_doc_ids(scorer.as_mut());
        assert_eq!(ids, vec![0, 1, 2]);
    }

    #[test]
    fn bool_must_not() {
        let store = build_test_store();
        let searcher = Searcher::new(&store);
        let query = BoolQuery {
            must: vec![Box::new(TermQuery {
                field: "body".into(),
                value: "hello".into(),
            })],
            should: vec![],
            must_not: vec![Box::new(TermQuery {
                field: "body".into(),
                value: "world".into(),
            })],
            filter: vec![],
            minimum_should_match: None,
        };

        let weight = query.bind(&searcher, ScoreMode::Complete).unwrap();
        let supplier = weight
            .scorer_supplier(&searcher.segments()[0])
            .unwrap()
            .unwrap();
        let mut scorer = supplier.scorer().unwrap();

        // "hello" in docs 0,1. "world" in docs 0,2. Must_not removes doc 0.
        let ids = collect_doc_ids(scorer.as_mut());
        assert_eq!(ids, vec![1]);
    }

    #[test]
    fn bool_filter_no_scores() {
        let store = build_test_store();
        let searcher = Searcher::new(&store);
        let query = BoolQuery {
            must: vec![],
            should: vec![],
            must_not: vec![],
            filter: vec![Box::new(TermQuery {
                field: "tag".into(),
                value: "a".into(),
            })],
            minimum_should_match: None,
        };

        let weight = query.bind(&searcher, ScoreMode::Complete).unwrap();
        let supplier = weight
            .scorer_supplier(&searcher.segments()[0])
            .unwrap()
            .unwrap();
        let mut scorer = supplier.scorer().unwrap();

        // tag="a" in docs 0, 2
        let ids = collect_doc_ids(scorer.as_mut());
        assert_eq!(ids, vec![0, 2]);
    }

    #[test]
    fn bool_must_plus_filter() {
        let store = build_test_store();
        let searcher = Searcher::new(&store);
        let query = BoolQuery {
            must: vec![Box::new(TermQuery {
                field: "body".into(),
                value: "hello".into(),
            })],
            should: vec![],
            must_not: vec![],
            filter: vec![Box::new(TermQuery {
                field: "tag".into(),
                value: "a".into(),
            })],
            minimum_should_match: None,
        };

        let weight = query.bind(&searcher, ScoreMode::Complete).unwrap();
        let supplier = weight
            .scorer_supplier(&searcher.segments()[0])
            .unwrap()
            .unwrap();
        let mut scorer = supplier.scorer().unwrap();

        // "hello" in 0,1 AND tag="a" in 0,2 → only doc 0
        let ids = collect_doc_ids(scorer.as_mut());
        assert_eq!(ids, vec![0]);
    }

    #[test]
    fn bool_empty_must_returns_none() {
        let store = build_test_store();
        let searcher = Searcher::new(&store);
        let query = BoolQuery {
            must: vec![Box::new(TermQuery {
                field: "body".into(),
                value: "nonexistent".into(),
            })],
            should: vec![],
            must_not: vec![],
            filter: vec![],
            minimum_should_match: None,
        };

        let weight = query.bind(&searcher, ScoreMode::Complete).unwrap();
        let supplier = weight.scorer_supplier(&searcher.segments()[0]).unwrap();
        assert!(supplier.is_none());
    }
}
