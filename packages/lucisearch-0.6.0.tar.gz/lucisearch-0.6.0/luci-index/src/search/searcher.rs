//! Searcher: multi-segment term search with BM25 scoring and source retrieval.
//!
//! Provides the `search(field, term, top_k)` API that searches across all
//! committed segments, scores with BM25, merges results, and retrieves
//! `_source` for the top hits.
//!
//! See [[architecture-query-execution]] and [[architecture-overview#Step 10]].

use std::sync::atomic::{AtomicU32, Ordering};

use rayon::prelude::*;

use crate::search::collector::TopDocsCollector;
use crate::segment::reader::SegmentReader;
use luci_analysis::AnalyzerRegistry;
use luci_core::{DocId, NO_MORE_DOCS};

/// Shared minimum competitive score across parallel search threads.
///
/// Each thread reads the global min to initialize its local threshold,
/// and updates it when its local min increases. The global min only
/// increases monotonically. Relaxed ordering is sufficient — stale
/// reads only cause slightly delayed pruning, not correctness issues.
struct SharedMinScore(AtomicU32);

impl SharedMinScore {
    fn new() -> Self {
        Self(AtomicU32::new(0.0f32.to_bits()))
    }

    fn get(&self) -> f32 {
        f32::from_bits(self.0.load(Ordering::Relaxed))
    }

    fn update(&self, new_min: f32) {
        let mut current = self.0.load(Ordering::Relaxed);
        loop {
            if new_min <= f32::from_bits(current) {
                break;
            }
            match self.0.compare_exchange_weak(
                current,
                new_min.to_bits(),
                Ordering::Relaxed,
                Ordering::Relaxed,
            ) {
                Ok(_) => break,
                Err(actual) => current = actual,
            }
        }
    }
}

/// Internal search results from the Searcher.
///
/// Used between Searcher and Index. Consumers see `search::results::SearchResults`.
pub(crate) struct ScoringResults {
    pub hits: Vec<crate::search::results::HitRef>,
    pub total_hits: crate::search::TotalHits,
    pub aggregations: std::collections::HashMap<String, crate::agg::AggregationResult>,
}

/// Searches across multiple segment readers.
///
/// Delegates to `SegmentStore` for shared state (segments, statistics,
/// analyzers, mapping). Handles scoring orchestration and parallel
/// segment dispatch.
///
/// See [[architecture-scoring-materialization-separation]].
pub(crate) struct Searcher<'a> {
    store: &'a crate::search::segment_store::SegmentStore,
}

impl<'a> Searcher<'a> {
    pub fn new(store: &'a crate::search::segment_store::SegmentStore) -> Self {
        Self { store }
    }

    /// Resolve the search-time analyzer name for a field.
    pub fn resolve_search_analyzer<'b>(
        &'b self,
        field: &str,
        query_analyzer: Option<&'b str>,
    ) -> &'b str
    where
        'a: 'b,
    {
        self.store.resolve_search_analyzer(field, query_analyzer)
    }

    /// Access the analyzer registry.
    pub fn analyzers(&self) -> &AnalyzerRegistry {
        self.store.analyzers()
    }

    /// Total number of documents across all segments.
    pub fn total_docs(&self) -> u32 {
        self.store.total_docs()
    }

    /// Access the segment readers.
    pub fn segments(&self) -> &[SegmentReader] {
        self.store.segments()
    }

    /// Total doc frequency for a term across all segments.
    pub fn doc_freq(&self, field_name: &str, term: &str) -> u32 {
        self.store.doc_freq(field_name, term)
    }

    /// Average field length across all segments (for BM25).
    pub fn avg_field_length(&self, field_name: &str) -> f32 {
        self.store.avg_field_length(field_name)
    }

    /// Access the mapping (for field type validation).
    pub fn mapping(&self) -> Option<&luci_mapping::Mapping> {
        self.store.mapping()
    }

    /// Execute a QueryExpression — the single entry point for all search paths.
    ///
    /// Dispatches scoring queries to the appropriate searcher method
    /// (with sort/collapse/aggs support) and ranking queries to
    /// `execute_ranking`. `Index::search()` delegates here after
    /// refreshing the reader.
    ///
    /// See [[feature-rrf-retrievers]] and [[architecture-query-execution]].
    pub fn execute_query(
        &self,
        query: &crate::query::ast::QueryExpression,
        expr: &crate::search::expression::SearchExpression,
    ) -> ScoringResults {
        use crate::query::ast::QueryExpression;

        let size = expr.size;
        let from = expr.from;

        match query {
            QueryExpression::Scoring(scoring) => {
                if !expr.aggs.is_empty() {
                    let factories: Vec<(String, Box<dyn crate::agg::AggregatorFactory>)> = expr
                        .aggs
                        .iter()
                        .map(|(name, e)| (name.clone(), e.bind()))
                        .collect();
                    self.search_with_aggs(scoring, &factories, from + size, from)
                } else if let Some(ref collapse_field) = expr.collapse {
                    self.search_query_collapsed(scoring, from + size, from, collapse_field)
                } else if let Some(ref sort_spec) = expr.sort {
                    self.search_query_sorted(
                        scoring,
                        from + size,
                        from,
                        sort_spec,
                        &expr.search_after,
                    )
                } else {
                    self.search_query(scoring, from + size, from)
                }
            }
            QueryExpression::Ranking(ranking) => self.execute_ranking(ranking, expr),
        }
    }

    /// Execute a RankingExpression — result-set composition.
    ///
    /// Produces a ranked result set, then applies sort, collapse,
    /// aggregations, and pagination. New ranking variants are
    /// dispatched here.
    fn execute_ranking(
        &self,
        ranking: &crate::query::ast::RankingExpression,
        expr: &crate::search::expression::SearchExpression,
    ) -> ScoringResults {
        use crate::query::ast::RankingExpression;

        let size = expr.size;
        let from = expr.from;

        // Produce the ranked result set
        let mut results = match ranking {
            RankingExpression::Fusion {
                sources,
                method,
                rank_constant,
                rank_window_size,
                weights,
            } => {
                let window = rank_window_size.unwrap_or(size);
                self.execute_fusion(
                    sources,
                    method,
                    *rank_constant,
                    window,
                    weights.as_deref(),
                    from + size,
                )
            }
        };

        // Post-ranking sort
        if let Some(ref sort_spec) = expr.sort {
            self.post_sort(&mut results, sort_spec, &expr.search_after);
        }

        // Post-ranking collapse
        if let Some(ref collapse_field) = expr.collapse {
            self.post_collapse(&mut results, collapse_field);
        }

        // Post-ranking aggregations
        if !expr.aggs.is_empty() {
            self.collect_aggregations(&mut results, &expr.aggs);
        }

        // Pagination
        if from > 0 && from < results.hits.len() {
            results.hits = results.hits.split_off(from);
        } else if from >= results.hits.len() {
            results.hits.clear();
        }
        results.hits.truncate(size);

        results
    }

    /// Execute a fusion query: run each source, combine results.
    ///
    /// Pure fusion — no sort/collapse/aggs/pagination. Those are applied
    /// by the caller (`execute_ranking`).
    fn execute_fusion(
        &self,
        sources: &[crate::query::ast::QueryExpression],
        method: &crate::query::ast::FusionMethod,
        rank_constant: f32,
        rank_window_size: usize,
        weights: Option<&[f32]>,
        collect_size: usize,
    ) -> ScoringResults {
        use crate::query::ast::{FusionMethod, QueryExpression};

        let source_results: Vec<ScoringResults> = sources
            .iter()
            .map(|source| match source {
                QueryExpression::Scoring(scoring) => {
                    self.search_query(scoring, rank_window_size, 0)
                }
                QueryExpression::Ranking(ranking) => {
                    self.execute_ranking_inner(ranking, rank_window_size)
                }
            })
            .collect();

        let refs: Vec<&ScoringResults> = source_results.iter().collect();

        match method {
            FusionMethod::ReciprocalRank => crate::search::rrf::reciprocal_rank_fusion(
                &refs,
                rank_constant,
                weights,
                collect_size,
            ),
            FusionMethod::Sum
            | FusionMethod::ArithmeticMean
            | FusionMethod::HarmonicMean
            | FusionMethod::GeometricMean => {
                crate::search::rrf::score_fusion(&refs, method, weights, collect_size)
            }
        }
    }

    /// Execute a ranking expression as a nested source (no top-level
    /// sort/collapse/aggs/pagination — those only apply at the outermost level).
    fn execute_ranking_inner(
        &self,
        ranking: &crate::query::ast::RankingExpression,
        collect_size: usize,
    ) -> ScoringResults {
        use crate::query::ast::RankingExpression;

        match ranking {
            RankingExpression::Fusion {
                sources,
                method,
                rank_constant,
                rank_window_size,
                weights,
            } => {
                let window = rank_window_size.unwrap_or(collect_size);
                self.execute_fusion(
                    sources,
                    method,
                    *rank_constant,
                    window,
                    weights.as_deref(),
                    collect_size,
                )
            }
        }
    }

    /// Collect aggregations over already-collected hits.
    ///
    /// Groups hits by segment, creates per-segment collectors, collects,
    /// then merges. Used when aggregations couldn't be collected inline
    /// (e.g., fusion results, sorted results).
    fn collect_aggregations(
        &self,
        results: &mut ScoringResults,
        aggs: &[(String, crate::agg::AggregationExpression)],
    ) {
        let factories: Vec<(String, Box<dyn crate::agg::AggregatorFactory>)> = aggs
            .iter()
            .map(|(name, e)| (name.clone(), e.bind()))
            .collect();

        // Group hit doc_ids by segment
        let mut segment_docs: std::collections::HashMap<
            luci_core::SegmentId,
            Vec<luci_core::DocId>,
        > = std::collections::HashMap::new();
        for hit in &results.hits {
            segment_docs
                .entry(hit.segment_id)
                .or_default()
                .push(hit.doc_id);
        }

        for (name, factory) in &factories {
            let mut segment_results = Vec::new();
            for segment in self.store.segments() {
                if let Some(doc_ids) = segment_docs.get(&segment.segment_id()) {
                    let mut collector = factory.create_collector(segment);
                    for &doc_id in doc_ids {
                        collector.collect(doc_id);
                    }
                    segment_results.push(collector.finish());
                }
            }
            if !segment_results.is_empty() {
                results
                    .aggregations
                    .insert(name.clone(), factory.merge_results(segment_results));
            }
        }
    }

    /// Search using a Query object, returning top-K results with scoring.
    ///
    /// Scores all matching documents, applies pagination (from/top_k), and
    /// returns hit metadata. Content (source, fields, highlight, explain)
    /// is retrieved lazily via `Hit`.
    ///
    /// See [[architecture-scoring-materialization-separation]].
    pub fn search_query(
        &self,
        query: &dyn crate::query::Query,
        top_k: usize,
        from: usize,
    ) -> ScoringResults {
        use luci_core::ScoreMode;

        let weight = match query.bind(self, ScoreMode::Complete) {
            Ok(w) => w,
            Err(_) => {
                return ScoringResults {
                    hits: Vec::new(),
                    total_hits: crate::search::TotalHits::exact(0),
                    aggregations: std::collections::HashMap::new(),
                };
            }
        };

        // Single-segment fast path: skip rayon overhead
        if self.store.segments().len() <= 1 {
            let mut collector = TopDocsCollector::new(top_k);
            let mut total_hits: u64 = 0;
            if let Some(segment) = self.store.segments().first() {
                total_hits = Self::search_segment(segment, weight.as_ref(), &mut collector, None);
            }
            return self.build_results(collector, total_hits, from);
        }

        // Multi-segment parallel search
        let shared_min = SharedMinScore::new();

        let partial_results: Vec<(TopDocsCollector, u64)> = self
            .store
            .segments()
            .par_iter()
            .map(|segment| {
                let mut collector = TopDocsCollector::new(top_k);
                let hits = Self::search_segment(
                    segment,
                    weight.as_ref(),
                    &mut collector,
                    Some(&shared_min),
                );
                // Propagate local min back to global
                shared_min.update(collector.min_score());
                (collector, hits)
            })
            .collect();

        // Merge thread-local results
        let mut merged = TopDocsCollector::new(top_k);
        let mut total_hits: u64 = 0;
        for (collector, hits) in partial_results {
            merged.merge(collector);
            total_hits += hits;
        }

        self.build_results(merged, total_hits, from)
    }

    /// Score with field collapse, returning only the merged collector and hit count.
    fn score_collapsed(
        &self,
        query: &dyn crate::query::Query,
        top_k: usize,
        collapse_field: &str,
    ) -> Option<(crate::search::collector::CollapsingCollector, u64)> {
        use crate::search::collector::{CollapseKey, CollapsingCollector};
        use luci_core::ScoreMode;

        let weight = query.bind(self, ScoreMode::Complete).ok()?;

        let search_one = |segment: &SegmentReader| -> (CollapsingCollector, u64) {
            let mut collector = CollapsingCollector::new(top_k);
            let seg_id = segment.segment_id();

            let field_id = segment
                .header()
                .fields
                .iter()
                .find(|f| f.field_name == collapse_field)
                .map(|f| f.field_id);
            let col_reader = field_id.and_then(|fid| segment.column(fid));

            let supplier = match weight.scorer_supplier(segment) {
                Ok(Some(s)) => s,
                _ => return (collector, 0),
            };
            let mut scorer = match supplier.scorer() {
                Ok(s) => s,
                Err(_) => return (collector, 0),
            };

            let mut total_hits: u64 = 0;
            loop {
                let doc = scorer.doc_id();
                if doc == NO_MORE_DOCS {
                    break;
                }
                let score = scorer.score();

                let key = match &col_reader {
                    Some(col) => {
                        use crate::columnar::writer::ColumnType;
                        let d = doc.as_u32();
                        match col.col_type() {
                            ColumnType::Keyword => col
                                .keyword_value(d)
                                .map(|s| CollapseKey::Keyword(s.to_string()))
                                .unwrap_or(CollapseKey::Null),
                            ColumnType::I64
                            | ColumnType::BitpackedI64
                            | ColumnType::ConstantI64 => col
                                .i64_value(d)
                                .map(CollapseKey::Numeric)
                                .unwrap_or(CollapseKey::Null),
                            ColumnType::F64 | ColumnType::ConstantF64 => col
                                .f64_value(d)
                                .map(|f| CollapseKey::Numeric(f.to_bits() as i64))
                                .unwrap_or(CollapseKey::Null),
                            _ => CollapseKey::Null,
                        }
                    }
                    None => CollapseKey::Null,
                };

                collector.collect(doc, seg_id, score, key);
                total_hits += 1;
                scorer.next();
            }

            (collector, total_hits)
        };

        let segment_results: Vec<(CollapsingCollector, u64)> = if self.store.segments().len() <= 1 {
            self.store.segments().iter().map(search_one).collect()
        } else {
            self.store.segments().par_iter().map(search_one).collect()
        };

        let mut merged = CollapsingCollector::new(top_k);
        let mut total_hits: u64 = 0;
        for (collector, hits) in segment_results {
            merged.merge(collector);
            total_hits += hits;
        }

        Some((merged, total_hits))
    }

    /// Search with field collapse (deduplication by field value).
    ///
    /// Keeps only the highest-scoring doc per unique collapse field value.
    /// See [[feature-search-collapse]].
    pub fn search_query_collapsed(
        &self,
        query: &dyn crate::query::Query,
        top_k: usize,
        from: usize,
        collapse_field: &str,
    ) -> ScoringResults {
        let (merged, total_hits) = match self.score_collapsed(query, top_k, collapse_field) {
            Some(r) => r,
            None => {
                return ScoringResults {
                    hits: Vec::new(),
                    total_hits: crate::search::TotalHits::exact(0),
                    aggregations: std::collections::HashMap::new(),
                };
            }
        };

        let collapsed_docs = merged.into_sorted_results();
        let hits = collapsed_docs
            .into_iter()
            .skip(from)
            .map(|cd| crate::search::results::HitRef {
                doc_id: cd.doc_id,
                segment_id: cd.segment_id,
                score: cd.score,
                sort_values: None,
                collapse_key: Some(cd.collapse_key.to_json()),
            })
            .collect();

        ScoringResults {
            hits,
            total_hits: crate::search::TotalHits::exact(total_hits),
            aggregations: std::collections::HashMap::new(),
        }
    }

    /// Search with field-based sorting.
    ///
    /// Uses `TopFieldCollector` instead of `TopDocsCollector`. Reads sort
    /// values from `ColumnReader` per segment. When sort doesn't include
    /// `_score`, scoring is skipped entirely.
    /// Score with field-based sorting, returning only the merged collector and hit count.
    fn score_sorted(
        &self,
        query: &dyn crate::query::Query,
        top_k: usize,
        sort_fields: &[crate::search::SortField],
        search_after: &Option<Vec<crate::search::SortValue>>,
    ) -> Option<(crate::search::collector::TopFieldCollector, u64)> {
        use crate::search::collector::TopFieldCollector;
        use crate::search::{SortField, SortFieldType, SortValue};
        use luci_core::ScoreMode;

        let needs_scores = sort_fields
            .iter()
            .any(|sf| matches!(sf.field, SortFieldType::Score));
        let score_mode = if needs_scores {
            ScoreMode::Complete
        } else {
            ScoreMode::CompleteNoScores
        };

        let weight = query.bind(self, score_mode).ok()?;

        let search_one = |segment: &SegmentReader| -> (TopFieldCollector, u64) {
            let mut collector = TopFieldCollector::new(top_k, sort_fields.to_vec());
            if let Some(after) = search_after {
                collector.set_search_after(after.clone());
            }
            let seg_id = segment.segment_id();

            let supplier = match weight.scorer_supplier(segment) {
                Ok(Some(s)) => s,
                _ => return (collector, 0),
            };
            let mut scorer = match supplier.scorer() {
                Ok(s) => s,
                Err(_) => return (collector, 0),
            };

            // Open ColumnReaders for sort fields
            let col_readers: Vec<Option<crate::columnar::reader::ColumnReader>> = sort_fields
                .iter()
                .map(|sf| match &sf.field {
                    SortFieldType::Field(name) => {
                        let field_id = segment
                            .header()
                            .fields
                            .iter()
                            .find(|f| f.field_name == *name)
                            .map(|f| f.field_id)?;
                        segment.column(field_id)
                    }
                    _ => None,
                })
                .collect();

            // Helper: read a sort value for field index `i` from columns
            let read_sort_value = |i: usize, sf: &SortField, doc: DocId, score: f32| -> SortValue {
                match &sf.field {
                    SortFieldType::Score => SortValue::Score(score),
                    SortFieldType::Doc => {
                        SortValue::Doc(seg_id.as_u64() * 1_000_000_000 + doc.as_u32() as u64)
                    }
                    SortFieldType::Field(_) => match &col_readers[i] {
                        Some(col) => {
                            use crate::columnar::writer::ColumnType;
                            let d = doc.as_u32();
                            match col.col_type() {
                                ColumnType::Keyword => col
                                    .keyword_value(d)
                                    .map(|s| SortValue::Str(s.to_string()))
                                    .unwrap_or(SortValue::Null),
                                ColumnType::F64 | ColumnType::ConstantF64 => col
                                    .f64_value(d)
                                    .map(SortValue::F64)
                                    .unwrap_or(SortValue::Null),
                                ColumnType::I64
                                | ColumnType::BitpackedI64
                                | ColumnType::ConstantI64 => col
                                    .i64_value(d)
                                    .map(SortValue::I64)
                                    .unwrap_or(SortValue::Null),
                                ColumnType::Bool => col
                                    .bool_value(d)
                                    .map(SortValue::Bool)
                                    .unwrap_or(SortValue::Null),
                                _ => SortValue::Null,
                            }
                        }
                        None => SortValue::Null,
                    },
                }
            };

            let mut total_hits: u64 = 0;
            loop {
                let doc = scorer.doc_id();
                if doc == NO_MORE_DOCS {
                    break;
                }

                let score = if needs_scores { scorer.score() } else { 0.0 };

                // Early rejection: check competitiveness before allocating.
                // For keyword fields, compare &str directly to avoid String alloc.
                let primary_competitive = match &sort_fields[0].field {
                    SortFieldType::Field(_) => match &col_readers[0] {
                        Some(col)
                            if col.col_type() == crate::columnar::writer::ColumnType::Keyword =>
                        {
                            let kv = col.keyword_value(doc.as_u32());
                            collector.is_competitive_keyword(kv)
                        }
                        _ => {
                            let primary = read_sort_value(0, &sort_fields[0], doc, score);
                            collector.is_competitive_primary(&primary)
                        }
                    },
                    _ => {
                        let primary = read_sort_value(0, &sort_fields[0], doc, score);
                        collector.is_competitive_primary(&primary)
                    }
                };
                if !primary_competitive {
                    total_hits += 1;
                    scorer.next();
                    continue;
                }

                // Competitive: build full sort values (re-read primary)
                let mut sort_values = Vec::with_capacity(sort_fields.len());
                sort_values.push(read_sort_value(0, &sort_fields[0], doc, score));
                for i in 1..sort_fields.len() {
                    sort_values.push(read_sort_value(i, &sort_fields[i], doc, score));
                }

                collector.collect(doc, seg_id, score, sort_values);
                total_hits += 1;
                scorer.next();
            }

            (collector, total_hits)
        };

        let segment_results: Vec<(TopFieldCollector, u64)> = if self.store.segments().len() <= 1 {
            self.store.segments().iter().map(search_one).collect()
        } else {
            self.store.segments().par_iter().map(search_one).collect()
        };

        let mut merged = TopFieldCollector::new(top_k, sort_fields.to_vec());
        let mut total_hits: u64 = 0;
        for (collector, hits) in segment_results {
            merged.merge(collector);
            total_hits += hits;
        }

        Some((merged, total_hits))
    }

    /// Search with field-based sorting and content materialization.
    ///
    /// Convenience method: calls [`score_sorted`] then materializes.
    /// See [[feature-sort-by-field]].
    pub fn search_query_sorted(
        &self,
        query: &dyn crate::query::Query,
        top_k: usize,
        from: usize,
        sort_fields: &[crate::search::SortField],
        search_after: &Option<Vec<crate::search::SortValue>>,
    ) -> ScoringResults {
        let (merged, total_hits) = match self.score_sorted(query, top_k, sort_fields, search_after)
        {
            Some(r) => r,
            None => {
                return ScoringResults {
                    hits: Vec::new(),
                    total_hits: crate::search::TotalHits::exact(0),
                    aggregations: std::collections::HashMap::new(),
                };
            }
        };

        let field_docs = merged.into_sorted_results();
        let hits = field_docs
            .into_iter()
            .skip(from)
            .map(|fd| crate::search::results::HitRef {
                doc_id: fd.doc_id,
                segment_id: fd.segment_id,
                score: fd.score,
                sort_values: Some(fd.sort_values),
                collapse_key: None,
            })
            .collect();

        ScoringResults {
            hits,
            total_hits: crate::search::TotalHits::exact(total_hits),
            aggregations: std::collections::HashMap::new(),
        }
    }

    /// Search a single segment, collecting into a thread-local collector.
    fn search_segment(
        segment: &SegmentReader,
        weight: &dyn crate::query::BoundQuery,
        collector: &mut TopDocsCollector,
        shared_min: Option<&SharedMinScore>,
    ) -> u64 {
        let seg_id = segment.segment_id();
        let mut total_hits: u64 = 0;

        // Try bulk scoring first (bypasses doc-at-a-time overhead)
        if let Ok(Some(hits)) = weight.bulk_score(segment, collector, seg_id) {
            if let Some(sm) = shared_min {
                sm.update(collector.min_score());
            }
            return hits;
        }

        let supplier = match weight.scorer_supplier(segment) {
            Ok(Some(s)) => s,
            _ => return 0,
        };

        let mut scorer = match supplier.scorer() {
            Ok(s) => s,
            Err(_) => return 0,
        };

        // Seed scorer with global min competitive score from other threads
        if let Some(sm) = shared_min {
            let global_min = sm.get();
            if global_min > 0.0 {
                scorer.set_min_competitive_score(global_min);
            }
        }

        // Hot loop: score + collect each matching document.
        // Only call set_min_competitive_score when the threshold actually
        // changes, avoiding 99.99% wasted indirect calls.
        // See [[optimization-collector-scaling]].
        let mut last_min: f32 = 0.0;
        loop {
            let doc = scorer.doc_id();
            if doc == NO_MORE_DOCS {
                break;
            }
            let score = scorer.score();
            collector.collect(doc, seg_id, score);
            total_hits += 1;
            let min = collector.min_score();
            if min > last_min {
                scorer.set_min_competitive_score(min);
                last_min = min;
            }
            scorer.next();
        }

        total_hits
    }

    /// Build ScoringResults from a collector and total hit count.
    ///
    /// Skips the first `from` results. Content (source, fields) is no longer
    /// materialized here — callers retrieve it lazily via `Hit`.
    /// See [[feature-search-from-offset]].
    fn build_results(
        &self,
        collector: TopDocsCollector,
        total_hits: u64,
        from: usize,
    ) -> ScoringResults {
        let score_docs = collector.into_sorted_results();
        let hits = score_docs
            .into_iter()
            .skip(from)
            .map(|sd| crate::search::results::HitRef {
                doc_id: sd.doc_id,
                segment_id: sd.segment_id,
                score: sd.score,
                sort_values: None,
                collapse_key: None,
            })
            .collect();

        ScoringResults {
            hits,
            total_hits: crate::search::TotalHits::exact(total_hits),
            aggregations: std::collections::HashMap::new(),
        }
    }

    /// Search with query and aggregations.
    ///
    /// Segments are searched in parallel via rayon when there are 2+ segments.
    pub fn search_with_aggs(
        &self,
        query: &dyn crate::query::Query,
        agg_factories: &[(String, Box<dyn crate::agg::AggregatorFactory>)],
        top_k: usize,
        from: usize,
    ) -> ScoringResults {
        use luci_core::ScoreMode;

        let weight = match query.bind(self, ScoreMode::Complete) {
            Ok(w) => w,
            Err(_) => {
                return ScoringResults {
                    hits: Vec::new(),
                    total_hits: crate::search::TotalHits::exact(0),
                    aggregations: std::collections::HashMap::new(),
                };
            }
        };

        // Per-segment search + agg collection (runs in parallel for multi-segment)
        let search_one =
            |segment: &SegmentReader| -> (TopDocsCollector, u64, Vec<crate::agg::AggregationResult>) {
                let mut collector = TopDocsCollector::new(top_k);
                let mut total_hits: u64 = 0;

                let mut agg_collectors: Vec<Box<dyn crate::agg::Aggregator>> = agg_factories
                    .iter()
                    .map(|(_, factory)| factory.create_collector(segment))
                    .collect();

                let seg_id = segment.segment_id();

                // Match-all + agg-only: bypass scorer, use collect_range
                if top_k == 0 && weight.is_match_all() {
                    let doc_count = segment.doc_count();
                    total_hits = doc_count as u64;
                    for agg_collector in &mut agg_collectors {
                        agg_collector.collect_range(0, doc_count);
                    }
                    let agg_results = agg_collectors.into_iter().map(|c| c.finish()).collect();
                    return (collector, total_hits, agg_results);
                }

                let supplier = match weight.scorer_supplier(segment) {
                    Ok(Some(s)) => s,
                    _ => {
                        let agg_results = agg_collectors.into_iter().map(|c| c.finish()).collect();
                        return (collector, 0, agg_results);
                    }
                };

                let mut scorer = match supplier.scorer() {
                    Ok(s) => s,
                    Err(_) => {
                        let agg_results = agg_collectors.into_iter().map(|c| c.finish()).collect();
                        return (collector, 0, agg_results);
                    }
                };

                if top_k == 0 {
                    loop {
                        let doc_id = scorer.doc_id();
                        if doc_id == NO_MORE_DOCS {
                            break;
                        }
                        total_hits += 1;
                        for agg_collector in &mut agg_collectors {
                            agg_collector.collect(doc_id);
                        }
                        scorer.next();
                    }
                } else {
                    loop {
                        let doc_id = scorer.doc_id();
                        if doc_id == NO_MORE_DOCS {
                            break;
                        }
                        let score = scorer.score();
                        collector.collect(doc_id, seg_id, score);
                        total_hits += 1;
                        for agg_collector in &mut agg_collectors {
                            agg_collector.collect(doc_id);
                        }
                        scorer.set_min_competitive_score(collector.min_score());
                        scorer.next();
                    }
                }

                let agg_results = agg_collectors.into_iter().map(|c| c.finish()).collect();
                (collector, total_hits, agg_results)
            };

        // Execute: parallel for multi-segment, sequential for single
        let segment_results: Vec<(TopDocsCollector, u64, Vec<crate::agg::AggregationResult>)> =
            if self.store.segments().len() <= 1 {
                self.store.segments().iter().map(search_one).collect()
            } else {
                self.store.segments().par_iter().map(search_one).collect()
            };

        // Merge collectors and agg results
        let mut merged = TopDocsCollector::new(top_k);
        let mut total_hits: u64 = 0;
        let num_aggs = agg_factories.len();
        let mut agg_partial_results: Vec<Vec<crate::agg::AggregationResult>> =
            (0..num_aggs).map(|_| Vec::new()).collect();

        for (collector, hits, agg_results) in segment_results {
            merged.merge(collector);
            total_hits += hits;
            for (i, result) in agg_results.into_iter().enumerate() {
                if i < num_aggs {
                    agg_partial_results[i].push(result);
                }
            }
        }

        let mut aggregations = std::collections::HashMap::new();
        for (i, (name, factory)) in agg_factories.iter().enumerate() {
            let partial = std::mem::take(&mut agg_partial_results[i]);
            let merged_agg = factory.merge_results(partial);
            aggregations.insert(name.clone(), merged_agg);
        }

        let score_docs = merged.into_sorted_results();
        let hits = score_docs
            .into_iter()
            .skip(from)
            .map(|sd| crate::search::results::HitRef {
                doc_id: sd.doc_id,
                segment_id: sd.segment_id,
                score: sd.score,
                sort_values: None,
                collapse_key: None,
            })
            .collect();

        ScoringResults {
            hits,
            total_hits: crate::search::TotalHits::exact(total_hits),
            aggregations,
        }
    }

    /// Post-hoc sort: re-order already-collected hits by field values.
    ///
    /// Used for fusion results where sort cannot be pushed into scoring.
    /// Reads field values from the columnar store for each hit.
    pub fn post_sort(
        &self,
        results: &mut ScoringResults,
        sort_fields: &[crate::search::SortField],
        search_after: &Option<Vec<crate::search::SortValue>>,
    ) {
        use crate::search::{SortFieldType, SortValue, compare_sort_values_cascade};

        if results.hits.is_empty() || sort_fields.is_empty() {
            return;
        }

        // Read sort values for each hit
        let mut hits_with_sort: Vec<(crate::search::results::HitRef, Vec<SortValue>)> = results
            .hits
            .drain(..)
            .map(|hit| {
                let sort_values: Vec<SortValue> = sort_fields
                    .iter()
                    .map(|sf| match &sf.field {
                        SortFieldType::Score => SortValue::Score(hit.score),
                        SortFieldType::Doc => SortValue::Doc(
                            hit.segment_id.as_u64() * 1_000_000_000 + hit.doc_id.as_u32() as u64,
                        ),
                        SortFieldType::Field(name) => self.read_sort_value(&hit, name),
                    })
                    .collect();
                (hit, sort_values)
            })
            .collect();

        // Filter by search_after if specified (strictly after cursor)
        if let Some(after) = search_after {
            hits_with_sort.retain(|(_, sv)| {
                compare_sort_values_cascade(sv, after, sort_fields) == std::cmp::Ordering::Greater
            });
        }

        // Sort by cascading sort fields
        hits_with_sort.sort_by(|(_, a), (_, b)| compare_sort_values_cascade(a, b, sort_fields));

        // Write back with sort_values attached
        results.hits = hits_with_sort
            .into_iter()
            .map(|(mut hit, sort_values)| {
                hit.sort_values = Some(sort_values);
                hit
            })
            .collect();
    }

    /// Read a single sort field value from the columnar store for a hit.
    fn read_sort_value(
        &self,
        hit: &crate::search::results::HitRef,
        field_name: &str,
    ) -> crate::search::SortValue {
        use crate::search::SortValue;

        let segment = match self
            .store
            .segments()
            .iter()
            .find(|s| s.segment_id() == hit.segment_id)
        {
            Some(s) => s,
            None => return SortValue::Null,
        };

        let field_id = match segment
            .header()
            .fields
            .iter()
            .find(|f| f.field_name == field_name)
            .map(|f| f.field_id)
        {
            Some(id) => id,
            None => return SortValue::Null,
        };

        let col = match segment.column(field_id) {
            Some(c) => c,
            None => return SortValue::Null,
        };

        use crate::columnar::writer::ColumnType;
        let d = hit.doc_id.as_u32();
        match col.col_type() {
            ColumnType::Keyword => col
                .keyword_value(d)
                .map(|s| SortValue::Str(s.to_string()))
                .unwrap_or(SortValue::Null),
            ColumnType::F64 | ColumnType::ConstantF64 => col
                .f64_value(d)
                .map(SortValue::F64)
                .unwrap_or(SortValue::Null),
            ColumnType::I64 | ColumnType::BitpackedI64 | ColumnType::ConstantI64 => col
                .i64_value(d)
                .map(SortValue::I64)
                .unwrap_or(SortValue::Null),
            _ => SortValue::Null,
        }
    }

    /// Post-hoc collapse: deduplicate already-collected hits by field value.
    ///
    /// Keeps the highest-scoring hit per unique field value. Reads collapse
    /// field values from the columnar store for each hit.
    pub fn post_collapse(&self, results: &mut ScoringResults, collapse_field: &str) {
        if results.hits.is_empty() {
            return;
        }

        let mut seen: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
        let mut kept = Vec::new();

        // Hits are already sorted by score (descending) — keep first per key
        for hit in results.hits.drain(..) {
            let key = self.read_collapse_key(&hit, collapse_field);
            let key_str = match &key {
                serde_json::Value::String(s) => s.clone(),
                serde_json::Value::Number(n) => n.to_string(),
                serde_json::Value::Null => "__null__".to_string(),
                other => other.to_string(),
            };

            if !seen.contains_key(&key_str) {
                seen.insert(key_str, kept.len());
                kept.push(crate::search::results::HitRef {
                    collapse_key: Some(key),
                    ..hit
                });
            }
        }

        results.hits = kept;
    }

    /// Read a collapse field value from the columnar store for a hit.
    fn read_collapse_key(
        &self,
        hit: &crate::search::results::HitRef,
        field_name: &str,
    ) -> serde_json::Value {
        let segment = match self
            .store
            .segments()
            .iter()
            .find(|s| s.segment_id() == hit.segment_id)
        {
            Some(s) => s,
            None => return serde_json::Value::Null,
        };

        let field_id = match segment
            .header()
            .fields
            .iter()
            .find(|f| f.field_name == field_name)
            .map(|f| f.field_id)
        {
            Some(id) => id,
            None => return serde_json::Value::Null,
        };

        let col = match segment.column(field_id) {
            Some(c) => c,
            None => return serde_json::Value::Null,
        };

        use crate::columnar::writer::ColumnType;
        let d = hit.doc_id.as_u32();
        match col.col_type() {
            ColumnType::Keyword => col
                .keyword_value(d)
                .map(|s| serde_json::json!(s))
                .unwrap_or(serde_json::Value::Null),
            ColumnType::F64 | ColumnType::ConstantF64 => col
                .f64_value(d)
                .map(|f| serde_json::json!(f))
                .unwrap_or(serde_json::Value::Null),
            ColumnType::I64 | ColumnType::BitpackedI64 | ColumnType::ConstantI64 => col
                .i64_value(d)
                .map(|i| serde_json::json!(i))
                .unwrap_or(serde_json::Value::Null),
            _ => serde_json::Value::Null,
        }
    }

    /// Apply rescore: re-score the top hits with an additional query and
    /// combine scores. See [[feature-search-rescore]].
    pub fn apply_rescore(
        &self,
        results: &mut ScoringResults,
        rescore_query: &dyn crate::query::Query,
        window_size: usize,
        query_weight: f32,
        rescore_query_weight: f32,
        score_mode: crate::search::RescoreScoreMode,
    ) {
        use luci_core::{NO_MORE_DOCS, ScoreMode};
        use std::cmp::Ordering;

        let weight = match rescore_query.bind(self, ScoreMode::Complete) {
            Ok(w) => w,
            Err(_) => return,
        };

        // Only rescore the top window_size hits
        let rescore_count = results.hits.len().min(window_size);

        // Group hits by segment, process each segment with one scorer
        // advancing forward through sorted doc_ids
        for segment in self.store.segments() {
            let seg_id = segment.segment_id();

            let supplier = match weight.scorer_supplier(segment) {
                Ok(Some(s)) => s,
                _ => continue,
            };
            let mut scorer = match supplier.scorer() {
                Ok(s) => s,
                Err(_) => continue,
            };

            // Collect indices of hits in this segment, sorted by doc_id
            let mut seg_hits: Vec<usize> = (0..rescore_count)
                .filter(|&i| results.hits[i].segment_id == seg_id)
                .collect();
            seg_hits.sort_by_key(|&i| results.hits[i].doc_id);

            for idx in seg_hits {
                let doc = results.hits[idx].doc_id;

                // Advance scorer forward to this doc
                if scorer.doc_id() == NO_MORE_DOCS {
                    break;
                }
                if scorer.doc_id() < doc {
                    scorer.advance(doc);
                }

                let rescore_score = if scorer.doc_id() == doc {
                    if let Some(tp) = scorer.two_phase() {
                        if tp.matches() { scorer.score() } else { 0.0 }
                    } else {
                        scorer.score()
                    }
                } else {
                    0.0
                };

                results.hits[idx].score = score_mode.combine(
                    results.hits[idx].score,
                    rescore_score,
                    query_weight,
                    rescore_query_weight,
                );
            }
        }

        // Re-sort by new combined score
        results.hits[..rescore_count].sort_by(|a, b| {
            b.score
                .partial_cmp(&a.score)
                .unwrap_or(Ordering::Equal)
                .then_with(|| a.doc_id.cmp(&b.doc_id))
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::query::term::TermQuery;
    use crate::segment::builder::SegmentBuilder;
    use luci_analysis::Token;
    use luci_core::{FieldId, SegmentId};
    use luci_mapping::{FieldType, Mapping};

    use crate::search::segment_store::SegmentStore;

    fn make_store(segments: Vec<crate::segment::reader::SegmentReader>) -> SegmentStore {
        SegmentStore::new(segments, AnalyzerRegistry::new(), None)
    }

    fn make_tokens(terms: &[&str]) -> Vec<Token> {
        terms
            .iter()
            .enumerate()
            .map(|(i, t)| Token::new(*t, 0, t.len(), i as u32))
            .collect()
    }

    fn test_schema() -> Mapping {
        Mapping::builder().field("body", FieldType::Text).build()
    }

    fn build_segment(id: u64, docs: &[(&[&str], &str)]) -> SegmentReader {
        let schema = test_schema();
        let mut builder = SegmentBuilder::new(SegmentId::new(id), &schema);
        for (terms, source) in docs {
            builder.add_document(&[(FieldId::new(0), make_tokens(terms))], source.as_bytes());
        }
        SegmentReader::open(builder.build()).unwrap()
    }

    #[test]
    fn single_segment_search() {
        let reader = build_segment(
            1,
            &[
                (&["hello", "world"], r#"{"body":"hello world"}"#),
                (&["hello", "luci"], r#"{"body":"hello luci"}"#),
                (&["goodbye", "world"], r#"{"body":"goodbye world"}"#),
            ],
        );

        let store = make_store(vec![reader]);
        let searcher = Searcher::new(&store);
        let results = searcher.search_query(
            &TermQuery {
                field: "body".into(),
                value: "hello".into(),
            },
            10,
            0,
        );

        assert_eq!(results.total_hits.value, 2);
        assert_eq!(results.hits.len(), 2);
        // Both results should have "hello" in the source (lazy retrieval)
        let reader = crate::search::reader::Reader::new(&store);
        for hit in &results.hits {
            let source = reader.get_source(hit.segment_id, hit.doc_id).unwrap();
            assert!(source["body"].as_str().unwrap().contains("hello"));
        }
    }

    #[test]
    fn multi_segment_search() {
        let seg1 = build_segment(
            1,
            &[
                (&["hello", "world"], r#"{"body":"hello world"}"#),
                (&["foo", "bar"], r#"{"body":"foo bar"}"#),
            ],
        );
        let seg2 = build_segment(
            2,
            &[
                (&["hello", "luci"], r#"{"body":"hello luci"}"#),
                (&["baz", "qux"], r#"{"body":"baz qux"}"#),
            ],
        );

        let store = make_store(vec![seg1, seg2]);
        let searcher = Searcher::new(&store);
        let results = searcher.search_query(
            &TermQuery {
                field: "body".into(),
                value: "hello".into(),
            },
            10,
            0,
        );

        assert_eq!(results.total_hits.value, 2);
        assert_eq!(results.hits.len(), 2);
    }

    #[test]
    fn correct_bm25_ranking() {
        // Doc with higher TF should rank higher (same field length)
        let reader = build_segment(
            1,
            &[
                (&["search"], r#"{"body":"search"}"#),
                (
                    &["search", "search", "search"],
                    r#"{"body":"search search search"}"#,
                ),
                (&["search", "other"], r#"{"body":"search other"}"#),
            ],
        );

        let store = make_store(vec![reader]);
        let searcher = Searcher::new(&store);
        let results = searcher.search_query(
            &TermQuery {
                field: "body".into(),
                value: "search".into(),
            },
            10,
            0,
        );

        assert_eq!(results.total_hits.value, 3);
        // Doc 1 (tf=3) should score highest
        assert_eq!(results.hits[0].doc_id, DocId::new(1));
    }

    #[test]
    fn top_k_limiting() {
        let reader = build_segment(
            1,
            &[
                (&["term"], r#"{"id":0}"#),
                (&["term"], r#"{"id":1}"#),
                (&["term"], r#"{"id":2}"#),
                (&["term"], r#"{"id":3}"#),
                (&["term"], r#"{"id":4}"#),
            ],
        );

        let store = make_store(vec![reader]);
        let searcher = Searcher::new(&store);
        let results = searcher.search_query(
            &TermQuery {
                field: "body".into(),
                value: "term".into(),
            },
            2,
            0,
        );

        assert_eq!(results.total_hits.value, 5);
        assert_eq!(results.hits.len(), 2);
    }

    #[test]
    fn score_descending_order() {
        let reader = build_segment(
            1,
            &[
                (&["a", "b", "c", "d", "search"], r#"{"id":0}"#),
                (&["search", "search"], r#"{"id":1}"#),
                (&["search"], r#"{"id":2}"#),
            ],
        );

        let store = make_store(vec![reader]);
        let searcher = Searcher::new(&store);
        let results = searcher.search_query(
            &TermQuery {
                field: "body".into(),
                value: "search".into(),
            },
            10,
            0,
        );

        for i in 0..results.hits.len() - 1 {
            assert!(
                results.hits[i].score >= results.hits[i + 1].score,
                "results should be in descending score order"
            );
        }
    }

    #[test]
    fn source_returned() {
        let reader = build_segment(1, &[(&["hello"], r#"{"body":"hello"}"#)]);

        let store = make_store(vec![reader]);
        let searcher = Searcher::new(&store);
        let results = searcher.search_query(
            &TermQuery {
                field: "body".into(),
                value: "hello".into(),
            },
            10,
            0,
        );

        assert_eq!(results.hits.len(), 1);
        let reader = crate::search::reader::Reader::new(&store);
        let source = reader
            .get_source(results.hits[0].segment_id, results.hits[0].doc_id)
            .unwrap();
        assert_eq!(source["body"], "hello");
    }

    #[test]
    fn missing_term() {
        let reader = build_segment(1, &[(&["hello"], r#"{"body":"hello"}"#)]);

        let store = make_store(vec![reader]);
        let searcher = Searcher::new(&store);
        let results = searcher.search_query(
            &TermQuery {
                field: "body".into(),
                value: "nonexistent".into(),
            },
            10,
            0,
        );

        assert_eq!(results.total_hits.value, 0);
        assert!(results.hits.is_empty());
    }

    #[test]
    fn missing_field() {
        let reader = build_segment(1, &[(&["hello"], r#"{"body":"hello"}"#)]);

        let store = make_store(vec![reader]);
        let searcher = Searcher::new(&store);
        let results = searcher.search_query(
            &TermQuery {
                field: "nonexistent_field".into(),
                value: "hello".into(),
            },
            10,
            0,
        );

        assert_eq!(results.total_hits.value, 0);
        assert!(results.hits.is_empty());
    }

    #[test]
    fn empty_index() {
        let store = make_store(vec![]);
        let searcher = Searcher::new(&store);
        let results = searcher.search_query(
            &TermQuery {
                field: "body".into(),
                value: "hello".into(),
            },
            10,
            0,
        );
        assert_eq!(results.total_hits.value, 0);
        assert!(results.hits.is_empty());
    }
}
