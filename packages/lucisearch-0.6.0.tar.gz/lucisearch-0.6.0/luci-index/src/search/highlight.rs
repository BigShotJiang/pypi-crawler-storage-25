//! Search highlighting: re-analyze field text and wrap matched terms in tags.
//!
//! Runs in the result construction phase (post-scoring, per-hit) following
//! the same materialization pattern as explain and fields retrieval.
//!
//! See [[feature-search-highlight]].

use std::collections::{HashMap, HashSet};

use luci_analysis::{Analyzer, AnalyzerRegistry};

use crate::query::ast::ScoringExpression;

// --- Configuration types ---

/// Parsed highlight request from the search JSON.
///
/// See [[feature-search-highlight]].
#[derive(Clone, Debug)]
pub struct HighlightConfig {
    pub fields: Vec<HighlightFieldConfig>,
    pub pre_tags: Vec<String>,
    pub post_tags: Vec<String>,
    pub require_field_match: bool,
    pub order: HighlightOrder,
}

/// Per-field highlight settings (merges global + field-level overrides).
#[derive(Clone, Debug)]
pub struct HighlightFieldConfig {
    pub field: String,
    pub fragment_size: usize,
    pub number_of_fragments: usize,
    pub no_match_size: usize,
    pub pre_tags: Option<Vec<String>>,
    pub post_tags: Option<Vec<String>>,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum HighlightOrder {
    /// Return fragments in their order of appearance in the field text.
    None,
    /// Return fragments ordered by relevance score (best match first).
    Score,
}

// --- Internal types ---

#[derive(Clone, Debug)]
struct MatchedToken {
    offset_from: usize,
    offset_to: usize,
}

// --- Constants ---

const BOUNDARY_CHARS: &[char] = &['.', ',', '!', '?', ' ', '\t', '\n'];
const BOUNDARY_MAX_SCAN: usize = 20;

// --- Term extraction from query expression ---

/// Extract query terms from the expression tree, keyed by field name.
///
/// Walks the expression recursively. For text-analyzed queries (Match,
/// MatchPhrase), the query text is re-analyzed to get the actual
/// indexed terms.
///
/// See [[feature-search-highlight]].
pub(crate) fn extract_query_terms(
    ast: &ScoringExpression,
    searcher: &crate::search::searcher::Searcher,
) -> HashMap<String, HashSet<String>> {
    let mut terms: HashMap<String, HashSet<String>> = HashMap::new();
    collect_terms(ast, searcher, &mut terms);
    terms
}

fn collect_terms(
    ast: &ScoringExpression,
    searcher: &crate::search::searcher::Searcher,
    terms: &mut HashMap<String, HashSet<String>>,
) {
    let analyzers = searcher.analyzers();
    match ast {
        ScoringExpression::Term { field, value } => {
            terms
                .entry(field.clone())
                .or_default()
                .insert(value.clone());
        }
        ScoringExpression::Terms { field, values } => {
            let set = terms.entry(field.clone()).or_default();
            for v in values {
                set.insert(v.clone());
            }
        }
        ScoringExpression::Match {
            field,
            query,
            analyzer,
        } => {
            let analyzer_name = searcher.resolve_search_analyzer(field, analyzer.as_deref());
            let a = analyzers.get(analyzer_name);
            let tokens = a.analyze(query);
            let set = terms.entry(field.clone()).or_default();
            for token in tokens {
                set.insert(token.text);
            }
        }
        ScoringExpression::MatchPhrase {
            field,
            query,
            analyzer,
        } => {
            let analyzer_name = searcher.resolve_search_analyzer(field, analyzer.as_deref());
            let a = analyzers.get(analyzer_name);
            let tokens = a.analyze(query);
            let set = terms.entry(field.clone()).or_default();
            for token in tokens {
                set.insert(token.text);
            }
        }
        ScoringExpression::MatchBoolPrefix {
            field,
            query,
            analyzer,
        } => {
            let analyzer_name = searcher.resolve_search_analyzer(field, analyzer.as_deref());
            let a = analyzers.get(analyzer_name);
            let tokens = a.analyze(query);
            let set = terms.entry(field.clone()).or_default();
            for token in tokens {
                set.insert(token.text);
            }
        }
        ScoringExpression::Prefix { field, value } => {
            terms
                .entry(field.clone())
                .or_default()
                .insert(value.clone());
        }
        ScoringExpression::Fuzzy { field, value, .. } => {
            terms
                .entry(field.clone())
                .or_default()
                .insert(value.clone());
        }
        ScoringExpression::Wildcard { field, value } => {
            terms
                .entry(field.clone())
                .or_default()
                .insert(value.clone());
        }
        ScoringExpression::MultiMatch {
            fields,
            query,
            analyzer,
        } => {
            // For multi_match, use the first field's analyzer for all fields
            let analyzer_name = if let Some(f) = fields.first() {
                searcher.resolve_search_analyzer(f, analyzer.as_deref())
            } else {
                "standard"
            };
            let a = analyzers.get(analyzer_name);
            let tokens = a.analyze(query);
            for f in fields {
                let set = terms.entry(f.clone()).or_default();
                for token in &tokens {
                    set.insert(token.text.clone());
                }
            }
        }
        ScoringExpression::SpanTerm { field, value } => {
            terms
                .entry(field.clone())
                .or_default()
                .insert(value.clone());
        }
        ScoringExpression::SpanNear {
            field,
            terms: span_terms,
            ..
        } => {
            let set = terms.entry(field.clone()).or_default();
            for t in span_terms {
                set.insert(t.clone());
            }
        }
        // Recursive cases — descend into sub-queries
        ScoringExpression::Bool {
            must,
            should,
            must_not: _,
            filter,
            ..
        } => {
            for q in must.iter().chain(should).chain(filter) {
                collect_terms(q, searcher, terms);
            }
            // must_not terms are intentionally excluded — they are
            // exclusion criteria, not highlight targets.
        }
        ScoringExpression::DisMax { queries, .. } => {
            for q in queries {
                collect_terms(q, searcher, terms);
            }
        }
        ScoringExpression::ConstantScore { query, .. }
        | ScoringExpression::Boost { query, .. }
        | ScoringExpression::Nested { query, .. }
        | ScoringExpression::SpanNot { include: query, .. }
        | ScoringExpression::SpanFirst { query, .. } => {
            collect_terms(query, searcher, terms);
        }
        ScoringExpression::ScriptScore { query, .. }
        | ScoringExpression::FunctionScore { query, .. } => {
            collect_terms(query, searcher, terms);
        }
        ScoringExpression::Boosting { positive, .. } => {
            collect_terms(positive, searcher, terms);
        }
        // Leaf queries with no terms to extract
        ScoringExpression::Exists { .. }
        | ScoringExpression::Range { .. }
        | ScoringExpression::GeoDistance { .. }
        | ScoringExpression::GeoBoundingBox { .. }
        | ScoringExpression::GeoShape { .. }
        | ScoringExpression::Regexp { .. }
        | ScoringExpression::Knn { .. }
        | ScoringExpression::MatchAll
        | ScoringExpression::MatchNone => {}
    }
}

// --- Token matching ---

/// Re-analyze field text and find matching token positions.
fn find_matching_tokens(
    text: &str,
    query_terms: &HashSet<String>,
    analyzer: &Analyzer,
) -> Vec<MatchedToken> {
    let tokens = analyzer.analyze(text);
    tokens
        .into_iter()
        .filter(|token| query_terms.contains(&token.text))
        .map(|token| MatchedToken {
            offset_from: token.offset_from,
            offset_to: token.offset_to,
        })
        .collect()
}

// --- Fragment selection ---

/// Select the best fragments from the field text.
///
/// Uses a greedy approach: score each candidate window by summing
/// the weights of matched terms it contains, then greedily pick
/// the top non-overlapping fragments.
fn select_fragments(
    text: &str,
    matches: &[MatchedToken],
    fragment_size: usize,
    number_of_fragments: usize,
    order: HighlightOrder,
) -> Vec<(usize, usize, f32)> {
    if matches.is_empty() {
        return Vec::new();
    }
    if number_of_fragments == 0 {
        return vec![(0, text.len(), 1.0)];
    }

    // Build candidate windows centered on each match
    let mut candidates: Vec<(usize, usize, f32)> = Vec::new();

    for m in matches {
        let center = (m.offset_from + m.offset_to) / 2;
        let half = fragment_size / 2;
        let raw_start = center.saturating_sub(half);
        let raw_end = (raw_start + fragment_size).min(text.len());

        let start = snap_to_boundary(text, raw_start, true);
        let end = snap_to_boundary(text, raw_end, false);

        // Score: count matching tokens in this window
        let score: f32 = matches
            .iter()
            .filter(|t| t.offset_from >= start && t.offset_to <= end)
            .count() as f32;

        candidates.push((start, end, score));
    }

    // Sort by score descending, then by position
    candidates.sort_by(|a, b| {
        b.2.partial_cmp(&a.2)
            .unwrap_or(std::cmp::Ordering::Equal)
            .then_with(|| a.0.cmp(&b.0))
    });

    // Greedily select non-overlapping fragments
    let mut selected: Vec<(usize, usize, f32)> = Vec::new();
    for (start, end, score) in candidates {
        if selected.len() >= number_of_fragments {
            break;
        }
        let overlaps = selected.iter().any(|(s, e, _)| start < *e && end > *s);
        if !overlaps {
            selected.push((start, end, score));
        }
    }

    // Order: by score or by position
    match order {
        HighlightOrder::Score => {
            selected.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap_or(std::cmp::Ordering::Equal));
        }
        HighlightOrder::None => {
            selected.sort_by_key(|f| f.0);
        }
    }

    selected
}

/// Snap a byte offset to a nearby boundary character.
fn snap_to_boundary(text: &str, offset: usize, snap_left: bool) -> usize {
    if offset == 0 || offset >= text.len() {
        return offset;
    }
    let scan_range = if snap_left {
        offset.saturating_sub(BOUNDARY_MAX_SCAN)..offset
    } else {
        offset..(offset + BOUNDARY_MAX_SCAN).min(text.len())
    };

    if snap_left {
        for i in (scan_range.start..scan_range.end).rev() {
            if text.is_char_boundary(i) {
                if let Some(c) = text[i..].chars().next() {
                    if BOUNDARY_CHARS.contains(&c) {
                        return i + c.len_utf8();
                    }
                }
            }
        }
    } else {
        for i in scan_range {
            if text.is_char_boundary(i) {
                if let Some(c) = text[i..].chars().next() {
                    if BOUNDARY_CHARS.contains(&c) {
                        return i;
                    }
                }
            }
        }
    }

    offset
}

// --- Fragment formatting ---

/// Format a text fragment by inserting highlight tags around matched terms.
fn format_fragment(
    text: &str,
    fragment_start: usize,
    fragment_end: usize,
    matches: &[MatchedToken],
    pre_tags: &[String],
    post_tags: &[String],
) -> String {
    let mut in_fragment: Vec<&MatchedToken> = matches
        .iter()
        .filter(|m| m.offset_from >= fragment_start && m.offset_to <= fragment_end)
        .collect();
    in_fragment.sort_by_key(|m| m.offset_from);

    let fragment_text = &text[fragment_start..fragment_end];
    let mut result = String::with_capacity(fragment_text.len() + in_fragment.len() * 10);
    let mut last_end = fragment_start;

    for (i, m) in in_fragment.iter().enumerate() {
        result.push_str(&text[last_end..m.offset_from]);
        let tag_idx = i % pre_tags.len();
        result.push_str(&pre_tags[tag_idx]);
        result.push_str(&text[m.offset_from..m.offset_to]);
        result.push_str(&post_tags[tag_idx]);
        last_end = m.offset_to;
    }
    result.push_str(&text[last_end..fragment_end]);

    result
}

// --- Top-level highlight function ---

/// Generate highlights for a single search hit.
///
/// Reads field text from `_source`, re-analyzes, matches terms,
/// selects fragments, formats with tags. Returns a map of
/// field -> fragment arrays matching ES response format.
///
/// See [[feature-search-highlight]].
pub fn highlight_hit(
    source: &serde_json::Value,
    config: &HighlightConfig,
    query_terms: &HashMap<String, HashSet<String>>,
    analyzers: &AnalyzerRegistry,
    mapping: Option<&luci_mapping::Mapping>,
) -> Option<serde_json::Map<String, serde_json::Value>> {
    let obj = source.as_object()?;
    let mut highlight_map = serde_json::Map::new();

    for field_config in &config.fields {
        let field_name = &field_config.field;

        let all_terms: HashSet<String>;
        let effective_terms = if config.require_field_match {
            match query_terms.get(field_name) {
                Some(t) => t,
                None => continue,
            }
        } else {
            all_terms = query_terms.values().flatten().cloned().collect();
            &all_terms
        };

        if effective_terms.is_empty() {
            continue;
        }

        // Extract field text from _source
        let text = match obj.get(field_name) {
            Some(serde_json::Value::String(s)) if !s.is_empty() => s.as_str(),
            _ => continue,
        };

        // Resolve per-field index-time analyzer for re-analysis.
        // For highlighting, we tokenize field text with the index-time analyzer
        // (matching how it was indexed).
        let field_analyzer_name = mapping
            .and_then(|m| m.field_id(field_name))
            .and_then(|fid| mapping.unwrap().field(fid).analyzer.as_deref())
            .unwrap_or("standard");
        let analyzer = analyzers.get(field_analyzer_name);

        let matches = find_matching_tokens(text, effective_terms, analyzer);

        let pre_tags = field_config.pre_tags.as_ref().unwrap_or(&config.pre_tags);
        let post_tags = field_config.post_tags.as_ref().unwrap_or(&config.post_tags);

        if matches.is_empty() {
            if field_config.no_match_size > 0 {
                let end = snap_to_char_boundary(text, field_config.no_match_size.min(text.len()));
                let snippet = text[..end].to_string();
                highlight_map.insert(field_name.clone(), serde_json::json!([snippet]));
            }
            continue;
        }

        let fragments = select_fragments(
            text,
            &matches,
            field_config.fragment_size,
            field_config.number_of_fragments,
            config.order,
        );

        let formatted: Vec<String> = fragments
            .iter()
            .map(|(start, end, _score)| {
                format_fragment(text, *start, *end, &matches, pre_tags, post_tags)
            })
            .collect();

        if !formatted.is_empty() {
            highlight_map.insert(field_name.clone(), serde_json::json!(formatted));
        }
    }

    if highlight_map.is_empty() {
        None
    } else {
        Some(highlight_map)
    }
}

/// Snap byte offset to the nearest valid UTF-8 char boundary.
fn snap_to_char_boundary(text: &str, offset: usize) -> usize {
    if offset >= text.len() {
        return text.len();
    }
    let mut i = offset;
    while i > 0 && !text.is_char_boundary(i) {
        i -= 1;
    }
    i
}

// --- Request parsing ---

/// Parse highlight config from the search request JSON.
pub fn parse_highlight_config(json: &serde_json::Value) -> HighlightConfig {
    let pre_tags = json
        .get("pre_tags")
        .and_then(|v| v.as_array())
        .map(|arr| {
            arr.iter()
                .filter_map(|v| v.as_str().map(String::from))
                .collect()
        })
        .unwrap_or_else(|| vec!["<em>".to_string()]);

    let post_tags = json
        .get("post_tags")
        .and_then(|v| v.as_array())
        .map(|arr| {
            arr.iter()
                .filter_map(|v| v.as_str().map(String::from))
                .collect()
        })
        .unwrap_or_else(|| vec!["</em>".to_string()]);

    let require_field_match = json
        .get("require_field_match")
        .and_then(|v| v.as_bool())
        .unwrap_or(true);

    let order = match json.get("order").and_then(|v| v.as_str()) {
        Some("score") => HighlightOrder::Score,
        _ => HighlightOrder::None,
    };

    let fields =
        json.get("fields")
            .and_then(|v| v.as_object())
            .map(|obj| {
                obj.iter()
                    .map(|(name, field_json)| {
                        let fragment_size = field_json
                            .get("fragment_size")
                            .and_then(|v| v.as_u64())
                            .map(|v| v as usize)
                            .unwrap_or(100);
                        let number_of_fragments = field_json
                            .get("number_of_fragments")
                            .and_then(|v| v.as_u64())
                            .map(|v| v as usize)
                            .unwrap_or(5);
                        let no_match_size = field_json
                            .get("no_match_size")
                            .and_then(|v| v.as_u64())
                            .map(|v| v as usize)
                            .unwrap_or(0);
                        let field_pre_tags = field_json
                            .get("pre_tags")
                            .and_then(|v| v.as_array())
                            .map(|arr| {
                                arr.iter()
                                    .filter_map(|v| v.as_str().map(String::from))
                                    .collect()
                            });
                        let field_post_tags = field_json
                            .get("post_tags")
                            .and_then(|v| v.as_array())
                            .map(|arr| {
                                arr.iter()
                                    .filter_map(|v| v.as_str().map(String::from))
                                    .collect()
                            });

                        HighlightFieldConfig {
                            field: name.clone(),
                            fragment_size,
                            number_of_fragments,
                            no_match_size,
                            pre_tags: field_pre_tags,
                            post_tags: field_post_tags,
                        }
                    })
                    .collect()
            })
            .unwrap_or_default();

    HighlightConfig {
        fields,
        pre_tags,
        post_tags,
        require_field_match,
        order,
    }
}
