//! Tests for kNN as a ScoringExpression variant (query-level kNN).
//!
//! See [[feature-knn-query-type]].

use luci_index::index::Index;
use luci_index::search::expression::parse_search;
use luci_mapping::{FieldType, Mapping};
use serde_json::json;

fn test_dir(name: &str) -> std::path::PathBuf {
    let dir = std::env::temp_dir().join(format!("luci_knn_query_{}_{name}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    dir
}

fn cleanup(path: &std::path::Path) {
    let _ = std::fs::remove_dir_all(path);
}

fn build_index(name: &str) -> (std::path::PathBuf, Index) {
    let path = test_dir(name);
    let schema = Mapping::builder()
        .field("title", FieldType::Text)
        .field("tag", FieldType::Keyword)
        .field("embedding", FieldType::DenseVector { dims: 4 })
        .build();
    let index = Index::create_with_mapping(&path, schema).unwrap();

    index.bulk(vec![
        json!({"title": "search engine design", "tag": "tech", "embedding": [0.9, 0.1, 0.0, 0.0]}),
        json!({"title": "search algorithms", "tag": "tech", "embedding": [0.1, 0.9, 0.0, 0.0]}),
        json!({"title": "cute cats", "tag": "animal", "embedding": [0.0, 0.0, 0.9, 0.1]}),
        json!({"title": "search optimization", "tag": "tech", "embedding": [0.0, 0.0, 0.1, 0.9]}),
        json!({"title": "happy dog", "tag": "animal", "embedding": [0.0, 0.0, 0.0, 0.1]}),
    ]).unwrap();

    (path, index)
}

fn search(
    index: &Index,
    query: serde_json::Value,
    size: usize,
) -> luci_index::search::results::SearchResults {
    let expr = parse_search(query, size).unwrap();
    index.search(&expr).unwrap()
}

// --- 1. Standalone kNN query ---

#[test]
fn knn_query_standalone() {
    let (path, index) = build_index("standalone");

    let results = search(
        &index,
        json!({
            "query": {"knn": {
                "field": "embedding",
                "query_vector": [1.0, 0.0, 0.0, 0.0],
                "k": 3
            }}
        }),
        10,
    );

    assert_eq!(results.len(), 3);
    // Doc 0 (0.9, 0.1, 0, 0) is closest to (1, 0, 0, 0)
    assert_eq!(results.hit(0).unwrap().doc_id().as_u32(), 0);

    cleanup(&path);
}

// --- 2. Threshold filters low-similarity results ---

#[test]
fn knn_query_with_threshold() {
    let (path, index) = build_index("threshold");

    // Without threshold: get all 5
    let all = search(
        &index,
        json!({
            "query": {"knn": {
                "field": "embedding",
                "query_vector": [1.0, 0.0, 0.0, 0.0],
                "k": 5
            }}
        }),
        10,
    );
    assert_eq!(all.len(), 5);

    // With threshold: only close results
    let filtered = search(
        &index,
        json!({
            "query": {"knn": {
                "field": "embedding",
                "query_vector": [1.0, 0.0, 0.0, 0.0],
                "k": 5,
                "threshold": 0.6
            }}
        }),
        10,
    );

    // Doc 0 (0.9, 0.1, 0, 0) is very close → should pass
    // Far docs should be filtered
    assert!(
        filtered.len() < all.len(),
        "threshold should reduce results"
    );
    assert!(filtered.len() >= 1, "closest doc should pass threshold");

    cleanup(&path);
}

// --- 3. Threshold too high excludes all ---

#[test]
fn knn_query_threshold_excludes_all() {
    let (path, index) = build_index("threshold_all");

    let results = search(
        &index,
        json!({
            "query": {"knn": {
                "field": "embedding",
                "query_vector": [1.0, 0.0, 0.0, 0.0],
                "k": 5,
                "threshold": 0.999
            }}
        }),
        10,
    );

    // No exact match exists, threshold 0.999 should exclude everything
    assert_eq!(results.len(), 0);

    cleanup(&path);
}

// --- 4. kNN in bool.should (hybrid search) ---

#[test]
fn knn_query_in_bool_should() {
    let (path, index) = build_index("bool_should");

    let results = search(
        &index,
        json!({
            "query": {"bool": {"should": [
                {"match": {"title": "search engine"}},
                {"knn": {
                    "field": "embedding",
                    "query_vector": [1.0, 0.0, 0.0, 0.0],
                    "k": 3
                }}
            ]}}
        }),
        10,
    );

    assert!(!results.is_empty());
    // Doc 0 matches both text ("search engine design") and kNN (closest vector)
    // so it should be ranked first
    assert_eq!(results.hit(0).unwrap().doc_id().as_u32(), 0);

    cleanup(&path);
}

// --- 5. kNN in bool.must (conjunction) ---

#[test]
fn knn_query_in_bool_must() {
    let (path, index) = build_index("bool_must");

    let results = search(
        &index,
        json!({
            "query": {"bool": {"must": [
                {"match": {"title": "search"}},
                {"knn": {
                    "field": "embedding",
                    "query_vector": [1.0, 0.0, 0.0, 0.0],
                    "k": 5
                }}
            ]}}
        }),
        10,
    );

    // Only docs matching BOTH text "search" AND in kNN top-5
    // "search" matches docs 0, 1, 3. All are in kNN top-5.
    for hit in results.iter() {
        let source = hit.source().unwrap();
        let title = source["title"].as_str().unwrap();
        assert!(
            title.contains("search"),
            "must conjunction: doc should match 'search', got '{title}'"
        );
    }

    cleanup(&path);
}

// --- 6. kNN in bool.filter (vector as filter) ---

#[test]
fn knn_query_in_bool_filter() {
    let (path, index) = build_index("bool_filter");

    let results = search(
        &index,
        json!({
            "query": {"bool": {
                "must": [{"match": {"title": "search"}}],
                "filter": [{"knn": {
                    "field": "embedding",
                    "query_vector": [1.0, 0.0, 0.0, 0.0],
                    "k": 2
                }}]
            }}
        }),
        10,
    );

    // "search" matches docs 0, 1, 3
    // kNN top-2 closest to (1,0,0,0): doc 0 (0.9,0.1,0,0), doc 1 (0.1,0.9,0,0)
    // Intersection: docs 0 and 1
    assert!(results.len() <= 2, "filter should restrict to kNN top-2");
    for hit in results.iter() {
        let id = hit.doc_id().as_u32();
        assert!(id == 0 || id == 1, "expected doc 0 or 1, got {id}");
    }

    cleanup(&path);
}

// --- 7. num_candidates defaults to 1.5 * k ---

#[test]
fn knn_query_num_candidates_default() {
    // Verify the parse succeeds without num_candidates specified
    // (verifies the default path doesn't error)
    let _expr = parse_search(
        json!({
            "query": {"knn": {
                "field": "f",
                "query_vector": [1.0],
                "k": 10
            }}
        }),
        10,
    )
    .unwrap();
}

// --- 8. Scores are descending ---

#[test]
fn knn_query_scores_descending() {
    let (path, index) = build_index("scores_desc");

    let results = search(
        &index,
        json!({
            "query": {"knn": {
                "field": "embedding",
                "query_vector": [1.0, 0.0, 0.0, 0.0],
                "k": 5
            }}
        }),
        10,
    );

    for i in 0..results.len().saturating_sub(1) {
        let a = results.hit(i).unwrap().score();
        let b = results.hit(i + 1).unwrap().score();
        assert!(
            a >= b,
            "scores should be descending: hit[{i}]={a} < hit[{}]={b}",
            i + 1
        );
    }

    cleanup(&path);
}

// --- 9. Scores non-negative ---

#[test]
fn knn_query_score_range() {
    let (path, index) = build_index("score_range");

    let results = search(
        &index,
        json!({
            "query": {"knn": {
                "field": "embedding",
                "query_vector": [1.0, 0.0, 0.0, 0.0],
                "k": 5
            }}
        }),
        10,
    );

    for hit in results.iter() {
        let s = hit.score();
        // Cosine metric: scores are in [0, 1]. Other metrics may exceed 1
        // for unnormalized vectors (matching Lucene behavior).
        assert!(s >= 0.0, "score should be non-negative, got {s}");
    }

    cleanup(&path);
}

// --- 10. Explain works ---

#[test]
fn knn_query_explain() {
    let (path, index) = build_index("explain");

    let results = search(
        &index,
        json!({
            "query": {"knn": {
                "field": "embedding",
                "query_vector": [1.0, 0.0, 0.0, 0.0],
                "k": 3
            }}
        }),
        10,
    );

    let hit = results.hit(0).unwrap();
    let explanation = hit.explain();
    assert!(
        explanation.is_some(),
        "kNN query should produce an explanation"
    );
    let expl = explanation.unwrap();
    assert!(expl.value > 0.0, "explanation score should be > 0");

    cleanup(&path);
}

// --- 12. Non-numeric query_vector is rejected ---

#[test]
fn knn_query_invalid_vector() {
    let result = parse_search(
        json!({
            "query": {"knn": {
                "field": "embedding",
                "query_vector": [1, "bad", 3]
            }}
        }),
        10,
    );

    assert!(
        result.is_err(),
        "non-numeric vector elements should be rejected"
    );
}

// --- 13. k=0 is rejected ---

#[test]
fn knn_query_zero_k() {
    let result = parse_search(
        json!({
            "query": {"knn": {
                "field": "embedding",
                "query_vector": [1.0, 0.0, 0.0, 0.0],
                "k": 0
            }}
        }),
        10,
    );

    assert!(result.is_err(), "k=0 should be rejected");
}

// --- 14. Bool must correctness (validates doc_id sort fix) ---

#[test]
fn knn_query_bool_must_correctness() {
    let path = test_dir("bool_must_correct");
    let schema = Mapping::builder()
        .field("tag", FieldType::Keyword)
        .field("embedding", FieldType::DenseVector { dims: 4 })
        .build();
    let index = Index::create_with_mapping(&path, schema).unwrap();

    // 20 docs: 5 tagged "target", 15 tagged "other"
    // Vectors are spread across 4D space
    let mut docs = Vec::new();
    for i in 0..20 {
        let tag = if i < 5 { "target" } else { "other" };
        let angle = (i as f32) * 0.3;
        let v = [
            angle.cos(),
            angle.sin(),
            (angle * 0.5).cos(),
            (angle * 0.5).sin(),
        ];
        docs.push(json!({"tag": tag, "embedding": v}));
    }
    index.bulk(docs).unwrap();

    // kNN top-10 should include some "target" and some "other" docs
    let knn_only = search(
        &index,
        json!({
            "query": {"knn": {
                "field": "embedding",
                "query_vector": [1.0, 0.0, 1.0, 0.0],
                "k": 10
            }}
        }),
        10,
    );

    // Term match: only "target" docs
    let term_only = search(
        &index,
        json!({
            "query": {"term": {"tag": "target"}}
        }),
        10,
    );

    // Conjunction: must match both
    let conjunction = search(
        &index,
        json!({
            "query": {"bool": {"must": [
                {"term": {"tag": "target"}},
                {"knn": {
                    "field": "embedding",
                    "query_vector": [1.0, 0.0, 1.0, 0.0],
                    "k": 10
                }}
            ]}}
        }),
        10,
    );

    let knn_ids: std::collections::HashSet<u32> =
        knn_only.iter().map(|h| h.doc_id().as_u32()).collect();
    let term_ids: std::collections::HashSet<u32> =
        term_only.iter().map(|h| h.doc_id().as_u32()).collect();

    // Every conjunction result must be in BOTH kNN and term results
    for hit in conjunction.iter() {
        let id = hit.doc_id().as_u32();
        assert!(
            knn_ids.contains(&id),
            "conjunction doc {id} not in kNN results"
        );
        assert!(
            term_ids.contains(&id),
            "conjunction doc {id} not in term results"
        );
    }

    // Conjunction should not be empty (some target docs should be in kNN top-10)
    assert!(
        !conjunction.is_empty(),
        "conjunction should find at least one doc matching both conditions"
    );

    cleanup(&path);
}

// --- 11. Dimension mismatch at bind time ---
// Note: search_query() currently swallows bind errors and returns empty results.
// The dimension validation error in KnnQuery::bind() causes zero results
// rather than a search-level error. This is a pre-existing design choice
// in the scorer pipeline. The validation still prevents garbage HNSW results.

#[test]
fn knn_query_dimension_mismatch() {
    let (path, index) = build_index("dim_mismatch");

    let results = search(
        &index,
        json!({
            "query": {"knn": {
                "field": "embedding",
                "query_vector": [1.0, 2.0],
                "k": 5
            }}
        }),
        10,
    );

    // Bind error → zero results (not garbage HNSW results)
    assert_eq!(
        results.len(),
        0,
        "dimension mismatch should produce no results"
    );

    cleanup(&path);
}
