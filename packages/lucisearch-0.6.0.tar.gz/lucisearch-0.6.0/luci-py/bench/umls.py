"""UMLS concept corpus for multi-segment parallel search benchmarks.

Joins MRCONSO (atoms) and MRSTY (semantic types) via DuckDB to produce
one document per CUI:

    {
        "cui": "C0000005",
        "semantic_type": ["Amino Acid, Peptide, or Protein", ...],
        "atoms": [
            {"code": "D012711", "sab": "MSH", "text": "(131)I-MAA"},
            ...
        ]
    }

Requires: ~/data/umls/installed/2025AA/META/{MRCONSO,MRSTY}.RRF
"""

import argparse
import sys
import tempfile
import time
from pathlib import Path

import duckdb

import luci

UMLS_META = Path.home() / "data" / "umls" / "installed" / "2025AA" / "META"
MRCONSO = UMLS_META / "MRCONSO.RRF"
MRSTY = UMLS_META / "MRSTY.RRF"

MAPPING = {
    "properties": {
        "cui": {"type": "keyword"},
        "semantic_type": {"type": "keyword"},
        "text": {"type": "text"},
        "embedding": {"type": "dense_vector", "dims": 512},
    },
}


def load_concepts(limit: int | None = None) -> list[dict]:
    """Load UMLS concepts via DuckDB join, returning dicts ready for indexing."""
    if not MRCONSO.exists():
        print(f"MRCONSO not found at {MRCONSO}", file=sys.stderr)
        sys.exit(1)

    con = duckdb.connect()

    # MRCONSO columns (pipe-delimited):
    # CUI|LAT|TS|LUI|STT|SUI|ISPREF|AUI|SAUI|
    # SCUI|SDUI|SAB|TTY|CODE|STR|SRL|SUPPRESS|CVF|
    conso_cols = (
        "cui,lat,ts,lui,stt,sui,ispref,aui,saui,"
        "scui,sdui,sab,tty,code,str,srl,"
        "suppress,cvf,_trail"
    )
    names_list = ",".join(f"'{c}'" for c in conso_cols.split(","))
    con.execute(f"""
        CREATE TABLE conso AS
        SELECT cui, sab, code, str
        FROM read_csv('{MRCONSO}',
            delim='|', header=false,
            names=[{names_list}], quote='')
        WHERE lat = 'ENG' AND suppress = 'N'
    """)

    # MRSTY columns: CUI|TUI|STN|STY|ATUI|CVF|
    sty_cols = "cui,tui,stn,sty,atui,cvf,_trail"
    sty_names = ",".join(f"'{c}'" for c in sty_cols.split(","))
    con.execute(f"""
        CREATE TABLE sty AS
        SELECT DISTINCT cui, sty
        FROM read_csv('{MRSTY}',
            delim='|', header=false,
            names=[{sty_names}], quote='')
    """)

    # Join: one row per concept with aggregated semantic types and atoms
    limit_clause = f"LIMIT {limit}" if limit else ""
    rows = con.execute(f"""
        WITH concept_stys AS (
            SELECT cui, list(DISTINCT sty ORDER BY sty) AS semantic_types
            FROM sty GROUP BY cui
        ),
        concept_atoms AS (
            SELECT cui,
                   list(struct_pack(code := code, sab := sab, text := str)) AS atoms,
                   string_agg(DISTINCT str, ' ') AS all_text
            FROM conso GROUP BY cui
        )
        SELECT a.cui, s.semantic_types, a.atoms, a.all_text
        FROM concept_atoms a
        JOIN concept_stys s ON a.cui = s.cui
        ORDER BY a.cui
        {limit_clause}
    """).fetchall()

    con.close()

    docs = []
    for cui, stys, atoms, all_text in rows:
        doc = {
            "cui": cui,
            "semantic_type": stys,
            "text": all_text or "",
        }
        # Flatten atoms from duckdb struct to plain dicts
        doc["atoms"] = [
            {
                "code": a["code"],
                "sab": a["sab"],
                "text": a["text"],
            }
            for a in atoms
        ]
        docs.append(doc)

    return docs


def build_index(
    docs: list[dict],
    path: str | Path,
    memory_budget: int = 16 * 1024 * 1024,
) -> luci.Index:
    """Index UMLS concepts into Luci with a given memory budget."""
    index = luci.Index.create(str(path), MAPPING, memory_budget=memory_budget)
    index.bulk(docs)
    return index


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Build UMLS concept index")
    parser.add_argument("-n", type=int, default=None, help="Limit concepts")
    parser.add_argument("--budget", type=int, default=16, help="Memory budget in MB")
    args = parser.parse_args()

    print(f"Loading UMLS concepts{f' (limit {args.n})' if args.n else ''}...")
    t0 = time.perf_counter()
    docs = load_concepts(args.n)
    t_load = time.perf_counter() - t0
    print(f"Loaded {len(docs):,} concepts in {t_load:.1f}s")

    with tempfile.TemporaryDirectory(prefix="luci_umls_") as tmpdir:
        idx_path = Path(tmpdir) / "umls.luci"
        budget = args.budget * 1024 * 1024

        print(f"Indexing with {args.budget}MB memory budget...")
        t0 = time.perf_counter()
        index = build_index(docs, idx_path, memory_budget=budget)
        t_idx = time.perf_counter() - t0
        print(f"Indexed in {t_idx:.1f}s ({len(docs) / t_idx:.0f} docs/s)")

        # Quick search test
        results = index.search({"match": {"text": "aspirin"}}, size=5)
        th = results["total_hits"]
        hit_count = th["value"] if isinstance(th, dict) else th
        print(f"\nSearch 'aspirin': {hit_count} hits")
        for hit in results["hits"]:
            src = hit["_source"]
            print(f"  {src['cui']} ({src['semantic_type'][0]}): {src['text'][:80]}")
