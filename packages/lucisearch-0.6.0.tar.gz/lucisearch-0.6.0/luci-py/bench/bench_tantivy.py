"""Benchmark Luci vs Tantivy (in-process Rust search libraries).

Both are embeddable, in-process, no HTTP overhead -- true apples-to-apples.
"""

from __future__ import annotations

import random
import shutil
import tempfile
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

import tantivy

import luci

if TYPE_CHECKING:
    from collections.abc import Callable

# --- Corpus ---

DOC_COUNT = 100_000
random.seed(42)

TAGS = ["technology", "science", "sports", "politics", "entertainment"]
WORDS = [
    "search",
    "engine",
    "document",
    "index",
    "query",
    "fast",
    "embedded",
    "rust",
    "python",
    "database",
    "storage",
    "analysis",
    "text",
    "full",
    "match",
    "filter",
    "aggregate",
    "score",
    "relevance",
    "ranking",
]


def build_corpus() -> list[dict[str, Any]]:
    docs: list[dict[str, Any]] = []
    for i in range(DOC_COUNT):
        tag = TAGS[i % 5]
        title_words = random.sample(WORDS, random.randint(3, 6))
        body_words = random.sample(WORDS, random.randint(8, 15))
        docs.append(
            {
                "title": " ".join(title_words),
                "body": " ".join(body_words),
                "tag": tag,
                "price": round(random.uniform(1.0, 100.0), 2),
            },
        )
    return docs


# --- Luci setup ---


def build_luci_index(
    docs: list[dict[str, Any]],
) -> tuple[luci.Index, str]:
    tmpdir = tempfile.mkdtemp(prefix="luci_bench_")
    path = Path(tmpdir) / "bench.luci"
    mapping = {
        "properties": {
            "title": {"type": "text"},
            "body": {"type": "text"},
            "tag": {"type": "keyword"},
            "price": {"type": "float"},
        },
    }
    index = luci.Index.create(str(path), mapping)
    index.bulk(docs)
    return index, tmpdir


# --- Tantivy setup ---


def build_tantivy_index(
    docs: list[dict[str, Any]],
) -> tuple[Any, Any, str]:
    tmpdir = tempfile.mkdtemp(prefix="tantivy_bench_")
    schema_builder = tantivy.SchemaBuilder()
    schema_builder.add_text_field(
        "title",
        stored=True,
        tokenizer_name="default",
    )
    schema_builder.add_text_field(
        "body",
        stored=True,
        tokenizer_name="default",
    )
    schema_builder.add_text_field(
        "tag",
        stored=True,
        tokenizer_name="raw",
    )
    schema_builder.add_float_field("price", stored=True, fast=True)
    schema = schema_builder.build()

    index = tantivy.Index(schema, path=tmpdir)
    writer = index.writer(heap_size=64 * 1024 * 1024)
    for doc in docs:
        writer.add_document(
            tantivy.Document(
                title=doc["title"],
                body=doc["body"],
                tag=doc["tag"],
                price=doc["price"],
            ),
        )
    writer.commit()
    index.reload()
    return index, schema, tmpdir


# --- Measurement ---


def measure(
    fn: Callable[[], Any],
    warmup: int = 30,
    iters: int = 200,
) -> float:
    for _ in range(warmup):
        fn()
    times: list[float] = []
    for _ in range(iters):
        t0 = time.perf_counter()
        fn()
        times.append((time.perf_counter() - t0) * 1e6)
    times.sort()
    return times[len(times) // 2]  # p50


# --- Benchmarks ---


def run_benchmarks() -> None:
    print(f"Building {DOC_COUNT:,} doc corpus...")
    docs = build_corpus()

    print("Building Luci index...")
    t0 = time.perf_counter()
    luci_index, luci_dir = build_luci_index(docs)
    luci_time = time.perf_counter() - t0
    print(f"  Luci indexed in {luci_time:.1f}s ({DOC_COUNT / luci_time:.0f} docs/s)")

    print("Building Tantivy index...")
    t0 = time.perf_counter()
    tv_index, _tv_schema, tv_dir = build_tantivy_index(docs)
    tv_time = time.perf_counter() - t0
    print(f"  Tantivy indexed in {tv_time:.1f}s ({DOC_COUNT / tv_time:.0f} docs/s)")

    tv_searcher = tv_index.searcher()

    print()
    print("=" * 70)
    print(f"Luci vs Tantivy ({DOC_COUNT:,} docs)")
    print("=" * 70)
    print(f"{'Query':<30} {'Luci p50':>10} {'Tantivy p50':>12} {'Speedup':>10}")
    print("-" * 70)

    benchmarks = []

    # --- Text queries ---

    # Single term match
    def luci_match_single() -> None:
        luci_index.search({"match": {"title": "search"}}, size=10)

    def tv_match_single() -> None:
        q = tv_index.parse_query("search", ["title"])
        tv_searcher.search(q, 10)

    benchmarks.append(("match_single", luci_match_single, tv_match_single))

    # Multi-word match
    def luci_match_multi() -> None:
        luci_index.search(
            {"query": {"match": {"title": "search engine fast"}}, "size": 10},
        )

    def tv_match_multi() -> None:
        q = tv_index.parse_query("search engine fast", ["title"])
        tv_searcher.search(q, 10)

    benchmarks.append(("match_multi", luci_match_multi, tv_match_multi))

    # Phrase match
    def luci_phrase() -> None:
        luci_index.search(
            {"query": {"match_phrase": {"title": "search engine"}}, "size": 10},
        )

    def tv_phrase() -> None:
        q = tv_index.parse_query('"search engine"', ["title"])
        tv_searcher.search(q, 10)

    benchmarks.append(("match_phrase", luci_phrase, tv_phrase))

    # --- Keyword queries ---

    def luci_term() -> None:
        luci_index.search({"term": {"tag": "technology"}}, size=10)

    def tv_term() -> None:
        q = tv_index.parse_query("technology", ["tag"])
        tv_searcher.search(q, 10)

    benchmarks.append(("term_keyword", luci_term, tv_term))

    # --- Boolean queries ---

    def luci_bool() -> None:
        luci_index.search(
            {
                "query": {
                    "bool": {
                        "must": [
                            {"match": {"title": "search"}},
                            {"term": {"tag": "technology"}},
                        ],
                    },
                },
                "size": 10,
            },
        )

    def tv_bool() -> None:
        q = tv_index.parse_query("title:search AND tag:technology", ["title"])
        tv_searcher.search(q, 10)

    benchmarks.append(("bool_must", luci_bool, tv_bool))

    # --- Prefix query ---
    # Note: Tantivy's parse_query doesn't support prefix queries on keyword fields
    # via the query parser. Skipping this comparison — not a fair test.

    # --- Fuzzy query ---
    # Note: Tantivy fuzzy via query parser syntax differs. Skipping.

    # --- Match all ---

    def luci_match_all() -> None:
        luci_index.search({"match_all": {}}, size=10)

    def tv_match_all() -> None:
        q = tv_index.parse_query("*", ["title"])
        tv_searcher.search(q, 10)

    benchmarks.append(("match_all", luci_match_all, tv_match_all))

    # --- Pagination (from offset) ---

    def luci_from_1000() -> None:
        luci_index.search(
            {"query": {"match_all": {}}, "from": 1000, "size": 10},
        )

    # Tantivy doesn't have from/offset -- must collect 1010 and skip
    def tv_from_1000() -> None:
        q = tv_index.parse_query("*", ["title"])
        tv_searcher.search(q, 1010)

    benchmarks.append(("from_1000", luci_from_1000, tv_from_1000))

    # --- Source retrieval disabled ---

    def luci_no_source() -> None:
        luci_index.search(
            {"query": {"match": {"title": "search"}}, "_source": False, "size": 10},
        )

    def tv_no_source() -> None:
        q = tv_index.parse_query("search", ["title"])
        tv_searcher.search(q, 10)  # tantivy doesn't retrieve source by default

    benchmarks.append(("no_source", luci_no_source, tv_no_source))

    # --- Explain ---

    def luci_explain() -> None:
        luci_index.search(
            {"query": {"match": {"title": "search"}}, "explain": True, "size": 10},
        )

    # Tantivy-py doesn't expose explain()
    def tv_explain() -> None:
        q = tv_index.parse_query("search", ["title"])
        tv_searcher.search(q, 10)

    benchmarks.append(("explain (luci only)", luci_explain, tv_explain))

    # --- Wildcard ---

    def luci_wildcard() -> None:
        luci_index.search({"wildcard": {"tag": "tech*"}}, size=10)

    def tv_wildcard() -> None:
        q = tantivy.Query.regex_query(tv_index.schema, "tag", "tech.*")
        tv_searcher.search(q, 10)

    benchmarks.append(("wildcard (tech*)", luci_wildcard, tv_wildcard))

    # --- Fuzzy ---

    def luci_fuzzy() -> None:
        luci_index.search(
            {"fuzzy": {"tag": {"value": "technoogy", "fuzziness": 1}}},
            size=10,
        )

    def tv_fuzzy() -> None:
        q = tantivy.Query.fuzzy_term_query(
            tv_index.schema,
            "tag",
            "technoogy",
            1,
            True,
        )
        tv_searcher.search(q, 10)

    benchmarks.append(("fuzzy (d=1)", luci_fuzzy, tv_fuzzy))

    # --- Indexing throughput ---

    def measure_luci_indexing() -> float:
        subset = docs[:10000]
        times: list[float] = []
        for _ in range(3):
            t0 = time.perf_counter()
            _, d = build_luci_index(subset)
            elapsed = time.perf_counter() - t0
            times.append(len(subset) / elapsed)
            shutil.rmtree(d)
        times.sort()
        return times[1]

    def measure_tv_indexing() -> float:
        subset = docs[:10000]
        times: list[float] = []
        for _ in range(3):
            t0 = time.perf_counter()
            _, _, d = build_tantivy_index(subset)
            elapsed = time.perf_counter() - t0
            times.append(len(subset) / elapsed)
            shutil.rmtree(d)
        times.sort()
        return times[1]

    luci_throughput = measure_luci_indexing()
    tv_throughput = measure_tv_indexing()

    # --- Run all query benchmarks ---

    for name, luci_fn, tv_fn in benchmarks:
        luci_p50 = measure(luci_fn)
        tv_p50 = measure(tv_fn)
        speedup = tv_p50 / luci_p50 if luci_p50 > 0 else float("inf")
        marker = " ***" if speedup < 1.0 else ""
        line = (
            f"{name:<30} {luci_p50:>8.0f}us {tv_p50:>10.0f}us {speedup:>8.1f}x{marker}"
        )
        print(line)

    # Indexing
    speedup = tv_throughput / luci_throughput if luci_throughput > 0 else 0
    marker = " ***" if speedup > 1.0 else ""
    idx_line = (
        f"{'indexing (docs/s)':<30} {luci_throughput:>8.0f}"
        f"   {tv_throughput:>10.0f}   {speedup:>8.1f}x{marker}"
    )
    print(idx_line)

    print()
    print("*** = Tantivy faster")

    # Cleanup
    shutil.rmtree(luci_dir)
    shutil.rmtree(tv_dir)


if __name__ == "__main__":
    run_benchmarks()
