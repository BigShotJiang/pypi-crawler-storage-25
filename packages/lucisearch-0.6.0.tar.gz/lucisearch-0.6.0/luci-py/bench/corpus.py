"""Shared corpus generation for Luci benchmarks.

All benchmark scripts MUST use this module to generate test documents.
Using different corpus generators produces incomparable results due to
different segment sizes and posting list layouts.
"""

import math

DOC_COUNT = 100_000

TOPICS = ["technology", "science", "sports", "politics", "entertainment"]
SUBTOPICS = [
    "artificial intelligence",
    "machine learning",
    "quantum computing",
    "climate change",
    "renewable energy",
    "space exploration",
    "football",
    "basketball",
    "tennis",
    "elections",
    "policy",
    "legislation",
    "movies",
    "music",
    "gaming",
]
CATEGORIES = [f"cat_{i}" for i in range(50)]
CITIES = [
    ("New York", 40.7128, -74.0060),
    ("London", 51.5074, -0.1278),
    ("Paris", 48.8566, 2.3522),
    ("Tokyo", 35.6762, 139.6503),
    ("Sydney", -33.8688, 151.2093),
]
SELLERS = ["alice", "bob", "charlie", "diana", "eve"]

MAPPING: dict = {
    "properties": {
        "title": {"type": "text"},
        "body": {"type": "text"},
        "tag": {"type": "keyword"},
        "category": {"type": "keyword"},
        "price": {"type": "float"},
        "location": {"type": "geo_point"},
        "boundary": {"type": "geo_shape"},
        "offers": {"type": "nested"},
        "offers.seller": {"type": "keyword"},
        "offers.price": {"type": "keyword"},
        "embedding": {"type": "dense_vector", "dims": 32},
    },
}


def _splitmix64(seed: int) -> int:
    """SplitMix64 — high-quality deterministic hash function."""
    seed = (seed + 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
    seed = ((seed ^ (seed >> 30)) * 0xBF58476D1CE4E5B9) & 0xFFFFFFFFFFFFFFFF
    seed = ((seed ^ (seed >> 27)) * 0x94D049BB133111EB) & 0xFFFFFFFFFFFFFFFF
    return (seed ^ (seed >> 31)) & 0xFFFFFFFFFFFFFFFF


def _pseudo_random(seed: int) -> float:
    """Deterministic pseudo-random float in [0, 1)."""
    return (_splitmix64(seed) >> 11) / (1 << 53)


def _make_vector(i: int, dims: int = 32) -> list[float]:
    """Generate a deterministic unit vector with good dispersion."""
    raw = [_pseudo_random(i * dims + d) * 2 - 1 for d in range(dims)]
    norm = math.sqrt(sum(x * x for x in raw))
    return [round(x / norm, 6) for x in raw] if norm > 0 else raw


def generate_doc(i: int) -> dict:
    """Generate a deterministic document with all field types."""
    topic = TOPICS[i % len(TOPICS)]
    subtopic = SUBTOPICS[i % len(SUBTOPICS)]
    category = CATEGORIES[i % len(CATEGORIES)]
    _city_name, base_lat, base_lon = CITIES[i % len(CITIES)]

    lat_jitter = (_pseudo_random(i * 2) - 0.5) * 0.5
    lon_jitter = (_pseudo_random(i * 2 + 1) - 0.5) * 0.5

    num_offers = (i % 3) + 1
    offers = [
        {
            "seller": SELLERS[(i + j) % len(SELLERS)],
            "price": str((i * 10 + j * 100) % 1000),
        }
        for j in range(num_offers)
    ]

    # Geo shape: polygon around the location point (varying radius)
    lat = round(base_lat + lat_jitter, 4)
    lon = round(base_lon + lon_jitter, 4)
    r = 0.01 + _pseudo_random(i * 3 + 99) * 0.09  # 0.01-0.10 degrees

    return {
        "title": f"document {i} about {topic} topics",
        "body": (
            f"this is the body text for document {i} covering {topic} "
            f"related content and discussions about {subtopic} "
            f"in the field of {category} research and development"
        ),
        "tag": topic,
        "category": category,
        "price": round((i % 1000) + 0.99, 2),
        "location": {"lat": lat, "lon": lon},
        "boundary": {
            "type": "Polygon",
            "coordinates": [
                [
                    [round(lon - r, 4), round(lat - r, 4)],
                    [round(lon + r, 4), round(lat - r, 4)],
                    [round(lon + r, 4), round(lat + r, 4)],
                    [round(lon - r, 4), round(lat + r, 4)],
                    [round(lon - r, 4), round(lat - r, 4)],
                ],
            ],
        },
        "offers": offers,
        "embedding": _make_vector(i),
    }


def generate_corpus(count: int = DOC_COUNT) -> list[dict]:
    """Generate the standard benchmark corpus."""
    return [generate_doc(i) for i in range(count)]
