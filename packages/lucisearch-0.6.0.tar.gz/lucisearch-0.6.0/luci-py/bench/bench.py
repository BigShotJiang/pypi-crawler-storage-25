"""Luci benchmark CLI.

Run individual or grouped benchmark queries against the standard corpus.
Optionally compare against Elasticsearch.

Usage::

    uv run python bench.py                         # all queries, Luci only
    uv run python bench.py term terms              # specific queries
    uv run python bench.py -g keyword              # preset group
    uv run python bench.py --vs-es                 # compare with ES
    uv run python bench.py --vs-es match_multi     # compare specific query
    uv run python bench.py -l                      # list queries and groups
"""

import contextlib
import datetime
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from collections.abc import Callable, Generator
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen

import typer

# Add bench/ to path for corpus import
sys.path.insert(0, str(Path(__file__).parent))

from corpus import DOC_COUNT, MAPPING, _make_vector, generate_corpus
from profiling import ALL_SUITES, current_rss_kb
from results import REPO_ROOT, ResultsDB

try:
    from testcontainers.elasticsearch import (
        ElasticSearchContainer,
    )
except ImportError:
    ElasticSearchContainer = None  # type: ignore[assignment,misc]

try:
    from umls import build_index, load_concepts
except ImportError:
    build_index = None  # type: ignore[assignment]
    load_concepts = None  # type: ignore[assignment]

import luci

app = typer.Typer(help="Luci benchmark CLI")

# --- Constants ---

ES_INDEX = "luci_bench"
ES_IMAGE = "docker.elastic.co/elasticsearch/elasticsearch:9.3.1"
WARMUP_DEFAULT = 50
ITERATIONS_DEFAULT = 500


# --- Query registry ---


def _build_queries() -> dict[str, dict[str, Any]]:
    """Build the query registry with the knn vector precomputed."""
    qv = _make_vector(0)
    return {
        "term": {"term": {"tag": "technology"}},
        "terms": {"terms": {"tag": ["technology", "science"]}},
        "exists": {"exists": {"field": "price"}},
        "prefix": {"prefix": {"tag": "tech"}},
        "wildcard": {"wildcard": {"tag": "tech*"}},
        "regexp": {"regexp": {"tag": "sci.*ce"}},
        "fuzzy": {"fuzzy": {"tag": {"value": "technoogy", "fuzziness": 1}}},
        "boosting": {
            "boosting": {
                "positive": {"match": {"title": "document"}},
                "negative": {"term": {"tag": "sports"}},
                "negative_boost": 0.5,
            },
        },
        "function_score": {
            "function_score": {
                "query": {"match": {"title": "document"}},
                "field_value_factor": {
                    "field": "price",
                    "modifier": "log1p",
                    "missing": 1,
                },
                "boost_mode": "multiply",
            },
        },
        "match_single": {"match": {"title": "technology"}},
        "match_multi": {"match": {"title": "document technology topics"}},
        "multi_match": {
            "multi_match": {
                "query": "document technology",
                "fields": ["title", "body"],
            },
        },
        "match_phrase": {"match_phrase": {"body": "related content"}},
        "match_all": {"match_all": {}},
        "bool_must+filter": {
            "bool": {
                "must": [{"match": {"title": "document"}}],
                "filter": [{"term": {"tag": "science"}}],
            },
        },
        "bool_must_not": {
            "bool": {
                "must": [{"match": {"title": "document"}}],
                "must_not": [{"term": {"tag": "sports"}}],
            },
        },
        "bool_should": {
            "bool": {
                "should": [
                    {"term": {"tag": "technology"}},
                    {"term": {"tag": "science"}},
                ],
            },
        },
        "geo_distance": {
            "geo_distance": {
                "distance": "50km",
                "location": {"lat": 40.7128, "lon": -74.006},
            },
        },
        "geo_bbox": {
            "geo_bounding_box": {
                "location": {
                    "top_left": {"lat": 41.0, "lon": -74.5},
                    "bottom_right": {"lat": 40.4, "lon": -73.5},
                },
            },
        },
        "nested_term": {
            "nested": {
                "path": "offers",
                "query": {"term": {"offers.seller": "alice"}},
            },
        },
        "nested_bool": {
            "nested": {
                "path": "offers",
                "query": {
                    "bool": {
                        "must": [
                            {"term": {"offers.seller": "alice"}},
                            {"term": {"offers.price": "100"}},
                        ],
                    },
                },
            },
        },
        "terms_agg": {
            "query": {"match_all": {}},
            "aggs": {"by_tag": {"terms": {"field": "tag"}}},
            "size": 0,
        },
        "avg_agg": {
            "query": {"match_all": {}},
            "aggs": {"avg_price": {"avg": {"field": "price"}}},
            "size": 0,
        },
        "query+agg": {
            "query": {"term": {"tag": "technology"}},
            "aggs": {"avg_price": {"avg": {"field": "price"}}},
            "size": 0,
        },
        "range_narrow": {
            "range": {"price": {"gte": 100, "lt": 110}},
        },
        "range_wide": {
            "range": {"price": {"gte": 0, "lte": 500}},
        },
        "bool_range+term": {
            "bool": {
                "must": [{"term": {"tag": "technology"}}],
                "filter": [{"range": {"price": {"gte": 50, "lt": 200}}}],
            },
        },
        "span_term": {
            "span_term": {"body": "content"},
        },
        "span_near": {
            "span_near": {
                "clauses": [
                    {"span_term": {"body": "related"}},
                    {"span_term": {"body": "content"}},
                ],
                "slop": 1,
                "in_order": True,
            },
        },
        "span_near_slop3": {
            "span_near": {
                "clauses": [
                    {"span_term": {"body": "body"}},
                    {"span_term": {"body": "content"}},
                ],
                "slop": 3,
                "in_order": True,
            },
        },
        "script_score": {
            "script_score": {
                "query": {"match": {"title": "document"}},
                "script": {"source": "_score * 2.5"},
            },
        },
        "geo_shape_intersects": {
            "geo_shape": {
                "boundary": {
                    "shape": {
                        "type": "Polygon",
                        "coordinates": [
                            [
                                [-74.1, 40.6],
                                [-73.8, 40.6],
                                [-73.8, 40.9],
                                [-74.1, 40.9],
                                [-74.1, 40.6],
                            ],
                        ],
                    },
                    "relation": "intersects",
                },
            },
        },
        "geo_shape_within": {
            "geo_shape": {
                "boundary": {
                    "shape": {
                        "type": "Polygon",
                        "coordinates": [
                            [
                                [-74.5, 40.3],
                                [-73.5, 40.3],
                                [-73.5, 41.1],
                                [-74.5, 41.1],
                                [-74.5, 40.3],
                            ],
                        ],
                    },
                    "relation": "within",
                },
            },
        },
        # Triangle query — no rect fast-path, forces full geo predicate
        "geo_shape_tri_inter": {
            "geo_shape": {
                "boundary": {
                    "shape": {
                        "type": "Polygon",
                        "coordinates": [
                            [
                                [-74.0, 40.5],
                                [-73.5, 41.0],
                                [-74.5, 41.0],
                                [-74.0, 40.5],
                            ],
                        ],
                    },
                    "relation": "intersects",
                },
            },
        },
        # Triangle within — no rect fast-path
        "geo_shape_tri_within": {
            "geo_shape": {
                "boundary": {
                    "shape": {
                        "type": "Polygon",
                        "coordinates": [
                            [
                                [-75.0, 40.0],
                                [-73.0, 40.0],
                                [-74.0, 42.0],
                                [-75.0, 40.0],
                            ],
                        ],
                    },
                    "relation": "within",
                },
            },
        },
        # OGC-only predicates (not supported by ES)
        "geo_shape_touches": {
            "geo_shape": {
                "boundary": {
                    "shape": {
                        "type": "Polygon",
                        "coordinates": [
                            [
                                [-73.9, 40.6],
                                [-73.7, 40.6],
                                [-73.7, 40.8],
                                [-73.9, 40.8],
                                [-73.9, 40.6],
                            ],
                        ],
                    },
                    "relation": "touches",
                },
            },
        },
        "geo_shape_overlaps": {
            "geo_shape": {
                "boundary": {
                    "shape": {
                        "type": "Polygon",
                        "coordinates": [
                            [
                                [-74.0, 40.7],
                                [-73.9, 40.7],
                                [-73.9, 40.8],
                                [-74.0, 40.8],
                                [-74.0, 40.7],
                            ],
                        ],
                    },
                    "relation": "overlaps",
                },
            },
        },
        "geo_shape_equals": {
            "geo_shape": {
                "boundary": {
                    "shape": {
                        "type": "Polygon",
                        "coordinates": [
                            [
                                [-74.1, 40.6],
                                [-73.8, 40.6],
                                [-73.8, 40.9],
                                [-74.1, 40.9],
                                [-74.1, 40.6],
                            ],
                        ],
                    },
                    "relation": "equals",
                },
            },
        },
        "geo_shape_disjoint": {
            "geo_shape": {
                "boundary": {
                    "shape": {
                        "type": "Polygon",
                        "coordinates": [
                            [
                                [10.0, 50.0],
                                [11.0, 50.0],
                                [11.0, 51.0],
                                [10.0, 51.0],
                                [10.0, 50.0],
                            ],
                        ],
                    },
                    "relation": "disjoint",
                },
            },
        },
        "from_0": {
            "query": {"match": {"title": "document"}},
            "from": 0,
            "size": 10,
        },
        "from_100": {
            "query": {"match": {"title": "document"}},
            "from": 100,
            "size": 10,
        },
        "from_1000": {
            "query": {"match": {"title": "document"}},
            "from": 1000,
            "size": 10,
        },
        "source_full": {
            "query": {"match": {"title": "document"}},
            "size": 10,
        },
        "source_disabled": {
            "query": {"match": {"title": "document"}},
            "_source": False,
            "size": 10,
        },
        "source_filtered": {
            "query": {"match": {"title": "document"}},
            "_source": ["title", "tag"],
            "size": 10,
        },
        # Sort
        "sort_numeric": {
            "query": {"match_all": {}},
            "sort": ["price"],
            "size": 10,
        },
        "sort_keyword": {
            "query": {"match_all": {}},
            "sort": [{"tag": "asc"}],
            "size": 10,
        },
        "sort_score": {
            "query": {"match": {"title": "document"}},
            "sort": ["_score"],
            "size": 10,
        },
        # Fields retrieval
        "fields_only": {
            "query": {"match": {"title": "document"}},
            "fields": ["tag", "price"],
            "_source": False,
            "size": 10,
        },
        # Collapse
        "collapse_keyword": {
            "query": {"match_all": {}},
            "collapse": {"field": "tag"},
            "size": 10,
        },
        # Explain
        "explain": {
            "query": {"match": {"title": "document"}},
            "explain": True,
            "size": 10,
        },
        # Rescore
        "rescore": {
            "query": {"match": {"title": "document"}},
            "rescore": {
                "window_size": 50,
                "query": {
                    "rescore_query": {"match_phrase": {"body": "related content"}},
                    "query_weight": 0.7,
                    "rescore_query_weight": 1.2,
                },
            },
            "size": 10,
        },
        "knn_k10": {
            "query": {
                "knn": {
                    "field": "embedding",
                    "query_vector": qv,
                    "k": 10,
                    "num_candidates": 50,
                },
            },
            "size": 10,
        },
        # Fusion / hybrid
        "knn_query": {
            "query": {
                "knn": {
                    "field": "embedding",
                    "query_vector": qv,
                    "k": 10,
                },
            },
            "size": 10,
        },
        "rrf_text+knn": {
            "query": {
                "fusion": {
                    "sources": [
                        {"match": {"title": "document"}},
                        {
                            "knn": {
                                "field": "embedding",
                                "query_vector": qv,
                                "k": 50,
                            },
                        },
                    ],
                    "method": "rrf",
                    "rank_window_size": 100,
                },
            },
            "size": 10,
        },
        "rrf_3source": {
            "query": {
                "fusion": {
                    "sources": [
                        {"match": {"title": "document"}},
                        {"term": {"tag": "technology"}},
                        {
                            "knn": {
                                "field": "embedding",
                                "query_vector": qv,
                                "k": 50,
                            },
                        },
                    ],
                    "method": "rrf",
                    "rank_window_size": 100,
                },
            },
            "size": 10,
        },
        "hybrid_bool_should": {
            "query": {
                "bool": {
                    "should": [
                        {"match": {"title": "document"}},
                        {
                            "knn": {
                                "field": "embedding",
                                "query_vector": qv,
                                "k": 50,
                            },
                        },
                    ],
                },
            },
            "size": 10,
        },
        # Highlight
        "highlight_single": {
            "query": {"match": {"title": "document"}},
            "highlight": {"fields": {"title": {}}},
            "size": 10,
        },
        "highlight_multi_field": {
            "query": {"match": {"body": "related content"}},
            "highlight": {"fields": {"title": {}, "body": {}}},
            "size": 10,
        },
        "highlight_full_field": {
            "query": {"match": {"title": "document"}},
            "highlight": {"fields": {"title": {"number_of_fragments": 0}}},
            "size": 10,
        },
    }


QUERIES = _build_queries()

GROUPS: dict[str, list[str]] = {
    "keyword": ["term", "terms", "exists", "prefix", "bool_should"],
    "text": ["match_single", "match_multi", "multi_match", "match_phrase", "match_all"],
    "bool": ["bool_must+filter", "bool_must_not", "bool_should"],
    "geo": [
        "geo_distance",
        "geo_bbox",
        "geo_shape_intersects",
        "geo_shape_within",
        "geo_shape_tri_inter",
        "geo_shape_tri_within",
        "geo_shape_disjoint",
    ],
    "geo_shape": [
        "geo_shape_intersects",
        "geo_shape_within",
        "geo_shape_tri_inter",
        "geo_shape_tri_within",
        "geo_shape_disjoint",
        "geo_shape_touches",
        "geo_shape_overlaps",
        "geo_shape_equals",
    ],
    "nested": ["nested_term", "nested_bool"],
    "agg": ["terms_agg", "avg_agg", "query+agg"],
    "range": ["range_narrow", "range_wide", "bool_range+term"],
    "span": ["span_term", "span_near", "span_near_slop3"],
    "pagination": ["from_0", "from_100", "from_1000"],
    "source": ["source_full", "source_disabled", "source_filtered"],
    "sort": ["sort_numeric", "sort_keyword", "sort_score"],
    "features": ["fields_only", "collapse_keyword", "explain"],
    "highlight": ["highlight_single", "highlight_multi_field", "highlight_full_field"],
    "vector": ["knn_k10", "knn_query"],
    "hybrid": ["rrf_text+knn", "rrf_3source", "hybrid_bool_should"],
    "disjunction": ["terms", "bool_should", "match_multi"],
}


# --- ES query conversion ---


def _luci_to_es_query(q: dict[str, Any]) -> dict[str, Any]:
    """Convert a Luci query dict to an ES search request body."""
    # Pass-through keys that ES supports directly
    passthrough_keys = {
        "from",
        "_source",
        "size",
        "sort",
        "fields",
        "collapse",
        "explain",
        "search_after",
        "highlight",
        "rescore",
    }

    # Queries that already have top-level structure (aggs, knn)
    if "aggs" in q:
        query_part = q.get("query", {"match_all": {}})
        result = {
            "query": query_part,
            "aggs": q["aggs"],
            "size": q.get("size", 0),
        }
        for k in passthrough_keys:
            if k in q and k not in result:
                result[k] = q[k]
        return result
    # Fusion → ES retriever API
    if "query" in q and isinstance(q["query"], dict) and "fusion" in q["query"]:
        fusion = q["query"]["fusion"]
        sources = fusion["sources"]
        window = fusion.get("rank_window_size", 100)
        k = fusion.get("rank_constant", 60)

        # Convert each source to an ES retriever
        retrievers = []
        for source in sources:
            if "knn" in source:
                knn = source["knn"]
                retrievers.append(
                    {
                        "knn": {
                            "field": knn["field"],
                            "query_vector": knn["query_vector"],
                            "k": knn.get("k", 10),
                            "num_candidates": knn.get("num_candidates", 50),
                        },
                    },
                )
            else:
                retrievers.append({"standard": {"query": source}})
        return {
            "retriever": {
                "rrf": {
                    "retrievers": retrievers,
                    "rank_constant": k,
                    "rank_window_size": window,
                },
            },
            "size": q.get("size", 10),
        }
    # knn query DSL → ES knn query
    if "query" in q and isinstance(q["query"], dict) and "knn" in q["query"]:
        knn = q["query"]["knn"]
        return {
            "query": {
                "knn": {
                    "field": knn["field"],
                    "query_vector": knn["query_vector"],
                    "k": knn.get("k", 10),
                    "num_candidates": knn.get("num_candidates", 50),
                },
            },
            "size": q.get("size", 10),
        }
    # Structured query with "query" key — pass through with extra fields
    if "query" in q:
        result = {"query": q["query"], "size": q.get("size", 10)}
        for k in passthrough_keys:
            if k in q and k not in result:
                result[k] = q[k]
        return result
    # Bare query: wrap in {"query": ..., "size": 10}
    return {"query": q, "size": 10}


# --- ES helpers ---


class _EsClient:
    """Thin Elasticsearch HTTP client bound to a base URL."""

    def __init__(self, base_url: str) -> None:
        self.base_url = base_url

    def request(
        self,
        method: str,
        path: str,
        body: object | None = None,
    ) -> dict[str, object]:
        url = f"{self.base_url}/{path}"
        data = json.dumps(body).encode() if body else None
        req = Request(url, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        with urlopen(req) as resp:
            return json.loads(resp.read())

    def bulk_index(self, docs: list[dict[str, object]]) -> None:
        lines: list[str] = []
        for doc in docs:
            lines.append(json.dumps({"index": {}}))
            lines.append(json.dumps(doc))
        body = "\n".join(lines) + "\n"
        url = f"{self.base_url}/{ES_INDEX}/_bulk"
        req = Request(url, data=body.encode(), method="POST")
        req.add_header("Content-Type", "application/x-ndjson")
        with urlopen(req) as resp:
            result = json.loads(resp.read())
        if result.get("errors"):
            for item in result.get("items", []):
                action = item.get("index", item.get("create", {}))
                if action.get("error"):
                    msg = f"ES bulk error: {action['error']}"
                    raise RuntimeError(msg)
            msg = "ES bulk indexing had errors"
            raise RuntimeError(msg)

    def search(
        self,
        body: dict[str, object],
    ) -> dict[str, object]:
        return self.request("POST", f"{ES_INDEX}/_search", body)


# --- Measurement ---


def _measure_fn(
    fn: Callable[[], object],
    warmup: int,
    iterations: int,
) -> dict[str, float]:
    for _ in range(warmup):
        fn()
    rss_before = current_rss_kb()
    times: list[float] = []
    for _ in range(iterations):
        start = time.perf_counter()
        fn()
        elapsed = (time.perf_counter() - start) * 1_000_000
        times.append(elapsed)
    rss_after = current_rss_kb()
    times.sort()
    n = len(times)
    return {
        "p50": times[n // 2],
        "p90": times[int(n * 0.9)],
        "p99": times[int(n * 0.99)],
        "rss_before_kb": rss_before,
        "rss_after_kb": rss_after,
        "rss_delta_kb": max(0, rss_after - rss_before),
    }


# --- Index management ---


class _IndexCache:
    """Lazy benchmark index — built once, reused across queries."""

    def __init__(self) -> None:
        self._index: luci.Index | None = None
        self._dir: str | None = None

    def get(self) -> luci.Index:
        if self._index is not None:
            return self._index
        self._dir = tempfile.mkdtemp(prefix="luci_bench_")
        path = str(Path(self._dir) / "bench.luci")
        typer.echo(f"Building {DOC_COUNT:,} doc corpus...")
        docs = generate_corpus()
        self._index = luci.Index.create(path, MAPPING)
        start = time.perf_counter()
        self._index.bulk(docs)
        elapsed = time.perf_counter() - start
        typer.echo(
            f"Luci indexed in {elapsed:.1f}s ({DOC_COUNT / elapsed:.0f} docs/s)",
        )
        return self._index

    def cleanup(self) -> None:
        self._index = None
        if self._dir:
            shutil.rmtree(self._dir)
            self._dir = None


_cache = _IndexCache()


@contextlib.contextmanager
def _es_container() -> Generator[str, None, None]:
    """Start an Elasticsearch container via testcontainers, yield the base URL."""
    typer.echo(f"Starting Elasticsearch container ({ES_IMAGE})...")
    container = ElasticSearchContainer(image=ES_IMAGE)
    container.with_env("discovery.type", "single-node")
    container.with_env("ES_JAVA_OPTS", "-Xms4g -Xmx4g")
    container.with_env("xpack.license.self_generated.type", "trial")
    container.with_env("cluster.routing.allocation.disk.watermark.low", "95%")
    container.with_env("cluster.routing.allocation.disk.watermark.high", "97%")
    container.with_env("cluster.routing.allocation.disk.watermark.flood_stage", "99%")
    container.with_kwargs(mem_limit="6g")

    with container:
        host = container.get_container_host_ip()
        port = container.get_exposed_port(9200)
        url = f"http://{host}:{port}"
        typer.echo(f"Elasticsearch ready at {url}")
        yield url


def _setup_es(es: _EsClient) -> None:
    """Index the standard corpus into Elasticsearch."""
    with contextlib.suppress(Exception):
        es.request("DELETE", ES_INDEX)

    es.request(
        "PUT",
        ES_INDEX,
        {
            "mappings": {
                "properties": {
                    "title": {"type": "text"},
                    "body": {"type": "text"},
                    "tag": {"type": "keyword"},
                    "category": {"type": "keyword"},
                    "price": {"type": "float"},
                    "location": {"type": "geo_point"},
                    "boundary": {"type": "geo_shape"},
                    "offers": {
                        "type": "nested",
                        "properties": {
                            "seller": {"type": "keyword"},
                            "price": {"type": "keyword"},
                        },
                    },
                    "embedding": {
                        "type": "dense_vector",
                        "dims": 32,
                        "index": True,
                        "similarity": "cosine",
                    },
                },
            },
            "settings": {"number_of_shards": 1, "number_of_replicas": 0},
        },
    )

    docs = generate_corpus()
    batch_size = 5000
    start = time.perf_counter()
    for i in range(0, len(docs), batch_size):
        es.bulk_index(docs[i : i + batch_size])
    es.request("POST", f"{ES_INDEX}/_refresh")
    elapsed = time.perf_counter() - start
    typer.echo(f"ES indexed in {elapsed:.1f}s ({DOC_COUNT / elapsed:.0f} docs/s)")


# --- Name resolution ---


def _resolve_names(queries: list[str] | None, group: str | None) -> list[str]:
    names: list[str] = []
    if group:
        if group not in GROUPS:
            typer.echo(f"Unknown group: {group}. Use --list.")
            raise typer.Exit(1)
        names = GROUPS[group]
    elif queries:
        for q in queries:
            if q in GROUPS:
                names.extend(GROUPS[q])
            elif q in QUERIES:
                names.append(q)
            else:
                typer.echo(f"Unknown query: {q}. Use --list.")
                raise typer.Exit(1)
    else:
        names = list(QUERIES.keys())

    seen: set[str] = set()
    unique: list[str] = []
    for n in names:
        if n not in seen:
            seen.add(n)
            unique.append(n)
    return unique


# --- CLI ---


@app.command()
def run(
    queries: list[str] | None = typer.Argument(None, help="Query names to run."),
    group: str | None = typer.Option(None, "--group", "-g", help="Preset group."),
    warmup: int = typer.Option(WARMUP_DEFAULT, "--warmup", "-w"),
    iterations: int = typer.Option(ITERATIONS_DEFAULT, "--iters", "-n"),
    vs_es: bool = typer.Option(False, "--vs-es", help="Compare with ES."),
    record: str | None = typer.Option(
        None,
        "--record",
        help="Record results to DuckDB.",
    ),
    list_queries: bool = typer.Option(
        False,
        "--list",
        "-l",
        help="List queries/groups.",
    ),
) -> None:
    """Run benchmark queries against the standard corpus."""
    if list_queries:
        typer.echo("Queries:")
        for name in QUERIES:
            typer.echo(f"  {name}")
        typer.echo("\nGroups:")
        for name, members in GROUPS.items():
            typer.echo(f"  {name}: {', '.join(members)}")
        return

    names = _resolve_names(queries, group)
    index = _cache.get()

    db = None
    if record:
        db = ResultsDB()
        db.delete_run(record, suite="bench")
        commit = (
            subprocess.check_output(
                ["git", "rev-parse", "--short", "HEAD"],
            )
            .decode()
            .strip()
        )

    if vs_es:
        _run_vs_es(names, index, warmup, iterations)
    else:
        typer.echo(f"\n{'Query':<25} {'p50':>10} {'p90':>10} {'p99':>10}")
        typer.echo("-" * 57)

        for name in names:
            q = QUERIES[name]
            m = _measure_fn(lambda q=q: index.search(q, 10), warmup, iterations)
            typer.echo(
                f"{name:<25} {m['p50']:>8.0f}us {m['p90']:>8.0f}us {m['p99']:>8.0f}us",
            )
            if db and record:
                r = index.search(q, size=0)
                th = r.get("total_hits", 0)
                hits = th["value"] if isinstance(th, dict) else th
                db.insert(
                    record,
                    commit,
                    "bench",
                    DOC_COUNT,
                    name,
                    m["p50"],
                    m["p90"],
                    m["p99"],
                    hits,
                    int(m.get("rss_delta_kb", 0)),
                )

    _cache.cleanup()


def _run_vs_es(
    names: list[str],
    index: luci.Index,
    warmup: int,
    iterations: int,
) -> None:
    """Run Luci vs ES comparison, managing the ES container lifecycle."""
    with _es_container() as url:
        es = _EsClient(url)
        _setup_es(es)

        typer.echo(f"\n{'=' * 70}")
        typer.echo(f"Luci vs Elasticsearch ({DOC_COUNT:,} docs)")
        typer.echo(f"{'=' * 70}")
        typer.echo(
            f"Warmup: {warmup}  Iterations: {iterations}  "
            f"Hardware: {platform.machine()}/{platform.system()}\n",
        )
        typer.echo(f"{'Query':<25} {'Luci p50':>12} {'ES p50':>12} {'Speedup':>10}")
        typer.echo("-" * 61)

        for name in names:
            q = QUERIES[name]
            m = _measure_fn(lambda q=q: index.search(q, 10), warmup, iterations)
            es_q = _luci_to_es_query(q)
            e = _measure_fn(lambda eq=es_q: es.search(eq), warmup, iterations)
            speedup = e["p50"] / m["p50"] if m["p50"] > 0 else float("inf")
            marker = " ***" if speedup < 1.0 else ""
            typer.echo(
                f"{name:<25} {m['p50']:>10.0f}μs {e['p50']:>10.0f}μs "
                f"{speedup:>9.1f}x{marker}",
            )

        typer.echo("\n*** = ES faster")


@app.command()
def umls(
    limit: int | None = typer.Option(None, "--limit", "-n", help="Limit concepts."),
    budget: int = typer.Option(64, "--budget", "-b", help="Memory budget in MB."),
    warmup: int = typer.Option(20, "--warmup", "-w"),
    iterations: int = typer.Option(200, "--iters", "-i"),
    vs_es: bool = typer.Option(False, "--vs-es", help="Compare with ES."),
    record: str | None = typer.Option(
        None,
        "--record",
        help="Record results to DuckDB.",
    ),
) -> None:
    """Run benchmarks on the UMLS concept corpus (multi-segment)."""

    typer.echo(f"Loading UMLS concepts{f' (limit {limit})' if limit else ''}...")
    t0 = time.perf_counter()
    docs = load_concepts(limit)
    t_load = time.perf_counter() - t0
    typer.echo(f"Loaded {len(docs):,} concepts in {t_load:.1f}s")

    # Filter to clinically relevant semantic types for vector benchmarks
    clinical_types = {
        "Neoplastic Process",
        "Sign or Symptom",
        "Disease or Syndrome",
        "Injury or Poisoning",
        "Body Part, Organ, or Organ Component",
    }
    docs = [d for d in docs if clinical_types.intersection(d["semantic_type"])]
    typer.echo(f"Filtered to {len(docs):,} clinical concepts")

    tmpdir = tempfile.mkdtemp(prefix="luci_umls_")
    idx_path = str(Path(tmpdir) / "umls.luci")
    budget_bytes = budget * 1024 * 1024

    # Generate semantic-type-based embeddings
    from embed import generate_embeddings as gen_embeddings  # noqa: PLC0415

    typer.echo("Generating concept embeddings...")
    t0 = time.perf_counter()
    embeddings, _dims = gen_embeddings(docs)
    typer.echo(f"Embeddings ready in {time.perf_counter() - t0:.1f}s")

    # Attach embeddings to docs
    for doc, emb in zip(docs, embeddings, strict=True):
        doc["embedding"] = emb

    typer.echo(f"Indexing with {budget}MB memory budget...")
    t0 = time.perf_counter()
    index = build_index(docs, idx_path, memory_budget=budget_bytes)
    t_idx = time.perf_counter() - t0
    size_mb = Path(idx_path).stat().st_size / 1024 / 1024
    rate = len(docs) / t_idx
    typer.echo(
        f"Indexed in {t_idx:.1f}s ({rate:.0f} docs/s), {size_mb:.0f}MB on disk",
    )

    # Build a query vector: embed "Disease or Syndrome" (common type)
    query_emb = embeddings[0]  # first concept's embedding
    # Find a disease concept for a more meaningful query vector
    for doc, emb in zip(docs, embeddings, strict=True):
        if "Disease or Syndrome" in doc.get("semantic_type", []):
            query_emb = emb
            break

    umls_queries: dict[str, dict[str, Any]] = {
        "term": {"term": {"cui": "C0004057"}},
        "match": {"match": {"text": "myocardial infarction"}},
        "phrase": {"match_phrase": {"text": "blood pressure"}},
        "bool": {
            "bool": {
                "must": [
                    {"match": {"text": "diabetes"}},
                    {"term": {"semantic_type": "Disease or Syndrome"}},
                ],
            },
        },
        "prefix": {"prefix": {"cui": "C012"}},
        "wildcard": {"wildcard": {"cui": "C000*"}},
        "fuzzy": {"fuzzy": {"cui": {"value": "C004057", "fuzziness": 1}}},
        "exists": {"exists": {"field": "semantic_type"}},
        "dis_max": {
            "dis_max": {
                "queries": [
                    {"match": {"text": "hypertension"}},
                    {"match": {"text": "blood pressure"}},
                ],
                "tie_breaker": 0.3,
            },
        },
        "agg": {
            "query": {"match": {"text": "cancer"}},
            "aggs": {"by_type": {"terms": {"field": "semantic_type"}}},
            "size": 0,
        },
        "cardinality": {
            "query": {"match_all": {}},
            "aggs": {"unique_types": {"cardinality": {"field": "semantic_type"}}},
            "size": 0,
        },
        "knn": {
            "query": {
                "knn": {
                    "field": "embedding",
                    "query_vector": query_emb,
                    "k": 10,
                    "num_candidates": 50,
                },
            },
            "size": 10,
        },
        "rrf": {
            "query": {
                "fusion": {
                    "sources": [
                        {"match": {"text": "myocardial infarction"}},
                        {
                            "knn": {
                                "field": "embedding",
                                "query_vector": query_emb,
                                "k": 50,
                            },
                        },
                    ],
                    "method": "rrf",
                    "rank_window_size": 100,
                },
            },
            "size": 10,
        },
    }

    if vs_es:
        with _es_container() as url:
            es = _EsClient(url)
            es.request(
                "PUT",
                ES_INDEX,
                {
                    "mappings": {
                        "properties": {
                            "cui": {"type": "keyword"},
                            "semantic_type": {"type": "keyword"},
                            "text": {"type": "text"},
                            "embedding": {
                                "type": "dense_vector",
                                "dims": 512,
                                "index": True,
                                "similarity": "cosine",
                            },
                        },
                    },
                    "settings": {"number_of_shards": 1, "number_of_replicas": 0},
                },
            )
            typer.echo("Indexing into ES...")
            t0 = time.perf_counter()
            batch_size = 2000
            for i in range(0, len(docs), batch_size):
                es.bulk_index(docs[i : i + batch_size])
            es.request("POST", f"{ES_INDEX}/_refresh")
            typer.echo(
                f"ES indexed in {time.perf_counter() - t0:.1f}s",
            )

            typer.echo(
                f"\n{'Query':<12} {'Luci p50':>10} {'ES p50':>10} {'Speedup':>10}",
            )
            typer.echo("-" * 46)

            for name, query in umls_queries.items():
                m = _measure_fn(
                    lambda q=query: index.search(q, 10),
                    warmup,
                    iterations,
                )
                es_q = _luci_to_es_query(query)
                try:
                    e = _measure_fn(
                        lambda eq=es_q: es.search(eq),
                        warmup,
                        iterations,
                    )
                    speedup = e["p50"] / m["p50"] if m["p50"] > 0 else float("inf")
                    marker = " ***" if speedup < 1.0 else ""
                    typer.echo(
                        f"{name:<12} {m['p50']:>8.0f}μs {e['p50']:>8.0f}μs "
                        f"{speedup:>8.1f}x{marker}",
                    )
                except (RuntimeError, OSError) as exc:
                    typer.echo(
                        f"{name:<12} {m['p50']:>8.0f}μs {'(error)':>10} {exc}",
                    )

            typer.echo("\n*** = ES faster")
    else:
        typer.echo(f"\n{'Query':<12} {'p50':>10} {'p90':>10} {'p99':>10} {'hits':>8}")
        typer.echo("-" * 52)

        db = None
        if record:
            db = ResultsDB()
            db.delete_run(record, suite="umls")
            commit = (
                subprocess.check_output(
                    ["git", "rev-parse", "--short", "HEAD"],
                )
                .decode()
                .strip()
            )

        for name, query in umls_queries.items():
            r = index.search(query, size=0)
            th = r["total_hits"]
            hits = th["value"] if isinstance(th, dict) else th
            m = _measure_fn(lambda q=query: index.search(q, 10), warmup, iterations)
            typer.echo(
                f"{name:<12} {m['p50']:>8.0f}us "
                f"{m['p90']:>8.0f}us "
                f"{m['p99']:>8.0f}us {hits:>8}",
            )
            if db and record:
                db.insert(
                    record,
                    commit,
                    "umls",
                    len(docs),
                    name,
                    m["p50"],
                    m["p90"],
                    m["p99"],
                    hits,
                    int(m.get("rss_delta_kb", 0)),
                )

    shutil.rmtree(tmpdir)


@app.command()
def segment_scaling(
    limit: int | None = typer.Option(None, "--limit", "-n", help="Limit concepts."),
    warmup: int = typer.Option(20, "--warmup", "-w"),
    iterations: int = typer.Option(100, "--iters", "-i"),
) -> None:
    """Measure query performance vs segment count (UMLS corpus).

    Builds the same data at different memory budgets to vary segment
    count, then benchmarks each. Uses the thread count set by
    RAYON_NUM_THREADS (default: all cores).

    Compare sequential vs parallel by running twice::

        RAYON_NUM_THREADS=1 uv run python bench.py segment-scaling
        uv run python bench.py segment-scaling
    """

    typer.echo(f"Loading UMLS concepts{f' (limit {limit})' if limit else ''}...")
    t0 = time.perf_counter()
    docs = load_concepts(limit)
    typer.echo(f"Loaded {len(docs):,} concepts in {time.perf_counter() - t0:.1f}s")

    queries: dict[str, dict[str, Any]] = {
        "match": {"match": {"text": "myocardial infarction"}},
        "broad": {"match": {"text": "protein"}},
        "agg": {
            "query": {"match": {"text": "cancer"}},
            "aggs": {"by_type": {"terms": {"field": "semantic_type"}}},
            "size": 0,
        },
        "match_all": {"match_all": {}},
    }

    budgets_mb = [512, 128, 64, 32, 16, 8]

    threads = os.environ.get("RAYON_NUM_THREADS", "default")
    typer.echo(f"RAYON_NUM_THREADS={threads}\n")

    # Header
    q_names = list(queries.keys())
    typer.echo(f"{'budget':>8} {'size':>6} " + " ".join(f"{n:>10}" for n in q_names))
    typer.echo("-" * (16 + 11 * len(q_names)))

    for budget_mb in budgets_mb:
        budget_bytes = budget_mb * 1024 * 1024
        tmpdir = tempfile.mkdtemp(prefix="luci_seg_")
        idx_path = str(Path(tmpdir) / "umls.luci")

        index = build_index(docs, idx_path, memory_budget=budget_bytes)
        size_mb = Path(idx_path).stat().st_size / 1024 / 1024

        parts = [f"{budget_mb:>6}MB {size_mb:>4.0f}MB"]

        for query in queries.values():
            for _ in range(warmup):
                index.search(query, size=10)
            idx = index
            m = _measure_fn(
                lambda q=query, i=idx: i.search(q, 10),
                0,
                iterations,
            )
            parts.append(f"{m['p50']:>8.0f}us")

        typer.echo(" ".join(parts))
        shutil.rmtree(tmpdir)


@app.command()
def profile(
    record: str | None = typer.Option(
        None,
        "--record",
        help="Record results to DuckDB.",
    ),
    suite: str | None = typer.Option(
        None,
        "--suite",
        "-s",
        help="Run a specific suite only.",
    ),
) -> None:
    """Run profile test suites and optionally record to DuckDB."""
    db = None
    commit = ""
    if record:
        db = ResultsDB()
        db.delete_run(record, suite="profile")
        commit = (
            subprocess.check_output(
                ["git", "rev-parse", "--short", "HEAD"],
            )
            .decode()
            .strip()
        )

    suites = {suite: ALL_SUITES[suite]} if suite else ALL_SUITES

    for suite_name, suite_fn in suites.items():
        typer.echo(f"\n--- {suite_name} ---")
        corpus_size, results = suite_fn()
        for r in results:
            typer.echo(
                f"  {r['query']:<35} "
                f"p50={r['p50']:>8.0f}\u03bcs  "
                f"p99={r['p99']:>8.0f}\u03bcs  "
                f"hits={r['hits']}",
            )
            if db and record:
                db.insert(
                    record,
                    commit,
                    "profile",
                    corpus_size,
                    r["query"],
                    r["p50"],
                    r["p90"],
                    r["p99"],
                    r["hits"],
                    r.get("rss_delta_kb", 0),
                )


@app.command()
def snapshot(
    run: str = typer.Argument(help="Current run name."),
    previous: str = typer.Argument(help="Previous run name to diff against."),
) -> None:
    """Generate an observation doc from recorded benchmark data."""
    db = ResultsDB()
    commit = (
        subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
        )
        .decode()
        .strip()
    )
    today = datetime.date.today().strftime("%Y%m%d")
    # Find next ordinal for today
    obs_dir = REPO_ROOT / "docs" / "observation"
    existing = sorted(obs_dir.glob(f"profiling-{today}-*.md"))
    ordinal = len(existing) + 1
    out = obs_dir / f"profiling-{today}-{ordinal:02d}-{run}.md"
    db.write_snapshot(run, previous, str(out), commit)
    typer.echo(f"Snapshot written to: {out.relative_to(REPO_ROOT)}")


if __name__ == "__main__":
    app()
