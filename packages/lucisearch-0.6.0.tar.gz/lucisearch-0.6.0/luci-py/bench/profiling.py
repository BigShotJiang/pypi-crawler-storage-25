"""Profile test suites — Python equivalent of luci-index/tests/profile/*.rs.

Each suite builds a specialized corpus and runs targeted queries to
measure latency. Results are recorded to DuckDB via ResultsDB.
"""

import ctypes
import ctypes.util
import platform
import shutil
import tempfile
import time
from pathlib import Path
from typing import Any

import luci


def current_rss_kb() -> int:
    """Current resident set size in KB."""
    if platform.system() == "Darwin":
        libc = ctypes.CDLL(ctypes.util.find_library("c"))

        mach_task_basic_info = 20

        class MachTaskBasicInfo(ctypes.Structure):
            _fields_ = [
                ("virtual_size", ctypes.c_uint64),
                ("resident_size", ctypes.c_uint64),
                ("resident_size_max", ctypes.c_uint64),
                ("user_time", ctypes.c_uint64),
                ("system_time", ctypes.c_uint64),
                ("policy", ctypes.c_int32),
                ("suspend_count", ctypes.c_int32),
            ]

        info = MachTaskBasicInfo()
        count = ctypes.c_uint32(ctypes.sizeof(info) // 4)
        libc.task_info(
            libc.mach_task_self(),
            mach_task_basic_info,
            ctypes.byref(info),
            ctypes.byref(count),
        )
        return info.resident_size // 1024
    with Path("/proc/self/status").open() as f:
        for line in f:
            if line.startswith("VmRSS:"):
                return int(line.split()[1])
    return 0


# --- Measurement ---


def measure(
    index: luci.Index,
    query: dict[str, Any],
    size: int = 10,
    warmup: int = 10,
    iters: int = 200,
) -> dict[str, Any]:
    """Measure query latency + RSS delta.

    Returns dict with p50, p90, p99, hits, rss_delta_kb.
    """
    for _ in range(warmup):
        index.search(query, size)
    rss_before = current_rss_kb()
    times = []
    for _ in range(iters):
        t0 = time.perf_counter()
        r = index.search(query, size)
        elapsed = (time.perf_counter() - t0) * 1_000_000
        times.append(elapsed)
    rss_after = current_rss_kb()
    times.sort()
    n = len(times)
    th = r.get("total_hits", 0)
    hits = th["value"] if isinstance(th, dict) else th
    return {
        "p50": times[n // 2],
        "p90": times[int(n * 0.9)],
        "p99": times[int(n * 0.99)],
        "hits": hits,
        "peak_rss_kb": rss_after,
        "rss_delta_kb": max(0, rss_after - rss_before),
    }


# --- Corpus builders ---


def _build_text_corpus(
    doc_count: int = 50000,
) -> tuple[Path, luci.Index]:
    """Build a text corpus (matches Rust profile harness)."""
    path = Path(tempfile.mkdtemp(prefix="luci_profile_")) / "text.luci"
    mapping = {
        "properties": {
            "title": {"type": "text"},
            "body": {"type": "text"},
            "tag": {"type": "keyword"},
            "price": {"type": "float"},
        },
    }
    index = luci.Index.create(str(path), mapping)
    tags = [
        "tech",
        "science",
        "sports",
        "politics",
        "entertainment",
    ]
    docs = [
        {
            "title": (f"document number {i} about {tags[i % len(tags)]} topics"),
            "body": (
                f"this is the body text for document {i}"
                f" covering {tags[i % len(tags)]}"
                " related content and discussions"
            ),
            "tag": tags[i % len(tags)],
            "price": (i % 100) + 0.99,
        }
        for i in range(doc_count)
    ]
    index.bulk(docs)
    return path.parent, index


# --- Profile suites ---


def suite_basic_queries(
    doc_count: int = 50000,
) -> tuple[int, list[dict[str, Any]]]:
    """Basic search queries on 50K text corpus."""
    tmpdir, index = _build_text_corpus(doc_count)
    queries = {
        "match_all": {"match_all": {}},
        "term_keyword": {"term": {"tag": "tech"}},
        "match_single": {"match": {"title": "document"}},
        "match_multi": {
            "match": {"body": "body text content"},
        },
        "phrase_2term": {
            "match_phrase": {"body": "body text"},
        },
        "phrase_3term": {
            "match_phrase": {"body": "body text for"},
        },
        "prefix": {"prefix": {"tag": "sci"}},
        "exists": {"exists": {"field": "title"}},
    }
    results: list[dict[str, Any]] = []
    for name, q in queries.items():
        m = measure(index, q)
        results.append({"query": name, **m})
    shutil.rmtree(tmpdir)
    return doc_count, results


def suite_bool_queries(
    doc_count: int = 50000,
) -> tuple[int, list[dict[str, Any]]]:
    """Bool query variations on 50K text corpus."""
    tmpdir, index = _build_text_corpus(doc_count)
    queries = {
        "must_1clause": {
            "bool": {
                "must": [{"match": {"title": "document"}}],
            },
        },
        "must_2clause": {
            "bool": {
                "must": [
                    {"match": {"title": "document"}},
                    {"term": {"tag": "tech"}},
                ],
            },
        },
        "must_3clause": {
            "bool": {
                "must": [
                    {"match": {"title": "document"}},
                    {"match": {"body": "text"}},
                    {"term": {"tag": "tech"}},
                ],
            },
        },
        "should_2clause": {
            "bool": {
                "should": [
                    {"term": {"tag": "tech"}},
                    {"term": {"tag": "science"}},
                ],
            },
        },
        "should_5clause": {
            "bool": {
                "should": [
                    {"term": {"tag": "tech"}},
                    {"term": {"tag": "science"}},
                    {"term": {"tag": "sports"}},
                    {"term": {"tag": "politics"}},
                    {"term": {"tag": "entertainment"}},
                ],
            },
        },
        "must+filter": {
            "bool": {
                "must": [{"match": {"title": "document"}}],
                "filter": [{"term": {"tag": "science"}}],
            },
        },
        "must+must_not": {
            "bool": {
                "must": [{"match": {"title": "document"}}],
                "must_not": [{"term": {"tag": "sports"}}],
            },
        },
        "must+should+filter": {
            "bool": {
                "must": [{"match": {"title": "document"}}],
                "should": [{"term": {"tag": "tech"}}],
                "filter": [
                    {
                        "range": {
                            "price": {"gte": 10, "lte": 50},
                        },
                    },
                ],
            },
        },
        "nested_bool": {
            "bool": {
                "must": [
                    {
                        "bool": {
                            "should": [
                                {"term": {"tag": "tech"}},
                                {"term": {"tag": "science"}},
                            ],
                        },
                    },
                ],
                "filter": [
                    {
                        "range": {
                            "price": {"gte": 0, "lte": 50},
                        },
                    },
                ],
            },
        },
        "const_score_filter": {
            "constant_score": {
                "filter": {"term": {"tag": "tech"}},
                "boost": 1.0,
            },
        },
    }
    results: list[dict[str, Any]] = []
    for name, q in queries.items():
        m = measure(index, q)
        results.append({"query": name, **m})
    shutil.rmtree(tmpdir)
    return doc_count, results


def suite_aggregations(
    doc_count: int = 50000,
) -> tuple[int, list[dict[str, Any]]]:
    """Aggregation queries on 50K text corpus."""
    tmpdir, index = _build_text_corpus(doc_count)
    ma = {"match_all": {}}
    queries = {
        "terms_5unique": {
            "query": ma,
            "aggs": {"x": {"terms": {"field": "tag"}}},
            "size": 0,
        },
        "avg": {
            "query": ma,
            "aggs": {"x": {"avg": {"field": "price"}}},
            "size": 0,
        },
        "sum": {
            "query": ma,
            "aggs": {"x": {"sum": {"field": "price"}}},
            "size": 0,
        },
        "min": {
            "query": ma,
            "aggs": {"x": {"min": {"field": "price"}}},
            "size": 0,
        },
        "max": {
            "query": ma,
            "aggs": {"x": {"max": {"field": "price"}}},
            "size": 0,
        },
        "value_count": {
            "query": ma,
            "aggs": {
                "x": {"value_count": {"field": "price"}},
            },
            "size": 0,
        },
        "stats": {
            "query": ma,
            "aggs": {"x": {"stats": {"field": "price"}}},
            "size": 0,
        },
        "range_3buckets": {
            "query": ma,
            "aggs": {
                "x": {
                    "range": {
                        "field": "price",
                        "ranges": [
                            {"to": 30},
                            {"from": 30, "to": 70},
                            {"from": 70},
                        ],
                    },
                },
            },
            "size": 0,
        },
        "histogram_10": {
            "query": ma,
            "aggs": {
                "x": {
                    "histogram": {
                        "field": "price",
                        "interval": 10,
                    },
                },
            },
            "size": 0,
        },
        "terms->avg": {
            "query": ma,
            "aggs": {
                "x": {
                    "terms": {"field": "tag"},
                    "aggs": {
                        "y": {"avg": {"field": "price"}},
                    },
                },
            },
            "size": 0,
        },
    }
    results: list[dict[str, Any]] = []
    for name, q in queries.items():
        m = measure(index, q, size=0)
        results.append({"query": name, **m})
    shutil.rmtree(tmpdir)
    return doc_count, results


def suite_indexing(
    doc_count: int = 50000,
) -> tuple[int, list[dict[str, Any]]]:
    """Indexing throughput and storage efficiency."""
    tags = [
        "tech",
        "science",
        "sports",
        "politics",
        "entertainment",
    ]
    mapping = {
        "properties": {
            "title": {"type": "text"},
            "body": {"type": "text"},
            "tag": {"type": "keyword"},
            "price": {"type": "float"},
        },
    }
    docs = []
    for i in range(doc_count):
        tag = tags[i % len(tags)]
        docs.append(
            {
                "title": (f"document number {i} about {tag} topics"),
                "body": (
                    f"this is the body text for document {i}"
                    f" covering {tag}"
                    " related content and discussions"
                ),
                "tag": tag,
                "price": (i % 100) + 0.99,
            },
        )

    results: list[dict[str, Any]] = []

    # Measure indexing throughput (3 runs, take median)
    throughputs = []
    for _ in range(3):
        tmpdir = Path(tempfile.mkdtemp(prefix="luci_profile_"))
        path = tmpdir / "idx.luci"
        index = luci.Index.create(str(path), mapping)
        t0 = time.perf_counter()
        index.bulk(docs)
        elapsed = time.perf_counter() - t0
        throughputs.append(doc_count / elapsed)
        file_size = path.stat().st_size
        shutil.rmtree(tmpdir)
    throughputs.sort()
    results.append(
        {
            "query": "indexing_throughput",
            "p50": throughputs[1],
            "p90": throughputs[0],
            "p99": throughputs[0],
            "hits": 0,
        },
    )
    results.append(
        {
            "query": "index_size_bytes",
            "p50": file_size,
            "p90": file_size,
            "p99": file_size,
            "hits": 0,
        },
    )
    results.append(
        {
            "query": "bytes_per_doc",
            "p50": file_size / doc_count,
            "p90": file_size / doc_count,
            "p99": file_size / doc_count,
            "hits": 0,
        },
    )

    # Measure cold open + first search latency
    tmpdir = Path(tempfile.mkdtemp(prefix="luci_profile_"))
    path = tmpdir / "cold.luci"
    index = luci.Index.create(str(path), mapping)
    index.bulk(docs)
    del index

    open_times = []
    for _ in range(10):
        t0 = time.perf_counter()
        index = luci.Index.open(str(path))
        index.search({"match_all": {}}, 1)
        elapsed = (time.perf_counter() - t0) * 1_000_000
        open_times.append(elapsed)
        del index
    open_times.sort()
    n = len(open_times)
    results.append(
        {
            "query": "cold_open+search",
            "p50": open_times[n // 2],
            "p90": open_times[int(n * 0.9)],
            "p99": open_times[int(n * 0.99)],
            "hits": 0,
        },
    )
    shutil.rmtree(tmpdir)

    # Measure commit latency (incremental: add 1 doc + commit)
    tmpdir = Path(tempfile.mkdtemp(prefix="luci_profile_"))
    path = tmpdir / "commit.luci"
    index = luci.Index.create(str(path), mapping)
    index.bulk(docs[:1000])

    commit_times = []
    for i in range(20):
        t0 = time.perf_counter()
        index.add(
            {
                "title": f"extra {i}",
                "body": "x",
                "tag": "tech",
                "price": 1.0,
            },
        )
        elapsed = (time.perf_counter() - t0) * 1_000_000
        commit_times.append(elapsed)
    commit_times.sort()
    n = len(commit_times)
    results.append(
        {
            "query": "incremental_commit",
            "p50": commit_times[n // 2],
            "p90": commit_times[int(n * 0.9)],
            "p99": commit_times[int(n * 0.99)],
            "hits": 0,
        },
    )
    shutil.rmtree(tmpdir)

    return doc_count, results


ALL_SUITES: dict[str, Any] = {
    "basic_queries": suite_basic_queries,
    "bool_queries": suite_bool_queries,
    "aggregations": suite_aggregations,
    "indexing": suite_indexing,
}
