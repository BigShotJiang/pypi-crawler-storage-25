"""Benchmark result storage and reporting via DuckDB.

Stores all benchmark runs in bench/benchmarks.db. Each run is a named
snapshot (e.g., "v010-composite") with per-query timing data across
suites (profile, bench, umls).

Usage:
    from results import ResultsDB
    db = ResultsDB()
    db.insert(
        "v010-composite", "abc1234", "bench",
        100000, "term", 204, 218, 247, 10000,
    )
    report = db.diff("v010-composite", "v010-nested-aggs")
    db.write_snapshot(
        "v010-composite", "v010-nested-aggs",
        "docs/observation/...",
    )
"""

import datetime
from pathlib import Path

import duckdb

DB_PATH = Path(__file__).parent / "benchmarks.db"
REPO_ROOT = Path(__file__).parent.parent.parent

# Thresholds for classifying percentage changes in benchmarks
_FLAT_THRESHOLD = 5
_REGRESSION_THRESHOLD = 10


class ResultsDB:
    def __init__(self, path: Path = DB_PATH) -> None:
        self.con = duckdb.connect(str(path))
        self.con.execute("""
            CREATE TABLE IF NOT EXISTS benchmarks (
                query        VARCHAR,
                suite        VARCHAR,
                corpus_size  BIGINT,
                run          VARCHAR,
                commit       VARCHAR,
                timestamp    TIMESTAMP,
                p50          DOUBLE,
                p90          DOUBLE,
                p99          DOUBLE,
                hits         BIGINT,
                rss_delta_kb  BIGINT
            )
        """)
        # Migration: add rss_delta_kb if table predates this column
        try:
            self.con.execute("SELECT rss_delta_kb FROM benchmarks LIMIT 0")
        except duckdb.BinderException:
            self.con.execute("ALTER TABLE benchmarks ADD COLUMN rss_delta_kb BIGINT")

    def insert(
        self,
        run: str,
        commit: str,
        suite: str,
        corpus_size: int,
        query: str,
        p50: float,
        p90: float,
        p99: float,
        hits: int = 0,
        rss_delta_kb: int = 0,
    ) -> None:
        self.con.execute(
            """INSERT INTO benchmarks VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            [
                query,
                suite,
                corpus_size,
                run,
                commit,
                datetime.datetime.now(),
                p50,
                p90,
                p99,
                hits,
                rss_delta_kb,
            ],
        )

    def insert_batch(
        self,
        run: str,
        commit: str,
        suite: str,
        corpus_size: int,
        rows: list[dict],
    ) -> None:
        for row in rows:
            self.insert(
                run,
                commit,
                suite,
                corpus_size,
                row["query"],
                row["p50"],
                row["p90"],
                row["p99"],
                row.get("hits", 0),
            )

    def delete_run(self, run: str, suite: str | None = None) -> None:
        """Delete rows for a run. If suite given, only delete that suite."""
        if suite:
            self.con.execute(
                "DELETE FROM benchmarks WHERE run = ? AND suite = ?",
                [run, suite],
            )
        else:
            self.con.execute(
                "DELETE FROM benchmarks WHERE run = ?",
                [run],
            )

    def runs(self) -> list[str]:
        """List all run names, most recent first."""
        sql = (
            "SELECT DISTINCT run FROM benchmarks"
            " ORDER BY max(timestamp)"
            " OVER (PARTITION BY run) DESC"
        )
        return [r[0] for r in self.con.execute(sql).fetchall()]

    def diff(self, current: str, previous: str) -> list[dict]:
        """Compare two runs, returning per-query diffs."""
        rows = self.con.execute(
            """
            SELECT
                c.suite,
                c.query,
                c.corpus_size,
                c.p50 AS current_p50,
                c.p90 AS current_p90,
                c.p99 AS current_p99,
                c.hits,
                c.rss_delta_kb,
                p.p50 AS prev_p50,
                CASE
                    WHEN p.p50 IS NULL THEN NULL
                    WHEN p.p50 = 0 THEN NULL
                    ELSE round((c.p50 - p.p50) / p.p50 * 100, 1)
                END AS pct_change
            FROM benchmarks c
            LEFT JOIN benchmarks p
                ON c.query = p.query
                AND c.suite = p.suite
                AND c.corpus_size = p.corpus_size
                AND p.run = ?
            WHERE c.run = ?
            ORDER BY c.suite, c.corpus_size, c.query
        """,
            [previous, current],
        ).fetchall()

        return [
            {
                "suite": r[0],
                "query": r[1],
                "corpus_size": r[2],
                "p50": r[3],
                "p90": r[4],
                "p99": r[5],
                "hits": r[6],
                "rss_delta_kb": r[7],
                "prev_p50": r[8],
                "pct_change": r[9],
            }
            for r in rows
        ]

    def format_change(self, pct: float | None) -> str:
        if pct is None:
            return "new"
        pct = round(pct)
        if -_FLAT_THRESHOLD <= pct <= _FLAT_THRESHOLD:
            return f"flat ({pct:+d}%)"
        if pct > _REGRESSION_THRESHOLD:
            return f"**+{pct}% REGRESSION**"
        if pct > _FLAT_THRESHOLD:
            return f"+{pct}% (investigate)"
        return f"{pct:+d}%"

    def write_snapshot(
        self,
        run: str,
        previous: str,
        output_path: str,
        commit: str = "",
    ) -> None:
        """Write a complete observation doc with inline diffs."""
        rows = self.diff(run, previous)
        suites = {}
        for r in rows:
            suites.setdefault(r["suite"], []).append(r)

        with Path(output_path).open("w") as f:
            f.write("---\ncategory: observation\n---\n\n")
            f.write(f"# Profiling — {run}\n\n")
            f.write(f"- **Date**: {datetime.date.today()}\n")
            f.write(f"- **Commit**: {commit}\n")
            f.write(f"- **Previous run**: {previous}\n\n")

            # Summary of regressions and improvements
            regressions = [
                r
                for r in rows
                if r["pct_change"] is not None
                and r["pct_change"] > _REGRESSION_THRESHOLD
            ]
            improvements = [
                r
                for r in rows
                if r["pct_change"] is not None
                and r["pct_change"] < -_REGRESSION_THRESHOLD
            ]
            if regressions:
                f.write("### Regressions (>10%)\n\n")
                for r in regressions:
                    q = r["query"]
                    s = r["suite"]
                    prev = r["prev_p50"]
                    cur = r["p50"]
                    chg = r["pct_change"]
                    f.write(
                        f"- **{q}** ({s}): {prev:.0f}us -> {cur:.0f}us (+{chg:.0f}%)\n",
                    )
                f.write("\n")
            if improvements:
                f.write("### Improvements (>10%)\n\n")
                for r in improvements:
                    q = r["query"]
                    s = r["suite"]
                    prev = r["prev_p50"]
                    cur = r["p50"]
                    chg = r["pct_change"]
                    f.write(
                        f"- **{q}** ({s}): {prev:.0f}us -> {cur:.0f}us ({chg:.0f}%)\n",
                    )
                f.write("\n")
            if not regressions and not improvements:
                f.write("*No significant changes (all within ±10%).*\n\n")

            f.write("## Analysis\n\n")
            f.write("<!-- TODO: Write context here —\n")
            f.write("     What changed in this commit/session?\n")
            f.write("     What do the regressions/improvements mean?\n")
            f.write("     Key insights, root causes, next steps.\n")
            f.write("     Delete this comment when done. -->\n\n")

            for suite, suite_rows in suites.items():
                # Group by corpus_size within suite
                by_corpus: dict[int, list[dict]] = {}
                for r in suite_rows:
                    by_corpus.setdefault(r["corpus_size"], []).append(r)

                for corpus_size, corpus_rows in sorted(by_corpus.items()):
                    size_label = f"{corpus_size:,}" if corpus_size else "?"
                    f.write(f"## {suite} ({size_label} docs)\n\n")
                    hdr = (
                        "| Query | p50 (us) | p90 (us)"
                        " | p99 (us) | hits"
                        " | RSS delta (KB)"
                        " | prev p50 | delta p50 |\n"
                    )
                    sep = (
                        "|-------|----------|----------"
                        "|----------|------"
                        "|----------------|"
                        "----------|----------|\n"
                    )
                    f.write(hdr)
                    f.write(sep)

                    for r in corpus_rows:
                        if r["prev_p50"] is not None:
                            prev = f"{r['prev_p50']:.0f}us"
                        else:
                            prev = "-"
                        change = self.format_change(r["pct_change"])
                        rss_delta = r.get("rss_delta_kb") or 0
                        rss_str = str(int(rss_delta)) if rss_delta else "0"
                        f.write(
                            f"| {r['query']} "
                            f"| {r['p50']:.0f}us "
                            f"| {r['p90']:.0f}us "
                            f"| {r['p99']:.0f}us "
                            f"| {r['hits']} "
                            f"| {rss_str} "
                            f"| {prev} "
                            f"| {change} |\n",
                        )
                    f.write("\n")
