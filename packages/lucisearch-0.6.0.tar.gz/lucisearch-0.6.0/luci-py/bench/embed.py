"""Generate UMLS concept embeddings via semantic type embedding.

Embeds the ~125 unique UMLS semantic types via Ollama, then assigns
each concept the average of its semantic type embeddings. Cached to
parquet at ~/data/umls/.

Usage:
    uv run python bench/embed.py                # generate embeddings
    uv run python bench/embed.py --limit 10000  # subset for testing
"""

import json
import math
import time
from pathlib import Path
from urllib.request import Request, urlopen

import duckdb
import typer

CACHE_DIR = Path.home() / "data" / "umls"
OLLAMA_URL = "http://localhost:11434/api/embed"
DEFAULT_MODEL = "qwen3-embedding:0.6b"


def _embed_batch(texts: list[str], model: str) -> list[list[float]]:
    """Embed a batch of texts via Ollama."""
    body = json.dumps({"model": model, "input": texts}).encode()
    req = Request(OLLAMA_URL, data=body, method="POST")
    req.add_header("Content-Type", "application/json")
    with urlopen(req, timeout=120) as resp:
        result = json.loads(resp.read())
    return result["embeddings"]


def generate_embeddings(
    docs: list[dict],
    model: str = DEFAULT_MODEL,
) -> tuple[list[list[float]], int]:
    """Generate concept embeddings from semantic type embeddings.

    1. Collect unique semantic types from all docs.
    2. Embed each semantic type (one API call, ~125 types).
    3. For each concept, average its semantic type embeddings.

    Returns (embeddings, dims).
    """
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    safe_model = model.replace(":", "_").replace("/", "_")
    sty_cache = CACHE_DIR / f"semantic_types_{safe_model}.parquet"

    # Collect unique semantic types
    sty_set: set[str] = set()
    for d in docs:
        for s in d["semantic_type"]:
            sty_set.add(s)
    sty_list = sorted(sty_set)
    typer.echo(f"{len(sty_list)} unique semantic types")

    # Embed semantic types (cached)
    sty_embeddings: dict[str, list[float]] = {}
    if sty_cache.exists():
        con = duckdb.connect()
        rows = con.execute(f"SELECT sty, embedding FROM '{sty_cache}'").fetchall()
        con.close()
        cached = {r[0]: r[1] for r in rows}
        if set(sty_list).issubset(cached.keys()):
            typer.echo(f"Loaded {len(cached)} cached semantic type embeddings")
            sty_embeddings = {s: cached[s] for s in sty_list}
        else:
            typer.echo("Cache missing some types, re-embedding...")

    if not sty_embeddings:
        typer.echo(f"Embedding {len(sty_list)} semantic types with {model}...")
        t0 = time.perf_counter()
        vectors = _embed_batch(sty_list, model)
        elapsed = time.perf_counter() - t0
        typer.echo(f"Embedded in {elapsed:.1f}s")
        sty_embeddings = dict(zip(sty_list, vectors, strict=True))

        # Cache
        con = duckdb.connect()
        con.execute("CREATE TABLE sty_emb (sty VARCHAR, embedding FLOAT[])")
        con.executemany(
            "INSERT INTO sty_emb VALUES (?, ?)",
            list(sty_embeddings.items()),
        )
        con.execute(f"COPY sty_emb TO '{sty_cache}' (FORMAT PARQUET)")
        con.close()
        typer.echo(f"Cached to {sty_cache.name}")

    raw_dims = len(next(iter(sty_embeddings.values())))
    dims = min(512, raw_dims)

    # Truncate and normalize semantic type embeddings
    def _truncate_normalize(v: list[float]) -> list[float]:
        t = v[:dims]
        norm = math.sqrt(sum(x * x for x in t))
        return [x / norm for x in t] if norm > 0 else t

    sty_embeddings = {k: _truncate_normalize(v) for k, v in sty_embeddings.items()}

    # Assign concept embeddings: average of semantic type embeddings, then normalize
    typer.echo(f"Assigning {len(docs):,} concept embeddings ({dims} dims)...")
    t0 = time.perf_counter()
    embeddings: list[list[float]] = []
    for d in docs:
        types = d["semantic_type"]
        if len(types) == 1:
            embeddings.append(sty_embeddings[types[0]])
        else:
            vecs = [sty_embeddings[s] for s in types if s in sty_embeddings]
            if not vecs:
                embeddings.append([0.0] * dims)
                continue
            avg = [sum(v[i] for v in vecs) / len(vecs) for i in range(dims)]
            norm = math.sqrt(sum(x * x for x in avg))
            embeddings.append([x / norm for x in avg] if norm > 0 else avg)

    elapsed = time.perf_counter() - t0
    typer.echo(f"Assigned in {elapsed:.1f}s")
    return embeddings, dims


app = typer.Typer()


@app.command()
def main(
    limit: int | None = typer.Option(None, "--limit", "-n"),
    model: str = typer.Option(DEFAULT_MODEL, "--model", "-m"),
) -> None:
    """Generate UMLS concept embeddings from semantic types."""
    from umls import load_concepts  # noqa: PLC0415

    typer.echo("Loading UMLS concepts...")
    t0 = time.perf_counter()
    docs = load_concepts(limit)
    typer.echo(f"Loaded {len(docs):,} concepts in {time.perf_counter() - t0:.1f}s")

    embeddings, dims = generate_embeddings(docs, model=model)
    typer.echo(f"Done: {len(embeddings):,} vectors x {dims} dims")


if __name__ == "__main__":
    app()
