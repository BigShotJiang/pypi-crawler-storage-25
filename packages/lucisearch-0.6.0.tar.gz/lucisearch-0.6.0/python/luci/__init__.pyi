"""Type stubs for the luci search engine."""

from typing import Any, Self, TypeAlias, TypedDict

from luci import _luci
from luci._luci import Transaction

# --- Mapping types ---

class FieldMapping(TypedDict, total=False):
    """A single field's mapping definition."""

    type: str
    """Field type: ``"text"``, ``"keyword"``, ``"integer"``, ``"long"``,
    ``"float"``, ``"double"``, ``"boolean"``, ``"date"``,
    ``"dense_vector"``, ``"geo_point"``, ``"nested"``."""
    analyzer: str
    """Analyzer name for text fields (default: ``"standard"``)."""
    dims: int
    """Vector dimensions for ``dense_vector`` fields."""
    store: bool
    """Whether to store the field value in ``_source``."""
    index: bool
    """Whether to index the field for search."""
    doc_values: bool
    """Whether to create columnar storage for sorting/aggregations."""
    norms: bool
    """Whether to store field length norms for BM25 scoring."""

class MappingProperties(TypedDict):
    """The ``properties`` section of a mapping."""

    properties: dict[str, FieldMapping]

class MappingDef(TypedDict, total=False):
    """ES-compatible field mapping definition."""

    properties: dict[str, FieldMapping]
    mappings: MappingProperties
    dynamic: str
    """Dynamic mapping mode: ``"true"`` (default) or ``"false"``."""

# --- Query types ---

class TermQuery(TypedDict):
    term: dict[str, str | dict[str, str]]

class TermsQuery(TypedDict):
    terms: dict[str, list[str]]

class MatchQuery(TypedDict):
    match: dict[str, str | dict[str, str]]

class MatchPhraseQuery(TypedDict):
    match_phrase: dict[str, str | dict[str, str]]

class ExistsQuery(TypedDict):
    exists: dict[str, str]

class PrefixQuery(TypedDict):
    prefix: dict[str, str | dict[str, str]]

class MatchAllQuery(TypedDict):
    match_all: dict[str, Any]

class MatchNoneQuery(TypedDict):
    match_none: dict[str, Any]

class BoolClauses(TypedDict, total=False):
    """Clauses for a ``bool`` query."""

    must: list[Query]
    should: list[Query]
    must_not: list[Query]
    filter: list[Query]

class BoolQuery(TypedDict):
    bool: BoolClauses

class ConstantScoreInner(TypedDict, total=False):
    filter: Query
    boost: float

class ConstantScoreQuery(TypedDict):
    constant_score: ConstantScoreInner

class GeoDistanceInner(TypedDict, total=False):
    distance: str
    """Distance string, e.g. ``"10km"``, ``"5mi"``, ``"1000m"``."""

class GeoDistanceQuery(TypedDict):
    geo_distance: dict[str, Any]

class GeoBoundingBoxField(TypedDict):
    top_left: dict[str, float] | list[float] | str
    bottom_right: dict[str, float] | list[float] | str

class GeoBoundingBoxQuery(TypedDict):
    geo_bounding_box: dict[str, GeoBoundingBoxField]

class NestedInner(TypedDict):
    path: str
    query: Query

class NestedQuery(TypedDict):
    nested: NestedInner

class KnnQueryInner(TypedDict, total=False):
    """kNN query parameters."""

    field: str
    """The ``dense_vector`` field to search."""
    query_vector: list[float]
    """The query vector."""
    k: int
    """Number of nearest neighbors to return (default: 10)."""
    num_candidates: int
    """Number of candidates to consider during HNSW traversal (default: 1.5*k)."""
    threshold: float
    """Minimum score threshold. Results below this are excluded."""

class KnnQuery(TypedDict):
    """kNN as a query type."""

    knn: KnnQueryInner

class FusionInner(TypedDict, total=False):
    """Fusion query parameters."""

    sources: list[QueryExpression]
    """Two or more query sources to fuse."""
    method: str
    """Fusion method: ``"rrf"``, ``"sum"``, ``"arithmetic_mean"``,
    ``"harmonic_mean"``, ``"geometric_mean"`` (default: ``"rrf"``)."""
    rank_constant: float
    """Rank constant k for RRF: ``score(d) = sum(w / (k + rank))`` (default: 60)."""
    rank_window_size: int
    """Number of candidates per source before fusion (default: search size)."""
    weights: list[float]
    """Per-source weights. Length must match ``sources``. Default: equal."""

class FusionQuery(TypedDict):
    """Fusion query: ``{"fusion": {"sources": [...], "method": "rrf"}}``."""

    fusion: FusionInner

Query: TypeAlias = (
    TermQuery
    | TermsQuery
    | MatchQuery
    | MatchPhraseQuery
    | BoolQuery
    | ExistsQuery
    | PrefixQuery
    | ConstantScoreQuery
    | GeoDistanceQuery
    | GeoBoundingBoxQuery
    | NestedQuery
    | KnnQuery
    | MatchAllQuery
    | MatchNoneQuery
    | dict[str, Any]
)
"""Any ES-compatible scoring query dict."""

QueryExpression: TypeAlias = Query | FusionQuery
"""A query expression: scoring query or ranking expression (fusion)."""

# --- Aggregation types ---

class FieldAgg(TypedDict):
    """Aggregation on a single field."""

    field: str

class TermsAgg(TypedDict, total=False):
    """Terms bucket aggregation."""

    field: str
    size: int
    """Maximum number of buckets to return (default: 10)."""

class RangeEntry(TypedDict, total=False):
    key: str
    from_: float
    to: float

class RangeAgg(TypedDict):
    field: str
    ranges: list[dict[str, float | str | None]]

class HistogramAgg(TypedDict):
    field: str
    interval: float

AggregationDef: TypeAlias = dict[str, dict[str, Any]]
"""A named aggregation definition, e.g. ``{"avg": {"field": "price"}}``."""

Aggregations: TypeAlias = dict[str, AggregationDef | dict[str, Any]]
"""Named aggregations with optional ``aggs`` sub-aggregations."""

# --- Search request ---

class SearchRequest(TypedDict, total=False):
    """Full search request with query, aggregations, sort, and pagination."""

    query: QueryExpression
    """The query — scoring (match, term, knn, bool) or ranking (fusion)."""
    aggs: Aggregations
    """Optional aggregations to compute alongside the query."""
    aggregations: Aggregations
    """Alias for ``aggs``."""
    size: int
    """Maximum number of hits to return (default: 10)."""
    from_: int
    """Pagination offset (default: 0). JSON key: ``from``."""
    sort: list[dict[str, Any]]
    """Sort specification, e.g. ``[{"price": "asc"}]``."""
    collapse: dict[str, str]
    """Field collapse: ``{"field": "category"}``."""

# --- Search response ---

class SearchHit(TypedDict):
    """A single search result."""

    _score: float
    """Relevance score (BM25 for text, RRF for hybrid, 1.0 for filters)."""
    _doc_id: int
    """Internal document ID within the segment."""
    _source: dict[str, Any]
    """The original document."""

class MetricAggResult(TypedDict, total=False):
    """Result from a metric aggregation (avg, sum, min, max, etc.)."""

    value: float | None
    count: float
    min: float
    max: float
    sum: float

class BucketEntry(TypedDict, total=False):
    """A single bucket in a bucket aggregation result."""

    key: str | float
    """Bucket key (term value, histogram boundary, etc.)."""
    doc_count: int
    """Number of documents in this bucket."""

class BucketAggResult(TypedDict):
    """Result from a bucket aggregation (terms, range, histogram, etc.)."""

    buckets: list[BucketEntry]

AggResult: TypeAlias = dict[str, object]

class SearchResults(TypedDict, total=False):
    """Search response."""

    hits: list[SearchHit]
    """Matching documents, sorted by score descending."""
    total_hits: dict[str, Any]
    """Total hit count: ``{"value": N, "relation": "eq"|"gte"}``."""
    aggregations: dict[str, AggResult]
    """Aggregation results (present if ``aggs`` was specified)."""

# --- GeoPoint types ---

class GeoPointObject(TypedDict):
    """Geographic point as an object."""

    lat: float
    lon: float

GeoPoint: TypeAlias = GeoPointObject | list[float] | str
"""A geographic point: ``{"lat": 40.7, "lon": -73.9}`` or
``[-73.9, 40.7]`` (GeoJSON) or ``"40.7,-73.9"``."""

# --- Index class ---

class Index:
    """A Luci search index.

    The primary entry point for indexing and searching documents.
    Wraps the Rust ``luci_index::Index`` via PyO3.

    Example::

        import luci

        # Create with explicit mappings
        index = luci.Index.create("data.luci", {
            "properties": {
                "title": {"type": "text"},
                "tag": {"type": "keyword"},
                "price": {"type": "float"},
            }
        })

        # Or create with fully dynamic mappings
        index = luci.Index.create("data.luci")

        index.add({"title": "Hello World", "tag": "greeting", "price": 9.99})

        results = index.search({"match": {"title": "hello"}})

        # Open existing index (mappings loaded from disk)
        index = luci.Index.open("data.luci")
    """

    @staticmethod
    def create(
        path: str,
        mapping: MappingDef | MappingProperties | dict[str, Any] | None = None,
        memory_budget: int | None = None,
        write_timeout: float | None = None,
    ) -> Index:
        """Create a new index.

        Args:
            path: File path for the index (e.g. ``"data.luci"``).
            mapping: Optional ES-compatible mapping/settings definition. Supports:

                - ``{"properties": {"title": {"type": "text"}}}`` — mappings only
                - ``{"settings": {"analysis": {...}}, "mappings": {...}}``
                  — custom analyzers + mappings

                If omitted, all field types are inferred dynamically from documents.
            memory_budget: Memory budget in bytes before auto-flush to a new
                segment. Smaller values produce more segments (better query
                parallelism, more merge work). Default: 64 MB (67108864).
                Not persisted — applies only to this session's writes.
            write_timeout: Cross-process write lock timeout in seconds.
                Default: 5.0. Not persisted.

        Returns:
            A new ``Index`` instance.

        Raises:
            ValueError: If the mapping or analysis settings are invalid.

        """

    @staticmethod
    def open(
        path: str,
        memory_budget: int | None = None,
        write_timeout: float | None = None,
    ) -> Index:
        """Open an existing index.

        Mappings are loaded from the index file automatically.

        Args:
            path: File path of the index.
            memory_budget: Memory budget in bytes before auto-flush to a new
                segment. Default: 64 MB (67108864).
                Not persisted — applies only to this session's writes.
            write_timeout: Cross-process write lock timeout in seconds.
                Default: 5.0. Not persisted.

        Returns:
            An ``Index`` instance connected to the existing index.

        Raises:
            ValueError: If the path doesn't exist or the file is corrupted.

        """

    def add(
        self,
        doc: dict[str, Any],
        write_timeout: float | None = None,
    ) -> None:
        """Add a single document to the index. Auto-commits.

        The document is immediately searchable after this call returns.
        For adding multiple documents, use :meth:`bulk` instead.

        Args:
            doc: A dict representing the document.
            write_timeout: Per-operation write lock timeout in seconds.

        Raises:
            ValueError: If the document is not a valid JSON object.

        """

    def bulk(
        self,
        docs: list[dict[str, Any]],
        write_timeout: float | None = None,
    ) -> dict[str, Any]:
        """Add multiple documents in a single call.

        Faster than calling :meth:`add` in a loop — reduces FFI overhead
        from one call per document to one call per batch. Fails fast on the
        first invalid document.

        Args:
            docs: A list of dicts, each representing a document.
            write_timeout: Per-operation write lock timeout in seconds.

        Returns:
            ``{"took": <ms>, "count": <n>}``

        Raises:
            ValueError: If ``docs`` is not a list, or if any document is invalid.

        """

    def force_merge(self, max_segments: int = 1) -> None:
        """Force-merge all segments down to at most ``max_segments``.

        Call after bulk indexing to optimize for query performance.
        This is expensive and should not be called routinely.

        Args:
            max_segments: Target number of segments. Default: 1.

        """

    def search(
        self,
        query: dict[str, Any],
        size: int = 10,
    ) -> SearchResults:
        """Search the index.

        Accepts either a bare query dict or a full search request with
        query, kNN, aggregations, and size.

        Args:
            query: ES-compatible query dict or full search request.
            size: Maximum number of hits to return. Default: 10.

        Returns:
            A :class:`SearchResults` dict with ``hits``, ``total_hits``,
            and optionally ``aggregations``.

        Raises:
            ValueError: If the query is invalid.

        """

    def get(self, id: str) -> dict[str, Any] | None:
        """Get a document by its ``_id``. Returns ``None`` if not found.

        Args:
            id: The document ``_id``.

        Returns:
            A dict with ``_id`` and ``_source``, or ``None``.

        """

    def delete(self, id: str) -> bool:
        """Delete a document by its ``_id``.

        Args:
            id: The document ``_id``.

        Returns:
            ``True`` if found and deleted, ``False`` if not found.

        """

    def update(self, id: str, doc: dict[str, Any]) -> bool:
        """Update a document by its ``_id`` with a partial doc merge.

        Args:
            id: The document ``_id``.
            doc: Partial document with fields to update.

        Returns:
            ``True`` if found and updated, ``False`` if not found.

        """

    def delete_by_query(self, query: dict[str, Any]) -> int:
        """Delete all documents matching a query.

        Args:
            query: ES-compatible query dict.

        Returns:
            Number of documents deleted.

        """

    def count(self, query: dict[str, Any]) -> int:
        """Count documents matching a query.

        Args:
            query: ES-compatible query dict.

        Returns:
            Number of matching documents.

        """

    def buffered_doc_count(self) -> int:
        """Return the number of documents buffered in the current write batch."""

    def set_write_timeout(self, timeout_secs: float = 5.0) -> None:
        """Set the cross-process write lock timeout in seconds.

        Default: 5 seconds. If another process holds the write lock,
        retries until the timeout, then raises ``RuntimeError``.

        """

    def transaction(self) -> _luci.Transaction:
        """Create a sync transaction context manager.

        Example::

            with index.transaction() as txn:
                txn.add({"title": "doc 1"})
                txn.add({"title": "doc 2"})

        """

    def async_transaction(self) -> AsyncTransaction:
        """Create an async transaction context manager.

        Example::

            async with index.async_transaction() as txn:
                txn.add({"title": "doc 1"})

        """

def set_num_threads(num_threads: int) -> None:
    """Configure the number of threads for parallel search.

    Must be called before any search operation. Can only be called once
    per process. If not called, defaults to the number of available CPUs.

    Args:
        num_threads: Number of threads to use for parallel search.

    Raises:
        ValueError: If called more than once or after a search has started.

    """

class AsyncTransaction:
    """Async transaction context manager for batched writes."""

    def add(self, doc: dict[str, Any]) -> None:
        """Add a document to the transaction buffer."""
    async def __aenter__(self) -> Self: ...
    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> bool: ...

__version__: str

__all__: list[str] = [
    "AsyncTransaction",
    "Index",
    "Transaction",
    "set_num_threads",
]
