"""Environment loader base class"""

from abc import ABC, abstractmethod

from vault88.constructs.environment import Environment


class EnvironmentLoader(ABC):
    name: str = ""
    version: str = "0.0.0"

    @abstractmethod
    def load(self) -> Environment:
        """Load and return the Environment."""
        ...
