"""Discover tests"""

import importlib
import inspect
import logging
import os
import re
import sys
import traceback
from typing import List, Optional

from vault88.constructs.test import Test


class Loader:
    name = "Loader"
    version = "1.0.0"
    test_base_classes = ["Test"]

    def __init__(self, logger=None):
        self.logger = logger if logger is not None else logging.getLogger("vault88")
        self.exception = False

    def _findTestsInDir(self, path: str, recursive: bool = False) -> List[Test]:
        selected_tests = []

        if not os.path.isdir(path):
            self.logger.debug("Path provided is not a directory")
            return []

        filelist = []
        if recursive:
            for root, dirs, files in os.walk(path):
                for file in files:
                    if file == "__init__.py":
                        continue
                    filelist.append(os.path.join(root, file))
        else:
            for file in os.listdir(path):
                if file == "__init__.py":
                    continue
                filelist.append(os.path.join(path, file))

        for file in filelist:
            selected_tests += self._findTestsInFile(file)

        return selected_tests

    def _record_exception(self, msg: str) -> List[Test]:
        self.logger.error(msg)
        self.exception = True
        return []

    def _findTestsByImport(self, filename: str, class_name: Optional[str] = None) -> List[Test]:
        path = os.path.dirname(os.path.abspath(filename))
        modname = os.path.splitext(os.path.basename(filename))[0]

        selected_tests = []
        mod = None

        try:
            sys.path.append(path)
            mod = importlib.import_module(modname)

            for obj in mod.__dict__.values():
                if not inspect.isclass(obj):
                    continue

                if obj.__name__ in self.test_base_classes:
                    continue

                if class_name is not None:
                    if obj.__name__ == class_name:
                        selected_tests.append(obj)
        except ImportError:
            detail = traceback.format_exc().split("\n")[-2].split(":")[1]
            return self._record_exception(f"import error within file: {modname}{detail}")

        except PermissionError:
            return self._record_exception(f"permission error for file: {modname}")

        except Exception:
            self.logger.error(f"Exception while importing file: {modname}")
            self.logger.error(traceback.format_exc())
            self.exception = True
            return []

        finally:
            del mod
            sys.modules.pop(modname, None)
            sys.path.pop(-1)

        return selected_tests

    def _findTestsByTextParsing(self, filename: str) -> List[Test]:
        selected_tests = []

        with open(os.path.abspath(filename), "r", encoding="utf-8") as fp:
            contents = fp.read()

            matches = re.findall(r"class (\w+)\(([\n\r,\sA-Za-z0-9_]*)\):", contents)
            for class_name, inherits in matches:
                mods = [mod.replace(" ", "").lstrip() for mod in inherits.split(",")]
                for test_class in self.test_base_classes:
                    if test_class in mods:
                        self.logger.debug(f"Selected test {test_class} {class_name}")
                        selected_tests += self._findTestsByImport(filename, class_name)
        return selected_tests

    def _findTestsInFile(self, filename: str) -> List[Test]:
        selected_tests = []

        if not filename.endswith(".py"):
            self.logger.debug("File provided does not have .py extension")
            return []

        tests = self._findTestsByTextParsing(filename)
        if len(tests) > 0:
            selected_tests += tests

        return selected_tests

    def _should_include_test(
        self, test_tags: List[str], include_tags: List[str], exclude_tags: List[str]
    ) -> bool:
        if set(test_tags) & set(exclude_tags):
            return False
        if not include_tags:
            return True
        return bool(set(test_tags) & set(include_tags))

    def loadTests(
        self,
        filepath: str,
        include_tags: List[str],
        exclude_tags: List[str],
        recursive: bool = False,
    ) -> List[Test]:
        selected_tests = []

        if not isinstance(include_tags, list):
            self.logger.error("Expected include tags to be a list")
            return []
        if not isinstance(exclude_tags, list):
            self.logger.error("Expected exclude tags to be a list")
            return []

        include_tags = [item.lower() for item in include_tags]
        exclude_tags = [item.lower() for item in exclude_tags]

        tests = []
        if os.path.isdir(filepath):
            tests += self._findTestsInDir(filepath, recursive)
        else:
            tests += self._findTestsInFile(filepath)

        for test in tests:
            test_tags = [item.lower() for item in test.tags]
            if self._should_include_test(test_tags, include_tags, exclude_tags):
                selected_tests.append(test)
            elif set(test_tags) & set(exclude_tags):
                self.logger.debug(f"Excluded tests [{test.name}] due to exclude tag(s)")
            else:
                self.logger.debug(f"Excluded tests [{test.name}] does not match include tag(s)")

        return selected_tests
