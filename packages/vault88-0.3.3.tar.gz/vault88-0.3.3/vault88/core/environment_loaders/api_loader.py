"""API environment loader"""

import json
import urllib.request

from vault88.constructs.environment import Environment
from vault88.core.environment_loader import EnvironmentLoader


class ApiLoader(EnvironmentLoader):
    name = "API Loader"
    version = "1.0.0"

    def __init__(self, url: str):
        self.url = url

    def load(self) -> Environment:
        with urllib.request.urlopen(self.url) as response:
            return Environment.from_dict(json.loads(response.read().decode()))
