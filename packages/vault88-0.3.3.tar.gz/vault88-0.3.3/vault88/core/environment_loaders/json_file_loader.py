"""JSON file environment loader"""

import json

from vault88.constructs.environment import Environment
from vault88.core.environment_loader import EnvironmentLoader


class JsonFileLoader(EnvironmentLoader):
    name = "JSON File Loader"
    version = "1.0.0"

    def __init__(self, path: str):
        self.path = path

    def load(self) -> Environment:
        with open(self.path) as f:
            return Environment.from_dict(json.load(f))
