"""Logging helper"""

import logging
import os
import re
import tempfile
from logging.handlers import RotatingFileHandler
from typing import Optional

from vault88.utils import console as _console

_FILE_FORMAT = "%(asctime)s - %(filename)s:%(lineno)d - %(levelname)s - %(message)s"
_STREAM_FORMAT_SIMPLE = "%(message)s"

_LOG_LEVELS = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warning": logging.WARNING,
    "error": logging.ERROR,
    "critical": logging.CRITICAL,
}


class _AnsiStrippingFormatter(logging.Formatter):
    """Formatter that removes ANSI color codes — used for file handlers."""
    _RE = re.compile(r"\033\[[0-9;]*m")

    def format(self, record):
        return self._RE.sub("", super().format(record))


class Logger:
    name = "Logger"
    version = "1.0.0"

    def __init__(self):
        self._logger = logging.getLogger("vault88")
        self._logger.setLevel(logging.DEBUG)
        self._stream_handler = None
        self._file_handler = None
        self._test_file_handler = None
        self._test_log_dir = None
        self._console_width = _console._DEFAULT_WIDTH
        self._template = self._default_template()

    @staticmethod
    def _default_template():
        from vault88.templates.default import DefaultTemplate
        return DefaultTemplate()

    def configure_console(self, config_width: Optional[int] = None) -> None:
        """Set console width from config or auto-detect from terminal."""
        self._console_width = _console.get_console_width(config_width)

    def configure_template(self, template) -> None:
        """Set the active console display template."""
        self._template = template

    def setupLogger(self, log_path: str, verbose: bool = False) -> None:
        stream_level = logging.DEBUG if verbose else logging.INFO
        stream_format = _FILE_FORMAT if verbose else _STREAM_FORMAT_SIMPLE

        self._stream_handler = logging.StreamHandler()
        self._stream_handler.setLevel(stream_level)
        self._stream_handler.setFormatter(logging.Formatter(stream_format))
        self._logger.addHandler(self._stream_handler)

        self._file_handler = RotatingFileHandler(log_path, maxBytes=10 * 1024 * 1024, backupCount=5)
        self._file_handler.setLevel(logging.DEBUG)
        self._file_handler.setFormatter(_AnsiStrippingFormatter(_FILE_FORMAT))
        self._logger.addHandler(self._file_handler)

    def setStreamLogLevel(self, level: str) -> None:
        if self._stream_handler is None:
            return
        log_level = _LOG_LEVELS.get(level.lower())
        if log_level is None:
            self.warning(f"Unknown log level: {level}")
            return
        self._stream_handler.setLevel(log_level)

    def addTestFileHandler(self) -> str:
        if self._test_file_handler is not None:
            self.warning(
                "A test file handler is already active — closing it before opening a new one"
            )
            self.removeTestFileHandler()

        self._test_log_dir = tempfile.mkdtemp()
        log_path = os.path.join(self._test_log_dir, "test.log")

        self._test_file_handler = logging.FileHandler(log_path)
        self._test_file_handler.setLevel(logging.DEBUG)
        self._test_file_handler.setFormatter(_AnsiStrippingFormatter(_FILE_FORMAT))
        self._logger.addHandler(self._test_file_handler)

        return self._test_log_dir

    def removeTestFileHandler(self) -> None:
        if self._test_file_handler is None:
            return
        self._logger.removeHandler(self._test_file_handler)
        self._test_file_handler.close()
        self._test_file_handler = None
        self._test_log_dir = None

    def detachFileHandler(self) -> None:
        if self._file_handler is None:
            return
        self._logger.removeHandler(self._file_handler)
        self._file_handler.close()
        self._file_handler = None

    def detachStreamHandler(self) -> None:
        if self._stream_handler is None:
            return
        self._logger.removeHandler(self._stream_handler)
        self._stream_handler.close()
        self._stream_handler = None

    # ------------------------------------------------------------------
    # Console display helpers
    # ------------------------------------------------------------------

    def logHr(self) -> None:
        self.info(self._template.render_hr(self._console_width))

    def logBanner(self, title: str) -> None:
        for line in self._template.render_banner(title, self._console_width):
            self.info(line)

    def logStage(self, name: str, stage_num: int) -> None:
        for line in self._template.render_stage(name, stage_num, self._console_width):
            self.info(line)

    def logResult(self, result, stage_num: int, step_num: int) -> None:
        for line in self._template.render_result(result, stage_num, step_num, self._console_width):
            self.info(line)

    def logTestSummary(self, test) -> None:
        test_name = test.__class__.name or test.__class__.__name__
        for line in self._template.render_test_summary(test_name, test.stages, self._console_width):
            self.info(line)

    def logSummary(self, rows) -> None:
        for line in self._template.render_summary_table(rows, self._console_width):
            self.info(line)

    def logTraceback(self, tb: str) -> None:
        for line in self._template.render_traceback(tb, self._console_width):
            self.info(line)

    # ------------------------------------------------------------------
    # Standard log methods
    # ------------------------------------------------------------------

    def debug(self, msg: str) -> None:
        self._logger.debug(msg)

    def info(self, msg: str) -> None:
        self._logger.info(msg)

    def warning(self, msg: str) -> None:
        self._logger.warning(msg)

    def error(self, msg: str) -> None:
        self._logger.error(msg)

    def critical(self, msg: str) -> None:
        self._logger.critical(msg)
