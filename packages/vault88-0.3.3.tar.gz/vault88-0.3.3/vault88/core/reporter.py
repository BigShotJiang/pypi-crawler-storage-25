"""Reporter base class"""

from abc import ABC, abstractmethod
from typing import Dict

from vault88.constructs.test import Test


class Reporter(ABC):
    name: str = ""
    version: str = "0.0.0"

    def __init__(self, logger, config: Dict[str, str]):
        self.logger = logger
        self.config = config

    @abstractmethod
    def check(self, test: Test) -> bool:
        """Return True if this reporter is able to publish results for the given test."""
        ...

    @abstractmethod
    def publish(self, test: Test) -> None:
        """Publish the results of the given test."""
        ...
