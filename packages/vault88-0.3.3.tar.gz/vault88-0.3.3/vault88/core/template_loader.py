"""Loader for ConsoleTemplate implementations."""

import importlib
import traceback

from vault88.core.console_template import ConsoleTemplate
from vault88.templates.blueprint import BlueprintTemplate
from vault88.templates.default import DefaultTemplate
from vault88.templates.diagnostic import DiagnosticTemplate
from vault88.templates.token import TokenTemplate

_BUILTIN_TEMPLATES = {
    "default": DefaultTemplate,
    "blueprint": BlueprintTemplate,
    "token": TokenTemplate,
    "diagnostic": DiagnosticTemplate,
}


def load_template(logger, config) -> ConsoleTemplate:
    """Load a ConsoleTemplate from [CONSOLE] config section, or return DefaultTemplate."""
    if not config.has_section("CONSOLE"):
        return DefaultTemplate()

    section = dict(config["CONSOLE"])
    template_key = section.get("template", "default").strip()

    if template_key in _BUILTIN_TEMPLATES:
        return _BUILTIN_TEMPLATES[template_key](section)

    # Load by full Python class path: module.path.ClassName
    parts = template_key.rsplit(".", 1)
    if len(parts) == 2:
        module_path, class_name = parts
        try:
            module = importlib.import_module(module_path)
            template_class = getattr(module, class_name)
            template = template_class(section)
            logger.info(f"Loaded console template: {template_key}")
            return template
        except Exception:
            logger.error(f"Failed to load console template [{template_key}], using default")
            logger.error(traceback.format_exc())
    else:
        logger.warning(f"Unknown console template '{template_key}', using default")

    return DefaultTemplate(section)
