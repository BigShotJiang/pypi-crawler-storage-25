"""Plugin loader for Reporter implementations."""

import configparser
import importlib
import re
import traceback
from typing import List

_SECTION_PATTERN = re.compile(r"^REPORTER\d+$")


def load_reporters(logger, config: configparser.ConfigParser) -> List:
    """Read REPORTER* sections from config and instantiate the named classes."""
    reporters = []

    for section in config.sections():
        if not _SECTION_PATTERN.match(section):
            continue

        enabled = config.getboolean(section, "enabled", fallback=True)
        if not enabled:
            logger.info(
                f"Reporter [{config.get(section, 'name', fallback=section)}] is disabled, skipping"
            )
            continue

        module_path = config.get(section, "module", fallback=None)
        class_name = config.get(section, "class", fallback=None)

        if not module_path or not class_name:
            logger.error(
                f"Reporter [{section}] is missing 'module' or 'class' config keys, skipping"
            )
            continue

        try:
            module = importlib.import_module(module_path)
            reporter_class = getattr(module, class_name)
            reporter = reporter_class(logger, dict(config[section]))
            reporters.append(reporter)
            logger.info(f"Loaded reporter: {reporter.name} v{reporter.version}")
        except Exception:
            logger.error(f"Failed to load reporter [{section}] ({module_path}.{class_name})")
            logger.error(traceback.format_exc())

    return reporters
