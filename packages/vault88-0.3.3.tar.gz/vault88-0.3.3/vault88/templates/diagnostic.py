"""Diagnostic console template — compiler/linter-style output with outcome-colored bullets."""

import textwrap
from typing import List

from vault88.core.console_template import ConsoleTemplate
from vault88.utils.console import _RESET, _visible_truncate, hr, strip_ansi

_BRIGHT_YELLOW  = "\033[93m"
_YELLOW         = "\033[33m"
_BRIGHT_WHITE   = "\033[97m"
_WHITE          = "\033[37m"
_BRIGHT_BLUE    = "\033[94m"
_BRIGHT_BLACK   = "\033[90m"
_CYAN           = "\033[36m"
_BRIGHT_GREEN   = "\033[92m"
_BRIGHT_RED     = "\033[91m"
_BRIGHT_MAGENTA = "\033[95m"

_DEFAULT_TS_FORMAT = "%H:%M:%S"


def _bullet_color(outcome_val: str) -> str:
    if outcome_val == "passed":
        return _BRIGHT_GREEN
    elif outcome_val == "failed":
        return _BRIGHT_RED
    return _YELLOW


def _badge(outcome_val: str):
    if outcome_val == "passed":
        return f"{_BRIGHT_GREEN}✓  PASSED{_RESET}", "✓  PASSED"
    elif outcome_val == "failed":
        return f"{_BRIGHT_RED}✗  FAILED{_RESET}", "✗  FAILED"
    return f"{_YELLOW}·  NOT RUN{_RESET}", "·  NOT RUN"


class DiagnosticTemplate(ConsoleTemplate):
    name = "DiagnosticTemplate"
    version = "1.0.0"

    def __init__(self, config: dict = None):
        config = config or {}
        self._ts_format = config.get("timestamp_format", _DEFAULT_TS_FORMAT)

    def render_hr(self, width: int) -> str:
        return hr(width)

    def render_banner(self, title: str, width: int) -> List[str]:
        return [title, hr(width)]

    def render_stage(self, name: str, stage_num: int, width: int) -> List[str]:
        label = f">>> STAGE {stage_num} — {name} "
        fill_w = max(0, width - len(label))
        line = (
            f"{_BRIGHT_YELLOW}>>>{_RESET}"
            f" STAGE {_BRIGHT_WHITE}{stage_num}{_RESET}"
            f" {_BRIGHT_BLACK}—{_RESET}"
            f" {_BRIGHT_WHITE}{name}{_RESET}"
            f" {_YELLOW}{'─' * fill_w}{_RESET}"
        )
        return ["", line]

    def render_result(self, result, stage_num: int, step_num: int, width: int) -> List[str]:
        colored_badge, plain_badge = _badge(result.outcome.value)
        bullet_c = _bullet_color(result.outcome.value)
        ts = result.timestamp.strftime(self._ts_format)
        step_id = f"{stage_num}-{step_num}"

        pipe = " │ "
        prefix_plain = f"  ● {step_id}{pipe}"
        suffix_plain = f"{pipe}{ts}"
        action_max = max(1, width - len(prefix_plain) - len(suffix_plain))
        action = result.action
        if len(action) > action_max:
            action = action[:max(0, action_max - 1)] + "…"

        dim_pipe = f"{_BRIGHT_BLACK} │ {_RESET}"
        step_line = (
            f"  {bullet_c}●{_RESET}"
            f" {_BRIGHT_BLUE}{step_id}{_RESET}"
            f"{dim_pipe}"
            f"{_WHITE}{action}{_RESET}"
            f"{dim_pipe}"
            f"{_BRIGHT_BLACK}{ts}{_RESET}"
        )

        field_indent = " " * len(prefix_plain)
        lines = ["", step_line]

        fields: List[str] = []

        def add_field(label: str, value: str, val_color: str) -> None:
            lw = len(label)
            val_w = max(1, width - len(field_indent) - lw)
            for i, chunk in enumerate(textwrap.wrap(value, width=val_w) or [value]):
                lbl = label if i == 0 else " " * lw
                fields.append(
                    field_indent
                    + f"{_BRIGHT_BLACK}{lbl}{_RESET}"
                    + f"{val_color}{chunk}{_RESET}"
                )

        add_field("expected   ", result.expected, _CYAN)
        add_field("actual     ", result.actual, _CYAN)
        if result.requirements:
            add_field("reqs       ", ", ".join(result.requirements), _BRIGHT_MAGENTA)

        for fl in fields[:-1]:
            lines.append(fl)
        if fields:
            last = fields[-1]
            last_w = len(strip_ansi(last))
            overhead = len(plain_badge) + 3
            if last_w + overhead > width:
                last = _visible_truncate(last, max(0, width - overhead))
                last_w = len(strip_ansi(last))
            # Right-align badge with spaces instead of dots
            spaces = max(1, width - last_w - 2 - len(plain_badge))
            lines.append(last + " " * spaces + " " + colored_badge)

        lines.append("")
        return lines

    def render_test_summary(self, test_name: str, stages, width: int) -> List[str]:
        label = f">>> Summary — {test_name} "
        fill_w = max(0, width - len(label))
        header = (
            f"{_BRIGHT_YELLOW}>>>{_RESET}"
            f" Summary {_BRIGHT_BLACK}—{_RESET}"
            f" {_BRIGHT_WHITE}{test_name}{_RESET}"
            f" {_YELLOW}{'─' * fill_w}{_RESET}"
        )
        lines = ["", header]

        had_failure = False
        had_any = False
        for stage_num, stage in enumerate(stages, start=1):
            for step_num, result in enumerate(stage.results, start=1):
                had_any = True
                step_id = f"{stage_num}-{step_num}"
                action_plain = strip_ansi(result.action)
                if result.outcome.value == "passed":
                    s_plain, s_color, b_color = "PASS", _BRIGHT_GREEN, _BRIGHT_GREEN
                elif result.outcome.value == "failed":
                    s_plain, s_color, b_color = "FAIL", _BRIGHT_RED, _BRIGHT_RED
                    had_failure = True
                else:
                    s_plain, s_color, b_color = "----", _YELLOW, _YELLOW
                row_plain = f"  ● {step_id} │ "
                max_action = width - len(row_plain) - 2 - len(s_plain) - 3
                if len(action_plain) > max_action:
                    action_plain = action_plain[:max(0, max_action - 1)] + "…"
                prefix = (
                    f"  {b_color}●{_RESET}"
                    f" {_BRIGHT_BLUE}{step_id}{_RESET}"
                    f" {_BRIGHT_BLACK}│{_RESET} "
                )
                content_plain = row_plain + action_plain
                dots = "." * max(3, width - len(content_plain) - 2 - len(s_plain))
                lines.append(f"{prefix}{action_plain} {dots} {s_color}{s_plain}{_RESET}")

        if had_failure:
            o_plain, o_color = "FAILED", _BRIGHT_RED
        elif had_any:
            o_plain, o_color = "PASSED", _BRIGHT_GREEN
        else:
            o_plain, o_color = "NOT RUN", _YELLOW
        lines.append(f"  Overall: {o_color}{o_plain}{_RESET}")
        return lines

    def render_summary_table(self, rows: List[tuple], width: int) -> List[str]:
        label = ">>> Execution Summary "
        fill_w = max(0, width - len(label))
        header = (
            f"{_BRIGHT_YELLOW}>>>{_RESET}"
            f" Execution Summary "
            f"{_YELLOW}{'─' * fill_w}{_RESET}"
        )
        lines = ["", header]
        for name, outcome in rows:
            if outcome == "passed":
                s_plain, s_color = "PASSED", _BRIGHT_GREEN
            elif outcome == "failed":
                s_plain, s_color = "FAILED", _BRIGHT_RED
            else:
                s_plain, s_color = "NOT RUN", _YELLOW
            max_name = width - 2 - 2 - len(s_plain) - 3
            name_str = name[:max_name] if len(name) > max_name else name
            dots = "." * max(3, width - 2 - len(name_str) - 2 - len(s_plain))
            lines.append(f"  {name_str} {dots} {s_color}{s_plain}{_RESET}")
        return lines

    def render_traceback(self, tb: str, width: int) -> List[str]:
        lines = [""]
        for raw in tb.rstrip().splitlines():
            if len(raw) <= width:
                lines.append(raw)
            else:
                for chunk in textwrap.wrap(raw, width=width) or [raw]:
                    lines.append(chunk)
        lines.append("")
        return lines
