"""Token console template — keyword-colored stage/step headers, right-aligned timestamps."""

import textwrap
from typing import List

from vault88.core.console_template import ConsoleTemplate
from vault88.utils.console import _RESET, _visible_truncate, hr, strip_ansi

_MAGENTA        = "\033[35m"
_BRIGHT_MAGENTA = "\033[95m"
_BRIGHT_CYAN    = "\033[96m"
_CYAN           = "\033[36m"
_BRIGHT_WHITE   = "\033[97m"
_BRIGHT_BLACK   = "\033[90m"
_BRIGHT_YELLOW  = "\033[93m"
_BRIGHT_GREEN   = "\033[92m"
_BRIGHT_RED     = "\033[91m"
_YELLOW         = "\033[33m"

_DEFAULT_TS_FORMAT = "%H:%M:%S"


def _badge(outcome_val: str):
    if outcome_val == "passed":
        return f"{_BRIGHT_GREEN}PASS{_RESET}", "PASS"
    elif outcome_val == "failed":
        return f"{_BRIGHT_RED}FAIL{_RESET}", "FAIL"
    return f"{_YELLOW}----{_RESET}", "----"


class TokenTemplate(ConsoleTemplate):
    name = "TokenTemplate"
    version = "1.0.0"

    def __init__(self, config: dict = None):
        config = config or {}
        self._ts_format = config.get("timestamp_format", _DEFAULT_TS_FORMAT)

    def render_hr(self, width: int) -> str:
        return hr(width)

    def render_banner(self, title: str, width: int) -> List[str]:
        return [title, hr(width)]

    def render_stage(self, name: str, stage_num: int, width: int) -> List[str]:
        header = (
            f"  {_MAGENTA}STAGE{_RESET}"
            f" {_BRIGHT_MAGENTA}{stage_num}{_RESET}"
            f"  {_BRIGHT_WHITE}{name}{_RESET}"
        )
        separator = f"  {_BRIGHT_BLACK}{'─' * (width - 2)}{_RESET}"
        return ["", header, separator]

    def render_result(self, result, stage_num: int, step_num: int, width: int) -> List[str]:
        colored_badge, plain_badge = _badge(result.outcome.value)
        ts = result.timestamp.strftime(self._ts_format)
        step_id = f"{stage_num}-{step_num}"

        prefix_plain = f"  step {step_id}  "
        suffix_plain = f"  @{ts}"
        action_max = max(1, width - len(prefix_plain) - len(suffix_plain))
        action = result.action
        if len(action) > action_max:
            action = action[:max(0, action_max - 1)] + "…"
        action_padded = action.ljust(action_max)

        step_line = (
            f"  {_BRIGHT_CYAN}step{_RESET} {_CYAN}{step_id}{_RESET}  "
            f"{_BRIGHT_WHITE}{action_padded}{_RESET}"
            f"  {_BRIGHT_BLACK}@{ts}{_RESET}"
        )

        field_indent = " " * len(prefix_plain)
        lines = ["", step_line]

        fields: List[str] = []

        def add_field(label: str, value: str, val_color: str) -> None:
            lw = len(label)
            val_w = max(1, width - len(field_indent) - lw)
            for i, chunk in enumerate(textwrap.wrap(value, width=val_w) or [value]):
                lbl = label if i == 0 else " " * lw
                fields.append(
                    field_indent
                    + f"{_BRIGHT_BLACK}{lbl}{_RESET}"
                    + f"{val_color}{chunk}{_RESET}"
                )

        add_field("expected   ", result.expected, _BRIGHT_YELLOW)
        add_field("actual     ", result.actual, _BRIGHT_YELLOW)
        if result.requirements:
            add_field("reqs       ", ", ".join(result.requirements), _BRIGHT_MAGENTA)

        for fl in fields[:-1]:
            lines.append(fl)
        if fields:
            last = fields[-1]
            last_w = len(strip_ansi(last))
            overhead = len(plain_badge) + 3
            if last_w + overhead > width:
                last = _visible_truncate(last, max(0, width - overhead))
                last_w = len(strip_ansi(last))
            dots = max(1, width - last_w - 2 - len(plain_badge))
            lines.append(last + " " + "." * dots + " " + colored_badge)

        lines.append("")
        return lines

    def render_test_summary(self, test_name: str, stages, width: int) -> List[str]:
        header = (
            f"  {_MAGENTA}SUMMARY{_RESET}"
            f"  {_BRIGHT_WHITE}{test_name}{_RESET}"
        )
        separator = f"  {_BRIGHT_BLACK}{'─' * (width - 2)}{_RESET}"
        lines = ["", header, separator]

        had_failure = False
        had_any = False
        for stage_num, stage in enumerate(stages, start=1):
            for step_num, result in enumerate(stage.results, start=1):
                had_any = True
                row_label = f"  step {stage_num}-{step_num}  "
                action_plain = strip_ansi(result.action)
                if result.outcome.value == "passed":
                    s_plain, s_color = "PASS", _BRIGHT_GREEN
                elif result.outcome.value == "failed":
                    s_plain, s_color = "FAIL", _BRIGHT_RED
                    had_failure = True
                else:
                    s_plain, s_color = "----", _YELLOW
                max_action = width - len(row_label) - 2 - len(s_plain) - 3
                if len(action_plain) > max_action:
                    action_plain = action_plain[:max(0, max_action - 1)] + "…"
                content = row_label + action_plain
                dots = "." * max(3, width - len(content) - 2 - len(s_plain))
                lines.append(f"{content} {dots} {s_color}{s_plain}{_RESET}")

        if had_failure:
            o_plain, o_color = "FAILED", _BRIGHT_RED
        elif had_any:
            o_plain, o_color = "PASSED", _BRIGHT_GREEN
        else:
            o_plain, o_color = "NOT RUN", _YELLOW
        lines.append(f"  overall: {o_color}{o_plain}{_RESET}")
        return lines

    def render_summary_table(self, rows: List[tuple], width: int) -> List[str]:
        header = f"  {_MAGENTA}EXECUTION SUMMARY{_RESET}"
        separator = f"  {_BRIGHT_BLACK}{'─' * (width - 2)}{_RESET}"
        lines = ["", header, separator]
        for name, outcome in rows:
            if outcome == "passed":
                s_plain, s_color = "PASSED", _BRIGHT_GREEN
            elif outcome == "failed":
                s_plain, s_color = "FAILED", _BRIGHT_RED
            else:
                s_plain, s_color = "NOT RUN", _YELLOW
            max_name = width - 2 - 2 - len(s_plain) - 3
            name_str = name[:max_name] if len(name) > max_name else name
            dots = "." * max(3, width - 2 - len(name_str) - 2 - len(s_plain))
            lines.append(f"  {name_str} {dots} {s_color}{s_plain}{_RESET}")
        return lines

    def render_traceback(self, tb: str, width: int) -> List[str]:
        lines = [""]
        for raw in tb.rstrip().splitlines():
            if len(raw) <= width:
                lines.append(raw)
            else:
                for chunk in textwrap.wrap(raw, width=width) or [raw]:
                    lines.append(chunk)
        lines.append("")
        return lines
