"""SSH client utility"""

from dataclasses import dataclass
from typing import Optional

import paramiko


@dataclass
class SSHResponse:
    return_code: int
    stdout: str
    stderr: str


class SSHClient:
    name = "SSH Client"
    version = "1.0.0"

    def __init__(
        self,
        host: str,
        port: int,
        username: str,
        password: Optional[str] = None,
        key_path: Optional[str] = None,
    ):
        if not password and not key_path:
            raise ValueError("Either password or key_path must be provided")

        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.key_path = key_path
        self._client: Optional[paramiko.SSHClient] = None

    def connect(self) -> None:
        self._client = paramiko.SSHClient()
        # AutoAddPolicy accepts any host key without verification — acceptable for
        # controlled lab/CI targets but should not be used against untrusted hosts.
        self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        kwargs = {"hostname": self.host, "port": self.port, "username": self.username}
        if self.key_path:
            kwargs["key_filename"] = self.key_path
        else:
            kwargs["password"] = self.password

        self._client.connect(**kwargs)

    def disconnect(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> "SSHClient":
        self.connect()
        return self

    def __exit__(self, *args) -> None:
        self.disconnect()

    def _require_connection(self) -> None:
        if self._client is None:
            raise RuntimeError("Not connected — call connect() or use as a context manager")

    def run(self, command: str) -> SSHResponse:
        self._require_connection()
        _, stdout_f, stderr_f = self._client.exec_command(command)
        return_code = stdout_f.channel.recv_exit_status()
        return SSHResponse(
            return_code=return_code,
            stdout=stdout_f.read().decode("utf-8"),
            stderr=stderr_f.read().decode("utf-8"),
        )

    def put(self, local_path: str, remote_path: str) -> None:
        """Copy a local file to the remote target."""
        self._require_connection()
        with self._client.open_sftp() as sftp:
            sftp.put(local_path, remote_path)

    def get(self, remote_path: str, local_path: str) -> None:
        """Copy a file from the remote target to a local path."""
        self._require_connection()
        with self._client.open_sftp() as sftp:
            sftp.get(remote_path, local_path)
