"""Console display helper utilities"""

import re
import shutil
import textwrap
from typing import List, Optional

_DEFAULT_WIDTH = 80
_FIELD_INDENT = "    "  # 4-space indent for Expected/Actual/Reqs lines
_FIELD_INDENT_W = 4

_GREEN = "\033[32m"
_RED = "\033[31m"
_ORANGE = "\033[33m"
_RESET = "\033[0m"

_ANSI_RE = re.compile(r"\033\[[0-9;]*m")

_COLOR_MAP = {
    "black": "\033[30m",
    "red": "\033[31m",
    "green": "\033[32m",
    "yellow": "\033[33m",
    "blue": "\033[34m",
    "magenta": "\033[35m",
    "cyan": "\033[36m",
    "white": "\033[37m",
    "bright_black": "\033[90m",
    "bright_red": "\033[91m",
    "bright_green": "\033[92m",
    "bright_yellow": "\033[93m",
    "bright_blue": "\033[94m",
    "bright_magenta": "\033[95m",
    "bright_cyan": "\033[96m",
    "bright_white": "\033[97m",
}


def get_console_width(config_width: Optional[int] = None) -> int:
    """Return console width from config, terminal detection, or default of 80."""
    if config_width is not None:
        return config_width
    try:
        cols = shutil.get_terminal_size().columns
        return cols if cols > 0 else _DEFAULT_WIDTH
    except Exception:
        return _DEFAULT_WIDTH


def resolve_color(name: str) -> str:
    """Return ANSI escape code for a named color, or empty string if unrecognized."""
    return _COLOR_MAP.get((name or "").lower().strip(), "")


def strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text)


def _visible_truncate(text: str, max_width: int) -> str:
    """Truncate text to max_width visible (non-ANSI) characters, appending … if cut."""
    if max_width <= 0:
        return ""
    if len(strip_ansi(text)) <= max_width:
        return text
    result = []
    visible = 0
    i = 0
    while i < len(text) and visible < max_width - 1:
        m = _ANSI_RE.match(text, i)
        if m:
            result.append(m.group())
            i = m.end()
            continue
        result.append(text[i])
        visible += 1
        i += 1
    return "".join(result) + "…"


def hr(width: int) -> str:
    return "─" * width


def _field_lines(label: str, value: str, inner: int) -> List[str]:
    val_w = max(1, inner - _FIELD_INDENT_W - len(label))
    lines = []
    for i, chunk in enumerate(textwrap.wrap(value, width=val_w) or [value]):
        lines.append(_FIELD_INDENT + (label if i == 0 else " " * len(label)) + chunk)
    return lines


def _badge(outcome_val: str):
    """Return (colored_text, plain_text) for the outcome badge."""
    if outcome_val == "passed":
        return f"{_GREEN}[PASS]{_RESET}", "[PASS]"
    elif outcome_val == "failed":
        return f"{_RED}[FAIL]{_RESET}", "[FAIL]"
    else:
        return f"{_ORANGE}[----]{_RESET}", "[----]"
