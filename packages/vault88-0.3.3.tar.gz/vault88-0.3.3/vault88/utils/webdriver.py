"""Selenium WebDriver utility"""

from typing import Optional

from selenium import webdriver
from selenium.webdriver.remote.webdriver import WebDriver

_BROWSER_OPTIONS = {
    "chrome": webdriver.ChromeOptions,
    "firefox": webdriver.FirefoxOptions,
    "edge": webdriver.EdgeOptions,
}


class WebDriverClient:
    name = "WebDriver Client"
    version = "1.0.0"

    def __init__(self, grid_url: str, browser: str, browser_version: str):
        browser_key = browser.lower()
        if browser_key not in _BROWSER_OPTIONS:
            raise ValueError(
                f"Unsupported browser '{browser}'. Supported: {list(_BROWSER_OPTIONS)}"
            )
        self._grid_url = grid_url
        self._browser_key = browser_key
        self._browser_version = browser_version
        self._driver: Optional[WebDriver] = None

    def connect(self) -> WebDriver:
        options = _BROWSER_OPTIONS[self._browser_key]()
        options.browser_version = self._browser_version
        self._driver = webdriver.Remote(command_executor=self._grid_url, options=options)
        return self._driver

    def disconnect(self) -> None:
        if self._driver is not None:
            self._driver.quit()
            self._driver = None

    def __enter__(self) -> WebDriver:
        return self.connect()

    def __exit__(self, *args) -> None:
        self.disconnect()
