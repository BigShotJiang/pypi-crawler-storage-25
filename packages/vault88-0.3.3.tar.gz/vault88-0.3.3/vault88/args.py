"""CLI argument parser"""

import argparse


def parseArgs():
    """
    creates the default arguments
    """

    parser = argparse.ArgumentParser(prog="vault88")

    parser.add_argument("testpath", help="Path to test file or folder containing tests")

    parser.add_argument("-t", "--tags", nargs="+", help="Tags that tests must contain to run")
    parser.add_argument(
        "-nt", "--nottags", nargs="+", help="Tags that tests must not contain to run"
    )

    parser.add_argument(
        "-r", "--recursive", action="store_true", help="Recursively search for tests to run"
    )
    parser.add_argument(
        "-l", "--log", default="./test_execution.log", help="file path and name to use for log file"
    )
    parser.add_argument(
        "--junit", action="store_true", help="enable generating a junit testresults.xml file"
    )

    parser.add_argument("-v", "--verbose", action="store_true", help="Increase log level to debug")

    parser.add_argument(
        "--env",
        metavar="PATH_OR_URL",
        help="Environment to load: a JSON file path or a full API URL (http/https)",
    )

    parser.add_argument(
        "--config",
        metavar="PATH",
        help="Path to config file (overrides ~/.vault88.conf and /etc/vault88.conf)",
    )

    return parser.parse_args()
