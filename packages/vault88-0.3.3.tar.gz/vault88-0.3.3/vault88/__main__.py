"""CLI Interface"""

from .main import main

main()
