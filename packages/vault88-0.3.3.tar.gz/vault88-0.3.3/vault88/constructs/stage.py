"""Test stage"""

from typing import List

from vault88.constructs.result import Result


class Stage:
    def __init__(self, name: str):
        self.name = name
        self.results: List[Result] = []

    def addResult(self, result: Result) -> None:
        self.results.append(result)
