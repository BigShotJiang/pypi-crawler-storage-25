"""Environment constructs"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class Credential:
    type: str
    username: Optional[str] = None
    password: Optional[str] = None
    key_path: Optional[str] = None
    token: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> Credential:
        return cls(
            type=data["type"],
            username=data.get("username"),
            password=data.get("password"),
            key_path=data.get("key_path"),
            token=data.get("token"),
        )


@dataclass
class Service:
    name: str
    port: Optional[int] = None
    url: Optional[str] = None
    credential: Optional[Credential] = None


@dataclass
class Host:
    address: str
    services: List[Service] = field(default_factory=list)
    name: Optional[str] = None


@dataclass
class Environment:
    name: str
    hosts: List[Host] = field(default_factory=list)
    version: Optional[str] = None
    tags: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> Environment:
        cred_store: Dict[str, Credential] = {
            k: Credential.from_dict(v) for k, v in data.get("credentials", {}).items()
        }
        hosts = []
        for host_data in data.get("hosts", []):
            services = [
                Service(
                    name=s["name"],
                    port=s.get("port"),
                    url=s.get("url"),
                    credential=cred_store.get(s["creds"]) if s.get("creds") else None,
                )
                for s in host_data.get("services", [])
            ]
            hosts.append(
                Host(address=host_data["host"], name=host_data.get("name"), services=services)
            )
        return cls(
            name=data["name"],
            hosts=hosts,
            version=data.get("version"),
            tags=data.get("tags", []),
        )
