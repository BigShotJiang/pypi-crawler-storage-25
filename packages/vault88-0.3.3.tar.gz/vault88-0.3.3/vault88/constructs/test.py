"""Test base class"""

from abc import ABC, abstractmethod
from typing import ClassVar, List, Optional

from vault88.constructs.result import Result, ResultOutcome
from vault88.constructs.stage import Stage


class Test(ABC):
    name: ClassVar[str] = ""
    version: ClassVar[str] = ""
    tags: ClassVar[List[str]] = []

    def __init__(self, logger, log_dir: str, environment=None):
        self.logger = logger
        self.log_dir = log_dir
        self.environment = environment
        self.stages: List[Stage] = []
        self._current_stage: Optional[Stage] = None

    # ------------------------------------------------------------------
    # Abstract lifecycle methods
    # ------------------------------------------------------------------

    @abstractmethod
    def selfCheck(self) -> bool: ...

    @abstractmethod
    def setup(self) -> bool: ...

    @abstractmethod
    def run(self) -> None: ...

    @abstractmethod
    def teardown(self) -> None: ...

    # ------------------------------------------------------------------
    # Stage and result tracking
    # ------------------------------------------------------------------

    def newStage(self, name: str) -> None:
        stage = Stage(name)
        self.stages.append(stage)
        self._current_stage = stage
        self.logger.logStage(name, len(self.stages))

    def _ensureStage(self) -> None:
        if self._current_stage is None:
            self.newStage("Unnamed Stage")

    def addResult(
        self,
        action: str,
        expected: str,
        actual: str,
        outcome: ResultOutcome,
        requirements: Optional[List[str]] = None,
    ) -> None:
        self._ensureStage()
        stage_num = len(self.stages)
        step_num = len(self._current_stage.results) + 1
        result = Result(action, expected, actual, outcome, requirements)
        self._current_stage.addResult(result)
        self.logger.logResult(result, stage_num, step_num)

    # ------------------------------------------------------------------
    # Assertion helpers
    # ------------------------------------------------------------------

    def _assert(
        self,
        action: str,
        expected_label: str,
        actual_label: str,
        passed: bool,
        requirements: Optional[List[str]] = None,
    ) -> None:
        outcome = ResultOutcome.PASSED if passed else ResultOutcome.FAILED
        self.addResult(action, expected_label, actual_label, outcome, requirements)

    def assertEqual(self, action: str, expected, actual,
                    requirements: Optional[List[str]] = None) -> None:
        self._assert(action, repr(expected), repr(actual), expected == actual, requirements)

    def assertNotEqual(self, action: str, expected, actual,
                       requirements: Optional[List[str]] = None) -> None:
        self._assert(action, f"not {repr(expected)}", repr(actual),
                     expected != actual, requirements)

    def assertTrue(self, action: str, value, requirements: Optional[List[str]] = None) -> None:
        self._assert(action, "truthy", repr(value), bool(value), requirements)

    def assertFalse(self, action: str, value, requirements: Optional[List[str]] = None) -> None:
        self._assert(action, "falsy", repr(value), not value, requirements)

    def assertGreaterThan(self, action: str, value, threshold,
                          requirements: Optional[List[str]] = None) -> None:
        self._assert(action, f"> {threshold}", repr(value), value > threshold, requirements)

    def assertLessThan(self, action: str, value, threshold,
                       requirements: Optional[List[str]] = None) -> None:
        self._assert(action, f"< {threshold}", repr(value), value < threshold, requirements)

    def assertGreaterThanOrEqual(self, action: str, value, threshold,
                                 requirements: Optional[List[str]] = None) -> None:
        self._assert(action, f">= {threshold}", repr(value), value >= threshold, requirements)

    def assertLessThanOrEqual(self, action: str, value, threshold,
                              requirements: Optional[List[str]] = None) -> None:
        self._assert(action, f"<= {threshold}", repr(value), value <= threshold, requirements)

    def assertIn(self, action: str, item, container,
                 requirements: Optional[List[str]] = None) -> None:
        self._assert(action, f"{repr(item)} in container", repr(container),
                     item in container, requirements)

    def assertNotIn(self, action: str, item, container,
                    requirements: Optional[List[str]] = None) -> None:
        self._assert(action, f"{repr(item)} not in container", repr(container),
                     item not in container, requirements)

    def assertIsNone(self, action: str, value, requirements: Optional[List[str]] = None) -> None:
        self._assert(action, "None", repr(value), value is None, requirements)

    def assertIsNotNone(self, action: str, value, requirements: Optional[List[str]] = None) -> None:
        self._assert(action, "not None", repr(value), value is not None, requirements)

    def has_failures(self) -> bool:
        return any(
            result.outcome.value == "failed"
            for stage in self.stages
            for result in stage.results
        )
