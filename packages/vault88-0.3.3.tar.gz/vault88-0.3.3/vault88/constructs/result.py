"""Test result"""

from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional


class ResultOutcome(Enum):
    PASSED = "passed"
    FAILED = "failed"
    NOT_RUN = "not_run"


class Result:
    def __init__(
        self,
        action: str,
        expected: str,
        actual: str,
        outcome: ResultOutcome,
        requirements: Optional[List[str]] = None,
    ):
        self.timestamp = datetime.now(timezone.utc)
        self.action = action
        self.expected = expected
        self.actual = actual
        self.outcome = outcome
        self.requirements = requirements if requirements is not None else []
