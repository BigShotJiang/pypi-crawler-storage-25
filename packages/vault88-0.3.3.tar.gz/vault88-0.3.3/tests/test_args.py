"""Tests for CLI argument parsing"""

from vault88.args import parseArgs


class TestParseArgs:
    def test_minimal_required_arg(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/"])
        args = parseArgs()
        assert args.testpath == "tests/"

    def test_tags_flag(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/", "-t", "smoke", "fast"])
        args = parseArgs()
        assert args.tags == ["smoke", "fast"]

    def test_nottags_flag(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/", "-nt", "slow"])
        args = parseArgs()
        assert args.nottags == ["slow"]

    def test_recursive_flag(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/", "-r"])
        args = parseArgs()
        assert args.recursive is True

    def test_recursive_default_is_false(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/"])
        args = parseArgs()
        assert args.recursive is False

    def test_log_flag(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/", "-l", "/tmp/run.log"])
        args = parseArgs()
        assert args.log == "/tmp/run.log"

    def test_log_default(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/"])
        args = parseArgs()
        assert args.log == "./test_execution.log"

    def test_junit_flag(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/", "--junit"])
        args = parseArgs()
        assert args.junit is True

    def test_verbose_flag(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/", "-v"])
        args = parseArgs()
        assert args.verbose is True

    def test_env_flag(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/", "--env", "http://env.local/api"])
        args = parseArgs()
        assert args.env == "http://env.local/api"

    def test_tags_default_is_none(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/"])
        args = parseArgs()
        assert args.tags is None

    def test_env_default_is_none(self, monkeypatch):
        monkeypatch.setattr("sys.argv", ["vault88", "tests/"])
        args = parseArgs()
        assert args.env is None
