"""Logger unit tests — covers edge cases not hit by the positive path"""

import pytest

from vault88.core.logger import Logger


@pytest.fixture
def logger(tmp_path):
    log = Logger()
    log.setupLogger(str(tmp_path / "vault88.log"), verbose=False)
    yield log
    log.detachFileHandler()
    log.detachStreamHandler()


@pytest.fixture
def verbose_logger(tmp_path):
    log = Logger()
    log.setupLogger(str(tmp_path / "vault88.log"), verbose=True)
    yield log
    log.detachFileHandler()
    log.detachStreamHandler()


class TestLoggerSetup:
    def test_stream_handler_attached_after_setup(self, logger):
        assert logger._stream_handler is not None

    def test_file_handler_attached_after_setup(self, logger):
        assert logger._file_handler is not None

    def test_verbose_flag_sets_stream_handler(self, verbose_logger):
        assert verbose_logger._stream_handler is not None


class TestSetStreamLogLevel:
    def test_valid_levels_do_not_raise(self, logger):
        for level in ("debug", "info", "warning", "error", "critical"):
            logger.setStreamLogLevel(level)

    def test_invalid_level_logs_warning_without_raising(self, logger):
        logger.setStreamLogLevel("NOTVALID")

    def test_no_stream_handler_returns_early(self):
        log = Logger()
        log.setStreamLogLevel("debug")


class TestTestFileHandler:
    def test_add_returns_temp_dir_path(self, logger):
        path = logger.addTestFileHandler()
        assert path is not None
        logger.removeTestFileHandler()

    def test_add_when_already_active_replaces_handler(self, logger):
        logger.addTestFileHandler()
        path2 = logger.addTestFileHandler()
        assert path2 is not None
        logger.removeTestFileHandler()

    def test_remove_when_no_handler_is_a_no_op(self):
        log = Logger()
        log.removeTestFileHandler()


class TestDetachHandlers:
    def test_detach_file_handler_when_none_is_a_no_op(self):
        log = Logger()
        log.detachFileHandler()

    def test_detach_stream_handler_when_none_is_a_no_op(self):
        log = Logger()
        log.detachStreamHandler()

    def test_detach_file_handler_removes_handler(self, logger):
        logger.detachFileHandler()
        assert logger._file_handler is None

    def test_detach_stream_handler_removes_handler(self, logger):
        logger.detachStreamHandler()
        assert logger._stream_handler is None


class TestLogMethods:
    def test_all_log_methods_execute_without_error(self, logger):
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.critical("critical message")
