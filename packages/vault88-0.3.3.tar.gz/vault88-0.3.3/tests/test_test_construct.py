"""Tests for Test base class assertion helpers and stage management"""

from unittest.mock import MagicMock

import pytest

from vault88.constructs.result import ResultOutcome
from vault88.constructs.test import Test


class _ConcreteTest(Test):
    name = "Concrete"
    tags = []

    def selfCheck(self):
        return True

    def setup(self):
        return True

    def run(self):
        pass

    def teardown(self):
        pass


@pytest.fixture
def t(tmp_path):
    return _ConcreteTest(MagicMock(), str(tmp_path), None)


def _last(t):
    return t.stages[-1].results[-1]


class TestStageManagement:
    def test_new_stage_appended(self, t):
        t.newStage("Alpha")
        t.newStage("Beta")
        assert [s.name for s in t.stages] == ["Alpha", "Beta"]

    def test_ensure_stage_auto_creates_unnamed(self, t):
        t.addResult("act", "exp", "act", ResultOutcome.PASSED)
        assert t.stages[0].name == "Unnamed Stage"

    def test_result_added_to_current_stage(self, t):
        t.newStage("S")
        t.addResult("a", "e", "v", ResultOutcome.PASSED)
        assert len(t.stages[0].results) == 1


class TestAssertEqual:
    def test_pass_when_equal(self, t):
        t.assertEqual("a", 1, 1)
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail_when_not_equal(self, t):
        t.assertEqual("a", 1, 2)
        assert _last(t).outcome == ResultOutcome.FAILED


class TestAssertNotEqual:
    def test_pass_when_not_equal(self, t):
        t.assertNotEqual("a", 1, 2)
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail_when_equal(self, t):
        t.assertNotEqual("a", 1, 1)
        assert _last(t).outcome == ResultOutcome.FAILED


class TestAssertTrue:
    def test_pass_when_truthy(self, t):
        t.assertTrue("a", "yes")
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail_when_falsy(self, t):
        t.assertTrue("a", "")
        assert _last(t).outcome == ResultOutcome.FAILED


class TestAssertFalse:
    def test_pass_when_falsy(self, t):
        t.assertFalse("a", False)
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail_when_truthy(self, t):
        t.assertFalse("a", True)
        assert _last(t).outcome == ResultOutcome.FAILED


class TestAssertGreaterThan:
    def test_pass(self, t):
        t.assertGreaterThan("a", 5, 3)
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail(self, t):
        t.assertGreaterThan("a", 3, 5)
        assert _last(t).outcome == ResultOutcome.FAILED


class TestAssertLessThan:
    def test_pass(self, t):
        t.assertLessThan("a", 1, 5)
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail(self, t):
        t.assertLessThan("a", 5, 1)
        assert _last(t).outcome == ResultOutcome.FAILED


class TestAssertGreaterThanOrEqual:
    def test_pass_greater(self, t):
        t.assertGreaterThanOrEqual("a", 5, 3)
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_pass_equal(self, t):
        t.assertGreaterThanOrEqual("a", 5, 5)
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail(self, t):
        t.assertGreaterThanOrEqual("a", 3, 5)
        assert _last(t).outcome == ResultOutcome.FAILED


class TestAssertLessThanOrEqual:
    def test_pass_less(self, t):
        t.assertLessThanOrEqual("a", 1, 5)
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_pass_equal(self, t):
        t.assertLessThanOrEqual("a", 5, 5)
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail(self, t):
        t.assertLessThanOrEqual("a", 5, 1)
        assert _last(t).outcome == ResultOutcome.FAILED


class TestAssertIn:
    def test_pass(self, t):
        t.assertIn("a", "b", ["a", "b", "c"])
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail(self, t):
        t.assertIn("a", "x", ["a", "b", "c"])
        assert _last(t).outcome == ResultOutcome.FAILED


class TestAssertNotIn:
    def test_pass(self, t):
        t.assertNotIn("a", "x", ["a", "b"])
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail(self, t):
        t.assertNotIn("a", "a", ["a", "b"])
        assert _last(t).outcome == ResultOutcome.FAILED


class TestAssertIsNone:
    def test_pass(self, t):
        t.assertIsNone("a", None)
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail(self, t):
        t.assertIsNone("a", "value")
        assert _last(t).outcome == ResultOutcome.FAILED


class TestAssertIsNotNone:
    def test_pass(self, t):
        t.assertIsNotNone("a", "value")
        assert _last(t).outcome == ResultOutcome.PASSED

    def test_fail(self, t):
        t.assertIsNotNone("a", None)
        assert _last(t).outcome == ResultOutcome.FAILED


class TestRequirements:
    def test_requirements_attached(self, t):
        t.assertEqual("a", 1, 1, requirements=["REQ-1", "REQ-2"])
        assert _last(t).requirements == ["REQ-1", "REQ-2"]

    def test_no_requirements_defaults_to_empty_list(self, t):
        t.assertEqual("a", 1, 1)
        assert _last(t).requirements == []
