"""Unit tests for LogArchiveReporter"""

import zipfile
from unittest.mock import MagicMock

import pytest

from vault88.constructs.test import Test
from vault88.core.reporters.log_archive_reporter import LogArchiveReporter

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class NamedTest(Test):
    name = "My Sample Test"
    tags = []

    def selfCheck(self):
        return True

    def setup(self):
        return True

    def run(self):
        pass

    def teardown(self):
        pass


def make_test(log_dir, name="My Sample Test"):
    t = NamedTest(MagicMock(), log_dir)
    t.name = name
    return t


def make_reporter(config=None):
    return LogArchiveReporter(MagicMock(), config or {})


def _find_zip(directory) -> str:
    """Return the path to the single zip file in directory."""
    zips = list(directory.glob("*.zip"))
    assert len(zips) == 1, f"Expected 1 zip file, found {[z.name for z in zips]}"
    return zips[0]


# ---------------------------------------------------------------------------
# check()
# ---------------------------------------------------------------------------


class TestCheck:
    def test_returns_true_when_log_dir_has_files(self, tmp_path):
        (tmp_path / "test.log").write_text("log content")
        assert make_reporter().check(make_test(str(tmp_path))) is True

    def test_returns_false_when_log_dir_is_empty(self, tmp_path):
        assert make_reporter().check(make_test(str(tmp_path))) is False

    def test_returns_false_when_log_dir_does_not_exist(self, tmp_path):
        assert make_reporter().check(make_test(str(tmp_path / "nonexistent"))) is False

    def test_returns_false_when_log_dir_is_none(self):
        test = make_test(None)
        test.log_dir = None
        assert make_reporter().check(test) is False

    def test_returns_false_when_log_dir_missing_entirely(self):
        test = make_test("/irrelevant")
        del test.log_dir
        assert make_reporter().check(test) is False


# ---------------------------------------------------------------------------
# publish()
# ---------------------------------------------------------------------------


class TestPublish:
    @pytest.fixture(autouse=True)
    def chdir(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        self.tmp_path = tmp_path

    @pytest.fixture
    def log_dir(self, tmp_path):
        d = tmp_path / "logs"
        d.mkdir()
        (d / "test.log").write_text("line one\nline two\n")
        return d

    # --- zip creation ---

    def test_creates_zip_file(self, log_dir):
        make_reporter().publish(make_test(str(log_dir)))
        assert len(list(self.tmp_path.glob("*.zip"))) == 1

    def test_zip_name_starts_with_test_name(self, log_dir):
        make_reporter().publish(make_test(str(log_dir)))
        zf = _find_zip(self.tmp_path)
        assert zf.name.startswith("My_Sample_Test_")

    def test_zip_name_replaces_spaces_with_underscores(self, log_dir):
        make_reporter().publish(make_test(str(log_dir), name="A Test With Spaces"))
        zf = _find_zip(self.tmp_path)
        assert zf.name.startswith("A_Test_With_Spaces_")

    def test_zip_name_for_single_word_test(self, log_dir):
        make_reporter().publish(make_test(str(log_dir), name="Login"))
        zf = _find_zip(self.tmp_path)
        assert zf.name.startswith("Login_")

    def test_duplicate_test_names_produce_separate_files(self, log_dir):
        reporter = make_reporter()
        reporter.publish(make_test(str(log_dir)))
        reporter.publish(make_test(str(log_dir)))
        zips = list(self.tmp_path.glob("*.zip"))
        assert len(zips) == 2

    # --- zip contents ---

    def test_zip_contains_log_file(self, log_dir):
        make_reporter().publish(make_test(str(log_dir)))
        zf_path = _find_zip(self.tmp_path)
        with zipfile.ZipFile(zf_path) as zf:
            assert "test.log" in zf.namelist()

    def test_zip_contains_all_files_in_log_dir(self, log_dir):
        (log_dir / "extra.log").write_text("extra content")
        make_reporter().publish(make_test(str(log_dir)))
        zf_path = _find_zip(self.tmp_path)
        with zipfile.ZipFile(zf_path) as zf:
            assert set(zf.namelist()) == {"test.log", "extra.log"}

    def test_zip_file_content_is_preserved(self, log_dir):
        make_reporter().publish(make_test(str(log_dir)))
        zf_path = _find_zip(self.tmp_path)
        with zipfile.ZipFile(zf_path) as zf:
            assert zf.read("test.log") == b"line one\nline two\n"

    def test_zip_entries_use_bare_filenames_not_full_paths(self, log_dir):
        make_reporter().publish(make_test(str(log_dir)))
        zf_path = _find_zip(self.tmp_path)
        with zipfile.ZipFile(zf_path) as zf:
            for name in zf.namelist():
                assert "/" not in name

    # --- output_dir config ---

    def test_custom_output_dir_from_config(self, tmp_path, log_dir):
        out_dir = tmp_path / "output"
        out_dir.mkdir()
        make_reporter(config={"output_dir": str(out_dir)}).publish(make_test(str(log_dir)))
        assert len(list(out_dir.glob("My_Sample_Test_*.zip"))) == 1

    # --- logger ---

    def test_logger_info_called_with_zip_path(self, log_dir):
        mock_logger = MagicMock()
        LogArchiveReporter(mock_logger, {}).publish(make_test(str(log_dir)))
        mock_logger.info.assert_called_once()
        assert "My_Sample_Test_" in mock_logger.info.call_args[0][0]
