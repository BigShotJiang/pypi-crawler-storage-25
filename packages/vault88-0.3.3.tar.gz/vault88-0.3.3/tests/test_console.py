"""Tests for console.py truncation utilities and DefaultTemplate result rendering."""

from vault88.constructs.result import Result, ResultOutcome
from vault88.templates.default import DefaultTemplate
from vault88.utils.console import _visible_truncate, strip_ansi

_GREEN = "\033[32m"
_RESET = "\033[0m"
_WIDTH = 80

_NO_TIMESTAMP = {"timestamp_position": "none"}


def _result(
    action="act", expected="exp", actual="act", outcome=ResultOutcome.PASSED, requirements=None
):
    return Result(action, expected, actual, outcome, requirements or [])


def _display_width(line: str) -> int:
    return len(strip_ansi(line))


def _render(result, width=_WIDTH, stage=1, step=1):
    return DefaultTemplate(_NO_TIMESTAMP).render_result(result, stage, step, width)


class TestVisibleTruncate:
    def test_zero_width_returns_empty(self):
        assert _visible_truncate("hello", 0) == ""

    def test_negative_width_returns_empty(self):
        assert _visible_truncate("hello", -5) == ""

    def test_text_shorter_than_max_unchanged(self):
        assert _visible_truncate("hi", 10) == "hi"

    def test_text_exactly_at_max_unchanged(self):
        assert _visible_truncate("hello", 5) == "hello"

    def test_plain_text_truncated_with_ellipsis(self):
        result = _visible_truncate("abcdef", 4)
        assert result == "abc…"

    def test_truncated_visible_length_equals_max_width(self):
        result = _visible_truncate("abcdefghij", 6)
        assert len(strip_ansi(result)) == 6

    def test_ansi_codes_not_counted_toward_width(self):
        colored = f"{_GREEN}hello{_RESET}"
        result = _visible_truncate(colored, 5)
        assert strip_ansi(result) == "hello"

    def test_ansi_codes_preserved_before_cut_point(self):
        colored = f"{_GREEN}abcdef{_RESET}"
        result = _visible_truncate(colored, 4)
        assert strip_ansi(result) == "abc…"
        assert _GREEN in result

    def test_ansi_colored_truncated_visible_length_matches_max_width(self):
        colored = f"{_GREEN}abcdefghij{_RESET}"
        result = _visible_truncate(colored, 6)
        assert len(strip_ansi(result)) == 6


class TestResultLines:
    def _badge_in(self, lines, badge="[PASS]"):
        return any(badge in strip_ansi(line) for line in lines)

    def _content_widths(self, lines):
        return [_display_width(line) for line in lines if line]

    def _has_step_prefix(self, lines, stage_num=1, step_num=1):
        prefix = f"Step {stage_num}-{step_num}:"
        return any(prefix in line for line in lines)

    def test_pass_badge_present(self):
        lines = _render(_result(outcome=ResultOutcome.PASSED))
        assert self._badge_in(lines, "[PASS]")

    def test_fail_badge_present(self):
        lines = _render(_result(outcome=ResultOutcome.FAILED))
        assert self._badge_in(lines, "[FAIL]")

    def test_step_prefix_present(self):
        lines = _render(_result())
        assert self._has_step_prefix(lines, 1, 1)

    def test_step_prefix_uses_correct_stage_and_step_numbers(self):
        lines = _render(_result(), stage=2, step=3)
        assert self._has_step_prefix(lines, 2, 3)

    def test_action_text_appears_in_output(self):
        lines = _render(_result(action="my action"))
        assert any("my action" in line for line in lines)

    def test_no_content_line_exceeds_width(self):
        lines = _render(_result())
        assert all(w <= _WIDTH for w in self._content_widths(lines))

    def test_long_action_no_line_exceeds_width(self):
        lines = _render(_result(action="A" * 300))
        assert all(w <= _WIDTH for w in self._content_widths(lines))

    def test_long_expected_no_line_exceeds_width(self):
        lines = _render(_result(expected="E" * 300))
        assert all(w <= _WIDTH for w in self._content_widths(lines))

    def test_long_actual_no_line_exceeds_width(self):
        lines = _render(_result(actual="A" * 300))
        assert all(w <= _WIDTH for w in self._content_widths(lines))

    def test_long_requirements_no_line_exceeds_width(self):
        reqs = ["REQ-" + str(i) for i in range(50)]
        lines = _render(_result(requirements=reqs))
        assert all(w <= _WIDTH for w in self._content_widths(lines))

    def test_badge_present_with_all_fields_long(self):
        r = _result(
            action="ACT" * 100,
            expected="EXP" * 100,
            actual="ACT" * 100,
            requirements=["REQ-" + str(i) for i in range(30)],
        )
        lines = _render(r)
        assert self._badge_in(lines, "[PASS]")
        assert all(w <= _WIDTH for w in self._content_widths(lines))

    def test_narrow_width_no_line_exceeds_width(self):
        lines = _render(_result(), width=20)
        assert all(w <= 20 for w in self._content_widths(lines))

    def test_narrow_width_badge_present(self):
        lines = _render(_result(outcome=ResultOutcome.PASSED), width=20)
        assert self._badge_in(lines, "[PASS]")

    def test_last_field_line_too_long_badge_still_present(self):
        r = _result(actual="X" * 300)
        lines = _render(r)
        assert self._badge_in(lines, "[PASS]")
        assert all(w <= _WIDTH for w in self._content_widths(lines))

    def test_long_reqs_last_line_badge_still_present(self):
        r = _result(requirements=["REQ-" + "X" * 60])
        lines = _render(r)
        assert self._badge_in(lines, "[PASS]")
        assert all(w <= _WIDTH for w in self._content_widths(lines))

    def test_starts_with_blank_line(self):
        lines = _render(_result())
        assert lines[0] == ""


class TestTimestampRendering:
    def test_timestamp_field_appears_as_field_line(self):
        r = _result()
        lines = DefaultTemplate({"timestamp_position": "field"}).render_result(r, 1, 1, _WIDTH)
        assert any("Timestamp:" in line for line in lines)

    def test_timestamp_none_omits_field(self):
        r = _result()
        lines = DefaultTemplate({"timestamp_position": "none"}).render_result(r, 1, 1, _WIDTH)
        assert not any("Timestamp:" in line for line in lines)

    def test_timestamp_inline_appears_in_step_header(self):
        r = _result()
        lines = DefaultTemplate({"timestamp_position": "inline"}).render_result(r, 1, 1, _WIDTH)
        step_line = next(line for line in lines if "Step 1-1:" in line)
        assert "[" in step_line and "]" in step_line

    def test_timestamp_field_no_line_exceeds_width(self):
        r = _result()
        lines = DefaultTemplate({"timestamp_position": "field"}).render_result(r, 1, 1, _WIDTH)
        widths = [len(strip_ansi(line)) for line in lines if line]
        assert all(w <= _WIDTH for w in widths)

    def test_timestamp_custom_format(self):
        r = _result()
        lines = DefaultTemplate({
            "timestamp_position": "field",
            "timestamp_format": "%Y-%m-%d",
        }).render_result(r, 1, 1, _WIDTH)
        assert any("Timestamp:" in line for line in lines)
        ts_line = next(line for line in lines if "Timestamp:" in line)
        import re
        assert re.search(r"\d{4}-\d{2}-\d{2}", strip_ansi(ts_line))
