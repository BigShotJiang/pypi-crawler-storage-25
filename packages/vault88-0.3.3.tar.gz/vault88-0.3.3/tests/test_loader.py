"""Tests for the Loader class (test discovery)"""

import textwrap
from unittest.mock import patch

from vault88.core.loader import Loader

_TEST_FILE = textwrap.dedent("""
    from vault88.constructs.test import Test

    class SampleDiscoveredTest(Test):
        name = "Sample Discovered Test"
        tags = ["smoke", "fast"]

        def selfCheck(self): return True
        def setup(self): return True
        def run(self): pass
        def teardown(self): pass
""")

_NOTAGS_TEST_FILE = textwrap.dedent("""
    from vault88.constructs.test import Test

    class NoTagsTest(Test):
        name = "No Tags Test"
        tags = []

        def selfCheck(self): return True
        def setup(self): return True
        def run(self): pass
        def teardown(self): pass
""")

_PLAIN_FILE = "x = 1\n"
_BAD_IMPORT_FILE = "import _nonexistent_module_xyz_abc_\n"


# ---------------------------------------------------------------------------
# _findTestsInDir
# ---------------------------------------------------------------------------


class TestFindTestsInDir:
    def test_non_directory_path_returns_empty(self, tmp_path):
        loader = Loader()
        assert loader._findTestsInDir(str(tmp_path / "does_not_exist")) == []

    def test_empty_directory_returns_empty(self, tmp_path):
        loader = Loader()
        assert loader._findTestsInDir(str(tmp_path)) == []

    def test_finds_test_class_in_py_file(self, tmp_path):
        (tmp_path / "my_test.py").write_text(_TEST_FILE)
        loader = Loader()
        assert len(loader._findTestsInDir(str(tmp_path))) == 1

    def test_ignores_init_py(self, tmp_path):
        (tmp_path / "__init__.py").write_text(_TEST_FILE)
        loader = Loader()
        assert loader._findTestsInDir(str(tmp_path)) == []

    def test_ignores_non_py_files(self, tmp_path):
        (tmp_path / "config.txt").write_text(_TEST_FILE)
        loader = Loader()
        assert loader._findTestsInDir(str(tmp_path)) == []

    def test_recursive_finds_nested_test(self, tmp_path):
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "nested_test.py").write_text(_TEST_FILE)
        loader = Loader()
        assert len(loader._findTestsInDir(str(tmp_path), recursive=True)) == 1

    def test_non_recursive_ignores_subdirectory(self, tmp_path):
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "nested_test.py").write_text(_TEST_FILE)
        loader = Loader()
        assert loader._findTestsInDir(str(tmp_path), recursive=False) == []

    def test_recursive_ignores_init_in_subdir(self, tmp_path):
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "__init__.py").write_text(_TEST_FILE)
        loader = Loader()
        assert loader._findTestsInDir(str(tmp_path), recursive=True) == []


# ---------------------------------------------------------------------------
# _findTestsInFile
# ---------------------------------------------------------------------------


class TestFindTestsInFile:
    def test_non_py_file_returns_empty(self, tmp_path):
        f = tmp_path / "readme.txt"
        f.write_text("hello")
        loader = Loader()
        assert loader._findTestsInFile(str(f)) == []

    def test_py_file_with_test_class(self, tmp_path):
        f = tmp_path / "my_test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        assert len(loader._findTestsInFile(str(f))) == 1

    def test_py_file_without_test_class_returns_empty(self, tmp_path):
        f = tmp_path / "helper.py"
        f.write_text(_PLAIN_FILE)
        loader = Loader()
        assert loader._findTestsInFile(str(f)) == []


# ---------------------------------------------------------------------------
# _findTestsByImport
# ---------------------------------------------------------------------------


class TestFindTestsByImport:
    def test_import_error_sets_exception_flag(self, tmp_path):
        f = tmp_path / "bad.py"
        f.write_text(_BAD_IMPORT_FILE)
        loader = Loader()
        result = loader._findTestsByImport(str(f), "SomeClass")
        assert result == []
        assert loader.exception is True

    def test_permission_error_sets_exception_flag(self, tmp_path):
        f = tmp_path / "test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        with patch("importlib.import_module", side_effect=PermissionError("denied")):
            result = loader._findTestsByImport(str(f), "SampleDiscoveredTest")
        assert result == []
        assert loader.exception is True

    def test_generic_exception_sets_exception_flag(self, tmp_path):
        f = tmp_path / "test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        with patch("importlib.import_module", side_effect=RuntimeError("boom")):
            result = loader._findTestsByImport(str(f), "SampleDiscoveredTest")
        assert result == []
        assert loader.exception is True

    def test_no_class_name_returns_empty(self, tmp_path):
        # class_name=None means the append branch is never hit
        f = tmp_path / "test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        result = loader._findTestsByImport(str(f), None)
        assert result == []
        assert loader.exception is False

    def test_class_name_mismatch_returns_empty(self, tmp_path):
        f = tmp_path / "test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        result = loader._findTestsByImport(str(f), "NonExistentClass")
        assert result == []


# ---------------------------------------------------------------------------
# loadTests
# ---------------------------------------------------------------------------


class TestLoadTests:
    def test_invalid_include_tags_returns_empty(self, tmp_path):
        loader = Loader()
        assert loader.loadTests(str(tmp_path), "not-a-list", []) == []

    def test_invalid_exclude_tags_returns_empty(self, tmp_path):
        loader = Loader()
        assert loader.loadTests(str(tmp_path), [], "not-a-list") == []

    def test_loads_tests_from_file(self, tmp_path):
        f = tmp_path / "my_test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(f), [], [])
        assert len(result) == 1

    def test_loads_tests_from_directory(self, tmp_path):
        (tmp_path / "my_test.py").write_text(_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(tmp_path), [], [])
        assert len(result) == 1

    def test_include_tags_passes_matching_test(self, tmp_path):
        f = tmp_path / "my_test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(f), ["smoke"], [])
        assert len(result) == 1

    def test_include_tags_blocks_non_matching_test(self, tmp_path):
        f = tmp_path / "my_test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(f), ["regression"], [])
        assert result == []

    def test_exclude_tags_removes_matching_test(self, tmp_path):
        f = tmp_path / "my_test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(f), [], ["fast"])
        assert result == []

    def test_include_tag_case_insensitive(self, tmp_path):
        f = tmp_path / "my_test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(f), ["SMOKE"], [])
        assert len(result) == 1

    def test_exclude_tag_case_insensitive(self, tmp_path):
        f = tmp_path / "my_test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(f), [], ["FAST"])
        assert result == []

    def test_no_tests_selected_returns_empty(self, tmp_path):
        loader = Loader()
        result = loader.loadTests(str(tmp_path), [], [])
        assert result == []

    def test_exclude_takes_precedence_over_include(self, tmp_path):
        # "smoke" is in both include and exclude — exclude wins
        f = tmp_path / "my_test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(f), ["smoke"], ["smoke"])
        assert result == []

    def test_multiple_include_tags_any_match_passes(self, tmp_path):
        # test has "smoke" and "fast"; filter includes "regression" and "smoke"
        f = tmp_path / "my_test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(f), ["regression", "smoke"], [])
        assert len(result) == 1

    def test_multiple_exclude_tags_any_match_excludes(self, tmp_path):
        # test has "smoke" and "fast"; exclude list contains "fast" and "regression"
        f = tmp_path / "my_test.py"
        f.write_text(_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(f), [], ["regression", "fast"])
        assert result == []

    def test_no_tags_test_passes_without_filters(self, tmp_path):
        f = tmp_path / "my_test.py"
        f.write_text(_NOTAGS_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(f), [], [])
        assert len(result) == 1

    def test_no_tags_test_blocked_by_include_filter(self, tmp_path):
        f = tmp_path / "my_test.py"
        f.write_text(_NOTAGS_TEST_FILE)
        loader = Loader()
        result = loader.loadTests(str(f), ["smoke"], [])
        assert result == []
