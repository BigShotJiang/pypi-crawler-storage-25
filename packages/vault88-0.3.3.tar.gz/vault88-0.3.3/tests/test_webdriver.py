"""Tests for the WebDriverClient utility"""

from unittest.mock import MagicMock, patch

import pytest

from vault88.utils.webdriver import WebDriverClient


class TestWebDriverClientInit:
    def test_unsupported_browser_raises_value_error(self):
        with pytest.raises(ValueError, match="Unsupported browser"):
            WebDriverClient("http://grid:4444", "safari", "latest")

    @pytest.mark.parametrize("browser", ["chrome", "firefox", "edge"])
    def test_supported_browser_accepted(self, browser):
        client = WebDriverClient("http://grid:4444", browser, "120")
        assert client._browser_key == browser.lower()

    def test_browser_name_is_case_insensitive(self):
        client = WebDriverClient("http://grid:4444", "Chrome", "latest")
        assert client._browser_key == "chrome"


class TestWebDriverClientConnect:
    @pytest.mark.parametrize("browser", ["chrome", "firefox", "edge"])
    def test_connect_returns_remote_driver(self, browser):
        fake_driver = MagicMock()
        with patch(
            "vault88.utils.webdriver.webdriver.Remote", return_value=fake_driver
        ) as mock_remote:
            client = WebDriverClient("http://grid:4444", browser, "120")
            result = client.connect()
        assert result is fake_driver
        mock_remote.assert_called_once()

    def test_browser_version_is_set_on_options(self):
        captured = {}

        def fake_remote(command_executor, options):
            captured["options"] = options
            return MagicMock()

        with patch("vault88.utils.webdriver.webdriver.Remote", side_effect=fake_remote):
            client = WebDriverClient("http://grid:4444", "chrome", "118")
            client.connect()

        assert captured["options"].browser_version == "118"

    def test_connect_stores_driver(self):
        fake_driver = MagicMock()
        with patch("vault88.utils.webdriver.webdriver.Remote", return_value=fake_driver):
            client = WebDriverClient("http://grid:4444", "chrome", "120")
            client.connect()
        assert client._driver is fake_driver


class TestWebDriverClientDisconnect:
    def test_disconnect_quits_driver(self):
        fake_driver = MagicMock()
        with patch("vault88.utils.webdriver.webdriver.Remote", return_value=fake_driver):
            client = WebDriverClient("http://grid:4444", "chrome", "120")
            client.connect()
            client.disconnect()
        fake_driver.quit.assert_called_once()
        assert client._driver is None

    def test_disconnect_when_not_connected_is_noop(self):
        client = WebDriverClient("http://grid:4444", "chrome", "120")
        client.disconnect()  # should not raise


class TestWebDriverClientContextManager:
    def test_context_manager_returns_webdriver(self):
        fake_driver = MagicMock()
        with patch("vault88.utils.webdriver.webdriver.Remote", return_value=fake_driver):
            with WebDriverClient("http://grid:4444", "chrome", "120") as driver:
                assert driver is fake_driver

    def test_context_manager_quits_on_exit(self):
        fake_driver = MagicMock()
        with patch("vault88.utils.webdriver.webdriver.Remote", return_value=fake_driver):
            with WebDriverClient("http://grid:4444", "chrome", "120"):
                pass
        fake_driver.quit.assert_called_once()

    def test_context_manager_quits_on_exception(self):
        fake_driver = MagicMock()
        with patch("vault88.utils.webdriver.webdriver.Remote", return_value=fake_driver):
            try:
                with WebDriverClient("http://grid:4444", "chrome", "120"):
                    raise RuntimeError("test error")
            except RuntimeError:
                pass
        fake_driver.quit.assert_called_once()
