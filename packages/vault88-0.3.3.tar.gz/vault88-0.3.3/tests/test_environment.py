"""Tests for environment dataclasses and their from_dict constructors"""

from vault88.constructs.environment import Credential, Environment


class TestCredential:
    def test_username_password(self):
        c = Credential.from_dict(
            {"type": "username-password", "username": "alice", "password": "s3cr3t"}
        )
        assert c.type == "username-password"
        assert c.username == "alice"
        assert c.password == "s3cr3t"
        assert c.token is None

    def test_username_with_key_path(self):
        c = Credential.from_dict(
            {"type": "username-password", "username": "bob", "key_path": "/id_rsa"}
        )
        assert c.username == "bob"
        assert c.key_path == "/id_rsa"
        assert c.password is None

    def test_token(self):
        c = Credential.from_dict({"type": "token", "token": "abc123"})
        assert c.type == "token"
        assert c.token == "abc123"
        assert c.username is None


class TestEnvironment:
    def _base(self):
        return {
            "name": "staging",
            "credentials": {
                "ssh-cred": {
                    "type": "username-password",
                    "username": "deploy",
                    "password": "s3cr3t",
                },
                "api-token": {"type": "token", "token": "tok-xyz"},
            },
            "hosts": [
                {
                    "name": "web-01",
                    "host": "10.0.0.1",
                    "services": [
                        {"name": "ssh", "port": 22, "creds": "ssh-cred"},
                        {"name": "api", "port": 8080, "creds": "api-token"},
                    ],
                },
                {
                    "host": "10.0.0.2",
                    "services": [
                        {"name": "ssh", "port": 22, "creds": "ssh-cred"},
                    ],
                },
            ],
        }

    def test_minimal(self):
        e = Environment.from_dict({"name": "empty"})
        assert e.name == "empty"
        assert e.hosts == []
        assert e.version is None
        assert e.tags == []

    def test_version_and_tags(self):
        e = Environment.from_dict({"name": "x", "version": "1.2.0", "tags": ["prod", "internal"]})
        assert e.version == "1.2.0"
        assert e.tags == ["prod", "internal"]

    def test_hosts_parsed(self):
        e = Environment.from_dict(self._base())
        assert len(e.hosts) == 2

    def test_host_address_and_name(self):
        e = Environment.from_dict(self._base())
        web = next(h for h in e.hosts if h.address == "10.0.0.1")
        assert web.name == "web-01"

    def test_host_name_optional(self):
        e = Environment.from_dict(self._base())
        unnamed = next(h for h in e.hosts if h.address == "10.0.0.2")
        assert unnamed.name is None

    def test_credential_resolved(self):
        e = Environment.from_dict(self._base())
        web = next(h for h in e.hosts if h.address == "10.0.0.1")
        ssh = next(s for s in web.services if s.name == "ssh")
        assert ssh.credential is not None
        assert ssh.credential.type == "username-password"
        assert ssh.credential.username == "deploy"

    def test_token_credential_resolved(self):
        e = Environment.from_dict(self._base())
        web = next(h for h in e.hosts if h.address == "10.0.0.1")
        api = next(s for s in web.services if s.name == "api")
        assert api.credential is not None
        assert api.credential.type == "token"
        assert api.credential.token == "tok-xyz"

    def test_service_without_creds(self):
        e = Environment.from_dict({
            "name": "x",
            "hosts": [{"host": "1.2.3.4", "services": [{"name": "http", "port": 80}]}],
        })
        assert e.hosts[0].services[0].credential is None

    def test_service_url(self):
        e = Environment.from_dict({
            "name": "x",
            "hosts": [{"host": "1.2.3.4", "services": [{"name": "web", "url": "https://example.com"}]}],
        })
        assert e.hosts[0].services[0].url == "https://example.com"
