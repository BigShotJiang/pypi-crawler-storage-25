"""Tests for SSHClient utility"""

from unittest.mock import MagicMock, patch

import pytest

from vault88.utils.ssh import SSHClient, SSHResponse


def _make_client(password="pass", key_path=None):
    return SSHClient("host", 22, "user", password=password, key_path=key_path)


def _mock_paramiko():
    """Return a mock paramiko.SSHClient instance and patch it in place."""
    mock_instance = MagicMock()
    patcher = patch("vault88.utils.ssh.paramiko.SSHClient", return_value=mock_instance)
    return patcher, mock_instance


class TestSSHClientInit:
    def test_requires_password_or_key_path(self):
        with pytest.raises(ValueError, match="password or key_path"):
            SSHClient("host", 22, "user")

    def test_password_only_is_valid(self):
        client = SSHClient("host", 22, "user", password="s3cr3t")
        assert client.password == "s3cr3t"

    def test_key_path_only_is_valid(self):
        client = SSHClient("host", 22, "user", key_path="/id_rsa")
        assert client.key_path == "/id_rsa"

    def test_both_provided_is_valid(self):
        client = SSHClient("host", 22, "user", password="pw", key_path="/id_rsa")
        assert client.password == "pw"
        assert client.key_path == "/id_rsa"

    def test_attributes_stored(self):
        client = SSHClient("myhost", 2222, "admin", password="pw")
        assert client.host == "myhost"
        assert client.port == 2222
        assert client.username == "admin"
        assert client._client is None


class TestConnect:
    def test_connect_with_password(self):
        patcher, mock_instance = _mock_paramiko()
        with patcher:
            client = _make_client(password="pw")
            client.connect()

        mock_instance.connect.assert_called_once_with(
            hostname="host", port=22, username="user", password="pw"
        )

    def test_connect_with_key_path(self):
        patcher, mock_instance = _mock_paramiko()
        with patcher:
            client = _make_client(password=None, key_path="/id_rsa")
            client.connect()

        mock_instance.connect.assert_called_once_with(
            hostname="host", port=22, username="user", key_filename="/id_rsa"
        )

    def test_auto_add_policy_set(self):
        patcher, mock_instance = _mock_paramiko()
        with patch("vault88.utils.ssh.paramiko.AutoAddPolicy") as mock_policy:
            with patcher:
                _make_client().connect()
        mock_instance.set_missing_host_key_policy.assert_called_once_with(mock_policy())


class TestDisconnect:
    def test_disconnect_closes_client(self):
        patcher, mock_instance = _mock_paramiko()
        with patcher:
            client = _make_client()
            client.connect()
            client.disconnect()

        mock_instance.close.assert_called_once()
        assert client._client is None

    def test_disconnect_when_not_connected_is_a_no_op(self):
        client = _make_client()
        client.disconnect()  # _client is None — should not raise


class TestContextManager:
    def test_enter_calls_connect_and_returns_self(self):
        patcher, mock_instance = _mock_paramiko()
        with patcher:
            client = _make_client()
            result = client.__enter__()
        assert result is client

    def test_exit_calls_disconnect(self):
        patcher, mock_instance = _mock_paramiko()
        with patcher:
            client = _make_client()
            client.connect()
            client.__exit__(None, None, None)
        mock_instance.close.assert_called_once()

    def test_with_statement_connects_and_disconnects(self):
        patcher, mock_instance = _mock_paramiko()
        with patcher:
            with _make_client():
                pass
        mock_instance.connect.assert_called_once()
        mock_instance.close.assert_called_once()


class TestRequireConnection:
    def test_raises_when_not_connected(self):
        client = _make_client()
        with pytest.raises(RuntimeError, match="Not connected"):
            client._require_connection()

    def test_does_not_raise_when_connected(self):
        patcher, mock_instance = _mock_paramiko()
        with patcher:
            client = _make_client()
            client.connect()
        client._require_connection()  # should not raise


class TestRun:
    def _connected_client(self, mock_instance):
        client = _make_client()
        client._client = mock_instance
        return client

    def test_run_returns_ssh_response(self):
        mock_instance = MagicMock()
        stdout_f = MagicMock()
        stderr_f = MagicMock()
        stdout_f.channel.recv_exit_status.return_value = 0
        stdout_f.read.return_value = b"hello\n"
        stderr_f.read.return_value = b""
        mock_instance.exec_command.return_value = (None, stdout_f, stderr_f)

        client = self._connected_client(mock_instance)
        response = client.run("echo hello")

        assert isinstance(response, SSHResponse)
        assert response.return_code == 0
        assert response.stdout == "hello\n"
        assert response.stderr == ""

    def test_run_captures_stderr(self):
        mock_instance = MagicMock()
        stdout_f = MagicMock()
        stderr_f = MagicMock()
        stdout_f.channel.recv_exit_status.return_value = 1
        stdout_f.read.return_value = b""
        stderr_f.read.return_value = b"error message"
        mock_instance.exec_command.return_value = (None, stdout_f, stderr_f)

        client = self._connected_client(mock_instance)
        response = client.run("bad_command")

        assert response.return_code == 1
        assert response.stderr == "error message"

    def test_run_raises_when_not_connected(self):
        client = _make_client()
        with pytest.raises(RuntimeError):
            client.run("ls")


class TestPutGet:
    def _connected_client(self, mock_instance):
        client = _make_client()
        client._client = mock_instance
        return client

    def test_put_uses_sftp(self):
        mock_instance = MagicMock()
        mock_sftp = MagicMock()
        mock_instance.open_sftp.return_value.__enter__ = MagicMock(return_value=mock_sftp)
        mock_instance.open_sftp.return_value.__exit__ = MagicMock(return_value=False)

        client = self._connected_client(mock_instance)
        client.put("/local/file.txt", "/remote/file.txt")

        mock_sftp.put.assert_called_once_with("/local/file.txt", "/remote/file.txt")

    def test_get_uses_sftp(self):
        mock_instance = MagicMock()
        mock_sftp = MagicMock()
        mock_instance.open_sftp.return_value.__enter__ = MagicMock(return_value=mock_sftp)
        mock_instance.open_sftp.return_value.__exit__ = MagicMock(return_value=False)

        client = self._connected_client(mock_instance)
        client.get("/remote/file.txt", "/local/file.txt")

        mock_sftp.get.assert_called_once_with("/remote/file.txt", "/local/file.txt")

    def test_put_raises_when_not_connected(self):
        client = _make_client()
        with pytest.raises(RuntimeError):
            client.put("/local/f", "/remote/f")

    def test_get_raises_when_not_connected(self):
        client = _make_client()
        with pytest.raises(RuntimeError):
            client.get("/remote/f", "/local/f")
