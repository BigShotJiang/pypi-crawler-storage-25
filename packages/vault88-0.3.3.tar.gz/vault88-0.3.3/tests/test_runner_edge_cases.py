"""Runner error-path tests"""

import pytest

from vault88.constructs.test import Test
from vault88.core.logger import Logger
from vault88.core.runner import Runner


@pytest.fixture
def logger(tmp_path):
    log = Logger()
    log.setupLogger(str(tmp_path / "vault88.log"))
    yield log
    log.detachFileHandler()
    log.detachStreamHandler()


class _Base(Test):
    name = "Base"
    tags = []

    def selfCheck(self):
        return True

    def setup(self):
        return True

    def run(self):
        pass

    def teardown(self):
        pass


class TestRunnerEdgeCases:
    def test_selfcheck_returns_false_aborts_run(self, logger):
        class T(_Base):
            setup_called = False

            def selfCheck(self):
                return False

            def setup(self):
                T.setup_called = True
                return True

        test = Runner(logger, T).runTest()
        assert test is not None
        assert T.setup_called is False
        assert test.stages == []

    def test_selfcheck_exception_sets_flag(self, logger):
        class T(_Base):
            def selfCheck(self):
                raise RuntimeError("selfcheck boom")

        runner = Runner(logger, T)
        runner.runTest()
        assert runner.exception is True

    def test_setup_returns_false_calls_teardown(self, logger):
        class T(_Base):
            torn = False

            def setup(self):
                return False

            def teardown(self):
                T.torn = True

        Runner(logger, T).runTest()
        assert T.torn is True

    def test_setup_exception_calls_teardown(self, logger):
        class T(_Base):
            torn = False

            def setup(self):
                raise RuntimeError("setup boom")

            def teardown(self):
                T.torn = True

        runner = Runner(logger, T)
        runner.runTest()
        assert T.torn is True
        assert runner.exception is True

    def test_run_exception_still_calls_teardown(self, logger):
        class T(_Base):
            torn = False

            def run(self):
                raise RuntimeError("run boom")

            def teardown(self):
                T.torn = True

        runner = Runner(logger, T)
        runner.runTest()
        assert T.torn is True
        assert runner.exception is True

    def test_teardown_exception_sets_flag(self, logger):
        class T(_Base):
            def teardown(self):
                raise RuntimeError("teardown boom")

        runner = Runner(logger, T)
        runner.runTest()
        assert runner.exception is True

    def test_init_exception_returns_none(self, logger):
        class T(_Base):
            def __init__(self, *a, **kw):
                raise RuntimeError("init boom")

        runner = Runner(logger, T)
        result = runner.runTest()
        assert result is None
        assert runner.exception is True

    def test_with_environment_passed_to_test(self, logger):
        class T(_Base):
            received_env = None

            def __init__(self, log, log_dir, environment=None):
                super().__init__(log, log_dir, environment)
                T.received_env = environment

        env = object()
        Runner(logger, T, environment=env).runTest()
        assert T.received_env is env
