"""Unit tests for JUnitReporter"""

import xml.etree.ElementTree as ET
from unittest.mock import MagicMock

import pytest

from vault88.constructs.result import Result, ResultOutcome
from vault88.constructs.stage import Stage
from vault88.constructs.test import Test
from vault88.core.reporters.junit_reporter import JUnitReporter

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class MinimalTest(Test):
    name = "Minimal Test"
    tags = []

    def selfCheck(self):
        return True

    def setup(self):
        return True

    def run(self):
        pass

    def teardown(self):
        pass


def make_test(stages_data):
    """Build a MinimalTest with pre-loaded stages from (stage_name, [results]) tuples."""
    test = MinimalTest(MagicMock(), "/tmp")
    for stage_name, results in stages_data:
        stage = Stage(stage_name)
        for r in results:
            stage.addResult(r)
        test.stages.append(stage)
    return test


def passed(action="step", expected="x", actual="x"):
    return Result(action, expected, actual, ResultOutcome.PASSED)


def failed(action="step", expected="x", actual="y"):
    return Result(action, expected, actual, ResultOutcome.FAILED)


def not_run(action="step", expected="x", actual="N/A"):
    return Result(action, expected, actual, ResultOutcome.NOT_RUN)


def make_reporter(config=None):
    return JUnitReporter(MagicMock(), config or {})


def read_xml(tmp_path):
    return ET.parse(tmp_path / "testresults.xml").getroot()


# ---------------------------------------------------------------------------
# check()
# ---------------------------------------------------------------------------


class TestCheck:
    def test_returns_false_when_no_stages(self):
        reporter = make_reporter()
        assert reporter.check(make_test([])) is False

    def test_returns_false_when_stages_have_no_results(self):
        reporter = make_reporter()
        assert reporter.check(make_test([("Stage A", []), ("Stage B", [])])) is False

    def test_returns_true_when_first_stage_has_results(self):
        reporter = make_reporter()
        assert reporter.check(make_test([("Stage A", [passed()])])) is True

    def test_returns_true_when_only_later_stage_has_results(self):
        reporter = make_reporter()
        assert reporter.check(make_test([("Stage A", []), ("Stage B", [passed()])])) is True


# ---------------------------------------------------------------------------
# publish()
# ---------------------------------------------------------------------------


class TestPublish:
    @pytest.fixture(autouse=True)
    def chdir(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        self.tmp_path = tmp_path

    # --- file output ---

    def test_creates_xml_file(self):
        make_reporter().publish(make_test([("Stage A", [passed()])]))
        assert (self.tmp_path / "testresults.xml").exists()

    def test_logger_info_called_with_output_path(self):
        mock_logger = MagicMock()
        reporter = JUnitReporter(mock_logger, {})
        reporter.publish(make_test([("Stage A", [passed()])]))
        mock_logger.info.assert_called_once()
        assert "testresults.xml" in mock_logger.info.call_args[0][0]

    # --- test case identity ---

    def test_testcase_name_matches_test_name(self):
        make_reporter().publish(make_test([("Stage A", [passed()])]))
        tc = read_xml(self.tmp_path).find(".//testcase")
        assert tc.get("name") == "Minimal Test"

    def test_testcase_classname_is_python_class_name(self):
        make_reporter().publish(make_test([("Stage A", [passed()])]))
        tc = read_xml(self.tmp_path).find(".//testcase")
        assert tc.get("classname") == "MinimalTest"

    # --- stdout trace ---

    def test_stdout_contains_stage_header(self):
        make_reporter().publish(make_test([("Arithmetic checks", [passed()])]))
        stdout = read_xml(self.tmp_path).find(".//system-out")
        assert "[Arithmetic checks]" in stdout.text

    def test_stdout_contains_outcome_action_expected_actual(self):
        make_reporter().publish(make_test([("Stage A", [passed("My Action", "5", "5")])]))
        stdout = read_xml(self.tmp_path).find(".//system-out")
        assert "PASSED" in stdout.text
        assert "My Action" in stdout.text
        assert "Expected: 5" in stdout.text
        assert "Actual: 5" in stdout.text

    def test_stdout_contains_all_stages_in_order(self):
        make_reporter().publish(
            make_test(
                [
                    ("First Stage", [passed("step 1")]),
                    ("Second Stage", [passed("step 2")]),
                ]
            )
        )
        stdout = read_xml(self.tmp_path).find(".//system-out")
        first_pos = stdout.text.index("[First Stage]")
        second_pos = stdout.text.index("[Second Stage]")
        assert first_pos < second_pos

    def test_failed_result_appears_as_failed_in_stdout(self):
        make_reporter().publish(make_test([("Stage A", [failed("Bad step")])]))
        stdout = read_xml(self.tmp_path).find(".//system-out")
        assert "FAILED" in stdout.text

    def test_not_run_result_appears_as_not_run_in_stdout(self):
        make_reporter().publish(make_test([("Stage A", [not_run("Skipped step")])]))
        stdout = read_xml(self.tmp_path).find(".//system-out")
        assert "NOT_RUN" in stdout.text

    # --- passing test ---

    def test_all_passed_produces_no_failure_element(self):
        make_reporter().publish(make_test([("Stage A", [passed(), passed()])]))
        tc = read_xml(self.tmp_path).find(".//testcase")
        assert tc.find("failure") is None

    def test_all_passed_produces_no_skipped_element(self):
        make_reporter().publish(make_test([("Stage A", [passed()])]))
        tc = read_xml(self.tmp_path).find(".//testcase")
        assert tc.find("skipped") is None

    # --- failing test ---

    def test_failed_result_produces_failure_element(self):
        make_reporter().publish(make_test([("Stage A", [failed("Bad step", "1", "2")])]))
        assert read_xml(self.tmp_path).find(".//failure") is not None

    def test_failure_message_reports_count(self):
        make_reporter().publish(make_test([("Stage A", [failed(), failed(), passed()])]))
        failure = read_xml(self.tmp_path).find(".//failure")
        assert "2 step(s) failed" in failure.get("message")

    def test_failure_output_includes_action_expected_actual(self):
        make_reporter().publish(
            make_test(
                [
                    (
                        "Stage A",
                        [
                            failed("Broken check", "good", "bad"),
                        ],
                    )
                ]
            )
        )
        failure = read_xml(self.tmp_path).find(".//failure")
        text = failure.text or ""
        assert "Broken check" in text
        assert "good" in text
        assert "bad" in text

    def test_failure_output_includes_all_failing_steps(self):
        make_reporter().publish(
            make_test(
                [
                    (
                        "Stage A",
                        [
                            failed("First fail"),
                            failed("Second fail"),
                        ],
                    )
                ]
            )
        )
        text = read_xml(self.tmp_path).find(".//failure").text or ""
        assert "First fail" in text
        assert "Second fail" in text

    def test_passing_steps_not_in_failure_output(self):
        make_reporter().publish(
            make_test(
                [
                    (
                        "Stage A",
                        [
                            failed("bad step"),
                            passed("good step"),
                        ],
                    )
                ]
            )
        )
        text = read_xml(self.tmp_path).find(".//failure").text or ""
        assert "good step" not in text

    # --- not-run test ---

    def test_not_run_produces_skipped_element(self):
        make_reporter().publish(make_test([("Stage A", [not_run("Skipped step")])]))
        tc = read_xml(self.tmp_path).find(".//testcase")
        assert tc.find("skipped") is not None

    def test_skipped_message_is_set(self):
        make_reporter().publish(make_test([("Stage A", [not_run()])]))
        skipped = read_xml(self.tmp_path).find(".//skipped")
        assert skipped.get("message") == "Test not fully executed"

    # --- precedence: failures override not_run ---

    def test_failures_take_precedence_over_not_run(self):
        make_reporter().publish(make_test([("Stage A", [failed("bad"), not_run("incomplete")])]))
        tc = read_xml(self.tmp_path).find(".//testcase")
        assert tc.find("failure") is not None
        assert tc.find("skipped") is None

    # --- accumulation across calls ---

    def test_accumulates_test_cases_across_publish_calls(self):
        reporter = make_reporter()
        reporter.publish(make_test([("Stage A", [passed()])]))
        reporter.publish(make_test([("Stage B", [passed()])]))
        assert len(read_xml(self.tmp_path).findall(".//testcase")) == 2

    # --- suite name ---

    def test_default_suite_name_is_vault88(self):
        make_reporter(config={}).publish(make_test([("Stage A", [passed()])]))
        suite = read_xml(self.tmp_path).find(".//testsuite")
        assert suite.get("name") == "vault88"

    def test_custom_suite_name_from_config(self):
        make_reporter(config={"suite_name": "MyProject"}).publish(
            make_test([("Stage A", [passed()])])
        )
        suite = read_xml(self.tmp_path).find(".//testsuite")
        assert suite.get("name") == "MyProject"
