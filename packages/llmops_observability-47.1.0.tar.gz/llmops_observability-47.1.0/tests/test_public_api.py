import importlib


def test_public_api_exports(monkeypatch):
    import llmops_observability as mod

    expected = {
        "TraceManager",
        "track_function",
        "track_llm_call",
        "track_external_service",
        "resume_external_service",
        "get_injected_headers",
        "send_to_sqs",
        "send_to_sqs_immediate",
        "flush_sqs",
        "is_sqs_enabled",
        "LLMOpsASGIMiddleware",
        "enable_outbound_http_instrumentation",
        "disable_outbound_http_instrumentation",
        "outbound_instrumentation_status",
        "enable_requests_instrumentation",
        "disable_requests_instrumentation",
        "is_requests_instrumentation_enabled",
        "enable_httpx_instrumentation",
        "disable_httpx_instrumentation",
        "is_httpx_instrumentation_enabled",
        "enable_urllib_instrumentation",
        "disable_urllib_instrumentation",
        "is_urllib_instrumentation_enabled",
        "EVALUATION_SPAN_TYPE",
        "record_evaluation",
        "CRAWL_SESSION_SPAN_TYPE",
        "CRAWL_PAGE_SPAN_TYPE",
        "crawl_session",
        "start_crawl_session",
        "record_crawl_page",
        "end_crawl_session",
        "enable_bedrock_instrumentation",
        "disable_bedrock_instrumentation",
        "is_instrumentation_enabled",
        "__version__",
    }

    assert set(mod.__all__) == expected


def test_version_fallback(monkeypatch):
    import importlib.metadata as metadata

    def _raise_pkg_not_found(_name):
        raise metadata.PackageNotFoundError()

    monkeypatch.setattr(metadata, "version", _raise_pkg_not_found)
    mod = importlib.reload(importlib.import_module("llmops_observability"))
    assert mod.__version__ == "0.0.0"


def test_bedrock_instrumentation_available():
    """Test that bedrock instrumentation is available when dependencies exist."""
    import llmops_observability as mod
    
    # If we got here, bedrock_instrumentation was imported successfully
    assert mod.BEDROCK_INSTRUMENTATION_AVAILABLE is True
    assert mod.enable_bedrock_instrumentation is not None
    assert mod.disable_bedrock_instrumentation is not None
    assert mod.is_instrumentation_enabled is not None


def test_bedrock_instrumentation_import_error_fallback(monkeypatch):
    """Test that module handles ImportError for bedrock_instrumentation gracefully."""
    # We need to simulate the ImportError case
    # This is hard to test directly because the module is already imported
    # Instead, verify the expected attributes exist in the fallback scenario
    import llmops_observability as mod
    
    # When bedrock instrumentation is available
    if mod.BEDROCK_INSTRUMENTATION_AVAILABLE:
        assert callable(mod.enable_bedrock_instrumentation)
        assert callable(mod.disable_bedrock_instrumentation)
        assert callable(mod.is_instrumentation_enabled)
    else:
        # Fallback case - functions should be None
        assert mod.enable_bedrock_instrumentation is None
        assert mod.disable_bedrock_instrumentation is None
        assert mod.is_instrumentation_enabled is None


def test_all_exports_are_importable():
    """Test that all items in __all__ can be accessed."""
    import llmops_observability as mod
    
    for name in mod.__all__:
        assert hasattr(mod, name), f"{name} not found in module"
        obj = getattr(mod, name)
        # Just verify we can access each export
        assert obj is not None or name in ["enable_bedrock_instrumentation", 
                                            "disable_bedrock_instrumentation",
                                            "is_instrumentation_enabled"]
