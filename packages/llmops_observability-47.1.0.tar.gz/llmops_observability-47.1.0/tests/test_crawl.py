import pytest

from llmops_observability.crawl import (
    CRAWL_PAGE_SPAN_TYPE,
    CRAWL_SESSION_SPAN_TYPE,
    crawl_session,
    end_crawl_session,
    record_crawl_page,
    start_crawl_session,
)
from llmops_observability.trace_manager import TraceManager


@pytest.fixture(autouse=True)
def _crawl_trace_env(monkeypatch):
    monkeypatch.setenv("AWS_SQS_URL", "https://example.com/test-queue")
    monkeypatch.setenv("PROJECT_ID", "test_project")
    monkeypatch.setenv("ENV", "test")
    TraceManager._active["trace_id"] = None
    TraceManager._active["trace_config"] = None
    TraceManager._active["start_time"] = None
    TraceManager._active["spans"] = []
    TraceManager._active["stack"] = []
    TraceManager._active["finalized_trace_id"] = None
    TraceManager._active["finalized_timestamp"] = None
    yield


def test_crawl_no_trace_returns_none():
    assert start_crawl_session(query="q") is None
    assert record_crawl_page(url="https://a.com") is None


def test_crawl_session_pages_and_summary():
    TraceManager.start_trace(name="crawl_test")
    sid = start_crawl_session(name="agent_crawl", provider="scrapy", query="weather", metadata={"safe": "x"})
    assert sid is not None
    assert TraceManager.get_current_parent_span_id() == sid

    p1 = record_crawl_page(
        url="https://news.example.com/a?api_key=secret&q=1",
        status_code=200,
        latency_ms=50,
    )
    p2 = record_crawl_page(url="https://news.example.com/b", status_code=404, latency_ms=30)

    assert p1 and p2
    pages = [s for s in TraceManager._active["spans"] if s.span_type == CRAWL_PAGE_SPAN_TYPE]
    assert len(pages) == 2
    assert pages[0].parent_span_id == sid
    assert "api_key=%5BREDACTED%5D" in (pages[0].metadata or {}).get("crawl.url", "")
    assert pages[1].status == "error" or pages[1].metadata.get("crawl.success") is False

    end_crawl_session(sid, metadata={"note": "done"})
    assert TraceManager.get_current_parent_span_id() is None

    sessions = [s for s in TraceManager._active["spans"] if s.span_type == CRAWL_SESSION_SPAN_TYPE]
    assert len(sessions) == 1
    sess = sessions[0]
    assert sess.span_id == sid
    assert sess.metadata.get("crawl.pages_ok") == 1
    assert sess.metadata.get("crawl.pages_fail") == 1


def test_crawl_session_context_manager():
    TraceManager.start_trace(name="ctx")
    with crawl_session(provider="tavily", query="q") as sid:
        assert sid is not None
        record_crawl_page(url="https://x.com", status_code=200, latency_ms=1)
    sess = [s for s in TraceManager._active["spans"] if s.span_type == CRAWL_SESSION_SPAN_TYPE]
    assert len(sess) == 1


def test_record_crawl_page_redacts_metadata():
    TraceManager.start_trace(name="m")
    sid = start_crawl_session()
    record_crawl_page(
        url="https://z.com",
        status_code=200,
        metadata={"api_key": "hide-me"},
    )
    page = next(s for s in TraceManager._active["spans"] if s.span_type == CRAWL_PAGE_SPAN_TYPE)
    assert page.metadata.get("api_key") == "[REDACTED]"
    end_crawl_session(sid)
