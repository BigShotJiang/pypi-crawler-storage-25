import pytest
import requests

from llmops_observability.trace_manager import TraceManager
import llmops_observability.outbound_http as outbound_http
import llmops_observability.outbound_httpx as outbound_httpx
import llmops_observability.outbound_urllib as outbound_urllib
from llmops_observability.outbound_http import (
    disable_outbound_http_instrumentation,
    enable_requests_instrumentation,
    disable_requests_instrumentation,
    is_requests_instrumentation_enabled,
)


@pytest.fixture(autouse=True)
def _reset_state(monkeypatch):
    monkeypatch.setenv("AWS_SQS_URL", "https://example.com/test-queue")
    monkeypatch.setenv("PROJECT_ID", "test_project")
    monkeypatch.setenv("ENV", "test")
    TraceManager._active["trace_id"] = None
    TraceManager._active["trace_config"] = None
    TraceManager._active["start_time"] = None
    TraceManager._active["spans"] = []
    TraceManager._active["stack"] = []
    TraceManager._active["finalized_trace_id"] = None
    TraceManager._active["finalized_timestamp"] = None
    disable_outbound_http_instrumentation()
    outbound_http._original_session_request = None
    outbound_httpx._original_client_request = None
    outbound_httpx._original_async_client_request = None
    outbound_httpx._sync_patched = False
    outbound_httpx._async_patched = False
    outbound_urllib._original_urlopen = None
    outbound_urllib._patched = False
    yield
    disable_outbound_http_instrumentation()
    outbound_http._original_session_request = None
    outbound_httpx._original_client_request = None
    outbound_httpx._original_async_client_request = None
    outbound_httpx._sync_patched = False
    outbound_httpx._async_patched = False
    outbound_urllib._original_urlopen = None
    outbound_urllib._patched = False


def test_enable_disable_requests_instrumentation():
    assert is_requests_instrumentation_enabled() is False
    assert enable_requests_instrumentation() is True
    assert is_requests_instrumentation_enabled() is True
    assert disable_requests_instrumentation() is True
    assert is_requests_instrumentation_enabled() is False


def test_outbound_request_creates_span(monkeypatch):
    class DummyResponse:
        status_code = 200
        headers = {"Content-Length": "12", "Content-Type": "application/json"}

    def fake_request(self, method, url, *args, **kwargs):
        return DummyResponse()

    monkeypatch.setattr(requests.sessions.Session, "request", fake_request)
    enable_requests_instrumentation()
    TraceManager.start_trace(name="http_trace")

    resp = requests.get(
        "https://example.com/search?q=test&api_key=secret",
        headers={"Authorization": "Bearer token-123", "x-custom": "ok"},
        timeout=5,
    )
    assert resp.status_code == 200
    assert len(TraceManager._active["spans"]) == 1
    span = TraceManager._active["spans"][0]
    assert span.status == "success"
    assert span.metadata["method"] == "GET"
    assert span.metadata["http.call_mode"] == "sync"
    assert span.metadata["status_code"] == 200
    assert span.metadata["latency_ms"] >= 0
    assert "%5BREDACTED%5D" in span.metadata["url"]
    assert span.metadata["request_headers"]["Authorization"] == "[REDACTED]"


def test_outbound_request_error_creates_error_span(monkeypatch):
    def fake_request(self, method, url, *args, **kwargs):
        raise requests.exceptions.Timeout("timed out")

    monkeypatch.setattr(requests.sessions.Session, "request", fake_request)
    enable_requests_instrumentation()
    TraceManager.start_trace(name="http_error_trace")

    with pytest.raises(requests.exceptions.Timeout):
        requests.post(
            "https://example.com/submit?token=abc",
            json={"password": "secret", "value": 1},
            timeout=2,
        )

    assert len(TraceManager._active["spans"]) == 1
    span = TraceManager._active["spans"][0]
    assert span.status == "error"
    assert "timed out" in (span.error or "")
    assert span.metadata["error"] is not None


def test_outbound_payload_redaction(monkeypatch):
    class DummyResponse:
        status_code = 201
        headers = {}

    def fake_request(self, method, url, *args, **kwargs):
        return DummyResponse()

    monkeypatch.setattr(requests.sessions.Session, "request", fake_request)
    enable_requests_instrumentation()
    TraceManager.start_trace(name="http_payload_redaction")

    requests.post(
        "https://example.com/create",
        json={"user": "abc", "password": "secret-1", "nested": {"api_key": "k1"}},
        timeout=3,
    )

    span = TraceManager._active["spans"][0]
    preview = span.metadata["request_payload"]["preview"]
    assert "secret-1" not in preview
    assert "k1" not in preview
    assert "[REDACTED]" in preview


def test_outbound_correlation_uses_parent_span(monkeypatch):
    class DummyResponse:
        status_code = 200
        headers = {}

    def fake_request(self, method, url, *args, **kwargs):
        return DummyResponse()

    monkeypatch.setattr(requests.sessions.Session, "request", fake_request)
    enable_requests_instrumentation()
    TraceManager.start_trace(name="http_correlation")

    TraceManager.push_span_context("parent-span-123")
    try:
        requests.get("https://example.com/ping", timeout=1)
    finally:
        TraceManager.pop_span_context()

    span = TraceManager._active["spans"][0]
    assert span.parent_span_id == "parent-span-123"


def test_urllib_urlopen_creates_span(monkeypatch):
    import urllib.request

    class DummyResponse:
        status_code = 200
        headers = {}

        def read(self):
            return b"ok"

        def __enter__(self):
            return self

        def __exit__(self, *exc):
            return None

    def fake_urlopen(url, data=None, **kwargs):
        return DummyResponse()

    outbound_urllib.enable_urllib_instrumentation()
    monkeypatch.setattr(outbound_urllib, "_original_urlopen", fake_urlopen)

    TraceManager.start_trace(name="urllib_trace")
    urllib.request.urlopen("https://example.com/path?api_key=secret")

    assert len(TraceManager._active["spans"]) == 1
    span = TraceManager._active["spans"][0]
    assert span.metadata["http.client.library"] == "urllib"
    assert span.metadata["http.call_mode"] == "sync"
    assert span.metadata["method"] == "GET"
    assert "[REDACTED]" in span.metadata["url"] or "REDACTED" in span.metadata["url"]


def test_httpx_sync_creates_span(monkeypatch):
    httpx = pytest.importorskip("httpx")

    def fake_request(self, method, url, *args, **kwargs):
        class R:
            status_code = 200
            headers = {}

        return R()

    outbound_httpx.enable_httpx_instrumentation(sync=True, async_client=False)
    monkeypatch.setattr(outbound_httpx, "_original_client_request", fake_request)

    TraceManager.start_trace(name="httpx_sync")
    with httpx.Client() as client:
        client.get("https://example.com/h?token=abc")

    assert len(TraceManager._active["spans"]) == 1
    span = TraceManager._active["spans"][0]
    assert span.metadata["http.client.library"] == "httpx"
    assert span.metadata["http.call_mode"] == "sync"
    assert span.metadata["status_code"] == 200


def test_httpx_async_creates_span(monkeypatch):
    import asyncio

    httpx = pytest.importorskip("httpx")

    async def fake_request(self, method, url, *args, **kwargs):
        class R:
            status_code = 204
            headers = {}

        return R()

    outbound_httpx.enable_httpx_instrumentation(sync=False, async_client=True)
    monkeypatch.setattr(outbound_httpx, "_original_async_client_request", fake_request)

    TraceManager.start_trace(name="httpx_async")

    async def run():
        async with httpx.AsyncClient() as client:
            await client.get("https://example.com/async")

    asyncio.run(run())

    assert len(TraceManager._active["spans"]) == 1
    span = TraceManager._active["spans"][0]
    assert span.metadata["http.client.library"] == "httpx-async"
    assert span.metadata["http.call_mode"] == "async"
    assert span.metadata["status_code"] == 204


def test_enable_all_outbound_helpers():
    disable_outbound_http_instrumentation()
    status = outbound_http.enable_outbound_http_instrumentation()
    assert status["requests"] is True
    assert status["urllib"] is True
    # httpx true only when installed (CI should have it via test extra)
    assert "httpx" in status
    disable_outbound_http_instrumentation()

