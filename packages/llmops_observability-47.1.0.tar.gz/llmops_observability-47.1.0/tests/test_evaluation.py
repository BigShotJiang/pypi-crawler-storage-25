import pytest

from llmops_observability.evaluation import EVALUATION_SPAN_TYPE, record_evaluation
from llmops_observability.trace_manager import TraceManager


@pytest.fixture(autouse=True)
def _evaluation_trace_env(monkeypatch):
    monkeypatch.setenv("AWS_SQS_URL", "https://example.com/test-queue")
    monkeypatch.setenv("PROJECT_ID", "test_project")
    monkeypatch.setenv("ENV", "test")
    TraceManager._active["trace_id"] = None
    TraceManager._active["trace_config"] = None
    TraceManager._active["start_time"] = None
    TraceManager._active["spans"] = []
    TraceManager._active["stack"] = []
    TraceManager._active["finalized_trace_id"] = None
    TraceManager._active["finalized_timestamp"] = None
    yield


def test_record_evaluation_no_trace_returns_none():
    assert record_evaluation(score=1.0, label="ok") is None


def test_record_evaluation_creates_span_with_payload():
    TraceManager.start_trace(name="eval_test")
    TraceManager.push_span_context("parent-span-1")

    sid = record_evaluation(
        score=0.87,
        label="pass",
        rationale="Matches expected format",
        name="quality_check",
        evaluated_span_id="generation-abc",
    )
    assert sid is not None
    assert len(TraceManager._active["spans"]) == 1
    span = TraceManager._active["spans"][0]
    assert span.span_id == sid
    assert span.span_name == "quality_check"
    assert span.span_type == EVALUATION_SPAN_TYPE
    assert span.parent_span_id == "parent-span-1"
    assert span.input_data["evaluation"]["score"] == pytest.approx(0.87)
    assert span.input_data["evaluation"]["label"] == "pass"
    assert span.input_data["evaluation"]["rationale"] == "Matches expected format"
    assert span.input_data["evaluation"]["evaluated_span_id"] == "generation-abc"
    assert "evaluation" in (span.tags or [])


def test_record_evaluation_parent_override():
    TraceManager.start_trace(name="eval_test")
    TraceManager.push_span_context("ignored-parent")

    record_evaluation(score=1, label="x", parent_span_id="explicit-parent")
    span = TraceManager._active["spans"][-1]
    assert span.parent_span_id == "explicit-parent"


def test_record_evaluation_redacts_metadata_keys():
    TraceManager.start_trace(name="eval_test")
    record_evaluation(
        score=0.5,
        metadata={"api_key": "secret123", "safe": "visible"},
    )
    span = TraceManager._active["spans"][-1]
    assert span.metadata.get("safe") == "visible"
    assert span.metadata.get("api_key") == "[REDACTED]"
