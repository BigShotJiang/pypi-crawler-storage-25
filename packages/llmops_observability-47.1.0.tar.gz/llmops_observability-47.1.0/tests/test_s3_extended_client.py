import json

import llmops_observability.s3_extended_client as s3_extended_client


class _Body:
    def __init__(self, payload: bytes):
        self._payload = payload

    def read(self):
        return self._payload


class _FakeS3Client:
    def __init__(self):
        self.objects = {}

    def put_object(self, Bucket, Key, Body, ContentType, Metadata):
        self.objects[(Bucket, Key)] = {
            "Body": Body,
            "ContentType": ContentType,
            "Metadata": Metadata,
        }

    def get_object(self, Bucket, Key):
        obj = self.objects[(Bucket, Key)]
        return {"Body": _Body(obj["Body"])}


class _FakeSession:
    def __init__(self, client):
        self._client = client

    def client(self, name, region_name=None):
        assert name == "s3"
        return self._client


def test_compress_and_decompress_roundtrip(monkeypatch):
    fake_s3 = _FakeS3Client()
    monkeypatch.setattr(s3_extended_client, "boto3", _FakeSession(fake_s3))

    client = s3_extended_client.S3ExtendedClient(bucket_name="bucket", region="us-east-1")
    raw = json.dumps({"hello": "world"})
    compressed = client._compress_payload(raw)
    restored = client._decompress_payload(compressed)

    assert restored == raw


def test_store_and_retrieve_from_s3_success(monkeypatch):
    fake_s3 = _FakeS3Client()

    class _Boto3:
        @staticmethod
        def client(name, region_name=None):
            assert name == "s3"
            return fake_s3

    monkeypatch.setattr(s3_extended_client, "boto3", _Boto3)

    client = s3_extended_client.S3ExtendedClient(bucket_name="bucket", region="us-east-1")

    payload = {"trace_id": "t1", "spans": [{"span_id": "s1"}]}
    ok, key, err = client.store_in_s3(payload, trace_id="t1")

    assert ok is True
    assert err is None
    assert key is not None

    ok_get, restored, err_get = client.retrieve_from_s3(key)
    assert ok_get is True
    assert err_get is None
    assert restored == payload


def test_store_in_s3_returns_error_when_disabled(monkeypatch):
    monkeypatch.setattr(s3_extended_client, "boto3", None)

    client = s3_extended_client.S3ExtendedClient(bucket_name="bucket", region="us-east-1")
    ok, key, err = client.store_in_s3({"a": 1}, trace_id="t1")

    assert ok is False
    assert key is None
    assert err is not None and "not initialized" in err


def test_create_and_detect_s3_reference(monkeypatch):
    fake_s3 = _FakeS3Client()

    class _Boto3:
        @staticmethod
        def client(name, region_name=None):
            return fake_s3

    monkeypatch.setattr(s3_extended_client, "boto3", _Boto3)

    client = s3_extended_client.S3ExtendedClient(bucket_name="bucket", region="us-east-1")
    reference = client.create_sqs_reference("prefix/key.json.gz")

    assert client.is_s3_reference(reference) is True
    assert client.extract_s3_key(reference) == "prefix/key.json.gz"


def test_get_s3_extended_client_prefers_programmatic_config(monkeypatch):
    s3_extended_client._s3_extended_client = None

    fake_s3 = _FakeS3Client()

    class _Boto3:
        @staticmethod
        def client(name, region_name=None):
            return fake_s3

    monkeypatch.setattr(s3_extended_client, "boto3", _Boto3)

    import llmops_observability.config as config

    config.set_configuration(s3_bucket="configured-bucket", aws_region="us-west-2")

    client = s3_extended_client.get_s3_extended_client()
    assert client is not None
    assert client.bucket_name == "configured-bucket"


def test_should_use_s3_storage_threshold_and_availability(monkeypatch):
    class _EnabledClient:
        def is_enabled(self):
            return True

    class _DisabledClient:
        def is_enabled(self):
            return False

    monkeypatch.setattr(s3_extended_client, "get_s3_extended_client", lambda: _EnabledClient())
    assert s3_extended_client.should_use_s3_storage(payload_size=2000, threshold=1000) is True

    monkeypatch.setattr(s3_extended_client, "get_s3_extended_client", lambda: _DisabledClient())
    assert s3_extended_client.should_use_s3_storage(payload_size=2000, threshold=1000) is False

    assert s3_extended_client.should_use_s3_storage(payload_size=500, threshold=1000) is False


def test_store_in_s3_handles_json_serialization_error(monkeypatch):
    """store_in_s3 handles JSON serialization errors."""
    fake_s3 = _FakeS3Client()

    class _Boto3:
        @staticmethod
        def client(name, region_name=None):
            return fake_s3

    monkeypatch.setattr(s3_extended_client, "boto3", _Boto3)

    client = s3_extended_client.S3ExtendedClient(bucket_name="bucket", region="us-east-1")

    class BadPayload:
        pass

    ok, key, err = client.store_in_s3({"bad": BadPayload()}, trace_id="t1")
    assert ok is False
    assert err is not None


def test_retrieve_from_s3_handles_missing_key(monkeypatch):
    """retrieve_from_s3 handles missing S3 key."""
    fake_s3 = _FakeS3Client()

    class _Boto3:
        @staticmethod
        def client(name, region_name=None):
            return fake_s3

    monkeypatch.setattr(s3_extended_client, "boto3", _Boto3)

    client = s3_extended_client.S3ExtendedClient(bucket_name="bucket", region="us-east-1")

    ok, payload, err = client.retrieve_from_s3("nonexistent-key")
    assert ok is False
    assert payload is None
    assert err is not None


def test_retrieve_from_s3_when_disabled(monkeypatch):
    """retrieve_from_s3 returns error when client disabled."""
    monkeypatch.setattr(s3_extended_client, "boto3", None)

    client = s3_extended_client.S3ExtendedClient(bucket_name="bucket", region="us-east-1")

    ok, payload, err = client.retrieve_from_s3("any-key")
    assert ok is False
    assert payload is None
    assert err is not None and "not initialized" in err


def test_compress_payload_handles_string_and_bytes(monkeypatch):
    """_compress_payload accepts both string and bytes."""
    fake_s3 = _FakeS3Client()

    class _Boto3:
        @staticmethod
        def client(name, region_name=None):
            return fake_s3

    monkeypatch.setattr(s3_extended_client, "boto3", _Boto3)

    client = s3_extended_client.S3ExtendedClient(bucket_name="bucket", region="us-east-1")

    compressed_str = client._compress_payload("test string")
    assert isinstance(compressed_str, bytes)

    compressed_bytes = client._compress_payload(b"test bytes")
    assert isinstance(compressed_bytes, bytes)


def test_get_s3_extended_client_from_env(monkeypatch):
    """get_s3_extended_client uses env var when no programmatic config."""
    s3_extended_client._s3_extended_client = None

    fake_s3 = _FakeS3Client()

    class _Boto3:
        @staticmethod
        def client(name, region_name=None):
            return fake_s3

    monkeypatch.setattr(s3_extended_client, "boto3", _Boto3)
    monkeypatch.setenv("LLMOPS_S3_BUCKET", "env-bucket")

    import llmops_observability.config as config

    config._CONFIG.clear()  # Clear programmatic config

    client = s3_extended_client.get_s3_extended_client()
    assert client is not None
