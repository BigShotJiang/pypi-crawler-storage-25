"""
Configuration management for LLMOps Observability SDK
- Environment loading
- SQS configuration
- Default model resolution
- Size and performance limits
"""
import os
import logging
import tempfile
from typing import Dict, Any
from dotenv import load_dotenv

# Configure logger
logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('[llmops_observability] %(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)

# Try to load .env if it exists, but don't require it
# This allows users to set env vars before or after importing the SDK
try:
    load_dotenv()
except Exception:
    pass  # Silently continue if no .env file


# ============================================================
# PROGRAMMATIC CONFIGURATION STORAGE
# ============================================================
# Global configuration storage - allows setting config via code instead of env vars
_CONFIG: Dict[str, Any] = {}


def set_configuration(**config):
    """
    Set configuration programmatically instead of using environment variables.
    
    Parameters:
        llmops_project_id (str): Project identifier
        llmops_env (str): Environment name (e.g., "development", "production")
        llmops_aws_sqs_url (str): SQS queue URL
        llmops_aws_region (str): AWS region (default: "us-east-1")
        llmops_aws_profile (str): AWS profile name (default: "default")
        llmops_s3_bucket (str): S3 bucket for large payloads (optional)
    
    Example:
        set_configuration(
            llmops_project_id="my-project",
            llmops_env="production",
            llmops_aws_sqs_url="https://sqs.us-east-1.amazonaws.com/123/my-queue",
            llmops_aws_region="us-east-1"
        )
    """
    global _CONFIG
    changed_keys = []
    for key, value in config.items():
        if _CONFIG.get(key) != value:
            _CONFIG[key] = value
            changed_keys.append(key)

    if changed_keys:
        logger.debug(f"Configuration updated programmatically: {changed_keys}")


def get_config_value(key: str, default: Any = None) -> Any:
    """
    Get configuration value from programmatic config first, then fall back to env vars.
    
    Args:
        key: Configuration key name
        default: Default value if not found
    
    Returns:
        Configuration value or default
    """
    # Check programmatic config first
    if key in _CONFIG:
        return _CONFIG[key]
    
    # Fall back to environment variables
    return os.getenv(key.upper(), default)


# ============================================================
# SIZE LIMITS & CONSTRAINTS
# ============================================================
# Payload size limits for SQS and compression
# MAX_SQS_SIZE is a conservative pre-base64 compressed-payload ceiling
# to keep the final JSON MessageBody under the 1,048,576 byte SQS limit.
# COMPRESSION_THRESHOLD (1 MB) - compress payload only if > this size

# Serialization limits (override with env vars if needed)
MAX_SQS_SIZE = int(os.getenv("LLMOPS_MAX_SQS_SIZE", 780_000))         # Safe pre-base64 ceiling
COMPRESSION_THRESHOLD = int(os.getenv("LLMOPS_COMPRESSION_THRESHOLD", 1_000_000))  # 1 MB

# S3 Extended Client Configuration
# When payload exceeds this threshold, automatically store in S3 instead of SQS
# NOTE: Developers don't need to configure these - sensible defaults are provided
# These can still be overridden via environment variables if needed
S3_STORAGE_THRESHOLD = int(os.getenv("LLMOPS_S3_THRESHOLD", 780_000))  # Align with safe SQS ceiling
S3_BUCKET = os.getenv("LLMOPS_S3_BUCKET", "llmops-telementry")              # Default S3 bucket (override via env)
S3_REGION = os.getenv("LLMOPS_AWS_REGION", "us-east-1")                        # Default region
S3_PREFIX = os.getenv("LLMOPS_S3_PREFIX", "LLMOps/backup_traces/compressed_traces")  # S3 key prefix



# ============================================================
# SQS CONFIGURATION & BATCHING
# ============================================================

# Spillover file for failed SQS sends
SPILLOVER_FILE = os.path.join(
    tempfile.gettempdir(), 
    "llmops_observability_spillover_queue.jsonl"
)

# Worker configuration
SQS_WORKER_COUNT = 4        # Number of background worker threads
SQS_BATCH_SIZE = 10         # Flush batch when reaching this count
SQS_BATCH_TIMEOUT = 0.2     # Timeout for queue.get() in seconds
SQS_FLUSH_TIME_THRESHOLD = 0.15  # Time-based flush threshold (every ~1s)
SQS_SHUTDOWN_TIMEOUT = 1.0  # Timeout for worker shutdown
SQS_RETRY_ATTEMPTS = 3      # Number of retry attempts if no MessageId received
SQS_RETRY_DELAY = 0.1       # Delay between retries in seconds


def get_sqs_config() -> Dict[str, Any]:
    """
    Get SQS configuration from programmatic config or environment variables.
    
    Configuration can be set programmatically using set_configuration() or via env vars.
    
    Environment variables:
        - LLMOPS_AWS_SQS_URL: SQS queue URL (required to enable SQS)
        - LLMOPS_AWS_PROFILE: AWS profile name (default: "default")
        - LLMOPS_AWS_REGION: AWS region (default: "us-east-1")
    
    Returns:
        Dict with SQS configuration
    """
    return {
        "aws_sqs_url": get_config_value("llmops_aws_sqs_url"),
        "aws_profile": get_config_value("llmops_aws_profile", "default"),
        "aws_region": get_config_value("llmops_aws_region", "us-east-1"),
    }


# ============================================================
# PROJECT & ENVIRONMENT CONFIGURATION
# ============================================================

def get_project_id() -> str:
    """
    Get project ID from programmatic config or environment variables.
    Auto-injected into every span's metadata.
    
    Configuration can be set programmatically using set_configuration() or via env vars.
    
    Environment variables:
        - LLMOPS_PROJECT_ID: Project identifier (default: "unknown_project")
    
    Returns:
        str: Project ID
    """
    value = get_config_value("llmops_project_id", "unknown_project")
    return str(value).strip() if value else "unknown_project"


def get_environment() -> str:
    """
    Get environment from programmatic config or environment variables.
    Auto-injected into every span's metadata.
    
    Configuration can be set programmatically using set_configuration() or via env vars.
    
    Environment variables:
        - LLMOPS_ENV: Environment (e.g., "development", "staging", "uat", "production")
        - Default: "development"
    
    Returns:
        str: Environment name
    """
    # Try 'llmops_env' first (matches .env convention), then 'llmops_environment' for backward compatibility
    value = get_config_value("llmops_env") or get_config_value("llmops_environment", "development")
    return str(value).strip() if value else "development"


def get_trace_context() -> Dict[str, str]:
    """
    Get trace context (project_id and environment) from environment.
    This is injected into all spans automatically.
    
    Returns:
        Dict with project_id and environment
    """
    return {
        "project_id": get_project_id(),
        "environment": get_environment(),
    }


# ============================================================
# MODEL CONFIGURATION
# ============================================================

def get_default_model() -> str:
    """
    Get default model ID for cost calculation.
    
    Resolution order:
        1. MODEL_ID environment variable (if set)
        2. Default: anthropic.claude-3-5-sonnet-20241022-v2:0 (Claude 3.5 Sonnet - most common, cost-effective)
    
    Environment variables:
        - MODEL_ID: Default model ID for cost calculation (e.g., "anthropic.claude-3-sonnet-20240229-v1:0")
    
    Returns:
        str: Default model ID for cost calculation
    """
    # Most popular and cost-effective model as fallback
    DEFAULT_FALLBACK = "anthropic.claude-3-5-sonnet-20241022-v2:0"
    
    model_id = os.getenv("MODEL_ID", DEFAULT_FALLBACK).strip()
    
    if not model_id:
        model_id = DEFAULT_FALLBACK
    
    logger.debug(f"Default model for cost calculation: {model_id}")
    return model_id
