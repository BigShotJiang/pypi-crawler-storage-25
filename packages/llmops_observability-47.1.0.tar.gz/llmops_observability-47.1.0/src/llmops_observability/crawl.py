"""
Agentic crawl / search telemetry — session and per-page spans with redacted URLs.
"""
from __future__ import annotations

import logging
import threading
import time
import uuid
from contextlib import contextmanager
from typing import Any, Dict, Iterator, Optional
from urllib.parse import urlparse

from .redaction import DEFAULT_SENSITIVE_KEYS, redact_deep
from .outbound_http_core import redact_url as _redact_url
from .trace_manager import SpanData, TraceManager, ensure_json_object

logger = logging.getLogger(__name__)

CRAWL_SESSION_SPAN_TYPE = "crawl_session"
CRAWL_PAGE_SPAN_TYPE = "crawl_page"

_registry_lock = threading.Lock()
_session_registry: Dict[str, Dict[str, Any]] = {}


def _infer_page_success(
    success: Optional[bool],
    error: Optional[str],
    status_code: Optional[int],
) -> bool:
    if success is not None:
        return bool(success)
    if error:
        return False
    if status_code is not None:
        return 200 <= int(status_code) < 400
    return True


def start_crawl_session(
    *,
    name: str = "crawl_session",
    provider: Optional[str] = None,
    query: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    """
    Begin a crawl session: pushes a synthetic span id on the trace stack so
    :func:`record_crawl_page` nests under it. Call :func:`end_crawl_session`
    with the returned id to emit the session span and pop the stack.

    Returns the session span id, or ``None`` if no trace is active.
    """
    if not TraceManager.can_track_span():
        logger.debug("start_crawl_session skipped: no active or finalized trace")
        return None

    parent_for_session = TraceManager.get_current_parent_span_id()
    session_span_id = uuid.uuid4().hex
    merged = {"crawl.kind": "session", "crawl.session_name": name}
    if provider:
        merged["crawl.provider"] = provider
    if query is not None:
        merged["crawl.query"] = query
    if metadata:
        merged.update(redact_deep(metadata, DEFAULT_SENSITIVE_KEYS))

    with _registry_lock:
        _session_registry[session_span_id] = {
            "start": time.time(),
            "name": name,
            "provider": provider,
            "query": query,
            "parent_span_id": parent_for_session,
            "base_metadata": merged,
            "pages_ok": 0,
            "pages_fail": 0,
        }

    TraceManager.push_span_context(session_span_id)
    return session_span_id


def record_crawl_page(
    *,
    url: str,
    status_code: Optional[int] = None,
    latency_ms: Optional[int] = None,
    error: Optional[str] = None,
    success: Optional[bool] = None,
    name: Optional[str] = None,
    parent_span_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    """
    Record a single page fetch (or crawl step) as a child span.

    ``url`` is stored redacted (query parameters use the same policy as outbound HTTP).
    """
    if not TraceManager.can_track_span():
        logger.debug("record_crawl_page skipped: no active or finalized trace")
        return None

    ok = _infer_page_success(success, error, status_code)
    parent = parent_span_id if parent_span_id is not None else TraceManager.get_current_parent_span_id()

    with _registry_lock:
        if parent in _session_registry:
            if ok:
                _session_registry[parent]["pages_ok"] += 1
            else:
                _session_registry[parent]["pages_fail"] += 1

    safe_url = _redact_url(url)
    parsed = urlparse(url)
    host = parsed.netloc or "unknown-host"
    span_name = name or f"crawl.page {host}{parsed.path or '/'}"

    merged_meta: Dict[str, Any] = {
        "crawl.kind": "page",
        "crawl.url": safe_url,
        "crawl.status_code": status_code,
        "crawl.latency_ms": latency_ms,
        "crawl.success": ok,
    }
    if metadata:
        merged_meta.update(redact_deep(metadata, DEFAULT_SENSITIVE_KEYS))

    now = time.time()
    span = SpanData(
        span_id=uuid.uuid4().hex,
        span_name=span_name[:512],
        span_type=CRAWL_PAGE_SPAN_TYPE,
        parent_span_id=parent,
        start_time=now,
        end_time=now,
        duration_ms=int(latency_ms) if latency_ms is not None else 0,
        input_data=ensure_json_object({"url": safe_url, "raw_path": parsed.path or "/"}),
        output_data=ensure_json_object(
            {"status_code": status_code, "success": ok},
            key="result",
        ),
        error=error,
        metadata=merged_meta,
        tags=["crawl", "crawl_page"],
        status="error" if error or not ok else "success",
        status_message=error,
    )
    TraceManager.add_span(span)
    return span.span_id


def end_crawl_session(
    session_span_id: str,
    *,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """
    End a crawl session: pops the stack and appends the session summary span.
    """
    if not TraceManager.can_track_span():
        logger.debug("end_crawl_session skipped: no active or finalized trace")
        return

    with _registry_lock:
        info = _session_registry.pop(session_span_id, None)
    if not info:
        logger.warning("end_crawl_session: unknown session id %s (stack not modified)", session_span_id)
        return

    popped = TraceManager.pop_span_context()
    if popped != session_span_id:
        logger.warning(
            "end_crawl_session: stack mismatch (expected %s, got %s)",
            session_span_id,
            popped,
        )

    end = time.time()
    start = info["start"]
    duration_ms = max(0, int((end - start) * 1000))

    base = dict(info["base_metadata"])
    base["crawl.pages_ok"] = info["pages_ok"]
    base["crawl.pages_fail"] = info["pages_fail"]
    base["crawl.pages_total"] = info["pages_ok"] + info["pages_fail"]
    if metadata:
        base.update(redact_deep(metadata, DEFAULT_SENSITIVE_KEYS))

    span = SpanData(
        span_id=session_span_id,
        span_name=info["name"],
        span_type=CRAWL_SESSION_SPAN_TYPE,
        parent_span_id=info.get("parent_span_id"),
        start_time=start,
        end_time=end,
        duration_ms=duration_ms,
        input_data=ensure_json_object(
            {
                "provider": info["provider"],
                "query": info["query"],
            },
            key="crawl",
        ),
        output_data=ensure_json_object(
            {
                "pages_ok": info["pages_ok"],
                "pages_fail": info["pages_fail"],
                "duration_ms": duration_ms,
            },
            key="summary",
        ),
        error=None,
        metadata=base,
        tags=["crawl", "crawl_session"],
        status="success",
        status_message=None,
    )
    TraceManager.add_span(span)


@contextmanager
def crawl_session(
    *,
    name: str = "crawl_session",
    provider: Optional[str] = None,
    query: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Iterator[Optional[str]]:
    """
    Context manager: :func:`start_crawl_session` / :func:`end_crawl_session`.

    Yields the session span id (or ``None`` if tracing is disabled).
    """
    sid = start_crawl_session(name=name, provider=provider, query=query, metadata=metadata)
    try:
        yield sid
    finally:
        if sid:
            end_crawl_session(sid)
