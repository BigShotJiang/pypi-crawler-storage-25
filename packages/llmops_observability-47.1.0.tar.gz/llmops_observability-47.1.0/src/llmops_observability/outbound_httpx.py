"""
Optional ``httpx`` instrumentation (sync ``Client`` and async ``AsyncClient``).

Requires: ``pip install httpx`` (or ``llmops-observability[http]``).
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from .outbound_http_core import run_outbound_span_wrapped, run_outbound_span_wrapped_async

logger = logging.getLogger(__name__)

_original_client_request: Optional[Any] = None
_original_async_client_request: Optional[Any] = None
_sync_patched = False
_async_patched = False


def _instrumented_httpx_client_request(self, method: str, url, *args, **kwargs):
    u = str(url)

    def execute():
        return _original_client_request(self, method, url, *args, **kwargs)

    return run_outbound_span_wrapped(
        library="httpx",
        execute=execute,
        extract_kwargs=dict(kwargs),
        method=method,
        url=u,
    )


async def _instrumented_httpx_async_client_request(self, method: str, url, *args, **kwargs):
    u = str(url)

    async def execute():
        return await _original_async_client_request(self, method, url, *args, **kwargs)

    return await run_outbound_span_wrapped_async(
        library="httpx-async",
        execute=execute,
        extract_kwargs=dict(kwargs),
        method=method,
        url=u,
    )


def enable_httpx_instrumentation(*, sync: bool = True, async_client: bool = True) -> bool:
    """
    Patch ``httpx.Client.request`` and/or ``httpx.AsyncClient.request``.

    Returns False if ``httpx`` is not installed.
    """
    global _original_client_request, _original_async_client_request
    global _sync_patched, _async_patched

    try:
        import httpx
    except ImportError:
        logger.warning(
            "[HTTP Instrumentation] httpx not installed; skipping. "
            "Install with: pip install httpx   or   pip install 'llmops-observability[http]'"
        )
        return False

    if sync and not _sync_patched:
        _original_client_request = httpx.Client.request
        httpx.Client.request = _instrumented_httpx_client_request
        _sync_patched = True
        logger.info("[HTTP Instrumentation] httpx.Client.request patched")

    if async_client and not _async_patched:
        _original_async_client_request = httpx.AsyncClient.request
        httpx.AsyncClient.request = _instrumented_httpx_async_client_request
        _async_patched = True
        logger.info("[HTTP Instrumentation] httpx.AsyncClient.request patched")

    return _sync_patched or _async_patched


def disable_httpx_instrumentation() -> bool:
    """Restore original httpx methods if they were patched."""
    global _sync_patched, _async_patched

    try:
        import httpx
    except ImportError:
        _sync_patched = False
        _async_patched = False
        return True

    if _sync_patched and _original_client_request is not None:
        httpx.Client.request = _original_client_request
        _sync_patched = False
        logger.info("[HTTP Instrumentation] httpx.Client.request restored")

    if _async_patched and _original_async_client_request is not None:
        httpx.AsyncClient.request = _original_async_client_request
        _async_patched = False
        logger.info("[HTTP Instrumentation] httpx.AsyncClient.request restored")

    return True


def is_httpx_instrumentation_enabled() -> bool:
    return _sync_patched or _async_patched
