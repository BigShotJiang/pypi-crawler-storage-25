"""
distributed_tracing.py
======================
New distributed tracing decorators for cross-service trace propagation.

    @track_external_service(service_name, transport)  -- parent side
    @resume_external_service(source)                  -- child side

These add to the existing SDK without changing any current behaviour.
The child segment payload is identical to a normal trace payload with two
extra top-level keys:

    is_child_segment : true
    has_external_segments : false   (child never has nested external calls)

The parent trace payload gets:

    is_child_segment : false
    has_external_segments : true    (signals EKS to fetch + merge child traces)

Both payloads are compressed and sent through the existing send_to_sqs_immediate()
pipeline — no new SQS infrastructure needed.
"""

from __future__ import annotations

import functools
import inspect
import json
import logging
import threading
import time
import uuid
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger(__name__)
logger.propagate = False

# ── Thread-local storage for injected headers ────────────────────────────────
# track_external_service sets these; the user's function body reads them via
# get_injected_headers().
_tl = threading.local()


def get_injected_headers() -> Dict[str, str]:
    """Return the trace-context headers injected by @track_external_service.

    Call this inside the decorated function body to obtain the headers to
    forward to the downstream HTTP call.

        headers = get_injected_headers()
        resp = httpx.get(url, headers=headers)
    """
    return getattr(_tl, "injected_headers", {})


# ── W3C traceparent helper ────────────────────────────────────────────────────
def _make_traceparent(trace_id: str, span_id: str) -> str:
    """Build a W3C traceparent header value.

    Format: 00-<32-hex trace_id>-<16-hex span_id>-01
    """
    tid = trace_id.replace("-", "").lower().ljust(32, "0")[:32]
    sid = span_id.replace("-", "").lower().ljust(16, "0")[:16]
    return f"00-{tid}-{sid}-01"


def _parse_traceparent(value: str) -> Optional[Dict[str, str]]:
    """Parse a W3C traceparent header.  Returns None on failure."""
    try:
        parts = value.strip().split("-")
        if len(parts) < 4:
            return None
        return {"trace_id": parts[1], "parent_span_id": parts[2]}
    except Exception:
        return None


# ── Helpers shared by both decorators ────────────────────────────────────────
def _build_span_dict(
    span_id: str,
    span_name: str,
    span_type: str,
    parent_span_id: Optional[str],
    start_time: float,
    end_time: float,
    input_data: Any = None,
    output_data: Any = None,
    metadata: Optional[Dict[str, Any]] = None,
    status: str = "success",
    error: Optional[str] = None,
) -> Dict[str, Any]:
    duration_ms = round((end_time - start_time) * 1000, 6)
    return {
        "span_id": span_id,
        "span_name": span_name,
        "span_type": span_type,
        "parent_span_id": parent_span_id,
        "start_time": start_time,
        "end_time": end_time,
        "duration_ms": duration_ms,
        "input_data": input_data,
        "output_data": output_data,
        "error": error,
        "model_id": None,
        "metadata": metadata or {},
        "tags": [],
        "usage": None,
        "prompt": None,
        "response": None,
        "status": status,
        "status_message": None,
        "level": "DEFAULT",
    }


def _wall_time_seconds() -> float:
    return time.time_ns() / 1_000_000_000


def _duration_ms_from_perf(start_perf_ns: int, end_perf_ns: Optional[int] = None) -> float:
    stop_perf_ns = end_perf_ns if end_perf_ns is not None else time.perf_counter_ns()
    return round((stop_perf_ns - start_perf_ns) / 1_000_000, 6)


def _normalize_child_span(span: Any) -> Dict[str, Any]:
    """Convert SpanData-like objects to plain dict payload shape."""
    if isinstance(span, dict):
        return span

    # Convert SDK SpanData objects and similar attribute-based spans
    get = lambda name, default=None: getattr(span, name, default)
    return {
        "span_id": get("span_id"),
        "span_name": get("span_name"),
        "span_type": get("span_type"),
        "parent_span_id": get("parent_span_id"),
        "start_time": get("start_time"),
        "end_time": get("end_time"),
        "duration_ms": get("duration_ms"),
        "input_data": get("input_data"),
        "output_data": get("output_data"),
        "error": get("error"),
        "model_id": get("model_id"),
        "metadata": get("metadata", {}) or {},
        "tags": get("tags", []) or [],
        "usage": get("usage"),
        "prompt": get("prompt"),
        "response": get("response"),
        "status": get("status", "success"),
        "status_message": get("status_message"),
        "level": get("level", "DEFAULT"),
    }


def _send_child_segment(
    trace_id: str,
    segment_id: str,
    service_name: str,
    entry_span_id: str,
    parent_span_id: Optional[str],
    spans: list,
    project_id: str,
    environment: str,
    start_time: float,
    end_time: float,
) -> None:
    """Compress and send a child segment to SQS via the existing pipeline."""
    import gzip
    import base64

    from .config import get_sqs_config
    from .sqs import send_to_sqs_immediate, is_sqs_enabled

    if not is_sqs_enabled():
        logger.warning("[DistributedTracing] SQS not enabled – child segment not sent")
        return

    payload: Dict[str, Any] = {
        # Segment identity
        "is_child_segment": True,
        "has_external_segments": False,
        "segment_id": segment_id,
        "service_name": service_name,
        "entry_span_id": entry_span_id,
        "parent_span_id": parent_span_id,
        # Shared trace identity (must match parent trace_id)
        "trace_id": trace_id,
        "trace_name": service_name,
        "project_id": project_id,
        "environment": environment,
        "user_id": None,
        "session_id": None,
        # Timing
        "start_time": start_time,
        "end_time": end_time,
        "duration_ms": round((end_time - start_time) * 1000, 6),
        # Spans
        "spans": [_normalize_child_span(s) for s in spans],
        "total_spans": len(spans),
        "total_generations": 0,
        # Metadata
        "trace_input": None,
        "trace_output": None,
        "metadata": {"segment_role": "downstream_segment"},
        "tags": ["distributed", "child_segment"],
        "sdk_name": "llmops-observability",
        "sdk_version": _sdk_version(),
    }

    logger.info(
        "[SQS_PAYLOAD_CHILD]\n%s",
        json.dumps(payload, indent=2, default=str),
    )

    json_bytes = json.dumps(payload, default=str).encode("utf-8")
    compressed = gzip.compress(json_bytes, compresslevel=9)
    sqs_message = json.dumps({
        "compressed": True,
        "data": base64.b64encode(compressed).decode("utf-8"),
        "trace_id": trace_id,
        "is_child_segment": True,
    })

    send_to_sqs_immediate(sqs_message)
    logger.info(
        "[DistributedTracing] Child segment sent | trace_id=%s segment_id=%s service=%s spans=%d",
        trace_id, segment_id, service_name, len(spans),
    )


def _sdk_version() -> str:
    try:
        from importlib.metadata import version
        return version("llmops-observability")
    except Exception:
        return "0.0.0"


# ─────────────────────────────────────────────────────────────────────────────
# @track_external_service  (parent side)
# ─────────────────────────────────────────────────────────────────────────────

def track_external_service(  # NOSONAR
    service_name: Optional[str] = None,
    transport: Optional[str] = None,
):
    """Decorator for functions that call a downstream service.

    What it does:
    1. Creates a client-side ``external_call`` span on the *active* parent trace.
     2. Auto-detects transport (http/event/queue) when not explicitly provided.
     3. Injects W3C traceparent + custom llmops headers into thread-local storage
       so the user can forward them via ``get_injected_headers()``.
     4. Marks the parent trace as ``has_external_segments=True`` so EKS knows to
       fetch and merge child traces from S3 before forwarding to Langfuse/NR.

    Usage (HTTP)::

        @track_external_service(service_name="user_service", transport="http")
        def get_user_profile(user_id):
            headers = get_injected_headers()   # traceparent + x-llmops-trace-id
            return httpx.get(url, headers=headers).json()

    Usage (event / queue)::

        @track_external_service(service_name="order_service", transport="event")
        def emit_order_event(order_id):
            headers = get_injected_headers()
            event = {"order_id": order_id, "trace_context": headers}
            publish(event)
    """
    def decorator(func: Callable) -> Callable:
        def _should_mark_external_segments(result: Any, status: str) -> bool:
            """Decide whether the parent should expect downstream child segments."""
            if status != "success":
                return False

            if isinstance(result, dict):
                result_status = str(result.get("status", "")).strip().lower()
                if result_status in {"error", "failed", "failure", "timeout", "unreachable"}:
                    return False

            return True

        def _infer_service_name() -> str:
            if service_name:
                return service_name

            # Prefer explicit "*_service" patterns in function names.
            fn = (func.__name__ or "external_service").lower()
            if "_service" in fn:
                idx = fn.find("_service")
                start = fn.rfind("_", 0, idx)
                token = fn[start + 1:idx] if start >= 0 else fn[:idx]
                token = token.strip("_")
                if token:
                    return f"{token}_service"

            # Otherwise infer from verb-noun style names like get_user_profile.
            parts = [p for p in fn.split("_") if p]
            ignored = {"get", "fetch", "call", "invoke", "request", "send", "post", "put", "delete", "update", "create"}
            meaningful = [p for p in parts if p not in ignored]
            if meaningful:
                return f"{meaningful[0]}_service"

            return "external_service"

        def _infer_transport(args: tuple, kwargs: dict) -> str:
            if transport:
                return transport

            # Heuristics for event/queue style calls.
            name = (func.__name__ or "").lower()
            queue_tokens = ("publish", "emit", "event", "queue", "kafka", "sqs", "sns")
            if any(tok in name for tok in queue_tokens):
                return "event"

            # If payload/event shaped inputs are present, treat as event transport.
            if "event" in kwargs or "message" in kwargs or "payload" in kwargs:
                return "event"
            for arg in args:
                if isinstance(arg, dict) and (
                    "trace_context" in arg or "Records" in arg or "Message" in arg
                ):
                    return "event"

            return "http"

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            from .trace_manager import TraceManager, SpanData
            resolved_service_name = _infer_service_name()
            transport_value = _infer_transport(args, kwargs)

            span_id = uuid.uuid4().hex[:16]
            parent_span_id = TraceManager.get_current_parent_span_id()
            trace_id = TraceManager.get_trace_id()
            start_perf_ns = time.perf_counter_ns()
            start_time = _wall_time_seconds()

            # Build and inject trace-context headers
            traceparent = _make_traceparent(trace_id or "0" * 32, span_id)
            headers: Dict[str, str] = {
                "traceparent": traceparent,
                "x-llmops-trace-id": trace_id or "",
                "x-llmops-span-id": span_id,
                "x-llmops-service": resolved_service_name,
            }
            if parent_span_id:
                headers["x-llmops-parent-span-id"] = parent_span_id
            _tl.injected_headers = headers

            # Push external_call span onto the stack so nested spans parent to it
            TraceManager.push_span_context(span_id)

            result = None
            error_msg: Optional[str] = None
            status = "success"
            mark_external_segments = False
            try:
                result = func(*args, **kwargs)
                mark_external_segments = _should_mark_external_segments(result, status)
                return result
            except Exception as exc:
                error_msg = str(exc)
                status = "error"
                raise
            finally:
                if mark_external_segments:
                    TraceManager.mark_has_external_segments()

                end_perf_ns = time.perf_counter_ns()
                end_time = _wall_time_seconds()
                TraceManager.pop_span_context()
                _tl.injected_headers = {}

                from .config import get_project_id, get_environment
                span = SpanData(
                    span_id=span_id,
                    span_name=f"{resolved_service_name}.{func.__name__}",
                    span_type="tool",
                    parent_span_id=parent_span_id,
                    start_time=start_time,
                    end_time=end_time,
                    duration_ms=_duration_ms_from_perf(start_perf_ns, end_perf_ns),
                    input_data=_safe_input(args, kwargs, func),
                    output_data=_safe_output(result),
                    error=error_msg,
                    metadata={
                        "service_name": resolved_service_name,
                        "transport": transport_value,
                        "environment": get_environment(),
                        "project_id": get_project_id(),
                    },
                    status=status,
                )
                TraceManager.add_span(span)
                logger.debug(
                    "[DistributedTracing] tool span | %s.%s %.3fms",
                    resolved_service_name, func.__name__, span.duration_ms,
                )

        return wrapper
    return decorator


# ─────────────────────────────────────────────────────────────────────────────
# @resume_external_service  (child side)
# ─────────────────────────────────────────────────────────────────────────────

def resume_external_service(  # NOSONAR
    source: Optional[str] = None,
    trace_id_override: Optional[str] = None,
    parent_span_id_override: Optional[str] = None,
):
    """Decorator for FastAPI / any framework route handlers that receive a
    distributed trace context from a parent service.

    What it does:
    1. Extracts ``trace_id`` and ``parent_span_id`` from the incoming request
       (headers by default, or from a JSON payload body).
    2. Starts a *child-mode* trace on the TraceManager with the *same* trace_id
       as the parent so spans share one trace in Langfuse.
    3. Creates a server-side ``external_entry`` span parented to the parent's
       ``external_call`` span.
    4. Runs the wrapped function (which may call ``@track_function()`` decorated
       helpers — those spans attach naturally under the entry span).
    5. When the function returns, sends the complete child segment to SQS via
       ``_send_child_segment()``.  EKS routes it to ``child_traces/{trace_id}/``.

        Sources:
        - ``"headers"``  — reads ``traceparent`` / ``x-llmops-*`` request headers.
      Requires the first argument to be a FastAPI ``Request`` object.
    - ``"payload"``  — reads ``event["trace_context"]`` from the first argument.
    - ``"manual"``   — use ``trace_id_override`` / ``parent_span_id_override``.
        - ``None``        — auto-detect source from runtime inputs.

    Usage::

        @app.get("/profile/{user_id}")
        @resume_external_service(source="headers")
        async def get_user_profile(request: Request, user_id: str):
            data = fetch_user_data(user_id)   # @track_function() spans attach here
            return data
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            return await _run_child_trace(func, args, kwargs, True)

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            return _run_child_trace_sync(func, args, kwargs)

        return async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper

    def _infer_source(args, kwargs) -> str:
        if source in {"headers", "payload", "manual"}:
            return source

        # If explicit overrides are provided, treat as manual source.
        if trace_id_override or parent_span_id_override:
            return "manual"

        # FastAPI/Starlette request object in args/kwargs.
        for arg in args:
            if hasattr(arg, "headers"):
                return "headers"
        if hasattr(kwargs.get("request"), "headers"):
            return "headers"

        # Event/message payload style.
        payload = args[0] if args else kwargs.get("event")
        if isinstance(payload, dict):
            if isinstance(payload.get("trace_context"), dict):
                return "payload"

        # Default to headers for web apps.
        return "headers"

    def _extract_context(args, kwargs) -> Dict[str, Optional[str]]:
        """Extract trace context from request headers / payload / overrides."""
        resolved_source = _infer_source(args, kwargs)
        ctx: Dict[str, Optional[str]] = {
            "trace_id": trace_id_override,
            "parent_span_id": parent_span_id_override,
        }

        if resolved_source == "manual":
            return ctx

        if resolved_source == "headers":
            # FastAPI: first arg is Request or it may be in kwargs["request"]
            request = None
            for arg in args:
                if hasattr(arg, "headers"):
                    request = arg
                    break
            if request is None:
                request = kwargs.get("request")

            if request is not None:
                headers = dict(request.headers)
                tp = headers.get("traceparent")
                if tp:
                    parsed = _parse_traceparent(tp)
                    if parsed:
                        ctx["trace_id"] = parsed["trace_id"]
                        ctx["parent_span_id"] = parsed["parent_span_id"]
                # Also accept explicit llmops headers as fallback
                if not ctx["trace_id"]:
                    ctx["trace_id"] = headers.get("x-llmops-trace-id")
                if not ctx["parent_span_id"]:
                    ctx["parent_span_id"] = headers.get("x-llmops-span-id")
                ctx["calling_service"] = headers.get("x-llmops-service")
            return ctx

        if resolved_source == "payload":
            # First positional arg is the event/message dict
            payload = args[0] if args else kwargs.get("event", {})
            if isinstance(payload, dict):
                tc = payload.get("trace_context", {})
                if isinstance(tc, dict):
                    tp = tc.get("traceparent")
                    if tp:
                        parsed = _parse_traceparent(tp)
                        if parsed:
                            ctx["trace_id"] = parsed["trace_id"]
                            ctx["parent_span_id"] = parsed["parent_span_id"]
                    if not ctx["trace_id"]:
                        ctx["trace_id"] = tc.get("x-llmops-trace-id")
                    if not ctx["parent_span_id"]:
                        ctx["parent_span_id"] = tc.get("x-llmops-span-id")
            return ctx

        return ctx

    async def _run_child_trace(func, args, kwargs, is_async):
        from .trace_manager import TraceManager
        from .config import get_project_id, get_environment

        ctx = _extract_context(args, kwargs)
        resolved_source = _infer_source(args, kwargs)
        incoming_trace_id = ctx.get("trace_id")
        incoming_parent_span_id = ctx.get("parent_span_id")

        if not incoming_trace_id:
            logger.warning(
                "[DistributedTracing] @resume_external_service: no trace_id found in %s "
                "– running function without child tracing", resolved_source
            )
            if is_async:
                return await func(*args, **kwargs)
            return func(*args, **kwargs)

        segment_id = uuid.uuid4().hex
        entry_span_id = uuid.uuid4().hex[:16]
        project_id = get_project_id()
        environment = get_environment()

        # Use the service name declared by the caller (sent in x-llmops-service header)
        # so the child identifies as e.g. "user_service", not the Python module name.
        child_service_name = ctx.get("calling_service") or func.__module__.split(".")[-1]

        # Start a child-mode trace (reuses existing trace_id)
        TraceManager.start_child_trace(
            trace_id=incoming_trace_id,
            entry_span_id=entry_span_id,
            service_name=child_service_name,
        )
        TraceManager.push_span_context(entry_span_id)

        start_time = _wall_time_seconds()
        result = None
        error_msg: Optional[str] = None
        status = "success"

        try:
            if is_async:
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)
            return result
        except Exception as exc:
            error_msg = str(exc)
            status = "error"
            raise
        finally:
            end_time = _wall_time_seconds()
            TraceManager.pop_span_context()

            # Collect all spans gathered during this child trace
            child_spans = TraceManager.collect_child_spans()
            child_spans = [_normalize_child_span(s) for s in child_spans]

            # Build the server-side entry span (first in the list)
            entry_span = _build_span_dict(
                span_id=entry_span_id,
                span_name=f"{func.__module__}.{func.__name__}",
                span_type="external_entry",
                parent_span_id=incoming_parent_span_id,
                start_time=start_time,
                end_time=end_time,
                input_data=_safe_input(args, kwargs, func),
                output_data=_safe_output(result),
                metadata={
                    "service_name": func.__module__,
                    "source": resolved_source,
                    "environment": environment,
                    "project_id": project_id,
                },
                status=status,
                error=error_msg,
            )

            all_spans = [entry_span] + child_spans

            # Send child segment to SQS
            _send_child_segment(
                trace_id=incoming_trace_id,
                segment_id=segment_id,
                service_name=func.__module__,
                entry_span_id=entry_span_id,
                parent_span_id=incoming_parent_span_id,
                spans=all_spans,
                project_id=project_id,
                environment=environment,
                start_time=start_time,
                end_time=end_time,
            )

            # End the child trace to release it
            TraceManager.end_child_trace()

    def _run_child_trace_sync(func, args, kwargs):
        """Sync version of _run_child_trace."""
        import asyncio
        # For sync functions, run the same logic without await
        from .trace_manager import TraceManager
        from .config import get_project_id, get_environment

        ctx = _extract_context(args, kwargs)
        resolved_source = _infer_source(args, kwargs)
        incoming_trace_id = ctx.get("trace_id")
        incoming_parent_span_id = ctx.get("parent_span_id")

        if not incoming_trace_id:
            logger.warning(
                "[DistributedTracing] @resume_external_service: no trace_id found in %s "
                "– running function without child tracing", resolved_source
            )
            return func(*args, **kwargs)

        segment_id = uuid.uuid4().hex
        entry_span_id = uuid.uuid4().hex[:16]
        project_id = get_project_id()
        environment = get_environment()

        TraceManager.start_child_trace(
            trace_id=incoming_trace_id,
            entry_span_id=entry_span_id,
            service_name=func.__module__,
        )
        TraceManager.push_span_context(entry_span_id)

        start_time = _wall_time_seconds()
        result = None
        error_msg: Optional[str] = None
        status = "success"

        try:
            result = func(*args, **kwargs)
            return result
        except Exception as exc:
            error_msg = str(exc)
            status = "error"
            raise
        finally:
            end_time = _wall_time_seconds()
            TraceManager.pop_span_context()
            child_spans = TraceManager.collect_child_spans()
            child_spans = [_normalize_child_span(s) for s in child_spans]

            entry_span = _build_span_dict(
                span_id=entry_span_id,
                span_name=f"{func.__module__}.{func.__name__}",
                span_type="external_entry",
                parent_span_id=incoming_parent_span_id,
                start_time=start_time,
                end_time=end_time,
                input_data=_safe_input(args, kwargs, func),
                output_data=_safe_output(result),
                metadata={
                    "service_name": func.__module__,
                    "source": resolved_source,
                    "environment": environment,
                    "project_id": project_id,
                },
                status=status,
                error=error_msg,
            )

            all_spans = [entry_span] + child_spans

            _send_child_segment(
                trace_id=incoming_trace_id,
                segment_id=segment_id,
                service_name=func.__module__,
                entry_span_id=entry_span_id,
                parent_span_id=incoming_parent_span_id,
                spans=all_spans,
                project_id=project_id,
                environment=environment,
                start_time=start_time,
                end_time=end_time,
            )
            TraceManager.end_child_trace()

    return decorator


# ── Internal helpers ──────────────────────────────────────────────────────────
def _safe_input(args, kwargs, func) -> Any:
    try:
        import inspect as _inspect
        sig = _inspect.signature(func)
        params = list(sig.parameters.keys())
        # Skip 'self', 'cls', 'request' (FastAPI request objects)
        skip = {"self", "cls", "request"}
        bound: Dict[str, Any] = {}
        positional_params = [p for p in params if p not in skip]
        positional_args = [
            a for a in args
            if not (hasattr(a, "headers"))  # skip Request objects
        ]
        for i, arg in enumerate(positional_args):
            if i < len(positional_params):
                bound[positional_params[i]] = str(arg)
        for k, v in kwargs.items():
            if k not in skip:
                bound[k] = str(v)
        return bound if bound else None
    except Exception:
        return None


def _safe_output(result: Any) -> Any:
    try:
        if result is None:
            return None
        if isinstance(result, (str, int, float, bool)):
            return result
        return json.loads(json.dumps(result, default=str))
    except Exception:
        return str(result)
