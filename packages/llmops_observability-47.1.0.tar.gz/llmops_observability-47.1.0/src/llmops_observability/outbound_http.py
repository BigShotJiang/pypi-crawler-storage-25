"""
Outbound HTTP instrumentation for external API telemetry.

Provides opt-in monkeypatch instrumentation for ``requests`` (sync) and re-exports
facade helpers that also enable ``httpx`` (sync + async) and ``urllib`` (sync).

For FastAPI / Starlette: use :class:`llmops_observability.asgi_middleware.LLMOpsASGIMiddleware`
for **inbound** requests; enable outbound instrumentation below for **client** calls
inside handlers (``httpx``, ``requests``, etc.).
"""
from __future__ import annotations

import logging

import requests

from .outbound_http_core import run_outbound_span_wrapped
from .outbound_httpx import (
    disable_httpx_instrumentation as _disable_httpx,
    enable_httpx_instrumentation as _enable_httpx,
    is_httpx_instrumentation_enabled,
)
from .outbound_urllib import (
    disable_urllib_instrumentation as _disable_urllib,
    enable_urllib_instrumentation as _enable_urllib,
    is_urllib_instrumentation_enabled,
)

logger = logging.getLogger(__name__)

_instrumentation_enabled = False
_original_session_request = None


def _instrumented_session_request(self, method, url, *args, **kwargs):
    if not _instrumentation_enabled:
        return _original_session_request(self, method, url, *args, **kwargs)

    def execute():
        return _original_session_request(self, method, url, *args, **kwargs)

    return run_outbound_span_wrapped(
        library="requests",
        execute=execute,
        extract_kwargs=dict(kwargs),
        method=method,
        url=str(url),
    )


def enable_requests_instrumentation() -> bool:
    """Enable outbound instrumentation for ``requests.Session.request``."""
    global _instrumentation_enabled, _original_session_request
    if _instrumentation_enabled:
        return True

    if _original_session_request is None:
        _original_session_request = requests.sessions.Session.request
    requests.sessions.Session.request = _instrumented_session_request
    _instrumentation_enabled = True
    logger.info("[HTTP Instrumentation] requests instrumentation enabled")
    return True


def disable_requests_instrumentation() -> bool:
    """Disable outbound instrumentation and restore original ``requests`` method."""
    global _instrumentation_enabled, _original_session_request
    if not _instrumentation_enabled:
        return True
    if _original_session_request is not None:
        requests.sessions.Session.request = _original_session_request
    _instrumentation_enabled = False
    logger.info("[HTTP Instrumentation] requests instrumentation disabled")
    return True


def is_requests_instrumentation_enabled() -> bool:
    return _instrumentation_enabled


def enable_outbound_http_instrumentation(
    *,
    requests_lib: bool = True,
    httpx_lib: bool = True,
    urllib_lib: bool = True,
    httpx_sync: bool = True,
    httpx_async: bool = True,
) -> dict[str, bool]:
    """
    Enable all available outbound HTTP client instrumentations.

    Parameters
    ----------
    requests_lib
        Patch ``requests.Session.request``.
    httpx_lib
        Patch ``httpx`` if installed (see optional extra ``llmops-observability[http]``).
    urllib_lib
        Patch ``urllib.request.urlopen``.
    httpx_sync
        When ``httpx`` is enabled, patch synchronous ``httpx.Client.request``.
    httpx_async
        When ``httpx`` is enabled, patch asynchronous ``httpx.AsyncClient.request``.

    Returns
    -------
    dict
        Which backends reported success (``httpx`` false if import failed).
    """
    out: dict[str, bool] = {}
    if requests_lib:
        out["requests"] = enable_requests_instrumentation()
    if httpx_lib:
        out["httpx"] = _enable_httpx(sync=httpx_sync, async_client=httpx_async)
    if urllib_lib:
        out["urllib"] = _enable_urllib()
    return out


def disable_outbound_http_instrumentation() -> None:
    """Disable every outbound HTTP instrumentation this package installed."""
    disable_requests_instrumentation()
    _disable_httpx()
    _disable_urllib()


def outbound_instrumentation_status() -> dict[str, bool]:
    """Return enable flags for each backend."""
    return {
        "requests": is_requests_instrumentation_enabled(),
        "httpx": is_httpx_instrumentation_enabled(),
        "urllib": is_urllib_instrumentation_enabled(),
    }
