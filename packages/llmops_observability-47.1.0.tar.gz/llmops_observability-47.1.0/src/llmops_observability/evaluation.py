"""
Response evaluation telemetry — record score, label, and rationale on the active trace.
"""
from __future__ import annotations

import logging
import time
import uuid
from typing import Any, Dict, Optional, Union

from .redaction import DEFAULT_SENSITIVE_KEYS, redact_deep
from .trace_manager import SpanData, TraceManager, ensure_json_object

logger = logging.getLogger(__name__)

EVALUATION_SPAN_TYPE = "evaluation"


def record_evaluation(
    *,
    score: Optional[Union[float, int]] = None,
    label: Optional[str] = None,
    rationale: Optional[str] = None,
    name: str = "evaluation",
    evaluated_span_id: Optional[str] = None,
    parent_span_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    """
    Record a response evaluation as a child span on the current trace.

    Uses the span context stack: the evaluation's parent defaults to
    ``TraceManager.get_current_parent_span_id()`` so it nests under the
    innermost active span (e.g. a generation). Pass ``parent_span_id`` to
    override, or set ``evaluated_span_id`` to reference which span was scored
    (correlation only; does not change parent linkage).

    Returns the new evaluation span id, or ``None`` if there is no trace to
    attach to (and nothing was recorded).
    """
    if not TraceManager.can_track_span():
        logger.debug("record_evaluation skipped: no active or finalized trace")
        return None

    span_id = uuid.uuid4().hex
    parent = parent_span_id if parent_span_id is not None else TraceManager.get_current_parent_span_id()
    now = time.time()

    merged_meta: Dict[str, Any] = {
        "evaluation.kind": "response",
    }
    if metadata:
        merged_meta.update(redact_deep(metadata, DEFAULT_SENSITIVE_KEYS))

    payload: Dict[str, Any] = {
        "score": score,
        "label": label,
        "rationale": rationale,
        "evaluated_span_id": evaluated_span_id,
    }
    payload = {k: v for k, v in payload.items() if v is not None}

    span = SpanData(
        span_id=span_id,
        span_name=name,
        span_type=EVALUATION_SPAN_TYPE,
        parent_span_id=parent,
        start_time=now,
        end_time=now,
        duration_ms=0,
        input_data=ensure_json_object({"evaluation": payload}),
        output_data=ensure_json_object({}),
        error=None,
        metadata=merged_meta,
        tags=["evaluation"],
        status="success",
        status_message=None,
    )
    TraceManager.add_span(span)
    return span_id
