"""
ASGI Middleware for FastAPI/Starlette Applications
Automatically traces all HTTP requests with full observability.
"""
import uuid
import time
import os
import socket
from typing import Optional, Dict, Any, Tuple

from .trace_manager import TraceManager

HTTP_METHOD_KEY = "http.method"
HTTP_PATH_KEY = "http.path"
HTTP_QUERY_STRING_KEY = "http.query_string"


class LLMOpsASGIMiddleware:
    """
    ASGI middleware for automatic HTTP request tracing.
    
    Captures:
    - Request method, path, headers
    - User and session identifiers
    - Response body and status
    - Request latency
    - Automatic trace lifecycle management
    
    Usage:
        from fastapi import FastAPI
        from llmops_observability import LLMOpsASGIMiddleware
        
        app = FastAPI()
        app.add_middleware(LLMOpsASGIMiddleware, service_name="my_api")
    """

    def __init__(self, app, service_name: Optional[str] = None):
        """
        Initialize ASGI middleware.
        
        Args:
            app: ASGI application instance
            service_name: Custom service name for traces. 
                         If None, uses "{project}_{hostname}" format.
        """
        self.app = app
        self.service_name = service_name

    def get_trace_name(self, path: Optional[str] = None) -> str:
        """
        Generate trace name from request path.

        The path (stripped of its leading ``/``) is used as the trace name so
        that, for example, ``POST /generate`` produces ``"generate"`` and
        ``POST /generate/v2`` produces ``"generate/v2"``.

        When no path is provided (legacy / non-HTTP usage) the name falls back
        to the configured ``service_name`` or ``"{project}_{hostname}"``.

        Returns:
            Trace name derived from the request path, or a fallback name.
        """
        if path and path != "/":
            return path.lstrip("/")

        if self.service_name:
            return self.service_name

        project = os.path.basename(os.getcwd())
        hostname = socket.gethostname()
        return f"{project}_{hostname}"

    @staticmethod
    def _build_trace_input(method: str, path: str, query_string: str) -> Dict[str, Any]:
        return {
            HTTP_METHOD_KEY: method,
            HTTP_PATH_KEY: path,
            HTTP_QUERY_STRING_KEY: query_string,
        }

    @staticmethod
    def _decode_response_body(body: Any) -> Optional[str]:
        if not body:
            return None
        try:
            return body.decode("utf-8")
        except UnicodeDecodeError:
            return f"<binary data: {len(body)} bytes>"

    def _finalize_error(
        self,
        *,
        user_id: str,
        session_id: str,
        trace_name: str,
        trace_input: Dict[str, Any],
        start_time: float,
        exc: Exception,
    ) -> None:
        latency_ms = int((time.time() - start_time) * 1000)
        TraceManager.finalize_and_send(
            user_id=user_id,
            session_id=session_id,
            trace_name=trace_name,
            trace_input=trace_input,
            trace_output={
                "error": str(exc),
                "error_type": type(exc).__name__,
                "http.status_code": 500,
                "http.latency_ms": latency_ms,
            },
        )

    def _finalize_success(
        self,
        *,
        user_id: str,
        session_id: str,
        trace_name: str,
        trace_input: Dict[str, Any],
        start_time: float,
        response_status: Optional[int],
        response_body: Optional[str],
    ) -> None:
        latency_ms = int((time.time() - start_time) * 1000)
        TraceManager.finalize_and_send(
            user_id=user_id,
            session_id=session_id,
            trace_name=trace_name,
            trace_input=trace_input,
            trace_output={
                "http.status_code": response_status or 200,
                "http.latency_ms": latency_ms,
                "response_body": response_body,
            },
        )

    def _extract_request_context(self, scope: Dict[str, Any]) -> Tuple[str, str, str, str, str, str]:
        method = scope.get("method", "UNKNOWN")
        path = scope.get("path", "UNKNOWN")
        query_string = scope.get("query_string", b"").decode()

        headers = {k.decode(): v.decode() for k, v in scope.get("headers", [])}

        user_id = headers.get("x-user-id", "anonymous")
        session_id = headers.get("x-session-id", str(uuid.uuid4()))
        user_agent = headers.get("user-agent", "unknown")
        client = scope.get("client")
        client_ip = client[0] if client else "unknown"

        trace_name = self.get_trace_name(path)
        TraceManager.start_trace(
            trace_name,
            user_id=user_id,
            session_id=session_id,
            metadata={
                HTTP_METHOD_KEY: method,
                HTTP_PATH_KEY: path,
                HTTP_QUERY_STRING_KEY: query_string,
                "http.user_agent": user_agent,
                "http.client_ip": client_ip,
                "service.name": self.service_name or trace_name,
            },
        )
        return method, path, query_string, user_id, session_id, trace_name

    async def __call__(self, scope, receive, send):
        """
        ASGI middleware entry point.
        
        Args:
            scope: ASGI connection scope
            receive: ASGI receive channel
            send: ASGI send channel
        """
        # Only trace HTTP requests (not WebSocket, lifespan, etc.)
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        # Skip middleware tracing for inbound distributed-trace requests.
        # @resume_external_service handles those — the middleware would create
        # a redundant (empty) envelope that gets suppressed anyway.
        headers = {k.decode(): v.decode() for k, v in scope.get("headers", [])}
        if headers.get("traceparent") or headers.get("x-llmops-trace-id"):
            await self.app(scope, receive, send)
            return

        method, path, query_string, user_id, session_id, trace_name = self._extract_request_context(scope)
        trace_input = self._build_trace_input(method, path, query_string)

        start_time = time.time()
        response_status = None
        response_body = None
        
        async def send_wrapper(message):
            """Intercept response to capture status and body."""
            nonlocal response_status, response_body
            
            # Capture status code
            if message["type"] == "http.response.start":
                response_status = message.get("status", 500)
            
            # Capture response body
            if message["type"] == "http.response.body":
                response_body = self._decode_response_body(message.get("body"))
            
            await send(message)

        try:
            # Execute the application
            await self.app(scope, receive, send_wrapper)
            
        except Exception as exc:
            # Capture exception and finalize trace with error
            self._finalize_error(
                user_id=user_id,
                session_id=session_id,
                trace_name=trace_name,
                trace_input=trace_input,
                start_time=start_time,
                exc=exc,
            )
            raise
        
        # Normal completion - finalize trace with response data
        self._finalize_success(
            user_id=user_id,
            session_id=session_id,
            trace_name=trace_name,
            trace_input=trace_input,
            start_time=start_time,
            response_status=response_status,
            response_body=response_body,
        )
