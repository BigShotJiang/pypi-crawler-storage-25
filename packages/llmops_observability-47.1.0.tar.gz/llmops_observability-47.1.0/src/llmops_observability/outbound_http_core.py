"""
Shared outbound HTTP span building for requests, httpx, urllib, and similar clients.

Keeps one consistent metadata shape (`method`, `url`, `latency_ms`, redaction, etc.)
regardless of which library performed the call.
"""
from __future__ import annotations

import json
import logging
import time
import uuid
from typing import Any, Dict, Optional, Tuple
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from .redaction import DEFAULT_SENSITIVE_KEYS, REDACTED_VALUE, redact_deep, redact_key_values
from .trace_manager import SpanData, TraceManager, ensure_json_object

logger = logging.getLogger(__name__)

_PREVIEW_LIMIT = 512


def normalize_headers(headers: Any) -> Dict[str, Any]:
    if headers is None:
        return {}
    if isinstance(headers, dict):
        return dict(headers)
    try:
        # httpx.Headers, werkzeug headers, etc.
        return dict(headers)
    except Exception:
        return {}


def redact_url(url: str) -> str:
    try:
        parsed = urlparse(url)
        query_items = parse_qsl(parsed.query, keep_blank_values=True)
        redacted_query = []
        for key, value in query_items:
            normalized = key.strip().lower()
            redacted_query.append((key, REDACTED_VALUE if normalized in DEFAULT_SENSITIVE_KEYS else value))
        safe_query = urlencode(redacted_query, doseq=True)
        return urlunparse(
            (parsed.scheme, parsed.netloc, parsed.path, parsed.params, safe_query, parsed.fragment)
        )
    except Exception:
        return url


def payload_summary(payload: Any) -> Dict[str, Any]:
    if payload is None:
        return {"present": False}
    safe_payload = redact_deep(payload)
    try:
        if isinstance(safe_payload, (dict, list, tuple)):
            as_str = json.dumps(safe_payload, default=str)
        else:
            as_str = str(safe_payload)
    except Exception:
        as_str = "<unprintable>"
    size_bytes = len(as_str.encode("utf-8", errors="replace"))
    preview = as_str[:_PREVIEW_LIMIT]
    if len(as_str) > _PREVIEW_LIMIT:
        preview += "..."
    return {
        "present": True,
        "size_bytes": size_bytes,
        "preview": preview,
        "truncated": len(as_str) > _PREVIEW_LIMIT,
    }


def build_span_name(method: str, url: str) -> str:
    parsed = urlparse(url)
    host = parsed.netloc or "unknown-host"
    path = parsed.path or "/"
    return f"http.{method.lower()} {host}{path}"


def extract_requests_style_request(
    method: str,
    url: str,
    kwargs: Dict[str, Any],
) -> Tuple[str, str, Dict[str, Any], Any]:
    """Parse method/url/headers/body from typical requests/httpx-style kwargs."""
    req_method = str(method).upper()
    req_url = str(url)
    headers = normalize_headers(kwargs.get("headers"))
    payload = kwargs.get("json")
    if payload is None:
        payload = kwargs.get("data")
    return req_method, req_url, headers, payload


def compose_outbound_http_span(
    *,
    req_method: str,
    req_url: str,
    req_headers: Dict[str, Any],
    req_payload: Any,
    timeout: Any,
    start_time: float,
    end_time: float,
    response: Any,
    error: Optional[BaseException],
    span_id: str,
    parent_span_id: Optional[str],
    library: str,
    call_mode: str,
) -> SpanData:
    """Build a completed client span for an outbound HTTP call."""
    duration_ms = int((end_time - start_time) * 1000)
    safe_url = redact_url(req_url)
    safe_headers = redact_key_values(req_headers)
    req_payload_summary = payload_summary(req_payload)

    response_status = getattr(response, "status_code", None)
    response_headers = normalize_headers(getattr(response, "headers", {})) if response is not None else {}
    response_size = response_headers.get("Content-Length")

    metadata: Dict[str, Any] = {
        "method": req_method,
        "url": safe_url,
        "status_code": response_status,
        "latency_ms": duration_ms,
        "error": str(error) if error else None,
        "request_headers": safe_headers,
        "request_payload": req_payload_summary,
        "response_headers": response_headers,
        "response_size": response_size,
        "timeout": timeout,
        "http.method": req_method,
        "http.url": safe_url,
        "http.status_code": response_status,
        "http.latency_ms": duration_ms,
        "http.request.headers": safe_headers,
        "http.request.payload": req_payload_summary,
        "http.response.headers": response_headers,
        "http.response.size": response_size,
        "http.timeout": timeout,
        "span.kind": "client",
        "outbound_http": True,
        "http.client.library": library,
        "http.call_mode": call_mode,
    }

    return SpanData(
        span_id=span_id,
        span_name=build_span_name(req_method, req_url),
        span_type="span",
        parent_span_id=parent_span_id,
        start_time=start_time,
        end_time=end_time,
        duration_ms=duration_ms,
        input_data=ensure_json_object(
            {
                "method": req_method,
                "url": safe_url,
                "headers": safe_headers,
                "payload": req_payload_summary,
            },
            key="request",
        ),
        output_data=ensure_json_object(
            {
                "status_code": response_status,
                "headers": response_headers,
                "size": response_size,
            },
            key="response",
        ),
        error=str(error) if error else None,
        metadata=metadata,
        status="error" if error else "success",
        status_message=str(error) if error else None,
    )


def run_outbound_span_wrapped(
    *,
    library: str,
    execute,
    extract_kwargs: Dict[str, Any],
    method: str,
    url: str,
    call_mode: str = "sync",
) -> Any:
    """
    Execute a callable (sync) inside outbound span lifecycle (push, record, pop).
    """
    if not TraceManager.can_track_span():
        return execute()

    pending_added = TraceManager._increment_pending_if_active()
    span_id = uuid.uuid4().hex
    parent_span_id = TraceManager.get_current_parent_span_id()
    TraceManager.push_span_context(span_id)
    start_time = time.time()
    response = None
    error = None
    try:
        response = execute()
        return response
    except BaseException as exc:
        error = exc
        raise
    finally:
        end_time = time.time()
        TraceManager.pop_span_context()
        req_method, req_url, req_headers, req_payload = extract_requests_style_request(
            method, url, extract_kwargs
        )
        span = compose_outbound_http_span(
            req_method=req_method,
            req_url=req_url,
            req_headers=req_headers,
            req_payload=req_payload,
            timeout=extract_kwargs.get("timeout"),
            start_time=start_time,
            end_time=end_time,
            response=response,
            error=error,
            span_id=span_id,
            parent_span_id=parent_span_id,
            library=library,
            call_mode=call_mode,
        )
        TraceManager.add_span(span)
        if pending_added:
            TraceManager._decrement_pending()


async def run_outbound_span_wrapped_async(
    *,
    library: str,
    execute,
    extract_kwargs: Dict[str, Any],
    method: str,
    url: str,
    call_mode: str = "async",
) -> Any:
    """Execute an async callable inside outbound span lifecycle."""
    if not TraceManager.can_track_span():
        return await execute()

    pending_added = TraceManager._increment_pending_if_active()
    span_id = uuid.uuid4().hex
    parent_span_id = TraceManager.get_current_parent_span_id()
    TraceManager.push_span_context(span_id)
    start_time = time.time()
    response = None
    error = None
    try:
        response = await execute()
        return response
    except BaseException as exc:
        error = exc
        raise
    finally:
        end_time = time.time()
        TraceManager.pop_span_context()
        req_method, req_url, req_headers, req_payload = extract_requests_style_request(
            method, url, extract_kwargs
        )
        span = compose_outbound_http_span(
            req_method=req_method,
            req_url=req_url,
            req_headers=req_headers,
            req_payload=req_payload,
            timeout=extract_kwargs.get("timeout"),
            start_time=start_time,
            end_time=end_time,
            response=response,
            error=error,
            span_id=span_id,
            parent_span_id=parent_span_id,
            library=library,
            call_mode=call_mode,
        )
        TraceManager.add_span(span)
        if pending_added:
            TraceManager._decrement_pending()
