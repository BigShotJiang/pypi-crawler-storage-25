"""
LLMOps Observability SDK - Public API
Minimal SDK focused on:
- Trace collection via decorators (@track_function, @track_llm_call)
- Single-message SQS dispatch with compression
- ASGI middleware for FastAPI/Starlette auto-tracing
- Automatic Bedrock model_id capture (optional)
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("llmops-observability")
except PackageNotFoundError:
    __version__ = "0.0.0"

# Core components
from .trace_manager import TraceManager, track_function
from .llm import track_llm_call
from .distributed_tracing import track_external_service, resume_external_service, get_injected_headers
from .sqs import send_to_sqs, send_to_sqs_immediate, flush_sqs, is_sqs_enabled
from .asgi_middleware import LLMOpsASGIMiddleware
from .outbound_http import (
    disable_outbound_http_instrumentation,
    enable_outbound_http_instrumentation,
    enable_requests_instrumentation,
    disable_requests_instrumentation,
    is_requests_instrumentation_enabled,
    outbound_instrumentation_status,
)
from .outbound_httpx import (
    disable_httpx_instrumentation,
    enable_httpx_instrumentation,
    is_httpx_instrumentation_enabled,
)
from .outbound_urllib import (
    disable_urllib_instrumentation,
    enable_urllib_instrumentation,
    is_urllib_instrumentation_enabled,
)
from .evaluation import EVALUATION_SPAN_TYPE, record_evaluation
from .crawl import (
    CRAWL_PAGE_SPAN_TYPE,
    CRAWL_SESSION_SPAN_TYPE,
    crawl_session,
    end_crawl_session,
    record_crawl_page,
    start_crawl_session,
)

# Bedrock auto-instrumentation (optional - requires boto3)
try:
    from .bedrock_instrumentation import (
        enable_bedrock_instrumentation,
        disable_bedrock_instrumentation,
        is_instrumentation_enabled,
    )
    BEDROCK_INSTRUMENTATION_AVAILABLE = True
except ImportError:
    BEDROCK_INSTRUMENTATION_AVAILABLE = False
    enable_bedrock_instrumentation = None
    disable_bedrock_instrumentation = None
    is_instrumentation_enabled = None

__all__ = [
    "TraceManager",
    "track_function",
    "track_llm_call",
    "track_external_service",
    "resume_external_service",
    "get_injected_headers",
    "send_to_sqs",
    "send_to_sqs_immediate",
    "flush_sqs",
    "is_sqs_enabled",
    "LLMOpsASGIMiddleware",
    "enable_outbound_http_instrumentation",
    "disable_outbound_http_instrumentation",
    "outbound_instrumentation_status",
    "enable_requests_instrumentation",
    "disable_requests_instrumentation",
    "is_requests_instrumentation_enabled",
    "enable_httpx_instrumentation",
    "disable_httpx_instrumentation",
    "is_httpx_instrumentation_enabled",
    "enable_urllib_instrumentation",
    "disable_urllib_instrumentation",
    "is_urllib_instrumentation_enabled",
    "EVALUATION_SPAN_TYPE",
    "record_evaluation",
    "CRAWL_SESSION_SPAN_TYPE",
    "CRAWL_PAGE_SPAN_TYPE",
    "crawl_session",
    "start_crawl_session",
    "record_crawl_page",
    "end_crawl_session",
    "enable_bedrock_instrumentation",
    "disable_bedrock_instrumentation",
    "is_instrumentation_enabled",
    "__version__",
]
