"""
Shared redaction helpers for telemetry payloads.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable


REDACTED_VALUE = "[REDACTED]"

DEFAULT_SENSITIVE_KEYS = {
    "authorization",
    "proxy-authorization",
    "x-api-key",
    "api-key",
    "api_key",
    "apikey",
    "token",
    "access_token",
    "refresh_token",
    "password",
    "passwd",
    "secret",
    "client_secret",
}


def redact_key_values(values: Dict[str, Any], sensitive_keys: Iterable[str] = DEFAULT_SENSITIVE_KEYS) -> Dict[str, Any]:
    sensitive = {str(k).strip().lower() for k in sensitive_keys}
    out: Dict[str, Any] = {}
    for key, value in values.items():
        normalized = str(key).strip().lower()
        out[str(key)] = REDACTED_VALUE if normalized in sensitive else value
    return out


def redact_deep(value: Any, sensitive_keys: Iterable[str] = DEFAULT_SENSITIVE_KEYS) -> Any:
    sensitive = {str(k).strip().lower() for k in sensitive_keys}
    if isinstance(value, dict):
        redacted: Dict[str, Any] = {}
        for key, val in value.items():
            normalized = str(key).strip().lower()
            if normalized in sensitive:
                redacted[str(key)] = REDACTED_VALUE
            else:
                redacted[str(key)] = redact_deep(val, sensitive)
        return redacted
    if isinstance(value, list):
        return [redact_deep(item, sensitive) for item in value]
    if isinstance(value, tuple):
        return tuple(redact_deep(item, sensitive) for item in value)
    return value

