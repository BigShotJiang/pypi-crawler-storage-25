"""
Bedrock Auto-Instrumentation - Automatically capture model_id, prompts, and responses
Uses wrapt to patch botocore at the lowest level for automatic tracking
"""
import json
import io
import logging
import wrapt
from typing import Optional, Dict, Any
from contextvars import ContextVar
from botocore.response import StreamingBody

logger = logging.getLogger(__name__)

# Context variable to store captured model data for the current call
_bedrock_call_context: ContextVar[Optional[Dict[str, Any]]] = ContextVar('bedrock_call_context', default=None)

# Global flag to track if instrumentation is enabled
_instrumentation_enabled = False


def _serialize_bedrock_body(body: Any) -> Optional[Dict[str, Any]]:
    """
    Serialize Bedrock request body to JSON-safe dict format.
    Handles dict, string (JSON), and bytes formats.
    
    Args:
        body: Request body in any format (dict, string, bytes)
    
    Returns:
        Parsed dict or None if conversion fails
    """
    if body is None:
        return None
    
    if isinstance(body, dict):
        # Already a dict, return as-is
        return body
    
    if isinstance(body, str):
        # JSON string, parse it
        try:
            return json.loads(body)
        except Exception as e:
            logger.debug(f"Failed to parse request body string: {e}")
            return None
    
    if isinstance(body, bytes):
        # Bytes, decode and parse
        try:
            decoded = body.decode('utf-8')
            return json.loads(decoded)
        except Exception as e:
            logger.debug(f"Failed to decode/parse request body bytes: {e}")
            return None
    
    return None


def _extract_invoke_model_inference_config(payload: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """
    Extract common inference parameters from InvokeModel payloads.
    Handles different model-specific schemas (e.g., parameters/textGenerationConfig).
    """
    if not isinstance(payload, dict):
        return None

    config: Dict[str, Any] = {}

    # Common nested config containers used by Bedrock models
    for key in (
        "inferenceConfig",
        "inference_config",
        "textGenerationConfig",
        "text_generation_config",
        "generationConfig",
        "generation_config",
        "parameters",
        "modelParameters",
        "model_parameters",
    ):
        value = payload.get(key)
        if isinstance(value, dict):
            config.update(value)

    # Common top-level inference parameters
    for key in (
        "temperature",
        "top_p",
        "topP",
        "top_k",
        "topK",
        "max_gen_len",
        "maxGenLen",
        "max_tokens",
        "maxTokens",
        "max_new_tokens",
        "maxNewTokens",
        "min_tokens",
        "minTokens",
        "stop",
        "stop_sequences",
        "stopSequences",
        "presence_penalty",
        "frequency_penalty",
        "repetition_penalty",
        "length_penalty",
        "seed",
    ):
        if key in payload:
            config[key] = payload[key]

    return config or None


def get_captured_model_data() -> Optional[Dict[str, Any]]:
    """
    Get the auto-captured model data from the current context.
    
    Returns:
        Dict with 'model_id', 'request_body', 'response_body' or None
    """
    return _bedrock_call_context.get()


def clear_captured_model_data():
    """Clear the captured model data from context."""
    _bedrock_call_context.set(None)


def _is_trackable_bedrock_call(instance: Any, operation_name: Optional[str]) -> bool:
    if not _instrumentation_enabled:
        return False
    if instance.meta.service_model.service_name != "bedrock-runtime":
        return False
    return operation_name in ("InvokeModel", "Converse", "ConverseStream")


def _extract_request_data(operation_name: str, args: Any, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    params = kwargs.get("api_params", args[1] if len(args) > 1 else {})
    model_id = params.get("modelId")
    request_payload = _serialize_bedrock_body(params.get("body"))
    inference_config = params.get("inferenceConfig") or params.get("inference_config")
    additional_model_request_fields = (
        params.get("additionalModelRequestFields") or params.get("additional_model_request_fields")
    )
    invoke_model_inference_config = _resolve_invoke_model_inference_config(operation_name, request_payload)
    inference_config, additional_model_request_fields = _resolve_inference_fields(
        request_payload=request_payload,
        inference_config=inference_config,
        additional_model_request_fields=additional_model_request_fields,
        invoke_model_inference_config=invoke_model_inference_config,
    )

    return {
        "params": params,
        "model_id": model_id,
        "request_payload": request_payload,
        "inference_config": inference_config,
        "additional_model_request_fields": additional_model_request_fields,
        "invoke_model_inference_config": invoke_model_inference_config,
        "messages": params.get("messages"),
        "system_prompts": params.get("system"),
    }


def _resolve_invoke_model_inference_config(operation_name: str, request_payload: Any) -> Optional[Dict[str, Any]]:
    if operation_name != "InvokeModel" or not isinstance(request_payload, dict):
        return None
    return _extract_invoke_model_inference_config(request_payload)


def _resolve_inference_fields(
    *,
    request_payload: Any,
    inference_config: Any,
    additional_model_request_fields: Any,
    invoke_model_inference_config: Optional[Dict[str, Any]],
) -> Any:
    if not isinstance(request_payload, dict):
        return inference_config, additional_model_request_fields
    if inference_config is None:
        inference_config = request_payload.get("inferenceConfig") or request_payload.get("inference_config")
    if additional_model_request_fields is None:
        additional_model_request_fields = (
            request_payload.get("additionalModelRequestFields")
            or request_payload.get("additional_model_request_fields")
        )
    if inference_config is None and invoke_model_inference_config:
        inference_config = invoke_model_inference_config
    return inference_config, additional_model_request_fields


def _extract_response_metadata(response: Any) -> Dict[str, Any]:
    response_metadata: Dict[str, Any] = {}
    if not (isinstance(response, dict) and "ResponseMetadata" in response):
        return response_metadata

    resp_meta = response["ResponseMetadata"]
    if "HTTPStatusCode" in resp_meta:
        response_metadata["status_code"] = resp_meta["HTTPStatusCode"]

    headers = resp_meta.get("HTTPHeaders")
    _merge_header_metadata(response_metadata, headers)
    _merge_usage_metadata(response_metadata, response.get("usage"))
    _merge_metrics_metadata(response_metadata, response.get("metrics"))

    return response_metadata


def _merge_header_metadata(response_metadata: Dict[str, Any], headers: Any) -> None:
    if not isinstance(headers, dict):
        return
    key_map = {
        "x-amzn-bedrock-invocation-latency": "invocation_latency_ms",
        "x-amzn-bedrock-input-token-count": "input_tokens",
        "x-amzn-bedrock-output-token-count": "output_tokens",
        "x-amzn-requestid": "request_id",
        "content-type": "content_type",
        "content-length": "content_length",
        "date": "date",
    }
    int_header_keys = {
        "x-amzn-bedrock-invocation-latency",
        "x-amzn-bedrock-input-token-count",
        "x-amzn-bedrock-output-token-count",
    }
    for src_key, dst_key in key_map.items():
        if src_key not in headers:
            continue
        value = headers[src_key]
        if src_key in int_header_keys:
            try:
                value = int(value)
            except (ValueError, TypeError):
                pass
        response_metadata[dst_key] = value


def _merge_usage_metadata(response_metadata: Dict[str, Any], usage: Any) -> None:
    if not isinstance(usage, dict):
        return
    if "inputTokens" in usage:
        response_metadata["usage_input_tokens"] = usage["inputTokens"]
    if "outputTokens" in usage:
        response_metadata["usage_output_tokens"] = usage["outputTokens"]


def _merge_metrics_metadata(response_metadata: Dict[str, Any], metrics: Any) -> None:
    if isinstance(metrics, dict) and "latencyMs" in metrics:
        response_metadata["latency_ms"] = metrics["latencyMs"]


def _wrap_converse_stream(stream_iter: Any, initial_context: Dict[str, Any]) -> Any:
    """
    Wraps the ConverseStream event iterator so we can intercept chunks as they
    are consumed by the caller (e.g. Strands), accumulate response text, and
    update the bedrock context variable once the stream is complete.
    """
    accumulated_text = []
    stop_reason = None
    usage = {}
    try:
        for chunk in stream_iter:
            # Accumulate text deltas
            delta = chunk.get("contentBlockDelta", {}).get("delta", {})
            if "text" in delta:
                accumulated_text.append(delta["text"])
            # Capture stop reason
            if "messageStop" in chunk:
                stop_reason = chunk["messageStop"].get("stopReason")
            # Capture usage from metadata chunk
            if "metadata" in chunk and "usage" in chunk["metadata"]:
                usage = chunk["metadata"]["usage"]
            yield chunk
    finally:
        # Update stored context with the now-complete response text
        response_text = "".join(accumulated_text) or None
        updated = dict(initial_context)
        updated["response_text"] = response_text
        updated["bedrock_response"] = dict(initial_context.get("bedrock_response") or {})
        updated["bedrock_response"]["stop_reason"] = stop_reason
        if usage:
            updated["bedrock_response"]["usage"] = usage
        _bedrock_call_context.set(updated)
        logger.debug("[Bedrock Instrumentation] Stream complete, response_text captured (%d chars)", len(response_text or ""))


def _extract_response_payload(operation_name: str, response: Any) -> Dict[str, Any]:
    if operation_name == "InvokeModel":
        return _extract_invoke_model_response_payload(response)
    if operation_name == "Converse":
        return _extract_converse_response_payload(response)
    if operation_name == "ConverseStream":
        # Streaming response — body is consumed by the caller; handled via stream wrapping
        return {"response_payload": None, "response_text": None}
    return {"response_payload": None, "response_text": None}


def _extract_text_from_payload(payload: Any) -> Optional[str]:
    if not isinstance(payload, dict):
        return None
    for key in ("generation", "completion", "text", "output"):
        if key in payload:
            return payload[key]
    return None


def _extract_invoke_model_response_payload(response: Any) -> Dict[str, Any]:
    if not (isinstance(response, dict) and "body" in response):
        return {"response_payload": None, "response_text": None}
    original_body_stream = response["body"]
    response_content = original_body_stream.read()
    response_payload = None
    response_text = None
    try:
        response_payload = json.loads(response_content)
        response_text = _extract_text_from_payload(response_payload)
    except Exception as e:
        logger.debug(f"Failed to parse response body: {e}")

    response["body"] = StreamingBody(
        raw_stream=io.BytesIO(response_content),
        content_length=len(response_content),
    )
    return {"response_payload": response_payload, "response_text": response_text}


def _extract_converse_response_payload(response: Any) -> Dict[str, Any]:
    response_payload = response.copy() if isinstance(response, dict) else None
    output = response_payload.get("output") if isinstance(response_payload, dict) else None
    message = output.get("message") if isinstance(output, dict) else None
    content = message.get("content") if isinstance(message, dict) else None
    response_text = None
    if isinstance(content, list):
        for item in content:
            if isinstance(item, dict) and "text" in item:
                response_text = item["text"]
                break
    return {"response_payload": response_payload, "response_text": response_text}


def _extract_stop_reason(payload: Any) -> Optional[str]:
    if not isinstance(payload, dict):
        return None
    for key in ("stop_reason", "stopReason"):
        if key in payload and payload[key] is not None:
            return payload[key]
    output = payload.get("output")
    if isinstance(output, dict):
        for key in ("stop_reason", "stopReason"):
            if key in output and output[key] is not None:
                return output[key]
    return None


def _extract_is_continue_invoke(payload: Any) -> Optional[bool]:
    if not isinstance(payload, dict):
        return None
    for key in ("is_continue_invoke", "isContinueInvoke", "isContinue"):
        if key in payload:
            return payload[key]
    output = payload.get("output")
    if isinstance(output, dict):
        for key in ("is_continue_invoke", "isContinueInvoke", "isContinue"):
            if key in output:
                return output[key]
    return None


def _instrument_bedrock_call(wrapped, instance, args, kwargs):
    """
    Wrapper function that intercepts botocore._make_api_call
    Automatically captures model_id, request body, and response body
    """
    operation_name = args[0] if args else None
    if not _is_trackable_bedrock_call(instance, operation_name):
        return wrapped(*args, **kwargs)

    try:
        request_data = _extract_request_data(operation_name, args, kwargs)
        logger.debug("[Bedrock Instrumentation] Captured modelId: %s", request_data["model_id"])
        response = wrapped(*args, **kwargs)

        response_metadata = _extract_response_metadata(response)
        response_data = _extract_response_payload(operation_name, response)
        response_payload = response_data["response_payload"]
        response_text = response_data["response_text"]

        bedrock_request_metadata = {
            "modelId": request_data["model_id"],
            "operation": operation_name,
            "body": request_data["request_payload"],
            "inferenceConfig": request_data["inference_config"],
            "additionalModelRequestFields": request_data["additional_model_request_fields"],
        }

        if operation_name == "Converse":
            messages = request_data["messages"]
            bedrock_request_metadata["messages_count"] = len(messages) if messages else 0
            bedrock_request_metadata["has_system_prompt"] = bool(request_data["system_prompts"])
        elif operation_name == "InvokeModel":
            if "accept" in request_data["params"]:
                bedrock_request_metadata["accept"] = request_data["params"]["accept"]
            if "contentType" in request_data["params"]:
                bedrock_request_metadata["contentType"] = request_data["params"]["contentType"]
            if request_data["invoke_model_inference_config"]:
                bedrock_request_metadata["invokeModelParameters"] = request_data["invoke_model_inference_config"]

        bedrock_response = {
            "response_metadata": response_metadata or {},
            "is_continue_invoke": _extract_is_continue_invoke(response_payload),
            "stop_reason": _extract_stop_reason(response_payload),
        }

        # Store captured data in context variable with enriched metadata
        captured_data = {
            "model_id": request_data["model_id"],
            "operation": operation_name,
            "request_body": request_data["request_payload"],
            "response_body": response_payload,
            "response_text": response_text,
            "messages": request_data["messages"],
            "system": request_data["system_prompts"],
            "inference_config": request_data["inference_config"],
            "additional_model_request_fields": request_data["additional_model_request_fields"],
            "bedrock_request": bedrock_request_metadata,
            "bedrock_response": bedrock_response,
        }
        
        _bedrock_call_context.set(captured_data)
        logger.debug("[Bedrock Instrumentation] Stored captured data in context")

        # For streaming, wrap the event iterator so chunks are intercepted as consumed
        if operation_name == "ConverseStream" and isinstance(response.get("stream"), object):
            response["stream"] = _wrap_converse_stream(response["stream"], captured_data)

        return response
        
    except Exception as e:
        logger.error(f"[Bedrock Instrumentation] Error during interception: {e}", exc_info=True)
        # If anything fails, just execute the original call
        return wrapped(*args, **kwargs)


def enable_bedrock_instrumentation():
    """
    Enable automatic Bedrock instrumentation.
    Must be called before making any Bedrock API calls.
    """
    global _instrumentation_enabled
    
    if _instrumentation_enabled:
        logger.info("[Bedrock Instrumentation] Already enabled")
        return
    
    try:
        import botocore.client
        
        logger.info("[Bedrock Instrumentation] Enabling automatic model_id capture...")
        
        wrapt.wrap_function_wrapper(
            'botocore.client',
            'BaseClient._make_api_call',
            _instrument_bedrock_call
        )
        
        _instrumentation_enabled = True
        logger.info("[Bedrock Instrumentation] Enabled successfully")
        
    except Exception as e:
        logger.error(f"[Bedrock Instrumentation] Failed to enable: {e}", exc_info=True)
        raise


def disable_bedrock_instrumentation():
    """
    Disable automatic Bedrock instrumentation.
    Note: Once wrapt patches are applied, they cannot be easily removed.
    This just sets the flag to stop processing in the wrapper.
    """
    global _instrumentation_enabled
    _instrumentation_enabled = False
    logger.info("[Bedrock Instrumentation] Disabled")


def is_instrumentation_enabled() -> bool:
    """Check if Bedrock instrumentation is enabled."""
    return _instrumentation_enabled
