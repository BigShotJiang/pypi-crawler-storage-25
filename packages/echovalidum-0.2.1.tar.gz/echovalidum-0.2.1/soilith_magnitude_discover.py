"""
soilith_magnitude_discover.py — discovery at the magnitude tier (Zone 124).

This is the first discovery engine that uses *all four* of the previously
built engines as inputs:

  • Zone 116  algebraic laws         (φ-operator registry)
  • Zone 120  conservation laws      (scalar invariants of φ-operators)
  • Zone 121  magnitude rows         (scale-aware-memory capsules)
  • Zone 123  multi-scale view       (vertex / edge / face fields)

A *capsule symmetry* is a φ-operator φ_k and a reducer ``Q`` such that
applying φ_k pointwise to every cell of a tier-0 capsule preserves the
aggregate ``Q`` simultaneously at every scale:

    vertex_sum(Q)  preserved   (Zone 120 fact, restated)
    edge_sum(|dQ|) preserved   (action commutes with df)
    face curls     remain 0    (preserved by d² = 0)

The conjunction is strictly stronger than Zone 120's vertex-only
preservation — it certifies that φ_k is a *gauge transformation* of
the entire memory layout, safe to compose into capsule-respecting
programs without breaking adjacency or shape.

Output
------
``Symmetry`` records, each persisted as a ψ-cell at

    symmetry/<probe_name>/phi_<k>_<quantity>

with ``value = [vertex_residual, edge_residual, face_residual]`` and
``trust = 1 - max(residuals)`` clipped to ``[0, 1]``.

CLI
---
    python soilith_magnitude_discover.py
    python soilith_magnitude_discover.py --threshold 1e-6 \\
        --catalog catalog/discoveries.json --arena lawbook.arena
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
import sys
from typing import Iterable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_arena import Arena  # noqa: E402
from soilith_lang import Cell  # noqa: E402
from soilith_memory import ScaleAwareMemory  # noqa: E402
from soilith_multiscale import MultiScaleView, REDUCERS  # noqa: E402
from soilith_phi import PHI  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Discovery record
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Symmetry:
    """One discovered capsule symmetry."""

    capsule_probe: str
    op_index: int
    quantity: str
    k: int
    vertex_residual: float
    edge_residual: float
    face_residual: float
    is_identity_alias: bool
    trust: float


# ──────────────────────────────────────────────────────────────────────────
#  Internals
# ──────────────────────────────────────────────────────────────────────────
def _populate(mem: ScaleAwareMemory, *, cell_dim: int, seed: int) -> None:
    rng = np.random.default_rng(seed)
    for addr in mem.positions():
        mem.write(
            addr,
            Cell(value=rng.standard_normal(cell_dim) * 0.5,
                 trust=1.0, phase=0.0),
        )


def _is_identity_alias(op_index: int, *, cell_dim: int, seed: int) -> bool:
    """Empirically check if φ_k acts as the identity on real inputs.

    Mirrors the Zone 117 correction: φ_16, φ_28, φ_29, φ_43 collapse
    to identity and so trivially satisfy every conservation. Marking
    these makes the rest of the discoveries non-trivial.
    """
    rng = np.random.default_rng(seed)
    op = PHI.get(op_index)
    if op is None:
        return False
    for _ in range(5):
        x = rng.standard_normal(cell_dim) * 0.5
        try:
            y = op(x)
            if isinstance(y, tuple):
                parts = [np.asarray(p) for p in y]
                if any(np.iscomplexobj(p) for p in parts):
                    return False
                y = np.concatenate(
                    [p.astype(float).ravel() for p in parts]
                )
            y = np.asarray(y)
            if np.iscomplexobj(y):
                return False
            y = y.astype(np.float64, copy=False)
        except Exception:
            return False
        if y.shape != x.shape:
            return False
        if not np.allclose(y, x, atol=1e-9):
            return False
    return True


def discover(
    magnitude_entry: dict,
    *,
    threshold: float = 1e-6,
    cell_dim: int = 4,
    seed: int = 17,
    k_indices: Iterable[int] | None = None,
    quantities: Iterable[str] | None = None,
) -> list[Symmetry]:
    """Find every (φ_k, quantity) pair that is a full capsule symmetry."""
    mem = ScaleAwareMemory.from_magnitude_entry(magnitude_entry)
    _populate(mem, cell_dim=cell_dim, seed=seed)
    msv = MultiScaleView(mem)

    if k_indices is None:
        k_indices = sorted(PHI.keys())
    if quantities is None:
        quantities = list(REDUCERS.keys())

    out: list[Symmetry] = []
    for k in k_indices:
        if k not in PHI:
            continue
        id_alias = _is_identity_alias(k, cell_dim=cell_dim, seed=seed)
        for q in quantities:
            lift = msv.lift_conservation(k, q, tol=threshold)
            if not lift.all_match:
                continue
            trust = max(0.0, 1.0 - max(
                lift.vertex_residual,
                lift.edge_residual,
                lift.face_residual,
            ))
            out.append(
                Symmetry(
                    capsule_probe=str(
                        magnitude_entry.get("payload", {}).get("probe_name", "")
                    ),
                    op_index=k,
                    quantity=q,
                    k=mem.k,
                    vertex_residual=lift.vertex_residual,
                    edge_residual=lift.edge_residual,
                    face_residual=lift.face_residual,
                    is_identity_alias=id_alias,
                    trust=float(min(1.0, trust)),
                )
            )
    return out


def persist(arena_path: Path, symmetries: list[Symmetry]) -> None:
    """Save each symmetry as a ψ-cell under
    ``symmetry/<probe>/phi_<k>_<quantity>``.
    """
    a = Arena.open(arena_path, autoflush=False)
    for s in symmetries:
        slot = f"symmetry/{s.capsule_probe}/phi_{s.op_index}_{s.quantity}"
        value = np.array(
            [s.vertex_residual, s.edge_residual, s.face_residual,
             float(s.is_identity_alias)],
            dtype=float,
        )
        a[slot] = Cell(value=value, trust=float(s.trust), phase=0.0)
    a.flush()


def _summarize(symmetries: list[Symmetry]) -> str:
    if not symmetries:
        return "  (no capsule symmetries above threshold)"
    by_probe: dict[str, list[Symmetry]] = {}
    for s in symmetries:
        by_probe.setdefault(s.capsule_probe, []).append(s)
    lines: list[str] = []
    for probe, rows in by_probe.items():
        non_trivial = [r for r in rows if not r.is_identity_alias]
        trivial = [r for r in rows if r.is_identity_alias]
        lines.append(
            f"  {probe}: {len(rows)} symmetries "
            f"({len(non_trivial)} non-trivial, {len(trivial)} identity-alias)"
        )
        for r in sorted(non_trivial, key=lambda r: (r.op_index, r.quantity)):
            lines.append(
                f"    φ_{r.op_index:>2d} preserves {r.quantity:<4s} "
                f"v={r.vertex_residual:.1e} e={r.edge_residual:.1e} "
                f"f={r.face_residual:.1e}  trust={r.trust:.6f}"
            )
        if non_trivial:
            ops = sorted({r.op_index for r in non_trivial})
            lines.append(f"    → non-trivial operators: {ops}")
    return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_catalog() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def _default_lawbook() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith magnitude-tier discovery (Zone 124)."
    )
    p.add_argument("--catalog", type=Path, default=_default_catalog())
    p.add_argument("--arena", type=Path, default=_default_lawbook(),
                   help="lawbook arena to persist symmetries into.")
    p.add_argument("--threshold", type=float, default=1e-6)
    p.add_argument("--cell-dim", type=int, default=4)
    p.add_argument("--seed", type=int, default=17)
    p.add_argument("--tier", type=int, default=0,
                   help="only probe capsules at this tier (default 0).")
    p.add_argument("--no-persist", action="store_true")
    args = p.parse_args(argv)

    if not args.catalog.exists():
        print(f"# no catalog at {args.catalog}; run soilith_catalog.py first.")
        return 1

    data = json.loads(args.catalog.read_text(encoding="utf-8"))
    capsules = [
        e for e in data.get("entries", [])
        if e.get("kind") == "magnitude"
        and e.get("payload", {}).get("tier") == args.tier
    ]
    if not capsules:
        print(f"# no tier-{args.tier} magnitude rows in {args.catalog}.")
        return 1

    print(f"# probing {len(capsules)} tier-{args.tier} capsule(s) "
          f"with threshold={args.threshold}, cell_dim={args.cell_dim}")

    all_symmetries: list[Symmetry] = []
    for entry in capsules:
        probe = entry.get("payload", {}).get("probe_name", entry.get("slot"))
        print(f"\n## {entry.get('slot')}  (probe={probe})")
        syms = discover(
            entry,
            threshold=args.threshold,
            cell_dim=args.cell_dim,
            seed=args.seed,
        )
        all_symmetries.extend(syms)
        print(_summarize(syms))

    if not args.no_persist:
        persist(args.arena, all_symmetries)
        print(f"\n# persisted {len(all_symmetries)} symmetry cells → {args.arena}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
