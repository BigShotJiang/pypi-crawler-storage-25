"""
soilith_prob.py — probabilistic programming on the trust lattice
(Zone 143).

Anglican, Pyro, Stan, and PSI treat a program as a *distribution
over execution traces* and infer **posterior** beliefs from
observed data via Bayes' rule. Σoilith's per-cell ``trust`` is
already a confidence number in ``[0, 1]``; Zone 143 makes the
probabilistic semantics explicit by:

* representing a posterior as a *weighted set of particles*
  (state, weight);
* taking Σoilith's catalog rows as a prior — the marginal
  probability of a law is its trust value;
* providing ``observe(particles, evidence_log_likelihood)`` for
  Bayesian update by reweighting;
* computing effective sample size (ESS) and resampling when
  particle weights collapse.

This zone lets users ask catalog-level questions like
"what is my posterior belief that *involutivity* holds for φ_38?"
and get a principled, calibrated answer.

CLI
---
    python soilith_prob.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any, Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class ProbError(Exception):
    pass


# ──────────────────────────────────────────────────────────────────────────
#  Particle and population
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Particle:
    state: dict[str, Any]
    log_weight: float = 0.0

    @property
    def weight(self) -> float:
        return float(np.exp(self.log_weight))


@dataclass
class Population:
    particles: list[Particle] = field(default_factory=list)

    @property
    def n(self) -> int:
        return len(self.particles)

    @property
    def total_weight(self) -> float:
        return float(np.sum([p.weight for p in self.particles]))

    def normalised_weights(self) -> np.ndarray:
        if not self.particles:
            return np.array([], dtype=float)
        lws = np.array([p.log_weight for p in self.particles],
                       dtype=float)
        m = float(np.max(lws))
        w = np.exp(lws - m)
        s = float(np.sum(w))
        if s == 0.0:
            return np.full_like(w, 1.0 / len(w))
        return w / s

    def effective_sample_size(self) -> float:
        w = self.normalised_weights()
        if w.size == 0:
            return 0.0
        return float(1.0 / np.sum(w * w))

    # Bayesian update: reweight every particle by its log-likelihood.
    def observe(self, log_likelihood: Callable[[Particle], float]) -> None:
        for p in self.particles:
            p.log_weight += float(log_likelihood(p))

    def resample(self, *, rng: np.random.Generator | None = None,
                 ) -> None:
        if rng is None:
            rng = np.random.default_rng(seed=0xC0FFEE)
        w = self.normalised_weights()
        idx = rng.choice(self.n, size=self.n, p=w)
        new_particles = [
            Particle(state=dict(self.particles[i].state), log_weight=0.0)
            for i in idx
        ]
        self.particles = new_particles

    def marginal(self, key: str) -> tuple[float, float]:
        """Return (mean, variance) of ``state[key]`` under the
        normalised weights."""
        w = self.normalised_weights()
        vals = np.array(
            [float(p.state.get(key, 0.0)) for p in self.particles],
            dtype=float,
        )
        if vals.size == 0:
            return 0.0, 0.0
        mean = float(np.sum(w * vals))
        var = float(np.sum(w * (vals - mean) ** 2))
        return mean, var


# ──────────────────────────────────────────────────────────────────────────
#  Catalog-as-prior
# ──────────────────────────────────────────────────────────────────────────
def prior_from_catalog(
    catalog: dict[str, Any], *, kind: str | None = None, n: int = 256,
    rng: np.random.Generator | None = None,
) -> Population:
    """Sample a population of size n from catalog rows of a given
    ``kind``; the prior for each row is ``Bernoulli(trust)`` for the
    *holds* state. Each particle is a dict
    ``{slot: 0 or 1}``."""
    if rng is None:
        rng = np.random.default_rng(seed=42)
    rows = [
        e for e in catalog.get("entries", [])
        if (kind is None or e.get("kind") == kind)
    ]
    if not rows:
        return Population()
    slots = [r["slot"] for r in rows]
    trusts = np.array([float(r.get("trust", 0.0)) for r in rows],
                      dtype=float)
    parts: list[Particle] = []
    for _ in range(n):
        flips = rng.random(len(slots)) < trusts
        st = {s: int(b) for s, b in zip(slots, flips)}
        parts.append(Particle(state=st, log_weight=0.0))
    return Population(particles=parts)


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(
    name: str, query: str, pop: Population, arena_path: Path,
) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    mean, var = pop.marginal(query)
    ess = pop.effective_sample_size()
    payload = np.array([
        mean, var, ess, float(pop.n),
    ], dtype=float)
    trust = float(np.clip(ess / max(pop.n, 1), 0.0, 1.0))
    safe = "".join(c if c.isalnum() else "_" for c in f"{name}/{query}")[:80]
    arena[f"posterior/{safe}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI / Demo
# ──────────────────────────────────────────────────────────────────────────
def _default_catalog() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith probabilistic programming (Zone 143)."
    )
    p.add_argument("--catalog", type=Path, default=_default_catalog())
    p.add_argument("--arena", type=Path, default=_default_arena())
    p.add_argument("--n", type=int, default=512)
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    import json
    catalog = (
        json.loads(args.catalog.read_text(encoding="utf-8"))
        if args.catalog.exists() else {"entries": []}
    )
    print("# Zone 143 — probabilistic programming on the catalog")

    print("\n# 1. Sample a prior over 'finite_order' rows")
    pop = prior_from_catalog(catalog, kind="finite_order", n=args.n)
    print(f"   |particles| = {pop.n}")
    if pop.n == 0:
        print("   (no finite_order entries — exiting demo)")
        return 0
    # Look at one canonical slot.
    sample_slot = pop.particles[0].state
    one_slot = next(iter(sample_slot.keys()))
    mean, var = pop.marginal(one_slot)
    print(f"   prior P[{one_slot} holds] ≈ {mean:.3f} ± {var**0.5:.3f}")

    print("\n# 2. Bayesian update — observe TWO independent experiments "
          "that each see the law hold")
    def loglik(p: Particle) -> float:
        # If the law holds in this particle's state, the observation
        # is likely; if it doesn't, the observation is unlikely.
        # Each experiment has 95%/10% likelihoods.
        h = p.state.get(one_slot, 0)
        return float(2 * (np.log(0.95) if h else np.log(0.10)))

    pop.observe(loglik)
    ess = pop.effective_sample_size()
    mean2, var2 = pop.marginal(one_slot)
    print(f"   posterior P[{one_slot} holds] ≈ "
          f"{mean2:.3f} ± {var2**0.5:.3f}")
    print(f"   ESS = {ess:.1f} / {pop.n}")

    print("\n# 3. Resample to combat weight degeneracy")
    if ess < pop.n / 2:
        pop.resample()
        print(f"   resampled; new ESS = "
              f"{pop.effective_sample_size():.1f}")

    print("\n# 4. Persist the marginal as a posterior cell")
    persist("finite_order", one_slot, pop, args.arena)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
