"""
soilith_gauge.py — gauge transformations on scale-aware memory
(Zone 128, part 3).

A *gauge transformation* in Σoilith terms is a φ-operator that the
Zone 124 magnitude-discovery engine certified as a *capsule symmetry*
on the target capsule — i.e. one that preserves a chosen scalar
``Q ∈ {l1, l2, sum, mean, …}`` simultaneously at the vertex, edge,
and face scales of the capsule's multi-scale view.

This module:

* loads ``symmetry/*`` rows from the unified catalog;
* exposes ``GaugeAction(phi_index, quantity, capsule_probe)`` records;
* applies a chosen gauge to every populated cell of a memory in-place,
  with pre- and post-action verification of:
    1. all per-cell quantities ``Q(value)`` are preserved (within tol);
    2. the capsule's audit still matches its attested χ (no global
       structural drift).

Gauge actions are the *only* way Σoilith should transform whole
capsules in bulk; anything else risks invalidating the catalog
guarantees the capsule was loaded with. Adoption gates in
``stdlib/gauge.sol`` refuse to bind a ``GaugeReport`` unless every
guarantee held.

CLI
---
    python soilith_gauge.py
    python soilith_gauge.py --phi 38 --quantity l2
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import json
from pathlib import Path
import sys
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402
from soilith_phi import PHI  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Reducers
# ──────────────────────────────────────────────────────────────────────────
def _reduce(name: str, x: np.ndarray) -> float:
    a = np.asarray(x, dtype=float).ravel()
    if name == "l1":
        return float(np.sum(np.abs(a)))
    if name == "l2":
        return float(np.linalg.norm(a, ord=2))
    if name == "sum":
        return float(np.sum(a))
    if name == "mean":
        return float(np.mean(a)) if a.size else 0.0
    if name == "max":
        return float(np.max(a)) if a.size else 0.0
    raise ValueError(f"unknown reducer {name!r}")


# ──────────────────────────────────────────────────────────────────────────
#  Records
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class GaugeAction:
    """A capsule-symmetry verdict promoted to a memory transformation."""

    phi_index: int
    quantity: str
    capsule_probe: str
    is_identity_alias: bool = False

    def describe(self) -> str:
        flavor = " (identity-alias)" if self.is_identity_alias else ""
        return (
            f"GaugeAction  φ_{self.phi_index} preserves {self.quantity}"
            f"{flavor}  on {self.capsule_probe}"
        )


@dataclass
class GaugeReport:
    """Verdict for applying a gauge to a populated memory."""

    action: GaugeAction
    cells_touched: int
    per_cell_residual: float       # max |Q(new) − Q(old)| over cells
    pre_audit_chi_match: bool
    post_audit_chi_match: bool
    is_endo: bool                  # operator was shape-preserving on cells
    notes: list[str] = field(default_factory=list)

    @property
    def successful(self) -> bool:
        return (
            self.is_endo
            and self.per_cell_residual < 1e-4
            and self.pre_audit_chi_match
            and self.post_audit_chi_match
        )

    def describe(self) -> str:
        ok = "✓" if self.successful else "✗"
        return (
            f"GaugeReport {ok}  φ_{self.action.phi_index} on "
            f"{self.action.capsule_probe}\n"
            f"  quantity         = {self.action.quantity}\n"
            f"  cells_touched    = {self.cells_touched}\n"
            f"  per_cell_residual= {self.per_cell_residual:.3e}\n"
            f"  is_endo          = {self.is_endo}\n"
            f"  pre  chi_match   = {self.pre_audit_chi_match}\n"
            f"  post chi_match   = {self.post_audit_chi_match}"
            + ("\n  · " + "\n  · ".join(self.notes) if self.notes else "")
        )


# ──────────────────────────────────────────────────────────────────────────
#  Catalog loader
# ──────────────────────────────────────────────────────────────────────────
def load_actions(
    catalog_path: Path,
    *,
    capsule_probe: str | None = None,
    quantity: str | None = None,
    include_identity_aliases: bool = False,
) -> list[GaugeAction]:
    """Pull every symmetry/* row matching the optional filters."""
    data = json.loads(catalog_path.read_text(encoding="utf-8"))
    out: list[GaugeAction] = []
    for e in data.get("entries", []):
        if e.get("kind") != "symmetry":
            continue
        p = e.get("payload", {})
        if capsule_probe is not None and p.get("capsule_probe") != capsule_probe:
            continue
        if quantity is not None and p.get("quantity") != quantity:
            continue
        is_alias = bool(p.get("is_identity_alias", False))
        if is_alias and not include_identity_aliases:
            continue
        out.append(GaugeAction(
            phi_index=int(p.get("op_index", -1)),
            quantity=str(p.get("quantity", "")),
            capsule_probe=str(p.get("capsule_probe", "")),
            is_identity_alias=is_alias,
        ))
    return out


# ──────────────────────────────────────────────────────────────────────────
#  Application
# ──────────────────────────────────────────────────────────────────────────
def _safe_apply(op, x: np.ndarray) -> np.ndarray | None:
    try:
        y = op(np.asarray(x, dtype=float))
    except Exception:
        return None
    if isinstance(y, tuple):
        parts = [np.asarray(p) for p in y]
        if any(np.iscomplexobj(p) for p in parts):
            return None
        try:
            y = np.concatenate([p.astype(float).ravel() for p in parts])
        except Exception:
            return None
    y = np.asarray(y)
    if np.iscomplexobj(y):
        return None
    try:
        y = y.astype(np.float64, copy=False).ravel()
    except Exception:
        return None
    if not np.all(np.isfinite(y)):
        return None
    return y


def apply_gauge(
    memory: Any,
    action: GaugeAction,
    *,
    tol: float = 1e-4,
    require_post_audit: bool = True,
) -> GaugeReport:
    """Apply ``action`` in-place across every populated cell of
    ``memory``. Returns a ``GaugeReport`` whose ``successful`` flag is
    True only when (a) the operator was shape-preserving, (b) every
    per-cell ``Q`` value was preserved within ``tol``, and (c) the
    capsule's pre- and post-audit ``chi_match`` both held."""
    op = PHI.get(action.phi_index)
    notes: list[str] = []
    if op is None:
        notes.append(f"unknown operator φ_{action.phi_index}")
        return GaugeReport(
            action=action, cells_touched=0,
            per_cell_residual=float("inf"),
            pre_audit_chi_match=False, post_audit_chi_match=False,
            is_endo=False, notes=notes,
        )

    try:
        pre_report = memory.audit(strict=False)
        pre_match = bool(getattr(pre_report, "chi_match", False))
    except Exception as exc:
        notes.append(f"pre-audit failed: {type(exc).__name__}: {exc}")
        pre_match = False

    addrs: list[Any] = []
    if hasattr(memory, "populated_addresses"):
        addrs = list(memory.populated_addresses())
    elif hasattr(memory, "_store"):
        addrs = list(memory._store.keys())  # ScaleAwareMemory
    if not addrs:
        notes.append("no populated cells")

    is_endo = True
    worst_q_resid = 0.0
    snap = memory.snapshot() if hasattr(memory, "snapshot") else None
    touched = 0
    for a in addrs:
        old = memory.read(a)
        if old is None:
            continue
        old_arr = np.asarray(old.value, dtype=float).ravel()
        new_arr = _safe_apply(op, old_arr)
        if new_arr is None:
            is_endo = False
            notes.append(f"φ_{action.phi_index} failed on cell {a!r}")
            continue
        if new_arr.shape != old_arr.shape:
            is_endo = False
            notes.append(
                f"shape change at {a!r}: {old_arr.shape} → {new_arr.shape}"
            )
            continue
        try:
            q_old = _reduce(action.quantity, old_arr)
            q_new = _reduce(action.quantity, new_arr)
            worst_q_resid = max(worst_q_resid, abs(q_new - q_old))
        except Exception as exc:
            notes.append(f"reducer raised at {a!r}: {exc}")
            continue
        memory.write(a, Cell(value=new_arr, trust=old.trust,
                             phase=old.phase))
        touched += 1

    if not is_endo and snap is not None:
        memory.restore(snap)
        notes.append("rolled back: operator not endo on this capsule")
        return GaugeReport(
            action=action, cells_touched=touched,
            per_cell_residual=worst_q_resid,
            pre_audit_chi_match=pre_match, post_audit_chi_match=False,
            is_endo=False, notes=notes,
        )

    if worst_q_resid > tol and snap is not None:
        memory.restore(snap)
        notes.append(
            f"rolled back: per-cell {action.quantity} drift = "
            f"{worst_q_resid:.3e} > tol {tol:.1e}"
        )
        return GaugeReport(
            action=action, cells_touched=touched,
            per_cell_residual=worst_q_resid,
            pre_audit_chi_match=pre_match, post_audit_chi_match=False,
            is_endo=True, notes=notes,
        )

    post_match = pre_match
    if require_post_audit:
        try:
            post_report = memory.audit(strict=False)
            post_match = bool(getattr(post_report, "chi_match", False))
        except Exception as exc:
            notes.append(f"post-audit failed: {type(exc).__name__}: {exc}")
            post_match = False

    return GaugeReport(
        action=action, cells_touched=touched,
        per_cell_residual=worst_q_resid,
        pre_audit_chi_match=pre_match, post_audit_chi_match=post_match,
        is_endo=True, notes=notes,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_catalog() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith gauge transformation runtime (Zone 128)."
    )
    p.add_argument("--catalog", type=Path, default=_default_catalog())
    p.add_argument("--probe", default="z2_cubed")
    p.add_argument("--quantity", default="l2")
    p.add_argument("--phi", type=int, default=38)
    args = p.parse_args(argv)

    from soilith_memory import ScaleAwareMemory

    actions = load_actions(args.catalog,
                           capsule_probe=args.probe,
                           quantity=args.quantity)
    matching = [a for a in actions if a.phi_index == args.phi]
    if not matching:
        print(f"# no symmetry row for φ_{args.phi} preserving {args.quantity} "
              f"on {args.probe}")
        return 1
    action = matching[0]
    print("# " + action.describe())

    mem = ScaleAwareMemory.from_catalog(args.catalog,
                                        slot=f"magnitude/tier0_{args.probe}")
    rng = np.random.default_rng(42)
    for addr in mem.positions():
        mem.write(addr, Cell(value=rng.standard_normal(8) * 0.7,
                             trust=1.0, phase=0.0))
    pre = mem.audit()
    print(f"\n# pre-audit chi_match = {pre.chi_match}")

    report = apply_gauge(mem, action)
    print("\n" + report.describe())
    return 0 if report.successful else 1


if __name__ == "__main__":
    raise SystemExit(main())
