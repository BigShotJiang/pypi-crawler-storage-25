"""
soilith_bytecode.py — Σoilith bytecode compiler + stack VM + on-disk ``.solc`` cache.

Pipeline:
        .sol  ──lex──▶ tokens ──parse──▶ AST ──compile──▶ CodeObject ──exec──▶ ψ
                                                       │
                                                       └──pickle──▶  <src>.solc

A ``.solc`` file is a versioned, pickled ``CodeObject`` cached next to the
``.sol`` source. On subsequent runs, if the cache is **newer** than the source
file and its magic+version match, we skip lex+parse and execute directly. Edit
the source → cache invalidates automatically.

The VM shares the lattice memory model from ``soilith_lang.py`` — every value
the VM pushes is still a ``Cell`` on the trust-coherence lattice; the bytecode
is just a fast, durable encoding of the program plan.
"""

from __future__ import annotations

import pickle
import struct
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
import soilith_phi as sp  # noqa: E402
from soilith_lang import (  # noqa: E402
    BOT, TOP, Cell, Function, Interpreter, TrustError, TypeRef,
    BinOp, BotE, Call, Echo, ExprStmt, FnDef, Import, Let, Norm, Num, Phi,
    Print, TopE, TrustDef, Var, When, WithTrust, Yield,
    ArenaOpen, Save, LoadE,
    GossipOpen, Broadcast, SyncStmt,
    Parser, lex,
)

# ──────────────────────────────────────────────────────────────────────────────
# CodeObject + on-disk format
# ──────────────────────────────────────────────────────────────────────────────
_MAGIC = b"\xcf\x9c\xce\xa3"  # UTF-8 bytes for "ϜΣ"
_VERSION = 1


@dataclass
class CodeObject:
    """Compiled Σoilith program (or function body)."""

    code: list[tuple] = field(default_factory=list)
    consts: list[Any] = field(default_factory=list)
    names: list[str] = field(default_factory=list)
    functions: list["CodeObject"] = field(default_factory=list)
    fn_meta: list[tuple] = field(default_factory=list)  # (name, params, ref)
    source_hint: str = ""

    def _const(self, v: Any) -> int:
        for i, c in enumerate(self.consts):
            if type(c) is type(v) and c == v:
                return i
        self.consts.append(v)
        return len(self.consts) - 1

    def _name(self, s: str) -> int:
        if s in self.names:
            return self.names.index(s)
        self.names.append(s)
        return len(self.names) - 1


def save_solc(code: CodeObject, path: Path) -> None:
    payload = pickle.dumps(code, protocol=pickle.HIGHEST_PROTOCOL)
    with open(path, "wb") as f:
        f.write(_MAGIC)
        f.write(struct.pack("<H", _VERSION))
        f.write(payload)


def load_solc(path: Path) -> CodeObject:
    with open(path, "rb") as f:
        magic = f.read(len(_MAGIC))
        if magic != _MAGIC:
            raise ValueError(f"{path.name}: not a Σoilith bytecode file")
        (ver,) = struct.unpack("<H", f.read(2))
        if ver != _VERSION:
            raise ValueError(f"{path.name}: unsupported bytecode version {ver}")
        return pickle.loads(f.read())


def cache_path(src_path: Path) -> Path:
    return src_path.with_suffix(".solc")


def cache_is_fresh(src_path: Path, cache: Path | None = None) -> bool:
    cache = cache or cache_path(src_path)
    if not cache.exists():
        return False
    try:
        return cache.stat().st_mtime >= src_path.stat().st_mtime
    except FileNotFoundError:
        return False


# ──────────────────────────────────────────────────────────────────────────────
# Compiler  (AST → CodeObject)
# ──────────────────────────────────────────────────────────────────────────────
class Compiler:
    """Compile a parsed Σoilith program into a CodeObject."""

    def __init__(self, source_hint: str = "") -> None:
        self.code = CodeObject(source_hint=source_hint)

    @classmethod
    def compile_source(cls, src: str, source_hint: str = "") -> CodeObject:
        ast = Parser(lex(src)).parse()
        return cls.compile_stmts(ast, source_hint=source_hint)

    @classmethod
    def compile_stmts(cls, stmts: list, source_hint: str = "") -> CodeObject:
        """Compile a pre-parsed (and possibly rewritten — Zone 119) AST."""
        comp = cls(source_hint=source_hint)
        for stmt in stmts:
            comp._stmt(stmt)
        return comp.code

    # ── helpers ──────────────────────────────────────────────────────────────
    def _emit(self, *op: Any) -> int:
        self.code.code.append(tuple(op))
        return len(self.code.code) - 1

    def _patch(self, idx: int, *op: Any) -> None:
        self.code.code[idx] = tuple(op)

    # ── statements ───────────────────────────────────────────────────────────
    def _stmt(self, n: Any) -> None:
        m = getattr(self, f"_s_{type(n).__name__}", None)
        if m is None:
            raise RuntimeError(f"no compiler for stmt {type(n).__name__}")
        m(n)

    def _s_Let(self, n: Let) -> None:
        self._expr(n.expr)
        ni = self.code._name(n.name)
        if n.refinement is None:
            self._emit("STORE_NAME", ni)
        else:
            ri = self.code._const((n.refinement.op, float(n.refinement.threshold)))
            self._emit("STORE_REFINED", ni, ri)

    def _s_TrustDef(self, n: TrustDef) -> None:
        self._expr(n.expr)
        self._emit("STORE_TRUST", self.code._name(n.name))

    def _s_When(self, n: When) -> None:
        self._expr(n.cond)
        jmp = self._emit("JUMP_IF_FALSE", -1)
        for s in n.body:
            self._stmt(s)
        self._patch(jmp, "JUMP_IF_FALSE", len(self.code.code))

    def _s_Echo(self, n: Echo) -> None:
        self._expr(n.expr)
        self._emit("ECHO", self.code._name(n.target))

    def _s_Yield(self, n: Yield) -> None:
        self._expr(n.expr)
        self._emit("YIELD")

    def _s_Print(self, n: Print) -> None:
        self._expr(n.expr)
        self._emit("PRINT")

    def _s_ExprStmt(self, n: ExprStmt) -> None:
        self._expr(n.expr)
        self._emit("POP_EXPR")

    def _s_Import(self, n: Import) -> None:
        self._emit("IMPORT", self.code._const(n.path))

    def _s_ArenaOpen(self, n: ArenaOpen) -> None:
        self._emit("ARENA_OPEN", self.code._const((n.path, n.agent)))

    def _s_Save(self, n: Save) -> None:
        self._expr(n.expr)
        if n.quorum_k is None:
            spec: Any = n.name
        else:
            spec = (n.name, int(n.quorum_k), int(n.quorum_n))
        self._emit("ARENA_SAVE", self.code._const(spec))

    # ── Zone 112: gossip / broadcast / sync ──────────────────────────────────
    def _s_GossipOpen(self, n: GossipOpen) -> None:
        self._emit("GOSSIP_OPEN", self.code._const(n.path))

    def _s_Broadcast(self, n: Broadcast) -> None:
        self._expr(n.expr)
        self._emit("BROADCAST", self.code._const(n.name))

    def _s_SyncStmt(self, _n: SyncStmt) -> None:
        self._emit("SYNC")

    def _s_FnDef(self, n: FnDef) -> None:
        sub = Compiler(source_hint=f"fn {n.name}")
        for s in n.body:
            sub._stmt(s)
        ref_tuple = None if n.refinement is None else (
            n.refinement.op, float(n.refinement.threshold)
        )
        self.code.functions.append(sub.code)
        self.code.fn_meta.append((n.name, list(n.params), ref_tuple))
        fn_idx = len(self.code.functions) - 1
        self._emit("MAKE_FN", fn_idx)
        self._emit("STORE_NAME", self.code._name(n.name))

    # ── expressions ──────────────────────────────────────────────────────────
    def _expr(self, n: Any) -> None:
        m = getattr(self, f"_e_{type(n).__name__}", None)
        if m is None:
            raise RuntimeError(f"no compiler for expr {type(n).__name__}")
        m(n)

    def _e_Num(self, n: Num) -> None:
        self._emit("LOAD_CONST", self.code._const(n.value))

    def _e_Var(self, n: Var) -> None:
        self._emit("LOAD_NAME", self.code._name(n.name))

    def _e_TopE(self, _: TopE) -> None:
        self._emit("MAKE_TOP")

    def _e_BotE(self, _: BotE) -> None:
        self._emit("MAKE_BOT")

    def _e_Norm(self, n: Norm) -> None:
        self._expr(n.expr)
        self._emit("NORM")

    def _e_WithTrust(self, n: WithTrust) -> None:
        self._expr(n.expr)
        self._expr(n.trust_expr)
        self._emit("WITH_TRUST")

    def _e_Phi(self, n: Phi) -> None:
        for a in n.args:
            self._expr(a)
        kwnames = list(n.kwargs.keys())
        for k in kwnames:
            self._expr(n.kwargs[k])
        kw_idx = self.code._const(tuple(kwnames))
        self._emit("CALL_PHI", int(n.k), len(n.args), len(kwnames), kw_idx)

    def _e_Call(self, n: Call) -> None:
        for a in n.args:
            self._expr(a)
        kwnames = list(n.kwargs.keys())
        for k in kwnames:
            self._expr(n.kwargs[k])
        kw_idx = self.code._const(tuple(kwnames))
        self._emit(
            "CALL_FN", self.code._name(n.name), len(n.args), len(kwnames), kw_idx
        )

    def _e_BinOp(self, n: BinOp) -> None:
        self._expr(n.left)
        self._expr(n.right)
        self._emit("BINOP", n.op)

    def _e_LoadE(self, n: LoadE) -> None:
        self._emit(
            "ARENA_LOAD",
            self.code._const((n.name, n.load_agent, bool(n.quorum))),
        )


# ──────────────────────────────────────────────────────────────────────────────
# VM  (executes a CodeObject against an Interpreter-like host)
# ──────────────────────────────────────────────────────────────────────────────
class VM:
    """Stack VM that shares lattice memory with an :class:`Interpreter` host."""

    def __init__(self, code: CodeObject, host: Interpreter) -> None:
        self.code = code
        self.host = host
        self.stack: list[Any] = []
        self.pc = 0

    def run(self) -> None:
        c = self.code
        s = self.stack
        h = self.host
        while self.pc < len(c.code):
            instr = c.code[self.pc]
            self.pc += 1
            op = instr[0]

            if op == "LOAD_CONST":
                s.append(c.consts[instr[1]])
            elif op == "LOAD_NAME":
                name = c.names[instr[1]]
                if name not in h.env:
                    raise NameError(f"unbound name {name!r}")
                s.append(h.env[name])
            elif op == "STORE_NAME":
                h.env[c.names[instr[1]]] = s.pop()
            elif op == "STORE_REFINED":
                name = c.names[instr[1]]
                op_name, threshold = c.consts[instr[2]]
                ref = TypeRef(op_name, float(threshold))
                v = s.pop()
                cell = h._as_cell(v)
                if not ref.check(cell.trust):
                    raise TrustError(
                        f"refinement violated for {name!r}: "
                        f"trust={cell.trust:.3f} ⋫ ({ref.op} {ref.threshold})"
                    )
                h.env[name] = cell
            elif op == "STORE_TRUST":
                h.env[c.names[instr[1]]] = float(h._scalar(s.pop()))
            elif op == "MAKE_TOP":
                s.append(TOP(h.default_n))
            elif op == "MAKE_BOT":
                s.append(BOT(h.default_n))
            elif op == "NORM":
                v = h._as_cell(s.pop())
                s.append(float(np.linalg.norm(v.value)))
            elif op == "WITH_TRUST":
                t_raw = s.pop()
                cell = h._as_cell(s.pop())
                t = h._scalar(t_raw) if not isinstance(t_raw, (int, float)) else float(t_raw)
                s.append(Cell(value=cell.value.copy(), trust=float(t), phase=cell.phase))
            elif op == "ECHO":
                target = c.names[instr[1]]
                cell = h._as_cell(s.pop())
                h.echo_stacks.setdefault(target, []).append(cell)
                h.env[target] = cell
            elif op == "YIELD":
                h.yielded = h._as_cell(s.pop())
            elif op == "PRINT":
                v = s.pop()
                print(v if not isinstance(v, np.ndarray) else f"array(shape={v.shape})")
            elif op == "POP_EXPR":
                v = s.pop()
                h._last_value = v
                h.env["_"] = v
            elif op == "JUMP_IF_FALSE":
                cond = s.pop()
                if not bool(cond):
                    self.pc = instr[1]
            elif op == "JUMP":
                self.pc = instr[1]
            elif op == "IMPORT":
                # Reuse the AST interpreter's import resolution.
                h.eval(Import(c.consts[instr[1]]))
            elif op == "ARENA_OPEN":
                spec = c.consts[instr[1]]
                if isinstance(spec, str):
                    h.eval(ArenaOpen(spec, None))
                else:
                    path, agent = spec[0], spec[1]
                    h.eval(ArenaOpen(path, agent))
            elif op == "ARENA_SAVE":
                spec = c.consts[instr[1]]
                cell = h._as_cell(s.pop())
                if isinstance(spec, str):
                    h._arena_save_cell(spec, cell, None)
                else:
                    name, k, n = spec[0], int(spec[1]), int(spec[2])
                    h._arena_save_cell(name, cell, (k, n))
            elif op == "ARENA_LOAD":
                spec = c.consts[instr[1]]
                if isinstance(spec, str):
                    s.append(h.eval(LoadE(spec)))
                else:
                    name, ag, qm = spec[0], spec[1], spec[2]
                    s.append(
                        h.eval(LoadE(name, load_agent=ag, quorum=bool(qm)))
                    )
            elif op == "GOSSIP_OPEN":
                h.eval(GossipOpen(c.consts[instr[1]]))
            elif op == "BROADCAST":
                name = c.consts[instr[1]]
                expr_value = s.pop()
                # The compiler pushed the cell expression; we wrap into a fake
                # AST node so the interpreter handler can reuse its bookkeeping
                # (clock bump + spool emit). We pre-eval the expression here.
                h._gossip_clock += 1
                from soilith_distributed import ArenaFrame  # local import

                spool = h._ensure_spool()
                if not h.arena_agent:
                    raise RuntimeError(
                        'broadcast requires an active agent — open arena with `agent "αᵢ"` first.'
                    )
                spool.emit(
                    ArenaFrame(
                        agent=h.arena_agent,
                        slot=name,
                        cell=h._as_cell(expr_value),
                        clock=h._gossip_clock,
                    )
                )
            elif op == "SYNC":
                h.eval(SyncStmt())
            elif op == "CALL_PHI":
                k, argc, kwargc, kw_idx = instr[1], instr[2], instr[3], instr[4]
                kwnames = c.consts[kw_idx]
                kwargs = {kwnames[i]: s.pop() for i in range(len(kwnames) - 1, -1, -1)}
                args = [s.pop() for _ in range(argc)][::-1]
                args = [h._unwrap(a) for a in args]
                kwargs = {kk: h._unwrap(vv) for kk, vv in kwargs.items()}
                if k == 0 and not args and "n" not in kwargs:
                    kwargs["n"] = h.default_n
                fn = sp.PHI[k]
                out = fn(*args, **kwargs)
                s.append(h._as_cell(out, trust=Interpreter._depth_trust(k)))
            elif op == "CALL_FN":
                name = c.names[instr[1]]
                argc, kwargc, kw_idx = instr[2], instr[3], instr[4]
                kwnames = c.consts[kw_idx]
                kwargs = {kwnames[i]: s.pop() for i in range(len(kwnames) - 1, -1, -1)}
                args = [s.pop() for _ in range(argc)][::-1]
                fn_value = h.env.get(name)
                if isinstance(fn_value, Function):
                    s.append(_invoke_fn_value(fn_value, args, kwargs, h))
                elif isinstance(fn_value, CompiledFunction):
                    s.append(fn_value.invoke(args, kwargs, h))
                else:
                    raise NameError(f"{name!r} is not a function")
            elif op == "MAKE_FN":
                fn_idx = instr[1]
                meta = c.fn_meta[fn_idx]
                cf = CompiledFunction(
                    body=c.functions[fn_idx],
                    params=list(meta[1]),
                    refinement=None if meta[2] is None
                    else TypeRef(meta[2][0], float(meta[2][1])),
                    closure=h.env,
                )
                s.append(cf)
            elif op == "BINOP":
                self._binop(instr[1])
            else:
                raise RuntimeError(f"unknown opcode {op!r}")

    def _binop(self, op: str) -> None:
        h = self.host
        s = self.stack
        b = s.pop()
        a = s.pop()
        if op == "meet":
            s.append(h._as_cell(a).meet(h._as_cell(b)))
        elif op == "join":
            s.append(h._as_cell(a).join(h._as_cell(b)))
        elif op == "<=":
            s.append(h._scalar(a) <= h._scalar(b))
        elif op == ">=":
            s.append(h._scalar(a) >= h._scalar(b))
        elif op == "<":
            s.append(h._scalar(a) <  h._scalar(b))
        elif op == ">":
            s.append(h._scalar(a) >  h._scalar(b))
        elif op == "+":
            s.append(h._as_cell(a) + h._as_cell(b))
        elif op == "-":
            s.append(h._as_cell(a) - h._as_cell(b))
        elif op == "*":
            if isinstance(a, (int, float)) and isinstance(b, (int, float)):
                s.append(float(a) * float(b))
            else:
                s.append(h._as_cell(a) * (b if isinstance(b, (int, float)) else h._as_cell(b)))
        elif op == "/":
            if isinstance(a, (int, float)) and isinstance(b, (int, float)):
                s.append(float(a) / float(b))
            else:
                s.append(h._as_cell(a) / (b if isinstance(b, (int, float)) else h._as_cell(b)))
        else:
            raise RuntimeError(f"unknown binop {op!r}")


# ──────────────────────────────────────────────────────────────────────────────
# CompiledFunction — Function but with a CodeObject body
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class CompiledFunction:
    body: CodeObject
    params: list[str]
    refinement: TypeRef | None
    closure: dict[str, Any]

    def invoke(self, args: list[Any], kwargs: dict[str, Any], host: Interpreter) -> Cell:
        if len(args) != len(self.params):
            raise TypeError(
                f"function expects {len(self.params)} args, got {len(args)}"
            )
        new_env: dict[str, Any] = dict(self.closure)
        for p, a in zip(self.params, args):
            new_env[p] = a
        for k, v in kwargs.items():
            new_env[k] = v
        saved_env, saved_yield = host.env, host.yielded
        host.env, host.yielded = new_env, None
        try:
            VM(self.body, host).run()
            result = host.yielded if host.yielded is not None else BOT(host.default_n)
        finally:
            host.env, host.yielded = saved_env, saved_yield
        if self.refinement is not None and not self.refinement.check(result.trust):
            raise TrustError(
                f"return refinement violated: trust={result.trust:.3f} "
                f"⋫ ({self.refinement.op} {self.refinement.threshold})"
            )
        return result


def _invoke_fn_value(
    fn: Function,
    args: list[Any],
    kwargs: dict[str, Any],
    host: Interpreter,
) -> Cell:
    """Fallback: invoke an AST-backed Function from the VM."""
    if len(args) != len(fn.params):
        raise TypeError(f"function expects {len(fn.params)} args, got {len(args)}")
    new_env: dict[str, Any] = dict(fn.closure)
    for p, a in zip(fn.params, args):
        new_env[p] = a
    for k, v in kwargs.items():
        new_env[k] = v
    saved_env, saved_yield = host.env, host.yielded
    host.env, host.yielded = new_env, None
    try:
        for stmt in fn.body:
            host.eval(stmt)
        result = host.yielded if host.yielded is not None else BOT(host.default_n)
    finally:
        host.env, host.yielded = saved_env, saved_yield
    if fn.refinement is not None and not fn.refinement.check(result.trust):
        raise TrustError(
            f"return refinement violated: trust={result.trust:.3f} "
            f"⋫ ({fn.refinement.op} {fn.refinement.threshold})"
        )
    return result


# ──────────────────────────────────────────────────────────────────────────────
# High-level helpers
# ──────────────────────────────────────────────────────────────────────────────
def compile_file(src: Path, force: bool = False) -> Path:
    """Compile ``src`` to ``<src>.solc`` (skipping if cache is fresh)."""
    src = src.resolve()
    out = cache_path(src)
    if not force and cache_is_fresh(src, out):
        return out
    code = Compiler.compile_source(src.read_text(encoding="utf-8"), source_hint=str(src))
    save_solc(code, out)
    return out


def run_file_cached(src: Path, host: Interpreter | None = None) -> Cell | None:
    """Run ``src`` using its bytecode cache, recompiling on a stale cache."""
    src = src.resolve()
    cache = cache_path(src)
    if cache_is_fresh(src, cache):
        code = load_solc(cache)
    else:
        code = Compiler.compile_source(src.read_text(encoding="utf-8"), source_hint=str(src))
        try:
            save_solc(code, cache)
        except OSError:
            pass  # read-only filesystem — that's fine
    host = host or Interpreter(module_path=src)
    VM(code, host).run()
    return host.yielded


def main(argv: list[str]) -> int:
    if "--compile" in argv:
        i = argv.index("--compile")
        path = Path(argv[i + 1])
        out = compile_file(path, force=True)
        print(f"compiled → {out}")
        return 0
    if len(argv) < 2:
        print(__doc__)
        return 0
    path = Path(argv[1])
    out = run_file_cached(path)
    if out is not None:
        print(f"\nyield → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
