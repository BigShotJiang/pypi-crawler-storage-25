"""
soilith_ifc.py — information-flow control and non-interference
(Zone 138).

In an information-flow type system (DCC, Jif, FlowCaml, ifc-style
Haskell) every value carries a *security label* drawn from a
lattice ``L = (Labels, ⊑)`` with ``low ⊑ high``. The fundamental
soundness property is **non-interference**:

    Two runs of the same program on inputs that agree on all
    *low* memory locations must produce outputs that agree on all
    *low* memory locations — no matter what the *high* inputs were.

Σoilith already carries a number on every cell that behaves like an
IFC label: ``trust``. Zone 138 makes that explicit by:

1. labelling each address with ``low`` or ``high`` (the simplest
   two-point lattice — easily generalised);
2. tracking *taint propagation* through φ-operator applications;
3. running the program twice with *agreed-low / disagreed-high*
   inputs and checking that all low outputs agree (empirical
   non-interference test).

Declassification — the only sanctioned way to send a high value to
a low channel — requires a Zone-133 capability with the
``declassify`` right.

CLI
---
    python soilith_ifc.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
import sys
from typing import Any, Callable, Iterable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402
from soilith_phi import PHI  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class IFCError(Exception):
    """Base class for Zone 138 errors."""


class IllegalFlow(IFCError):
    """A high value tried to flow to a low channel without
    declassification."""


class Interference(IFCError):
    """A non-interference check detected a high-input-dependent
    low output (a leak)."""


# ──────────────────────────────────────────────────────────────────────────
#  Labels
# ──────────────────────────────────────────────────────────────────────────
class Label(str, Enum):
    LOW = "low"
    HIGH = "high"

    def joined(self, other: "Label") -> "Label":
        if self == Label.HIGH or other == Label.HIGH:
            return Label.HIGH
        return Label.LOW

    def leq(self, other: "Label") -> bool:
        if self == Label.LOW:
            return True
        return other == Label.HIGH


@dataclass
class LabeledCell:
    cell: Cell
    label: Label


# ──────────────────────────────────────────────────────────────────────────
#  LabeledStore
# ──────────────────────────────────────────────────────────────────────────
class LabeledStore:
    """An IFC-labelled key-value store."""

    def __init__(self) -> None:
        self._cells: dict[str, LabeledCell] = {}

    def declare(self, slot: str, label: Label, value: Cell) -> None:
        self._cells[slot] = LabeledCell(cell=value, label=label)

    def write(self, slot: str, value: Cell, *, with_label: Label) -> None:
        """Write a fresh value at ``slot`` with a fresh label.
        Refuses to *lower* an existing label without a capability."""
        existing = self._cells.get(slot)
        if existing is not None and not existing.label.leq(with_label):
            raise IllegalFlow(
                f"would lower slot {slot!r} from {existing.label.value} "
                f"to {with_label.value}; use declassify(...)"
            )
        self._cells[slot] = LabeledCell(cell=value, label=with_label)

    def read(self, slot: str) -> LabeledCell:
        return self._cells[slot]

    def label_of(self, slot: str) -> Label:
        return self._cells[slot].label

    def low_view(self) -> dict[str, Cell]:
        return {
            s: lc.cell for s, lc in self._cells.items()
            if lc.label == Label.LOW
        }

    def snapshot(self) -> dict[str, LabeledCell]:
        return {
            s: LabeledCell(cell=Cell(
                value=np.asarray(lc.cell.value, dtype=float).copy(),
                trust=lc.cell.trust, phase=lc.cell.phase,
            ), label=lc.label) for s, lc in self._cells.items()
        }

    def restore(self, snap: dict[str, LabeledCell]) -> None:
        self._cells = dict(snap)


# ──────────────────────────────────────────────────────────────────────────
#  Operations
# ──────────────────────────────────────────────────────────────────────────
def apply_phi(
    store: LabeledStore, op: int, *, src: str, dst: str,
) -> None:
    """``dst ← φ_op(src)`` with label = label(src) (the join over
    a single argument). Refuses if writing this label to dst would
    illegally lower it."""
    fn = PHI.get(op)
    if fn is None:
        raise IFCError(f"unknown operator φ_{op}")
    lc = store.read(src)
    x = np.asarray(lc.cell.value, dtype=float).ravel()
    y = np.asarray(fn(x), dtype=float).ravel()
    out_cell = Cell(value=y, trust=lc.cell.trust, phase=lc.cell.phase)
    store.write(dst, out_cell, with_label=lc.label)


def declassify(
    store: LabeledStore,
    slot: str,
    *,
    to_label: Label = Label.LOW,
    capability: Any = None,
) -> None:
    """Lower a slot's label. Requires a Zone-133 capability that
    holds the ``write`` right and a ``min_trust`` ≥ 0.85, or
    ``capability='trusted'`` for tests."""
    if capability != "trusted":
        try:
            from soilith_capability import Capability
            if not isinstance(capability, Capability):
                raise IllegalFlow(
                    "declassification requires a Capability or "
                    "'trusted' sentinel"
                )
            if not capability.has("write") or capability.min_trust < 0.85:
                raise IllegalFlow(
                    "capability has insufficient rights/trust for "
                    "declassification"
                )
        except ImportError:
            raise IllegalFlow("declassification requires Zone 133")
    lc = store.read(slot)
    store._cells[slot] = LabeledCell(cell=lc.cell, label=to_label)


# ──────────────────────────────────────────────────────────────────────────
#  Non-interference check
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class NIReport:
    program_name: str
    low_diff: dict[str, tuple[float, float]] = field(default_factory=dict)

    @property
    def successful(self) -> bool:
        return not self.low_diff

    def describe(self) -> str:
        ok = "✓" if self.successful else "✗"
        out = [f"NIReport {ok}  program={self.program_name}"]
        if not self.low_diff:
            out.append("  no low-output disagreement detected")
        else:
            for slot, (a, b) in self.low_diff.items():
                out.append(f"  · {slot}: run_a={a:.3e}  run_b={b:.3e}")
        return "\n".join(out)


def noninterference_check(
    program: Callable[[LabeledStore], None],
    *,
    high_inputs: dict[str, tuple[Cell, Cell]],
    low_inputs: dict[str, Cell],
    name: str = "<program>",
) -> NIReport:
    """Run ``program`` twice. ``high_inputs[slot] = (cell_a, cell_b)``
    gives the two distinct high values; ``low_inputs[slot] = cell``
    is the shared low input. Both runs end with the program's final
    store; we compare every LOW slot."""
    def fresh(idx: int) -> LabeledStore:
        s = LabeledStore()
        for slot, c in low_inputs.items():
            s.declare(slot, Label.LOW, c)
        for slot, (a, b) in high_inputs.items():
            s.declare(slot, Label.HIGH, a if idx == 0 else b)
        return s

    s_a, s_b = fresh(0), fresh(1)
    program(s_a)
    program(s_b)

    diffs: dict[str, tuple[float, float]] = {}
    for slot in set(s_a._cells) | set(s_b._cells):
        la = s_a._cells.get(slot)
        lb = s_b._cells.get(slot)
        if la is None or lb is None:
            continue
        if la.label != Label.LOW or lb.label != Label.LOW:
            continue
        va = float(np.linalg.norm(np.asarray(la.cell.value, dtype=float)))
        vb = float(np.linalg.norm(np.asarray(lb.cell.value, dtype=float)))
        if abs(va - vb) > 1e-9:
            diffs[slot] = (va, vb)
    return NIReport(program_name=name, low_diff=diffs)


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(report: NIReport, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(len(report.low_diff)),
        1.0 if report.successful else 0.0,
    ], dtype=float)
    trust = 1.0 if report.successful else 0.0
    arena[f"ifc/{_safe(report.program_name)}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


def _safe(name: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in name)[:60]


# ──────────────────────────────────────────────────────────────────────────
#  CLI / Demo
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith information-flow control (Zone 138)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print("# Zone 138 — information-flow control")

    print("\n# 1. label-respecting program (no leak)")
    def clean(store: LabeledStore) -> None:
        # Read low, compute on it, write low. Never touch high.
        apply_phi(store, 38, src="public_input", dst="public_output")

    rep = noninterference_check(
        clean,
        high_inputs={"secret": (
            Cell(value=np.array([1.0]), trust=1.0, phase=0.0),
            Cell(value=np.array([99.0]), trust=1.0, phase=0.0),
        )},
        low_inputs={"public_input":
                    Cell(value=np.array([0.5, 0.25, 0.125, 0.0625]),
                         trust=1.0, phase=0.0)},
        name="clean",
    )
    print(rep.describe())
    persist(rep, args.arena)

    print("\n# 2. leaky program (writes secret to a low slot)")
    def leaky(store: LabeledStore) -> None:
        # Without declassification — refused.
        try:
            store.write(
                "public_output",
                store.read("secret").cell,
                with_label=Label.LOW,
            )
        except IllegalFlow as exc:
            # Bypass via direct mutation (cheating)
            store._cells["public_output"] = LabeledCell(
                cell=store.read("secret").cell, label=Label.LOW,
            )

    rep = noninterference_check(
        leaky,
        high_inputs={"secret": (
            Cell(value=np.array([1.0]), trust=1.0, phase=0.0),
            Cell(value=np.array([99.0]), trust=1.0, phase=0.0),
        )},
        low_inputs={"public_output":
                    Cell(value=np.array([0.0]), trust=1.0, phase=0.0)},
        name="leaky",
    )
    print(rep.describe())
    persist(rep, args.arena)

    print("\n# 3. labelled write refuses to lower without declassify")
    s = LabeledStore()
    s.declare("x", Label.HIGH, Cell(value=np.array([5.0]),
                                    trust=1.0, phase=0.0))
    try:
        s.write("x", Cell(value=np.array([0.0]), trust=1.0, phase=0.0),
                with_label=Label.LOW)
    except IllegalFlow as exc:
        print(f"   ✓ {type(exc).__name__}: {exc}")

    print("\n# 4. declassify with a trusted sentinel succeeds")
    declassify(s, "x", to_label=Label.LOW, capability="trusted")
    print(f"   slot 'x' label is now {s.label_of('x').value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
