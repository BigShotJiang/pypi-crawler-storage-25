"""
soilith_loop_ifc.py — Zone 154

Loop-form non-interference: the intersection of Zone 138 (IFC /
non-interference) and Zone 153 (iteration vocabulary).

The point
---------
Every loop has an iteration count. That count is a LOW-observable
side channel (timing, cache, fuel). A program is *termination-
sensitively* non-interferent iff the iteration count of every loop
is identical across two runs that differ only in HIGH inputs.

Σoilith's six basic loop forms (Zone 153) each have a known a-priori
IFC verdict that depends on what their iteration count is a function
of:

  +---+--------------------------------+--------------------------------+
  | # | Form                           | Iteration count is a function  |
  +---+--------------------------------+--------------------------------+
  | 1 | for-each phi in [phi_a..phi_b] | static range                   |
  | 2 | for-each addr in ball(seed,r)  | (seed, r, k)                   |
  | 3 | for-each page in pages(mem64)  | write history                  |
  | 4 | fixpoint state widen-after k   | transfer-function inputs       |
  | 5 | replay node in graph dirty     | touch pattern                  |
  | 6 | until particles.ess >= theta   | likelihood values              |
  +---+--------------------------------+--------------------------------+

This module:
* classifies each form by its strongest IFC verdict
  (``PROVEN_NI``, ``NI_IF_LOW_PARAMS``, ``NI_IF_LOW_WRITES``,
  ``NI_IF_LOW_TRANSFERS``, ``NI_IF_LOW_TOUCHES``, ``EMPIRICAL``);
* exposes ``iteration_count_ni_check`` which runs a loop factory
  twice (LOW shared, HIGH differing) and asserts the two iteration
  counts agree; and
* persists ``loop_ifc/<form>/<program>`` payloads
  ``[verdict, count_a, count_b, leaked]`` into the arena via
  ``soilith_arena.Arena.open``.

Conformance
-----------
A loop form is admissible under ``loop_ni_strict`` (trust ≥ 1.0)
iff ``noninterfering=True``: the two empirical iteration counts
agree. Forms classified ``EMPIRICAL`` (e.g. particle filters)
*can* leak by design — they must be wrapped by an explicit
``declassify(...)`` from Zone 138 and audited through
``loop_ni_observed`` (trust ≥ 0.0).
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable

import numpy as np

from soilith_lang import Cell


# ──────────────────────────────────────────────────────────────────────────
# Verdicts
# ──────────────────────────────────────────────────────────────────────────
class IFCVerdict(str, Enum):
    PROVEN_NI = "proven_ni"                # form 1
    NI_IF_LOW_PARAMS = "ni_if_low_params"  # form 2
    NI_IF_LOW_WRITES = "ni_if_low_writes"  # form 3
    NI_IF_LOW_TRANSFERS = "ni_if_low_transfers"  # form 4
    NI_IF_LOW_TOUCHES = "ni_if_low_touches"      # form 5
    EMPIRICAL = "empirical"                # form 6


class LoopForm(str, Enum):
    OPERATOR_RANGE = "operator_range"  # for-each phi in [phi_a..phi_b]
    CAYLEY_BALL = "cayley_ball"        # for-each addr in ball(seed, r)
    MEM64_PAGES = "mem64_pages"        # for-each page in pages(mem64)
    FIXPOINT_WIDEN = "fixpoint_widen"  # fixpoint state widen-after k
    DAG_REPLAY = "dag_replay"          # replay node dirty-only
    ESS_RESAMPLE = "ess_resample"      # until particles.ess >= theta


VERDICT_OF: dict[LoopForm, IFCVerdict] = {
    LoopForm.OPERATOR_RANGE: IFCVerdict.PROVEN_NI,
    LoopForm.CAYLEY_BALL: IFCVerdict.NI_IF_LOW_PARAMS,
    LoopForm.MEM64_PAGES: IFCVerdict.NI_IF_LOW_WRITES,
    LoopForm.FIXPOINT_WIDEN: IFCVerdict.NI_IF_LOW_TRANSFERS,
    LoopForm.DAG_REPLAY: IFCVerdict.NI_IF_LOW_TOUCHES,
    LoopForm.ESS_RESAMPLE: IFCVerdict.EMPIRICAL,
}


def classify_loop_form(form: LoopForm) -> IFCVerdict:
    """Return the a-priori IFC verdict for a given loop form."""
    return VERDICT_OF[form]


# ──────────────────────────────────────────────────────────────────────────
# The 2-trace iteration-count check
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class LoopNIReport:
    form: LoopForm
    program_name: str
    verdict: IFCVerdict
    count_a: int
    count_b: int
    high_keys: tuple[str, ...] = ()
    low_keys: tuple[str, ...] = ()
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def leaked(self) -> bool:
        """A leak is any disagreement in iteration count when only
        HIGH inputs changed between the two runs."""
        return self.count_a != self.count_b

    @property
    def noninterfering(self) -> bool:
        return not self.leaked

    def describe(self) -> str:
        ok = "✓" if self.noninterfering else "✗"
        return (
            f"LoopNIReport {ok}  form={self.form.value}  "
            f"program={self.program_name}\n"
            f"  verdict       : {self.verdict.value}\n"
            f"  count_a       : {self.count_a}\n"
            f"  count_b       : {self.count_b}\n"
            f"  leaked        : {self.leaked}\n"
            f"  high_keys     : {list(self.high_keys)}\n"
            f"  low_keys      : {list(self.low_keys)}"
        )


def iteration_count_ni_check(
    loop_factory: Callable[[dict[str, Any], dict[str, Any]], int],
    *,
    high_inputs: dict[str, tuple[Any, Any]],
    low_inputs: dict[str, Any],
    form: LoopForm,
    name: str,
) -> LoopNIReport:
    """Run ``loop_factory(high, low)`` twice with the two HIGH
    variants and the same LOW inputs. Each call must return the
    iteration count it executed. The two counts are then compared.

    ``loop_factory`` receives **fresh** dicts on each invocation so
    side-effects on mutable inputs don't leak between runs.
    """
    high_a = {k: v[0] for k, v in high_inputs.items()}
    high_b = {k: v[1] for k, v in high_inputs.items()}

    def _fresh_low() -> dict[str, Any]:
        out: dict[str, Any] = {}
        for k, v in low_inputs.items():
            if isinstance(v, Cell):
                out[k] = Cell(
                    value=np.asarray(v.value, dtype=float).copy(),
                    trust=v.trust, phase=v.phase,
                )
            elif isinstance(v, np.ndarray):
                out[k] = v.copy()
            else:
                out[k] = v
        return out

    count_a = int(loop_factory(high_a, _fresh_low()))
    count_b = int(loop_factory(high_b, _fresh_low()))

    return LoopNIReport(
        form=form,
        program_name=name,
        verdict=classify_loop_form(form),
        count_a=count_a,
        count_b=count_b,
        high_keys=tuple(sorted(high_inputs.keys())),
        low_keys=tuple(sorted(low_inputs.keys())),
    )


# ──────────────────────────────────────────────────────────────────────────
# Sabelfeld–Sands channel mapping  (Zone 154 × Zone 151)
# ──────────────────────────────────────────────────────────────────────────
class SSChannel(str, Enum):
    """The four channels of Sabelfeld & Sands (2000), §3.2,
    lifted onto Σoilith's loop-form vocabulary."""
    LOOP_BOUND = "ss_channel_1_loop_bound"          # forms 1, 3
    OUTER_SCHEDULE = "ss_channel_2_outer_schedule"  # form 4
    TOUCH_PATTERN = "ss_channel_3_touch_pattern"    # forms 2, 5
    DATA_DEPENDENT = "ss_channel_4_iteration_bound"  # form 6


CHANNEL_OF: dict[LoopForm, SSChannel] = {
    LoopForm.OPERATOR_RANGE: SSChannel.LOOP_BOUND,
    LoopForm.CAYLEY_BALL: SSChannel.TOUCH_PATTERN,
    LoopForm.MEM64_PAGES: SSChannel.LOOP_BOUND,
    LoopForm.FIXPOINT_WIDEN: SSChannel.OUTER_SCHEDULE,
    LoopForm.DAG_REPLAY: SSChannel.TOUCH_PATTERN,
    LoopForm.ESS_RESAMPLE: SSChannel.DATA_DEPENDENT,
}


def channel_of(form: LoopForm) -> SSChannel:
    """Return the Sabelfeld–Sands channel for a loop form."""
    return CHANNEL_OF[form]


def discharge_loop_form_ni(
    form: LoopForm,
    *,
    leak: bool = False,
    closure_sizes: list[int] | None = None,
    low_node: int = 0,
    low_n_writes: int = 1,
    low_n_runs: int = 1,
    iters_per_run: int = 1,
    max_iter: int = 1,
    k_bits: int = 32,
    sign: bool = False,
) -> dict[str, Any]:
    """Discharge the Sabelfeld–Sands NI obligation for ``form`` via Z3.

    Returns ``{"channel", "result", "attestation"}`` where:

    * ``channel`` is the ``SSChannel`` enum value;
    * ``result`` is a ``Z3VerifyResult`` (verified=True ⇔ UNSAT
      on negation ⇔ termination-sensitive NI proven for this
      footprint pair);
    * ``attestation`` is the PQC/MVPS-signed attestation dict
      produced by ``soilith_z3verify.sign_with_pqc`` (only when
      ``sign=True``; otherwise ``None``).

    ``leak=True`` selects the leaky variant of the model (HIGH
    drives the relevant input). For forms whose backing channel
    is ``DATA_DEPENDENT`` (Form 6), the discharge is the *safety*
    property ``c ≤ max_iter`` — the only mechanically checkable
    obligation for an irreducibly empirical loop form.
    """
    try:
        from soilith_z3verify import (
            verify_loop_bound_ni,
            verify_outer_schedule_ni,
            verify_touch_pattern_ni,
            verify_iteration_bound,
            sign_with_pqc,
            Z3VerifyError,
        )
    except ImportError as exc:
        raise RuntimeError(
            f"Zone 151 Z3 verifier not available: {exc}"
        )

    channel = channel_of(form)
    if channel == SSChannel.LOOP_BOUND:
        result = verify_loop_bound_ni(
            high_drives_bound=leak,
            low_n_writes=low_n_writes,
            k_bits=k_bits,
        )
    elif channel == SSChannel.OUTER_SCHEDULE:
        result = verify_outer_schedule_ni(
            high_drives_schedule=leak,
            low_n_runs=low_n_runs,
            iters_per_run=iters_per_run,
            k_bits=k_bits,
        )
    elif channel == SSChannel.TOUCH_PATTERN:
        if closure_sizes is None:
            raise ValueError(
                "TOUCH_PATTERN channel requires closure_sizes"
            )
        result = verify_touch_pattern_ni(
            closure_sizes=closure_sizes,
            high_drives_touch=leak,
            low_node=low_node,
        )
    else:  # DATA_DEPENDENT
        result = verify_iteration_bound(
            max_iter=max_iter, k_bits=k_bits,
        )

    attestation: dict[str, Any] | None = None
    if sign:
        try:
            attestation = sign_with_pqc(result)
        except Z3VerifyError:
            attestation = None
    return {
        "channel": channel,
        "result": result,
        "attestation": attestation,
    }


# ──────────────────────────────────────────────────────────────────────────
# Persistence
# ──────────────────────────────────────────────────────────────────────────
def _safe(name: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in name)[:60]


def persist(report: LoopNIReport, arena_path: Path) -> None:
    """Write the report into the arena under
    ``loop_ifc/<form>/<program>``. Trust 1.0 iff non-interfering;
    trust 0.0 if a leak was detected. The diagnostic ``EMPIRICAL``
    verdict still records trust 0.0 on leak so external auditors see
    the channel."""
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(report.count_a),
        float(report.count_b),
        1.0 if report.leaked else 0.0,
        float(list(IFCVerdict).index(report.verdict)),
    ], dtype=float)
    trust = 1.0 if report.noninterfering else 0.0
    slot = (
        f"loop_ifc/{report.form.value}/{_safe(report.program_name)}"
    )
    arena[slot] = Cell(value=payload, trust=trust, phase=0.0)


# ──────────────────────────────────────────────────────────────────────────
# Built-in factories for the six forms (used by tests and the CLI demo)
# ──────────────────────────────────────────────────────────────────────────
def factory_operator_range(
    a: int = 0, b: int = 40,
) -> Callable[[dict[str, Any], dict[str, Any]], int]:
    """Form 1 — iteration count is the static range size."""
    from soilith_phi import PHI

    def _go(high: dict[str, Any], low: dict[str, Any]) -> int:
        # Read HIGH only as a payload, never as a loop bound, to
        # demonstrate proven non-interference of the count itself.
        n = 0
        for k in range(a, b + 1):
            _ = PHI[k]
            n += 1
        return n
    return _go


def factory_cayley_ball() -> (
    Callable[[dict[str, Any], dict[str, Any]], int]
):
    """Form 2 — count = |ball(seed, r)| in (Z/2)^k. NI iff seed
    and r are LOW; HIGH must only carry the cell *payload*."""
    from soilith_sparse import SparseScaleMemory

    def _go(high: dict[str, Any], low: dict[str, Any]) -> int:
        k: int = int(low["k"])
        r: int = int(low["r"])
        seed: str = str(low["seed"])
        mem = SparseScaleMemory(k=k)
        # HIGH payload — value only; never used as a bound.
        cell = Cell(
            value=np.asarray(high["payload"], dtype=float),
            trust=1.0, phase=0.0,
        )
        mem.write(seed, cell)
        return len(mem.ball(seed, r))
    return _go


def factory_fixpoint_widen(
    *, leak: bool = False,
) -> Callable[[dict[str, Any], dict[str, Any]], int]:
    """Form 4 — count = total #widening iterations summed across
    one or more invocations of the fixpoint engine.

    ``leak=False``: HIGH never enters the analyser invocation
    schedule; iteration count is determined entirely by LOW.

    ``leak=True``: HIGH controls how many times the analyser is
    invoked (``for _ in range(HIGH): analyse(cfg)``). This is the
    most common real-world iteration-count covert channel: a
    secret-dependent outer loop wrapping an analysis. The two
    runs visibly disagree and ``loop_ni_strict`` refuses.
    """
    from soilith_intervals import (
        Interval, Stmt, Block, CFG, analyse,
    )

    cfg = CFG(
        entry="entry",
        blocks={
            "entry": Block(
                name="entry",
                stmts=[Stmt(kind=("const", "x", 0.0))],
                succs=["head"]),
            "head": Block(
                name="head",
                stmts=[
                    Stmt(kind=("join_in", "x",
                                ["entry.x", "body.x"])),
                    Stmt(kind=("widen", "x", "x")),
                ],
                succs=["body"]),
            "body": Block(
                name="body",
                stmts=[Stmt(kind=("phi", "x", 38, "x"))],
                succs=["head"]),
        },
    )

    def _go(high: dict[str, Any], low: dict[str, Any]) -> int:
        if leak:
            n_runs = int(np.asarray(
                high["secret"], dtype=float).ravel()[0])
        else:
            n_runs = int(low["n_runs"])
        total = 0
        for _ in range(max(1, n_runs)):
            rep = analyse(
                cfg, initial={"x": Interval.of(0.0)},
                widen_after=3, max_iter=32,
            )
            total += rep.iterations
        return total
    return _go


def factory_mem64_pages(
    *, leak: bool = False,
) -> Callable[[dict[str, Any], dict[str, Any]], int]:
    """Form 3 — count = #allocated pages in the 64-bit trie.

    ``leak=False``: every write goes to a LOW-determined address; the
    page count is identical across HIGH variants because the HIGH
    payload only contributes the *cell value*, never the address.

    ``leak=True``: the *number* (and therefore the addresses) of
    writes is HIGH-determined, so the populated-page count differs
    across runs — the canonical "amount of work" iteration-count
    channel.
    """
    from soilith_64bit import Memory64, Capability

    def _go(high: dict[str, Any], low: dict[str, Any]) -> int:
        page_bits = int(low["page_bits"])
        n_low_writes = int(low["n_low_writes"])
        base = int(low["base"])
        stride = int(low["stride"])
        if leak:
            n_writes = int(np.asarray(
                high["secret"], dtype=float).ravel()[0])
        else:
            n_writes = n_low_writes
        mem = Memory64(page_bits=page_bits, tlb_size=64)
        cap = Capability(base=0, length=1 << 62, perms="RW")
        for i in range(n_writes):
            payload = np.asarray(
                high.get("payload", np.array([float(i)])),
                dtype=float,
            )
            mem.write(
                base + i * stride,
                Cell(value=payload, trust=1.0, phase=0.0),
                cap=cap,
            )
        return sum(1 for _ in mem.iter_pages())
    return _go


def factory_dag_replay(
    *, leak: bool = False,
) -> Callable[[dict[str, Any], dict[str, Any]], int]:
    """Form 5 — count = number of recomputed nodes (|dirty set|).

    ``leak=False``: the set of nodes that get touched between
    replays is LOW-determined (a fixed audit walk over the
    graph). The dirty-set size is identical across HIGH variants.

    ``leak=True``: HIGH selects *which* node to touch. Touching a
    leaf vs an interior node yields very different dirty-set sizes
    in a fan-out graph — a textbook touch-pattern covert channel.
    """
    from soilith_incremental import Graph

    def _build() -> Graph:
        g = Graph()
        g.add("a", lambda env: 1)
        g.add("b", lambda env: env["a"] + 1, deps=("a",))
        g.add("c", lambda env: env["b"] * 2, deps=("b",))
        g.add("d", lambda env: env["c"] + env["a"], deps=("c", "a"))
        g.add("e", lambda env: env["d"] - 1, deps=("d",))
        g.replay()
        return g

    def _go(high: dict[str, Any], low: dict[str, Any]) -> int:
        g = _build()
        if leak:
            touch_key = str(high["secret"])
        else:
            touch_key = str(low["touch_key"])
        g.touch(touch_key)
        rep = g.replay()
        return rep.recomputed
    return _go


def factory_ess_resample() -> (
    Callable[[dict[str, Any], dict[str, Any]], int]
):
    """Form 6 — count = #resamples to reach ESS threshold. This is
    *intentionally* HIGH-dependent: the form's a-priori verdict is
    ``EMPIRICAL`` and a leak here is expected unless the iteration
    count is declassified."""
    from soilith_prob import Particle, Population

    def _go(high: dict[str, Any], low: dict[str, Any]) -> int:
        n_particles = int(low["n_particles"])
        threshold = float(low["threshold"])
        max_iter = int(low["max_iter"])
        sharpness = float(np.asarray(
            high["sharpness"], dtype=float).ravel()[0])
        rng = np.random.default_rng(seed=int(low["seed"]))
        parts = [
            Particle(
                state={"x": float(rng.normal(scale=3.0))},
                log_weight=0.0,
            )
            for _ in range(n_particles)
        ]
        pop = Population(particles=parts)
        pop.observe(
            lambda p: -sharpness * ((p.state["x"] - 0.5) ** 2))
        iters = 0
        while (pop.effective_sample_size() < threshold
               and iters < max_iter):
            pop.resample(rng=rng)
            pop.observe(
                lambda p: -0.5 * ((p.state["x"] - 0.5) ** 2))
            iters += 1
        return iters
    return _go


# ──────────────────────────────────────────────────────────────────────────
# CLI / Demo
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith loop-form non-interference (Zone 154)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    print("# Zone 154 — loop-form non-interference")

    # Form 1 — PROVEN_NI: count is the static range.
    rep1 = iteration_count_ni_check(
        factory_operator_range(0, 40),
        high_inputs={"secret_payload": (
            Cell(value=np.array([1.0]), trust=1.0, phase=0.0),
            Cell(value=np.array([99.0]), trust=1.0, phase=0.0),
        )},
        low_inputs={},
        form=LoopForm.OPERATOR_RANGE,
        name="audit_all_phi",
    )
    print("\n[Form 1 — operator range]")
    print(rep1.describe())
    persist(rep1, args.arena)

    # Form 2 — NI_IF_LOW_PARAMS: seed and r are LOW; HIGH is only payload.
    k = 8
    rep2 = iteration_count_ni_check(
        factory_cayley_ball(),
        high_inputs={"payload": (
            np.array([1.0]), np.array([99.0]),
        )},
        low_inputs={"k": k, "r": 2, "seed": "0" * k},
        form=LoopForm.CAYLEY_BALL,
        name="touch_neighbours",
    )
    print("\n[Form 2 — Cayley ball with LOW params]")
    print(rep2.describe())
    persist(rep2, args.arena)

    # Form 4 — NI_IF_LOW_TRANSFERS: HIGH never controls the schedule.
    rep4 = iteration_count_ni_check(
        factory_fixpoint_widen(leak=False),
        high_inputs={"secret": (np.array([1.0]), np.array([99.0]))},
        low_inputs={"n_runs": 1},
        form=LoopForm.FIXPOINT_WIDEN,
        name="analyse_loop_clean",
    )
    print("\n[Form 4 — fixpoint, HIGH outside schedule (clean)]")
    print(rep4.describe())
    persist(rep4, args.arena)

    # Form 4 — leak witness: HIGH controls the outer schedule.
    rep4l = iteration_count_ni_check(
        factory_fixpoint_widen(leak=True),
        high_inputs={"secret": (np.array([1.0]), np.array([8.0]))},
        low_inputs={},
        form=LoopForm.FIXPOINT_WIDEN,
        name="analyse_loop_leaky",
    )
    print("\n[Form 4 — fixpoint, HIGH drives schedule (leaky)]")
    print(rep4l.describe())
    persist(rep4l, args.arena)

    # Form 3 — NI_IF_LOW_WRITES: write count is LOW; HIGH is payload.
    rep3 = iteration_count_ni_check(
        factory_mem64_pages(leak=False),
        high_inputs={"payload": (
            np.array([1.0]), np.array([99.0]))},
        low_inputs={
            "page_bits": 6, "n_low_writes": 64,
            "base": 0x4000_0000_0000, "stride": 64,
        },
        form=LoopForm.MEM64_PAGES,
        name="audit_pages_clean",
    )
    print("\n[Form 3 — mem64 pages, HIGH is payload (clean)]")
    print(rep3.describe())
    persist(rep3, args.arena)

    # Form 3 — leak witness: HIGH controls #writes (and thus pages).
    rep3l = iteration_count_ni_check(
        factory_mem64_pages(leak=True),
        high_inputs={"secret": (np.array([16.0]), np.array([64.0]))},
        low_inputs={
            "page_bits": 6, "n_low_writes": 0,
            "base": 0x4000_0000_0000, "stride": 4096,
        },
        form=LoopForm.MEM64_PAGES,
        name="audit_pages_leaky",
    )
    print("\n[Form 3 — mem64 pages, HIGH drives #writes (leaky)]")
    print(rep3l.describe())
    persist(rep3l, args.arena)

    # Form 5 — NI_IF_LOW_TOUCHES: same node touched in both runs.
    rep5 = iteration_count_ni_check(
        factory_dag_replay(leak=False),
        high_inputs={"payload": (
            np.array([1.0]), np.array([99.0]))},
        low_inputs={"touch_key": "c"},
        form=LoopForm.DAG_REPLAY,
        name="rebuild_clean",
    )
    print("\n[Form 5 — DAG replay, HIGH outside touch (clean)]")
    print(rep5.describe())
    persist(rep5, args.arena)

    # Form 5 — leak witness: HIGH picks which node to touch.
    rep5l = iteration_count_ni_check(
        factory_dag_replay(leak=True),
        high_inputs={"secret": ("e", "a")},
        low_inputs={},
        form=LoopForm.DAG_REPLAY,
        name="rebuild_leaky",
    )
    print("\n[Form 5 — DAG replay, HIGH picks touch (leaky)]")
    print(rep5l.describe())
    persist(rep5l, args.arena)

    # Form 6 — EMPIRICAL: count is HIGH-dependent by design.
    rep6 = iteration_count_ni_check(
        factory_ess_resample(),
        high_inputs={"sharpness": (np.array([0.5]), np.array([5.0]))},
        low_inputs={
            "n_particles": 128, "threshold": 0.9 * 128,
            "max_iter": 16, "seed": 42,
        },
        form=LoopForm.ESS_RESAMPLE,
        name="infer_posterior",
    )
    print("\n[Form 6 — particle filter (EMPIRICAL, expected leak)]")
    print(rep6.describe())
    persist(rep6, args.arena)

    # ── Z3 discharge of the four Sabelfeld–Sands channels ────────────
    # Each loop form's iteration-count NI is now machine-checked by
    # the same Z3 + AegisOps SMT pipeline that already certifies
    # Zone 151's Cayley/frame/AI judgments. The discharge returns
    # UNSAT on the negation (NI proven) or a concrete (h_a, h_b)
    # counterexample (leak witness), with a PQC/MVPS attestation.
    print("\n# ──────────────────────────────────────────────")
    print("# Z3 discharge of Sabelfeld–Sands channels")
    print("# ──────────────────────────────────────────────")
    discharges = [
        ("Form 1 clean",
         LoopForm.OPERATOR_RANGE,
         {"leak": False, "low_n_writes": 41}),
        ("Form 3 leak (LOOP_BOUND)",
         LoopForm.MEM64_PAGES,
         {"leak": True, "low_n_writes": 64}),
        ("Form 4 clean (OUTER_SCHEDULE)",
         LoopForm.FIXPOINT_WIDEN,
         {"leak": False, "low_n_runs": 1, "iters_per_run": 2}),
        ("Form 4 leak (OUTER_SCHEDULE)",
         LoopForm.FIXPOINT_WIDEN,
         {"leak": True, "low_n_runs": 1, "iters_per_run": 2}),
        ("Form 5 leak (TOUCH_PATTERN, DAG fan-out)",
         LoopForm.DAG_REPLAY,
         {"leak": True,
          "closure_sizes": [5, 4, 3, 2, 1],
          "low_node": 0}),
        ("Form 5 clean (TOUCH_PATTERN, low pick)",
         LoopForm.DAG_REPLAY,
         {"leak": False,
          "closure_sizes": [5, 4, 3, 2, 1],
          "low_node": 2}),
        ("Form 6 (DATA_DEPENDENT, bound only)",
         LoopForm.ESS_RESAMPLE,
         {"max_iter": 16}),
    ]
    for label, form, kwargs in discharges:
        d = discharge_loop_form_ni(form, sign=True, **kwargs)
        r = d["result"]
        print(f"\n[{label}]  → channel={d['channel'].value}")
        print(f"  {r.describe()}")
        if d["attestation"]:
            sig = str(d["attestation"].get("signature", ""))
            sig_preview = sig[:24] + "…" if len(sig) > 24 else sig
            print(
                f"  attested by signer={d['attestation']['signer_id']} "
                f"type={d['attestation']['attestation_type']} "
                f"sig={sig_preview}"
            )

    print("\n# Persisted to:", args.arena)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
