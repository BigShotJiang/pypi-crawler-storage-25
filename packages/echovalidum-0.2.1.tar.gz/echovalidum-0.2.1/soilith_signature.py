"""
soilith_signature.py — empirical categorical type inference for Σoilith
φ-operators (Zone 126, part 1).

Zone 125 ended on an honest dead end: the discovered capsule-symmetry
set didn't form a group because some operators changed cell shape and
others had no finite order at the probe horizon used. Zone 126
upgrades the analysis by first asking, for each operator, **what is
its categorical type?** — i.e. how does the output size depend on the
input size?

We probe each operator at several cell sizes ``n ∈ {4, 6, 8, 12, 16,
24}``, fit a linear model ``y.size = a · n + b`` to the resulting
``(n, y.size)`` pairs, and classify into one of these kinds:

* ``endo``      a = 1, b = 0          x → y, ``len(y) == len(x)``
* ``scale_up``  a integer ≥ 2, b = 0  x → y, ``len(y) == a·len(x)``
* ``scale_down`` a = 1/d, b ∈ {0, 1}  x → y, ``len(y) ≈ ⌈len(x)/d⌉``
* ``affine``    a, b consistent, but
                not in the canonical
                family above           x → y, ``len(y) = a·len(x)+b``
* ``dynamic``   no consistent linear
                fit                    output size depends on values
* ``failed``    operator raised or
                produced non-real
                output                 excluded from every closure

A small ``Signature`` record carries the fit and a slot-safe canonical
name (``endo``, ``scale_up_2``, ``scale_down_2``, ``affine_3_1``,
``dynamic``, ``failed``) so the typed closure engine (part 2) can
bucket operators by *shape morphism class* before attempting any
composition.

The catalog reader (``soilith_catalog._signature_entry``) files every
``signature/phi_<k>`` cell under ``zone: "126"``.

CLI
---
    python soilith_signature.py
    python soilith_signature.py --indices 2 38 41 45 59
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from fractions import Fraction
from pathlib import Path
import sys
from typing import Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_arena import Arena  # noqa: E402
from soilith_lang import Cell  # noqa: E402
from soilith_phi import PHI  # noqa: E402


# Slot kind → integer code (persisted in the cell payload so a reader
# without strings can still recover the verdict).
KIND_CODES: dict[str, int] = {
    "endo":        0,
    "scale_up":    1,
    "scale_down":  2,
    "affine":      3,
    "dynamic":     4,
    "failed":      5,
}
CODE_TO_KIND: dict[int, str] = {v: k for k, v in KIND_CODES.items()}


@dataclass
class Signature:
    op_index: int
    kind: str
    a_num: int            # ``a = a_num / a_den`` — the slope
    a_den: int
    b: int                # additive offset (after rounding)
    samples: int          # number of (n, y.size) pairs that succeeded
    examples: list[tuple[int, int]] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    @property
    def canonical_name(self) -> str:
        if self.kind == "endo":
            return "endo"
        if self.kind == "scale_up":
            return f"scale_up_{self.a_num}"
        if self.kind == "scale_down":
            return f"scale_down_{self.a_den}"
        if self.kind == "affine":
            return f"affine_{self.a_num}_{self.a_den}_{self.b}"
        return self.kind


# ──────────────────────────────────────────────────────────────────────────
#  Sample battery
# ──────────────────────────────────────────────────────────────────────────
def _battery(
    cell_sizes: tuple[int, ...] = (4, 6, 8, 12, 16, 24),
    trials_per_size: int = 3,
    seed: int = 7,
) -> list[np.ndarray]:
    rng = np.random.default_rng(seed)
    out: list[np.ndarray] = []
    for n in cell_sizes:
        for _ in range(trials_per_size):
            out.append(rng.standard_normal(n) * 0.7)
    return out


def _try_call(op: Callable, x: np.ndarray) -> np.ndarray | None:
    """Apply ``op`` and return a ravelled real ``ndarray``, or ``None``
    on any failure (exception, complex output, shape that can't be
    raveled coherently)."""
    try:
        y = op(np.asarray(x, dtype=float))
    except Exception:
        return None
    if isinstance(y, tuple):
        parts = [np.asarray(p) for p in y]
        if any(np.iscomplexobj(p) for p in parts):
            return None
        try:
            y = np.concatenate([p.astype(float).ravel() for p in parts])
        except Exception:
            return None
    y = np.asarray(y)
    if np.iscomplexobj(y):
        return None
    try:
        y = y.astype(np.float64, copy=False).ravel()
    except Exception:
        return None
    if not np.all(np.isfinite(y)):
        return None
    return y


# ──────────────────────────────────────────────────────────────────────────
#  Inference
# ──────────────────────────────────────────────────────────────────────────
def infer(
    op: Callable,
    op_index: int,
    *,
    cell_sizes: tuple[int, ...] = (4, 6, 8, 12, 16, 24),
    trials_per_size: int = 3,
    seed: int = 7,
) -> Signature:
    samples = _battery(cell_sizes, trials_per_size, seed=seed)
    pairs: list[tuple[int, int]] = []
    notes: list[str] = []
    fails = 0
    for x in samples:
        y = _try_call(op, x)
        if y is None:
            fails += 1
            continue
        pairs.append((x.size, y.size))
    if not pairs:
        return Signature(
            op_index=op_index, kind="failed",
            a_num=0, a_den=1, b=0,
            samples=0, examples=[], notes=["all probes failed"],
        )

    # Fit a · n + b with a, b rational where possible.
    if all(p[1] == p[0] for p in pairs):
        return Signature(
            op_index=op_index, kind="endo",
            a_num=1, a_den=1, b=0,
            samples=len(pairs), examples=pairs[:3], notes=notes,
        )
    if all(p[0] > 0 and p[1] % p[0] == 0 for p in pairs):
        ratios = {p[1] // p[0] for p in pairs}
        if len(ratios) == 1 and next(iter(ratios)) >= 2:
            return Signature(
                op_index=op_index, kind="scale_up",
                a_num=int(next(iter(ratios))), a_den=1, b=0,
                samples=len(pairs), examples=pairs[:3], notes=notes,
            )
    # scale_down: y.size = ceil(x.size / d) for some integer d ≥ 2.
    for d in range(2, 17):
        if all(p[1] == -(-p[0] // d) for p in pairs):
            return Signature(
                op_index=op_index, kind="scale_down",
                a_num=1, a_den=d, b=0,
                samples=len(pairs), examples=pairs[:3], notes=notes,
            )

    # Try a linear best fit y = a n + b with rational a.
    distinct_sizes = sorted({p[0] for p in pairs})
    if len(distinct_sizes) >= 2:
        per_n_out = {
            n: {p[1] for p in pairs if p[0] == n} for n in distinct_sizes
        }
        if all(len(v) == 1 for v in per_n_out.values()):
            outs = [(n, next(iter(per_n_out[n]))) for n in distinct_sizes]
            n0, y0 = outs[0]
            n1, y1 = outs[-1]
            try:
                a_frac = Fraction(y1 - y0, n1 - n0)
            except ZeroDivisionError:
                a_frac = None
            if a_frac is not None:
                b_val = y0 - a_frac * n0
                if b_val.denominator == 1 and all(
                    Fraction(y) == a_frac * n + b_val for n, y in outs
                ):
                    return Signature(
                        op_index=op_index, kind="affine",
                        a_num=a_frac.numerator,
                        a_den=a_frac.denominator,
                        b=int(b_val), samples=len(pairs),
                        examples=pairs[:3], notes=notes,
                    )

    return Signature(
        op_index=op_index, kind="dynamic",
        a_num=0, a_den=1, b=0,
        samples=len(pairs), examples=pairs[:3],
        notes=["no consistent linear (n, y.size) fit"],
    )


def infer_all(indices: list[int] | None = None) -> dict[int, Signature]:
    if indices is None:
        indices = sorted(PHI.keys())
    return {k: infer(PHI[k], k) for k in indices}


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(arena_path: Path, signatures: dict[int, Signature]) -> None:
    """Write a ``signature/phi_<k>`` cell for every signature with
    payload ``[kind_code, a_num, a_den, b, samples]`` and trust 1.0
    (the inference is deterministic on a fixed seed and battery)."""
    a = Arena.open(arena_path, autoflush=False)
    for k, sig in signatures.items():
        slot = f"signature/phi_{k}"
        a[slot] = Cell(
            value=np.array(
                [
                    float(KIND_CODES.get(sig.kind, 5)),
                    float(sig.a_num),
                    float(sig.a_den),
                    float(sig.b),
                    float(sig.samples),
                ],
                dtype=float,
            ),
            trust=1.0,
            phase=0.0,
        )
    a.flush()


# ──────────────────────────────────────────────────────────────────────────
#  Convenience: bucket by signature
# ──────────────────────────────────────────────────────────────────────────
def bucket_by_kind(
    signatures: dict[int, Signature],
) -> dict[str, list[int]]:
    out: dict[str, list[int]] = {k: [] for k in KIND_CODES}
    for k, s in signatures.items():
        out.setdefault(s.kind, []).append(k)
    for v in out.values():
        v.sort()
    return out


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith categorical type inference (Zone 126)."
    )
    p.add_argument(
        "--arena", type=Path,
        default=Path(__file__).resolve().parent / "lawbook.arena",
    )
    p.add_argument(
        "--indices", type=int, nargs="*", default=None,
        help="Restrict to specific operator indices; default = all.",
    )
    p.add_argument("--no-persist", action="store_true")
    args = p.parse_args(argv)

    sigs = infer_all(args.indices)
    buckets = bucket_by_kind(sigs)

    print(f"# inferred {len(sigs)} signature(s):")
    for kind in ("endo", "scale_up", "scale_down", "affine", "dynamic", "failed"):
        ks = buckets.get(kind, [])
        if ks:
            print(f"   {kind:10s} ({len(ks):3d}) : {ks}")

    print("\n# canonical names (first 12):")
    for k in sorted(sigs)[:12]:
        s = sigs[k]
        ex = ", ".join(f"({n}→{m})" for n, m in s.examples)
        print(f"   φ_{k:<3d} = {s.canonical_name:<22s}  e.g. {ex}")

    if not args.no_persist:
        persist(args.arena, sigs)
        print(f"\n# persisted {len(sigs)} signature/* cells → {args.arena}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
