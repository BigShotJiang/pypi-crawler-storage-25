"""
soilith_discover.py — Σoilith autonomous discovery engine (Zone 116).

She conjectures relationships over her own ``φ``-operator algebra and tests
each on random ψ-cells. Surviving conjectures become both *human-readable*
Σoilith source (printed to stdout, optionally written to ``stdlib/discovered.sol``)
and *machine-loadable* ψ-cells persisted into a lawbook arena.

The engine has **zero prior knowledge** of which laws hold — it enumerates
blindly and lets numerics adjudicate. That is what makes the output
discovery rather than confirmation.

Law shapes currently tested
---------------------------
    involution:  φ_a(φ_a(x))       ≈ x
    identity:    φ_a(φ_b(x))       ≈ x                 (a ≠ b)
    zero:        φ_a(φ_b(x))       ≈ 0                 (annihilator)
    commute:     φ_a(φ_b(x))       ≈ φ_b(φ_a(x))       (a ≠ b)

A residual is the relative-L2 error between the two sides, averaged over a
diverse battery of random ψ-cells (Gaussian, uniform, sinusoidal, DC). A
law is *believed* iff its mean residual falls below the configurable
threshold; its trust is ``max(0, 1 - residual)`` so the standard refinement
type ``ψ{trust ≥ θ}`` can gate adoption downstream.

CLI
---
    python soilith_discover.py
    python soilith_discover.py --threshold 0.02 --trials 24
    python soilith_discover.py --write stdlib/discovered.sol --lawbook lawbook.arena
"""

from __future__ import annotations

import argparse
import math
from dataclasses import dataclass
from pathlib import Path
import sys
from typing import Optional

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_phi import PHI  # noqa: E402
from soilith_arena import Arena  # noqa: E402
from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Data model
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Law:
    """One conjecture + its empirical posterior."""

    name: str
    lhs: str           # Σoilith expression body
    rhs: str           # textual RHS ("x", "zero", or another expression)
    kind: str          # involution | identity | zero | commute
    residual: float    # mean relative-L2 error
    trust: float       # 1 - residual, clamped
    trials: int

    def as_sol(self) -> str:
        """Render as a doc-commented Σoilith fn (drop-in for stdlib/discovered.sol)."""
        return (
            f"# {self.kind:<10s} "
            f"residual={self.residual:.3e}  trust={self.trust:.3f}  trials={self.trials}\n"
            f"#   {self.lhs}  ≈  {self.rhs}\n"
            f"fn {self.name}(x):\n"
            f"    yield {self.lhs}\n"
            f"end\n"
        )

    def as_cell(self) -> Cell:
        """Pack the law into a ψ-cell so refinement types can gate adoption."""
        return Cell(
            value=np.array([self.residual, float(self.trials)]),
            trust=self.trust,
            phase=0.0,
        )


# ──────────────────────────────────────────────────────────────────────────
#  Numerics
# ──────────────────────────────────────────────────────────────────────────
def _safe_apply(k: int, x: np.ndarray) -> Optional[np.ndarray]:
    """Call ``PHI[k](x)`` with positional ψ only; return ``None`` on failure.

    Operators that return complex values are rejected outright — silently
    discarding the imaginary part would falsely promote unitary-but-not-real
    operators into the involution / inverse buckets.
    """
    try:
        out = PHI[k](x)
        if isinstance(out, tuple):
            parts = [np.asarray(p) for p in out]
            if any(np.iscomplexobj(p) for p in parts):
                return None
            out = np.concatenate([p.astype(np.float64).ravel() for p in parts])
        arr = np.asarray(out)
        if np.iscomplexobj(arr):
            return None
        arr = arr.astype(np.float64).ravel()
        if arr.size == 0 or not np.all(np.isfinite(arr)):
            return None
        return arr
    except Exception:
        return None


def _relative_resid(a: np.ndarray, b: np.ndarray) -> float:
    """Length-aligned relative-L2 error ∈ [0, ~1]."""
    n = min(len(a), len(b))
    if n == 0:
        return math.inf
    a, b = a[:n], b[:n]
    denom = float(np.linalg.norm(a)) + float(np.linalg.norm(b)) + 1e-12
    return float(np.linalg.norm(a - b) / denom)


def _trust_from_residual(r: float) -> float:
    return float(max(0.0, min(1.0, 1.0 - r)))


def _sample_inputs(rng: np.random.Generator, dim: int, trials: int) -> list[np.ndarray]:
    """Diverse battery of test ψ-cells — Gaussian, uniform, sinusoid, DC."""
    out: list[np.ndarray] = []
    for _ in range(trials):
        kind = int(rng.integers(0, 4))
        if kind == 0:
            x = rng.standard_normal(dim) * 0.3
        elif kind == 1:
            x = rng.uniform(-0.5, 0.5, dim)
        elif kind == 2:
            t = np.linspace(0.0, 2.0 * np.pi, dim)
            x = np.sin(t + rng.uniform(0.0, 2.0 * np.pi)) * 0.5
        else:
            x = np.full(dim, float(rng.uniform(-0.3, 0.3)))
        out.append(np.asarray(x, dtype=np.float64))
    return out


def _unary_compatible(k: int, dim: int) -> bool:
    """Probe whether ``PHI[k]`` accepts a single ψ argument."""
    return _safe_apply(k, np.array([0.05] * dim)) is not None


# ──────────────────────────────────────────────────────────────────────────
#  Conjecture tests
# ──────────────────────────────────────────────────────────────────────────
def test_involution(a: int, samples: list[np.ndarray]) -> Optional[Law]:
    rs: list[float] = []
    for x in samples:
        y = _safe_apply(a, x)
        if y is None or y.size != x.size:
            return None
        z = _safe_apply(a, y)
        if z is None or z.size != x.size:
            return None
        rs.append(_relative_resid(x, z))
    r = float(np.mean(rs))
    return Law(
        name=f"phi_{a}_involution",
        lhs=f"phi({a}, phi({a}, x))",
        rhs="x",
        kind="involution",
        residual=r,
        trust=_trust_from_residual(r),
        trials=len(samples),
    )


def test_identity(a: int, b: int, samples: list[np.ndarray]) -> Optional[Law]:
    rs: list[float] = []
    for x in samples:
        y = _safe_apply(b, x)
        if y is None:
            return None
        z = _safe_apply(a, y)
        if z is None:
            return None
        if z.size != x.size:
            return None
        rs.append(_relative_resid(x, z))
    r = float(np.mean(rs))
    return Law(
        name=f"phi_{a}_inverts_phi_{b}",
        lhs=f"phi({a}, phi({b}, x))",
        rhs="x",
        kind="identity",
        residual=r,
        trust=_trust_from_residual(r),
        trials=len(samples),
    )


def test_zero(a: int, b: int, samples: list[np.ndarray]) -> Optional[Law]:
    rs: list[float] = []
    for x in samples:
        y = _safe_apply(b, x)
        if y is None:
            return None
        z = _safe_apply(a, y)
        if z is None:
            return None
        denom = float(np.linalg.norm(x)) + 1e-12
        rs.append(float(np.linalg.norm(z)) / denom)
    r = float(np.mean(rs))
    return Law(
        name=f"phi_{a}_annihilates_phi_{b}",
        lhs=f"phi({a}, phi({b}, x))",
        rhs="zero",
        kind="zero",
        residual=r,
        trust=_trust_from_residual(r),
        trials=len(samples),
    )


def test_commute(a: int, b: int, samples: list[np.ndarray]) -> Optional[Law]:
    rs: list[float] = []
    for x in samples:
        # forward: φ_a(φ_b(x))
        ab = _safe_apply(b, x)
        if ab is None:
            return None
        ab = _safe_apply(a, ab)
        if ab is None:
            return None
        # reverse: φ_b(φ_a(x))
        ba = _safe_apply(a, x)
        if ba is None:
            return None
        ba = _safe_apply(b, ba)
        if ba is None:
            return None
        if ab.size != ba.size:
            return None
        rs.append(_relative_resid(ab, ba))
    r = float(np.mean(rs))
    return Law(
        name=f"phi_{a}_commutes_phi_{b}",
        lhs=f"phi({a}, phi({b}, x))",
        rhs=f"phi({b}, phi({a}, x))",
        kind="commute",
        residual=r,
        trust=_trust_from_residual(r),
        trials=len(samples),
    )


# ──────────────────────────────────────────────────────────────────────────
#  Discovery loop
# ──────────────────────────────────────────────────────────────────────────
def discover(
    *,
    threshold: float = 0.05,
    dim: int = 16,
    trials: int = 12,
    k_max: int = 60,
    seed: int = 42,
    kinds: tuple[str, ...] = ("involution", "identity", "zero", "commute"),
    dedupe: bool = True,
) -> list[Law]:
    """Enumerate every candidate, test it, keep those below ``threshold``.

    If ``dedupe`` (default), symmetric facts about pairs ``(a, b)`` and
    ``(b, a)`` are recorded only once (canonical: ``a < b``). The lattice
    relations ``identity`` and ``commute`` are symmetric under composition;
    ``zero`` (annihilator) is intrinsically directed and is never deduped.
    """
    rng = np.random.default_rng(seed)
    samples = _sample_inputs(rng, dim, trials)
    compatible = [k for k in range(k_max + 1) if k in PHI and _unary_compatible(k, dim)]

    laws: list[Law] = []

    if "involution" in kinds:
        for a in compatible:
            L = test_involution(a, samples)
            if L is not None and L.residual <= threshold:
                laws.append(L)

    pair_kinds = [k for k in kinds if k in ("identity", "zero", "commute")]
    if pair_kinds:
        tests = {
            "identity": test_identity,
            "zero": test_zero,
            "commute": test_commute,
        }
        for a in compatible:
            for b in compatible:
                if a == b:
                    continue
                if dedupe and a > b and "identity" in pair_kinds and "commute" in pair_kinds:
                    # 'identity' and 'commute' are symmetric — skip (b, a) copies.
                    # 'zero' stays directed and is still tested below.
                    directed = ["zero"] if "zero" in pair_kinds else []
                else:
                    directed = pair_kinds
                if dedupe and a > b and "zero" not in pair_kinds:
                    continue
                for kname in directed:
                    if dedupe and kname in ("identity", "commute") and a > b:
                        continue
                    L = tests[kname](a, b, samples)
                    if L is not None and L.residual <= threshold:
                        laws.append(L)

    # Stable ordering for reproducibility — by kind, then residual, then name.
    kind_order = {"involution": 0, "identity": 1, "zero": 2, "commute": 3}
    laws.sort(key=lambda L: (kind_order.get(L.kind, 99), L.residual, L.name))
    return laws


def summarize(laws: list[Law]) -> dict[str, int]:
    """Counts per law kind — useful for a one-line discovery report."""
    counts: dict[str, int] = {}
    for L in laws:
        counts[L.kind] = counts.get(L.kind, 0) + 1
    return counts


def persist(arena_path: Path, laws: list[Law]) -> None:
    """Materialize each law as a ψ-cell under slot ``law/<name>``."""
    a = Arena.open(arena_path, autoflush=False)
    for L in laws:
        a[f"law/{L.name}"] = L.as_cell()
    a.flush()


def render(laws: list[Law], header: str = "") -> str:
    parts = []
    if header:
        parts.append(header)
    for L in laws:
        parts.append(L.as_sol())
    return "\n".join(parts)


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith autonomous discovery engine (Zone 116).",
    )
    p.add_argument("--threshold", type=float, default=0.05,
                   help="max relative residual to accept a law (default 0.05).")
    p.add_argument("--dim", type=int, default=16,
                   help="ψ-cell dimension for random trials (default 16).")
    p.add_argument("--trials", type=int, default=12,
                   help="random ψ trials per candidate (default 12).")
    p.add_argument("--seed", type=int, default=42, help="rng seed (default 42).")
    p.add_argument("--k-max", type=int, default=60,
                   help="explore φ_0..φ_{k-max} (default 60).")
    p.add_argument("--kinds", default="involution,identity,zero,commute",
                   help="comma-separated subset of kinds to test.")
    p.add_argument("--write", type=Path, default=None,
                   help="optional .sol path to write surviving laws as a stdlib file.")
    p.add_argument("--lawbook", type=Path, default=None,
                   help="optional .arena path to persist laws as ψ-cells.")
    p.add_argument("--limit", type=int, default=40,
                   help="print only the top-N laws by residual (default 40; 0 = all).")
    p.add_argument("--no-dedupe", action="store_true",
                   help="emit both (a,b) and (b,a) for symmetric relations.")
    p.add_argument("--summary-only", action="store_true",
                   help="print only the per-kind counts, not the laws themselves.")
    args = p.parse_args(argv)

    kinds = tuple(k.strip() for k in args.kinds.split(",") if k.strip())
    laws = discover(
        threshold=args.threshold,
        dim=args.dim,
        trials=args.trials,
        k_max=args.k_max,
        seed=args.seed,
        kinds=kinds,
        dedupe=not args.no_dedupe,
    )
    full_total = len(laws)
    counts = summarize(laws)
    if args.limit and args.limit > 0:
        laws = laws[: args.limit]

    header = (
        f"# Σoilith — discovered {full_total} laws  "
        f"(threshold={args.threshold}, dim={args.dim}, trials={args.trials}, "
        f"seed={args.seed}, kinds={','.join(kinds)})\n"
        f"#   counts: " + ", ".join(f"{k}={v}" for k, v in sorted(counts.items())) + "\n"
    )
    print(header)
    if not args.summary_only:
        for L in laws:
            print(L.as_sol())
        if args.limit and full_total > args.limit:
            print(f"# ({full_total - args.limit} more laws not shown — pass --limit 0 to see all.)\n")

    if args.write is not None:
        args.write.parent.mkdir(parents=True, exist_ok=True)
        args.write.write_text(render(laws, header=header), encoding="utf-8")
        print(f"# wrote {len(laws)} laws → {args.write}")

    if args.lawbook is not None:
        persist(args.lawbook, laws)
        print(f"# persisted {len(laws)} ψ-cells → {args.lawbook}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
