"""
soilith_incremental.py — incremental / differential dataflow
(Zone 144).

Naiad's Differential Dataflow, Adapton's incremental computation,
and self-adjusting computation (Acar et al.) re-execute only the
subgraph of a program whose inputs changed. Σoilith's discovery
pipeline is one big DAG — a topology cell depends on a magnitude
capsule, a closure depends on the symmetries it consumed, a
pair-group lookup depends on its source operators — so reusing
already-correct results across catalog runs is a real win.

API
---
* ``Node(key, fn, deps)`` — a single dataflow node. ``fn`` is a
  thunk that, when called, returns the node's value.
* ``Graph`` owns a dict ``key → Node``, tracks dirty bits, and
  computes a topological order on demand.
* ``Graph.touch(key)`` marks ``key`` and all transitive consumers
  dirty.
* ``Graph.value(key)`` returns the cached value if clean, else
  recomputes (and any unclean ancestor it depends on).
* ``Graph.replay()`` recomputes every dirty node in topological
  order and returns a ``Recomp`` report
  ``(total, recomputed, skipped, time_ms)``.

CLI
---
    python soilith_incremental.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
import time
from typing import Any, Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class IncrementalError(Exception):
    pass


class CycleDetected(IncrementalError):
    pass


# ──────────────────────────────────────────────────────────────────────────
#  Node
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Node:
    key: str
    fn: Callable[[dict[str, Any]], Any]
    deps: tuple[str, ...] = ()
    cached: Any | None = None
    dirty: bool = True
    recomputes: int = 0


@dataclass
class Recomp:
    total: int
    recomputed: int
    skipped: int
    time_ms: float

    @property
    def skip_ratio(self) -> float:
        return 0.0 if self.total == 0 else self.skipped / self.total

    def describe(self) -> str:
        return (
            f"Recomp  total={self.total} recomputed={self.recomputed} "
            f"skipped={self.skipped}  skip_ratio={self.skip_ratio:.2%} "
            f"({self.time_ms:.1f} ms)"
        )


# ──────────────────────────────────────────────────────────────────────────
#  Graph
# ──────────────────────────────────────────────────────────────────────────
class Graph:
    def __init__(self) -> None:
        self._nodes: dict[str, Node] = {}
        self._consumers: dict[str, set[str]] = {}

    def add(
        self, key: str,
        fn: Callable[[dict[str, Any]], Any],
        deps: tuple[str, ...] = (),
    ) -> None:
        if key in self._nodes:
            raise IncrementalError(f"duplicate node key {key!r}")
        self._nodes[key] = Node(key=key, fn=fn, deps=tuple(deps))
        for d in deps:
            self._consumers.setdefault(d, set()).add(key)

    def touch(self, key: str) -> set[str]:
        """Mark ``key`` and every transitive consumer dirty.
        Returns the set of dirty keys."""
        if key not in self._nodes:
            raise IncrementalError(f"unknown node {key!r}")
        dirty: set[str] = set()
        frontier = [key]
        while frontier:
            k = frontier.pop()
            if k in dirty:
                continue
            dirty.add(k)
            self._nodes[k].dirty = True
            frontier.extend(self._consumers.get(k, ()))
        return dirty

    def _topological(self) -> list[str]:
        order: list[str] = []
        seen: set[str] = set()
        path: set[str] = set()

        def visit(k: str) -> None:
            if k in seen:
                return
            if k in path:
                raise CycleDetected(f"cycle through {k!r}")
            path.add(k)
            for d in self._nodes[k].deps:
                if d in self._nodes:
                    visit(d)
            path.discard(k)
            seen.add(k)
            order.append(k)
        for k in self._nodes:
            visit(k)
        return order

    def value(self, key: str) -> Any:
        node = self._nodes[key]
        if not node.dirty and node.cached is not None:
            return node.cached
        # Recompute deps first.
        env: dict[str, Any] = {}
        for d in node.deps:
            env[d] = self.value(d)
        node.cached = node.fn(env)
        node.dirty = False
        node.recomputes += 1
        return node.cached

    def replay(self) -> Recomp:
        t0 = time.perf_counter()
        order = self._topological()
        recomputed = 0
        for k in order:
            n = self._nodes[k]
            if n.dirty or n.cached is None:
                self.value(k)
                recomputed += 1
        elapsed = (time.perf_counter() - t0) * 1000.0
        total = len(order)
        return Recomp(
            total=total, recomputed=recomputed,
            skipped=total - recomputed, time_ms=elapsed,
        )

    def stats(self) -> dict[str, int]:
        return {
            "n_nodes": len(self._nodes),
            "n_dirty": sum(1 for n in self._nodes.values() if n.dirty),
            "n_clean": sum(1 for n in self._nodes.values()
                           if not n.dirty),
            "total_recomputes": sum(
                n.recomputes for n in self._nodes.values()
            ),
        }


# ──────────────────────────────────────────────────────────────────────────
#  Catalog → graph
# ──────────────────────────────────────────────────────────────────────────
def build_catalog_graph(catalog: dict[str, Any]) -> Graph:
    """Build a tiny illustrative DAG over the catalog: 'symmetry/*'
    depends on 'topology/*'; 'closure/*' depends on 'symmetry/*'.
    All node fns simply return the row's slot/trust pair so that
    dirtying any topology row forces a recompute downstream."""
    g = Graph()
    rows = catalog.get("entries", [])
    topo = [e for e in rows if e.get("kind") == "topology"][:8]
    sym = [e for e in rows if e.get("kind") == "symmetry"][:8]
    clo = [e for e in rows if e.get("kind") == "closure"][:4]

    for e in topo:
        slot = e["slot"]
        trust = float(e.get("trust", 0.0))
        g.add(slot, (lambda env, s=slot, t=trust: (s, t)))
    for e in sym:
        slot = e["slot"]
        trust = float(e.get("trust", 0.0))
        deps = tuple(t["slot"] for t in topo)
        g.add(
            slot,
            (lambda env, s=slot, t=trust: (s, t,
                                            sum(v[1] for v in env.values())
                                            if env else 0.0)),
            deps=deps,
        )
    for e in clo:
        slot = e["slot"]
        trust = float(e.get("trust", 0.0))
        deps = tuple(s["slot"] for s in sym)
        g.add(
            slot,
            (lambda env, s=slot, t=trust: (s, t,
                                            sum(v[1] for v in env.values())
                                            if env else 0.0)),
            deps=deps,
        )
    return g


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(name: str, rep: Recomp, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(rep.total), float(rep.recomputed),
        float(rep.skipped), rep.time_ms,
    ], dtype=float)
    safe = "".join(c if c.isalnum() else "_" for c in name)[:60]
    trust = float(np.clip(rep.skip_ratio, 0.0, 1.0))
    arena[f"incremental/{safe}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI / Demo
# ──────────────────────────────────────────────────────────────────────────
def _default_catalog() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith incremental dataflow (Zone 144)."
    )
    p.add_argument("--catalog", type=Path, default=_default_catalog())
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    import json
    catalog = (
        json.loads(args.catalog.read_text(encoding="utf-8"))
        if args.catalog.exists() else {"entries": []}
    )

    print("# Zone 144 — incremental dataflow on the catalog DAG")
    g = build_catalog_graph(catalog)
    print(f"   nodes: {g.stats()['n_nodes']}")

    print("\n# 1. Cold run — everything recomputes")
    rep1 = g.replay()
    print("   " + rep1.describe())
    persist("cold_run", rep1, args.arena)

    print("\n# 2. Warm run — nothing changed, everything skips")
    rep2 = g.replay()
    print("   " + rep2.describe())
    persist("warm_run", rep2, args.arena)

    print("\n# 3. Touch one topology node — only its descendants recompute")
    topo_keys = [k for k in g._nodes if k.startswith("topology/")]
    if topo_keys:
        touched = g.touch(topo_keys[0])
        print(f"   touched {len(touched)} nodes via dirty propagation")
        rep3 = g.replay()
        print("   " + rep3.describe())
        persist("incremental_run", rep3, args.arena)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
