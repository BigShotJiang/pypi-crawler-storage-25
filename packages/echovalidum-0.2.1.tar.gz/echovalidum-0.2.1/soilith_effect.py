"""
soilith_effect.py — algebraic effects and effect handlers
(Zone 137).

Koka, Eff, and OCaml 5 model effectful computation as the *free
monad* over a signature of operations, interpreted by *handlers*
that catch each operation in turn. Σoilith already has the right
substrate: the PHI operator algebra is exactly such a signature,
and the Zone-127 composition / finite-order laws are the algebraic
*equations* that quotient the free monad.

API
---
An **EffectSignature** names a set of φ-operator indices — the
"operations" of one effect. An **EffectRow** is a (frozen) union
of signatures, written ``<state, exn>`` in Koka.

An **EffectfulProgram** is a list of ``(op_index, payload)``
calls. A **Handler** is a dict
``{op_index → (payload, k_resume) → result}`` plus a final
``return`` handler. ``run(program, handler, init)`` interprets
the program against the handler, returning the final value.

Two universal effect rows are auto-derived from the catalog:
* **EffectRow.endo** — every operator with Zone-126 signature
  ``endo`` (cell-shape-preserving);
* **EffectRow.dynamic** — every operator Zone-126 flagged
  ``dynamic`` or ``failed`` (shape varies with input).

A program type-checks against a row iff every operation it invokes
is in the row. A handler *covers* a row iff it has a clause for
every operation in it.

Persistence
-----------
``effect/<row_name>/program_<hash>`` carries a 5-float payload
``[ops_count, distinct_ops, handler_covered, type_checked, ok]``.
Trust 1.0 iff handler covered + type-checked.

CLI
---
    python soilith_effect.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import json
from pathlib import Path
import sys
from typing import Any, Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402
from soilith_phi import PHI  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class EffectError(Exception):
    """Base class for Zone 137 errors."""


class UnhandledEffect(EffectError):
    """The handler has no clause for an invoked operation."""


class EffectRowViolation(EffectError):
    """A program performs an op outside the declared effect row."""


# ──────────────────────────────────────────────────────────────────────────
#  Signatures
# ──────────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class EffectSignature:
    name: str
    op_indices: frozenset[int]

    def __or__(self, other: "EffectSignature") -> "EffectRow":
        return EffectRow(name=f"{self.name}|{other.name}",
                         signatures=(self, other))


@dataclass(frozen=True)
class EffectRow:
    name: str
    signatures: tuple[EffectSignature, ...]

    @property
    def op_indices(self) -> frozenset[int]:
        return frozenset.union(*(s.op_indices for s in self.signatures))

    def contains(self, op: int) -> bool:
        return op in self.op_indices

    def covers(self, program: "EffectfulProgram") -> bool:
        return all(self.contains(op) for op, _ in program.calls)

    @classmethod
    def from_signatures(cls, *sigs: EffectSignature) -> "EffectRow":
        name = "|".join(s.name for s in sigs) or "empty"
        return cls(name=name, signatures=tuple(sigs))


# ──────────────────────────────────────────────────────────────────────────
#  Programs and handlers
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class EffectfulProgram:
    """A sequence of operations to perform."""
    calls: list[tuple[int, Any]] = field(default_factory=list)

    def perform(self, op: int, payload: Any) -> "EffectfulProgram":
        self.calls.append((op, payload))
        return self

    @property
    def distinct_ops(self) -> frozenset[int]:
        return frozenset(op for op, _ in self.calls)


@dataclass
class Handler:
    """A handler is a dict mapping op_index → (payload, state) → (new_state)
    plus an optional ``return_`` function for the final value."""
    clauses: dict[int, Callable[[Any, Any], Any]] = field(
        default_factory=dict,
    )
    return_: Callable[[Any], Any] | None = None

    def covers(self, row: EffectRow) -> bool:
        return all(op in self.clauses for op in row.op_indices)

    def add(self, op: int, fn: Callable[[Any, Any], Any]) -> "Handler":
        self.clauses[op] = fn
        return self


def run(
    program: EffectfulProgram,
    handler: Handler,
    *,
    initial: Any = None,
    row: EffectRow | None = None,
) -> tuple[Any, list[Any]]:
    """Interpret ``program`` against ``handler``. Returns
    ``(final, trace)`` where ``trace`` is the per-step state history.
    ``initial`` seeds the handler's state thread. ``row`` (optional)
    statically rejects programs that perform operations outside it."""
    if row is not None and not row.covers(program):
        bad = sorted(program.distinct_ops - row.op_indices)
        raise EffectRowViolation(
            f"program performs ops {bad!r} not in row {row.name!r}"
        )
    state = initial
    trace = [state]
    for op, payload in program.calls:
        clause = handler.clauses.get(op)
        if clause is None:
            raise UnhandledEffect(
                f"no handler clause for op φ_{op}"
            )
        state = clause(payload, state)
        trace.append(state)
    if handler.return_ is not None:
        state = handler.return_(state)
    return state, trace


# ──────────────────────────────────────────────────────────────────────────
#  Catalog-derived rows
# ──────────────────────────────────────────────────────────────────────────
def rows_from_catalog(catalog: dict[str, Any]) -> dict[str, EffectSignature]:
    """Group every φ by its Zone-126 categorical signature into
    one ``EffectSignature`` per kind."""
    by_kind: dict[str, set[int]] = {}
    for e in catalog.get("entries", []):
        if e.get("kind") != "signature":
            continue
        p = e.get("payload", {})
        k = p.get("kind", "failed")
        idx = p.get("op_index", -1)
        try:
            idx = int(idx)
        except Exception:
            continue
        if idx < 0:
            continue
        by_kind.setdefault(k, set()).add(idx)
    out: dict[str, EffectSignature] = {}
    for kind, ops in by_kind.items():
        out[kind] = EffectSignature(
            name=kind, op_indices=frozenset(ops),
        )
    return out


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(
    program: EffectfulProgram,
    handler: Handler,
    row: EffectRow,
    arena_path: Path,
    *,
    label: str | None = None,
) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    covered = handler.covers(row)
    typed = row.covers(program)
    ok = covered and typed
    payload = np.array([
        float(len(program.calls)),
        float(len(program.distinct_ops)),
        1.0 if covered else 0.0,
        1.0 if typed else 0.0,
        1.0 if ok else 0.0,
    ], dtype=float)
    h = label or _hash(program)
    slot = f"effect/{_safe(row.name)}/program_{h}"
    trust = 1.0 if ok else 0.4
    arena[slot] = Cell(value=payload, trust=trust, phase=0.0)


def _safe(name: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in name)[:40]


def _hash(p: EffectfulProgram) -> str:
    return "x".join(str(op) for op, _ in p.calls[:8]) or "empty"


# ──────────────────────────────────────────────────────────────────────────
#  CLI / Demo
# ──────────────────────────────────────────────────────────────────────────
def _default_catalog() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith algebraic effects (Zone 137)."
    )
    p.add_argument("--catalog", type=Path, default=_default_catalog())
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    catalog = json.loads(args.catalog.read_text(encoding="utf-8")) \
        if args.catalog.exists() else {"entries": []}

    print("# Zone 137 — algebraic effects from the operator algebra")
    sigs = rows_from_catalog(catalog)
    print(f"#   derived {len(sigs)} effect signatures from catalog")
    for kind in sorted(sigs):
        ops = sorted(sigs[kind].op_indices)
        head = ", ".join(f"phi_{o}" for o in ops[:5])
        if len(ops) > 5:
            head += f", … (+{len(ops)-5} more)"
        print(f"   {kind:<12s} ({len(ops):3d} ops):  {head}")

    print("\n# 1. Build a row from the endo + dynamic signatures")
    endo = sigs.get("endo", EffectSignature(name="endo", op_indices=frozenset()))
    dyn = sigs.get("dynamic",
                   EffectSignature(name="dynamic", op_indices=frozenset()))
    row = endo | dyn
    print(f"   row = {row.name}  (|ops| = {len(row.op_indices)})")

    print("\n# 2. Write a program: shift twice, add a constant, print")
    prog = EffectfulProgram()
    prog.perform(38, None).perform(38, None).perform(1, 0.5)

    handler = Handler().add(
        38, lambda _payload, s: ((s or 0) + 1),  # 'shift' bumps a counter
    ).add(
        1, lambda payload, s: (s, payload),       # 'inject' records payload
    )
    print(f"   program calls = {prog.calls}")
    print(f"   handler covers row? {handler.covers(row)}")

    print("\n# 3. Run with initial = 0")
    try:
        result, trace = run(prog, handler, initial=0, row=row)
        print(f"   result = {result}")
        print(f"   trace  = {trace}")
        persist(prog, handler, row, args.arena, label="demo_run")
    except EffectError as exc:
        print(f"   ✗ {type(exc).__name__}: {exc}")

    print("\n# 4. Reject a program that violates the row")
    bad = EffectfulProgram().perform(60, None)   # phi_60 is shape-changing
    pure_row = EffectRow.from_signatures(endo)
    try:
        run(bad, handler, row=pure_row)
    except EffectRowViolation as exc:
        print(f"   ✓ {type(exc).__name__}: {exc}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
