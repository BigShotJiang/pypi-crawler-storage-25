"""
soilith_fibration.py — cross-capsule fibrations (Zone 129).

Zone 128 made χ a runtime invariant of a single capsule. Zone 129
makes χ a runtime invariant *between* capsules.

A ``Fibration(source, target, π)`` is a group homomorphism
``π: G_source → G_target`` (lifted to a map of address spaces) that:

* is a covering map (``π`` is surjective, fibers all have the same
  cardinality ``deg = |G_source| / |G_target|``);
* respects Cayley adjacency in the sense that if Zone-117's
  "horizontal" generators of the source (those not in ker π) are
  pushed by π, they give exactly the generators of the target;
* satisfies χ-multiplicativity ``χ(source) = deg · χ(target)`` —
  a topological theorem for cell complexes, here a *runtime check*.

Two canonical fibrations are built in:

1. **Quotient-of-a-generator** for tier-0 capsules
   ``(ℤ/2)^k  →  (ℤ/2)^(k-1)`` by sending one generator to the
   identity. Degree = 2; the kernel is a copy of ℤ/2 acting as the
   deck transformation. Each address ``b₀b₁…b_{k-1}`` is mapped to
   the (k-1)-bit string with bit ``axis`` dropped.

2. **Cyclic-rotation halving** for pair-group capsules
   ``ℤ/(2n) × ℤ/2  →  ℤ/n × ℤ/2`` by sending ``(k, j)`` to
   ``(k mod n, j)``. Degree = 2; the kernel acts by shifting the
   rotation index by ``n``. Each fiber has the two pre-images
   ``(k₀, j)`` and ``(k₀ + n, j)``.

Both fibrations also support **pullback** of memory (lift each
target cell along π by copying to every preimage) and
**pushforward** (average target values over fibers).

CLI
---
    python soilith_fibration.py
    python soilith_fibration.py --kind quotient_z2 --k 4 --axis 2
    python soilith_fibration.py --kind cyclic_halving --n 8 --m 2

Persistence
-----------
Each successful fibration audit is written as a ``fibration/*``
ψ-cell carrying a 9-float payload
``[degree, V_src, V_tgt, E_src, E_tgt, chi1_src, chi1_tgt,
chi2_src, chi2_tgt]``. Trust is ``1.0`` only if every audit and
χ-multiplicativity check passed; ``0.5`` otherwise.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any, Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402
from soilith_memory import ScaleAwareMemory  # noqa: E402
from soilith_pair_memory import PairGroupMemory  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Exceptions
# ──────────────────────────────────────────────────────────────────────────
class FibrationError(Exception):
    """Base class for Zone 129 errors."""


class NotASurjection(FibrationError):
    """``π`` is not surjective onto the claimed target group."""


class ChiMultiplicativityFailure(FibrationError):
    """``χ(source) ≠ deg · χ(target)``."""


# ──────────────────────────────────────────────────────────────────────────
#  Report
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class FibrationReport:
    name: str
    kind: str                       # "quotient_z2" | "cyclic_halving"
    degree: int
    V_src: int; V_tgt: int
    E_src: int; E_tgt: int
    F_src: int; F_tgt: int
    chi1_src: int; chi1_tgt: int
    chi2_src: int; chi2_tgt: int
    V_multiplicative: bool          # V_src == deg · V_tgt
    chi1_multiplicative: bool       # χ₁ multiplicative (theorem holds)
    chi2_multiplicative: bool       # χ₂ multiplicative
    surjection_verified: bool
    fiber_uniform: bool             # all fibers have cardinality = deg
    chi1_ratio: float               # χ₁(src) / χ₁(tgt), or NaN if tgt χ₁=0
    chi2_ratio: float               # χ₂(src) / χ₂(tgt), or NaN if tgt χ₂=0
    notes: list[str] = field(default_factory=list)

    @property
    def is_covering_map(self) -> bool:
        """True iff π is a surjective covering map with uniform
        fiber and V multiplies cleanly. This is the runtime property
        that lets ``pullback`` and ``pushforward`` work."""
        return (
            self.surjection_verified
            and self.fiber_uniform
            and self.V_multiplicative
        )

    @property
    def successful(self) -> bool:
        return self.is_covering_map

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name, "kind": self.kind, "degree": self.degree,
            "V_src": self.V_src, "V_tgt": self.V_tgt,
            "E_src": self.E_src, "E_tgt": self.E_tgt,
            "F_src": self.F_src, "F_tgt": self.F_tgt,
            "chi1_src": self.chi1_src, "chi1_tgt": self.chi1_tgt,
            "chi2_src": self.chi2_src, "chi2_tgt": self.chi2_tgt,
            "V_multiplicative": self.V_multiplicative,
            "chi1_multiplicative": self.chi1_multiplicative,
            "chi2_multiplicative": self.chi2_multiplicative,
            "surjection_verified": self.surjection_verified,
            "fiber_uniform": self.fiber_uniform,
            "chi1_ratio": self.chi1_ratio,
            "chi2_ratio": self.chi2_ratio,
            "is_covering_map": self.is_covering_map,
            "successful": self.successful,
            "notes": list(self.notes),
        }

    def describe(self) -> str:
        ok = "✓" if self.successful else "✗"
        lines = [
            f"FibrationReport {ok}  {self.name}  ({self.kind})",
            f"  degree (|fiber|)        = {self.degree}",
            f"  V_src / V_tgt           = {self.V_src} / {self.V_tgt}",
            f"  E_src / E_tgt           = {self.E_src} / {self.E_tgt}",
            f"  χ₁_src / χ₁_tgt         = {self.chi1_src} / {self.chi1_tgt}"
            f"  (ratio {self.chi1_ratio:.3f})",
            f"  χ₂_src / χ₂_tgt         = {self.chi2_src} / {self.chi2_tgt}"
            f"  (ratio {self.chi2_ratio:.3f})",
            f"  surjection verified     = {self.surjection_verified}",
            f"  fiber uniform           = {self.fiber_uniform}",
            f"  V multiplicative        = {self.V_multiplicative}",
            f"  χ₁ multiplicative       = {self.chi1_multiplicative}",
            f"  χ₂ multiplicative       = {self.chi2_multiplicative}",
        ]
        for n in self.notes:
            lines.append(f"  · {n}")
        return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────
#  Fibration
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Fibration:
    """A typed cross-capsule covering map.

    ``project`` is the address-level map ``addr_src → addr_tgt``;
    ``lifts`` is the address-level fiber map ``addr_tgt → list[addr_src]``.
    Both must be consistent (every address in ``lifts(t)`` projects to
    ``t``, and the union of all lifts is the entire source address
    space).
    """

    name: str
    kind: str
    source: Any                     # ScaleAwareMemory | PairGroupMemory
    target: Any
    degree: int
    project: Callable[[Any], Any]
    lifts: Callable[[Any], list[Any]]

    # ── factories ────────────────────────────────────────────────────────
    @classmethod
    def quotient_z2(
        cls, k: int, axis: int,
    ) -> "Fibration":
        """``(ℤ/2)^k → (ℤ/2)^(k-1)`` by quotienting generator ``axis``."""
        if k < 1:
            raise ValueError("k must be ≥ 1")
        if not 0 <= axis < k:
            raise ValueError(f"axis {axis} outside [0, {k})")

        # build the two capsules using attested closed forms
        src_inv = expected_invariants_z2k_local(k)
        tgt_inv = expected_invariants_z2k_local(k - 1) if k >= 2 else {
            "V": 1, "E": 0, "F": 0, "chi_1": 1, "chi_2": 1, "order": 1,
        }
        src = ScaleAwareMemory(
            k=k,
            attested_V=src_inv["V"], attested_E=src_inv["E"],
            attested_F=src_inv["F"],
            attested_chi_1=src_inv["chi_1"],
            attested_chi_2=src_inv["chi_2"],
            probe_name=f"z2_{k}",
        )
        if k >= 2:
            tgt = ScaleAwareMemory(
                k=k - 1,
                attested_V=tgt_inv["V"], attested_E=tgt_inv["E"],
                attested_F=tgt_inv["F"],
                attested_chi_1=tgt_inv["chi_1"],
                attested_chi_2=tgt_inv["chi_2"],
                probe_name=f"z2_{k-1}",
            )
        else:
            tgt = None  # the trivial 1-point capsule

        def project(addr_src: str) -> str:
            if k == 1:
                return ""
            return addr_src[:axis] + addr_src[axis + 1:]

        def lifts(addr_tgt: str) -> list[str]:
            if k == 1:
                return ["0", "1"]
            return [
                addr_tgt[:axis] + bit + addr_tgt[axis:]
                for bit in ("0", "1")
            ]

        return cls(
            name=f"quotient_z2_{k}_axis{axis}",
            kind="quotient_z2",
            source=src, target=tgt,
            degree=2, project=project, lifts=lifts,
        )

    @classmethod
    def cyclic_halving(
        cls, n: int,
    ) -> "Fibration":
        """``ℤ/(2n) × ℤ/2 → ℤ/n × ℤ/2`` by halving rotation."""
        if n < 1:
            raise ValueError("n must be ≥ 1")
        src = PairGroupMemory(n=2 * n, capsule_probe=f"pair_n{2*n}")
        tgt = PairGroupMemory(n=n, capsule_probe=f"pair_n{n}")

        def project(addr_src: tuple[int, int]) -> tuple[int, int]:
            k, j = addr_src
            return (k % n, j)

        def lifts(addr_tgt: tuple[int, int]) -> list[tuple[int, int]]:
            k, j = addr_tgt
            return [(k, j), (k + n, j)]

        return cls(
            name=f"cyclic_halving_n{n}",
            kind="cyclic_halving",
            source=src, target=tgt,
            degree=2, project=project, lifts=lifts,
        )

    # ── audit ────────────────────────────────────────────────────────────
    def audit(self) -> FibrationReport:
        """Verify ``π`` is a surjective covering map and check
        χ-multiplicativity."""
        src, tgt = self.source, self.target
        notes: list[str] = []

        # 1. fiber uniformity + surjection
        if tgt is None:
            # k=1 quotient maps onto the trivial 1-point capsule.
            src_addrs = list(src.positions())
            tgt_addrs = [""]
            fiber_uniform = (len(src_addrs) == self.degree)
            surjection = True
        else:
            src_addrs = list(src.positions())
            tgt_addrs = list(tgt.positions())
            seen: dict[Any, int] = {a: 0 for a in tgt_addrs}
            seen_addresses: set[Any] = set()
            for s in src_addrs:
                t = self.project(s)
                seen[t] = seen.get(t, 0) + 1
                seen_addresses.add(t)
            surjection = (set(seen.keys()) == set(tgt_addrs)
                          and all(c > 0 for c in seen.values()))
            fiber_uniform = len(set(seen.values())) == 1 and (
                next(iter(seen.values())) == self.degree
            )
            if not surjection:
                notes.append("π is not surjective onto target address space")
            if not fiber_uniform:
                bad = {t: c for t, c in seen.items() if c != self.degree}
                notes.append(
                    f"non-uniform fibers ({len(bad)} have wrong cardinality)"
                )

        # 2. multiplicativity of V, χ₁, χ₂
        sa = src.attested
        if tgt is None:
            ta = {"V": 1, "E": 0, "F": 0, "chi_1": 1, "chi_2": 1}
        else:
            ta = tgt.attested
        V_mult = (sa["V"] == self.degree * ta["V"])
        chi1_mult = (sa["chi_1"] == self.degree * ta["chi_1"])
        chi2_mult = (sa["chi_2"] == self.degree * ta["chi_2"])
        chi1_ratio = (sa["chi_1"] / ta["chi_1"]) if ta["chi_1"] != 0 else float("nan")
        chi2_ratio = (sa["chi_2"] / ta["chi_2"]) if ta["chi_2"] != 0 else float("nan")
        if not V_mult:
            notes.append(
                f"V is NOT multiplicative: V_src={sa['V']} vs "
                f"deg·V_tgt={self.degree * ta['V']}"
            )
        if not chi1_mult:
            notes.append(
                f"χ₁ NOT multiplicative (ratio = {chi1_ratio:.3f}); "
                "the cover's extra 'vertical' (kernel-generator) "
                "edges break χ₁ at the full-Cayley convention. "
                "Restrict to the horizontal sub-graph for theorem."
            )
        if not chi2_mult:
            notes.append(
                f"χ₂ NOT multiplicative (ratio = {chi2_ratio:.3f}); "
                "F counts abstract relations, not their witnesses, so "
                "F is *not* multiplicative under a cover."
            )

        return FibrationReport(
            name=self.name, kind=self.kind, degree=self.degree,
            V_src=sa["V"], V_tgt=ta["V"],
            E_src=sa["E"], E_tgt=ta["E"],
            F_src=sa["F"], F_tgt=ta["F"],
            chi1_src=sa["chi_1"], chi1_tgt=ta["chi_1"],
            chi2_src=sa["chi_2"], chi2_tgt=ta["chi_2"],
            V_multiplicative=V_mult,
            chi1_multiplicative=chi1_mult,
            chi2_multiplicative=chi2_mult,
            chi1_ratio=chi1_ratio,
            chi2_ratio=chi2_ratio,
            surjection_verified=surjection,
            fiber_uniform=fiber_uniform,
            notes=notes,
        )

    # ── transport ────────────────────────────────────────────────────────
    def pullback(self, target_mem: Any) -> Any:
        """Lift every populated cell on the target up to every fiber
        element on the source. Returns a fresh memory of the source's
        type with the same shape."""
        # construct a fresh source memory
        sa = self.source.attested
        if isinstance(self.source, ScaleAwareMemory):
            new_src = ScaleAwareMemory(
                k=self.source.k,
                attested_V=sa["V"], attested_E=sa["E"], attested_F=sa["F"],
                attested_chi_1=sa["chi_1"], attested_chi_2=sa["chi_2"],
                probe_name=self.source.probe_name,
            )
        elif isinstance(self.source, PairGroupMemory):
            new_src = PairGroupMemory(
                n=self.source.n,
                attested_V=sa["V"], attested_E=sa["E"], attested_F=sa["F"],
                attested_chi_1=sa["chi_1"], attested_chi_2=sa["chi_2"],
                capsule_probe=self.source.capsule_probe,
                cell_dim=self.source.cell_dim,
            )
        else:
            raise TypeError("unsupported source memory type")
        for tgt_addr in target_mem.positions():
            cell = target_mem.read(tgt_addr)
            if cell is None:
                continue
            for s in self.lifts(tgt_addr):
                new_src.write(s, Cell(value=np.asarray(cell.value).copy(),
                                      trust=cell.trust, phase=cell.phase))
        return new_src

    def pushforward(self, source_mem: Any) -> Any:
        """Fiber-average every fiber. Returns a fresh target memory."""
        ta = self.target.attested
        if isinstance(self.target, ScaleAwareMemory):
            new_tgt = ScaleAwareMemory(
                k=self.target.k,
                attested_V=ta["V"], attested_E=ta["E"], attested_F=ta["F"],
                attested_chi_1=ta["chi_1"], attested_chi_2=ta["chi_2"],
                probe_name=self.target.probe_name,
            )
        elif isinstance(self.target, PairGroupMemory):
            new_tgt = PairGroupMemory(
                n=self.target.n,
                attested_V=ta["V"], attested_E=ta["E"], attested_F=ta["F"],
                attested_chi_1=ta["chi_1"], attested_chi_2=ta["chi_2"],
                capsule_probe=self.target.capsule_probe,
                cell_dim=self.target.cell_dim,
            )
        else:
            raise TypeError("unsupported target memory type")
        for t in self.target.positions():
            fiber = self.lifts(t)
            cells = [source_mem.read(s) for s in fiber]
            present = [c for c in cells if c is not None]
            if not present:
                continue
            shapes = {np.asarray(c.value).shape for c in present}
            if len(shapes) != 1:
                continue
            avg = np.mean(
                np.stack([np.asarray(c.value, dtype=float) for c in present]),
                axis=0,
            )
            trust = float(np.mean([c.trust for c in present]))
            phase = float(np.mean([c.phase for c in present]))
            new_tgt.write(t, Cell(value=avg, trust=trust, phase=phase))
        return new_tgt

    # ── section ──────────────────────────────────────────────────────────
    def canonical_section(self) -> Callable[[Any], Any]:
        """Pick the lexicographically smallest preimage as the canonical
        section ``s: G_target → G_source``. ``π ∘ s = id`` by
        construction; ``s ∘ π = id`` only on the image of ``s``."""
        def s(addr_tgt: Any) -> Any:
            preims = self.lifts(addr_tgt)
            return min(preims)
        return s

    # ── persistence ──────────────────────────────────────────────────────
    def persist(self, arena_path: Path) -> bool:
        from soilith_arena import Arena
        report = self.audit()
        arena = Arena.open(arena_path)
        # Trust 1.0 iff this is a genuine covering map AND χ₁ is
        # also multiplicative (the "topologically clean" case);
        # 0.75 if cover but χ₁ ratio non-integer (vertical edges
        # break the theorem at this skeleton); 0.0 if not a cover.
        if not report.is_covering_map:
            trust = 0.0
        elif report.chi1_multiplicative and report.chi2_multiplicative:
            trust = 1.0
        elif report.chi1_multiplicative:
            trust = 0.85
        else:
            trust = 0.55
        payload = np.array([
            float(report.degree),
            float(report.V_src), float(report.V_tgt),
            float(report.E_src), float(report.E_tgt),
            float(report.chi1_src), float(report.chi1_tgt),
            float(report.chi2_src), float(report.chi2_tgt),
            float(1.0 if report.chi1_multiplicative else 0.0),
            float(1.0 if report.chi2_multiplicative else 0.0),
        ], dtype=float)
        arena[f"fibration/{self.name}"] = Cell(
            value=payload, trust=trust, phase=0.0,
        )
        return report.successful


# ──────────────────────────────────────────────────────────────────────────
#  Closed-form attested invariants for (ℤ/2)^k
# ──────────────────────────────────────────────────────────────────────────
def expected_invariants_z2k_local(k: int) -> dict[str, int]:
    """Standalone fallback — same convention as ``soilith_topology``."""
    from math import comb
    V = 2 ** k
    E = k * (2 ** (k - 1)) if k >= 1 else 0
    F = comb(k, 2) if k >= 2 else 0
    return {
        "V": V, "E": E, "F": F,
        "chi_1": V - E,
        "chi_2": V - E + F,
        "order": V,
    }


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith cross-capsule fibration engine (Zone 129)."
    )
    p.add_argument("--kind",
                   choices=["quotient_z2", "cyclic_halving", "all"],
                   default="all")
    p.add_argument("--k", type=int, default=4)
    p.add_argument("--axis", type=int, default=0)
    p.add_argument("--n", type=int, default=4)
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)

    fibrations: list[Fibration] = []
    if args.kind in ("quotient_z2", "all"):
        for k in (2, 3, 4, 5):
            for axis in range(k):
                fibrations.append(Fibration.quotient_z2(k, axis))
    if args.kind in ("cyclic_halving", "all"):
        for n in (2, 3, 4, 6):
            fibrations.append(Fibration.cyclic_halving(n))

    print(f"# probing {len(fibrations)} fibrations")
    coverings = 0
    chi1_mult_count = 0
    chi2_mult_count = 0
    for f in fibrations:
        ok = f.persist(args.arena)
        if ok:
            coverings += 1
        report = f.audit()
        flag = "✓" if report.successful else "✗"
        chi1_flag = "✓" if report.chi1_multiplicative else " "
        chi2_flag = "✓" if report.chi2_multiplicative else " "
        if report.chi1_multiplicative:
            chi1_mult_count += 1
        if report.chi2_multiplicative:
            chi2_mult_count += 1
        print(
            f"  {flag} {f.name:<26s}  deg={f.degree}  "
            f"V {report.V_src:>3d}/{report.V_tgt:<3d}  "
            f"χ₁ {report.chi1_src:>+4d}/{report.chi1_tgt:<+4d} "
            f"[mult{chi1_flag}]  "
            f"χ₂ {report.chi2_src:>+4d}/{report.chi2_tgt:<+4d} "
            f"[mult{chi2_flag}]"
        )

    print(
        f"\n# {coverings}/{len(fibrations)} are genuine covering maps "
        f"(V multiplicative, surjective, uniform fiber)."
    )
    print(
        f"# {chi1_mult_count} of those have χ₁ also multiplicative "
        "(the 'topologically clean' covers)."
    )
    print(
        f"# {chi2_mult_count} have χ₂ multiplicative too "
        "(F-multiplicativity is generally false for abstract-relation F)."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
