"""
soilith_abstract.py — abstract interpretation over PHI
(Zone 145).

Cousot & Cousot's abstract interpretation framework approximates
concrete program behaviour by sound transfer functions over an
*abstract domain*: a lattice of computable shapes that
over-approximates concrete values. ASTREE famously used this for
zero-false-negative null-pointer analysis on Airbus avionics.

Zone 145 attaches an abstract domain to Σoilith cells and lifts
every PHI operator to it. The domain is a 5-element lattice:

           TOP
          / | \\
   NEG  ZERO  POS
          \\ | /
           BOT

with the obvious order. Transfer functions are *learned
empirically* from a small batch of concrete probes per operator
(``calibrate(samples=…)``), then a soundness audit verifies on a
hold-out batch that ``abstract(concrete(x)) ⊑ transfer(abstract(x))``.
Soundness failures are tracked and reported — Σoilith refuses to
emit a "verified" cell unless every probe in the hold-out batch
agreed with the abstract prediction.

CLI
---
    python soilith_abstract.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
import sys
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402
from soilith_phi import PHI  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Domain
# ──────────────────────────────────────────────────────────────────────────
class Sign(str, Enum):
    BOT = "⊥"
    NEG = "-"
    ZERO = "0"
    POS = "+"
    TOP = "⊤"

    @staticmethod
    def of(value: float) -> "Sign":
        if value < -1e-12:
            return Sign.NEG
        if value > 1e-12:
            return Sign.POS
        return Sign.ZERO

    @staticmethod
    def join(a: "Sign", b: "Sign") -> "Sign":
        if a == Sign.BOT:
            return b
        if b == Sign.BOT:
            return a
        if a == b:
            return a
        # Distinct non-bot signs join to TOP.
        return Sign.TOP

    @staticmethod
    def of_vector(v: np.ndarray) -> "Sign":
        """Reduce a vector to a single sign by joining its element-
        wise signs. A mixed sign vector reaches TOP fast."""
        out = Sign.BOT
        for x in v.ravel():
            out = Sign.join(out, Sign.of(float(x)))
            if out == Sign.TOP:
                break
        return out

    def leq(self, other: "Sign") -> bool:
        if self == other:
            return True
        if self == Sign.BOT:
            return True
        if other == Sign.TOP:
            return True
        return False


@dataclass
class AbstractValue:
    sign: Sign

    def describe(self) -> str:
        return self.sign.value


# ──────────────────────────────────────────────────────────────────────────
#  Transfer functions
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class TransferFn:
    """Per-operator transfer function, empirically calibrated.

    For each abstract input ``s_in`` we record the set of abstract
    outputs observed on probes. The transfer function is the *join*
    of those outputs — a sound over-approximation."""
    op_index: int
    table: dict[Sign, Sign] = field(default_factory=dict)
    n_calibrated: int = 0

    def __call__(self, s_in: Sign) -> Sign:
        return self.table.get(s_in, Sign.TOP)

    def calibrate(self, samples: int = 32, rng_seed: int = 0) -> None:
        fn = PHI.get(self.op_index)
        if fn is None:
            return
        rng = np.random.default_rng(rng_seed)
        # Probe inputs that span all four non-bottom signs.
        groups = {
            Sign.NEG: rng.uniform(-1.0, -0.05, size=(samples, 4)),
            Sign.POS: rng.uniform(0.05, 1.0, size=(samples, 4)),
            Sign.ZERO: np.zeros((samples, 4)),
            Sign.TOP: rng.uniform(-1.0, 1.0, size=(samples, 4)),
        }
        for s_in, batch in groups.items():
            joined = Sign.BOT
            for row in batch:
                try:
                    out = np.asarray(fn(row), dtype=float).ravel()
                except Exception:
                    joined = Sign.TOP
                    break
                joined = Sign.join(joined, Sign.of_vector(out))
                if joined == Sign.TOP:
                    break
            self.table[s_in] = joined
        self.n_calibrated = samples * 4

    def audit(self, holdout: int = 32, rng_seed: int = 1) -> dict[str, int]:
        """Run a hold-out audit; return counts of sound/unsound
        predictions per input sign."""
        fn = PHI.get(self.op_index)
        if fn is None:
            return {"sound": 0, "unsound": 0}
        rng = np.random.default_rng(rng_seed)
        sound = 0
        unsound = 0
        groups = {
            Sign.NEG: rng.uniform(-1.0, -0.05, size=(holdout, 4)),
            Sign.POS: rng.uniform(0.05, 1.0, size=(holdout, 4)),
            Sign.ZERO: np.zeros((holdout, 4)),
        }
        for s_in, batch in groups.items():
            pred = self(s_in)
            for row in batch:
                try:
                    out = np.asarray(fn(row), dtype=float).ravel()
                except Exception:
                    sound += 1  # symbolic failure → TOP covers everything
                    continue
                concrete = Sign.of_vector(out)
                if concrete.leq(pred):
                    sound += 1
                else:
                    unsound += 1
        return {"sound": sound, "unsound": unsound}


# ──────────────────────────────────────────────────────────────────────────
#  Analysis driver
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class AnalysisReport:
    op_index: int
    transfer: dict[str, str]
    audit_sound: int
    audit_unsound: int

    @property
    def successful(self) -> bool:
        return self.audit_unsound == 0

    def describe(self) -> str:
        ok = "✓" if self.successful else "✗"
        tbl = ", ".join(
            f"{k}→{v}" for k, v in self.transfer.items()
        )
        return (
            f"AbstractReport {ok} φ_{self.op_index}: {{{tbl}}}\n"
            f"   audit sound/unsound: "
            f"{self.audit_sound}/{self.audit_unsound}"
        )


def analyse_operator(
    op: int, *, samples: int = 32, holdout: int = 32,
) -> AnalysisReport:
    tf = TransferFn(op_index=op)
    tf.calibrate(samples=samples)
    audit = tf.audit(holdout=holdout)
    table = {k.value: v.value for k, v in tf.table.items()}
    return AnalysisReport(
        op_index=op, transfer=table,
        audit_sound=audit["sound"],
        audit_unsound=audit["unsound"],
    )


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(rep: AnalysisReport, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    # Encode the transfer table compactly.
    keys = ["⊥", "-", "0", "+", "⊤"]
    payload = np.array([
        float(rep.op_index),
        float(rep.audit_sound),
        float(rep.audit_unsound),
        1.0 if rep.successful else 0.0,
    ], dtype=float)
    trust = 1.0 if rep.successful else 0.0
    arena[f"abstract/phi_{rep.op_index}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith abstract interpretation (Zone 145)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    p.add_argument("--ops", type=int, nargs="*",
                   default=[1, 9, 38, 39, 45])
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print("# Zone 145 — abstract interpretation over PHI")
    print(f"#   sign lattice ⊥ ⊑ {{-, 0, +}} ⊑ ⊤")
    total_sound = total_unsound = 0
    for op in args.ops:
        rep = analyse_operator(op)
        print()
        print("   " + rep.describe().replace("\n", "\n   "))
        persist(rep, args.arena)
        total_sound += rep.audit_sound
        total_unsound += rep.audit_unsound

    print()
    print(f"   total sound={total_sound}, unsound={total_unsound}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
