"""
soilith_contract.py — behavioural contracts (Zone 142).

Eiffel's Design-by-Contract and Racket's contract system attach
**pre-** and **postconditions** to function values, blaming the
offending party when a contract is violated. Σoilith's stdlib gates
are already trust contracts; Zone 142 lifts them to a first-class
runtime system with:

* arbitrary predicates over ``Cell`` arguments;
* first-class blame (positive = the function; negative = the caller);
* higher-order arrow contracts that **flip domain blame** (the
  Findler–Felleisen insight);
* an empirical blame-tracking log that persists as
  ``contract/<name>``.

API
---
* ``Predicate(name, fn)`` — a named cell predicate.
* ``Contract(pre, post)`` — a pre/post pair.
* ``ContractedFn(name, fn, contract)`` — a wrapped function.
* ``arrow(domain_contract, codomain_contract)`` — a higher-order
  contract whose ``apply(fn, *args)`` returns a wrapped fn.
* ``CheckLog`` — running count of passes / +blame / -blame.

CLI
---
    python soilith_contract.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any, Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors and blame
# ──────────────────────────────────────────────────────────────────────────
class ContractError(Exception):
    pass


@dataclass(frozen=True)
class ContractBlame:
    party: str         # "positive" or "negative"
    contract: str
    reason: str

    def flip(self) -> "ContractBlame":
        other = "negative" if self.party == "positive" else "positive"
        return ContractBlame(other, self.contract, self.reason)


class ContractViolation(ContractError):
    def __init__(self, blame: ContractBlame) -> None:
        super().__init__(
            f"CONTRACT-BLAME on {blame.party} party of "
            f"{blame.contract!r}: {blame.reason}"
        )
        self.blame = blame


# ──────────────────────────────────────────────────────────────────────────
#  Predicates and contracts
# ──────────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Predicate:
    name: str
    fn: Callable[[Cell], bool]

    def __call__(self, cell: Cell) -> bool:
        return bool(self.fn(cell))


@dataclass
class Contract:
    name: str
    pre: Predicate | None = None
    post: Predicate | None = None


# Useful predicate library — these compose naturally with Zone 135.
def trust_at_least(tau: float) -> Predicate:
    return Predicate(
        name=f"trust>={tau}",
        fn=lambda c: c.trust + 1e-12 >= tau,
    )


def shape_eq(n: int) -> Predicate:
    return Predicate(
        name=f"shape==R^{n}",
        fn=lambda c: np.asarray(c.value, dtype=float).ravel().size == n,
    )


def positive_values() -> Predicate:
    return Predicate(
        name="all>0",
        fn=lambda c: bool(np.all(
            np.asarray(c.value, dtype=float).ravel() > 0
        )),
    )


def conjunction(*preds: Predicate) -> Predicate:
    return Predicate(
        name=" ∧ ".join(p.name for p in preds),
        fn=lambda c: all(p(c) for p in preds),
    )


# ──────────────────────────────────────────────────────────────────────────
#  Contracted functions
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class CheckLog:
    passed: int = 0
    failed_positive: int = 0
    failed_negative: int = 0

    @property
    def failed(self) -> int:
        return self.failed_positive + self.failed_negative


@dataclass
class ContractedFn:
    name: str
    fn: Callable[[Cell], Cell]
    contract: Contract
    log: CheckLog = field(default_factory=CheckLog)

    def __call__(self, arg: Cell) -> Cell:
        # PRE: violation → blame the CALLER ("negative")
        if self.contract.pre is not None and not self.contract.pre(arg):
            self.log.failed_negative += 1
            raise ContractViolation(ContractBlame(
                party="negative", contract=self.contract.name,
                reason=f"precondition violated: {self.contract.pre.name}",
            ))
        result = self.fn(arg)
        # POST: violation → blame the FUNCTION ("positive")
        if (self.contract.post is not None
                and not self.contract.post(result)):
            self.log.failed_positive += 1
            raise ContractViolation(ContractBlame(
                party="positive", contract=self.contract.name,
                reason=f"postcondition violated: {self.contract.post.name}",
            ))
        self.log.passed += 1
        return result


@dataclass
class ArrowContract:
    """Higher-order contract on a function value.

    When a contracted function ``fn`` is *passed as an argument* to
    another contracted function ``g``, ``g``'s domain check expects
    a function — and any contract violation that surfaces from inside
    that function is the *caller's* fault, not g's. The arrow
    contract flips the blame of its domain side accordingly."""
    name: str
    domain: Contract
    codomain: Contract

    def wrap(
        self, fn: Callable[[Cell], Cell],
    ) -> Callable[[Cell], Cell]:
        def wrapped(arg: Cell) -> Cell:
            if self.domain.pre is not None and not self.domain.pre(arg):
                raise ContractViolation(ContractBlame(
                    party="negative", contract=self.name,
                    reason=(
                        f"arrow domain pre violated: "
                        f"{self.domain.pre.name}"
                    ),
                ))
            try:
                result = fn(arg)
            except ContractViolation as exc:
                raise ContractViolation(exc.blame.flip())
            if (self.codomain.post is not None
                    and not self.codomain.post(result)):
                raise ContractViolation(ContractBlame(
                    party="positive", contract=self.name,
                    reason=(
                        f"arrow codomain post violated: "
                        f"{self.codomain.post.name}"
                    ),
                ))
            return result
        return wrapped


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(name: str, log: CheckLog, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(log.passed), float(log.failed_positive),
        float(log.failed_negative),
        1.0 if log.failed == 0 else 0.0,
    ], dtype=float)
    trust = 1.0 if log.failed == 0 else 0.4
    safe = "".join(c if c.isalnum() else "_" for c in name)[:60]
    arena[f"contract/{safe}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI / Demo
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith behavioural contracts (Zone 142)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print("# Zone 142 — behavioural contracts with first-class blame")

    print("\n# 1. Contract: pre = trust≥0.7, post = all values > 0")
    contract = Contract(
        name="positivity",
        pre=trust_at_least(0.7),
        post=positive_values(),
    )
    fn = ContractedFn(
        name="abs_then_one",
        fn=lambda c: Cell(value=np.abs(np.asarray(c.value, dtype=float))
                                  + 1e-3,
                          trust=c.trust, phase=c.phase),
        contract=contract,
    )

    print("   call with trust=0.8 → should pass")
    try:
        out = fn(Cell(value=np.array([1.0, -2.0]), trust=0.8, phase=0.0))
        print(f"     result {out.value}")
    except ContractViolation as exc:
        print(f"     ✗ {exc}")

    print("   call with trust=0.3 → negative blame (caller's fault)")
    try:
        fn(Cell(value=np.array([1.0]), trust=0.3, phase=0.0))
    except ContractViolation as exc:
        print(f"     ✓ {exc}")

    print("   inject a buggy fn that violates post → positive blame")
    bad_fn = ContractedFn(
        name="zero_thief",
        fn=lambda c: Cell(value=np.zeros_like(np.asarray(c.value)),
                          trust=c.trust, phase=c.phase),
        contract=contract,
    )
    try:
        bad_fn(Cell(value=np.array([1.0]), trust=0.9, phase=0.0))
    except ContractViolation as exc:
        print(f"     ✓ {exc}")

    print(f"   final log: passed={fn.log.passed}, "
          f"-blame={fn.log.failed_negative}, "
          f"+blame={bad_fn.log.failed_positive}")
    persist("positivity", fn.log, args.arena)

    print("\n# 2. Higher-order arrow contract — caller passes a bad fn")
    dom = Contract(name="dom", pre=shape_eq(2))
    cod = Contract(name="cod", post=positive_values())
    arrow = ArrowContract(name="map", domain=dom, codomain=cod)
    # Inner fn returns negative values — postcondition will fail.
    inner = lambda c: Cell(
        value=-np.abs(np.asarray(c.value, dtype=float)),
        trust=c.trust, phase=c.phase,
    )
    wrapped = arrow.wrap(inner)
    try:
        wrapped(Cell(value=np.array([1.0, 2.0]), trust=1.0, phase=0.0))
    except ContractViolation as exc:
        print(f"   ✓ {exc}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
