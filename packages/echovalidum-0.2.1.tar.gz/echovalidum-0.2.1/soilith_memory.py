"""
soilith_memory.py — scale-aware memory runtime (Zone 122).

Zones 116–121 produced *facts about Σoilith*: laws, topology, conservation,
catalog rows, and a magnitude verdict over the topology rows. Zone 122 is
the first runtime that **uses** a magnitude row as memory.

A ``ScaleAwareMemory`` instance is constructed from a tier-0
``magnitude/*`` entry in the unified catalog. Under the (ℤ/2)^k Cayley
convention the entry attests:

    k    = generators_approx           (independent axes)
    V    = order = 2^k                 (addressable positions)
    E    = k · 2^(k-1)                 (one edge per (state, generator) pair)
    F    = C(k, 2)                     (commutator squares)
    χ₁   = V − E                       (1-skeleton)
    χ₂   = V − E + F                   (2-complex)

Memory semantics
----------------
* An **address** is a length-k bit-string. ``"000"`` is the identity
  position; flipping bit ``i`` corresponds to applying generator ``i``.
* **Adjacency** is the Cayley graph relation: two addresses are
  neighbours iff their Hamming distance is exactly 1. That is the
  *only* legal one-step move; any cross-scale walk decomposes into
  generator flips.
* **Read / write** is over a backing dict from address to ``Cell``.
  Programs may write to any valid address, but a write to a
  *non-neighbour* of the last write is flagged as a neighbour
  violation. This is the address-level anomaly detector from the
  Zone 121 spec.
* **Audit** recomputes (V_eff, E_eff, F_eff, χ₁_eff) over the
  *populated* subgraph and compares to the attested χ. Drift in χ₁
  means the program has skipped a generator axis (under-populating)
  or written outside the lattice (impossible if ``write`` is the only
  ingress, but caught explicitly so external mutators that bypass
  the API still trip the audit). ``F_eff`` counts the *abstract*
  presentation 2-cells (one per generator pair whose commutator is
  witnessed in the population), matching what ``soilith_topology``
  writes; ``F_geometric`` reports the count of physical 4-corner
  squares (= ``k·2^(k-2)`` on a full ``(ℤ/2)^k`` population) for
  diagnostic purposes but does not drive ``chi_match``.

This is the runtime version of "memory is no longer an address; it is a
position in a group action, an adjacency, and a global shape constraint
— and the shape is checkable at every scale."

CLI
---
    python soilith_memory.py
    python soilith_memory.py --catalog catalog/discoveries.json
    python soilith_memory.py --slot magnitude/tier0_z2_cubed
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, field
from itertools import combinations, product
from math import comb
from pathlib import Path
import sys
from typing import Any, Iterable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Exceptions
# ──────────────────────────────────────────────────────────────────────────
class MemoryError_(Exception):
    """Base class for Zone 122 memory violations."""


class NotInLattice(MemoryError_):
    """Address is not a length-k bit-string of the loaded capsule."""


class NeighborViolation(MemoryError_):
    """Two addresses were declared adjacent but their Hamming distance is ≠ 1."""


class ChiDrift(MemoryError_):
    """The audited χ does not match the attested χ from the magnitude row."""


# ──────────────────────────────────────────────────────────────────────────
#  Audit report
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class AuditReport:
    """Snapshot of the *populated* memory subgraph vs the attested capsule."""

    attested: dict[str, int]            # {V, E, F, chi_1, chi_2, order, k}
    measured: dict[str, int]            # over the populated subgraph
    populated: int                      # how many addresses currently hold a Cell
    total: int                          # 2^k — the full lattice
    chi_match: bool                     # measured chi_1 == attested chi_1
    coverage: float                     # populated / total
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "attested": dict(self.attested),
            "measured": dict(self.measured),
            "populated": self.populated,
            "total": self.total,
            "chi_match": self.chi_match,
            "coverage": self.coverage,
            "notes": list(self.notes),
        }

    def describe(self) -> str:
        a, m = self.attested, self.measured
        lines = [
            "AuditReport — scale-aware memory",
            f"  attested  V={a['V']:>3d} E={a['E']:>3d} F={a['F']:>3d} "
            f"χ₁={a['chi_1']:>+d} χ₂={a['chi_2']:>+d}  (|G|=2^{a['k']})",
            f"  measured  V={m['V']:>3d} E={m['E']:>3d} F={m['F']:>3d} "
            f"χ₁={m['chi_1']:>+d} χ₂={m['chi_2']:>+d}  "
            f"(populated {self.populated}/{self.total} = {self.coverage:.2%})",
            f"  chi_match = {self.chi_match}",
        ]
        for note in self.notes:
            lines.append(f"  · {note}")
        return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────
#  Runtime
# ──────────────────────────────────────────────────────────────────────────
class ScaleAwareMemory:
    """Memory backed by a Zone 121 magnitude row (only tier-0 by default)."""

    def __init__(
        self,
        k: int,
        *,
        attested_V: int,
        attested_E: int,
        attested_F: int,
        attested_chi_1: int,
        attested_chi_2: int,
        topology_slot: str = "",
        probe_name: str = "",
    ) -> None:
        if k < 1:
            raise ValueError("k must be ≥ 1 for a non-trivial capsule")
        self.k = k
        self._attested = {
            "k": k,
            "order": 2 ** k,
            "V": int(attested_V),
            "E": int(attested_E),
            "F": int(attested_F),
            "chi_1": int(attested_chi_1),
            "chi_2": int(attested_chi_2),
        }
        self.topology_slot = topology_slot
        self.probe_name = probe_name
        self._store: dict[str, Cell] = {}
        self._last_write: str | None = None

    # ── factories ────────────────────────────────────────────────────────
    @classmethod
    def from_magnitude_entry(cls, entry: dict[str, Any]) -> "ScaleAwareMemory":
        if entry.get("kind") != "magnitude":
            raise ValueError(f"not a magnitude entry: kind={entry.get('kind')!r}")
        p = entry.get("payload", {})
        k = int(p.get("generators_approx", 0))
        if k < 1:
            raise ValueError(
                f"magnitude row {entry.get('slot')!r} has generators_approx={k}; "
                "need ≥ 1 for a usable capsule"
            )
        return cls(
            k=k,
            attested_V=int(p.get("V", 0)),
            attested_E=int(p.get("E", 0)),
            attested_F=int(p.get("F", 0)),
            attested_chi_1=int(p.get("chi_1", 0)),
            attested_chi_2=int(p.get("chi_2", 0)),
            topology_slot=str(p.get("topology_slot", "")),
            probe_name=str(p.get("probe_name", "")),
        )

    @classmethod
    def from_catalog(
        cls,
        catalog_path: Path,
        *,
        slot: str | None = None,
        tier: int = 0,
    ) -> "ScaleAwareMemory":
        """Load the highest-scoring magnitude row of the requested tier
        (or the named slot if given) from a Zone 118 manifest."""
        if not catalog_path.exists():
            raise FileNotFoundError(f"no catalog at {catalog_path}")
        data = json.loads(catalog_path.read_text(encoding="utf-8"))
        entries = data.get("entries", [])
        candidates = [e for e in entries if e.get("kind") == "magnitude"]
        if slot is not None:
            for e in candidates:
                if e.get("slot") == slot:
                    return cls.from_magnitude_entry(e)
            raise KeyError(f"no magnitude row at slot {slot!r}")
        candidates = [e for e in candidates if e.get("payload", {}).get("tier") == tier]
        if not candidates:
            raise KeyError(f"no magnitude rows at tier {tier}")
        candidates.sort(
            key=lambda e: -float(e.get("payload", {}).get("score", 0.0))
        )
        return cls.from_magnitude_entry(candidates[0])

    # ── lattice introspection ───────────────────────────────────────────
    @property
    def attested(self) -> dict[str, int]:
        return dict(self._attested)

    def positions(self) -> list[str]:
        """All 2^k legal addresses, in lexicographic bit-string order."""
        return [self._fmt(i) for i in range(2 ** self.k)]

    def _fmt(self, idx: int) -> str:
        return format(idx, f"0{self.k}b")

    def is_address(self, addr: str) -> bool:
        return (
            isinstance(addr, str)
            and len(addr) == self.k
            and all(c in "01" for c in addr)
        )

    def _check_address(self, addr: str) -> None:
        if not self.is_address(addr):
            raise NotInLattice(
                f"{addr!r} is not a length-{self.k} bit-string address"
            )

    def neighbors(self, addr: str) -> list[str]:
        """Cayley neighbours: addresses at Hamming distance exactly 1."""
        self._check_address(addr)
        out = []
        for i in range(self.k):
            out.append(self.walk(addr, i))
        return out

    def walk(self, addr: str, generator_index: int) -> str:
        """Apply generator ``generator_index`` (flip bit i)."""
        self._check_address(addr)
        if not 0 <= generator_index < self.k:
            raise IndexError(
                f"generator index {generator_index} outside [0, {self.k})"
            )
        bits = list(addr)
        bits[generator_index] = "1" if bits[generator_index] == "0" else "0"
        return "".join(bits)

    @staticmethod
    def hamming(a: str, b: str) -> int:
        if len(a) != len(b):
            raise ValueError(f"address widths differ: {len(a)} vs {len(b)}")
        return sum(ca != cb for ca, cb in zip(a, b))

    def expect_neighbor(self, prev: str, new: str) -> None:
        """Raise unless ``prev`` and ``new`` are exactly one generator apart.

        This is the address-level anomaly detector: any program that claims
        two consecutive writes form a one-step move must satisfy the Cayley
        adjacency, or the capsule rejects the move.
        """
        self._check_address(prev)
        self._check_address(new)
        d = self.hamming(prev, new)
        if d != 1:
            raise NeighborViolation(
                f"non-adjacent move: {prev!r} → {new!r} (Hamming distance {d}, "
                "Cayley adjacency requires 1)"
            )

    # ── reads and writes ────────────────────────────────────────────────
    def read(self, addr: str) -> Cell | None:
        self._check_address(addr)
        return self._store.get(addr)

    def write(self, addr: str, cell: Cell, *, enforce_adjacency: bool = False) -> None:
        self._check_address(addr)
        if enforce_adjacency and self._last_write is not None:
            self.expect_neighbor(self._last_write, addr)
        self._store[addr] = cell
        self._last_write = addr

    def write_path(self, addrs: Iterable[str], cells: Iterable[Cell]) -> None:
        """Write a sequence of addresses, enforcing adjacency between
        consecutive writes. Useful for explicit cross-scale walks."""
        prev: str | None = None
        for addr, cell in zip(addrs, cells):
            if prev is not None:
                self.expect_neighbor(prev, addr)
            self._store[addr] = cell
            self._last_write = addr
            prev = addr

    @property
    def populated(self) -> int:
        return len(self._store)

    @property
    def total(self) -> int:
        return 2 ** self.k

    def populated_addresses(self) -> list[str]:
        return sorted(self._store.keys())

    def snapshot(self) -> dict[str, Cell]:
        """Shallow copy of the backing store — the unit of rollback
        used by Zone 128's transactional wrapper."""
        return dict(self._store)

    def restore(self, snap: dict[str, Cell]) -> None:
        self._store = dict(snap)
        self._last_write = None

    # ── audit ────────────────────────────────────────────────────────────
    def audit(self, *, strict: bool = False) -> AuditReport:
        """Recompute (V, E, F, χ) over the *populated* induced subgraph
        and compare to the attested capsule. With ``strict=True`` a
        χ-mismatch raises ``ChiDrift``."""
        addrs = set(self._store.keys())
        V_eff = len(addrs)
        E_eff = 0
        for a, b in combinations(sorted(addrs), 2):
            if self.hamming(a, b) == 1:
                E_eff += 1
        # F here counts *abstract* commutator squares — one per pair of
        # generators (i, j) whose relation [g_i, g_j] = e is witnessed by
        # at least one fully-populated 4-corner square in the population.
        # This matches what soilith_topology.persist_topology writes, which
        # is F_abs = C(k, 2) for any abelian (ℤ/2)^k group. The *geometric*
        # count (k · 2^(k-2) faces of the k-cube) is reported separately
        # for diagnostic purposes but does not drive χ_match.
        F_eff = 0
        F_geo = 0
        if self.k >= 2:
            for i, j in combinations(range(self.k), 2):
                pair_has_witness = False
                fixed_indices = [b for b in range(self.k) if b not in (i, j)]
                for fixed in product("01", repeat=len(fixed_indices)):
                    base = ["0"] * self.k
                    for pos, bit in zip(fixed_indices, fixed):
                        base[pos] = bit
                    corners = []
                    for vi, vj in product("01", repeat=2):
                        base[i] = vi; base[j] = vj
                        corners.append("".join(base))
                    if all(c in addrs for c in corners):
                        F_geo += 1
                        pair_has_witness = True
                if pair_has_witness:
                    F_eff += 1
        chi_1_eff = V_eff - E_eff
        chi_2_eff = V_eff - E_eff + F_eff
        att = self._attested

        notes: list[str] = []
        coverage = V_eff / self.total if self.total else 0.0
        if V_eff < self.total:
            notes.append(
                f"partial population: {V_eff}/{self.total} addresses "
                f"({coverage:.2%}); χ-match requires full coverage."
            )
        full = V_eff == self.total
        chi_match = full and chi_1_eff == att["chi_1"] and chi_2_eff == att["chi_2"]
        if full and not chi_match:
            notes.append(
                f"χ drift: measured (χ₁,χ₂)=({chi_1_eff:+d},{chi_2_eff:+d}) "
                f"vs attested ({att['chi_1']:+d},{att['chi_2']:+d})"
            )

        report = AuditReport(
            attested=att,
            measured={
                "k": self.k,
                "order": self.total,
                "V": V_eff,
                "E": E_eff,
                "F": F_eff,
                "F_geometric": F_geo,
                "chi_1": chi_1_eff,
                "chi_2": chi_2_eff,
            },
            populated=V_eff,
            total=self.total,
            chi_match=chi_match,
            coverage=coverage,
            notes=notes,
        )
        if strict and full and not chi_match:
            raise ChiDrift(
                f"attested χ₁={att['chi_1']} but measured χ₁={chi_1_eff} "
                f"on full population — capsule has been mutated outside the API"
            )
        return report

    # ── debug ────────────────────────────────────────────────────────────
    def describe(self) -> str:
        att = self._attested
        return (
            f"ScaleAwareMemory  k={self.k}  |G|={att['order']}\n"
            f"  topology_slot = {self.topology_slot}\n"
            f"  probe_name    = {self.probe_name}\n"
            f"  attested      V={att['V']} E={att['E']} F={att['F']} "
            f"χ₁={att['chi_1']:+d} χ₂={att['chi_2']:+d}\n"
            f"  populated     {self.populated}/{self.total}"
        )


# ──────────────────────────────────────────────────────────────────────────
#  Sanity check at import: attested values are mathematically consistent
# ──────────────────────────────────────────────────────────────────────────
def expected_invariants(k: int) -> dict[str, int]:
    """The closed-form invariants of (ℤ/2)^k under the abelian involutive
    Cayley convention used in Zone 117."""
    V = 2 ** k
    E = k * (V // 2) if k >= 1 else 0
    F = comb(k, 2)
    return {
        "k": k,
        "order": V,
        "V": V,
        "E": E,
        "F": F,
        "chi_1": V - E,
        "chi_2": V - E + F,
    }


# ──────────────────────────────────────────────────────────────────────────
#  CLI — load a capsule, populate it, print the audit
# ──────────────────────────────────────────────────────────────────────────
def _default_catalog() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith scale-aware-memory runtime (Zone 122)."
    )
    p.add_argument("--catalog", type=Path, default=_default_catalog())
    p.add_argument("--slot", default=None,
                   help="magnitude slot (default: highest-scoring tier-0 row).")
    p.add_argument("--tier", type=int, default=0)
    args = p.parse_args(argv)

    try:
        mem = ScaleAwareMemory.from_catalog(
            args.catalog, slot=args.slot, tier=args.tier
        )
    except (FileNotFoundError, KeyError) as exc:
        print(f"# {exc}")
        return 1
    print(mem.describe())

    # Populate the whole lattice with deterministic ψ-cells.
    rng = np.random.default_rng(7)
    for i, addr in enumerate(mem.positions()):
        mem.write(addr, Cell(value=rng.standard_normal(4) * 0.1,
                              trust=1.0, phase=0.0))
    print()
    print(mem.audit().describe())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
