"""
soilith_descent.py — cross-capsule gauge descent (Zone 130).

Zone 124 discovered the *capsule symmetries* — φ-operators that
preserve a chosen scalar ``Q`` across the vertex / edge / face scales
of a single capsule. Zone 129 connected capsules via covering maps
(fibrations). Zone 130 asks: **which capsule symmetries descend
through a fibration?**

Formally, given a fibration ``π: G_src → G_tgt`` and a φ certified as
a Zone-124 symmetry on the source capsule, we say φ *descends* iff
applying φ to a pulled-back memory gives the same result as pulling
back the φ-applied target memory. The diagram

    target_mem ──φ──▶ φ(target_mem)
        │                 │
     pullback          pullback
        ▼                 ▼
    src_mem  ──φ──▶ φ(src_mem)

commutes. Equivalently, for every populated target cell ``c_t`` and
every fiber lift ``s ∈ π⁻¹(t)``::

    apply_phi(c_t).value  ≈  apply_phi(lift(c_t, s)).value

This is the runtime expression of "the gauge group acts compatibly
across scales."

A φ that descends is a *true cross-scale symmetry*; the same
gauge action can be applied at the coarse OR fine scale and the
results agree under the cover. A φ that doesn't descend is a
*scale-local symmetry* — valid on one capsule but not the cover.

Persistence
-----------
Each (fibration, φ, quantity) descent test is persisted as a
``descent/<fibration>/<phi>_<quantity>`` ψ-cell with a 7-float
payload ``[op_index, degree, max_per_cell_residual, descends_flag,
mean_residual, source_chi_ok, target_chi_ok]``.

CLI
---
    python soilith_descent.py
    python soilith_descent.py --kind cyclic_halving --quantity l2
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any, Iterable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402
from soilith_phi import PHI  # noqa: E402
from soilith_memory import ScaleAwareMemory  # noqa: E402
from soilith_pair_memory import PairGroupMemory  # noqa: E402
from soilith_fibration import Fibration  # noqa: E402
from soilith_gauge import _reduce, _safe_apply  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Verdict
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class DescentReport:
    fibration_name: str
    op_index: int
    quantity: str
    degree: int
    descends: bool                       # trivial constant-pullback diagram
    equivariant_descends: bool           # sign-twisted pullback diagram
    is_endo_on_target: bool
    is_endo_on_source: bool
    max_per_cell_residual: float
    equivariant_max_residual: float
    mean_per_cell_residual: float
    target_chi_match_after: bool
    source_chi_match_after: bool
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "fibration_name": self.fibration_name,
            "op_index": self.op_index,
            "quantity": self.quantity,
            "degree": self.degree,
            "descends": self.descends,
            "equivariant_descends": self.equivariant_descends,
            "is_endo_on_target": self.is_endo_on_target,
            "is_endo_on_source": self.is_endo_on_source,
            "max_per_cell_residual": self.max_per_cell_residual,
            "equivariant_max_residual": self.equivariant_max_residual,
            "mean_per_cell_residual": self.mean_per_cell_residual,
            "target_chi_match_after": self.target_chi_match_after,
            "source_chi_match_after": self.source_chi_match_after,
            "notes": list(self.notes),
        }

    def describe(self) -> str:
        ok = "✓" if self.descends else "✗"
        return (
            f"DescentReport {ok}  φ_{self.op_index}  preserves "
            f"{self.quantity}  across  {self.fibration_name}\n"
            f"  degree                = {self.degree}\n"
            f"  endo on target        = {self.is_endo_on_target}\n"
            f"  endo on source        = {self.is_endo_on_source}\n"
            f"  max per-cell residual = {self.max_per_cell_residual:.3e}\n"
            f"  mean per-cell residual= {self.mean_per_cell_residual:.3e}\n"
            f"  target χ_match (post) = {self.target_chi_match_after}\n"
            f"  source χ_match (post) = {self.source_chi_match_after}\n"
            + ("\n  · " + "\n  · ".join(self.notes) if self.notes else "")
        )


# ──────────────────────────────────────────────────────────────────────────
#  Probe data
# ──────────────────────────────────────────────────────────────────────────
def _populate_target(
    fibration: Fibration, *, seed: int = 0, cell_dim: int = 8,
) -> Any:
    """Fill the target capsule with deterministic test cells."""
    rng = np.random.default_rng(seed)
    tgt = fibration.target
    if tgt is None:
        return None
    if isinstance(tgt, ScaleAwareMemory):
        sa = tgt.attested
        mem = ScaleAwareMemory(
            k=tgt.k,
            attested_V=sa["V"], attested_E=sa["E"], attested_F=sa["F"],
            attested_chi_1=sa["chi_1"], attested_chi_2=sa["chi_2"],
            probe_name=tgt.probe_name,
        )
    elif isinstance(tgt, PairGroupMemory):
        sa = tgt.attested
        mem = PairGroupMemory(
            n=tgt.n,
            attested_V=sa["V"], attested_E=sa["E"], attested_F=sa["F"],
            attested_chi_1=sa["chi_1"], attested_chi_2=sa["chi_2"],
            capsule_probe=tgt.capsule_probe, cell_dim=cell_dim,
        )
    else:
        raise TypeError("unsupported target memory")
    for addr in mem.positions():
        v = rng.standard_normal(cell_dim) * 0.7
        mem.write(addr, Cell(value=v, trust=1.0, phase=0.0))
    return mem


def descend(
    fibration: Fibration,
    op_index: int,
    quantity: str = "l2",
    *,
    seed: int = 0,
    cell_dim: int = 8,
    tol: float = 1e-4,
) -> DescentReport:
    """Check whether φ ``op_index`` descends through ``fibration``."""
    op = PHI.get(op_index)
    notes: list[str] = []
    if op is None:
        notes.append(f"unknown operator φ_{op_index}")
        return DescentReport(
            fibration_name=fibration.name, op_index=op_index,
            quantity=quantity, degree=fibration.degree,
            descends=False, equivariant_descends=False,
            is_endo_on_target=False, is_endo_on_source=False,
            max_per_cell_residual=float("inf"),
            equivariant_max_residual=float("inf"),
            mean_per_cell_residual=float("inf"),
            target_chi_match_after=False, source_chi_match_after=False,
            notes=notes,
        )

    tgt_mem = _populate_target(fibration, seed=seed, cell_dim=cell_dim)
    if tgt_mem is None:
        notes.append("target is the trivial 1-point capsule; no descent")
        return DescentReport(
            fibration_name=fibration.name, op_index=op_index,
            quantity=quantity, degree=fibration.degree,
            descends=False, equivariant_descends=False,
            is_endo_on_target=False, is_endo_on_source=False,
            max_per_cell_residual=float("inf"),
            equivariant_max_residual=float("inf"),
            mean_per_cell_residual=float("inf"),
            target_chi_match_after=False, source_chi_match_after=False,
            notes=notes,
        )

    # 1. Apply φ on target, then pull back  → expected_src.
    expected_src = fibration.pullback(_apply_phi_inplace(tgt_mem, op, notes,
                                                        marker="target"))
    is_endo_on_target = not any(n.startswith("target:") for n in notes)
    target_chi = expected_src is not None and fibration.target is not None

    # 2. Pull back original target, then apply φ on source → actual_src.
    fresh_target = _repopulate_like(tgt_mem, seed=seed, cell_dim=cell_dim)
    pulled = fibration.pullback(fresh_target)
    actual_src = _apply_phi_inplace(pulled, op, notes, marker="source")
    is_endo_on_source = not any(n.startswith("source:") for n in notes)

    # 3. Compare cell-by-cell.
    max_resid = 0.0
    sum_resid = 0.0
    n_cells = 0
    if is_endo_on_source and is_endo_on_target:
        for addr in actual_src.positions():
            a_cell = actual_src.read(addr)
            e_cell = expected_src.read(addr)
            if a_cell is None or e_cell is None:
                continue
            try:
                qa = _reduce(quantity, np.asarray(a_cell.value, dtype=float))
                qe = _reduce(quantity, np.asarray(e_cell.value, dtype=float))
                resid = abs(qa - qe)
                max_resid = max(max_resid, resid)
                sum_resid += resid
                n_cells += 1
            except Exception:
                continue
    else:
        max_resid = float("inf")
    mean_resid = (sum_resid / n_cells) if n_cells > 0 else float("inf")

    # 4. χ checks on the post-image memories.
    try:
        tgt_after = _apply_phi_inplace(_repopulate_like(tgt_mem, seed=seed,
                                                        cell_dim=cell_dim),
                                       op, notes, marker="tgt_chi")
        t_chi_match = bool(tgt_after.audit().chi_match)
    except Exception as exc:
        t_chi_match = False
        notes.append(f"tgt_chi audit failed: {type(exc).__name__}: {exc}")
    try:
        s_chi_match = bool(actual_src.audit().chi_match) if is_endo_on_source else False
    except Exception:
        s_chi_match = False

    descends = (
        is_endo_on_target
        and is_endo_on_source
        and max_resid < tol
    )

    # 5. Equivariant descent test. Build a sign-twisted pullback:
    #    one fiber element holds c, the other holds −c. Then apply φ on
    #    source. For φ to descend equivariantly, the two fiber values
    #    after φ must STILL be sign-flipped copies of each other and
    #    their fiber-average must be zero (the equivariant pushforward
    #    is trivial). Any departure from that is the equivariant
    #    residual.
    eq_resid = _equivariant_descent_residual(fibration, op, quantity,
                                              seed=seed, cell_dim=cell_dim)
    equivariant_descends = (
        is_endo_on_target
        and is_endo_on_source
        and eq_resid < tol
    )

    return DescentReport(
        fibration_name=fibration.name, op_index=op_index,
        quantity=quantity, degree=fibration.degree,
        descends=descends,
        equivariant_descends=equivariant_descends,
        is_endo_on_target=is_endo_on_target,
        is_endo_on_source=is_endo_on_source,
        max_per_cell_residual=max_resid,
        equivariant_max_residual=eq_resid,
        mean_per_cell_residual=mean_resid,
        target_chi_match_after=t_chi_match,
        source_chi_match_after=s_chi_match,
        notes=notes,
    )


def _equivariant_descent_residual(
    fibration: Fibration,
    op,
    quantity: str,
    *,
    seed: int,
    cell_dim: int,
) -> float:
    """Build a Z/2-equivariant pullback (sign-flipped on the second
    fiber element), apply ``op`` to every cell, and measure the
    residual of fiber-averaging. For an odd ``op`` (op(−x) = −op(x))
    on a deg-2 cover, the residual is identically zero; for an
    even op, the residual equals ``2 · |op(±x)|`` (the average is
    NOT zero). The residual discriminates odd vs even φ."""
    src = fibration.source
    if not hasattr(src, "positions"):
        return float("inf")
    # Construct a fresh source memory with sign-twisted pullback.
    if isinstance(src, ScaleAwareMemory):
        sa = src.attested
        new_src = ScaleAwareMemory(
            k=src.k,
            attested_V=sa["V"], attested_E=sa["E"], attested_F=sa["F"],
            attested_chi_1=sa["chi_1"], attested_chi_2=sa["chi_2"],
            probe_name=src.probe_name,
        )
    elif isinstance(src, PairGroupMemory):
        sa = src.attested
        new_src = PairGroupMemory(
            n=src.n,
            attested_V=sa["V"], attested_E=sa["E"], attested_F=sa["F"],
            attested_chi_1=sa["chi_1"], attested_chi_2=sa["chi_2"],
            capsule_probe=src.capsule_probe, cell_dim=cell_dim,
        )
    else:
        return float("inf")
    rng = np.random.default_rng(seed)
    tgt = fibration.target
    if tgt is None:
        return float("inf")
    for tgt_addr in tgt.positions():
        c = rng.standard_normal(cell_dim) * 0.7
        lifts = fibration.lifts(tgt_addr)
        for k, s in enumerate(lifts):
            sign = 1.0 if (k % 2 == 0) else -1.0
            new_src.write(s, Cell(value=sign * c, trust=1.0, phase=0.0))
    # Apply φ in place on the source.
    bad = []
    _apply_phi_inplace(new_src, op, bad, marker="eq")
    if any(n.startswith("eq:") for n in bad):
        return float("inf")
    # Measure residual: fiber-average should be zero for odd ops.
    worst = 0.0
    for tgt_addr in tgt.positions():
        lifts = fibration.lifts(tgt_addr)
        cells = [new_src.read(s) for s in lifts]
        if any(c is None for c in cells):
            continue
        values = [np.asarray(c.value, dtype=float).ravel() for c in cells]
        shapes = {v.shape for v in values}
        if len(shapes) != 1:
            return float("inf")
        avg = np.mean(np.stack(values), axis=0)
        # Residual is the L∞ norm of the average; zero iff fiber-sum cancels.
        worst = max(worst, float(np.max(np.abs(avg))))
    return worst


def _apply_phi_inplace(memory, op, notes: list[str], *, marker: str):
    """Apply ``op`` to every populated cell of ``memory``. Tags
    failures in ``notes`` with ``marker``."""
    for addr in memory.positions():
        c = memory.read(addr)
        if c is None:
            continue
        x = np.asarray(c.value, dtype=float).ravel()
        y = _safe_apply(op, x)
        if y is None or y.shape != x.shape:
            notes.append(f"{marker}: φ failed/changed shape at {addr!r}")
            continue
        memory.write(addr, Cell(value=y, trust=c.trust, phase=c.phase))
    return memory


def _repopulate_like(template, *, seed: int, cell_dim: int):
    """Recreate a memory with the same shape and a fresh deterministic
    population."""
    if isinstance(template, ScaleAwareMemory):
        sa = template.attested
        out = ScaleAwareMemory(
            k=template.k,
            attested_V=sa["V"], attested_E=sa["E"], attested_F=sa["F"],
            attested_chi_1=sa["chi_1"], attested_chi_2=sa["chi_2"],
            probe_name=template.probe_name,
        )
    elif isinstance(template, PairGroupMemory):
        sa = template.attested
        out = PairGroupMemory(
            n=template.n,
            attested_V=sa["V"], attested_E=sa["E"], attested_F=sa["F"],
            attested_chi_1=sa["chi_1"], attested_chi_2=sa["chi_2"],
            capsule_probe=template.capsule_probe, cell_dim=cell_dim,
        )
    else:
        raise TypeError(f"unsupported memory: {type(template)!r}")
    rng = np.random.default_rng(seed)
    for addr in out.positions():
        out.write(addr, Cell(value=rng.standard_normal(cell_dim) * 0.7,
                             trust=1.0, phase=0.0))
    return out


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(report: DescentReport, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(report.op_index), float(report.degree),
        float(report.max_per_cell_residual),
        1.0 if report.descends else 0.0,
        float(report.mean_per_cell_residual),
        1.0 if report.source_chi_match_after else 0.0,
        1.0 if report.target_chi_match_after else 0.0,
        float(report.equivariant_max_residual),
        1.0 if report.equivariant_descends else 0.0,
    ], dtype=float)
    slot = (
        f"descent/{report.fibration_name}/"
        f"phi_{report.op_index}_{report.quantity}"
    )
    trust = 1.0 if report.descends else 0.3
    arena[slot] = Cell(value=payload, trust=trust, phase=0.0)


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith cross-capsule gauge descent (Zone 130)."
    )
    p.add_argument("--kind",
                   choices=["quotient_z2", "cyclic_halving", "all"],
                   default="all")
    p.add_argument("--quantity", default="l2")
    p.add_argument("--phi", type=int, nargs="+",
                   default=[28, 38, 39, 43])
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)

    fibrations: list[Fibration] = []
    if args.kind in ("quotient_z2", "all"):
        for k in (3, 4):
            fibrations.append(Fibration.quotient_z2(k, 0))
    if args.kind in ("cyclic_halving", "all"):
        for n in (4, 6, 8):
            fibrations.append(Fibration.cyclic_halving(n))

    print(f"# probing descent of φ ∈ {args.phi} on quantity '{args.quantity}'")
    descend_count = 0
    total = 0
    rows: list[DescentReport] = []
    for fib in fibrations:
        for phi_idx in args.phi:
            r = descend(fib, phi_idx, args.quantity, cell_dim=8)
            persist(r, args.arena)
            rows.append(r)
            total += 1
            if r.descends:
                descend_count += 1
                flag = "✓"
            else:
                flag = "·"
            eqflag = "✓" if r.equivariant_descends else "·"
            print(
                f"  {flag} {fib.name:<26s}  φ_{phi_idx:<3d}  "
                f"endo_t={r.is_endo_on_target} endo_s={r.is_endo_on_source}  "
                f"const_resid={r.max_per_cell_residual:.2e}  "
                f"eq_resid={r.equivariant_max_residual:.2e}  "
                f"const_descends={r.descends} eq_descends={r.equivariant_descends} [{eqflag}]"
            )
    eq_descends_count = sum(1 for r in rows if r.equivariant_descends)
    print(
        f"\n# {descend_count}/{total} (operator × fibration) pairs are "
        "constant-pullback cross-scale symmetries."
    )
    print(
        f"# {eq_descends_count}/{total} pairs ALSO descend through the "
        "Z/2-equivariant (sign-twisted) pullback — these are the *odd* "
        "operators that respect the deck transformation."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
