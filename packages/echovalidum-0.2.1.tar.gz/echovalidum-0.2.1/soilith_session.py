"""
soilith_session.py — session types from operator composition laws
(Zone 136).

Session types describe communication protocols as state machines.
Σoilith's analog is not channels but **operator-composition
algebra**: a sequence ``φ_{a₁} ∘ φ_{a₂} ∘ … ∘ φ_{aₙ}`` is a
*protocol run*; the 237 ``composition_law/*`` rows in the catalog
(Zone 127) tell us which compositions equal which — that's a
transition system.

A ``SessionType`` is a finite-state DFA over PHI operators:

* states are equivalence classes of φ-compositions modulo the
  catalog's composition laws;
* transitions are labelled by φ-indices;
* the *initial state* is the identity composition;
* the *accept states* are flagged by user assertion (e.g. "must
  return to identity" or "must reach a specific finite-order
  endo").

We build session types automatically from the catalog and check
whether a given sequence of φ-applications is a *legal trace*:
every transition is justified by a composition law or finite-order
fact in the catalog.

CLI
---
    python soilith_session.py
    python soilith_session.py --trace 38,38,38,38
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import json
from pathlib import Path
import sys
from typing import Any, Iterable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class SessionError(Exception):
    """Base class for Zone 136 errors."""


class IllegalTransition(SessionError):
    """No catalog evidence supports this op from this state."""


# ──────────────────────────────────────────────────────────────────────────
#  Compose laws
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class CompositionFact:
    """φ_i ∘ φ_j ≈ φ_k (or ≈ id if ``k_target == -1``)."""
    i: int
    j: int
    k_target: int             # -1 means "id"
    cell_dim: int


@dataclass
class FiniteOrderFact:
    op_index: int
    order: int                # smallest n such that φ^n ≈ id
    cell_dim: int


def _ig(p: dict[str, Any], k: str, default: int = 0) -> int:
    v = p.get(k, default)
    if v is None:
        return default
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


def load_facts(catalog: dict[str, Any]) -> tuple[
    list[CompositionFact], list[FiniteOrderFact],
]:
    comps: list[CompositionFact] = []
    fins: list[FiniteOrderFact] = []
    for e in catalog.get("entries", []):
        kind, p = e.get("kind"), e.get("payload", {})
        if kind == "composition_law":
            comps.append(CompositionFact(
                i=_ig(p, "i", -1), j=_ig(p, "j", -1),
                k_target=_ig(p, "k_target", -1),
                cell_dim=_ig(p, "cell_dim", 0),
            ))
        elif kind == "finite_order":
            fins.append(FiniteOrderFact(
                op_index=_ig(p, "op_index", -1),
                order=_ig(p, "order", 0),
                cell_dim=_ig(p, "cell_dim", 0),
            ))
    return comps, fins


# ──────────────────────────────────────────────────────────────────────────
#  Session DFA
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class SessionType:
    """A finite-state protocol over φ-compositions.

    State 0 = "identity composition" = the empty word. Other states
    are normal-form representatives drawn from finite-order
    operators (φ^k for k = 1..order−1) and named composition
    targets.
    """

    name: str
    states: list[str]
    transitions: dict[tuple[str, int], str]
    accept_states: set[str]

    @property
    def initial(self) -> str:
        return self.states[0]

    def step(self, state: str, op: int) -> str:
        key = (state, op)
        if key not in self.transitions:
            raise IllegalTransition(
                f"no transition from state {state!r} on op φ_{op}"
            )
        return self.transitions[key]

    def run(self, trace: Iterable[int]) -> "SessionRun":
        s = self.initial
        history = [s]
        for op in trace:
            s = self.step(s, op)
            history.append(s)
        return SessionRun(
            session=self.name, final_state=s,
            history=history, ops=list(trace),
            accepted=s in self.accept_states,
        )


@dataclass
class SessionRun:
    session: str
    final_state: str
    history: list[str]
    ops: list[int]
    accepted: bool

    def describe(self) -> str:
        ok = "✓" if self.accepted else "·"
        steps = " → ".join(
            f"{self.history[i]} --[φ_{op}]→ {self.history[i+1]}"
            for i, op in enumerate(self.ops)
        ) or "(empty trace)"
        return (
            f"SessionRun {ok}  {self.session}\n"
            f"  trace:    {steps}\n"
            f"  final:    {self.final_state}\n"
            f"  accepted: {self.accepted}"
        )


# ──────────────────────────────────────────────────────────────────────────
#  Builders
# ──────────────────────────────────────────────────────────────────────────
def cyclic_session(
    op: int, order: int, *, name: str | None = None,
) -> SessionType:
    """``ℤ/order``-protocol generated by a single finite-order
    operator. State ``i`` means "applied φ_op a total of ``i`` times
    modulo ``order``"; accept = back at state 0 (identity)."""
    nm = name or f"cyclic_phi_{op}_n{order}"
    states = [f"s_{i}" for i in range(order)]
    transitions: dict[tuple[str, int], str] = {}
    for i in range(order):
        transitions[(f"s_{i}", op)] = f"s_{(i + 1) % order}"
    return SessionType(
        name=nm,
        states=states,
        transitions=transitions,
        accept_states={"s_0"},
    )


def from_catalog(
    catalog: dict[str, Any], *, op_set: set[int] | None = None,
) -> list[SessionType]:
    """Auto-derive one session type per finite-order op in the
    catalog, optionally restricted to a chosen ``op_set``."""
    _, fins = load_facts(catalog)
    seen: dict[int, int] = {}
    for f in fins:
        if f.order < 2:
            continue                  # skip identity aliases
        if op_set is not None and f.op_index not in op_set:
            continue
        # keep the smallest order encountered
        if f.op_index not in seen or seen[f.op_index] > f.order:
            seen[f.op_index] = f.order
    return [
        cyclic_session(op, order)
        for op, order in sorted(seen.items())
    ]


def involution_pair_session(
    rot: int, inv: int, *, n: int, name: str | None = None,
) -> SessionType:
    """``ℤ/n × ℤ/2`` protocol from a Zone 127 pair-group row. State
    space = (rot_pos, inv_flag); accept = (0, 0)."""
    nm = name or f"pair_phi_{rot}_phi_{inv}_n{n}"
    states = [f"({k},{j})" for k in range(n) for j in (0, 1)]
    transitions: dict[tuple[str, int], str] = {}
    for k in range(n):
        for j in (0, 1):
            cur = f"({k},{j})"
            transitions[(cur, rot)] = f"({(k+1) % n},{j})"
            transitions[(cur, inv)] = f"({k},{1-j})"
    return SessionType(
        name=nm, states=states,
        transitions=transitions, accept_states={"(0,0)"},
    )


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(run: SessionRun, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(len(run.ops)),
        float(len(run.history)),
        1.0 if run.accepted else 0.0,
    ], dtype=float)
    slot = f"session/{_safe(run.session)}/run_{_short(run.ops)}"
    trust = 1.0 if run.accepted else 0.5
    arena[slot] = Cell(value=payload, trust=trust, phase=0.0)


def _safe(name: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in name)[:60]


def _short(ops: list[int]) -> str:
    if not ops:
        return "empty"
    s = "_".join(str(o) for o in ops[:6])
    if len(ops) > 6:
        s += f"__plus{len(ops)-6}"
    return s


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_catalog() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith session types (Zone 136)."
    )
    p.add_argument("--catalog", type=Path, default=_default_catalog())
    p.add_argument("--arena", type=Path, default=_default_arena())
    p.add_argument("--trace", default="38,38,38,38",
                   help="comma-separated φ indices")
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    catalog = json.loads(args.catalog.read_text(encoding="utf-8")) \
        if args.catalog.exists() else {"entries": []}

    print("# Zone 136 — session types from composition laws")
    sessions = from_catalog(catalog)
    print(f"#   {len(sessions)} cyclic sessions derived from catalog")
    for s in sessions[:6]:
        print(f"   {s.name}  ({len(s.states)} states)")

    if not sessions:
        return 0
    # pick the φ_38 session and run an empty + complete cycle
    s38 = next((s for s in sessions if "phi_38" in s.name), sessions[0])
    print(f"\n# 1. Run a complete cycle on {s38.name}")
    n = len(s38.states)
    run = s38.run([38] * n)
    print(run.describe())
    persist(run, args.arena)

    print(f"\n# 2. Partial trace (n−1 applications) does NOT accept")
    run2 = s38.run([38] * (n - 1))
    print(run2.describe())
    persist(run2, args.arena)

    print("\n# 3. User-provided trace from --trace")
    ops = [int(x) for x in args.trace.split(",") if x.strip()]
    try:
        run3 = s38.run(ops)
        print(run3.describe())
        persist(run3, args.arena)
    except IllegalTransition as exc:
        print(f"   ✗ {type(exc).__name__}: {exc}")

    print("\n# 4. Build the pair-group session ℤ/8 × ℤ/2 directly from "
          "the (φ_38, φ_39) Zone-127 row")
    pair = involution_pair_session(rot=38, inv=39, n=8)
    print(f"   {pair.name}  states={len(pair.states)}")
    long_run = pair.run([38, 39, 38, 39, 38, 39, 38, 39] * 2)
    print(long_run.describe())
    persist(long_run, args.arena)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
