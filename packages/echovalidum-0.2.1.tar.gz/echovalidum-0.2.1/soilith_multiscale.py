"""
soilith_multiscale.py — vertex → edge → face calculus on a capsule (Zone 123).

Zone 122 made a (ℤ/2)^k capsule into addressable memory. Zone 123 gives
that memory a *multi-scale operator algebra*. The user's framing is the
spec:

  zoom from vertex-local state  →  edge-level interactions
                                →  face/volume-level invariants

and the runtime invariant is the discrete exterior-calculus identity

      d² = 0  on every commutator face

which says: any 1-cochain that is the gradient of a 0-cochain has zero
curl on every face of the Cayley 2-complex. The face-curl is therefore
a topological defect detector: nonzero curl means the edge data is not
consistent with any single vertex field. Used at runtime, this catches
*cross-scale tampering*: a write that perturbs an edge value without
the matching vertex update.

What this module provides
-------------------------
``MultiScaleView(memory)`` — a read-only view over a ``ScaleAwareMemory``
that derives, on demand:

* ``vertex_field(reducer)``     — ``2^k`` scalars, one per address.
* ``edge_gradients(reducer)``   — ``k · 2^(k-1)`` scalars, one per
                                   oriented edge ``(source, target)``
                                   with source < target lexicographically.
* ``face_curls(reducer)``       — one scalar per *abstract* commutator
                                   face (a pair of generators); each is
                                   the sum of edge gradients around the
                                   square with the standard alternating
                                   sign convention.

The identity ``d² = 0`` says: when ``edge_gradients`` are derived from
``vertex_field`` via the runtime, every ``face_curl`` is zero to
floating-point precision. ``verify_closed_form()`` returns the L∞ of
the curls, which the runtime uses as a topological-defect score.

For *user-supplied* edge cochains (e.g. measurements taken on physical
edges, or edge-level features synthesized from another model),
``closure_residual(edge_values)`` checks whether they form a closed
1-cochain — i.e., whether they could have come from any vertex field
at all.

Lifting a Zone 120 conservation law across scales
-------------------------------------------------
``lift_conservation(op, quantity)`` applies ``φ_op`` to every cell of
the capsule and checks the three scales independently:

* vertex level — does ``Σ Q(cell)`` stay invariant?
* edge level   — does the L1 of edge gradients stay invariant?
* face level   — does the L∞ of face curls stay zero (they must, by
                 d²=0; but a faithful Zone 120 operator preserves this).

The verdict is a ``ConservationLift`` dataclass with one residual per
scale and an ``all_match`` flag. φ_38 (L2-preserving) lifts cleanly
across all three scales on the (ℤ/2)⁴ capsule; an operator that
breaks L2 fails the vertex check immediately.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from itertools import combinations
from typing import Callable

import numpy as np

from soilith_lang import Cell
from soilith_memory import ScaleAwareMemory


# ──────────────────────────────────────────────────────────────────────────
#  Reducers — cell → scalar
# ──────────────────────────────────────────────────────────────────────────
def _l2(v: np.ndarray) -> float:
    return float(np.linalg.norm(np.asarray(v, dtype=float).ravel()))


def _l1(v: np.ndarray) -> float:
    return float(np.sum(np.abs(np.asarray(v, dtype=float).ravel())))


def _sum(v: np.ndarray) -> float:
    return float(np.sum(np.asarray(v, dtype=float).ravel()))


def _mean(v: np.ndarray) -> float:
    x = np.asarray(v, dtype=float).ravel()
    return float(np.mean(x)) if x.size else 0.0


REDUCERS: dict[str, Callable[[np.ndarray], float]] = {
    "l2": _l2,
    "l1": _l1,
    "sum": _sum,
    "mean": _mean,
}


def _resolve(reducer: str | Callable[[np.ndarray], float]) -> Callable[[np.ndarray], float]:
    if callable(reducer):
        return reducer
    if reducer not in REDUCERS:
        raise KeyError(f"unknown reducer {reducer!r}; use one of {sorted(REDUCERS)}")
    return REDUCERS[reducer]


# ──────────────────────────────────────────────────────────────────────────
#  Verdicts
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class ConservationLift:
    """Whether a Zone 120 conservation law lifts across vertex/edge/face."""

    op_index: int
    quantity: str
    vertex_residual: float
    edge_residual: float
    face_residual: float
    all_match: bool
    notes: list[str] = field(default_factory=list)

    def describe(self) -> str:
        ok = "✓" if self.all_match else "✗"
        return (
            f"ConservationLift  {ok}  φ_{self.op_index} preserves "
            f"{self.quantity}\n"
            f"  vertex residual = {self.vertex_residual:.3e}\n"
            f"  edge residual   = {self.edge_residual:.3e}\n"
            f"  face residual   = {self.face_residual:.3e}\n"
            f"  all_match       = {self.all_match}"
        )


# ──────────────────────────────────────────────────────────────────────────
#  Multi-scale view
# ──────────────────────────────────────────────────────────────────────────
class MultiScaleView:
    """Vertex/edge/face read-only view over a ``ScaleAwareMemory``.

    Conventions
    -----------
    * **Edges** are oriented by lexicographic address order: an edge
      between ``a`` and ``b`` has source ``min(a, b)`` and target
      ``max(a, b)``. ``edge_gradients`` returns ``f(target) − f(source)``.
    * **Faces** are abstract commutator squares indexed by the pair
      of generator indices ``(i, j)`` with ``i < j``. There are
      ``k · 2^(k-2)`` such squares for ``k ≥ 2`` — one per ``(i, j)``
      pair per assignment of the remaining bits — but the *abstract*
      F (matching ``soilith_topology``) is ``C(k, 2)``. ``face_curls``
      returns one scalar per *physical* square; ``face_curls_abstract``
      returns one per abstract pair (the L1 of physical curls in
      that pair).
    """

    def __init__(self, memory: ScaleAwareMemory) -> None:
        self.mem = memory
        self.k = memory.k

    # ── vertex scale ────────────────────────────────────────────────────
    def vertex_field(
        self, reducer: str | Callable = "l2"
    ) -> dict[str, float]:
        """``addr → scalar`` for every populated address; 0.0 elsewhere."""
        f = _resolve(reducer)
        out: dict[str, float] = {}
        for addr in self.mem.positions():
            cell = self.mem.read(addr)
            out[addr] = f(cell.value) if cell is not None else 0.0
        return out

    def vertex_sum(self, reducer: str | Callable = "l2") -> float:
        return float(sum(self.vertex_field(reducer).values()))

    # ── edge scale ──────────────────────────────────────────────────────
    def _oriented_edges(self) -> list[tuple[str, str, int]]:
        """``(source, target, generator_index)``, source < target lexicographically."""
        out: list[tuple[str, str, int]] = []
        for addr in self.mem.positions():
            for i in range(self.k):
                tgt = self.mem.walk(addr, i)
                if addr < tgt:
                    out.append((addr, tgt, i))
        return out

    def edge_gradients(
        self, reducer: str | Callable = "l2"
    ) -> dict[tuple[str, str], float]:
        """``df(e) = f(target) − f(source)`` for every Cayley edge."""
        vf = self.vertex_field(reducer)
        return {
            (s, t): vf[t] - vf[s]
            for s, t, _ in self._oriented_edges()
        }

    def edge_sum(self, reducer: str | Callable = "l2") -> float:
        return float(sum(abs(v) for v in self.edge_gradients(reducer).values()))

    # ── face scale ──────────────────────────────────────────────────────
    def _faces(self) -> list[tuple[int, int, str, str, str, str]]:
        """Each physical commutator square: ``(i, j, c00, c10, c11, c01)``
        traversed counterclockwise (i is the "x" generator, j is "y")."""
        out: list[tuple[int, int, str, str, str, str]] = []
        if self.k < 2:
            return out
        for i, j in combinations(range(self.k), 2):
            fixed_indices = [b for b in range(self.k) if b not in (i, j)]
            for fixed_idx in range(2 ** len(fixed_indices)):
                base = ["0"] * self.k
                for pos, bit_offset in enumerate(fixed_indices):
                    base[bit_offset] = "1" if (fixed_idx >> pos) & 1 else "0"
                c00 = list(base); c10 = list(base); c11 = list(base); c01 = list(base)
                c10[i] = "1"
                c11[i] = "1"; c11[j] = "1"
                c01[j] = "1"
                out.append((i, j, "".join(c00), "".join(c10),
                            "".join(c11), "".join(c01)))
        return out

    def face_curls(
        self, reducer: str | Callable = "l2"
    ) -> dict[tuple[int, int, str], float]:
        """``ddf(F) = Σ (oriented edge gradients around F)``.

        For a 0-cochain ``f`` this is identically zero on every face
        by the discrete ``d² = 0`` identity. A nonzero result reveals
        that the data does not arise from any single vertex field.
        Returned key is ``(i, j, corner_signature)`` where the
        corner_signature is the c00 address of that physical square.
        """
        vf = self.vertex_field(reducer)
        out: dict[tuple[int, int, str], float] = {}
        for i, j, c00, c10, c11, c01 in self._faces():
            # Boundary walk: c00 →i c10 →j c11 →i c01 →j c00.
            curl = (
                (vf[c10] - vf[c00])
                + (vf[c11] - vf[c10])
                - (vf[c11] - vf[c01])
                - (vf[c01] - vf[c00])
            )
            out[(i, j, c00)] = float(curl)
        return out

    def face_sum(self, reducer: str | Callable = "l2") -> float:
        return float(sum(abs(v) for v in self.face_curls(reducer).values()))

    # ── consistency checks ──────────────────────────────────────────────
    def closed_form_residual(self, reducer: str | Callable = "l2") -> float:
        """L∞ of face curls when edge data is vertex-derived.

        By d²=0 this is 0 to floating-point precision. A nonzero
        result means the runtime view is internally inconsistent.
        """
        curls = self.face_curls(reducer)
        if not curls:
            return 0.0
        return float(max(abs(v) for v in curls.values()))

    def closure_residual(
        self,
        edge_values: dict[tuple[str, str], float],
    ) -> float:
        """L∞ face curl of an arbitrary 1-cochain.

        A user supplies ``edge_values: oriented_edge → scalar``; this
        returns the max ``|d(edge_values)(F)|`` over all faces. Zero
        means the cochain is *closed* (could be a vertex gradient);
        nonzero is the topological-defect score.
        """
        # Indexed by (source, target).
        def lookup(s: str, t: str) -> float:
            if s < t:
                return edge_values.get((s, t), 0.0)
            return -edge_values.get((t, s), 0.0)

        worst = 0.0
        for i, j, c00, c10, c11, c01 in self._faces():
            curl = (
                lookup(c00, c10)
                + lookup(c10, c11)
                - lookup(c01, c11)
                - lookup(c00, c01)
            )
            worst = max(worst, abs(curl))
        return float(worst)

    # ── lifting Zone 120 conservation across scales ─────────────────────
    def lift_conservation(
        self,
        op_index: int,
        quantity: str,
        *,
        tol: float = 1e-6,
    ) -> ConservationLift:
        """Apply ``φ_op`` cellwise and check vertex/edge/face invariants.

        ``quantity`` is the reducer name (e.g. ``"l2"``, ``"sum"``); a
        Zone 120 ``conservation/phi_<op>/<quantity>`` law guarantees the
        vertex sum is preserved. The edge L1 *should* also be preserved
        when φ_op acts pointwise (the reducer commutes with cellwise
        composition), and the face L∞ remains 0 by d²=0.
        """
        from soilith_phi import PHI

        before = MultiScaleView(self.mem)
        v0 = before.vertex_sum(quantity)
        e0 = before.edge_sum(quantity)
        f0 = before.closed_form_residual(quantity)

        op = PHI.get(op_index)
        notes: list[str] = []
        if op is None:
            notes.append(f"PHI[{op_index}] not registered")
            return ConservationLift(
                op_index=op_index,
                quantity=quantity,
                vertex_residual=float("inf"),
                edge_residual=float("inf"),
                face_residual=float("inf"),
                all_match=False,
                notes=notes,
            )

        # Build a transient capsule with cells = op(cell) for every address.
        transformed = ScaleAwareMemory(
            k=self.k,
            attested_V=self.mem.attested["V"],
            attested_E=self.mem.attested["E"],
            attested_F=self.mem.attested["F"],
            attested_chi_1=self.mem.attested["chi_1"],
            attested_chi_2=self.mem.attested["chi_2"],
            topology_slot=self.mem.topology_slot,
            probe_name=self.mem.probe_name,
        )
        for addr in self.mem.positions():
            src = self.mem.read(addr)
            if src is None:
                continue
            try:
                y = op(np.asarray(src.value, dtype=float))
                if isinstance(y, tuple):
                    parts = [np.asarray(p) for p in y]
                    if any(np.iscomplexobj(p) for p in parts):
                        notes.append(f"φ_{op_index} produced non-real output (complex tuple)")
                        return ConservationLift(
                            op_index=op_index,
                            quantity=quantity,
                            vertex_residual=float("inf"),
                            edge_residual=float("inf"),
                            face_residual=float("inf"),
                            all_match=False,
                            notes=notes,
                        )
                    y = np.concatenate(
                        [p.astype(float).ravel() for p in parts]
                    )
                y = np.asarray(y)
                if np.iscomplexobj(y):
                    notes.append(f"φ_{op_index} produced non-real output")
                    return ConservationLift(
                        op_index=op_index,
                        quantity=quantity,
                        vertex_residual=float("inf"),
                        edge_residual=float("inf"),
                        face_residual=float("inf"),
                        all_match=False,
                        notes=notes,
                    )
                y = y.astype(np.float64, copy=False)
                if not np.all(np.isfinite(y)):
                    notes.append(f"φ_{op_index} produced non-finite output")
                    return ConservationLift(
                        op_index=op_index,
                        quantity=quantity,
                        vertex_residual=float("inf"),
                        edge_residual=float("inf"),
                        face_residual=float("inf"),
                        all_match=False,
                        notes=notes,
                    )
            except Exception as exc:  # pragma: no cover — defensive
                notes.append(f"φ_{op_index} raised {type(exc).__name__}: {exc}")
                return ConservationLift(
                    op_index=op_index,
                    quantity=quantity,
                    vertex_residual=float("inf"),
                    edge_residual=float("inf"),
                    face_residual=float("inf"),
                    all_match=False,
                    notes=notes,
                )
            transformed.write(addr, Cell(value=y, trust=src.trust, phase=src.phase))

        after = MultiScaleView(transformed)
        v_resid = abs(after.vertex_sum(quantity) - v0) / max(1.0, abs(v0))
        e_resid = abs(after.edge_sum(quantity) - e0) / max(1.0, abs(e0))
        f_resid = after.closed_form_residual(quantity)

        return ConservationLift(
            op_index=op_index,
            quantity=quantity,
            vertex_residual=float(v_resid),
            edge_residual=float(e_resid),
            face_residual=float(f_resid),
            all_match=(v_resid < tol and e_resid < tol and f_resid < tol),
            notes=notes,
        )


# ──────────────────────────────────────────────────────────────────────────
#  Convenience
# ──────────────────────────────────────────────────────────────────────────
def view(memory: ScaleAwareMemory) -> MultiScaleView:
    return MultiScaleView(memory)
