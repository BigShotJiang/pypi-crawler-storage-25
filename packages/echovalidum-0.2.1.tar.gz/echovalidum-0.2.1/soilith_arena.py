"""
soilith_arena.py — Persistent ψ-arena: durable storage of the trust-coherence
lattice across program runs.

An ``Arena`` is a single ``.arena`` file (a versioned, atomic-write pickle)
that holds a dict[str, Cell]. Programs `save` cells into it and `load` them
back — across processes, across reboots — so memory survives between sessions.

File layout
-----------
    +--------+--------+----------- pickled dict[str, Cell] ------------+
    | magic  |  ver   | { "name": Cell(value, trust, phase), ... }     |
    +--------+--------+-----------------------------------------------+
    magic = b"\\xcf\\x9c\\xce\\xa3\\x41"   ("ϜΣA")
    ver   = uint16 little-endian (currently 1)

Writes are **atomic**: the arena writes to ``<path>.tmp`` and ``os.replace`` s
it onto ``<path>``, so a crash mid-write never corrupts an existing arena.
"""

from __future__ import annotations

import os
import pickle
import struct
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator

sys.path.insert(0, str(Path(__file__).parent))
from soilith_lang import Cell  # noqa: E402


_MAGIC = b"\xcf\x9c\xce\xa3\x41"  # ϜΣA
_VERSION = 1


def _is_cell(c: object) -> bool:
    """Duck-typed Cell check — robust to the __main__ vs imported-module class identity
    quirk (running ``python soilith_lang.py`` makes Cell live under ``__main__``)."""
    return (
        type(c).__name__ == "Cell"
        and hasattr(c, "value")
        and hasattr(c, "trust")
        and hasattr(c, "phase")
    )


@dataclass
class Arena:
    """A persistent named-cell store on the trust-coherence lattice."""

    path: Path
    cells: dict[str, Cell] = field(default_factory=dict)
    autoflush: bool = True

    @classmethod
    def open(cls, path: str | Path, autoflush: bool = True) -> "Arena":
        p = Path(path)
        if p.exists():
            return cls(path=p, cells=cls._load(p), autoflush=autoflush)
        p.parent.mkdir(parents=True, exist_ok=True)
        a = cls(path=p, autoflush=autoflush)
        a.flush()
        return a

    # ── persistence ──────────────────────────────────────────────────────────
    @staticmethod
    def _load(path: Path) -> dict[str, Cell]:
        with open(path, "rb") as f:
            magic = f.read(len(_MAGIC))
            if magic != _MAGIC:
                raise ValueError(f"{path.name}: not a Σoilith arena file")
            (ver,) = struct.unpack("<H", f.read(2))
            if ver != _VERSION:
                raise ValueError(f"{path.name}: unsupported arena version {ver}")
            payload = pickle.loads(f.read())
        if not isinstance(payload, dict):
            raise ValueError(f"{path.name}: corrupt arena (root is not a dict)")
        return payload

    def flush(self) -> None:
        # Best-effort atomic write: prefer tmp + replace; on Windows that races
        # against AV scanners, so fall back to a direct write if replace fails.
        # Either way, the magic + version header on the next load catches a
        # truncated file.
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        payload = _MAGIC + struct.pack("<H", _VERSION) + pickle.dumps(
            self.cells, protocol=pickle.HIGHEST_PROTOCOL
        )
        try:
            with open(tmp, "wb") as f:
                f.write(payload)
            os.replace(tmp, self.path)
        except (PermissionError, OSError):
            try:
                if tmp.exists():
                    tmp.unlink()
            except OSError:
                pass
            with open(self.path, "wb") as f:
                f.write(payload)

    # ── dict-like API ────────────────────────────────────────────────────────
    def __contains__(self, name: str) -> bool:
        return name in self.cells

    def __getitem__(self, name: str) -> Cell:
        if name not in self.cells:
            raise KeyError(f"arena has no cell {name!r}")
        return self.cells[name]

    def __setitem__(self, name: str, cell: Cell) -> None:
        if not _is_cell(cell):
            raise TypeError(
                f"arena cells must be Cell instances (got {type(cell).__name__})"
            )
        self.cells[name] = cell
        if self.autoflush:
            self.flush()

    def __delitem__(self, name: str) -> None:
        del self.cells[name]
        if self.autoflush:
            self.flush()

    def __iter__(self) -> Iterator[str]:
        return iter(self.cells)

    def __len__(self) -> int:
        return len(self.cells)

    def keys(self):
        return self.cells.keys()

    def items(self):
        return self.cells.items()

    def __repr__(self) -> str:
        return f"Arena(path={self.path.name!r}, cells={len(self.cells)})"
