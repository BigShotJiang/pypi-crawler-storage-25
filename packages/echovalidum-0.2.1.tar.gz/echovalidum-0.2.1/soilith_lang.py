"""
soilith_lang.py — Σoilith: a small programming language whose memory model is
a trust-coherence lattice.

Memory model
------------
Every named value is a ``Cell`` on the lattice ``L = (V, ⊑, ∧, ∨, ⊥, ⊤)``
where:
    V        : numpy ndarray payload (the ψ value)
    trust    : float in [0, 1]   — anchors ⊥ (0) and ⊤ (1)
    phase    : float             — θ angle on the spiral
    ⊑        : a ⊑ b iff trust(a) ≤ trust(b) and value(a) ≤ value(b) pointwise
    ∧ (meet) : pointwise min on values, min on trust, mean on phase
    ∨ (join) : pointwise max on values, max on trust, mean on phase
    ⊥        : Cell(value=0, trust=0)         — silent / no-trust bottom
    ⊤        : Cell(value=Σ_s·ones, trust=1)  — fully-trusted top

The built-in instruction set is the morphism set ``PHI = {φ_0 … φ_50}`` from
``soilith_phi.py``. Each ``phi(k, …)`` call returns a fresh ``Cell`` whose
trust decays slightly with depth-from-seed but is bounded below by τ when
the operation is run inside a ``when ρ(ψ) >= τ:`` guard.

Syntax (ASCII + Unicode aliases)
--------------------------------
    let  name = expr         # bind a cell
    trust  name = number     # bind a trust scalar (also usable as expr)
    when expr >= expr:       # trust/coherence guard
        ...
    end
    echo  expr -> name       # write into echo-stack `name` (append)
    yield expr               # mark as the program's output
    print expr               # print a cell's summary

    expr := term  (('meet'|'join'|'<='|'+'|'-') term)*
    term := factor (('*'|'/') factor)*
    factor :=
        number
        | ident
        | 'phi' '(' int (',' expr | ',' kw '=' expr)* ')'
        | 'norm' '(' expr ')'
        | 'top' | 'bot' | '⊤' | '⊥'
        | '(' expr ')'

Unicode aliases accepted: ψ_k, φ_k, ∧ for meet, ∨ for join, ⊑ for ≤,
                          ⊤ for top, ⊥ for bot, → for ->.
Lines starting with ``#`` are comments.

CLI
---
    python soilith_lang.py path/to/program.sol
    python soilith_lang.py --demo
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

# Import morphism instruction set from the sibling module.
sys.path.insert(0, str(Path(__file__).parent))
import soilith_phi as sp  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────────
# Lattice memory model
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class Cell:
    """A ψ cell on the trust-coherence lattice."""

    value: np.ndarray
    trust: float = 1.0
    phase: float = 0.0

    def __post_init__(self) -> None:
        self.value = np.asarray(self.value, dtype=float)
        self.trust = float(np.clip(self.trust, 0.0, 1.0))

    @staticmethod
    def _align(a: np.ndarray, b: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        af, bf = a.ravel(), b.ravel()
        n = max(af.size, bf.size)
        if n == 0:
            return af, bf
        return np.resize(af, n), np.resize(bf, n)

    def meet(self, other: "Cell") -> "Cell":
        u, v = self._align(self.value, other.value)
        return Cell(
            value=np.minimum(u, v),
            trust=min(self.trust, other.trust),
            phase=0.5 * (self.phase + other.phase),
        )

    def join(self, other: "Cell") -> "Cell":
        u, v = self._align(self.value, other.value)
        return Cell(
            value=np.maximum(u, v),
            trust=max(self.trust, other.trust),
            phase=0.5 * (self.phase + other.phase),
        )

    def leq(self, other: "Cell") -> bool:
        u, v = self._align(self.value, other.value)
        return bool(self.trust <= other.trust + 1e-12 and np.all(u <= v + 1e-9))

    def coherence(self) -> float:
        """Scalar ρ(ψ) used for trust guards: ‖ψ‖ scaled by trust."""
        return float(np.linalg.norm(self.value) * self.trust)

    def __add__(self, o: "Cell") -> "Cell":
        u, v = self._align(self.value, o.value)
        return Cell(u + v, min(self.trust, o.trust), 0.5 * (self.phase + o.phase))

    def __sub__(self, o: "Cell") -> "Cell":
        u, v = self._align(self.value, o.value)
        return Cell(u - v, min(self.trust, o.trust), 0.5 * (self.phase + o.phase))

    def __mul__(self, o: Any) -> "Cell":
        if isinstance(o, Cell):
            u, v = self._align(self.value, o.value)
            return Cell(u * v, min(self.trust, o.trust), 0.5 * (self.phase + o.phase))
        return Cell(self.value * float(o), self.trust, self.phase)

    def __truediv__(self, o: Any) -> "Cell":
        if isinstance(o, Cell):
            u, v = self._align(self.value, o.value)
            return Cell(sp._safe_div(u, v), min(self.trust, o.trust), self.phase)
        return Cell(self.value / float(o), self.trust, self.phase)

    def __repr__(self) -> str:
        return (
            f"ψ(shape={self.value.shape}, ‖·‖={np.linalg.norm(self.value):.4f},"
            f" trust={self.trust:.3f}, θ={self.phase:.3f})"
        )


def TOP(n: int = 16, Sigma_s: float = sp.SIGMA_S) -> Cell:
    return Cell(np.full(n, Sigma_s), trust=1.0, phase=0.0)


def BOT(n: int = 16) -> Cell:
    return Cell(np.zeros(n), trust=0.0, phase=0.0)


# ──────────────────────────────────────────────────────────────────────────────
# Lexer
# ──────────────────────────────────────────────────────────────────────────────
# Unicode aliases that fold to the canonical token text:
_UNICODE_FOLD = {
    "∧": "meet",
    "∨": "join",
    "⊑": "<=",
    "⊤": "top",
    "⊥": "bot",
    "→": "->",
    "ψ": "psi",   # ψ_3 → psi_3
    "φ": "phi",   # φ(3, …) → phi(3, …)
    "Σ": "Sigma", # Σ_s → Sigma_s
    "ζ": "zeta",
    "τ": "tau",
}

_KEYWORDS = {
    "let", "trust", "when", "end", "echo", "yield", "print",
    "phi", "norm", "top", "bot", "meet", "join", "true", "false",
    "fn", "psi", "import",
    "arena", "save", "load", "as",
    "agent", "quorum", "of",
    "gossip", "broadcast", "sync",
    "with_trust",
}


class TrustError(RuntimeError):
    """Raised when a refinement-type predicate on the trust-coherence lattice fails."""


class QuorumError(RuntimeError):
    """Raised when a quorum-gated arena write violates roster or agreement rules."""


@dataclass
class Tok:
    kind: str
    value: Any
    line: int


def _fold_unicode(src: str) -> str:
    for k, v in _UNICODE_FOLD.items():
        src = src.replace(k, v)
    # Subscript digits → ASCII digits (so ψ₀ → psi0).
    subs = str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789")
    return src.translate(subs)


def lex(src: str) -> list[Tok]:
    src = _fold_unicode(src)
    toks: list[Tok] = []
    line = 1
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == "\n":
            toks.append(Tok("NL", "\n", line))
            line += 1
            i += 1
            continue
        if c in " \t\r":
            i += 1
            continue
        if c == "#":
            while i < n and src[i] != "\n":
                i += 1
            continue
        if c == '"':
            j = i + 1
            while j < n and src[j] != '"':
                if src[j] == "\\" and j + 1 < n:
                    j += 2
                    continue
                if src[j] == "\n":
                    raise SyntaxError(f"unterminated string at line {line}")
                j += 1
            if j >= n:
                raise SyntaxError(f"unterminated string at line {line}")
            raw = src[i + 1:j]
            # If the literal contains escape sequences, decode them; otherwise
            # pass through verbatim so multi-byte UTF-8 chars (α, ψ, ₁, …)
            # survive intact. ``unicode_escape`` internally treats input as
            # Latin-1, so naively encoding to UTF-8 first mangles non-ASCII.
            if "\\" in raw:
                literal = (
                    raw.encode("utf-8")
                       .decode("unicode_escape")
                       .encode("latin-1")
                       .decode("utf-8")
                )
            else:
                literal = raw
            toks.append(Tok("STRING", literal, line))
            i = j + 1
            continue
        if c.isdigit() or (c == "." and i + 1 < n and src[i + 1].isdigit()):
            j = i
            while j < n and (src[j].isdigit() or src[j] in ".eE+-"):
                if src[j] in "+-" and j > i and src[j - 1] not in "eE":
                    break
                j += 1
            text = src[i:j]
            num: float | int = int(text) if text.lstrip("+-").isdigit() else float(text)
            toks.append(Tok("NUMBER", num, line))
            i = j
            continue
        if c.isalpha() or c == "_":
            j = i
            while j < n and (src[j].isalnum() or src[j] == "_"):
                j += 1
            word = src[i:j]
            if word in _KEYWORDS:
                toks.append(Tok(word.upper(), word, line))
            else:
                toks.append(Tok("IDENT", word, line))
            i = j
            continue
        # Two-char operators
        two = src[i:i + 2]
        if two in {"<=", ">=", "==", "!=", "->"}:
            toks.append(Tok("OP", two, line))
            i += 2
            continue
        if c in "=+-*/(),:<>{}":
            toks.append(Tok("OP", c, line))
            i += 1
            continue
        raise SyntaxError(f"unexpected character {c!r} at line {line}")
    toks.append(Tok("EOF", None, line))
    return toks


# ──────────────────────────────────────────────────────────────────────────────
# AST
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class Num:
    value: float


@dataclass
class Var:
    name: str


@dataclass
class TopE:
    pass


@dataclass
class BotE:
    pass


@dataclass
class Norm:
    expr: Any


@dataclass
class WithTrust:
    """``with_trust(cell, t)``: return a copy of ``cell`` with trust rebound to ``t``."""

    expr: Any
    trust_expr: Any


@dataclass
class Phi:
    k: int
    args: list[Any]
    kwargs: dict[str, Any]


@dataclass
class BinOp:
    op: str
    left: Any
    right: Any


@dataclass
class TypeRef:
    """Refinement: trust ⋈ threshold, where ⋈ ∈ {>=, <=, >, <, ==}."""

    op: str
    threshold: float

    def check(self, trust: float) -> bool:
        ops = {
            ">=": trust >= self.threshold - 1e-12,
            "<=": trust <= self.threshold + 1e-12,
            ">":  trust >  self.threshold,
            "<":  trust <  self.threshold,
            "==": abs(trust - self.threshold) < 1e-9,
        }
        return ops[self.op]


@dataclass
class Let:
    name: str
    expr: Any
    refinement: TypeRef | None = None


@dataclass
class TrustDef:
    name: str
    expr: Any


@dataclass
class FnDef:
    name: str
    params: list[str]
    body: list[Any]
    refinement: TypeRef | None = None


@dataclass
class Call:
    name: str
    args: list[Any]
    kwargs: dict[str, Any]


@dataclass
class When:
    cond: Any
    body: list[Any]


@dataclass
class Echo:
    expr: Any
    target: str


@dataclass
class Yield:
    expr: Any


@dataclass
class Print:
    expr: Any


@dataclass
class Import:
    path: str


@dataclass
class ExprStmt:
    """A bare expression — useful in the REPL and for ad-hoc inspection."""

    expr: Any


@dataclass
class ArenaOpen:
    path: str
    agent: str | None = None


@dataclass
class Save:
    expr: Any
    name: str
    quorum_k: int | None = None
    quorum_n: int | None = None


@dataclass
class LoadE:
    name: str
    load_agent: str | None = None
    quorum: bool = False


@dataclass
class GossipOpen:
    """Open or create the shared gossip spool directory."""

    path: str


@dataclass
class Broadcast:
    """Emit one ArenaFrame into the active spool."""

    expr: Any
    name: str


@dataclass
class SyncStmt:
    """Read all unseen frames from the spool and merge them into __q__/slot."""

    pass


# ──────────────────────────────────────────────────────────────────────────────
# Parser
# ──────────────────────────────────────────────────────────────────────────────
class Parser:
    def __init__(self, toks: list[Tok]) -> None:
        self.toks = toks
        self.i = 0

    def peek(self, off: int = 0) -> Tok:
        return self.toks[self.i + off]

    def eat(self, kind: str, value: Any = None) -> Tok:
        t = self.peek()
        if t.kind != kind or (value is not None and t.value != value):
            raise SyntaxError(
                f"line {t.line}: expected {kind}{'=' + str(value) if value else ''},"
                f" got {t.kind}={t.value!r}"
            )
        self.i += 1
        return t

    def skip_nl(self) -> None:
        while self.peek().kind == "NL":
            self.i += 1

    def parse(self) -> list[Any]:
        stmts: list[Any] = []
        self.skip_nl()
        while self.peek().kind != "EOF":
            stmts.append(self.stmt())
            self.skip_nl()
        return stmts

    def stmt(self) -> Any:
        t = self.peek()
        if t.kind == "LET":
            return self.let_stmt()
        if t.kind == "TRUST":
            return self.trust_stmt()
        if t.kind == "WHEN":
            return self.when_stmt()
        if t.kind == "ECHO":
            return self.echo_stmt()
        if t.kind == "YIELD":
            self.i += 1
            return Yield(self.expr())
        if t.kind == "PRINT":
            self.i += 1
            return Print(self.expr())
        if t.kind == "FN":
            return self.fn_stmt()
        if t.kind == "IMPORT":
            self.i += 1
            path_tok = self.eat("STRING")
            return Import(path_tok.value)
        if t.kind == "ARENA":
            self.i += 1
            path = self.eat("STRING").value
            agent: str | None = None
            if self.peek().kind == "AGENT":
                self.i += 1
                agent = self.eat("STRING").value
            return ArenaOpen(path, agent)
        if t.kind == "SAVE":
            self.i += 1
            e = self.expr()
            self.eat("AS")
            name = self.eat("STRING").value
            qk, qn = None, None
            if self.peek().kind == "QUORUM":
                self.i += 1
                qk = int(self.eat("NUMBER").value)
                self.eat("OF")
                qn = int(self.eat("NUMBER").value)
            return Save(e, name, quorum_k=qk, quorum_n=qn)
        if t.kind == "GOSSIP":
            self.i += 1
            return GossipOpen(self.eat("STRING").value)
        if t.kind == "BROADCAST":
            self.i += 1
            e = self.expr()
            self.eat("AS")
            name = self.eat("STRING").value
            return Broadcast(e, name)
        if t.kind == "SYNC":
            self.i += 1
            return SyncStmt()
        # Fall through: bare expression statement (allowed at top level, useful in the REPL).
        return ExprStmt(self.expr())

    def let_stmt(self) -> Let:
        self.eat("LET")
        name = self.eat("IDENT").value
        ref: TypeRef | None = None
        if self.peek().kind == "OP" and self.peek().value == ":":
            self.i += 1
            ref = self.type_ref()
        self.eat("OP", "=")
        return Let(name, self.expr(), refinement=ref)

    def type_ref(self) -> TypeRef:
        # Accept an optional base name (psi / ψ / IDENT) for readability; ignore it.
        if self.peek().kind in {"PSI", "IDENT"}:
            self.i += 1
        if self.peek().kind == "OP" and self.peek().value == "{":
            self.i += 1
            self.eat("TRUST")
            op_tok = self.peek()
            if op_tok.kind != "OP" or op_tok.value not in {">=", "<=", ">", "<", "=="}:
                raise SyntaxError(f"line {op_tok.line}: refinement op expected, got {op_tok.value!r}")
            self.i += 1
            thresh = float(self.eat("NUMBER").value)
            self.eat("OP", "}")
            return TypeRef(op_tok.value, thresh)
        return TypeRef(">=", 0.0)

    def fn_stmt(self) -> FnDef:
        self.eat("FN")
        name = self.eat("IDENT").value
        self.eat("OP", "(")
        params: list[str] = []
        if not (self.peek().kind == "OP" and self.peek().value == ")"):
            params.append(self.eat("IDENT").value)
            while self.peek().kind == "OP" and self.peek().value == ",":
                self.i += 1
                params.append(self.eat("IDENT").value)
        self.eat("OP", ")")
        ref: TypeRef | None = None
        if self.peek().kind == "OP" and self.peek().value == ":":
            # Could be either ": <type>" return refinement or just ":" body separator.
            # If the next token after ':' is '{' or 'psi' or 'IDENT' followed by '{',
            # treat as return-refinement.
            save = self.i
            self.i += 1
            if (
                self.peek().kind == "OP" and self.peek().value == "{"
            ) or (
                self.peek().kind in {"PSI", "IDENT"}
                and self.peek(1).kind == "OP"
                and self.peek(1).value == "{"
            ):
                ref = self.type_ref()
                self.eat("OP", ":")
            else:
                self.i = save
                self.eat("OP", ":")
        else:
            self.eat("OP", ":")
        self.skip_nl()
        body: list[Any] = []
        while self.peek().kind != "END":
            body.append(self.stmt())
            self.skip_nl()
        self.eat("END")
        return FnDef(name, params, body, refinement=ref)

    def trust_stmt(self) -> TrustDef:
        self.eat("TRUST")
        name = self.eat("IDENT").value
        self.eat("OP", "=")
        return TrustDef(name, self.expr())

    def when_stmt(self) -> When:
        self.eat("WHEN")
        cond = self.expr()
        self.eat("OP", ":")
        self.skip_nl()
        body: list[Any] = []
        while self.peek().kind != "END":
            body.append(self.stmt())
            self.skip_nl()
        self.eat("END")
        return When(cond, body)

    def echo_stmt(self) -> Echo:
        self.eat("ECHO")
        e = self.expr()
        self.eat("OP", "->")
        target = self.eat("IDENT").value
        return Echo(e, target)

    # expr := term (('meet'|'join'|'<='|'>='|'<'|'>'|'+'|'-') term)*
    def expr(self) -> Any:
        left = self.term()
        while True:
            t = self.peek()
            if t.kind == "MEET" or t.kind == "JOIN":
                op = t.kind.lower()
                self.i += 1
                left = BinOp(op, left, self.term())
            elif t.kind == "OP" and t.value in {"<=", ">=", "<", ">", "+", "-"}:
                op = t.value
                self.i += 1
                left = BinOp(op, left, self.term())
            else:
                return left

    def term(self) -> Any:
        left = self.factor()
        while True:
            t = self.peek()
            if t.kind == "OP" and t.value in {"*", "/"}:
                op = t.value
                self.i += 1
                left = BinOp(op, left, self.factor())
            else:
                return left

    def factor(self) -> Any:
        t = self.peek()
        if t.kind == "NUMBER":
            self.i += 1
            return Num(t.value)
        if t.kind == "TOP":
            self.i += 1
            return TopE()
        if t.kind == "BOT":
            self.i += 1
            return BotE()
        if t.kind == "PHI":
            return self.phi_call()
        if t.kind == "NORM":
            self.i += 1
            self.eat("OP", "(")
            e = self.expr()
            self.eat("OP", ")")
            return Norm(e)
        if t.kind == "WITH_TRUST":
            self.i += 1
            self.eat("OP", "(")
            e = self.expr()
            self.eat("OP", ",")
            t_expr = self.expr()
            self.eat("OP", ")")
            return WithTrust(e, t_expr)
        if t.kind == "LOAD":
            self.i += 1
            if self.peek().kind == "QUORUM":
                self.i += 1
                return LoadE(self.eat("STRING").value, quorum=True)
            name = self.eat("STRING").value
            if self.peek().kind == "AGENT":
                self.i += 1
                return LoadE(name, load_agent=self.eat("STRING").value)
            return LoadE(name)
        if t.kind == "OP" and t.value == "(":
            self.i += 1
            e = self.expr()
            self.eat("OP", ")")
            return e
        if t.kind == "IDENT":
            self.i += 1
            # User-defined function call: ident '(' args ')'
            if self.peek().kind == "OP" and self.peek().value == "(":
                return self.user_call(t.value)
            return Var(t.value)
        raise SyntaxError(f"line {t.line}: unexpected token {t.value!r}")

    def user_call(self, name: str) -> Call:
        self.eat("OP", "(")
        args: list[Any] = []
        kwargs: dict[str, Any] = {}
        if not (self.peek().kind == "OP" and self.peek().value == ")"):
            self._call_arg(args, kwargs)
            while self.peek().kind == "OP" and self.peek().value == ",":
                self.i += 1
                self._call_arg(args, kwargs)
        self.eat("OP", ")")
        return Call(name, args, kwargs)

    def _call_arg(self, args: list[Any], kwargs: dict[str, Any]) -> None:
        if (
            self.peek().kind == "IDENT"
            and self.peek(1).kind == "OP"
            and self.peek(1).value == "="
        ):
            key = self.eat("IDENT").value
            self.eat("OP", "=")
            kwargs[key] = self.expr()
        else:
            args.append(self.expr())

    def phi_call(self) -> Phi:
        self.eat("PHI")
        self.eat("OP", "(")
        k_tok = self.eat("NUMBER")
        k = int(k_tok.value)
        args: list[Any] = []
        kwargs: dict[str, Any] = {}
        while self.peek().kind == "OP" and self.peek().value == ",":
            self.i += 1
            # kwarg? IDENT '=' expr
            if (
                self.peek().kind == "IDENT"
                and self.peek(1).kind == "OP"
                and self.peek(1).value == "="
            ):
                key = self.eat("IDENT").value
                self.eat("OP", "=")
                kwargs[key] = self.expr()
            else:
                args.append(self.expr())
        self.eat("OP", ")")
        return Phi(k, args, kwargs)


# ──────────────────────────────────────────────────────────────────────────────
# Interpreter
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class Function:
    """A user-defined morphism. The body's `yield` becomes the return value."""

    params: list[str]
    body: list[Any]
    closure: dict[str, Any]
    refinement: TypeRef | None = None


class Interpreter:
    """Evaluates a Σoilith program. State is held on a trust-coherence lattice."""

    def __init__(
        self,
        default_n: int = 16,
        module_path: Path | None = None,
        search_paths: list[Path] | None = None,
    ) -> None:
        self.env: dict[str, Any] = {}
        self.echo_stacks: dict[str, list[Cell]] = {}
        self.default_n = default_n
        self.yielded: Cell | None = None
        self.module_path = module_path
        # Default search paths: this file's dir + the canonical ``stdlib`` next to it.
        here = Path(__file__).parent
        self.search_paths: list[Path] = list(search_paths or []) + [here, here / "stdlib"]
        self._imported: set[Path] = set()
        self._last_value: Any | None = None  # mirrors REPL `_`
        self.arena = None  # type: ignore[assignment]  # set by `arena "path"`
        self.arena_agent: str | None = None  # Zone 111: active agent namespace αᵢ
        # (arena path string, logical slot) → { agent_id → proposed Cell } — in-process only
        self._quorum_votes: dict[tuple[str, str], dict[str, Cell]] = {}
        # Zone 112: gossip spool + per-host Lamport clock for ordering frames
        self.spool = None  # type: ignore[assignment]
        self._gossip_clock: int = 0

    # ── helpers ──────────────────────────────────────────────────────────────
    @staticmethod
    def _as_cell(value: Any, trust: float = 1.0) -> Cell:
        if isinstance(value, Cell):
            return value
        # Duck-typed Cell: handles the `__main__` vs `soilith_lang` class-identity
        # quirk that crops up when modules import Cell while __main__ owns its
        # own copy (e.g. cells returned by soilith_arena / soilith_distributed).
        if (
            type(value).__name__ == "Cell"
            and hasattr(value, "value")
            and hasattr(value, "trust")
            and hasattr(value, "phase")
        ):
            return Cell(
                np.asarray(value.value, dtype=float),
                trust=float(value.trust),
                phase=float(value.phase),
            )
        if isinstance(value, (int, float, np.floating)):
            return Cell(np.array([float(value)]), trust=trust)
        if isinstance(value, np.ndarray):
            return Cell(value, trust=trust)
        if isinstance(value, tuple):
            # phi can return tuples (e.g. φ₂ → (ψ⁻, ψ⁺), φ₂₆ → (dθ/dt, tense));
            # fold to a 1-D ψ-vector by concatenating ravelled parts so shapes
            # with differing widths still align on the lattice.
            arr = np.concatenate([np.asarray(x, dtype=float).ravel() for x in value])
            return Cell(arr, trust=trust)
        raise TypeError(f"cannot lift {type(value).__name__} to Cell")

    def _scalar(self, v: Any) -> float:
        if isinstance(v, Cell):
            return v.coherence()
        return float(v)

    # ── eval ─────────────────────────────────────────────────────────────────
    def eval(self, node: Any) -> Any:
        m = getattr(self, f"e_{type(node).__name__}", None)
        if m is None:
            raise RuntimeError(f"no evaluator for {type(node).__name__}")
        return m(node)

    def e_Num(self, n: Num) -> float:
        return n.value

    def e_Var(self, v: Var) -> Any:
        if v.name not in self.env:
            raise NameError(f"unbound name {v.name!r}")
        return self.env[v.name]

    def e_TopE(self, _: TopE) -> Cell:
        return TOP(self.default_n)

    def e_BotE(self, _: BotE) -> Cell:
        return BOT(self.default_n)

    def e_Norm(self, n: Norm) -> float:
        c = self._as_cell(self.eval(n.expr))
        return float(np.linalg.norm(c.value))

    def e_WithTrust(self, n: WithTrust) -> Cell:
        c = self._as_cell(self.eval(n.expr))
        t = self._scalar(self.eval(n.trust_expr))
        # Clamp to [0, 1] silently — Cell.__post_init__ does the same.
        return Cell(value=c.value.copy(), trust=float(t), phase=c.phase)

    def e_Phi(self, p: Phi) -> Cell:
        if p.k not in sp.PHI:
            raise RuntimeError(f"phi({p.k}) not in instruction set 0..60")
        fn = sp.PHI[p.k]
        args = [self._unwrap(self.eval(a)) for a in p.args]
        kwargs = {k: self._unwrap(self.eval(v)) for k, v in p.kwargs.items()}
        # Sensible default first argument for nullary morphisms (φ₀).
        if p.k == 0 and not args and "n" not in kwargs:
            kwargs["n"] = self.default_n
        out = fn(*args, **kwargs)
        return self._as_cell(out, trust=self._depth_trust(p.k))

    @staticmethod
    def _depth_trust(k: int) -> float:
        # Gentle trust decay with morphism depth (still > 0.5 at k = 50).
        return float(max(0.55, 1.0 - 0.01 * k))

    @staticmethod
    def _unwrap(v: Any) -> Any:
        return v.value if isinstance(v, Cell) else v

    def e_BinOp(self, b: BinOp) -> Any:
        if b.op == "meet":
            return self._as_cell(self.eval(b.left)).meet(self._as_cell(self.eval(b.right)))
        if b.op == "join":
            return self._as_cell(self.eval(b.left)).join(self._as_cell(self.eval(b.right)))
        if b.op == "<=":
            return self._scalar(self.eval(b.left)) <= self._scalar(self.eval(b.right))
        if b.op == ">=":
            return self._scalar(self.eval(b.left)) >= self._scalar(self.eval(b.right))
        if b.op == "<":
            return self._scalar(self.eval(b.left)) < self._scalar(self.eval(b.right))
        if b.op == ">":
            return self._scalar(self.eval(b.left)) > self._scalar(self.eval(b.right))
        L, R = self.eval(b.left), self.eval(b.right)
        if b.op == "+":
            return self._as_cell(L) + self._as_cell(R)
        if b.op == "-":
            return self._as_cell(L) - self._as_cell(R)
        if b.op == "*":
            if isinstance(L, (int, float)) and isinstance(R, (int, float)):
                return float(L) * float(R)
            return self._as_cell(L) * (R if isinstance(R, (int, float)) else self._as_cell(R))
        if b.op == "/":
            if isinstance(L, (int, float)) and isinstance(R, (int, float)):
                return float(L) / float(R)
            return self._as_cell(L) / (R if isinstance(R, (int, float)) else self._as_cell(R))
        raise RuntimeError(f"unknown op {b.op}")

    # ── statements ───────────────────────────────────────────────────────────
    def e_Let(self, n: Let) -> None:
        v = self.eval(n.expr)
        if n.refinement is not None:
            cell = self._as_cell(v)
            if not n.refinement.check(cell.trust):
                raise TrustError(
                    f"refinement violated for {n.name!r}: "
                    f"trust={cell.trust:.3f} ⋫ ({n.refinement.op} {n.refinement.threshold})"
                )
            v = cell
        self.env[n.name] = v

    def e_TrustDef(self, n: TrustDef) -> None:
        self.env[n.name] = float(self._scalar(self.eval(n.expr)))

    def e_FnDef(self, n: FnDef) -> None:
        self.env[n.name] = Function(
            params=n.params,
            body=n.body,
            closure=self.env,
            refinement=n.refinement,
        )

    def e_Call(self, n: Call) -> Any:
        fn = self.env.get(n.name)
        if not isinstance(fn, Function):
            raise NameError(f"{n.name!r} is not a function")
        if len(n.args) != len(fn.params):
            raise TypeError(
                f"{n.name}() expects {len(fn.params)} positional args, got {len(n.args)}"
            )
        new_env: dict[str, Any] = dict(fn.closure)
        for p, a in zip(fn.params, n.args):
            new_env[p] = self.eval(a)
        for k, e in n.kwargs.items():
            new_env[k] = self.eval(e)
        saved_env, saved_yield = self.env, self.yielded
        self.env, self.yielded = new_env, None
        try:
            for stmt in fn.body:
                self.eval(stmt)
            result = self.yielded if self.yielded is not None else BOT(self.default_n)
        finally:
            self.env, self.yielded = saved_env, saved_yield
        if fn.refinement is not None and not fn.refinement.check(result.trust):
            raise TrustError(
                f"return refinement violated for {n.name}(): "
                f"trust={result.trust:.3f} ⋫ ({fn.refinement.op} {fn.refinement.threshold})"
            )
        return result

    def e_When(self, n: When) -> None:
        if bool(self.eval(n.cond)):
            for s in n.body:
                self.eval(s)

    def e_Echo(self, n: Echo) -> None:
        cell = self._as_cell(self.eval(n.expr))
        self.echo_stacks.setdefault(n.target, []).append(cell)
        # Also expose the most-recent echo via the target name.
        self.env[n.target] = cell

    def e_Yield(self, n: Yield) -> None:
        self.yielded = self._as_cell(self.eval(n.expr))

    def e_Print(self, n: Print) -> None:
        v = self.eval(n.expr)
        print(v if not isinstance(v, np.ndarray) else f"array(shape={v.shape})")

    def e_ExprStmt(self, n: ExprStmt) -> Any:
        v = self.eval(n.expr)
        self._last_value = v
        self.env["_"] = v  # mirror Python REPL: `_` is the last value
        return v

    # ── persistent ψ-arena (Zones 110–111) ───────────────────────────────────
    def e_ArenaOpen(self, n: ArenaOpen) -> None:
        from soilith_arena import Arena
        target = Path(n.path)
        if not target.is_absolute():
            base = self.module_path.parent if self.module_path else Path.cwd()
            target = (base / target).resolve()
        self.arena = Arena.open(target)
        self.arena_agent = n.agent

    def _arena_disk_key(
        self,
        logical: str,
        *,
        explicit_agent: str | None = None,
        quorum_commit: bool = False,
    ) -> str:
        if quorum_commit:
            return f"__q__/{logical}"
        ag = explicit_agent if explicit_agent is not None else self.arena_agent
        if ag:
            return f"{ag}/{logical}"
        return logical

    def _arena_save_cell(
        self,
        logical: str,
        cell: Cell,
        quorum: tuple[int, int] | None = None,
    ) -> None:
        """Write ``cell`` under ``logical``; optional ``quorum`` = (k, n) for k-of-n commit."""
        if self.arena is None:
            raise RuntimeError("save: no arena is open. use `arena \"path\"` first.")
        ap = str(self.arena.path.resolve())

        if quorum is None:
            self.arena[self._arena_disk_key(logical)] = cell
            return

        k, n = quorum
        if not self.arena_agent:
            raise RuntimeError(
                'quorum save requires an active agent — use: arena "path" agent "αᵢ"'
            )
        if k <= 0 or n <= 0 or k > n:
            raise QuorumError(f"quorum k-of-n invalid: need 0 < k <= n, got k={k}, n={n}")

        qkey = (ap, logical)
        votes = self._quorum_votes.setdefault(qkey, {})
        assert self.arena_agent is not None
        votes[self.arena_agent] = cell
        if len(votes) > n:
            raise QuorumError(
                f"quorum roster overflow on {logical!r}: {len(votes)} distinct agents > n={n}"
            )
        if len(votes) >= k:
            merged = self._meet_fold(list(votes.values()))
            self.arena[self._arena_disk_key(logical, quorum_commit=True)] = merged
            votes.clear()

    def e_Save(self, n: Save) -> None:
        cell = self._as_cell(self.eval(n.expr))
        q = (n.quorum_k, n.quorum_n) if n.quorum_k is not None else None
        self._arena_save_cell(n.name, cell, q)

    @staticmethod
    def _meet_fold(cells: list[Cell]) -> Cell:
        c = cells[0]
        for x in cells[1:]:
            c = c.meet(x)
        return c

    def e_LoadE(self, n: LoadE) -> Cell:
        if self.arena is None:
            raise RuntimeError("load: no arena is open. use `arena \"path\"` first.")
        key = self._arena_disk_key(
            n.name,
            explicit_agent=n.load_agent,
            quorum_commit=n.quorum,
        )
        return self.arena[key]

    # ── Zone 112: gossip / broadcast / sync ─────────────────────────────────
    def _ensure_spool(self) -> Any:
        if self.spool is None:
            raise RuntimeError(
                'no gossip spool is open. use `gossip "path/to/spool"` first.'
            )
        return self.spool

    def e_GossipOpen(self, n: GossipOpen) -> None:
        from soilith_distributed import Spool  # local import → optional dep

        self.spool = Spool(Path(n.path).expanduser().resolve())

    def e_Broadcast(self, n: Broadcast) -> None:
        from soilith_distributed import ArenaFrame  # local import

        spool = self._ensure_spool()
        if not self.arena_agent:
            raise RuntimeError(
                'broadcast requires an active agent — open arena with `agent "αᵢ"` first.'
            )
        cell = self._as_cell(self.eval(n.expr))
        self._gossip_clock += 1
        frame = ArenaFrame(
            agent=self.arena_agent,
            slot=n.name,
            cell=cell,
            clock=self._gossip_clock,
        )
        spool.emit(frame)

    def e_SyncStmt(self, _n: SyncStmt) -> None:
        from soilith_distributed import sync_into_arena  # local import

        spool = self._ensure_spool()
        if self.arena is None:
            raise RuntimeError(
                "sync: no arena is open. open one with `arena \"path\"` first."
            )
        host_tag = self.arena_agent or "anon"

        def _set(key: str, cell: Cell) -> None:
            assert self.arena is not None
            self.arena[key] = cell

        def _qkey(slot: str, quorum: bool) -> str:
            return self._arena_disk_key(slot, quorum_commit=quorum)

        sync_into_arena(spool, host_tag, _set, _qkey)

    def e_Import(self, n: Import) -> None:
        resolved = self._resolve_import(n.path)
        if resolved in self._imported:
            return
        self._imported.add(resolved)
        sub = Interpreter(
            default_n=self.default_n,
            module_path=resolved,
            search_paths=self.search_paths,
        )
        sub._imported = self._imported  # share visited set to break cycles
        sub.run(resolved.read_text(encoding="utf-8"))
        # Merge module bindings into the caller (later definitions shadow on conflict;
        # the imported module's `_` last-value slot is intentionally excluded).
        for k, v in sub.env.items():
            if k == "_":
                continue
            self.env[k] = v

    def _resolve_import(self, path: str) -> Path:
        candidate = Path(path)
        bases: list[Path] = []
        if self.module_path is not None:
            bases.append(self.module_path.parent)
        bases.extend(self.search_paths)
        if candidate.is_absolute() and candidate.exists():
            return candidate.resolve()
        for base in bases:
            p = (base / candidate).resolve()
            if p.exists():
                return p
        raise FileNotFoundError(
            f"import {path!r}: not found in {[str(b) for b in bases]}"
        )

    def run(self, src: str) -> Cell | None:
        for stmt in Parser(lex(src)).parse():
            self.eval(stmt)
        return self.yielded

    def run_stmts(self, stmts: list[Any]) -> Cell | None:
        """Evaluate an already-parsed AST. Used by the Zone 119 rewriter
        pass so callers can transform the AST before execution."""
        for stmt in stmts:
            self.eval(stmt)
        return self.yielded


# ──────────────────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────────────────
_DEMO = """\
# Σoilith demo: identity burst on a trust-coherence lattice.

trust tau = 0.5

let psi0   = phi(0, n=16)
let psi1   = phi(1, psi0)
let burst  = phi(4, psi1, n=5)
let prime  = phi(5, burst)

# Lattice meet/join — operate on the trust-coherence lattice directly.
let lower  = psi1 meet prime
let upper  = psi1 join top

when norm(psi1) >= tau:
    echo psi1  -> spine
    echo prime -> spine
end

yield upper
print upper
print lower
"""


_BLOCK_OPENERS = {"WHEN", "FN"}  # statements whose body ends with `end`


def _block_depth_delta(line: str) -> int:
    """How many open `end`-terminated blocks this line opens (positive) or closes (negative)."""
    try:
        toks = lex(line)
    except SyntaxError:
        return 0
    delta = 0
    for t in toks:
        if t.kind in _BLOCK_OPENERS:
            delta += 1
        elif t.kind == "END":
            delta -= 1
    return delta


_REPL_BANNER = """\
Σoilith ψ-shell — lattice-based memory programming language
  type a statement or expression and press Enter.
  multi-line blocks (when/fn) continue until you write `end`.
  meta: :help  :env  :reset  :imports  :quit
"""

_REPL_HELP = """\
Σoilith ψ-shell quick reference:

  let x = phi(0, n=16)             # bind a cell on the lattice
  let y : ψ{trust >= 0.9} = top    # refinement-typed binding
  fn f(a):                         # user morphism (multi-line)
      yield phi(1, a)
  end
  a meet b   /   a join b          # lattice operations
  norm(x)                          # ‖value‖ as a scalar
  with_trust(x, 0.7)               # copy x with trust rebound to 0.7
  echo x -> spine                  # append to echo-stack `spine`
  import "stdlib/spiral.sol"       # load other Σoilith modules
  arena "mem.arena" agent "α₁"     # persistent store + active agent namespace
  save x as "spine"                # writes key α₁/spine on disk
  save x as "vote" quorum 2 of 3   # k-of-n commit → __q__/vote (meet of votes)
  load "spine"                     # load from active agent namespace
  load "spine" agent "α₂"          # read another agent's namespace
  load quorum "vote"               # load committed quorum cell
  gossip "spool/"                  # open shared spool for cross-host gossip
  broadcast x as "vote"            # emit an ArenaFrame for slot "vote"
  sync                             # merge all unseen frames → __q__/slot
  print x      yield x             # observe / publish

  meta-commands:
    :help     show this help
    :env      list bindings in scope
    :imports  list modules already loaded
    :reset    clear the interpreter state
    :quit     exit (Ctrl-D / Ctrl-Z also work)
"""


def repl(default_n: int = 16) -> int:
    interp = Interpreter(default_n=default_n)
    print(_REPL_BANNER, end="")
    buf: list[str] = []
    depth = 0
    while True:
        prompt = "ψ> " if not buf else " · "
        try:
            line = input(prompt)
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        stripped = line.strip()
        # Meta commands only when we're not inside a block.
        if not buf and stripped.startswith(":"):
            cmd = stripped[1:].split()[0] if stripped[1:] else ""
            if cmd in {"quit", "q", "exit"}:
                return 0
            if cmd in {"help", "h", "?"}:
                print(_REPL_HELP)
            elif cmd == "env":
                if not interp.env:
                    print("  (empty)")
                for k, v in interp.env.items():
                    print(f"  {k} = {v}")
            elif cmd == "imports":
                if not interp._imported:
                    print("  (none)")
                for p in interp._imported:
                    print(f"  {p}")
            elif cmd == "reset":
                interp = Interpreter(default_n=default_n)
                print("  state cleared.")
            else:
                print(f"  unknown command :{cmd}  (try :help)")
            continue
        buf.append(line)
        depth += _block_depth_delta(line)
        if depth > 0:
            continue  # still inside a multi-line block
        src = "\n".join(buf)
        buf.clear()
        depth = 0
        if not src.strip():
            continue
        try:
            for stmt in Parser(lex(src)).parse():
                val = interp.eval(stmt)
                if isinstance(stmt, ExprStmt) and val is not None:
                    print(val)
        except (SyntaxError, NameError, TypeError, TrustError, QuorumError, RuntimeError,
                FileNotFoundError) as e:
            print(f"  ! {type(e).__name__}: {e}")


def main(argv: list[str]) -> int:
    if "--repl" in argv:
        return repl()
    if "--compile" in argv:
        # Delegate to the bytecode module's `--compile <path>` semantics.
        from soilith_bytecode import main as bc_main
        return bc_main(argv)
    use_bc = "--bc" in argv
    if use_bc:
        argv = [a for a in argv if a != "--bc"]

    # Zone 119: optional self-rewrite pass driven by the lawbook arena.
    rewrite_arena: Path | None = None
    rewrite_threshold: float = 0.999
    if "--rewrite" in argv:
        i = argv.index("--rewrite")
        rewrite_arena = Path(argv[i + 1]).resolve()
        del argv[i:i + 2]
    if "--rewrite-threshold" in argv:
        i = argv.index("--rewrite-threshold")
        rewrite_threshold = float(argv[i + 1])
        del argv[i:i + 2]

    if "--demo" in argv:
        src, path = _DEMO, None
    elif len(argv) >= 2:
        path = Path(argv[1]).resolve()
        src = path.read_text(encoding="utf-8")
    else:
        print(__doc__)
        return 0

    if rewrite_arena is not None:
        from soilith_rewrite import RewriteTable, rewrite_source
        table = RewriteTable.from_arena(rewrite_arena, rewrite_threshold)
        stmts, stats = rewrite_source(src, table)
        if stats.total > 0:
            print(f"# rewriter: {stats.total} pattern(s) fired from {rewrite_arena.name}")
        if use_bc:
            from soilith_bytecode import Compiler, VM
            host = Interpreter(module_path=path) if path else Interpreter()
            VM(Compiler.compile_stmts(stmts), host).run()
            out = host.yielded
        else:
            host = Interpreter(module_path=path) if path else Interpreter()
            out = host.run_stmts(stmts)
    elif use_bc:
        from soilith_bytecode import Compiler, VM
        if path is None:
            host = Interpreter()
            VM(Compiler.compile_source(_DEMO), host).run()
            out = host.yielded
        else:
            from soilith_bytecode import run_file_cached
            out = run_file_cached(path)
    else:
        host = Interpreter(module_path=path) if path else Interpreter()
        out = host.run(src)
    if out is not None:
        print(f"\nyield → {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
