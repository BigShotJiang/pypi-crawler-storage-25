"""
soilith_coherent.py — transactional scale-coherent memory
(Zone 128, part 2).

Zone 122 gave Σoilith a memory whose audit can detect ``χ`` drift.
Zone 123 gave her a multi-scale view that enforces ``d² = 0`` across
vertex / edge / face cochains. Zone 128 makes those checks
*transactional*: a sequence of writes is either committed atomically
*after* every scale-level check passes, or rolled back as a whole.

This is the runtime expression of the user's thesis:

    "enforce consistency across scales as a semantic property of memory"

API
---
A ``ScaleCoherent(memory)`` wraps any object exposing ``snapshot()``
and ``restore(snapshot)``. The two supported memory types are
``soilith_memory.ScaleAwareMemory`` and
``soilith_pair_memory.PairGroupMemory`` but any duck-typed analogue
works.

    sc = ScaleCoherent(memory)
    with sc.transaction(require_chi_match=True, require_d2_zero=True):
        memory.write(addr_a, cell_a)
        memory.write(addr_b, cell_b)
        # … on context exit, audit + d²=0 run. If either fails,
        # the store is restored and a CoherentRollback is raised.

Adoption gates in ``stdlib/coherent.sol`` accept the resulting
``CommitReport`` only when every requested scale-level check passed.
"""

from __future__ import annotations

import contextlib
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any, Callable, Iterator

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Exceptions
# ──────────────────────────────────────────────────────────────────────────
class CoherentError(Exception):
    """Base class for Zone 128 transactional errors."""


class CoherentRollback(CoherentError):
    """A commit failed and the memory was restored to its pre-transaction
    snapshot."""


# ──────────────────────────────────────────────────────────────────────────
#  Commit report
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class CommitReport:
    transaction_id: int
    writes: int
    rolled_back: bool
    audit_summary: dict[str, Any] | None = None
    closed_form_residual: float | None = None
    notes: list[str] = field(default_factory=list)

    def describe(self) -> str:
        lines = [
            f"CommitReport(txn={self.transaction_id})",
            f"  writes        = {self.writes}",
            f"  rolled_back   = {self.rolled_back}",
        ]
        if self.audit_summary is not None:
            a = self.audit_summary.get("attested", {})
            m = self.audit_summary.get("measured", {})
            lines.append(
                f"  attested χ₁   = {a.get('chi_1', '?')}"
            )
            lines.append(
                f"  measured χ₁   = {m.get('chi_1', '?')}"
            )
            lines.append(
                f"  chi_match     = {self.audit_summary.get('chi_match', '?')}"
            )
            lines.append(
                f"  coverage      = {self.audit_summary.get('coverage', 0):.2%}"
            )
        if self.closed_form_residual is not None:
            lines.append(
                f"  d² residual  = {self.closed_form_residual:.2e}"
            )
        for n in self.notes:
            lines.append(f"  · {n}")
        return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────
#  Wrapper
# ──────────────────────────────────────────────────────────────────────────
class ScaleCoherent:
    """Transactional scale-coherent wrapper around a duck-typed memory."""

    def __init__(self, memory: Any) -> None:
        if not hasattr(memory, "snapshot") or not hasattr(memory, "restore"):
            raise TypeError(
                "memory must expose snapshot() and restore(snap); "
                "ScaleAwareMemory and PairGroupMemory both do"
            )
        if not hasattr(memory, "audit"):
            raise TypeError("memory must expose audit(*, strict=True)")
        self.memory = memory
        self._txn_count = 0
        self._last_commit: CommitReport | None = None
        self._writes_during_txn = 0
        self._in_txn = False

    @property
    def last_commit(self) -> CommitReport | None:
        return self._last_commit

    @contextlib.contextmanager
    def transaction(
        self,
        *,
        require_chi_match: bool = True,
        require_d2_zero: bool = False,
        d2_quantity: str = "sum",
    ) -> Iterator["ScaleCoherent"]:
        """Open a transaction. On exit, run requested scale-level
        checks; on failure, restore the snapshot and raise
        ``CoherentRollback``."""
        if self._in_txn:
            raise CoherentError("transactions are not reentrant")
        self._in_txn = True
        self._writes_during_txn = 0
        self._txn_count += 1
        txn_id = self._txn_count
        snap = self.memory.snapshot()
        original_write = getattr(self.memory, "write", None)
        if original_write is None:
            self._in_txn = False
            raise TypeError("memory must expose a write() method")

        def counted_write(*args, **kwargs):
            self._writes_during_txn += 1
            return original_write(*args, **kwargs)

        self.memory.write = counted_write  # type: ignore[assignment]
        body_exc: BaseException | None = None
        try:
            yield self
        except BaseException as exc:
            body_exc = exc
        finally:
            self.memory.write = original_write  # restore
            self._in_txn = False

        notes: list[str] = []
        rolled_back = False
        audit_summary: dict[str, Any] | None = None
        d2_residual: float | None = None

        if body_exc is not None:
            self.memory.restore(snap)
            rolled_back = True
            notes.append(f"body raised {type(body_exc).__name__}: {body_exc}")
            self._last_commit = CommitReport(
                transaction_id=txn_id,
                writes=self._writes_during_txn,
                rolled_back=True,
                audit_summary=None,
                closed_form_residual=None,
                notes=notes,
            )
            raise CoherentRollback(
                f"transaction {txn_id} rolled back; original exception: "
                f"{type(body_exc).__name__}: {body_exc}"
            ) from body_exc

        # Run audit.
        try:
            report = self.memory.audit(strict=False)
            audit_summary = report.as_dict() if hasattr(report, "as_dict") else None
        except Exception as exc:
            self.memory.restore(snap)
            rolled_back = True
            notes.append(f"audit raised {type(exc).__name__}: {exc}")
            self._last_commit = CommitReport(
                transaction_id=txn_id,
                writes=self._writes_during_txn,
                rolled_back=True,
                audit_summary=None,
                closed_form_residual=None,
                notes=notes,
            )
            raise CoherentRollback(
                f"transaction {txn_id} rolled back during audit"
            ) from exc

        if require_chi_match and audit_summary is not None:
            if not audit_summary.get("chi_match", False):
                self.memory.restore(snap)
                rolled_back = True
                notes.append(
                    "χ drift detected after commit; transaction rolled back"
                )

        if not rolled_back and require_d2_zero:
            try:
                from soilith_multiscale import MultiScaleView
                view = MultiScaleView(self.memory)
                d2_residual = float(view.closed_form_residual(d2_quantity))
                if not np.isfinite(d2_residual) or d2_residual > 1e-6:
                    self.memory.restore(snap)
                    rolled_back = True
                    notes.append(
                        f"d²=0 violated: residual={d2_residual:.3e}"
                    )
            except Exception as exc:
                notes.append(
                    f"d²=0 check skipped: {type(exc).__name__}: {exc}"
                )

        self._last_commit = CommitReport(
            transaction_id=txn_id,
            writes=self._writes_during_txn,
            rolled_back=rolled_back,
            audit_summary=audit_summary,
            closed_form_residual=d2_residual,
            notes=notes,
        )
        if rolled_back:
            raise CoherentRollback(
                f"transaction {txn_id} rolled back ({notes[-1] if notes else 'unknown'})"
            )
