"""
soilith_bench.py — reproducible benchmark harness (Zone 150).

Honest framing
--------------
"Battle-testing" in the literature sense — thousands of person-
years on millions of LOC — is not a thing Σoilith can claim today.
What it *can* claim, and what every serious system maintains, is a
**reproducible benchmark harness** with:

* fixed seeds and inputs;
* per-zone workloads exercising the hottest code paths;
* a **baseline file** that pins each benchmark's expected outcome
  and a soft wall-clock target;
* persistence to ``bench/<name>`` cells so regressions /
  improvements are visible across catalog rebuilds.

This is not a competitive shootout against ThreadSanitizer or
Astrée — it's the foundation any such comparison would build on.

API
---
* ``Benchmark(name, fn, *, baseline_ms, expected_outcome=None)``.
* ``BenchmarkSuite`` collects benchmarks, runs them, persists.
* ``BenchmarkReport`` carries timing + pass/fail.

CLI
---
    python soilith_bench.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
import time
from typing import Any, Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Benchmark and suite
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Benchmark:
    name: str
    fn: Callable[[], Any]
    baseline_ms: float
    expected_outcome: Any = None
    description: str = ""


@dataclass
class BenchmarkReport:
    name: str
    elapsed_ms: float
    ratio_to_baseline: float
    passed: bool
    outcome: Any = None
    error: str | None = None

    def describe(self) -> str:
        ok = "✓" if self.passed else "✗"
        if self.error:
            return (
                f"BenchmarkReport {ok}  {self.name}  ERROR: {self.error}"
            )
        return (
            f"BenchmarkReport {ok}  {self.name}: "
            f"{self.elapsed_ms:7.2f}ms  "
            f"(×{self.ratio_to_baseline:.2f} of baseline)"
        )


class BenchmarkSuite:
    def __init__(self) -> None:
        self._benches: list[Benchmark] = []

    def add(self, b: Benchmark) -> None:
        self._benches.append(b)

    def run(self) -> list[BenchmarkReport]:
        out: list[BenchmarkReport] = []
        for b in self._benches:
            t0 = time.perf_counter()
            outcome: Any = None
            err: str | None = None
            try:
                outcome = b.fn()
            except Exception as e:
                err = f"{type(e).__name__}: {e}"
            t_ms = (time.perf_counter() - t0) * 1000.0
            passed = (
                err is None
                and (b.expected_outcome is None
                     or outcome == b.expected_outcome)
            )
            out.append(BenchmarkReport(
                name=b.name, elapsed_ms=t_ms,
                ratio_to_baseline=t_ms / max(b.baseline_ms, 1e-6),
                passed=passed, outcome=outcome, error=err,
            ))
        return out


# ──────────────────────────────────────────────────────────────────────────
#  Built-in benchmarks per zone
# ──────────────────────────────────────────────────────────────────────────
def build_default_suite() -> BenchmarkSuite:
    s = BenchmarkSuite()

    # Zone 139 — concurrent race check on (ℤ/2)^3, antipodal procs.
    def bench_concurrent_antipodal() -> bool:
        from soilith_concurrent import Process, race_check
        from soilith_memory import ScaleAwareMemory
        m = ScaleAwareMemory(
            k=3, attested_V=8, attested_E=12, attested_F=3,
            attested_chi_1=-4, attested_chi_2=-1,
            probe_name="z2_cubed",
        )
        for a in m.positions():
            m.write(a, Cell(value=np.zeros(2),
                            trust=1.0, phase=0.0))
        p = Process("A").write(
            "000",
            Cell(value=np.array([1.0]), trust=1.0, phase=0.0),
        )
        q = Process("B").write(
            "111",
            Cell(value=np.array([2.0]), trust=1.0, phase=0.0),
        )
        return race_check(p, q, m).race_free

    s.add(Benchmark(
        name="zone139_antipodal_race_free",
        fn=bench_concurrent_antipodal,
        baseline_ms=20.0,
        expected_outcome=True,
        description="Race-free antipodal writes on (Z/2)^3",
    ))

    # Zone 146 — synced release-acquire on D_3.
    def bench_weakmem_d3_synced() -> bool:
        from soilith_weakmem import (
            Group, WeakMemory, Sync, Permission,
        )
        G = Group.dihedral(3)
        mem = WeakMemory(G)
        sync = Sync(name="lock")
        addr = ("r", 0)
        mem.grant("A", addr, Permission.full())
        mem.write("A", addr,
                  Cell(value=np.array([1.0]),
                       trust=1.0, phase=0.0))
        mem.release("A", sync)
        mem.acquire("B", sync)
        mem._held.pop(("A", addr), None)
        mem.grant("B", addr, Permission.full())
        mem.read("B", addr, perm=Permission.full())
        return mem.audit().race_free

    s.add(Benchmark(
        name="zone146_d3_synced_race_free",
        fn=bench_weakmem_d3_synced,
        baseline_ms=10.0,
        expected_outcome=True,
        description="D_3 release-acquire synced read/write",
    ))

    # Zone 148 — interval widening convergence.
    def bench_intervals_convergence() -> bool:
        from soilith_intervals import (
            CFG, Block, Stmt, Interval, analyse,
        )
        cfg = CFG(
            entry="start",
            blocks={
                "start": Block(
                    "start",
                    [Stmt(("const", "x", 0.0))],
                    succs=["loop"],
                ),
                "loop": Block(
                    "loop",
                    [Stmt(("phi", "y", 38, "x")),
                     Stmt(("widen", "x", "y"))],
                    succs=["loop", "exit"],
                ),
                "exit": Block("exit", [], succs=[]),
            },
        )
        rep = analyse(cfg, initial={"x": Interval.of(0.0)},
                      max_iter=64, widen_after=2)
        return rep.converged

    s.add(Benchmark(
        name="zone148_widening_converges",
        fn=bench_intervals_convergence,
        baseline_ms=15.0,
        expected_outcome=True,
        description="Cousot widening converges on φ_38 loop",
    ))

    # Zone 149 — sparse audit at k=20.
    def bench_sparse_audit() -> int:
        from soilith_sparse import SparseScaleMemory
        m = SparseScaleMemory(20)
        seed = "0" * 20
        m.write(seed, Cell(value=np.array([1.0]),
                           trust=1.0, phase=0.0))
        rep = m.local_audit(seed, radius=2)
        return rep.n_vertices

    s.add(Benchmark(
        name="zone149_sparse_k20_r2",
        fn=bench_sparse_audit,
        baseline_ms=50.0,
        expected_outcome=211,
        description="Sparse k=20 local audit ball at r=2",
    ))

    # Zone 145 — abstract interpretation soundness audit.
    def bench_ai_phi38() -> int:
        from soilith_abstract import analyse_operator
        rep = analyse_operator(38, samples=16, holdout=16)
        return rep.audit_unsound

    s.add(Benchmark(
        name="zone145_phi38_ai_audit",
        fn=bench_ai_phi38,
        baseline_ms=40.0,
        expected_outcome=0,
        description="Sign-domain AI audit on φ_38",
    ))

    return s


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(report: BenchmarkReport, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        report.elapsed_ms,
        report.ratio_to_baseline,
        1.0 if report.passed else 0.0,
    ], dtype=float)
    trust = 1.0 if report.passed and report.ratio_to_baseline <= 2.0 \
        else (0.6 if report.passed else 0.0)
    safe = "".join(c if c.isalnum() else "_" for c in report.name)[:60]
    arena[f"bench/{safe}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith benchmark harness (Zone 150)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print("# Zone 150 — reproducible benchmark harness")
    suite = build_default_suite()
    reports = suite.run()
    passed = 0
    for r in reports:
        print("  " + r.describe())
        persist(r, args.arena)
        if r.passed:
            passed += 1
    print(f"\n# total {passed}/{len(reports)} passed")
    return 0 if passed == len(reports) else 1


if __name__ == "__main__":
    raise SystemExit(main())
