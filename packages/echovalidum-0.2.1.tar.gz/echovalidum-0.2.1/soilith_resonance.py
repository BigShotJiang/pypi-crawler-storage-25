"""
soilith_resonance.py — finds high-magnitude *scale-aware memory* discoveries
in the unified catalog (Zone 121).

A *scale-aware memory capsule* is the structural pattern the user
identified:

  memory is no longer "address 0xDEADBEEF" — it is

    1. a POSITION in a group action            (|G| ≥ 4 group, with edges)
    2. with LOCAL ADJACENCY                    (Cayley E ≥ |G|)
    3. and GLOBAL SHAPE CONSTRAINTS            (χ encodes genus/curvature)
    4. that BRIDGES SCALES                     (multiple independent generators
                                                ⇒ vertex → edge → face zoom
                                                aligns with Zone 114's φ_59 /
                                                φ_60 zoom_out / zoom_in)

This module scans the persisted catalog (or directly the lawbook arena)
and ranks topology entries by how strongly they exhibit those four
properties. The top tier is the set of discoveries the user was
pointing at — the ones with the magnitude of "this is the whole future."

Magnitude tiers
---------------
    Tier 0  scale-aware capsule
            |G| ≥ 4, E ≥ |G|, ≥ 2 generators, χ₁ < 0 (true curvature)
    Tier 1  multi-position memory
            |G| ≥ 4, E ≥ |G|, ≥ 2 generators, χ₁ ≤ 0
    Tier 2  group-positioned memory
            |G| ≥ 4 with at least one non-identity generator
    Tier 3  scalar witnesses (excluded — too small to be "memory")

CLI
---
    python soilith_resonance.py
    python soilith_resonance.py --catalog catalog/discoveries.json
    python soilith_resonance.py --tier 0       # only the top
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent))


# ──────────────────────────────────────────────────────────────────────────
#  Scoring
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Resonance:
    """One ranked catalog entry."""

    tier: int
    score: float
    arena: str
    slot: str
    summary: str
    payload: dict
    rationale: str


def _generator_count(payload: dict) -> int:
    """Estimate the number of independent generators from (V, E).

    For an abelian group on ``n`` involutive generators ``E = V·n/2``,
    so ``n = 2E/V``. The catalog stores the *unique* edge count, so
    rounding is safe for V₂, V₄, V₈ cases on the docket.
    """
    V = int(payload.get("V", 0))
    E = int(payload.get("E", 0))
    if V <= 1:
        return 0
    return max(0, round(2 * E / V))


def _classify(entry: dict) -> Resonance | None:
    if entry.get("kind") != "topology":
        return None
    p = entry.get("payload", {})
    order = int(p.get("order", 0))
    V = int(p.get("V", 0))
    E = int(p.get("E", 0))
    chi1 = int(p.get("chi_1", 0))
    chi2 = int(p.get("chi_2", 0))
    gens = _generator_count(p)

    if order < 4:
        return None
    if E < V:
        return None

    if gens >= 2 and chi1 < 0:
        tier = 0
        reason = (
            f"multi-generator (≈{gens}), χ₁={chi1} < 0 ⇒ true curvature / "
            "higher-genus skeleton; vertex→edge→face zoom is non-trivial."
        )
    elif gens >= 2 and chi1 <= 0:
        tier = 1
        reason = (
            f"multi-generator (≈{gens}), χ₁={chi1} ≤ 0 ⇒ Cayley graph "
            "lives on a circle (genus-0 1-skeleton); scale-bridging "
            "partially present."
        )
    else:
        tier = 2
        reason = (
            f"single-generator or trivially abelian; |G|={order}, "
            f"E={E}, χ₁={chi1}. Group-positioned but no cross-scale "
            "alignment yet."
        )

    trust = float(entry.get("trust", 0.0))
    score = (
        order * 10
        + max(0, E - V) * 5
        + max(0, -chi1) * 25     # negative χ₁ counts double (curvature)
        + max(0, -chi2) * 15
        + max(0, gens - 1) * 8
        + int(round(trust * 5))
    )
    return Resonance(
        tier=tier,
        score=score,
        arena=str(entry.get("arena", "")),
        slot=entry.get("slot", ""),
        summary=entry.get("summary", ""),
        payload={**p, "generators_approx": gens, "trust": trust},
        rationale=reason,
    )


def find_resonances(catalog: dict) -> list[Resonance]:
    rows: list[Resonance] = []
    for entry in catalog.get("entries", []):
        r = _classify(entry)
        if r is not None:
            rows.append(r)
    rows.sort(key=lambda r: (r.tier, -r.score, r.arena, r.slot))
    return rows


# ──────────────────────────────────────────────────────────────────────────
#  Companion: which conserved quantities decorate the same arena?
# ──────────────────────────────────────────────────────────────────────────
def conservation_witnesses(catalog: dict, arena: str | None = None) -> dict[str, list[str]]:
    """Group conservation entries by the operator they decorate.

    A scale-aware capsule is *more compelling* when independent
    conserved quantities also live in the same arena — they show the
    group action respects multiple invariants simultaneously.
    """
    by_op: dict[str, list[str]] = {}
    for e in catalog.get("entries", []):
        if e.get("kind") != "conservation":
            continue
        if arena is not None and e.get("arena") != arena:
            continue
        p = e.get("payload", {})
        op = f"phi_{p.get('op_index')}"
        by_op.setdefault(op, []).append(str(p.get("quantity")))
    for v in by_op.values():
        v.sort()
    return by_op


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_catalog() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith scale-aware-memory resonance query (Zone 121)."
    )
    p.add_argument("--catalog", type=Path, default=_default_catalog())
    p.add_argument("--tier", type=int, default=None,
                   help="show only this tier (0–2).")
    p.add_argument("--companions", action="store_true",
                   help="also list conservation witnesses per operator.")
    args = p.parse_args(argv)

    if not args.catalog.exists():
        print(f"# no catalog at {args.catalog} — run soilith_catalog.py first.")
        return 1
    catalog = json.loads(args.catalog.read_text(encoding="utf-8"))
    rows = find_resonances(catalog)
    if args.tier is not None:
        rows = [r for r in rows if r.tier == args.tier]

    print(f"# scale-aware-memory resonances over {args.catalog.name}")
    print(f"#   {len(rows)} qualifying topology rows  "
          f"(tier 0 = full capsule, 1 = partial, 2 = group-positioned)")
    if not rows:
        print("#   (none — no topology entries meet |G| ≥ 4 with E ≥ V)")
    for r in rows:
        print()
        print(f"  [tier {r.tier}]  score={r.score}  {r.slot}")
        print(f"     {r.summary}")
        print(f"     generators≈{r.payload['generators_approx']}, "
              f"trust={r.payload['trust']:.3f}, "
              f"V={r.payload.get('V')}, E={r.payload.get('E')}, "
              f"F={r.payload.get('F')}, χ₁={r.payload.get('chi_1')}, "
              f"χ₂={r.payload.get('chi_2')}")
        print(f"     → {r.rationale}")

    if args.companions:
        print()
        cons = conservation_witnesses(catalog)
        n = sum(len(v) for v in cons.values())
        print(f"# conservation witnesses available in catalog: "
              f"{n} laws over {len(cons)} operators")
        for op, qts in sorted(cons.items(), key=lambda kv: int(kv[0].split('_')[1])):
            if len(qts) >= 3:
                print(f"   {op}: preserves {', '.join(qts)}  "
                      f"({len(qts)} invariants ⇒ rich companion for any tier-0 capsule)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
