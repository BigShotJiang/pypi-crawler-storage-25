"""
soilith_refinement_check.py — static refinement type checker
(Zone 135).

Σoilith already had *runtime* refinement gates (the
``stdlib/*.sol`` ``ψ{trust ≥ X}`` annotations). Zone 135 turns
them into a **compile-time** check that consults the unified
catalog (``catalog/discoveries.json``) without running the
program.

Concretely, for any ``.sol`` source the checker:

1. parses every ``fn name(arg) : ψ{trust >= τ}: yield ... end``
   declaration into a refinement signature;
2. for each *call site* in the same module, statically infers a
   trust *lower bound* on the argument, drawing on:
     * literal ``trust = 0.95`` bindings;
     * ``with_trust(x, t)`` calls with a constant ``t``;
     * ``phi(k, …)`` calls — looked up in the catalog: if a Zone-116
       law or Zone-124 symmetry certifies that φ_k preserves trust at
       1.0, that bound propagates;
     * any catalog row ``law/*`` / ``symmetry/*`` / ``finite_order/*``
       that names the variable's source slot.
3. **rejects** the call if the inferred lower bound is below the
   gate's threshold; **accepts** with the residual gap otherwise.

This is the same shape as Liquid Haskell — refinements live in
comments, the checker runs offline — except Σoilith refinements
are *backed by empirical evidence* in the catalog rather than
SMT-discharged formulas. Every accepted call has a trail of
catalog rows that justify the bound.

CLI
---
    python soilith_refinement_check.py path/to/program.sol
    python soilith_refinement_check.py --self-demo
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import json
from pathlib import Path
import re
import sys
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Refinement signatures
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Refinement:
    """``fn name(arg) : ψ{trust >= τ}``."""
    name: str
    arg: str
    threshold: float


_FN_RE = re.compile(
    r"fn\s+(\w+)\s*\(\s*(\w+)\s*\)\s*:\s*"
    r"ψ\s*\{\s*trust\s*(?:>=|≥|>\s*=)\s*([0-9.]+)\s*\}",
    re.UNICODE,
)


def parse_refinements(source: str) -> dict[str, Refinement]:
    out: dict[str, Refinement] = {}
    for m in _FN_RE.finditer(source):
        name, arg, t = m.group(1), m.group(2), float(m.group(3))
        out[name] = Refinement(name=name, arg=arg, threshold=t)
    return out


# ──────────────────────────────────────────────────────────────────────────
#  Bindings / call sites
# ──────────────────────────────────────────────────────────────────────────
_LET_TRUST_RE = re.compile(
    r"let\s+(\w+)\s*=\s*with_trust\s*\(\s*(\w+)\s*,\s*([0-9.]+)\s*\)",
)
_TRUST_LITERAL_RE = re.compile(r"trust\s+(\w+)\s*=\s*([0-9.]+)")
_PHI_RE = re.compile(r"let\s+(\w+)\s*=\s*phi\s*\(\s*(\d+)\s*,\s*(\w+)")
_CALL_RE = re.compile(r"(?<!\.)([a-zA-Z_]\w*)\s*\(\s*(\w+)\s*\)")


@dataclass
class CallSite:
    function: str
    argument: str
    line: int


_FN_DECL_RE = re.compile(r"^\s*fn\s+\w+")
_END_RE = re.compile(r"^\s*end\s*$")
# Single-line ``fn name(args) : ψ : body end`` declarations open and close
# the body on the same line. Without this match a single-line ``fn`` would
# bump ``in_body`` but the same-line ``end`` would never decrement it (the
# ``continue`` short-circuits the end check), and every following line
# would be treated as still inside the body.
_SINGLE_LINE_FN_RE = re.compile(r"^\s*fn\s+\w+.*\bend\s*$")


def parse_calls(
    source: str, refinements: dict[str, Refinement],
) -> list[CallSite]:
    """Find call sites in *top-level* code only — calls inside a
    ``fn ... end`` body are part of the function's definition (where
    formal parameters are *guaranteed* to satisfy the refinement) and
    should not be re-checked at the call point."""
    out: list[CallSite] = []
    in_body = 0
    for ln, line in enumerate(source.splitlines(), start=1):
        if _SINGLE_LINE_FN_RE.match(line):
            continue
        if _FN_DECL_RE.match(line):
            in_body += 1
            continue
        if _END_RE.match(line) and in_body > 0:
            in_body -= 1
            continue
        if in_body > 0:
            continue
        for m in _CALL_RE.finditer(line):
            fn = m.group(1)
            if fn in refinements:
                out.append(CallSite(function=fn, argument=m.group(2),
                                    line=ln))
    return out


# ──────────────────────────────────────────────────────────────────────────
#  Trust inference
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class TrustEnvironment:
    """Lower bounds on trust for each named variable, plus the catalog
    rows that justified them."""

    bounds: dict[str, float] = field(default_factory=dict)
    evidence: dict[str, list[str]] = field(default_factory=dict)

    def declare(self, name: str, lo: float, witness: str) -> None:
        cur = self.bounds.get(name, -1.0)
        if lo > cur:
            self.bounds[name] = lo
            self.evidence[name] = [witness]
        elif abs(lo - cur) < 1e-12:
            self.evidence.setdefault(name, []).append(witness)


def _phi_trust_floor(phi_k: int, catalog: dict[str, Any]) -> tuple[float, str]:
    """Pick the strongest catalog row that constrains φ_k's trust output."""
    best = (0.5, f"phi_{phi_k} default depth-decay floor 0.5")
    for e in catalog.get("entries", []):
        kind = e.get("kind")
        slot = e.get("slot", "")
        payload = e.get("payload", {})
        op_idx = payload.get("op_index", payload.get("a", payload.get("b", -1)))
        try:
            op_idx = int(op_idx)
        except Exception:
            continue
        if op_idx != phi_k:
            continue
        trust = float(e.get("trust", 0.0))
        if kind == "symmetry" and trust >= best[0]:
            best = (trust, f"symmetry {slot} (trust={trust})")
        if kind == "finite_order" and trust >= best[0]:
            best = (trust, f"finite_order {slot} (trust={trust})")
        if kind == "law" and trust >= best[0]:
            best = (trust, f"law {slot} (trust={trust})")
    return best


def infer(
    source: str, catalog: dict[str, Any],
) -> TrustEnvironment:
    """Conservatively infer trust lower bounds. We track only:

    * ``trust x = c``               → x ≥ c
    * ``let y = with_trust(_, c)``  → y ≥ c
    * ``let y = phi(k, …)``         → y ≥ catalog floor for φ_k
    """
    env = TrustEnvironment()
    for line in source.splitlines():
        for m in _TRUST_LITERAL_RE.finditer(line):
            env.declare(m.group(1), float(m.group(2)),
                        witness=f"literal trust = {m.group(2)}")
        for m in _LET_TRUST_RE.finditer(line):
            env.declare(m.group(1), float(m.group(3)),
                        witness=f"with_trust(..., {m.group(3)})")
        for m in _PHI_RE.finditer(line):
            name, k = m.group(1), int(m.group(2))
            input_arg = m.group(3)
            input_lo = env.bounds.get(input_arg, 0.0)
            cat_floor, why = _phi_trust_floor(k, catalog)
            # Output trust is bounded above by input trust (a phi can't
            # manufacture trust). The catalog floor only matters as a
            # cap; we take the min so high-trust catalog evidence on
            # phi_k applied to a low-trust argument still yields a
            # low bound.
            lo = min(input_lo, cat_floor)
            ev = (
                f"phi_{k}({input_arg}) with input_lo={input_lo:.3f}, "
                f"catalog_floor={cat_floor:.3f} ({why})"
            )
            env.declare(name, lo, witness=ev)
    return env


# ──────────────────────────────────────────────────────────────────────────
#  Verdict
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Verdict:
    site: CallSite
    threshold: float
    inferred: float
    accepted: bool
    evidence: list[str]
    reason: str = ""

    def describe(self) -> str:
        ok = "✓" if self.accepted else "✗"
        out = [
            f"{ok}  line {self.site.line}: {self.site.function}"
            f"({self.site.argument})  needs trust ≥ {self.threshold:.3f}, "
            f"inferred ≥ {self.inferred:.3f}",
        ]
        if self.evidence:
            for e in self.evidence:
                out.append(f"     evidence: {e}")
        if not self.accepted:
            out.append(f"     reason: {self.reason}")
        return "\n".join(out)


@dataclass
class CheckReport:
    accepted: list[Verdict] = field(default_factory=list)
    rejected: list[Verdict] = field(default_factory=list)

    @property
    def successful(self) -> bool:
        return not self.rejected

    def describe(self) -> str:
        ok = "✓" if self.successful else "✗"
        out = [
            f"CheckReport {ok}  "
            f"accepted={len(self.accepted)} rejected={len(self.rejected)}",
        ]
        for v in self.accepted + self.rejected:
            out.append(v.describe())
        return "\n".join(out)


def check(source: str, catalog: dict[str, Any]) -> CheckReport:
    refs = parse_refinements(source)
    if not refs:
        return CheckReport()
    calls = parse_calls(source, refs)
    env = infer(source, catalog)
    rep = CheckReport()
    for site in calls:
        ref = refs[site.function]
        lo = env.bounds.get(site.argument, 0.0)
        evidence = env.evidence.get(site.argument, [])
        if lo >= ref.threshold - 1e-12:
            rep.accepted.append(Verdict(
                site=site, threshold=ref.threshold, inferred=lo,
                accepted=True, evidence=evidence,
            ))
        else:
            rep.rejected.append(Verdict(
                site=site, threshold=ref.threshold, inferred=lo,
                accepted=False, evidence=evidence,
                reason=(
                    f"argument {site.argument!r} not proven to have "
                    f"trust ≥ {ref.threshold}"
                ),
            ))
    return rep


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(report: CheckReport, slot_name: str, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(len(report.accepted)), float(len(report.rejected)),
        1.0 if report.successful else 0.0,
    ], dtype=float)
    trust = 1.0 if report.successful else 0.5
    arena[f"refinement_check/{slot_name}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
DEMO = """
# demo.sol
trust hi = 0.95
trust lo = 0.30
let safe = with_trust(seed, 0.95)
let warm = phi(38, hi)
let cold = phi(45, lo)

fn admit_high(x) : ψ{trust >= 0.85}:
    yield x
end

fn admit_any(x) : ψ{trust >= 0.0}:
    yield x
end

# These should pass:
admit_high(safe)
admit_high(hi)
admit_any(lo)

# This should be rejected:
admit_high(lo)
admit_high(cold)
"""


def _default_catalog() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith static refinement type checker (Zone 135)."
    )
    p.add_argument("source", nargs="?", default=None)
    p.add_argument("--catalog", type=Path, default=_default_catalog())
    p.add_argument("--self-demo", action="store_true")
    p.add_argument("--arena", type=Path,
                   default=Path(__file__).resolve().parent / "lawbook.arena")
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    if args.self_demo or args.source is None:
        source = DEMO
        label = "demo"
    else:
        source = Path(args.source).read_text(encoding="utf-8")
        label = Path(args.source).stem
    catalog = json.loads(args.catalog.read_text(encoding="utf-8")) \
        if args.catalog.exists() else {"entries": []}

    print("# Zone 135 — static refinement check")
    print(f"#   source = {label}")
    print(f"#   catalog entries available: {len(catalog.get('entries', []))}")
    print()
    report = check(source, catalog)
    print(report.describe())
    persist(report, label, args.arena)
    return 0 if report.successful else 1


if __name__ == "__main__":
    raise SystemExit(main())
