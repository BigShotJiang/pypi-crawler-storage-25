"""
soilith_symmetry_closure.py — closure structure of discovered capsule
symmetries (Zone 125).

The Zone 124 engine discovered five non-identity-alias capsule
symmetries — ``{φ_2, φ_38, φ_41, φ_45, φ_59}`` — that are gauge
transformations of every tier-0 capsule in the catalog. Zone 125 takes
that *set* and asks the next-order question: **what is the algebraic
structure they generate?**

A direct closure under composition (Zone 117's ``build_group``) found
the set is **open** at every reasonable size cap: ordered 25 at
max=24, ordered 129 at max=128. The honest interpretation is that
either (a) the generators don't all have finite order at threshold
1e-6, or (b) they don't commute and span a non-abelian monoid larger
than the cap. So Zone 125 doesn't pretend to enumerate the group;
it *characterizes* it:

* ``generator_orders``  : smallest ``n ∈ [1, N_probe]`` such that
                          ``φ_k^n`` acts as identity on a sample
                          battery within tolerance; ``None`` otherwise.
* ``commutators``       : ``(k_a, k_b) → ‖φ_a∘φ_b − φ_b∘φ_a‖`` over the
                          battery. Symmetric in (a, b). Zero ⇒ commute.
* ``abelian``           : all off-diagonal commutator residuals < tol.
* ``finite_abelian``    : abelian AND every generator has finite order
                          AND the resulting product group is ≤ a cap.
                          Only then does ``graph`` populate with the
                          Cayley graph and χ invariants.

The persisted cell still ships ``[order, V, E, F, χ₁, χ₂, abelian,
max_generator_order]`` so catalog readers that already understand the
six-integer Zone-117 layout keep working; the two new floats are
``-1.0`` when the closure didn't enumerate.

CLI
---
    python soilith_symmetry_closure.py
    python soilith_symmetry_closure.py --probe z2_cubed
    python soilith_symmetry_closure.py --probe z2_to_the_4
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import json
from pathlib import Path
import re
import sys
from typing import Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_arena import Arena  # noqa: E402
from soilith_lang import Cell  # noqa: E402
from soilith_phi import PHI  # noqa: E402
from soilith_topology import (  # noqa: E402
    CayleyGraph,
    _default_samples,
    _safe_call,
    build_group,
)


# ──────────────────────────────────────────────────────────────────────────
#  Records
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class SymmetryClosure:
    """Structural characterization of a discovered symmetry set.

    Honest about openness: ``graph`` is populated only when the set is
    abelian AND every generator has finite order; otherwise the field
    is ``None`` and the closure is described by ``generator_orders``
    and ``commutators`` alone.
    """

    capsule_probe: str
    generator_indices: list[int]
    generator_orders: dict[int, int | None]
    commutators: dict[tuple[int, int], float]
    abelian: bool
    finite_abelian: bool
    max_generator_order: int   # max finite order found; -1 if any is None
    graph: CayleyGraph | None
    notes: list[str]
    shape_preserving: dict[int, bool] = field(default_factory=dict)

    def name(self) -> str:
        if self.graph is not None:
            return self.graph.name()
        if not self.abelian:
            return "non-abelian open monoid"
        return "abelian open monoid (infinite-order generators)"

    def describe(self) -> str:
        gens = ", ".join(f"φ_{k}" for k in self.generator_indices)
        endo = [k for k, ok in self.shape_preserving.items() if ok]
        exo = [k for k, ok in self.shape_preserving.items() if not ok]
        lines = [
            f"SymmetryClosure on capsule={self.capsule_probe}",
            f"  generators        = [{gens}]",
            f"  shape-preserving  = {endo}",
            f"  shape-changing    = {exo}  (excluded from Cayley)",
            f"  generator_orders  = {dict(sorted(self.generator_orders.items()))}",
            f"  abelian (endo)    = {self.abelian}",
            f"  finite_abelian    = {self.finite_abelian}",
            f"  max_gen_order     = {self.max_generator_order}",
        ]
        if self.commutators:
            worst = max(self.commutators.items(), key=lambda kv: kv[1])
            lines.append(
                f"  worst commutator  = {worst[0]} → ‖[a,b]‖ = {worst[1]:.3e}"
            )
        if self.graph is not None:
            lines.append("  ── Cayley graph ──")
            lines.append("  " + self.graph.describe().replace("\n", "\n  "))
        else:
            lines.append("  (no finite Cayley graph — closure is open)")
        for note in self.notes:
            lines.append(f"  · {note}")
        return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────
#  Catalog → operator set
# ──────────────────────────────────────────────────────────────────────────
def operators_from_catalog(
    catalog: dict,
    probe: str,
    *,
    exclude_identity: bool = True,
) -> dict[str, Callable]:
    """Pull every certified Zone-124 capsule-symmetry operator on ``probe``.

    Returns a dictionary keyed by ``"phi_<k>"`` mapping to the live
    ``PHI[k]`` callable. Duplicate (k, quantity) entries collapse to a
    single operator (we just want the set of operators).
    """
    seen: dict[int, bool] = {}
    for e in catalog.get("entries", []):
        if e.get("kind") != "symmetry":
            continue
        p = e.get("payload", {})
        if p.get("capsule_probe") != probe:
            continue
        if exclude_identity and bool(p.get("is_identity_alias", False)):
            continue
        k = int(p.get("op_index", -1))
        if k in PHI:
            seen[k] = True

    return {f"phi_{k}": PHI[k] for k in sorted(seen.keys())}


# ──────────────────────────────────────────────────────────────────────────
#  Closure
# ──────────────────────────────────────────────────────────────────────────
def _is_shape_preserving(op: Callable, samples: list[np.ndarray]) -> bool:
    """True iff ``op(x)`` has the same shape as ``x.ravel()`` for every
    sample. Operators that change dimension cannot self-compose into
    a meaningful order/commutator structure on a fixed cell shape."""
    for x in samples:
        y = _safe_call(op, x)
        if y is None or y.shape != x.ravel().shape:
            return False
    return True


def _generator_order(
    op: Callable,
    samples: list[np.ndarray],
    *,
    max_probe: int = 12,
    tol: float = 1e-6,
) -> int | None:
    """Smallest ``n ∈ [1, max_probe]`` such that ``op^n`` is the identity
    on every sample within ``tol``; ``None`` if no such ``n`` (or if
    ``op`` is not shape-preserving)."""
    if not _is_shape_preserving(op, samples):
        return None
    current_outputs: list[np.ndarray] = []
    for x in samples:
        y = _safe_call(op, x)
        if y is None:
            return None
        current_outputs.append(y)
    for n in range(1, max_probe + 1):
        try:
            is_id = all(
                np.allclose(samples[i].ravel(), current_outputs[i],
                            atol=tol, rtol=0.0)
                for i in range(len(samples))
            )
        except ValueError:
            return None
        if is_id:
            return n
        next_outputs: list[np.ndarray] = []
        for i, _ in enumerate(samples):
            z = _safe_call(op, current_outputs[i])
            if z is None or z.shape != samples[i].ravel().shape:
                return None
            next_outputs.append(z)
        current_outputs = next_outputs
    return None


def _commutator_residual(
    op_a: Callable,
    op_b: Callable,
    samples: list[np.ndarray],
) -> float:
    """``sup_x ‖op_a(op_b(x)) − op_b(op_a(x))‖`` over the battery.

    Returns ``inf`` if either operator fails, returns non-real output,
    or produces a shape mismatch that prevents the difference being
    formed.
    """
    worst = 0.0
    for x in samples:
        ab = _safe_call(op_a, _safe_call(op_b, x))
        ba = _safe_call(op_b, _safe_call(op_a, x))
        if ab is None or ba is None:
            return float("inf")
        if ab.shape != ba.shape:
            return float("inf")
        worst = max(worst, float(np.linalg.norm(ab - ba)))
    return worst


def close(
    ops: dict[str, Callable],
    *,
    samples: list[np.ndarray] | None = None,
    seed: int = 42,
    dim: int = 16,
    trials: int = 8,
    max_order: int = 32,
    tol: float = 1e-6,
    capsule_probe: str = "",
) -> SymmetryClosure:
    """Characterize the structure generated by ``ops`` under composition.

    Computes generator orders, pairwise commutators, and an abelian
    flag.  Only attempts to enumerate a Cayley graph + χ when the set
    is genuinely abelian AND every generator has finite order ≤
    ``max_order``; otherwise reports honestly that the closure is open.
    """
    if samples is None:
        samples = _default_samples(seed, dim, trials)
    gens_idx = sorted(
        int(re.match(r"phi_(\d+)$", n).group(1))  # type: ignore[union-attr]
        for n in ops.keys()
        if re.match(r"phi_(\d+)$", n)
    )

    notes: list[str] = []
    name_to_op = {f"phi_{k}": ops.get(f"phi_{k}") for k in gens_idx}

    # 1a) Shape-preservation per generator — needed before any
    #     composition / order / commutator analysis makes sense.
    shape_preserving: dict[int, bool] = {
        k: _is_shape_preserving(name_to_op[f"phi_{k}"], samples)
        for k in gens_idx
    }
    endo = [k for k, ok in shape_preserving.items() if ok]
    exo = [k for k, ok in shape_preserving.items() if not ok]
    if exo:
        notes.append(
            "shape-changing generators (NOT vector-space endomorphisms): "
            + ", ".join(f"φ_{k}" for k in exo)
            + " — these are invariant-preserving morphisms across cell"
              " shapes, not group elements; they're excluded from the"
              " Cayley enumeration but retain their Zone 124 verdict."
        )

    # 1b) Generator orders — only meaningful for shape-preserving ops.
    orders: dict[int, int | None] = {}
    for k in gens_idx:
        if shape_preserving[k]:
            orders[k] = _generator_order(
                name_to_op[f"phi_{k}"], samples, tol=tol
            )
        else:
            orders[k] = None
    finite_orders = {k: n for k, n in orders.items() if n is not None}
    all_finite = (
        len(finite_orders) == len(endo) and len(endo) == len(gens_idx)
    )
    max_gen_order = max(finite_orders.values()) if finite_orders else -1
    if endo and not all_finite:
        unbounded = [
            k for k, n in orders.items()
            if n is None and shape_preserving[k]
        ]
        if unbounded:
            notes.append(
                "shape-preserving but unbounded-order generators: "
                + ", ".join(f"φ_{k}" for k in unbounded)
            )

    # 2) Commutators — only over the endo subset.
    commutators: dict[tuple[int, int], float] = {}
    for i, ka in enumerate(endo):
        for kb in endo[i + 1:]:
            resid = _commutator_residual(
                name_to_op[f"phi_{ka}"], name_to_op[f"phi_{kb}"], samples
            )
            commutators[(ka, kb)] = resid
    abelian = all(v < tol for v in commutators.values()) if commutators else True
    if not abelian:
        bad = [(k, v) for k, v in commutators.items() if v >= tol]
        bad.sort(key=lambda kv: -kv[1])
        notes.append(
            "non-commuting pairs: "
            + ", ".join(f"{p[0]}:{p[1]:.1e}" for p in bad[:4])
        )

    # 3) Attempt Cayley graph only when (endo, abelian, all finite).
    graph: CayleyGraph | None = None
    finite_abelian = abelian and all_finite and len(endo) > 0
    if finite_abelian:
        endo_ops = {f"phi_{k}": ops[f"phi_{k}"] for k in endo}
        try:
            graph = build_group(endo_ops, samples, max_order=max_order)
            if graph.order > max_order:
                graph = None
                notes.append(
                    f"abelian but Cayley enumeration exceeded max_order={max_order}"
                )
        except Exception as exc:  # pragma: no cover — defensive
            notes.append(f"build_group raised {type(exc).__name__}: {exc}")
            graph = None

    return SymmetryClosure(
        capsule_probe=capsule_probe,
        generator_indices=gens_idx,
        generator_orders=orders,
        commutators=commutators,
        abelian=abelian,
        finite_abelian=finite_abelian and graph is not None,
        max_generator_order=int(max_gen_order),
        graph=graph,
        notes=notes,
        shape_preserving=shape_preserving,
    )


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def _slot_safe_name(name: str) -> str:
    """Slot-safe rendering of a group name (drop Unicode, spaces, slashes)."""
    out = []
    for ch in name:
        if ch.isalnum():
            out.append(ch)
        elif ch in ("_",):
            out.append(ch)
        else:
            out.append("_")
    s = "".join(out).strip("_")
    while "__" in s:
        s = s.replace("__", "_")
    return s or "unnamed"


def persist(arena_path: Path, closure: SymmetryClosure) -> None:
    """Write the closure as ``closure/<probe>/<safe_group_name>``.

    Cell payload: ``[order, V, E, F, χ₁, χ₂, abelian, max_gen_order]``.
    The first six match the Zone 117 topology layout for backward
    compatibility; the last two are ``-1.0`` (or 0.0/1.0 for abelian)
    when the enumeration didn't run.  Trust is ``0.5`` for open
    monoids and ``1.0`` for fully enumerated Cayley graphs — adoption
    gates can refuse to celebrate an open closure.
    """
    a = Arena.open(arena_path, autoflush=False)
    probe = closure.capsule_probe or "anonymous"
    name = _slot_safe_name(closure.name())
    slot = f"closure/{probe}/{name}"
    if closure.graph is not None:
        g = closure.graph
        payload = [g.order, g.V, g.E, g.F, g.euler_1, g.euler_2]
        trust = 1.0
    else:
        payload = [-1.0, -1.0, -1.0, -1.0, 0.0, 0.0]
        trust = 0.5
    payload.append(1.0 if closure.abelian else 0.0)
    payload.append(float(closure.max_generator_order))
    a[slot] = Cell(
        value=np.array(payload, dtype=float),
        trust=float(trust),
        phase=0.0,
    )
    a.flush()


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_catalog() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def _default_lawbook() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith capsule-symmetry closure (Zone 125)."
    )
    p.add_argument("--catalog", type=Path, default=_default_catalog())
    p.add_argument("--arena", type=Path, default=_default_lawbook())
    p.add_argument("--probe", default=None,
                   help="capsule probe name (default: every probe found).")
    p.add_argument("--max-order", type=int, default=24)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--dim", type=int, default=16)
    p.add_argument("--trials", type=int, default=8)
    p.add_argument("--no-persist", action="store_true")
    args = p.parse_args(argv)

    if not args.catalog.exists():
        print(f"# no catalog at {args.catalog}; run soilith_catalog.py first.")
        return 1

    data = json.loads(args.catalog.read_text(encoding="utf-8"))
    probes: set[str] = {
        e.get("payload", {}).get("capsule_probe", "")
        for e in data.get("entries", [])
        if e.get("kind") == "symmetry"
    }
    probes.discard("")
    if args.probe:
        probes = {args.probe} & probes
        if not probes:
            print(f"# no symmetry rows for probe={args.probe!r}.")
            return 1

    samples = _default_samples(args.seed, args.dim, args.trials)

    closures: list[SymmetryClosure] = []
    for probe in sorted(probes):
        ops = operators_from_catalog(data, probe)
        if not ops:
            print(f"# no non-trivial symmetry operators for probe={probe!r}")
            continue
        print(f"\n## closure on capsule={probe}")
        print(f"   generators = {sorted(ops.keys())}")
        closure = close(
            ops,
            samples=samples,
            max_order=args.max_order,
            capsule_probe=probe,
        )
        print(closure.describe())
        closures.append(closure)

    if not args.no_persist and closures:
        for c in closures:
            persist(args.arena, c)
        print(f"\n# persisted {len(closures)} closure/* cells → {args.arena}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
