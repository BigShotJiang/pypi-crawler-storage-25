"""echovalidum.catalog — discovery catalog.

Re-exports from ``soilith_catalog``. The catalog scans arena
files for slot families and emits a JSON manifest with stable
ids, per-zone counts, and audit summaries. It currently indexes
laws, topology, conservation, magnitude, symmetry, closure,
signature, typed closures, finite orders, round-trips,
composition laws, pair groups, fibrations, descent, separation,
linearity, capabilities, ownership, refinement checks, sessions,
effects, IFC, concurrency, region, gradual, contract, posterior,
incremental, abstract, weak memory, soundness, intervals, sparse,
benchmarks, z3verify, mem64, and loop_ifc — 36 kinds across
zones 116..154.
"""

from __future__ import annotations

from soilith_catalog import (  # noqa: F401
    CatalogEntry, scan_arena, build_manifest, write_manifest,
    default_output_path,
)

__all__ = [
    "CatalogEntry",
    "scan_arena", "build_manifest", "write_manifest",
    "default_output_path",
]
