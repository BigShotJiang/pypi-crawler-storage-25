"""echovalidum.ifc — Zone-138 information-flow control.

Re-exports from ``soilith_ifc``. The two-point security lattice
(``Label.LOW``, ``Label.HIGH``) plus the 2-trace non-interference
check ``noninterference_check`` and the capability-gated
``declassify``.
"""

from __future__ import annotations

from soilith_ifc import (  # noqa: F401
    Label, LabeledCell, LabeledStore,
    NIReport,
    IFCError, IllegalFlow, Interference,
    apply_phi, declassify, noninterference_check,
)

__all__ = [
    "Label", "LabeledCell", "LabeledStore", "NIReport",
    "IFCError", "IllegalFlow", "Interference",
    "apply_phi", "declassify", "noninterference_check",
]
