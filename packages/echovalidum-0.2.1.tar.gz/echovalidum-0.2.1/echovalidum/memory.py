"""echovalidum.memory — core lattice memory primitives.

Re-exports from the historical ``soilith_lang``, ``soilith_arena``,
``soilith_sparse``, and ``soilith_64bit`` modules. No behaviour
change; this is the clean front door for code that wants to write
``from echovalidum.memory import Cell, Arena, Memory64`` etc.
"""

from __future__ import annotations

from soilith_lang import (  # noqa: F401
    Cell, BOT, TOP, TrustError, QuorumError,
)
from soilith_arena import Arena  # noqa: F401
from soilith_sparse import SparseScaleMemory  # noqa: F401
from soilith_64bit import (  # noqa: F401
    Memory64, Capability, CapabilityFault,
)

__all__ = [
    "Cell", "BOT", "TOP", "TrustError", "QuorumError",
    "Arena",
    "SparseScaleMemory",
    "Memory64", "Capability", "CapabilityFault",
]
