"""echovalidum.loops — Zone-154 loop-form non-interference.

Re-exports the six basic loop forms (Zone 153) and their
termination-sensitive NI machinery (Zone 154) from
``soilith_loop_ifc``: the ``LoopForm`` and ``IFCVerdict`` enums,
the ``SSChannel`` taxonomy that maps each form onto its
Sabelfeld-Sands covert channel, the 2-trace empirical check
``iteration_count_ni_check``, and the Z3-backed discharger
``discharge_loop_form_ni`` (which also routes through the
PQC/MVPS attestation pipeline when ``sign=True``).
"""

from __future__ import annotations

from soilith_loop_ifc import (  # noqa: F401
    LoopForm, IFCVerdict, SSChannel,
    LoopNIReport,
    classify_loop_form, channel_of,
    iteration_count_ni_check, discharge_loop_form_ni,
    factory_operator_range, factory_cayley_ball,
    factory_mem64_pages, factory_fixpoint_widen,
    factory_dag_replay, factory_ess_resample,
    persist,
)

__all__ = [
    "LoopForm", "IFCVerdict", "SSChannel", "LoopNIReport",
    "classify_loop_form", "channel_of",
    "iteration_count_ni_check", "discharge_loop_form_ni",
    "factory_operator_range", "factory_cayley_ball",
    "factory_mem64_pages", "factory_fixpoint_widen",
    "factory_dag_replay", "factory_ess_resample",
    "persist",
]
