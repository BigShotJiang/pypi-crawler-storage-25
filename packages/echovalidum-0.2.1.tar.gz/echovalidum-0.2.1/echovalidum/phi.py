"""echovalidum.phi — operator algebra φ_0..φ_60.

Re-exports ``PHI`` (a dict ``{k: callable}``) and the individual
``phi_k`` functions from ``soilith_phi``.
"""

from __future__ import annotations

from soilith_phi import PHI  # noqa: F401

__all__ = ["PHI"]
