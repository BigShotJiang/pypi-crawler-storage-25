"""
soilith_topology.py — Σoilith topological self-knowledge (Zone 117).

She builds the Cayley graph of any subgroup she finds in her own operator
algebra and computes its Euler characteristic χ = V − E + F.

Why this exists
---------------
Zone 116's discovery engine surfaced relationships like ``φ_a ∘ φ_b ≈ x``,
which collapse to *abstract group laws*. Two operators that compose to the
identity could be (a) genuinely distinct involutions, or (b) two formulas
that happen to be functionally equal as maps. The lawbook alone cannot
tell them apart — only an *empirical equivalence test* over a fixed sample
battery can. This module performs that test, recovers the underlying
group, and reads off its topology.

Pipeline
--------
1.  ``cluster(ops, samples)`` partitions named operators into functional
    equivalence classes via signature hashing (rounded outputs over a
    fixed sample battery).
2.  ``build_group(ops, samples)`` inserts the missing identity if absent,
    closes the resulting set under composition, builds the full
    multiplication table, picks minimal generators by greedy span, and
    materializes the Cayley graph.
3.  ``CayleyGraph.euler_1`` and ``.euler_2`` return χ for the 1-skeleton
    and the 2-complex obtained by gluing 2-cells along commutator
    squares that close to the identity (the canonical presentation of
    the abelianization).
4.  ``main()`` runs the pipeline against a user-supplied set of
    operators — either by PHI index (the default surface, mirroring
    Zone 116) or from an in-memory dict (used by the V₄ demo).

What "Euler characteristic of a group" means here
-------------------------------------------------
There are several reasonable definitions; this module computes the
*combinatorial Euler characteristic of the Cayley 2-complex* obtained
by:

* one 0-cell per group element  → V
* one 1-cell per generator edge → E
* one 2-cell per commutator that bounds a closed square in the Cayley
  graph (i.e. every relation ``[g, h] = e`` for distinct generators g, h)
                                  → F

so χ = V − E + F.  For abelian groups on n independent involutive
generators this recovers the χ of the n-torus skeleton:

    | group              | (V, E, F) | χ (1-cplx) | χ (2-cplx) |
    | trivial {e}        | (1, 0, 0) |     1      |     1      |
    | ℤ/2                | (2, 1, 0) |     1      |     1      |
    | V₄ = ℤ/2 × ℤ/2     | (4, 4, 1) |     0      |     1      |  *square w/ 1 face → disc*
    | ℤ/4 (cyclic)       | (4, 4, 0) |     0      |     0      |  *4-cycle, no relation*
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Callable, Optional

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_phi import PHI  # noqa: E402
from soilith_arena import Arena  # noqa: E402
from soilith_lang import Cell  # noqa: E402


Operator = Callable[[np.ndarray], np.ndarray]
Signature = tuple[tuple[float, ...], ...]


# ──────────────────────────────────────────────────────────────────────────
#  Functional-equivalence clustering
# ──────────────────────────────────────────────────────────────────────────
def _safe_call(op: Operator, x: np.ndarray) -> Optional[np.ndarray]:
    try:
        y = op(x)
        if isinstance(y, tuple):
            parts = [np.asarray(p) for p in y]
            if any(np.iscomplexobj(p) for p in parts):
                return None
            y = np.concatenate([p.astype(np.float64).ravel() for p in parts])
        y = np.asarray(y)
        if np.iscomplexobj(y):
            return None
        y = y.astype(np.float64).ravel()
        if y.size == 0 or not np.all(np.isfinite(y)):
            return None
        return y
    except Exception:
        return None


def _signature(op: Operator, samples: list[np.ndarray], digits: int = 6) -> Optional[Signature]:
    """Hashable functional signature: rounded outputs across the sample battery.

    Two operators with the same signature act identically (within ``10^-digits``)
    on every sample, so they represent the same group element.
    """
    rows = []
    for x in samples:
        y = _safe_call(op, x)
        if y is None:
            return None
        rows.append(tuple(np.round(y, digits).tolist()))
    return tuple(rows)


def _identity_signature(samples: list[np.ndarray], digits: int = 6) -> Signature:
    return tuple(tuple(np.round(x.ravel(), digits).tolist()) for x in samples)


def cluster(ops: dict[str, Operator], samples: list[np.ndarray]) -> dict[Signature, list[str]]:
    """Partition named operators into functional equivalence classes."""
    classes: dict[Signature, list[str]] = {}
    for name, op in ops.items():
        sig = _signature(op, samples)
        if sig is None:
            continue
        classes.setdefault(sig, []).append(name)
    for v in classes.values():
        v.sort()
    return classes


# ──────────────────────────────────────────────────────────────────────────
#  Cayley graph + Euler characteristic
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class CayleyGraph:
    """The Cayley 2-complex of a finite group discovered from operator probes."""

    elements: list[str]
    multiplication: dict[tuple[str, str], str]  # (a, b) → a·b
    identity: str
    generators: list[str]
    edges: set[tuple[str, str]]      # undirected (min, max)
    n_2cells: int = 0
    aliases: dict[str, list[str]] = field(default_factory=dict)

    @property
    def order(self) -> int:
        return len(self.elements)

    @property
    def V(self) -> int:
        return len(self.elements)

    @property
    def E(self) -> int:
        return len(self.edges)

    @property
    def F(self) -> int:
        return self.n_2cells

    @property
    def euler_1(self) -> int:
        """χ of the Cayley graph as a 1-complex."""
        return self.V - self.E

    @property
    def euler_2(self) -> int:
        """χ of the Cayley 2-complex (one 2-cell per closing commutator)."""
        return self.V - self.E + self.n_2cells

    def name(self) -> str:
        n = self.order
        if n == 1:
            return "trivial group {e}"
        if n == 2:
            return "ℤ/2"
        if n == 3:
            return "ℤ/3 (cyclic group of order 3)"
        if n == 4:
            non_id = [e for e in self.elements if e != self.identity]
            if all(self.multiplication.get((e, e)) == self.identity for e in non_id):
                return "Klein-four V₄ ≅ ℤ/2 × ℤ/2"
            return "ℤ/4 (cyclic group of order 4)"
        return f"group of order {n}"

    def describe(self) -> str:
        lines = [
            f"Cayley graph of  {self.name()}",
            f"  order        = {self.order}",
            f"  elements     = {self.elements}",
            f"  generators   = {self.generators}",
            f"  V, E, F      = {self.V}, {self.E}, {self.F}",
            f"  χ(1-complex) = {self.euler_1}",
            f"  χ(2-complex) = {self.euler_2}",
        ]
        if any(len(v) > 1 for v in self.aliases.values()):
            lines.append(f"  aliases      = {self.aliases}")
        return "\n".join(lines)


def _closure(seed: set[str], mult: dict[tuple[str, str], str]) -> set[str]:
    """Smallest set containing ``seed`` that is closed under the multiplication."""
    out = set(seed)
    changed = True
    while changed:
        changed = False
        for a in list(out):
            for b in list(out):
                p = mult.get((a, b))
                if p is not None and p not in out:
                    out.add(p)
                    changed = True
    return out


def build_group(
    ops: dict[str, Operator],
    samples: list[np.ndarray],
    *,
    max_order: int = 32,
) -> CayleyGraph:
    """Infer the group structure of ``ops`` empirically over the sample battery.

    The procedure:
      1. cluster operators by functional equivalence;
      2. ensure the identity class is present;
      3. close the set under composition with composition-signature caching;
      4. compute the full multiplication table;
      5. pick minimal generators by greedy span;
      6. emit the Cayley graph + commutator 2-cells.

    ``max_order`` bounds the discovered group's order — a guard against
    operator sets that don't close into a finite group within the
    sample-precision tolerance.
    """
    classes = cluster(ops, samples)
    id_sig = _identity_signature(samples)

    sig_to_name: dict[Signature, str] = {}
    sig_to_action: dict[Signature, Operator] = {}
    aliases: dict[str, list[str]] = {}

    for sig, names in classes.items():
        canonical = "e" if sig == id_sig else names[0]
        sig_to_name[sig] = canonical
        sig_to_action[sig] = ops[names[0]]
        aliases[canonical] = list(names)

    if id_sig not in sig_to_name:
        sig_to_name[id_sig] = "e"
        sig_to_action[id_sig] = lambda x: x.copy()
        aliases["e"] = ["(virtual identity)"]

    sigs = list(sig_to_name.keys())

    # Composition cache: (sig_a, sig_b) → sig(a∘b). Each pair is probed
    # exactly once, even across multiple closure iterations.
    comp_cache: dict[tuple[Signature, Signature], Signature] = {}

    def _compose_sig(sa: Signature, sb: Signature) -> Optional[Signature]:
        key = (sa, sb)
        if key in comp_cache:
            return comp_cache[key]
        fa, fb = sig_to_action[sa], sig_to_action[sb]
        comp = _signature(lambda x, fa=fa, fb=fb: fa(fb(x)), samples)
        if comp is not None:
            comp_cache[key] = comp
        return comp

    # Close under composition.
    iters = 0
    while iters < 64 and len(sigs) <= max_order:
        iters += 1
        added: list[Signature] = []
        for sa in list(sigs):
            for sb in list(sigs):
                comp = _compose_sig(sa, sb)
                if comp is None or comp in sig_to_name:
                    continue
                new_name = f"{sig_to_name[sa]}·{sig_to_name[sb]}"
                sig_to_name[comp] = new_name
                fa, fb = sig_to_action[sa], sig_to_action[sb]
                sig_to_action[comp] = lambda x, fa=fa, fb=fb: fa(fb(x))
                aliases[new_name] = []
                added.append(comp)
                if len(sigs) + len(added) > max_order:
                    break
            if len(sigs) + len(added) > max_order:
                break
        if not added:
            break
        sigs.extend(added)

    # Multiplication table — reuse the cache populated during closure.
    mult: dict[tuple[str, str], str] = {}
    for sa in sigs:
        for sb in sigs:
            comp = _compose_sig(sa, sb)
            if comp in sig_to_name:
                mult[(sig_to_name[sa], sig_to_name[sb])] = sig_to_name[comp]

    elements = sorted(sig_to_name.values(), key=lambda n: (n != "e", n))

    # Minimal generators by greedy span.
    generators: list[str] = []
    spanned = {"e"}
    while spanned != set(elements):
        best, best_size = None, len(spanned)
        for cand in elements:
            if cand in spanned:
                continue
            new_span = _closure(spanned | {cand}, mult)
            if len(new_span) > best_size:
                best, best_size = cand, len(new_span)
        if best is None:
            break
        generators.append(best)
        spanned = _closure(spanned | {best}, mult)

    # Cayley graph edges (undirected).
    edges: set[tuple[str, str]] = set()
    for elem in elements:
        for gen in generators:
            tgt = mult.get((elem, gen))
            if tgt is None or tgt == elem:
                continue
            edges.add((min(elem, tgt), max(elem, tgt)))

    # 2-cells from commutator squares: every pair of distinct generators (g, h)
    # whose commutator [g, h] = g·h·g^(-1)·h^(-1) equals e bounds one 2-cell.
    # For involutive generators (order 2), g^(-1) = g, so [g, h] = (g·h)².
    n_2cells = 0
    for i, g in enumerate(generators):
        for h in generators[i + 1:]:
            gh = mult.get((g, h))
            hg = mult.get((h, g))
            if gh is None or hg is None:
                continue
            if gh == hg:  # abelian commutator closes
                n_2cells += 1

    return CayleyGraph(
        elements=elements,
        multiplication=mult,
        identity="e",
        generators=generators,
        edges=edges,
        n_2cells=n_2cells,
        aliases=aliases,
    )


# ──────────────────────────────────────────────────────────────────────────
#  Lawbook-driven discovery (probes operators referenced by Zone 116 laws)
# ──────────────────────────────────────────────────────────────────────────
def _operator_indices_from_lawbook(
    arena_path: Path,
    *,
    residual_tol: float = 1e-9,
) -> set[int]:
    """Extract PHI indices that the discoverer marked as *exact* involutions.

    An exact involution (``residual ≤ residual_tol``) provably squares to
    the identity at numerical precision — a true order-2 group element.
    Near-involutions (residual > 0) freely generate composition chains
    that don't close into a finite group within the same precision, so
    they're excluded to keep the closure tractable.

    The residual is read from each law's persisted ψ-cell payload
    (``Cell.value = [residual, trials]`` — see ``soilith_discover.Law``).
    """
    a = Arena.open(arena_path)
    indices: set[int] = set()
    for slot, cell in a.items():
        body = slot[len("law/"):] if slot.startswith("law/") else slot
        if not body.endswith("_involution"):
            continue
        try:
            residual = float(np.asarray(cell.value).ravel()[0])
        except Exception:
            continue
        if residual > residual_tol:
            continue
        for tok in body.split("_"):
            if tok.isdigit():
                indices.add(int(tok))
    return indices


def from_lawbook(arena_path: Path, samples: list[np.ndarray],
                 *, residual_tol: float = 1e-9) -> CayleyGraph:
    """Build the group whose elements are the *exact* involutions named in
    the lawbook at ``arena_path``."""
    ks = sorted(_operator_indices_from_lawbook(arena_path, residual_tol=residual_tol))
    ops: dict[str, Operator] = {f"phi_{k}": PHI[k] for k in ks if k in PHI}
    return build_group(ops, samples)


# ──────────────────────────────────────────────────────────────────────────
#  Persistence — a topology cell back into a Σoilith arena
# ──────────────────────────────────────────────────────────────────────────
def persist_topology(arena_path: Path, slot: str, graph: CayleyGraph,
                     trust: float = 1.0) -> None:
    """Materialize a topology summary as a ψ-cell at ``topology/<slot>``.

    The cell encodes ``[order, V, E, F, χ_1, χ_2]`` so refinement-typed gates
    can adopt or doubt the invariant alongside the other discoveries.
    """
    a = Arena.open(arena_path, autoflush=False)
    a[f"topology/{slot}"] = Cell(
        value=np.array([graph.order, graph.V, graph.E, graph.F,
                        graph.euler_1, graph.euler_2], dtype=float),
        trust=float(trust),
        phase=0.0,
    )
    a.flush()


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_samples(seed: int, dim: int, trials: int) -> list[np.ndarray]:
    rng = np.random.default_rng(seed)
    out = []
    for _ in range(trials):
        kind = int(rng.integers(0, 4))
        if kind == 0:
            x = rng.standard_normal(dim) * 0.3
        elif kind == 1:
            x = rng.uniform(-0.5, 0.5, dim)
        elif kind == 2:
            t = np.linspace(0.0, 2.0 * np.pi, dim)
            x = np.sin(t + rng.uniform(0.0, 2.0 * np.pi)) * 0.5
        else:
            x = np.full(dim, float(rng.uniform(-0.3, 0.3)))
        out.append(np.asarray(x, dtype=np.float64))
    return out


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith topological self-knowledge (Zone 117).")
    p.add_argument("--lawbook", type=Path, default=Path("lawbook.arena"),
                   help="lawbook arena to probe (default lawbook.arena).")
    p.add_argument("--save-to", type=Path, default=None,
                   help="optional arena to persist the topology cell into.")
    p.add_argument("--slot", default="lawbook",
                   help="slot name for the persisted topology cell (default 'lawbook').")
    p.add_argument("--dim", type=int, default=16)
    p.add_argument("--trials", type=int, default=12)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args(argv)

    samples = _default_samples(args.seed, args.dim, args.trials)
    if not args.lawbook.exists():
        print(f"# no lawbook at {args.lawbook} — run soilith_discover.py first.")
        return 1

    graph = from_lawbook(args.lawbook, samples)
    print(graph.describe())

    if args.save_to is not None:
        persist_topology(args.save_to, args.slot, graph)
        print(f"# persisted χ cell → {args.save_to} :: topology/{args.slot}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
