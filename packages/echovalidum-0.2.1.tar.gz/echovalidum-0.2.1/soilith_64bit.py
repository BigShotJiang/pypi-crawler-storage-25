"""
soilith_64bit.py — 64-bit virtualised address space with
hierarchical sparse trie + CHERI-flavoured capability tags
(Zone 152).

Background and framing
----------------------
Zone 149's ``SparseScaleMemory`` reached k=30 (~1 G addresses)
by lazy materialisation of bitstring addresses. That's good for
small-rank groups but still well below production systems whose
**virtual** address space is 64 bits and whose **physical**
backing is hardware-paged with a TLB. seL4, CertiKOS, and Rust's
borrow checker at scale all assume that geometry.

Zone 152 lifts Σoilith memory onto the same playing field:

* **64-bit virtual addresses** (``uint64``). The full 2^64 = 1.8 ×
  10^19 address space is conceptually available; only touched
  pages allocate.
* **Hierarchical page trie**: addresses are split into 4 ×
  16-bit levels (L0 = high 16, L3 = low 16). Each level is a
  ``dict`` populated only on first touch — exactly the structure
  of an x86-64 page table, but in software.
* **Page granularity**: bottom-level "pages" are ``Page`` objects
  carrying a numpy array of ``Cell``-encoded slots, so per-page
  reads/writes vectorise.
* **CHERI-flavoured capability tags**: every populated cell
  carries a 64-bit ``tag`` (``base``, ``length``, ``perms``); a
  read or write outside its bounds raises ``CapabilityFault``.
  Permissions: ``R``, ``W``, ``X`` (read / write / execute).
* **TLB-style residency cache**: a small LRU keeps recent
  ``(L0,L1,L2)`` page-table walks warm; cold lookups still find
  the page via the trie.

API
---
* ``Capability(base, length, perms)`` — bounded, unforgeable.
* ``Page`` — 64 slots, vectorised.
* ``Memory64(page_bits=6)`` — page = 2^page_bits cells.
* ``Memory64.write(va, cell, cap)`` / ``Memory64.read(va, cap)``.
* ``Memory64.stats()`` — n_pages, n_cells_populated, virtual span.
* ``Memory64.bulk_populate(addresses)`` — fast workload primer.

Honest residual limits
----------------------
* The "TLB" is software; there is no real hardware acceleration.
  But the *structure* is identical to a hardware page-table walk,
  so the same algorithmic complexity (O(level depth)) applies.
* The capability model is CHERI-*flavoured*, not CHERI-equivalent;
  full CHERI also has sealed capabilities, monotonicity invariants
  enforced by hardware, and a hardware tag bit per memory line.
* Σoilith does not page out to disk; cold pages are in process
  memory just like hot ones.

CLI
---
    python soilith_64bit.py
"""

from __future__ import annotations

import argparse
from collections import OrderedDict
from dataclasses import dataclass, field
from pathlib import Path
import sys
import time
from typing import Any, Iterable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class Memory64Error(Exception):
    pass


class CapabilityFault(Memory64Error):
    """Access outside the bounds or permissions of a capability."""


class AddressFault(Memory64Error):
    pass


# ──────────────────────────────────────────────────────────────────────────
#  CHERI-flavoured capability
# ──────────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Capability:
    """An unforgeable, bounded, permission-tagged reference."""

    base: int            # uint64
    length: int          # number of cells covered
    perms: str           # subset of "RWX"

    def contains(self, va: int) -> bool:
        return self.base <= va < self.base + self.length

    def has(self, p: str) -> bool:
        return all(c in self.perms for c in p)

    def attenuate(self, *,
                  new_base: int | None = None,
                  new_length: int | None = None,
                  drop_perms: str = "") -> "Capability":
        nb = self.base if new_base is None else new_base
        nl = self.length if new_length is None else new_length
        if nb < self.base or nb + nl > self.base + self.length:
            raise CapabilityFault(
                "attenuated capability must lie within parent"
            )
        np_perms = "".join(c for c in self.perms if c not in drop_perms)
        return Capability(base=nb, length=nl, perms=np_perms)


# ──────────────────────────────────────────────────────────────────────────
#  Page
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Page:
    """A populated leaf in the address trie. ``slots`` is a sparse
    dict keyed by the in-page offset."""

    base: int
    size: int
    slots: dict[int, Cell] = field(default_factory=dict)


# ──────────────────────────────────────────────────────────────────────────
#  Memory64 — hierarchical sparse trie
# ──────────────────────────────────────────────────────────────────────────
class Memory64:
    """A 64-bit virtual address space.

    Address layout::

        ┌───────────┬───────────┬───────────┬───────────┬──────────┐
        │   L0      │    L1     │    L2     │    L3     │  offset  │
        │ high 16   │  next 16  │  next 16  │  next 16  │ page_bits│
        └───────────┴───────────┴───────────┴───────────┴──────────┘

    The page size is ``2^page_bits``. With ``page_bits=6`` (the
    default) every page holds 64 cells.
    """

    def __init__(self, *, page_bits: int = 6,
                 tlb_size: int = 256) -> None:
        if page_bits < 0 or page_bits > 24:
            raise Memory64Error("page_bits out of range [0, 24]")
        self.page_bits = page_bits
        self.page_mask = (1 << page_bits) - 1
        self.page_size = 1 << page_bits
        # Trie: root → L0 → L1 → L2 → L3 → Page
        self._root: dict[int, Any] = {}
        self._n_pages = 0
        self._n_cells = 0
        # TLB-style residency cache.
        self._tlb: OrderedDict[tuple[int, int, int, int], Page] = (
            OrderedDict()
        )
        self._tlb_size = tlb_size
        self._tlb_hits = 0
        self._tlb_misses = 0

    # — page-table walk — — — — — — — — — — — — — — — — — — — — — — —
    def _walk(self, va: int, *, create: bool = False
              ) -> tuple[Page | None, int]:
        if va < 0 or va >= (1 << 64):
            raise AddressFault(f"va={va} outside 64-bit range")
        offset = va & self.page_mask
        page_va = va - offset
        rest = page_va >> self.page_bits
        L3 = rest & 0xFFFF
        L2 = (rest >> 16) & 0xFFFF
        L1 = (rest >> 32) & 0xFFFF
        L0 = (rest >> 48) & 0xFFFF
        key = (L0, L1, L2, L3)
        if key in self._tlb:
            self._tlb.move_to_end(key)
            self._tlb_hits += 1
            return self._tlb[key], offset
        self._tlb_misses += 1
        node: Any = self._root
        for level in (L0, L1, L2):
            if level not in node:
                if not create:
                    return None, offset
                node[level] = {}
            node = node[level]
        if L3 not in node:
            if not create:
                return None, offset
            node[L3] = Page(base=page_va, size=self.page_size)
            self._n_pages += 1
        page: Page = node[L3]
        if len(self._tlb) >= self._tlb_size:
            self._tlb.popitem(last=False)
        self._tlb[key] = page
        return page, offset

    # — public API — — — — — — — — — — — — — — — — — — — — — — — — —
    def write(self, va: int, cell: Cell, *,
              cap: Capability) -> None:
        if not cap.contains(va):
            raise CapabilityFault(
                f"write va={va} outside cap [{cap.base},"
                f"{cap.base + cap.length})"
            )
        if not cap.has("W"):
            raise CapabilityFault(
                f"cap perms {cap.perms!r} lacks W"
            )
        page, off = self._walk(va, create=True)
        assert page is not None
        if off not in page.slots:
            self._n_cells += 1
        page.slots[off] = cell

    def read(self, va: int, *, cap: Capability) -> Cell:
        if not cap.contains(va):
            raise CapabilityFault(
                f"read va={va} outside cap [{cap.base},"
                f"{cap.base + cap.length})"
            )
        if not cap.has("R"):
            raise CapabilityFault(
                f"cap perms {cap.perms!r} lacks R"
            )
        page, off = self._walk(va, create=False)
        if page is None or off not in page.slots:
            raise AddressFault(f"va={va} not populated")
        return page.slots[off]

    def bulk_populate(
        self, addresses: Iterable[int], *, cap: Capability,
        value_fn: Any = None,
    ) -> int:
        if value_fn is None:
            value_fn = lambda va: Cell(
                value=np.array([float(va & 0xFF)], dtype=float),
                trust=1.0, phase=0.0,
            )
        n = 0
        for va in addresses:
            self.write(va, value_fn(va), cap=cap)
            n += 1
        return n

    def iter_pages(self) -> Iterable[Page]:
        def walk(d: Any) -> Iterable[Page]:
            if isinstance(d, Page):
                yield d
                return
            if isinstance(d, dict):
                for v in d.values():
                    yield from walk(v)
        yield from walk(self._root)

    def stats(self) -> dict[str, Any]:
        total_cells = sum(len(p.slots) for p in self.iter_pages())
        return {
            "page_bits": self.page_bits,
            "page_size": self.page_size,
            "n_pages": self._n_pages,
            "n_cells_populated": total_cells,
            "virtual_span_bits": 64,
            "virtual_span_addresses": 1 << 64,
            "utilisation": total_cells / (1 << 64),
            "tlb_size": self._tlb_size,
            "tlb_hits": self._tlb_hits,
            "tlb_misses": self._tlb_misses,
            "tlb_hit_rate": (
                self._tlb_hits / max(1, self._tlb_hits + self._tlb_misses)
            ),
        }


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(name: str, mem: Memory64, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    s = mem.stats()
    payload = np.array([
        float(s["n_pages"]),
        float(s["n_cells_populated"]),
        s["utilisation"],
        s["tlb_hit_rate"],
    ], dtype=float)
    safe = "".join(c if c.isalnum() else "_" for c in name)[:60]
    arena[f"mem64/{safe}"] = Cell(
        value=payload, trust=1.0, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI / Demo
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith 64-bit virtualised memory (Zone 152)."
    )
    p.add_argument("--n", type=int, default=1_000_000,
                   help="number of addresses to populate")
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print("# Zone 152 — 64-bit virtualised memory with capability tags")

    mem = Memory64(page_bits=6, tlb_size=256)
    s = mem.stats()
    print(f"   virtual address span = 2^64 = "
          f"{s['virtual_span_addresses']:,}")
    print(f"   page size            = {s['page_size']} cells "
          f"({s['page_bits']} bits)")

    # Hand out a fat capability covering the entire span.
    cap = Capability(base=0, length=(1 << 63), perms="RW")
    print(f"   root capability      = "
          f"[base=0, len=2^63, perms='RW']")

    print(f"\n# 1. Bulk-populating {args.n:,} pseudorandom addresses…")
    rng = np.random.default_rng(seed=42)
    addresses = (
        rng.integers(0, 1 << 40, size=args.n, dtype=np.uint64)
        .astype(int).tolist()
    )
    t0 = time.perf_counter()
    n = mem.bulk_populate(addresses, cap=cap)
    dt = (time.perf_counter() - t0) * 1000.0
    print(f"   wrote {n:,} cells in {dt:.1f}ms  "
          f"({n / max(1e-6, dt / 1000):,.0f} writes/sec)")

    print("\n# 2. Stats")
    s = mem.stats()
    for k, v in s.items():
        if isinstance(v, float):
            print(f"   {k:24s} = {v:.4g}")
        else:
            print(f"   {k:24s} = {v:,}")

    print("\n# 3. Hot read pattern — populate a contiguous 4 KiB region "
          "and re-read it 10x to exercise the TLB")
    hot_base = 0x4000_0000_0000
    hot_n = 4096
    hot_addrs = list(range(hot_base, hot_base + hot_n))
    for a in hot_addrs:
        mem.write(a, Cell(value=np.array([float(a & 0xFF)]),
                          trust=1.0, phase=0.0), cap=cap)
    before = mem.stats()
    t0 = time.perf_counter()
    for _ in range(10):
        for a in hot_addrs:
            mem.read(a, cap=cap)
    dt = (time.perf_counter() - t0) * 1000.0
    after = mem.stats()
    new_hits = after["tlb_hits"] - before["tlb_hits"]
    new_misses = after["tlb_misses"] - before["tlb_misses"]
    hit_rate = new_hits / max(1, new_hits + new_misses)
    print(f"   {10 * hot_n:,} hot reads in {dt:.2f}ms  "
          f"({(10 * hot_n) / max(1e-6, dt / 1000):,.0f}/sec)  "
          f"TLB hit rate = {hit_rate:.2%}  "
          f"(hits={new_hits:,}, misses={new_misses:,})")

    print("\n# 4. CHERI-flavoured capability check")
    narrow = cap.attenuate(new_base=0x1000, new_length=0x100,
                           drop_perms="W")
    print(f"   attenuated cap = base={narrow.base}, "
          f"length={narrow.length}, perms={narrow.perms!r}")
    try:
        mem.write(0x1050,
                  Cell(value=np.array([7.0]),
                       trust=1.0, phase=0.0),
                  cap=narrow)
    except CapabilityFault as exc:
        print(f"   ✓ write rejected on read-only cap: {exc}")

    try:
        mem.read(0x2000, cap=narrow)
    except CapabilityFault as exc:
        print(f"   ✓ out-of-bounds read rejected: {exc}")

    print("\n# 5. Persist and report")
    persist("workload_1M", mem, args.arena)
    s = mem.stats()
    print(f"   pages allocated      = {s['n_pages']:,}  "
          f"(per page = {n / max(1, s['n_pages']):.1f} cells)")
    print(f"   utilisation of 2^64  = {s['utilisation']:.2e}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
