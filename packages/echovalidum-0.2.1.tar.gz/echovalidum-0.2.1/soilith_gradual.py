"""
soilith_gradual.py — gradual typing with first-class blame
(Zone 141).

Reticulated Python, Typed Racket, and the Gradual Typing Soundness
program track *blame*: when a value flows across a boundary between
typed and untyped code and later violates a type, the boundary that
admitted it is at fault. Σoilith already carries the perfect blame
substrate on every value — ``trust`` — and Zone 141 turns it into a
first-class gradual type system.

API
---
* ``GradualType`` is one of:
    - ``GradualType.dynamic()``      — the ``?`` / ``Any`` type;
    - ``GradualType.shape(n)``       — a 1-D vector of length n;
    - ``GradualType.trust_at(τ)``    — refinement ``ψ{trust ≥ τ}``;
    - ``GradualType.intersect(t1,t2)``  — meet of two types.

* ``Boundary(name, expects, requires)`` is a labelled translation
  between two gradual types. ``Boundary.cast(cell)`` returns either
  the cell (passed) or raises ``BlameError(label, party)``.

* ``Blame(party, contract, reason)`` is a frozen record. ``party``
  is ``"positive"`` (the value side) or ``"negative"`` (the
  consumer / boundary side).

Higher-order coercions follow the classic Findler–Felleisen rule:
domain blame is **flipped** (the *caller* is now negative for what
it passes in), codomain blame is preserved. ``Boundary.arrow(...)``
implements that.

CLI
---
    python soilith_gradual.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any, Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors and blame
# ──────────────────────────────────────────────────────────────────────────
class GradualError(Exception):
    pass


@dataclass(frozen=True)
class Blame:
    party: str                 # "positive" or "negative"
    contract: str              # name of the boundary that detected
    reason: str

    def flip(self) -> "Blame":
        other = "negative" if self.party == "positive" else "positive"
        return Blame(party=other, contract=self.contract,
                     reason=self.reason)


class BlameError(GradualError):
    def __init__(self, blame: Blame) -> None:
        super().__init__(
            f"BLAME on {blame.party} party of {blame.contract!r}: "
            f"{blame.reason}"
        )
        self.blame = blame


# ──────────────────────────────────────────────────────────────────────────
#  Gradual types
# ──────────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class GradualType:
    """A small ad-hoc gradual type lattice."""
    kind: str
    shape: int | None = None
    min_trust: float | None = None
    components: tuple["GradualType", ...] = ()

    @classmethod
    def dynamic(cls) -> "GradualType":
        return cls(kind="dynamic")

    @classmethod
    def shape_of(cls, n: int) -> "GradualType":
        return cls(kind="shape", shape=n)

    @classmethod
    def trust_at(cls, tau: float) -> "GradualType":
        return cls(kind="trust", min_trust=float(tau))

    @classmethod
    def intersect(cls, a: "GradualType", b: "GradualType") -> "GradualType":
        return cls(kind="meet", components=(a, b))

    def consistent_with(self, other: "GradualType") -> bool:
        """Wadler-style consistency: ``? ~ τ`` for any τ. Otherwise
        we descend structurally."""
        if self.kind == "dynamic" or other.kind == "dynamic":
            return True
        if self.kind == other.kind == "shape":
            return self.shape == other.shape
        if self.kind == other.kind == "trust":
            # Trust types are consistent if their thresholds overlap.
            return True
        if self.kind == "meet":
            return all(c.consistent_with(other) for c in self.components)
        if other.kind == "meet":
            return all(c.consistent_with(self) for c in other.components)
        return False

    def describe(self) -> str:
        if self.kind == "dynamic":
            return "?"
        if self.kind == "shape":
            return f"R^{self.shape}"
        if self.kind == "trust":
            return f"ψ{{trust ≥ {self.min_trust:.2f}}}"
        if self.kind == "meet":
            return " ∧ ".join(c.describe() for c in self.components)
        return f"<{self.kind}>"

    # The runtime check the boundary performs on the cell.
    def check(self, cell: Cell) -> tuple[bool, str]:
        if self.kind == "dynamic":
            return True, ""
        if self.kind == "shape":
            v = np.asarray(cell.value, dtype=float).ravel()
            if v.size != self.shape:
                return False, (
                    f"shape mismatch: expected R^{self.shape}, "
                    f"got R^{v.size}"
                )
            return True, ""
        if self.kind == "trust":
            if cell.trust + 1e-12 < self.min_trust:
                return False, (
                    f"trust {cell.trust:.3f} below threshold "
                    f"{self.min_trust:.3f}"
                )
            return True, ""
        if self.kind == "meet":
            for c in self.components:
                ok, msg = c.check(cell)
                if not ok:
                    return False, msg
            return True, ""
        return False, f"unknown gradual type kind {self.kind!r}"


# ──────────────────────────────────────────────────────────────────────────
#  Boundaries (casts)
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Boundary:
    name: str
    expects: GradualType                # the type the boundary's
                                        # "positive" (value) side
                                        # advertises
    requires: GradualType               # the type the "negative"
                                        # (consumer) side demands

    def cast(self, cell: Cell) -> Cell:
        if not self.expects.consistent_with(self.requires):
            raise BlameError(Blame(
                party="negative", contract=self.name,
                reason=(
                    f"types are inconsistent: "
                    f"{self.expects.describe()} ⊮ "
                    f"{self.requires.describe()}"
                ),
            ))
        ok, msg = self.requires.check(cell)
        if not ok:
            # The producer ("positive") gave a value that doesn't
            # satisfy what the consumer demanded.
            raise BlameError(Blame(
                party="positive", contract=self.name,
                reason=msg,
            ))
        return cell

    def arrow(
        self,
        domain: "Boundary",
        codomain: "Boundary",
    ) -> "ArrowBoundary":
        """Wrap a function in an arrow contract. Domain blame is
        flipped (the caller becomes negative for the arg it passes
        in); codomain blame is preserved."""
        return ArrowBoundary(
            name=self.name, domain=domain, codomain=codomain,
        )


@dataclass
class ArrowBoundary:
    name: str
    domain: Boundary
    codomain: Boundary

    def wrap(self, fn: Callable[[Cell], Cell]) -> Callable[[Cell], Cell]:
        def wrapped(arg: Cell) -> Cell:
            # Domain blame: a violation on the way in is the
            # *caller's* fault (negative position in the arrow type).
            try:
                checked_arg = self.domain.cast(arg)
            except BlameError as exc:
                raise BlameError(exc.blame.flip())
            result = fn(checked_arg)
            # Codomain blame: untouched.
            return self.codomain.cast(result)
        return wrapped


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class CastLog:
    passed: int = 0
    failed: int = 0
    blamed_positive: int = 0
    blamed_negative: int = 0

    def record(self, ok: bool, party: str | None = None) -> None:
        if ok:
            self.passed += 1
        else:
            self.failed += 1
            if party == "positive":
                self.blamed_positive += 1
            elif party == "negative":
                self.blamed_negative += 1


def persist(name: str, log: CastLog, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(log.passed), float(log.failed),
        float(log.blamed_positive), float(log.blamed_negative),
    ], dtype=float)
    trust = 1.0 if log.failed == 0 else 0.3
    safe = "".join(c if c.isalnum() else "_" for c in name)[:60]
    arena[f"gradual/{safe}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith gradual typing (Zone 141)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print("# Zone 141 — gradual typing with first-class blame")

    log = CastLog()

    print("\n# 1. dynamic ~ R^3 — consistent, value of correct shape passes")
    b = Boundary(name="shape3",
                 expects=GradualType.dynamic(),
                 requires=GradualType.shape_of(3))
    try:
        b.cast(Cell(value=np.array([1.0, 2.0, 3.0]),
                    trust=1.0, phase=0.0))
        print("   passed")
        log.record(ok=True)
    except BlameError as exc:
        print(f"   blamed: {exc}")
        log.record(ok=False, party=exc.blame.party)

    print("\n# 2. dynamic side gives wrong shape — positive blame")
    try:
        b.cast(Cell(value=np.array([1.0, 2.0]),
                    trust=1.0, phase=0.0))
        log.record(ok=True)
    except BlameError as exc:
        print(f"   ✓ {exc}")
        log.record(ok=False, party=exc.blame.party)

    print("\n# 3. Refinement contract: trust ≥ 0.85")
    b2 = Boundary(name="hi_trust",
                  expects=GradualType.dynamic(),
                  requires=GradualType.trust_at(0.85))
    try:
        b2.cast(Cell(value=np.array([1.0]), trust=0.5, phase=0.0))
        log.record(ok=True)
    except BlameError as exc:
        print(f"   ✓ {exc}")
        log.record(ok=False, party=exc.blame.party)

    print("\n# 4. Higher-order: arrow contract flips domain blame")
    in_b = Boundary(name="arg_shape", expects=GradualType.dynamic(),
                    requires=GradualType.shape_of(2))
    out_b = Boundary(name="ret_shape", expects=GradualType.shape_of(2),
                     requires=GradualType.shape_of(2))
    arrow = Boundary(name="fn", expects=GradualType.dynamic(),
                     requires=GradualType.dynamic()
                     ).arrow(domain=in_b, codomain=out_b)
    fn = arrow.wrap(lambda c: c)
    try:
        # Caller passes a shape-3 arg — that's *the caller's* fault.
        fn(Cell(value=np.array([1.0, 2.0, 3.0]), trust=1.0, phase=0.0))
    except BlameError as exc:
        print(f"   ✓ arrow domain blame flipped → "
              f"{exc.blame.party}/{exc.blame.contract}")
        log.record(ok=False, party=exc.blame.party)

    print("\n# 5. Persist")
    persist("demo", log, args.arena)
    print(f"   log: passed={log.passed}, failed={log.failed}, "
          f"+blame={log.blamed_positive}, -blame={log.blamed_negative}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
