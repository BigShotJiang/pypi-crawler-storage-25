"""
soilith_region.py — region-based memory management (Zone 140).

Region-based memory (Tofte & Talpin '94, MLKit, Cyclone) replaces
the heap with named **regions** that have explicit lifetimes:
allocate-in-region, deallocate-region-all-at-once, statically
verify that no value escapes its region.

Σoilith already has a natural notion of region: a magnitude
capsule (a ψ-arena keyed on (ℤ/2)^k addresses, or on ℤ/n × ℤ/2
addresses) is exactly a finite, group-indexed memory bank. Zone
140 makes this explicit by introducing:

* ``Region`` — a named container with its own backing store and a
  ``lifetime`` (an integer that counts up at every ``free`` and
  fences accesses through stale handles).
* ``RegionHandle`` — a tuple ``(region_name, slot, born_at)`` that
  rebinds to the same Cell across a region's lifetime but becomes
  *invalid* once the region is freed.
* ``RegionManager`` — owns the regions, tracks lifetimes, performs
  escape analysis.

The escape check is empirical: every handle returned from a
region-scoped block must either be wrapped in a region that
outlives the inner one, or it must point into a copy that lives
elsewhere. Returning a raw inner handle is rejected at
``escape_check``.

API
---
    mgr = RegionManager()
    mgr.open("outer")
    mgr.open("inner")
    mgr.write("inner", "x", cell)
    h = mgr.handle("inner", "x")
    mgr.escape_check(h, scope="outer")    # rejects: inner ⊂ outer
    mgr.free("inner")
    mgr.access(h)                          # raises StaleHandle

Persistence
-----------
``region/<name>/lifetime``: a 4-float payload
``[lifetime, n_allocations, n_frees, alive]``.

CLI
---
    python soilith_region.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class RegionError(Exception):
    """Base class for Zone 140 errors."""


class StaleHandle(RegionError):
    """The handle's region was freed or the lifetime advanced past
    the handle's ``born_at``."""


class EscapeViolation(RegionError):
    """A handle from a shorter-lived region tried to escape to a
    longer-lived (or unrelated) scope."""


class UnknownRegion(RegionError):
    pass


# ──────────────────────────────────────────────────────────────────────────
#  Region + handle
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Region:
    name: str
    parent: str | None = None
    lifetime: int = 0           # incremented on free
    store: dict[str, Cell] = field(default_factory=dict)
    n_alloc: int = 0
    n_free: int = 0
    alive: bool = True

    def alloc(self, slot: str, cell: Cell) -> None:
        self.store[slot] = cell
        self.n_alloc += 1

    def get(self, slot: str) -> Cell:
        return self.store[slot]

    def free_all(self) -> int:
        n = len(self.store)
        self.store.clear()
        self.lifetime += 1
        self.n_free += 1
        self.alive = False
        return n


@dataclass(frozen=True)
class RegionHandle:
    region: str
    slot: str
    born_at: int


# ──────────────────────────────────────────────────────────────────────────
#  Region manager
# ──────────────────────────────────────────────────────────────────────────
class RegionManager:
    """Owns a forest of regions with parent/child lifetime nesting.
    A region's ``parent`` outlives it. ``escape_check(h, scope)``
    asserts h's region outlives ``scope`` (so the handle is safe
    to return up to ``scope``)."""

    def __init__(self) -> None:
        self._regions: dict[str, Region] = {}
        self._open_stack: list[str] = []

    def open(self, name: str, *, parent: str | None = None) -> None:
        if name in self._regions and self._regions[name].alive:
            raise RegionError(f"region {name!r} already open")
        if parent is None and self._open_stack:
            parent = self._open_stack[-1]
        self._regions[name] = Region(name=name, parent=parent, lifetime=0)
        self._open_stack.append(name)

    def free(self, name: str) -> int:
        reg = self._regions.get(name)
        if reg is None:
            raise UnknownRegion(f"unknown region {name!r}")
        if not reg.alive:
            raise RegionError(f"region {name!r} is already freed")
        n = reg.free_all()
        if self._open_stack and self._open_stack[-1] == name:
            self._open_stack.pop()
        else:
            try:
                self._open_stack.remove(name)
            except ValueError:
                pass
        return n

    def write(self, region: str, slot: str, cell: Cell) -> RegionHandle:
        reg = self._regions.get(region)
        if reg is None or not reg.alive:
            raise UnknownRegion(f"region {region!r} not open")
        reg.alloc(slot, cell)
        return RegionHandle(region=region, slot=slot, born_at=reg.lifetime)

    def handle(self, region: str, slot: str) -> RegionHandle:
        reg = self._regions[region]
        return RegionHandle(region=region, slot=slot, born_at=reg.lifetime)

    def access(self, h: RegionHandle) -> Cell:
        reg = self._regions.get(h.region)
        if reg is None or not reg.alive:
            raise StaleHandle(
                f"handle to {h.region!r} is stale (region freed)"
            )
        if h.born_at != reg.lifetime:
            raise StaleHandle(
                f"handle born_at={h.born_at}, region now at "
                f"lifetime={reg.lifetime}"
            )
        if h.slot not in reg.store:
            raise StaleHandle(
                f"slot {h.slot!r} no longer in region {h.region!r}"
            )
        return reg.get(h.slot)

    def _ancestors(self, name: str) -> list[str]:
        out, cur = [], name
        while cur is not None:
            out.append(cur)
            reg = self._regions.get(cur)
            cur = reg.parent if reg is not None else None
        return out

    def escape_check(self, h: RegionHandle, *, scope: str) -> None:
        """Allow a handle to ``h`` to be returned out to ``scope``
        iff ``h.region`` is an ancestor of (i.e. outlives) ``scope``,
        or is equal to it. In the inner⊂outer case ``scope`` is the
        outer one and ``h.region`` is the inner — so this **rejects**
        attempts to leak inner handles upward."""
        if h.region not in self._regions:
            raise EscapeViolation(
                f"handle's region {h.region!r} is unknown"
            )
        if scope not in self._regions:
            raise EscapeViolation(f"scope {scope!r} is unknown")
        if h.region == scope:
            return
        ancestors_of_scope = self._ancestors(scope)
        # If scope is an ancestor of h.region → h is inner, leaking outward.
        if h.region in ancestors_of_scope:
            return                                       # outer-to-inner OK
        ancestors_of_h = self._ancestors(h.region)
        if scope in ancestors_of_h:
            raise EscapeViolation(
                f"handle in inner region {h.region!r} would escape to "
                f"longer-lived scope {scope!r}"
            )
        raise EscapeViolation(
            f"regions {h.region!r} and {scope!r} are unrelated"
        )

    def lifetimes(self) -> dict[str, int]:
        return {n: r.lifetime for n, r in self._regions.items()}

    def stats(self, name: str) -> dict[str, int]:
        r = self._regions[name]
        return {
            "lifetime": r.lifetime,
            "alloc": r.n_alloc,
            "free": r.n_free,
            "alive": 1 if r.alive else 0,
        }


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(manager: RegionManager, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    for name, reg in manager._regions.items():
        payload = np.array([
            float(reg.lifetime),
            float(reg.n_alloc),
            float(reg.n_free),
            1.0 if reg.alive else 0.0,
        ], dtype=float)
        safe = "".join(c if c.isalnum() else "_" for c in name)[:60]
        arena[f"region/{safe}/lifetime"] = Cell(
            value=payload, trust=1.0, phase=0.0,
        )


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith region-based memory (Zone 140)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print("# Zone 140 — region-based memory management")
    mgr = RegionManager()

    print("\n# 1. Open nested regions outer ⊃ inner")
    mgr.open("outer")
    mgr.open("inner", parent="outer")
    print(f"   regions: {list(mgr._regions)}")

    print("\n# 2. Allocate in 'inner' and grab a handle")
    h_inner = mgr.write(
        "inner", "scratch",
        Cell(value=np.array([1.0, 2.0, 3.0]), trust=1.0, phase=0.0),
    )
    print(f"   wrote inner.scratch, handle = {h_inner}")
    print(f"   access OK: {mgr.access(h_inner).value}")

    print("\n# 3. Reject escape of inner handle to outer scope")
    try:
        mgr.escape_check(h_inner, scope="outer")
    except EscapeViolation as exc:
        print(f"   ✓ {type(exc).__name__}: {exc}")

    print("\n# 4. Free 'inner' — handles become stale")
    n = mgr.free("inner")
    print(f"   freed inner, dropped {n} cells")
    try:
        mgr.access(h_inner)
    except StaleHandle as exc:
        print(f"   ✓ {type(exc).__name__}: {exc}")

    print("\n# 5. Outer region survives, can still be used")
    h_outer = mgr.write(
        "outer", "result",
        Cell(value=np.array([42.0]), trust=1.0, phase=0.0),
    )
    print(f"   outer.result = {mgr.access(h_outer).value}")
    print(f"   lifetimes: {mgr.lifetimes()}")
    print(f"   outer stats: {mgr.stats('outer')}")

    persist(mgr, args.arena)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
