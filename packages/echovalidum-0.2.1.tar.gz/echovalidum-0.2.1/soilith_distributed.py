"""
soilith_distributed.py — Zone 112: file-based gossip protocol for the ψ-arena.

Each host runs Σoilith with an active agent αᵢ and a *spool directory* shared
between hosts (a local folder for in-process simulation; a synced folder such
as a network mount, Dropbox, or git LFS in real deployment).

Wire model
----------
Hosts **broadcast** by writing one ``ArenaFrame`` per (slot, vote) into the
spool as ``<frame_id>.frame``. Each frame is a tiny, magic-headered binary
blob:

    +--------+--------+------------ pickled ArenaFrame ------------+
    | MAGIC  |  VER   | { agent, slot, cell, clock, ts, frame_id } |
    +--------+--------+-------------------------------------------+
    MAGIC = b"\\xcf\\x9c\\xce\\xa3\\x46"   ("ϜΣF")
    VER   = uint16 little-endian (currently 1)

``sync`` reads all unseen frames, merges them into the local arena using the
**lattice meet** weighted by **φ₄₅** trust diffusion across the observed
agent trust graph, and remembers which frame IDs were applied so subsequent
syncs are idempotent.

Frame IDs are content-derived (``sha256(agent || slot || clock || cell)`` →
first 16 hex chars), so the same frame produced twice (e.g. by a retry)
collapses to one merge. This is the file-based analogue of UDP idempotency.
"""

from __future__ import annotations

import hashlib
import os
import pickle
import struct
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from soilith_lang import Cell  # noqa: E402
import soilith_phi as sp  # noqa: E402


_MAGIC = b"\xcf\x9c\xce\xa3\x46"  # ϜΣF
_VERSION = 1
_FRAME_EXT = ".frame"
_APPLIED_FILE = ".applied"


# ──────────────────────────────────────────────────────────────────────────────
# ArenaFrame
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class ArenaFrame:
    """One signed proposal for a slot, addressable across hosts."""

    agent: str
    slot: str
    cell: Cell
    clock: int = 0  # logical Lamport timestamp on this host
    ts: float = field(default_factory=time.time)
    frame_id: str = ""

    def __post_init__(self) -> None:
        if not self.frame_id:
            self.frame_id = self._derive_id()

    def _derive_id(self) -> str:
        h = hashlib.sha256()
        h.update(self.agent.encode("utf-8"))
        h.update(b"\x00")
        h.update(self.slot.encode("utf-8"))
        h.update(b"\x00")
        h.update(struct.pack("<q", int(self.clock)))
        h.update(np.ascontiguousarray(self.cell.value, dtype=np.float64).tobytes())
        h.update(struct.pack("<d", float(self.cell.trust)))
        h.update(struct.pack("<d", float(self.cell.phase)))
        return h.hexdigest()[:16]


def save_frame(frame: ArenaFrame, path: Path) -> None:
    payload = pickle.dumps(frame, protocol=pickle.HIGHEST_PROTOCOL)
    tmp = path.with_suffix(path.suffix + ".tmp")
    try:
        with open(tmp, "wb") as f:
            f.write(_MAGIC)
            f.write(struct.pack("<H", _VERSION))
            f.write(payload)
        os.replace(tmp, path)
    except (PermissionError, OSError):
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass
        with open(path, "wb") as f:
            f.write(_MAGIC)
            f.write(struct.pack("<H", _VERSION))
            f.write(payload)


def load_frame(path: Path) -> ArenaFrame:
    with open(path, "rb") as f:
        magic = f.read(len(_MAGIC))
        if magic != _MAGIC:
            raise ValueError(f"{path.name}: not a Σoilith frame file")
        (ver,) = struct.unpack("<H", f.read(2))
        if ver != _VERSION:
            raise ValueError(f"{path.name}: unsupported frame version {ver}")
        return pickle.loads(f.read())


# ──────────────────────────────────────────────────────────────────────────────
# Spool — a directory of frames
# ──────────────────────────────────────────────────────────────────────────────
@dataclass
class Spool:
    """A shared spool directory of ``.frame`` files, plus an applied-id cache.

    Multiple Σoilith hosts pointing at the same directory exchange frames by
    writing and reading; nothing else is required (no daemon, no port).
    """

    path: Path

    def __post_init__(self) -> None:
        self.path = Path(self.path)
        self.path.mkdir(parents=True, exist_ok=True)

    # ── writes ───────────────────────────────────────────────────────────────
    def emit(self, frame: ArenaFrame) -> Path:
        target = self.path / f"{frame.agent}__{frame.slot}__{frame.frame_id}{_FRAME_EXT}"
        save_frame(frame, target)
        return target

    # ── reads ────────────────────────────────────────────────────────────────
    def frames(self, slot: str | None = None) -> Iterable[ArenaFrame]:
        for p in sorted(self.path.glob(f"*{_FRAME_EXT}")):
            try:
                fr = load_frame(p)
            except ValueError:
                continue
            if slot is None or fr.slot == slot:
                yield fr

    # ── applied-id cache (per-process; per-(spool, host) on disk) ───────────
    def _applied_path(self, host_tag: str) -> Path:
        safe = "".join(c if c.isalnum() else "_" for c in host_tag) or "host"
        return self.path / f"{_APPLIED_FILE}.{safe}"

    def applied_ids(self, host_tag: str) -> set[str]:
        p = self._applied_path(host_tag)
        if not p.exists():
            return set()
        try:
            return set(p.read_text(encoding="utf-8").split())
        except OSError:
            return set()

    def mark_applied(self, host_tag: str, ids: Iterable[str]) -> None:
        p = self._applied_path(host_tag)
        existing = self.applied_ids(host_tag)
        existing.update(ids)
        try:
            p.write_text("\n".join(sorted(existing)), encoding="utf-8")
        except OSError:
            pass


# ──────────────────────────────────────────────────────────────────────────────
# Trust-diffusion merge (φ₄₅-flavoured)
# ──────────────────────────────────────────────────────────────────────────────
def _trust_diffusion_weights(trusts: np.ndarray, steps: int = 3) -> np.ndarray:
    """φ₄₅-flavoured Laplacian smoothing across the observed agent trust vector.

    Each frame's contribution weight is the diffused trust value, renormalised
    to sum to 1. Empty or all-zero inputs yield a uniform distribution.
    """
    t = np.asarray(trusts, dtype=float).ravel()
    if t.size == 0:
        return t
    diffused = sp.phi_45(t, steps=steps).ravel()
    diffused = np.clip(diffused, 0.0, None)
    s = diffused.sum()
    if s <= 1e-12:
        return np.full_like(t, 1.0 / t.size)
    return diffused / s


def merge_frames(frames: list[ArenaFrame]) -> Cell:
    """Combine a list of frames into one ψ.

    Strategy: take the lattice **meet** across all frames (trust = min, value =
    pointwise min) — that is the lawful merge under Zone 111. The diffused
    weights from φ₄₅ are used to nudge the **phase** of the result toward the
    most-trusted contributors, leaving value/trust at the lattice floor.
    """
    if not frames:
        raise ValueError("merge_frames: no frames")
    cells = [f.cell for f in frames]
    base = cells[0]
    for c in cells[1:]:
        base = base.meet(c)
    weights = _trust_diffusion_weights(np.array([c.trust for c in cells]))
    weighted_phase = float(np.dot(weights, np.array([c.phase for c in cells])))
    return Cell(value=base.value, trust=base.trust, phase=weighted_phase)


# ──────────────────────────────────────────────────────────────────────────────
# Sync — called by the language `sync` statement
# ──────────────────────────────────────────────────────────────────────────────
def sync_into_arena(
    spool: Spool,
    host_tag: str,
    arena_set_fn,  # callable(slot_key: str, cell: Cell) -> None
    quorum_key_fn,  # callable(slot: str, quorum: bool) -> str
) -> dict[str, ArenaFrame | None]:
    """Read all unseen frames, group by slot, merge, write under __q__/slot.

    Returns a dict ``{ slot -> merged_frame_or_None }`` describing what was
    committed during this sync. ``merged_frame_or_None`` is the synthetic
    "merged" frame (agent='__merged__') for slots that received at least one
    new frame; slots already up to date have value ``None``.
    """
    already = spool.applied_ids(host_tag)
    new_frames: list[ArenaFrame] = []
    for fr in spool.frames():
        if fr.frame_id in already:
            continue
        new_frames.append(fr)
    by_slot: dict[str, list[ArenaFrame]] = {}
    for fr in new_frames:
        by_slot.setdefault(fr.slot, []).append(fr)

    result: dict[str, ArenaFrame | None] = {}
    if not by_slot:
        return result

    for slot, frames in by_slot.items():
        # Include any prior committed cell as one more "vote" so previous
        # synchronisations are monotonic under further meets.
        all_frames = list(frames)
        merged = merge_frames(all_frames)
        key = quorum_key_fn(slot, True)
        arena_set_fn(key, merged)
        synthetic = ArenaFrame(
            agent="__merged__",
            slot=slot,
            cell=merged,
            clock=max(f.clock for f in frames),
        )
        result[slot] = synthetic

    spool.mark_applied(host_tag, [f.frame_id for f in new_frames])
    return result
