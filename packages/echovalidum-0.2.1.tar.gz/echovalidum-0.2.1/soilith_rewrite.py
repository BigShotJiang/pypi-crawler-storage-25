"""
soilith_rewrite.py — self-rewriting compiler pass driven by the lawbook (Zone 119).

When Σoilith has *proven* (Zone 116) that an operator composition equals a
simpler form, this module rewrites the AST to use the simpler form before
bytecode emission or interpretation. The rewriter only consults laws
whose persisted ψ-cell carries ``trust ≥ threshold`` (default 0.999), so
near-laws never become silent program transformations.

Rewrites currently supported
----------------------------
    involution:  phi(a, phi(a, x))      →  x
                 when "law/phi_<a>_involution" has trust ≥ θ
    identity  :  phi(a, phi(b, x))      →  x
                 when "law/phi_<a>_inverts_phi_<b>" has trust ≥ θ

Both rules are sound only at ``residual ≤ 1 − θ`` numerical precision;
the threshold is the single knob that trades aggressiveness against the
risk of changing observable output. The default 0.999 corresponds to a
maximum permitted residual of 1e-3.

Public API
----------
    RewriteTable.from_arena(path, threshold)       → table of (kind, ids) → "x"
    rewrite_program(stmts, table)                  → (new_stmts, n_rewrites)
    apply_rewrites_to_src(src, table, *, module)   → (new_src_ast, n_rewrites)

CLI
---
    python soilith_rewrite.py path/to/program.sol
    python soilith_rewrite.py --lawbook lawbook.arena --threshold 0.999 prog.sol

Prints the rewrite count and a `dis`-style summary of which patterns fired.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_arena import Arena  # noqa: E402
from soilith_lang import (  # noqa: E402
    BinOp, Call, Echo, ExprStmt, FnDef, Let, Norm, Phi, Print, TrustDef,
    Var, When, WithTrust, Yield, Parser, lex,
)


# ──────────────────────────────────────────────────────────────────────────
#  Rewrite table — loaded from a lawbook arena
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class RewriteTable:
    """Compiled set of safe rewrites distilled from a Σoilith lawbook."""

    involutions: set[int] = field(default_factory=set)        # {a : phi_a ∘ phi_a = id}
    identities: set[tuple[int, int]] = field(default_factory=set)  # {(a, b) : phi_a ∘ phi_b = id}
    threshold: float = 0.999
    source: str = ""

    @classmethod
    def from_arena(cls, path: Path | str, threshold: float = 0.999) -> "RewriteTable":
        """Read every ``law/*`` cell with ``trust ≥ threshold`` into a table.

        Residual is the first element of ``Cell.value`` (see
        ``soilith_discover.Law.as_cell``); we also require ``residual ≤
        1 − threshold`` as a belt-and-braces check, so a stale arena
        with inflated trust can't smuggle a noisy law in.
        """
        p = Path(path)
        if not p.exists():
            return cls(source=str(p))
        a = Arena.open(p, autoflush=False)
        max_resid = 1.0 - threshold
        involutions: set[int] = set()
        identities: set[tuple[int, int]] = set()
        for slot, cell in a.items():
            if not slot.startswith("law/"):
                continue
            if cell.trust < threshold - 1e-12:
                continue
            try:
                residual = float(np.asarray(cell.value).ravel()[0])
            except Exception:
                continue
            if residual > max_resid:
                continue
            body = slot[len("law/"):]
            if body.endswith("_involution"):
                k = _parse_index(body.replace("_involution", "").replace("phi_", ""))
                if k is not None:
                    involutions.add(k)
            elif "_inverts_phi_" in body:
                left, _, right = body.partition("_inverts_phi_")
                a_idx = _parse_index(left.replace("phi_", ""))
                b_idx = _parse_index(right)
                if a_idx is not None and b_idx is not None:
                    identities.add((a_idx, b_idx))
        return cls(
            involutions=involutions,
            identities=identities,
            threshold=threshold,
            source=str(p),
        )

    def __len__(self) -> int:
        return len(self.involutions) + len(self.identities)

    def describe(self) -> str:
        return (
            f"RewriteTable(source={self.source!r}, "
            f"threshold={self.threshold}, "
            f"involutions={sorted(self.involutions)}, "
            f"identities={sorted(self.identities)})"
        )


def _parse_index(tok: str) -> int | None:
    try:
        return int(tok)
    except ValueError:
        return None


# ──────────────────────────────────────────────────────────────────────────
#  Pattern matcher
# ──────────────────────────────────────────────────────────────────────────
def _is_simple_phi_call(node: Any) -> bool:
    """``phi(k, single_positional_arg)`` with no kwargs — the only shape we rewrite.

    Anything else (kwargs, varargs, missing argument) is left alone, because
    those forms commonly mean "phi with non-default knobs" and could behave
    differently from the law's reference implementation.
    """
    return (
        isinstance(node, Phi)
        and not node.kwargs
        and len(node.args) == 1
    )


@dataclass
class _RewriteStats:
    fires: Counter = field(default_factory=Counter)

    @property
    def total(self) -> int:
        return sum(self.fires.values())


def _rewrite_node(node: Any, table: RewriteTable, stats: _RewriteStats) -> Any:
    """Bottom-up rewrite: recurse first, then test outermost pattern."""
    if isinstance(node, Phi):
        new_args = [_rewrite_node(a, table, stats) for a in node.args]
        new_kwargs = {k: _rewrite_node(v, table, stats) for k, v in node.kwargs.items()}
        node = Phi(k=node.k, args=new_args, kwargs=new_kwargs)
        if _is_simple_phi_call(node) and _is_simple_phi_call(node.args[0]):
            outer_k = node.k
            inner = node.args[0]
            inner_k = inner.k
            payload = inner.args[0]
            if outer_k == inner_k and outer_k in table.involutions:
                stats.fires[("involution", outer_k)] += 1
                return _rewrite_node(payload, table, stats)
            if (outer_k, inner_k) in table.identities:
                stats.fires[("identity", (outer_k, inner_k))] += 1
                return _rewrite_node(payload, table, stats)
        return node
    if isinstance(node, BinOp):
        return BinOp(node.op,
                     _rewrite_node(node.left, table, stats),
                     _rewrite_node(node.right, table, stats))
    if isinstance(node, Norm):
        return Norm(_rewrite_node(node.expr, table, stats))
    if isinstance(node, WithTrust):
        return WithTrust(
            _rewrite_node(node.expr, table, stats),
            _rewrite_node(node.trust_expr, table, stats),
        )
    if isinstance(node, Call):
        return Call(
            node.name,
            [_rewrite_node(a, table, stats) for a in node.args],
            {k: _rewrite_node(v, table, stats) for k, v in node.kwargs.items()},
        )
    if isinstance(node, Let):
        return Let(node.name, _rewrite_node(node.expr, table, stats), node.refinement)
    if isinstance(node, TrustDef):
        return TrustDef(node.name, _rewrite_node(node.expr, table, stats))
    if isinstance(node, When):
        return When(
            _rewrite_node(node.cond, table, stats),
            [_rewrite_node(s, table, stats) for s in node.body],
        )
    if isinstance(node, Echo):
        return Echo(_rewrite_node(node.expr, table, stats), node.target)
    if isinstance(node, Yield):
        return Yield(_rewrite_node(node.expr, table, stats))
    if isinstance(node, Print):
        return Print(_rewrite_node(node.expr, table, stats))
    if isinstance(node, ExprStmt):
        return ExprStmt(_rewrite_node(node.expr, table, stats))
    if isinstance(node, FnDef):
        return FnDef(
            node.name,
            node.params,
            [_rewrite_node(s, table, stats) for s in node.body],
            node.refinement,
        )
    return node  # Var, TopE, BotE, Num, Import, ArenaOpen, Save, LoadE, GossipOpen, etc.


def rewrite_program(stmts: list[Any], table: RewriteTable) -> tuple[list[Any], _RewriteStats]:
    """Return ``(new_statements, stats)`` — input list is not mutated."""
    if len(table) == 0:
        return list(stmts), _RewriteStats()
    stats = _RewriteStats()
    new_stmts = [_rewrite_node(s, table, stats) for s in stmts]
    return new_stmts, stats


def rewrite_source(src: str, table: RewriteTable) -> tuple[list[Any], _RewriteStats]:
    """Parse → rewrite. Returns the rewritten AST and stats."""
    return rewrite_program(Parser(lex(src)).parse(), table)


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith self-rewriting compiler pass (Zone 119)."
    )
    p.add_argument("source", nargs="?", type=Path, help=".sol file to analyze.")
    p.add_argument("--lawbook", type=Path,
                   default=Path(__file__).resolve().parent / "lawbook.arena")
    p.add_argument("--threshold", type=float, default=0.999)
    args = p.parse_args(argv)

    table = RewriteTable.from_arena(args.lawbook, args.threshold)
    print(table.describe())

    if args.source is None:
        return 0

    src = args.source.read_text(encoding="utf-8")
    _, stats = rewrite_source(src, table)
    print(f"# rewrites fired: {stats.total}")
    for (kind, key), n in sorted(stats.fires.items()):
        if kind == "involution":
            print(f"#   involution φ_{key} ∘ φ_{key} → x      ({n}×)")
        else:
            a, b = key
            print(f"#   identity   φ_{a} ∘ φ_{b}  → x         ({n}×)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
