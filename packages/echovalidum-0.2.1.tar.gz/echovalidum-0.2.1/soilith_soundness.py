"""
soilith_soundness.py — mechanizable soundness witnesses
(Zone 147).

Honest framing
--------------
Σoilith does not (yet) ship a machine-checked Coq/Lean proof of
its frame rule, borrow rule, or non-interference theorem. What it
*can* do — and what real-world systems like Stainless, RustBelt,
and Verus already exploit — is **emit a structured derivation
witness** alongside each accepted judgment. A derivation lists the
inference rules used, the conclusions reached, and the premises
each rule discharged.

A derivation is **mechanizable** in the precise sense that:

* each rule name matches a standard inference rule (FRAME, SEP-
  CONJ, BORROW-MUT, NI-PRESERVATION, etc.);
* premises are themselves derivations (so the witness is a tree);
* conclusions are stringified judgments suitable for parsing by a
  proof-assistant front-end.

This module wraps the existing checkers (Zones 131, 134, 138, 145)
and produces ``Derivation`` objects when their judgments succeed.

API
---
* ``Derivation(rule, conclusion, premises)`` — a proof tree.
* ``frame_witness(commands, P, Q, memory)`` — witnesses the frame
  rule from Zone 131.
* ``borrow_witness(addresses, memory)`` — witnesses the
  Cayley-disjoint mutable-borrow rule from Zone 134.
* ``ni_witness(low_diff)`` — witnesses non-interference from
  Zone 138.
* ``abstract_witness(transfer, audit)`` — witnesses abstract
  soundness from Zone 145.
* ``export_coq(deriv)`` — renders the derivation as a Coq-friendly
  proof script skeleton.

CLI
---
    python soilith_soundness.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Derivation tree
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Derivation:
    """A single node in a proof-witness tree.

    Each node names an inference rule, states the conclusion as a
    string judgment, and lists premises (which are themselves
    Derivations). Leaves have ``premises=()`` and represent axioms
    or structural facts.
    """

    rule: str
    conclusion: str
    premises: tuple["Derivation", ...] = ()
    side_conditions: tuple[str, ...] = ()

    def depth(self) -> int:
        if not self.premises:
            return 1
        return 1 + max(p.depth() for p in self.premises)

    def size(self) -> int:
        return 1 + sum(p.size() for p in self.premises)

    def names(self) -> set[str]:
        out = {self.rule}
        for p in self.premises:
            out |= p.names()
        return out

    def render(self, indent: int = 0) -> str:
        pad = "  " * indent
        out = [f"{pad}[{self.rule}] {self.conclusion}"]
        for cond in self.side_conditions:
            out.append(f"{pad}    side: {cond}")
        for prem in self.premises:
            out.append(prem.render(indent + 1))
        return "\n".join(out)


# ──────────────────────────────────────────────────────────────────────────
#  Witness factories
# ──────────────────────────────────────────────────────────────────────────
def frame_witness(
    *, P_addrs: set[str], R_addrs: set[str], c_footprint: set[str],
) -> Derivation:
    """Frame rule (Reynolds 2002):

        {P} c {Q}    footprint(c) ⊆ dom(P)    footprint(c) ∩ R = ∅
        ──────────────────────────────────────────────────────────
                        {P * R} c {Q * R}

    We witness it from the footprint disjointness check that
    Zone 131 already performs."""
    disjoint = c_footprint.isdisjoint(R_addrs)
    if not disjoint:
        raise ValueError("cannot witness: footprint overlaps R")
    return Derivation(
        rule="FRAME",
        conclusion="{P * R} c {Q * R}",
        premises=(
            Derivation(rule="HOARE-TRIPLE",
                       conclusion="{P} c {Q}",
                       side_conditions=(
                           f"footprint(c) = {sorted(c_footprint)}",
                       )),
            Derivation(rule="DISJOINT-FOOTPRINTS",
                       conclusion=f"footprint(c) ∩ dom(R) = ∅",
                       side_conditions=(
                           f"dom(R) = {sorted(R_addrs)}",
                       )),
        ),
        side_conditions=("Reynolds 2002, §3.2",),
    )


def borrow_witness(
    *, addresses: list[str],
    neighborhoods: dict[str, set[str]],
) -> Derivation:
    """Mutable-borrow rule (Zone 134, Cayley-aware):

        ∀ a, b ∈ B, a ≠ b: N[a] ∩ N[b] = ∅
        ─────────────────────────────────────
              ⊢ concurrent_mut_borrows(B)
    """
    pairwise: list[Derivation] = []
    for i in range(len(addresses)):
        for j in range(i + 1, len(addresses)):
            a, b = addresses[i], addresses[j]
            na, nb = neighborhoods[a], neighborhoods[b]
            inter = na & nb
            if inter:
                raise ValueError(
                    f"cannot witness: N[{a}] ∩ N[{b}] = {sorted(inter)}"
                )
            pairwise.append(Derivation(
                rule="CAYLEY-DISJOINT",
                conclusion=f"N[{a}] ∩ N[{b}] = ∅",
                side_conditions=(
                    f"|N[{a}]|={len(na)}, |N[{b}]|={len(nb)}",
                ),
            ))
    return Derivation(
        rule="BORROW-MUT-PARALLEL",
        conclusion=(
            f"⊢ concurrent_mut_borrows({addresses})"
        ),
        premises=tuple(pairwise),
        side_conditions=(
            "Cayley-closed neighborhood discipline (Zone 134)",
        ),
    )


def ni_witness(
    *, low_diff: dict[str, tuple[float, float]],
    program_name: str,
) -> Derivation:
    """Non-interference (Zone 138). The judgment is only accepted
    when ``low_diff`` is empty (no observable disagreement on low
    outputs across two traces with same low / different high)."""
    if low_diff:
        raise ValueError(
            f"cannot witness NI: low-diff non-empty ({list(low_diff)})"
        )
    return Derivation(
        rule="NONINTERFERENCE",
        conclusion=(
            f"⊢ NI({program_name})  "
            "(no low-output disagreement)"
        ),
        premises=(
            Derivation(
                rule="TWO-TRACE-AGREEMENT",
                conclusion=(
                    "∀ slot ∈ Low. trace_a(slot) = trace_b(slot)"
                ),
                side_conditions=("checked empirically over both runs",),
            ),
        ),
        side_conditions=(
            "Goguen-Meseguer 1982; Sabelfeld-Myers 2003",
        ),
    )


def abstract_witness(
    *, op_index: int, transfer: dict[str, str],
    sound: int, unsound: int,
) -> Derivation:
    """Abstract-interpretation soundness (Zone 145).

    Per Cousot's framework, we want ``γ(φ_k(x)) ⊑ φ̃_k(γ(x))``.
    The hold-out audit is the (empirical) discharge.
    """
    if unsound > 0:
        raise ValueError(
            f"cannot witness AI-SOUND: {unsound} unsound predictions"
        )
    return Derivation(
        rule="AI-SOUND",
        conclusion=f"⊢ γ(φ_{op_index}(·)) ⊑ φ̃_{op_index}(γ(·))",
        premises=(
            Derivation(
                rule="TRANSFER-TABLE",
                conclusion=(
                    f"φ̃_{op_index} = {transfer}"
                ),
                side_conditions=("calibrated by Zone-145 probing",),
            ),
            Derivation(
                rule="EMPIRICAL-AUDIT",
                conclusion=(
                    f"audit: sound={sound} / unsound={unsound}"
                ),
                side_conditions=("hold-out, distinct RNG seed",),
            ),
        ),
        side_conditions=("Cousot & Cousot 1977, §3",),
    )


# ──────────────────────────────────────────────────────────────────────────
#  Export to a proof-assistant-friendly script
# ──────────────────────────────────────────────────────────────────────────
def export_coq(deriv: Derivation) -> str:
    """Render the derivation as a Coq proof-script skeleton."""
    lines: list[str] = []
    lines.append(f"(* Auto-generated by Σoilith Zone 147. *)")
    lines.append(f"Theorem auto_soilith_witness :")
    lines.append(f"  {deriv.conclusion}.")
    lines.append(f"Proof.")

    def walk(d: Derivation, indent: int) -> None:
        pad = "  " * (indent + 1)
        lines.append(f"{pad}(* rule: {d.rule} *)")
        for prem in d.premises:
            walk(prem, indent + 1)
        for cond in d.side_conditions:
            lines.append(f"{pad}(* side: {cond} *)")
        lines.append(f"{pad}apply {d.rule}.")

    walk(deriv, 0)
    lines.append(f"Qed.")
    return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(
    name: str, deriv: Derivation, arena_path: Path,
) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(deriv.depth()),
        float(deriv.size()),
        float(len(deriv.names())),
    ], dtype=float)
    safe = "".join(c if c.isalnum() else "_" for c in name)[:60]
    arena[f"soundness/{safe}"] = Cell(
        value=payload, trust=1.0, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI / Demo
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith mechanizable witnesses (Zone 147)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print("# Zone 147 — mechanizable soundness witnesses")

    print("\n# 1. Frame witness from Zone 131")
    d_frame = frame_witness(
        P_addrs={"000", "100"},
        R_addrs={"111"},
        c_footprint={"000", "100"},
    )
    print(d_frame.render())
    print(f"   depth={d_frame.depth()} size={d_frame.size()}")
    persist("frame_rule_demo", d_frame, args.arena)

    print("\n# 2. Borrow witness from Zone 134 (antipodes on Z/2^3)")
    nbhd = {
        "000": {"000", "001", "010", "100"},
        "111": {"111", "110", "101", "011"},
    }
    d_borrow = borrow_witness(
        addresses=["000", "111"], neighborhoods=nbhd,
    )
    print(d_borrow.render())
    persist("borrow_z2_3_antipodes", d_borrow, args.arena)

    print("\n# 3. NI witness from Zone 138 (clean program)")
    d_ni = ni_witness(low_diff={}, program_name="leakless_phi_38")
    print(d_ni.render())
    persist("ni_leakless", d_ni, args.arena)

    print("\n# 4. Abstract-interpretation witness from Zone 145")
    d_ai = abstract_witness(
        op_index=39,
        transfer={"-": "+", "0": "0", "+": "-", "⊤": "⊤"},
        sound=96, unsound=0,
    )
    print(d_ai.render())
    persist("ai_phi_39_signflip", d_ai, args.arena)

    print("\n# 5. Export #2 as a Coq script skeleton")
    coq = export_coq(d_borrow)
    print(coq)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
