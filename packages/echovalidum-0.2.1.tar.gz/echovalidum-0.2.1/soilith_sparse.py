"""
soilith_sparse.py — sparse, lazy scale-aware memory (Zone 149).

Honest framing
--------------
Zone 122's ``ScaleAwareMemory`` materialises every vertex of
``(ℤ/2)^k`` and every directed edge. That makes the global
χ-invariant cheap to verify and the algebra clean, but it does not
scale: for ``k = 16`` we'd materialise 65 536 vertices and several
hundred thousand edges; for ``k = 30`` we'd be at a billion
vertices, which is infeasible.

Real-world memory models (CHERI capabilities, WebAssembly's linear
memory, Rust's regions) work over enormous address spaces by
**lazy materialisation**: only the *touched* subset is concrete.
Zone 149 mirrors that for Σoilith:

* addresses are bitstrings of length up to ``k = 30``;
* ``_store`` carries only populated cells (no global list of all
  vertices);
* neighbourhoods are computed *on demand* via single-bit XOR;
* a **local audit** operates over a BFS ball of radius ``r`` around
  a seed — small, predictable, scalable;
* the **global χ-shape constraint is reported honestly** as
  "extrapolated from local samples" rather than measured exactly.

API
---
* ``SparseScaleMemory(k)`` for k up to 30.
* ``.write(addr, cell)`` / ``.read(addr)``.
* ``.neighbors(addr)`` — k bitflips, computed lazily.
* ``.populated_count`` and ``.theoretical_count``.
* ``.local_audit(seed, radius)`` — returns a ``LocalAuditReport``.
* ``.extrapolated_chi()`` — global χ heuristic from sample.

CLI
---
    python soilith_sparse.py
"""

from __future__ import annotations

import argparse
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
import random
import sys
from typing import Iterable, Iterator

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class SparseMemoryError(Exception):
    pass


# ──────────────────────────────────────────────────────────────────────────
#  Sparse memory
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class LocalAuditReport:
    seed: str
    radius: int
    n_vertices: int
    n_edges: int
    populated_in_ball: int
    chi_local: int

    def describe(self) -> str:
        return (
            f"LocalAuditReport seed={self.seed} r={self.radius}  "
            f"V={self.n_vertices} E={self.n_edges} "
            f"populated={self.populated_in_ball} "
            f"χ_local={self.chi_local}"
        )


class SparseScaleMemory:
    """Lazy ``(ℤ/2)^k`` memory.

    Vertices are bitstrings of length ``k``. Neighbours are computed
    on demand by flipping one bit. Only populated cells are stored.
    Local audits operate over a BFS ball, which keeps cost
    independent of ``2^k`` for sparse workloads.
    """

    def __init__(self, k: int) -> None:
        if k < 1 or k > 30:
            raise SparseMemoryError(
                f"k={k} out of supported range [1, 30]"
            )
        self.k = k
        self._store: dict[str, Cell] = {}

    @property
    def theoretical_count(self) -> int:
        return 1 << self.k

    @property
    def populated_count(self) -> int:
        return len(self._store)

    def _check_addr(self, addr: str) -> None:
        if len(addr) != self.k or any(c not in "01" for c in addr):
            raise SparseMemoryError(
                f"address {addr!r} not in (ℤ/2)^{self.k}"
            )

    def neighbors(self, addr: str) -> list[str]:
        self._check_addr(addr)
        out: list[str] = []
        for i in range(self.k):
            bit = "1" if addr[i] == "0" else "0"
            out.append(addr[:i] + bit + addr[i + 1:])
        return out

    def write(self, addr: str, cell: Cell) -> None:
        self._check_addr(addr)
        self._store[addr] = cell

    def read(self, addr: str) -> Cell:
        self._check_addr(addr)
        if addr not in self._store:
            raise SparseMemoryError(f"{addr!r} not populated")
        return self._store[addr]

    def populated_addresses(self) -> list[str]:
        return sorted(self._store)

    def ball(self, seed: str, radius: int) -> set[str]:
        """BFS ball of radius ``radius`` around ``seed``."""
        self._check_addr(seed)
        seen: set[str] = {seed}
        frontier = deque([(seed, 0)])
        while frontier:
            a, d = frontier.popleft()
            if d >= radius:
                continue
            for nb in self.neighbors(a):
                if nb not in seen:
                    seen.add(nb)
                    frontier.append((nb, d + 1))
        return seen

    def local_audit(self, seed: str, radius: int) -> LocalAuditReport:
        """Audit a small ball — V, undirected E, faces (commuting
        pairs of generators) per the Zone-117 convention, and a
        local χ."""
        V = self.ball(seed, radius)
        E = 0
        for a in V:
            for nb in self.neighbors(a):
                if nb in V and nb > a:
                    E += 1
        # Local faces = adjacent commuting-generator squares.
        # For Z/2^k generators commute pairwise, so faces are the
        # 4-cycles a → a⊕e_i → a⊕e_i⊕e_j → a⊕e_j → a, i<j.
        F = 0
        sorted_V = sorted(V)
        for a in sorted_V:
            for i in range(self.k):
                for j in range(i + 1, self.k):
                    b = a[:i] + ("1" if a[i] == "0" else "0") + a[i + 1:]
                    c = b[:j] + ("1" if b[j] == "0" else "0") + b[j + 1:]
                    d = a[:j] + ("1" if a[j] == "0" else "0") + a[j + 1:]
                    if b in V and c in V and d in V:
                        F += 1
        # Each square counted 4× (once per starting vertex), so divide.
        F //= 4
        populated_in_ball = sum(1 for a in V if a in self._store)
        chi = len(V) - E + F
        return LocalAuditReport(
            seed=seed, radius=radius,
            n_vertices=len(V), n_edges=E,
            populated_in_ball=populated_in_ball, chi_local=chi,
        )

    def extrapolated_chi(self, *, samples: int = 4,
                         radius: int = 3,
                         rng_seed: int = 0) -> float:
        """Empirical χ extrapolation: average local χ over random
        balls, scaled to the global vertex count. Honest:
        no claim of exactness."""
        rng = random.Random(rng_seed)
        seeds = [
            "".join("01"[rng.randint(0, 1)] for _ in range(self.k))
            for _ in range(samples)
        ]
        chis = [self.local_audit(s, radius).chi_local for s in seeds]
        if not chis:
            return 0.0
        return float(np.mean(chis))


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(name: str, mem: SparseScaleMemory,
            rep: LocalAuditReport, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(mem.k), float(mem.theoretical_count),
        float(mem.populated_count),
        float(rep.n_vertices), float(rep.n_edges),
        float(rep.chi_local),
    ], dtype=float)
    safe = "".join(c if c.isalnum() else "_" for c in name)[:60]
    trust = 1.0 if mem.populated_count > 0 else 0.5
    arena[f"sparse/{safe}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith sparse scale-aware memory (Zone 149)."
    )
    p.add_argument("--k", type=int, default=20)
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print(f"# Zone 149 — sparse scale-aware memory at k={args.k}")
    mem = SparseScaleMemory(args.k)
    print(f"   theoretical addresses = 2^{args.k} "
          f"= {mem.theoretical_count:,}")
    print(f"   populated             = {mem.populated_count}")

    rng = random.Random(7)
    seed = "0" * mem.k
    populate = [seed]
    for _ in range(31):
        addr = "".join("01"[rng.randint(0, 1)] for _ in range(mem.k))
        populate.append(addr)
    for a in populate:
        mem.write(a, Cell(value=np.array([1.0, float(len(a))]),
                          trust=1.0, phase=0.0))
    print(f"   populated 32 random addresses; populated count = "
          f"{mem.populated_count}")

    print("\n# 1. Local audit at radius 2 around the seed")
    rep = mem.local_audit(seed, radius=2)
    print(f"   {rep.describe()}")
    persist(f"k{args.k}_seed_r2", mem, rep, args.arena)

    print("\n# 2. Local audit at radius 3 around the seed")
    rep3 = mem.local_audit(seed, radius=3)
    print(f"   {rep3.describe()}")
    persist(f"k{args.k}_seed_r3", mem, rep3, args.arena)

    print("\n# 3. χ extrapolation from 4 random balls (radius 3)")
    chi_avg = mem.extrapolated_chi(samples=4, radius=3)
    print(f"   ⟨χ_local⟩ ≈ {chi_avg:.2f}   (honest: heuristic)")

    print("\n# 4. Memory pressure check")
    print(f"   memory cells in use   = {mem.populated_count}")
    print(f"   theoretical vertices  = {mem.theoretical_count:,}")
    print(f"   utilisation           = "
          f"{mem.populated_count / mem.theoretical_count:.2e}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
