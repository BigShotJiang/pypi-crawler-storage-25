"""
soilith_ownership.py — ownership and borrow scopes (Zone 134).

Rust's borrow checker enforces "either one mutable borrow or any
number of shared borrows" on each location, with lexical (or NLL)
scopes. Σoilith's scale-aware memory adds a *spatial* twist that
Rust can't even express: borrows have a **Cayley footprint** (the
borrowed address plus its closed neighborhood), and two mutable
borrows must have *disjoint* footprints — not just disjoint
addresses.

API
---
    bc = BorrowChecker(memory)
    with bc.borrow_mut("000") as h:
        h.write(np.zeros(8))
    # The mutable borrow excluded the closed-neighbourhood
    # {000, 001, 010, 100} for its lifetime — any concurrent
    # borrow_mut("001") would have raised BorrowConflict.

Two simultaneous shared borrows on the same address are fine; a
shared borrow within the footprint of an existing mutable borrow
is rejected. ``BorrowChecker.audit()`` returns the count of
borrows currently outstanding plus any conflicts that were
attempted (and rejected).

CLI
---
    python soilith_ownership.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any, Iterable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class OwnershipError(Exception):
    """Base class for Zone 134 errors."""


class BorrowConflict(OwnershipError):
    """A new borrow conflicts with an outstanding one."""


class UseAfterEndOfBorrow(OwnershipError):
    """A handle was used after its borrow scope ended."""


# ──────────────────────────────────────────────────────────────────────────
#  Borrow records
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class _Borrow:
    addr: Any
    footprint: frozenset
    is_mut: bool
    handle_id: int


@dataclass
class BorrowAudit:
    open_mut: int
    open_shared: int
    rejected: int
    history: list[str] = field(default_factory=list)

    @property
    def successful(self) -> bool:
        return self.open_mut == 0 and self.open_shared == 0

    def describe(self) -> str:
        ok = "✓" if self.successful else "✗"
        out = [
            f"BorrowAudit {ok}",
            f"  open mutable    = {self.open_mut}",
            f"  open shared     = {self.open_shared}",
            f"  rejected total  = {self.rejected}",
        ]
        for h in self.history[-6:]:
            out.append(f"  · {h}")
        return "\n".join(out)


# ──────────────────────────────────────────────────────────────────────────
#  BorrowChecker
# ──────────────────────────────────────────────────────────────────────────
class BorrowChecker:
    """Scoped borrow checker layered over a scale-aware memory."""

    def __init__(self, memory: Any) -> None:
        if not hasattr(memory, "neighbors"):
            raise TypeError("memory must expose neighbors(addr)")
        if not hasattr(memory, "read") or not hasattr(memory, "write"):
            raise TypeError("memory must expose read/write")
        self.memory = memory
        self._borrows: list[_Borrow] = []
        self._next_id = 0
        self._rejected = 0
        self._history: list[str] = []

    # ── footprints ──────────────────────────────────────────────────────
    def _closed_neighbourhood(self, addr: Any) -> frozenset:
        """{addr} ∪ neighbors(addr) — the spatial scope of a mutable
        borrow."""
        nbrs = list(self.memory.neighbors(addr))
        return frozenset({addr, *nbrs})

    # ── conflict checks ─────────────────────────────────────────────────
    def _conflicts(self, fp: frozenset, is_mut: bool) -> _Borrow | None:
        for b in self._borrows:
            shared_addrs = fp & b.footprint
            if not shared_addrs:
                continue
            if is_mut or b.is_mut:
                return b
        return None

    # ── core API ────────────────────────────────────────────────────────
    def borrow_mut(self, addr: Any) -> "MutBorrow":
        fp = self._closed_neighbourhood(addr)
        existing = self._conflicts(fp, is_mut=True)
        if existing is not None:
            self._rejected += 1
            self._history.append(
                f"REJECT mut {addr!r}: conflicts with "
                f"{'mut' if existing.is_mut else 'shared'} on {existing.addr!r}"
            )
            raise BorrowConflict(
                f"mutable borrow of {addr!r} conflicts with outstanding "
                f"borrow on {existing.addr!r}"
            )
        h_id = self._next_id
        self._next_id += 1
        rec = _Borrow(addr=addr, footprint=fp, is_mut=True, handle_id=h_id)
        self._borrows.append(rec)
        self._history.append(f"borrow_mut({addr!r})  fp={sorted(fp)!r}")
        return MutBorrow(self, rec)

    def borrow_shared(self, addr: Any) -> "SharedBorrow":
        fp = frozenset({addr})
        existing = self._conflicts(fp, is_mut=False)
        if existing is not None:
            self._rejected += 1
            self._history.append(
                f"REJECT shared {addr!r}: conflicts with mut "
                f"on {existing.addr!r}"
            )
            raise BorrowConflict(
                f"shared borrow of {addr!r} conflicts with outstanding "
                f"mutable borrow on {existing.addr!r}"
            )
        h_id = self._next_id
        self._next_id += 1
        rec = _Borrow(addr=addr, footprint=fp, is_mut=False, handle_id=h_id)
        self._borrows.append(rec)
        self._history.append(f"borrow_shared({addr!r})")
        return SharedBorrow(self, rec)

    def _release(self, rec: _Borrow) -> None:
        try:
            self._borrows.remove(rec)
            self._history.append(
                f"release {'mut' if rec.is_mut else 'shared'} {rec.addr!r}"
            )
        except ValueError:
            pass

    # ── audit ───────────────────────────────────────────────────────────
    def audit(self) -> BorrowAudit:
        open_m = sum(1 for b in self._borrows if b.is_mut)
        open_s = sum(1 for b in self._borrows if not b.is_mut)
        return BorrowAudit(
            open_mut=open_m, open_shared=open_s,
            rejected=self._rejected, history=list(self._history),
        )


# ──────────────────────────────────────────────────────────────────────────
#  Borrow handles
# ──────────────────────────────────────────────────────────────────────────
class _BorrowHandle:
    def __init__(self, checker: BorrowChecker, rec: _Borrow) -> None:
        self._checker = checker
        self._rec = rec
        self._released = False

    def __enter__(self) -> "_BorrowHandle":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.release()

    def release(self) -> None:
        if not self._released:
            self._checker._release(self._rec)
            self._released = True

    def _check(self) -> None:
        if self._released:
            raise UseAfterEndOfBorrow(
                f"handle for {self._rec.addr!r} already released"
            )


class SharedBorrow(_BorrowHandle):
    def value(self) -> Cell | None:
        self._check()
        return self._checker.memory.read(self._rec.addr)


class MutBorrow(_BorrowHandle):
    def value(self) -> Cell | None:
        self._check()
        return self._checker.memory.read(self._rec.addr)

    def write(self, cell: Cell) -> None:
        self._check()
        self._checker.memory.write(self._rec.addr, cell)


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(audit: BorrowAudit, slot_name: str, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(audit.open_mut), float(audit.open_shared),
        float(audit.rejected),
        1.0 if audit.successful else 0.0,
    ], dtype=float)
    trust = 1.0 if audit.successful else 0.5
    arena[f"ownership/{slot_name}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith ownership / borrow checker (Zone 134)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    from soilith_memory import ScaleAwareMemory

    print("# Zone 134 — Cayley-aware borrow checker on (Z/2)^3")
    mem = ScaleAwareMemory(
        k=3, attested_V=8, attested_E=12, attested_F=3,
        attested_chi_1=-4, attested_chi_2=-1,
        probe_name="z2_cubed",
    )
    for addr in mem.positions():
        mem.write(addr, Cell(value=np.zeros(4), trust=1.0, phase=0.0))

    bc = BorrowChecker(mem)

    print("\n# 1. Two ANTIPODAL mutable borrows ('000' & '111') are allowed")
    print("   (their closed neighbourhoods are the two halves of the cube)")
    with bc.borrow_mut("000") as a, bc.borrow_mut("111") as b:
        a.write(Cell(value=np.array([1.0, 1.0, 1.0, 1.0]),
                     trust=1.0, phase=0.0))
        b.write(Cell(value=np.array([2.0, 2.0, 2.0, 2.0]),
                     trust=1.0, phase=0.0))
        audit = bc.audit()
        print(f"   open mut={audit.open_mut}, shared={audit.open_shared}")

    print("\n# 1b. Non-antipodal mutable borrows ('000' & '110') REJECTED")
    print("   (they share neighbours {010, 100} — Cayley conflict)")
    try:
        with bc.borrow_mut("000") as _:
            with bc.borrow_mut("110") as _:
                pass
    except BorrowConflict as exc:
        print(f"   ✓ {type(exc).__name__}: {exc}")

    print("\n# 2. Two ADJACENT mutable borrows are rejected (Cayley-aware!)")
    try:
        with bc.borrow_mut("000") as a:
            with bc.borrow_mut("001") as b:  # 000 and 001 are neighbors
                pass
    except BorrowConflict as exc:
        print(f"   ✓ {type(exc).__name__}: {exc}")

    print("\n# 3. Many shared borrows on disjoint addresses are fine")
    handles = [bc.borrow_shared(addr) for addr in
               ("000", "001", "010", "100")]
    print(f"   open shared = {bc.audit().open_shared}")
    for h in handles:
        h.release()

    print("\n# 4. Mutable borrow rejected while a shared borrow lives")
    s = bc.borrow_shared("000")
    try:
        bc.borrow_mut("000")
    except BorrowConflict as exc:
        print(f"   ✓ {type(exc).__name__}: {exc}")
    s.release()

    print("\n# 5. Audit & persist")
    audit = bc.audit()
    print(audit.describe())
    persist(audit, "demo", args.arena)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
