"""
soilith_concurrent.py — concurrency, interleaving, and race
detection (Zone 139).

The concurrent-PL research line (CSP, π-calculus, TLA+, Iris
concurrent) verifies safety of *interleaved* executions: two
processes running on a shared store don't interfere as long as
they don't both touch the same locations, or as long as their
touches are synchronised.

Σoilith's twist: a process's *footprint* is its set of touched
addresses; two processes are **interference-free** iff the
Zone-134 closed Cayley neighbourhoods of their footprints don't
overlap. That's strictly stronger than address-level disjointness
and matches the mutable-borrow discipline of Zone 134.

API
---
* ``Process(steps)``: a list of (op, addr, payload) entries.
  ``op ∈ {"read", "write", "phi"}``.
* ``footprint(process)``: addresses the process touches.
* ``interference_free(p, q, memory)``: True iff the closed
  Cayley neighbourhoods of footprints are disjoint.
* ``interleave(p, q)``: a generator yielding every interleaving
  of p and q.
* ``race_check(p, q, memory)``: runs every interleaving and
  checks whether final memory states agree. If they don't, the
  pair is **racy** and the offending interleavings are recorded.

Persistence
-----------
``concurrent/<pair>/check`` with 5-float payload
``[len_p, len_q, n_interleavings, interference_free, race_free]``.

CLI
---
    python soilith_concurrent.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from itertools import combinations
from pathlib import Path
import sys
from typing import Any, Callable, Iterator

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402
from soilith_phi import PHI  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class ConcurrencyError(Exception):
    """Base class for Zone 139 errors."""


class DataRace(ConcurrencyError):
    """A race was detected: two interleavings produce different
    final states."""


# ──────────────────────────────────────────────────────────────────────────
#  Process model
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Step:
    op: str                          # "read" | "write" | "phi"
    addr: str
    payload: Any = None              # Cell for write; (op_index, src) for phi


@dataclass
class Process:
    name: str
    steps: list[Step] = field(default_factory=list)

    def write(self, addr: str, cell: Cell) -> "Process":
        self.steps.append(Step("write", addr, cell))
        return self

    def read(self, addr: str) -> "Process":
        self.steps.append(Step("read", addr))
        return self

    def phi(self, addr: str, op: int, src: str) -> "Process":
        """``addr ← φ_op(read src)``."""
        self.steps.append(Step("phi", addr, (op, src)))
        return self

    def footprint(self) -> set[str]:
        return {s.addr for s in self.steps} | {
            s.payload[1] for s in self.steps if s.op == "phi"
        }


# ──────────────────────────────────────────────────────────────────────────
#  Interference
# ──────────────────────────────────────────────────────────────────────────
def cayley_footprint(addrs: set[str], memory: Any) -> set[str]:
    """Closed Cayley neighbourhood — Zone 134's discipline."""
    out: set[str] = set()
    for a in addrs:
        out.add(a)
        try:
            for nb in memory.neighbors(a):
                out.add(nb)
        except Exception:
            pass
    return out


def interference_free(p: Process, q: Process, memory: Any) -> bool:
    fp_p = cayley_footprint(p.footprint(), memory)
    fp_q = cayley_footprint(q.footprint(), memory)
    return fp_p.isdisjoint(fp_q)


# ──────────────────────────────────────────────────────────────────────────
#  Interleaving + execution
# ──────────────────────────────────────────────────────────────────────────
def interleave(p: Process, q: Process) -> Iterator[list[tuple[str, Step]]]:
    """All interleavings of p and q's step sequences. Each yielded
    schedule is a list of ``(process_name, step)`` tuples."""
    n, m = len(p.steps), len(q.steps)
    # Pick positions for p's steps among (n+m) slots.
    for picks in combinations(range(n + m), n):
        picks_set = set(picks)
        sched: list[tuple[str, Step]] = []
        pi, qi = 0, 0
        for k in range(n + m):
            if k in picks_set:
                sched.append((p.name, p.steps[pi]))
                pi += 1
            else:
                sched.append((q.name, q.steps[qi]))
                qi += 1
        yield sched


def execute(memory: Any, schedule: list[tuple[str, Step]]) -> dict[str, Cell]:
    """Run a schedule against a fresh copy of memory's current state.
    Returns the final dict of cells (only on the touched addresses)."""
    if hasattr(memory, "snapshot"):
        snap = memory.snapshot()
    else:
        snap = dict(getattr(memory, "_store", {}))
    state: dict[str, Cell] = dict(snap)
    for _proc, step in schedule:
        if step.op == "write":
            state[step.addr] = step.payload
        elif step.op == "read":
            pass
        elif step.op == "phi":
            op_idx, src = step.payload
            src_cell = state.get(src)
            if src_cell is None:
                continue
            fn = PHI.get(op_idx)
            if fn is None:
                continue
            try:
                y = np.asarray(fn(np.asarray(src_cell.value, dtype=float)),
                               dtype=float).ravel()
                state[step.addr] = Cell(value=y,
                                         trust=src_cell.trust,
                                         phase=src_cell.phase)
            except Exception:
                continue
    return state


# ──────────────────────────────────────────────────────────────────────────
#  Race detection
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class RaceReport:
    pair: str
    n_interleavings: int
    interference_free: bool
    race_free: bool
    divergent_schedule_count: int = 0
    example_disagreement: tuple[str, str, str] | None = None
    # (slot, value_in_a, value_in_b)

    @property
    def successful(self) -> bool:
        return self.race_free

    def describe(self) -> str:
        ok = "✓" if self.successful else "✗"
        out = [
            f"RaceReport {ok}  {self.pair}",
            f"  interleavings tried   = {self.n_interleavings}",
            f"  interference_free     = {self.interference_free}",
            f"  race_free             = {self.race_free}",
        ]
        if self.divergent_schedule_count > 0:
            out.append(
                f"  divergent schedules   = {self.divergent_schedule_count}"
            )
            if self.example_disagreement is not None:
                s, a, b = self.example_disagreement
                out.append(f"  example: {s} = {a} vs {b}")
        return "\n".join(out)


def race_check(p: Process, q: Process, memory: Any) -> RaceReport:
    schedules = list(interleave(p, q))
    n = len(schedules)
    if_free = interference_free(p, q, memory)
    final_states = []
    for sched in schedules:
        final_states.append(execute(memory, sched))
    # Compare each final state to the first; record disagreements.
    base = final_states[0]
    base_touched = {
        a for a in (p.footprint() | q.footprint()) if a in base
    }
    divergent = 0
    example: tuple[str, str, str] | None = None
    for other in final_states[1:]:
        for a in base_touched:
            ca = base.get(a); cb = other.get(a)
            if ca is None or cb is None:
                continue
            va = np.asarray(ca.value, dtype=float).ravel()
            vb = np.asarray(cb.value, dtype=float).ravel()
            if va.shape != vb.shape or not np.allclose(va, vb, atol=1e-9):
                divergent += 1
                if example is None:
                    example = (a,
                               f"{float(va[0]):.3f}" if va.size else "()",
                               f"{float(vb[0]):.3f}" if vb.size else "()")
                break
    return RaceReport(
        pair=f"{p.name}||{q.name}",
        n_interleavings=n,
        interference_free=if_free,
        race_free=(divergent == 0),
        divergent_schedule_count=divergent,
        example_disagreement=example,
    )


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(report: RaceReport, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(report.n_interleavings),
        1.0 if report.interference_free else 0.0,
        1.0 if report.race_free else 0.0,
        float(report.divergent_schedule_count),
    ], dtype=float)
    trust = 1.0 if report.race_free else 0.0
    safe = "".join(c if c.isalnum() else "_" for c in report.pair)[:60]
    arena[f"concurrent/{safe}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith concurrent process algebra (Zone 139)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    from soilith_memory import ScaleAwareMemory

    print("# Zone 139 — concurrent processes on (Z/2)^3")
    mem = ScaleAwareMemory(
        k=3, attested_V=8, attested_E=12, attested_F=3,
        attested_chi_1=-4, attested_chi_2=-1, probe_name="z2_cubed",
    )
    for addr in mem.positions():
        mem.write(addr, Cell(value=np.zeros(2), trust=1.0, phase=0.0))

    print("\n# 1. Two interference-free processes (antipodal footprints)")
    p_a = Process("A").write("000", Cell(value=np.array([1.0, 1.0]),
                                          trust=1.0, phase=0.0))
    p_b = Process("B").write("111", Cell(value=np.array([2.0, 2.0]),
                                          trust=1.0, phase=0.0))
    rep = race_check(p_a, p_b, mem)
    print(rep.describe())
    persist(rep, args.arena)

    print("\n# 2. Two RACY processes (both write to '000' with diff. values)")
    p_c = Process("C").write("000", Cell(value=np.array([10.0, 10.0]),
                                          trust=1.0, phase=0.0))
    p_d = Process("D").write("000", Cell(value=np.array([20.0, 20.0]),
                                          trust=1.0, phase=0.0))
    rep = race_check(p_c, p_d, mem)
    print(rep.describe())
    persist(rep, args.arena)

    print("\n# 3. Cayley-adjacent processes ('000' and '001') — "
          "interference detected even though they write to DIFFERENT addresses")
    p_e = Process("E").write("000", Cell(value=np.array([1.0, 1.0]),
                                          trust=1.0, phase=0.0))
    p_f = Process("F").write("001", Cell(value=np.array([2.0, 2.0]),
                                          trust=1.0, phase=0.0))
    if_free = interference_free(p_e, p_f, mem)
    print(f"   addresses differ but Cayley-overlap → "
          f"interference_free = {if_free}")
    rep = race_check(p_e, p_f, mem)
    print(rep.describe())
    persist(rep, args.arena)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
