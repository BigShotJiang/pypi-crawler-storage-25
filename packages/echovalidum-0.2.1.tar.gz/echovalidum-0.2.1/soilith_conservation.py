"""
soilith_conservation.py — discovery of conservation laws (Zone 120).

Where Zone 116 finds *algebraic* identities (``φ_a ∘ φ_b = id``), this
zone finds *dynamical* invariants: scalar functionals ``Q`` such that
``Q(φ_k(x)) ≈ Q(x)`` for every test ψ-cell. That makes ``Q`` a
**symmetry** of ``φ_k`` — and any measurement where ``Q(φ_k(x)) ≠ Q(x)``
is a symmetry-breaking event, the sharpest kind of anomaly signal.

Quantities probed
-----------------
    l1            — Σ |x_i|
    l2            — √(Σ x_i²)
    linf          — max |x_i|
    sum           — Σ x_i
    mean          — (1/n) Σ x_i
    variance      — population variance
    range         — max(x) − min(x)
    sign_balance  — (#pos − #neg) / n
    zero_count    — #{i : |x_i| < 1e−9}
    argmax_pos    — index of max (exact-match indicator)
    shannon       — Shannon entropy of |x|/Σ|x| (zeros softened)

The first eight are continuous (relative L1 residual); the last three are
mostly categorical / sensitive to small perturbations (exact-match or
absolute residual). Each is normalized so a threshold of ``0.01`` means
"preserved to within 1%" regardless of the quantity's natural scale.

Output
------
For each surviving ``(operator, quantity)``, the engine emits:

  * a ψ-cell at ``conservation/phi_<k>/<quantity>`` in the lawbook arena,
    with ``value = [residual, trials]``, ``trust = 1 − residual``;
  * an entry in the optional Σoilith stdlib file written to ``--write``.

CLI
---
    python soilith_conservation.py
    python soilith_conservation.py --threshold 0.005 --lawbook lawbook.arena \\
        --write stdlib/conserved.sol --summary-only
"""

from __future__ import annotations

import argparse
import math
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
import sys
from typing import Callable, Optional

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_phi import PHI  # noqa: E402
from soilith_arena import Arena  # noqa: E402
from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Conserved-quantity functionals
# ──────────────────────────────────────────────────────────────────────────
def _l1(x: np.ndarray) -> float:
    return float(np.sum(np.abs(x)))


def _l2(x: np.ndarray) -> float:
    return float(np.linalg.norm(x))


def _linf(x: np.ndarray) -> float:
    return float(np.max(np.abs(x))) if x.size else 0.0


def _sum(x: np.ndarray) -> float:
    return float(np.sum(x))


def _mean(x: np.ndarray) -> float:
    return float(np.mean(x)) if x.size else 0.0


def _variance(x: np.ndarray) -> float:
    return float(np.var(x)) if x.size else 0.0


def _range(x: np.ndarray) -> float:
    if x.size == 0:
        return 0.0
    return float(np.max(x) - np.min(x))


def _sign_balance(x: np.ndarray) -> float:
    if x.size == 0:
        return 0.0
    return float((np.sum(x > 0) - np.sum(x < 0)) / x.size)


def _zero_count(x: np.ndarray) -> float:
    return float(np.sum(np.abs(x) < 1e-9))


def _argmax_pos(x: np.ndarray) -> float:
    return float(int(np.argmax(x))) if x.size else 0.0


def _shannon(x: np.ndarray) -> float:
    a = np.abs(x)
    total = float(a.sum())
    if total < 1e-12:
        return 0.0
    p = a / total
    p = p[p > 1e-12]
    return float(-np.sum(p * np.log(p)))


CONTINUOUS = ("l1", "l2", "linf", "sum", "mean", "variance", "range",
              "sign_balance", "shannon")
CATEGORICAL = ("argmax_pos", "zero_count")

QUANTITIES: dict[str, Callable[[np.ndarray], float]] = {
    "l1": _l1,
    "l2": _l2,
    "linf": _linf,
    "sum": _sum,
    "mean": _mean,
    "variance": _variance,
    "range": _range,
    "sign_balance": _sign_balance,
    "zero_count": _zero_count,
    "argmax_pos": _argmax_pos,
    "shannon": _shannon,
}


# ──────────────────────────────────────────────────────────────────────────
#  Data model
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Conservation:
    """One surviving symmetry of a single operator."""

    op_index: int
    quantity: str
    residual: float
    trust: float
    trials: int

    @property
    def slot(self) -> str:
        return f"conservation/phi_{self.op_index}/{self.quantity}"

    def as_sol(self) -> str:
        return (
            f"# conservation  φ_{self.op_index} preserves {self.quantity:<13s} "
            f"residual={self.residual:.3e}  trust={self.trust:.3f}  trials={self.trials}\n"
            f"#   {self.quantity}(phi({self.op_index}, x))  ≈  {self.quantity}(x)\n"
            f"fn phi_{self.op_index}_preserves_{self.quantity}(x):\n"
            f"    yield phi({self.op_index}, x)\n"
            f"end\n"
        )

    def as_cell(self) -> Cell:
        return Cell(
            value=np.array([self.residual, float(self.trials)]),
            trust=self.trust,
            phase=0.0,
        )


# ──────────────────────────────────────────────────────────────────────────
#  Numerics
# ──────────────────────────────────────────────────────────────────────────
def _safe_apply(k: int, x: np.ndarray) -> Optional[np.ndarray]:
    try:
        y = PHI[k](x)
        if isinstance(y, tuple):
            parts = [np.asarray(p) for p in y]
            if any(np.iscomplexobj(p) for p in parts):
                return None
            y = np.concatenate([p.astype(np.float64).ravel() for p in parts])
        y = np.asarray(y)
        if np.iscomplexobj(y):
            return None
        y = y.astype(np.float64).ravel()
        if y.size == 0 or not np.all(np.isfinite(y)):
            return None
        return y
    except Exception:
        return None


def _continuous_residual(qx: float, qy: float) -> float:
    denom = abs(qx) + abs(qy) + 1e-9
    return abs(qy - qx) / denom


def _categorical_residual(qx: float, qy: float) -> float:
    # 0 if exact match (within int rounding), 1 otherwise — averaged over
    # trials this becomes the empirical mismatch frequency.
    return 0.0 if int(round(qx)) == int(round(qy)) else 1.0


def _trust_from_residual(r: float) -> float:
    return float(max(0.0, min(1.0, 1.0 - r)))


def _sample_inputs(rng: np.random.Generator, dim: int, trials: int) -> list[np.ndarray]:
    out: list[np.ndarray] = []
    for _ in range(trials):
        kind = int(rng.integers(0, 4))
        if kind == 0:
            x = rng.standard_normal(dim) * 0.3
        elif kind == 1:
            x = rng.uniform(-0.5, 0.5, dim)
        elif kind == 2:
            t = np.linspace(0.0, 2.0 * np.pi, dim)
            x = np.sin(t + rng.uniform(0.0, 2.0 * np.pi)) * 0.5
        else:
            x = np.full(dim, float(rng.uniform(-0.3, 0.3)))
        out.append(np.asarray(x, dtype=np.float64))
    return out


def _is_size_preserving(k: int, dim: int) -> bool:
    """Conservation analysis requires same-size output. Generators (φ₀),
    zoomers (φ₅₉/φ₆₀), and reducers are excluded by this check."""
    probe = np.array([0.05] * dim)
    y = _safe_apply(k, probe)
    return y is not None and y.size == dim


# ──────────────────────────────────────────────────────────────────────────
#  Discovery loop
# ──────────────────────────────────────────────────────────────────────────
def discover(
    *,
    threshold: float = 0.01,
    dim: int = 16,
    trials: int = 16,
    k_max: int = 60,
    seed: int = 42,
    quantities: tuple[str, ...] = tuple(QUANTITIES.keys()),
) -> list[Conservation]:
    rng = np.random.default_rng(seed)
    samples = _sample_inputs(rng, dim, trials)
    compatible = [k for k in range(k_max + 1) if k in PHI and _is_size_preserving(k, dim)]

    survivors: list[Conservation] = []
    for k in compatible:
        for qname in quantities:
            Q = QUANTITIES[qname]
            resids = []
            ok = True
            for x in samples:
                y = _safe_apply(k, x)
                if y is None or y.size != x.size:
                    ok = False
                    break
                qx, qy = Q(x), Q(y)
                if not np.isfinite(qx) or not np.isfinite(qy):
                    ok = False
                    break
                if qname in CATEGORICAL:
                    resids.append(_categorical_residual(qx, qy))
                else:
                    resids.append(_continuous_residual(qx, qy))
            if not ok:
                continue
            r = float(np.mean(resids))
            if r <= threshold:
                survivors.append(Conservation(
                    op_index=k,
                    quantity=qname,
                    residual=r,
                    trust=_trust_from_residual(r),
                    trials=trials,
                ))
    survivors.sort(key=lambda c: (c.op_index, c.residual, c.quantity))
    return survivors


def persist(arena_path: Path, laws: list[Conservation]) -> None:
    a = Arena.open(arena_path, autoflush=False)
    for c in laws:
        a[c.slot] = c.as_cell()
    a.flush()


def summarize(laws: list[Conservation]) -> dict[str, int]:
    by_qty: Counter = Counter(c.quantity for c in laws)
    by_op: Counter = Counter(c.op_index for c in laws)
    return {
        "total": len(laws),
        "distinct_operators": len(by_op),
        "by_quantity": dict(by_qty),
    }


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Σoilith conservation-law discovery (Zone 120).")
    p.add_argument("--threshold", type=float, default=0.01,
                   help="max relative residual to accept a conservation (default 0.01).")
    p.add_argument("--dim", type=int, default=16)
    p.add_argument("--trials", type=int, default=16)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--k-max", type=int, default=60)
    p.add_argument("--write", type=Path, default=None,
                   help="optional .sol path for the conservation stdlib wrappers.")
    p.add_argument("--lawbook", type=Path, default=None,
                   help="optional .arena path to persist conservation cells into.")
    p.add_argument("--limit", type=int, default=60)
    p.add_argument("--summary-only", action="store_true")
    args = p.parse_args(argv)

    laws = discover(
        threshold=args.threshold,
        dim=args.dim,
        trials=args.trials,
        seed=args.seed,
        k_max=args.k_max,
    )
    s = summarize(laws)
    header = (
        f"# Σoilith — conservation: {s['total']} laws over "
        f"{s['distinct_operators']} operators "
        f"(threshold={args.threshold}, dim={args.dim}, trials={args.trials}, seed={args.seed})\n"
        f"#   by_quantity: " + ", ".join(f"{k}={v}" for k, v in sorted(s["by_quantity"].items())) + "\n"
    )
    print(header)

    if not args.summary_only:
        for c in laws[: args.limit]:
            print(c.as_sol())
        if len(laws) > args.limit:
            print(f"# ({len(laws) - args.limit} more not shown — pass --limit 0 to see all.)\n")

    if args.write is not None:
        args.write.parent.mkdir(parents=True, exist_ok=True)
        body = header + "\n".join(c.as_sol() for c in laws)
        args.write.write_text(body, encoding="utf-8")
        print(f"# wrote {len(laws)} conservation fn definitions → {args.write}")

    if args.lawbook is not None:
        persist(args.lawbook, laws)
        print(f"# persisted {len(laws)} ψ-cells → {args.lawbook}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
