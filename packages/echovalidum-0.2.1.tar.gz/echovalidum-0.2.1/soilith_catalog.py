"""
soilith_catalog.py — unified index of Σoilith discoveries (Zones 118+121).

Scans one or more persistent ψ-arenas and emits a single versioned JSON
manifest listing every ``law/*`` slot (Zone 116), every ``topology/*``
slot (Zone 117), every ``conservation/*`` slot (Zone 120), and **derived**
``magnitude/*`` rows (Zone 121) computed from topology + conservation
entries in the same manifest.

The magnitude catalog is the machine-readable form of “memory as a
group position + Cayley adjacency + χ invariants + cross-scale
consistency witnesses.”  It is not stored in arenas; it is regenerated
whenever ``build_manifest`` runs.

CLI
---
    python soilith_catalog.py
    python soilith_catalog.py --arena lawbook.arena --arena other.arena \\
        --out catalog/discoveries.json

If ``--out`` is omitted, writes ``catalog/discoveries.json`` next to this
file (under the Σoilith package root).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_arena import Arena  # noqa: E402
from soilith_resonance import conservation_witnesses, find_resonances  # noqa: E402


SCHEMA_VERSION = 1


@dataclass
class CatalogEntry:
    """One indexed discovery row."""

    id: str
    zone: str
    kind: str
    arena: str
    slot: str
    trust: float
    summary: str
    payload: dict[str, Any]


def _stable_id(arena_name: str, slot: str) -> str:
    h = hashlib.sha256()
    h.update(arena_name.encode("utf-8"))
    h.update(b"\x00")
    h.update(slot.encode("utf-8"))
    return h.hexdigest()[:16]


def _law_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    v = np.asarray(cell.value, dtype=float).ravel()
    residual = float(v[0]) if v.size > 0 else float("nan")
    trials = int(v[1]) if v.size > 1 else 0
    body = slot[len("law/") :] if slot.startswith("law/") else slot
    if body.endswith("_involution"):
        law_kind = "involution"
    elif "_inverts_phi_" in body:
        law_kind = "identity"
    elif "_annihilates_phi_" in body:
        law_kind = "zero"
    elif "_commutes_phi_" in body:
        law_kind = "commute"
    else:
        law_kind = "unknown"
    summary = f"law:{law_kind} residual={residual:.3e} trials={trials}"
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="116",
        kind=f"law/{law_kind}",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "residual": residual,
            "trials": trials,
            "phase": float(cell.phase),
            "law_body": body,
        },
    )


def _finite_order_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot shape: ``finite_order/phi_<k>/dim_<n>``.

    Payload: ``[op_index, cell_dim, order, horizon]``.
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    k = int(v[0]) if v.size > 0 else -1
    n = int(v[1]) if v.size > 1 else -1
    order = int(v[2]) if v.size > 2 else 0
    horizon = int(v[3]) if v.size > 3 else 0
    summary = (
        f"finite_order φ_{k} dim={n} order={order}"
        if order > 0
        else f"finite_order φ_{k} dim={n} (no order ≤ {horizon})"
    )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="127",
        kind="finite_order",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "op_index": k,
            "cell_dim": n,
            "order": order if order > 0 else None,
            "horizon": horizon,
            "finite": order > 0,
            "phase": float(cell.phase),
        },
    )


def _round_trip_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``round_trip/phi_<a>_of_phi_<b>/dim_<n>``.

    Payload: ``[a, b, dim, output_dim, kind_code, deviation]``.
    kind_code: 0 identity, 1 approx_identity, 2 endo_proper,
               3 shape_mismatch, 4 failed.
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    a = int(v[0]) if v.size > 0 else -1
    b = int(v[1]) if v.size > 1 else -1
    n = int(v[2]) if v.size > 2 else -1
    out_dim = int(v[3]) if v.size > 3 else -1
    code = int(v[4]) if v.size > 4 else 4
    dev = float(v[5]) if v.size > 5 else -1.0
    kind_map = {0: "identity", 1: "approx_identity", 2: "endo_proper",
                3: "shape_mismatch", 4: "failed"}
    kind = kind_map.get(code, "failed")
    summary = (
        f"round_trip φ_{a}∘φ_{b} dim={n} kind={kind} dev={dev:.2e}"
    )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="127",
        kind="round_trip",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "a": a, "b": b,
            "cell_dim": n,
            "output_dim": out_dim,
            "kind": kind,
            "deviation": dev,
            "phase": float(cell.phase),
        },
    )


def _composition_law_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``composition_law/phi_<i>_of_phi_<j>/dim_<n>/phi_<k>``.

    Payload: ``[i, j, k, dim, residual]``. ``k = -1`` means
    ``φ_i ∘ φ_j ≈ identity``.
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    i = int(v[0]) if v.size > 0 else -1
    j = int(v[1]) if v.size > 1 else -1
    k = int(v[2]) if v.size > 2 else -1
    n = int(v[3]) if v.size > 3 else -1
    resid = float(v[4]) if v.size > 4 else -1.0
    rhs = "id" if k == -1 else f"φ_{k}"
    summary = (
        f"composition_law φ_{i}∘φ_{j} ≡ {rhs} dim={n} resid={resid:.2e}"
    )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="127",
        kind="composition_law",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "i": i, "j": j, "k_target": k,
            "cell_dim": n, "residual": resid,
            "target_is_identity": k == -1,
            "phase": float(cell.phase),
        },
    )


def _pair_group_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``pair_group/phi_<a>_phi_<b>/dim_<n>/order_<N>``.

    Payload (12 floats):
        [a, b, dim, order_a, order_b, order, V, E, F, χ₁, χ₂,
         commute_residual]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    a = int(v[0]) if v.size > 0 else -1
    b = int(v[1]) if v.size > 1 else -1
    n = int(v[2]) if v.size > 2 else -1
    oa = int(v[3]) if v.size > 3 else 0
    ob = int(v[4]) if v.size > 4 else 0
    order = int(v[5]) if v.size > 5 else 0
    Vv = int(v[6]) if v.size > 6 else 0
    Ee = int(v[7]) if v.size > 7 else 0
    Ff = int(v[8]) if v.size > 8 else 0
    chi1 = int(v[9]) if v.size > 9 else 0
    chi2 = int(v[10]) if v.size > 10 else 0
    comm = float(v[11]) if v.size > 11 else -1.0
    summary = (
        f"pair_group (φ_{a}|{oa}, φ_{b}|{ob}) dim={n} "
        f"|G|={order} χ₁={chi1} comm={comm:.1e}"
    )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="127",
        kind="pair_group",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "a": a, "b": b,
            "cell_dim": n,
            "order_a": oa, "order_b": ob,
            "order": order, "V": Vv, "E": Ee, "F": Ff,
            "chi_1": chi1, "chi_2": chi2,
            "commute_residual": comm,
            "phase": float(cell.phase),
        },
    )


def _separation_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``separation/<command>/frame_<assertion>`` (Zone 131)."""
    v = np.asarray(cell.value, dtype=float).ravel()
    fp = int(v[0]) if v.size > 0 else 0
    ws = int(v[1]) if v.size > 1 else 0
    disjoint = bool(v[2]) if v.size > 2 else False
    holds = bool(v[3]) if v.size > 3 else False
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="131", kind="separation",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=f"separation {slot}  disjoint={disjoint} holds={holds}",
        payload={
            "footprint_size": fp, "write_set_size": ws,
            "disjoint": disjoint, "frame_holds": holds,
            "phase": float(cell.phase),
        },
    )


def _linearity_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``linearity/<label>`` (Zone 132)."""
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i): return int(v[i]) if v.size > i else 0
    unused, borrowed, consumed = _g(0), _g(1), _g(2)
    leaks, double_c, uac = _g(3), _g(4), _g(5)
    mode = "linear" if (v.size > 6 and v[6] > 0.5) else "affine"
    ok = bool(v[7]) if v.size > 7 else False
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="132", kind="linearity",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=f"linearity {slot} mode={mode} ok={ok} leaks={leaks}",
        payload={
            "mode": mode, "unused": unused, "borrowed": borrowed,
            "consumed": consumed, "leaks": leaks,
            "double_consumes": double_c, "use_after_consumes": uac,
            "successful": ok, "phase": float(cell.phase),
        },
    )


def _capability_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``capability/<target>/<label>`` (Zone 133)."""
    v = np.asarray(cell.value, dtype=float).ravel()
    rights_bits = int(v[0]) if v.size > 0 else 0
    min_trust = float(v[1]) if v.size > 1 else 0.0
    revoked = bool(v[2]) if v.size > 2 else False
    n_rights = int(v[3]) if v.size > 3 else 0
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="133", kind="capability",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=f"capability {slot} rights={n_rights} "
                f"min_trust={min_trust:.2f} revoked={revoked}",
        payload={
            "rights_bits": rights_bits, "n_rights": n_rights,
            "min_trust": min_trust, "revoked": revoked,
            "phase": float(cell.phase),
        },
    )


def _ownership_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``ownership/<label>`` (Zone 134)."""
    v = np.asarray(cell.value, dtype=float).ravel()
    open_m = int(v[0]) if v.size > 0 else 0
    open_s = int(v[1]) if v.size > 1 else 0
    rejected = int(v[2]) if v.size > 2 else 0
    ok = bool(v[3]) if v.size > 3 else False
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="134", kind="ownership",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=f"ownership {slot} mut={open_m} shared={open_s} "
                f"rejected={rejected} ok={ok}",
        payload={
            "open_mut": open_m, "open_shared": open_s,
            "rejected": rejected, "successful": ok,
            "phase": float(cell.phase),
        },
    )


def _refinement_check_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``refinement_check/<label>`` (Zone 135)."""
    v = np.asarray(cell.value, dtype=float).ravel()
    accepted = int(v[0]) if v.size > 0 else 0
    rejected = int(v[1]) if v.size > 1 else 0
    ok = bool(v[2]) if v.size > 2 else False
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="135", kind="refinement_check",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=f"refinement_check {slot} accepted={accepted} "
                f"rejected={rejected} ok={ok}",
        payload={
            "accepted": accepted, "rejected": rejected,
            "successful": ok, "phase": float(cell.phase),
        },
    )


def _session_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``session/<name>/run_<ops>`` (Zone 136)."""
    v = np.asarray(cell.value, dtype=float).ravel()
    n_ops = int(v[0]) if v.size > 0 else 0
    n_hist = int(v[1]) if v.size > 1 else 0
    accepted = bool(v[2]) if v.size > 2 else False
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="136", kind="session",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=f"session {slot} ops={n_ops} accepted={accepted}",
        payload={
            "n_ops": n_ops, "n_history": n_hist,
            "accepted": accepted, "phase": float(cell.phase),
        },
    )


def _effect_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``effect/<row>/program_<hash>`` (Zone 137).

    Payload (5 floats):
        [ops_count, distinct_ops, handler_covered, type_checked, ok]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0):
        return v[i] if v.size > i else d
    ops_count = int(_g(0))
    distinct = int(_g(1))
    covered = bool(_g(2))
    typed = bool(_g(3))
    ok = bool(_g(4))
    body = slot[len("effect/"):] if slot.startswith("effect/") else slot
    parts = body.split("/", 1)
    row = parts[0] if parts else ""
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="137", kind="effect",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"effect row={row} ops={ops_count} distinct={distinct} "
            f"covered={covered} typed={typed} ok={ok}"
        ),
        payload={
            "row": row,
            "ops_count": ops_count, "distinct_ops": distinct,
            "handler_covered": covered, "type_checked": typed,
            "successful": ok, "phase": float(cell.phase),
        },
    )


def _ifc_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``ifc/<program>`` (Zone 138).

    Payload (2 floats): [n_low_disagreements, noninterfering_flag]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0):
        return v[i] if v.size > i else d
    n_diff = int(_g(0))
    ok = bool(_g(1))
    name = slot[len("ifc/"):] if slot.startswith("ifc/") else slot
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="138", kind="ifc",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=f"ifc program={name} low_diffs={n_diff} noninterfering={ok}",
        payload={
            "program": name, "low_diffs": n_diff,
            "noninterfering": ok, "phase": float(cell.phase),
        },
    )


def _concurrent_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``concurrent/<pair>`` (Zone 139).

    Payload (4 floats): [n_interleavings, interference_free, race_free,
                         divergent_schedules]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0):
        return v[i] if v.size > i else d
    n_i = int(_g(0))
    iff = bool(_g(1))
    rf = bool(_g(2))
    div = int(_g(3))
    pair = slot[len("concurrent/"):] if slot.startswith("concurrent/") else slot
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="139", kind="concurrent",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"concurrent {pair} n={n_i} interference_free={iff} "
            f"race_free={rf} divergent={div}"
        ),
        payload={
            "pair": pair, "n_interleavings": n_i,
            "interference_free": iff, "race_free": rf,
            "divergent": div, "phase": float(cell.phase),
        },
    )


def _weakmem_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``weakmem/<name>`` (Zone 146).

    Payload (4 floats): [n_events, n_races, perm_violations, ok]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0.0):
        return v[i] if v.size > i else d
    n_events = int(_g(0))
    n_races = int(_g(1))
    n_perm = int(_g(2))
    ok = bool(_g(3))
    name = slot[len("weakmem/"):] if slot.startswith("weakmem/") else slot
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="146", kind="weakmem",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"weakmem {name} events={n_events} races={n_races} "
            f"perm_v={n_perm} ok={ok}"
        ),
        payload={
            "name": name, "n_events": n_events,
            "n_races": n_races, "permission_violations": n_perm,
            "race_free": ok, "phase": float(cell.phase),
        },
    )


def _soundness_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``soundness/<name>`` (Zone 147).

    Payload (3 floats): [depth, size, distinct_rules]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0.0):
        return v[i] if v.size > i else d
    depth = int(_g(0))
    size = int(_g(1))
    n_rules = int(_g(2))
    name = slot[len("soundness/"):] if slot.startswith("soundness/") else slot
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="147", kind="soundness",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"soundness {name} depth={depth} size={size} "
            f"rules={n_rules}"
        ),
        payload={
            "name": name, "depth": depth, "size": size,
            "distinct_rules": n_rules,
            "phase": float(cell.phase),
        },
    )


def _intervals_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``intervals/<name>`` (Zone 148).

    Payload (5 floats):
       [iterations, n_blocks, total_sound, total_unsound, ok]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0.0):
        return v[i] if v.size > i else d
    iters = int(_g(0))
    n_blocks = int(_g(1))
    sound = int(_g(2))
    unsound = int(_g(3))
    ok = bool(_g(4))
    name = slot[len("intervals/"):] if slot.startswith("intervals/") else slot
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="148", kind="intervals",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"intervals {name} iters={iters} blocks={n_blocks} "
            f"sound/unsound={sound}/{unsound} ok={ok}"
        ),
        payload={
            "name": name, "iterations": iters,
            "n_blocks": n_blocks, "sound": sound,
            "unsound": unsound, "successful": ok,
            "phase": float(cell.phase),
        },
    )


def _sparse_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``sparse/<name>`` (Zone 149).

    Payload (6 floats): [k, theoretical, populated, V, E, chi_local]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0.0):
        return v[i] if v.size > i else d
    k = int(_g(0))
    theoretical = int(_g(1))
    populated = int(_g(2))
    V = int(_g(3))
    E = int(_g(4))
    chi = int(_g(5))
    name = slot[len("sparse/"):] if slot.startswith("sparse/") else slot
    util = (populated / theoretical) if theoretical else 0.0
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="149", kind="sparse",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"sparse {name} k={k} pop={populated}/2^{k} "
            f"V={V} E={E} χ_local={chi}"
        ),
        payload={
            "name": name, "k": k,
            "theoretical": theoretical, "populated": populated,
            "utilisation": util,
            "V_local": V, "E_local": E, "chi_local": chi,
            "phase": float(cell.phase),
        },
    )


def _bench_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``bench/<name>`` (Zone 150).

    Payload (3 floats): [elapsed_ms, ratio_to_baseline, passed]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0.0):
        return v[i] if v.size > i else d
    elapsed = float(_g(0))
    ratio = float(_g(1))
    passed = bool(_g(2))
    name = slot[len("bench/"):] if slot.startswith("bench/") else slot
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="150", kind="bench",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"bench {name} {elapsed:.2f}ms ×{ratio:.2f}base "
            f"passed={passed}"
        ),
        payload={
            "name": name, "elapsed_ms": elapsed,
            "ratio_to_baseline": ratio, "passed": passed,
            "phase": float(cell.phase),
        },
    )


def _z3verify_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``z3verify/<judgment>/<name>`` (Zone 151).

    Payload (4 floats):
        [verified, n_clauses, time_ms, counterexample_found]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0.0):
        return v[i] if v.size > i else d
    verified = bool(_g(0))
    n_clauses = int(_g(1))
    time_ms = float(_g(2))
    cex = bool(_g(3))
    body = (
        slot[len("z3verify/"):] if slot.startswith("z3verify/") else slot
    )
    parts = body.split("/", 1)
    judgment = parts[0] if parts else "?"
    name = parts[1] if len(parts) > 1 else ""
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="151", kind="z3verify",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"z3verify {judgment} {name} verified={verified} "
            f"clauses={n_clauses} t={time_ms:.2f}ms cex={cex}"
        ),
        payload={
            "judgment": judgment, "name": name,
            "verified": verified, "n_clauses": n_clauses,
            "time_ms": time_ms, "counterexample_found": cex,
            "phase": float(cell.phase),
        },
    )


def _loop_ifc_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``loop_ifc/<form>/<program>`` (Zone 154).

    Payload (4 floats):
        [count_a, count_b, leaked, verdict_index]

    ``verdict_index`` corresponds to the position of the verdict in
    ``IFCVerdict`` (proven_ni=0, ni_if_low_params=1,
    ni_if_low_writes=2, ni_if_low_transfers=3,
    ni_if_low_touches=4, empirical=5).
    """
    v = np.asarray(cell.value, dtype=float).ravel()

    def _g(i, d=0.0):
        return v[i] if v.size > i else d

    count_a = int(_g(0))
    count_b = int(_g(1))
    leaked = bool(_g(2))
    verdict_index = int(_g(3))
    body = (
        slot[len("loop_ifc/"):] if slot.startswith("loop_ifc/")
        else slot
    )
    parts = body.split("/", 1)
    form = parts[0] if parts else "?"
    program = parts[1] if len(parts) > 1 else ""
    verdict_names = [
        "proven_ni", "ni_if_low_params", "ni_if_low_writes",
        "ni_if_low_transfers", "ni_if_low_touches", "empirical",
    ]
    verdict = (
        verdict_names[verdict_index]
        if 0 <= verdict_index < len(verdict_names) else "?"
    )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="154", kind="loop_ifc",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"loop_ifc {form}/{program} verdict={verdict} "
            f"counts={count_a}/{count_b} leaked={leaked}"
        ),
        payload={
            "form": form, "program": program,
            "verdict": verdict, "verdict_index": verdict_index,
            "count_a": count_a, "count_b": count_b,
            "leaked": leaked,
            "phase": float(cell.phase),
        },
    )


def _mem64_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``mem64/<name>`` (Zone 152).

    Payload (4 floats):
        [n_pages, n_cells_populated, utilisation, tlb_hit_rate]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0.0):
        return v[i] if v.size > i else d
    n_pages = int(_g(0))
    n_cells = int(_g(1))
    util = float(_g(2))
    tlb_rate = float(_g(3))
    name = slot[len("mem64/"):] if slot.startswith("mem64/") else slot
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="152", kind="mem64",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"mem64 {name} pages={n_pages} cells={n_cells} "
            f"util={util:.2e} tlb_hit={tlb_rate:.2%}"
        ),
        payload={
            "name": name, "n_pages": n_pages,
            "n_cells_populated": n_cells,
            "utilisation": util, "tlb_hit_rate": tlb_rate,
            "phase": float(cell.phase),
        },
    )


def _gradual_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``gradual/<label>`` (Zone 141).

    Payload (4 floats):
        [passed, failed, blamed_positive, blamed_negative]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0):
        return v[i] if v.size > i else d
    passed = int(_g(0))
    failed = int(_g(1))
    bp = int(_g(2))
    bn = int(_g(3))
    label = slot[len("gradual/"):] if slot.startswith("gradual/") else slot
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="141", kind="gradual",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"gradual {label} pass={passed} fail={failed} "
            f"+blame={bp} -blame={bn}"
        ),
        payload={
            "label": label, "passed": passed, "failed": failed,
            "blamed_positive": bp, "blamed_negative": bn,
            "phase": float(cell.phase),
        },
    )


def _contract_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``contract/<name>`` (Zone 142).

    Payload (4 floats):
        [passed, failed_positive, failed_negative, successful]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0):
        return v[i] if v.size > i else d
    passed = int(_g(0))
    fp = int(_g(1))
    fn_ = int(_g(2))
    ok = bool(_g(3))
    name = slot[len("contract/"):] if slot.startswith("contract/") else slot
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="142", kind="contract",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"contract {name} pass={passed} +blame={fp} -blame={fn_} "
            f"ok={ok}"
        ),
        payload={
            "name": name, "passed": passed,
            "failed_positive": fp, "failed_negative": fn_,
            "successful": ok, "phase": float(cell.phase),
        },
    )


def _posterior_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``posterior/<name>/<query>`` (Zone 143).

    Payload (4 floats): [mean, var, ess, n_particles]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0.0):
        return v[i] if v.size > i else d
    mean = float(_g(0))
    var = float(_g(1))
    ess = float(_g(2))
    n = int(_g(3))
    body = slot[len("posterior/"):] if slot.startswith("posterior/") else slot
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="143", kind="posterior",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"posterior {body} mean={mean:.3f} var={var:.3f} "
            f"ess={ess:.1f}/{n}"
        ),
        payload={
            "query": body, "mean": mean, "var": var,
            "ess": ess, "n_particles": n,
            "phase": float(cell.phase),
        },
    )


def _incremental_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``incremental/<run>`` (Zone 144).

    Payload (4 floats): [total, recomputed, skipped, time_ms]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0.0):
        return v[i] if v.size > i else d
    total = int(_g(0))
    recomp = int(_g(1))
    skipped = int(_g(2))
    t_ms = float(_g(3))
    name = slot[len("incremental/"):] if slot.startswith("incremental/") else slot
    skip_ratio = (skipped / total) if total else 0.0
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="144", kind="incremental",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"incremental {name} total={total} recomp={recomp} "
            f"skipped={skipped} ratio={skip_ratio:.2%}"
        ),
        payload={
            "name": name, "total": total, "recomputed": recomp,
            "skipped": skipped, "skip_ratio": skip_ratio,
            "time_ms": t_ms, "phase": float(cell.phase),
        },
    )


def _abstract_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``abstract/phi_<k>`` (Zone 145).

    Payload (4 floats): [op_index, sound, unsound, sound_flag]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0.0):
        return v[i] if v.size > i else d
    op = int(_g(0))
    sound = int(_g(1))
    unsound = int(_g(2))
    ok = bool(_g(3))
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="145", kind="abstract",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"abstract phi_{op} sound/unsound={sound}/{unsound} "
            f"ok={ok}"
        ),
        payload={
            "op_index": op, "sound": sound, "unsound": unsound,
            "successful": ok, "phase": float(cell.phase),
        },
    )


def _region_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``region/<name>/lifetime`` (Zone 140).

    Payload (4 floats): [lifetime, n_alloc, n_free, alive]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, d=0):
        return v[i] if v.size > i else d
    lifetime = int(_g(0))
    n_alloc = int(_g(1))
    n_free = int(_g(2))
    alive = bool(_g(3))
    body = slot[len("region/"):] if slot.startswith("region/") else slot
    parts = body.split("/", 1)
    name = parts[0] if parts else ""
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="140", kind="region",
        arena=arena_path.resolve().as_posix(), slot=slot,
        trust=float(cell.trust),
        summary=(
            f"region {name} lifetime={lifetime} alloc={n_alloc} "
            f"free={n_free} alive={alive}"
        ),
        payload={
            "name": name, "lifetime": lifetime,
            "n_alloc": n_alloc, "n_free": n_free,
            "alive": alive, "phase": float(cell.phase),
        },
    )


def _descent_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``descent/<fibration_name>/phi_<k>_<quantity>`` (Zone 130).

    Payload (9 floats):
        [op_index, degree, max_per_cell_residual, descends_flag,
         mean_per_cell_residual, source_chi_match, target_chi_match,
         equivariant_max_residual, equivariant_descends_flag]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, default=0):
        return v[i] if v.size > i else default
    op_index = int(_g(0))
    degree = int(_g(1))
    max_resid = float(_g(2))
    descends = bool(_g(3, 0))
    mean_resid = float(_g(4))
    s_chi = bool(_g(5, 0))
    t_chi = bool(_g(6, 0))
    eq_resid = float(_g(7, float("inf")))
    eq_descends = bool(_g(8, 0))
    body = slot[len("descent/") :] if slot.startswith("descent/") else slot
    parts = body.split("/")
    fib_name = parts[0] if parts else ""
    tail = parts[1] if len(parts) > 1 else ""
    import re as _re
    m = _re.match(r"phi_(\d+)_(.+)$", tail)
    qty = m.group(2) if m else ""
    summary = (
        f"descent  φ_{op_index} across {fib_name}  "
        f"const={descends} eq={eq_descends} "
        f"eq_resid={eq_resid:.2e}"
    )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="130",
        kind="descent",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "op_index": op_index,
            "degree": degree,
            "fibration_name": fib_name,
            "quantity": qty,
            "max_per_cell_residual": max_resid,
            "mean_per_cell_residual": mean_resid,
            "descends": descends,
            "source_chi_match": s_chi,
            "target_chi_match": t_chi,
            "equivariant_max_residual": eq_resid,
            "equivariant_descends": eq_descends,
            "phase": float(cell.phase),
        },
    )


def _fibration_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot: ``fibration/<name>`` (Zone 129).

    Payload (11 floats):
        [degree, V_src, V_tgt, E_src, E_tgt, χ₁_src, χ₁_tgt,
         χ₂_src, χ₂_tgt, chi1_mult, chi2_mult]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    def _g(i, default=0):
        return v[i] if v.size > i else default
    degree = int(_g(0))
    V_src, V_tgt = int(_g(1)), int(_g(2))
    E_src, E_tgt = int(_g(3)), int(_g(4))
    chi1_src, chi1_tgt = int(_g(5)), int(_g(6))
    chi2_src, chi2_tgt = int(_g(7)), int(_g(8))
    chi1_mult = bool(_g(9, 0))
    chi2_mult = bool(_g(10, 0))
    name = slot[len("fibration/") :] if slot.startswith("fibration/") else slot
    kind = "quotient_z2" if name.startswith("quotient_z2") else (
        "cyclic_halving" if name.startswith("cyclic_halving") else "other"
    )
    chi1_ratio = (chi1_src / chi1_tgt) if chi1_tgt != 0 else float("nan")
    chi2_ratio = (chi2_src / chi2_tgt) if chi2_tgt != 0 else float("nan")
    summary = (
        f"{kind} {name} deg={degree} V {V_src}/{V_tgt} "
        f"χ₁_mult={chi1_mult} χ₂_mult={chi2_mult}"
    )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="129",
        kind="fibration",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "name": name, "kind_of_fibration": kind, "degree": degree,
            "V_src": V_src, "V_tgt": V_tgt,
            "E_src": E_src, "E_tgt": E_tgt,
            "chi_1_src": chi1_src, "chi_1_tgt": chi1_tgt,
            "chi_2_src": chi2_src, "chi_2_tgt": chi2_tgt,
            "chi1_multiplicative": chi1_mult,
            "chi2_multiplicative": chi2_mult,
            "chi1_ratio": chi1_ratio,
            "chi2_ratio": chi2_ratio,
            "phase": float(cell.phase),
        },
    )


def _signature_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot shape: ``signature/phi_<k>``.

    Payload: ``[kind_code, a_num, a_den, b, samples]``.
    ``kind_code``: 0 endo, 1 scale_up, 2 scale_down, 3 affine,
                   4 dynamic, 5 failed.
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    code = int(v[0]) if v.size > 0 else 5
    a_num = int(v[1]) if v.size > 1 else 0
    a_den = int(v[2]) if v.size > 2 else 1
    b = int(v[3]) if v.size > 3 else 0
    samples = int(v[4]) if v.size > 4 else 0
    kind_map = {0: "endo", 1: "scale_up", 2: "scale_down",
                3: "affine", 4: "dynamic", 5: "failed"}
    kind = kind_map.get(code, "failed")
    body = slot[len("signature/") :] if slot.startswith("signature/") else slot
    import re as _re
    m = _re.match(r"phi_(\d+)$", body)
    op_index = int(m.group(1)) if m else -1
    if kind == "endo":
        canonical = "endo"
    elif kind == "scale_up":
        canonical = f"scale_up_{a_num}"
    elif kind == "scale_down":
        canonical = f"scale_down_{a_den}"
    elif kind == "affine":
        canonical = f"affine_{a_num}_{a_den}_{b}"
    else:
        canonical = kind
    summary = f"signature φ_{op_index} = {canonical}  (samples={samples})"
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="126",
        kind="signature",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "op_index": op_index,
            "kind": kind,
            "canonical_name": canonical,
            "a_num": a_num,
            "a_den": a_den,
            "b": b,
            "samples": samples,
            "phase": float(cell.phase),
        },
    )


def _typed_closure_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot shape: ``typed_closure/<probe>/<quantity>/<dim>/<group_name>``.

    Payload (10 floats):
        [order, V, E, F, χ₁, χ₂, abelian, max_gen_order,
         cell_dim, num_generators]
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    order = int(v[0]) if v.size > 0 else -1
    Vv = int(v[1]) if v.size > 1 else -1
    Ee = int(v[2]) if v.size > 2 else -1
    Ff = int(v[3]) if v.size > 3 else -1
    chi1 = int(v[4]) if v.size > 4 else 0
    chi2 = int(v[5]) if v.size > 5 else 0
    abelian = bool(v[6]) if v.size > 6 else False
    max_gen = int(v[7]) if v.size > 7 else -1
    cell_dim = int(v[8]) if v.size > 8 else -1
    num_gens = int(v[9]) if v.size > 9 else -1
    enumerated = order > 0
    body = slot[len("typed_closure/") :] if slot.startswith("typed_closure/") else slot
    parts = body.split("/", 3)
    probe = parts[0] if len(parts) > 0 else ""
    quantity = parts[1] if len(parts) > 1 else ""
    dim_str = parts[2] if len(parts) > 2 else ""
    group_name = parts[3] if len(parts) > 3 else ""
    if enumerated:
        summary = (
            f"typed:{probe}/{quantity}/dim={cell_dim} "
            f"|G|={order} χ₁={chi1} abelian={abelian} gens={num_gens}"
        )
    else:
        summary = (
            f"typed:{probe}/{quantity}/dim={cell_dim} "
            f"(open) abelian={abelian} gens={num_gens}"
        )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="126",
        kind="typed_closure",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "capsule_probe": probe,
            "quantity": quantity,
            "cell_dim": cell_dim,
            "group_name": group_name,
            "enumerated": enumerated,
            "order": order if enumerated else None,
            "V": Vv if enumerated else None,
            "E": Ee if enumerated else None,
            "F": Ff if enumerated else None,
            "chi_1": chi1 if enumerated else None,
            "chi_2": chi2 if enumerated else None,
            "abelian": abelian,
            "max_generator_order": max_gen,
            "num_generators": num_gens,
            "phase": float(cell.phase),
        },
    )


def _closure_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot shape: ``closure/<probe>/<group_name>``.

    Payload: ``[order, V, E, F, χ₁, χ₂]`` — identical to Zone 117 topology
    cells but for the *symmetry group of a capsule* rather than the
    capsule itself.
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    order = int(v[0]) if v.size > 0 else 0
    Vv = int(v[1]) if v.size > 1 else 0
    Ee = int(v[2]) if v.size > 2 else 0
    Ff = int(v[3]) if v.size > 3 else 0
    chi1 = int(v[4]) if v.size > 4 else 0
    chi2 = int(v[5]) if v.size > 5 else 0
    abelian = bool(v[6]) if v.size > 6 else False
    max_gen_order = int(v[7]) if v.size > 7 else -1
    enumerated = order > 0
    body = slot[len("closure/") :] if slot.startswith("closure/") else slot
    probe, _, group_name = body.partition("/")
    if enumerated:
        summary = (
            f"closure:{probe}/{group_name} |G|={order} "
            f"(V,E,F)=({Vv},{Ee},{Ff}) χ₁={chi1} χ₂={chi2} "
            f"abelian={abelian}"
        )
    else:
        summary = (
            f"closure:{probe}/{group_name} (open) "
            f"abelian={abelian} max_gen_order={max_gen_order}"
        )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="125",
        kind="closure",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "capsule_probe": probe,
            "group_name": group_name,
            "enumerated": enumerated,
            "order": order if enumerated else None,
            "V": Vv if enumerated else None,
            "E": Ee if enumerated else None,
            "F": Ff if enumerated else None,
            "chi_1": chi1 if enumerated else None,
            "chi_2": chi2 if enumerated else None,
            "abelian": abelian,
            "max_generator_order": max_gen_order,
            "phase": float(cell.phase),
        },
    )


def _symmetry_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot shape: ``symmetry/<probe_name>/phi_<k>_<quantity>``.

    Cell value: ``[vertex_residual, edge_residual, face_residual, is_identity_alias]``.
    """
    v = np.asarray(cell.value, dtype=float).ravel()
    vertex_residual = float(v[0]) if v.size > 0 else float("nan")
    edge_residual = float(v[1]) if v.size > 1 else float("nan")
    face_residual = float(v[2]) if v.size > 2 else float("nan")
    is_identity_alias = bool(int(v[3])) if v.size > 3 else False
    body = slot[len("symmetry/") :] if slot.startswith("symmetry/") else slot
    probe, _, tail = body.partition("/")
    import re as _re
    m = _re.match(r"phi_(\d+)_(.+)$", tail)
    if m is not None:
        op_index = int(m.group(1))
        quantity = m.group(2)
    else:
        op_index = -1
        quantity = tail
    flavor = " (identity-alias)" if is_identity_alias else ""
    summary = (
        f"symmetry:{probe} φ_{op_index} preserves {quantity}{flavor} "
        f"v={vertex_residual:.1e} e={edge_residual:.1e} f={face_residual:.1e}"
    )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="124",
        kind="symmetry",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "capsule_probe": probe,
            "op_index": op_index,
            "quantity": quantity,
            "vertex_residual": vertex_residual,
            "edge_residual": edge_residual,
            "face_residual": face_residual,
            "is_identity_alias": is_identity_alias,
            "phase": float(cell.phase),
        },
    )


def _conservation_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    """Slot shape: ``conservation/phi_<k>/<quantity>``."""
    v = np.asarray(cell.value, dtype=float).ravel()
    residual = float(v[0]) if v.size > 0 else float("nan")
    trials = int(v[1]) if v.size > 1 else 0
    body = slot[len("conservation/") :] if slot.startswith("conservation/") else slot
    op_part, _, quantity = body.partition("/")
    op_index_str = op_part.replace("phi_", "")
    try:
        op_index = int(op_index_str)
    except ValueError:
        op_index = -1
    summary = (
        f"conservation:φ_{op_index} preserves {quantity} "
        f"residual={residual:.3e} trials={trials}"
    )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="120",
        kind="conservation",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "residual": residual,
            "trials": trials,
            "phase": float(cell.phase),
            "op_index": op_index,
            "quantity": quantity,
        },
    )


def _topology_entry(arena_path: Path, slot: str, cell) -> CatalogEntry:
    v = np.asarray(cell.value, dtype=float).ravel()
    order = int(v[0]) if v.size > 0 else 0
    Vv = int(v[1]) if v.size > 1 else 0
    Ee = int(v[2]) if v.size > 2 else 0
    Ff = int(v[3]) if v.size > 3 else 0
    chi1 = int(v[4]) if v.size > 4 else 0
    chi2 = int(v[5]) if v.size > 5 else 0
    name = slot[len("topology/") :] if slot.startswith("topology/") else slot
    summary = (
        f"topology:{name} |G|={order} (V,E,F)=({Vv},{Ee},{Ff}) "
        f"χ₁={chi1} χ₂={chi2}"
    )
    return CatalogEntry(
        id=_stable_id(arena_path.name, slot),
        zone="117",
        kind="topology",
        arena=arena_path.resolve().as_posix(),
        slot=slot,
        trust=float(cell.trust),
        summary=summary,
        payload={
            "order": order,
            "V": Vv,
            "E": Ee,
            "F": Ff,
            "chi_1": chi1,
            "chi_2": chi2,
            "phase": float(cell.phase),
            "probe_name": name,
        },
    )


def _derive_magnitude_entries(entries: list[CatalogEntry]) -> list[CatalogEntry]:
    """Synthetic Zone-121 rows: one per qualifying topology (see soilith_resonance)."""
    cat_dict = {"entries": [asdict(e) for e in entries]}
    resonances = find_resonances(cat_dict)
    topo_by_arena_slot: dict[tuple[str, str], CatalogEntry] = {
        (e.arena, e.slot): e for e in entries if e.kind == "topology"
    }
    out: list[CatalogEntry] = []
    for r in resonances:
        te = topo_by_arena_slot.get((r.arena, r.slot))
        if te is None:
            continue
        arena_path = Path(te.arena)
        arena_name = arena_path.name
        probe = str(r.payload.get("probe_name", r.slot.split("/")[-1]))
        mag_slot = f"magnitude/tier{r.tier}_{probe}"
        companions = conservation_witnesses(cat_dict, arena=te.arena)
        rich_ops = sorted(
            (
                {"op": op, "n_invariants": len(qts)}
                for op, qts in companions.items()
                if len(qts) >= 3
            ),
            key=lambda d: int(d["op"].split("_")[1]),
        )
        summary = (
            f"magnitude:tier{r.tier} topology={probe} score={r.score:.0f} "
            f"|G|={r.payload.get('order')} χ₁={r.payload.get('chi_1')} "
            f"gens≈{r.payload.get('generators_approx')}"
        )
        out.append(
            CatalogEntry(
                id=_stable_id(arena_name, mag_slot),
                zone="121",
                kind="magnitude",
                arena=te.arena,
                slot=mag_slot,
                trust=float(te.trust),
                summary=summary,
                payload={
                    "tier": r.tier,
                    "score": float(r.score),
                    "topology_slot": r.slot,
                    "probe_name": probe,
                    "order": int(r.payload.get("order", 0)),
                    "V": int(r.payload.get("V", 0)),
                    "E": int(r.payload.get("E", 0)),
                    "F": int(r.payload.get("F", 0)),
                    "chi_1": int(r.payload.get("chi_1", 0)),
                    "chi_2": int(r.payload.get("chi_2", 0)),
                    "generators_approx": int(r.payload.get("generators_approx", 0)),
                    "rationale": r.rationale,
                    "scale_zoom_semantics": (
                        "vertex=group_element; edge=one_generator_flip; "
                        "face=commuting_pair; χ=global_shape_constraint"
                    ),
                    "conservation_rich_ops": rich_ops,
                    "n_conservation_rich_ops": len(rich_ops),
                },
            )
        )
    return out


def scan_arena(arena_path: Path) -> list[CatalogEntry]:
    """Return catalog rows for every ``law/*`` and ``topology/*`` cell."""
    if not arena_path.exists():
        return []
    a = Arena.open(arena_path, autoflush=False)
    rows: list[CatalogEntry] = []
    for slot in sorted(a.keys()):
        if slot.startswith("law/"):
            rows.append(_law_entry(arena_path, slot, a[slot]))
        elif slot.startswith("topology/"):
            rows.append(_topology_entry(arena_path, slot, a[slot]))
        elif slot.startswith("conservation/"):
            rows.append(_conservation_entry(arena_path, slot, a[slot]))
        elif slot.startswith("symmetry/"):
            rows.append(_symmetry_entry(arena_path, slot, a[slot]))
        elif slot.startswith("closure/"):
            rows.append(_closure_entry(arena_path, slot, a[slot]))
        elif slot.startswith("signature/"):
            rows.append(_signature_entry(arena_path, slot, a[slot]))
        elif slot.startswith("typed_closure/"):
            rows.append(_typed_closure_entry(arena_path, slot, a[slot]))
        elif slot.startswith("finite_order/"):
            rows.append(_finite_order_entry(arena_path, slot, a[slot]))
        elif slot.startswith("round_trip/"):
            rows.append(_round_trip_entry(arena_path, slot, a[slot]))
        elif slot.startswith("composition_law/"):
            rows.append(_composition_law_entry(arena_path, slot, a[slot]))
        elif slot.startswith("pair_group/"):
            rows.append(_pair_group_entry(arena_path, slot, a[slot]))
        elif slot.startswith("fibration/"):
            rows.append(_fibration_entry(arena_path, slot, a[slot]))
        elif slot.startswith("descent/"):
            rows.append(_descent_entry(arena_path, slot, a[slot]))
        elif slot.startswith("separation/"):
            rows.append(_separation_entry(arena_path, slot, a[slot]))
        elif slot.startswith("linearity/"):
            rows.append(_linearity_entry(arena_path, slot, a[slot]))
        elif slot.startswith("capability/"):
            rows.append(_capability_entry(arena_path, slot, a[slot]))
        elif slot.startswith("ownership/"):
            rows.append(_ownership_entry(arena_path, slot, a[slot]))
        elif slot.startswith("refinement_check/"):
            rows.append(_refinement_check_entry(arena_path, slot, a[slot]))
        elif slot.startswith("session/"):
            rows.append(_session_entry(arena_path, slot, a[slot]))
        elif slot.startswith("effect/"):
            rows.append(_effect_entry(arena_path, slot, a[slot]))
        elif slot.startswith("ifc/"):
            rows.append(_ifc_entry(arena_path, slot, a[slot]))
        elif slot.startswith("concurrent/"):
            rows.append(_concurrent_entry(arena_path, slot, a[slot]))
        elif slot.startswith("region/"):
            rows.append(_region_entry(arena_path, slot, a[slot]))
        elif slot.startswith("gradual/"):
            rows.append(_gradual_entry(arena_path, slot, a[slot]))
        elif slot.startswith("contract/"):
            rows.append(_contract_entry(arena_path, slot, a[slot]))
        elif slot.startswith("posterior/"):
            rows.append(_posterior_entry(arena_path, slot, a[slot]))
        elif slot.startswith("incremental/"):
            rows.append(_incremental_entry(arena_path, slot, a[slot]))
        elif slot.startswith("abstract/"):
            rows.append(_abstract_entry(arena_path, slot, a[slot]))
        elif slot.startswith("weakmem/"):
            rows.append(_weakmem_entry(arena_path, slot, a[slot]))
        elif slot.startswith("soundness/"):
            rows.append(_soundness_entry(arena_path, slot, a[slot]))
        elif slot.startswith("intervals/"):
            rows.append(_intervals_entry(arena_path, slot, a[slot]))
        elif slot.startswith("sparse/"):
            rows.append(_sparse_entry(arena_path, slot, a[slot]))
        elif slot.startswith("bench/"):
            rows.append(_bench_entry(arena_path, slot, a[slot]))
        elif slot.startswith("z3verify/"):
            rows.append(_z3verify_entry(arena_path, slot, a[slot]))
        elif slot.startswith("mem64/"):
            rows.append(_mem64_entry(arena_path, slot, a[slot]))
        elif slot.startswith("loop_ifc/"):
            rows.append(_loop_ifc_entry(arena_path, slot, a[slot]))
    return rows


def build_manifest(arena_paths: list[Path]) -> dict[str, Any]:
    """Merge scans; duplicate ``(arena, slot)`` pairs keep the last write.

    Appends derived ``magnitude/*`` rows (Zone 121) after all arena
    scans — one per qualifying topology row, keyed by ``(arena, mag_slot)``.
    """
    by_key: dict[tuple[str, str], CatalogEntry] = {}
    for ap in arena_paths:
        for e in scan_arena(ap):
            by_key[(e.arena, e.slot)] = e
    base = sorted(by_key.values(), key=lambda r: (r.zone, r.kind, r.slot))
    magnitude = _derive_magnitude_entries(base)
    for me in magnitude:
        by_key[(me.arena, me.slot)] = me
    entries = sorted(by_key.values(), key=lambda r: (r.zone, r.kind, r.slot))
    return {
        "schema_version": SCHEMA_VERSION,
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "sources": [p.resolve().as_posix() for p in arena_paths],
        "counts": {
            "total": len(entries),
            "zone_116_laws": sum(1 for e in entries if e.zone == "116"),
            "zone_117_topology": sum(1 for e in entries if e.zone == "117"),
            "zone_120_conservation": sum(1 for e in entries if e.zone == "120"),
            "zone_121_magnitude": sum(1 for e in entries if e.zone == "121"),
            "zone_124_symmetry": sum(1 for e in entries if e.zone == "124"),
            "zone_125_closure": sum(1 for e in entries if e.zone == "125"),
            "zone_126_signature": sum(
                1 for e in entries if e.zone == "126" and e.kind == "signature"
            ),
            "zone_126_typed_closure": sum(
                1 for e in entries
                if e.zone == "126" and e.kind == "typed_closure"
            ),
            "zone_127_finite_order": sum(
                1 for e in entries
                if e.zone == "127" and e.kind == "finite_order"
            ),
            "zone_127_round_trip": sum(
                1 for e in entries
                if e.zone == "127" and e.kind == "round_trip"
            ),
            "zone_127_composition_law": sum(
                1 for e in entries
                if e.zone == "127" and e.kind == "composition_law"
            ),
            "zone_127_pair_group": sum(
                1 for e in entries
                if e.zone == "127" and e.kind == "pair_group"
            ),
            "zone_129_fibration": sum(
                1 for e in entries
                if e.zone == "129" and e.kind == "fibration"
            ),
            "zone_130_descent": sum(
                1 for e in entries
                if e.zone == "130" and e.kind == "descent"
            ),
            "zone_131_separation": sum(
                1 for e in entries
                if e.zone == "131" and e.kind == "separation"
            ),
            "zone_132_linearity": sum(
                1 for e in entries
                if e.zone == "132" and e.kind == "linearity"
            ),
            "zone_133_capability": sum(
                1 for e in entries
                if e.zone == "133" and e.kind == "capability"
            ),
            "zone_134_ownership": sum(
                1 for e in entries
                if e.zone == "134" and e.kind == "ownership"
            ),
            "zone_135_refinement_check": sum(
                1 for e in entries
                if e.zone == "135" and e.kind == "refinement_check"
            ),
            "zone_136_session": sum(
                1 for e in entries
                if e.zone == "136" and e.kind == "session"
            ),
            "zone_137_effect": sum(
                1 for e in entries
                if e.zone == "137" and e.kind == "effect"
            ),
            "zone_138_ifc": sum(
                1 for e in entries
                if e.zone == "138" and e.kind == "ifc"
            ),
            "zone_139_concurrent": sum(
                1 for e in entries
                if e.zone == "139" and e.kind == "concurrent"
            ),
            "zone_140_region": sum(
                1 for e in entries
                if e.zone == "140" and e.kind == "region"
            ),
            "zone_141_gradual": sum(
                1 for e in entries
                if e.zone == "141" and e.kind == "gradual"
            ),
            "zone_142_contract": sum(
                1 for e in entries
                if e.zone == "142" and e.kind == "contract"
            ),
            "zone_143_posterior": sum(
                1 for e in entries
                if e.zone == "143" and e.kind == "posterior"
            ),
            "zone_144_incremental": sum(
                1 for e in entries
                if e.zone == "144" and e.kind == "incremental"
            ),
            "zone_145_abstract": sum(
                1 for e in entries
                if e.zone == "145" and e.kind == "abstract"
            ),
            "zone_146_weakmem": sum(
                1 for e in entries
                if e.zone == "146" and e.kind == "weakmem"
            ),
            "zone_147_soundness": sum(
                1 for e in entries
                if e.zone == "147" and e.kind == "soundness"
            ),
            "zone_148_intervals": sum(
                1 for e in entries
                if e.zone == "148" and e.kind == "intervals"
            ),
            "zone_149_sparse": sum(
                1 for e in entries
                if e.zone == "149" and e.kind == "sparse"
            ),
            "zone_150_bench": sum(
                1 for e in entries
                if e.zone == "150" and e.kind == "bench"
            ),
            "zone_151_z3verify": sum(
                1 for e in entries
                if e.zone == "151" and e.kind == "z3verify"
            ),
            "zone_152_mem64": sum(
                1 for e in entries
                if e.zone == "152" and e.kind == "mem64"
            ),
            "zone_154_loop_ifc": sum(
                1 for e in entries
                if e.zone == "154" and e.kind == "loop_ifc"
            ),
        },
        "entries": [asdict(e) for e in entries],
    }


def write_manifest(manifest: dict[str, Any], out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(manifest, indent=2, ensure_ascii=False) + "\n"
    out_path.write_text(text, encoding="utf-8")


def default_output_path() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Σoilith discovery catalog (Zone 118).")
    p.add_argument(
        "--arena",
        type=Path,
        action="append",
        default=[],
        help="arena file to scan (repeatable). Default: lawbook.arena next to this file.",
    )
    p.add_argument(
        "--out",
        type=Path,
        default=None,
        help="JSON output path (default: catalog/discoveries.json under Σoilith/).",
    )
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    root = Path(__file__).resolve().parent
    arenas = list(args.arena) if args.arena else [root / "lawbook.arena"]
    out = args.out if args.out is not None else default_output_path()

    manifest = build_manifest(arenas)
    write_manifest(manifest, out)
    c = manifest["counts"]
    print(
        f"# catalog v{SCHEMA_VERSION}: {c['total']} entries "
        f"(laws={c['zone_116_laws']}, "
        f"topology={c['zone_117_topology']}, "
        f"conservation={c.get('zone_120_conservation', 0)}, "
        f"magnitude={c.get('zone_121_magnitude', 0)}, "
        f"symmetry={c.get('zone_124_symmetry', 0)}, "
        f"closure={c.get('zone_125_closure', 0)}, "
        f"signature={c.get('zone_126_signature', 0)}, "
        f"typed={c.get('zone_126_typed_closure', 0)}, "
        f"finite_order={c.get('zone_127_finite_order', 0)}, "
        f"round_trip={c.get('zone_127_round_trip', 0)}, "
        f"comp_law={c.get('zone_127_composition_law', 0)}, "
        f"pair_group={c.get('zone_127_pair_group', 0)}, "
        f"fibration={c.get('zone_129_fibration', 0)}, "
        f"descent={c.get('zone_130_descent', 0)}, "
        f"separation={c.get('zone_131_separation', 0)}, "
        f"linear={c.get('zone_132_linearity', 0)}, "
        f"cap={c.get('zone_133_capability', 0)}, "
        f"ownership={c.get('zone_134_ownership', 0)}, "
        f"refcheck={c.get('zone_135_refinement_check', 0)}, "
        f"session={c.get('zone_136_session', 0)}, "
        f"effect={c.get('zone_137_effect', 0)}, "
        f"ifc={c.get('zone_138_ifc', 0)}, "
        f"concurrent={c.get('zone_139_concurrent', 0)}, "
        f"region={c.get('zone_140_region', 0)}, "
        f"gradual={c.get('zone_141_gradual', 0)}, "
        f"contract={c.get('zone_142_contract', 0)}, "
        f"posterior={c.get('zone_143_posterior', 0)}, "
        f"incremental={c.get('zone_144_incremental', 0)}, "
        f"abstract={c.get('zone_145_abstract', 0)}, "
        f"weakmem={c.get('zone_146_weakmem', 0)}, "
        f"soundness={c.get('zone_147_soundness', 0)}, "
        f"intervals={c.get('zone_148_intervals', 0)}, "
        f"sparse={c.get('zone_149_sparse', 0)}, "
        f"bench={c.get('zone_150_bench', 0)}, "
        f"z3verify={c.get('zone_151_z3verify', 0)}, "
        f"mem64={c.get('zone_152_mem64', 0)}, "
        f"loop_ifc={c.get('zone_154_loop_ifc', 0)}) → {out}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
