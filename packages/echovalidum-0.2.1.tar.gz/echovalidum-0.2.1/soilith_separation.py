"""
soilith_separation.py — separation logic on scale-aware memory
(Zone 131).

Iris-style separation logic gives you a *spatial* connective ``P * Q``
that holds on disjoint heap pieces, plus a frame rule that lets you
extend a triple ``{P} c {P'}`` to ``{P * R} c {P' * R}`` whenever
``c`` does not touch ``R``.

Σoilith's scale-aware memory is unusually well-suited to this
because:

* address space is a finite group (a ``ScaleAwareMemory`` is
  ``(ℤ/2)^k``; a ``PairGroupMemory`` is ``ℤ/n × ℤ/2``);
* "disjoint" means literal address-set disjointness;
* the Cayley adjacency rule from Zone 122 is exactly what you need
  for the *frame rule*: a write at ``addr`` only affects ``addr``
  and its k-neighbours, so any subset disjoint from a closed
  neighbourhood is automatically *framed*.

API
---
A heap **assertion** is a callable ``HeapAssertion(memory) -> bool``
together with an explicit **footprint**: the set of addresses on
which the predicate looks. Two assertions are ``disjoint`` iff
their footprints don't intersect; ``P * Q`` is then well-formed and
the runtime checker verifies both halves on the same memory and
returns the conjunction.

The classical points-to assertion ``addr ↦ v`` is provided as
``points_to(addr, predicate)``, where ``predicate`` is any
``Cell -> bool``. ``emp`` is the always-true assertion with empty
footprint.

The frame rule is checked *empirically*: given a command (a function
``mem -> mem``), an assertion ``R``, and the command's claimed
write set ``W``, we verify that ``R``'s footprint is disjoint from
``W`` and that ``R`` evaluates the same way before and after the
command runs.

Persistence
-----------
A successful frame proof is persisted as
``separation/<command>/frame_<assertion>`` with a 4-float payload
``[footprint_size, write_set_size, disjoint, frame_holds]``. Trust
1.0 if both flags are 1.

CLI
---
    python soilith_separation.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any, Callable, Iterable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class SeparationError(Exception):
    """Base class for Zone 131 errors."""


class FootprintOverlap(SeparationError):
    """Two assertions in a `P * Q` overlap on at least one address."""


class FrameViolation(SeparationError):
    """A command violated the frame rule (modified an address it
    wasn't supposed to)."""


# ──────────────────────────────────────────────────────────────────────────
#  Assertions
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class HeapAssertion:
    """A heap predicate annotated with its footprint.

    Two assertions on the same memory are *disjoint* iff their
    footprints don't intersect. The separating conjunction
    ``P * Q`` is well-formed iff ``P`` and ``Q`` are disjoint, and
    its truth value is ``P(mem) ∧ Q(mem)``.
    """

    name: str
    predicate: Callable[[Any], bool]
    footprint: frozenset[Any]

    def __call__(self, memory: Any) -> bool:
        return bool(self.predicate(memory))

    # Operator overloading so users can write ``p * q``.
    def __mul__(self, other: "HeapAssertion") -> "HeapAssertion":
        return sep_conj(self, other)


def emp() -> HeapAssertion:
    """The always-true assertion with empty footprint."""
    return HeapAssertion(
        name="emp",
        predicate=lambda mem: True,
        footprint=frozenset(),
    )


def points_to(
    addr: Any,
    predicate: Callable[[Cell | None], bool] | None = None,
    *,
    label: str | None = None,
) -> HeapAssertion:
    """``addr ↦? value`` style assertion. ``predicate`` defaults to
    "the address holds *some* cell"."""
    if predicate is None:
        predicate = lambda c: c is not None  # noqa: E731
    name = label or f"points_to({addr!r})"

    def check(memory: Any) -> bool:
        return predicate(memory.read(addr))

    return HeapAssertion(name=name, predicate=check,
                         footprint=frozenset({addr}))


def at_trust(addr: Any, *, gte: float) -> HeapAssertion:
    """``addr ↦ Cell(_, trust ≥ gte)`` — the Σoilith analog of a
    fractional permission."""
    def check_cell(c: Cell | None) -> bool:
        return c is not None and float(c.trust) >= gte

    return points_to(addr, check_cell, label=f"trust({addr!r}) ≥ {gte}")


def in_orbit_of(addr: Any, mem: Any) -> HeapAssertion:
    """An assertion whose footprint is the entire Cayley orbit of
    ``addr`` (the connected component reachable by adjacency steps).
    Useful when reasoning about a sub-capsule of a fibration."""
    seen = {addr}
    frontier = [addr]
    while frontier:
        a = frontier.pop()
        for b in mem.neighbors(a):
            if b not in seen:
                seen.add(b)
                frontier.append(b)
    return HeapAssertion(
        name=f"orbit({addr!r})",
        predicate=lambda m: True,
        footprint=frozenset(seen),
    )


def sep_conj(p: HeapAssertion, q: HeapAssertion) -> HeapAssertion:
    """Iris-style ``P * Q``. Refuses to construct if footprints
    overlap (the connective is *only* defined on disjoint heaps)."""
    overlap = p.footprint & q.footprint
    if overlap:
        raise FootprintOverlap(
            f"{p.name} and {q.name} overlap on {sorted(overlap)!r}"
        )
    return HeapAssertion(
        name=f"({p.name} * {q.name})",
        predicate=lambda m: p(m) and q(m),
        footprint=p.footprint | q.footprint,
    )


def sep_imp(p: HeapAssertion, q: HeapAssertion) -> Callable[[Any], bool]:
    """The magic wand ``P -∗ Q``: a function that, given a memory in
    which ``P`` holds on the disjoint frame, decides whether ``Q``
    would hold on the combined heap. Implemented as a check; not
    persisted because it's higher-order."""
    overlap = p.footprint & q.footprint

    def check(memory: Any) -> bool:
        if overlap and p(memory) and q(memory):
            return False
        return (not p(memory)) or q(memory)

    return check


# ──────────────────────────────────────────────────────────────────────────
#  Frame rule
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class FrameReport:
    command_name: str
    frame_name: str
    footprint_size: int
    write_set_size: int
    disjoint: bool
    frame_holds_before: bool
    frame_holds_after: bool

    @property
    def frame_holds(self) -> bool:
        return (
            self.disjoint
            and self.frame_holds_before
            and self.frame_holds_after
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "command_name": self.command_name,
            "frame_name": self.frame_name,
            "footprint_size": self.footprint_size,
            "write_set_size": self.write_set_size,
            "disjoint": self.disjoint,
            "frame_holds_before": self.frame_holds_before,
            "frame_holds_after": self.frame_holds_after,
            "frame_holds": self.frame_holds,
        }

    def describe(self) -> str:
        ok = "✓" if self.frame_holds else "✗"
        return (
            f"FrameReport {ok}  {self.command_name}  with frame "
            f"{self.frame_name}\n"
            f"  footprint              = {self.footprint_size}\n"
            f"  write set              = {self.write_set_size}\n"
            f"  disjoint               = {self.disjoint}\n"
            f"  frame_holds_before     = {self.frame_holds_before}\n"
            f"  frame_holds_after      = {self.frame_holds_after}\n"
            f"  frame_holds            = {self.frame_holds}"
        )


def check_frame(
    memory: Any,
    command: Callable[[Any], None],
    *,
    write_set: Iterable[Any],
    frame: HeapAssertion,
    command_name: str = "<command>",
) -> FrameReport:
    """Run ``command`` and verify the frame rule for ``frame``.

    The command is allowed to mutate exactly the addresses in
    ``write_set``. ``frame`` must remain true before and after, and
    its footprint must be disjoint from the write set. We also check
    that ``command`` did not actually touch any address outside its
    declared write set (by snapshotting the relevant cells)."""
    ws = frozenset(write_set)
    disjoint = ws.isdisjoint(frame.footprint)
    pre = bool(frame(memory))

    # Snapshot frame cells so we can detect an out-of-bounds mutation.
    pre_state = {a: _copy_cell(memory.read(a)) for a in frame.footprint}

    command(memory)

    post = bool(frame(memory))
    untouched = all(
        _cells_equal(memory.read(a), pre_state[a])
        for a in frame.footprint
    )
    return FrameReport(
        command_name=command_name,
        frame_name=frame.name,
        footprint_size=len(frame.footprint),
        write_set_size=len(ws),
        disjoint=disjoint,
        frame_holds_before=pre,
        frame_holds_after=(post and untouched),
    )


def _copy_cell(c: Cell | None) -> Cell | None:
    if c is None:
        return None
    return Cell(value=np.asarray(c.value, dtype=float).copy(),
                trust=float(c.trust), phase=float(c.phase))


def _cells_equal(a: Cell | None, b: Cell | None) -> bool:
    if a is None and b is None:
        return True
    if a is None or b is None:
        return False
    if abs(a.trust - b.trust) > 1e-12 or abs(a.phase - b.phase) > 1e-12:
        return False
    av = np.asarray(a.value, dtype=float).ravel()
    bv = np.asarray(b.value, dtype=float).ravel()
    if av.shape != bv.shape:
        return False
    return bool(np.allclose(av, bv, atol=1e-12))


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(report: FrameReport, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(report.footprint_size),
        float(report.write_set_size),
        1.0 if report.disjoint else 0.0,
        1.0 if report.frame_holds else 0.0,
    ], dtype=float)
    slot = (
        f"separation/{_safe(report.command_name)}/"
        f"frame_{_safe(report.frame_name)}"
    )
    trust = 1.0 if report.frame_holds else 0.0
    arena[slot] = Cell(value=payload, trust=trust, phase=0.0)


def _safe(name: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in name)[:80]


# ──────────────────────────────────────────────────────────────────────────
#  CLI / Demo
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith separation logic (Zone 131)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    from soilith_memory import ScaleAwareMemory

    print("# Zone 131 — separation logic on (Z/2)^3")
    mem = ScaleAwareMemory(
        k=3, attested_V=8, attested_E=12, attested_F=3,
        attested_chi_1=-4, attested_chi_2=-1,
        probe_name="z2_cubed",
    )
    rng = np.random.default_rng(0)
    for addr in mem.positions():
        mem.write(addr, Cell(value=rng.standard_normal(4),
                              trust=1.0, phase=0.0))

    print("\n# 1. Build P (low-half plane) * Q (high-half plane)")
    low = HeapAssertion(
        name="low_plane",
        predicate=lambda m: all(
            (c := m.read(a)) is not None and float(c.trust) > 0.0
            for a in [a for a in m.positions() if a[0] == "0"]
        ),
        footprint=frozenset(a for a in mem.positions() if a[0] == "0"),
    )
    high = HeapAssertion(
        name="high_plane",
        predicate=lambda m: all(
            (c := m.read(a)) is not None and float(c.trust) > 0.0
            for a in [a for a in m.positions() if a[0] == "1"]
        ),
        footprint=frozenset(a for a in mem.positions() if a[0] == "1"),
    )
    pstar = sep_conj(low, high)
    print(f"   {pstar.name} holds = {pstar(mem)}")
    print(f"   footprint sizes  : low={len(low.footprint)}, "
          f"high={len(high.footprint)}, P*Q={len(pstar.footprint)}")

    print("\n# 2. Frame rule: a write to '011' should leave 'high_plane' alone")
    def write_to_011(m: Any) -> None:
        m.write("011", Cell(value=np.array([99.0, 99.0, 99.0, 99.0]),
                            trust=0.5, phase=0.0))

    report = check_frame(mem, write_to_011,
                         write_set={"011"}, frame=high,
                         command_name="write_011")
    print(report.describe())
    persist(report, args.arena)

    print("\n# 3. Frame rule violation (claim '111' is in W but actually "
          "touch '000')")
    def cheating_command(m: Any) -> None:
        m.write("000", Cell(value=np.zeros(4), trust=0.0, phase=0.0))

    bad_report = check_frame(mem, cheating_command,
                             write_set={"111"}, frame=low,
                             command_name="cheat_000")
    print(bad_report.describe())
    persist(bad_report, args.arena)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
