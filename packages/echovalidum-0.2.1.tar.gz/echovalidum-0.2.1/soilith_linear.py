"""
soilith_linear.py — linear and affine resource discipline (Zone 132).

Linear types ensure each resource is used *exactly once*; affine
types weaken that to *at most once*. Σoilith already has the
substrate (Cell + ψ-arena + transactions); Zone 132 adds the
discipline.

A ``LinearArena(arena, mode)`` wraps any arena-like object and:

* tracks a ``status`` for each slot — ``unused``, ``borrowed``,
  ``consumed``;
* refuses ``read`` of a consumed slot (linear violation);
* refuses ``write`` to a consumed slot (no resurrection);
* on ``move(src, dst)`` atomically copies the cell into ``dst`` and
  marks ``src`` as consumed;
* on ``borrow(slot)`` returns a one-shot view that *must* be
  followed by either ``release`` (back to unused) or ``move``.

In ``mode="linear"`` every unused slot must be eventually consumed;
``audit_drops()`` reports any leaks. In ``mode="affine"`` leaks
are allowed.

This is the resource discipline that Rust's ownership system,
linear-Haskell's `%1 ->` arrows, and session-types' linear
endpoints all rely on. Σoilith now has it as a memory-arena layer.

CLI
---
    python soilith_linear.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
import sys
from typing import Any, Callable, Iterable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class LinearError(Exception):
    """Base class for Zone 132 errors."""


class UseAfterConsume(LinearError):
    """Read or write to a slot that was already consumed."""


class DoubleConsume(LinearError):
    """Two ``move`` or ``consume`` operations on the same slot."""


class LinearLeak(LinearError):
    """A ``mode=linear`` arena ended with unused slots — caller failed
    to consume an obligation."""


# ──────────────────────────────────────────────────────────────────────────
#  Status
# ──────────────────────────────────────────────────────────────────────────
class Status(str, Enum):
    UNUSED = "unused"
    BORROWED = "borrowed"
    CONSUMED = "consumed"


# ──────────────────────────────────────────────────────────────────────────
#  LinearArena
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class LinearAuditReport:
    mode: str
    counts: dict[str, int]
    leaks: list[str] = field(default_factory=list)
    double_consumes: list[str] = field(default_factory=list)
    use_after_consumes: list[str] = field(default_factory=list)

    @property
    def successful(self) -> bool:
        if self.mode == "linear":
            return (not self.leaks
                    and not self.double_consumes
                    and not self.use_after_consumes)
        return (not self.double_consumes
                and not self.use_after_consumes)

    def describe(self) -> str:
        ok = "✓" if self.successful else "✗"
        out = [
            f"LinearAuditReport {ok}  mode={self.mode}",
            f"  unused   = {self.counts.get('unused', 0)}",
            f"  borrowed = {self.counts.get('borrowed', 0)}",
            f"  consumed = {self.counts.get('consumed', 0)}",
        ]
        if self.leaks:
            out.append(f"  leaks               = {self.leaks}")
        if self.double_consumes:
            out.append(f"  double_consumes     = {self.double_consumes}")
        if self.use_after_consumes:
            out.append(f"  use_after_consumes  = {self.use_after_consumes}")
        return "\n".join(out)


class LinearArena:
    """A linear/affine view over a backing dict-like store."""

    def __init__(
        self,
        backing: dict[str, Cell] | None = None,
        *,
        mode: str = "linear",
    ) -> None:
        if mode not in ("linear", "affine"):
            raise ValueError("mode must be 'linear' or 'affine'")
        self.mode = mode
        self._cells: dict[str, Cell] = dict(backing or {})
        self._status: dict[str, Status] = {
            k: Status.UNUSED for k in self._cells
        }
        self._double_consumes: list[str] = []
        self._use_after_consumes: list[str] = []

    # ── core operations ─────────────────────────────────────────────────
    def write(self, slot: str, cell: Cell) -> None:
        if self._status.get(slot) == Status.CONSUMED:
            self._use_after_consumes.append(slot)
            raise UseAfterConsume(
                f"write to consumed slot {slot!r}"
            )
        self._cells[slot] = cell
        self._status[slot] = Status.UNUSED

    def read(self, slot: str) -> Cell:
        st = self._status.get(slot)
        if st == Status.CONSUMED:
            self._use_after_consumes.append(slot)
            raise UseAfterConsume(f"read of consumed slot {slot!r}")
        if slot not in self._cells:
            raise KeyError(f"no slot {slot!r}")
        return self._cells[slot]

    def consume(self, slot: str) -> Cell:
        """Linear consume — the cell is taken and the slot may not be
        used again."""
        if self._status.get(slot) == Status.CONSUMED:
            self._double_consumes.append(slot)
            raise DoubleConsume(f"slot {slot!r} already consumed")
        cell = self.read(slot)
        self._status[slot] = Status.CONSUMED
        return cell

    def move(self, src: str, dst: str) -> None:
        """``dst ← src`` atomically; ``src`` becomes ``consumed``."""
        cell = self.consume(src)
        # Don't allow writing to a slot that is itself consumed.
        if self._status.get(dst) == Status.CONSUMED:
            self._use_after_consumes.append(dst)
            raise UseAfterConsume(
                f"move target {dst!r} is consumed"
            )
        self._cells[dst] = cell
        self._status[dst] = Status.UNUSED

    def borrow(self, slot: str) -> "Borrow":
        """Affine immutable borrow: get a one-shot read handle."""
        if self._status.get(slot) == Status.CONSUMED:
            self._use_after_consumes.append(slot)
            raise UseAfterConsume(
                f"borrow of consumed slot {slot!r}"
            )
        self._status[slot] = Status.BORROWED
        return Borrow(self, slot)

    def status(self, slot: str) -> Status:
        return self._status.get(slot, Status.CONSUMED)

    # ── audit ───────────────────────────────────────────────────────────
    def audit(self) -> LinearAuditReport:
        counts: dict[str, int] = {"unused": 0, "borrowed": 0, "consumed": 0}
        leaks: list[str] = []
        for slot, st in self._status.items():
            counts[st.value] += 1
            if st == Status.UNUSED and self.mode == "linear":
                leaks.append(slot)
            if st == Status.BORROWED:
                leaks.append(slot)
        return LinearAuditReport(
            mode=self.mode, counts=counts, leaks=leaks,
            double_consumes=list(self._double_consumes),
            use_after_consumes=list(self._use_after_consumes),
        )


class Borrow:
    """One-shot handle returned by ``LinearArena.borrow``."""

    def __init__(self, arena: LinearArena, slot: str) -> None:
        self._arena = arena
        self._slot = slot
        self._released = False

    def value(self) -> Cell:
        if self._released:
            raise LinearError(f"borrow on {self._slot!r} already released")
        return self._arena._cells[self._slot]

    def release(self) -> None:
        if self._released:
            return
        if self._arena._status.get(self._slot) == Status.BORROWED:
            self._arena._status[self._slot] = Status.UNUSED
        self._released = True

    def __enter__(self) -> "Borrow":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.release()


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(report: LinearAuditReport, slot_name: str,
            arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(report.counts.get("unused", 0)),
        float(report.counts.get("borrowed", 0)),
        float(report.counts.get("consumed", 0)),
        float(len(report.leaks)),
        float(len(report.double_consumes)),
        float(len(report.use_after_consumes)),
        1.0 if report.mode == "linear" else 0.0,
        1.0 if report.successful else 0.0,
    ], dtype=float)
    trust = 1.0 if report.successful else 0.0
    arena[f"linearity/{slot_name}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith linear/affine arena (Zone 132)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print("# Zone 132 — linear discipline on a ψ-arena")
    a = LinearArena(mode="linear")
    a.write("a", Cell(value=np.array([1.0]), trust=1.0, phase=0.0))
    a.write("b", Cell(value=np.array([2.0]), trust=1.0, phase=0.0))
    a.write("c", Cell(value=np.array([3.0]), trust=1.0, phase=0.0))
    print(f"   wrote a, b, c; statuses = {a._status}")

    print("\n# 1. consume 'a' once — fine")
    cell_a = a.consume("a")
    print(f"   consumed: {cell_a.value}")

    print("\n# 2. consume 'a' twice — caught")
    try:
        a.consume("a")
    except DoubleConsume as exc:
        print(f"   ✓ {type(exc).__name__}: {exc}")

    print("\n# 3. move 'b' -> 'd' (atomic copy + consume of source)")
    a.move("b", "d")
    print(f"   b status = {a.status('b')}, d status = {a.status('d')}")

    print("\n# 4. linear leak detection (we forgot 'c')")
    report = a.audit()
    print(report.describe())
    persist(report, "demo_leak", args.arena)

    print("\n# 5. fix leak by consuming 'c' and 'd'")
    a.consume("c")
    a.consume("d")
    final = a.audit()
    print(final.describe())
    persist(final, "demo_clean", args.arena)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
