"""
soilith_typed_closure.py — per-quantity, per-shape closures over the
discovered symmetry set (Zone 126, part 2).

Zone 125 closed the *entire* five-operator symmetry set under
composition and found an open non-abelian monoid because:

* two of the five were shape-changing (φ_2, φ_59) — not even
  endomorphisms of the cell space;
* the remaining three didn't commute and had no finite order at the
  probe horizon we used.

Zone 126 part 1 (``soilith_signature.py``) gave us empirical
categorical types for every φ-operator. Part 2 — this module — uses
those types to ask the **right** closure question, which is:

    For a fixed capsule probe ``P``, a fixed invariant ``Q``, and a
    fixed cell shape ``(n,)``, what is the closure of *exactly the
    operators that preserve Q on P at shape (n,) and are endos of
    (n,)*?

That is the only place where a finite group can possibly live. Zone
126 enumerates over ``(P, Q)`` from the catalog (Zone 124 symmetry
rows), buckets by signature (Zone 126 signatures), and runs Zone 125's
structural closure analyzer with a **probe horizon scaled to the cell
dimension** (``2·n``) so finite cyclic orders are not silently
discarded.

When a clean abelian finite group emerges, it is persisted at

    typed_closure/<probe>/<quantity>/<n>/<group_name>

with the same 8-float payload Zone 125 uses for ``closure/*`` cells
plus two extra floats ``[cell_dim, num_generators]`` so the catalog
remembers the shape it was certified on.

Headline finding (anticipated and verified below): φ_38 alone is a
cyclic rotation by 1 on length-``n`` vectors; the typed closure of
``{φ_38}`` at shape ``(n,)`` is the cyclic group ``ℤ/n``, with
``V = n``, ``E = n``, ``F = 0``, ``χ₁ = 0``. Zone 125's "non-abelian
open monoid" was an artifact of testing the wrong set; the *typed*
sub-closure recovers a real finite group inside the same symmetry
data.

CLI
---
    python soilith_typed_closure.py
    python soilith_typed_closure.py --probe z2_cubed --quantity l2
    python soilith_typed_closure.py --probe z2_cubed --quantity l2 --dim 8
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import json
from pathlib import Path
import re
import sys
from typing import Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_arena import Arena  # noqa: E402
from soilith_lang import Cell  # noqa: E402
from soilith_phi import PHI  # noqa: E402
from soilith_signature import (  # noqa: E402
    Signature,
    infer,
    infer_all,
)
from soilith_symmetry_closure import (  # noqa: E402
    SymmetryClosure,
    _commutator_residual,
    _generator_order,
    _is_shape_preserving,
    _slot_safe_name,
)
from soilith_topology import build_group  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Records
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class TypedClosure:
    """Closure of a *typed* subset of capsule symmetries.

    ``capsule_probe``  – the magnitude row (e.g. ``z2_cubed``).
    ``quantity``       – the invariant ``Q`` that selected the operators.
    ``cell_dim``       – the cell shape ``(n,)`` we certify the closure on.
    ``endo_indices``   – the φ-indices that survived the endo filter.
    ``closure``        – Zone 125 ``SymmetryClosure`` on the endo subset.
    ``notes``          – human-readable extras (which operators were
                         dropped and why).
    """

    capsule_probe: str
    quantity: str
    cell_dim: int
    endo_indices: list[int]
    closure: SymmetryClosure
    notes: list[str] = field(default_factory=list)

    @property
    def graph(self):
        return self.closure.graph

    def name(self) -> str:
        if self.graph is not None:
            return self.graph.name()
        return "open monoid (typed)"

    def describe(self) -> str:
        lines = [
            f"TypedClosure  capsule={self.capsule_probe}  Q={self.quantity}  "
            f"shape=({self.cell_dim},)",
            f"  endo_indices = {self.endo_indices}",
        ]
        for n in self.notes:
            lines.append(f"  · {n}")
        lines.append("  " + self.closure.describe().replace("\n", "\n  "))
        return "\n".join(lines)


# ──────────────────────────────────────────────────────────────────────────
#  Sample battery at a fixed cell dimension
# ──────────────────────────────────────────────────────────────────────────
def _samples_at_dim(n: int, *, trials: int = 8, seed: int = 42) -> list[np.ndarray]:
    rng = np.random.default_rng(seed)
    return [rng.standard_normal(n) * 0.7 for _ in range(trials)]


# ──────────────────────────────────────────────────────────────────────────
#  Closure of a typed (endo-only) subset
# ──────────────────────────────────────────────────────────────────────────
def _close_endo_subset(
    endo_indices: list[int],
    *,
    cell_dim: int,
    samples: list[np.ndarray] | None = None,
    trials: int = 8,
    seed: int = 42,
    tol: float = 1e-6,
    max_order: int | None = None,
    capsule_probe: str = "",
) -> SymmetryClosure:
    """Run Zone 125's structural analyzer on a *typed* (endo-only)
    subset, with a probe horizon scaled to the cell dimension."""
    if samples is None:
        samples = _samples_at_dim(cell_dim, trials=trials, seed=seed)
    probe_horizon = max(2 * cell_dim, 16)
    max_order = max_order if max_order is not None else max(4 * cell_dim, 16)
    notes: list[str] = []

    name_to_op = {f"phi_{k}": PHI[k] for k in endo_indices if k in PHI}

    shape_preserving: dict[int, bool] = {
        k: _is_shape_preserving(PHI[k], samples) for k in endo_indices
        if k in PHI
    }
    endos = [k for k, ok in shape_preserving.items() if ok]
    exo = [k for k, ok in shape_preserving.items() if not ok]
    if exo:
        notes.append(
            f"signature said endo but shape-mismatch at dim={cell_dim}: "
            + ", ".join(f"φ_{k}" for k in exo)
        )

    orders: dict[int, int | None] = {}
    for k in endo_indices:
        if k not in PHI:
            orders[k] = None
            continue
        if shape_preserving.get(k, False):
            orders[k] = _generator_order(
                PHI[k], samples,
                max_probe=probe_horizon, tol=tol,
            )
        else:
            orders[k] = None
    finite_orders = {k: n for k, n in orders.items() if n is not None}
    all_finite = (
        len(finite_orders) == len(endos) and len(endos) == len(endo_indices)
    )
    max_gen_order = max(finite_orders.values()) if finite_orders else -1

    commutators: dict[tuple[int, int], float] = {}
    for i, ka in enumerate(endos):
        for kb in endos[i + 1:]:
            resid = _commutator_residual(
                PHI[ka], PHI[kb], samples
            )
            commutators[(ka, kb)] = resid
    abelian = (
        all(v < tol for v in commutators.values())
        if commutators else True
    )

    graph = None
    finite_abelian = abelian and all_finite and len(endos) > 0
    if finite_abelian:
        endo_ops = {f"phi_{k}": PHI[k] for k in endos}
        try:
            graph = build_group(endo_ops, samples, max_order=max_order)
            if graph.order > max_order:
                graph = None
                notes.append(
                    f"enumeration exceeded max_order={max_order}"
                )
        except Exception as exc:
            notes.append(f"build_group raised {type(exc).__name__}: {exc}")
            graph = None

    return SymmetryClosure(
        capsule_probe=capsule_probe,
        generator_indices=sorted(endo_indices),
        generator_orders=orders,
        commutators=commutators,
        abelian=abelian,
        finite_abelian=finite_abelian and graph is not None,
        max_generator_order=int(max_gen_order),
        graph=graph,
        notes=notes,
        shape_preserving=shape_preserving,
    )


# ──────────────────────────────────────────────────────────────────────────
#  Catalog-driven discovery
# ──────────────────────────────────────────────────────────────────────────
def operators_for_probe_quantity(
    catalog: dict, probe: str, quantity: str,
) -> list[int]:
    """Pull every certified Zone-124 capsule-symmetry operator on
    (probe, quantity), excluding identity aliases."""
    seen: set[int] = set()
    for e in catalog.get("entries", []):
        if e.get("kind") != "symmetry":
            continue
        p = e.get("payload", {})
        if p.get("capsule_probe") != probe:
            continue
        if p.get("quantity") != quantity:
            continue
        if bool(p.get("is_identity_alias", False)):
            continue
        k = int(p.get("op_index", -1))
        if k in PHI:
            seen.add(k)
    return sorted(seen)


def filter_endos(
    indices: list[int],
    signatures: dict[int, Signature],
) -> tuple[list[int], list[int]]:
    """Split ``indices`` into ``(endos, non_endos)`` by Zone-126
    signature."""
    endos = [k for k in indices if signatures.get(k) and signatures[k].kind == "endo"]
    nonendo = [k for k in indices if k not in endos]
    return endos, nonendo


def close_per_quantity(
    catalog: dict,
    probe: str,
    quantity: str,
    *,
    cell_dim: int = 8,
    signatures: dict[int, Signature] | None = None,
    samples: list[np.ndarray] | None = None,
    tol: float = 1e-6,
) -> TypedClosure:
    """Build a typed closure on (probe, quantity, dim)."""
    if signatures is None:
        signatures = infer_all(sorted(PHI.keys()))
    all_indices = operators_for_probe_quantity(catalog, probe, quantity)
    endos, nonendo = filter_endos(all_indices, signatures)
    notes: list[str] = []
    if nonendo:
        names = [
            f"φ_{k}({signatures.get(k).canonical_name if signatures.get(k) else '?'})"
            for k in nonendo
        ]
        notes.append("excluded non-endo: " + ", ".join(names))

    closure = _close_endo_subset(
        endos,
        cell_dim=cell_dim,
        samples=samples,
        tol=tol,
        capsule_probe=probe,
    )
    return TypedClosure(
        capsule_probe=probe,
        quantity=quantity,
        cell_dim=cell_dim,
        endo_indices=endos,
        closure=closure,
        notes=notes,
    )


def probes_and_quantities(catalog: dict) -> list[tuple[str, str]]:
    """Distinct (probe, quantity) pairs in the symmetry table."""
    pairs: set[tuple[str, str]] = set()
    for e in catalog.get("entries", []):
        if e.get("kind") != "symmetry":
            continue
        p = e.get("payload", {})
        probe = p.get("capsule_probe", "")
        quantity = p.get("quantity", "")
        if probe and quantity:
            pairs.add((probe, quantity))
    return sorted(pairs)


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(arena_path: Path, tc: TypedClosure) -> None:
    """Write ``typed_closure/<probe>/<quantity>/<dim>/<group_name>``.

    Payload (10 floats):
        [order, V, E, F, χ₁, χ₂, abelian, max_gen_order,
         cell_dim, num_generators]

    Trust 1.0 if enumerated, 0.5 if open.
    """
    a = Arena.open(arena_path, autoflush=False)
    probe = tc.capsule_probe or "anonymous"
    quantity = tc.quantity or "unknown"
    name = _slot_safe_name(tc.name())
    slot = f"typed_closure/{probe}/{quantity}/{tc.cell_dim}/{name}"
    if tc.graph is not None:
        g = tc.graph
        payload = [
            float(g.order), float(g.V), float(g.E), float(g.F),
            float(g.euler_1), float(g.euler_2),
        ]
        trust = 1.0
    else:
        payload = [-1.0, -1.0, -1.0, -1.0, 0.0, 0.0]
        trust = 0.5
    payload.append(1.0 if tc.closure.abelian else 0.0)
    payload.append(float(tc.closure.max_generator_order))
    payload.append(float(tc.cell_dim))
    payload.append(float(len(tc.endo_indices)))
    a[slot] = Cell(
        value=np.array(payload, dtype=float),
        trust=float(trust),
        phase=0.0,
    )
    a.flush()


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_catalog() -> Path:
    return Path(__file__).resolve().parent / "catalog" / "discoveries.json"


def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith typed per-quantity closure (Zone 126)."
    )
    p.add_argument("--catalog", type=Path, default=_default_catalog())
    p.add_argument("--arena", type=Path, default=_default_arena())
    p.add_argument("--probe", default=None)
    p.add_argument("--quantity", default=None)
    p.add_argument("--dim", type=int, default=8)
    p.add_argument("--no-persist", action="store_true")
    args = p.parse_args(argv)

    if not args.catalog.exists():
        print(f"# no catalog at {args.catalog}; run soilith_catalog.py first.")
        return 1
    data = json.loads(args.catalog.read_text(encoding="utf-8"))
    pairs = probes_and_quantities(data)
    if args.probe:
        pairs = [(p, q) for (p, q) in pairs if p == args.probe]
    if args.quantity:
        pairs = [(p, q) for (p, q) in pairs if q == args.quantity]
    if not pairs:
        print("# no (probe, quantity) pairs matched filters.")
        return 1

    sigs = infer_all(sorted(PHI.keys()))

    closures: list[TypedClosure] = []
    for probe, quantity in pairs:
        tc = close_per_quantity(
            data, probe, quantity,
            cell_dim=args.dim, signatures=sigs,
        )
        print()
        print(tc.describe())
        closures.append(tc)

    if not args.no_persist and closures:
        for tc in closures:
            persist(args.arena, tc)
        print(f"\n# persisted {len(closures)} typed_closure/* cells → {args.arena}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
