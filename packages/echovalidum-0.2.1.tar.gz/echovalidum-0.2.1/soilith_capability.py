"""
soilith_capability.py — capability-style references over the
ψ-arena (Zone 133).

A *capability* is an unforgeable reference that bundles a target
(here: an arena slot) with a set of *rights* and a trust threshold.
Holding a capability lets you do exactly what its rights permit —
no more.

Σoilith's lattice on rights is a finite Boolean algebra
(``{read, write, consume, attenuate, mint}``); attenuation is
**meet** on rights and **min** on the trust threshold, so handing a
capability down a call chain can only weaken it. Revocation flips
a slot-keyed bit in a registry and instantly invalidates every
outstanding capability for that slot.

Capabilities are derived from a single root authority via
``mint(root, slot, rights)``; the root must itself hold the
``mint`` right. There is no global way to fabricate capabilities,
so the system is unforgeable in the usual capability-security sense
provided callers never share their root.

CLI
---
    python soilith_capability.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class CapabilityError(Exception):
    """Base class for Zone 133 errors."""


class InsufficientRights(CapabilityError):
    """Capability held doesn't include the requested right."""


class TrustTooLow(CapabilityError):
    """Cell trust below the capability's required threshold."""


class Revoked(CapabilityError):
    """Capability was issued for a slot that has been revoked."""


class UnauthorizedMint(CapabilityError):
    """Tried to mint a child without the parent's ``mint`` right."""


# ──────────────────────────────────────────────────────────────────────────
#  Rights lattice
# ──────────────────────────────────────────────────────────────────────────
RIGHTS = {"read", "write", "consume", "attenuate", "mint"}


def _normalise(rights: Any) -> frozenset[str]:
    if isinstance(rights, str):
        rights = {rights}
    out = frozenset(rights)
    bad = out - RIGHTS
    if bad:
        raise CapabilityError(f"unknown right(s): {sorted(bad)!r}")
    return out


# ──────────────────────────────────────────────────────────────────────────
#  Registry
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class CapabilityRegistry:
    """Tracks revoked slots; held by whoever owns the system root."""

    revoked: set[str] = field(default_factory=set)

    def revoke(self, slot: str) -> None:
        self.revoked.add(slot)

    def is_revoked(self, slot: str) -> bool:
        return slot in self.revoked


# ──────────────────────────────────────────────────────────────────────────
#  Capability
# ──────────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Capability:
    slot: str
    rights: frozenset[str]
    min_trust: float
    registry: CapabilityRegistry

    def has(self, right: str) -> bool:
        return right in self.rights and not self.registry.is_revoked(self.slot)

    def attenuate(
        self,
        *,
        rights: Any | None = None,
        min_trust: float | None = None,
    ) -> "Capability":
        """Lattice meet on rights + max on min_trust. Requires the
        ``attenuate`` right."""
        if "attenuate" not in self.rights:
            raise InsufficientRights(
                "missing 'attenuate' right; cannot weaken this cap"
            )
        new_rights = (
            self.rights & _normalise(rights)
            if rights is not None else self.rights
        )
        new_min = max(
            self.min_trust,
            float(min_trust) if min_trust is not None else self.min_trust,
        )
        return Capability(
            slot=self.slot,
            rights=new_rights,
            min_trust=new_min,
            registry=self.registry,
        )

    # ── operations on the underlying arena ─────────────────────────────
    def read(self, arena: Any) -> Cell:
        if self.registry.is_revoked(self.slot):
            raise Revoked(f"slot {self.slot!r} has been revoked")
        if "read" not in self.rights:
            raise InsufficientRights(
                f"capability for {self.slot!r} lacks 'read'"
            )
        cell = arena[self.slot] if hasattr(arena, "__getitem__") else \
            arena.read(self.slot)
        if float(cell.trust) < self.min_trust - 1e-12:
            raise TrustTooLow(
                f"cell trust {cell.trust:.3f} < capability "
                f"threshold {self.min_trust:.3f}"
            )
        return cell

    def write(self, arena: Any, cell: Cell) -> None:
        if self.registry.is_revoked(self.slot):
            raise Revoked(f"slot {self.slot!r} has been revoked")
        if "write" not in self.rights:
            raise InsufficientRights(
                f"capability for {self.slot!r} lacks 'write'"
            )
        if float(cell.trust) < self.min_trust - 1e-12:
            raise TrustTooLow(
                f"cell trust {cell.trust:.3f} < capability "
                f"threshold {self.min_trust:.3f}"
            )
        if hasattr(arena, "__setitem__"):
            arena[self.slot] = cell
        else:
            arena.write(self.slot, cell)


# ──────────────────────────────────────────────────────────────────────────
#  Mint
# ──────────────────────────────────────────────────────────────────────────
def root(slot: str, registry: CapabilityRegistry) -> Capability:
    """Manufacture the *root* capability for ``slot``. This is the
    only point in the system where a capability appears
    ex nihilo — every other capability must be derived from a
    capability that already holds the ``mint`` right."""
    return Capability(
        slot=slot,
        rights=_normalise(RIGHTS),
        min_trust=0.0,
        registry=registry,
    )


def mint(
    parent: Capability,
    *,
    slot: str | None = None,
    rights: Any,
    min_trust: float = 0.0,
) -> Capability:
    """Derive a child capability from ``parent``. ``slot`` defaults
    to the parent's slot. ``rights`` must be ⊆ parent.rights;
    ``min_trust`` must be ≥ parent.min_trust."""
    if "mint" not in parent.rights:
        raise UnauthorizedMint(
            "parent capability lacks 'mint' right"
        )
    target = slot if slot is not None else parent.slot
    if target != parent.slot:
        raise UnauthorizedMint(
            f"parent for {parent.slot!r} cannot mint child for {target!r}"
        )
    new_rights = _normalise(rights)
    if not new_rights.issubset(parent.rights):
        raise UnauthorizedMint(
            f"requested rights {sorted(new_rights)!r} not subset of "
            f"parent rights {sorted(parent.rights)!r}"
        )
    if float(min_trust) < parent.min_trust - 1e-12:
        raise UnauthorizedMint(
            f"requested min_trust {min_trust} < parent's "
            f"{parent.min_trust}"
        )
    return Capability(
        slot=target, rights=new_rights, min_trust=float(min_trust),
        registry=parent.registry,
    )


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist_capability(cap: Capability, arena_path: Path,
                       *, label: str = "default") -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    rights_bits = sum(
        (1 << i) for i, r in enumerate(sorted(RIGHTS)) if r in cap.rights
    )
    payload = np.array([
        float(rights_bits),
        float(cap.min_trust),
        1.0 if cap.registry.is_revoked(cap.slot) else 0.0,
        float(len(cap.rights)),
    ], dtype=float)
    out = f"capability/{cap.slot}/{label}"
    arena[out] = Cell(value=payload, trust=cap.min_trust, phase=0.0)


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith capabilities (Zone 133)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print("# Zone 133 — capability-style references")
    reg = CapabilityRegistry()
    store: dict[str, Cell] = {
        "ledger": Cell(value=np.array([1000.0]), trust=1.0, phase=0.0),
    }
    rt = root("ledger", reg)
    print(f"   root rights = {sorted(rt.rights)}, min_trust = {rt.min_trust}")

    print("\n# 1. Mint a read-only attenuated capability for an auditor")
    auditor = mint(rt, rights={"read", "attenuate"}, min_trust=0.85)
    val = auditor.read(store)
    print(f"   auditor read -> {val.value}")

    print("\n# 2. Auditor cannot write")
    try:
        auditor.write(store, Cell(value=np.array([0.0]),
                                  trust=1.0, phase=0.0))
    except InsufficientRights as exc:
        print(f"   ✓ {type(exc).__name__}: {exc}")

    print("\n# 3. Further attenuation drops the read right")
    blind = auditor.attenuate(rights={"attenuate"})
    try:
        blind.read(store)
    except InsufficientRights as exc:
        print(f"   ✓ blind.read failed: {exc}")

    print("\n# 4. Revocation invalidates the auditor")
    reg.revoke("ledger")
    try:
        auditor.read(store)
    except Revoked as exc:
        print(f"   ✓ {type(exc).__name__}: {exc}")

    print("\n# 5. Persist a capability proof")
    persist_capability(auditor, args.arena, label="auditor")
    print("   wrote capability/ledger/auditor to lawbook.arena")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
