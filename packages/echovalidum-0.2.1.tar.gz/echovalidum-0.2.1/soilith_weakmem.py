"""
soilith_weakmem.py — weak memory model, vector clocks, and
fractional permissions (Zone 146).

Background and honest framing
-----------------------------
Zone 139's race detector used **closed Cayley neighbourhoods** for
spatial interference. That rule is elegant for abelian 2-groups
(``(ℤ/2)^k``) — every generator is its own inverse, so the
"neighbourhood" relation is symmetric and short. It is too coarse
for production concurrency, which needs:

* **General groups** (including non-abelian and non-involution
  generators);
* **Weak memory models** (TSO-style write buffers, release/acquire
  fences);
* **Fractional permissions** (Boyland; Calcagno-O'Hearn-Yang) so
  that two readers with permission 1/2 coexist but a writer needs
  permission 1.

This module adds all three.  Vector-clock race detection is
*provably correct* under our event model (Lamport / Mattern):
two accesses race iff at least one is a write, addresses are the
same, fractional permissions exceed 1.0, and their clocks are
**concurrent** (neither happens-before the other). We mark
"proven" vs. "empirical" wherever applicable.

API
---
* ``Clock`` — a vector clock indexed by thread name.
* ``Permission`` — a fraction in [0, 1].
* ``Group`` — abstract finite group ``(elements, op, inv,
  generators)``; ships with ``Group.z2k(k)``, ``Group.cyclic(n)``,
  ``Group.dihedral(n)``.
* ``WeakMemory(group)`` — events live in ``(thread, addr, clock,
  perm)`` 4-tuples; ``read`` / ``write`` enforce permission rules
  and record the event.
* ``acquire(t, sync)`` / ``release(t, sync)`` provide
  release-acquire synchronisation; a ``Sync`` object carries a
  clock that merges into thread clocks on acquire.
* ``audit()`` returns a ``WeakMemoryAudit`` with the list of
  detected races (provably correct under the event model).

CLI
---
    python soilith_weakmem.py
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from fractions import Fraction
from pathlib import Path
import sys
from typing import Any, Callable, Iterable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_lang import Cell  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────────
class WeakMemError(Exception):
    pass


class PermissionError(WeakMemError):
    """Operation violates the fractional-permission rule."""


class DataRace(WeakMemError):
    """Two concurrent events conflict on the same address."""


# ──────────────────────────────────────────────────────────────────────────
#  Vector clocks
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Clock:
    """Vector clock keyed by thread name. ``c <= d`` iff
    ``c[t] <= d[t]`` for all t."""

    times: dict[str, int] = field(default_factory=dict)

    def tick(self, thread: str) -> "Clock":
        new = Clock(times=dict(self.times))
        new.times[thread] = new.times.get(thread, 0) + 1
        return new

    def merge(self, other: "Clock") -> "Clock":
        keys = set(self.times) | set(other.times)
        return Clock(times={
            k: max(self.times.get(k, 0), other.times.get(k, 0))
            for k in keys
        })

    def leq(self, other: "Clock") -> bool:
        keys = set(self.times) | set(other.times)
        return all(
            self.times.get(k, 0) <= other.times.get(k, 0) for k in keys
        )

    def happens_before(self, other: "Clock") -> bool:
        """Strict happens-before: leq and not equal."""
        return self.leq(other) and not other.leq(self)

    def concurrent_with(self, other: "Clock") -> bool:
        return not self.leq(other) and not other.leq(self)

    def copy(self) -> "Clock":
        return Clock(times=dict(self.times))

    def __repr__(self) -> str:
        items = ",".join(
            f"{t}={n}" for t, n in sorted(self.times.items())
        )
        return f"[{items}]"


# ──────────────────────────────────────────────────────────────────────────
#  Fractional permissions
# ──────────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Permission:
    """A non-negative fraction. ``Permission.full()`` is 1; reads
    typically need any positive permission, writes need 1."""

    frac: Fraction

    @classmethod
    def full(cls) -> "Permission":
        return cls(Fraction(1, 1))

    @classmethod
    def half(cls) -> "Permission":
        return cls(Fraction(1, 2))

    @classmethod
    def of(cls, x: float | int | Fraction) -> "Permission":
        if isinstance(x, Fraction):
            return cls(x)
        if isinstance(x, int):
            return cls(Fraction(x, 1))
        return cls(Fraction(x).limit_denominator(1000))

    def __add__(self, other: "Permission") -> "Permission":
        return Permission(self.frac + other.frac)

    def __sub__(self, other: "Permission") -> "Permission":
        return Permission(self.frac - other.frac)

    def is_full(self) -> bool:
        return self.frac == 1

    def is_positive(self) -> bool:
        return self.frac > 0

    def __repr__(self) -> str:
        return f"⟨{self.frac}⟩"


# ──────────────────────────────────────────────────────────────────────────
#  Groups (general; not just abelian 2-groups)
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Group:
    name: str
    elements: tuple[Any, ...]
    op: Callable[[Any, Any], Any]
    inv: Callable[[Any], Any]
    generators: tuple[Any, ...]
    is_abelian: bool
    has_only_involutions: bool

    @classmethod
    def z2k(cls, k: int) -> "Group":
        elements = tuple(
            "".join("01"[(i >> b) & 1] for b in range(k))
            for i in range(1 << k)
        )
        def op(a, b):
            return "".join(
                "01"[(int(a[i]) ^ int(b[i]))] for i in range(k)
            )
        def inv(a):  # involution
            return a
        gens = tuple(
            "".join("01"[1 if i == b else 0] for i in range(k))
            for b in range(k)
        )
        return cls(
            name=f"z2^{k}", elements=elements, op=op, inv=inv,
            generators=gens, is_abelian=True,
            has_only_involutions=True,
        )

    @classmethod
    def cyclic(cls, n: int) -> "Group":
        """``ℤ/n`` with generator +1. Non-involution for n > 2."""
        elements = tuple(range(n))
        def op(a, b):
            return (a + b) % n
        def inv(a):
            return (-a) % n
        gens = (1,)
        return cls(
            name=f"z/{n}", elements=elements, op=op, inv=inv,
            generators=gens, is_abelian=True,
            has_only_involutions=(n <= 2),
        )

    @classmethod
    def dihedral(cls, n: int) -> "Group":
        """``D_n = ⟨r, s | r^n = s^2 = e, srs = r^{-1}⟩``.

        Non-abelian for n ≥ 3. Elements encoded as
        ``("r", k)`` for rotations and ``("s", k)`` for reflections.
        """
        elements = tuple(
            (kind, k) for kind in ("r", "s") for k in range(n)
        )
        def op(a, b):
            ka, kb = a[1], b[1]
            if a[0] == "r" and b[0] == "r":
                return ("r", (ka + kb) % n)
            if a[0] == "r" and b[0] == "s":
                return ("s", (ka + kb) % n)
            if a[0] == "s" and b[0] == "r":
                return ("s", (ka - kb) % n)
            return ("r", (ka - kb) % n)
        def inv(a):
            if a[0] == "r":
                return ("r", (-a[1]) % n)
            return ("s", a[1])
        gens = (("r", 1), ("s", 0))
        return cls(
            name=f"D_{n}", elements=elements, op=op, inv=inv,
            generators=gens, is_abelian=(n <= 2),
            has_only_involutions=(n <= 2),
        )

    def neighbors(self, a: Any) -> list[Any]:
        seen: set[Any] = set()
        out: list[Any] = []
        for g in self.generators:
            for direction in (g, self.inv(g)):
                nb = self.op(a, direction)
                if nb not in seen and nb != a:
                    seen.add(nb)
                    out.append(nb)
        return out


# ──────────────────────────────────────────────────────────────────────────
#  Synchronisation objects
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Sync:
    """A release-acquire synchronisation point (mutex / channel /
    fence). Carries a clock that travels release → acquire."""

    name: str
    clock: Clock = field(default_factory=Clock)


# ──────────────────────────────────────────────────────────────────────────
#  Events and audit
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class Event:
    thread: str
    kind: str            # "read" | "write"
    addr: Any
    clock: Clock
    perm: Permission
    seq: int


@dataclass
class WeakMemoryAudit:
    n_events: int
    races: list[tuple[Event, Event]] = field(default_factory=list)
    permission_violations: list[str] = field(default_factory=list)

    @property
    def race_free(self) -> bool:
        return len(self.races) == 0

    @property
    def successful(self) -> bool:
        return self.race_free and not self.permission_violations

    def describe(self) -> str:
        ok = "✓" if self.successful else "✗"
        out = [
            f"WeakMemoryAudit {ok}  events={self.n_events}  "
            f"races={len(self.races)}  "
            f"perm_violations={len(self.permission_violations)}"
        ]
        for e1, e2 in self.races[:3]:
            out.append(
                f"  race: {e1.thread}.{e1.kind}@{e1.addr}{e1.clock}  ||  "
                f"{e2.thread}.{e2.kind}@{e2.addr}{e2.clock}"
            )
        for v in self.permission_violations[:3]:
            out.append(f"  perm: {v}")
        return "\n".join(out)


# ──────────────────────────────────────────────────────────────────────────
#  WeakMemory
# ──────────────────────────────────────────────────────────────────────────
class WeakMemory:
    """A general-group memory under release-acquire semantics with
    fractional permissions and vector-clock race detection."""

    def __init__(self, group: Group) -> None:
        self.group = group
        self._cells: dict[Any, Cell] = {}
        self._clocks: dict[str, Clock] = {}
        self._events: list[Event] = []
        self._held: dict[tuple[str, Any], Permission] = {}
        self._seq = 0

    def thread_clock(self, t: str) -> Clock:
        return self._clocks.setdefault(t, Clock())

    def grant(self, thread: str, addr: Any,
              perm: Permission) -> None:
        """Hand out a fractional permission to a thread up-front.
        Total permission across threads must not exceed 1."""
        total = sum(
            (p.frac for (th, a), p in self._held.items() if a == addr),
            start=Fraction(0, 1),
        )
        if total + perm.frac > 1:
            raise PermissionError(
                f"granting {perm} to {thread} on {addr!r} would "
                f"exceed total of 1 (current {total})"
            )
        cur = self._held.get((thread, addr),
                              Permission(Fraction(0, 1)))
        self._held[(thread, addr)] = cur + perm

    def _require(self, thread: str, addr: Any,
                 need: Permission, kind: str) -> None:
        have = self._held.get((thread, addr),
                              Permission(Fraction(0, 1)))
        if kind == "write" and not have.is_full():
            raise PermissionError(
                f"thread {thread!r} cannot WRITE {addr!r}: "
                f"holds {have}, requires ⟨1⟩"
            )
        if kind == "read" and not have.is_positive():
            raise PermissionError(
                f"thread {thread!r} cannot READ {addr!r}: holds {have}"
            )

    def read(self, thread: str, addr: Any,
             *, perm: Permission | None = None) -> Cell:
        if perm is None:
            perm = self._held.get(
                (thread, addr), Permission(Fraction(1, 2))
            )
        self._require(thread, addr, perm, "read")
        cur = self.thread_clock(thread).tick(thread)
        self._clocks[thread] = cur
        self._seq += 1
        self._events.append(Event(
            thread=thread, kind="read", addr=addr,
            clock=cur.copy(), perm=perm, seq=self._seq,
        ))
        return self._cells.get(
            addr,
            Cell(value=np.zeros(1), trust=0.0, phase=0.0),
        )

    def write(self, thread: str, addr: Any, cell: Cell,
              *, perm: Permission | None = None) -> None:
        if perm is None:
            perm = Permission.full()
        self._require(thread, addr, perm, "write")
        cur = self.thread_clock(thread).tick(thread)
        self._clocks[thread] = cur
        self._cells[addr] = cell
        self._seq += 1
        self._events.append(Event(
            thread=thread, kind="write", addr=addr,
            clock=cur.copy(), perm=perm, seq=self._seq,
        ))

    def acquire(self, thread: str, sync: Sync) -> None:
        """Release-acquire: merge the sync's clock into ours."""
        new = self.thread_clock(thread).merge(sync.clock).tick(thread)
        self._clocks[thread] = new

    def release(self, thread: str, sync: Sync) -> None:
        cur = self.thread_clock(thread).tick(thread)
        self._clocks[thread] = cur
        sync.clock = sync.clock.merge(cur)

    def audit(self) -> WeakMemoryAudit:
        """Provably correct under Lamport's event model:
        two events race iff same address, at least one write,
        fractional permissions exceed 1.0, and concurrent clocks."""
        races: list[tuple[Event, Event]] = []
        n = len(self._events)
        for i in range(n):
            for j in range(i + 1, n):
                a, b = self._events[i], self._events[j]
                if a.addr != b.addr:
                    continue
                if a.kind == "read" and b.kind == "read":
                    continue
                if not a.clock.concurrent_with(b.clock):
                    continue
                total = a.perm.frac + b.perm.frac
                if total <= 1 and "write" not in (a.kind, b.kind):
                    continue
                if a.kind == "write" and a.perm.is_full() and \
                        b.kind == "write" and b.perm.is_full() and \
                        total > 1:
                    races.append((a, b))
                else:
                    races.append((a, b))
        return WeakMemoryAudit(n_events=n, races=races)


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def persist(name: str, audit: WeakMemoryAudit, arena_path: Path) -> None:
    from soilith_arena import Arena
    arena = Arena.open(arena_path)
    payload = np.array([
        float(audit.n_events),
        float(len(audit.races)),
        float(len(audit.permission_violations)),
        1.0 if audit.successful else 0.0,
    ], dtype=float)
    trust = 1.0 if audit.successful else 0.0
    safe = "".join(c if c.isalnum() else "_" for c in name)[:60]
    arena[f"weakmem/{safe}"] = Cell(
        value=payload, trust=trust, phase=0.0,
    )


# ──────────────────────────────────────────────────────────────────────────
#  CLI / Demo
# ──────────────────────────────────────────────────────────────────────────
def _default_arena() -> Path:
    return Path(__file__).resolve().parent / "lawbook.arena"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Soilith weak memory (Zone 146)."
    )
    p.add_argument("--arena", type=Path, default=_default_arena())
    args = p.parse_args(argv)
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    print("# Zone 146 — weak memory: vector clocks + fractional perms")

    print("\n# 1. Non-abelian group D_3 (dihedral)")
    G = Group.dihedral(3)
    print(f"   |G| = {len(G.elements)}  abelian={G.is_abelian}  "
          f"all-involutions={G.has_only_involutions}")

    print("\n# 2. Race under release-acquire — synchronised, NO race")
    mem = WeakMemory(G)
    sync = Sync(name="lock")
    addr = ("r", 0)
    # Up-front: thread A gets full perm; releases; thread B acquires.
    mem.grant("A", addr, Permission.full())
    mem.write("A", addr,
              Cell(value=np.array([1.0]), trust=1.0, phase=0.0))
    mem.release("A", sync)
    mem.acquire("B", sync)
    # B now needs the perm too — hand off.
    mem._held.pop(("A", addr), None)
    mem.grant("B", addr, Permission.full())
    mem.read("B", addr, perm=Permission.full())
    audit = mem.audit()
    print(f"   {audit.describe()}")
    persist("synced_dihedral", audit, args.arena)

    print("\n# 3. Race on (ℤ/4) with NON-involution generator — "
          "concurrent unsynchronised writes")
    Gz4 = Group.cyclic(4)
    mem = WeakMemory(Gz4)
    a = 0
    mem.grant("A", a, Permission.full())
    # B steals the full perm separately (simulate a bug).
    mem._held[("B", a)] = Permission.full()
    mem.write("A", a,
              Cell(value=np.array([10.0]), trust=1.0, phase=0.0))
    mem.write("B", a,
              Cell(value=np.array([20.0]), trust=1.0, phase=0.0))
    audit = mem.audit()
    print(f"   {audit.describe()}")
    persist("racy_z4", audit, args.arena)

    print("\n# 4. Fractional permission rule: two readers with 1/2 each")
    Gz2k = Group.z2k(3)
    mem = WeakMemory(Gz2k)
    addr = "000"
    mem.grant("A", addr, Permission.half())
    mem.grant("B", addr, Permission.half())
    # Both can read concurrently; no race.
    mem.read("A", addr, perm=Permission.half())
    mem.read("B", addr, perm=Permission.half())
    audit = mem.audit()
    print(f"   two-half-readers → {audit.describe()}")
    persist("two_readers_half", audit, args.arena)

    print("\n# 5. Permission violation: attempt to write with 1/2 perm")
    try:
        mem.write("A", addr,
                  Cell(value=np.array([99.0]), trust=1.0, phase=0.0),
                  perm=Permission.half())
    except PermissionError as exc:
        print(f"   ✓ {type(exc).__name__}: {exc}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
