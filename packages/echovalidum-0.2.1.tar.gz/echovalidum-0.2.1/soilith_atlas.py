"""
soilith_atlas.py — Operator Algebra Atlas (Zone 127).

Zone 126 typed every φ-operator and pulled the cyclic group ``ℤ/n``
out of {φ_38}. Zone 127 turns that lens on the whole 29-endo subset
and asks four systematic questions, each producing its own catalog
row type:

* **finite-order scan** — for every endo and every cell dim in a
  sweep, find the smallest ``n`` with ``φ_k^n ≈ id``. Most endos turn
  out infinite-order; the ones that close are precious.

* **round-trip scan** — for every pair ``(a, b)`` whose signatures
  compose (output of ``b`` matches input of ``a``), measure
  ``‖φ_a(φ_b(x)) − x‖`` over a sample battery. Detects honest
  retractions (``identity`` round-trips) and almost-identities.

* **composition equivalence** — for every endo pair ``(i, j)`` at a
  fixed shape, test whether ``φ_i ∘ φ_j ≈ φ_k`` for some ``k`` in the
  algebra. When the answer is yes, persist a factorization law that
  the Zone 119 rewriter can use to collapse ``φ_i(φ_j(x))`` into a
  single ``φ_k(x)``.

* **pair-group discovery** — for every pair of *finite-order*
  *commuting* endos, build the abelian product group ``ℤ/a × ℤ/b``
  and persist it as a ``pair_group`` Cayley graph. This is where new
  finite groups beyond ``ℤ/n`` can live.

All four engines share a tiny common toolkit (``_safe_apply``,
``_l2``, ``_clusters_signature``) so the verdicts are numerically
consistent with Zone 117 and Zone 126.

CLI
---
    python soilith_atlas.py
    python soilith_atlas.py --dim 8 --no-pair-groups
    python soilith_atlas.py --finite-only
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass, field
from itertools import combinations
from pathlib import Path
import sys
from typing import Callable

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from soilith_arena import Arena  # noqa: E402
from soilith_lang import Cell  # noqa: E402
from soilith_phi import PHI  # noqa: E402
from soilith_signature import Signature, infer_all  # noqa: E402
from soilith_symmetry_closure import (  # noqa: E402
    _commutator_residual,
    _generator_order,
    _is_shape_preserving,
)
from soilith_topology import build_group  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────
#  Records
# ──────────────────────────────────────────────────────────────────────────
@dataclass
class FiniteOrder:
    op_index: int
    cell_dim: int
    order: int          # the empirical period, 0 if not found within horizon
    horizon: int        # the probe horizon used
    notes: list[str] = field(default_factory=list)


@dataclass
class RoundTrip:
    a: int               # outer
    b: int               # inner
    cell_dim: int
    output_dim: int      # size of φ_a(φ_b(x))
    is_identity: bool    # output_dim == cell_dim AND deviation ≤ tol
    deviation: float     # ‖φ_a(φ_b(x)) − x‖∞ averaged over samples; inf if
                         # composition isn't shape-back-to-(n,)
    kind: str            # "identity", "approx_identity", "endo_proper",
                         #  "shape_mismatch", "failed"
    notes: list[str] = field(default_factory=list)


@dataclass
class CompositionLaw:
    """``φ_i ∘ φ_j ≈ φ_k`` at a fixed cell shape."""
    i: int
    j: int
    k: int
    cell_dim: int
    residual: float      # ‖φ_i(φ_j(x)) − φ_k(x)‖∞ averaged over samples
    notes: list[str] = field(default_factory=list)


@dataclass
class PairGroup:
    a: int
    b: int
    cell_dim: int
    order_a: int
    order_b: int
    commute_residual: float
    order: int           # |G|
    V: int
    E: int
    F: int
    euler_1: int
    euler_2: int
    name: str
    notes: list[str] = field(default_factory=list)


# ──────────────────────────────────────────────────────────────────────────
#  Common toolkit
# ──────────────────────────────────────────────────────────────────────────
def _safe_apply(op: Callable, x: np.ndarray) -> np.ndarray | None:
    """Apply ``op``, ravel & realify the result; ``None`` on any failure
    (exception, complex output, non-finite values, raveling error)."""
    try:
        y = op(np.asarray(x, dtype=float))
    except Exception:
        return None
    if isinstance(y, tuple):
        parts = [np.asarray(p) for p in y]
        if any(np.iscomplexobj(p) for p in parts):
            return None
        try:
            y = np.concatenate([p.astype(float).ravel() for p in parts])
        except Exception:
            return None
    y = np.asarray(y)
    if np.iscomplexobj(y):
        return None
    try:
        y = y.astype(np.float64, copy=False).ravel()
    except Exception:
        return None
    if not np.all(np.isfinite(y)):
        return None
    return y


def _samples(dim: int, *, trials: int = 8, seed: int = 42) -> list[np.ndarray]:
    rng = np.random.default_rng(seed)
    return [rng.standard_normal(dim) * 0.7 for _ in range(trials)]


def _clusters_signature(values: list[np.ndarray], digits: int = 5) -> str:
    """Canonical hashable string for a list of arrays."""
    parts: list[str] = []
    for v in values:
        if v is None:
            parts.append("∅")
        else:
            parts.append(
                ",".join(f"{x:.{digits}g}" for x in np.asarray(v).ravel())
            )
    return " | ".join(parts)


# ──────────────────────────────────────────────────────────────────────────
#  1. Finite-order scan
# ──────────────────────────────────────────────────────────────────────────
def finite_order_scan(
    indices: list[int],
    *,
    dims: tuple[int, ...] = (4, 6, 8, 12),
    seed: int = 42,
    tol: float = 1e-6,
) -> list[FiniteOrder]:
    out: list[FiniteOrder] = []
    for n in dims:
        sams = _samples(n, seed=seed)
        horizon = max(2 * n, 16)
        for k in indices:
            if k not in PHI:
                continue
            op = PHI[k]
            if not _is_shape_preserving(op, sams):
                continue
            order = _generator_order(
                op, sams, max_probe=horizon, tol=tol,
            )
            out.append(FiniteOrder(
                op_index=k, cell_dim=n,
                order=int(order) if order is not None else 0,
                horizon=horizon,
                notes=[] if order is not None else ["no finite order ≤ horizon"],
            ))
    return out


# ──────────────────────────────────────────────────────────────────────────
#  2. Round-trip scan
# ──────────────────────────────────────────────────────────────────────────
def _compatible_pairs(
    signatures: dict[int, Signature],
    *,
    n: int,
) -> list[tuple[int, int]]:
    """``(a, b)`` such that ``len(φ_b(x))`` (for ``len(x)=n``) equals the
    input length that ``φ_a`` expects to map back to ``n``.

    Concretely: a inverse of b — output of ``φ_a∘φ_b`` lands back in
    ``(n,)``. We allow (scale_up, scale_down) and (scale_down,
    scale_up) and (endo, endo).
    """
    pairs: list[tuple[int, int]] = []
    kinds = {k: s.kind for k, s in signatures.items()}
    a_nums = {k: s.a_num for k, s in signatures.items()}
    a_dens = {k: s.a_den for k, s in signatures.items()}
    valid = {k for k, s in signatures.items() if s.kind != "failed"}
    for a in sorted(valid):
        for b in sorted(valid):
            if a == b:
                continue
            ka, kb = kinds[a], kinds[b]
            if ka == "endo" and kb == "endo":
                pairs.append((a, b))
            elif ka == "scale_down" and kb == "scale_up":
                if a_dens[a] == a_nums[b]:
                    pairs.append((a, b))
            elif ka == "scale_up" and kb == "scale_down":
                if a_nums[a] == a_dens[b]:
                    pairs.append((a, b))
    return pairs


def round_trip_scan(
    signatures: dict[int, Signature],
    *,
    cell_dim: int = 8,
    seed: int = 42,
    tol: float = 1e-4,
    approx_tol: float = 0.1,
) -> list[RoundTrip]:
    pairs = _compatible_pairs(signatures, n=cell_dim)
    sams = _samples(cell_dim, seed=seed)
    out: list[RoundTrip] = []
    for a, b in pairs:
        op_a, op_b = PHI[a], PHI[b]
        devs: list[float] = []
        output_dim = -1
        failed = False
        for x in sams:
            y = _safe_apply(op_b, x)
            if y is None:
                failed = True
                break
            z = _safe_apply(op_a, y)
            if z is None:
                failed = True
                break
            output_dim = z.size
            if z.size != x.size:
                devs.append(float("inf"))
            else:
                devs.append(float(np.linalg.norm(z - x, ord=np.inf)))
        if failed:
            out.append(RoundTrip(
                a=a, b=b, cell_dim=cell_dim,
                output_dim=-1, is_identity=False,
                deviation=float("inf"), kind="failed",
                notes=["operator failed during round-trip"],
            ))
            continue
        avg_dev = float(np.mean([d for d in devs if np.isfinite(d)]))
        if not devs or output_dim < 0:
            out.append(RoundTrip(
                a=a, b=b, cell_dim=cell_dim,
                output_dim=output_dim, is_identity=False,
                deviation=float("inf"), kind="failed",
                notes=["no usable round-trip samples"],
            ))
            continue
        if output_dim != cell_dim:
            out.append(RoundTrip(
                a=a, b=b, cell_dim=cell_dim,
                output_dim=output_dim, is_identity=False,
                deviation=float("inf"), kind="shape_mismatch",
                notes=[f"φ_{a}∘φ_{b} lands in dim {output_dim} ≠ {cell_dim}"],
            ))
            continue
        if avg_dev < tol:
            kind = "identity"
        elif avg_dev < approx_tol:
            kind = "approx_identity"
        else:
            kind = "endo_proper"
        out.append(RoundTrip(
            a=a, b=b, cell_dim=cell_dim,
            output_dim=output_dim,
            is_identity=(kind == "identity"),
            deviation=avg_dev, kind=kind,
            notes=[],
        ))
    return out


# ──────────────────────────────────────────────────────────────────────────
#  3. Composition-equivalence scan
# ──────────────────────────────────────────────────────────────────────────
def composition_equivalence_scan(
    endo_indices: list[int],
    *,
    cell_dim: int = 8,
    seed: int = 42,
    tol: float = 1e-6,
) -> list[CompositionLaw]:
    """For each ordered pair ``(i, j)`` of endos, test whether
    ``φ_i ∘ φ_j ≈ φ_k`` for some endo ``k`` (including the identity
    represented by k=-1).

    Returns one ``CompositionLaw`` per discovery; pairs that don't
    match any existing operator are silently dropped (Zone 119 doesn't
    care about new operators here — it only wants factorizations of
    existing ones)."""
    sams = _samples(cell_dim, seed=seed)
    # Precompute signatures of every candidate target operator.
    candidates: dict[int, list[np.ndarray]] = {}
    for k in endo_indices + [-1]:
        if k == -1:
            candidates[-1] = [np.asarray(x, dtype=float).copy() for x in sams]
            continue
        if k not in PHI:
            continue
        op = PHI[k]
        out: list[np.ndarray] = []
        ok = True
        for x in sams:
            y = _safe_apply(op, x)
            if y is None or y.shape != x.shape:
                ok = False
                break
            out.append(y)
        if ok:
            candidates[k] = out

    laws: list[CompositionLaw] = []
    for i in endo_indices:
        for j in endo_indices:
            op_i, op_j = PHI.get(i), PHI.get(j)
            if op_i is None or op_j is None:
                continue
            comp_outs: list[np.ndarray] = []
            ok = True
            for x in sams:
                y = _safe_apply(op_j, x)
                if y is None or y.shape != x.shape:
                    ok = False
                    break
                z = _safe_apply(op_i, y)
                if z is None or z.shape != x.shape:
                    ok = False
                    break
                comp_outs.append(z)
            if not ok:
                continue
            for k, target in candidates.items():
                if k == i and len(endo_indices) > 1:
                    # Skip the trivial "φ_i ∘ φ_j = φ_i" unless j is identity
                    # (we'll still match identity when applicable).
                    pass
                if any(c.shape != t.shape for c, t in zip(comp_outs, target)):
                    continue
                resid = float(np.mean([
                    np.linalg.norm(c - t, ord=np.inf)
                    for c, t in zip(comp_outs, target)
                ]))
                if resid < tol:
                    laws.append(CompositionLaw(
                        i=i, j=j, k=k, cell_dim=cell_dim,
                        residual=resid,
                        notes=([] if k != -1
                               else ["target = identity"]),
                    ))
                    break  # one match per (i, j) — take the first hit
    return laws


# ──────────────────────────────────────────────────────────────────────────
#  4. Pair-group discovery
# ──────────────────────────────────────────────────────────────────────────
def pair_group_scan(
    finite_indices: list[int],
    *,
    cell_dim: int = 8,
    seed: int = 42,
    tol: float = 1e-6,
    max_order: int = 64,
) -> list[PairGroup]:
    """For every commuting pair of *finite-order* endo operators, build
    the abelian product group and return one ``PairGroup`` record."""
    sams = _samples(cell_dim, seed=seed)
    horizon = max(2 * cell_dim, 16)
    # Pre-filter: each operator must have finite order at this dim.
    orders: dict[int, int] = {}
    for k in finite_indices:
        if k not in PHI:
            continue
        op = PHI[k]
        if not _is_shape_preserving(op, sams):
            continue
        n = _generator_order(op, sams, max_probe=horizon, tol=tol)
        if n is not None and n >= 2:
            orders[k] = n
    finite = sorted(orders.keys())

    out: list[PairGroup] = []
    for a, b in combinations(finite, 2):
        op_a, op_b = PHI[a], PHI[b]
        resid = _commutator_residual(op_a, op_b, sams)
        if resid > tol:
            continue
        ops = {f"phi_{a}": op_a, f"phi_{b}": op_b}
        try:
            graph = build_group(ops, sams, max_order=max_order)
        except Exception:
            continue
        if graph.order >= max_order:
            continue  # bounded out — not a real finite group
        out.append(PairGroup(
            a=a, b=b, cell_dim=cell_dim,
            order_a=orders[a], order_b=orders[b],
            commute_residual=resid,
            order=graph.order, V=graph.V, E=graph.E, F=graph.F,
            euler_1=graph.euler_1, euler_2=graph.euler_2,
            name=graph.name(),
            notes=[],
        ))
    return out


# ──────────────────────────────────────────────────────────────────────────
#  Persistence
# ──────────────────────────────────────────────────────────────────────────
def _open_arena(p: Path) -> Arena:
    return Arena.open(p, autoflush=False)


def persist_finite_orders(arena_path: Path, rows: list[FiniteOrder]) -> None:
    a = _open_arena(arena_path)
    for r in rows:
        slot = f"finite_order/phi_{r.op_index}/dim_{r.cell_dim}"
        a[slot] = Cell(
            value=np.array([
                float(r.op_index), float(r.cell_dim),
                float(r.order), float(r.horizon),
            ], dtype=float),
            trust=1.0 if r.order > 0 else 0.5,
            phase=0.0,
        )
    a.flush()


def persist_round_trips(arena_path: Path, rows: list[RoundTrip]) -> None:
    a = _open_arena(arena_path)
    kind_codes = {
        "identity": 0, "approx_identity": 1, "endo_proper": 2,
        "shape_mismatch": 3, "failed": 4,
    }
    for r in rows:
        slot = f"round_trip/phi_{r.a}_of_phi_{r.b}/dim_{r.cell_dim}"
        a[slot] = Cell(
            value=np.array([
                float(r.a), float(r.b), float(r.cell_dim),
                float(r.output_dim),
                float(kind_codes.get(r.kind, 4)),
                float(r.deviation if np.isfinite(r.deviation) else -1.0),
            ], dtype=float),
            trust=1.0 if r.kind in ("identity",) else 0.7,
            phase=0.0,
        )
    a.flush()


def persist_composition_laws(arena_path: Path, rows: list[CompositionLaw]) -> None:
    a = _open_arena(arena_path)
    for r in rows:
        slot = f"composition_law/phi_{r.i}_of_phi_{r.j}/dim_{r.cell_dim}/phi_{r.k}"
        a[slot] = Cell(
            value=np.array([
                float(r.i), float(r.j), float(r.k),
                float(r.cell_dim), float(r.residual),
            ], dtype=float),
            trust=1.0,
            phase=0.0,
        )
    a.flush()


def persist_pair_groups(arena_path: Path, rows: list[PairGroup]) -> None:
    a = _open_arena(arena_path)
    for r in rows:
        slot = f"pair_group/phi_{r.a}_phi_{r.b}/dim_{r.cell_dim}/order_{r.order}"
        a[slot] = Cell(
            value=np.array([
                float(r.a), float(r.b), float(r.cell_dim),
                float(r.order_a), float(r.order_b),
                float(r.order), float(r.V), float(r.E), float(r.F),
                float(r.euler_1), float(r.euler_2),
                float(r.commute_residual),
            ], dtype=float),
            trust=1.0,
            phase=0.0,
        )
    a.flush()


# ──────────────────────────────────────────────────────────────────────────
#  CLI
# ──────────────────────────────────────────────────────────────────────────
def _print_section(title: str) -> None:
    print()
    print("─" * 72)
    print(f"  {title}")
    print("─" * 72)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(
        description="Σoilith Operator Algebra Atlas (Zone 127)."
    )
    p.add_argument(
        "--arena", type=Path,
        default=Path(__file__).resolve().parent / "lawbook.arena",
    )
    p.add_argument("--dim", type=int, default=8)
    p.add_argument("--dims", type=int, nargs="*", default=[4, 6, 8, 12])
    p.add_argument("--no-finite", action="store_true")
    p.add_argument("--no-round-trips", action="store_true")
    p.add_argument("--no-comp-laws", action="store_true")
    p.add_argument("--no-pair-groups", action="store_true")
    p.add_argument("--no-persist", action="store_true")
    args = p.parse_args(argv)

    sigs = infer_all(sorted(PHI.keys()))
    endos = [k for k, s in sigs.items() if s.kind == "endo"]

    if not args.no_finite:
        _print_section(
            f"Finite-order scan over {len(endos)} endos × {len(args.dims)} dims"
        )
        rows = finite_order_scan(endos, dims=tuple(args.dims))
        finite_rows = [r for r in rows if r.order > 0]
        print(f"   tested {len(rows)} (op, dim) pairs;"
              f" {len(finite_rows)} have finite order.")
        for r in finite_rows:
            print(f"     φ_{r.op_index:<3d} at dim {r.cell_dim:<3d} → order {r.order}")
        if not args.no_persist:
            persist_finite_orders(args.arena, rows)
            print(f"   → persisted {len(rows)} finite_order/* cells")

    if not args.no_round_trips:
        _print_section(f"Round-trip scan at dim={args.dim}")
        rows = round_trip_scan(sigs, cell_dim=args.dim)
        identities = [r for r in rows if r.kind == "identity"]
        approx = [r for r in rows if r.kind == "approx_identity"]
        print(f"   tested {len(rows)} (a, b) pairs;"
              f" {len(identities)} exact identity + {len(approx)} approx.")
        for r in identities[:12]:
            print(f"     φ_{r.a}(φ_{r.b}(x)) ≡ x  dev={r.deviation:.2e}")
        for r in approx[:12]:
            print(f"     φ_{r.a}(φ_{r.b}(x)) ≈ x  dev={r.deviation:.2e}")
        if not args.no_persist:
            persist_round_trips(args.arena, rows)
            print(f"   → persisted {len(rows)} round_trip/* cells")

    if not args.no_comp_laws:
        _print_section(f"Composition-equivalence scan at dim={args.dim}")
        rows = composition_equivalence_scan(endos, cell_dim=args.dim)
        print(f"   discovered {len(rows)} factorization laws.")
        for r in rows[:20]:
            tag = "id" if r.k == -1 else f"φ_{r.k}"
            print(f"     φ_{r.i}∘φ_{r.j} ≡ {tag}  resid={r.residual:.2e}")
        if not args.no_persist:
            persist_composition_laws(args.arena, rows)
            print(f"   → persisted {len(rows)} composition_law/* cells")

    if not args.no_pair_groups:
        _print_section(f"Pair-group discovery at dim={args.dim}")
        rows = pair_group_scan(endos, cell_dim=args.dim)
        print(f"   discovered {len(rows)} commuting finite-order endo pairs.")
        for r in rows[:20]:
            print(f"     (φ_{r.a}|order {r.order_a}, φ_{r.b}|order {r.order_b}) "
                  f"→ {r.name:<32s}  |G|={r.order} χ₁={r.euler_1}")
        if not args.no_persist:
            persist_pair_groups(args.arena, rows)
            print(f"   → persisted {len(rows)} pair_group/* cells")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
