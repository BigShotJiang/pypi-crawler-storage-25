"""Model browser package."""
