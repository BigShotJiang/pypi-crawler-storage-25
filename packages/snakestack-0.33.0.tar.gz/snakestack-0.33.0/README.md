# 🐍 SnakeStack

![Python](https://img.shields.io/badge/python->=3.10-blue)
![built with uv](https://img.shields.io/badge/built%20with-uv-blueviolet)
![Pipeline](https://github.com/BrunoSegato/snakestack/actions/workflows/ci.yml/badge.svg)
[![PyPI version](https://badge.fury.io/py/snakestack.svg)](https://pypi.org/project/snakestack/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![codecov](https://codecov.io/gh/BrunoSegato/snakestack/graph/badge.svg)](https://codecov.io/gh/BrunoSegato/snakestack)
![gitleaks badge](https://img.shields.io/badge/protected%20by-gitleaks-blue)

---

## 📦 Visão Geral

O `snakestack` é um pacote modular que oferece uma base robusta para construção de serviços backend com foco em:

- Observabilidade com OpenTelemetry
- Cache assíncrono com Redis
- Integração com Google Pub/Sub
- Acesso assíncrono ao MongoDB
- Client HTTPX com suporte a tracing
- Modelos base com `pydantic` e `pydantic-settings`
- Stack de logging estruturado e configurável

---

## ⚙️ Instalação

### Base

```bash
pip install snakestack
```

### Extras disponíveis

| Extra     | Comando de instalação               |
| --------- | ----------------------------------- |
| Redis     | `pip install snakestack[redis]`     |
| MongoDB   | `pip install snakestack[mongodb]`   |
| Pub/Sub   | `pip install snakestack[pubsub]`    |
| Telemetry | `pip install snakestack[telemetry]` |
| Todos     | `pip install snakestack[all]`       |

---

## 📚 Módulos disponíveis

| Módulo                  | Descrição                                                             | Extra        |
| ----------------------- | --------------------------------------------------------------------- | ------------ |
| `snakestack.logging`    | Logging estruturado com filtros, formatadores e propagação de request ID | —         |
| `snakestack.cache`      | Cliente Redis assíncrono com TTL, prefixo e serialização via `orjson` | `[redis]`    |
| `snakestack.pubsub`     | Publisher e subscriber para Google Pub/Sub com presets e tracing      | `[pubsub]`   |
| `snakestack.telemetry`  | Setup do OpenTelemetry com auto-instrumentação de HTTPX e logging     | `[telemetry]`|
| `snakestack.mongodb`    | Wrapper assíncrono para PyMongo com singleton de conexão              | `[mongodb]`  |
| `snakestack.healthz`    | Agregador de health checks com medição de latência por check          | —            |
| `snakestack.httpx`      | `AsyncClient` do HTTPX com composição de URL e normalização de erros  | —            |
| `snakestack.model`      | Modelos base Pydantic v2: `StrictModel`, `LenientModel`, `ORMModel`   | —            |
| `snakestack.task`       | Pool de workers assíncrono sobre `asyncio.Queue` com shutdown graceful| —            |
| `snakestack.config`     | Gerenciamento de settings com `pydantic-settings`                     | —            |

---

## 🧪 Exemplos de Uso

Os exemplos completos estão no diretório [`examples/`](examples/).

### Cache

| Arquivo | Descrição |
| ------- | --------- |
| [`cache/async_cache_service.py`](examples/cache/async_cache_service.py) | Uso básico do `AsyncRedisService` com diferentes tipos de valor |

### Healthz

| Arquivo | Descrição |
| ------- | --------- |
| [`healthz/sample_healthz.py`](examples/healthz/sample_healthz.py) | Health check com callbacks síncronos e assíncronos |
| [`healthz/sample_healthz_with_deps.py`](examples/healthz/sample_healthz_with_deps.py) | Health check verificando Redis e MongoDB |

### HTTPX

| Arquivo | Descrição |
| ------- | --------- |
| [`httpx/sample_use_httpx.py`](examples/httpx/sample_use_httpx.py) | Client HTTPX básico com composição de URL |
| [`httpx/sample_use_httpx_with_telemetry.py`](examples/httpx/sample_use_httpx_with_telemetry.py) | Client HTTPX com tracing via OpenTelemetry |

### Logging

| Arquivo | Descrição |
| ------- | --------- |
| [`logging/default_logging.py`](examples/logging/default_logging.py) | Formatter padrão |
| [`logging/with_request_id_logging.py`](examples/logging/with_request_id_logging.py) | Formatter com propagação de request ID |
| [`logging/custom_json_logging.py`](examples/logging/custom_json_logging.py) | Formatter JSON estruturado |
| [`logging/excluded_name_filter_logging.py`](examples/logging/excluded_name_filter_logging.py) | Filtro por nome do logger |
| [`logging/filter_path_logging.py`](examples/logging/filter_path_logging.py) | Filtro por path da requisição |

### MongoDB

| Arquivo | Descrição |
| ------- | --------- |
| [`mongodb/sample_mongodb.py`](examples/mongodb/sample_mongodb.py) | Conexão, consulta e encerramento com PyMongo assíncrono |

### Pub/Sub

| Arquivo | Descrição |
| ------- | --------- |
| [`pubsub/sample_publisher.py`](examples/pubsub/sample_publisher.py) | Publicação básica de mensagens |
| [`pubsub/sample_publisher_with_open_telemetry.py`](examples/pubsub/sample_publisher_with_open_telemetry.py) | Publicação com tracing |
| [`pubsub/sample_subscriber.py`](examples/pubsub/sample_subscriber.py) | Subscriber com `SimpleProcessor` |
| [`pubsub/sample_subscriber_with_batch.py`](examples/pubsub/sample_subscriber_with_batch.py) | Subscriber com `BatchProcessor` |
| [`pubsub/sample_subscriber_with_open_telemetry.py`](examples/pubsub/sample_subscriber_with_open_telemetry.py) | Subscriber com tracing |
| [`pubsub/sample_flow_control.py`](examples/pubsub/sample_flow_control.py) | Configuração de flow control |

### Settings

| Arquivo | Descrição |
| ------- | --------- |
| [`settings/sample_settings.py`](examples/settings/sample_settings.py) | Uso do `SnakeStackSettings` com override por env var |

### Task

| Arquivo | Descrição |
| ------- | --------- |
| [`task/sample_task.py`](examples/task/sample_task.py) | Worker pool básico |
| [`task/sample_task_with_sentinel.py`](examples/task/sample_task_with_sentinel.py) | Worker pool com sentinel de encerramento |
| [`task/sample_task_with_callback.py`](examples/task/sample_task_with_callback.py) | Worker pool com callback customizado |

### Telemetry

| Arquivo | Descrição |
| ------- | --------- |
| [`telemetry/sample_telemetry.py`](examples/telemetry/sample_telemetry.py) | Setup do OpenTelemetry com `instrument_app` |
| [`telemetry/sample_decorator_telemetry.py`](examples/telemetry/sample_decorator_telemetry.py) | Tracing via decorator `@instrumented_span` |

---

## 🛠️ Desenvolvimento Local

### 1. Clone o repositório

```bash
git clone https://github.com/BrunoSegato/snakestack.git
cd snakestack
```

### 2. Instale as dependências

```bash
uv sync --all-groups --all-extras
```

### 3. Instale os hooks de pre-commit

```bash
make hooks
```

### 4. Suba os serviços locais

```bash
docker-compose up -d
```

---

## 🧾 Comandos

| Comando                        | Descrição                                      |
| ------------------------------ | ---------------------------------------------- |
| `make install`                 | Instala apenas dependências de runtime         |
| `make lint`                    | Executa `ruff check`                           |
| `make format`                  | Executa `ruff check --fix`                     |
| `make mypy`                    | Executa `mypy` sem cache incremental           |
| `make check`                   | Executa lint + mypy                            |
| `make pre-commit`              | Executa todos os hooks de pre-commit           |
| `make test`                    | Executa todos os testes                        |
| `make test-unit`               | Executa apenas testes unitários                |
| `make test-matching test=nome` | Executa testes por nome com `-vv -s --pdb`     |
| `make release`                 | Bump de versão + changelog via commitizen      |
| `make publish`                 | Publica no PyPI                                |

---

## 🧪 Testes

O projeto possui cobertura completa de testes unitários organizados por domínio.

```bash
# Todos os testes
make test

# Apenas testes unitários
make test-unit

# Testes de um domínio específico
uv run pytest -m cache
uv run pytest -m pubsub
uv run pytest -m telemetry
uv run pytest -m mongodb

# Teste por nome
make test-matching test='nome_do_teste'
```
