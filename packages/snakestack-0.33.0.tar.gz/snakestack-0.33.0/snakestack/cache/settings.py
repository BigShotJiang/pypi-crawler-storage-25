from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class CacheSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SNAKESTACK_CACHE_")

    host: str = Field(
        default="localhost",
        description="Redis server hostname or IP address.",
    )
    port: int = Field(
        default=6379,
        description="Redis server port.",
    )
    db: int = Field(
        default=0,
        description="Redis database index to use.",
    )
    username: str | None = Field(
        default=None,
        description="Redis ACL username for authentication (Redis 6+). Must be set together with 'password'.",
    )
    password: str | None = Field(
        default=None,
        description="Redis authentication password.",
    )
