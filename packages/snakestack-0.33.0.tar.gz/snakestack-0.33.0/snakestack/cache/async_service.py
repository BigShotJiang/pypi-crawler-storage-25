from typing import Any, Self, cast

import orjson

try:
    from redis.asyncio import Redis
except ImportError:
    raise RuntimeError("Redis extra is not installed. Run `pip install snakestack[redis]`.")

from snakestack.cache.utils import deco_cache
from snakestack.logging.encoders import safe_jsonable_encoder


class AsyncRedisService:
    """Async service for common Redis operations with key prefixing, default TTL and JSON serialization."""

    def __init__(
        self: Self,
        client: Redis,
        default_ttl: int | None = None,
        prefix: str = "",
    ) -> None:
        """
        Args:
            client: Connected redis.asyncio.Redis instance.
            default_ttl: Default expiration time in seconds (optional).
            prefix: Optional key prefix for namespacing.
        """
        self._client = client
        self._default_ttl = default_ttl
        self._prefix = prefix.strip(":")

    def _format_key(self: Self, key: str) -> str:
        """Returns the key with prefix applied, if configured."""
        return f"{self._prefix}:{key}" if self._prefix else key

    @deco_cache(default=False)
    async def set(self: Self, key: str, value: Any, ex: int | None = None) -> bool:
        """Store a serialized value in Redis with optional TTL.

        Args:
            key: Key name.
            value: Value to serialize and store.
            ex: Expiration in seconds. Overrides default_ttl when provided,
                including when set to 0.

        Returns:
            True if stored successfully, False on error.
        """
        serialized = orjson.dumps(value, default=safe_jsonable_encoder)
        return bool(await self._client.set(
            name=self._format_key(key),
            value=serialized,
            ex=ex if ex is not None else self._default_ttl,
        ))

    @deco_cache(default=None)
    async def get(self: Self, key: str) -> Any | None:
        """Retrieve and deserialize a value from Redis.

        Args:
            key: Key name.

        Returns:
            Deserialized value or None if not found.
        """
        raw = await self._client.get(self._format_key(key))
        if raw is None:
            return None
        try:
            return orjson.loads(raw)
        except orjson.JSONDecodeError:
            return raw

    @deco_cache(default=0)
    async def delete(self: Self, key: str) -> int:
        """Delete a key from Redis. Returns 1 if removed, 0 if not found."""
        result = await self._client.delete(self._format_key(key))
        return cast(int, result)

    @deco_cache(default=False)
    async def exists(self: Self, key: str) -> bool:
        """Check whether a key exists in Redis."""
        return bool(await self._client.exists(self._format_key(key)))

    @deco_cache(default=False)
    async def expire(self: Self, key: str, ttl: int) -> bool:
        """Set an expiration time (in seconds) on a key."""
        return bool(await self._client.expire(self._format_key(key), ttl))

    @deco_cache(default=0)
    async def incr(self: Self, key: str, amount: int = 1) -> int:
        """Increment a numeric value stored at key."""
        result = await self._client.incr(self._format_key(key), amount)
        return cast(int, result)

    @deco_cache(default=0)
    async def decr(self: Self, key: str, amount: int = 1) -> int:
        """Decrement a numeric value stored at key."""
        result = await self._client.decr(self._format_key(key), amount)
        return cast(int, result)

    @deco_cache(default=0)
    async def ttl(self: Self, key: str) -> int:
        """Get the remaining expiration time of a key in seconds."""
        result = await self._client.ttl(self._format_key(key))
        return cast(int, result)

    @deco_cache(default=False)
    async def ping(self: Self) -> bool:
        """Check connectivity to Redis."""
        result = await self._client.ping()
        return cast(bool, result)
