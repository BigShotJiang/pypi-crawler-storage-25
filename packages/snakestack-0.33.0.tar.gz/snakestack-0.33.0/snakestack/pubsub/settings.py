from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class PubSubSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SNAKESTACK_PUBSUB_")
    project_id: str = Field(
        default="snakestack-project",
        description=""
    )
    subscription_name: str | None = Field(
        default=None,
        description=""
    )
    topic_name: str | None = Field(
        default=None,
        description=""
    )
    publisher_timeout: int = Field(
        default=5,
        description="Timeout in seconds for synchronous publish calls (future.result). Only used when no callback is provided."
    )
