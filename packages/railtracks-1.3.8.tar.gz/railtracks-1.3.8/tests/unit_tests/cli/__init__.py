# CLI unit tests
