import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from ins_pricing.frontend.ft_workflow import FTWorkflowHelper


def _prepare_step1_inputs(
    tmp_path: Path,
    *,
    ft_embedding_source_features=None,
    split_cache_path=None,
) -> Path:
    model_name = "od_bc"
    data_dir = tmp_path / "Data"
    data_dir.mkdir(parents=True, exist_ok=True)

    raw = pd.DataFrame(
        {
            "f1": [1, 2, 3, 4, 5],
            "f2": ["a", "b", "a", "c", "b"],
            "target": [0.1, 0.2, 0.3, 0.4, 0.5],
            "weights": [1.0, 1.0, 2.0, 2.0, 3.0],
        }
    )
    raw.to_csv(data_dir / f"{model_name}.csv", index=False)

    cfg = {
        "data_dir": "./Data",
        "output_dir": "./ResultsFT",
        "model_list": ["od"],
        "model_categories": ["bc"],
        "feature_list": ["f1", "f2"],
        "categorical_features": ["f2"],
        "target": "target",
        "weight": "weights",
        "prop_test": 0.4,
        "rand_seed": 13,
        "ft_feature_prefix": "ft_emb",
        "prediction_cache_format": "csv",
        "ft_search_space": {
            "d_model": {"type": "int", "low": 16, "high": 32, "step": 8},
        },
        "ft_unsupervised_search_space": {
            "d_model": {"type": "int", "low": 16, "high": 64, "step": 8},
        },
    }
    if ft_embedding_source_features is not None:
        cfg["ft_embedding_source_features"] = ft_embedding_source_features
    if split_cache_path is not None:
        cfg["split_cache_path"] = split_cache_path

    cfg_path = tmp_path / "temp_ft_step1_config.json"
    cfg_path.write_text(json.dumps(cfg), encoding="utf-8")

    pred_dir = tmp_path / "ResultsFT" / "Results" / "predictions"
    pred_dir.mkdir(parents=True, exist_ok=True)
    pred_train = pd.DataFrame({"pred_ft_emb_0": [0.1, 0.2, 0.3]})
    pred_test = pd.DataFrame({"pred_ft_emb_0": [0.4, 0.5]})
    pred_train.to_csv(pred_dir / f"{model_name}_ft_emb_train.csv", index=False)
    pred_test.to_csv(pred_dir / f"{model_name}_ft_emb_test.csv", index=False)

    return cfg_path


def test_generate_step2_configs_applies_overrides_and_saves_augmented_data(tmp_path, monkeypatch):
    helper = FTWorkflowHelper()
    cfg_path = _prepare_step1_inputs(tmp_path)

    def _fake_alignment(raw, cfg, *, pred_train_rows, pred_test_rows):
        return raw.index[:pred_train_rows], raw.index[pred_train_rows:pred_train_rows + pred_test_rows]

    monkeypatch.setattr(helper, "_resolve_prediction_alignment_indices", _fake_alignment)

    xgb_cfg, resn_cfg = helper.generate_step2_configs(
        step1_config_path=str(cfg_path),
        target_models=["xgb", "resn"],
        augmented_data_dir="./DataFTEmbed",
        xgb_overrides={
            "output_dir": "./ResultsXGBFromFTEmbed",
            "runner": {"nproc_per_node": 3},
            "xgb_max_depth_max": 7,
        },
        resn_overrides={
            "output_dir": "./ResultsResNFromFTEmbed",
            "runner": {"nproc_per_node": 4},
            "use_resn_ddp": False,
        },
    )

    assert xgb_cfg is not None
    assert resn_cfg is not None
    assert xgb_cfg["runner"]["nproc_per_node"] == 3
    assert xgb_cfg["xgb_max_depth_max"] == 7
    assert "optuna_storage" not in xgb_cfg
    assert resn_cfg["runner"]["nproc_per_node"] == 4
    assert resn_cfg["use_resn_ddp"] is False
    assert "optuna_storage" not in resn_cfg
    assert "max_depth" in xgb_cfg["xgb_search_space"]
    assert xgb_cfg["ft_search_space"] == {}
    assert xgb_cfg["ft_unsupervised_search_space"] == {}
    assert xgb_cfg["resn_search_space"] == {}
    assert "hidden_dim" in resn_cfg["resn_search_space"]
    assert resn_cfg["ft_search_space"] == {}
    assert resn_cfg["ft_unsupervised_search_space"] == {}
    assert resn_cfg["xgb_search_space"] == {}

    # Default behavior: all raw feature_list columns are treated as embedding source.
    assert xgb_cfg["feature_list"] == ["pred_ft_emb_0"]
    assert xgb_cfg["categorical_features"] == []

    aug_path = tmp_path / "DataFTEmbed" / "od_bc.csv"
    assert aug_path.exists()
    aug = pd.read_csv(aug_path)
    assert len(aug) == 5
    assert "pred_ft_emb_0" in aug.columns


def test_prepare_step1_config_defaults_to_embedding_role():
    helper = FTWorkflowHelper()
    cfg = helper.prepare_step1_config(
        base_config={"runner": {}, "plot": {}},
    )
    assert cfg["ft_role"] == "embedding"
    assert cfg["output_dir"] == "./ResultsFTEmbedDDP"
    assert cfg["build_oht"] is False
    assert cfg["oht_sparse_csr"] is False
    assert cfg["keep_unscaled_oht"] is False
    assert cfg["optuna_study_prefix"] == "pricing_ft_embed"


def test_prepare_step1_config_accepts_unsupervised_embedding_alias():
    helper = FTWorkflowHelper()
    cfg = helper.prepare_step1_config(
        base_config={"runner": {}, "plot": {}},
        ft_role="unsupervised_embedding",
    )
    assert cfg["ft_role"] == "unsupervised_embedding"
    assert cfg["optuna_study_prefix"] == "pricing_ft_unsup"


def test_ensure_unique_split_key_for_step1_rewrites_csv_and_config(tmp_path: Path):
    helper = FTWorkflowHelper()
    model_name = "od_bc"
    data_dir = tmp_path / "Data"
    data_dir.mkdir(parents=True, exist_ok=True)
    raw_path = data_dir / f"{model_name}.csv"
    pd.DataFrame(
        {
            "_row_id": [7, 7, 8],
            "f1": [1.0, 2.0, 3.0],
            "target": [0.1, 0.2, 0.3],
            "weights": [1.0, 1.0, 1.0],
        }
    ).to_csv(raw_path, index=False)

    cfg_path = tmp_path / "config_ft.json"
    cfg = {
        "data_dir": "./Data",
        "model_list": ["od"],
        "model_categories": ["bc"],
        "feature_list": ["f1", "_row_uid"],
        "categorical_features": ["_row_uid"],
        "target": "target",
        "weight": "weights",
        "split_cache_key_col": "_row_id",
    }
    cfg_path.write_text(json.dumps(cfg), encoding="utf-8")

    result = helper.ensure_unique_split_key_for_step1(
        step1_config_path=str(cfg_path),
        split_key_col="_row_uid",
    )
    assert result["split_key_col"] == "_row_uid"
    assert result["row_count"] == 3

    saved_cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    assert saved_cfg["split_cache_key_col"] == "_row_uid"
    assert "_row_uid" not in saved_cfg["feature_list"]
    assert "_row_uid" not in saved_cfg["categorical_features"]

    updated = pd.read_csv(raw_path)
    assert updated.columns[0] == "_row_uid"
    assert updated["_row_uid"].tolist() == [0, 1, 2]
    assert updated["f1"].tolist() == [1.0, 2.0, 3.0]


def test_ensure_unique_split_key_for_step1_replaces_existing_key_values(tmp_path: Path):
    helper = FTWorkflowHelper()
    model_name = "od_bc"
    data_dir = tmp_path / "Data"
    data_dir.mkdir(parents=True, exist_ok=True)
    raw_path = data_dir / f"{model_name}.csv"
    pd.DataFrame(
        {
            "_row_uid": [100, 100, 200],
            "f1": [9.0, 8.0, 7.0],
            "target": [0.9, 0.8, 0.7],
            "weights": [1.0, 1.0, 1.0],
        }
    ).to_csv(raw_path, index=False)

    cfg_path = tmp_path / "config_ft.json"
    cfg = {
        "data_dir": "./Data",
        "model_list": ["od"],
        "model_categories": ["bc"],
        "feature_list": ["f1"],
        "categorical_features": [],
        "target": "target",
        "weight": "weights",
        "split_cache_key_col": "_row_uid",
    }
    cfg_path.write_text(json.dumps(cfg), encoding="utf-8")

    helper.ensure_unique_split_key_for_step1(
        step1_config_path=str(cfg_path),
        split_key_col="_row_uid",
    )

    updated = pd.read_csv(raw_path)
    assert updated["_row_uid"].tolist() == [0, 1, 2]
    assert updated["f1"].tolist() == [9.0, 8.0, 7.0]


def test_save_configs_uses_embed_primary_names_and_writes_legacy_aliases(tmp_path):
    helper = FTWorkflowHelper()
    helper.step1_config = {"ft_role": "embedding", "runner": {"model_keys": ["ft"]}}
    helper.step2_configs = {
        "xgb": {"stack_model_keys": ["xgb"]},
        "resn": {"stack_model_keys": ["resn"]},
    }
    saved = helper.save_configs(str(tmp_path))
    assert (tmp_path / "config_ft_step1_embed.json").exists()
    assert (tmp_path / "config_xgb_from_ft_embed.json").exists()
    assert (tmp_path / "config_resn_from_ft_embed.json").exists()
    assert (tmp_path / "config_ft_step1_unsupervised.json").exists()
    assert (tmp_path / "config_xgb_from_ft_unsupervised.json").exists()
    assert (tmp_path / "config_resn_from_ft_unsupervised.json").exists()
    assert (tmp_path / "config_xgb_from_ft_step2.json").exists()
    assert (tmp_path / "config_resn_from_ft_step2.json").exists()
    assert saved["xgb_step2"].endswith("config_xgb_from_ft_embed.json")
    assert saved["resn_step2"].endswith("config_resn_from_ft_embed.json")


def test_generate_step2_configs_respects_embedding_source_subset(tmp_path, monkeypatch):
    helper = FTWorkflowHelper()
    cfg_path = _prepare_step1_inputs(
        tmp_path,
        ft_embedding_source_features=["f1"],
    )

    def _fake_alignment(raw, cfg, *, pred_train_rows, pred_test_rows):
        return raw.index[:pred_train_rows], raw.index[pred_train_rows:pred_train_rows + pred_test_rows]

    monkeypatch.setattr(helper, "_resolve_prediction_alignment_indices", _fake_alignment)

    xgb_cfg, _ = helper.generate_step2_configs(
        step1_config_path=str(cfg_path),
        target_models=["xgb"],
    )

    assert xgb_cfg is not None
    assert xgb_cfg["feature_list"] == ["f2", "pred_ft_emb_0"]
    assert xgb_cfg["categorical_features"] == ["f2"]


def test_generate_step2_configs_rejects_invalid_model_keys():
    helper = FTWorkflowHelper()

    with pytest.raises(ValueError, match="Unsupported Step 2 models"):
        helper.generate_step2_configs(
            step1_config_path="dummy.json",
            target_models=["xgb", "invalid_model"],
        )


def test_generate_step2_configs_prefers_split_cache_alignment(tmp_path, monkeypatch):
    helper = FTWorkflowHelper()
    cfg_path = _prepare_step1_inputs(
        tmp_path,
        split_cache_path="./Data/splits/{model_name}_holdout_split.npz",
    )
    cache_path = tmp_path / "Data" / "splits" / "od_bc_holdout_split.npz"
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        cache_path,
        train_idx=np.asarray([0, 2, 4], dtype=np.int64),
        test_idx=np.asarray([1, 3], dtype=np.int64),
        row_count=np.asarray([5], dtype=np.int64),
        meta_json=np.asarray(
            [json.dumps({"split_strategy": "random", "holdout_ratio": 0.4, "rand_seed": 13})]
        ),
    )

    def _must_not_rebuild(*args, **kwargs):
        raise AssertionError("split cache should be used before rebuilding split")

    monkeypatch.setattr(helper, "_resolve_prediction_alignment_indices", _must_not_rebuild)

    xgb_cfg, _ = helper.generate_step2_configs(
        step1_config_path=str(cfg_path),
        target_models=["xgb"],
        augmented_data_dir="./DataFTFromCache",
    )

    assert xgb_cfg is not None
    aug = pd.read_csv(tmp_path / "DataFTFromCache" / "od_bc.csv")
    assert aug["pred_ft_emb_0"].tolist() == [0.1, 0.4, 0.2, 0.5, 0.3]


def test_generate_step2_configs_split_cache_missing_falls_back_to_rebuild(
    tmp_path,
    monkeypatch,
):
    helper = FTWorkflowHelper()
    cfg_path = _prepare_step1_inputs(
        tmp_path,
        split_cache_path="./Data/splits/{model_name}_holdout_split.npz",
    )

    called = {"fallback": False}

    def _fake_alignment(raw, cfg, *, pred_train_rows, pred_test_rows):
        _ = cfg
        called["fallback"] = True
        return raw.index[:pred_train_rows], raw.index[pred_train_rows:pred_train_rows + pred_test_rows]

    monkeypatch.setattr(helper, "_resolve_prediction_alignment_indices", _fake_alignment)

    xgb_cfg, _ = helper.generate_step2_configs(
        step1_config_path=str(cfg_path),
        target_models=["xgb"],
    )
    assert xgb_cfg is not None
    assert called["fallback"] is True


def test_generate_step2_configs_split_cache_seed_string_matches_numeric(
    tmp_path,
    monkeypatch,
):
    helper = FTWorkflowHelper()
    cfg_path = _prepare_step1_inputs(
        tmp_path,
        split_cache_path="./Data/splits/{model_name}_holdout_split.npz",
    )
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    cfg["rand_seed"] = "13"
    cfg_path.write_text(json.dumps(cfg), encoding="utf-8")
    cache_path = tmp_path / "Data" / "splits" / "od_bc_holdout_split.npz"
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        cache_path,
        train_idx=np.asarray([0, 2, 4], dtype=np.int64),
        test_idx=np.asarray([1, 3], dtype=np.int64),
        row_count=np.asarray([5], dtype=np.int64),
        meta_json=np.asarray(
            [json.dumps({"split_strategy": "random", "holdout_ratio": 0.4, "rand_seed": 13})]
        ),
    )

    def _must_not_fallback(*args, **kwargs):
        raise AssertionError("split cache metadata check should accept seed string/int equivalence")

    monkeypatch.setattr(helper, "_resolve_prediction_alignment_indices", _must_not_fallback)

    xgb_cfg, _ = helper.generate_step2_configs(
        step1_config_path=str(cfg_path),
        target_models=["xgb"],
        augmented_data_dir="./DataFTFromCacheSeed",
    )
    assert xgb_cfg is not None


@pytest.mark.parametrize(
    ("augmented_format", "expected_suffix"),
    [("parquet", ".parquet"), ("feather", ".feather")],
)
def test_generate_step2_configs_supports_binary_augmented_formats(
    tmp_path,
    monkeypatch,
    augmented_format,
    expected_suffix,
):
    helper = FTWorkflowHelper()
    cfg_path = _prepare_step1_inputs(tmp_path)

    def _fake_alignment(raw, cfg, *, pred_train_rows, pred_test_rows):
        return raw.index[:pred_train_rows], raw.index[pred_train_rows:pred_train_rows + pred_test_rows]

    captured = {}

    def _fake_write_table(df, path, *, data_format):
        captured["path"] = Path(path)
        captured["format"] = data_format
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("stub", encoding="utf-8")

    monkeypatch.setattr(helper, "_resolve_prediction_alignment_indices", _fake_alignment)
    monkeypatch.setattr(helper, "_write_table", _fake_write_table)

    xgb_cfg, _ = helper.generate_step2_configs(
        step1_config_path=str(cfg_path),
        target_models=["xgb"],
        augmented_data_dir="./DataFTBinary",
        augmented_data_format=augmented_format,
    )

    assert xgb_cfg is not None
    assert captured["format"] == augmented_format
    assert captured["path"].suffix == expected_suffix
    assert captured["path"].exists()
    assert xgb_cfg["data_format"] == augmented_format
    assert xgb_cfg["data_path_template"] == "{model_name}.{ext}"
    assert xgb_cfg["data_dir"] == "./DataFTBinary"
