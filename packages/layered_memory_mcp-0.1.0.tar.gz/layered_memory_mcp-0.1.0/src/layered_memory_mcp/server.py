"""
Layered Memory MCP Server — FastMCP 2.0 Implementation.

A 4-tier knowledge architecture MCP server that extends AI agent memory
beyond token limits. Works with any MCP-compatible agent (Hermes, Claude, etc.).

Usage:
    # stdio transport (default)
    layered-memory-mcp

    # HTTP transport
    layered-memory-mcp --transport http --port 8080

    # Custom home directory
    LAYERED_MEMORY_HOME=/path/to/data layered-memory-mcp
"""

import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Optional

from fastmcp import FastMCP

from .config import MemoryConfig
from .recall import recall, scan_knowledge_files, score_relevance
from .session_scanner import scan_sessions

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

mcp = FastMCP("layered-memory")

# Global config (initialized lazily)
_config: Optional[MemoryConfig] = None


def _get_config() -> MemoryConfig:
    """Get or create config singleton."""
    global _config
    if _config is None:
        _config = MemoryConfig()
    return _config


# ---------------------------------------------------------------------------
# MCP Resources
# ---------------------------------------------------------------------------

@mcp.resource("memory://status")
async def get_memory_status() -> str:
    """Get overall memory system status and space statistics."""
    config = _get_config()

    # L1 knowledge files
    files = scan_knowledge_files(str(config.knowledge_dir))
    total_l1_size = 0
    file_details = []
    for name, path in files.items():
        try:
            size = Path(path).stat().st_size
            total_l1_size += size
            file_details.append({"file": name, "size_bytes": size})
        except Exception:
            pass

    # L0 index (if configured)
    l0_info = {"configured": False}
    if config.l0_index_file and config.l0_index_file.exists():
        try:
            l0_content = config.l0_index_file.read_text(encoding="utf-8")
            l0_info = {
                "configured": True,
                "path": str(config.l0_index_file),
                "size_bytes": len(l0_content.encode("utf-8")),
                "lines": len(l0_content.strip().split("\n")),
            }
        except Exception:
            pass

    # Sessions info
    sessions_info = {"available": False}
    if config.sessions_dir and config.sessions_dir.exists():
        try:
            session_files = list(config.sessions_dir.rglob("*.jsonl"))
            session_files += list(config.sessions_dir.rglob("*.json"))
            sessions_info = {
                "available": True,
                "path": str(config.sessions_dir),
                "total_files": len(session_files),
            }
        except Exception:
            pass

    return json.dumps({
        "status": "healthy",
        "home": str(config.home),
        "l1_knowledge": {
            "total_files": len(files),
            "total_size_bytes": total_l1_size,
            "files": file_details,
        },
        "l0_index": l0_info,
        "sessions": sessions_info,
    }, ensure_ascii=False, indent=2)


@mcp.resource("knowledge://files")
async def list_knowledge_files() -> str:
    """List all L1 knowledge files with metadata."""
    config = _get_config()
    files = scan_knowledge_files(str(config.knowledge_dir))

    file_list = []
    for name, path in files.items():
        try:
            stat = Path(path).stat()
            # Read first line as title hint
            first_line = ""
            with open(path, "r", encoding="utf-8") as f:
                first_line = f.readline().strip().lstrip("# ")
            file_list.append({
                "file": name,
                "size_bytes": stat.st_size,
                "title_hint": first_line[:100],
            })
        except Exception:
            file_list.append({"file": name, "error": "cannot read"})

    return json.dumps({
        "knowledge_dir": str(config.knowledge_dir),
        "total_files": len(file_list),
        "files": file_list,
    }, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def recall_knowledge(
    keyword: str,
    top_n: int = 5,
) -> str:
    """Search L1 knowledge files by keyword with relevance scoring.

    Finds relevant knowledge sections across all markdown files in the
    knowledge directory. Returns matched sections sorted by relevance.

    Args:
        keyword: Search keyword (supports Chinese and English).
        top_n: Maximum number of files to return (default 5).

    Returns:
        JSON with matched files, relevance scores, and content sections.
    """
    config = _get_config()
    result = await asyncio.to_thread(
        recall, keyword, str(config.knowledge_dir), top_n
    )
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def scan_recent_sessions(
    days: int = 3,
    max_sessions: int = 10,
) -> str:
    """Scan recent agent sessions to identify knowledge extraction candidates.

    Reads session files and extracts user messages, assistant topics,
    and tool call patterns for AI-driven knowledge distillation.

    Args:
        days: Look back N days (default 3).
        max_sessions: Maximum sessions to scan (default 10).

    Returns:
        JSON with session summaries for AI analysis.
    """
    config = _get_config()

    if not config.sessions_dir or not config.sessions_dir.exists():
        return json.dumps({
            "success": False,
            "error": "Sessions directory not configured or not found. "
                     "Set LAYERED_MEMORY_SESSIONS_DIR or ensure ~/.hermes/sessions/ exists.",
        })

    result = await asyncio.to_thread(
        scan_sessions, str(config.sessions_dir), days, max_sessions
    )
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_knowledge_file(filename: str) -> str:
    """Read a specific L1 knowledge file by filename.

    Args:
        filename: Name of the knowledge file (e.g. 'dev-principles.md').

    Returns:
        Full content of the knowledge file.
    """
    config = _get_config()
    filepath = config.knowledge_dir / filename

    # Security: prevent path traversal
    try:
        filepath.resolve().relative_to(config.knowledge_dir.resolve())
    except ValueError:
        return json.dumps({"error": "Path traversal not allowed"})

    if not filepath.exists():
        return json.dumps({"error": f"File not found: {filename}"})

    try:
        content = await asyncio.to_thread(filepath.read_text, "utf-8")
        return content
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
async def list_memory_stats() -> str:
    """Get detailed memory space statistics and health report.

    Returns L0/L1 space usage, file counts, and optimization suggestions.
    """
    config = _get_config()
    files = scan_knowledge_files(str(config.knowledge_dir))

    total_size = 0
    oversized = []
    file_stats = []

    for name, path in files.items():
        try:
            size = Path(path).stat().st_size
            total_size += size
            is_oversized = size > 2048  # 2KB threshold
            if is_oversized:
                oversized.append({"file": name, "size_bytes": size})
            file_stats.append({
                "file": name,
                "size_bytes": size,
                "size_kb": round(size / 1024, 1),
                "oversized": is_oversized,
            })
        except Exception:
            pass

    suggestions = []
    if len(files) > 15:
        suggestions.append("Consider consolidating L1 files — more than 15 files may reduce scan efficiency")
    if oversized:
        suggestions.append(f"{len(oversized)} file(s) exceed 2KB threshold — consider splitting for faster recall")

    return json.dumps({
        "l1_knowledge": {
            "total_files": len(files),
            "total_size_bytes": total_size,
            "total_size_kb": round(total_size / 1024, 1),
            "avg_size_kb": round(total_size / max(len(files), 1) / 1024, 1),
            "oversized_files": oversized,
            "files": file_stats,
        },
        "suggestions": suggestions,
    }, ensure_ascii=False, indent=2)


@mcp.tool()
async def search_sessions_by_keyword(
    keyword: str,
    days: int = 7,
    max_results: int = 5,
) -> str:
    """Search session content for a specific keyword.

    Scans recent session files for messages containing the keyword.

    Args:
        keyword: Keyword to search for in session messages.
        days: Look back N days (default 7).
        max_results: Maximum matching sessions to return (default 5).

    Returns:
        JSON with matching session excerpts.
    """
    config = _get_config()

    if not config.sessions_dir or not config.sessions_dir.exists():
        return json.dumps({"success": False, "error": "Sessions directory not configured"})

    from .session_scanner import find_recent_sessions, extract_session_summary

    sessions = await asyncio.to_thread(find_recent_sessions, str(config.sessions_dir), days)

    matches = []
    for s in sessions:
        summary = await asyncio.to_thread(extract_session_summary, s["path"])

        # Check if keyword appears in any user message or assistant topic
        keyword_lower = keyword.lower()
        matched_msgs = [m for m in summary.get("user_messages", []) if keyword_lower in m.lower()]
        matched_topics = [t for t in summary.get("assistant_topics", []) if keyword_lower in t.lower()]

        if matched_msgs or matched_topics:
            matches.append({
                "path": s["path"],
                "mtime": s["mtime"],
                "matched_user_messages": matched_msgs[:3],
                "matched_assistant_topics": matched_topics[:3],
            })

        if len(matches) >= max_results:
            break

    return json.dumps({
        "success": True,
        "keyword": keyword,
        "scan_days": days,
        "total_sessions": len(sessions),
        "matched_sessions": len(matches),
        "matches": matches,
    }, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# MCP Prompts
# ---------------------------------------------------------------------------

@mcp.prompt()
def knowledge_compression_prompt() -> str:
    """Prompt template for AI-driven knowledge compression from sessions.

    Use this prompt with scan_recent_sessions output to extract
    durable knowledge from conversations.
    """
    return """You are a knowledge distillation agent. Your job is to scan recent AI agent sessions and extract stable, factual knowledge that should be preserved for future sessions.

## Rules
1. Only extract STABLE facts — things that will remain true across sessions (configurations, conventions, user preferences, environment details)
2. Do NOT extract: temporary debugging state, one-off commands, data that changes frequently
3. Classify each fact by domain (e.g., infrastructure, development, content)
4. Output facts as declarative statements, not instructions

## Process
1. First, call `scan_recent_sessions` to get session summaries
2. For each interesting session, call `search_sessions_by_keyword` for deeper context
3. Identify new knowledge not yet in L1 files (call `list_knowledge_files` to check)
4. Return a structured list of knowledge to add/update

## Output Format
For each piece of knowledge:
- domain: which L1 file it belongs to (or "NEW" for new domains)
- action: "add" or "update"
- content: the factual knowledge as a declarative statement
- source: which session it came from

Be conservative — when in doubt, don't extract. It's better to miss a fact than to pollute the knowledge base with noise."""


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    """Run the MCP server."""
    import argparse

    parser = argparse.ArgumentParser(description="Layered Memory MCP Server")
    parser.add_argument(
        "--transport",
        choices=["stdio", "http"],
        default="stdio",
        help="Transport mode (default: stdio)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="HTTP port (default: 8080, only used with --transport http)",
    )
    parser.add_argument(
        "--home",
        type=str,
        default=None,
        help="Home directory for memory data (default: ~/.layered-memory/)",
    )
    args = parser.parse_args()

    # Override config if specified
    global _config
    if args.home:
        os.environ["LAYERED_MEMORY_HOME"] = args.home
    _config = MemoryConfig(home=args.home)

    if args.transport == "stdio":
        mcp.run(transport="stdio")
    else:
        mcp.run(transport="http", port=args.port)


if __name__ == "__main__":
    main()
