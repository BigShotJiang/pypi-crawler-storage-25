"""
L1 Knowledge Retrieval Engine.

Searches knowledge files by keyword with relevance scoring.
Pure stdlib, zero external dependencies.
"""

import re
from pathlib import Path
from typing import Optional


def scan_knowledge_files(knowledge_dir: str) -> dict:
    """Scan knowledge directory, return {filename: full_path}."""
    files = {}
    kdir = Path(knowledge_dir)
    if not kdir.exists():
        return files
    for f in sorted(kdir.glob("*.md")):
        files[f.name] = str(f)
    return files


def score_relevance(keyword: str, content: str, filename: str) -> float:
    """Calculate relevance score between keyword and file content."""
    score = 0.0
    kw_lower = keyword.lower()

    # Exact filename match
    if kw_lower in filename.lower():
        score += 10.0

    # Content frequency (capped)
    count = content.lower().count(kw_lower)
    score += min(count * 0.5, 5.0)

    # Heading match bonus
    for line in content.split("\n"):
        if line.startswith("#") and kw_lower in line.lower():
            score += 3.0

    return score


def extract_relevant_sections(keyword: str, content: str, max_sections: int = 3) -> list:
    """Extract markdown sections (## headings) containing the keyword."""
    sections = []
    current = {"title": "Header", "lines": [], "matched": False}

    for line in content.split("\n"):
        if line.startswith("## ") and current["lines"]:
            if current["matched"]:
                sections.append(current)
            current = {"title": line.lstrip("# ").strip(), "lines": [line], "matched": False}
        else:
            current["lines"].append(line)

        if keyword.lower() in line.lower():
            current["matched"] = True

    if current["matched"]:
        sections.append(current)

    return [
        {"title": s["title"], "content": "\n".join(s["lines"]).strip()}
        for s in sections[:max_sections]
    ]


def recall(
    keyword: str,
    knowledge_dir: str,
    top_n: int = 5,
    section_context_lines: int = 2,
) -> dict:
    """Main retrieval function.

    Returns:
        {
            "success": bool,
            "keyword": str,
            "total_files": int,
            "matched_files": int,
            "results": [
                {
                    "file": str,
                    "score": float,
                    "matched_sections": int,
                    "sections": [{"title": str, "content": str}]
                }
            ]
        }
    """
    files = scan_knowledge_files(knowledge_dir)

    if not files:
        return {
            "success": False,
            "error": f"No knowledge files found in {knowledge_dir}",
            "keyword": keyword,
        }

    results = []
    for filename, filepath in files.items():
        try:
            content = Path(filepath).read_text(encoding="utf-8")
        except Exception:
            continue

        score = score_relevance(keyword, content, filename)
        if score > 0:
            sections = extract_relevant_sections(keyword, content)
            results.append({
                "file": filename,
                "score": round(score, 2),
                "matched_sections": len(sections),
                "sections": sections,
            })

    results.sort(key=lambda x: x["score"], reverse=True)
    results = results[:top_n]

    return {
        "success": True,
        "keyword": keyword,
        "total_files": len(files),
        "matched_files": len(results),
        "results": results,
    }
