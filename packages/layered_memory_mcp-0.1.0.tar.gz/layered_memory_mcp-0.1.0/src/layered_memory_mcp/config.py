"""
Configuration for Layered Memory MCP Server.

All paths are configurable via environment variables or constructor arguments.
No hardcoded personal paths.
"""

import os
from pathlib import Path
from typing import Optional


def default_home() -> Path:
    """Default home directory for the memory system.
    
    Priority:
      1. LAYERED_MEMORY_HOME env var
      2. ~/.layered-memory/
    """
    env = os.environ.get("LAYERED_MEMORY_HOME")
    if env:
        return Path(env)
    return Path.home() / ".layered-memory"


def default_knowledge_dir(home: Optional[Path] = None) -> Path:
    """Default directory for L1 knowledge files."""
    base = home or default_home()
    return base / "knowledge"


def default_sessions_dir() -> Optional[Path]:
    """Try to auto-detect agent sessions directory.
    
    Supports:
      - Hermes Agent: ~/.hermes/sessions/
      - Custom: LAYERED_MEMORY_SESSIONS_DIR env var
    """
    env = os.environ.get("LAYERED_MEMORY_SESSIONS_DIR")
    if env:
        return Path(env)
    
    hermes_sessions = Path.home() / ".hermes" / "sessions"
    if hermes_sessions.exists():
        return hermes_sessions
    
    return None


class MemoryConfig:
    """Runtime configuration for the memory server."""
    
    def __init__(
        self,
        home: Optional[str] = None,
        knowledge_dir: Optional[str] = None,
        sessions_dir: Optional[str] = None,
        l0_index_file: Optional[str] = None,
    ):
        self.home = Path(home) if home else default_home()
        self.knowledge_dir = Path(knowledge_dir) if knowledge_dir else default_knowledge_dir(self.home)
        self.sessions_dir = Path(sessions_dir) if sessions_dir else default_sessions_dir()
        self.l0_index_file = Path(l0_index_file) if l0_index_file else None
        
        # Ensure directories exist
        self.knowledge_dir.mkdir(parents=True, exist_ok=True)
