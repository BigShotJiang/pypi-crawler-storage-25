"""
Session Scanner for Knowledge Compression.

Scans agent session files and extracts summaries for AI-driven knowledge extraction.
Supports Hermes Agent JSONL session format.
"""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional


def find_recent_sessions(sessions_dir: str, days: int = 7) -> list:
    """Find session files modified within the last N days."""
    cutoff = datetime.now() - timedelta(days=days)
    sessions = []

    sdir = Path(sessions_dir)
    if not sdir.exists():
        return sessions

    # Scan JSONL files (Hermes format)
    for f in sorted(sdir.rglob("*.jsonl")):
        try:
            mtime = datetime.fromtimestamp(f.stat().st_mtime)
            if mtime >= cutoff:
                sessions.append({
                    "path": str(f),
                    "mtime": mtime.isoformat(),
                    "size": f.stat().st_size,
                })
        except Exception:
            continue

    # Also scan JSON files
    for f in sorted(sdir.rglob("*.json")):
        try:
            mtime = datetime.fromtimestamp(f.stat().st_mtime)
            if mtime >= cutoff:
                sessions.append({
                    "path": str(f),
                    "mtime": mtime.isoformat(),
                    "size": f.stat().st_size,
                })
        except Exception:
            continue

    return sorted(sessions, key=lambda x: x["mtime"], reverse=True)


def extract_session_summary(filepath: str, max_lines: int = 50) -> dict:
    """Extract summary from a session file (JSONL format).

    Returns:
        {
            "path": str,
            "user_messages": [str],
            "assistant_topics": [str],
            "tool_calls": [str],
            "truncated": bool (optional)
        }
    """
    result = {
        "path": filepath,
        "user_messages": [],
        "assistant_topics": [],
        "tool_calls": [],
    }

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            for i, line in enumerate(f):
                if i >= max_lines:
                    result["truncated"] = True
                    break
                try:
                    entry = json.loads(line.strip())
                    role = entry.get("role", "")
                    content = entry.get("content", "")

                    if role == "user" and content and len(content) < 500:
                        result["user_messages"].append(content[:200])
                    elif role == "assistant" and content:
                        text = (content[:100] if isinstance(content, str) else str(content)[:100])
                        if text and text not in result["assistant_topics"]:
                            result["assistant_topics"].append(text)

                    # Extract tool call names
                    for tc in entry.get("tool_calls", [])[:3]:
                        fn = tc.get("function", {}).get("name", "")
                        if fn:
                            result["tool_calls"].append(fn)

                except json.JSONDecodeError:
                    continue
    except Exception as e:
        result["error"] = str(e)

    return result


def scan_sessions(sessions_dir: str, days: int = 3, max_sessions: int = 10) -> dict:
    """Scan recent sessions and return summaries.

    Returns:
        {
            "generated_at": str,
            "scan_days": int,
            "total_sessions": int,
            "sessions": [dict]
        }
    """
    sessions = find_recent_sessions(sessions_dir, days)

    output = {
        "generated_at": datetime.now().isoformat(),
        "scan_days": days,
        "total_sessions": len(sessions),
        "sessions": [],
    }

    for s in sessions[:max_sessions]:
        summary = extract_session_summary(s["path"])
        summary["mtime"] = s["mtime"]
        summary["size"] = s["size"]
        output["sessions"].append(summary)

    return output
