"""Tests for Layered Memory MCP Server."""

import json
import os
import tempfile
from pathlib import Path

import pytest

from layered_memory_mcp.config import MemoryConfig
from layered_memory_mcp.recall import recall, scan_knowledge_files, score_relevance
from layered_memory_mcp.session_scanner import scan_sessions


@pytest.fixture
def knowledge_dir(tmp_path):
    """Create a temp knowledge directory with sample files."""
    kdir = tmp_path / "knowledge"
    kdir.mkdir()

    (kdir / "infrastructure.md").write_text("""## Servers
- Production: prod.example.com
- Staging: stage.example.com

## Database
- PostgreSQL on db.example.com:5432
""", encoding="utf-8")

    (kdir / "development.md").write_text("""## Code Style
- Python 3.12+
- Formatter: ruff format

## Testing
- Framework: pytest
""", encoding="utf-8")

    return str(kdir)


@pytest.fixture
def sessions_dir(tmp_path):
    """Create a temp sessions directory with a sample session."""
    sdir = tmp_path / "sessions"
    sdir.mkdir()

    session_file = sdir / "2026-01-01.jsonl"
    lines = [
        json.dumps({"role": "user", "content": "How do I deploy to production?"}),
        json.dumps({"role": "assistant", "content": "You can deploy using ./deploy.sh --env production"}),
        json.dumps({"role": "user", "content": "What's the database connection?"}),
        json.dumps({"role": "assistant", "content": "PostgreSQL is on db.example.com:5432"}),
    ]
    session_file.write_text("\n".join(lines), encoding="utf-8")

    return str(sdir)


class TestRecall:
    def test_scan_knowledge_files(self, knowledge_dir):
        files = scan_knowledge_files(knowledge_dir)
        assert len(files) == 2
        assert "infrastructure.md" in files
        assert "development.md" in files

    def test_recall_by_keyword(self, knowledge_dir):
        result = recall("database", knowledge_dir)
        assert result["success"] is True
        assert result["matched_files"] >= 1

        # Should find infrastructure.md (has "Database" heading)
        files_found = [r["file"] for r in result["results"]]
        assert "infrastructure.md" in files_found

    def test_recall_no_match(self, knowledge_dir):
        result = recall("nonexistent-topic-xyz", knowledge_dir)
        assert result["success"] is True
        assert result["matched_files"] == 0

    def test_recall_empty_dir(self, tmp_path):
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()
        result = recall("test", str(empty_dir))
        assert result["success"] is False
        assert "No knowledge files" in result["error"]

    def test_score_relevance(self):
        score = score_relevance(
            "database",
            "## Database\n- PostgreSQL on db.example.com",
            "infrastructure.md"
        )
        assert score > 0

    def test_recall_top_n(self, knowledge_dir):
        result = recall("test", knowledge_dir, top_n=1)
        assert len(result["results"]) <= 1


class TestSessionScanner:
    def test_scan_sessions(self, sessions_dir):
        result = scan_sessions(sessions_dir, days=30)
        assert result["total_sessions"] >= 1
        assert len(result["sessions"]) >= 1

    def test_session_summary_content(self, sessions_dir):
        result = scan_sessions(sessions_dir, days=30)
        session = result["sessions"][0]
        assert len(session["user_messages"]) > 0
        assert "deploy" in " ".join(session["user_messages"]).lower()

    def test_scan_sessions_empty_dir(self, tmp_path):
        empty_dir = tmp_path / "empty_sessions"
        empty_dir.mkdir()
        result = scan_sessions(str(empty_dir), days=30)
        assert result["total_sessions"] == 0


class TestConfig:
    def test_default_config(self, tmp_path, monkeypatch):
        monkeypatch.setenv("LAYERED_MEMORY_HOME", str(tmp_path / "mem"))
        config = MemoryConfig()
        assert config.home == tmp_path / "mem"
        assert config.knowledge_dir.exists()

    def test_custom_knowledge_dir(self, tmp_path):
        kdir = tmp_path / "custom-knowledge"
        config = MemoryConfig(knowledge_dir=str(kdir))
        assert config.knowledge_dir == kdir
        assert config.knowledge_dir.exists()
