import warnings
from typing import Union, List

Number = Union[int, float]


# ---------- VALIDATORS ----------

def _validate_numbers(*args):
    for arg in args:
        if not isinstance(arg, (int, float)):
            raise TypeError(f"Invalid type {type(arg)}. Only int or float allowed.")


def _validate_number_list(numbers: List[Number]):
    if not isinstance(numbers, (list, tuple)):
        raise TypeError("Input must be a list")

    if len(numbers) == 0:
        raise ValueError("List cannot be empty")

    for num in numbers:
        if not isinstance(num, (int, float)):
            raise TypeError(f"Invalid element {type(num)} in list. Only int or float allowed.")


# ---------- ARITHMETIC ----------

def add_numbers(num1: Number, num2: Number) -> Number:
    _validate_numbers(num1, num2)
    return num1 + num2


def subtract_numbers(num1: Number, num2: Number) -> Number:
    _validate_numbers(num1, num2)
    return num1 - num2


def multiply_numbers(num1: Number, num2: Number) -> Number:
    _validate_numbers(num1, num2)
    return num1 * num2


def divide_numbers(num1: Number, num2: Number) -> float:
    _validate_numbers(num1, num2)

    if num2 == 0:
        raise ZeroDivisionError("Cannot divide by zero")

    return num1 / num2


def modulus_numbers(num1: Number, num2: Number) -> Number:
    _validate_numbers(num1, num2)

    if num2 == 0:
        raise ZeroDivisionError("Cannot perform modulus with zero")

    return num1 % num2


def power_numbers(num1: Number, num2: Number) -> Number:
    _validate_numbers(num1, num2)

    if num1 < 0 and not float(num2).is_integer():
        warnings.warn(
            "Negative base with fractional exponent may return complex result",
            RuntimeWarning
        )

    return num1 ** num2


# ---------- STATISTICS ----------

def mean_numbers(numbers: List[Number]) -> float:
    _validate_number_list(numbers)
    return sum(numbers) / len(numbers)


def median_numbers(numbers: List[Number]) -> float:
    _validate_number_list(numbers)

    sorted_nums = sorted(numbers)
    n = len(sorted_nums)
    mid = n // 2

    if n % 2 == 0:
        return (sorted_nums[mid - 1] + sorted_nums[mid]) / 2
    return sorted_nums[mid]


def mode_numbers(numbers: List[Number]) -> List[Number]:
    _validate_number_list(numbers)

    freq = {}
    for num in numbers:
        freq[num] = freq.get(num, 0) + 1

    max_count = max(freq.values())
    modes = [k for k, v in freq.items() if v == max_count]

    if len(modes) == len(freq):
        warnings.warn("No unique mode found (all values equally frequent)", RuntimeWarning)

    return modes


def variance_numbers(numbers: List[Number]) -> float:
    _validate_number_list(numbers)

    mean = mean_numbers(numbers)
    return sum((x - mean) ** 2 for x in numbers) / len(numbers)


def std_deviation_numbers(numbers: List[Number]) -> float:
    _validate_number_list(numbers)
    return variance_numbers(numbers) ** 0.5


def min_number(numbers: List[Number]) -> Number:
    _validate_number_list(numbers)
    return min(numbers)


def max_number(numbers: List[Number]) -> Number:
    _validate_number_list(numbers)
    return max(numbers)


def range_numbers(numbers: List[Number]) -> Number:
    _validate_number_list(numbers)
    return max(numbers) - min(numbers)
