from setuptools import setup, find_packages

with open('README.md', encoding='utf-8') as f:
    readme = f.read()

try:
    with open('CHANGELOG.txt', encoding='utf-8') as f:
        changelog = f.read()
except FileNotFoundError:
    changelog = ""

long_description = readme + "\n\n" + changelog

classifiers = [
    'Development Status :: 3 - Alpha',
    'Intended Audience :: Education',
    'Operating System :: OS Independent',
    'License :: OSI Approved :: MIT License',
    'Programming Language :: Python :: 3'
]

setup(
    name='download-premium-calculator',
    version='0.0.1',
    description='A simple arithmetic and statistics calculator library',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='',
    author='krish',
    license='MIT',
    classifiers=classifiers,
    keywords='calculator math statistics python',
    packages=find_packages(),
    install_requires=[]
)