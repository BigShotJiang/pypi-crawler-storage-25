PremiumCalculator Library

A simple Python library for arithmetic and basic statistics operations.

---

Folder Name:
PremiumCalculator

---

Features:

Arithmetic Operations:

- Addition
- Subtraction
- Multiplication
- Division
- Modulus
- Power

Statistics Operations:

- Mean
- Median
- Mode
- Variance
- Standard Deviation
- Min / Max
- Range

---

Usage:

Import the functions in your Python file:

from PremiumCalculator import \*

Example:

print(add_numbers(5, 3))

nums = [1, 2, 2, 3]
print(mean_numbers(nums))

---

Notes:

- Supports only int and float values
- Raises errors for invalid input
- Division by zero is not allowed

---

Author:
Krish
