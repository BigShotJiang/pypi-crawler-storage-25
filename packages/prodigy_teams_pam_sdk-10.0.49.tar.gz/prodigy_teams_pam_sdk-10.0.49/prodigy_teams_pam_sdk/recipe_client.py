import uuid
from datetime import datetime
from typing import Any, Type, Union
from uuid import UUID

import uuid_utils
from pydantic import AliasChoices, BaseModel, Field
from pydantic_settings import BaseSettings

from .client.full_client import Client
from .models import MetricsCreating, MetricsLogging


def uuid7() -> uuid.UUID:
    """Generate a UUIDv7 (time-sortable) as a stdlib uuid.UUID."""
    return uuid.UUID(int=uuid_utils.uuid7().int)


SUPPORTED = [int, float, str]
MetricsValue = Union[int, float, str, BaseModel]


class Settings(BaseSettings):
    pam_bootstrap_token: str = Field(
        default="",
        validation_alias=AliasChoices(
            "PRODIGY_TEAMS_PAM_BOOTSTRAP_TOKEN",
            "PRODIGY_TEAMS_JOB_TOKEN",
        ),
    )
    pam_host: str = ""
    broker_bootstrap_token: str = Field(
        default="",
        validation_alias="PRODIGY_TEAMS_BROKER_BOOTSTRAP_TOKEN",
    )
    broker_host: str = Field(
        default="",
        validation_alias="PRODIGY_TEAMS_BROKER_HOST",
    )
    job_id: UUID | None = None
    execution_id: UUID | None = None
    broker_id: UUID | None = None

    @property
    def job_token(self) -> str:
        """Compatibility alias for the PAM bootstrap token."""
        return self.pam_bootstrap_token

    def has_broker_auth(self) -> bool:
        return bool(self.broker_host and self.broker_bootstrap_token)

    def is_valid(self) -> bool:
        values = [
            self.pam_bootstrap_token,
            self.pam_host,
            self.job_id,
            self.execution_id,
            self.broker_id,
        ]
        return all(x for x in values)

    model_config = {"env_prefix": "PRODIGY_TEAMS_"}


def get_pam_client(pam_host: str, job_token: str) -> Client:
    """Exchange a PAM bootstrap token for a PAM access token.

    The preferred workload env var is ``PRODIGY_TEAMS_PAM_BOOTSTRAP_TOKEN``.
    ``PRODIGY_TEAMS_JOB_TOKEN`` is still accepted as a legacy fallback.
    """
    return Client.from_job_token_sync(pam_host, job_token)


async def get_authenticated_pam_client(settings: Settings) -> Client:
    """Exchange the broker token for a PAM token and return an authenticated client."""
    return await Client.from_job_token(settings.pam_host, settings.job_token)


class Metrics:
    client: Client | None
    name: str
    id: UUID
    type: Type[MetricsValue]
    cfg: Settings

    def __init__(self, name: str, metric_type: Type[MetricsValue]) -> None:
        self._validate_type(metric_type)
        self.cfg = Settings()
        is_valid = self.cfg.is_valid()
        if is_valid:
            self.client = get_pam_client(self.cfg.pam_host, self.cfg.job_token)
        else:
            self.client = None
        self.name = name
        self.id = uuid7()
        self.type = metric_type
        self.initialize()

    @property
    def type_schema(self) -> dict[str, Any]:
        if issubclass(self.type, BaseModel):
            return self.type.model_json_schema()
        return {"type": self.type.__name__}

    def initialize(self) -> None:
        if self.client is not None:
            assert self.cfg.job_id
            assert self.cfg.execution_id
            body = MetricsCreating(
                id=self.id,
                name=self.name,
                job_id=self.cfg.job_id,
                execution_id=self.cfg.execution_id,
                metrics_schema=self.type_schema,
            )
            self.client.for_cluster.init_metrics(body)
        else:  # TODO
            print("INIT METRICS", self.name, self.type_schema)

    def log(self, value: MetricsValue, final: bool = False) -> None:
        if not isinstance(value, self.type):
            raise ValueError(
                f"Can't log metric of type {type(value)}: doesn't match "
                f"specified metrics type ({self.type})"
            )
        data = value.model_dump_json() if isinstance(value, BaseModel) else value
        timestamp = datetime.now()
        if self.client is not None:
            body = MetricsLogging(
                timestamp=timestamp, id=self.id, value=data, final=final
            )
            self.client.for_cluster.log_metrics(body)
        else:  # TODO
            print("LOG METRICS", self.name, timestamp, data)

    def _validate_type(self, metric_type: Type[MetricsValue]) -> None:
        if metric_type not in SUPPORTED and not isinstance(
            metric_type, type(BaseModel)
        ):
            raise ValueError(
                f"Unsupported metrics type {metric_type}. The type can either "
                f"be one of {SUPPORTED} or a pydantic.BaseModel subclass"
            )
