from ..models import (
    ReleaseCreating,
    ReleaseDeleting,
    ReleaseDetail,
    ReleaseReading,
    ReleaseSummary,
)
from .base import ModelClient


class Release(
    ModelClient[
        ReleaseCreating,
        ReleaseReading,
        ReleaseCreating,
        ReleaseDeleting,
        ReleaseSummary,
        ReleaseDetail,
    ]
):
    Creating = ReleaseCreating
    Reading = ReleaseReading
    Deleting = ReleaseDeleting
    Summary = ReleaseSummary
    Detail = ReleaseDetail
