from typing import cast
from uuid import UUID

from ..models import (
    ClusterSettingsDetail,
    ClusterSettingsReading,
    ClusterSettingsUpdating,
)
from .base import BaseClient


class ClusterSettings(BaseClient):
    def read(
        self, query: ClusterSettingsReading | None = None, **kwargs
    ) -> ClusterSettingsDetail:
        if query is None:
            query = ClusterSettingsReading(**kwargs)
        res = self.request(
            "POST",
            endpoint="read",
            data=query,
            return_model=ClusterSettingsDetail,
        )
        return cast(ClusterSettingsDetail, res)

    def ensure(self, broker_id: UUID) -> ClusterSettingsDetail:
        res = self.request(
            "POST",
            endpoint="ensure",
            data=ClusterSettingsReading(broker_id=broker_id),
            return_model=ClusterSettingsDetail,
        )
        return cast(ClusterSettingsDetail, res)

    def update(self, data: ClusterSettingsUpdating) -> ClusterSettingsDetail:
        res = self.request(
            "POST",
            endpoint="update",
            data=data,
            return_model=ClusterSettingsDetail,
        )
        return cast(ClusterSettingsDetail, res)
